#!/usr/bin/env python3
"""Independent finite-syntax audit for CR and equality-bit rooted induction.

This checks syntax, substitution, and exact sizes; it is NOT a proof checker
for the mathematical interpretation theorem. Both schemata are compared in
the SAME term grammar, including the logical equality-bit term bit(s,t).
Frozen recursor descriptors are included in the optional expanded and shared
dictionary metrics. Only Python's standard library is required.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import random
from typing import Optional


@dataclass(frozen=True)
class Descriptor:
    body: "Term"


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple["Term", ...] = ()
    name: Optional[str] = None
    descriptor: Optional[Descriptor] = None


@dataclass(frozen=True)
class Formula:
    kind: str
    parts: tuple["Formula", ...] = ()
    terms: tuple[Term, ...] = ()
    binder: Optional[str] = None


def var(name):
    return Term("var", name=name)


ZERO = Term("zero")
N, A, V, W = (var(s) for s in ("n", "a", "v", "w"))


def succ(t):
    return Term("succ", (t,))


ONE = succ(ZERO)


def bit(s, t):
    return Term("bit", (s, t))


def rec(d, n, a):
    return Term("rec", (n, a), descriptor=d)


def substitute(t, mapping):
    """Simultaneous active substitution; never descend into descriptor bodies."""
    if t.kind == "var":
        return mapping.get(t.name, t)
    return Term(t.kind, tuple(substitute(a, mapping) for a in t.args),
                t.name, t.descriptor)


def free_term(t):
    if t.kind == "var":
        return {t.name}
    return set().union(*(free_term(a) for a in t.args)) if t.args else set()


def occurrences(t, variable):
    return int(t.kind == "var" and t.name == variable) + sum(
        occurrences(a, variable) for a in t.args)


def term_size(t, expanded=False):
    extra = term_size(t.descriptor.body, True) if (
        expanded and t.descriptor is not None) else 0
    return 1 + extra + sum(term_size(a, expanded) for a in t.args)


def eq(s, t):
    return Formula("eq", terms=(s, t))


def connective(kind, *parts):
    return Formula(kind, parts=tuple(parts))


def forall(name, body):
    return Formula("all", parts=(body,), binder=name)


BOTTOM = Formula("bottom")
SIGMA = connective("imp", eq(ZERO, ONE), BOTTOM)


def formula_size(f, expanded=False):
    return 1 + sum(term_size(t, expanded) for t in f.terms) + sum(
        formula_size(p, expanded) for p in f.parts)


def free_formula(f):
    out = set().union(*(free_term(t) for t in f.terms),
                      *(free_formula(p) for p in f.parts))
    return out - {f.binder} if f.kind == "all" else out


def quantifier_profile(f):
    children = [quantifier_profile(p) for p in f.parts]
    own = int(f.kind == "all")
    return (own + sum(c[0] for c in children),
            own + max((c[1] for c in children), default=0))


def all_term_nodes(t, include_descriptors=False):
    yield t
    for a in t.args:
        yield from all_term_nodes(a, include_descriptors)
    if include_descriptors and t.descriptor is not None:
        yield from all_term_nodes(t.descriptor.body, True)


def formula_terms(f):
    for t in f.terms:
        yield t
    for p in f.parts:
        yield from formula_terms(p)


def descriptors(f):
    return {node.descriptor for t in formula_terms(f)
            for node in all_term_nodes(t, True)
            if node.descriptor is not None}


def shared_size(f):
    """Active formula plus each distinct stored descriptor body charged once."""
    return formula_size(f) + sum(term_size(d.body) for d in descriptors(f))


def syntax_check(f, profile=(3, 3)):
    assert free_formula(f) == set()
    assert quantifier_profile(f) == profile
    nodes = [node for t in formula_terms(f) for node in all_term_nodes(t)]
    assert {node.name for node in nodes if node.kind == "var"} <= {"n", "a"}
    arities = {"var": 0, "zero": 0, "succ": 1, "rec": 2, "bit": 2}
    for node in nodes:
        assert len(node.args) == arities[node.kind]
        if node.descriptor is not None:
            assert free_term(node.descriptor.body) <= {"v", "w"}


def schema(u, mode="adjacent", depth_two=False):
    d = Descriptor(substitute(u, {"n": V, "a": W}))
    base = eq(rec(d, ZERO, A), A)
    step = eq(rec(d, succ(N), A),
              substitute(u, {"n": rec(d, N, A), "a": N}))
    computation = connective("and", SIGMA, connective("and", base, step))

    def endpoint(n):
        left = substitute(u, {"n": n, "a": A})
        if mode != "adjacent":
            return eq(left, ZERO)
        return eq(left, substitute(u, {"n": n, "a": succ(A)}))

    def rooted(n):
        return connective("or", eq(n, ZERO), endpoint(n))

    if mode == "ordinary_zero":
        premise = connective("and", endpoint(ZERO), forall("n",
            connective("imp", endpoint(N), endpoint(succ(N)))))
        conclusion = endpoint(N)
    else:
        assert mode in {"adjacent", "rooted_zero"}
        premise = forall("n", connective("imp", rooted(N), endpoint(succ(N))))
        conclusion = rooted(N)
    if depth_two:
        return forall("a", connective("and", forall("n", computation),
            connective("imp", premise, forall("n", conclusion))))
    return forall("a", forall("n", connective("and", computation,
        connective("imp", premise, conclusion))))


def audit(u):
    old = schema(u)
    new = schema(u, "ordinary_zero")
    rooted = schema(u, "rooted_zero")
    old2 = schema(u, "adjacent", True)
    new2 = schema(u, "ordinary_zero", True)
    rooted2 = schema(u, "rooted_zero", True)
    for f in (old, new, rooted):
        syntax_check(f)
    for f in (old2, new2, rooted2):
        syntax_check(f, (4, 2))
    m, i, j = term_size(u), occurrences(u, "n"), occurrences(u, "a")
    old_count, new_count = formula_size(old), formula_size(new)
    assert old_count == 35 + 7*m + 4*i + 3*j
    assert new_count == 33 + 5*m + 3*i
    assert formula_size(rooted) == 38 + 4*m + 3*i
    for f, f2 in ((old, old2), (new, new2), (rooted, rooted2)):
        assert formula_size(f2) == formula_size(f) + 1
        assert formula_size(f2, True) == formula_size(f, True) + 1
    saving = old_count - new_count
    assert saving == 2 + 2*m + i + 3*j
    assert saving >= 4
    root_saving = old_count - formula_size(rooted)
    assert root_saving == 3*m + i + 3*j - 3
    assert root_saving >= 0
    assert (root_saving == 0) == (u == ZERO)

    mf = term_size(u, True)
    assert formula_size(old, True) == 35 + (9+i)*mf + 4*i + 3*j
    assert formula_size(new, True) == 33 + (7+i)*mf + 3*i
    assert formula_size(rooted, True) == 38 + (6+i)*mf + 3*i
    assert formula_size(old, True) - formula_size(new, True) == 2+2*mf+i+3*j
    assert formula_size(old, True) - formula_size(rooted, True) == 3*mf+i+3*j-3
    assert descriptors(old) == descriptors(new)
    assert shared_size(old) - shared_size(new) == saving
    return {"m": m, "i": i, "j": j, "old": old_count, "new": new_count,
            "saving": saving, "rooted_zero": formula_size(rooted),
            "rooted_zero_saving": root_saving,
            "depth_two_old": formula_size(old2),
            "depth_two_new": formula_size(new2),
            "old_expanded": formula_size(old, True),
            "new_expanded": formula_size(new, True),
            "shared_descriptor_count": len(descriptors(old))}


def main():
    counter = Descriptor(W)
    identity = Descriptor(V)
    successor = Descriptor(succ(V))
    predicate = Descriptor(bit(V, W))
    predecessor = Descriptor(rec(counter, V, ZERO))
    nested = Descriptor(rec(predicate, rec(counter, V, ZERO), W))
    available = (counter, identity, successor, predicate, predecessor, nested)

    # This distinguishes actual frozen substitution from replacing variables
    # indiscriminately inside a symbol name. Both active slots are replaced.
    frozen = rec(nested, N, A)
    changed = substitute(frozen, {"n": succ(A), "a": N, "v": ZERO, "w": ZERO})
    assert changed.args == (succ(A), N)
    assert changed.descriptor is nested
    assert changed.descriptor.body == nested.body
    assert free_term(changed) == {"a", "n"}
    # A substituted expression is not subjected to a second substitution.
    assert substitute(N, {"n": A, "a": ZERO}) == A

    examples = {
        "0": ZERO, "n": N, "a": A, "S(n)": succ(N), "S(a)": succ(A),
        "R_w(n,a)": rec(counter, N, A),
        "p(n)=R_w(n,0)": rec(counter, N, ZERO),
        "bit(n,a)": bit(N, A),
        "bit(S(n),a)": bit(succ(N), A),
        "nested_descriptor(n,a)": frozen,
        "R_v(n,n)": rec(identity, N, N),
    }
    results = {name: audit(t) for name, t in examples.items()}

    rng = random.Random(20261102)

    def random_term(depth):
        if depth == 0 or rng.randrange(5) == 0:
            return rng.choice((ZERO, N, A))
        constructor = rng.randrange(3)
        if constructor == 0:
            return succ(random_term(depth-1))
        if constructor == 1:
            return bit(random_term(depth-1), random_term(depth-1))
        return rec(rng.choice(available), random_term(depth-1), random_term(depth-1))

    sample_count = 1500
    maximum_active_size = 0
    for _ in range(sample_count):
        t = random_term(rng.randrange(6))
        result = audit(t)
        maximum_active_size = max(maximum_active_size, result["m"])

    # Pure FOL encoding of the equality-bit term contributes a fixed axiom.
    # Its 24 nodes are reported, not silently absorbed into the term grammar.
    equal = eq(N, A)
    unequal = connective("imp", equal, BOTTOM)
    bit_definition = forall("n", forall("a", connective("or",
        connective("and", equal, eq(bit(N, A), ZERO)),
        connective("and", unequal, eq(bit(N, A), ONE)))))
    assert formula_size(bit_definition) == 24
    assert quantifier_profile(bit_definition) == (2, 2)
    assert free_formula(bit_definition) == set()

    print(json.dumps({
        "status": "passed",
        "scope": "Finite syntax and size checks only; no arithmetic proof checking.",
        "common_grammar": "0, S, frozen binary recursors, logical binary equality-bit terms",
        "old_active": "35+7m+4i+3j",
        "new_active": "33+5m+3i",
        "active_saving": "2+2m+i+3j; strictly positive for every legal input",
        "rooted_zero_active": "38+4m+3i",
        "rooted_zero_saving": "3m+i+3j-3; zero exactly for literal input0",
        "old_descriptor_expanded": "35+(9+i)M+4i+3j",
        "new_descriptor_expanded": "33+(7+i)M+3i",
        "expanded_saving": "2+2M+i+3j",
        "rooted_zero_descriptor_expanded": "38+(6+i)M+3i",
        "shared_dictionary_saving": "same as active; descriptor dictionaries identical",
        "quantifier_occurrences": 3,
        "maximum_quantifier_depth": 3,
        "depth_two_variant": {"added_nodes": 1, "quantifier_occurrences": 4,
                              "maximum_quantifier_depth": 2},
        "active_individual_variable_names": ["n", "a"],
        "maximum_arithmetic_function_arity": 2,
        "equality_bit_term_arity": 2,
        "frozen_substitution": "passed",
        "simultaneous_substitution": "passed",
        "random_seed": 20261102,
        "random_terms_checked": sample_count,
        "maximum_sample_active_term_size": maximum_active_size,
        "representative_inputs": results,
        "pure_first_order_equality_bit_definition_nodes": 24,
        "equality_bit_definition_form": "forall x,y [(x=y and bit(x,y)=0) or ((x=y -> bottom) and bit(x,y)=S0)]",
        "not_counted_as_free": "Equality-bit syntax and its semantic definition rules must be disclosed separately.",
    }, indent=2))


if __name__ == "__main__":
    main()
