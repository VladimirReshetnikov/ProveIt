#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p verification
python3 check_artifacts.py --output syntax_results.json > verification/python.log
cat verification/python.log
if [[ -n "${LEAN_BIN:-}" ]]; then
  "$LEAN_BIN" OneContraction.lean > verification/lean.log 2>&1
  cat verification/lean.log
elif command -v lean >/dev/null 2>&1; then
  lean OneContraction.lean > verification/lean.log 2>&1
  cat verification/lean.log
else
  echo 'Lean is unavailable: the formal certificate was NOT rechecked.' >&2
fi
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex > verification/latex.log 2>&1
echo 'Compiled report.pdf.'
