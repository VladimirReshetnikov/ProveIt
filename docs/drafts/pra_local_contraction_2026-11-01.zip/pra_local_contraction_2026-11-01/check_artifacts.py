#!/usr/bin/env python3
"""Replay finite-syntax diagnostics for the two-variable 18-node schema.

These checks exercise the exact admission boundary, stored-description
binding, one-contraction certificates, the essential two-mode restriction,
the deliberately shadowed emitted syntax, and the disclosed node ledger.
They do not verify the infinite theory, arithmetic bridge, or interpretation
proof. No finite numerical experiment is offered as a substitute for those
proofs. Checks use explicit exceptions and remain active under Python -O.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from axiom_check import (
    A, B, U, V, X, Y, Z, ZERO,
    And, Bottom, Certificate, COUNTER_DESCRIPTION, Description, Eq, Imp, Or,
    Rec, Succ, SyntaxErrorDetail, Var,
    admit, certificate_is_valid, coverage_matrix, display_metrics,
    emit_axiom, emitted_axiom_nodes, find_base_certificate,
    formula_from_data, formula_to_data, is_literal_reflexive, predecessor,
    replay_certificate, sentence_variable_audit, separation_matrix,
    substitute_formula, substitute_term, syntax_nodes,
    validate_description, validate_formula, validate_term,
    variable_occurrences, zero_instance,
)


class CheckFailure(RuntimeError):
    pass


def run_checks() -> dict:
    checked: list[str] = []
    positives: list[dict] = []
    negatives: list[str] = []

    def require(condition: bool, label: str) -> None:
        if not condition:
            raise CheckFailure(label)
        checked.append(label)

    def expect_syntax_error(action, label: str) -> None:
        try:
            action()
        except SyntaxErrorDetail:
            checked.append(label)
        else:
            raise CheckFailure(label)

    def positive(name: str, formula, expected_rule: str, *, classical: bool = True) -> None:
        result = admit(formula)
        require(result.accepted, f"{name}: intuitionistic admission")
        require(result.certificate is not None, f"{name}: certificate returned")
        certificate = result.certificate
        require(certificate.rule == expected_rule, f"{name}: expected rule {expected_rule}")
        base = zero_instance(formula)
        require(certificate_is_valid(base, certificate), f"{name}: certificate replay")
        require(admit(formula, intuitionistic=False).accepted == classical,
                f"{name}: classical grammar boundary")
        require(formula_from_data(formula_to_data(formula)) == formula,
                f"{name}: complete JSON round trip")
        actual = emit_axiom(formula)
        audit = sentence_variable_audit(actual)
        require(audit["all_names"] == ["a", "b"], f"{name}: only two actual names")
        require(audit["binders_in_preorder"] == ["a", "b", "b"],
                f"{name}: deliberate quantifier shadowing")
        require(audit["free_names"] == [], f"{name}: emitted sentence is closed")
        expanded = emitted_axiom_nodes(formula)
        expected = 5 + 3 * syntax_nodes(formula) + variable_occurrences(formula, "x")
        require(expanded == expected, f"{name}: independent expanded-size identity")
        require(emitted_axiom_nodes(formula, universal_conclusion=True) == expanded + 1,
                f"{name}: universal conclusion adds one binder")
        positives.append({
            "name": name,
            "matrix_nodes": syntax_nodes(formula),
            "raw_counter_occurrences": variable_occurrences(formula, "x"),
            "expanded_axiom_nodes": expanded,
            "certificate": certificate.to_data(),
            "raw_free_variables": sorted(validate_formula(formula)),
            "actual_variable_audit": audit,
            "matrix": formula_to_data(formula),
        })

    def negative(name: str, formula, *, gate_must_fail: bool = True) -> None:
        require(not admit(formula).accepted, f"{name}: rejected by complete specification")
        if gate_must_fail:
            require(find_base_certificate(zero_instance(formula)) is None,
                    f"{name}: exact local gate rejects")
        negatives.append(name)

    zero_update = Description(ZERO)
    identity_update = Description(V)
    successor_update = Description(Succ(V))
    predecessor_update = Description(Rec(COUNTER_DESCRIPTION, V, ZERO))
    nested_update = Description(Rec(successor_update, U, V))
    descriptions = {
        "zero": zero_update,
        "counter_projection": COUNTER_DESCRIPTION,
        "state_projection": identity_update,
        "successor_state": successor_update,
        "predecessor_state": predecessor_update,
        "nested_earlier_recursion": nested_update,
    }

    for name, description in descriptions.items():
        validate_description(description)
        checked.append(f"{name}: finite bound update grammar")
        initialization = Imp(Eq(Y, Y), Eq(Rec(description, ZERO, Y), Y))
        positive(f"R0_{name}", initialization, "R0")
        old_value = Rec(description, Y, Z)
        updated = substitute_term(description.body, {"u": Y, "v": old_value})
        successor = Imp(
            Eq(updated, updated), Eq(Rec(description, Succ(Y), Z), updated)
        )
        positive(f"RS_{name}", successor, "RS")

    positive("separation", separation_matrix(), "SEP")
    positive("constructor_coverage", coverage_matrix(), "REFL", classical=False)

    equation = Eq(Rec(successor_update, X, Y), Y)
    equation_induction = Imp(substitute_formula(equation, {"x": ZERO}), equation)
    positive("one_parameter_equation_induction", equation_induction, "REFL")
    negative_coverage = Imp(Eq(X, Y), Eq(ZERO, Y))
    positive("classical_negative_coverage", negative_coverage, "REFL")
    positive("parameter_free_equation_induction", Imp(Eq(ZERO, ZERO), Eq(X, X)), "REFL")

    # Crucial correctness regression: the unfiltered gate accepts this
    # context. In the shadowed output, F(b,a,b) is (b=b)->(0=b), whereas
    # F(Sb,a,b) is (Sb=b)->(0=b). The latter is true for every natural b,
    # so progress is true, but the conclusion at outer b=1 is false.
    # This is why gate acceptance alone cannot authorize the shadowed axiom.
    mixed_context = Imp(Eq(X, Z), Eq(ZERO, Z))
    require(find_base_certificate(zero_instance(mixed_context)) == Certificate("REFL"),
            "mixed context: raw local gate accepts with zero contractions")
    require(admit(mixed_context, require_mode=False).accepted,
            "mixed context: optional unshadowed three-variable version admits")
    require(admit(mixed_context).reason == "context must ignore x or ignore z",
            "mixed context: essential two-mode filter diagnoses rejection")
    negative("mixed_counter_and_second_parameter", mixed_context, gate_must_fail=False)
    unshadowed = sentence_variable_audit(emit_axiom(mixed_context, shadowed=False))
    require(unshadowed["all_names"] == ["a", "b", "n"],
            "optional unshadowed comparison has three actual variable names")
    require(unshadowed["free_names"] == [], "optional unshadowed sentence is closed")

    negative("bare_falsity", Bottom())
    negative("constant_false_equation_implication",
             Imp(Eq(ZERO, ZERO), Eq(ZERO, Succ(ZERO))))
    nested_r0 = Imp(
        Eq(Y, Y), Eq(Rec(identity_update, ZERO, Rec(identity_update, ZERO, Y)), Y)
    )
    negative("two_nested_initialization_contractions", nested_r0)
    require(not certificate_is_valid(zero_instance(nested_r0),
                                    Certificate("R0", ("consequent", "left"))),
            "one nested R0 contraction is insufficient")
    once = replay_certificate(zero_instance(nested_r0), Certificate("R0", ("consequent", "left")))
    twice = replay_certificate(once, Certificate("R0", ("consequent", "left")))
    require(is_literal_reflexive(twice),
            "nested example becomes reflexive after exactly two contractions")

    parallel_r0 = Imp(
        Eq(Y, Y), Eq(Rec(identity_update, ZERO, Y), Rec(identity_update, ZERO, Y))
    )
    negative("two_parallel_initialization_contractions", parallel_r0)

    generating_update = Description(Rec(identity_update, ZERO, V))
    old = Rec(generating_update, Y, Z)
    generated_redex = Imp(Eq(old, old), Eq(Rec(generating_update, Succ(Y), Z), old))
    negative("successor_creates_a_second_redex", generated_redex)
    once = replay_certificate(zero_instance(generated_redex),
                              Certificate("RS", ("consequent", "left")))
    require(not is_literal_reflexive(once), "successor expansion is not implicitly normalized")
    twice = replay_certificate(once, Certificate("R0", ("consequent", "left")))
    require(is_literal_reflexive(twice), "generated-redex example requires a second contraction")

    # If a checker wrongly rewrites inside stored descriptions, the left
    # symbol here can turn into the right symbol and make the base reflexive.
    opaque_body = Imp(
        Eq(Rec(generating_update, Y, Z), ZERO),
        Eq(Rec(identity_update, Y, Z), ZERO),
    )
    negative("stored_description_is_opaque_to_contraction", opaque_body)
    expect_syntax_error(
        lambda: replay_certificate(zero_instance(opaque_body),
                                   Certificate("R0", ("antecedent", "left", "description", "body"))),
        "certificates cannot enter stored descriptions",
    )

    original = Rec(COUNTER_DESCRIPTION, U, V)
    substituted = substitute_term(original, {"u": V, "v": ZERO})
    require(substituted == Rec(COUNTER_DESCRIPTION, V, ZERO),
            "substitution is simultaneous, with no second substitution in inserted terms")
    require(substituted.description is COUNTER_DESCRIPTION,
            "substitution preserves the stored-description object")
    require(substituted.description.body == U,
            "bound body variable u is not substituted as a call argument")
    require(validate_term(Rec(nested_update, Y, Z)) == frozenset({"y", "z"}),
            "stored u,v names do not become free object variables")

    valid_successor = Imp(Eq(ZERO, ZERO), Eq(Rec(zero_update, Succ(Y), Z), ZERO))
    valid_base = zero_instance(valid_successor)
    require(not certificate_is_valid(valid_base, Certificate("R0", ("consequent", "left"))),
            "tampered rule rejected")
    require(not certificate_is_valid(valid_base, Certificate("RS", ("antecedent", "left"))),
            "tampered path rejected")
    require(not certificate_is_valid(valid_base, Certificate("REFL", ("antecedent",))),
            "zero-contraction certificate cannot hide a path")

    # These check the finite description grammar, separately from the gate.
    bad_description = Description(Var("a"))
    expect_syntax_error(lambda: validate_description(bad_description),
                        "stored updates cannot contain a frozen free parameter")
    bad_context = Imp(Eq(Var("c"), Var("c")), Eq(Var("c"), Var("c")))
    require(not admit(bad_context).accepted, "fourth raw context variable rejected")
    cyclic_description = Description(ZERO)
    object.__setattr__(cyclic_description, "body", Rec(cyclic_description, U, V))
    expect_syntax_error(lambda: validate_description(cyclic_description),
                        "cyclic stored recursion description rejected")
    cyclic_term = Succ(ZERO)
    object.__setattr__(cyclic_term, "argument", cyclic_term)
    expect_syntax_error(lambda: validate_term(cyclic_term), "cyclic term rejected")
    expect_syntax_error(lambda: formula_from_data(["eq", ["R", ["0"], ["0"]], ["0"]]),
                        "malformed JSON recursor arity rejected")

    # Grammar restrictions are distinct from the zero-instance gate.
    q = Or(Eq(X, ZERO), Eq(Y, Y))
    broad_context = Imp(substitute_formula(q, {"x": ZERO}), q)
    require(find_base_certificate(zero_instance(broad_context)) == Certificate("REFL"),
            "arbitrary disjunctive context passes only the raw gate")
    negative("arbitrary_disjunction_outside_fixed_coverage", broad_context, gate_must_fail=False)
    broad_conjunction = Imp(And(Eq(Y, Y), Eq(Y, Y)), And(Eq(Y, Y), Eq(Y, Y)))
    negative("arbitrary_conjunction_outside_matrix_grammar", broad_conjunction, gate_must_fail=False)

    metrics = display_metrics()
    require(metrics == {
        "new_diagonal_display": 18,
        "universal_conclusion_display": 19,
        "existing_normalized_display": 26,
    }, "partial schema-display trees reproduce 18, 19, and 26")
    by_name = {row["name"]: row for row in positives}
    require(by_name["R0_zero"]["expanded_axiom_nodes"] == 32,
            "expanded initialization probe has 32 nodes")
    require(by_name["RS_zero"]["expanded_axiom_nodes"] == 35,
            "expanded constant-zero computation probe has 35 nodes")
    require(by_name["separation"]["expanded_axiom_nodes"] == 23,
            "expanded separation probe has 23 nodes")
    require(by_name["constructor_coverage"]["expanded_axiom_nodes"] == 71,
            "expanded coverage probe has 71 nodes")
    require(by_name["classical_negative_coverage"]["expanded_axiom_nodes"] == 27,
            "expanded classical coverage probe has 27 nodes")

    return {
        "status": "passed",
        "check_count": len(checked),
        "positive_probe_count": len(positives),
        "negative_probe_count": len(negatives),
        "partial_display_counts": metrics,
        "counting_policy": {
            "included": "individual variables/constants, applications, equality, connectives, individual quantifiers",
            "stored_description_bodies": "excluded as function-symbol indices; instantiated body nodes inside an actual formula are counted",
            "partial_display_excludes": ["arbitrary formula-placeholder bodies", "update-placeholder bodies", "admission algorithm", "description encoding"],
            "expanded_instance_identity": "5 + 3 * nodes(F) + occurrences_x(F)",
            "raw_slots": ["x", "y", "z"],
            "emitted_individual_names": ["a", "b"],
        },
        "positive_probes": positives,
        "negative_probes": negatives,
        "checks": checked,
        "scope": "finite syntax, admissibility boundary, certificates, variable accounting, and sizes; not an arithmetic or bi-interpretability proof",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="write the full diagnostic JSON")
    args = parser.parse_args()
    report = run_checks()
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    summary = {key: report[key] for key in (
        "status", "check_count", "positive_probe_count", "negative_probe_count",
        "partial_display_counts", "scope",
    )}
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
