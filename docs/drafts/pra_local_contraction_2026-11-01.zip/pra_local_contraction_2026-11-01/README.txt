PRA FROM ONE LOCAL CONTRACTION AND DIAGONAL INDUCTION
Research prepared for Vladimir Reshetnikov, 1 November 2026

MAIN RESULT

The paper gives a classical and a native intuitionistic presentation of
first-order primitive recursive arithmetic. Each has a common conservative
definitional extension with matching-logic PRA. Both interpretation domains
are the full carrier, equality is preserved, and both round trips are
internally the identity.

The language starts with 0,S and contains a binary R_h for every finite
earlier update term h(u,v). The update has no other free variables. Its
stored body is part of the symbol description, not an object-language input.

The only nonlogical schema is

  forall a forall b,
    [forall b (F(b,a,b) -> F(Sb,a,b))] -> F(b,a,b).

The inner b intentionally shadows the outer target b. The raw source
context F(x,y,z) MUST ignore x or ignore z. Its zero instance F(0,a,b)
must be literally B->B after zero or one contraction at one occurrence:

  R_h(0,t)  -> t
  R_h(Ss,t) -> h(s,R_h(s,t))
  (0=S0)    -> bottom

There is no repeated normalization and no rewriting in stored descriptions.
The rule set describes admission, not additional assumed arithmetic axioms.
Stationary probes recover all three corresponding arithmetic requirements.

Classical matrices: equation->equation, plus the fixed (0=S0)->bottom.
Intuitionistic matrices: the same, plus ONE fixed Cov(0)->Cov(x), where
  p(x)=R_u(x,0),  Cov(x)=(x=0 or x=S(p(x))).

All emitted axioms have only the two variable names a,b. The raw contexts
still have three slots. Removing the unused-slot condition makes the theory
inconsistent: (x=z)->(0=z) passes the base gate and forces every element to 0.

COMPARISON AND QUALIFICATIONS

All eight drafts were inspected at ProveIt snapshot
ab29d2ad2189948d995d6cffa7cea5298cd126a0.
Two previous packages already attain a 26-node outer display. The new
uniform display has 18 nodes under their partial metric and retains two
individual variable names per axiom. This number omits the admission
algorithm, unused-slot test, stored update descriptions, and substituted
matrix bodies. There is no claim of an absolute minimum or shortest total
encoding. Successor computation has moved into the admission specification;
it has not disappeared from the theory's complete description.

The paper also proves a separate refinement keeping the old 26-node display
and its normalizer while restricting its matrices to the same small forms.
The oriented triangular pairing and arithmetic bootstrap are credited to
the inspected drafts. This work does not claim those inherited ingredients
as new. The new reductions are the single local-contraction admission,
diagonal conclusion with safe variable reuse, and sharper matrix restriction.

FILES

report.pdf                  Complete compiled paper.
report.tex                  Main LaTeX source and bibliography.
arithmetic.tex              Complete arithmetic, equality-bit, and pairing proof.
interpretations.tex         Gate soundness, compiler, and both identity round trips.
comparison.tex              Baselines, exact metrics, counterexamples, Kripke model.
verification.tex            Machine-checking scope and reproducibility.
OneContraction.lean         Standalone Lean 4.19.0 logical/syntax kernel.
axiom_check.py              Exact finite-syntax admission checker and serializer.
check_artifacts.py          Targeted syntax, certificate, and metric regressions.
syntax_results.json         All recorded probes and verification results.
source_manifest.json        Pinned sources and verified provenance hashes.
lean-toolchain              Lean version used for the certificate.
build.sh                    Rebuild checks and PDF; runs Lean if available.
verification/lean.log       Successful Lean dependency reports.
verification/python.log     Successful finite-syntax test summary.
verification/latex.log      Successful final PDF build output.
SHA256SUMS                  Checksums of packaged deliverables.

REPRODUCTION

Python 3.10 or later; no third-party Python dependencies:

  python3 check_artifacts.py --output syntax_results.json

Lean 4.19.0, core only:

  lean OneContraction.lean

TeX Live with latexmk and the packages listed in report.tex:

  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

Or run:

  bash build.sh

An absolute Lean executable can be selected by setting LEAN_BIN before
running build.sh. If no Lean executable is available, the script clearly
reports that the formal check was not rerun; it does not claim success.

MACHINE-CHECKING BOUNDARY

All 237 finite-syntax checks pass (17 positive probes, nine negative probes).
They check the actual two-name emitted AST, simultaneous substitution,
opaque stored descriptions, one-contraction certificates, the necessary
unused-slot filter, and counts 18/19/26. They do not prove the infinite theory.

The Lean file compiles with all 28 printed declarations reporting no global
axiom dependencies, including no sorryAx or Classical.choice. Every
mathematical assumption is an explicit argument. In particular, the classical
coverage bridge explicitly receives its excluded-middle/decision instance.

Lean checks a constructive semantic logical kernel and concrete finite-syntax
contraction soundness. It does NOT contain a complete formal first-order proof
calculus, arithmetic bootstrap, primitive-recursion compiler, or final
bi-interpretation. Those parts are complete written proofs in the paper.
The syntactic unused-slot parser is implemented in Python; the abstract Lean
reverse theorem states the corresponding semantic independence explicitly.

No new GitHub commit or pull request is part of this delivery.
