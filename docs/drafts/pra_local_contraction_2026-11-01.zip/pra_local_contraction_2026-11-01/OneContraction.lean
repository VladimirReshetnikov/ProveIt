/-
One-contraction admission and a diagonal induction conclusion.

Lean 4.19.0, core only. This file checks a constructive semantic logical
kernel and soundness of a concrete finite-syntax contraction relation.
It does not formalize first-order derivations, the one-parameter arithmetic
bootstrap, primitive-recursive compilation, or the final bi-interpretation.
Every mathematical assumption is an explicit argument; there are no
placeholder axioms, sorry declarations, or uses of classical choice.
-/
import Lean

namespace OneContraction

/-! A logical kernel with an explicitly restricted family of matrices. -/

universe u v

structure Data (A : Type u) (H : Type v) where
  zero : A
  succ : A → A
  recursor : H → A → A → A
  update : H → A → A → A

variable {A : Type u} {H : Type v}

theorem congrArgTwo {B C D : Sort u} (f : B → C → D)
    {x x' : B} {y y' : C} (hx : x = x') (hy : y = y') :
    f x y = f x' y' := by
  cases hx
  cases hy
  rfl

def Initialization (d : Data A H) : Prop :=
  ∀ h a, d.recursor h d.zero a = a

def Computation (d : Data A H) : Prop :=
  ∀ h n a, d.recursor h (d.succ n) a =
    d.update h n (d.recursor h n a)

def Separation (d : Data A H) : Prop := d.zero ≠ d.succ d.zero

def DiagonalSchema (d : Data A H)
    (admit : (A → A → A → Prop) → Prop) : Prop :=
  ∀ F, admit F → ∀ a b,
    (∀ n, F n a b → F (d.succ n) a b) → F b a b

def OneParameterInduction (d : Data A H)
    (family : (A → A → Prop) → Prop) : Prop :=
  ∀ G, family G → ∀ a, G d.zero a →
    (∀ n, G n a → G (d.succ n) a) → ∀ n, G n a

def TwoParameterInduction (d : Data A H)
    (family : (A → A → A → Prop) → Prop) : Prop :=
  ∀ F, family F → ∀ a b, F d.zero a b →
    (∀ n, F n a b → F (d.succ n) a b) → ∀ n, F n a b

def initProbe (d : Data A H) (h : H) : A → A → A → Prop :=
  fun _ a _ => (a = a) → (d.recursor h d.zero a = a)

def stepProbe (d : Data A H) (h : H) : A → A → A → Prop :=
  fun _ a b =>
    (d.update h a (d.recursor h a b) =
      d.update h a (d.recursor h a b)) →
    (d.recursor h (d.succ a) b = d.update h a (d.recursor h a b))

def sepProbe (d : Data A H) : A → A → A → Prop :=
  fun _ _ _ => (d.zero = d.succ d.zero) → False

def normalized (d : Data A H) (G : A → A → Prop) : A → A → A → Prop :=
  fun n a _ => G d.zero a → G n a

theorem extracts_initialization (d : Data A H) (admit)
    (schema : DiagonalSchema d admit)
    (accepted : ∀ h, admit (initProbe d h)) : Initialization d := by
  intro h a
  have hp := schema (initProbe d h) (accepted h) a d.zero (fun _ hq => hq)
  exact hp rfl

theorem extracts_computation (d : Data A H) (admit)
    (schema : DiagonalSchema d admit)
    (accepted : ∀ h, admit (stepProbe d h)) : Computation d := by
  intro h n a
  have hp := schema (stepProbe d h) (accepted h) n a (fun _ hq => hq)
  exact hp rfl

theorem extracts_separation (d : Data A H) (admit)
    (schema : DiagonalSchema d admit)
    (accepted : admit (sepProbe d)) : Separation d := by
  exact schema (sepProbe d) accepted d.zero d.zero (fun _ hq => hq)

theorem extracts_one_parameter_induction (d : Data A H) (admit) (family)
    (schema : DiagonalSchema d admit)
    (accepted : ∀ G, family G → admit (normalized d G)) :
    OneParameterInduction d family := by
  intro G hG a hzero hstep n
  have progress : ∀ k, normalized d G k a n →
      normalized d G (d.succ k) a n := by
    intro k hk hb
    exact hstep k (hk hb)
  have hn := schema (normalized d G) (accepted G hG) a n progress
  exact hn hzero

theorem basis_implies_diagonal (d : Data A H) (admit) (family)
    (induction : TwoParameterInduction d family)
    (allowed : ∀ F, admit F → family F)
    (base : ∀ F, admit F → ∀ a b, F d.zero a b) :
    DiagonalSchema d admit := by
  intro F hF a b hstep
  exact induction F (allowed F hF) a b (base F hF a b) hstep b

/-! The primary schema uses the same actual variable in raw slots one and three.
The inner bound variable shadows the outer target variable in the emitted
first-order sentence. Semantic notation uses distinct binders for clarity. -/

def ShadowSchema (d : Data A H)
    (admit : (A → A → A → Prop) → Prop) : Prop :=
  ∀ F, admit F → ∀ a b,
    (∀ n, F n a n → F (d.succ n) a n) → F b a b

def UnusedCounter (F : A → A → A → Prop) : Prop :=
  ∀ n n' a b, F n a b ↔ F n' a b

def UnusedLast (F : A → A → A → Prop) : Prop :=
  ∀ n a b b', F n a b ↔ F n a b'

def SlotCondition (F : A → A → A → Prop) : Prop :=
  UnusedCounter F ∨ UnusedLast F

theorem shadow_extracts_initialization (d : Data A H) (admit)
    (schema : ShadowSchema d admit)
    (accepted : ∀ h, admit (initProbe d h)) : Initialization d := by
  intro h a
  exact schema (initProbe d h) (accepted h) a d.zero (fun _ hq => hq) rfl

theorem shadow_extracts_computation (d : Data A H) (admit)
    (schema : ShadowSchema d admit)
    (accepted : ∀ h, admit (stepProbe d h)) : Computation d := by
  intro h n a
  exact schema (stepProbe d h) (accepted h) n a (fun _ hq => hq) rfl

theorem shadow_extracts_separation (d : Data A H) (admit)
    (schema : ShadowSchema d admit)
    (accepted : admit (sepProbe d)) : Separation d := by
  exact schema (sepProbe d) accepted d.zero d.zero (fun _ hq => hq)

theorem shadow_extracts_one_parameter_induction (d : Data A H) (admit) (family)
    (schema : ShadowSchema d admit)
    (accepted : ∀ G, family G → admit (normalized d G)) :
    OneParameterInduction d family := by
  intro G hG a hzero hstep n
  have progress : ∀ k, normalized d G k a k →
      normalized d G (d.succ k) a k := by
    intro k hk hb
    exact hstep k (hk hb)
  exact schema (normalized d G) (accepted G hG) a n progress hzero

theorem basis_implies_shadow (d : Data A H) (admit) (family)
    (induction : OneParameterInduction d family)
    (allowed : ∀ F, admit F → family (fun n a => F n a d.zero))
    (shape : ∀ F, admit F → SlotCondition F)
    (base : ∀ F, admit F → ∀ a b, F d.zero a b) :
    ShadowSchema d admit := by
  intro F hF a b hstep
  cases shape F hF with
  | inl hfirst =>
    exact (hfirst d.zero b a b).mp (base F hF a b)
  | inr hlast =>
    have progress : ∀ n, F n a d.zero → F (d.succ n) a d.zero := by
      intro n hn
      have hn' : F n a n := (hlast n a d.zero n).mp hn
      exact (hlast (d.succ n) a n d.zero).mp (hstep n hn')
    have hb := induction (fun n a => F n a d.zero) (allowed F hF)
      a (base F hF a d.zero) progress b
    exact (hlast b a d.zero b).mp hb

theorem initProbe_slot (d : Data A H) (h : H) : SlotCondition (initProbe d h) :=
  Or.inl (fun _ _ _ _ => Iff.rfl)

theorem stepProbe_slot (d : Data A H) (h : H) : SlotCondition (stepProbe d h) :=
  Or.inl (fun _ _ _ _ => Iff.rfl)

theorem sepProbe_slot (d : Data A H) : SlotCondition (sepProbe d) :=
  Or.inl (fun _ _ _ _ => Iff.rfl)

theorem normalized_slot (d : Data A H) (G : A → A → Prop) :
    SlotCondition (normalized d G) := Or.inr (fun _ _ _ _ => Iff.rfl)

/-! The equality-implication fragment and the intuitionistic coverage issue. -/

def weakCoverageProbe (d : Data A H) : A → A → A → Prop :=
  fun n a _ => n = a → d.zero = a

theorem weak_coverage (d : Data A H) (admit) (p : A → A)
    (pred_succ : ∀ x, p (d.succ x) = x)
    (schema : DiagonalSchema d admit)
    (accepted : admit (weakCoverageProbe d)) :
    ∀ a, (a ≠ d.succ (p a)) → a = d.zero := by
  intro a hnot
  have progress : ∀ n, weakCoverageProbe d n a a →
      weakCoverageProbe d (d.succ n) a a := by
    intro n _ hsa
    have hpa : p a = n := Eq.trans (congrArg p hsa.symm) (pred_succ n)
    have ha : a = d.succ (p a) :=
      Eq.trans hsa.symm (congrArg d.succ hpa.symm)
    exact False.elim (hnot ha)
  exact (schema (weakCoverageProbe d) accepted a a progress rfl).symm

theorem coverage_from_weak_with_decision (d : Data A H) (p : A → A)
    (weak : ∀ a, (a ≠ d.succ (p a)) → a = d.zero)
    (decision : ∀ a, a = d.succ (p a) ∨ a ≠ d.succ (p a)) :
    ∀ a, a = d.zero ∨ a = d.succ (p a) := by
  intro a
  cases decision a with
  | inl he => exact Or.inr he
  | inr hn => exact Or.inl (weak a hn)

def coverageProbe (d : Data A H) (p : A → A) : A → A → A → Prop :=
  fun n _ _ =>
    (d.zero = d.zero ∨ d.zero = d.succ (p d.zero)) →
    (n = d.zero ∨ n = d.succ (p n))

theorem coverage_from_fixed_probe (d : Data A H) (admit) (p : A → A)
    (pred_succ : ∀ x, p (d.succ x) = x)
    (schema : DiagonalSchema d admit)
    (accepted : admit (coverageProbe d p)) :
    ∀ a, a = d.zero ∨ a = d.succ (p a) := by
  intro a
  have progress : ∀ n, coverageProbe d p n d.zero a →
      coverageProbe d p (d.succ n) d.zero a := by
    intro n _ _
    exact Or.inr (congrArg d.succ (pred_succ n).symm)
  exact schema (coverageProbe d p) accepted d.zero a progress (Or.inl rfl)

theorem shadow_weak_coverage (d : Data A H) (admit) (p : A → A)
    (pred_succ : ∀ x, p (d.succ x) = x)
    (schema : ShadowSchema d admit)
    (accepted : admit (weakCoverageProbe d)) :
    ∀ a, (a ≠ d.succ (p a)) → a = d.zero := by
  intro a hnot
  have progress : ∀ n, weakCoverageProbe d n a n →
      weakCoverageProbe d (d.succ n) a n := by
    intro n _ hsa
    have hpa : p a = n := Eq.trans (congrArg p hsa.symm) (pred_succ n)
    have ha : a = d.succ (p a) :=
      Eq.trans hsa.symm (congrArg d.succ hpa.symm)
    exact False.elim (hnot ha)
  exact (schema (weakCoverageProbe d) accepted a a progress rfl).symm

theorem shadow_coverage_from_fixed_probe (d : Data A H) (admit) (p : A → A)
    (pred_succ : ∀ x, p (d.succ x) = x)
    (schema : ShadowSchema d admit)
    (accepted : admit (coverageProbe d p)) :
    ∀ a, a = d.zero ∨ a = d.succ (p a) := by
  intro a
  have progress : ∀ n, coverageProbe d p n d.zero n →
      coverageProbe d p (d.succ n) d.zero n := by
    intro n _ _
    exact Or.inr (congrArg d.succ (pred_succ n).symm)
  exact schema (coverageProbe d p) accepted d.zero a progress (Or.inl rfl)

/-! Concrete finite syntax, including well-founded recursion descriptions. -/

inductive Index : Nat → Type where
  | first {k} : Index (Nat.succ k)
  | next {k} : Index k → Index (Nat.succ k)

def Index.isFirst : {k : Nat} → Index k → Bool
  | _, .first => true
  | _, .next _ => false

def Index.isSecond : {k : Nat} → Index k → Bool
  | _, .first => false
  | _, .next i => i.isFirst

inductive Term : Nat → Type where
  | var {k} : Index k → Term k
  | zero {k} : Term k
  | succ {k} : Term k → Term k
  | recursor {k} : Term 2 → Term k → Term k → Term k

namespace Term

def subst {k l} (s : Index k → Term l) : Term k → Term l
  | .var i => s i
  | .zero => .zero
  | .succ t => .succ (subst s t)
  | .recursor h n a => .recursor h (subst s n) (subst s a)

theorem subst_ext {k l} (t : Term k) (s r : Index k → Term l)
    (he : ∀ i, s i = r i) : subst s t = subst r t := by
  induction t with
  | var i => exact he i
  | zero => rfl
  | succ t ih => exact congrArg Term.succ (ih s r he)
  | recursor h n a _ ihn iha =>
    exact congrArgTwo (Term.recursor h) (ihn s r he) (iha s r he)

theorem subst_comp {k l m} (t : Term k)
    (s : Index k → Term l) (r : Index l → Term m) :
    subst r (subst s t) = subst (fun i => subst r (s i)) t := by
  induction t with
  | var i => rfl
  | zero => rfl
  | succ t ih => exact congrArg Term.succ (ih s)
  | recursor h n a _ ihn iha =>
    exact congrArgTwo (Term.recursor h) (ihn s) (iha s)

def pair {B : Type} (a b : B) (i : Index 2) : B :=
  if i.isFirst then a else b

structure Algebra (B : Type) where
  zero : B
  succ : B → B
  recursor : Term 2 → B → B → B

def eval {B} (m : Algebra B) {k} : Term k → (Index k → B) → B
  | .var i, e => e i
  | .zero, _ => m.zero
  | .succ t, e => m.succ (eval m t e)
  | .recursor h n a, e => m.recursor h (eval m n e) (eval m a e)

theorem eval_ext {B} (m : Algebra B) {k} (t : Term k)
    (e f : Index k → B) (he : ∀ i, e i = f i) : eval m t e = eval m t f := by
  induction t with
  | var i => exact he i
  | zero => rfl
  | succ t ih => exact congrArg m.succ (ih e f he)
  | recursor h n a _ ihn iha =>
    exact congrArgTwo (m.recursor h) (ihn e f he) (iha e f he)

theorem eval_subst {B} (m : Algebra B) {k l} (t : Term k)
    (s : Index k → Term l) (e : Index l → B) :
    eval m (subst s t) e = eval m t (fun i => eval m (s i) e) := by
  induction t with
  | var i => rfl
  | zero => rfl
  | succ t ih => exact congrArg m.succ (ih s)
  | recursor h n a _ ihn iha =>
    exact congrArgTwo (m.recursor h) (ihn s) (iha s)

theorem eval_subst_pair {B} (m : Algebra B) {k} (h : Term 2)
    (n a : Term k) (e : Index k → B) :
    eval m (subst (pair n a) h) e =
      eval m h (pair (eval m n e) (eval m a e)) := by
  apply Eq.trans (eval_subst m h (pair n a) e)
  apply eval_ext
  intro i
  unfold pair
  cases i.isFirst <;> rfl

def Initial {B} (m : Algebra B) : Prop :=
  ∀ h a, m.recursor h m.zero a = a

def Successor {B} (m : Algebra B) : Prop :=
  ∀ h n a, m.recursor h (m.succ n) a =
    eval m h (pair n (m.recursor h n a))

inductive Contract : {k : Nat} → Term k → Term k → Prop where
  | initial {k} (h : Term 2) (a : Term k) :
      Contract (.recursor h .zero a) a
  | successor {k} (h : Term 2) (n a : Term k) :
      Contract (.recursor h (.succ n) a)
        (subst (pair n (.recursor h n a)) h)
  | underSucc {k} {s t : Term k} :
      Contract s t → Contract (.succ s) (.succ t)
  | underCounter {k} (h : Term 2) {s t : Term k} (a : Term k) :
      Contract s t → Contract (.recursor h s a) (.recursor h t a)
  | underSeed {k} (h : Term 2) (n : Term k) {s t : Term k} :
      Contract s t → Contract (.recursor h n s) (.recursor h n t)

theorem contract_sound {B} (m : Algebra B)
    (hi : Initial m) (hs : Successor m) {k} {s t : Term k}
    (hc : Contract s t) (e : Index k → B) : eval m s e = eval m t e := by
  induction hc with
  | initial h a => exact hi h (eval m a e)
  | successor h n a =>
    exact Eq.trans (hs h (eval m n e) (eval m a e))
      (eval_subst_pair m h n (.recursor h n a) e).symm
  | underSucc _ ih => exact congrArg m.succ ih
  | underCounter h a _ ih =>
    exact congrArg (fun z => m.recursor h z (eval m a e)) ih
  | underSeed h n _ ih =>
    exact congrArg (m.recursor h (eval m n e)) ih

end Term

inductive Formula (k : Nat) where
  | equal : Term k → Term k → Formula k
  | falsum : Formula k
  | implies : Formula k → Formula k → Formula k
  | conj : Formula k → Formula k → Formula k
  | disj : Formula k → Formula k → Formula k

namespace Formula

def subst {k l} (s : Index k → Term l) : Formula k → Formula l
  | .equal a b => .equal (Term.subst s a) (Term.subst s b)
  | .falsum => .falsum
  | .implies p q => .implies (subst s p) (subst s q)
  | .conj p q => .conj (subst s p) (subst s q)
  | .disj p q => .disj (subst s p) (subst s q)

theorem subst_ext {k l} (p : Formula k) (s r : Index k → Term l)
    (he : ∀ i, s i = r i) : subst s p = subst r p := by
  induction p with
  | equal a b =>
    exact congrArgTwo Formula.equal (Term.subst_ext a s r he) (Term.subst_ext b s r he)
  | falsum => rfl
  | implies p q ihp ihq => exact congrArgTwo Formula.implies ihp ihq
  | conj p q ihp ihq => exact congrArgTwo Formula.conj ihp ihq
  | disj p q ihp ihq => exact congrArgTwo Formula.disj ihp ihq

theorem subst_comp {k l m} (p : Formula k)
    (s : Index k → Term l) (r : Index l → Term m) :
    subst r (subst s p) = subst (fun i => Term.subst r (s i)) p := by
  induction p with
  | equal a b =>
    exact congrArgTwo Formula.equal (Term.subst_comp a s r) (Term.subst_comp b s r)
  | falsum => rfl
  | implies p q ihp ihq => exact congrArgTwo Formula.implies ihp ihq
  | conj p q ihp ihq => exact congrArgTwo Formula.conj ihp ihq
  | disj p q ihp ihq => exact congrArgTwo Formula.disj ihp ihq

def eval {B} (m : Term.Algebra B) {k} : Formula k → (Index k → B) → Prop
  | .equal a b, e => Term.eval m a e = Term.eval m b e
  | .falsum, _ => False
  | .implies p q, e => eval m p e → eval m q e
  | .conj p q, e => eval m p e ∧ eval m q e
  | .disj p q, e => eval m p e ∨ eval m q e

theorem implication_congr {p p' q q' : Prop} (hp : p ↔ p') (hq : q ↔ q') :
    (p → q) ↔ (p' → q') :=
  ⟨fun h h' => hq.mp (h (hp.mpr h')), fun h h' => hq.mpr (h (hp.mp h'))⟩

theorem conjunction_congr {p p' q q' : Prop} (hp : p ↔ p') (hq : q ↔ q') :
    (p ∧ q) ↔ (p' ∧ q') :=
  ⟨fun h => ⟨hp.mp h.1, hq.mp h.2⟩, fun h => ⟨hp.mpr h.1, hq.mpr h.2⟩⟩

theorem disjunction_congr {p p' q q' : Prop} (hp : p ↔ p') (hq : q ↔ q') :
    (p ∨ q) ↔ (p' ∨ q') := by
  constructor
  · intro h
    cases h with
    | inl h => exact Or.inl (hp.mp h)
    | inr h => exact Or.inr (hq.mp h)
  · intro h
    cases h with
    | inl h => exact Or.inl (hp.mpr h)
    | inr h => exact Or.inr (hq.mpr h)

theorem eval_ext {B} (m : Term.Algebra B) {k} (p : Formula k)
    (e f : Index k → B) (he : ∀ i, e i = f i) : eval m p e ↔ eval m p f := by
  induction p with
  | equal a b =>
    change (Term.eval m a e = Term.eval m b e) ↔ (Term.eval m a f = Term.eval m b f)
    rw [Term.eval_ext m a e f he, Term.eval_ext m b e f he]
  | falsum => exact Iff.rfl
  | implies p q ihp ihq => exact implication_congr ihp ihq
  | conj p q ihp ihq => exact conjunction_congr ihp ihq
  | disj p q ihp ihq => exact disjunction_congr ihp ihq

theorem eval_subst {B} (m : Term.Algebra B) {k l} (p : Formula k)
    (s : Index k → Term l) (e : Index l → B) :
    eval m (subst s p) e ↔ eval m p (fun i => Term.eval m (s i) e) := by
  induction p with
  | equal a b =>
    change (Term.eval m (Term.subst s a) e = Term.eval m (Term.subst s b) e) ↔ _
    rw [Term.eval_subst, Term.eval_subst]
    exact Iff.rfl
  | falsum => exact Iff.rfl
  | implies p q ihp ihq => exact implication_congr ihp ihq
  | conj p q ihp ihq => exact conjunction_congr ihp ihq
  | disj p q ihp ihq => exact disjunction_congr ihp ihq

inductive Contract : {k : Nat} → Formula k → Formula k → Prop where
  | equalLeft {k} {s t : Term k} (a : Term k) :
      Term.Contract s t → Contract (.equal s a) (.equal t a)
  | equalRight {k} (a : Term k) {s t : Term k} :
      Term.Contract s t → Contract (.equal a s) (.equal a t)
  | separation {k} :
      Contract (.equal (Term.zero : Term k) (.succ .zero)) .falsum
  | impliesLeft {k} {p p' : Formula k} (q : Formula k) :
      Contract p p' → Contract (.implies p q) (.implies p' q)
  | impliesRight {k} (p : Formula k) {q q' : Formula k} :
      Contract q q' → Contract (.implies p q) (.implies p q')
  | conjLeft {k} {p p' : Formula k} (q : Formula k) :
      Contract p p' → Contract (.conj p q) (.conj p' q)
  | conjRight {k} (p : Formula k) {q q' : Formula k} :
      Contract q q' → Contract (.conj p q) (.conj p q')
  | disjLeft {k} {p p' : Formula k} (q : Formula k) :
      Contract p p' → Contract (.disj p q) (.disj p' q)
  | disjRight {k} (p : Formula k) {q q' : Formula k} :
      Contract q q' → Contract (.disj p q) (.disj p q')

theorem contract_sound {B} (m : Term.Algebra B)
    (hi : Term.Initial m) (hs : Term.Successor m)
    (hsep : m.zero ≠ m.succ m.zero) {k} {p q : Formula k}
    (hc : Contract p q) (e : Index k → B) : eval m p e ↔ eval m q e := by
  induction hc with
  | equalLeft a ht =>
    change (Term.eval m _ e = Term.eval m a e) ↔ (Term.eval m _ e = Term.eval m a e)
    rw [Term.contract_sound m hi hs ht e]
  | equalRight a ht =>
    change (Term.eval m a e = Term.eval m _ e) ↔ (Term.eval m a e = Term.eval m _ e)
    rw [Term.contract_sound m hi hs ht e]
  | separation => exact ⟨hsep, False.elim⟩
  | impliesLeft q _ ih => exact implication_congr ih Iff.rfl
  | impliesRight p _ ih => exact implication_congr Iff.rfl ih
  | conjLeft q _ ih => exact conjunction_congr ih Iff.rfl
  | conjRight p _ ih => exact conjunction_congr Iff.rfl ih
  | disjLeft q _ ih => exact disjunction_congr ih Iff.rfl
  | disjRight p _ ih => exact disjunction_congr Iff.rfl ih

def zeroCounter (i : Index 3) : Term 3 :=
  if i.isFirst then .zero else .var i

def base (p : Formula 3) : Formula 3 := subst zeroCounter p

def Admitted (p : Formula 3) : Prop :=
  ∃ q, base p = .implies q q ∨ Contract (base p) (.implies q q)

theorem admitted_base_sound {B} (m : Term.Algebra B)
    (hi : Term.Initial m) (hs : Term.Successor m)
    (hsep : m.zero ≠ m.succ m.zero) (p : Formula 3) (hp : Admitted p)
    (e : Index 3 → B) : eval m (base p) e := by
  obtain ⟨q, hq⟩ := hp
  cases hq with
  | inl he =>
    rw [he]
    exact fun h => h
  | inr hc =>
    exact (contract_sound m hi hs hsep hc e).mpr (fun h => h)

def triple {B : Type} (n a b : B) (i : Index 3) : B :=
  if i.isFirst then n else if i.isSecond then a else b

theorem admitted_zero_instance {B} (m : Term.Algebra B)
    (hi : Term.Initial m) (hs : Term.Successor m)
    (hsep : m.zero ≠ m.succ m.zero) (p : Formula 3) (hp : Admitted p)
    (a b : B) : eval m p (triple m.zero a b) := by
  let e := triple m.zero a b
  have hb := admitted_base_sound m hi hs hsep p hp e
  have hz := (eval_subst m p zeroCounter e).mp hb
  apply (eval_ext m p (fun i => Term.eval m (zeroCounter i) e) e ?_).mp hz
  intro i
  change Term.eval m (zeroCounter i) (triple m.zero a b) = triple m.zero a b i
  unfold zeroCounter triple
  cases hfirst : i.isFirst with
  | true => rfl
  | false =>
    change (if i.isFirst then m.zero else if i.isSecond then a else b) =
      (if i.isSecond then a else b)
    rw [hfirst]
    rfl

/-! Literal admission certificates for the essential extraction probes. -/

def counterTerm : Term 3 := .var .first
def parameterTerm : Term 3 := .var (.next .first)
def targetTerm : Term 3 := .var (.next (.next .first))

def initialFormula (h : Term 2) : Formula 3 :=
  .implies (.equal parameterTerm parameterTerm)
    (.equal (.recursor h .zero parameterTerm) parameterTerm)

theorem initialFormula_admitted (h : Term 2) : Admitted (initialFormula h) := by
  refine ⟨.equal parameterTerm parameterTerm, Or.inr ?_⟩
  exact Contract.impliesRight (.equal parameterTerm parameterTerm)
    (Contract.equalLeft parameterTerm (Term.Contract.initial h parameterTerm))

def stepRight (h : Term 2) : Term 3 :=
  Term.subst (Term.pair parameterTerm (.recursor h parameterTerm targetTerm)) h

theorem stepRight_fixed (h : Term 2) : Term.subst zeroCounter (stepRight h) = stepRight h := by
  unfold stepRight
  apply Eq.trans (Term.subst_comp h _ zeroCounter)
  apply Term.subst_ext
  intro i
  unfold Term.pair
  cases i.isFirst <;> rfl

def successorFormula (h : Term 2) : Formula 3 :=
  .implies (.equal (stepRight h) (stepRight h))
    (.equal (.recursor h (.succ parameterTerm) targetTerm) (stepRight h))

theorem successorFormula_fixed (h : Term 2) : base (successorFormula h) = successorFormula h := by
  unfold base successorFormula subst
  change
    Formula.implies (.equal (Term.subst zeroCounter (stepRight h))
      (Term.subst zeroCounter (stepRight h)))
      (.equal (.recursor h (.succ parameterTerm) targetTerm)
        (Term.subst zeroCounter (stepRight h))) = _
  rw [stepRight_fixed]

theorem successorFormula_admitted (h : Term 2) : Admitted (successorFormula h) := by
  refine ⟨.equal (stepRight h) (stepRight h), Or.inr ?_⟩
  rw [successorFormula_fixed]
  exact Contract.impliesRight (.equal (stepRight h) (stepRight h))
    (Contract.equalLeft (stepRight h) (Term.Contract.successor h parameterTerm targetTerm))

def separationFormula : Formula 3 := .implies (.equal .zero (.succ .zero)) .falsum

theorem separationFormula_admitted : Admitted separationFormula := by
  exact ⟨.falsum, Or.inr (Contract.impliesLeft .falsum Contract.separation)⟩

def zeroLift (g : Formula 2) : Formula 3 :=
  subst (Term.pair .zero parameterTerm) g

def counterLift (g : Formula 2) : Formula 3 :=
  subst (Term.pair counterTerm parameterTerm) g

theorem zeroLift_fixed (g : Formula 2) : base (zeroLift g) = zeroLift g := by
  unfold base zeroLift
  apply Eq.trans (subst_comp g _ zeroCounter)
  apply subst_ext
  intro i
  unfold Term.pair
  cases i.isFirst <;> rfl

theorem counterLift_zero (g : Formula 2) : base (counterLift g) = zeroLift g := by
  unfold base counterLift zeroLift
  apply Eq.trans (subst_comp g _ zeroCounter)
  apply subst_ext
  intro i
  unfold Term.pair
  cases i.isFirst <;> rfl

def normalizedFormula (g : Formula 2) : Formula 3 := .implies (zeroLift g) (counterLift g)

theorem normalizedFormula_admitted (g : Formula 2) : Admitted (normalizedFormula g) := by
  refine ⟨zeroLift g, Or.inl ?_⟩
  exact congrArgTwo Formula.implies (zeroLift_fixed g) (counterLift_zero g)

def weakCoverageFormula : Formula 3 :=
  .implies (.equal counterTerm parameterTerm) (.equal .zero parameterTerm)

theorem weakCoverageFormula_admitted : Admitted weakCoverageFormula := by
  exact ⟨.equal .zero parameterTerm, Or.inl rfl⟩

end Formula

#print axioms extracts_initialization
#print axioms extracts_computation
#print axioms extracts_separation
#print axioms extracts_one_parameter_induction
#print axioms basis_implies_diagonal
#print axioms weak_coverage
#print axioms coverage_from_weak_with_decision
#print axioms coverage_from_fixed_probe
#print axioms shadow_extracts_initialization
#print axioms shadow_extracts_computation
#print axioms shadow_extracts_separation
#print axioms shadow_extracts_one_parameter_induction
#print axioms basis_implies_shadow
#print axioms shadow_weak_coverage
#print axioms shadow_coverage_from_fixed_probe
#print axioms Term.eval_ext
#print axioms Term.eval_subst
#print axioms Term.pair
#print axioms Term.eval_subst_pair
#print axioms Term.contract_sound
#print axioms Formula.contract_sound
#print axioms Formula.admitted_base_sound
#print axioms Formula.admitted_zero_instance
#print axioms Formula.initialFormula_admitted
#print axioms Formula.successorFormula_admitted
#print axioms Formula.separationFormula_admitted
#print axioms Formula.normalizedFormula_admitted
#print axioms Formula.weakCoverageFormula_admitted

end OneContraction
