#!/usr/bin/env python3
"""Finite syntax and admission checker for the two-variable 18-node PRA presentation.

The language has 0, S, and R_h(counter, seed), with h a finite earlier term
whose only free variables are the locally bound names u,v. Stored bodies
index function symbols; they are not extra object-language arguments.

Permitted raw three-slot contexts F(x,y,z):
  * an implication between two equations;
  * the fixed separation matrix (0 = S0) -> bottom;
  * intuitionistically, the single fixed matrix Cov(0) -> Cov(x), where
    Cov(x) := (x = 0) or (x = S(R_u(x,0))).

The context must ignore x OR ignore z. This side condition is essential.
Its zero instance F(0,a,b) must become a literal B -> B after ZERO OR ONE
local contraction in its original syntax tree:

  R_h(0,t)       -> t
  R_h(Su,t)      -> h(u, R_h(u,t))
  Eq(0,S0)       -> bottom

No normalization to a fixed point occurs. In particular, newly created
redexes are not contracted. Rewriting, substitution, and occurrence
counting never traverse stored update descriptions. Description validation
does inspect them separately to check finiteness and their binding grammar.

The emitted axiom, with deliberate shadowing of the outer b, is

  forall a forall b,
    [forall b (F(b,a,b) -> F(Sb,a,b))] -> F(b,a,b).

Only the individual names a,b occur in emitted axioms. The raw context
still has three slots x,y,z. If x is absent, progress is reflexive. If z
is absent, the premise is ordinary progress with just one frozen parameter.

This is a syntactic diagnostic, not a checker for the mathematical
bi-interpretability proof. Run check_artifacts.py for the supplied examples.

JSON terms use ["0"], ["var", name], ["S", term], and
["R", stored_body, counter, seed]. Formulas use ["bottom"],
["eq", term, term], and ["imp"/"and"/"or", formula, formula].
The stored_body field binds u,v and is not substituted as an argument.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, replace
import json
from pathlib import Path
from typing import Iterator, Mapping


@dataclass(frozen=True, slots=True)
class Zero:
    pass


@dataclass(frozen=True, slots=True)
class Var:
    name: str


@dataclass(frozen=True, slots=True)
class Succ:
    argument: Term


@dataclass(frozen=True, slots=True)
class Description:
    """A finite, dependency-ordered body with locally bound variables u,v."""

    body: Term


@dataclass(frozen=True, slots=True)
class Rec:
    description: Description
    counter: Term
    seed: Term


Term = Zero | Var | Succ | Rec


@dataclass(frozen=True, slots=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True, slots=True)
class Bottom:
    pass


@dataclass(frozen=True, slots=True)
class Imp:
    antecedent: Formula
    consequent: Formula


@dataclass(frozen=True, slots=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True, slots=True)
class Or:
    left: Formula
    right: Formula


Formula = Eq | Bottom | Imp | And | Or
Syntax = Term | Formula
NodePath = tuple[str, ...]

ZERO = Zero()
X, Y, Z = Var("x"), Var("y"), Var("z")
A, B = Var("a"), Var("b")
U, V = Var("u"), Var("v")
COUNTER_DESCRIPTION = Description(U)
MATRIX_VARIABLES = frozenset({"x", "y", "z"})
BODY_VARIABLES = frozenset({"u", "v"})


class SyntaxErrorDetail(ValueError):
    """The input is not a term/formula of the stated finite grammar."""


class _Validator:
    def __init__(self) -> None:
        self.active_terms: set[int] = set()
        self.term_cache: dict[int, frozenset[str]] = {}
        self.active_descriptions: set[int] = set()
        self.finished_descriptions: set[int] = set()
        self.active_formulas: set[int] = set()
        self.formula_cache: dict[int, frozenset[str]] = {}

    def description(self, description: Description) -> None:
        if type(description) is not Description:
            raise SyntaxErrorDetail("R must carry a Description object")
        identity = id(description)
        if identity in self.active_descriptions:
            raise SyntaxErrorDetail("cyclic recursion-description dependency")
        if identity in self.finished_descriptions:
            return
        self.active_descriptions.add(identity)
        variables = self.term(description.body)
        if not variables <= BODY_VARIABLES:
            extra = sorted(variables - BODY_VARIABLES)
            raise SyntaxErrorDetail(f"stored update has unbound variables: {extra}")
        self.active_descriptions.remove(identity)
        self.finished_descriptions.add(identity)

    def term(self, term: Term) -> frozenset[str]:
        identity = id(term)
        if identity in self.active_terms:
            raise SyntaxErrorDetail("cyclic term tree")
        if identity in self.term_cache:
            return self.term_cache[identity]
        self.active_terms.add(identity)
        if type(term) is Zero:
            variables = frozenset()
        elif type(term) is Var:
            if not isinstance(term.name, str) or not term.name.isidentifier():
                raise SyntaxErrorDetail("variable name must be an identifier")
            variables = frozenset({term.name})
        elif type(term) is Succ:
            variables = self.term(term.argument)
        elif type(term) is Rec:
            self.description(term.description)
            variables = self.term(term.counter) | self.term(term.seed)
        else:
            raise SyntaxErrorDetail(f"unknown term constructor: {type(term).__name__}")
        self.active_terms.remove(identity)
        self.term_cache[identity] = variables
        return variables

    def formula(self, formula: Formula) -> frozenset[str]:
        identity = id(formula)
        if identity in self.active_formulas:
            raise SyntaxErrorDetail("cyclic formula tree")
        if identity in self.formula_cache:
            return self.formula_cache[identity]
        self.active_formulas.add(identity)
        if type(formula) is Eq:
            variables = self.term(formula.left) | self.term(formula.right)
        elif type(formula) is Bottom:
            variables = frozenset()
        elif type(formula) is Imp:
            variables = self.formula(formula.antecedent) | self.formula(formula.consequent)
        elif type(formula) in (And, Or):
            variables = self.formula(formula.left) | self.formula(formula.right)
        else:
            raise SyntaxErrorDetail(f"unknown formula constructor: {type(formula).__name__}")
        self.active_formulas.remove(identity)
        self.formula_cache[identity] = variables
        return variables


def validate_description(description: Description) -> None:
    _Validator().description(description)


def validate_term(term: Term, allowed: frozenset[str] | None = None) -> frozenset[str]:
    variables = _Validator().term(term)
    if allowed is not None and not variables <= allowed:
        raise SyntaxErrorDetail(f"unbound term variables: {sorted(variables - allowed)}")
    return variables


def validate_formula(
    formula: Formula, allowed: frozenset[str] | None = None
) -> frozenset[str]:
    variables = _Validator().formula(formula)
    if allowed is not None and not variables <= allowed:
        raise SyntaxErrorDetail(f"unbound matrix variables: {sorted(variables - allowed)}")
    return variables


def substitute_term(term: Term, replacements: Mapping[str, Term]) -> Term:
    """Simultaneous substitution, leaving every stored description untouched."""
    if isinstance(term, Zero):
        return term
    if isinstance(term, Var):
        # Do not recurse into the inserted term: substitution is simultaneous.
        return replacements.get(term.name, term)
    if isinstance(term, Succ):
        return Succ(substitute_term(term.argument, replacements))
    if isinstance(term, Rec):
        return Rec(
            term.description,
            substitute_term(term.counter, replacements),
            substitute_term(term.seed, replacements),
        )
    raise SyntaxErrorDetail("invalid term supplied to substitution")


def substitute_formula(formula: Formula, replacements: Mapping[str, Term]) -> Formula:
    if isinstance(formula, Bottom):
        return formula
    if isinstance(formula, Eq):
        return Eq(
            substitute_term(formula.left, replacements),
            substitute_term(formula.right, replacements),
        )
    if isinstance(formula, Imp):
        return Imp(
            substitute_formula(formula.antecedent, replacements),
            substitute_formula(formula.consequent, replacements),
        )
    if isinstance(formula, (And, Or)):
        return type(formula)(
            substitute_formula(formula.left, replacements),
            substitute_formula(formula.right, replacements),
        )
    raise SyntaxErrorDetail("invalid formula supplied to substitution")


def predecessor(term: Term) -> Term:
    return Rec(COUNTER_DESCRIPTION, term, ZERO)


def coverage(term: Term) -> Formula:
    return Or(Eq(term, ZERO), Eq(term, Succ(predecessor(term))))


def separation_matrix() -> Formula:
    return Imp(Eq(ZERO, Succ(ZERO)), Bottom())


def coverage_matrix() -> Formula:
    return Imp(coverage(ZERO), coverage(X))


def zero_instance(formula: Formula) -> Formula:
    """The raw slots x,y,z are replaced simultaneously by 0,a,b."""
    return substitute_formula(formula, {"x": ZERO, "y": A, "z": B})


def matrix_kind(formula: Formula, intuitionistic: bool) -> str | None:
    if isinstance(formula, Imp):
        if isinstance(formula.antecedent, Eq) and isinstance(formula.consequent, Eq):
            return "equation_implication"
    if formula == separation_matrix():
        return "fixed_separation"
    if intuitionistic and formula == coverage_matrix():
        return "fixed_coverage"
    return None


def _children(node: Syntax) -> tuple[tuple[str, Syntax], ...]:
    if isinstance(node, Succ):
        return (("argument", node.argument),)
    if isinstance(node, Rec):
        # The description is deliberately not a child in the object syntax.
        return (("counter", node.counter), ("seed", node.seed))
    if isinstance(node, Imp):
        return (("antecedent", node.antecedent), ("consequent", node.consequent))
    if isinstance(node, (Eq, And, Or)):
        return (("left", node.left), ("right", node.right))
    if isinstance(node, (Zero, Var, Bottom)):
        return ()
    raise SyntaxErrorDetail("unknown syntax node")


def _walk(node: Syntax, path: NodePath = ()) -> Iterator[tuple[NodePath, Syntax]]:
    yield path, node
    for field, child in _children(node):
        yield from _walk(child, path + (field,))


def _lookup(node: Syntax, path: NodePath) -> Syntax:
    for field in path:
        children = dict(_children(node))
        if field not in children:
            raise SyntaxErrorDetail(f"invalid certificate path component: {field}")
        node = children[field]
    return node


def _replace_at(node: Syntax, path: NodePath, replacement: Syntax) -> Syntax:
    if not path:
        return replacement
    field = path[0]
    children = dict(_children(node))
    if field not in children:
        raise SyntaxErrorDetail(f"invalid certificate path component: {field}")
    return replace(node, **{field: _replace_at(children[field], path[1:], replacement)})


def _contract(node: Syntax, rule: str) -> Syntax:
    if rule == "R0" and isinstance(node, Rec) and isinstance(node.counter, Zero):
        return node.seed
    if rule == "RS" and isinstance(node, Rec) and isinstance(node.counter, Succ):
        previous_counter = node.counter.argument
        previous_value = Rec(node.description, previous_counter, node.seed)
        return substitute_term(
            node.description.body, {"u": previous_counter, "v": previous_value}
        )
    if rule == "SEP" and node == Eq(ZERO, Succ(ZERO)):
        return Bottom()
    raise SyntaxErrorDetail(f"rule {rule!r} does not apply at the indicated node")


@dataclass(frozen=True, slots=True)
class Certificate:
    """A rule and an original-tree path; REFL denotes zero contractions."""

    rule: str
    path: NodePath = ()

    def to_data(self) -> dict[str, object]:
        return {"rule": self.rule, "path": list(self.path)}


def replay_certificate(base: Formula, certificate: Certificate) -> Formula:
    """Replay one certificate, never examining newly introduced redexes."""
    validate_formula(base)
    if certificate.rule == "REFL":
        if certificate.path:
            raise SyntaxErrorDetail("REFL must have an empty path")
        return base
    node = _lookup(base, certificate.path)
    contracted = _contract(node, certificate.rule)
    result = _replace_at(base, certificate.path, contracted)
    validate_formula(result)
    return result


def is_literal_reflexive(formula: Formula) -> bool:
    return isinstance(formula, Imp) and formula.antecedent == formula.consequent


def find_base_certificate(base: Formula) -> Certificate | None:
    """Decide the exact zero-or-one-contraction gate on a finite zero instance."""
    validate_formula(base)
    if is_literal_reflexive(base):
        return Certificate("REFL")
    # _walk visits only positions of the original base, not rewritten outputs.
    for path, node in _walk(base):
        if isinstance(node, Rec) and isinstance(node.counter, Zero):
            rule = "R0"
        elif isinstance(node, Rec) and isinstance(node.counter, Succ):
            rule = "RS"
        elif node == Eq(ZERO, Succ(ZERO)):
            rule = "SEP"
        else:
            continue
        result = _replace_at(base, path, _contract(node, rule))
        if is_literal_reflexive(result):
            return Certificate(rule, path)
    return None


def certificate_is_valid(base: Formula, certificate: Certificate) -> bool:
    try:
        return is_literal_reflexive(replay_certificate(base, certificate))
    except (SyntaxErrorDetail, RecursionError):
        return False


@dataclass(frozen=True, slots=True)
class Admission:
    accepted: bool
    kind: str | None
    certificate: Certificate | None
    reason: str


def admit(
    formula: Formula, *, intuitionistic: bool = True, require_mode: bool = True
) -> Admission:
    try:
        variables = validate_formula(formula, MATRIX_VARIABLES)
        kind = matrix_kind(formula, intuitionistic)
        if kind is None:
            return Admission(False, None, None, "matrix is outside the permitted grammar")
        if require_mode and {"x", "z"} <= variables:
            return Admission(False, kind, None, "context must ignore x or ignore z")
        base = zero_instance(formula)
        certificate = find_base_certificate(base)
        if certificate is None:
            return Admission(False, kind, None, "zero instance needs more than one contraction, or fails")
        return Admission(True, kind, certificate, "literal reflexivity after at most one contraction")
    except (SyntaxErrorDetail, RecursionError) as error:
        return Admission(False, None, None, f"invalid finite syntax: {error}")


def syntax_nodes(node: Syntax) -> int:
    """Expanded object-syntax count; stored description bodies are excluded."""
    return 1 + sum(syntax_nodes(child) for _, child in _children(node))


def variable_occurrences(node: Syntax, name: str) -> int:
    return sum(isinstance(current, Var) and current.name == name for _, current in _walk(node))


@dataclass(frozen=True, slots=True)
class Forall:
    variable: str
    body: Sentence


@dataclass(frozen=True, slots=True)
class SentenceImp:
    antecedent: Sentence
    consequent: Sentence


Sentence = Formula | Forall | SentenceImp


def emit_axiom(
    matrix: Formula, *, shadowed: bool = True, universal_conclusion: bool = False
) -> Sentence:
    """Build the actual first-order AST; admission must be checked separately.

    The optional 19-node universal-conclusion comparison uses three variable
    names. The main 18-node form uses deliberate b-shadowing by default.
    Allowing emission before admission is useful for rejection regressions;
    it does not make an unadmitted formula an axiom of the theory.
    """
    validate_formula(matrix, MATRIX_VARIABLES)
    counter = B if shadowed and not universal_conclusion else Var("n")
    current = substitute_formula(matrix, {"x": counter, "y": A, "z": B})
    successor = substitute_formula(matrix, {"x": Succ(counter), "y": A, "z": B})
    progress = Forall(counter.name, Imp(current, successor))
    if universal_conclusion:
        conclusion = Forall(counter.name, current)
    else:
        conclusion = substitute_formula(matrix, {"x": B, "y": A, "z": B})
    return Forall("a", Forall("b", SentenceImp(progress, conclusion)))


def sentence_nodes(sentence: Sentence) -> int:
    if isinstance(sentence, Forall):
        return 1 + sentence_nodes(sentence.body)
    if isinstance(sentence, SentenceImp):
        return 1 + sentence_nodes(sentence.antecedent) + sentence_nodes(sentence.consequent)
    return syntax_nodes(sentence)


def sentence_variable_audit(sentence: Sentence) -> dict[str, list[str]]:
    """Inspect actual individual names, respecting the two distinct b scopes."""
    all_names: set[str] = set()
    binders: list[str] = []

    def free(current: Sentence, bound: frozenset[str]) -> frozenset[str]:
        if isinstance(current, Forall):
            binders.append(current.variable)
            all_names.add(current.variable)
            return free(current.body, bound | {current.variable})
        if isinstance(current, SentenceImp):
            return free(current.antecedent, bound) | free(current.consequent, bound)
        names = validate_formula(current)
        all_names.update(names)
        return names - bound

    free_names = free(sentence, frozenset())
    return {
        "all_names": sorted(all_names),
        "binders_in_preorder": binders,
        "free_names": sorted(free_names),
    }


def emitted_axiom_nodes(matrix: Formula, *, universal_conclusion: bool = False) -> int:
    return sentence_nodes(emit_axiom(matrix, universal_conclusion=universal_conclusion))


def display_metrics() -> dict[str, int]:
    """Reconstruct partial placeholder displays as trees, not hard-coded totals."""
    def node(label: str, *children: tuple) -> tuple:
        return (label, *children)

    def count(tree: tuple) -> int:
        return 1 + sum(count(child) for child in tree[1:])

    n, a, b = node("n"), node("a"), node("b")
    sn = node("S", n)
    f3 = node("F", n, a, b)
    step3 = node("forall", node("implies", f3, node("F", sn, a, b)))
    shadowed_step = node("forall", node("implies", node("F", b, a, b),
                                       node("F", node("S", b), a, b)))
    diagonal = node("forall", node("forall", node("implies", shadowed_step,
                                                        node("F", b, a, b))))
    universal = node("forall", node("forall", node("implies", step3, node("forall", f3))))
    f2 = node("F", n, a)
    step2 = node("forall", node("implies", f2, node("F", sn, a)))
    computation = node("eq", node("R", sn, a), node("h", n, node("R", n, a)))
    old_conclusion = node("forall", node("and", f2, computation))
    normalized = node("forall", node("implies", step2, old_conclusion))
    return {
        "new_diagonal_display": count(diagonal),
        "universal_conclusion_display": count(universal),
        "existing_normalized_display": count(normalized),
    }


def term_to_data(term: Term) -> list:
    if isinstance(term, Zero):
        return ["0"]
    if isinstance(term, Var):
        return ["var", term.name]
    if isinstance(term, Succ):
        return ["S", term_to_data(term.argument)]
    if isinstance(term, Rec):
        return ["R", term_to_data(term.description.body), term_to_data(term.counter), term_to_data(term.seed)]
    raise SyntaxErrorDetail("unknown term in JSON encoding")


def formula_to_data(formula: Formula) -> list:
    if isinstance(formula, Bottom):
        return ["bottom"]
    if isinstance(formula, Eq):
        return ["eq", term_to_data(formula.left), term_to_data(formula.right)]
    if isinstance(formula, Imp):
        return ["imp", formula_to_data(formula.antecedent), formula_to_data(formula.consequent)]
    if isinstance(formula, (And, Or)):
        label = "and" if isinstance(formula, And) else "or"
        return [label, formula_to_data(formula.left), formula_to_data(formula.right)]
    raise SyntaxErrorDetail("unknown formula in JSON encoding")


def term_from_data(data: object) -> Term:
    if not isinstance(data, list) or not data:
        raise SyntaxErrorDetail("term JSON must be a nonempty tagged array")
    tag = data[0]
    if tag == "0" and len(data) == 1:
        return ZERO
    if tag == "var" and len(data) == 2:
        return Var(data[1])
    if tag == "S" and len(data) == 2:
        return Succ(term_from_data(data[1]))
    if tag == "R" and len(data) == 4:
        return Rec(Description(term_from_data(data[1])), term_from_data(data[2]), term_from_data(data[3]))
    raise SyntaxErrorDetail(f"invalid term JSON tag or arity: {tag!r}")


def formula_from_data(data: object) -> Formula:
    if not isinstance(data, list) or not data:
        raise SyntaxErrorDetail("formula JSON must be a nonempty tagged array")
    tag = data[0]
    if tag == "bottom" and len(data) == 1:
        return Bottom()
    if tag == "eq" and len(data) == 3:
        return Eq(term_from_data(data[1]), term_from_data(data[2]))
    if tag in ("imp", "and", "or") and len(data) == 3:
        constructor = {"imp": Imp, "and": And, "or": Or}[tag]
        return constructor(formula_from_data(data[1]), formula_from_data(data[2]))
    raise SyntaxErrorDetail(f"invalid formula JSON tag or arity: {tag!r}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("matrix", nargs="?", type=Path, help="JSON matrix to check")
    parser.add_argument("--logic", choices=("classical", "intuitionistic"), default="intuitionistic")
    parser.add_argument("--unrestricted-three-variable", action="store_true",
                        help="check the optional unshadowed 18-node variant without the mode restriction")
    args = parser.parse_args()
    if args.matrix is None:
        print(json.dumps({
            "partial_display_counts": display_metrics(),
            "excluded_costs": ["admission algorithm", "stored descriptions", "substituted placeholder bodies"],
            "verification_scope": "finite syntax and metric diagnostics, not the arithmetic proof",
        }, indent=2))
        return 0
    try:
        matrix = formula_from_data(json.loads(args.matrix.read_text(encoding="utf-8")))
        result = admit(matrix, intuitionistic=args.logic == "intuitionistic",
                       require_mode=not args.unrestricted_three_variable)
        output = {
            "accepted": result.accepted,
            "kind": result.kind,
            "reason": result.reason,
            "certificate": None if result.certificate is None else result.certificate.to_data(),
        }
        if result.accepted:
            output["expanded_matrix_nodes"] = syntax_nodes(matrix)
            output["expanded_18_schema_instance_nodes"] = emitted_axiom_nodes(matrix)
            output["actual_variables"] = sentence_variable_audit(
                emit_axiom(matrix, shadowed=not args.unrestricted_three_variable)
            )
        print(json.dumps(output, indent=2))
        return 0 if result.accepted else 1
    except (OSError, ValueError, RecursionError) as error:
        print(json.dumps({"accepted": False, "reason": str(error)}, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
