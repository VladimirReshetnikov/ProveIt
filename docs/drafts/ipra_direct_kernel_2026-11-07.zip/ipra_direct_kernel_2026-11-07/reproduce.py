"""Reproduce the package's finite checks and measurements offline."""
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent

def run(script,log):
    p=subprocess.run([sys.executable,'-B',str(ROOT/script)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (ROOT/'results'/log).write_text(p.stdout)
    if p.returncode:
        print(p.stdout)
        raise SystemExit(p.returncode)
    print('PASS:',script,flush=True)

(ROOT/'results').mkdir(exist_ok=True)
run('measure.py','measurement_run.txt')
run('validation/verify.py','validation_run.txt')
run('boolean_range/generate_verify.py','boolean_range_run.txt')
run('evidence.py','evidence_run.txt')
print('All finite checks and measured comparisons passed.')
