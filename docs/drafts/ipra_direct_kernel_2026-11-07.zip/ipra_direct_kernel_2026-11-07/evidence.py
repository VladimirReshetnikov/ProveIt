"""Generate report tables from exact frozen-source measurements and test records."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def main():
    m=json.loads((ROOT/'results/measurements.json').read_text())
    v=json.loads((ROOT/'validation/summary.json').read_text())
    b=json.loads((ROOT/'boolean_range/results.json').read_text())
    if v['status']!='PASS' or b['status']!='PASS':raise ValueError('Validation is not PASS')
    by_name={r['label']:r for r in m['candidates']}
    for name,profile in [('checker.py','full'),('checker_scalar.py','scalar')]:
        if by_name[name]['sha256']!=v['programs'][profile]['sha256']:
            raise ValueError('Tested source hash does not match '+name)
    if by_name['checker.py']['sha256']!=b['checker_sha256']:
        raise ValueError('Boolean reconstruction checked another source')
    fields=['source_tokens','normalized_tokens','ast_nodes','normalized_bytes','raw_bytes']
    labels=['Source tokens','Normalized tokens','AST nodes','Normalized bytes','Raw bytes']
    lines=[r'\begin{center}',r'\begin{tabular}{@{}lrrr@{}}',r'\toprule',
           r'Measure & Current minimum & Direct & Scalar\\',r'\midrule']
    for key,label in zip(fields,labels):
        lines.append(label+' & '+' & '.join(format(row[key],',') for row in [m['coordinatewise_minimum'],by_name['checker.py'],by_name['checker_scalar.py']])+r'\\')
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{center}']
    (ROOT/'results/all_measurements_table.tex').write_text('\n'.join(lines)+'\n')
    rows=m['common_driver']['candidates'];minimum=m['common_driver']['minimum']
    lines=[r'\begin{center}',r'\begin{tabular}{@{}lrrr@{}}',r'\toprule',
           r'Identical conventional driver & Tokens & AST nodes & Bytes\\',r'\midrule']
    for label,row in [('Current minimum',minimum),('Direct',rows[0]),('Scalar',rows[1])]:
        lines.append(label+' & '+' & '.join(format(row[key],',') for key in ['normalized_tokens','ast_nodes','normalized_bytes'])+r'\\')
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{center}']
    (ROOT/'results/common_driver_table.tex').write_text('\n'.join(lines)+'\n')
    ps=v['profiles'];full=ps['full'];scalar=ps['scalar']
    counts=[('Fixture/profile pairs',sum(p['fixture_count'] for p in ps.values())),
            ('Normal and optimized fixture CLI runs',sum(p['cli_processes'] for p in ps.values())),
            ('Additional error CLI runs',sum(p.get('cli_error_audit',{}).get('processes',0) for p in ps.values())),
            ('Independent opening comparisons',full['opening_audit']['cases']+scalar['opening_audit']['cases']),
            ('Seeded packet/oracle mutation comparisons',full['mutation_agreement']['cases']+scalar['mutation_agreement']['cases']),
            ('False-target attempts rejected',full['false_goal_audit']['cases']+scalar['false_goal_audit']['cases']),
            ('Staged versus simultaneous substitutions',v['sequential_opening']['cases']),
            ('Source mutation sensitivity controls',len(full['sensitivity_controls'])+len(scalar['sensitivity_controls'])),
            ('Boolean reconstruction certificates',b['certificate_count']),
            ('Additional Boolean-certificate CLI runs',b['cli_processes'])]
    lines=[r'\begin{center}',r'\begin{tabular}{@{}lr@{}}',r'\toprule',r'Finite validation category & Passed\\',r'\midrule']
    lines += [label+' & '+format(count,',')+r'\\' for label,count in counts]
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{center}']
    (ROOT/'results/validation_table.tex').write_text('\n'.join(lines)+'\n')
    (ROOT/'results/evidence_summary.json').write_text(json.dumps({'status':'PASS','counts':dict(counts),'source_hashes':v['programs']},indent=2)+'\n')
    print('PASS: exact measurement/test correspondence and report tables')

if __name__=='__main__':main()
