"""Build the complete paper from its local sources and verified result tables."""
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
for script in ['measure.py','evidence.py']:
    subprocess.run([sys.executable,str(ROOT/script)],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
for number in range(1,4):
    p=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','report.tex'],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (ROOT/'results'/('latex_pass_'+str(number)+'.txt')).write_text(p.stdout)
    if p.returncode:
        print(p.stdout[-12000:])
        raise SystemExit(p.returncode)
print('Built report.pdf')
