"""Reproduce complete-program and shared-driver comparisons, without network."""
import ast
import importlib.util
import json
import platform
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CMP = ROOT / 'comparison'
spec = importlib.util.spec_from_file_location('source_measure', CMP / 'source_measure.py')
meter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(meter)
FIELDS = ['source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes']
PRIMARY = ['normalized_tokens', 'ast_nodes', 'normalized_bytes']
DRIVER = """
try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
"""

def measure(path, expected=None):
    result = meter.metrics(path)
    if expected is not None and result['sha256'] != expected:
        raise ValueError('Comparator changed: ' + str(path))
    return result

def common_driver(path):
    tree = ast.parse(path.read_text())
    cut = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Try) or (isinstance(node, ast.If) and '__name__' in ast.unparse(node.test)))
    if not any(isinstance(node, ast.FunctionDef) and node.name == 'check' for node in tree.body[:cut]):
        raise ValueError('No compatible checker interface: ' + str(path))
    tree.body = tree.body[:cut] + ast.parse(DRIVER).body
    with tempfile.TemporaryDirectory() as temporary:
        target = Path(temporary) / 'control.py'
        target.write_text(ast.unparse(tree) + '\n')
        return measure(target)

def main():
    manifest = json.loads((CMP / 'manifest.json').read_text())
    rows = [{**r, **measure(CMP/r['local_file'], r['sha256'])} for r in manifest['programs']]
    minimum = {k:min(r[k] for r in rows) for k in FIELDS}
    candidates = [{'label':name, **measure(ROOT/name)} for name in ['checker.py', 'checker_scalar.py']]
    expanded = json.loads((CMP/'expanded_manifest.json').read_text())
    extra = [{**r, **measure(CMP/r['local_file'],r['sha256'])} for r in expanded['entries']]
    extra_minimum = {k:min(r[k] for r in extra) for k in FIELDS}
    if extra_minimum != minimum:
        raise ValueError('The expanded scan changes the comparison envelope.')
    for candidate in candidates:
        if not all(candidate[k] < minimum[k] for k in PRIMARY):
            raise ValueError('The primary strict comparison failed: '+candidate['label'])
    if not all(candidates[1][k] < minimum[k] for k in FIELDS):
        raise ValueError('The scalar five-measure comparison failed.')
    controls = [{ 'label':r['label'], **common_driver(CMP/r['local_file'])} for r in rows]
    control_candidates = [{'label':r['label'], **common_driver(ROOT/r['label'])} for r in candidates]
    result = {'python':platform.python_version(), 'commit':manifest['commit'],
              'archive_count':len(manifest['archives']), 'root_checker_count':len(rows),
              'expanded_source_hashes':len(extra),
              'expanded_path_count':sum(len(r['source_paths']) for r in extra),
              'coordinatewise_minimum':minimum, 'expanded_minimum':extra_minimum,
              'programs':rows, 'candidates':candidates,
              'common_driver':{'minimum':{k:min(r[k] for r in controls) for k in PRIMARY},
                               'comparators':controls,'candidates':control_candidates}}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/measurements.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=[r'\begin{center}',r'\begin{tabular}{@{}lrrr@{}}',r'\toprule',
           r'Complete program & Normalized tokens & AST nodes & Bytes\\',r'\midrule',
           'Current coordinatewise minima & %d & %d & %s\\\\' % tuple([minimum[PRIMARY[0]],minimum[PRIMARY[1]],format(minimum[PRIMARY[2]],',')])]
    for row,label in zip(candidates,['Direct full recursor','Scalar iterator']):
        vals=[str(row[k]) if k!='normalized_bytes' else format(row[k],',') for k in PRIMARY]
        lines.append(label+' & '+' & '.join(r'\textbf{'+v+'}' for v in vals)+r'\\')
    lines.extend([r'\bottomrule',r'\end{tabular}',r'\end{center}'])
    (ROOT/'results/measurement_table.tex').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['programs','common_driver']},indent=2))
    print('Common-driver minima:',result['common_driver']['minimum'])
    print('Common-driver candidates:',[{k:r[k] for k in ['label',*PRIMARY]} for r in control_candidates])

if __name__ == '__main__':
    main()
