VALIDATION OF THE FROZEN COMPLETE CHECKERS
==========================================

Run: python3 verify.py
The support can live beside the checkers or in their validation/ subfolder.
Only Python's standard library is required. The checkers accept a path to a
JSON proof packet and print exactly ACCEPT/REJECT, with exit status 0/1.

Frozen source metrics (significant source tokens / normalized tokens /
AST nodes / normalized UTF-8 bytes / raw bytes):
  checker.py:        372 / 374 / 398 / 1088 / 1151
  checker_scalar.py: 365 / 367 / 392 / 1076 / 1132
metrics.json records the SHA-256 hashes and the original metric's core fields.
The original core metric excludes imports; it does not isolate the mathematical
proof kernel from the rest of the command-line driver.

SHARED NUMERICAL ALIAS POLICY
Both checkers accept JSON False as zero and True as bound
coordinate one. True is not the numeral one, whose spelling is [0]. A used
True outside a protecting binder rejects. Booleans cannot occupy formula
positions. Floats are rejected even when their mathematical values are integral.
Unused witness annotations remain inert in both profiles.

Both profiles interpret integers outside the current interval [k,d) as the
single exposed template hole. This includes integers below the current rigid
parameter floor k. Closed syntax has no image; any such exposed coordinate
then rejects. The current floor is taken after a major proof has finished,
including any parameter allocations made by a failed major proof.

Each checker's terminal expression 1/check(...) accepts only a True
return. False raises ZeroDivisionError, caught by the existing rejection
handler. All fixture packets pass the same verdict checks under ordinary
Python and python -O. There is no assert in either production checker.

FINAL FINITE EVIDENCE (Python 3.12.14)
- 99 full-recursion fixtures: 44 accepted, 55 rejected.
- 95 scalar fixtures: 41 accepted, 54 rejected.
- 39 accepted scalar certificates translated to full recursion.
- All 233 fixture/profile pairs checked against the independent named oracle
  and run through the actual command-line programs both normally and with -O:
  466 command-line processes.
- 32 further command-line runs reject missing files, missing arguments,
  malformed JSON, NaN/Infinity payloads, and trailing input.
- 19,760 opening/validation comparisons against independent named parsing.
- 4,000 seeded mutated packets with exact oracle verdict agreement.
- 600 attempts with target 0=S0 all rejected.
- 2,500 full recursor comparisons between production sequential opening and
  independent simultaneous named substitution.
- 23 source mutation controls expose capture, full-formula induction,
  deleted retained bases, undeclared parameters, missing validation, default
  zero images, unchecked computation/transport, invalid successor forms,
  counter/state mistakes, and required Boolean-alias handling.
- Deleted terminal rejection guards in both checkers are exposed in both Python
  modes; eight additional runs compare mutant and production behavior.

There were no mismatches. Detailed results are in results.json; compact
counts and source hashes are in summary.json. The fixtures are in cases/.

These finite checks support the implemented native proof-calculus behavior.
They do not prove consistency, soundness, full first-order bi-interpretability,
historical novelty, or global minimality. Written mathematical arguments and
explicit trust-boundary definitions are required separately.
