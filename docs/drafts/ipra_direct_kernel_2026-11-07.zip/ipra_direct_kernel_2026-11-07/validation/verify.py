"""Finite independent checks; no soundness or bi-interpretability claim.

Run this script from any directory. The two standalone checkers are siblings.
The named oracle shares no production traversal, sort/depth table, dispatch,
or source imports. Its full recursor uses simultaneous named substitution.
"""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import types

from generate_cases import Builder, generated
from named_oracle import Oracle, opening, computation_rhs, embed_packet, embed_scalar

HERE = Path(__file__).resolve().parent
KERNEL_DIR = HERE if (HERE / 'checker.py').is_file() else HERE.parent
PROGRAMS = {'full': KERNEL_DIR / 'checker.py', 'scalar': KERNEL_DIR / 'checker_scalar.py'}


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def load_kernel(path, source=None):
    source = path.read_text() if source is None else source
    tree = ast.parse(source, filename=str(path))
    nodes = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom, ast.FunctionDef))
             or isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'k'
                                                  for t in n.targets)]
    module = types.ModuleType(path.stem)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), module.__dict__)
    return module


def run(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'final_k': module.k,
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def agreement(module, packet, width, name):
    actual = run(module, packet)
    expected = Oracle(width).run(packet)
    require(actual['accepted'] == expected['accepted'], ('oracle verdict', name, actual, expected))
    if actual['accepted']:
        for field in ('final_k', 'remaining'):
            require(actual[field] == expected[field], ('successful trace', name, field, actual, expected))
    return actual, expected


def extended_cases(width):
    rows = generated(width)
    for row in rows:
        if row['name'] == 'boolean_zero_is_not_numerical':
            row['name'] = 'boolean_zero_is_a_permitted_alias'
        if row['name'] == 'boolean_unused_update_is_invalid':
            row['name'] = 'boolean_coordinate_is_a_permitted_alias'

    def add(name, packet, expected, reason):
        rows.append({'name': name, 'packet': packet, 'expected': expected, 'reason': reason})

    for i, hole in enumerate((-1, -2, -999, -(10 ** 100), 1, 2, 10 ** 100)):
        builder = Builder([0, 0], width)
        builder.transport([[0, 0, 0], 0], [hole, 0], builder.computation, builder.computation)
        add('signed_hole_transport_%02d' % i, builder.packet(), True,
            'Every integer outside the current interval names the one template hole.')
    builder = Builder([[0, 0]], width)
    builder.transport([[0, 0, 0], 0], [[-999, -1000]], builder.computation,
                      lambda: builder.intro(0, lambda *_: builder.hyp()))
    add('two_negative_holes_under_binder', builder.packet(), True,
        'The same hole is substituted below a protected binder without capture.')
    builder = Builder([0, 0], width)
    builder.transport([[0, 0, 0], 0], [-999, 10 ** 100], builder.computation, builder.reflexivity)
    add('mixed_signed_hole_spellings', builder.packet(), True,
        'Negative and positive out-of-scope integers denote one common hole.')

    # Adapted from the current scope-complement archive. The major proof
    # consumes two eigenparameters before the transport motive is opened.
    for hole in (-1, -2, -3, -(10 ** 30)):
        packet = [[], [], [], 0,
                  [[[[0, 0, 0], 0], [0, 0], [0, 0]], None],
                  [[[0, 0, 0], 0], [hole, 0]], [0, 0]]
        add('scope_after_major_%s' % abs(hole), packet, hole < -2,
            'The template interval is the interval after the major proof finishes.')

    add('transport_wrong_target_false_sentence',
        [[], [], [[[0, 0, 0], 0], [1, 0]], [0, [0]]], False,
        'A true major and true minor cannot bypass the exact target check.')
    add('bool_successor_state_alias', [[], [[[False], False, True], [False, False, True]]],
        True, 'Both profiles admit False=0 and True=coordinate 1.')
    add('bool_zero_is_not_successor', [[], [[False, False, True], [False]]], False,
        'Permitting zero aliases never identifies zero with its successor.')
    add('bool_exposed_coordinate_rejected', [[], [[True, 0, 0], 0]], False,
        'True is coordinate 1, not the numerical one [0].')
    add('bool_false_sentence_rejected', [[], [False, [False]]], False,
        'The alias spelling of 0=S0 remains rejected.')
    add('float_under_update_rejected', [[], [[0, 0, 1.0], 0]], False,
        'Floating-point integers are never numerical syntax.')
    add('false_padding_is_not_formula', [0, [[0, 0], False, [0, 0]]], False,
        'Boolean aliases are available only in the numerical sort.')
    for i, term in enumerate(('x', '', '\u2200', '\U0001f642', {'a': 0}, {'': 0}, None,
                              0.0, 1.0, [], [0, 0], [0, 0, 0, 0])):
        add('malformed_term_%02d' % i, [[], [[0, term, 0], 0]], False,
            'Every syntax node, including an otherwise unused branch, is validated.')
    for i, packet in enumerate((None, True, False, 0, '', 'x', {'0': 0}, [True], [False], [None])):
        add('malformed_packet_%02d' % i, packet, False,
            'The public interface requires an array containing a closed formula.')
    return rows


def opening_audit(module, width):
    atoms = [-100, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 999,
             True, False, 0.0, 1.0, None, {}, '0', '\u2200']
    terms = [*atoms, [], [0], [1], [999], [0, 0], [0, 0, 1],
             [0, 0, 3], [0, 0, 5], [0, 0, 999], [1, 0, [0, 3, 7]],
             [0, 0, [0, 1, 999]], [3, 1, [5, 7, [1]]]]
    formulas = [[term, 0] for term in terms]
    formulas += [[[t, 0]] for t in (-100, -2, 0, 1, 2, 3, 4, 5, 7, 999)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-100, -2, 0, 1, 2, 3, 4, 5, 7, 999)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 999], 5]], [0, 0], [0, 0]]]
    images = [None, 0, -1, -3, 1, 2, [0], [0, 0, 1], [0, 0, 3], True, False, {}, 'x']
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2, 3):
                for lower in (0, -2):
                    for image in images:
                        module.k = lower
                        try:
                            actual = module.inst(deepcopy(value), deepcopy(image),
                                                 2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        try:
                            expected = opening(deepcopy(value), deepcopy(image), formula=formula,
                                               depth=depth, lower=lower, width=width)
                            valid_expected = True
                        except Exception:
                            expected, valid_expected = None, False
                        require(valid == valid_expected and (not valid or actual == expected),
                                ('opening', width, value, image, formula, depth, lower, actual, expected))
                        counts['accepted' if valid else 'rejected'] += 1
    return {'cases': sum(counts.values()), **dict(counts)}


def random_term(rng, depth, bound, width):
    choices = [0, -1, -2, *range(1, 2 * bound + 1)]
    if width == 2:
        choices.append(False)
        if bound:
            choices.append(True)
    if depth == 0 or rng.random() < .45:
        return rng.choice(choices)
    if rng.random() < .4:
        return [random_term(rng, depth - 1, bound, width)]
    return [random_term(rng, depth - 1, bound, width),
            random_term(rng, depth - 1, bound, width),
            random_term(rng, depth - 1, bound + width, width)]


def staged_opening_audit(module, count=2500):
    rng = random.Random(2026110701)
    module.k = -2
    for i in range(count):
        counter = random_term(rng, 2, 0, 2)
        initial = random_term(rng, 2, 0, 2)
        update = random_term(rng, 3, 2, 2)
        lhs = [[counter], initial, update]
        actual = module.inst(module.inst(update, counter, 3), [counter, initial, update], 1)
        expected = computation_rhs(lhs, lower=-2, width=2)
        require(actual == expected, ('staged versus simultaneous', i, lhs, actual, expected))
    return {'cases': count, 'seed': 2026110701,
            'comparison': 'sequential production opening versus simultaneous named substitution'}


def paths(value, path=()):
    result = [path]
    if type(value) is list:
        for i, child in enumerate(value):
            result.extend(paths(child, (*path, i)))
    return result


def mutate(value, rng):
    value = deepcopy(value)
    path = rng.choice(paths(value))
    replacements = [None, True, False, -999, -1, 0, 1, 2, 3, 5, 999,
                    [], [0], [0, 0], [0, 0, 0, 0], {'bad': 0}, 'x', 0.0]
    replacement = deepcopy(rng.choice(replacements))
    if not path:
        return replacement
    parent = value
    for position in path[:-1]:
        parent = parent[position]
    parent[path[-1]] = replacement
    return value


def mutation_agreement(module, rows, width, count=2000):
    rng = random.Random(2026110702 + width)
    eligible = [row['packet'] for row in rows if row['expected'] and len(row['packet']) < 150]
    counts = Counter()
    for i in range(count):
        packet = mutate(rng.choice(eligible), rng)
        actual, _ = agreement(module, packet, width, 'mutation_' + str(i))
        counts['accepted' if actual['accepted'] else 'rejected'] += 1
    return {'cases': count, 'seed': 2026110702 + width, **dict(counts)}


def false_goal_audit(module, rows, width, count=300):
    rng = random.Random(2026110710 + width)
    eligible = [row['packet'] for row in rows if row['expected'] and len(row['packet']) < 150]
    for i in range(count):
        packet = deepcopy(rng.choice(eligible))
        packet[-1] = [0, [0]]
        actual, _ = agreement(module, packet, width, 'false_target_' + str(i))
        require(not actual['accepted'], ('false target accepted', width, i))
    return {'cases': count, 'seed': 2026110710 + width, 'rejected': count}


def controls(path, rows, width):
    source = path.read_text()
    specifications = [
        ('capture_allowed', 'inst(t, d=1)', 'inst(t, d=d)', 'contextual_capture_attack', True),
        ('compound_induction_allowed', 'h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [a, inst(a, 0)]', 'compound_induction_hypothesis_attack', True),
        ('atomic_base_deleted', 'h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [a] if len(a) == 2 else [inst(a, 0)]', 'retained_false_base_is_used', False),
        ('future_parameters_allowed', 'k <= a < d', 'a < d',
         'future_parameter_in_unused_update', True),
        ('goal_validation_removed', 'if inst(a) in g:', 'if a in g:',
         'future_parameter_in_unused_update', True),
        ('implicit_zero_image', 'def inst(a, t=None, d=0):', 'def inst(a, t=0, d=0):',
         'global_unused_update_hole', True),
        ('wrong_computation_allowed', 'return b == t', 'return True',
         'wrong_zero_initializer', True),
        ('transport_endpoint_unchecked', 'inst(t, m[1]) == a and ', '',
         'transport_wrong_target_false_sentence', True),
        ('non_successor_counter_allowed', 'n, = n', 'n = n[0]',
         'counter_is_not_syntactic_successor', True),
    ]
    if width == 2:
        specifications += [
            ('counter_and_state_exchanged', 't = inst(inst(r, n, 3), [n, t, r], 1)',
             't = inst(inst(r, [n, t, r], 3), n, 1)', 'counter_and_state_swapped', True),
            ('outer_counter_opening_omitted', 't = inst(inst(r, n, 3), [n, t, r], 1)',
             't = inst(r, [n, t, r], 1)', 'counter_and_state_swapped', True),
            ('permitted_boolean_alias_removed', 'd & isinstance(a, int)',
             'd & (type(a) is int)', 'boolean_zero_is_a_permitted_alias', False),
        ]
    else:
        specifications += [
            ('phantom_scalar_counter', "b'\\0\\0\\2'", "b'\\0\\0\\4'",
             'unused_counter_update_coordinate', True),
            ('permitted_scalar_boolean_alias_removed', 'd & isinstance(a, int)',
             'd & (type(a) is int)', 'boolean_zero_is_a_permitted_alias', False),
        ]
    by_name = {row['name']: row for row in rows}
    results = []
    for label, before, after, name, expected in specifications:
        require(source.count(before) == 1, ('mutation anchor', label))
        module = load_kernel(path, source.replace(before, after))
        actual = run(module, by_name[name]['packet'])['accepted']
        require(actual == expected, ('sensitivity control', label, name, actual, expected))
        require(actual != by_name[name]['expected'], ('control did not flip verdict', label))
        results.append({'mutant': label, 'fixture': name, 'mutant_accepts': actual,
                        'correct_accepts': by_name[name]['expected']})
    return results


def cli(path, packet_path, expected, optimized=False):
    command = [sys.executable, *(['-O'] if optimized else []), str(path), str(packet_path)]
    process = subprocess.run(command, capture_output=True, text=True, timeout=15)
    actual = (process.returncode, process.stdout.strip(), process.stderr)
    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
    require(actual == wanted, ('public CLI', path.name, packet_path.name, optimized, actual, wanted))
    return {'optimized': optimized, 'exit_status': process.returncode,
            'stdout': process.stdout.strip()}


def cli_error_audit(path, directory):
    checks = []
    texts = ['', '{', '[]garbage', 'NaN', 'Infinity', '[[], [[NaN, 0, 0], 0]]']
    for i, text in enumerate(texts):
        target = directory / ('invalid_json_%02d.txt' % i)
        target.write_text(text)
        for optimized in (False, True):
            checks.append(cli(path, target, False, optimized))
    for optimized in (False, True):
        process = subprocess.run([sys.executable, *(['-O'] if optimized else []), str(path)],
                                 capture_output=True, text=True, timeout=15)
        require((process.returncode, process.stdout.strip(), process.stderr) == (1, 'REJECT', ''),
                ('missing file argument', path, optimized, process))
        checks.append({'optimized': optimized, 'kind': 'missing file argument'})
        checks.append(cli(path, directory / 'nonexistent.json', False, optimized))
    return {'processes': len(checks), 'all_rejected': True}


def driver_sensitivity(path, cases_dir):
    source = path.read_text()
    anchor = '1 / check(take(), [])'
    require(source.count(anchor) == 1, 'checker guard anchor')
    mutant_path = HERE / 'mutant_driver.py'
    mutant_path.write_text(source.replace(anchor, 'check(take(), [])'))
    packet_path = cases_dir / 'wrong_zero_initializer.json'
    result = []
    for optimized in (False, True):
        # The deliberately broken driver accepts a false computation. The
        # negative fixture must expose this defect in both Python modes.
        result.append(cli(mutant_path, packet_path, True, optimized))
        cli(path, packet_path, False, optimized)
    mutant_path.unlink()
    return {'mutant': 'false_return_guard_deleted', 'detected_in_both_modes': True,
            'checks': result}


def main():
    updating_scalar = '--scalar-update' in sys.argv
    modules = {name: load_kernel(path) for name, path in PROGRAMS.items()}
    inventories = {name: extended_cases(width) for name, width in [('full', 2), ('scalar', 1)]}
    inventories['embedded'] = [
        {'name': row['name'], 'packet': embed_packet(row['packet']), 'expected': True}
        for row in inventories['scalar'] if row['expected'] and not row['name'].startswith('failed_major_')]
    (HERE / 'cases').mkdir(exist_ok=True)
    result = {'python': platform.python_version(), 'scope': 'finite executable validation',
              'programs': {name: {'path': path.name,
                                  'sha256': sha256(path.read_bytes()).hexdigest()}
                           for name, path in PROGRAMS.items()}, 'profiles': {}}
    if updating_scalar:
        previous = json.loads((HERE / 'results.json').read_text())
        require(previous['programs']['full'] == result['programs']['full'],
                'full checker changed during scalar-only validation')
        result['profiles']['full'] = previous['profiles']['full']
        result['sequential_opening'] = previous['sequential_opening']
        controls_before = previous.get('driver_sensitivity', {})
        result['driver_sensitivity'] = ({'full': controls_before} if 'mutant' in controls_before
                                        else controls_before)
    profile_order = [('scalar', 1), ('embedded', 2)] if updating_scalar else [
        ('full', 2), ('scalar', 1), ('embedded', 2)]
    for name, width in profile_order:
        key = 'full' if name == 'embedded' else name
        directory = HERE / 'cases' / name
        directory.mkdir(exist_ok=True)
        profile = {'fixtures': []}
        rule_counts = Counter()
        for row in inventories[name]:
            packet_path = directory / (row['name'] + '.json')
            packet_path.write_text(json.dumps(row['packet']) + '\n')
            actual, oracle = agreement(modules[key], row['packet'], width, name + '/' + row['name'])
            require(actual['accepted'] == row['expected'], ('fixture expectation', name, row['name'], actual))
            rule_counts.update(oracle['rules'])
            checks = [cli(PROGRAMS[key], packet_path, row['expected'], optimized)
                      for optimized in (False, True)]
            profile['fixtures'].append({'name': row['name'], 'expected': row['expected'],
                                        'actual': actual, 'oracle': oracle, 'cli': checks,
                                        'packet_sha256': sha256(packet_path.read_bytes()).hexdigest()})
        profile['fixture_count'] = len(inventories[name])
        profile['accepted_count'] = sum(row['expected'] for row in inventories[name])
        profile['rejected_count'] = profile['fixture_count'] - profile['accepted_count']
        profile['cli_processes'] = 2 * profile['fixture_count']
        profile['rules_exercised'] = dict(rule_counts)
        if name != 'embedded':
            profile['opening_audit'] = opening_audit(modules[key], width)
            profile['mutation_agreement'] = mutation_agreement(modules[key], inventories[name], width)
            profile['false_goal_audit'] = false_goal_audit(modules[key], inventories[name], width)
            profile['sensitivity_controls'] = controls(PROGRAMS[key], inventories[name], width)
            profile['cli_error_audit'] = cli_error_audit(PROGRAMS[key], directory)
        result['profiles'][name] = profile
        print(name, 'PASS', profile['fixture_count'], 'fixtures', flush=True)
    if not updating_scalar:
        result['sequential_opening'] = staged_opening_audit(modules['full'])
        result['driver_sensitivity'] = {}
    for profile in (('scalar',) if updating_scalar else ('full', 'scalar')):
        result['driver_sensitivity'][profile] = driver_sensitivity(
            PROGRAMS[profile], HERE / 'cases' / profile)
    result['status'] = 'PASS'
    (HERE / 'cases.json').write_text(json.dumps(inventories, indent=2) + '\n')
    (HERE / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    summary = {**result, 'profiles': {name: {k: v for k, v in profile.items() if k != 'fixtures'}
                                     for name, profile in result['profiles'].items()}}
    (HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
