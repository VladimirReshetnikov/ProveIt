"""Four actual native proof certificates for the Boolean-range reconstruction.

This producer and its named-binder oracle are untrusted support. Each packet
is independently checked by the frozen complete full-recursion executable,
both normally and under Python optimization.
"""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SUPPORT = next(p for p in (HERE.parent / 'validation', HERE.parent / 'validation_new', HERE.parent)
               if (p / 'named_oracle.py').is_file())
CHECKER = SUPPORT / 'checker.py'
if not CHECKER.is_file():
    CHECKER = SUPPORT.parent / 'checker.py'
sys.path.insert(0, str(SUPPORT))
from generate_cases import Builder
from named_oracle import Syntax, Oracle, opening


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def canonical_matrix(template):
    """Name the free hole, then emit its proper coordinate under each binder."""
    syntax = Syntax(lower=0, width=2)
    return syntax.formula_data(syntax.formula(template, template=True), emit_hole=True)


def selector(n, a, b):
    return [n, a, b]


def sign(n):
    return selector(n, 0, [0])


def predecessor(n):
    # State is coordinate one and previous counter is coordinate three.
    return [n, 0, 3]


def reconstruction(n):
    return selector(sign(n), 0, [predecessor(n)])


def build():
    hole = 10 ** 6
    # The deliberately excessive integer is a free-hole marker. The named
    # parser makes its coordinates correct below the two recursor binders.
    identity = canonical_matrix([reconstruction(hole), hole])
    successor_sign = canonical_matrix([sign([hole]), [0]])
    rows = []

    def add(name, formula, goal, action, note):
        builder = Builder(goal, width=2)
        action(builder)
        rows.append({'name': name, 'formula': formula, 'packet': builder.packet(),
                     'producer_allocations': -builder.lower, 'note': note})

    add('reconstruction_base', 'L(0)=0', opening(identity, 0, width=2),
        lambda b: b.normalize(),
        'Two outer computation reductions, assembled as equality-transport proofs.')
    add('reconstruction_closure', 'Q_n(L(n)=n)', [identity],
        lambda b: b.intro(0, lambda *_: b.normalize()),
        'The successor step normalizes directly; the induction hypothesis is unused.')
    add('sign_zero', 'z(0)=0', [sign(0), 0], lambda b: b.computation(),
        'A direct R0 computation certificate.')
    add('sign_successor_closure', 'Q_n(z(Sn)=1)', [successor_sign],
        lambda b: b.intro(0, lambda *_: b.normalize()),
        'Every successor instance reduces directly by RS; the induction hypothesis is unused.')
    return rows, identity, successor_sign


def main():
    rows, identity, successor_sign = build()
    results = []
    for row in rows:
        packet_path = HERE / (row['name'] + '.json')
        packet_path.write_text(json.dumps(row['packet']) + '\n')
        oracle = Oracle(2).run(row['packet'])
        require(oracle['accepted'], ('oracle rejected', row['name'], oracle))
        require(-oracle['final_k'] == row['producer_allocations'], ('allocation mismatch', row['name']))
        cli = []
        for optimized in (False, True):
            process = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                      str(CHECKER), str(packet_path)],
                                     capture_output=True, text=True, timeout=15)
            require((process.returncode, process.stdout.strip(), process.stderr) == (0, 'ACCEPT', ''),
                    ('CLI rejected', row['name'], optimized, process.returncode,
                     process.stdout, process.stderr))
            cli.append({'optimized': optimized, 'exit_status': process.returncode,
                        'stdout': process.stdout.strip()})
        results.append({k: v for k, v in row.items() if k != 'packet'} | {
            'packet_entries': len(row['packet']), 'packet_bytes': packet_path.stat().st_size,
            'packet_sha256': sha256(packet_path.read_bytes()).hexdigest(),
            'oracle': oracle, 'cli': cli})
    result = {'status': 'PASS', 'checker_sha256': sha256(CHECKER.read_bytes()).hexdigest(),
              'identity_matrix': identity, 'successor_sign_matrix': successor_sign,
              'certificate_count': len(rows), 'cli_processes': 2 * len(rows), 'certificates': results}
    (HERE / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
