BOOLEAN-RANGE RECONSTRUCTION: FOUR ACTUAL PROOF PACKETS
======================================================

Definitions in the full primitive-recursion language:
  C(n,a,b) = R(n,a;v,u.b), with v,u fresh for b;
  z(n) = C(n,0,1), where 1=S0;
  P(n) = R(n,0;v,u.v);
  L(n) = C(z(n),0,S P(n)).

The defining equations give:
  z(0)=0,  z(Sn)=1,  P(Sn)=n,
  L(0)=0,
  L(Sn)=C(1,0,S P(Sn))=S P(Sn)=Sn.
Consequently equation induction proves L(n)=n. Its successor premise
uses no induction hypothesis. The certificate generator constructs these
reductions as actual native computation and equality-transport derivations.

FILES
- reconstruction_base.json: L(0)=0; 16 packet entries, 513 bytes.
- reconstruction_closure.json: Q_n(L(n)=n); 23 entries, 791 bytes.
- sign_zero.json: z(0)=0; 2 entries, 23 bytes.
- sign_successor_closure.json: Q_n(z(Sn)=1); 11 entries, 238 bytes.

The native Q_y B is the base-conditioned closure B(0) -> forall y B(y).
Thus the first two packets together yield every instance of L(n)=n by QE.
For the sign-successor closure, its base z(S0)=1 is directly an RS instance.
No packet should be read as deriving an unconditional universal claim from
Q alone without the corresponding base.

The closure steps use no hypothesis leaves. Their proof records contain
only atomic closure introduction, computations, and equality transport.
They do not assume Boolean-range disjunction or numerical coverage in the
successor reductions. These packets support the equational reconstruction
needed when analyzing the additional Boolean-range axiom z(n)=0 or z(n)=1;
they do not themselves purport to certify that disjunction schema.

REPRODUCTION
Run: python3 boolean_range_cases/generate_verify.py
The script finds named_oracle.py and generate_cases.py in the sibling
validation/ directory, and checker.py at the package root. It also supports
the development layout with a sibling validation_new/ directory.

All four packets were accepted by the independent named-binder oracle and
by the frozen full-recursion checker, normally and with python -O: eight
actual command-line processes. results.json records every packet hash,
rule count, eigenparameter allocation, and CLI verdict.

Full checker SHA-256:
14471b2f011c97a462af00aebb742c3152b8efc11f1290f73403f190ff9ea161

The producer and oracle are untrusted support. They are never imported by
the complete checker. Each accepted packet is verified independently by it.
