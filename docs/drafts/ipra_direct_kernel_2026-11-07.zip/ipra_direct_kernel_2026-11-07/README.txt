SMALLER CHECKERS FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
===============================================================
Prepared for Vladimir Reshetnikov, 7 November 2026.

PURPOSE AND RESULTS

This package contains a mathematical paper, its LaTeX sources, two complete
standalone proof checkers, proof certificates, and reproducible comparisons.
The paper specifies the logical and arithmetic rules, reconstructs full
intuitionistic first-order logic, and gives mathematical proofs of
equiconsistency and bi-interpretability with iPRA.

checker_scalar.py is the smallest delivered checker. Its numerical operator
is an initialized scalar iterator, whose update binds the previous value.
checker.py uses full primitive recursion, whose update also binds the
previous counter. This gives the shorter direct arithmetic interpretation;
the scalar predecessor and coding arguments appear in the appendices.

The mathematical additions identify numerical coverage with one Boolean
range axiom and prove an obstruction to equation-only bi-interpretations,
including ordinary definable quotient domains and finitely many parameters.
The smaller executable sources integrate compatible existing conventions;
the inherited arithmetic and logical basis is explicitly credited.

EXACT MEASUREMENTS

The frozen comparison is ProveIt commit
25e16049bbc73c92703296181e0696370c987577, six current draft archives and
their ten root checker programs. Measurements use CPython 3.12.14 and the
inherited docstring-removal and ast.unparse convention. Complete sources
include imports, JSON input, validation, inference rules, error handling,
verdict output, and exit status.

                    Source tokens  Normalized tokens  AST nodes  Norm bytes  Raw bytes
Current minima                372                375        403        1117       1173
checker_scalar.py             365                367        392        1076       1132
checker.py                    372                374        398        1088       1151

The scalar checker is below every recorded minimum. The direct checker is
below all three normalized minima and ties the source-token minimum.
With an identical conventional command-line driver, the scalar version
still beats the current normalized envelope: 371 tokens, 397 AST nodes,
1113 bytes. The direct version then has 378/403/1125, so its complete-source
advantage includes its compact error driver. See results/measurements.json
and the paper for the comparison boundary and exact source hashes.

These are corpus-relative improvements. They are not a proof of absolute,
encoding-independent, or globally shortest axiomatization. Normalized
measurements can vary with the Python version.

QUICK START

Use Python 3.10 or later; the checkers require only its standard library.
Run these commands from the extracted package directory:

  python3 checker_scalar.py validation/cases/scalar/addition_two_three.json
  python3 checker.py boolean_range/reconstruction_closure.json
  python3 -O checker.py boolean_range/reconstruction_closure.json

Each example prints ACCEPT and exits with status 0. Rejection prints REJECT
and exits with status 1. FORMAT.txt specifies the complete packet language.
Both checkers accept Boolean numerical aliases: false denotes zero and
true denotes coordinate one. Neither Boolean is an unrestricted formula;
true is not the numeral one, whose representation is [0].

REPRODUCTION

Reproduce the finite checks, actual certificates, and measured comparisons:

  python3 reproduce.py

Build the paper with pdflatex and the LaTeX packages listed in report.tex:

  python3 build.py

build.py refreshes the measured/evidence tables and runs pdflatex three
times. Once those tables exist, the equivalent LaTeX compilation commands
are:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

The package is self-contained for these operations; no network is needed.

CONTENTS AND EVIDENCE

- report.tex, sections/, appendices/, report.pdf: the complete paper.
- checker_scalar.py, checker.py: complete trusted checker sources.
- comparison/: unchanged comparator sources and provenance.
- validation/: independent named-binder oracle, certificate producer,
  adversarial fixtures, mutation controls, and detailed results.
- boolean_range/: four actual reconstruction certificates and their
  independent oracle and normal/optimized CLI verification.
- results/: measurements, evidence summaries, and reproduction logs.

The recorded validation includes 233 fixture/profile pairs, each checked
normally and with -O; 19,760 independent opening comparisons; 4,000 mutated
packet/oracle comparisons; 600 rejected attempts targeting 0=S0; and 2,500
comparisons of staged with simultaneous full-recursion substitution.
Four further certificates prove the equational reconstruction used in the
Boolean-range analysis. The detailed results distinguish these finite
checks from mathematical metatheorems.

TRUST AND LIMITS

Neither checker imports the proof producer, oracle, measurement scripts,
or another project-specific module. Used syntax and substituted images are
checked; the retained base is always available during introduction, while
an induction hypothesis is available only for a literal equation.

The completeness statement uses idealized unlimited finite resources.
Python recursion, parsing, time, and memory limits can reject large valid
certificates. The programs check proofs in the stated calculus; they do
not decide arbitrary arithmetical truth.

The mathematical arguments are written proofs, not a Lean or Rocq
mechanization of the whole development or Python runtime. Finite tests
alone do not establish soundness, consistency, or bi-interpretability.
See ATTRIBUTION.txt and the preserved source licenses for provenance.
