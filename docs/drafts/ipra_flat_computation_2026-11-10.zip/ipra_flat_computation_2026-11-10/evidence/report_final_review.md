# Final report review

Reviewed `report.tex`, `theory/main.tex`, the delivered complete checker, the generated verification summary, and inherited-provenance entries. No final deliverable was modified.

## Verdict

No blocking mathematical defect found in the changed theory or its account of the checker. The final text correctly describes a strict but modest simultaneous source-metric improvement, preserves the distinction from an absolute optimum or significant breakthrough, and distinguishes written metatheory from finite tests and formal proof-assistant verification.

The delivered checker is exactly 679 raw bytes and has SHA-256 `8ac122714ebb0f3351d6eb9a7bf3b97031e2055436ea83b2e20d5c81b80acf06`, matching the independently reviewed 278-token / 314-AST / 679-normalized-byte program.

## Specific mathematical points checked

- **Primitive IB versus admitted computations:** the abstract theory only needs I0 and boxed IB. The boxing theorem derives unrestricted IS before the implementation soundness theorem uses it. Therefore permitting other composite predecessor computations in the program is an admissible extension and introduces no hidden primitive schema. The equivalence proof does not circularly assume cut in the restricted theory: cut is established for the inherited calculus in the forward translation, and the reverse translation expands each computation leaf directly.
- **Uniform supply:** the null branch really opens arithmetic assumptions with literal zero. The supplied proof correctly separates a used recursive image (validated at the old floor) from an unused image (state-independent update), while keeping eager `list(*s)` constructor validation. Fresh negative aliases are consistently retained. The proof supports uniform computation theorems, rather than merely true zero instances.
- **Canonical completeness:** B(p)=I(0,p;v.0) is list-shaped and equal to p by I0. Compute at B(p), then transport with a motive that keeps all passive arguments fixed. This recovers every omitted IS instance. The null command tag permits the previously awkward literal zero witness directly.
- **Atomic-case obstruction:** the proposed counterinterpretation is sound for the retained primitive rules in standard arithmetic. Atomic D is read as existential progressivity; its DE rule follows because progressivity entails conditional closure by ordinary induction. Numerical transport cannot change the root classification. D(y=1), with unused existential coordinate, is false in this interpretation but follows in the old calculus from its atomic case rule under 0=1. The counterinterpretation does not retain previously derived Q/D equivalences as additional axioms; the report's explicit primitive inventory makes this boundary appropriate.
- **Raw Q formulas:** both directions between Q_y A and unused-witness D_{x,y}A follow from the displayed rules, with Hyp providing the DE continuation. Using this as a derived definitional extension, together with binder congruence from the inherited bridge, correctly handles arbitrary raw unary goals. No internal-clause-only restriction is silently substituted for the public interface.
- **Interpretation scope:** the report keeps whole-domain actual equality, both formula composites, and explicit ordinary coverage/falsity bridges. Its numerical bootstrap precedes pairing and does not infer nonstandard equality reflection from finite evaluations.

## Two concrete reporting corrections

1. In `theory/main.tex`, the sentence saying that "canonical certificates use integers and arrays only" is literally false for the new packet protocol: arithmetic packets require a JSON null tag. Suggested exact correction: "Canonical numerical and formula encodings use integers and arrays; arithmetic instructions additionally use the null command tag." This is a protocol-description correction, not a mathematical defect.
2. In `evidence/inherited_provenance.json`, the two comparator member paths have duplicated archive-root prefixes. The actual ZIP members are:
   - `ipra_local_rewriting_2026-11-10/code/kernel_scalar_boxed.py`;
   - `ipra_guarded_elimination_2026-11-10/code/kernel_tokens.py`.
   The recorded copied-file SHA-256 hashes are correct. Only the stated member paths require correction.

All other inspected provenance hashes match the delivered files. Exact test totals were checked for internal consistency with the generated summary, not rerun as part of this final prose review; root's final test run remains the verification authority.

## Corrections applied after review

Both reporting corrections were applied before the final PDF build: the canonical-tree sentence now distinguishes the null command tag, and the two ZIP member paths no longer repeat the outer archive stem. All inherited source hashes remain unchanged.
