# Audit of the ten current iPRA draft archives

Repository snapshot: `VladimirReshetnikov/ProveIt`, commit `8b2b54e63fb68da9722d1f5d6a7375a7808c8586`.
Runtime for static source measurement: CPython 3.12.14.

## Actual current target

The coordinatewise envelope of complete, documented checker programs is **281 significant normalized Python tokens / 315 whole-module AST nodes / 685 normalized UTF-8 bytes**. Different programs attain these minima. In particular:

| Program | Tokens | AST nodes | Normalized bytes |
| --- | ---: | ---: | ---: |
| generated_assumptions/code/checker.py | 281 | 318 | 685 |
| generated_assumptions/code/checker_ast.py | 283 | 315 | 710 |
| generated_assumptions/code/checker_strict.py | 284 | 321 | 688 |
| guarded_elimination/code/kernel_tokens.py | 281 | 325 | 739 |
| local_rewriting/code/kernel_scalar_boxed.py | 290 | 334 | 685 |
| local_rewriting/code/kernel_balanced.py | 286 | 320 | 736 |

The first program dominates the local-rewriting byte profile in the other two coordinates. The second supplies the AST minimum. A new program must be at most **280 / 314 / 684** to strictly beat all three integer-valued coordinate minima in one source. A single lower coordinate is a limited improvement and must be described that way.

The metric is inherited from the corpus: remove genuine docstrings, apply `ast.unparse`, append one newline, then count significant tokens, all AST nodes, and UTF-8 bytes. Count the **entire module**, including its parser calls and public ACCEPT/REJECT driver. Raw bytes are not a substitute: local_rewriting's 628 raw bytes normalize to 685. Reformatting saves no normalized source.

Several papers compare against the older envelope 287/323/738 or 292/330/762. Those are no longer the current corpus target. Attained corpus minima are upper bounds on an unknown optimum, not mathematical lower bounds for all theories or checkers.

## Coverage

The direct ZIP extraction contains 278 Python source occurrences with 177 distinct SHA-256 hashes. A recursive scan through nested ZIPs finds 432 source occurrences and the same 177 distinct hashes. The ten nested source archives in generated_assumptions contribute no new Python byte string beyond the direct extraction/reference copies.

A deliberately broad initial complete-checker heuristic identified 128 occurrences / 71 distinct byte strings. It is a candidate count, not a claim that all 71 are proved-correct full iPRA checkers. Every source excluded by that heuristic but below any of the three current envelope coordinates was read. Each such source is a build helper, manifest checker, metric utility or test orchestration script, not a standalone theorem checker. Therefore no potential smaller complete source was excluded merely because of its directory or filename.

The complete metrics and source hashes are in `sources/audit_metrics.json`. No upstream checker or verification script was executed in this audit; source measurements are static. Reports and selected source programs were read directly rather than treating their historical tables as current evidence.

## Mechanism comparison

| Draft | Main contribution | Audit consequence |
| --- | --- | --- |
| atomic_transport | Literal-equation-only transport; compound transport and hypothesis use expanded | Mathematical restriction is not the source of its byte saving; unrestricted matched control is smaller. Historical transport predecessor expressly acknowledged. |
| elimination_assumptions | Remove general hypothesis conclusion, use context assumptions only as elimination majors, derive identity structurally | Genuine proof-interface change, but superseded current source sizes. Object Eq/D and internal Q boundaries matter. |
| endpoint_certificates | Submit explicit source, target and motive, share Eq/Q minor-premise computation | Entire new fields are checked; smaller encoding, not a new arithmetic basis. |
| generated_assumptions | Generate numerical equation H(w), with known H(0), as a local assumption and discharge the fresh w; share all continuations | Current principal source leader and AST leader. Neutral elimination defaults require a successfully checked major. |
| guarded_elimination | Unmatched Eq/Q requests retain goal and add truth | Harmless administrative steps are erased in soundness; invalid equality endpoints are never assumed. |
| local_rewriting | Local occurrence replacement plus successor-seeded scalar R; recover a zero seed by transposition, then predecessor | Strongest distinct recent arithmetic route; complete implementation actually accepts proved general transport. Its balanced profile has an explicitly qualified permissive opener. |
| named_specialization | Restrict Q specialization to variables and numeral one, deriving arbitrary specialization | Direct restricted checker is larger; separately optimized general checker sizes cannot be attributed to the restriction. |
| scalar_countdown | Fixed uniqueness rule plus R2 observation sentence recovers induction | Completed theory has claimed full bridge, but its complete checker is much larger. Bare uniqueness alone remains unresolved. |
| shared_continuation | Share elimination continuation and combine existing techniques | Openly a modest implementation synthesis, not a new arithmetic breakthrough. |
| successor_recursion | Counter-aware successor-seeded R; successor abbreviation; direct primitive recursion compiler | Simplifies the arithmetic bootstrap relative to scalar iteration, but source sizes are superseded. |

## Trusted boundary of current leaders

The generated-assumptions principal and AST programs are complete standalone programs importing only Python's standard JSON facilities. Proof-producing code, arithmetic evaluators, source normalizers, reports, and tests are not imported by the checker. Their functions `i` and `c` implement scope/opening and proof checking. The global negative floor allocates fresh names. All meaningful submitted formulas are checked on the route to acceptance. Input is data, not evaluated code.

The 685-byte generated-assumptions source uses a direct list check. The 710-byte AST variant uses `a + []` inside a try block, so non-list JSON objects fall into the scalar check. It does not have local_rewriting's nonempty-string infinite-recursion issue. Local-rewriting's balanced profile directly iterates arbitrary objects and explicitly relies on actual Python recursion limits to reject some malformed nonempty strings; its canonical array/integer proof fragment is structural. This qualification is a reason to prefer the guarded current leader, but it does not alter the numerical envelope.

The principal generated assumption H(w) is intentionally not always a theorem uniformly in w. For example, a raw seed alias can produce `I(0,0;v.0)=w`. Its zero instance is the theorem. The discharge is valid because w is fresh for the old context and goal: substitute zero, then cut H(0). Treating the assumption as universally true would be unsound, but the supplied paper does not do that.

The eager call `i([*n,t,u], d=1)` in its step generator is essential to its current proof. Without it, a non-unary counter and constant update can hide a malformed recursive image and supply a false computation. The paper exhibits precisely this guard-removal counterexample. Any synthesis with another recursor must re-establish this invariant, not just delete the call for source size.

## Mathematical scope and outstanding caution

I read the generated-assumptions complete rule specification, known-instance cut proof, identity-language equivalence proof, raw zero-extension lemma, checker correspondence argument, and its whole-domain interpretation summary; I also read local-rewriting's complete transposition construction and interpretation argument. No concrete soundness counterexample was found in these inspected portions. This is not a complete independent formalization of every inherited scalar predecessor/equality-reflection lemma.

The intended object theory is **full first-order intuitionistic PRA**, with arbitrary quantified intuitionistic formulas and quantifier-free induction, not merely equational PRA. The ordinary intermediate theories explicitly include coverage and the falsity bridge `(0=1) -> bottom`. That bridge must not be omitted: positive equations alone admit a singleton ordinary structure. In the native calculus, designated absurdity is `0=1`, and explosion and coverage are derived.

Bi-interpretability is argued by whole-domain actual-equality interpretations. Equation induction gives uniqueness of each fixed recursive description, so its double translation equals the original operation on all domain elements. Structural formula reconstruction supplies both logical composites. This argument is stronger than merely matching standard-model computable functions. Native Q syntax requires attention: some focused presentations regard Q only as an internal reusable closure rather than a general object goal; their full-sequent equivalence claim is limited accordingly, and their reports say so.

No inspected draft establishes an absolute simplest axiomatization, a universal lower bound for arbitrary proof checkers, or a Lean/Rocq formalization of the full metatheory. Numerical checks and reported assistant reviews are supporting evidence, not universal proofs. A deliverable should keep these distinctions explicit.
