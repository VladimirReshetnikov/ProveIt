# Independent review of the flat computation-supply checker

## Reviewed object and verdict

Reviewed file: `experiments/supply_flat.py`.

SHA-256: `8ac122714ebb0f3351d6eb9a7bf3b97031e2055436ea83b2e20d5c81b80acf06`.

Independently reproduced complete-module CPython 3.12.14 metrics: **278 significant normalized tokens / 314 AST nodes / 679 normalized bytes**. The current ten-draft envelope is **281 / 315 / 685**, so this one program strictly improves every coordinate, by 3 tokens, 1 AST node, and 6 bytes. The byte decrease is approximately 0.876%. This is a small implementation/proof-interface improvement, not an established significant mathematical breakthrough or absolute optimum.

**Verdict:** I find the changed arithmetic generator sound and canonically complete for the inherited native scalar-I theory. The stronger uniform-supply claim is supportable: every successfully generated equation is an ordinary computation theorem uniformly in the newly allocated parameter. A zero-instance discharge remains a valid weaker account. The reasoning below is a written review, not a Lean/Rocq formalization, and assumes the inherited native-calculus/iPRA bridge already established in the included reference sources.

## Precisely what changed

The numerical syntax remains initialized scalar iteration:

- I(0,a;v.r)=a;
- I(Sn,a;v.r)=r[I(n,a;v.r)/v].

It is not the successor-seeded R arithmetic from the local-rewriting draft.

The flat packet is `[m,s,u,t]`. A null major selects arithmetic, with fields directly interpreted as counter, initializer, and update. The constructed local equation is

```python
h = [[s, u, t], i(t, [list(*s), u, t], 1) if s else u]
```

A non-null falsy major selects paired introduction; the last field is its witness and may now be raw zero. Truthy majors retain the inherited checked elimination behavior. The arithmetic branch's final opening image is exactly zero, since `m is None` makes both `m` and `len(a)%2 == m` false. Thus arithmetic executes `i(h,0)` after allocating a fresh name.

Constructing `[s,u,t]` charges source shape in the Python syntax rather than trusting a submitted prebuilt node. The call `list(*s)` is eagerly evaluated as a function argument even when the update ignores the recursive-state image. It therefore retains the key constructor check that unrestricted lazy expansion would lose.

## Arithmetic soundness

Let k be the old parameter floor, let w be the newly allocated negative label k-1, and let H(w) be the equation after the final opening. Existing labels denote arbitrary passive numerical parameters. Use the sorted decoder of the generated-assumptions draft: a unary numerical node is successor with one dummy zero slot; a ternary numerical node is initialized I, whose counter/seed have two dummy zero slots and whose update has two aliases of its scalar state. Binary numerical nodes denote zero, while their annotations are still traversed.

### Zero counter

Successful final traversal forces a falsy counter to decode as zero. The left side is I(0,a;v.r), where a is decoded beneath two additional dummy zero slots. The right side is the same raw initializer opened to zero at numerical root.

These denote the same initializer uniformly in w. Prove this by structural recursion on the initializer: additional outer slots have value zero, while exposed coordinates are also replaced by zero; internal binders retain their nearest-slot meanings. Existing negative labels and the newly allocated w are retained in both copies and can have arbitrary values. Consequently H(w) is I0 for every w.

This is the exact improvement over the older fresh-image supply: there the initializer's exposed coordinate could become w while its source occurrence denoted a dummy zero. Here it becomes literal zero, so no specialization w=0 is needed to identify the two initializers.

### True counter and eager shape guard

For successful final traversal, a truthy counter s must be a list. Other JSON iterables cannot survive numerical traversal. The eager call `list(*s)` forces s to contain exactly one argument and that argument to be iterable. Final traversal rejects strings and dictionaries in numerical positions, so the argument is a list p. Arrays of forbidden arity are rejected when traversed. Therefore the source counter is an actual successor of the decoded p.

The recursive-state image is `[p,u,t]`. There are two exhaustive cases in evaluation of `i(t,image,1)`.

1. **The image is used at least once.** The opening routine itself evaluates `i(image,d=1)` before copying it. This validates the entire predecessor iterator at the old floor k. In particular, all of p,u,t exclude meaningful occurrences of the still-unallocated negative label w and unavailable exposed coordinates. The old source/image correspondence, with the extra successor slot interpreted as zero, therefore applies. The generated equation is IS with the validated predecessor iterator substituted for the update's scalar state.

2. **The image is never used.** Every numerical coordinate traversed in the update is an old allocated rigid parameter or a coordinate internal to the update's own binders. A reference to either outer scalar-state slot, an out-of-scope positive coordinate, or a newly allocated negative label would have taken the substitution branch and used the image. Hence the decoded update is independent of the outer state and of w. The source counter and initializer may still contain w, but IS holds for arbitrary counter/initializer values with this constant-in-state update. The unvalidated recursive image is irrelevant to the equation.

The dichotomy proves H(w) uniformly from a computation instance. It also explains why deleting the older eager validation is safe here but unrestricted `[*s,u,t]` alone would not be: `list(*s)` still proves that the source is a genuine successor even in case 2.

### Discharging the local theorem

The old goal and context exclude the new w by the inherited root validation/fresh-floor invariant. Since H(w) is a theorem uniformly in w, cut eliminates its local assumption. A parameter absent from the conclusion creates no additional assertion. The weaker argument of specializing w=0 and cutting H(0) also works, but is not necessary for this generator.

## Logical branch review

The truthy-major branch is unchanged from the current generated-assumptions leader. It must check the major before attempting transport/Q elimination or defaulting to a neutral continuation. Invalid endpoints are never assumed.

For paired introduction, falsy non-null markers split into the inherited cases: numerical zero, false, and zero float aliases select progress exactly when the opened matrix has even arity; empty lists, strings, or dictionaries select case because they do not equal that numerical parity. Nonzero scalar major claims cannot successfully prove an arbitrary scalar formula. Literal-equation matrices are the only nontrivial progress cases; an empty truth node is harmless. Unary Q and ternary D matrices still receive the case assumption. Thus changing the discriminator does not introduce compound induction.

A witness equal to raw zero is now permitted because null, rather than witness falsiness, determines the arithmetic branch. Zero is an ordinary legal native witness, so this extends certificate convenience without strengthening the theory.

The inherited scalar-goal invariant is preserved: every appended context entry is a list, and a successful leaf is context membership. Scalar requested goals therefore cannot close; their other branches reject or consume another packet without producing finite acceptance. All successful majors consequently have the intended list arities.

## Canonical completeness

The only computation restriction is that a successor predecessor supplied directly to this generator must have a list-shaped encoding. Every numerical term p has a canonical list-shaped box

    B(p) = I(0,p;v.0),

and the base computation proves B(p)=p. The new generator directly supplies the step equation at predecessor B(p):

    I(S B(p),a;v.r) = r[I(B(p),a;v.r)/v].

Transport this equation along B(p)=p, using the formula motive which replaces the two displayed predecessor occurrences and leaves passive parameters fixed. This derives the unrestricted IS instance. I0 instances are direct. Boxing is a finite syntax transformation and uses no total program evaluator, proof oracle, additional axiom, or stronger induction rule.

Replace every old computation leaf by this finite derivation (or direct I0). Re-serialize with the flat null packets, allocate fresh labels at every common continuation, and preserve the inherited checked endpoint/logical packets. Arbitrary numerical witnesses, including zero, are available. Thus every closed theorem of the inherited native scalar-I calculus has a canonical accepted finite certificate under the usual unbounded-resource completeness convention. The identity-language proof equivalence preserves its existing iPRA bi-interpretation.

## Independent finite falsification attempts

The following diagnostics were executed independently of the main producer. They support the written argument but do not prove a universal theorem.

1. A separately written opener and numerical decoder examined 180,000 random arithmetic triples at old floors 0,-1,-3. Leaves included integers, fractional aliases, null, booleans, strings, dictionaries, NaN, positive/negative infinity, and arrays through forbidden arities. There were 32,475 successfully opened equations. All 32,475 had true zero instances; there were zero evaluation-budget skips and zero counterexamples.
2. A separate uniformity run examined 300,000 triples. There were 75,203 successfully opened equations, each checked at fresh-parameter values 1,2,5 with independently varied existing parameters: 225,609 valuation checks, zero skips, and zero counterexamples.
3. The actual reviewed checker functions, run with fresh global state, rejected 9,596 malformed or adversarial packets whose requested closed equations were deliberately false, including 0=1,1=0,2=1,1=2. The corpus included one-step arithmetic packets with malformed counters/seeds/updates, alternate falsy mode tags, and random multi-instruction prefixes. No false-goal acceptance occurred.

The reviewed source hash was rechecked after these runs and was unchanged.

## Qualifications for the final report

- This is the complete 278/314/679 module, not a small fragment with hidden trusted preprocessing.
- The arithmetic and full intuitionistic logical reconstruction are inherited; the new result is a smaller verified proof interface and its boxed/zero-completed supply argument.
- Report the exact current envelope, not the older historical 287/323/738 tables.
- The improvement is modest. Do not call it an absolute simplest axiomatization or a significant breakthrough.
- Distinguish written proof, independent review, and finite diagnostic evidence from proof-assistant verification.
