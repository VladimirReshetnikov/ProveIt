# Independent mathematical review of the scalar-I bridge

## Scope and conclusion

I read all five inherited sources in full:

- `reference/inherited_choice_basis.tex`
- `reference/inherited_ordinary_bridge.tex`
- `reference/scalar_predecessor.tex`
- `reference/equality_reflection.tex`
- `reference/primitive_recursion.tex`

All paths above are relative to `sources/unpacked/ipra_generated_assumptions_2026-11-10/ipra_generated_assumptions_2026-11-10/`.

I found no mathematical gap in the scalar predecessor, actual-equality reflection, or interpretation-composite arguments. The square-pairing section compresses elementary ordered-semiring lemmas into a standard QFI argument; this is an exposition dependency, not an identified false claim. The proofs are written metamathematics, not a Lean/Rocq formalization or independent human review.

The logical bridge is substantially stronger than a consistency comparison: it supplies both full-domain numerical composites and formula composites. The details below isolate the dependency order needed for the new checker. Nothing here makes the new checker implementation sound automatically; its scope decoder, arithmetic packet restriction, and proof translation need their own proof.

## 1. Exact ordinary comparison theory

Let T_I use ordinary intuitionistic first-order logic with actual equality and genuine falsity. Its numerical symbols are staged fixed scalar iterators. For each previously formed fixed template h(u,p), add i_h(n,a,p), with

`i_h(0,a,p)=a`,
`i_h(Sn,a,p)=h(i_h(n,a,p),p)`.

Add contextual induction for literal equations, numerical coverage `x=0 or exists y x=Sy`, and the explicit separation sentence `(0=S0)->false`.

These last hypotheses must not be silently omitted. All positive numerical equations have a singleton model. Native explosion from `0=1` does not by itself prove that ordinary genuine falsity is equivalent to `0=1` without the ordinary separation bridge.

Each iterator description is a fixed finite syntax tree. No numerical variable ranges over updates and no universal total evaluator occurs.

## 2. Native D rules reconstruct the ordinary logical interface

The ordinary meaning of native paired binding is

`D_xy B(x,y) := exists x (B(x,0) -> forall y B(x,y))`.

Case introduction assumes B(t,0) while proving B(t,Sz). Progress introduction assumes E(t,z) while proving E(t,Sz), and is allowed only for a literal equation E. A fresh witness is opened by D elimination, yielding its closure resource `B(a,0)->forall y B(a,y)`. Equality transport and scalar computation have their usual meanings.

### Equation induction and numerical cases

Use an unused existential coordinate u. Progress DI on `D_uy E(y)`, followed by DE and its zero premise, gives contextual equation induction. The case version gives zero/successor cases for every native formula. Neither construction changes passive parameters in an active induction hypothesis.

Reflexivity follows from the computation `r=t`, with `r=I(0,t;u.0)`, used as both premises of equality transport with motive `v=t`. Symmetry, transitivity, and term congruence follow by the ordinary equality motives. Uniform matrix interderivability lifts under D: open the old D at a fresh witness, introduce the new D at the same witness, convert its base to the old base, use the old closure at the successor, and convert back.

### Gates and selectors

Define `C(n,a,b)=I(n,a;u.b)`, so C(0,a,b)=a and C(Sn,a,b)=b.

For every fixed native formula A define its gate by syntax recursion:

`G_v(s=t) := C(v,0,s)=C(v,0,t)`,
`G_v(D_xy B) := D_xy G_v B`.

Freshen bound variables. Then G_0 A is a theorem, G_(Sv) A is interderivable with A, and `A <-> D_uy G_y A` when u,y are unused in A.

For equations define

`M_v(s=t,u=w) := C(v,s,u)=C(v,t,w)`.

Align paired binders on compound inputs. Recurse pointwise when both inputs have D roots; when only one does, replace the atomic other input by its zero-gated padding. Each recursive call decreases the maximum binder depth. The result has endpoint equivalences `M_0(A,B)<->A` and `M_(Sv)(A,B)<->B`.

Put `delta(v)=C(v,1,0)` and `r(z)=I(z,0;u.delta(u))`. Only r(1)=1 and r(2)=0 are needed. The following macros provide all logical connectives and quantifiers:

- `A ->* B := D_uz M_z(A,B)`.
- `A and* B := D_uz G_z M_(r(z))(A,B)`.
- `exists* x A(x) := D_xy G_y A(x)`.
- `A or* B := exists* x M_x(A,B)`.
- `forall* x A(x) := A(0) and* D_uz G_z A(z)`.
- `false* := 0=1`.

The unused u and all gate/control binders are fresh. Implication and existential rules follow immediately from their zero/successor endpoints. Conjunction projections use closure instances 1 and 2; its introduction uses numerical cases on the selector. Disjunction elimination uses numerical cases on `M_z(A,B)->*F`, then existential elimination. Numerical coverage is derived by cases on `(x=0) or* exists* y (x=Sy)`. Universal elimination must use this equality-based coverage when the target appears in the retained context; silently substituting into that retained context would be invalid. The sources handle this correctly.

Under 0=1, transport between C(0,s,t)=s and C(1,s,t)=t proves every equation. Structural induction on formulas using case DI then proves every native formula. This gives ex falso, without excluded middle for quantified formulas.

### The nontrivial formula round trip

Internally,

`D_xy B <-> exists* x (B(x,0) ->* forall* y B(x,y))`.

Forward: open D at fresh a, use its closure under the temporary base to introduce the universal, implication and existential. Reverse: open the translated existential at fresh a and use its implication/universal at Sz to discharge case DI with witness a. Together with the endpoint arguments for the macros, structural induction on formulas proves both formula composites. The domain remains the full numerical domain and equality remains actual equality.

## 3. Scalar I produces predecessor before pairing

This is the delicate part: the update has no hidden recursion counter. The following construction uses only 0,S,I, equation induction, and the numerical cases already reconstructed.

Let addition be `a+b=I(b,a;u.Su)`. Prove its commutative-monoid identities by equation induction. Set

`Z(n)=C(n,1,0)`,
`N(n)=I(n,0;u.Z(u))`,
`j(u)=Z(u)+2N(u)`,
`M(n)=I(n,0;u.j(u))`,
`G(n)=I(n,0;u.u+M(u)+1)`.

Numerical cases, not disjunction induction, show N(n) is 0 or 1: its zero value is 0 and its successor value is a value of Z. Equation inductions prove

`N(2n)=0`, `N(2n+1)=1`, `N(3n)=N(n)`,
`M(G(n))=N(n)`, `G(n+2)=G(n)+3`,
`G(2n)=3n`, `G(3n)=3G(n)+N(n)`.

The last step uses the Boolean cases for N(n), with the induction variable and parameters fixed. The finite computations j(0)=1, j(1)=2, j(2)=0 are sufficient; no remainder or division theorem is assumed.

Define `H(u)=C(N(u),G(u),u)`. Then

`H(2u)=3u`, `H(1)=1`, `H(3u)=3H(u)`.

For every fixed template h, equation induction gives iterator rotation `I(Sy,a;h)=I(y,h(a);h)`. With H it also gives `I(y,3a;H)=3I(y,a;H)` and `I(y,1;H)=1`.

Now let

`E(x)=I(x,1;u.2u)`,
`L(x,y)=N(I(y,E(x);H))`.

The three internally proved equations are

`L(0,y)=1`, `L(Sx,0)=0`, `L(Sx,Sy)=L(x,y)`.

The last equation follows by rotation, H(2u)=3u, iterator scaling by 3, and N(3u)=N(u). All are whole-domain identities.

Set

`B_m(u)=C(L(Su,m),u,Su)`,
`W(t,m)=I(t,0;u.B_m(u))`.

Selector cases give `B_(Sm)(Su)=S(B_m(u))` and `B_(Sm)(0)=1`. Equation induction on t with m fixed gives `W(St,Sm)=S(W(t,m))`. Separate equation inductions yield `L(Sn,n)=0` and `W(n,n)=n`; thus `W(Sn,n)=n`. The diagonal substitutions are made into the already proved universally parameterized shift law, never into an active induction hypothesis with a changed parameter.

Finally define

`P(m)=I(m,0;u.C(L(SSu,m),u,Su))`.

P(0)=0 is computation. For m replaced by Sm, its update is pointwise B_m by the comparator recurrence. An equation induction comparing the two fixed iterators gives `P(Sm)=W(Sm,m)=m`. This supplies a genuine predecessor term on every element of the original domain, not only on standard numerals.

## 4. Actual equality reflection, then QFI

From P derive successor injectivity. Define `sg(u)=C(u,0,1)` and `K(u)=C(u,1,P(u))`. Coverage and separation show

`sg(u)=0 <-> u=0`, `K(u)=0 <-> u=1`.

Let truncated subtraction be `d(x,y)=I(y,x;u.P(u))`. Equation induction proves successor cancellation, `d(Sx,Sy)=d(x,y)`, and `d(Sa,a)=1`.

The critical equation invariant is

`C(sg(d(x,y)), x, y+d(x,y))=x`.

Induct on y with x fixed. If the new residual is zero, the selector yields x. Otherwise coverage says the old residual is the successor of the new residual; the induction equation reconstructs x as y plus the old residual, and elementary addition shifts one successor to y. No implication or disjunction is used as the induction matrix.

Consequently `d(Sa,b)=1 <-> a=b`. The forward implication reconstructs `b+1=Sa` and applies P; the converse uses the diagonal identity. Define

`e(a,b)=sg(K(d(Sa,b)))`.

Then `e(a,b)=0 <-> a=b`, and e is Boolean, throughout the whole domain. Decidable equality follows; it was not assumed.

For every fixed quantifier-free formula A, recursively build b_A with 0 meaning true:

- `b_(s=t)=e(s,t)` and `b_false=1`.
- `b_(A and B)=C(b_A,b_B,1)`.
- `b_(A or B)=C(b_A,0,b_B)`.
- `b_(A -> B)=C(b_A,b_B,0)`.

Finite Boolean cases prove `b_A=0 <-> A` intuitionistically. Apply equation induction to `b_A(n)=0` to obtain all contextual QFI. Arbitrary quantified retained contexts are allowed; only the induction matrix is restricted. This order avoids using QFI, equality decidability, or pairing in the predecessor construction.

## 5. Pairing and every fixed primitive recursion

With QFI established, define multiplication by scalar iteration. Elementary discrete linear-order and semiring laws follow by QFI from addition and monus; they need to be listed or cited as an inherited lemma if the final report does not reproduce them.

For fixed n put

`U_n(v)=C(d((Sv)^2,n),Sv,v)`,
`R_n(i)=I(i,0;v.U_n(v))`, `q(n)=R_n(n)`.

QFI simultaneously establishes the three quantifier-free invariants

`R_n(i)<=i`, `R_n(i)^2<=n`, and `R_n(i)=i or n<(S(R_n(i)))^2`.

At i=n this gives `q(n)^2<=n<(q(n)+1)^2`; monotonicity of squares gives uniqueness. Thus for

`pi(a,b)=(a+b)^2+a`,
`lo(n)=d(n,q(n)^2)`, `hi(n)=d(q(n),lo(n))`,

one has `lo(pi(a,b))=a`, `hi(pi(a,b))=b` internally. Pairing need not be surjective. No domain restriction to paired values is made.

To compile `f(0,p)=g(p)`, `f(Sn,p)=h(n,f(n,p),p)`, assume g,h have already been translated and set

`V(n,p)=I(n,pi(0,g*(p));u.pi(S(lo(u)),h*(lo(u),hi(u),p)))`,
`f*(n,p)=hi(V(n,p))`.

Equation induction gives lo(V(n,p))=n. The projection identities then give both target recursion equations. This is external recursion on each finite PR description; the numerical domain contains no universal program evaluator.

## 6. Why the interpretations are genuinely bi-interpretations

In iPRA, interpret each scalar iterator by ordinary primitive recursion ignoring its counter in the update. In T_I, interpret every fixed PR symbol by the scalar compiler. Both use the full domain x=x and actual equality.

For two fixed iterators with the same seed and pointwise equal updates, literal-equation induction comparing their values proves equality at every internal counter. The corresponding uniqueness proof works for counter-aware primitive recursion. External induction on finite descriptions therefore proves that each double-translated operation equals the original operation internally. This also supplies the required coherence when numerical substitution changes the staged syntactic description of an update.

The graph x=y is internally total and bijective and preserves every interpreted numerical operation. Section 2 supplies the formula composites and the explicit separation bridge preserves falsity. This proves full-domain bi-interpretability and effective mutual proof translations, hence equiconsistency. It is not a statement that either theory proves its own consistency.

## Exact qualifications for the final report

1. Keep the ordinary separation sentence explicit.
2. Keep progress DI restricted to literal equations. Compound progress would supply stronger induction.
3. Do not replace the scalar predecessor proof with a claim that scalar iteration obviously simulates counter-aware primitive recursion; that would be circular without pairing.
4. Do not derive equality reflection merely from the standard meaning of L or a Boolean-looking evaluator.
5. Keep passive parameters fixed inside every induction. The predecessor proof does this correctly.
6. Describe raw Q goals separately if the implementation accepts them: Q has the definitional ordinary meaning `B(0)->forall y B(y)` and corresponds to an unused-witness D. For an Eq/D-only mathematical object language, Q is an internal resource, not an additional ordinary object theorem. Either presentation is sound, but the public acceptance claim should say which decoding is used.
7. Present this material as inherited, verified written argument, and attribute the archive members. It is not a new contribution of the flat-packet checker.
