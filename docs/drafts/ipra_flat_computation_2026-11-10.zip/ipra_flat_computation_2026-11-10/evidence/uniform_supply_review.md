# Independent review of flat computation supply

## Reviewed program

`experiments/supply_flat.py` uses the following packet protocol:

* A truthy `m` is an elimination-major packet `[m,s,u,t]` with the inherited meanings.
* Exactly `m=null` is a numerical supply packet `[null,n,a,h]`. The source iterator is constructed directly from those three fields.
* Every other false marker selects paired introduction. Canonical marker `0` permits atomic progress; canonical marker `[]` selects the case mode. The witness is `t` and may now be literal zero.

The tag test is independent of witness truthiness. This removes the old need for a truthy zero box in paired introduction.

Full normalized source metrics are 278 significant tokens, 314 AST nodes, and 679 UTF-8 bytes. The actual source hash and executable protocol receipts are recorded in `flat_protocol_checks.json`.

## Scope and raw input review

At entry to every checker call, `i(a)` validates the meaningful parameters of the goal before new name allocation. Context membership can only finish at a previously opened list formula. A fresh negative coordinate therefore cannot occur meaningfully in the old retained goal or context. Inert annotation positions do not become meaningful in any rule.

For null arithmetic, the final expression

    k if m or len(a)%2 == m else 0

always selects zero: `m` is `None`, and integer parity is never `None`. The whole generated equation is therefore zero-opened at the new floor. Raw negative labels newly admitted by that floor may denote the new parameter w; the following theorem permits them uniformly.

## Uniform computation-supply theorem

Every arithmetic packet that survives its generator and final opening produces a decoded equation H(w) that is an instance of a numerical computation theorem for every fresh parameter w. The claim is stronger than merely proving H(0). No zero-instance discharge principle is needed for this profile.

### Zero-completed decoding lemma

Give available negative rigid coordinates arbitrary numerical values; assign protected positive coordinates to their numerical environment, and assign exposed positive coordinates zero. Interpret raw numerical arrays as follows: empty means zero, unary means successor with an extra dummy zero coordinate, binary means zero with checked inert annotations, and ternary means initialized scalar iteration with two dummy zero coordinates in its counter and initializer and two copies of its state in the update.

Adding any number of outer zero coordinates leaves this zero-completed decoding unchanged. Proof is structural induction on the raw numerical tree. At a coordinate, an added zero is indistinguishable from the previous exposed zero. Successor adds the same inner dummy coordinate on both sides. A binary term remains zero. For an iterator, add identical dummy coordinates or identical duplicated state coordinates on both sides and apply the induction hypotheses, keeping its state symbolic. Negative rigid coordinates, including w, are unchanged throughout.

The final arithmetic opening with image zero implements this decoding at the newly allocated floor. Finite fractional aliases denote their integer-floor coordinates. Out-of-range infinities and NaN are replaced by zero when they occur at an exposed numerical position. Other nonnumerical JSON values either fail opening or occur only in semantically inert positions; acceptance never creates an extra arithmetic operation.

### Zero-counter case

A successful false counter denotes numerical zero. The source initializer is decoded beneath two extra dummy zero coordinates; its copied right side is decoded without those extra coordinates. The preceding lemma identifies them for arbitrary w. The generated equation is therefore I(0,a;v.h)=a. Newly admitted negative rigid coordinates in the initializer are retained consistently on both sides. No specialization w=0 is required.

### Successor constructor guard

For a true counter n, `list(*n)` is evaluated before the update is opened. Successful evaluation together with final numerical traversal forces n=[p], with p a list of permitted arity. A non-singleton n raises an argument-count error even if the update ignores its state. A scalar predecessor cannot be passed to `list`; nonnumerical iterable predecessors fail the final numerical traversal. Consequently the decoded source counter is a genuine successor S(P).

### Successor case when the image is used

If the update-opening operation substitutes its recursive-state image at any meaningful occurrence, the opener calls `i(image,d=1)` at the OLD name floor before copying that image. Successful checking therefore validates the entire predecessor iterator, including its predecessor, initializer, and update, without the newly allocated parameter. In particular none of those components can have a meaningful excess outer slot or fresh negative name w.

The usual opening-substitution lemma now identifies the computed right side with h[I(P,a;v.h)/v]. The extra dummy zero introduced by the source successor changes no decoded term by the zero-completion lemma. Thus the resulting equation is IS at arbitrary domain arguments.

### Successor case when the image is unused

If the image is never substituted, every meaningful numerical coordinate in the update is an old rigid parameter or is bound internally to that update. A meaningful occurrence of the outer scalar state, an excess outer coordinate, or the newly allocated negative name w would have triggered image substitution. Coordinates inside binary-node annotations are irrelevant because those numerical nodes denote zero.

The decoded update is therefore independent of the outer recursion state and w. It has the same value in the source recursor and the computed right side. Apply IS to the genuine successor source counter; its predecessor and initializer can be arbitrary and can contain w. Their values are irrelevant because the update is constant in the recursion state. Again the equation holds for all w.

These arguments use only the computation equations and finite syntactic substitution. They do not assume that arbitrary domain elements are standard numerals.

## Consequence for the mathematical presentation

The supply inference can be stated as ordinary computation-assumption introduction followed by cut:

    Γ,H ⊢ A  implies  Γ ⊢ A,

where H is generated as a computation theorem. Any fresh parameter appearing only in H is eliminated by ordinary numerical substitution after cutting, or by universal generality of the computation theorem. It is unnecessary to include a special rule whose admissibility depends only on H(0).

## Canonical completeness

The new primitive successor generator accepts list-shaped predecessors. For any omitted predecessor term p, let B(p)=I(0,p;v.0). The base computation proves B(p)=p. Use the allowed successor computation at the composite predecessor B(p), and transport along that equality. This is a finite proof expansion in the existing scalar theory.

Every canonical paired-introduction witness, including literal zero, is now admitted by its own tag. The case/progress distinction remains intact. Eq/Q elimination, paired elimination, hypothesis closure, and the inherited fresh-name allocation are unchanged. Producers must emit arithmetic packets `[null,n,a,h]` and reserialize all allocation-dependent labels; copying old packets without translation is not claimed to work.

## Diagnostic evidence

* 600,000 attempted raw source triples; 383,027 surviving generated equations evaluated at fresh w=0; no counterexamples.
* 300,000 further attempted triples; 191,847 surviving equations evaluated with fresh w drawn from 0,1,2,5,11; no counterexamples.
* Protocol tests exercise both zero-witness DI modes, zero and successor computation, actual state use, malformed binary/ternary counters with ignored state, rejected scalar predecessors, and supplied fresh negative parameters.

The draft-audit agent independently challenged the uniform theorem with a different malformed corpus and reported no objection or counterexample. None of these finite checks is a proof-assistant verification.
