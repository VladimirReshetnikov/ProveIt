FLAT COMPUTATION FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
================================================================
Research prepared for Vladimir Reshetnikov, 10 November 2026.

RESULT AND LIMIT
----------------
The complete standalone checker has 278 normalized Python tokens,
314 AST nodes, and 679 normalized bytes. The current ten-draft coordinate
envelope is 281 / 315 / 685. This single program is strictly smaller in
every coordinate. The gain is modest: 3 tokens, 1 AST node, and 6 bytes.
An absolute minimum or a significant architectural breakthrough has not
been established.

The native calculus is equiconsistent and fully bi-interpretable with
first-order intuitionistic PRA. Both interpretations use the whole
numerical domain and actual equality; their composites are internally
isomorphic via x=y. These are written mathematical proofs, not Lean or
Rocq formalizations. The arithmetic and logical reconstruction is inherited
from the supplied drafts and reproduced with attribution in the report.

THE NEW STEP
------------
Only boxed predecessors need to be checked directly. For every term p,

    B(p) = I(0,p;v.0) = p.

Compute at B(p), then transport along B(p)=p to recover computation at p.
The constructor check remains eager, while the recursive image is validated
only when the update uses it. Arithmetic packets [null,n,a,h] construct
the computation source directly and always open supplied equations with
zero. The generated equations are ordinary computation theorems uniformly
in admitted fresh parameters, so the older known-zero-witness discharge
is unnecessary. The separate null tag also allows literal zero as a DI
witness without a truthy-zero encoding.

OPEN FIRST
----------
ipra_flat_computation.pdf   Complete research report and inherited proofs.
ipra_flat_computation.tex   Standalone source; compiles without other files.
code/checker.py            Entire measured trusted checker, exactly 679 bytes.
code/readable_checker.py   Separately executable readable expansion.
code/FORMAT.txt            Input format, rules, scope, and examples.
verify.py                  Offline measurements and execution checks.
tests/producer.py          Untrusted named derivations and box expansion.
tests/fixtures/            Individually executable proof/rejection packets.
reference/                Frozen comparators, inherited TeX, measurer, license.
evidence/                 Measurements, receipts, reviews, source identities.

REPRODUCE
---------
From this directory, with Python 3:

    python3 verify.py
    python3 code/checker.py < tests/fixtures/I0_arbitrary_seed.json

The verifier regenerates 31 cases from named derivations and explicit
negative controls, runs both complete checkers normally and with -O,
and checks 3 targeted unsound guard-removal controls. The ordinary suite
contains 124 full-process expectation checks. The checker prints ACCEPT
with zero exit status or REJECT with nonzero status; rejected runs may
also print a traceback on stderr. An unread certificate prefix is inert.

Optional independent numerical diagnostics:

    python3 tests/falsify_flat.py
    python3 tests/falsify_flat_general.py

These search for counterexamples to the uniform-supply lemma. They are
not imported by the checker and are not proofs of universal soundness.

To rebuild the standalone TeX and PDF with installed PDFLaTeX:

    python3 build.py

No network or shell escape is used by the checker, normal verification,
or report build. The modular editing sources are report.tex and theory/.

To fetch and re-audit the exact ten original source archives:

    python3 audit_corpus.py

This optional networked audit checks byte lengths, Git blob identities,
and all 432 Python source occurrences including embedded archives, without
executing downloaded programs. The classification of complete checkers
is the documented manual audit, keyed to immutable source hashes. Frozen
leading checkers suffice to reproduce the ordinary offline comparison.

To rebuild checksums and the ZIP after intentional edits:

    python3 package.py

MATHEMATICAL SCOPE
------------------
Terms are variables, 0, S, and initialized scalar iteration I. Formulas are
equations and the binders Q_y A and D_xy A. The report explicitly lists
Hyp, equality transport, Q elimination, D elimination, both D introduction
modes, and computation supply. Progress is restricted to literal equations.
All ordinary intuitionistic logical operations are reconstructed.
Ordinary separation (0=S0)->false is explicit in the comparison theory.
No classical collapse, restriction to standard numerals, hidden evaluator,
or induction on arbitrary quantified matrices is used.

The failed attempt to remove atomic-case introduction is recorded with a
counterinterpretation. It is not used in the delivered checker. No known
unsound experimental checker is included as a candidate.

PROVENANCE
----------
Repository: VladimirReshetnikov/ProveIt
Commit: 8b2b54e63fb68da9722d1f5d6a7375a7808c8586
Directory: docs/drafts
All 10 current ZIPs were retrieved and verified. There are 278 directly
extracted Python occurrences, 432 including historical nested ZIPs, and
177 distinct Python source hashes. See evidence/corpus_audit.md.

Inherited sources retain the repository's MIT No Attribution license at
reference/LICENSE.txt. Exact source-member hashes and new adaptations are
identified in evidence/inherited_provenance.json and tests/producer_review.txt.
No repository mutation or publication is part of this deliverable.
