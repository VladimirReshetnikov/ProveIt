"""Deterministic targeted cases for the changed certificate constructors.

The five positive numerical schema expectations below come from the frozen
predecessor implementation. The separate named_audit.py constructs schema
expectations independently in named syntax.
"""


def cases(source):
    truth = ["=", -1, -1]
    false = ["false"]
    quantified = ["pi", ["=", 0, 1], ["ex", ["=", 0, 2]]]
    checks = [
        ("index_zero", [[truth], truth, 0], True),
        ("index_negative", [[truth], truth, -1], True),
        ("index_last", [[truth, false], false, 1], True),
        ("reject_boolean_leaf", [[truth], truth, False], False),
        ("reject_float_leaf", [[truth], truth, 0.0], False),
        ("reject_missing_assumption", [[], truth, 0], False),
        ("reject_out_of_range_index", [[truth], truth, 1], False),
        ("reject_negative_out_of_range_index", [[truth], truth, -2], False),
        ("reject_wrong_goal_index", [[truth], false, 0], False),
        ("reject_formula_hypothesis_record", [[truth], truth, ["hyp", truth]], False),
        ("reject_ignored_pi_witness_sort", [[["pi", truth, truth]], truth,
                                           ["use", 0, truth, 0]], False),
        ("reject_ignored_pack_witness_sort", [[], ["ex", ["=", 0, 0]],
                                             ["pack", truth, 0]], False),
        ("reject_rec_nonconstructor", [[], truth, ["r", 0, -1, 0]], False),
        ("reject_boolean_term", [[], truth, ["r", False, -1, 0]], False),
        ("reject_partial_nat_matrix", [[], truth, ["nat", ["pi", truth]]], False),
        ("reject_pi_capture_indexed", [[["=", 0, -1]],
              ["pi", truth, ["=", 0, -1]], ["pi", truth, 0]], False),
        ("reject_ex_escape_indexed", [[["ex", ["=", 0, -1]]],
              ["=", 0, -1], ["use", 0, ["=", 0, -1], -1]], False),
        ("reject_pack_missing_lift_indexed", [[], ["ex", ["=", 0, 0]],
                                              ["pack", 0, -1]], False),
    ]
    for matrix in (truth, false, quantified, ["=", 0, 1],
                   ["pi", false, ["ex", false]]):
        expected = source.infer(["nat", matrix], [])
        checks.append(("nat_matrix_" + str(len(checks)),
                       [[], expected, ["nat", matrix]], True))
    for bad in (-1, 0, True, ["s", -1], ["pi", truth], ["=", True, -1]):
        checks.append(("reject_ex_template_sort_" + str(len(checks)),
                       [[["ex", truth]], truth, ["use", 0, bad, -1]], False))
    matrix = ["ex", ["=", 1, -1]]
    base = source.subst(matrix, [-1, 0])
    wrong_step = ["pi", matrix, source.subst(matrix, [["s", 0], 0])]
    wrong_induction = ["pi", base, ["pi", source.subst(wrong_step, (2,)),
                                    source.subst(matrix)]]
    checks.append(("reject_quantified_induction_indexed",
                   [[], wrong_induction, ["nat", matrix]], False))
    return checks
