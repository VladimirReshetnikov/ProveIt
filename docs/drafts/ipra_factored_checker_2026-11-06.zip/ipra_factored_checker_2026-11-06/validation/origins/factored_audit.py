"""Independent targeted audit of the four newly factored checker paths.

Expected numerical schemas are assembled with named binders and only then
encoded to de Bruijn notation. They do not use the checker's substitution.
"""

import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "checker_work" / "checker.py"
spec = importlib.util.spec_from_file_location("candidate", SOURCE)
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)
results = []


def variable(name):
    return ("v", name)


def replace(a, name, term):
    if a[0] == "v":
        return term if a[1] == name else a
    if a[0] in ("zero", "false"):
        return a
    if a[0] == "r":
        _, n, b, u, k, h = a
        return ("r", replace(n, name, term), replace(b, name, term), u, k,
                h if name in (u, k) else replace(h, name, term))
    if a[0] in ("pi", "ex"):
        return (a[0], a[1], *(a[2:] if a[1] == name else
                              (replace(t, name, term) for t in a[2:])))
    return (a[0], *(replace(t, name, term) for t in a[1:]))


def encode(a, free, bound=(), canonical=False):
    tag = a[0]
    if tag == "v":
        return bound.index(a[1]) if a[1] in bound else len(bound) + free.index(a[1])
    if tag == "zero":
        return -1
    if tag == "false":
        return ["=", -1, ["s", -1]] if canonical else ["false"]
    if tag == "r":
        _, n, b, u, k, h = a
        return ["r", encode(n, free, bound, canonical),
                encode(b, free, bound, canonical),
                encode(h, free, (u, k) + bound, canonical)]
    if tag in ("pi", "ex"):
        return [tag, *(encode(t, free, (a[1],) + bound, canonical) for t in a[2:])]
    return [tag, *(encode(t, free, bound, canonical) for t in a[1:])]


def expected_nat(p):
    base = replace(p, "x", ("zero",))
    h = replace(p, "x", variable("n")) if p[0] == "=" else base
    step = ("pi", "n", h, replace(p, "x", ("s", variable("n"))))
    return ("pi", "counter", base,
            ("pi", "unused", step, replace(p, "x", variable("counter"))))


def accepts(data):
    try:
        return kernel.check(data) is True
    except (ValueError, TypeError, KeyError, IndexError, RecursionError):
        return False


def record(name, data, expected):
    actual = accepts(data)
    results.append({"name": name, "expected": expected, "actual": actual,
                    "pass": actual == expected})


x, a, b, w = map(variable, ("x", "a", "b", "w"))
zero = ("zero",)
eq = ("=", x, a)
rec = ("r", x, a, "u", "k",
       ("r", variable("k"), variable("u"), "U", "K",
        ("s", variable("U"))))
templates = [
    eq,
    ("false",),
    ("pi", "w", ("=", w, x), ("=", x, a)),
    ("ex", "w", ("=", w, x)),
    ("=", rec, b),
    ("pi", "w", ("false",), ("ex", "q", ("=", variable("q"), x))),
    ("=", a, b),
]
for i, p in enumerate(templates):
    source = encode(p, ("x", "a", "b"))
    goal = encode(expected_nat(p), ("a", "b"), canonical=True)
    record("named_N_template_%d" % i, [[], goal, ["nat", source]], True)

top = ["=", -1, -1]
for index in (0, -1):
    record("hyp_index_%s" % index, [[top], top, index], True)
for index in (1, -2, False, True, 0.0, None, "0"):
    record("reject_hyp_%r" % index, [[top], top, index], False)

r0 = ["r", -1, 2, ["s", 0]]
record("direct_rec_zero", [[], ["=", r0, 2], r0], True)
h = ["r", 1, 0, ["s", 0]]
rs = ["r", ["s", 0], 1, h]
expected_rhs = ["r", 0, ["r", 0, 1, h], ["s", 0]]
record("direct_rec_nested_successor", [[], ["=", rs, expected_rhs], rs], True)
for i, bad_body in enumerate((True, 0.0, ["false"], ["s"], ["=", -1, -1])):
    bad = ["r", -1, -1, bad_body]
    record("reject_unused_rec_body_%d" % i, [[], top, bad], False)

g = [["=", 0, 1], ["=", 0, 0]]
record("shared_equality_elimination", [g, ["=", 1, 1],
       ["use", 0, ["=", 0, 0], 1]], True)
guard = ["=", 0, 0]
pi = ["pi", guard, guard]
record("shared_pi_introduction", [[], pi, ["pi", guard, -1]], True)
one = ["s", -1]
one_reflexive = ["=", one, one]
record("shared_pi_elimination", [[pi, one_reflexive], one_reflexive,
       ["use", 0, one, 1]], True)
record("shared_pack_introduction", [[], ["ex", ["=", 0, 1]],
       ["pack", 0, -1]], True)
g = [["ex", ["=", 0, -1]], top]
record("shared_ex_elimination", [g, top, ["use", 0, top, 1]], True)
record("reject_escaping_ex_witness", [g, ["=", 0, -1],
       ["use", 0, ["=", 0, -1], -1]], False)

report = {
    "source": str(SOURCE),
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "tests": len(results),
    "passed": sum(r["pass"] for r in results),
    "results": results,
}
out = Path(__file__).with_name("new_checker_audit_results.json")
out.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "results"}, indent=2))
for r in results:
    if not r["pass"]:
        print("FAIL", r)
raise SystemExit(0 if all(r["pass"] for r in results) else 1)
