"""Verify provenance, reproduce proof transports, and replay 184 certificates.

Run from any directory. This program reads frozen fixtures and never changes
them. Its imported predecessor checker is used only as a validation reference;
the candidate accepts every certificate independently in a fresh process.
"""

import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

from targeted import cases
from transport import backward, forward

ROOT = Path(__file__).resolve().parent
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def encode(data):
    return (json.dumps(data, separators=(",", ":")) + "\n").encode()


def load_checker(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepts(checker, data):
    try:
        return checker.check(data) is True
    except ERRORS:
        return False


def canonical_sequent(data, source):
    g, a, _ = data
    return [[source.subst(b, (0,), formula=True) for b in g],
            source.subst(a, (0,), formula=True)]


def verify_member(path, record):
    raw = path.read_bytes()
    require(len(raw) == record["bytes"] and digest(raw) == record["sha256"],
            "Source hash or byte-count mismatch: " + str(path))


def run(checker_path):
    provenance = read_json(ROOT / "source_provenance.json")
    for record in provenance["copied_members"]:
        verify_member(ROOT / record["local_path"], record)
    source_path = (ROOT / provenance["source_checker"]["local_path"]).resolve()
    verify_member(source_path, provenance["source_checker"])
    source = load_checker(source_path, "frozen_source_checker")
    candidate = load_checker(checker_path, "candidate_checker")
    manifest = read_json(ROOT / "manifest.json")
    records = manifest["certificates"]
    by_name = {row["name"]: row for row in records}
    require(len(by_name) == len(records) == 184, "Incorrect frozen fixture inventory")
    require(sum(row["accepted"] for row in records) == 124,
            "Incorrect positive fixture count")
    require(all(type(row["accepted"]) is bool for row in records),
            "Acceptance labels must be Boolean")
    for record in records:
        verify_member(ROOT / record["file"], record)

    source_manifest = read_json(ROOT / "source/fixtures/manifest.json")
    excluded = []
    transported = 0
    source_positive = 0
    for row in source_manifest["certificates"]:
        data = read_json(ROOT / "source/fixtures" / row["file"])
        require(accepts(source, data) == row["accepted"],
                "Predecessor label mismatch: " + row["name"])
        source_positive += row["accepted"]
        try:
            new_data = forward(data, source)
        except ERRORS as error:
            require(not row["accepted"], "Positive source transport failed")
            excluded.append({"name": row["name"], "exception": type(error).__name__})
            continue
        record = by_name[row["name"]]
        require(record["origin"] == "transported", "Wrong fixture provenance")
        require(record["accepted"] == row["accepted"], "Changed predecessor label")
        require(record["source_sha256"] == row["sha256"], "Changed source identity")
        require(encode(new_data) == (ROOT / record["file"]).read_bytes(),
                "Transport changed frozen candidate bytes: " + row["name"])
        if row["accepted"]:
            require(canonical_sequent(data, source) == canonical_sequent(new_data, source),
                    "Transport changed the stated sequent")
        transported += 1
    expected_excluded = [{"name": row["name"], "exception": row["exception"]}
                         for row in manifest["source_excluded_negative"]]
    require(excluded == expected_excluded, "Changed excluded-negative inventory")
    require(len(excluded) == 23 and transported == 154 and source_positive == 116,
            "Incorrect transport totals")

    targeted = cases(source)
    require(len(targeted) == 30, "Incorrect targeted fixture count")
    for name, data, wanted in targeted:
        record = by_name[name]
        require(record["origin"] == "targeted" and record["accepted"] is wanted,
                "Targeted label mismatch: " + name)
        require(encode(data) == (ROOT / record["file"]).read_bytes(),
                "Targeted fixture changed: " + name)

    results = []
    backward_count = 0
    cli_count = 0
    for record in records:
        data = read_json(ROOT / record["file"])
        require(accepts(candidate, data) == record["accepted"],
                "Candidate result mismatch: " + record["name"])
        if record["accepted"]:
            old_data = backward(data, source)
            require(accepts(source, old_data), "Backward transport rejected")
            new_data = forward(old_data, source)
            require(accepts(candidate, new_data), "Forward round-trip rejected")
            require(canonical_sequent(data, source) == canonical_sequent(old_data, source)
                    == canonical_sequent(new_data, source), "Round-trip changed the sequent")
            backward_count += 1
        for optimized in (False, True):
            command = [sys.executable, *(["-O"] if optimized else []),
                       str(checker_path), str(ROOT / record["file"])]
            process = subprocess.run(command, capture_output=True, text=True, timeout=30)
            expected = (0, "ACCEPT\n") if record["accepted"] else (1, "REJECT\n")
            require((process.returncode, process.stdout) == expected and not process.stderr,
                    "CLI mismatch: " + record["name"] + "; optimized=" + str(optimized))
            cli_count += 1
        results.append({"name": record["name"], "expected_accept": record["accepted"],
                        "status": "PASS"})
    return {
        "status": "PASS",
        "python_version": platform.python_version(),
        "checker_sha256": digest(checker_path.read_bytes()),
        "source_checker_sha256": provenance["source_checker"]["sha256"],
        "source_archive_sha256": provenance["archive_sha256"],
        "source_members_verified": len(provenance["copied_members"]),
        "source_certificates_checked": len(source_manifest["certificates"]),
        "source_positive_certificates_transported": source_positive,
        "source_certificates_transported": transported,
        "source_negative_certificates_excluded": excluded,
        "targeted_certificates": len(targeted),
        "certificate_checks": len(results),
        "accepted": sum(row["accepted"] for row in records),
        "rejected": sum(not row["accepted"] for row in records),
        "positive_backward_and_roundtrip_checks": backward_count,
        "cli_checks": cli_count,
        "cli_modes": ["normal", "python -O"],
        "results": results,
        "scope": "Finite regression evidence with unchanged predecessor labels and verified "
                 "proof transports. Excluded malformed predecessor negatives are reported "
                 "and are not counted as candidate rejections. This is not a formal "
                 "verification of the kernel metatheory."
    }



def run_audits(checker_path):
    # Verify the inherited named oracle itself was not altered by adaptation.
    original = ast.parse((ROOT / "source/audit_candidate.py").read_text())
    adapted = ast.parse((ROOT / "named_audit.py").read_text())
    original_functions = {node.name: node for node in original.body
                          if isinstance(node, ast.FunctionDef)}
    adapted_functions = {node.name: node for node in adapted.body
                         if isinstance(node, ast.FunctionDef)}
    unchanged = ["canonical", "formed", "decode", "encode", "named_replace",
                 "oracle_subst", "sh", "ins", "expected_nat", "corpus"]
    for name in unchanged:
        require(ast.dump(original_functions[name]) == ast.dump(adapted_functions[name]),
                "Inherited independent oracle changed: " + name)
    for record in read_json(ROOT / "independent_provenance.json")["origins"]:
        require(digest((ROOT / record["file"]).read_bytes()) == record["sha256"],
                "Independent audit origin changed: " + record["file"])

    configurations = [
        ("named_syntax", "named_audit.py", "named_audit_results.json"),
        ("factored_paths", "factored_audit.py", "factored_audit_results.json"),
        ("finite_semantics", "semantic_audit.py", "semantic_results.json"),
        ("local_formation", "preservation_audit.py", "preservation_results.json"),
    ]
    summaries = {}
    for name, script, output in configurations:
        audit = load_checker(ROOT / script, name + "_audit")
        result = audit.run(checker_path)
        require(result["status"] == "PASS", "Supplementary audit failed: " + name)
        require(result["checker_sha256"] == digest(checker_path.read_bytes()),
                "Audit tested another candidate")
        (ROOT / output).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        if "checks" in result:
            counts = result["checks"]
        elif "tests" in result:
            counts = {"independent_targeted_cases": result["tests"]}
        else:
            counts = {"valid_goal_formation_rejections": len(result["negative_tests"]),
                      "calibrated_mutant_detections": len(result["mutation_calibration"]),
                      "redundancy_controls": len(result["redundancy_control"])}
        summaries[name] = {"status": result["status"], "output": output,
                           "checks": counts, "total_check_events": sum(counts.values())}
    return unchanged, summaries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, default=ROOT.parent / "checker.py")
    parser.add_argument("--output", type=Path, default=ROOT / "results.json")
    args = parser.parse_args()
    checker_path = args.checker.resolve()
    result = run(checker_path)
    unchanged, audits = run_audits(checker_path)
    result["inherited_oracle_functions_unchanged"] = unchanged
    result["additional_audits"] = audits
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    summary = {key: value for key, value in result.items()
               if key not in ("results", "source_negative_certificates_excluded")}
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
