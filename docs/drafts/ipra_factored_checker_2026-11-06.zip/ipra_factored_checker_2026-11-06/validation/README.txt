VALIDATION AND PROOF TRANSPORT
==============================

From the package directory, run:

    python3 validation/reproduce.py

The command works from any current directory when given its absolute path.
It reads the frozen corpus, verifies provenance, performs both derivation
transports, runs every corpus certificate through the actual command line in
normal and Python -O modes, and runs all four supplementary audits. No fixture
or candidate source file is modified. Only result JSON files are refreshed.

Outputs
-------

summary.json                   Concise combined result.
results.json                   Full corpus, transport, and audit summary.
named_audit_results.json       Inherited independent named-syntax audit.
factored_audit_results.json    Independently constructed tests of new paths.
semantic_results.json          Independent finite semantic checks.
preservation_results.json      Local formation tests and mutation calibration.

Recorded evidence for the frozen checker
----------------------------------------

* 184 corpus certificates: 124 accepted and 60 rejected.
* 368 actual CLI runs: every corpus certificate in normal and Python -O modes.
* 124 accepted backward transports and their forward round trips.
* 177 predecessor JSON certificates checked against their original labels.
* All 116 positive predecessor certificates transported successfully.
* 154 predecessor certificates transported in total; 23 malformed predecessor
  negatives could not be transported and are explicitly excluded. They are
  not counted as successful candidate rejections.
* 30 explicitly labelled targeted certificates.
* Named-syntax audit: 1,372 substitution comparisons, 23 independently built
  numerical schemas, 25 positive certificates, 198 adversarial certificates,
  and 6 JSON/CLI checks.
* Factored-path audit: 29 independently constructed cases.
* Finite semantic supplement: 625 function-value checks, 945 substitution/
  evaluation checks, 10 computation-certificate shape checks, 1,250 checks of
  computation equations, one native-language cases counterexample observation,
  and one explicit-falsity check.
* Local formation supplement: four malformed proofs with valid final goals,
  three detections calibrated against two deliberately weakened in-memory
  checkers, and one control confirming a redundantly checked formula sort.

These are heterogeneous finite checks; their counts are not a statistical
confidence estimate or a machine-checked metatheorem. Some ordinary negative
cases can reject for more than one reason. The local formation supplement
specifically isolates important checks so rejection cannot be explained merely
by a malformed final goal. Its weakened programs are test calibration only;
no mutated program is used for acceptance or written over checker.py.

Source preservation and provenance
---------------------------------

source_provenance.json pins the current supplied ZIP at repository commit
046c84aa5e99f3a437e5bc6873af9f9a1cc797a5. It records the archive SHA-256 and Git
blob SHA-1, exact ZIP member names, byte counts, and hashes of 186 copied files.
Every copied file under source/ was compared byte-for-byte with its ZIP member.
The frozen predecessor checker is ../comparison/baselines/shared_unary_1.py.

source/fixtures/ contains the predecessor fixtures and manifests exactly as
supplied in that ZIP. Its own provenance.json preserves the earlier history,
including a hypothesis-key normalization performed before this iteration.
This iteration changes no supplied source fixture or expected label.

manifest.json identifies the 184 current-format fixtures, their source record
where applicable, expected result, byte count, and SHA-256. The current fixtures
are generated once, then frozen. Reproduction verifies their exact bytes;
it does not silently regenerate or relabel them from candidate results.

source/audit_candidate.py is the exact supplied independent named-syntax audit.
named_audit.py changes proof constructors and hypothesis references for the new
certificate format. named_audit_adaptation.diff makes those changes reviewable.
Reproduction compares the ASTs of ten oracle functions to ensure they remain
unchanged, including named substitution and numerical-schema construction.

independent_provenance.json identifies the fresh independent audit sources.
origins/ holds the original factored-path and semantic supplements. The former
is adapted only for a portable callable runner; the latter only gains a default
checker path. Preservation tests were copied unchanged from their independent
implementation. These validation programs are outside the acceptance boundary.

What the two transports prove
-----------------------------

transport.py provides forward(data, source) and backward(data, source). The
input and output are the same sequent after expanding the public false alias;
only proof records and harmless canonical spelling change. The transports are
not literal inverses on JSON: repeated equal assumptions can have several
indices, and the forward direction chooses the first occurrence.

Here is the relative derivability argument, independent of the finite tests.
Fix a well-formed context Gamma and use the ideal finite-tree semantics of the
two calculi, without implementation resource limits. Induct on a derivation.

1. A predecessor hypothesis key denotes a canonical formula in Gamma. Replace
   it by an index of that formula. Conversely, a successful integer leaf in
   the new calculus selects an actual entry Gamma[i]; the predecessor hyp
   record names that entry. Signed indices select premises under the stated
   convention and do not create new assumptions.

2. A predecessor [rec, r] proof is replaced by the raw recursion term r.
   Conversely, restore the wrapper. Both check the same term and produce the
   same zero or successor unfolding equation.

3. Pi and pack introduction form exactly the same lifted context and new
   assumption. Apply the induction hypothesis to their subderivations.

4. In shared elimination, the major premise has the same inferred formula
   in both calculi. Hence both select the same elimination branch, validate
   the same annotation, and use the same subordinate context. Apply the
   induction hypothesis to the major and minor derivations. Destructuring
   the major conclusion once instead of slicing it repeatedly changes no
   mathematical operation.

5. The numerical schema now validates its matrix during base substitution.
   For an equality matrix, well-sorted terms cannot contain the public false
   alias, so the original matrix is already canonical. For a Pi or ex matrix,
   both versions use the same canonical base as the frozen antecedent. For
   the bare false alias, its canonical equation is constant in the induction
   variable and equals its base instance. Thus every resulting numerical
   schema is literally identical after canonicalization.

Every rule therefore transports in both directions and preserves its sequent.
This establishes equivalence with the predecessor calculus; the accompanying
paper supplies the separate mathematics relating that calculus to iPRA.

Boundary
--------

The acceptance program is only ../checker.py, together with the fixed Python
runtime and its standard json/sys libraries. It imports no file in validation/,
comparison/, or origins/. Proof transport, oracle construction, fixture labels,
semantic evaluators, and calibration mutants are all untrusted auxiliary tools.
