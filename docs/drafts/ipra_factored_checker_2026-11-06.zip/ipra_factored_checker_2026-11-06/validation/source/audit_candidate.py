"""Independent finite audit of the shared unary iPRA checker.

Run with --checker PATH and optionally --output PATH.  In a deliverable's
validation/ directory the default checker is ../checker.py.

The substitution oracle decodes de Bruijn trees to named syntax, substitutes
only free names, and encodes again.  It does not import a baseline checker or
reuse the candidate's substitution/validation routines.  These finite tests
are evidence for the implementation; the report's metatheorems are separate.
"""

import argparse
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile


ZERO = -1
TRUTH = ["=", ZERO, ZERO]
FALSE = ["=", ZERO, ["s", ZERO]]
SERIAL = itertools.count()


def fresh():
    return ("bound", next(SERIAL))


def canonical(a):
    if a == ["false"]:
        return FALSE
    return [canonical(b) for b in a] if type(a) is list else a


def formed(a, formula):
    """Independent sort/arity recognizer, with explicit constructor clauses."""
    a = canonical(a)
    if type(a) is int:
        return not formula and a >= ZERO
    if type(a) is not list or not a:
        return False
    if a[0] == "s":
        return not formula and len(a) == 2 and formed(a[1], False)
    if a[0] == "r":
        return not formula and len(a) == 4 and all(formed(t, False) for t in a[1:])
    if a[0] == "=":
        return formula and len(a) == 3 and all(formed(t, False) for t in a[1:])
    if a[0] == "pi":
        return formula and len(a) == 3 and all(formed(t, True) for t in a[1:])
    if a[0] == "ex":
        return formula and len(a) == 2 and formed(a[1], True)
    return False


def decode(a, bound=()):
    """Translate to named syntax.  r binds state, counter; pi binds both arms."""
    a = canonical(a)
    if a == ZERO:
        return ("zero",)
    if type(a) is int:
        return ("var", bound[a] if a < len(bound) else ("free", a - len(bound)))
    tag = a[0]
    if tag == "s":
        return ("s", decode(a[1], bound))
    if tag == "=":
        return ("=", decode(a[1], bound), decode(a[2], bound))
    if tag == "r":
        u, v = fresh(), fresh()
        return ("r", decode(a[1], bound), decode(a[2], bound), u, v,
                decode(a[3], (u, v) + bound))
    x = fresh()
    if tag == "pi":
        return ("pi", x, decode(a[1], (x,) + bound), decode(a[2], (x,) + bound))
    if tag == "ex":
        return ("ex", x, decode(a[1], (x,) + bound))
    raise ValueError("oracle received an invalid expression")


def encode(a, bound=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "var":
        name = a[1]
        return len(bound) + name[1] if name[0] == "free" else bound.index(name)
    if tag in ("s", "="):
        return [tag, *(encode(b, bound) for b in a[1:])]
    if tag == "r":
        _, n, b, u, v, h = a
        return ["r", encode(n, bound), encode(b, bound), encode(h, (u, v) + bound)]
    if tag == "pi":
        _, x, p, q = a
        return ["pi", encode(p, (x,) + bound), encode(q, (x,) + bound)]
    _, x, p = a
    return ["ex", encode(p, (x,) + bound)]


def named_replace(a, replacements):
    """Simultaneous replacement of free-name leaves, without entering insertions."""
    if a[0] == "var":
        return replacements(a[1]) if a[1][0] == "free" else a
    if a[0] == "zero":
        return a
    if a[0] in ("s", "="):
        return (a[0], *(named_replace(b, replacements) for b in a[1:]))
    if a[0] == "r":
        _, n, b, u, v, h = a
        return ("r", named_replace(n, replacements), named_replace(b, replacements),
                u, v, named_replace(h, replacements))
    if a[0] == "pi":
        _, x, p, q = a
        return ("pi", x, named_replace(p, replacements), named_replace(q, replacements))
    _, x, p = a
    return ("ex", x, named_replace(p, replacements))


def oracle_subst(a, terms=(), delta=0, depth=0):
    protected = tuple(fresh() for _ in range(depth))
    tree = decode(a, protected)
    inserted = [decode(t) for t in terms]

    def replace(name):
        i = name[1]
        return inserted[i] if i < len(inserted) else ("var", ("free", i + delta))

    return encode(named_replace(tree, replace), protected)


def sh(a, n=1):
    return oracle_subst(a, delta=n)


def ins(a, t):
    return oracle_subst(a, [t], -1)


def expected_nat(matrix, force_induction=False):
    """Build the displayed numerical axiom in named syntax, then encode it."""
    matrix = canonical(matrix)
    p = decode(matrix)
    x, y, dummy = fresh(), fresh(), fresh()

    def instance(value):
        return named_replace(p, lambda name: value if name[1] == 0 else
                             ("var", ("free", name[1] - 1)))

    base = instance(("zero",))
    at_y = instance(("var", y))
    hypothesis = at_y if matrix[0] == "=" or force_induction else base
    step = ("pi", y, hypothesis, instance(("s", ("var", y))))
    axiom = ("pi", x, base, ("pi", dummy, step, instance(("var", x))))
    return encode(axiom)


def load_checker(path):
    spec = importlib.util.spec_from_file_location("audited_checker", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def corpus():
    """Deliberately exercise outer parameters and mixed one/two-variable scopes."""
    terms = [ZERO, 0, 1, 2, 5, ["s", 0], ["s", ZERO],
             ["r", 0, 1, ["s", 0]],
             ["r", 1, 0, ["r", 1, 0, ["s", 2]]],
             ["r", ["s", 2], 5, ["r", 3, 2, ["r", 1, 4, 6]]]]
    formulas = [TRUTH, FALSE, ["false"], ["=", 0, 1],
                ["pi", ["=", 0, 1], ["ex", ["=", 0, 2]]],
                ["ex", ["pi", ["=", 0, 2], ["=", 1, 3]]],
                ["pi", ["false"], ["ex", ["=", ["r", 2, 0, ["s", 4]], 3]]]]
    rng = random.Random(20261106)

    def term(level):
        if level == 0:
            return rng.choice([ZERO, 0, 1, 2, 3, 7])
        if rng.randrange(3) == 0:
            return ["s", term(level - 1)]
        return ["r", term(level - 1), term(level - 1), term(level - 1)]

    def formula(level):
        if level == 0:
            return ["=", term(1), term(1)]
        if rng.randrange(2):
            return ["pi", formula(level - 1), formula(level - 1)]
        return ["ex", formula(level - 1)]

    terms += [term(2) for _ in range(16)]
    formulas += [formula(2) for _ in range(16)]
    return terms, formulas


def certificates():
    yes, no = [], []

    def add(name, g, a, p):
        yes.append((name, [g, a, p]))

    def reject(name, g, a, p):
        no.append((name, [g, a, p]))

    def refl(t):
        rec = ["rec", ["r", ZERO, t, ZERO]]
        return ["use", rec, ["=", 0, sh(t)], rec]

    add("canonical_hypothesis", [TRUTH], TRUTH, ["hyp", TRUTH])
    add("surface_falsity_hypothesis", [FALSE], ["false"], ["hyp", ["false"]])
    for i, t in enumerate([ZERO, 0, ["s", 1], ["r", 0, 1, ["s", 2]]]):
        add(f"derived_reflexivity_{i}", [], ["=", t, t], refl(t))
        r = ["r", ZERO, t, ["r", 1, 0, ["s", 2]]]
        add(f"recursion_zero_{i}", [], ["=", r, t], ["rec", r])
        n = ["s", t]
        r = ["r", n, 2, ["r", 1, 0, ["s", 2]]]
        rhs = oracle_subst(r[3], [["r", t, 2, r[3]], t], -2)
        add(f"recursion_successor_nested_scope_{i}", [], ["=", r, rhs], ["rec", r])

    a = ["=", 0, 1]
    add("pi_retained_context_is_lifted", [a], ["pi", TRUTH, sh(a)],
        ["pi", TRUTH, ["hyp", sh(a)]])
    reject("pi_retained_context_capture", [a], ["pi", TRUTH, a],
           ["pi", TRUTH, ["hyp", a]])
    add("pi_canonicalized_guard", [], ["pi", FALSE, FALSE],
        ["pi", ["false"], ["hyp", ["false"]]])
    pi = ["pi", TRUTH, ["=", 0, 0]]
    t = ["s", 1]
    add("pi_elimination_with_open_term", [pi], ["=", t, t],
        ["use", ["hyp", pi], t, refl(ZERO)])

    witness_eq = ["=", 0, sh(t)]
    add("existential_witness_equation", [], ["ex", witness_eq],
        ["pack", t, ["hyp", witness_eq]])
    ex = ["ex", ["=", 0, 1]]
    add("existential_elimination_constant_goal", [ex], TRUTH,
        ["use", ["hyp", ex], TRUTH, refl(ZERO)])
    reject("existential_eigenvariable_escape", [ex], ["=", 0, 1],
           ["use", ["hyp", ex], ["=", 0, 1], ["hyp", ["=", 0, 1]]])

    s, t = 0, ["s", 1]
    eq = ["=", s, t]
    motives = [
        ["pi", ["=", 0, 1], ["ex", ["=", 0, 2]]],
        ["=", ["r", 1, 0, ["r", 1, 2, ["s", 4]]], 0],
    ]
    for i, motive in enumerate(motives):
        fs, ft = ins(motive, s), ins(motive, t)
        add(f"equality_transport_mixed_scopes_{i}", [eq, fs], ft,
            ["use", ["hyp", eq], motive, ["hyp", fs]])

    matrices = [["=", 0, 1], ["ex", ["=", 0, 1]],
                ["pi", ["=", 0, 0], ["=", 1, 0]], ["false"]]
    for i, matrix in enumerate(matrices):
        add(f"numerical_axiom_{i}", [], expected_nat(matrix), ["nat", matrix])
        if canonical(matrix)[0] != "=":
            reject(f"forbidden_quantified_induction_{i}", [],
                   expected_nat(matrix, force_induction=True), ["nat", matrix])

    bad_values = [True, False, 0.0, -1.0, None, "0", {}, [], -2,
                  ["unknown", 0], ["s"], ["s", 0, 1],
                  ["r", 0, ZERO], ["r", 0, ZERO, 0, 0],
                  ["r", 0, ZERO, ["=", 0, 0]],
                  ["=", 0], ["=", 0, 0, 0], ["=", True, 0],
                  ["=", -2, 0], ["=", ["false"], 0],
                  ["pi", TRUTH], ["pi", TRUTH, 0],
                  ["ex"], ["ex", TRUTH, TRUTH], ["ex", 0],
                  [["s"], 0], [True, 0]]
    for i, bad in enumerate(bad_values):
        if not formed(bad, True):
            reject(f"malformed_root_goal_{i}", [TRUTH], bad, ["hyp", TRUTH])
            reject(f"malformed_assumption_{i}", [bad, TRUTH], TRUTH, ["hyp", TRUTH])
            reject(f"malformed_pi_guard_{i}", [], TRUTH, ["pi", bad, refl(ZERO)])
            reject(f"malformed_nat_matrix_{i}", [], TRUTH, ["nat", bad])
            reject(f"malformed_equality_motive_{i}", [TRUTH], TRUTH,
                   ["use", ["hyp", TRUTH], bad, ["hyp", TRUTH]])
        if not formed(bad, False):
            reject(f"malformed_witness_{i}", [], ["ex", TRUTH], ["pack", bad, refl(ZERO)])
            reject(f"malformed_pi_argument_{i}", [["pi", TRUTH, TRUTH]], TRUTH,
                   ["use", ["hyp", ["pi", TRUTH, TRUTH]], bad, refl(ZERO)])

    reject("boolean_alias_hypothesis", [["=", 1, 1]], ["=", 1, 1],
           ["hyp", ["=", True, True]])
    reject("float_alias_hypothesis", [["=", 0, 0]], ["=", 0, 0],
           ["hyp", ["=", 0.0, 0.0]])
    reject("unused_recursion_body_invalid", [], ["=", ["r", ZERO, ZERO, True], ZERO],
           ["rec", ["r", ZERO, ZERO, True]])
    reject("unjustified_false", [], FALSE, ["hyp", FALSE])
    reject("recursion_at_variable_is_not_computation", [], TRUTH, ["rec", ["r", 0, ZERO, 0]])
    return yes, no


def run(checker_path):
    checker = load_checker(checker_path)
    results = {"checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
               "checker_file": checker_path.name, "checks": {}, "failures": []}
    terms, formulas = corpus()
    environments = [((), 0), ((), 1), ((), 3), ((ZERO,), -1),
                    ((["s", 0],), 0), ((2,), -1),
                    ((["r", 0, 1, ["s", 2]], 1), -2)]
    count = 0
    for formula, expressions in [(False, terms), (True, formulas)]:
        for j, a in enumerate(expressions):
            for depth in (0, 1, 2, 5):
                for inserted, delta in environments:
                    expected = oracle_subst(a, inserted, delta, depth)
                    actual = checker.subst(a, [*inserted, delta], depth, formula)
                    if actual != expected or not formed(actual, formula):
                        results["failures"].append({"test": "named_substitution_oracle", "formula": formula,
                            "index": j, "depth": depth, "terms": inserted, "delta": delta,
                            "expected": expected, "actual": actual})
                    count += 1
    results["checks"]["independent_named_substitution_comparisons"] = count

    nat_count = 0
    for matrix in formulas:
        actual = checker.infer(["nat", matrix], [])
        expected = expected_nat(matrix)
        if actual != expected:
            results["failures"].append({"test": "named_numerical_axiom", "matrix": matrix,
                                        "expected": expected, "actual": actual})
        nat_count += 1
    results["checks"]["independent_named_numerical_axioms"] = nat_count

    yes, no = certificates()
    for wanted, fixtures in [(True, yes), (False, no)]:
        for name, certificate in fixtures:
            error = None
            try:
                accepted = checker.check(certificate) is True
            except (ValueError, TypeError, IndexError, KeyError, RecursionError) as exc:
                accepted = False
                error = type(exc).__name__
            if accepted != wanted:
                results["failures"].append({"test": name, "expected_accept": wanted,
                                            "accepted": accepted, "exception": error})
    results["checks"]["positive_rule_certificates"] = len(yes)
    results["checks"]["adversarial_certificates"] = len(no)

    # Exercise the actual file/JSON/CLI trust boundary, including invalid JSON.
    cli_inputs = [("positive", json.dumps(yes[0][1]), True),
                  ("false", json.dumps([[], FALSE, ["hyp", FALSE]]), False),
                  ("object_envelope", '{"g": [], "a": 0, "p": 0}', False),
                  ("extra_envelope", '[[], ["=",-1,-1], ["hyp",0],0]', False),
                  ("invalid_json", '[', False),
                  ("float_nan", '[[], ["=",NaN,NaN], ["hyp",0]]', False)]
    with tempfile.TemporaryDirectory() as temp:
        for name, content, wanted in cli_inputs:
            p = Path(temp) / (name + ".json")
            p.write_text(content, encoding="utf-8")
            proc = subprocess.run([sys.executable, str(checker_path), str(p)],
                                  capture_output=True, text=True, timeout=10)
            expected = (0, "ACCEPT") if wanted else (1, "REJECT")
            if (proc.returncode, proc.stdout.strip()) != expected or proc.stderr:
                results["failures"].append({"test": "cli_" + name, "returncode": proc.returncode,
                                            "stdout": proc.stdout, "stderr": proc.stderr})
    results["checks"]["json_cli_boundaries"] = len(cli_inputs)
    results["status"] = "PASS" if not results["failures"] else "FAIL"
    results["scope"] = ("Finite checks of typed substitution, simultaneous replacement, binder capture, "
        "public-falsity conversion, numerical-axiom construction, every inference record, malformed "
        "annotations, Python scalar aliases, eigenvariable escape, forbidden quantified-induction "
        "certificates, and the JSON CLI. These are not a machine-checked metatheorem or an exhaustive "
        "test of all finite proofs. Python interpreter and JSON parser remain in the trusted runtime.")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, default=Path(__file__).resolve().parents[1] / "checker.py")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run(args.checker.resolve())
    text = json.dumps(result, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
