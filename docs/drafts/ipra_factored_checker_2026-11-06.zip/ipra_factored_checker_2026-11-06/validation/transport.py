"""Untrusted proof transport between predecessor and indexed certificates.

The source checker supplies context formation during conversion only. Neither
this file nor the source checker is imported by the candidate checker.
For accepted proofs, each direction preserves the sequent after expansion of
public falsity. These are derivation transports, not literal JSON inverses:
a hypothesis index may change to the first equal occurrence in the context.
"""


def forward_proof(p, g, source):
    match p:
        case ["hyp", key]:
            return g.index(source.subst(key, (0,), formula=True))
        case ["pi", a, q]:
            a = source.subst(a, (0,), formula=True)
            h = [*map(source.subst, g), a]
            return ["pi", a, forward_proof(q, h, source)]
        case ["pack", t, q]:
            t = source.subst(t, (0,), formula=False)
            h = [*map(source.subst, g), ["=", 0, source.subst(t)]]
            return ["pack", t, forward_proof(q, h, source)]
        case ["use", p, a, q]:
            e = source.infer(p, g)
            h = [*map(source.subst, g), *e[1:]] if e[0] == "ex" else g
            return ["use", forward_proof(p, g, source), a,
                    forward_proof(q, h, source)]
        case ["rec", r]:
            return r
        case _:
            return p


def backward_proof(p, g, source):
    if type(p) is int:
        return ["hyp", g[p]]
    match p:
        case ["pi", a, q]:
            a = source.subst(a, (0,), formula=True)
            h = [*map(source.subst, g), a]
            return ["pi", a, backward_proof(q, h, source)]
        case ["pack", t, q]:
            t = source.subst(t, (0,), formula=False)
            h = [*map(source.subst, g), ["=", 0, source.subst(t)]]
            return ["pack", t, backward_proof(q, h, source)]
        case ["use", p, a, q]:
            major = backward_proof(p, g, source)
            e = source.infer(major, g)
            h = [*map(source.subst, g), *e[1:]] if e[0] == "ex" else g
            return ["use", major, a, backward_proof(q, h, source)]
        case ["r", _, _, _]:
            return ["rec", p]
        case _:
            return p


def forward(data, source):
    g, a, p = data
    g = [source.subst(b, (0,), formula=True) for b in g]
    return [g, a, forward_proof(p, g, source)]


def backward(data, source):
    g, a, p = data
    g = [source.subst(b, (0,), formula=True) for b in g]
    return [g, a, backward_proof(p, g, source)]
