"""Finite semantic checks supplementing the inherited named-syntax audit.

This independent script checks initialized recursion against five elementary
functions, finite instances of substitution/evaluation coherence, the two
computation certificates, and a native-language counterexample showing why
numerical cases cannot be removed. It is not a proof of the metatheory.

The candidate is imported only for subst() and infer(). The term encoder,
two evaluators, expected functions and classical pair-model calculations
do not use the candidate's substitution or inference machinery.
"""

import argparse
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path


Z = ("zero",)
FREE = ("n", "a", "k")


def V(name):
    return ("var", name)


def S(term):
    return ("s", term)


def R(counter, initial, state, index, body):
    return ("r", counter, initial, state, index, body)


def Eq(left, right):
    return ("=", left, right)


def encode_named(term, free=FREE, bound=()):
    """Encode explicitly named terms; only an r body binds its two names."""
    match term:
        case ("zero",):
            return -1
        case ("var", name):
            return bound.index(name) if name in bound else len(bound) + free.index(name)
        case ("s", child):
            return ["s", encode_named(child, free, bound)]
        case ("r", counter, initial, state, index, body):
            return ["r", encode_named(counter, free, bound),
                    encode_named(initial, free, bound),
                    encode_named(body, free, (state, index) + bound)]
    raise ValueError("invalid named term")


def named_value(term, values):
    """Lexical-environment interpretation, independent of numerical indices."""
    match term:
        case ("zero",):
            return 0
        case ("var", name):
            return values[name]
        case ("s", child):
            return 1 + named_value(child, values)
        case ("r", counter, initial, state_name, index_name, body):
            count = named_value(counter, values)
            state = named_value(initial, values)
            for index in range(count):
                state = named_value(body, {**values, state_name: state, index_name: index})
            return state
    raise ValueError("invalid named term")


def native_value(term, values):
    """Direct denotation of a native term, with no syntactic substitution."""
    if type(term) is int:
        return 0 if term == -1 else values[term]
    if term[0] == "s":
        return 1 + native_value(term[1], values)
    if term[0] == "r":
        count = native_value(term[1], values)
        state = native_value(term[2], values)
        for index in range(count):
            state = native_value(term[3], (state, index, *values))
        return state
    raise ValueError("invalid native term")


def example_functions():
    n, a, k = map(V, FREE)
    u, v, w = map(V, ("u", "v", "w"))
    return [
        ("addition", R(n, a, "u", "v", S(u)), lambda n, a, k: a + n),
        ("predecessor", R(n, Z, "u", "v", v), lambda n, a, k: max(n - 1, 0)),
        ("sum_of_counters", R(n, a, "u", "v", R(v, u, "w", "j", S(w))),
         lambda n, a, k: a + n * (n - 1) // 2),
        ("external_parameter", R(n, a, "u", "v", R(k, u, "w", "j", S(w))),
         lambda n, a, k: a + n * k),
        ("protected_outer_counter", R(n, a, "u", "v", R(k, u, "w", "j", S(v))),
         lambda n, a, k: a if n == 0 or k == 0 else n),
    ]


def pair_value(term, values):
    return tuple(named_value(term, {name: value[axis] for name, value in values.items()})
                 for axis in (0, 1))


def classical_sample(formula, values, grid):
    """Classical evaluation for the explicitly stated finite sample of N x N.

    The grid is a quantifier sample, not a finite arithmetic model. The
    accompanying mathematical argument concerns the whole infinite product.
    """
    match formula:
        case ("=", left, right):
            return pair_value(left, values) == pair_value(right, values)
        case ("pi", name, antecedent, consequent):
            for value in grid:
                local = {**values, name: value}
                if classical_sample(antecedent, local, grid) and not classical_sample(consequent, local, grid):
                    return False
            return True
        case ("ex", name, matrix):
            return any(classical_sample(matrix, {**values, name: value}, grid) for value in grid)
    raise ValueError("invalid named formula")


def run(checker_path):
    spec = importlib.util.spec_from_file_location("semantic_candidate", checker_path)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    result = {"checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
              "checks": {}, "failures": []}

    def record(category, condition, detail):
        result["checks"][category] = result["checks"].get(category, 0) + 1
        if not condition:
            result["failures"].append({"category": category, "detail": detail})

    assignments = list(itertools.product(range(5), repeat=3))
    examples = example_functions()
    for name, named, expected in examples:
        native = encode_named(named)
        for values in assignments:
            wanted = expected(*values)
            record("named_and_native_function_values",
                   named_value(named, dict(zip(FREE, values))) == native_value(native, values) == wanted,
                   {"function": name, "values": values})

        environments = [([], 0), ([], 1), ([], 3), ([["s", 0]], -1),
                        ([1, 0], 0), ([["s", 1], ["r", 0, 2, ["s", 0]]], -2),
                        ([["r", 1, 0, ["s", 2]]], 0)]
        for terms, delta in environments:
            transformed = checker.subst(native, [*terms, delta], 0, False)
            for values in itertools.product(range(3), repeat=3):
                target = (*values, 1, 2, 0, 1, 2, 0)
                source = tuple(native_value(terms[i], target) if i < len(terms)
                               else target[i + delta] for i in range(len(FREE)))
                record("substitution_evaluation_coherence",
                       native_value(transformed, target) == named_value(named, dict(zip(FREE, source))),
                       {"function": name, "prefix": terms, "offset": delta, "values": values})

        for mode, counter in (("zero", -1), ("successor", ["s", native[1]])):
            recursor = ["r", counter, *native[2:]]
            equation = checker.infer(recursor, [])
            record("computation_certificate_shapes", equation[:2] == ["=", recursor],
                   {"function": name, "mode": mode})
            for values in assignments:
                record("computation_certificate_values",
                       native_value(equation[1], values) == native_value(equation[2], values),
                       {"function": name, "mode": mode, "values": values})

    contradiction = Eq(Z, S(Z))
    # P(x) = ((x = 0 -> D) -> exists y. x = S(y)). Both implications
    # are represented by guarded universal binders with unused variables.
    p = ("pi", "unused_outer", ("pi", "unused_inner", Eq(V("x"), Z), contradiction),
         ("ex", "y", Eq(V("x"), S(V("y")))))
    grid = tuple(itertools.product(range(3), repeat=2))
    observations = {"zero": classical_sample(p, {"x": (0, 0)}, grid),
                    "successors": [classical_sample(p, {"x": (a + 1, b + 1)}, grid)
                                   for a, b in grid],
                    "mixed_01": classical_sample(p, {"x": (0, 1)}, grid),
                    "mixed_10": classical_sample(p, {"x": (1, 0)}, grid)}
    record("native_cases_counterexample",
           observations["zero"] and all(observations["successors"])
           and not observations["mixed_01"] and not observations["mixed_10"], observations)
    result["counterexample_observations"] = observations

    canonical_false = ["=", -1, ["s", -1]]
    record("explicit_falsity",
           checker.subst(["false"], (0,), 0, True) == canonical_false
           and checker.infer(["nat", ["false"]], []) == checker.infer(["nat", canonical_false], [])
           and not classical_sample(contradiction, {}, grid),
           "Public falsity is D; its constant induction and cases axiom instances coincide.")
    result["status"] = "PASS" if not result["failures"] else "FAIL"
    result["scope"] = ("Finite semantic corroboration only. The pair grid is not a finite arithmetic model. "
                       "The infinite-product counterexample and general bi-interpretability require the "
                       "accompanying mathematical proofs; resource-limited Python execution is not a "
                       "formal verification of those proofs.")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path,
                        default=Path(__file__).resolve().parents[1] / "checker.py")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run(args.checker.resolve())
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
