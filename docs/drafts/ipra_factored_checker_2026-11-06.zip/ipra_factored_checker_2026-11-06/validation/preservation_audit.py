"""Targeted checks of local formation, with valid outer conclusions.

The original checker must reject all four malformed proof records. Two
deliberately weakened in-memory variants establish that three of these
checks really exercise the relevant validation, rather than succeeding
accidentally from a malformed final goal or an unrelated mismatch. A third
variant confirms redundant enforcement of N's formula sort. No candidate
file is modified, and the variants are never part of proof acceptance.
"""

import argparse
import hashlib
import json
from pathlib import Path
import types


T = ["=", -1, -1]
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def reflexivity_zero():
    computation = ["r", -1, -1, -1]
    return ["use", computation, ["=", 0, -1], computation]


def discarded_existential(body):
    return ["use", ["pack", -1, body], T, reflexivity_zero()]


def fixtures():
    return [
        {"name": "hidden_term_as_pi_guard",
         "certificate": [[], T, discarded_existential(["pi", ["s", 0], reflexivity_zero()])],
         "obligation": "Pi's guard is a formula even when its inferred conclusion is later discarded."},
        {"name": "hidden_term_as_nat_matrix",
         "certificate": [[], T, discarded_existential(["nat", ["s", 0]])],
         "obligation": "N's matrix is a formula even when its inferred conclusion is later discarded."},
        {"name": "unused_recursion_body_boolean",
         "certificate": [[], T, ["use", ["r", -1, -1, True], T, reflexivity_zero()]],
         "obligation": "R0 validates the whole recursor, including an unused scalar body."},
        {"name": "unused_recursion_body_wrong_sort",
         "certificate": [[], T, ["use", ["r", -1, -1, ["=", 0, 0]], T, reflexivity_zero()]],
         "obligation": "R0 validates the whole recursor, including an unused formula body."},
    ]


def module_from_source(source):
    module = types.ModuleType("preservation_audit_candidate")
    exec(compile(source, "<preservation-audit>", "exec"), module.__dict__)
    return module


def accepted(module, certificate):
    try:
        return module.check(certificate) is True
    except ERRORS:
        return False


def run(checker_path):
    source = checker_path.read_text(encoding="utf-8")
    checker = module_from_source(source)
    records = fixtures()
    result = {"checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
              "negative_tests": [], "mutation_calibration": [],
              "redundancy_control": [], "failures": []}
    for record in records:
        observed = accepted(checker, record["certificate"])
        result["negative_tests"].append({"name": record["name"], "accepted": observed,
                                         "obligation": record["obligation"]})
        if observed:
            result["failures"].append(record["name"])

    mutations = [
        ("omit_pi_guard_sort", 'a = subst(a, (0,), formula=tag == "pi")',
         'a = subst(a, (0,))', [records[0]]),
        ("omit_recursion_formation", 'subst(r, (0,), formula=False)',
         'pass', records[2:]),
    ]
    for name, before, after, tests in mutations:
        if source.count(before) != 1:
            result["failures"].append("Unexpected source shape for " + name)
            continue
        mutant = module_from_source(source.replace(before, after))
        for record in tests:
            observed = accepted(mutant, record["certificate"])
            result["mutation_calibration"].append({"mutant": name, "test": record["name"],
                                                    "accepted_as_expected": observed})
            if not observed:
                result["failures"].append("Test does not detect " + name + ": " + record["name"])

    before = 'base = subst(a, [ZERO, 0], formula=True)'
    if source.count(before) != 1:
        result["failures"].append("Unexpected source shape for N redundancy control")
    else:
        control = module_from_source(source.replace(before, 'base = subst(a, [ZERO, 0])'))
        observed = accepted(control, records[1]["certificate"])
        result["redundancy_control"].append({
            "change": "omit_explicit_nat_root_sort", "test": records[1]["name"],
            "accepted": observed, "expected_accept": False,
            "reason": "The later subst(step, (2,)) still checks the Pi antecedent's formula sort."})
        if observed:
            result["failures"].append("N redundancy control unexpectedly accepted")

    result["status"] = "PASS" if not result["failures"] else "FAIL"
    result["scope"] = ("Four strict-formation rejections with valid goals, three mutant detections "
                       "and one redundant-validation control. "
                       "The weakened variants are test calibration only; they are not a claim that "
                       "the malformed records prove a contradiction. The candidate file is untouched.")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path,
                        default=Path(__file__).resolve().parents[1] / "checker.py")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--fixtures", type=Path)
    args = parser.parse_args()
    result = run(args.checker.resolve())
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    if args.fixtures:
        args.fixtures.mkdir(parents=True, exist_ok=True)
        for record in fixtures():
            (args.fixtures / (record["name"] + ".json")).write_text(
                json.dumps(record["certificate"], separators=(",", ":")) + "\n", encoding="utf-8")
    print(rendered, end="")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
