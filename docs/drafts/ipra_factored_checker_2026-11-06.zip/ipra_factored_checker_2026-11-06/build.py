"""Compile the complete LaTeX article and reject unresolved layout warnings."""

from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    for run in range(3):
        with (build / f"pdflatex-{run + 1}.txt").open("w") as output:
            subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                            "-output-directory", str(build), "report.tex"],
                           cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=True)
    log = (build / "report.log").read_text(errors="replace")
    problems = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()
                or "Rerun to get cross-references right" in line]
    if problems:
        raise RuntimeError("LaTeX verification failed:\n" + "\n".join(problems))
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    print("Compiled report.pdf; no overfull boxes or unresolved references.")


if __name__ == "__main__":
    main()
