"""Recount exact complete checker sources without executing them."""

import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
KEYS = ("source_tokens", "normalized_tokens", "ast_nodes", "normalized_bytes", "raw_bytes")
LAYOUT = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE,
          tokenize.NL, tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT}


def string_statement(node):
    return (isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str))


class Executable(ast.NodeTransformer):
    def visit_Expr(self, node):
        return None if string_statement(node) else self.generic_visit(node)


def count_tokens(source, spans=()):
    return sum(token.type not in LAYOUT and not any(
        start <= token.start and token.end <= end for start, end in spans)
        for token in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)

    def position(row, byte_column):
        return row, len(lines[row - 1].encode("utf-8")[:byte_column].decode("utf-8"))

    spans = [(position(n.lineno, n.col_offset), position(n.end_lineno, n.end_col_offset))
             for n in ast.walk(tree) if string_statement(n)]
    source_tokens = count_tokens(source, spans)
    clean = ast.fix_missing_locations(Executable().visit(tree))
    normal = ast.unparse(clean) + "\n"
    return {"sha256": hashlib.sha256(raw).hexdigest(),
            "source_tokens": source_tokens,
            "normalized_tokens": count_tokens(normal),
            "ast_nodes": sum(1 for _ in ast.walk(clean)),
            "normalized_bytes": len(normal.encode("utf-8")),
            "raw_bytes": len(raw)}


def verified(entry):
    counts = measure(ROOT / entry["snapshot"])
    if counts["sha256"] != entry["sha256"]:
        raise ValueError("Changed source: " + entry["snapshot"])
    return dict(entry, **counts)


def minima(rows):
    return {key: min(row[key] for row in rows) for key in KEYS}


def main():
    provenance = json.loads((ROOT / "comparison/provenance.json").read_text())
    inventory = json.loads((ROOT / "comparison/inventory.json").read_text())
    primary = [verified(entry) for entry in provenance["primary"]]
    core = verified(provenance["core"])
    sources = [verified(entry) for entry in inventory["sources"]]
    candidate = measure(ROOT / "checker.py")
    lower = minima(primary)
    inventory_lower = minima(sources)
    comparisons = {key: candidate[key] < lower[key] for key in KEYS}
    if not all(comparisons.values()):
        raise ValueError("Candidate does not beat every current primary minimum")
    if not all(candidate[key] < inventory_lower[key] for key in KEYS):
        raise ValueError("Candidate does not beat every inventoried source minimum")
    result = {"python_version": platform.python_version(),
              "repository": provenance["repository"], "commit": provenance["commit"],
              "metric_contract": {
                  "source_tokens": "Original Python tokens excluding layout, comments, and standalone string statements.",
                  "normalized_tokens": "Same token count after removing string statements and ast.unparse.",
                  "ast_nodes": "All nodes in ast.walk after removing standalone string statements, including the module node.",
                  "normalized_bytes": "UTF-8 bytes of ast.unparse of that tree plus one newline.",
                  "raw_bytes": "Exact original file bytes, including comments and documentation."},
              "trusted_boundary": "Every byte of checker.py plus common Python/standard-library runtime; no local helper imported.",
              "primary": primary, "primary_coordinate_minima": lower,
              "core_only": core, "inventory_coordinate_minima": inventory_lower,
              "inventory_distinct_sources": len(sources),
              "inventory_source_occurrences": inventory["source_occurrences"],
              "candidate": candidate, "strict_improvements": comparisons}
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    (out / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    suffix = {"source_tokens": "Tokens", "normalized_tokens": "NormalizedTokens",
              "ast_nodes": "AST", "normalized_bytes": "NormalizedBytes", "raw_bytes": "RawBytes"}
    macros = ["\\newcommand{\\" + prefix + suffix[key] + "}{" + str(row[key]) + "}"
              for prefix, row in (("Candidate", candidate), ("Baseline", lower)) for key in KEYS]
    (out / "metrics_macros.tex").write_text("\n".join(macros) + "\n")
    table = [r"\begin{center}", r"\small\setlength{\tabcolsep}{4pt}",
             r"\begin{tabular}{lrrrrr}", r"\toprule",
             r"Complete program & \shortstack{Source\\tokens} & \shortstack{Normal\\tokens} & \shortstack{AST\\nodes} & \shortstack{Normal\\bytes} & \shortstack{Raw\\bytes} \\",
             r"\midrule"]
    for row in primary:
        table.append(row["label"] + " & " + " & ".join(str(row[k]) for k in KEYS) + r" \\")
    table += [r"\midrule", "Coordinate minima & " + " & ".join(str(lower[k]) for k in KEYS) + r" \\",
              r"\textbf{This checker} & " + " & ".join(r"\textbf{" + str(candidate[k]) + "}" for k in KEYS) + r" \\",
              r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    (out / "comparison_table.tex").write_text("\n".join(table) + "\n")
    print(json.dumps({"candidate": candidate, "primary_minima": lower,
                      "inventory_minima": inventory_lower}, indent=2))


if __name__ == "__main__":
    main()
