A FACTORED COMPLETE CHECKER FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
========================================================================
Prepared for Vladimir Reshetnikov, 6 November 2026.

RESULT

The complete checker has 785 significant Python tokens, 785 normalized
tokens, 833 executable AST nodes, 2,522 normalized bytes, and 2,764 raw
bytes. Each count is below the corresponding minimum among the six main
implementations in ProveIt/docs/drafts at commit
046c84aa5e99f3a437e5bc6873af9f9a1cc797a5:
808 / 808 / 855 / 2,618 / 2,865.

It is also below all coordinate minima in the 115 distinct inventoried
infer/check modules embedded in those archives, including the smaller
typed-substitution core that omits its public falsity wrapper.

This is a measured improvement over the inspected finite corpus. It is
not a theorem of absolute shortest-program or axiomatic minimality.

MATHEMATICS

report.pdf is the complete article. report.tex, sections/, and results/*.tex
are all its LaTeX sources. The paper specifies every logical rule and
nonlogical schema, derives full intuitionistic logic and quantifier-free
induction, and proves whole-domain bi-interpretability with the explicitly
specified first-order iPRA. The composite internal isomorphisms are equality.

The mathematical basis is inherited from the supplied drafts: initialized
primitive recursion, equality, guarded universal implication, unary existence,
and the combined equation-induction / numerical-cases schema. The new
contribution is a smaller complete proof representation and acceptance
program. The article explicitly credits the inherited formula-amalgamation
and equality-detection arguments.

The reference iPRA uses full first-order intuitionistic logic and
quantifier-free induction. The paper does not silently identify this with
a bare atomic-induction theory without numerical coverage. Genuine falsity
is explicitly bridged to 0 = S0; the public ["false"] alias is checked.

CHECK A PROOF

Python 3.10 or later is required. No third-party Python package is needed.

    python3 checker.py examples/reflexivity.json
    python3 checker.py examples/exists_zero.json
    python3 checker.py examples/addition_induction.json

The input is [context, goal, proof]. ACCEPT with exit status zero means the
asserted sequent passed. REJECT with nonzero status means this certificate
did not pass; it is not a decision that the sequent is unprovable.

The complete acceptance source is checker.py. It imports only json and sys.
Neither the proof transports nor validation programs are trusted by it.
FORMAT.txt documents the proof and expression syntax, including negative
context indices. The source listing is also included in the PDF appendix.

REPRODUCE THE COMPARISON AND EVIDENCE

    python3 reproduce.py

This runs measure.py and validation/reproduce.py. It requires no network.
The latter verifies the exact vendored predecessor members, transports all
116 positive source fixtures, checks 184 new-format certificates (124
positive and 60 negative), makes 368 actual CLI invocations across normal
and optimized Python modes, and checks the reverse transport of every
accepted fixture. Excluded malformed predecessor negatives are recorded
and are not counted as successful candidate rejections.

The independent audits include 1,372 named-syntax substitution comparisons,
23 independently constructed numerical schemas, 25 additional positive and
198 adversarial rule certificates, six JSON boundary checks, 29 focused
instruction tests, 2,832 finite semantic/computation checks, and four local
formation rejections calibrated against narrowly weakened in-memory controls.
These categories are reported separately rather than claimed to be disjoint
or exhaustive. The frozen checker is not modified by the controls.

results/metrics.json records the whole-program measurements.
validation/summary.json records the validation summary.
validation/results.json and the separate *_results.json files retain details.
comparison/provenance.json and comparison/inventory.json record the source
archive/member identities. All 115 distinct comparison source files are
included and recounted without executing them.

BUILD THE ARTICLE

Install a standard pdfLaTeX distribution with the packages in report.tex.

    python3 build.py
    # Or run verification and compilation together:
    python3 reproduce.py --pdf

The build uses three passes and rejects unresolved references and overfull
boxes. The delivered PDF was rendered and visually inspected as well.

SCOPE AND LIMITS

The article contains mathematical proofs; the program has structural
correctness arguments and finite executable audits. This is not a Lean or
Rocq formalization of the general metatheory or of Python semantics.
Python and its standard-library parser are the shared runtime trust base.
Actual resource limits can reject very deep valid proof trees. Completeness
is asserted for the calculus and abstract checking algorithm with sufficient
resources, not for an interpreter with fixed finite limits.

MANIFEST.sha256 records the delivered snapshot. Running reproduction can
regenerate measurement, result, and build files under a different Python or
TeX version; the recorded versions make such changes visible.
