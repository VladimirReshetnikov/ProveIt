"""Reproduce measurements and validation; add --pdf to rebuild the article."""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(script):
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)


if __name__ == "__main__":
    run("measure.py")
    run("validation/reproduce.py")
    if "--pdf" in sys.argv[1:]:
        run("build.py")
    print("Reproduction completed.")
