"""Remeasure the complete programs and reproduce their verification offline."""
import json
from pathlib import Path
import subprocess
import sys
import compare_snapshot


def main():
    root = Path(__file__).resolve().parent
    comparison = compare_snapshot.recount(root / "comparison", root / "checker.py")
    variants = {}
    for name in ("checker_open_strict.py", "checker_open.py",
                 "checker_strict.py", "checker.py"):
        variants[name] = compare_snapshot.measure((root / name).read_bytes())
    below = {name: {key: value[key] < comparison["envelope"][key]
                    for key in compare_snapshot.FIELDS}
             for name, value in variants.items()}
    if not all(all(row.values()) for row in below.values()):
        raise SystemExit("A measured program did not beat the comparison envelope.")
    measurements = {
        "python": sys.version, "commit": comparison["commit"],
        "baseline_envelope": comparison["envelope"], "variants": variants,
        "below_envelope": below,
    }
    (root / "results" / "kernel_metrics.json").write_text(
        json.dumps(measurements, indent=2) + "\n")
    runs = [
        [sys.executable, str(root / "validation" / "independent_audit.py"),
         "--root", str(root)],
        [sys.executable, str(root / "roundtrip.py"), "--root", str(root)],
        [sys.executable, str(root / "validation" / "cli_boundary.py"),
         "--root", str(root)],
    ]
    for command in runs:
        result = subprocess.run(command, cwd=root, capture_output=True, text=True)
        if result.returncode:
            print(result.stdout + result.stderr)
            raise SystemExit(result.returncode)
    audit = json.loads((root / "results" / "independent_audit.json").read_text())
    rounds = json.loads((root / "validation" / "roundtrip_results.json").read_text())
    boundary = json.loads((root / "results" / "cli_boundary.json").read_text())
    summary = {
        "status": "PASS",
        "baseline_envelope": comparison["envelope"],
        "kernels": {name: {key: row[key] for key in compare_snapshot.FIELDS}
                    for name, row in variants.items()},
        "independent_audit": {
            "status": audit["status"],
            "inputs": audit["fixture_count"] + audit["raw_json_count"],
            "comparisons": audit["checker_comparisons"],
            "failures": len(audit["failures"]),
        },
        "proof_roundtrips": {
            "status": rounds["status"], "source_records": rounds["source_records"],
            "exact_roundtrips": rounds["counts"]["exact_sequent_roundtrips"],
            "closed_kernel_checks": rounds["counts"]["closed_theorem_acceptances"],
            "cli_runs": rounds["counts"]["cli_runs"],
        },
        "cli_boundary": {"status": boundary["status"], "runs": boundary["runs"]},
    }
    (root / "results" / "reproduction.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
