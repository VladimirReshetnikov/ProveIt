"""Rebuild the checksum manifest and a deterministic ZIP of the deliverable."""
from pathlib import Path
import hashlib
import zipfile


def main():
    root = Path(__file__).resolve().parent
    if not (root / "report.pdf").is_file():
        raise SystemExit("Build report.pdf first.")
    excluded_suffixes = {".pyc", ".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk"}
    files = sorted(p for p in root.rglob("*") if p.is_file()
                   and not any(part.startswith(".") or part == "__pycache__"
                               for part in p.relative_to(root).parts)
                   and p.suffix not in excluded_suffixes
                   and p.name != "MANIFEST.sha256")
    manifest = root / "MANIFEST.sha256"
    manifest.write_text("".join(
        hashlib.sha256(p.read_bytes()).hexdigest() + "  " +
        p.relative_to(root).as_posix() + "\n" for p in files))
    archive = root.parent / (root.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as output:
        for p in sorted(files + [manifest]):
            info = zipfile.ZipInfo(
                root.name + "/" + p.relative_to(root).as_posix(),
                date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, p.read_bytes(), compresslevel=9)
    print(archive.name)
    print("Bytes:", archive.stat().st_size)
    print("SHA256:", hashlib.sha256(archive.read_bytes()).hexdigest())
    print("Files:", len(files) + 1)


if __name__ == "__main__":
    main()
