"""Offline complexity census of the six pinned ProveIt draft archives.

No comparison source is imported or executed. Build the immutable census with
  python3 compare_snapshot.py --archives ../baseline --comparison comparison
Remeasure frozen sources and (optionally) a complete new acceptance program with
  python3 compare_snapshot.py --comparison comparison --candidate checker.py
The source archives are needed only to rebuild provenance, not to remeasure.
"""
import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize
import zipfile

FIELDS = ('ast_nodes', 'normalized_tokens', 'source_tokens',
          'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
ACCEPTANCE_NAMES = {'check', 'check_proof', 'accept', 'verify'}
PRIMARY_LABELS = {
    'ipra_compact_calculus_2026-11-06.zip': 'compact',
    'ipra_factored_kernel_2026-11-06(1).zip': 'factored',
    'ipra_integrated_kernel_2026-11-06.zip': 'integrated',
    'ipra_parameter_axiom_2026-11-06.zip': 'parameter_axiom',
    'ipra_reduction_2026-11-06.zip': 'goal_directed',
    'ipra_repaired_computation_2026-11-06.zip': 'repaired_computation',
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def measure(raw):
    """Retain the drafts' actual-docstring and ast.unparse convention."""
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    functions = sorted(n.name for n in tree.body
                       if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)))
    imports = sorted(set(
        [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
        + [n.module or '' for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]))
    has_cli = any(isinstance(n, ast.Constant) and n.value == '__main__'
                  for n in ast.walk(tree))
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'

    def tokens(text, omitted=()):
        return sum(t.type not in IGNORED and not any(
            start <= t.start and t.end <= end for start, end in omitted)
            for t in tokenize.generate_tokens(io.StringIO(text).readline))

    return {
        'sha256': digest(raw), 'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'source_tokens': tokens(source, spans),
        'normalized_tokens': tokens(normalized),
        'normalized_bytes': len(normalized.encode('utf-8')), 'raw_bytes': len(raw),
        'function_names': functions, 'imports': imports, 'has_cli': has_cli,
    }


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def hash_list(value):
    """Read the three formats used by inherited source/group manifests."""
    if not isinstance(value, list):
        return []
    result = []
    for item in value:
        h = item if isinstance(item, str) else item.get('sha256') if isinstance(item, dict) else None
        if isinstance(h, str) and len(h) == 64 and all(c in '0123456789abcdef' for c in h):
            result.append(h)
    return sorted(set(result))


def collect(archives, destination):
    snapshot = json.loads((archives / 'manifest.json').read_text())
    if set(x['name'] for x in snapshot['files']) != set(PRIMARY_LABELS):
        raise ValueError('Expected exactly the six pinned archive names.')
    sources, source_bytes, archive_rows, primary, documents = {}, {}, [], [], []
    occurrence_count = 0
    for entry in snapshot['files']:
        archive_path = archives / entry['name']
        raw_archive = archive_path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(raw_archive)).encode() + b'\0' + raw_archive).hexdigest()
        if len(raw_archive) != entry['size'] or blob != entry['blob_sha']:
            raise ValueError('Archive differs from pinned Git blob: ' + entry['name'])
        archive_rows.append({**entry, 'sha256': digest(raw_archive)})
        with zipfile.ZipFile(io.BytesIO(raw_archive)) as package:
            names = package.namelist()
            if any(name.endswith('.zip') for name in names):
                raise ValueError('Nested archive requires an explicit census policy.')
            top_checkers = [name for name in names if len(Path(name).parts) == 2
                            and Path(name).name == 'checker.py']
            if len(top_checkers) != 1:
                raise ValueError('Unresolved primary checker: ' + entry['name'])
            primary_member = top_checkers[0]
            for member in names:
                if member.endswith('.py'):
                    raw = package.read(member)
                    row = measure(raw)
                    h = row['sha256']
                    occurrence_count += 1
                    origin = {'archive': entry['name'], 'member': member,
                              'source_url': entry['url']}
                    if h not in sources:
                        sources[h] = {**row, 'origins': [], 'selection_reasons': []}
                        source_bytes[h] = raw
                    sources[h]['origins'].append(origin)
                    if member == primary_member:
                        primary.append({'label': PRIMARY_LABELS[entry['name']],
                                        **origin, 'sha256': h,
                                        'immutable_copy': 'primary/' + PRIMARY_LABELS[entry['name']] + '.py'})
                elif member.endswith('.json') and 'manifest' in Path(member).name:
                    raw = package.read(member)
                    try:
                        content = json.loads(raw)
                    except (UnicodeError, ValueError):
                        continue
                    if isinstance(content, dict):
                        documents.append((entry['name'], member, digest(raw), content))

    declarations, group_map = {}, {}
    for archive, member, mh, doc in documents:
        origin = {'archive': archive, 'member': member, 'manifest_sha256': mh}
        for h in hash_list(doc.get('standalone')):
            declarations.setdefault(h, []).append(origin)
        for key in ('historical_groups', 'dependency_groups'):
            for group in doc.get(key, []):
                members = hash_list(group.get('files', group.get('members', [])))
                if not members:
                    continue
                signature = tuple(members)
                record = group_map.setdefault(signature, {'members': members, 'declarations': []})
                record['declarations'].append({**origin, 'label': group.get('label'), 'kind': key})

    missing = sorted((set(declarations) | {h for g in group_map for h in g}) - set(sources))
    if missing:
        raise ValueError('A recorded comparison dependency is absent: ' + repr(missing))
    primary_hashes = {p['sha256'] for p in primary}
    selected = set(declarations) | primary_hashes
    for h, row in sources.items():
        if h in primary_hashes:
            row['selection_reasons'].append('current_primary')
        if h in declarations:
            row['selection_reasons'].append('inherited_declared_standalone')
            row['standalone_declarations'] = declarations[h]
        if (set(row['function_names']) & ACCEPTANCE_NAMES
                and set(row['imports']) <= {'json', 'sys'}):
            selected.add(h)
            row['selection_reasons'].append('static_acceptance_census_with_only_json_sys_imports')
    dependency_members = {h for members in group_map for h in members}
    needed = selected | dependency_members
    for h in dependency_members:
        sources[h]['selection_reasons'].append('historical_dependency_group_member')
    destination.mkdir(parents=True, exist_ok=True)
    (destination / 'sources').mkdir(exist_ok=True)
    (destination / 'primary').mkdir(exist_ok=True)
    for h in sorted(needed):
        path = 'sources/' + h + '.py'
        (destination / path).write_bytes(source_bytes[h])
        sources[h]['file'] = path
    for entry in primary:
        (destination / entry['immutable_copy']).write_bytes(source_bytes[entry['sha256']])
    groups = [{'id': 'historical_' + str(i).zfill(3), **row}
              for i, (_, row) in enumerate(sorted(group_map.items()))]
    manifest = {
        'schema_version': 1, 'repository': snapshot['repository'],
        'commit': snapshot['commit'], 'directory': 'docs/drafts',
        'archives': archive_rows, 'primary': primary,
        'standalone_and_favorable_cores': sorted(selected),
        'historical_groups': groups,
        'sources': {h: sources[h] for h in sorted(needed)},
        'census': {'archive_count': len(archive_rows), 'python_occurrences': occurrence_count,
                   'distinct_python_sources': len(sources),
                   'selected_standalone_or_core_sources': len(selected),
                   'historical_dependency_groups': len(groups),
                   'frozen_source_files': len(needed),
                   'excluded_source_files': len(sources) - len(needed)},
        'selection': (
            'All six primary checkers; the union of every inherited declared standalone '
            'boundary; every source defining check/check_proof/accept/verify with no imports '
            'beyond json/sys, whether or not it supplies a CLI; all inherited historical '
            'dependency groups, counted as the union of their complete source files. '
            'Additional core-only boundaries favor the baseline. All Python members of '
            'the six hash-verified archives were parsed, never imported or executed.'),
        'boundary': (
            'The complete new acceptance program, including public input, syntax validation, '
            'substitution, all logical and numerical rules, CLI and rejection handling. '
            'Python and json/sys are shared runtime assumptions. Raw bytes include all '
            'documentation. AST/normalized/source-token measures remove actual docstrings '
            'and exclude comments. No certification of competitor soundness is implied.'),
    }
    dump(destination / 'manifest.json', manifest)
    dump(destination / 'inventory.json', {'sources': sources, 'census': manifest['census']})
    return manifest


def recount(destination, candidate=None):
    manifest = json.loads((destination / 'manifest.json').read_text())
    measured = {}
    for h, row in manifest['sources'].items():
        value = measure((destination / row['file']).read_bytes())
        if value['sha256'] != h:
            raise ValueError('Frozen source changed: ' + row['file'])
        measured[h] = value
    for entry in manifest['primary']:
        if digest((destination / entry['immutable_copy']).read_bytes()) != entry['sha256']:
            raise ValueError('Immutable primary source changed: ' + entry['label'])
    groups = []
    for group in manifest['historical_groups']:
        groups.append({'id': group['id'], 'members': group['members'],
                       **{key: sum(measured[h][key] for h in set(group['members'])) for key in FIELDS}})
    boundaries = [{'id': h, **measured[h]} for h in manifest['standalone_and_favorable_cores']] + groups
    envelope = {key: min(row[key] for row in boundaries) for key in FIELDS}
    witnesses = {key: [row['id'] for row in boundaries if row[key] == envelope[key]] for key in FIELDS}
    primary = [{**entry, **measured[entry['sha256']]} for entry in manifest['primary']]
    inventory_path = destination / 'inventory.json'
    if inventory_path.exists():
        inventory = json.loads(inventory_path.read_text())['sources']
        exclusions = []
        for h, row in inventory.items():
            if h in manifest['standalone_and_favorable_cores']:
                continue
            if any(row[k] < envelope[k] for k in FIELDS):
                reason = ('Incomplete component, included with its dependencies in historical groups.'
                          if 'historical_dependency_group_member' in row['selection_reasons']
                          else 'Build, measurement, translation, or driver helper; not a standalone acceptance program.')
                exclusions.append({'sha256': h, 'reason': reason, **row})
        dump(destination / 'excluded_small_sources.json', sorted(exclusions, key=lambda r: r['normalized_tokens']))
    result = {
        'python': sys.version, 'platform_python': platform.python_version(),
        'commit': manifest['commit'], 'census': manifest['census'],
        'envelope': envelope, 'envelope_witnesses': witnesses,
        'primary': primary, 'standalone_sources': measured, 'historical_groups': groups,
    }
    if candidate is not None:
        result['candidate'] = {'path': str(candidate), **measure(candidate.read_bytes())}
        result['strictly_below'] = {key: result['candidate'][key] < envelope[key] for key in FIELDS}
    dump(destination / 'metrics.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archives', type=Path, help='Directory containing the pinned six ZIPs and manifest.json; rebuild source census.')
    parser.add_argument('--comparison', type=Path, default=Path(__file__).resolve().parent / 'comparison')
    parser.add_argument('--candidate', type=Path, help='Complete new acceptance program to compare.')
    args = parser.parse_args()
    if args.archives:
        collect(args.archives, args.comparison)
    result = recount(args.comparison, args.candidate)
    print(json.dumps({key: result[key] for key in
                      ('census', 'envelope', 'candidate', 'strictly_below') if key in result}, indent=2))
    if args.candidate and not all(result['strictly_below'].values()):
        raise SystemExit('Candidate is not below every frozen comparison coordinate.')


if __name__ == '__main__':
    main()
