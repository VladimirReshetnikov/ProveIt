SMALLER COMPLETE PROOF KERNELS FOR iPRA
Prepared for Vladimir Reshetnikov -- 6 November 2026

RESULT

This package gives a complete finite proof presentation of full first-order
intuitionistic primitive recursive arithmetic, with an explicit ordinary
theory bi-interpretable with iPRA on the entire number domain. All logical
and arithmetic rules, the derivation of the usual logical connectives,
quantifier-free induction, and both interpretation round trips are proved
in report.pdf.

The new reduction concerns proof representation and the complete checker.
The arithmetic basis is inherited from and credited to the current drafts.
Expected goals reconstruct introduction constructors; a single Boolean
distinguishes guarded introduction from the numerical rule; hypothesis
membership removes proof indices; and elimination validates the major
in a pattern guard.

                         AST nodes    Tokens    Normalized bytes
Current lower envelope        639       603                1928
Strict open kernel            618       596                1863
Erasing open kernel           606       586                1821
Strict theorem kernel         594       579                1804
Erasing theorem kernel        582       569                1762

The strict open kernel is the same-interface comparison and beats every
minimum before either of the two optional savings is used. The theorem
entry point accepts no external hypotheses. Unused-witness erasure permits
an ignored annotation only when both universal matrices are vacuous;
every actually used witness and every public formula remains validated.
All four kernels have exactly the same well-formed theorems.

This is a strict measured improvement over a fixed corpus, not an absolute
minimality theorem. Full mathematical proofs are written in the article;
the package does not claim Lean/Rocq verification of the metatheory.

START HERE

  report.pdf                    Complete article.
  report.tex, sections/*.tex     All LaTeX sources.
  checker.py                    Smallest complete theorem entry point.
  checker_strict.py             Strict theorem entry point.
  checker_open.py               Open sequents, demand-checked witnesses.
  checker_open_strict.py        Open sequents, all witnesses checked.
  FORMAT.txt                    Exact syntax and certificate conventions.
  examples/                     18 literally closed theorem certificates.
  translate_proofs.py           Proof readback, lifting, deduction and closure.
  roundtrip.py                  Reproduce exact proof translation tests.
  validation/                   Frozen source corpus and independent audit.
  comparison/                   Frozen baseline sources and full census.
  compare_snapshot.py           Remeasure complete acceptance programs.
  results/                      Actual measurements and verification summaries.
  reproduce.py                  Rerun measurements, audit and translations.
  build.py                      Rebuild the PDF locally.
  package.py                    Rebuild checksums and the ZIP.
  MANIFEST.sha256               Hashes of every other delivered file.
  LICENSE_SOURCE.txt            ProveIt MIT No Attribution license.

RUN

Use Python 3.10 or newer. All Python code uses only the standard library.
Exact normalization figures were measured with CPython 3.12.14.

  python3 checker.py examples/reflexivity.json
  python3 checker_strict.py examples/residual.json
  python3 reproduce.py

The checker prints ACCEPT and exits zero on success; otherwise it prints
REJECT and exits nonzero. The public acceptance boundary is the CLI.
The internal check(goal,proof,context) requires a validated context.
The theorem entry point supplies an empty context, while open entry
points validate every hypothesis.

Rebuild the article (pdfLaTeX and the packages in report.tex required):

  python3 build.py

Rebuild the ZIP and checksum manifest:

  python3 package.py

All verification, measurement and rebuilding run offline.

EXECUTED EVIDENCE

- Six archive Git-blob hashes verified at the pinned source commit.
- 1482 Python-file occurrences / 338 distinct sources inspected statically.
- 218 standalone or favorable core boundaries and 74 historical dependency
  groups counted, with 241 needed source files frozen for remeasurement.
- Independent syntax/rule implementation: 751 inputs tested against each
  of the two open kernels, 1502 comparisons, zero disagreements.
- 212 labeled inherited records translated forward and backward with
  literal preservation of context and conclusion. These contain 153
  distinct canonical open certificates and 148 distinct open sequents.
- 345 individual deduction steps checked; all 212 outputs universally
  closed and accepted by all four kernels (848 closed-kernel checks).
- All closed outputs reconstructed into the older checker under empty
  context, then reopened to the exact original sequents.
- 18 named closed examples x four kernels x ordinary/optimized Python:
  144 successful CLI runs.
- 56 additional actual CLI boundary checks verify theorem arity, public
  formation, malformed JSON and external-hypothesis rejection.
- Additional tests cover sparse parameter indices, unused witness repair,
  malformed demanded witnesses, and failed-major hypothesis fallback.

The suites overlap; their counts are not independent proofs of correctness.
Python resource limits can reject very large otherwise valid certificates.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: edf7ea445673b29301012177998b0cc66bfabbf0
Directory: docs/drafts

All six current archives were inspected. No repository write or publication
was performed. Exact archive/source/certificate provenance and hashes are
in the manifests. Historical comparison sources were parsed, not executed;
only the audited original goal-directed checker was run for round trips.
