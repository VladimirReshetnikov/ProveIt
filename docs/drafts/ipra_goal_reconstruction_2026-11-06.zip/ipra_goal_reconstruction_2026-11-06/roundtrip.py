"""Reproduce proof-format and deduction translations using only this package.

Run: python3 roundtrip.py --root /path/to/package
No network or third-party modules are required. Source fixtures and the audited
original goal checker are hash-verified before execution. The four new acceptance
programs never import this driver or the untrusted translators.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

KERNELS = {
    'theorem_erasing': 'checker.py',
    'theorem_strict': 'checker_strict.py',
    'open_erasing': 'checker_open.py',
    'open_strict': 'checker_open_strict.py',
}
EXAMPLE_TITLES = {
    'coverage': 'Numerical coverage in the native formula encoding',
    'diff_cancel': 'Cancellation of simultaneous successors in truncated subtraction',
    'diff_diagonal': 'Truncated subtraction on the diagonal',
    'diff_successor_diagonal': 'One-step successor difference',
    'direct_successor_plus_n': 'Successor commutes with addition, direct induction',
    'direct_zero_plus_n': 'Zero plus a number, direct induction',
    'epsilon_zero_implies_equal': 'A zero equality detector implies equality',
    'equal_implies_epsilon_zero': 'Equality makes the equality detector zero',
    'forall_exists_successor': 'Every number has a successor witness',
    'one_residual_implies_equal': 'The unit residual determines the predecessor equality',
    'q_zero_implies_one': 'The auxiliary predecessor selector detects one',
    'reflexivity': 'Equality reflexivity from computation and transport',
    'residual': 'The truncated-subtraction residual identity',
    'successor_injective': 'Successor injectivity from predecessor congruence',
    'successor_plus': 'Successor and addition',
    'zero_diff': 'Truncated subtraction from zero',
    'zero_plus': 'Addition of zero on the left',
    'zero_plus_n': 'Zero plus an arbitrary number',
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def stable(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def load_module(name, path):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def new_accepts(kernel, data):
    try:
        goal, proof, *context = data
        for hypothesis in context:
            kernel.subst(hypothesis)
        return kernel.check(goal, proof, context) is True
    except Exception:
        return False


def old_accepts(kernel, data):
    try:
        goal, proof, *context = data
        for hypothesis in context:
            kernel.subst(hypothesis)
        kernel.check(goal, proof, context)
        return True
    except Exception:
        return False


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def run(root, cli=True):
    root = root.resolve()
    manifest_path = root / 'validation/source_fixture_manifest.json'
    manifest = json.loads(manifest_path.read_text())
    original_path = root / manifest['source_checker']['file']
    require(digest(original_path.read_bytes()) == manifest['source_checker']['sha256'],
            'The pinned original checker changed')
    original = load_module('pinned_goal_checker', original_path)
    kernels = {name: load_module('current_' + name, root / file) for name, file in KERNELS.items()}
    tr = load_module('untrusted_proof_translators', root / 'translate_proofs.py')
    counts = {
        'source_acceptances': 0, 'forward_open_acceptances': 0,
        'backward_open_acceptances': 0, 'lifting_open_acceptances': 0,
        'lifting_backward_acceptances': 0, 'deduction_steps': 0,
        'closed_theorem_acceptances': 0, 'closed_backward_acceptances': 0,
        'reopened_open_acceptances': 0, 'reopened_backward_acceptances': 0,
        'exact_sequent_roundtrips': 0, 'witness_repairs_in_frozen_corpus': 0,
        'cli_runs': 0,
    }
    open_records, theorem_records, example_records, records = [], [], [], []
    for item in manifest['fixtures']:
        source_path = root / item['file']
        raw = source_path.read_bytes()
        require(digest(raw) == item['sha256'], 'Fixture hash mismatch: ' + item['id'])
        data = json.loads(raw)
        goal, proof, *context = data
        require(old_accepts(original, data), 'Original source rejected: ' + item['id'])
        counts['source_acceptances'] += 1
        repairs = []
        canonical = tr.from_original(goal, proof, context, repairs)
        translated = [goal, canonical, *context]
        counts['witness_repairs_in_frozen_corpus'] += len(repairs)
        for name in ('open_erasing', 'open_strict'):
            require(new_accepts(kernels[name], translated), name + ' rejected translation: ' + item['id'])
            counts['forward_open_acceptances'] += 1
        returned = [goal, tr.to_original(goal, canonical, context), *context]
        require(old_accepts(original, returned), 'Original rejected backward proof: ' + item['id'])
        require(returned[0] == data[0] and returned[2:] == data[2:],
                'Forward/backward translation changed the source sequent')
        counts['backward_open_acceptances'] += 1
        lifted_goal, lifted_context = tr.shift(goal), [tr.shift(a) for a in context]
        lifted_proof = tr.lift_proof(canonical)
        lifted = [lifted_goal, lifted_proof, *lifted_context]
        for name in ('open_erasing', 'open_strict'):
            require(new_accepts(kernels[name], lifted), name + ' rejected proof lifting: ' + item['id'])
            counts['lifting_open_acceptances'] += 1
        lifted_old = [lifted_goal, tr.to_original(lifted_goal, lifted_proof, lifted_context), *lifted_context]
        require(old_accepts(original, lifted_old), 'Original rejected lifted proof: ' + item['id'])
        counts['lifting_backward_acceptances'] += 1

        # Check each deduction step, not merely the final empty-context result.
        deduction_goal, deduction_proof = goal, canonical
        for i in reversed(range(len(context))):
            hypothesis = context[i]
            deduction_goal = ['pi', tr.shift(hypothesis), tr.shift(deduction_goal)]
            deduction_proof = [False, tr.lift_proof(deduction_proof)]
            require(new_accepts(kernels['open_strict'],
                               [deduction_goal, deduction_proof, *context[:i]]),
                    'A deduction step failed: ' + item['id'])
            counts['deduction_steps'] += 1
        closed_goal, closed_proof, metadata = tr.compile_theorem(goal, canonical, context)
        require(metadata['hypothesis_free_goal'] == deduction_goal,
                'Deduction compiler and checked steps disagree')
        require(not tr.free_variables(closed_goal), 'The output formula is not a closed sentence')
        theorem = [closed_goal, closed_proof]
        for name, kernel in kernels.items():
            require(new_accepts(kernel, theorem), name + ' rejected closed theorem: ' + item['id'])
            counts['closed_theorem_acceptances'] += 1
        closed_old = [closed_goal, tr.to_original(closed_goal, closed_proof, [])]
        require(old_accepts(original, closed_old), 'Original rejected closed theorem: ' + item['id'])
        counts['closed_backward_acceptances'] += 1

        reopened_goal, reopened_proof = tr.reopen_theorem(closed_goal, closed_proof,
                                                         context, metadata['parameter_binders'])
        require(reopened_goal == goal, 'Universal instantiation/deduction reversal changed the goal')
        reopened = [reopened_goal, reopened_proof, *context]
        for name in ('open_erasing', 'open_strict'):
            require(new_accepts(kernels[name], reopened), name + ' rejected reopened theorem: ' + item['id'])
            counts['reopened_open_acceptances'] += 1
        reopened_old = [goal, tr.to_original(goal, reopened_proof, context), *context]
        require(old_accepts(original, reopened_old), 'Original rejected reopened theorem: ' + item['id'])
        counts['reopened_backward_acceptances'] += 1
        require(reopened_old[0] == data[0] and reopened_old[2:] == data[2:],
                'The closed-theorem round trip changed the exact source sequent')
        counts['exact_sequent_roundtrips'] += 1
        record = {'id': item['id'], 'kind': item['kind'],
                  'source_sha256': item['sha256'], 'repairs': repairs,
                  'hypothesis_count': metadata['hypothesis_count'],
                  'parameter_binders': metadata['parameter_binders'],
                  'open_certificate_sha256': digest(stable(translated).encode()),
                  'closed_certificate_sha256': digest(stable(theorem).encode())}
        records.append(record)
        open_records.append({'id': item['id'], 'data': translated})
        theorem_records.append({'id': item['id'], 'data': theorem,
                                'hypothesis_count': metadata['hypothesis_count'],
                                'parameter_binders': metadata['parameter_binders']})
        if item['kind'] == 'named_example':
            stem = Path(item['file']).stem
            filename = 'examples/' + stem + '.json'
            write_json(root / filename, theorem)
            example_records.append({'file': filename, 'title': EXAMPLE_TITLES.get(stem, stem),
                                    'source_id': item['id'], 'source_sha256': item['sha256'],
                                    'sha256': digest((root / filename).read_bytes()),
                                    'hypothesis_count': metadata['hypothesis_count'],
                                    'parameter_binders': metadata['parameter_binders'],
                                    'closed_sentence': True})

    # Targeted checks of erasing repair and of alias-to-hypothesis normalization.
    truth, bad = tr.TRUE, {'unused_annotation': True}
    vacuous_major = ['pi', truth, truth]
    old_vacuous = [truth, ['use', vacuous_major, ['lam', 0], bad, 0], truth]
    require(old_accepts(original, old_vacuous), 'Pinned erasing-witness example failed')
    repairs = []
    repaired = tr.from_original(*old_vacuous[:2], old_vacuous[2:], repairs)
    require(len(repairs) == 1, 'Vacuous witness was not repaired exactly once')
    require(new_accepts(kernels['open_strict'], [truth, repaired, truth]), 'Strict repaired proof failed')
    raw_new = [truth, [vacuous_major, [False, None], bad, None], truth]
    require(new_accepts(kernels['open_erasing'], raw_new), 'Erasing variant rejected vacuous annotation')
    require(not new_accepts(kernels['open_strict'], raw_new), 'Strict variant accepted invalid annotation')
    canonical_repairs = []
    normalized = tr.normalize_accepted(kernels['open_erasing'], truth, raw_new[1], [truth], canonical_repairs)
    require(len(canonical_repairs) == 1 and normalized == repaired, 'Two repair translations disagree')
    require(old_accepts(original, [truth, tr.to_original(truth, normalized, [truth]), truth]),
            'Original rejected repaired normalization')
    live_major = ['pi', ['=', 0, 0], truth]
    live = [truth, [live_major, None, bad, None], truth, live_major]
    for name in ('open_erasing', 'open_strict'):
        require(not new_accepts(kernels[name], live), 'A demanded malformed witness was accepted')
    try:
        tr.repaired_witness(bad, live_major, [], 'demanded')
    except ValueError:
        pass
    else:
        raise AssertionError('Repair erased a demanded witness')
    aliases = [None, {'ignored': 'hypothesis request'},
               [['pi', truth, ['=', -1, ['s', -1]]], None, -1, None]]
    for alias in aliases:
        normalized = tr.normalize_accepted(kernels['open_erasing'], truth, alias, [truth])
        require(normalized is None, 'Hypothesis alias did not normalize to None')
        require(old_accepts(original, [truth, tr.to_original(truth, normalized, [truth]), truth]),
                'Original rejected normalized hypothesis alias')

    # Sparse high parameter indices test closure order and vacuous quantifiers.
    closure_probes = []
    for term, context in [(7, []), (['r', 0, 7, ['s', 2]], []), (7, [['=', 7, 7]])]:
        goal = ['=', term, term]
        if context:
            proof = None
        else:
            computation = ['=', ['r', -1, term, -1], term]
            proof = [computation, 'r', ['=', 0, tr.shift(term, formula=False)], 'r']
        require(new_accepts(kernels['open_strict'], [goal, proof, *context]), 'Sparse parameter probe invalid')
        closed_goal, closed_proof, info = tr.compile_theorem(goal, proof, context)
        require(not tr.free_variables(closed_goal), 'Sparse probe left free parameters')
        require(new_accepts(kernels['theorem_strict'], [closed_goal, closed_proof]), 'Sparse closed proof failed')
        require(old_accepts(original, [closed_goal, tr.to_original(closed_goal, closed_proof, [])]),
                'Original rejected sparse closed proof')
        reopened_goal, reopened_proof = tr.reopen_theorem(closed_goal, closed_proof,
                                                         context, info['parameter_binders'])
        require(reopened_goal == goal, 'Sparse reopening changed parameter order')
        require(new_accepts(kernels['open_strict'], [goal, reopened_proof, *context]), 'Sparse reopened proof failed')
        require(old_accepts(original, [goal, tr.to_original(goal, reopened_proof, context), *context]),
                'Original rejected sparse reopened proof')
        closure_probes.append({'goal': goal, 'context': context, 'parameter_binders': info['parameter_binders']})

    cli_results = []
    if cli:
        for example in example_records:
            for name, filename in KERNELS.items():
                for optimized in (False, True):
                    command = [sys.executable, *(['-O'] if optimized else []),
                               str(root / filename), str(root / example['file'])]
                    result = subprocess.run(command, capture_output=True, text=True, timeout=30)
                    require(result.returncode == 0 and result.stdout.strip() == 'ACCEPT',
                            'CLI failed: ' + repr(command) + '\n' + result.stdout + result.stderr)
                    counts['cli_runs'] += 1
                    cli_results.append({'example': example['file'], 'kernel': name,
                                        'optimized': optimized, 'returncode': result.returncode,
                                        'stdout': result.stdout.strip()})
    open_keys = {stable(r['data']) for r in open_records}
    sequent_keys = {stable([r['data'][0], *r['data'][2:]]) for r in open_records}
    theorem_keys = {stable(r['data']) for r in theorem_records}
    summary = {
        'status': 'PASS', 'python': sys.version,
        'source_commit': manifest['commit'], 'source_archive': manifest['source_archive'],
        'source_manifest_sha256': digest(manifest_path.read_bytes()),
        'original_checker_sha256': manifest['source_checker']['sha256'],
        'candidate_sha256': {name: digest((root / file).read_bytes()) for name, file in KERNELS.items()},
        'translator_sha256': digest((root / 'translate_proofs.py').read_bytes()),
        'counts': counts, 'source_records': len(records),
        'distinct_canonical_open_certificates': len(open_keys),
        'distinct_open_sequents': len(sequent_keys),
        'distinct_closed_certificates': len(theorem_keys),
        'named_closed_examples': len(example_records), 'cli_enabled': cli,
        'max_parameter_binders_in_corpus': max(r['parameter_binders'] for r in records),
        'targeted_validation': {'vacuous_witness_repair_cases': 1,
                               'demanded_witness_rejection_cases': 1,
                               'hypothesis_alias_cases': len(aliases),
                               'sparse_parameter_closure_cases': closure_probes},
        'qualification': (
            'These are repeated checks and translations of 212 labeled source records, '
            'not independent proofs of the metatheory. Counts overlap. Every translated '
            'source sequent is preserved literally. Theorem outputs have no assumptions '
            'and no free numerical variables. '
            + ('All four public CLIs are tested in ordinary and optimized Python on '
               '18 named closed certificates.' if cli else 'CLI subprocess checks were skipped in this run.')),
        'records': records, 'cli_results': cli_results,
    }
    write_json(root / 'validation/reconstructed_corpus.json', open_records)
    write_json(root / 'validation/closed_corpus.json', theorem_records)
    write_json(root / 'examples/manifest.json', {'examples': example_records,
                                              'qualification': 'Each file contains [closed_goal, canonical_proof]; there are no open assumptions or free goal variables.'})
    write_json(root / 'validation/roundtrip_results.json', summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--skip-cli', action='store_true', help='Skip subprocess checks; all structural translations still run.')
    args = parser.parse_args()
    result = run(args.root, cli=not args.skip_cli)
    print(json.dumps({key: result[key] for key in
                      ('status', 'source_records', 'distinct_canonical_open_certificates',
                       'distinct_open_sequents', 'distinct_closed_certificates',
                       'named_closed_examples', 'counts')}, indent=2))


if __name__ == '__main__':
    main()
