"""Check the actual theorem/open CLI boundary, including optimized Python."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    root = parser.parse_args().root.resolve()
    truth = ["=", -1, -1]
    falsehood = ["=", -1, ["s", -1]]
    equation = ["=", ["r", -1, -1, -1], -1]
    proof = [equation, "r", ["=", 0, -1], "r"]
    cases = [
        ("valid_theorem", json.dumps([truth, proof]), True, True),
        ("falsehood_without_premise", json.dumps([falsehood, None]), False, False),
        ("external_hypothesis", json.dumps([falsehood, None, falsehood]), False, True),
        ("nested_hypothesis_injection", json.dumps([falsehood, None, [falsehood]]), False, False),
        ("malformed_unused_hypothesis", json.dumps([truth, proof, ["=", True, True]]), False, False),
        ("malformed_goal", json.dumps([["=", True, True], None]), False, False),
        ("invalid_json", "[", False, False),
    ]
    kernels = ("checker.py", "checker_strict.py", "checker_open.py", "checker_open_strict.py")
    results = []
    with tempfile.TemporaryDirectory(prefix="ipra_cli_") as directory:
        for label, source, theorem_expected, open_expected in cases:
            path = Path(directory) / (label + ".json")
            path.write_text(source)
            for kernel in kernels:
                expected = open_expected if "_open" in kernel else theorem_expected
                for optimized in (False, True):
                    command = [sys.executable, *(["-O"] if optimized else []),
                               str(root / kernel), str(path)]
                    result = subprocess.run(command, capture_output=True, text=True, timeout=30)
                    passed = ((result.returncode == 0) == expected and
                              result.stdout.strip() == ("ACCEPT" if expected else "REJECT"))
                    results.append({"case": label, "kernel": kernel, "optimized": optimized,
                                    "expected_accept": expected, "returncode": result.returncode,
                                    "stdout": result.stdout.strip(), "passed": passed})
    output = {"status": "PASS" if all(r["passed"] for r in results) else "FAIL",
              "runs": len(results), "kernel_sha256": {
                  k: hashlib.sha256((root / k).read_bytes()).hexdigest() for k in kernels},
              "results": results}
    (root / "results" / "cli_boundary.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"status": output["status"], "runs": output["runs"]}))
    if output["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
