"""Independent syntax, scope, and hostile-JSON audit of both open checkers.

The reference uses separate term/formula parsers and separate lifting and
instantiation operations.  It does not import the candidate's substitution
routine.  Run with Python 3.11+:

    python3 validation/independent_audit.py --root .

The two audited files are checker_open_strict.py and checker_open.py.
"""

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import random


def demand(condition):
    if not condition:
        raise ValueError("invalid reference certificate")


def term(a):
    if type(a) is int:
        demand(a >= -1)
        return a
    demand(type(a) is list and bool(a))
    if a[0] == "s" and len(a) == 2:
        return ("s", term(a[1]))
    if a[0] == "r" and len(a) == 4:
        return ("r", term(a[1]), term(a[2]), term(a[3]))
    raise ValueError("not a term")


def formula(a):
    demand(type(a) is list and bool(a))
    if a[0] == "=" and len(a) == 3:
        return ("=", term(a[1]), term(a[2]))
    if a[0] == "pi" and len(a) == 3:
        return ("pi", formula(a[1]), formula(a[2]))
    if a[0] == "ex" and len(a) == 2:
        return ("ex", formula(a[1]))
    raise ValueError("not a formula")


def lift_term(t, amount=1, bound=0):
    if type(t) is int:
        return t + amount if t >= bound else t
    if t[0] == "s":
        return ("s", lift_term(t[1], amount, bound))
    return ("r", lift_term(t[1], amount, bound),
            lift_term(t[2], amount, bound),
            lift_term(t[3], amount, bound + 2))


def lift_formula(a, amount=1, bound=0):
    if a[0] == "=":
        return ("=", lift_term(a[1], amount, bound),
                lift_term(a[2], amount, bound))
    if a[0] == "ex":
        return ("ex", lift_formula(a[1], amount, bound + 1))
    return ("pi", lift_formula(a[1], amount, bound + 1),
            lift_formula(a[2], amount, bound + 1))


def inst_term(t, values, remove, bound=0):
    if type(t) is int:
        if t < bound:
            return t
        index = t - bound
        if index < len(values):
            return lift_term(values[index], bound)
        return t - remove
    if t[0] == "s":
        return ("s", inst_term(t[1], values, remove, bound))
    return ("r", inst_term(t[1], values, remove, bound),
            inst_term(t[2], values, remove, bound),
            inst_term(t[3], values, remove, bound + 2))


def inst_formula(a, values, remove, bound=0):
    if a[0] == "=":
        return ("=", inst_term(a[1], values, remove, bound),
                inst_term(a[2], values, remove, bound))
    if a[0] == "ex":
        return ("ex", inst_formula(a[1], values, remove, bound + 1))
    return ("pi", inst_formula(a[1], values, remove, bound + 1),
            inst_formula(a[2], values, remove, bound + 1))


def occurs_term(t, depth=0):
    if type(t) is int:
        return t == depth
    if t[0] == "s":
        return occurs_term(t[1], depth)
    return (occurs_term(t[1], depth) or occurs_term(t[2], depth)
            or occurs_term(t[3], depth + 2))


def occurs_formula(a, depth=0):
    if a[0] == "=":
        return occurs_term(a[1], depth) or occurs_term(a[2], depth)
    if a[0] == "ex":
        return occurs_formula(a[1], depth + 1)
    return occurs_formula(a[1], depth + 1) or occurs_formula(a[2], depth + 1)


def reference(a, p, context, strict=True):
    def recur(b, q, g):
        return reference(b, q, g, strict)

    if (a[0] == "pi" and type(p) is list and len(p) == 2
            and type(p[0]) is bool):
        h, b = a[1:]
        if p[0]:
            if h != inst_formula(b, (-1,), 0):
                return False
            h = b if b[0] == "=" else h
            b = inst_formula(b, (("s", 0),), 0)
        return recur(b, p[1], [lift_formula(c) for c in context] + [h])
    if a[0] == "ex" and type(p) is list and len(p) == 2:
        witness = term(p[0])
        h = ("=", 0, lift_term(witness))
        return recur(a[1], p[1], [lift_formula(c) for c in context] + [h])
    if (type(p) is list and len(p) >= 2 and type(p[0]) is list
            and len(p[0]) >= 1):
        major = formula(p[0])
        if recur(major, p[1], context):
            args = p[2:]
            if major[0] == "ex":
                demand(len(args) == 1)
                return recur(lift_formula(a), args[0],
                             [lift_formula(c) for c in context] + [major[1]])
            demand(len(args) == 2)
            if major[0] == "pi":
                # Independently reconstruct the erased witness as zero only
                # when it has no free occurrence in either opened matrix.
                used = occurs_formula(major[1]) or occurs_formula(major[2])
                witness = term(args[0]) if strict or used else -1
                before = inst_formula(major[1], (witness,), 1)
                after = inst_formula(major[2], (witness,), 1)
            else:
                motive = formula(args[0])
                before = inst_formula(motive, (major[1],), 1)
                after = inst_formula(motive, (major[2],), 1)
            return a == after and recur(before, args[1], context)
    if a[0] == "=" and type(a[1]) is tuple and a[1][0] == "r" and p == "r":
        _, n, initial, body = a[1]
        if n == -1:
            return a[2] == initial
        demand(type(n) is tuple and n[0] == "s")
        previous = ("r", n[1], initial, body)
        return a[2] == inst_term(body, (previous, n[1]), 2)
    return a in context


def reference_accept(data, strict=True):
    try:
        demand(type(data) is list and len(data) >= 2)
        a, p, *g = data
        return bool(reference(formula(a), p, [formula(c) for c in g], strict))
    except Exception:
        return False


def candidate_accept(module, data):
    try:
        a, p, *g = data
        for c in g:
            module.subst(c)
        return bool(module.check(a, p, g))
    except Exception:
        return False


def array(a):
    return [array(c) for c in a] if type(a) is tuple else a


def S(t):
    return ["s", t]


def R(n, a, h):
    return ["r", n, a, h]


def E(s, t):
    return ["=", s, t]


def P(h, b):
    return ["pi", h, b]


def X(a):
    return ["ex", a]


def lifted(t, amount=1):
    return array(lift_term(term(t), amount))


def refl(t):
    """Reflexivity derived using two occurrences of an R0 computation."""
    major = E(R(-1, t, -1), t)
    return [major, "r", E(0, lifted(t)), "r"]


def successor_result(n, initial, h):
    return array(inst_term(term(h), (term(R(n, initial, h)), term(n)), 2))


def nodes(a, prefix=()):
    yield prefix, a
    if type(a) is list:
        for i, b in enumerate(a):
            yield from nodes(b, prefix + (i,))


def replaced(a, path, value):
    b = copy.deepcopy(a)
    if not path:
        return copy.deepcopy(value)
    p = b
    for index in path[:-1]:
        p = p[index]
    p[path[-1]] = copy.deepcopy(value)
    return b


def fixtures():
    cases = []

    def put(name, data, accepted, category, erasing=None):
        cases.append({"name": name, "data": data, "expected": accepted,
                      "expected_erasing": accepted if erasing is None else erasing,
                      "category": category})

    truth = E(-1, -1)
    variable_eq = E(0, 0)
    put("zero_reflexivity", [truth, refl(-1)], True, "arithmetic")
    put("parameter_reflexivity", [variable_eq, refl(0)], True, "arithmetic")
    put("guarded_identity", [P(variable_eq, variable_eq), [False, None]], True, "logic")
    put("nested_guarded_identity", [P(truth, P(E(0, 1), E(0, 1))),
                                     [False, [False, None]]], True, "scope")
    put("pack_parameter", [X(E(0, 1)), [0, None]], True, "scope")
    deep = R(S(0), R(-1, 1, 3), R(1, 2, S(4)))
    put("deep_recursor_reflexivity", [E(deep, deep), refl(deep)], True, "scope")
    t = R(-1, 0, R(1, 2, S(4)))
    put("pack_nested_recursor", [X(E(t, t)), [0, refl(t)]], True, "scope")
    m = X(E(0, 0))
    put("exists_elim_parameter", [E(0, 0), [m, None, refl(1)], m], True, "scope")
    put("exists_elim_escape", [E(0, -1), [X(E(0, -1)), None, None], X(E(0, -1))],
        False, "eigenvariable")
    body = E(R(-1, -1, 2), R(-1, -1, 2))
    put("exists_escape_recursor_body", [body, [X(body), None, None], X(body)],
        False, "eigenvariable")
    body = P(truth, X(E(2, -1)))
    put("exists_escape_two_formula_binders", [body, [X(body), None, None], X(body)],
        False, "eigenvariable")
    eq = E(0, 1)
    motive = X(E(0, 1))
    put("transport_below_exists", [X(E(0, 2)), [eq, None, motive, [0, None]], eq],
        True, "scope")
    motive = E(R(S(-1), -1, 2), 0)
    put("transport_below_recursor", [E(R(S(-1), -1, 3), 1), [eq, None, motive, "r"], eq],
        True, "scope")
    put("transport_capture_mutation", [X(E(0, 2)), [eq, None, X(E(0, 0)), [0, None]], eq],
        False, "scope")
    nat_body = E(R(0, -1, S(0)), 0)
    nat_base = E(R(-1, -1, S(0)), -1)
    nat_motive = E(R(S(1), -1, S(0)), S(0))
    nat_step = [nat_body, None, nat_motive, "r"]
    put("induction_uses_equation_hypothesis", [P(nat_base, nat_body), [True, nat_step]],
        True, "induction")
    put("induction_reflexivity", [P(truth, variable_eq), [True, refl(S(0))]],
        True, "induction")
    put("induction_wrong_base", [P(E(-1, S(-1)), variable_eq), [True, refl(S(0))]],
        False, "induction")
    b = X(E(0, 1))
    put("nonequation_numerical_cases", [P(X(E(0, -1)), b), [True, [S(0), None]]],
        True, "induction")
    b = X(E(1, 1))
    # This proof would pass if an existential matrix incorrectly acquired
    # the full B(x) induction hypothesis merely because its body is atomic.
    q = [b, None, [-1, refl(S(2))]]
    put("forbidden_nonequation_induction_hypothesis", [P(X(truth), b), [True, q]],
        False, "induction")
    for h in (0, 1, 2, R(0, 1, R(2, 3, 4))):
        result = successor_result(0, 1, h)
        put("recursor_argument_order_" + str(len(cases)), [E(R(S(0), 1, h), result), "r"],
            True, "arithmetic")
    put("recursor_unknown_counter", [E(R(0, -1, 0), -1), "r"], False, "arithmetic")
    put("recursor_non_successor_counter", [E(R(R(-1, -1, -1), -1, 0), -1), "r"],
        False, "arithmetic")
    put("failed_application_hypothesis_fallback", [truth, [P(truth, E(0, 0)), None, -1, None], truth],
        True, "logic")
    identity = P(variable_eq, variable_eq)
    for mode in [0, 1, 0.0, 1.0, None, "false", "true", {}, [], -1]:
        put("non_boolean_mode_" + str(len(cases)), [identity, [mode, None]], False, "proof_sort")
    put("unused_dictionary_hypothesis_certificate", [truth, {"arbitrary": [True, None]}, truth],
        True, "logic")

    hostile = [None, False, True, -2, -1.0, 0.0, 1.0, "0", "s", "rxy", [], {},
               {"s": 0}, {"s": 0, "0": 1}, ["s"], ["s", -1, -1],
               ["r", -1, -1], ["r", -1, -1, None], ["=", -1, -1],
               ["pi", truth, truth], ["ex", truth]]
    principal = P(truth, truth)
    for i, bad in enumerate(hostile):
        put(f"vacuous_pi_bad_witness_{i}", [truth, [principal, None, bad, refl(-1)], principal],
            False, "strict_witness", erasing=True)
        put(f"vacuous_pack_bad_witness_{i}", [X(truth), [bad, refl(-1)]],
            False, "strict_witness")
        put(f"r0_bad_unused_update_{i}", [E(R(-1, -1, bad), -1), "r"],
            False, "strict_syntax")
        # A variable used in either matrix must force full validation of its
        # replacement, including use below binders and in dead R0 updates.
        for name, used_principal, goal in [
            ("antecedent", P(E(0, 0), truth), truth),
            ("consequent", P(truth, E(0, 0)), truth),
            ("nested_binders", P(truth, X(P(truth, E(2, 2)))),
             X(P(truth, truth))),
            ("recursor_body", P(truth, E(R(-1, -1, 2), -1)),
             E(R(-1, -1, -1), -1)),
        ]:
            put(f"used_bad_pi_witness_{name}_{i}",
                [goal, [used_principal, None, bad, refl(-1)], used_principal],
                False, "demand_validation")
    # The zeros below the inner logical binders are locally bound, so they
    # do not count as occurrences of the outer universal's variable.
    outer_vacuous = P(X(E(0, 0)), P(E(0, 0), E(0, 0)))
    for i, bad in enumerate([None, {"unused": [False, 0.0]}]):
        put(f"nested_vacuous_pi_witness_{i}",
            [P(E(0, 0), E(0, 0)),
             [outer_vacuous, None, bad, [-1, refl(0)]], outer_vacuous],
            False, "demand_validation", erasing=True)
    bad_formulas = [None, False, 0, -1, 1.0, "=", {}, {"=": 0, "0": 1, "1": 2},
                    ["=", -1], ["=", -1, -1, -1], ["s", -1],
                    ["ex", -1], ["pi", truth], ["pi", truth, ["s", -1]]]
    for i, bad in enumerate(bad_formulas):
        put(f"unused_bad_hypothesis_{i}", [truth, refl(-1), bad], False, "public_syntax")
        put(f"bad_equality_motive_{i}", [truth, [truth, refl(-1), bad, refl(-1)]],
            False, "strict_syntax")
    # A deeply nested canonical statement is corrupted at every numerical
    # leaf and every array node.  All public syntax must be checked, even
    # when the proof is just context membership.
    base = P(E(R(S(0), -1, R(1, 2, S(4))), 3), X(P(truth, E(R(2, 1, 4), 0))))
    for path, node in list(nodes(base)):
        if type(node) is int:
            for bad in [False, True, float(node), None, -2, {}, {"s": 1}, "0"]:
                malformed = replaced(base, path, bad)
                put("deep_leaf_corruption_" + str(len(cases)), [malformed, None, malformed],
                    False, "public_syntax")
        if type(node) is list:
            for bad in [node + [-1], node[:-1], {str(i): x for i, x in enumerate(node)}]:
                malformed = replaced(base, path, bad)
                put("deep_node_corruption_" + str(len(cases)), [malformed, None, malformed],
                    False, "public_syntax")
    return cases


def random_cases(count=400, seed=20261106):
    rng = random.Random(seed)

    def t(depth):
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice([-1, 0, 1, 2, 3, 8, 100])
        if rng.randrange(2):
            return S(t(depth - 1))
        return R(t(depth - 1), t(depth - 1), t(depth - 1))

    def f(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return E(t(2), t(2))
        if rng.randrange(2):
            return X(f(depth - 1))
        return P(f(depth - 1), f(depth - 1))

    result = []
    for i in range(count):
        kind = i % 6
        if kind == 0:
            a = t(3)
            data = [E(a, a), refl(a)]
        elif kind == 1:
            a = f(3)
            data = [P(a, a), [False, None]]
        elif kind == 2:
            a = t(3)
            data = [X(E(0, lifted(a))), [a, None]]
        elif kind == 3:
            a, h = t(3), t(3)
            data = [E(R(-1, a, h), a), "r"]
        elif kind == 4:
            n, a, h = t(2), t(2), t(3)
            data = [E(R(S(n), a, h), successor_result(n, a, h)), "r"]
        else:
            a = f(3)
            data = [a, None, a]
        result.append({"name": f"generated_positive_{i}", "data": data,
                       "expected": True, "expected_erasing": True,
                       "category": "generated"})
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path,
                        default=Path(__file__).resolve().parent.parent)
    args = parser.parse_args()
    root = args.root.resolve()
    modules = {}
    for name in ("checker_open_strict", "checker_open"):
        spec = importlib.util.spec_from_file_location(name, root / (name + ".py"))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        modules[name] = module
    cases = fixtures() + random_cases()
    failures = []
    counts = {}
    verdicts = {name: {"accept": 0, "reject": 0} for name in modules}
    for case in cases:
        counts[case["category"]] = counts.get(case["category"], 0) + 1
        for name, module in modules.items():
            strict = name.endswith("_strict")
            expected = case["expected"] if strict else case["expected_erasing"]
            got = candidate_accept(module, case["data"])
            independent = reference_accept(case["data"], strict)
            verdicts[name]["accept" if expected else "reject"] += 1
            if got != expected or independent != expected:
                failures.append({**case, "variant": name, "expected": expected,
                                 "candidate": got, "reference": independent})
    # Exercise Python's actual JSON decoding, including nonfinite floats,
    # escaped keys, duplicate object keys, and integer negative zero.
    raw = [
        ('[["=",true,true],null,["=",true,true]]', False),
        ('[["=",0.0,0.0],null,["=",0.0,0.0]]', False),
        ('[["=",NaN,NaN],null,["=",NaN,NaN]]', False),
        ('[["=",Infinity,Infinity],null,["=",Infinity,Infinity]]', False),
        ('[["=",1e309,1e309],null,["=",1e309,1e309]]', False),
        ('[{"=":0,"x":1,"x":2},null,{"=":0,"x":1,"y":2}]', False),
        ('[["=",["s",-1],["s",-1]],null,["=",["\\u0073",-1],["s",-1]]]', True),
        ('[["=",-0,0],null,["=",0,0]]', True),
    ]
    for i, (source, expected) in enumerate(raw):
        data = json.loads(source)
        for name, module in modules.items():
            got = candidate_accept(module, data)
            independent = reference_accept(data, name.endswith("_strict"))
            verdicts[name]["accept" if expected else "reject"] += 1
            if got != expected or independent != expected:
                failures.append({"name": f"raw_json_{i}", "source": source,
                                 "variant": name, "expected": expected,
                                 "candidate": got, "reference": independent})
    report = {"status": "PASS" if not failures else "FAIL",
              "candidate_sha256": {
                  name + ".py": hashlib.sha256((root / (name + ".py")).read_bytes()).hexdigest()
                  for name in modules},
              "fixture_count": len(cases), "raw_json_count": len(raw),
              "checker_comparisons": len(modules) * (len(cases) + len(raw)),
              "expected_verdicts": verdicts,
              "categories": counts, "failures": failures,
              "scope": "Finite regression and independent implementation comparison; not a formal soundness proof."}
    output = root / "results" / "independent_audit.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
