"""Rebuild the article locally with pdfLaTeX; no network access is needed."""
from pathlib import Path
import os
import shutil
import subprocess


def main():
    root = Path(__file__).resolve().parent
    build = root / ".build"
    build.mkdir(exist_ok=True)
    env = dict(os.environ)
    env["SOURCE_DATE_EPOCH"] = "1794021716"
    env["FORCE_SOURCE_DATE"] = "1"
    command = [
        "pdflatex", "-halt-on-error", "-interaction=nonstopmode",
        "-file-line-error", "-output-directory=" + str(build), "report.tex",
    ]
    for run in range(3):
        result = subprocess.run(command, cwd=root, env=env,
                                capture_output=True, text=True)
        (build / ("pass_" + str(run + 1) + ".txt")).write_text(result.stdout + result.stderr)
        if result.returncode:
            print((result.stdout + result.stderr)[-10000:])
            raise SystemExit(result.returncode)
    log = (build / "report.log").read_text(errors="replace")
    if "There were undefined references" in log:
        raise SystemExit("Unresolved references remain.")
    shutil.copyfile(build / "report.pdf", root / "report.pdf")
    print("Built report.pdf")
    for line in log.splitlines():
        if "Overfull" in line or "Output written" in line:
            print(line)


if __name__ == "__main__":
    main()
