PRA FROM A SINGLE OCCURRENCE BOUNDARY EQUATION
2 November 2026

START HERE
  report.pdf  Complete report and proofs.
  report.tex  LaTeX entry point; sections/ contains all source sections.
  AXIOMS.txt  Standalone complete specifications and exact scope.

MAIN RESULT
  A numerical boundary schema containing one occurrence of an arbitrary
  test term has full size T+28, including four recursor descriptor nodes.
  The inspected current one-occurrence table costs T+43.

  The raw-term hybrid emits the shortest of three specified templates:
    min(2T+i+17, 2T+22, T+28).
  Its fixed basis may be the same 17-node basis as the existing fused
  theory; charge the common 19-node diagonal-recovery instance once in
  finite proof support. The saturated fixed basis costs 24 nodes.

  A separate atomic native presentation starts with only 0,S and one
  recursion constructor. It needs just 0 != S(0) as a fixed arithmetic
  axiom and restricts the boundary generator to pairs of terms.

  Both theories are proved conservatively definitionally equivalent to
  first-order PRA, with whole-carrier identity round trips. Classical
  and intuitionistic versions are treated separately with matching logic.

SOURCE AUDIT
  Snapshot: 356163ca545206e31dd6b634f9c9bfc1596b3cac
  Seven current archives and six archived archives inspected.
  All seven current archives improve the prior iteration in some respect.
  provenance/draft_audit_matrix.json and .tsv contain the full inventory,
  hashes, recipe variants, and inspected source sections.

VERIFICATION
  Run: python3 artifacts/verify.py
  This checks syntax sizes, frozen descriptor substitution, endpoint truth
  tables, and millions of finite boundary-witness matrix instances.
  Results: artifacts/verification_results.json
  These checks are NOT a full proof-assistant formalization. Complete
  first-order interpretation arguments are in the report. No Lean/Rocq
  kernel verification is claimed.

BUILD
  Run: sh build.sh
  Requires Python 3 (standard library only) and a normal pdflatex setup
  with amsmath, amsthm, mathtools, lmodern, microtype, geometry, booktabs,
  tabularx, enumitem, xcolor, hyperref, and fancyhdr.

COMPARISON LIMIT
  The precise improvement is in the drafts' shared, descriptor-charged
  tree metric, with fixed basis and finite support accounted for.
  No encoding-independent absolutely simplest PRA theory is asserted.
  The report includes Further research questions.
