#!/usr/bin/env python3
"""Independent finite and syntactic checks for single-occurrence PRA.

This is original verification code written for the accompanying report.  It
does not load or execute code from the source archives.  It checks exact
expanded syntax-tree sizes, frozen-descriptor substitution, the finite
Boolean boundary kernel, and explicit witnesses on finite value tables.

It is NOT a proof assistant, a verifier of arbitrary PRA derivations, or a
formalization of the full arithmetic bootstrap and bi-interpretation.  In
particular, finite tests do not prove the assertions for nonstandard models.

Run with the Python standard library only:
    python3 artifacts/verify.py --output artifacts/verification_results.json

Quantifier binders count once; their variable labels have no second charge.
A generated R_h application has an active application node and two active
arguments.  Full size additionally charges its frozen descriptor h at EVERY
occurrence, recursively, with no free sharing.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import product
import json
from pathlib import Path
import platform
import time
from typing import Mapping


@dataclass(frozen=True)
class Syntax:
    kind: str
    label: str = ""
    children: tuple["Syntax", ...] = ()
    descriptor: "Syntax | None" = None

    def size(self, *, full: bool = False) -> int:
        answer = 1 + sum(child.size(full=full) for child in self.children)
        if full and self.descriptor is not None:
            answer += self.descriptor.size(full=True)
        return answer

    def as_data(self):
        data = {"kind": self.kind, "label": self.label}
        if self.children:
            data["children"] = [child.as_data() for child in self.children]
        if self.descriptor is not None:
            data["frozen_descriptor"] = self.descriptor.as_data()
        return data


def var(name: str) -> Syntax:
    return Syntax("variable", name)


def app(name: str, *arguments: Syntax) -> Syntax:
    return Syntax("application", name, tuple(arguments))


ZERO = Syntax("constant", "0")
FALSE = Syntax("falsity", "false")
X, A, B, N = (var(name) for name in ("x", "a", "b", "n"))
V, W = var("v"), var("w")


def succ(term: Syntax) -> Syntax:
    return app("S", term)


ONE = succ(ZERO)


def recursor(body: Syntax, counter: Syntax, initial: Syntax) -> Syntax:
    return Syntax("application", "R", (counter, initial), body)


def q(first: Syntax, second: Syntax) -> Syntax:
    return recursor(W, first, second)


def z(first: Syntax, second: Syntax) -> Syntax:
    return recursor(ZERO, first, second)


def chi(first: Syntax, second: Syntax) -> Syntax:
    return app("chi", first, second)


def equal(first: Syntax, second: Syntax) -> Syntax:
    return Syntax("equality", "=", (first, second))


def conjunction(first: Syntax, second: Syntax) -> Syntax:
    return Syntax("connective", "and", (first, second))


def disjunction(first: Syntax, second: Syntax) -> Syntax:
    return Syntax("connective", "or", (first, second))


def implication(first: Syntax, second: Syntax) -> Syntax:
    return Syntax("connective", "implies", (first, second))


def quantified(prefix: tuple[tuple[str, str], ...], matrix: Syntax) -> Syntax:
    result = matrix
    for quantifier, name in reversed(prefix):
        result = Syntax("quantifier", f"{quantifier} {name}", (result,))
    return result


def substitute_active(node: Syntax, replacements: Mapping[str, Syntax]) -> Syntax:
    """Simultaneous substitution in a term or quantifier-free formula.

    Stored R_h descriptors are frozen and deliberately not traversed.  This
    helper rejects binders rather than pretending to implement a general
    capture-avoiding substitution algorithm.  All payloads here are terms or
    quantifier-free formulas; binders are added only by the axiom builders.
    """
    if node.kind == "quantifier":
        raise ValueError("This helper accepts only binder-free payload syntax.")
    if node.kind == "variable":
        return replacements.get(node.label, node)
    return Syntax(
        node.kind,
        node.label,
        tuple(substitute_active(child, replacements) for child in node.children),
        node.descriptor,
    )


def active_occurrences(node: Syntax, variable: str) -> int:
    count = int(node.kind == "variable" and node.label == variable)
    return count + sum(active_occurrences(c, variable) for c in node.children)


def descriptor_sequence(node: Syntax) -> tuple[Syntax, ...]:
    """Record descriptors of active applications, preserving occurrence order."""
    result = () if node.descriptor is None else (node.descriptor,)
    for child in node.children:
        result += descriptor_sequence(child)
    return result


def old_fused(payload: Syntax) -> Syntax:
    at_b = substitute_active(payload, {"x": B})
    at_successor = substitute_active(payload, {"x": succ(B)})
    matrix = equal(
        chi(B, q(z(at_successor, succ(B)), N)),
        succ(z(at_b, B)),
    )
    return quantified((("forall", "a"), ("forall", "n"), ("exists", "b")), matrix)


def old_fused_successor_shared(payload: Syntax) -> Syntax:
    d = var("d")
    at_b = substitute_active(payload, {"x": B})
    at_d = substitute_active(payload, {"x": d})
    matrix = conjunction(
        equal(d, succ(B)),
        equal(chi(B, q(z(at_d, d), N)), succ(z(at_b, B))),
    )
    return quantified(
        (("forall", "a"), ("forall", "n"), ("exists", "b"), ("exists", "d")),
        matrix,
    )


def old_fused_payload_table(payload: Syntax) -> Syntax:
    r, s, y = var("r"), var("s"), var("y")
    kernel = equal(chi(B, q(z(r, succ(B)), N)), succ(z(s, B)))
    graph = disjunction(
        conjunction(equal(X, B), equal(y, s)),
        conjunction(equal(X, succ(B)), equal(y, r)),
    )
    table = quantified(
        (("forall", "x"), ("forall", "y")),
        implication(graph, equal(payload, y)),
    )
    return quantified(
        (("forall", "a"), ("forall", "n"), ("exists", "b"),
         ("exists", "r"), ("exists", "s")),
        conjunction(kernel, table),
    )


def new_single_occurrence(payload: Syntax) -> Syntax:
    left_error = q(chi(B, ZERO), chi(X, B))
    right_error = q(chi(B, N), chi(X, succ(B)))
    matrix = equal(q(z(payload, succ(left_error)), right_error), ZERO)
    return quantified(
        (("forall", "a"), ("forall", "n"), ("exists", "b"), ("forall", "x")),
        matrix,
    )


def choose_hybrid(payload: Syntax) -> tuple[str, Syntax]:
    """Emit the smallest full-size raw-tail sentence, with specified tie order.

    This decision reads syntax only.  The generator's own source bytes are
    not part of the emitted-sentence tree metric.
    """
    choices = (
        ("FB", old_fused(payload)),
        ("FB-S", old_fused_successor_shared(payload)),
        ("SC", new_single_occurrence(payload)),
    )
    return min(choices, key=lambda choice: choice[1].size(full=True))


def native_boundary(predicate: Syntax) -> Syntax:
    at_b = substitute_active(predicate, {"x": B})
    at_successor = substitute_active(predicate, {"x": succ(B)})
    matrix = conjunction(
        disjunction(equal(B, ZERO), at_b),
        implication(at_successor, equal(B, N)),
    )
    return quantified((("forall", "a"), ("forall", "n"), ("exists", "b")), matrix)


def native_boundary_successor_shared(predicate: Syntax) -> Syntax:
    d = var("d")
    at_b = substitute_active(predicate, {"x": B})
    at_d = substitute_active(predicate, {"x": d})
    matrix = conjunction(
        equal(d, succ(B)),
        conjunction(
            disjunction(equal(B, ZERO), at_b),
            implication(at_d, equal(B, N)),
        ),
    )
    return quantified(
        (("forall", "a"), ("forall", "n"), ("exists", "b"), ("exists", "d")),
        matrix,
    )


def one_copy_atomic_guarded(left: Syntax, right: Syntax) -> Syntax:
    """An auxiliary one-copy atomic template; not the primary SC schema."""
    guard = disjunction(equal(X, B), equal(X, succ(B)))
    matching_bit = equal(chi(left, right), chi(X, B))
    exemption = equal(B, q(chi(X, B), N))
    return quantified(
        (("forall", "a"), ("forall", "n"), ("exists", "b"), ("forall", "x")),
        implication(guard, disjunction(matching_bit, exemption)),
    )


def counts(node: Syntax) -> dict[str, int]:
    return {"active": node.size(), "full": node.size(full=True)}


def check_counts_and_substitution() -> dict:
    long_successor = X
    for _ in range(15):
        long_successor = succ(long_successor)
    nested_body = chi(
        recursor(succ(V), V, W),
        recursor(q(V, W), W, V),
    )
    payloads = {
        "zero": ZERO,
        "variable_x": X,
        "parameter_a": A,
        "one": ONE,
        "equality_bit": chi(X, A),
        "fifteen_successors": long_successor,
        "simple_recursor": recursor(succ(V), X, A),
        "nested_frozen_descriptors": recursor(nested_body, X, A),
        "repeated_active_x": chi(chi(X, X), chi(succ(X), A)),
        "nested_and_repeated": recursor(nested_body, chi(X, A), succ(X)),
    }
    table = []
    frozen_checks = 0
    for name, payload in payloads.items():
        m, total, i = payload.size(), payload.size(full=True), active_occurrences(payload, "x")
        constructions = {
            "old_FB": (old_fused(payload), (2*m+i+14, 2*total+i+17)),
            "old_FB_S": (old_fused_successor_shared(payload), (2*m+19, 2*total+22)),
            "old_FB_T": (old_fused_payload_table(payload), (m+40, total+43)),
            "new_SC": (new_single_occurrence(payload), (m+24, total+28)),
        }
        row = {"payload": name, "m": m, "T": total, "i": i, "formulas": {}}
        for formula_name, (formula, expected) in constructions.items():
            actual = (formula.size(), formula.size(full=True))
            assert actual == expected, (name, formula_name, actual, expected)
            row["formulas"][formula_name] = counts(formula)
        selected_name, selected_formula = choose_hybrid(payload)
        assert selected_formula.size(full=True) == min(
            2*total+i+17, 2*total+22, total+28)
        row["hybrid_selection"] = {"form": selected_name, **counts(selected_formula)}
        table.append(row)

        replaced = substitute_active(payload, {"x": succ(B)})
        assert replaced.size() == m+i
        assert replaced.size(full=True) == total+i
        assert descriptor_sequence(replaced) == descriptor_sequence(payload)
        assert substitute_active(payload, {"v": ZERO, "w": ONE}) == payload
        frozen_checks += 4

    # The minimal 17-node fixed basis recovers diagonal bits through this
    # automatically chosen instance; no special renderer exception is used.
    normalization_name, normalization_formula = choose_hybrid(A)
    assert normalization_name == "FB"
    assert normalization_formula.size(full=True) == 19

    # Here v is active in the application but also bound by the descriptor
    # convention inside its frozen body.  Only the active occurrence changes.
    frozen_application = recursor(nested_body, V, A)
    replaced_application = substitute_active(frozen_application, {"v": succ(X), "w": ZERO})
    assert replaced_application.children == (succ(X), A)
    assert replaced_application.descriptor is nested_body
    assert replaced_application.size(full=True) == frozen_application.size(full=True)+1
    # Substituting into the body itself DOES alter its active v,w arguments,
    # while descriptors of the lower-rank recursors remain unchanged.
    replaced_body = substitute_active(nested_body, {"v": ZERO, "w": ONE})
    assert replaced_body != nested_body
    assert descriptor_sequence(replaced_body) == descriptor_sequence(nested_body)
    frozen_checks += 5

    predicates = {
        "atom_x_equals_a": equal(X, A),
        "atom_nested": equal(payloads["nested_and_repeated"], ZERO),
        "conjunction": conjunction(equal(X, A), equal(succ(X), ZERO)),
        "implication": implication(equal(payloads["simple_recursor"], A), equal(X, ZERO)),
        "negation_expanded": implication(equal(X, A), FALSE),
        "falsity": FALSE,
    }
    predicate_table = []
    for name, predicate in predicates.items():
        f, total, i = predicate.size(), predicate.size(full=True), active_occurrences(predicate, "x")
        direct = native_boundary(predicate)
        alias = native_boundary_successor_shared(predicate)
        assert (direct.size(), direct.size(full=True)) == (2*f+i+12, 2*total+i+12)
        assert (alias.size(), alias.size(full=True)) == (2*f+18, 2*total+18)
        row = {"predicate": name, "f": f, "F": total, "i": i,
               "native_BC": counts(direct), "native_BC_alias": counts(alias)}
        if predicate.kind == "equality":
            guarded = one_copy_atomic_guarded(*predicate.children)
            assert (guarded.size(), guarded.size(full=True)) == (f+25, total+26)
            row["one_copy_atom_guarded"] = counts(guarded)
        predicate_table.append(row)

    envelope_cases = 0
    for total in range(1, 257):
        for i in range(total+1):
            old = min(2*total+i+17, 2*total+22, total+43)
            new = min(2*total+i+17, 2*total+22, total+28)
            saving = max(0, min(15, total+min(i, 5)-11))
            assert new <= old
            assert old-new == saving
            envelope_cases += 1

    return {"payloads": table, "predicates": predicate_table,
            "frozen_substitution_assertions": frozen_checks,
            "envelope_cases": envelope_cases}


def num_q(first: int, second: int) -> int:
    return second if first == 0 else first-1


def num_z(first: int, second: int) -> int:
    return second if first == 0 else 0


def num_chi(first: int, second: int) -> int:
    return int(first == second)


def num_selector(test: int, first: int, second: int) -> int:
    return num_q(num_z(test, first+1), second)


def check_endpoint_kernel() -> dict:
    distinct_cases = 0
    coincident_cases = 0
    for b_is_zero, b_is_target, bit_at_b, bit_at_successor in product((0, 1), repeat=4):
        bc = (b_is_zero == 1 or bit_at_b == 1) and (bit_at_successor == 0 or b_is_target == 1)
        # Distinct endpoints: both off-diagonal equality bits are zero.
        first_error = num_selector(bit_at_b, num_q(b_is_zero, 1), num_q(b_is_target, 0))
        second_error = num_selector(bit_at_successor, num_q(b_is_zero, 0), num_q(b_is_target, 1))
        assert (first_error == 0 and second_error == 0) == bc
        distinct_cases += 1

        # Also verify the consistent coincident-endpoint algebra.  This
        # confirms that the forward kernel does not need S(b) != b.
        if bit_at_b == bit_at_successor:
            common_error = num_selector(bit_at_b, num_q(b_is_zero, 1), num_q(b_is_target, 1))
            assert (common_error == 0) == bc
            coincident_cases += 1
    assert distinct_cases == 16
    assert coincident_cases == 8
    return {"distinct_endpoint_boolean_cases": distinct_cases,
            "consistent_coincident_endpoint_cases": coincident_cases,
            "no_fixed_point_lemma_required": True}


def scan_witnesses(values: tuple[int, ...], max_target: int) -> tuple[int, ...]:
    """The explicit PRA candidate recurrence, evaluated on a finite table."""
    assert len(values) >= max_target+2
    candidate = 0
    answers = [candidate]
    for old_target in range(max_target):
        if values[candidate+1] != 0:
            candidate = old_target+1
        answers.append(candidate)
    return tuple(answers)


def check_value_table(values: tuple[int, ...], max_target: int) -> tuple[int, int]:
    witnesses = scan_witnesses(values, max_target)
    target_checks = 0
    universal_checks = 0
    for target, witness in enumerate(witnesses):
        assert 0 <= witness <= target
        assert witness == 0 or values[witness] != 0
        assert values[witness+1] == 0 or witness == target
        at_zero = num_chi(witness, 0)
        at_target = num_chi(witness, target)
        for point, value in enumerate(values):
            left_error = num_q(at_zero, num_chi(point, witness))
            right_error = num_q(at_target, num_chi(point, witness+1))
            result = num_q(num_z(value, left_error+1), right_error)
            assert result == 0, (values, target, witness, point, result)
            universal_checks += 1
        target_checks += 1
    return target_checks, universal_checks


def check_binary_witnesses(max_target: int) -> dict:
    words = target_checks = universal_checks = 0
    for bound in range(max_target+1):
        for values in product((0, 1), repeat=bound+2):
            targets, points = check_value_table(values, bound)
            target_checks += targets
            universal_checks += points
            words += 1
    return {"largest_target": max_target, "all_word_lengths": [2, max_target+2],
            "binary_words": words, "target_checks": target_checks,
            "universal_matrix_checks": universal_checks}


def check_raw_witnesses() -> dict:
    ternary_words = target_checks = universal_checks = 0
    for values in product((0, 1, 2), repeat=7):
        targets, points = check_value_table(values, 5)
        target_checks += targets
        universal_checks += points
        ternary_words += 1
    sequences = {
        "all_zero": tuple(0 for _ in range(64)),
        "all_large_nonzero": tuple(10**100 for _ in range(64)),
        "alternating_zero_and_two": tuple(0 if j % 2 == 0 else 2 for j in range(64)),
        "quadratic_residues": tuple((j*j+3*j) % 11 for j in range(64)),
        "single_late_zero": tuple(0 if j == 37 else j+2 for j in range(64)),
        "single_early_zero": tuple(0 if j == 1 else j*j+1 for j in range(64)),
        "powers_and_zeros": tuple(0 if j % 7 == 0 else 2**j for j in range(64)),
    }
    for values in sequences.values():
        targets, points = check_value_table(values, 62)
        target_checks += targets
        universal_checks += points
    return {"ternary_words_length_7": ternary_words,
            "additional_raw_sequences": list(sequences),
            "target_checks": target_checks, "universal_matrix_checks": universal_checks}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-target", type=int, default=12,
                        help="largest target in the exhaustive binary-word check (default: 12)")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("verification_results.json"))
    arguments = parser.parse_args()
    if not 0 <= arguments.max_target <= 16:
        parser.error("--max-target must be between 0 and 16; runtime grows exponentially")
    start = time.perf_counter()
    results = {
        "scope": "Exact syntax counts and finite algebra/witness checks; not a full formalization.",
        "python_version": platform.python_version(),
        "syntax": check_counts_and_substitution(),
        "endpoint_kernel": check_endpoint_kernel(),
        "binary_witnesses": check_binary_witnesses(arguments.max_target),
        "raw_witnesses": check_raw_witnesses(),
        "status": "all_checks_passed",
    }
    results["elapsed_seconds"] = round(time.perf_counter()-start, 3)
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(results, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({
        "status": results["status"],
        "SC_exact_size": {"active": "m+24", "full": "T+28"},
        "endpoint_kernel": results["endpoint_kernel"],
        "binary_witnesses": results["binary_witnesses"],
        "raw_witnesses": results["raw_witnesses"],
        "elapsed_seconds": results["elapsed_seconds"],
    }, indent=2))


if __name__ == "__main__":
    main()
