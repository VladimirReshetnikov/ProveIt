"""Measure the complete acceptance programs, including parsing and verdicts.

Only comments and real docstrings are omitted.  The same Python runtime and
standard libraries are outside every boundary.  No generated checker is used.
"""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ('ast_nodes', 'source_tokens', 'normalized_tokens', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def count_tokens(source, spans=()):
    return sum(token.type not in IGNORED and not any(
        first <= token.start and token.end <= last for first, last in spans)
        for token in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(path, core=False):
    raw = Path(path).read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                node.body.pop(0)
                spans.append(((first.lineno, first.col_offset),
                              (first.end_lineno, first.end_col_offset)))
    if core:
        tree.body = [n for n in tree.body
                     if not isinstance(n, (ast.Import, ast.ImportFrom, ast.If))]
    normalized = ast.unparse(tree) + '\n'
    result = {'sha256': hashlib.sha256(raw).hexdigest(),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'source_tokens': count_tokens(source, spans),
            'normalized_tokens': count_tokens(normalized),
            'normalized_bytes': len(normalized.encode('utf-8')),
            'raw_bytes': len(raw), 'physical_lines': len(source.splitlines()),
            'nonblank_lines': sum(bool(line.strip()) for line in source.splitlines())}
    if core:
        return {key: result[key] for key in
                ('sha256', 'ast_nodes', 'normalized_tokens', 'normalized_bytes')}
    return result


def policy(package, filename):
    theorem = any(s in package for s in ('rigid_parameters', 'scope_kernel',
                                        'unary_numerical_binder'))
    demand = (filename in ('checker_demand.py', 'checker_text_scopes.py') or
              ('stack_kernel' in package and filename == 'checker.py'))
    return {'interface': 'theorem' if theorem else 'open sequent',
            'annotations': 'demand' if demand else 'strict',
            'stack_exhaustion': filename == 'checker_exact.py'}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    baselines, cores = [], []
    for entry in manifest['entries']:
        path = ROOT / entry['source']
        metrics = measure(path)
        if metrics['sha256'] != entry['sha256']:
            raise ValueError('Baseline changed: ' + entry['source'])
        row = {**entry, **policy(entry['package'], entry['filename']), **metrics}
        baselines.append(row)
        cores.append({**entry, **measure(path, core=True)})
    candidates = []
    for name in ('checker.py', 'checker_demand.py'):
        path = ROOT / name
        if path.exists():
            candidates.append({'source': name, **measure(path)})
    if not candidates:
        raise ValueError('No candidate checker')
    minima = {field: min(row[field] for row in baselines) for field in FIELDS}
    core_fields = ('ast_nodes', 'normalized_tokens', 'normalized_bytes')
    core_minima = {field: min(row[field] for row in cores) for field in core_fields}
    strict_cores = [c for b, c in zip(baselines, cores)
                    if b['annotations'] == 'strict']
    strict_core_minima = {field: min(row[field] for row in strict_cores)
                          for field in core_fields}
    result = {'python': platform.python_version(), 'repository': manifest['repository'],
              'commit': manifest['commit'], 'baseline_count': len(baselines),
              'boundary': 'Entire standalone acceptance source; only comments and docstrings omitted.',
              'baselines': baselines, 'coordinatewise_minimum': minima,
              'candidates': candidates, 'core_baselines': cores,
              'core_coordinatewise_minimum': core_minima,
              'strict_core_coordinatewise_minimum': strict_core_minima}
    for candidate in candidates:
        candidate['strictly_below_minimum'] = {
            field: candidate[field] < minima[field] for field in FIELDS}
        candidate['percentage_reduction'] = {
            field: 100 * (1 - candidate[field] / minima[field]) for field in FIELDS}
        candidate['core'] = measure(ROOT / candidate['source'], core=True)
        candidate['core_strictly_below_minimum'] = {
            field: candidate['core'][field] < core_minima[field] for field in core_fields}
    primary = candidates[0]
    result['primary_passed'] = all(primary['strictly_below_minimum'].values())
    result['primary_core_passed'] = all(primary['core_strictly_below_minimum'].values())
    result['primary_core_below_all_strict'] = {
        field: primary['core'][field] < strict_core_minima[field] for field in core_fields}
    destination = ROOT / 'results'
    destination.mkdir(exist_ok=True)
    (destination / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (destination / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('source', 'interface', 'annotations', *FIELDS,
                                         'raw_bytes', 'physical_lines', 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows([*baselines, *candidates])
    names = {'ast_nodes': 'AST', 'source_tokens': 'SourceTokens',
             'normalized_tokens': 'Tokens', 'normalized_bytes': 'Bytes'}
    macros = []
    for field, label in names.items():
        macros.append('\\newcommand{\\New' + label + '}{' + f'{primary[field]:,}' + '}')
        macros.append('\\newcommand{\\Old' + label + '}{' + f'{minima[field]:,}' + '}')
    (destination / 'numbers.tex').write_text('\n'.join(macros) + '\n')
    table = []
    labels = {'reduced_kernel': 'Reduced', 'rigid_parameters': 'Rigid parameters',
              'scope_kernel': 'Scope', 'stack_kernel': 'Stack',
              'unary_numerical_binder': 'Unary numerical', 'unary_universal': 'Unary universal'}
    for row in baselines:
        label = next(v for k, v in labels.items() if k in row['package'])
        variant = row['filename'].replace('checker', '').replace('.py', '').strip('_') or 'main'
        variant = variant.replace('_', ' ')
        table.append(f"{label}: {variant} & {row['ast_nodes']} & {row['source_tokens']} & "
                     f"{row['normalized_tokens']} & {row['normalized_bytes']:,} " + r'\\')
    table.append(r'\midrule')
    table.append('Coordinatewise minimum & ' + ' & '.join(f'{minima[f]:,}' for f in FIELDS) + r'\\')
    table.append(r'\textbf{New complete checker} & ' + ' & '.join(
        r'\textbf{' + f'{primary[f]:,}' + '}' for f in FIELDS) + r'\\')
    table = [r'\begin{center}', r'\small', r'\begin{tabular}{lrrrr}',
             r'\toprule', r'Complete acceptance program & AST & Source & Norm. & Norm.\\',
             r'& nodes & tokens & tokens & bytes\\', r'\midrule', *table,
             r'\bottomrule', r'\end{tabular}', r'\end{center}']
    (destination / 'comparison_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('baselines', 'core_baselines')}, indent=2))
    if (not result['primary_passed'] or
            not all(result['primary_core_below_all_strict'].values())):
        raise ValueError('Primary candidate failed a declared strict comparison')
    return result


if __name__ == '__main__':
    main()
