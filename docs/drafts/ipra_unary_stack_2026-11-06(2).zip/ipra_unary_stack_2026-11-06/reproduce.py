"""Reproduce the measured comparison and the delivered verification evidence."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(relative):
    command = [sys.executable, str(ROOT / relative)]
    process = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    if process.returncode:
        print(process.stdout)
        print(process.stderr, file=sys.stderr)
        raise SystemExit(process.returncode)
    return json.loads(process.stdout)


def summaries():
    metrics = json.loads((ROOT / 'results/metrics.json').read_text())
    validation = json.loads((ROOT / 'results/validation.json').read_text())
    adversarial = json.loads((ROOT / 'results/adversarial.json').read_text())
    if not metrics['primary_passed']:
        raise ValueError('Full-program comparison failed')
    if not all(metrics['primary_core_below_all_strict'].values()):
        raise ValueError('Matched strict core comparison failed')
    if not all(metrics['candidates'][1]['core_strictly_below_minimum'].values()):
        raise ValueError('Demand core comparison failed')
    if validation['status'] != 'PASS' or adversarial['status'] != 'all expected outcomes':
        raise ValueError('A validation suite failed')
    rows = [
        ('Current strict core minimum', metrics['strict_core_coordinatewise_minimum']),
        ('Current mixed-policy core minimum', metrics['core_coordinatewise_minimum']),
        ('New strict core', metrics['candidates'][0]['core']),
        ('New demand core', metrics['candidates'][1]['core']),
    ]
    lines = [r'\begin{center}', r'\begin{tabular}{lrrr}', r'\toprule',
             r'Core only & AST nodes & Norm. tokens & Norm. bytes\\', r'\midrule']
    for label, data in rows:
        lines.append(label + ' & ' + ' & '.join(f'{data[k]:,}' for k in
                     ('ast_nodes', 'normalized_tokens', 'normalized_bytes')) + r'\\')
    lines += [r'\bottomrule', r'\end{tabular}', r'\end{center}']
    (ROOT / 'results/verification_table.tex').write_text('\n'.join(lines) + '\n')
    counts = validation['counts']
    summary = (
        'The delivered run checked \\textbf{' + str(counts['source_theorems']) +
        '} source theorems through both production checkers, with complete stack\n'
        'consumption, independent reconstruction, and acceptance of the recovered\n'
        'trees by both frozen references. It also checked \\textbf{' +
        str(counts['boundary_scenarios']) + '} boundary scenarios against both variants\n'
        'and made ' + str(counts['actual_cli_invocations']) +
        ' additional command-line checks. The independent adversarial suite\n'
        'performed \\textbf{' + str(adversarial['total_checks']) + '} checks (' +
        str(adversarial['kernel_checks']) + ' kernel and ' + str(adversarial['cli_checks']) +
        ' public command-line checks); all expected outcomes were observed.\n\n'
        'Two deliberate semantic mutations were detected: granting compound\n'
        'formulas an induction hypothesis, and permitting an existential\n'
        'eigenvariable to escape. These mutations exist only in temporary\n'
        'in-memory test modules; the delivered checkers retain their frozen hashes.\n')
    (ROOT / 'results/validation_summary.tex').write_text(summary)
    result = {'status': 'PASS', 'python': platform.python_version(),
              'full_program_comparison': 'strict primary below all fourteen variants',
              'strict_core_comparison': 'below every strict predecessor',
              'demand_core_comparison': 'below every predecessor of either policy',
              'certificate_validation': counts,
              'independent_adversarial_checks': adversarial['total_checks'],
              'checkers': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                           for name in ('checker.py', 'checker_demand.py')}}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    for script in ('comparison/measure.py', 'validation/validate.py',
                   'validation/adversarial.py'):
        run(script)
    print(json.dumps(summaries(), indent=2))


if __name__ == '__main__':
    main()
