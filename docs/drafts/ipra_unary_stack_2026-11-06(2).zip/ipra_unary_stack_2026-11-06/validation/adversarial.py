"""Independent targeted adversarial review of the delivered unary stack kernels.

The default run checks checker.py and, when present, checker_demand.py.  It
validates the exact reviewed source hashes, exercises 34 scoped kernel cases
per implementation, and invokes the actual command-line program on malformed
files, root records, formula trees, and inference packets.  Results are written
to results/adversarial.json; stdout is a single JSON summary.  These finite
tests support, but do not replace, the written soundness argument.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
REVIEWED_SHA256 = {
    "strict": "5243e2fb1ed39f25ff18dacd323394a741f18cc69ac0d18c7ebbfce31062f707",
    "demand": "c81c089cb573db571431387f8898d88a4b2dcc2f4b31b6957aff697117cb5993",
}
NIL = None  # An unmatched cell requests the hypothesis rule.
ONE = ["s", 0]
FALSE = ["=", 0, ONE]
REVERSE_FALSE = ["=", ONE, 0]
R0 = ["=", ["r", 0, 0, 0], 0]
Q_R0 = ["q", R0]
BAD_TERM = {"not": "a numerical term"}


def reflexivity(t):
    # The test inputs are closed terms or negative rigid parameters, so their
    # indices require no lifting when they occur in this equality motive.
    computation = ["=", ["r", 0, t, 0], t]
    return ["=", t, t], [[], [], [computation, ["=", 1, t]]]


def kernel_cases(strict):
    refl0, refl0_stack = reflexivity(0)
    reflrigid, reflrigid_stack = reflexivity(-7)
    ex_zero = ["ex", ["=", 1, 0]]
    ex_rigid = ["ex", ["=", 1, -7]]
    q_false = ["q", FALSE]
    # This failed major proof consumes NIL.  The body then succeeds by Hyp,
    # because Q has introduced FALSE as its base.  It does not prove FALSE.
    fallback = [NIL, [REVERSE_FALSE, BAD_TERM], []]
    return [
        ("R0 computation", R0, [[]], True),
        ("R successor computation", ["=", ["r", ONE, 0, ["s", 1]], ["s", ["r", 0, 0, ["s", 1]]]], [[]], True),
        ("derived zero reflexivity", refl0, refl0_stack, True),
        ("derived rigid reflexivity", reflrigid, reflrigid_stack, True),
        ("false atom cannot be hypothesis at root", FALSE, [NIL], False),
        ("empty stack rejects", R0, [], False),
        ("wrong computation rejects", ["=", ["r", 0, 0, 0], ONE], [[]], False),
        ("rigid variable cannot be unrolled as successor", ["=", ["r", -7, 0, 0], 0], [[]], False),
        ("positive parameter cannot be unrolled as successor", ["=", ["r", 1, 0, 0], 0], [[]], False),
        ("nonconstructor counter needs proof rather than direct unrolling", ["=", ["r", ["r", 0, 0, 0], 0, 0], 0], [[]], False),
        ("Q of constant false is implication reflexivity", q_false, [NIL, []], True),
        ("Q induction cannot prove every number zero", ["q", ["=", 1, 0]], [NIL, []], False),
        ("existential zero witness", ex_zero, [NIL, [0]], True),
        ("existential rigid witness", ex_rigid, [NIL, [-7]], True),
        ("nested witness retains outer variable", ["ex", ["ex", ["=", 1, 2]]], [NIL, [1], [0]], True),
        ("existential cannot prove constant false", ["ex", FALSE], [NIL, [0]], False),
        ("existential malformed witness rejects even if vacuous", ["ex", R0], [[], [BAD_TERM]], False),
        ("existential eigenvariable cannot escape", ["=", 1, 0], [NIL, NIL, [0], [ex_zero, NIL]], False),
        ("existential eigenvariable cannot become rigid", ["=", 1, -7], [NIL, NIL, [-7], [ex_rigid, NIL]], False),
        ("vacuous Q elimination with valid witness", R0, [[], [], [], [Q_R0, -7]], True),
        ("vacuous Q elimination with malformed witness", R0, [[], [], [], [Q_R0, BAD_TERM]], not strict),
        ("malformed witness cannot prove false", FALSE, [NIL, NIL, [], [q_false, BAD_TERM]], False),
        ("vacuous equality motive still validates", R0, [[], [], [R0, BAD_TERM]], False),
        ("failed major fallback is valid under Q assumption", q_false, fallback, True),
        ("failed major fallback cannot prove root false", FALSE, [NIL, [REVERSE_FALSE, BAD_TERM]], False),
        ("unused prefix explicitly permitted", R0, [BAD_TERM, {"unparsed": [False]}, []], True),
        ("prefix does not make false computation true", FALSE, [BAD_TERM, []], False),
        ("booleans are not integer syntax", ["=", False, 0], [NIL], False),
        ("floats are not integer syntax", ["=", 0.0, 0], [NIL], False),
        ("formula arity wildcard cannot accept malformed Q", ["q", R0, 0], [[]], False),
        ("formula arity wildcard cannot accept malformed ex", ["ex", R0, 0], [[]], False),
        ("recursor arity wildcard cannot accept ex as term", ["=", ["ex", 0, 0, 0], 0], [[]], False),
        ("recursor arity wildcard cannot accept unknown term", ["=", ["bogus", 0, 0, 0], 0], [[]], False),
        ("unknown goal tag rejects", ["bogus", ["r", 0, 0, 0], 0], [[]], False),
    ]


def run_kernel(mod, goal, stack):
    p = copy.deepcopy(stack)
    try:
        accepted = bool(mod.check(copy.deepcopy(goal), p, []))
        return {"accepted": accepted, "leftover_cells": len(p)}
    except Exception as exc:
        return {"accepted": False, "exception": type(exc).__name__, "leftover_cells": len(p)}


def cli_records(strict):
    ex_zero = ["ex", ["=", 1, 0]]
    return [
        ("valid theorem through public CLI", [R0, [[]]], True),
        ("valid existential witness packet through public CLI", [ex_zero, [NIL, [0]]], True),
        ("public interface forbids user-supplied assumptions", [FALSE, [NIL], [FALSE]], False),
        ("public interface forbids even an extra empty context", [R0, [[]], []], False),
        ("missing root stack", [R0], False),
        ("empty root record", [], False),
        ("empty proof stack", [R0, []], False),
        ("non-list root record", {"goal": R0, "stack": [[]]}, False),
        ("non-list proof stack", [R0, {"proof": []}], False),
        ("malformed boolean goal", [["=", False, 0], [NIL]], False),
        ("malformed floating-point goal", [["=", 0.0, 0], [NIL]], False),
        ("unknown formula tag", [["bogus", ["r", 0, 0, 0], 0], [[]]], False),
        ("equality missing right child", [["=", 0], [NIL]], False),
        ("equality with excess child", [["=", 0, 0, 0], [NIL]], False),
        ("Q missing matrix child", [["q"], [[]]], False),
        ("Q with excess matrix child", [["q", R0, R0], [[]]], False),
        ("existential missing matrix child", [["ex"], [[0]]], False),
        ("existential with excess matrix child", [["ex", R0, R0], [[0]]], False),
        ("recursor missing update child", [["=", ["r", 0, 0], 0], [[]]], False),
        ("recursor with excess child", [["=", ["r", 0, 0, 0, 0], 0], [[]]], False),
        ("successor missing child", [["=", ["s"], 0], [[]]], False),
        ("successor with excess child", [["=", ["s", 0, 0], 0], [[]]], False),
        ("Q introduction missing its subproof", [Q_R0, [[]]], False),
        ("Q introduction with excess packet argument", [Q_R0, [[], [0]]], False),
        ("existential introduction missing witness packet argument", [ex_zero, [NIL, []]], False),
        ("existential introduction with excess packet argument", [ex_zero, [NIL, [0, 0]]], False),
        ("existential introduction missing its subproof", [ex_zero, [[0]]], False),
        ("elimination missing packet argument", [R0, [[], [], [], [Q_R0]]], False),
        ("elimination with excess packet argument", [R0, [[], [], [], [Q_R0, 0, 0]]], False),
        ("computation with excess packet argument", [R0, [[0]]], False),
        ("vacuous malformed Q witness at public boundary", [R0, [[], [], [], [Q_R0, BAD_TERM]]], not strict),
    ]


def invoke_cli(checker, args):
    completed = subprocess.run([sys.executable, str(checker), *map(str, args)],
                               capture_output=True, text=True, timeout=10)
    return {"returncode": completed.returncode, "stdout": completed.stdout,
            "stderr": completed.stderr}


def assert_cli(name, expected, observed):
    correct = observed == {
        "returncode": 0 if expected else 1,
        "stdout": "ACCEPT\n" if expected else "REJECT\n",
        "stderr": "",
    }
    if not correct:
        raise AssertionError({"case": name, "expected": expected, "observed": observed})


def check_cli(checker, strict):
    results = []
    with tempfile.TemporaryDirectory(prefix="ipra-adversarial-") as directory:
        temp = Path(directory)
        for index, (name, record, expected) in enumerate(cli_records(strict)):
            path = temp / (str(index) + ".json")
            path.write_text(json.dumps(record), encoding="utf-8")
            observed = invoke_cli(checker, [path])
            assert_cli(name, expected, observed)
            results.append({"name": name, "expected": expected, **observed})
        for name, contents in (("empty JSON file", b""),
                               ("truncated JSON file", b"["),
                               ("invalid UTF-8 file", b"\xff")):
            path = temp / "bad.json"
            path.write_bytes(contents)
            observed = invoke_cli(checker, [path])
            assert_cli(name, False, observed)
            results.append({"name": name, "expected": False, **observed})
        for name, args in (("nonexistent input file", [temp / "absent.json"]),
                           ("directory supplied as file", [temp]),
                           ("missing CLI filename", []),
                           ("excess CLI filename", [temp / "bad.json", "extra"])):
            observed = invoke_cli(checker, args)
            assert_cli(name, False, observed)
            results.append({"name": name, "expected": False, **observed})
    return results


def review(checker, kind):
    checker = checker.resolve()
    source = checker.read_bytes()
    actual_sha = hashlib.sha256(source).hexdigest()
    expected_sha = REVIEWED_SHA256[kind]
    if actual_sha != expected_sha:
        raise AssertionError({"checker": str(checker), "expected_sha256": expected_sha,
                              "actual_sha256": actual_sha})
    spec = importlib.util.spec_from_file_location("reviewed_" + kind, checker)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    kernel_results = []
    strict = kind == "strict"
    for name, goal, stack, expected in kernel_cases(strict):
        observed = run_kernel(mod, goal, stack)
        if observed["accepted"] != expected:
            raise AssertionError({"checker": str(checker), "case": name,
                                  "expected": expected, "observed": observed})
        kernel_results.append({"name": name, "expected": expected, **observed})
    cli_results = check_cli(checker, strict)
    # Detect concurrent edits after importing or invoking the program, too.
    if hashlib.sha256(checker.read_bytes()).hexdigest() != actual_sha:
        raise AssertionError("Checker changed during review: " + str(checker))
    return {"checker": checker.name, "kind": kind, "source_sha256": actual_sha,
            "source_bytes": len(source), "source_matches_reviewed_hash": True,
            "kernel_count": len(kernel_results), "cli_count": len(cli_results),
            "kernel_cases": kernel_results, "cli_cases": cli_results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, default=ROOT / "checker.py")
    parser.add_argument("--demand", type=Path, default=ROOT / "checker_demand.py")
    parser.add_argument("--no-demand", action="store_true", help="Review only the primary strict checker")
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "adversarial.json")
    args = parser.parse_args()
    reports = [review(args.checker, "strict")]
    if not args.no_demand and args.demand.exists():
        reports.append(review(args.demand, "demand"))
    totals = {"kernel_checks": sum(r["kernel_count"] for r in reports),
              "cli_checks": sum(r["cli_count"] for r in reports)}
    report = {"status": "all expected outcomes", "formal_verification": False,
              **totals, "total_checks": sum(totals.values()), "checkers": reports}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], **totals,
                      "total_checks": report["total_checks"],
                      "result": str(args.output.resolve())}))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"status": "FAILED", "exception": type(exc).__name__, "detail": str(exc)}))
        sys.exit(1)
