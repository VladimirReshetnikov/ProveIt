"""Untrusted conversions between proof trees and proof stacks.

The forward direction uses the frozen source calculus. The reverse direction
independently parses sorted expressions with fresh named binders, using the
unchanged named-variable reference from the numerical-binder draft. Neither
production checker imports this module. Every reconstructed tree is intended
to be checked again by both unchanged reference implementations.
"""

from copy import deepcopy
from dataclasses import dataclass

from frozen import unary_reference as N


def instructions(source, goal, proof, context):
    """Extract the successful source derivation in execution order."""
    if not source.check(goal, proof, context):
        raise ValueError("source proof rejected")
    match (goal, proof):
        case [["q", body], [child]]:
            local = [source.subst(body, [0, 0])]
            if body[0] == "=":
                local.append(body)
            target = source.subst(body, [["s", 1], 0])
            return [[], *instructions(source, target, child,
                                      [*map(source.subst, context), *local])]
        case [["ex", body], [witness, child]]:
            local = ["=", 1, source.subst(witness, formula=False)]
            return [[witness], *instructions(source, body, child,
                                             [*map(source.subst, context), local])]
        case [_, [[tag, *parts] as major, first, *args]] if source.check(major, first, context):
            prefix = instructions(source, major, first, context)
            if tag == "ex":
                child, = args
                rest = instructions(source, source.subst(goal), child,
                                    [*map(source.subst, context), *parts])
                return [[major, None], *prefix, *rest]
            annotation, child = args
            if tag == "q":
                target = source.subst(parts[0], [0, -1])
            else:
                target = source.subst(annotation, [parts[0], -1])
            return [[major, annotation], *prefix,
                    *instructions(source, target, child, context)]
        case [["=", ["r", _, _, _], _], "r"]:
            return [[]]
        case _:
            if goal not in context:
                raise AssertionError("successful fallback was not an assumption")
            return [None]


def to_stack(source, document, context=()):
    """Return the same goal with a canonical stack; verify the result separately."""
    goal, proof = document
    stream = instructions(source, goal, proof, list(context))
    return deepcopy([goal, list(reversed(stream))])


def unchecked_tree_to_stack(proof):
    """Serialize canonical-looking trees, including deliberately invalid tests.

    This function does not establish validity and must never be trusted. Its
    purpose is to keep faulty proof attempts faulty while changing the wire
    format. Unlike to_stack, it does not require source acceptance.
    """
    if proof is None:
        return [None]
    if proof == "r":
        return [[]]
    if type(proof) is not list:
        return [proof]
    if len(proof) == 1:
        return [[], *unchecked_tree_to_stack(proof[0])]
    if len(proof) == 2:
        return [[proof[0]], *unchecked_tree_to_stack(proof[1])]
    if len(proof) == 3:
        return [[proof[0], None], *unchecked_tree_to_stack(proof[1]),
                *unchecked_tree_to_stack(proof[2])]
    if len(proof) == 4:
        return [[proof[0], proof[2]], *unchecked_tree_to_stack(proof[1]),
                *unchecked_tree_to_stack(proof[3])]
    return [proof]


def integer_labels(data):
    if type(data) is int:
        yield data
    elif type(data) is list:
        for item in data:
            yield from integer_labels(item)
    elif type(data) is dict:
        for item in data.values():
            yield from integer_labels(item)


@dataclass
class Proof:
    tree: object


class StackOracle(N.Oracle):
    """An independent named-variable proof-stack interpreter.

    A negative label is parsed as a distinct fresh ordinary free parameter.
    Its new coordinate is above every original positive coordinate. Serializing
    named expressions adds the actual local binder depth, so this is a genuine
    capture-avoiding rigid-parameter elimination, not a raw integer replacement.
    """

    def __init__(self, document, context=(), demand=False):
        super().__init__()
        if type(document) is not list or len(document) != 2:
            raise N.Invalid("a theorem document has exactly two fields")
        if type(document[1]) is not list:
            raise N.Invalid("a proof stack must be an array")
        labels = list(integer_labels([document, list(context)]))
        maximum = max([0, *[x for x in labels if x > 0]])
        negative = sorted({x for x in labels if x < 0})
        self.renaming = {label: maximum + i + 1
                         for i, label in enumerate(negative)}
        self.stack = deepcopy(document[1])
        self.demand = demand
        self.discarded_failed_majors = 0

    def term(self, data, local=()):
        if type(data) is int and data < 0:
            return N.Var(('free', self.renaming[data] - 1))
        return super().term(data, local)

    def take(self):
        if not self.stack:
            raise N.Invalid("truncated proof stack")
        return self.stack.pop()

    def derive(self, goal, context=(), local=()):
        token = self.take()
        array = type(token) is list

        if isinstance(goal, N.Q) and array and len(token) == 0:
            eigen = self.fresh('eigen')
            base = N.instantiate(goal, N.Zero())
            assumptions = [*context, base]
            if isinstance(goal.body, N.Eq):
                assumptions.append(N.instantiate(goal, N.Var(eigen)))
            target = N.instantiate(goal, N.Succ(N.Var(eigen)))
            child = self.derive(target, assumptions, (eigen,) + local)
            return None if child is None else Proof([child.tree])

        if isinstance(goal, N.Ex) and array and len(token) == 1:
            witness = self.term(token[0], local)
            eigen = self.fresh('eigen')
            target = N.instantiate(goal, N.Var(eigen))
            child = self.derive(target, [*context, N.Eq(N.Var(eigen), witness)],
                                (eigen,) + local)
            return None if child is None else Proof([N.coordinates(witness, local),
                                                    child.tree])

        if (array and len(token) == 2 and type(token[0]) is list
                and len(token[0]) >= 1):
            raw_major, annotation = token
            major = self.formula(raw_major, local)
            first = self.derive(major, context, local)
            if first is not None:
                major_code = N.coordinates(major, local)
                if isinstance(major, N.Ex):
                    eigen = self.fresh('eigen')
                    body = N.instantiate(major, N.Var(eigen))
                    second = self.derive(goal, [*context, body], (eigen,) + local)
                    return (None if second is None else
                            Proof([major_code, first.tree, second.tree]))
                if isinstance(major, N.Eq):
                    slot = self.fresh('template')
                    motive = self.formula(annotation, (slot,) + local)
                    premise = N.replace(motive, {slot: major.left})
                    conclusion = N.replace(motive, {slot: major.right})
                    annotation_code = N.coordinates(motive, (slot,) + local)
                elif isinstance(major, N.Q):
                    unused = N.same(N.instantiate(major, N.Zero()),
                                    N.instantiate(major, N.Succ(N.Zero())))
                    witness = (N.Zero() if self.demand and unused
                               else self.term(annotation, local))
                    premise = N.instantiate(major, N.Zero())
                    conclusion = N.instantiate(major, witness)
                    annotation_code = N.coordinates(witness, local)
                else:
                    raise N.Invalid("unknown eliminable formula")
                if not N.same(goal, conclusion):
                    return None
                second = self.derive(premise, context, local)
                return (None if second is None else
                        Proof([major_code, first.tree, annotation_code, second.tree]))
            self.discarded_failed_majors += 1

        if isinstance(goal, N.Eq) and isinstance(goal.left, N.Rec) and array and not token:
            term = goal.left
            if isinstance(term.index, N.Zero):
                result = term.initial
            elif isinstance(term.index, N.Succ):
                index = term.index.value
                previous = N.Rec(index, term.initial, term.accumulator,
                                 term.predecessor, term.step)
                result = N.replace(term.step, {term.accumulator: previous,
                                              term.predecessor: index})
            else:
                raise N.Invalid("computation requires zero or a successor")
            return Proof('r') if N.same(goal.right, result) else None

        return Proof(None) if any(N.same(goal, h) for h in context) else None


def reconstruct(document, context=(), demand=False):
    """Reconstruct a strict, ordinary-variable tree or report rejection.

    Returned trees contain neither rigid coordinates nor erased bad witnesses.
    Their validity must be confirmed with the unchanged frozen checker/oracle.
    An unused initial stack segment is recorded and omitted from the tree.
    """
    try:
        oracle = StackOracle(document, context, demand)
        goal = oracle.formula(document[0])
        assumptions = [oracle.formula(h) for h in context]
        result = oracle.derive(goal, assumptions)
        if result is None:
            return {'accepted': False}
        return {'accepted': True,
                'document': [N.coordinates(goal), result.tree],
                'context': [N.coordinates(h) for h in assumptions],
                'unused_cells': len(oracle.stack),
                'rigid_renaming': oracle.renaming,
                'discarded_failed_majors': oracle.discarded_failed_majors}
    except Exception as error:
        return {'accepted': False, 'error': type(error).__name__}
