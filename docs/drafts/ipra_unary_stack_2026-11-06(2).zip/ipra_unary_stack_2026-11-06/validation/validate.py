"""Reproduce certificate translation, independent extraction and boundary tests.

All support is untrusted. The standalone checker imports none of this code.
Run with Python 3.11 or newer from any working directory.
"""

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types

from frozen import unary_checker as SOURCE
from frozen import unary_reference as NAMED
from stack_translation import reconstruct, to_stack, unchecked_tree_to_stack

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent


def load_kernel(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(kernel, document, context=()):
    try:
        if type(document) is not list or len(document) != 2:
            return False, None
        goal, stack = deepcopy(document)
        return bool(kernel.check(goal, stack, deepcopy(list(context)))), len(stack)
    except Exception:
        return False, None


def confirm_extraction(record, kernels):
    assert record['accepted']
    document, context = record['document'], record['context']
    assert SOURCE.check(*deepcopy(document), deepcopy(context))
    assert NAMED.accept_sequent(*document, context)
    canonical = to_stack(SOURCE, document, context)
    for kernel in kernels.values():
        assert run(kernel, canonical, context) == (True, 0)
    return canonical


def lift_term(term, depth=0):
    """A separate structural lift used only to build a test certificate."""
    if type(term) is int:
        return term + 1 if term > depth else term
    if term[0] == 's':
        return ['s', lift_term(term[1], depth)]
    if term[0] == 'r':
        return ['r', lift_term(term[1], depth), lift_term(term[2], depth),
                lift_term(term[3], depth + 2)]
    raise ValueError('unknown term in test construction')


def reflexivity(term):
    major = ['=', ['r', 0, term, 0], term]
    motive = ['=', 1, lift_term(term)]
    return [['=', term, term], [[], [], [major, motive]]]


def boundary_cases():
    true = ['=', 0, 0]
    false = ['=', 0, ['s', 0]]
    exists = ['ex', ['=', 1, 0]]
    cases = []

    def add(name, document, strict, demand=None, context=(), note=''):
        cases.append({'name': name, 'document': document, 'context': list(context),
                      'expected': {'strict': strict,
                                   'demand': strict if demand is None else demand},
                      'note': note})

    add('rigid_existential_witness', [['ex', ['=', 1, -7]], [None, [-7]]], True)
    add('two_rigid_witnesses_under_two_binders',
        [['ex', ['ex', ['=', 2, -7]]], [None, [-9], [-7]]], True)
    add('rigid_parameter_below_q_and_ex',
        [['q', ['ex', ['=', 1, -7]]], [None, []]], True)
    add('rigid_recursion_initial_value',
        [['=', ['r', 0, -7, ['s', -9]], -7], [[]]], True)
    nested_term = ['r', 1, -7, ['r', 2, 1, ['s', -9]]]
    add('rigid_transport_and_nested_recursion', reflexivity(nested_term), True)

    sample = reflexivity(0)
    add('unused_initial_stack_cell',
        [sample[0], [{'unread': True}, *sample[1]]], True,
        note='Prefix acceptance; independent extraction deletes the unread cell.')
    add('failed_major_then_assumption',
        [exists, [None, [false, 0], [0]]], True,
        note='A failed major may consume cells before a genuine assumption fallback.')
    add('malformed_major_does_not_fall_back',
        [exists, [None, [['unknown'], 0], [0]]], False)
    add('closed_existential_eigenvariable_escape',
        [['=', 1, 0], [None, None, [0], [exists, None]]], False,
        note='The witness of exists x (x=0) cannot become a retained free parameter.')

    q_major = ['q', true]
    prefix = [[q_major, {'not': 'a term'}], [], None]
    minor = list(reversed(sample[1]))
    add('unused_malformed_q_witness', [true, list(reversed(prefix + minor))],
        False, True,
        note='Strict checks the witness; demand repairs the unused witness to zero.')

    for length in range(len(sample[1])):
        add('truncated_reflexivity_' + str(length),
            [sample[0], sample[1][-length:] if length else []], False)
    add('reversed_execution_order', [sample[0], list(reversed(sample[1]))], False)
    add('wrong_computation_rhs', [['=', ['r', 0, 0, 0], ['s', 0]], [[]]], False)
    add('boolean_is_not_a_number', [['=', ['r', 0, True, 0], True], [[]]], False)
    add('unknown_formula_constructor', [['unknown', ['r', 0, 0, 0], 0], [[]]], False)
    add('unknown_term_constructor', [['=', ['unknown', 0, 0, 0], 0], [[]]], False)
    add('wrong_recursor_arity', [['=', ['r', 0, 0], 0], [[]]], False)
    add('invalid_stack_object', [true, {'stack': []}], False)
    add('extra_top_level_context_field', [true, [], true], False)
    add('missing_top_level_proof', [true], False)

    for fixture in json.loads((HERE / 'source_fixtures.json').read_text()):
        stream = unchecked_tree_to_stack(fixture['proof'])
        document = [fixture['goal'], list(reversed(stream))]
        add(fixture['name'], document, fixture['accepted'],
            context=fixture['context'],
            note='Pinned source boundary fixture; any assumptions are internal test data.')
    return cases


def main():
    kernels = {'strict': load_kernel('strict_candidate', ROOT / 'checker.py'),
               'demand': load_kernel('demand_candidate', ROOT / 'checker_demand.py')}
    provenance = json.loads((HERE / 'provenance.json').read_text())
    for record in provenance['source_examples']:
        path = ROOT / record['frozen']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256']
    for record in provenance['frozen_support']:
        path = ROOT / record['file']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256']

    results = {'status': 'PASS', 'corpus': [], 'boundary_cases': [],
               'cli_cases': [], 'mutation_sensitivity': []}
    for record in provenance['source_examples']:
        path = ROOT / record['frozen']
        document = json.loads(path.read_text())
        assert SOURCE.check(*deepcopy(document), [])
        assert NAMED.accept_document(document)
        translated = to_stack(SOURCE, document)
        relative = path.relative_to(HERE / 'source_trees')
        target = ROOT / 'examples' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(translated, separators=(',', ':')) + '\n')
        for name, kernel in kernels.items():
            assert run(kernel, translated) == (True, 0), (relative, name)
            extraction = reconstruct(translated, demand=name == 'demand')
            assert extraction['accepted'], (relative, name, extraction)
            assert extraction['unused_cells'] == 0
            confirm_extraction(extraction, kernels)
        results['corpus'].append({'name': str(relative),
                                   'stack_cells': len(translated[1]),
                                   'both_variants_accept_and_exhaust': True,
                                   'independent_named_extraction': True,
                                   'both_frozen_references_accept': True})

    fixtures = boundary_cases()
    for fixture in fixtures:
        row = {'name': fixture['name'], 'note': fixture['note'], 'decisions': {}}
        for name, kernel in kernels.items():
            actual, remaining = run(kernel, fixture['document'], fixture['context'])
            expected = fixture['expected'][name]
            assert actual == expected, (fixture['name'], name, actual, expected)
            extraction = reconstruct(fixture['document'], fixture['context'],
                                     demand=name == 'demand')
            assert extraction['accepted'] == expected, (fixture['name'], name, extraction)
            decision = {'accepted': actual, 'expected': expected}
            if actual:
                assert extraction['unused_cells'] == remaining
                confirm_extraction(extraction, kernels)
                decision.update(unused_cells=remaining,
                                rigid_renaming=extraction['rigid_renaming'],
                                discarded_failed_majors=extraction['discarded_failed_majors'])
            row['decisions'][name] = decision
        results['boundary_cases'].append(row)

    # Check that these rejection tests detect the intended unsound changes.
    source = (ROOT / 'checker.py').read_text()
    faults = [
        ('allow_induction_on_compound_formulas',
         "([b] if b[0] == '=' else [])", '[b]',
         'forbidden_quantified_induction_hypothesis'),
        ('let_existential_eigenvariable_escape',
         'b, h = subst(a), parts', 'b, h = a, parts',
         'closed_existential_eigenvariable_escape'),
    ]
    for name, before, after, case_name in faults:
        assert source.count(before) == 1
        mutant = types.ModuleType(name)
        exec(compile(source.replace(before, after), '<deliberate semantic fault>', 'exec'),
             mutant.__dict__)
        fixture = next(item for item in fixtures if item['name'] == case_name)
        assert not fixture['expected']['strict']
        assert run(mutant, fixture['document'], fixture['context'])[0]
        results['mutation_sensitivity'].append({'fault': name, 'detected_by': case_name})

    selected = {'rigid_existential_witness', 'unused_malformed_q_witness',
                'closed_existential_eigenvariable_escape', 'extra_top_level_context_field',
                'forbidden_quantified_induction_hypothesis'}
    with tempfile.TemporaryDirectory(prefix='ipra_unary_stack_') as temporary:
        for fixture in fixtures:
            if fixture['name'] not in selected:
                continue
            assert not fixture['context']
            path = Path(temporary) / 'certificate.json'
            path.write_text(json.dumps(fixture['document']))
            for name, filename in [('strict', 'checker.py'), ('demand', 'checker_demand.py')]:
                result = subprocess.run([sys.executable, str(ROOT / filename), str(path)],
                                        text=True, capture_output=True, timeout=15)
                expected = fixture['expected'][name]
                assert result.stdout.strip() == ('ACCEPT' if expected else 'REJECT')
                assert result.returncode == (0 if expected else 1)
                results['cli_cases'].append({'name': fixture['name'], 'variant': name,
                                             'expected': expected, 'passed': True})

    results['counts'] = {'source_theorems': len(results['corpus']),
                         'boundary_scenarios': len(fixtures),
                         'checker_variants': len(kernels),
                         'actual_cli_invocations': len(results['cli_cases']),
                         'semantic_faults_detected': len(results['mutation_sensitivity'])}
    (HERE / 'cases.json').write_text(json.dumps(fixtures, indent=2) + '\n')
    (ROOT / 'results/validation.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({'status': results['status'], **results['counts']}, indent=2))
    return results


if __name__ == '__main__':
    main()
