A SMALLER UNARY PROOF PRESENTATION OF iPRA
========================================
Prepared for Vladimir Reshetnikov, 6 November 2026 (Pacific time).

Start with report.pdf. Its complete LaTeX source is report.tex together with
sections/*.tex and the generated tables in results/*.tex.

RESULT
------
The native language has number terms 0, successor, and initialized primitive
recursion, and formulas consisting of equality, numerical closure Q, and
existence E. Q_x B has the derived reading B(0) -> forall x B(x).

The article states all primitive axioms, schemas, and inference rules. It
proves recovery of full intuitionistic first-order logic, every fixed PR
function, and induction for all quantifier-free formulas, including implication
and negation. Its ordinary first-order realization is bi-interpretable with
iPRA on the whole number domain. Identity is the definable isomorphism for
both composite interpretations. Equiconsistency follows from the explicit
proof translations and the designated contradiction 0=S0.

The mathematical basis is inherited from the current unary numerical binder
draft and credited. The new contribution is a smaller complete certificate
presentation and verifier. The article also proves that equality transport
can be restricted to equational motives; general transport is then an
admissible macro. That optional restriction is not counted as another source
size saving.

EXACT COMPARISON
----------------
Repository: VladimirReshetnikov/ProveIt
Commit: b9aefe20fe876273886d5d55be49e6ccbefce9ad
Directory: docs/drafts
Current archives inspected: 6
Current top-level checker variants: 14

                           AST       Source       Normalized     Normalized
                           nodes     tokens       tokens         bytes
Current separate minima     537       522          526            1633
checker.py (strict)         531       518          522            1623
checker_demand.py           523       510          514            1579

The full acceptance program is counted, including JSON input, syntax
validation, substitution, rules, exception handling, and verdict. Comments
and actual docstrings are excluded. Normalization uses CPython 3.12.14.
The exact current baseline sources and hashes are included.

After removing input/output uniformly:
  Strict primary core:       465 AST, 464 normalized tokens, 1362 bytes.
  Current strict core floor: 480 AST, 471 normalized tokens, 1369 bytes.
  Demand companion core:     457 AST, 456 normalized tokens, 1318 bytes.
  Current all-policy floor:  468 AST, 461 normalized tokens, 1324 bytes.

The strict core beats every strict predecessor. It does not beat the
mixed-policy core floor in tokens or bytes. The demand companion does beat
that entire floor. The strict full program beats every current full program
in all four principal measurements. This is a measured finite-corpus
improvement, not an absolute minimality theorem.

USE
---
Run from this directory:

  python3 checker.py examples/equation_induction.json
  python3 reproduce.py
  python3 build.py

The first command prints ACCEPT or REJECT; success means ACCEPT and exit
status zero. The public certificate format is exactly [goal, stack], with an
internally empty initial context. See FORMAT.txt for syntax and stack order.
The strict primary validates all selected numerical witnesses, including
ones for vacuous binders. An unused initial stack prefix is harmless and
permitted. Canonical examples consume their entire stacks.

The optional demand companion skips checking a Q-elimination witness only
when it is syntactically unused; replacing such data by zero recovers a
strict certificate of the same theorem. It proves the same theory.

REPRODUCIBILITY AND VALIDATION
------------------------------
The checkers need Python 3.10 or later. The delivered measurements and
verification run use Python 3.12.14; use that version for exact size
reproduction. PDF rebuilding additionally needs latexmk and a standard
LaTeX installation. No network or third-party Python package is required
for the measured kernels, proof validation, or comparison.

Delivered verification includes:
  * 30 source theorems translated to fully consumed stacks;
  * independent reconstruction through sorted named-variable syntax;
  * rechecking reconstructed trees with two unchanged references;
  * 31 boundary scenarios against both final variants;
  * 10 additional real CLI checks;
  * an independent 144-check adversarial suite (68 kernel, 76 CLI);
  * two deliberate semantic mutations detected by the rejection tests.

All observed outcomes passed. Results are recorded under results/.
The universal soundness, completeness, and bi-interpretability theorems
are mathematical proofs in the report. This package does not claim a
Lean or Rocq formalization of those metatheorems.

FILES
-----
report.tex, sections/       Full article source
report.pdf                 Compiled article
checker.py                 Complete strict theorem verifier
checker_demand.py          Smaller equivalent demand verifier
FORMAT.txt                 Exact syntax, instructions, and public contract
source_snapshot.json       Six pinned archives with verified blob identities
comparison/                Fourteen frozen checkers and measurement script
examples/                  Thirty canonical theorem certificates
validation/                Translators, references, fixtures, rejection tests
results/                   Measured counts, observed outcomes, generated tables
reproduce.py               Reproduce measurements and validation
build.py                   Rebuild the PDF
package.py                 Rebuild the ZIP and checksum manifest
MANIFEST.sha256            Hashes for all packaged files other than itself
ATTRIBUTION.txt             Provenance and division of contributions
LICENSE_SOURCE.txt         MIT-0 source license

No supporting generator, translator, baseline checker, or reference oracle
is imported by either delivered acceptance program. The only runtime
dependencies of those programs are Python and its json and sys modules.
