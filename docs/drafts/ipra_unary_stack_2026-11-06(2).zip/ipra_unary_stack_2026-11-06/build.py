"""Build the article; requires a standard LaTeX installation with latexmk."""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    command = ['latexmk', '-pdf', '-interaction=nonstopmode', '-halt-on-error',
               '-file-line-error', 'report.tex']
    process = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    (ROOT / 'results/build.log').write_text(process.stdout + process.stderr)
    if process.returncode:
        print(process.stdout[-12000:])
        print(process.stderr)
        raise SystemExit(process.returncode)
    pdf = ROOT / 'report.pdf'
    result = {'status': 'PASS', 'command': command, 'pdf_bytes': pdf.stat().st_size}
    (ROOT / 'results/build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
