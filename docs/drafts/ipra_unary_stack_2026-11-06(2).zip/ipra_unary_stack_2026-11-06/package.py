"""Create the deliverable archive with hashes and stable ZIP timestamps."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_SUFFIXES = {'.aux', '.fdb_latexmk', '.fls', '.log', '.out', '.toc', '.pyc'}


def included():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts
                  and p.suffix not in SKIP_SUFFIXES
                  and p.name != 'MANIFEST.sha256')


def main():
    files = included()
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() +
                               '  ' + p.relative_to(ROOT).as_posix() + '\n'
                               for p in files))
    target = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted([*files, manifest]):
            name = ROOT.name + '/' + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, (2026, 11, 6, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise ValueError('Archive integrity check failed')
    print(str(target))
    print('bytes:', target.stat().st_size)
    print('sha256:', hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
