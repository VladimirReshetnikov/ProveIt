#!/usr/bin/env python3
"""Reproduce finite checks and the PDF; optionally rerun the Lean kernel."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import subprocess
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="An installed Lean 4 executable")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    verification = root / "verification"
    verification.mkdir(exist_ok=True)
    results = []

    def run(label: str, command: list[str]) -> None:
        completed = subprocess.run(command, cwd=root, capture_output=True, text=True)
        output = completed.stdout + completed.stderr
        (verification / f"{label}.log").write_text(output)
        results.append({"step": label, "exit_code": completed.returncode})
        print(f"{label}: exit {completed.returncode}")
        if completed.returncode:
            print(output[-10000:])
            (verification / "build_results.json").write_text(
                json.dumps({"status": "FAIL", "steps": results}, indent=2) + "\n")
            raise SystemExit(completed.returncode)

    run("check_syntax", [sys.executable, "checks/check_syntax.py"])
    run("check_witnesses", [sys.executable, "checks/check_witnesses.py"])
    if args.lean:
        run("lean_check", [args.lean, "formal/PredecessorWitness.lean"])
    for index in range(1, 4):
        run(f"latex_pass_{index}", ["pdflatex", "-interaction=nonstopmode",
                                    "-halt-on-error", "report.tex"])
    log = (root / "report.log").read_text(errors="replace")
    bad_patterns = (
        r"Overfull \\hbox", r"Overfull \\vbox",
        r"LaTeX Warning:.*undefined", r"There were undefined references",
        r"LaTeX Warning: Label\(s\) may have changed",
        r"pdfTeX warning",
    )
    issues = [pattern for pattern in bad_patterns if re.search(pattern, log)]
    result = {
        "status": "PASS" if not issues else "REVIEW_REQUIRED",
        "steps": results,
        "layout_or_reference_issues": issues,
        "lean_rerun_in_this_build": bool(args.lean),
        "lean_independent_verification": "formal/verification.json",
        "pdf": "report.pdf",
    }
    (verification / "build_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if issues:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
