#!/usr/bin/env python3
"""Finite checks of the explicit witnesses and the pairing construction.

The written and Lean proofs supply the general mathematical arguments.
These checks exercise both zero and positive seeds, failed returns,
later returns after a failure, and the precise predecessor selector.
They do not prove all-model equivalence or consistency.
"""

from __future__ import annotations

import hashlib
from itertools import product
import json
from pathlib import Path


def q(counter: int, seed: int) -> int:
    return seed if counter == 0 else counter - 1


def z(counter: int, seed: int) -> int:
    return seed if counter == 0 else 0


def first_failure(values: tuple[int, ...] | list[int], n: int) -> int:
    """The exact recursion (not an invocation of min) used in the paper."""
    candidate = 0
    seed = values[0]
    for k in range(n):
        if candidate == 0 and values[k + 1] != seed:
            candidate = k + 1
    return candidate


def verify_invariant(values: tuple[int, ...] | list[int], n: int) -> int:
    seed = values[0]
    b = first_failure(values, n)
    if b == 0:
        assert values[n] == seed
    else:
        assert values[b] != seed
        assert values[b - 1] == seed
    return b


def verify_generic(values: tuple[int, ...] | list[int], n: int) -> None:
    seed = values[0]
    b = verify_invariant(values, n)
    bit = int(values[b] == seed)
    selected = q(z(bit, b), n)
    assert 0 <= selected < len(values)
    assert values[selected] == seed


def verify_raw(values: tuple[int, ...] | list[int], n: int) -> None:
    seed = values[0]
    assert all(value in (0, seed) for value in values)
    b = verify_invariant(values, n)
    selected = q(z(values[b], b), n)
    assert 0 <= selected < len(values)
    assert values[selected] == seed


def triangular_and_block(maximum: int) -> tuple[list[int], list[int]]:
    triangular = [0]
    for n in range(maximum + 1):
        triangular.append(triangular[-1] + n + 1)
    limit = triangular[maximum]
    block = [0]
    for value in range(limit):
        old = block[-1]
        block.append(old + int(value + 1 == triangular[old + 1]))
    return triangular, block


def main() -> None:
    generic_checks = 0
    generic_prefixes = 0
    # All four-valued trajectory prefixes through seven update steps.
    for length in range(8):
        for seed in range(4):
            for tail in product(range(4), repeat=length):
                values = (seed, *tail)
                generic_prefixes += 1
                for n in range(length + 1):
                    verify_generic(values, n)
                    generic_checks += 1

    raw_checks = 0
    raw_prefixes = 0
    # A larger corpus allows returns after failures; it is more general
    # than an absorbing latch but still obeys the range hypothesis.
    for length in range(11):
        for seed in range(5):
            for mask in product((False, True), repeat=length):
                values = (seed, *(seed if keep else 0 for keep in mask))
                raw_prefixes += 1
                for n in range(length + 1):
                    verify_raw(values, n)
                    raw_checks += 1

    actual_latch_checks = 0
    tails = (
        lambda v, w: 0,
        lambda v, w: 1,
        lambda v, w: w % 3,
        lambda v, w: int(w == v),
        lambda v, w: (v + w) % 5,
        lambda v, w: int(w >= 17),
    )
    for tail in tails:
        for seed in range(16):
            values = [seed]
            for n in range(64):
                values.append(z(tail(values[-1], n), values[-1]))
            for n in range(len(values)):
                verify_raw(values, n)
                actual_latch_checks += 1

    triangular, block = triangular_and_block(128)
    block_checks = 0
    for b in range(127):
        assert block[triangular[b]] == b
        for j in range(b + 1):
            assert block[triangular[b] + j] == b
            block_checks += 1
    pairing_checks = 0
    for x in range(64):
        for y in range(64):
            encoded = triangular[x + y] + y
            right = max(encoded - triangular[block[encoded]], 0)
            left = max(block[encoded] - right, 0)
            assert (left, right) == (x, y)
            pairing_checks += 1

    # N is the separately discussed normalizer; its natural-number
    # interpretation is identity. The paper/Lean proof treats extra roots.
    normalizer_checks = 0
    for a in range(64):
        normalized = z(int(a == 0), 1 + q(a, 0))
        assert normalized == a
        normalizer_checks += 1

    result = {
        "status": "PASS",
        "scope": "Exhaustive finite prefix checks and bounded arithmetic checks only",
        "generic_prefixes": generic_prefixes,
        "generic_target_checks": generic_checks,
        "generic_maximum_steps": 7,
        "generic_state_alphabet": list(range(4)),
        "raw_prefixes": raw_prefixes,
        "raw_target_checks": raw_checks,
        "raw_maximum_steps": 10,
        "raw_seeds": list(range(5)),
        "actual_latch_target_checks": actual_latch_checks,
        "triangular_block_checks": block_checks,
        "pairing_retraction_checks": pairing_checks,
        "normalizer_checks": normalizer_checks,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    destination = Path(__file__).with_name("witness_results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
