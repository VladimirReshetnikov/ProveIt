#!/usr/bin/env python3
"""Independent syntax audit of the predecessor-witness PRA emitter.

Every compared formula is built as a syntax tree.  Recursor descriptions
are frozen finite trees, and the full metric charges each description at
every occurrence.  No incumbent checker is imported.  The autonomous
archive is compared on explicitly matched two-slot formula profiles, not
claimed to have the same signature as the three binary-return archives.

This executable checks finite syntax, counts, and comparison examples.
It does not prove consistency, induction, or bi-interpretability.  The
general comparison is established algebraically in the accompanying paper.
Run with Python 3.10 or later; no third-party dependencies are required.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import random


@dataclass(frozen=True, slots=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


@dataclass(frozen=True, slots=True)
class Formula:
    tag: str
    args: tuple["Term | Formula", ...] = ()
    binder: str = ""


def var(name: str) -> Term:
    return Term("variable", name=name)


N, A, B, C, K, V, W, X, Y = map(var, ("n", "a", "b", "c", "k", "v", "w", "x", "y"))
ZERO = Term("zero")
FALSE = Formula("false")


def succ(value: Term) -> Term:
    return Term("successor", (value,))


ONE = succ(ZERO)


def chi(left: Term, right: Term) -> Term:
    return Term("chi", (left, right))


def is_rec(term: Term, body: Term) -> bool:
    return term.tag == "recursor" and term.body == body


def normalize(term: Term) -> Term:
    """Strip outer Q(Sr,s) only; arguments and descriptions stay frozen."""
    while is_rec(term, W) and term.args[0].tag == "successor":
        term = term.args[0].args[0]
    return term


def free_variables(term: Term) -> frozenset[str]:
    if term.tag == "variable":
        return frozenset((term.name,))
    return frozenset().union(*(free_variables(arg) for arg in term.args))


def rec(body: Term, counter: Term, seed: Term, canonical: bool = True) -> Term:
    if not free_variables(body) <= {"v", "w"}:
        raise ValueError("A stored description captures a numerical variable")
    return Term("recursor", (counter, seed), body=normalize(body) if canonical else body)


def q(counter: Term, seed: Term) -> Term:
    return rec(W, counter, seed)


def z(counter: Term, seed: Term) -> Term:
    return rec(ZERO, counter, seed)


def substitute(term: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous substitution acts only on active arguments."""
    if term.tag == "variable":
        return replacements.get(term.name, term)
    return Term(term.tag, tuple(substitute(arg, replacements) for arg in term.args),
                term.name, term.body)


def at(term: Term, first: Term, second: Term) -> Term:
    return substitute(term, {"n": first, "a": second})


def selected_rec(term: Term, counter: Term, seed: Term,
                 canonical: bool = True) -> Term:
    return rec(at(term, V, W), counter, seed, canonical=canonical)


def weight(tree: Term | Formula, full: bool = False) -> int:
    total = 1 + sum(weight(arg, full) for arg in tree.args)
    if full and isinstance(tree, Term) and tree.tag == "recursor":
        assert tree.body is not None
        total += weight(tree.body, True)
    return total


def occurrences(term: Term, variable: str) -> int:
    return int(term.tag == "variable" and term.name == variable) + sum(
        occurrences(arg, variable) for arg in term.args)


def profile(term: Term) -> tuple[int, int, int, int, int]:
    return (weight(term), weight(term, True), weight(normalize(term), True),
            occurrences(term, "n"), occurrences(term, "a"))


def equality(left: Term, right: Term) -> Formula:
    return Formula("equals", (left, right))


def conjunction(left: Formula, right: Formula) -> Formula:
    return Formula("and", (left, right))


def disjunction(left: Formula, right: Formula) -> Formula:
    return Formula("or", (left, right))


def implies(left: Formula, right: Formula) -> Formula:
    return Formula("implies", (left, right))


def forall(variable: str, formula: Formula) -> Formula:
    return Formula("forall", (formula,), variable)


def exists(variable: str, formula: Formula) -> Formula:
    return Formula("exists", (formula,), variable)


def close(formula: Formula) -> Formula:
    return forall("a", forall("n", formula))


def quantifiers(formula: Formula) -> tuple[int, int]:
    children = [quantifiers(arg) for arg in formula.args if isinstance(arg, Formula)]
    own = int(formula.tag in {"forall", "exists"})
    return (own + sum(total for total, _ in children),
            own + max((depth for _, depth in children), default=0))


SEPARATION = implies(equality(ZERO, ONE), FALSE)
BIT = close(conjunction(equality(chi(A, A), ONE),
                        disjunction(equality(A, N), equality(chi(A, N), ZERO))))
COVERAGE = forall("x", exists("y", disjunction(equality(X, ZERO),
                                              equality(X, succ(Y)))))
OLD_SEED = q(succ(N), A)
ROOTED_SEED = z(chi(N, ZERO), A)


def seed_formula() -> Formula:
    return close(conjunction(SEPARATION, BIT.args[0].args[0]))


def computation(term: Term, right: bool = False, canonical: bool = True,
                immutable_seed: bool = False) -> Formula:
    base = equality(selected_rec(term, ZERO, A, canonical), A)
    if right:
        update = selected_rec(term, N, at(term, A, ZERO), canonical)
    else:
        update = at(term, selected_rec(term, N, A, canonical),
                    A if immutable_seed else N)
    step = equality(selected_rec(term, succ(N), A, canonical), update)
    return conjunction(base, step)


def bound_computation(term: Term) -> Formula:
    base = equality(selected_rec(term, ZERO, A), A)
    step = forall("c", implies(equality(selected_rec(term, N, A), C),
                                equality(selected_rec(term, succ(N), A), at(term, C, N))))
    return conjunction(base, step)


def predecessor_witness(term: Term, raw: bool) -> Formula:
    probe = selected_rec(term, B, A)
    test = probe if raw else chi(probe, A)
    index = q(z(test, B), N)
    conclusion = equality(selected_rec(term, index, A), A)
    return close(exists("b", conclusion))


def is_plain_latch(term: Term) -> bool:
    return is_rec(term, ZERO) and term.args[1] == N


def new_emitter(term: Term) -> tuple[str, Formula]:
    _, _, _, first, second = profile(term)
    if term == ZERO:
        return "coverage", COVERAGE
    if term == OLD_SEED:
        return "separation", SEPARATION
    if term == ROOTED_SEED:
        return "equality_bit", BIT
    if is_plain_latch(term):
        return "raw_predecessor_witness", predecessor_witness(term, raw=True)
    if normalize(term) == term and first > 0 and term != N:
        return "generic_predecessor_witness", predecessor_witness(term, raw=False)
    if first > 0 and second == 0:
        return "autonomous_right", close(computation(term, right=True))
    if first >= 4:
        return "bound_state", close(bound_computation(term))
    return "ordinary_left", close(computation(term))


def expected_new_counts(term: Term, branch: str) -> tuple[int, int]:
    size, full, normalized, first, _ = profile(term)
    constants = {"coverage": (10, 10), "separation": (6, 6),
                 "equality_bit": (18, 18)}
    if branch in constants:
        return constants[branch]
    if branch == "raw_predecessor_witness":
        return 14, 16 + 2 * normalized
    if branch == "generic_predecessor_witness":
        return 16, 18 + 2 * normalized
    if branch == "autonomous_right":
        return 15 + size, 15 + full + 3 * normalized
    if branch == "bound_state":
        return 20 + size, 20 + full + 3 * normalized
    return 13 + size + 2 * first, 13 + full + 2 * first + (2 + first) * normalized


def identity_guard(tail: Term) -> Term:
    return q(z(chi(A, ZERO), succ(tail)), N)


def identity_guard_tail(term: Term) -> Term | None:
    if not (is_rec(term, W) and term.args[1] == N):
        return None
    inner = term.args[0]
    if not (is_rec(inner, ZERO) and inner.args[0] == chi(A, ZERO)):
        return None
    return inner.args[1].args[0] if inner.args[1].tag == "successor" else None


def wider_identity_guard(tail: Term) -> Term:
    return z(chi(N, ZERO), identity_guard(tail))


def is_identity_guard(term: Term, wider: bool = False) -> bool:
    if identity_guard_tail(term) is not None:
        return True
    return (wider and is_rec(term, ZERO) and term.args[0] == chi(N, ZERO)
            and identity_guard_tail(term.args[1]) is not None)


def rooted_guard(tail: Term) -> Term:
    return z(z(chi(A, ZERO), chi(tail, ZERO)), N)


def is_rooted_guard(term: Term) -> bool:
    if not is_plain_latch(term):
        return False
    inner = term.args[0]
    return (is_rec(inner, ZERO) and inner.args[0] == chi(A, ZERO)
            and inner.args[1].tag == "chi" and inner.args[1].args[1] == ZERO)


def boundary_formula(term: Term) -> Formula:
    first = equality(selected_rec(term, succ(B), A), A)
    next_return = equality(selected_rec(term, succ(succ(B)), A), A)
    return close(exists("b", conjunction(first, implies(next_return, equality(B, N)))))


def local_formula(term: Term) -> Formula:
    test = chi(selected_rec(term, succ(succ(B)), A), A)
    index = q(z(test, succ(B)), N)
    return close(exists("b", equality(selected_rec(term, succ(index), A), A)))


def rooted_formula(term: Term) -> Formula:
    first = equality(selected_rec(term, succ(B), A), A)
    second = equality(selected_rec(term, succ(succ(B)), A), A)
    target = equality(selected_rec(term, succ(N), A), A)
    return close(implies(forall("b", implies(first, second)), target))


def incumbent_binary(term: Term, kind: str) -> tuple[str, Formula]:
    _, _, _, first, second = profile(term)
    if term == (ROOTED_SEED if kind == "rooted" else OLD_SEED):
        return "seed", seed_formula()
    if first > 0 and second == 0:
        return "autonomous_right", close(computation(term, right=True))
    if kind == "rooted" and is_rooted_guard(term):
        return "rooted_return", rooted_formula(term)
    if kind in {"local", "local_optional", "boundary"}:
        if is_identity_guard(term, wider=(kind == "local_optional")):
            formula = boundary_formula(term) if kind == "boundary" else local_formula(term)
            return "boundary" if kind == "boundary" else "local_return", formula
    if kind == "rooted" and first >= 4:
        return "bound_state", close(bound_computation(term))
    return "ordinary_left", close(computation(term))


def autonomous_profiles(term: Term) -> dict[str, Formula]:
    """Actual two-slot formula trees; immutable-parameter signatures differ."""
    first = occurrences(term, "n")
    size = weight(term)
    term_descent = implies(forall("k", equality(at(term, K, A),
                                               succ(at(term, succ(K), A)))), FALSE)
    orbit_descent = implies(forall("k", equality(selected_rec(term, K, A, False),
                            succ(selected_rec(term, succ(K), A, False)))), FALSE)
    basic = computation(term, canonical=False)
    term_formula = close(conjunction(basic, term_descent))
    orbit_formula = close(conjunction(basic, orbit_descent))
    seeded_formula = close(conjunction(computation(term, canonical=False,
                                                  immutable_seed=True), orbit_descent))
    return {
        "autonomous_term_profile": term_formula,
        "autonomous_orbit_profile": orbit_formula,
        "autonomous_seed_aware_profile": seeded_formula,
        "autonomous_active_selector": term_formula if 2 * size + first <= 7 else orbit_formula,
        "autonomous_full_selector": term_formula if first <= 7 else orbit_formula,
        "autonomous_joint_selector": term_formula if first < 7 else orbit_formula,
    }


def incumbent_formulas(term: Term) -> dict[str, tuple[str, Formula]]:
    result = {name: incumbent_binary(term, name)
              for name in ("rooted", "boundary", "local", "local_optional")}
    result.update({name: ("matched_two_slot_profile", formula)
                   for name, formula in autonomous_profiles(term).items()})
    return result


def expected_incumbent_counts(term: Term, branch: str) -> tuple[int, int]:
    size, full, normalized, first, _ = profile(term)
    if branch == "seed":
        return 25, 25
    if branch == "autonomous_right":
        return 15 + size, 15 + full + 3 * normalized
    if branch == "bound_state":
        return 20 + size, 20 + full + 3 * normalized
    if branch == "rooted_return":
        return 24, 24 + 3 * full
    if branch == "boundary":
        return 21, 21 + 2 * full
    if branch == "local_return":
        return 20, 22 + 2 * full
    return 13 + size + 2 * first, 13 + full + 2 * first + (2 + first) * normalized


def literal_text(term: Term) -> str:
    if term.tag == "variable":
        return term.name
    if term == ZERO:
        return "0"
    if term.tag == "successor":
        return "S(" + literal_text(term.args[0]) + ")"
    if term.tag == "chi":
        label = "chi"
    elif is_rec(term, W):
        label = "Q"
    elif is_rec(term, ZERO):
        label = "Z"
    else:
        assert term.body is not None
        label = "R[" + literal_text(term.body) + "]"
    return label + "(" + ",".join(literal_text(arg) for arg in term.args) + ")"


def formula_text(formula: Formula) -> str:
    if formula.tag == "false":
        return "false"
    if formula.tag == "equals":
        return literal_text(formula.args[0]) + " = " + literal_text(formula.args[1])
    if formula.tag in {"forall", "exists"}:
        return formula.tag + " " + formula.binder + ". (" + formula_text(formula.args[0]) + ")"
    operator = {"and": " and ", "or": " or ", "implies": " -> "}[formula.tag]
    return "(" + formula_text(formula.args[0]) + operator + formula_text(formula.args[1]) + ")"


def exhaustive_terms(limit: int) -> list[Term]:
    """Every active term through limit over 0,n,a,S,chi,Q,Z, with fixed Q/Z."""
    by_size = {1: [ZERO, N, A]}
    for size in range(2, limit + 1):
        terms = [succ(term) for term in by_size[size - 1]]
        for left_size in range(1, size - 1):
            right_size = size - 1 - left_size
            for left in by_size[left_size]:
                for right in by_size[right_size]:
                    terms.extend((chi(left, right), q(left, right), z(left, right)))
        by_size[size] = terms
    return [term for size in range(1, limit + 1) for term in by_size[size]]


def random_term(rng: random.Random, budget: int, bodies: list[Term]) -> Term:
    if budget == 1:
        return rng.choice((ZERO, N, A))
    if budget == 2 or rng.randrange(4) == 0:
        return succ(random_term(rng, budget - 1, bodies))
    left_size = rng.randrange(1, budget - 1)
    left = random_term(rng, left_size, bodies)
    right = random_term(rng, budget - 1 - left_size, bodies)
    constructor = rng.randrange(4)
    if constructor == 0:
        return chi(left, right)
    if constructor == 1:
        return q(left, right)
    if constructor == 2:
        return z(left, right)
    return rec(rng.choice(bodies), left, right)


def example_terms() -> dict[str, Term]:
    result = {"zero": ZERO, "counter_slot": A, "state_slot": N,
              "successor_state": succ(N), "old_seed": OLD_SEED,
              "rooted_seed": ROOTED_SEED, "plain_latch_zero": z(ZERO, N),
              "plain_latch_counter": z(A, N), "identity_guard_zero": identity_guard(ZERO),
              "rooted_guard_zero": rooted_guard(ZERO),
              "optional_local_guard_zero": wider_identity_guard(ZERO)}
    tail = A
    for index in range(1, 21):
        tail = chi(N, tail)
        if index in {4, 8, 20}:
            result[f"chi_family_{index}"] = tail
            result[f"latch_family_{index}"] = z(tail, N)
            result[f"alias_family_{index}"] = q(succ(tail), A)
    nested = rec(z(chi(W, ZERO), V), N, A)
    result["nested_description"] = rec(chi(V, at(nested, V, W)), N, A)
    return result


def audit_one(term: Term) -> dict:
    branch, formula = new_emitter(term)
    counts = weight(formula), weight(formula, True)
    assert counts == expected_new_counts(term, branch), (literal_text(term), branch, counts)
    size, full, normalized, first, _ = profile(term)
    all_baselines = incumbent_formulas(term)
    baseline_counts = {}
    for name, (baseline_branch, baseline_formula) in all_baselines.items():
        pair = weight(baseline_formula), weight(baseline_formula, True)
        if baseline_branch != "matched_two_slot_profile":
            expected = expected_incumbent_counts(term, baseline_branch)
            assert pair == expected, (name, literal_text(term), pair, expected)
        else:
            if name == "autonomous_term_profile":
                assert pair == (19 + 3 * size + 3 * first,
                                19 + (5 + first) * full + 3 * first)
            if name in {"autonomous_orbit_profile", "autonomous_seed_aware_profile"}:
                assert pair == (26 + size + 2 * first,
                                26 + (5 + first) * full + 2 * first)
        assert all(counts[i] <= pair[i] for i in (0, 1)), (
            literal_text(term), branch, counts, name, baseline_branch, pair)
        baseline_counts[name] = {"branch": baseline_branch, "active": pair[0], "full": pair[1]}
    envelope = tuple(min(entry[key] for entry in baseline_counts.values())
                     for key in ("active", "full"))
    # This is the exact uniform double alias used in the mathematical proof.
    # Two outer Q(S-,-) reductions leave the original raw term unchanged.
    alias = q(succ(q(succ(term), A)), A)
    assert normalize(alias) == normalize(term)
    assert alias.args[0].args[0].args[0].args[0] == term
    assert selected_rec(alias, N, A) == selected_rec(term, N, A)
    alias_branch, _ = new_emitter(alias)
    assert alias_branch in {"ordinary_left", "bound_state"}, (literal_text(alias), alias_branch)
    assert weight(alias) == size + 6 and weight(alias, True) == full + 8
    assert normalize(normalize(term)) == normalize(term)
    assert normalized <= full
    return {"input": literal_text(term), "profile": {"m": size, "W": full, "V": normalized,
            "i": first, "j": occurrences(term, "a")}, "branch": branch,
            "new": {"active": counts[0], "full": counts[1]},
            "envelope": {"active": envelope[0], "full": envelope[1]},
            "strict_active": counts[0] < envelope[0], "strict_full": counts[1] < envelope[1],
            "baselines": baseline_counts, "formula": formula_text(formula),
            "quantifiers": quantifiers(formula)}


def main() -> None:
    destination = Path(__file__).resolve().parent
    # These checks would fail if active substitution entered stored bodies,
    # if normalization traversed arguments, or if it ignored root aliases.
    frozen_body = chi(V, W)
    frozen_term = rec(frozen_body, N, A)
    changed = substitute(frozen_term, {"n": A, "a": N, "v": ZERO, "w": ZERO})
    assert changed.body == frozen_body and changed.args == (A, N)
    inner_alias = q(succ(N), A)
    outer = chi(inner_alias, ZERO)
    assert normalize(inner_alias) == N and normalize(outer) == outer
    assert profile(rec(succ(V), N, A))[3:] == (1, 1)

    small = exhaustive_terms(5)
    rng = random.Random(20261102)
    bodies = [V, W, ZERO, succ(V), chi(V, W), z(chi(W, ZERO), V)]
    bodies.append(rec(bodies[-1], V, W))
    randoms = [random_term(rng, rng.randrange(6, 28), bodies) for _ in range(1200)]
    designed = []
    for tail in small:
        designed.extend((z(tail, N), identity_guard(tail), rooted_guard(tail),
                         wider_identity_guard(tail), q(succ(tail), A),
                         q(succ(q(succ(tail), A)), A)))
    examples = example_terms()
    corpus = list(dict.fromkeys(small + randoms + designed + list(examples.values())))
    branches = Counter()
    strict_active = strict_full = strict_both = ties = 0
    max_quantifiers = max_depth = 0
    for term in corpus:
        record = audit_one(term)
        branches[record["branch"]] += 1
        strict_active += record["strict_active"]
        strict_full += record["strict_full"]
        strict_both += record["strict_active"] and record["strict_full"]
        ties += not record["strict_active"] and not record["strict_full"]
        total, depth = record["quantifiers"]
        max_quantifiers, max_depth = max(max_quantifiers, total), max(max_depth, depth)

    example_records = {label: audit_one(term) for label, term in examples.items()}
    results = {
        "status": "PASS", "scope": "Finite AST accounting; not a semantic formal proof",
        "repository_snapshot": "53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4",
        "source_archives": ["pra_autonomous_orbits_2026-11-02.zip",
                            "pra_boundary_witness_2026-11-02.zip",
                            "pra_local_return_2026-11-02.zip",
                            "pra_rooted_return_2026-11-02.zip"],
        "autonomous_comparison_scope": "Matched k=0 profiles; signatures are not identified",
        "all_compared_formulas_are_constructed_trees": True,
        "metric": {"active": "Every variable, constant, application, formula node and quantifier",
                   "full": "Active plus recursively expanded descriptor at each occurrence",
                   "negation": "Expanded as implication to false", "one": "Expanded as S(0)"},
        "random_seed": 20261102, "exhaustive_limit": 5,
        "exhaustive_alphabet": ["0", "n", "a", "S", "chi", "Q", "Z"],
        "exhaustive_terms": len(small), "random_candidates": len(randoms),
        "designed_candidates": len(designed), "unique_inputs": len(corpus),
        "baseline_formulas_per_input": 10, "baseline_comparisons": 10 * len(corpus),
        "new_formula_weight_checks": 2 * len(corpus),
        "literal_binary_baseline_weight_checks": 8 * len(corpus),
        "autonomous_direct_profile_weight_checks": 6 * len(corpus),
        "double_alias_recovery_checks": len(corpus), "strict_active": strict_active,
        "strict_full": strict_full, "strict_both": strict_both, "ties_both": ties,
        "new_branch_counts": dict(sorted(branches.items())),
        "maximum_quantifier_count": max_quantifiers, "maximum_quantifier_depth": max_depth,
        "fixed_calibration_cost": {"coverage": 10, "separation": 6, "equality_bit": 18,
                                   "total": 34, "previous_combined_seed": 25},
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (destination / "syntax_results.json").write_text(json.dumps(results, indent=2) + "\n")
    (destination / "syntax_examples.json").write_text(json.dumps(example_records, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
