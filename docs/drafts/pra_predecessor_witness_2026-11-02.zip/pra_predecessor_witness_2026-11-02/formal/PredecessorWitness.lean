import Std

/-!
# Predecessor witnesses: an arbitrary-carrier proof kernel

The forward theorems quantify over an arbitrary type A. They do not use
natural-number induction, an induction hypothesis on A, or classical choice.
The fixed coverage axiom is an explicit field of Kernel. The raw and generic
witnesses are exactly the arithmetic terms in the accompanying article.

Reverse soundness is proved from one explicitly displayed quantifier-free
boundary invariant. A separate Nat specialization constructs its primitive
recursive candidate and proves the invariant by Nat induction.

This file does not formalize the syntax emitter, description normalization,
the finite truth-term compiler, the pairing proof, or the complete
bi-interpretation. See SCOPE.txt for the exact verification boundary.
-/

namespace PredecessorWitness

universe u

def ReturnClosed {A : Type u} (s : A → A) (F : A → A) (a : A) : Prop :=
  ∀ n, F n = a → F (s n) = a

/-- Computational arithmetic before the fixed coverage axiom is imposed. -/
structure BareKernel (A : Type u) where
  zero : A
  succ : A → A
  Q : A → A → A
  Z : A → A → A
  chi : A → A → A
  separated : zero ≠ succ zero
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ n a, Q (succ n) a = n
  z_zero : ∀ a, Z zero a = a
  z_succ : ∀ n a, Z (succ n) a = zero
  chi_diag : ∀ a, chi a a = succ zero
  chi_off : ∀ a b, a = b ∨ chi a b = zero

/-- The primary theory's fixed basis, including existential coverage. -/
structure Kernel (A : Type u) extends BareKernel A where
  coverage : ∀ x, ∃ y, x = zero ∨ x = succ y

namespace Kernel

variable {A : Type u} (K : Kernel A)

def pred (x : A) : A := K.Q x K.zero

theorem pred_succ (x : A) : K.pred (K.succ x) = x := K.q_succ x K.zero

theorem succ_injective (x y : A) (h : K.succ x = K.succ y) : x = y := by
  have hp := congrArg (fun z => K.Q z K.zero) h
  simpa only [K.q_succ] using hp

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro hs
  have hx : x = K.zero := by
    have hp := congrArg (fun z => K.Q z K.zero) hs
    simpa only [K.q_succ, K.q_zero] using hp
  apply K.separated
  exact hs.symm.trans (congrArg K.succ hx)

theorem zero_or_succ (x : A) : x = K.zero ∨ ∃ y, x = K.succ y := by
  rcases K.coverage x with ⟨y, hy | hy⟩
  · exact Or.inl hy
  · exact Or.inr ⟨y, hy⟩

theorem coverage_pred (x : A) : x = K.zero ∨ x = K.succ (K.pred x) := by
  rcases K.zero_or_succ x with hx | ⟨y, hx⟩
  · exact Or.inl hx
  · apply Or.inr
    simp only [hx, K.pred_succ]

theorem chi_of_ne (x y : A) (h : x ≠ y) : K.chi x y = K.zero := by
  rcases K.chi_off x y with he | hc
  · exact False.elim (h he)
  · exact hc

include K in
theorem eq_or_ne (x y : A) : x = y ∨ x ≠ y := by
  rcases K.chi_off x y with he | hc
  · exact Or.inl he
  · apply Or.inr
    intro he
    subst x
    apply K.separated
    exact hc.symm.trans (K.chi_diag y)

theorem z_any_zero (x : A) : K.Z x K.zero = K.zero := by
  rcases K.zero_or_succ x with hx | ⟨y, hx⟩
  · simp only [hx, K.z_zero]
  · simp only [hx, K.z_succ]

/-- The 14-active-node witness uses this selector, with x = F(b). -/
def rawPick (x b n : A) : A := K.Q (K.Z x b) n

/-- The 16-active-node generic witness inserts the native-equality bit. -/
def genericPick (x a b n : A) : A := K.Q (K.Z (K.chi x a) b) n

def RawPW (F : A → A) (a : A) : Prop :=
  ∀ n, ∃ b, F (K.rawPick (F b) b n) = a

def GenericPW (F : A → A) (a : A) : Prop :=
  ∀ n, ∃ b, F (K.genericPick (F b) a b n) = a

theorem genericPick_of_eq (x a b n : A) (hx : x = a) :
    K.genericPick x a b n = n := by
  subst x
  simp only [genericPick, K.chi_diag, K.z_succ, K.q_zero]

theorem genericPick_of_ne_at_succ (x a b n : A) (hx : x ≠ a) :
    K.genericPick x a (K.succ b) n = b := by
  simp only [genericPick, K.chi_of_ne x a hx, K.z_zero, K.q_succ]

/-- No induction principle is used; coverage deals with the witness index. -/
theorem genericPW_implies_returns (F : A → A) (a : A)
    (hw : K.GenericPW F a) (hc : ReturnClosed K.succ F a) :
    ∀ n, F n = a := by
  intro n
  rcases hw n with ⟨b, hb⟩
  rcases K.chi_off (F b) a with he | hz
  · simpa only [K.genericPick_of_eq _ _ _ _ he] using hb
  · rcases K.zero_or_succ b with hb0 | ⟨c, hbc⟩
    · have hpick : K.genericPick (F b) a b n = n := by
        unfold genericPick
        rw [hz, K.z_zero, hb0, K.q_zero]
      simpa only [hpick] using hb
    · have hfc : F c = a := by
        have hpick : K.genericPick (F b) a b n = c := by
          unfold genericPick
          rw [hz, K.z_zero, hbc, K.q_succ]
        simpa only [hpick] using hb
      have hfb : F b = a := by
        simpa only [hbc] using hc c hfc
      simpa only [K.genericPick_of_eq _ _ _ _ hfb] using hb

/--
Raw predecessor witnesses suffice at a nonzero target. The source theorem
does not assume an orbit-range invariant: coverage handles F(b) directly.
-/
theorem rawPW_implies_returns (F : A → A) (a : A)
    (ha : a ≠ K.zero) (hw : K.RawPW F a)
    (hc : ReturnClosed K.succ F a) : ∀ n, F n = a := by
  intro n
  rcases hw n with ⟨b, hb⟩
  rcases K.zero_or_succ (F b) with hf0 | ⟨c, hfc⟩
  · rcases K.zero_or_succ b with hb0 | ⟨d, hbd⟩
    · have hpick : K.rawPick (F b) b n = n := by
        unfold rawPick
        rw [hf0, K.z_zero, hb0, K.q_zero]
      simpa only [hpick] using hb
    · have hfd : F d = a := by
        have hpick : K.rawPick (F b) b n = d := by
          unfold rawPick
          rw [hf0, K.z_zero, hbd, K.q_succ]
        simpa only [hpick] using hb
      have hfb : F b = a := by
        simpa only [hbd] using hc d hfd
      exact False.elim (ha (hfb.symm.trans hf0))
  · simpa only [rawPick, hfc, K.z_succ, K.q_zero] using hb

/-- The truth bit tests the next counter, not the current counter. -/
def latch (b : A → A → A) (v w : A) : A :=
  K.Z (b (K.succ w) (K.pred v)) v

theorem latch_reflection
    (P : A → A → Prop) (b : A → A → A)
    (brange : ∀ n a, b n a = K.zero ∨ b n a = K.succ K.zero)
    (btruth : ∀ n a, b n a = K.zero ↔ P n a)
    (v w a : A) :
    K.latch b v w = K.succ a ↔ v = K.succ a ∧ P (K.succ w) a := by
  constructor
  · intro hl
    rcases brange (K.succ w) (K.pred v) with hb | hb
    · have hv : v = K.succ a := by
        simpa only [latch, hb, K.z_zero] using hl
      have hba : b (K.succ w) a = K.zero := by
        simpa only [hv, K.pred_succ] using hb
      exact ⟨hv, (btruth (K.succ w) a).mp hba⟩
    · have hz : K.zero = K.succ a := by
        simpa only [latch, hb, K.z_succ] using hl
      exact False.elim (K.succ_ne_zero a hz.symm)
  · rintro ⟨hv, hp⟩
    have hb := (btruth (K.succ w) a).mpr hp
    simp only [latch, hv, K.pred_succ, hb, K.z_zero]

/--
The one-parameter QFI kernel. P can be any predicate admitting the stated
finite truth term. Its base and progress hypotheses remain local throughout.
-/
theorem induction_from_rawPW
    (P : A → A → Prop) (b : A → A → A)
    (brange : ∀ n a, b n a = K.zero ∨ b n a = K.succ K.zero)
    (btruth : ∀ n a, b n a = K.zero ↔ P n a)
    (R : A → A → A)
    (_rzero : ∀ a, R K.zero a = a)
    (rstep : ∀ n a, R (K.succ n) a = K.latch b (R n a) n)
    (witness : ∀ a, K.RawPW (fun n => R n a) a)
    (a : A) (hbase : P K.zero a)
    (hprogress : ∀ n, P n a → P (K.succ n) a) :
    ∀ n, P n a := by
  have reflect : ∀ n, R n (K.succ a) = K.succ a → P n a := by
    intro n hn
    rcases K.zero_or_succ n with hz | ⟨k, hk⟩
    · simpa only [hz] using hbase
    · have hl : K.latch b (R k (K.succ a)) k = K.succ a := by
        rw [← rstep]
        simpa only [hk] using hn
      have hp := ((K.latch_reflection P b brange btruth
        (R k (K.succ a)) k a).mp hl).2
      simpa only [hk] using hp
  have stable : ReturnClosed K.succ (fun n => R n (K.succ a))
      (K.succ a) := by
    intro n hn
    have hp := hprogress n (reflect n hn)
    change R (K.succ n) (K.succ a) = K.succ a
    rw [rstep]
    exact (K.latch_reflection P b brange btruth
      (R n (K.succ a)) n a).mpr ⟨hn, hp⟩
  have allReturns := K.rawPW_implies_returns
    (fun n => R n (K.succ a)) (K.succ a) (K.succ_ne_zero a)
    (witness (K.succ a)) stable
  exact fun n => reflect n (allReturns n)

/-- Updates a boundary candidate; a returning current index selects S(n). -/
def nextCandidate (x a prior n : A) : A :=
  K.Q (K.Z (K.chi x a) (K.succ prior)) (K.succ n)

theorem nextCandidate_of_eq (x a prior n : A) (h : x = a) :
    K.nextCandidate x a prior n = K.succ n := by
  subst x
  simp only [nextCandidate, K.chi_diag, K.z_succ, K.q_zero]

theorem nextCandidate_of_ne (x a prior n : A) (h : x ≠ a) :
    K.nextCandidate x a prior n = prior := by
  simp only [nextCandidate, K.chi_of_ne x a h, K.z_zero, K.q_succ]

/-- This invariant is quantifier-free in F, c and the fixed arithmetic. -/
def BoundaryInvariant (F : A → A) (a : A) (c : A → A) (n : A) : Prop :=
  F n = a ∨ (F (c n) ≠ a ∧ c n ≠ K.zero ∧ F (K.pred (c n)) = a)

theorem boundary_base (F : A → A) (a : A) (c : A → A)
    (hf : F K.zero = a) : K.BoundaryInvariant F a c K.zero := Or.inl hf

theorem boundary_step (F : A → A) (a : A) (c : A → A)
    (cstep : ∀ n, c (K.succ n) = K.nextCandidate (F n) a (c n) n)
    (n : A) (hi : K.BoundaryInvariant F a c n) :
    K.BoundaryInvariant F a c (K.succ n) := by
  rcases K.eq_or_ne (F n) a with hn | hn
  · have hc : c (K.succ n) = K.succ n := by
      rw [cstep, K.nextCandidate_of_eq _ _ _ _ hn]
    rcases K.eq_or_ne (F (K.succ n)) a with hs | hs
    · exact Or.inl hs
    · apply Or.inr
      refine ⟨?_, ?_, ?_⟩
      · simpa only [hc] using hs
      · simpa only [hc] using K.succ_ne_zero n
      · simpa only [hc, K.pred_succ] using hn
  · have hc : c (K.succ n) = c n := by
      rw [cstep, K.nextCandidate_of_ne _ _ _ _ hn]
    apply Or.inr
    rcases hi with hi | hi
    · exact False.elim (hn hi)
    · simpa only [hc] using hi

theorem genericPW_from_boundary (F : A → A) (a : A) (c : A → A)
    (hbase : F K.zero = a)
    (hi : ∀ n, K.BoundaryInvariant F a c n) : K.GenericPW F a := by
  intro n
  rcases hi n with hn | ⟨hbad, hc0, hcgood⟩
  · refine ⟨K.zero, ?_⟩
    simpa only [K.genericPick_of_eq _ _ _ _ hbase] using hn
  · refine ⟨c n, ?_⟩
    rcases K.coverage_pred (c n) with hc | hc
    · exact False.elim (hc0 hc)
    · have hq : K.Q (c n) n = K.pred (c n) := by
        calc
          K.Q (c n) n = K.Q (K.succ (K.pred (c n))) n :=
            congrArg (fun x => K.Q x n) hc
          _ = K.pred (c n) := K.q_succ _ _
      unfold genericPick
      rw [K.chi_of_ne _ _ hbad, K.z_zero, hq]
      exact hcgood

/-- Only this reverse direction assumes the two-valued orbit invariant. -/
theorem rawPW_from_boundary (F : A → A) (a : A) (c : A → A)
    (hrange : ∀ n, F n = K.zero ∨ F n = a)
    (hi : ∀ n, K.BoundaryInvariant F a c n) : K.RawPW F a := by
  intro n
  rcases hi n with hn | ⟨hbad, hc0, hcgood⟩
  · refine ⟨K.zero, ?_⟩
    simpa only [rawPick, K.z_any_zero, K.q_zero] using hn
  · have hf0 : F (c n) = K.zero := by
      rcases hrange (c n) with hz | he
      · exact hz
      · exact False.elim (hbad he)
    refine ⟨c n, ?_⟩
    rcases K.coverage_pred (c n) with hc | hc
    · exact False.elim (hc0 hc)
    · have hq : K.Q (c n) n = K.pred (c n) := by
        calc
          K.Q (c n) n = K.Q (K.succ (K.pred (c n))) n :=
            congrArg (fun x => K.Q x n) hc
          _ = K.pred (c n) := K.q_succ _ _
      unfold rawPick
      rw [hf0, K.z_zero, hq]
      exact hcgood

/-- Reverse PRA soundness needs exactly this displayed QFI instance. -/
theorem genericPW_from_boundaryInduction (F : A → A) (a : A) (c : A → A)
    (hbase : F K.zero = a)
    (cstep : ∀ n, c (K.succ n) = K.nextCandidate (F n) a (c n) n)
    (induction : K.BoundaryInvariant F a c K.zero →
      (∀ n, K.BoundaryInvariant F a c n →
        K.BoundaryInvariant F a c (K.succ n)) →
      ∀ n, K.BoundaryInvariant F a c n) : K.GenericPW F a := by
  exact K.genericPW_from_boundary F a c hbase
    (induction (K.boundary_base F a c hbase) (K.boundary_step F a c cstep))

theorem rawPW_from_boundaryInduction (F : A → A) (a : A) (c : A → A)
    (hbase : F K.zero = a)
    (hrange : ∀ n, F n = K.zero ∨ F n = a)
    (cstep : ∀ n, c (K.succ n) = K.nextCandidate (F n) a (c n) n)
    (induction : K.BoundaryInvariant F a c K.zero →
      (∀ n, K.BoundaryInvariant F a c n →
        K.BoundaryInvariant F a c (K.succ n)) →
      ∀ n, K.BoundaryInvariant F a c n) : K.RawPW F a := by
  exact K.rawPW_from_boundary F a c hrange
    (induction (K.boundary_base F a c hbase) (K.boundary_step F a c cstep))

end Kernel

namespace NatSoundness

def q : Nat → Nat → Nat
  | 0, a => a
  | n + 1, _ => n

def z : Nat → Nat → Nat
  | 0, a => a
  | _ + 1, _ => 0

def chi (x y : Nat) : Nat := if x = y then 1 else 0

def kernel : Kernel Nat where
  zero := 0
  succ := Nat.succ
  Q := q
  Z := z
  chi := chi
  separated := by decide
  q_zero := by intro a; rfl
  q_succ := by intro n a; rfl
  z_zero := by intro a; rfl
  z_succ := by intro n a; rfl
  chi_diag := by intro a; unfold chi; rw [if_pos rfl]
  chi_off := by
    intro a b
    by_cases h : a = b
    · exact Or.inl h
    · exact Or.inr (if_neg h)
  coverage := by
    intro x
    cases x with
    | zero => exact ⟨0, Or.inl rfl⟩
    | succ y => exact ⟨y, Or.inr rfl⟩

/-- Primitive recursion, with F and a as the displayed immutable data. -/
def candidate (F : Nat → Nat) (a : Nat) : Nat → Nat
  | 0 => 0
  | n + 1 => if F n = a then n + 1 else candidate F a n

theorem candidate_step (F : Nat → Nat) (a n : Nat) :
    candidate F a (n + 1) =
      kernel.nextCandidate (F n) a (candidate F a n) n := by
  by_cases h : F n = a
  · rw [kernel.nextCandidate_of_eq _ _ _ _ h]
    simp only [candidate, if_pos h]
    rfl
  · rw [kernel.nextCandidate_of_ne _ _ _ _ h]
    simp only [candidate, if_neg h]

theorem candidate_invariant (F : Nat → Nat) (a : Nat) (hbase : F 0 = a) :
    ∀ n, kernel.BoundaryInvariant F a (candidate F a) n := by
  intro n
  induction n with
  | zero => exact kernel.boundary_base F a (candidate F a) hbase
  | succ n hi =>
    exact kernel.boundary_step F a (candidate F a) (candidate_step F a) n hi

theorem generic_soundness (F : Nat → Nat) (a : Nat) (hbase : F 0 = a) :
    kernel.GenericPW F a := by
  exact kernel.genericPW_from_boundary F a (candidate F a) hbase
    (candidate_invariant F a hbase)

theorem raw_soundness (F : Nat → Nat) (a : Nat) (hbase : F 0 = a)
    (hrange : ∀ n, F n = 0 ∨ F n = a) : kernel.RawPW F a := by
  exact kernel.rawPW_from_boundary F a (candidate F a) hrange
    (candidate_invariant F a hbase)

/-- A concrete zero-or-retain recursor; its tail can be any numerical map. -/
def orbit (t : Nat → Nat → Nat) (a : Nat) : Nat → Nat
  | 0 => a
  | n + 1 => z (t (orbit t a n) n) (orbit t a n)

theorem orbit_range (t : Nat → Nat → Nat) (a : Nat) :
    ∀ n, orbit t a n = 0 ∨ orbit t a n = a := by
  intro n
  induction n with
  | zero => exact Or.inr rfl
  | succ n hi =>
    change z (t (orbit t a n) n) (orbit t a n) = 0 ∨
      z (t (orbit t a n) n) (orbit t a n) = a
    cases htest : t (orbit t a n) n with
    | zero => simpa only [z] using hi
    | succ r => exact Or.inl rfl

/-- The complete raw witness is valid for every such standard orbit. -/
theorem raw_latch_soundness (t : Nat → Nat → Nat) (a : Nat) :
    kernel.RawPW (orbit t a) a := by
  exact raw_soundness (orbit t a) a rfl (orbit_range t a)

end NatSoundness

namespace BareKernel

variable {A : Type u} (K : BareKernel A)

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro hs
  have hx : x = K.zero := by
    have hp := congrArg (fun z => K.Q z K.zero) hs
    simpa only [K.q_succ, K.q_zero] using hp
  apply K.separated
  exact hs.symm.trans (congrArg K.succ hx)

/-- A term whose outputs are zero or successors, without assuming coverage. -/
def normal (x : A) : A := K.Z (K.chi x K.zero) (K.succ (K.Q x K.zero))

theorem normal_range (x : A) :
    K.normal x = K.zero ∨ ∃ y, K.normal x = K.succ y := by
  rcases K.chi_off x K.zero with hx | hc
  · apply Or.inl
    simp only [normal, hx, K.chi_diag, K.z_succ]
  · apply Or.inr
    refine ⟨K.Q x K.zero, ?_⟩
    simp only [normal, hc, K.z_zero]

theorem normal_zero_imp (x : A) (hn : K.normal x = K.zero) : x = K.zero := by
  rcases K.chi_off x K.zero with hx | hc
  · exact hx
  · have hs : K.succ (K.Q x K.zero) = K.zero := by
      simpa only [normal, hc, K.z_zero] using hn
    exact False.elim (K.succ_ne_zero _ hs)

/--
Optional coverage bootstrap. Its witness is the 16-node unshifted
successor-index variant for the one update normal(v). Coverage is not a
hypothesis, since this theorem is stated for BareKernel.
-/
theorem coverage_from_normalized_witness
    (R : A → A → A)
    (rzero : ∀ a, R K.zero a = a)
    (rstep : ∀ n a, R (K.succ n) a = K.normal (R n a))
    (witness : ∀ a n, ∃ b,
      R (K.Q (K.Z (R (K.succ b) a) (K.succ b)) n) a = a) :
    ∀ a, ∃ y, a = K.zero ∨ a = K.succ y := by
  intro a
  rcases witness a (K.succ K.zero) with ⟨b, hb⟩
  have hrange : R (K.succ b) a = K.zero ∨
      ∃ y, R (K.succ b) a = K.succ y := by
    rw [rstep]
    exact K.normal_range (R b a)
  rcases hrange with hz | ⟨y, hs⟩
  · have hba : R b a = a := by
      simpa only [hz, K.z_zero, K.q_succ] using hb
    have hna : K.normal a = K.zero := by
      rw [rstep, hba] at hz
      exact hz
    exact ⟨K.zero, Or.inl (K.normal_zero_imp a hna)⟩
  · have hna : K.normal a = a := by
      have h1 : R (K.succ K.zero) a = a := by
        simpa only [hs, K.z_succ, K.q_zero] using hb
      simpa only [rstep, rzero] using h1
    rcases K.normal_range a with hz | ⟨z, hz⟩
    · exact ⟨K.zero, Or.inl (hna.symm.trans hz)⟩
    · exact ⟨z, Or.inr (hna.symm.trans hz)⟩

end BareKernel

end PredecessorWitness

#print axioms PredecessorWitness.Kernel.succ_ne_zero
#print axioms PredecessorWitness.Kernel.eq_or_ne
#print axioms PredecessorWitness.Kernel.genericPW_implies_returns
#print axioms PredecessorWitness.Kernel.rawPW_implies_returns
#print axioms PredecessorWitness.Kernel.latch_reflection
#print axioms PredecessorWitness.Kernel.induction_from_rawPW
#print axioms PredecessorWitness.Kernel.boundary_step
#print axioms PredecessorWitness.Kernel.genericPW_from_boundaryInduction
#print axioms PredecessorWitness.Kernel.rawPW_from_boundaryInduction
#print axioms PredecessorWitness.NatSoundness.generic_soundness
#print axioms PredecessorWitness.NatSoundness.raw_soundness
#print axioms PredecessorWitness.NatSoundness.raw_latch_soundness
#print axioms PredecessorWitness.BareKernel.coverage_from_normalized_witness
