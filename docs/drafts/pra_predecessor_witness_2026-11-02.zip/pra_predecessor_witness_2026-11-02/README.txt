PRA FROM PREDECESSOR WITNESSES
November 2, 2026

Start with report.pdf. Complete LaTeX is in report.tex and sections/.
AXIOMS.txt provides the exact theory and eight-case serializer independently
of the typeset exposition.

RESULT
The main induction principle is a 14-node existential equation for
zero-or-retain recursors. A generic 16-node predecessor witness covers
other canonical state-bearing inputs in the exact serializer.
The theory is bi-interpretable and equiconsistent with first-order PRA,
indeed it has a common conservative definitional extension with PRA.
The result holds separately in classical and intuitionistic logic.

COMPARISON
All four archives actually present in docs/drafts were inspected at commit
53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4. Their own old comparison tables
were not mistaken for the current directory. Source archive hashes and
immutable links are recorded under provenance/.

The new serializer lies below the matched lower envelope in both active
and full descriptor-repeated tree size. This includes the different seed
locations, local-return optional broader selector, rooted bound-state case,
and explicitly matched k=0 autonomous profiles. It is NOT a global
minimum over logical languages or generator implementations. The fixed
basis costs 34 nodes and the serializer has eight cases.

VALIDATION
checks/check_syntax.py constructs actual formula trees and compares the
specified current profiles. checks/check_witnesses.py tests the explicit
witness construction and pairing computations on finite exhaustive corpora.
Their JSON outputs report exact scope and counts.

formal/PredecessorWitness.lean has been checked with Lean 4.19.0 without
Mathlib. It verifies the arbitrary-carrier induction kernel, reverse witness
invariants, Nat soundness, and an optional coverage-producing normalizer.
See formal/SCOPE.txt and formal/verification.json. The complete syntax,
pairing compiler, and bi-interpretation are proved in the paper; they are
not claimed to be fully mechanically verified by that local kernel.

REBUILD
  python3 build.py
Optional repeat of the Lean check:
  python3 build.py --lean /path/to/lean
Python 3.10+ and a standard pdflatex installation are required.

CONTENTS
report.pdf, report.tex, sections/     Paper and complete source.
AXIOMS.txt                          Standalone exact specification.
checks/                            Reproducible finite checks and results.
formal/                            Lean source, version, logs, and scope.
provenance/                        Repository snapshot and source hashes.
verification/                      Build, mathematical, and PDF checks.
SHA256SUMS                         File checksums for the delivered package.

The input draft ZIPs are cited, not copied into this package.
