#!/usr/bin/env python3
"""Explicit formula-tree and stored-description counts for the paper.

Each variable/constant occurrence, application, equality, connective,
falsehood, and individual quantifier is one node.  Negation is implication
to falsehood; 1 is S(0).  Quantifier-bound variable names are metadata, not
extra children.  Schematic function applications charge their displayed
arguments, not the bodies of the infinitely many programs substituted.
Separate sentences are added without an invented conjunction joining them.

These are disclosed local measures, not complete specification bit lengths.
Run: python3 artifacts/schema_metrics.py
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple["Node", ...] = ()

    def size(self):
        return 1 + sum(child.size() for child in self.children)

    def display(self):
        if not self.children:
            return self.label
        return self.label + "(" + ",".join(child.display() for child in self.children) + ")"


def V(name): return Node(name)
def A(name, *children): return Node(name, children)
def Eq(x,y): return A("=",x,y)
def Imp(x,y): return A("implies",x,y)
def Or(x,y): return A("or",x,y)
def And(x,y): return A("and",x,y)
def S(x): return A("S",x)
Z, BOT = V("0"), V("bottom")
ONE = S(Z)
def Neq(x,y): return Imp(Eq(x,y),BOT)


def All(names, matrix):
    for name in reversed(names):
        matrix = A("forall " + name, matrix)
    return matrix


def params(m):
    return [V("a")] + [V("b"+str(i)) for i in range(1,m)]


def computation(m, grammar):
    p = params(m)
    n, a, frozen = V("n"), p[0], p[1:]
    names = [x.label for x in p]
    r0, rs = A("R",Z,*p), A("R",S(n),*p)
    initialized = grammar in ("initialized_substitution", "swap", "counterfree")
    base = All(names,Eq(r0,a if initialized else A("g",*p)))
    if grammar in ("swap","counterfree"):
        call = A("R",a,n,*frozen)
    elif grammar in ("substitution","initialized_substitution"):
        call = A("R",n,A("k",a),*frozen)
    elif grammar == "fixed_predecessor":
        call = A("R",n,A("p",a),*frozen)
    else:
        call = A("R",n,*p)
    h = A("h",*p,call) if grammar == "counterfree" else A("h",n,*p,call)
    step = All(["n"]+names,Eq(rs,h))
    return base, step


def stationarity(m):
    p = params(m)
    n = V("n")
    return All(["n"], Eq(A("f",S(n),*p),A("f",n,*p)))


def pointed(m, relative=True, uniform=False, reverse=True):
    p, n = params(m), V("n")
    a = p[0]
    fn, f0 = A("f",n,*p), A("f",Z,*p)
    negative_test = Eq(A("T" if relative else "E",f0,a), a if relative else Z)
    equality = Eq(fn,a)
    if uniform:
        conclusion = Or(All(["n"],equality),negative_test)
    else:
        disjunction = Or(negative_test,equality) if reverse else Or(equality,negative_test)
        conclusion = All(["n"],disjunction)
    return All([x.label for x in p],Imp(stationarity(m),conclusion))


def stationary_separation(m):
    p,n = params(m),V("n")
    conclusion = All(["n"],Neq(S(A("f",n,*p)),A("f",Z,*p)))
    return All([x.label for x in p],Imp(stationarity(m),conclusion))


def stationary_agreement(m):
    p,n = params(m),V("n")
    conclusion = All(["n"],Neq(A("E",A("f",n,*p),A("f",Z,*p)),Z))
    return All([x.label for x in p],Imp(stationarity(m),conclusion))


def off_diagonal(relative=False):
    x,y = V("x"),V("y")
    return All(["x","y"],Or(Eq(A("T" if relative else "E",x,y),y if relative else Z),Eq(x,y)))


def classical_iff(m, expanded):
    p,n = params(m),V("n")
    left = Eq(A("E",A("f",n,*p),p[0]),Z)
    right = Neq(A("f",Z,*p),p[0])
    iff = And(Imp(left,right),Imp(right,left)) if expanded else A("iff",left,right)
    return All([x.label for x in p],Imp(stationarity(m),All(["n"],iff)))


def selected_bodies():
    n,a,b,v,y = (V(x) for x in ("n","a","b","v","y"))
    c = lambda z,u,w: A("C",z,u,w)
    d = lambda x,z: A("D",x,z)
    main = {"C_update":b, "D_update":v,
            "T_update":c(d(a,n),d(v,n),a)}
    old_swap = {"C_update":b, "D_update":v,
                "T_update":c(d(a,n),c(d(n,a),a,Z),a)}
    secondary = {"C_update":b, "D_update":v,
                 "B_update":c(d(a,v),c(d(v,a),a,S(a)),a)}
    p = lambda x: A("P",x,Z)
    expanded_c = lambda z,u,w: A("P",A("B",z,S(u)),w)
    initialized_substitution = {
        "P_update":n,"P_transformer":a,
        "B_update":Z,"B_transformer":a,
        "M_update":v,"M_transformer":p(a),
        "R_update":expanded_c(a,Z,S(expanded_c(n,S(p(p(a))),v))),
        "R_transformer":p(a),
    }
    pointed_old = {
        "P_base":a,"P_update":n,"P_transformer":a,
        "B_base":a,"B_update":Z,"B_transformer":a,
        "E_base":A("B",y,ONE),
        "E_update":A("P",A("B",y,ONE),v),
        "E_transformer":p(y),
    }
    probe_old = {
        "P_base":a,"P_update":n,"P_transformer":a,
        "C_base":a,"C_update":b,"C_transformer":a,
        "E_base":c(y,ONE,Z),"E_update":c(y,Z,v),"E_transformer":p(y),
    }
    fixed_p = {
        "p_base":Z,"p_update":n,
        "C_base":a,"C_update":b,
        "E_base":c(y,ONE,Z),"E_update":c(y,Z,v),
    }
    ordinary = {
        "p_base":Z,"p_update":n,
        "M_base":a,"M_update":A("p",v),
        "Z_base":ONE,"Z_update":Z,
        "H_base":Z,"H_update":A("Z",n),
        "E_base":A("Z",a),"E_update":A("H",A("M",n,a)),
    }
    groups = {"main":main,"secondary":secondary,"old_initialized_swap":old_swap,
              "initialized_biinterpretation":initialized_substitution,
              "pointed_constancy":pointed_old,"probe_constancy":probe_old,
              "stationary_comparison":pointed_old,
              "stationary_comparison_1_fixed_predecessor":fixed_p,
              "stationary_agreement":ordinary}
    result = {}
    for name,bodies in groups.items():
        result[name] = {"bodies":{key:{"nodes":term.size(),"tree":term.display()}
                                  for key,term in bodies.items()},
                        "total":sum(term.size() for term in bodies.values())}
    for name,count in (("main",10),("secondary",14),("old_initialized_swap",13),
                       ("initialized_biinterpretation",28),("pointed_constancy",19),
                       ("probe_constancy",18),("stationary_agreement",17),
                       ("stationary_comparison_1_fixed_predecessor",13)):
        assert result[name]["total"] == count, (name,result[name])
    return result


def measure():
    sep = Neq(Z,ONE)
    assert sep.size() == 6
    bodies = selected_bodies()
    rows = []
    for m in range(1,9):
        main_d = sum(t.size() for t in computation(m,"swap"))
        secondary_d = sum(t.size() for t in computation(m,"counterfree"))
        pc,ss = pointed(m).size(),stationary_separation(m).size()
        assert main_d == 6*m+13
        assert secondary_d == 6*m+12
        assert pc == 5*m+20
        assert ss == 5*m+17
        assert pointed(m,relative=False,uniform=True).size() == pc
        assert pointed(m,relative=False,reverse=True).size() == pc
        rows.append({"displayed_parameters_including_probe":m,
            "main_computation":main_d,"secondary_computation":secondary_d,
            "pointed_schema":pc,"ground_separation":sep.size(),
            "main_total":main_d+pc+sep.size(),
            "secondary_total":secondary_d+pc+sep.size(),
            "old_swap_total":main_d+ss+off_diagonal(True).size(),
            "matched_main_saving":2})
    def record(filename,grammar,arithmetic,body_key,comment):
        d = sum(t.size() for t in computation(1,grammar))
        return {"filename":filename,"grammar":grammar,"computation":d,
                "arithmetic":arithmetic,"display_total":d+arithmetic,
                "selected_body_nodes":bodies[body_key]["total"],
                "two_ledger_sum":d+arithmetic+bodies[body_key]["total"],
                "qualification":comment}
    table = [
        record("pra_initialized_biinterpretation_2026-11-01.zip","initialized_substitution",33,
               "initialized_biinterpretation","Initialized base; arbitrary unary parameter transformer."),
        record("pra_initialized_swap_2026-10-31.zip","swap",33,
               "old_initialized_swap","Closest matched predecessor; same update grammar."),
        record("pra_pointed_constancy_2026-10-31.zip","substitution",31,
               "pointed_constancy","Pointed equality-bit schema; indirect selector."),
        record("pra_probe_constancy_2026-10-31.zip","substitution",31,
               "probe_constancy","Same positive schema with a direct selector."),
        record("pra_stationary_agreement_2026-10-31.zip","ordinary",34,
               "stationary_agreement","Ordinary PR grammar; same-language equivalence."),
        record("pra_stationary_comparison_2026-10-31.zip","substitution",31,
               "stationary_comparison","Uniform equality disjunct outside the index quantifier."),
        record("pra_stationary_comparison_2026-10-31 (1).zip","fixed_predecessor",31,
               "stationary_comparison_1_fixed_predecessor","Recommended fixed-predecessor version; arbitrary-transformer variant has19 body nodes."),
    ]
    provenance = json.loads(Path(__file__).with_name("source_snapshot.json").read_text())
    by_name = {item["filename"]:item for item in provenance["archives"]}
    assert set(by_name) == {row["filename"] for row in table}
    for row in table:
        row["source"] = by_name[row["filename"]]
    assert [row["display_total"] for row in table] == [53,52,52,52,54,52,52]
    ordinary_d = sum(t.size() for t in computation(1,"ordinary"))
    primitive_iff_total = ordinary_d+classical_iff(1,False).size()
    expanded_iff_total = ordinary_d+classical_iff(1,True).size()
    assert (primitive_iff_total,expanded_iff_total)==(47,63)
    return {
        "status":"passed",
        "metric":"One node per leaf, application, equality, connective, bottom, and individual quantifier; negation expands to implication to bottom; 1=S0.",
        "scope":"Displayed formula templates and selected stored bodies are separate ledgers. Their sum is not a complete encoded theory length. All finite parameter arities remain admitted.",
        "source_commit":provenance["commit"],
        "main_one_parameter_trees":{
            "base":{"nodes":computation(1,"swap")[0].size(),"tree":computation(1,"swap")[0].display()},
            "step":{"nodes":computation(1,"swap")[1].size(),"tree":computation(1,"swap")[1].display()},
            "separation":{"nodes":sep.size(),"tree":sep.display()},
            "pointed_schema":{"nodes":pointed(1).size(),"tree":pointed(1).display()}},
        "main":{"display_total":50,"selected_body_nodes":10,"two_ledger_sum":60},
        "secondary":{"display_total":49,"selected_body_nodes":14,"two_ledger_sum":63},
        "uniform_formulas":{"main_computation":"6m+13","secondary_computation":"6m+12",
            "pointed_schema":"5m+20","separation":6,"main_total":"11m+39",
            "secondary_total":"11m+38","old_swap_total":"11m+41"},
        "parameter_rows":rows,
        "current_seven_drafts":table,
        "selected_program_bodies":bodies,
        "classical_single_schema_caution":{"source":"pra_stationary_agreement_2026-10-31.zip",
            "primitive_biconditional_total":primitive_iff_total,
            "expanded_biconditional_total":expanded_iff_total,
            "qualification":"47 uses a different primitive connective alphabet. Under the disclosed arrow/conjunction/disjunction measure its total is63."},
    }


if __name__ == "__main__":
    result = measure()
    output = Path(__file__).with_name("schema_metrics.json")
    output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":result["status"],"output":str(output),
                      "main":result["main"],"secondary":result["secondary"]},indent=2))
