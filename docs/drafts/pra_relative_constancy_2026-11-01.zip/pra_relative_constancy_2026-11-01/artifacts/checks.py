#!/usr/bin/env python3
"""Finite diagnostics for the accompanying PRA manuscript.

These checks exercise concrete natural-number programs.  They do not prove
the axiom schemas, the intuitionistic derivations, interpretation correctness,
or uniqueness on nonstandard models.  Those arguments are in the paper.
The deliberately broken compiler checks ensure that this suite can detect
argument-order and initialization errors rather than merely echoing formulas.

Run: python3 artifacts/checks.py
Only the Python standard library is required.  Results go beside this file.
"""

from __future__ import annotations

from itertools import product
import json
from pathlib import Path


def swap(update):
    """R(0,a,b)=a; R(n+1,a,b)=h(n,a,b,R(a,n,b))."""
    cache = {}
    def run(x, a, frozen=()):
        # Evaluate the defining recursion itself, storing its pending calls.
        # The explicit stack avoids dependence on Python's recursion limit.
        key = (x, a, tuple(frozen))
        requested = key
        pending = []
        while key not in cache and key[0] != 0:
            pending.append(key)
            old_x, old_a, parameters = key
            key = (old_a, old_x - 1, parameters)
        if key not in cache:
            cache[key] = key[1]
        value = cache[key]
        for old_x, old_a, parameters in reversed(pending):
            value = update(old_x - 1, old_a, parameters, value)
            cache[(old_x, old_a, parameters)] = value
        return cache[requested]
    return run


def counterfree(update):
    """R(0,a,b)=a; R(n+1,a,b)=h(a,b,R(a,n,b))."""
    return swap(lambda n, a, frozen, v: update(a, frozen, v))


def fold(update, x, y, frozen=(), broken_inner_order=False):
    """The paper's ordinary-PR diagonal-fold compiler, on natural inputs."""
    d, e, m = max(x - y, 0), max(y - x, 0), min(x, y)
    value = e if d == 0 else update(d - 1, 0, frozen, d - 1)
    for j in range(m):
        if broken_inner_order:
            inner = update(d + j, e + j, frozen, value)
        else:
            inner = update(e + j, d + j, frozen, value)
        value = update(d + j, e + j + 1, frozen, inner)
    return value


C_program = swap(lambda n, a, b, v: b[0])
D_program = swap(lambda n, a, b, v: v)


def C(z, u, w):
    return C_program(z, u, (w,))


def D(x, a):
    return D_program(x, a)


def T_update(n, a, frozen, v):
    return C(D(a, n), D(v, n), a)


T_program = swap(T_update)


def T(x, a):
    return T_program(x, a)


def q(z):
    return T(z + 1, 1)


def J(z, u, w):
    return C(q(z), u, w)


def error(x, y):
    return T(x + 1, y + 1)


def predecessor(x):
    return D(x, 0)


def ordinary_simulation(base, update):
    """Translate F0=G, F(n+1)=H(n,F(n)) into initialized swap syntax."""
    def h(n, a, frozen, v):
        return J(error(a, n), v,
                 J(n, base(frozen), update(predecessor(n), frozen, v)))
    machine = swap(h)
    return lambda n, frozen=(): machine(n + 1, n + 1, frozen)


def ordinary_reference(base, update, n, frozen):
    value = base(frozen)
    for k in range(n):
        value = update(k, frozen, value)
    return value


def B_update(a, frozen, v):
    return C(D(a, v), C(D(v, a), a, a + 1), a)


B_program = counterfree(B_update)


def B(x, a):
    return B_program(x, a)


def cf_agreement(x, y):
    """The manuscript's positive agreement bit: 1 exactly for equality."""
    return D(y + 1, B(x + 1, y + 1))


def cf_J(z, u, w):
    return C(cf_agreement(z, 0), w, u)


def cf_Q(s, t, u, w):
    return C(cf_agreement(s, t), w, u)


def cf_error(x, y):
    """The paper's derived error bit J(e(x,y),1,0)."""
    return cf_J(cf_agreement(x, y), 1, 0)


def cf_q(z):
    return cf_error(z, 0)


double_machine = counterfree(lambda a, frozen, v: v + 1)


def double(n):
    return double_machine(n, n)


half_machine = counterfree(
    lambda a, frozen, v: cf_Q(a, double(v + 1), v + 1, v))


def half(n):
    return half_machine(n, n)


def counterfree_simulation(base, update, broken_phase=False):
    def K(a, z, frozen):
        return cf_J(predecessor(a), base(frozen),
                    update(predecessor(predecessor(a)), frozen, z))
    def h(a, frozen, v):
        odd_value = v if broken_phase else v + 1
        return cf_Q(v, double(half(v)), odd_value,
                    double(K(a, half(v), frozen)))
    machine = counterfree(h)
    return lambda n, frozen=(): half(machine(n + 1, n + 1, frozen))


def bounded_update_search():
    """A small, explicitly limited lower bound on the eight-node T update.

    Leaves: 0,n,a,v.  Constructors: unary S, binary D, ternary C.
    v is fixed to U(a,n), for the exact intended eraser U.  Equal finite
    evaluation vectors can be merged because all constructors are pointwise.
    A smaller expression with the same vector is always an admissible
    replacement, so discarding larger duplicate vectors preserves completeness
    for the question whether a term of at most seven nodes matches the grid.
    This is not a lower bound on axiomatizations or on other helper languages.
    """
    inputs = [(n, a, 0 if a == n and n > 0 else n)
              for n in range(6) for a in range(6)]
    target = tuple(0 if a == n + 1 else a for n, a, v in inputs)
    terms = {1: {
        tuple(row[0] for row in inputs): "n",
        tuple(row[1] for row in inputs): "a",
        tuple(row[2] for row in inputs): "v",
        (0,) * len(inputs): "0",
    }}
    seen = set(terms[1])
    assert target not in seen
    counts = {1: len(terms[1])}
    for size in range(2, 8):
        out = {}
        def add(values, description):
            assert values != target, (size, description)
            if values not in seen:
                out.setdefault(values, description)
        for x, s in terms[size - 1].items():
            add(tuple(z + 1 for z in x), f"S({s})")
        for i in range(1, size - 1):
            j = size - 1 - i
            for x, s in terms[i].items():
                for y, t in terms[j].items():
                    add(tuple(b - a if a <= b else a - b - 1
                              for a, b in zip(x, y)), f"D({s},{t})")
        for i in range(1, size - 2):
            for j in range(1, size - i - 1):
                k = size - 1 - i - j
                if k < 1:
                    continue
                for x, s in terms[i].items():
                    for y, t in terms[j].items():
                        for z, u in terms[k].items():
                            add(tuple(b if a == 0 else c
                                      for a, b, c in zip(x, y, z)),
                                f"C({s},{t},{u})")
        terms[size] = out
        seen.update(out)
        counts[size] = len(out)
    witness = tuple(
        (D(v, n) if D(a, n) == 0 else a) for n, a, v in inputs)
    assert witness == target
    return {
        "status": "passed",
        "input_grid": "n,a in 0..5; v=U(a,n)",
        "constructors": {"leaves": ["0", "n", "a", "v"],
                         "unary": ["S"], "binary": ["D"],
                         "ternary": ["C"]},
        "new_evaluation_vectors_by_minimum_size": counts,
        "no_matching_term_of_at_most": 7,
        "matching_eight_node_term": "C(D(a,n),D(v,n),a)",
        "scope": "Fixed helper language and exact intended eraser only; no minimum theory claim.",
    }


def run_checks():
    result = {
        "status": "passed",
        "scope": "Finite natural-number diagnostics only. No formal proof or nonstandard-model validation is claimed.",
    }
    count = 0
    for x, a in product(range(81), repeat=2):
        assert D(x, a) == max(a - x, 0) + max(x - a - 1, 0)
        assert T(x, a) == (0 if x == a and a > 0 else a)
        assert B(x, a) == (a + 1 if x == a and a > 0 else a)
        assert T(x, a) == fold(T_update, x, a)
        assert B(x, a) == fold(lambda n, a, b, v: B_update(a, b, v), x, a)
        count += 1
    result["designated_programs"] = {"pairs": count, "bound_inclusive": 80,
        "checks": ["D closed form", "eight-node T eraser", "counterfree B bump",
                   "T against diagonal fold", "B against diagonal fold"]}

    count = 0
    for z, u, w in product(range(9), repeat=3):
        expected = u if z == 0 else w
        assert C(z, u, w) == expected
        assert J(z, u, w) == expected
        assert cf_J(z, u, w) == expected
        count += 1
    for x, y in product(range(25), repeat=2):
        assert (error(x, y) == 0) == (x == y)
        assert cf_agreement(x, y) == (1 if x == y else 0)
        assert cf_error(x, y) == (0 if x == y else 1)
        assert cf_Q(x, y, 17, 29) == (17 if x == y else 29)
    result["selectors_and_equality"] = {"selector_triples": count,
        "equality_pairs": 625, "both_languages": True,
        "secondary_helpers": "e(x,y)=D(Sy,B(Sx,Sy)); J(z,u,v)=C(e(z,0),v,u); Q(s,t,u,v)=C(e(s,t),v,u)"}

    families = {
        "return_recursive_value": lambda n, a, b, v: v,
        "return_counter": lambda n, a, b, v: n,
        "return_current_seed": lambda n, a, b, v: a,
        "asymmetric_affine": lambda n, a, b, v: 2*n + 3*a + v + 1,
        "selector": lambda n, a, b, v: a if v == 0 else n,
        "frozen_affine": lambda n, a, b, v: n + 2*a + v + sum(b),
        "weighted_frozen": lambda n, a, b, v: n*a + v + sum((i+1)*t for i,t in enumerate(b)),
        "modular_update": lambda n, a, b, v: (n + 3*a + 5*v + sum(b)) % 97,
    }
    tuples = [(), (0,), (3,), (2, 5), (1, 4, 2)]
    count = 0
    for name, h in families.items():
        machine = swap(h)
        for frozen in tuples:
            for x, a in product(range(18), repeat=2):
                assert machine(x, a, frozen) == fold(h, x, a, frozen), (name, x, a, frozen)
                count += 1
    result["general_swap_compiler"] = {"cases": count,
        "update_families": list(families), "frozen_tuples": tuples,
        "active_argument_bound_inclusive": 17}
    h = families["asymmetric_affine"]
    machine = swap(h)
    bad = next(({"x": x, "a": a, "correct": machine(x,a),
                 "broken": fold(h,x,a,broken_inner_order=True)}
                for x,a in product(range(8), repeat=2)
                if machine(x,a) != fold(h,x,a,broken_inner_order=True)), None)
    assert bad is not None
    result["negative_control_swapped_inner_arguments"] = bad

    recursion_cases = {
        "successive_sum": (lambda b: 0, lambda n,b,v: v+n+1),
        "factorial": (lambda b: 1, lambda n,b,v: (n+1)*v),
        "nonzero_initial_state": (lambda b: 7, lambda n,b,v: v+3),
        "frozen_affine": (lambda b: sum(b)+2, lambda n,b,v: v+n+sum(b)),
        "frozen_multiplier": (lambda b: sum(b)+1, lambda n,b,v: v*(1+(b[0] if b else 1))),
    }
    count = 0
    for name, (base, update) in recursion_cases.items():
        simulation = ordinary_simulation(base, update)
        for frozen in tuples:
            for n in range(8):
                expected = ordinary_reference(base, update, n, frozen)
                assert simulation(n, frozen) == expected, (name,n,frozen)
                count += 1
    result["ordinary_recursion_in_main_language"] = {
        "cases": count, "families": list(recursion_cases), "n_bound_inclusive": 7}

    # Characteristic bits: 0=true, 1=false.  These checks test the Boolean
    # implementation, including implication's truth table.  They cannot
    # validate intuitionistic implication; its constructive justification
    # is the derivation in the accompanying paper.
    atoms = ["eq_xy", "eq_x0", "eq_sum3", "bottom", "top"]
    formulas = [(a,) for a in atoms]
    formulas += [(op,(a,),(b,)) for op in ("and","or","imp") for a,b in product(atoms,repeat=2)]
    formulas += [("imp", ("and",("eq_xy",),("eq_x0",)),
                  ("or",("eq_sum3",),("bottom",)))]
    def truth(formula, x, y):
        op = formula[0]
        if op == "eq_xy": return x == y
        if op == "eq_x0": return x == 0
        if op == "eq_sum3": return x+y == 3
        if op == "bottom": return False
        if op == "top": return True
        left, right = truth(formula[1],x,y), truth(formula[2],x,y)
        return {"and": left and right, "or": left or right,
                "imp": (not left) or right}[op]
    def bit(formula, x, y):
        op = formula[0]
        if op == "eq_xy": return q(error(x,y))
        if op == "eq_x0": return q(error(x,0))
        if op == "eq_sum3": return q(error(x+y,3))
        if op == "bottom": return 1
        if op == "top": return 0
        left, right = bit(formula[1],x,y), bit(formula[2],x,y)
        if op == "and": return J(left,right,1)
        if op == "or": return J(left,0,right)
        return J(left,right,0)
    count = 0
    for formula in formulas:
        for x,y in product(range(9), repeat=2):
            answer = bit(formula,x,y)
            assert answer in (0,1)
            assert (answer == 0) == truth(formula,x,y)
            count += 1
    result["formula_to_bit_translation"] = {"cases": count,
        "formulas": len(formulas), "variable_grid": "x,y in 0..8"}

    count = 0
    for before, after in ((0,0),(1,0),(1,1)):
        for state in range(17):
            first = J(before,state,0)
            second = J(after,first,0)
            assert first == second
            # The direct diagonal latch in the secondary proof performs
            # exactly these two updates at consecutive positive seeds.
            for n in range(7):
                def b(k):
                    return before if k == n else after
                def update(a,v):
                    return cf_J(a,1,cf_J(b(predecessor(a)),v,0))
                assert update(n+2, update(n+1,state)) == first
            count += 1
    assert J(0,1,0) != J(1,J(0,1,0),0)
    result["latch_local_stationarity"] = {"bit_state_cases": count,
        "allowed_adjacent_bits": [[0,0],[1,0],[1,1]],
        "negative_control_without_step": {"bits": [0,1], "state": 1,
                                           "first": 1, "second": 0}}

    for n in range(81):
        assert double(n) == 2*n
        assert half(n) == n//2
        assert half(double(n)) == n
        assert half(double(n)+1) == n
    cf_cases = {
        "successive_sum": recursion_cases["successive_sum"],
        "nonzero_initial_state": recursion_cases["nonzero_initial_state"],
        "frozen_affine": recursion_cases["frozen_affine"],
    }
    count = 0
    for name, (base, update) in cf_cases.items():
        simulation = counterfree_simulation(base,update)
        for frozen in [(), (0,), (2,3)]:
            for n in range(6):
                expected = ordinary_reference(base,update,n,frozen)
                assert simulation(n,frozen) == expected, (name,n,frozen)
                count += 1
    base, update = recursion_cases["nonzero_initial_state"]
    broken = counterfree_simulation(base, update, broken_phase=True)
    assert broken(0) != base(())
    result["secondary_counterfree_programs"] = {
        "doubling_and_halving_inputs": 81,
        "ordinary_recursion_cases": count,
        "families": list(cf_cases),
        "negative_control_missing_phase_tag": {"n": 0,
             "correct": base(()), "broken": broken(0)}}

    result["limited_update_minimality_search"] = bounded_update_search()
    return result


if __name__ == "__main__":
    output = run_checks()
    target = Path(__file__).with_name("check_results.json")
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"status": output["status"], "output": str(target),
                      "checks": list(output)[2:]}, indent=2))
