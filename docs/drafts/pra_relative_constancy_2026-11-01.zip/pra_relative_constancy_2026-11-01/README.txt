PRA FROM RELATIVE CONSTANCY
Research package prepared for Vladimir Reshetnikov, 1 November 2026

MAIN RESULT

Two effective first-order presentations are proved bi-interpretable and
equiconsistent with PRA, separately in classical and intuitionistic logic.
The interpretations retain the whole domain and native equality. Both
composites are provably the identity on all finite function descriptions.

Recommended presentation:
  R_h(0,a,b) = a
  R_h(Sn,a,b) = h(n,a,b,R_h(a,n,b))
  0 != S0
  stationary f implies T(f(0,a,b),a)=a or f(n,a,b)=a, for every n.
All finite parameter tuples are admitted; h and f range syntactically
over finite terms, not over an object-language function sort.

The three designated updates are b, v, and C(D(a,n),D(v,n),a).
The last is the new eight-node eraser update. Under the disclosed metric,
the representative display costs 50 nodes and its designated bodies cost
10, compared with 52 and 13 in the closest existing draft. A secondary
presentation omits n from the update language; it costs 49 and 14.
The partial sums 60 and 63 are not complete encoded description lengths.

CONTENTS

report.tex                    Main LaTeX source and comparison
report.pdf                    Complete compiled research report
sections/base.tex             Specification and constructive forward proof
sections/reverse.tex          Explicit reverse compiler and both round trips
sections/counterfree.tex       Complete proof of the 49-node alternative
artifacts/checks.py            Finite computational diagnostics
artifacts/check_results.json   Recorded diagnostic results
artifacts/schema_metrics.py    Explicit formula-tree size calculations
artifacts/schema_metrics.json  Recorded comparisons and size trees
artifacts/source_snapshot.json Seven pinned archive identities and hashes
audit/source_manifest.json    Complete retrieval and comparison provenance
audit/independent_review.txt   Scope and conclusions of the proof review
audit/validation.json         Build, layout, and artifact validation record
build.py                      Rebuild PDF and rerun the diagnostics
SHA256SUMS.txt                SHA-256 hashes of the package contents

REPRODUCE

Python 3 and a LaTeX installation with the packages listed in report.tex
are required. No third-party Python packages are required for the
mathematical diagnostics.

From this directory run:
  python3 build.py

To run only the diagnostics:
  python3 artifacts/checks.py
  python3 artifacts/schema_metrics.py

To rebuild only the PDF, leaving the recorded checks alone:
  python3 build.py --skip-checks

VERIFICATION BOUNDARY

Complete mathematical proofs are supplied in the manuscript, including
nonstandard-domain uniqueness and both identity round trips. The Python
checks test finite natural-number computations, Boolean implementations,
compiler examples, and exact syntax counts. They do not constitute a
formal verification of the first-order schema or intuitionistic proofs.
No new Lean or Rocq certificate is claimed.

An exhaustive finite evaluation search also proves a narrow minimum:
the new eraser update cannot use seven or fewer nodes in the explicitly
fixed helper grammar with leaves 0,n,a,v and constructors S,D,C. This is
not a minimum over theories or alternative helper languages.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: c5a6a6a4087c9a3a2e9ce4f4ad8ad6a79e466ef7
All seven current docs/drafts archives were read and their Git blob
hashes verified. The docs/incoming inventory and full index were also
examined. The archive does not repackage the earlier manuscripts.

The report includes a Further research questions section and distinguishes
the native free-variable calculus from the first-order theories used for
the bi-interpretability theorem.
