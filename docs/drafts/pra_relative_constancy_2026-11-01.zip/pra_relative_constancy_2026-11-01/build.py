#!/usr/bin/env python3
"""Rebuild the report and rerun its standard-library finite diagnostics."""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skip-checks', action='store_true')
    args = parser.parse_args()
    if not args.skip_checks:
        for filename in ('checks.py', 'schema_metrics.py'):
            subprocess.run([sys.executable, str(ROOT / 'artifacts' / filename)],
                           cwd=ROOT, check=True)
    if shutil.which('latexmk'):
        subprocess.run(['latexmk', '-pdf', '-interaction=nonstopmode',
                        '-halt-on-error', '-file-line-error', 'report.tex'],
                       cwd=ROOT, check=True)
    elif shutil.which('pdflatex'):
        for _ in range(3):
            subprocess.run(['pdflatex', '-interaction=nonstopmode',
                            '-halt-on-error', '-file-line-error', 'report.tex'],
                           cwd=ROOT, check=True)
    else:
        raise SystemExit('Install latexmk or pdflatex to compile the supplied TeX.')
    log = (ROOT / 'report.log').read_text(errors='replace')
    problems = [needle for needle in (
        'Overfull \\hbox', 'Overfull \\vbox',
        'There were undefined references', 'multiply defined') if needle in log]
    if problems:
        raise SystemExit('Build completed with layout/reference issues: ' + ', '.join(problems))
    print('Built report.pdf; mathematical diagnostics are finite checks, not formal proofs.')


if __name__ == '__main__':
    main()
