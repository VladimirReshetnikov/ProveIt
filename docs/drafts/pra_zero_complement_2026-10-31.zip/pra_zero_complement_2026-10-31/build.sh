#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_zero_complement.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_zero_complement.tex
cp build/pra_zero_complement.pdf pra_zero_complement.pdf
