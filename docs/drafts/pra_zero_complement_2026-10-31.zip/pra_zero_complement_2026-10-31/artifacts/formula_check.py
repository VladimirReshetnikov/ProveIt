#!/usr/bin/env python3
"""Finite standard-model checks for the PRA zero-complement report.

Uses only the Python standard library. It checks the arithmetic helper
recursions, six stated induction matrices on bounded inputs, and the
quantifier-free formula compiler on a deterministic corpus.

These are sanity checks of numerical definitions. They do not check a
formal proof, justify induction from finite cases, or establish validity
in arbitrary intuitionistic/Kripke models. The mathematical derivations
are in sections/constructive.tex.
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Mapping


def pred(n: int) -> int:
    return max(n - 1, 0)


def zero(n: int) -> int:
    return 1 if n == 0 else 0


def select(n: int, u: int, v: int) -> int:
    return u if n == 0 else v


def alpha(n: int, y: int) -> int:
    value = y
    for _ in range(n):
        value = pred(value)
    return value


def beta(n: int, y: int) -> int:
    # The selector in the defining successor equation sees the OLD
    # countdown value, before that value is decremented.
    remaining, overflow = y, 0
    for _ in range(n):
        overflow = select(remaining, overflow + 1, overflow)
        remaining = pred(remaining)
    return overflow


def distance(x: int, y: int) -> int:
    return alpha(x, y) + beta(x, y)


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple = ()

    def evaluate(self, env: Mapping[str, int]) -> int:
        if self.op == "var":
            return env[self.args[0]]
        if self.op == "num":
            return self.args[0]
        values = tuple(arg.evaluate(env) for arg in self.args)
        if self.op == "succ":
            return values[0] + 1
        if self.op == "pred":
            return pred(values[0])
        if self.op == "add":
            return values[0] + values[1]
        if self.op == "alpha":
            return alpha(*values)
        if self.op == "beta":
            return beta(*values)
        if self.op == "distance":
            return distance(*values)
        if self.op == "zero":
            return zero(values[0])
        if self.op == "select":
            return select(*values)
        raise ValueError(f"Unknown term operation: {self.op}")

    def display(self) -> str:
        if self.op in {"var", "num"}:
            return str(self.args[0])
        return f"{self.op}({', '.join(arg.display() for arg in self.args)})"


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple = ()

    def evaluate(self, env: Mapping[str, int]) -> bool:
        if self.op == "top":
            return True
        if self.op == "bottom":
            return False
        if self.op == "eq":
            return self.args[0].evaluate(env) == self.args[1].evaluate(env)
        if self.op == "not":
            return not self.args[0].evaluate(env)
        a, b = (arg.evaluate(env) for arg in self.args)
        if self.op == "and":
            return a and b
        if self.op == "or":
            return a or b
        if self.op == "implies":
            return (not a) or b
        raise ValueError(f"Unknown formula operation: {self.op}")

    def display(self) -> str:
        if not self.args:
            return self.op
        return f"{self.op}({', '.join(arg.display() for arg in self.args)})"


ZERO = Term("num", (0,))
ONE = Term("num", (1,))


def compile_error(formula: Formula) -> Term:
    """Construct the exact error-term syntax used in the paper."""
    if formula.op == "eq":
        return Term("distance", formula.args)
    if formula.op == "top":
        return ZERO
    if formula.op == "bottom":
        return ONE
    if formula.op == "not":
        return Term("zero", (compile_error(formula.args[0]),))
    a, b = (compile_error(arg) for arg in formula.args)
    if formula.op == "and":
        return Term("add", (a, b))
    if formula.op == "or":
        return Term("select", (a, ZERO, b))
    if formula.op == "implies":
        return Term("select", (a, b, ZERO))
    raise ValueError(f"Unknown formula operation: {formula.op}")


INDUCTION_MATRICES = [
    {
        "number": 1,
        "matrix": "n + 0 = n",
        "variable": "n",
        "fixed_parameters": [],
        "base": "0 + 0 = 0 by definition",
        "step": "Apply successor to the induction hypothesis",
    },
    {
        "number": 2,
        "matrix": "n + S(y) = S(n + y)",
        "variable": "n",
        "fixed_parameters": ["y"],
        "base": "0 + S(y) = S(y) = S(0 + y)",
        "step": "S(n) + S(y) = S(n + S(y)) = S(S(n + y))",
    },
    {
        "number": 3,
        "matrix": "alpha(S(n), S(y)) = alpha(n, y)",
        "variable": "n",
        "fixed_parameters": ["y"],
        "base": "alpha(1, S(y)) = pred(S(y)) = y",
        "step": "Apply predecessor to the induction hypothesis",
    },
    {
        "number": 4,
        "matrix": "beta(S(n), S(y)) = beta(n, y)",
        "variable": "n",
        "fixed_parameters": ["y"],
        "base": "beta(1, S(y)) = select(S(y), 1, 0) = 0",
        "step": "Use the completed alpha shift and the beta induction hypothesis",
    },
    {
        "number": 5,
        "matrix": "n + alpha(n, y) = y + beta(n, y)",
        "variable": "n",
        "fixed_parameters": ["y"],
        "base": "0 + y = y + 0 using matrix 1",
        "step": "Split alpha(n,y) into zero or successor; use the two defining counter steps",
    },
    {
        "number": 6,
        "matrix": "distance(n, n) = 0",
        "variable": "n",
        "fixed_parameters": [],
        "base": "Both counters equal zero at (0,0)",
        "step": "Use both completed universally quantified shift identities",
    },
]


def build_corpus() -> list[Formula]:
    x, y = Term("var", ("x",)), Term("var", ("y",))
    atoms = [
        Formula("eq", (x, y)),
        Formula("eq", (Term("add", (x, y)), Term("succ", (x,)))),
        Formula("eq", (Term("pred", (x,)), y)),
        Formula("eq", (Term("alpha", (x, y)), ZERO)),
        Formula("eq", (Term("beta", (x, y)), y)),
        Formula("eq", (ZERO, ONE)),
        Formula("eq", (x, x)),
        Formula("top"),
        Formula("bottom"),
    ]
    corpus = list(atoms)
    corpus.extend(Formula("not", (a,)) for a in atoms)
    corpus.extend(
        Formula(op, (a, b))
        for op, a, b in product(("and", "or", "implies"), atoms, atoms)
    )
    rng = random.Random(20261031)

    def random_formula(depth: int) -> Formula:
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice(atoms)
        op = rng.choice(("not", "and", "or", "implies"))
        a = random_formula(depth - 1)
        return Formula(op, (a,)) if op == "not" else Formula(
            op, (a, random_formula(depth - 1))
        )

    corpus.extend(random_formula(4) for _ in range(256))
    # Keep the corpus order stable and report only distinct formula syntax.
    return list(dict.fromkeys(corpus))


def check_arithmetic(bound: int) -> dict:
    counts = {"counter_definitions": 0, "counter_semantics": 0,
              "matrix_values": 0, "comparator_equivalence": 0}
    for n, y in product(range(bound + 1), repeat=2):
        a, b = alpha(n, y), beta(n, y)
        assert alpha(n + 1, y) == pred(a)
        assert beta(n + 1, y) == select(a, b + 1, b)
        counts["counter_definitions"] += 2
        assert a == max(y - n, 0)
        assert b == max(n - y, 0)
        counts["counter_semantics"] += 2
        assert n + (y + 1) == (n + y) + 1
        assert alpha(n + 1, y + 1) == a
        assert beta(n + 1, y + 1) == b
        assert n + a == y + b
        counts["matrix_values"] += 4
        assert (distance(n, y) == 0) == (n == y)
        counts["comparator_equivalence"] += 1
    for n in range(bound + 1):
        assert alpha(0, n) == n
        assert beta(0, n) == 0
        counts["counter_definitions"] += 2
        assert n + 0 == n
        assert distance(n, n) == 0
        counts["matrix_values"] += 2
    return {"bound_inclusive": bound, "checks": counts}


def check_compiler(bound: int) -> dict:
    corpus = build_corpus()
    compiled = [compile_error(f) for f in corpus]
    evaluations = 0
    for x, y in product(range(bound + 1), repeat=2):
        env = {"x": x, "y": y}
        for formula, error in zip(corpus, compiled):
            expected = formula.evaluate(env)
            value = error.evaluate(env)
            assert value >= 0
            assert (value == 0) == expected, (
                formula.display(), error.display(), env, value
            )
            evaluations += 1
    sample_indices = [len(corpus) - 1, len(corpus) - 2, len(corpus) - 3]
    return {
        "bound_inclusive": bound,
        "variables": ["x", "y"],
        "distinct_formulas": len(corpus),
        "assignments": (bound + 1) ** 2,
        "formula_assignment_checks": evaluations,
        "corpus": "All binary connective combinations of nine base formulas, their negations, and seeded depth-four syntax",
        "random_seed": 20261031,
        "examples": [
            {"formula": corpus[i].display(), "error_term": compiled[i].display()}
            for i in sample_indices
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arithmetic-bound", type=int, default=64)
    parser.add_argument("--formula-bound", type=int, default=7)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("formula_check_report.json"))
    parser.add_argument("--matrix-log", type=Path,
                        default=Path(__file__).with_name("induction_matrices.json"))
    args = parser.parse_args()
    if min(args.arithmetic_bound, args.formula_bound) < 0:
        parser.error("Bounds must be nonnegative")
    report = {
        "status": "passed",
        "scope": "Finite standard-natural-number sanity checks; not formal proof verification",
        "arithmetic": check_arithmetic(args.arithmetic_bound),
        "formula_compiler": check_compiler(args.formula_bound),
        "induction_matrices_recorded": len(INDUCTION_MATRICES),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.matrix_log.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    args.matrix_log.write_text(json.dumps({
        "scope": "Human-readable proof accounting, not machine-checked certificates",
        "source": "sections/constructive.tex",
        "matrices": INDUCTION_MATRICES,
    }, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": report["status"],
        "arithmetic_checks": sum(report["arithmetic"]["checks"].values()),
        "formula_assignment_checks": report["formula_compiler"]["formula_assignment_checks"],
        "distinct_formulas": report["formula_compiler"]["distinct_formulas"],
        "induction_matrices_recorded": len(INDUCTION_MATRICES),
        "scope": report["scope"],
    }, indent=2))


if __name__ == "__main__":
    main()
