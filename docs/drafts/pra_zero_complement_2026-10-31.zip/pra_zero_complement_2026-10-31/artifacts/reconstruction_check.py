#!/usr/bin/env python3
"""Check the symbolic D-reductions for the reconstruction induction.

This small equational normalizer leaves numerical variables symbolic.
It checks the exact base and unconditional successor calculation; it is
not a formalization of first-order logic or of the entire equivalence proof.
Only the six explicitly declared predecessor/zero-test/selector equations
are used. Python 3.10+, standard library only.
"""
import json


def V(name):
    return ("var", name)


Z = ("0",)


def S(t):
    return ("S", t)


def P(t):
    return ("p", t)


def T(t):
    return ("z", t)


def C(t, u, v):
    return ("c", t, u, v)


def display(t):
    if t[0] == "var":
        return t[1]
    if t[0] == "0":
        return "0"
    return t[0] + "(" + ",".join(display(a) for a in t[1:]) + ")"


def normal(t):
    if t[0] in ("var", "0"):
        return t
    args = tuple(normal(a) for a in t[1:])
    op = t[0]
    if op == "p":
        if args[0] == Z:
            return Z
        if args[0][0] == "S":
            return args[0][1]
    if op == "z":
        if args[0] == Z:
            return S(Z)
        if args[0][0] == "S":
            return Z
    if op == "c":
        if args[0] == Z:
            return args[1]
        if args[0][0] == "S":
            return args[2]
    return (op,) + args


def reconstruction(x):
    return C(T(x), S(P(x)), Z)


def run():
    n = V("n")
    pairs = [(reconstruction(Z), Z), (reconstruction(S(n)), S(n))]
    checks = []
    for lhs, rhs in pairs:
        lhs_normal, rhs_normal = normal(lhs), normal(rhs)
        assert lhs_normal == rhs_normal
        checks.append({
            "equation": display(lhs) + " = " + display(rhs),
            "left_normal_form": display(lhs_normal),
            "right_normal_form": display(rhs_normal),
            "uses_induction_hypothesis": False,
        })
    return {
        "status": "passed",
        "scope": "Symbolic computation reductions only; not a full proof checker.",
        "induction_matrix": "c(z(n),S(p(n)),0)=n",
        "fixed_parameters": [],
        "declared_equations": [
            "p(0)=0", "p(S(n))=n", "z(0)=S(0)", "z(S(n))=0",
            "c(0,u,v)=u", "c(S(n),u,v)=v",
        ],
        "checks": checks,
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
