#!/usr/bin/env python3
"""Executable examples for the finite-numeral-test induction countermodel.

This is a smoke check of the displayed construction, not a finite-model search
and not a formal proof of the infinite schema.  The mathematical construction
extends to every finite primitive-recursion description.  In particular, this
program performs NO finite test of an induction schema or of the zero-guard
axiom: their validity is proved by truth pullback in the accompanying paper.
The Zi and Zc checks below evaluate the actual displayed fixed bridge formulas
on sample elements of the classical (equivalently, one-node Kripke) structures.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json
import random


@dataclass(frozen=True)
class Elt:
    rank: int
    extra: bool = False


# Terms are ("v", i), ("0",), ("S", term), or ("call", name, arguments).
def v(i): return ("v", i)
Z = ("0",)
def S(t): return ("S", t)
def call(name, *args): return ("call", name, tuple(args))


@dataclass(frozen=True)
class Rec:
    name: str
    parameter_count: int
    base: tuple
    step: tuple


DECLS: dict[str, Rec] = {}


def declare(name, k, base, step):
    # Base variables: parameters.  Step variables: index, old value, parameters.
    def validate(t, count):
        if t[0] == "v": assert 0 <= t[1] < count
        elif t[0] == "0": pass
        elif t[0] == "S": validate(t[1], count)
        else:
            assert t[0] == "call" and t[1] in DECLS
            assert len(t[2]) == DECLS[t[1]].parameter_count + 1
            for a in t[2]: validate(a, count)
    validate(base, k)
    validate(step, k + 2)
    assert name not in DECLS
    DECLS[name] = Rec(name, k, base, step)


declare("pred", 0, Z, v(0))
declare("zero_test", 0, S(Z), Z)
declare("case", 2, v(0), v(3))
declare("add", 1, v(0), S(v(1)))
declare("monus", 1, v(0), call("pred", v(1)))
declare("sample_identity", 0, Z, S(v(0)))
declare("iterate_identity", 0, Z, S(v(1)))
declare("parity", 0, Z, call("case", v(1), S(Z), Z))
declare("double", 0, Z, S(S(v(1))))


class Model:
    def __init__(self, root_rank=None):
        self.root_rank = root_rank

    def succ(self, x): return Elt(x.rank + 1, x.extra)

    @lru_cache(maxsize=None)
    def term(self, t, env):
        if t[0] == "v": return env[t[1]]
        if t[0] == "0": return Elt(0)
        if t[0] == "S": return self.succ(self.term(t[1], env))
        return self.rec(t[1], tuple(self.term(a, env) for a in t[2]))

    @lru_cache(maxsize=None)
    def rec(self, name, args):
        d = DECLS[name]
        assert len(args) == d.parameter_count + 1
        x, pars = args[0], args[1:]
        if x.extra:
            assert self.root_rank is not None and x.rank >= self.root_rank
            # At the extra-chain root, choose the canonical lift of the
            # ordinary numerical output, even when parameters are extra.
            std_args = (Elt(self.root_rank),) + tuple(Elt(a.rank) for a in pars)
            out = STD.rec(name, std_args)
            start = self.root_rank
        else:
            out = self.term(d.base, pars)
            start = 0
        for n in range(start, x.rank):
            out = self.term(d.step, (Elt(n, x.extra), out) + pars)
        return out


STD = Model()


def term_text(t):
    if t[0] == "v": return "x" + str(t[1])
    if t[0] == "0": return "0"
    if t[0] == "S": return "S(" + term_text(t[1]) + ")"
    return t[1] + "(" + ",".join(map(term_text, t[2])) + ")"


def generate_terms(count, rng):
    terms = [Z, S(Z), v(0), v(1)]
    shallow = list(terms)
    while len(terms) < count:
        name = rng.choice(tuple(DECLS))
        arity = DECLS[name].parameter_count + 1
        # Keep recursion bounds small.  Parameters may use constructed terms.
        args = [rng.choice(shallow)]
        args += [rng.choice(terms) for _ in range(arity - 1)]
        t = call(name, *args)
        if t not in terms: terms.append(t)
    return terms


def run():
    rng = random.Random(20261031)
    terms = generate_terms(70, rng)
    results = []
    for K in range(4):
        r = K + 1
        M = Model(r)
        values = tuple(Elt(n) for n in range(r + 4)) + tuple(Elt(n, True) for n in range(r, r + 4))
        small = (Elt(0), Elt(1), Elt(r), Elt(r, True))
        equation_count = 0
        for name, d in DECLS.items():
            for pars in product(small, repeat=d.parameter_count):
                assert M.rec(name, (Elt(0),) + pars) == M.term(d.base, pars)
                equation_count += 1
                for x in values:
                    lhs = M.rec(name, (M.succ(x),) + pars)
                    rhs = M.term(d.step, (x, M.rec(name, (x,) + pars)) + pars)
                    assert lhs == rhs
                    equation_count += 1
        rank_count = test_count = 0
        for t in terms:
            for env in product(values, repeat=2):
                out = M.term(t, env)
                standard = STD.term(t, tuple(Elt(x.rank) for x in env))
                assert out.rank == standard.rank
                rank_count += 1
                for j in range(K + 1):
                    assert (out == Elt(j)) == (standard == Elt(j))
                    test_count += 1

        bridge_count = 0
        for x in values:
            zx = M.rec("zero_test", (x,))
            # Zc: z(x)=0 iff x != 0.
            assert (zx == Elt(0)) == (x != Elt(0))
            # Zi: (x=0 or z(x)=0) and x != z(x).
            assert ((x == Elt(0)) or (zx == Elt(0))) and x != zx
            assert zx == Elt(0) or zx == Elt(1)
            bridge_count += 1

        root = Elt(r, True)
        predecessor = M.rec("pred", (root,))
        assert root != Elt(0)
        assert M.succ(predecessor) != root

        # The ordinary PR numerical equality tester tests rank, not identity.
        # monus(n,a) means a dotminus n.
        x, y = v(0), v(1)
        distance = call("add", call("monus", x, y), call("monus", y, x))
        tester = call("zero_test", distance)
        assert M.term(distance, (root, Elt(r))) == Elt(0)
        assert M.term(tester, (root, Elt(r))) == Elt(1)
        assert root != Elt(r)
        results.append({
            "K": K,
            "extra_root_rank": r,
            "defining_equation_instances_checked": equation_count,
            "term_rank_homomorphism_instances_checked": rank_count,
            "fixed_numeral_test_instances_checked": test_count,
            "Zc_instances_checked": bridge_count,
            "Zi_instances_checked": bridge_count,
            "zero_test_boolean_range_instances_checked": bridge_count,
            "constructor_coverage_counterexample": {
                "element": "b_" + str(r),
                "predecessor": "canonical_" + str(predecessor.rank),
                "successor_of_predecessor": "canonical_" + str(r),
            },
            "ordinary_numerical_equality_test_on_distinct_root_and_canonical_lift": 1,
        })
    return {
        "status": "all executable checks passed",
        "scope": "Finite examples of an infinite model construction; the mathematical proof, not this program, verifies the full schemas.",
        "induction_verification": {
            "finite_induction_tests_performed": 0,
            "finite_zero_guard_tests_performed": 0,
            "full_schema_status": "Established only by the accompanying mathematical truth-pullback argument; not machine-verified here.",
        },
        "seed": 20261031,
        "sample_term_count": len(terms),
        "models": results,
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
