PRA FROM A UNARY ZERO-COMPLEMENT LAW
==================================

Main result
-----------
Computation equations + induction for equations + one unary zero-complement
law exactly axiomatize classical or intuitionistic first-order PRA:

  Classical:      forall x (z(x)=0 iff x!=0).
  Intuitionistic: forall x ((x=0 or z(x)=0) and x!=z(x)).

Here z(0)=1 and z(Sx)=0 are ordinary computation equations. The intuitionistic
law can also be used classically. The paper proves exact same-language
equivalence, derives nontriviality and successor laws, and gives a complete
constructive equality-detector and formula-compiler proof.

This is a modest simplification of fixed bridges in the supplied drafts.
Their best guarded-equation basis remains an alternative; no absolute
shortest-axiomatization or historical-priority claim is made.

The countermodel theorem rules out induction based only on tests against any
fixed finite set of numerals, even with arbitrary formula quantifiers and the
correct zero-complement law. It is stronger than a finite test or example.

Contents
--------
pra_zero_complement.pdf              Complete paper and proofs.
pra_zero_complement.tex              Main LaTeX source.
sections/constructive.tex            Constructive equality test and compiler.
axioms.txt                          Exact standalone axiom specification.
source_audit.json                    Six pinned draft URLs and hashes.
draft_comparison.txt                Comparison of existing and proposed bases.
artifacts/formula_check.py           Finite numerical compiler checks.
artifacts/rank_model_check.py        Examples of the infinite countermodels.
artifacts/reconstruction_check.py    Symbolic base/step reduction checks.
artifacts/*report.json               Executed check outputs.
artifacts/induction_matrices.json    Six equality-detector induction matrices.
build.sh                            Rebuild the PDF with pdflatex.
verify.sh                           Rerun the Python checks.
VALIDATION.txt                      Verification scope and build status.
SHA256SUMS                          Checksums of deliverables.

Rebuild
-------
  sh build.sh

Requires a normal TeX Live installation with pdflatex and the packages listed
in the preamble (amsmath, amsthm, lmodern, microtype, geometry, tcolorbox, etc.).
No bibliography download or network access is required.

Checks
------
  sh verify.sh

Requires Python 3.10 or later; uses only its standard library.
The numerical checks are finite sanity checks. The symbolic checker checks
two equational reductions, not all first-order reasoning. The paper proves
the universal theorems; no full Lean/Rocq formalization is claimed.

Date and source snapshot
------------------------
31 October 2026 (America/Los_Angeles).
ProveIt commit a0dd253b72f0ebfd368f674fcf722e0671d4a6ef.
