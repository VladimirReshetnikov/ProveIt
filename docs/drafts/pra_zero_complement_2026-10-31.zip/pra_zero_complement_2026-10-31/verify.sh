#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/reconstruction_check.py > artifacts/reconstruction_check_report.json
python3 artifacts/rank_model_check.py > artifacts/rank_model_check_report.json
python3 artifacts/formula_check.py
