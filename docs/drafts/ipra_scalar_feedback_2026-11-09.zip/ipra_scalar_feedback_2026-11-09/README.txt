SCALAR SELF-COMPARISON FOR iPRA
AND A SMALLER COMPLETE PROOF KERNEL
==================================
Prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific time).

READ FIRST
----------
report.pdf is the complete research report.
report.tex is its editable master source, with sections/ and appendices/.
report_standalone.tex expands every input and checker listing into one
compilable LaTeX file. The final PDF is 42 pages; the standalone source
was also compiled separately without access to the package's other inputs.

EXACT RESULTS
-------------
1. A complete Choice-DI checker is 762 bytes. The previous current byte
   minimum was 801. Under the unchanged full-module normalization:

                         Tokens     AST nodes     Normalized bytes
   Previous byte leader     303           349                  801
   New choice_checker.py    298           349                  762

   The normalized delivered choice_checker.py is also exactly 762 raw
   bytes. All parser calls, rule checking, scope handling and verdicts
   are inside that file. It imports only json. The saving is 39 bytes
   (4.87%), with five fewer tokens and the same AST count.

   The observed old coordinate envelope is 295/334/801, attained by
   different existing programs. The new Choice profiles give 292/331/762,
   again in different files. No single-source dominance of all three
   old coordinate minima is claimed. These are empirical corpus minima,
   not a universal lower-bound or absolute-minimality theorem.

2. A new scalar feedback theory uses only 0, S, e, I in its numerical
   grammar, two iterator computation schemas, and one arithmetic
   self-comparison rule. The comparison e initially has no equations.
   Before induction is available, two finite-state scalar iterators
   supply three disjoint successor-isolated supports. They replace
   predecessor-based spikes and remove the full relative PR-description
   grammar from the earlier self-comparison approach.

   Calibration proves that e is actual Boolean inequality on the whole
   domain. It then yields equation/QF induction and the full PR language.
   The report proves both interpretation composites with identity domain
   isomorphisms. The native logical interface has Hyp, Tr, QE, DE and
   Case-DI only; no progress DI is assumed.

   The separate complete scalar_sc_checker.py measures 358 tokens,
   401 AST nodes and 941 normalized bytes. The 762-byte result DOES NOT
   measure this new theory. Its extra primitive and feedback rule are
   fully charged in its own source.

3. A general finite-period compiler constructs any fixed finite number
   of such supports without object-level induction. The sole induction
   in constructing that compiler is external finite syntax/proof building.

LIMIT OF THE OUTCOME
-------------------
A significant new axiomatization whose own complete checker beats the
entire compact frontier has not been established. The report provides
the two exact reductions above and does not relabel implementation
savings as that breakthrough. Neither absolute simplestness nor
literature-wide priority is claimed.

REPRODUCE OFFLINE
----------------
With Python 3.12 (recorded runtime: CPython 3.12.14):

    python3 verify.py

This verifies the package manifest, remeasures complete programs,
replays the supplied kernel certificates under normal and optimized
Python, runs the focused dispatch checks, and regenerates the finite
support/period validation. It needs no network and no proof assistant.
The standalone checkers use only Python's standard library.
The original file hashes are checked before regeneration. Evidence files
may change if regenerated under a different Python version; the manifest
describes the original delivered bytes.
The final supplied run passed 543 in-process checks, 1,086 public CLI
runs, and 7,800 targeted dispatch mutations. These counts describe
overlapping execution modes, not that many independent mathematical
theorems. The scalar-feedback suite has 19 accepts and 20 rejects.

Build the document with an installed standard LaTeX distribution:

    python3 build.py

The script uses three pdfLaTeX passes with shell escape disabled and
regenerates the complete standalone source. It records build warnings
for explicit review. The final PDF is already supplied.

The unchanged source_measure.py is imported by measure_sources.py; use
that wrapper to measure this package. To repeat the full corpus audit,
extract all 14 pinned ZIPs into a separate directory and run:

    python3 code/audit_corpus.py EXTRACTED_ROOT audit_result.json

EXAMPLES
--------
    python3 code/choice_checker.py < examples/choice_identity_iteration.json
    python3 code/scalar_sc_checker.py < examples/nonconstant_sc_closed.json

Both print ACCEPT and exit 0. Rejections print REJECT and return a
nonzero status, with a traceback on stderr. This matches the actual
older comparison controls; silent stderr is not a hidden comparison
requirement. Programs do not evaluate submitted strings as code.

The nonconstant SC example is a CLOSED native consequence whose local
closure/base assumptions supply its feedback premise. It does not
assert an unconditional false numerical equality. Its proof structure
and the precise term encodings are documented in the report and formats.

FILE GUIDE
----------
code/choice_checker.py        Primary 762-byte standalone Choice kernel.
code/choice_tokens.py         Independent 292-token profile.
code/choice_structure.py      Independent 331-AST profile.
code/scalar_sc_checker.py     Complete checker for the new feedback theory.
code/FORMAT_choice.txt        Full Choice packet and syntax interface.
code/FORMAT_scalar_sc.txt     Exact new comparator and feedback interface.
code/validate_kernels.py      Offline positive/negative and CLI validation.
code/validate_scalar_supports.py
                              Expanded scalar terms and finite phase tests.
code/measure_sources.py       Whole-program metric reproduction.
code/audit_corpus.py          Original full-source inventory script; requires
                              the 14 pinned source ZIPs extracted separately.
comparison/                   Exact current metric attainers, with provenance.
fixtures/, examples/          Reproducible certificate data.
evidence/                     Snapshot, hashes, metrics, reviews and receipts.
ATTRIBUTION.txt                Detailed inherited/new contribution mapping.
MANIFEST.json                 SHA-256 payload inventory.

EVIDENCE BOUNDARY
----------------
Finite tests check concrete programs, certificates, encodings and phase
tables. The universal equivalence, calibration, arithmetic compiler and
bi-interpretation claims are written proofs with separate assistant
reviews. They are not Lean/Rocq formalizations or external human peer
review. Real finite resource limits can reject very deep valid proofs.

SOURCE SNAPSHOT
---------------
VladimirReshetnikov/ProveIt
Commit 6c902762efcb1e78a5dd25db745310bab74f47a5
Directory docs/drafts, 14 direct ZIP archives.

https://github.com/VladimirReshetnikov/ProveIt/tree/6c902762efcb1e78a5dd25db745310bab74f47a5/docs/drafts

All 14 downloaded archive lengths and Git blob hashes were checked
against the GitHub directory listing. Full archive SHA-256 identities
and source-level audit results are included. No repository modification
or publication was performed.
