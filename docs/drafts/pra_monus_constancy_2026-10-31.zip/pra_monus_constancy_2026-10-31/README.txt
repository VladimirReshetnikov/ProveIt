A SMALLER CONSTANCY AXIOMATIZATION OF PRA
========================================
Prepared for Vladimir Reshetnikov, 31 October 2026 (Pacific time).

Read pra_monus_constancy.pdf for the complete report.
The main source is pra_monus_constancy.tex; keep sections/ alongside it.
axioms.txt is the complete concise formal specification.

MAIN RESULT
For classical PRA, use the ordinary primitive-recursion equations D, the
single axiom eps(x,y)=0 iff x!=y, and constancy of every successor-invariant
term. For intuitionistic PRA replace the fixed axiom by exclusive
x=y OR eps(x,y)=0. Define eps with four truncated-subtraction calls and
only two helper recursion declarations (predecessor, truncated subtraction).
The report proves exact same-language first-order equivalence in each logic.

WHAT IMPROVES
This simplifies the fixed comparison program of the existing constancy
alternatives. The constancy architecture itself is credited to the drafts.
The proof uses no fixed arithmetic helpers besides predecessor and monus.
Two scoped optimality theorems establish the minimum of four monus nodes
and two recursion declarations under the specified grammars.
A new duplicate-element countermodel disproves the proposed narrower
one-term zero-guard induction schema.

No absolute shortest-axiomatization or historical-priority claim is made.
No Lean or Rocq formal verification is claimed.

CONTENTS
  pra_monus_constancy.tex         main TeX source
  sections/*.tex                 complete proof sections
  pra_monus_constancy.pdf         compiled report
  axioms.txt                     precise concise specification
  draft_manifest.json            exact source snapshot and verified blob SHAs
  artifacts/*.py                 executable standard-library companions
  artifacts/*.json               reproduced finite check results
  VERIFICATION.txt               actual build and validation outcomes
  SHA256SUMS.txt                 package checksums, excluding this checksum file
  build.sh                       build and check commands

REBUILD
Run:
  sh build.sh
Requires Python 3 and a TeX Live installation with pdflatex and the packages
listed in the source. The scripts use only the Python standard library.
All finite tests are explicitly distinguished from the general mathematical
proofs. Rebuilding JSON certificates and the PDF may change their checksums.

SOURCES
Six archives from:
https://github.com/VladimirReshetnikov/ProveIt/tree/a0dd253b72f0ebfd368f674fcf722e0671d4a6ef/docs/drafts
Each downloaded archive was checked against its repository Git blob SHA.
The source archives themselves are not redistributed in this package.

