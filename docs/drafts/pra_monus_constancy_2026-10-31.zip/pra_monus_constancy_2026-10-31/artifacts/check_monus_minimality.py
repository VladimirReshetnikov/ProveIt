#!/usr/bin/env python3
"""Check the restricted minimality certificate for a four-monus equality flag.

This is an exhaustive finite certificate, not a proof assistant certificate.
On Boolean inputs, monus preserves Boolean values. A term zero exactly when
x != y must therefore have XNOR truth table 1001. The dynamic recurrence
below lists ALL truth tables of terms with k binary monus nodes and leaves
chosen from 0, 1, x, y. XNOR is absent for k <= 3 and present for k = 4.

The accompanying mathematical proof is stronger: a term with the desired
zero set on all natural inputs must contain x twice and y twice, since a
single occurrence gives a monotone or antitone function of that variable.
It also needs a positive numeral leaf to be nonzero at (0,0). Five leaves
require at least four binary nodes.
"""

from __future__ import annotations

import json
from pathlib import Path


def monus(x: int, y: int) -> int:
    return max(x - y, 0)


def epsilon(x: int, y: int) -> int:
    """Four monus calls; equal to 1 precisely when x=y, and 0 otherwise."""
    return monus(monus(1, monus(x, y)), monus(y, x))


def main() -> None:
    # Bits 0,1,2,3 correspond to (x,y)=(0,0),(0,1),(1,0),(1,1).
    full_mask = 0b1111
    target = 0b1001
    masks: list[set[int]] = [{0b0000, 0b1111, 0b1100, 0b1010}]
    term_counts = [4]
    for size in range(1, 5):
        masks.append(
            {
                left & (full_mask ^ right)
                for left_size in range(size)
                for left in masks[left_size]
                for right in masks[size - 1 - left_size]
            }
        )
        term_counts.append(
            sum(
                term_counts[left_size] * term_counts[size - 1 - left_size]
                for left_size in range(size)
            )
        )
    assert all(target not in masks[size] for size in range(4))
    assert target in masks[4]
    assert term_counts == [4, 16, 128, 1280, 14336]

    # A regression check of the numerical implementation, not the general
    # proof of its equality-indicator property.
    for x in range(129):
        for y in range(129):
            assert epsilon(x, y) == int(x == y)

    certificate = {
        "grammar": "T ::= 0 | 1 | x | y | monus(T,T)",
        "monus": "monus(a,b) = max(a-b,0)",
        "candidate": "monus(monus(1,monus(x,y)),monus(y,x))",
        "candidate_binary_nodes": 4,
        "candidate_numerical_regression_domain": "0 <= x,y <= 128",
        "bit_order": [[0, 0], [0, 1], [1, 0], [1, 1]],
        "target_equality_truth_mask": target,
        "exact_size_tables": [
            {
                "binary_nodes": size,
                "syntax_tree_count": term_counts[size],
                "attainable_masks": sorted(masks[size]),
                "contains_equality_mask": target in masks[size],
            }
            for size in range(5)
        ],
        "scope": (
            "Formula trees over the stated leaves and operator. This does "
            "not claim minimum whole-axiomatization size, or minimum circuits "
            "with shared subexpressions, or minimum terms in other signatures."
        ),
    }
    output = Path(__file__).with_name("monus_minimality_certificate.json")
    output.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
    print("Verified: no term with at most three monus nodes has the required")
    print("zero set even on Boolean inputs; the four-node candidate works.")
    print("Numerical regression: all 16,641 pairs in {0,...,128}^2 passed.")
    print(f"Certificate: {output.name}")


if __name__ == "__main__":
    main()
