#!/usr/bin/env python3
"""Executable illustration of the zero-guard countermodel for PRA.

The domain consists of ordinary n >= 0 and starred n >= 1.  Successor
preserves the star.  The projection forgets it and has singleton zero
fiber.  A fresh primitive-recursion declaration is evaluated normally on
the ordinary recursion-argument chain.  At the additional root 1*, its
value is the ordinary lift of its standard numerical value, and its
defining step then propagates along the starred chain.

Descriptions are finite and well founded: a declaration can use only
earlier declarations.  Recursion is represented by a distinguished
argument, a base term in the remaining parameters, and a step term in
(index, previous_value, parameters).  Arguments may be permuted; in
particular monus(x, y) recurses on y and means max(x - y, 0).

The script checks its generic interpreter on a finite sample.  These
checks do NOT prove every instance of the zero-guard schema.  The
universal model argument, including why every such instance holds, is a
mathematical proof in the accompanying report.

Run with Python 3.10 or later; no third-party packages are required.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json


@dataclass(frozen=True)
class Var:
    index: int


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    term: Term


@dataclass(frozen=True)
class Call:
    name: str
    arguments: tuple[Term, ...]


Term = Var | Zero | Succ | Call


@dataclass(frozen=True)
class Element:
    """An ordinary n >= 0 or a starred n >= 1."""

    number: int
    starred: bool = False

    def __post_init__(self) -> None:
        if type(self.number) is not int or self.number < 0:
            raise ValueError("The numerical coordinate must be a natural number")
        if type(self.starred) is not bool:
            raise ValueError("The star flag must be Boolean")
        if self.starred and self.number == 0:
            raise ValueError("There is no starred zero")

    def successor(self) -> Element:
        return Element(self.number + 1, self.starred)

    def __str__(self) -> str:
        return f"{self.number}{'*' if self.starred else ''}"


ZERO = Element(0)
ONE = Element(1)
STAR_ONE = Element(1, True)


@dataclass(frozen=True)
class Recursion:
    name: str
    arity: int
    recursion_index: int
    base: Term
    step: Term


class Language:
    """A registry enforcing finite, well-founded recursion descriptions."""

    def __init__(self) -> None:
        self.declarations: dict[str, Recursion] = {}

    def check_term(self, term: Term, variable_count: int) -> None:
        if isinstance(term, Var):
            if not 0 <= term.index < variable_count:
                raise ValueError("Variable outside its declared scope")
        elif isinstance(term, Zero):
            return
        elif isinstance(term, Succ):
            self.check_term(term.term, variable_count)
        elif isinstance(term, Call):
            if term.name not in self.declarations:
                raise ValueError("A declaration can refer only to earlier declarations")
            declaration = self.declarations[term.name]
            if len(term.arguments) != declaration.arity:
                raise ValueError("Function application has the wrong arity")
            for argument in term.arguments:
                self.check_term(argument, variable_count)
        else:
            raise TypeError(f"Unknown term constructor: {type(term).__name__}")

    def declare(self, declaration: Recursion) -> None:
        if declaration.name in self.declarations:
            raise ValueError("Declarations cannot be replaced")
        if declaration.arity < 1:
            raise ValueError("A recursion needs a recursion argument")
        if not 0 <= declaration.recursion_index < declaration.arity:
            raise ValueError("Invalid recursion argument position")
        self.check_term(declaration.base, declaration.arity - 1)
        self.check_term(declaration.step, declaration.arity + 1)
        self.declarations[declaration.name] = declaration


def split_arguments(
    declaration: Recursion, arguments: tuple
) -> tuple[object, tuple]:
    if len(arguments) != declaration.arity:
        raise ValueError("Wrong number of arguments")
    position = declaration.recursion_index
    return arguments[position], arguments[:position] + arguments[position + 1 :]


def insert_recursion_argument(
    declaration: Recursion, value: object, parameters: tuple
) -> tuple:
    position = declaration.recursion_index
    return parameters[:position] + (value,) + parameters[position:]


class Interpreter:
    """Generic interpretation in N and in the starred-domain model."""

    def __init__(self, language: Language) -> None:
        self.language = language

    @lru_cache(maxsize=None)
    def standard_term(self, term: Term, environment: tuple[int, ...]) -> int:
        if isinstance(term, Var):
            return environment[term.index]
        if isinstance(term, Zero):
            return 0
        if isinstance(term, Succ):
            return self.standard_term(term.term, environment) + 1
        if isinstance(term, Call):
            arguments = tuple(
                self.standard_term(argument, environment)
                for argument in term.arguments
            )
            return self.standard_call(term.name, arguments)
        raise TypeError("Invalid term")

    @lru_cache(maxsize=None)
    def ghost_term(
        self, term: Term, environment: tuple[Element, ...]
    ) -> Element:
        if isinstance(term, Var):
            return environment[term.index]
        if isinstance(term, Zero):
            return ZERO
        if isinstance(term, Succ):
            return self.ghost_term(term.term, environment).successor()
        if isinstance(term, Call):
            arguments = tuple(
                self.ghost_term(argument, environment)
                for argument in term.arguments
            )
            return self.ghost_call(term.name, arguments)
        raise TypeError("Invalid term")

    @lru_cache(maxsize=None)
    def standard_call(self, name: str, arguments: tuple[int, ...]) -> int:
        declaration = self.language.declarations[name]
        recursion_argument, parameters = split_arguments(declaration, arguments)
        if type(recursion_argument) is not int or recursion_argument < 0:
            raise ValueError("Standard recursion argument is not a natural number")
        value = self.standard_term(declaration.base, parameters)
        for index in range(recursion_argument):
            value = self.standard_term(
                declaration.step, (index, value) + parameters
            )
        return value

    @lru_cache(maxsize=None)
    def ghost_call(self, name: str, arguments: tuple[Element, ...]) -> Element:
        declaration = self.language.declarations[name]
        recursion_argument, parameters = split_arguments(declaration, arguments)
        if not isinstance(recursion_argument, Element):
            raise TypeError("Ghost recursion argument is not a model element")

        if recursion_argument.starred:
            # The extra chain starts at 1*.  This value is deliberately
            # chosen in the ordinary fiber, even for starred parameters.
            projected_parameters = tuple(value.number for value in parameters)
            root_arguments = insert_recursion_argument(
                declaration, 1, projected_parameters
            )
            value = Element(self.standard_call(name, root_arguments))
            first_step = 1
        else:
            value = self.ghost_term(declaration.base, parameters)
            first_step = 0

        for index in range(first_step, recursion_argument.number):
            value = self.ghost_term(
                declaration.step,
                (Element(index, recursion_argument.starred), value) + parameters,
            )
        return value


def make_language() -> Language:
    language = Language()
    # p(0)=0; p(Sn)=n.
    language.declare(Recursion("pred", 1, 0, Zero(), Var(0)))
    # monus(x,0)=x; monus(x,Sy)=p(monus(x,y)).
    language.declare(
        Recursion("monus", 2, 1, Var(0), Call("pred", (Var(1),)))
    )
    # z(0)=1; z(Sn)=0.
    language.declare(Recursion("zero_test", 1, 0, Succ(Zero()), Zero()))
    # c(0,u,v)=u; c(Sn,u,v)=v.
    language.declare(Recursion("selector", 3, 0, Var(0), Var(3)))
    # k(0,a)=a; k(Sn,a)=k(n,a).
    language.declare(Recursion("constant", 2, 0, Var(0), Var(1)))
    # add(0,y)=y; add(Sn,y)=S(add(n,y)).
    language.declare(Recursion("add", 2, 0, Var(0), Succ(Var(1))))
    return language


def check_rejected_descriptions() -> int:
    invalid = (
        Recursion("self", 1, 0, Zero(), Call("self", (Var(0),))),
        Recursion("forward", 1, 0, Zero(), Call("later", (Var(0),))),
        Recursion("scope", 1, 0, Var(0), Zero()),
        Recursion("arity", 1, 0, Call("pred", (Zero(), Zero())), Zero()),
    )
    for declaration in invalid:
        try:
            make_language().declare(declaration)
        except ValueError:
            continue
        raise AssertionError("An invalid recursion description was accepted")
    try:
        Element(0, True)
    except ValueError:
        return len(invalid) + 1
    raise AssertionError("The model admitted a starred zero")


def check_standard_semantics(interpreter: Interpreter, maximum: int) -> int:
    checks = 0
    numbers = range(maximum + 1)
    for n in numbers:
        assert interpreter.standard_call("pred", (n,)) == max(n - 1, 0)
        assert interpreter.standard_call("zero_test", (n,)) == int(n == 0)
        checks += 2
    for x, y in product(numbers, repeat=2):
        assert interpreter.standard_call("monus", (x, y)) == max(x - y, 0)
        assert interpreter.standard_call("constant", (x, y)) == y
        assert interpreter.standard_call("add", (x, y)) == x + y
        checks += 3
    for n, u, v in product(numbers, repeat=3):
        assert interpreter.standard_call("selector", (n, u, v)) == (
            u if n == 0 else v
        )
        checks += 1
    return checks


def run_checks(maximum: int) -> dict:
    language = make_language()
    interpreter = Interpreter(language)
    elements = tuple(Element(n) for n in range(maximum + 1)) + tuple(
        Element(n, True) for n in range(1, maximum + 1)
    )
    counts = {"base_equations": 0, "step_equations": 0, "projection": 0,
              "zero_reflection": 0, "compound_terms": 0}

    for declaration in language.declarations.values():
        for parameters in product(elements, repeat=declaration.arity - 1):
            zero_arguments = insert_recursion_argument(declaration, ZERO, parameters)
            assert interpreter.ghost_call(declaration.name, zero_arguments) == (
                interpreter.ghost_term(declaration.base, parameters)
            )
            counts["base_equations"] += 1

            for n in elements:
                arguments = insert_recursion_argument(declaration, n, parameters)
                successor_arguments = insert_recursion_argument(
                    declaration, n.successor(), parameters
                )
                value = interpreter.ghost_call(declaration.name, arguments)
                assert interpreter.ghost_call(declaration.name, successor_arguments) == (
                    interpreter.ghost_term(declaration.step, (n, value) + parameters)
                )
                counts["step_equations"] += 1
                standard_value = interpreter.standard_call(
                    declaration.name, tuple(argument.number for argument in arguments)
                )
                assert value.number == standard_value
                counts["projection"] += 1
                assert (value == ZERO) == (standard_value == 0)
                counts["zero_reflection"] += 1

    # epsilon(x,y)=(1 monus (x monus y)) monus (y monus x).
    epsilon = Call("monus", (
        Call("monus", (Succ(Zero()), Call("monus", (Var(0), Var(1))))),
        Call("monus", (Var(1), Var(0))),
    ))
    language.check_term(epsilon, 2)
    for x, y in product(elements, repeat=2):
        value = interpreter.ghost_term(epsilon, (x, y))
        standard_value = interpreter.standard_term(epsilon, (x.number, y.number))
        assert standard_value == int(x.number == y.number)
        assert value.number == standard_value
        assert (value == ZERO) == (standard_value == 0)
        counts["compound_terms"] += 1

    predecessor = interpreter.ghost_call("pred", (STAR_ONE,))
    assert predecessor == ZERO
    assert STAR_ONE != ZERO
    assert predecessor.successor() != STAR_ONE
    assert ZERO != ONE
    for value in elements:
        assert value.successor() != ZERO
        # The zero-test case split holds although constructor coverage fails.
        assert value == ZERO or interpreter.ghost_call("zero_test", (value,)) == ZERO

    ordinary_constant = interpreter.ghost_call("constant", (ONE, STAR_ONE))
    starred_constant = interpreter.ghost_call("constant", (STAR_ONE, STAR_ONE))
    assert ordinary_constant == STAR_ONE
    assert starred_constant == ONE
    assert interpreter.ghost_call("monus", (STAR_ONE, ZERO)) == STAR_ONE
    assert interpreter.ghost_call("monus", (STAR_ONE, ONE)) == ZERO
    assert interpreter.ghost_call("selector", (STAR_ONE, ZERO, STAR_ONE)) == ONE

    counts["standard_semantics"] = check_standard_semantics(interpreter, maximum)
    counts["invalid_descriptions_rejected"] = check_rejected_descriptions()
    return {
        "status": "passed",
        "sample_maximum": maximum,
        "sample_elements": len(elements),
        "declarations": list(language.declarations),
        "finite_checks": counts,
        "coverage_counterexample": {
            "x": str(STAR_ONE), "pred_x": str(predecessor),
            "S_pred_x": str(predecessor.successor()),
            "x_is_zero": False, "x_equals_S_pred_x": False,
        },
        "constant_with_starred_parameter": {
            "constant(1,1*)": str(ordinary_constant),
            "constant(1*,1*)": str(starred_constant),
        },
        "scope": "Finite interpreter checks only; universal validity of G0 is proved in the report.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-value", type=int, default=4,
                        help="largest coordinate in the finite test sample (default: 4)")
    arguments = parser.parse_args()
    if arguments.max_value < 1:
        parser.error("--max-value must be at least 1")
    print(json.dumps(run_checks(arguments.max_value), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
