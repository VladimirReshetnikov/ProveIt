#!/usr/bin/env python3
"""Independent executable checks for the selector-free PRA construction.

The mathematical report proves the general equivalence. This module checks
the arithmetic truth tables, structural formula compiler, and local latch
identity. In particular, the incoming latch state q is NOT assumed Boolean.
Only monus and the four-monus equality flag are used arithmetically.
"""

from __future__ import annotations

import itertools
import json
from pathlib import Path


def sub(x: int, y: int) -> int:
    return max(x - y, 0)


def eps(x: int, y: int) -> int:
    return sub(sub(1, sub(x, y)), sub(y, x))


def zero_flag(q: int) -> int:
    return eps(q, 0)


def positive_flag(q: int) -> int:
    return sub(1, zero_flag(q))


def bnot(a: int) -> int:
    return sub(1, a)


def band(a: int, b: int) -> int:
    return sub(a, sub(1, b))


def bor(a: int, b: int) -> int:
    return sub(1, sub(sub(1, a), b))


def bimp(a: int, b: int) -> int:
    return sub(1, sub(a, b))


# Formulas are finite tuples; arithmetic atoms use variable names.
def compiled_value(formula: tuple, env: dict[str, int]) -> int:
    op = formula[0]
    if op == "top":
        return 1
    if op == "bottom":
        return 0
    if op == "eq":
        return positive_flag(eps(env[formula[1]], env[formula[2]]))
    if op == "not":
        return bnot(compiled_value(formula[1], env))
    a = compiled_value(formula[1], env)
    b = compiled_value(formula[2], env)
    return {"and": band, "or": bor, "imp": bimp}[op](a, b)


def logical_value(formula: tuple, env: dict[str, int]) -> bool:
    op = formula[0]
    if op == "top":
        return True
    if op == "bottom":
        return False
    if op == "eq":
        return env[formula[1]] == env[formula[2]]
    if op == "not":
        return not logical_value(formula[1], env)
    a = logical_value(formula[1], env)
    b = logical_value(formula[2], env)
    return {"and": a and b, "or": a or b, "imp": (not a) or b}[op]


def formula_families(max_connectives: int) -> list[list[tuple]]:
    families = [[("top",), ("bottom",), ("eq", "x", "y"),
                 ("eq", "y", "z"), ("eq", "x", "z")]]
    for size in range(1, max_connectives + 1):
        current = [("not", f) for f in families[size - 1]]
        for left_size in range(size):
            for op in ("and", "or", "imp"):
                current.extend(
                    (op, left, right)
                    for left in families[left_size]
                    for right in families[size - 1 - left_size]
                )
        families.append(current)
    return families


def main() -> None:
    for a, b in itertools.product((0, 1), repeat=2):
        assert bnot(a) == int(not a)
        assert band(a, b) == int(bool(a) and bool(b))
        assert bor(a, b) == int(bool(a) or bool(b))
        assert bimp(a, b) == int((not a) or bool(b))

    transitions = []
    local_checks = 0
    for a, b in itertools.product((0, 1), repeat=2):
        if a == 1 and b == 0:
            continue  # This is excluded by the induction-step hypothesis.
        transitions.append([a, b])
        for q in range(129):
            # P(Sn)=a monus N(P(n)); write q=P(n), ell=P(Sn).
            ell = sub(a, zero_flag(q))
            ell_next = sub(b, zero_flag(ell))
            assert ell in (0, 1)
            assert ell_next == ell
            assert positive_flag(positive_flag(q)) == positive_flag(q)
            local_checks += 1
    assert sub(1, zero_flag(1)) == 1  # P(0)=1 and b(0)=1 give L(0)=1.

    families = formula_families(2)
    environments = [dict(zip(("x", "y", "z"), xs))
                    for xs in itertools.product(range(3), repeat=3)]
    compiler_checks = 0
    for family in families:
        for formula in family:
            for env in environments:
                value = compiled_value(formula, env)
                assert value in (0, 1)
                assert value == int(logical_value(formula, env))
                compiler_checks += 1

    report = {
        "boolean_truth_tables": "all four input pairs passed",
        "truth_convention": "1=true, 0=false",
        "allowed_latch_transitions": transitions,
        "incoming_latch_states": "all q in {0,...,128}, not assumed Boolean",
        "local_latch_checks": local_checks,
        "formula_counts_by_number_of_connectives": [len(f) for f in families],
        "arithmetic_environments": len(environments),
        "compiler_checks": compiler_checks,
        "status": "all checks passed",
        "scope": (
            "Finite exhaustive truth-table and regression checks. The article "
            "supplies the general constructive argument and syntactic "
            "equivalence proof; this script is not a proof assistant."
        ),
    }
    output = Path(__file__).with_name("boolean_latch_verification.json")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"All Boolean truth tables passed; {local_checks} local latch checks passed.")
    print(f"Compiler: {compiler_checks:,} formula/environment checks passed.")
    print(f"Certificate: {output.name}")


if __name__ == "__main__":
    main()
