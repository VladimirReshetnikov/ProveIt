#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check_monus_minimality.py
python3 artifacts/check_kernel.py
python3 artifacts/ghost_model.py > artifacts/ghost_model_results.json
pdflatex -interaction=nonstopmode -halt-on-error pra_monus_constancy.tex
pdflatex -interaction=nonstopmode -halt-on-error pra_monus_constancy.tex

