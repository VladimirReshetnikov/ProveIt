"""Finite validation of the supporting transport compiler and independent checker.

Run: python3 tests/test_transport.py
The resulting receipt is evidence/transport_validation.json. These tests are
not a formal proof of the universal transport metatheorem or iPRA equivalence.
"""
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
from transport_kernel import (
    Var, App, Eq, D, Clause, Proof, ZERO, successor, Rejected,
    check, substitute, substitute_term, alpha_equal, free_names,
    proof_statistics,
)
from transport_compiler import compile_transport


RECEIPT = {"positive_examples": [], "negative_controls": []}


def atom(name):
    return Eq(Var(name), Var(name))


def nested_formula(depth):
    arguments = (Var("hole"),) + tuple(
        Var(name) for i in range(depth) for name in (f"x{i}", f"y{i}")
    )
    result = Eq(App("left", arguments), App("right", (Var("hole"),)))
    for i in reversed(range(depth)):
        result = D(f"x{i}", f"y{i}", result)
    return result


class TransportTests(unittest.TestCase):
    def accepted(self, label, motive, variable="hole", source=None, target=None):
        source = Var("s") if source is None else source
        target = App("f", (Var("t"),)) if target is None else target
        context, proof = compile_transport(motive, variable, source, target)
        result = check(proof, context)
        self.assertTrue(alpha_equal(result, substitute(motive, {variable: target})))
        RECEIPT["positive_examples"].append({"name": label, **proof_statistics(proof)})
        return context, proof

    def rejected(self, label, proof, context=()):
        with self.assertRaises(Rejected) as failure:
            check(proof, context)
        RECEIPT["negative_controls"].append({"name": label, "reason": str(failure.exception)})

    def test_depth_zero_through_five(self):
        for depth in range(6):
            with self.subTest(depth=depth):
                self.accepted(f"binder_depth_{depth}", nested_formula(depth))

    def test_capture_avoidance_for_both_inserted_terms(self):
        motive = D("s", "t", Eq(App("p", (Var("hole"), Var("s"))), Var("t")))
        self.accepted("capture_both_images", motive, source=Var("s"), target=Var("t"))

    def test_nested_shadowing(self):
        motive = D("x", "y", D("x", "z", Eq(
            App("p", (Var("hole"), Var("x"), Var("y"))), Var("z"))))
        self.accepted("nested_shadowing", motive, source=Var("x"), target=Var("z"))

    def test_hole_is_bound(self):
        motive = D("hole", "y", Eq(Var("hole"), Var("y")))
        self.accepted("bound_hole", motive)

    def test_hole_is_absent(self):
        self.accepted("absent_hole", D("x", "y", atom("x")))

    def test_substitution_is_simultaneous(self):
        term = App("pair", (Var("x"), Var("y")))
        self.assertEqual(substitute_term(term, {"x": Var("y"), "y": ZERO}),
                         App("pair", (Var("y"), ZERO)))

    def test_substitution_alpha_and_free_names(self):
        original = D("a", "b", Eq(Var("hole"), Var("a")))
        actual = substitute(original, {"hole": Var("a")})
        expected = D("new", "b", Eq(Var("a"), Var("new")))
        self.assertTrue(alpha_equal(actual, expected))
        self.assertEqual(free_names(actual), {"a"})
        self.assertFalse(alpha_equal(actual, D("a", "b", Eq(Var("a"), Var("a")))))

    def test_nested_shadow_alpha(self):
        first = D("x", "y", D("x", "z", Eq(Var("x"), Var("y"))))
        second = D("a", "b", D("c", "d", Eq(Var("c"), Var("b"))))
        self.assertTrue(alpha_equal(first, second))
        self.assertFalse(alpha_equal(first, D("a", "b", D("c", "d", Eq(Var("a"), Var("b"))))))

    def test_reject_compound_transport(self):
        motive = D("x", "y", Eq(Var("hole"), Var("x")))
        source, target = Var("s"), Var("t")
        gamma = (Eq(source, target), substitute(motive, {"hole": source}))
        bad = Proof("transport", substitute(motive, {"hole": target}),
                    (Proof("hyp", gamma[0], data={"index": 0}),
                     Proof("hyp", gamma[1], data={"index": 1})),
                    {"variable": "hole", "motive": motive})
        self.rejected("compound_transport", bad, gamma)

    def test_reject_DI_eigenvariable_escape(self):
        context = (atom("z"),)
        goal = D("x", "y", atom("y"))
        step = Proof("refl", Eq(successor(Var("z")), successor(Var("z"))))
        self.rejected("DI_retained_eigenvariable", Proof(
            "DI", goal, (step,), {"witness": ZERO, "eigen": "z"}), context)

    def test_reject_DE_eigenvariable_escape(self):
        major = D("x", "y", atom("y"))
        context = (major,)
        goal = atom("a")
        proof = Proof("DE", goal,
                      (Proof("hyp", major, data={"index": 0}), Proof("refl", goal)),
                      {"eigen": "a"})
        self.rejected("DE_conclusion_eigenvariable", proof, context)

    def test_reject_compound_induction_hypothesis(self):
        body = D("u", "v", Eq(Var("y"), Var("u")))
        goal = D("x", "y", body)
        step = substitute(body, {"y": successor(Var("z"))})
        # A compound DI has only its base at index 0; an index-1 IH is illegal.
        proof = Proof("DI", goal,
                      (Proof("hyp", step, data={"index": 1}),),
                      {"witness": ZERO, "eigen": "z"})
        self.rejected("compound_induction_hypothesis", proof)

    def test_reject_unproved_major(self):
        major = D("x", "y", atom("y"))
        proof = Proof("DE", atom("n"),
                      (Proof("hyp", major, data={"index": 0}), Proof("refl", atom("n"))),
                      {"eigen": "a"})
        self.rejected("unproved_DE_major", proof)

    def test_reject_bad_clause_base(self):
        clause = Clause(Eq(Var("p"), ZERO), "y", atom("y"))
        proof = Proof("use", atom("n"), (Proof("refl", Eq(ZERO, ZERO)),),
                      {"index": 0, "term": Var("n")})
        self.rejected("bad_clause_base", proof, (clause,))

    def test_reject_bad_atomic_transport_target(self):
        equation = Eq(Var("s"), Var("t"))
        proof = Proof("transport", Eq(Var("s"), Var("s")),
                      (Proof("hyp", equation, data={"index": 0}),
                       Proof("refl", Eq(Var("s"), Var("s")))),
                      {"variable": "v", "motive": Eq(Var("v"), Var("s"))})
        self.rejected("bad_atomic_transport_target", proof, (equation,))


if __name__ == "__main__":
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(TransportTests))
    print(log.getvalue(), end="")
    receipt = {
        "scope": "Finite supporting checks for an inherited theorem; not a full iPRA checker, size record, Lean/Rocq formalization, or proof of the universal metatheorem.",
        "kernel_conveniences": ["ordinary Hyp", "Refl"],
        "kernel_rules": ["hyp", "refl", "transport (literal-equation motives only)", "use", "DI", "DE"],
        "arithmetic": "Uninterpreted first-order applications; 0 and S are constructors only. No PR computation or full iPRA syntax is implemented.",
        "python": sys.version,
        "tests_run": result.testsRun,
        "successful": result.wasSuccessful(),
        "failures": len(result.failures),
        "errors": len(result.errors),
        **RECEIPT,
        "source_sha256": {
            str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in [ROOT / "code/transport_kernel.py", ROOT / "code/transport_compiler.py", Path(__file__).resolve()]
        },
        "test_log": log.getvalue(),
    }
    (ROOT / "evidence/transport_validation.json").write_text(json.dumps(receipt, indent=2) + "\n")
    raise SystemExit(0 if result.wasSuccessful() else 1)
