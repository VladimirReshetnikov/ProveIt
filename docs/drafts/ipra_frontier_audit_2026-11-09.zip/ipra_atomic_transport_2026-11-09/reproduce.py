"""Reproduce the source audit and supporting transport tests."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

if __name__ == '__main__':
    subprocess.run([sys.executable, 'code/audit_frontier.py',
                    'experiments/clausal_direct.py',
                    'experiments/clausal_triples.py'], cwd=ROOT, check=True)
    subprocess.run([sys.executable, 'tests/test_transport.py'], cwd=ROOT, check=True)
    print('Source measurements and supporting proof checks reproduced.')
