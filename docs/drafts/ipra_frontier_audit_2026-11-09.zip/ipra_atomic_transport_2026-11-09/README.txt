ATOMIC EQUALITY, INDUCTION CUTS, AND THE IPRA FRONTIER
Prepared for Vladimir Reshetnikov, 9 November 2026

STATUS
The requested significant mathematical breakthrough and a complete checker
strictly below the current draft frontier were NOT established. This package
does not claim a new smallest axiomatization.

The current baseline is 309 normalized tokens / 344 AST nodes / 864
normalized bytes, already attained by the reconstructed complete_kernel.py
in the user's supplied drafts. Atomic-only equality transport was also
already noted in the corpus. The new code here is a readable supporting
proof compiler and independent local checker, not a smaller complete iPRA
checker.

CONTENTS
report.tex, sections/     Editable source of the research report.
report.pdf               Compiled report.
code/audit_frontier.py    Reproducible full-source comparison.
code/transport_kernel.py Independent checker for the transport fragment.
code/transport_compiler.py
                         Explicit native D transport derivation compiler.
tests/test_transport.py  Capture, alpha, freshness, and rejection tests.
experiments/             Two new unvalidated Open-interface sketches;
                         measured separately and excluded from the minimum.
reference/               19 unchanged complete comparators, 3 explicitly
                         unvalidated inherited experiments, normalizer,
                         licenses, specifications, and provenance.
evidence/                Measurement, source verification, test receipts,
                         claim ledger, and document-quality evidence.
dependencies/            Unchanged inherited shifted-equational package,
                         with its source/PDF and embedded dependencies.
build.py                 Compile this report with pdflatex.
reproduce.py             Remeasure comparators and rerun supporting tests.
MANIFEST.sha256           SHA-256 hashes of the final package files.

REPRODUCTION
From this package directory:
  python3 reproduce.py
  python3 build.py

Expected environment for exact inherited metric: CPython 3.12.14.
Other Python releases may produce different ast.unparse output.
LaTeX needs a standard installation with pdflatex and the packages imported
by report.tex. No network access is needed for these commands.

SOURCE SNAPSHOT
Repository: VladimirReshetnikov/ProveIt
Commit: 89fd4b4c5cd158259b1f2846f63e3d98f053553c
Directory: docs/drafts
Current ZIPs: 11
Distinct inventoried Python sources: 131
Recorded Python member occurrences: 415
Complete-source comparators: 19 (per the supplied papers' classification)

TRUST BOUNDARY
Written mathematical proofs are not a Lean/Rocq formalization.
Finite compiler tests do not prove the general metatheorem by themselves.
The frontier audit does not re-prove every inherited kernel's soundness.
The entire measured source includes imports, input, checks, rejection and
verdict handling. Only comments and genuine docstrings are removed.
All comparison code is preserved with its original notices; it is not
claimed as newly authored here.

RESEARCH OUTCOME
The report specifies the complete native K/D theory, spells out the
already-known atomic transport reduction for D, proves equivalence of a
uniform Open presentation, gives a concrete constant-orbit obstruction to
an unchanged-rule normalization shortcut, and applies a published
interpretability theorem to exclude finite ordinary first-order
axiomatizations of iPRA up to mutual interpretation. The latter is a
qualitative boundary, not a token/byte lower bound.
