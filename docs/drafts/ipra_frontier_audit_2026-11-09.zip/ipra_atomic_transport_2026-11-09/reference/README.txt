CURRENT CORPUS: COMPLETE-CHECKER SOURCE AUDIT
===========================================

Snapshot: VladimirReshetnikov/ProveIt, main commit
89fd4b4c5cd158259b1f2846f63e3d98f053553c, docs/drafts.
All 11 current ZIP archives and their recursively embedded ZIP members were
inventoried. There are 131 distinct Python sources at 415 member occurrences.
The inventory includes 19 distinct programs classified as complete iPRA proof
acceptors, 3 explicitly unvalidated full-interface experiments, and the
remaining fragment checkers, producers, diagnostics and utility programs.

The complete programs comprise the 17 compact sources preserved by the
previous frontier bundles, the readable direct shifted-arithmetic checker,
and complete_kernel.py in ipra_package_reconstructed.zip. Omitting this last
current source gives an obsolete 312/347/878 comparison. With it, the actual
literal-source minima are 309 tokens / 344 AST nodes / 864 normalized bytes,
all attained by complete_kernel.py. These are achieved implementation sizes,
not universal lower bounds. The token/AST/byte convention is the unchanged
inherited whole-program normalizer under CPython 3.12.14.

Run from the package root:
    python3 code/audit_frontier.py

The script verifies exact SHA-256 source identities and remeasures every
retained complete source and each explicitly excluded full-interface
experiment. The reader, imports, rule and scope checking, and output driver
all count. It does not execute comparator programs or reprove their universal
correctness. Their classification is grounded in the inherited specifications
and written soundness/completeness arguments, not a proof-assistant audit.

Optionally verify the original eleven ZIPs and all listed Python occurrences:
    python3 code/audit_frontier.py --source-directory /path/to/original/zip/directory

Optional further source files may be supplied as positional arguments. They
are measured separately; the script does not infer completeness from a small
size. No experimental unified-Open sketch is included as a complete source.

frontier_manifest.json records the exact archive Git blob and SHA-256 hashes,
all checker member paths (including nested ZIP chains), source hashes, the
normalizer identity, retained attribution files, and the excluded inventory.
The checker files are unchanged. LICENSE-inherited.txt and provenance/ retain
the supplied license and attribution notices. Documentation under provenance/
is copied unchanged and may describe earlier archive layouts; its file names
are historical provenance, not instructions to fetch omitted dependencies.

The uniform short-name control is reported separately. In particular,
compact_open.py becomes 317 tokens / 351 AST nodes / 816 bytes under the
shared inst->i, check->c, take->q renaming. Therefore the 864-byte literal
minimum is not a name-independent byte optimum.
