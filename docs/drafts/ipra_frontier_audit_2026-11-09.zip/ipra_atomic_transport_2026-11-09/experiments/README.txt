EXPLORATORY INTERFACE SKETCHES — NOT VALIDATED COMPLETE CHECKERS

clausal_direct.py and clausal_triples.py preserve the two trial layouts
reported in Section 3.3. Their arithmetic and substitution skeletons adapt
the inherited compact checker organization. Their role is to record why
the trial implementation did not improve the complete-source frontier.

No soundness or completeness certification is claimed. These files must
not be counted as complete iPRA comparators or used as trusted acceptors.
The measurement utility parses their full source without executing them.

Running reproduce.py records them under "candidates" in evidence/frontier.json,
separately from the nineteen inherited complete comparators and the three
inherited unvalidated experiments. Their expected profiles are:

clausal_direct.py:  351 normalized tokens / 392 AST nodes / 1014 bytes
clausal_triples.py: 370 normalized tokens / 404 AST nodes / 1014 bytes

Inherited source notices are retained under reference/.
