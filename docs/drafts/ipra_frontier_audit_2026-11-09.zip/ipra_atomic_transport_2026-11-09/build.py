"""Compile the editable research report; no network access is used."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent

if __name__ == '__main__':
    exe = shutil.which('pdflatex')
    if exe is None:
        raise SystemExit('pdflatex is required; install a standard TeX distribution.')
    for run in range(3):
        completed = subprocess.run(
            [exe, '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if completed.returncode:
            print(completed.stdout)
            raise SystemExit(completed.returncode)
    print('Compiled', ROOT / 'report.pdf')
