"""Construct finite examples of the inherited atomic-transport theorem.

The separate transport_kernel.check validates the output. This compiler does
not implement a full iPRA language or claim a machine proof of the general
metatheorem. All compounds are handled by DI/DE/Use, never by compound Tr.
"""
from transport_kernel import (
    Var, Eq, D, Clause, Proof, ZERO, successor, substitute, free_names,
    all_names, term_names, context_names, fresh_name,
)


class Compiler:
    def __init__(self, forbidden=()):
        self.used = set(forbidden)

    def fresh(self, prefix):
        name = fresh_name(self.used, prefix)
        self.used.add(name)
        return name

    @staticmethod
    def hypothesis(formula, index):
        return Proof("hyp", formula, data={"index": index})

    def symmetry(self, equality_proof):
        equation = equality_proof.conclusion
        hole = self.fresh("_sym")
        return Proof(
            "transport", Eq(equation.right, equation.left),
            (equality_proof, Proof("refl", Eq(equation.left, equation.left))),
            {"variable": hole, "motive": Eq(Var(hole), equation.left)},
        )

    def transport(self, motive, variable, source, target, equality_proof,
                  source_proof, context):
        """Build a proof of motive[target] using equation-only Tr."""
        self.used |= (all_names(motive) | term_names(source) | term_names(target)
                      | context_names(context, True) | {variable})
        goal = substitute(motive, {variable: target})
        if isinstance(motive, Eq):
            return Proof("transport", goal, (equality_proof, source_proof),
                         {"variable": variable, "motive": motive})

        # Alpha-rename both outer binders away from the hole and inserted terms.
        # The original compound motive may shadow the requested hole entirely.
        x, y = self.fresh("_x"), self.fresh("_y")
        body = substitute(motive.body,
                          {motive.witness: Var(x), motive.counter: Var(y)})
        renamed = D(x, y, body)
        # If the original binder shadows `variable`, the renamed body must not
        # expose that occurrence: the renaming above has already replaced it.
        source_formula = substitute(renamed, {variable: source})
        target_formula = substitute(renamed, {variable: target})

        a, z = self.fresh("_a"), self.fresh("_z")
        source_matrix = substitute(source_formula.body, {x: Var(a)})
        clause = Clause(substitute(source_matrix, {y: ZERO}), y, source_matrix)
        open_context = context + (clause,)

        base = substitute(target_formula.body, {x: Var(a), y: ZERO})
        local = open_context + (base,)
        if isinstance(target_formula.body, Eq):
            local += (substitute(target_formula.body, {x: Var(a), y: Var(z)}),)

        base_motive = substitute(body, {x: Var(a), y: ZERO})
        backwards = self.transport(
            base_motive, variable, target, source, self.symmetry(equality_proof),
            self.hypothesis(base, len(open_context)), local,
        )
        source_step = substitute(source_matrix, {y: successor(Var(z))})
        specialized = Proof("use", source_step, (backwards,),
                            {"index": len(context), "term": successor(Var(z))})
        step_motive = substitute(body, {x: Var(a), y: successor(Var(z))})
        forwards = self.transport(step_motive, variable, source, target,
                                  equality_proof, specialized, local)
        introduced = Proof("DI", target_formula, (forwards,),
                           {"witness": Var(a), "eigen": z})
        # Source and target may have different harmless capture-avoiding names;
        # the kernel checks their alpha-equivalence rather than textual identity.
        return Proof("DE", goal, (source_proof, introduced), {"eigen": a})


def compile_transport(motive, variable, source, target):
    """Return (context, proof) for s=t, F(s) |- F(t)."""
    context = (Eq(source, target), substitute(motive, {variable: source}))
    compiler = Compiler(all_names(motive) | term_names(source) | term_names(target)
                        | context_names(context, True) | {variable})
    proof = compiler.transport(
        motive, variable, source, target, compiler.hypothesis(context[0], 0),
        compiler.hypothesis(context[1], 1), context,
    )
    return context, proof
