"""Reproduce the complete-program frontier from the pinned current corpus.

The measured checker sources and normalizer are unchanged reference copies.
This utility checks identities and source metrics; it never executes a checker
and does not claim to prove its semantic correctness. All imports, readers,
validation, rule dispatch and CLI code remain in each measurement.
"""
from pathlib import Path
from zipfile import ZipFile
import argparse
import ast
import collections
import hashlib
import importlib.util
import io
import json
import platform
import sys

ROOT = Path(__file__).resolve().parents[1]
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checked_file(record):
    path = ROOT / record['file']
    if digest(path.read_bytes()) != record['sha256']:
        raise ValueError('Changed reference file: ' + record['file'])
    return path


def member_bytes(source_directory, occurrence):
    data = (source_directory / occurrence['archive']).read_bytes()
    for member in occurrence['members']:
        with ZipFile(io.BytesIO(data)) as archive:
            data = archive.read(member)
    return data


def verify_archives(source_directory, manifest):
    for item in manifest['archives']:
        data = (source_directory / item['name']).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if len(data) != item['size'] or digest(data) != item['sha256'] or blob != item['git_blob_sha1']:
            raise ValueError('Changed source archive: ' + item['name'])
    occurrence_count = 0
    for item in manifest['programs'] + manifest['excluded_python_sources']:
        for occurrence in item['occurrences']:
            data = member_bytes(source_directory, occurrence)
            if len(data) != item['source_size'] or digest(data) != item['sha256']:
                raise ValueError('Changed source member: ' + repr(occurrence))
            occurrence_count += 1
    if occurrence_count != manifest['python_member_occurrence_count']:
        raise ValueError('Source inventory count changed')
    return {'archives_verified': len(manifest['archives']),
            'python_member_occurrences_verified': occurrence_count,
            'distinct_python_sources_verified': manifest['python_source_count']}


def strip_documentation(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                node.body.pop(0)
    return tree


def uniform_name_control(path, measurer):
    """The inherited attainer control; it changes identifiers, never rules."""
    mapping = {'inst': 'i', 'check': 'c', 'take': 'q'}
    tree = strip_documentation(ast.parse(path.read_text()))
    names = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)}
    names.update(n.arg for n in ast.walk(tree) if isinstance(n, ast.arg))
    names.update(n.name for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)))
    used = {k: v for k, v in mapping.items() if k in names}
    if set(used.values()) & names:
        return {'applied': False, 'reason': 'A target identifier already occurs.'}

    class Rename(ast.NodeTransformer):
        def visit_Name(self, node):
            node.id = used.get(node.id, node.id)
            return node

        def visit_arg(self, node):
            node.arg = used.get(node.arg, node.arg)
            return node

        def visit_FunctionDef(self, node):
            node.name = used.get(node.name, node.name)
            return self.generic_visit(node)

        def visit_Global(self, node):
            node.names = [used.get(name, name) for name in node.names]
            return node

    transformed = ast.fix_missing_locations(Rename().visit(tree))
    source = ast.unparse(transformed) + '\n'
    return {'applied': True, 'renaming': used,
            'normalized_tokens': measurer.significant(source),
            'ast_nodes': sum(1 for _ in ast.walk(transformed)),
            'normalized_bytes': len(source.encode('utf-8'))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-directory', type=Path,
                        help='Optional directory containing the eleven original ZIPs; verifies all archived Python occurrences too.')
    parser.add_argument('candidates', nargs='*', type=Path,
                        help='Optional new source files to measure separately; no completeness classification is inferred.')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'reference/frontier_manifest.json').read_text())
    normalizer = checked_file(manifest['normalizer'])
    spec = importlib.util.spec_from_file_location('inherited_source_measure', normalizer)
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    for item in manifest['retained_provenance_files']:
        checked_file(item)

    rows = []
    for item in manifest['programs']:
        path = checked_file(item)
        metrics = measure.metrics(path)
        # The optional inherited 'core' submetric is deliberately discarded.
        metrics.pop('core', None)
        rows.append({'label': item['label'], 'status': item['status'],
                     'file': item['file'], **metrics})
    complete = [row for row in rows if row['status'] == 'complete']
    experiments = [row for row in rows if row['status'] != 'complete']
    if len(complete) != manifest['expected_complete_source_count']:
        raise ValueError('Complete-program inventory changed')
    if len(experiments) != manifest['expected_unvalidated_experiment_count']:
        raise ValueError('Experimental-program inventory changed')
    minima = {key: min(row[key] for row in complete) for key in KEYS}
    if minima != manifest['expected_coordinate_minima']:
        raise ValueError('Source frontier changed; check Python version and references: ' + repr(minima))
    attainers = {key: [row['label'] for row in complete if row[key] == minima[key]] for key in KEYS}
    pareto = [row['label'] for row in complete if not any(
        all(other[k] <= row[k] for k in KEYS) and any(other[k] < row[k] for k in KEYS)
        for other in complete)]
    controls = []
    for label in ('array_only', 'compact_unpack_open', 'structural_open', 'compact_open', 'complete_kernel'):
        row = next(row for row in complete if row['label'] == label)
        controls.append({'label': label, 'literal': {k: row[k] for k in KEYS},
                         'uniform_names': uniform_name_control(ROOT / row['file'], measure)})
    candidates = []
    for requested in args.candidates:
        path = requested if requested.is_absolute() else ROOT / requested
        metrics = measure.metrics(path)
        metrics.pop('core', None)
        candidates.append({'file': str(path), 'status': 'measurement_only_not_classified_complete',
                           **metrics, 'strictly_below_each_corpus_coordinate': all(metrics[k] < minima[k] for k in KEYS)})
    result = {
        'format': 'ipra-complete-checker-frontier-results-v1',
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'archive_count': manifest['archive_count'],
        'inventoried_python_sources': manifest['python_source_count'],
        'inventoried_python_member_occurrences': manifest['python_member_occurrence_count'],
        'complete_program_count': len(complete), 'unvalidated_experiment_count': len(experiments),
        'classification_scope': manifest['validation_scope'],
        'measurement_boundary': 'Entire source module, including imports, reader, scope and syntax validation, inference dispatch, errors, and verdict/exit driver. Only comments and true docstrings are removed before ast.unparse.',
        'checker_execution_performed': False,
        'normalizer_sha256': manifest['normalizer']['sha256'],
        'coordinate_minima': minima, 'minimum_attainers': attainers,
        'pareto_labels': pareto, 'complete_programs': complete,
        'unvalidated_full_interface_experiments': experiments,
        'excluded_source_status_counts': dict(collections.Counter(row['status'] for row in manifest['excluded_python_sources'])),
        'uniform_name_control': controls,
        'warning': 'These are achieved corpus minima, not a universal mathematical lower bound. Literal byte counts depend on identifier spelling. Complete-program status is inherited and distinguished from fragment or prototype status.',
        'candidates': candidates,
    }
    if args.source_directory:
        result['original_archive_verification'] = verify_archives(args.source_directory.resolve(), manifest)
    target = ROOT / 'evidence/frontier.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('python', 'complete_program_count', 'coordinate_minima', 'minimum_attainers', 'pareto_labels')}, indent=2))


if __name__ == '__main__':
    main()
