"""Supporting checker for the inherited atomic-transport admissibility proof.

This is NOT a complete iPRA checker and is not entered in size comparisons.
Its numerical functions are uninterpreted. Ordinary Hyp and Refl are explicitly
admitted conveniences: both are derived in the full native arithmetic calculus.
The primitive transport rule here permits equation motives only.
"""
from dataclasses import dataclass, field


class Rejected(ValueError):
    """A malformed or unjustified proof was rejected."""


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class App:
    name: str
    args: tuple = ()


@dataclass(frozen=True)
class Eq:
    left: object
    right: object


@dataclass(frozen=True)
class D:
    witness: str
    counter: str
    body: object


@dataclass(frozen=True)
class Clause:
    premise: object
    variable: str
    conclusion: object


@dataclass(frozen=True)
class Proof:
    rule: str
    conclusion: object
    children: tuple = ()
    data: dict = field(default_factory=dict)


ZERO = App("0")


def successor(term):
    return App("S", (term,))


def require(condition, message):
    if not condition:
        raise Rejected(message)


def valid_name(name):
    require(type(name) is str and bool(name), "invalid variable/symbol name")


def validate_term(term):
    if isinstance(term, Var):
        valid_name(term.name)
    elif isinstance(term, App):
        valid_name(term.name)
        require(type(term.args) is tuple, "application arguments must be a tuple")
        for arg in term.args:
            validate_term(arg)
    else:
        raise Rejected("not a numerical term")


def validate_formula(formula):
    if isinstance(formula, Eq):
        validate_term(formula.left)
        validate_term(formula.right)
    elif isinstance(formula, D):
        valid_name(formula.witness)
        valid_name(formula.counter)
        require(formula.witness != formula.counter, "paired binders must be distinct")
        validate_formula(formula.body)
    else:
        raise Rejected("not a native formula")


def term_names(term):
    if isinstance(term, Var):
        return {term.name}
    return set().union(*(term_names(a) for a in term.args))


def free_names(formula):
    if isinstance(formula, Eq):
        return term_names(formula.left) | term_names(formula.right)
    return free_names(formula.body) - {formula.witness, formula.counter}


def all_names(formula):
    if isinstance(formula, Eq):
        return term_names(formula.left) | term_names(formula.right)
    return all_names(formula.body) | {formula.witness, formula.counter}


def context_names(context, bound=False):
    out = set()
    names = all_names if bound else free_names
    for entry in context:
        if isinstance(entry, Clause):
            out |= names(entry.premise)
            out |= names(entry.conclusion) - (set() if bound else {entry.variable})
            if bound:
                out.add(entry.variable)
        else:
            out |= names(entry)
    return out


def fresh_name(used, prefix="_v"):
    index = 0
    while f"{prefix}{index}" in used:
        index += 1
    return f"{prefix}{index}"


def substitute_term(term, replacements):
    """Simultaneous substitution: never substitute inside inserted images."""
    if isinstance(term, Var):
        return replacements.get(term.name, term)
    return App(term.name, tuple(substitute_term(a, replacements) for a in term.args))


def substitute(formula, replacements):
    """Capture-avoiding simultaneous numerical substitution in a formula."""
    if isinstance(formula, Eq):
        return Eq(substitute_term(formula.left, replacements),
                  substitute_term(formula.right, replacements))
    x, y, body = formula.witness, formula.counter, formula.body
    remaining = {n: t for n, t in replacements.items() if n not in {x, y}}
    image_names = set().union(*(term_names(t) for t in remaining.values()))
    used = all_names(body) | image_names | set(remaining) | {x, y}
    renamed = []
    for name in (x, y):
        if name in image_names:
            new = fresh_name(used, "_bound")
            used.add(new)
            body = substitute(body, {name: Var(new)})
            renamed.append(new)
        else:
            renamed.append(name)
    return D(*renamed, substitute(body, remaining))


def _term_key(term, environment):
    if isinstance(term, Var):
        for distance, name in enumerate(reversed(environment)):
            if term.name == name:
                return ("bound", distance)
        return ("free", term.name)
    return ("app", term.name, tuple(_term_key(a, environment) for a in term.args))


def _formula_key(formula, environment=()):
    if isinstance(formula, Eq):
        return ("eq", _term_key(formula.left, environment),
                _term_key(formula.right, environment))
    return ("D", _formula_key(formula.body,
                             environment + (formula.witness, formula.counter)))


def alpha_equal(left, right):
    return _formula_key(left) == _formula_key(right)


def validate_context(context):
    require(type(context) is tuple, "context must be a tuple")
    for entry in context:
        if isinstance(entry, Clause):
            validate_formula(entry.premise)
            validate_formula(entry.conclusion)
            valid_name(entry.variable)
            require(entry.variable not in free_names(entry.premise),
                    "clause variable occurs in its premise")
        else:
            validate_formula(entry)


def check(proof, context=()):
    """Reconstruct every rule instance under the given reusable context."""
    validate_context(context)
    active = set()

    def visit(node, gamma):
        require(isinstance(node, Proof), "not a proof node")
        require(id(node) not in active, "cyclic proof")
        validate_formula(node.conclusion)
        require(type(node.children) is tuple and type(node.data) is dict,
                "malformed proof fields")
        active.add(id(node))
        try:
            rule, goal, data = node.rule, node.conclusion, node.data

            def shape(count, fields):
                require(len(node.children) == count and set(data) == set(fields),
                        "wrong proof arity or fields for " + rule)

            def child(index, local=gamma):
                return visit(node.children[index], local)

            def same(actual, expected, message):
                require(alpha_equal(actual, expected), message)

            def select():
                index = data["index"]
                require(type(index) is int and 0 <= index < len(gamma),
                        "context index out of range")
                return gamma[index]

            if rule == "hyp":
                shape(0, {"index"})
                item = select()
                require(not isinstance(item, Clause), "Hyp cannot use a clause")
                same(goal, item, "wrong assumption")
            elif rule == "refl":
                shape(0, set())
                require(isinstance(goal, Eq) and goal.left == goal.right,
                        "not reflexivity")
            elif rule == "transport":
                shape(2, {"variable", "motive"})
                valid_name(data["variable"])
                motive = data["motive"]
                validate_formula(motive)
                require(isinstance(motive, Eq), "compound transport is forbidden")
                equality = child(0)
                require(isinstance(equality, Eq), "transport major is not an equation")
                source = substitute(motive, {data["variable"]: equality.left})
                target = substitute(motive, {data["variable"]: equality.right})
                same(child(1), source, "transport minor is not the source instance")
                same(goal, target, "transport goal is not the target instance")
            elif rule == "use":
                shape(1, {"index", "term"})
                clause = select()
                require(isinstance(clause, Clause), "Use requires a clause")
                validate_term(data["term"])
                same(child(0), clause.premise, "unproved or wrong clause premise")
                same(goal, substitute(clause.conclusion,
                                      {clause.variable: data["term"]}),
                     "wrong clause specialization")
            elif rule == "DI":
                shape(1, {"witness", "eigen"})
                require(isinstance(goal, D), "DI goal is not paired")
                witness, z = data["witness"], data["eigen"]
                validate_term(witness)
                valid_name(z)
                # Strong name hygiene is harmless: alpha-renaming always supplies it.
                forbidden = context_names(gamma, True) | all_names(goal) | term_names(witness)
                require(z not in forbidden, "DI eigenvariable is not fresh")
                images = {goal.witness: witness, goal.counter: ZERO}
                base = substitute(goal.body, images)
                images[goal.counter] = Var(z)
                ih = substitute(goal.body, images)
                images[goal.counter] = successor(Var(z))
                step = substitute(goal.body, images)
                local = gamma + (base,) + ((ih,) if isinstance(goal.body, Eq) else ())
                same(child(0, local), step, "DI step has wrong conclusion")
            elif rule == "DE":
                shape(2, {"eigen"})
                major = child(0)
                require(isinstance(major, D), "DE major is not paired")
                a = data["eigen"]
                valid_name(a)
                forbidden = context_names(gamma, True) | all_names(goal) | all_names(major)
                require(a not in forbidden, "DE eigenvariable escapes or is not fresh")
                matrix = substitute(major.body, {major.witness: Var(a)})
                base = substitute(matrix, {major.counter: ZERO})
                clause = Clause(base, major.counter, matrix)
                validate_context((clause,))
                same(child(1, gamma + (clause,)), goal, "DE continuation has wrong conclusion")
            else:
                raise Rejected("unknown rule: " + str(rule))
            return goal
        finally:
            active.remove(id(node))

    return visit(proof, context)


def proof_statistics(proof):
    """Counts the unfolded finite proof tree, not shared Python object identities."""
    counts = {}

    def visit(node):
        counts[node.rule] = counts.get(node.rule, 0) + 1
        for child in node.children:
            visit(child)

    visit(proof)
    return {"nodes": sum(counts.values()), "rules": counts}
