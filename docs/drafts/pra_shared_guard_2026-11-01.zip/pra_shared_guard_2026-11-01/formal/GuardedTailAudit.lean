import Init

/-!
Independent constructive audit of the shared-root, shifted-tail reduction.

The proposed sentence is represented by `PrimaryAt`: separation outside all
quantifiers, followed by one SELECTED binary term instance with a common
zero exception for its equation, Reset, and shifted Tail. `FullySharedAt`
puts separation inside the implication; the two envelopes interconvert
once separation is known. `SharedAt` also moves Reset out of the exception.
Stored descriptor syntax and membership of the concrete selected terms
remain external obligations. No semantic induction schema is assumed.

The critical chain checked below is:
  reflexive extraction -> zero seed from guarded Reset alone
  -> guarded constant-one tail -> one seed -> full Reset
  -> selector values at tags zero and one ONLY -> predecessor calibration
  using successor nonzeroness derived LOCALLY from its induction hypothesis
  -> global successor nonzeroness -> the old unguarded delayed tail.

No global successor case of the selector, equality decision, coverage, or
unrestricted tail is assumed during predecessor calibration. All theorems
are intuitionistic and all printed axiom dependency lists are empty.

This is not a mechanization of the complete first-order bi-interpretation.
-/

universe u
namespace GuardedTailAudit
variable {A : Type u}

def Progress (zero : A) (succ : A → A) (term : A → A → A) (a : A) : Prop :=
  ∀ n, (n = zero ∨ term n a = term n (succ a)) →
    term (succ n) a = term (succ n) (succ a)

def SharedAt (zero : A) (succ : A → A) (term : A → A → A)
    (sep : Prop) (reset tail : A → A → Prop) : Prop :=
  ∀ a, Progress zero succ term a →
    ∀ n, sep ∧ reset n a ∧
      (n = zero ∨ (term n a = term n (succ a) ∧ tail n a))

def FullySharedAt (zero : A) (succ : A → A) (term : A → A → A)
    (sep : Prop) (reset tail : A → A → Prop) : Prop :=
  ∀ a, Progress zero succ term a →
    ∀ n, sep ∧
      (n = zero ∨ (term n a = term n (succ a) ∧ reset n a ∧ tail n a))

def PrimaryAt (zero : A) (succ : A → A) (term : A → A → A)
    (sep : Prop) (reset tail : A → A → Prop) : Prop :=
  sep ∧ ∀ a, Progress zero succ term a →
    ∀ n, n = zero ∨ (term n a = term n (succ a) ∧ reset n a ∧ tail n a)

theorem primary_to_fully_shared (zero : A) (succ : A → A)
    (term : A → A → A) (sep : Prop) (reset tail : A → A → Prop)
    (selected : PrimaryAt zero succ term sep reset tail) :
    FullySharedAt zero succ term sep reset tail := by
  intro a progress n
  exact ⟨selected.1, selected.2 a progress n⟩

theorem fully_shared_to_primary (zero : A) (succ : A → A)
    (term : A → A → A) (sep : Prop) (reset tail : A → A → Prop)
    (separation : sep)
    (selected : FullySharedAt zero succ term sep reset tail) :
    PrimaryAt zero succ term sep reset tail := by
  refine ⟨separation, ?_⟩
  intro a progress n
  exact (selected a progress n).2

def ShortAt (zero : A) (succ : A → A) (E : A → A → Prop) : Prop :=
  ∀ a, (∀ n, (n = zero ∨ E n a) → E (succ n) a) →
    ∀ n, n = zero ∨ E n a

theorem computation_extract (zero : A) (succ : A → A) (h : A → A)
    (sep : Prop) (reset tail : A → A → Prop)
    (selected : SharedAt zero succ (fun n _ => h n) sep reset tail) :
    ∀ a n, sep ∧ reset n a ∧ (n = zero ∨ tail n a) := by
  intro a n
  have result := selected a (fun _ _ => rfl) n
  refine ⟨result.1, result.2.1, ?_⟩
  cases result.2.2 with
  | inl hz => exact Or.inl hz
  | inr ht => exact Or.inr ht.2

theorem fully_shared_computation_extract (zero : A) (succ : A → A)
    (h : A → A) (sep : Prop) (reset tail : A → A → Prop)
    (selected : FullySharedAt zero succ (fun n _ => h n) sep reset tail) :
    ∀ a n, sep ∧ (n = zero ∨ (reset n a ∧ tail n a)) := by
  intro a n
  have result := selected a (fun _ _ => rfl) n
  refine ⟨result.1, ?_⟩
  cases result.2 with
  | inl hz => exact Or.inl hz
  | inr ht => exact Or.inr ht.2

theorem shared_to_fully_shared (zero : A) (succ : A → A)
    (term : A → A → A) (sep : Prop) (reset tail : A → A → Prop)
    (selected : SharedAt zero succ term sep reset tail) :
    FullySharedAt zero succ term sep reset tail := by
  intro a progress n
  have result := selected a progress n
  refine ⟨result.1, ?_⟩
  cases result.2.2 with
  | inl hz => exact Or.inl hz
  | inr ht => exact Or.inr ⟨ht.1, result.2.1, ht.2⟩

theorem fully_shared_to_shared (zero : A) (succ : A → A)
    (term : A → A → A) (sep : Prop) (reset tail : A → A → Prop)
    (selected : FullySharedAt zero succ term sep reset tail)
    (unconditionalReset : ∀ n a, reset n a) :
    SharedAt zero succ term sep reset tail := by
  intro a progress n
  have result := selected a progress n
  refine ⟨result.1, unconditionalReset n a, ?_⟩
  cases result.2 with
  | inl hz => exact Or.inl hz
  | inr ht => exact Or.inr ⟨ht.1, ht.2.2⟩

theorem propagation_project (zero : A) (succ : A → A)
    (term : A → A → A) (sep : Prop) (reset tail : A → A → Prop)
    (selected : SharedAt zero succ term sep reset tail) :
    ShortAt zero succ (fun n a => term n a = term n (succ a)) := by
  intro a progress n
  cases (selected a progress n).2.2 with
  | inl hz => exact Or.inl hz
  | inr ht => exact Or.inr ht.1

theorem guarded_unlock (zero : A) (succ : A → A) (d : A → A → A)
    (h : A → A)
    (guard : ∀ n a, n = zero ∨ d (succ n) a = h (d n a))
    (n a : A) (nonzero : n ≠ zero) :
    d (succ n) a = h (d n a) := by
  cases guard n a with
  | inl hz => exact False.elim (nonzero hz)
  | inr ht => exact ht

theorem delayed_seeds (zero : A) (succ : A → A) (d q : A → A → A)
    (sep : zero ≠ succ zero)
    (resetD : ∀ n a, d (q n zero) a = a)
    (resetQ : ∀ n a, q (q n zero) a = a)
    (guardQ : ∀ n a, n = zero ∨ q (succ n) a = succ zero) :
    (∀ a, d zero a = a) ∧ (∀ a, d (succ zero) a = a) := by
  have oneNonzero : succ zero ≠ zero := fun hz => sep hz.symm
  have qTwo : q (succ (succ zero)) zero = succ zero := by
    cases guardQ (succ zero) zero with
    | inl hz => exact False.elim (oneNonzero hz)
    | inr ht => exact ht
  have seedOne : ∀ a, d (succ zero) a = a := by
    intro a
    have result := resetD (succ (succ zero)) a
    rw [qTwo] at result
    exact result
  have qOne : q (succ zero) zero = zero := by
    have result := resetQ (succ (succ zero)) zero
    rw [qTwo] at result
    exact result
  have seedZero : ∀ a, d zero a = a := by
    intro a
    have result := resetD (succ zero) a
    rw [qOne] at result
    exact result
  exact ⟨seedZero, seedOne⟩

theorem zero_seed_from_guarded_reset (zero : A) (succ : A → A)
    (d q : A → A → A) (sep : zero ≠ succ zero)
    (resetD : ∀ n a, n = zero ∨ d (q n zero) a = a)
    (resetQ : ∀ n a, n = zero ∨ q (q n zero) a = a) :
    ∀ a, d zero a = a := by
  have oneNonzero : succ zero ≠ zero := fun hz => sep hz.symm
  have atR : ∀ a, d (q (succ zero) zero) a = a := by
    intro a
    cases resetD (succ zero) a with
    | inl hz => exact False.elim (oneNonzero hz)
    | inr hr => exact hr
  have qAtR : q (q (succ zero) zero) zero = zero := by
    cases resetQ (succ zero) zero with
    | inl hz => exact False.elim (oneNonzero hz)
    | inr hr => exact hr
  intro a
  cases resetD (q (succ zero) zero) a with
  | inl rZero =>
    have result := atR a
    rw [rZero] at result
    exact result
  | inr hr =>
    rw [qAtR] at hr
    exact hr

theorem fully_guarded_delayed_seeds (zero : A) (succ : A → A)
    (d q : A → A → A) (sep : zero ≠ succ zero)
    (resetD : ∀ n a, n = zero ∨ d (q n zero) a = a)
    (resetQ : ∀ n a, n = zero ∨ q (q n zero) a = a)
    (guardQ : ∀ n a, n = zero ∨ q (succ n) a = succ zero) :
    (∀ a, d zero a = a) ∧ (∀ a, d (succ zero) a = a) := by
  have seedZero := zero_seed_from_guarded_reset zero succ d q sep resetD resetQ
  have qSeedZero := zero_seed_from_guarded_reset zero succ q q sep resetQ resetQ
  have oneNonzero : succ zero ≠ zero := fun hz => sep hz.symm
  have qTwo : q (succ (succ zero)) zero = succ zero := by
    cases guardQ (succ zero) zero with
    | inl hz => exact False.elim (oneNonzero hz)
    | inr ht => exact ht
  have twoNonzero : succ (succ zero) ≠ zero := by
    intro twoZero
    have oneZero : succ zero = zero := calc
      succ zero = q (succ (succ zero)) zero := qTwo.symm
      _ = q zero zero := congrArg (fun n => q n zero) twoZero
      _ = zero := qSeedZero zero
    exact sep oneZero.symm
  have seedOne : ∀ a, d (succ zero) a = a := by
    intro a
    cases resetD (succ (succ zero)) a with
    | inl hz => exact False.elim (twoNonzero hz)
    | inr hr =>
      rw [qTwo] at hr
      exact hr
  exact ⟨seedZero, seedOne⟩

theorem recover_unguarded_reset (zero : A) (d q : A → A → A)
    (dZero : ∀ a, d zero a = a) (qZero : q zero zero = zero)
    (guardReset : ∀ n a, n = zero ∨ d (q n zero) a = a) :
    ∀ n a, d (q n zero) a = a := by
  intro n a
  cases guardReset n a with
  | inl hz =>
    rw [hz, qZero]
    exact dZero a
  | inr hr => exact hr

def ZeroGate (succ : A → A) (dZeroBody : A → A → A) (r b : A) : A :=
  dZeroBody (succ r) b

theorem gate_at_zero_and_one (zero : A) (succ : A → A)
    (dZeroBody : A → A → A)
    (sep : zero ≠ succ zero)
    (oneSeed : ∀ b, dZeroBody (succ zero) b = b)
    (guardZero : ∀ n b, n = zero ∨ dZeroBody (succ n) b = zero) :
    (∀ b, ZeroGate succ dZeroBody zero b = b) ∧
      (∀ b, ZeroGate succ dZeroBody (succ zero) b = zero) := by
  constructor
  · exact oneSeed
  · intro b
    cases guardZero (succ zero) b with
    | inl hz => exact False.elim (sep hz.symm)
    | inr ht => exact ht

def Select (succ : A → A) (d Z : A → A → A) (one tag left right : A) : A :=
  d (Z tag (succ left)) (Z (Z tag one) right)

theorem selector_zero_before (zero : A) (succ : A → A)
    (d Z : A → A → A)
    (ZZero : ∀ b, Z zero b = b)
    (ZOne : ∀ b, Z (succ zero) b = zero) (b c : A) :
    Select succ d Z (succ zero) zero b c = d (succ b) zero := by
  unfold Select
  rw [ZZero, ZZero, ZOne]

theorem selector_one_before (zero : A) (succ : A → A)
    (d Z : A → A → A)
    (dZero : ∀ b, d zero b = b)
    (ZZero : ∀ b, Z zero b = b)
    (ZOne : ∀ b, Z (succ zero) b = zero) (b c : A) :
    Select succ d Z (succ zero) (succ zero) b c = c := by
  unfold Select
  rw [ZOne, ZOne, ZZero, dZero]

theorem successor_nonzero_from_local_fixed (zero : A) (succ : A → A)
    (d : A → A → A) (sep : zero ≠ succ zero)
    (dZero : ∀ b, d zero b = b)
    (n : A) (fixed : d (succ n) zero = n) : succ n ≠ zero := by
  intro bad
  have nZero : n = zero := calc
    n = d (succ n) zero := fixed.symm
    _ = d zero zero := congrArg (fun x => d x zero) bad
    _ = zero := dZero zero
  have oneZero : succ zero = zero := calc
    succ zero = succ n := congrArg succ nZero.symm
    _ = zero := bad
  exact sep oneZero.symm

theorem propagation_transfer_at (zero : A) (succ : A → A)
    (term : A → A → A) (f g : A → A) (a : A)
    (left : ∀ n, term n a = f n)
    (right : ∀ n, term n (succ a) = g n)
    (selected : ShortAt zero succ (fun n a => term n a = term n (succ a))) :
    (∀ n, (n = zero ∨ f n = g n) → f (succ n) = g (succ n)) →
      ∀ n, n = zero ∨ f n = g n := by
  intro progress n
  have endpoints (k : A) : (term k a = term k (succ a)) ↔ (f k = g k) := by
    rw [left k, right k]
  have transferred : ∀ k, (k = zero ∨ term k a = term k (succ a)) →
      term (succ k) a = term (succ k) (succ a) := by
    intro k premise
    apply (endpoints (succ k)).mpr
    apply progress k
    cases premise with
    | inl hz => exact Or.inl hz
    | inr he => exact Or.inr ((endpoints k).mp he)
  cases selected a transferred n with
  | inl hz => exact Or.inl hz
  | inr he => exact Or.inr ((endpoints n).mp he)

theorem equation_induction_at (zero : A) (succ : A → A) (f g : A → A)
    (selected :
      (∀ n, (n = zero ∨ f n = g n) → f (succ n) = g (succ n)) →
      ∀ n, n = zero ∨ f n = g n) :
    f zero = g zero → (∀ n, f n = g n → f (succ n) = g (succ n)) →
      ∀ n, f n = g n := by
  intro base step n
  have progress : ∀ k, (k = zero ∨ f k = g k) → f (succ k) = g (succ k) := by
    intro k premise
    cases premise with
    | inl hz => exact step k (hz ▸ base)
    | inr he => exact step k he
  cases selected progress n with
  | inl hz => exact hz ▸ base
  | inr he => exact he

theorem predecessor_recovery (zero : A) (succ : A → A)
    (d Z : A → A → A) (sep : zero ≠ succ zero)
    (dZero : ∀ b, d zero b = b)
    (dOne : ∀ b, d (succ zero) b = b)
    (guardS : ∀ n b, n = zero ∨ d (succ n) b = succ (d n b))
    (ZZero : ∀ b, Z zero b = b)
    (ZOne : ∀ b, Z (succ zero) b = zero)
    (reset tail : A → A → Prop)
    (selected : SharedAt zero succ
      (fun n a => Select succ d Z (succ zero) a n n)
      (zero ≠ succ zero) reset tail) :
    ∀ n, d (succ n) zero = n := by
  have projected := propagation_project zero succ
    (fun n a => Select succ d Z (succ zero) a n n)
    (zero ≠ succ zero) reset tail selected
  have transferred := propagation_transfer_at zero succ
    (fun n a => Select succ d Z (succ zero) a n n)
    (fun n => d (succ n) zero) (fun n => n) zero
    (fun n => selector_zero_before zero succ d Z ZZero ZOne n n)
    (fun n => selector_one_before zero succ d Z dZero ZZero ZOne n n)
    projected
  have base : d (succ zero) zero = zero := dOne zero
  have step : ∀ n, d (succ n) zero = n →
      d (succ (succ n)) zero = succ n := by
    intro n fixed
    have nonzero := successor_nonzero_from_local_fixed zero succ d sep dZero n fixed
    have equation := guarded_unlock zero succ d succ guardS (succ n) zero nonzero
    exact equation.trans (congrArg succ fixed)
  exact equation_induction_at zero succ (fun n => d (succ n) zero)
    (fun n => n) transferred base step

theorem successor_nonzero (zero : A) (succ : A → A) (d : A → A → A)
    (sep : zero ≠ succ zero) (dZero : ∀ b, d zero b = b)
    (predSucc : ∀ n, d (succ n) zero = n) : ∀ n, succ n ≠ zero := by
  intro n
  exact successor_nonzero_from_local_fixed zero succ d sep dZero n (predSucc n)

theorem successor_injective (zero : A) (succ : A → A) (d : A → A → A)
    (predSucc : ∀ n, d (succ n) zero = n) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y same
  have result := congrArg (fun z => d z zero) same
  change d (succ x) zero = d (succ y) zero at result
  rw [predSucc, predSucc] at result
  exact result

theorem recover_delayed_tail (zero : A) (succ : A → A)
    (d : A → A → A) (h : A → A)
    (guard : ∀ n a, n = zero ∨ d (succ n) a = h (d n a))
    (successorNonzero : ∀ n, succ n ≠ zero) :
    ∀ n a, d (succ (succ n)) a = h (d (succ n) a) := by
  intro n a
  exact guarded_unlock zero succ d h guard (succ n) a (successorNonzero n)

def OldAt (zero : A) (succ : A → A) (term : A → A → A)
    (sep : Prop) (reset oldTail : A → A → Prop) : Prop :=
  ∀ a, Progress zero succ term a → ∀ n,
    (n = zero ∨ term n a = term n (succ a)) ∧ sep ∧ reset n a ∧ oldTail n a

theorem shared_to_old (zero : A) (succ : A → A) (term : A → A → A)
    (sep : Prop) (reset tail oldTail : A → A → Prop)
    (selected : SharedAt zero succ term sep reset tail)
    (unconditionalTail : ∀ n a, oldTail n a) :
    OldAt zero succ term sep reset oldTail := by
  intro a progress n
  have result := selected a progress n
  refine ⟨?_, result.1, result.2.1, unconditionalTail n a⟩
  cases result.2.2 with
  | inl hz => exact Or.inl hz
  | inr ht => exact Or.inr ht.1

theorem old_to_shared (zero : A) (succ pred : A → A)
    (term d : A → A → A) (h : A → A) (sep : Prop)
    (reset : A → A → Prop)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (selected : OldAt zero succ term sep reset
      (fun n a => d (succ (succ n)) a = h (d (succ n) a))) :
    SharedAt zero succ term sep reset
      (fun n a => d (succ n) a = h (d n a)) := by
  intro a progress n
  have result := selected a progress n
  refine ⟨result.2.1, result.2.2.1, ?_⟩
  cases result.1 with
  | inl hz => exact Or.inl hz
  | inr he =>
    cases coverage n with
    | inl hz => exact Or.inl hz
    | inr hs =>
      apply Or.inr
      refine ⟨he, ?_⟩
      have shifted := (selected a progress (pred n)).2.2.2
      change d (succ (succ (pred n))) a = h (d (succ (pred n)) a) at shifted
      rw [← hs] at shifted
      exact shifted

#print axioms primary_to_fully_shared
#print axioms fully_shared_to_primary
#print axioms computation_extract
#print axioms fully_shared_computation_extract
#print axioms shared_to_fully_shared
#print axioms fully_shared_to_shared
#print axioms propagation_project
#print axioms guarded_unlock
#print axioms delayed_seeds
#print axioms zero_seed_from_guarded_reset
#print axioms fully_guarded_delayed_seeds
#print axioms recover_unguarded_reset
#print axioms gate_at_zero_and_one
#print axioms selector_zero_before
#print axioms selector_one_before
#print axioms successor_nonzero_from_local_fixed
#print axioms propagation_transfer_at
#print axioms equation_induction_at
#print axioms predecessor_recovery
#print axioms successor_nonzero
#print axioms successor_injective
#print axioms recover_delayed_tail
#print axioms shared_to_old
#print axioms old_to_shared

end GuardedTailAudit
