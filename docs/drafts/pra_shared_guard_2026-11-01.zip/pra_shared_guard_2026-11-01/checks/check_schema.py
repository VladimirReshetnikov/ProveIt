#!/usr/bin/env python3
"""Finite syntax checks for the shared-root-guard PRA axiom schema.

This program checks syntax, substitution, and exact tree-node counts. It is
not a proof assistant and does not verify the mathematical equivalence proof.
It has no external dependencies. Run with Python 3.10 or newer:

    python3 checks/check_schema.py

Results are written next to this script as schema_checks.json and
generated_examples.txt. Descriptor bodies are frozen syntax, not arguments.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Union


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    argument: Term


@dataclass(frozen=True)
class Descriptor:
    body: Term


@dataclass(frozen=True)
class Delay:
    descriptor: Descriptor
    counter: Term
    seed: Term


Term = Union[Var, Zero, Succ, Delay]


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bottom:
    pass


@dataclass(frozen=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Or:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Implies:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Forall:
    variable: str
    body: Formula


Formula = Union[Eq, Bottom, And, Or, Implies, Forall]
ZERO = Zero()
N = Var("n")
A = Var("a")
V = Var("v")
ONE = Succ(ZERO)
Q = Descriptor(ONE)


def active_free_variables(term: Term) -> frozenset[str]:
    """Stored bodies contribute no active free variables to a Delay term."""
    if isinstance(term, Var):
        return frozenset((term.name,))
    if isinstance(term, Zero):
        return frozenset()
    if isinstance(term, Succ):
        return active_free_variables(term.argument)
    if isinstance(term, Delay):
        return active_free_variables(term.counter) | active_free_variables(term.seed)
    raise TypeError(type(term))


def substitute(term: Term, replacements: Mapping[str, Term]) -> Term:
    """Simultaneous active substitution; never descend into a descriptor."""
    if isinstance(term, Var):
        return replacements.get(term.name, term)
    if isinstance(term, Zero):
        return term
    if isinstance(term, Succ):
        return Succ(substitute(term.argument, replacements))
    if isinstance(term, Delay):
        return Delay(
            term.descriptor,
            substitute(term.counter, replacements),
            substitute(term.seed, replacements),
        )
    raise TypeError(type(term))


def term_size(term: Term, include_descriptors: bool = False) -> int:
    if isinstance(term, (Var, Zero)):
        return 1
    if isinstance(term, Succ):
        return 1 + term_size(term.argument, include_descriptors)
    if isinstance(term, Delay):
        total = 1 + term_size(term.counter, include_descriptors)
        total += term_size(term.seed, include_descriptors)
        if include_descriptors:
            total += term_size(term.descriptor.body, True)
        return total
    raise TypeError(type(term))


def occurrences(term: Term, variable: str) -> int:
    if isinstance(term, Var):
        return int(term.name == variable)
    if isinstance(term, Zero):
        return 0
    if isinstance(term, Succ):
        return occurrences(term.argument, variable)
    if isinstance(term, Delay):
        return occurrences(term.counter, variable) + occurrences(term.seed, variable)
    raise TypeError(type(term))


def dependency_rank(term: Term) -> int:
    """Initial language has rank zero; each D_h lies above its body."""
    if isinstance(term, (Var, Zero)):
        return 0
    if isinstance(term, Succ):
        return dependency_rank(term.argument)
    if isinstance(term, Delay):
        return max(
            1 + dependency_rank(term.descriptor.body),
            dependency_rank(term.counter),
            dependency_rank(term.seed),
        )
    raise TypeError(type(term))


def validate_term(term: Term) -> None:
    """Reject an illegal frozen parameter; recurse through the finite tree."""
    if isinstance(term, (Var, Zero)):
        return
    if isinstance(term, Succ):
        validate_term(term.argument)
        return
    if isinstance(term, Delay):
        if not active_free_variables(term.descriptor.body) <= frozenset(("v",)):
            raise ValueError("A descriptor body has an external active variable")
        validate_term(term.descriptor.body)
        validate_term(term.counter)
        validate_term(term.seed)
        return
    raise TypeError(type(term))


def formula_size(formula: Formula, include_descriptors: bool = False) -> int:
    if isinstance(formula, Eq):
        return 1 + term_size(formula.left, include_descriptors) + term_size(
            formula.right, include_descriptors
        )
    if isinstance(formula, Bottom):
        return 1
    if isinstance(formula, (And, Or, Implies)):
        return 1 + formula_size(formula.left, include_descriptors) + formula_size(
            formula.right, include_descriptors
        )
    if isinstance(formula, Forall):
        return 1 + formula_size(formula.body, include_descriptors)
    raise TypeError(type(formula))


def formula_free_variables(formula: Formula) -> frozenset[str]:
    if isinstance(formula, Eq):
        return active_free_variables(formula.left) | active_free_variables(formula.right)
    if isinstance(formula, Bottom):
        return frozenset()
    if isinstance(formula, (And, Or, Implies)):
        return formula_free_variables(formula.left) | formula_free_variables(formula.right)
    if isinstance(formula, Forall):
        return formula_free_variables(formula.body) - frozenset((formula.variable,))
    raise TypeError(type(formula))


def variable_names(formula: Formula) -> frozenset[str]:
    """All active variable names, including names bound by quantifiers."""
    if isinstance(formula, Eq):
        return active_free_variables(formula.left) | active_free_variables(formula.right)
    if isinstance(formula, Bottom):
        return frozenset()
    if isinstance(formula, (And, Or, Implies)):
        return variable_names(formula.left) | variable_names(formula.right)
    if isinstance(formula, Forall):
        return variable_names(formula.body) | frozenset((formula.variable,))
    raise TypeError(type(formula))


def quantifier_profile(formula: Formula) -> tuple[int, int]:
    if isinstance(formula, (Eq, Bottom)):
        return (0, 0)
    if isinstance(formula, (And, Or, Implies)):
        left_count, left_depth = quantifier_profile(formula.left)
        right_count, right_depth = quantifier_profile(formula.right)
        return (left_count + right_count, max(left_depth, right_depth))
    if isinstance(formula, Forall):
        count, depth = quantifier_profile(formula.body)
        return (count + 1, depth + 1)
    raise TypeError(type(formula))


def validate_formula(formula: Formula) -> None:
    if isinstance(formula, Eq):
        validate_term(formula.left)
        validate_term(formula.right)
    elif isinstance(formula, (And, Or, Implies)):
        validate_formula(formula.left)
        validate_formula(formula.right)
    elif isinstance(formula, Forall):
        validate_formula(formula.body)
    elif not isinstance(formula, Bottom):
        raise TypeError(type(formula))


def endpoint(u: Term, counter: Term, parameter: Term) -> Formula:
    return Eq(
        substitute(u, {"n": counter, "a": parameter}),
        substitute(u, {"n": counter, "a": Succ(parameter)}),
    )


def generate_schemas(u: Term) -> tuple[Formula, Formula]:
    """Return the exact old adjacent schema and the new fully guarded schema."""
    validate_term(u)
    if not active_free_variables(u) <= frozenset(("n", "a")):
        raise ValueError("Input terms have only the active slots n and a")
    h = Descriptor(substitute(u, {"n": V, "a": ZERO}))
    e = endpoint(u, N, A)
    p = Or(Eq(N, ZERO), e)
    progress = Forall("n", Implies(p, endpoint(u, Succ(N), A)))
    separation = Implies(Eq(ZERO, ONE), Bottom())
    reset = Eq(Delay(h, Delay(Q, N, ZERO), A), A)
    old_tail = Eq(
        Delay(h, Succ(Succ(N)), A),
        substitute(h.body, {"v": Delay(h, Succ(N), A)}),
    )
    old = Forall(
        "a",
        Implies(progress, Forall("n", And(p, And(separation, And(reset, old_tail))))),
    )
    shifted_tail = Eq(
        Delay(h, Succ(N), A),
        substitute(h.body, {"v": Delay(h, N, A)}),
    )
    guarded = Or(Eq(N, ZERO), And(e, And(reset, shifted_tail)))
    new = And(separation, Forall("a", Implies(progress, Forall("n", guarded))))
    return old, new


def show_term(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return "S(" + show_term(term.argument) + ")"
    if isinstance(term, Delay):
        return (
            "D{" + show_term(term.descriptor.body) + "}("
            + show_term(term.counter) + "," + show_term(term.seed) + ")"
        )
    raise TypeError(type(term))


def show_formula(formula: Formula) -> str:
    if isinstance(formula, Eq):
        return "(" + show_term(formula.left) + " = " + show_term(formula.right) + ")"
    if isinstance(formula, Bottom):
        return "false"
    if isinstance(formula, Forall):
        return "(forall " + formula.variable + ". " + show_formula(formula.body) + ")"
    operators = {And: " & ", Or: " | ", Implies: " -> "}
    for kind, operator in operators.items():
        if isinstance(formula, kind):
            return "(" + show_formula(formula.left) + operator + show_formula(formula.right) + ")"
    raise TypeError(type(formula))


def corpus() -> list[Term]:
    """A deterministic structural corpus, including frozen nested descriptors."""
    ident = Descriptor(V)
    successor = Descriptor(Succ(V))
    constant = Descriptor(ZERO)
    nested = Descriptor(Delay(successor, V, ZERO))
    double_use = Descriptor(Delay(nested, V, Succ(V)))
    descriptors = (ident, successor, constant, Q, nested, double_use)
    atoms = (ZERO, N, A, ONE)
    terms: set[Term] = set(atoms)
    terms.update(Succ(term) for term in atoms)
    terms.update(Delay(desc, left, right) for desc in descriptors for left in atoms for right in atoms)
    first_layer = sorted(terms, key=show_term)
    terms.update(Succ(term) for term in first_layer)
    # Independently vary both argument positions without an exponential tree blowup.
    for desc in descriptors:
        for term in first_layer:
            for atom in atoms:
                terms.add(Delay(desc, term, atom))
                terms.add(Delay(desc, atom, term))
    # Repeated active variables and nested descriptors exercise the occurrence formula.
    terms.add(Delay(double_use, Delay(ident, N, A), Delay(nested, A, N)))
    terms.add(Delay(double_use, Delay(ident, N, N), Delay(nested, N, N)))
    terms.add(Delay(nested, Delay(constant, A, A), Delay(ident, A, A)))
    return sorted(terms, key=show_term)


def check_substitution_boundaries() -> dict[str, bool]:
    ident = Descriptor(V)
    successor = Descriptor(Succ(V))
    raw = Delay(successor, N, A)
    changed = substitute(raw, {"n": A, "a": ZERO, "v": ONE})
    assert changed == Delay(successor, A, ZERO), "Substitution was not simultaneous"
    assert isinstance(changed, Delay) and changed.descriptor is successor
    assert changed.descriptor.body == Succ(V), "A frozen body was modified"
    # A descriptor may contain v even when the external substitution replaces v.
    nested = Descriptor(Delay(ident, V, ZERO))
    outer = Delay(nested, V, N)
    replaced = substitute(outer, {"v": ONE, "n": ZERO})
    assert replaced == Delay(nested, ONE, ZERO)
    assert isinstance(replaced, Delay) and replaced.descriptor is nested
    assert active_free_variables(replaced) == frozenset()
    assert dependency_rank(Delay(nested, N, A)) == 2
    try:
        validate_term(Delay(Descriptor(A), N, A))
    except ValueError:
        pass
    else:
        raise AssertionError("Illegal frozen external parameter was accepted")
    try:
        generate_schemas(Var("b"))
    except ValueError:
        pass
    else:
        raise AssertionError("A third active input slot was accepted")
    return {
        "simultaneous_substitution": True,
        "frozen_descriptor_identity": True,
        "nested_frozen_descriptor": True,
        "dependency_rank": True,
        "rejects_external_descriptor_parameter": True,
        "rejects_third_input_slot": True,
    }


def main() -> None:
    boundary_checks = check_substitution_boundaries()
    terms = corpus()
    max_rank = 0
    min_saving: int | None = None
    max_saving = 0
    zero_n_count = 0
    nested_count = 0
    corpus_digest = hashlib.sha256()
    successor = Descriptor(Succ(V))
    example_terms = (ZERO, N, A, Succ(N), Delay(successor, N, A), Delay(successor, N, N))
    examples = []
    rendered_examples = [
        "Syntax verification only; these generated formulas are not semantic proofs.",
        "D{h}(n,a) stores the body h frozen in the function-symbol label.",
        "Each quantifier occurrence and connective counts one node; binder names do not.",
        "",
    ]
    for u in terms:
        old, new = generate_schemas(u)
        validate_formula(old)
        validate_formula(new)
        size = term_size(u)
        n_count = occurrences(u, "n")
        a_count = occurrences(u, "a")
        old_size = formula_size(old)
        new_size = formula_size(new)
        assert old_size == 38 + 7 * size + 5 * n_count + 3 * a_count
        assert new_size == 37 + 7 * size + 4 * n_count + 3 * a_count
        saving = old_size - new_size
        assert saving == 1 + n_count
        assert formula_size(old, True) - formula_size(new, True) == saving
        for formula in (old, new):
            assert formula_free_variables(formula) == frozenset()
            assert variable_names(formula) == frozenset(("n", "a"))
            assert quantifier_profile(formula) == (3, 2)
        h_body = substitute(u, {"n": V, "a": ZERO})
        assert active_free_variables(h_body) <= frozenset(("v",))
        assert dependency_rank(h_body) <= dependency_rank(u)
        assert dependency_rank(Delay(Descriptor(h_body), N, A)) == 1 + dependency_rank(h_body)
        max_rank = max(max_rank, dependency_rank(u))
        min_saving = saving if min_saving is None else min(min_saving, saving)
        max_saving = max(max_saving, saving)
        zero_n_count += int(n_count == 0)
        nested_count += int(dependency_rank(u) >= 2)
        corpus_digest.update((show_term(u) + "\n").encode("utf-8"))
        if u in example_terms:
            row = {
                "input": show_term(u), "input_active_size": size,
                "n_occurrences": n_count, "a_occurrences": a_count,
                "old_nodes": old_size, "new_nodes": new_size, "saving": saving,
                "old_descriptor_inclusive_nodes": formula_size(old, True),
                "new_descriptor_inclusive_nodes": formula_size(new, True),
            }
            examples.append(row)
            rendered_examples.extend([
                "INPUT: " + show_term(u),
                "OLD: " + show_formula(old),
                "NEW: " + show_formula(new),
                "COUNTS: " + json.dumps(row, sort_keys=True),
                "",
            ])
    report = {
        "status": "passed",
        "scope": "Finite syntax, substitution, and exact node-count checks; not logical proof verification.",
        "inputs_checked": len(terms),
        "inputs_ignoring_n": zero_n_count,
        "inputs_with_nested_descriptors": nested_count,
        "max_input_dependency_rank": max_rank,
        "corpus_sha256": corpus_digest.hexdigest(),
        "old_active_size_formula": "38 + 7*|u| + 5*nu_n(u) + 3*nu_a(u)",
        "new_active_size_formula": "37 + 7*|u| + 4*nu_n(u) + 3*nu_a(u)",
        "saving_formula_both_conventions": "1 + nu_n(u)",
        "minimum_observed_saving": min_saving,
        "maximum_observed_saving": max_saving,
        "active_variable_names": ["a", "n"],
        "quantifier_occurrences": 3,
        "maximum_quantifier_depth": 2,
        "maximum_primitive_function_arity": 2,
        "substitution_boundary_checks": boundary_checks,
        "examples": sorted(examples, key=lambda row: row["input"]),
    }
    destination = Path(__file__).resolve().parent
    (destination / "schema_checks.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    (destination / "generated_examples.txt").write_text("\n".join(rendered_examples), encoding="utf-8")
    print(json.dumps({"status": report["status"], "inputs_checked": len(terms),
                      "minimum_saving": min_saving, "maximum_saving": max_saving,
                      "report": str(destination / "schema_checks.json")}, indent=2))


if __name__ == "__main__":
    main()

