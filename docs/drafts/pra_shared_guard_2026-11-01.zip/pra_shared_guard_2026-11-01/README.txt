A SHARED ZERO GUARD FOR PRIMITIVE RECURSIVE ARITHMETIC
Research note prepared for Vladimir Reshetnikov
November 1, 2026

RESULT

A strictly shorter single axiom schema in exactly the language of the
best common structural baseline among the five current ProveIt PRA drafts.
The same schema works with classical or intuitionistic first-order logic.
The report proves a common conservative definitional extension with the
corresponding first-order PRA, hence bi-interpretability and equiconsistency.

The change places the propagated equation, Reset, and a shifted recurrence
under one existing zero-case disjunction. For every binary input term u,
the fully expanded instance is shorter by exactly 1 + occ_n(u) nodes.
The saving holds both with atomic descriptor labels and when descriptor
trees are charged recursively. No extra symbol or input slot is introduced.

This is a uniform local improvement, not a global minimality theorem.

START HERE

  report.pdf                    Complete mathematical article
  report.tex                    Self-contained LaTeX source
  formal/GuardedTailAudit.lean   Lean check of the new bootstrap
  formal/SCOPE.txt              Exact formalization boundary
  checks/check_schema.py        Reproducible syntax and size checker
  checks/schema_checks.json     Results for 4,957 generated input terms
  checks/generated_examples.txt Fully expanded example formulas
  audit/source_manifest.json    Exact five-archive comparison snapshot
  audit/lean-check.txt           Lean version, command, result, dependencies
  audit/verification.json       Final validation summary
  MANIFEST.sha256                Checksums of packaged files

REPRODUCE

From this directory:

  python3 checks/check_schema.py
  lean formal/GuardedTailAudit.lean
  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

Or use:

  make syntax
  make lean
  make pdf

The Python checker needs Python 3.10 or later and only the standard library.
The recorded Lean check uses Lean 4.19.0, pinned by lean-toolchain, with
Init only: no Mathlib, Lake project, or package dependencies are needed.
The PDF uses standard LaTeX packages from TeX Live (including amsmath,
amssymb, amsthm, mathtools, booktabs, tabularx, microtype, hyperref, cleveref,
and Latin Modern fonts). If latexmk is unavailable, run pdflatex twice.

VERIFICATION BOUNDARY

The complete PRA bi-interpretation is a written mathematical proof.
The Lean file checks selected arbitrary-carrier bootstrap implications,
including the fully guarded seed argument and the local nonzeroness step
needed to recover predecessor. All 24 audited declarations have empty
Lean axiom dependency lists, with their theorem hypotheses explicit.
The descriptor grammar, full arithmetic calibration, scalar pairing,
PR compiler, and complete first-order metatheorem are not mechanized here.

The Python program verifies syntax, frozen-descriptor substitution, exact
node counts, and variable/quantifier budgets on its stated finite corpus.
It does not prove logical equivalence of the infinite theories.

COMPARISON AND PROVENANCE

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 9e77f2a2bb9ccf0a4f85934f1f83df8a3f8767be
Directory: docs/drafts

All five archives at this revision were downloaded and their Git blob
hashes checked. The adjacent-parameter archive and the numbered copy of
the one-term-one-schema archive have the same operative axiom schema.
The new result is guard sharing and the shorter recurrence, not the
already present adjacent-parameter reduction. The report credits and
re-proves the inherited scalar calibration to remain self-contained.

No external repository was modified by preparing this package.
