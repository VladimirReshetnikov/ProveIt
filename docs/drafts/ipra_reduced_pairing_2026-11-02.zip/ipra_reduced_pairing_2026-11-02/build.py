#!/usr/bin/env python3
"""Run reproducible checks, compile the report, and optionally make its ZIP."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent


def distributable_files():
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if any(part in {'build', '__pycache__'} for part in rel.parts):
            continue
        if path.suffix in {'.pyc', '.zip'}:
            continue
        yield path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', action='store_true')
    args = parser.parse_args()
    (ROOT / 'verification').mkdir(exist_ok=True)
    record = {'checks': [], 'full_proof_assistant_verification': False}
    for script in ('verify.py', 'module_counts.py', 'pair_basis.py', 'compact_counts.py'):
        proc = subprocess.run([sys.executable, str(ROOT / 'checks' / script)],
                              cwd=ROOT, text=True, capture_output=True)
        if proc.returncode:
            sys.stderr.write(proc.stdout + proc.stderr)
            raise SystemExit(proc.returncode)
        data = json.loads(proc.stdout)
        if data.get('status') != 'passed':
            raise SystemExit('Check did not report success: ' + script)
        (ROOT / 'checks' / script.replace('.py', '.json')).write_text(
            json.dumps(data, indent=2) + '\n')
        record['checks'].append({'script': script, 'status': 'passed'})
    proc = subprocess.run(['latexmk', '-pdf', '-interaction=nonstopmode',
                           '-halt-on-error', '-outdir=build', 'report.tex'],
                          cwd=ROOT, text=True, capture_output=True)
    (ROOT / 'verification' / 'latex_build.txt').write_text(proc.stdout + proc.stderr)
    if proc.returncode:
        sys.stderr.write(proc.stdout + proc.stderr)
        raise SystemExit(proc.returncode)
    log = (ROOT / 'build' / 'report.log').read_text(errors='replace')
    flags = [line for line in log.splitlines() if any(k in line for k in
             ('Overfull', 'Undefined control', 'undefined references', 'multiply defined'))]
    record['latex_layout_flags'] = flags
    if flags:
        raise SystemExit('Resolve LaTeX flags before release: ' + repr(flags))
    shutil.copy2(ROOT / 'build' / 'report.pdf', ROOT / 'report.pdf')
    record['pdf_size_bytes'] = (ROOT / 'report.pdf').stat().st_size
    record['status'] = 'passed'
    (ROOT / 'verification' / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
    checksums = []
    for path in distributable_files():
        if path.name == 'SHA256SUMS.txt':
            continue
        checksums.append(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' +
                         path.relative_to(ROOT).as_posix())
    (ROOT / 'SHA256SUMS.txt').write_text('\n'.join(checksums) + '\n')
    if args.archive:
        archive = ROOT.parent / (ROOT.name + '.zip')
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
            for path in distributable_files():
                out.write(path, (Path(ROOT.name) / path.relative_to(ROOT)).as_posix())
        with zipfile.ZipFile(archive) as check:
            assert check.testzip() is None
        record['archive'] = archive.name
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
