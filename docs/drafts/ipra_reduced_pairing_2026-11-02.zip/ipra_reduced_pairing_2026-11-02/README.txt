A SMALLER PAIRED AXIOMATIZATION OF iPRA
====================================

Main result
-----------
The main theory uses the basic numerical signature 0,S,B,L,R, generated
initialized recursors, five fixed nonlogical sentences, and a restricted
diagonal boundary schema. The pairing equations themselves define full
numerical case analysis and predecessor. No auxiliary computation axioms
for those operations remain in the main theory.

The report proves full first-order INTUITIONISTIC bi-interpretability
and equiconsistency with iPRA. Both whole-carrier interpretation composites
are internally the identity. Arbitrary quantified formulas retain their
intuitionistic logic; quantifier-free decidability is derived separately.

Exact finite-prefix comparison
------------------------------
Five fixed nonlogical sentences: 59 tree nodes.
With the paid four-place chain definition: 74.
The strongest current paired proposal's supported prefix: 106 with its
components separately grouped, or 105 after cross-component prefix sharing.
The new prefix saves 32 or 31 nodes respectively. This is not a finite
size for the entire infinite theory, and not an absolute minimality claim.
Larger expanded helper terms are charged. Separately priced p,C and
single-U alternatives trade more fixed axioms for shorter repeated terms.

An independent fixed-signature transformation retains every old module
and adds aliases after all strictly shrinking lower-rank computations.
It never enlarges a selected module and has unbounded strict savings on
the disclosed h_m=Z(S^m(w),v) family, with Z already paid as support.

Contents
--------
report.pdf                   Complete mathematical report.
report.tex, sections/*.tex    Full LaTeX sources.
AXIOMS.txt                   Exact standalone theory and proof map.
checks/*.py                  Independent exact syntax and finite diagnostics.
checks/*.json                Recorded results.
provenance/source_manifest.json
                             Pinned source paths, Git blobs, SHA-256 hashes.
provenance/comparison.csv     Current/archived audit and retained improvements.
verification/STATUS.txt       Scope of verification and limitations.
verification/build.json       Reproduction results.
verification/layout.json      Final PDF layout inspection record.
build.py                     Run all checks, compile PDF, optionally archive.
SHA256SUMS.txt                Checksums of distributable files.

Rebuild
-------
Requirements: Python 3.10+ standard library; a LaTeX installation with
latexmk and pdflatex, lmodern, microtype, amsmath, mathtools, booktabs,
enumitem, hyperref, fancyhdr. No network access is needed.

From the extracted directory:
  python3 build.py

To create a ZIP next to the extracted directory as well:
  python3 build.py --archive

To run only the mathematical diagnostics:
  python3 checks/verify.py
  python3 checks/module_counts.py
  python3 checks/pair_basis.py
  python3 checks/compact_counts.py

Verification scope
------------------
General correctness rests on the complete written intuitionistic proofs.
Python checks exact syntax counts, frozen-descriptor handling, finite
description reduction closures, and bounded numerical consequences.
It does not certify the whole theory in Lean or Rocq. No such complete
formal verification is claimed. The PDF was rendered and visually checked.

Sources
-------
Repository: VladimirReshetnikov/ProveIt.
Snapshot: 44d32ed7bce61b58f6a28c03979cc95dd935acf7.
All four current and five archived packages at that snapshot were reviewed.
All four current packages contribute genuine improvements over the archived
iteration, so none was discarded wholesale. The archive includes source
identifiers and comparisons, but not duplicate copies of the source ZIPs.

Further research questions appear at the end of the report.
