"""Exhaustive size search in the RESTRICTED grammar 0,n,a,b,S,q,g.

Every q/g node costs three nodes plus its arguments, because its fully
expanded term is L(S(B(...))) or R(S(B(...))). This does not search all
terms over B,L,R,S and is not an absolute minimality claim.

Terms are identified by their values on 96 tuples. This is a congruence
for the operations used, so keeping only a smallest representative of
each vector cannot discard a minimum-size matching term. Failure to
match this finite sample excludes an exact implementation as well.
The returned formulas' correctness on all inputs is proved in the text.
"""
from itertools import product
import json

samples=list(product(range(6),(0,1,2,5),(0,1,2,5)))
targets={
    "predecessor":tuple(max(0,n-1) for n,a,b in samples),
    "conditional":tuple(a if n==0 else b for n,a,b in samples),
}
base={
    "0":tuple(0 for _ in samples),
    "n":tuple(n for n,a,b in samples),
    "a":tuple(a for n,a,b in samples),
    "b":tuple(b for n,a,b in samples),
}
seen={value:(1,term) for term,value in base.items()}
layers={1:{value:term for term,value in base.items()}}
found={}
counts=[]
for size in range(1,15):
    if size>1:
        current={}
        for value,term in layers[size-1].items():
            result=tuple(x+1 for x in value)
            if result not in seen:
                current.setdefault(result,"S("+term+")")
        for left_size in range(1,size-3):
            right_size=size-3-left_size
            if right_size<1:
                continue
            for left,left_term in layers[left_size].items():
                for right,right_term in layers[right_size].items():
                    q_result=tuple(y+1 if x==0 else x-1 for x,y in zip(left,right))
                    g_result=tuple(0 if x==0 else y+1 for x,y in zip(left,right))
                    if q_result not in seen:
                        current.setdefault(q_result,"q("+left_term+","+right_term+")")
                    if g_result not in seen:
                        current.setdefault(g_result,"g("+left_term+","+right_term+")")
        layers[size]=current
        seen.update((value,(size,term)) for value,term in current.items())
    for name,target in targets.items():
        if name not in found and target in layers[size]:
            found[name]={"size":size,"term":layers[size][target]}
    counts.append({"size":size,"new_semantic_classes":len(layers[size]),
                   "total_semantic_classes":len(seen)})
    if len(found)==len(targets):
        break

assert found=={
    "predecessor":{"size":13,"term":"q(q(g(n,n),0),0)"},
    "conditional":{"size":14,"term":"q(q(g(n,S(b)),a),0)"},
}
print(json.dumps({"status":"passed","grammar":"0,n,a,b,S,q,g",
    "scope":"Restricted grammar only; not all B,L,R,S terms or all presentations.",
    "sample_count":len(samples),"found":found,"size_layers":counts},indent=2))
