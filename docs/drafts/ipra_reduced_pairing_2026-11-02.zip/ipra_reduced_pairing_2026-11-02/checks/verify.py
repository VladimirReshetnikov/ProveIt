#!/usr/bin/env python3
"""Independent kernel counts, active reduction closures and finite scan tests.

This is not a formal proof of the infinite intuitionistic theories.
The complete general deductions are in the report.
"""
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from math import isqrt
import json


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple = ()
    desc: object = None


def node(op, *args):
    return Term(op, args)


def rec(h, counter, initial):
    return Term('rec', (counter, initial), h)


@lru_cache(None)
def size(term):
    return 1 + sum(size(t) for t in term.args) + (
        size(term.desc) if term.desc is not None else 0)


def subst(term, mapping):
    """Simultaneous active substitution, with every descriptor frozen."""
    if term in mapping:
        return mapping[term]
    return Term(term.op, tuple(subst(t, mapping) for t in term.args), term.desc)


zero, v, w, a, n, x, y, z = map(Term, ('0', 'v', 'w', 'a', 'n', 'x', 'y', 'z'))
S = lambda t: node('S', t)
B = lambda t, u: node('B', t, u)
L = lambda t: node('L', t)
R = lambda t: node('R', t)
eq = lambda t, u: node('=', t, u)
conj = lambda t, u: node('and', t, u)


def quant(names, formula, op='forall'):
    # Binder annotations cost no extra node, per the report's metric.
    for _ in reversed(names):
        formula = node(op, formula)
    return formula


def all_conj(formulas):
    formula = formulas[-1]
    for item in reversed(formulas[:-1]):
        formula = conj(item, formula)
    return formula


def root_reducts(term):
    candidates = []
    if term.op == 'rec':
        counter, initial = term.args
        h = term.desc
        if counter == zero:
            candidates.append(initial)
        if counter.op == 'S':
            previous = counter.args[0]
            candidates.append(subst(h, {v: rec(h, previous, initial), w: previous}))
        if h == v:
            candidates.append(initial)
    return {t for t in candidates if size(t) < size(term)}


def successors(term):
    """All one-step active strict reductions; frozen bodies are opaque."""
    out = root_reducts(term)
    for index, child in enumerate(term.args):
        for changed in successors(child):
            args = list(term.args)
            args[index] = changed
            rebuilt = Term(term.op, tuple(args), term.desc)
            assert size(rebuilt) < size(term)
            out.add(rebuilt)
    return out


def closure(term):
    seen = {term}
    pending = [term]
    while pending:
        current = pending.pop()
        for reduced in successors(current):
            if reduced not in seen:
                seen.add(reduced)
                pending.append(reduced)
    return seen


def kernel_counts():
    eta = quant([z], eq(B(L(z), R(z)), z))
    horiz = eq(S(B(S(a), n)), B(a, S(n)))
    left = eq(L(B(a, n)), a)
    right = eq(R(B(a, n)), n)
    joint = quant([a, n], conj(horiz, conj(left, right)))
    weak_v = quant([n], eq(L(S(B(zero, n))), S(n)))
    strong_v = quant([n], eq(S(B(zero, n)), B(S(n), zero)))
    sep = node('implies', eq(zero, S(zero)), node('false'))
    cov = quant([z], quant([y], node('or', eq(z, zero), eq(z, S(y))), 'exists'))
    counts = dict(zip(('eta', 'joint', 'weak_vertical', 'sep', 'coverage'),
                      map(size, (eta, joint, weak_v, sep, cov))))
    assert counts == {'eta': 8, 'joint': 26, 'weak_vertical': 9,
                      'sep': 6, 'coverage': 10}
    assert size(strong_v) == 10
    Q = lambda c, t: rec(w, c, t)
    Z = lambda c, t: rec(zero, c, t)
    old_atoms = [eq(Q(zero, a), a), eq(Q(S(n), a), n),
                 eq(Z(zero, a), a), eq(Z(S(n), a), zero),
                 eq(B(L(a), R(a)), a), horiz, left, right,
                 eq(S(B(zero, n)), B(S(n), zero))]
    packed_old = quant([a, n], all_conj(old_atoms))
    assert size(packed_old) == 74
    main_numerical = size(eta) + size(joint) + size(weak_v)
    assert main_numerical == 43
    counts.update({'nonlogical_fixed': 59, 'with_chain_record': 74,
                   'old_globally_packed_arithmetic': size(packed_old),
                   'old_global_with_sep_cov_chain': 105,
                   'saving_against_global_packet': 31})
    return counts


def normalization_checks():
    # A closed counter occurs in the FROZEN descriptor; it must survive.
    frozen = rec(zero, S(w), v)
    outer = rec(frozen, x, a)
    assert successors(outer) == set()
    changed = subst(outer, {v: zero, w: S(zero), x: y})
    assert changed.desc == frozen and changed.args == (y, a)
    family = []
    for m in (1, 2, 8, 10, 20, 100):
        sw = w
        for _ in range(m):
            sw = S(sw)
        h = rec(zero, sw, v)
        H = size(h)
        assert H == m + 4
        reached = closure(h)
        assert zero in reached
        alias = quant([a, n], eq(rec(h, n, a), rec(zero, n, a)))
        assert size(alias) == m + 14
        old = {'D': 4*m+31, 'G3': 3*m+33, 'G0': 3*m+34,
               'T4': 2*m+39, 'T3': 2*m+40, 'F': 3*m+29,
               'L': 3*m+34, 'N4': 2*m+38, 'N3': 2*m+39}
        bound = 2*m + 7
        if m >= 8:
            assert bound > size(alias)
        family.append({'m': m, 'H': H, 'closure_size': len(reached),
                       'new_alias': size(alias), 'raw_old_min': min(old.values()),
                       'proved_old_shared_lower_bound': bound,
                       'guaranteed_saving': bound-size(alias)})
    # Ordinary, non-special step rewriting and literal identity rewriting.
    assert v in closure(rec(v, w, v))
    # This successor step is a raw size tie, so the strict normalizer
    # correctly refuses it even though a two-step reduction could shrink.
    tie = rec(S(v), S(zero), v)
    assert closure(tie) == {tie}
    assert S(zero) in closure(rec(S(w), S(zero), v))
    assert S(v) in closure(rec(w, S(S(v)), a))
    return {'frozen_descriptor_tests': 'passed', 'strict_family': family}


def triangular(k):
    return k * (k + 1) // 2


def pair(a, b):
    return triangular(a+b) + b


def unpair(z):
    k = (isqrt(8*z+1)-1)//2
    b = z-triangular(k)
    return k-b, b


def pairing_checks():
    assertions = 0
    for a in range(61):
        for n in range(61):
            assert unpair(pair(a, n)) == (a, n)
            assert pair(a+1, n)+1 == pair(a, n+1)
            assertions += 2
    k = 0
    for z in range(5001):
        left, right = unpair(z)
        assert pair(left, right) == z
        next_left, next_right = unpair(z+1)
        assert next_right in (0, right+1)
        if left == 0:
            assert (next_left, next_right) == (right+1, 0)
        else:
            assert (next_left, next_right) == (left-1, right+1)
        assert triangular(k) <= z < triangular(k+1)
        k += int(z+1 == triangular(k+1))
        assertions += 4
    for n in range(501):
        assert unpair(pair(0, n)+1)[0] == n+1
        assert pair(0, n)+1 == pair(n+1, 0)
        assertions += 2
    return {'assertions': assertions, 'pair_arguments_max': 60,
            'coordinate_counter_max': 5000, 'vertical_argument_max': 500}


def scan_checks():
    tables = probes = 0
    for target in range(10):
        for bits in product((False, True), repeat=target+1):
            b = 0
            for k in range(target+1):
                assert not bits[b] or b == k
                assert b == 0 or bits[b-1]
                if k < target:
                    b = k+1 if bits[b] else b
            # The SAME b handles every numerical probe.
            for x in range(target+2):
                P = bits[x] if x <= target else False
                assert x+1 != b or P
                assert not (P and x == b) or b == target
                probes += 1
            tables += 1
    return {'truth_tables': tables, 'probe_checks': probes,
            'target_max': 9, 'single_witness_for_all_probes': True}


def graph_checks():
    updates = [lambda state, counter: state+counter+1,
               lambda state, counter: counter,
               lambda state, counter: 0,
               lambda state, counter: state,
               lambda state, counter: counter if state == 0 else 0]
    checks = 0
    for update in updates:
        for initial in range(5):
            values = [initial]
            for x in range(11):
                values.append(update(values[-1], x))
            for n in range(10):
                pred = max(0, n-1)
                u = values[pred]
                expected = initial if n == 0 else update(u, pred)
                for x in range(12):
                    for y in {0, u, values[x]}:
                        assert not (x+1 == n and y == u) or values[x] == y
                        assert not (values[x] == y and x == n) or y == expected
                        checks += 1
    return {'updates': len(updates), 'graph_probe_checks': checks,
            'counter_max': 9, 'initial_max': 4}


def main():
    result = {'status': 'passed',
              'scope': 'Exact syntax and finite diagnostics only; general proofs are in report.pdf.',
              'kernel': kernel_counts(),
              'normalization': normalization_checks(),
              'canonical_pair': pairing_checks(),
              'boundary_scan': scan_checks(),
              'generalized_predecessor_graph': graph_checks()}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
