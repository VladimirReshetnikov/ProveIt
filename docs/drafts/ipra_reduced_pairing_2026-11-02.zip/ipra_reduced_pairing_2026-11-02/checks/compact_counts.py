"""Exact finite AST counts and numerical diagnostics for the compact interfaces.

These checks are not a proof-assistant certification of the infinite theory.
Run from any directory; module_counts.py is loaded from this script's folder.
"""
from pathlib import Path
from contextlib import redirect_stdout
import importlib.util
import io
import json
from math import isqrt

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("module_counts", here / "module_counts.py")
m = importlib.util.module_from_spec(spec)
with redirect_stdout(io.StringIO()):
    spec.loader.exec_module(m)

O, size, Rrec = m.O, m.size, m.R
v, w, a, n, u, x, y, zero = m.v, m.w, m.a, m.n, m.u, m.x, m.y, m.z
b, t = m.V("b"), m.V("t")
S = m.S
B = lambda s,t: O("B",s,t)
L = lambda s: O("L",s)
R = lambda s: O("R",s)
U = lambda s,t: O("U",s,t)
q = lambda s,t: L(S(B(s,t)))
g = lambda s,t: R(S(B(s,t)))
p_pair = lambda s: q(q(g(s,s),zero),zero)
C_pair = lambda s,a,b: q(q(g(s,S(b)),a),zero)
pi = lambda s: q(s,zero)
J = lambda s,a,b: q(g(s,S(b)),a)
p_u = lambda s: L(U(s,zero))
C_u17 = lambda s,a,b: R(U(s,B(b,a)))
C_u16 = lambda s,a,b: L(R(U(s,B(b,B(a,zero)))))

term_counts = {
    "q": size(q(n,a)), "g": size(g(n,a)),
    "pair_p": size(p_pair(n)), "pair_C": size(C_pair(n,a,b)),
    "guarded_predecessor": size(pi(n)), "shifted_selector": size(J(n,a,b)),
    "U_p": size(p_u(n)), "U17_C": size(C_u17(n,a,b)), "U16_C": size(C_u16(n,a,b)),
}
assert term_counts == {"q":5,"g":5,"pair_p":13,"pair_C":14,
                      "guarded_predecessor":5,"shifted_selector":10,
                      "U_p":4,"U17_C":6,"U16_C":9}
assert size(p_pair(S(n))) == 2 * size(S(n)) + 11
assert size(C_pair(B(n,a),S(a),L(b))) == size(B(n,a))+size(S(a))+size(L(b))+11

eq, qs, conj = m.eq, m.qs, m.conj
u0 = qs([t],eq(U(zero,t),t))
u17step = qs([n,t],eq(U(S(n),t),B(n,L(t))))
u16step = qs([n,t],eq(U(S(n),t),B(n,t)))
assert size(u0)==6 and size(u17step)==11 and size(u16step)==10
assert size(qs([n,t],conj(eq(U(zero,t),t),eq(U(S(n),t),B(n,L(t))))))==17
assert size(qs([n,t],conj(eq(U(zero,t),t),eq(U(S(n),t),B(n,t)))))==16
eta = qs([x],eq(B(L(x),R(x)),x))
horiz = eq(S(B(S(a),n)),B(a,S(n)))
left_beta = eq(L(B(a,n)),a)
right_beta = eq(R(B(a,n)),n)
joined = qs([a,n],conj(horiz,conj(left_beta,right_beta)))
weak_vertical = qs([n],eq(L(S(B(zero,n))),S(n)))
assert [size(eta),size(joined),size(weak_vertical)]==[8,26,9]
fixed_records={"pair_only":43+6+10+15,
               "U16":43+6+10+15+16,
               "U17":43+6+10+15+17,
               "native_p_C_grouped":43+6+10+15+27}
assert fixed_records=={"pair_only":74,"U16":90,"U17":91,"native_p_C_grouped":101}

cases=[v,w,zero,S(v),S(w),B(v,w),q(v,w),g(S(w),L(v)),
       Rrec(B(v,S(w)),w,B(v,v)),B(S(S(w)),v)]
module_results=[]
for mode,pfun,cfun in [("U17",p_u,C_u17),("U16",p_u,C_u16),
                       ("pair_shifted",pi,J)]:
    m.p,m.C=pfun,cfun
    for h in cases:
        H=size(h);k=m.active(h,v);j=m.active(h,S(w));r=m.active(h,w)-j
        actual=m.modules(h)
        if mode=="U17":
            expected={"F":2*H-j+11+k*(H+5)+3*r,
                      "L":2*H-j+19+k*(H+2),"N4":2*H-j+29+3*r}
        elif mode=="U16":
            expected={"F":2*H-j+14+k*(H+5)+3*r,
                      "L":2*H-j+22+k*(H+2),"N4":2*H-j+32+3*r}
        else:
            # Replace the conclusion's left value by its successor in each
            # of F,L,N4. This adds one node to that single occurrence.
            actual={name:value+(name in ("F","L","N4")) for name,value in actual.items()}
            expected={"F":2*H-j+16+k*(H+6)+4*r,
                      "L":2*H-j+25+k*(H+2),"N4":2*H-j+34+4*r}
        assert all(actual[name]==value for name,value in expected.items()),(mode,H,k,j,r,actual,expected)
        module_results.append({"mode":mode,"H":H,"k":k,"j":j,"r":r,
                               "F":actual["F"],"L":actual["L"],"N4":actual["N4"]})

def pair(a,b): return (a+b)*(a+b+1)//2+b
def coords(z):
    k=(isqrt(8*z+1)-1)//2
    r=z-k*(k+1)//2
    return k-r,r
def qq(n,z): return coords(pair(n,z)+1)[0]
def gg(n,z): return coords(pair(n,z)+1)[1]
def pp(n): return qq(qq(gg(n,n),0),0)
def cc(n,a,b): return qq(qq(gg(n,b+1),a),0)
def uu17(n,z): return z if n==0 else pair(n-1,coords(z)[0])
def uu16(n,z): return z if n==0 else pair(n-1,z)
for n0 in range(101):
    assert pp(n0)==max(0,n0-1)
    assert coords(uu17(n0,0))[0]==max(0,n0-1)
    assert coords(uu16(n0,0))[0]==max(0,n0-1)
for n0 in range(21):
    for a0 in range(12):
        for b0 in range(12):
            wanted=a0 if n0==0 else b0
            assert cc(n0,a0,b0)==wanted
            assert coords(uu17(n0,pair(b0,a0)))[1]==wanted
            assert coords(coords(uu16(n0,pair(b0,pair(a0,0))))[1])[0]==wanted

print(json.dumps({"status":"passed",
 "scope":"Exact finite AST counts and finite standard-model diagnostics, not a proof-assistant formalization.",
 "term_counts":term_counts,"fixed_records":fixed_records,
 "module_cases":module_results,
 "numerical_checks":{"predecessor_arguments":101,"conditional_triples":21*12*12}},indent=2))
