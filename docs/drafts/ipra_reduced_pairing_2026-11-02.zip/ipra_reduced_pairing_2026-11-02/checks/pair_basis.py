#!/usr/bin/env python3
"""Independent finite AST and standard-natural checks of the pairing basis.

The written proof establishes the universal laws. This script checks exact
expanded syntax sizes and bounded evaluations; it is not a proof assistant.
"""
from dataclasses import dataclass
from itertools import product
from math import isqrt
import json

@dataclass(frozen=True)
class Node:
    op: str
    args: tuple = ()
    descriptor: object = None

def node(op,*args): return Node(op,args)
def var(name): return Node(name)
def rec(h,n,a): return Node('rec',(n,a),h)
def size(t):
    return 1+sum(size(x) for x in t.args)+(size(t.descriptor) if t.descriptor else 0)
def active(t,s): return int(t==s)+sum(active(x,s) for x in t.args)
def replace(t,u,n,x):
    if t==S(w):return x
    if t==v:return u
    if t==w:return n
    return Node(t.op,tuple(replace(c,u,n,x) for c in t.args),t.descriptor)
def eq(a,b):return node('=',a,b)
def imp(a,b):return node('->',a,b)
def both(a,b):return node('&',a,b)
def quant(vars,t,op='forall'):
    for _ in reversed(vars):t=node(op,t)
    return t
z=var('0')
v,w,n,a,b,u,x,y=map(var,['v','w','n','a','b','u','x','y'])
S=lambda t:node('S',t)
B=lambda a,b:node('B',a,b)
L=lambda t:node('L',t)
R=lambda t:node('R',t)
q=lambda n,z:L(S(B(n,z)))
g=lambda n,z:R(S(B(n,z)))
pi=lambda n:q(n,z)
Q=lambda n,a:q(q(g(n,n),a),z)
p=lambda n:Q(n,z)
C=lambda n,a,b:q(q(g(n,S(b)),a),z)
J=lambda n,a,b:q(g(n,S(b)),a)

sizes={name:size(t) for name,t in {
    'q(n,a)':q(n,a),'g(n,a)':g(n,a),'pi(n)':pi(n),
    'p(n)':p(n),'Q(n,a)':Q(n,a),'C(n,a,b)':C(n,a,b),
    'J(n,a,b)':J(n,a,b),'C(n,a,0)':C(n,a,z),
}.items()}
assert sizes=={'q(n,a)':5,'g(n,a)':5,'pi(n)':5,'p(n)':13,
              'Q(n,a)':13,'C(n,a,b)':14,'J(n,a,b)':10,'C(n,a,0)':14}

# Evaluations traverse the actual expanded AST, using only B,L,R,S and0.
def pair(a,b):s=a+b;return s*(s+1)//2+b
def coords(z):
    s=(isqrt(8*z+1)-1)//2
    r=z-s*(s+1)//2
    return s-r,r

def evaluate(t,env):
    if t.op=='0':return 0
    if not t.args:return env[t.op]
    aa=[evaluate(x,env) for x in t.args]
    if t.op=='S':return aa[0]+1
    if t.op=='B':return pair(*aa)
    if t.op=='L':return coords(aa[0])[0]
    if t.op=='R':return coords(aa[0])[1]
    raise ValueError(t.op)

checks=0
for nn,aa in product(range(33),repeat=2):
    env={'n':nn,'a':aa}
    assert evaluate(q(z,a),env)==aa+1
    assert evaluate(q(S(n),a),env)==nn
    assert evaluate(g(z,a),env)==0
    assert evaluate(g(S(n),a),env)==aa+1
    assert evaluate(Q(n,a),env)==(aa if nn==0 else nn-1)
    assert evaluate(p(n),env)==max(nn-1,0)
    checks+=6
for nn,aa,bb in product(range(17),repeat=3):
    env={'n':nn,'a':aa,'b':bb}
    assert evaluate(C(n,a,b),env)==(aa if nn==0 else bb)
    assert evaluate(J(n,a,b),env)==(aa+1 if nn==0 else bb+1)
    checks+=2

cases=[v,w,z,S(v),S(w),B(v,S(w)),B(S(w),B(v,w)),
       rec(B(v,S(w)),S(w),B(v,v)),B(S(S(w)),v),
       R(B(v,B(S(w),w)))]
formula_checks=[]
for h in cases:
    H=size(h);k=active(h,v);j=active(h,S(w));r=active(h,w)-j
    f=quant([a,n],eq(S(rec(h,n,a)),J(n,a,replace(h,rec(h,pi(n),a),pi(n),n))))
    ell=quant([a,n,u],imp(eq(pi(n),u),eq(S(rec(h,n,a)),J(n,a,replace(h,rec(h,u,a),u,n)))))
    tab=quant([a,n],quant([u],quant([x,y],node('K4',both(eq(S(x),n),eq(y,u)),eq(rec(h,x,a),y),eq(x,n),eq(S(y),J(n,a,replace(h,u,pi(n),n))))),'exists'))
    got={'F_pair':size(f),'L_pair':size(ell),'N_pair':size(tab)}
    expect={'F_pair':2*H-j+16+k*(H+6)+4*r,
            'L_pair':2*H-j+25+k*(H+2),
            'N_pair':2*H-j+34+4*r}
    assert got==expect,(h,got,expect)
    assert got['N_pair']>2*H-j+32
    aliases={name:size(quant([a,n],eq(rec(h,n,a),t))) for name,t in
             {'identity':a,'zero':C(n,a,z),'counter':Q(n,a)}.items()}
    assert aliases=={'identity':H+7,'zero':H+20,'counter':H+19}
    # Optional full p,C expansion is valid but more expensive than the
    # successor-output construction used by the pairing-only selector.
    f_full=quant([a,n],eq(rec(h,n,a),C(n,a,replace(h,rec(h,p(n),a),p(n),n))))
    l_full=quant([a,n,u],imp(eq(p(n),u),eq(rec(h,n,a),C(n,a,replace(h,rec(h,u,a),u,n)))))
    n_full=quant([a,n],quant([u],quant([x,y],node('K4',both(eq(S(x),n),eq(y,u)),eq(rec(h,x,a),y),eq(x,n),eq(y,C(n,a,replace(h,u,p(n),n))))),'exists'))
    assert size(f_full)==2*H-j+19+k*(H+14)+12*r
    assert size(l_full)==2*H-j+36+k*(H+2)
    assert size(n_full)==2*H-j+37+12*r
    formula_checks.append({'H':H,'k':k,'j':j,'r':r,'counts':got,'aliases':aliases})

print(json.dumps({'status':'passed','scope':'Exact expanded AST counts and bounded standard-natural diagnostics; universal laws are proved in the report.',
                  'term_sizes':sizes,'numerical_assertions':checks,'formula_cases':formula_checks},indent=2))
