from dataclasses import dataclass
from functools import lru_cache
from itertools import combinations
import json

@dataclass(frozen=True)
class T:
    op:str
    args:tuple=()
    desc:object=None

def V(x): return T(x)
def O(op,*args): return T(op,args)
def R(h,n,a): return T('rec',(n,a),h)
def size(t): return 1+sum(size(a) for a in t.args)+(size(t.desc) if t.desc else 0)
def active(t,needle): return (int(t==needle)+sum(active(a,needle) for a in t.args))
def subst(t,mp):
    if t in mp:return mp[t]
    return T(t.op,tuple(subst(a,mp) for a in t.args),t.desc)
def dagger(t,u,n,x):
    if t==O('S',w):return x
    if t==v:return u
    if t==w:return n
    return T(t.op,tuple(dagger(a,u,n,x) for a in t.args),t.desc)
def eq(x,y):return O('=',x,y)
def imp(x,y):return O('->',x,y)
def conj(x,y):return O('&',x,y)
def q(v,f,op='forall'):return T(op,(f,))
def qs(vs,f):
    for v_ in reversed(vs): f=q(v_,f)
    return f
v,w,a,n,u,x,y=map(V,'vwanuxy')
z=V('0')
S=lambda t:O('S',t)
p=lambda t:O('p',t)
C=lambda n,a,b:O('C',n,a,b)

def modules(h):
    D=[qs([a],eq(R(h,z,a),a)),qs([a,n],eq(R(h,S(n),a),subst(h,{v:R(h,n,a),w:n})))]
    G3=qs([a,n,u],O('K3',conj(eq(n,z),eq(u,a)),eq(R(h,n,a),u),eq(R(h,S(n),a),subst(h,{v:u,w:n}))))
    G0=qs([a,n,u],imp(eq(R(h,n,a),u),conj(imp(eq(n,z),eq(u,a)),eq(R(h,S(n),a),subst(h,{v:u,w:n})))))
    T4=qs([a,n],q(u,conj(imp(eq(n,z),eq(u,a)),qs([x,y],O('K4',conj(eq(x,n),eq(y,u)),eq(R(h,x,a),y),eq(x,S(n)),eq(y,dagger(h,u,n,x))))),'exists'))
    F=qs([a,n],eq(R(h,n,a),C(n,a,dagger(h,R(h,p(n),a),p(n),n))))
    L=qs([a,n,u],imp(eq(p(n),u),eq(R(h,n,a),C(n,a,dagger(h,R(h,u,a),u,n)))))
    N4=qs([a,n],q(u,qs([x,y],O('K4',conj(eq(S(x),n),eq(y,u)),eq(R(h,x,a),y),eq(x,n),eq(y,C(n,a,dagger(h,u,p(n),n))))),'exists'))
    return {'D':sum(map(size,D)),'G3':size(G3),'G0':size(G0),'T4':size(T4),'F':size(F),'L':size(L),'N4':size(N4)}

cases=[v,w,z,S(v),S(w),C(w,v,z),O('B',S(w),O('B',v,p(w))),R(C(w,v,z),S(w),O('B',v,v)),O('B',S(S(w)),v)]
res=[]
for h in cases:
    H=size(h);k=active(h,v);j=active(h,S(w));r=active(h,w)-j
    expect={'D':3*H+13+k*(H+2),'G3':3*H+21,'G0':3*H+22,'T4':2*H-j+32,'F':2*H-j+9+k*(H+3)+r,'L':2*H-j+15+k*(H+2),'N4':2*H-j+27+r}
    got=modules(h)
    for name in got:
        assert got[name]==expect[name],(h,name,got,expect)
    aliases={
        'identity':size(qs([a,n],eq(R(h,n,a),a))),
        'zero':size(qs([a,n],eq(R(h,n,a),C(n,a,z)))),
        'counter':size(qs([a,n],eq(R(h,n,a),C(n,a,p(n))))),
        'ordinary':size(qs([a,n],eq(R(h,n,a),R(S(v),n,a)))),
    }
    assert aliases=={'identity':H+7,'zero':H+10,'counter':H+11,'ordinary':H+size(S(v))+9}
    res.append({'H':H,'k':k,'j':j,'r':r,'counts':got,'alias_counts':aliases})

# For universally closed equations with independent bound variables, any
# conjunction group can share a prefix of maximum arity, after alpha renaming.
# A group of k equations costs sum(atom sizes)+(k-1)+max(arity).
def min_prefix(atoms,arity):
    full=(1<<len(atoms))-1
    @lru_cache(None)
    def best(mask):
        if not mask:return (0,())
        least=mask&-mask; ans=(10**9,())
        sub=mask
        while sub:
            if sub&least:
                ids=tuple(i for i in range(len(atoms)) if sub>>i&1)
                cost=sum(atoms[i] for i in ids)+len(ids)-1+max(arity[i] for i in ids)
                tail,partition=best(mask^sub)
                ans=min(ans,(cost+tail,(ids,)+partition))
            sub=(sub-1)&mask
        return ans
    return best(full)

supports={
    'native_p_C':{'atoms':[4,5,6,7],'arities':[0,1,2,3]},
    'old_Q_Z':{'atoms':[6,7,6,7],'arities':[1,2,1,2]},
    'native_helpers_plus_pairing':{'atoms':[4,5,6,7,7,10,6,6,8],'arities':[0,1,2,3,1,2,2,2,1]},
    'source_helpers_plus_pairing':{'atoms':[6,7,6,7,7,10,9,6,6],'arities':[1,2,1,2,1,2,1,2,2]},
}
for s in supports.values():
    s['unshared']=sum(s['atoms'])+sum(s['arities'])
    s['minimum_prefix_shared'],s['partition']=min_prefix(s['atoms'],s['arities'])
assert supports['native_p_C']['unshared']==28
assert supports['native_p_C']['minimum_prefix_shared']==27
assert supports['old_Q_Z']['unshared']==32
assert supports['old_Q_Z']['minimum_prefix_shared']==31
assert supports['native_helpers_plus_pairing']['minimum_prefix_shared']==69
assert supports['source_helpers_plus_pairing']['minimum_prefix_shared']==74
# Build native and old helper equations independently of the count table.
b=V('b')
plain_native=[eq(p(z),z),qs([n],eq(p(S(n)),n)),qs([a,b],eq(C(z,a,b),a)),qs([n,a,b],eq(C(S(n),a,b),b))]
assert sum(map(size,plain_native))==28
shared_native=[plain_native[0],plain_native[1],qs([a,b],conj(eq(C(z,a,b),a),qs([n],eq(C(S(n),a,b),b))))]
assert sum(map(size,shared_native))==27
Q=lambda n,a:R(w,n,a)
Z=lambda n,a:R(z,n,a)
old_atoms=[eq(Q(z,a),a),eq(Q(S(n),a),n),eq(Z(z,a),a),eq(Z(S(n),a),z)]
old_shared=qs([a,n],conj(old_atoms[0],conj(old_atoms[1],conj(old_atoms[2],old_atoms[3]))))
assert size(old_shared)==31

# Known frozen descriptors must not contribute active counts.
frozen=R(O('B',v,S(w)),a,n)
assert active(frozen,v)==0 and active(frozen,w)==0 and active(frozen,S(w))==0
assert dagger(frozen,u,p(n),x)==frozen
print(json.dumps({'status':'passed','scope':'Finite AST counts and support-prefix optimization; not a proof assistant formalization.', 'formula_cases':res,'supports':supports},indent=2))
