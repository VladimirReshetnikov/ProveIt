NATIVE BOUNDARY CHOICE FOR PRIMITIVE RECURSIVE ARITHMETIC
Research package, 2 November 2026

MAIN RESULT
===========
The initial arithmetic symbols are only 0 and successor S. For every
earlier finite two-slot term h(v,w), introduce a binary function R_h.
Use ordinary first-order logic with equality and precisely these axioms:

  0 != S(0)
  forall a: R_h(0,a) = a
  forall a,n: R_h(S(n),a) = h(R_h(n,a),n)
  forall a,n exists b:
    (b=0 or P(b,a)) and (P(S(b),a) -> b=n)

The last schema ranges over all quantifier-free formulas P(x,a) of the
entire staged language, with no other free variables. A descriptor is
frozen and has no captured numerical parameters. The schemes are
infinite and effective; this is not a finite-language finite theory.

The report proves that this theory and first-order PRA have a common
conservative definitional extension. Both interpretations use the full
carrier, native equality, and identity composite isomorphisms. The result
holds separately for classical and intuitionistic first-order logic.

The key induction argument is immediate: under P(0,a) and progress, the
witness b satisfies P(b,a), then P(Sb,a), then b=n, hence P(n,a).
The report also supplies the reverse primitive-recursive witness, the
noncircular equality-bit and pairing bootstrap, and both translations.

WHAT IS SIMPLER
===============
No primitive equality bit, pointwise mask, mask definition, composition
constructor, two-mode recursion grammar, or special logical binder is
needed. The fixed arithmetic basis has 6 nodes under the drafts' metric,
instead of at least 24.

The local native boundary schema uses two copies of its predicate.
For full predicate size L and j active occurrences of the induction
variable, its exact size is 12+2L+j. For a shared raw tail t of full size
T, the specialization P=(t!=0) has size 20+2T+j. The favorable current
complete mask benchmark is 22+4T, so the saving is at least 2+T nodes.
The comparison retains an identical earlier arithmetic vocabulary in a
conservative companion theory; it does not price an expanded derived
function as if it were an incumbent primitive.

The full-size result includes mask definitions and frozen descriptors.
Active-size domination is false, and the report gives a counterexample.
Absolute shortestness, historical novelty, and beating every optional
serializer output are not claimed. See the precise workload definition.

CONTENTS
========
report.pdf, report.tex, sections/   Complete research report and LaTeX source.
formal/BoundaryKernel.lean         Constructive boundary/candidate kernel.
formal/EqualityBootstrap.lean      Derived equality test from explicit ledger.
formal/*check*.txt and *.json      Verified Lean transcripts and scope/hashes.
checks/check_sizes.py              Independent frozen-descriptor AST accounting.
checks/check_witnesses.py          Exhaustive finite candidate checks and pairing.
checks/*results.json               Recorded results.
checks/verify_sources.py           Re-download and verify the six pinned drafts.
provenance/sources.json            Immutable source URLs and hashes.
lean-toolchain                    Lean 4.19.0; no Mathlib needed.
build.py                          Re-run checks and build the PDF.
package_manifest.json             SHA-256 hashes of delivered component files.

VERIFICATION SCOPE
==================
Lean checked 19 theorems across the two files; every printed axiom
dependency list is empty. The hypotheses explicitly listed as theorem
parameters are still required. The full generated first-order syntax,
ledger derivations, pairing compiler, and bi-interpretability metatheorem
are proved in the report, not fully mechanized in Lean.

The Python tests provide finite regression evidence and exact syntax-tree
checks. They are not proofs about every model of PRA.

BUILD
=====
Requires Python 3.10+ (standard library), a LaTeX distribution with latexmk,
and optionally Lean 4.19.0. From this directory:

  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

Or run the commands in the report's verification section individually.
Network access is needed only for optional source re-downloads.

SOURCE SNAPSHOT
===============
VladimirReshetnikov/ProveIt, docs/drafts
Commit: 4d5474f10e00412135d659dc7a1f74fc6457656a
All six current archives were downloaded and checked against Git blob IDs.
The bibliography and provenance identify both distinct pointwise-mask ZIPs.
