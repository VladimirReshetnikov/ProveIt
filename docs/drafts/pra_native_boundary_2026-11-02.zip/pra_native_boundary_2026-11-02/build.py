#!/usr/bin/env python3
"""Re-run the local checks and compile the complete LaTeX report."""

from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys


def run(command: list[str], root: Path) -> None:
    print("Running:", " ".join(command), flush=True)
    subprocess.run(command, cwd=root, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Optional path to the Lean 4.19.0 executable")
    arguments = parser.parse_args()
    root = Path(__file__).resolve().parent
    run([sys.executable, "checks/check_sizes.py"], root)
    run([sys.executable, "checks/check_witnesses.py"], root)
    if arguments.lean:
        run([arguments.lean, "formal/BoundaryKernel.lean"], root)
        run([arguments.lean, "formal/EqualityBootstrap.lean"], root)
    run(
        ["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        root,
    )


if __name__ == "__main__":
    main()
