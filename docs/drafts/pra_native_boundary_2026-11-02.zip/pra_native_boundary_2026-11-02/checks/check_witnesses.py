#!/usr/bin/env python3
"""Finite checks of the boundary candidate and the explicitly defined pairing.

These checks are regression evidence, not proofs for arbitrary PRA models.
The report and Lean files give the actual logical/invariant arguments.
Run from anywhere with Python 3.10 or later; no third-party packages are used.
"""

from __future__ import annotations

import json
from pathlib import Path


def certificate(bits: list[bool], target: int, witness: int) -> bool:
    return (witness == 0 or bits[witness]) and (
        not bits[witness + 1] or witness == target
    )


def iterate(body, count: int, initial: int) -> int:
    state = initial
    for counter in range(count):
        state = body(state, counter)
    return state


def q(index: int, initial: int) -> int:
    return iterate(lambda state, counter: counter, index, initial)


def z(index: int, initial: int) -> int:
    return iterate(lambda state, counter: 0, index, initial)


def pred(value: int) -> int:
    return q(value, 0)


def add(left: int, right: int) -> int:
    return iterate(lambda state, counter: state + 1, right, left)


def difference(left: int, right: int) -> int:
    return iterate(lambda state, counter: pred(state), right, left)


def chi(left: int, right: int) -> int:
    return z(add(difference(left, right), difference(right, left)), 1)


def triangular(index: int) -> int:
    return iterate(lambda state, counter: add(state, counter + 1), index, 0)


def block(index: int) -> int:
    return iterate(
        lambda state, counter: add(state, chi(counter + 1, triangular(state + 1))),
        index,
        0,
    )


def pair(left: int, right: int) -> int:
    return add(triangular(add(left, right)), right)


def right_projection(code: int) -> int:
    return difference(code, triangular(block(code)))


def left_projection(code: int) -> int:
    return difference(block(code), right_projection(code))


def main() -> None:
    max_target = 12
    bit_count = max_target + 2
    pattern_count = 1 << bit_count
    candidate_checks = 0
    for pattern in range(pattern_count):
        bits = [bool((pattern >> index) & 1) for index in range(bit_count)]
        witness = 0
        for target in range(max_target + 1):
            assert 0 <= witness <= target
            assert certificate(bits, target, witness), (pattern, target, witness)
            candidate_checks += 1
            if target < max_target and bits[witness + 1]:
                witness = target + 1

    arithmetic_checks = 0
    for x in range(17):
        for y in range(17):
            assert add(x, y) == x + y
            assert difference(x, y) == max(x - y, 0)
            assert chi(x, y) == int(x == y)
            if difference(y, x) == 0:
                assert x == add(y, difference(x, y))
            arithmetic_checks += 1

    pairing_checks = 0
    for x in range(9):
        for y in range(9):
            code = pair(x, y)
            assert left_projection(code) == x
            assert right_projection(code) == y
            pairing_checks += 1

    results = {
        "status": "passed",
        "scope": "Finite regression checks, not an arbitrary-model proof.",
        "candidate": {
            "max_target": max_target,
            "truth_table_entries": bit_count,
            "exhaustive_truth_patterns": pattern_count,
            "certificates_checked": candidate_checks,
            "includes_false_base_predicates": True,
        },
        "arithmetic": {
            "argument_range": [0, 16],
            "pairs_checked": arithmetic_checks,
            "operations": "Initialized recursors for Q, Z, +, difference, and derived chi",
        },
        "pairing": {
            "argument_range": [0, 8],
            "pairs_checked": pairing_checks,
            "operations": "Triangular and block recursors, then both projection identities",
        },
    }
    destination = Path(__file__).with_name("witness_results.json")
    destination.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
