#!/usr/bin/env python3
"""Independent syntax-tree checks for the native-boundary PRA proposal.

This program checks exact sizes, not mathematical adequacy of a theory.
Every variable, constant, function application, equality, connective,
falsity and quantifier costs one active node. A quantifier's binder name
does not cost a separate node. Full size additionally charges the complete
frozen descriptor at EVERY application of a generated function symbol.
Substitution and occurrence counting never enter a frozen descriptor.

The baseline formulas are reconstructed directly from the six archives at
ProveIt commit 4d5474f10e00412135d659dc7a1f74fc6457656a. We include their
12-node coverage alternatives and give every baseline the counterexample
draft's cheaper tail-only descriptor convention in the uniform bound.
This is favorable to the baseline; it is not a claim about a globally
shortest proof, arbitrary serializer output, or a theory's total size.

Run: python3 checks/check_sizes.py
Output: checks/size_results.json
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import random


@dataclass(frozen=True)
class Symbol:
    name: str
    descriptor: "Node | None" = None


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()
    label: str = ""
    symbol: Symbol | None = None


def var(name: str) -> Node:
    return Node("var", label=name)


def app(symbol: Symbol, *args: Node) -> Node:
    return Node("app", tuple(args), symbol=symbol)


ZERO = Node("const", label="0")
BOTTOM = Node("bottom")
SUCCESSOR = Symbol("S")
CHI = Symbol("chi")
Q = Symbol("R_w", var("w"))
Z = Symbol("R_0", ZERO)


def succ(t: Node) -> Node:
    return app(SUCCESSOR, t)


ONE = succ(ZERO)


def binary(tag: str, first: Node, second: Node) -> Node:
    return Node(tag, (first, second))


def eq(first: Node, second: Node) -> Node:
    return binary("eq", first, second)


def conj(first: Node, second: Node) -> Node:
    return binary("and", first, second)


def disj(first: Node, second: Node) -> Node:
    return binary("or", first, second)


def implies(first: Node, second: Node) -> Node:
    return binary("imp", first, second)


def neg(p: Node) -> Node:
    return implies(p, BOTTOM)


def quantify(tag: str, variable: str, p: Node) -> Node:
    return Node(tag, (p,), label=variable)


def forall(variable: str, p: Node) -> Node:
    return quantify("forall", variable, p)


def exists(variable: str, p: Node) -> Node:
    return quantify("exists", variable, p)


def size(node: Node, full: bool = False) -> int:
    result = 1 + sum(size(child, full) for child in node.children)
    if full and node.symbol is not None and node.symbol.descriptor is not None:
        result += size(node.symbol.descriptor, True)
    return result


def occurrences(node: Node, name: str) -> int:
    """Count active occurrences only: descriptors remain frozen."""
    return int(node.tag == "var" and node.label == name) + sum(
        occurrences(child, name) for child in node.children
    )


def substitute(node: Node, replacements: dict[str, Node]) -> Node:
    """Simultaneous, capture-checked substitution in active syntax only."""
    if node.tag == "var":
        return replacements.get(node.label, node)
    if node.tag in {"forall", "exists"}:
        replacements = {k: v for k, v in replacements.items() if k != node.label}
        if any(occurrences(value, node.label) for value in replacements.values()):
            raise ValueError("The check requires fresh binders, not capture.")
    return Node(
        node.tag,
        tuple(substitute(child, replacements) for child in node.children),
        node.label,
        node.symbol,
    )


def selector(test: Node, if_zero: Node, if_successor: Node) -> Node:
    return app(Q, app(Z, test, succ(if_zero)), if_successor)


def truth_term(p: Node, compiler: str) -> Node:
    """The two literal true-on-one compilers in the current archives."""
    if p.tag == "eq":
        return app(CHI, *p.children)
    if p.tag == "bottom":
        return ZERO
    left, right = (truth_term(child, compiler) for child in p.children)
    if compiler == "selector":
        if p.tag == "and":
            return selector(left, ZERO, right)
        if p.tag == "or":
            return selector(left, right, ONE)
        if p.tag == "imp":
            return selector(left, ONE, right)
    if compiler == "q_boolean":
        if p.tag == "and":
            return app(Q, app(Q, left, ONE), right)
        if p.tag == "or":
            return app(Q, app(Q, left, app(Q, right, ONE)), ONE)
        if p.tag == "imp":
            return app(Q, app(Q, right, left), ONE)
    raise ValueError((p.tag, compiler))


X, A, B, N = (var(name) for name in ("x", "a", "b", "n"))


def native_boundary(p: Node) -> Node:
    at_b = substitute(p, {"x": B})
    at_sb = substitute(p, {"x": succ(B)})
    body = conj(disj(eq(B, ZERO), at_b), implies(at_sb, eq(B, N)))
    return forall("a", forall("n", exists("b", body)))


def old_mask_module(
    tail: Node, *, whole_body: bool, shifted: bool, mask_operator: Symbol = Z
) -> tuple[Node, Node]:
    """Explicit mask definition and its actual shifted/unshifted witness."""
    mask_body = app(mask_operator, tail, X)
    mask = Symbol("M", mask_body if whole_body else tail)
    definition = forall("x", forall("a", eq(app(mask, X, A), mask_body)))
    inner_index = succ(B) if shifted else B
    witness_body = eq(app(mask, app(Q, app(mask, inner_index, A), N), A), ZERO)
    witness = forall("a", forall("n", exists("b", witness_body)))
    return definition, witness


def count_pair(formulas: tuple[Node, ...]) -> dict[str, int]:
    return {
        "active": sum(size(p) for p in formulas),
        "full": sum(size(p, True) for p in formulas),
    }


def check_tail(tail: Node) -> dict[str, object]:
    m, t, j = size(tail), size(tail, True), occurrences(tail, "x")
    p = neg(eq(tail, ZERO))
    boundary = native_boundary(p)
    assert size(boundary) == 20 + 2 * m + j
    assert size(boundary, True) == 20 + 2 * t + j
    assert 0 <= j <= m <= t
    profiles = {}
    for whole in (False, True):
        for shifted in (False, True):
            definition, witness = old_mask_module(
                tail, whole_body=whole, shifted=shifted
            )
            counts = count_pair((definition, witness))
            expected_active = m + 20 + int(shifted)
            expected_full = 4 * t + 22 + int(shifted) + 9 * int(whole)
            assert counts == {"active": expected_active, "full": expected_full}
            assert counts["full"] > size(boundary, True)
            profiles[("whole" if whole else "tail") + ("_13" if shifted else "_12")] = counts
    lower_bound = 4 * t + 22
    saving = lower_bound - size(boundary, True)
    assert saving == 2 + 2 * t - j
    assert saving >= 2 + t
    return {
        "tail_active": m,
        "tail_full": t,
        "active_input_occurrences": j,
        "native_raw_tail": count_pair((boundary,)),
        "baseline_profiles": profiles,
        "favorable_baseline_full_lower_bound": lower_bound,
        "native_full_saving": saving,
    }


def check_formula(p: Node) -> dict[str, object]:
    active, full, j = size(p), size(p, True), occurrences(p, "x")
    boundary = native_boundary(p)
    assert size(boundary) == 12 + 2 * active + j
    assert size(boundary, True) == 12 + 2 * full + j
    assert 0 <= j <= active <= full
    compiled = {}
    for compiler in ("selector", "q_boolean"):
        tail = truth_term(p, compiler)
        assert occurrences(tail, "x") == j
        assert size(tail) >= active
        assert size(tail, True) >= full
        report = check_tail(tail)
        lower_bound = 4 * size(tail, True) + 22
        saving = lower_bound - size(boundary, True)
        assert saving >= 10 + 2 * size(tail, True) - j
        assert saving >= 10 + size(tail, True)
        report["native_formula_full_saving"] = saving
        compiled[compiler] = report
    return {
        "formula_active": active,
        "formula_full": full,
        "active_input_occurrences": j,
        "native_formula": count_pair((boundary,)),
        "compilers": compiled,
    }


def main() -> None:
    # A nested description deliberately uses the same letter as an active
    # variable. Its occurrence is counted in full size but is never shifted.
    nested_symbol = Symbol("R_nested", app(Q, var("x"), app(Z, var("a"), ZERO)))
    nested_term = app(nested_symbol, X, A)
    assert occurrences(nested_term, "x") == 1
    shifted_nested = substitute(nested_term, {"x": succ(X)})
    assert shifted_nested.symbol is nested_symbol
    assert size(shifted_nested, True) == size(nested_term, True) + 1

    separation = neg(eq(ZERO, ONE))
    bit = forall("x", forall("a", conj(eq(app(CHI, X, X), ONE),
                                            disj(eq(X, A), eq(app(CHI, X, A), ZERO)))))
    partition = forall("x", exists("a", neg(eq(app(CHI, X, ZERO),
                                                 app(CHI, X, succ(A))))))
    assert size(separation, True) == 6
    assert size(bit, True) == 18
    assert size(partition, True) == 12

    long_term = X
    for _ in range(15):
        long_term = succ(long_term)
    examples = {
        "falsity": BOTTOM,
        "x_equals_a": eq(X, A),
        "two_equalities": conj(eq(X, A), eq(X, ZERO)),
        "implication": implies(eq(X, A), eq(succ(X), succ(A))),
        "nested_frozen_description": eq(nested_term, X),
        "active_size_tradeoff": eq(long_term, A),
    }
    reports = {name: check_formula(p) for name, p in examples.items()}
    tradeoff = reports["active_size_tradeoff"]
    assert tradeoff["native_formula"]["active"] > (
        tradeoff["compilers"]["selector"]["baseline_profiles"]["tail_13"]["active"]
    )

    rng = random.Random(20261102)
    term_pool = [X, A, ZERO, ONE, nested_term]
    for _ in range(80):
        left, right = rng.choice(term_pool), rng.choice(term_pool)
        term_pool.append(rng.choice((succ(left), app(Q, left, right), app(Z, left, right))))
    formula_pool = [BOTTOM] + [eq(rng.choice(term_pool), rng.choice(term_pool)) for _ in range(80)]
    for _ in range(360):
        left, right = rng.choice(formula_pool), rng.choice(formula_pool)
        formula_pool.append(rng.choice((conj(left, right), disj(left, right), implies(left, right))))
    for term in term_pool:
        check_tail(term)
    for formula in formula_pool:
        check_formula(formula)

    results = {
        "status": "passed",
        "scope": "Exact syntax-tree size checks; not a proof of bi-interpretability.",
        "snapshot": "4d5474f10e00412135d659dc7a1f74fc6457656a",
        "count_conventions": {
            "active": "One per variable, constant, application, atom, connective, falsity, quantifier.",
            "full": "Active plus each complete frozen descriptor at every generated call, recursively.",
            "negation": "A -> bottom",
            "one": "S(0)",
            "sharing": "None; repeated syntax and descriptors are charged repeatedly.",
        },
        "seed_sizes": {"native_primary": 6, "native_bit_companion": 24,
                       "draft_shifted": 24, "draft_partition_variant": 30},
        "formulas": {
            "native_formula_full": "12 + 2*L + j",
            "native_raw_tail_full": "20 + 2*T + j",
            "counterexample_tail_13_module": "23 + 4*T",
            "counterexample_tail_12_module": "22 + 4*T",
            "whole_body_13_module": "32 + 4*T",
            "whole_body_12_module": "31 + 4*T",
            "uniform_raw_tail_saving_at_least": "2 + 2*T - j >= 2 + T > 0",
            "uniform_formula_saving_at_least": "10 + 2*T - j >= 10 + T > 0, because T >= L >= j",
        },
        "important_limits": [
            "The complete induction module includes its mask definition, not only its witness.",
            "The 12-node baseline is granted even when its extra fixed coverage basis is not charged.",
            "The common earlier arithmetic vocabulary and its frozen-description costs are held fixed.",
            "The native bit companion retains the same chi primitive and bit seed for raw-tail matching.",
            "The comparison is for literal readable recipes, not arbitrary logical simplification or emitter addresses.",
            "The current marked-predecessor emitter can print 0=0; that isolated output is not an induction module.",
            "Active-size domination is false; an explicit counterexample is included.",
            "Finite generated examples check implementations; the general inequalities require the written proof.",
        ],
        "test_counts": {"generated_terms": len(term_pool), "generated_formulas": len(formula_pool),
                        "named_examples": len(examples)},
        "examples": reports,
    }
    destination = Path(__file__).with_name("size_results.json")
    destination.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "generated_terms": len(term_pool),
                      "generated_formulas": len(formula_pool), "output": str(destination)}))


if __name__ == "__main__":
    main()
