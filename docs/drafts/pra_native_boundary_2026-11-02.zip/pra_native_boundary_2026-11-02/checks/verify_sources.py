#!/usr/bin/env python3
"""Optionally download and verify the six immutable comparison archives.

Network access is required. Files are written only when --destination is
provided. The manifest fixes every URL, byte size, Git blob ID, and SHA-256.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import urllib.request


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path)
    arguments = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "provenance/sources.json").read_text())
    if arguments.destination:
        arguments.destination.mkdir(parents=True, exist_ok=True)
    for item in manifest["archives"]:
        with urllib.request.urlopen(item["immutable_download_url"], timeout=60) as response:
            data = response.read()
        assert len(data) == item["size_bytes"], item["name"]
        git_blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert git_blob == item["git_blob_sha1"], item["name"]
        assert hashlib.sha256(data).hexdigest() == item["sha256"], item["name"]
        if arguments.destination:
            (arguments.destination / item["name"]).write_bytes(data)
        print("Verified", item["name"])


if __name__ == "__main__":
    main()
