/-!
# Recovering an equality bit from an elementary arithmetic ledger

This file works on an arbitrary carrier. It does not import natural-number
arithmetic or assume an equality bit. The elementary ledger below lists the
identities proved in the report using at most one fixed induction parameter.
Those ledger proofs and their quantifier-free syntactic admissibility are not
formalized here.

The only induction premise used below is the explicit induction instance for
`ReconstructionPredicate`, separately for each fixed parameter `x`. We check
its base and step, the reconstruction conclusion, subtraction antisymmetry,
the derived bit's range and exactness, and the disjunction expressing
decidability of native equality. No general induction principle is assumed.

All assumptions are theorem parameters, not additional Lean axioms. Checked
with Lean 4.19.0 and its core library. This is a partial verification of the
report's arithmetic bootstrap, not a formalization of bi-interpretability.
-/

namespace EqualityBootstrap

variable {α : Type u}

structure ArithmeticData (α : Type u) where
  zero : α
  succ : α → α
  pred : α → α
  add : α → α → α
  sub : α → α → α
  zeroTest : α → α → α

/-- Identities supplied by the report's preceding elementary ledger. -/
structure ElementaryLedger (arithmetic : ArithmeticData α) : Prop where
  separation : arithmetic.zero ≠ arithmetic.succ arithmetic.zero
  pred_zero : arithmetic.pred arithmetic.zero = arithmetic.zero
  pred_succ : ∀ x, arithmetic.pred (arithmetic.succ x) = x
  add_zero_right : ∀ x, arithmetic.add x arithmetic.zero = x
  add_zero_left : ∀ x, arithmetic.add arithmetic.zero x = x
  add_succ_right : ∀ x y,
    arithmetic.add x (arithmetic.succ y) = arithmetic.succ (arithmetic.add x y)
  add_succ_left : ∀ x y,
    arithmetic.add (arithmetic.succ x) y = arithmetic.succ (arithmetic.add x y)
  sub_zero_right : ∀ x, arithmetic.sub x arithmetic.zero = x
  sub_succ_right : ∀ x y,
    arithmetic.sub x (arithmetic.succ y) = arithmetic.pred (arithmetic.sub x y)
  sub_pred_left : ∀ x y,
    arithmetic.sub (arithmetic.pred x) y = arithmetic.pred (arithmetic.sub x y)
  sub_diagonal : ∀ x, arithmetic.sub x x = arithmetic.zero
  sub_succ_diagonal : ∀ x,
    arithmetic.sub (arithmetic.succ x) x = arithmetic.succ arithmetic.zero
  coverage : ∀ x,
    x = arithmetic.zero ∨ x = arithmetic.succ (arithmetic.pred x)
  zeroTest_zero : ∀ initial, arithmetic.zeroTest arithmetic.zero initial = initial
  zeroTest_succ : ∀ x initial,
    arithmetic.zeroTest (arithmetic.succ x) initial = arithmetic.zero

/-- Successor nonzeroness needs only the predecessor equations and separation. -/
theorem succ_ne_zero (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic) (x : α) :
    arithmetic.succ x ≠ arithmetic.zero := by
  intro successor_zero
  have x_zero : x = arithmetic.zero := by
    calc
      x = arithmetic.pred (arithmetic.succ x) := (ledger.pred_succ x).symm
      _ = arithmetic.pred arithmetic.zero := congrArg arithmetic.pred successor_zero
      _ = arithmetic.zero := ledger.pred_zero
  have one_zero : arithmetic.succ arithmetic.zero = arithmetic.zero := by
    calc
      arithmetic.succ arithmetic.zero = arithmetic.succ x :=
        congrArg arithmetic.succ x_zero.symm
      _ = arithmetic.zero := successor_zero
  exact ledger.separation one_zero.symm

/-- The quantifier-free predicate to which the sole induction premise applies. -/
def ReconstructionPredicate (arithmetic : ArithmeticData α) (x y : α) : Prop :=
  arithmetic.sub y x = arithmetic.zero →
    x = arithmetic.add y (arithmetic.sub x y)

theorem reconstruction_base (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic) (x : α) :
    ReconstructionPredicate arithmetic x arithmetic.zero := by
  intro _
  calc
    x = arithmetic.add arithmetic.zero x := (ledger.add_zero_left x).symm
    _ = arithmetic.add arithmetic.zero (arithmetic.sub x arithmetic.zero) :=
      congrArg (arithmetic.add arithmetic.zero) (ledger.sub_zero_right x).symm

/-- The critical reconstruction step, with `x` the only fixed parameter. -/
theorem reconstruction_step (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic) (x y : α)
    (previous : ReconstructionPredicate arithmetic x y) :
    ReconstructionPredicate arithmetic x (arithmetic.succ y) := by
  intro successor_difference_zero
  have previous_difference_zero : arithmetic.sub y x = arithmetic.zero := by
    calc
      arithmetic.sub y x = arithmetic.sub (arithmetic.pred (arithmetic.succ y)) x :=
        congrArg (fun value => arithmetic.sub value x) (ledger.pred_succ y).symm
      _ = arithmetic.pred (arithmetic.sub (arithmetic.succ y) x) :=
        ledger.sub_pred_left (arithmetic.succ y) x
      _ = arithmetic.pred arithmetic.zero :=
        congrArg arithmetic.pred successor_difference_zero
      _ = arithmetic.zero := ledger.pred_zero
  have reconstructed : x = arithmetic.add y (arithmetic.sub x y) :=
    previous previous_difference_zero
  cases ledger.coverage (arithmetic.sub x y) with
  | inl remainder_zero =>
    have x_eq_y : x = y := by
      calc
        x = arithmetic.add y (arithmetic.sub x y) := reconstructed
        _ = arithmetic.add y arithmetic.zero := congrArg (arithmetic.add y) remainder_zero
        _ = y := ledger.add_zero_right y
    have one_zero : arithmetic.succ arithmetic.zero = arithmetic.zero := by
      calc
        arithmetic.succ arithmetic.zero = arithmetic.sub (arithmetic.succ y) y :=
          (ledger.sub_succ_diagonal y).symm
        _ = arithmetic.sub (arithmetic.succ y) x :=
          congrArg (arithmetic.sub (arithmetic.succ y)) x_eq_y.symm
        _ = arithmetic.zero := successor_difference_zero
    exact False.elim (ledger.separation one_zero.symm)
  | inr remainder_successor =>
    calc
      x = arithmetic.add y (arithmetic.sub x y) := reconstructed
      _ = arithmetic.add y (arithmetic.succ (arithmetic.pred (arithmetic.sub x y))) :=
        congrArg (arithmetic.add y) remainder_successor
      _ = arithmetic.succ (arithmetic.add y (arithmetic.pred (arithmetic.sub x y))) :=
        ledger.add_succ_right y (arithmetic.pred (arithmetic.sub x y))
      _ = arithmetic.add (arithmetic.succ y) (arithmetic.pred (arithmetic.sub x y)) :=
        (ledger.add_succ_left y (arithmetic.pred (arithmetic.sub x y))).symm
      _ = arithmetic.add (arithmetic.succ y) (arithmetic.sub x (arithmetic.succ y)) :=
        congrArg (arithmetic.add (arithmetic.succ y)) (ledger.sub_succ_right x y).symm

/-- Exactly one family of induction instances, with one fixed parameter. -/
def ReconstructionInduction (arithmetic : ArithmeticData α) : Prop :=
  ∀ x,
    ReconstructionPredicate arithmetic x arithmetic.zero →
    (∀ y, ReconstructionPredicate arithmetic x y →
      ReconstructionPredicate arithmetic x (arithmetic.succ y)) →
    ∀ y, ReconstructionPredicate arithmetic x y

theorem reconstruction (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic)
    (induction_for_reconstruction : ReconstructionInduction arithmetic) :
    ∀ x y, arithmetic.sub y x = arithmetic.zero →
      x = arithmetic.add y (arithmetic.sub x y) := by
  intro x
  exact induction_for_reconstruction x (reconstruction_base arithmetic ledger x)
    (reconstruction_step arithmetic ledger x)

theorem subtraction_antisymmetry (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic)
    (induction_for_reconstruction : ReconstructionInduction arithmetic)
    (x y : α) (forward_zero : arithmetic.sub x y = arithmetic.zero)
    (reverse_zero : arithmetic.sub y x = arithmetic.zero) : x = y := by
  calc
    x = arithmetic.add y (arithmetic.sub x y) :=
      reconstruction arithmetic ledger induction_for_reconstruction x y reverse_zero
    _ = arithmetic.add y arithmetic.zero := congrArg (arithmetic.add y) forward_zero
    _ = y := ledger.add_zero_right y

theorem sum_zero_iff (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic) (x y : α) :
    arithmetic.add x y = arithmetic.zero ↔
      x = arithmetic.zero ∧ y = arithmetic.zero := by
  constructor
  · intro sum_zero
    cases ledger.coverage y with
    | inl y_zero =>
      have x_zero : x = arithmetic.zero := by
        calc
          x = arithmetic.add x arithmetic.zero := (ledger.add_zero_right x).symm
          _ = arithmetic.add x y := congrArg (arithmetic.add x) y_zero.symm
          _ = arithmetic.zero := sum_zero
      exact ⟨x_zero, y_zero⟩
    | inr y_successor =>
      have successor_zero :
          arithmetic.succ (arithmetic.add x (arithmetic.pred y)) = arithmetic.zero := by
        calc
          arithmetic.succ (arithmetic.add x (arithmetic.pred y)) =
              arithmetic.add x (arithmetic.succ (arithmetic.pred y)) :=
            (ledger.add_succ_right x (arithmetic.pred y)).symm
          _ = arithmetic.add x y := congrArg (arithmetic.add x) y_successor.symm
          _ = arithmetic.zero := sum_zero
      exact False.elim
        (succ_ne_zero arithmetic ledger (arithmetic.add x (arithmetic.pred y)) successor_zero)
  · intro both_zero
    calc
      arithmetic.add x y = arithmetic.add x arithmetic.zero :=
        congrArg (arithmetic.add x) both_zero.2
      _ = x := ledger.add_zero_right x
      _ = arithmetic.zero := both_zero.1

theorem zeroTest_range (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic) (input : α) :
    arithmetic.zeroTest input (arithmetic.succ arithmetic.zero) = arithmetic.zero ∨
      arithmetic.zeroTest input (arithmetic.succ arithmetic.zero) =
        arithmetic.succ arithmetic.zero := by
  cases ledger.coverage input with
  | inl input_zero =>
    right
    calc
      arithmetic.zeroTest input (arithmetic.succ arithmetic.zero) =
          arithmetic.zeroTest arithmetic.zero (arithmetic.succ arithmetic.zero) :=
        congrArg (fun value => arithmetic.zeroTest value (arithmetic.succ arithmetic.zero))
          input_zero
      _ = arithmetic.succ arithmetic.zero := ledger.zeroTest_zero _
  | inr input_successor =>
    left
    calc
      arithmetic.zeroTest input (arithmetic.succ arithmetic.zero) =
          arithmetic.zeroTest (arithmetic.succ (arithmetic.pred input))
            (arithmetic.succ arithmetic.zero) :=
        congrArg (fun value => arithmetic.zeroTest value (arithmetic.succ arithmetic.zero))
          input_successor
      _ = arithmetic.zero := ledger.zeroTest_succ _ _

theorem zeroTest_one_iff (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic) (input : α) :
    arithmetic.zeroTest input (arithmetic.succ arithmetic.zero) =
        arithmetic.succ arithmetic.zero ↔ input = arithmetic.zero := by
  constructor
  · intro test_one
    cases ledger.coverage input with
    | inl input_zero => exact input_zero
    | inr input_successor =>
      have test_zero :
          arithmetic.zeroTest input (arithmetic.succ arithmetic.zero) = arithmetic.zero := by
        calc
          arithmetic.zeroTest input (arithmetic.succ arithmetic.zero) =
              arithmetic.zeroTest (arithmetic.succ (arithmetic.pred input))
                (arithmetic.succ arithmetic.zero) :=
            congrArg
              (fun value => arithmetic.zeroTest value (arithmetic.succ arithmetic.zero))
              input_successor
          _ = arithmetic.zero := ledger.zeroTest_succ _ _
      exact False.elim (ledger.separation (test_zero.symm.trans test_one))
  · intro input_zero
    calc
      arithmetic.zeroTest input (arithmetic.succ arithmetic.zero) =
          arithmetic.zeroTest arithmetic.zero (arithmetic.succ arithmetic.zero) :=
        congrArg (fun value => arithmetic.zeroTest value (arithmetic.succ arithmetic.zero))
          input_zero
      _ = arithmetic.succ arithmetic.zero := ledger.zeroTest_zero _

/-- A finite numerical term, not an additional primitive arithmetic symbol. -/
def equalityBit (arithmetic : ArithmeticData α) (x y : α) : α :=
  arithmetic.zeroTest
    (arithmetic.add (arithmetic.sub x y) (arithmetic.sub y x))
    (arithmetic.succ arithmetic.zero)

theorem equalityBit_range (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic) (x y : α) :
    equalityBit arithmetic x y = arithmetic.zero ∨
      equalityBit arithmetic x y = arithmetic.succ arithmetic.zero := by
  exact zeroTest_range arithmetic ledger
    (arithmetic.add (arithmetic.sub x y) (arithmetic.sub y x))

theorem equalityBit_one_iff (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic)
    (induction_for_reconstruction : ReconstructionInduction arithmetic) (x y : α) :
    equalityBit arithmetic x y = arithmetic.succ arithmetic.zero ↔ x = y := by
  constructor
  · intro bit_one
    have sum_zero := (zeroTest_one_iff arithmetic ledger
      (arithmetic.add (arithmetic.sub x y) (arithmetic.sub y x))).mp bit_one
    have differences_zero := (sum_zero_iff arithmetic ledger
      (arithmetic.sub x y) (arithmetic.sub y x)).mp sum_zero
    exact subtraction_antisymmetry arithmetic ledger induction_for_reconstruction x y
      differences_zero.1 differences_zero.2
  · intro same
    cases same
    apply (zeroTest_one_iff arithmetic ledger
      (arithmetic.add (arithmetic.sub x x) (arithmetic.sub x x))).mpr
    exact (sum_zero_iff arithmetic ledger (arithmetic.sub x x) (arithmetic.sub x x)).mpr
      ⟨ledger.sub_diagonal x, ledger.sub_diagonal x⟩

theorem equalityBit_zero_iff (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic)
    (induction_for_reconstruction : ReconstructionInduction arithmetic) (x y : α) :
    equalityBit arithmetic x y = arithmetic.zero ↔ x ≠ y := by
  constructor
  · intro bit_zero same
    have bit_one :=
      (equalityBit_one_iff arithmetic ledger induction_for_reconstruction x y).mpr same
    exact ledger.separation (bit_zero.symm.trans bit_one)
  · intro different
    cases equalityBit_range arithmetic ledger x y with
    | inl bit_zero => exact bit_zero
    | inr bit_one =>
      have same :=
        (equalityBit_one_iff arithmetic ledger induction_for_reconstruction x y).mp bit_one
      exact False.elim (different same)

theorem native_equality_decidable (arithmetic : ArithmeticData α)
    (ledger : ElementaryLedger arithmetic)
    (induction_for_reconstruction : ReconstructionInduction arithmetic) (x y : α) :
    x = y ∨ x ≠ y := by
  cases equalityBit_range arithmetic ledger x y with
  | inl bit_zero =>
    exact Or.inr
      ((equalityBit_zero_iff arithmetic ledger induction_for_reconstruction x y).mp bit_zero)
  | inr bit_one =>
    exact Or.inl
      ((equalityBit_one_iff arithmetic ledger induction_for_reconstruction x y).mp bit_one)

#print axioms succ_ne_zero
#print axioms reconstruction_base
#print axioms reconstruction_step
#print axioms reconstruction
#print axioms subtraction_antisymmetry
#print axioms sum_zero_iff
#print axioms zeroTest_range
#print axioms zeroTest_one_iff
#print axioms equalityBit_range
#print axioms equalityBit_one_iff
#print axioms equalityBit_zero_iff
#print axioms native_equality_decidable

end EqualityBootstrap
