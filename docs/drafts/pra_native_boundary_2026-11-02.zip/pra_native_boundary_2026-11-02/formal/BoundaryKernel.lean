/-!
# A constructive boundary kernel for primitive recursive arithmetic

This file checks the logical kernel of the accompanying report. It does not
formalize the whole generated arithmetic language, its primitive-recursive
compiler, or the full bi-interpretability theorem.

The forward argument works on an arbitrary carrier and uses no decidability
assumption. The reverse one-step argument uses a decidable fixed predicate.
The abstract reverse theorem states its one induction hypothesis explicitly.
The concrete `Nat` realization uses ordinary Lean natural-number induction.

No `sorry`, additional axiom, or classical-choice invocation is used.
Checked with Lean 4.19.0, using only its core library.
-/

namespace NativeBoundary

variable {α : Type u}

/-- The local certificate at an arbitrary target. -/
def Certificate (zero : α) (succ : α → α) (predicate : α → Prop)
    (target witness : α) : Prop :=
  (witness = zero ∨ predicate witness) ∧
    (predicate (succ witness) → witness = target)

/-- The boundary assertion for one fixed predicate. -/
def Boundary (zero : α) (succ : α → α) (predicate : α → Prop) : Prop :=
  ∀ target, ∃ witness, Certificate zero succ predicate target witness

/-- The full induction implication, derived under arbitrary local hypotheses. -/
theorem boundary_implies_induction (zero : α) (succ : α → α)
    (predicate : α → Prop) (boundary : Boundary zero succ predicate)
    (base : predicate zero)
    (step : ∀ value, predicate value → predicate (succ value)) :
    ∀ target, predicate target := by
  intro target
  obtain ⟨witness, good, forces_target⟩ := boundary target
  have at_witness : predicate witness := by
    cases good with
    | inl at_zero => simpa only [at_zero] using base
    | inr holds => exact holds
  have witness_eq_target : witness = target :=
    forces_target (step witness at_witness)
  simpa only [witness_eq_target] using at_witness

/-- Parameters remain arbitrary; no premise is required to be a theorem. -/
theorem boundary_family_implies_induction {β : Type v}
    (zero : α) (succ : α → α) (predicate : α → β → Prop)
    (boundary : ∀ parameter, Boundary zero succ (fun x => predicate x parameter)) :
    ∀ parameter,
      (predicate zero parameter ∧
        ∀ value, predicate value parameter → predicate (succ value) parameter) →
      ∀ target, predicate target parameter := by
  intro parameter assumptions
  exact boundary_implies_induction zero succ (fun x => predicate x parameter)
    (boundary parameter) assumptions.1 assumptions.2

/-- The zero target has a certificate without testing the predicate. -/
theorem certificate_zero (zero : α) (succ : α → α) (predicate : α → Prop) :
    Certificate zero succ predicate zero zero := by
  exact ⟨Or.inl rfl, fun _ => rfl⟩

/-- A single candidate update preserves the certificate invariant. -/
theorem certificate_step (zero : α) (succ : α → α) (predicate : α → Prop)
    [DecidablePred predicate] (target witness : α)
    (previous : Certificate zero succ predicate target witness) :
    Certificate zero succ predicate (succ target)
      (if predicate (succ witness) then succ target else witness) := by
  by_cases positive : predicate (succ witness)
  · rw [if_pos positive]
    have witness_eq_target : witness = target := previous.2 positive
    constructor
    · right
      simpa only [witness_eq_target] using positive
    · intro _
      rfl
  · rw [if_neg positive]
    exact ⟨previous.1, fun impossible => False.elim (positive impossible)⟩

/--
The reverse proof requires only induction on this explicit invariant.
The premise below is an assumption about the arbitrary carrier, not an axiom
added to Lean and not an implicit use of natural-number induction.
-/
theorem abstract_candidate_correct (zero : α) (succ : α → α)
    (predicate : α → Prop) [DecidablePred predicate] (candidate : α → α)
    (candidate_zero : candidate zero = zero)
    (candidate_succ : ∀ target,
      candidate (succ target) =
        if predicate (succ (candidate target)) then succ target else candidate target)
    (induction_for_invariant :
      Certificate zero succ predicate zero (candidate zero) →
      (∀ target,
        Certificate zero succ predicate target (candidate target) →
        Certificate zero succ predicate (succ target) (candidate (succ target))) →
      ∀ target, Certificate zero succ predicate target (candidate target)) :
    Boundary zero succ predicate := by
  have base : Certificate zero succ predicate zero (candidate zero) := by
    simpa only [candidate_zero] using certificate_zero zero succ predicate
  have step : ∀ target,
      Certificate zero succ predicate target (candidate target) →
      Certificate zero succ predicate (succ target) (candidate (succ target)) := by
    intro target previous
    rw [candidate_succ target]
    exact certificate_step zero succ predicate target (candidate target) previous
  intro target
  exact ⟨candidate target, induction_for_invariant base step target⟩

/-- The primitive-recursive candidate used in the reverse interpretation. -/
def candidate (predicate : Nat → Prop) [DecidablePred predicate] : Nat → Nat
  | 0 => 0
  | Nat.succ target =>
      if predicate (Nat.succ (candidate predicate target)) then Nat.succ target
      else candidate predicate target

/-- Its complete invariant is established by ordinary natural induction. -/
theorem candidate_correct (predicate : Nat → Prop) [DecidablePred predicate] :
    ∀ target, Certificate 0 Nat.succ predicate target (candidate predicate target) := by
  intro target
  induction target with
  | zero => exact certificate_zero 0 Nat.succ predicate
  | succ target previous =>
    exact certificate_step 0 Nat.succ predicate target (candidate predicate target) previous

/-- A concrete witness for every decidable predicate on the natural numbers. -/
theorem nat_boundary (predicate : Nat → Prop) [DecidablePred predicate] :
    Boundary 0 Nat.succ predicate := by
  intro target
  exact ⟨candidate predicate target, candidate_correct predicate target⟩

#print axioms boundary_implies_induction
#print axioms boundary_family_implies_induction
#print axioms certificate_zero
#print axioms certificate_step
#print axioms abstract_candidate_correct
#print axioms candidate_correct
#print axioms nat_boundary

end NativeBoundary
