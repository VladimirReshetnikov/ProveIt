"""Rebuild report.pdf using an installed TeX distribution."""
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def run(command, cwd):
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-12000:] + result.stderr[-12000:])
    return result.stdout


def typeset(extra):
    for _ in range(2):
        run(["pdflatex", *extra, "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "report.tex"], ROOT)
    print("Built " + str(ROOT / "report.pdf"))


if __name__ == "__main__":
    if shutil.which("pdflatex") is None:
        raise SystemExit("Install a TeX distribution with pdflatex, then rerun.")
    found = subprocess.run(["kpsewhich", "pdflatex.fmt"], text=True,
                           capture_output=True).stdout.strip()
    if found:
        typeset([])
    else:
        with tempfile.TemporaryDirectory(prefix="ipra-tex-format-") as directory:
            run(["pdftex", "-ini", "-jobname=pdflatex", "-progname=pdflatex",
                 "-etex", "pdflatex.ini"], directory)
            typeset(["-fmt=" + str(Path(directory) / "pdflatex.fmt")])
