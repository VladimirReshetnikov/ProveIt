These JSON files are complete certificates for either new checker.

At the package root:
    python3 checker.py examples/reflexivity.json
    python3 checker.py examples/automatic_collision.json

The second example intentionally starts with an ordinary Pi-introduction
whose guard equals the consequent at zero. The translated certificate uses
the closed-zero-redex detour and equality transport. It also exercises a
Boolean hypothesis-index alias. The exterior sequent is unchanged.

The remaining arithmetic and logical examples are translated from the 18
frozen examples in the supplied reduction draft. They include coverage,
successor injectivity, the equality detector, and quantified existential
claims. They are checked by both targets during reproduction.
