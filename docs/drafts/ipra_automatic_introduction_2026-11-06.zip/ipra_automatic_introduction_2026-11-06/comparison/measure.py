"""Recount whole acceptance programs with identical boundaries, offline.

Only comments and module/function/class docstrings are removed. No CLI,
syntax table, function, identifier or logical rule is omitted or rewritten.
"""
import ast,csv,hashlib,io,json,platform,sys,tokenize
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
IGNORED={tokenize.ENCODING,tokenize.COMMENT,tokenize.NL,tokenize.NEWLINE,tokenize.INDENT,tokenize.DEDENT,tokenize.ENDMARKER}
FIELDS=('source_tokens','normalized_tokens','ast_nodes','normalized_bytes','raw_bytes')

def measure(path):
    raw=path.read_bytes();source=raw.decode('utf-8');tree=ast.parse(source);spans=[]
    for node in ast.walk(tree):
        if isinstance(node,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and node.body and isinstance(node.body[0],ast.Expr) and isinstance(node.body[0].value,ast.Constant) and isinstance(node.body[0].value.value,str):
            doc=node.body.pop(0);spans.append(((doc.lineno,doc.col_offset),(doc.end_lineno,doc.end_col_offset)))
    normalized=ast.unparse(tree)+'\n'
    def count(text,omitted=()):
        return sum(token.type not in IGNORED and not any(start<=token.start and token.end<=end for start,end in omitted) for token in tokenize.generate_tokens(io.StringIO(text).readline))
    return {'source':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(raw).hexdigest(),'source_tokens':count(source,spans),'normalized_tokens':count(normalized),'ast_nodes':sum(1 for _ in ast.walk(tree)),'normalized_bytes':len(normalized.encode('utf-8')),'raw_bytes':len(raw)}

def main():
    manifest=json.loads((ROOT/'comparison/manifest.json').read_text())
    baselines=[]
    for entry in manifest['baselines']:
        row=measure(ROOT/entry['source'])
        if row['sha256']!=entry['source_sha256']:
            raise ValueError('Modified baseline: '+entry['source'])
        baselines.append(row)
    envelope={key:min(row[key] for row in baselines) for key in FIELDS}
    candidates={name:measure(ROOT/path) for name,path in [('strict','checker.py'),('companion','checker_demand.py')]}
    comparisons={name:{key:row[key]<envelope[key] for key in FIELDS} for name,row in candidates.items()}
    result={'python':sys.version,'python_version':platform.python_version(),'repository':manifest['repository'],'commit':manifest['commit'],'boundary':'Entire Python acceptance program including syntax, scope tables, arithmetic, logic, JSON and CLI. Only comments and docstrings excluded from primary measures. Raw bytes supplementary.','baselines':baselines,'envelope':envelope,'candidates':candidates,'strictly_below':comparisons}
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    with (ROOT/'results/metrics.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=['source','sha256',*FIELDS]);writer.writeheader();writer.writerows([*baselines,*candidates.values()])
    if not all(all(row.values()) for row in comparisons.values()):
        raise ValueError('A candidate no longer strictly beats every comparison coordinate')
    print(json.dumps({'measurement':'passed','baselines':len(baselines),'envelope':envelope,'candidates':{name:{key:row[key] for key in FIELDS} for name,row in candidates.items()}},indent=2))
    return result

if __name__=='__main__':main()
