"""Offline replay of 327 constructive-translation checks.

These are explicitly counted runs, not 327 distinct theorems: 194 frozen
proofs, 126 generated parameter combinations, one named regression, and six
irrelevant-witness reconstruction cases. The two targets see the same output.
"""
import collections,hashlib,json
from pathlib import Path
from support import ROOT,goal_corpus,load,accepted
from translate import old,s,eq,translate_data
TARGETS={'strict':ROOT/'checker.py','companion':ROOT/'checker_demand.py'}
modules={name:load(path,'translation_target_'+name) for name,path in TARGETS.items()}
records=[]

def check(name,kind,data):
    a,p,*g=data
    for h in g:s(h)
    old.check(a,p,g)
    translated=translate_data(data)
    if translated[0]!=a or translated[2:]!=g:
        raise ValueError('Translation changed the sequent: '+name)
    outcomes={name:accepted(module,translated) for name,module in modules.items()}
    if not all(outcomes.values()):raise ValueError((name,outcomes))
    records.append({'name':name,'kind':kind,'accepted_by_both':True,'exact_sequent_preserved':True})
    return translated

def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')

for filename,data,entry in goal_corpus(strict=True):
    translated=check(filename,'frozen',data)
    if filename.startswith('example_'):
        write(ROOT/'examples'/filename[len('example_'):],translated)

T=['=',-1,-1]
reflexivity=['use',eq,'r',['=',0,-1],'r']
def raise_n(a,n):
    for _ in range(n):a=s(a)
    return a

def nested_collision(b,depth,selector):
    h=s(b,[-1,0]);a=['pi',h,b]
    def body(d):
        if d==depth:return ['use',raise_n(a,d+1),0,d,selector]
        goal=raise_n(b,d)
        dummy=['pi',T,s(goal)]
        return ['use',dummy,['lam',body(d+1)],-1,reflexivity]
    return [a,['lam',body(0)],a]

bodies=[
    ['=',0,['s',-1]],
    ['=',['r',1,1,2],1],
    ['ex',['=',1,2]],
    ['pi',['=',2,2],['=',1,2]],
    ['pi',['=',2,2],['ex',['=',['r',3,3,4],3]]],
    ['=',1,1],
    ['pi',['=',1,1],['=',2,2]],
]
for i,b in enumerate(bodies):
    for depth in range(6):
        # There are depth+2 context entries at the selected use. The retained
        # outer guard stays at positive index 1, hence negative index -(d+1).
        for label,selector in [('positive',1),('negative',-(depth+1)),('boolean',True)]:
            data=nested_collision(b,depth,selector)
            result=check(f'body{i}_depth{depth}_{label}','nested_collision',data)
            if i==0 and depth==0 and label=='boolean':write(ROOT/'examples/automatic_collision.json',result)

b=['=',0,['s',-1]];h=s(b,[-1,0]);a=['pi',h,b]
alias=[a,['lam',['use',s(a),0,0,True]],a]
check('boolean_hypothesis_alias','regression',alias)
write(ROOT/'validation/ordinary_collision.json',alias)
for payload in (None,True,3.5,'unused',{},['r',-1,None,-1]):
    major=['pi',T,T]
    check(repr(payload),'irrelevant_witness_reconstruction',[T,['use',major,0,payload,1],major,T])

counts=dict(collections.Counter(r['kind'] for r in records))
if counts!={'frozen':194,'nested_collision':126,'regression':1,'irrelevant_witness_reconstruction':6}:
    raise ValueError(('Unexpected run count',counts))
report={'status':'passed','total_runs':len(records),'groups':counts,'failures':[],'records':records,'translator_sha256':hashlib.sha256((Path(__file__).with_name('translate.py')).read_bytes()).hexdigest(),'target_sha256':{name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in TARGETS.items()},'qualification':'327 successful translator runs on each target; categories can overlap other audits and need not be distinct sequents or proofs. Universal correctness rests on the written mathematical proof.'}
(ROOT/'results/translation_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('records','translator_sha256','target_sha256','qualification')},indent=2))
