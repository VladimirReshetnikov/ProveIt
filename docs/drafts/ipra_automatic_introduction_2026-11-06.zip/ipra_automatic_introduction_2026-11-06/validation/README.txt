OFFLINE VALIDATION SUPPORT (UNTRUSTED)

Neither checker imports anything in this directory. The complete trusted
acceptance programs are ../checker.py and ../checker_demand.py.

translate.py is the sole packaged forward certificate translator. It adapts
the fixed guard-perturbation construction, handles boolean context-index
aliases, and reconstructs an irrelevant malformed Pi witness with zero.
The source and destination preserve the same numerical variables, goal and
retained hypotheses. untag() removes redundant application tags only after
the proof has been translated.

translation_checks.py performs 327 explicitly classified translator runs on
both targets. It also regenerates the executable examples. These run counts
are not a count of distinct theorems and overlap some independent-audit cases.

audit.py uses automatic_rule_oracle.py, which uses independent named-variable
substitution from frozen/named_oracle.py. It validates positive and negative
rules, the automatic-choice collision, scopes, arithmetic computation,
induction restrictions, exact certificate arities, JSON/CLI errors and
optimized (-O) execution. It also returns accepted automatic proofs to the
ordinary two-mode checker. Ignored malformed witnesses are normalized during
that return to avoid asking the named substitution implementation to process
an irrelevant nonterm.

frozen/ contains only selected unchanged supporting sources and the 256
small source fixtures from the pinned reduction archive. It is not a copy of
the historical nested comparison corpus. Each included source/fixture hash is
verified before use. support.py regenerates the two 194-proof goal corpora
from these files in memory; they are not duplicated in the archive.

Run python3 reproduce.py at the package root, or invoke that script by its
absolute path from any directory. All work uses Python's standard library
and the retained files. No network access is required.
