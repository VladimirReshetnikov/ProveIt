"""Independent audit of both automatic-introduction full acceptance programs.

All source positives are translated by the collision-repair compiler. All
rule expectations are checked independently using named variables, never
using a target substitution routine. Rejection tests cover each acceptance
boundary and the automatic introduction's genuinely different certificate
semantics. The packaged translator handles boolean hypothesis aliases and canonicalizes
unobserved malformed numerical witnesses to zero.
"""
import collections,copy,hashlib,importlib.util,json,random,subprocess,sys,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
from support import FROZEN,fixtures,to_goal,goal_corpus,load,accepted
import goal_audit
import automatic_rule_oracle as independent
import translate as compiler
TARGETS={'companion':ROOT/'checker_demand.py','strict':ROOT/'checker.py'}
modules={name:load(path,'automatic_audit_'+name) for name,path in TARGETS.items()}
old=compiler.old

def accepts(module,data):return accepted(module,data)

def old_accepts(data):
 try:
  a,p,*g=data
  for b in g:old.subst(b)
  old.check(a,p,g);return True
 except Exception:return False

def translate(data):return compiler.translate_data(data)

def erase_modes(p):
 if type(p) is not list:return copy.deepcopy(p)
 p=copy.deepcopy(p)
 if p and p[0] in ('lam','nat') and len(p)>=2:
  p[0]='lam';p[1]=erase_modes(p[1]);return p
 if p and p[0]=='pack' and len(p)>=3:
  p[2]=erase_modes(p[2]);return p
 if p and p[0]=='use' and len(p)>=3:
  _,m,r,*args=p;r=erase_modes(r)
  if type(m) is list and m and m[0]=='ex':args=[erase_modes(q) for q in args]
  elif len(args)>=2:args[1]=erase_modes(args[1])
  return [m,r,*args]
 return p

def erase_data(data):
 if type(data) is list and len(data)>=2:
  a,p,*g=data;return [copy.deepcopy(a),erase_modes(p),*copy.deepcopy(g)]
 return copy.deepcopy(data)

T=['=',-1,-1];F=['=',-1,['s',-1]];P=['pi',T,T];E=['ex',T]
new_cases=[
 ('universal elimination',[T,[P,0,-1,1],P,T],True),
 ('existential scope transition',[T,[E,0,-1],E],True),
 ('existential missing minor',[T,[E,0],E],False),
 ('existential two minors',[T,[E,0,-1,-1],E],False),
 ('existential three minors',[T,[E,0,-1,-1,-1],E],False),
 ('existential fake two-part matrix',[T,[['ex',T,T],0,-1],E],False),
 ('existential fake zero-part matrix',[T,[['ex'],0,-1],E],False),
 ('universal extra minor',[T,[P,0,-1,1,1],P,T],False),
 ('universal missing annotation',[T,[P,0,1],P,T],False),
 ('universal missing major proof',[T,[P],P,T],False),
 ('false major verdict must propagate',[T,[P,0,-1,1],T,T],False),
 ('equality missing motive',[T,[T,0,0],T],False),
 ('equality extra minor',[T,[T,0,T,0,0],T],False),
 ('legacy use tag',[T,['use',E,0,-1],E],False),
 ('legacy nat tag',[['pi',T,T],['nat',-1]],False),
 ('string-valued major',[T,['ex',0,-1],E],False),
 ('one-item intro array',[P,[0],T],False),
 ('outer eigenvariable cannot become local',[['=',0,-1],[['ex',['=',0,-1]],0,-1],['ex',['=',0,-1]]],False),
 ('raised retained context',[['=',0,-1],[E,0,1],E,['=',0,-1]],True),
 ('unraised context forgery',[['=',0,-1],[E,0,-1],E,['=',0,-1]],False),
 ('nested context capture forgery',[['ex',['=',1,-1]],[['ex',['ex',['=',1,-1]]],0,-1],['ex',['ex',['=',1,-1]]]],False),
 ('unused malformed recursor update',[['=',['r',-1,-1,None],-1],'r'],False),
 ('unused malformed recursor initializer',[['=',['r',['s',-1],None,1],-1],'r'],False),
 ('automatic induction false step',[['pi',T,['=',0,-1]],['lam',-1]],False),
 ('malformed unused hypothesis',[T,0,T,['=',True,-1]],False),
 ('auto equation constant matrix',[P,['lam',-1]],True),
 ('auto quantified constant matrix',[['pi',E,E],['lam',-1]],True),
 ('raw unused malformed witness',[T,[P,0,None,1],P,T],{'companion':True,'strict':False}),
 ('raw used malformed witness',[T,[["pi",["=",0,0],T],0,None,1],["pi",["=",0,0],T],T],False),
]

failures=[];records=[];counts=collections.Counter();rules={name:collections.Counter() for name in modules}

def check_case(name,data,expected=None,category='direct',cli=False,filename=None):
 row={'name':name,'category':category,'results':{}}
 for kind,m in modules.items():
  strict=kind=='strict';want=independent.accepted(data,strict)
  if expected is not None and (expected[kind] if type(expected) is dict else expected)!=want:
   failures.append({'name':name,'kind':kind,'reason':'independent expectation disagrees','expected':expected,'oracle':want})
  actual=accepts(m,data);counts[kind+'_'+category]+=1
  result={'expected':want,'actual':actual}
  if actual!=want:failures.append({'name':name,'kind':kind,'reason':'candidate/oracle mismatch','data':data})
  if want:
   rules[kind].update(independent.check(data,strict))
   try:
    a,p,*g=data;restored=[a,independent.to_standard(a,p,g),*g]
    restore_ok=old_accepts(restored)
   except Exception:restore_ok=False
   result['standard_return_accepted']=restore_ok
   if not restore_ok:failures.append({'name':name,'kind':kind,'reason':'standard return rejected','data':data})
  if cli:
   filename.write_text(json.dumps(data)+'\n')
   proc=subprocess.run([sys.executable,str(TARGETS[kind]),str(filename)],capture_output=True,text=True,timeout=15)
   good=proc.returncode==(0 if want else 1) and proc.stdout==('ACCEPT\n' if want else 'REJECT\n') and not proc.stderr
   result['cli_ok']=good;counts[kind+'_cli']+=1
   if not good:failures.append({'name':name,'kind':kind,'reason':'CLI mismatch'})
  row['results'][kind]=result
 records.append(row)
 return row

collisions=[]
s=compiler.s
matrices=[
 ('atomic',['=',0,['s',-1]]),
 ('existential',['ex',['=',1,0]]),
 ('guarded',['pi',['=',1,1],['=',0,1]]),
 ('two_formula_binders',['ex',['pi',['=',2,0],['=',1,2]]]),
 ('recursor_update',['=',['r',1,1,2],1]),
 ('two_recursor_updates',['=',['r',1,1,['r',0,1,4]],1]),
 ('no_zero',['=',1,1]),
 ('constant_zero',['=',-1,-1]),
]
for label,b in matrices:
 h=s(b,[-1,0]);a=['pi',h,b]
 for index_name,index in [('positive',1),('negative',-1),('boolean',True)]:
  p=['lam',['use',s(a),0,0,index]];data=[a,p,a]
  if not old_accepts(data):raise ValueError(('bad collision source',label,index_name))
  translated=translate(data)
  collisions.append({'name':label+'_'+index_name,'source':data,'translated':translated,'naive':erase_data(data)})
# Transport the colliding guard through an extra universal binder.
b=['pi',T,['=',1,['s',-1]]];h=s(b,[-1,0]);a=['pi',h,b]
inside=['use',s(b),['use',s(s(a)),0,1,True],0,-1]
p=['lam',['lam',inside]];data=[a,p,a]
if not old_accepts(data):raise ValueError('bad nested lambda collision source')
collisions.append({'name':'transport_through_nested_pi','source':data,'translated':translate(data),'naive':erase_data(data)})
# Transport through existential elimination and its additional local variable.
b=['ex',['=',1,['s',-1]]];h=s(b,[-1,0]);a=['pi',h,b]
p=['lam',['use',h,True,['use',s(s(a)),0,1,True]]];data=[a,p,a]
if not old_accepts(data):raise ValueError('bad nested existential collision source')
collisions.append({'name':'transport_through_existential_elim','source':data,'translated':translate(data),'naive':erase_data(data)})

with tempfile.TemporaryDirectory(prefix='ipra-auto-audit-',dir=HERE) as temporary:
 filename=Path(temporary)/'case.json'
 direct=goal_audit.direct_cases(False)
 changed_negative=[]
 for c in direct:
  data=translate(c['data']) if c['expected'] else erase_data(c['data'])
  row=check_case('frozen '+c['name'],data,None,'frozen_direct',True,filename)
  if c['expected'] and not row['results']['companion']['actual']:
   failures.append({'name':c['name'],'reason':'source positive lost'})
  if not c['expected'] and any(x['actual'] for x in row['results'].values()):
   changed_negative.append({'name':c['name'],'data':data,'results':row['results']})
 for name,data,expected in new_cases:check_case(name,data,expected,'new_direct',True,filename)
 for c in collisions:
  check_case('collision '+c['name'],c['translated'],True,'collision',True,filename)
  check_case('naive collision '+c['name'],c['naive'],None,'naive_collision',True,filename)
 # Check process/decoder failures and -O on every custom rule test.
 for kind,path in TARGETS.items():
  for label,raw in [('truncated JSON','['),('NaN term','[["=",NaN,-1],0]'),('Infinity in unused hypothesis','[["=",-1,-1],0,["=",-1,-1],["=",Infinity,0]]')]:
   filename.write_text(raw);proc=subprocess.run([sys.executable,str(path),str(filename)],capture_output=True,text=True,timeout=10)
   counts[kind+'_decoder']+=1
   if proc.returncode!=1 or proc.stdout!='REJECT\n' or proc.stderr:failures.append({'name':label,'kind':kind,'reason':'decoder'})
  for label,args in [('no filename',[]),('extra filename',[str(filename),str(filename)]),('missing file',[str(Path(temporary)/'absent')])]:
   proc=subprocess.run([sys.executable,str(path),*args],capture_output=True,text=True,timeout=10)
   counts[kind+'_arguments']+=1
   if proc.returncode!=1 or proc.stdout!='REJECT\n' or proc.stderr:failures.append({'name':label,'kind':kind,'reason':'arguments'})
  for label,data,expected in new_cases:
   filename.write_text(json.dumps(data)+'\n');proc=subprocess.run([sys.executable,'-O',str(path),str(filename)],capture_output=True,text=True,timeout=10)
   counts[kind+'_optimized']+=1
   want=expected[kind] if type(expected) is dict else expected
   if proc.returncode!=(0 if want else 1) or proc.stdout!=('ACCEPT\n' if want else 'REJECT\n') or proc.stderr:failures.append({'name':label,'kind':kind,'reason':'optimized'})

# Regenerate both source corpora from one immutable collection of 256 files.
# The strict compiler normalizes irrelevant source witnesses in either corpus.
for corpus,strict_source in [('source_demand_corpus',False),('source_normalized_corpus',True)]:
 for filename,data,entry in goal_corpus(strict_source):
  translated=translate(data)
  check_case(corpus+'/'+filename,translated,True,corpus)

fixture_rows=[]
for item,data in fixtures():
 if item['expected']['primary']:continue
 row={'name':item['name']}
 try:translated=erase_data(to_goal(data))
 except Exception as e:row.update(translatable=False,reason=type(e).__name__)
 else:
  row.update(translatable=True)
  row['results']=check_case('negative inference '+item['name'],translated,None,'inference_negative')['results']
 fixture_rows.append(row)

# Perturb valid automatic syntax and compare both independent semantics and
# a goal-guided return to the conventional two-mode rules.
rng=random.Random(260611)
seeds=[c['translated'] for c in collisions]+[data for _,data,expected in new_cases if expected]
replacements=[None,False,True,-3,-1,0,1,0.0,'r','use','lam','nat',[],{},['r'],['s',-1],T,F,P,E]
def paths(v,p=()):
 yield p
 if type(v) is list:
  for i,x in enumerate(v):yield from paths(x,(*p,i))
def replaced(v,p,x):
 if not p:return copy.deepcopy(x)
 v=copy.deepcopy(v);w=v
 for i in p[:-1]:w=w[i]
 w[p[-1]]=copy.deepcopy(x);return v
for i in range(1000):
 data=rng.choice(seeds);p=rng.choice(list(paths(data)));data=replaced(data,p,rng.choice(replacements))
 check_case('mutation '+str(i),data,None,'mutation')

summary={'status':'passed' if not failures else 'failed','counts':dict(counts),'direct_cases':len(direct)+len(new_cases),'collision_sources':len(collisions),'source_negative_auto_reclassifications':changed_negative,'negative_inference_translated':sum(r['translatable'] for r in fixture_rows),'negative_inference_untranslatable':[r for r in fixture_rows if not r['translatable']],'negative_inference_auto_accepted':[r for r in fixture_rows if r.get('translatable') and any(x['actual'] for x in r['results'].values())],'failures':failures,'rule_counts':{k:dict(v) for k,v in rules.items()},'program_sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in TARGETS.items()},'compiler_sha256':hashlib.sha256((HERE/'translate.py').read_bytes()).hexdigest(),'qualification':'Finite implementation testing, independent named-variable rule interpretation, and explicit proof translations. These are not a proof-assistant formalization or consistency proof. The untrusted compiler handles boolean aliases and normalizes irrelevant witnesses.'}
(ROOT/'results/independent_audit.json').write_text(json.dumps({**summary,'records':records,'negative_fixture_records':fixture_rows},indent=2)+'\n')
(ROOT/'results/collision_cases.json').write_text(json.dumps(collisions,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('rule_counts','qualification','program_sha256','compiler_sha256')},indent=2))
raise SystemExit(bool(failures))
