"""Independent named-variable rule oracle for the automatic introduction.

The candidate checker is neither imported nor called. Syntax and substitution
come from the independent named-variable implementation in the frozen draft.
"""
from collections import Counter
from named_oracle import valid,named,oracle

def ensure(c):
    if not c:raise ValueError('independent automatic rule check rejected')

def checked(expression,is_formula):
    ensure(valid(expression,is_formula));return expression

def uses_slot(e):
    if not isinstance(e,tuple):return False
    return (e[0]=='free' and e[1]==0) or any(uses_slot(c) for c in e[1:])

def rule(a,p,g,strict,counts):
    checked(a,True)
    if type(p) in (int,bool):
        ensure(-len(g)<=p<len(g) and a==g[p]);counts['assumption']+=1;return
    if p=='r':
        ensure(a[0]=='=' and type(a[1]) is list and a[1][0]=='r')
        _,n,t,h=a[1]
        if n==-1:b=t;counts['computation_zero']+=1
        else:
            ensure(type(n) is list and len(n)==2 and n[0]=='s')
            n=n[1];b=oracle(h,[['r',n,t,h],n,-2],formula=False);counts['computation_successor']+=1
        ensure(b==a[2]);return
    ensure(type(p) is list and len(p)>=2)
    if p[0]=='lam':
        ensure(len(p)==2 and a[0]=='pi')
        _,h,b=a
        if h==oracle(b,[-1,0]):
            if b[0]=='=':h=b;counts['equation_induction']+=1
            else:counts['general_numerical_cases']+=1
            b=oracle(b,[['s',0],0])
        else:counts['ordinary_guarded_intro']+=1
        rule(b,p[1],[*[oracle(x) for x in g],h],strict,counts);return
    if p[0]=='pack':
        ensure(len(p)==3 and a[0]=='ex')
        t=checked(p[1],False)
        h=['=',0,oracle(t,formula=False)]
        rule(a[1],p[2],[*[oracle(x) for x in g],h],strict,counts);counts['existential_intro']+=1;return
    ensure(type(p[0]) is list)
    major=checked(p[0],True)
    rule(major,p[1],g,strict,counts)
    if major[0]=='ex':
        ensure(len(p)==3)
        rule(oracle(a),p[2],[*[oracle(x) for x in g],major[1]],strict,counts)
        counts['existential_elim']+=1;return
    ensure(len(p)==4)
    t,q=p[2:]
    if major[0]=='pi':
        used=any(uses_slot(named(part)) for part in major[1:])
        witness=checked(t,False) if strict or used else -1
        b,c=(oracle(part,[witness,-1]) for part in major[1:])
        counts['guarded_elim']+=1
    else:
        ensure(major[0]=='=');checked(t,True)
        b,c=(oracle(t,[part,-1]) for part in major[1:]);counts['equality_transport']+=1
    ensure(c==a)
    rule(b,q,g,strict,counts)

def check(data,strict=False):
    ensure(type(data) is list and len(data)>=2)
    a,p,*g=data
    for h in g:checked(h,True)
    counts=Counter();rule(a,p,g,strict,counts);return counts

def accepted(data,strict=False):
    try:check(data,strict);return True
    except Exception:return False

def to_standard(a,p,g):
    """Restore an old tagged certificate for any accepted automatic proof."""
    if type(p) is not list:return p
    if p[0]=='lam':
        _,h,b=a
        tag='lam'
        if h==oracle(b,[-1,0]):
            tag='nat';h=b if b[0]=='=' else h;b=oracle(b,[['s',0],0])
        return [tag,to_standard(b,p[1],[*[oracle(x) for x in g],h])]
    if p[0]=='pack':
        _,t,q=p;h=['=',0,oracle(t,formula=False)]
        return ['pack',t,to_standard(a[1],q,[*[oracle(x) for x in g],h])]
    major,r,*args=p
    r=to_standard(major,r,g)
    if major[0]=='ex':
        q,=args
        return ['use',major,r,to_standard(oracle(a),q,[*[oracle(x) for x in g],major[1]])]
    t,q=args
    if major[0]=='pi':
        if not valid(t,False):
            ensure(not any(uses_slot(named(x)) for x in major[1:]))
            t=-1
        b=oracle(major[1],[t,-1])
    else:b=oracle(t,[major[1],-1])
    return ['use',major,r,t,to_standard(b,q,g)]
