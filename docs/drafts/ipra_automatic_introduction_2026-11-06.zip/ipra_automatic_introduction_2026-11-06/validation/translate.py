"""Constructive, untrusted translator from the frozen two-mode goal calculus.

The guard-perturbation compiler includes boolean hypothesis aliases and
normalizes unobserved malformed witnesses to zero. Neither target kernel
imports this module. All paths are relative to this extracted package.
"""
import importlib.util
from pathlib import Path

def module(name,path):
    sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
ROOT=Path(__file__).resolve().parents[1]
old=module('frozen_goal_source',ROOT/'comparison/ipra_reduction_2026-11-06.py')
s=old.subst
red=['r',-1,-1,-1]
eq=['=',red,-1]

def findzero(a,depth=0):
    if a == -1:return (),depth
    if isinstance(a,list):
        widths=next(table[a[0]] for table in old.SCOPES if a[0] in table)
        for i,(x,w) in enumerate(zip(a[1:],widths),1):
            out=findzero(x,depth+w)
            if out is not None:
                path,d=out;return (i,*path),d

def replace(a,path,value):
    if not path:return value
    i,*rest=path;a=a.copy();a[i]=replace(a[i],rest,value);return a

def subgoals(a,p,g,auto=False):
    """Iterator over recursive premises, matching the two public calculi."""
    if isinstance(p,list):
        if p[0] in ('lam','nat'):
            _,h,b=a
            if p[0]=='nat' or auto and h == s(b,[-1,0]):
                h=b if b[0]=='=' else h;b=s(b,[['s',0],0])
            return [(b,p[1],[*map(s,g),h])]
        if p[0]=='pack':
            _,t,q=p;return [(a[1],q,[*map(s,g),['=',0,s(t,formula=False)]])]
        if p[0]=='use':
            _,m,r,*args=p;tag,*parts=m
            out=[(m,r,g)]
            if tag=='ex':out.append((s(a),args[0],[*map(s,g),*parts]))
            else:
                t,q=args;b,c=(s(t,[v,-1]) if tag=='=' else s(v,[t,-1]) for v in parts)
                out.append((b,q,g))
            return out
    return []

def rebuild(p,qs):
    if not qs:return p
    if p[0] in ('lam','nat'):return [p[0],qs[0]]
    if p[0]=='pack':return ['pack',p[1],qs[0]]
    if p[1][0]=='ex':return ['use',p[1],qs[0],qs[1]]
    return ['use',p[1],qs[0],p[3],qs[1]]

def transport_hyp(a,p,g,index,path):
    if type(p) in (int, bool) and p%len(g)==index:
        # g[index] is the old guard raised by the surrounding local binders.
        target=g[index]
        # Replacing a literal closed zero is safe under any binder nesting.
        depth=0;v=target
        for i in path:
            widths=next(table[v[0]] for table in old.SCOPES if v[0] in table)
            depth+=widths[i-1];v=v[i]
        template=replace(s(target),path,depth)
        return ['use',eq,'r',template,p]
    return rebuild(p,[transport_hyp(b,q,h,index,path) for b,q,h in subgoals(a,p,g,True)])

def translate(a,p,g):
    qs=[translate(b,q,h) for b,q,h in subgoals(a,p,g)]
    if isinstance(p,list) and p[0] in ('lam','nat'):
        _,h,b=a
        if p[0]=='nat' or h != s(b,[-1,0]):return ['lam',qs[0]]
        zero=findzero(h)
        if zero is None:
            assert h==b and s(b,[['s',0],0])==b
            return ['lam',-1]
        path,depth=zero
        h2=replace(h,path,red)
        assert h2!=s(b,[-1,0])
        q2=transport_hyp(b,qs[0],[*map(s,g),h],len(g),path)
        template=replace(s(a),(1,*path),depth+1)
        return ['use',eq,'r',template,['lam',q2]]
    if isinstance(p,list) and p[0]=='use' and p[1][0]=='pi':
        # The source permits an irrelevant malformed witness. Reconstruct
        # the mathematical inference with zero for strict target kernels.
        try:
            s(p[3],formula=False)
        except Exception:
            assert all(s(v,[p[3],-1])==s(v,[-1,-1]) for v in p[1][1:])
            p=p.copy();p[3]=-1
    return rebuild(p,qs)

def untag(p):
    """Encode an accepted automatic proof using formula-headed applications."""
    if type(p) is not list:return p
    if p[0] in ('lam','nat'):return [p[0],untag(p[1])]
    if p[0]=='pack':return ['pack',p[1],untag(p[2])]
    _,major,premise,*args=p
    if major[0]=='ex':return [major,untag(premise),untag(args[0])]
    return [major,untag(premise),args[0],untag(args[1])]


def translate_data(data):
    """Validate the old proof, preserve its exact sequent, and translate it."""
    a,p,*g=data
    for h in g:s(h)
    old.check(a,p,g)
    return [a,untag(translate(a,p,g)),*g]
