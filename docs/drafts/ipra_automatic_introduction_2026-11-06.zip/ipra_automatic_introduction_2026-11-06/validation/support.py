"""Shared untrusted offline fixture/provenance helpers."""
import hashlib,importlib.util,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
FROZEN=HERE/'frozen'
sys.dont_write_bytecode=True

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def verify_frozen():
    provenance=json.loads((FROZEN/'provenance.json').read_text())
    for entry in provenance['files']:
        path=FROZEN/entry['file']
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        if actual!=entry['sha256']:
            raise ValueError('Changed frozen source or fixture: '+entry['file'])
    return len(provenance['files'])

verify_frozen()
sys.path.insert(0,str(FROZEN))
inference=load(FROZEN/'reference.py','frozen_inference_reference')
source_translator=load(FROZEN/'roundtrip.py','frozen_inference_to_goal')
manifest=json.loads((FROZEN/'fixture_manifest.json').read_text())

def fixtures():
    for entry in manifest['fixtures']:
        raw=(FROZEN/entry['file']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=entry['sha256']:
            raise ValueError('Changed fixture: '+entry['file'])
        yield entry,json.loads(raw)

def source_accepted(data):
    try:return inference.check(data) is True
    except Exception:return False

def to_goal(data,strict=False):
    g,a,p=data
    return [a,source_translator.to_goal(inference,p,g,strict=strict),*g]

def goal_corpus(strict=False):
    for entry,data in fixtures():
        actual=source_accepted(data)
        if actual!=entry['expected']['primary']:
            raise ValueError('Frozen fixture outcome changed: '+entry['name'])
        if actual:yield Path(entry['file']).name,to_goal(data,strict),entry

def accepted(target,data):
    try:
        a,p,*g=data
        for h in g:target.subst(h)
        return target.check(a,p,g) is True
    except Exception:return False
