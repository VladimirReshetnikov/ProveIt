"""Reproduce measurements, translations and independent audits offline.

Python 3.10+ and its standard library suffice. Paths are relative to this file;
this driver can be invoked from any working directory. No network is used.
"""
import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
if sys.version_info<(3,10):raise SystemExit('Python 3.10 or later is required')
(ROOT/'results').mkdir(exist_ok=True)
(ROOT/'examples').mkdir(exist_ok=True)
for script in ('comparison/measure.py','validation/translation_checks.py','validation/audit.py'):
    subprocess.run([sys.executable,'-B',str(ROOT/script)],cwd=ROOT,check=True)
metrics=json.loads((ROOT/'results/metrics.json').read_text())
translation=json.loads((ROOT/'results/translation_checks.json').read_text())
audit=json.loads((ROOT/'results/independent_audit.json').read_text())
if translation['status']!='passed' or audit['status']!='passed':raise SystemExit('Validation did not pass')
summary={'status':'passed','python':sys.version,'baseline_programs':len(metrics['baselines']),'both_candidates_below_every_coordinate':all(all(x.values()) for x in metrics['strictly_below'].values()),'translator_runs_per_target':translation['total_runs'],'translator_groups':translation['groups'],'independent_direct_cases_per_target':audit['direct_cases'],'collision_sources':audit['collision_sources'],'translated_inference_rejections_per_target':audit['negative_inference_translated'],'independent_perturbations_per_target':1000,'failure_count':len(translation['failures'])+len(audit['failures']),'qualification':'Counts describe separate, potentially overlapping audits. They are not summed into a claim of distinct theorems, proofs, or cases.'}
(ROOT/'results/reproduction.json').write_text(json.dumps(summary,indent=2)+'\n')
tex=r'''\paragraph{Executable evidence.}
The offline driver completed with zero failures. It first verified the
hashes of all six retained baseline programs and recomputed every metric
in Table~\ref{tab:metrics}. Both new programs are strictly below the
coordinatewise minimum in all four primary measures and also in raw bytes.

\paragraph{Constructive translation checks.}
The translator passed 327 runs on each target: 194 frozen source proofs,
126 generated combinations of formula shape, nesting depth, and hypothesis
index representation, one named Boolean-index regression, and six
reconstructions of irrelevant malformed witnesses. The generated cases
include zeros inside formula binders and inside two-variable recursor
updates, with up to five extra proof-local binders. Positive, negative,
and Boolean hypothesis indices are exercised. Every translation preserves
the exact exterior goal and retained hypotheses. These are run counts;
some cases overlap other audits and are not asserted to be distinct theorems.

\paragraph{Independent rule and boundary audit.}
A separate rule interpreter uses named variables and its own substitution
implementation; it never calls either target's substitution or scope table
to determine expected results. It agrees with both targets on 171 direct
certificate cases, 26 collision repairs and their 26 naive-erasure controls,
two 194-proof source corpora, 60 translated rejected inference fixtures,
and 1,000 deterministic perturbations. All 26 repaired collision proofs
pass, whereas 20 of the naive-erasure controls fail. Of the 62 rejected
inference fixtures, two cannot be translated because their source syntax
is malformed; direct target tests cover the same recursor and existential
witness defects. No negative source fixture becomes accepted.

The audit also executes 223 certificate cases through each complete
command-line interface, three malformed-JSON cases and three argument-error
cases per target, and 29 selected direct cases per target with Python
assertions disabled. Every independently accepted certificate is translated
back to an accepted conventional two-mode proof. Raw unused-witness controls
confirm the stated difference between the strict and companion programs;
the constructive source translator canonicalizes those witnesses to zero.
Detailed case records, source hashes, and the exact runtime are retained in
\code{results/}. These finite checks supplement the written proofs; they
are not a proof-assistant formalization or an internal consistency proof.
'''
(ROOT/'verification.tex').write_text(tex)
print(json.dumps(summary,indent=2))
