A SMALLER AXIOMATIZATION OF iPRA BY AUTOMATIC INTRODUCTION
Research report for Vladimir Reshetnikov -- 6 November 2026

RESULT

Both complete acceptance programs in this archive are strictly below the
coordinatewise minimum of the six CURRENT ProveIt draft checkers inspected
at commit edf7ea445673b29301012177998b0cc66bfabbf0.

                       AST     source tokens    normalized tokens    normalized bytes
Current envelope       639          603                 603                  1928
checker.py (strict)    618          590                 592                  1856
checker_demand.py      606          580                 582                  1811

These measurements include every application-specific acceptance operation,
the scope/syntax table, the JSON input wrapper, and the CLI verdict. Only
comments and docstrings are excluded. All rows are remeasured using the same
Python runtime; the recorded runtime is CPython 3.12.14.

THE NEW MATHEMATICAL IDEA

There is one guarded-introduction instruction. For a goal Pi x (H(x), B(x)),
it uses the numerical premise exactly when H is literally B(0); otherwise
it uses ordinary introduction. There is no separate induction-mode flag.

Completeness is not automatic: an ordinary introduction can have H = B(0).
In that collision case, replace one closed zero in H by R(0,0;u,v.0).
The modified guard is syntactically larger, so ordinary introduction is
selected. The computation equation R(0,0;u,v.0)=0 transports the original
guard into the child proof and restores the original whole conclusion.
The zero-free collision case is a direct local-hypothesis proof.

The report proves context cut first, then ordinary-introduction admissibility,
then equality of consequence relations with the older separated calculus.
Only afterward does it derive arbitrary numerical substitution admissibility:
such substitutions can change the automatic branch, so they cannot be assumed
to preserve a certificate unchanged.

The native calculus faithfully presents an ordinary first-order theory
bi-interpretable with full first-order intuitionistic primitive recursive
arithmetic. Both interpretations use the full number domain; fixed-recursion
uniqueness proves the double translations internally equal to the original
operations. Both definable composite isomorphisms are x=y. Equiconsistency
follows, with native contradiction 0=S0 corresponding to ordinary falsity.

START HERE

  report.pdf              Complete mathematical paper and implementation argument.
  report.tex              Main TeX source.
  verification.tex        Included recorded validation summary.
  checker.py              Complete strict acceptance program; no support imports.
  checker_demand.py       Smaller companion; only unused Pi witness payloads ignored.
  FORMAT.txt              Exact mathematical and certificate interfaces.
  reproduce.py            Offline measurement and verification entry point.
  translate.py            Untrusted constructive proof translator.
  examples/               Executable certificates, including the collision detour.
  comparison/             Six byte-identical baseline sources and provenance.
  validation/             Independent oracle, translation checks, and regressions.
  results/                Recorded machine-readable evidence.
  build.py                Rebuild the paper with a standard LaTeX installation.
  MANIFEST.sha256         Checksums of all distributed payload files.

RUN

Use Python 3.10 or later (3.12.14 is recommended for exact recorded AST/unparse
measurements). No third-party Python packages or network access are needed.
Run from this directory:

  python3 reproduce.py
  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/automatic_collision.json

Acceptance prints ACCEPT and exits with code 0. Rejection prints REJECT and
exits with code 1. Internally, check(a,p,g) returns a Boolean and assumes the
caller has validated g. Use the complete CLI for untrusted public certificates.
Neither kernel uses assert; Python -O does not remove its checks.

The source archive is self-contained: the translator, oracle, and fixtures
are support artifacts, not dependencies of either acceptance program.

REBUILD THE PDF

  python3 build.py

Alternatively, on a normally configured LaTeX installation:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

The build helper can initialize a temporary pdflatex format if the installed
TeX distribution has the source files but lacks its generated format. The
compiled PDF is already supplied; LaTeX is not needed for checker reproduction.

STRICT AND DEMAND VARIANTS

The strict checker validates all numerical witnesses, even unused ones.
The smaller companion follows the earlier drafts' convention: a Pi witness
field occurring in neither the guard nor consequent is irrelevant metadata.
It can be replaced by the genuine zero term without changing either formula.
Every demanded witness is validated. Both programs validate every public goal
and hypothesis. The two programs prove exactly the same well-formed sequents.
The strict checker itself already beats the current primary lower envelope.

EVIDENCE AND LIMITATIONS

The complete mathematical proofs are in the paper; recorded finite audit
results and exact counts are in verification.tex and results/. The audit
exercises accepted source proofs, rejected certificates, nested eigenvariables,
literal-equation induction, forbidden stronger induction, computation errors,
boolean proof-index aliases, the closed-zero detour under binders, and an
independent named-variable interpreter. The proof translator canonicalizes
irrelevant malformed source witnesses before producing strict certificates.

This is a verified finite-source size comparison, with a written mathematical
soundness/completeness and bi-interpretability proof. It is not a theorem of
absolute minimality across all programming languages or proof systems. It is
not claimed to be Lean- or Rocq-verified, and the tests are not an internal
consistency proof. Ideal completeness abstracts from physical recursion,
memory, and time limits of a particular execution.

SOURCE SNAPSHOT AND ATTRIBUTION

Repository: VladimirReshetnikov/ProveIt
Commit:     edf7ea445673b29301012177998b0cc66bfabbf0
Directory:  docs/drafts
URL:
https://github.com/VladimirReshetnikov/ProveIt/tree/edf7ea445673b29301012177998b0cc66bfabbf0/docs/drafts

The recursion/guarded-universal/existential basis and the logical/arithmetic
reconstruction are inherited from the supplied draft series. This report
introduces automatic guarded introduction, proves its zero-detour translation,
and combines it with smaller goal-directed scope sharing and Boolean checking.
The exact six original archive and checker identities are in
comparison/manifest.json. All archive Git blob hashes were verified on download.
LICENSE_SOURCE.txt preserves the supplied source license.

The final section of the paper lists further research questions, including
formal verification, substitution-stable presentations, proof-expansion bounds,
different arithmetic bases, and a more canonical complexity metric.
