"""Translate a frozen two-mode goal certificate and strictly check the result.

Usage: python3 translate.py SOURCE.json OUTPUT.json
This is untrusted support; neither acceptance checker imports it.
"""
import argparse
import json
from pathlib import Path
import checker
from validation.translate import translate_data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    data = json.loads(args.source.read_text(encoding="utf-8"))
    result = translate_data(data)
    goal, proof, *hypotheses = result
    for formula in hypotheses:
        checker.subst(formula)
    if checker.check(goal, proof, hypotheses) is not True:
        raise ValueError("Translated certificate failed the strict checker")
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("Wrote a strictly checked translation to " + str(args.output))


if __name__ == "__main__":
    main()
