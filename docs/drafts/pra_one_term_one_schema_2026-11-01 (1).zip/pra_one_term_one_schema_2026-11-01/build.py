#!/usr/bin/env python3
"""Reproduce the finite checks and compiled report; optionally rerun Lean."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def run(command: list[str], root: Path, log: Path) -> str:
    completed = subprocess.run(
        command, cwd=root, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False,
    )
    log.write_text(completed.stdout, encoding="utf-8")
    if completed.returncode:
        print(completed.stdout[-12000:], file=sys.stderr)
        raise SystemExit(f"Failed with exit {completed.returncode}: {command[0]}")
    return completed.stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Lean 4.19.0 executable; otherwise search PATH")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit, build = root / "audit", root / "build"
    audit.mkdir(exist_ok=True)
    build.mkdir(exist_ok=True)
    run(
        [sys.executable, "checks/adjacent_schema_check.py",
         "--output", "checks/schema_checks.json",
         "--examples", "checks/schema_examples.txt"],
        root, audit / "syntax-check.log",
    )
    lean = args.lean or shutil.which("lean")
    lean_status = "not rerun: no Lean executable supplied or found"
    if lean:
        run([lean, "--version"], root, audit / "lean-version.log")
        output = run(
            [lean, "formal/AdjacentPropagation.lean"],
            root, audit / "lean-check.log",
        )
        empty = [line for line in output.splitlines()
                 if "does not depend on any axioms" in line]
        nonempty = [line for line in output.splitlines() if "depends on axioms" in line]
        if len(empty) != 17 or nonempty:
            raise SystemExit("Unexpected Lean dependency report; inspect audit/lean-check.log")
        lean_status = "passed: 17 empty axiom-dependency lists"
    pdflatex = shutil.which("pdflatex")
    if not pdflatex:
        raise SystemExit("pdflatex is required to compile report.tex")
    command = [pdflatex, "-no-shell-escape", "-interaction=nonstopmode",
               "-halt-on-error", "-file-line-error", "-output-directory=build", "report.tex"]
    for number in range(1, 4):
        run(command, root, audit / f"latex-pass-{number}.log")
    shutil.copyfile(build / "report.pdf", root / "report.pdf")
    status = {"syntax": "passed", "lean": lean_status,
              "pdf": "compiled in three passes", "source": "report.tex"}
    (audit / "build-results.json").write_text(json.dumps(status, indent=2) + "\n")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
