#!/usr/bin/env python3
"""Exact finite syntax checks for the adjacent-probe one-term PRA generator.

This checks syntax, substitutions, and node accounting.  It is not a
formal proof of the arithmetic calibration or bi-interpretability.
Stored iterator descriptors are immutable syntax and active substitution
never enters them.  No external Python packages are required.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Union


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


def V(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def S(t: Term) -> Term:
    return Term("succ", (t,))


ONE = S(ZERO)
N, A, Z, V0 = map(V, ("n", "a", "z", "v"))
SUCC_BODY = S(V0)


def variables(t: Term) -> set[str]:
    if t.op == "var":
        return {t.name}
    return set().union(*(variables(x) for x in t.args))


def D(body: Term, index: Term, seed: Term) -> Term:
    if not variables(body) <= {"v"}:
        raise ValueError("An iterator body has an active variable other than v")
    return Term("iter", (index, seed), body=body)


def sub(t: Term, mapping: dict[str, Term]) -> Term:
    """Simultaneous active substitution, freezing every stored body."""
    if t.op == "var":
        return mapping.get(t.name, t)
    return Term(t.op, tuple(sub(x, mapping) for x in t.args), t.name, t.body)


def nodes(t: Term) -> int:
    """Active AST nodes: descriptors are symbol indices, not active children."""
    return 1 + sum(nodes(x) for x in t.args)


def inclusive_nodes(t: Term) -> int:
    return (1 + sum(inclusive_nodes(x) for x in t.args)
            + (inclusive_nodes(t.body) if t.body is not None else 0))


def occurrences(t: Term, name: str) -> int:
    return (int(t.op == "var" and t.name == name)
            + sum(occurrences(x, name) for x in t.args))


def rank(t: Term) -> int:
    active = max((rank(x) for x in t.args), default=0)
    return max(active, 1 + rank(t.body) if t.body is not None else 0)


def render_term(t: Term) -> str:
    if t.op == "var":
        return t.name
    if t.op == "zero":
        return "0"
    if t.op == "succ":
        return f"S({render_term(t.args[0])})"
    return (f"D_[{render_term(t.body)}]"
            f"({render_term(t.args[0])},{render_term(t.args[1])})")


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple[Union[Term, "Formula"], ...] = ()
    binder: str = ""


def Eq(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


def And(p: Formula, q: Formula) -> Formula:
    return Formula("and", (p, q))


def Or(p: Formula, q: Formula) -> Formula:
    return Formula("or", (p, q))


def Imp(p: Formula, q: Formula) -> Formula:
    return Formula("imp", (p, q))


def All(name: str, p: Formula) -> Formula:
    return Formula("all", (p,), name)


BOT = Formula("bottom")


def formula_sub(p: Formula, mapping: dict[str, Term]) -> Formula:
    if p.op == "eq":
        return Eq(*(sub(t, mapping) for t in p.args))
    if p.op == "all":
        reduced = {k: v for k, v in mapping.items() if k != p.binder}
        if any(p.binder in variables(v) for v in reduced.values()):
            raise ValueError("This checker does not silently rename binders")
        return All(p.binder, formula_sub(p.args[0], reduced))
    return Formula(p.op, tuple(formula_sub(x, mapping) for x in p.args))


def formula_nodes(p: Formula, inclusive: bool = False) -> int:
    if p.op == "eq":
        counter = inclusive_nodes if inclusive else nodes
        return 1 + sum(counter(t) for t in p.args)
    return 1 + sum(formula_nodes(x, inclusive) for x in p.args)


def formula_variables(p: Formula) -> set[str]:
    if p.op == "eq":
        return set().union(*(variables(t) for t in p.args))
    free = set().union(*(formula_variables(x) for x in p.args))
    return free - {p.binder} if p.op == "all" else free


def individual_names(p: Formula) -> set[str]:
    if p.op == "eq":
        return set().union(*(variables(t) for t in p.args))
    names = set().union(*(individual_names(x) for x in p.args))
    return names | {p.binder} if p.op == "all" else names


def quantifier_count(p: Formula) -> int:
    if p.op == "eq":
        return 0
    return int(p.op == "all") + sum(quantifier_count(x) for x in p.args)


def quantifier_depth(p: Formula) -> int:
    if p.op == "eq":
        return 0
    return (int(p.op == "all")
            + max((quantifier_depth(x) for x in p.args), default=0))


def render_formula(p: Formula) -> str:
    if p.op == "eq":
        return f"({render_term(p.args[0])} = {render_term(p.args[1])})"
    if p.op == "bottom":
        return "false"
    if p.op == "all":
        return f"forall {p.binder} ({render_formula(p.args[0])})"
    token = {"and": "AND", "or": "OR", "imp": "->"}[p.op]
    return f"({render_formula(p.args[0])} {token} {render_formula(p.args[1])})"


def q(index: Term, seed: Term) -> Term:
    return D(ONE, index, seed)


def zero_gate(index: Term, seed: Term) -> Term:
    return D(ZERO, S(index), seed)


def selector(tag: Term, yes: Term, no: Term) -> Term:
    """Only seeds and the predecessor bridge prove its two endpoint laws."""
    return D(SUCC_BODY, zero_gate(tag, S(yes)), zero_gate(zero_gate(tag, ONE), no))


def normalize_endpoints(t: Term, *, bridge: bool = False) -> Term:
    """Check symbolic transcription against the explicitly listed local laws.

    This rewrite uses recovered seeds, Tail for constant zero, and optionally
    p(Sx)=x.  The checker does not claim to prove those laws itself.
    """
    if not t.args:
        return t
    args = tuple(normalize_endpoints(x, bridge=bridge) for x in t.args)
    out = Term(t.op, args, t.name, t.body)
    if t.op != "iter":
        return out
    index, seed = args
    if index in (ZERO, ONE):
        return seed
    if t.body == ZERO and index.op == "succ" and index.args[0].op == "succ":
        return ZERO
    if bridge and t.body == SUCC_BODY and seed == ZERO and index.op == "succ":
        return index.args[0]
    return out


def computation(body: Term) -> Formula:
    separation = Imp(Eq(ZERO, ONE), BOT)
    reset = Eq(D(body, q(N, ZERO), A), A)
    tail = Eq(D(body, S(S(N)), A), sub(body, {"v": D(body, S(N), A)}))
    return And(separation, And(reset, tail))


def pair_axiom(s: Term, t: Term, *, short: bool) -> Formula:
    """Current one-schema draft, optionally with the short successor premise."""
    e = Eq(s, t)
    p = Or(Eq(N, ZERO), e)
    right = e if short else p
    h = sub(s, {"n": V0, "a": V0})
    return All("a", Imp(All("n", Imp(p, formula_sub(right, {"n": S(N)}))),
                        All("n", And(p, computation(h)))))


def adjacent_axiom(u: Term) -> Formula:
    if not variables(u) <= {"n", "a"}:
        raise ValueError("Input has forbidden free variables")
    s, t = u, sub(u, {"a": S(A)})
    # Final candidate: initial section.  The stored bodies stay frozen.
    h = sub(u, {"n": V0, "a": ZERO})
    e = Eq(s, t)
    p = Or(Eq(N, ZERO), e)
    out = All("a", Imp(All("n", Imp(p, formula_sub(e, {"n": S(N)}))),
                       All("n", And(p, computation(h)))))
    return out


def predecessor(x: Term) -> Term:
    return D(SUCC_BODY, x, ZERO)


TOGGLE_BODY = zero_gate(V0, ONE)


def parity(x: Term) -> Term:
    return D(TOGGLE_BODY, S(x), ZERO)


def pack_pair(s: Term, t: Term, phase: int) -> Term:
    """Two one-term instances suffice after a parity case split on a."""
    shifted_t = sub(t, {"a": predecessor(A)})
    if phase == 0:
        return selector(parity(A), s, shifted_t)
    if phase == 1:
        return selector(parity(A), shifted_t, s)
    raise ValueError("phase must be 0 or 1")


def eval_term(t: Term, env: dict[str, int]) -> int:
    """The standard numerical algebra only; bounded sanity checks, not proofs."""
    if t.op == "var":
        return env[t.name]
    if t.op == "zero":
        return 0
    if t.op == "succ":
        return eval_term(t.args[0], env) + 1
    index, state = (eval_term(x, env) for x in t.args)
    for _ in range(max(index - 1, 0)):
        state = eval_term(t.body, {"v": state})
    return state


def run() -> tuple[dict, str]:
    bootstrap = selector(A, N, N)
    coverage = selector(A, S(predecessor(N)), N)
    examples = {
        "counter": N,
        "parameter": A,
        "constant_zero": ZERO,
        "successor_counter": S(N),
        "successor_parameter": S(A),
        "frozen_descriptor": D(S(V0), A, N),
        "predecessor_bootstrap": bootstrap,
        "coverage_bootstrap": coverage,
        "h_only_successor": S(N),
        "h_only_predecessor": predecessor(N),
        "parity": parity(A),
        "packed_n_a_even": pack_pair(N, A, 0),
        "packed_n_a_odd": pack_pair(N, A, 1),
        "packed_Sn_a_even": pack_pair(S(N), A, 0),
        "packed_Sn_a_odd": pack_pair(S(N), A, 1),
        "packed_a_n_even": pack_pair(A, N, 0),
        "packed_a_n_odd": pack_pair(A, N, 1),
    }
    rows = []
    for name, u in examples.items():
        axiom = adjacent_axiom(u)
        s, t = u, sub(u, {"a": S(A)})
        baseline = pair_axiom(s, t, short=False)
        short = pair_axiom(s, t, short=True)
        size = formula_nodes(axiom)
        expected = (38 + 7 * nodes(u) + 5 * occurrences(u, "n")
                    + 3 * occurrences(u, "a"))
        assert size == expected
        assert not formula_variables(axiom)
        assert individual_names(axiom) == {"n", "a"}
        assert quantifier_count(axiom) == 3
        assert quantifier_depth(axiom) == 2
        assert formula_nodes(baseline) - size == 5 + 3 * occurrences(u, "a")
        assert formula_nodes(short) - size == 3 * occurrences(u, "a")
        inclusive_saving = (5 + occurrences(u, "a") * (3 + inclusive_nodes(u)))
        assert (formula_nodes(baseline, True) - formula_nodes(axiom, True)
                == inclusive_saving)
        h = sub(u, {"n": V0, "a": ZERO})
        assert variables(h) <= {"v"}
        assert rank(h) == rank(u)
        rows.append({
            "name": name,
            "input": render_term(u),
            "input_active_nodes": nodes(u),
            "input_descriptor_inclusive_nodes": inclusive_nodes(u),
            "input_occurrences": {x: occurrences(u, x) for x in ("n", "a")},
            "axiom_active_nodes": size,
            "axiom_descriptor_inclusive_nodes": formula_nodes(axiom, True),
            "original_endpoint_pair_descriptor_inclusive_nodes": formula_nodes(baseline, True),
            "descriptor_inclusive_savings": inclusive_saving,
            "endpoint_pair_original_axiom_nodes": formula_nodes(baseline),
            "endpoint_pair_short_axiom_nodes": formula_nodes(short),
            "savings_vs_original_endpoint_pair": formula_nodes(baseline) - size,
            "savings_vs_short_endpoint_pair": formula_nodes(short) - size,
            "quantifiers": quantifier_count(axiom),
            "depth": quantifier_depth(axiom),
            "active_names": sorted(individual_names(axiom)),
            "free_variables": sorted(formula_variables(axiom)),
        })

    # Descriptor substitution must not accidentally capture its stored v.
    frozen = D(S(V0), N, A)
    changed = sub(frozen, {"n": V0, "a": V0, "v": ZERO})
    assert changed.body == S(V0)
    assert changed.args == (V0, V0)

    # These symbolic checks rely only on the local laws documented above.
    assert normalize_endpoints(sub(bootstrap, {"a": ZERO})) == D(SUCC_BODY, S(N), ZERO)
    assert normalize_endpoints(sub(bootstrap, {"a": ONE})) == N
    assert normalize_endpoints(sub(coverage, {"a": ZERO}), bridge=True) == S(predecessor(N))
    assert normalize_endpoints(sub(coverage, {"a": ONE}), bridge=True) == N
    for s, t in [(N, A), (S(N), A), (A, N)]:
        packed = selector(Z, s, t)
        assert normalize_endpoints(sub(packed, {"z": ZERO}), bridge=True) == s
        assert normalize_endpoints(sub(packed, {"z": ONE}), bridge=True) == t

    # h-only terms recover every chosen descriptor literally, not extensionally.
    test_bodies = [V0, ZERO, ONE, S(V0), D(SUCC_BODY, V0, ZERO),
                   D(D(SUCC_BODY, V0, ZERO), S(V0), V0)]
    for h in test_bodies:
        u = sub(h, {"v": N})
        recovered = sub(u, {"n": V0, "a": ZERO})
        assert recovered == h
        assert u == sub(u, {"a": S(A)})

    # Finite numerical checks are explicitly separated from syntax validation.
    for n in range(17):
        assert eval_term(bootstrap, {"a": 0, "n": n}) == n
        assert eval_term(bootstrap, {"a": 1, "n": n}) == n
        for a in range(13):
            assert eval_term(parity(A), {"a": a}) == a % 2
            assert eval_term(parity(S(A)), {"a": a}) == 1 - a % 2
            for s, t in [(N, A), (S(N), A), (A, N)]:
                u = pack_pair(s, t, a % 2)
                assert eval_term(u, {"n": n, "a": a}) == eval_term(s, {"n": n, "a": a})
                assert eval_term(u, {"n": n, "a": a+1}) == eval_term(t, {"n": n, "a": a})

    packing = []
    for name, s, t in [("n,a", N, A), ("Sn,a", S(N), A), ("a,n", A, N)]:
        u0, u1 = pack_pair(s, t, 0), pack_pair(s, t, 1)
        packed_sizes = [formula_nodes(adjacent_axiom(u)) for u in (u0, u1)]
        packing.append({
            "pair": name,
            "original_one_schema_pair_nodes": formula_nodes(pair_axiom(s, t, short=False)),
            "short_pair_nodes": formula_nodes(pair_axiom(s, t, short=True)),
            "adjacent_packed_nodes": packed_sizes,
            "adjacent_packed_total_nodes": sum(packed_sizes),
            "packing_overhead_vs_short_pair": sum(packed_sizes) - formula_nodes(pair_axiom(s, t, short=True)),
            "note": ("This compares syntax only. The instances select different "
                     "computation bodies; no finite-instance equivalence is claimed."),
        })

    result = {
        "status": "all assertions passed",
        "scope": "Finite syntax/count checks and bounded standard-model examples only.",
        "candidate": "E_u=u(n,a)=u(n,Sa), h_u(v)=u(v,0); one binary input",
        "active_node_formula": "38 + 7|u| + 5#n(u) + 3#a(u)",
        "descriptor_inclusive_savings_formula": "5 + #a(u) * (3 + inclusive_nodes(u))",
        "descriptor_policy": "Substitution changes only active arguments; bodies remain frozen.",
        "comparison": (
            "At the same endpoints (u(n,a),u(n,Sa)), the adjacent-probe instance "
            "has 5+3#a(u) fewer active nodes than the unshortened one-schema "
            "instance. Five are saved by removing the successor zero guard; "
            "3#a(u) are saved by zero-section specialization in Tail. The "
            "computation descriptors differ, so this is a syntax comparison, "
            "not equivalence of the individual instances. Encoding an "
            "arbitrary pair by two parity templates has a positive syntax cost."),
        "examples": rows,
        "packing_examples": packing,
        "h_only_extraction_cases": len(test_bodies),
        "symbolic_endpoint_checks": (
            "Bootstrap endpoints p(Sn), n follow by the listed seed/Tail_0 "
            "rewrites. General packed endpoints s,t additionally use the "
            "predecessor bridge. The arbitrary-parameter adjacent encoding "
            "additionally uses the proved parity range and flip laws."),
        "bounded_bootstrap_counters": 17,
        "bounded_adjacent_endpoint_evaluations": 17 * 13 * 3 * 2,
    }
    expanded = "\n\n".join(
        f"{name}\nINPUT {render_term(u)}\nAXIOM {render_formula(adjacent_axiom(u))}"
        for name, u in examples.items()
    ) + "\n"
    return result, expanded


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write complete JSON results here")
    parser.add_argument("--examples", type=Path, help="Write fully expanded examples here")
    args = parser.parse_args()
    result, expanded = run()
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n")
    if args.examples:
        args.examples.parent.mkdir(parents=True, exist_ok=True)
        args.examples.write_text(expanded)
    print(json.dumps({
        "status": result["status"],
        "active_node_formula": result["active_node_formula"],
        "example_count": len(result["examples"]),
        "packing_examples": result["packing_examples"],
        "scope": result["scope"],
    }, indent=2))


if __name__ == "__main__":
    main()
