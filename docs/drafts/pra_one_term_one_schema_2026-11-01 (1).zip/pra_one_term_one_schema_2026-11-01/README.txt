PRA FROM ONE BINARY TERM AND ONE AXIOM SCHEMA
Prepared for Vladimir Reshetnikov, 1 November 2026.

RESULT
One axiom constructor indexed by one binary term u(n,a) suffices for
both classical and intuitionistic first-order PRA, in the matching logic.
It compares u(n,a) with u(n,S(a)); its computational body is u(v,0).
The theory is definitionally equivalent, bi-interpretable, and
equiconsistent with that matching PRA. Both interpretations use native
equality and the whole carrier, with internal identity round trips.

The new reduction uses a parity encoding of adjacent parameter values.
It combines the current drafts' input and constructor reductions without
adding a diagonal law, a third template slot, or an equality-test axiom.
There is no absolute shortestness claim and no claim that every proof
translation becomes shorter. The size costs are explicitly reported.

CONTENTS
report.pdf                 Complete mathematical report.
report.tex, sections/      Complete LaTeX source.
AXIOMS.txt                 Exact standalone theory specification.
formal/                    Lean 4.19.0 constructive kernel and scope.
checks/                    Standalone Python syntax/count checker/results.
audit/                     Pinned source hashes, reviews, and check logs.
build.py                   Rebuild checks and PDF; optionally rerun Lean.
SHA256SUMS.txt              Deliverable checksums.

REBUILD
Requirements: Python 3.10+ and pdflatex with common LaTeX packages.
The syntax checker requires only the Python standard library.

  python3 build.py

Lean is optional for rebuilding the PDF. To rerun its verified kernel:

  python3 build.py --lean /absolute/path/to/lean

If lean is on PATH it is found automatically. Use Lean 4.19.0 as recorded
in formal/lean-toolchain. No Mathlib dependency is needed.

The supplied Lean log checks 17 named theorems with empty axiom
dependencies. The full descriptor syntax, scalar pairing, PR compiler,
and first-order bi-interpretation are written proofs, not completely
mechanized. Bounded Python examples are diagnostic checks, not proofs
of induction, consistency, or interpretation strength.

PROVENANCE
Comparison repository: VladimirReshetnikov/ProveIt.
Pinned main commit: d605be20835fc80907e01a105bcb059f07ed8b8c.
All three ZIPs present in docs/drafts at that snapshot were inspected.
The prior arithmetic calibration and scalar pairing are credited in
the paper; the adjacent-parameter reduction is the new contribution.
No repository files were changed by this research deliverable.
