"""Validate the registered-name companion against the frozen named oracle.

This is untrusted support and is never imported by either acceptance kernel.
It replays the 45 original public theorems and 53 original audits, then runs
four selected certificates through the real CLI normally and under python -O.
"""
from copy import deepcopy
import json
from pathlib import Path
import platform
import subprocess
import sys
import types

from comparison.measure_reference import metrics
from frozen.named_source import NamedOracle

ROOT = Path(__file__).resolve().parent
PROGRAM = ROOT / 'checker_registered.py'
RESULTS = ROOT / 'results'


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def kernel():
    module = types.ModuleType('registered_companion')
    exec(compile(PROGRAM.read_text(), str(PROGRAM), 'exec'), module.__dict__)
    return module


def verdict(module, certificate):
    module.k = 0
    stream = deepcopy(certificate)
    try:
        goal = stream.pop()
        module.take = stream.pop
        accepted = bool(module.check(goal, []))
        error = None
    except Exception as exc:
        accepted = False
        error = type(exc).__name__
    return {'accepted': accepted, 'final_supply': module.k,
            'unread_instructions': len(stream), 'error': error}


def oracle(certificate):
    accepted, supply, unread = NamedOracle('demand').verdict(
        [certificate[-1], certificate[:-1]])
    return {'accepted': accepted, 'final_supply': supply,
            'unread_instructions': unread}


def compare(module, name, certificate, expected):
    actual = verdict(module, certificate)
    independent = oracle(certificate)
    require(actual['accepted'] == independent['accepted'] == expected,
            ('companion/oracle acceptance mismatch', name, actual, independent))
    if expected:
        require(actual['final_supply'] == independent['final_supply']
                and actual['unread_instructions'] == independent['unread_instructions'],
                ('accepted trace mismatch', name, actual, independent))
    return {'name': name, 'expected': expected, 'kernel': actual,
            'independent_named_oracle': independent}


def main():
    module = kernel()
    public = []
    for path in sorted((ROOT / 'frozen' / 'theorems').glob('*.json')):
        public.append(compare(module, path.name, json.loads(path.read_text()), True))
    require(len(public) == 45, 'wrong public theorem inventory')

    cases = json.loads((ROOT / 'frozen' / 'source_audit_cases.json').read_text())
    audits = [compare(module, case['name'], case['proof'] + [case['goal']],
                      case['expected_demand']) for case in cases]
    require(len(audits) == 53, 'wrong inherited audit inventory')

    cli_cases = [(ROOT / 'frozen' / 'theorems' / name, True) for name in (
        '007_rigid_reflexivity_1.json', '022_universal_reflexivity.json')]
    by_name = {case['name']: case for case in cases}
    input_dir = RESULTS / 'registered_cli_inputs'
    input_dir.mkdir(parents=True, exist_ok=True)
    for name in ('capture_by_illegal_positive_witness',
                 'freshness_collision_with_goal_parameter'):
        case = by_name[name]
        path = input_dir / (name + '.json')
        path.write_text(json.dumps(case['proof'] + [case['goal']], indent=2) + '\n')
        cli_cases.append((path, False))
    cli = []
    for optimized in (False, True):
        for path, expected in cli_cases:
            command = [sys.executable] + (['-O'] if optimized else [])
            command += [str(PROGRAM), str(path)]
            result = subprocess.run(command, text=True, capture_output=True, timeout=20)
            require(result.returncode == (0 if expected else 1)
                    and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT')
                    and not result.stderr,
                    ('companion CLI mismatch', path.name, optimized, result))
            cli.append({'input': str(path.relative_to(ROOT)), 'optimized': optimized,
                        'expected': expected, 'exit_code': result.returncode,
                        'stdout': result.stdout.strip()})

    measured = metrics(PROGRAM)
    require((measured['normalized_tokens'], measured['ast_nodes'],
             measured['normalized_bytes']) == (450, 465, 1348),
            ('companion metrics changed', measured))
    result = {
        'python': platform.python_version(), 'program': PROGRAM.name,
        'checker_sha256': measured['sha256'], 'metrics': measured,
        'public_certificates': len(public), 'inherited_audit_cases': len(audits),
        'actual_cli_runs_including_optimized': len(cli),
        'independent_named_oracle_agrees': True, 'all_checks_passed': True,
        'public_results': public, 'audit_results': audits, 'cli_results': cli,
        'limitations': 'Finite implementation evidence; no formalization of the universal metatheorems.',
    }
    (RESULTS / 'registered_companion.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('public_results', 'audit_results', 'cli_results')}, indent=2))


if __name__ == '__main__':
    main()
