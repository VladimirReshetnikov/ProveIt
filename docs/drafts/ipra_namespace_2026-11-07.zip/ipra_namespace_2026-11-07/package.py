"""Create a clean archive and integrity manifest for this deliverable."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent


def deliverable(path):
    return (path.is_file() and not any(part in {'__pycache__', '_build'}
                                     for part in path.relative_to(ROOT).parts)
            and path.suffix not in {'.pyc', '.aux', '.log', '.out', '.toc'}
            and path.name != 'MANIFEST.sha256')


def main():
    files = sorted(p for p in ROOT.rglob('*') if deliverable(p))
    rows = [hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix()
            for p in files]
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text('\n'.join(rows) + '\n')
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
        for path in sorted(files + [manifest]):
            info = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 7, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            stream.writestr(info, path.read_bytes())
    print(archive)


if __name__ == '__main__':
    main()
