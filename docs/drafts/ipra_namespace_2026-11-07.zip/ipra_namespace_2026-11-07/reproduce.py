"""Verify original inputs, remeasure all programs, and run finite evidence offline."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    provenance = json.loads((ROOT / 'frozen/provenance.json').read_text())
    required = [
        ('frozen/source_checker.py', provenance['source_checker_sha256']),
        (provenance['named_oracle_original_file'], provenance['named_oracle_original_sha256']),
        (provenance['named_oracle_extracted_file'], provenance['named_oracle_extracted_sha256']),
        *[(entry['frozen_path'], entry['sha256']) for entry in provenance['public_corpus']],
    ]
    for name, expected in required:
        actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError('Frozen source hash mismatch: ' + name)
    for script in ['measure.py', 'validate.py', 'validate_registered.py']:
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    print('All comparison and validation checks passed.')


if __name__ == '__main__':
    main()
