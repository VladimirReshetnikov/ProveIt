"""Reproduce the full, hash-checked comparison at the pinned repository snapshot."""
import csv
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('reference_measure', ROOT / 'comparison/measure_reference.py')
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['comparison_files']:
        result = reference.metrics(ROOT / entry['file'])
        if result['sha256'] != entry['sha256']:
            raise ValueError('Comparator hash mismatch: ' + entry['file'])
        rows.append({**entry, **result})
    current = {k: min(r[k] for r in rows) for k in KEYS}
    core = {k: min(r['core'][k] for r in rows) for k in KEYS}
    open_rows = [r for r in rows if r['scope'] != 'closed-sentence only']
    open_current = {k: min(r[k] for r in open_rows) for k in KEYS}
    candidate = reference.metrics(ROOT / 'checker.py')
    companion = reference.metrics(ROOT / 'checker_registered.py')
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
              'program_count': len(rows), 'coordinatewise_minimum': current,
              'core_coordinatewise_minimum': core, 'open_interface_minimum': open_current,
              'candidate': candidate, 'registered_companion': companion,
              'strict_improvements': {k: candidate[k] < current[k] for k in KEYS},
              'strict_core_improvements': {k: candidate['core'][k] < core[k] for k in KEYS},
              'programs': rows}
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (ROOT / 'results/metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('archive', 'file', 'scope', *KEYS, 'raw_bytes', 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
        writer.writerow({'archive': 'This work', 'file': 'checker.py', 'scope': 'arbitrary free numerical parameters', **candidate})
        writer.writerow({'archive': 'Registered companion', 'file': 'checker_registered.py', 'scope': 'arbitrary free numerical parameters', **companion})
    names = ('Tokens', 'AST', 'Bytes')
    macros = []
    for prefix, values in [('New', candidate), ('Old', current), ('Core', candidate['core']), ('OldCore', core)]:
        macros.extend('\\newcommand{\\' + prefix + n + '}{' + str(values[k]) + '}' for n, k in zip(names, KEYS))
    (ROOT / 'results/numbers.tex').write_text('\n'.join(macros) + '\n')
    labels = {
        ('ipra_combined_2026-11-07.zip', 'checker.py'): 'Combined',
        ('ipra_arity_parameters_2026-11-07.zip', 'checker.py'): 'Arity parameters, demand',
        ('ipra_arity_parameters_2026-11-07.zip', 'checker_strict.py'): 'Arity parameters, strict',
        ('ipra_fresh_arity_2026-11-07.zip', 'checker.py'): 'Fresh arity, strict',
        ('ipra_integrated_2026-11-07.zip', 'checker.py'): 'Integrated',
        ('ipra_integrated_2026-11-07 (1).zip', 'checker.py'): 'Integrated (1)',
        ('ipra_integrated_2026-11-07 (1).zip', 'checker_separate.py'): 'Integrated (1), separate depth',
        ('ipra_scope_2026-11-07.zip', 'checker.py'): 'Scope, demand',
        ('ipra_scope_2026-11-07.zip', 'checker_strict.py'): 'Scope, strict',
        ('ipra_scope_2026-11-07.zip', 'checker_closed.py'): 'Scope, closed sentences',
    }
    table = ['\\begin{tabular}{@{}lrrr@{}}\\toprule',
             'Complete acceptance program & Tokens & AST nodes & Bytes\\\\\\midrule']
    for row in rows:
        label = labels[(row['archive'], Path(row['file']).name)]
        table.append(label + ' & ' + ' & '.join(str(row[k]) for k in KEYS) + '\\\\')
    table += ['\\midrule', 'Coordinatewise minimum & ' + ' & '.join(str(current[k]) for k in KEYS) + '\\\\',
              '\\textbf{This work} & ' + ' & '.join('\\textbf{' + str(candidate[k]) + '}' for k in KEYS) + '\\\\',
              'Registered companion & ' + ' & '.join(str(companion[k]) for k in KEYS) + '\\\\\\bottomrule',
              '\\end{tabular}']
    (ROOT / 'results/comparison_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))
    if not all(result['strict_improvements'].values()) or not all(result['strict_core_improvements'].values()):
        raise ValueError('Claimed comparison does not hold under this Python runtime')
    if not all(companion[k] < current[k] and companion['core'][k] < core[k] for k in KEYS):
        raise ValueError('Companion comparison does not hold under this Python runtime')


if __name__ == '__main__':
    main()
