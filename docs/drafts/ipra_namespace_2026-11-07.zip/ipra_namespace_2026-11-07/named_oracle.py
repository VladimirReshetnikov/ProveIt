"""Independent named-binder semantics for the two parameter namespaces.

This uses the attributed explicit grammar and ordinary named substitution
in frozen/named_source.py. It does not use the kernel's packed scope/sort
coordinate, byte-string dispatch table, or inst function.
"""
from frozen.named_source import (
    NamedOracle, NamedSyntax, negative_names, require,
    substitute_names, used_holes,
)


class NamespaceOracle(NamedOracle):
    def __init__(self):
        super().__init__('demand')

    def allowed(self, tree):
        for name in negative_names(tree):
            if name % 2 == 0 and name < self.k:
                raise ValueError('undeclared private numerical parameter')

    def opening(self, value, images=(), formula=True):
        syntax = NamedSyntax()
        tree = (syntax.formula if formula else syntax.term)(
            value, holes=len(images))
        self.allowed(tree)
        replacements = {}
        for index in sorted(used_holes(tree)):
            replacements[index] = syntax.term(images[index])
            self.allowed(replacements[index])
        result = substitute_names(tree, replacements)
        return (syntax.formula_data if formula else syntax.term_data)(result)

    def allocate(self, relevant):
        names = set()
        for value in relevant:
            names |= negative_names(NamedSyntax().formula(value, holes=1))
        previous = self.k
        self.k -= 2
        require(self.k not in names, ('freshness collision', self.k, names))
        require(all(name % 2 or name >= previous for name in names),
                ('undeclared relevant private parameter', previous, names))
        self.allocations.append({'previous_supply': previous,
                                 'allocated': self.k,
                                 'relevant_names': sorted(names)})
        return self.k
