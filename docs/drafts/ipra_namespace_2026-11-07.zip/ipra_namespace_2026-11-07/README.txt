A SMALLER COMPLETE PRESENTATION OF iPRA
Freshness without scanning free parameters
Prepared for Vladimir Reshetnikov, 7 November 2026

RESULT

The primary complete checker measures 450 normalized significant Python
tokens, 467 AST nodes, and 1335 normalized UTF-8 bytes. This is strictly
below the respective minima 457 / 469 / 1352 of all ten complete top-level
checker variants in the six draft archives at ProveIt commit:

  8b00e6ea50c664476e3a3289a78287946e5e0a34

The primary retains arbitrary free numerical parameters at the root.
Its uniformly measured core is 390 / 402 / 1075, below 397 / 404 / 1092.
Measurements use CPython 3.12.14 and the unchanged baseline metric routine.

The new architecture separates free parameter labels (negative odd integers)
from generated eigenparameter labels (negative even integers declared in
order). This removes the mutating minimum-name scan. The new program also
integrates goal validation directly into its rule match. The arithmetic,
logical basis, arity representation, and demand witness policy are inherited
and explicitly attributed.

An independent companion, checker_registered.py, keeps minimum registration
and the direct match. It measures 450 / 465 / 1348 and also beats the current
envelope. The namespace version therefore trades two AST nodes for thirteen
fewer normalized bytes at equal tokens. The split alone is not claimed to
improve all three measures. Both complete programs are provided.

This is a modest strict improvement against the inspected finite corpus.
It is not a global-minimality theorem or a reduction of the arithmetic axiom
basis. The one-variable iterator research direction is explicitly unresolved.

MATHEMATICS

The report states every primitive logical rule and both recursion computation
schemas. It derives full intuitionistic first-order logic and quantifier-free
induction and proves ordinary whole-domain bi-interpretability with iPRA.
Both composite isomorphisms are defined by x=y, with internal fixed-recursion
uniqueness covering nonstandard counters. Native contradiction corresponds
to ordinary falsity through an explicit bridge in the ordinary realization.

The interpretation and checker theorems are mathematical proofs, not Lean or
Rocq formalizations. Finite executable validation supports the implementation.

START HERE

  ipra_namespace.pdf          Compiled complete paper.
  report.tex, sections/       Complete LaTeX source.
  checker.py                 Entire primary trusted acceptance program.
  FORMAT.txt                 Exact public certificate contract.
  checker_registered.py      Separately measured registered-name companion.
  measure.py, comparison/    Ten frozen current comparators, metric, provenance.
  translate.py              Untrusted trace-aware alpha-renaming compiler.
  named_oracle.py, frozen/   Independent named syntax and original corpus.
  validate.py               Primary finite validation.
  validate_registered.py    Companion finite validation.
  examples/                 45 translated public theorem certificates.
  results/                  Detailed reproducible measurements and checks.
  INVARIANTS.txt             Detailed implementation invariants.
  research/                 Explicitly conditional iterator investigation.
  validation/               Additional independent review records.
  ATTRIBUTION.txt            Inherited and new contributions.
  LICENSE_SOURCE.txt         Preserved supplied source license.
  MANIFEST.sha256            Delivered-file hashes.

REPRODUCE OFFLINE

  python3 checker.py examples/021_reflexivity_zero.json
  python3 checker.py examples/022_universal_reflexivity.json
  python3 reproduce.py
  python3 build.py

The checker prints ACCEPT (exit 0) or REJECT (exit 1). All Python support
uses only the standard library. Exact normalized counts are pinned to Python
3.12.14; the checker itself requires Python 3.10 or later. PDF rebuilding
additionally needs pdfLaTeX and the standard packages named in report.tex.
Reproduction does not use the network.

PUBLIC INPUT

The certificate is ONE JSON list: proof instructions first, goal last. It is
consumed from its end. The public context is always empty. Positive integers
are bound coordinates, not numeral values. Negative odd integers name arbitrary
free numerical parameters. Negative even integers can be used only after the
checker allocates them. A parameter label's magnitude has no connection to the
number it denotes. Arithmetic one is [0].

This is the demand witness policy: every actually used substitution image is
validated; an unused annotation can be malformed and is semantically replaced
by zero. Every active formula and every existential padding field is checked.
The format permits an unread initial proof prefix; all packaged canonical
theorem proofs consume their entire instruction stream.

The registered-name companion instead accepts the original negative-label
convention and should be used with frozen/theorems/, not the translated
examples/. Each CLI invocation starts a new name supply.

VALIDATION

Primary checks passed: 45 public theorem certificates; 53 inherited audits;
108 syntax, declaration, and substitution boundaries; 384 distinct seeded
opening inputs; 6 namespace cases; 4 deliberately defective-program controls;
and 32 real command-line runs, half under python -O. These overlapping cohorts
are not summed as independent theorems. Detailed records identify each test.

No untrusted compiler, oracle, comparison script, or test module is imported
by either complete acceptance program. Concrete memory/recursion limits may
reject a very large valid proof; the mathematical theorem concerns the finite
algorithm with sufficient resources.
