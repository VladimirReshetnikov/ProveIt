"""Focused reproducible validation, independent of the acceptance boundary.

Run from any directory with Python 3.10+. The normal run uses both in-process
checks and real command-line checks under normal Python and python -O.
"""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import types

from named_oracle import NamespaceOracle
from translate import translate

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
EXAMPLES = ROOT / 'examples'
SEED = 20261107


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_kernel(source=None):
    module = types.ModuleType('namespace_candidate')
    source = (ROOT / 'checker.py').read_text() if source is None else source
    exec(compile(source, 'namespace_candidate', 'exec'), module.__dict__)
    return module


def verdict(module, certificate):
    module.k = 0
    stream = deepcopy(certificate)
    try:
        goal = stream.pop()
        module.take = stream.pop
        accepted = bool(module.check(goal, []))
        error = None
    except Exception as exc:
        accepted = False
        error = type(exc).__name__
    return {'accepted': accepted, 'final_supply': module.k,
            'unread_instructions': len(stream), 'error': error}


def named_verdict(certificate):
    goal, proof = certificate[-1], certificate[:-1]
    accepted, supply, unread = NamespaceOracle().verdict([goal, proof])
    return {'accepted': accepted, 'final_supply': supply,
            'unread_instructions': unread}


def reflexivity(term):
    axiom = [[0, term, 0], term]
    return [[], [], [axiom, [1, term]], [term, term]]


def fake_witness_elimination(parameter):
    # From a genuine proof of exists x (x=0), try to infer parameter=0.
    # This succeeds only if a defective allocator captures that parameter.
    major = [[1, 0], [0, 0], [0, 0]]
    return ([None] + reflexivity(0)[:-1] + [[0], [major, None]]
            + [[parameter, 0]])


def check_corpus(module):
    rows = []
    for source in sorted((ROOT / 'frozen' / 'theorems').glob('*.json')):
        certificate, trace = translate(json.loads(source.read_text()))
        # Replay is deterministic, including allocation order.
        repeat, repeated_trace = translate(json.loads(source.read_text()))
        require(certificate == repeat and trace == repeated_trace,
                ('nondeterministic translation', source.name))
        actual = verdict(module, certificate)
        oracle = named_verdict(certificate)
        require(actual['accepted'] and oracle['accepted'],
                ('translated theorem rejected', source.name, actual, oracle))
        require(actual['final_supply'] == oracle['final_supply']
                == trace['target_final_supply_expected'],
                ('allocation trace changed', source.name))
        require(actual['unread_instructions'] == oracle['unread_instructions']
                == trace['source_unread_instructions'] == 0,
                ('instruction trace changed', source.name))
        target = EXAMPLES / source.name
        write_json(target, certificate)
        rows.append({'name': source.name, 'source_sha256': digest(source),
                     'target_sha256': digest(target), 'kernel': actual,
                     'named_oracle': oracle, 'translation': trace})
    require(len(rows) == 45, 'wrong frozen public theorem inventory')
    write_json(RESULTS / 'corpus.json', rows)
    return rows


def check_inherited_audits(module):
    cases = json.loads((ROOT / 'frozen' / 'source_audit_cases.json').read_text())
    rows = []
    translated_cases = []
    for case in cases:
        source = case['proof'] + [case['goal']]
        certificate, trace = translate(source, allow_rejected=True)
        actual = verdict(module, certificate)
        oracle = named_verdict(certificate)
        expected = case['expected_demand']
        require(trace['source_accepted'] == actual['accepted']
                == oracle['accepted'] == expected,
                ('inherited audit mismatch', case['name'], trace, actual, oracle))
        if expected:
            require(actual['final_supply'] == oracle['final_supply']
                    == trace['target_final_supply_expected'],
                    ('accepted audit allocation mismatch', case['name']))
        rows.append({'name': case['name'], 'expected': expected,
                     'kernel': actual, 'named_oracle': oracle})
        translated_cases.append({'name': case['name'], 'expected': expected,
                                 'certificate': certificate})
    write_json(RESULTS / 'inherited_audits.json', rows)
    write_json(RESULTS / 'inherited_cases.json', translated_cases)
    return rows, translated_cases


def compare_opening(module, value, images=(), formula=True, supply=0):
    module.k = supply
    oracle = NamespaceOracle()
    oracle.k = supply
    try:
        actual = module.inst(value, images, d=0 if formula else 1)
        actual_ok = True
    except Exception:
        actual = None
        actual_ok = False
    try:
        expected = oracle.opening(value, images, formula=formula)
        expected_ok = True
    except Exception:
        expected = None
        expected_ok = False
    require(actual_ok == expected_ok and (not actual_ok or actual == expected),
            ('opening mismatch', value, images, formula, supply, actual, expected))
    require(module.k == oracle.k == supply, 'read-only opening changed allocation supply')
    return actual_ok


def check_opening_boundaries(module):
    rows = []

    def run(label, value, expected, images=(), formula=False, supply=0):
        accepted = compare_opening(module, value, images, formula, supply)
        require(accepted == expected, ('boundary mismatch', label, value))
        rows.append({'name': label, 'accepted': accepted, 'expected': expected,
                     'supply': supply})

    bad_terms = [True, False, None, 1, 2, 1.0, 1.5, '0', {}, [], [0, 0],
                 [0, 0, 3], [True], [0, 0, [0, 0, 5]], [0, 0, 0, 0],
                 -2, -4, [-2], [0, -2, 1]]
    for i, value in enumerate(bad_terms):
        run('bad_term_' + str(i), value, False)
    good_terms = [0, -1, -3, -(10 ** 40) - 1, [0], [0, 0, 1], [0, 0, 2],
                  [0, 0, [0, 0, 3]], [0, 0, [0, 0, 4]]]
    for i, value in enumerate(good_terms):
        run('valid_term_' + str(i), value, True)
    bad_formulas = [[], 0, True, [0], [0, 1], [[2, 2]],
                    [[0, 0], [0, 0], [2, 2]], [[0, 0], [0, 0], True],
                    [0, 0, 0, 0], [-2, -2], [[1, -2]]]
    for i, value in enumerate(bad_formulas):
        run('bad_formula_' + str(i), value, False, formula=True)
    used = [[1, 0], [[[3, 1], [0, 0], [0, 0]]], [[2, 1]],
            [[0, 0, 3], 0], [[0, 0], [2, 0], [0, 0]],
            [[0, 0], [0, 0], [2, 0]]]
    images = [None, True, False, 1, [1], [0, 0, 3], -2]
    for i, body in enumerate(used):
        for j, image in enumerate(images):
            run('used_bad_image_%d_%d' % (i, j), body, False,
                images=[image], formula=True)
    unused = [[0, 0], [[1, 1]], [[1, 1], [0, 0], [0, 0]]]
    for i, body in enumerate(unused):
        for j, image in enumerate(images):
            run('unused_image_%d_%d' % (i, j), body, True,
                images=[image], formula=True)
    for name in [-2, -4, -1, -9999999]:
        run('declared_or_public_' + str(name), name, True, supply=-4)
    for name in [-6, -8]:
        run('not_yet_declared_' + str(name), name, False, supply=-4)
    write_json(RESULTS / 'opening_boundaries.json', rows)
    return rows


def check_random_openings(module):
    rng = random.Random(SEED)
    rows = []
    seen = set()

    def term(depth, bound, holes):
        if depth == 0 or rng.randrange(3) == 0:
            return rng.choice([0, -1, -9999999, -2, -4]
                              + list(range(1, bound + holes + 1)))
        if rng.randrange(2):
            return [term(depth - 1, bound, holes)]
        return [term(depth - 1, bound, holes),
                term(depth - 1, bound, holes),
                term(depth - 1, bound + 2, holes)]

    def formula(depth, bound, holes):
        if depth == 0 or rng.randrange(3) == 0:
            return [term(2, bound, holes), term(2, bound, holes)]
        if rng.randrange(2):
            return [formula(depth - 1, bound + 1, holes)]
        return [formula(depth - 1, bound + 1, holes) for _ in range(3)]

    while len(rows) < 384:
        is_formula = bool(len(rows) % 2)
        holes = rng.randrange(3)
        value = (formula if is_formula else term)(3, 0, holes)
        images = [term(2, 0, 0) for _ in range(holes)]
        key = json.dumps([value, images, is_formula], separators=(',', ':'))
        if key in seen:
            continue
        seen.add(key)
        require(compare_opening(module, value, images, is_formula, -4),
                'generated valid opening rejected')
        rows.append({'formula': is_formula, 'input': value, 'images': images})
    write_json(RESULTS / 'random_openings.json', {'seed': SEED, 'cases': rows})
    return len(rows)


def check_namespace_cases(module):
    huge = -(10 ** 40) - 1
    vacuous_exists = reflexivity(0)[:-1] + [[-200], [[0, 0], [0, 0], [0, 0]]]
    cases = [
        {'name': 'arbitrary_large_public_parameter', 'certificate': reflexivity(huge), 'expected': True},
        {'name': 'reserved_name_in_final_conclusion', 'certificate': reflexivity(-2), 'expected': False},
        {'name': 'future_reserved_name_in_final_conclusion', 'certificate': reflexivity(-200), 'expected': False},
        {'name': 'public_parameter_not_captured', 'certificate': fake_witness_elimination(-1), 'expected': False},
        {'name': 'undeclared_private_parameter_not_captured', 'certificate': fake_witness_elimination(-2), 'expected': False},
        {'name': 'unused_undeclared_witness_is_inert', 'certificate': vacuous_exists, 'expected': True},
    ]
    rows = []
    for case in cases:
        actual = verdict(module, case['certificate'])
        oracle = named_verdict(case['certificate'])
        require(actual['accepted'] == oracle['accepted'] == case['expected'],
                ('namespace test mismatch', case, actual, oracle))
        rows.append({'name': case['name'], 'expected': case['expected'],
                     'kernel': actual, 'named_oracle': oracle})
    write_json(RESULTS / 'namespace_cases.json', cases)
    write_json(RESULTS / 'namespace_results.json', rows)
    return rows, cases


def check_defect_controls(module, audit_cases):
    source = (ROOT / 'checker.py').read_text()
    by_name = {case['name']: case for case in audit_cases}
    specs = [
        ('namespace_guard_deleted', ' and (a % 2 or a >= k)', '',
         fake_witness_elimination(-2)),
        ('wrong_parity_allocator', 'k -= 2', 'k -= 1',
         fake_witness_elimination(-1)),
        ('substitution_image_validation_deleted',
         'else inst(env[a - d // 2 - 1], d=1)',
         'else env[a - d // 2 - 1]',
         by_name['capture_by_illegal_positive_witness']['certificate']),
        ('compound_induction_hypothesis_added', '[:2 - len(b) % 2]', '',
         by_name['compound_induction_hypothesis_is_unavailable']['certificate']),
    ]
    rows = []
    for name, old, replacement, certificate in specs:
        require(source.count(old) == 1, ('mutant site changed', name))
        changed = load_kernel(source.replace(old, replacement, 1))
        original = verdict(module, certificate)
        defective = verdict(changed, certificate)
        require(not original['accepted'] and defective['accepted'],
                ('defect-control test did not distinguish programs', name,
                 original, defective))
        rows.append({'name': name, 'correct_kernel': original,
                     'deliberately_defective_kernel': defective})
    write_json(RESULTS / 'defect_controls.json', rows)
    return rows


def check_cli(audit_cases, namespace_cases):
    names = ['001_encoded_forall_exists_successor.json',
             '022_universal_reflexivity.json',
             '048_transport_through_existential.json',
             '051_recursion_nested_update_2.json',
             '052_equation_induction_at_parameter.json']
    cases = [(EXAMPLES / name, True) for name in names]
    for case in [*namespace_cases, *(case for case in audit_cases if case['name'] in {
            'capture_by_illegal_positive_witness',
            'compound_induction_hypothesis_is_unavailable',
            'malformed_first_existential_annotation', 'boolean_in_goal', 'float_in_goal'})]:
        path = RESULTS / 'cli_inputs' / (case['name'] + '.json')
        write_json(path, case['certificate'])
        cases.append((path, case['expected']))
    rows = []
    for optimized in (False, True):
        for path, expected in cases:
            command = [sys.executable] + (['-O'] if optimized else [])
            command += [str(ROOT / 'checker.py'), str(path)]
            result = subprocess.run(command, text=True, capture_output=True, timeout=20)
            require(result.returncode == (0 if expected else 1)
                    and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT')
                    and not result.stderr,
                    ('command-line mismatch', path.name, optimized, result))
            rows.append({'file': str(path.relative_to(ROOT)), 'optimized': optimized,
                         'expected': expected, 'exit_code': result.returncode,
                         'stdout': result.stdout.strip()})
    write_json(RESULTS / 'cli.json', rows)
    return rows


def main():
    module = load_kernel()
    corpus = check_corpus(module)
    audits, audit_cases = check_inherited_audits(module)
    boundaries = check_opening_boundaries(module)
    openings = check_random_openings(module)
    namespaces, namespace_cases = check_namespace_cases(module)
    controls = check_defect_controls(module, audit_cases)
    cli = check_cli(audit_cases, namespace_cases)
    result = {
        'python': platform.python_version(), 'checker_sha256': digest(ROOT / 'checker.py'),
        'public_theorem_certificates': len(corpus),
        'inherited_audit_cases': len(audits),
        'opening_boundary_cases': len(boundaries),
        'distinct_random_opening_inputs': openings,
        'namespace_cases': len(namespaces),
        'deliberate_defect_controls': len(controls),
        'actual_cli_runs_including_optimized': len(cli),
        'all_checks_passed': True,
        'limitations': 'Finite checks support the implementation and alpha compiler; they do not formalize universal soundness, completeness, or bi-interpretability.',
    }
    write_json(RESULTS / 'validation.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
