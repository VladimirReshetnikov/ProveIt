"""Attributed named-binder oracle, extracted unchanged from the scope draft.

Source: ProveIt commit 8b00e6ea50c664476e3a3289a78287946e5e0a34,
docs/drafts/ipra_scope_2026-11-07.zip, validation/run.py.
Only selected definitions and their one required import are retained.
This is untrusted validation support, never imported by checker.py.
"""
from copy import deepcopy

def require(condition, message):
    if not condition:
        raise AssertionError(message)

class NamedSyntax:
    """Explicit named binding, independent of the packed-depth algorithm."""
    def __init__(self):
        self.serial = 0

    def fresh(self):
        self.serial += 1
        return ('binder', self.serial)

    def term(self, a, bound=(), holes=0):
        if type(a) is int:
            if a <= 0:
                return ('constant', a)
            if a <= len(bound):
                return ('variable', bound[a - 1])
            slot = a - len(bound) - 1
            if slot < holes:
                return ('hole', slot)
            raise ValueError('unbound positive term coordinate')
        if type(a) is not list:
            raise ValueError('term is neither an integer nor a constructor')
        if len(a) == 1:
            return ('successor', self.term(a[0], bound, holes))
        if len(a) == 3:
            u, v = self.fresh(), self.fresh()
            return ('recursor', self.term(a[0], bound, holes),
                    self.term(a[1], bound, holes), u, v,
                    self.term(a[2], (u, v) + bound, holes))
        raise ValueError('wrong numerical constructor arity')

    def formula(self, a, bound=(), holes=0):
        if type(a) is not list:
            raise ValueError('formula is not an array')
        if len(a) == 2:
            return ('equal', self.term(a[0], bound, holes),
                    self.term(a[1], bound, holes))
        if len(a) == 1:
            x = self.fresh()
            return ('closure', x, self.formula(a[0], (x,) + bound, holes))
        if len(a) == 3:
            x = self.fresh()
            return ('exists', x, *(self.formula(b, (x,) + bound, holes) for b in a))
        raise ValueError('wrong formula constructor arity')

    def term_data(self, t, bound=()):
        tag = t[0]
        if tag == 'constant':
            return t[1]
        if tag == 'variable':
            return bound.index(t[1]) + 1
        if tag == 'successor':
            return [self.term_data(t[1], bound)]
        if tag == 'recursor':
            _, n, a, u, v, h = t
            return [self.term_data(n, bound), self.term_data(a, bound),
                    self.term_data(h, (u, v) + bound)]
        raise ValueError('unsubstituted hole in result')

    def formula_data(self, a, bound=()):
        tag = a[0]
        if tag == 'equal':
            return [self.term_data(a[1], bound), self.term_data(a[2], bound)]
        if tag == 'closure':
            return [self.formula_data(a[2], (a[1],) + bound)]
        if tag == 'exists':
            return [self.formula_data(b, (a[1],) + bound) for b in a[2:]]
        raise ValueError('unknown named formula')

def children(a):
    tag = a[0]
    if tag in ('constant', 'variable', 'hole'):
        return ()
    if tag == 'successor':
        return (a[1],)
    if tag == 'recursor':
        return (a[1], a[2], a[5])
    if tag == 'equal':
        return a[1:]
    if tag in ('closure', 'exists'):
        return a[2:]
    raise ValueError('unknown named syntax')

def used_holes(a):
    if a[0] == 'hole':
        return {a[1]}
    return set().union(*(used_holes(c) for c in children(a)))

def negative_names(a):
    if a[0] == 'constant' and a[1] < 0:
        return {a[1]}
    return set().union(*(negative_names(c) for c in children(a)))

def substitute_names(a, replacements):
    """Ordinary structural replacement of uniquely named free holes."""
    tag = a[0]
    if tag == 'hole':
        return replacements[a[1]]
    if tag in ('constant', 'variable'):
        return a
    if tag == 'successor':
        return (tag, substitute_names(a[1], replacements))
    if tag == 'recursor':
        return (tag, substitute_names(a[1], replacements),
                substitute_names(a[2], replacements), a[3], a[4],
                substitute_names(a[5], replacements))
    if tag == 'equal':
        return (tag, *(substitute_names(c, replacements) for c in a[1:]))
    if tag in ('closure', 'exists'):
        return (tag, a[1], *(substitute_names(c, replacements) for c in a[2:]))
    raise ValueError('unknown named syntax')

class NamedOracle:
    """A separate rule interpreter using named substitution, not packed depth."""
    def __init__(self, policy):
        self.policy = policy
        self.k = 0
        self.stack = []
        self.allocations = []

    def opening(self, a, images=(), formula=True):
        syntax = NamedSyntax()
        tree = (syntax.formula if formula else syntax.term)(a, holes=len(images))
        self.k = min(self.k, *negative_names(tree)) if negative_names(tree) else self.k
        selected = range(len(images)) if self.policy == 'strict' else sorted(used_holes(tree))
        replacements = {}
        for i in selected:
            replacements[i] = syntax.term(images[i])
            names = negative_names(replacements[i])
            if names:
                self.k = min(self.k, *names)
        result = substitute_names(tree, replacements)
        return (syntax.formula_data if formula else syntax.term_data)(result)

    def allocate(self, relevant):
        names = set()
        for a in relevant:
            # A matrix can have one distinguished hole, but that is not a name.
            names |= negative_names(NamedSyntax().formula(a, holes=1))
        old = self.k
        self.k -= 1
        require(self.k not in names, ('oracle eigenparameter collision', self.k, names))
        require(all(self.k < n for n in names), ('oracle did not register all names', self.k, names))
        self.allocations.append({'previous_supply': old, 'allocated': self.k,
                                 'relevant_names': sorted(names)})
        return self.k

    def check(self, a, g):
        self.opening(a)
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, g):
                if len(major) == 3:
                    eigen = self.allocate([a, *g, major])
                    assumption = self.opening(major[0], [eigen])
                    return self.check(a, [*g, assumption])
                if len(major) == 1:
                    motive, images = major[0], (0, annotation)
                else:
                    motive, images = annotation, major
                base, result = (self.opening(motive, [v]) for v in images)
                return result == a and self.check(base, g)
            return a in g
        if len(a) == 1 and instruction == []:
            body = a[0]
            base = self.opening(body, [0])
            local = [base]
            if len(body) == 2:
                local.append(body)
            eigen = self.allocate([a, *g])
            goal = self.opening(body, [[eigen]])
            assumptions = [self.opening(b, [eigen]) for b in local]
            return self.check(goal, [*g, *assumptions])
        if len(a) == 3 and type(instruction) is list and len(instruction) == 1:
            return self.check(self.opening(a[0], [instruction[0]]), g)
        if (len(a) == 2 and type(a[0]) is list and len(a[0]) == 3
                and instruction == []):
            n, initial, update = a[0]
            expected = initial
            if n != 0:
                if type(n) is not list or len(n) != 1:
                    raise ValueError('recursor computation counter is not zero or successor')
                n = n[0]
                expected = self.opening(update, [[n, initial, update], n], formula=False)
            return a[1] == expected
        return a in g

    def verdict(self, data):
        self.k = 0
        self.allocations = []
        a, p, *g = deepcopy(data)
        self.stack = p
        try:
            for h in g:
                self.opening(h)
            result = bool(self.check(a, g))
            return result, self.k, len(self.stack)
        except Exception as exc:
            if isinstance(exc, AssertionError):
                raise
            return False, self.k, len(self.stack)

