"""Build the complete paper locally using pdfLaTeX."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    target = ROOT / '_build'
    target.mkdir(exist_ok=True)
    if shutil.which('pdflatex') is None:
        raise SystemExit('pdflatex is required to rebuild the supplied PDF')
    command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
               '-file-line-error', '-jobname=ipra_namespace',
               '-output-directory=' + str(target), 'report.tex']
    for run in range(3):
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        (target / ('pass_' + str(run + 1) + '.txt')).write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-8000:])
            raise SystemExit('LaTeX failed; inspect _build/')
    log = (target / 'ipra_namespace.log').read_text()
    defects = [line for line in log.splitlines()
               if 'Overfull \\hbox' in line or 'undefined' in line.lower()
               or 'multiply defined' in line.lower()]
    if defects:
        raise SystemExit('\n'.join(defects))
    shutil.copyfile(target / 'ipra_namespace.pdf', ROOT / 'ipra_namespace.pdf')
    print('Built ipra_namespace.pdf with no undefined references or overfull boxes.')


if __name__ == '__main__':
    main()
