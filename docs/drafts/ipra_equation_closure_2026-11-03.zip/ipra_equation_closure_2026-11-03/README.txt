iPRA FROM EQUATION CLOSURE
3 November 2026
=========================

Start with report.pdf. AXIOMS.txt is an exact standalone specification.

RESULT
A one-fixed-sentence, two-schema presentation of full intuitionistic PRA.
The induction schema is indexed only by equations E(x,c). It asserts that
successor closure of x=0 OR E(x,c) implies its universality. This derives
both equation induction and numerical coverage, then full quantifier-free
induction by constructive equality reflection.

A completely specified generic logical binder gives a paid fixed record
of 23 nodes; a partially binding companion gives 22, with one extra node in
each separately closed schema instance. The smallest comparable paid
records in the four current drafts were 28. These are finite prefix counts,
not sizes of the full logic, effective generators, or infinite theories.

The report proves full whole-carrier bi-interpretability with iPRA and both
internal identity round trips. It also gives two further recursion reductions
missed by all four current rule lists and an exact nonincreasing homomorphic
image for every finite axiom packet from each source, keeping its own
interface and support. Strict family savings are unbounded.

TRADEOFFS
The new ordinary expansion is not uniformly smaller. The complete generated-Q
constructor packet of 53 beats witnessed-J's 61, but direct-K4 has a 47-node
constructor packet. The U/V schema and an old boundary for the same equation
are not equivalent in isolation; the packet guarantee is a separate theorem.
The exact old-module image retains residual expanded computation clauses.
No universal proof-length or absolute-minimality claim is made.

CONTENTS
report.tex / report.pdf       Full article and compiled PDF
AXIOMS.txt                   Exact reference specification and costs
artifacts/check_*.py          Three standard-library diagnostic programs
artifacts/*.json             Completed results and tested ranges
provenance/                  Pinned source manifest and comparison ledger
build.py                     Rebuild checks, PDF, checksums, optional ZIP
SHA256SUMS.txt                SHA-256 hashes of the deliverable files

REBUILD
  python3 build.py
  python3 build.py --checks-only
  python3 build.py --archive

The diagnostics require Python 3.10 or later and no third-party packages.
PDF generation requires pdflatex and the standard packages in report.tex.
Temporary build output is written to .build and excluded from ZIPs.

VERIFICATION STATUS
Complete written mathematical proofs; independent proof reviews; exact AST
and scope diagnostics; symbolic base/step checks; finite numerical examples.
No full Lean/Rocq formalization. The numerical tests do not establish claims
about nonstandard models; those are handled by internal induction proofs.

SOURCE SNAPSHOT
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: f26a867c0f5c94ec91e2aa26030720ed5046bca8
Four current ZIPs and three archived ZIPs, all blob identities verified.
All four current drafts pass the requested historical improvement filter.
Exact source paths and hashes are recorded in provenance/source_manifest.json.
Original source archives are referenced, not duplicated in this package.
