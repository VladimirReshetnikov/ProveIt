#!/usr/bin/env python3
"""Reproduce the diagnostics, PDF, and checksums using Python and pdflatex."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


ROOT = Path(__file__).resolve().parent


def run(command: list[str], log: Path) -> None:
    completed = subprocess.run(
        command, cwd=ROOT, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, text=True, check=False,
    )
    log.write_text(completed.stdout, encoding="utf-8")
    if completed.returncode:
        print(completed.stdout[-6000:], file=sys.stderr)
        raise SystemExit(f"Command failed; see {log.name}")


def inventory() -> list[Path]:
    return sorted(
        path for path in ROOT.rglob("*")
        if path.is_file()
        and not any(part in {".build", "__pycache__"} for part in path.relative_to(ROOT).parts)
        and path.name != "SHA256SUMS.txt"
        and path.suffix != ".zip"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    artifacts = ROOT / "artifacts"
    cache = ROOT / ".build"
    artifacts.mkdir(exist_ok=True)
    cache.mkdir(exist_ok=True)

    run([sys.executable, "artifacts/check_new_core.py", "--output",
         "artifacts/new_core_checks.json"], cache / "core_stdout.txt")
    run([sys.executable, "artifacts/check_block.py"], cache / "block_stdout.txt")
    run([sys.executable, "artifacts/check_v.py"], cache / "v_stdout.txt")
    for name in ("new_core_checks.json", "block_verification.json", "v_verification.json"):
        result = json.loads((artifacts / name).read_text(encoding="utf-8"))
        assert result["status"].lower() in {"pass", "passed"}, name
    print("All three diagnostic suites passed.")
    if args.checks_only:
        return

    if shutil.which("pdflatex") is None:
        raise SystemExit("Install pdflatex and the packages in report.tex to rebuild the PDF.")
    for iteration in range(1, 4):
        run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
             "-output-directory=.build", "report.tex"], cache / f"latex_{iteration}.txt")
    latex_log = (cache / "report.log").read_text(encoding="utf-8")
    disallowed = ["There were undefined references", "There were undefined citations",
                  "Label(s) may have changed", "Overfull "]
    problems = [item for item in disallowed if item in latex_log]
    if problems:
        raise SystemExit("PDF needs inspection: " + ", ".join(problems))
    shutil.copyfile(cache / "report.pdf", ROOT / "report.pdf")
    (artifacts / "build_summary.txt").write_text(
        "All diagnostic suites passed.\n"
        "PDF compiled successfully in three passes.\n"
        "No unresolved references, citations, or overfull boxes in the final log.\n"
        "Mathematical metatheorems rely on the written proofs.\n",
        encoding="utf-8",
    )
    checksum_text = "".join(
        f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(ROOT).as_posix()}\n"
        for path in inventory()
    )
    (ROOT / "SHA256SUMS.txt").write_text(checksum_text, encoding="utf-8")
    print("PDF and checksums rebuilt.")
    if args.archive:
        archive = ROOT.parent / f"{ROOT.name}.zip"
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
            for path in inventory() + [ROOT / "SHA256SUMS.txt"]:
                bundle.write(path, arcname=f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}")
        print(f"Archive created: {archive.name}")


if __name__ == "__main__":
    main()
