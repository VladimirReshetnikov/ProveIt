#!/usr/bin/env python3
"""Independent finite diagnostics for the rooted-closure core and intertwining.

Uses actual immutable syntax trees with charged frozen recursor descriptors.
These checks are not a proof-assistant formalization of the universal theorems.
No external dependencies. Run: python3 check_new_core.py [--output FILE]
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import product
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    op: str
    args: tuple[Node, ...] = ()
    name: str = ""
    descriptor: Node | None = None
    parameters: tuple[str, ...] = ()


def V(name):
    return Node("var", name=name)


Z = Node("zero")
BOT = Node("bottom")


def S(term):
    return Node("successor", (term,))


def Eq(left, right):
    return Node("equality", (left, right))


def And(left, right):
    return Node("and", (left, right))


def Or(left, right):
    return Node("or", (left, right))


def Imp(left, right):
    return Node("implies", (left, right))


def All(variable, formula):
    return Node("forall", (formula,), name=variable)


def Exists(variable, formula):
    return Node("exists", (formula,), name=variable)


def U(variable, predicate, update):
    return Node("closure_binder", (predicate, update), name=variable)


def call(name, descriptor, counter, initial, *arguments, parameters=()):
    assert len(arguments) == len(parameters)
    return Node("recursor", (counter, initial, *arguments), name=name,
                descriptor=descriptor, parameters=tuple(parameters))


def Q(counter, initial):
    return call("Q", V("w"), counter, initial)


def A(counter, initial):
    return call("A", S(V("v")), counter, initial)


def pred(term):
    return Q(term, Z)


def repeat(function, times, term):
    for _ in range(times):
        term = function(term)
    return term


def charge(node):
    """Every descriptor is paid recursively at every recursor occurrence."""
    return (1 + sum(charge(child) for child in node.args)
            + (charge(node.descriptor) if node.descriptor is not None else 0))


def free_variables(node):
    if node.op == "var":
        return {node.name}
    result = set().union(*(free_variables(child) for child in node.args))
    if node.op in ("forall", "exists", "closure_binder"):
        result.discard(node.name)
    # Descriptor slots belong to an independent frozen scope.
    return result


def active_occurrences(node, variable):
    if node.op == "var":
        return int(node.name == variable)
    if node.op in ("forall", "exists", "closure_binder") and node.name == variable:
        return 0
    return sum(active_occurrences(child, variable) for child in node.args)


def substitute(node, substitution):
    """Simultaneous, capture-avoiding substitution in active positions only."""
    if node.op == "var":
        return substitution.get(node.name, node)
    name = node.name
    children = node.args
    local = dict(substitution)
    if node.op in ("forall", "exists", "closure_binder"):
        local.pop(name, None)
        relevant = set().union(*(free_variables(child) for child in children))
        relevant.discard(name)
        inserted_free = set().union(*(
            free_variables(term) for key, term in local.items() if key in relevant
        ))
        if name in inserted_free:
            avoid = relevant | inserted_free | set(local) | {name}
            suffix = 0
            fresh = f"{name}_{suffix}"
            while fresh in avoid:
                suffix += 1
                fresh = f"{name}_{suffix}"
            children = tuple(substitute(child, {name: V(fresh)}) for child in children)
            name = fresh
    return Node(node.op, tuple(substitute(child, local) for child in children),
                name, node.descriptor, node.parameters)


def expand_u(node):
    assert node.op == "closure_binder"
    predicate, update = node.args
    advanced = substitute(predicate, {node.name: update})
    return Imp(All(node.name, Imp(predicate, advanced)), All(node.name, predicate))


def close(formula, parameters):
    for variable in reversed(parameters):
        formula = All(variable, formula)
    return formula


def rooted_instance(equation, parameters, expanded=False):
    guarded = Or(Eq(V("x"), Z), equation)
    formula = U("x", guarded, S(V("x")))
    return close(expand_u(formula) if expanded else formula, parameters)


def module(name, descriptor, parameters=()):
    a, n = V("a"), V("n")
    actual = tuple(V(c) for c in parameters)
    at = lambda counter: call(name, descriptor, counter, a, *actual,
                              parameters=parameters)
    substitution = {"v": at(n), "w": n}
    substitution.update(zip(parameters, actual))
    body = And(Eq(at(Z), a),
               All("n", Eq(at(S(n)), substitute(descriptor, substitution))))
    return close(body, ("a", *parameters))


def unfold_once(node):
    """One ordinary recursor equation, without rewriting descriptor metadata."""
    assert node.op == "recursor"
    counter, initial, *actual = node.args
    if counter == Z:
        return initial
    assert counter.op == "successor"
    previous = Node("recursor", (counter.args[0], initial, *actual), node.name,
                    node.descriptor, node.parameters)
    substitution = {"v": previous, "w": counter.args[0]}
    substitution.update(zip(node.parameters, actual))
    return substitute(node.descriptor, substitution)


def normalize_q_and_bases(node):
    """Only finite Q predecessor contractions and ordinary zero equations."""
    children = tuple(normalize_q_and_bases(child) for child in node.args)
    result = Node(node.op, children, node.name, node.descriptor, node.parameters)
    if result.op == "recursor":
        counter = children[0]
        if counter == Z or (result.name == "Q" and counter.op == "successor"):
            return normalize_q_and_bases(unfold_once(result))
    return result


def replace_active(node, old, replacement):
    if node == old:
        return replacement
    return Node(node.op, tuple(replace_active(c, old, replacement) for c in node.args),
                node.name, node.descriptor, node.parameters)


def translate_hj(node, index):
    """Fixed symbol interpretation, preserving every retained frozen label."""
    children = tuple(translate_hj(child, index) for child in node.args)
    if node.op == "recursor" and node.name == f"H{index}":
        return call("H0", A(V("w"), V("v")), *children)
    return Node(node.op, children, node.name, node.descriptor, node.parameters)


def evaluate(node, environment):
    if node.op == "zero":
        return 0
    if node.op == "var":
        return environment[node.name]
    if node.op == "successor":
        return 1 + evaluate(node.args[0], environment)
    if node.op != "recursor":
        raise ValueError(f"Not a numerical term: {node.op}")
    counter, state, *actual = (evaluate(child, environment) for child in node.args)
    local = dict(zip(node.parameters, actual))
    for previous in range(counter):
        local.update(v=state, w=previous)
        state = evaluate(node.descriptor, local)
    return state


def active_recursor_nodes(node):
    if node.op == "recursor":
        yield node
    for child in node.args:
        yield from active_recursor_nodes(child)


def family(index):
    f = repeat(S, index + 1, repeat(pred, index, V("v")))
    F = lambda counter, initial: call(f"F{index}", f, counter, initial)
    h = repeat(pred, index, F(V("w"), repeat(S, index, V("v"))))
    return f, F, h


def check_core():
    x = V("x")
    template_p = Node("predicate_template", (x,), name="P")
    template_h = Node("term_template", (x,), name="h")
    generic = U("x", template_p, template_h)
    record = 1 + charge(generic) + charge(expand_u(generic))
    assert (charge(generic), charge(expand_u(generic)), record) == (5, 11, 17)
    sep = Imp(Eq(Z, S(Z)), BOT)
    assert charge(sep) == 6
    q_module = module("Q", V("w"))
    assert charge(q_module) == 16
    coverage_equation = Eq(S(Q(x, Z)), x)
    coverage = rooted_instance(coverage_equation, ())
    assert charge(coverage_equation) == 7
    assert charge(coverage) == 14
    assert not free_variables(coverage)
    advanced = substitute(coverage_equation, {"x": S(x)})
    assert normalize_q_and_bases(advanced) == Eq(S(x), S(x))
    examples = [
        (Eq(x, x), ()),
        (Eq(x, Z), ()),
        (Eq(S(x), V("c0")), ("c0",)),
        (Eq(Q(x, V("c0")), V("c1")), ("c0", "c1")),
        (Eq(A(x, A(x, V("c0"))), S(V("c1"))), ("c0", "c1")),
        (Eq(V("c0"), V("c1")), ("c0", "c1")),
        (Eq(x, Z), ("unused0", "unused1", "unused2")),
    ]
    rows = []
    for equation, parameters in examples:
        F = charge(equation)
        k = active_occurrences(equation, "x")
        p = len(parameters)
        paid = rooted_instance(equation, parameters)
        raw = rooted_instance(equation, parameters, expanded=True)
        assert charge(paid) == F + p + 7
        assert charge(raw) == 3 * F + k + p + 17
        assert not free_variables(paid) and not free_variables(raw)
        rows.append(dict(F=F, active_x=k, parameters=p,
                         paid=charge(paid), expanded=charge(raw)))
    return {
        "definition_lhs": 5, "definition_rhs": 11, "definition_record": record,
        "separation": charge(sep), "fixed_paid_record": charge(sep) + record,
        "Q_module": charge(q_module), "coverage_matrix": charge(coverage_equation),
        "coverage_instance": charge(coverage),
        "constructor_bootstrap": charge(sep) + record + charge(q_module) + charge(coverage),
        "coverage_successor_equation_rewrites_to_reflexivity": True,
        "schema_examples": rows,
    }


def check_scope():
    formula = All("y", Eq(V("x"), V("y")))
    translated = substitute(formula, {"x": V("y")})
    assert translated.name != "y"
    assert free_variables(translated) == {"y"}
    assert translated.args[0] == Eq(V("y"), V(translated.name))
    descriptor = V("c1")
    term = call("C", descriptor, V("x"), Z, V("c1"), parameters=("c1",))
    translated_term = substitute(term, {"c1": S(V("c1")), "x": S(V("x"))})
    assert translated_term.descriptor is descriptor
    assert translated_term.args == (S(V("x")), Z, S(V("c1")))
    binder = U("x", Or(Eq(V("x"), Z), Eq(V("x"), V("y"))), S(V("x")))
    translated_binder = substitute(binder, {"y": V("x")})
    assert translated_binder.name != "x"
    assert free_variables(translated_binder) == {"x"}
    assert free_variables(expand_u(translated_binder)) == {"x"}
    return dict(capture_avoidance=True, frozen_descriptor_scope=True,
                generic_binder_capture_avoidance=True)


def check_rooted_closure():
    """Finite semantic check of the logical mechanism, not full arithmetic models."""
    map_count = instance_count = 0
    for size in range(1, 5):
        universe = set(range(size))
        for successor in product(range(size), repeat=size):
            map_count += 1
            every_instance = True
            for bits in product((False, True), repeat=size):
                instance_count += 1
                E = {x for x in universe if bits[x]}
                P = E | {0}
                closed_P = all(successor[x] in P for x in P)
                instance = (not closed_P) or P == universe
                every_instance = every_instance and instance
                base = 0 in E
                closed_E = all(successor[x] in E for x in E)
                assert not (instance and base and closed_E) or E == universe
            orbit = set()
            point = 0
            while point not in orbit:
                orbit.add(point)
                point = successor[point]
            assert every_instance == (orbit == universe)
    return dict(domains_checked="1..4", successor_maps=map_count,
                predicate_instances=instance_count,
                equation_induction_implication=True,
                all_rooted_instances_equivalent_to_root_generation=True,
                scope="Isolated logical mechanism; these are not finite models of iPRA.")


def check_intertwining():
    rows = []
    numerical_equalities = 0
    for j in range(1, 9):
        f, F, h = family(j)
        H0body = A(V("w"), V("v"))
        n, a = V("n"), V("a")
        lhs = repeat(pred, j, F(n, a))
        rhs = A(n, repeat(pred, j, a))
        # Check symbolic zero case using only ordinary zero equations.
        assert normalize_q_and_bases(substitute(lhs, {"n": Z})) == \
            normalize_q_and_bases(substitute(rhs, {"n": Z}))
        # Check successor computation, then one use of the stated IH.
        successor_lhs = repeat(pred, j, unfold_once(F(S(n), a)))
        successor_lhs = normalize_q_and_bases(successor_lhs)
        assert successor_lhs == S(lhs)
        after_hypothesis = replace_active(successor_lhs, lhs, rhs)
        successor_rhs = unfold_once(A(S(n), repeat(pred, j, a)))
        assert after_hypothesis == successor_rhs
        # Check specialization to the encoded initializer.
        specialized_rhs = A(V("w"), repeat(pred, j, repeat(S, j, V("v"))))
        assert normalize_q_and_bases(specialized_rhs) == H0body
        old = module(f"H{j}", h)
        image = translate_hj(old, j)
        canonical = module("H0", H0body)
        assert charge(f) == 4 * j + 2
        assert charge(h) == 8 * j + 5
        assert charge(call(f"H{j}", h, n, a)) == 8 * j + 8
        assert charge(old) == 32 * j + 35
        assert charge(image) == 8 * j + 35
        assert charge(canonical) == 35
        assert charge(Eq(lhs, rhs)) == 10 * j + 11
        assert charge(module(f"F{j}", f)) == 16 * j + 23
        assert not free_variables(old) and not free_variables(image)
        # Every active recursor counter is neither zero nor a successor;
        # this independently checks the computational obstruction.
        nodes = list(active_recursor_nodes(h))
        assert all(node.args[0].op not in ("zero", "successor") for node in nodes)
        assert all(node.name != "A" for node in nodes)
        assert all(node.args[1].op != "recursor" for node in nodes)
        seed = repeat(S, j, V("v"))
        advanced_seed = normalize_q_and_bases(substitute(f, {"v": seed}))
        assert advanced_seed == repeat(S, j + 1, V("v"))
        assert advanced_seed != seed
        assert normalize_q_and_bases(substitute(f, {"v": Z})) != Z
        assert active_occurrences(f, "v") == active_occurrences(h, "v") == 1
        for counter in range(7):
            for initial in range(9):
                env = {"n": counter, "a": initial}
                assert evaluate(lhs, env) == evaluate(rhs, env)
                numerical_equalities += 1
                env2 = {"w": counter, "v": initial}
                assert evaluate(h, env2) == evaluate(H0body, env2)
                numerical_equalities += 1
        for counter in range(5):
            for initial in range(5):
                Hj = call(f"H{j}", h, n, a)
                H0 = call("H0", H0body, n, a)
                env = {"n": counter, "a": initial}
                assert evaluate(Hj, env) == evaluate(H0, env)
                numerical_equalities += 1
        # Nonvariable actual arguments test the universal per-call saving.
        actual_counter = A(n, a)
        actual_initial = Q(A(a, n), S(a))
        contraction_lhs = repeat(pred, j, F(actual_counter, repeat(S, j, actual_initial)))
        contraction_rhs = A(actual_counter, actual_initial)
        assert charge(contraction_lhs) - charge(contraction_rhs) == 8 * j
        rows.append(dict(j=j, descriptor_f=charge(f), descriptor_h=charge(h),
                         original_module=charge(old), literal_image_module=charge(image),
                         fresh_canonical_module=charge(canonical),
                         image_saving=charge(old)-charge(image)))
    return {
        "indices_checked": "1..8", "symbolic_base_and_step_certificates": 8,
        "specialized_initializer_cancellations": 8,
        "bounded_numerical_equalities": numerical_equalities,
        "blocked_computation_zero_fixed_point_and_fusion_shape_checks": True,
        "scope": "Bounded and symbolic diagnostics; the universal induction proof is in the report.",
        "rows": rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    results = {
        "status": "PASS",
        "verification_scope": "Actual-AST counts, scope checks, finite semantics and bounded computations; not proof-assistant verification.",
        "core": check_core(),
        "scope_checks": check_scope(),
        "rooted_closure": check_rooted_closure(),
        "intertwining": check_intertwining(),
    }
    rendered = json.dumps(results, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
