#!/usr/bin/env python3
"""Finite syntax diagnostics for the U/V closure-binder tradeoff.

This checks charged AST counts and the capture/scope side condition of the
ordinary intuitionistic equivalence. It is not a formal logical proof.
"""
from __future__ import annotations
from dataclasses import dataclass
import json
from pathlib import Path

@dataclass(frozen=True)
class Node:
    op: str
    children: tuple[Node, ...] = ()
    name: str = ""
    frozen: Node | None = None

    def size(self) -> int:
        return 1 + sum(c.size() for c in self.children) + (
            0 if self.frozen is None else self.frozen.size())


def var(name):
    return Node("var", name=name)


def const(name):
    return Node("const", name=name)


def call(name, *args):
    return Node("call", tuple(args), name)


def op(name, *args):
    return Node(name, tuple(args))


def all_(name, body):
    return Node("all", (body,), name)


def rec(desc, *args):
    return Node("rec", tuple(args), frozen=desc)


def fv(t):
    if t.op == "var":
        return {t.name}
    result = set().union(*(fv(c) for c in t.children))
    if t.op == "all":
        result.discard(t.name)
    # A frozen descriptor has its own local slots. Do not traverse it.
    return result


def fresh(used, stem="y"):
    if stem not in used:
        return stem
    index = 0
    while f"{stem}{index}" in used:
        index += 1
    return f"{stem}{index}"


def subst(t, variable, term):
    if t.op == "var":
        return term if t.name == variable else t
    if t.op == "all":
        bound = t.name
        body = t.children[0]
        if bound == variable:
            return t
        if bound in fv(term):
            renamed = fresh(fv(body) | fv(term) | {variable, bound}, "z")
            body = subst(body, bound, var(renamed))
            bound = renamed
        return all_(bound, subst(body, variable, term))
    return Node(t.op, tuple(subst(c, variable, term) for c in t.children),
                t.name, t.frozen)


def occurrences(t, variable):
    if t.op == "var":
        return int(t.name == variable)
    if t.op == "all" and t.name == variable:
        return 0
    return sum(occurrences(c, variable) for c in t.children)


def close(params, formula):
    for parameter in reversed(params):
        formula = all_(parameter, formula)
    return formula


def closure_antecedent(P, h, x="x"):
    y = fresh(fv(P) | fv(h) | {x})
    hy = subst(h, x, var(y))
    return all_(y, op("imp", subst(P, x, var(y)), subst(P, x, hy)))


def expand_U(P, h, x="x"):
    return op("imp", closure_antecedent(P, h, x), all_(x, P))


def expand_V(P, h, x="x"):
    # The probe x remains free only in the unaltered final P.
    return op("imp", closure_antecedent(P, h, x), P)


def move_forall(t):
    """The single logical equivalence, used only with its required guard."""
    assert t.op == "all"
    x = t.name
    body = t.children[0]
    assert body.op == "imp"
    antecedent, consequent = body.children
    assert x not in fv(antecedent)
    return op("imp", antecedent, all_(x, consequent))


def main():
    x, y, zero = var("x"), var("y"), const("0")
    Px, hx = call("P", x), call("h", x)
    Py, hy = call("P", y), call("h", y)
    U_lhs = op("U", Px, hx)
    V_lhs = op("V", Px, hx)
    U_rhs = op("imp", all_("y", op("imp", Py, call("P", hy))),
               all_("x", Px))
    V_rhs = op("imp", all_("y", op("imp", Py, call("P", hy))), Px)
    U_record = U_lhs.size() + U_rhs.size() + 1
    V_record = V_lhs.size() + V_rhs.size() + 1
    assert (U_lhs.size(), U_rhs.size(), U_record) == (5, 11, 17)
    assert (V_lhs.size(), V_rhs.size(), V_record) == (5, 10, 16)

    sx = call("S", x)
    checked = 0
    for p in range(4):
        params = [f"c{i}" for i in range(p)]
        choices = [x, zero, sx, call("S", sx), rec(var("w"), x, zero)]
        # Deliberately reuse the name x in a FROZEN local descriptor.
        choices += [rec(var("x"), x, x)]
        choices += [var(c) for c in params]
        for left in choices:
            for right in choices:
                E = op("eq", left, right)
                P = op("or", op("eq", x, zero), E)
                F, k = E.size(), occurrences(E, "x")
                U = close(params, op("U", P, sx))
                V = close(params, all_("x", op("V", P, sx)))
                U_expanded = close(params, expand_U(P, sx))
                V_expanded = close(params, all_("x", expand_V(P, sx)))
                assert U.size() == F + p + 7
                assert V.size() == F + p + 8
                assert U_expanded.size() == 3 * F + k + p + 17
                assert V_expanded.size() == U_expanded.size()
                assert move_forall(all_("x", expand_V(P, sx))) == expand_U(P, sx)
                assert "x" not in fv(closure_antecedent(P, sx))
                checked += 1

    # Generic binding, beyond the equation-only axiom indexing: avoid
    # capturing h's parameter z under a quantifier internal to P.
    P = all_("z", op("eq", x, var("z")))
    h = call("f", x, var("z"))
    assert fv(expand_V(P, h)) == {"x", "z"}
    assert fv(expand_U(P, h)) == {"z"}
    assert move_forall(all_("x", expand_V(P, h))) == expand_U(P, h)
    captured = subst(P, "x", h)
    assert captured.name != "z" and "z" in fv(captured)

    # Guard rejection: forall x(A(x)->P(x)) cannot move x past A(x).
    try:
        move_forall(all_("x", op("imp", call("A", x), Px)))
    except AssertionError:
        guard_rejected = True
    else:
        guard_rejected = False
    assert guard_rejected

    Qx = rec(var("w"), x, zero)
    E_cov = op("eq", call("S", Qx), x)
    chi = op("or", op("eq", x, zero), E_cov)
    U_cov = op("U", chi, sx).size()
    V_cov = all_("x", op("V", chi, sx)).size()
    assert (E_cov.size(), chi.size(), U_cov, V_cov) == (7, 11, 14, 15)
    assert 6 + U_record + 16 + U_cov == 53
    assert 6 + V_record + 16 + V_cov == 53
    for N in range(21):
        # Matching separately closed instances; common modules cancel.
        V_total = 6 + V_record + N * V_cov
        U_total = 6 + U_record + N * U_cov
        assert V_total - U_total == N - 1

    result = {
        "status": "passed",
        "schema_cases": checked,
        "definition_records": {"U": U_record, "V": V_record},
        "fixed_records": {"U": 6 + U_record, "V": 6 + V_record},
        "coverage_instance_sizes": {"U": U_cov, "V": V_cov},
        "constructor_packets": {"U": 53, "V": 53},
        "scope_capture_check": "passed",
        "dependent_antecedent_negative_control": "rejected",
        "packet_difference": "V-U=N-1 for matching separately closed instances",
        "scope": "Finite AST diagnostics, not a proof-assistant formalization."
    }
    destination = Path(__file__).with_name("v_verification.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
