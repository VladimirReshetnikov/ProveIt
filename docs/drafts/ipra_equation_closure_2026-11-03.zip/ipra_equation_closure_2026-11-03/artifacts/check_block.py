#!/usr/bin/env python3
"""Finite independent AST diagnostics for the block-cancellation family.

This does not formally prove the universal equivalence theorem. It implements
the active/frozen scope distinction, tests the published rules that could affect
the explicit family, verifies charged sizes, and checks numerical samples.
Only the native-p and generated-Q direct interfaces are executable here.
"""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple[Term, ...] = ()
    body: Term | None = None


def var(name):
    return Term(name)


Z = Term("0")
V, W = var("v"), var("w")


def succ(t, count=1):
    for _ in range(count):
        t = Term("S", (t,))
    return t


def rec(body, counter, initial):
    return Term("R", (counter, initial), body)


def pred(t, overhead):
    if overhead == 1:
        return Term("p", (t,))
    assert overhead == 3
    return rec(W, t, Z)


def pred_iter(t, count, overhead):
    for _ in range(count):
        t = pred(t, overhead)
    return t


def size(t):
    return 1 + sum(map(size, t.args)) + (size(t.body) if t.body else 0)


def active_vars(t):
    if not t.args and t.op != "0":
        return {t.op}
    return set().union(*(active_vars(a) for a in t.args))


def subst(t, values):
    """Only active arguments are traversed; stored descriptor stays frozen."""
    if t.op in values and not t.args:
        return values[t.op]
    return Term(t.op, tuple(subst(a, values) for a in t.args), t.body)


def numeral_value(t):
    value = 0
    while t.op == "S":
        value += 1
        t = t.args[0]
    return value if t == Z else None


def evaluate(t, env):
    if t == Z:
        return 0
    if t.op == "S":
        return evaluate(t.args[0], env) + 1
    if t.op == "p":
        return max(evaluate(t.args[0], env) - 1, 0)
    if t.op == "R":
        counter = evaluate(t.args[0], env)
        state = evaluate(t.args[1], env)
        for index in range(counter):
            state = evaluate(t.body, {"v": state, "w": index})
        return state
    return env[t.op]


def unwrap_pred(t, overhead):
    if overhead == 1 and t.op == "p":
        return t.args[0]
    if overhead == 3 and t.op == "R" and t.body == W and t.args[1] == Z:
        return t.args[0]
    return None


def active_positions(t):
    yield t
    for a in t.args:
        yield from active_positions(a)


def ordinary_module(body):
    a, n = var("a"), var("n")
    base = Term("=", (rec(body, Z, a), a))
    step = Term("=", (rec(body, succ(n), a),
                      subst(body, {"v": rec(body, n, a), "w": n})))
    return Term("forall a", (Term("and", (base, Term("forall n", (step,)))),))


def erase_identity(t, erased_body):
    arguments = tuple(erase_identity(a, erased_body) for a in t.args)
    if t.op == "R" and t.body == erased_body:
        return arguments[1]
    return Term(t.op, arguments, t.body)


def old_root_candidates(t, overhead):
    """Candidate raw endpoints from the old displayed rule lists.

    The zero/absorbing checks below are exact for the only two stored bodies
    occurring actively in this family: w and S^r(v). Their seed tests have no
    recursors, hence cannot acquire a hidden normalizing step.
    """
    if t.op == "p":
        if t.args[0] == Z:
            yield "native-p-zero", Z
        if t.args[0].op == "S":
            yield "native-p-successor", t.args[0].args[0]
    if t.op == "R":
        n, a = t.args
        if n == Z:
            yield "recursion-zero", a
        if n.op == "S":
            prev = n.args[0]
            yield "recursion-step", subst(t.body, {"v": rec(t.body, prev, a), "w": prev})
        k = numeral_value(n)
        if k is not None:
            endpoint = a
            for j in range(k):
                endpoint = subst(t.body, {"v": endpoint, "w": succ(Z, j)})
            yield "finite-numeral", endpoint
        if t.body == succ(V) and a == Z:
            yield "addition-zero", n
        if t.body == W:
            seed = var("fresh_u")
            assert seed != a
            assert subst(t.body, {"v": Z}) != Z
        else:
            # All family G_r bodies are literal successor chains over v.
            tail = t.body
            while tail.op == "S":
                tail = tail.args[0]
            assert tail == V
            assert subst(t.body, {"v": Z}) != Z
            assert subst(t.body, {"v": a, "w": var("fresh_u")}) != a
        if "w" not in active_vars(t.body) and a.op == "R" and a.body == t.body:
            m, initial = a.args
            yield "autonomous-fusion", rec(t.body, rec(succ(V), n, m), initial)
    inner = unwrap_pred(t, overhead)
    if inner is not None and inner.op == "R" and inner.args[0].op == "S":
        n, a = inner.args
        prev = n.args[0]
        if inner.body.op == "S":
            yield "one-D-contextual", subst(
                inner.body.args[0], {"v": rec(inner.body, prev, a), "w": prev}
            )
        if inner.body == succ(V):
            yield "addition-cancellation", rec(inner.body, prev, a)


def test_family(r, k, overhead):
    g = succ(V, r)
    center = rec(g, succ(Z, k), V)
    h = pred_iter(center, r * k, overhead)
    expected = overhead * r * k + r + k + 4
    assert size(h) == expected
    assert active_vars(h) == {"v"}
    outer = rec(h, var("n"), var("a"))
    assert size(outer) == expected + 3
    module = ordinary_module(h)
    module_image = erase_identity(module, h)
    assert size(module) == 4 * expected + 15
    assert size(module_image) == expected + 8
    assert size(module) - size(module_image) == 3 * expected + 7

    candidates = []
    for node in active_positions(h):
        for name, endpoint in old_root_candidates(node, overhead):
            change = size(endpoint) - size(node)
            candidates.append((name, change))
            assert change >= 0, (r, k, overhead, name, change)
    assert Counter(name for name, _ in candidates) == {
        "recursion-step": 1,
        "finite-numeral": 1,
        "one-D-contextual": 1,
    }
    changes = dict(candidates)
    assert changes["recursion-step"] == r - 1
    assert changes["finite-numeral"] == (r - 1) * (k - 1) - 4
    assert changes["one-D-contextual"] == r - overhead - 2

    # Inspecting a descriptor never makes its formal v,w active in a call.
    assert active_vars(outer) == {"n", "a"}
    assert subst(outer, {"v": Z, "w": Z}) == outer

    # Each new block endpoint is built independently, then counted.
    current = h
    for remaining in range(k, 0, -1):
        endpoint = pred_iter(
            rec(g, succ(Z, remaining - 1), V), r * (remaining - 1), overhead
        )
        assert size(current) - size(endpoint) == overhead * r + 1
        current = endpoint
    assert current == rec(g, Z, V)
    assert size(current) - size(V) == r + 3

    arbitrary_terms = (V, succ(Z, 3), rec(W, var("n"), succ(V)))
    for n in arbitrary_terms:
        for a in arbitrary_terms:
            left = pred_iter(rec(g, succ(n), a), r, overhead)
            right = rec(g, n, a)
            assert size(left) - size(right) == overhead * r + 1

    # General recursion evaluation (no built-in closed form for G or h).
    semantic_checks = 0
    for value in range(5):
        for counter in range(3):
            assert evaluate(h, {"v": value, "w": counter}) == value
            assert evaluate(outer, {"a": value, "n": counter}) == value
            semantic_checks += 2

    return {
        "r": r, "k": k, "predecessor_overhead": overhead,
        "body_size": expected, "outer_variable_call_size": expected + 3,
        "ordinary_module_size": size(module),
        "ordinary_image_module_size": size(module_image),
        "old_endpoint_changes": changes, "accepted_old_rules": 0,
        "block_step_saving": overhead * r + 1,
        "final_body_size": 1, "semantic_checks": semantic_checks,
    }


def main():
    cases = [test_family(r, k, d) for d in (1, 3)
             for r in range(6, 13) for k in range(2, 6)]
    result = {
        "status": "passed",
        "scope": "Finite AST and bounded semantic diagnostics; not a formal metatheorem proof.",
        "cases": len(cases),
        "semantic_checks": sum(c["semantic_checks"] for c in cases),
        "frozen_descriptor_checks": 2 * len(cases),
        "representatives": [cases[0], cases[len(cases)//2]],
        "all_cases": cases,
    }
    destination = Path(__file__).with_name("block_verification.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "all_cases"}, indent=2))


if __name__ == "__main__":
    main()
