#!/usr/bin/env python3
"""Exact certificate for the degree-four, girth-78 maximal-independent-set bound.

Python 3.10+, standard library only. Run without -O.

Full reproduction:
    python3 certify_high_girth.py --check certificate.json
Generate a fresh certificate:
    python3 certify_high_girth.py --write certificate.json
Check the final quartic inequalities alone (does not verify propagation):
    python3 certify_high_girth.py --root-only certificate.json

The message-cone construction and the primitive/determinant/hull routines are
adapted from Cinna Davis and GPT-6.2 Astra, solved-conjectures,
results/frankl-generator-families/tree_messages.py (MIT license).
The degree-four certificate and the bounded-complexity outward enclosure are
new calculations in this report. See THIRD_PARTY_LICENSE.txt and README.md.

Every proof decision uses integers or fractions. Decimal is used only to print.
"""
from argparse import ArgumentParser
from decimal import Decimal, localcontext
from fractions import Fraction
from math import gcd, lcm
from pathlib import Path
import json
import time

if not __debug__:
    raise RuntimeError('Assertions are proof checks; run without Python -O.')

GRID = 10**9
NORMAL_RADIUS = 8
LEVELS = 37
ROOT_DEGREE = 4
BRANCH_CHILDREN = 3
BOUNDARY_RADIUS = LEVELS + 1
GIRTH = 2 * BOUNDARY_RADIUS + 2
TARGET = Fraction(249, 500)
EXPECTED_FINAL = Fraction(
    565043654892030374858741761024000,
    1134957096210054809779668025493977,
)
AXES = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
NORMALS = tuple((u, v) for u in range(-NORMAL_RADIUS, NORMAL_RADIUS + 1)
                for v in range(-NORMAL_RADIUS, NORMAL_RADIUS + 1)
                if gcd(u, v) == 1)


def primitive(ray):
    assert all(isinstance(z, int) and z >= 0 for z in ray)
    divisor = gcd(*ray)
    return tuple(z // divisor for z in ray) if divisor else None


def determinant(p, q, r):
    a, b, c = p
    u, v, w = q
    x, y, z = r
    return a * (v*z - w*y) + b * (w*x - u*z) + c * (u*y - v*x)


def hull(rays):
    """Positive cone, via the convex hull of rays normalized to coordinate sum 1.

    All input points are checked against every returned oriented polygon edge.
    Thus each call explicitly verifies the containment needed by propagation.
    """
    unique = {p for ray in rays if (p := primitive(ray)) is not None}
    ordered = sorted(unique, key=lambda v: (Fraction(v[0], sum(v)),
                                            Fraction(v[1], sum(v))))
    if len(ordered) < 3:
        return tuple(ordered)

    def chain(items):
        result = []
        for p in items:
            while len(result) >= 2 and determinant(result[-2], result[-1], p) <= 0:
                result.pop()
            result.append(p)
        return result

    polygon = tuple(chain(ordered)[:-1] + chain(reversed(ordered))[:-1])
    if len(polygon) == 2:
        assert all(determinant(*polygon, p) == 0 for p in ordered)
        # The endpoints are also the first and last points in normalized order.
        assert set(polygon) == {ordered[0], ordered[-1]}
    else:
        assert len(polygon) >= 3
        assert all(determinant(polygon[i-1], polygon[i], p) >= 0
                   for i in range(len(polygon)) for p in ordered)
    return polygon


def ceil_ratio(numerator, denominator):
    assert denominator > 0
    return -((-numerator) // denominator)


def outward_enclosure(rays):
    """Intersect rational support half-planes in the normalized simplex.

    For each fixed integer normal (u,v), C is the upward rounding of the
    largest GRID*(u*a+v*b)/(a+b+c). The normalized rays satisfy
    u*x+v*y <= C/GRID. Exact clipping returns an outer polygon. Independent
    determinant checks below also verify containment of every input ray.
    """
    rays = tuple(rays)
    assert rays and all(sum(p) > 0 and min(p) >= 0 for p in rays)
    polygon = [(Fraction(1), Fraction(0)),
               (Fraction(0), Fraction(1)),
               (Fraction(0), Fraction(0))]
    for u, v in NORMALS:
        cap = max(ceil_ratio(GRID * (u*a + v*b), a+b+c) for a, b, c in rays)
        intercept = Fraction(cap, GRID)

        def signed_distance(point):
            return u * point[0] + v * point[1] - intercept

        clipped = []
        for p, q in zip(polygon, polygon[1:] + polygon[:1]):
            ep, eq = signed_distance(p), signed_distance(q)
            if ep <= 0:
                clipped.append(p)
            if (ep < 0 < eq) or (eq < 0 < ep):
                clipped.append(tuple((eq*x - ep*y)/(eq-ep) for x, y in zip(p, q)))
        polygon = clipped
        assert polygon

    integer_rays = []
    for a, b in polygon:
        c = 1-a-b
        assert min(a, b, c) >= 0
        denominator = lcm(a.denominator, b.denominator, c.denominator)
        integer_rays.append(tuple(int(z*denominator) for z in (a, b, c)))
    result = hull(integer_rays)
    assert len(result) >= 3
    assert all(determinant(result[i-1], result[i], p) >= 0
               for i in range(len(result)) for p in rays)
    return result


def propagate(incoming):
    """Contain every three-child message with children in cone(incoming)."""
    factors = tuple((b+c, a+b, b) for a, b, c in incoming)
    products = ((1, 1, 1),)
    for _ in range(BRANCH_CHILDREN):
        products = hull((u*i, v*j, w*k)
                        for u, v, w in products for i, j, k in factors)
    assert all(v >= w for u, v, w in products)
    messages = tuple((u, v-w, w) for u, v, w in products)
    return outward_enclosure(messages)


def root_bound(cone):
    ratios = []
    for a, b, c in cone:
        numerator = (b+c)**ROOT_DEGREE
        denominator = numerator + (a+b)**ROOT_DEGREE - b**ROOT_DEGREE
        assert denominator > 0
        ratios.append(Fraction(numerator, denominator))
    return max(ratios)


def decimal(value):
    with localcontext() as context:
        context.prec = 24
        return str(Decimal(value.numerator) / Decimal(value.denominator))


def record(level, cone):
    bound = root_bound(cone)
    return {
        'level': level,
        'rays': [list(p) for p in cone],
        'ray_count': len(cone),
        'root_upper_numerator': bound.numerator,
        'root_upper_denominator': bound.denominator,
        'root_upper_decimal_display_only': decimal(bound),
    }


def verify_root(cone):
    bound = root_bound(cone)
    assert bound == EXPECTED_FINAL
    assert bound < TARGET
    # Equivalent quartic inequalities, checked independently of ratio division.
    s, t = TARGET.numerator, TARGET.denominator
    assert all((t-s)*(b+c)**ROOT_DEGREE + s*b**ROOT_DEGREE
               < s*(a+b)**ROOT_DEGREE for a, b, c in cone)
    return bound


def reproduce():
    cone = AXES
    levels = [record(0, cone)]
    for level in range(1, LEVELS+1):
        started = time.monotonic()
        cone = propagate(cone)
        item = record(level, cone)
        levels.append(item)
        print(f"level {level:2}: {len(cone):3} rays; root upper "
              f"{item['root_upper_decimal_display_only']}; "
              f"{time.monotonic()-started:.2f} s", flush=True)
    bound = verify_root(cone)
    result = {
        'schema': 'rank-four-mis-cone-certificate-v1',
        'arithmetic': 'exact Python integers and fractions; decimals only for display',
        'grid': GRID,
        'normal_radius': NORMAL_RADIUS,
        'normal_count': len(NORMALS),
        'normals': [list(p) for p in NORMALS],
        'branch_children': BRANCH_CHILDREN,
        'root_degree': ROOT_DEGREE,
        'levels': LEVELS,
        'boundary_radius': BOUNDARY_RADIUS,
        'sufficient_girth': GIRTH,
        'target_absence': {'numerator': 249, 'denominator': 500},
        'strict_frequency_lower': {'numerator': 251, 'denominator': 500},
        'final_root_upper': {'numerator': bound.numerator, 'denominator': bound.denominator},
        'cones': levels,
    }
    print('PROVED: root occupancy < 249/500; union frequency > 251/500.', flush=True)
    return result


def main():
    parser = ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--write', type=Path)
    mode.add_argument('--check', type=Path)
    mode.add_argument('--root-only', type=Path)
    args = parser.parse_args()
    if args.root_only:
        data = json.loads(args.root_only.read_text())
        assert data['levels'] == LEVELS and data['sufficient_girth'] == GIRTH
        cone = tuple(tuple(p) for p in data['cones'][-1]['rays'])
        bound = verify_root(cone)
        print('Final quartic inequalities verified; propagation was not checked in this mode.')
        print(f'Root bound: {bound} < 249/500.')
        return
    computed = reproduce()
    if args.check:
        expected = json.loads(args.check.read_text())
        assert computed == expected, 'Certificate differs from exact reproduction.'
        print('All recorded cone transitions and final bounds reproduced exactly.')
    else:
        args.write.write_text(json.dumps(computed, indent=2) + '\n')
        print(f'Wrote {args.write}.')


if __name__ == '__main__':
    main()
