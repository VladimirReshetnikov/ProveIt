#!/usr/bin/env python3
"""Independent exact audit of the saved message-cone certificate.

This does not reproduce all 37 transitions. It checks all saved polygons and
root fractions, and directly checks every extreme-ray triple in the first,
second, and last transitions. The last check uses no hull or clipping code
from the certificate generator. Full propagation is certified by the separate
certify_high_girth.py --check command.
"""
from fractions import Fraction
from itertools import combinations_with_replacement
from math import gcd
from pathlib import Path
import json


def det(p, q, r):
    return (p[0]*q[1]*r[2] + p[1]*q[2]*r[0] + p[2]*q[0]*r[1]
            - p[2]*q[1]*r[0] - p[1]*q[0]*r[2] - p[0]*q[2]*r[1])


def in_convex_polygon(polygon, point):
    """Projective-normalized triangle-fan membership, using only determinants."""
    first = polygon[0]
    if det(first, polygon[1], point) < 0:
        return False
    if det(first, polygon[-1], point) > 0:
        return False
    lo, hi = 1, len(polygon)-1
    while lo+1 < hi:
        mid = (lo+hi)//2
        if det(first, polygon[mid], point) >= 0:
            lo = mid
        else:
            hi = mid
    return det(polygon[lo], polygon[hi], point) >= 0


def main():
    if not __debug__:
        raise RuntimeError('Run with assertions enabled.')
    directory = Path(__file__).resolve().parent
    data = json.loads((directory/'certificate.json').read_text())
    assert data['levels'] == 37 and data['branch_children'] == 3
    assert data['root_degree'] == 4 and data['sufficient_girth'] == 78
    assert len(data['cones']) == 38
    cones = []
    for level, item in enumerate(data['cones']):
        assert item['level'] == level
        polygon = tuple(tuple(p) for p in item['rays'])
        assert len(polygon) == item['ray_count']
        assert len(polygon) >= 3 and len(set(polygon)) == len(polygon)
        for p in polygon:
            assert len(p) == 3 and all(type(x) is int and x >= 0 for x in p)
            assert sum(p) > 0 and gcd(*p) == 1
        # These tests verify convexity, orientation, and the membership helper
        # on all vertices and on positive combinations of every vertex pair.
        for p in polygon:
            assert all(det(polygon[i-1], polygon[i], p) >= 0
                       for i in range(len(polygon)))
            assert in_convex_polygon(polygon, p)
        for p, q in combinations_with_replacement(polygon, 2):
            midpoint_ray = tuple(x+y for x,y in zip(p,q))
            assert in_convex_polygon(polygon, midpoint_ray)
        ratios = [Fraction((b+c)**4, (b+c)**4+(a+b)**4-b**4)
                  for a,b,c in polygon]
        assert max(ratios) == Fraction(item['root_upper_numerator'],
                                      item['root_upper_denominator'])
        cones.append(polygon)

    selected = []
    for level in (1, 2, 37):
        incoming, outgoing = cones[level-1], cones[level]
        triples, nonzero = 0, 0
        for p, q, r in combinations_with_replacement(incoming, 3):
            triples += 1
            occupied = (p[1]+p[2])*(q[1]+q[2])*(r[1]+r[2])
            pending = p[1]*q[1]*r[1]
            dominated = ((p[0]+p[1])*(q[0]+q[1])*(r[0]+r[1])
                         - pending)
            message = (occupied, dominated, pending)
            assert min(message) >= 0
            if sum(message):
                nonzero += 1
                assert in_convex_polygon(outgoing, message), (level, p, q, r)
        selected.append({'level': level, 'symmetric_extreme_triples': triples,
                         'nonzero_images': nonzero, 'all_contained': True})
        print(f'Independent direct transition {level}: {triples} triples checked.',
              flush=True)

    final = cones[-1]
    assert all(251*(b+c)**4 + 249*b**4 < 249*(a+b)**4 for a,b,c in final)
    exact = max(Fraction((b+c)**4, (b+c)**4+(a+b)**4-b**4) for a,b,c in final)
    assert exact == Fraction(565043654892030374858741761024000,
                            1134957096210054809779668025493977)
    assert exact < Fraction(249,500)
    result = {
        'scope': 'all polygon and root-fraction records; direct first, second, and last transitions',
        'not_a_full_propagation_replay': True,
        'arithmetic': 'exact integers and fractions only',
        'polygons_checked': len(cones),
        'selected_transitions': selected,
        'final_strict_quartic_inequalities_checked': len(final),
        'final_numerator': exact.numerator,
        'final_denominator': exact.denominator,
        'strictly_below_249_over_500': True,
    }
    (directory/'independent_audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print('Independent selected-transition audit passed.')


if __name__ == '__main__':
    main()
