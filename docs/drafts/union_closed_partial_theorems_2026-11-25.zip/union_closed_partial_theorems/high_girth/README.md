# A degree-four half-frequency theorem

## Result

Let each generator have exactly four points and let each point lie in exactly
four generators. If the bipartite incidence graph has girth at least 78, then
**every point belongs to more than 251/500 = 50.2% of the distinct unions**,
including the empty union. In the same uniform distribution, every generator
is contained in fewer than 249/500 = 49.8% of the unions.

The underlying graph theorem applies more generally to every finite simple
4-regular graph of girth at least 78: a uniformly chosen maximal independent
set occupies any specified vertex with probability at most

    565043654892030374858741761024000 /
    1134957096210054809779668025493977

which is approximately 0.49785463854 and is strictly below 249/500.
The bound remains true after fixing the occupied vertices at distance at
least 38 in any feasible way.

## What is proved and what is new here

The maximal-independent-set correspondence is standard. The three-state
recurrence, positive-cone propagation, and Hölder/Minkowski root bound follow
the approach of Cinna Davis and GPT-6.2 Astra, whose publicly available note
proves a point-degree-three theorem under girth 16. Their note and program
are unrefereed, and their numerical theorem is not assumed in our proof.

This calculation adds rational outer polygon enclosures of bounded
complexity, carries the recursion to depth 37 in degree four, and certifies
the new finite statement above. No degree-four pointwise theorem with these
hypotheses was found in the supplied ProveIt drafts or the primary literature
checked. This is a bounded priority review, not an exhaustive novelty claim.

The verifier contains small routines adapted from the MIT-licensed upstream
program. Its license and source attribution are in THIRD_PARTY_LICENSE.txt.
Upstream source revision inspected:
1c248e471f0ec5801c34c06fbfe60e8da470268a.

## Files

- `section.tex`: complete human-readable proof, including the finite-certificate
  specification and the passage from ray bounds to arbitrary unequal children.
- `certify_high_girth.py`: standalone exact arithmetic reproduction and checker.
- `certificate.json`: all 38 cone lists, including the level-zero coordinate
  axes and the 37 propagated outer cones; exact maxima and parameters.
- `reproduction.log`: output of the full exact calculation.
- `audit_selected_transitions.py` and `independent_audit.json`: an independent
  checker and its results. It checks all recorded polygons and root ratios,
  and directly enumerates all symmetric ray triples for transitions 1, 2,
  and 37 (295,240 triples at the last transition). It does not independently
  replay every intermediate transition.
- `bibliography_items.tex`: source entries for inclusion in the report.
- `THIRD_PARTY_LICENSE.txt`: upstream MIT license and attribution.

## Reproduction

From this directory, with Python 3.10 or later and no third-party packages:

    python3 certify_high_girth.py --check certificate.json

The full calculation takes several minutes. Every geometric proof decision
uses integer determinants or Python Fraction arithmetic. The fixed 176
support directions are integer pairs. Decimal values appear only as display
text, never in a proof assertion.

To create the certificate afresh:

    python3 certify_high_girth.py --write certificate.json

For a fast check of only the final ray inequalities:

    python3 certify_high_girth.py --root-only certificate.json

The last command does not check cone propagation and is not a replacement for
the complete reproduction. Do not run Python with `-O`; assertions are part of
the verifier. This is a computer-assisted proof with a transparent exact
certificate. It has not been formalized in Lean.

The additional independent audit is reproduced by:

    python3 audit_selected_transitions.py

It reads `certificate.json` beside the script and writes
`independent_audit.json` there. Its limited transition scope is stated
explicitly in the audit report.

## Boundaries and limitations

For a root, girth 78 makes its radius-38 ball a tree. After all occupation
states at distance at least 38 are fixed, every boundary vertex has one of
three forced states. The degree-four graph gives three children at every
nonroot interior vertex. Thus 37 cone steps reach the four neighbors of the
root. The certificate handles every feasible exterior, not only random or
symmetric boundary conditions.

The result does not remove the girth or regularity assumptions, prove the
full union-closed sets conjecture, or optimize the girth threshold.
