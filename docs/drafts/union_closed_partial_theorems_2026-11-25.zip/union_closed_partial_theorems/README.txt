TWO QUANTITATIVE RESULTS FOR UNION-CLOSED FAMILIES
Prepared for Vladimir Reshetnikov, 25 November 2026

START HERE
==========
paper.pdf is the complete manuscript. Its editable source is paper.tex,
which includes high_girth/section.tex and the supplied figure.

The general union-closed sets conjecture is NOT proved. The package gives
two proposed new partial results, with their hypotheses and antecedents
explicit. A targeted literature review did not locate these statements;
absolute historical priority is not certified.

MAIN RESULT: A HALF-FREQUENCY THEOREM
===================================
Let every generator contain four points, every point belong to four
generators, and the bipartite incidence graph have no cycle shorter than
78. Then every point belongs to at least

  1 - 565043654892030374858741761024000
        / 1134957096210054809779668025493977

of the DISTINCT generated unions, including the empty union. This is
0.5021453614600303... and exceeds 251/500 = 50.2%.

The underlying theorem bounds the probability that any specified vertex
belongs to a uniform maximal independent set in ANY finite simple
4-regular graph of girth at least 78. The proof handles every feasible
exterior configuration. The manuscript also proves that finite connected
bipartite graphs satisfying the hypotheses exist at arbitrarily large
orders.

SECOND RESULT: SHARP FIRST-ORDER FREQUENCY DEFICITS
================================================
Suppose every generator has d points, every point lies in r generators,
and two generators intersect in at most one point. For fixed r>=3, a
point's frequency has a uniform first-order expansion about 1-2^(-r),
with a coefficient determined by its local incidence geometry and an
exponentially smaller error. There is no bound on the number of generators.

For r=3 the normalized deficit

  (7/8 - f_x) / [d*(3/4)^d]

has sharp asymptotic endpoints 19/216 and 1/8. Explicit affine Steiner
systems and modular progression systems attain them. An inverse theorem
identifies the geometry of sequences approaching either endpoint.
For every d>=200 the normalized deficit lies strictly between
879/10000 and 627/5000. This last assertion has a fully rational finite
certificate and an analytic monotonicity proof.

WHAT IS NEW AND WHAT IS INHERITED
===============================
The graph/MIS correspondence, three-state recursion, positive-cone method,
and root Holder argument are prior ingredients. The degree-four enclosure
crossing one half is the proposed addition to the located degree-three
work of Cinna Davis and GPT-6.2 Astra. Its MIT notice is preserved.

The ProveIt drafts already establish the zeroth-order limit 1-2^(-r),
an O(d*a^d) error, joint laws and concentration. The new coefficient,
smaller error, sharp range, inverse statement, and finite bounds are
identified separately. The original primal one-point asymptotic is also
credited. Full details are in the manuscript and PROOF_AND_NOVELTY_NOTES.txt.

REPRODUCE
=========
Use Python 3.10 or newer with its standard library. Do not use python -O:
assertions implement exact checks. No network, optimization solver,
proprietary library, or downloaded data is needed.

  make verify

This runs the full 37-step high-girth certificate replay, its separate
selected-transition audit, the rational frequency-bound certificates,
and the independent finite-model checks. The full cone replay takes
several minutes. Individual commands are:

  python3 high_girth/certify_high_girth.py --check high_girth/certificate.json
  python3 high_girth/audit_selected_transitions.py
  python3 code/certify_bounds.py
  python3 code/check_finite_models.py

The high-girth --root-only option checks only the final quartic inequalities,
NOT all propagation steps. It is useful for inspecting the endpoint, but
is not a substitute for the full replay above.

To rebuild the PDF with a normal TeX Live/MiKTeX installation:

  make pdf

or run pdflatex paper.tex at least twice. Standard AMS, Latin Modern,
geometry, hyperref, microtype, booktabs and fancyhdr packages are used.
No BibTeX run is required. The PDF figure is already supplied.

To recreate the optional figure, install matplotlib and run:

  make figures

The figure is an illustration of proved envelopes, not a simulation.

VERIFICATION SCOPE
==================
The full cone generator checks all 37 stages using exact integers and
fractions. The saved certificate includes all 38 cones (including the
initial cone) and all exact endpoint ratios. The independent audit imports
none of the generator's code: it checks all saved polygons and ratios,
all 113 final strict quartic inequalities, and transitions 1, 2 and 37.
At the last transition it directly checks all 295,240 unordered triples
of extreme rays. Its selected scope is intentional and explicit.

The other independent checker makes 170,079 exact comparisons on six
fully enumerated models (74,944 product subsets) and nine further
structural models. These finite models validate identities and examples;
they do not establish the infinite asymptotic theorem. The manuscript
supplies that proof. Rational constants are certified separately.

No proof-assistant formalization or external peer review is claimed.

CONTENTS
========
paper.tex, paper.pdf                Complete manuscript
high_girth/section.tex              Computer-assisted half-frequency proof
high_girth/certificate.json         All cone lists and exact rational bounds
high_girth/certify_high_girth.py     Complete exact certificate replay
high_girth/reproduction.log         Successful generating replay
high_girth/audit_selected_transitions.py
high_girth/independent_audit.json    Separate audit and actual results
high_girth/THIRD_PARTY_LICENSE.txt   MIT notice for the adapted upstream method
code/certify_bounds.py              Exact finite-error and all-d>=200 checks
data/finite_bound_certificates.json Outward decimal intervals and certificates
code/check_finite_models.py         Independent combinatorial enumerations
data/finite_models.json             Exact counts, frequencies, and geometry
code/make_figure.py                 Optional figure regeneration
figures/                           Figure in PDF and PNG formats
SOURCE_PROVENANCE.json              Source commit and archive digests
PROOF_AND_NOVELTY_NOTES.txt          Scope, proof dependencies, review ledger
MANIFEST.sha256                     Digests of the delivered files

Run sha256sum -c MANIFEST.sha256 from this directory to check the delivered
bytes. Verification programs may rewrite their own reports; regenerating
a report can therefore change its recorded hash even when all checks pass.
