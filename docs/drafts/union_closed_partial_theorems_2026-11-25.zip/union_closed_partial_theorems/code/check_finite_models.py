#!/usr/bin/env python3
"""Independent, exact finite checks for the frequency-asymptotics manuscript.

This program uses only the Python standard library.  Its finite enumerations
validate identities and examples used in the proof; they do not prove an
asymptotic statement or certify that a result is new.

For a linear, r-uniform, d-regular hypergraph H=(V,E), the original generators
are G_v={e in E: v in e}.  We enumerate distinct unions of the G_v, independently
enumerate unions of the edges of H, and compare both with vertex subsets having
no selected isolated vertex.  All probabilities and comparisons are rational.

Run from any directory:
    python3 check_finite_models.py
    python3 check_finite_models.py --output /path/to/finite_models.json
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations, product
import json
from pathlib import Path
import platform
import sys
import time


@dataclass(frozen=True)
class Hypergraph:
    name: str
    n: int
    r: int
    d: int
    edges: tuple[tuple[int, ...], ...]


class CheckLog:
    """Count comparisons and retain bounded diagnostic output on failure."""

    def __init__(self) -> None:
        self.counts: Counter[str] = Counter()
        self.failure_count = 0
        self.failures: list[str] = []

    def require(self, condition: bool, category: str, description: str) -> None:
        self.counts[category] += 1
        if not condition:
            self.failure_count += 1
            if len(self.failures) < 100:
                self.failures.append(description)


def rational(value: Fraction | int) -> str:
    value = Fraction(value)
    return str(value.numerator) if value.denominator == 1 else str(value)


def bits(mask: int):
    while mask:
        low = mask & -mask
        yield low.bit_length() - 1
        mask ^= low


def edge_mask(edge: tuple[int, ...]) -> int:
    return sum(1 << v for v in edge)


def incidence(h: Hypergraph) -> list[list[int]]:
    result: list[list[int]] = [[] for _ in range(h.n)]
    for i, edge in enumerate(h.edges):
        for v in edge:
            result[v].append(i)
    return result


def validate(h: Hypergraph, checks: CheckLog) -> list[list[int]]:
    prefix = h.name + ": "
    checks.require(len(set(h.edges)) == len(h.edges), "distinct_edges", prefix + "duplicate edge")
    checks.require(all(len(e) == h.r and len(set(e)) == h.r for e in h.edges),
                   "uniformity", prefix + "wrong edge size")
    checks.require(all(0 <= v < h.n for e in h.edges for v in e),
                   "vertex_labels", prefix + "invalid vertex")
    inc = incidence(h)
    checks.require(all(len(x) == h.d for x in inc), "regularity", prefix + "wrong degree")
    checks.require(h.n * h.d == len(h.edges) * h.r,
                   "incidence_count", prefix + "incidence identity")
    used_pairs: set[tuple[int, int]] = set()
    linear = True
    for edge in h.edges:
        for pair in combinations(edge, 2):
            if pair in used_pairs:
                linear = False
            used_pairs.add(pair)
    checks.require(linear, "linearity", prefix + "repeated vertex pair")
    return inc


def local_multiplicities(h: Hypergraph, inc: list[list[int]], edge_index: int) -> list[int]:
    """Compute t_v by inspecting every incident edge, without a formula for t_v."""
    distinguished = set(h.edges[edge_index])
    answer = [0] * h.n
    for v in range(h.n):
        if v not in distinguished:
            answer[v] = sum(bool(distinguished.intersection(h.edges[j])) for j in inc[v])
    return answer


def geometry(h: Hypergraph, inc: list[list[int]], checks: CheckLog,
             expected_positive_t: int | None = None) -> list[dict]:
    rho = Fraction(2 ** (h.r - 1) - 2, 2 ** (h.r - 1) - 1)
    result = []
    for i, edge in enumerate(h.edges):
        t = local_multiplicities(h, inc, i)
        outside = [v for v in range(h.n) if v not in edge]
        histogram = Counter(t[v] for v in outside)
        checks.require(all(0 <= t[v] <= h.r for v in outside), "multiplicity_range",
                       f"{h.name}: t_v out of range at edge {i}")
        checks.require(sum(t) == h.r * (h.r - 1) * (h.d - 1), "multiplicity_sum",
                       f"{h.name}: sum t_v identity at edge {i}")
        coefficient = Fraction(h.r) + sum((1 - rho ** t[v] for v in outside), Fraction(0))
        if h.r == 3:
            checks.require(Fraction(38 * h.d + 43, 27) <= coefficient <= 2 * h.d + 1,
                           "sharp_coefficient_bounds", f"{h.name}: coefficient bounds at edge {i}")
        if expected_positive_t is not None:
            checks.require(all(t[v] in (0, expected_positive_t) for v in outside),
                           "extremal_geometry", f"{h.name}: nonextremal multiplicity at edge {i}")
            expected_coefficient = (Fraction(38 * h.d + 43, 27) if expected_positive_t == 3
                                    else Fraction(2 * h.d + 1))
            checks.require(coefficient == expected_coefficient, "extremal_coefficient",
                           f"{h.name}: extremal coefficient at edge {i}")
            if expected_positive_t == 3:
                checks.require(all(t[v] == 3 for v in outside), "steiner_outside_multiplicities",
                               f"{h.name}: outside vertex has t_v != 3 at edge {i}")
        result.append({"edge_index": i, "edge": list(edge), "t": t,
                       "outside_t_histogram": {str(k): v for k, v in sorted(histogram.items())},
                       "coefficient_value": coefficient})
    return result


def fano_plane() -> Hypergraph:
    edges = {tuple(sorted((x - 1, y - 1, (x ^ y) - 1)))
             for x in range(1, 8) for y in range(x + 1, 8)}
    return Hypergraph("Fano plane", 7, 3, 3, tuple(sorted(edges)))


def affine_lines_3(k: int) -> Hypergraph:
    points = list(product(range(3), repeat=k))
    index = {p: i for i, p in enumerate(points)}
    edges = set()
    for x in points:
        for direction in points[1:]:
            edge = tuple(sorted(index[tuple((x[j] + s * direction[j]) % 3 for j in range(k))]
                                for s in range(3)))
            edges.add(edge)
    n = 3 ** k
    return Hypergraph(f"AG({k},3)", n, 3, (n - 1) // 2, tuple(sorted(edges)))


def cyclic_sts_13() -> Hypergraph:
    bases = ((0, 1, 4), (0, 2, 7))
    edges = {tuple(sorted((x + shift) % 13 for x in base))
             for base in bases for shift in range(13)}
    return Hypergraph("Cyclic STS(13)", 13, 3, 6, tuple(sorted(edges)))


def pasch_configuration() -> Hypergraph:
    # The four vertex-stars of K_4, viewed as triples of its six edges.
    return Hypergraph("Pasch configuration", 6, 3, 2,
                      ((0, 1, 2), (0, 3, 4), (1, 3, 5), (2, 4, 5)))


def row_column_grid_3() -> Hypergraph:
    edges = [tuple(3 * row + col for col in range(3)) for row in range(3)]
    edges += [tuple(3 * row + col for row in range(3)) for col in range(3)]
    return Hypergraph("3 by 3 row-column grid", 9, 3, 2, tuple(sorted(edges)))


def gf4_multiply(a: int, b: int) -> int:
    """Polynomial multiplication over F_2 modulo X^2+X+1."""
    result = 0
    while b:
        if b & 1:
            result ^= a
        b >>= 1
        a <<= 1
        if a & 4:
            a ^= 7
    return result


def affine_plane_4() -> Hypergraph:
    edges = []
    for slope in range(4):
        for intercept in range(4):
            edges.append(tuple(sorted(4 * x + (gf4_multiply(slope, x) ^ intercept)
                                      for x in range(4))))
    for x in range(4):
        edges.append(tuple(4 * x + y for y in range(4)))
    return Hypergraph("AG(2,4)", 16, 4, 5, tuple(sorted(edges)))


def ap_free_system(d: int) -> tuple[Hypergraph, int, tuple[int, ...]]:
    modulus = 2 ** (d + 1) + 1
    steps = tuple(2 ** i for i in range(d))
    edges = []
    for x in range(modulus):
        for step in steps:
            edges.append((x, modulus + (x + step) % modulus,
                          2 * modulus + (x + 2 * step) % modulus))
    h = Hypergraph(f"AP-free modular system, d={d}", 3 * modulus, 3, d, tuple(sorted(edges)))
    return h, modulus, steps


def enumerate_finite_model(h: Hypergraph, checks: CheckLog) -> dict:
    if h.n > 16:
        raise ValueError("Exhaustive product-space enumeration is limited to 16 vertices")
    started = time.perf_counter()
    inc = validate(h, checks)
    steiner_triple_parameters = h.r == 3 and h.n == 2 * h.d + 1
    shapes = geometry(h, inc, checks, 3 if steiner_triple_parameters else None)
    masks = [edge_mask(e) for e in h.edges]
    m = len(masks)
    full_v = (1 << h.n) - 1
    full_e = (1 << m) - 1
    assignments = 1 << h.n
    generators = [sum(1 << j for j in indices) for indices in inc]

    # Enumerate ORIGINAL generator selections, retaining maximal selections in
    # each fiber.  This construction does not use the no-isolated-vertex rule.
    original_unions = [0] * assignments
    fiber_maximum: dict[int, int] = {0: 0}
    for selection in range(1, assignments):
        low = selection & -selection
        v = low.bit_length() - 1
        union = original_unions[selection ^ low] | generators[v]
        original_unions[selection] = union
        fiber_maximum[union] = fiber_maximum.get(union, 0) | selection

    # Independently enumerate DUAL edge unions by closure under adjoining an edge.
    dual_edge_unions = {0}
    for mask in masks:
        dual_edge_unions.update({selected | mask for selected in dual_edge_unions})

    bad_counts = [0] * h.n
    pair_counts = [[0] * h.n for _ in range(h.n)]
    pin_counts = [0] * m
    pin_bad_counts = [[0] * h.n for _ in range(m)]
    valid_pin_counts = [0] * m
    valid_subsets: set[int] = set()
    valid_original_images: set[int] = set()
    for selected in range(assignments):
        contained = [j for j, mask in enumerate(masks) if selected & mask == mask]
        covered = 0
        contained_mask = 0
        for j in contained:
            covered |= masks[j]
            contained_mask |= 1 << j
            pin_counts[j] += 1
        isolated = selected & ~covered
        isolated_vertices = list(bits(isolated))
        direct_isolated = sum(1 << v for v in bits(selected)
                              if all(selected & masks[j] != masks[j] for j in inc[v]))
        checks.require(isolated == direct_isolated, "bad_event_characterization",
                       f"{h.name}: isolated-vertex characterization at subset {selected}")
        checks.require(original_unions[full_v ^ selected] == full_e ^ contained_mask,
                       "complement_union_identity",
                       f"{h.name}: complement identity at subset {selected}")
        for v in isolated_vertices:
            bad_counts[v] += 1
        for u, v in combinations(isolated_vertices, 2):
            pair_counts[u][v] += 1
        for j in contained:
            for v in isolated_vertices:
                pin_bad_counts[j][v] += 1
        if not isolated:
            valid_subsets.add(selected)
            original_image = full_e ^ contained_mask
            valid_original_images.add(original_image)
            checks.require(full_v ^ fiber_maximum[original_image] == selected,
                           "canonical_inverse_bijection",
                           f"{h.name}: inverse correspondence at subset {selected}")
            for j in contained:
                valid_pin_counts[j] += 1

    checks.require(valid_subsets == dual_edge_unions, "dual_union_family_equality",
                   h.name + ": no-isolate family differs from dual edge-union family")
    checks.require(valid_original_images == set(fiber_maximum), "original_union_family_equality",
                   h.name + ": original family differs from image of dual valid family")
    checks.require({full_v ^ maximum for maximum in fiber_maximum.values()} == valid_subsets,
                   "canonical_family_equality", h.name + ": canonical fibers differ from valid subsets")
    checks.require(len(valid_subsets) == len(fiber_maximum), "bijection_cardinality",
                   h.name + ": family cardinalities differ")

    a = 1 - Fraction(1, 2 ** (h.r - 1))
    rho = Fraction(2 ** (h.r - 1) - 2, 2 ** (h.r - 1) - 1)
    p = a ** h.d / 2
    for v, count in enumerate(bad_counts):
        checks.require(Fraction(count, assignments) == p, "exact_bad_event_marginal",
                       f"{h.name}: P(B_{v}) != a^d/2")
    edge_results = []
    frequencies = []
    residuals = []
    for j, edge in enumerate(h.edges):
        checks.require(pin_counts[j] == 2 ** (h.n - h.r), "exact_pin_probability",
                       f"{h.name}: wrong pin probability for edge {j}")
        for v in range(h.n):
            actual = Fraction(pin_bad_counts[j][v], pin_counts[j])
            expected = 0 if v in edge else p * rho ** shapes[j]["t"][v]
            checks.require(actual == expected, "exact_pinned_bad_marginal",
                           f"{h.name}: pinned marginal at edge {j}, vertex {v}")
        coefficient_from_counts = sum((Fraction(bad_counts[v], assignments)
                                       - Fraction(pin_bad_counts[j][v], pin_counts[j])
                                       for v in range(h.n)), Fraction(0)) / p
        coefficient = shapes[j]["coefficient_value"]
        checks.require(coefficient_from_counts == coefficient, "coefficient_from_exact_marginals",
                       f"{h.name}: first-moment coefficient at edge {j}")
        frequency = 1 - Fraction(valid_pin_counts[j], len(valid_subsets))
        direct_original_frequency = Fraction(sum(bool(union & (1 << j)) for union in fiber_maximum),
                                             len(fiber_maximum))
        checks.require(frequency == direct_original_frequency, "uniform_distinct_union_frequency",
                       f"{h.name}: original point frequency at edge {j}")
        first_order_prediction = 1 - Fraction(1, 2 ** h.r) - a ** h.d * coefficient / 2 ** (h.r + 1)
        residual = frequency - first_order_prediction
        frequencies.append(frequency)
        residuals.append(residual)
        edge_results.append({"edge_index": j, "edge": list(edge),
                             "outside_t_histogram": shapes[j]["outside_t_histogram"],
                             "coefficient": rational(coefficient),
                             "uniform_distinct_union_frequency": rational(frequency),
                             "first_order_prediction": rational(first_order_prediction),
                             "actual_minus_first_order_prediction": rational(residual),
                             "pinned_bad_counts": pin_bad_counts[j]})

    pair_report: dict = {"applicable": h.r == 3}
    if h.r == 3:
        bound = Fraction(1, 4) * Fraction(2, 3) ** h.d
        pair_values = []
        adjacent_values = []
        nonadjacent_values = []
        for u, v in combinations(range(h.n), 2):
            actual = Fraction(pair_counts[u][v], assignments)
            checks.require(actual <= bound, "r3_pair_bad_event_bound",
                           f"{h.name}: P(B_{u} and B_{v}) exceeds (2/3)^d/4")
            pair_values.append((actual, u, v))
            target = adjacent_values if set(inc[u]).intersection(inc[v]) else nonadjacent_values
            target.append(actual)
        maximum, u, v = max(pair_values)
        pair_report.update({"pair_count": len(pair_values), "bound": rational(bound),
                            "largest_actual_probability": rational(maximum),
                            "largest_actual_to_bound_ratio": rational(maximum / bound),
                            "one_maximizing_pair": [u, v],
                            "joint_bad_probability_histogram": {
                                rational(value): count for value, count in sorted(Counter(x[0] for x in pair_values).items())}})
        pair_report["adjacent_pair_count"] = len(adjacent_values)
        pair_report["nonadjacent_pair_count"] = len(nonadjacent_values)
        pair_report["largest_adjacent_probability"] = rational(max(adjacent_values)) if adjacent_values else None
        pair_report["largest_nonadjacent_probability"] = rational(max(nonadjacent_values)) if nonadjacent_values else None

    return {"name": h.name, "vertices": h.n, "rank": h.r, "degree": h.d, "edge_count": m,
            "edges": [list(e) for e in h.edges], "product_assignments_enumerated": assignments,
            "original_generator_selections_enumerated": assignments,
            "distinct_original_unions": len(fiber_maximum),
            "distinct_dual_edge_unions": len(dual_edge_unions), "valid_vertex_subsets": len(valid_subsets),
            "valid_product_probability": rational(Fraction(len(valid_subsets), assignments)),
            "a": rational(a), "rho": rational(rho), "bad_event_probability": rational(p),
            "bad_event_counts": bad_counts,
            "frequency_range": [rational(min(frequencies)), rational(max(frequencies))],
            "first_order_residual_range": [rational(min(residuals)), rational(max(residuals))],
            "first_order_values_are_descriptive_only": True,
            "r3_pair_bound": pair_report, "edge_statistics": edge_results,
            "elapsed_seconds": round(time.perf_counter() - started, 6)}


def structural_extremal_model(h: Hypergraph, checks: CheckLog, positive_t: int) -> dict:
    inc = validate(h, checks)
    shapes = geometry(h, inc, checks, positive_t)
    if positive_t == 3:
        pair_counts = Counter(pair for edge in h.edges for pair in combinations(edge, 2))
        checks.require(len(pair_counts) == h.n * (h.n - 1) // 2
                       and all(count == 1 for count in pair_counts.values()),
                       "steiner_pair_coverage", h.name + ": incomplete Steiner pair coverage")
    coefficients = sorted({shape["coefficient_value"] for shape in shapes})
    histograms = {json.dumps(shape["outside_t_histogram"], sort_keys=True) for shape in shapes}
    return {"name": h.name, "vertices": h.n, "rank": h.r, "degree": h.d,
            "edge_count": len(h.edges), "all_edges_checked": len(shapes),
            "product_space_enumerated": False, "expected_nonzero_outside_multiplicity": positive_t,
            "outside_t_histograms": [json.loads(value) for value in sorted(histograms)],
            "coefficients": [rational(value) for value in coefficients]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    default_output = Path(__file__).resolve().parent.parent / "data" / "finite_models.json"
    parser.add_argument("--output", type=Path, default=default_output)
    args = parser.parse_args()
    started = time.perf_counter()
    checks = CheckLog()
    finite = []
    structural = []
    for h in (fano_plane(), affine_lines_3(2), cyclic_sts_13(), affine_plane_4(),
              pasch_configuration(), row_column_grid_3()):
        result = enumerate_finite_model(h, checks)
        finite.append(result)
        print(f"{h.name}: enumerated {result['product_assignments_enumerated']} product subsets; "
              f"{result['distinct_original_unions']} distinct unions; "
              f"frequency range {result['frequency_range']}", flush=True)
    for k in range(1, 4):
        structural.append(structural_extremal_model(affine_lines_3(k), checks, 3))
    for d in range(1, 7):
        h, modulus, steps = ap_free_system(d)
        for a, b, c in product(steps, repeat=3):
            checks.require((a + c - 2 * b) % modulus != 0 or a == b == c,
                           "no_modular_three_term_progression",
                           f"{h.name}: nontrivial modular progression {(a, b, c)}")
        result = structural_extremal_model(h, checks, 1)
        result.update({"modulus": modulus, "steps": list(steps),
                       "construction": "edges {(0,x),(1,x+s),(2,x+2s)} over Z/modulus"})
        structural.append(result)
    report = {"status": "passed" if not checks.failure_count else "failed",
              "scope": "Exact finite checks of stated identities and examples; not a proof of the asymptotic theorem or of novelty.",
              "arithmetic": "Exact integers and fractions.Fraction; floating point is used only for elapsed time.",
              "python_version": platform.python_version(),
              "finite_model_count": len(finite), "structural_model_count": len(structural),
              "product_assignments_enumerated": sum(x["product_assignments_enumerated"] for x in finite),
              "logical_comparisons": sum(checks.counts.values()),
              "comparisons_by_category": dict(sorted(checks.counts.items())),
              "failure_count": checks.failure_count, "failures_first_100": checks.failures,
              "finite_models": finite, "structural_extremal_models": structural,
              "elapsed_seconds": round(time.perf_counter() - started, 6)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"{report['status'].upper()}: {report['logical_comparisons']} exact comparisons; "
          f"{checks.failure_count} failures; report: {args.output}", flush=True)
    return 1 if checks.failure_count else 0


if __name__ == "__main__":
    sys.exit(main())
