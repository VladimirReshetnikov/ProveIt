#!/usr/bin/env python3
"""Exact rational certificates for the finite frequency-deficit theorem.

Only the standard library is required. Fractions decide every asserted
inequality; decimal intervals are outward-rounded display values.
"""
from __future__ import annotations

import json
from fractions import Fraction as F
from math import comb
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def interval(x: F, digits: int = 30) -> list[str]:
    """Enclose a rational in adjacent multiples of 10**(-digits)."""
    scale = 10**digits
    lo = x.numerator * scale // x.denominator
    hi = -((-x.numerator * scale) // x.denominator)

    def fmt(n: int) -> str:
        sign = "-" if n < 0 else ""
        n = abs(n)
        return f"{sign}{n // scale}.{n % scale:0{digits}d}"

    assert F(lo, scale) <= x <= F(hi, scale)
    return [fmt(lo), fmt(hi)]


def finite_bound(r: int, d: int) -> dict[str, F | int]:
    assert r >= 3 and d >= 1
    k = r - 1
    a = 1 - F(1, 2**k)
    rho = F(2**k - 2, 2**k - 1)
    gamma = 1 - (rho / 2)**k
    ell = 1 + k * (k - 1)
    z = a**d
    p = z / 2
    D = (1 + k*d)**2
    M = r * (1 + k*(d-1))
    assert M <= D
    if D*z > F(1, 2):
        raise ValueError("The stated sufficient hypothesis D*z <= 1/2 fails")
    lam = 1 / (1-D*z)
    if r == 3:
        J = F(2, 3)**d / 4
    else:
        J = max(z * gamma**((d+ell-1)//ell),
                (2*a-1) * a**(d-1) * gamma**((d+ell-2)//ell)) / 4
    Q = 2**r * J * lam**2
    eta = p*(lam-1) + D*Q
    E = M*eta + comb(M, 2)*Q
    B = M*p*lam
    assert 0 <= B <= F(1, 2)
    delta = F(1, 2**r)*(2*E + M*p*B)/(1-B)
    c_min = r + (d-1)*k*(1-rho**r)
    c_max = r + r*(d-1)*k*(1-rho)
    main_min = F(1, 2**(r+1))*z*c_min
    main_max = F(1, 2**(r+1))*z*c_max
    return dict(r=r, d=d, z=z, D=D, M=M, lam=lam, J=J,
                B=B, delta=delta, c_min=c_min, c_max=c_max,
                normalized_error=delta/(d*z),
                normalized_lower=(main_min-delta)/(d*z),
                normalized_upper=(main_max+delta)/(d*z))


def certify_all_large_degrees() -> dict:
    """Finite rational endpoints of the analytic monotonicity proof."""
    d0 = 200
    v = finite_bound(3, d0)
    q = F(8, 9)
    L = F(1001, 1000)
    # The proof shows these quantities decrease for every integer d>=d0.
    assert F(3, 4)*F(2*d0+3, 2*d0+1)**2 < 1  # D(d) z(d)
    assert F(3, 4)*F(6*d0+3, 6*d0-3) < 1    # M(d) z(d)
    assert q*F(d0+1, d0)**2 < 1              # d^2 q^d
    assert v['D']*v['z'] <= F(1, 1001)
    assert v['B'] <= F(1, 1001)
    assert F(27, 32)**d0 <= F(1, 1000)
    A = F(401, 200)**2
    c_first = F(3, 4)*(A+F(3, 400))
    c_second = 3*(A+F(3, 200))
    coefficient = L**3*(c_first/F(1000)+c_second)
    assert coefficient < F(25, 2)
    tail = F(25, 2)*d0**2*q**d0
    assert tail < F(3, 100000)
    assert F(19, 216)-F(3, 100000) > F(879, 10000)
    assert F(1, 8)+F(1, 16*d0)+F(3, 100000) < F(627, 5000)
    assert F(627, 5000)*d0*F(3, 4)**d0 < F(3, 8)
    return {
        'minimum_degree': d0,
        'polynomial_coefficient_upper': '25/2',
        'checked_coefficient_interval': interval(coefficient),
        'normalized_error_uniform_upper': '3/100000',
        'endpoint_tail_interval': interval(tail),
        'uniform_normalized_deficit_lower': '879/10000',
        'uniform_normalized_deficit_upper': '627/5000',
        'interpretation': 'The manuscript proves monotonicity for all d>=200; exact arithmetic certifies its finite starting inequalities.'
    }


def main() -> None:
    rows = []
    for r, ds in [(3, [128, 150, 160, 180, 200, 250, 300]),
                  (4, [2000, 4000])]:
        for d in ds:
            v = finite_bound(r, d)
            rows.append({
                'r': r, 'd': d,
                'normalized_error_interval': interval(v['normalized_error']),
                'normalized_deficit_lower_interval': interval(v['normalized_lower']),
                'normalized_deficit_upper_interval': interval(v['normalized_upper']),
                'hypothesis_Dz_at_most_half': True,
                'denominator_B_at_most_half': True,
            })
    result = {
        'arithmetic': 'fractions.Fraction; exact integer comparisons',
        'normalization': '(1-2^(-r)-f_x)/(d*(1-2^(1-r))^d)',
        'rows': rows,
        'all_d_at_least_200': certify_all_large_degrees(),
        'status': 'All exact rational checks passed',
        'scope': 'Certificates for constants and finite algebra; the general proof is in paper.tex.'
    }
    out = ROOT/'data'/'finite_bound_certificates.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2)+'\n')
    print(result['status'])
    for row in rows:
        print(f"r={row['r']}, d={row['d']}: error interval {row['normalized_error_interval']}")
    print('Certified all-degree consequence: d>=200, normalized deficit in [879/10000,627/5000].')


if __name__ == '__main__':
    main()
