#!/usr/bin/env python3
"""Draw the proved finite envelopes; no simulated data enter this figure."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from certify_bounds import finite_bound

ROOT = Path(__file__).resolve().parents[1]

def main():
    ds = list(range(150, 321, 2))
    bounds = [finite_bound(3, d) for d in ds]
    lower = [float(v['normalized_lower']) for v in bounds]
    upper = [float(v['normalized_upper']) for v in bounds]
    fig, ax = plt.subplots(figsize=(8.2, 4.3), constrained_layout=True)
    fig.patch.set_facecolor('white')
    ax.set_facecolor('#fbfcfd')
    ax.fill_between(ds, lower, upper, color='#dbe8ef', label='Interval guaranteed by the finite theorem')
    ax.plot(ds, upper, color='#17617b', lw=2.2, label='Certified upper envelope')
    ax.plot(ds, lower, color='#ad592e', lw=2.2, label='Certified lower envelope')
    ax.axhline(1/8, color='#17617b', ls='--', lw=1.1)
    ax.axhline(19/216, color='#ad592e', ls='--', lw=1.1)
    ax.text(315, 1/8-0.0014, r'$1/8$', ha='right', va='top', color='#17617b')
    ax.text(315, 19/216+0.0014, r'$19/216$', ha='right', va='bottom', color='#ad592e')
    ax.set_xlabel(r'Generator size $d$ (each element lies in three generators)', labelpad=8)
    ax.set_ylabel(r'Normalized deficit $(7/8-f_x)/[d(3/4)^d]$', labelpad=9)
    ax.set_xlim(150, 320)
    ax.set_ylim(0.08, 0.135)
    ax.grid(axis='y', color='#ccd4d9', lw=0.6, alpha=.7)
    ax.set_axisbelow(True)
    ax.spines[['top', 'right']].set_visible(False)
    ax.legend(loc='center right', fontsize=8.5, frameon=True, facecolor='white', framealpha=.95)
    ax.set_title('A sharp interval for the leading frequency deficit', loc='left', pad=12, fontsize=13, fontweight='bold')
    out = ROOT/'figures'
    out.mkdir(exist_ok=True)
    fig.savefig(out/'deficit_bounds.pdf')
    fig.savefig(out/'deficit_bounds.png', dpi=170)
    plt.close(fig)
    print('Created the PDF and PNG figure from the rational finite bound.')

if __name__ == '__main__':
    main()
