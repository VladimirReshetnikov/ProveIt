#!/usr/bin/env python3
"""Illustrative syntax, computations, and Boolean compilation for the PRA paper.

Python 3.10+, standard library only.  Run --check for regression-check JSON,
or --demo for the presentation and an example.  This is NOT a formal proof
checker.  Finite computations do not establish any axiom-schema equivalence.
The uniform interpreter for arbitrary PR descriptions is not itself a
primitive-recursive function; each fixed description denotes a PR function.
Python resource limits still apply to large descriptions and inputs.

Terms are variables or applications.  Nesting supplies composition; variables
supply projections.  A recursion declaration R(n,p) has base g(p) and step
h(n,z,p); only previously declared functions may occur in g and h.
Only 0 and S are primitive.  The ordinary PR term delta(x,y), built below
from predecessor, truncated subtraction, and B, is 1 when x=y and 0
otherwise in the standard natural numbers.  The paper's
single comparison axiom is delta(x,y)=0 iff x != y; together with the
recursion equations it implies 0 != S(0).  No primitive equality oracle
occurs in the term language or its evaluator.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import itertools
import json


@dataclass(frozen=True)
class Var:
    index: int


@dataclass(frozen=True)
class Call:
    name: str
    args: tuple[Term, ...] = ()


Term = Var | Call


def f(name: str, *args: Term) -> Call:
    return Call(name, args)


ZERO = f("0")
ONE = f("S", ZERO)


@dataclass(frozen=True)
class Recursion:
    parameters: int
    base: Term
    step: Term


class Language:
    def __init__(self) -> None:
        self.arities = {"0": 0, "S": 1}
        self.recursions: dict[str, Recursion] = {}

    def validate(self, term: Term, variables: int) -> None:
        if isinstance(term, Var):
            if type(term.index) is not int or not 0 <= term.index < variables:
                raise ValueError("variable is outside the current environment")
            return
        if not isinstance(term, Call) or term.name not in self.arities:
            raise ValueError("term uses an unknown function or invalid constructor")
        if not isinstance(term.args, tuple) or len(term.args) != self.arities[term.name]:
            raise ValueError("incorrect function arity")
        for arg in term.args:
            self.validate(arg, variables)

    def declare(self, name: str, parameters: int, base: Term, step: Term) -> None:
        if not isinstance(name, str) or not name or name in self.arities:
            raise ValueError("a declaration requires a fresh nonempty name")
        if type(parameters) is not int or parameters < 0:
            raise ValueError("parameter count must be a natural number")
        # Register only AFTER checking, thereby excluding forward/self references.
        self.validate(base, parameters)
        self.validate(step, parameters + 2)
        self.recursions[name] = Recursion(parameters, base, step)
        self.arities[name] = parameters + 1

    def evaluate(self, term: Term, values: tuple[int, ...] = ()) -> int:
        if any(type(value) is not int or value < 0 for value in values):
            raise ValueError("all inputs must be natural numbers")
        self.validate(term, len(values))
        return self._evaluate(term, values)

    def _evaluate(self, term: Term, values: tuple[int, ...]) -> int:
        if isinstance(term, Var):
            return values[term.index]
        args = tuple(self._evaluate(arg, values) for arg in term.args)
        if term.name == "0":
            return 0
        if term.name == "S":
            return args[0] + 1
        declaration = self.recursions[term.name]
        n, parameters = args[0], args[1:]
        result = self._evaluate(declaration.base, parameters)
        for k in range(n):
            result = self._evaluate(declaration.step, (k, result, *parameters))
        return result


def make_language() -> Language:
    language = Language()
    language.declare("P", 0, ZERO, Var(0))
    language.declare("monus", 1, Var(0), f("P", Var(1)))  # monus(n,x)=x-n, cut at 0.
    language.declare("B", 1, Var(0), ZERO)  # B(0,y)=y; B(Sn,y)=0.
    # Optional ordinary helper for examples/checks; not used by delta or gates.
    language.declare("add", 1, Var(0), f("S", Var(1)))  # add(n,x)=x+n.
    return language


def gate(tag: str, a: Term, b: Term = ZERO) -> Term:
    choices = {"not": f("B", a, ONE),
               "and": f("B", f("B", a, f("B", b, ONE)), ONE),
               "or": f("B", f("B", a, ONE), b), "imp": f("B", a, b)}
    if tag not in choices:
        raise ValueError("unknown Boolean connective")
    return choices[tag]


def compile_formula(language: Language, formula: tuple, variables: int) -> Term:
    if not isinstance(formula, tuple) or not formula:
        raise ValueError("invalid formula")
    tag, *parts = formula
    if tag == "bottom" and not parts:
        result = ONE
    elif tag == "eq" and len(parts) == 2:
        result = f("B", delta(*parts), ONE)
    elif tag == "not" and len(parts) == 1:
        result = gate(tag, compile_formula(language, parts[0], variables))
    elif tag in ("and", "or", "imp") and len(parts) == 2:
        result = gate(tag, *(compile_formula(language, p, variables) for p in parts))
    else:
        raise ValueError("invalid formula constructor or arity")
    language.validate(result, variables)
    return result


def direct_truth(language: Language, formula: tuple, values: tuple[int, ...]) -> bool:
    tag, *parts = formula
    if tag == "bottom":
        return False
    if tag == "eq":
        return language.evaluate(parts[0], values) == language.evaluate(parts[1], values)
    a = direct_truth(language, parts[0], values)
    if tag == "not":
        return not a
    b = direct_truth(language, parts[1], values)
    return {"and": a and b, "or": a or b, "imp": (not a) or b}[tag]


def delta(x: Term, y: Term) -> Term:
    """B(x monus y,B(y monus x,1)): standard value 1 if equal, else 0."""
    return f("B", f("monus", y, x), f("B", f("monus", x, y), ONE))


def pretty(term: Term) -> str:
    if isinstance(term, Var):
        return f"v{term.index}"
    return term.name if not term.args else term.name + "(" + ",".join(map(pretty, term.args)) + ")"


def checks() -> dict:
    language = make_language()
    x, y, z = Var(0), Var(1), Var(2)
    counts = {"arithmetic": 0, "boolean_gates": 0, "formula_instances": 0,
              "invalid_inputs_rejected": 0}
    for n in range(12):
        assert language.evaluate(f("P", x), (n,)) == max(0, n - 1)
        counts["arithmetic"] += 1
    for a, b in itertools.product(range(8), repeat=2):
        env = (a, b)
        assert language.evaluate(f("add", x, y), env) == a + b
        assert language.evaluate(f("monus", x, y), env) == max(0, b - a)
        assert language.evaluate(delta(x, y), env) == int(a == b)
        assert language.evaluate(f("B", delta(x, y), ONE), env) == int(a != b)
        counts["arithmetic"] += 4
    tables = []
    for a, b in itertools.product((0, 1), repeat=2):
        row = {"a": a, "b": b}
        truth = {"not": not (a == 0), "and": a == 0 and b == 0,
                 "or": a == 0 or b == 0, "imp": a != 0 or b == 0}
        for tag in truth:
            row[tag] = language.evaluate(gate(tag, x, y), (a, b))
            assert row[tag] == int(not truth[tag])
            counts["boolean_gates"] += 1
        tables.append(row)
    formulas = [
        ("bottom",),
        ("eq", x, y), ("not", ("eq", x, y)),
        ("and", ("eq", f("add", x, ONE), y), ("not", ("eq", x, ZERO))),
        ("or", ("eq", x, ZERO), ("eq", f("P", x), y)),
        ("imp", ("and", ("eq", x, y), ("eq", z, ZERO)),
         ("eq", f("add", z, x), y)),
    ]
    for formula in formulas:
        term = compile_formula(language, formula, 3)
        for values in itertools.product(range(6), repeat=3):
            value = language.evaluate(term, values)
            assert value in (0, 1)
            assert (value == 0) == direct_truth(language, formula, values)
            counts["formula_instances"] += 1
    invalid = [
        lambda: language.validate(Var(3), 3),
        lambda: language.validate(f("unknown"), 0),
        lambda: language.validate(f("S", ZERO, ZERO), 0),
        lambda: language.declare("cycle", 0, ZERO, f("cycle", Var(0))),
        lambda: language.declare("badbase", 0, Var(0), ZERO),
        lambda: language.declare("badstep", 0, ZERO, Var(2)),
        lambda: language.declare("B", 0, ZERO, ZERO),
        lambda: language.evaluate(x, (-1,)),
        lambda: compile_formula(language, ("and", ("eq", x, y)), 2),
    ]
    for reject in invalid:
        try:
            reject()
        except ValueError:
            counts["invalid_inputs_rejected"] += 1
        else:
            raise AssertionError("invalid syntax or input was accepted")
    return {"status": "ok", "counts": counts, "truth_code": "0=true, 1=false",
            "gate_truth_tables": tables,
            "scope": "Finite regression checks only; not a formal proof checker."}


def demo() -> None:
    print("Primitive signature: 0,S.  All other functions come from recursion.")
    print("Comparison axiom: delta(x,y)=0 iff x!=y.")
    print("delta(x,y)=B(x monus y,B(y monus x,1)); B(0,y)=y, B(Sn,y)=0.")
    print("Induction: [t(0,p)=0 & forall n(t(n,p)=0 -> t(Sn,p)=0)]")
    print("           -> forall n t(n,p)=0.")
    print("R(n,p): base g(p); step h(n,z,p); declarations must be acyclic.")
    print("Argument convention: monus(n,x)=max(x-n,0).")
    print("Optional example helper: add(n,x)=x+n (not used in the core).")
    language = make_language()
    formula = ("imp", ("eq", Var(0), Var(1)),
               ("eq", f("S", Var(0)), f("S", Var(1))))
    term = compile_formula(language, formula, 2)
    print("Example formula: v0=v1 -> S(v0)=S(v1)")
    print("Compiled truth-code term:", pretty(term))
    print("At (2,2) its value is", language.evaluate(term, (2, 2)))
    print("The ordinary PR delta term:", pretty(delta(Var(0), Var(1))))
    print("Each fixed description is PR; this uniform interpreter is not itself PR.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="run checks and print JSON")
    parser.add_argument("--demo", action="store_true", help="print presentation and example")
    args = parser.parse_args()
    if args.demo or not args.check:
        demo()
    if args.check:
        if not __debug__:
            parser.error("--check requires assertions enabled: do not use python -O")
        print(json.dumps(checks(), indent=2))
