A COMPACT AXIOMATIZATION OF PRA WITH ATOMIC INDUCTION
31 October 2026

MAIN RESULT
Besides the ordinary primitive-recursive defining equations, use one
fixed comparison axiom and induction only for equations t(n,p)=0.
The fixed comparison term is an ordinary PR program, not an oracle.
The paper proves exact equivalence with standard first-order PRA in
the same description language, with complete proofs in both directions.

CONTENTS
  pra_axiomatization.pdf  Compiled mathematical report.
  pra_axiomatization.tex  Self-contained LaTeX source and bibliography.
  axioms.txt             Complete plain-text specification.
  pra_core.py            Syntax/evaluation/formula-compilation demonstration.
  verification.json      Actual finite implementation-check output.
  verification.txt       Validation scope and build record.
  Makefile               Rebuild and check commands.
  SHA256SUMS             SHA-256 checksums of the other deliverables.

READING GUIDE
  Sections 2-5: Complete basis and proof of exact equivalence.
  Section 6: Product countermodel explaining the failed naive reduction.
  Section 7: Alternative presentations and limits of minimality claims.
  Section 9: Further research questions.
  Appendix A: Full reverse proof for the fixed comparison term.
  Appendix B: Precise partial observations on disequation induction.

BUILD THE PDF
Requires a reasonably complete TeX Live installation with pdflatex,
amsmath, amssymb, amsthm, mathtools, lmodern, geometry, booktabs,
enumitem, microtype, xcolor, tcolorbox, fancyhdr, and hyperref.

  make

Equivalent commands:
  pdflatex -interaction=nonstopmode -halt-on-error pra_axiomatization.tex
  pdflatex -interaction=nonstopmode -halt-on-error pra_axiomatization.tex

RUN THE DEMONSTRATION
Requires Python 3.10 or later; uses only the standard library.

  python3 pra_core.py --check
  python3 pra_core.py --demo

Do not run --check with Python optimization (-O), which disables assertions.

The evaluator has only 0 and S as primitive operations. Every other
operation is an acyclic primitive-recursion declaration. The primary
comparison program uses P, monus, and B; addition is only an optional
example helper. The code puts the recursion argument first:
  monus(n,x) = max(x-n,0)
  add(n,x) = x+n
The displayed mathematical subtraction sub(x,y) is therefore represented
by monus(y,x). The script's delta follows the paper's argument order exactly.

VERIFICATION SCOPE
The equivalence is proved mathematically in the paper. The executable
checks validate finite computations and compiler examples; they do not
formally verify the general theorem. No Lean or Rocq proof is included.
The external uniform interpreter is not itself a primitive-recursive
function of a program description and its input, although each fixed
well-formed description denotes a primitive-recursive function.

IMPORTANT QUALIFICATIONS
The one comparison axiom is accompanied by infinite defining-equation
and induction families. This is not a finite axiomatization, and no
absolute minimality or historical novelty is claimed. The report also
identifies a problem with a literal reading of a printed 1975 statement;
its own equivalence theorem does not depend on that statement.
