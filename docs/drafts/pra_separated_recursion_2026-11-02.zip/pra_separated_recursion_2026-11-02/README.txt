PRA BY SEPARATED RECURSION
Prepared for Vladimir Reshetnikov, November 2, 2026

Start with report.pdf for the complete paper or AXIOMS.txt for the exact
four-case specification. LaTeX source is report.tex plus sections/*.tex.

RESULT
The primary theory is bi-interpretable and equiconsistent with first-order
PRA, with a common conservative definitional extension and full-carrier
identity round trips. The proof works separately with classical and
intuitionistic logic.

The four-case emitter is strictly below the current scalar lower envelope
at every raw input in both inherited syntax measures. It separates base
from update, uses a bound intermediate state, and removes occurrence
thresholds. This is a presentation simplification: it redistributes the
same obligations across existing normalized aliases. It is not a claim
of an encoding-independent minimum or of a weaker induction principle.

A second direct compression replaces a next-orbit test by one transition
at a known return state. An infinite family saves 1 active and 12 full
nodes versus the old selected-input coordinatewise envelope. Its optional
threshold refinement is distinguished from the primary four-case theory.

COMPARISON
All four archives in ProveIt/docs/drafts were inspected at commit
53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4.
The exact pointwise theorem covers the three archives sharing the scalar
grammar, including Local's optional selector. The autonomous archive's
different primary grammar is discussed separately; its binary adaptive
templates are counted as matched-template benchmarks only.
provenance/source_manifest.json contains immutable URLs and archive hashes.
The source archives are not redistributed here.

CONTENTS
report.pdf, report.tex, sections/*.tex: complete mathematical article.
AXIOMS.txt: exact primary theory and concise optional refinement.
checks/check_separated_emitter.py: independent actual-AST comparison.
checks/separated_results.json: completed comparison results.
checks/check_one_call.py, one_call_counts.json: witness-formula counts.
formal/BoundaryKernel.lean: checked logical kernels, no external imports.
formal/lean-toolchain, lean_version.txt, lean_output.txt: verified compiler.
formal/SCOPE.txt: exact limits of the formal verification.
verification/: build, review, and PDF checks.
build.py: portable build and optional checks.
SHA256SUMS: hashes of all package files except the manifest itself.

REPRODUCE
Requirements: Python 3.10+ and a standard LaTeX installation providing
pdflatex, amsmath, amsthm, mathtools, booktabs, tabularx, enumitem,
microtype, lmodern, fancyhdr, and hyperref.

  python3 build.py
  python3 build.py --checks
  python3 build.py --lean

--checks runs both Python checks (standard library only); the larger check
can take a few minutes. --lean uses lean on PATH or the executable path in
the LEAN environment variable. Verified with Lean 4.19.0; no Mathlib needed.
Flags may be combined. By default only the PDF is rebuilt.

VERIFICATION
The independent syntax run checked 28,206 distinct descriptions and
197,442 actual formula trees in both metrics; all comparisons passed.
The general theorem is proved symbolically in the article.
All seven printed Lean theorem axiom-dependency lists are empty.
The complete first-order bi-interpretation is a written proof; the Lean
file does not formalize the whole theory, pairing, or compiler.

The package is a research result with a precisely stated comparison scope,
not a proof of absolute optimality or exhaustive historical novelty.
