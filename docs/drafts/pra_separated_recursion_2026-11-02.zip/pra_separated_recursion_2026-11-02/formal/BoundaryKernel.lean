/-
PRA boundary and selector kernels.
Lean 4.19.0; no imports, classical axioms, sorry, or arithmetic induction
in the arbitrary-carrier extraction arguments.

The final Nat theorem uses legitimate Nat induction to verify the reverse
boundary-witness construction in the standard natural-number instance.
It does not formalize PRA's proof system, its syntax, or the full compiler.
-/
namespace BoundaryKernel

universe u

/-- Return induction follows from a boundary witness on any carrier. -/
theorem boundary_implies_return
    {M : Type u} (successor : M → M) (returns : M → Prop)
    (boundary : ∀ target, ∃ point,
      returns point ∧ (returns (successor point) → point = target))
    (progress : ∀ point, returns point → returns (successor point)) :
    ∀ target, returns target := by
  intro target
  obtain ⟨point, atPoint, identifies⟩ := boundary target
  have same : point = target := identifies (progress point atPoint)
  exact same ▸ atPoint

/-- The abstract one-call selector needs no order, predecessor or coverage. -/
theorem selector_implies_return
    {M : Type u} (returns : M → Prop) (test : M → Prop)
    (testDecision : ∀ point, Decidable (test point))
    (choose : M → M → M)
    (choose_yes : ∀ point target, test point → choose point target = target)
    (choose_no : ∀ point target, ¬test point → choose point target = point)
    (witness : ∀ target, ∃ point, returns (choose point target))
    (successful_return : ∀ point, returns point → test point) :
    ∀ target, returns target := by
  intro target
  obtain ⟨point, selectedReturns⟩ := witness target
  cases testDecision point with
  | isTrue successful =>
      rw [choose_yes point target successful] at selectedReturns
      exact selectedReturns
  | isFalse unsuccessful =>
      rw [choose_no point target unsuccessful] at selectedReturns
      exact False.elim (unsuccessful (successful_return point selectedReturns))

/-- Under the step equation, a tail test and the next return coincide
    whenever the current value returns. -/
theorem tail_selector_iff_boundary
    {M : Type u} [DecidableEq M]
    (successor : M → M) (trajectory : M → M) (targetValue : M)
    (tail : M → M)
    (returned_step : ∀ point, trajectory point = targetValue →
      trajectory (successor point) = tail point)
    (target : M) :
    (∃ point,
      trajectory (if tail point = targetValue then target else point) =
        targetValue) ↔
    (∃ point, trajectory point = targetValue ∧
      (trajectory (successor point) = targetValue → point = target)) := by
  constructor
  · rintro ⟨point, selectedReturns⟩
    by_cases successful : tail point = targetValue
    · simp only [if_pos successful] at selectedReturns
      exact ⟨target, selectedReturns, fun _ => rfl⟩
    · simp only [if_neg successful] at selectedReturns
      refine ⟨point, selectedReturns, ?_⟩
      intro nextReturns
      have nextStep := returned_step point selectedReturns
      exact False.elim (successful (nextStep.symm.trans nextReturns))
  · rintro ⟨point, atPoint, identifies⟩
    refine ⟨point, ?_⟩
    by_cases successful : tail point = targetValue
    · simp only [if_pos successful]
      have nextReturns : trajectory (successor point) = targetValue :=
        (returned_step point atPoint).trans successful
      exact identifies nextReturns ▸ atPoint
    · simpa only [if_neg successful] using atPoint

/-- Bound-state computation is exactly the ordinary step equation.
    This is first-order equality reasoning, with no induction. -/
theorem bound_step_iff
    {M : Type u} (successor : M → M)
    (recursor : M → M → M) (body : M → M → M) :
    (∀ seed counter state, recursor counter seed = state →
      recursor (successor counter) seed = body state counter) ↔
    (∀ seed counter,
      recursor (successor counter) seed = body (recursor counter seed) counter) := by
  constructor
  · intro bound seed counter
    exact bound seed counter (recursor counter seed) rfl
  · intro ordinary seed counter state equalState
    rw [← equalState]
    exact ordinary seed counter

/-- The complete one-parameter latch extraction over an arbitrary carrier.
    The hypotheses explicitly supply only equations, reflection, and boundary
    witnesses. No assumption says every element is zero or a successor. -/
theorem latch_gives_induction
    {M : Type u} (zero : M) (successor : M → M)
    (predicate : M → M → Prop)
    (recursor : M → M → M) (body : M → M → M)
    (step : ∀ counter seed,
      recursor (successor counter) seed = body (recursor counter seed) counter)
    (reflection : ∀ state counter parameter,
      body state counter = successor parameter ↔
        state = successor parameter ∧
          (counter = zero ∨ predicate counter parameter))
    (boundary : ∀ seed target, ∃ point,
      recursor (successor point) seed = seed ∧
        (recursor (successor (successor point)) seed = seed → point = target)) :
    ∀ parameter,
      predicate zero parameter →
      (∀ counter, predicate counter parameter → predicate (successor counter) parameter) →
      ∀ counter, predicate counter parameter := by
  intro parameter atZero progress
  let returns : M → Prop := fun counter =>
    recursor (successor counter) (successor parameter) = successor parameter
  have reflects : ∀ counter, returns counter → predicate counter parameter := by
    intro counter returned
    change recursor (successor counter) (successor parameter) =
      successor parameter at returned
    rw [step] at returned
    have alternatives := (reflection _ _ parameter).mp returned
    cases alternatives.2 with
    | inl isZero => exact isZero ▸ atZero
    | inr holds => exact holds
  have returnsProgress : ∀ counter, returns counter → returns (successor counter) := by
    intro counter returned
    have nextTruth := progress counter (reflects counter returned)
    change recursor (successor (successor counter)) (successor parameter) =
      successor parameter
    rw [step]
    change recursor (successor counter) (successor parameter) =
      successor parameter at returned
    rw [returned]
    exact (reflection _ _ parameter).mpr ⟨rfl, Or.inr nextTruth⟩
  have allReturn : ∀ counter, returns counter :=
    boundary_implies_return successor returns (boundary (successor parameter))
      returnsProgress
  intro counter
  exact reflects counter (allReturn counter)

/-- Exact boundary finder used in the paper, defined by primitive recursion
    relative to the supplied test. A successful successor test promotes the
    candidate to the next requested target; a failed test freezes a boundary. -/
def boundaryFinder (returns : Nat → Prop) [DecidablePred returns] : Nat → Nat
  | 0 => 0
  | n + 1 =>
      if returns (boundaryFinder returns n + 1) then n + 1
      else boundaryFinder returns n

/-- The exact paper invariant, proved with ordinary Nat induction. -/
theorem boundaryFinder_invariant
    (returns : Nat → Prop) [DecidablePred returns]
    (atZero : returns 0) :
    ∀ target,
      returns (boundaryFinder returns target) ∧
        (returns (boundaryFinder returns target + 1) →
          boundaryFinder returns target = target) := by
  intro target
  induction target with
  | zero => exact ⟨atZero, fun _ => rfl⟩
  | succ target previous =>
      by_cases nextReturns : returns (boundaryFinder returns target + 1)
      · have candidateIsTarget : boundaryFinder returns target = target :=
          previous.2 nextReturns
        have targetReturns : returns (target + 1) :=
          Eq.mp (congrArg (fun value => returns (value + 1)) candidateIsTarget)
            nextReturns
        have finderEq : boundaryFinder returns (target + 1) = target + 1 := by
          change (if returns (boundaryFinder returns target + 1) then target + 1
            else boundaryFinder returns target) = target + 1
          exact if_pos nextReturns
        exact ⟨Eq.mpr (congrArg returns finderEq) targetReturns, fun _ => finderEq⟩
      · have finderEq : boundaryFinder returns (target + 1) =
            boundaryFinder returns target := by
          change (if returns (boundaryFinder returns target + 1) then target + 1
            else boundaryFinder returns target) = boundaryFinder returns target
          exact if_neg nextReturns
        refine ⟨Eq.mpr (congrArg returns finderEq) previous.1, ?_⟩
        intro impossible
        have oldNextReturns :=
          Eq.mp (congrArg (fun value => returns (value + 1)) finderEq) impossible
        exact False.elim (nextReturns oldNextReturns)

/-- The finder itself supplies the exact boundary sentence in the axioms. -/
theorem nat_boundary_witness
    (returns : Nat → Prop) [DecidablePred returns]
    (atZero : returns 0) :
    ∀ target, ∃ point,
      returns point ∧ (returns (point + 1) → point = target) := by
  intro target
  exact ⟨boundaryFinder returns target,
    boundaryFinder_invariant returns atZero target⟩

#print axioms boundary_implies_return
#print axioms selector_implies_return
#print axioms tail_selector_iff_boundary
#print axioms bound_step_iff
#print axioms latch_gives_induction
#print axioms boundaryFinder_invariant
#print axioms nat_boundary_witness

end BoundaryKernel
