#!/usr/bin/env python3
"""Independent AST audit of the separated PRA emitter.

Counts actual formula trees, including every frozen recursor descriptor in
full mode. This is a finite syntax/comparison test, not a formal proof of
PRA calibration or of the universal comparison theorem.

Only Python's standard library is used. No baseline program is imported.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import json
from pathlib import Path


@dataclass(frozen=True, slots=True)
class Node:
    kind: str
    name: str = ""
    args: tuple["Node", ...] = ()
    descriptor: "Node | None" = None


def var(name):
    return Node("var", name)


ZERO = Node("const", "0")
BOT = Node("bot")
N, A, V, W, B, C, K = map(var, ("n", "a", "v", "w", "b", "c", "k"))


def s(x):
    return Node("fn", "S", (x,))


def chi(x, y):
    return Node("fn", "chi", (x, y))


def r(descriptor, x, y):
    return Node("fn", "R", (x, y), descriptor)


def q(x, y):
    return r(W, x, y)


def z(x, y):
    return r(ZERO, x, y)


def is_r(t, descriptor):
    return t.kind == "fn" and t.name == "R" and t.descriptor == descriptor


def is_s(t):
    return t.kind == "fn" and t.name == "S"


@lru_cache(maxsize=None)
def nf(t):
    if is_r(t, W) and is_s(t.args[0]):
        return nf(t.args[0].args[0])
    return t


def subst(t, bindings):
    """Simultaneous active substitution: descriptor is intentionally frozen."""
    if t.kind == "var":
        return bindings.get(t.name, t)
    if not t.args:
        return t
    return Node(t.kind, t.name, tuple(subst(x, bindings) for x in t.args),
                t.descriptor)


def rec(u, x, y, normalize=True):
    body = subst(nf(u) if normalize else u, {"n": V, "a": W})
    return r(body, x, y)


def pad(t):
    return q(s(t), A)


def pads(t, count):
    for _ in range(count):
        t = pad(t)
    return t


def marked(t):
    return q(z(chi(A, ZERO), s(t)), N)


def outer_marked(t):
    return z(chi(N, ZERO), marked(t))


def rooted(t):
    return z(z(chi(A, ZERO), chi(t, ZERO)), N)


def is_marked(t):
    if not (is_r(t, W) and t.args[1] == N):
        return False
    inner = t.args[0]
    return (is_r(inner, ZERO) and inner.args[0] == chi(A, ZERO)
            and is_s(inner.args[1]))


def is_outer_marked(t):
    return (is_r(t, ZERO) and t.args[0] == chi(N, ZERO)
            and is_marked(t.args[1]))


def is_rooted(t):
    if not (is_r(t, ZERO) and t.args[1] == N):
        return False
    inner = t.args[0]
    if not (is_r(inner, ZERO) and inner.args[0] == chi(A, ZERO)):
        return False
    tail_test = inner.args[1]
    return (tail_test.kind == "fn" and tail_test.name == "chi"
            and tail_test.args[1] == ZERO)


def is_padded_marked(t):
    return (is_r(t, W) and t.args[1] == A and is_s(t.args[0])
            and is_marked(t.args[0].args[0]))


def eq(x, y):
    return Node("eq", args=(x, y))


def conj(x, y):
    return Node("and", args=(x, y))


def disj(x, y):
    return Node("or", args=(x, y))


def imp(x, y):
    return Node("imp", args=(x, y))


def forall(name, body):
    return Node("forall", name, (body,))


def exists(name, body):
    return Node("exists", name, (body,))


def close_an(body):
    return forall("a", forall("n", body))


def seed():
    sep = imp(eq(ZERO, s(ZERO)), BOT)
    bit = conj(eq(chi(A, A), s(ZERO)),
               disj(eq(A, N), eq(chi(A, N), ZERO)))
    return close_an(conj(sep, bit))


def base(u):
    return forall("a", eq(rec(u, ZERO, A), A))


def left(u):
    initial = eq(rec(u, ZERO, A), A)
    update = subst(u, {"n": rec(u, N, A), "a": N})
    step = eq(rec(u, s(N), A), update)
    return close_an(conj(initial, step))


def right(u):
    initial = eq(rec(u, ZERO, A), A)
    update = subst(u, {"n": A, "a": ZERO})
    step = eq(rec(u, s(N), A), rec(u, N, update))
    return close_an(conj(initial, step))


def bound_step_matrix(u):
    update = subst(u, {"n": C, "a": N})
    return forall("c", imp(eq(rec(u, N, A), C),
                            eq(rec(u, s(N), A), update)))


def bound_computation(u):
    return close_an(conj(eq(rec(u, ZERO, A), A), bound_step_matrix(u)))


def bound_step(u):
    return close_an(bound_step_matrix(nf(u)))


def boundary(u):
    matrix = conj(eq(rec(u, s(K), A), A),
                  imp(eq(rec(u, s(s(K)), A), A), eq(K, N)))
    return close_an(exists("k", matrix))


def local_return(u):
    choose = q(z(chi(rec(u, s(s(B)), A), A), s(B)), N)
    return close_an(exists("b", eq(rec(u, s(choose), A), A)))


def rooted_return(u):
    progress = forall("b", imp(eq(rec(u, s(B), A), A),
                               eq(rec(u, s(s(B)), A), A)))
    return close_an(imp(progress, eq(rec(u, s(N), A), A)))


@lru_cache(maxsize=None)
def active(t):
    return 1 + sum(active(x) for x in t.args)


@lru_cache(maxsize=None)
def full(t):
    return (1 + sum(full(x) for x in t.args)
            + (0 if t.descriptor is None else full(t.descriptor)))


@lru_cache(maxsize=None)
def occurrences(t, name):
    return int(t.kind == "var" and t.name == name) + sum(
        occurrences(x, name) for x in t.args)


def sizes(t):
    return active(t), full(t)


def is_autonomous(u):
    return occurrences(u, "n") > 0 and occurrences(u, "a") == 0


OLD_SEED = pad(N)
ROOT_SEED = z(chi(N, ZERO), A)
NEW_SEED = pads(N, 4)


def baseline_rooted(u):
    if u == ROOT_SEED:
        return "seed", seed()
    if is_autonomous(u):
        return "autonomous", right(u)
    if is_rooted(u):
        return "rooted", rooted_return(u)
    if occurrences(u, "n") >= 4:
        return "bound", bound_computation(u)
    return "left", left(u)


def baseline_boundary(u):
    if u == OLD_SEED:
        return "seed", seed()
    if is_autonomous(u):
        return "autonomous", right(u)
    if is_marked(u):
        return "boundary", boundary(u)
    return "left", left(u)


def baseline_local(u, broader=False):
    if u == OLD_SEED:
        return "seed", seed()
    if is_autonomous(u):
        return "autonomous", right(u)
    if is_marked(u) or (broader and is_outer_marked(u)):
        return "local", local_return(u)
    return "left", left(u)


def separated(u):
    if u == NEW_SEED:
        return "seed", seed()
    if is_padded_marked(u):
        return "boundary", boundary(u)
    if nf(u) == u:
        return "base", base(u)
    return "step", bound_step(u)


def adaptive_templates(u):
    """Fourth archive's k=0 adaptive templates, in a common syntactic extension.

    These use RAW descriptors, not normalized scalar ones. Neither comparison
    claims the immutable-parameter grammar equals the binary scalar grammar.
    """
    rr = lambda x, y: rec(u, x, y, normalize=False)
    computation = conj(eq(rr(ZERO, A), A),
                       eq(rr(s(N), A), subst(u, {"n": rr(N, A), "a": N})))
    term_descent = forall("b", eq(subst(u, {"n": B}),
                                  s(subst(u, {"n": s(B)}))))
    orbit_descent = forall("b", eq(rr(B, A), s(rr(s(B), A))))
    return (close_an(conj(computation, imp(term_descent, BOT))),
            close_an(conj(computation, imp(orbit_descent, BOT))))


def serial(t):
    if not t.args:
        return t.name or t.kind
    desc = "" if t.descriptor is None else "{" + serial(t.descriptor) + "}"
    return (t.name or t.kind) + desc + "(" + ",".join(map(serial, t.args)) + ")"


def syntax_fixtures():
    d0 = V
    d1 = chi(V, W)
    d2 = r(d1, s(V), q(W, ZERO))
    d3 = z(chi(r(d2, V, W), s(ZERO)), q(s(W), V))
    d4 = chi(r(d3, V, W), r(d2, q(V, W), s(V)))
    for d in (d0, d1, d2, d3, d4):
        assert nf(d) == d
    return (W, ZERO, d0, d1, d2, d3, d4)


def representative_bodies():
    """Exhaust all active terms <=5 over a fixed staged eight-binary-symbol set.

    Supplement with all marked wrappers on terms <=4, alias-depth probes,
    arbitrary ignored wrapper arguments, and high-occurrence families.
    """
    descs = syntax_fixtures()
    binary = [chi] + [(lambda x, y, d=d: r(d, x, y)) for d in descs]
    by_size = {1: {ZERO, N, A}}
    for size in range(2, 6):
        layer = {s(x) for x in by_size[size - 1]}
        for lhs_size in range(1, size - 1):
            rhs_size = size - 1 - lhs_size
            for lhs in by_size[lhs_size]:
                for rhs in by_size[rhs_size]:
                    for constructor in binary:
                        layer.add(constructor(lhs, rhs))
        by_size[size] = layer
    exhaustive = set().union(*by_size.values())
    probes = set()
    for u in exhaustive:
        probes.update(pads(u, depth) for depth in range(5))
        probes.add(q(s(u), chi(N, s(A))))
    short = set().union(*(by_size[k] for k in range(1, 5)))
    for u in short:
        for shaped in (marked(u), outer_marked(u), rooted(u)):
            probes.add(shaped)
            probes.add(pad(shaped))
            probes.add(pads(shaped, 2))
    repeated = A
    for count in range(1, 17):
        repeated = chi(N, repeated)
        for u in (repeated, marked(repeated), rooted(repeated),
                  q(s(A), repeated), chi(repeated, repeated)):
            probes.update(pads(u, depth) for depth in range(5))
    probes.update((OLD_SEED, ROOT_SEED, NEW_SEED))
    return probes, {str(k): len(v) for k, v in by_size.items()}, len(exhaustive)


def asserted_envelope(u):
    m, w, v = active(u), full(u), full(nf(u))
    i = occurrences(u, "n")
    if u == OLD_SEED:
        return 19, 23
    if u == ROOT_SEED:
        return 20, 25
    if is_autonomous(u):
        return 15 + m, 15 + w + 3 * v
    if is_marked(u):
        return 20, 21 + 2 * w
    if is_outer_marked(u):
        return 20, 22 + 2 * w
    if is_rooted(u):
        return 24, 24 + 3 * w
    if i >= 4:
        return 20 + m, 20 + w + 3 * v
    return 13 + m + 2 * i, 13 + w + 2 * i + (2 + i) * v


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("separated_results.json"))
    args = parser.parse_args()
    bodies, layers, exhaustive_count = representative_bodies()
    branches = Counter()
    baseline_branches = Counter()
    min_saving = [10**9, 10**9]
    min_adaptive_saving = [10**9, 10**9]
    max_descriptor = 0
    all_counted = 0
    for u in bodies:
        branch, new_formula = separated(u)
        new_size = sizes(new_formula)
        branches[branch] += 1
        old_results = (baseline_rooted(u), baseline_boundary(u),
                       baseline_local(u), baseline_local(u, broader=True))
        old_sizes = []
        for name, formula in old_results:
            baseline_branches[name] += 1
            old_sizes.append(sizes(formula))
        envelope = tuple(min(x[j] for x in old_sizes) for j in range(2))
        assert envelope == asserted_envelope(u), (serial(u), envelope,
                                                  asserted_envelope(u))
        assert all(new_size[j] < envelope[j] for j in range(2)), (
            serial(u), branch, new_size, envelope)
        for j in range(2):
            min_saving[j] = min(min_saving[j], envelope[j] - new_size[j])
        h = nf(u)
        expected = {"seed": (25, 25),
                    "boundary": (21, 21 + 2 * full(h)),
                    "base": (6, 6 + full(h)),
                    "step": (14 + active(h), 14 + 3 * full(h))}[branch]
        assert new_size == expected, (serial(u), new_size, expected)
        # Computation witnesses cannot fall into the deleted-computation cases.
        assert separated(h)[0] == "base"
        assert separated(pads(h, 2))[0] == "step"
        assert rec(h, N, A).descriptor == rec(pads(h, 2), N, A).descriptor
        if is_marked(h):
            assert separated(pad(h))[0] == "boundary"
        for formula in adaptive_templates(u):
            cost = sizes(formula)
            assert all(new_size[j] < cost[j] for j in range(2)), (
                "adaptive", serial(u), new_size, cost)
            for j in range(2):
                min_adaptive_saving[j] = min(min_adaptive_saving[j],
                                             cost[j] - new_size[j])
        m, w, i = active(u), full(u), occurrences(u, "n")
        adaptive_sizes = tuple(map(sizes, adaptive_templates(u)))
        assert adaptive_sizes == ((19 + 3*m + 3*i, 19 + (5+i)*w + 3*i),
                                  (26 + m + 2*i, 26 + (5+i)*w + 2*i))
        max_descriptor = max(max_descriptor, full(h))
        all_counted += 7  # new + four scalar baselines + two adaptive profiles
    # Direct checks that active substitution does not enter stored programs.
    original = r(chi(V, W), N, A)
    substituted = subst(original, {"n": s(A), "a": ZERO, "v": ZERO, "w": ZERO})
    assert substituted.descriptor == original.descriptor
    assert substituted.args == (s(A), ZERO)
    # Root-only normalization must leave reducible proper arguments unchanged.
    opaque = chi(pad(N), pad(A))
    assert nf(opaque) == opaque
    assert nf(q(s(opaque), N)) == opaque
    examples = {}
    for label, u in (("zero", ZERO), ("state", N),
                     ("old_boundary_seed", OLD_SEED),
                     ("old_rooted_seed", ROOT_SEED),
                     ("new_seed", NEW_SEED), ("marked_zero", marked(ZERO)),
                     ("padded_marked_zero", pad(marked(ZERO))),
                     ("outer_marked_zero", outer_marked(ZERO)),
                     ("rooted_zero", rooted(ZERO))):
        tag, formula = separated(u)
        examples[label] = {"input": serial(u), "new_branch": tag,
                           "new": sizes(formula),
                           "current_scalar_envelope": asserted_envelope(u),
                           "binary_adaptive_templates": list(map(sizes, adaptive_templates(u)))}
    result = {
        "status": "PASS",
        "scope": "Finite AST verification; not a formal proof of arithmetic or bi-interpretability.",
        "baseline_commit": "53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4",
        "definitions": {"active": "One node per variable, constant, application, equality, connective, falsity, and quantifier.",
                        "full": "Active tree plus every full stored descriptor at every recursor occurrence.",
                        "normalization": "Strip only successive literal Q(S(r),s) roots; frozen descriptions stay unchanged."},
        "exhaustive_active_size_layers": layers,
        "exhaustive_core_bodies": exhaustive_count,
        "total_distinct_bodies": len(bodies),
        "formula_trees_measured_in_both_metrics": all_counted,
        "new_branch_counts": dict(sorted(branches.items())),
        "baseline_branch_counts": dict(sorted(baseline_branches.items())),
        "max_canonical_descriptor_full_size": max_descriptor,
        "minimum_strict_scalar_savings": {"active": min_saving[0], "full": min_saving[1]},
        "minimum_strict_adaptive_savings": {"active": min_adaptive_saving[0], "full": min_adaptive_saving[1]},
        "all_original_base_and_step_recovery_witnesses_checked": True,
        "frozen_substitution_and_root_only_normalization_checked": True,
        "fourth_archive_scope": "Two binary k=0 adaptive templates counted with raw descriptors. This is a matched-template comparison in a common syntactic extension, not a literal comparison with the autonomous primary theory's immutable-seed/parameter grammar.",
        "examples": examples,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ("status", "exhaustive_core_bodies", "total_distinct_bodies", "formula_trees_measured_in_both_metrics", "new_branch_counts", "minimum_strict_scalar_savings")}, indent=2))
    print(f"Results: {args.output.resolve()}")


if __name__ == "__main__":
    main()
