from dataclasses import dataclass
import json
from pathlib import Path

@dataclass(frozen=True)
class Node:
    label: str
    children: tuple = ()
    descriptor: object = None

    def count(self, full=False):
        return 1 + sum(c.count(full) for c in self.children) + (
            self.descriptor.count(True) if full and self.descriptor is not None else 0)

def V(name): return Node(name)
def App(name,*args): return Node(name,args)
def R(h,x,y): return Node('R',(x,y),h)
v,w,a,b,n,z=map(V,('v','w','a','b','n','0'))
def S(x): return App('S',x)
def Q(x,y): return R(w,x,y)
def Z(x,y): return R(z,x,y)
def chi(x,y): return App('chi',x,y)
def substitute(t,env):
    if not t.children: return env.get(t.label,t)
    return Node(t.label,tuple(substitute(c,env) for c in t.children),t.descriptor)
def occurrences(t,name):
    return int(t.label==name and not t.children)+sum(occurrences(c,name) for c in t.children)
def I(t): return Q(Z(chi(w,z),S(t)),v)
def close(form): return App('forall a',App('forall n',App('exists b',form)))
def make(t):
    h=I(t)
    trans=substitute(t,{'v':a,'w':S(b)})
    pick=Q(Z(chi(trans,a),S(b)),n)
    return close(App('=',R(h,S(pick),a),a))

def tailored_boundary(t):
    h=I(t)
    trans=substitute(t,{'v':a,'w':S(b)})
    return close(App('and',App('=',R(h,S(b),a),a),
                     App('implies',App('=',trans,a),App('=',b,n))))

def old_lr(h):
    pick=Q(Z(chi(R(h,S(S(b)),a),a),S(b)),n)
    return close(App('=',R(h,S(pick),a),a))
def old_bw(h):
    return close(App('and',App('=',R(h,S(b),a),a),App('implies',App('=',R(h,S(S(b)),a),a),App('=',b,n))))

examples=[]
for r in range(1,21):
    g=v
    for _ in range(r):g=S(g)
    t=R(g,v,w); h=I(t); new=make(t)
    m=t.count(); Wt=t.count(True); W=h.count(True); j=occurrences(t,'w')
    assert h.count()==m+7 and W==Wt+9
    assert new.count()==15+m+j
    assert new.count(True)==8+2*W+j
    assert tailored_boundary(t).count()==16+m+j
    assert tailored_boundary(t).count(True)==7+2*W+j
    assert old_lr(h).count()==20 and old_lr(h).count(True)==22+2*W
    assert old_bw(h).count()==21 and old_bw(h).count(True)==21+2*W
    examples.append(dict(r=r,tail_active=m,tail_full=Wt,body_full=W,
                         new_active=new.count(),new_full=new.count(True),
                         tailored_boundary_active=tailored_boundary(t).count(),
                         tailored_boundary_full=tailored_boundary(t).count(True),
                         old_coordinate_min_active=20,old_coordinate_min_full=21+2*W))
for t in [v,w,z,S(v),S(w),chi(v,w),R(S(v),v,w),R(S(v),w,w),Q(v,w),Z(v,w),S(S(S(v)))]:
    f=make(t); m=t.count(); j=occurrences(t,'w'); W=I(t).count(True)
    assert (f.count(),f.count(True))==(15+m+j,8+2*W+j)
    c=tailored_boundary(t)
    assert (c.count(),c.count(True))==(16+m+j,7+2*W+j)
result={'scope':'Independent AST counts only; mathematics is in accompanying notes.',
        'status':'PASS','formula':'local active=15+m+j, full=8+2W+j; boundary active=16+m+j, full=7+2W+j','examples':examples}
p=Path(__file__).with_name('one_call_counts.json');p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
