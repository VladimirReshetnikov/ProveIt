#!/usr/bin/env python3
"""Build the paper; optionally reproduce syntax and Lean checks."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks", action="store_true")
    parser.add_argument("--lean", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    verification = root / "verification"
    verification.mkdir(exist_ok=True)
    results = []

    def run(command: list[str], log: Path) -> None:
        result = subprocess.run(command, cwd=root, text=True,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, check=False)
        log.write_text(result.stdout, encoding="utf-8")
        results.append({"command": command, "returncode": result.returncode,
                        "log": str(log.relative_to(root))})
        if result.returncode:
            print(result.stdout[-12000:], file=sys.stderr)
            raise SystemExit(result.returncode)

    if args.checks:
        run([sys.executable, "checks/check_separated_emitter.py"],
            verification / "separated_check_output.txt")
        run([sys.executable, "checks/check_one_call.py"],
            verification / "one_call_check_output.txt")

    if args.lean:
        lean = os.environ.get("LEAN") or shutil.which("lean")
        if not lean:
            raise SystemExit("Install Lean 4.19.0 or set LEAN to its executable path.")
        run([lean, "--version"], root / "formal/lean_version.txt")
        run([lean, "formal/BoundaryKernel.lean"], root / "formal/lean_output.txt")

    latex = shutil.which("pdflatex")
    if not latex:
        raise SystemExit("pdflatex is required to compile the LaTeX source.")
    for number in range(1, 4):
        run([latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            verification / f"latex_pass_{number}.txt")
    (verification / "build_results.json").write_text(json.dumps({
        "status": "PASS",
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "checks_requested": args.checks,
        "lean_requested": args.lean,
        "commands": results,
        "pdf_bytes": (root / "report.pdf").stat().st_size,
    }, indent=2) + "\n", encoding="utf-8")
    print("Built report.pdf successfully.")


if __name__ == "__main__":
    main()
