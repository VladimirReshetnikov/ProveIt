SORT SEPARATION: A SMALLER COMPLETE iPRA PROOF KERNEL
7 November 2026

START HERE
  report.pdf                         Complete mathematical report
  report.tex and sections/            Complete editable LaTeX source
  checker.py                         Primary complete acceptance program
  checker_five_rules.py               Five-primitive-pattern companion

RESULT
The primary measures 411 normalized significant tokens, 428 AST nodes,
and 1,207 normalized UTF-8 bytes. Its core measures 352 / 365 / 957.
The companion measures 416 / 427 / 1,215; its core is 357 / 364 / 965.
Both individually lie strictly below the current complete-program envelope
427 / 436 / 1,246 and the current core envelope 367 / 373 / 979.
The primary wins on tokens and bytes; the companion has one fewer AST node.
These are reproducible CPython 3.12.14 source metrics, not an absolute
minimality theorem or an implementation-independent lower bound.

The snapshot is ProveIt commit:
  5c4724e5550a1b19347ac62c9b02857a7e3fbd19
All six current archives were pinned and checked against their Git blob
hashes. Twelve designated current programs are frozen under comparison/;
an expanded inventory contains 90 distinct complete source programs at
300 archive paths and has the same minimum. Every predecessor archive's
own reproduction suite was also rerun successfully in an isolated copy.

WHAT IS NEW
The primary replaces a separate introduction-constructor test by the
already-required syntax traversal. The first child of an equality is a
numerical term, which cannot be a formula; that attempted introduction
therefore rejects. The same branch supports paired introduction and the
already-derived closure introduction. Adding a derived certificate form
allows a smaller trusted program without adding theorems.

The five-rule fused calculus, positional opening interface, coordinate
representation, and other established implementation idioms are inherited
and credited. The companion substitutes beneath a protected binder directly,
removing a temporary wrapper. The report supplies exact ablations and
distinguishes these contributions from a new arithmetic axiom basis.

MATHEMATICS
One numerical sort; terms 0, successor, variables, and initialized recursion.
Formulas are equality, a numerical closure binder Q, and a paired binder B.
Five primitive inference patterns and two computation schemas suffice.
The primary additionally checks the derived Q-introduction pattern directly.
Full intuitionistic logic, numerical cases, and quantifier-free induction
are derived. An ordinary first-order realization is bi-interpretable with
iPRA on the whole numerical domain; both composite isomorphisms use x=y.
The internal recursion-uniqueness proof includes nonstandard counters.

No new arithmetic breakthrough or globally shortest checker is claimed.
Pure iteration with an arbitrary initializer is a concrete further-research
direction, supported by known extensional generation results but not
certified as a bi-interpretable alternative here. See the final report section.

RUN OFFLINE
  python3 reproduce.py
  python3 checker.py examples/direct_q_reflexivity.json
  python3 checker_five_rules.py examples/direct_q_reflexivity_five_rules.json
  python3 reproduce.py --pdf

Python 3.10+ is needed for the checkers' structural matching. Exact size
receipts use CPython 3.12.14. Rebuilding the PDF needs pdflatex and the
standard packages listed in report.tex. build.py has a temporary-format
fallback for incomplete Debian TeX installations.

Input is a JSON list: its last element is the closed goal, earlier elements
are proof instructions in reverse consumption order. The public context
starts empty. The program prints ACCEPT with exit status 0 or REJECT with
exit status 1. The native term/formula encoding and every instruction are
specified in report.pdf. Canonical raw bound coordinates are odd numbers;
arithmetic one is [0], not the integer token 1.

CORRECTNESS BOUNDARIES
The primary and companion have the same native theorems but different raw
certificate languages. A direct Q-introduction packet can be rejected by
the companion until expanded into its derived three-rule proof.
validation/compile_direct_closure.py performs this expansion for the
documented symbolic proof-tree interface and checks concrete examples.
It is not an unrestricted translator for arbitrary raw JSON packets.

Goals, formula padding, and recursor updates are validated. A substitution
image is validated when used; a wholly unused annotation may be inert and
can be replaced by zero in proof extraction. This is demand validation.
Fresh names, exact integer types, protected binders, and capture avoidance
remain checked. The programs import only json and sys.

Validation and independent named-syntax oracles are untrusted support code.
Tests cover normal execution and -O, source and scope boundaries, proof
translations, and deterministic mutations. Counts overlap and are not counts
of independent theorems. They do not replace the report's proofs, and the
proofs have not been formalized in Lean or Rocq. Finite Python resource limits
can reject sufficiently large otherwise-valid certificates.

CONTENTS
  comparison/                       Frozen sources, metric, provenance
  comparison/expanded/              Supplemental distinct-source inventory
  comparison/ablations/             Intermediate executable implementations
  validation/                       Oracles, fixtures, proof expansion
  examples/                         Concrete accepted certificate entry points
  results/                          Metrics, validation, build and PDF QA receipts
  measure.py, reproduce.py, build.py Offline reproduction
  ATTRIBUTION.txt                    Source lineage and reused support code
  SHA256SUMS.txt                     Checksums of the delivered bundle
