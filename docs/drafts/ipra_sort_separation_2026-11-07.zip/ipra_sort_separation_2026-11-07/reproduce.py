"""Reproduce the pinned measurements and finite validation from any directory."""
import argparse
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', action='store_true', help='rebuild report.pdf after all measurements and validation pass')
    args = parser.parse_args()
    if sys.flags.optimize:
        raise SystemExit('Run reproduce.py without -O; validation tests the checker under -O itself.')
    print('Reproducing with', platform.python_implementation(), platform.python_version(), flush=True)
    if platform.python_implementation() != 'CPython' or platform.python_version() != '3.12.14':
        print('Published exact normalized counts use CPython 3.12.14.', flush=True)
    for name in ('measure.py', 'validation/verify.py', 'validation/compile_direct_closure.py'):
        subprocess.run([sys.executable, '-B', str(ROOT / name)], cwd=ROOT, check=True)
    if args.pdf:
        subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)
    print('PASS: frozen hashes, source measurements, opening oracle, certificates, differential audit and closure expansion.')
    print('See results/metrics.json, results/verification.json and results/closure_expansion.json.')


if __name__ == '__main__':
    main()
