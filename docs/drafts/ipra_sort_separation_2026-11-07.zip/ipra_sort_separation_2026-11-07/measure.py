"""Verify the pinned corpus and reproduce complete-program and core comparisons.

Uses the unchanged upstream source metric; all paths are relative to this file.
Exact published normalization counts use CPython 3.12.14.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT / 'comparison'
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
FIELDS = ('source_tokens', *KEYS, 'raw_bytes')


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def minimum(rows, core=False):
    return {key: min(row['core'][key] if core else row[key] for row in rows)
            for key in (KEYS if core else FIELDS)}


def table(rows, envelope, candidate, companion):
    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete program & Tokens & AST nodes & Bytes\\', r'\midrule']
    for row in rows:
        label = row['label'].replace('_', r'\_').replace('&', r'\&')
        lines.append(label + ' & ' + ' & '.join(str(row[key]) for key in KEYS) + r'\\')
    lines.extend([r'\midrule', 'Componentwise minimum & ' +
                  ' & '.join(str(envelope[key]) for key in KEYS) + r'\\',
                  r'\textbf{Delivered checker} & ' +
                  ' & '.join(r'\textbf{' + str(candidate[key]) + '}' for key in KEYS) + r'\\',
                  r'\bottomrule', r'\end{tabular}'])
    lines.insert(-2, 'Five-rule companion & ' + ' & '.join(str(companion[key]) for key in KEYS) + r'\\')
    return '\n'.join(lines) + '\n'


def main():
    manifest = json.loads((COMPARISON / 'manifest.json').read_text())
    metric_path = COMPARISON / 'source_measure.py'
    require(digest(metric_path) == manifest['measurement_source_sha256'],
            'Changed frozen source metric')
    spec = importlib.util.spec_from_file_location('frozen_source_metric', metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)

    rows = []
    for entry in manifest['programs']:
        path = COMPARISON / entry['local_file']
        require(digest(path) == entry['sha256'], 'Changed comparator: ' + entry['local_file'])
        measured = metric.metrics(path)
        rows.append({key: value for key, value in entry.items() if key != 'metrics'} | measured)
    require(len(rows) == 12, 'Expected the twelve pinned root/alternative programs')
    envelope, core_envelope = minimum(rows), minimum(rows, core=True)

    expanded_manifest = json.loads((COMPARISON / 'expanded_manifest.json').read_text())
    expanded = []
    for entry in expanded_manifest['programs']:
        path = COMPARISON / entry['local_file']
        require(digest(path) == entry['sha256'], 'Changed expanded comparator: ' + entry['local_file'])
        expanded.append({'local_file': entry['local_file'],
                         'original_paths': entry['original_paths']} | metric.metrics(path))
    require(len(expanded) == expanded_manifest['distinct'] == 90,
            'Expected ninety distinct sources in the supplemental inventory')
    require(sum(len(row['original_paths']) for row in expanded) == expanded_manifest['paths'] == 300,
            'Expanded original-path mapping changed')
    expanded_envelope, expanded_core = minimum(expanded), minimum(expanded, core=True)
    require(all(expanded_envelope[key] == envelope[key] for key in KEYS),
            'The expanded whole-program envelope differs; update the report')

    candidate = metric.metrics(ROOT / 'checker.py')
    companion = metric.metrics(ROOT / 'checker_five_rules.py')
    whole_improvement = {key: candidate[key] < envelope[key] for key in KEYS}
    core_improvement = {key: candidate['core'][key] < core_envelope[key] for key in KEYS}
    require(all(whole_improvement.values()), 'The delivered program does not strictly beat every main coordinate')
    require(all(core_improvement.values()), 'The delivered core does not strictly beat every core coordinate')

    companion_whole = {key: companion[key] < envelope[key] for key in KEYS}
    companion_core = {key: companion['core'][key] < core_envelope[key] for key in KEYS}
    require(all(companion_whole.values()), 'The five-rule companion does not beat the whole-program envelope')
    require(all(companion_core.values()), 'The five-rule companion does not beat the core envelope')

    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    ablations = []
    ablation_file = results / 'ablations.json'
    if ablation_file.exists():
        for entry in json.loads(ablation_file.read_text()):
            if entry['file'] in ('checker.py', 'checker_five_rules.py'):
                continue
            path = ROOT / entry['file']
            require(digest(path) == entry['sha256'], 'Changed frozen ablation: ' + entry['file'])
            ablations.append({'file': entry['file']} | metric.metrics(path))
        ablations.append({'file': 'checker_five_rules.py'} | companion)
        ablations.append({'file': 'checker.py'} | candidate)
        ablation_file.write_text(json.dumps(ablations, indent=2) + '\n')

    result = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
        'main_program_count': len(rows), 'expanded_distinct_sources': len(expanded),
        'expanded_original_paths': expanded_manifest['paths'],
        'metric_source_sha256': digest(metric_path),
        'coordinatewise_minimum': envelope, 'core_coordinatewise_minimum': core_envelope,
        'expanded_coordinatewise_minimum': expanded_envelope,
        'expanded_core_coordinatewise_minimum': expanded_core,
        'candidate': candidate, 'companion': companion,
        'strict_companion_whole_improvement': companion_whole,
        'strict_companion_core_improvement': companion_core,
        'strict_whole_improvement': whole_improvement,
        'strict_core_improvement': core_improvement,
        'whole_program_reduction': {key: envelope[key] - candidate[key] for key in KEYS},
        'core_reduction': {key: core_envelope[key] - candidate['core'][key] for key in KEYS},
        'programs': rows, 'expanded_programs': expanded, 'ablations': ablations,
        'scope': 'Finite pinned source comparison; not an absolute minimum theorem. Core excludes imports and CLI by the frozen metric. Supplemental expanded inventory is not an endorsement of every historical implementation.'}
    (results / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    macros = {
        'NewTokens': candidate['normalized_tokens'], 'NewAst': candidate['ast_nodes'],
        'NewBytes': candidate['normalized_bytes'],
        'CoreTokens': candidate['core']['normalized_tokens'],
        'CoreAst': candidate['core']['ast_nodes'], 'CoreBytes': candidate['core']['normalized_bytes']}
    (results / 'numbers.tex').write_text(''.join(
        rf"\newcommand{{\{name}}}{{{value}}}" + "\n" for name, value in macros.items()))
    (results / 'comparison_table.tex').write_text(table(rows, envelope, candidate, companion))
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('programs', 'expanded_programs', 'ablations')}, indent=2))


if __name__ == '__main__':
    main()
