"""Portable finite audit of the delivered checker against frozen independent support.

This file is untrusted verification support, not part of the acceptance kernel.
The opening cohort and adversarial fixtures are adapted from the pinned fused-
binder archive; exact source attribution is in provenance.json and reference/.
"""
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'validation'
REFERENCE = HERE / 'reference'
TARGET = ROOT / 'checker.py'
SEED = 202611071349


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(module, packet):
    """Mirror the public closed-root entry, including malformed top-level JSON."""
    stream = deepcopy(packet)
    module.k = 0
    try:
        module.take = stream.pop
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    try:
        remaining = len(stream)
    except TypeError:
        remaining = None
    return {'accepted': accepted, 'remaining': remaining,
            'final_k': module.k, 'error': error}


def oracle_run(oracle_module, packet):
    try:
        return oracle_module.Oracle().run(packet)
    except (TypeError, AttributeError):
        # The inherited oracle reports len(stack) outside its exception handler.
        # Scalar top-level JSON therefore needs this public-interface adapter.
        return {'accepted': False}


def opening_audit(target, named):
    """Unchanged upstream cohort, with the new variadic opening interface."""
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, True, None, {}]
    terms = [*atoms, [], [0], [1], [5], [0, 0], [0, 0, 1], [0, 0, 3],
             [0, 0, 5], [1, 0, [0, 3, 7]], [0, 0, [0, 1, 9]]]
    formulas = [[t, 0] for t in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 6)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 9], 5]], [0, 0], [0, 0]]]
    environments = [(), (0,), (-1,), (-3,), (1,), ([0],), ([0, 0, 3],),
                    ([0, 0, 5],), (0, [0])]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2):
                for lower in (0, -2):
                    for images in environments:
                        target.k = lower
                        try:
                            actual = target.inst(deepcopy(value), *deepcopy(images),
                                                 d=2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        try:
                            expected = named.opening(deepcopy(value), deepcopy(images),
                                                     formula=formula, depth=depth, lower=lower)
                            expected_valid = True
                        except Exception:
                            expected, expected_valid = None, False
                        require(valid == expected_valid and (not valid or actual == expected),
                                ('opening', value, images, formula, depth, lower, actual, expected))
                        counts['valid' if valid else 'invalid'] += 1
    return dict(counts)


def paths(value, path=()):
    result = [path]
    if type(value) is list:
        for index, child in enumerate(value):
            result.extend(paths(child, (*path, index)))
    return result


def mutate(packet, rng):
    value = deepcopy(packet)
    path = rng.choice(paths(value))
    replacement = deepcopy(rng.choice([
        0, 1, 2, 3, 4, 5, -1, -2, -999, True, False, None, {}, 'x',
        [], [0], [0, 0], [0, 0, 0], [[0], 0, [1]]]))
    if not path:
        return replacement
    parent = value
    for index in path[:-1]:
        parent = parent[index]
    parent[path[-1]] = replacement
    return value


def primary_mutate(value, rng):
    """Exact 15,000-case sort-separation mutation generator from the kernel audit."""
    result = deepcopy(value)
    path = rng.choice(paths(result))
    replacement = rng.choice([None, True, False, 0., 1., -99, -1, 0, 1, 2, 3, 4, 5,
                              [], [0], [0, 0], [0, 0, 0, 0], {}, 'x'])
    if not path:
        return deepcopy(replacement)
    parent = result
    for index in path[:-1]:
        parent = parent[index]
    parent[path[-1]] = deepcopy(replacement)
    return result


def main():
    if sys.flags.optimize:
        raise SystemExit('Run this audit without -O; it tests both checkers under -O itself.')
    provenance = json.loads((HERE / 'provenance.json').read_text())
    for entry in provenance['files']:
        require(digest(ROOT / entry['path']) == entry['sha256'],
                ('changed frozen support', entry['path']))
    checker_paths = {'primary': TARGET, 'five_rules': ROOT / 'checker_five_rules.py'}
    initial_digests = {name: digest(path) for name, path in checker_paths.items()}
    kernels = {name: load(path, 'delivered_' + name) for name, path in checker_paths.items()}
    reference = load(REFERENCE / 'checker_fused.py', 'frozen_fused_checker')
    named = load(REFERENCE / 'named_oracle.py', 'independent_named_oracle')
    extended = load(HERE / 'derived_closure_oracle.py', 'independent_derived_closure_oracle')
    oracles = {'primary': extended, 'five_rules': named}
    opening = {name: opening_audit(kernel, named) for name, kernel in kernels.items()}

    original_fixed = []
    for entry in json.loads((HERE / 'fixtures.json').read_text()):
        path = ROOT / entry['path']
        require(digest(path) == entry['sha256'], ('changed frozen fixture', entry['path']))
        original_fixed.append((entry, json.loads(path.read_text())))
    new_fixed = []
    for entry in json.loads((HERE / 'derived_closure_fixtures.json').read_text()):
        path = ROOT / entry['path']
        require(digest(path) == entry['sha256'], ('changed new fixture', entry['path']))
        new_fixed.append((entry, json.loads(path.read_text())))
    all_fixed = [
        (entry, packet, {'primary': entry['expected'], 'five_rules': entry['expected']}, True)
        for entry, packet in original_fixed]
    all_fixed += [
        (entry, packet, {'primary': entry['expected_primary'],
                         'five_rules': entry['expected_five_rules']}, False)
        for entry, packet in new_fixed]

    fixed_rows, cli_count = [], 0
    with tempfile.TemporaryDirectory(prefix='ipra-kernel-audit-') as temporary:
        packet_path = Path(temporary) / 'packet.json'
        for entry, packet, expectations, original in all_fixed:
            name = entry['name']
            baseline = run(reference, packet)
            require(baseline['accepted'] == expectations['five_rules'],
                    ('frozen fixed verdict', name, baseline, expectations))
            verdicts = {}
            packet_path.write_text(json.dumps(packet))
            for key, kernel in kernels.items():
                actual = run(kernel, packet)
                oracle = oracle_run(oracles[key], packet)
                require(oracle['accepted'] == actual['accepted'] == expectations[key],
                        ('fixed verdict', key, name, oracle, actual, expectations))
                # The old corpus is unchanged in both implementations. The strict
                # five-rule companion remains packet-equivalent to the reference.
                if original or key == 'five_rules':
                    for field in ('remaining', 'final_k'):
                        require(actual[field] == baseline[field],
                                ('fixed execution', key, name, field, baseline, actual))
                for optimized in (False, True):
                    command = [sys.executable, *(['-O'] if optimized else []),
                               str(checker_paths[key]), str(packet_path)]
                    result = subprocess.run(command, capture_output=True, text=True, timeout=10)
                    required = (0, 'ACCEPT', '') if expectations[key] else (1, 'REJECT', '')
                    require((result.returncode, result.stdout.strip(), result.stderr) == required,
                            ('CLI', key, name, optimized, result.returncode, result.stdout, result.stderr))
                    cli_count += 1
                verdicts[key] = {'actual': actual, 'named_oracle': oracle}
            fixed_rows.append({'name': name, 'category': entry['category'],
                               'expected': expectations, 'verdicts': verdicts,
                               'reference': baseline})

    minimal_rows = []
    for entry in json.loads((HERE / 'minimal_examples.json').read_text()):
        path = ROOT / entry['path']
        require(digest(path) == entry['sha256'], ('changed minimal example', entry['path']))
        packet = json.loads(path.read_text())
        verdicts = {}
        for key, kernel in kernels.items():
            actual = run(kernel, packet)
            oracle = oracle_run(oracles[key], packet)
            require(actual['accepted'] == oracle['accepted'] == entry['expected'],
                    ('minimal example', key, entry['path'], actual, oracle))
            verdicts[key] = actual['accepted']
        minimal_rows.append({'path': entry['path'], 'accepted': verdicts})

    # The five-rule companion is tested for exact packet behavior against the
    # frozen five-rule reference. This claim is deliberately not made for the
    # primary, which adds certificates for the already-derived Q introduction.
    rng = random.Random(SEED)
    companion_mutations = []
    for _ in range(3000):
        changed = mutate(rng.choice(original_fixed)[1], rng)
        if rng.randrange(3) == 0:
            changed = mutate(changed, rng)
        companion_mutations.append(changed)
    companion_accepted = 0
    for index, packet in enumerate(companion_mutations):
        baseline = run(reference, packet)
        actual = run(kernels['five_rules'], packet)
        oracle = oracle_run(named, packet)
        require(oracle['accepted'] == baseline['accepted'],
                ('companion mutation oracle', index, packet, oracle, baseline))
        for field in ('accepted', 'remaining', 'final_k'):
            require(actual[field] == baseline[field],
                    ('companion mutation execution', index, field, packet, actual, baseline))
        companion_accepted += actual['accepted']

    # Reproduce the kernel researcher's exact 43+19, seed-11072026 mutation
    # cohort. The independent oracle explicitly recognizes Q introduction;
    # it does not reuse the production first-child projection or packed table.
    primary_sources = [(entry, packet) for entry, packet in original_fixed
                       if entry['name'].startswith('declared/')] + new_fixed
    require(len(primary_sources) == 62, 'The inherited 43+19 mutation cohort changed')
    primary_seed = 11072026
    rng = random.Random(primary_seed)
    primary_hashes, primary_accepted = set(), 0
    for index in range(15000):
        packet = primary_mutate(primary_sources[index % len(primary_sources)][1], rng)
        actual = run(kernels['primary'], packet)
        oracle = oracle_run(extended, packet)
        require(actual['accepted'] == oracle['accepted'],
                ('primary mutation verdict', index, packet, actual, oracle))
        primary_accepted += actual['accepted']
        primary_hashes.add(hashlib.sha256(json.dumps(packet, sort_keys=True).encode()).hexdigest())
    for key, path in checker_paths.items():
        require(digest(path) == initial_digests[key],
                key + ' changed during validation; rerun the audit')

    result = {
        'status': 'PASS', 'python': platform.python_version(),
        'candidate_sha256': initial_digests['primary'],
        'companion_sha256': initial_digests['five_rules'],
        'reference_sha256': digest(REFERENCE / 'checker_fused.py'),
        'named_oracle_sha256': digest(REFERENCE / 'named_oracle.py'),
        'derived_closure_oracle_sha256': digest(HERE / 'derived_closure_oracle.py'),
        'frozen_support_files_verified': len(provenance['files']),
        'transported_closed_theorems': sum(e['category'] == 'transported theorem' for e, _ in original_fixed),
        'original_boundary_cases': sum(e['category'] == 'boundary' for e, _ in original_fixed),
        'new_derived_closure_boundary_cases': len(new_fixed),
        'fixed_packets': len(all_fixed),
        'opening_oracle_per_checker': opening,
        'opening_comparisons_per_checker': {key: sum(value.values()) for key, value in opening.items()},
        'actual_cli_runs': cli_count,
        'minimal_example_files_checked': len(minimal_rows),
        'primary_mutation_seed': primary_seed,
        'primary_mutation_packets': 15000,
        'primary_distinct_mutation_packets': len(primary_hashes),
        'primary_accepted_mutation_packets': primary_accepted,
        'companion_mutation_seed': SEED,
        'companion_mutation_packets': len(companion_mutations),
        'companion_distinct_mutation_packets': len({json.dumps(p, sort_keys=True) for p in companion_mutations}),
        'companion_accepted_mutation_packets': companion_accepted,
        'packet_equivalence_scope': 'The five-rule companion is compared with the frozen five-rule checker. The primary is compared with an independent oracle extended by derived unary closure introduction; it intentionally accepts additional raw certificates.',
        'limitations': 'Finite regression, differential execution and independent named-syntax checks; not a mechanized soundness, consistency or bi-interpretability proof. Cohorts may overlap.'}
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    (results / 'verification_fixed_cases.json').write_text(json.dumps(fixed_rows, indent=2) + '\n')
    (results / 'verification_minimal_examples.json').write_text(json.dumps(minimal_rows, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
