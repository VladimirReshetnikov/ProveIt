"""Independent explicit derived-Q extension of the unchanged named-binder oracle.

The production checker discovers the Q/D distinction by sorted parsing of a
projected singleton. This oracle instead dispatches explicitly on a unary
closure goal, then uses the inherited ordinary named-binder operations.
It is untrusted test support, never imported by either acceptance program.
Adapted from notes/kernel/audit_sortseparation_auto.py during this report.
"""
from copy import deepcopy
import importlib.util
from pathlib import Path

path = Path(__file__).resolve().parent / 'reference/named_oracle.py'
spec = importlib.util.spec_from_file_location('frozen_named_for_derived_closure', path)
named = importlib.util.module_from_spec(spec)
spec.loader.exec_module(named)


class Oracle(named.Oracle):
    def check(self, goal, context):
        self.open(goal)
        if goal in context:
            self.rule('hypothesis')
            return True
        if (len(goal) == 1 and self.stack and type(self.stack[-1]) is list
                and len(self.stack[-1]) == 1):
            self.stack.pop()  # its single entry is semantically unused
            self.rule('derived_closure_introduction')
            body = deepcopy(goal[0])
            assumptions = [self.open(body, [0])]
            if len(body) == 2:
                assumptions.append(body)
            eigen = self.fresh([goal, *context])
            premises = [self.open(value, [eigen]) for value in assumptions]
            return self.check(self.open(body, [[eigen]]), [*context, *premises])
        return super().check(goal, context)
