"""Untrusted accepted-execution recorder for the frozen paired Q/E checkers.

The acceptance kernel never imports this module.  We first record an accepted
source execution, including failed-major fallback effects, then emit a new
derivation.  Already available assumptions prune complete subtrees.  Scoped
eigenparameters are renamed at their declarations.  Parameters of the public
goal and supplied external context are fixed; other free auxiliary parameters
are uniformly specialized to zero.  The latter prevents a later auxiliary
name from colliding with an earlier eigenname after pruning changes allocation.

"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
import importlib.util
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_kernel(path, name):
    spec = importlib.util.spec_from_file_location(name, Path(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_kernel(module, certificate, context=()):
    """Run exactly the public proof logic, with an explicitly checked context."""
    stream = deepcopy(certificate)
    module.k = 0
    module.take = stream.pop
    try:
        for formula in context:
            module.inst(formula)
        accepted = bool(module.check(stream.pop(), deepcopy(list(context))))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {"accepted": accepted, "remaining": len(stream),
            "final_k": module.k, "error": error}


def negative_parameters(value):
    if type(value) is int:
        return {value} if value < 0 else set()
    if type(value) is list:
        return set().union(*(negative_parameters(x) for x in value))
    if type(value) is dict:
        return set().union(*(negative_parameters(x) for x in value.values()))
    return set()


@dataclass
class Node:
    goal: object
    cell: object
    kind: str
    accepted: bool = False
    children: list = field(default_factory=list)
    eigen: int | None = None
    consumed: int = 0
    failed_major: bool = False


class SourceRecorder:
    """Explicit replay of the frozen source; compared with its real execution."""
    def __init__(self, module, certificate, context):
        self.module = module
        self.stream = deepcopy(certificate)
        self.goal = self.stream.pop()
        self.context = deepcopy(list(context))
        self.calls = 0
        self.failed_major_fallbacks = 0
        self.allocations = []
        module.k = 0
        for formula in context:
            module.inst(formula)

    def check(self, goal, context):
        self.calls += 1
        before = len(self.stream)
        m = self.module
        m.inst(goal)
        cell = self.stream.pop()
        node = Node(deepcopy(goal), deepcopy(cell), "hyp")

        def finish(accepted):
            node.accepted = bool(accepted)
            node.consumed = before - len(self.stream)
            return node

        def scoped(body, assumptions, kind):
            node.kind = kind
            m.k -= 1
            node.eigen = m.k
            self.allocations.append(m.k)
            child_goal = m.inst(body, [[m.k]])
            child_context = context + [m.inst(c, [m.k]) for c in assumptions]
            child = self.check(child_goal, child_context)
            node.children.append(child)
            return finish(child.accepted)

        if type(cell) is list and len(cell) == 2:
            major, annotation = cell
            major_node = self.check(major, context)
            if major_node.accepted:
                node.children.append(major_node)
                if len(major) == 3:
                    return scoped(goal, major[:1], "ex_elim")
                if len(major) == 1:
                    body, endpoints = major[0], [0, annotation]
                    node.kind = "q_elim"
                else:
                    body, endpoints = annotation, major
                    node.kind = "eq_elim"
                premise, result = (m.inst(body, [v]) for v in endpoints)
                if result != goal:
                    return finish(False)
                child = self.check(premise, context)
                node.children.append(child)
                return finish(child.accepted)
            node.failed_major = True
            self.failed_major_fallbacks += 1
            # The failed execution consumed cells and changed k.  It is not
            # an accepted proof premise and is deliberately omitted here.
            return finish(goal in context)

        if cell == [] and type(cell) is list and len(goal) == 1:
            body = goal[0]
            assumptions = [m.inst(body, [0]), body][:2 - len(body) % 2]
            return scoped(body, assumptions, "q_intro")

        if type(cell) is list and len(cell) == 1 and len(goal) == 3:
            node.kind = "ex_intro"
            child = self.check(m.inst(goal[0], [cell[0]]), context)
            node.children.append(child)
            return finish(child.accepted)

        if (cell == [] and type(cell) is list and len(goal) == 2
                and type(goal[0]) is list and len(goal[0]) == 3):
            node.kind = "compute"
            n, initial, update = goal[0]
            if n:
                n, = n
                initial = m.inst(update, ([n, initial, update], n), d=1)
            return finish(goal[1] == initial)

        return finish(goal in context)

