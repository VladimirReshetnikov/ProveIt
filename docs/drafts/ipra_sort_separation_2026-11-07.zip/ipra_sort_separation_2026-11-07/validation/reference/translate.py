"""Untrusted proof translation from the frozen Q/E calculus to fused Q/D.

D(x,y,B) means exists x Q_y B. Numerical variables in semantic syntax have
globally fresh names. Raw coordinates are produced only by the final emitter.
The source proof is recorded by the inspected upstream execution recorder;
the target proof is constructed by explicit rule derivations, then checked by
the independent target program. This compiler is outside the trust boundary.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass
import importlib.util
import itertools
import json
from pathlib import Path

from source_trace import SourceRecorder, run_kernel, load_kernel, require, negative_parameters

ROOT = Path(__file__).resolve().parent
serial = itertools.count()


def fresh():
    return 'v' + str(next(serial))


def S(t):
    return ('s', t)


def R(n, a, u, v, h):
    return ('r', n, a, u, v, h)


def Eq(s, t):
    return ('=', s, t)


def Q(x, b):
    return ('q', x, b)


def D(x, y, b):
    return ('d', x, y, b)


T = Eq(0, 0)


def term_key(t, bound=()):
    if t == 0:
        return 0
    if isinstance(t, str):
        return ('bound', bound.index(t)) if t in bound else ('free', t)
    if t[0] == 's':
        return ('s', term_key(t[1], bound))
    _, n, a, u, v, h = t
    return ('r', term_key(n, bound), term_key(a, bound),
            term_key(h, (u, v) + bound))


def key(a, bound=()):
    tag = a[0]
    if tag == '=':
        return ('=', term_key(a[1], bound), term_key(a[2], bound))
    if tag in ('q', 'e'):
        return (tag, key(a[2], (a[1],) + bound))
    return ('d', key(a[3], (a[2], a[1]) + bound))


def same(a, b):
    return key(a) == key(b)


def st(t, variable, image):
    if t == variable:
        return image
    if t == 0 or isinstance(t, str):
        return t
    if t[0] == 's':
        return S(st(t[1], variable, image))
    _, n, a, u, v, h = t
    return R(st(n, variable, image), st(a, variable, image), u, v,
             h if variable in (u, v) else st(h, variable, image))


def sf(a, variable, image):
    tag = a[0]
    if tag == '=':
        return Eq(st(a[1], variable, image), st(a[2], variable, image))
    if tag in ('q', 'e'):
        return a if variable == a[1] else (tag, a[1], sf(a[2], variable, image))
    return a if variable in a[1:3] else D(a[1], a[2], sf(a[3], variable, image))


def instances(a, pairs):
    for variable, image in pairs:
        a = sf(a, variable, image)
    return a


def parse_term(raw, scope, bound=(), holes=()):
    if type(raw) is int:
        if raw == 0:
            return 0
        if raw < 0:
            # Parameters outside retained source scopes are uniformly
            # specialized to zero, as in the inspected upstream transporter.
            return scope.get(raw, 0)
        index = (raw + 1) // 2 - 1
        if index < len(bound):
            return bound[index]
        return holes[index - len(bound)]
    if type(raw) is not list:
        raise ValueError('invalid source term')
    if len(raw) == 1:
        return S(parse_term(raw[0], scope, bound, holes))
    if len(raw) == 3:
        u, v = fresh(), fresh()
        return R(parse_term(raw[0], scope, bound, holes),
                 parse_term(raw[1], scope, bound, holes), u, v,
                 parse_term(raw[2], scope, (u, v) + bound, holes))
    raise ValueError('invalid source term arity')


def parse_formula(raw, scope, bound=(), holes=()):
    if type(raw) is not list:
        raise ValueError('invalid source formula')
    if len(raw) == 2:
        return Eq(*(parse_term(x, scope, bound, holes) for x in raw))
    if len(raw) in (1, 3):
        x = fresh()
        return ('q' if len(raw) == 1 else 'e', x,
                parse_formula(raw[0], scope, (x,) + bound, holes))
    raise ValueError('invalid source formula arity')


def witness(raw, scope):
    try:
        return parse_term(raw, scope)
    except (ValueError, IndexError):
        # The source accepts malformed annotations only when never used.
        # The surrounding proof construction checks the resulting premises.
        return 0


def selector(z, a, b):
    u, v = fresh(), fresh()
    return R(z, a, u, v, b)


def gate(a, z):
    tag = a[0]
    if tag == '=':
        return Eq(selector(z, 0, a[1]), selector(z, 0, a[2]))
    if tag == 'q':
        return Q(a[1], gate(a[2], z))
    if tag == 'd':
        return D(a[1], a[2], gate(a[3], z))
    raise ValueError('gate requires a target formula')


def translate_formula(a):
    tag = a[0]
    if tag == '=':
        return a
    if tag == 'q':
        return Q(a[1], translate_formula(a[2]))
    if tag == 'e':
        y = fresh()
        return D(a[1], y, gate(translate_formula(a[2]), y))
    raise ValueError('unknown source formula')


@dataclass
class Proof:
    goal: tuple
    rule: str
    data: tuple = ()
    children: tuple = ()


def hyp(a):
    return Proof(a, 'hyp')


def comp(left, right):
    return Proof(Eq(left, right), 'compute')


def eq_elim(major, variable, matrix, minor):
    require(major.goal[0] == '=', 'equality major is not an equation')
    left, right = major.goal[1:]
    require(same(sf(matrix, variable, left), minor.goal),
            'equality motive has wrong minor premise')
    return Proof(sf(matrix, variable, right), 'eq_elim', (variable, matrix),
                 (major, minor))


def refl(t):
    u, v, x = fresh(), fresh(), fresh()
    r = R(0, t, u, v, 0)
    p = comp(r, t)
    return eq_elim(p, x, Eq(x, t), p)


def sym(p):
    x = fresh()
    return eq_elim(p, x, Eq(x, p.goal[1]), refl(p.goal[1]))


def trans(p, q):
    require(term_key(p.goal[2]) == term_key(q.goal[1]),
            'transitivity middle terms differ')
    x = fresh()
    return eq_elim(q, x, Eq(p.goal[1], x), p)


def q_elim(major, term, minor):
    require(major.goal[0] == 'q', 'Q major has wrong shape')
    _, x, b = major.goal
    require(same(sf(b, x, 0), minor.goal), 'Q elimination has wrong base')
    return Proof(sf(b, x, term), 'q_elim', (term,), (major, minor))


def d_intro(goal, term, eigen, step):
    require(goal[0] == 'd', 'D introduction has wrong goal')
    _, x, y, b = goal
    expected = instances(b, [(x, term), (y, S(eigen))])
    require(same(expected, step.goal), 'D introduction has wrong step')
    return Proof(goal, 'd_intro', (term, eigen), (step,))


def d_elim(major, eigen, minor):
    require(major.goal[0] == 'd', 'D elimination has wrong major')
    return Proof(minor.goal, 'd_elim', (eigen,), (major, minor))


def q_intro(goal, eigen, step):
    require(goal[0] == 'q', 'derived Q introduction has wrong goal')
    _, y, b = goal
    dummy, discarded = fresh(), fresh()
    major = d_intro(D(dummy, y, b), 0, eigen, step)
    return d_elim(major, discarded, hyp(goal))


def gate_zero(a):
    if a[0] == '=':
        left, right = gate(a, 0)[1:]
        return trans(comp(left, 0), sym(comp(right, 0)))
    if a[0] == 'q':
        eigen = fresh()
        return q_intro(gate(a, 0), eigen, gate_zero(sf(a[2], a[1], S(eigen))))
    if a[0] == 'd':
        eigen = fresh()
        b = instances(a[3], [(a[1], 0), (a[2], S(eigen))])
        return d_intro(gate(a, 0), 0, eigen, gate_zero(b))
    raise ValueError('unknown target formula in zero gate')


def gate_convert(p, a, z, up):
    """A -> G_z A (up), or G_z A -> A, for z literally a successor."""
    require(isinstance(z, tuple) and z[0] == 's', 'gate endpoint is not successor')
    require(same(p.goal, a if up else gate(a, z)), 'gate source differs')
    target = gate(a, z) if up else a
    if a[0] == '=':
        left, right = gate(a, z)[1:]
        lp, rp = comp(left, a[1]), comp(right, a[2])
        return trans(trans(lp, p), sym(rp)) if up else trans(trans(sym(lp), p), rp)
    if a[0] == 'q':
        eigen = fresh()
        target_base = sf(target[2], target[1], 0)
        original_base = sf(a[2], a[1], 0)
        source_base = gate_convert(hyp(target_base), original_base, z, not up)
        source_step = q_elim(p, S(eigen), source_base)
        step = gate_convert(source_step, sf(a[2], a[1], S(eigen)), z, up)
        return q_intro(target, eigen, step)
    if a[0] == 'd':
        chosen, eigen = fresh(), fresh()
        _, sx, sy, sb = p.goal
        source_closure = Q(sy, sf(sb, sx, chosen))
        target_base = instances(target[3], [(target[1], chosen), (target[2], 0)])
        original_base = instances(a[3], [(a[1], chosen), (a[2], 0)])
        source_base = gate_convert(hyp(target_base), original_base, z, not up)
        source_step = q_elim(hyp(source_closure), S(eigen), source_base)
        original_step = instances(a[3], [(a[1], chosen), (a[2], S(eigen))])
        step = gate_convert(source_step, original_step, z, up)
        minor = d_intro(target, chosen, eigen, step)
        return d_elim(p, chosen, minor)
    raise ValueError('unknown target formula in gate conversion')


def compile_source(node, scope=None, assumptions=()):
    scope = {} if scope is None else scope
    original = parse_formula(node.goal, scope)
    wanted = translate_formula(original)
    kind = node.kind
    if kind == 'hyp':
        for source, proof in reversed(assumptions):
            if same(source, original):
                require(same(proof.goal, wanted), 'hypothesis translation differs')
                return proof
        raise ValueError('source hypothesis missing from translated context')
    if kind == 'compute':
        return comp(*wanted[1:])
    if kind == 'q_intro':
        _, x, b = original
        eigen = fresh()
        extra = [(sf(b, x, 0), hyp(translate_formula(sf(b, x, 0))))]
        if b[0] == '=':
            extra.append((sf(b, x, eigen), hyp(translate_formula(sf(b, x, eigen)))))
        new_scope = {**scope, node.eigen: eigen}
        step = compile_source(node.children[0], new_scope, (*assumptions, *extra))
        result = q_intro(wanted, eigen, step)
    elif kind == 'ex_intro':
        term = witness(node.cell[0], scope)
        source_proof = compile_source(node.children[0], scope, assumptions)
        a = translate_formula(sf(original[2], original[1], term))
        require(same(a, source_proof.goal), 'existential source premise differs')
        eigen = fresh()
        step = gate_convert(source_proof, a, S(eigen), True)
        result = d_intro(wanted, term, eigen, step)
    elif kind == 'q_elim':
        major = compile_source(node.children[0], scope, assumptions)
        minor = compile_source(node.children[1], scope, assumptions)
        result = q_elim(major, witness(node.cell[1], scope), minor)
    elif kind == 'eq_elim':
        major = compile_source(node.children[0], scope, assumptions)
        minor = compile_source(node.children[1], scope, assumptions)
        variable = fresh()
        matrix = translate_formula(parse_formula(node.cell[1], scope, holes=(variable,)))
        result = eq_elim(major, variable, matrix, minor)
    elif kind == 'ex_elim':
        major = compile_source(node.children[0], scope, assumptions)
        old_major = parse_formula(node.cell[0], scope)
        chosen = fresh()
        assumption = sf(old_major[2], old_major[1], chosen)
        a = translate_formula(assumption)
        _, dx, dy, db = major.goal
        closure = Q(dy, sf(db, dx, chosen))
        gated = q_elim(hyp(closure), S(0), gate_zero(a))
        extracted = gate_convert(gated, a, S(0), False)
        new_scope = {**scope, node.eigen: chosen}
        minor = compile_source(node.children[1], new_scope,
                               (*assumptions, (assumption, extracted)))
        result = d_elim(major, chosen, minor)
    else:
        raise ValueError('unknown source rule: ' + kind)
    require(same(result.goal, wanted), ('translated conclusion differs', kind))
    return result


def raw_term(t, scope, bound=()):
    if t == 0:
        return 0
    if isinstance(t, str):
        return 2 * bound.index(t) + 1 if t in bound else scope[t]
    if t[0] == 's':
        return [raw_term(t[1], scope, bound)]
    _, n, a, u, v, h = t
    return [raw_term(n, scope, bound), raw_term(a, scope, bound),
            raw_term(h, scope, (u, v) + bound)]


def raw_formula(a, scope, bound=()):
    tag = a[0]
    if tag == '=':
        return [raw_term(a[1], scope, bound), raw_term(a[2], scope, bound)]
    if tag == 'q':
        return [raw_formula(a[2], scope, (a[1],) + bound)]
    if tag == 'd':
        return [raw_formula(a[3], scope, (a[2], a[1]) + bound), [0, 0], [0, 0]]
    raise ValueError('source existential left in target')


class Emitter:
    def __init__(self, initial_scope=None):
        self.initial_scope = {} if initial_scope is None else initial_scope
        self.initial_k = min((0, *self.initial_scope.values()))
        self.k = self.initial_k
        self.cells = []
        self.rule_counts = {}
        self.pruned = 0

    def emit(self, proof, context=(), scope=None):
        scope = {} if scope is None else scope
        goal = raw_formula(proof.goal, scope)
        if goal in context:
            self.pruned += 1
            return
        rule = proof.rule
        self.rule_counts[rule] = self.rule_counts.get(rule, 0) + 1
        if rule == 'hyp':
            raise ValueError('target hypothesis absent from actual context')
        if rule == 'compute':
            self.cells.append([])
        elif rule in ('eq_elim', 'q_elim'):
            major, minor = proof.children
            if rule == 'eq_elim':
                variable, matrix = proof.data
                annotation = raw_formula(matrix, scope, (variable,))
            else:
                annotation = raw_term(proof.data[0], scope)
            self.cells.append([raw_formula(major.goal, scope), annotation])
            self.emit(major, context, scope)
            self.emit(minor, context, scope)
        elif rule == 'd_intro':
            term, eigen = proof.data
            self.cells.append([raw_term(term, scope)])
            self.k -= 1
            local = {**scope, eigen: self.k}
            _, x, y, b = proof.goal
            base = instances(b, [(x, term), (y, 0)])
            added = [raw_formula(base, local)]
            if b[0] == '=':
                added.append(raw_formula(instances(b, [(x, term), (y, eigen)]), local))
            self.emit(proof.children[0], (*context, *added), local)
        elif rule == 'd_elim':
            major, minor = proof.children
            self.cells.append([raw_formula(major.goal, scope), None])
            self.emit(major, context, scope)
            self.k -= 1
            eigen, = proof.data
            local = {**scope, eigen: self.k}
            _, x, y, b = major.goal
            assumption = Q(y, sf(b, x, eigen))
            self.emit(minor, (*context, raw_formula(assumption, local)), local)
        else:
            raise ValueError('unknown target proof rule: ' + rule)

    def packet(self, proof):
        self.emit(proof, scope=self.initial_scope)
        return self.cells[::-1] + [raw_formula(proof.goal, self.initial_scope)]


def run_target(module, packet, header=False):
    stream = deepcopy(packet)
    module.k = -len(stream.pop()) if header else 0
    module.take = stream.pop
    try:
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'remaining': len(stream),
            'final_k': module.k, 'error': error}


def transport(packet, target_path, *, source_path=None,
              preserve_parameters=False, header=False):
    source = load_kernel(source_path or ROOT / 'source_checker.py', 'frozen_paired_source')
    direct = run_kernel(source, packet)
    require(direct['accepted'], 'frozen paired source rejects input')
    record = SourceRecorder(source, packet, [])
    tree = record.check(record.goal, [])
    require(tree.accepted and len(record.stream) == direct['remaining']
            and source.k == direct['final_k'], 'source trace replay mismatch')
    source_scope = {n: fresh() for n in sorted(negative_parameters(tree.goal), reverse=True)} \
        if preserve_parameters else {}
    target_scope = {name: -i for i, name in enumerate(source_scope.values(), 1)}
    proof = compile_source(tree, source_scope)
    emitter = Emitter(target_scope)
    result = emitter.packet(proof)
    if header:
        result.append([None] * len(source_scope))
    target = load_kernel(target_path, 'fused_target')
    checked = run_target(target, result, header)
    require(checked['accepted'] and checked['remaining'] == 0,
            ('fused target rejects translated proof', checked))
    require(checked['final_k'] == emitter.k, 'emitter and kernel allocations differ')
    return result, {'source_cells': tree.consumed,
                    'target_cells': len(result) - 1 - int(header),
                    'source_calls': record.calls,
                    'source_eigenparameters': len(record.allocations),
                    'target_eigenparameters': emitter.initial_k - emitter.k,
                    'root_parameter_renaming': {n: target_scope[name]
                                                for n, name in source_scope.items()},
                    'header': header,
                    'target_rules': emitter.rule_counts,
                    'pruned_target_subtrees': emitter.pruned,
                    'target_run': checked}


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    parser.add_argument('--checker', type=Path, required=True)
    args = parser.parse_args()
    output, report = transport(json.loads(args.source.read_text()), args.checker)
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    args.destination.write_text(json.dumps(output, separators=(',', ':')) + '\n')
    print(json.dumps(report, indent=2))
