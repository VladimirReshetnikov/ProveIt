FROZEN VALIDATION SUPPORT

These files are unchanged from ipra_fused_binder_2026-11-07.zip in
ProveIt/docs/drafts at commit 5c4724e5550a1b19347ac62c9b02857a7e3fbd19.
validation/provenance.json gives exact original paths and SHA-256 hashes.

checker_fused.py is the reference five-rule closed-root acceptance program.
named_oracle.py independently parses explicit named binders and interprets
the rules without the production packed sort/depth or grammar table.
The remaining source/translation modules preserve the upstream provenance
and permit inspection of how the inherited proof fixtures were built.
Only named_oracle.py and checker_fused.py are used by the standard audit.

No file in this directory is imported by the delivered acceptance checker.
This is untrusted test support. Finite tests do not prove soundness or
consistency. The source license is included unchanged.
