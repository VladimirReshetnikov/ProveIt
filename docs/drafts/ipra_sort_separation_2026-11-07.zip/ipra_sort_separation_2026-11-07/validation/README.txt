PORTABLE VALIDATION
===================

From any directory:
  python3 /path/to/package/validation/verify.py

From the package root:
  python3 reproduce.py
  python3 reproduce.py --pdf

The second command also rebuilds the PDF after all verification passes.
Neither acceptance program imports any validation module.

FROZEN SUPPORT AND CORPORA
-------------------------
reference/ contains unchanged upstream copies of the five-rule checker,
independent named-syntax oracle, and original proof-translation support.
provenance.json records their SHA-256 hashes and original archive paths.
fixtures.json lists the 45 inherited closed theorem packets and 29 boundary
controls; all copied packets retain their exact source bytes and hashes.
derived_closure_fixtures.json lists 19 controls for the primary's additional
certificate form, sort separation, freshness, and capture rejection.
minimal_examples.json records four small illustrative proof files.

TWO CERTIFICATE LANGUAGES
------------------------
checker_five_rules.py preserves the frozen five-rule packet language.
checker.py also accepts direct certificates for a closure-introduction rule
that is derived in the five-rule calculus. This changes raw acceptance but
not the mathematical consequence relation.

Accordingly, the primary is compared with derived_closure_oracle.py, which
explicitly recognizes unary closure introduction on top of the unchanged
named-binder oracle. This independent oracle does not use the production
first-child projection or its packed sort/depth grammar table. The strict
companion is compared with the frozen checker and frozen named oracle.

ACTUAL PORTABLE COHORT
---------------------
The recorded run in results/verification.json passed:
  * 93 fixed packets: 45 inherited theorem packets, 29 original boundaries,
    and 19 derived-closure/sort-separation controls;
  * 372 actual CLI invocations: both programs, normal Python and -O;
  * 3672 independent opening comparisons per program (2110 valid, 1562 invalid);
  * 4 small example files, checked in both programs and the relevant oracle;
  * 15000 primary mutations, 10751 distinct, using seed 11072026;
  * 3000 companion mutations, 2668 distinct, using seed 202611071349.

The primary mutation cohort exactly reproduces the 43+19 developer audit.
It is not an additional independent set of 15000 mathematical examples.
All receipts record the actual checker hashes. The verifier refuses to finish
if a checker changes while its audit is running. It refreshes the receipts
for intentional changes only after every required comparison passes.

BOUNDARIES
----------
These are finite implementation checks. They are not a formal proof of
consistency, universal soundness, or bi-interpretability. Fixture groups and
mutations can overlap. A rejected certificate is not a disproof of its goal.
Python recursion, time, and memory limits remain finite implementation limits.
