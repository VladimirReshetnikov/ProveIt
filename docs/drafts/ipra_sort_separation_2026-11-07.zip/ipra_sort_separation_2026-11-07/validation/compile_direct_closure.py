"""Untrusted symbolic proof expansion for direct closure introduction.

The input is a finite symbolic proof tree, not arbitrary raw JSON. The native
checker and the strict five-rule checker independently validate every emitted
example. The target inserts the derived D-introduction / D-elimination macro
for each direct Q-introduction. Named eigenvariables are emitted anew against
the target's global allocation counter, so later raw negative coordinates are
renamed when inserted eliminations change the allocation order.

The constructors, five-rule derivation and five-rule emitter are inherited
from validation/reference/translate.py. None of this file is imported by
checker.py or checker_five_rules.py.
"""
from __future__ import annotations
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'validation' / 'reference'))
import translate as p


def direct_q(goal, eigen, step):
    if goal[0] != 'q' or not p.same(p.sf(goal[2], goal[1], p.S(eigen)), step.goal):
        raise ValueError('direct closure premise has the wrong formula')
    return p.Proof(goal, 'direct_q_intro', (eigen,), (step,))


def expand(proof):
    """Structural expansion on finite symbolic proof trees."""
    children = tuple(expand(child) for child in proof.children)
    if proof.rule == 'direct_q_intro':
        return p.q_intro(proof.goal, proof.data[0], children[0])
    return p.Proof(proof.goal, proof.rule, proof.data, children)


class TrackingEmitter(p.Emitter):
    def __init__(self):
        super().__init__()
        self.bindings = {}

    def record(self, scope):
        for name, value in scope.items():
            if name in self.bindings and self.bindings[name] != value:
                raise ValueError('one symbolic eigenvariable used by distinct binders')
            self.bindings[name] = value

    def emit(self, proof, context=(), scope=None):
        scope = {} if scope is None else scope
        self.record(scope)
        return super().emit(proof, context, scope)


class DirectEmitter(TrackingEmitter):
    def emit(self, proof, context=(), scope=None):
        scope = {} if scope is None else scope
        self.record(scope)
        if proof.rule != 'direct_q_intro':
            return super().emit(proof, context, scope)
        goal = p.raw_formula(proof.goal, scope)
        if goal in context:
            self.pruned += 1
            return
        self.rule_counts[proof.rule] = self.rule_counts.get(proof.rule, 0) + 1
        self.cells.append([0])
        self.k -= 1
        eigen, = proof.data
        local = {**scope, eigen: self.k}
        _, variable, matrix = proof.goal
        added = [p.raw_formula(p.sf(matrix, variable, 0), local)]
        if matrix[0] == '=':
            added.append(p.raw_formula(p.sf(matrix, variable, eigen), local))
        self.emit(proof.children[0], (*context, *added), local)


def plus(left, right):
    previous, counter = p.fresh(), p.fresh()
    return p.R(right, left, previous, counter, p.S(previous))


def all_(variable, matrix):
    return p.Q(variable, p.gate(matrix, variable))


def all_intro(variable, matrix, eigen, instance):
    successor_matrix = p.sf(matrix, variable, p.S(eigen))
    if not p.same(successor_matrix, instance.goal):
        raise ValueError('universal instance differs')
    step = p.gate_convert(instance, successor_matrix, p.S(eigen), True)
    return direct_q(all_(variable, matrix), eigen, step)


def exists_(variable, matrix):
    counter = p.fresh()
    return p.D(variable, counter, p.gate(matrix, counter))


def exists_intro(goal, witness, instance):
    _, variable, counter, gated = goal
    eigen = p.fresh()
    # For this construction the ungated matrix is recorded by the instance;
    # d_intro checks the final successor formula, independently of this hint.
    step = p.gate_convert(instance, instance.goal, p.S(eigen), True)
    return p.d_intro(goal, witness, eigen, step)


def q_reflexivity_at(term):
    variable, eigen = p.fresh(), p.fresh()
    closure = direct_q(p.Q(variable, p.Eq(variable, variable)),
                       eigen, p.refl(p.S(eigen)))
    return p.q_elim(closure, term, p.refl(0))


def examples():
    variable, eigen = p.fresh(), p.fresh()
    yield ('direct_q_constant',
           'Q x (0 = 0); its successor premise is the retained base.',
           direct_q(p.Q(variable, p.T), eigen, p.hyp(p.T)))

    variable, eigen = p.fresh(), p.fresh()
    yield ('direct_q_reflexivity',
           'Q x (x = x); the successor premise uses derived equality reflexivity.',
           direct_q(p.Q(variable, p.Eq(variable, variable)),
                    eigen, p.refl(p.S(eigen))))

    x, y, ex, ey = (p.fresh() for _ in range(4))
    term = plus(x, y)
    body = p.Q(y, p.Eq(term, term))
    inner_goal = p.sf(body, x, p.S(ex))
    step_term = plus(p.S(ex), p.S(ey))
    inner = direct_q(inner_goal, ey, p.refl(step_term))
    yield ('direct_q_nested_closures',
           'Q x Q y (x + y = x + y); the outer matrix is quantified and receives no induction hypothesis.',
           direct_q(p.Q(x, body), ex, inner))

    x, u, v, ex, ev = (p.fresh() for _ in range(5))
    left, right = plus(u, v), plus(x, v)
    body = p.D(u, v, p.Eq(left, right))
    paired_goal = p.sf(body, x, p.S(ex))
    value = plus(p.S(ex), p.S(ev))
    step = p.d_intro(paired_goal, p.S(ex), ev, p.refl(value))
    yield ('direct_q_paired_matrix',
           'Q x D(u,v) (u + v = x + v), using witness u = x in the successor branch.',
           direct_q(p.Q(x, body), ex, step))

    u, v, x, ev, ex = (p.fresh() for _ in range(5))
    value = plus(v, x)
    inner = p.Q(x, p.Eq(value, value))
    goal = p.D(u, v, inner)
    q_goal = p.sf(inner, v, p.S(ev))
    q_step = direct_q(q_goal, ex, p.refl(plus(p.S(ev), p.S(ex))))
    yield ('direct_q_inside_pair',
           'D(u,v) Q x (v + x = v + x); direct Q-introduction occurs below paired introduction.',
           p.d_intro(goal, 0, ev, q_step))

    x, ex, motive = p.fresh(), p.fresh(), p.fresh()
    successor = p.S(ex)
    major, minor = q_reflexivity_at(successor), q_reflexivity_at(successor)
    step = p.eq_elim(major, motive, p.Eq(motive, successor), minor)
    yield ('direct_q_renaming_after_major',
           'Q x (x = x), proved with two separate direct-Q major subproofs; inserted D eliminations rename a later eigenparameter.',
           direct_q(p.Q(x, p.Eq(x, x)), ex, step))

    x, u, ex = p.fresh(), p.fresh(), p.fresh()
    matrix = p.Eq(u, p.S(x))
    existential = exists_(u, matrix)
    successor_existence = p.sf(existential, x, p.S(ex))
    witness = p.S(p.S(ex))
    witness_equation = p.refl(witness)
    instance = exists_intro(successor_existence, witness, witness_equation)
    yield ('direct_q_forall_exists_successor',
           'Encoded ordinary forall x exists u (u = S x), with both quantifiers expressed by the report\'s numerical gates.',
           all_intro(x, existential, ex, instance))

    x, y, ex, ey = (p.fresh() for _ in range(4))
    value = plus(x, y)
    equation = p.Eq(value, value)
    inner_all = all_(y, equation)
    inner_equation = p.sf(equation, x, p.S(ex))
    inner_proof = all_intro(y, inner_equation, ey, p.refl(plus(p.S(ex), p.S(ey))))
    yield ('direct_q_forall_forall_reflexivity',
           'Encoded ordinary forall x forall y (x + y = x + y), with two nested numerical-gate universal introductions.',
           all_intro(x, inner_all, ex, inner_proof))


def load_checker(name):
    path = ROOT / name
    spec = importlib.util.spec_from_file_location(name.replace('.', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(module, packet):
    stream = deepcopy(packet)
    module.k = 0
    module.take = stream.pop
    try:
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'remaining': len(stream),
            'final_k': module.k, 'error': error}


def save(path, packet):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(packet, separators=(',', ':')) + '\n')
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    destination = ROOT / 'examples' / 'sort_separation'
    primary = load_checker('checker.py')
    strict = load_checker('checker_five_rules.py')
    records = []
    for name, description, proof in examples():
        source_emitter, target_emitter = DirectEmitter(), TrackingEmitter()
        source_packet = source_emitter.packet(proof)
        target_packet = target_emitter.packet(expand(proof))
        if source_packet[-1] != target_packet[-1]:
            raise AssertionError((name, 'conclusions changed'))
        source_run = run(primary, source_packet)
        target_run = run(strict, target_packet)
        if not source_run['accepted'] or source_run['remaining'] != 0:
            raise AssertionError((name, 'primary source rejected', source_run))
        if not target_run['accepted'] or target_run['remaining'] != 0:
            raise AssertionError((name, 'strict target rejected', target_run))
        if run(strict, source_packet)['accepted']:
            raise AssertionError((name, 'raw proof format unexpectedly equivalent'))
        if not run(primary, target_packet)['accepted']:
            raise AssertionError((name, 'primary rejected strict derivation'))
        q_count = source_emitter.rule_counts.get('direct_q_intro', 0)
        if target_emitter.k != source_emitter.k - q_count:
            raise AssertionError((name, 'unexpected number of inserted allocations'))
        source_path = destination / (name + '.json')
        target_path = destination / (name + '_five_rules.json')
        source_sha = save(source_path, source_packet)
        target_sha = save(target_path, target_packet)
        for filename, path in [('checker.py', source_path), ('checker_five_rules.py', target_path)]:
            for optimized in [False, True]:
                command = [sys.executable, *(['-O'] if optimized else []), str(ROOT / filename), str(path)]
                proc = subprocess.run(command, capture_output=True, text=True)
                if (proc.returncode, proc.stdout.strip()) != (0, 'ACCEPT'):
                    raise AssertionError((name, filename, optimized, proc.stderr))
        renamings = [{'symbol': symbol, 'source': value,
                      'expanded': target_emitter.bindings[symbol]}
                     for symbol, value in source_emitter.bindings.items()
                     if target_emitter.bindings[symbol] != value]
        records.append({'name': name, 'description': description,
                        'source': str(source_path.relative_to(ROOT)),
                        'expanded': str(target_path.relative_to(ROOT)),
                        'source_sha256': source_sha, 'expanded_sha256': target_sha,
                        'same_goal': True, 'source_accepted_by_primary': True,
                        'source_rejected_by_strict': True,
                        'expanded_accepted_by_both': True,
                        'source_proof_cells': len(source_packet)-1,
                        'expanded_proof_cells': len(target_packet)-1,
                        'source_eigenparameters': -source_emitter.k,
                        'expanded_eigenparameters': -target_emitter.k,
                        'direct_closure_steps': q_count,
                        'renamings': renamings,
                        'source_rules': source_emitter.rule_counts,
                        'expanded_rules': target_emitter.rule_counts})
        if name == 'direct_q_reflexivity':
            save(ROOT / 'examples' / 'direct_q_reflexivity.json', source_packet)
            save(ROOT / 'examples' / 'direct_q_reflexivity_five_rules.json', target_packet)
    if not any(item['renamings'] for item in records):
        raise AssertionError('fresh-variable renaming was not exercised')
    result = {'status': 'PASS', 'examples': len(records),
              'cli_checks': 4 * len(records),
              'same_conclusions': len(records),
              'source_packets_rejected_by_strict': len(records),
              'expanded_packets_accepted_by_both': len(records),
              'records': records}
    (ROOT / 'results' / 'closure_expansion.json').write_text(json.dumps(result, indent=2) + '\n')
    (destination / 'README.txt').write_text(
        'Each direct_q_NAME.json certificate is accepted by checker.py and rejected by\n'
        'checker_five_rules.py in its original form. Its direct_q_NAME_five_rules.json\n'
        'partner proves the identical raw goal using only the original five logical\n'
        'rules and is accepted by both checkers. Each direct closure step expands\n'
        'to paired introduction followed by paired elimination with an unused witness.\n'
        'The offline symbolic proof-tree expander re-emits all eigenvariables in\n'
        'the target allocation order. See results/closure_expansion.json for cell\n'
        'counts, allocation counts, and explicit source-to-target eigenparameter\n'
        'renamings. Regenerate with python3 validation/compile_direct_closure.py.\n'
        'This utility does not parse or claim to translate every arbitrary raw JSON\n'
        'certificate; it performs structural expansion of the supplied symbolic\n'
        'proof trees. It is outside the checker trust boundary.\n\n' +
        '\n'.join(item['name'] + ': ' + item['description'] for item in records) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))


if __name__ == '__main__':
    main()
