EXAMPLE CERTIFICATES
====================

From the package root:
  python3 checker.py examples/reflexivity_zero.json
  python3 checker_five_rules.py examples/derived_closure.json

The four JSON files directly in examples/ are small accepted examples in
both programs. examples/transported/ preserves 45 inherited closed theorem
certificates. examples/boundary/ contains both accepted controls and expected
rejections; validation/fixtures.json records their verdicts.

examples/derived_closure_boundary/ exercises the primary's extra raw proof
form. Its expected verdicts for both programs are recorded separately in
validation/derived_closure_fixtures.json. Some valid primary certificates
are intentionally rejected by the strict five-rule companion; their goals
remain provable in that calculus through the derived-rule expansion.

Do not treat every boundary filename as an accepted theorem. Successful
invocations print ACCEPT and exit 0; rejected invocations print REJECT and
exit 1. Rejection says that the packet is invalid, not that its goal is false.
