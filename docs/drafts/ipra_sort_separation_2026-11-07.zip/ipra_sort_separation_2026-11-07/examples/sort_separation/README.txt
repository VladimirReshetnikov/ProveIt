Each direct_q_NAME.json certificate is accepted by checker.py and rejected by
checker_five_rules.py in its original form. Its direct_q_NAME_five_rules.json
partner proves the identical raw goal using only the original five logical
rules and is accepted by both checkers. Each direct closure step expands
to paired introduction followed by paired elimination with an unused witness.
The offline symbolic proof-tree expander re-emits all eigenvariables in
the target allocation order. See results/closure_expansion.json for cell
counts, allocation counts, and explicit source-to-target eigenparameter
renamings. Regenerate with python3 validation/compile_direct_closure.py.
This utility does not parse or claim to translate every arbitrary raw JSON
certificate; it performs structural expansion of the supplied symbolic
proof trees. It is outside the checker trust boundary.

direct_q_constant: Q x (0 = 0); its successor premise is the retained base.
direct_q_reflexivity: Q x (x = x); the successor premise uses derived equality reflexivity.
direct_q_nested_closures: Q x Q y (x + y = x + y); the outer matrix is quantified and receives no induction hypothesis.
direct_q_paired_matrix: Q x D(u,v) (u + v = x + v), using witness u = x in the successor branch.
direct_q_inside_pair: D(u,v) Q x (v + x = v + x); direct Q-introduction occurs below paired introduction.
direct_q_renaming_after_major: Q x (x = x), proved with two separate direct-Q major subproofs; inserted D eliminations rename a later eigenparameter.
direct_q_forall_exists_successor: Encoded ordinary forall x exists u (u = S x), with both quantifiers expressed by the report's numerical gates.
direct_q_forall_forall_reflexivity: Encoded ordinary forall x forall y (x + y = x + y), with two nested numerical-gate universal introductions.
