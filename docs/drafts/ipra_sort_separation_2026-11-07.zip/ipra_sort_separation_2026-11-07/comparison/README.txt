FROZEN COMPARISON CORPUS

Pinned repository commit: 5c4724e5550a1b19347ac62c9b02857a7e3fbd19

The programs/ directory contains unchanged copies of twelve current root or
endorsed-alternative acceptance programs from the six supplied archives.
manifest.json records their source locations, SHA-256 hashes, archive names,
Git blob hashes, interfaces, and measured complete-source sizes.

Run python3 comparison/source_measure.py checker.py from the package root
to recompute the frozen comparison and compare the delivered checker.
The source measurement code is unchanged from the inspected drafts.
Exact figures use CPython 3.12.14.

The main whole-program envelope is 427 normalized significant tokens,
436 AST nodes, and 1246 normalized UTF-8 bytes. Separate coordinates may
be attained by different programs. Core-only envelope: 367/373/979.

expanded/ contains 90 distinct sources, mapped to 300 original paths by
expanded_manifest.json. Its broader, heuristic inventory has the same
whole-program envelope. It is supplemental evidence, not a certification
of every historical/reference implementation.

The finite comparison establishes no language-independent minimum and no
absolute shortestness theorem. Open-parameter interfaces are labeled;
the delivered checker has a closed-root public interface.
