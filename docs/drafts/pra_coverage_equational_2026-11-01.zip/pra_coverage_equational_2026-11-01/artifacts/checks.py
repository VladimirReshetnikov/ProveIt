#!/usr/bin/env python3
"""Independent finite diagnostics and literal AST ledgers.

These computations do not prove statements about all models. The paper
and checked Lean kernel establish the universal mathematical claims.
Python standard library only. No upstream code is imported or executed.
"""

from dataclasses import dataclass
from itertools import product
import json
from pathlib import Path


@dataclass(frozen=True)
class Tree:
    label: str
    children: tuple = ()

    def size(self):
        return 1 + sum(c.size() for c in self.children)


def node(label, *children):
    return Tree(label, children)


z, a, n, x, y, v = map(node, ("0", "a", "n", "x", "y", "v"))
bottom = node("false")


def suc(t):
    return node("S", t)


def eq(s, t):
    return node("=", s, t)


def imp(s, t):
    return node("implies", s, t)


def land(s, t):
    return node("and", s, t)


def lor(s, t):
    return node("or", s, t)


def forall(variables, body):
    # One node per binder; binding names are metadata, as in the drafts.
    for variable in reversed(variables):
        body = node("forall:" + variable.label, body)
    return body


def recursion(r, changing_seed=False, swap=False):
    bs = [node(f"b{i}") for i in range(r)]
    base = forall([a, *bs], eq(node("R", z, a, *bs), a))
    recursive = node("R", *([a, n] if swap else [n, a]), *bs)
    args = [n, *([a] if changing_seed else []), *bs, recursive]
    step = forall([n, a, *bs], eq(node("R", suc(n), a, *bs), node("h", *args)))
    return base.size(), step.size()


def induction(q, kind):
    cs = [node(f"c{i}") for i in range(q)]

    def equation(at):
        return eq(node("s", at, *cs), node("t", at, *cs))

    def matrix(at):
        if kind == "formula":
            return node("A", at, *cs)
        if kind == "equation":
            return equation(at)
        return lor(equation(at), eq(node("u", at, *cs), node("w", at, *cs)))

    if kind == "i0":
        b = lor(eq(n, z), equation(n))
        return forall(cs, imp(forall([n], imp(b, equation(suc(n)))), forall([n], b))).size()
    return forall(cs, imp(land(matrix(z), forall([n], imp(matrix(n), matrix(suc(n))))),
                         forall([n], matrix(n)))).size()


def comparison(q, successor):
    cs = [node(f"c{i}") for i in range(q)]
    f = lambda at: node("f", at, *cs)
    stationary = forall([n], eq(f(suc(n)), f(n)))
    if successor:
        first = eq(node("C", node("D", a, f(z)), f(z), a), a)
        second = eq(suc(f(n)), a)
    else:
        first = eq(node("T", f(z), a), a)
        second = eq(f(n), a)
    return forall(cs, imp(stationary, forall([a, n], lor(first, second)))).size()


def ledgers():
    sep = imp(eq(z, suc(z)), bottom).size()
    cover = forall([x], lor(eq(x, z), node("exists:y", eq(x, suc(y))))).size()
    assert (sep, cover) == (6, 10)
    rows = []
    for r, q in product(range(4), range(5)):
        r0, rs = recursion(r)
        assert (r0, rs) == (6 + 2*r, 12 + 4*r)
        assert induction(q, "formula") == 14 + 5*q
        assert induction(q, "equation") == 27 + 9*q
        assert induction(q, "two") == 53 + 17*q
        assert induction(q, "i0") == 29 + 7*q
        ordinary = r0 + rs + sep
        counts = {
            "qfi_formula": ordinary + induction(q, "formula"),
            "two_equations": ordinary + induction(q, "two"),
            "equation_and_coverage": ordinary + induction(q, "equation") + cover,
            "i0": ordinary + induction(q, "i0"),
            "fresh_T_swap": sum(recursion(r, changing_seed=True, swap=True)) + sep + comparison(q, False) + 8,
            "fresh_successor_swap": sum(recursion(r, swap=True)) + sep + comparison(q, True) + 2,
        }
        expected = (38+6*r+5*q, 77+6*r+17*q, 61+6*r+9*q,
                    53+6*r+7*q, 54+6*r+5*q, 52+6*r+6*q)
        assert tuple(counts.values()) == expected
        rows.append({"frozen_recursion_parameters": r, "induction_parameters": q, **counts})
    return {"node_convention": "One node per term/formula/binder occurrence; schematic application bodies omitted.",
            "rows": rows, "all_profile_formulas_verified": True}


def pred(x):
    return 0 if x == 0 else x - 1


def cond(x, a, b):
    return a if x == 0 else b


def residual(x, n):
    result = x
    for _ in range(n):
        result = pred(result)
    return result


def overflow(n, x, *, mutated=False):
    result = 0
    for j in range(n):
        test = residual(x, j)
        if mutated:
            result = cond(test, result, result + 1)
        else:
            result = cond(test, result + 1, result)
    return result


def numerical(bound=64):
    pairs = 0
    for x, y in product(range(bound+1), repeat=2):
        d = residual(x, y)
        r = overflow(y, x)
        assert x + r == y + d
        assert r == max(y-x, 0)  # Independent numerical oracle; not used in the proof.
        delta = d + r
        assert (delta == 0) == (x == y)
        assert delta == abs(x-y)
        assert cond(delta, 0, 1) == int(x != y)
        assert residual(x+y, x) == y
        pairs += 1
    mutation = next(({"x": x, "n": n} for x, n in product(range(4), repeat=2)
                     if x + overflow(n, x, mutated=True) != n + residual(x, n)), None)
    assert mutation is not None
    return {"bound_inclusive": bound, "pairs_checked": pairs,
            "balance_and_native_equality_diagnostics": "pass",
            "deliberately_reversed_update_rejected_at": mutation,
            "scope": "Finite standard-natural diagnostics, not an all-model proof."}


def boolean_tables():
    rows = []
    for b, d in product((0, 1), repeat=2):
        # Zero means true in all these expressions.
        values = (cond(b, d, 1), cond(b, 0, d), cond(b, d, 0))
        truth = ((b == 0) and (d == 0), (b == 0) or (d == 0), (b != 0) or (d == 0))
        assert tuple(v == 0 for v in values) == truth
        rows.append({"B_error": b, "D_error": d, "and": values[0], "or": values[1], "implication": values[2]})
    return rows


def main():
    result = {"syntax_ledgers": ledgers(), "numerical": numerical(),
              "boolean_tables": boolean_tables()}
    path = Path(__file__).with_name("results.json")
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"profiles": len(result["syntax_ledgers"]["rows"]),
                      **result["numerical"], "boolean_rows": len(result["boolean_tables"])}, indent=2))


if __name__ == "__main__":
    main()
