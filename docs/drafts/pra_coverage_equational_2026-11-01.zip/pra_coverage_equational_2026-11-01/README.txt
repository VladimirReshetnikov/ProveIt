PRA FROM ONE EQUATION AND A FIXED ZERO ALTERNATIVE
Prepared for Vladimir Reshetnikov, 1 November 2026

START HERE
report.pdf is the complete 14-page research report.
report.tex is its standalone editable source.
AXIOMS.txt is an exact plain-text specification.

MAIN RESULT
Use initialized ordinary recursion, 0 != S0, and, for every pair of terms
s(n,c),t(n,c), the universally closed schema

  [forall n ((n=0 OR s(n,c)=t(n,c)) -> s(Sn,c)=t(Sn,c))]
  -> forall n (n=0 OR s(n,c)=t(n,c)).

The same nonlogical basis is definitionally equivalent to first-order PRA
in each matching logic, classical and intuitionistic. Both interpretations
use the whole carrier and native equality; both round trips are provably
the identity. All finite parameter tuples are allowed.

NEW PROOF STEP
Equation induction plus one fixed positive constructor-coverage axiom
recovers full quantifier-free induction. A recursive overflow accumulator
proves x+r(n,x)=n+d(x,n) by induction on ONE EQUATION. Its error term
d(x,y)+r(y,x) recognizes native equality. This replaces the current draft's
disjunctive comparison induction. The compact schema above supplies both
ordinary equation induction and constructor coverage.

COMPARISON
The current six drafts were reviewed at ProveIt commit
9db1e0b1a625767ac54321715f5669d75002360e; all Git blob hashes were verified.
Under their partial AST ledger, the new basis has 53+6r+7q nodes (r frozen
recursion parameters, q induction parameters), no designated helper bodies.
At r=0,q=1 this is 60 versus the expanded two-equation draft's 94.
The existing arbitrary-formula-placeholder display remains smaller (43 at
that profile); it has a different schema generator.

The report also gives a fresh-probe synthesis of the existing
successor-comparison basis: 52+6r+6q versus the current fresh comparator's
54+6r+5q. The saving depends on q and is not uniform. The main ordinary-
recursion theorem is proved self-contained; this secondary swap theorem
uses the precisely cited existing full bi-interpretation theorem.

No globally shortest axiomatization or historical priority is claimed.
These are effective infinite schemas, not finitely many first-order axioms.

CONTENTS
report.pdf, report.tex          Complete report and source
AXIOMS.txt                    Exact theory cards
build.py                      Offline diagnostics and PDF rebuild
formal/Coverage.lean          Constructive Lean core, including I0 adapter
formal/check.log              17 successful axiom audits
formal/SCOPE.txt               Exact scope and inherited-code credit
formal/lean-toolchain          Lean 4.19.0
formal/verification.json       Toolchain, scope, and source/log hashes
artifacts/checks.py            Independent AST and numerical diagnostics
artifacts/results.json         20 parameter profiles, 4,225 numerical pairs
audit/source_manifest.json     Immutable input URLs and verified hashes
audit/mathematical_review.txt  Independent proof audit
audit/validation.json          Build, proof-check, and visual review record
SHA256SUMS.txt                 Package payload checksums

REBUILD
Python 3 standard library; pdfLaTeX with the packages listed in report.tex.
No network access, original archives, shell escape, or repository code needed.

  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only

Optional constructive proof replay with Lean 4.19.0 and bundled Std:

  python3 build.py --checks-only --lean /absolute/path/to/lean

Before rebuilding, verify delivered bytes:

  sha256sum -c SHA256SUMS.txt

Rebuilding changes PDF timestamps and may therefore change hashes. The
build's temporary _build directory is not part of the archive.

VERIFICATION BOUNDARY
The Lean endpoint checks I0 -> coverage+equation induction, the arithmetic
bridge and equality recognizer, Boolean compilation including intuitionistic
implication, and QF induction over admitted terms on an arbitrary carrier.
The complete recursion-description syntax, both compilers, first-order proof
transport, interpretation round trips, and countermodel arguments are written
proofs, not end-to-end proof-assistant formalizations. No global Lean axioms
are used beyond the explicitly parameterized theory assumptions.

The Python checks are finite diagnostics and literal syntax counts. They do
not establish universal mathematical claims or claims about nonstandard
models. Full written proofs and the checked constructive kernel supply that
evidence within their declared scopes.
