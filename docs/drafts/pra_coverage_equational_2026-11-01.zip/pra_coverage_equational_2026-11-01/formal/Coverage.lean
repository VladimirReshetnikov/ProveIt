import Std

/-!
# The constructive kernel for constructor coverage and atomic induction

This file works over an arbitrary carrier. `adm` denotes unary functions
represented by finite source terms after fixing their parameters. The
induction assumption is restricted to two admitted functions; it is NOT
induction over all predicates or all carrier-valued functions.

The initialized-recursion syntax and its compiler into the conventional
PRA language are treated in the accompanying paper. Here the operations
selected there are supplied with their defining equations and closure
properties. No ambient induction on the carrier is used.
The selected overflow scan is the initialized recursion with update
`cond (sub x n) (succ v) v` and initial value zero.
`RootedBasis` uses the compact zero-exception induction schema; its
adapter derives the coverage-plus-atomic-induction interface.
-/

namespace Coverage

universe u

structure Operations (N : Type u) where
  zero : N
  succ : N → N
  pred : N → N
  cond : N → N → N → N
  add : N → N → N
  sub : N → N → N
  overflow : N → N → N
  sep : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  cond_zero : ∀ a b, cond zero a b = a
  cond_succ : ∀ n a b, cond (succ n) a b = b
  add_zero : ∀ x, add x zero = x
  add_succ : ∀ x y, add x (succ y) = succ (add x y)
  sub_zero : ∀ x, sub x zero = x
  sub_succ : ∀ x y, sub x (succ y) = pred (sub x y)
  overflow_zero : ∀ x, overflow zero x = zero
  overflow_succ : ∀ n x, overflow (succ n) x =
    cond (sub x n) (succ (overflow n x)) (overflow n x)
  adm : (N → N) → Prop
  adm_const : ∀ a, adm (fun _ => a)
  adm_var : adm (fun x => x)
  adm_succ : ∀ f, adm f → adm (fun x => succ (f x))
  adm_pred : ∀ f, adm f → adm (fun x => pred (f x))
  adm_cond : ∀ f g h, adm f → adm g → adm h →
    adm (fun x => cond (f x) (g x) (h x))
  adm_add : ∀ f g, adm f → adm g → adm (fun x => add (f x) (g x))
  adm_sub : ∀ f g, adm f → adm g → adm (fun x => sub (f x) (g x))
  adm_overflow : ∀ f g, adm f → adm g → adm (fun x => overflow (f x) (g x))

structure Basis (N : Type u) extends Operations N where
  cover_exists : ∀ x, x = zero ∨ ∃ y, x = succ y
  ind_eq : ∀ f g, adm f → adm g →
    (f zero = g zero) →
    (∀ n, f n = g n → f (succ n) = g (succ n)) →
    ∀ n, f n = g n

/-!
`RootedBasis` is the shorter single-schema basis. The zero alternative is
fixed syntax: the schematic part still consists of exactly two admitted
terms. The following adapter derives both ordinary atomic induction and
positive constructor coverage from that schema.
-/
structure RootedBasis (N : Type u) extends Operations N where
  ind_zero : ∀ f g, adm f → adm g →
    (∀ n, (n = zero ∨ f n = g n) → f (succ n) = g (succ n)) →
    ∀ n, n = zero ∨ f n = g n

namespace RootedBasis

variable {N : Type u} (B : RootedBasis N)

def toBasis : Basis N where
  toOperations := B.toOperations
  cover_exists := by
    intro x
    have h := B.ind_zero (fun n => n) (fun n => B.succ (B.pred n))
      B.adm_var (B.adm_succ _ (B.adm_pred _ B.adm_var))
      (by
        intro n _
        dsimp only
        rw [B.pred_succ]) x
    rcases h with hx | hx
    · exact Or.inl hx
    · exact Or.inr ⟨B.pred x, hx⟩
  ind_eq := by
    intro f g hf hg hb hs n
    have hz := B.ind_zero f g hf hg (by
      intro k hk
      apply hs k
      rcases hk with hk | hk
      · rw [hk]
        exact hb
      · exact hk) n
    rcases hz with hz | hz
    · rw [hz]
      exact hb
    · exact hz

end RootedBasis

namespace Basis

variable {N : Type u} (B : Basis N)

def one : N := B.succ B.zero

theorem atomicInd (f g : N → N) (hf : B.adm f) (hg : B.adm g)
    (hb : f B.zero = g B.zero)
    (hs : ∀ n, f n = g n → f (B.succ n) = g (B.succ n)) :
    ∀ n, f n = g n := B.ind_eq f g hf hg hb hs

theorem succ_injective {x y : N} (h : B.succ x = B.succ y) : x = y := by
  have hp := congrArg B.pred h
  rw [B.pred_succ, B.pred_succ] at hp
  exact hp

theorem succ_ne_zero (x : N) : B.succ x ≠ B.zero := by
  intro h
  have hx : x = B.zero := by
    have hp := congrArg B.pred h
    rw [B.pred_succ, B.pred_zero] at hp
    exact hp
  rw [hx] at h
  exact B.sep h.symm


theorem cover (x : N) : x = B.zero ∨ x = B.succ (B.pred x) := by
  rcases B.cover_exists x with hx | hx
  · exact Or.inl hx
  · rcases hx with ⟨y, hy⟩
    right
    rw [hy, B.pred_succ]


theorem zero_add (x : N) : B.add B.zero x = x := by
  apply B.atomicInd (fun n => B.add B.zero n) (fun n => n)
    (B.adm_add _ _ (B.adm_const B.zero) B.adm_var) B.adm_var
    (B.add_zero B.zero) ?_ x
  intro n ih
  dsimp only at ih ⊢
  rw [B.add_succ, ih]

theorem succ_add (x y : N) : B.add (B.succ x) y = B.succ (B.add x y) := by
  apply B.atomicInd (fun n => B.add (B.succ x) n)
    (fun n => B.succ (B.add x n))
    (B.adm_add _ _ (B.adm_const _) B.adm_var)
    (B.adm_succ _ (B.adm_add _ _ (B.adm_const _) B.adm_var)) ?_ ?_ y
  · dsimp only
    rw [B.add_zero, B.add_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.add_succ, B.add_succ, ih]

theorem add_one (x : N) : B.add x B.one = B.succ x := by
  unfold one
  rw [B.add_succ, B.add_zero]

theorem sub_succ_succ (x y : N) :
    B.sub (B.succ x) (B.succ y) = B.sub x y := by
  apply B.atomicInd (fun n => B.sub (B.succ x) (B.succ n))
    (fun n => B.sub x n)
    (B.adm_sub _ _ (B.adm_const _) (B.adm_succ _ B.adm_var))
    (B.adm_sub _ _ (B.adm_const _) B.adm_var) ?_ ?_ y
  · dsimp only
    rw [B.sub_succ, B.sub_zero, B.pred_succ, B.sub_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.sub_succ (B.succ x) (B.succ n), ih, B.sub_succ x n]

theorem sub_add_cancel (x c : N) : B.sub (B.add x c) x = c := by
  apply B.atomicInd (fun n => B.sub (B.add n c) n) (fun _ => c)
    (B.adm_sub _ _ (B.adm_add _ _ B.adm_var (B.adm_const _)) B.adm_var)
    (B.adm_const _) ?_ ?_ x
  · dsimp only
    rw [B.zero_add, B.sub_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.succ_add, B.sub_succ_succ, ih]

theorem sub_self (x : N) : B.sub x x = B.zero := by
  have h := B.sub_add_cancel x B.zero
  rw [B.add_zero] at h
  exact h

theorem sub_next (x : N) : B.sub (B.succ x) x = B.one := by
  have h := B.sub_add_cancel x B.one
  rw [B.add_one] at h
  exact h

theorem add_eq_zero {x y : N} (h : B.add x y = B.zero) :
    x = B.zero ∧ y = B.zero := by
  rcases B.cover y with hy | hy
  · constructor
    · rw [hy, B.add_zero] at h
      exact h
    · exact hy
  · have hz : B.succ (B.add x (B.pred y)) = B.zero := by
      rw [hy, B.add_succ] at h
      exact h
    exact False.elim (B.succ_ne_zero _ hz)

theorem overflow_bridge (y x : N) :
    B.add x (B.overflow y x) = B.add y (B.sub x y) := by
  apply B.atomicInd (fun n => B.add x (B.overflow n x))
    (fun n => B.add n (B.sub x n))
    (B.adm_add _ _ (B.adm_const _)
      (B.adm_overflow _ _ B.adm_var (B.adm_const _)))
    (B.adm_add _ _ B.adm_var
      (B.adm_sub _ _ (B.adm_const _) B.adm_var)) ?_ ?_ y
  · dsimp only
    rw [B.overflow_zero, B.add_zero, B.sub_zero, B.zero_add]
  · intro n ih
    dsimp only at ih ⊢
    rcases B.cover (B.sub x n) with hd | hd
    · rw [B.overflow_succ, hd, B.cond_zero, B.sub_succ, hd, B.pred_zero]
      rw [B.add_succ, B.add_zero]
      rw [hd, B.add_zero] at ih
      exact congrArg B.succ ih
    · rw [B.overflow_succ, hd, B.cond_succ, B.sub_succ, hd, B.pred_succ]
      rw [hd, B.add_succ] at ih
      rw [B.succ_add]
      exact ih

theorem overflow_self (x : N) : B.overflow x x = B.zero := by
  have h := B.overflow_bridge x x
  rw [B.sub_self, B.add_zero] at h
  have hc := congrArg (fun z => B.sub z x) h
  dsimp only at hc
  rw [B.sub_add_cancel, B.sub_self] at hc
  exact hc

def error (x y : N) : N := B.add (B.sub x y) (B.overflow y x)

theorem error_zero (x y : N) : B.error x y = B.zero ↔ x = y := by
  constructor
  · intro h
    have hp := B.add_eq_zero h
    have hb := B.overflow_bridge y x
    rw [hp.1, hp.2, B.add_zero, B.add_zero] at hb
    exact hb
  · intro h
    subst y
    unfold error
    rw [B.sub_self, B.overflow_self, B.add_zero]

def eqBit (x y : N) : N :=
  B.cond (B.error x y) B.zero B.one

theorem eqBit_adm (f g : N → N) (hf : B.adm f) (hg : B.adm g) :
    B.adm (fun n => B.eqBit (f n) (g n)) := by
  exact B.adm_cond _ _ _
    (B.adm_add _ _ (B.adm_sub _ _ hf hg) (B.adm_overflow _ _ hg hf))
    (B.adm_const _) (B.adm_const _)

theorem eqBit_range (x y : N) :
    B.eqBit x y = B.zero ∨ B.eqBit x y = B.one := by
  unfold eqBit
  rcases B.cover (B.error x y) with h | h
  · exact Or.inl (by rw [h, B.cond_zero])
  · exact Or.inr (by rw [h, B.cond_succ])

theorem eqBit_zero (x y : N) : B.eqBit x y = B.zero ↔ x = y := by
  constructor
  · intro h
    have hd : B.error x y = B.zero := by
      rcases B.cover (B.error x y) with hd | hd
      · exact hd
      · have hone : B.one = B.zero := by
          unfold eqBit at h
          rw [hd, B.cond_succ] at h
          exact h
        exact False.elim (B.sep hone.symm)
    exact (B.error_zero x y).1 hd
  · intro h
    subst y
    unfold eqBit
    rw [(B.error_zero x x).2 rfl, B.cond_zero]

theorem eqBit_one (x y : N) : B.eqBit x y = B.one ↔ x ≠ y := by
  constructor
  · intro h hxy
    have hz := (B.eqBit_zero x y).2 hxy
    exact B.sep (hz.symm.trans h)
  · intro h
    rcases B.eqBit_range x y with hz | ho
    · exact False.elim (h ((B.eqBit_zero x y).1 hz))
    · exact ho

include B in
theorem equality_decidable (x y : N) : x = y ∨ x ≠ y := by
  rcases B.eqBit_range x y with hz | ho
  · exact Or.inl ((B.eqBit_zero x y).1 hz)
  · exact Or.inr ((B.eqBit_one x y).1 ho)

/-! The endpoint applies to every formula with an admitted error bit. -/

structure Encoded (A : N → Prop) where
  bit : N → N
  admitted : B.adm bit
  range : ∀ n, bit n = B.zero ∨ bit n = B.one
  truth : ∀ n, bit n = B.zero ↔ A n

namespace Encoded

variable {B} {A D : N → Prop}

theorem false_of_one (a : B.Encoded A) {n : N} (h : a.bit n = B.one) :
    ¬ A n := by
  intro ha
  have hz := (a.truth n).2 ha
  exact B.sep (hz.symm.trans h)

theorem induction (a : B.Encoded A) (hb : A B.zero)
    (hs : ∀ n, A n → A (B.succ n)) : ∀ n, A n := by
  have hi := B.atomicInd a.bit (fun _ => B.zero) a.admitted
    (B.adm_const _) ((a.truth B.zero).2 hb)
    (fun n hn => (a.truth (B.succ n)).2 (hs n ((a.truth n).1 hn)))
  intro n
  exact (a.truth n).1 (hi n)

end Encoded

def encodedEq (f g : N → N) (hf : B.adm f) (hg : B.adm g) :
    B.Encoded (fun n => f n = g n) where
  bit := fun n => B.eqBit (f n) (g n)
  admitted := B.eqBit_adm f g hf hg
  range := fun n => B.eqBit_range (f n) (g n)
  truth := fun n => B.eqBit_zero (f n) (g n)

def encodedTrue : B.Encoded (fun _ => True) where
  bit := fun _ => B.zero
  admitted := B.adm_const _
  range := fun _ => Or.inl rfl
  truth := fun _ => ⟨fun _ => True.intro, fun _ => rfl⟩

def encodedFalse : B.Encoded (fun _ => False) where
  bit := fun _ => B.one
  admitted := B.adm_const _
  range := fun _ => Or.inr rfl
  truth := fun _ => ⟨fun h => B.sep h.symm, fun h => False.elim h⟩

def encodedAnd {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n ∧ D n) where
  bit := fun n => B.cond (a.bit n) (d.bit n) B.one
  admitted := B.adm_cond _ _ _ a.admitted d.admitted (B.adm_const _)
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact d.range n
    · rw [ha, one, B.cond_succ]
      exact Or.inr rfl
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      constructor
      · intro h
        exact ⟨(a.truth n).1 ha, (d.truth n).1 h⟩
      · intro h
        exact (d.truth n).2 h.2
    · rw [ha, one, B.cond_succ]
      constructor
      · intro h
        exact False.elim (B.sep h.symm)
      · intro h
        exact False.elim (a.false_of_one ha h.1)

def encodedOr {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n ∨ D n) where
  bit := fun n => B.cond (a.bit n) B.zero (d.bit n)
  admitted := B.adm_cond _ _ _ a.admitted (B.adm_const _) d.admitted
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact Or.inl rfl
    · rw [ha, one, B.cond_succ]
      exact d.range n
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact ⟨fun _ => Or.inl ((a.truth n).1 ha), fun _ => rfl⟩
    · rw [ha, one, B.cond_succ]
      constructor
      · intro h
        exact Or.inr ((d.truth n).1 h)
      · intro h
        rcases h with h | h
        · exact False.elim (a.false_of_one ha h)
        · exact (d.truth n).2 h

def encodedImp {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n → D n) where
  bit := fun n => B.cond (a.bit n) (d.bit n) B.zero
  admitted := B.adm_cond _ _ _ a.admitted d.admitted (B.adm_const _)
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact d.range n
    · rw [ha, one, B.cond_succ]
      exact Or.inl rfl
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      constructor
      · intro h _
        exact (d.truth n).1 h
      · intro h
        exact (d.truth n).2 (h ((a.truth n).1 ha))
    · rw [ha, one, B.cond_succ]
      constructor
      · intro _ h
        exact False.elim (a.false_of_one ha h)
      · intro _
        rfl

/-!
This syntax is parameterized by admitted unary terms. It formalizes the
logical part of the QF compiler; parsing and interpreting the concrete
finite recursion descriptions are outside this file's scope.
-/

inductive QF (B : Basis N) : Type u where
  | atom (f g : N → N) (hf : B.adm f) (hg : B.adm g) : QF B
  | bot : QF B
  | top : QF B
  | conj : QF B → QF B → QF B
  | disj : QF B → QF B → QF B
  | impl : QF B → QF B → QF B

namespace QF

variable {B}

def denote : QF B → N → Prop
  | atom f g _ _ => fun n => f n = g n
  | bot => fun _ => False
  | top => fun _ => True
  | conj a d => fun n => a.denote n ∧ d.denote n
  | disj a d => fun n => a.denote n ∨ d.denote n
  | impl a d => fun n => a.denote n → d.denote n

def encode : (a : QF B) → B.Encoded a.denote
  | atom f g hf hg => B.encodedEq f g hf hg
  | bot => B.encodedFalse
  | top => B.encodedTrue
  | conj a d => B.encodedAnd a.encode d.encode
  | disj a d => B.encodedOr a.encode d.encode
  | impl a d => B.encodedImp a.encode d.encode

theorem induction (a : QF B) (hb : a.denote B.zero)
    (hs : ∀ n, a.denote n → a.denote (B.succ n)) : ∀ n, a.denote n := by
  exact a.encode.induction hb hs

end QF

end Basis

namespace RootedBasis

variable {N : Type u} (B : RootedBasis N)

theorem qfInduction (a : Basis.QF B.toBasis)
    (hb : a.denote B.zero)
    (hs : ∀ n, a.denote n → a.denote (B.succ n)) :
    ∀ n, a.denote n := by
  exact a.induction hb hs

end RootedBasis

end Coverage

#print axioms Coverage.RootedBasis.toBasis
#print axioms Coverage.Basis.cover
#print axioms Coverage.Basis.overflow_bridge
#print axioms Coverage.Basis.overflow_self
#print axioms Coverage.Basis.error_zero
#print axioms Coverage.Basis.eqBit_zero
#print axioms Coverage.Basis.equality_decidable
#print axioms Coverage.Basis.Encoded.induction
#print axioms Coverage.Basis.encodedEq
#print axioms Coverage.Basis.encodedTrue
#print axioms Coverage.Basis.encodedFalse
#print axioms Coverage.Basis.encodedAnd
#print axioms Coverage.Basis.encodedOr
#print axioms Coverage.Basis.encodedImp
#print axioms Coverage.Basis.QF.encode
#print axioms Coverage.Basis.QF.induction

#print axioms Coverage.RootedBasis.qfInduction
