#!/usr/bin/env python3
"""Offline rebuild. Python 3 standard library, pdfLaTeX; optional Lean 4.19."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(argv, *, log=None):
    result = subprocess.run(argv, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, check=False)
    if log:
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout, file=sys.stderr)
        raise SystemExit(result.returncode)
    return result.stdout


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--pdf-only", action="store_true")
    parser.add_argument("--lean", help="Path to the optional Lean 4.19.0 executable")
    args = parser.parse_args()
    if args.checks_only and args.pdf_only:
        parser.error("Choose at most one of --checks-only and --pdf-only")
    if not args.pdf_only:
        print(run([sys.executable, str(ROOT / "artifacts/checks.py")]))
    if args.lean:
        print(run([args.lean, str(ROOT / "formal/Coverage.lean")],
                  log=ROOT / "formal/check.log"))
    if not args.checks_only:
        build = ROOT / "_build"
        build.mkdir(exist_ok=True)
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "-no-shell-escape",
                   "-output-directory=" + str(build), str(ROOT / "report.tex")]
        for i in range(3):
            run(command, log=build / f"pass-{i+1}.txt")
        final_log = (build / "report.log").read_text(encoding="utf-8")
        for bad in ("Overfull ", "undefined references", "undefined on input line"):
            if bad in final_log:
                raise RuntimeError(f"Resolve LaTeX warning before delivery: {bad}")
        shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
        print("PDF rebuilt successfully with resolved references and no overfull boxes.")


if __name__ == "__main__":
    main()
