"""Reproduce source measurements and executable validation, without network access."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for relative in ("comparison/measure.py", "validation/validate.py"):
        result = subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT)
        if result.returncode:
            raise SystemExit(result.returncode)
    print("All comparison assertions and validation checks passed.")


if __name__ == "__main__":
    main()
