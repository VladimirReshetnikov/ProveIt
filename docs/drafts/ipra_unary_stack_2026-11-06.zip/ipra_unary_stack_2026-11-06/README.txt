iPRA WITH UNARY CLOSURE AND A SHARED PROOF STACK
Research report prepared for Vladimir Reshetnikov, 6 November 2026

Start with report.pdf. Its complete LaTeX source is report.tex and sections/.

RESULT

The strict standalone theorem checker checker.py has:
    523 executable AST nodes
    518 normalized significant Python tokens
   1613 normalized UTF-8 bytes

The coordinatewise minima among ALL 14 current top-level checker variants
in the six supplied drafts are 537, 526, and 1633, respectively. Thus the
strict complete program is below every current comparator in each metric.

The smaller demand companion has 515 AST nodes, 510 tokens, and 1569 bytes.
Its mathematical core also beats every current core minimum: 449 < 468
AST nodes, 452 < 461 tokens, and 1307 < 1324 normalized bytes. The strict
core beats the strict-policy core envelope, but not the smallest demand
core in normalized bytes (1351 versus 1324). This distinction is retained
in the report and generated comparison outputs.

All comparisons are pinned to ProveIt commit:
    b9aefe20fe876273886d5d55be49e6ccbefce9ad
The comparison uses the ACTUAL sources in all six current archives,
not their older, mutually inconsistent printed comparison minima.

MATHEMATICAL CONTENT

The native syntax has numerical terms formed from zero, successor, and
initialized recursion, and formulas formed from equality, unary closure
Q_x B, and existence E_x B. Q_x B reads as B(0) -> forall x B(x).

There are six native logical rule patterns and two recursion computation
schemas. The closure-introduction rule retains B(0), and additionally
permits B(y) only when B is literally an equation. The paper reconstructs
full intuitionistic first-order logic, successor axioms, all primitive
recursive descriptions, and every quantifier-free induction instance,
including implication and negation.

The native calculus faithfully presents an ordinary theory T_cov with
the explicit falsity bridge 0=S0 -> bottom. T_cov is bi-interpretable with
full first-order intuitionistic PRA. The two interpretations use the whole
number domain; equality defines both internally proved inverse
isomorphisms. This is stronger than a bare equiconsistency assertion.

The arithmetic and unary-binder mathematics are inherited and explicitly
credited. The contribution is the combined smaller checking presentation,
its correctness/transport argument, current-corpus comparison, independent
validation, and a semantic obstruction to deleting the retained base.
See ATTRIBUTION.txt. Absolute minimality and a completed proof-assistant
formalization are not claimed.

FILES

  report.tex, sections/      Complete paper source, including all rules/proofs.
  report.pdf                Compiled paper.
  checker.py                Complete strict theorem-acceptance program.
  checker_demand.py         Companion permitting erased unused Q annotations.
  FORMAT.txt                Exact syntax, instructions, and acceptance contract.
  examples/                 Concrete canonical proof certificates.
  validation/               Independent oracle, compiler, fixtures, and tests.
  comparison/               All 14 frozen comparators, hashes, measurement code.
  results/                  Reproduced comparison and validation results.
  reproduce.py              Rerun measurements and executable validation.
  build.py                  Rebuild report.pdf using pdfLaTeX.
  MANIFEST.sha256            Integrity hashes of delivered files.
  LICENSE_SOURCE.txt         Preserved MIT No Attribution source license.

RUN

Use CPython 3.12 to reproduce AST/unparse-based counts exactly. The
checkers themselves require Python 3.10 or later and only the standard
json and sys modules. No third-party Python packages are required.

  python3 reproduce.py
  python3 checker.py examples/exists_rigid_parameter.json
  python3 checker_demand.py examples/exists_rigid_parameter.json

The last two commands print ACCEPT and exit 0. Rejection prints REJECT
and exits 1. Both public interfaces take exactly [goal, stack], with an
empty initial context. Free numerical parameters are allowed.

To rebuild the paper, install a standard TeX Live distribution and run:

  python3 build.py

The build helper can generate a temporary pdfLaTeX format when required.
The compiled PDF is already included.

ACCEPTANCE AND VALIDATION LIMITS

Canonical certificates exhaust their stacks. The small kernels also
accept an irrelevant initial stack prefix; this prefix contributes no
inference and can be removed from the extracted derivation. Strict means
that every active numerical witness is validated, not that all irrelevant
JSON fields or stack prefixes must be rejected. An existential-elimination
placeholder has no semantic role. The demand companion additionally ignores
a Q-instantiation witness when its variable is absent from the matrix;
replacing that annotation by zero yields a strict proof of the same theorem.

Every mathematical ingredient in theorem acceptance appears in the checker.
Proof builders, the independent reference verifier, and measurement code
are untrusted aids and are never imported by either acceptance program.
Finite tests support the implementation audit; the general correctness and
bi-interpretability arguments are written mathematical proofs. Very large
valid certificates can exceed a concrete Python process's resource limits.
