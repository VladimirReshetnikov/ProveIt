"""Complete strict iPRA sequent checker with goal-only certificates."""
import json
import sys

def subst(a, env=(1,), d=0, formula=True):
    if not formula and type(a) is int and a >= 0:
        i = a - d
        return a if i <= 0 else subst(env[i - 1], (d,), formula=False) if i < len(env) else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1) for b, width in zip(args, ({'=': b'\0\0', 'pi': b'\1\1', 'ex': b'\1'} if formula else {'s': b'\0', 'r': b'\0\0\2'})[tag], strict=True))]

def check(a, p, *g):
    for b in (a, *g):
        subst(b)
    match (a, p):
        case [['pi', h, b], [q]]:
            if h == subst(b, [0, 0]):
                h = b if b[0] == '=' else h
                b = subst(b, [['s', 1], 0])
        case [[_, b], [t, q]]:
            h = ['=', 1, subst(t, formula=False)]
        case [_, [[tag, *parts] as m, r, *args]] if check(m, r, *g):
            if tag == 'ex':
                b, q, h = subst(a), *args, *parts
            else:
                t, q = args
                subst(t, formula=tag == '=')
                b, c = (subst(t, [v, -1]) if tag == '=' else subst(v, [t, -1]) for v in parts)
                return c == a and check(b, q, *g)
        case [[_, [_, n, t, h], b], []]:
            if n:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return b == t
        case _:
            return a in g
    return check(b, q, *map(subst, g), h)
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, encoding='utf-8'))):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
