"""Complete iPRA checker with unary conditional universals and strict witnesses."""
import json
import sys

SCOPES = ({'s': b'\x00', 'r': b'\x00\x00\x02'}, {'=': b'\x00\x00', 'u': b'\x01', 'ex': b'\x01'})

def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int and not formula and a >= 0:
        i = a - d
        return a if i <= 0 else subst(env[i - 1], (d,), formula=False) if i < len(env) else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1) for b, width in zip(args, SCOPES[formula][tag], strict=True))]

def check(a, p, *g):
    for b in (a, *g):
        subst(b)
    match (a, p):
        case [['u', b], [q]]:
            h = [subst(b, [0, 0]), *([b] if b[0] == '=' else [])]
            b = subst(b, [['s', 1], 0])
        case [['ex', b], [t, q]]:
            h = [['=', 1, subst(t, formula=False)]]
        case [_, [[tag, *parts] as m, r, *args]] if check(m, r, *g):
            if tag == 'ex':
                b, q, h = subst(a), *args, parts
            else:
                t, q = args
                subst(t, formula=tag == '=')
                if tag == 'u':
                    t, parts = *parts, [0, t]
                b, c = (subst(t, [v, -1]) for v in parts)
                return c == a and check(b, q, *g)
        case [['=', ['r', n, t, h], b], 'r']:
            if n:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return b == t
        case _:
            return a in g
    return check(b, q, *map(subst, g), *h)
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, 'rb'))):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
