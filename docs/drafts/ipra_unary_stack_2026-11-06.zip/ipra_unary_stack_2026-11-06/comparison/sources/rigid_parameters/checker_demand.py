"""Demand iPRA theorem checker with rigid negative numerical parameters."""
import json
import sys

SCOPES = ({'s': '0', 'r': '002'}, {'=': '00', 'pi': '11', 'ex': '1'})

def subst(a, env=(1,), d=0, formula=True):
    if not formula and type(a) is int:
        i = a - d
        return a if i <= 0 else subst(env[i - 1], (d,), formula=False) if i < len(env) else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + int(width), width == '1') for b, width in zip(args, SCOPES[formula][tag], strict=True))]

def check(a, p, g):
    subst(a)
    match (a, p):
        case [['pi', h, b], [q]]:
            if h == subst(b, [0, 0]):
                h = b if b[0] == '=' else h
                b = subst(b, [['s', 1], 0])
        case [['ex', b], [t, q]]:
            h = ['=', 1, subst(t, formula=False)]
        case [_, [[tag, *parts] as m, r, *args]] if check(m, r, g):
            if tag == 'ex':
                b, q, h = subst(a), *args, *parts
            else:
                t, q = args
                b, c = (subst(t, [v, -1]) if tag == '=' else subst(v, [t, -1]) for v in parts)
                return c == a and check(b, q, g)
        case [['=', ['r', n, t, h], b], 'r']:
            if n:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return b == t
        case _:
            return a in g
    return check(b, q, [*map(subst, g), h])
if __name__ == '__main__':
    try:
        _, path = sys.argv
        with open(path, encoding='utf-8') as stream:
            if not check(*json.load(stream), []):
                raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
