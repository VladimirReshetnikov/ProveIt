CURRENT-DRAFT COMPARISON
========================
Run from any directory:
  python3 comparison/measure.py
when the current directory is the package root, or use an absolute script path.
Use CPython 3.12 to reproduce the AST/unparse convention (tested on 3.12.14).
No third-party modules are required.

SCOPE AND PROVENANCE
The snapshot is ProveIt commit b9aefe20fe876273886d5d55be49e6ccbefce9ad.
It contains six ZIP archives in docs/drafts. This directory preserves all 14
top-level checker*.py sources byte for byte. Copies nested in comparison/
or history/ inside those archives are historical references, not additional
current proposals. manifest.json records each archive's original repository
path, size, Git blob identity, SHA-256, member path, and checker SHA-256.
The script refuses to measure a frozen source whose content hash changes.

MEASUREMENT
Full includes grammar validation, substitution, proof checking, JSON parsing,
file opening, argument validation, printing the verdict, exception handling,
and exit status. Only comments and actual docstrings are removed.
The primary measures are:
  AST nodes: every node yielded by ast.walk after docstring removal.
  Tokens: significant tokens in ast.unparse output, excluding whitespace,
          comments, indentation, and line terminators.
  Bytes: UTF-8 size of that normalized executable source, ending in newline.
Original significant source tokens and raw byte size are also recorded.
The common Python runtime and its standard library are outside all boundaries.
This is a source-size comparison, not a runtime-performance comparison.

Core is a diagnostic with all imports and top-level CLI blocks removed,
identically for every program. The exact-stack comparator enforces stack
exhaustion in its CLI; removing that check favors it in the core diagnostic.
Current comparators with public contexts validate those contexts in the core.
The manifest makes theorem versus public-open-sequent interfaces explicit.
New public inputs are [goal,stack] and start with an empty hypothesis context.

RESULTS AND LIMITS
The strict new program is below every current program in all 3 primary full
metrics. It is also below the strict-policy core envelope. The demand new
program is below the all-policy envelope in both boundaries. The strict core
has 27 more normalized bytes than the all-policy minimum; no stronger claim
is made. Coordinate minima may come from different programs.
The supplied tables include every current program, even variants with
weaker unused-annotation validation. No comparator is discarded to improve
the result. No claim of absolute or coding-invariant minimum is made.

LICENSE AND CONTRIBUTION
Frozen source code comes from VladimirReshetnikov/ProveIt and its draft
archives; the source MIT No Attribution license is preserved unchanged in
LICENSE_SOURCE.txt. The new programs combine the unary numerical closure
calculus with proof stacks, rigid variable names, and redundant-tag removal.
These are credited as inherited components. The new contribution is the
combined complete implementation and its explicit current-corpus comparison.
