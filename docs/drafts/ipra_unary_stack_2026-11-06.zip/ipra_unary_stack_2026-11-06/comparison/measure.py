"""Reproduce sizes of the two kernels and fourteen frozen current comparators.

Primary boundary: every source statement needed for public JSON acceptance,
including parsing and verdict code. Only comments and genuine docstrings are
excluded. The same Python runtime and standard library are outside each boundary.
"""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / 'results'
PRIMARY = ('ast_nodes', 'normalized_tokens', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


def source_measure(path, core=False):
    raw = Path(path).read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            doc = node.body[0]
            if (isinstance(doc, ast.Expr) and
                    isinstance(doc.value, ast.Constant) and
                    isinstance(doc.value.value, str)):
                node.body.pop(0)
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    if core:
        tree.body = [node for node in tree.body
                     if not isinstance(node, (ast.Import, ast.ImportFrom, ast.If))]
    normalized = ast.unparse(tree) + '\n'

    def count_tokens(text, omitted=()):
        return sum(token.type not in IGNORED and not any(
            first <= token.start and token.end <= last
            for first, last in omitted)
            for token in tokenize.generate_tokens(io.StringIO(text).readline))

    result = {'ast_nodes': sum(1 for _ in ast.walk(tree)),
              'normalized_tokens': count_tokens(normalized),
              'normalized_bytes': len(normalized.encode('utf-8'))}
    if not core:
        result.update(sha256=hashlib.sha256(raw).hexdigest(),
                      source_tokens=count_tokens(source, spans),
                      raw_bytes=len(raw))
    return result


def envelope(rows, boundary):
    return {key: min(row[boundary][key] for row in rows) for key in PRIMARY}


def below(left, right):
    return {key: left[key] < right[key] for key in PRIMARY}


def tex_row(label, values):
    return label + ' & ' + ' & '.join(f'{values[key]:,}' for key in PRIMARY) + r' \\' + '\n'


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    rows = []
    for entry in manifest['checkers']:
        path = ROOT / entry['source']
        full = source_measure(path)
        if full['sha256'] != entry['sha256']:
            raise ValueError('Changed comparison source: ' + entry['source'])
        rows.append({**entry, 'full': full, 'core': source_measure(path, core=True)})
    candidates = {}
    for policy, file in [('strict', 'checker.py'), ('demand', 'checker_demand.py')]:
        path = ROOT.parent / file
        candidates[policy] = {'source': file, 'interface': 'theorem',
                              'witness_policy': policy,
                              'full': source_measure(path),
                              'core': source_measure(path, core=True)}
    strict_rows = [row for row in rows if row['witness_policy'] == 'strict']
    minima = {boundary: envelope(rows, boundary) for boundary in ('full', 'core')}
    strict_minima = {boundary: envelope(strict_rows, boundary) for boundary in ('full', 'core')}
    comparisons = {
        'strict_full_below_all_current': below(candidates['strict']['full'], minima['full']),
        'strict_core_below_strict_current': below(candidates['strict']['core'], strict_minima['core']),
        'strict_core_below_all_current': below(candidates['strict']['core'], minima['core']),
        'demand_full_below_all_current': below(candidates['demand']['full'], minima['full']),
        'demand_core_below_all_current': below(candidates['demand']['core'], minima['core'])}
    required = ('strict_full_below_all_current', 'strict_core_below_strict_current',
                'demand_full_below_all_current', 'demand_core_below_all_current')
    for claim in required:
        if not all(comparisons[claim].values()):
            raise ValueError('Size claim failed: ' + claim)
    result = {
        'python_version': platform.python_version(),
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'primary_boundary': 'Complete public JSON acceptance programs; comments and docstrings excluded.',
        'core_boundary': 'Identical removal of all imports and top-level CLI blocks; diagnostic only.',
        'primary_metrics': list(PRIMARY),
        'program_count': len(rows), 'archive_count': len(manifest['archives']),
        'current_programs': rows, 'candidates': candidates,
        'all_current_minima': minima, 'strict_current_minima': strict_minima,
        'comparisons': comparisons,
        'strict_full_reduction_percent': {
            key: 100 * (1 - candidates['strict']['full'][key] / minima['full'][key])
            for key in PRIMARY},
        'notes': [
            'Coordinate minima may be attained by different comparator programs.',
            'Negative integers denote rigid free parameters in the new kernels.',
            'Strict and demand differ only in validation of unused Q numerical witnesses.',
            'The strict core exceeds the all-policy core byte minimum; this is reported, not hidden.',
            'Some comparators expose checked public contexts; new kernels expose an empty-context theorem interface.',
            'These are finite-corpus measurements, not a coding-invariant lower-bound or absolute-minimality theorem.']}
    OUTPUT.mkdir(exist_ok=True)
    (OUTPUT / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (OUTPUT / 'metrics.csv').open('w', newline='') as stream:
        fields = ['draft', 'file', 'interface', 'policy', 'boundary', *PRIMARY, 'sha256']
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            for boundary in ('full', 'core'):
                writer.writerow({'draft': row['draft'], 'file': row['file'],
                                 'interface': row['interface'], 'policy': row['witness_policy'],
                                 'boundary': boundary, **{key: row[boundary][key] for key in PRIMARY},
                                 'sha256': row['sha256']})
        for policy, row in candidates.items():
            for boundary in ('full', 'core'):
                writer.writerow({'draft': 'new', 'file': row['source'],
                                 'interface': row['interface'], 'policy': policy,
                                 'boundary': boundary, **{key: row[boundary][key] for key in PRIMARY},
                                 'sha256': row['full']['sha256']})
    summary = [r'\begin{tabular}{@{}lrrr@{}}' + '\n',
               r'\toprule' + '\n',
               r'Complete acceptance program & AST nodes & Tokens & Bytes \\' + '\n',
               r'\midrule' + '\n',
               tex_row('Current componentwise minimum', minima['full']),
               tex_row('New strict checker', candidates['strict']['full']),
               tex_row('New demand checker', candidates['demand']['full']),
               r'\midrule' + '\n',
               r'Core diagnostic & AST nodes & Tokens & Bytes \\' + '\n',
               r'\midrule' + '\n',
               tex_row('Current minimum, all policies', minima['core']),
               tex_row('Current minimum, strict only', strict_minima['core']),
               tex_row('New strict core', candidates['strict']['core']),
               tex_row('New demand core', candidates['demand']['core']),
               r'\bottomrule' + '\n', r'\end{tabular}' + '\n']
    (OUTPUT / 'metrics_summary.tex').write_text(''.join(summary))
    names = {'reduced_kernel': 'Reduced', 'rigid_parameters': 'Rigid parameters',
             'scope_kernel': 'Scope', 'stack_kernel': 'Stack',
             'unary_numerical_binder': 'Unary numerical binder',
             'unary_universal': 'Unary universal'}
    variants = {'checker.py': 'main', 'checker_demand.py': 'demand',
                'checker_strict.py': 'strict', 'checker_exact.py': 'exact',
                'checker_text_scopes.py': 'text scopes'}
    table = [r'\begin{tabular}{@{}lllrrr@{}}' + '\n', r'\toprule' + '\n',
             r'Draft & Variant & Policy & AST & Tokens & Bytes \\' + '\n', r'\midrule' + '\n']
    core_table = list(table)
    for row in rows:
        label = names[row['draft']] + ' & ' + variants[row['file']] + ' & ' + row['witness_policy']
        table.append(tex_row(label, row['full']))
        core_table.append(tex_row(label, row['core']))
    for entries, filename in [(table, 'baseline_table.tex'), (core_table, 'baseline_core_table.tex')]:
        entries += [r'\bottomrule' + '\n', r'\end{tabular}' + '\n']
        (OUTPUT / filename).write_text(''.join(entries))
    print(json.dumps({key: result[key] for key in
                      ('python_version', 'program_count', 'archive_count',
                       'all_current_minima', 'strict_current_minima',
                       'comparisons', 'strict_full_reduction_percent')}, indent=2))


if __name__ == '__main__':
    main()
