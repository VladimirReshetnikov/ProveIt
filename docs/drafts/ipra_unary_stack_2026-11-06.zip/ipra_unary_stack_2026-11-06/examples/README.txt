EXAMPLE CERTIFICATES

Each report_*.json file and every file in theorems/ is a public two-field
certificate [goal, stack]. Run, for example:

  python3 checker.py examples/report_recursion_zero.json
  python3 checker.py examples/report_existence.json
  python3 checker.py examples/report_numerical_closure.json

All three print ACCEPT. They demonstrate the zero recursion equation,
existential introduction with a rigid parameter, and numerical closure.
Every theorem in theorems/ also passes checker_demand.py and consumes its
complete generated stack.

internal_sequents.json contains 51 conditional, internal-interface test cases,
each with separately labeled goal, stack, and context fields. It is not a
public CLI certificate file. The validation runner validates these assumptions
before making its private check(a, stack, context) calls. Treating conditional
sequents as unconditionally proved theorems would be incorrect.

The source tree proofs and their provenance are preserved in
validation/source_sequents.json. To reproduce the compilation and checks:

  python3 validation/translate.py

To run the independent named-variable and adversarial audit as well:

  python3 validation/validate.py
