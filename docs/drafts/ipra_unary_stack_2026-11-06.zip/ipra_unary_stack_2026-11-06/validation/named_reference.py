"""Independent named-variable interpreter for the unary-Q calculus.

The acceptance source uses de Bruijn coordinates and one compact traversal.
This reference instead parses into sorted dataclasses with distinct names,
performs capture-free substitution on names, and compares alpha-normal forms.
It is audit support and is never imported by the acceptance program.
"""
from dataclasses import dataclass
from itertools import count


class Invalid(ValueError):
    pass


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Var:
    name: tuple


@dataclass(frozen=True)
class Succ:
    value: object


@dataclass(frozen=True)
class Rec:
    index: object
    initial: object
    accumulator: tuple
    predecessor: tuple
    step: object


@dataclass(frozen=True)
class Eq:
    left: object
    right: object


@dataclass(frozen=True)
class Q:
    variable: tuple
    body: object


@dataclass(frozen=True)
class Ex:
    variable: tuple
    body: object


def alpha(expression, bound=()):
    """An alpha-invariant tuple, with names retained for genuinely free vars."""
    if isinstance(expression, Zero):
        return ('zero',)
    if isinstance(expression, Var):
        if expression.name in bound:
            return ('bound', bound.index(expression.name))
        return ('free', expression.name)
    if isinstance(expression, Succ):
        return ('succ', alpha(expression.value, bound))
    if isinstance(expression, Rec):
        inner = (expression.accumulator, expression.predecessor) + bound
        return ('rec', alpha(expression.index, bound),
                alpha(expression.initial, bound), alpha(expression.step, inner))
    if isinstance(expression, Eq):
        return ('eq', alpha(expression.left, bound), alpha(expression.right, bound))
    if isinstance(expression, (Q, Ex)):
        return (type(expression).__name__,
                alpha(expression.body, (expression.variable,) + bound))
    raise Invalid('Unknown sorted expression')


def same(left, right):
    return alpha(left) == alpha(right)


def replace(expression, mapping):
    """Simultaneous named substitution; substitutions do not enter binders."""
    if isinstance(expression, Zero):
        return expression
    if isinstance(expression, Var):
        return mapping.get(expression.name, expression)
    if isinstance(expression, Succ):
        return Succ(replace(expression.value, mapping))
    if isinstance(expression, Rec):
        inner = {k: v for k, v in mapping.items()
                 if k not in (expression.accumulator, expression.predecessor)}
        return Rec(replace(expression.index, mapping),
                   replace(expression.initial, mapping),
                   expression.accumulator, expression.predecessor,
                   replace(expression.step, inner))
    if isinstance(expression, Eq):
        return Eq(replace(expression.left, mapping), replace(expression.right, mapping))
    if isinstance(expression, (Q, Ex)):
        inner = {k: v for k, v in mapping.items() if k != expression.variable}
        return type(expression)(expression.variable, replace(expression.body, inner))
    raise Invalid('Unknown sorted expression')


def instantiate(binder, term):
    return replace(binder.body, {binder.variable: term})


def coordinates(expression, local=()):
    """Serialize a named expression, rejecting an eigenvariable escape."""
    if isinstance(expression, Zero):
        return 0
    if isinstance(expression, Var):
        if expression.name in local:
            return 1 + local.index(expression.name)
        if expression.name[0] == 'free' and expression.name[1] >= 0:
            return len(local) + expression.name[1] + 1
        raise Invalid('Escaped variable')
    if isinstance(expression, Succ):
        return ['s', coordinates(expression.value, local)]
    if isinstance(expression, Rec):
        inner = (expression.accumulator, expression.predecessor) + local
        return ['r', coordinates(expression.index, local),
                coordinates(expression.initial, local),
                coordinates(expression.step, inner)]
    if isinstance(expression, Eq):
        return ['=', coordinates(expression.left, local),
                coordinates(expression.right, local)]
    if isinstance(expression, (Q, Ex)):
        tag = 'q' if isinstance(expression, Q) else 'ex'
        return [tag, coordinates(expression.body, (expression.variable,) + local)]
    raise Invalid('Unknown sorted expression')


def free_parameters(expression):
    """Names of ordinary free parameters, excluding all lexical binders."""
    if isinstance(expression, Var):
        return {expression.name} if expression.name[0] == 'free' else set()
    if isinstance(expression, Zero):
        return set()
    if isinstance(expression, Succ):
        return free_parameters(expression.value)
    if isinstance(expression, Rec):
        return (free_parameters(expression.index) | free_parameters(expression.initial)
                | free_parameters(expression.step))
    if isinstance(expression, Eq):
        return free_parameters(expression.left) | free_parameters(expression.right)
    if isinstance(expression, (Q, Ex)):
        return free_parameters(expression.body)
    raise Invalid('Unknown sorted expression')


class Oracle:
    def __init__(self):
        self.counter = count()

    def fresh(self, kind='bound'):
        return (kind, next(self.counter))

    def term(self, data, local=()):
        if type(data) is int:
            if data == 0:
                return Zero()
            if data < 0:
                raise Invalid('Negative number coordinate')
            if data <= len(local):
                return Var(local[data - 1])
            return Var(('free', data - len(local) - 1))
        if type(data) is not list or not data or type(data[0]) is not str:
            raise Invalid('Expected a numerical term')
        if data[0] == 's' and len(data) == 2:
            return Succ(self.term(data[1], local))
        if data[0] == 'r' and len(data) == 4:
            accumulator = self.fresh()
            predecessor = self.fresh()
            return Rec(self.term(data[1], local), self.term(data[2], local),
                       accumulator, predecessor,
                       self.term(data[3], (accumulator, predecessor) + local))
        raise Invalid('Unknown term constructor or wrong arity')

    def formula(self, data, local=()):
        if type(data) is not list or not data or type(data[0]) is not str:
            raise Invalid('Expected a formula')
        if data[0] == '=' and len(data) == 3:
            return Eq(self.term(data[1], local), self.term(data[2], local))
        if data[0] in ('q', 'ex') and len(data) == 2:
            variable = self.fresh()
            body = self.formula(data[1], (variable,) + local)
            return (Q if data[0] == 'q' else Ex)(variable, body)
        raise Invalid('Unknown formula constructor or wrong arity')

    def derive(self, goal, proof, context=(), local=()):
        # Q introduction: base instance and an equation-only induction hypothesis.
        if isinstance(goal, Q) and type(proof) is list and len(proof) == 1:
            eigen = self.fresh('eigen')
            base = instantiate(goal, Zero())
            assumptions = [*context, base]
            if isinstance(goal.body, Eq):
                assumptions.append(instantiate(goal, Var(eigen)))
            step = instantiate(goal, Succ(Var(eigen)))
            return self.derive(step, proof[0], assumptions, (eigen,) + local)

        # Ex introduction retains the witness by a fresh equality assumption.
        if isinstance(goal, Ex) and type(proof) is list and len(proof) == 2:
            witness = self.term(proof[0], local)
            eigen = self.fresh('eigen')
            body = instantiate(goal, Var(eigen))
            assumptions = [*context, Eq(Var(eigen), witness)]
            return self.derive(body, proof[1], assumptions, (eigen,) + local)

        # Elimination is selected only after its displayed major is established.
        if (type(proof) is list and len(proof) >= 2
                and type(proof[0]) is list and len(proof[0]) >= 1):
            major = self.formula(proof[0], local)
            if self.derive(major, proof[1], context, local):
                arguments = proof[2:]
                if isinstance(major, Ex):
                    if len(arguments) != 1:
                        raise Invalid('Existential elimination requires one branch')
                    eigen = self.fresh('eigen')
                    assumptions = [*context, instantiate(major, Var(eigen))]
                    return self.derive(goal, arguments[0], assumptions,
                                       (eigen,) + local)
                if len(arguments) != 2:
                    raise Invalid('Elimination requires one annotation and one minor')
                annotation, minor = arguments
                if isinstance(major, Eq):
                    place = self.fresh('template')
                    motive = self.formula(annotation, (place,) + local)
                    premise = replace(motive, {place: major.left})
                    conclusion = replace(motive, {place: major.right})
                elif isinstance(major, Q):
                    witness = self.term(annotation, local)
                    premise = instantiate(major, Zero())
                    conclusion = instantiate(major, witness)
                else:
                    raise Invalid('Unknown eliminable formula')
                return same(goal, conclusion) and self.derive(premise, minor, context, local)

        # The two initialized-recursion equations, unfolded by named substitution.
        if isinstance(goal, Eq) and isinstance(goal.left, Rec) and proof == 'r':
            term = goal.left
            if isinstance(term.index, Zero):
                result = term.initial
            elif isinstance(term.index, Succ):
                predecessor = term.index.value
                previous = Rec(predecessor, term.initial, term.accumulator,
                               term.predecessor, term.step)
                result = replace(term.step, {term.accumulator: previous,
                                             term.predecessor: predecessor})
            else:
                # The certificate explicitly selects computation.  A variable
                # or recursive index is an invalid selected rule, not a failed
                # major that permits an outer hypothesis fallback.
                raise Invalid('Computation requires zero or a successor index')
            return same(goal.right, result)

        return any(same(goal, assumption) for assumption in context)


def accept_sequent(goal, proof, context=()):
    try:
        oracle = Oracle()
        expected = oracle.formula(goal)
        assumptions = [oracle.formula(item) for item in context]
        return oracle.derive(expected, proof, assumptions)
    except Exception:
        return False


def accept_document(document):
    if type(document) is not list or len(document) != 2:
        return False
    return accept_sequent(*document)


def substitution(data, environment=(1,), depth=0, formula=True):
    """Independent prefix substitution, implemented through ordinary names."""
    oracle = Oracle()
    local = tuple(('local', i) for i in range(depth))
    expression = (oracle.formula if formula else oracle.term)(data, local)
    replacements = [oracle.term(term) for term in environment[:-1]]
    tail = environment[-1]
    if type(tail) is not int:
        raise Invalid('A tail shift is an integer')
    mapping = {}
    for name in free_parameters(expression):
        index = name[1]
        if index < len(replacements):
            mapping[name] = replacements[index]
        else:
            mapping[name] = Var(('free', index + tail))
    return coordinates(replace(expression, mapping), local)
