"""Untrusted compiler from canonical unary-Q trees to stack certificates.

The checker pops the rightmost instruction and visits a major premise before
a minor premise. Therefore compile each minor first, then the major, then
their elimination instruction. This module is never imported by the checkers.
"""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent


def compile_proof(proof):
    if proof is None:
        return [None]
    if proof == 'r':
        return [[]]
    if type(proof) is not list:
        raise ValueError('A canonical tree certificate is required')
    if len(proof) == 1:
        return compile_proof(proof[0]) + [[]]
    if len(proof) == 2:
        witness, minor = proof
        return compile_proof(minor) + [[deepcopy(witness)]]
    if len(proof) == 3:
        major, major_proof, minor = proof
        if major[0] != 'ex':
            raise ValueError('Three fields select existential elimination')
        return compile_proof(minor) + compile_proof(major_proof) + [[deepcopy(major), 0]]
    if len(proof) == 4:
        major, major_proof, annotation, minor = proof
        if major[0] not in ('q', '='):
            raise ValueError('Four fields select Q or equality elimination')
        return (compile_proof(minor) + compile_proof(major_proof)
                + [[deepcopy(major), deepcopy(annotation)]])
    raise ValueError('Noncanonical tree-rule arity')


def load(path, name):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


def run(write_examples=True):
    source = load(ROOT / 'comparison/sources/unary_numerical_binder/checker.py',
                  'transport_source_checker')
    checkers = [(name, load(ROOT / name, 'transport_' + name.replace('.', '_')))
                for name in ('checker.py', 'checker_demand.py')]
    cases = json.loads((ROOT / 'validation/source_sequents.json').read_text())
    outcomes, contextual = [], []
    destination = ROOT / 'examples/theorems'
    if write_examples:
        destination.mkdir(parents=True, exist_ok=True)
    theorem_count = 0
    for row in cases:
        goal, proof, context = row['goal'], row['proof'], row['context']
        for hypothesis in context:
            source.subst(hypothesis)
        if not source.check(goal, proof, context):
            raise ValueError('Original source rejects ' + row['name'])
        stack = compile_proof(proof)
        accepted = {}
        for name, checker in checkers:
            remaining = deepcopy(stack)
            for hypothesis in context:
                checker.subst(hypothesis)
            accepted[name] = bool(checker.check(goal, remaining, context)) and not remaining
            if not accepted[name]:
                raise ValueError(name + ' rejects transported ' + row['name'])
        record = {'name': row['name'], 'source': row['source'],
                  'context_size': len(context), 'instructions': len(stack),
                  'accepted_with_exhaustion': accepted}
        if context:
            contextual.append({'name': row['name'], 'goal': goal,
                               'stack': stack, 'context': context})
        else:
            theorem_count += 1
            filename = '%02d_%s.json' % (theorem_count, row['name'])
            record['theorem_file'] = 'examples/theorems/' + filename
            if write_examples:
                (destination / filename).write_text(json.dumps([goal, stack], indent=2) + '\n')
        outcomes.append(record)
    if write_examples:
        (ROOT / 'examples/internal_sequents.json').write_text(
            json.dumps(contextual, indent=2) + '\n')
    result = {'source_cases': len(cases), 'context_free': theorem_count,
              'contextual': len(contextual),
              'all_transports_accepted_with_exhaustion': True, 'cases': outcomes}
    if write_examples:
        (ROOT / 'results/transport.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    result = run()
    print(json.dumps({key: value for key, value in result.items() if key != 'cases'}, indent=2))
