VALIDATION AND CERTIFICATE TRANSPORT

Run from the package root with Python 3.10 or later:

  python3 validation/validate.py

The command reproduces results/validation.json and results/transport.json,
regenerates validation/cases.json, and writes the compiled example files.
Only the Python standard library is needed. The validation programs are not
part of the trusted checker and are never imported by either checker.

The independent oracle parses formulas into named-variable dataclasses,
opens binders with distinct fresh names, performs substitution on names, and
compares alpha-normal forms. It does not call either candidate's substitution
routine. validate.py extends the inherited named reference with negative rigid
parameters and a separate interpretation of stack execution.

Successful demand executions are reconstructed as canonical tree proofs.
The separate named tree verifier checks those proofs. The untrusted translator
then recompiles them, and the strict checker checks the resulting certificates
with complete stack consumption. This also exercises replacement of malformed
unused Q-witness annotations by zero, removal of unused stack prefixes, and
replacement of successful hypothesis fallbacks by ordinary Hyp leaves.

The recorded run contains:

  270 rule/certificate fixtures, compared against both checker variants;
  234 independently calculated substitution cases, compared against both;
   76 command-line executions, including runs with Python optimization;
   81 inherited source tree proofs transported to both stack variants;
  164 accepted demand proofs reconstructed and rechecked;
   25 malformed but unused witness annotations repaired;
    6 deliberate faults, each detected by a specific adversarial fixture.

The 270 fixtures comprise 101 unary-Q regression cases, 58 logical example
proofs, 23 compatible stack regression cases, and 88 targeted cases. One old
tree fixture has a noncanonical existential rule arity with no compiler image.
Seventeen old stack fixtures use the removed binary Pi binder and are not
replayed unchanged. Their relevant Q analogues, including induction limits,
scope/capture checks, witness validation, truncated stacks and execution order,
are tested in the targeted or inherited unary-Q fixtures. All omissions are
listed in results/validation.json.

The 81 source sequents are preserved in source_sequents.json: 30 are
context-free, and 51 have explicit assumptions. Context-free compiled inputs
are in examples/theorems/. The conditional cases are recorded separately in
examples/internal_sequents.json and checked through the private interface
with validated assumptions. No public CLI argument can supply a context.

The three short examples printed in the report are also checked independently,
by both candidates, and through both optimized and ordinary public CLI runs.

Scope of evidence
-----------------
These finite tests and proof reconstructions support the handwritten kernel
correspondence proof; they are not a machine-checked general soundness theorem.
The word 'strict' describes validation of an active Q-elimination witness.
Both variants intentionally allow unused stack prefixes, inactive auxiliary
payloads in existential elimination, and opaque hypothesis instructions.
The public input still has exactly two fields and starts from no assumptions.

Attribution and original fixture licenses are in ATTRIBUTION.txt and
LICENSE_SOURCE.txt. The inherited named reference is byte-identical to its
source; its SHA-256 is recorded in results/validation.json.
