"""Independent audit of the unary-Q, stack-certificate, rigid-parameter kernel.

The named syntax, alpha comparison, and named substitution are imported from
the November 6 unary-Q draft's independent reference, not from a candidate.
This file adds rigid numerical parameters and independently interprets stack
execution.  Successful executions are reconstructed as canonical tree proofs;
those trees are checked by the separate tree oracle and recompiled for the
strict candidate.  None of this code belongs to the trusted checker.
"""
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


ref = load(HERE / 'named_reference.py', 'independent_q_reference')
compiler = load(HERE / 'translate.py', 'untrusted_tree_compiler')


class RigidOracle(ref.Oracle):
    def term(self, data, local=()):
        if type(data) is int and data < 0:
            return ref.Var(('rigid', data))
        return super().term(data, local)


def free_names(expression):
    if isinstance(expression, ref.Zero):
        return set()
    if isinstance(expression, ref.Var):
        return {expression.name}
    if isinstance(expression, ref.Succ):
        return free_names(expression.value)
    if isinstance(expression, ref.Rec):
        return (free_names(expression.index) | free_names(expression.initial)
                | (free_names(expression.step)
                   - {expression.accumulator, expression.predecessor}))
    if isinstance(expression, ref.Eq):
        return free_names(expression.left) | free_names(expression.right)
    if isinstance(expression, (ref.Q, ref.Ex)):
        return free_names(expression.body) - {expression.variable}
    raise ref.Invalid('Unknown named expression')


def coordinates(expression, local=()):
    if isinstance(expression, ref.Zero):
        return 0
    if isinstance(expression, ref.Var):
        if expression.name in local:
            return local.index(expression.name) + 1
        kind, number = expression.name
        if kind == 'rigid':
            return number
        if kind == 'free' and number >= 0:
            return len(local) + number + 1
        raise ref.Invalid('Escaped eigenvariable')
    if isinstance(expression, ref.Succ):
        return ['s', coordinates(expression.value, local)]
    if isinstance(expression, ref.Rec):
        inner = (expression.accumulator, expression.predecessor) + local
        return ['r', coordinates(expression.index, local),
                coordinates(expression.initial, local), coordinates(expression.step, inner)]
    if isinstance(expression, ref.Eq):
        return ['=', coordinates(expression.left, local), coordinates(expression.right, local)]
    if isinstance(expression, (ref.Q, ref.Ex)):
        return ['q' if isinstance(expression, ref.Q) else 'ex',
                coordinates(expression.body, (expression.variable,) + local)]
    raise ref.Invalid('Unknown named expression')


def named_substitution(data, environment=(1,), depth=0, formula=True):
    oracle = RigidOracle()
    local = tuple(('local', i) for i in range(depth))
    expression = (oracle.formula if formula else oracle.term)(data, local)
    replacements = [oracle.term(raw) for raw in environment[:-1]]
    tail = environment[-1]
    if type(tail) is not int:
        raise ref.Invalid('Non-integer tail shift')
    mapping = {}
    for name in free_names(expression):
        if name[0] != 'free':
            continue
        index = name[1]
        mapping[name] = (replacements[index] if index < len(replacements)
                         else ref.Var(('free', index + tail)))
    return coordinates(ref.replace(expression, mapping), local)


@dataclass
class Derivation:
    ok: bool
    tree: object = None


class NamedStackOracle(RigidOracle):
    def __init__(self, strict):
        super().__init__()
        self.strict = strict
        self.repaired_witnesses = 0
        self.discarded_failed_majors = 0

    def stack_derive(self, goal, proof, context=(), local=()):
        if type(proof) is not list or not proof:
            raise ref.Invalid('An instruction must be available')
        instruction = proof.pop()
        array = type(instruction) is list
        if isinstance(goal, ref.Q) and array and not instruction:
            eigen = self.fresh('eigen')
            base = ref.instantiate(goal, ref.Zero())
            assumptions = [*context, base]
            if isinstance(goal.body, ref.Eq):
                assumptions.append(ref.instantiate(goal, ref.Var(eigen)))
            step = ref.instantiate(goal, ref.Succ(ref.Var(eigen)))
            minor = self.stack_derive(step, proof, assumptions, (eigen,) + local)
            return Derivation(minor.ok, [minor.tree])

        if isinstance(goal, ref.Ex) and array and len(instruction) == 1:
            witness = self.term(instruction[0], local)
            eigen = self.fresh('eigen')
            body = ref.instantiate(goal, ref.Var(eigen))
            assumptions = [*context, ref.Eq(ref.Var(eigen), witness)]
            minor = self.stack_derive(body, proof, assumptions, (eigen,) + local)
            return Derivation(minor.ok, [deepcopy(instruction[0]), minor.tree])

        if (array and len(instruction) == 2 and type(instruction[0]) is list
                and instruction[0]):
            major = self.formula(instruction[0], local)
            major_proof = self.stack_derive(major, proof, context, local)
            if major_proof.ok:
                if isinstance(major, ref.Ex):
                    eigen = self.fresh('eigen')
                    assumptions = [*context, ref.instantiate(major, ref.Var(eigen))]
                    minor = self.stack_derive(goal, proof, assumptions, (eigen,) + local)
                    return Derivation(minor.ok,
                                      [deepcopy(instruction[0]), major_proof.tree, minor.tree])
                if isinstance(major, ref.Eq):
                    hole = self.fresh('template')
                    motive = self.formula(instruction[1], (hole,) + local)
                    premise = ref.replace(motive, {hole: major.left})
                    conclusion = ref.replace(motive, {hole: major.right})
                    annotation = deepcopy(instruction[1])
                elif isinstance(major, ref.Q):
                    if self.strict or major.variable in free_names(major.body):
                        witness = self.term(instruction[1], local)
                        annotation = deepcopy(instruction[1])
                    else:
                        witness = ref.Zero()
                        annotation = 0
                        try:
                            self.term(instruction[1], local)
                        except Exception:
                            self.repaired_witnesses += 1
                    premise = ref.instantiate(major, ref.Zero())
                    conclusion = ref.instantiate(major, witness)
                else:
                    raise ref.Invalid('Unknown major formula')
                if not ref.same(goal, conclusion):
                    return Derivation(False)
                minor = self.stack_derive(premise, proof, context, local)
                return Derivation(minor.ok, [deepcopy(instruction[0]), major_proof.tree,
                                            annotation, minor.tree])
            self.discarded_failed_majors += 1

        if (isinstance(goal, ref.Eq) and isinstance(goal.left, ref.Rec)
                and array and not instruction):
            recursor = goal.left
            if isinstance(recursor.index, ref.Zero):
                result = recursor.initial
            elif isinstance(recursor.index, ref.Succ):
                predecessor = recursor.index.value
                previous = ref.Rec(predecessor, recursor.initial, recursor.accumulator,
                                   recursor.predecessor, recursor.step)
                result = ref.replace(recursor.step, {recursor.accumulator: previous,
                                                     recursor.predecessor: predecessor})
            else:
                raise ref.Invalid('Computation requires zero or a successor')
            return Derivation(ref.same(goal.right, result), 'r')

        return Derivation(any(ref.same(goal, hypothesis) for hypothesis in context))


def oracle_run(row, strict):
    oracle = NamedStackOracle(strict)
    remaining = deepcopy(row['stack'])
    try:
        goal = oracle.formula(row['goal'])
        context = [oracle.formula(x) for x in row['context']]
        result = oracle.stack_derive(goal, remaining, context)
        return result.ok, remaining, result.tree, oracle
    except Exception:
        return False, remaining, None, oracle


def candidate_run(module, row):
    remaining = deepcopy(row['stack'])
    try:
        # The public candidate accepts no context; contextual audit calls have
        # the explicitly stated precondition of well-formed assumptions.
        verifier = RigidOracle()
        for hypothesis in row['context']:
            verifier.formula(hypothesis)
        result = module.check(deepcopy(row['goal']), remaining, deepcopy(row['context']))
        return bool(result), remaining
    except Exception:
        return False, remaining


def E(s, t):
    return ['=', s, t]


def S(t):
    return ['s', t]


def R(n, a, h):
    return ['r', n, a, h]


def reflexivity(t):
    return [E(R(0, t, 0), t), 'r', E(1, named_substitution(t, formula=False)), 'r']


def contains_pi(value):
    return (type(value) is list and
            ((bool(value) and value[0] == 'pi') or any(contains_pi(x) for x in value)))


def collect_rows():
    rows, skipped = [], []
    tree_files = [(HERE / 'fixtures/q_cases.json', 'q_fixture'),
                  (HERE / 'fixtures/q_logic.json', 'q_logic')]
    for path, category in tree_files:
        for row in json.loads(path.read_text()):
            try:
                stack = compiler.compile_proof(row['proof'])
            except Exception:
                skipped.append({'source': category, 'name': row['name'],
                                'reason': 'Noncanonical tree-rule arity has no compiler image'})
                continue
            rows.append({'name': row['name'], 'source': category, 'goal': row['goal'],
                         'stack': stack, 'context': row['context']})
    for row in json.loads((HERE / 'fixtures/stack_cases.json').read_text()):
        document = row['document']
        if contains_pi(document):
            skipped.append({'source': 'stack_fixture', 'name': row['name'],
                            'reason': 'Uses the old binary guarded binder'})
            continue
        rows.append({'name': row['name'], 'source': 'stack_fixture', 'goal': document[0],
                     'stack': document[1], 'context': document[2:]})

    def add(name, goal, stack, context=(), expected=None):
        rows.append({'name': name, 'source': 'targeted', 'goal': goal,
                     'stack': stack, 'context': list(context), 'expected': expected})

    truth, falsehood = E(0, 0), E(0, S(0))
    qtruth = ['q', truth]
    qdependent = ['q', E(1, 1)]
    for parameter in (-1, -9, -1000000000000000, 1, 20):
        add('parameter_reflexivity_' + str(parameter), E(parameter, parameter),
            compiler.compile_proof(reflexivity(parameter)), expected=(True, True))
        add('parameter_existential_' + str(parameter),
            ['ex', E(1, named_substitution(parameter, formula=False))],
            [None, [parameter]], expected=(True, True))
        add('zero_recursion_parameter_' + str(parameter),
            E(R(0, parameter, R(2, 1, S(3))), parameter), [[]], expected=(True, True))
    for h in (1, 2, 3, -1, S(-7), R(2, 1, S(3)), R(-3, 4, R(2, 1, S(5)))):
        n, a = S(-2), R(0, 1, -6)
        reduct = named_substitution(h, (R(n, a, h), n, -2), formula=False)
        add('successor_recursion_' + str(len(rows)), E(R(S(n), a, h), reduct),
            [[]], expected=(True, True))
    add('negative_counter_is_not_numeral', E(R(-1, 0, 1), 0), [[]], expected=(False, False))
    add('rigid_and_flexible_are_distinct', E(1, 0), [None], [E(-1, 0)], (False, False))
    add('rigid_context_under_two_binders', ['q', ['q', E(-1, 0)]],
        [None, [], []], [E(-1, 0)], (True, True))
    add('positive_context_under_two_binders', ['q', ['q', E(3, 0)]],
        [None, [], []], [E(1, 0)], (True, True))
    add('existential_context_capture_attack', ['ex', E(1, 0)],
        [None, [1]], [E(1, 0)], (False, False))
    add('rigid_q_elimination', E(-8, 0),
        [None, None, [['q', E(1, 0)], -8]], [['q', E(1, 0)], truth], (True, True))
    add('rigid_equality_transport', E(0, -3),
        compiler.compile_proof([E(-3, 0), None, E(1, -3), reflexivity(-3)]),
        [E(-3, 0)], (True, True))

    malformed = [False, True, 0.0, 1.0, None, '0', [], ['s'], ['s', 0, 0],
                 ['r', 0, 0], ['r', 0, 0, E(0, 0)], ['q', truth], {'term': 0}]
    for index, bad in enumerate(malformed):
        add('unused_q_annotation_%02d' % index, truth,
            compiler.compile_proof(reflexivity(0)) + [None, [], [qtruth, bad]],
            expected=(True, False))
        add('used_q_annotation_%02d' % index, truth,
            [None, None, [qdependent, bad]], [qdependent, truth], (False, False))
        add('strict_ex_annotation_%02d' % index, ['ex', E(1, 1)],
            compiler.compile_proof(reflexivity(1)) + [[bad]], expected=(False, False))
    add('bool_zero_alias', E(False, 0), compiler.compile_proof(reflexivity(0)),
        expected=(False, False))
    add('bool_one_alias', E(True, 1), compiler.compile_proof(reflexivity(1)),
        expected=(False, False))

    for index, instruction in enumerate((None, False, True, 77, 'hyp', {}, [1, 2, 3], [])):
        add('hyp_fallback_%02d' % index, truth, [instruction], [truth], (True, True))
    add('failed_major_fallback_without_assumption', truth,
        [None, [falsehood, {'unused': True}]], expected=(False, False))
    add('failed_major_consumption_with_q', truth,
        [None, None, [falsehood, None], [qtruth, 0]], [qtruth, truth], (True, True))
    add('unused_prefix_rigid_reflexivity', E(-5, -5),
        [{'unread': ['bad', False]}, 0, None] + compiler.compile_proof(reflexivity(-5)),
        expected=(True, True))
    complete = compiler.compile_proof(reflexivity(0))
    for cut in range(len(complete)):
        add('truncated_q_stack_reflexivity_%d' % cut, truth, complete[:cut],
            expected=(False, False))
    add('reversed_q_stack_execution_order', truth, list(reversed(complete)),
        expected=(False, False))
    for name in ('report_recursion_zero', 'report_existence', 'report_numerical_closure'):
        document = json.loads((ROOT / ('examples/' + name + '.json')).read_text())
        add(name, document[0], document[1], expected=(True, True))
    return rows, skipped


def substitution_cases():
    terms = [0, 1, 2, 9, -1, -999, S(-2), R(1, -7, R(2, 1, S(5))),
             R(-2, 3, R(2, -1, R(1, 4, S(5))))]
    formulas = [E(1, -1), ['q', E(1, 2)], ['ex', ['q', E(3, -8)]],
                ['q', ['ex', E(R(2, 3, R(2, 1, S(5))), 3)]]]
    environments = [(1,), (3,), (0, 0), (S(1), 0), (-3, -1),
                    (R(1, -2, S(1)), S(-5), -2)]
    return [(data, env, depth, is_formula)
            for data, is_formula in [(x, False) for x in terms] + [(x, True) for x in formulas]
            for env in environments for depth in (0, 1, 2)]


def public_cases(rows):
    good = [E(-4, -4), compiler.compile_proof(reflexivity(-4))]
    bad = [E(0, S(0)), [None]]
    cases = [('theorem_with_rigid_parameter', good, (True, True)),
             ('falsehood', bad, (False, False)),
             ('third_field_context_injection', bad + [[bad[0]]], (False, False)),
             ('third_field_empty_context', good + [[]], (False, False)),
             ('missing_proof', [good[0]], (False, False)),
             ('null_document', None, (False, False)),
             ('object_document', {'goal': good[0], 'proof': good[1]}, (False, False)),
             ('proof_is_object', [good[0], {}], (False, False)),
             ('proof_is_null', [good[0], None], (False, False)),
             ('empty_proof', [good[0], []], (False, False))]
    selected = {'equation_rule_uses_retained_base', 'forbidden_quantified_induction_hypothesis',
                'unused_q_annotation_00', 'used_q_annotation_00', 'bool_zero_alias',
                'unused_prefix_rigid_reflexivity', 'negative_counter_is_not_numeral',
                'report_recursion_zero', 'report_existence', 'report_numerical_closure'}
    for row in rows:
        if row['name'] in selected and not row['context']:
            expected = tuple(oracle_run(row, strict)[0] for strict in (False, True))
            cases.append((row['name'], [row['goal'], row['stack']], expected))
    return cases


def main():
    transport = compiler.run()
    paths = [ROOT / 'checker_demand.py', ROOT / 'checker.py']
    modules = [load(path, path.stem + '_audit') for path in paths]
    rows, skipped = collect_rows()
    failures, outcomes = [], []
    reconstructed = repairs = fallback_reconstructions = prefix_reconstructions = 0
    for row in rows:
        record = {'name': row['name'], 'source': row['source'], 'accepted': []}
        for index, module in enumerate(modules):
            expected, expected_remaining, tree, oracle = oracle_run(row, bool(index))
            actual, remaining = candidate_run(module, row)
            record['accepted'].append(actual)
            if expected != actual or (actual and remaining != expected_remaining):
                failures.append({'type': 'oracle_mismatch', 'candidate': paths[index].name,
                                 'case': row, 'expected': expected, 'actual': actual,
                                 'expected_remaining': expected_remaining, 'remaining': remaining})
            stipulated = row.get('expected')
            if stipulated is not None and actual != stipulated[index]:
                failures.append({'type': 'targeted_expectation', 'case': row['name'],
                                 'candidate': paths[index].name, 'actual': actual})
            if actual and index == 0:
                named_tree = RigidOracle()
                independent_ok = named_tree.derive(named_tree.formula(row['goal']), tree,
                                                   [named_tree.formula(h) for h in row['context']])
                canonical = {'goal': row['goal'], 'stack': compiler.compile_proof(tree),
                             'context': row['context']}
                strict_ok, residue = candidate_run(modules[1], canonical)
                if not independent_ok or not strict_ok or residue:
                    failures.append({'type': 'reconstruction', 'case': row['name'],
                                     'named_tree': independent_ok, 'strict': strict_ok,
                                     'residue': residue})
                reconstructed += 1
                repairs += oracle.repaired_witnesses
                fallback_reconstructions += int(oracle.discarded_failed_majors > 0)
                prefix_reconstructions += int(bool(remaining))
        outcomes.append(record)

    comparisons = 0
    for data, env, depth, is_formula in substitution_cases():
        expected = named_substitution(data, env, depth, is_formula)
        for index, module in enumerate(modules):
            actual = module.subst(deepcopy(data), deepcopy(env), depth, is_formula)
            if actual != expected:
                failures.append({'type': 'substitution', 'candidate': paths[index].name,
                                 'data': data, 'environment': env, 'depth': depth,
                                 'expected': expected, 'actual': actual})
            comparisons += 1

    cli_runs = 0
    with tempfile.TemporaryDirectory() as temporary:
        for name, document, expected in public_cases(rows):
            fixture = Path(temporary) / (name + '.json')
            fixture.write_text(json.dumps(document))
            for index, path in enumerate(paths):
                for optimized in (False, True):
                    run = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                          str(path), str(fixture)],
                                         text=True, capture_output=True, timeout=15)
                    if (run.returncode != (0 if expected[index] else 1)
                            or run.stdout.strip() != ('ACCEPT' if expected[index] else 'REJECT')):
                        failures.append({'type': 'cli', 'name': name,
                                         'candidate': path.name, 'optimized': optimized,
                                         'code': run.returncode, 'stdout': run.stdout,
                                         'stderr': run.stderr})
                    cli_runs += 1

    source = paths[0].read_text()
    faults = [
        ('unrestricted_formula_induction', "([b] if b[0] == '=' else [])", '[b]',
         'forbidden_quantified_induction_hypothesis'),
        ('omitted_elimination_minor', 'return c == a and check(b, p, g)', 'return c == a',
         'q_elimination_missing_base'),
        ('existential_target_not_lifted', 'b, h = subst(a), parts', 'b, h = a, parts',
         'existential_eigenvariable_escape'),
        ('retained_context_not_lifted', '[*map(subst, g), *h]', '[*g, *h]',
         'existential_context_capture_attack'),
        ('boolean_integer_alias', 'type(a) is int', 'isinstance(a, int)', 'bool_zero_alias'),
        ('recursor_binders_not_counted', "'r': b'\\0\\0\\2'", "'r': b'\\0\\0\\0'",
         'nested_recursion_capture_avoided'),
    ]
    sensitivity = []
    by_name = {row['name']: row for row in rows}
    for name, before, after, fixture in faults:
        if source.count(before) != 1:
            failures.append({'type': 'mutation_point_missing', 'fault': name})
            continue
        namespace = {'__name__': 'audit_fault'}
        exec(compile(source.replace(before, after, 1), '<deliberate_fault>', 'exec'), namespace)
        mutant = type('Mutant', (), {'check': staticmethod(namespace['check'])})
        row = by_name[fixture]
        correct = candidate_run(modules[0], row)[0]
        altered = candidate_run(mutant, row)[0]
        detected = correct != altered
        sensitivity.append({'fault': name, 'fixture': fixture, 'detected': detected,
                            'correct_acceptance': correct, 'faulty_acceptance': altered})
        if not detected:
            failures.append({'type': 'mutation_not_detected', 'fault': name})

    counts = {}
    for row in rows:
        counts[row['source']] = counts.get(row['source'], 0) + 1
    result = {
        'status': 'passed' if not failures else 'failed',
        'python_version': sys.version.split()[0],
        'checker_sha256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},
        'named_reference_sha256': hashlib.sha256((HERE / 'named_reference.py').read_bytes()).hexdigest(),
        'fixture_sources': counts,
        'fixture_count': len(rows),
        'candidate_comparisons': 2 * len(rows),
        'demand_accepts': sum(row['accepted'][0] for row in outcomes),
        'strict_accepts': sum(row['accepted'][1] for row in outcomes),
        'accepted_demand_proofs_reconstructed_and_rechecked': reconstructed,
        'malformed_unused_witnesses_repaired': repairs,
        'failed_major_fallbacks_reconstructed': fallback_reconstructions,
        'accepted_unused_prefixes_removed': prefix_reconstructions,
        'named_substitution_cases': len(substitution_cases()),
        'named_substitution_candidate_comparisons': comparisons,
        'public_cli_runs': cli_runs,
        'source_tree_transport': {key: value for key, value in transport.items() if key != 'cases'},
        'fault_sensitivity': sensitivity,
        'excluded_legacy_cases': skipped,
        'outcomes': outcomes,
        'failures': failures,
        'limits': 'Finite regression and reconstruction evidence, not a machine-checked general '
                  'soundness theorem. Internal contextual tests validate their assumptions; '
                  'the public candidate always starts from an empty context.',
    }
    (ROOT / 'results/validation.json').write_text(json.dumps(result, indent=2) + '\n')
    (HERE / 'cases.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('outcomes', 'excluded_legacy_cases', 'failures')}, indent=2))
    print('Failures:', len(failures))
    if failures:
        print(json.dumps(failures[:5], indent=2))
        raise SystemExit(1)


if __name__ == '__main__':
    main()
