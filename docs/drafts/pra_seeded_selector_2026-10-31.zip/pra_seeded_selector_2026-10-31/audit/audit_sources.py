#!/usr/bin/env python3
"""Hash the exact four reviewed GitHub ZIPs and the incoming index.

Usage:
  python3 audit_sources.py --manifest sources.json \
      --source-root /path/to/downloaded/repository/files

No network request is made and no archive code is executed. The source manifest
contains immutable GitHub URLs, expected byte sizes, and expected Git blob SHA-1
identifiers. The output adds verified SHA-256 identifiers and a TeX inventory.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    result = {
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "scope": {
            "drafts": "All four ZIP archives present in docs/drafts at this commit were reviewed.",
            "incoming": "Directory inventory and README searched; no PRA-labelled archive or PRA entry found. Unrelated archives were not unpacked.",
            "prior_snapshots": "Earlier reports cited inside the current drafts were not part of this four-archive comparison set.",
        },
        "files": [],
    }
    for item in manifest["files"]:
        path = args.source_root / item["path"]
        raw = path.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        if blob != item["blob_sha"] or len(raw) != item["size"]:
            raise ValueError(f"Git identity or byte size mismatch: {item['path']}")
        entry = dict(item)
        entry.update(sha256=hashlib.sha256(raw).hexdigest(), git_blob_verified=True,
                     byte_size_verified=True)
        if path.suffix == ".zip":
            with zipfile.ZipFile(path) as archive:
                if archive.testzip() is not None:
                    raise ValueError(f"Corrupt ZIP: {item['path']}")
                names = sorted(archive.namelist())
                for name in names:
                    pp = PurePosixPath(name)
                    if pp.is_absolute() or ".." in pp.parts:
                        raise ValueError(f"Unsafe ZIP member: {name}")
                entry["tex_members"] = [name for name in names if name.endswith(".tex")]
                entry["archive_members"] = len(names)
        else:
            entry["role"] = "incoming-index scope check"
        result["files"].append(entry)
    if len(result["files"]) != 5:
        raise ValueError("Expected four draft ZIPs and one incoming README")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
