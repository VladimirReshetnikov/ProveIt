/-
  PRA transposition: a constructive, FINITE-SYNTAX kernel.
  Checked with Lean 4.19.0. No imports, global axioms, or classical reasoning.

  The schema ranges over Term, not arbitrary functions on the arithmetic domain.
  Term has three variable slots and binary symbols. Additional binary symbols
  have completely arbitrary interpretations, so every extension by further
  initialized-iteration descriptions is covered by the same proof.

  Only two explicit descriptions are used in the kernel:
     R = I_{(k,v) |-> k},       B = I_{(k,v) |-> 0}.
  The selector C(x,u,v)=R(B(x,Su),v) uses no addition theorem.
  Two fixed term families bootstrap separation, zero decision, and coverage.
  A single-delay term compiles arbitrary one-parameter equation induction.

  Certified: substitution composition; literal boundary identity; evaluation
  of substituted finite terms; separation; successor laws; zero decision;
  selector laws; constructor coverage; full equation induction for finite
  terms; and the reverse schema instance from its quantifier-free induction
  instance.

  Scope: this is a syntax-scoped semantic proof of the constructive kernel.
  It does not encode the well-founded iterator declarations or a first-order
  proof calculus, and does not formalize the full comparator/pairing theorem.
-/

namespace FiniteSeededSelector

universe u

inductive Fn where
  | seededPredecessor
  | gate
  | other (index : Nat)

inductive Term where
  | first
  | second
  | parameter
  | zero
  | succ (argument : Term)
  | app (function : Fn) (left right : Term)

def instantiate : Term → Term → Term → Term → Term
  | .first, x, _, _ => x
  | .second, _, y, _ => y
  | .parameter, _, _, a => a
  | .zero, _, _, _ => .zero
  | .succ t, x, y, a => .succ (instantiate t x y a)
  | .app f s t, x, y, a =>
      .app f (instantiate s x y a) (instantiate t x y a)

def one : Term := .succ .zero
def rTerm (x a : Term) : Term := .app .seededPredecessor x a
def predTerm (x : Term) : Term := rTerm x .zero
def gateTerm (x a : Term) : Term := .app .gate x a
def selectorTerm (x a b : Term) : Term := rTerm (gateTerm x (.succ a)) b

def swapLeft (h : Term) : Term := instantiate h .first one .parameter
def swapRight (h : Term) : Term := instantiate h one .first .parameter
def boundary (h : Term) : Term := instantiate h one .zero .parameter

theorem instantiate_comp (t x y a z w b : Term) :
    instantiate (instantiate t x y a) z w b =
      instantiate t (instantiate x z w b) (instantiate y z w b)
        (instantiate a z w b) := by
  induction t with
  | first => rfl
  | second => rfl
  | parameter => rfl
  | zero => rfl
  | succ t ih => exact congrArg Term.succ ih
  | app f s t ihs iht =>
      have q := congr (congrArg (Term.app f) ihs) iht
      exact q

theorem boundary_reflexive (h : Term) :
    boundary (swapLeft h) = boundary (swapRight h) := by
  unfold boundary swapLeft swapRight
  rw [instantiate_comp, instantiate_comp]
  rfl

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  function : Fn → A → A → A
  r_zero : ∀ a, function .seededPredecessor zero a = a
  r_succ : ∀ n a, function .seededPredecessor (succ n) a = n
  b_zero : ∀ a, function .gate zero a = a
  b_succ : ∀ n a, function .gate (succ n) a = zero

def r {A : Type u} (C : Arithmetic A) : A → A → A :=
  C.function .seededPredecessor
def pred {A : Type u} (C : Arithmetic A) (x : A) : A := r C x C.zero
def gate {A : Type u} (C : Arithmetic A) : A → A → A := C.function .gate
def select {A : Type u} (C : Arithmetic A) (x a b : A) : A :=
  r C (gate C x (C.succ a)) b

def eval {A : Type u} (C : Arithmetic A) : Term → A → A → A → A
  | .first, x, _, _ => x
  | .second, _, y, _ => y
  | .parameter, _, _, a => a
  | .zero, _, _, _ => C.zero
  | .succ t, x, y, a => C.succ (eval C t x y a)
  | .app f s t, x, y, a =>
      C.function f (eval C s x y a) (eval C t x y a)

def value {A : Type u} (C : Arithmetic A) (t : Term) (n a : A) : A :=
  eval C t n C.zero a

variable {A : Type u} (C : Arithmetic A)

theorem eval_instantiate (t x y b : Term) (n m a : A) :
    eval C (instantiate t x y b) n m a =
      eval C t (eval C x n m a) (eval C y n m a) (eval C b n m a) := by
  induction t with
  | first => rfl
  | second => rfl
  | parameter => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | app f s t ihs iht =>
      have q := congr (congrArg (C.function f) ihs) iht
      exact q

theorem r_zero (a : A) : r C C.zero a = a := C.r_zero a
theorem r_succ (x a : A) : r C (C.succ x) a = x := C.r_succ x a
theorem pred_zero : pred C C.zero = C.zero := C.r_zero C.zero
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.r_succ x C.zero
theorem gate_zero (a : A) : gate C C.zero a = a := C.b_zero a
theorem gate_succ (x a : A) : gate C (C.succ x) a = C.zero := C.b_succ x a

theorem select_zero (a b : A) : select C C.zero a b = a := by
  unfold select
  rw [gate_zero C, r_succ C]

theorem select_succ (x a b : A) : select C (C.succ x) a b = b := by
  unfold select
  rw [gate_succ C, r_zero C]

theorem eval_selector (x a b : Term) (n m c : A) :
    eval C (selectorTerm x a b) n m c =
      select C (eval C x n m c) (eval C a n m c) (eval C b n m c) := rfl

def Cross (h : Term) (n a : A) : Prop :=
  eval C h n (C.succ C.zero) a = eval C h (C.succ C.zero) n a

def SwapSchema : Prop :=
  ∀ (h : Term) (a : A),
    (∀ n, Cross C h n a → Cross C h (C.succ n) a) →
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ Cross C h n a

def gateContext : Term := gateTerm .first .parameter
def coverageContext : Term :=
  selectorTerm (predTerm .first) .second (.succ (predTerm .first))
def equationContext (s t : Term) : Term :=
  selectorTerm (predTerm .first)
    (instantiate t (predTerm .second) .zero .parameter)
    (instantiate s (predTerm .first) .zero .parameter)

theorem eval_coverage_context (x y a : A) :
    eval C coverageContext x y a = select C (pred C x) y (C.succ (pred C x)) := rfl

theorem eval_equation_context (s t : Term) (x y a : A) :
    eval C (equationContext s t) x y a =
      select C (pred C x) (value C t (pred C y) a) (value C s (pred C x) a) := by
  unfold equationContext
  rw [eval_selector C, eval_instantiate C, eval_instantiate C]
  rfl

variable (H : SwapSchema C)
include H

theorem gate_bootstrap (a : A) :
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ gate C n a = C.zero := by
  have h := H gateContext a (by
    intro n _
    change gate C (C.succ n) a = gate C (C.succ C.zero) a
    rw [gate_succ C, gate_succ C])
  refine ⟨h.1, ?_⟩
  intro n
  rcases h.2 n with hz | he
  · exact Or.inl hz
  · apply Or.inr
    change gate C n a = gate C (C.succ C.zero) a at he
    rw [gate_succ C] at he
    exact he

theorem separation : C.zero ≠ C.succ C.zero := (gate_bootstrap C H C.zero).1

theorem gate_nonzero (x a : A) (hx : x ≠ C.zero) : gate C x a = C.zero := by
  rcases (gate_bootstrap C H a).2 x with hz | he
  · exact False.elim (hx hz)
  · exact he

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases (gate_bootstrap C H (C.succ C.zero)).2 x with hz | he
  · exact Or.inl hz
  · apply Or.inr
    intro hz
    rw [hz, gate_zero C] at he
    exact separation C H he.symm

theorem select_nonzero (x a b : A) (hx : x ≠ C.zero) : select C x a b = b := by
  unfold select
  rw [gate_nonzero C H x (C.succ a) hx, r_zero C]

theorem select_equal (x a : A) : select C x a a = a := by
  rcases zero_decision C H x with hz | hn
  · rw [hz, select_zero C]
  · exact select_nonzero C H x a a hn

omit H in
theorem successor_injective {x y : A} (he : C.succ x = C.succ y) : x = y := by
  have hp := congrArg (pred C) he
  rw [pred_succ C, pred_succ C] at hp
  exact hp

theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro bad
  have hx := congrArg (pred C) bad
  rw [pred_succ C, pred_zero C] at hx
  have hOne : C.succ C.zero = C.zero := (congrArg C.succ hx).symm.trans bad
  exact separation C H hOne.symm

theorem coverage_context_right (x a : A) :
    eval C coverageContext x (C.succ C.zero) a = C.succ (pred C x) := by
  rw [eval_coverage_context C]
  rcases zero_decision C H (pred C x) with hz | hn
  · rw [hz, select_zero C]
  · exact select_nonzero C H (pred C x) (C.succ C.zero) (C.succ (pred C x)) hn

omit H in
theorem coverage_context_left (x a : A) :
    eval C coverageContext (C.succ C.zero) x a = x := by
  rw [eval_coverage_context C, pred_succ C, select_zero C]

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  have h := H coverageContext C.zero (by
    intro n _
    unfold Cross
    rw [coverage_context_right C H, coverage_context_left C, pred_succ C])
  rcases h.2 x with hz | he
  · exact Or.inl hz
  · unfold Cross at he
    rw [coverage_context_right C H, coverage_context_left C] at he
    exact Or.inr he.symm

theorem equation_context_iff (s t : Term) (a : A)
    (base : value C s C.zero a = value C t C.zero a) (n : A) :
    Cross C (equationContext s t) n a ↔
      value C s (pred C n) a = value C t (pred C n) a := by
  unfold Cross
  rw [eval_equation_context C, eval_equation_context C, pred_succ C, select_zero C]
  rcases zero_decision C H (pred C n) with hz | hn
  · rw [hz, select_zero C]
    exact ⟨fun _ => base, fun _ => rfl⟩
  · rw [select_nonzero C H (pred C n) _ _ hn]

theorem equation_induction (s t : Term) (a : A)
    (base : value C s C.zero a = value C t C.zero a)
    (step : ∀ n, value C s n a = value C t n a →
      value C s (C.succ n) a = value C t (C.succ n) a) :
    ∀ n, value C s n a = value C t n a := by
  have hs := H (equationContext s t) a (by
    intro n hn
    have he := (equation_context_iff C H s t a base n).1 hn
    apply (equation_context_iff C H s t a base (C.succ n)).2
    rw [pred_succ C]
    rcases coverage C H n with hz | hnSucc
    · rw [hz]
      exact base
    · rw [hnSucc] at he ⊢
      rw [pred_succ C] at he
      exact step (pred C n) he)
  intro n
  rcases hs.2 (C.succ n) with bad | good
  · exact False.elim (successor_ne_zero C H n bad)
  · have he := (equation_context_iff C H s t a base (C.succ n)).1 good
    rw [pred_succ C] at he
    exact he

theorem identity_induction (s : Term) (a : A)
    (base : value C s C.zero a = C.zero)
    (step : ∀ n, value C s n a = n → value C s (C.succ n) a = C.succ n) :
    ∀ n, value C s n a = n := equation_induction C H s .first a base step

theorem zero_equation_induction (s : Term) (a : A)
    (base : value C s C.zero a = C.zero)
    (step : ∀ n, value C s n a = C.zero → value C s (C.succ n) a = C.zero) :
    ∀ n, value C s n a = C.zero := equation_induction C H s .zero a base step

omit H in
def GuardedCrossInduction (h : Term) (a : A) : Prop :=
  (C.zero = C.zero ∨ Cross C h C.zero a) →
  (∀ n, (n = C.zero ∨ Cross C h n a) →
    (C.succ n = C.zero ∨ Cross C h (C.succ n) a)) →
  ∀ n, n = C.zero ∨ Cross C h n a

omit H in
theorem reverse_instance (h : Term) (a : A)
    (sep : C.zero ≠ C.succ C.zero)
    (ind : GuardedCrossInduction C h a)
    (step : ∀ n, Cross C h n a → Cross C h (C.succ n) a) :
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ Cross C h n a := by
  refine ⟨sep, ind (Or.inl rfl) ?_⟩
  intro n hn
  apply Or.inr
  rcases hn with hz | he
  · rw [hz]
    exact Eq.refl _
  · exact step n he

#print axioms instantiate_comp
#print axioms boundary_reflexive
#print axioms eval_instantiate
#print axioms select_zero
#print axioms select_succ
#print axioms gate_bootstrap
#print axioms separation
#print axioms zero_decision
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms coverage
#print axioms equation_context_iff
#print axioms equation_induction
#print axioms identity_induction
#print axioms zero_equation_induction
#print axioms reverse_instance

end FiniteSeededSelector
