# A Smaller Constructive Kernel for PRA

Prepared for Vladimir Reshetnikov, 31 October 2026.

## Result and limits

The same nonlogical basis works with classical first-order equality logic
and intuitionistic first-order equality logic. It consists of initialized
iteration and the literal-boundary schema RB, equivalently its one-term
transposition subfamily.

The four current ProveIt drafts already contain the 39-node RB arithmetic
formula. This report does **not** claim a shorter complete arithmetic schema.
Its new result is a simpler constructive kernel:

    R(0,a) = a       R(Sn,a) = n
    B(0,a) = a       B(Sn,a) = 0
    C(x,u,v) = R(B(x,Su),v)

The selector has 6 raw term nodes instead of 13. Both constructor branches
reduce in exactly two defining-equation rewrites. Only R and B are needed
before general equation induction; the previous best proof also needed
addition and the theorem n+1=Sn. Both proofs use two fixed bootstrap contexts.
The new contexts are longer in aggregate (14 nodes versus 8), so the
improvement is specifically in the selector and proof dependencies.

The paper also proves that a shorter backward-diagonal candidate fails
intuitionistically, using a three-node Kripke countermodel. Its classical
completeness is not established. Constant-boundary-target completeness is
also left open, with proved partial consequences stated explicitly.

## Contents

- `pra_seeded_selector.pdf`: complete research paper.
- `pra_seeded_selector.tex`: main LaTeX source.
- `backward_candidate.tex`: included section with the backward candidate,
  proved consequences, exact parameter costs, and constructive countermodel.
- `axioms.txt`: exact plain-text specification and scope.
- `formal/FiniteSeededSelector.lean`: checked finite-syntax constructive kernel.
- `formal/finite_verification.log`: Lean 4.19.0 dependency audit.
- `artifacts/check_syntax.py`: symbolic syntax and raw-rewrite certificates.
- `artifacts/syntax_certificates.json`: recorded output of that checker.
- `artifacts/schema_metrics.py`: independent formula and term-size audit.
- `artifacts/schema_metrics.json`: recorded metric results.
- `audit/sources.json`: immutable source commit, URLs, sizes and hashes.
- `audit/comparison.json`: detailed comparison with all four current drafts.
- `audit/audit_sources.py`: optional replay of source hash checks.
- `audit/verification_summary.json`: summary of checks and formal scope.
- `SHA256SUMS`: integrity hashes of the packaged files (excluding itself).

## Reproduce

Build the paper with a normal TeX Live installation:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error pra_seeded_selector.tex
```

Check the constructive kernel with Lean 4.19.0 (no external packages):

```sh
lean formal/FiniteSeededSelector.lean
```

All sixteen printed axiom-dependency audits should report no axioms.
The explicit theorem hypotheses still include the computation equations
and the finite-term transposition schema. This is a semantic verification
of the constructive kernel over actual finite term syntax, not a formalized
first-order proof calculus or a machine proof of the entire definitional
equivalence theorem. Comparator, pairing, and translation correctness are
proved in the paper.

Run the symbolic checks with Python 3.10 or later:

```sh
python3 artifacts/check_syntax.py
python3 artifacts/schema_metrics.py
```

They do not require network access or third-party packages. They do not
execute code from the reviewed archives. They check literal boundaries,
raw computation rewrites and syntax counts, not universal arithmetic by
finite numerical testing.

The prior source archives are not duplicated in this package. To replay
their byte-identity checks, download the exact immutable URLs listed in
`audit/sources.json`, preserving their `docs/drafts/` and `docs/incoming/`
paths under a directory of your choice, then run:

```sh
python3 audit/audit_sources.py --manifest audit/sources.json --source-root /path/to/downloaded/files
```

## Source snapshot

Repository: `VladimirReshetnikov/ProveIt`

Commit: `66372d99e4f4e1d3a48822b9d322ae9e9ae7e7e3`

Reviewed all four ZIP archives currently in `docs/drafts` at that commit,
plus the directory inventory and README of `docs/incoming`. No PRA-labelled
incoming archive or PRA entry was found. Unrelated archive interiors were
not reviewed. Earlier snapshots mentioned inside the four drafts were not
mistaken for the current comparison set.

The iteration grammar, RB/Swap axiom families, single-delay compiler,
subtraction reconstruction, triangular pairing, and stored-parameter
simulation are inherited and credited. The manuscript identifies the new
selector and gate-first bootstrap separately from those prior ingredients.
