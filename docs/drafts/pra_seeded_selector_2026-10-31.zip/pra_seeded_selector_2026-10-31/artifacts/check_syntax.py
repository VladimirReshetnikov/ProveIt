#!/usr/bin/env python3
"""Check finite syntax and raw computation certificates for the seeded selector.

This checks symbolic syntax, not bounded numerical instances of arithmetic.
Only the four equations R(0,a)=a, R(Sn,a)=n, B(0,a)=a, B(Sn,a)=0
are available to the rewrite engine. A, F, and G remain uninterpreted binary
symbols. The Lean certificate supplies the universal substitution theorem.
No external Python dependencies are required.
"""

from __future__ import annotations

import argparse
import json
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Term:
    tag: str
    name: str = ""
    args: tuple["Term", ...] = ()

    def __str__(self) -> str:
        if self.tag == "var":
            return self.name
        if self.tag == "zero":
            return "0"
        if self.tag == "succ":
            return f"S({self.args[0]})"
        return f"{self.name}({self.args[0]},{self.args[1]})"


def var(name: str) -> Term:
    return Term("var", name)


ZERO = Term("zero")


def succ(t: Term) -> Term:
    return Term("succ", args=(t,))


ONE = succ(ZERO)


def app(name: str, left: Term, right: Term) -> Term:
    return Term("app", name, (left, right))


def pred(t: Term) -> Term:
    return app("R", t, ZERO)


def gate(t: Term, seed: Term) -> Term:
    return app("B", t, seed)


def choose(test: Term, yes: Term, no: Term) -> Term:
    return app("R", gate(test, succ(yes)), no)


def substitute(t: Term, env: dict[str, Term]) -> Term:
    if t.tag == "var":
        return env.get(t.name, t)
    return Term(t.tag, t.name, tuple(substitute(a, env) for a in t.args))


def size(t: Term) -> int:
    return 1 + sum(size(a) for a in t.args)


def free_variables(t: Term) -> set[str]:
    if t.tag == "var":
        return {t.name}
    return set().union(*(free_variables(a) for a in t.args))


def root_rewrite(t: Term) -> tuple[str, Term] | None:
    if t.tag != "app" or t.name not in {"R", "B"}:
        return None
    count, seed = t.args
    if count == ZERO:
        return (t.name + "0", seed)
    if count.tag == "succ":
        if t.name == "R":
            return ("RS", count.args[0])
        return ("BS", ZERO)
    return None


def one_step(t: Term) -> Iterable[tuple[Term, tuple[int, ...], str]]:
    top = root_rewrite(t)
    if top is not None:
        rule, result = top
        yield result, (), rule
    for index, child in enumerate(t.args):
        for changed, path, rule in one_step(child):
            children = list(t.args)
            children[index] = changed
            yield Term(t.tag, t.name, tuple(children)), (index,) + path, rule


def shortest_rewrite(source: Term, target: Term, max_steps: int) -> list[dict]:
    """Exhaustively search the finite raw-rewrite tree up to max_steps."""
    queue = deque([(source, [])])
    seen = {source}
    while queue:
        current, steps = queue.popleft()
        if current == target:
            return steps
        if len(steps) == max_steps:
            continue
        for result, path, rule in one_step(current):
            if result in seen:
                continue
            seen.add(result)
            entry = {
                "rule": rule,
                "path": list(path),
                "before": str(current),
                "after": str(result),
            }
            queue.append((result, steps + [entry]))
    raise AssertionError(f"No certificate within {max_steps} steps: {source} -> {target}")


def boundary_certificate(name: str, h: Term) -> dict:
    assert free_variables(h) <= {"x", "y", "a"}
    n = var("n")
    left = substitute(h, {"x": n, "y": ONE})
    right = substitute(h, {"x": ONE, "y": n})
    left_at_one = substitute(left, {"n": ONE})
    right_at_one = substitute(right, {"n": ONE})
    assert left_at_one == right_at_one
    return {
        "name": name,
        "term": str(h),
        "free_variables": sorted(free_variables(h)),
        "left_boundary": str(left_at_one),
        "right_boundary": str(right_at_one),
        "literal_identity": True,
        "computation_rewrites": 0,
    }


def equation_context(s: Term, t: Term) -> Term:
    assert free_variables(s) <= {"n", "a"}
    assert free_variables(t) <= {"n", "a"}
    x, y = var("x"), var("y")
    return choose(
        pred(x),
        substitute(t, {"n": pred(y)}),
        substitute(s, {"n": pred(x)}),
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().with_name("syntax_certificates.json"),
    )
    options = parser.parse_args()

    n, x, y, a, u, v = (var(q) for q in ("n", "x", "y", "a", "u", "v"))
    rewrite_certificates = []
    for name, source, target in [
        ("selector_at_zero", choose(ZERO, u, v), u),
        ("selector_at_successor", choose(succ(n), u, v), v),
    ]:
        steps = shortest_rewrite(source, target, 2)
        assert len(steps) == 2  # BFS also excludes a zero- or one-step proof.
        rewrite_certificates.append({
            "name": name,
            "source": str(source),
            "target": str(target),
            "shortest_raw_rewrite_length": len(steps),
            "steps": steps,
        })

    boundaries = [
        boundary_certificate("gate", gate(x, a)),
        boundary_certificate("coverage", choose(pred(x), y, succ(pred(x)))),
    ]

    # All inputs below are finite terms in the genuine binary signature.
    # Repeated occurrences are intentional: substitution must replace all of
    # them, and no evaluation of F, G, or A may be smuggled into admission.
    samples = [
        ("constant_targets", ZERO, ONE),
        ("identity_and_parameter", n, a),
        ("repeat_left", app("F", n, n), app("G", n, a)),
        ("repeat_both", app("F", n, app("F", a, n)),
            app("G", app("G", n, n), a)),
        ("nested_computation_symbols", app("R", succ(n), gate(a, n)),
            gate(n, app("R", n, succ(a)))),
        ("uninterpreted_addition", app("A", n, a), app("A", a, n)),
    ]
    for name, s, t in samples:
        certificate = boundary_certificate("equation_context_" + name, equation_context(s, t))
        certificate["input_s"] = str(s)
        certificate["input_t"] = str(t)
        boundaries.append(certificate)

    new_selector = choose(x, u, v)
    old_selector = pred(app("A", gate(x, u), succ(gate(gate(x, ONE), v))))
    assert size(new_selector) == 6
    assert size(old_selector) == 13

    result = {
        "certificate_format": 1,
        "scope": "Finite symbolic syntax and raw R/B rewrites; no bounded numerical proof.",
        "raw_rules": ["R(0,a)->a", "R(S(n),a)->n", "B(0,a)->a", "B(S(n),a)->0"],
        "rewrite_certificates": rewrite_certificates,
        "literal_boundary_certificates": boundaries,
        "node_metric": "Every variable, zero, successor, and binary function application counts one node; p and 1 are expanded.",
        "selector_sizes": {
            "previous": {"term": str(old_selector), "nodes": size(old_selector)},
            "seeded": {"term": str(new_selector), "nodes": size(new_selector)},
            "node_reduction": size(old_selector) - size(new_selector),
        },
        "all_checks_passed": True,
    }
    options.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "raw_rewrite_certificates": len(rewrite_certificates),
        "literal_boundary_certificates": len(boundaries),
        "selector_nodes_old_new": [size(old_selector), size(new_selector)],
        "all_checks_passed": True,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
