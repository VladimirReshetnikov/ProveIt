#!/usr/bin/env python3
"""Recompute the report's formula and raw-selector tree sizes.

An AST node is one occurrence of a variable, constant, application, equality,
connective, falsity, or quantifier. Bound-variable names are labels, not extra
term occurrences. Numeral 1 is S(0), and negation is implication to falsity.
Schematic term applications count their displayed argument trees. This is a
formula metric, not a total-description-length or shortest-proof metric.
"""
from __future__ import annotations

import json
from typing import NamedTuple


class Node(NamedTuple):
    tag: str
    children: tuple["Node", ...] = ()


def app(tag: str, *args: Node) -> Node:
    return Node(tag, args)


def size(tree: Node) -> int:
    return 1 + sum(map(size, tree.children))


def occurrences(tree: Node, tag: str) -> int:
    return int(tree.tag == tag) + sum(occurrences(t, tag) for t in tree.children)


def prefix(tree: Node) -> str:
    if not tree.children:
        return tree.tag
    return tree.tag + "(" + ",".join(map(prefix, tree.children)) + ")"


zero, n, a, z, u, v, x, y = map(Node, ("0", "n", "a", "z", "u", "v", "x", "y"))
S = lambda t: app("S", t)
one = S(zero)
eq = lambda p, q: app("=", p, q)
imp = lambda p, q: app("implies", p, q)
conj = lambda p, q: app("and", p, q)
disj = lambda p, q: app("or", p, q)
all_n = lambda p: app("forall_n", p)
all_a = lambda p: app("forall_a", p)
separation = imp(eq(zero, one), Node("bottom"))


def schema(E) -> Node:
    return all_a(imp(all_n(imp(E(n), E(S(n)))),
                     conj(separation, all_n(disj(eq(n, zero), E(n))))))


literal_boundary = schema(lambda t: eq(app("s", t, a), app("t", t, a)))
swap = schema(lambda t: eq(app("H", t, one, a), app("H", one, t, a)))

R = lambda p, q: app("R", p, q)
A = lambda p, q: app("A", p, q)
B = lambda p, q: app("B", p, q)
pred = lambda p: R(p, zero)
old_selector = R(A(B(z, u), S(B(B(z, one), v))), zero)
new_selector = R(B(z, S(u)), v)
choose = lambda c, p, q: R(B(c, S(p)), q)

old_contexts = [A(x, y), A(pred(x), y)]
new_contexts = [B(x, a), choose(pred(x), y, S(pred(x)))]


def raw_reduce_root(tree: Node) -> Node:
    """One D0/DS rewrite for R=I_counter or B=I_zero."""
    if tree.tag not in ("R", "B") or len(tree.children) != 2:
        raise ValueError("Not an R/B redex")
    index, seed = tree.children
    if index == zero:
        return seed
    if index.tag == "S" and len(index.children) == 1:
        return index.children[0] if tree.tag == "R" else zero
    raise ValueError("No constructor at the recursion index")


def selector_trace(index: Node, expected: Node) -> list[str]:
    start = choose(index, u, v)
    middle = R(raw_reduce_root(start.children[0]), v)
    end = raw_reduce_root(middle)
    assert end == expected
    return list(map(prefix, (start, middle, end)))


def main() -> None:
    assert size(literal_boundary) == 39
    assert size(swap) == 51
    assert occurrences(literal_boundary, "=") == occurrences(swap, "=") == 5
    assert size(old_selector) == 13
    assert size(new_selector) == 6
    result = {
        "metric": __doc__.strip(),
        "arithmetic_schemata": {
            "literal_boundary_RB": {"nodes": size(literal_boundary),
                                     "equalities": occurrences(literal_boundary, "="),
                                     "prefix_ast": prefix(literal_boundary)},
            "unrestricted_swap": {"nodes": size(swap),
                                  "equalities": occurrences(swap, "="),
                                  "prefix_ast": prefix(swap)},
        },
        "raw_selectors": {
            "prior_reflexive_base": {"nodes": size(old_selector),
                                     "prefix_ast": prefix(old_selector)},
            "seeded_predecessor": {"nodes": size(new_selector),
                                   "prefix_ast": prefix(new_selector)},
        },
        "selector_raw_rewrite_certificates": {
            "zero_branch": selector_trace(zero, u),
            "successor_branch": selector_trace(S(z), v),
            "rewrites_per_branch": 2,
        },
        "fixed_bootstrap_contexts": {
            "prior_reflexive_base": {"individual_nodes": list(map(size, old_contexts)),
                                     "total_nodes": sum(map(size, old_contexts)),
                                     "prefix_asts": list(map(prefix, old_contexts))},
            "seeded_predecessor": {"individual_nodes": list(map(size, new_contexts)),
                                   "total_nodes": sum(map(size, new_contexts)),
                                   "prefix_asts": list(map(prefix, new_contexts))},
        },
        "interpretation": [
            "The arithmetic axiom schemata are unchanged: 39 nodes or 51 nodes.",
            "The selector shrinks from 13 raw nodes to 6 and loses addition.",
            "Both proofs use two fixed bootstrap context families.",
            "The new fixed contexts are larger in aggregate (14 versus 8 raw nodes).",
            "The improvement is in the selector and proof dependencies, not every size metric.",
        ],
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
