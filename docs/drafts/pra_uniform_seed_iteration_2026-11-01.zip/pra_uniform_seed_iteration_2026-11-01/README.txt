PRA BY UNARY ITERATION WITH PREDECESSOR INITIALIZATION
Research package prepared for Vladimir Reshetnikov, 1 November 2026.

MAIN RESULT
One uniform binary family with unary updates replaces the special counter
operation K and ordinary iterators:

  A_h(0,0)=0,  A_h(0,S(a))=a,  A_h(S(n),a)=h(A_h(n,a)).

Predecessor p(a)=A_id(0,a) and ordinary iteration I_h(n,a)=A_h(n,S(a))
follow directly. Add separation and QF induction with one scalar parameter.
This is definitionally equivalent to matching first-order PRA.

A compressed version has one nonlogical propagation schema with a precise
three-pattern root gate. It uses two individual variable names. The
intuitionistic version includes a fixed zero-decidability matrix.

The report proves both internal identity round trips, not just mutual
interpretability. It includes the one-parameter arithmetic bootstrap and
explicit parameter coding before it is used.

FILES
  report.pdf / report.tex  Main paper and LaTeX master
  sections/               Additional LaTeX sources
  AXIOMS.txt              Complete extractable formal specification
  formal/SeedKernel.lean   Constructive local conversion kernel (main theory)
  formal/StutteringKernel.lean
                          Constructive local kernel (alternative)
  formal/*.log            Actual Lean 4.19.0 compiler outputs
  formal/SCOPE.txt         Exact scope of formal verification
  checks/check_seed_spec.py
                          Main finite-syntax / bounded-semantic checker
  checks/check_spec.py     Shared syntax code and alternative checker
  checks/*results.json    Reproducible finite-check reports
  audit/                  Source hashes, reviews, build and validation evidence
  build.py                Rebuild checks and PDF; optionally rerun Lean
  SHA256SUMS.txt           Checksums for delivered files

BUILD
  python3 build.py
requires Python 3 and pdflatex (standard TeX Live packages).

To check Lean too, provide Lean 4.19.0:
  python3 build.py --lean /absolute/path/to/lean

The scripts use only the Python standard library. The LaTeX source has
relative include paths and requires no external images or bibliography files.

CLAIM BOUNDARIES
This is a simplification of the current uniform scalar generator, not an
absolute shortestness theorem. Root-template nodes fall 25->20 and closed
computation-template nodes 31->23 under the disclosed partial convention.
The opaque outer schema remains 15. Initializing at predecessor is an
explicit change to strict pure iteration, not a proof of the old unchanged
pure-iteration predecessor conjecture.

Lean verifies the new local conversions under an explicit semantic equation-
induction hypothesis. The full first-order language, gate, arithmetic
compiler, and bi-interpretability theorem are written proofs, not a complete
Lean formalization. Python finite checks are not arbitrary-model proofs.

The comparison covers the five ZIPs in ProveIt/docs/drafts at commit
9e793b1080d95e3fdd1537ba475e67e639d84f20. Exact URLs and hashes are in
audit/source_manifest.json. No repository content was modified.
