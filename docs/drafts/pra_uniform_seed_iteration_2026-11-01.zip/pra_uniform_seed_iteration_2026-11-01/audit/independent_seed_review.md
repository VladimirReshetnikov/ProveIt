# Independent audit: predecessor-seeded unary iteration

## Candidate

For each earlier unary body h(v), introduce binary A_h and postulate

A_h(0,0)=0,
A_h(0,Sa)=a,
A_h(Sn,a)=h(A_h(n,a)).

Use 0!=S0 and one-parameter qf induction in matching classical or intuitionistic FOL. For the compressed atomic presentation, use the supplied exact root gate plus bare stationary quantified equations, Sep, and the intuitionistic zero-decision exception.

## Main verdict

The candidate has a correct internal reduction to and from the current scalar K/I basis, with no nonstandard-carrier or hidden-parameter gap found. It eliminates the exceptional K symbol and the counter input from every update body. The cost is a uniform constructor inspection of the seed in the initialization clause. This is not ordinary pure iteration, and should not be described as solving the old pure-iteration-only predecessor question.

## The essential seed lemma

Let p(a)=A_id(0,a), where id(v)=v. Its two predecessor equations p(0)=0 and p(Sa)=a are direct instances, requiring no induction.

For each h, prove A_h(0,a)=p(a) by **parameter-free equation induction on a**. At zero both sides are 0. At Sa both sides are a, independently of the induction hypothesis. Do not justify this identity by silently assuming that every carrier element is 0 or a successor: that coverage has not yet been established at this point.

Define I_h(n,a)=A_h(n,Sa). The seed and successor equations for ordinary pure iteration then compute directly. Define

K(n,a)=I_S(p(n),I_0(n,a)).

At zero this gives a. At Sn it gives I_S(n,0)=n, the latter by parameter-free equation induction. Thus all old K/I computation equations are recovered using at most one frozen parameter, and usually none.

## Reverse interpretation

In the old K/I basis define p(a)=K(a,0) and

A_h(n,a)=I_h(n,p(a)).

The three displayed A equations follow directly from p(0)=0, p(Sa)=a and the I equations. Update bodies remain unary after translation; no seed variable or counter variable is inserted freely into an update descriptor.

## Internal identity round trips

Both signature translations preserve every free variable and every ordinary logical operation. They are defined by external induction on finite descriptor dependencies.

* For an A symbol, the returned term has the same initial value p(a), by the seed lemma, and the same pointwise unary update after the earlier descriptor round-trip identities have been proved. Equation induction on n with seed a frozen proves equality with A_h(n,a).
* For an I symbol, the returned term has initial value a and the same update; the usual equation induction proves equality.
* For K, both returned and original terms satisfy K(0,a)=a and K(Sn,a)=n. Equation induction proves equality; its successor step ignores the induction hypothesis.
* If one directly uses the expanded translation of old p=K(-,0), its returned term is equal to the new p by parameter-free equation induction, since both have the predecessor equations.

No positivity, excluded middle, full induction, coded satisfaction predicate, or uniform evaluator is used in these round-trip arguments. Each finite descriptor translates to a finite term using already translated descriptions. Same-sort identity interpretations therefore give common conservative definitional extensions once full qf induction with arbitrary parameters has been reconstructed by the supplied arithmetic/pairing proof.

## Compressed-gate checks

The exact root operation is:

rho(A_h(0,0))=0,
rho(A_h(0,Ss))=s,
rho(A_h(Ss,t))=h(A_h(s,t)).

It is undefined at A_h(0,a) for a variable a. The mathematical seed lemma is not a normalization rule in admission. This distinction is covered by an explicit rejection test.

Equation induction is recovered by the padded consequent A_0(0,S(t(n,a)))=s(n,a); one root step removes the padding. The negative probe is (n=a)->A_0(0,S0)=a. Stationary computation probes can all be bare forall-n equations, with the same bound n name used by the outer schema, because all its occurrences in that branch are already bound. Capture-free substitution must leave that entire stationary matrix unchanged.

The successor stationary probe is forall n [A_h(Sa,n)=h(A_h(a,n))]; outer a and inner n remain independently arbitrary. Thus no successor argument is accidentally identified with its seed.

## Honest comparison

Using active AST nodes, one node per equality/rewrite/quantifier/application, and an opaque unary h application:

- Old four K/I root templates: 25; new three A root templates: 20.
- Old universally closed K/I computation templates: 31; new A computation templates: 23.
- The inherited opaque propagation display remains 15.

These are specified local subledgers. They exclude descriptor metadata, the logic and the full axiom-generator implementation. The new pattern matcher inspects the seed constructor when its counter is zero; the delayed alternative inspects only the counter. The unrestricted binary-update R language still has two recursion patterns but a richer update grammar, so this candidate is not a universal Pareto improvement under all measures.

## Artifacts

`check_seed_spec.py` (which imports sibling `check_spec.py`) records 1,485 successful finite diagnostics. `check_spec.py` independently records 1,216 diagnostics for the stuttering-delay alternative. Neither executable is a proof of the arbitrary-model arithmetic or of the bi-interpretations; the latter are the written internal arguments above and in the report.
