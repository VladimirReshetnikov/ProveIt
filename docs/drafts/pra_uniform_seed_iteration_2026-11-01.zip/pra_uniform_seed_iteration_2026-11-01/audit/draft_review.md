# Independent audit of the five current PRA drafts

Snapshot: `9e793b1080d95e3fdd1537ba475e67e639d84f20`, `docs/drafts`.

## Scope and confidence

Read all five report specifications, logical kernels, product interpretation arguments, and the scalar arithmetic/pairing details. This is a mathematical review of the written proofs, not a fully formal verification. No fatal defect was found in their main matching-logic bi-interpretability arguments. Their qualifications about what the number 15 does and does not count are essential.

## Comparison

| Archive | Main language | Outer schema | Admission / positive content | Main contribution |
|---|---|---|---|---|
| `pra_literal_zero_2026-11-01.zip` | Scalar 0,S and binary recursors indexed by binary updates | Universal-conclusion 15 | Oriented equation and zero specialization; exact stationary initializer, successor, separation; one wrapped zero-decision matrix intuitionistically | Smaller literal grammar; constructive zero-decision-to-coverage bootstrap |
| `pra_smaller_generator_2026-11-01.zip` | Scalar 0,S,K, unary-state iterators | Universal-conclusion 15 | Exactly one root unfolding in designated left consequent term; stationary quantified implications; Sep; direct D(n) intuitionistically | Narrow deterministic root gate; no zero-rewrite branch; unary updates except fixed counter projection K |
| `pra_two_names_reflexive_2026-11-01.zip` | Scalar 0,S,K, unary-state iterators | Universal-conclusion 15 | Implications of atoms/bottom plus bare stationary quantified equations; zero/one local replacement; fixed coverage matrix intuitionistically | Bare stationary equation replaces quantified implication; two individual names by safe shadowing |
| `pra_product_iteration_2026-11-01.zip` | Finite product types, 0,S, uniform unary-state iterators | Endpoint 15, endpoint pi_1(a) | Four literal zero-instance shapes; full qf matrices | Eliminates exceptional counter update; structural parameter packing; no extra intuitionistic exception |
| `pra_product_iteration_2026-11-01 (1).zip` | Same product language, explicit scalar expansion | Universal-conclusion 15 | Three literal base shapes: guarded reflexivity (B or delta)->B, initializer, successor | Merges separation into guarded reflexivity; complete scalar expanded version and constructive identity round trips |

There is no unqualified single smallest member. The product variant has the shortest natural correctness argument and only three base shapes, but uses product structure / unbounded scalar arities. The scalar drafts preserve binary arity and one scalar parameter, at the expense of a much longer internal coding proof and either special quantified matrices or a slot restriction.

## Bi-interpretability checkpoints

1. The target is explicitly first-order PRA_c or PRA_i: qf induction, unrestricted ambient first-order formulas. This differs in logical interface from the original free-variable PRA calculus. Each paper treats the two ambient logics separately.
2. Both interpretations use the whole number carrier and native equality. The scalar papers prove native equality decidable before truth-term compilation; they do not silently replace equality by an arithmetic surrogate.
3. Scalar parameter coding is proved before it is used to obtain arbitrarily many induction parameters. In the unary-update draft, the tail-splitting lemma is deliberately diagonal; its proof uses only one frozen parameter.
4. Product papers include beta and eta, or eliminate products by an explicit scalar coordinate expansion. Beta alone would allow junk product elements; eta is correctly retained for genuine product sorts.
5. The forward compiler stores the counter and frozen parameters in the iteration state. The invariant is qf and available before reverse numerical coding is used.
6. Reverse product iteration is encoded in ordinary PRA by a finite PR pairing/decoding construction. Only left-inverse decoding is needed for the basic reverse interpretation. The endpoint paper also explains a bijective coding variant.
7. Both composite interpretations are checked internally via uniqueness under qf equality induction. They claim common ordinary definitional extensions only for same-sort scalar theories, and use Morita/product terminology for the genuine sorted version.
8. The stored update descriptor is syntax and is not traversed by ordinary object-variable substitution. Each definition has finite well-founded dependencies. Formula matrices may use the complete generated language; restricting them to early symbols would break the intended induction strength.

## Intuitionistic checkpoint

The negative/universal scalar computational fragment cannot derive zero-decidability on the native carrier. The papers' fork Kripke model (root N^2, two projection leaves) is an appropriate congruence/quotient semantics for intuitionistic equality, and the negative-fragment root/leaf induction is sound. It establishes nonderivability of the native positive principle, not failure of every conceivable alternate interpretation.

The literal-zero construction correctly obtains coverage from D(x): decide z(a)=0; in the positive branch an equation-induction identity yields a=S(p(a)); in the negative branch the reverse probe (n=a)->(0=a) gives a=0. It never uses coverage to establish that equation identity.

The product papers allow all qf matrices, so positive coverage is an ordinary qf induction instance. Thus their same generator can work for both ambient logics without an additional special positive matrix.

## Limits that should remain explicit

* 15 is an opaque-template AST subtotal, not a finite axiomatization size or whole-generator code length.
* The scalar diagonal 14-node formula is still unproved. It merges the endpoint and parameter before an internally established numerical packing operation is available.
* The displayed pure scalar predecessor in smaller_generator is only proved correct on standard N. Its dyadic/interval argument is not yet an internal proof in the predecessor-free weak source theory.
* No paper gives end-to-end Lean/Rocq verification of the entire description language, logical proof system, compiler, and internal round trips. The checked kernels and executable diagnostics have smaller stated scopes.
* Combining the literal-zero positive lemma, the two-name bare stationary equation, and the smaller root gate would be a valid incremental refinement, but not a new global simplicity record.
