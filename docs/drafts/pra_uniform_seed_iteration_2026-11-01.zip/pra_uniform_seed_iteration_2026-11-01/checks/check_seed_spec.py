#!/usr/bin/env python3
"""Exact syntax and bounded diagnostics for predecessor-seeded unary iteration.

Run beside check_spec.py, which supplies the shared finite-tree implementation.
This is a diagnostic, not a formal proof of the arbitrary-model theorem.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

import check_spec as core

Node = core.Node
V, ZERO, BOT, S = core.V, core.ZERO, core.BOT, core.S
Eq, Imp, Or, All = core.Eq, core.Imp, core.Or, core.All
fv, names, subst, size = core.fv, core.names, core.subst, core.size
admit, outer = core.admit, core.outer
n, a, b, v = V("n"), V("a"), V("b"), V("v")


def A(index: int, counter: Node, seed: Node) -> Node:
    return Node("seeded", (counter, seed), index)


class SeedDescriptions(core.Descriptions):
    def term_ok(self, node: Node, before: int | None = None) -> bool:
        limit = len(self.bodies) if before is None else before
        if node.tag == "zero":
            return not node.args and node.value is None
        if node.tag == "var":
            return not node.args and isinstance(node.value, str)
        if node.tag == "succ":
            return (node.value is None and len(node.args) == 1
                    and self.term_ok(node.args[0], limit))
        if node.tag == "seeded":
            return (type(node.value) is int and 0 <= node.value < limit
                    and len(node.args) == 2
                    and all(self.term_ok(x, limit) for x in node.args))
        return False

    def rho(self, node: Node) -> Node | None:
        if not self.term_ok(node) or node.tag != "seeded":
            return None
        count, seed = node.args
        index = int(node.value)
        if count == ZERO:
            if seed == ZERO:
                return ZERO
            if seed.tag == "succ":
                return seed.args[0]
            return None
        if count.tag == "succ":
            return self.apply(index, A(index, count.args[0], seed))
        return None


def evaluate(node: Node, environment: dict[str, int], registry: SeedDescriptions) -> int:
    if node.tag == "zero":
        return 0
    if node.tag == "var":
        return environment[str(node.value)]
    if node.tag == "succ":
        return evaluate(node.args[0], environment, registry) + 1
    if node.tag == "seeded":
        count = evaluate(node.args[0], environment, registry)
        seed = evaluate(node.args[1], environment, registry)
        state = max(seed - 1, 0)
        body = registry.bodies[int(node.value)]
        for _ in range(count):
            state = evaluate(body, {"v": state}, registry)
        return state
    raise ValueError(f"Not a predecessor-seeded term: {node.tag}")


def truth(node: Node, environment: dict[str, int], registry: SeedDescriptions) -> bool:
    if node.tag == "bottom":
        return False
    if node.tag == "eq":
        return evaluate(node.args[0], environment, registry) == evaluate(
            node.args[1], environment, registry)
    if node.tag == "imp":
        return not truth(node.args[0], environment, registry) or truth(
            node.args[1], environment, registry)
    if node.tag == "or":
        return truth(node.args[0], environment, registry) or truth(
            node.args[1], environment, registry)
    if node.tag == "and":
        return truth(node.args[0], environment, registry) and truth(
            node.args[1], environment, registry)
    raise ValueError("Only quantifier-free truth is evaluated")


class OrdinaryTranslation(core.OrdinaryTranslation):
    """Dependency-preserving A_h(n,a) -> I_h*(n,p(a))."""
    def term(self, node: Node) -> Node:
        if node.tag == "seeded":
            index = int(node.value)
            if not 0 <= index < len(self.bodies):
                raise ValueError("A translation encountered a forward dependency")
            count, seed = (self.term(x) for x in node.args)
            return Node("iterate", (count, Node("pred", (seed,))), index)
        return Node(node.tag, tuple(self.term(x) for x in node.args), node.value)


def run() -> dict:
    checks = core.Checks()
    registry = SeedDescriptions()
    zero_update = registry.add(ZERO)
    successor = registry.add(S(v))
    identity = registry.add(v)
    double = registry.add(A(successor, v, S(v)))
    nested = registry.add(A(successor, A(identity, ZERO, v), v))
    checks.raises(lambda: registry.add(a), "reject a frozen update parameter")
    checks.raises(lambda: registry.add(A(len(registry.bodies), v, ZERO)),
                  "reject self-reference / forward dependency")
    checks.raises(lambda: registry.add(Eq(v, v)), "reject a formula as an update")

    accepted: list[Node] = []
    for index in range(len(registry.bodies)):
        base_zero = Imp(Eq(ZERO, ZERO), Eq(A(index, ZERO, ZERO), ZERO))
        base_successor = Imp(Eq(a, a), Eq(A(index, ZERO, S(a)), a))
        for label, probe in (("00", base_zero), ("0S", base_successor)):
            checks.check(admit(registry, probe, False) == "A",
                         f"ordinary extraction {index}/{label}")
            accepted.append(probe)
        stat_zero = All("n", Eq(A(index, ZERO, ZERO), ZERO))
        stat_successor = All("n", Eq(A(index, ZERO, S(n)), n))
        stat_step = All("n", Eq(A(index, S(a), n),
                                registry.apply(index, A(index, a, n))))
        for label, probe in (("00", stat_zero), ("0S", stat_successor),
                             ("S", stat_step)):
            checks.check(admit(registry, probe, False) == "B",
                         f"stationary extraction {index}/{label}")
            checks.check(subst(probe, "n", ZERO) == probe
                         and subst(probe, "n", S(n)) == probe,
                         f"bound induction name protected {index}/{label}")
            accepted.append(probe)
        # A successor counter always uses the update branch, even at seed 0.
        checks.check(registry.rho(A(index, S(n), ZERO))
                     == registry.apply(index, A(index, n, ZERO)),
                     f"successor-counter branch at zero seed {index}")

    equations = [Eq(n, a), Eq(S(n), S(a)),
                 Eq(A(double, n, a), A(successor, a, n)),
                 Eq(A(nested, S(n), A(identity, a, n)), ZERO)]
    for index, equation in enumerate(equations):
        left, right = equation.args
        padded = Imp(subst(equation, "n", ZERO),
                     Eq(A(zero_update, ZERO, S(left)), right))
        checks.check(admit(registry, padded, False) == "A",
                     f"equation induction via shifted seed {index}")
        accepted.append(padded)
    negative = Imp(Eq(n, a), Eq(A(zero_update, ZERO, S(ZERO)), a))
    checks.check(admit(registry, negative, False) == "A", "negative atomic probe")
    accepted.append(negative)
    checks.check(admit(registry, core.SEP, False) == "Sep", "classical separation")
    checks.check(admit(registry, core.SEP, True) == "Sep", "intuitionistic separation")
    checks.check(admit(registry, core.DECIDE_ZERO, False) is None,
                 "classical gate has no special decision exception")
    checks.check(admit(registry, core.DECIDE_ZERO, True) == "D",
                 "intuitionistic zero decision exception")
    accepted.extend((core.SEP, core.DECIDE_ZERO))

    rejected = {
        "unknown seed constructor is not unfolded":
            All("n", Eq(A(successor, ZERO, n), A(identity, ZERO, n))),
        "unknown counter is not unfolded":
            Imp(Eq(a, a), Eq(A(successor, a, S(a)), a)),
        "nonroot rewrite":
            Imp(Eq(S(a), a), Eq(S(A(zero_update, ZERO, S(a))), a)),
        "two unfoldings needed":
            Imp(Eq(S(a), a), Eq(A(successor, S(ZERO), S(a)), a)),
        "right-hand rewrite is not allowed":
            Imp(Eq(a, a), Eq(A(zero_update, ZERO, S(a)),
                            A(zero_update, ZERO, S(a)))),
        "antecedent-only rewrite is not allowed":
            Imp(Eq(A(zero_update, ZERO, S(a)), a), Eq(a, a)),
        "wrong update body":
            All("n", Eq(A(successor, S(a), n), A(successor, a, n))),
        "reversed stationary equation":
            All("n", Eq(S(A(successor, a, n)), A(successor, S(a), n))),
        "wrong stationary binder":
            All("b", Eq(A(successor, S(a), b), S(A(successor, a, b)))),
        "extra free variable":
            All("n", Eq(A(successor, S(b), n), S(A(successor, b, n)))),
        "nested quantification":
            All("n", All("a", Eq(A(identity, ZERO, S(a)), a))),
        "unknown description":
            Imp(Eq(a, a), Eq(A(1000, ZERO, S(a)), a)),
        "reflexivity without a root unfolding": Imp(Eq(n, a), Eq(n, a)),
    }
    for label, matrix in rejected.items():
        checks.check(admit(registry, matrix, True) is None, label)

    old_bodies = tuple(registry.bodies)
    term_with_private_name = A(identity, n, v)
    checks.check(subst(term_with_private_name, "v", ZERO) == A(identity, n, ZERO)
                 and tuple(registry.bodies) == old_bodies,
                 "object substitution leaves description bodies immutable")
    checks.check(registry.rho(A(identity, S(n), a)) == A(identity, n, a),
                 "stored identity update still sees its private state variable")
    captured = subst(All("a", Eq(n, a)), "n", a)
    checks.check(fv(captured) == {"a"} and captured.value != "a",
                 "capture-free substitution control")
    for index, matrix in enumerate(accepted):
        generated = outer(matrix)
        checks.check(not fv(generated) and names(generated) <= {"n", "a"},
                     f"closed two-name emitted axiom {index}")

    def App(name: str, *arguments: Node) -> Node:
        return Node("opaque", tuple(arguments), name)

    def Rewrite(left: Node, right: Node) -> Node:
        return Node("rewrite", (left, right))

    old_rules = [Rewrite(App("K", ZERO, a), a),
                 Rewrite(App("K", S(n), a), n),
                 Rewrite(App("I", ZERO, a), a),
                 Rewrite(App("I", S(n), a), App("h", App("I", n, a)))]
    seed_rules = [Rewrite(App("A", ZERO, ZERO), ZERO),
                  Rewrite(App("A", ZERO, S(a)), a),
                  Rewrite(App("A", S(n), a), App("h", App("A", n, a)))]
    old_equations = [All("a", Eq(*old_rules[0].args)),
                     All("n", All("a", Eq(*old_rules[1].args))),
                     All("a", Eq(*old_rules[2].args)),
                     All("n", All("a", Eq(*old_rules[3].args)))]
    seed_equations = [Eq(*seed_rules[0].args),
                      All("a", Eq(*seed_rules[1].args)),
                      All("n", All("a", Eq(*seed_rules[2].args)))]
    counts = {
        "old_root_rules": sum(map(size, old_rules)),
        "seeded_root_rules": sum(map(size, seed_rules)),
        "old_closed_computation_equations": sum(map(size, old_equations)),
        "seeded_closed_computation_equations": sum(map(size, seed_equations)),
        "opaque_outer_schema": size(outer(App("F", n, a))),
        "zero_decision_matrix": size(core.DECIDE_ZERO),
    }
    checks.check(counts == {
        "old_root_rules": 25,
        "seeded_root_rules": 20,
        "old_closed_computation_equations": 31,
        "seeded_closed_computation_equations": 23,
        "opaque_outer_schema": 15,
        "zero_decision_matrix": 9,
    }, "exact exposed AST counts")

    ordinary = OrdinaryTranslation(registry)
    for index in range(len(registry.bodies)):
        for count in range(7):
            for seed in range(6):
                environment = {"n": count, "a": seed}
                term = A(index, n, a)
                checks.check(evaluate(term, environment, registry)
                             == ordinary.evaluate(ordinary.term(term), environment),
                             "nested descriptor translation", "translation_cases")
                checks.check(evaluate(A(index, ZERO, ZERO), environment, registry) == 0
                             and evaluate(A(index, ZERO, S(a)), environment, registry)
                             == seed, "two constructor seed clauses", "equation_cases")
                checks.check(evaluate(A(index, S(n), a), environment, registry)
                             == evaluate(registry.apply(index, A(index, n, a)),
                                         environment, registry),
                             "ordinary counter step", "equation_cases")

    def I(index: int, counter: Node, seed: Node) -> Node:
        return A(index, counter, S(seed))

    pred_n = A(identity, ZERO, n)
    pred_a = A(identity, ZERO, a)
    projection = I(successor, pred_n, I(zero_update, n, a))
    for count in range(9):
        for seed in range(7):
            environment = {"n": count, "a": seed}
            checks.check(evaluate(pred_n, environment, registry) == max(count - 1, 0),
                         "derived predecessor", "derived_function_cases")
            checks.check(evaluate(projection, environment, registry)
                         == (seed if count == 0 else count - 1),
                         "derived exceptional K", "derived_function_cases")
            for index in (zero_update, successor, double, nested):
                checks.check(evaluate(A(index, n, a), environment, registry)
                             == evaluate(I(index, n, pred_a), environment, registry),
                             "A equals I with predecessor seed", "roundtrip_cases")
                checks.check(evaluate(A(index, ZERO, a), environment, registry)
                             == evaluate(pred_a, environment, registry),
                             "all updates have the same initial predecessor",
                             "initialization_cases")

    for matrix in accepted:
        if matrix.tag == "all":
            continue
        base = subst(matrix, "n", ZERO)
        for seed in range(7):
            checks.check(truth(base, {"n": 0, "a": seed}, registry),
                         "accepted qf base", "base_cases")

    return {
        "status": "PASS",
        "scope": "Finite syntax, exposed AST counts, bounded standard-number diagnostics",
        "not_proved_by_this_program": [
            "The arbitrary-model arithmetic reconstruction",
            "Internal primitive-recursion completeness",
            "The first-order bi-interpretations and identity round trips",
            "An encoding-independent minimum",
        ],
        "tradeoff": "The initializer inspects the seed constructor as well as the counter",
        "descriptor_count": len(registry.bodies),
        "check_counts": checks.counts,
        "total_checks": sum(checks.counts.values()),
        "ast_counts": counts,
        "syntax_check_names": checks.named,
    }


if __name__ == "__main__":
    result = run()
    rendered = json.dumps(result, indent=2)
    if len(sys.argv) > 2:
        raise SystemExit("Usage: python3 check_seed_spec.py [report.json]")
    if len(sys.argv) == 2:
        Path(sys.argv[1]).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
