#!/usr/bin/env python3
"""Finite diagnostics for delayed-iteration PRA's exact syntactic specification.

This program checks syntax, selected admission examples, exposed AST counts,
and bounded standard-number evaluations. It is not a proof of the arbitrary-
model arithmetic or bi-interpretability theorem. Only the standard library is
used. A nonzero exit indicates a failed check; assertions are not used.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import sys


@dataclass(frozen=True)
class Node:
    tag: str
    args: tuple["Node", ...] = ()
    value: str | int | None = None


def V(name: str) -> Node:
    return Node("var", value=name)


ZERO = Node("zero")
BOT = Node("bottom")


def S(term: Node) -> Node:
    return Node("succ", (term,))


def D(index: int, counter: Node, seed: Node) -> Node:
    return Node("delayed", (counter, seed), index)


def Eq(left: Node, right: Node) -> Node:
    return Node("eq", (left, right))


def Imp(left: Node, right: Node) -> Node:
    return Node("imp", (left, right))


def Or(left: Node, right: Node) -> Node:
    return Node("or", (left, right))


def All(name: str, body: Node) -> Node:
    return Node("all", (body,), name)


def fv(node: Node) -> frozenset[str]:
    if node.tag == "var":
        return frozenset((str(node.value),))
    found = frozenset().union(*(fv(child) for child in node.args))
    if node.tag == "all":
        return found - {str(node.value)}
    return found


def names(node: Node) -> frozenset[str]:
    found = frozenset().union(*(names(child) for child in node.args))
    if node.tag in {"var", "all"}:
        return found | {str(node.value)}
    return found


def subst(node: Node, variable: str, replacement: Node) -> Node:
    """Capture-free active-tree substitution; descriptor indices are opaque."""
    if node.tag == "var":
        return replacement if node.value == variable else node
    if node.tag == "all":
        binder = str(node.value)
        if binder == variable:
            return node
        body = node.args[0]
        if binder in fv(replacement) and variable in fv(body):
            occupied = names(body) | names(replacement) | {variable}
            suffix = 0
            fresh = f"_{binder}{suffix}"
            while fresh in occupied:
                suffix += 1
                fresh = f"_{binder}{suffix}"
            body = subst(body, binder, V(fresh))
            binder = fresh
        return All(binder, subst(body, variable, replacement))
    return Node(node.tag, tuple(subst(x, variable, replacement)
                                for x in node.args), node.value)


def size(node: Node) -> int:
    """Every active node counts once; binder labels and metadata do not."""
    return 1 + sum(size(child) for child in node.args)


class Descriptions:
    def __init__(self) -> None:
        self.bodies: list[Node] = []

    def term_ok(self, node: Node, before: int | None = None) -> bool:
        limit = len(self.bodies) if before is None else before
        if node.tag == "zero":
            return not node.args and node.value is None
        if node.tag == "var":
            return not node.args and isinstance(node.value, str)
        if node.tag == "succ":
            return (node.value is None and len(node.args) == 1
                    and self.term_ok(node.args[0], limit))
        if node.tag == "delayed":
            return (type(node.value) is int and 0 <= node.value < limit
                    and len(node.args) == 2
                    and all(self.term_ok(x, limit) for x in node.args))
        return False

    def formula_ok(self, node: Node) -> bool:
        if node.tag == "bottom":
            return not node.args and node.value is None
        if node.tag == "eq":
            return (node.value is None and len(node.args) == 2
                    and all(self.term_ok(x) for x in node.args))
        if node.tag in {"imp", "or", "and"}:
            return (node.value is None and len(node.args) == 2
                    and all(self.formula_ok(x) for x in node.args))
        if node.tag == "all":
            return (len(node.args) == 1 and isinstance(node.value, str)
                    and self.formula_ok(node.args[0]))
        return False

    def add(self, body: Node) -> int:
        index = len(self.bodies)
        if not self.term_ok(body, index) or not fv(body) <= {"v"}:
            raise ValueError("An update must be an earlier term in v alone")
        self.bodies.append(body)
        return index

    def apply(self, index: int, argument: Node) -> Node:
        return subst(self.bodies[index], "v", argument)

    def rho(self, node: Node) -> Node | None:
        if not self.term_ok(node) or node.tag != "delayed":
            return None
        counter, seed = node.args
        index = int(node.value)
        if counter == ZERO:
            return seed
        if counter == S(ZERO):
            return seed
        if (counter.tag == "succ" and counter.args[0].tag == "succ"):
            previous = counter.args[0]  # SSs -> Ss, without unfolding further.
            return self.apply(index, D(index, previous, seed))
        return None


N, A, B, STATE = V("n"), V("a"), V("b"), V("v")
SEP = Imp(Eq(ZERO, S(ZERO)), BOT)
DECIDE_ZERO = Or(Eq(N, ZERO), Imp(Eq(N, ZERO), BOT))


def admit(registry: Descriptions, matrix: Node, intuitionistic: bool) -> str | None:
    if not registry.formula_ok(matrix):
        return None
    if matrix == SEP:
        return "Sep"
    if intuitionistic and matrix == DECIDE_ZERO:
        return "D"
    if not fv(matrix) <= {"n", "a"}:
        return None
    if (matrix.tag == "imp" and matrix.args[0].tag == "eq"
            and matrix.args[1].tag == "eq"):
        zero_instance = subst(matrix, "n", ZERO)
        left, right = zero_instance.args
        s, t = left.args
        u, v = right.args
        reduced = registry.rho(u)
        if reduced is not None and reduced == s and v == t:
            return "A"
    if (matrix.tag == "all" and matrix.value == "n"
            and matrix.args[0].tag == "eq"):
        u, v = matrix.args[0].args
        if fv(u) | fv(v) <= {"a", "n"}:
            reduced = registry.rho(u)
            if reduced is not None and reduced == v:
                return "B"
    return None


def outer(matrix: Node) -> Node:
    return All("a", Imp(All("n", Imp(matrix, subst(matrix, "n", S(N)))),
                        All("n", matrix)))


def evaluate(node: Node, environment: dict[str, int], registry: Descriptions) -> int:
    if node.tag == "zero":
        return 0
    if node.tag == "var":
        return environment[str(node.value)]
    if node.tag == "succ":
        return evaluate(node.args[0], environment, registry) + 1
    if node.tag == "delayed":
        counter = evaluate(node.args[0], environment, registry)
        state = evaluate(node.args[1], environment, registry)
        body = registry.bodies[int(node.value)]
        for _ in range(max(counter - 1, 0)):
            state = evaluate(body, {"v": state}, registry)
        return state
    raise ValueError(f"Not a source term: {node.tag}")


def truth(node: Node, environment: dict[str, int], registry: Descriptions) -> bool:
    """Only qf formulas: no bounded replacement for actual universal truth."""
    if node.tag == "bottom":
        return False
    if node.tag == "eq":
        return evaluate(node.args[0], environment, registry) == evaluate(
            node.args[1], environment, registry)
    if node.tag == "imp":
        return not truth(node.args[0], environment, registry) or truth(
            node.args[1], environment, registry)
    if node.tag == "or":
        return truth(node.args[0], environment, registry) or truth(
            node.args[1], environment, registry)
    if node.tag == "and":
        return truth(node.args[0], environment, registry) and truth(
            node.args[1], environment, registry)
    raise ValueError("Truth diagnostics accept only quantifier-free formulas")


class OrdinaryTranslation:
    """Translate D_h(n,a) into I_h*(p(n),a) in dependency order."""
    def __init__(self, source: Descriptions) -> None:
        self.bodies: list[Node] = []
        self.source = source
        for body in source.bodies:
            self.bodies.append(self.term(body))

    def term(self, node: Node) -> Node:
        if node.tag == "delayed":
            index = int(node.value)
            if not 0 <= index < len(self.bodies):
                raise ValueError("A translation encountered a forward dependency")
            n, a = (self.term(x) for x in node.args)
            return Node("iterate", (Node("pred", (n,)), a), index)
        return Node(node.tag, tuple(self.term(x) for x in node.args), node.value)

    def evaluate(self, node: Node, environment: dict[str, int]) -> int:
        if node.tag == "zero":
            return 0
        if node.tag == "var":
            return environment[str(node.value)]
        if node.tag == "succ":
            return self.evaluate(node.args[0], environment) + 1
        if node.tag == "pred":
            return max(self.evaluate(node.args[0], environment) - 1, 0)
        if node.tag == "iterate":
            count = self.evaluate(node.args[0], environment)
            state = self.evaluate(node.args[1], environment)
            for _ in range(count):
                state = self.evaluate(self.bodies[int(node.value)], {"v": state})
            return state
        raise ValueError(f"Not an ordinary translated term: {node.tag}")


class Checks:
    def __init__(self) -> None:
        self.counts: dict[str, int] = {}
        self.named: list[str] = []

    def check(self, condition: bool, name: str, group: str = "syntax") -> None:
        if not condition:
            raise RuntimeError(f"CHECK FAILED: {name}")
        self.counts[group] = self.counts.get(group, 0) + 1
        if group == "syntax":
            self.named.append(name)

    def raises(self, operation, name: str) -> None:
        try:
            operation()
        except ValueError:
            self.check(True, name)
            return
        self.check(False, name)


def run() -> dict:
    checks = Checks()
    registry = Descriptions()
    zero_update = registry.add(ZERO)
    successor = registry.add(S(STATE))
    identity = registry.add(STATE)
    double = registry.add(D(successor, S(STATE), STATE))
    nested = registry.add(D(successor, D(successor, STATE, ZERO), STATE))
    checks.raises(lambda: registry.add(A), "reject a frozen update parameter")
    checks.raises(lambda: registry.add(D(len(registry.bodies), STATE, ZERO)),
                  "reject self-reference / forward dependency")
    checks.raises(lambda: registry.add(Eq(STATE, STATE)),
                  "reject a formula as an update body")

    accepted: list[Node] = []
    for index in range(len(registry.bodies)):
        for seed_counter, label in ((ZERO, "0"), (S(ZERO), "1")):
            probe = Imp(Eq(A, A), Eq(D(index, seed_counter, A), A))
            checks.check(admit(registry, probe, False) == "A",
                         f"A initialization extraction {index}/{label}")
            accepted.append(probe)
            stationary = All("n", Eq(D(index, seed_counter, N), N))
            checks.check(admit(registry, stationary, False) == "B",
                         f"B initialization extraction {index}/{label}")
            accepted.append(stationary)
        step = All("n", Eq(D(index, S(S(A)), N),
                           registry.apply(index, D(index, S(A), N))))
        checks.check(admit(registry, step, False) == "B",
                     f"B SS extraction {index}")
        checks.check(subst(step, "n", ZERO) == step
                     and subst(step, "n", S(N)) == step,
                     f"stationary bound n protected {index}")
        accepted.append(step)

    equations = [Eq(N, A), Eq(S(N), S(A)),
                 Eq(D(double, N, A), D(successor, A, N)),
                 Eq(D(nested, S(N), D(identity, A, N)), ZERO)]
    for index, equation in enumerate(equations):
        left, right = equation.args
        padded = Imp(subst(equation, "n", ZERO),
                     Eq(D(zero_update, ZERO, left), right))
        checks.check(admit(registry, padded, False) == "A",
                     f"arbitrary-equation induction padding {index}")
        accepted.append(padded)
    negative = Imp(Eq(N, A), Eq(D(zero_update, ZERO, ZERO), A))
    checks.check(admit(registry, negative, False) == "A", "negative atomic probe")
    accepted.append(negative)
    checks.check(admit(registry, SEP, False) == "Sep", "classical separation")
    checks.check(admit(registry, SEP, True) == "Sep", "intuitionistic separation")
    checks.check(admit(registry, DECIDE_ZERO, False) is None,
                 "no classical special zero-decision matrix")
    checks.check(admit(registry, DECIDE_ZERO, True) == "D",
                 "intuitionistic zero-decision matrix")
    accepted.extend([SEP, DECIDE_ZERO])

    rejections = {
        "nonroot redex": Imp(Eq(S(A), A), Eq(S(D(zero_update, ZERO, A)), A)),
        "two unfoldings needed": Imp(Eq(S(A), A),
                                     Eq(D(successor, S(S(ZERO)), A), A)),
        "antecedent rewrite only": Imp(Eq(D(zero_update, ZERO, A), A), Eq(A, A)),
        "right term requires rewrite": Imp(Eq(A, A),
                                           Eq(D(zero_update, ZERO, A),
                                              D(zero_update, ZERO, A))),
        "wrong stored update": All("n", Eq(D(successor, S(S(A)), N),
                                             D(successor, S(A), N))),
        "reversed stationary equation": All("n", Eq(S(D(successor, S(A), N)),
                                                     D(successor, S(S(A)), N))),
        "wrong stationary binder": All("b", Eq(D(successor, S(S(A)), B),
                                               S(D(successor, S(A), B)))),
        "additional free variable": All("n", Eq(D(successor, S(S(B)), N),
                                                 S(D(successor, S(B), N)))),
        "nested quantified matrix": All("n", All("a", Eq(D(identity, ZERO, A), A))),
        "unknown descriptor": Imp(Eq(A, A), Eq(D(1000, ZERO, A), A)),
        "ordinary reflexivity without unfolding": Imp(Eq(N, A), Eq(N, A)),
    }
    for name, matrix in rejections.items():
        checks.check(admit(registry, matrix, True) is None, name)

    before = tuple(registry.bodies)
    object_term = D(identity, N, STATE)
    replaced = subst(object_term, "v", ZERO)
    checks.check(replaced == D(identity, N, ZERO)
                 and tuple(registry.bodies) == before,
                 "active substitution leaves descriptor metadata unchanged")
    checks.check(registry.rho(D(identity, S(S(N)), A)) == D(identity, S(N), A),
                 "stored identity body still substitutes its private state")
    capture_example = All("a", Eq(N, A))
    capture_result = subst(capture_example, "n", A)
    checks.check(fv(capture_result) == {"a"} and capture_result.value != "a",
                 "general substitution avoids capture")
    for index, matrix in enumerate(accepted):
        emitted = outer(matrix)
        checks.check(not fv(emitted) and names(emitted) <= {"n", "a"},
                     f"emitted axiom closed with two names {index}")

    # Explicitly count the exact exposed patterns used in the report.
    def App(name: str, *arguments: Node) -> Node:
        return Node("opaque", tuple(arguments), name)

    def Rewrite(left: Node, right: Node) -> Node:
        return Node("rewrite", (left, right))

    old_rules = [Rewrite(App("K", ZERO, A), A),
                 Rewrite(App("K", S(N), A), N),
                 Rewrite(App("I", ZERO, A), A),
                 Rewrite(App("I", S(N), A), App("h", App("I", N, A)))]
    new_rules = [Rewrite(App("D", ZERO, A), A),
                 Rewrite(App("D", S(ZERO), A), A),
                 Rewrite(App("D", S(S(N)), A), App("h", App("D", S(N), A)))]
    old_equations = [All("a", Eq(old_rules[0].args[0], A)),
                     All("n", All("a", Eq(old_rules[1].args[0], N))),
                     All("a", Eq(old_rules[2].args[0], A)),
                     All("n", All("a", Eq(*old_rules[3].args)))]
    new_equations = [All("a", Eq(new_rules[0].args[0], A)),
                     All("a", Eq(new_rules[1].args[0], A)),
                     All("n", All("a", Eq(*new_rules[2].args)))]
    counts = {
        "old_root_rules": sum(map(size, old_rules)),
        "delayed_root_rules": sum(map(size, new_rules)),
        "old_closed_computation_equations": sum(map(size, old_equations)),
        "delayed_closed_computation_equations": sum(map(size, new_equations)),
        "opaque_outer_schema": size(outer(App("F", N, A))),
        "zero_decision_matrix": size(DECIDE_ZERO),
    }
    checks.check(counts == {
        "old_root_rules": 25,
        "delayed_root_rules": 22,
        "old_closed_computation_equations": 31,
        "delayed_closed_computation_equations": 26,
        "opaque_outer_schema": 15,
        "zero_decision_matrix": 9,
    }, "exact exposed AST ledger")

    ordinary = OrdinaryTranslation(registry)
    for index in range(len(registry.bodies)):
        for n in range(7):
            for a in range(6):
                env = {"n": n, "a": a}
                term = D(index, N, A)
                checks.check(evaluate(term, env, registry)
                             == ordinary.evaluate(ordinary.term(term), env),
                             "nested descriptor translation", "translation_cases")
                checks.check(evaluate(D(index, ZERO, A), env, registry) == a
                             and evaluate(D(index, S(ZERO), A), env, registry) == a,
                             "both delayed seeds", "equation_cases")
                left = evaluate(D(index, S(S(N)), A), env, registry)
                right = evaluate(registry.apply(index, D(index, S(N), A)),
                                 env, registry)
                checks.check(left == right, "delayed step", "equation_cases")

    def I(index: int, n: Node, a: Node) -> Node:
        return D(index, S(n), a)

    pred = D(successor, N, ZERO)
    counter_projection = I(successor, pred, I(zero_update, N, A))
    for n in range(9):
        for a in range(7):
            env = {"n": n, "a": a}
            checks.check(evaluate(pred, env, registry) == max(n - 1, 0),
                         "derived predecessor", "derived_function_cases")
            checks.check(evaluate(counter_projection, env, registry)
                         == (a if n == 0 else n - 1),
                         "derived exceptional K", "derived_function_cases")
            for index in (zero_update, successor, double, nested):
                checks.check(evaluate(D(index, N, A), env, registry)
                             == evaluate(I(index, pred, A), env, registry),
                             "D equals I after predecessor", "roundtrip_cases")
    for matrix in accepted:
        if matrix.tag == "all":
            continue  # Do not disguise finite checks as universal semantics.
        if not fv(matrix) <= {"n", "a"}:
            raise RuntimeError("Unexpected test free variable")
        base = subst(matrix, "n", ZERO)
        for a in range(7):
            checks.check(truth(base, {"a": a, "n": 0}, registry),
                         "accepted quantifier-free base", "base_cases")

    return {
        "status": "PASS",
        "scope": "Finite syntax, exposed counts, and bounded standard-number diagnostics only",
        "not_proved_by_this_program": [
            "The arbitrary-model arithmetic reconstruction",
            "Internal primitive-recursion completeness",
            "The first-order bi-interpretations or their identity round trips",
            "An encoding-independent minimality theorem",
        ],
        "descriptor_count": len(registry.bodies),
        "check_counts": checks.counts,
        "total_checks": sum(checks.counts.values()),
        "ast_counts": counts,
        "syntax_check_names": checks.named,
    }


if __name__ == "__main__":
    result = run()
    rendered = json.dumps(result, indent=2)
    if len(sys.argv) > 2:
        raise SystemExit("Usage: python3 check_spec.py [report.json]")
    if len(sys.argv) == 2:
        Path(sys.argv[1]).write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
