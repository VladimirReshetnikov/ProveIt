#!/usr/bin/env python3
"""Reproduce the finite checks and PDF, optionally compiling local Lean kernels."""
import argparse
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent


def run(command, log):
    result = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False,
    )
    log.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}); see {log}")
    return result.stdout


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", help="Path to Lean 4.19.0; omitted means no Lean run")
    args = parser.parse_args()
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)
    summaries = {}
    for script, stem in [
        ("check_seed_spec.py", "seed_results"),
        ("check_spec.py", "stuttering_results"),
    ]:
        destination = ROOT / "checks" / (stem + ".json")
        run(
            [sys.executable, str(ROOT / "checks" / script), str(destination)],
            audit / (stem + "_console.txt"),
        )
        data = json.loads(destination.read_text())
        summaries[stem] = {
            "status": data["status"],
            "total_checks": data["total_checks"],
            "ast_counts": data["ast_counts"],
        }
    for index in range(1, 4):
        run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "report.tex"],
            audit / f"latex_pass_{index}.txt",
        )
    log = (ROOT / "report.log").read_text(errors="replace")
    defects = [
        line for line in log.splitlines()
        if "Overfull" in line or "undefined" in line
        or "LaTeX Error" in line or "multiply defined" in line
    ]
    if defects:
        raise RuntimeError("LaTeX defects: " + "\n".join(defects))
    summaries["pdf"] = {
        "build": "PASS",
        "bytes": (ROOT / "report.pdf").stat().st_size,
        "sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
    }
    summaries["lean_rerun"] = bool(args.lean)
    if args.lean:
        summaries["lean_version"] = run(
            [args.lean, "--version"], audit / "lean_version.txt"
        ).strip()
        for name in ["SeedKernel", "StutteringKernel"]:
            run([args.lean, str(ROOT / "formal" / (name + ".lean"))],
                ROOT / "formal" / (name + ".log"))
    (audit / "build_results.json").write_text(
        json.dumps(summaries, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
