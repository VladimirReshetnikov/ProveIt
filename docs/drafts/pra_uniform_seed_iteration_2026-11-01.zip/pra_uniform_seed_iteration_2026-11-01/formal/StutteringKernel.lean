import Std

/-!
A constructive local kernel for stuttering iteration.

This file proves the algebraic conversion lemmas used by the manuscript.
`EqInduction` is a supplied semantic equation-induction principle. This
file does not encode the effective first-order language, its literal gate,
primitive recursive syntax, or the complete bi-interpretability theorem.
The iterator records expose only the three displayed defining equations.
No classical reasoning, choice, `sorry`, or extra axiom declaration occurs.
-/

namespace StutteringKernel

universe u
variable {α : Type u}

def EqInduction (zero : α) (succ : α → α) : Prop :=
  ∀ (f g : α → α), f zero = g zero →
    (∀ n, f n = g n → f (succ n) = g (succ n)) →
    ∀ n, f n = g n

structure Stutter (zero : α) (succ h : α → α) where
  run : α → α → α
  at_zero : ∀ a, run zero a = a
  at_one : ∀ a, run (succ zero) a = a
  step : ∀ n a, run (succ (succ n)) a = h (run (succ n) a)

structure Iterator (zero : α) (succ h : α → α) where
  run : α → α → α
  at_zero : ∀ a, run zero a = a
  step : ∀ n a, run (succ n) a = h (run n a)

variable {zero : α} {succ h : α → α}

def toIterator (d : Stutter zero succ h) : Iterator zero succ h where
  run n a := d.run (succ n) a
  at_zero := d.at_one
  step := d.step

def pred (ds : Stutter zero succ succ) (n : α) : α := ds.run n zero

theorem pred_zero (ds : Stutter zero succ succ) : pred ds zero = zero :=
  ds.at_zero zero

theorem pred_succ (ind : EqInduction zero succ)
    (ds : Stutter zero succ succ) : ∀ n, pred ds (succ n) = n := by
  apply ind (fun n => ds.run (succ n) zero) (fun n => n)
  · exact ds.at_one zero
  · intro n ih
    exact (ds.step n zero).trans (congrArg succ ih)

theorem succ_injective (ind : EqInduction zero succ)
    (ds : Stutter zero succ succ) : ∀ x y, succ x = succ y → x = y := by
  intro x y same
  have image := congrArg (pred ds) same
  exact (pred_succ ind ds x).symm.trans (image.trans (pred_succ ind ds y))

theorem count_from_zero (ind : EqInduction zero succ)
    (ds : Stutter zero succ succ) (n : α) :
    (toIterator ds).run n zero = n := pred_succ ind ds n

def recoverK (ds : Stutter zero succ succ)
    (dz : Stutter zero succ (fun _ => zero)) (n a : α) : α :=
  (toIterator ds).run (pred ds n) ((toIterator dz).run n a)

theorem recoverK_zero (ds : Stutter zero succ succ)
    (dz : Stutter zero succ (fun _ => zero)) (a : α) :
    recoverK ds dz zero a = a := by
  unfold recoverK
  rw [pred_zero ds, (toIterator dz).at_zero, (toIterator ds).at_zero]

theorem recoverK_succ (ind : EqInduction zero succ)
    (ds : Stutter zero succ succ)
    (dz : Stutter zero succ (fun _ => zero)) (n a : α) :
    recoverK ds dz (succ n) a = n := by
  unfold recoverK
  rw [pred_succ ind ds n, (toIterator dz).step]
  exact count_from_zero ind ds n

theorem separation_all
    (dz : Stutter zero succ (fun _ => zero))
    (separate : zero ≠ succ zero) : ∀ n, succ n ≠ zero := by
  intro n eqn
  have test := congrArg (fun t => (toIterator dz).run t (succ zero)) eqn
  change (toIterator dz).run (succ n) (succ zero) =
    (toIterator dz).run zero (succ zero) at test
  rw [(toIterator dz).step, (toIterator dz).at_zero] at test
  exact separate test

/-- Rebuilding an arbitrary delayed iterator from its shifted ordinary
iterator returns the original, including the zero endpoint. -/
theorem delayed_roundtrip (ind : EqInduction zero succ)
    (ds : Stutter zero succ succ) (d : Stutter zero succ h) (a : α) :
    ∀ n, (toIterator d).run (pred ds n) a = d.run n a := by
  apply ind (fun n => d.run (succ (pred ds n)) a) (fun n => d.run n a)
  · rw [pred_zero ds, d.at_one, d.at_zero]
  · intro n _
    rw [pred_succ ind ds n]

/-- The reverse conversion needs only the predecessor equations. -/
def toStutter (i : Iterator zero succ h) (p : α → α)
    (pzero : p zero = zero) (psucc : ∀ n, p (succ n) = n) :
    Stutter zero succ h where
  run n a := i.run (p n) a
  at_zero a := by rw [pzero, i.at_zero]
  at_one a := by rw [psucc, i.at_zero]
  step n a := by rw [psucc, psucc, i.step]

theorem iterator_roundtrip (i : Iterator zero succ h) (p : α → α)
    (pzero : p zero = zero) (psucc : ∀ n, p (succ n) = n) (n a : α) :
    (toIterator (toStutter i p pzero psucc)).run n a = i.run n a := by
  change i.run (p (succ n)) a = i.run n a
  rw [psucc]


theorem iterator_unique (ind : EqInduction zero succ)
    (i j : Iterator zero succ h) (a : α) : ∀ n, i.run n a = j.run n a := by
  apply ind (fun n => i.run n a) (fun n => j.run n a)
  · exact (i.at_zero a).trans (j.at_zero a).symm
  · intro n ih
    rw [i.step, j.step, ih]

theorem stutter_unique (ind : EqInduction zero succ)
    (ds : Stutter zero succ succ) (d e : Stutter zero succ h) (n a : α) :
    d.run n a = e.run n a := by
  have middle := iterator_unique ind (toIterator d) (toIterator e) a (pred ds n)
  exact (delayed_roundtrip ind ds d a n).symm.trans
    (middle.trans (delayed_roundtrip ind ds e a n))

#print axioms toIterator
#print axioms toStutter
#print axioms pred_zero
#print axioms pred_succ
#print axioms succ_injective
#print axioms count_from_zero
#print axioms recoverK_zero
#print axioms recoverK_succ
#print axioms separation_all
#print axioms delayed_roundtrip
#print axioms iterator_roundtrip
#print axioms iterator_unique
#print axioms stutter_unique

end StutteringKernel
