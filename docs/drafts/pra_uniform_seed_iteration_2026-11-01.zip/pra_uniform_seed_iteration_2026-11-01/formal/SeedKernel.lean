import Std

/-!
A constructive local kernel for predecessor-seeded iteration.

This file proves the algebraic conversion lemmas used by the manuscript.
`EqInduction` is a supplied semantic equation-induction principle. This
file does not encode the effective first-order language, its literal gate,
primitive recursive syntax, or the complete bi-interpretability theorem.
The iterator records expose only their displayed defining equations.
No classical reasoning, choice, `sorry`, or extra axiom declaration occurs.
-/

namespace SeedKernel

universe u
variable {α : Type u}

def EqInduction (zero : α) (succ : α → α) : Prop :=
  ∀ (f g : α → α), f zero = g zero →
    (∀ n, f n = g n → f (succ n) = g (succ n)) →
    ∀ n, f n = g n

structure SeedIterator (zero : α) (succ h : α → α) where
  run : α → α → α
  at_zero_zero : run zero zero = zero
  at_zero_succ : ∀ a, run zero (succ a) = a
  step : ∀ n a, run (succ n) a = h (run n a)

structure Iterator (zero : α) (succ h : α → α) where
  run : α → α → α
  at_zero : ∀ a, run zero a = a
  step : ∀ n a, run (succ n) a = h (run n a)

variable {zero : α} {succ h : α → α}

def pred (ai : SeedIterator zero succ (fun x => x)) (a : α) : α :=
  ai.run zero a

theorem pred_zero (ai : SeedIterator zero succ (fun x => x)) :
    pred ai zero = zero := ai.at_zero_zero

theorem pred_succ (ai : SeedIterator zero succ (fun x => x)) (a : α) :
    pred ai (succ a) = a := ai.at_zero_succ a

theorem succ_injective (ai : SeedIterator zero succ (fun x => x)) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y same
  have image := congrArg (pred ai) same
  exact (pred_succ ai x).symm.trans (image.trans (pred_succ ai y))

def toIterator (a : SeedIterator zero succ h) : Iterator zero succ h where
  run n x := a.run n (succ x)
  at_zero := a.at_zero_succ
  step n x := a.step n (succ x)

theorem initial_eq_pred (ind : EqInduction zero succ)
    (ai : SeedIterator zero succ (fun x => x)) (a : SeedIterator zero succ h) :
    ∀ x, a.run zero x = pred ai x := by
  apply ind (fun x => a.run zero x) (pred ai)
  · exact a.at_zero_zero.trans (pred_zero ai).symm
  · intro x _
    exact (a.at_zero_succ x).trans (pred_succ ai x).symm

theorem initial_unique (ind : EqInduction zero succ)
    (a b : SeedIterator zero succ h) : ∀ x, a.run zero x = b.run zero x := by
  apply ind (fun x => a.run zero x) (fun x => b.run zero x)
  · exact a.at_zero_zero.trans b.at_zero_zero.symm
  · intro x _
    exact (a.at_zero_succ x).trans (b.at_zero_succ x).symm

/-- The pointwise round trip from a predecessor-seeded iterator through its
ordinary iterator is provable without coverage or excluded middle. -/
theorem seed_roundtrip (ind : EqInduction zero succ)
    (ai : SeedIterator zero succ (fun x => x))
    (a : SeedIterator zero succ h) (x : α) :
    ∀ n, (toIterator a).run n (pred ai x) = a.run n x := by
  apply ind (fun n => a.run n (succ (pred ai x))) (fun n => a.run n x)
  · exact (a.at_zero_succ (pred ai x)).trans (initial_eq_pred ind ai a x).symm
  · intro n ih
    rw [a.step, a.step, ih]

/-- The reverse conversion uses only the two predecessor equations. -/
def toSeedIterator (i : Iterator zero succ h) (p : α → α)
    (pzero : p zero = zero) (psucc : ∀ x, p (succ x) = x) :
    SeedIterator zero succ h where
  run n x := i.run n (p x)
  at_zero_zero := by rw [pzero, i.at_zero]
  at_zero_succ x := by rw [psucc, i.at_zero]
  step n x := i.step n (p x)

theorem iterator_roundtrip (i : Iterator zero succ h) (p : α → α)
    (pzero : p zero = zero) (psucc : ∀ x, p (succ x) = x) (n x : α) :
    (toIterator (toSeedIterator i p pzero psucc)).run n x = i.run n x := by
  change i.run n (p (succ x)) = i.run n x
  rw [psucc]

theorem count_from_zero (ind : EqInduction zero succ)
    (a : SeedIterator zero succ succ) : ∀ n, (toIterator a).run n zero = n := by
  apply ind (fun n => (toIterator a).run n zero) (fun n => n)
  · exact (toIterator a).at_zero zero
  · intro n ih
    exact ((toIterator a).step n zero).trans (congrArg succ ih)

def recoverK (ai : SeedIterator zero succ (fun x => x))
    (as : SeedIterator zero succ succ)
    (az : SeedIterator zero succ (fun _ => zero)) (n x : α) : α :=
  (toIterator as).run (pred ai n) ((toIterator az).run n x)

theorem recoverK_zero (ai : SeedIterator zero succ (fun x => x))
    (as : SeedIterator zero succ succ)
    (az : SeedIterator zero succ (fun _ => zero)) (x : α) :
    recoverK ai as az zero x = x := by
  unfold recoverK
  rw [pred_zero ai, (toIterator az).at_zero, (toIterator as).at_zero]

theorem recoverK_succ (ind : EqInduction zero succ)
    (ai : SeedIterator zero succ (fun x => x))
    (as : SeedIterator zero succ succ)
    (az : SeedIterator zero succ (fun _ => zero)) (n x : α) :
    recoverK ai as az (succ n) x = n := by
  unfold recoverK
  rw [pred_succ ai n, (toIterator az).step]
  exact count_from_zero ind as n

theorem separation_all (az : SeedIterator zero succ (fun _ => zero))
    (separate : zero ≠ succ zero) : ∀ n, succ n ≠ zero := by
  intro n eqn
  have test := congrArg (fun t => (toIterator az).run t (succ zero)) eqn
  change (toIterator az).run (succ n) (succ zero) =
    (toIterator az).run zero (succ zero) at test
  rw [(toIterator az).step, (toIterator az).at_zero] at test
  exact separate test

theorem iterator_unique (ind : EqInduction zero succ)
    (i j : Iterator zero succ h) (x : α) : ∀ n, i.run n x = j.run n x := by
  apply ind (fun n => i.run n x) (fun n => j.run n x)
  · exact (i.at_zero x).trans (j.at_zero x).symm
  · intro n ih
    rw [i.step, j.step, ih]

theorem seed_unique (ind : EqInduction zero succ)
    (a b : SeedIterator zero succ h) (x : α) : ∀ n, a.run n x = b.run n x := by
  apply ind (fun n => a.run n x) (fun n => b.run n x)
  · exact initial_unique ind a b x
  · intro n ih
    rw [a.step, b.step, ih]

#print axioms pred_zero
#print axioms pred_succ
#print axioms succ_injective
#print axioms toIterator
#print axioms initial_eq_pred
#print axioms initial_unique
#print axioms seed_roundtrip
#print axioms toSeedIterator
#print axioms iterator_roundtrip
#print axioms count_from_zero
#print axioms recoverK_zero
#print axioms recoverK_succ
#print axioms separation_all
#print axioms iterator_unique
#print axioms seed_unique

end SeedKernel
