#!/usr/bin/env python3
"""Executable checks for the compact PRA axiomatization.

This is NOT a proof-assistant formalization of the equivalence theorem. It
checks the primitive-recursive syntax, finite examples in the standard natural
numbers, a symbolic local latch certificate, and an explicit product-model
witness. The paper supplies the mathematical proof for all models and inputs.

Every recursion has parameters first and its recursion argument last:
    R(g, h)(a, 0) = g(a)
    R(g, h)(a, n + 1) = h(a, n, R(g, h)(a, n)).
Here ``a`` denotes a possibly empty parameter tuple. The public conditional
``c(test, when_zero, when_nonzero)`` is a permutation of a recursion whose
native arguments are ``(when_zero, when_nonzero, test)``. Latch programs use
``(parameters..., n)`` even when the paper writes ``L(n, parameters...)``.

Python 3.10 or newer; standard library only. Example:
    python3 verify.py --output verification.json
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class PR:
    """Arity-checked syntax: zero, successor, projection, composition, recursion."""

    kind: str
    arity: int
    children: tuple[PR, ...] = ()
    index: int | None = None

    def __post_init__(self) -> None:
        if type(self.arity) is not int or self.arity < 0:
            raise ValueError("A program arity must be a nonnegative integer")
        if not isinstance(self.children, tuple):
            raise ValueError("Program children must be a tuple")
        if any(not isinstance(child, PR) for child in self.children):
            raise ValueError("Every program child must itself be a PR program")
        if self.kind == "zero":
            valid = self.arity == 0 and not self.children and self.index is None
        elif self.kind == "successor":
            valid = self.arity == 1 and not self.children and self.index is None
        elif self.kind == "projection":
            valid = (
                not self.children
                and type(self.index) is int
                and 0 <= self.index < self.arity
            )
        elif self.kind == "composition":
            valid = bool(self.children) and self.index is None
            if valid:
                outer, *inner = self.children
                valid = len(inner) == outer.arity and all(
                    child.arity == self.arity for child in inner
                )
        elif self.kind == "recursion":
            valid = len(self.children) == 2 and self.index is None
            if valid:
                base, step = self.children
                valid = (
                    self.arity == base.arity + 1
                    and step.arity == base.arity + 2
                )
        else:
            valid = False
        if not valid:
            raise ValueError(f"Malformed {self.kind!r} program of arity {self.arity}")


ZERO = PR("zero", 0)
SUCCESSOR = PR("successor", 1)


def projection(arity: int, index: int) -> PR:
    """Projection indices are zero based."""
    return PR("projection", arity, index=index)


def composition(outer: PR, *inner: PR, arity: int | None = None) -> PR:
    if arity is None:
        if not inner:
            raise ValueError("Nullary composition needs an explicit input arity")
        arity = inner[0].arity
    return PR("composition", arity, (outer,) + inner)


def recursion(base: PR, step: PR) -> PR:
    return PR("recursion", base.arity + 1, (base, step))


def constant(value: int, arity: int) -> PR:
    if type(value) is not int or value < 0:
        raise ValueError("A numerical constant must be a nonnegative integer")
    result = composition(ZERO, arity=arity)
    for _ in range(value):
        result = composition(SUCCESSOR, result)
    return result


@lru_cache(maxsize=131072)
def evaluate(program: PR, arguments: tuple[int, ...]) -> int:
    if len(arguments) != program.arity:
        raise ValueError("Evaluation arguments do not match the program arity")
    if any(type(value) is not int or value < 0 for value in arguments):
        raise ValueError("Evaluation is restricted to standard natural numbers")
    if program.kind == "zero":
        return 0
    if program.kind == "successor":
        return arguments[0] + 1
    if program.kind == "projection":
        assert program.index is not None
        return arguments[program.index]
    if program.kind == "composition":
        outer, *inner = program.children
        return evaluate(outer, tuple(evaluate(child, arguments) for child in inner))
    if program.kind == "recursion":
        base, step = program.children
        parameters, bound = arguments[:-1], arguments[-1]
        value = evaluate(base, parameters)
        for index in range(bound):
            value = evaluate(step, parameters + (index, value))
        return value
    raise AssertionError("The constructor should reject unknown program kinds")


# All named programs below expand to the five AST constructors above.
PRED = recursion(ZERO, projection(2, 0))
IS_ZERO = recursion(constant(1, 0), constant(0, 2))
ADD = recursion(projection(1, 0), composition(SUCCESSOR, projection(3, 2)))
MONUS = recursion(projection(1, 0), composition(PRED, projection(3, 2)))
SWAP_MONUS = composition(MONUS, projection(2, 1), projection(2, 0))
ABS_DIFFERENCE = composition(ADD, MONUS, SWAP_MONUS)
EPSILON = composition(IS_ZERO, ABS_DIFFERENCE)
NATIVE_CASE = recursion(projection(2, 0), projection(4, 1))
CASE = composition(
    NATIVE_CASE, projection(3, 1), projection(3, 2), projection(3, 0)
)
NORMALIZER = composition(EPSILON, projection(1, 0), constant(0, 1))

PROGRAMS = {
    "pred": PRED,
    "is_zero": IS_ZERO,
    "add": ADD,
    "monus": MONUS,
    "absolute_difference": ABS_DIFFERENCE,
    "epsilon": EPSILON,
    "native_case": NATIVE_CASE,
    "c": CASE,
    "Z": NORMALIZER,
}


@dataclass(frozen=True)
class Formula:
    """Quantifier-free formulas whose terms share a fixed argument list."""

    kind: str
    parts: tuple[PR | Formula, ...]

    def __post_init__(self) -> None:
        if self.kind == "equals":
            valid = len(self.parts) == 2 and all(
                isinstance(part, PR) for part in self.parts
            )
        elif self.kind == "not":
            valid = len(self.parts) == 1 and isinstance(self.parts[0], Formula)
        elif self.kind in {"and", "or", "implies"}:
            valid = len(self.parts) == 2 and all(
                isinstance(part, Formula) for part in self.parts
            )
        else:
            valid = False
        if not valid or len({part.arity for part in self.parts}) != 1:
            raise ValueError("Malformed formula or inconsistent term arities")

    @property
    def arity(self) -> int:
        return self.parts[0].arity


def equals(left: PR, right: PR) -> Formula:
    return Formula("equals", (left, right))


def compile_boolean(formula: Formula) -> PR:
    """Return a PR program with 0 = true and 1 = false.

    The double use of epsilon at atoms is deliberate. The weak axiom E only
    controls the zero set of epsilon; the outer Z normalizes its other outputs.
    """
    if formula.kind == "equals":
        left, right = formula.parts
        assert isinstance(left, PR) and isinstance(right, PR)
        return composition(NORMALIZER, composition(EPSILON, left, right))
    children = [compile_boolean(part) for part in formula.parts]
    zero, one = constant(0, formula.arity), constant(1, formula.arity)
    if formula.kind == "not":
        return composition(NORMALIZER, children[0])
    if formula.kind == "and":
        return composition(CASE, children[0], children[1], one)
    if formula.kind == "or":
        return composition(CASE, children[0], zero, children[1])
    if formula.kind == "implies":
        return composition(CASE, children[0], children[1], zero)
    raise AssertionError("Formula constructor should reject unknown connectives")


def evaluate_formula(formula: Formula, arguments: tuple[int, ...]) -> bool:
    if formula.kind == "equals":
        left, right = formula.parts
        assert isinstance(left, PR) and isinstance(right, PR)
        return evaluate(left, arguments) == evaluate(right, arguments)
    values = [evaluate_formula(part, arguments) for part in formula.parts]
    if formula.kind == "not":
        return not values[0]
    if formula.kind == "and":
        return values[0] and values[1]
    if formula.kind == "or":
        return values[0] or values[1]
    if formula.kind == "implies":
        return not values[0] or values[1]
    raise AssertionError("Unknown connective")


def make_latch(bit_program: PR) -> tuple[PR, PR]:
    """Compile P and L; arguments are (parameters..., induction_argument)."""
    if bit_program.arity < 1:
        raise ValueError("A latch needs a designated induction argument")
    parameter_count = bit_program.arity - 1
    step_arity = parameter_count + 2
    bit_at_step = composition(
        bit_program,
        *(projection(step_arity, index) for index in range(parameter_count + 1)),
    )
    step = composition(
        CASE,
        bit_at_step,
        projection(step_arity, parameter_count + 1),
        constant(0, step_arity),
    )
    accumulator = recursion(constant(1, parameter_count), step)
    latch = composition(
        CASE, bit_program, accumulator, constant(0, bit_program.arity)
    )
    return accumulator, latch


def unique_nodes(roots: list[PR]) -> set[PR]:
    seen: set[PR] = set()
    pending = list(roots)
    while pending:
        program = pending.pop()
        if program not in seen:
            seen.add(program)
            pending.extend(program.children)
    return seen


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def check_rejections() -> int:
    invalid: list[Callable[[], object]] = [
        lambda: projection(2, 2),
        lambda: projection(-1, 0),
        lambda: composition(SUCCESSOR, arity=1),
        lambda: composition(ADD, projection(1, 0), projection(2, 0)),
        lambda: recursion(ZERO, projection(3, 0)),
        lambda: evaluate(SUCCESSOR, (-1,)),
        lambda: evaluate(ADD, (1,)),
        lambda: equals(projection(1, 0), projection(2, 0)),
    ]
    for action in invalid:
        try:
            action()
        except ValueError:
            continue
        raise AssertionError("An invalid syntax or evaluation request was accepted")
    return len(invalid)


def symbolic_latch_certificate() -> dict[str, object]:
    """Exact local simplification; A is a symbol, not a sampled number."""
    accumulator = "A (arbitrary accumulator)"

    def choose(bit: int, when_zero: object, when_one: object) -> object:
        require(bit in (0, 1), "The certificate requires Boolean bits")
        return when_zero if bit == 0 else when_one

    rows = []
    for current_bit, next_bit in ((0, 0), (1, 0), (1, 1)):
        current_latch = choose(current_bit, accumulator, 0)
        next_latch = choose(next_bit, current_latch, 0)
        require(current_latch == next_latch, "The local latch identity failed")
        rows.append({
            "b_n": current_bit,
            "b_Sn": next_bit,
            "L_n": current_latch,
            "L_Sn": next_latch,
        })
    require(choose(0, 1, 0) == 1, "The latch base computation failed")
    require(choose(1, accumulator, 0) == 0, "The final implication failed")
    require(
        choose(1, choose(0, accumulator, 0), 0) != accumulator,
        "The forbidden 0-to-1 transition should not simplify to stationarity",
    )
    return {
        "allowed_transitions_checked": len(rows),
        "rows": rows,
        "excluded_transition": [0, 1],
        "reason_excluded": "The induction-step assumption forbids true-to-false",
        "accumulator_is_arbitrary_symbol": True,
        "base_and_final_local_implication_checked": True,
    }


def product_value(program: PR, *arguments: tuple[int, int]) -> tuple[int, int]:
    return tuple(
        evaluate(program, tuple(argument[coordinate] for argument in arguments))
        for coordinate in range(2)
    )


def product_witness() -> dict[str, object]:
    zero, one, point = (0, 0), (1, 1), (0, 1)
    reconstructed = product_value(SUCCESSOR, product_value(PRED, point))
    epsilon_value = product_value(EPSILON, point, zero)
    cover = point == zero or point == reconstructed
    e_left, e_right = epsilon_value == zero, point != zero
    require(zero != one, "Product nontriviality witness failed")
    require(not cover, "Product coverage counterexample failed")
    require(e_left != e_right, "Axiom E should exclude the product model")
    return {
        "domain": "N x N, with all PR operations interpreted componentwise",
        "point": list(point),
        "S_pred_point": list(reconstructed),
        "coverage_formula_is_false": not cover,
        "epsilon_point_zero": list(epsilon_value),
        "axiom_E_left_side": e_left,
        "axiom_E_right_side": e_right,
        "zero_and_one_are_distinct": True,
        "scope": (
            "Checks these explicit values only. The paper proves that the full "
            "product structure satisfies defining equations and constancy."
        ),
    }


def verify() -> dict[str, object]:
    rejection_count = check_rejections()
    domain = range(7)
    arithmetic_checks = 0
    for value in domain:
        for program, expected in (
            (PRED, max(value - 1, 0)),
            (IS_ZERO, int(value == 0)),
            (NORMALIZER, int(value == 0)),
        ):
            require(evaluate(program, (value,)) == expected, "Unary arithmetic check")
            arithmetic_checks += 1
    for left, right in itertools.product(domain, repeat=2):
        for program, expected in (
            (ADD, left + right),
            (MONUS, max(left - right, 0)),
            (EPSILON, int(left == right)),
        ):
            require(evaluate(program, (left, right)) == expected, "Binary arithmetic check")
            arithmetic_checks += 1
    for test, left, right in itertools.product(domain, repeat=3):
        require(
            evaluate(CASE, (test, left, right)) == (left if test == 0 else right),
            "Conditional argument permutation check",
        )
        arithmetic_checks += 1
    require(evaluate(EPSILON, (0, 0)) == 1, "Required closed epsilon computation")
    arithmetic_checks += 1

    x, y = projection(2, 0), projection(2, 1)
    zero = constant(0, 2)
    equality = equals(x, y)
    samples = {
        "equality": equality,
        "x_is_zero": equals(x, zero),
        "successor_relation": equals(y, composition(SUCCESSOR, x)),
        "pred_successor": equals(composition(PRED, composition(SUCCESSOR, x)), x),
        "addition_commutes": equals(ADD, composition(ADD, y, x)),
        "epsilon_is_one": equals(EPSILON, constant(1, 2)),
        "negation": Formula("not", (equality,)),
        "conjunction": Formula("and", (equals(x, zero), equals(y, zero))),
        "disjunction": Formula("or", (equality, equals(x, zero))),
        "implication": Formula("implies", (
            equality, equals(composition(SUCCESSOR, x), composition(SUCCESSOR, y))
        )),
        "nested_connectives": Formula("not", (
            Formula("and", (equality, Formula("not", (equals(x, zero),)))),
        )),
        "truncated_subtraction_zero": equals(MONUS, zero),
    }
    compiled = {name: compile_boolean(formula) for name, formula in samples.items()}
    formula_checks = 0
    for name, formula in samples.items():
        require(compiled[name].arity == 2, "The compiler changed formula arity")
        for arguments in itertools.product(domain, repeat=2):
            bit = evaluate(compiled[name], arguments)
            require(bit in (0, 1), "A compiled predicate was not Boolean")
            require((bit == 0) == evaluate_formula(formula, arguments), name)
            formula_checks += 1

    latch_bits = {
        "always_true": constant(0, 2),
        "n_at_least_parameter": compile_boolean(equals(MONUS, zero)),
        "n_at_most_parameter": compile_boolean(equals(SWAP_MONUS, zero)),
    }
    latch_roots: list[PR] = []
    latch_checks = 0
    for name, bit_program in latch_bits.items():
        accumulator, latch = make_latch(bit_program)
        latch_roots.extend((accumulator, latch))
        require(accumulator.arity == 2 and latch.arity == 2, "Latch arity")
        for parameter in range(5):
            require(evaluate(accumulator, (parameter, 0)) == 1, "Latch base equation")
            latch_checks += 1
            for n in range(7):
                require(
                    evaluate(accumulator, (parameter, n + 1))
                    == evaluate(latch, (parameter, n)),
                    "Accumulator/latch indexing",
                )
                expected = int(all(
                    evaluate(bit_program, (parameter, earlier)) == 0
                    for earlier in range(n + 1)
                ))
                require(evaluate(latch, (parameter, n)) == expected, name)
                latch_checks += 2

    nodes = unique_nodes(list(PROGRAMS.values()) + list(compiled.values()) + latch_roots)
    kinds = {
        kind: sum(node.kind == kind for node in nodes)
        for kind in ("zero", "successor", "projection", "composition", "recursion")
    }
    return {
        "status": "passed",
        "verification_level": (
            "Not a proof-assistant formalization. Checks syntax, a local symbolic "
            "certificate, and bounded standard-model smoke tests only."
        ),
        "recursion_convention": (
            "Parameters first, recursion argument last; step arguments are "
            "(parameters..., index, accumulated_value)."
        ),
        "syntax": {
            "named_program_arities": {name: p.arity for name, p in PROGRAMS.items()},
            "invalid_requests_rejected": rejection_count,
            "unique_ast_nodes": len(nodes),
            "nodes_by_constructor": kinds,
        },
        "arithmetic_smoke_tests": {
            "input_range_inclusive": [0, 6],
            "checks": arithmetic_checks,
            "epsilon_zero_zero": 1,
        },
        "formula_compiler_smoke_tests": {
            "formula_names": list(samples),
            "formula_count": len(samples),
            "argument_range_inclusive": [0, 6],
            "checks": formula_checks,
            "true_code": 0,
            "false_code": 1,
        },
        "compiled_latch_smoke_tests": {
            "predicate_names": list(latch_bits),
            "parameter_range_inclusive": [0, 4],
            "induction_argument_range_inclusive": [0, 6],
            "checks": latch_checks,
        },
        "symbolic_local_latch_certificate": symbolic_latch_certificate(),
        "product_model_witness": product_witness(),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write the deterministic JSON report here")
    arguments = parser.parse_args()
    report = verify()
    rendered = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if arguments.output is None:
        print(rendered, end="")
    else:
        arguments.output.write_text(rendered, encoding="utf-8")
        print(
            "PASS: 8 invalid requests rejected; "
            f"{report['arithmetic_smoke_tests']['checks']} arithmetic checks; "
            f"{report['formula_compiler_smoke_tests']['checks']} formula checks; "
            f"{report['compiled_latch_smoke_tests']['checks']} latch checks; "
            "3 symbolic transition cases; product witness checked."
        )
        print(f"Report: {arguments.output}")
        print("These checks are not a proof-assistant formalization.")


if __name__ == "__main__":
    main()
