A COMPACT AXIOMATIZATION OF PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, October 31, 2026

MAIN RESULT

In classical first-order logic, use the defining equations D_PR for every
syntactically specified primitive recursive program. Fix the equality-test
program epsilon(x,y) = z((x dotminus y) + (y dotminus x)), with z(0)=1
and z(Sn)=0. Add:

  E: epsilon(x,y)=0 if and only if x is unequal to y.

  C_f: for each program f and each fixed tuple of parameters a,
       [for all n, f(Sn,a)=f(n,a)] implies
       [for all m, f(m,a)=f(0,a)].

The paper proves that this theory and standard first-order PRA have exactly
the same theorems in the same program-indexed language. This is stronger than
equiconsistency or agreement only on equations. It does not assert an absolute
shortest description, a new historical priority, or finite axiomatizability.

CONTENTS

  pra_compact_axiomatization.tex   Complete LaTeX source, including references
  pra_compact_axiomatization.pdf   Compiled research note
  verify.py                       Standard-library Python executable checks
  verification.json               Deterministic results of those checks
  Makefile                        PDF and verification build commands
  SHA256SUMS                      Hashes of the other deliverable files

REBUILD

  make all

Alternatively:

  latexmk -pdf -interaction=nonstopmode -halt-on-error \
      pra_compact_axiomatization.tex
  python3 verify.py --output verification.json

Requirements: a standard TeX Live or MiKTeX installation with latexmk, and
Python 3.10 or newer. No third-party Python packages are required. The Python
program uses parameters first and the recursion argument last; the paper
sometimes permutes arguments to put the induction variable first.

WHAT HAS BEEN CHECKED

The mathematical proof includes: exact Boolean normalization without
induction; an explicit ordinary primitive recursive accumulator; derivation
of every quantifier-free induction instance; recovery of the successor
axioms; and a self-contained proof that PRA verifies the fixed equality test.
The product N x N is proved to refute the tempting version with only 0 != 1
in place of E.

The executable artifact checks program arities and malformed inputs, bounded
standard-model arithmetic and formula compilations, compiled accumulator
behavior, the three local symbolic transition cases with an arbitrary
accumulator symbol, and the explicit product-model witness. These checks
are not a proof-assistant formalization of the first-order theorem.

No third-party article PDFs are redistributed in this archive. Bibliographic
references and their links are included in the paper.
