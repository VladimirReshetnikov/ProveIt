#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p audit
python3 artifacts/check_autonomous_uniqueness.py --output artifacts/autonomous_audit.json > audit/syntax_check.log
pra_lean_exe="${PRA_LEAN:-lean}"
"$pra_lean_exe" --version > audit/lean_version.txt
for pra_certificate in FullOrbitKernel DelayedOrbitKernel StoredLatch StationaryReflection BooleanDiagonal; do
  "$pra_lean_exe" "formal/${pra_certificate}.lean" > "audit/${pra_certificate}.log" 2>&1
  cat "audit/${pra_certificate}.log"
done
python3 - <<'PY'
from pathlib import Path
import json
results = []
for name in ['FullOrbitKernel','DelayedOrbitKernel','StoredLatch','StationaryReflection','BooleanDiagonal']:
    path = Path('audit') / (name + '.log')
    lines = path.read_text().splitlines()
    audits = [line for line in lines if 'does not depend on any axioms' in line]
    if not audits or any('depends on axioms:' in line or 'error:' in line for line in lines):
        raise RuntimeError('Unexpected dependency or compiler output: ' + name)
    results.append({'file': 'formal/' + name + '.lean', 'exit_code': 0,
                    'empty_axiom_audits': len(audits)})
report = {'lean_version': Path('audit/lean_version.txt').read_text().strip(),
          'certificates': results,
          'scope': 'Conditional proof kernels over an arbitrary carrier; not the entire first-order equivalence formalization.'}
Path('audit/lean_results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
PY
