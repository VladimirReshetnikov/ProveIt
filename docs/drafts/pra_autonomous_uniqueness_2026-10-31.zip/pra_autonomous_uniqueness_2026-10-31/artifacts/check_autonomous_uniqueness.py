#!/usr/bin/env python3
"""Audit finite syntax and formula sizes for autonomous uniqueness.

This script is NOT a proof checker for PRA or the equivalence theorem. It
checks formula-tree counts, actual finite declaration dependencies, the
restriction on update variables, and a parameter-erasing latch compiler.
The manuscript proves the general arithmetic statements.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import argparse
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    label: str = ""
    args: tuple["Node", ...] = ()

    def data(self):
        return {"kind": self.kind, "label": self.label,
                "args": [arg.data() for arg in self.args]}


def var(name):
    return Node("variable", name)


ZERO = Node("constant", "0")


def app(name, *args):
    return Node("function", name, tuple(args))


def S(term):
    return app("S", term)


ONE = S(ZERO)


def form(kind, *args, label=""):
    return Node(kind, label, tuple(args))


def Eq(left, right):
    return form("equality", left, right)


def Imp(left, right):
    return form("implies", left, right)


def All(name, formula):
    return form("forall", formula, label=name)


def tally(node):
    result = Counter({node.kind: 1})
    for child in node.args:
        result.update(tally(child))
    return result


def free_vars(term):
    if term.kind == "variable":
        return {term.label}
    result = set()
    for child in term.args:
        result.update(free_vars(child))
    return result


def symbols(term):
    result = {term.label} if term.kind == "function" else set()
    for child in term.args:
        result.update(symbols(child))
    return result


def subst(term, mapping):
    """Simultaneous substitution in argument trees, never in symbol indices."""
    if term.kind == "variable":
        return mapping.get(term.label, term)
    return Node(term.kind, term.label,
                tuple(subst(child, mapping) for child in term.args))


def pretty(term):
    if not term.args:
        return term.label or term.kind
    return term.label + "(" + ",".join(pretty(a) for a in term.args) + ")"


def measure(formulas):
    counts = Counter()
    for formula in formulas:
        counts.update(tally(formula))
    return {"nodes": sum(counts.values()),
            "equality_occurrences": counts["equality"],
            "templates": len(formulas),
            "by_kind": dict(sorted(counts.items())),
            "formulas": [formula.data() for formula in formulas]}


def formula_audit():
    n, a, v = var("n"), var("a"), var("v")
    sep = Imp(Eq(ZERO, ONE), form("bottom"))
    f = lambda x: app("f", x, a)
    pred = app("I_counter", n, ZERO)
    conclusion = All("n", form("or", Eq(n, ZERO),
        Eq(f(n), app("I_h", pred, f(ONE)))))
    delayed_conclusion = All("n", form("or", Eq(n, ZERO),
        Eq(f(n), app("h", app("D_h", n, f(ZERO))))))
    binary_premise = All("n", Eq(f(S(S(n))), app("h", n, f(S(n)))))
    unary_tail_premise = All("n", Eq(f(S(S(n))), app("h", f(S(n)))))
    unary_full_premise = All("n", Eq(f(S(n)), app("h", f(n))))
    pack = lambda p: All("a", Imp(p, form("and", sep, conclusion)))
    equation = lambda x: Eq(app("s", x, a), app("t", x, a))
    rb = All("a", Imp(All("n", Imp(equation(n), equation(S(n)))),
        form("and", sep, All("n", form("or", Eq(n, ZERO), equation(n))))))
    d0 = All("a", Eq(app("I_h", ZERO, a), a))
    ds = All("n", All("a", Eq(app("I_h", S(n), a),
                               app("h", n, app("I_h", n, a)))))
    rows = {
        "literal_boundary_RB_arithmetic": measure([rb]),
        "binary_update_PU_arithmetic": measure([pack(binary_premise)]),
        "intermediate_autonomous_positive_tail_APU_arithmetic": measure([pack(unary_tail_premise)]),
        "prior_full_language_PIU_arithmetic": measure([pack(unary_tail_premise)]),
        "new_autonomous_full_orbit_AU_arithmetic": measure([pack(unary_full_premise)]),
        "new_autonomous_full_orbit_AU_separated_arithmetic": measure(
            [sep, All("a", Imp(unary_full_premise, conclusion))]),
        "optional_delayed_autonomous_AU_arithmetic": measure(
            [All("a", Imp(unary_full_premise, form("and", sep, delayed_conclusion)))]),
        "shared_binary_definition_templates": measure([d0, ds]),
        "binary_PU_with_definitions": measure([d0, ds, pack(binary_premise)]),
        "intermediate_autonomous_positive_tail_APU_with_definitions": measure([d0, ds, pack(unary_tail_premise)]),
        "new_autonomous_full_orbit_AU_with_definitions": measure([d0, ds, pack(unary_full_premise)]),
        "optional_delayed_autonomous_AU_with_definitions": measure(
            [d0, ds, All("a", Imp(unary_full_premise, form("and", sep, delayed_conclusion)))]),
    }
    expected = {
        "literal_boundary_RB_arithmetic": (39, 5),
        "binary_update_PU_arithmetic": (39, 4),
        "intermediate_autonomous_positive_tail_APU_arithmetic": (38, 4),
        "prior_full_language_PIU_arithmetic": (38, 4),
        "new_autonomous_full_orbit_AU_arithmetic": (36, 4),
        "new_autonomous_full_orbit_AU_separated_arithmetic": (35, 4),
        "optional_delayed_autonomous_AU_arithmetic": (34, 4),
        "shared_binary_definition_templates": (18, 2),
        "binary_PU_with_definitions": (57, 6),
        "intermediate_autonomous_positive_tail_APU_with_definitions": (56, 6),
        "new_autonomous_full_orbit_AU_with_definitions": (54, 6),
        "optional_delayed_autonomous_AU_with_definitions": (52, 6),
    }
    for name, pair in expected.items():
        assert (rows[name]["nodes"], rows[name]["equality_occurrences"]) == pair
    assert rows["intermediate_autonomous_positive_tail_APU_arithmetic"] == rows["prior_full_language_PIU_arithmetic"]
    return {
        "metric": "One node per variable occurrence, constant, function application, "
                  "equality, connective, bottom, or one-variable quantifier. Expand "
                  "1 as S(0), negation as implication to bottom, and p(n) as "
                  "I_counter(n,0). Count displayed arguments of schematic terms, "
                  "but not their substituted bodies or symbol-description indices.",
        "qualification": "The intermediate autonomous positive-tail formula has 38 "
                         "nodes and already appears in the prior full-language PIU "
                         "draft. The new full-orbit AU formula has 36 nodes: its "
                         "premise is f(Sn,a)=h(f(n,a)), with the same positive "
                         "conclusion. Completeness holds with the restricted binary "
                         "description grammar and one fixed arithmetic parameter.",
        "optional_delayed_qualification": "The optional 34-node delayed display uses "
                         "D_h=I_Kh, where Kh(k,v)=C(k,v,h(v)). It counts the new "
                         "iterator by its symbol name, under the same convention "
                         "that excludes description indices. The fixed compiler "
                         "h -> Kh is additional syntax machinery and is not free "
                         "under a description-length metric. AU36 remains the "
                         "recommended presentation without this compiler.",
        "not_measured": ["length of program descriptions", "substituted term bodies",
                         "proof length", "absolute axiomatization minimality"],
        "rows": rows,
    }


class Registry:
    """Finite dependency-ordered prefix of the binary iterator grammar."""
    def __init__(self):
        self.arities = {"S": 1}
        self.declarations = []
        self.updates = {}

    def check_term(self, term):
        if term.kind in ("variable", "constant"):
            assert not term.args
            if term.kind == "constant":
                assert term.label == "0"
            return
        assert term.kind == "function"
        assert term.label in self.arities, term.label
        assert len(term.args) == self.arities[term.label], term
        for child in term.args:
            self.check_term(child)

    def add_iterator(self, name, update):
        assert name not in self.arities
        self.check_term(update)
        assert free_vars(update) <= {"k", "v"}, free_vars(update)
        self.declarations.append({
            "name": name,
            "stage": len(self.declarations) + 1,
            "update": update.data(),
            "update_text": pretty(update),
            "free_variables": sorted(free_vars(update)),
            "dependencies": sorted(symbols(update)),
        })
        self.arities[name] = 2
        self.updates[name] = update

    def normalize(self, term):
        """Normalize finite symbolic examples using only declared D0/DS rules."""
        if term.kind != "function":
            return term
        if term.label in self.updates:
            counter, seed = term.args
            if counter == ZERO:
                return self.normalize(seed)
            if counter.kind == "function" and counter.label == "S":
                previous = counter.args[0]
                return self.normalize(subst(self.updates[term.label], {
                    "k": previous, "v": app(term.label, previous, seed)}))
        normalized = Node(term.kind, term.label,
                          tuple(self.normalize(child) for child in term.args))
        if normalized != term:
            return self.normalize(normalized)
        return normalized


def syntax_audit():
    reg = Registry()
    k, v = var("k"), var("v")
    n, a = var("n"), var("a")
    reg.add_iterator("P", k)
    reg.add_iterator("B", ZERO)
    reg.add_iterator("A", S(v))
    p = lambda x: app("P", x, ZERO)
    gate = lambda x, y: app("B", x, y)
    plus = lambda x, y: app("A", x, y)
    reg.add_iterator("M", p(v))
    mon = lambda x, y: app("M", x, y)
    # Every displayed helper is expanded into the actual binary signature.
    C = lambda z, u, w: app("P", gate(z, S(u)), w)
    reg.add_iterator("Parity", gate(v, ONE))
    parity = lambda x: app("Parity", x, ZERO)
    reg.add_iterator("Half", C(parity(k), v, S(v)))
    half = lambda x: app("Half", x, ZERO)
    double = lambda x: plus(x, x)
    enc = lambda x, b: C(b, double(x), S(double(x)))

    targets = [
        ZERO, n, a, S(n), plus(n, a), mon(n, a),
        C(mon(n, a), p(a), plus(n, S(a))),
        mon(half(plus(n, a)), plus(parity(a), p(n))),
    ]
    # Generate a bounded, varied collection to catch substitution and arity errors.
    initial = tuple(targets)
    targets.extend(S(t) for t in initial)
    targets.extend(mon(s, t) for s in initial for t in initial)
    targets = list(dict.fromkeys(targets))
    compiled = []
    for index, target in enumerate(targets):
        reg.check_term(target)
        assert free_vars(target) <= {"n", "a"}
        parameterized_test = subst(target, {"n": k, "a": half(v)})
        assert free_vars(parameterized_test) <= {"k", "v"}
        update = enc(half(v), C(parameterized_test, parity(v), ZERO))
        name = f"Latch_{index:03d}"
        reg.add_iterator(name, update)
        trajectory = app(name, n, enc(a, ONE))
        reg.check_term(trajectory)
        assert free_vars(trajectory) <= {"n", "a"}
        compiled.append({"target": target.data(), "target_text": pretty(target),
                         "update_name": name,
                         "trajectory": trajectory.data(),
                         "update_nodes": sum(tally(update).values()),
                         "update_free_variables": sorted(free_vars(update))})

    # Each of these arithmetic updates is autonomous. The counter example
    # is a legal old update and a legal definition body but is not autonomous.
    unary_updates = {"successor": S(v), "predecessor": p(v), "identity": v}
    for update in unary_updates.values():
        reg.check_term(update)
        assert free_vars(update) <= {"v"}
    reg.check_term(k)
    assert free_vars(k) <= {"k", "v"}
    assert not free_vars(k) <= {"v"}

    # Counter-dependence remains legal in definitions: the half iterator and
    # the latch are examples. Arithmetic schema eligibility is separate.
    assert set(reg.declarations[5]["free_variables"]) == {"k", "v"}
    bad_parameter_update = plus(v, a)
    assert not free_vars(bad_parameter_update) <= {"k", "v"}
    try:
        reg.add_iterator("IllegalFrozenParameter", bad_parameter_update)
    except AssertionError:
        pass
    else:
        raise AssertionError("The definition checker accepted a hidden parameter.")

    # The stationary-reflection term is already expressible in this grammar.
    reflection = plus(mon(mon(a, n), n), mon(n, a))
    reg.check_term(reflection)
    assert free_vars(reflection) == {"n", "a"}

    # Optional delayed iterator: its compilation is genuine finite syntax,
    # not an extra numerical axiom or a hidden function parameter.
    delayed_updates = [v, S(v), p(v), plus(v, v), mon(v, S(v)),
                       half(v), parity(v), C(v, plus(v, ONE), p(v))]
    delayed_compiled = []
    for index, unary in enumerate(delayed_updates):
        reg.check_term(unary)
        assert free_vars(unary) <= {"v"}
        delayed_update = C(k, v, unary)
        assert free_vars(delayed_update) <= {"k", "v"}
        name = f"Delayed_{index:03d}"
        reg.add_iterator(name, delayed_update)
        b = var("b")
        assert reg.normalize(app(name, ZERO, b)) == b
        assert reg.normalize(app(name, ONE, b)) == b
        twice_successor = app(name, S(S(n)), b)
        rho_of_previous = subst(unary, {"v": app(name, S(n), b)})
        assert reg.normalize(twice_successor) == reg.normalize(rho_of_previous)
        delayed_compiled.append({"autonomous_update": unary.data(),
                                 "autonomous_update_text": pretty(unary),
                                 "delayed_update_name": name,
                                 "delayed_update": delayed_update.data(),
                                 "delayed_update_text": pretty(delayed_update),
                                 "free_variables": sorted(free_vars(delayed_update)),
                                 "constructor_rewrite_checks": "all three passed using D0/DS only"})

    return {
        "status": "all finite syntax checks passed",
        "tested_target_count": len(targets),
        "declaration_count": len(reg.declarations),
        "declarations": reg.declarations,
        "compiled_latches": compiled,
        "arithmetic_update_restriction": {
            "allowed_checked": {name: update.data() for name, update in unary_updates.items()},
            "strict_exclusion_witness": k.data(),
            "witness_meaning": "h(k,v)=k is admitted by binary PU but not by autonomous AU.",
            "qualification": "The update restriction is syntactically strict. The full-orbit "
                             "premise also strengthens the positive-tail premise, so "
                             "AU is not literally a subfamily of the old displayed "
                             "axioms. Equivalence of theories is proved in the manuscript.",
        },
        "premise_strengthening_witness": {
            "term": gate(n, ONE).data(),
            "term_text": "f(n)=B(n,1)",
            "update": v.data(),
            "positive_tail": "f(SSn)=0=f(Sn), by computation",
            "full_orbit_failure": "At n=0, the full recurrence would say 0=1.",
            "meaning": "The positive-tail premise can hold while the full-orbit premise fails.",
        },
        "stationary_reflection_term": reflection.data(),
        "stationary_reflection_text": pretty(reflection),
        "optional_delayed_compiler": {
            "formula": "K_h(k,v)=C(k,v,h(v)); D_h=I_{K_h}",
            "fully_expanded_outer_context": "K_h(k,v)=P(B(k,S(v)),h(v))",
            "instances": delayed_compiled,
            "constructor_reductions": [
                "D_h(0,b)=b", "D_h(1,b)=b",
                "D_h(SSn,b)=h(D_h(Sn,b))"],
            "qualification": "The finite syntax and all three symbolic reductions "
                             "are executed for the eight supplied updates. The "
                             "normalizer uses only the two defining equations for "
                             "each iterator, with no logical assumptions, induction "
                             "or coverage hypothesis. The general compiler argument "
                             "is in the accompanying notes and manuscript.",
        },
        "limits": "Finite checks and syntactic bookkeeping only. This does not prove "
                  "the latch arithmetic, stationary reflection, or conservative equivalence.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write the complete JSON audit here.")
    args = parser.parse_args()
    result = {"formula_audit": formula_audit(), "syntax_audit": syntax_audit()}
    encoded = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
        print(json.dumps({"status": "passed", "output": str(args.output),
                          "target_count": result["syntax_audit"]["tested_target_count"],
                          "metric_rows": {name: {k: row[k] for k in ("nodes", "equality_occurrences")}
                              for name, row in result["formula_audit"]["rows"].items()}}, indent=2))
    else:
        print(encoded, end="")


if __name__ == "__main__":
    main()
