/-
Constructive Boolean diagonal propagation over an arbitrary carrier.
Lean 4.19.0, no imports.

This certificate checks the row-scanner reduction used before native equality
reflection. The arithmetic record lists previously derived equations. The
bit-storage record lists the already derived two tag-decoding laws. From the
scanner's two defining equations and its identity-update uniqueness instance,
the certificate derives preservation of the stored parameter and both row
recursion equations. The finite iterator descriptions are displayed in
notes/boolean_bootstrap.txt.

The only induction inputs are three explicitly displayed families of ZERO
induction instances. Each has at most one fixed numerical parameter. No
induction over arbitrary predicates, no native decidable equality, no Nat
induction for the carrier, and no classical axioms are used.

This is a finite-instance semantic audit. The separate positive-uniqueness
certificate and mathematical notes supply the earlier reductions. This file
does not encode the entire first-order proof calculus.
-/

namespace BooleanDiagonal

universe u

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  separation : zero ≠ succ zero
  coverage : ∀ n, n = zero ∨ n = succ (pred n)
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  select : A → A → A → A
  select_zero : ∀ x y, select zero x y = x
  select_succ : ∀ n x y, select (succ n) x y = y
  add : A → A → A
  add_comm : ∀ x y, add x y = add y x
  add_succ_right : ∀ x y, add x (succ y) = succ (add x y)
  monus : A → A → A
  monus_zero : ∀ y, monus zero y = y
  monus_right_zero : ∀ x, monus x zero = zero
  monus_succ : ∀ x y, monus (succ x) y = pred (monus x y)
  monus_shift : ∀ x y, monus (succ x) (succ y) = monus x y
  monus_cancel : ∀ x y, monus x (add x y) = y
  monus_diagonal : ∀ x, monus x x = zero

variable {A : Type u} (C : Arithmetic A)

def one : A := C.succ C.zero

def Bit (x : A) : Prop := x = C.zero ∨ x = one C

def conjunction (x y : A) : A := C.select x C.zero y

def zeroTest (x : A) : A := C.select x (one C) C.zero

def bitError (x y : A) : A := C.select x y (zeroTest C y)

def ZeroInduction (f : A → A) : Prop :=
  f C.zero = C.zero →
  (∀ n, f n = C.zero → f (C.succ n) = C.zero) →
  ∀ n, f n = C.zero

theorem one_ne_zero : one C ≠ C.zero := by
  intro h
  exact C.separation h.symm

theorem succ_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro h
  have hp := congrArg C.pred h
  rw [C.pred_succ, C.pred_zero] at hp
  exact C.separation (hp ▸ h.symm)

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases C.coverage x with hz | hs
  · exact Or.inl hz
  · exact Or.inr (fun hz => succ_ne_zero C _ (hs.symm.trans hz))

theorem select_nonzero {x : A} (hx : x ≠ C.zero) (y z : A) :
    C.select x y z = z := by
  rcases C.coverage x with hz | hs
  · exact False.elim (hx hz)
  · rw [hs, C.select_succ]

theorem select_one (x y : A) : C.select (one C) x y = y := by
  exact C.select_succ C.zero x y

theorem zero_test_zero : zeroTest C C.zero = one C := C.select_zero _ _

theorem zero_test_succ (x : A) : zeroTest C (C.succ x) = C.zero :=
  C.select_succ _ _ _

theorem zero_test_nonzero {x : A} (hx : x ≠ C.zero) :
    zeroTest C x = C.zero := select_nonzero C hx _ _

theorem zero_test_bit (x : A) : Bit C (zeroTest C x) := by
  rcases C.coverage x with hz | hs
  · rw [hz, zero_test_zero]
    exact Or.inr rfl
  · rw [hs, zero_test_succ]
    exact Or.inl rfl

theorem select_bit (x : A) {y z : A} (hy : Bit C y) (hz : Bit C z) :
    Bit C (C.select x y z) := by
  rcases C.coverage x with hzero | hs
  · rw [hzero, C.select_zero]
    exact hy
  · rw [hs, C.select_succ]
    exact hz

theorem conjunction_zero_left (x : A) :
    conjunction C C.zero x = C.zero := by
  exact C.select_zero _ _

theorem conjunction_one_left (x : A) : conjunction C (one C) x = x := by
  exact select_one C _ _

theorem conjunction_one_right {x : A} (hx : Bit C x) :
    conjunction C x (one C) = x := by
  rcases hx with hz | ho
  · rw [hz, conjunction_zero_left]
  · rw [ho, conjunction_one_left]

theorem conjunction_bit (x : A) {y : A} (hy : Bit C y) :
    Bit C (conjunction C x y) := by
  rcases C.coverage x with hz | hs
  · rw [hz, conjunction_zero_left]
    exact Or.inl rfl
  · change Bit C (C.select x C.zero y)
    rw [hs, C.select_succ]
    exact hy

theorem conjunction_eq_one {x y : A} (hx : Bit C x) (_hy : Bit C y) :
    conjunction C x y = one C ↔ x = one C ∧ y = one C := by
  constructor
  · intro h
    rcases hx with hz | ho
    · rw [hz, conjunction_zero_left] at h
      exact False.elim (C.separation h)
    · rw [ho, conjunction_one_left] at h
      exact ⟨ho, h⟩
  · intro h
    rw [h.1, conjunction_one_left, h.2]

theorem bit_error_zero {x y : A} (hx : Bit C x) (hy : Bit C y) :
    bitError C x y = C.zero ↔ x = y := by
  rcases hx with hx | hx <;> rcases hy with hy | hy
  · rw [hx, hy]
    change C.select C.zero C.zero (zeroTest C C.zero) = C.zero ↔ _
    rw [C.select_zero]
  · rw [hx, hy]
    change C.select C.zero (one C) (zeroTest C (one C)) = C.zero ↔ _
    rw [C.select_zero]
    exact ⟨fun h => False.elim (one_ne_zero C h),
      fun h => False.elim (C.separation h)⟩
  · rw [hx, hy]
    change C.select (one C) C.zero (C.select C.zero (one C) C.zero) =
      C.zero ↔ _
    rw [select_one, C.select_zero]
  · rw [hx, hy]
    change C.select (one C) (one C) (C.select (one C) (one C) C.zero) =
      C.zero ↔ _
    rw [select_one, select_one]
    exact ⟨fun _ => rfl, fun _ => rfl⟩

theorem boolean_equation_induction (f g : A → A)
    (hf : ∀ n, Bit C (f n)) (hg : ∀ n, Bit C (g n))
    (zi : ZeroInduction C (fun n => bitError C (f n) (g n)))
    (base : f C.zero = g C.zero)
    (step : ∀ n, f n = g n → f (C.succ n) = g (C.succ n)) :
    ∀ n, f n = g n := by
  have hb : bitError C (f C.zero) (g C.zero) = C.zero :=
    (bit_error_zero C (hf _) (hg _)).2 base
  have hs : ∀ n, bitError C (f n) (g n) = C.zero →
      bitError C (f (C.succ n)) (g (C.succ n)) = C.zero := by
    intro n h
    exact (bit_error_zero C (hf _) (hg _)).2
      (step n ((bit_error_zero C (hf _) (hg _)).1 h))
  intro n
  exact (bit_error_zero C (hf n) (hg n)).1 (zi hb hs n)

/-- The binary tag storage is derived before native equality reflection. -/
structure BitStorage where
  half : A → A
  parity : A → A
  encode : A → A → A
  parity_bit : ∀ n, Bit C (parity n)
  half_encode : ∀ a b, Bit C b → half (encode a b) = a
  parity_encode : ∀ a b, Bit C b → parity (encode a b) = b

def scannerUpdate (S : BitStorage C) (q : A → A → A) (i v : A) : A :=
  S.encode (S.half v)
    (conjunction C (S.parity v) (q i (C.monus i (S.half v))))

/-- One identity-update instance of the already derived uniqueness schema. -/
def ConstantUniqueness (f : A → A) : Prop :=
  (∀ n, f (C.succ n) = f n) → ∀ n, f n = f C.zero

structure ScannerData (S : BitStorage C) (q : A → A → A) where
  state : A → A → A
  state_zero : ∀ k, state C.zero k = S.encode k (one C)
  state_succ : ∀ n k, state (C.succ n) k =
    scannerUpdate C S q n (state n k)
  stored_parameter_unique : ∀ k,
    ConstantUniqueness C (fun n => S.half (state n k))

def scannerRow (S : BitStorage C) {q : A → A → A}
    (V : ScannerData C S q) (n k : A) : A := S.parity (V.state n k)

theorem stored_parameter (S : BitStorage C) (q : A → A → A)
    (qbit : ∀ x y, Bit C (q x y)) (V : ScannerData C S q) (n k : A) :
    S.half (V.state n k) = k := by
  have hstep : ∀ i, S.half (V.state (C.succ i) k) = S.half (V.state i k) := by
    intro i
    rw [V.state_succ]
    change S.half (S.encode (S.half (V.state i k))
      (conjunction C (S.parity (V.state i k))
        (q i (C.monus i (S.half (V.state i k)))))) = S.half (V.state i k)
    exact S.half_encode _ _ (conjunction_bit C _ (qbit _ _))
  have h := V.stored_parameter_unique k hstep n
  change S.half (V.state n k) = S.half (V.state C.zero k) at h
  rw [V.state_zero, S.half_encode _ _ (Or.inr rfl)] at h
  exact h

theorem scanner_row_zero (S : BitStorage C) (q : A → A → A)
    (V : ScannerData C S q) (k : A) : scannerRow C S V C.zero k = one C := by
  change S.parity (V.state C.zero k) = one C
  rw [V.state_zero]
  exact S.parity_encode _ _ (Or.inr rfl)

theorem scanner_row_succ (S : BitStorage C) (q : A → A → A)
    (qbit : ∀ x y, Bit C (q x y)) (V : ScannerData C S q) (n k : A) :
    scannerRow C S V (C.succ n) k =
      conjunction C (scannerRow C S V n k) (q n (C.monus n k)) := by
  change S.parity (V.state (C.succ n) k) = _
  rw [V.state_succ]
  change S.parity (S.encode (S.half (V.state n k))
    (conjunction C (S.parity (V.state n k))
      (q n (C.monus n (S.half (V.state n k)))))) = _
  rw [S.parity_encode _ _ (conjunction_bit C _ (qbit _ _)),
    stored_parameter C S q qbit V n k]
  rfl

structure DiagonalData where
  value : A → A → A
  bit : ∀ x y, Bit C (value x y)
  zero_left : ∀ y, value C.zero y = one C
  zero_right : ∀ x, value x C.zero = one C
  shift : ∀ x y, value (C.succ x) (C.succ y) = value x y
  row : A → A → A
  row_zero : ∀ k, row C.zero k = one C
  row_succ : ∀ n k, row (C.succ n) k =
    conjunction C (row n k) (value n (C.monus n k))

variable (D : DiagonalData C)

def fullRow (k : A) : A := D.row (C.succ k) k

structure InductionInputs : Prop where
  row_shift : ∀ k, ZeroInduction C (fun n => bitError C
    (D.row (C.succ n) (C.succ (C.succ k))) (D.row n k))
  paired_rows : ZeroInduction C (fun k => bitError C
    (conjunction C (fullRow C D k) (fullRow C D (C.succ k))) (one C))
  descending_prefix : ∀ k, ZeroInduction C (fun j => bitError C
    (D.row (C.monus j (C.succ k)) k) (one C))

theorem row_bit (n k : A) : Bit C (D.row n k) := by
  rcases C.coverage n with hz | hs
  · rw [hz, D.row_zero]
    exact Or.inr rfl
  · rw [hs, D.row_succ]
    exact conjunction_bit C _ (D.bit _ _)

theorem pred_monus_succ (i k : A) :
    C.pred (C.monus i (C.succ k)) = C.monus i k := by
  rw [← C.monus_succ, C.monus_shift]

theorem shifted_value (i k : A) :
    D.value (C.succ i) (C.monus (C.succ i) (C.succ (C.succ k))) =
      D.value i (C.monus i k) := by
  rw [C.monus_shift]
  rcases C.coverage (C.monus i (C.succ k)) with hz | hs
  · have hp : C.monus i k = C.zero := by
      rw [← pred_monus_succ C i k, hz, C.pred_zero]
    rw [hz, hp, D.zero_right, D.zero_right]
  · calc
      D.value (C.succ i) (C.monus i (C.succ k)) =
          D.value (C.succ i) (C.succ (C.pred (C.monus i (C.succ k)))) :=
        congrArg (D.value (C.succ i)) hs
      _ = D.value i (C.pred (C.monus i (C.succ k))) := D.shift _ _
      _ = D.value i (C.monus i k) :=
        congrArg (D.value i) (pred_monus_succ C i k)

theorem row_shift (I : InductionInputs C D) (n k : A) :
    D.row (C.succ n) (C.succ (C.succ k)) = D.row n k := by
  apply boolean_equation_induction C
      (fun m => D.row (C.succ m) (C.succ (C.succ k)))
      (fun m => D.row m k)
      (fun m => row_bit C D _ _) (fun m => row_bit C D _ _)
      (I.row_shift k)
  · rw [D.row_succ, D.row_zero, D.zero_left, conjunction_one_left,
      D.row_zero]
  · intro m ih
    rw [D.row_succ, ih, shifted_value C D, D.row_succ]

theorem full_row_bit (k : A) : Bit C (fullRow C D k) := row_bit C D _ _

theorem full_row_zero : fullRow C D C.zero = one C := by
  change D.row (C.succ C.zero) C.zero = one C
  rw [D.row_succ, D.row_zero, D.zero_left, conjunction_one_left]

theorem full_row_one : fullRow C D (one C) = one C := by
  change D.row (C.succ (one C)) (one C) = one C
  rw [D.row_succ, C.monus_diagonal, D.zero_right]
  rw [conjunction_one_right C (row_bit C D _ _)]
  change D.row (C.succ C.zero) (one C) = one C
  rw [D.row_succ, D.row_zero, D.zero_left, conjunction_one_left]

theorem full_row_two_step (I : InductionInputs C D) (k : A) :
    fullRow C D (C.succ (C.succ k)) = fullRow C D k := by
  change D.row (C.succ (C.succ (C.succ k))) (C.succ (C.succ k)) = _
  rw [row_shift C D I, D.row_succ, C.monus_succ, C.monus_diagonal,
    C.pred_zero, D.zero_right]
  exact conjunction_one_right C (row_bit C D _ _)

theorem all_full_rows (I : InductionInputs C D) (k : A) :
    fullRow C D k = one C := by
  have hp : ∀ n, conjunction C (fullRow C D n)
      (fullRow C D (C.succ n)) = one C := by
    apply boolean_equation_induction C
      (fun n => conjunction C (fullRow C D n) (fullRow C D (C.succ n)))
      (fun _ => one C)
      (fun n => conjunction_bit C _ (full_row_bit C D _))
      (fun _ => Or.inr rfl) I.paired_rows
    · change conjunction C (fullRow C D C.zero) (fullRow C D (one C)) = one C
      rw [full_row_zero, full_row_one, conjunction_one_left]
    · intro n ih
      have both := (conjunction_eq_one C
        (full_row_bit C D n) (full_row_bit C D (C.succ n))).1 ih
      rw [both.2, conjunction_one_left, full_row_two_step C D I, both.1]
  exact ((conjunction_eq_one C
    (full_row_bit C D k) (full_row_bit C D (C.succ k))).1 (hp k)).1

theorem descending_prefix (I : InductionInputs C D) (j k : A) :
    D.row (C.monus j (C.succ k)) k = one C := by
  apply boolean_equation_induction C
    (fun i => D.row (C.monus i (C.succ k)) k)
    (fun _ => one C)
    (fun i => row_bit C D _ _) (fun _ => Or.inr rfl)
    (I.descending_prefix k)
  · rw [C.monus_zero]
    exact all_full_rows C D I k
  · intro i ih
    rw [C.monus_succ]
    rcases C.coverage (C.monus i (C.succ k)) with hz | hs
    · rw [hz, C.pred_zero, D.row_zero]
    · have fact : conjunction C (D.row (C.pred (C.monus i (C.succ k))) k)
          (D.value (C.pred (C.monus i (C.succ k)))
            (C.monus (C.pred (C.monus i (C.succ k))) k)) = one C := by
        rw [← D.row_succ]
        exact (congrArg (fun n => D.row n k) hs.symm).trans ih
      exact ((conjunction_eq_one C (row_bit C D _ _) (D.bit _ _)).1 fact).1

theorem complement_index (x y : A) :
    C.monus y (C.succ (C.add x y)) = C.succ x := by
  calc
    C.monus y (C.succ (C.add x y)) =
        C.monus y (C.succ (C.add y x)) := by rw [C.add_comm x y]
    _ = C.monus y (C.add y (C.succ x)) := by rw [C.add_succ_right]
    _ = C.succ x := C.monus_cancel _ _

theorem diagonal_propagation (I : InductionInputs C D) (x y : A) :
    D.value x y = one C := by
  have hr := descending_prefix C D I y (C.add x y)
  rw [complement_index C, D.row_succ, C.monus_cancel] at hr
  exact ((conjunction_eq_one C (row_bit C D _ _) (D.bit _ _)).1 hr).2

/-- A Boolean code for “r is nonzero iff v is zero”. -/
def complementCode (r v : A) : A :=
  C.select r (zeroTest C (zeroTest C v)) (zeroTest C v)

def comparisonCode (n a : A) : A :=
  complementCode C (C.monus n a) (C.monus a (C.succ n))

theorem complement_code_true (r v : A) :
    complementCode C r v = one C ↔ (r ≠ C.zero ↔ v = C.zero) := by
  rcases zero_decision C r with hr | hr <;>
    rcases zero_decision C v with hv | hv
  · rw [hr, hv]
    change C.select C.zero (zeroTest C (zeroTest C C.zero))
      (zeroTest C C.zero) = one C ↔ _
    rw [C.select_zero, zero_test_zero]
    change zeroTest C (C.succ C.zero) = one C ↔ _
    rw [zero_test_succ]
    constructor
    · intro h
      exact False.elim (C.separation h)
    · intro h
      exact False.elim ((h.2 rfl) rfl)
  · rw [hr]
    change C.select C.zero (zeroTest C (zeroTest C v))
      (zeroTest C v) = one C ↔ _
    rw [C.select_zero, zero_test_nonzero C hv, zero_test_zero]
    constructor
    · intro _
      exact ⟨fun h => False.elim (h rfl), fun h => False.elim (hv h)⟩
    · intro _
      rfl
  · rw [hv]
    change C.select r (zeroTest C (zeroTest C C.zero))
      (zeroTest C C.zero) = one C ↔ _
    rw [select_nonzero C hr, zero_test_zero]
    constructor
    · intro _
      exact ⟨fun _ => rfl, fun _ => hr⟩
    · intro _
      rfl
  · change C.select r (zeroTest C (zeroTest C v))
      (zeroTest C v) = one C ↔ _
    rw [select_nonzero C hr, zero_test_nonzero C hv]
    constructor
    · intro h
      exact False.elim (C.separation h)
    · intro h
      exact False.elim (hv (h.1 hr))

theorem comparison_code_bit (n a : A) : Bit C (comparisonCode C n a) := by
  exact select_bit C _ (zero_test_bit C _) (zero_test_bit C _)

theorem comparison_code_zero_left (a : A) :
    comparisonCode C C.zero a = one C := by
  change C.select (C.monus C.zero a)
    (zeroTest C (zeroTest C (C.monus a (C.succ C.zero))))
    (zeroTest C (C.monus a (C.succ C.zero))) = one C
  rw [C.monus_zero]
  rcases C.coverage a with hz | hs
  · rw [hz, C.monus_zero, C.select_zero, zero_test_succ, zero_test_zero]
  · rw [hs, C.monus_shift, C.monus_right_zero, C.select_succ, zero_test_zero]

theorem comparison_code_zero_right (n : A) :
    comparisonCode C n C.zero = one C := by
  change C.select (C.monus n C.zero)
    (zeroTest C (zeroTest C (C.monus C.zero (C.succ n))))
    (zeroTest C (C.monus C.zero (C.succ n))) = one C
  rw [C.monus_right_zero, C.monus_zero, C.select_zero,
    zero_test_succ, zero_test_zero]

theorem comparison_code_shift (n a : A) :
    comparisonCode C (C.succ n) (C.succ a) = comparisonCode C n a := by
  unfold comparisonCode
  rw [C.monus_shift, C.monus_shift]

def comparisonData (S : BitStorage C) (V : ScannerData C S (comparisonCode C)) :
    DiagonalData C where
  value := comparisonCode C
  bit := comparison_code_bit C
  zero_left := comparison_code_zero_left C
  zero_right := comparison_code_zero_right C
  shift := comparison_code_shift C
  row := scannerRow C S V
  row_zero := scanner_row_zero C S (comparisonCode C) V
  row_succ := scanner_row_succ C S (comparisonCode C) (comparison_code_bit C) V

theorem comparison_complement (S : BitStorage C)
    (V : ScannerData C S (comparisonCode C))
    (I : InductionInputs C (comparisonData C S V)) (n a : A) :
    C.monus n a ≠ C.zero ↔ C.monus a (C.succ n) = C.zero := by
  apply (complement_code_true C _ _).1
  exact diagonal_propagation C (comparisonData C S V) I n a

#print axioms bit_error_zero
#print axioms boolean_equation_induction
#print axioms stored_parameter
#print axioms scanner_row_zero
#print axioms scanner_row_succ
#print axioms shifted_value
#print axioms row_shift
#print axioms all_full_rows
#print axioms descending_prefix
#print axioms diagonal_propagation
#print axioms comparison_complement

end BooleanDiagonal
