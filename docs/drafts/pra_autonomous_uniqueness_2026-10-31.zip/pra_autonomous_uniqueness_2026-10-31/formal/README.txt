FORMAL VERIFICATION SCOPE

All five Lean sources are checked with Lean 4.19.0. No external packages
are required. Some new files import the bundled Std library; the printed
endpoint dependencies are empty. An empty printed axiom list concerns
Lean logical constants: the displayed arithmetic hypotheses remain
explicit theorem inputs.

NEW FILES

FullOrbitKernel.lean
  One selected identity/successor AU instance yields separation,
  successor laws, constructor coverage, and zero decision.
  Two selected trajectory instances yield ordinary autonomous uniqueness.
  No global quantification over all semantic functions as an axiom.

DelayedOrbitKernel.lean
  Direct P/B selector computations, the delayed iterator equations,
  one selected DU constructor instance, and the two-trajectory comparison.

StoredLatch.lean
  Given selector laws, positive zero decision, bit retractions, the
  explicit state initialization/recurrence, and exactly two selected
  constancy callbacks, proves parameter preservation, projected latch
  equations, and zero-test induction. No carrier induction is used.
  See STORED_LATCH_SCOPE.txt.

StationaryReflection.lean
  Given the proved elementary arithmetic, coverage, and strict-comparison
  complement SC, checks stationarity of
      M(M(a,n),n) + M(n,a),
  uses the one displayed constancy instance, and derives native equality
  reflection and decision. No arbitrary recurrence uniqueness is assumed.

INHERITED FILE

BooleanDiagonal.lean
  Copied without modification from the (1) positive-uniqueness archive
  at the repository commit recorded in SOURCES.json. Its companion
  notes/boolean_bootstrap.txt is also included unchanged.
  Checks the stored row parameter, row recurrence, diagonal propagation,
  and strict-comparison complement from explicit arithmetic hypotheses
  and selected zero-induction inputs. Its existing dependency statements
  are conditional kernels, not a complete first-order theory formalization.

WRITTEN OBLIGATIONS

The paper supplies the finite term/declaration grammar, the admissibility
of each displayed schema instance, the derivation of the kernel inputs,
all quantifier-free formula compilation, tuple coding, general recursion
simulation, and conservative definitional-equivalence proof. These are
not claimed to have been fully mechanized by the five files.

The Python artifact audits actual finite syntax and formula counts but
is not an arithmetic proof checker. The paper explicitly distinguishes
these evidence levels.
