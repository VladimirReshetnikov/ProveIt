import Lean

/-!
# Delayed-orbit alternative: selected constructive kernel

This file checks the fixed selector's constructor computations, the delayed
iterator computations, constructor coverage from the single identity-orbit
instance, and ordinary unary recursion uniqueness from two selected orbit
instances. The arithmetic carrier is arbitrary. All equations and selected
schema instances are explicit theorem parameters.

It does not quantify an arithmetic axiom over every Lean function: the
parameters `t_instance` and `canonical_instance` are only the two concrete
instances used in the reduction. Finite-syntax admissibility and the
surrounding first-order equivalence proof remain in the manuscript.
-/

set_option autoImplicit false

namespace UnaryPositiveUniqueness.DelayedOrbit

universe u

structure SeedKernel (A : Type u) where
  zero : A
  succ : A → A
  seededPred : A → A → A
  gate : A → A → A
  seededPred_zero : ∀ a, seededPred zero a = a
  seededPred_succ : ∀ n a, seededPred (succ n) a = n
  gate_zero : ∀ a, gate zero a = a
  gate_succ : ∀ n a, gate (succ n) a = zero

variable {A : Type u}

def pred (m : SeedKernel A) (x : A) : A :=
  m.seededPred x m.zero

def select (m : SeedKernel A) (k v w : A) : A :=
  m.seededPred (m.gate k (m.succ v)) w

theorem pred_zero (m : SeedKernel A) : pred m m.zero = m.zero :=
  m.seededPred_zero m.zero

theorem pred_succ (m : SeedKernel A) (x : A) : pred m (m.succ x) = x :=
  m.seededPred_succ x m.zero

theorem select_zero (m : SeedKernel A) (v w : A) :
    select m m.zero v w = v :=
  (congrArg (fun t => m.seededPred t w) (m.gate_zero (m.succ v))).trans
    (m.seededPred_succ v w)

theorem select_succ (m : SeedKernel A) (k v w : A) :
    select m (m.succ k) v w = w :=
  (congrArg (fun t => m.seededPred t w) (m.gate_succ k (m.succ v))).trans
    (m.seededPred_zero w)

def DelayedComputation (m : SeedKernel A) (h : A → A)
    (delayed : A → A → A) : Prop :=
  (∀ b, delayed m.zero b = b) ∧
  ∀ n b, delayed (m.succ n) b =
    select m n (delayed n b) (h (delayed n b))

theorem delayed_one (m : SeedKernel A) (h : A → A)
    (delayed : A → A → A) (compute : DelayedComputation m h delayed)
    (b : A) : delayed (m.succ m.zero) b = b :=
  (compute.2 m.zero b).trans
    ((select_zero m (delayed m.zero b) (h (delayed m.zero b))).trans
      (compute.1 b))

theorem delayed_positive_step (m : SeedKernel A) (h : A → A)
    (delayed : A → A → A) (compute : DelayedComputation m h delayed)
    (n b : A) :
    delayed (m.succ (m.succ n)) b = h (delayed (m.succ n) b) :=
  (compute.2 (m.succ n) b).trans
    (select_succ m n (delayed (m.succ n) b)
      (h (delayed (m.succ n) b)))

theorem succ_nonzero (m : SeedKernel A)
    (separate : m.zero ≠ m.succ m.zero) (x : A) :
    m.succ x ≠ m.zero := by
  intro successor_zero
  have x_zero : x = m.zero :=
    (pred_succ m x).symm.trans
      ((congrArg (pred m) successor_zero).trans (pred_zero m))
  have one_zero : m.succ m.zero = m.zero :=
    (congrArg m.succ x_zero).symm.trans successor_zero
  exact separate one_zero.symm

/-- The positive conclusion of the selected instance f(n)=n and h(v)=Sv. -/
theorem coverage_from_identity_orbit (m : SeedKernel A)
    (delayedSucc : A → A → A)
    (identity_positive : ∀ n, n = m.zero ∨
      n = m.succ (delayedSucc n m.zero))
    (n : A) : n = m.zero ∨ n = m.succ (pred m n) := by
  cases identity_positive n with
  | inl is_zero => exact Or.inl is_zero
  | inr is_successor =>
    have predecessor : pred m n = delayedSucc n m.zero :=
      (congrArg (pred m) is_successor).trans
        (pred_succ m (delayedSucc n m.zero))
    exact Or.inr (is_successor.trans (congrArg m.succ predecessor.symm))

def PositiveConclusion (m : SeedKernel A) (h : A → A)
    (delayed : A → A → A) (f : A → A → A) (a : A) : Prop :=
  ∀ n, n = m.zero ∨ f n a = h (delayed n (f m.zero a))

def OrbitInstance (m : SeedKernel A) (h : A → A)
    (delayed : A → A → A) (f : A → A → A) (a : A) : Prop :=
  (∀ n, f (m.succ n) a = h (f n a)) →
    (m.zero ≠ m.succ m.zero ∧ PositiveConclusion m h delayed f a)

theorem two_solutions_equal (m : SeedKernel A) (h : A → A)
    (delayed : A → A → A) (f g : A → A → A) (a : A)
    (f_positive : PositiveConclusion m h delayed f a)
    (g_positive : PositiveConclusion m h delayed g a)
    (same_initial : f m.zero a = g m.zero a) (n : A) : f n a = g n a := by
  have at_zero : n = m.zero → f n a = g n a := by
    intro n_zero
    exact (congrArg (fun t => f t a) n_zero).trans
      (same_initial.trans (congrArg (fun t => g t a) n_zero).symm)
  cases f_positive n with
  | inl n_zero => exact at_zero n_zero
  | inr f_value =>
    cases g_positive n with
    | inl n_zero => exact at_zero n_zero
    | inr g_value =>
      exact f_value.trans
        ((congrArg (fun b => h (delayed n b)) same_initial).trans g_value.symm)

/-- The canonical trajectory is a finite term when t and its iterator are. -/
theorem ordinary_uniqueness (m : SeedKernel A) (h : A → A)
    (delayed canonical : A → A → A) (t : A → A → A) (a : A)
    (canonical_zero : ∀ b, canonical m.zero b = b)
    (canonical_step : ∀ n b, canonical (m.succ n) b = h (canonical n b))
    (t_instance : OrbitInstance m h delayed t a)
    (canonical_instance : OrbitInstance m h delayed
      (fun n b => canonical n (t m.zero b)) a)
    (recurrence : ∀ n, t (m.succ n) a = h (t n a))
    (n : A) : t n a = canonical n (t m.zero a) := by
  have t_positive := (t_instance recurrence).2
  have canonical_positive := (canonical_instance
    (fun k => canonical_step k (t m.zero a))).2
  exact two_solutions_equal m h delayed t
    (fun k b => canonical k (t m.zero b)) a t_positive canonical_positive
    (canonical_zero (t m.zero a)).symm n

#print axioms pred_zero
#print axioms pred_succ
#print axioms select_zero
#print axioms select_succ
#print axioms delayed_one
#print axioms delayed_positive_step
#print axioms succ_nonzero
#print axioms coverage_from_identity_orbit
#print axioms two_solutions_equal
#print axioms ordinary_uniqueness

end UnaryPositiveUniqueness.DelayedOrbit
