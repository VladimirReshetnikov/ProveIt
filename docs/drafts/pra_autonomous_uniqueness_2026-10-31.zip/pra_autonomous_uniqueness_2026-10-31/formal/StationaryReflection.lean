import Lean

/-!
# Native equality reflection using one stationary term

The carrier is arbitrary. The equations below, positive constructor coverage,
and strict comparison duality are explicit hypotheses derived earlier in the
accompanying manuscript. No ordering or equality oracle is assumed.

The new term is

  F(n,a) = M(M(a,n),n) + M(n,a),

where M(x,y) is truncated subtraction with the counter first: y minus x.
We prove F(Sn,a) = F(n,a) by constructive case analysis, and F(0,a) = a.
For every fixed parameter a, exactly the constancy instance for this displayed
term is supplied as a callback. It is the instance derived from the unary
update h(v) = v, not an axiom for all Lean functions or predicates.

Consequently F(n,a) = a. Mutual vanishing of M(n,a) and M(a,n) now gives
n = a. The sum of the two remainders reflects native equality, and native
equality is decidable.

This checks the new reflection kernel. It does not by itself formalize the
entire first-order proof calculus, the earlier Boolean diagonal argument, or
the final conservative definitional extension theorem. All assumptions are
ordinary theorem parameters, and the printed global axiom audits are empty.
-/

set_option autoImplicit false

namespace UnaryPositiveUniqueness.StationaryReflection

universe u

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  add : A → A → A
  monus : A → A → A
  pred_zero : pred zero = zero
  coverage : ∀ x, x = zero ∨ x = succ (pred x)
  succ_nonzero : ∀ x, succ x ≠ zero
  add_zero_left : ∀ x, add zero x = x
  add_zero_right : ∀ x, add x zero = x
  add_succ_left : ∀ x y, add (succ x) y = succ (add x y)
  add_succ_right : ∀ x y, add x (succ y) = succ (add x y)
  monus_zero_left : ∀ x, monus zero x = x
  monus_zero_right : ∀ x, monus x zero = zero
  monus_succ_left : ∀ x y, monus (succ x) y = pred (monus x y)
  monus_shift : ∀ x y, monus (succ x) (succ y) = monus x y
  monus_pred_second : ∀ x y, pred (monus x (succ y)) = monus x y
  monus_diagonal : ∀ x, monus x x = zero

variable {A : Type u}

def StrictDuality (m : Arithmetic A) : Prop :=
  ∀ n a, m.monus n a ≠ m.zero ↔ m.monus a (m.succ n) = m.zero

def residualSum (m : Arithmetic A) (n a : A) : A :=
  m.add (m.monus (m.monus a n) n) (m.monus n a)

/-- Only the constancy callback for the particular displayed residual sum. -/
def ResidualConstancy (m : Arithmetic A) (a : A) : Prop :=
  (∀ n, residualSum m (m.succ n) a = residualSum m n a) →
    ∀ n, residualSum m n a = residualSum m m.zero a

def equalityError (m : Arithmetic A) (x y : A) : A :=
  m.add (m.monus x y) (m.monus y x)

theorem add_congr (m : Arithmetic A) {x y z w : A}
    (first : x = y) (second : z = w) : m.add x z = m.add y w :=
  (congrArg (fun t => m.add t z) first).trans
    (congrArg (m.add y) second)

theorem zero_decision (m : Arithmetic A) (x : A) :
    x = m.zero ∨ x ≠ m.zero := by
  cases m.coverage x with
  | inl is_zero => exact Or.inl is_zero
  | inr is_succ =>
    apply Or.inr
    intro is_zero
    exact m.succ_nonzero (m.pred x) (is_succ.symm.trans is_zero)

theorem residual_zero (m : Arithmetic A) (a : A) :
    residualSum m m.zero a = a := by
  have inner : m.monus (m.monus a m.zero) m.zero = m.zero :=
    (congrArg (fun t => m.monus t m.zero) (m.monus_zero_right a)).trans
      (m.monus_zero_left m.zero)
  exact (add_congr m inner (m.monus_zero_left a)).trans (m.add_zero_left a)

theorem residual_stationary (m : Arithmetic A) (dual : StrictDuality m)
    (n a : A) :
    residualSum m (m.succ n) a = residualSum m n a := by
  cases zero_decision m (m.monus n a) with
  | inl remainder_zero =>
    have opposite_nonzero : m.monus a (m.succ n) ≠ m.zero := by
      intro opposite_zero
      exact (dual n a).mpr opposite_zero remainder_zero
    have opposite_successor :
        m.monus a (m.succ n) = m.succ (m.monus a n) := by
      have covered := (m.coverage (m.monus a (m.succ n))).resolve_left
        opposite_nonzero
      exact covered.trans (congrArg m.succ (m.monus_pred_second a n))
    have first_summand :
        m.monus (m.monus a (m.succ n)) (m.succ n) =
          m.monus (m.monus a n) n :=
      (congrArg (fun t => m.monus t (m.succ n)) opposite_successor).trans
        (m.monus_shift (m.monus a n) n)
    have second_summand : m.monus (m.succ n) a = m.monus n a :=
      (m.monus_succ_left n a).trans
        ((congrArg m.pred remainder_zero).trans
          (m.pred_zero.trans remainder_zero.symm))
    exact add_congr m first_summand second_summand
  | inr remainder_nonzero =>
    have opposite_next_zero : m.monus a (m.succ n) = m.zero :=
      (dual n a).mp remainder_nonzero
    have opposite_zero : m.monus a n = m.zero :=
      (m.monus_pred_second a n).symm.trans
        ((congrArg m.pred opposite_next_zero).trans m.pred_zero)
    have remainder_successor :
        m.monus n a = m.succ (m.pred (m.monus n a)) :=
      (m.coverage (m.monus n a)).resolve_left remainder_nonzero
    have add_step :
        m.add (m.succ n) (m.pred (m.monus n a)) =
          m.add n (m.monus n a) :=
      (m.add_succ_left n (m.pred (m.monus n a))).trans
        ((m.add_succ_right n (m.pred (m.monus n a))).symm.trans
          (congrArg (m.add n) remainder_successor.symm))
    have next_reduction : residualSum m (m.succ n) a =
        m.add (m.succ n) (m.pred (m.monus n a)) :=
      add_congr m
        ((congrArg (fun t => m.monus t (m.succ n)) opposite_next_zero).trans
          (m.monus_zero_left (m.succ n)))
        (m.monus_succ_left n a)
    have current_reduction : residualSum m n a = m.add n (m.monus n a) :=
      add_congr m
        ((congrArg (fun t => m.monus t n) opposite_zero).trans
          (m.monus_zero_left n)) rfl
    exact next_reduction.trans (add_step.trans current_reduction.symm)

theorem residual_identity (m : Arithmetic A) (dual : StrictDuality m)
    (a : A) (constant : ResidualConstancy m a) (n : A) :
    residualSum m n a = a := by
  exact (constant (fun k => residual_stationary m dual k a) n).trans
    (residual_zero m a)

theorem mutual_zero_reflects (m : Arithmetic A) (dual : StrictDuality m)
    (constant : ∀ a, ResidualConstancy m a) (x y : A)
    (left_zero : m.monus x y = m.zero)
    (right_zero : m.monus y x = m.zero) : x = y := by
  have reduction : residualSum m x y = x :=
    (add_congr m
      ((congrArg (fun t => m.monus t x) right_zero).trans
        (m.monus_zero_left x)) left_zero).trans (m.add_zero_right x)
  exact reduction.symm.trans (residual_identity m dual y (constant y) x)

theorem add_zero_iff (m : Arithmetic A) (r s : A) :
    m.add r s = m.zero ↔ r = m.zero ∧ s = m.zero := by
  constructor
  · intro sum_zero
    cases m.coverage r with
    | inl r_zero =>
      have s_zero : s = m.zero := by
        exact (m.add_zero_left s).symm.trans
          ((congrArg (fun x => m.add x s) r_zero).symm.trans sum_zero)
      exact ⟨r_zero, s_zero⟩
    | inr r_successor =>
      have contradiction : m.succ (m.add (m.pred r) s) = m.zero :=
        (m.add_succ_left (m.pred r) s).symm.trans
          ((congrArg (fun x => m.add x s) r_successor).symm.trans sum_zero)
      exact False.elim (m.succ_nonzero (m.add (m.pred r) s) contradiction)
  · intro both_zero
    exact (add_congr m both_zero.1 both_zero.2).trans
      (m.add_zero_left m.zero)

theorem equality_reflection (m : Arithmetic A) (dual : StrictDuality m)
    (constant : ∀ a, ResidualConstancy m a) (x y : A) :
    equalityError m x y = m.zero ↔ x = y := by
  constructor
  · intro error_zero
    have both_zero := (add_zero_iff m (m.monus x y) (m.monus y x)).mp
      error_zero
    exact mutual_zero_reflects m dual constant x y both_zero.1 both_zero.2
  · intro equal
    cases equal
    exact (add_congr m (m.monus_diagonal x) (m.monus_diagonal x)).trans
      (m.add_zero_left m.zero)

theorem equality_decision (m : Arithmetic A) (dual : StrictDuality m)
    (constant : ∀ a, ResidualConstancy m a) (x y : A) :
    x = y ∨ x ≠ y := by
  cases zero_decision m (equalityError m x y) with
  | inl error_zero =>
    exact Or.inl ((equality_reflection m dual constant x y).mp error_zero)
  | inr error_nonzero =>
    exact Or.inr (fun equal => error_nonzero
      ((equality_reflection m dual constant x y).mpr equal))

#print axioms zero_decision
#print axioms residual_zero
#print axioms residual_stationary
#print axioms residual_identity
#print axioms mutual_zero_reflects
#print axioms add_zero_iff
#print axioms equality_reflection
#print axioms equality_decision

end UnaryPositiveUniqueness.StationaryReflection
