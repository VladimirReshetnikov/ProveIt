import Std

/-!
# A stored parameter latch for zero induction

This file checks only the constructive semantic core of the reduction.
The carrier is arbitrary.  We do not induct on `Nat`, assume classical
logic, or postulate constancy for every semantic function.  The theorem
receives exactly the two constancy instances used in the manuscript:

* `n ↦ half (Q n)`;
* `n ↦ bit (Q (succ n))`.

The separate finite-syntax argument must show that `Q` is the term obtained
by the admitted initialized iterator, and that these two displayed term
instances belong to the arithmetic schema.  In the application, `one` is
`succ zero`, but that identity is not needed by this local lemma.
-/

namespace StoredLatch

universe u

def Stationary {N : Type u} (succ : N → N) (F : N → N) : Prop :=
  ∀ n, F (succ n) = F n

def ConstancyInstance {N : Type u} (zero : N) (succ : N → N)
    (F : N → N) : Prop :=
  Stationary succ F → ∀ n, F n = F zero

structure BitRetract (N : Type u) (zero one : N) where
  half : N → N
  bit : N → N
  encode : N → N → N
  bit_range : ∀ v, bit v = zero ∨ bit v = one
  half_zero : ∀ a, half (encode a zero) = a
  half_one : ∀ a, half (encode a one) = a
  bit_zero : ∀ a, bit (encode a zero) = zero
  bit_one : ∀ a, bit (encode a one) = one

section Selector

variable {N : Type u} {zero one : N}
variable (coding : BitRetract N zero one)
variable (choose : N → N → N → N)
variable (zero_cases : ∀ x : N, x = zero ∨ x ≠ zero)
variable (choose_zero : ∀ b c, choose zero b c = b)
variable (choose_nonzero : ∀ x b c, x ≠ zero → choose x b c = c)

include zero_cases choose_zero choose_nonzero in
theorem choose_same (x b : N) : choose x b b = b := by
  rcases zero_cases x with hx | hx
  · rw [hx, choose_zero]
  · exact choose_nonzero x b b hx

include zero_cases choose_zero choose_nonzero in
theorem chosen_bit (x v : N) :
    choose x (coding.bit v) zero = zero ∨
    choose x (coding.bit v) zero = one := by
  rcases zero_cases x with hx | hx
  · rw [hx, choose_zero]
    exact coding.bit_range v
  · exact Or.inl (choose_nonzero x (coding.bit v) zero hx)

theorem half_encode_bit (a b : N) (hb : b = zero ∨ b = one) :
    coding.half (coding.encode a b) = a := by
  rcases hb with hb | hb
  · rw [hb]
    exact coding.half_zero a
  · rw [hb]
    exact coding.half_one a

theorem bit_encode_bit (a b : N) (hb : b = zero ∨ b = one) :
    coding.bit (coding.encode a b) = b := by
  rcases hb with hb | hb
  · rw [hb]
    exact coding.bit_zero a
  · rw [hb]
    exact coding.bit_one a

end Selector

section Latch

variable {N : Type u} (zero one : N) (succ : N → N)
variable (separate : zero ≠ one)
variable (coding : BitRetract N zero one)
variable (choose : N → N → N → N)
variable (zero_cases : ∀ x : N, x = zero ∨ x ≠ zero)
variable (choose_zero : ∀ b c, choose zero b c = b)
variable (choose_nonzero : ∀ x b c, x ≠ zero → choose x b c = c)
variable (f : N → N → N) (a : N) (Q : N → N)
variable (Q_zero : Q zero = coding.encode a one)
variable (Q_step : ∀ n, Q (succ n) =
  coding.encode (coding.half (Q n))
    (choose (f n (coding.half (Q n))) (coding.bit (Q n)) zero))

include zero_cases choose_zero choose_nonzero Q_zero Q_step in
/-- Parameter preservation uses only the constancy instance for `half ∘ Q`. -/
theorem parameter_preserved
    (constancy_half : ConstancyInstance zero succ (fun n => coding.half (Q n))) :
    ∀ n, coding.half (Q n) = a := by
  have hstationary : Stationary succ (fun n => coding.half (Q n)) := by
    intro n
    change coding.half (Q (succ n)) = coding.half (Q n)
    rw [Q_step]
    exact half_encode_bit coding _ _
      (chosen_bit coding choose zero_cases choose_zero choose_nonzero _ _)
  have hconstant := constancy_half hstationary
  intro n
  calc
    coding.half (Q n) = coding.half (Q zero) := hconstant n
    _ = coding.half (coding.encode a one) := congrArg coding.half Q_zero
    _ = a := coding.half_one a

include zero_cases choose_zero choose_nonzero Q_step in
/--
The exact stored latch step after the numerical parameter has been
recovered.  The update itself never reads the original seed separately.
-/
theorem bit_recurrence
    (parameter_invariant : ∀ n, coding.half (Q n) = a) :
    ∀ n, coding.bit (Q (succ n)) =
      choose (f n a) (coding.bit (Q n)) zero := by
  intro n
  calc
    coding.bit (Q (succ n)) = coding.bit
      (coding.encode (coding.half (Q n))
        (choose (f n (coding.half (Q n))) (coding.bit (Q n)) zero)) :=
          congrArg coding.bit (Q_step n)
    _ = choose (f n (coding.half (Q n))) (coding.bit (Q n)) zero :=
      bit_encode_bit coding _ _
        (chosen_bit coding choose zero_cases choose_zero choose_nonzero _ _)
    _ = choose (f n a) (coding.bit (Q n)) zero := by
      rw [parameter_invariant n]

include separate zero_cases choose_zero choose_nonzero Q_zero Q_step in
/--
Zero induction from precisely two term-specific constancy instances.
The proof is constructive: all case splits use the supplied positive
zero decision.  In particular, no classical principle or induction on
the arbitrary carrier occurs.
-/
theorem zero_induction
    (constancy_half : ConstancyInstance zero succ (fun n => coding.half (Q n)))
    (constancy_shift : ConstancyInstance zero succ
      (fun n => coding.bit (Q (succ n))))
    (base : f zero a = zero)
    (step : ∀ n, f n a = zero → f (succ n) a = zero) :
    ∀ n, f n a = zero := by
  have hparam : ∀ n, coding.half (Q n) = a :=
    parameter_preserved zero one succ coding choose zero_cases
      choose_zero choose_nonzero f a Q Q_zero Q_step constancy_half
  have hrec : ∀ n, coding.bit (Q (succ n)) =
      choose (f n a) (coding.bit (Q n)) zero :=
    bit_recurrence zero one succ coding choose zero_cases choose_zero
      choose_nonzero f a Q Q_step hparam
  have hbit0 : coding.bit (Q zero) = one := by
    rw [Q_zero]
    exact coding.bit_one a
  have hbit1 : coding.bit (Q (succ zero)) = one := by
    rw [hrec zero, base, choose_zero, hbit0]
  have hstationary : Stationary succ (fun n => coding.bit (Q (succ n))) := by
    intro n
    change coding.bit (Q (succ (succ n))) = coding.bit (Q (succ n))
    rcases zero_cases (f n a) with hn | hn
    · have hnext : f (succ n) a = zero := step n hn
      rw [hrec (succ n), hnext, choose_zero]
    · have hbit : coding.bit (Q (succ n)) = zero := by
        rw [hrec n]
        exact choose_nonzero _ _ _ hn
      rw [hrec (succ n), hbit]
      exact choose_same choose zero_cases choose_zero choose_nonzero _ _
  have hconstant := constancy_shift hstationary
  have hpositive : ∀ n, coding.bit (Q (succ n)) = one := by
    intro n
    exact (hconstant n).trans hbit1
  intro n
  rcases zero_cases (f n a) with hn | hn
  · exact hn
  · have hbit : coding.bit (Q (succ n)) = zero := by
      rw [hrec n]
      exact choose_nonzero _ _ _ hn
    exact False.elim (separate (hbit.symm.trans (hpositive n)))

end Latch

#print axioms parameter_preserved
#print axioms bit_recurrence
#print axioms zero_induction

end StoredLatch
