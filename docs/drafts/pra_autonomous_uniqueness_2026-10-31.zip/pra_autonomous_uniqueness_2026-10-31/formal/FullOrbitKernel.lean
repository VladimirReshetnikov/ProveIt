import Std

/-!
# Full-orbit uniqueness: the constructive logical kernel

`OrbitInstance ... F` is one explicit schema-instance callback for the
displayed function F.  No theorem assumes a schema quantified over all
semantic functions.  In the object theory each displayed function is a
finite term, with its one fixed numerical parameter suppressed here.

This file verifies:
* separation and positive constructor coverage from the single identity
  term instance with successor update;
* common-trajectory uniqueness from the two selected term instances;
* ordinary unary iteration uniqueness by choosing the second term to be
  the canonical iterator from the first term's initial value.

The carrier is arbitrary.  No arithmetic induction, decidable equality,
or classical principle is used.
-/

namespace FullOrbitKernel

universe u

def OrbitInstance {N : Type u} (zero : N) (succ pred : N → N)
    (iter : N → N → N) (update F : N → N) : Prop :=
  (∀ n, F (succ n) = update (F n)) →
    (zero ≠ succ zero ∧
      ∀ n, n = zero ∨ F n = iter (pred n) (F (succ zero)))

section Predecessor

variable {N : Type u} (zero : N) (succ pred : N → N)

theorem successor_injective
    (pred_succ : ∀ x, pred (succ x) = x)
    {x y : N} (h : succ x = succ y) : x = y := by
  calc
    x = pred (succ x) := (pred_succ x).symm
    _ = pred (succ y) := congrArg pred h
    _ = y := pred_succ y

theorem successor_nonzero
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ x, pred (succ x) = x)
    (separate : zero ≠ succ zero) :
    ∀ x, succ x ≠ zero := by
  intro x hx
  have hxzero : x = zero := by
    calc
      x = pred (succ x) := (pred_succ x).symm
      _ = pred zero := congrArg pred hx
      _ = zero := pred_zero
  exact separate (hx.symm.trans (congrArg succ hxzero))

end Predecessor

section Coverage

variable {N : Type u} (zero : N) (succ pred : N → N)
variable (iterSucc : N → N → N)

/--
Only the instance for F(n)=n and update(v)=succ(v) is assumed.
No equations for iterSucc are needed for this bootstrap: the instance
itself first gives iterSucc(n,1)=succ(n) at successor arguments.
-/
theorem identity_instance_coverage
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ x, pred (succ x) = x)
    (au_identity : OrbitInstance zero succ pred iterSucc succ (fun n => n)) :
    zero ≠ succ zero ∧ ∀ n, n = zero ∨ n = succ (pred n) := by
  have hidentity : ∀ n : N, (fun n => n) (succ n) = succ ((fun n => n) n) :=
    fun _ => rfl
  have hau := au_identity hidentity
  have hnonzero : ∀ n, succ n ≠ zero :=
    successor_nonzero zero succ pred pred_zero pred_succ hau.1
  have hiter : ∀ n, iterSucc n (succ zero) = succ n := by
    intro n
    rcases hau.2 (succ n) with hz | heq
    · exact False.elim (hnonzero n hz)
    · change succ n = iterSucc (pred (succ n)) (succ zero) at heq
      rw [pred_succ n] at heq
      exact heq.symm
  refine And.intro hau.1 ?_
  intro n
  rcases hau.2 n with hz | heq
  · exact Or.inl hz
  · change n = iterSucc (pred n) (succ zero) at heq
    exact Or.inr (heq.trans (hiter (pred n)))

theorem identity_instance_zero_decision
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ x, pred (succ x) = x)
    (au_identity : OrbitInstance zero succ pred iterSucc succ (fun n => n)) :
    ∀ n, n = zero ∨ n ≠ zero := by
  have hcore := identity_instance_coverage zero succ pred iterSucc
    pred_zero pred_succ au_identity
  have hnonzero := successor_nonzero zero succ pred pred_zero pred_succ hcore.1
  intro n
  rcases hcore.2 n with hz | hs
  · exact Or.inl hz
  · apply Or.inr
    intro hz
    exact hnonzero (pred n) (hs.symm.trans hz)

end Coverage

section Uniqueness

variable {N : Type u} (zero : N) (succ pred : N → N)
variable (iter : N → N → N) (update f g : N → N)

/--
Two selected full-orbit instances imply common-trajectory uniqueness.
Their first successor values agree because their initial values agree.
This proof requires no constructor coverage, iterator equations, or
separation beyond what is included (unused here) in the two callbacks.
-/
theorem common_trajectory
    (au_f : OrbitInstance zero succ pred iter update f)
    (au_g : OrbitInstance zero succ pred iter update g)
    (f_step : ∀ n, f (succ n) = update (f n))
    (g_step : ∀ n, g (succ n) = update (g n))
    (initial : f zero = g zero) :
    ∀ n, f n = g n := by
  have hf := (au_f f_step).2
  have hg := (au_g g_step).2
  have first : f (succ zero) = g (succ zero) := by
    calc
      f (succ zero) = update (f zero) := f_step zero
      _ = update (g zero) := congrArg update initial
      _ = g (succ zero) := (g_step zero).symm
  intro n
  have at_zero : n = zero → f n = g n := by
    intro hn
    exact (congrArg f hn).trans (initial.trans (congrArg g hn).symm)
  rcases hf n with hn | hfn
  · exact at_zero hn
  rcases hg n with hn | hgn
  · exact at_zero hn
  · calc
      f n = iter (pred n) (f (succ zero)) := hfn
      _ = iter (pred n) (g (succ zero)) :=
        congrArg (fun b => iter (pred n) b) first
      _ = g n := hgn.symm

/--
Ordinary unary iteration uniqueness follows by comparing f with the
specific canonical term n ↦ iter(n,f(0)).  Exactly those two full-orbit
instances are hypotheses.  The canonical term's recurrence is a
computation equation, so its callback is usable unconditionally.
-/
theorem ordinary_uniqueness
    (iter_zero : ∀ b, iter zero b = b)
    (iter_step : ∀ n b, iter (succ n) b = update (iter n b))
    (au_f : OrbitInstance zero succ pred iter update f)
    (au_canonical : OrbitInstance zero succ pred iter update
      (fun n => iter n (f zero)))
    (f_step : ∀ n, f (succ n) = update (f n)) :
    ∀ n, f n = iter n (f zero) := by
  exact common_trajectory zero succ pred iter update f
    (fun n => iter n (f zero)) au_f au_canonical f_step
    (fun n => iter_step n (f zero)) (iter_zero (f zero)).symm

end Uniqueness

#print axioms successor_injective
#print axioms successor_nonzero
#print axioms identity_instance_coverage
#print axioms identity_instance_zero_decision
#print axioms common_trajectory
#print axioms ordinary_uniqueness

end FullOrbitKernel
