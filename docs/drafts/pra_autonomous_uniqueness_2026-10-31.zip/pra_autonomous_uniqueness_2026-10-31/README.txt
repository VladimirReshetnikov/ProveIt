PRA WITH THREE ELEMENTARY UNIQUENESS UPDATES
Research report for Vladimir Reshetnikov -- 31 October 2026

MAIN RESULT

The direct AU schema gives a common axiomatization of classical and
intuitionistic first-order PRA, using the existing binary initialized
iterator language and one numerical parameter per arithmetic instance.
Its recurrence update is unary; only successor, predecessor, and identity
are needed. Under the reviewed drafts' formula-tree convention, AU has
36 arithmetic nodes, compared with 39 for the strongest directly
comparable draft. A proved delayed-iterator alternative has 34 nodes,
with an explicitly specified iterator-description transformation.

This is theorem equivalence via explicit conservative definitions in
each chosen logic, not merely equiconsistency. It is not an absolute
shortestness claim. The computation definitions remain allowed to read
the counter and current state.

CONTENTS

pra_autonomous_uniqueness.pdf   Complete paper (18 pages at this build).
pra_autonomous_uniqueness.tex   Main LaTeX source.
sections/                      All included LaTeX source sections.
SPECIFICATION.txt              Standalone definitions of AU and DU.
formal/                        Four new Lean kernels, one inherited kernel,
                               attribution and scope statements.
artifacts/                     Executable finite-syntax and metric checker,
                               its complete JSON report and explanatory notes.
audit/                         Reproduced Lean outputs and validation results.
notes/boolean_bootstrap.txt     Inherited companion to BooleanDiagonal.lean.
SOURCES.json                   Exact repository snapshot and input hashes.
VALIDATION.txt                 What was checked, and what was not formalized.
build.sh                       Rebuild the PDF.
check.sh                       Reproduce syntax and Lean checks.
SHA256SUMS                     Hashes of the delivered files, excluding itself.

BUILD

The PDF uses standard TeX Live packages. From this directory run:
  bash build.sh

Checks need Python 3.10+ and Lean 4.19.0, with its bundled standard library.
Set PRA_LEAN to the desired Lean executable if it is not on PATH:
  PRA_LEAN=/absolute/path/to/lean bash check.sh

No external Lean packages, network downloads, or repository changes are
performed by these scripts. Lean builds are conditional proof-kernel
checks over an arbitrary carrier. The complete first-order equivalence
is proved in the manuscript, not fully mechanized in these files.

PROVENANCE

Reviewed commit: b0350fd1c96d8273ca9c3b5ce025782b748cded7
All six current docs/drafts archives were inspected. The incoming
directory inventory and README contained no further PRA item; unrelated
Busy Beaver archives were not unpacked. Git blob hashes were verified
for the six downloaded archives and incoming README.

The arithmetic preliminaries, bit storage, Boolean diagonal argument,
and triangular coding adapt the restricted-language positive-uniqueness
draft (the archive whose filename ends with ' (1).zip'). The one-instance
constructor observation appears in the full-language unary-update draft.
The seeded selector is from the selector/single-replacement drafts.
The new reductions are the stored latch using identity uniqueness, the
stationary native-equality reconstruction, the full-orbit premise, and
the delayed-iterator alternative. See the paper for exact attribution.
