#!/usr/bin/env python3
"""Verify sealed contents and run only the newly authored diagnostic scripts."""
import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
for line in (root/'MANIFEST.sha256').read_text().splitlines():
    digest,name=line.split('  ',1)
    p=root/name
    assert p.is_file(),name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
entries=json.loads((root/'sources/inventory.json').read_text())
for item in entries:
    data=(root/'sources/archives'/item['name']).read_bytes()
    assert len(data)==item['size'],item['name']
    got=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert got==item['sha'],item['name']
for script in sorted((root/'checks').glob('check_*.py')):
    result=subprocess.run([sys.executable,str(script)],check=True,capture_output=True,text=True)
    actual=json.loads(result.stdout)
    expected=json.loads(script.with_suffix('.json').read_text())
    assert actual==expected,script.name
    print(script.name+': PASS (output matches sealed expected JSON)')
print('PASS: SHA256 manifest, six pinned Git blobs, all authored checks')
