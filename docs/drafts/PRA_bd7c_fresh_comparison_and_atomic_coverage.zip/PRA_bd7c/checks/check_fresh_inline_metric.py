import json

def atom(s): return (s,)
def op(s,*xs): return (s,*xs)
def size(t): return 1+sum(size(c) for c in t[1:])
def alls(vs,t):
    for v in reversed(vs): t=op('forall '+v,t)
    return t

def ledger(k, fresh=True):
    n,a,z=map(atom,['n','a','0']); bs=[atom('b'+str(i)) for i in range(k)]
    ns=lambda x:op('S',x)
    eq=lambda x,y:op('=',x,y)
    R=lambda x,y:op('R',x,y,*bs)
    # Quantify each free variable separately in each computation axiom.
    base=alls(['a']+['b'+str(i) for i in range(k)],eq(R(z,a),a))
    step=alls(['n','a']+['b'+str(i) for i in range(k)],eq(R(ns(n),a),op('h',n,*bs,R(a,n))))
    sep=op('implies',eq(z,ns(z)),atom('false'))
    f=lambda x:op('f',x,*([] if fresh else [a]),*bs)
    K=op('C',op('D',a,f(z)),f(z),a)
    st=alls(['n'],eq(f(ns(n)),f(n)))
    conc=alls(['a','n'] if fresh else ['n'],op('or',eq(K,a),eq(ns(f(n)),a)))
    form=alls(['b'+str(i) for i in range(k)] if fresh else ['a']+['b'+str(i) for i in range(k)],op('implies',st,conc))
    return {'k':k,'fresh':fresh,'computation':size(base)+size(step),'separation':size(sep),'schema':size(form),'display':size(base)+size(step)+size(sep)+size(form),'selected_bodies':2,'subtotal':size(base)+size(step)+size(sep)+size(form)+2}
res=[ledger(k,f) for k in range(9) for f in [False,True]]
for r in res:
    k=r['k']; assert r['computation']==18+6*k
    assert r['schema']==(26 if r['fresh'] else 31)+6*k
    assert r['subtotal']==(52 if r['fresh'] else 57)+12*k


def atomic(q):
    n,z=atom('n'),atom('0'); ps=[atom('c'+str(i)) for i in range(q)]
    E=lambda x:op('=',op('s',x,*ps),op('t',x,*ps))
    return alls(['c'+str(i) for i in range(q)],op('implies',op('and',E(z),alls(['n'],op('implies',E(n),E(op('S',n))))),alls(['n'],E(n))))
x=atom('x'); z=atom('0')
cover=alls(['x'],op('or',op('=',x,z),op('exists y',op('=',x,op('S',atom('y'))))))
assert size(cover)==10
for q in range(9): assert size(atomic(q))==27+9*q
print(json.dumps({'fresh_inline':res,'atomic_I_sizes':[size(atomic(q)) for q in range(9)],'existential_cover':size(cover),'ordinary_computation_k0':18,'sep':6,'selected_bodies':0,'display_q0':18+6+10+size(atomic(0)),'display_q1':18+6+10+size(atomic(1))},indent=2))
