import json

def atom(s):return(s,)
def op(s,*xs):return(s,*xs)
def size(t):return 1+sum(size(c) for c in t[1:])
def alls(vs,t):
 for v in reversed(vs):t=op('forall '+v,t)
 return t
out=[]
for q in range(9):
 n=atom('n');ps=[atom('c'+str(i)) for i in range(q)]
 E=lambda x:op('=',op('s',x,*ps),op('t',x,*ps))
 f=alls(['c'+str(i) for i in range(q)],op('implies',alls(['n'],op('implies',E(n),E(op('S',n)))),alls(['n'],E(n))))
 assert size(f)==21+7*q
 out.append({'q':q,'schema':size(f),'subtotal_k0':size(f)+18+6+10})
zero=atom('0');n=atom('n');c=atom('c')
def sub(t):return zero if t==n else(t[0],*(sub(x) for x in t[1:]))
# Descriptor signatures known in this finite admission unit-test.
arity={'R_U':3,'R_V':3}
def admissible(t):
 b=sub(t)
 if b[0] in arity and len(b)-1==arity[b[0]] and b[1]==zero:
  return b[2]==zero
 return False
accepted=[op('R_U',n,zero,c),op('R_V',n,zero,c),op('R_U',zero,zero,c)]
rejected=[zero,op('S',zero),op('R_U',n,op('S',zero),c),op('S',op('R_U',n,zero,c)),op('R_U',op('S',n),zero,c),op('R_U',n,op('R_V',zero,zero,c),c),op('unknown',n,zero,c),op('R_U',n,zero)]
assert all(map(admissible,accepted));assert not any(map(admissible,rejected))
# Delayed induction encoding diagnostics, without asserting tests prove its logic.
checks=0
for initial in range(8):
 for coef in range(5):
  s=lambda x:initial+coef*x
  u=lambda x:0 if x==0 else s(x)
  for x in range(65):
   assert (u(x)==s(x)) if x else(u(x)==0)
   checks+=1
print(json.dumps({'status':'PASS','normalized':out,'admission_accepted':len(accepted),'admission_rejected':len(rejected),'delayed_term_checks':checks,'scope':'Exact AST metric and admission unit tests; all-model deduction is mathematical proof.'},indent=2))
