"""Finite diagnostics, not replacements for the mathematical proofs."""
import functools, json

def C(z,u,v): return u if z==0 else v
@functools.lru_cache(None)
def D(x,a): return a if x==0 else D(a,x-1)
def K(x,a): return C(D(a,x),x,a)
def E(x,y): return D(y,K(x,y+1))
counts={'inline_comparator':0,'reverse_compiler':0,'diagonal_rewrites':0,'atomic_cover':0,'mutations_rejected':0}
for x in range(129):
 for a in range(129):
  assert D(x,a)==max(a-x,0)+max(x-a-1,0)
  assert K(x,a)==a or x+1==a
  assert K(x,x+1)==x
  assert E(x,a)==int(x!=a)
  counts['inline_comparator']+=1

updates=[lambda i,v:v,lambda i,v:0,lambda i,v:i,lambda i,v:v+1,lambda i,v:(i+2*v+1)%17,lambda i,v:C(i,v,3)]
for mode in ('counter','seed'):
 for update in updates:
  def h(n,a,v): return update(n if mode=='counter' else a,v)
  @functools.lru_cache(None)
  def R(x,a): return a if x==0 else h(x-1,a,R(a,x-1))
  def compiled(x,y):
   d,e=max(x-y,0),max(y-x,0)
   v=e if d==0 else h(d-1,0,d-1)
   for j in range(min(x,y)):
    v=h(d+j,e+j+1,h(e+j,d+j,v))
   return v
  for x in range(33):
   for y in range(33):
    assert R(x,y)==compiled(x,y)
    counts['reverse_compiler']+=1
   lhs=R(x+1,x+1)
   if mode=='counter': rhs=update(x,update(x,R(x,x)))
   else: rhs=update(x+1,update(x,R(x,x)))
   assert lhs==rhs
   counts['diagonal_rewrites']+=1

def atomic_sequence(x,N):
 r=x;q=0
 vals=[]
 for n in range(N+1):
  # q is computed from its own recursion, not min(n,x).
  e=C(x,1,0) if n==0 else C(r,C(previous_r,0,1),0)
  assert q+r==x
  assert C(r,0,q)==C(r,0,n)
  assert e in (0,1)
  assert (e==1)==(n==x)
  vals.append((n,x,r,q,e))
  previous_r=r
  q=C(r,q,q+1)
  r=max(r-1,0)
 return vals
for x in range(257):
 vals=atomic_sequence(x,256)
 counts['atomic_cover']+=len(vals)
# Two deliberate errors are genuinely rejected by the required properties.
try:
 assert C(0,0,1)==1 # flipped zero branch in equality bit at0
except AssertionError: counts['mutations_rejected']+=1
try:
 x=3;q=0;r=x
 q=q # incorrect no-increment q successor
 r=max(r-1,0)
 assert q+r==x
except AssertionError: counts['mutations_rejected']+=1
assert counts['mutations_rejected']==2
print(json.dumps({'status':'PASS','counts':counts,'scope':'Finite diagnostics; mathematical proofs establish all-natural/internal claims.'},indent=2))
