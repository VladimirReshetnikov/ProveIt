# Source review at bd7c1189f8

Pinned full commit: bd7c1189f8d75f1cf738c156d8c376158de16460. Current docs/drafts inventory matched this commit at retrieval. Six current archives; fourteen changed paths comprise eight removals and six additions, not fourteen new constructions. Every ZIP was downloaded read-only, safely extracted, and verified against its Git blob SHA-1. No imported scripts were executed. Exact metadata/hashes: sources/commit.json, inventory.json, current_inventory.json, source_hashes.json.

## Current baselines
- pra_fresh_probe and pra_compact_bases independently converge on fresh-probe stationarity: the probe a is absent from f. Display46 plus selected helper8 gives54 at representative parameter count. Counter-free version45+11=56. Its dependency-normalization saving is template-level: recovering a particular old dependent instance may need an extra frozen parameter.
- pra_initialized_induction: ordinary initialized recursion, separation and full QFI give43 with formula-placeholder convention. Induction restricted to disjunctions of two equations suffices constructively but expands to94 under literal term display. Atomic induction alone is refuted by N×N; automorphism argument rules out parameter-free biinterpretation with PRA. These are different schematic classes, not directly comparable with term-only54.
- pra_one_index_and_binary and pra_successor_comparison give counter-only initialized swap grammar and inlined successor-comparison schema, display55+selected2=57. The index-only interface saves one grammar argument. They contain full constructive bootstrap, ordinary-recursion translation and reverse compiler.
- PRA_counterfree_9node_commit_review is the preceding delivered report: counterfree60, earlier best58. Its comparison is superseded by54/56 now.

## Proof spot checks
Fresh-probe equivalence is by promoting old probe dependence to a new frozen parameter c and specializing independent a to c; constructive quantifier rules suffice. Fresh report forward proof obtains D diagonals by stationary0/1, then a finite equality bit without constructor coverage. Initialized-induction report correctly uses two disjunctive inductions (Cover and Compare), with equation-only algebra and final error-term induction; it does not silently use disequality induction. Product countermodel proof separates coordinates using the base point and admits a coordinate-swap automorphism.

## Synthesis lead not in current counts
Combine fresh-probe restriction with the inlined one-index successor-comparison schema. Its five f occurrences each lose the compulsory probe argument, suggesting display50 + selected2 =52, below54 at the shared representative parameter convention. The old inline reports allow unused a but do not restrict the generating subschema or claim this count. Need new exact AST count and explicit renaming proof. This is a combination of supplied principles, not a new comparator or new proof-theoretic phenomenon.
