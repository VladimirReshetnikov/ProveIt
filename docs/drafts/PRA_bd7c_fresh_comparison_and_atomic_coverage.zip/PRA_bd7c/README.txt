PRA: fresh inline comparison and atomic induction plus coverage
Pinned source: VladimirReshetnikov/ProveIt bd7c1189f8d75f1cf738c156d8c376158de16460

Read report.pdf; report.tex is its editable source.
Two new combinations are proved with matching classical/intuitionistic
bi-interpretations and identity round trips:
(1) Fresh-inline term schema: 52+12k, versus supplied54+11k.
    Low-parameter improvement only, not uniform dominance or global minimality.
(2) Ordinary initialized recursion + equation induction + fixed existential
    coverage gives full QFI. At matched k0,q1 expanded cost70 versus94.
    Optional exact-root syntactic-base normalization reduces this to62.
    Different schema interface, not an improvement over52.

REPLAY: python3 replay.py
Runs only this report's own Python checks, verifies file hashes and pinned
Git blob identities. Never executes code contained in inherited archives.
BOUNDED TESTS ARE NOT PROOF-ASSISTANT CERTIFICATES.

BUILD: sh build.sh (standard TeX Live with pdflatex, lmodern, microtype,
amsmath, amssymb, amsthm, booktabs, longtable, hyperref, geometry).
PDF timestamps and TeX versions may change PDF bytes. The included PDF
is the visually inspected delivery build, not a byte-reproducibility claim.

sources/archives contains all six exact archives from the pinned commit,
for inspectable provenance. They may contain prior verification scripts and
certificates; these remain inherited material, not fresh execution claims.
sources/inline_core.tex and reverse_compiler.tex are credited proof sources.
proofs/ contains research working proofs supporting the final report.
See report section 'Verification and proof boundaries' for claim scope.
