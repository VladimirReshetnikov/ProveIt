# Atomic induction plus a fixed coverage sentence suffices

## Theory
Ordinary initialized recursion R_h(0,a,b)=a and R_h(Sn,a,b)=h(n,b,R_h(n,a,b)), all earlier finite h and finite frozen tuples; 0 != S0; atomic induction for every equality s(n,c)=t(n,c), under arbitrary fixed assumptions; and single axiom ∀x (x=0 or x=S p(x)), where p(x)=R_{h=n}(x,0).
Predecessor p0=0,p(Sn)=n; S injectivity and successor nonzeroness follow by finite rewrites and separation. Selector C(0,u,v)=u,C(Sn,u,v)=v is ordinary initialized recursion with constant frozen update v; positive coverage makes C globally a zero-selector. Ordinary recursion with arbitrary initial G is compiled simply R_h(n,G(b),b), so no initialization gap.

## Elementary equations
Define addition x+0=x,x+Sn=S(x+n), and d(x,0)=x,d(x,Sn)=p(d(x,n)). Atomic induction proves 0+n=n, Sx+n=S(x+n), d(0,n)=0, d(Sx,Sn)=d(x,n), d(x+c,x)=c. These are exactly the atomic derivations in supplied initialized_induction report. In particular d(x,x)=0,d(Sx,x)=1. Sum with1 is successor.

## Saturation counter
Define q(0,x)=0 and q(Sn,x)=C(d(x,n),q(n,x),S q(n,x)). (Admitted ordinary recursion, x frozen.) Write r_n=d(x,n). Thus r_{Sn}=p(r_n).

Atomic induction on the equation q(n,x)+r_n=x proves it for every n. Base0+x=x. In successor step eliminate coverage of r_n. If r_n=0, then q_next=q and r_next=0, so preserve the equation. If r_n=S u, then q_next=S q, r_next=u, and S q+u=S(q+u)=q+S u=q+r_n=x.

A SECOND atomic induction proves the single equation
 C(r_n,0,q(n,x)) = C(r_n,0,n).
Base both sides0. At successor, split coverage of r_next. If r_next=0 both sides0. If r_next!=0 then r_n!=0 since p0=0; coverage makes r_n successor and IH implies q(n,x)=n. Hence q_next=S q=Sn, giving required equality. Every case split is furnished by the fixed coverage axiom; neither induction matrix contains a connective. Consequently r_n !=0 implies q(n,x)=n.

## Native equality bit
Define by ordinary recursion
 e(0,x)=C(x,1,0),
 e(Sn,x)=C(d(x,Sn), C(d(x,n),0,1),0).
The arbitrary initial value is admitted by the simple compiler above. Coverage of each selector argument proves e(n,x)=0 or e(n,x)=1 without induction.

Diagonal: at n=x=0, e=1. For x=Sk, d(Sk,Sk)=0 and d(Sk,k)=1, whence e(Sk,Sk)=1. Coverage of x proves e(x,x)=1 for all x. Hence n=x implies e(n,x)=1.

Reflection: suppose e(n,x)=1. Coverage of n gives n=0 or n=Sk. At zero, C(x,1,0)=1 implies x=0, using coverage and separation. At n=Sk, nested selectors force r_{Sk}=0 and r_k!=0. Coverage yields r_k=Su and p(r_k)=u=0, so r_k=1. The second q invariant yields q(k,x)=k; the first yields x=q+r_k=k+1=Sk=n. Thus e(n,x)=1 iff n=x; Boolean range then gives e(n,x)=0 iff n!=x. All reasoning is intuitionistically valid.

## QFI and biinterpretation
Build the ordinary Boolean circuits for all quantifier-free formulas using e and C. A formula A is constructively equivalent to its bit being1, and its negation to bit0. Under any fixed assumptions containing base and successor step for A, apply atomic induction to the bit equation =1; recover A for all n. Thus full QFI in the entire generated language follows. The converse interpretation into PRA is immediate because Cover is a QFI instance and atomic induction is included. Ordinary initialized-recursion compiler and uniqueness by atomic induction give full-carrier identity roundtrips exactly as in supplied report. Thus this is an unconditional same-language conservative definitional presentation of matching PRA, not only equiconsistency.

## What is new and scope
This replaces the two-equation induction report's variable two-disjunct schema by atomic induction plus one fixed positive coverage sentence. Product countermodel for atomic induction alone violates coverage. No minimum or strongest-ledger improvement follows without counting; this is a structural narrowing of induction syntax at the price of one axiom.
