# Fresh-inline one-index presentation

## Exact specification
Choose either counter-only or seed-only initialized swap descriptions, with finite dependency ordered update h(i,b,v):
R_h(0,a,b)=a,
R_h(Sn,a,b)=h(n,b,R_h(a,n,b)) [counter-only]
or h(a,b,R_h(a,n,b)) [seed-only].
Select C with update b and D with update v. Add 0 != S0. For every finite term f(n,b), with comparison variable a absent from f, add
∀b ([∀n f(Sn,b)=f(n,b)] → ∀a∀n [C(D(a,f(0,b)),f(0,b),a)=a ∨ S f(n,b)=a]).
No other assumptions. All finite frozen tuples b allowed.

## Exact schema equivalence (constructive)
Let IP be the existing inline schema permitting f(n,a,b), and FIP the displayed fresh schema. IP implies FIP because it allows terms ignoring a. Conversely fix a dependent term g(n,c,b). The FIP instance with frozen tuple (c,b) and fresh comparison variable y has conclusion universally quantified over y,n. Specialize y=c; the result is exactly the IP instance for g(n,c,b). Generalize c and rename to a. This purely logical argument holds under all fixed assumptions and in intuitionistic logic; no induction, arithmetic, model semantics, or computational adequacy hypothesis enters. There is no change of language or computation equations. Consequently IP and FIP have literally the same deductive closure in each matching logic. Every compiler and definable identity roundtrip supplied for IP therefore transfers verbatim. The proof does not claim that the expanded instance g becomes shorter: recovery may add a frozen parameter.

## Metric
In the inherited fully expanded formula-tree ledger with k frozen parameters (b length k), the one-index defining-equation display costs18+6k; separation costs6. FIP costs26+6k. Hence display50+12k and selected C,D bodies2 give52+12k.
At k=0 old inline57 becomes52. Relative fresh-probe comparison has subtotal54+11k. Thus new FIP is2 nodes smaller at k0,1 smaller at k1, tied at k2, and larger for k>=3. This is not uniform pointwise dominance of all parameter arities, nor an axiom-enumerator code-length result. Both are template/selected-body partial ledgers. Old inline counts5 forced occurrences of its probe in applications of f:2 in stationarity,2 in inline K,1 in observation; removal saves exactly5.

## Attribution
Both ingredients occur in bd7c1189f8: one-index inline IP in pra_one_index_and_binary, and dependency normalization in pra_fresh_probe. Their new combination is the claimed contribution, not either ingredient alone.
