Independent tests for explicit elimination fields
================================================

These files are untrusted certificate-generation and validation tools.
The measured proof checkers import none of them.

convert.py expands old [major,payload] instructions into [major,source,
target,motive] instructions. It preserves the goal, instruction order,
and automatic hypothesis-closing schedule. Malformed old instructions
become malformed new instructions; unread prefixes remain irrelevant.

--erase is deliberately partial. It supports canonical numeric-zero
sources at unary closures, but refuses a falsy nonnumeric source such as
[]: these are valid raw zero aliases in the new calculus, yet their minor
proofs may need a native proof conversion rather than literal packet
field deletion. Canonical forward conversion always uses source 0.

replay.py compares the original two-field checker, optional equally
cleaned-up two-field controls, and the supplied four-field checkers. It
checks verdicts, final freshness floors, and consumed packet positions on
accepted runs. It then invokes the actual complete programs in ordinary
Python and Python -O and checks stdout and exit status.

focused.py constructs 16 independent cases. Seven guard-removal probes
check equality endpoints, the closure source/body, major proofs, goal
scope, and image scope. Five probes become proofs of an explicit false
numerical equation when the named guard is removed. The two scope probes
instead expose forbidden free/future labels. Correct kernels reject all
seven. Additional cases cover malformed computation and inert fields.
The focused script also checks both public interfaces and malformed JSON.

inherited_cases.json is reproduced from
ipra_three_schema_2026-11-09(1).zip,
ipra_three_schema_2026-11-09/compact_controls/cases.json
in the inspected ProveIt corpus. Its 168 cases comprise 157 positive and
11 negative cases. Keep the containing report's source attribution.

All results are finite executable evidence. They do not establish general
soundness, completeness, the arithmetic compiler, or bi-interpretability.
Those require the accompanying mathematical arguments.

Replay command schema:
  python3 replay.py --baseline BASELINE.py
    --candidate fall FALL.py --candidate join JOIN.py
    --legacy-control matched_legacy LEGACY.py
    --legacy-control matched_legacy_structure LEGACY_STRUCTURE.py
    --mutation-rounds 4 --cases inherited_cases.json
    --output final_replay_results.json

Focused command schema:
  python3 focused.py --candidate FALL.py --candidate JOIN.py
    --output focused_results.json
