EXPLICIT ENDPOINTS: A SMALLER COMPLETE CHECKER FOR iPRA
====================================================
Prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific date).

Main result
-----------
At ProveIt commit 7e694b036f89a0f16313089329555da531d6a656, the eleven
current draft archives have complete-checker coordinate minima
292 normalized Python tokens / 330 AST nodes / 762 normalized bytes.

code/compact.py measures 287 / 328 / 749, strictly below all three old
coordinates in one complete standalone program. code/explicit_failure.py
measures 289 / 330 / 739 and explicitly rejects wrong computations.

The mathematical calculus is inherited Choice-DI, with scalar iteration.
Its ordinary realization is whole-domain bi-interpretable and
equiconsistent with full first-order intuitionistic PRA. The report
states every native axiom and rule and includes the inherited bridge.

This is a modest implementation improvement, not the requested significant
new mathematical axiomatization, not an absolute minimality theorem, and
not a Lean/Rocq formalization. The extra stopped-index research appendix
does not resolve the countdown theory's equality-reflection gap.

New idea
--------
Old proof packets contain [major,payload]. New packets contain
[major,source,target,template]. The checker proves the major and checks
that it is either equality [source,target] or unary closure [template]
with zero source. It then checks the same substitution instances in
both cases. All redundant certificate fields are checked, not trusted.

The compact checker also uses successful completion versus exceptions.
After a failed computation, a guaranteed unbound local h forces rejection.
This unusual but reviewed invariant is explained in report.pdf.
code/readable.py supplies explicit descriptive errors instead.

Use
---
  python3 code/compact.py < examples/computation.json
  python3 code/compact.py < certificate.json
  python3 tests/convert.py < old_certificate.json > new_certificate.json
  python3 reproduce.py
  python3 build.py

Use tests/convert.py --erase for the partial reverse adapter on canonical
zero-source closure packets; see its source docstring for the boundary.
The checkers use only Python's standard json module and accept finite
JSON arrays. The last cell is the closed goal; earlier instructions are
consumed from the end. Unread prefixes are inert. ACCEPT with status 0
means success; REJECT with a nonzero status means failure. Real resource
limits can reject a deep valid proof. Tests also run Python with -O.

Contents
--------
report.tex, report.pdf       Full research report and mathematical proofs
appendices/                 Attributed inherited bridge + new research note
code/                       New compact, explicit-failure, readable checkers
reference/                  Exact old leaders, matched controls, normalizer
tests/                      Untrusted converters, fixtures, guard tests
examples/computation.json   A complete proof of I(0,0;v.0)=0
evidence/                   Snapshot, hashes, measurements, replay results
reviews/                    Independent assistant review records
reproduce.py                Offline deterministic reproduction
build.py                    pdfLaTeX build with shell escape disabled
MANIFEST.sha256.json         Hashes of the delivered payload
LICENSE-inherited.txt       ProveIt's MIT No Attribution license

Reproduction needs Python 3.12 for exact normalized source measurements.
The recorded runtime is CPython 3.12.14. PDF compilation needs pdfLaTeX
and the ordinary packages listed in report.tex. Neither testing nor PDF
generation is part of the proof checker's trusted implementation.

Source provenance
-----------------
All source archives were downloaded from the pinned public repository
and checked against their Git blob identities. Their complete inventory
is in evidence/repository_snapshot.json; copied members have explicit
provenance and SHA-256 hashes. No repository changes were made.
This package includes the complete necessary local source and fixtures;
the original source ZIPs are not duplicated.
