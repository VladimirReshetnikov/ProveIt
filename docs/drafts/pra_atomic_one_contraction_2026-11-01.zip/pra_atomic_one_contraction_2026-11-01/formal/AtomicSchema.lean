import NormalizedSchema

/-
One-contraction atomic admission for PRA's logical kernel.

The grammar has finite terms with named binary recursors, native equality,
and finite quantifier-free formulas. A candidate is an implication between
single equality atoms or bottom. After zero substitution, its branches must
coincide, or ONE contraction in ONE branch must make them coincide.

The exact seed contraction is R_k(0,a) -> a, with a the sole seed variable;
it is not the stronger R_k(0,t) -> t rule for arbitrary t. It may occur in
one term context. The other contraction replaces the WHOLE atom 0=S0 by
bottom. The inductive relations below count exactly one contraction.

Checked here: finite admission witnesses, containment in the earlier full
normalization gate, recovery of initialization, successor computation,
separation, equation induction, and negative constructor coverage. A single
additional concrete instance gives positive coverage intuitionistically.

Scope: Model abstracts the external well-founded generation of recursor
indices and their stored update bodies. This file does not formalize the
arithmetic equality-bit bootstrap, pairing, full compiler, or complete
bi-interpretability theorem. No theorem assumes induction for arbitrary
semantic predicates in place of the finite syntactic induction schema.
-/

namespace AtomicSchema

open DiagonalSchema

inductive Atomic {V : Type} : Formula V → Prop where
  | eq (s t : Term V) : Atomic (.eq s t)
  | bot : Atomic .bot

inductive TermContract (k : Nat) : Term Unit → Term Unit → Prop where
  | root : TermContract k (.app k .zero (.var ())) (.var ())
  | succ {s t} : TermContract k s t →
      TermContract k (.succ s) (.succ t)
  | appLeft {s t} (i : Nat) (u : Term Unit) : TermContract k s t →
      TermContract k (.app i s u) (.app i t u)
  | appRight {s t} (i : Nat) (u : Term Unit) : TermContract k s t →
      TermContract k (.app i u s) (.app i u t)

inductive AtomContract (k : Nat) : Formula Unit → Formula Unit → Prop where
  | eqLeft {s t} (u : Term Unit) : TermContract k s t →
      AtomContract k (.eq s u) (.eq t u)
  | eqRight {s t} (u : Term Unit) : TermContract k s t →
      AtomContract k (.eq u s) (.eq u t)
  | falseAtom : AtomContract k guard .bot

def Gate (k : Nat) (A B : Formula Unit) : Prop :=
  A = B ∨ AtomContract k A B ∨ AtomContract k B A

def Admitted (k : Nat) (F : Formula Two) : Prop :=
  ∃ A B : Formula Two,
    F = .imp A B ∧ Atomic A ∧ Atomic B ∧
    Gate k (A.subst zeroSub) (B.subst zeroSub)

/- Every single contraction has the same full normal form on both sides. -/
theorem termContract_norm (k : Nat) {s t : Term Unit}
    (hc : TermContract k s t) :
    NormalizedSchema.normTerm k s = NormalizedSchema.normTerm k t := by
  induction hc with
  | root => simp [NormalizedSchema.normTerm, NormalizedSchema.reduceApp]
  | succ hc ih => simp only [NormalizedSchema.normTerm, ih]
  | appLeft i u hc ih => simp only [NormalizedSchema.normTerm, ih]
  | appRight i u hc ih => simp only [NormalizedSchema.normTerm, ih]

theorem atomContract_norm (k : Nat) {A B : Formula Unit}
    (hc : AtomContract k A B) :
    NormalizedSchema.normFormula k A = NormalizedSchema.normFormula k B := by
  cases hc with
  | eqLeft u ht =>
    simp only [NormalizedSchema.normFormula, termContract_norm k ht]
  | eqRight u ht =>
    simp only [NormalizedSchema.normFormula, termContract_norm k ht]
  | falseAtom => rfl

theorem gate_norm (k : Nat) {A B : Formula Unit} (hg : Gate k A B) :
    NormalizedSchema.normFormula k A = NormalizedSchema.normFormula k B := by
  rcases hg with heq | hc | hc
  · exact congrArg (NormalizedSchema.normFormula k) heq
  · exact atomContract_norm k hc
  · exact (atomContract_norm k hc).symm

theorem admitted_normalized (k : Nat) (F : Formula Two)
    (ha : Admitted k F) : NormalizedSchema.Admitted k F := by
  rcases ha with ⟨A, B, rfl, _, _, hg⟩
  refine ⟨NormalizedSchema.normFormula k (A.subst zeroSub), ?_⟩
  simp only [Formula.subst, NormalizedSchema.normFormula]
  rw [← gate_norm k hg]

def Instance {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (F : Formula Two) : Prop :=
  ∀ a : D,
    (∀ n, F.eval M (envTwo n a) → F.eval M (envTwo (M.succ n) a)) →
    ∀ n, F.eval M (envTwo n a) ∧
      M.app k (M.succ n) a = h.eval M (envTwo n (M.app k n a))

def Schema {D : Type} (M : Model D) (k : Nat) (h : Term Two) : Prop :=
  ∀ F : Formula Two, Admitted k F → Instance M k h F

theorem normalized_schema_atomic {D : Type} (M : Model D) (k : Nat)
    (h : Term Two) (HN : NormalizedSchema.Schema M k h) : Schema M k h := by
  intro F hf
  exact HN F (admitted_normalized k F hf)

theorem base_induction_schema {D : Type} (M : Model D) (k : Nat)
    (h : Term Two) (hb : Base M k) (hs : Step M k h)
    (he : Separation M) (hi : QFInduction M) : Schema M k h := by
  exact normalized_schema_atomic M k h
    (NormalizedSchema.base_induction_schema M k h hb hs he hi)

def truthProbe : Formula Two := .imp .bot .bot

theorem truthProbe_admitted (k : Nat) : Admitted k truthProbe :=
  ⟨.bot, .bot, rfl, .bot, .bot, Or.inl rfl⟩

def separationProbe : Formula Two := .imp guard .bot

theorem separationProbe_admitted (k : Nat) : Admitted k separationProbe :=
  ⟨guard, .bot, rfl, .eq _ _, .bot, Or.inr (Or.inl .falseAtom)⟩

def initProbe (k : Nat) : Formula Two :=
  .imp (.eq (.var .seed) (.var .seed))
    (.eq (.app k .zero (.var .seed)) (.var .seed))

theorem initProbe_admitted (k : Nat) : Admitted k (initProbe k) :=
  ⟨.eq (.var .seed) (.var .seed),
    .eq (.app k .zero (.var .seed)) (.var .seed),
    rfl, .eq _ _, .eq _ _, Or.inr (Or.inr (.eqLeft (.var ()) .root))⟩

theorem schema_step {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Step M k h := by
  intro n a
  exact (H truthProbe (truthProbe_admitted k) a
    (by intro n hn; exact hn) n).2

theorem schema_separation {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Separation M := by
  exact (H separationProbe (separationProbe_admitted k) M.zero
    (by intro n hn; exact hn) M.zero).1

theorem schema_base {D : Type} (M : Model D) (k : Nat) (h : Term Two)
    (H : Schema M k h) : Base M k := by
  intro a
  have hinit := (H (initProbe k) (initProbe_admitted k) a
    (by intro n hn; exact hn) M.zero).1
  exact hinit rfl

theorem zero_freeze (F : Formula Two) :
    (F.subst NormalizedSchema.freezeCounter).subst zeroSub =
      F.subst zeroSub := by
  have hcomp :
      (fun v => (NormalizedSchema.freezeCounter v).subst zeroSub) = zeroSub := by
    funext v
    cases v <;> rfl
  simp only [Formula.subst_subst, hcomp]

def equationProbe (s t : Term Two) : Formula Two :=
  NormalizedSchema.inductionProbe (.eq s t)

theorem equationProbe_admitted (k : Nat) (s t : Term Two) :
    Admitted k (equationProbe s t) := by
  refine ⟨(Formula.eq s t).subst NormalizedSchema.freezeCounter, .eq s t,
    rfl, .eq _ _, .eq _ _, Or.inl ?_⟩
  exact zero_freeze (.eq s t)

def EqInduction {D : Type} (M : Model D) : Prop :=
  ∀ s t : Term Two, ∀ a : D,
    s.eval M (envTwo M.zero a) = t.eval M (envTwo M.zero a) →
    (∀ n, s.eval M (envTwo n a) = t.eval M (envTwo n a) →
      s.eval M (envTwo (M.succ n) a) = t.eval M (envTwo (M.succ n) a)) →
    ∀ n, s.eval M (envTwo n a) = t.eval M (envTwo n a)

theorem schema_eqInduction {D : Type} (M : Model D) (k : Nat)
    (h : Term Two) (H : Schema M k h) : EqInduction M := by
  intro s t a hz hs n
  let E : Formula Two := .eq s t
  have prog : ∀ m, (equationProbe s t).eval M (envTwo m a) →
      (equationProbe s t).eval M (envTwo (M.succ m) a) := by
    intro m hm
    apply (NormalizedSchema.eval_inductionProbe M E (M.succ m) a).2
    intro hb
    exact hs m ((NormalizedSchema.eval_inductionProbe M E m a).1 hm hb)
  have hp := (H (equationProbe s t) (equationProbe_admitted k s t) a prog n).1
  exact (NormalizedSchema.eval_inductionProbe M E n a).1 hp hz

def negativeCoverageProbe : Formula Two :=
  .imp (.eq (.var .counter) (.var .seed)) (.eq .zero (.var .seed))

theorem negativeCoverageProbe_admitted (k : Nat) :
    Admitted k negativeCoverageProbe :=
  ⟨.eq (.var .counter) (.var .seed), .eq .zero (.var .seed),
    rfl, .eq _ _, .eq _ _, Or.inl rfl⟩

theorem schema_negativeCoverage {D : Type} (M : Model D) (k : Nat)
    (h : Term Two) (H : Schema M k h) (p : D → D)
    (hp : ∀ n, p (M.succ n) = n) :
    ∀ a, (a = M.succ (p a) → False) → a = M.zero := by
  intro a hn
  have prog : ∀ n, negativeCoverageProbe.eval M (envTwo n a) →
      negativeCoverageProbe.eval M (envTwo (M.succ n) a) := by
    intro n _ heq
    have hpa : p a = n := (congrArg p heq).symm.trans (hp n)
    exact False.elim (hn (heq.symm.trans (congrArg M.succ hpa.symm)))
  have hfinal := (H negativeCoverageProbe (negativeCoverageProbe_admitted k)
    a prog a).1
  exact (hfinal rfl).symm

/- Index 0 is the designated predecessor recursor, with update h(u,v)=u. -/
def predTerm (t : Term Two) : Term Two := .app 0 t .zero

def predecessor {D : Type} (M : Model D) (n : D) : D := M.app 0 n M.zero

def Coverage {D : Type} (M : Model D) : Prop :=
  ∀ n, n = M.zero ∨ n = M.succ (predecessor M n)

theorem predecessor_step {D : Type} (M : Model D)
    (H : Schema M 0 (.var .counter)) :
    ∀ n, predecessor M (M.succ n) = n := by
  intro n
  exact schema_step M 0 (.var .counter) H n M.zero

theorem schema_coverage_of_excludedMiddle {D : Type} (M : Model D)
    (H : Schema M 0 (.var .counter))
    (em : ∀ P : Prop, P ∨ (P → False)) : Coverage M := by
  intro a
  rcases em (a = M.succ (predecessor M a)) with ha | hn
  · exact Or.inr ha
  · exact Or.inl (schema_negativeCoverage M 0 (.var .counter) H
      (predecessor M) (predecessor_step M H) a hn)

def coverageFormula : Formula Two :=
  .disj (.eq (.var .counter) .zero)
    (.eq (.var .counter) (.succ (predTerm (.var .counter))))

def coverageProbe : Formula Two :=
  NormalizedSchema.inductionProbe coverageFormula

def CoverageInstance {D : Type} (M : Model D) : Prop :=
  Instance M 0 (.var .counter) coverageProbe

theorem coverageProbe_normalized : NormalizedSchema.Admitted 0 coverageProbe :=
  NormalizedSchema.inductionProbe_admitted 0 coverageFormula

theorem coverageInstance_of_base_induction {D : Type} (M : Model D)
    (hb : Base M 0) (hs : Step M 0 (.var .counter))
    (he : Separation M) (hi : QFInduction M) : CoverageInstance M := by
  exact NormalizedSchema.base_induction_schema M 0 (.var .counter)
    hb hs he hi coverageProbe coverageProbe_normalized

theorem coverageInstance_positiveCoverage {D : Type} (M : Model D)
    (H : Schema M 0 (.var .counter)) (HC : CoverageInstance M) : Coverage M := by
  have hp := predecessor_step M H
  have hbase : coverageFormula.eval M (envTwo M.zero M.zero) := Or.inl rfl
  have prog : ∀ n, coverageProbe.eval M (envTwo n M.zero) →
      coverageProbe.eval M (envTwo (M.succ n) M.zero) := by
    intro n _
    apply (NormalizedSchema.eval_inductionProbe M coverageFormula
      (M.succ n) M.zero).2
    intro _
    apply Or.inr
    exact congrArg M.succ (hp n).symm
  intro n
  have hf := (HC M.zero prog n).1
  exact (NormalizedSchema.eval_inductionProbe M coverageFormula n M.zero).1 hf hbase

theorem extracted_kernel {D : Type} (M : Model D) (k : Nat)
    (h : Term Two) (H : Schema M k h) :
    Base M k ∧ Step M k h ∧ Separation M ∧ EqInduction M := by
  exact ⟨schema_base M k h H, schema_step M k h H,
    schema_separation M k h H, schema_eqInduction M k h H⟩

#print axioms admitted_normalized
#print axioms base_induction_schema
#print axioms extracted_kernel
#print axioms schema_negativeCoverage
#print axioms schema_coverage_of_excludedMiddle
#print axioms coverageInstance_positiveCoverage

end AtomicSchema
