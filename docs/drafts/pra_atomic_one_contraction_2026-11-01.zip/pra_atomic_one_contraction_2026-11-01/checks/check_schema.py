#!/usr/bin/env python3
"""Executable admission specification and finite diagnostics.

These checks are not a proof of PRA equivalence. See report.tex for the
infinite theory, its internal arithmetic proofs, and the interpretations.
Only the standard Python library is required.
"""
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path


def var(name):
    return ("var", name)


ZERO = ("zero",)
BOT = ("bot",)
N = var("n")
A = var("a")


def succ(t):
    return ("succ", t)


def rec(h, n, a):
    return ("rec", h, n, a)


def eq(s, t):
    return ("eq", s, t)


def imp(p, q):
    return ("imp", p, q)


def disj(p, q):
    return ("or", p, q)


ONE = succ(ZERO)
DELTA = eq(ZERO, ONE)


def subst(t, name, replacement):
    tag = t[0]
    if tag == "var":
        return replacement if t[1] == name else t
    if tag in {"zero", "bot"}:
        return t
    if tag == "succ":
        return succ(subst(t[1], name, replacement))
    if tag == "rec":
        # The stored update index is not subject to substitution.
        return rec(t[1], subst(t[2], name, replacement),
                   subst(t[3], name, replacement))
    return (tag, *(subst(x, name, replacement) for x in t[1:]))


def free_vars(t):
    if t[0] == "var":
        return {t[1]}
    if t[0] in {"zero", "bot"}:
        return set()
    children = t[2:] if t[0] == "rec" else t[1:]
    return set().union(*(free_vars(x) for x in children))


def term_contractions(t, h):
    """All results of exactly ONE R_h(0,a) -> a contraction."""
    out = set()
    if t == rec(h, ZERO, A):
        out.add(A)
    if t[0] == "succ":
        out.update(succ(u) for u in term_contractions(t[1], h))
    if t[0] == "rec":
        out.update(rec(t[1], u, t[3]) for u in term_contractions(t[2], h))
        out.update(rec(t[1], t[2], u) for u in term_contractions(t[3], h))
    return out


def atom_contractions(p, h):
    """All results of exactly ONE permitted contraction in an atom."""
    if p[0] != "eq":
        return set()
    out = {BOT} if p == DELTA else set()
    out.update(eq(t, p[2]) for t in term_contractions(p[1], h))
    out.update(eq(p[1], t) for t in term_contractions(p[2], h))
    return out


def is_atom(p):
    return p[0] in {"eq", "bot"}


def coverage(n):
    # Description 0 is fixed to the earlier update h(u,v)=u.
    return disj(eq(n, ZERO), eq(n, succ(rec(0, n, ZERO))))


COVERAGE_PROBE = imp(coverage(ZERO), coverage(N))


def admission_witness(f, h, intuitionistic=False):
    """Return a finite witness, or None; there is no proof-search oracle."""
    if not free_vars(f) <= {"n", "a"}:
        return None
    if intuitionistic and h == 0 and f == COVERAGE_PROBE:
        return {"kind": "fixed_coverage"}
    if f[0] != "imp" or not is_atom(f[1]) or not is_atom(f[2]):
        return None
    left = subst(f[1], "n", ZERO)
    right = subst(f[2], "n", ZERO)
    if left == right:
        return {"kind": "literal", "common_atom": left}
    if right in atom_contractions(left, h):
        return {"kind": "contract_left", "common_atom": right}
    if left in atom_contractions(right, h):
        return {"kind": "contract_right", "common_atom": left}
    return None


def full_norm(t, h):
    """The earlier draft's bottom-up normalizer, for comparison only."""
    tag = t[0]
    if tag in {"var", "zero", "bot"}:
        return t
    if tag == "succ":
        return succ(full_norm(t[1], h))
    if tag == "rec":
        x, y = full_norm(t[2], h), full_norm(t[3], h)
        return y if t[1] == h and x == ZERO else rec(t[1], x, y)
    if tag == "eq":
        result = eq(full_norm(t[1], h), full_norm(t[2], h))
        return BOT if result == DELTA else result
    return (tag, *(full_norm(x, h) for x in t[1:]))


def full_n_admits(f, h):
    f0 = full_norm(subst(f, "n", ZERO), h)
    return f0[0] == "imp" and f0[1] == f0[2]


def display_nodes():
    # Every variable/constant/application/equality/connective/quantifier costs 1.
    # F and h are schematic applications; their bodies are not expanded.
    atom = lambda name, *args: (name, *args)
    n, a = ("n",), ("a",)
    sn = atom("S", n)
    fn, fsn = atom("F", n, a), atom("F", sn, a)
    rs = atom("=", atom("R", sn, a), atom("h", n, atom("R", n, a)))
    step = atom("forall_n", atom("implies", fn, fsn))
    conclusion = atom("forall_n", atom("and", fn, rs))
    whole = atom("forall_a", atom("implies", step, conclusion))
    size = lambda x: 1 + sum(size(y) for y in x[1:])
    return {"step": size(step), "conclusion": size(conclusion),
            "outer": size(whole), "formula_occurrences": 3,
            "individual_variable_names": 2}


def run_checks():
    checks = []

    def check(name, value):
        if not value:
            raise AssertionError(name)
        checks.append(name)

    for h in (0, 1, 5):
        probes = {
            "step": imp(eq(ZERO, ZERO), eq(ZERO, ZERO)),
            "initialization": imp(eq(A, A), eq(rec(h, ZERO, A), A)),
            "separation": imp(DELTA, BOT),
            "negative_coverage": imp(eq(N, A), eq(ZERO, A)),
        }
        for name, f in probes.items():
            w = admission_witness(f, h)
            check(f"probe_{name}_h{h}", w is not None)
            check(f"probe_in_full_N_{name}_h{h}", full_n_admits(f, h))
        check(f"initialization_uses_one_h{h}",
              admission_witness(probes["initialization"], h)["kind"]
              == "contract_right")

    check("coverage_int_admitted_at_designated_index",
          admission_witness(COVERAGE_PROBE, 0, True) is not None)
    check("coverage_not_classically_generated",
          admission_witness(COVERAGE_PROBE, 0) is None)
    check("coverage_not_generated_at_other_index",
          admission_witness(COVERAGE_PROBE, 1, True) is None)
    check("coverage_is_full_N_instance", full_n_admits(COVERAGE_PROBE, 0))
    twice = imp(eq(A, A), eq(rec(0, ZERO, A), rec(0, ZERO, A)))
    check("strict_subfamily_full_N_accepts_two_contractions", full_n_admits(twice, 0))
    check("strict_subfamily_new_gate_rejects_two_contractions",
          admission_witness(twice, 0) is None)
    wrong_seed = imp(eq(succ(A), A), eq(rec(0, ZERO, succ(A)), A))
    check("full_N_allows_arbitrary_seed_term", full_n_admits(wrong_seed, 0))
    check("new_gate_requires_exact_seed_variable",
          admission_witness(wrong_seed, 0) is None)
    check("source_variable_budget_enforced",
          admission_witness(imp(eq(var("b"), A), eq(var("b"), A)), 0) is None)
    check("wrong_index_does_not_contract",
          admission_witness(imp(eq(A, A), eq(rec(1, ZERO, A), A)), 0) is None)

    rng = random.Random(20261101)

    def term(depth):
        if depth <= 0:
            return rng.choice((ZERO, N, A))
        k = rng.randrange(5)
        if k < 2:
            return rng.choice((ZERO, N, A))
        if k == 2:
            return succ(term(depth - 1))
        return rec(rng.randrange(4), term(depth - 1), term(depth - 1))

    for i in range(512):
        e = eq(term(4), term(4))
        f = imp(subst(e, "n", ZERO), e)
        check(f"equation_induction_{i:03d}",
              admission_witness(f, i % 4) is not None and full_n_admits(f, i % 4))
    for i in range(256):
        h = i % 4
        p = eq(term(3), term(3))
        # Inject a legal contractum on one side in varied term contexts.
        p = eq(rec(h, ZERO, A), p[2]) if i % 2 else eq(succ(rec(h, ZERO, A)), p[2])
        p0 = subst(p, "n", ZERO)
        for q in atom_contractions(p0, h):
            f = imp(q, p)
            check(f"one_contraction_embedding_{i:03d}",
                  admission_witness(f, h) is not None and full_n_admits(f, h))
    ledger = display_nodes()
    check("partial_display_is_26", ledger["outer"] == 26)
    return {
        "status": "pass", "number_of_assertions": len(checks),
        "scope": "Finite syntax diagnostics, not an infinite-theory proof.",
        "random_seed": 20261101, "equation_induction_samples": 512,
        "one_contraction_samples": 256, "display_ledger": ledger,
        "strictness_example": twice, "checks": checks,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path)
    options = parser.parse_args()
    result = run_checks()
    if options.out:
        options.out.parent.mkdir(parents=True, exist_ok=True)
        options.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
