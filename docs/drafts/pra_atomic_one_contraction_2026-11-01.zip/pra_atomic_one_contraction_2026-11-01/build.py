#!/usr/bin/env python3
"""Rebuild the report and diagnostics; optionally recheck the Lean sources."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(argv, cwd, logfile, env=None):
    completed = subprocess.run(argv, cwd=cwd, env=env, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    logfile.parent.mkdir(parents=True, exist_ok=True)
    logfile.write_text(completed.stdout)
    if completed.returncode:
        print(completed.stdout)
        raise SystemExit(f"Command failed ({completed.returncode}): {argv}")
    return {"command": argv, "exit_code": completed.returncode,
            "log": str(logfile.relative_to(ROOT))}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--skip-pdf", action="store_true")
    p.add_argument("--lean", help="Path to Lean 4.19.0; omit to skip formal rechecking")
    opts = p.parse_args()
    records = []
    records.append(run([sys.executable, "checks/check_schema.py", "--out",
                        "checks/schema_results.json"], ROOT,
                       ROOT / "audit/schema-check.log"))
    if not opts.skip_pdf:
        tex = shutil.which("pdflatex")
        if not tex:
            raise SystemExit("pdflatex is required unless --skip-pdf is specified.")
        (ROOT / "build").mkdir(exist_ok=True)
        for i in range(1, 4):
            records.append(run([tex, "-interaction=nonstopmode", "-halt-on-error",
                                "-no-shell-escape", "-output-directory=build", "report.tex"],
                               ROOT, ROOT / f"build/compile-pass{i}.txt"))
        log = (ROOT / "build/report.log").read_text()
        forbidden = ["Overfull", "undefined references", "undefined citations",
                     "There were undefined", "Rerun to get cross-references right"]
        if any(s in log for s in forbidden):
            raise SystemExit("The final TeX log requires review; see build/report.log.")
        shutil.copyfile(ROOT / "build/report.pdf", ROOT / "report.pdf")
    formal = {"status": "not rerun", "reason": "No --lean executable supplied"}
    if opts.lean:
        executable = str(Path(opts.lean).resolve())
        env = os.environ.copy()
        env["LEAN_PATH"] = "."
        results = []
        for module in ("DiagonalSchema", "NormalizedSchema", "AtomicSchema"):
            results.append(run([executable, "-o", module + ".olean", module + ".lean"],
                               ROOT / "formal", ROOT / f"formal/{module}-recheck.log", env))
        formal = {"status": "pass", "results": results}
    result = {"build": "pass", "commands": records, "formal_recheck": formal,
              "scope": "Formal checking is limited to the scope in formal/SCOPE.txt."}
    (ROOT / "audit/rebuild_status.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"build": "pass", "formal_recheck": formal["status"]}))


if __name__ == "__main__":
    main()
