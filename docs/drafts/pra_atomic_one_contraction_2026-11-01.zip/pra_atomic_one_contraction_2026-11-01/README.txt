PRIMITIVE RECURSIVE ARITHMETIC FROM ATOMIC TEMPLATES AND ONE CONTRACTION
Prepared for Vladimir Reshetnikov, 1 November 2026.

START WITH report.pdf. Its complete source is report.tex.
AXIOMS.txt gives the standalone specification.

RESULT
The current 26-node normalized presentation can be restricted to an ordinary
matrix consisting of one implication between two atoms (equations or bottom).
After substituting the counter by zero, the atoms must agree literally or
become identical after at most ONE contraction TOTAL in ONE atom:
  - a selected occurrence of exact R_h(0,a) becomes the seed variable a; or
  - the whole atom 0=S0 becomes bottom.
No repeated normalization or arbitrary quantifier-free matrix is needed.

In classical logic this family suffices. In intuitionistic logic add ONE fixed
coverage matrix C(0)->C(n), C(n)=(n=0 or n=S(R_u(n,0))), at update h(u,v)=u.
The report proves common conservative definitional extensions with matching
first-order PRA. Both interpretations retain the entire carrier and native
equality, and the round trips are internally the identity.

The improvement is a strict restriction of the current axiom family and its
formula grammar, not a reduction of the 26-node outer display. Every actual
axiom still has at most two individual variable names. The theory is an
effective infinite schema, not a single finite sentence. No absolute
shortestness claim is made.

CONTENTS
  report.tex / report.pdf           Complete manuscript and compiled report
  AXIOMS.txt                       Complete standalone specification
  checks/check_schema.py            Executable admission gate and diagnostics
  checks/schema_results.json       Recorded successful syntax diagnostics
  formal/AtomicSchema.lean          New checked finite-syntax logical kernel
  formal/DiagonalSchema.lean        Unchanged credited syntax infrastructure
  formal/NormalizedSchema.lean      Unchanged credited normalization infrastructure
  formal/AtomicSchema-check.txt    Actual successful Lean output
  formal/AtomicSchema-verification.json
                                  Compiler version, source hash, checked scope
  formal/SCOPE.txt                  Exact formalization boundary
  formal/ATTRIBUTION.txt            Reused source provenance
  audit/source_manifest.json        Eight pinned source archives and hashes
  audit/validation.json             Final build/layout/diagnostic record
  build.py                         Portable rebuilding script
  SHA256SUMS                       Hashes of all other archived files

REBUILD
Python 3.10+ and a TeX Live installation with the packages listed in report.tex:

  python3 build.py

Checks only:

  python3 build.py --skip-pdf

Rebuild and recheck the Lean modules (Lean 4.19.0, core only; no Mathlib):

  python3 build.py --lean /absolute/path/to/lean

Direct formal recheck from formal/, in dependency order:

  lean -o DiagonalSchema.olean DiagonalSchema.lean
  LEAN_PATH=. lean -o NormalizedSchema.olean NormalizedSchema.lean
  LEAN_PATH=. lean -o AtomicSchema.olean AtomicSchema.lean

The supplied SHA256SUMS describes distributed bytes. Rebuilding may change
PDF metadata and diagnostic logs; byte-identical PDF rebuilding is not claimed.

VERIFICATION SCOPE
Lean checks finite syntax, the single-contraction relation, containment in
the older normalized gate, and logical extraction through equation induction
and the two coverage arguments. The classical coverage theorem takes excluded
middle as an explicit hypothesis. The complete arithmetic bootstrap, pairing,
primitive-recursion compiler and bi-interpretability theorem are written proofs,
not an end-to-end Lean formalization. The Python checks are finite diagnostics.

COMPARISON SNAPSHOT
  https://github.com/VladimirReshetnikov/ProveIt
  ab29d2ad2189948d995d6cffa7cea5298cd126a0
  docs/drafts (eight archives)

Binary recursors, the one-parameter arithmetic bootstrap, pairing and the
compiler are inherited and credited. One-mark restrictions and a single
coverage ingredient also occur separately in the inputs. The exact combined
atomic, one-contraction subfamily and its proof are the contribution here.
