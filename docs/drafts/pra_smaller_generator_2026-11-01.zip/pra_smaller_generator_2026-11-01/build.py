#!/usr/bin/env python3
"""Rebuild the deterministic checks and PDF; optionally rerun Lean kernels."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def run(args, log=None):
    r = subprocess.run([str(x) for x in args], cwd=ROOT, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if log:
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(r.stdout)
    if r.returncode:
        print(r.stdout, file=sys.stderr)
        raise SystemExit(r.returncode)
    return r.stdout


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--lean', help='Explicit path to a Lean 4.19.0 executable')
    p.add_argument('--checks-only', action='store_true')
    p.add_argument('--pdf-only', action='store_true')
    options = p.parse_args()
    if options.checks_only and options.pdf_only:
        p.error('Choose at most one of --checks-only and --pdf-only')
    record = {'scope': 'Finite diagnostics and selected Lean kernels; full theorem is a written proof.'}
    if not options.pdf_only:
        run([sys.executable, 'checks/check_schema.py', '--output',
             'checks/schema_results.json'], ROOT/'audit/schema_check.log')
        run([sys.executable, 'checks/check_counts.py'], ROOT/'audit/count_check.log')
        run([sys.executable, 'exploration/build_pure_iteration_term.py'],
            ROOT/'audit/pure_term_syntax.log')
        run([sys.executable, 'exploration/check_pure_iteration_frontier.py'],
            ROOT/'audit/pure_standard_checks.log')
        record['python_checks'] = 'passed'
        lean = options.lean or shutil.which('lean')
        if lean:
            record['lean_version'] = run([lean, '--version']).strip()
            results = []
            for name in ('RootComputation.lean', 'ZeroDecision.lean'):
                source = ROOT/'formal'/name
                text = run([lean, source], source.with_suffix('.log'))
                results.append({'file': name, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                                'exit_code': 0, 'axiom_free_reports': text.count('does not depend on any axioms')})
            (ROOT/'formal/verification.json').write_text(json.dumps({
                'lean': record['lean_version'], 'results': results,
                'scope': 'Constructive logical/algebraic kernels only.'}, indent=2)+'\n')
            record['lean'] = 'passed'
        else:
            record['lean'] = 'not rerun; no executable supplied or found'
            print('Lean checks not rerun: supply --lean /absolute/path/to/lean.')
    if not options.checks_only:
        latexmk = shutil.which('latexmk')
        if not latexmk:
            raise SystemExit('latexmk not found; install TeX Live to rebuild the PDF.')
        run([latexmk, '-pdf', '-interaction=nonstopmode', '-halt-on-error',
             '-outdir=audit/tex', 'report.tex'], ROOT/'audit/latex-build.log')
        log = (ROOT/'audit/tex/report.log').read_text(errors='replace')
        forbidden = ('Undefined control sequence', 'There were undefined references',
                     'There were undefined citations', 'Overfull \\hbox', 'Overfull \\vbox')
        found = [s for s in forbidden if s in log]
        if found:
            raise SystemExit('Review PDF build diagnostics: '+', '.join(found))
        shutil.copy2(ROOT/'audit/tex/report.pdf', ROOT/'report.pdf')
        record['pdf'] = 'built; visual inspection remains a separate human review'
    (ROOT/'audit/build_results.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
