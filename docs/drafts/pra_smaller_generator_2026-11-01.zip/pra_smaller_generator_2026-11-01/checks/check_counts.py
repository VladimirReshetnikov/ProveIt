#!/usr/bin/env python3
"""Explicit AST accounting. Display subtotals are not full specification sizes."""
import json
from pathlib import Path
from check_schema import V, ZERO, BOT, S, R, Eq, Imp, Or, All, formula_sub, dec


def size(t):
    tag = t[0]
    if tag in ('var', 'zero', 'bottom'):
        return 1
    if tag == 'S':
        return 1 + size(t[1])
    if tag == 'R':
        return 1 + size(t[2]) + size(t[3])
    if tag == 'F':
        return 1 + sum(size(x) for x in t[1:])
    if tag in ('eq', 'imp', 'or', 'and'):
        return 1 + size(t[1]) + size(t[2])
    if tag == 'all':
        return 1 + size(t[2])
    raise ValueError(t)


def emit15(f):
    return All('a', Imp(All('n', Imp(f, formula_sub(f, {'n': S(V('n'))}))),
                        All('n', f)))


def main():
    n, a, b = V('n'), V('a'), V('b')
    F = lambda *args: ('F', *args)
    h15 = All('a', Imp(All('n', Imp(F(n, a), F(S(n), a))), All('n', F(n, a))))
    h18 = All('a', All('b', Imp(All('b', Imp(F(b, a, b), F(S(b), a, b))), F(b, a, b))))
    coverage = Or(Eq(n, ZERO), Eq(n, S(R('K', n, ZERO))))
    decision = dec(n)
    values = {
        'H15_outer_template': size(h15),
        'H18_outer_template': size(h18),
        'D_matrix_expanded': size(decision),
        'coverage_matrix_expanded_with_K': size(coverage),
        'H15_direct_D_exception_expanded': size(emit15(decision)),
        'H15_wrapped_D_exception_expanded': size(emit15(Imp(dec(ZERO), decision))),
        'H15_direct_coverage_exception_expanded_comparator': size(emit15(coverage)),
        'H15_wrapped_coverage_exception_expanded_comparator': size(emit15(
            Imp(formula_sub(coverage, {'n': ZERO}), coverage))),
    }
    expected = [15, 18, 9, 10, 34, 64, 38, 71]
    if list(values.values()) != expected:
        raise RuntimeError((values, expected))
    result = {
        'status': 'passed', 'counts': values,
        'convention': 'One node per variable/constant occurrence, function/formula application, equality, connective, falsity, quantifier. Binder names and symbol metadata are labels.',
        'scope': 'Outer templates exclude matrix/update bodies and all generator code. Expanded exception counts include their actual formula bodies. None is a total encoding or global minimum.'
    }
    output = Path(__file__).with_name('counts.json')
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(values))


if __name__ == '__main__':
    main()
