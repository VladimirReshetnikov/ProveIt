#!/usr/bin/env python3
"""Finite syntax checker for the PRA deterministic one-root computation gate.

This checks the stated admission grammar, examples and rejection witnesses.
It does not verify the arithmetic bootstrap or bi-interpretability theorem.
Stored update descriptions are immutable symbol metadata, not term subtrees.
Only Python's standard library is used.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path


def V(name): return ("var", name)
ZERO = ("zero",)
BOT = ("bottom",)
def S(t): return ("S", t)
def R(name, counter, seed): return ("R", name, counter, seed)
def Eq(s, t): return ("eq", s, t)
def Imp(a, b): return ("imp", a, b)
def Or(a, b): return ("or", a, b)
def All(name, f): return ("all", name, f)


def term_vars(t):
    tag = t[0]
    if tag == "var": return {t[1]}
    if tag == "zero": return set()
    if tag == "S": return term_vars(t[1])
    if tag == "R": return term_vars(t[2]) | term_vars(t[3])
    raise ValueError(f"Unknown term node: {t!r}")


def term_sub(t, env):
    tag = t[0]
    if tag == "var": return env.get(t[1], t)
    if tag == "zero": return t
    if tag == "S": return S(term_sub(t[1], env))
    if tag == "R":
        # The description NAME t[1] is intentionally untouched.
        return R(t[1], term_sub(t[2], env), term_sub(t[3], env))
    raise ValueError(f"Unknown term node: {t!r}")


def formula_vars(f):
    tag = f[0]
    if tag == "bottom": return set()
    if tag == "eq": return term_vars(f[1]) | term_vars(f[2])
    if tag in ("imp", "or"): return formula_vars(f[1]) | formula_vars(f[2])
    if tag == "all": return formula_vars(f[2]) - {f[1]}
    raise ValueError(f"Unknown formula node: {f!r}")


def formula_sub(f, env):
    tag = f[0]
    if tag == "bottom": return f
    if tag == "eq": return Eq(term_sub(f[1], env), term_sub(f[2], env))
    if tag in ("imp", "or"):
        return (tag, formula_sub(f[1], env), formula_sub(f[2], env))
    if tag == "all":
        reduced = {k: v for k, v in env.items() if k != f[1]}
        if any(f[1] in term_vars(t) for t in reduced.values()):
            raise ValueError("Capture-risk substitution is outside this checker")
        return All(f[1], formula_sub(f[2], reduced))
    raise ValueError(f"Unknown formula node: {f!r}")


def validate_term(t, descriptions):
    tag = t[0]
    if tag == "var" and len(t) == 2 and isinstance(t[1], str): return
    if tag == "zero" and len(t) == 1: return
    if tag == "S" and len(t) == 2:
        validate_term(t[1], descriptions)
        return
    if tag == "R" and len(t) == 4 and t[1] in descriptions:
        validate_term(t[2], descriptions)
        validate_term(t[3], descriptions)
        return
    raise ValueError(f"Invalid or unavailable term symbol: {t!r}")


def validate_formula(f, descriptions):
    tag = f[0]
    if tag == "bottom" and len(f) == 1: return
    if tag == "eq" and len(f) == 3:
        validate_term(f[1], descriptions)
        validate_term(f[2], descriptions)
        return
    if tag in ("imp", "or") and len(f) == 3:
        validate_formula(f[1], descriptions)
        validate_formula(f[2], descriptions)
        return
    if tag == "all" and len(f) == 3:
        validate_formula(f[2], descriptions)
        return
    raise ValueError(f"Invalid formula node: {f!r}")


def registry(definitions, unary_except_projection=True):
    descriptions = {}
    for name, body in definitions:
        if name in descriptions: raise ValueError("Duplicate description name")
        validate_term(body, descriptions)  # earlier descriptions only
        allowed = {"u", "v"} if name == "K" else {"v"}
        if not unary_except_projection: allowed = {"u", "v"}
        if not term_vars(body) <= allowed: raise ValueError("Illegal update parameter")
        if name == "K" and unary_except_projection and body != V("u"):
            raise ValueError("K must be the single counter-projection exception")
        descriptions[name] = body
    return descriptions


def head_computation(t, descriptions):
    """Exactly one computation at this term's root, or failure."""
    if t[0] != "R": return None
    name, counter, seed = t[1:]
    if counter == ZERO:
        return seed, {"rule": "zero", "description": name}
    if counter[0] == "S":
        previous = counter[1]
        value = term_sub(descriptions[name], {"u": previous, "v": R(name, previous, seed)})
        # No recursive call: newly inserted syntax is never computed.
        return value, {"rule": "successor", "description": name}
    return None


SEP = Imp(Eq(ZERO, S(ZERO)), BOT)
def dec(t): return Or(Eq(t, ZERO), Imp(Eq(t, ZERO), BOT))
def dec_matrix(variable): return Imp(dec(ZERO), dec(V(variable)))


def inspect_root_pair(antecedent, consequent, descriptions):
    result = head_computation(consequent[1], descriptions)
    if result is None: return {"accepted": False, "reason": "no root computation"}
    replacement, detail = result
    if Eq(replacement, consequent[2]) != antecedent:
        return {"accepted": False, "reason": "one computation does not match", **detail}
    return {"accepted": True, **detail}


def admit15(f, descriptions, intuitionistic=False, decision_form="direct"):
    if decision_form not in ("direct", "wrapped"): raise ValueError("Unknown decision-matrix form")
    validate_formula(f, descriptions)
    if f == SEP: return {"accepted": True, "branch": "fixed separation"}
    decision = dec(V("n")) if decision_form == "direct" else dec_matrix("n")
    if intuitionistic and f == decision:
        return {"accepted": True, "branch": "fixed zero-decidability matrix"}
    if f[0] != "imp": return {"accepted": False, "reason": "matrix grammar"}
    antecedent, consequent = f[1:]
    if antecedent[0] == consequent[0] == "eq":
        if not formula_vars(f) <= {"n", "a"}:
            return {"accepted": False, "reason": "free-variable budget"}
        base = formula_sub(f, {"n": ZERO})
        return {"branch": "equation implication", **inspect_root_pair(base[1], base[2], descriptions)}
    if (antecedent[0] == consequent[0] == "all"
            and antecedent[1] == consequent[1] == "b"
            and antecedent[2][0] == consequent[2][0] == "eq"):
        if not (formula_vars(antecedent[2]) | formula_vars(consequent[2])) <= {"a", "b"}:
            return {"accepted": False, "reason": "stationary quantified branch"}
        return {"branch": "stationary quantified equations",
                **inspect_root_pair(antecedent[2], consequent[2], descriptions)}
    return {"accepted": False, "reason": "matrix grammar"}


def admit18(f, descriptions, intuitionistic=False, decision_form="direct"):
    if decision_form not in ("direct", "wrapped"): raise ValueError("Unknown decision-matrix form")
    validate_formula(f, descriptions)
    if f == SEP: return {"accepted": True, "branch": "fixed separation"}
    decision = dec(V("x")) if decision_form == "direct" else dec_matrix("x")
    if intuitionistic and f == decision:
        return {"accepted": True, "branch": "fixed zero-decidability matrix"}
    if not (f[0] == "imp" and f[1][0] == f[2][0] == "eq"):
        return {"accepted": False, "reason": "matrix grammar"}
    names = formula_vars(f)
    if not names <= {"x", "y", "z"}:
        return {"accepted": False, "reason": "free-variable budget"}
    if "x" in names and "z" in names:
        return {"accepted": False, "reason": "unused-slot requirement"}
    base = formula_sub(f, {"x": ZERO})
    return {"branch": "equation implication", **inspect_root_pair(base[1], base[2], descriptions)}


def emit18(f):
    """The two-name shadowing convention is intentional and checked below."""
    now = formula_sub(f, {"x": V("b"), "y": V("a"), "z": V("b")})
    nxt = formula_sub(f, {"x": S(V("b")), "y": V("a"), "z": V("b")})
    return All("a", All("b", Imp(All("b", Imp(now, nxt)), now)))


def all_variable_names(f):
    tag = f[0]
    if tag == "bottom": return set()
    if tag == "eq": return term_vars(f[1]) | term_vars(f[2])
    if tag in ("imp", "or"): return all_variable_names(f[1]) | all_variable_names(f[2])
    if tag == "all": return {f[1]} | all_variable_names(f[2])
    raise ValueError(f)


def regressions():
    definitions = [
        ("K", V("u")), ("I", V("v")), ("Z", ZERO), ("Add", S(V("v"))),
        ("Pred", R("K", V("v"), ZERO)),
        ("Nested", R("Z", ZERO, R("K", V("v"), ZERO))),
    ]
    descriptions = registry(definitions)
    initial_registry = json.dumps(descriptions, sort_keys=True)
    records = []

    def expect(label, result, accepted):
        if result["accepted"] != accepted:
            raise RuntimeError(f"Regression failed: {label}: {result}")
        records.append({"case": label, "expected_acceptance": accepted, **result})

    a, b, n = V("a"), V("b"), V("n")
    y, z, x = V("y"), V("z"), V("x")
    for name, body in descriptions.items():
        init = Imp(Eq(a, a), Eq(R(name, ZERO, a), a))
        expect(f"15 initialization {name}", admit15(init, descriptions), True)
        rhs = term_sub(body, {"u": a, "v": R(name, a, b)})
        step = Imp(All("b", Eq(rhs, rhs)), All("b", Eq(R(name, S(a), b), rhs)))
        expect(f"15 independent-seed successor {name}", admit15(step, descriptions), True)
        rhs18 = term_sub(body, {"u": y, "v": R(name, y, z)})
        step18 = Imp(Eq(rhs18, rhs18), Eq(R(name, S(y), z), rhs18))
        expect(f"18 independent-seed successor {name}", admit18(step18, descriptions), True)
        emitted = emit18(step18)
        if formula_vars(emitted) or all_variable_names(emitted) != {"a", "b"}:
            raise RuntimeError("Two-name emitted successor axiom was not closed")

    equations = [
        Eq(n, a), Eq(S(n), R("K", S(n), a)),
        Eq(R("Nested", n, R("I", a, ZERO)), R("Z", a, S(n))),
    ]
    for index, e in enumerate(equations):
        base = formula_sub(e, {"n": ZERO})
        probe = Imp(base, Eq(R("Z", ZERO, e[1]), e[2]))
        expect(f"15 wrapped equation induction {index}", admit15(probe, descriptions), True)
        probe18 = formula_sub(probe, {"n": x, "a": y})
        expect(f"18 wrapped equation induction {index}", admit18(probe18, descriptions), True)
        emitted = emit18(probe18)
        if formula_vars(emitted) or all_variable_names(emitted) != {"a", "b"}:
            raise RuntimeError("Two-name emitted induction axiom was not closed")

    negative = Imp(Eq(n, a), Eq(R("Z", ZERO, ZERO), a))
    expect("15 negative-coverage probe", admit15(negative, descriptions), True)
    expect("18 negative-coverage probe", admit18(formula_sub(negative, {"n": x, "a": y}), descriptions), True)
    for logic in (False, True):
        label = "intuitionistic" if logic else "classical"
        expect(f"15 separation {label}", admit15(SEP, descriptions, logic), True)
        expect(f"18 separation {label}", admit18(SEP, descriptions, logic), True)
        expect(f"15 direct zero-decidability exception {label}", admit15(dec(n), descriptions, logic), logic)
        expect(f"18 direct zero-decidability exception {label}", admit18(dec(x), descriptions, logic), logic)
        expect(f"15 wrapped zero-decidability exception {label}", admit15(dec_matrix("n"), descriptions, logic, "wrapped"), logic)
        expect(f"18 wrapped zero-decidability exception {label}", admit18(dec_matrix("x"), descriptions, logic, "wrapped"), logic)

    rejections = {
        "zero-computation tautology": Imp(Eq(ZERO, ZERO), Eq(ZERO, ZERO)),
        "consequent right-term computation": Imp(Eq(a, a), Eq(a, R("I", ZERO, a))),
        "nested consequent computation": Imp(Eq(S(a), S(a)), Eq(S(R("I", ZERO, a)), S(a))),
        "antecedent computation": Imp(Eq(R("I", ZERO, a), a), Eq(a, a)),
        "two computations required": Imp(Eq(a, a), Eq(R("I", ZERO, a), R("I", ZERO, a))),
        "newly inserted syntax must not reduce": Imp(Eq(a, a), Eq(R("Nested", S(ZERO), a), a)),
        "extra free variable": Imp(Eq(b, b), Eq(R("I", ZERO, b), b)),
        "moving quantified formula": Imp(All("b", Eq(n, n)), All("b", Eq(R("I", ZERO, n), n))),
    }
    for label, f in rejections.items(): expect(label, admit15(f, descriptions), False)
    xz_probe = Imp(Eq(z, z), Eq(R("I", ZERO, z), z))
    # Place x in both identical argument positions without affecting the head test.
    xz_probe = Imp(Eq(R("I", x, z), R("I", x, z)),
                   Eq(R("I", ZERO, R("I", x, z)), R("I", x, z)))
    expect("18 rejects simultaneous moving and endpoint slots", admit18(xz_probe, descriptions), False)

    # A positive nested-description test: successor expansion stops immediately.
    rhs = term_sub(descriptions["Nested"], {"u": a, "v": R("Nested", a, ZERO)})
    exact = Imp(Eq(rhs, rhs), Eq(R("Nested", S(a), ZERO), rhs))
    expect("newly inserted syntax retained exactly", admit15(exact, descriptions), True)

    active = R("K", V("u"), V("v"))
    substituted = term_sub(active, {"u": ZERO, "v": S(ZERO)})
    if substituted != R("K", ZERO, S(ZERO)):
        raise RuntimeError("Application argument substitution failed")
    if json.dumps(descriptions, sort_keys=True) != initial_registry or descriptions["K"] != V("u"):
        raise RuntimeError("Stored description metadata was mutated")

    invalid_definitions = [
        [("K", V("u")), ("Future", R("Later", V("v"), ZERO))],
        [("K", V("u")), ("Frozen", V("a"))],
        [("K", V("u")), ("Mixed", V("u"))],
    ]
    for index, items in enumerate(invalid_definitions):
        try: registry(items)
        except ValueError: pass
        else: raise RuntimeError(f"Invalid stored description accepted: {index}")

    return {
        "status": "passed", "regression_count": len(records),
        "tested_descriptions": list(descriptions),
        "registry_sha256": hashlib.sha256(initial_registry.encode()).hexdigest(),
        "stored_description_opacity": "passed",
        "description_well_foundedness_and_parameter_rejections": len(invalid_definitions),
        "two_name_18_emission": "all tested successor and induction probes closed using only a,b",
        "scope": "Finite syntax/admission regressions only; no claim of formal arithmetic or bi-interpretability verification.",
        "fixed_intuitionistic_matrix": "D(n), D(t)=(t=0) or ((t=0)->bottom); optional strict-subfamily form D(0)->D(n) also checked",
        "cases": records,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    options = parser.parse_args()
    result = regressions()
    serialized = json.dumps(result, indent=2) + "\n"
    if options.output: options.output.write_text(serialized)
    print(json.dumps({"status": result["status"], "regression_count": result["regression_count"],
                      "output": str(options.output) if options.output else None}))
