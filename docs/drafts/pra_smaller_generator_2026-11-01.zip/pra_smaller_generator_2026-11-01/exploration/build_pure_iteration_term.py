#!/usr/bin/env python3
"""Emit and audit the exact predecessor candidate as finite pure-iterator syntax.

No numerical functions are used in the emitted syntax except 0 and S.
Composition is ordinary term substitution; each iterator stores a unary body.
The output proves a syntactic property only, not arithmetic correctness.
"""
from __future__ import annotations

import json
from pathlib import Path


def var(name):
    return {"var": name}


def call(name, *args):
    return {"call": name, "args": list(args)}


def num(n):
    result = call("0")
    for _ in range(n):
        result = call("S", result)
    return result


definitions = []
arities = {"0": 0, "S": 1}


def scan(term, allowed_vars, dependencies):
    if "var" in term:
        if set(term) != {"var"} or term["var"] not in allowed_vars:
            raise ValueError(("invalid variable", term))
        return 1
    if set(term) != {"call", "args"}:
        raise ValueError(("invalid term", term))
    name, args = term["call"], term["args"]
    if name not in arities or len(args) != arities[name]:
        raise ValueError(("unknown, later, or wrong-arity symbol", name, args))
    dependencies.add(name)
    return 1 + sum(scan(t, allowed_vars, dependencies) for t in args)


def term(name, params, body):
    dependencies = set()
    nodes = scan(body, set(params), dependencies)
    definitions.append({"name": name, "kind": "term_abbreviation",
                        "parameters": params, "body": body,
                        "direct_dependencies": sorted(dependencies),
                        "stored_body_nodes": nodes})
    arities[name] = len(params)


def iterator(name, body):
    dependencies = set()
    nodes = scan(body, {"v"}, dependencies)
    definitions.append({"name": name, "kind": "pure_iterator",
                        "arity": 2, "update_variable": "v", "body": body,
                        "direct_dependencies": sorted(dependencies),
                        "stored_body_nodes": nodes})
    arities[name] = 2


def build():
    v, n, x, y, aa, bb, zz = map(var, ["v", "n", "x", "y", "a", "b", "z"])
    zero, one, two, four, seven, eight = map(num, [0, 1, 2, 4, 7, 8])
    iterator("I0", zero)
    iterator("IS", call("S", v))
    term("Z", ["n", "a"], call("I0", n, aa))
    term("Add", ["x", "y"], call("IS", y, x))
    term("C", ["z", "a", "b"],
         call("Add", call("Z", zz, aa), call("Z", call("Z", zz, one), bb)))
    term("If", ["b", "x", "y"], call("C", bb, y, x))
    term("O", ["v"], call("Z", v, one))
    term("D", ["v"], call("Add", v, v))
    term("T", ["v"], call("Add", call("D", v), v))
    iterator("IO", call("O", v))
    iterator("ID", call("D", v))
    iterator("IT", call("T", v))
    term("N", ["n"], call("IO", n, zero))
    term("Pow2", ["n"], call("ID", n, one))
    term("Pow3", ["n"], call("IT", n, one))
    term("c3", ["v"], call("C", v, one, call("C", call("N", v), zero, two)))
    iterator("Ic3", call("c3", v))
    term("m3", ["n"], call("Ic3", n, zero))
    term("g2", ["v"], call("Add", call("S", v), call("N", call("m3", v))))
    iterator("Ig2", call("g2", v))
    term("F2", ["n"], call("Ig2", n, zero))
    term("h", ["v"], call("If", call("N", v), one, call("F2", v)))
    iterator("Ih", call("h", v))
    term("LE", ["x", "y"], call("N", call("Ih", y, call("Pow2", x))))
    term("Eq", ["x", "y"], call("If", call("LE", x, y), call("LE", y, x), zero))
    term("w", ["v"], call("If", call("N", v), call("T", v), call("F2", v)))
    iterator("Iw", call("w", v))
    term("Q", ["v"], call("Eq", call("Iw", v, v), call("Pow3", v)))
    ss_v = call("S", call("S", v))
    term("j", ["v"], call("If", call("N", v),
                             call("If", call("Q", call("S", v)), zero, ss_v), ss_v))
    iterator("Ij", call("j", v))
    term("E", ["n"], call("C", n, zero, call("Ij", n, call("S", call("D", n)))))
    term("c9", ["v"], call("If", call("Eq", v, eight), zero, call("S", v)))
    iterator("Ic9", call("c9", v))
    term("m9", ["n"], call("Ic9", n, zero))
    term("g8", ["v"], call("Add", call("S", v), call("Eq", call("m9", v), seven)))
    iterator("Ig8", call("g8", v))
    term("F8", ["n"], call("Ig8", n, zero))
    term("q", ["v"], call("If", call("Eq", v, two), one,
                             call("If", call("Eq", v, four), two, call("E", call("F8", v)))))
    term("a", ["v"], call("If", call("Q", call("S", v)), call("q", call("S", v)), call("S", v)))
    term("b", ["v"], call("If", call("Q", v), call("S", call("q", v)), call("S", v)))
    term("z", ["v"], call("S", call("D", v)))
    iterator("Ia", call("a", v))
    iterator("Ib", call("b", v))
    iterator("Iz", call("z", v))
    term("Tau", ["x"], call("Iz", x, zero))
    term("Pred", ["x"], call("C", x, zero,
         call("If", call("Eq", x, one), zero,
         call("If", call("Eq", x, two), one,
         call("If", call("Q", x), call("Ib", call("Tau", x), x),
                                  call("Ia", call("Tau", x), x))))))
    data = {
        "syntax_status": "validated_finite_dependency_ordered_pure_iteration",
        "arithmetic_status": "standard_N_proof_in_companion_note_only",
        "weak_theory_predecessor_identity_proved": False,
        "initial_signature": {"0": 0, "S": 1},
        "iterator_schema": {
            "zero": "I_h(0,a)=a",
            "successor": "I_h(Sn,a)=h(I_h(n,a))",
            "restriction": "h has only v free and calls earlier symbols"
        },
        "output_term": {"call": "Pred", "args": [{"var": "x"}]},
        "definitions": definitions,
        "counts": {
            "term_abbreviations": sum(d["kind"] == "term_abbreviation" for d in definitions),
            "pure_iterators": sum(d["kind"] == "pure_iterator" for d in definitions),
            "stored_body_nodes_total": sum(d["stored_body_nodes"] for d in definitions),
            "count_caution": "A DAG size, not an expanded term size or a minimality claim"
        }
    }
    output = Path(__file__).with_name("pure_iteration_predecessor_term.json")
    output.write_text(json.dumps(data, indent=2) + "\n")
    print(json.dumps({"output": str(output), "validated": True, "counts": data["counts"]}, indent=2))


if __name__ == "__main__":
    build()
