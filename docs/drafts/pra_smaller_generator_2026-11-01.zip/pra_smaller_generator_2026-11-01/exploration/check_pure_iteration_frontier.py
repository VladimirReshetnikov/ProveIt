#!/usr/bin/env python3
"""Finite standard-N diagnostics for a scalar pure-iterator predecessor term.

This is NOT an internal first-order proof or a fully expanded term evaluator.
Successive helper formulas, checked at finite inputs, serve as accelerators.
"""
from __future__ import annotations

import json
from pathlib import Path


def iterate(f, n: int, seed: int) -> int:
    for _ in range(n):
        seed = f(seed)
    return seed


def c3(v: int) -> int:
    return 1 if v == 0 else (0 if v % 2 == 0 else 2)


def m3(n: int) -> int:
    return iterate(c3, n, 0)


def g2(v: int) -> int:
    # The proven m3 formula is used as an accelerator here.
    return v + 1 + ((v % 3) % 2)


def F2(n: int) -> int:
    return iterate(g2, n, 0)


def h(v: int) -> int:
    # The F2 formula is used to prevent nested gigantic loops.
    return 1 if v % 2 else (3 * v // 2)


def le_term(x: int, y: int) -> int:
    return iterate(h, y, 2**x) % 2


def w(v: int) -> int:
    return 3 * v if v % 2 else (3 * v // 2)


def power_term(n: int) -> int:
    # Numerical equality accelerates the previous LE-based equality term.
    return int(iterate(w, n, n) == 3**n)


def Q(n: int) -> int:
    # Checked power_term characteristic, used as an accelerator.
    return int(n > 0 and (n & (n - 1)) == 0)


def j(v: int) -> int:
    if v % 2 == 0:
        return v + 2
    return 0 if Q(v + 1) else v + 2


def excess_term(n: int) -> int:
    return 0 if n == 0 else iterate(j, n, 2 * n + 1)


def c9(v: int) -> int:
    return 0 if v == 8 else v + 1


def g8(v: int) -> int:
    # m9(v)=v mod9 is the checked helper formula.
    return v + 1 + int(v % 9 == 7)


def F8(n: int) -> int:
    return iterate(g8, n, 0)


def q(n: int) -> int:
    if n == 2:
        return 1
    if n == 4:
        return 2
    # F8's checked formula accelerates this helper.
    return excess_term(n + n // 8)


def a(v: int) -> int:
    return q(v + 1) if Q(v + 1) else v + 1


def b(v: int) -> int:
    return q(v) + 1 if Q(v) else v + 1


def tau(x: int) -> int:
    return iterate(lambda v: 2 * v + 1, x, 0)


def pred_term(x: int) -> int:
    if x in (0, 1):
        return 0
    if x == 2:
        return 1
    return iterate(b if Q(x) else a, tau(x), x)


def main() -> None:
    checks = []

    def check(name, domain, predicate, shortcuts):
        cases = 0
        for item in domain:
            if not predicate(item):
                raise AssertionError((name, item))
            cases += 1
        checks.append({"name": name, "cases": cases, "passed": True,
                       "accelerators": shortcuts})

    check("modulo_three", range(129), lambda n: m3(n) == n % 3,
          ["addition and parity evaluated by their standard formulas"])
    check("F2_floor_3n_over_2", range(513), lambda n: F2(n) == 3 * n // 2,
          ["m3(v)=v mod3"])
    check("comparison", ((x, y) for x in range(17) for y in range(17)),
          lambda xy: le_term(*xy) == int(xy[0] <= xy[1]),
          ["F2(v)=floor(3v/2)", "Pow2(x)=2^x", "N(v)=v mod2"])
    check("power_of_two_characteristic", range(129),
          lambda n: power_term(n) == Q(n),
          ["F2(v)=floor(3v/2)", "Eq is numerical equality",
           "Pow3(v)=3^v", "N(v)=v mod2"])
    check("four_times_binary_excess", range(1025),
          lambda n: excess_term(n) == (0 if n == 0 else
                                      4 * (n - 2**(n.bit_length() - 1))),
          ["Q is the bitwise positive-power-of-two test", "N(v)=v mod2"])
    check("modulo_nine", range(129), lambda n: iterate(c9, n, 0) == n % 9,
          ["Eq is numerical equality"])
    check("F8_floor_9n_over_8", range(513), lambda n: F8(n) == 9 * n // 8,
          ["m9(v)=v mod9", "Eq is numerical equality"])
    check("halving_powers_of_two", (2**k for k in range(12)),
          lambda n: q(n) == n // 2,
          ["F8(v)=floor(9v/8)", "Q is bitwise power test"])
    check("first_dyadic_cycle", (2**k for k in range(8)),
          lambda B: all(a(n) == (n + 1 if n < 2*B-1 else B)
                        for n in range(B, 2*B)),
          ["Q is bitwise power test", "q uses checked F8 shortcut"])
    check("second_dyadic_cycle", (2**k for k in range(8)),
          lambda B: all(b(n) == (n + 1 if n < 2*B else B+1)
                        for n in range(B+1, 2*B+1)),
          ["Q is bitwise power test", "q uses checked F8 shortcut"])
    check("tau_power_minus_one", range(65), lambda n: tau(n) == 2**n-1,
          ["doubling evaluated by addition"])
    check("predecessor_outer_iteration", range(18),
          lambda n: pred_term(n) == max(n-1, 0),
          ["addition/parity/Eq/Q use checked formulas",
           "F8 uses checked formula; E and final a/b iterators run literally"])
    result = {
        "status": "finite_standard_model_diagnostic_only",
        "internal_weak_theory_proof": False,
        "fully_expanded_term_evaluator": False,
        "checks": checks,
        "total_cases": sum(c["cases"] for c in checks),
        "predecessor_values": [pred_term(n) for n in range(18)],
        "remaining_goal": "Prove Pred(Sx)=x internally in the pure-iterator theory without K."
    }
    output = Path(__file__).with_name("pure_iteration_frontier_checks.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"output": str(output), "all_passed": True,
                      "total_cases": result["total_cases"],
                      "predecessor_values": result["predecessor_values"]}, indent=2))


if __name__ == "__main__":
    main()
