PRA WITH A SMALLER AXIOM GENERATOR
Prepared for Vladimir Reshetnikov, 1 November 2026.
Source snapshot: 0e1088217e60a865ee39f86a5563cadbbbc5875f.

MAIN RESULT
The complete report gives classical and intuitionistic theories, separately
definitionally equivalent and hence bi-interpretable/equiconsistent with
matching first-order PRA. The full carrier and native equality are preserved;
both internal round-trip isomorphisms are the identity.

The best current 15/18 outer displays are retained. Their admission procedure
is simplified to EXACTLY ONE unfolding of the WHOLE LEFT TERM of the
consequent equation, followed by literal comparison. There is no contextual
search or zero-rewrite branch. A fixed separation instance remains. The
intuitionistic additional instance is zero-decidability D(n)=n=0 or n!=0;
the report proves constructively that it supplies constructor coverage.

This is a new reduction of the generator, NOT a new outer-node minimum.
The smaller unary-update language still retains its one fixed K projection.

ADDITIONAL RESEARCH RESULT
The exploration supplement gives an explicit pure scalar-iteration term for
predecessor. Its correctness is proved on standard natural numbers and its
finite dependency grammar is checked. The weak-theory internal equation
Pred(Sx)=x remains open; the supplement therefore does NOT remove K from
the main bi-interpretability theorem.

FILES
  report.pdf                Complete compiled paper and supplement.
  report.tex, sections/     Complete LaTeX source, proofs and references.
  AXIOMS.txt                Standalone exact main specifications.
  checks/                   Admission checker, AST accounting, results.
  formal/                   Two Lean 4.19.0 kernels, logs and scope.
  exploration/              Exact pure predecessor term, standard-N proof,
                            syntax/dependency generator and bounded diagnostics.
  source_manifest.json      All seven input archives, immutable URLs and hashes.
  audit/                    Build results and review records.
  build.py                  Portable rebuild/check entry point.
  SHA256SUMS                Integrity hashes of the packaged files.

REBUILD
  python3 build.py
  python3 build.py --lean /absolute/path/to/lean
  python3 build.py --checks-only
  python3 build.py --pdf-only

The Python scripts use only the standard library. PDF building needs TeX Live
and latexmk. Lean needs no Mathlib. No dependencies or comparison archives
are downloaded or executed by the rebuild script. Rebuilding changes logs,
PDF metadata, results, and therefore integrity hashes.

VERIFICATION BOUNDARY
48 deterministic finite-syntax regressions pass. Fourteen constructive Lean
kernel theorems compile and have no global axiom dependencies, with all
arithmetic/induction assumptions supplied explicitly. The full first-order
proof calculus, arithmetic pairing/compiler, and bi-interpretability result
are written proofs, not an end-to-end proof-assistant formalization.

The pure-predecessor syntax contains 15 iterators and 31 term abbreviations.
Its 2,838 bounded numerical checks use declared accelerators; they are not a
fully expanded evaluator or an internal theory proof. See the detailed scope
labels in every exploration output.

No repository change is required to use this archive.
