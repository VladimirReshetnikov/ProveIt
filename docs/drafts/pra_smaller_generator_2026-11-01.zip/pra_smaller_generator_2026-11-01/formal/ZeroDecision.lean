/-
  Zero-decidability reconstructs constructor coverage.

  Scope: this file checks a constructive algebraic/logical lemma on an
  arbitrary carrier. It does not formalize a first-order syntax, a PRA
  axiom enumerator, or the full primitive-recursion compiler.

  The induction assumptions are explicitly limited to ONE displayed
  parameter-free equation and ONE fixed family of atomic implications.
  No induction over all Lean predicates or arbitrary functions is assumed.
  The parent axiom theory derives exactly these two instances.
-/

universe u

namespace PrimitiveRecursiveZeroDecision

variable {A : Type u}

def indicator (zero : A) (succ : A → A) (Z : A → A → A) (n : A) : A :=
  Z n (succ zero)

def reconstruction
    (zero : A) (succ : A → A) (Z : A → A → A) (pred : A → A)
    (n : A) : Prop :=
  n = Z (indicator zero succ Z n) (succ (pred n))

/-- Only the single parameter-free equation used in this file. -/
def reconstructionInduction
    (zero : A) (succ : A → A) (Z : A → A → A) (pred : A → A) : Prop :=
  reconstruction zero succ Z pred zero →
  (∀ n, reconstruction zero succ Z pred n →
    reconstruction zero succ Z pred (succ n)) →
  ∀ n, reconstruction zero succ Z pred n

/-- Only the one fixed atomic-implication family used in this file. -/
def atomicProbe (zero : A) (succ : A → A) : Prop :=
  ∀ a,
    (∀ n, (n = a → zero = a) → (succ n = a → zero = a)) →
    ∀ n, n = a → zero = a

theorem successor_ne_zero
    (zero : A) (succ : A → A) (Z : A → A → A)
    (Z_zero : ∀ a, Z zero a = a)
    (Z_succ : ∀ n a, Z (succ n) a = zero)
    (separation : zero ≠ succ zero) :
    ∀ n, succ n ≠ zero := by
  intro n h
  have e : succ zero = zero := by
    calc
      succ zero = Z zero (succ zero) := (Z_zero (succ zero)).symm
      _ = Z (succ n) (succ zero) := congrArg (fun x => Z x (succ zero)) h.symm
      _ = zero := Z_succ n (succ zero)
  exact separation e.symm

theorem prove_reconstruction
    (zero : A) (succ : A → A) (Z : A → A → A) (pred : A → A)
    (Z_zero : ∀ a, Z zero a = a)
    (Z_succ : ∀ n a, Z (succ n) a = zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (eq_ind : reconstructionInduction zero succ Z pred) :
    ∀ n, reconstruction zero succ Z pred n := by
  apply eq_ind
  · change zero = Z (Z zero (succ zero)) (succ (pred zero))
    rw [Z_zero, Z_succ]
  · intro n _ih
    change succ n = Z (Z (succ n) (succ zero)) (succ (pred (succ n)))
    rw [Z_succ, Z_zero, pred_succ]

theorem nonzero_indicator_forces_zero
    (zero : A) (succ : A → A) (Z : A → A → A)
    (Z_succ : ∀ n a, Z (succ n) a = zero)
    (probe : atomicProbe zero succ) :
    ∀ a, indicator zero succ Z a ≠ zero → a = zero := by
  intro a hne
  have progress : ∀ n, (n = a → zero = a) → (succ n = a → zero = a) := by
    intro n _ih hsucc
    have e : indicator zero succ Z a = zero := by
      change Z a (succ zero) = zero
      rw [← hsucc, Z_succ]
    exact False.elim (hne e)
  exact (probe a progress a rfl).symm

theorem zero_decision_implies_coverage
    (zero : A) (succ : A → A) (Z : A → A → A) (pred : A → A)
    (Z_zero : ∀ a, Z zero a = a)
    (Z_succ : ∀ n a, Z (succ n) a = zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (eq_ind : reconstructionInduction zero succ Z pred)
    (probe : atomicProbe zero succ)
    (zero_decision : ∀ a, a = zero ∨ a ≠ zero) :
    ∀ a, a = zero ∨ a = succ (pred a) := by
  have reconstruct := prove_reconstruction zero succ Z pred
    Z_zero Z_succ pred_succ eq_ind
  intro a
  rcases zero_decision (indicator zero succ Z a) with hz | hnz
  · right
    have e := reconstruct a
    change a = Z (indicator zero succ Z a) (succ (pred a)) at e
    rw [hz, Z_zero] at e
    exact e
  · left
    exact nonzero_indicator_forces_zero zero succ Z Z_succ probe a hnz

/-- The direct exceptional schema needs only its fixed progressive instance. -/
theorem obtain_zero_decision
    (zero : A) (succ : A → A)
    (succ_ne_zero : ∀ n, succ n ≠ zero)
    (decision_progression :
      (∀ n, (n = zero ∨ n ≠ zero) →
        (succ n = zero ∨ succ n ≠ zero)) →
      ∀ n, n = zero ∨ n ≠ zero) :
    ∀ n, n = zero ∨ n ≠ zero := by
  apply decision_progression
  intro n _ih
  exact Or.inr (succ_ne_zero n)

/-- The wrapped exception has the old literal-reflexive zero shape. -/
theorem obtain_zero_decision_wrapped
    (zero : A) (succ : A → A)
    (succ_ne_zero : ∀ n, succ n ≠ zero)
    (decision_progression :
      (∀ n,
        ((zero = zero ∨ zero ≠ zero) → (n = zero ∨ n ≠ zero)) →
        ((zero = zero ∨ zero ≠ zero) → (succ n = zero ∨ succ n ≠ zero))) →
      ∀ n, (zero = zero ∨ zero ≠ zero) → (n = zero ∨ n ≠ zero)) :
    ∀ n, n = zero ∨ n ≠ zero := by
  have result := decision_progression (by
    intro n _ih _base
    exact Or.inr (succ_ne_zero n))
  intro n
  exact result n (Or.inl rfl)

#print axioms successor_ne_zero
#print axioms prove_reconstruction
#print axioms nonzero_indicator_forces_zero
#print axioms zero_decision_implies_coverage
#print axioms obtain_zero_decision
#print axioms obtain_zero_decision_wrapped

end PrimitiveRecursiveZeroDecision
