import Std

/-
Logical kernel for deterministic one-root admission.
These theorems concern explicitly supplied predicates and computation
equations. They do NOT encode first-order syntax, the arithmetic bootstrap,
the full axiom generator, or the bi-interpretability theorem.
No classical reasoning is used.
-/

namespace RootComputation

universe u
variable {α : Type u}

theorem stationary_extraction
    (zero : α) (A : Prop)
    (propagate : (∀ _ : α, A → A) → ∀ _ : α, A) : A := by
  exact propagate (fun _ h => h) zero

theorem root_equation_transport
    (lhs rhs other : α) (computation : lhs = rhs) :
    (rhs = other) → (lhs = other) := by
  intro h
  exact computation.trans h

theorem stationary_quantified_base
    (lhs rhs other : α → α) (computation : ∀ b, lhs b = rhs b) :
    (∀ b, rhs b = other b) → ∀ b, lhs b = other b := by
  intro h b
  exact (computation b).trans (h b)

theorem padded_equation_induction
    (zero : α) (succ seedMap : α → α)
    (initialization : ∀ x, seedMap x = x)
    (t s : α → α)
    (propagate :
      (∀ n,
        (t zero = s zero → seedMap (t n) = s n) →
        (t zero = s zero → seedMap (t (succ n)) = s (succ n))) →
      ∀ n, (t zero = s zero → seedMap (t n) = s n))
    (base : t zero = s zero)
    (step : ∀ n, t n = s n → t (succ n) = s (succ n)) :
    ∀ n, t n = s n := by
  have allPadded : ∀ n, t zero = s zero → seedMap (t n) = s n := by
    apply propagate
    intro n ih hzero
    have current : t n = s n :=
      (initialization (t n)).symm.trans (ih hzero)
    exact (initialization (t (succ n))).trans (step n current)
  intro n
  exact (initialization (t n)).symm.trans (allPadded n base)

theorem negative_probe
    (zero : α) (succ seedMap : α → α)
    (initialization : ∀ x, seedMap x = x)
    (a : α)
    (noSuccessor : ∀ n, succ n ≠ a)
    (propagate :
      (∀ n, (n = a → seedMap zero = a) →
        (succ n = a → seedMap zero = a)) →
      ∀ n, (n = a → seedMap zero = a)) :
    zero = a := by
  have allProbe : ∀ n, n = a → seedMap zero = a := by
    apply propagate
    intro n _ impossible
    exact False.elim (noSuccessor n impossible)
  exact (initialization zero).symm.trans (allProbe a rfl)

theorem two_name_stationary
    (F : α → α → Prop) (a : α)
    (endpoint : ∀ b, (∀ n, F a n → F a n) → F a b) :
    ∀ b, F a b := by
  intro b
  exact endpoint b (fun _ h => h)

theorem two_name_moving
    (succ : α → α) (F : α → α → Prop) (a : α)
    (endpoint : ∀ b, (∀ n, F n a → F (succ n) a) → F b a) :
    (∀ n, F n a → F (succ n) a) → ∀ n, F n a := by
  intro h n
  exact endpoint n h

theorem direct_or_wrapped_decision
    (zero : α) (D : α → Prop) (base : D zero) :
    (∀ n, D n) ↔ (∀ n, D zero → D n) := by
  constructor
  · intro allD n _
    exact allD n
  · intro allWrapped n
    exact allWrapped n base

#print axioms stationary_extraction
#print axioms root_equation_transport
#print axioms stationary_quantified_base
#print axioms padded_equation_induction
#print axioms negative_probe
#print axioms two_name_stationary
#print axioms two_name_moving
#print axioms direct_or_wrapped_decision

end RootComputation
