#!/usr/bin/env python3
"""Exact arithmetic verification of sufficient certificates, plus finite audits.

Requires only Python 3 standard library. All comparisons use integers or Fraction.
The finite audits are checks, not the proof of the general theorems.
"""
from fractions import Fraction as Q
from itertools import combinations
from functools import lru_cache, reduce
import random

ROWS = [
    (2, None, 2, Q(3,20), Q(1,2)),
    (3, 14, 13, Q(1,53), Q(54,100)),
    (4, 40, 39, Q(1,213), Q(67,100)),
    (5, 100, 98, Q(1,549), Q(52,100)),
    (6, 237, 233, Q(1,1518), Q(54,100)),
    (7, 541, 533, Q(1,3882), Q(52,100)),
    (8, 1206, 1192, Q(1,9868), Q(53,100)),
]

def bounds(r,d,t):
    k=r-1; q=1-Q(1,2**k); g=1-k*t
    assert 0<t<Q(1,r)
    assert q**d/2<=t*g**(d-1)
    u=(q/g)**(d-1)
    z1=q**(d-1)/(2*g**d)
    z2=Q(1,2**k)*q**(d-1)/g**(1+k*(d-1))
    B=k*u+k*(d-1)*min(z1,z2)
    L=r*max(Q(0),1-B)
    return L/(1+L),1-Q(1,2**r)/((1-r*t)*g**(r*(d-1)))

print('Exact rational threshold checks:')
for r,old,d,t,target in ROWS:
    q=1-Q(1,2**(r-1))
    assert d-1>=q/(1-q)
    delete,direct=bounds(r,d,t)
    assert (direct if r==2 else delete)>target
    print(f'r={r}, old={old}, d0={d}, t={t}: deletion={float(delete):.9f}, direct={float(direct):.9f}; strict target {target} certified')
    # Sample propagation independently, in addition to its general proof.
    for dd in (d+1,d+5):
        de,di=bounds(r,dd,t*Q(d-1,dd-1))
        assert de>=delete and di>=direct

# Displayed exact example inequalities.
q=Q(3,4);g=Q(51,53)
assert 2*Q(53,68)**12+24*q**12/(4*g**25)<Q(3,5)
assert Q(7,10)*Q(17,20)**2==Q(2023,4000)>Q(1,2)
# Nonlinear block example.
a=Q(3,32); H=5*a+a*Q(6,17)**2
assert 6*a<1 and 1-Q(1,4)/(1-H)>Q(51,100)
assert 1-Q(1,8)/(1-H)>Q(75,100)
assert a>Q(1,5)*Q(4,5)**4
print('Nonlinear block strict targets and impossibility of old product certificate: certified.')


def bits(mask):
    while mask:
        b=mask & -mask; yield b.bit_length()-1; mask ^= b

def subsets(mask):
    s=mask
    while True:
        yield s
        if not s: break
        s=(s-1)&mask

def model(n,edges):
    V=(1<<n)-1
    edge_unions={0}
    for e in edges: edge_unions |= {s|e for s in edge_unions}
    generators=[sum(1<<i for i,e in enumerate(edges) if e>>v&1) for v in range(n)]
    original={0}
    for b in generators: original |= {s|b for s in original}
    assert len(edge_unions)==len(original)
    for U in original:
        T=sum(1<<v for v,b in enumerate(generators) if b&~U)
        assert T in edge_unions
        assert all(bool(U>>i&1)==bool(e&~T) for i,e in enumerate(edges))
    failures=[]
    adj=[0]*n
    for e in edges:
        for v in bits(e): adj[v]|=e&~(1<<v)
    for Y in range(1<<n):
        covered=0
        for e in edges:
            if not e&~Y: covered|=e
        failures.append(Y&~covered)
        assert (not failures[-1])==(Y in edge_unions)
    for e in edges:
        full=[T for T in edge_unions if not e&~T]
        succ=sum((T&~(1<<v)) in edge_unions for T in full for v in bits(e))
        assert succ<=len(edge_unions)-len(full)
    return edge_unions, failures, adj


def polynomial_audit(n,edges):
    """Check exact lopsided and Shearer ratio inequalities on all induced sets,
    for the unpinned law and for each support edge pinned to one, when Q>0.
    Uses a separate recursive independence polynomial and exhaustive counts.
    """
    unions,fail,adj=model(n,edges); V=(1<<n)-1
    p=[Q(sum(bool(f>>v&1) for f in fail),1<<n) for v in range(n)]
    @lru_cache(None)
    def poly(S):
        if not S:return Q(1)
        v=next(bits(S));rest=S&~(1<<v)
        return poly(rest)-p[v]*poly(rest&~adj[v])
    # Check polynomial directly via independent sets for small n.
    for S in subsets(V):
        total=Q(0)
        for J in subsets(S):
            if any(adj[v]&J for v in bits(J)):continue
            term=Q((-1)**J.bit_count())
            for v in bits(J):term*=p[v]
            total+=term
        assert poly(S)==total
    if not all(poly(S)>0 for S in subsets(V)):return 0,0
    tested=0; lop=0
    for E in [0]+list(edges):
        I=V&~E
        eligible=[f for Y,f in enumerate(fail) if Y&E==E]
        counts={S:sum(not f&S for f in eligible) for S in subsets(I)}
        assert all(counts.values())
        for S in subsets(I):
            for v in bits(S):
                R=S&~(1<<v)
                assert Q(counts[S],counts[R])>=poly(S)/poly(R)
                tested+=1
            for v in bits(I&~S):
                if not adj[v]&S:
                    numerator=sum(bool(f>>v&1) and not f&S for f in eligible)
                    assert Q(numerator,counts[S])<=p[v]
                    lop+=1
    return tested,lop

# All graphs through 5 vertices and seeded hypergraphs through 8 vertices.
count=0
for n in range(1,6):
    options=[(1<<i)|(1<<j) for i,j in combinations(range(n),2)]
    for mask in range(1<<len(options)):
        model(n,[e for i,e in enumerate(options) if mask>>i&1]);count+=1
rng=random.Random(20261125)
for i in range(100):
    n=rng.randint(3,8); edges=sorted(set(rng.sample(range(1,1<<n),rng.randint(1,min(18,(1<<n)-1)))))
    model(n,edges);count+=1
print(f'Distinct-union bijections and single-deletion inequalities: {count} finite hypergraphs checked.')

ratio=lop=0
cases=[]
for n in range(3,8):
    cases.append((n,[(1<<i)|(1<<((i+1)%n)) for i in range(n)]))
    cases.append((n,[(1<<i)|(1<<j) for i,j in combinations(range(n),2)]))
for n in range(5,8):
    cases.append((n,[sum(1<<v for v in e) for e in combinations(range(n),3)]))
for n,edges in cases:
    rr,ll=polynomial_audit(n,edges);ratio+=rr;lop+=ll
assert ratio>0 and lop>0
print(f'Exact Shearer ratio tests: {ratio}; simultaneous lopsided conditioning tests: {lop}.')

# Independently check all clique-message polynomial ratios on small models.
clique_tests=0
for n,edges in cases:
    V=(1<<n)-1
    _,fail,adj=model(n,edges)
    p=[Q(sum(bool(f>>v&1) for f in fail),1<<n) for v in range(n)]
    covers=[edges,[V]] if all(adj[v]==V&~(1<<v) for v in range(n)) else [edges]
    for cliques in covers:
        # Use either one complete clique or uniform rational messages found by
        # a small deterministic exact search. No optimization claim.
        for h in [Q(j,100) for j in range(1,40)]:
            if any(len(list(bits(C)))*h>=1 for C in cliques):continue
            if not all(p[v]<=h*reduce(lambda a,b:a*b,(1-(C.bit_count()-1)*h for C in cliques if C>>v&1 and C!=D),Q(1)) for D in cliques for v in bits(D)):continue
            @lru_cache(None)
            def poly(S):
                if not S:return Q(1)
                v=next(bits(S));R=S&~(1<<v)
                return poly(R)-p[v]*poly(R&~adj[v])
            for S in subsets(V):
                assert poly(S)>0
                for C in cliques:
                    assert poly(S)/poly(S&~C)>=1-(S&C).bit_count()*h
                    clique_tests+=1
            break
assert clique_tests>0
print(f'Clique-message polynomial ratio tests: {clique_tests}.')

# Test pointwise abundance on the first
# block star for which the simple separation argument applies (16 vertices).
M=3;n=1+5*M
blocks=[1|sum(1<<j for j in range(1+5*i,6+5*i)) for i in range(M)]
edges=[sum(1<<v for v in e) for C in blocks for e in combinations(list(bits(C)),3)]
# Enumerate the 65536 subsets directly, not via an astronomical list of edge selections.
good=[]
for Y in range(1<<n):
    covered=0
    for e in edges:
        if not e&~Y:covered|=e
    if covered==Y:good.append(Y)
for e in edges:
    absence=sum(not e&~Y for Y in good)
    assert 1-Q(absence,len(good))>(Q(51,100) if e&1 else Q(75,100))
print(f'3-block star: {len(good)} distinct edge unions, {len(edges)} supports, exact frequencies pass.')
print('All checks passed. Decimals printed for readability only; no floating-point test used.')
