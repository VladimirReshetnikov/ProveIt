# Clique messages and deletion certificates for union-closed families

Research note, 25 November 2026. **Restricted theorem, not a proof of Frankl's conjecture.**

## Files
- `paper.tex`: complete self-contained mathematical argument, statements, examples and bibliography.
- `paper.pdf`: compiled paper.
- `verify.py`: Python 3 standard-library-only exact arithmetic and small-model checks.
- `verification.txt`: recorded output of the executed checks.

## Reproduce

```sh
python3 verify.py
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

The proof is analytical. The checker verifies rational witnesses and provides bounded regression tests; it is not a formal proof assistant. The printed decimal values are for readability only.

## Provenance and novelty

The GitHub connector was used to enumerate `VladimirReshetnikov/ProveIt`, `main`, `docs/drafts`, and to read the TeX of `union_closed_lopsided_certificates_2026-11-25.zip` in full. The other nine selected archive abstracts/section headings were read for overlap. The direct predecessor's section on open questions asks for a stronger local-lemma argument lowering the rank-three threshold. This note answers that question by a directed clique-message polynomial recursion and a new deletion-counting target. See the bibliography and discussion in the paper. The general Shearer and cluster-expansion tools are prior art. No comprehensive priority search or independent peer review was performed. No repository changes were made.

The regular rank-three through rank-eight thresholds improve the explicit sufficient thresholds in that prior draft, not necessarily all possible or published thresholds. The nonlinear block example separates the new certificate from the preceding asymmetric product test, not from all possible proofs. No unrestricted numerical frequency improvement is claimed.
