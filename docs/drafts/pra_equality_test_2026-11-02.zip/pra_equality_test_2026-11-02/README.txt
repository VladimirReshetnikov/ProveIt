PRIMITIVE RECURSIVE ARITHMETIC WITH EXPLICIT EQUALITY TESTS
Research package for Vladimir Reshetnikov
November 2, 2026

START HERE
  report.pdf  Complete research report.
  AXIOMS.txt  Exact recommended equality-mask specification.
  report.tex  Main LaTeX source; sections/ contains the complete proof.

RESULT
The recommended ordinary first-order theory adds one binary equality
mask Delta and one fixed axiom:

  forall x forall y (x=y OR Delta(x,y)=0).

It uses the current counter-recursion language and a shorter one-term
mask propagation schema. That schema itself derives the omitted diagonal
law Delta(x,x)=x. The complete theory has a common conservative
definitional extension with first-order PRA, with full-carrier
interpretations and identity round trips. The result works separately
in classical and intuitionistic logic.

The report also gives an equality-bit version with ordinary zero-term
induction, and a classical equality-conditional logical-language version
having one nonlogical schema.

For a single schema in ordinary first-order logic, the equivalent fused
mask version M* incorporates the fixed axiom under the existing outer
quantifiers. Its size is 45 + 4m + 3i. See AXIOMS.txt and Section 5.6.

HONEST COMPARISON
The current counter-recursion draft has recurring size
  35 + 7m + 4i + 3j.
The recommended mask schema has recurring size
  35 + 4m + 3i,
plus an 11-node fixed axiom and one added binary primitive.
Thus the recurring saving is 3m + i + 3j on common input syntax.
The report states all conventions and tradeoffs. It does NOT prove an
absolute shortestness theorem or a reduction in the original test-free
signature.

NEGATIVE RESULTS
Deleting the equality test admits explicit extra-chain countermodels.
Their finite-order automorphisms exclude bi-interpretability with PRA.
The general proofs are in the report; the Python checker supplies
finite diagnostic examples, not a substitute for those proofs.

REPRODUCTION
Requirements: Python 3.10+ standard library and a normal TeX Live
installation with pdflatex, amsmath, amsthm, lmodern, geometry, microtype,
booktabs, tabularx, fancyhdr, enumitem, hyperref, and cleveref.

  python3 build.py

The build uses no network. It runs both diagnostic checkers and three
LaTeX passes. Logs and JSON results are written under audit/ and checks/.
Visual layout review is separate from compilation.

VERIFICATION SCOPE
No complete Lean/Rocq mechanization is claimed. The main mathematical
theorems have written proofs. AST checks verify explicit sizes, binding,
frozen descriptors, and simultaneous substitution. Countermodel checks
verify finite samples of the infinite construction.

PROVENANCE
All six current source archives were read at ProveIt commit
5ffc596c844086fc26509685c7833b548ebf25c3.
audit/source_manifest.json records exact Git blob hashes, SHA-256 hashes,
URLs, sizes, and verification status. The inherited counter-recursion,
pairing, and PR compilation methods are attributed in the report.

CONTENTS
  report.tex, report.pdf
  sections/*.tex
  AXIOMS.txt
  checks/check_schema.py, checks/check_countermodel.py
  checks/*results.json, checks/schema_examples.txt
  checks/COUNTERMODEL_SCOPE.txt
  audit/source_manifest.json, audit/comparison_notes.txt
  audit/*logs, audit/build_results.json, audit/pdf_review.json
  build.py, SHA256SUMS.txt
