#!/usr/bin/env python3
"""Finite diagnostics for the orphan-chain countermodel.

The mathematical construction has infinitely many labels and unbounded
heights. No operation is truncated here. The checker samples finitely many
inputs of that infinite construction. It is not a proof of the general
countermodel theorem, an axiom checker for all instances, or a formal
verification of bi-interpretability.

Run with Python 3.10 or later. Only the standard library is used.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True, order=True)
class Element:
    height: int
    label: int = 0

    def __post_init__(self) -> None:
        if self.height < 0 or self.label < 0:
            raise ValueError("Heights and labels must be nonnegative")
        if self.height == 0 and self.label != 0:
            raise ValueError("The zero fiber has exactly one element")

    def json(self) -> dict[str, int]:
        return {"height": self.height, "label": self.label}


ZERO = Element(0)
ONE = Element(1)


def successor(value: Element) -> Element:
    return Element(value.height + 1, value.label)


def swap(value: Element) -> Element:
    label = {1: 2, 2: 1}.get(value.label, value.label)
    return Element(value.height, label)


# Terms are finite immutable trees. A Rec node stores its body, followed
# by its two active arguments. The body is frozen under active substitution.
Term = tuple
Z: Term = ("zero",)
X: Term = ("var", 0)
Y: Term = ("var", 1)


def s(term: Term) -> Term:
    return ("succ", term)


def rec(body: Term, counter: Term, seed: Term) -> Term:
    return ("rec", body, counter, seed)


def delta(left: Term, right: Term) -> Term:
    return ("delta", left, right)


def q(counter: Term, seed: Term) -> Term:
    return rec(Y, counter, seed)


def z(counter: Term, seed: Term) -> Term:
    return rec(Z, counter, seed)


def pred(term: Term) -> Term:
    return q(term, Z)


def case(term: Term, zero_branch: Term, positive_branch: Term) -> Term:
    return q(z(term, s(zero_branch)), z(z(term, s(Z)), positive_branch))


@lru_cache(maxsize=500_000)
def evaluate(term: Term, left: Element, right: Element) -> Element:
    tag = term[0]
    if tag == "zero":
        return ZERO
    if tag == "var":
        return (left, right)[term[1]]
    if tag == "succ":
        return successor(evaluate(term[1], left, right))
    if tag == "delta":
        first = evaluate(term[1], left, right)
        second = evaluate(term[2], left, right)
        return ZERO if first == second else ONE
    if tag == "rec":
        body, counter_term, seed_term = term[1:]
        counter = evaluate(counter_term, left, right)
        state = evaluate(seed_term, left, right)
        # At every height-one root the previous counter is the unique zero.
        # At later heights the previous counter keeps the root's label.
        for height in range(counter.height):
            previous = ZERO if height == 0 else Element(height, counter.label)
            state = evaluate(body, state, previous)
        return state
    raise ValueError(f"Unknown term constructor: {tag}")


@lru_cache(maxsize=500_000)
def evaluate_nat(term: Term, left: int, right: int) -> int:
    tag = term[0]
    if tag == "zero":
        return 0
    if tag == "var":
        return (left, right)[term[1]]
    if tag == "succ":
        return evaluate_nat(term[1], left, right) + 1
    if tag == "delta":
        return int(
            evaluate_nat(term[1], left, right)
            != evaluate_nat(term[2], left, right)
        )
    if tag == "rec":
        body, counter_term, seed_term = term[1:]
        counter = evaluate_nat(counter_term, left, right)
        state = evaluate_nat(seed_term, left, right)
        for previous in range(counter):
            state = evaluate_nat(body, state, previous)
        return state
    raise ValueError(f"Unknown term constructor: {tag}")


def descriptor_rank(term: Term) -> int:
    tag = term[0]
    if tag in {"zero", "var"}:
        return 0
    if tag == "succ":
        return descriptor_rank(term[1])
    if tag == "delta":
        return max(descriptor_rank(term[1]), descriptor_rank(term[2]))
    body, counter, seed = term[1:]
    return max(
        descriptor_rank(body) + 1,
        descriptor_rank(counter),
        descriptor_rank(seed),
    )


def all_bodies(term: Term) -> set[Term]:
    tag = term[0]
    if tag in {"zero", "var"}:
        return set()
    if tag == "succ":
        return all_bodies(term[1])
    if tag == "delta":
        return all_bodies(term[1]) | all_bodies(term[2])
    body, counter, seed = term[1:]
    return {body} | all_bodies(body) | all_bodies(counter) | all_bodies(seed)


def sample_terms() -> list[Term]:
    """A deterministic catalog including genuinely nested descriptors.

    Updates are chosen to keep the finite diagnostic inexpensive; their
    values and loop lengths are not truncated or taken modulo a bound.
    """
    atoms = [Z, X, Y, s(Z), s(X), s(Y)]
    bodies = [
        Z,
        X,
        Y,
        s(X),
        s(Y),
        s(s(X)),
        pred(X),
        pred(Y),
        z(X, s(Z)),
        z(Y, X),
        q(X, Y),
        q(Y, X),
        z(pred(X), s(Z)),
        rec(z(X, s(Z)), X, Z),
    ]
    catalog: set[Term] = set(atoms)
    for body in bodies:
        for counter in (Z, X, Y, s(X)):
            for seed in (Z, X, Y):
                catalog.add(rec(body, counter, seed))
    catalog.update(
        {
            case(X, Y, Z),
            case(X, s(Y), pred(Y)),
            q(z(X, s(Y)), z(z(X, s(Z)), Y)),
            rec(s(X), pred(Y), z(X, Y)),
            rec(pred(X), q(Y, X), s(Y)),
            rec(rec(z(X, s(Z)), X, Z), X, Y),
        }
    )
    rng = random.Random(20261102)
    simple = sorted(catalog, key=repr)
    for _ in range(80):
        # Nested active arguments as well as frozen nested descriptors.
        body = rng.choice(bodies[:4] + bodies[6:])
        counter = rng.choice(atoms + [pred(X), pred(Y), z(X, Y)])
        seed = rng.choice(simple)
        catalog.add(rec(body, counter, seed))
    return sorted(catalog, key=repr)


def elements(max_height: int) -> list[Element]:
    return [ZERO] + [
        Element(height, label)
        for height in range(1, max_height + 1)
        for label in range(3)
    ]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def run(max_height: int) -> dict:
    if not 1 <= max_height <= 8:
        raise ValueError("Choose a diagnostic height between 1 and 8")
    inputs = elements(max_height)
    terms = sample_terms()
    bodies = sorted(set().union(*(all_bodies(t) for t in terms)), key=repr)
    counts = {
        "base_equations": 0,
        "step_equations": 0,
        "projection_homomorphism": 0,
        "automorphism_equivariance": 0,
        "singleton_zero_fiber_reflection": 0,
        "rooted_zero_instances_with_true_sampled_premise": 0,
        "rooted_zero_instances_with_false_sampled_premise": 0,
    }

    for body in bodies:
        operation = rec(body, X, Y)
        for seed in inputs:
            require(evaluate(operation, ZERO, seed) == seed, "Base equation")
            counts["base_equations"] += 1
            for counter in inputs:
                state = evaluate(operation, counter, seed)
                result = evaluate(operation, successor(counter), seed)
                update = evaluate(body, state, counter)
                require(result == update, "Step equation")
                counts["step_equations"] += 1

    for term in terms:
        for left in inputs:
            for right in inputs:
                value = evaluate(term, left, right)
                projected = evaluate_nat(term, left.height, right.height)
                require(value.height == projected, "Projection homomorphism")
                counts["projection_homomorphism"] += 1
                moved = evaluate(term, swap(left), swap(right))
                require(moved == swap(value), "Automorphism equivariance")
                counts["automorphism_equivariance"] += 1
                require((value == ZERO) == (projected == 0), "Zero reflection")
                counts["singleton_zero_fiber_reflection"] += 1

        for parameter in inputs:
            premise = all(
                not (counter == ZERO or evaluate(term, counter, parameter) == ZERO)
                or evaluate(term, successor(counter), parameter) == ZERO
                for counter in inputs
            )
            if premise:
                # The sampled progress premise includes height max_height,
                # so the conclusion also checks its successor frontier.
                conclusion_inputs = elements(max_height + 1)
                require(
                    all(
                        counter == ZERO
                        or evaluate(term, counter, parameter) == ZERO
                        for counter in conclusion_inputs
                    ),
                    "Sampled rooted-zero propagation",
                )
                counts["rooted_zero_instances_with_true_sampled_premise"] += 1
            else:
                counts["rooted_zero_instances_with_false_sampled_premise"] += 1

    orphan = Element(1, 1)
    orphan_predecessor = evaluate(pred(X), orphan, ZERO)
    reconstruction = successor(orphan_predecessor)
    require(orphan != ZERO and orphan != reconstruction, "Coverage failure")
    require(swap(orphan) != orphan and swap(swap(orphan)) == orphan,
            "Nonidentity involution")

    # This term uses the NEW logical equality test, interpreted by exact
    # native equality in M. Its pure-recursor subterm C is the direct selector.
    witness = delta(case(X, Z, s(pred(X))), X)
    require(evaluate(witness, ZERO, ZERO) == ZERO, "Witness base")
    for counter in inputs:
        require(evaluate(witness, successor(counter), ZERO) == ZERO,
                "Witness unconditional successor equation")
    require(evaluate(witness, orphan, ZERO) == ONE, "Witness orphan value")
    require(evaluate_nat(witness, orphan.height, 0) == 0,
            "Witness projected standard value")

    serialized = json.dumps(terms, separators=(",", ":"))
    return {
        "status": "passed",
        "scope": (
            "Finite diagnostics for an infinite mathematical construction; "
            "no finite truncation of the operations and no proof claim."
        ),
        "python_requirement": "Python 3.10+, standard library only",
        "input_max_height": max_height,
        "input_labels": [0, 1, 2],
        "sampled_elements": len(inputs),
        "sampled_terms": len(terms),
        "distinct_stored_bodies": len(bodies),
        "maximum_descriptor_rank": max(map(descriptor_rank, terms)),
        "sample_catalog_sha256": hashlib.sha256(serialized.encode()).hexdigest(),
        "checks": counts,
        "coverage_counterexample": {
            "orphan": orphan.json(),
            "predecessor": orphan_predecessor.json(),
            "successor_of_predecessor": reconstruction.json(),
            "coverage_holds": False,
        },
        "automorphism": {
            "description": "Swap labels 1 and 2; fix label 0 and the unique zero",
            "orphan_image": swap(orphan).json(),
            "order": 2,
        },
        "native_delta_witness": {
            "term": "delta(C(n,0,S(p(n))),n)",
            "delta_convention": "0 for native equality, canonical 1 otherwise",
            "base_value": evaluate(witness, ZERO, ZERO).json(),
            "all_sampled_successor_values_are_zero": True,
            "orphan_value": evaluate(witness, orphan, ZERO).json(),
            "projected_standard_value": evaluate_nat(witness, 1, 0),
            "ordinary_zero_induction_fails": True,
            "rooted_zero_propagation_fails": True,
            "projection_is_delta_homomorphism": False,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--height", type=int, default=4)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_name("countermodel_results.json"),
    )
    args = parser.parse_args()
    result = run(args.height)
    text = json.dumps(result, indent=2, sort_keys=True) + "\n"
    args.output.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
