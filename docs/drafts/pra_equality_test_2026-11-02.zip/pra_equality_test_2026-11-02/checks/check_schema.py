#!/usr/bin/env python3
"""Check finite axiom syntax and exact tree-size claims, with no dependencies.

Run: python3 checks/check_schema.py

This diagnostic builds finite terms/formulas, expands the schema substitutions,
and checks their node counts, free variables, quantifier scopes, and frozen
descriptors. It is NOT a proof checker for PRA, induction completeness, or
bi-interpretability. The mathematical proofs are in the accompanying report.

Each active variable, constant, function application, connective, equality,
quantifier and falsity occurrence costs one node. A native If(s=t,r,q) costs
one If node plus one equality-condition node and its four term subtrees.
Descriptor bodies are either omitted (active size) or recursively charged at
EVERY occurrence of their recursor symbol (expanded-descriptor size).
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
import random
from typing import Dict, FrozenSet, Optional, Tuple, Union


SEED = 20261102
CORPUS_SIZE = 900
OUTPUT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Body:
    kind: str
    term: "Term"


@dataclass(frozen=True)
class App:
    symbol: str
    args: Tuple["Term", ...] = ()
    body: Optional[Body] = None


Term = Union[Var, App]


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple = ()


ZERO = App("0")
N = Var("n")
A = Var("a")
V = Var("v")
W = Var("w")
X = Var("x")
Y = Var("y")


def successor(term: Term) -> Term:
    return App("S", (term,))


ONE = successor(ZERO)


def delta(left: Term, right: Term) -> Term:
    return App("delta", (left, right))


def mask(left: Term, right: Term) -> Term:
    return App("Delta", (left, right))


def conditional(left: Term, right: Term, yes: Term, no: Term) -> Term:
    return App("If", (left, right, yes, no))


def recursor(body: Body, counter: Term, seed: Term) -> Term:
    return App(body.kind, (counter, seed), body)


def equal(left: Term, right: Term) -> Formula:
    return Formula("=", (left, right))


def conjunction(left: Formula, right: Formula) -> Formula:
    return Formula("and", (left, right))


def disjunction(left: Formula, right: Formula) -> Formula:
    return Formula("or", (left, right))


def implies(left: Formula, right: Formula) -> Formula:
    return Formula("implies", (left, right))


def forall(name: str, formula: Formula) -> Formula:
    return Formula("forall", (name, formula))


BOTTOM = Formula("false")
SEPARATION = implies(equal(ZERO, ONE), BOTTOM)


@lru_cache(maxsize=None)
def active_size(term: Term) -> int:
    if isinstance(term, Var):
        return 1
    extra = 2 if term.symbol == "If" else 1
    return extra + sum(active_size(arg) for arg in term.args)


@lru_cache(maxsize=None)
def expanded_size(term: Term) -> int:
    if isinstance(term, Var):
        return 1
    extra = 2 if term.symbol == "If" else 1
    if term.body is not None:
        extra += expanded_size(term.body.term)
    return extra + sum(expanded_size(arg) for arg in term.args)


@lru_cache(maxsize=None)
def free_variables(term: Term) -> FrozenSet[str]:
    if isinstance(term, Var):
        return frozenset((term.name,))
    result: FrozenSet[str] = frozenset()
    for arg in term.args:
        result |= free_variables(arg)
    return result


@lru_cache(maxsize=None)
def occurrences(term: Term, name: str) -> int:
    if isinstance(term, Var):
        return int(term.name == name)
    return sum(occurrences(arg, name) for arg in term.args)


@lru_cache(maxsize=None)
def descriptor_rank(term: Term) -> int:
    if isinstance(term, Var):
        return 0
    ranks = [descriptor_rank(arg) for arg in term.args]
    if term.body is not None:
        ranks.append(1 + descriptor_rank(term.body.term))
    return max(ranks, default=0)


def substitute(term: Term, mapping: Dict[str, Term]) -> Term:
    """Simultaneous active substitution; inserted terms are not revisited."""
    if isinstance(term, Var):
        return mapping.get(term.name, term)
    return App(
        term.symbol,
        tuple(substitute(arg, mapping) for arg in term.args),
        term.body,  # The stored descriptor is deliberately frozen.
    )


@lru_cache(maxsize=None)
def rename_primitive(term: Term, old: str, new: str) -> Term:
    """Whole-signature renaming, deliberately distinct from active substitution."""
    if isinstance(term, Var):
        return term
    renamed_body = None if term.body is None else Body(
        term.body.kind, rename_primitive(term.body.term, old, new)
    )
    return App(
        new if term.symbol == old else term.symbol,
        tuple(rename_primitive(arg, old, new) for arg in term.args),
        renamed_body,
    )


def validate_term(term: Term, variables: FrozenSet[str], grammar: str) -> None:
    """Check the effective finite descriptor grammar, not numerical meaning."""
    if isinstance(term, Var):
        assert term.name in variables, (term.name, variables)
        return
    allowed = {"0": 0, "S": 1}
    recursor_kind = "D" if grammar == "delayed" else "R"
    allowed[recursor_kind] = 2
    if grammar == "delta":
        allowed["delta"] = 2
    if grammar == "mask":
        allowed["Delta"] = 2
    if grammar == "conditional":
        allowed["If"] = 4
    assert term.symbol in allowed, (term.symbol, grammar)
    assert len(term.args) == allowed[term.symbol]
    for arg in term.args:
        validate_term(arg, variables, grammar)
    if term.symbol == recursor_kind:
        assert term.body is not None and term.body.kind == recursor_kind
        slots = frozenset(("v",)) if recursor_kind == "D" else frozenset(("v", "w"))
        validate_term(term.body.term, slots, grammar)
        # Descriptors are finite immutable trees, not mutable named links.
        # Their symbol rank is one greater than the largest body-symbol rank.
    else:
        assert term.body is None


def validate_formula(formula: Formula, grammar: str) -> None:
    if formula.tag == "=":
        for term in formula.args:
            validate_term(term, frozenset(("n", "a", "x", "y")), grammar)
    elif formula.tag == "false":
        assert not formula.args
    elif formula.tag == "forall":
        name, body = formula.args
        assert name in {"n", "a", "x", "y"}
        validate_formula(body, grammar)
    else:
        assert formula.tag in {"and", "or", "implies"}
        assert len(formula.args) == 2
        for item in formula.args:
            validate_formula(item, grammar)


def formula_size(formula: Formula, expanded: bool = False) -> int:
    term_size = expanded_size if expanded else active_size
    if formula.tag == "=":
        return 1 + sum(term_size(term) for term in formula.args)
    if formula.tag == "false":
        return 1
    if formula.tag == "forall":
        return 1 + formula_size(formula.args[1], expanded)
    return 1 + sum(formula_size(item, expanded) for item in formula.args)


def scope_audit(formula: Formula) -> dict:
    """Resolve active variable occurrences to binders, including shadowing."""
    unbound = set()
    names = set()
    counters = Counter()
    maximum_depth = 0
    next_binder = 0
    binder_uses = Counter()

    def visit_term(term: Term, environment: dict) -> None:
        if isinstance(term, Var):
            names.add(term.name)
            if term.name not in environment:
                unbound.add(term.name)
            else:
                binder_uses[environment[term.name]] += 1
        else:
            for arg in term.args:
                visit_term(arg, environment)

    def visit(node: Formula, environment: dict, depth: int) -> None:
        nonlocal maximum_depth, next_binder
        counters[node.tag] += 1
        if node.tag == "=":
            for term in node.args:
                visit_term(term, environment)
        elif node.tag == "forall":
            name, body = node.args
            if name in environment:
                counters["shadowing_binders"] += 1
            copied = dict(environment)
            copied[name] = next_binder
            next_binder += 1
            maximum_depth = max(maximum_depth, depth + 1)
            visit(body, copied, depth + 1)
        elif node.tag != "false":
            for child in node.args:
                visit(child, environment, depth)

    visit(formula, {}, 0)
    return {
        "unbound_variables": sorted(unbound),
        "active_variable_names": sorted(names),
        "quantifier_occurrences": counters["forall"],
        "quantifier_depth": maximum_depth,
        "shadowing_binders": counters["shadowing_binders"],
        "binder_use_counts": [binder_uses[index] for index in range(next_binder)],
        "formula_connective_counts": dict(sorted(counters.items())),
    }


def profile(term: Term) -> dict:
    return {
        "m": active_size(term),
        "i": occurrences(term, "n"),
        "j": occurrences(term, "a"),
        "W": expanded_size(term),
        "descriptor_rank": descriptor_rank(term),
    }


def adjacent_parts(term: Term) -> Tuple[Formula, Formula, Formula]:
    adjacent = equal(term, substitute(term, {"a": successor(A)}))
    at_successor = equal(
        substitute(term, {"n": successor(N)}),
        substitute(term, {"n": successor(N), "a": successor(A)}),
    )
    rooted = disjunction(equal(N, ZERO), adjacent)
    progress = forall("n", implies(rooted, at_successor))
    return adjacent, rooted, progress


def counter_payload(term: Term) -> Formula:
    body = Body("R", substitute(term, {"n": V, "a": W}))
    base = equal(recursor(body, ZERO, A), A)
    step = equal(
        recursor(body, successor(N), A),
        substitute(term, {"n": recursor(body, N, A), "a": N}),
    )
    return conjunction(SEPARATION, conjunction(base, step))


def old_counter_schema(term: Term) -> Formula:
    _, rooted, progress = adjacent_parts(term)
    return forall(
        "a", forall("n", conjunction(counter_payload(term), implies(progress, rooted)))
    )


def shared_zero_schema(term: Term) -> Formula:
    body = Body("D", substitute(term, {"n": V, "a": ZERO}))
    probe = Body("D", ONE)
    adjacent, _, progress = adjacent_parts(term)
    reset = equal(recursor(body, recursor(probe, N, ZERO), A), A)
    middle = equal(
        recursor(body, successor(N), A),
        substitute(term, {"n": recursor(body, N, A), "a": ZERO}),
    )
    conclusion = conjunction(
        SEPARATION,
        conjunction(
            reset, disjunction(equal(N, ZERO), conjunction(adjacent, middle))
        ),
    )
    return forall("a", implies(progress, forall("n", conclusion)))


def zero_counter_schema(term: Term) -> Formula:
    base = equal(substitute(term, {"n": ZERO}), ZERO)
    equation = equal(term, ZERO)
    step = forall(
        "n", implies(equation, equal(substitute(term, {"n": successor(N)}), ZERO))
    )
    induction = implies(conjunction(base, step), equation)
    return forall("a", forall("n", conjunction(counter_payload(term), induction)))


def mask_counter_schema(term: Term) -> Formula:
    rooted = equal(mask(N, term), N)
    step = equal(substitute(term, {"n": successor(N)}), successor(N))
    progress = forall("n", implies(rooted, step))
    return forall(
        "a", forall("n", conjunction(counter_payload(term), implies(progress, rooted)))
    )


def equality_bit_axiom() -> Formula:
    return forall(
        "x", forall(
            "y", conjunction(
                equal(delta(X, X), ZERO),
                disjunction(equal(X, Y), equal(delta(X, Y), ONE)),
            )
        )
    )


def equality_mask_axiom() -> Formula:
    return forall(
        "x", forall(
            "y", conjunction(
                equal(mask(X, X), X),
                disjunction(equal(X, Y), equal(mask(X, Y), ZERO)),
            )
        )
    )


def off_diagonal_axiom() -> Formula:
    return forall(
        "x", forall("y", disjunction(equal(X, Y), equal(mask(X, Y), ZERO)))
    )


def initial_terms(grammar: str) -> list:
    terms = [ZERO, N, A, ONE, successor(N), successor(A)]
    kind = "D" if grammar == "delayed" else "R"
    bodies = [ZERO, V, successor(V), ONE]
    if kind == "R":
        bodies.append(W)
    for body in bodies:
        terms.append(recursor(Body(kind, body), N, A))
        terms.append(recursor(Body(kind, body), N, N))
    nested = recursor(Body(kind, successor(V)), V, ZERO)
    terms.append(recursor(Body(kind, nested), N, A))
    if grammar == "delta":
        terms += [delta(N, A), delta(A, N), delta(N, N), delta(ZERO, N)]
        terms.append(recursor(Body("R", delta(V, W)), N, A))
    if grammar == "conditional":
        terms += [
            conditional(N, A, ZERO, ONE),
            conditional(N, ZERO, A, N),
            recursor(Body("R", conditional(V, W, ZERO, ONE)), N, A),
        ]
    return terms


def generate_terms(grammar: str, rng: random.Random) -> list:
    pool = list(dict.fromkeys(initial_terms(grammar)))
    seen = set(pool)
    attempts = 0
    while len(pool) < CORPUS_SIZE:
        attempts += 1
        assert attempts < 200000, (grammar, len(pool))
        pick = rng.randrange(5)
        left = rng.choice(pool)
        right = rng.choice(pool)
        if pick == 0:
            term = successor(left)
        elif pick == 1 and grammar == "delta":
            term = delta(left, right)
        elif pick == 1 and grammar == "conditional":
            term = conditional(left, right, rng.choice(pool), rng.choice(pool))
        else:
            earlier = rng.choice(pool)
            kind = "D" if grammar == "delayed" else "R"
            mapping = {"n": V, "a": ZERO if kind == "D" else W}
            body = Body(kind, substitute(earlier, mapping))
            term = recursor(body, left, right)
        if active_size(term) > 32 or expanded_size(term) > 3500:
            continue
        if descriptor_rank(term) > 4 or term in seen:
            continue
        validate_term(term, frozenset(("n", "a")), grammar)
        seen.add(term)
        pool.append(term)
    return pool


class Printer:
    def __init__(self) -> None:
        self.labels: Dict[Body, str] = {}

    def term(self, term: Term) -> str:
        if isinstance(term, Var):
            return term.name
        if term.symbol == "0":
            return "0"
        if term.symbol == "If":
            left, right, yes, no = [self.term(arg) for arg in term.args]
            return f"If({left}={right},{yes},{no})"
        name = term.symbol
        if term.body is not None:
            if term.body not in self.labels:
                self.labels[term.body] = f"{term.symbol}{len(self.labels) + 1}"
            name = self.labels[term.body]
        return name + "(" + ",".join(self.term(arg) for arg in term.args) + ")"

    def formula(self, formula: Formula) -> str:
        if formula.tag == "=":
            return "(" + self.term(formula.args[0]) + "=" + self.term(formula.args[1]) + ")"
        if formula.tag == "false":
            return "false"
        if formula.tag == "forall":
            return "(forall " + formula.args[0] + " " + self.formula(formula.args[1]) + ")"
        token = {"and": " & ", "or": " | ", "implies": " -> "}[formula.tag]
        return "(" + token.join(self.formula(arg) for arg in formula.args) + ")"

    def descriptors(self) -> list:
        lines = []
        done = set()
        while len(done) < len(self.labels):
            for body, label in list(self.labels.items()):
                if body in done:
                    continue
                slots = "v" if body.kind == "D" else "v,w"
                lines.append(f"  {label}: stored body ({slots}) = {self.term(body.term)}")
                done.add(body)
        return lines


def substitution_checks() -> dict:
    body = Body("R", delta(V, W))
    nested = recursor(body, V, W)
    changed = substitute(nested, {"v": successor(N), "w": A})
    assert isinstance(changed, App) and changed.body is body
    assert changed.args == (successor(N), A)
    assert changed.body.term == delta(V, W)

    replacement = recursor(Body("R", W), N, A)
    actual = substitute(delta(N, A), {"n": replacement, "a": N})
    assert actual == delta(replacement, N)
    # A sequential substitution would wrongly rewrite the inserted seed a.
    sequential = substitute(substitute(delta(N, A), {"n": replacement}), {"a": N})
    assert sequential != actual
    swapped = substitute(delta(N, A), {"n": A, "a": N})
    assert swapped == delta(A, N)

    # Descriptor variables are not active free variables or occurrences.
    frozen = recursor(Body("R", delta(V, W)), ZERO, ONE)
    assert free_variables(frozen) == frozenset()
    assert occurrences(frozen, "v") == 0
    assert occurrences(frozen, "w") == 0
    assert descriptor_rank(recursor(Body("R", nested), N, A)) == 2
    return {
        "simultaneous_substitution": True,
        "inserted_terms_not_revisited": True,
        "sequential_substitution_counterexample_detected": True,
        "stored_descriptor_identity_preserved": True,
        "descriptor_variables_excluded_from_active_scope": True,
        "nested_descriptor_rank_checked": True,
    }


def audit_instance(label: str, term: Term, grammar: str) -> Tuple[Formula, dict]:
    p = profile(term)
    m, i, j, expanded = p["m"], p["i"], p["j"], p["W"]
    if label == "G":
        formula = shared_zero_schema(term)
        expected = 37 + 7 * m + 4 * i + 3 * j
        expected_expanded = 39 + (9 + i) * expanded + 4 * i + 3 * j
        depth, shadows = 2, 0
    elif label == "CR":
        formula = old_counter_schema(term)
        expected = 35 + 7 * m + 4 * i + 3 * j
        expected_expanded = 35 + (9 + i) * expanded + 4 * i + 3 * j
        depth, shadows = 3, 1
    elif label == "ZCR":
        formula = zero_counter_schema(term)
        expected = 33 + 5 * m + 3 * i
        expected_expanded = 33 + (7 + i) * expanded + 3 * i
        depth, shadows = 3, 1
    else:
        assert label == "M"
        formula = mask_counter_schema(term)
        expected = 35 + 4 * m + 3 * i
        expected_expanded = 35 + (6 + i) * expanded + 3 * i
        depth, shadows = 3, 1
    validate_formula(formula, grammar)
    observed = formula_size(formula)
    observed_expanded = formula_size(formula, expanded=True)
    assert observed == expected, (label, p, observed, expected)
    assert observed_expanded == expected_expanded, (
        label, p, observed_expanded, expected_expanded
    )
    scopes = scope_audit(formula)
    assert scopes["unbound_variables"] == []
    assert scopes["active_variable_names"] == ["a", "n"]
    assert scopes["quantifier_occurrences"] == 3
    assert scopes["quantifier_depth"] == depth
    assert scopes["shadowing_binders"] == shadows
    # A legitimate constant-in-n input leaves the step binder vacuous in
    # ZCR. It must still be counted as one printed quantifier occurrence.
    expected_vacuous = int(label == "ZCR" and i == 0)
    assert sum(value == 0 for value in scopes["binder_use_counts"]) == expected_vacuous
    return formula, {
        "schema": label,
        "grammar": grammar,
        "input_profile": p,
        "active_nodes": observed,
        "expanded_descriptor_nodes": observed_expanded,
        "scope": scopes,
    }


def main() -> None:
    substitutions = substitution_checks()
    rng = random.Random(SEED)
    corpora = {
        grammar: generate_terms(grammar, rng)
        for grammar in ("delayed", "counter", "delta", "conditional")
    }
    # A literal primitive-symbol renaming supplies an equally rich legal
    # mask corpus, including occurrences inside frozen stored descriptors.
    corpora["mask"] = [rename_primitive(t, "delta", "Delta") for t in corpora["delta"]]
    examples = []
    report = {}
    total_instances = 0
    size_checks = 0
    for grammar, terms in corpora.items():
        if grammar == "delayed":
            labels = ("G",)
        elif grammar == "mask":
            labels = ("CR", "ZCR", "M")
        else:
            labels = ("CR", "ZCR")
        tallies = {}
        for label in labels:
            minimum = None
            maximum = 0
            for index, term in enumerate(terms):
                formula, item = audit_instance(label, term, grammar)
                total_instances += 1
                size_checks += 2
                minimum = item["active_nodes"] if minimum is None else min(
                    minimum, item["active_nodes"]
                )
                maximum = max(maximum, item["active_nodes"])
                source_grammar = "delta" if grammar == "mask" else grammar
                if index in (0, 1, 2, len(initial_terms(source_grammar)) - 1):
                    examples.append((term, formula, item))
                if label == "ZCR":
                    old = old_counter_schema(term)
                    p = profile(term)
                    assert formula_size(old) - item["active_nodes"] == (
                        2 + 2 * p["m"] + p["i"] + 3 * p["j"]
                    )
                    assert formula_size(old, True) - item["expanded_descriptor_nodes"] == (
                        2 + 2 * p["W"] + p["i"] + 3 * p["j"]
                    )
                if label == "M":
                    old = old_counter_schema(term)
                    p = profile(term)
                    assert formula_size(old) - item["active_nodes"] == (
                        3 * p["m"] + p["i"] + 3 * p["j"]
                    )
                    assert formula_size(old, True) - item["expanded_descriptor_nodes"] == (
                        3 * p["W"] + p["i"] + 3 * p["j"]
                    )
                    assert formula_size(zero_counter_schema(term)) - item["active_nodes"] == (
                        p["m"] - 2
                    )
            tallies[label] = {
                "instances": len(terms),
                "min_active_nodes": minimum,
                "max_active_nodes": maximum,
            }
        report[grammar] = {
            "distinct_input_terms": len(terms),
            "terms_with_stored_descriptors": sum(descriptor_rank(t) > 0 for t in terms),
            "terms_with_nested_descriptors": sum(descriptor_rank(t) > 1 for t in terms),
            "maximum_descriptor_rank": max(descriptor_rank(t) for t in terms),
            "maximum_active_input_size": max(active_size(t) for t in terms),
            "maximum_expanded_input_size": max(expanded_size(t) for t in terms),
            "schemas": tallies,
        }

    bit = equality_bit_axiom()
    validate_formula(bit, "delta")
    assert formula_size(bit) == 18
    assert formula_size(bit, True) == 18
    bit_scope = scope_audit(bit)
    assert bit_scope["unbound_variables"] == []
    assert bit_scope["active_variable_names"] == ["x", "y"]
    assert bit_scope["quantifier_occurrences"] == 2
    assert bit_scope["quantifier_depth"] == 2
    assert bit_scope["shadowing_binders"] == 0

    mask_axiom = equality_mask_axiom()
    validate_formula(mask_axiom, "mask")
    assert formula_size(mask_axiom) == 17
    assert formula_size(mask_axiom, True) == 17
    mask_scope = scope_audit(mask_axiom)
    assert mask_scope["unbound_variables"] == []
    assert mask_scope["active_variable_names"] == ["x", "y"]
    assert mask_scope["quantifier_occurrences"] == 2
    assert mask_scope["quantifier_depth"] == 2
    assert mask_scope["shadowing_binders"] == 0

    off_diagonal = off_diagonal_axiom()
    validate_formula(off_diagonal, "mask")
    assert formula_size(off_diagonal) == 11
    assert formula_size(off_diagonal, True) == 11
    off_scope = scope_audit(off_diagonal)
    assert off_scope["unbound_variables"] == []
    assert off_scope["active_variable_names"] == ["x", "y"]
    assert off_scope["quantifier_occurrences"] == 2
    assert off_scope["quantifier_depth"] == 2
    assert off_scope["shadowing_binders"] == 0

    # For input u=n the progress consequent is literally Sn=Sn. This
    # records the exact instance used in the written diagonal-law proof;
    # the diagnostic itself does not implement logical proof search.
    diagonal_progress = forall(
        "n", implies(equal(mask(N, N), N), equal(successor(N), successor(N)))
    )
    assert mask_counter_schema(N) == forall(
        "a", forall(
            "n", conjunction(counter_payload(N), implies(diagonal_progress, equal(mask(N, N), N)))
        )
    )

    results = {
        "status": "PASS",
        "purpose": "Finite syntactic diagnostic; not a proof of bi-interpretability.",
        "seed": SEED,
        "total_corpus_inputs": sum(len(terms) for terms in corpora.values()),
        "total_distinct_input_trees": len(set(
            term for terms in corpora.values() for term in terms
        )),
        "total_schema_instances": total_instances,
        "exact_size_checks": size_checks,
        "fixed_equality_bit_axiom": {"active_nodes": 18, "scope": bit_scope},
        "fixed_equality_mask_axiom": {"active_nodes": 17, "scope": mask_scope},
        "fixed_off_diagonal_axiom": {"active_nodes": 11, "scope": off_scope},
        "diagonal_extraction_input": "u(n,a)=n; progress consequent is literally S(n)=S(n)",
        "substitution_checks": substitutions,
        "corpora": report,
        "size_formulas": {
            "G_active": "37+7*m+4*i+3*j",
            "CR_active": "35+7*m+4*i+3*j",
            "ZCR_active": "33+5*m+3*i",
            "M_active": "35+4*m+3*i",
            "G_expanded_descriptors": "39+(9+i)*W+4*i+3*j",
            "CR_expanded_descriptors": "35+(9+i)*W+4*i+3*j",
            "ZCR_expanded_descriptors": "33+(7+i)*W+3*i",
            "M_expanded_descriptors": "35+(6+i)*W+3*i",
            "CR_minus_ZCR_active": "2+2*m+i+3*j",
            "CR_minus_ZCR_expanded_descriptors": "2+2*W+i+3*j",
            "CR_minus_M_active": "3*m+i+3*j",
            "CR_minus_M_expanded_descriptors": "3*W+i+3*j",
            "ZCR_minus_M_active": "m-2",
            "B_delta_active": "18",
            "B_Delta_active": "17",
            "B_off_active": "11",
        },
        "comparison_scope": [
            "G is checked only on its legal unary-body delayed-iterator grammar.",
            "CR on the counter grammar is the literal current-draft baseline.",
            "CR on delta/mask/conditional grammars means the stated common extension.",
            "M is checked on a legal mask corpus obtained by primitive renaming of the delta corpus.",
            "All descriptor text is frozen under active substitution.",
            "Native If costs two nodes plus four subtrees: If and its equality condition.",
            "The fixed 11-node off-diagonal and 17-node full mask axioms are checked as exact ASTs.",
            "No schema equivalence or semantic correctness is inferred from these checks.",
        ],
    }
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "schema_results.json").write_text(json.dumps(results, indent=2) + "\n")
    lines = [
        "FINITE SCHEMA EXAMPLES",
        "Diagnostic output only; semantic proofs are in the report.",
        "Descriptor labels below are symbol names, not numerical function codes.",
        "",
    ]
    for term, formula, item in examples:
        printer = Printer()
        lines.append(f"[{item['grammar']} / {item['schema']}]")
        lines.append("u(n,a) = " + printer.term(term))
        lines.append("profile = " + json.dumps(item["input_profile"], sort_keys=True))
        lines.append(
            "nodes: active=" + str(item["active_nodes"])
            + ", expanded descriptors=" + str(item["expanded_descriptor_nodes"])
        )
        lines.append(printer.formula(formula))
        lines.extend(printer.descriptors())
        lines.append("")
    printer = Printer()
    lines.extend(["[fixed B_delta: 18 nodes]", printer.formula(bit), ""])
    lines.extend(["[fixed B_Delta: 17 nodes]", printer.formula(mask_axiom), ""])
    lines.extend(["[fixed B_off: 11 nodes]", printer.formula(off_diagonal), ""])
    (OUTPUT / "schema_examples.txt").write_text("\n".join(lines))
    print(json.dumps({
        "status": results["status"],
        "corpus_inputs": results["total_corpus_inputs"],
        "distinct_input_trees": results["total_distinct_input_trees"],
        "schema_instances": total_instances,
        "size_checks": size_checks,
        "B_delta_nodes": 18,
        "B_Delta_nodes": 17,
        "B_off_nodes": 11,
        "results": str(OUTPUT / "schema_results.json"),
        "examples": str(OUTPUT / "schema_examples.txt"),
    }, indent=2))


if __name__ == "__main__":
    main()
