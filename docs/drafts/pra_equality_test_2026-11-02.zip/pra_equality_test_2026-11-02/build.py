#!/usr/bin/env python3
"""Reproduce the finite checks and compile the report; no network is used."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
AUDIT = ROOT / "audit"
AUDIT.mkdir(exist_ok=True)
results = []


def run(label, args):
    result = subprocess.run(args, cwd=ROOT, text=True, capture_output=True)
    log = AUDIT / (label + ".log")
    log.write_text(result.stdout + result.stderr)
    results.append({"operation": label, "exit_code": result.returncode,
                    "log": str(log.relative_to(ROOT))})
    print(label + ": " + ("passed" if result.returncode == 0 else "FAILED"))
    if result.returncode:
        print((result.stdout + result.stderr)[-6000:])
        raise RuntimeError(label + " failed")


try:
    run("schema_check", [sys.executable, "checks/check_schema.py"])
    run("countermodel_check", [sys.executable, "checks/check_countermodel.py"])
    if not shutil.which("pdflatex"):
        raise RuntimeError("pdflatex is required (TeX Live or equivalent).")
    for index in range(1, 4):
        run("latex_pass_" + str(index),
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "report.tex"])
    log = (ROOT / "report.log").read_text(errors="replace")
    concerns = [line for line in log.splitlines()
                if any(key in line for key in (
                    "Overfull", "Undefined control sequence",
                    "undefined references", "undefined citations",
                    "multiply-defined labels"))]
    if concerns:
        raise RuntimeError("Final LaTeX concerns: " + repr(concerns))
    pdf = ROOT / "report.pdf"
    results.append({"operation": "final_pdf", "bytes": pdf.stat().st_size,
                    "sha256": hashlib.sha256(pdf.read_bytes()).hexdigest()})
    status = "passed"
except Exception as error:
    status = "failed"
    results.append({"error": str(error)})
finally:
    (AUDIT / "build_results.json").write_text(
        json.dumps({"status": status, "results": results}, indent=2) + "\n")

if status != "passed":
    sys.exit(1)
print("Report and diagnostics complete. Visual PDF review remains a separate step.")
