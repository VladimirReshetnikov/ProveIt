UNCHANGED COMPLETE COMPARATOR SOURCES
====================================

The sixteen files in checkers/ are copied byte for byte from the current
ipra_stationarity_2026-11-08.zip archive at ProveIt commit
deefab74912eef91a2cd1ba6686589cb8964466e.

baseline_manifest.json is the unchanged inherited manifest. It records
earlier source origins, SHA-256 identities, and the CPython 3.12.14 source
measurements. Its commit names refer to the earlier snapshot inspected by
the stationarity report, not to the present report's current snapshot.
The direct current provenance is ../provenance/baseline_sources.json.

Run the current audit from any working directory with:

    python3 /path/to/package/code/measure_baselines.py

It verifies every unchanged source and the original inherited normalizer,
uses that normalizer on each complete program, and writes the measured
profiles and the five-row comparison table under ../evidence/.

The metric includes the whole program: source validation, scope handling,
logical operations, imports, and input/output acceptance code. Genuine
docstrings and comments are omitted, and ast.unparse normalizes layout.
Python and its standard library are the common external runtime.

All checker sources are parsed as text, never imported or executed during
measurement. The unchanged source normalizer is imported as an ordinary
measurement helper; it does not execute any checker. Measurements are
not soundness proofs or universal lower bounds. The coordinate minima
313 tokens / 347 AST nodes / 878 bytes have different attainers.

provenance/ preserves the original license and attribution records,
the original source normalizer, and the original stationarity README and
measurement script for provenance. The latter script has been relocated
and is not the current reproduction entry point.

The current package does not enter a new complete checker in this table.
