#!/usr/bin/env python3
"""Compile the complete paper offline with pdfLaTeX, without shell escape."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    compiler = shutil.which("pdflatex")
    if compiler is None:
        raise SystemExit("pdfLaTeX is required; a compiled report.pdf is included.")
    runs = []
    for number in range(1, 4):
        run = subprocess.run(
            [compiler, "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "report.tex"],
            cwd=ROOT, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        runs.append({"run": number, "returncode": run.returncode})
        (ROOT / "evidence" / "latex_build.txt").write_text(run.stdout)
        if run.returncode:
            print(run.stdout[-8000:])
            raise SystemExit(run.returncode)
    log = (ROOT / "report.log").read_text(errors="replace")
    warnings = [line for line in log.splitlines()
                if "Warning:" in line or "Overfull" in line]
    receipt = {"compiler": "pdfLaTeX", "shell_escape": False,
               "runs": runs, "warnings": warnings,
               "pdf_bytes": (ROOT / "report.pdf").stat().st_size}
    (ROOT / "evidence" / "build.json").write_text(
        json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
