#!/usr/bin/env python3
"""Reproduce all sixteen complete baseline profiles, offline, from any cwd.

Only the unchanged inherited measurement helper is imported. Checker programs
are read and parsed as text, never imported or executed. Whole programs,
including their public acceptance/rejection drivers, are measured.
"""

import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys


ROOT = Path(__file__).resolve().parents[1]
COMPARISON = ROOT / "comparison"
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
SNAPSHOT = "deefab74912eef91a2cd1ba6686589cb8964466e"
PINNED = {
    "baseline_manifest.json":
        "9ce76a56d5cb17754ea3bb7b90877dfc32fe39de2a53025e31f53038e35b59a3",
    "provenance/inherited_measure_current.py":
        "bf0e35b80f43f47f2ba618fe86593ee8b556b3bc57a49bfcc945068b308b0678",
}
TABLE_ROWS = (
    ("initializer_structural.py", "Initializer, structural"),
    ("initializer_compact.py", "Initializer, compact"),
    ("structural_open.py", "Structural, UTF-8 input"),
    ("compact_open.py", "Compact, UTF-8 input"),
    ("compact_unpack_open.py", "Compact, unpacked + UTF-8"),
)


def verified_bytes(path, digest):
    raw = path.read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != digest:
        raise ValueError("SHA-256 mismatch: " + str(path))
    return raw


def load_original_normalizer():
    path = COMPARISON / "provenance/inherited_measure_current.py"
    verified_bytes(path, PINNED["provenance/inherited_measure_current.py"])
    spec = importlib.util.spec_from_file_location("inherited_source_measure", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load the preserved source normalizer")
    module = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = old
    return module


def latex_table(rows, minima):
    by_name = {Path(row["package_path"]).name: row for row in rows}
    lines = [
        r"\begin{tabular}{@{}lrrr@{}}",
        r"\toprule",
        r"Complete program & Tokens & AST nodes & Bytes\\",
        r"\midrule",
    ]
    for name, label in TABLE_ROWS:
        row = by_name[name]
        values = " & ".join(str(row[key]) for key in FIELDS)
        lines.append(label + " & " + values + r"\\")
    lines.extend([
        r"\midrule",
        "All sixteen: coordinate minima & "
        + " & ".join(str(minima[key]) for key in FIELDS) + r"\\",
        r"\bottomrule",
        r"\end{tabular}",
        "",
    ])
    return "\n".join(lines)


def main():
    manifest = json.loads(verified_bytes(
        COMPARISON / "baseline_manifest.json", PINNED["baseline_manifest.json"]
    ))
    original = load_original_normalizer()
    entries = manifest["programs"]
    if len(entries) != 16:
        raise ValueError("Expected exactly sixteen complete comparator sources")
    expected = {entry["local_file"] for entry in entries}
    observed = {str(path.relative_to(COMPARISON))
                for path in (COMPARISON / "checkers").glob("*.py")}
    if expected != observed:
        raise ValueError("The complete comparator source inventory changed")

    rows = []
    for entry in entries:
        path = COMPARISON / entry["local_file"]
        raw = verified_bytes(path, entry["sha256"])
        measured = original.metrics(raw)
        profile = {key: measured[key] for key in FIELDS}
        rows.append({
            "label": entry["label"],
            "package_path": "comparison/" + entry["local_file"],
            "sha256": measured["sha256"],
            "raw_bytes": measured["raw_bytes"],
            "source_tokens": measured["source_tokens"],
            **profile,
            "recorded_profile": entry["recorded_metrics"],
            "matches_recorded_profile": profile == entry["recorded_metrics"],
            "direct_source_archive": "ipra_stationarity_2026-11-08.zip",
            "direct_source_member": "ipra_stationarity_2026-11-08/comparison/"
                                    + entry["local_file"],
        })

    minima = {key: min(row[key] for row in rows) for key in FIELDS}
    pareto = [row["package_path"] for row in rows if not any(
        all(other[key] <= row[key] for key in FIELDS)
        and any(other[key] < row[key] for key in FIELDS)
        for other in rows
    )]
    all_match = all(row["matches_recorded_profile"] for row in rows)
    result = {
        "format": "ipra-unary-barriers-baseline-metrics-v1",
        "repository": "VladimirReshetnikov/ProveIt",
        "snapshot": SNAPSHOT,
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "pinned_metric_version": "CPython 3.12.14",
        "program_count": len(rows),
        "all_source_hashes_verified": True,
        "original_normalizer_sha256":
            PINNED["provenance/inherited_measure_current.py"],
        "inherited_manifest_sha256": PINNED["baseline_manifest.json"],
        "coordinate_envelope": minima,
        "attainers": {
            key: [row["package_path"] for row in rows if row[key] == minima[key]]
            for key in FIELDS
        },
        "pareto_frontier": pareto,
        "all_profiles_match_recorded": all_match,
        "programs": rows,
        "scope": (
            "Whole unchanged complete programs, including syntax/scope validation, "
            "logical operations, imports and acceptance/rejection drivers. Genuine "
            "docstrings and comments are removed; ast.unparse normalizes layout. "
            "Python and its standard library are the common external runtime. "
            "Source metrics are not soundness proofs or universal lower bounds. "
            "No new complete checker is entered in this comparison."
        ),
    }
    evidence = ROOT / "evidence"
    evidence.mkdir(parents=True, exist_ok=True)
    (evidence / "baselines.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    (evidence / "table.tex").write_text(latex_table(rows, minima), encoding="utf-8")
    print(json.dumps({
        "programs": len(rows), "envelope": minima,
        "all_source_hashes_verified": True,
        "all_profiles_match_recorded": all_match,
    }))
    if not all_match:
        raise SystemExit(
            "Profiles differ from CPython 3.12.14. Recomputed results are saved; "
            "inspect the interpreter-dependent AST/unparser changes."
        )


if __name__ == "__main__":
    main()
