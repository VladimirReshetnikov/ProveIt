#!/usr/bin/env python3
"""Offline diagnostics for the stated obstructions; not an iPRA checker.

This program evaluates disclosed finite recursion terms, checks a schematic
meet-preservation calculation, and tests a finite pairing-obstruction pattern.
It neither constructs a nonstandard Kripke model nor proves either fan theorem.
All tests use explicit exceptions, so Python's -O option does not disable them.
"""

from functools import lru_cache
from itertools import product
from pathlib import Path
import hashlib
import json
import platform


def require(condition, message):
    if not condition:
        raise ValueError(message)


def zero():
    return ("zero",)


def variable(index):
    return ("var", index)


def successor(term):
    return ("succ", term)


def recursion(counter, update, seed=0):
    # Update variables 0 and 1 denote the current counter and current state.
    # Its variables 2, 3, ... denote the enclosing environment, in order.
    return ("rec", seed, counter, update)


def lift(term, amount, depth=0):
    tag = term[0]
    if tag == "zero":
        return term
    if tag == "var":
        return variable(term[1] + (amount if term[1] >= depth else 0))
    if tag == "succ":
        return successor(lift(term[1], amount, depth))
    if tag == "rec":
        return recursion(lift(term[2], amount, depth),
                         lift(term[3], amount, depth + 2), term[1])
    raise ValueError("Unknown term constructor")


def validate(term, arity, zero_seed_only=True):
    require(type(term) is tuple and bool(term), "Malformed term")
    tag = term[0]
    if tag == "zero":
        require(len(term) == 1, "Malformed zero")
    elif tag == "var":
        require(len(term) == 2 and type(term[1]) is int
                and 0 <= term[1] < arity, "Unbound variable")
    elif tag == "succ":
        require(len(term) == 2, "Malformed successor")
        validate(term[1], arity, zero_seed_only)
    elif tag == "rec":
        require(len(term) == 4 and type(term[1]) is int
                and term[1] >= 0, "Malformed recursion seed")
        require(not zero_seed_only or term[1] == 0, "Nonzero seed")
        validate(term[2], arity, zero_seed_only)
        validate(term[3], arity + 2, zero_seed_only)
    else:
        raise ValueError("Unknown term constructor")


@lru_cache(maxsize=None)
def evaluate(term, environment):
    tag = term[0]
    if tag == "zero":
        return 0
    if tag == "var":
        return environment[term[1]]
    if tag == "succ":
        return evaluate(term[1], environment) + 1
    if tag == "rec":
        count = evaluate(term[2], environment)
        require(count <= 100000, "Diagnostic evaluation limit exceeded")
        state = term[1]
        for counter in range(count):
            state = evaluate(term[3], (counter, state) + environment)
        return state
    raise ValueError("Unknown term constructor")


def gate(count, value):
    return recursion(count, lift(value, 2))


def predecessor(count):
    return recursion(count, variable(0))


def twice(count):
    return recursion(count, successor(successor(variable(1))))


def exponential_minus_one(count):
    return recursion(count, successor(twice(variable(1))))


def examples():
    n, p, q = variable(0), variable(1), variable(2)
    return [
        ("successor", 1, successor(n)),
        ("counter_predecessor", 1, predecessor(n)),
        ("counter_identity", 1, recursion(n, successor(variable(0)))),
        ("double_by_two_successors", 1, twice(n)),
        ("counter_double", 1, recursion(n, twice(variable(0)))),
        ("exponential_minus_one", 1, exponential_minus_one(n)),
        ("iterated_exponential_small_bound", 1,
         recursion(n, successor(exponential_minus_one(variable(1))))),
        ("positive_gate", 2, gate(n, p)),
        ("delayed_gate_using_counter", 2,
         recursion(n, gate(variable(0), variable(3)))),
        ("state_gate_with_parameter", 2,
         recursion(n, successor(gate(variable(1), variable(3))))),
        ("parameter_gated_counter", 2,
         recursion(n, gate(variable(3), variable(0)))),
        ("exponential_of_gate", 2, exponential_minus_one(gate(n, p))),
        ("parameter_gated_growth", 2,
         recursion(n, gate(variable(3),
                           successor(twice(variable(1)))))),
        ("two_independent_positive_gates", 3, gate(n, gate(p, q))),
    ]


def finite_meet_checks():
    records = []
    bound = 4
    for name, arity, term in examples():
        validate(term, arity)
        inputs = list(product(range(bound + 1), repeat=arity))
        values = {args: evaluate(term, args) for args in inputs}
        for left in inputs:
            for right in inputs:
                meet = tuple(min(x, y) for x, y in zip(left, right))
                require(values[meet] == min(values[left], values[right]),
                        f"Meet preservation failed: {name}, {left}, {right}")
        records.append({
            "name": name, "arity": arity, "term_ast": term,
            "seed_policy": "Every recursion node has fixed seed zero.",
            "each_input_range_inclusive": [0, bound],
            "input_tuples": len(inputs), "ordered_tuple_pairs": len(inputs) ** 2,
            "largest_observed_output": max(values.values()), "passed": True,
        })
    return records


def meet_counterexample(function, left, right):
    meet = tuple(min(x, y) for x, y in zip(left, right))
    output_at_meet = function(*meet)
    meet_of_outputs = min(function(*left), function(*right))
    require(output_at_meet != meet_of_outputs, "Negative control did not fail")
    return {"left_input": left, "right_input": right, "input_meet": meet,
            "output_at_meet": output_at_meet, "meet_of_outputs": meet_of_outputs,
            "property_fails_as_expected": True}


def negative_controls():
    seed_one_zero_test = recursion(variable(0), zero(), seed=1)
    validate(seed_one_zero_test, 1, zero_seed_only=False)

    def initialized_successor(count, seed):
        state = seed
        for _ in range(count):
            state += 1
        return state

    return {
        "addition": meet_counterexample(lambda x, y: x + y, (1, 0), (0, 1)),
        "maximum": meet_counterexample(max, (1, 0), (0, 1)),
        "fixed_seed_one_zero_test": {
            "term_ast": seed_one_zero_test,
            **meet_counterexample(lambda n: evaluate(seed_one_zero_test, (n,)),
                                  (0,), (1,)),
        },
        "varying_initializer_successor_iteration": {
            "definition": "I(0,a)=a; I(n+1,a)=I(n,a)+1",
            **meet_counterexample(initialized_successor, (1, 0), (0, 1)),
            "first_coordinate_fixed_at_zero_outputs":
                [initialized_successor(0, a) for a in range(9)],
            "second_coordinate_fixed_at_zero_outputs":
                [initialized_successor(n, 0) for n in range(9)],
            "finite_table_scope": "The table alone does not prove unboundedness.",
        },
    }


def match_pattern(pattern, expression, bindings):
    if type(pattern) is str and pattern.startswith("?"):
        if pattern in bindings:
            require(bindings[pattern] == expression, "Inconsistent pattern match")
        else:
            bindings[pattern] = expression
    elif type(pattern) is tuple:
        require(type(expression) is tuple and len(pattern) == len(expression),
                "Pattern shape mismatch")
        for left, right in zip(pattern, expression):
            match_pattern(left, right, bindings)
    else:
        require(pattern == expression, "Pattern atom mismatch")


def instantiate(pattern, bindings):
    if type(pattern) is str and pattern.startswith("?"):
        return bindings[pattern]
    if type(pattern) is tuple:
        return tuple(instantiate(child, bindings) for child in pattern)
    return pattern


def rewrite(expression, path, left, right):
    if path:
        index = path[0]
        require(type(expression) is tuple and 0 <= index < len(expression),
                "Invalid rewrite path")
        children = list(expression)
        children[index] = rewrite(children[index], path[1:], left, right)
        return tuple(children)
    bindings = {}
    match_pattern(left, expression, bindings)
    return instantiate(right, bindings)


def recursion_meet_certificate():
    # This checks the conditional symbolic induction step, not a general
    # proof language or the fan theorem. h's meet law and IH are assumptions.
    rules = {
        "recursion_zero": (("R", 0, "?p"), 0),
        "minimum_zero": (("min", 0, "?x"), 0),
        "recursion_successor": (
            ("R", ("S", "?n"), "?p"),
            ("h", "?n", ("R", "?n", "?p"), "?p")),
        "update_meet_law": (
            ("min", ("h", "?a", "?b", "?c"),
                    ("h", "?d", "?e", "?f")),
            ("h", ("min", "?a", "?d"), ("min", "?b", "?e"),
                  ("min", "?c", "?f"))),
        "ordered_counters": (("min", "n", "m"), "n"),
        "induction_hypothesis": (
            ("min", ("R", "n", "p"), ("R", "m", "q")),
            ("R", "n", ("min", "p", "q"))),
    }
    start = ("min", ("R", ("S", "n"), "p"),
                    ("R", ("S", "m"), "q"))
    expression = start
    steps = []
    for rule, path in [("recursion_successor", (1,)),
                       ("recursion_successor", (2,)),
                       ("update_meet_law", ()),
                       ("ordered_counters", (1,)),
                       ("induction_hypothesis", (2,))]:
        expression = rewrite(expression, path, *rules[rule])
        steps.append({"rule": rule, "path": path, "result": expression})
    desired = ("R", ("S", "n"), ("min", "p", "q"))
    expanded_desired = rewrite(desired, (), *rules["recursion_successor"])
    require(expression == expanded_desired, "Symbolic successor endpoints differ")
    altered_target = ("R", ("S", "m"), ("min", "p", "q"))
    require(expression != rewrite(altered_target, (), *rules["recursion_successor"]),
            "Altered symbolic endpoint was accepted")
    base_start = ("min", ("R", 0, "p"), ("R", "m", "q"))
    base_middle = rewrite(base_start, (1,), *rules["recursion_zero"])
    base_end = rewrite(base_middle, (), *rules["minimum_zero"])
    base_desired = rewrite(("R", 0, ("min", "p", "q")), (),
                           *rules["recursion_zero"])
    require(base_end == base_desired == 0, "Symbolic base endpoints differ")
    return {
        "assumptions": ["n <= m", "h preserves coordinatewise minimum",
                        "IH: min(R(n,p),R(m,q)) = R(n,min(p,q))"],
        "parameter_notation": "p and q may stand for tuples; min is componentwise.",
        "base_steps": [base_start, base_middle, base_end],
        "expanded_base_desired": base_desired,
        "start": start, "steps": steps, "desired_endpoint": desired,
        "expanded_desired_endpoint": expanded_desired,
        "symbolic_steps_checked": len(steps) + 4,
        "altered_endpoint_rejected": True,
        "scope": "Checks the base and conditional induction-step rewrites. "
                 "The mathematical induction and structural closure proof are in the report.",
    }


def initialized_addition_certificate():
    # An affine form (c,a,n) denotes c + a_coefficient*a + n_coefficient*n.
    formula = (0, 1, 1)
    base = (formula[0], formula[1], 0)
    successor_substitution = (formula[0] + formula[2], formula[1], formula[2])
    successor_of_previous = (formula[0] + 1, formula[1], formula[2])
    require(base == (0, 1, 0), "Affine base is not the initializer")
    require(successor_substitution == successor_of_previous,
            "Affine successor equations differ")
    require(formula[1] == 1 and formula[2] == 1,
            "Both independent coordinates must remain unbounded")
    return {
        "affine_convention": "(constant, initializer coefficient, counter coefficient)",
        "candidate_formula": formula, "base_at_counter_zero": base,
        "candidate_at_successor_counter": successor_substitution,
        "successor_of_previous_candidate": successor_of_previous,
        "coefficient_checks_passed": True,
        "exact_obstruction_schema": [
            "If b(a) were a unary bound, set a=0 and n=b(0)+1.",
            "If b(n) were a unary bound, set n=0 and a=b(0)+1.",
        ],
        "scope": "The coefficient identities certify the displayed affine recurrence. "
                 "Its interpretation by induction and the two unboundedness contradictions "
                 "are mathematical arguments, not conclusions from a finite growth table.",
    }


def pairing_pattern():
    # At two abstract coordinates choose independent target vectors x,y.
    # A possible code vector must have uniform truth of the unary formula Lz=Rz.
    x, y = (0, 0), (0, 1)
    require((x[0] == y[0]) != (x[1] == y[1]), "Targets lack mixed equality")
    alphabet = range(3)
    examined = admitted = matches = unrestricted_matches = 0
    for candidate_left in product(alphabet, repeat=2):
        for candidate_right in product(alphabet, repeat=2):
            examined += 1
            if candidate_left == x and candidate_right == y:
                unrestricted_matches += 1
            truth = tuple(a == b for a, b in zip(candidate_left, candidate_right))
            if truth[0] != truth[1]:
                continue
            admitted += 1
            if candidate_left == x and candidate_right == y:
                matches += 1
    require(matches == 0, "A homogeneous candidate matched mixed-equality targets")
    require(unrestricted_matches == 1, "Unrestricted pairing control failed")
    return {
        "left_target_vector": x, "right_target_vector": y,
        "unary_type_label_used": "Truth value of L(z)=R(z) only.",
        "candidate_projection_alphabet": list(alphabet),
        "candidate_pairs_examined": examined,
        "uniform_label_candidates": admitted, "matching_admitted_candidates": matches,
        "unrestricted_matching_candidates": unrestricted_matches,
        "scope": "A finite combinatorial pattern illustrating PairSurj failure. "
                 "These labels are not complete types. This is not a finite Kripke model "
                 "of the arithmetic theories and does not prove either fan theorem.",
    }


def main():
    meet_records = finite_meet_checks()
    receipt = {
        "schema_version": 1,
        "status": "PASS",
        "verification_scope": [
            "Exhaustive finite evaluation of the disclosed ASTs and input bounds only.",
            "All main recursion terms have zero seed and permit a genuine counter argument.",
            "The symbolic certificate checks a conditional meet-preservation calculation.",
            "No finite diagnostic represents the nonstandard or homogeneous-type Kripke model.",
            "No fan theorem, global completeness, or bi-interpretability is proved by this program.",
            "This program is not a full iPRA proof checker or a Lean/Rocq formalization.",
        ],
        "term_syntax": {
            "zero": ["zero"], "variable": ["var", "index"],
            "successor": ["succ", "term"],
            "recursion": ["rec", "fixed seed", "counter term", "update term"],
            "update_environment": ["current counter", "current state",
                                   "enclosing variable 0", "enclosing variable 1", "..."],
        },
        "python_version": platform.python_version(),
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "meet_checks": meet_records,
        "meet_ordered_tuple_pairs_checked": sum(r["ordered_tuple_pairs"] for r in meet_records),
        "negative_controls": negative_controls(),
        "recursion_meet_symbolic_certificate": recursion_meet_certificate(),
        "varying_initializer_affine_certificate": initialized_addition_certificate(),
        "pairing_obstruction_pattern": pairing_pattern(),
    }
    destination = Path(__file__).resolve().parents[1] / "evidence" / "finite_diagnostics.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": receipt["status"], "term_count": len(meet_records),
                      "meet_pairs": receipt["meet_ordered_tuple_pairs_checked"],
                      "negative_controls": len(receipt["negative_controls"]),
                      "symbolic_steps": receipt["recursion_meet_symbolic_certificate"]
                                                 ["symbolic_steps_checked"],
                      "receipt": str(destination)}))


if __name__ == "__main__":
    main()
