#!/usr/bin/env python3
"""Reproduce source measurements and scoped finite/symbolic diagnostics."""
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    inherited = json.loads(
        (ROOT / "provenance" / "inherited_math.json").read_text())
    for row in inherited["files"]:
        raw = (ROOT / row["destination"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != row["sha256"]:
            raise ValueError("Inherited source changed: " + row["destination"])
    rows = []
    for relative in ["code/measure_baselines.py", "code/finite_diagnostics.py"]:
        result = subprocess.run([sys.executable, str(ROOT / relative)],
                                cwd=ROOT, text=True, capture_output=True)
        rows.append({"program": relative, "returncode": result.returncode,
                     "stdout": result.stdout.strip(),
                     "stderr": result.stderr.strip()})
        if result.returncode:
            print(result.stdout)
            print(result.stderr)
            raise SystemExit(result.returncode)
    receipt = {
        "status": "PASS", "python": platform.python_version(),
        "inherited_mathematical_files_verified": len(inherited["files"]),
        "runs": rows,
        "scope": "Source identity/metrics and disclosed finite/symbolic checks only. "
                 "No nonstandard model construction, fan formalization, new full "
                 "iPRA kernel, or strict checker-size improvement is certified."
    }
    (ROOT / "evidence" / "reproduction.json").write_text(
        json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": receipt["status"],
                      "programs": len(rows), "python": receipt["python"]}))


if __name__ == "__main__":
    main()
