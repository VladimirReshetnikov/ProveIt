#!/usr/bin/env python3
"""Create an integrity manifest and deterministic ZIP after deliberate changes."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def payload():
    return sorted(p for p in ROOT.rglob("*")
                  if p.is_file() and p.name != "MANIFEST.json"
                  and p.suffix not in SKIP_SUFFIXES
                  and "__pycache__" not in p.parts)


def main():
    paths = payload()
    manifest = {
        "format": "ipra-research-package-sha256-v1",
        "package": ROOT.name,
        "scope": "Integrity manifest, not a mathematical proof certificate.",
        "files": [{"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size,
                   "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                  for p in paths]
    }
    manifest_path = ROOT / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    archive = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as target:
        for path in sorted(paths + [manifest_path]):
            member = str(Path(ROOT.name) / path.relative_to(ROOT))
            info = zipfile.ZipInfo(member, date_time=(2026, 11, 9, 4, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            target.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as target:
        damaged = target.testzip()
        if damaged:
            raise ValueError("Damaged ZIP member: " + damaged)
        for row in manifest["files"]:
            raw = target.read(ROOT.name + "/" + row["path"])
            if hashlib.sha256(raw).hexdigest() != row["sha256"]:
                raise ValueError("Archive hash mismatch: " + row["path"])
    print(json.dumps({"archive": archive.name,
                      "payload_files": len(paths),
                      "bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                      "integrity": "PASS"}))


if __name__ == "__main__":
    main()
