UNARY COMPUTATION, INDEPENDENT PARAMETERS, AND THE iPRA MINIMIZATION BOUNDARY
===========================================================================
Prepared for Vladimir Reshetnikov, 9 November 2026 (UTC).

STATUS FIRST
------------
The requested strict improvement in complete proof-checker complexity has
NOT been achieved. This is a mathematical research package, not a claimed
smallest axiomatization. No new complete checker is entered in the comparison.
The verified coordinate minima remain 313 normalized tokens / 347 AST nodes /
878 normalized bytes, attained by different programs.

NEW RESULTS RELATIVE TO THE INSPECTED CORPUS
------------------------------------------
1. A homogeneous-type Kripke fan validates an extremely rich unary theory:
   all unary PR functions, all true universal Horn sentences, all true
   parameter-free unary quantifier-free facts, numerical coverage, contextual
   equation induction with parameters, and parameter-free qf induction.
   Nevertheless this theory and every effective fragment validated by the
   same model fail ordinary bi-interpretability with iPRA, even through
   finite-dimensional definable domains, relational graphs, quotients, and
   finite parameter tuples. Relational pairing and two-parameter equality
   decidability fail explicitly. The all-true overtheory is an obstruction
   device, not an effective axiomatization proposal.
2. A nonstandard fan excludes a zero-initialized counter-dependent recursor
   even after adding numerical coverage and contextual equation induction.
   Its standard term operations also preserve coordinatewise minimum.
3. The prior scalar fixed-seed majorization theorem extends to counter-dependent
   updates and arbitrary unary PR initial functions. This is a term result;
   it does not alone exclude relational interpretations.
4. A bounded-or-inflationary orbit invariant excludes predecessor from a
   closed-unary composition/iteration fragment with bounded varying seeds.
   The supplied shifted clock uses an unbounded initializer, so this does
   not refute it or derive its unresolved internal retraction equation.

COMPLETE POSITIVE REFERENCE
---------------------------
The full inherited scalar/native presentation is stated explicitly, with
all ordinary logical rules, all five auxiliary native patterns, the iterator
equations, freshness conditions, full internal arithmetic reconstruction,
and both identity-domain interpretation composites. The appended arithmetic
and logical proofs retain their original attribution. The reference is not
advertised as a new reduction.

FILES
-----
report.pdf / report.tex / sections/    Primary paper and full editable source.
appendices/                          Attributed full inherited arithmetic/logic.
code/measure_baselines.py             Exact whole-program source audit.
code/finite_diagnostics.py            Scoped finite and symbolic diagnostics.
comparison/                          Sixteen unchanged complete reference kernels.
reference/                           Original format, notices, supporting sources.
evidence/                            Executed receipts and written review.
provenance/                          Pinned archive/source identities and hashes.
reproduce.py                         Run offline computational checks.
build.py                             Rebuild the PDF with pdfLaTeX.
package.py                           Rebuild the manifest and deterministic ZIP.
MANIFEST.json                        SHA-256 integrity of all other payload files.
ATTRIBUTION.txt                       Exact new/inherited contribution boundary.

REPRODUCE
---------
Python 3.10+ and standard library only:
    python3 reproduce.py
Use CPython 3.12.14 for the exact recorded AST/unparser measurements.

PDF rebuild (TeX Live or equivalent, no shell escape):
    python3 build.py
Packages: fontenc, inputenc, lmodern, microtype, geometry, amsmath, amssymb,
amsthm, mathtools, booktabs, longtable, array, tabularx, enumitem, xcolor,
fancyhdr, needspace, tikz, hyperref.

After deliberate edits, regeneration of the release ZIP:
    python3 package.py
This packages current files; it does not reprove the mathematics or rebuild
the PDF. Run reproduction and PDF compilation first when needed.

EVIDENCE LIMITS
---------------
The diagnostic program checks 14 disclosed zero-seeded terms and 19,550
finite meet instances, four negative controls, nine symbolic rewrites,
and an 81-candidate pairing pattern. It does not construct a nonstandard
model or formally verify either fan theorem. Written proofs received
independent mathematical review; no Lean or Rocq formalization is included.
The comparison program measures complete source files but does not execute
or formally verify their whole acceptance behavior.

PINNED SOURCE
-------------
https://github.com/VladimirReshetnikov/ProveIt/tree/deefab74912eef91a2cd1ba6686589cb8964466e/docs/drafts
Ten current archives were retrieved. The sixteen frozen comparison programs
are directly retained in the current stationarity archive. Older arithmetic
source was retrieved at commit 06e097f723c659030816e0194e5eb7e8c607ba9b.
No remote repository mutation was performed. No literature-wide novelty,
universal complexity lower bound, or completed minimization result is claimed.
