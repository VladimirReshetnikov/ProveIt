"""Compile the complete report twice with pdfLaTeX; no network calls."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    compiler = shutil.which('pdflatex')
    if compiler is None:
        raise SystemExit('pdfLaTeX is required to rebuild the PDF.')
    for unused in range(3):
        result = subprocess.run([compiler, '-interaction=nonstopmode', '-halt-on-error',
                                 '-file-line-error', 'report.tex'], cwd=ROOT,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        if result.returncode:
            print(result.stdout[-10000:])
            raise SystemExit(result.returncode)
    print('Built report.pdf')


if __name__ == '__main__':
    main()
