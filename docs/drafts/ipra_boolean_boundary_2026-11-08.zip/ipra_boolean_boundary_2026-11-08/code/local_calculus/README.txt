LOCAL ONE-OCCURRENCE CALCULUS: AUDIT IMPLEMENTATION

Run:
    python3 test_checker.py
    python3 -O test_checker.py

No dependencies are required. Python 3.8 or later is sufficient.

This is a proof-tree API over finite immutable dataclass ASTs, not a JSON
certificate parser, standalone adversarial-input service, or size-optimized
kernel. The input boundary is explicit Python data constructed from these ASTs.
Native free numerical variables are allowed parameters. Named binders use
capture-avoiding substitution, and syntax comparison allows alpha-renaming.

check(proof, context=()) infers the conclusion or raises InvalidProof.
Contexts are tuples of reusable Clause(antecedent, bound_name, consequent).
The bound name must not occur free in the antecedent.

The only primitive proof constructors checked are:
  I0      I(0,a;u.h)=a.
  IS      I(Sn,a;u.h)=h[I(n,a;u.h)/u].
  Use     Apply a retained clause to a proof of its antecedent.
  DI      Introduce D_xy B with retained B(t,0), plus B(t,z) only when
          B is literally an equation; prove B(t,Sz), with fresh z.
  DE      Open D_xy B with fresh witness a, retaining the clause
          <B(a,0); y.B(a,y)> in its minor premise.
  Replace From s=t and C[s]=r infer C[t]=r. C is a numerical term context
          with exactly one hole; the right side remains unchanged.

Hole is metasyntax for replacement only and is rejected in ordinary terms.
All finite substitutions and hole filling rename binders to avoid capture.
DI and DE check their eigenvariable side conditions. The checker contains no
Python assert, so these checks remain enabled under python3 -O.

The functions after check are UNTRUSTED proof producers, not primitive rules:
  truth_proof, assumption, reflexivity, symmetry;
  atomic_transport (repeated selected occurrences, including right sides);
  formula_transport (external recursion through paired binders);
  weaken (relocates local clause indices and renames eigenparameters).
Their outputs are independently replayed through the same six-rule checker.

The tests cover all six native rules, one-occurrence restrictions, duplicate
template variables, accidental equal subterms, capture avoidance under scalar
binders and during witness opening, depth-two logical transport, eigenvariable
rejection, and the literal-equation guard on induction assumptions. Regressions
include a witness/counter name collision that formerly admitted a false 1=0
conclusion, valid alpha-renamed uses of that same collision, simultaneous DI
substitution, malformed object holes, and rejection of cyclic proof graphs.
These are finite implementation audits.
They do not replace the paper's metatheoretic proof or a Lean/Rocq formalization.
No implementation-size improvement or absolute simplicity claim is made.
