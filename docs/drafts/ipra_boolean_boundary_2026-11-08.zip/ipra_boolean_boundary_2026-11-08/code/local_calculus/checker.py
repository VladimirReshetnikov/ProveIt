"""A readable proof-tree API for the one-binder clausal iPRA calculus.

The six checked node kinds are I0, IS, Use, DI, DE, and Replace.  Replace
changes exactly one numerical occurrence on the LEFT of an equation.
There is no primitive hypothesis, reflexivity, symmetry, or formula transport.

This module is an audit implementation, not a serialized proof format or a
checker-size contender.  Inputs are finite instances of the immutable ASTs
below.  Free numerical variables are parameters; binders use named variables.
All substitutions and hole filling avoid capture.  Equality of syntax is
checked modulo alpha-renaming.  No Python assert is used in the checker.
"""
from dataclasses import dataclass
import re


class InvalidProof(ValueError):
    pass


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    value: object


@dataclass(frozen=True)
class Iter:
    count: object
    initial: object
    variable: str
    update: object


@dataclass(frozen=True)
class Hole:
    """Metasyntax only: forbidden in object-language terms and formulas."""


@dataclass(frozen=True)
class Eq:
    left: object
    right: object


@dataclass(frozen=True)
class D:
    witness_variable: str
    counter_variable: str
    matrix: object


@dataclass(frozen=True)
class Clause:
    antecedent: object
    variable: str
    consequent: object


@dataclass(frozen=True)
class I0:
    initial: object
    variable: str
    update: object


@dataclass(frozen=True)
class IS:
    count: object
    initial: object
    variable: str
    update: object


@dataclass(frozen=True)
class Use:
    index: int
    argument: object
    premise: object


@dataclass(frozen=True)
class DI:
    goal: object
    witness: object
    eigenvariable: str
    premise: object


@dataclass(frozen=True)
class DE:
    major: object
    eigenvariable: str
    conclusion: object
    premise: object


@dataclass(frozen=True)
class Replace:
    equality: object
    equation: object
    context: object


ZERO = Zero()
HOLE = Hole()
TRUTH = Eq(Iter(ZERO, ZERO, "u", ZERO), ZERO)


def require(condition, message):
    if not condition:
        raise InvalidProof(message)


def valid_name(name):
    require(type(name) is str and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", name),
            "variable names must be nonempty ASCII identifiers")


def term_ok(t, holes=False):
    if type(t) is Var:
        valid_name(t.name)
    elif type(t) is Zero:
        pass
    elif type(t) is Hole:
        require(holes, "a hole is not an object-language term")
    elif type(t) is Succ:
        term_ok(t.value, holes)
    elif type(t) is Iter:
        valid_name(t.variable)
        term_ok(t.count, holes)
        term_ok(t.initial, holes)
        term_ok(t.update, holes)
    else:
        raise InvalidProof("unknown numerical syntax")


def formula_ok(f):
    if type(f) is Eq:
        term_ok(f.left)
        term_ok(f.right)
    elif type(f) is D:
        valid_name(f.witness_variable)
        valid_name(f.counter_variable)
        require(f.witness_variable != f.counter_variable, "D binds distinct names")
        formula_ok(f.matrix)
    else:
        raise InvalidProof("unknown formula syntax")


def fv(t):
    """Free numerical names, for terms, formulas, clauses, or contexts."""
    if type(t) is Var:
        return {t.name}
    if type(t) in (Zero, Hole):
        return set()
    if type(t) is Succ:
        return fv(t.value)
    if type(t) is Iter:
        return fv(t.count) | fv(t.initial) | (fv(t.update) - {t.variable})
    if type(t) is Eq:
        return fv(t.left) | fv(t.right)
    if type(t) is D:
        return fv(t.matrix) - {t.witness_variable, t.counter_variable}
    if type(t) is Clause:
        return fv(t.antecedent) | (fv(t.consequent) - {t.variable})
    if type(t) is tuple:
        return set().union(*(fv(x) for x in t)) if t else set()
    raise InvalidProof("cannot compute free names of unknown syntax")


def names(t):
    """Every name, including bound and proof eigenvariable names."""
    if isinstance(t, str):
        return {t}
    if type(t) is tuple:
        return set().union(*(names(x) for x in t)) if t else set()
    if hasattr(t, "__dataclass_fields__"):
        return set().union(*(names(getattr(t, k)) for k in t.__dataclass_fields__))
    return set()


def fresh(avoid, prefix="v"):
    n = 0
    while prefix + str(n) in avoid:
        n += 1
    return prefix + str(n)


def key(t, bound=()):
    """Alpha-invariant syntax key.  Nearest binder has index zero."""
    if type(t) is Var:
        for n, v in enumerate(reversed(bound)):
            if v == t.name:
                return ("bound", n)
        return ("free", t.name)
    if type(t) is Zero:
        return ("zero",)
    if type(t) is Hole:
        return ("hole",)
    if type(t) is Succ:
        return ("S", key(t.value, bound))
    if type(t) is Iter:
        return ("I", key(t.count, bound), key(t.initial, bound),
                key(t.update, bound + (t.variable,)))
    if type(t) is Eq:
        return ("eq", key(t.left, bound), key(t.right, bound))
    if type(t) is D:
        return ("D", key(t.matrix, bound + (t.witness_variable, t.counter_variable)))
    raise InvalidProof("unknown syntax in alpha comparison")


def same(a, b):
    return key(a) == key(b)


def subst(t, variable, replacement):
    """Capture-avoiding substitution of a term for a free numerical name."""
    if type(t) is Var:
        return replacement if t.name == variable else t
    if type(t) in (Zero, Hole):
        return t
    if type(t) is Succ:
        return Succ(subst(t.value, variable, replacement))
    if type(t) is Eq:
        return Eq(subst(t.left, variable, replacement), subst(t.right, variable, replacement))
    if type(t) is Iter:
        n = subst(t.count, variable, replacement)
        a = subst(t.initial, variable, replacement)
        u, h = t.variable, t.update
        if u != variable:
            if u in fv(replacement) and variable in fv(h):
                v = fresh(names(t) | names(replacement) | {variable}, "b")
                h, u = subst(h, u, Var(v)), v
            h = subst(h, variable, replacement)
        return Iter(n, a, u, h)
    if type(t) is D:
        x, y, b = t.witness_variable, t.counter_variable, t.matrix
        if variable in (x, y):
            return t
        if variable in fv(b):
            avoid = names(t) | names(replacement) | {variable}
            if x in fv(replacement):
                z = fresh(avoid, "b")
                b, x = subst(b, x, Var(z)), z
                avoid.add(z)
            if y in fv(replacement):
                z = fresh(avoid, "b")
                b, y = subst(b, y, Var(z)), z
        return D(x, y, subst(b, variable, replacement))
    raise InvalidProof("unknown substitution syntax")


def subst_many(t, replacements):
    """Simultaneous substitution, using fresh temporary names."""
    avoid = names(t) | set(replacements)
    for v in replacements.values():
        avoid |= names(v)
    temporary = []
    for old, value in replacements.items():
        new = fresh(avoid, "tmp")
        avoid.add(new)
        t = subst(t, old, Var(new))
        temporary.append((new, value))
    for new, value in temporary:
        t = subst(t, new, value)
    return t


def holes(t):
    if type(t) is Hole:
        return 1
    if type(t) in (Var, Zero):
        return 0
    if type(t) is Succ:
        return holes(t.value)
    if type(t) is Iter:
        return holes(t.count) + holes(t.initial) + holes(t.update)
    raise InvalidProof("a replacement context must be numerical")


def plug(t, value):
    """Fill holes as external terms, renaming iterator binders if needed."""
    if type(t) is Hole:
        return value
    if type(t) in (Var, Zero):
        return t
    if type(t) is Succ:
        return Succ(plug(t.value, value))
    if type(t) is Iter:
        u, h = t.variable, t.update
        if holes(h) and u in fv(value):
            v = fresh(names(t) | names(value), "b")
            h, u = subst(h, u, Var(v)), v
        return Iter(plug(t.count, value), plug(t.initial, value), u, plug(h, value))
    raise InvalidProof("a hole may occur only in a numerical context")


def constant(f):
    return Clause(TRUTH, fresh(names(f), "unused"), f)


def instance(goal, witness, counter):
    return subst_many(goal.matrix, {goal.witness_variable: witness,
                                   goal.counter_variable: counter})


def opened(goal, eigen):
    x, y, b = goal.witness_variable, goal.counter_variable, goal.matrix
    # The new witness is free in the opened matrix.  In particular it must
    # not be captured by the counter binder when the two names coincide.
    if y == eigen:
        new = fresh(names(goal) | {eigen}, "counter")
        b, y = subst(b, y, Var(new)), new
    b = subst(b, x, Var(eigen))
    return Clause(subst(b, y, ZERO), y, b)


def di_context(ctx, goal, witness, eigen):
    result = ctx + (constant(instance(goal, witness, ZERO)),)
    if type(goal.matrix) is Eq:
        result += (constant(instance(goal, witness, Var(eigen))),)
    return result


def check(proof, context=()):
    """Infer and check a finite proof tree, raising InvalidProof on rejection."""
    require(type(context) is tuple, "context must be a tuple of clauses")
    for c in context:
        require(type(c) is Clause, "context entry is not a clause")
        formula_ok(c.antecedent)
        formula_ok(c.consequent)
        valid_name(c.variable)
        require(c.variable not in fv(c.antecedent), "clause binder occurs in antecedent")
    memo = {}
    active = set()

    def infer(p, ctx):
        cache_key = (id(p), ctx)
        if cache_key in memo:
            return memo[cache_key]
        require(id(p) not in active, "cyclic proof graph")
        active.add(id(p))
        if type(p) in (I0, IS):
            term_ok(p.initial)
            term_ok(p.update)
            valid_name(p.variable)
            if type(p) is I0:
                answer = Eq(Iter(ZERO, p.initial, p.variable, p.update), p.initial)
            else:
                term_ok(p.count)
                old = Iter(p.count, p.initial, p.variable, p.update)
                answer = Eq(Iter(Succ(p.count), p.initial, p.variable, p.update),
                            subst(p.update, p.variable, old))
        elif type(p) is Use:
            require(type(p.index) is int and 0 <= p.index < len(ctx), "invalid clause index")
            term_ok(p.argument)
            c = ctx[p.index]
            require(same(infer(p.premise, ctx), c.antecedent), "Use premise is not the antecedent")
            answer = subst(c.consequent, c.variable, p.argument)
        elif type(p) is DI:
            formula_ok(p.goal)
            require(type(p.goal) is D, "DI goal is not a paired formula")
            term_ok(p.witness)
            valid_name(p.eigenvariable)
            require(p.eigenvariable not in fv(ctx) | fv(p.goal) | fv(p.witness),
                    "DI eigenvariable is not fresh")
            local = di_context(ctx, p.goal, p.witness, p.eigenvariable)
            require(same(infer(p.premise, local), instance(p.goal, p.witness, Succ(Var(p.eigenvariable)))),
                    "DI minor conclusion is not the successor matrix")
            answer = p.goal
        elif type(p) is DE:
            major = infer(p.major, ctx)
            require(type(major) is D, "DE major is not a paired formula")
            formula_ok(p.conclusion)
            valid_name(p.eigenvariable)
            require(p.eigenvariable not in fv(ctx) | fv(major) | fv(p.conclusion),
                    "DE eigenvariable is not fresh")
            require(same(infer(p.premise, ctx + (opened(major, p.eigenvariable),)), p.conclusion),
                    "DE minor conclusion does not match")
            answer = p.conclusion
        elif type(p) is Replace:
            e = infer(p.equality, ctx)
            q = infer(p.equation, ctx)
            require(type(e) is Eq and type(q) is Eq, "Replace requires two equations")
            term_ok(p.context, holes=True)
            require(holes(p.context) == 1, "Replace context must contain exactly one hole")
            require(same(q.left, plug(p.context, e.left)), "Replace selected occurrence does not match")
            answer = Eq(plug(p.context, e.right), q.right)
        else:
            raise InvalidProof("unknown proof node")
        active.remove(id(p))
        formula_ok(answer)
        memo[cache_key] = answer
        return answer

    return infer(proof, context)


# The helpers below are untrusted proof producers: their outputs are checked by
# the same six-rule checker.  They are not new inference rules.

def truth_proof():
    return I0(ZERO, "u", ZERO)


def assumption(index):
    return Use(index, ZERO, truth_proof())


def reflexivity(term):
    p = I0(term, "u", ZERO)
    return Replace(p, p, HOLE)


def symmetry(proof, context=()):
    equation = check(proof, context)
    require(type(equation) is Eq, "symmetry needs an equation")
    return Replace(proof, reflexivity(equation.left), HOLE)


def freshen_term(t, avoid):
    if type(t) in (Var, Zero, Hole):
        return t
    if type(t) is Succ:
        return Succ(freshen_term(t.value, avoid))
    u, h = t.variable, t.update
    if u in avoid:
        v = fresh(names(t) | avoid, "bound")
        h, u = subst(h, u, Var(v)), v
    return Iter(freshen_term(t.count, avoid), freshen_term(t.initial, avoid),
                u, freshen_term(h, avoid | {u}))


def abstract(t, variable):
    if type(t) is Var:
        return HOLE if t.name == variable else t
    if type(t) is Zero:
        return t
    if type(t) is Succ:
        return Succ(abstract(t.value, variable))
    return Iter(abstract(t.count, variable), abstract(t.initial, variable), t.variable,
                t.update if t.variable == variable else abstract(t.update, variable))


def fill_separately(t, values):
    """Untrusted helper; binders must already be fresh for all values."""
    it = iter(values)
    def go(u):
        if type(u) is Hole:
            return next(it)
        if type(u) in (Var, Zero):
            return u
        if type(u) is Succ:
            return Succ(go(u.value))
        return Iter(go(u.count), go(u.initial), u.variable, go(u.update))
    return go(t)


def atomic_transport(equality, premise, template, variable, context=()):
    """Compile arbitrary atomic transport into one-occurrence replacements."""
    e = check(equality, context)
    require(type(e) is Eq and type(template) is Eq, "atomic transport requires equations")
    require(same(check(premise, context), subst(template, variable, e.left)), "atomic source mismatch")
    left = abstract(freshen_term(template.left, fv(e.left) | fv(e.right)), variable)
    right = abstract(freshen_term(template.right, fv(e.left) | fv(e.right)), variable)

    def rewrite(p, marked):
        count = holes(marked)
        for k in range(count):
            frozen = [e.right if j < k else HOLE if j == k else e.left for j in range(count)]
            p = Replace(equality, p, fill_separately(marked, frozen))
        return p

    result = rewrite(premise, left)
    if holes(right):
        result = symmetry(result, context)
        result = rewrite(result, right)
        result = symmetry(result, context)
    require(same(check(result, context), subst(template, variable, e.right)), "atomic compiler target mismatch")
    return result


def proof_subst(p, variable, replacement):
    """Substitute in a proof; replacement names must be globally fresh.

    Eigenvariables bind only their minor premises.  This helper is used solely
    for alpha-renaming them, with a freshly chosen variable replacement.
    """
    if type(p) in (I0, IS):
        t = Iter(ZERO if type(p) is I0 else p.count, p.initial, p.variable, p.update)
        t = subst(t, variable, replacement)
        return I0(t.initial, t.variable, t.update) if type(p) is I0 else IS(t.count, t.initial, t.variable, t.update)
    if type(p) is Use:
        return Use(p.index, subst(p.argument, variable, replacement), proof_subst(p.premise, variable, replacement))
    if type(p) is Replace:
        return Replace(proof_subst(p.equality, variable, replacement),
                       proof_subst(p.equation, variable, replacement), subst(p.context, variable, replacement))
    if type(p) is DI:
        minor = p.premise if p.eigenvariable == variable else proof_subst(p.premise, variable, replacement)
        return DI(subst(p.goal, variable, replacement), subst(p.witness, variable, replacement), p.eigenvariable, minor)
    if type(p) is DE:
        minor = p.premise if p.eigenvariable == variable else proof_subst(p.premise, variable, replacement)
        return DE(proof_subst(p.major, variable, replacement), p.eigenvariable,
                  subst(p.conclusion, variable, replacement), minor)
    raise InvalidProof("unknown proof syntax in renaming")


def freshen_proof(p, avoid):
    """Rename local eigenparameters before weakening into new assumptions."""
    used = names(p) | set(avoid)
    def go(q):
        if type(q) in (I0, IS):
            return q
        if type(q) is Use:
            return Use(q.index, q.argument, go(q.premise))
        if type(q) is Replace:
            return Replace(go(q.equality), go(q.equation), q.context)
        eigen, minor = q.eigenvariable, q.premise
        if eigen in avoid:
            new = fresh(used, "eigen")
            used.add(new)
            minor, eigen = proof_subst(minor, eigen, Var(new)), new
        if type(q) is DI:
            return DI(q.goal, q.witness, eigen, go(minor))
        if type(q) is DE:
            return DE(go(q.major), eigen, q.conclusion, go(minor))
        raise InvalidProof("unknown proof syntax in freshening")
    return go(p)


def weaken(proof, context, extra):
    """Append root assumptions, relocate local indices, and rename eigenvariables."""
    check(proof, context)
    proof = freshen_proof(proof, fv(extra))
    cutoff, offset = len(context), len(extra)
    def go(p):
        if type(p) in (I0, IS):
            return p
        if type(p) is Use:
            return Use(p.index + (offset if p.index >= cutoff else 0), p.argument, go(p.premise))
        if type(p) is Replace:
            return Replace(go(p.equality), go(p.equation), p.context)
        if type(p) is DI:
            return DI(p.goal, p.witness, p.eigenvariable, go(p.premise))
        if type(p) is DE:
            return DE(go(p.major), p.eigenvariable, p.conclusion, go(p.premise))
        raise InvalidProof("unknown proof syntax in weakening")
    result = go(proof)
    require(same(check(result, context + extra), check(proof, context)), "weakening changed conclusion")
    return result


def formula_transport(equality, premise, template, variable, context=()):
    """Compile full formula transport.  No full-transport node is emitted."""
    formula_ok(template)
    equality = freshen_proof(equality, names(template) | names(context))
    premise = freshen_proof(premise, names(template) | names(context))
    e = check(equality, context)
    require(type(e) is Eq, "formula transport needs an equation")
    require(same(check(premise, context), subst(template, variable, e.left)), "formula source mismatch")
    if variable not in fv(template):
        return premise
    if type(template) is Eq:
        return atomic_transport(equality, premise, template, variable, context)

    # Alpha-rename both bound names away from replacement terms.  The newly
    # opened eigenparameters are fresh for entire proof trees, not just goals.
    x, y, body = template.witness_variable, template.counter_variable, template.matrix
    avoid = names(template) | names(equality) | names(premise) | names(context)
    for which in (0, 1):
        old = x if which == 0 else y
        if old in fv(e.left) | fv(e.right):
            new = fresh(avoid, "bound")
            avoid.add(new)
            body = subst(body, old, Var(new))
            if which == 0:
                x = new
            else:
                y = new
    template = D(x, y, body)
    source = subst(template, variable, e.left)
    target = subst(template, variable, e.right)
    a = fresh(avoid, "witness")
    avoid.add(a)
    z = fresh(avoid, "counter")
    outer = context + (opened(source, a),)
    inner = di_context(outer, target, Var(a), z)
    base_template = instance(template, Var(a), ZERO)
    successor_template = instance(template, Var(a), Succ(Var(z)))
    base = assumption(len(outer))
    inner_equality = weaken(equality, context, inner[len(context):])
    converted_base = formula_transport(symmetry(inner_equality, inner), base, base_template, variable, inner)
    source_step = Use(len(context), Succ(Var(z)), converted_base)
    converted_step = formula_transport(inner_equality, source_step, successor_template, variable, inner)
    result = DE(premise, a, target, DI(target, Var(a), z, converted_step))
    require(same(check(result, context), target), "formula compiler target mismatch")
    return result


def proof_statistics(proof):
    """Count distinct DAG nodes and list the primitive node kinds used."""
    seen, counts = set(), {}
    def go(p):
        if id(p) in seen:
            return
        seen.add(id(p))
        name = type(p).__name__
        counts[name] = counts.get(name, 0) + 1
        if type(p) in (Use, DI):
            go(p.premise)
        elif type(p) is DE:
            go(p.major)
            go(p.premise)
        elif type(p) is Replace:
            go(p.equality)
            go(p.equation)
    go(proof)
    return {"nodes": len(seen), "kinds": counts}
