"""Targeted audit examples; run with `python3 test_checker.py` (also under -O)."""
import json
import unittest
from checker import *


class CheckerTests(unittest.TestCase):
    def test_zero_computation(self):
        p = I0(Var("a"), "u", Succ(Var("u")))
        self.assertTrue(same(check(p), Eq(Iter(ZERO, Var("a"), "u", Succ(Var("u"))), Var("a"))))

    def test_successor_computation(self):
        p = IS(Var("n"), Var("a"), "u", Succ(Var("u")))
        old = Iter(Var("n"), Var("a"), "u", Succ(Var("u")))
        self.assertTrue(same(check(p).right, Succ(old)))

    def test_successor_computation_avoids_update_capture(self):
        update = Iter(ZERO, ZERO, "u", Var("x"))
        p = IS(Var("u"), ZERO, "x", update)
        right = check(p).right
        self.assertNotEqual(right.variable, "u")
        self.assertIn("u", fv(right))

    def test_reflexivity_and_symmetry_are_derived(self):
        e = I0(Var("x"), "u", ZERO)
        self.assertTrue(same(check(reflexivity(Var("x"))), Eq(Var("x"), Var("x"))))
        self.assertTrue(same(check(symmetry(e)), Eq(check(e).right, check(e).left)))

    def test_clause_use(self):
        ctx = (Clause(TRUTH, "n", Eq(Var("n"), Var("n"))),)
        self.assertTrue(same(check(Use(0, Succ(ZERO), truth_proof()), ctx), Eq(Succ(ZERO), Succ(ZERO))))

    def test_one_hole_under_iterator_avoids_capture(self):
        e = I0(Var("u"), "v", ZERO)
        q = check(e)
        c = Iter(Var("n"), ZERO, "u", HOLE)
        p = Replace(e, reflexivity(plug(c, q.left)), c)
        result = check(p)
        self.assertIn("u", fv(result.left))
        self.assertNotEqual(result.left.variable, "u")
        self.assertTrue(same(result.left, plug(c, q.right)))

    def test_rejects_two_holes(self):
        e = reflexivity(ZERO)
        with self.assertRaises(InvalidProof):
            check(Replace(e, e, Iter(HOLE, HOLE, "u", ZERO)))

    def test_rejects_no_hole(self):
        e = reflexivity(ZERO)
        with self.assertRaises(InvalidProof):
            check(Replace(e, e, ZERO))

    def test_rejects_wrong_occurrence(self):
        e = I0(ZERO, "u", ZERO)
        with self.assertRaises(InvalidProof):
            check(Replace(e, reflexivity(Succ(ZERO)), HOLE))

    def test_rejects_bad_context_and_index(self):
        with self.assertRaises(InvalidProof):
            check(Use(0, ZERO, truth_proof()))
        with self.assertRaises(InvalidProof):
            check(truth_proof(), (Clause(Eq(Var("x"), ZERO), "x", TRUTH),))

    def test_atomic_transport_tracks_duplicate_template_occurrences(self):
        s, t, v = Var("s"), Var("t"), Var("v")
        duplicated = Iter(v, v, "u", Succ(v))
        template = Eq(duplicated, Iter(v, ZERO, "u", v))
        ctx = (constant(Eq(s, t)), constant(subst(template, "v", s)))
        p = atomic_transport(assumption(0), assumption(1), template, "v", ctx)
        self.assertTrue(same(check(p, ctx), subst(template, "v", t)))
        self.assertGreaterEqual(proof_statistics(p)["kinds"]["Replace"], 5)

    def test_accidental_equal_subterms_are_not_replaced(self):
        s, t, v = Var("s"), Var("t"), Var("v")
        template = Eq(Iter(v, s, "u", v), s)
        ctx = (constant(Eq(s, t)), constant(subst(template, "v", s)))
        p = atomic_transport(assumption(0), assumption(1), template, "v", ctx)
        self.assertTrue(same(check(p, ctx), subst(template, "v", t)))
        self.assertEqual(check(p, ctx).left.initial, s)
        self.assertEqual(check(p, ctx).right, s)

    def test_substitution_does_not_capture_bound_names(self):
        f = D("x", "y", Eq(Var("v"), Var("x")))
        result = subst(f, "v", Var("x"))
        self.assertIn("x", fv(result))
        self.assertNotEqual(result.witness_variable, "x")
        original = Iter(Var("v"), Var("v"), "u", Var("v"))
        self.assertIn("u", fv(subst(original, "v", Var("u"))))

    def test_DI_and_DE_valid(self):
        goal = D("x", "y", Eq(Var("x"), Var("x")))
        p = DI(goal, ZERO, "z", reflexivity(ZERO))
        self.assertTrue(same(check(p), goal))
        # Open its witness, supply the reflexive base, and use the clause.
        minor = Use(0, Succ(ZERO), reflexivity(Var("a")))
        de = DE(p, "a", Eq(Var("a"), Var("a")), minor)
        with self.assertRaises(InvalidProof):  # witness may not escape
            check(de)
        valid = DE(p, "a", TRUTH, truth_proof())
        self.assertTrue(same(check(valid), TRUTH))

    def test_DI_eigenvariable_rejected(self):
        goal = D("x", "y", Eq(Var("x"), Var("x")))
        with self.assertRaises(InvalidProof):
            check(DI(goal, Var("z"), "z", reflexivity(Var("z"))))

    def test_DE_counter_name_does_not_capture_the_witness(self):
        goal = D("x", "y", Eq(Var("x"), ZERO))
        major = DI(goal, ZERO, "z", reflexivity(ZERO))
        # If opened() binds the fresh witness y as the counter, this would
        # turn the true major into the false clause (0=0 => forall y y=0).
        false_conclusion = Eq(Succ(ZERO), ZERO)
        exploit = DE(major, "y", false_conclusion,
                     Use(0, Succ(ZERO), reflexivity(ZERO)))
        with self.assertRaises(InvalidProof):
            check(exploit)
        clause = opened(goal, "y")
        self.assertNotEqual(clause.variable, "y")
        self.assertIn("y", fv(clause.antecedent))
        self.assertIn("y", fv(clause.consequent))

    def test_DE_counter_name_collision_is_alpha_renamed(self):
        goal = D("x", "y", Eq(Var("y"), Var("y")))
        major = DI(goal, ZERO, "z", reflexivity(Succ(Var("z"))))
        conclusion = Eq(Succ(ZERO), Succ(ZERO))
        proof = DE(major, "y", conclusion,
                   Use(0, Succ(ZERO), reflexivity(ZERO)))
        self.assertTrue(same(check(proof), conclusion))

    def test_DI_bound_names_and_witness_use_simultaneous_substitution(self):
        counter_goal = D("x", "y", Eq(Var("y"), Var("y")))
        p = DI(counter_goal, ZERO, "y", reflexivity(Succ(Var("y"))))
        self.assertTrue(same(check(p), counter_goal))
        witness_goal = D("x", "y", Eq(Var("x"), Var("x")))
        p = DI(witness_goal, Var("y"), "z", reflexivity(Var("y")))
        self.assertTrue(same(check(p), witness_goal))
        p = DI(witness_goal, ZERO, "x", reflexivity(ZERO))
        self.assertTrue(same(check(p), witness_goal))

    def test_rejects_object_holes_and_malformed_syntax(self):
        with self.assertRaises(InvalidProof):
            check(I0(HOLE, "u", ZERO))
        with self.assertRaises(InvalidProof):
            check(I0(ZERO, "u", Succ(HOLE)))
        with self.assertRaises(InvalidProof):
            check(DI(D("x", "x", Eq(ZERO, ZERO)), ZERO, "z", reflexivity(ZERO)))
        with self.assertRaises(InvalidProof):
            check(I0(0, "u", ZERO))
        with self.assertRaises(InvalidProof):
            check(Use(True, ZERO, truth_proof()), (constant(TRUTH),))

    def test_rejects_cyclic_proof_graph(self):
        p = Use(0, ZERO, truth_proof())
        # Deliberately bypass dataclass immutability to attack the API boundary.
        object.__setattr__(p, "premise", p)
        with self.assertRaises(InvalidProof):
            check(p, (constant(TRUTH),))

    def test_equation_induction_assumption_is_present(self):
        # Constant atomic family: select its optional induction hypothesis.
        goal = D("x", "y", Eq(Var("x"), Var("x")))
        p = DI(goal, ZERO, "z", assumption(1))
        self.assertTrue(same(check(p), goal))

    def test_compound_matrix_has_no_induction_assumption(self):
        goal = D("x", "y", D("a", "b", Eq(ZERO, ZERO)))
        with self.assertRaises(InvalidProof):
            check(DI(goal, ZERO, "z", assumption(1)))

    def test_full_transport_at_depth_two(self):
        s, t, v = Var("s"), Var("t"), Var("v")
        template = D("x", "y", D("a", "b", Eq(Iter(v, v, "u", Var("x")),
                                                            Iter(v, Var("y"), "u", Var("a")))))
        ctx = (constant(Eq(s, t)), constant(subst(template, "v", s)))
        p = formula_transport(assumption(0), assumption(1), template, "v", ctx)
        self.assertTrue(same(check(p, ctx), subst(template, "v", t)))
        stats = proof_statistics(p)
        self.assertEqual(stats["kinds"]["DE"], 3)
        self.assertEqual(stats["kinds"]["DI"], 3)
        self.assertNotIn("Transport", stats["kinds"])

    def test_weakening_relocates_local_indices_and_freshens_eigen(self):
        goal = D("x", "y", Eq(ZERO, ZERO))
        p = DI(goal, ZERO, "z", assumption(1))
        extra = (constant(Eq(Var("z"), Var("z"))),)
        weakened = weaken(p, (), extra)
        self.assertNotEqual(weakened.eigenvariable, "z")
        self.assertEqual(weakened.premise.index, 2)
        self.assertTrue(same(check(weakened, extra), goal))

    def test_formula_transport_with_bound_name_in_replacement(self):
        template = D("x", "y", Eq(Var("v"), Var("x")))
        s, t = Var("s"), Var("x")
        ctx = (constant(Eq(s, t)), constant(subst(template, "v", s)))
        p = formula_transport(assumption(0), assumption(1), template, "v", ctx)
        self.assertTrue(same(check(p, ctx), subst(template, "v", t)))
        self.assertIn("x", fv(check(p, ctx)))

    def test_transport_freshens_equality_proof_before_weakening(self):
        computation = I0(Var("s"), "u", ZERO)
        equation = check(computation)
        # k is local in the equality proof but free in the transported formula.
        major_goal = D("a", "b", equation)
        major = DI(major_goal, ZERO, "k", computation)
        equality = DE(major, "local", equation, computation)
        term = Iter(Var("v"), Var("k"), "u", Var("x"))
        template = D("x", "y", Eq(term, term))
        source = subst(template, "v", equation.left)
        source_term = instance(source, ZERO, Succ(Var("z"))).left
        premise = DI(source, ZERO, "z", reflexivity(source_term))
        result = formula_transport(equality, premise, template, "v")
        self.assertTrue(same(check(result), subst(template, "v", equation.right)))


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CheckerTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    print(json.dumps({"tests": result.testsRun, "failures": len(result.failures),
                      "errors": len(result.errors), "successful": result.wasSuccessful()}, sort_keys=True))
    raise SystemExit(0 if result.wasSuccessful() else 1)
