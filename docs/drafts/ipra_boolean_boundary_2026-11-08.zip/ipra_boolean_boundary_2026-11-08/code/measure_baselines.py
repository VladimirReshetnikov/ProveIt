"""Remeasure all nine current submitted programs; no candidate-size claim."""
import json
import platform
from pathlib import Path
from source_measure import metrics

ROOT = Path(__file__).resolve().parent.parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    rows = []
    for path in sorted((ROOT / 'reference').glob('*__checker*.py')):
        rows.append({'file': path.name, **metrics(path)})
    if len(rows) != 9:
        raise RuntimeError('Expected exactly the nine submitted root programs')
    result = {
        'python': platform.python_version(),
        'commit': '6fac3001a902d6666186fc4692a96de0ef296cf7',
        'program_count': len(rows),
        'coordinatewise_minimum': {k: min(r[k] for r in rows) for k in FIELDS},
        'programs': rows,
        'note': 'Whole programs are measured. The local-calculus API has a different '
                'boundary and is not entered as a competing size benchmark.'
    }
    dest = ROOT / 'results' / 'baseline_measurements.json'
    dest.write_text(json.dumps(result, indent=2) + '\n')
    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Current program & Tokens & AST & Bytes\\', r'\midrule']
    for row in rows:
        name = row['file'].replace('ipra_', '').replace('_2026-11-08', '')
        name = name.replace('__', ' / ').replace('_', r'\_')
        lines.append(name + ' & ' + ' & '.join(str(row[k]) for k in FIELDS) + r'\\')
    lines.extend([r'\midrule', 'Coordinatewise minima & ' +
                  ' & '.join(str(result['coordinatewise_minimum'][k]) for k in FIELDS) + r'\\',
                  r'\bottomrule', r'\end{tabular}'])
    (ROOT / 'results' / 'baseline_table.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: result[k] for k in ('python', 'program_count', 'coordinatewise_minimum')}, sort_keys=True))


if __name__ == '__main__':
    main()
