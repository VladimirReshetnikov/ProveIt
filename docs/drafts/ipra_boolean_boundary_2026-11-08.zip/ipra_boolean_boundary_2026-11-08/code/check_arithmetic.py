"""Finite checks of the displayed scalar terms and product counterexample.

These are standard-model calculations, not a verification of the induction
schema, the infinite product theorem, or bi-interpretability. The paper gives
those proofs. Cached orbit prefixes keep the inherited scalar terms practical.
"""
import json
from itertools import product
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def iterate(n, initial, update):
    state = initial
    for unused in range(n):
        state = update(state)
    return state


def C(n, a, b):
    # Exact evaluation of a constant-update orbit: the first step returns b,
    # and every later step returns b again.
    return a if n == 0 else b


def Z(n):
    return C(n, 1, 0)


class Orbit:
    """Memoize one fixed scalar iteration, extending its state list as needed."""
    def __init__(self, initial, update):
        self.states = [initial]
        self.update = update

    def __call__(self, n):
        while len(self.states) <= n:
            self.states.append(self.update(self.states[-1]))
        return self.states[n]


N = Orbit(0, Z)
M = Orbit(0, lambda u: Z(u) + N(u) + N(u))
G = Orbit(0, lambda u: 1 + u + M(u))
E = Orbit(1, lambda u: u + u)


def H(u):
    return C(N(u), G(u), u)


def L(x, y):
    return N(iterate(y, E(x), H))


def V(t, m):
    return iterate(t, 0, lambda u: C(L(u + 2, m), u, u + 1))


def P(m):
    return V(m, m)


def main():
    checks = {}

    def require(group, condition):
        if not condition:
            raise RuntimeError('Failed arithmetic check: ' + group)
        checks[group] = checks.get(group, 0) + 1

    for n in range(25):
        require('selector_retraction', Z(Z(Z(n))) == Z(n))
        require('parity_retraction', N(n) == Z(Z(N(n))))
        require('parity_range', N(n) in (0, 1))
        require('parity_scale', N(2 * n) == 0 and N(2 * n + 1) == 1 and N(3 * n) == N(n))
        require('ramp_invariant', M(G(n)) == N(n))
        require('ramp_scale', G(2 * n) == 3 * n and G(3 * n) == 3 * G(n) + N(n))
        require('factor_scale', H(2 * n) == 3 * n and H(3 * n) == 3 * H(n))
    for x, y in product(range(6), repeat=2):
        require('comparator', L(0, y) == 1 and L(x + 1, 0) == 0 and L(x + 1, y + 1) == L(x, y))
    for t, m in product(range(5), repeat=2):
        require('shifted_orbit', V(t + 1, m + 2) == 1 + V(t, m + 1))
    for n in range(7):
        require('predecessor', P(n) == max(0, n - 1))
        require('coverage_equation', n == C(Z(n), P(n) + 1, 0))

    # Finite truth tables used by endpoint equation induction in the paper.
    meet = lambda a, b: C(a, 0, b)
    join = lambda a, b: C(a, b, 1)
    for a, b, c in product((0, 1), repeat=3):
        require('boolean_laws',
                meet(a, b) == meet(b, a) and join(a, b) == join(b, a)
                and meet(a, join(b, c)) == join(meet(a, b), meet(a, c))
                and join(a, meet(b, c)) == meet(join(a, b), join(a, c))
                and meet(a, Z(a)) == 0 and join(a, Z(a)) == 1)

    sample = (0, 1)
    z_sample = tuple(Z(x) for x in sample)
    require('product_counterexample', sample != (0, 0) and 0 in sample)
    require('mixed_boolean', z_sample != (0, 0) and z_sample != (1, 1))
    swap = lambda a: (a[1], a[0])
    for a, b in product(product(range(3), repeat=2), repeat=2):
        require('coordinate_swap',
                swap(swap(a)) == a
                and swap(tuple(a[i] + b[i] for i in range(2)))
                == tuple(swap(a)[i] + swap(b)[i] for i in range(2)))

    result = {'status': 'PASS', 'checks': checks, 'total': sum(checks.values()),
              'predecessor_values': [P(n) for n in range(7)],
              'mixed_boolean_example': {'input': sample, 'Z': z_sample},
              'scope': 'Finite standard-model and two-coordinate sanity checks only; universal proofs are in the paper.'}
    (ROOT / 'results' / 'arithmetic_checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
