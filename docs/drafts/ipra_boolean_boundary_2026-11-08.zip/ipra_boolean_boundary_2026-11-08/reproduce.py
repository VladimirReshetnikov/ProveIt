"""Run the focused supporting checks, measurements, and optional PDF build."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(relative, optimized=False):
    command = [sys.executable] + (['-O'] if optimized else []) + [str(ROOT / relative)]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr)
        raise SystemExit(result.returncode)
    lines = [line for line in result.stdout.splitlines() if line.startswith('{')]
    receipt = json.loads(lines[-1]) if lines else {'stdout': result.stdout.strip()}
    return {'program': relative, 'optimized': optimized, 'result': receipt}


def main():
    results = [run('code/measure_baselines.py'), run('code/check_arithmetic.py'),
               run('code/local_calculus/test_checker.py'),
               run('code/local_calculus/test_checker.py', optimized=True)]
    if '--pdf' in sys.argv:
        results.append(run('build.py'))
    receipt = {'status': 'PASS', 'runs': results,
               'scope': 'Executable audits and reproducible measurements; the universal metatheorems are written proofs.'}
    (ROOT / 'results' / 'reproduction.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
