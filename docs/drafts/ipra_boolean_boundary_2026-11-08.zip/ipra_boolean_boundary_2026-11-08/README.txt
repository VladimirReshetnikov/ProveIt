A BOOLEAN BOUNDARY FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
=================================================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

Start with report.pdf. report.tex, sections/, appendices/, and the small
generated results/baseline_table.tex are the complete editable source.

RESULTS
-------
1. Over scalar iteration and literal-equation induction, replace numerical
   coverage by Z(n)=0 or Z(n)=1, where Z(n)=I(n,1;u.0). A full internal
   construction derives predecessor before using numerical coverage.
   The ordinary theories are deductively equivalent by identity, with
   the falsity bridge retained. This preserves full iPRA bi-interpretability.
2. The current clausal native system needs equality replacement at just
   one numerical occurrence on the left of an equation. All formula-valued
   transport is derived. The complete four-rule basis is stated explicitly.
3. A product-preserving equational replacement cannot be bi-interpretable
   with iPRA through any ordinary definable domain or quotient, even with
   finitely many parameters. Coordinate transpositions and the definable
   arithmetic linear order give a direct obstruction.
4. The canonical Boolean core, the fixed points of Z^2, explains the
   boundary: product models have mixed Boolean elements; the new axiom
   requires exactly the two designated Boolean points. In classical
   models this is equivalent to direct indecomposability of the underlying
   scalar algebra; nontrivial core elements split it into two models of
   the equational base.

CLAIM BOUNDARY
--------------
This archive does NOT establish a new checker below the whole current
322-token / 350-AST-node / 903-normalized-byte envelope, a language-independent
minimum, or the significant positive breakthrough requested. The improvements
are mathematical and exact, but limited. The metatheorems are written proofs
with independent review, not a Lean/Rocq formalization.

The readable checker is a finite Python proof-tree API, not a serialized
certificate service or a size contender. It checks only I0, IS, Use, DI, DE,
and one-occurrence Replace. General transport is an untrusted proof producer
whose outputs replay through those primitive rules.

REPRODUCE
---------
  python3 reproduce.py
  python3 reproduce.py --pdf

The first command runs the source measurements and finite arithmetic checks,
and runs the proof-tree audits both normally and under python3 -O. The second also
builds the PDF. Python 3.12.14 was used. Rebuilding the PDF requires pdfLaTeX
and the packages declared in report.tex. Neither command uses the network.

CONTENTS
--------
report.tex / report.pdf       Paper and complete main TeX source
sections/, appendices/        New proofs and attributed inherited developments
code/local_calculus/          Readable checker, proof producers, focused tests
code/check_arithmetic.py      Finite arithmetic and product calculations
code/measure_baselines.py     Current nine-program measurement
code/source_measure.py       Exact inherited normalization implementation
reference/                   Commit metadata, source excerpts, nine comparators
results/                     Measurement and audit receipts
build.py / reproduce.py       Offline reproduction scripts
ATTRIBUTION.txt               New/inherited contribution boundaries
MANIFEST.sha256               Final package hashes

Pinned source commit: 6fac3001a902d6666186fc4692a96de0ef296cf7
Repository: https://github.com/VladimirReshetnikov/ProveIt
No changes were pushed to the repository.
