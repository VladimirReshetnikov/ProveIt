#!/usr/bin/env python3
"""Rebuild the report and rerun its explicitly scoped checks.

Requires Python 3.10+, pdflatex, and optionally core Lean 4.19.0.
The Python checks use only the standard library.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def run(command: list[str], root: Path) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command, cwd=root, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False,
    )
    if result.returncode:
        print(result.stdout, end="")
        raise SystemExit(result.returncode)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Absolute path to a Lean executable")
    parser.add_argument("--skip-pdf", action="store_true",
                        help="Run checks without rebuilding the PDF")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)

    syntax = run(
        [sys.executable, "checks/check_schema.py", "--json",
         "audit/schema_check_results.json"], root,
    )
    print(syntax.stdout, end="")
    countermodel = run(
        [sys.executable, "checks/check_two_slot_countermodel.py"], root,
    )
    table_report = json.loads(countermodel.stdout)
    assert table_report["status"] == "passed"
    (audit / "countermodel_check_results.json").write_text(
        json.dumps(table_report, indent=2) + "\n", encoding="utf-8",
    )
    print("PASS: two-slot countermodel tables and induction checks.")
    rewrite = run(
        [sys.executable, "checks/check_rewrite_variant.py", "--json",
         "audit/rewrite_check_results.json"], root,
    )
    print(rewrite.stdout, end="")

    lean = args.lean or shutil.which("lean")
    if lean:
        version = run([lean, "--version"], root).stdout
        checked = run([lean, "formal/DiagonalSchema.lean"], root)
        (audit / "lean_validation.txt").write_text(
            "Command: lean formal/DiagonalSchema.lean\n"
            + version + checked.stdout + "Exit status: 0\n",
            encoding="utf-8",
        )
        expected = "does not depend on any axioms"
        if checked.stdout.count(expected) != 8:
            raise SystemExit("Unexpected Lean endpoint audit; inspect the log.")
        print("PASS: Lean kernel; eight endpoints have no axiom dependencies.")
    else:
        print("SKIP: Lean executable unavailable; existing validation log retained.")

    if not args.skip_pdf:
        compiler = shutil.which("pdflatex")
        if not compiler:
            raise SystemExit("pdflatex is required to rebuild report.pdf")
        os.environ.setdefault("SOURCE_DATE_EPOCH", "1793491200")
        transcripts = []
        for pass_number in (1, 2):
            result = run(
                [compiler, "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", "report.tex"], root,
            )
            transcripts.append(f"PASS {pass_number}\n{result.stdout}")
        (audit / "latex_build.txt").write_text(
            "\n".join(transcripts), encoding="utf-8",
        )
        final_log = (root / "report.log").read_text(encoding="utf-8")
        bad_markers = (
            "Overfull ", "There were undefined references",
            "undefined on input line", "Label(s) may have changed",
        )
        found = [item for item in bad_markers if item in final_log]
        if found:
            raise SystemExit("LaTeX needs review: " + ", ".join(found))
        print("PASS: report.pdf compiled; no overfull boxes or unresolved references.")


if __name__ == "__main__":
    main()
