/-
  DiagonalSchema.lean -- core Lean 4.19.0, no Mathlib.

  Exact scope: an explicit term/formula syntax, literal admission after
  substitution, and a constructive proof that the diagonal schema for a
  fixed recursion symbol is equivalent to its two recursion equations plus
  quantifier-free induction with one parameter. The final theorem combines
  all recursion symbols and the independent separation axiom.

  This file does not formalize the arithmetic pairing bootstrap, the compiler
  for arbitrary primitive recursion, or the bi-interpretation round trips.
  No claim that those remaining arguments are machine checked is intended.
-/

namespace DiagonalSchema

inductive Term (F V : Type) where
  | var : V → Term F V
  | zero : Term F V
  | succ : Term F V → Term F V
  | app : F → Term F V → Term F V → Term F V

inductive Formula (F V : Type) where
  | bot : Formula F V
  | equal : Term F V → Term F V → Formula F V
  | and : Formula F V → Formula F V → Formula F V
  | or : Formula F V → Formula F V → Formula F V
  | imp : Formula F V → Formula F V → Formula F V

structure Model (F D : Type) where
  zero : D
  succ : D → D
  app : F → D → D → D

variable {F V W U D : Type}

theorem congrBinary {α β γ : Type} (f : α → β → γ)
    {a a' : α} {b b' : β} (ha : a = a') (hb : b = b') :
    f a b = f a' b' := by
  cases ha
  cases hb
  rfl

def Term.subst (σ : V → Term F W) : Term F V → Term F W
  | .var v => σ v
  | .zero => .zero
  | .succ t => .succ (t.subst σ)
  | .app f s t => .app f (s.subst σ) (t.subst σ)

def Formula.subst (σ : V → Term F W) : Formula F V → Formula F W
  | .bot => .bot
  | .equal s t => .equal (s.subst σ) (t.subst σ)
  | .and A B => .and (A.subst σ) (B.subst σ)
  | .or A B => .or (A.subst σ) (B.subst σ)
  | .imp A B => .imp (A.subst σ) (B.subst σ)

def Term.eval (M : Model F D) (ρ : V → D) : Term F V → D
  | .var v => ρ v
  | .zero => M.zero
  | .succ t => M.succ (t.eval M ρ)
  | .app f s t => M.app f (s.eval M ρ) (t.eval M ρ)

def Formula.Holds (M : Model F D) (ρ : V → D) : Formula F V → Prop
  | .bot => False
  | .equal s t => s.eval M ρ = t.eval M ρ
  | .and A B => A.Holds M ρ ∧ B.Holds M ρ
  | .or A B => A.Holds M ρ ∨ B.Holds M ρ
  | .imp A B => A.Holds M ρ → B.Holds M ρ

theorem Term.subst_congr (t : Term F V) {σ τ : V → Term F W}
    (h : ∀ v, σ v = τ v) : t.subst σ = t.subst τ := by
  induction t with
  | var v => exact h v
  | zero => rfl
  | succ t ih => exact congrArg Term.succ ih
  | app f s t ihs iht =>
      exact congrBinary (Term.app f) ihs iht

theorem Formula.subst_congr (A : Formula F V) {σ τ : V → Term F W}
    (h : ∀ v, σ v = τ v) : A.subst σ = A.subst τ := by
  induction A with
  | bot => rfl
  | equal s t =>
      exact congrBinary Formula.equal (s.subst_congr h) (t.subst_congr h)
  | and A B ihA ihB => exact congrBinary Formula.and ihA ihB
  | or A B ihA ihB => exact congrBinary Formula.or ihA ihB
  | imp A B ihA ihB => exact congrBinary Formula.imp ihA ihB

theorem Term.subst_comp (t : Term F V) (σ : V → Term F W)
    (τ : W → Term F U) :
    (t.subst σ).subst τ = t.subst (fun v => (σ v).subst τ) := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => exact congrArg Term.succ ih
  | app f s t ihs iht => exact congrBinary (Term.app f) ihs iht

theorem Formula.subst_comp (A : Formula F V) (σ : V → Term F W)
    (τ : W → Term F U) :
    (A.subst σ).subst τ = A.subst (fun v => (σ v).subst τ) := by
  induction A with
  | bot => rfl
  | equal s t =>
      exact congrBinary Formula.equal (s.subst_comp σ τ) (t.subst_comp σ τ)
  | and A B ihA ihB => exact congrBinary Formula.and ihA ihB
  | or A B ihA ihB => exact congrBinary Formula.or ihA ihB
  | imp A B ihA ihB => exact congrBinary Formula.imp ihA ihB

theorem Term.eval_subst (M : Model F D) (ρ : W → D)
    (σ : V → Term F W) (t : Term F V) :
    (t.subst σ).eval M ρ = t.eval M (fun v => (σ v).eval M ρ) := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => exact congrArg M.succ ih
  | app f s t ihs iht => exact congrBinary (M.app f) ihs iht

theorem Formula.holds_subst (M : Model F D) (ρ : W → D)
    (σ : V → Term F W) (A : Formula F V) :
    (A.subst σ).Holds M ρ ↔
      A.Holds M (fun v => (σ v).eval M ρ) := by
  induction A with
  | bot => exact Iff.rfl
  | equal s t =>
      change ((s.subst σ).eval M ρ = (t.subst σ).eval M ρ) ↔ _
      rw [s.eval_subst, t.eval_subst]
      exact Iff.rfl
  | and A B ihA ihB =>
      exact ⟨fun h => ⟨ihA.mp h.1, ihB.mp h.2⟩,
        fun h => ⟨ihA.mpr h.1, ihB.mpr h.2⟩⟩
  | or A B ihA ihB =>
      exact ⟨fun h => h.elim (fun a => Or.inl (ihA.mp a))
        (fun b => Or.inr (ihB.mp b)),
        fun h => h.elim (fun a => Or.inl (ihA.mpr a))
          (fun b => Or.inr (ihB.mpr b))⟩
  | imp A B ihA ihB =>
      exact ⟨fun h a => ihB.mp (h (ihA.mpr a)),
        fun h a => ihB.mpr (h (ihA.mp a))⟩

theorem Term.eval_congr (M : Model F D) (t : Term F V)
    {ρ η : V → D} (h : ∀ v, ρ v = η v) : t.eval M ρ = t.eval M η := by
  induction t with
  | var v => exact h v
  | zero => rfl
  | succ t ih => exact congrArg M.succ ih
  | app f s t ihs iht => exact congrBinary (M.app f) ihs iht

theorem Formula.holds_congr (M : Model F D) (A : Formula F V)
    {ρ η : V → D} (h : ∀ v, ρ v = η v) :
    A.Holds M ρ ↔ A.Holds M η := by
  induction A with
  | bot => exact Iff.rfl
  | equal s t =>
      change s.eval M ρ = t.eval M ρ ↔ s.eval M η = t.eval M η
      rw [s.eval_congr M h, t.eval_congr M h]
  | and A B ihA ihB =>
      exact ⟨fun h => ⟨ihA.mp h.1, ihB.mp h.2⟩,
        fun h => ⟨ihA.mpr h.1, ihB.mpr h.2⟩⟩
  | or A B ihA ihB =>
      exact ⟨fun h => h.elim (fun a => Or.inl (ihA.mp a))
        (fun b => Or.inr (ihB.mp b)),
        fun h => h.elim (fun a => Or.inl (ihA.mpr a))
          (fun b => Or.inr (ihB.mpr b))⟩
  | imp A B ihA ihB =>
      exact ⟨fun h a => ihB.mp (h (ihA.mpr a)),
        fun h a => ihB.mpr (h (ihA.mp a))⟩

inductive Var2 where
  | counter
  | seed

inductive Var3 where
  | counter
  | slot
  | seed

def env2 (n a : D) : Var2 → D
  | .counter => n
  | .seed => a

def env3 (n z a : D) : Var3 → D
  | .counter => n
  | .slot => z
  | .seed => a

def baseSub (r : F) : Var3 → Term F Unit
  | .counter => .zero
  | .slot => .app r .zero (.var ())
  | .seed => .var ()

def diagonalSub : Var3 → Term F Var2
  | .counter => .var .counter
  | .slot => .var .seed
  | .seed => .var .seed

def Admitted (r : F) (A : Formula F Var3) : Prop :=
  ∃ B : Formula F Unit, A.subst (baseSub r) = .imp B B

def QFI1 (M : Model F D) : Prop :=
  ∀ A : Formula F Var2, ∀ a,
    A.Holds M (env2 M.zero a) →
    (∀ n, A.Holds M (env2 n a) → A.Holds M (env2 (M.succ n) a)) →
    ∀ n, A.Holds M (env2 n a)

def RecZero (M : Model F D) (r : F) : Prop :=
  ∀ a, M.app r M.zero a = a

def RecSucc (M : Model F D) (r : F) (h : D → D → D) : Prop :=
  ∀ n a, M.app r (M.succ n) a = h n (M.app r n a)

def Diagonal (M : Model F D) (r : F) (h : D → D → D) : Prop :=
  ∀ A : Formula F Var3, Admitted r A → ∀ a,
    (∀ n, A.Holds M (env3 n a a) →
      A.Holds M (env3 (M.succ n) a a)) →
    ∀ n, A.Holds M (env3 n a a) ∧
      M.app r (M.succ n) a = h n (M.app r n a)

theorem admitted_base (M : Model F D) (r : F) (A : Formula F Var3)
    (adm : Admitted r A) (a : D) :
    A.Holds M (env3 M.zero (M.app r M.zero a) a) := by
  obtain ⟨B, equation⟩ := adm
  have truth : (A.subst (baseSub r)).Holds M (fun _ => a) := by
    rw [equation]
    exact fun b => b
  have unfolded := (A.holds_subst M (fun _ => a) (baseSub r)).mp truth
  exact (A.holds_congr M (fun v => by cases v <;> rfl)).mp unfolded

theorem diagonal_holds (M : Model F D) (A : Formula F Var3) (n a : D) :
    (A.subst diagonalSub).Holds M (env2 n a) ↔
      A.Holds M (env3 n a a) := by
  exact (A.holds_subst M (env2 n a) diagonalSub).trans
    (A.holds_congr M (fun v => by cases v <;> rfl))

def initializationProbe (r : F) : Formula F Var3 :=
  .imp (.equal (.var .slot) (.var .slot))
    (.equal (.var .slot) (.app r .zero (.var .seed)))

theorem probe_admitted (r : F) : Admitted r (initializationProbe r) := by
  exact ⟨.equal (.app r .zero (.var ())) (.app r .zero (.var ())), rfl⟩

theorem diagonal_recZero (M : Model F D) (r : F) (h : D → D → D)
    (schema : Diagonal M r h) : RecZero M r := by
  intro a
  have out := schema (initializationProbe r) (probe_admitted r) a
    (fun _ hyp => hyp) M.zero
  exact (out.1 rfl).symm

theorem diagonal_recSucc (M : Model F D) (r : F) (h : D → D → D)
    (schema : Diagonal M r h) : RecSucc M r h := by
  intro n a
  have admitted : Admitted r (.imp .bot .bot) := ⟨.bot, rfl⟩
  exact (schema (.imp .bot .bot) admitted a (fun _ hyp => hyp) n).2

def liftCurrent : Var2 → Term F Var3
  | .counter => .var .counter
  | .seed => .var .seed

def liftZero : Var2 → Term F Var3
  | .counter => .zero
  | .seed => .var .seed

def oneBase : Var2 → Term F Unit
  | .counter => .zero
  | .seed => .var ()

def normalized (A : Formula F Var2) : Formula F Var3 :=
  .imp (A.subst liftZero) (A.subst liftCurrent)

theorem normalized_admitted (r : F) (A : Formula F Var2) :
    Admitted r (normalized A) := by
  have left : (A.subst liftZero).subst (baseSub r) = A.subst oneBase :=
    (A.subst_comp liftZero (baseSub r)).trans
      (A.subst_congr (fun v => by cases v <;> rfl))
  have right : (A.subst liftCurrent).subst (baseSub r) = A.subst oneBase :=
    (A.subst_comp liftCurrent (baseSub r)).trans
      (A.subst_congr (fun v => by cases v <;> rfl))
  exact ⟨A.subst oneBase, congrBinary Formula.imp left right⟩

theorem normalized_holds (M : Model F D) (A : Formula F Var2)
    (n a : D) : (normalized A).Holds M (env3 n a a) ↔
      (A.Holds M (env2 M.zero a) → A.Holds M (env2 n a)) := by
  have left : (A.subst liftZero).Holds M (env3 n a a) ↔
      A.Holds M (env2 M.zero a) :=
    (A.holds_subst M (env3 n a a) liftZero).trans
      (A.holds_congr M (fun v => by cases v <;> rfl))
  have right : (A.subst liftCurrent).Holds M (env3 n a a) ↔
      A.Holds M (env2 n a) :=
    (A.holds_subst M (env3 n a a) liftCurrent).trans
      (A.holds_congr M (fun v => by cases v <;> rfl))
  exact ⟨fun f p => right.mp (f (left.mpr p)),
    fun f p => right.mpr (f (left.mp p))⟩

theorem diagonal_qfi (M : Model F D) (r : F) (h : D → D → D)
    (schema : Diagonal M r h) : QFI1 M := by
  intro A a initial progress n
  have normalizedProgress : ∀ k,
      (normalized A).Holds M (env3 k a a) →
      (normalized A).Holds M (env3 (M.succ k) a a) := by
    intro k assumption
    apply (normalized_holds M A (M.succ k) a).mpr
    intro base
    exact progress k ((normalized_holds M A k a).mp assumption base)
  have conclusion := schema (normalized A) (normalized_admitted r A)
    a normalizedProgress n
  exact (normalized_holds M A n a).mp conclusion.1 initial

theorem kernel_diagonal (M : Model F D) (r : F) (h : D → D → D)
    (initial : RecZero M r) (successor : RecSucc M r h)
    (induction : QFI1 M) : Diagonal M r h := by
  intro A admitted a progress n
  have base : A.Holds M (env3 M.zero a a) := by
    have result := admitted_base M r A admitted a
    rw [initial a] at result
    exact result
  have matrixBase := (diagonal_holds M A M.zero a).mpr base
  have matrixProgress : ∀ k,
      (A.subst diagonalSub).Holds M (env2 k a) →
      (A.subst diagonalSub).Holds M (env2 (M.succ k) a) := by
    intro k assumption
    exact (diagonal_holds M A (M.succ k) a).mpr
      (progress k ((diagonal_holds M A k a).mp assumption))
  have result := induction (A.subst diagonalSub) a matrixBase matrixProgress n
  exact ⟨(diagonal_holds M A n a).mp result, successor n a⟩

theorem diagonal_iff_kernel (M : Model F D) (r : F) (h : D → D → D) :
    Diagonal M r h ↔ RecZero M r ∧ RecSucc M r h ∧ QFI1 M := by
  exact ⟨fun schema => ⟨diagonal_recZero M r h schema,
    diagonal_recSucc M r h schema, diagonal_qfi M r h schema⟩,
    fun kernel => kernel_diagonal M r h kernel.1 kernel.2.1 kernel.2.2⟩

def Separation (M : Model F D) : Prop := M.zero ≠ M.succ M.zero

theorem complete_family_equivalence (M : Model F D) (selected : F)
    (updates : F → D → D → D) :
    (Separation M ∧ ∀ r, Diagonal M r (updates r)) ↔
      (Separation M ∧ (∀ r, RecZero M r) ∧
        (∀ r, RecSucc M r (updates r)) ∧ QFI1 M) := by
  constructor
  · intro source
    exact ⟨source.1, (fun r => diagonal_recZero M r (updates r) (source.2 r)),
      (fun r => diagonal_recSucc M r (updates r) (source.2 r)),
      diagonal_qfi M selected (updates selected) (source.2 selected)⟩
  · intro target
    exact ⟨target.1, fun r => kernel_diagonal M r (updates r)
      (target.2.1 r) (target.2.2.1 r) target.2.2.2⟩

#print axioms probe_admitted
#print axioms normalized_admitted
#print axioms diagonal_recZero
#print axioms diagonal_recSucc
#print axioms diagonal_qfi
#print axioms kernel_diagonal
#print axioms diagonal_iff_kernel
#print axioms complete_family_equivalence

end DiagonalSchema
