#!/usr/bin/env python3
"""Reproducible syntax checks for the diagonal PRA schema.

This checks literal syntax, variable scopes, a finite collection of description
dependencies, and the disclosed partial syntax-tree metric.  It is not a proof
of the arithmetic compiler or of bi-interpretability.  The accompanying paper
and the separate Lean kernel carry those different proof obligations.

Only the Python standard library is used.  Run:
    python3 check_schema.py --json schema_check_results.json

The metric counts one node per variable/constant occurrence, application,
equality, connective, falsity, or individual quantifier.  Binder names are
labels, not nodes.  Schematic formula applications and their displayed
arguments count, but substituted formula bodies, stored update bodies,
admission tests, and the theory enumerator do not.  Separate axiom-family
counts are summed without adding an artificial conjunction.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path
import random
from typing import Mapping


@dataclass(frozen=True)
class Node:
    kind: str
    name: str = ""
    children: tuple["Node", ...] = ()


def var(name: str) -> Node:
    return Node("variable", name)


ZERO = Node("constant", "0")
BOT = Node("falsity")
N, Z, A = var("n"), var("z"), var("a")


def app(name: str, *children: Node) -> Node:
    return Node("function_application", name, children)


def succ(term: Node) -> Node:
    return app("S", term)


def eq(left: Node, right: Node) -> Node:
    return Node("equality", children=(left, right))


def imp(left: Node, right: Node) -> Node:
    return Node("implication", children=(left, right))


def conj(left: Node, right: Node) -> Node:
    return Node("conjunction", children=(left, right))


def disj(left: Node, right: Node) -> Node:
    return Node("disjunction", children=(left, right))


def forall(name: str, formula: Node) -> Node:
    return Node("universal_quantifier", name, (formula,))


def hole(name: str, *arguments: Node) -> Node:
    return Node("formula_placeholder", name, arguments)


def close(names: list[str], formula: Node) -> Node:
    for name in reversed(names):
        formula = forall(name, formula)
    return formula


def free_variables(node: Node) -> set[str]:
    if node.kind == "variable":
        return {node.name}
    result: set[str] = set()
    for child in node.children:
        result.update(free_variables(child))
    if node.kind == "universal_quantifier":
        result.discard(node.name)
    return result


def kinds(node: Node) -> Counter[str]:
    result: Counter[str] = Counter({node.kind: 1})
    for child in node.children:
        result.update(kinds(child))
    return result


def count(node: Node) -> int:
    return sum(kinds(node).values())


def substitute(node: Node, mapping: Mapping[str, Node]) -> Node:
    """Simultaneous substitution in a term or quantifier-free formula.

    A replacement is returned as a whole: it is not traversed a second time.
    Function-description names are atomic labels and are never substituted.
    Refusing quantifiers avoids accidentally relying on a capture-prone
    implementation for formulas outside this checker's intended scope.
    """
    if node.kind == "universal_quantifier":
        raise ValueError("Substitution here is deliberately quantifier-free")
    if node.kind == "variable":
        return mapping.get(node.name, node)
    return Node(node.kind, node.name,
                tuple(substitute(child, mapping) for child in node.children))


def is_reflexive_implication(node: Node) -> bool:
    return (node.kind == "implication"
            and len(node.children) == 2
            and node.children[0] == node.children[1])


def is_qf_formula(node: Node) -> bool:
    if node.kind == "falsity":
        return True
    if node.kind == "equality":
        return len(node.children) == 2 and all(is_term(t) for t in node.children)
    if node.kind in {"implication", "conjunction", "disjunction"}:
        return (len(node.children) == 2
                and all(is_qf_formula(t) for t in node.children))
    return False


def is_term(node: Node) -> bool:
    if node.kind in {"variable", "constant"}:
        return not node.children
    return (node.kind == "function_application"
            and all(is_term(t) for t in node.children))


def rec(name: str, counter: Node, seed: Node) -> Node:
    return app(name, counter, seed)


def initial_value(name: str, seed: Node = A) -> Node:
    return rec(name, ZERO, seed)


def shifted_base(matrix: Node, name: str) -> Node:
    return substitute(matrix, {"n": ZERO, "z": initial_value(name)})


def admitted_diagonal(matrix: Node, name: str) -> bool:
    return (is_qf_formula(matrix)
            and free_variables(matrix) <= {"n", "z", "a"}
            and is_reflexive_implication(shifted_base(matrix, name)))


def admitted_reflexive(matrix: Node) -> bool:
    return (is_qf_formula(matrix)
            and free_variables(matrix) <= {"n", "a"}
            and is_reflexive_implication(substitute(matrix, {"n": ZERO})))


@dataclass(frozen=True)
class Description:
    name: str
    body: Node


def validate_descriptions(descriptions: tuple[Description, ...]) -> None:
    """Check two-variable update bodies and strictly earlier dependencies."""
    available: dict[str, int] = {"S": 1}
    for description in descriptions:
        if description.name in available:
            raise ValueError("Duplicate or shadowed function-description name")
        if free_variables(description.body) - {"u", "v"}:
            raise ValueError("Unexpected free variable in stored update body")

        def visit(node: Node) -> None:
            if node.kind == "variable":
                return
            if node.kind == "constant" and node.name == "0":
                return
            if node.kind != "function_application":
                raise ValueError("Not a term in the generated language")
            if available.get(node.name) != len(node.children):
                raise ValueError("Non-earlier dependency or invalid arity")
            for child in node.children:
                visit(child)

        visit(description.body)
        available[description.name] = 2


def successor_equation(description: Description) -> Node:
    body = substitute(description.body,
                      {"u": N, "v": rec(description.name, N, A)})
    return eq(rec(description.name, succ(N), A), body)


def diagonal_instance(description: Description, matrix: Node,
                      check_admission: bool = True) -> Node:
    if check_admission and not admitted_diagonal(matrix, description.name):
        raise ValueError("Matrix does not meet the literal shifted-base test")
    diagonal = substitute(matrix, {"z": A})
    step = forall("n", imp(diagonal, substitute(diagonal, {"n": succ(N)})))
    conclusion = forall("n", conj(diagonal, successor_equation(description)))
    return forall("a", imp(step, conclusion))


def explicit_instance(description: Description, matrix: Node) -> Node:
    if not admitted_reflexive(matrix):
        raise ValueError("Matrix does not meet the literal zero-base test")
    step = forall("n", imp(matrix, substitute(matrix, {"n": succ(N)})))
    computations = conj(eq(initial_value(description.name), A),
                        successor_equation(description))
    conclusion = forall("n", conj(matrix, computations))
    return forall("a", imp(step, conclusion))


def singleton_value(node: Node) -> bool | int:
    """Interpret in the one-world, one-element intuitionistic structure."""
    if node.kind in {"variable", "constant", "function_application"}:
        return 0
    if node.kind == "equality":
        return singleton_value(node.children[0]) == singleton_value(node.children[1])
    if node.kind == "falsity":
        return False
    if node.kind == "implication":
        return (not singleton_value(node.children[0])
                or bool(singleton_value(node.children[1])))
    if node.kind == "conjunction":
        return (bool(singleton_value(node.children[0]))
                and bool(singleton_value(node.children[1])))
    if node.kind == "disjunction":
        return (bool(singleton_value(node.children[0]))
                or bool(singleton_value(node.children[1])))
    if node.kind == "universal_quantifier":
        return singleton_value(node.children[0])
    raise ValueError(f"No interpretation for node kind {node.kind}")


def ascii_formula(node: Node) -> str:
    if node.kind in {"variable", "constant"}:
        return node.name
    if node.kind in {"function_application", "formula_placeholder"}:
        return node.name + "(" + ",".join(map(ascii_formula, node.children)) + ")"
    if node.kind == "falsity":
        return "False"
    if node.kind == "universal_quantifier":
        return "forall " + node.name + ". " + ascii_formula(node.children[0])
    operations = {"equality": "=", "implication": "->",
                  "conjunction": "&", "disjunction": "|"}
    return ("(" + ascii_formula(node.children[0]) + " " + operations[node.kind]
            + " " + ascii_formula(node.children[1]) + ")")


def schema_metrics() -> dict[str, object]:
    """Construct all compared templates independently as trees."""
    r0 = eq(initial_value("R_h"), A)
    rs = eq(rec("R_h", succ(N), A), app("h", N, rec("R_h", N, A)))
    separation = imp(eq(ZERO, succ(ZERO)), BOT)
    old: dict[str, object] = {}
    for extra in range(5):
        params = [var("c" + str(i)) for i in range(extra)]
        names = ["a"] + [p.name for p in params]

        def f(n: Node, seed: Node = A) -> Node:
            return hole("A", n, seed, *params)

        progress = forall("n", imp(f(N), f(succ(N))))
        fi = close(names, imp(conj(disj(f(ZERO), eq(ZERO, succ(ZERO))),
                                   progress), forall("n", f(N))))
        implicit = close(names, imp(
            conj(disj(f(ZERO, initial_value("R_h")), eq(ZERO, succ(ZERO))),
                 progress), forall("n", conj(f(N), rs))))
        ni = close(names, imp(progress, forall("n", f(N))))
        computations = [forall("a", r0), close(["n", "a"], rs)]
        fused_count = sum(map(count, computations)) + count(fi)
        implicit_count = count(implicit)
        reflexive_count = sum(map(count, computations)) + count(separation) + count(ni)
        assert fused_count == 42 + 5 * extra
        assert implicit_count == 37 + 5 * extra
        assert reflexive_count == 39 + 4 * extra
        old[str(extra)] = {
            "fused_42_plus_5r": fused_count,
            "implicit_37_plus_5r": implicit_count,
            "reflexive_39_plus_4r": reflexive_count,
        }

    def d(n: Node) -> Node:
        return hole("A", n, A, A)

    diagonal = forall("a", imp(forall("n", imp(d(N), d(succ(N)))),
                              forall("n", conj(d(N), rs))))

    def b(n: Node) -> Node:
        return hole("B", n, A)

    explicit = forall("a", imp(forall("n", imp(b(N), b(succ(N)))),
                              forall("n", conj(b(N), conj(r0, rs)))))
    assert count(diagonal) == 29
    assert count(explicit) == 32
    assert count(separation) == 6
    assert count(diagonal) + count(separation) == 35
    assert count(explicit) + count(separation) == 38
    return {
        "definition": __doc__.split("The metric counts", 1)[1].strip(),
        "parameter_convention": (
            "r counts extra matrix parameters beyond the seed a in the old "
            "templates; the reflexive baseline has q=1+r parameters. The "
            "35-node template keeps all three displayed A arguments, including "
            "the repeated seed. Its admission test is a different interface."
        ),
        "old_templates_by_extra_parameter_count": old,
        "main35": {
            "schema": count(diagonal), "separation": count(separation),
            "sum": count(diagonal) + count(separation),
            "schema_nodes_by_kind": dict(sorted(kinds(diagonal).items())),
            "separation_nodes_by_kind": dict(sorted(kinds(separation).items())),
            "template": ascii_formula(diagonal),
        },
        "alternative38": {
            "schema": count(explicit), "separation": count(separation),
            "sum": count(explicit) + count(separation),
            "schema_nodes_by_kind": dict(sorted(kinds(explicit).items())),
            "template": ascii_formula(explicit),
        },
    }


def run_checks() -> dict[str, object]:
    u, v = var("u"), var("v")
    descriptions = (
        Description("R_zero", ZERO),
        Description("R_pred", u),
        Description("R_succ", succ(v)),
        Description("R_nested", rec("R_zero", succ(u), rec("R_succ", v, ZERO))),
    )
    validate_descriptions(descriptions)
    invalid_descriptions = (
        (Description("R_self", app("R_self", u, v)),),
        (Description("R_free", var("w")),),
        (Description("R_wrong_arity", app("S", u, v)),),
    )
    for invalid in invalid_descriptions:
        try:
            validate_descriptions(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError("Bad recursion description was accepted")

    collision = app("R_zero", N, Z)
    assert substitute(collision, {"n": Z, "z": A}) == app("R_zero", Z, A)
    assert free_variables(app("R_pred", A, ZERO)) == {"a"}
    assert free_variables(close(["a", "n"], eq(N, A))) == set()

    seed = 20261101
    rng = random.Random(seed)
    names = [description.name for description in descriptions]

    def term(depth: int, variables: tuple[Node, ...]) -> Node:
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice(variables + (ZERO,))
        if rng.randrange(3) == 0:
            return succ(term(depth - 1, variables))
        return rec(rng.choice(names), term(depth - 1, variables),
                   term(depth - 1, variables))

    def formula(depth: int, variables: tuple[Node, ...]) -> Node:
        if depth == 0 or rng.randrange(4) == 0:
            if rng.randrange(7) == 0:
                return BOT
            return eq(term(2, variables), term(2, variables))
        operation = rng.choice((conj, disj, imp))
        return operation(formula(depth - 1, variables),
                         formula(depth - 1, variables))

    normalized_examples = 400
    probe_examples: list[dict[str, object]] = []
    checked_diagonal = checked_explicit = 0
    for description in descriptions:
        g = initial_value(description.name)
        probe = imp(eq(Z, Z), eq(Z, g))
        assert admitted_diagonal(probe, description.name)
        emitted_probe = diagonal_instance(description, probe)
        diagonal_probe = substitute(probe, {"z": A})
        assert diagonal_probe == imp(eq(A, A), eq(A, g))
        assert free_variables(emitted_probe) == set()
        assert free_variables(diagonal_probe) == {"a"}
        assert singleton_value(emitted_probe)
        probe_examples.append({
            "description": description.name,
            "stored_body": ascii_formula(description.body),
            "matrix": ascii_formula(probe),
            "shifted_base": ascii_formula(shifted_base(probe, description.name)),
            "emitted_diagonal": ascii_formula(diagonal_probe),
            "emitted_instance_nodes": count(emitted_probe),
        })
        checked_diagonal += 1

        tautology = imp(eq(ZERO, ZERO), eq(ZERO, ZERO))
        assert admitted_diagonal(tautology, description.name)
        assert admitted_reflexive(tautology)
        assert singleton_value(diagonal_instance(description, tautology))
        assert singleton_value(explicit_instance(description, tautology))
        checked_diagonal += 1
        checked_explicit += 1

        for _ in range(normalized_examples):
            target = formula(3, (N, A))
            normalized = imp(substitute(target, {"n": ZERO}), target)
            assert admitted_diagonal(normalized, description.name)
            assert admitted_reflexive(normalized)
            emitted = diagonal_instance(description, normalized)
            explicit = explicit_instance(description, normalized)
            assert free_variables(emitted) == set()
            assert free_variables(explicit) == set()
            assert free_variables(substitute(normalized, {"z": A})) <= {"n", "a"}
            assert singleton_value(emitted)
            assert singleton_value(explicit)
            checked_diagonal += 1
            checked_explicit += 1

            arbitrary = formula(3, (N, Z, A))
            shifted_normalized = imp(shifted_base(arbitrary, description.name), arbitrary)
            assert admitted_diagonal(shifted_normalized, description.name)
            shifted_emission = diagonal_instance(description, shifted_normalized)
            assert free_variables(shifted_emission) == set()
            assert free_variables(substitute(shifted_normalized, {"z": A})) <= {"n", "a"}
            assert singleton_value(shifted_emission)
            checked_diagonal += 1

        assert not admitted_diagonal(BOT, description.name)
        assert not admitted_diagonal(eq(ZERO, ZERO), description.name)
        assert not admitted_diagonal(imp(eq(var("w"), var("w")),
                                        eq(var("w"), var("w"))), description.name)
        unrestricted_bottom = diagonal_instance(description, BOT, check_admission=False)
        assert not singleton_value(unrestricted_bottom)

    separation = imp(eq(ZERO, succ(ZERO)), BOT)
    assert not singleton_value(separation)
    return {
        "status": "passed",
        "random_seed": seed,
        "checks": {
            "well_founded_two_variable_update_descriptions": len(descriptions),
            "rejected_invalid_descriptions": len(invalid_descriptions),
            "qfi_targets_per_description": normalized_examples,
            "shifted_normalizations_per_description": normalized_examples,
            "accepted_diagonal_instances_checked": checked_diagonal,
            "accepted_explicit_instances_checked": checked_explicit,
            "simultaneous_substitution_collision_check": True,
            "all_emitted_instances_are_closed": True,
            "all_expanded_matrices_use_at_most_n_and_a": True,
            "description_body_variables_not_treated_as_application_free_variables": True,
        },
        "initialization_probe_certificates": probe_examples,
        "countermodel_checks": {
            "without_separation": (
                "The one-world singleton structure validates every tested admitted "
                "instance and falsifies 0 != S(0). The paper gives the argument "
                "for every admitted instance, not just this finite sample."
            ),
            "without_admission": (
                "A=False has logically true progress and a false conclusion. "
                "The unrestricted schema is inconsistent."
            ),
        },
        "metrics": schema_metrics(),
        "not_verified_by_this_script": [
            "An exhaustive theorem about all syntax trees; the paper proves that structurally.",
            "The intuitionistic logical extraction theorem; see the separate Lean kernel.",
            "The one-parameter arithmetic and pairing bootstrap.",
            "The primitive-recursion compiler or identity bi-interpretations.",
            "A complete encoding-length or global shortestness claim.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, help="Write the complete JSON check report")
    options = parser.parse_args()
    report = run_checks()
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if options.json is not None:
        options.json.write_text(encoded, encoding="utf-8")
        print(f"PASS: {report['checks']['accepted_diagonal_instances_checked']} diagonal "
              f"and {report['checks']['accepted_explicit_instances_checked']} explicit "
              "instances; partial template totals 35 and 38.")
        print(f"Report: {options.json}")
    else:
        print(encoded, end="")


if __name__ == "__main__":
    main()
