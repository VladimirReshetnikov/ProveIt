#!/usr/bin/env python3
"""Check the optional 32-node, exact-initialization-rewrite variant.

This imports the finite syntax-tree definitions from check_schema.py.  It does
not change that checker or its 35-node main presentation.  The new admission
algorithm first substitutes n := 0, then walks the resulting tree postorder,
contracting a node precisely when it is R_h(0,a) for the current description h
and the distinguished free parameter a.  No other computation is performed.
It admits the matrix exactly when the result is literally B -> B.

Finite syntax tests and template counts are not proofs of the arithmetic
compiler or of the full bi-interpretability theorem.  The algorithm and its
mathematical proof obligations are described in the accompanying report.

Run from the directory containing both scripts:
    python3 check_rewrite_variant.py --json rewrite_check_results.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import random

from check_schema import (
    A, BOT, N, ZERO, Description, Node, app, ascii_formula, conj, count, disj,
    eq, forall, free_variables, hole, imp, initial_value,
    is_qf_formula, is_reflexive_implication, kinds, rec, singleton_value,
    substitute, succ, successor_equation, var,
)


def contract_initialization(node: Node, current: str) -> Node:
    """A single postorder pass, matching exact trees after child reductions."""
    if node.kind == "universal_quantifier":
        raise ValueError("This normalizer is intended only for terms and QF matrices")
    reduced = Node(node.kind, node.name,
                   tuple(contract_initialization(child, current)
                         for child in node.children))
    if reduced == initial_value(current):
        return A
    return reduced


def normalized_base(matrix: Node, current: str) -> Node:
    return contract_initialization(substitute(matrix, {"n": ZERO}), current)


def admitted(matrix: Node, current: str) -> bool:
    return (is_qf_formula(matrix)
            and free_variables(matrix) <= {"n", "a"}
            and is_reflexive_implication(normalized_base(matrix, current)))


def emit(description: Description, matrix: Node) -> Node:
    if not admitted(matrix, description.name):
        raise ValueError("Matrix fails the normalized-base reflexivity test")
    step = forall("n", imp(matrix, substitute(matrix, {"n": succ(N)})))
    conclusion = forall("n", conj(matrix, successor_equation(description)))
    return forall("a", imp(step, conclusion))


def metrics() -> dict[str, object]:
    def f(counter: Node) -> Node:
        return hole("F", counter, A)

    rs = eq(rec("R_h", succ(N), A), app("h", N, rec("R_h", N, A)))
    schema = forall("a", imp(forall("n", imp(f(N), f(succ(N)))),
                            forall("n", conj(f(N), rs))))
    separation = imp(eq(ZERO, succ(ZERO)), BOT)
    assert count(schema) == 26
    assert count(separation) == 6
    return {
        "schema": count(schema),
        "separation": count(separation),
        "total": count(schema) + count(separation),
        "schema_nodes_by_kind": dict(sorted(kinds(schema).items())),
        "template": ascii_formula(schema),
        "excluded_costs": [
            "The additional exact-match normalization algorithm.",
            "Substituted matrix bodies and stored update bodies.",
            "Description encodings, binding metadata, and the theory enumerator.",
        ],
    }


def run_checks() -> dict[str, object]:
    name = "R_h"
    other = "R_k"
    g = initial_value(name)
    description = Description(name, succ(var("v")))
    nested = rec(name, ZERO, g)
    deep_nested = rec(name, ZERO, nested)
    edge_cases = (
        ("exact pattern", g, A),
        ("nested pattern becomes a root redex", nested, A),
        ("three nested exact recursors", deep_nested, A),
        ("congruence under successor", succ(g), succ(A)),
        ("other description unchanged", initial_value(other), initial_value(other)),
        ("nonparameter seed unchanged", rec(name, ZERO, succ(A)),
         rec(name, ZERO, succ(A))),
        ("closed-zero seed unchanged", rec(name, ZERO, ZERO), rec(name, ZERO, ZERO)),
        ("other name prevents outer contraction", rec(name, ZERO, initial_value(other)),
         rec(name, ZERO, initial_value(other))),
        ("different free variable unchanged", rec(name, ZERO, var("b")),
         rec(name, ZERO, var("b"))),
        ("normalizing counter is not computing it", rec(name, g, A), rec(name, A, A)),
        ("no contraction at a successor counter", rec(name, succ(ZERO), A),
         rec(name, succ(ZERO), A)),
        ("inner contraction with nonmatching outer seed", rec(name, ZERO, succ(g)),
         rec(name, ZERO, succ(A))),
    )
    for _, source, expected in edge_cases:
        actual = contract_initialization(source, name)
        assert actual == expected
        assert contract_initialization(actual, name) == actual
        assert count(actual) <= count(source)

    probe = imp(eq(A, A), eq(g, A))
    nested_probe = imp(eq(A, A), eq(deep_nested, A))
    assert admitted(probe, name)
    assert admitted(nested_probe, name)
    assert normalized_base(probe, name) == imp(eq(A, A), eq(A, A))
    assert normalized_base(nested_probe, name) == imp(eq(A, A), eq(A, A))
    assert not is_reflexive_implication(substitute(probe, {"n": ZERO}))
    assert not admitted(BOT, name)
    assert not admitted(eq(A, A), name)
    other_probe = imp(eq(A, A), eq(initial_value(other), A))
    assert not admitted(other_probe, name)
    assert admitted(other_probe, other)

    # Substitution precedes reduction: a nonzero schematic counter can become
    # zero at the induction base, and then must be recognized.
    counter_probe = imp(eq(A, A), eq(rec(name, N, A), A))
    assert contract_initialization(counter_probe, name) == counter_probe
    assert admitted(counter_probe, name)

    seed = 320261101
    rng = random.Random(seed)

    def term(depth: int) -> Node:
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice((N, A, ZERO))
        if rng.randrange(3) == 0:
            return succ(term(depth - 1))
        return rec(rng.choice((name, other)), term(depth - 1), term(depth - 1))

    def formula(depth: int) -> Node:
        if depth == 0 or rng.randrange(4) == 0:
            return BOT if rng.randrange(7) == 0 else eq(term(3), term(3))
        operation = rng.choice((conj, disj, imp))
        return operation(formula(depth - 1), formula(depth - 1))

    targets = 1000
    for _ in range(targets):
        target = formula(3)
        normalized = imp(substitute(target, {"n": ZERO}), target)
        assert admitted(normalized, name)
        instance = emit(description, normalized)
        assert free_variables(instance) == set()
        assert free_variables(normalized) <= {"n", "a"}
        assert singleton_value(instance)

        base = substitute(target, {"n": ZERO})
        reduced = contract_initialization(base, name)
        assert contract_initialization(reduced, name) == reduced
        assert count(reduced) <= count(base)
        assert free_variables(reduced) <= free_variables(base)

    for matrix in (probe, nested_probe, counter_probe):
        assert free_variables(emit(description, matrix)) == set()
        assert singleton_value(emit(description, matrix))

    return {
        "status": "passed",
        "random_seed": seed,
        "admission_algorithm": (
            "First substitute n:=0 simultaneously. Then normalize postorder, "
            "replacing only exact R_h(0,a) nodes for the current h by a, "
            "including nodes newly exposed by reducing their children. Finally "
            "compare the two branches of the outer implication literally."
        ),
        "edge_case_count": len(edge_cases),
        "edge_cases": [
            {"name": label, "input": ascii_formula(source),
             "normal_form": ascii_formula(expected)}
            for label, source, expected in edge_cases
        ],
        "initialization_probe": ascii_formula(probe),
        "initialization_probe_normalized_base": ascii_formula(normalized_base(probe, name)),
        "qfi_normalization_targets_checked": targets,
        "idempotence_and_nonincrease_checks": targets + len(edge_cases),
        "different_description_probe_rejected": True,
        "two_variable_emitted_instances": True,
        "metrics": metrics(),
        "proof_scope": (
            "Finite syntax checks and independent partial template count only. "
            "The reverse mathematical implication uses R_h(0,a)=a plus equality "
            "congruence to justify each finite contraction; the forward "
            "initialization argument treats contraction solely as syntax. "
            "No arithmetic theorem is assumed by the implemented normalizer."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, help="Write the full JSON check report")
    options = parser.parse_args()
    report = run_checks()
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if options.json is None:
        print(encoded, end="")
    else:
        options.json.write_text(encoded, encoding="utf-8")
        print("PASS: 12 normalization edge cases, 1,000 QFI targets; "
              "partial template total 32 = 26 + 6.")
        print(f"Report: {options.json}")


if __name__ == "__main__":
    main()
