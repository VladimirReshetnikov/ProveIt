#!/usr/bin/env python3
"""Check the finite model obstructing an unmarked two-slot induction schema.

The written structural argument, rather than this finite computation, covers
the infinite description language.  Every generated term depends on at most
one free variable: successor is unary and each chosen recursor ignores its
second argument.  For a body h(n, v), the only possibilities are therefore
0, 1, n, 1-n, v, and 1-v.  We check closure of these six binary truth tables
and verify the successor-recursion equation for every case and every input.

The failed candidate admits A(x, z) when A(0, R_h(0, a)) is literally B -> B,
with a fresh for the source formula.  Substitution z |-> R_h(0, a) is
injective on such finite syntax: replacing each R_h(0, a) subtree by z is a
left inverse.  Every occurrence of the fresh marker a comes from an inserted
subtree, and no source subtree contains a.  Thus the admission condition is
equivalent to ordinary reflexivity A(0, z) = C -> C.  This syntactic argument
is proved in the accompanying report; finite enumeration is not its proof.

Our two-cycle satisfies separation, all successor-recursion equations, and
full quantifier-free induction (indeed induction for every predicate).  It
fails initialization.  The original-seed slot in the three-slot construction
therefore has a substantive role.
"""

from __future__ import annotations

import itertools
import json


DOMAIN = (0, 1)
INPUTS = tuple(itertools.product(DOMAIN, repeat=2))


def successor(value: int) -> int:
    return 1 - value


def table(function):
    return tuple(function(counter, value) for counter, value in INPUTS)


BODIES = {
    "0": table(lambda n, v: 0),
    "1": table(lambda n, v: 1),
    "n": table(lambda n, v: n),
    "1-n": table(lambda n, v: 1 - n),
    "v": table(lambda n, v: v),
    "1-v": table(lambda n, v: 1 - v),
}

# Each pair lists R_h(0, a), R_h(1, a); the seed a is ignored.
RECURSORS = {
    "0": (0, 0),
    "1": (1, 1),
    "n": (1, 0),
    "1-n": (0, 1),
    "v": (0, 0),
    "1-v": (0, 1),
}


def evaluate(body, counter: int, value: int) -> int:
    return body[2 * counter + value]


def main() -> None:
    assert len(set(BODIES.values())) == 6
    structural_tables = set(BODIES.values())

    # Structural induction on terms is witnessed by these closure checks.
    assert table(lambda n, v: 0) in structural_tables
    assert table(lambda n, v: n) in structural_tables
    assert table(lambda n, v: v) in structural_tables
    for source in structural_tables:
        assert tuple(successor(value) for value in source) in structural_tables

    recursor_closure_checks = 0
    for recursor in RECURSORS.values():
        for first in structural_tables:
            for second in structural_tables:
                # A recursor application R_h(t, u) ignores u.  Iterating over
                # both arguments nevertheless checks every binary composition.
                result = tuple(recursor[value] for value in first)
                assert result in structural_tables
                recursor_closure_checks += 1

    recursion_checks = 0
    for name, body in BODIES.items():
        recursor = RECURSORS[name]
        for counter, seed in INPUTS:
            left = recursor[successor(counter)]
            right = evaluate(body, counter, recursor[counter])
            assert left == right, (name, counter, seed, left, right)
            recursion_checks += 1

    # The separation sentence 0 != S(0) holds.
    assert 0 != successor(0)

    # A table describes A(n, a).  For either fixed seed, the base at 0 and
    # successor closure immediately supply its only other value, at 1.
    qfi_checks = 0
    for predicate in itertools.product((False, True), repeat=4):
        for seed in DOMAIN:
            holds = lambda n: predicate[2 * n + seed]
            base = holds(0)
            progress = all(
                (not holds(n)) or holds(successor(n)) for n in DOMAIN
            )
            conclusion = all(holds(n) for n in DOMAIN)
            assert not (base and progress) or conclusion
            qfi_checks += 1

    # Initialization fails for the counter-reading body h(n, v) = n.
    failing_seed = 0
    failing_value = RECURSORS["n"][0]
    assert failing_value == 1 and failing_value != failing_seed

    print(json.dumps({
        "status": "passed",
        "carrier": list(DOMAIN),
        "successor": [successor(n) for n in DOMAIN],
        "body_classes": len(BODIES),
        "recursor_table": {
            name: list(values) for name, values in RECURSORS.items()
        },
        "recursor_composition_closure_checks": recursor_closure_checks,
        "successor_recursion_checks": recursion_checks,
        "predicate_tables": 16,
        "qfi_fixed_seed_checks": qfi_checks,
        "separation": True,
        "failed_initialization": {
            "body": "n", "seed": failing_seed, "R_h(0, seed)": failing_value
        },
        "scope": (
            "Finite table diagnostic.  Structural induction on description "
            "syntax and injectivity of the fresh-marker substitution are "
            "written proofs, not inferred from bounded tests."
        ),
    }, indent=2))


if __name__ == "__main__":
    main()
