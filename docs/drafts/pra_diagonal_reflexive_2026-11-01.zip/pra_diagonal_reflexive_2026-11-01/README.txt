PRA FROM A DIAGONAL INDUCTION SCHEMA
Research report prepared for Vladimir Reshetnikov, 1 November 2026.

Main result
-----------
In classical or intuitionistic first-order equality logic, separately:
  * Use 0, S, and binary R_h for every earlier two-variable update h(u,v).
  * Postulate 0 != S(0).
  * For each quantifier-free source A(x,z,w), admit it when simultaneous
    substitution A(0,R_h(0,a),a) is literally B -> B.
  * Emit the diagonal induction/recursion schema in report.tex, equation D.

Every generated nonlogical axiom uses at most two variable names. The
initialization R_h(0,a)=a is derived. The written report proves common
conservative definitional extensions with matching classical and
intuitionistic first-order PRA, including internal identity round trips.

The partial display subtotal is 35 nodes. This EXCLUDES the admission
algorithm, substituted formula/update bodies, and description encoding.
It is not an absolute shortest-axiomatization claim. A 38-node alternative
has a simpler admission test. A 32-node alternative adds an exact
initialization contraction to the admission algorithm; its equivalence
is proved in an appendix, but it is outside the Lean kernel's scope.
A two-element countermodel rules out simply dropping the third source
slot from the 35-node construction without changing admission.

Contents
--------
report.tex / report.pdf
    Complete statement, constructive proofs, comparison, limitations.
formal/DiagonalSchema.lean
    Core Lean semantic kernel for the new logical schema equivalence.
formal/SCOPE.txt
    Exact boundary of the formal verification.
checks/check_schema.py
    Independent syntax, admission, variable-budget, and count checks.
checks/check_two_slot_countermodel.py
    Finite calculations for the entire-language countermodel argument.
checks/check_rewrite_variant.py
    Syntax and normalization checks for the optional 32-node variant.
audit/
    Pinned source manifest and actual verification reports.
build.py
    Rebuild and check script.

Rebuild
-------
  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

Python 3.10+ and a TeX installation with pdflatex are required. The checks
use only Python's standard library. The Lean proof uses core Lean 4.19.0,
with no Mathlib. If Lean is unavailable the build reports a skip rather
than a successful formal check and retains the delivered validation log.

Comparison snapshot
-------------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 0bf6525f9b09421e5ffacdd5fba7648d28b7fcff
Directory: docs/drafts
All five archives at that snapshot were read and their Git blob hashes
verified. The source repository was not modified.

Verification boundary
---------------------
The new logical equivalence has a checked constructive Lean kernel.
The one-parameter arithmetic, full recursion compiler, and bi-interpretation
round trips are written mathematical proofs, not fully mechanized results.
Finite executable checks do not prove the infinite theory equivalent to PRA.
