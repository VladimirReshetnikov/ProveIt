A DIRECT INDUCTION RULE FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
3 November 2026

Main recommendation
Use ordinary intuitionistic equality logic, initialized primitive recursion,
0 != S0, and the equation-indexed schema

  [forall x ((x=0 or E(x,c)) -> E(Sx,c))]
       -> forall x (x=0 or E(x,c)),

universally closed in the parameters c. It has the equivalent rule:
prove the equation at one, prove its successor step, and conclude that
every number is zero or satisfies the equation. The context and freshness
conditions are specified in AXIOMS.txt and report.tex.

Result
The report proves equivalence to the explicitly specified first-order iPRA
target, whole-carrier bi-interpretability with identity isomorphisms, and
syntactic equiconsistency. It lists every logical rule and every nonlogical
schema. Its arithmetic reduction removes exactly five ordinary syntax-tree
nodes from each expanded instance of the current equation-closure schema.

Comparison scope
The four archives in ProveIt/docs/drafts were inspected at commit
5753b3f955eb6681b6f89f5d778fda2b7ec8f87a. Each source archive matched its Git
blob SHA and size. Exact source identifiers and SHA-256 checksums are in
provenance/source_manifest.json. The report does not assert a global minimum
across unspecified languages, schema generators or proof-length metrics.

Files
  report.pdf                   Complete 14-page report, including proofs
  report.tex                   Complete LaTeX source (no external inputs)
  AXIOMS.txt                   Standalone full formal specification
  build.py                     Rerun checks and compile the report
  artifacts/check_core.py       Standard-library finite diagnostics
  artifacts/check_results.json Completed results and their exact scope
  artifacts/independent_audit.txt Independent written mathematical review
  artifacts/verification.txt   Build, source and visual verification record
  artifacts/build_output.txt   Final reproducible-build command output
  provenance/source_manifest.json Source provenance and archive hashes
  SHA256SUMS.txt               Checksums of deliverable files

Rebuild
From the extracted directory, run:
  python3 build.py

Requirements: Python 3.10 or later, pdflatex, and the ordinary TeX packages
listed at the beginning of report.tex. The diagnostic program uses only the
Python standard library. The build sets a fixed PDF source date for stable
metadata; binary output may still differ across TeX installations.

To run diagnostics without TeX:
  python3 artifacts/check_core.py

Verification scope
The unbounded constructive proofs are in the report. The scripts check
finite syntax trees, numerical identities, Boolean formula calculations,
and finite pointed successor maps. They are not a formal verification of
the complete first-order proof system or interpretation theorem. No Lean
or Rocq formalization is claimed. The PDF was compiled and all 14 pages
were visually inspected before packaging.
