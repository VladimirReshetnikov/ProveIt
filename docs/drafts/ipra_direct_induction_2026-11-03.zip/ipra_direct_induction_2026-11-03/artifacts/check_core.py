#!/usr/bin/env python3
"""Finite diagnostics for the direct-induction presentation of iPRA.

Run with Python 3.10 or later; only the standard library is used:
    python3 artifacts/check_core.py

The output is check_results.json beside this script unless --output is set.
These checks are NOT a proof assistant, an interpretation verifier, or a
finite-model verification of iPRA.  In particular, the finite pointed maps
below need not satisfy the recursor equations.  They test the propositional
shape of the competing schemata.  The report supplies the mathematical
intuitionistic proofs and the unbounded induction arguments.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import product
import json
from pathlib import Path


@dataclass(frozen=True)
class Term:
    name: str
    arguments: tuple[Term, ...] = ()
    descriptor: Term | None = None
    variable: bool = False


@dataclass(frozen=True)
class Formula:
    connective: str
    arguments: tuple[Formula | Term, ...] = ()
    binder: str | None = None


def V(name: str) -> Term:
    return Term(name, variable=True)


ZERO = Term("0")


def S(term: Term) -> Term:
    return Term("S", (term,))


def R(descriptor: Term, *arguments: Term) -> Term:
    return Term("R", tuple(arguments), descriptor)


def Eq(left: Term, right: Term) -> Formula:
    return Formula("=", (left, right))


def Op(name: str, *arguments: Formula) -> Formula:
    return Formula(name, tuple(arguments))


def All(variable: str, formula: Formula) -> Formula:
    return Formula("forall", (formula,), variable)


def size(expression: Term | Formula) -> int:
    """Every AST node costs one; each recursor label is charged in full.

    A binder costs one, without charging its variable annotation again.
    Descriptor trees are copied charges, not shared-DAG discounts.
    """
    extra = size(expression.descriptor) if isinstance(expression, Term) and expression.descriptor is not None else 0
    return 1 + extra + sum(size(argument) for argument in expression.arguments)


def active_occurrences(expression: Term | Formula, variable: str) -> int:
    """Count active occurrences only; frozen descriptor slots are distinct."""
    if isinstance(expression, Term) and expression.variable:
        return int(expression.name == variable)
    return sum(active_occurrences(argument, variable) for argument in expression.arguments)


def all_named_occurrences(expression: Term | Formula, variable: str) -> int:
    """Deliberately unsuitable for substitution: also visits frozen labels."""
    extra = all_named_occurrences(expression.descriptor, variable) if isinstance(expression, Term) and expression.descriptor is not None else 0
    if isinstance(expression, Term) and expression.variable:
        return int(expression.name == variable)
    return extra + sum(all_named_occurrences(argument, variable) for argument in expression.arguments)


def active_variables(expression: Term | Formula) -> set[str]:
    if isinstance(expression, Term) and expression.variable:
        return {expression.name}
    return set().union(*(active_variables(argument) for argument in expression.arguments))


def substitute_term(term: Term, variable: str, replacement: Term) -> Term:
    if term.variable:
        return replacement if term.name == variable else term
    return Term(term.name, tuple(substitute_term(a, variable, replacement) for a in term.arguments), term.descriptor)


def substitute_equation(equation: Formula, variable: str, replacement: Term) -> Formula:
    # The schema index is an equation, so it has no active logical binders.
    assert equation.connective == "="
    return Eq(*(substitute_term(a, variable, replacement) for a in equation.arguments))


def closure_axiom(equation: Formula, parameters: tuple[str, ...] = (), variable: str = "x", old: bool = False) -> Formula:
    assert equation.connective == "="
    assert len(set(parameters)) == len(parameters) and variable not in parameters
    assert active_variables(equation) <= {variable, *parameters}
    x = V(variable)
    rooted = Op("or", Eq(x, ZERO), equation)
    successor_equation = substitute_equation(equation, variable, S(x))
    successor_formula = Op("or", Eq(S(x), ZERO), successor_equation) if old else successor_equation
    statement = Op("implies", All(variable, Op("implies", rooted, successor_formula)), All(variable, rooted))
    for parameter in reversed(parameters):
        statement = All(parameter, statement)
    return statement


def check_syntax() -> dict:
    x, a, b, v, w, c = (V(name) for name in ("x", "a", "b", "v", "w", "c1"))
    q = lambda counter, initializer: R(w, counter, initializer)
    add = lambda counter, initializer: R(S(v), counter, initializer)
    pool = (
        x, a, b, ZERO, S(x), S(S(x)), q(x, ZERO), q(a, x),
        add(x, a), R(c, x, a, b), R(q(v, ZERO), x, a),
        q(q(x, a), b), add(x, add(x, b)), R(q(w, ZERO), a, x),
    )
    checked = 0
    for parameters in ((), ("a",), ("a", "b")):
        admissible = tuple(term for term in pool if active_variables(term) <= {"x", *parameters})
        for left, right in product(admissible, repeat=2):
            equation = Eq(left, right)
            F = size(equation)
            k = active_occurrences(equation, "x")
            p = len(parameters)
            assert size(substitute_equation(equation, "x", S(x))) == F + k
            assert size(closure_axiom(equation, parameters)) == 3 * F + k + p + 12
            assert size(closure_axiom(equation, parameters, old=True)) == 3 * F + k + p + 17
            assert size(closure_axiom(equation, parameters, old=True)) - size(closure_axiom(equation, parameters)) == 5
            checked += 1

    coverage_equation = Eq(S(q(x, ZERO)), x)
    coverage_size = size(closure_axiom(coverage_equation))
    separation = Op("implies", Eq(ZERO, S(ZERO)), Op("false"))
    n = V("n")
    q_module = All("a", Op("and", Eq(q(ZERO, a), a), All("n", Eq(q(S(n), a), n))))
    assert (size(coverage_equation), active_occurrences(coverage_equation, "x"), coverage_size) == (7, 2, 35)
    assert (size(separation), size(q_module), coverage_size + size(separation) + size(q_module)) == (6, 16, 57)

    # Same spelling in two independent scopes: the inner label w stays frozen.
    collision_equation = Eq(q(w, ZERO), w)
    replaced = substitute_equation(collision_equation, "w", S(w))
    assert replaced.arguments[0].descriptor is collision_equation.arguments[0].descriptor
    assert size(replaced) == size(collision_equation) + 2
    assert active_occurrences(collision_equation, "w") == 2
    assert all_named_occurrences(collision_equation, "w") == 3
    assert size(closure_axiom(collision_equation, variable="w")) == 32
    assert 3 * size(collision_equation) + all_named_occurrences(collision_equation, "w") + 12 == 33

    return {
        "status": "passed",
        "equation_and_parameter_cases": checked,
        "charged_term_pool_size": len(pool),
        "C_size": "3*F + k + p + 12",
        "Z_size": "3*F + k + p + 17",
        "saving_per_expanded_instance": 5,
        "notation": {"F": "full charged equation size", "k": "active induction-variable occurrences", "p": "number of universally bound parameters"},
        "coverage_packet": {"equation": "S(Q(x,0))=x", "F": 7, "k": 2, "C": 35, "Sep": 6, "Q_module": 16, "total": 57},
        "frozen_label_negative_control": {"equation": "Q(w,0)=w, with Q's frozen descriptor also spelled w", "F": 6, "active_occurrences": 2, "incorrect_count_including_label": 3, "correct_C_size": 32, "incorrect_prediction": 33},
        "scope": "Finite AST diagnostics; the general counting identities are proved structurally in the report.",
    }


def Q(n: int, a: int) -> int:
    return a if n == 0 else n - 1


def pred(n: int) -> int:
    return Q(n, 0)


def selector(n: int, a: int, b: int) -> int:
    return a if n == 0 else b


def addition(x: int, y: int) -> int:
    value = x
    for _ in range(y):
        value += 1
    return value


def difference(x: int, y: int) -> int:
    value = x
    for _ in range(y):
        value = pred(value)
    return value


def equality_bit(s: int, t: int) -> int:
    return selector(Q(difference(s + 1, t), 1), 0, 1)


def check_numbers(bound: int = 32) -> dict:
    pairs = 0
    for y, n in product(range(bound + 1), repeat=2):
        residual = difference(y, n)
        assert residual == max(y - n, 0)
        assert selector(residual, y, addition(n, residual)) == y
        bit = equality_bit(y, n)
        assert bit in (0, 1)
        assert (bit == 0) == (y == n)
        assert (bit == 1) == (y != n)
        pairs += 1
    for n in range(bound + 1):
        assert pred(n + 1) == n
        assert difference(n, n) == 0
        assert difference(n + 1, n) == 1
        for a in range(bound + 1):
            assert Q(0, a) == a
            assert Q(n + 1, a) == n
    # A missing successor in beta is caught even at zero, rather than passing
    # merely because both sides used the same equality implementation.
    faulty_bit = selector(Q(difference(0, 0), 1), 0, 1)
    assert faulty_bit == 1 and equality_bit(0, 0) == 0
    return {
        "status": "passed", "inclusive_range": [0, bound], "residual_cases": pairs,
        "equality_bit_cases": pairs, "beta_range": [0, 1],
        "residual_identity": "selector(d(y,n), y, n+d(y,n)) = y",
        "equality_bit": "selector(Q(d(s+1,t),1),0,1)",
        "negative_control_missing_successor": {"s": 0, "t": 0, "faulty_beta": 1, "correct_beta": 0},
        "scope": "Standard natural-number calculations in the displayed finite range, not an unbounded proof.",
    }


def boolean_formulas(depth: int) -> tuple:
    atoms = (("atom", "p"), ("atom", "q"), ("false",))
    if depth == 0:
        return atoms
    smaller = boolean_formulas(depth - 1)
    return atoms + tuple((op, left, right) for op in ("and", "or", "implies") for left in smaller for right in smaller)


def truth(formula: tuple, valuation: dict[str, bool]) -> bool:
    op = formula[0]
    if op == "atom":
        return valuation[formula[1]]
    if op == "false":
        return False
    left, right = truth(formula[1], valuation), truth(formula[2], valuation)
    if op == "and":
        return left and right
    if op == "or":
        return left or right
    return (not left) or right


def compiled_bit(formula: tuple, valuation: dict[str, bool]) -> int:
    op = formula[0]
    if op == "atom":
        return 0 if valuation[formula[1]] else 1
    if op == "false":
        return 1
    left, right = compiled_bit(formula[1], valuation), compiled_bit(formula[2], valuation)
    if op == "and":
        return selector(left, right, 1)
    if op == "or":
        return selector(left, 0, right)
    return selector(left, right, 0)


def check_boolean_compiler() -> dict:
    formulas = boolean_formulas(2)
    cases = 0
    for p, q in product((False, True), repeat=2):
        valuation = {"p": p, "q": q}
        for formula in formulas:
            result = compiled_bit(formula, valuation)
            assert result in (0, 1)
            assert (result == 0) == truth(formula, valuation)
            assert (result == 1) == (not truth(formula, valuation))
            cases += 1
    return {
        "status": "passed", "atoms": ["p", "q", "false"], "connectives": ["and", "or", "implies"],
        "maximum_binary_connective_depth": 2, "formulas": len(formulas), "valuations_per_formula": 4,
        "evaluations": cases,
        "scope": "Truth-table check for decidable Boolean inputs only; no excluded middle for arbitrary intuitionistic formulas is tested or assumed as a theorem.",
    }


def schema_values(successor: tuple[int, ...], E: frozenset[int]) -> dict[str, bool]:
    carrier = range(len(successor))
    P = frozenset({0}) | E
    conclusion = all(x in P for x in carrier)
    c_premise = all((x not in P) or (successor[x] in E) for x in carrier)
    z_premise = all((x not in P) or (successor[x] in P) for x in carrier)
    unrooted_premise = all((x not in E) or (successor[x] in E) for x in carrier)
    return {
        "C": (not c_premise) or conclusion,
        "Z": (not z_premise) or conclusion,
        "root_deleted_from_premise": (not unrooted_premise) or conclusion,
        "root_deleted_from_conclusion": (not c_premise) or all(x in E for x in carrier),
    }


def witness(successor: tuple[int, ...], E: frozenset[int]) -> dict:
    return {"carrier": list(range(len(successor))), "zero": 0, "successor": list(successor), "E": sorted(E), "values": schema_values(successor, E)}


def check_pointed_maps(max_size: int = 4) -> dict:
    cases = no_zero_range_cases = disagreements = 0
    first_failure = first_failure_with_separation = None
    maps_by_size = {}
    for size_ in range(1, max_size + 1):
        maps_by_size[str(size_)] = size_ ** size_
        subsets = tuple(frozenset(i for i in range(size_) if mask & (1 << i)) for mask in range(1 << size_))
        for successor in product(range(size_), repeat=size_):
            for E in subsets:
                values = schema_values(successor, E)
                cases += 1
                # Z always implies C, before any constructor assumptions.
                assert not values["Z"] or values["C"]
                if 0 not in successor:
                    no_zero_range_cases += 1
                    assert values["C"] == values["Z"]
                elif values["C"] != values["Z"]:
                    disagreements += 1
                    if first_failure is None:
                        first_failure = witness(successor, E)
                    if successor[0] != 0 and first_failure_with_separation is None:
                        first_failure_with_separation = witness(successor, E)
    assert first_failure is not None and first_failure_with_separation is not None

    # The two naive root deletions fail even with zero outside the S-image.
    s = (1, 1)
    no_premise_root = witness(s, frozenset())
    no_conclusion_root = witness(s, frozenset({1}))
    assert no_premise_root["values"]["C"] and not no_premise_root["values"]["root_deleted_from_premise"]
    assert no_conclusion_root["values"]["C"] and not no_conclusion_root["values"]["root_deleted_from_conclusion"]
    return {
        "status": "passed", "carrier_sizes": [1, max_size], "maps_by_size": maps_by_size,
        "map_and_predicate_cases": cases, "cases_with_zero_outside_successor_image": no_zero_range_cases,
        "C_Z_disagreements_when_zero_is_in_image": disagreements,
        "first_disagreement": first_failure,
        "first_disagreement_despite_S0_ne_0": first_failure_with_separation,
        "negative_control_root_removed_from_premise": no_premise_root,
        "negative_control_root_removed_from_conclusion": no_conclusion_root,
        "natural_number_counterexample_equations_for_root_deletions": {
            "premise_deletion": "E(x) is 0=S0: E is empty, so the deleted premise is vacuous but the conclusion fails at x=1.",
            "conclusion_deletion": "E(x) is S(p(x))=x: E holds at all positive numbers; the original premise holds but the deleted conclusion fails at x=0.",
        },
        "scope": "Finite classical semantic diagnostic for arbitrary pointed successor maps and predicates. These finite maps are not claimed to model the recursion axioms or iPRA. The report proves the intuitionistic equivalence using the derived law Sx!=0.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("check_results.json"))
    args = parser.parse_args()
    results = {
        "status": "passed",
        "artifact": "Finite diagnostics for iPRA by direct induction",
        "assurance": "This file records finite executable checks, not formal intuitionistic proof verification.",
        "syntax": check_syntax(),
        "arithmetic": check_numbers(),
        "boolean_compiler": check_boolean_compiler(),
        "pointed_successor_maps": check_pointed_maps(),
    }
    args.output.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "output": str(args.output.resolve()), "sections": [name for name, value in results.items() if isinstance(value, dict)]}, sort_keys=True))


if __name__ == "__main__":
    main()
