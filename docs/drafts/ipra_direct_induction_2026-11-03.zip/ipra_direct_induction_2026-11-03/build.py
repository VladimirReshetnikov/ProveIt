#!/usr/bin/env python3
"""Run finite diagnostics and compile the self-contained LaTeX report."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
IGNORED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def run(command: list[str], env: dict[str, str] | None = None) -> str:
    completed = subprocess.run(
        command, cwd=ROOT, env=env, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    if completed.returncode:
        print(completed.stdout)
        raise SystemExit(completed.returncode)
    return completed.stdout


def deliverable_files() -> list[Path]:
    return sorted(
        path for path in ROOT.rglob("*")
        if path.is_file()
        and path.name != "SHA256SUMS.txt"
        and "__pycache__" not in path.parts
        and path.suffix not in IGNORED_SUFFIXES
    )


def main() -> None:
    if sys.version_info < (3, 10):
        raise SystemExit("Python 3.10 or later is required.")
    if shutil.which("pdflatex") is None:
        raise SystemExit("pdflatex is required to rebuild report.pdf.")

    outputs = [run([sys.executable, "artifacts/check_core.py"])]
    env = os.environ.copy()
    # 2026-11-03 at 12:00 UTC: fixed source metadata, not a timestamp claim.
    from datetime import datetime, timezone
    env["SOURCE_DATE_EPOCH"] = str(int(datetime(2026, 11, 3, 12, tzinfo=timezone.utc).timestamp()))
    env["FORCE_SOURCE_DATE"] = "1"
    for index in range(2):
        outputs.append(f"LaTeX pass {index + 1}\n" + run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"], env
        ))
    log = (ROOT / "report.log").read_text(encoding="utf-8")
    problems = [line for line in log.splitlines() if (
        "Overfull" in line or "undefined" in line.lower()
        or "multiply defined" in line.lower()
        or "destination with the same identifier" in line
    )]
    if problems:
        raise SystemExit("Unresolved LaTeX issues:\n" + "\n".join(problems))
    (ROOT / "artifacts/build_output.txt").write_text("\n".join(outputs), encoding="utf-8")
    checksums = [
        f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(ROOT).as_posix()}"
        for path in deliverable_files()
    ]
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(checksums) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "pdf": "report.pdf", "checksummed_files": len(checksums)}))


if __name__ == "__main__":
    main()
