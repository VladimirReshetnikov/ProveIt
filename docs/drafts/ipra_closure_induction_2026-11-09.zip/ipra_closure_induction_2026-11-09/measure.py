"""Measure whole standalone checkers with the unchanged inherited normalizer."""
from pathlib import Path
import csv
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def main():
    spec = importlib.util.spec_from_file_location(
        "inherited_source_measure", ROOT / "comparison/source_measure.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    names = ["comparison/choice_tokens.py", "comparison/choice_structure.py",
             "comparison/choice_bytes.py", "code/localized_tokens.py",
             "code/localized_structure.py", "code/localized_bytes.py"]
    for name in ("code/readable/localized_checker.py", "code/readable/choice_checker.py"):
        if (ROOT / name).is_file():
            names.append(name)
    rows = [{"file": name, **module.metrics(ROOT / name)} for name in names]
    old = rows[:3]
    new = rows[3:6]
    data = {"python": platform.python_version(),
            "implementation": platform.python_implementation(),
            "boundary": "Entire standalone source, with comments and docstrings stripped",
            "baseline_envelope": {f: min(x[f] for x in old) for f in FIELDS},
            "new_envelope": {f: min(x[f] for x in new) for f in FIELDS},
            "programs": rows}
    data["beats_baseline_in_every_coordinate"] = all(
        data["new_envelope"][f] < data["baseline_envelope"][f] for f in FIELDS)
    (ROOT / "evidence/metrics.json").write_text(json.dumps(data, indent=2) + "\n")
    with (ROOT / "evidence/metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=("file", *FIELDS, "sha256"),
                                extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(data, indent=2))


if __name__ == "__main__":
    main()
