INDUCTION WITHOUT AN EXISTENTIAL WITNESS
======================================
Prepared for Vladimir Reshetnikov, November 9, 2026.

STATUS
------
The requested significant breakthrough below the existing complete-checker
frontier was not obtained. This archive supplies a complete, equivalent
closure-induction calculus and a modest proof-theoretic reorganization.
It does not claim absolute simplestness or a new checker-size record.

Main theorem: retain Case-DI for every paired formula; localize the sole
arithmetic introduction to Q_y E(y), with E literally an equation, from
E(z) |- E(Sz). Keep the original conditional meaning E(0)->forall y E(y).
This has exactly the same sequents as Choice-DI in all retained contexts.
Proof translations have exact node counts N+3m and N+2r and use each old
premise once. Full-domain bi-interpretability and equiconsistency with
iPRA follow, with complete logical reconstruction and attributed internal
scalar-arithmetic proofs included.

Measured old coordinate envelope: 299 tokens / 340 AST nodes / 815 bytes.
Measured new coordinate envelope: 305 tokens / 348 AST nodes / 889 bytes.
Different programs attain these coordinates. These are implementation
measurements, not universal complexity lower bounds.

START HERE
----------
report.pdf                 Compiled complete research report.
report.tex                 Main editable source (uses sections/appendices).
report_standalone.tex      Fully expanded single-file editable source.
code/FORMAT.txt            Compact scalar certificate format.
code/readable/FORMAT.txt   Readable full-PR format and compiler interface.
evidence/                  Snapshot, measurements and validation records.
ATTRIBUTION.txt             Inherited sources versus new contributions.

REPRODUCE
---------
Python 3.12.14 was used for the recorded source metrics.

  python3 reproduce.py
  python3 build.py

The first command needs only Python's standard library. It runs the readable
suite (357 checks), compact suite (48 checks), and whole-source measurement.
The second needs pdflatex plus the standard packages named in report.tex.
No network or repository checkout is required for these commands.

EXAMPLE
-------
  python3 code/readable/localized_checker.py < \
    code/readable/fixtures/localized/choice_progress_induction.json

The checker prints ACCEPT or REJECT. Its compiler is separate and untrusted.
The readable and compact programs use different explicit numerical frontends,
proved equivalent in the report: full PR versus scalar iteration. No raw-packet
language equivalence between those formats is claimed.

SCOPE
-----
All 26 current source archives were frozen at ProveIt commit
1d0d5f030546d707992b4cc4194ea6971fe84938, retrieved and Git-blob verified.
No change was committed to the source repository.

Finite executable checks validate concrete certificates and implementation
boundaries. They are not a Lean/Rocq proof of the universal metatheorems,
the internal arithmetic compiler, or the host Python interpreter. The report
states that distinction and contains Further research questions.
