"""Create the source/PDF/evidence archive with a complete hash manifest."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent


def included():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and "__pycache__" not in p.parts
                  and p.suffix not in {".pyc", ".pyo"}
                  and p.name != "MANIFEST.sha256.json")


def main():
    files = included()
    manifest = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in files}
    target = ROOT / "MANIFEST.sha256.json"
    target.write_text(json.dumps(manifest, indent=2) + "\n")
    destination = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in files + [target]:
            name = str(Path(ROOT.name) / path.relative_to(ROOT))
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Archive CRC verification failed")
        for name, expected in manifest.items():
            actual = hashlib.sha256(archive.read(ROOT.name + "/" + name)).hexdigest()
            if actual != expected:
                raise RuntimeError("Archive content mismatch: " + name)
    print(json.dumps({"file": str(destination), "members": len(files) + 1,
                      "bytes": destination.stat().st_size,
                      "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()},
                     indent=2))


if __name__ == "__main__":
    main()
