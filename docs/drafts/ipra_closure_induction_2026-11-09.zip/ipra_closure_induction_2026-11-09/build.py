"""Compile the report and create an exactly expanded standalone TeX source."""
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def expanded(path):
    text = path.read_text(encoding="utf-8")
    return re.sub(r"\\input\{([^}]+)\}",
                  lambda match: expanded(ROOT / match.group(1)), text)


def main():
    (ROOT / "report_standalone.tex").write_text(
        expanded(ROOT / "report.tex"), encoding="utf-8")
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("pdflatex is required (TeX Live with the standard packages used by report.tex).")
    logs = []
    with tempfile.TemporaryDirectory(prefix="ipra_report_") as tmp:
        for _ in range(3):
            run = subprocess.run(
                [executable, "-interaction=nonstopmode", "-halt-on-error",
                 "-output-directory=" + tmp, "report.tex"], cwd=ROOT,
                text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            logs.append(run.stdout)
            if run.returncode:
                print(run.stdout)
                raise SystemExit(run.returncode)
        shutil.copyfile(Path(tmp) / "report.pdf", ROOT / "report.pdf")
        final_log = (Path(tmp) / "report.log").read_text(errors="replace")
    (ROOT / "evidence").mkdir(exist_ok=True)
    (ROOT / "evidence/build.log").write_text(final_log)
    failures = [line for line in final_log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()
                or "multiply defined" in line.lower()]
    if failures:
        print("Layout/reference messages requiring inspection:")
        print("\n".join(failures))
    print("Built report.pdf and report_standalone.tex")


if __name__ == "__main__":
    main()
