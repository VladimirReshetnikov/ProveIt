"""Run the package's finite validations and whole-source measurement."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for name in ("code/readable/run_tests.py", "code/validate_compact.py", "measure.py"):
        args = [sys.executable, str(ROOT / name)]
        if name == "code/validate_compact.py":
            args += ["--receipt", str(ROOT / "evidence/compact_validation.json")]
        subprocess.run(args, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
