"""Reproducibly adapt the inherited validated PR frontend to Eq/Q/D rules.

The emitted checker files are standalone; this authoring script is not in
an acceptance boundary. The complete inherited attribution is retained.
"""
from pathlib import Path
root=Path(__file__).resolve().parent
text=(root/'inherited/choice_checker.py').read_text()
start=text.index('"""')
end=text.index('"""',start+3)+3
text='''"""Complete standalone Eq/Q/D checker. See FORMAT.txt and ATTRIBUTION.txt.

All numerical declarations, formulas, scopes, alpha comparison, capture-free
substitution, inference rules and strict JSON decoding are included here.
There are no local imports and no assertion controls acceptance.
"""'''+text[end:]
start=text.index('def fv_formula(')
end=text.index('\ndef alpha_equal(',start)
text=text[:start]+'''def binders_and_body(formula):
    return (formula[1:2], formula[2]) if formula[0] == "Q" else (formula[1:3], formula[3])


def fv_formula(formula):
    if formula[0] == "=":
        return fv_term(formula[1]) | fv_term(formula[2])
    binders, body = binders_and_body(formula)
    return fv_formula(body) - set(binders)


def all_names(formula):
    if formula[0] == "=":
        return fv_formula(formula)
    binders, body = binders_and_body(formula)
    return set(binders) | all_names(body)


def fresh_name(used, prefix="_v"):
    number = 0
    while prefix + str(number) in used:
        number += 1
    return prefix + str(number)


def subst_term(term, mapping):
    if term[0] == "$":
        return mapping.get(term[1], term)
    return [term[0], *(subst_term(child, mapping) for child in term[1:])]


def subst_formula(formula, mapping):
    """Simultaneous substitution, alpha-renaming conflicting binders first."""
    if formula[0] == "=":
        return ["=", subst_term(formula[1], mapping), subst_term(formula[2], mapping)]
    old_binders, body = binders_and_body(formula)
    active = {key: value for key, value in mapping.items() if key not in old_binders}
    image_names = set()
    for term in active.values():
        image_names.update(fv_term(term))
    used = all_names(body) | image_names | set(active) | set(old_binders)
    renaming = {}
    binders = list(old_binders)
    for index, old in enumerate(old_binders):
        if old in image_names:
            new = fresh_name(used)
            used.add(new)
            binders[index] = new
            renaming[old] = variable(new)
    if renaming:
        body = subst_formula(body, renaming)
    return [formula[0], *binders, subst_formula(body, active)]


def alpha_key(formula):
    """Canonical alpha-equivalence key; free names remain actual names."""
    def term_key(term, environment):
        if term[0] == "$":
            item = term[1]
            return ("bound", environment[item]) if item in environment else ("free", item)
        return ("function", term[0], tuple(term_key(child, environment) for child in term[1:]))
    def formula_key(item, environment, depth):
        if item[0] == "=":
            return ("=", term_key(item[1], environment), term_key(item[2], environment))
        binders, body = binders_and_body(item)
        extended = dict(environment)
        for offset, binder in enumerate(binders):
            extended[binder] = depth + offset
        return (item[0], formula_key(body, extended, depth + len(binders)))
    return formula_key(formula, {}, 0)

''' +text[end:]
# Remove the old ordinary-hypothesis clause constructor.
start=text.index('def hypothesis(')
end=text.index('\nclass Checker:',start)
text=text[:start]+text[end:]
start=text.index('        else:\n            require(head == "D"', text.index('    def formula('))
end=text.index('\n    def computation(',start)
text=text[:start]+'''        else:
            require((head == "D" and len(value) == 4)
                    or (head == "Q" and len(value) == 3), "unknown formula constructor")
            binders, body = binders_and_body(value)
            require(all(name(item) for item in binders) and len(set(binders)) == len(binders),
                    "logical binders must have distinct valid names")
            self.formula(body, scope | set(binders))
''' + text[end:]
start=text.index('    def check(')
end=text.index('\ndef check_packet(',start)
text=text[:start]+'''    def check(self, proof, context=(), scope=frozenset(), expected=None):
        """Check a derivation in an explicit validated ordinary-formula context."""
        require(type(scope) in (set, frozenset) and all(name(item) for item in scope),
                "scope must be a set of variable names")
        scope = set(scope)
        require(type(context) in (tuple, list), "context must be a sequence of formulas")
        for formula in context:
            self.formula(formula, scope)
        if expected is not None:
            self.formula(expected, scope)
        self._check(proof, tuple(context), scope, expected, 0)
        return {"accepted": True, "proof_nodes": self.nodes,
                "maximum_depth": self.max_depth, "rule_counts": dict(self.rule_counts),
                "declared_functions": len(self.functions) - 3}

    def _check(self, proof, context, scope, expected, depth):
        require(type(proof) is dict, "proof node must be an object")
        rule = proof.get("rule")
        required = {
            "comp": ("rule", "conclusion"),
            "hyp": ("rule", "conclusion", "index"),
            "qe": ("rule", "conclusion", "major", "base", "term"),
            "di": DI_FIELDS,
            "de": ("rule", "conclusion", "major", "eigen", "premise"),
            "tr": ("rule", "conclusion", "equality", "before", "variable", "motive"),
            QP_FIELDS
        }
        require(type(rule) is str and rule in required, "unknown inference rule")
        fields(proof, required[rule], "proof node")
        conclusion = proof["conclusion"]
        self.formula(conclusion, scope)
        if expected is not None:
            require(alpha_equal(conclusion, expected), "premise has the wrong conclusion")
        self.nodes += 1
        self.max_depth = max(self.max_depth, depth)
        self.rule_counts[rule] = self.rule_counts.get(rule, 0) + 1

        if rule == "comp":
            require(self.computes(conclusion), "conclusion is not a single defining equation")
            return

        if rule == "hyp":
            index = proof["index"]
            require(type(index) is int and 0 <= index < len(context),
                    "hypothesis index is outside the context")
            require(alpha_equal(conclusion, context[index]), "wrong hypothesis conclusion")
            return

        if rule == "qe":
            self._check(proof["major"], context, scope, None, depth + 1)
            closure = proof["major"]["conclusion"]
            require(closure[0] == "Q", "closure elimination needs a Q major")
            argument = proof["term"]
            self.term(argument, scope)
            binder, body = closure[1:]
            require(alpha_equal(conclusion, subst_formula(body, {binder: argument})),
                    "closure specialization has wrong conclusion")
            base = subst_formula(body, {binder: zero()})
            self._check(proof["base"], context, scope, base, depth + 1)
            return

        if rule == "di":
            require(conclusion[0] == "D", "paired introduction needs a paired conclusion")
            witness = proof["witness"]
            eigen = proof["eigen"]
            self.term(witness, scope)
            require(name(eigen) and eigen not in scope, "introduction eigenvariable is not fresh")
            x, y, body = conclusion[1:]
            base = subst_formula(body, {x: witness, y: zero()})
            step = subst_formula(body, {x: witness, y: successor(variable(eigen))})
            DI_RETAINED
            self._check(proof["premise"], context + (retained,), scope | {eigen}, step, depth + 1)
            return

        QP_BRANCH

        if rule == "de":
            self._check(proof["major"], context, scope, None, depth + 1)
            paired = proof["major"]["conclusion"]
            require(paired[0] == "D", "paired elimination needs a paired major")
            eigen = proof["eigen"]
            require(name(eigen) and eigen not in scope, "elimination eigenvariable is not fresh")
            x, y, body = paired[1:]
            opened = subst_formula(["Q", y, body], {x: variable(eigen)})
            self._check(proof["premise"], context + (opened,), scope | {eigen},
                        conclusion, depth + 1)
            return

        equality = proof["equality"]
        self._check(equality, context, scope, None, depth + 1)
        equation = equality["conclusion"]
        require(equation[0] == "=", "transport major must be an equation")
        placeholder = proof["variable"]
        require(name(placeholder) and placeholder not in scope,
                "transport placeholder must be a fresh variable name")
        motive = proof["motive"]
        self.formula(motive, scope | {placeholder})
        old = subst_formula(motive, {placeholder: equation[1]})
        target = subst_formula(motive, {placeholder: equation[2]})
        require(alpha_equal(conclusion, target), "transport has the wrong result")
        self._check(proof["before"], context, scope, old, depth + 1)

''' +text[end:]
qp='''if rule == "qp":
            require(conclusion[0] == "Q" and conclusion[2][0] == "=",
                    "progress introduction requires a literal equation closure")
            eigen = proof["eigen"]
            require(name(eigen) and eigen not in scope, "progress eigenvariable is not fresh")
            y, body = conclusion[1:]
            ih = subst_formula(body, {y: variable(eigen)})
            step = subst_formula(body, {y: successor(variable(eigen))})
            self._check(proof["premise"], context + (ih,), scope | {eigen}, step, depth + 1)
            return'''
for kind in ('localized','choice'):
 s=text
 if kind=='localized':
  s=s.replace('DI_FIELDS','("rule", "conclusion", "witness", "eigen", "premise")')
  s=s.replace('QP_FIELDS','"qp": ("rule", "conclusion", "eigen", "premise"),')
  s=s.replace('DI_RETAINED','retained = base')
  s=s.replace('QP_BRANCH',qp)
 else:
  s=s.replace('DI_FIELDS','("rule", "conclusion", "witness", "eigen", "mode", "premise")')
  s=s.replace('QP_FIELDS','')
  s=s.replace('QP_BRANCH','')
  s=s.replace('DI_RETAINED','''mode = proof["mode"]
            require(type(mode) is str and mode in ("case", "ind"), "invalid DI mode")
            require(mode == "case" or body[0] == "=", "induction needs an equation")
            retained = (base if mode == "case" else
                        subst_formula(body, {x: witness, y: variable(eigen)}))''')
 (root/(kind+'_checker.py')).write_text(s)
print('Wrote two standalone checkers.')
