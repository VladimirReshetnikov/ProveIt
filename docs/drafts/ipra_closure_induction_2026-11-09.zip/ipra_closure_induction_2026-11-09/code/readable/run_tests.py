"""Reproduce complete-checker tests, fixtures and bidirectional compiler receipts.

Checkers are copied alone into an empty temporary directory for CLI runs.
All tests concern concrete certificates and do not prove metatheorems.
"""
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import choice_checker as C
import localized_checker as L
import compiler as P
import convert_inherited as A

ROOT=Path(__file__).resolve().parent
DEFS=json.loads((ROOT/'inherited/choice/progress_induction.json').read_text())['declarations']
ROWS=[]; RECEIPTS=[]

def write(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')

def check(condition,label,**details):
    row={'test':label,'passed':bool(condition),**details}; ROWS.append(row)
    if not condition: raise RuntimeError(json.dumps(row))

def packet(proof): return {'declarations':copy.deepcopy(DEFS),'goal':copy.deepcopy(proof['conclusion']),'proof':proof}

def comp(a,b): return {'rule':'comp','conclusion':P.eq(a,b)}

def trans(first,second,hole):
    return {'rule':'tr','conclusion':P.eq(first['conclusion'][1],second['conclusion'][2]),
            'equality':second,'before':first,'variable':hole,
            'motive':P.eq(first['conclusion'][1],P.v(hole))}

def anchored_progress(witness,retained=False,nested=False):
    """The witness occurs nontrivially in the fixed matrix; the step uses actual IH."""
    z=P.v('outer_step'); R=lambda t:['R',t]
    c=['C',copy.deepcopy(witness),P.ZERO,P.ZERO]
    context=[P.eq(R(P.ZERO),c),P.q('arbitrary',P.eq(P.v('arbitrary'),P.v('arbitrary')))] if retained else []
    recurrence=comp(R(P.s(z)),['last2',z,R(z)])
    projection=comp(['last2',z,R(z)],R(z))
    step=trans(trans(recurrence,projection,'h1'),P.hyp(P.eq(R(z),c),len(context)),'h2')
    if retained:
        # The retained numerical assumption is not a computation axiom. Its
        # use also checks that insertion shifts only the new local IH slot.
        step={'rule':'tr','conclusion':step['conclusion'],'equality':P.hyp(context[0],0),
              'before':step,'variable':'h3','motive':copy.deepcopy(step['conclusion'])}
    if nested:
        original=json.loads((ROOT/'inherited/choice/progress_induction.json').read_text())
        inner=A.packet(original)['proof']
        inner=P.insert_context(inner,0,len(context)+1)
        step={'rule':'tr','conclusion':step['conclusion'],'equality':inner,'before':step,
              'variable':'h4','motive':copy.deepcopy(step['conclusion'])}
    matrix=P.eq(R(P.v('n')),['C',P.v('x'),P.ZERO,P.ZERO])
    proof={'rule':'di','conclusion':P.d('x','n',matrix),'mode':'ind',
           'witness':copy.deepcopy(witness),'eigen':'outer_step','premise':step}
    scope=sorted(P.term_names(witness))
    return {'declarations':copy.deepcopy(DEFS),'scope':scope,'context':context,
            'goal':copy.deepcopy(proof['conclusion']),'proof':proof}

def api_scoped(module,item):
    return module.Checker(item['declarations']).check(item['proof'],context=item['context'],
                scope=set(item['scope']),expected=item['goal'])

def run():
    # Validate each inherited fixture before adapting its certificate interface.
    spec=importlib.util.spec_from_file_location('old_choice',ROOT/'inherited/choice_checker.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    positive=[]
    for path in sorted((ROOT/'inherited').glob('*/*.json')):
        original=json.loads(path.read_text()); label=path.parent.name+'_'+path.stem
        check(old.check_packet(original)['accepted'],'inherited:'+label)
        source=A.packet(original); target=P.compile_packet(source)
        returned=P.compile_packet(target,'reverse')
        for kind,item,module in [('choice',source,C),('localized',target,L),('returned',returned,C)]:
            stats=module.check_packet(item)
            check(stats['accepted'] and stats['proof_nodes']==P.counts(item['proof'])['nodes'],
                  'api:'+kind+':'+label)
            write(ROOT/'fixtures'/kind/(label+'.json'),item)
            positive.append((kind,label,item))
        for direction,a,b in [('forward',source,target),('reverse',target,returned)]:
            r=P.receipt(a['proof'],b['proof'],direction);r['fixture']=label
            check(r['exact_node_bound'],'node-bound:'+direction+':'+label)
            check(a['goal']==b['goal'] and a['declarations']==b['declarations'],
                  'interface-preservation:'+direction+':'+label)
            RECEIPTS.append(r)
    scoped={
      'parameter_witness_retained_base':anchored_progress(P.v('a'),True),
      'nonzero_witness':anchored_progress(P.s(P.ZERO)),
      'nested_progress_with_retained_base':anchored_progress(P.v('a'),True,True),
    }
    # New unary binders must avoid capture under both QE and transport.
    q_major=P.q('y',P.q('a',P.eq(P.v('y'),P.v('a'))))
    q_base=P.q('a',P.eq(P.ZERO,P.v('a')))
    q_target=P.q('b',P.eq(P.v('a'),P.v('b')))
    scoped['Q_capture_avoiding_specialization']={
      'declarations':copy.deepcopy(DEFS),'scope':['a'],'context':[q_major,q_base],
      'goal':q_target,'proof':{'rule':'qe','conclusion':q_target,
       'major':P.hyp(q_major,0),'base':P.hyp(q_base,1),'term':P.v('a')}}
    tr_before=P.q('b',P.eq(['id',P.v('a')],P.v('b')))
    scoped['Q_capture_avoiding_transport']={
      'declarations':copy.deepcopy(DEFS),'scope':['a'],'context':[tr_before],
      'goal':q_target,'proof':{'rule':'tr','conclusion':q_target,
       'equality':comp(['id',P.v('a')],P.v('a')),'before':P.hyp(tr_before,0),
       'variable':'transport_hole','motive':P.q('a',P.eq(P.v('transport_hole'),P.v('a')))}}
    for label,source in scoped.items():
        target=P.compile_scoped(source);returned=P.compile_scoped(target,'reverse')
        for kind,item,module in [('choice',source,C),('localized',target,L),('returned',returned,C)]:
            stats=api_scoped(module,item)
            check(stats['accepted'] and stats['proof_nodes']==P.counts(item['proof'])['nodes'],
                  'scoped-api:'+kind+':'+label)
            write(ROOT/'fixtures'/'scoped'/kind/(label+'.json'),item)
        for direction,a,b in [('forward',source,target),('reverse',target,returned)]:
            r=P.receipt(a['proof'],b['proof'],direction);r['fixture']=label
            check(r['exact_node_bound'],'scoped-node-bound:'+direction+':'+label)
            RECEIPTS.append(r)
    captured=copy.deepcopy(scoped['Q_capture_avoiding_specialization'])
    captured['proof']['conclusion']=P.q('a',P.eq(P.v('a'),P.v('a')))
    rejected=False
    try:api_scoped(L,captured)
    except L.ProofError:rejected=True
    check(rejected,'Q-capture:reject-captured-result')
    # Direct Q-progress accepts no hidden base requirement, even with an
    # arbitrary retained context. The body really depends on its counter.
    atomic=scoped['parameter_witness_retained_base']
    x,y,body=atomic['proof']['conclusion'][1:]
    direct=copy.deepcopy(atomic)
    direct['goal']=P.q(y,P.subst(body,{x:atomic['proof']['witness']}))
    direct['proof']={'rule':'qp','conclusion':copy.deepcopy(direct['goal']),
                     'eigen':atomic['proof']['eigen'],'premise':atomic['proof']['premise']}
    check(api_scoped(L,direct)['accepted'],'direct-qp:retained-context-and-actual-IH')
    backward=P.compile_scoped(direct,'reverse')
    check(api_scoped(C,backward)['accepted'],'direct-qp:reverse-compiler')
    write(ROOT/'fixtures'/'scoped'/'localized'/'direct_q_progress.json',direct)
    write(ROOT/'fixtures'/'scoped'/'returned'/'direct_q_progress.json',backward)
    r=P.receipt(direct['proof'],backward['proof'],'reverse');r['fixture']='direct_q_progress'
    RECEIPTS.append(r);check(r['exact_node_bound'],'direct-qp:reverse-exact-bound')

    # Complete closed standalone-CLI validation normally and with -O.
    negatives=[]
    seed=next(item for kind,label,item in positive if kind=='localized' and label=='choice_progress_induction')
    def bad(label,edit):
        item=copy.deepcopy(seed);edit(item);negatives.append((label,item))
    bad('unrecognized_rule',lambda p:p['proof'].update(rule='oracle'))
    bad('extra_packet_field',lambda p:p.update(extra=True))
    bad('extra_proof_field',lambda p:p['proof'].update(extra=True))
    bad('old_DI_mode',lambda p:p['proof']['major'].update(mode='ind'))
    bad('out_of_scope_witness',lambda p:p['proof']['major'].update(witness=P.v('absent')))
    # Locate the inserted local unary progression.
    def qp(p):return p['proof']['major']['premise']['major']
    bad('compound_Q_progress',lambda p:qp(p).update(conclusion=P.q('x',P.d('a','b',P.eq(P.ZERO,P.ZERO)))))
    bad('not_Q_progress',lambda p:qp(p).update(conclusion=P.eq(P.ZERO,P.ZERO)))
    bad('reused_Q_eigenvariable',lambda p:qp(p).update(eigen=p['proof']['major']['eigen']))
    bad('boolean_hypothesis_index',lambda p:p['proof']['major']['premise']['base'].update(index=True))
    bad('wrong_base_hypothesis_index',lambda p:p['proof']['major']['premise']['base'].update(index=99))
    bad('false_QE_target',lambda p:p['proof']['major']['premise'].update(term=P.ZERO))
    bad('malformed_recursion_declaration',lambda p:p['declarations'][-1].update(arity=True))
    bad('forward_function_reference',lambda p:p['declarations'].__setitem__(0,{'name':'alias','kind':'comp','arity':1,'outer':'later','inners':['id']}))
    bad('missing_Q_eigenvariable',lambda p:qp(p).pop('eigen'))
    bad('wrong_compound_progress_IH',lambda p:qp(p).update(premise={'rule':'hyp','conclusion':P.eq(P.ZERO,P.ZERO),'index':0}))
    for label,item in negatives:write(ROOT/'fixtures'/'negative'/(label+'.json'),item)
    with tempfile.TemporaryDirectory() as directory:
        directory=Path(directory)
        for kind in ('choice','localized'):
            shutil.copyfile(ROOT/(kind+'_checker.py'),directory/(kind+'_checker.py'))
        for kind,label,item in positive:
            checker='localized' if kind=='localized' else 'choice'
            for optimize in (False,True):
                cmd=[sys.executable]+(['-O'] if optimize else [])+[str(directory/(checker+'_checker.py'))]
                result=subprocess.run(cmd,input=json.dumps(item),text=True,capture_output=True,cwd=directory)
                check(result.returncode==0 and result.stdout=='ACCEPT\n' and not result.stderr,
                      'standalone-cli:'+kind+':'+label+(':optimized' if optimize else ':normal'))
        for label,item in negatives:
            for optimize in (False,True):
                cmd=[sys.executable]+(['-O'] if optimize else [])+[str(directory/'localized_checker.py')]
                result=subprocess.run(cmd,input=json.dumps(item),text=True,capture_output=True,cwd=directory)
                check(result.returncode==1 and result.stdout=='REJECT\n' and not result.stderr,
                      'negative-cli:'+label+(':optimized' if optimize else ':normal'))
        for label,raw in [('duplicate_json_key','{"declarations":[],"declarations":[],"goal":[],"proof":{}}'),
                          ('nonfinite_json','{"declarations":[],"goal":NaN,"proof":{}}')]:
            for optimize in (False,True):
                cmd=[sys.executable]+(['-O'] if optimize else [])+[str(directory/'localized_checker.py')]
                result=subprocess.run(cmd,input=raw,text=True,capture_output=True,cwd=directory)
                check(result.returncode==1 and result.stdout=='REJECT\n' and not result.stderr,
                      'negative-json:'+label+(':optimized' if optimize else ':normal'))
    result={'checks':len(ROWS),'passed':sum(r['passed'] for r in ROWS),'failed':sum(not r['passed'] for r in ROWS),
            'inherited_closed_fixtures':21,'closed_variants':len(positive),'scoped_families':len(scoped),
            'compiler_receipts':len(RECEIPTS),'python':sys.version,'details':ROWS}
    write(ROOT/'validation.json',result);write(ROOT/'compiler_receipts.json',RECEIPTS)
    print(json.dumps({k:v for k,v in result.items() if k not in ('details','python')},sort_keys=True))

if __name__=='__main__':run()
