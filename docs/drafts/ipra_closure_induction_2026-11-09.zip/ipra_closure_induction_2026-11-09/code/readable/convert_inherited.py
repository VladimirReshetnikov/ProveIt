"""Untrusted adapter for inherited closed D-only Choice proof fixtures.

Old ordinary-assumption clauses become ordinary formula hypotheses; old DE
clauses become explicit Q formulas. Other arbitrary external clauses are not
an input to this fixture adapter. The general main compiler has no such
restriction on ordinary Eq/Q/D contexts or scopes.
"""
import copy
import compiler as P

def convert(proof,context=()):
    out=copy.deepcopy(proof); rule=proof['rule']
    if rule=='use':
        index=proof['clause']; kind,formula=context[index]
        if kind=='hyp':
            return P.hyp(copy.deepcopy(proof['conclusion']),index)
        return {'rule':'qe','conclusion':copy.deepcopy(proof['conclusion']),
                'major':P.hyp(copy.deepcopy(formula),index),
                'base':convert(proof['premise'],context),'term':copy.deepcopy(proof['term'])}
    if rule=='di':
        x,y,body=proof['conclusion'][1:]
        term=P.ZERO if proof['mode']=='case' else P.v(proof['eigen'])
        local=P.subst(body,{x:proof['witness'],y:term})
        out['premise']=convert(proof['premise'],context+(('hyp',local),))
        return out
    if rule=='de':
        out['major']=convert(proof['major'],context)
        x,y,body=proof['major']['conclusion'][1:]
        closure=P.subst(P.q(y,body),{x:P.v(proof['eigen'])})
        out['premise']=convert(proof['premise'],context+(('closure',closure),))
        return out
    for key in P.CHILDREN:
        if key in proof: out[key]=convert(proof[key],context)
    return out

def packet(source):
    result=copy.deepcopy(source); result['proof']=convert(source['proof'])
    return result
