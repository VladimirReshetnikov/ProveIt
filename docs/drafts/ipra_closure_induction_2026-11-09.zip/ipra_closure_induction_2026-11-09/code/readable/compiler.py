"""Untrusted general proof-tree translations between explicit Choice and localized Eq/Q/D.

No checker is imported. Check input and output independently. Forward maps
Choice to localized and has N+3r nodes, where r counts progress-DI nodes.
Reverse maps localized to Choice and has N+2q nodes, where q counts Q-progress.
Input must be a valid proof in its stated scope/context; packet goals are closed.
"""
import argparse
import copy
import json
import sys

ZERO=["0"]
CHILDREN=("premise","major","base","equality","before")

def v(name): return ["$",name]
def s(term): return ["S",term]
def eq(a,b): return ["=",a,b]
def q(y,body): return ["Q",y,body]
def d(x,y,body): return ["D",x,y,body]
def hyp(formula,index): return {"rule":"hyp","conclusion":formula,"index":index}

def strings(obj):
    if isinstance(obj,str): yield obj
    elif isinstance(obj,(list,tuple)):
        for child in obj: yield from strings(child)
    elif isinstance(obj,dict):
        for key,child in obj.items():
            yield key
            yield from strings(child)

def term_names(t):
    if t[0]=="$": return {t[1]}
    out=set()
    for child in t[1:]: out.update(term_names(child))
    return out

def formula_names(a):
    if a[0]=="=": return term_names(a[1])|term_names(a[2])
    return set(a[1:-1])|formula_names(a[-1])

def subst_term(t,mapping):
    if t[0]=="$": return copy.deepcopy(mapping.get(t[1],t))
    return [t[0],*[subst_term(x,mapping) for x in t[1:]]]

def subst(a,mapping):
    if a[0]=="=": return eq(subst_term(a[1],mapping),subst_term(a[2],mapping))
    binders=list(a[1:-1]); body=copy.deepcopy(a[-1])
    active={x:t for x,t in mapping.items() if x not in binders}
    image=set()
    for term in active.values(): image.update(term_names(term))
    occupied=formula_names(a)|image|set(active)
    for i,old in enumerate(binders):
        if old in image:
            j=0
            while '_alpha'+str(j) in occupied: j+=1
            new='_alpha'+str(j); occupied.add(new)
            body=subst(body,{old:v(new)}); binders[i]=new
    return [a[0],*binders,subst(body,active)]

def renamed(proof,old,new):
    """Rename a free numerical parameter, respecting every logical and proof binder."""
    out=copy.deepcopy(proof); mapping={old:v(new)}; rule=proof['rule']
    out['conclusion']=subst(proof['conclusion'],mapping)
    for key in ('witness','term'):
        if key in proof: out[key]=subst_term(proof[key],mapping)
    if rule=='tr' and proof['variable']!=old:
        out['motive']=subst(proof['motive'],mapping)
    for key in CHILDREN:
        if key not in proof: continue
        if key=='premise' and rule in ('di','de','qp') and proof['eigen']==old: continue
        out[key]=renamed(proof[key],old,new)
    return out

def insert_context(proof,cutoff,amount=1):
    """Weaken by inserting formula slots before cutoff; retain every local binder."""
    out=copy.deepcopy(proof)
    if out['rule']=='hyp' and out['index']>=cutoff: out['index']+=amount
    for key in CHILDREN:
        if key in proof: out[key]=insert_context(proof[key],cutoff,amount)
    return out

def counts(proof):
    result={'nodes':1,'progress_di':int(proof['rule']=='di' and proof.get('mode')=='ind'),
            'q_progress':int(proof['rule']=='qp')}
    for key in CHILDREN:
        if key in proof:
            for metric,value in counts(proof[key]).items(): result[metric]+=value
    return result

class Compiler:
    def __init__(self,data): self.occupied=set(strings(data)); self.counter=0
    def fresh(self):
        while True:
            x='_compile'+str(self.counter); self.counter+=1
            if x not in self.occupied: self.occupied.add(x); return x
    def forward(self,proof,depth=0):
        out=copy.deepcopy(proof); rule=proof['rule']
        if rule=='qp': raise ValueError('Q-progress is absent from the Choice source')
        if rule=='di':
            out.pop('mode')
            if proof['mode']=='case':
                out['premise']=self.forward(proof['premise'],depth+1)
                return out
            if proof['mode']!='ind' or proof['conclusion'][3][0]!='=':
                raise ValueError('Invalid progress-DI source')
            x,y,body=proof['conclusion'][1:]
            witness=proof['witness']; outer=proof['eigen']
            binder,inner=self.fresh(),self.fresh()
            matrix=subst(body,{x:witness,y:v(binder)})
            base=subst(body,{x:witness,y:ZERO})
            target=subst(body,{x:witness,y:s(v(outer))})
            premise=self.forward(renamed(proof['premise'],outer,inner),depth+1)
            premise=insert_context(premise,depth)
            progress={'rule':'qp','conclusion':q(binder,matrix),'eigen':inner,'premise':premise}
            out['premise']={'rule':'qe','conclusion':target,'major':progress,
                            'base':hyp(base,depth),'term':s(v(outer))}
            return out
        for key in CHILDREN:
            if key in proof:
                out[key]=self.forward(proof[key],depth+(1 if rule=='de' and key=='premise' else 0))
        return out
    def reverse(self,proof,depth=0):
        out=copy.deepcopy(proof); rule=proof['rule']
        if rule=='qp':
            y,body=proof['conclusion'][1:]
            unused,opened=self.fresh(),self.fresh()
            major={'rule':'di','conclusion':d(unused,y,body),'witness':ZERO,
                   'eigen':proof['eigen'],'mode':'ind',
                   'premise':self.reverse(proof['premise'],depth+1)}
            return {'rule':'de','conclusion':copy.deepcopy(proof['conclusion']),
                    'major':major,'eigen':opened,'premise':hyp(copy.deepcopy(proof['conclusion']),depth)}
        if rule=='di': out['mode']='case'
        for key in CHILDREN:
            if key in proof:
                added=1 if key=='premise' and rule in ('di','de') else 0
                out[key]=self.reverse(proof[key],depth+added)
        return out

def compile_packet(packet,direction='forward'):
    out=copy.deepcopy(packet)
    out['proof']=getattr(Compiler(packet),direction)(packet['proof'])
    return out

def compile_scoped(fixture,direction='forward'):
    out=copy.deepcopy(fixture)
    out['proof']=getattr(Compiler(fixture),direction)(fixture['proof'],len(fixture['context']))
    return out

def receipt(before,after,direction='forward'):
    a,b=counts(before),counts(after)
    predicted=a['nodes']+(3*a['progress_di'] if direction=='forward' else 2*a['q_progress'])
    return {'direction':direction,'source':a,'target':b,'predicted_nodes':predicted,
            'exact_node_bound':b['nodes']==predicted}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--direction',choices=('forward','reverse'),default='forward')
    parser.add_argument('--receipt')
    args=parser.parse_args(); source=json.load(sys.stdin)
    target=compile_packet(source,args.direction)
    if args.receipt:
        with open(args.receipt,'w') as stream:
            json.dump(receipt(source['proof'],target['proof'],args.direction),stream,indent=2)
            stream.write('\n')
    json.dump(target,sys.stdout,indent=2); sys.stdout.write('\n')
