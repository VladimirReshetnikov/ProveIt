"""Reproduce the eight finite cases for each of three compact checkers.

Run this script from any working directory. By default the checkers are
beside this file; --directory may select another directory. Every packet
is included here, so neither a repository checkout nor downloaded drafts
are needed. These 48 CLI runs are finite validation, not formal verification.
"""

import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys


PROGRAMS = (
    "localized_tokens.py",
    "localized_structure.py",
    "localized_bytes.py",
)


def cases():
    """The same eight packets used in the original compact validation."""
    equation = [[5, [0], 2], [0]]
    hypothesis = [[-1, [0], 2], [0]]
    motive = [[[-1], [0], 2], 1]
    direct_induction = [
        [0, 0],
        [hypothesis, motive],
        [0, [0, 0, 0]],
        [equation],
    ]
    # Inherited Choice-DI focused packet: the native theorem Q_y(y=1).
    # It uses the false zero instance through paired Case introduction.
    retained_false_base = [
        [0, 0],
        [[0, [0]], [[5, [0], [-1]], [0]]],
        [0, 0],
        [[[[0], [0], [-1]], [-1]], [1, [0]]],
        [[], [0, 0, 0]],
        [[[1, [0]], [1, [0]], [1, [0]]], 0],
        [[1, [0]]],
    ]
    return [
        ("direct_q_induction", direct_induction, True),
        ("retained_false_base_D_case", retained_false_base, True),
        ("zero_computation", [[0, 0], [[0, 0, 0], 0]], True),
        (
            "Q_compound_progress_rejected",
            [[0, 0], [0, [0, 0, 0]], [[0, 0, [0, 0]]]],
            False,
        ),
        (
            "Q_unary_compound_progress_rejected",
            [[0, 0], [0, [0, 0, 0]], [[[0, 0]]]],
            False,
        ),
        (
            "equation_intro_rejected",
            [[0, 0], [0, [0, 0, 0]], [0, [0]]],
            False,
        ),
        (
            "negative_free_parameter",
            [[0, 0], [[0, -1, 0], -1]],
            False,
        ),
        ("four_arity_rejected", [[0, 0], [0, 0, 0, 0]], False),
    ]


def validate(directory):
    paths = [directory / name for name in PROGRAMS]
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(path)
    hashes = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in paths
    }
    runs = []
    for path in paths:
        for name, packet, expected in cases():
            for optimized in (False, True):
                command = [sys.executable]
                if optimized:
                    command.append("-O")
                command.append(str(path))
                process = subprocess.run(
                    command,
                    input=json.dumps(packet),
                    text=True,
                    capture_output=True,
                    timeout=20,
                )
                observed = (
                    process.stdout,
                    process.stderr,
                    process.returncode,
                )
                required = (
                    ("ACCEPT\n", "", 0)
                    if expected
                    else ("REJECT\n", "", 1)
                )
                if observed != required:
                    raise RuntimeError(
                        repr((path.name, name, optimized, observed, required))
                    )
                runs.append({
                    "program": path.name,
                    "case": name,
                    "optimized": optimized,
                    "accepted": expected,
                })
    return {
        "scope": (
            "Eight fixed packets for each of three standalone checkers, "
            "in normal and optimized Python: 48 finite CLI runs. "
            "This is not a formal correctness proof or a universal compiler."
        ),
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "checker_sha256": hashes,
        "fixture_count": len(cases()),
        "program_count": len(paths),
        "run_count": len(runs),
        "all_checks_passed": True,
        "runs": runs,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--directory", type=Path, default=Path(__file__).resolve().parent,
        help="Directory containing the three named compact checkers.",
    )
    parser.add_argument(
        "--receipt", type=Path,
        help="Optional destination for the full JSON validation receipt.",
    )
    args = parser.parse_args()
    result = validate(args.directory.resolve())
    if args.receipt is not None:
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        args.receipt.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "all_checks_passed": result["all_checks_passed"],
        "fixture_count": result["fixture_count"],
        "program_count": result["program_count"],
        "run_count": result["run_count"],
    }, indent=2))


if __name__ == "__main__":
    main()
