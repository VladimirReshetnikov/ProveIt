#!/usr/bin/env python3
"""Finite evaluations of the paper's actual binary-recursion descriptions.

Only Python's standard library is needed. Run from any directory:
    python3 check_constructions.py

This is an executable construction check on standard natural numbers,
not a proof of the arbitrary-model theorem. In particular, the evaluator
below is metatheoretic Python code, NOT an object-language universal
primitive-recursive evaluator asserted by the theory.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
import json


@dataclass(frozen=True)
class Term:
    tag: str
    data: int = 0
    children: tuple["Term", ...] = ()


def var(index: int) -> Term:
    return Term("var", index)


ZERO = Term("zero")


def succ(term: Term) -> Term:
    return Term("succ", children=(term,))


def app(symbol: int, first: Term, second: Term) -> Term:
    return Term("app", symbol, (first, second))


def free_vars(term: Term) -> set[int]:
    if term.tag == "var":
        return {term.data}
    return set().union(*(free_vars(t) for t in term.children))


def dependencies(term: Term) -> set[int]:
    own = {term.data} if term.tag == "app" else set()
    return own.union(*(dependencies(t) for t in term.children))


class BinaryDescriptions:
    def __init__(self) -> None:
        self.names: list[str] = []
        self.bodies: list[Term] = []
        self.tables: dict[tuple[int, int], list[int]] = {}

    def admit(self, name: str, body: Term) -> int:
        index = len(self.bodies)
        assert free_vars(body) <= {0, 1}, "Body leaks an extra input"
        assert all(d < index for d in dependencies(body)), "Cyclic definition"
        self.names.append(name)
        self.bodies.append(body)
        return index

    def evaluate(self, term: Term, env: tuple[int, ...]) -> int:
        if term.tag == "zero":
            return 0
        if term.tag == "var":
            return env[term.data]
        if term.tag == "succ":
            return self.evaluate(term.children[0], env) + 1
        if term.tag == "app":
            n = self.evaluate(term.children[0], env)
            a = self.evaluate(term.children[1], env)
            return self.recurse(term.data, n, a)
        raise ValueError(term.tag)

    def recurse(self, symbol: int, n: int, a: int) -> int:
        assert n >= 0 and a >= 0
        table = self.tables.setdefault((symbol, a), [a])
        while len(table) <= n:
            counter = len(table) - 1
            table.append(self.evaluate(self.bodies[symbol], (counter, table[-1])))
        return table[n]


def build() -> tuple[BinaryDescriptions, dict[str, Term]]:
    language = BinaryDescriptions()
    counter, value = var(0), var(1)
    one = succ(ZERO)
    pred_symbol = language.admit("pred", counter)
    zero_symbol = language.admit("zero_tail", ZERO)
    add_symbol = language.admit("add", succ(value))

    def pred(x: Term) -> Term:
        return app(pred_symbol, x, ZERO)

    def zero_tail(z: Term, a: Term) -> Term:
        return app(zero_symbol, z, a)

    def add(x: Term, y: Term) -> Term:
        return app(add_symbol, y, x)

    sub_symbol = language.admit("sub", pred(value))

    def sub(x: Term, y: Term) -> Term:
        return app(sub_symbol, y, x)

    def select(z: Term, a: Term, b: Term) -> Term:
        return add(zero_tail(z, a), zero_tail(zero_tail(z, one), b))

    def unit_error(r: Term) -> Term:
        return select(r, one, select(pred(r), ZERO, one))

    def equality_error(x: Term, y: Term) -> Term:
        return unit_error(sub(succ(x), y))

    def equality_select(x: Term, y: Term, a: Term, b: Term) -> Term:
        return select(equality_error(x, y), a, b)

    triangle_symbol = language.admit("triangle", add(value, succ(counter)))

    def triangle(n: Term) -> Term:
        return app(triangle_symbol, n, ZERO)

    row_symbol = language.admit(
        "row",
        equality_select(triangle(succ(value)), succ(counter), succ(value), value),
    )

    def row(n: Term) -> Term:
        return app(row_symbol, n, ZERO)

    def pair(x: Term, y: Term) -> Term:
        return add(triangle(add(x, y)), y)

    def right(w: Term) -> Term:
        return sub(w, triangle(row(w)))

    def left(w: Term) -> Term:
        return sub(row(w), right(w))

    terms = {
        "triangle": triangle(counter),
        "row": row(counter),
        "pair": pair(counter, value),
        "left": left(counter),
        "right": right(counter),
        "equality_error": equality_error(counter, value),
        "selector": select(var(0), var(1), var(2)),
    }
    return language, terms


def main() -> None:
    language, terms = build()

    def ev(name: str, *inputs: int) -> int:
        return language.evaluate(terms[name], inputs)

    equality_checks = 0
    for x, y in product(range(21), repeat=2):
        assert ev("equality_error", x, y) == (0 if x == y else 1)
        equality_checks += 1

    selector_checks = 0
    for z, a, b in product(range(9), range(6), range(6)):
        assert ev("selector", z, a, b) == (a if z == 0 else b)
        selector_checks += 1

    for n in range(351):
        r = ev("row", n)
        assert r * (r + 1) // 2 <= n < (r + 1) * (r + 2) // 2

    pair_checks = 0
    block_checks = 0
    for x, y in product(range(13), repeat=2):
        w = ev("pair", x, y)
        assert w == (x + y) * (x + y + 1) // 2 + y
        assert ev("left", w) == x
        assert ev("right", w) == y
        pair_checks += 1
    for z in range(25):
        t = ev("triangle", z)
        assert ev("row", t) == z
        for y in range(z + 1):
            assert ev("row", t + y) == z
            block_checks += 1

    tuple_checks = 0
    tuple_coordinate_checks = 0
    for length in range(5):
        for values in product(range(2), repeat=length):
            code = 0
            for value in reversed(values):
                code = ev("pair", value, code)
            remaining = code
            for value in values:
                assert ev("left", remaining) == value
                remaining = ev("right", remaining)
                tuple_coordinate_checks += 1
            assert remaining == 0
            tuple_checks += 1

    result = {
        "status": "PASS",
        "scope": "Finite standard-natural evaluation; not arbitrary-model proof",
        "evaluator": "Only zero, successor, variables, and finite binary recursors",
        "descriptors": [
            {
                "index": i,
                "name": name,
                "free_body_inputs": sorted(free_vars(language.bodies[i])),
                "earlier_dependencies": sorted(dependencies(language.bodies[i])),
            }
            for i, name in enumerate(language.names)
        ],
        "checks": {
            "equality_bit_pairs_0_through_20": equality_checks,
            "selector_triples": selector_checks,
            "row_indices_0_through_350": 351,
            "pairing_pairs_0_through_12": pair_checks,
            "triangular_boundaries_0_through_24": 25,
            "block_instances": block_checks,
            "binary_tuples_length_0_through_4": tuple_checks,
            "decoded_tuple_coordinates": tuple_coordinate_checks,
        },
        "no_extra_free_body_inputs": True,
        "all_description_dependencies_earlier": True,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
