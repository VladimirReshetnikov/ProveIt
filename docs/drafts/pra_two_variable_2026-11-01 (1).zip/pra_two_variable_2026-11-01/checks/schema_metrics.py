#!/usr/bin/env python3
"""Independent AST ledger for the proposed two-variable PRA axiom bases.

Python standard library only.  Run:
    python3 schema_metrics.py > schema_metrics.json

This is a partial *schema-display* metric, not a description length for an
entire theory. Every variable/constant occurrence, function/schematic
application, equality, connective, falsity, and individual quantifier is
one node. Quantifier binder names are labels, not extra child occurrences.
All universal closures are included. Negation is expanded to implication
to falsity; 1 is expanded to S(0). There is no shared-subexpression credit.

The instantiated bodies of h, A, s and t, the infinite language generator,
binding metadata beyond the quantifier node, and the proof calculus are
outside the metric. No individual functions are quantified over.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Any


@dataclass(frozen=True)
class Node:
    kind: str
    children: tuple["Node", ...] = ()
    label: str | None = None

    def count(self) -> int:
        return 1 + sum(child.count() for child in self.children)

    def tree(self) -> dict[str, Any]:
        result: dict[str, Any] = {"kind": self.kind}
        if self.label is not None:
            result["label"] = self.label
        if self.children:
            result["children"] = [child.tree() for child in self.children]
        return result

    def sexpr(self) -> str:
        label = self.kind if self.label is None else f"{self.kind}:{self.label}"
        if not self.children:
            return label
        return "(" + label + " " + " ".join(c.sexpr() for c in self.children) + ")"


def var(name: str) -> Node:
    return Node("var", label=name)


ZERO = Node("constant", label="0")
FALSE = Node("false")


def app(name: str, *args: Node) -> Node:
    return Node("function", args, name)


def term_hole(name: str, *args: Node) -> Node:
    return Node("term-placeholder", args, name)


def formula_hole(name: str, *args: Node) -> Node:
    return Node("formula-placeholder", args, name)


def eq(left: Node, right: Node) -> Node:
    return Node("=", (left, right))


def connective(name: str, left: Node, right: Node) -> Node:
    return Node(name, (left, right))


def forall(name: str, body: Node) -> Node:
    return Node("forall", (body,), name)


def close(names: list[str], body: Node) -> Node:
    for name in reversed(names):
        body = forall(name, body)
    return body


def computation_axioms() -> tuple[Node, Node]:
    n, a = var("n"), var("a")
    base = forall("a", eq(app("R_h", ZERO, a), a))
    step = close(
        ["n", "a"],
        eq(app("R_h", app("S", n), a), term_hole("h", n, app("R_h", n, a))),
    )
    return base, step


def induction_axioms(q: int) -> dict[str, Node]:
    if q < 0:
        raise ValueError("The number of frozen parameters must be nonnegative.")
    names = ["c"] if q == 1 else [f"c{i + 1}" for i in range(q)]
    params = tuple(var(name) for name in names)
    n = var("n")
    successor = app("S", n)
    forbidden = eq(ZERO, app("S", ZERO))

    def a(x: Node) -> Node:
        return formula_hole("A", x, *params)

    def e(x: Node) -> Node:
        return eq(term_hole("s", x, *params), term_hole("t", x, *params))

    progress = forall("n", connective("implies", a(n), a(successor)))
    conclusion = forall("n", a(n))
    ordinary = close(
        names,
        connective("implies", connective("and", a(ZERO), progress), conclusion),
    )
    fused = close(
        names,
        connective(
            "implies",
            connective("and", connective("or", a(ZERO), forbidden), progress),
            conclusion,
        ),
    )
    zero_exception = connective("or", eq(n, ZERO), e(n))
    restricted = close(
        names,
        connective(
            "implies",
            forall("n", connective("implies", zero_exception, e(successor))),
            forall("n", zero_exception),
        ),
    )
    return {
        "separation": connective("implies", forbidden, FALSE),
        "ordinary_qfi": ordinary,
        "fused_qfi": fused,
        "fixed_zero_equation": restricted,
    }


def row(q: int) -> dict[str, Any]:
    base, step = computation_axioms()
    matrices = induction_axioms(q)
    counts = {name: node.count() for name, node in matrices.items()}
    computation = base.count() + step.count()
    return {
        "frozen_induction_parameters": q,
        "components": {
            "binary_base": base.count(),
            "binary_step": step.count(),
            **counts,
        },
        "theory_display_totals": {
            "binary_separation_ordinary_qfi": computation
            + counts["separation"]
            + counts["ordinary_qfi"],
            "binary_fused_qfi": computation + counts["fused_qfi"],
            "binary_separation_fixed_zero": computation
            + counts["separation"]
            + counts["fixed_zero_equation"],
        },
    }


def main() -> None:
    rows = [row(q) for q in range(5)]
    for q, item in enumerate(rows):
        components = item["components"]
        totals = item["theory_display_totals"]
        assert components["binary_base"] == 6
        assert components["binary_step"] == 12
        assert components["separation"] == 6
        assert components["ordinary_qfi"] == 14 + 5 * q
        assert components["fused_qfi"] == 19 + 5 * q
        assert components["fixed_zero_equation"] == 29 + 7 * q
        assert totals["binary_separation_ordinary_qfi"] == 38 + 5 * q
        assert totals["binary_fused_qfi"] == 37 + 5 * q
        assert totals["binary_separation_fixed_zero"] == 53 + 7 * q
    assert rows[1]["theory_display_totals"]["binary_fused_qfi"] == 42
    assert rows[1]["theory_display_totals"]["binary_separation_fixed_zero"] == 60

    base, step = computation_axioms()
    one = induction_axioms(1)
    examples = {"binary_base": base, "binary_step": step, **one}
    result = {
        "metric": "Expanded schema-display AST; one node per occurrence",
        "quantifier_convention": (
            "Every quantifier, including every universal closure, costs one node; "
            "its binder name is metadata and has no extra variable-occurrence cost."
        ),
        "scope": (
            "The proposed theories use the q=1 row (unused c permitted). The q>1 "
            "rows describe the unrestricted-parameter comparison templates. "
            "Two-variable axioms do not restrict the ambient first-order proof "
            "calculus. There are infinitely many binary R_h symbols, plus 0 and S."
        ),
        "excluded_costs": [
            "actual substituted program and formula bodies",
            "the complete effective description grammar and axiom enumerator",
            "variable-binding metadata beyond the quantifier node",
            "the ambient logical proof calculus",
            "symbol spelling and name encodings",
        ],
        "closed_form_totals": {
            "binary_separation_ordinary_qfi": "38+5q",
            "binary_fused_qfi": "37+5q",
            "binary_separation_fixed_zero": "53+7q",
        },
        "rows": rows,
        "one_parameter_asts": {
            name: {"nodes": node.count(), "sexpr": node.sexpr(), "tree": node.tree()}
            for name, node in examples.items()
        },
        "checks": "All displayed component, affine-count, and q=1 checks passed.",
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
