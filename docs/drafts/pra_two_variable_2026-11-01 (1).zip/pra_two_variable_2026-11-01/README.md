# A two-variable axiomatization of primitive recursive arithmetic

Prepared for Vladimir Reshetnikov, 1 November 2026.

## Result

Use only `0`, `S`, and binary initialized recursors

```text
R_h(0,a) = a
R_h(Sn,a) = h(n,R_h(n,a))
```

where `h` is any earlier finite term with only the counter and current
value as free inputs. Add the fused quantifier-free induction schema in
`axioms.txt`, restricted to **one** frozen individual parameter.

The resulting theory is definitionally equivalent to the matching
first-order version of PRA, separately in classical and intuitionistic
logic. Every nonlogical axiom has at most two distinct variables; the
ambient first-order logic and its proof calculus remain unrestricted.

The new result relative to the eight reviewed drafts is the uniform
one-parameter bound. Binary recursors and the fused induction template
were already present. The shortest readable display stays at 42 nodes
under the explicitly partial convention used in the drafts. This is not
an absolute minimality or historical-priority claim.

## Main proof

The report gives a self-contained arbitrary-model proof. A finite
equality test is constructed with equation induction using at most one
frozen parameter. An exact-boundary triangular decoder then proves a
pairing retraction under the same restriction. Nested pairs pack every
finite parameter tuple into one input. A state-pair compiler simulates
arbitrary ordinary primitive recursion. Internal recursion uniqueness
proves both interpretation round trips are identities.

## Contents

- `report.tex`, `report.pdf`: complete article and compiled PDF.
- `axioms.txt`: the two exact nonlogical specifications.
- `formal/OneParameterPairing.lean`: constructive arbitrary-carrier
  kernel for the block lemma, triangular boundaries, and pairing.
- `formal/ParameterPacking.lean`: actual finite term/formula syntax,
  substitution, decoder terms, and one-parameter to all-parameter QFI.
- `formal/SCOPE.md`: explicit formalization assumptions and limits.
- `checks/schema_metrics.py`, `checks/schema_metrics.json`: independent
  displayed syntax-tree counts and exact trees.
- `checks/check_constructions.py`, `checks/construction_results.json`:
  finite evaluations of the actual binary-recursion descriptions.
- `sources/source_manifest.json`: all eight archive identities and
  source member hashes at the frozen comparison commit.
- `verification/`: compiler and construction-check records.
- `SHA256SUMS`: hashes of the deliverable files, excluding itself.

## Rebuild

The PDF uses standard LaTeX packages. From this directory run:

```bash
pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape report.tex
pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape report.tex
pdflatex -interaction=nonstopmode -halt-on-error -no-shell-escape report.tex
```

The Lean files require Lean 4.19.0; `OneParameterPairing.lean` imports
only the bundled `Std` library, and `ParameterPacking.lean` uses the
default environment. No Mathlib checkout or project dependency is needed.

```bash
lean formal/OneParameterPairing.lean
lean formal/ParameterPacking.lean
python3 checks/schema_metrics.py
python3 checks/check_constructions.py
```

Both Python programs use only the standard library (Python 3.10 or
newer). Their output is JSON. Run `sha256sum -c SHA256SUMS` to verify the
packaged file hashes.

## Verification boundary

The complete mathematical proof is in the article. The Lean pairing
kernel assumes the listed precursor arithmetic laws and exactly two
permitted induction instances. The term-syntax packing kernel assumes
pairing terms with left/right inverse equations and one-parameter QFI.
The audited endpoints have no global axiom dependencies, but their
explicit hypotheses remain assumptions. The arithmetic bootstrap,
complete first-order proof transport, and interpretation compilers are
not claimed to have an end-to-end proof-assistant formalization.

The numerical checks are reproducibility and implementation checks; they
do not prove the arbitrary-model statements. Every substantive claim is
proved independently of those finite computations in the article.

## Source snapshot

`VladimirReshetnikov/ProveIt`, `docs/drafts`, commit
`586952f1ea771b26e95d724e6419c174302a3eb7`.
All eight source ZIPs matched their recorded Git blob hashes. The
source archives are not duplicated in this package; their exact immutable
URLs and hashes are retained in `sources/source_manifest.json`.
