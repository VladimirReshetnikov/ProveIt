import Std

/-!
# Cantor pairing from two explicitly restricted induction instances

This kernel formalizes the new pairing argument over an arbitrary carrier.
The arithmetic laws in `Basis` are hypotheses proved in the paper using
equation induction with at most one frozen parameter. The row recurrences
are the two cases of a finite equality selector applied to a binary
primitive-recursion description.

Only TWO induction instances are assumed:

* `block_ind`: matrix `sub y z = zero -> row (add (tri z) y) = z`,
  induction variable y, sole frozen parameter z;
* `row_ind`: matrix `row (tri z) = z`, induction variable z, no parameter.

There is no induction hypothesis for arbitrary predicates or for arbitrary
families with two frozen parameters. In particular associativity, order
transitivity, and a previously available pairing function are not assumed.
The exact-schema hypotheses are deliberately explicit, so this kernel does
not claim to formalize the preceding syntax and Boolean-compilation bridge.
-/

namespace OneParameterPairing

universe u

structure Basis (N : Type u) where
  zero : N
  succ : N → N
  pred : N → N
  add : N → N → N
  sub : N → N → N
  tri : N → N
  row : N → N
  sep : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  cover : ∀ x, x = zero ∨ x = succ (pred x)
  add_zero : ∀ x, add x zero = x
  add_succ : ∀ x y, add x (succ y) = succ (add x y)
  zero_add : ∀ y, add zero y = y
  succ_add : ∀ x y, add (succ x) y = succ (add x y)
  add_comm : ∀ x y, add x y = add y x
  sub_zero : ∀ x, sub x zero = x
  sub_succ : ∀ x y, sub x (succ y) = pred (sub x y)
  sub_succ_succ : ∀ x y, sub (succ x) (succ y) = sub x y
  sub_cancel : ∀ c x, sub (add c x) x = c
  sub_into_sum : ∀ x y, sub y (add x y) = zero
  tri_zero : tri zero = zero
  tri_succ : ∀ z, tri (succ z) = add (tri z) (succ z)
  row_zero : row zero = zero
  row_hit : ∀ n, tri (succ (row n)) = succ n →
    row (succ n) = succ (row n)
  row_miss : ∀ n, tri (succ (row n)) ≠ succ n →
    row (succ n) = row n
  block_ind : ∀ z,
    (sub zero z = zero → row (add (tri z) zero) = z) →
    (∀ y, (sub y z = zero → row (add (tri z) y) = z) →
      sub (succ y) z = zero → row (add (tri z) (succ y)) = z) →
    ∀ y, sub y z = zero → row (add (tri z) y) = z
  row_ind : row (tri zero) = zero →
    (∀ z, row (tri z) = z → row (tri (succ z)) = succ z) →
    ∀ z, row (tri z) = z

namespace Basis

variable {N : Type u} (B : Basis N)

theorem succ_injective {x y : N} (h : B.succ x = B.succ y) : x = y := by
  have hp := congrArg B.pred h
  rw [B.pred_succ, B.pred_succ] at hp
  exact hp

theorem succ_ne_zero (x : N) : B.succ x ≠ B.zero := by
  intro h
  have hp := congrArg B.pred h
  rw [B.pred_succ, B.pred_zero] at hp
  rw [hp] at h
  exact B.sep h.symm

theorem sub_self (x : N) : B.sub x x = B.zero := by
  have h := B.sub_cancel B.zero x
  rw [B.zero_add] at h
  exact h

theorem sub_succ_self (x : N) : B.sub (B.succ x) x = B.succ B.zero := by
  have h := B.sub_cancel (B.succ B.zero) x
  rw [B.succ_add, B.zero_add] at h
  exact h

theorem add_left_cancel {a b c : N} (h : B.add a b = B.add a c) : b = c := by
  have hd := congrArg (fun x => B.sub x a) h
  dsimp only at hd
  rw [B.add_comm a b, B.add_comm a c, B.sub_cancel, B.sub_cancel] at hd
  exact hd

theorem bound_predecessor {y z : N} (h : B.sub (B.succ y) z = B.zero) :
    B.sub y z = B.zero ∧ y ≠ z := by
  constructor
  · rcases B.cover z with hz | hz
    · rw [hz, B.sub_zero] at h
      exact False.elim (B.succ_ne_zero y h)
    · rw [hz, B.sub_succ_succ] at h
      rw [hz, B.sub_succ, h, B.pred_zero]
  · intro hy
    rw [← hy, B.sub_succ_self] at h
    exact B.sep h.symm

theorem conditional_block (z : N) (hz : B.row (B.tri z) = z) :
    ∀ y, B.sub y z = B.zero → B.row (B.add (B.tri z) y) = z := by
  apply B.block_ind z
  · intro _
    rw [B.add_zero]
    exact hz
  · intro y ih hnext
    have hb := B.bound_predecessor hnext
    have hrow : B.row (B.add (B.tri z) y) = z := ih hb.1
    have hmiss : B.tri (B.succ (B.row (B.add (B.tri z) y))) ≠
        B.succ (B.add (B.tri z) y) := by
      intro heq
      rw [hrow, B.tri_succ, ← B.add_succ] at heq
      have hs : B.succ z = B.succ y := B.add_left_cancel heq
      have hzy : z = y := B.succ_injective hs
      exact hb.2 hzy.symm
    rw [B.add_succ, B.row_miss _ hmiss, hrow]

theorem row_triangle : ∀ z, B.row (B.tri z) = z := by
  apply B.row_ind
  · rw [B.tri_zero, B.row_zero]
  · intro z ih
    have hrow : B.row (B.add (B.tri z) z) = z :=
      B.conditional_block z ih z (B.sub_self z)
    have hhit : B.tri (B.succ (B.row (B.add (B.tri z) z))) =
        B.succ (B.add (B.tri z) z) := by
      rw [hrow, B.tri_succ, B.add_succ]
    rw [B.tri_succ, B.add_succ, B.row_hit _ hhit, hrow]

theorem row_block (z y : N) (h : B.sub y z = B.zero) :
    B.row (B.add (B.tri z) y) = z :=
  B.conditional_block z (B.row_triangle z) y h

def pair (x y : N) : N := B.add (B.tri (B.add x y)) y

def right (w : N) : N := B.sub w (B.tri (B.row w))

def left (w : N) : N := B.sub (B.row w) (B.right w)

theorem row_pair (x y : N) : B.row (B.pair x y) = B.add x y := by
  exact B.row_block (B.add x y) y (B.sub_into_sum x y)

theorem right_pair (x y : N) : B.right (B.pair x y) = y := by
  unfold right
  rw [B.row_pair]
  unfold pair
  rw [B.add_comm (B.tri (B.add x y)) y, B.sub_cancel]

theorem left_pair (x y : N) : B.left (B.pair x y) = x := by
  unfold left
  rw [B.row_pair, B.right_pair, B.sub_cancel]

theorem pairing_retraction (x y : N) :
    B.left (B.pair x y) = x ∧ B.right (B.pair x y) = y :=
  ⟨B.left_pair x y, B.right_pair x y⟩

theorem pair_injective {x y a b : N} (h : B.pair x y = B.pair a b) :
    x = a ∧ y = b := by
  constructor
  · have hl := congrArg B.left h
    rw [B.left_pair, B.left_pair] at hl
    exact hl
  · have hr := congrArg B.right h
    rw [B.right_pair, B.right_pair] at hr
    exact hr

end Basis

#print axioms Basis.conditional_block
#print axioms Basis.row_triangle
#print axioms Basis.pairing_retraction
#print axioms Basis.pair_injective

end OneParameterPairing
