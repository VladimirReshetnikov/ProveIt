# Formal verification scope

Lean version: 4.19.0, release commit `6caaee842e94`.

## OneParameterPairing.lean

This file proves the new pairing retraction over an arbitrary carrier
`N`. Its `Basis N` structure includes explicit hypotheses for:

- zero, successor, predecessor, addition, subtraction, triangle, and row;
- separation, predecessor equations, and constructor coverage;
- the precursor addition/subtraction equations proved in the paper;
- the two computation cases of the row update;
- exactly the block-induction instance with one frozen parameter;
- exactly the boundary-induction instance with no frozen parameters.

It derives successor injectivity and nonzeroness, cancellation, the
bound-predecessor fact, the conditional block lemma, row values at
triangular boundaries, the two pairing inverses, and pair injectivity.

There is no field giving arbitrary predicate induction. In particular,
the proof cannot obtain induction with two frozen parameters from an
unrestricted Lean assumption hidden in this basis. Numerical induction
on the arbitrary carrier occurs only through the two listed instances.

The arithmetic precursor proofs, their term definitions, and the
equality-selector construction are mathematical proofs in the report.
They are not encoded by this kernel.

## ParameterPacking.lean

This file defines actual finite terms with variable indices, zero,
successor, and binary-symbol application. It defines quantifier-free
formulas with equality, falsity, conjunction, disjunction, and implication.
It proves term and formula substitution correctness without function
extensionality. Pairing and both projections must be actual terms.

Given their two inverse equations, it constructs fixed finite tuple
codes and decoder terms. It proves that the packed formula has exactly
the original interpretation at a coded parameter tuple, and transports
one-parameter QFI to arbitrary finite-parameter QFI.

The theorem is a constructive semantics-and-syntax kernel. It is not a
formalization of an entire intuitionistic first-order derivation system
or of Kripke semantics. The uniform intuitionistic proof transport is
given syntactically in the article.

## Global axioms and assumptions

The seven audited endpoints have empty `#print axioms` dependency lists.
There are no `sorry` proofs or extra axiom declarations. This means no
global classical-choice, propositional-extensionality, or admitted-proof
axiom is used. It does not mean that the explicit theorem hypotheses or
`Basis` fields have been proved within these files.

## Not claimed

- A complete kernel formalization of the descriptor-generating language.
- An end-to-end derivation of all precursor arithmetic facts from F2/Z2.
- A formal first-order derivation-transport checker.
- A kernel-checked proof of both complete bi-interpretations.

Those parts are supplied as explicit mathematical proofs in the article.
