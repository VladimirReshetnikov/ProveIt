/-
Parameter packing for a first-order language with only 0, S, and binary
function symbols. This file checks the passage from one frozen parameter
in quantifier-free induction to arbitrarily many frozen parameters.

Pairing and its projections are actual terms, with explicitly assumed
left/right inverse equations. No arbitrary functions are treated as terms.
The arithmetic construction of these terms is outside this kernel.
-/

namespace ParameterPacking

universe u v w

/- Avoid the library's Fin.cases proof, which depends on propext. -/
@[elab_as_elim] def splitFin {n : Nat} {motive : Fin (n + 1) → Sort w}
    (h0 : motive ⟨0, Nat.zero_lt_succ n⟩)
    (hs : ∀ i : Fin n, motive i.succ) : ∀ i, motive i
  | ⟨0, _⟩ => h0
  | ⟨i + 1, h⟩ => hs ⟨i, Nat.lt_of_succ_lt_succ h⟩

inductive Term (Fn : Type u) (n : Nat) : Type u where
  | var : Fin n → Term Fn n
  | zero : Term Fn n
  | succ : Term Fn n → Term Fn n
  | app : Fn → Term Fn n → Term Fn n → Term Fn n

structure Interpretation (Fn : Type u) (D : Type v) where
  zero : D
  succ : D → D
  app : Fn → D → D → D

namespace Term

def eval {Fn : Type u} {D : Type v} {n : Nat}
    (I : Interpretation Fn D) (env : Fin n → D) : Term Fn n → D
  | .var i => env i
  | .zero => I.zero
  | .succ t => I.succ (eval I env t)
  | .app f s t => I.app f (eval I env s) (eval I env t)

def subst {Fn : Type u} {m n : Nat} (σ : Fin n → Term Fn m) :
    Term Fn n → Term Fn m
  | .var i => σ i
  | .zero => .zero
  | .succ t => .succ (subst σ t)
  | .app f s t => .app f (subst σ s) (subst σ t)

theorem eval_subst {Fn : Type u} {D : Type v} {m n : Nat}
    (I : Interpretation Fn D) (env : Fin m → D)
    (σ : Fin n → Term Fn m) (t : Term Fn n) :
    eval I env (subst σ t) = eval I (fun i => eval I env (σ i)) t := by
  induction t with
  | var i => rfl
  | zero => rfl
  | succ t ih => exact congrArg I.succ ih
  | app f s t ihs iht =>
      exact (congrArg (fun z => I.app f z (eval I env (subst σ t))) ihs).trans
        (congrArg (I.app f (eval I (fun i => eval I env (σ i)) s)) iht)

theorem eval_congr {Fn : Type u} {D : Type v} {n : Nat}
    (I : Interpretation Fn D) (env env' : Fin n → D)
    (he : ∀ i, env i = env' i) (t : Term Fn n) :
    eval I env t = eval I env' t := by
  induction t with
  | var i => exact he i
  | zero => rfl
  | succ t ih => exact congrArg I.succ ih
  | app f s t ihs iht =>
      exact (congrArg (fun z => I.app f z (eval I env t)) ihs).trans
        (congrArg (I.app f (eval I env' s)) iht)

def unary {Fn : Type u} {n : Nat} (f : Term Fn 1) (t : Term Fn n) :
    Term Fn n := subst (fun _ => t) f

theorem eval_unary {Fn : Type u} {D : Type v} {n : Nat}
    (I : Interpretation Fn D) (env : Fin n → D)
    (f : Term Fn 1) (t : Term Fn n) :
    eval I env (unary f t) = eval I (fun _ => eval I env t) f :=
  eval_subst I env (fun _ => t) f

end Term

inductive Formula (Fn : Type u) (n : Nat) : Type u where
  | eq : Term Fn n → Term Fn n → Formula Fn n
  | bot : Formula Fn n
  | conj : Formula Fn n → Formula Fn n → Formula Fn n
  | disj : Formula Fn n → Formula Fn n → Formula Fn n
  | impl : Formula Fn n → Formula Fn n → Formula Fn n

namespace Formula

def eval {Fn : Type u} {D : Type v} {n : Nat}
    (I : Interpretation Fn D) (env : Fin n → D) : Formula Fn n → Prop
  | .eq s t => s.eval I env = t.eval I env
  | .bot => False
  | .conj A B => eval I env A ∧ eval I env B
  | .disj A B => eval I env A ∨ eval I env B
  | .impl A B => eval I env A → eval I env B

def subst {Fn : Type u} {m n : Nat} (σ : Fin n → Term Fn m) :
    Formula Fn n → Formula Fn m
  | .eq s t => .eq (s.subst σ) (t.subst σ)
  | .bot => .bot
  | .conj A B => .conj (subst σ A) (subst σ B)
  | .disj A B => .disj (subst σ A) (subst σ B)
  | .impl A B => .impl (subst σ A) (subst σ B)

theorem eval_subst {Fn : Type u} {D : Type v} {m n : Nat}
    (I : Interpretation Fn D) (env : Fin m → D)
    (σ : Fin n → Term Fn m) (A : Formula Fn n) :
    eval I env (subst σ A) ↔ eval I (fun i => (σ i).eval I env) A := by
  induction A with
  | eq s t =>
      change (s.subst σ).eval I env = (t.subst σ).eval I env ↔ _
      rw [Term.eval_subst, Term.eval_subst]
      exact Iff.rfl
  | bot => exact Iff.rfl
  | conj A B ihA ihB => exact and_congr ihA ihB
  | disj A B ihA ihB => exact or_congr ihA ihB
  | impl A B ihA ihB => exact imp_congr ihA ihB

theorem eval_congr {Fn : Type u} {D : Type v} {n : Nat}
    (I : Interpretation Fn D) (env env' : Fin n → D)
    (he : ∀ i, env i = env' i) (A : Formula Fn n) :
    eval I env A ↔ eval I env' A := by
  induction A with
  | eq s t =>
      change s.eval I env = t.eval I env ↔ _
      rw [Term.eval_congr I env env' he s, Term.eval_congr I env env' he t]
      exact Iff.rfl
  | bot => exact Iff.rfl
  | conj A B ihA ihB => exact and_congr ihA ihB
  | disj A B ihA ihB => exact or_congr ihA ihB
  | impl A B ihA ihB => exact imp_congr ihA ihB

end Formula

def env2 {D : Type v} (x a : D) : Fin 2 → D :=
  splitFin x (fun _ => a)

def index0 : Fin 2 := ⟨0, Nat.zero_lt_succ 1⟩
def index1 : Fin 2 := ⟨1, Nat.lt_succ_self 1⟩

structure Pairing {Fn : Type u} {D : Type v} (I : Interpretation Fn D) where
  pairTerm : Term Fn 2
  leftTerm : Term Fn 1
  rightTerm : Term Fn 1
  left_inverse : ∀ x y,
    leftTerm.eval I (fun _ => pairTerm.eval I (env2 x y)) = x
  right_inverse : ∀ x y,
    rightTerm.eval I (fun _ => pairTerm.eval I (env2 x y)) = y

namespace Pairing

variable {Fn : Type u} {D : Type v} {I : Interpretation Fn D}

def pair (P : Pairing I) (x y : D) : D := P.pairTerm.eval I (env2 x y)
def left (P : Pairing I) (x : D) : D := P.leftTerm.eval I (fun _ => x)
def right (P : Pairing I) (x : D) : D := P.rightTerm.eval I (fun _ => x)

theorem left_pair (P : Pairing I) (x y : D) : P.left (P.pair x y) = x :=
  P.left_inverse x y

theorem right_pair (P : Pairing I) (x y : D) : P.right (P.pair x y) = y :=
  P.right_inverse x y

def code (P : Pairing I) : (k : Nat) → (Fin k → D) → D
  | 0, _ => I.zero
  | k + 1, params =>
      P.pair (params ⟨0, Nat.zero_lt_succ k⟩) (code P k (fun i => params i.succ))

def decode (P : Pairing I) : Nat → D → D
  | 0, z => P.left z
  | i + 1, z => decode P i (P.right z)

theorem decode_code (P : Pairing I) (k : Nat) (params : Fin k → D)
    (i : Fin k) : P.decode i.val (P.code k params) = params i := by
  induction k with
  | zero => exact Fin.elim0 i
  | succ k ih =>
      refine splitFin ?_ (fun j => ?_) i
      · exact P.left_pair _ _
      · change P.decode j.val (P.right (P.pair (params ⟨0, Nat.zero_lt_succ k⟩)
          (P.code k (fun q => params q.succ)))) = params j.succ
        rw [P.right_pair]
        exact ih (fun q => params q.succ) j

def decodeTerm (P : Pairing I) {n : Nat} : Nat → Term Fn n → Term Fn n
  | 0, z => P.leftTerm.unary z
  | i + 1, z => decodeTerm P i (P.rightTerm.unary z)

theorem eval_decodeTerm (P : Pairing I) {n : Nat} (env : Fin n → D)
    (i : Nat) (z : Term Fn n) :
    (P.decodeTerm i z).eval I env = P.decode i (z.eval I env) := by
  induction i generalizing z with
  | zero => exact Term.eval_unary I env P.leftTerm z
  | succ i ih =>
      change (P.decodeTerm i (P.rightTerm.unary z)).eval I env = _
      rw [ih, Term.eval_unary]
      rfl

def packingSubstitution (P : Pairing I) (k : Nat) : Fin (k + 1) → Term Fn 2 :=
  splitFin (.var index0) (fun i => P.decodeTerm i.val (.var index1))

def packFormula (P : Pairing I) {k : Nat} (A : Formula Fn (k + 1)) :
    Formula Fn 2 := A.subst (P.packingSubstitution k)

theorem eval_packFormula (P : Pairing I) {k : Nat}
    (A : Formula Fn (k + 1)) (x : D) (params : Fin k → D) :
    (P.packFormula A).eval I (env2 x (P.code k params)) ↔
      A.eval I (splitFin x params) := by
  apply Iff.trans (Formula.eval_subst I _ _ A)
  apply Formula.eval_congr
  intro i
  refine splitFin ?_ (fun j => ?_) i
  · rfl
  · change (P.decodeTerm j.val (.var index1)).eval I (env2 x (P.code k params)) =
        params j
    rw [P.eval_decodeTerm]
    exact P.decode_code k params j

end Pairing

def OneParameterInduction {Fn : Type u} {D : Type v}
    (I : Interpretation Fn D) : Prop :=
  ∀ (A : Formula Fn 2) (a : D),
    A.eval I (env2 I.zero a) →
    (∀ x, A.eval I (env2 x a) → A.eval I (env2 (I.succ x) a)) →
    ∀ x, A.eval I (env2 x a)

def AllParameterInduction {Fn : Type u} {D : Type v}
    (I : Interpretation Fn D) : Prop :=
  ∀ (k : Nat) (A : Formula Fn (k + 1)) (params : Fin k → D),
    A.eval I (splitFin I.zero params) →
    (∀ x, A.eval I (splitFin x params) → A.eval I (splitFin (I.succ x) params)) →
    ∀ x, A.eval I (splitFin x params)

theorem all_induction_from_one {Fn : Type u} {D : Type v}
    {I : Interpretation Fn D} (P : Pairing I)
    (one : OneParameterInduction I) : AllParameterInduction I := by
  intro k A params base step x
  apply (P.eval_packFormula A x params).mp
  apply one (P.packFormula A) (P.code k params)
  · exact (P.eval_packFormula A I.zero params).mpr base
  · intro n hn
    exact (P.eval_packFormula A (I.succ n) params).mpr
      (step n ((P.eval_packFormula A n params).mp hn))

#print axioms all_induction_from_one
#print axioms Pairing.eval_packFormula
#print axioms Pairing.decode_code

end ParameterPacking
