# Four partial results on Frankl’s union-closed sets conjecture

Open **collection.pdf** for all four papers, with a linked opening page. The four directories also contain the standalone PDFs with their reference links and the complete LaTeX sources. The unrestricted conjecture remains open.

| Paper | Main statement |
| --- | --- |
| incidences/sparse_refined.pdf | A generator incidence graph of maximum average degree strictly below 27/11 guarantees Frankl’s half threshold. |
| matrices/digraph.pdf | Abundant vertices meet every directed cycle if each vertex’s nonneighbors induce an acyclic graph. Every alternating square in a binary matrix has an abundant row or column under the submatrix sampling rule in the paper. |
| symmetry/symmetry.pdf | A leaf-starting induced four-vertex path in an incidence graph with side-exchanging symmetry forces a sharp frequency of at least 3/5. More general endpoint degrees yield explicit bounds. |
| flats/flats.pdf | Sharp coefficientwise circuit surplus, an extremal classification, and a Bell-number bound for a prescribed edge at a simplicial vertex. Exact finite certificates cover every degree from 1 through 35, with no restriction on the total graph size. The all-degree extremum equals a graph-coloring extremum under an explicit change of variables. |

## Proof status and sources

The proofs use distinct unions with uniform counting. The first three papers and the circuit, classification, equivalence, and all-degree analytic results in the fourth have mathematical proofs independent of the programs. The result for degrees up to 35 also uses the supplied integer-flow certificates. Their verifier reconstructs the integer partitions, Bell numbers, labelled multiplicities and balances without running the flow generator. Each PDF states which bounds are sharp and gives its own prior-work comparison.

The ProveIt comparison used the twelve draft archives listed at the repository revision below. The symmetry paper extends the translate-fiber argument in union_closed_abundance.zip. The directed-cycle paper extends the signed rule identity in union_closed_frequency_bounds.zip. Literature and repository searches support provisional novelty of the stated refinements. They do not establish publication priority.

https://github.com/VladimirReshetnikov/ProveIt/tree/a2662c5411fa892dbfe98e8189f66e5d6af4d84c/docs/drafts

## Reproducing the checks

Run the following from the archive root with Python 3.10 or later, using normal mode. Every script uses only the standard library. The adjacent text files contain the recorded results. For the certificate the recorded table gives the generating run; the verify command prints one independent confirmation per degree.

```sh
python3 incidences/check_sparse_refined.py
python3 matrices/verify_digraph.py
python3 symmetry/check_symmetry.py
python3 flats/check_flats.py
python3 flats/check_partitions.py
python3 flats/check_bell_flow.py --verify flats/bell_flow_certificate.jsonl.gz
```

To regenerate the flow certificate separately, run `python3 flats/check_bell_flow.py --write regenerated.jsonl.gz`. The gzip wrapper can have a different timestamp from the supplied file. The proof checks the mathematical content of each record.

## Rebuilding the PDFs

With a standard TeX Live distribution, run pdfLaTeX twice in each paper’s own directory on its .tex file. Then run pdfLaTeX twice on collection.tex in the root directory. The collection imports the four standalone PDFs. The individual papers’ visible page numbers start at one; the opening page of the collection refers to the combined PDF page numbers.
