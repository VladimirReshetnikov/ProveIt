#!/usr/bin/env python3
"""Exact finite checks for Directed cycles and abundant elements. Python 3.10+."""
from itertools import combinations, product


def vertices(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def digraph(n, arcs):
    out = [0] * n
    inc = [0] * n
    for i, j in arcs:
        assert i != j and not (out[j] >> i & 1)
        out[i] |= 1 << j
        inc[j] |= 1 << i
    return out, inc


def inspect(graph):
    out, inc = graph
    n = len(out)
    full = (1 << n) - 1
    feasible = []
    cycles = []
    for s in range(full + 1):
        selected = tuple(vertices(s))
        if any(not (out[i] & s and inc[i] & s) for i in selected):
            continue
        feasible.append(s)
        if not s or any((out[i] & s).bit_count() != 1 or
                        (inc[i] & s).bit_count() != 1 for i in selected):
            continue
        reached = 0
        i = selected[0]
        while not (reached >> i & 1):
            reached |= 1 << i
            i = (out[i] & s).bit_length() - 1
        if reached == s:
            cycles.append(s)

    def antineighbors(s):
        block = s
        for i in vertices(s):
            block |= inc[i] | out[i]
        return full ^ block

    def extensions(s):
        return sum(t & ~s == 0 for t in feasible)

    freq = [sum(s >> i & 1 for s in feasible) for i in range(n)]
    scores = [-extensions(antineighbors(1 << i)) for i in range(n)]
    local = all(score == -1 for score in scores)
    for cycle in cycles:
        credit = extensions(antineighbors(cycle))
        for i in vertices(cycle):
            scores[i] += credit
    for s in feasible:
        difference = sum(2 * freq[i] - len(feasible) for i in vertices(s))
        assert difference >= sum(scores[i] for i in vertices(s))
    if local:
        assert all(any(2 * freq[i] >= len(feasible) for i in vertices(c))
                   for c in cycles)
    return feasible, cycles, freq, scores


def all_oriented_graphs(n):
    edges = list(combinations(range(n), 2))
    for choices in product(range(3), repeat=len(edges)):
        arcs = [edge if orientation == 1 else edge[::-1]
                for edge, orientation in zip(edges, choices) if orientation]
        yield digraph(n, arcs)


def main():
    for n in range(1, 6):
        count = 0
        nontrivial = 0
        local_tests = 0
        for graph in all_oriented_graphs(n):
            family, cycles, _, _ = inspect(graph)
            count += 1
            nontrivial += bool(cycles)
            local_tests += len(family) - 1
        print(f"n={n} graphs={count} graphs_with_cycle={nontrivial} "
              f"nonempty_member_inequalities={local_tests}")
    # Four consecutive blocks are {0}, {1,4}, {2}, {3}.
    family, cycles, freq, scores = inspect(digraph(
        5, [(0, 1), (0, 4), (1, 2), (4, 2), (2, 3), (3, 0)]))
    print(f"K(2,3): members={len(family)} induced_cycles={len(cycles)} "
          f"counts={freq} lower_bound_terms={scores}")
    assert (len(family), len(cycles), freq, scores) == (
        4, 2, [3, 2, 3, 3, 2], [1, 0, 1, 1, 0])
    fano = digraph(14, [(i, j+7) if (j-i) % 7 in (1, 2, 4) else (j+7, i)
                         for i in range(7) for j in range(7)])
    family, cycles, freq, scores = inspect(fano)
    assert (len(family), len(cycles), freq, scores) == (
        5777, 84, [3421]*14, [23]*14)
    print("Fano incidence orientation: members=5777 induced_cycles=84 "
          "each_count=3421 each_lower_bound_term=23")
    # Anticomplete cycles test the extension factor, which can exceed one.
    for lengths in [(3, 3), (4, 5), (3, 3, 3)]:
        arcs = []
        start = 0
        for k in lengths:
            arcs.extend((start + j, start + (j + 1) % k) for j in range(k))
            start += k
        family, _, freq, scores = inspect(digraph(start, arcs))
        assert len(family) == 2 ** len(lengths)
        assert all(2 * f == len(family) for f in freq) and not any(scores)
        print(f"disjoint cycles {lengths}: equality for every member")
    print("PASS")


if __name__ == "__main__":
    main()
