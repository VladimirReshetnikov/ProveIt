#!/usr/bin/env python3
"""Integer cross-checks of the sparse-incidence theorem. Python 3.10+."""
from collections import Counter
from functools import reduce
from operator import or_


def union_all(items):
    return reduce(or_, items, 0)


def irreducibles(supports):
    return [s for s in supports
            if union_all(t for t in supports if t != s and t & s == t) != s]


def family(m, supports):
    # Point order is the given support order, including under projection.
    return {sum(1 << j for j, s in enumerate(supports) if s & selected)
            for selected in range(1 << m)}


def below_threshold(m, supports, numerator=27, denominator=11):
    # For fixed generator vertices, each point independently contributes
    # max(0, 2*q*chosen_degree-p) to max(2*q*edges-p*vertices).
    return all(sum(max(0, 2 * denominator * (s & selected).bit_count() - numerator)
                   for s in supports) < numerator * selected.bit_count()
               for selected in range(1, 1 << m))


def proof_check(m, supports, stats):
    kept = irreducibles(supports)
    primal = family(m, kept)
    assert len(primal) == len(family(m, supports))
    dual = {0}
    for s in kept:
        dual |= {x | s for x in dual}
    assert len(primal) == len(dual)
    counts = [sum(bool(u & (1 << j)) for u in primal)
              for j in range(len(kept))]
    for s, f in zip(kept, counts):
        assert f + sum(t & s == s for t in dual) == len(primal)
    if below_threshold(m, supports):
        stats['original graph passes density hypothesis'] += 1
        assert 2 * max(counts) >= len(primal)
    shared = [s for s in kept if s.bit_count() >= 2]
    per_gen = [[s for s in shared if s & (1 << i)] for i in range(m)]
    light = next((ss for ss in per_gen if len(ss) <= 2), None)
    if light is not None:
        stats['light-generator branch'] += 1
        if light:
            assert 2 * sum(counts[kept.index(s)] for s in light) >= len(light) * len(primal)
        return
    pair = [s for s in shared if s.bit_count() == 2]
    d = [sum(bool(s & (1 << i)) for s in pair) for i in range(m)]
    dirty = {i for i in range(m) if len(per_gen[i]) != 3 or d[i] != 3}
    low = sum(1 << i for i in range(m) if d[i] <= 2)
    bad = union_all([1 << i for i in dirty] + [s for s in pair if s & low])
    cert = [s for s in pair if not s & bad]
    deficits = [sum(max(0, 3 - d[j]) for j in range(m)
                    if j != i and ((1 << j) | (1 << i)) in pair)
                for i in range(m)]
    refined = [s for s in pair if all(i not in dirty for i in range(m) if s & (1 << i))
               and sum(deficits[i] for i in range(m) if s & (1 << i)) <= 1]
    assert set(cert) <= set(refined)
    e = sum(map(int.bit_count, shared))
    a, b = e - 3 * m, e - 2 * len(shared)
    if not cert:
        assert 3 * m <= 7 * a + 39 * b
        assert 32 * e >= 39 * (m + len(shared))
    if refined:
        stats['classical Knill edge' if cert else 'refined Knill edge only'] += 1
        for s in refined:
            assert 2 * counts[kept.index(s)] >= len(primal)
        return
    stats['refined density obstruction'] += 1
    assert 3 * m <= 7 * a + 27 * b
    assert 22 * e >= 27 * (m + len(shared))
    assert not below_threshold(m, supports)


def ladder_score(q, p):
    """Maximum of q*edges-p*vertices over induced subgraphs of the ladder
    example, including the empty subgraph. For 1<p/q<2 private leaves
    never increase this integer objective. Column bit 0 is the upper rail.
    """
    assert q < p < 2 * q
    pair_gain = 2 * q - p
    marks = {0, 4, 10}
    best = None
    for first in range(4):
        initial = -p * first.bit_count() + pair_gain * (first == 3)
        dp = {(first, first & 1): initial}
        for col in range(1, 14):
            nxt = {}
            for (prev, t), val in dp.items():
                for cur in range(4):
                    next_t = t + ((cur & 1) if col in marks else 0)
                    gain = pair_gain * ((prev & cur).bit_count() + (cur == 3))
                    value = val + gain - p * cur.bit_count()
                    key = cur, next_t
                    nxt[key] = max(nxt.get(key, value), value)
            dp = nxt
        for (last, t), val in dp.items():
            value = val + pair_gain * (last & first).bit_count() + max(0, q * t - p)
            best = value if best is None else max(best, value)
    return best


def run():
    stats = Counter()
    for m in range(1, 5):
        n = (1 << m) - 1
        for subset in range(1, 1 << n):
            supports = [i + 1 for i in range(n) if subset & (1 << i)]
            if union_all(supports) == n:
                proof_check(m, supports, stats)
                stats['systems with nonempty generator vertices'] += 1
    for key, count in sorted(stats.items()):
        print(f'{key}: {count}')
    # A small explicit local pattern: two endpoints, four exclusive
    # neighbors and one shortfall. A large support at index 6 may couple
    # exterior bits arbitrarily without meeting the pair (0,1).
    local_pairs = [(0, 1), (0, 2), (0, 3), (1, 4), (1, 5),
                   (2, 6), (2, 7), (3, 7), (3, 8), (4, 8), (4, 9), (5, 9)]
    pair_supports = [(1 << i) | (1 << j) for i, j in local_pairs]
    import random
    rng = random.Random(27511)
    for trial in range(96):
        exterior = sorted(rng.sample(range(4, 256), 5))
        supports = sorted(set(pair_supports + [x << 2 for x in exterior]))
        primal = family(10, supports)
        i = supports.index(3)
        assert 2 * sum(bool(u & (1 << i)) for u in primal) >= len(primal)
    print('96 ten-index exterior completions passed the one-shortfall frequency check')
    # Explicit maximum for the core: e/v=87/71. The whole core gives
    # equality and the dynamic program proves all subgraphs give <=0.
    assert ladder_score(71, 87) == 0
    assert 2 * 87 * 16 > 39 * 71 and 2 * 87 * 11 < 27 * 71
    print('circular ladder exact maximum average degree: 174/71')
    print('all assertions passed')


if __name__ == '__main__':
    run()
