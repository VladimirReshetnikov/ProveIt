#!/usr/bin/env python3
"""Exact checks of the pointed flat inequalities. Uses the standard library."""
from itertools import combinations
from math import comb


def subsets(mask):
    sub = mask
    while True:
        yield sub
        if sub == 0:
            return
        sub = (sub - 1) & mask


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit
        mask ^= bit


def basis_exchange(bases):
    bases = set(bases)
    return all(any((left ^ a ^ b) in bases for b in bits(right & ~left))
               for left in bases for right in bases for a in bits(left & ~right))


def rank_table(n, bases):
    return [max((s & b).bit_count() for b in bases) for s in range(1 << n)]


def flat_data(ground, ranks):
    return [s for s in subsets(ground)
            if all(ranks[s | x] > ranks[s] for x in bits(ground ^ s))]


def surplus(flats, e, ranks, r):
    coefficients = [0] * (r + 1)
    for flat in flats:
        if flat & e:
            coefficients[ranks[flat] - 1] -= 1
        else:
            coefficients[ranks[flat]] += 1
    return coefficients


def lifted_lower_bound(coefficients, extra_rank):
    lifted = [0] * (len(coefficients) + extra_rank)
    for j, coefficient in enumerate(coefficients):
        for k in range(extra_rank + 1):
            lifted[j + k] += coefficient * comb(extra_rank, k)
    return lifted


def check_matroid(n, ranks):
    ground = (1 << n) - 1
    r = ranks[ground]
    assert all(ranks[x | y] == 2 for x, y in combinations(bits(ground), 2))
    ground_flats = flat_data(ground, ranks)
    total = {e: surplus(ground_flats, e, ranks, r) for e in bits(ground)}
    circuits = [s for s in subsets(ground) if ranks[s] < s.bit_count()
                and all(ranks[s ^ x] == s.bit_count() - 1 for x in bits(s))]
    for e, coeff in total.items():
        assert min(coeff) >= 0
        pointed = [s for s in circuits if s & e]
        if not pointed:
            assert sum(coeff) == 0
            continue
        assert sum(coeff) >= r - 1
        for s in pointed:
            g = s.bit_count()
            lower = [0] * (g - 2) + [g - 2, 0]
            assert all(a >= b for a, b in zip(coeff, lifted_lower_bound(lower, r - g + 1)))
        if sum(coeff) == r - 1:
            spanning_circuit = circuits == [ground]
            triangle_with_coloop = r == 3 and n == 4 and len(circuits) == 1 and pointed[0].bit_count() == 3
            assert spanning_circuit or triangle_with_coloop
    lift_checks = 0
    for subset in subsets(ground):
        flats = flat_data(subset, ranks)
        for e in bits(subset):
            sub_coeff = surplus(flats, e, ranks, ranks[subset])
            lower = lifted_lower_bound(sub_coeff, r - ranks[subset])
            assert all(a >= b for a, b in zip(total[e], lower))
            lift_checks += 1
    return lift_checks



def all_small_matroids():
    count = checks = 0
    for n in range(1, 6):
        for rank in range(1, n + 1):
            candidates = [s for s in range(1 << n) if s.bit_count() == rank]
            for mask in range(1, 1 << len(candidates)):
                bases = [candidates[i] for i in range(len(candidates)) if mask & (1 << i)]
                if any(not any(b & s == s for b in bases) for s in range(1, 1 << n)
                       if s.bit_count() <= 2):
                    continue
                if basis_exchange(bases):
                    checks += check_matroid(n, rank_table(n, bases))
                    count += 1
    print(f'All labelled nonempty simple matroids on at most five points: {count}')
    print(f'Pointed restriction inequalities checked for these matroids: {checks}')


def vamos():
    pairs = [3 << i for i in (0, 2, 4, 6)]
    forbidden = {a | b for a, b in combinations(pairs, 2)} - {pairs[2] | pairs[3]}
    bases = [s for s in range(256) if s.bit_count() == 4 and s not in forbidden]
    assert basis_exchange(bases)
    ranks = rank_table(8, bases)
    print(f'Vamos matroid: {check_matroid(8, ranks)} pointed restrictions checked')
    print('Vamos surplus by rank at the first point:', surplus(flat_data(255, ranks), 1, ranks, 4))


def equality_examples():
    count = 0
    for g in range(3, 9):
        for r in range(g - 1, 9):
            n = r + 1
            circuit = (1 << g) - 1
            ranks = [s.bit_count() - int(s & circuit == circuit) for s in range(1 << n)]
            coeff = surplus(flat_data((1 << n) - 1, ranks), 1, ranks, r)
            expected = lifted_lower_bound([0] * (g - 2) + [g - 2, 0], r - g + 1)
            assert coeff == expected
            count += 1
    print(f'Coefficientwise equality for a circuit plus free points: {count} parameter choices')


if __name__ == '__main__':
    all_small_matroids()
    vamos()
    equality_examples()
