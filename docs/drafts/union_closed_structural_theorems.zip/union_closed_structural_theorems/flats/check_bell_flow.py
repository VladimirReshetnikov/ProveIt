"""Certify the sharp Bell lower bound for increasing clique trace weights.

At each degree an integer flow routes every negative type coefficient to
positive type coefficients by splitting blocks. All graph capacities, flows
and final conservation tests use exact Python integers.
"""
import argparse
import gzip
import json
from contextlib import nullcontext
from itertools import groupby
from collections import Counter, deque
from math import comb, factorial


def partition_types(n, largest=None):
    if not n:
        yield ()
        return
    cap = min(largest, n) if largest is not None else n
    for part in range(cap, 0, -1):
        for tail in partition_types(n - part, part):
            yield (part,) + tail


def multiplicity(shape, degree_factorial):
    divisor = 1
    for value, count in Counter(shape).items():
        divisor *= factorial(value) ** count * factorial(count)
    return degree_factorial // divisor


def refinements(shape):
    for size in set(shape):
        remainder = list(shape)
        remainder.remove(size)
        for first in range(1, size // 2 + 1):
            yield tuple(sorted(remainder + [first, size - first], reverse=True))


class Network:
    def __init__(self, n):
        self.adjacent = [[] for _ in range(n)]
        self.capacities = []
        self.ends = []

    def add(self, source, target, capacity):
        edge = len(self.capacities)
        self.capacities.extend((capacity, 0))
        self.ends.extend((target, source))
        self.adjacent[source].append(edge)
        self.adjacent[target].append(edge + 1)
        return edge

    def max_flow(self, source, target, limit):
        total = 0
        n = len(self.adjacent)
        while total < limit:
            level = [-1] * n
            level[source] = 0
            queue = deque([source])
            while queue:
                x = queue.popleft()
                if level[target] >= 0 and level[x] >= level[target]:
                    break
                for edge in self.adjacent[x]:
                    y = self.ends[edge]
                    if self.capacities[edge] and level[y] < 0:
                        level[y] = level[x] + 1
                        queue.append(y)
            if level[target] < 0:
                break
            cursor = [0] * n

            def augment(x, available):
                if x == target:
                    return available
                while cursor[x] < len(self.adjacent[x]):
                    edge = self.adjacent[x][cursor[x]]
                    y = self.ends[edge]
                    if self.capacities[edge] and level[y] == level[x] + 1:
                        amount = augment(y, min(available, self.capacities[edge]))
                        if amount:
                            self.capacities[edge] -= amount
                            self.capacities[edge ^ 1] += amount
                            return amount
                    cursor[x] += 1
                return 0

            while total < limit:
                amount = augment(source, limit - total)
                if not amount:
                    break
                total += amount
        return total


def certify(n, output=None):
    shapes = list(partition_types(n))
    index = {shape: i for i, shape in enumerate(shapes)}
    counts = [multiplicity(shape, factorial(n)) for shape in shapes]
    bell = sum(counts)
    next_bell = sum((len(shape) + 1) * count for shape, count in zip(shapes, counts))
    demand = [count * ((len(shape) + 1) * bell - next_bell)
              for shape, count in zip(shapes, counts)]
    assert sum(demand) == 0
    positive = sum(d for d in demand if d > 0)
    # Reserve one unit on a fixed bottom-to-top chain to certify strictness.
    residual_demand = demand.copy()
    chain = set()
    if n >= 2:
        path = [(size,) + (1,) * (n - size) for size in range(n, 0, -1)]
        chain = {(index[a], index[b]) for a, b in zip(path, path[1:])}
        residual_demand[index[path[0]]] += 1
        residual_demand[index[path[-1]]] -= 1
        assert demand[index[path[0]]] < 0 < demand[index[path[-1]]]
    residual_positive = sum(d for d in residual_demand if d > 0)
    source, target = len(shapes), len(shapes) + 1
    network = Network(target + 1)
    split_edges = []
    for x, shape in enumerate(shapes):
        for child in refinements(shape):
            y = index[child]
            edge = network.add(x, y, positive)
            split_edges.append((x, y, edge))
        if residual_demand[x] < 0:
            network.add(source, x, -residual_demand[x])
        elif residual_demand[x] > 0:
            network.add(x, target, residual_demand[x])
    flow = network.max_flow(source, target, residual_positive)
    assert flow == residual_positive, f'degree {n}: routed {flow} of {residual_positive}' 
    # Verify the certificate directly without using source or sink arcs.
    balance = [0] * len(shapes)
    active = 0
    certificate = []
    checked_chain = set()
    for x, y, edge in split_edges:
        amount = network.capacities[edge ^ 1]
        if (x, y) in chain:
            amount += 1
            checked_chain.add((x, y))
        assert 0 <= amount <= positive
        balance[x] -= amount
        balance[y] += amount
        active += bool(amount)
        if amount and output is not None:
            certificate.append([x, y, amount])
    assert checked_chain == chain and len(chain) == n - 1
    assert balance == demand, f'degree {n}: conservation failed'
    if output is not None:
        output.write(json.dumps([n, certificate], separators=(',', ':')) + "\n")
    return bell, next_bell, len(shapes), len(split_edges), active


def verify_archive(path, minimum, maximum):
    """Reconstruct types and coefficients without the max-flow construction."""
    bells = [1]
    for n in range(1, maximum + 2):
        bells.append(sum(comb(n - 1, j) * bells[j] for j in range(n)))
    # Independent type enumeration: extend partitions by adding one box.
    types = {()}
    expected = minimum
    with gzip.open(path, 'rt', encoding='ascii') as stream:
        for n in range(1, maximum + 1):
            new_types = set()
            for shape in types:
                new_types.add(shape + (1,))
                for i in range(len(shape)):
                    added = list(shape)
                    added[i] += 1
                    new_types.add(tuple(sorted(added, reverse=True)))
            types = new_types
            if n < minimum:
                continue
            degree, records = json.loads(next(stream))
            assert degree == n == expected
            expected += 1
            shapes = sorted(types, reverse=True)
            # Choose each labelled block from the remaining point set.
            masses = []
            for shape in shapes:
                choices, remaining = 1, n
                for size in shape:
                    choices *= comb(remaining, size)
                    remaining -= size
                divisor = 1
                for _, equal_parts in groupby(shape):
                    divisor *= factorial(sum(1 for _ in equal_parts))
                multiplicity, remainder = divmod(choices, divisor)
                assert remainder == 0
                masses.append(multiplicity)
            assert sum(masses) == bells[n]
            assert sum(m * (len(s) + 1) for m, s in zip(masses, shapes)) == bells[n + 1]
            expected_balance = [m * ((len(s) + 1) * bells[n] - bells[n + 1])
                                for m, s in zip(masses, shapes)]
            balance = [0] * len(shapes)
            positive_edges = set()
            for x, y, amount in records:
                assert type(x) is int and type(y) is int and type(amount) is int
                assert 0 <= x < len(shapes) and 0 <= y < len(shapes) and amount > 0
                assert (x, y) not in positive_edges
                positive_edges.add((x, y))
                coarse, finer = Counter(shapes[x]), Counter(shapes[y])
                removed = list((coarse - finer).elements())
                inserted = list((finer - coarse).elements())
                assert len(removed) == 1 and len(inserted) == 2 and sum(inserted) == removed[0]
                balance[x] -= amount
                balance[y] += amount
            assert balance == expected_balance
            index = {s: i for i, s in enumerate(shapes)}
            chain = [index[(size,) + (1,) * (n-size)] for size in range(n, 0, -1)]
            assert all(pair in positive_edges for pair in zip(chain, chain[1:]))
            print(f'd={n:2d}  certificate verified; types={len(shapes)}  '
                  f'positive arcs={len(records)}  strict chain={n-1}', flush=True)
        assert next(stream, None) is None


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--maximum', default=35, type=int)
    parser.add_argument('--minimum', default=1, type=int)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--write', metavar='GZIP_FILE', help='write positive flows')
    modes.add_argument('--verify', metavar='GZIP_FILE', help='independently check saved flows')
    args = parser.parse_args()
    if not 1 <= args.minimum <= args.maximum:
        parser.error('require 1 <= minimum <= maximum')
    if not __debug__:
        parser.error('run without -O so the checks are enabled')
    if args.verify:
        verify_archive(args.verify, args.minimum, args.maximum)
    else:
        dest = gzip.open(args.write, 'wt', compresslevel=6, encoding='ascii') if args.write else nullcontext()
        with dest as output:
            for degree in range(args.minimum, args.maximum + 1):
                b, new_b, types, edges, active = certify(degree, output)
                print(f'd={degree:2d}  B_d={b}  B_(d+1)={new_b}  '
                      f'types={types}  splits={edges}  used={active}  strict_chain={degree-1}  verified',
                      flush=True)
