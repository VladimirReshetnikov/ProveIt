"""Check the clique moment and simplicial-vertex formulas on all graphs through order five."""
from collections import Counter
from fractions import Fraction
from itertools import combinations


def set_partitions(mask):
    """Partitions into nonempty bit masks, in order of least element."""
    if not mask:
        yield ()
        return
    first = mask & -mask
    remaining = mask ^ first
    part = remaining
    while True:
        for rest in set_partitions(remaining ^ part):
            yield (first | part,) + rest
        if not part:
            break
        part = (part - 1) & remaining


def connected(mask, neighbors):
    reached = frontier = mask & -mask
    while frontier:
        vertex = frontier & -frontier
        frontier ^= vertex
        new = neighbors[vertex.bit_length() - 1] & mask & ~reached
        reached |= new
        frontier |= new
    return reached == mask


def check_size(n):
    full = (1 << n) - 1
    edges = list(combinations(range(n), 2))
    partitions = {mask: list(set_partitions(mask)) for mask in range(full + 1)}
    counts = Counter()
    for graph in range(1 << len(edges)):
        neighbors = [0] * n
        for bit, (x, y) in enumerate(edges):
            if graph >> bit & 1:
                neighbors[x] |= 1 << y
                neighbors[y] |= 1 << x
        if not connected(full, neighbors):
            continue
        counts['graphs'] += 1
        connected_parts = {mask for mask in range(1, full + 1) if connected(mask, neighbors)}
        cliques = {
            mask for mask in range(1, full + 1)
            if all(not (mask >> i & 1) or not (mask & ~(neighbors[i] | (1 << i)))
                   for i in range(n))
        }
        whole = [p for p in partitions[full] if all(b in connected_parts for b in p)]
        for clique in cliques:
            traces = Counter(
                tuple(sorted(block & clique for block in p if block & clique)) for p in whole
            )
            lhs = sum(mult * sum((1 << (b.bit_count() - 1)) - 1 for b in tr)
                      for tr, mult in traces.items())
            rhs = sum(mult * (len(tr) * (len(tr) - 1) // 2) for tr, mult in traces.items())
            assert lhs <= rhs
            for tr, weight in traces.items():
                for i, j in combinations(range(len(tr)), 2):
                    coarse = [b for ix, b in enumerate(tr) if ix not in (i, j)]
                    coarse.append(tr[i] | tr[j])
                    assert traces[tuple(sorted(coarse))] <= weight
                    counts['trace_splits'] += 1
            total_k = sum(len(tr) * weight for tr, weight in traces.items())
            assert 2 ** (clique.bit_count() * len(whole)) <= (clique.bit_count() + 1) ** total_k
            counts['cliques'] += 1
        for v, clique in enumerate(neighbors):
            if clique not in cliques:
                continue
            old = [p for p in partitions[full ^ (1 << v)] if all(b in connected_parts for b in p)]
            total_k = sum(sum(bool(b & clique) for b in p) for p in old)
            assert len(whole) == len(old) + total_k
            separation = Fraction(total_k, len(whole))
            for u in range(n):
                if not (clique >> u & 1):
                    continue
                separated = sum(not any((b >> u & 1) and (b >> v & 1) for b in p) for p in whole)
                assert separated == total_k
                counts['incident_edges'] += 1
            if clique.bit_count() in (2, 3):
                bound = {2: Fraction(3, 5), 3: Fraction(2, 3)}[clique.bit_count()]
                assert separation >= bound
                if len(edges) == graph.bit_count():
                    assert separation == bound
            counts['simplicial_vertices'] += 1
    return counts


if __name__ == '__main__':
    total = Counter()
    for size in range(1, 6):
        result = check_size(size)
        print(f'n={size}: ' + ', '.join(f'{k}={v}' for k, v in sorted(result.items())))
        total += result
    print('Total: ' + ', '.join(f'{k}={v}' for k, v in sorted(total.items())))
