"""Exact checks for the local abundance-gap theorem. Run with Python 3.10+."""
from fractions import Fraction
from itertools import combinations


def exact_trace_hull(k):
    """Lower convex hull of (family size, total size), including the empty family."""
    n = 1 << k
    costs = {}
    for mask in range(1 << n):
        family = [x for x in range(n) if mask >> x & 1]
        if any(not (mask >> (x | y) & 1) for x, y in combinations(family, 2)):
            continue
        size = len(family)
        cost = sum(x.bit_count() for x in family)
        costs[size] = min(costs.get(size, cost), cost)
    hull = []
    for x, y in sorted(costs.items()):
        while len(hull) >= 2:
            (a, b), (c, d) = hull[-2:]
            if (d - b) * (x - c) < (y - d) * (c - a):
                break
            hull.pop()
        hull.append((x, y))
    return hull


def maximum_size(hull, budget):
    """Right endpoint of the hull sublevel set at the given budget."""
    if hull[-1][1] <= budget:
        return Fraction(hull[-1][0])
    for (a, b), (c, d) in zip(hull, hull[1:]):
        if b <= budget < d:
            return a + Fraction((budget - b) * (c - a), d - b)
    raise AssertionError("budget outside hull")


def unions(rows):
    family = {0}
    for row in rows:
        family |= {s | row for s in family}
    return family


def glued_blocks(r):
    """Closed neighborhoods of r copies of K(3,3) sharing vertex 0."""
    rows = [1 << i for i in range(5 * r + 1)]
    for j in range(r):
        left = [0, 5 * j + 1, 5 * j + 2]
        right = [5 * j + k for k in (3, 4, 5)]
        for x in left:
            for y in right:
                rows[x] |= 1 << y
                rows[y] |= 1 << x
    return rows


def verify_all_3_by_3(bounds):
    """Every labelled bipartite 3-by-3 graph and each oriented induced P4."""
    checked = 0
    for entry_bits in range(1 << 9):
        rows = [(entry_bits >> (3 * i)) & 7 for i in range(3)]
        for generators in (rows, [sum((rows[i] >> j & 1) << i for i in range(3))
                                  for j in range(3)]):
            family = unions(generators)
            n = len(family)
            contained = [sum((s & row) == row for s in family) for row in generators]
            absent = [sum(not (s >> x & 1) for s in family) for x in range(3)]
            for a, first in enumerate(generators):
                for v, second in enumerate(generators):
                    for u in range(3):
                        if not (first & second & (1 << u)):
                            continue
                        for b in range(3):
                            if not (second & ~first & (1 << b)):
                                continue
                            local = [contained[a], contained[v], absent[b]]
                            local += [absent[x] for x in range(3) if first >> x & 1]
                            assert 1 - Fraction(min(local), n) >= bounds[first.bit_count()]
                            checked += 1
    return checked


if __name__ == "__main__":
    bounds = {}
    for k in range(5):
        hull = exact_trace_hull(k)
        rho = maximum_size(hull, k)
        bound = Fraction(rho + 2, 2 * rho + 3)
        bounds[k + 1] = bound
        print(f"endpoint degree {k+1}: hull {hull}, rho={rho}, abundance >= {bound}")
    print("Labelled, oriented induced paths verified on 3-by-3 graphs:",
          verify_all_3_by_3(bounds))
    path_six = unions([0b001, 0b011, 0b110])
    assert len(path_six) == 5
    path_max = max(Fraction(sum(s >> x & 1 for s in path_six), 5) for x in range(3))
    assert path_max == bounds[1]
    print(f"Six-vertex path: size=5, largest abundance={path_max} (sharp for degree 1)")
    for r in (2, 3, 4):
        rows = glued_blocks(r)
        assert all(x == y or (x & y) != x for x in rows for y in rows)
        family = unions(rows)
        counts = [sum(s >> i & 1 for s in family) for i in range(len(rows))]
        frequencies = sorted({Fraction(c, len(family)) for c in counts})
        assert max(frequencies) >= bounds[4]
        print(f"{r} glued blocks: points={len(rows)}, family={len(family)}, "
              f"frequencies={', '.join(map(str, frequencies))}")
