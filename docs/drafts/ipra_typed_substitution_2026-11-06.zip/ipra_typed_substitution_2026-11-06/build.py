"""Compile the LaTeX report; keep temporary TeX files under build/."""

import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    work = ROOT / "build"
    work.mkdir(exist_ok=True)
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("Install a TeX distribution providing pdflatex.")
    lookup = subprocess.run(["kpsewhich", "pdflatex.fmt"],
                            text=True, capture_output=True)
    options = []
    if lookup.returncode or not lookup.stdout.strip():
        # Minimal TeX installations sometimes provide sources but no format.
        local_format = work / "pdflatex.fmt"
        if not local_format.exists():
            run = subprocess.run(
                ["pdftex", "-ini", "-etex", "-jobname=pdflatex",
                 "-progname=pdflatex", "pdflatex.ini"],
                cwd=work, text=True, capture_output=True)
            (work / "format_stdout.txt").write_text(run.stdout + run.stderr)
            if run.returncode:
                raise SystemExit(run.stdout[-6000:] + run.stderr)
        options = ["-fmt=" + str(local_format)]
    for _ in range(3):
        run = subprocess.run(
            [engine, *options, "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "-output-directory=build", "report.tex"],
            cwd=ROOT, text=True, capture_output=True)
        (work / "stdout.txt").write_text(run.stdout + run.stderr)
        if run.returncode:
            raise SystemExit(run.stdout[-6000:] + run.stderr)
    shutil.copyfile(work / "report.pdf", ROOT / "report.pdf")
    log = (work / "report.log").read_text()
    diagnostics = [line for line in log.splitlines()
                   if any(x in line for x in ("Overfull", "undefined", "Warning:"))]
    result = dict(success=True, passes=3, diagnostics=diagnostics)
    (ROOT / "validation/latex_results.json").write_text(
        json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
