CURRENT COMPARISON CORPUS
=========================

Repository: VladimirReshetnikov/ProveIt
Directory: docs/drafts
Pinned commit: 9e338a5c51a26ac6ae90f2d8f563a44c3879ba68

The six source archives are prefix_kernel, reduced_checker, reduced_kernel,
single_traversal, unary_existential, and uniform_kernel, dated 2026-11-06.
Exact filenames, pinned Git blob SHA-1 identities, archive SHA-256 hashes,
source archive members and source SHA-256 hashes are recorded in index.json.
Every archive was checked against its pinned Git blob identity before its
source files were admitted to this comparison.

Scope of the census
-------------------
336 Python source occurrences were present in the six archives. They contain
165 distinct byte-for-byte source files. The inventory identifies:

* 16 complete directly offered current programs: six principal checkers and
  ten explicit controls/alternative programs.
* 92 distinct standalone checker sources in total, including those 16 and
  76 inherited standalone programs embedded in the archives.
* 74 distinct inherited dependency/source groups, deduplicated from 230
  supplied group records. These overlap the standalone set; they are not
  74 additional disjoint algorithms.

Standalone sources have an actual __main__ entrypoint, proof-checking
definitions, and no imports except json/sys. Every matching source was
included; no smaller matching source was excluded as an inferior proposal.
Current controls are counted even where their source presentation differs
from the principal program. Both canonical-only and public-falsity interfaces
are admitted to the comparison, which favors the existing frontier.

The frozen sources/ directory contains 128 source files: all 92 standalone
programs and 36 other components needed to remeasure the historical groups.
Every listed dependency group is measured by summing all its listed files.
No custom imported module is silently treated as part of Python's runtime.
For example, an inherited 608-token checker imports a 1,227-token shared
module; its group totals 1,835 normalized tokens. The inherited 618-token
Hilbert component is part of a 1,685-token package including syntax,
arithmetic and its JSON driver. Neither isolated component is a complete
checker.

Historical API-only groups are also recorded and favorably counted without
adding a missing command-line interface. Even these smaller boundaries do
not change any of the five expanded minima. The supplied group boundaries
are preserved in index.json and validation/metrics.json; no claim is made
that every historical program has been independently certified sound.

The other 37 unique Python sources are proof generators, translators,
measurements, builders, tests or audit utilities. They are not acceptance
programs and occur in no supplied trusted dependency group. Their exact
origins, imports, definitions and exclusion reason are retained in index.json.

Reproduction and measurement
----------------------------
Run `python3 measure.py` from the parent directory. It does not import or run
the candidate or any comparison checker. It verifies all 128 source hashes,
parses their syntax trees, remeasures the standalone programs and all group
components, and writes validation/metrics.json, comparison_table.tex and
metrics_macros.tex. It also measures the exact current checker.py and, when
present, checker_core.py and controls/*.py.

Five metrics are recorded:

* Raw UTF-8 bytes, including comments and documentation.
* Significant source tokens, excluding comments, layout and genuine initial
  module/function/class docstrings.
* Normalized tokens after removing those docstrings and applying ast.unparse.
* Executable AST nodes, including operator and context nodes.
* UTF-8 bytes of that normalized program plus one final newline.

Imports, syntax validation, substitution, all axioms and inference handlers,
falsity conversion where implemented, and the JSON/CLI interface are counted.
Python and its standard library form the same external runtime boundary for
all compared programs. Exact AST-unparse results are tied to the Python
version recorded by measure.py.

The expanded minima are 863 source tokens, 864 normalized tokens, 915 AST
nodes, 2,730 normalized bytes and 3,088 raw bytes. The unary-existential
principal program attains the source-token and byte minima; the uniform
principal program attains the normalized-token and AST minima. Enlarging the
comparison from the six principal programs to every listed control,
standalone source and inherited group does not lower these thresholds.

This is a finite, reproducible implementation comparison. It is not an
absolute lower bound on every possible correct proof checker, or a claim
that every source in this historical corpus is a sound iPRA presentation.
