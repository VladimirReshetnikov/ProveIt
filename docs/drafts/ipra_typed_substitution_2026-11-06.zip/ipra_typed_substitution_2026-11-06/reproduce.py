"""Remeasure, validate, and optionally rebuild the report."""

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-pdf", action="store_true",
                        help="run the Python checks without requiring TeX")
    args = parser.parse_args()
    scripts = ["measure.py", "validation/validate.py"]
    if not args.no_pdf:
        scripts.append("build.py")
    for script in scripts:
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
