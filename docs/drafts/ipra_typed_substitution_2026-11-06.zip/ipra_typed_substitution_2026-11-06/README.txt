A SMALLER CHECKED PRESENTATION OF iPRA
====================================
Unary existence and typed prefix substitution
Prepared for Vladimir Reshetnikov, 6 November 2026

RESULT
------
The public checker is a complete standalone implementation of the calculus
specified in report.tex/report.pdf. It has 840 significant and normalized
Python tokens, 880 executable AST nodes, and 2,632 normalized UTF-8 bytes.
The inspected current corpus has coordinate minima 863 source tokens,
864 normalized tokens, 915 AST nodes, and 2,730 normalized bytes.

The optional canonical-input checker has 796 tokens, 839 AST nodes,
and 2,547 normalized bytes. It expects 0=S0 already written in place
of surface falsity. The main result uses the public interface and counts
its falsity converter.

The mathematical basis is inherited from the current unary-existential
proposal. The new implementation combines unary existence, finite-prefix
substitution, and a single typed traversal for formation, substitution,
shifting and public-falsity conversion. The report states every logical
rule and arithmetic schema, proves full quantifier-free induction, and
gives whole-domain bi-interpretations and equiconsistency with explicit
first-order iPRA. No absolute shortest-checker claim is made.

FILES
-----
report.tex, report.pdf       Complete mathematical report and checker listing.
checker.py                  Primary standalone public-input checker.
checker_core.py             Optional canonical-input checker.
measure.py                  Hash-verified measurement, no comparator execution.
build.py                    PDF compilation with three LaTeX passes.
reproduce.py                Measurement, validation, and optional PDF rebuild.
comparison/index.json       Exact sources, hashes, corpus inventory, exclusions.
comparison/sources/         128 frozen source files for full remeasurement.
comparison/README.txt       Detailed comparison boundary and methodology.
validation/validate.py      Reproducible acceptance and binding tests.
validation/fixtures/        176 inherited, hash-checked certificate fixtures.
validation/results.json    All validation outcomes and interface distinctions.
validation/metrics.json    Current complete-checker measurements.
validation/SOURCES.json    Validation-source provenance.
validation/named_oracle.py  Independent named-variable substitution oracle.
SHA256SUMS.txt              Hashes of the delivered files except this manifest.

REPRODUCE
---------
Python 3.10 or newer suffices for the checkers and tests; no third-party
Python package or network connection is needed. Exact stored normalization
counts were produced with Python 3.12.14. ast.unparse formatting can vary
between Python releases.

From this directory:

    python3 reproduce.py --no-pdf

This remeasures the complete comparison corpus, replays the certificate
fixtures, tests binding against an independent named-variable oracle,
and invokes both command-line checkers under Python and Python -O.

To rebuild the PDF as well, install a TeX distribution providing pdflatex,
the standard AMS packages, Latin Modern, microtype, geometry, hyperref,
listings, enumitem, booktabs, and fancyhdr, then run:

    python3 reproduce.py

The build script can create a local pdflatex format when the installed TeX
sources are present but the system format is missing. Temporary build files
are kept in build/. The delivered archive omits them.

INDIVIDUAL CERTIFICATES
----------------------
    python3 checker.py validation/fixtures/induction_zero_plus_n.json

The exact available fixture filenames are listed in
validation/fixture_manifest.json. ACCEPT exits zero; REJECT exits nonzero.
The certificate is [context, conclusion, proof] in finite JSON. The report
gives the complete syntax and all six proof-record forms. Public falsity
uses ["false"]; canonical falsity is ["=", -1, ["s", -1]].

EVIDENCE
--------
Both candidate checkers passed 7,500 substitution comparisons each against
the independent named-variable oracle; 176 inherited and 20 focused
certificate checks each; 12 public-falsity substitution comparisons;
and 800 ordinary/optimized command-line invocations with zero unexpected
outcomes. The public checker intentionally rejects one inherited malformed
Boolean hypothesis key that the old implementation harmlessly accepted.
The canonical checker rejects one raw surface-falsity certificate, and
agrees with all 176 reference outcomes after explicit falsity translation.
These differences are documented rather than counted as unexplained passes.

The general theorems are mathematical proofs, not a Lean/Rocq formalization.
Finite tests do not prove consistency or full implementation correctness.

PINNED SOURCES AND ATTRIBUTION
-----------------------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 9e338a5c51a26ac6ae90f2d8f563a44c3879ba68
Directory: docs/drafts

All six source archives were verified against their Git blob hashes.
The primary comparison covers the current prefix, reduced-checker,
reduced-kernel, single-traversal, unary-existential, and uniform proposals.
The enlarged inventory includes 16 directly offered current variants,
92 distinct standalone programs in total, and 74 inherited source groups
(overlapping the standalone set). All specified dependencies are charged.

The arithmetic and logical equivalence arguments, including the formula
amalgamation construction, originate in the supplied draft line; they are
restated with attribution in the self-contained report. Reference sources
and inherited fixtures are preserved byte-for-byte. New checker changes,
the integrated comparison, and focused validation are identified explicitly.
