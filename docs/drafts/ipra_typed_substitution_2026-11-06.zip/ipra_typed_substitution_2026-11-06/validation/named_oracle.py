"""Independent named-variable substitution oracle.

Adapted from the current ProveIt unary-existential draft; see SOURCES.json.
No checker code or depth-based substitution operation is called here.
"""

def bind_count(tag, child):
    if tag == "r" and child == 2:
        return 2
    return 1 if tag in ("pi", "ex") else 0


def decode(tree, bound=()):
    if type(tree) is int:
        if tree == -1:
            return ("zero",)
        return ("var", bound[tree] if tree < len(bound) else tree - len(bound))
    tag, *children = tree
    slots = tuple(object() for _ in range(2 if tag == "r" else
                                        1 if tag in ("pi", "ex") else 0))
    return (tag, slots, tuple(
        decode(child, slots[:bind_count(tag, i)] + bound)
        for i, child in enumerate(children)))


def encode(tree, bound=()):
    if tree[0] == "zero":
        return -1
    if tree[0] == "var":
        symbol = tree[1]
        return symbol + len(bound) if type(symbol) is int else bound.index(symbol)
    tag, slots, children = tree
    return [tag, *(encode(child, slots[:bind_count(tag, i)] + bound)
                   for i, child in enumerate(children))]


def replace_free(tree, prefix, offset):
    if tree[0] == "zero":
        return tree
    if tree[0] == "var":
        symbol = tree[1]
        if type(symbol) is not int:
            return tree
        return decode(prefix[symbol]) if symbol < len(prefix) else ("var", symbol + offset)
    tag, slots, children = tree
    return (tag, slots, tuple(replace_free(c, prefix, offset) for c in children))


def term(rng, depth, scope=0):
    if depth == 0 or rng.randrange(4) == 0:
        return rng.randrange(-1, scope + 6)
    if rng.randrange(2):
        return ["s", term(rng, depth - 1, scope)]
    return ["r", term(rng, depth - 1, scope), term(rng, depth - 1, scope),
            term(rng, depth - 1, scope + 2)]


def formula(rng, depth, scope=0):
    if depth == 0 or rng.randrange(3) == 0:
        return ["=", term(rng, 2, scope), term(rng, 2, scope)]
    if rng.randrange(2):
        return ["ex", formula(rng, depth - 1, scope + 1)]
    return ["pi", formula(rng, depth - 1, scope + 1),
            formula(rng, depth - 1, scope + 1)]


