REPRODUCIBLE VALIDATION
=======================

From the package root, run:

    python3 validation/validate.py

Python 3.10 or later is sufficient. No third-party package, repository
checkout, or network access is required. The script can also be invoked
by absolute path from another working directory. It writes results.json
beside itself. Use --output PATH to choose another result file, or
--skip-cli to omit subprocess runs while retaining all in-process tests.

What is checked
---------------

1. The 176 exact JSON fixtures inherited from the current unary-existential
   draft, with SHA-256 checks before they are used. These include derived
   conjunction/disjunction, dependent logical rules, recursion, equation
   induction, numerical cases, equality, and rejection tests for scope,
   witness, and malformed-syntax errors.

2. The same fixtures after the explicitly included, untrusted translation
   of public ["false"] syntax to ["=", -1, ["s", -1]]. This separates
   the mathematical certificate from a surface-language difference.

3. For each of the two candidate checkers, 7,500 simultaneous substitutions
   checked against an independent named-variable oracle. The oracle uses
   unique objects for bound names, replaces free named symbols, and then
   re-encodes; it does not call either checker's depth traversal.

4. Twenty focused certificates aimed at traversal fusion: malformed unused
   recursion bodies hidden in an intermediate equation; nonconstructor
   recursion counters; ignored witnesses with formula sort; and public
   falsity in hypotheses, introductions, eliminations, equality templates,
   and the numerical schema. Twelve additional comparisons check public
   falsity conversion under simultaneous substitution.

5. Both complete command-line programs on the inherited and focused cases,
   plus malformed JSON, under ordinary Python and Python -O. There are
   800 subprocess invocations in the full run.

Intentional interface differences
---------------------------------

The primary checker validates hypothesis keys. It rejects the inherited
stored_hypothesis_boolean_alias.json case: that key contains the JSON
Boolean false where the syntax requires a numerical variable index. The
reference checker safely accepts it because Python compares False equal
to 0 and returns the well-formed stored assumption. Replacing that key's
Boolean by the integer 0 gives the same mathematical proof. This is a
stricter input grammar, not a loss of a sequent or inference rule.

The canonical core omits the public falsity converter and therefore
rejects the raw public_falsity_conversion.json case. It accepts the
certificate after the explicit translation described above. The core
retains the reference's harmless hypothesis-key alias behavior.

Consequently the primary and canonical checkers each accept 115 and
reject 61 of the 176 raw inherited inputs, but their exceptional case is
different. The unchanged reference accepts 116 and rejects 60. After
explicit falsity translation, the canonical core agrees with all 176
reference outcomes. The primary still rejects the Boolean-key alias.

Scope of the evidence
---------------------

The checkers are standalone; none of the scripts or fixtures in this
directory belongs to their trusted implementation. The tests are finite
executable evidence and do not constitute a Lean/Rocq formalization of
the general soundness or bi-interpretability proofs.

Provenance
----------

SOURCES.json identifies the exact ProveIt commit and archive. The copied
reference checker and original JSON fixtures have unchanged contents.
named_oracle.py retains the independent named-syntax routines from that
archive with its checker-loading and original runner removed. The new
test runner states expectations explicitly and includes every new test
case in its source.
