"""Reproduce the finite verification evidence for both complete checkers.

Run with Python 3.10+ from any working directory:
    python3 validation/validate.py

All inputs and the independent named-variable oracle are included here.
No repository checkout, network access, or third-party package is needed.
The test runner and proof corpus are not trusted by either proof checker.
"""

from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import argparse
import ast
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import tokenize

import named_oracle as oracle


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)
TRIVIAL = ["=", -1, -1]
CLASH = ["=", -1, ["s", -1]]


def demand(condition, message):
    if not condition:
        raise AssertionError(message)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepts(module, data):
    try:
        return module.check(data) is True
    except ERRORS:
        return False


def canonicalize(data):
    """Untrusted, explicit translation of public falsity into its equation."""
    if data == ["false"]:
        return ["=", -1, ["s", -1]]
    return [canonicalize(item) for item in data] if type(data) is list else data


def metrics(path):
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    docstring_spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and type(node.body[0].value.value) is str):
                text = node.body.pop(0)
                docstring_spans.append(((text.lineno, text.col_offset),
                                        (text.end_lineno, text.end_col_offset)))
    excluded = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
                tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}

    def tokens(text, spans=()):
        return sum(t.type not in excluded and not any(a <= t.start and t.end <= b
                   for a, b in spans)
                   for t in tokenize.generate_tokens(io.StringIO(text).readline))

    normalized = ast.unparse(tree) + "\n"
    return {
        "source_tokens_without_comments_or_docstrings": tokens(source, docstring_spans),
        "normalized_tokens": tokens(normalized),
        "executable_ast_nodes": len(list(ast.walk(tree))),
        "normalized_utf8_bytes_including_final_newline": len(normalized.encode("utf-8")),
        "raw_utf8_bytes": len(source.encode("utf-8")),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def expected_raw(kind, record):
    name = record["file"]
    if kind == "primary" and name == "stored_hypothesis_boolean_alias.json":
        return False
    if kind == "canonical" and name == "public_falsity_conversion.json":
        return False
    return record["accepted_by_reference"]


def check_corpus(modules):
    manifest = json.loads((HERE / "fixture_manifest.json").read_text())
    categories = Counter()
    raw = {kind: Counter() for kind in modules}
    translated = {kind: Counter() for kind in modules}
    cases = []
    for record in manifest:
        path = HERE / "fixtures" / record["file"]
        content = path.read_bytes()
        demand(hashlib.sha256(content).hexdigest() == record["sha256"],
               "Changed inherited fixture: " + record["file"])
        data = json.loads(content)
        categories[record["category"]] += 1
        results = {}
        for kind, module in modules.items():
            actual = accepts(module, data)
            expected = expected_raw(kind, record)
            demand(actual == expected, (kind, record["file"], expected, actual))
            raw[kind]["accepted" if actual else "rejected"] += 1
            results[kind] = actual

            normalized = canonicalize(data)
            expected_normalized = record["accepted_by_reference"]
            if kind == "primary" and record["file"] == "stored_hypothesis_boolean_alias.json":
                expected_normalized = False
            actual_normalized = accepts(module, normalized)
            demand(actual_normalized == expected_normalized,
                   (kind, "canonicalized", record["file"], expected_normalized, actual_normalized))
            translated[kind]["accepted" if actual_normalized else "rejected"] += 1
        cases.append({"file": record["file"], "raw_results": results})
    return {
        "fixture_count": len(manifest),
        "raw": {kind: dict(count) for kind, count in raw.items()},
        "after_explicit_falsity_translation": {kind: dict(count) for kind, count in translated.items()},
        "categories": dict(sorted(categories.items())),
        "unexpected_differences": 0,
        "interface_differences": {
            "primary": "Rejects the Boolean hypothesis-key alias; keys are validated syntax.",
            "canonical": "Rejects raw public falsity syntax; explicit falsity translation is outside this core.",
        },
        "cases": cases,
    }, manifest


def check_substitutions(modules):
    rng = random.Random(20261106)
    counts = Counter()
    for i in range(1500):
        tree = oracle.formula(rng, 3) if i % 2 else oracle.term(rng, 3)
        named = oracle.decode(tree)
        demand(oracle.encode(named) == tree, "Named-syntax round trip")
        envs = [
            ("shift", [rng.randrange(5)]),
            ("instantiate", [oracle.term(rng, 2), -1]),
            ("recursion", [oracle.term(rng, 2), oracle.term(rng, 2), -2]),
            ("successor", [["s", 0], 0]),
            ("general", [*[oracle.term(rng, 2) for _ in range(3)], rng.randrange(-3, 4)]),
        ]
        for name, env in envs:
            expected = oracle.encode(oracle.replace_free(named, env[:-1], env[-1]))
            for kind in ("primary", "canonical"):
                actual = modules[kind].subst(tree, env)
                demand(actual == expected, ("substitution", kind, name, tree, env))
            counts[name] += 1
    return {
        "seed": 20261106,
        "trees": 1500,
        "named_round_trips": 1500,
        "substitutions_per_checker": sum(counts.values()),
        "checkers": ["primary", "canonical"],
        "total_comparisons": 2 * sum(counts.values()),
        "cases_per_checker": dict(counts),
        "oracle": "Decode to unique named bound symbols, replace free symbols, re-encode.",
        "mismatches": 0,
    }


def focused_cases():
    """Small tests aimed at the boundaries affected by traversal fusion."""
    cases = []

    def add(name, data, primary, canonical, risk):
        cases.append({"name": name, "data": data,
                      "expected": {"primary": primary, "canonical": canonical},
                      "risk": risk})

    # The malformed body is invisible in the advertised sequent. A zero
    # recursion would discard it, and equality transport uses a constant
    # template. Only validation of the intermediate recursor rejects it.
    invalid_bodies = [True, 0.0, -2, {"s": -1}, ["false"], ["=", -1, -1],
                      ["s"], ["s", -1, -1], ["r", -1, -1], ["ex", TRIVIAL]]
    for i, body in enumerate(invalid_bodies):
        proof = ["use", ["rec", ["r", -1, -1, body]], TRIVIAL, ["hyp", TRIVIAL]]
        add(f"unused_recursion_body_{i:02d}", [[TRIVIAL], TRIVIAL, proof], False, False,
            "Malformed unused intermediate arithmetic syntax")

    # One-step computation admits only literal zero or successor counters.
    for i, counter in enumerate([0, ["r", -1, -1, 0]]):
        proof = ["use", ["rec", ["r", counter, -1, 0]], TRIVIAL, ["hyp", TRIVIAL]]
        add(f"nonconstructor_recursion_counter_{i:02d}", [[TRIVIAL], TRIVIAL, proof],
            False, False, "No uncharged normalization of arithmetic terms")

    # Public falsity is a formula even when the matrix ignores its witness.
    pi_proof = ["pi", TRIVIAL, ["hyp", TRIVIAL]]
    add("public_false_not_ignored_pi_term",
        [[TRIVIAL], TRIVIAL, ["use", pi_proof, ["false"], ["hyp", TRIVIAL]]],
        False, False, "Ignored numerical witnesses must still have term sort")
    add("public_false_not_ignored_ex_term",
        [[TRIVIAL], ["ex", TRIVIAL], ["pack", ["false"], ["hyp", TRIVIAL]]],
        False, False, "Ignored numerical witnesses must still have term sort")

    add("public_false_hypothesis", [[["false"]], CLASH, ["hyp", ["false"]]],
        True, False, "Falsity normalization at hypothesis lookup")
    add("public_false_pi_annotation", [[], ["pi", CLASH, CLASH],
        ["pi", ["false"], ["hyp", ["false"]]]],
        True, False, "Falsity normalization before context extension")
    add("public_false_ex_elimination", [[["ex", ["false"]]], CLASH,
        ["use", ["hyp", ["ex", ["false"]]], ["false"], ["hyp", ["false"]]]],
        True, False, "Falsity normalization at an elimination target")
    add("public_false_equality_template", [[CLASH, TRIVIAL], CLASH,
        ["use", ["hyp", TRIVIAL], ["false"], ["hyp", CLASH]]],
        True, False, "Falsity normalization at a formula-template annotation")
    expected_n = ["pi", CLASH, ["pi", ["pi", CLASH, CLASH], CLASH]]
    add("public_false_numerical_schema", [[], expected_n, ["nat", ["false"]]],
        True, False, "Falsity normalization before the numerical schema")
    add("malformed_false_arity", [[["false", -1]], TRIVIAL, ["hyp", TRIVIAL]],
        False, False, "Conversion applies only to the exact public constructor")
    return cases


def check_focused(modules):
    cases = focused_cases()
    groups = Counter()
    for case in cases:
        groups[case["risk"]] += 1
        for kind in ("primary", "canonical"):
            expected = case["expected"][kind]
            actual = accepts(modules[kind], case["data"])
            demand(actual == expected, ("focused", kind, case["name"], expected, actual))
        # Every well-formed public positive example has the same canonical
        # mathematical sequent after the explicitly included translation.
        if case["expected"]["primary"]:
            demand(accepts(modules["canonical"], canonicalize(case["data"])),
                   ("canonical translation of focused positive", case["name"]))
    public_formulas = [
        ["false"],
        ["pi", ["false"], ["=", 0, 1]],
        ["ex", ["pi", ["=", 0, 2], ["false"]]],
        ["pi", ["ex", ["false"]], ["=", ["r", 0, 1, ["s", 2]], 2]],
    ]
    conversion_substitutions = 0
    for tree in public_formulas:
        for env in ([2], [-1, -1], [["s", 0], 0]):
            source = canonicalize(tree)
            expected = oracle.encode(oracle.replace_free(oracle.decode(source), env[:-1], env[-1]))
            demand(modules["primary"].subst(tree, env, True) == expected,
                   ("public conversion under substitution", tree, env))
            conversion_substitutions += 1
    return {
        "certificates": len(cases),
        "checks": 2 * len(cases),
        "public_positive_translations": sum(c["expected"]["primary"] for c in cases),
        "public_falsity_substitution_comparisons": conversion_substitutions,
        "groups": dict(groups),
        "mismatches": 0,
        "cases": [{k: v for k, v in c.items() if k != "data"} for c in cases],
    }, cases


def check_cli(paths, manifest, focused):
    jobs = []
    with tempfile.TemporaryDirectory(prefix="ipra-fused-validation-") as temp:
        temp = Path(temp)
        for kind in ("primary", "canonical"):
            checker = paths[kind]
            for record in manifest:
                fixture = HERE / "fixtures" / record["file"]
                expected = expected_raw(kind, record)
                for optimize in (False, True):
                    jobs.append((kind, checker, fixture, expected, optimize))
            for case in focused:
                fixture = temp / (case["name"] + ".json")
                fixture.write_text(json.dumps(case["data"]), encoding="utf-8")
                for optimize in (False, True):
                    jobs.append((kind, checker, fixture, case["expected"][kind], optimize))
            for i, invalid in enumerate(("{", "[", "", '[[],["=",-1,-1],]')):
                fixture = temp / f"malformed_json_{i}.txt"
                fixture.write_text(invalid, encoding="utf-8")
                for optimize in (False, True):
                    jobs.append((kind, checker, fixture, False, optimize))

        def run(job):
            kind, checker, fixture, expected, optimize = job
            command = [sys.executable, *(["-O"] if optimize else []), str(checker), str(fixture)]
            result = subprocess.run(command, capture_output=True, text=True, timeout=20)
            want = (0, "ACCEPT") if expected else (1, "REJECT")
            demand((result.returncode, result.stdout.strip()) == want,
                   ("CLI", kind, fixture.name, optimize, want,
                    result.returncode, result.stdout, result.stderr))
            return kind

        with ThreadPoolExecutor(max_workers=4) as pool:
            kinds = Counter(pool.map(run, jobs))
    return {"invocations": len(jobs), "per_checker": dict(kinds),
            "normal_and_optimized_python": True, "mismatches": 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-cli", action="store_true",
                        help="Skip subprocess checks; useful for quickly rerunning mathematical fixtures.")
    parser.add_argument("--output", type=Path, default=HERE / "results.json")
    args = parser.parse_args()
    paths = {"primary": ROOT / "checker.py", "canonical": ROOT / "checker_core.py",
             "reference": HERE / "reference_unary_checker.py"}
    modules = {kind: load_module("validation_" + kind, path) for kind, path in paths.items()}
    corpus, manifest = check_corpus(modules)
    substitutions = check_substitutions(modules)
    focused, focused_inputs = check_focused(modules)
    result = {
        "status": "passed",
        "python_version": platform.python_version(),
        "metrics": {kind: metrics(path) for kind, path in paths.items()},
        "inherited_corpus": corpus,
        "independent_substitution_audit": substitutions,
        "focused_validation": focused,
        "cli": {"skipped": True} if args.skip_cli else check_cli(paths, manifest, focused_inputs),
        "qualification": "Finite executable evidence. General soundness and bi-interpretability are mathematical proofs, not Lean/Rocq verification.",
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "metrics": result["metrics"],
        "raw_corpus_outcomes": corpus["raw"],
        "substitutions_per_checker": substitutions["substitutions_per_checker"],
        "focused_certificates": focused["certificates"],
        "cli": result["cli"],
    }, indent=2))


if __name__ == "__main__":
    main()
