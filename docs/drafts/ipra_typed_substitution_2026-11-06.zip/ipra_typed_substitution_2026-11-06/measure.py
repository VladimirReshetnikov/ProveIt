"""Measure complete acceptance programs without importing them."""

import ast
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent
AXES = ("raw_bytes", "normalized_bytes", "source_tokens",
        "normalized_tokens", "ast_nodes")


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    excluded = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
                tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in excluded
              and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    ntokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
               if t.type not in excluded]
    return dict(sha256=hashlib.sha256(data).hexdigest(),
                raw_bytes=len(data), normalized_bytes=len(normalized.encode()),
                source_tokens=len(tokens), normalized_tokens=len(ntokens),
                ast_nodes=sum(1 for _ in ast.walk(tree)),
                lines=len(source.splitlines()))


def minima(rows):
    return {axis: min(row["metrics"][axis] for row in rows) for axis in AXES}


def main():
    index_path = ROOT / "comparison/index.json"
    index = json.loads(index_path.read_text())
    cache = {}
    for item in index["source_files"]:
        result = measure(ROOT / item["path"])
        if result["sha256"] != item["sha256"]:
            raise ValueError("Comparator changed: " + item["path"])
        cache[item["sha256"]] = result

    primary = [dict(item, metrics=cache[item["sha256"]])
               for item in index["primary_checkers"]]
    current = [dict(item, metrics=cache[item["sha256"]])
               for item in index["current_variants"]]
    standalone = [dict(item, metrics=cache[item["sha256"]])
                  for item in index["standalone_programs"]]
    inherited = [dict(item, metrics={
        axis: sum(cache[file["sha256"]][axis] for file in item["files"])
        for axis in AXES}) for item in index["inherited_groups"]]
    complete_inherited = [item for item in inherited
                          if any(b.startswith("complete")
                                 for b in item["declared_boundaries"])]
    expanded = standalone + inherited
    frontier = minima(expanded)
    candidate = measure(ROOT / "checker.py")
    core_path = ROOT / "checker_core.py"
    core = measure(core_path) if core_path.exists() else None
    controls = {p.stem: measure(p) for p in sorted((ROOT / "controls").glob("*.py"))}
    savings = {axis: dict(absolute=frontier[axis] - candidate[axis],
                         percent=100 * (frontier[axis] - candidate[axis]) / frontier[axis])
               for axis in AXES}
    result = dict(
        repository=index["repository"], commit=index["repository_commit"],
        python_version=platform.python_version(),
        index_sha256=hashlib.sha256(index_path.read_bytes()).hexdigest(),
        all_comparison_hashes_verified=True,
        method=("Complete acceptance-source counts, including syntax validation, binding, "
                "schemas, rules, falsity representation, imports and JSON/CLI. Significant "
                "source tokens omit only comments, layout and actual initial docstrings. "
                "Normalized tokens/bytes use ast.unparse after docstring removal. AST counts "
                "include operator and context nodes. Each historical package sums all its "
                "listed source files. Python and its standard library are common runtime. "
                "No comparison program is imported or executed."),
        counts=index["counts"],
        candidate=candidate, core=core, controls=controls,
        coordinate_minima=frontier,
        primary_coordinate_minima=minima(primary),
        current_variants_coordinate_minima=minima(current),
        standalone_coordinate_minima=minima(standalone),
        inherited_coordinate_minima=minima(inherited),
        inherited_declared_complete_coordinate_minima=minima(complete_inherited),
        frontier_attained_by={axis: [row["id"] for row in expanded
                                    if row["metrics"][axis] == frontier[axis]]
                              for axis in AXES},
        primary_frontier_equals_expanded=(minima(primary) == frontier),
        current_variants_frontier_equals_expanded=(minima(current) == frontier),
        savings=savings,
        strictly_below_every_coordinate=all(candidate[axis] < frontier[axis] for axis in AXES),
        core_strictly_below_every_coordinate=(all(core[axis] < frontier[axis] for axis in AXES)
                                            if core else None),
        primary_checkers=primary,
        current_variants=current,
        standalone_programs=standalone,
        inherited_groups=inherited,
        qualification=index["qualification"])
    validation = ROOT / "validation"
    validation.mkdir(exist_ok=True)
    (validation / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")

    table_keys = ("source_tokens", "normalized_tokens", "ast_nodes", "normalized_bytes")
    table = [r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
             r"Complete checker & Source tokens & Norm.\ tokens & AST & Norm.\ bytes \\",
             r"\midrule"]
    for row in primary:
        table.append(row["label"] + " & " + " & ".join(
            f'{row["metrics"][key]:,}' for key in table_keys) + r" \\")
    table += [r"\midrule", "Expanded coordinate minima & "
              + " & ".join(f"{frontier[key]:,}" for key in table_keys) + r" \\",
              r"\textbf{Typed substitution (public)} & "
              + " & ".join(r"\textbf{" + f"{candidate[key]:,}" + "}" for key in table_keys)
              + r" \\"]
    if core:
        table.append("Canonical interface (optional) & "
                     + " & ".join(f"{core[key]:,}" for key in table_keys) + r" \\")
    table += [r"\bottomrule", r"\end{tabular}"]
    (validation / "comparison_table.tex").write_text("\n".join(table) + "\n")

    macros = {"CandidateTokens": candidate["normalized_tokens"],
              "CandidateSourceTokens": candidate["source_tokens"],
              "CandidateAST": candidate["ast_nodes"],
              "CandidateBytes": candidate["raw_bytes"],
              "CandidateNormBytes": candidate["normalized_bytes"],
              "MinimumTokens": frontier["normalized_tokens"],
              "MinimumSourceTokens": frontier["source_tokens"],
              "MinimumAST": frontier["ast_nodes"],
              "MinimumBytes": frontier["raw_bytes"],
              "MinimumNormBytes": frontier["normalized_bytes"],
              "StandaloneCount": len(standalone),
              "CurrentVariantCount": len(current),
              "HistoricalGroupCount": len(inherited)}
    if core:
        macros.update(CoreTokens=core["normalized_tokens"], CoreAST=core["ast_nodes"],
                      CoreNormBytes=core["normalized_bytes"],
                      CoreSourceTokens=core["source_tokens"], CoreBytes=core["raw_bytes"])
    (validation / "metrics_macros.tex").write_text("".join(
        "\\newcommand{\\" + name + "}{" + str(value) + "}\n"
        for name, value in macros.items()))
    print(json.dumps(dict(candidate=candidate, core=core, minima=frontier,
                          counts=index["counts"],
                          strictly_below=result["strictly_below_every_coordinate"]), indent=2))


if __name__ == "__main__":
    main()


