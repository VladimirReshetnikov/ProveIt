#!/usr/bin/env python3
"""Rebuild the paper and rerun the supplementary, finite checks."""
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
AUDIT = ROOT / "audit"


def run(label, command):
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (AUDIT / (label + ".log")).write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"{label} failed; see audit/{label}.log")
    return {"label": label, "exit_code": result.returncode}


def main():
    AUDIT.mkdir(exist_ok=True)
    if shutil.which("pdflatex") is None:
        raise RuntimeError("pdflatex is required to rebuild report.pdf")
    results = []
    for script in ("check_syntax.py", "check_pairing.py"):
        results.append(run(script.removesuffix(".py"),
                           [sys.executable, str(ROOT / "checks" / script)]))
    for index in range(1, 4):
        results.append(run(f"latex_pass_{index}",
                           ["pdflatex", "-interaction=nonstopmode",
                            "-halt-on-error", "report.tex"]))
    log = (ROOT / "report.log").read_text(encoding="utf-8", errors="replace")
    warnings = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()
                or "LaTeX Warning" in line]
    record = {"status": "PASS", "steps": results,
              "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
              "layout_warnings": warnings,
              "scope": "Build and supplementary checks; visual review is separate."}
    (AUDIT / "build_results.json").write_text(
        json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
