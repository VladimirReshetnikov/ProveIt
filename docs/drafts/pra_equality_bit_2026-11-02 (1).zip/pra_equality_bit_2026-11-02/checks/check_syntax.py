#!/usr/bin/env python3
"""Independent finite-syntax audit for the equality-bit PRA schema.

This checks concrete ASTs, not the mathematical bi-interpretation theorem.
Run from any directory; JSON and example output are written beside this file.
Only the Python standard library is required.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    kind: str
    children: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


def V(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")
N, A, V0, W0 = (V(x) for x in ("n", "a", "v", "w"))


def S(x: Term) -> Term:
    return Term("succ", (x,))


ONE = S(ZERO)


def eps(x: Term, y: Term) -> Term:
    return Term("eps", (x, y))


def rec(body: Term, counter: Term, seed: Term) -> Term:
    return Term("rec", (counter, seed), body=body)


@lru_cache(maxsize=None)
def active_size(t: Term) -> int:
    return 1 + sum(active_size(x) for x in t.children)


@lru_cache(maxsize=None)
def expanded_size(t: Term) -> int:
    """Count every frozen descriptor again at each recursor occurrence."""
    return (1 + sum(expanded_size(x) for x in t.children)
            + (expanded_size(t.body) if t.body is not None else 0))


@lru_cache(maxsize=None)
def occurrences(t: Term, name: str) -> int:
    return (int(t.kind == "var" and t.name == name)
            + sum(occurrences(x, name) for x in t.children))


@lru_cache(maxsize=None)
def free_vars(t: Term) -> frozenset[str]:
    if t.kind == "var":
        return frozenset((t.name,))
    return frozenset().union(*(free_vars(x) for x in t.children))


def substitute(t: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous ACTIVE substitution: inserted terms and indices stay frozen."""
    if t.kind == "var":
        return replacements.get(t.name, t)
    return Term(t.kind, tuple(substitute(x, replacements) for x in t.children),
                t.name, t.body)


@lru_cache(maxsize=None)
def rank(t: Term) -> int:
    active_rank = max((rank(x) for x in t.children), default=0)
    return max(active_rank, 1 + rank(t.body)) if t.body is not None else active_rank


@lru_cache(maxsize=None)
def legal(t: Term) -> bool:
    arities = {"var": 0, "zero": 0, "succ": 1, "eps": 2, "rec": 2}
    if t.kind not in arities or len(t.children) != arities[t.kind]:
        return False
    if (t.body is not None) != (t.kind == "rec"):
        return False
    if not all(legal(x) for x in t.children):
        return False
    if t.body is not None:
        if not legal(t.body) or not free_vars(t.body) <= {"v", "w"}:
            return False
        # Finite trees make the dependency relation well founded. The newly
        # named recursor has symbol rank 1 + rank(body); active argument terms
        # may belong to later stages and do not change its stored index.
    return True


@lru_cache(maxsize=None)
def uses(t: Term, kind: str) -> bool:
    return (t.kind == kind or any(uses(x, kind) for x in t.children)
            or (t.body is not None and uses(t.body, kind)))


@dataclass(frozen=True)
class Formula:
    kind: str
    children: tuple["Formula | Term", ...] = ()
    binder: str = ""


def eq(x: Term, y: Term) -> Formula:
    return Formula("eq", (x, y))


BOT = Formula("bottom")


def both(x: Formula, y: Formula) -> Formula:
    return Formula("and", (x, y))


def either(x: Formula, y: Formula) -> Formula:
    return Formula("or", (x, y))


def implies(x: Formula, y: Formula) -> Formula:
    return Formula("implies", (x, y))


def all_(name: str, body: Formula) -> Formula:
    return Formula("forall", (body,), name)


SIGMA = implies(eq(ZERO, ONE), BOT)


def formula_size(f: Formula, expand_descriptors: bool = False) -> int:
    size = expanded_size if expand_descriptors else active_size
    return 1 + sum(size(x) if isinstance(x, Term)
                   else formula_size(x, expand_descriptors) for x in f.children)


def formula_free_vars(f: Formula) -> frozenset[str]:
    result = frozenset().union(*(
        free_vars(x) if isinstance(x, Term) else formula_free_vars(x)
        for x in f.children))
    return result - {f.binder} if f.kind == "forall" else result


def quantifier_profile(f: Formula, depth: int = 0) -> tuple[int, int]:
    is_quantifier = int(f.kind == "forall")
    current_depth = depth + is_quantifier
    profiles = [quantifier_profile(x, current_depth)
                for x in f.children if isinstance(x, Formula)]
    return (is_quantifier + sum(x[0] for x in profiles),
            max([current_depth] + [x[1] for x in profiles]))


def active_names(f: Formula) -> frozenset[str]:
    result = frozenset((f.binder,)) if f.kind == "forall" else frozenset()
    return result.union(*(
        free_vars(x) if isinstance(x, Term) else active_names(x)
        for x in f.children))


def base_and_step(u: Term) -> Formula:
    body = substitute(u, {"n": V0, "a": W0})
    assert legal(body) and free_vars(body) <= {"v", "w"}
    r0 = rec(body, ZERO, A)
    rn = rec(body, N, A)
    rsn = rec(body, S(N), A)
    update = substitute(u, {"n": rn, "a": N})
    return both(eq(r0, A), eq(rsn, update))


def zero_induction(u: Term) -> Formula:
    base = eq(substitute(u, {"n": ZERO}), ZERO)
    present = eq(u, ZERO)
    following = eq(substitute(u, {"n": S(N)}), ZERO)
    progress = all_("n", implies(present, following))
    return implies(both(base, progress), present)


def new_schema(u: Term) -> Formula:
    computation = base_and_step(u)
    if u == ZERO:  # Literal syntax only: no numerical equality test is used here.
        equality_bit = both(eq(eps(A, A), ZERO),
                            either(eq(A, N), eq(eps(A, N), ONE)))
        payload = both(SIGMA, equality_bit)
    else:
        payload = zero_induction(u)
    return all_("a", all_("n", both(computation, payload)))


def old_counter_schema(u: Term) -> Formula:
    adjacent = eq(u, substitute(u, {"a": S(A)}))
    rooted = either(eq(N, ZERO), adjacent)
    successor_adjacent = eq(substitute(u, {"n": S(N)}),
                            substitute(u, {"n": S(N), "a": S(A)}))
    progress = all_("n", implies(rooted, successor_adjacent))
    computation = both(SIGMA, base_and_step(u))
    return all_("a", all_("n", both(computation, implies(progress, rooted))))


def show_term(t: Term) -> str:
    if t.kind == "var":
        return t.name
    if t.kind == "zero":
        return "0"
    if t.kind == "rec":
        return "R{" + show_term(t.body) + "}(" + ",".join(map(show_term, t.children)) + ")"
    return {"succ": "S", "eps": "eps"}[t.kind] + "(" + ",".join(map(show_term, t.children)) + ")"


def show_formula(f: Formula) -> str:
    if f.kind == "bottom":
        return "FALSE"
    if f.kind == "eq":
        return "(" + show_term(f.children[0]) + "=" + show_term(f.children[1]) + ")"
    if f.kind == "forall":
        return "forall " + f.binder + " (" + show_formula(f.children[0]) + ")"
    op = {"and": " & ", "or": " | ", "implies": " -> "}[f.kind]
    return "(" + op.join(show_formula(x) for x in f.children) + ")"


def check_substitution() -> dict[str, bool]:
    body = eps(V0, W0)
    t = rec(body, N, eps(A, ZERO))
    replacement = rec(V0, N, A)
    result = substitute(t, {"n": replacement, "a": N})
    assert result.body is body
    assert result.children[0] is replacement
    assert result.children[0].children[1] == A  # Not recursively substituted.
    assert result.children[1] == eps(N, ZERO)
    nested_body = rec(eps(V0, W0), V0, W0)
    outer = rec(nested_body, N, A)
    renamed = substitute(outer, {"n": V0, "a": W0})
    assert renamed.body is nested_body
    assert renamed.children == (V0, W0)
    assert new_schema(eps(ZERO, ZERO)) != new_schema(ZERO)
    assert quantifier_profile(new_schema(eps(ZERO, ZERO))) == (3, 3)
    # An explicit forbidden captured variable is rejected in a stored index.
    assert not legal(rec(A, N, A))
    return {
        "stored_descriptors_frozen": True,
        "inserted_terms_not_resubstituted": True,
        "nested_descriptor_renaming_is_capture_free": True,
        "zero_exception_is_literal_not_extensional": True,
        "captured_external_parameter_rejected": True,
    }


def generate_terms() -> list[Term]:
    rng = random.Random(20261102)
    initial = [ZERO, N, A, ONE, S(N), S(A), eps(N, A), eps(ZERO, ZERO),
               rec(ZERO, N, A), rec(V0, N, A), rec(W0, N, A),
               rec(eps(V0, W0), N, A),
               rec(rec(S(V0), V0, W0), N, eps(A, ZERO))]

    def make(depth: int, names: tuple[str, str], allow_eps: bool) -> Term:
        if depth == 0 or rng.random() < 0.23:
            return rng.choice((ZERO, V(names[0]), V(names[1])))
        op = rng.choice(("succ", "rec", "eps") if allow_eps else ("succ", "rec"))
        if op == "succ":
            return S(make(depth - 1, names, allow_eps))
        if op == "eps":
            return eps(make(depth - 1, names, allow_eps), make(depth - 1, names, allow_eps))
        return rec(make(depth - 1, ("v", "w"), allow_eps),
                   make(depth - 1, names, allow_eps),
                   make(depth - 1, names, allow_eps))

    unique = dict.fromkeys(initial)
    for allow_eps, target in ((False, 320), (True, 640)):
        while len(unique) < target:
            candidate = make(rng.choice((2, 3, 4)), ("n", "a"), allow_eps)
            if active_size(candidate) <= 80 and expanded_size(candidate) <= 800:
                unique[candidate] = None
    return list(unique)


def main() -> None:
    here = Path(__file__).resolve().parent
    substitution = check_substitution()
    terms = generate_terms()
    rows = []
    common_rows = []
    for index, u in enumerate(terms):
        assert legal(u) and free_vars(u) <= {"n", "a"}
        m, i, j = active_size(u), occurrences(u, "n"), occurrences(u, "a")
        M = expanded_size(u)
        fresh, old = new_schema(u), old_counter_schema(u)
        new_active, old_active = formula_size(fresh), formula_size(old)
        new_expanded, old_expanded = formula_size(fresh, True), formula_size(old, True)
        expected_new = 38 if u == ZERO else 26 + 5 * m + 3 * i
        expected_new_expanded = 40 if u == ZERO else 26 + (7 + i) * M + 3 * i
        expected_old = 35 + 7 * m + 4 * i + 3 * j
        expected_old_expanded = 35 + (9 + i) * M + 4 * i + 3 * j
        assert new_active == expected_new, (show_term(u), new_active, expected_new)
        assert old_active == expected_old, (show_term(u), old_active, expected_old)
        assert new_expanded == expected_new_expanded
        assert old_expanded == expected_old_expanded
        assert formula_free_vars(fresh) == formula_free_vars(old) == frozenset()
        assert active_names(fresh) == active_names(old) == {"n", "a"}
        assert quantifier_profile(fresh) == ((2, 2) if u == ZERO else (3, 3))
        assert quantifier_profile(old) == (3, 3)
        assert new_active < old_active and new_expanded < old_expanded
        row = {"index": index, "term": show_term(u), "m": m, "i": i, "j": j,
               "descriptor_expanded_input_size": M, "rank": rank(u),
               "common_old_language_input": not uses(u, "eps"),
               "new_active": new_active, "old_active": old_active,
               "active_saving": old_active - new_active,
               "new_descriptor_expanded": new_expanded,
               "old_descriptor_expanded": old_expanded,
               "descriptor_expanded_saving": old_expanded - new_expanded}
        rows.append(row)
        if row["common_old_language_input"]:
            common_rows.append(row)

    summary = {
        "status": "PASS",
        "scope": "Finite syntax, substitution, exact AST counts, and binder checks; not a formal proof of PRA calibration or bi-interpretability.",
        "seed": 20261102,
        "distinct_terms": len(terms),
        "common_old_language_terms": len(common_rows),
        "terms_containing_epsilon_in_active_syntax_or_descriptor": sum(uses(t, "eps") for t in terms),
        "terms_containing_recursors": sum(uses(t, "rec") for t in terms),
        "terms_of_descriptor_rank_at_least_two": sum(rank(t) >= 2 for t in terms),
        "maximum_active_input_size": max(active_size(t) for t in terms),
        "maximum_descriptor_expanded_input_size": max(expanded_size(t) for t in terms),
        "literal_zero_special_instances": sum(t == ZERO for t in terms),
        "old_formula_profile": {"quantifier_occurrences": 3, "depth": 3},
        "new_ordinary_profile": {"quantifier_occurrences": 3, "depth": 3},
        "new_literal_zero_profile": {"quantifier_occurrences": 2, "depth": 2},
        "all_formulas_closed": True,
        "only_active_names_n_a": True,
        "all_primitive_function_arities_at_most_two": True,
        "all_active_and_descriptor_expanded_counts_match": True,
        "all_common_inputs_strictly_shorter": True,
        "minimum_common_active_saving": min(r["active_saving"] for r in common_rows),
        "minimum_common_descriptor_expanded_saving": min(r["descriptor_expanded_saving"] for r in common_rows),
        "substitution_checks": substitution,
        "active_formulas": {
            "new_ordinary": "26 + 5*m + 3*i", "new_literal_zero": "38",
            "old": "35 + 7*m + 4*i + 3*j",
            "ordinary_saving": "9 + 2*m + i + 3*j", "literal_zero_saving": "4"},
        "descriptor_expanded_formulas": {
            "new_ordinary": "26 + (7+i)*M + 3*i", "new_literal_zero": "40",
            "old": "35 + (9+i)*M + 4*i + 3*j",
            "ordinary_saving": "9 + 2*M + i + 3*j", "literal_zero_saving": "4"},
        "comparison_caveat": "The old template is also counted for epsilon-containing terms to audit the algebraic size formula, but those are not asserted to be legal inputs in the old signature. Strict literal-input comparisons use common_old_language_input=true.",
    }
    result = {"summary": summary, "terms": rows}
    (here / "syntax_results.json").write_text(json.dumps(result, indent=2) + "\n")
    examples = ["FINITE-SYNTAX EXAMPLES", "", "R{body}(counter,seed) freezes body during active substitution.",
                "m = active size; i,j = active occurrences of n,a; M includes frozen descriptors.",
                "All formula abbreviations are expanded in the checked ASTs.", ""]
    for row in rows[:13]:
        examples.extend([f"Input: {row['term']}",
                         f"  m={row['m']} i={row['i']} j={row['j']} M={row['descriptor_expanded_input_size']} rank={row['rank']}",
                         f"  active: new={row['new_active']} old={row['old_active']} saving={row['active_saving']}",
                         f"  descriptor-expanded: new={row['new_descriptor_expanded']} old={row['old_descriptor_expanded']} saving={row['descriptor_expanded_saving']}",
                         f"  literal common input: {row['common_old_language_input']}", ""])
    for u in (ZERO, N, eps(N, A)):
        examples.extend(["Expanded new formula for " + show_term(u) + ":", show_formula(new_schema(u)), ""])
    (here / "syntax_examples.txt").write_text("\n".join(examples))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
