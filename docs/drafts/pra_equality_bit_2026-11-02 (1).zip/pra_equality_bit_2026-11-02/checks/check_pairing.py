#!/usr/bin/env python3
"""Bounded standard-natural-number diagnostics for the scalar pairing.

The mathematical general proof is in the manuscript. These computations
check implementation and indexing, and do not replace that proof.
"""

from __future__ import annotations

import json
from pathlib import Path


def epsilon(x: int, y: int) -> int:
    return 0 if x == y else 1


TRIANGULAR = [0]


def triangular(n: int) -> int:
    assert n >= 0
    while len(TRIANGULAR) <= n:
        TRIANGULAR.append(TRIANGULAR[-1] + len(TRIANGULAR))
    return TRIANGULAR[n]


def diagonal_counter(limit: int) -> list[int]:
    """Compute k by exactly the manuscript's scalar counter recurrence."""
    values = [0]
    for old_counter in range(limit):
        state = values[-1]
        increment = epsilon(epsilon(old_counter + 1, triangular(state + 1)), 1)
        values.append(state + increment)
    return values


def pair(x: int, y: int) -> int:
    return triangular(x + y) + y


def projections(z: int, k_values: list[int]) -> tuple[int, int]:
    diagonal = k_values[z]
    right = max(z - triangular(diagonal), 0)
    left = max(diagonal - right, 0)
    return left, right


def main() -> None:
    here = Path(__file__).resolve().parent
    limit = 8191
    width = 64
    values = diagonal_counter(limit)
    assert pair(width - 1, width - 1) <= limit
    grid_tests = 0
    for x in range(width):
        for y in range(width):
            encoded = pair(x, y)
            assert projections(encoded, values) == (x, y)
            grid_tests += 1
    round_trip_tests = 0
    for z in range(limit + 1):
        x, y = projections(z, values)
        assert pair(x, y) == z
        assert triangular(values[z]) <= z < triangular(values[z] + 1)
        round_trip_tests += 1
    boundary_tests = block_tests = 0
    b = 0
    while triangular(b) <= limit:
        assert values[triangular(b)] == b
        assert triangular(b) == b * (b + 1) // 2
        boundary_tests += 1
        for j in range(b + 1):
            at = triangular(b) + j
            if at <= limit:
                assert values[at] == b
                block_tests += 1
        b += 1
    result = {
        "status": "PASS",
        "scope": "Bounded computations in the standard natural numbers only; no formal proof and no check of all nonstandard models.",
        "recurrence": "k(0)=0; k(n+1)=k(n)+epsilon(epsilon(n+1,T(k(n)+1)),1)",
        "epsilon_convention": "0 for equal inputs, 1 otherwise",
        "triangular_recurrence": "T(0)=0; T(n+1)=T(n)+(n+1)",
        "pair": "T(x+y)+y",
        "right_projection": "z dotminus T(k(z))",
        "left_projection": "k(z) dotminus right_projection(z)",
        "counter_inputs": {"minimum": 0, "maximum": limit},
        "grid": {"x": [0, width - 1], "y": [0, width - 1]},
        "pair_projection_retractions_checked": grid_tests,
        "encoded_value_round_trips_checked": round_trip_tests,
        "triangular_boundary_values_checked": boundary_tests,
        "block_entries_checked": block_tests,
        "boundary_and_block_checks": "PASS",
        "closed_triangular_formula_crosscheck": "PASS",
        "surjectivity_note": "The extra encoded-value round trips are numerical diagnostics. Only the two projection retractions are needed for the manuscript's parameter coding.",
        "examples": [{"x": x, "y": y, "code": pair(x, y),
                      "projections": list(projections(pair(x, y), values))}
                     for x, y in [(0, 0), (0, 1), (1, 0), (2, 3), (3, 2), (7, 11), (63, 63)]],
    }
    (here / "pairing_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
