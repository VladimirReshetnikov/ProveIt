SUPPORTING CHECKS

Run with Python 3.10 or later; no third-party packages are required:

  python3 checks/check_syntax.py
  python3 checks/check_pairing.py

Both scripts also work from another working directory. Output files are
written beside the scripts.

check_syntax.py constructs concrete immutable term and formula syntax trees.
It checks 640 distinct terms, including nested recursor descriptors and
equality-bit terms. Active simultaneous substitution never changes a stored
descriptor or substitutes again inside an inserted term. Every resulting
formula is closed, uses only the active names n,a, and has the stated
quantifier profile. Both active and recursively descriptor-expanded node
counts are calculated from the ASTs and compared with the reported formulas.

The new constructor treats only the literal input term 0 specially. A term
such as epsilon(0,0), although numerically zero in the intended model, goes
through the ordinary constructor. The special instance contains all of the
separation and equality-bit axioms, and both computation equations for R_0.

The old counter-recursion formula is also built as an AST. Literal same-input
comparisons are distinguished from purely algebraic template comparisons:
terms containing epsilon, including inside a stored descriptor, were not
inputs in the old signature. The JSON marks that distinction for every term.

One node is charged for each variable, constant, function application,
equality, connective, bottom, and quantifier. Negation is expanded as an
implication to bottom. Stored descriptors are omitted in active counts and
counted recursively at every occurrence in descriptor-expanded counts.
There is no shared-DAG or shared-descriptor discount in the expanded count.

check_pairing.py computes triangular numbers and the inverse counter by their
actual scalar recurrences. It checks the projection retractions on a 64 by 64
grid, triangular boundaries and blocks, and 8192 encoded-value round trips.
It uses no square-root formula for the inverse counter.

VERIFICATION BOUNDARY

These are syntax audits and bounded standard-model diagnostics. They are not
a Lean/Rocq formalization, a proof of the general induction calibration, or a
machine-checked proof of first-order bi-interpretability. The manuscript
contains the mathematical proofs. Passing these checks does not replace them.
