PRA FROM A BINARY EQUALITY TEST
2 November 2026

START HERE
report.pdf is the complete mathematical paper.
report.tex and sections/*.tex are its complete editable LaTeX source.
AXIOMS.txt gives the exact stand-alone specification.

RESULT
A classical first-order theory with 0, S, a binary equality bit epsilon,
and description-indexed binary scalar counter recursors is definitionally
equivalent, bi-interpretable, and equiconsistent with classical first-order
PRA. The interpretations preserve the whole carrier and native equality.

The actual axiom family has one literal-zero seed instance and one
effective schema for every other binary term. The seed includes ALL
equality-bit axioms and separation; no new logical rules are assumed.
The missing zero-induction payload at the zero term is a logical tautology.

COMPARISON
All six archives in ProveIt's docs/drafts were inspected at commit
5ffc596c844086fc26509685c7833b548ebf25c3.
The smallest current active-syntax template was counter recursion:
    35 + 7*m + 4*i + 3*j.
Here m is active input-term size, i the active n occurrences, and j
the active a occurrences. The new fully charged family has size:
    38,                         for the literal input 0;
    26 + 5*m + 3*i,             for all other inputs.
At input 0 the old size was 42. Every common input is strictly shorter.
The corresponding strict comparison also holds when all stored
descriptors are recursively counted at every occurrence.

TRADEOFFS
One additional binary primitive and two syntactic constructor cases,
instead of the incumbent's one. Ordinary first-order logic and maximum
function arity two are retained. No global minimality, proof-translation
size bound, or same-language shortening is claimed.

PROOF
The paper proves native equality reflection, one-parameter quantifier-free
induction, a short triangular pairing retraction with its parameter
budget checked, arbitrary finite parameter induction, the PR compiler,
the reverse interpretation, and both identity composites. It also
includes an explicit PR equality-bit construction inside ordinary PRA.
This is a complete written proof, not a full Lean or Rocq formalization.

ARTIFACTS
  report.pdf; report.tex; sections/*.tex
  AXIOMS.txt
  checks/check_syntax.py; checks/check_pairing.py
  checks/*_results.json; checks/*_check.log; checks/syntax_examples.txt
  source-manifest.json       pinned inputs with Git and SHA-256 hashes
  audit/review.txt           mathematical review scope and findings
  audit/build_results.json   reproducible build/check status
  build.py                  build PDF and rerun checks
  SHA256SUMS.txt             hashes of deliverable contents

RUN
From this directory:
    python3 build.py
Requires Python 3 (standard library only), pdflatex, and the LaTeX
packages listed in report.tex. The existing PDF can be read without them.

CHECKING SCOPE
The syntax checker independently constructs axiom ASTs, performs active
simultaneous substitution with frozen descriptor bodies, and verifies
both count conventions, binding, arities, and legal dependencies.
The numerical checker evaluates the triangular counter by its recurrence.
Its finite natural-number tests are diagnostics, not a proof of the
unbounded arithmetic or model-theoretic results.

The source ZIPs are not duplicated here. Their precise URLs, immutable
snapshot identifiers, byte counts, and hashes are in source-manifest.json.
