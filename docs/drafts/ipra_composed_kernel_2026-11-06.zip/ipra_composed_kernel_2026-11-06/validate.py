"""Offline regression and independent-baseline cross-checks.

Every accepted candidate is expanded into the separately implemented,
verbatim fused K checker.  The numerical axioms and witness introductions
therefore pass through the older contextual numerical and ordinary Sigma
rules.  These finite tests are not a machine formalization of soundness.
Neither checker imports this module or the untrusted compiler.
"""

from pathlib import Path
import hashlib
import json
import subprocess
import sys

import checker as k
import translate as tr

ROOT = Path(__file__).resolve().parent
OLD = tr.old
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)
Z = k.ZERO
T = ["=", Z, Z]
F = ["=", Z, ["s", Z]]


def json_value(value):
    return json.loads(json.dumps(value))


def eq(s, t):
    return ["=", s, t]


def source_wrap(source, witness):
    """An ordinary Sigma-I wrapper, checked by the original kernel."""
    goal = OLD.freeze(source["goal"])
    principal = ("sig", OLD.shift(goal), ("=", 0, 0))
    result = {"assumptions": source["assumptions"], "goal": principal,
              "proof": ("pair", principal, witness, OLD.freeze(source["proof"]),
                        tr.old_reflexivity(witness))}
    OLD.check(result)
    return result


def direct_positive_cases():
    yield "identity", [[], ["pi", ["false"], ["false"]],
                       ["pi", ["false"], ["hyp", ["false"]]]]
    yield "derived_reflexivity", [[], eq(0, 0), tr.reflexivity(0)]
    large = 10**50
    yield "large_free_parameter", [[eq(large, Z)], eq(large, Z),
                                   ["hyp", eq(large, Z)]]
    yield "surface_bottom_conversion", [[["false"]], ["false"],
                                        ["hyp", F]]
    # A malformed lookup key can be Python-equal to a stored valid formula.
    # The checker deliberately returns that stored formula.  It must not
    # return the key; the latter would violate the formation invariant.
    yield "lookup_returns_stored_formula", [[eq(1, Z)], eq(1, Z),
                                            ["hyp", eq(True, Z)]]
    witness = ["r", ["s", 3], 4, ["r", 1, 0, ["s", 0]]]
    guard = eq(0, k.shift(witness))
    yield "witness_equation_is_available", [[], ["sig", guard, guard],
                                            ["pair", witness,
                                             ["hyp", guard], ["hyp", guard]]]

    # Obtain expected schema conclusions from derivations in original K,
    # not from the candidate's numerical generator.
    templates = [
        ("=", 0, 0),
        ("=", ("r", 0, 1, ("s", 0)), 2),
        OLD.CLASH,
        ("pi", ("=", 0, 1), ("=", 1, 2)),
        ("sig", ("=", 0, 1), ("pi", ("=", 2, 0), ("=", 3, 2))),
        ("pi", ("sig", ("=", 0, 2), ("=", 1, 3)),
         ("=", ("r", 1, 2, ("r", 1, 0, ("s", 0))), 0)),
    ]
    for context_size in (0, 2):
        context = tuple(("=", i, OLD.ZERO) for i in range(context_size))
        for i, template in enumerate(templates):
            derivation = tr.expand_numerical(template, context_size)
            expected = OLD.infer(derivation, context)
            source = {"assumptions": context, "goal": expected, "proof": derivation}
            OLD.check(json_value(source))
            yield f"numerical_schema_{i}_context_{context_size}", [
                tr.encode(context), tr.encode(expected), ["nat", tr.encode(template)]]


def negative_cases():
    g = eq(0, Z)
    yield "pi_eigenvariable_capture", [[g], ["pi", T, g],
                                       ["pi", T, ["hyp", k.shift(g)]]]
    sigma = ["sig", eq(0, Z), T]
    yield "sigma_witness_escape", [[sigma], eq(0, Z),
                                    ["use", ["hyp", sigma], eq(0, Z),
                                     ["hyp", eq(0, Z)]]]
    h = eq(["r", Z, Z, 2], Z)
    sigma_h = ["sig", h, T]
    yield "sigma_escape_beneath_recursion", [[sigma_h], h,
        ["use", ["hyp", sigma_h], h, ["hyp", h]]]
    yield "witness_capture", [[], ["sig", eq(0, 0), eq(0, 0)],
                               ["pair", 0, ["hyp", eq(0, 1)], ["hyp", eq(0, 1)]]]
    template = ["pi", T, eq(1, 0)]
    equality = eq(0, 1)
    premise = k.inst(template, 0)
    yield "transport_capture_under_pi", [[equality, premise],
        ["pi", T, eq(0, 0)], ["use", ["hyp", equality], template, ["hyp", premise]]]
    premise = k.inst(h, 0)
    yield "transport_capture_under_recursion", [[equality, premise],
        eq(["r", Z, Z, 1], Z), ["use", ["hyp", equality], h, ["hyp", premise]]]

    # Forged unrestricted induction: its claimed non-equation step guard
    # contains A(y), whereas the actual leaf supplies only A(0).
    matrix = ["pi", T, eq(1, Z)]
    base = k.inst(matrix, Z)
    successor = k.subst(matrix, lambda i: ["s", 0] if i == 0 else i)
    bad_step = ["pi", matrix, successor]
    forged = ["pi", ["sig", k.shift(base, 2), k.shift(bad_step, 2)], matrix]
    yield "forbidden_quantified_induction", [[], forged, ["nat", matrix]]

    yield "unproved_bottom", [[], ["false"], ["hyp", ["false"]]]
    yield "wrong_guard", [[["pi", F, T], T], T,
                          ["use", ["hyp", ["pi", F, T]], Z, ["hyp", T]]]
    yield "wrong_equality_source", [[equality, eq(2, 2)], eq(1, 0),
        ["use", ["hyp", equality], eq(0, 1), ["hyp", eq(2, 2)]]]
    yield "missing_hypothesis", [[T], F, ["hyp", F]]
    yield "raw_integer_hypothesis_key", [[T], T, ["hyp", 0]]
    yield "boolean_hypothesis_key", [[T], T, ["hyp", False]]

    yield "malformed_equality_template", [[T], T,
        ["use", ["hyp", T], ["=", 0], ["hyp", T]]]
    yield "string_in_equality_template", [[T], T,
        ["use", ["hyp", T], ["=", "z", "z"], ["hyp", T]]]
    yield "boolean_in_equality_template", [[eq(0, Z)], T,
        ["use", ["hyp", eq(0, Z)], eq(True, Z), ["hyp", eq(0, Z)]]]
    ss = ["sig", T, T]
    yield "string_in_sigma_conclusion", [[T, ss], T,
        ["use", ["use", ["hyp", ss], ["=", "z", "z"], ["hyp", T]],
         eq(0, Z), ["hyp", T]]]
    yield "malformed_sigma_conclusion", [[ss], T,
        ["use", ["hyp", ss], ["=", Z], ["hyp", T]]]
    yield "malformed_fresh_pi_guard", [[], ["pi", T, T],
                                       ["pi", ["=", Z], tr.reflexivity(Z)]]
    yield "formula_as_pi_witness", [[["pi", T, T], T], T,
        ["use", ["hyp", ["pi", T, T]], T, ["hyp", T]]]
    for name, witness in [("boolean", True), ("float", 0.0),
                          ("string", "x"), ("formula", T),
                          ("negative", -2), ("unknown", ["unknown"])]:
        yield f"invalid_{name}_witness", [[T], ss,
            ["pair", witness, ["hyp", T], ["hyp", T]]]
    yield "malformed_numerical_matrix", [[], T, ["nat", ["=", Z]]]
    yield "string_in_numerical_matrix", [[], T, ["nat", ["=", "z", "z"]]]

    variable_counter = ["r", 0, Z, 0]
    yield "unknown_recursion_counter", [[], eq(variable_counter, Z),
                                        ["rec", variable_counter]]
    yield "wrong_recursion_arity", [[], T, ["rec", ["r", Z, Z]]]
    yield "formula_recursion_body", [[], T, ["rec", ["r", Z, Z, T]]]
    yield "recursion_is_variable", [[], T, ["rec", 0]]
    yield "primitive_reflexivity_absent", [[], T, ["refl", Z]]
    yield "primitive_explosion_absent", [[F], T, ["abort", ["hyp", F], T]]
    yield "primitive_bridge_absent", [[F], F, ["bridge", ["hyp", F]]]

    yield "boolean_goal", [[eq(1, Z)], eq(True, Z), ["hyp", eq(1, Z)]]
    yield "floating_goal", [[eq(0, Z)], eq(0.0, Z), ["hyp", eq(0, Z)]]
    yield "boolean_assumption", [[eq(True, Z)], eq(1, Z), ["hyp", eq(1, Z)]]
    yield "negative_below_zero_token", [[eq(-2, Z)], eq(-2, Z), ["hyp", eq(-2, Z)]]
    yield "dictionary_envelope", {"assumptions": [T], "goal": T, "proof": ["hyp", T]}
    yield "extra_envelope_item", [[T], T, ["hyp", T], 0]
    yield "missing_envelope_item", [[T], T]
    yield "string_assumption_context", ["", T, tr.reflexivity(Z)]
    yield "object_assumption_context", [{}, T, tr.reflexivity(Z)]
    yield "scalar_input", 0
    yield "string_input", "abc"


def main():
    positive = []
    negative = []
    cli_files = []
    output = ROOT / "certificates"
    output.mkdir(exist_ok=True)

    def accept(name, data, save=False):
        data = json_value(data)
        k.check(data)
        expanded = tr.backward_certificate(data)
        if tr.encode(expanded["goal"]) != k.erase(data[1]):
            raise AssertionError(("expanded goal changed", name))
        if tr.encode(expanded["assumptions"]) != k.erase(data[0]):
            raise AssertionError(("expanded context changed", name))
        positive.append(name)
        if save:
            filename = "identity" if name == "direct/identity" else name.replace("/", "_")
            path = output / (filename + ".json")
            path.write_text(json.dumps(data, separators=(",", ":")) + "\n")
            cli_files.append((path, True))

    def reject(name, data):
        data = json_value(data)
        try:
            k.check(data)
        except ERRORS:
            pass
        else:
            raise AssertionError(("negative accepted", name))
        negative.append(name)
        path = output / ("reject_" + name + ".json")
        path.write_text(json.dumps(data, separators=(",", ":")) + "\n")
        cli_files.append((path, False))

    inherited = []
    for folder in ("baseline", "stress"):
        paths = sorted((ROOT / "validation" / folder).glob("*.json"))
        expected = 53 if folder == "baseline" else 6
        if len(paths) != expected:
            raise AssertionError(("wrong fixture count", folder, len(paths)))
        for path in paths:
            source = json.loads(path.read_text())
            accept(folder + "/" + path.stem, tr.certificate(source), save=True)
            inherited.append((folder + "/" + path.stem, source))
            # One and two new witness binders stress local Pi/Sigma scopes,
            # induction hypotheses, and the two recursor-bound positions.
            wrapped = source
            for depth, witness in enumerate((13, ("r", ("s", 2), 5,
                                                   ("r", 1, 0, ("s", 0)))), 1):
                wrapped = source_wrap(wrapped, witness)
                accept(f"wrapped_{depth}/{folder}/{path.stem}", tr.certificate(wrapped))

    for name, source in inherited:
        # Replace every free number by a dependent nested recursor.  The
        # substitution traverses local proof and term binders independently.
        env = lambda i: ["r", ["s", i + 2], i + 5, ["r", 1, 0, ["s", 0]]]
        context = tuple(map(OLD.freeze, source["assumptions"]))
        target = [[tr.expression(a, env) for a in context],
                  tr.expression(OLD.freeze(source["goal"]), env),
                  tr.translate(OLD.freeze(source["proof"]), context, env)]
        accept("substitution/" + name, target)

    for name, data in direct_positive_cases():
        accept("direct/" + name, data, save=True)
    for name, data in negative_cases():
        reject(name, data)

    rejected_source = []
    for path in sorted((ROOT / "validation" / "invalid_baseline").glob("*.json")):
        try:
            tr.certificate(json.loads(path.read_text()))
        except ERRORS:
            rejected_source.append(path.name)
        else:
            raise AssertionError(("invalid source survived compiler", path.name))
    # These source nodes would disappear during erasure, so source checking
    # must happen before compilation rather than only checking the output.
    for name, source in [
        ("bad_bridge_erasure", {"assumptions": [("=", OLD.ZERO, OLD.ZERO)],
          "goal": OLD.FALSE, "proof": ("bridge", ("hyp", 0))}),
        ("bad_discarded_bottom_step", {"assumptions": [OLD.FALSE],
          "goal": OLD.FALSE, "proof": ("nat", OLD.FALSE, OLD.ZERO,
          ("hyp", 0), ("hyp", 99))})]:
        try:
            tr.certificate(json_value(source))
        except ERRORS:
            rejected_source.append(name)
        else:
            raise AssertionError(("invalid erased source survived", name))

    for path, expected in cli_files:
        for optimized in (False, True):
            command = [sys.executable, *(["-O"] if optimized else []),
                       str(ROOT / "checker.py"), str(path)]
            result = subprocess.run(command, text=True, capture_output=True)
            if (result.returncode != (0 if expected else 1) or
                    result.stdout.strip() != ("ACCEPT" if expected else "REJECT")):
                raise AssertionError(("CLI", path.name, optimized,
                                      result.returncode, result.stdout, result.stderr))

    hash_file = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    summary = {
        "status": "PASS",
        "checker_sha256": hash_file(ROOT / "checker.py"),
        "translator_sha256": hash_file(ROOT / "translate.py"),
        "baseline_sha256": hash_file(ROOT / "validation" / "baseline_checker.py"),
        "baseline_original_certificates": 53,
        "inherited_binding_stress_certificates": 6,
        "wrapped_certificates": 2 * len(inherited),
        "numerical_substitution_certificates": len(inherited),
        "candidate_positive_checks": len(positive),
        "independent_baseline_expansion_checks": len(positive),
        "candidate_negative_checks": len(negative),
        "invalid_sources_rejected_before_compilation": len(rejected_source),
        "normal_and_optimized_cli_checks": 2 * len(cli_files),
        "positive_names": positive,
        "negative_names": negative,
        "rejected_source_names": rejected_source,
        "scope": "Finite executable regressions, bidirectional compiler checks, and original-kernel proof replay. No Lean/Rocq formalization or universal machine-checked soundness theorem is claimed.",
    }
    (ROOT / "validation" / "test_report.json").write_text(json.dumps(summary, indent=2) + "\n")
    summary_tex = rf"""The validation run completed successfully.  The untrusted
compiler checks each source certificate before erasing bridge nodes or
replacing rules.  It then checks the translated certificate with the new
kernel.  An independently written reverse compiler expands every accepted
candidate into the verbatim original fused checker: witness introductions
become ordinary existential introductions, and each packed numerical axiom
is derived using the old contextual numerical rule.  Both contexts and
conclusions agree after the specified falsity encoding.

\begin{{center}}\small
\begin{{tabular}}{{@{{}}lr@{{}}}}
\toprule
Check & Passed\\
\midrule
Inherited baseline derivations & {summary['baseline_original_certificates']}\\
Inherited binding stress derivations & {summary['inherited_binding_stress_certificates']}\\
One and two additional witness binders & {summary['wrapped_certificates']}\\
Substitution of dependent nested recursors & {summary['numerical_substitution_certificates']}\\
Additional direct candidate derivations & {len(positive) - 4 * len(inherited)}\\
\midrule
Accepted candidate derivations, total & {len(positive)}\\
Expansions accepted by the original checker & {len(positive)}\\
Adversarial candidate inputs rejected & {len(negative)}\\
Invalid sources rejected before compilation & {len(rejected_source)}\\
Normal and optimized Python command-line runs & {2 * len(cli_files)}\\
\bottomrule
\end{{tabular}}
\end{{center}}

The adversarial cases cover escaping eigenvariables, capture beneath
recursion and logical binders, a forged induction schema for a quantified
matrix, malformed templates, invalid witnesses, unproved falsity,
incorrect inference premises, boolean/float aliases in numerical syntax,
and malformed input envelopes.  The membership-key check also confirms
that lookup returns the stored wellformed assumption, including when a
raw key is merely Python-equal to it.  All delivered certificate files are
run through the command-line checker both normally and with
\texttt{{python3 -O}}; optimization does not disable validation.

Run \texttt{{python3 validate.py}} from the extracted archive to reproduce
these counts and regenerate \texttt{{validation/test\_report.json}}.
\texttt{{translate.py}} supplies both forward and reverse proof compilers.
The preserved original source, provenance, and inherited fixtures are in
\texttt{{validation/}}.  These are finite executable checks and original-kernel
proof replays, not a Lean or Rocq formalization of the general metatheorems.
"""
    (ROOT / "validation" / "validation_summary.tex").write_text(summary_tex)
    print(json.dumps({key: value for key, value in summary.items()
                      if not key.endswith("_names")}, indent=2))


if __name__ == "__main__":
    main()
