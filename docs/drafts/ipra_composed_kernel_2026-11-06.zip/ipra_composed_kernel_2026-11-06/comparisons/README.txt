FROZEN SOURCE COMPARISONS

The six plainly named Python files are the exact main checkers from all
six archives in ProveIt/docs/drafts at repository commit
39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75.

source_index.json records their archive Git-blob identity, archive SHA-256,
archive member path, pinned repository URL and exact source SHA-256.

embedded/ contains deduplicated source snapshots needed to reproduce the
supplied embedded comparison inventories. A snapshot is named by a prefix
of its SHA-256; its complete hash and original archive/member path are in
the index. There are 81 distinct frozen source files in total, including
the six main files. Their 230 inventory entries correspond to 74 distinct
source sets. Renamed multi-file snapshots are measured as source groups;
the original import/module filenames remain recorded for reconstruction.

candidate_dictionary_envelope.py is a new matched control. It differs
from the delivered candidate only in the two statements that unpack and
validate its input envelope. measure.py verifies that exact source edit.

Run `python3 measure.py` from the archive root (or supply its full path).
It uses only the Python standard library, reads these snapshots without
importing or executing them, checks every hash, and regenerates:

  validation/source_metrics.json
  validation/embedded_inventory_audit.json
  validation/comparison_table.tex

All fixed axiom data and trusted local modules listed by a supplied
inventory are counted. Python and its standard library are the common
runtime. Historical inventory groups can include API-only and positive
cores; the audit retains their stated boundaries and does not assert
that every such group is a full ordinary public theory. None lowers the
coordinate envelope already attained by the six current main checkers.
