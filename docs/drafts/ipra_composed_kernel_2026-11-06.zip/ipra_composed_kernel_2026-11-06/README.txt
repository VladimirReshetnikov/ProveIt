A COMPOSED SMALL CHECKER FOR iPRA
6 November 2026
===============================

RESULT

This archive gives a complete axiomatization of full first-order
intuitionistic primitive recursive arithmetic, with whole-domain
bi-interpretations and internal identity round trips. It includes all
logical and nonlogical rules and schemas, plus a standalone proof checker.

The complete checker is 3,504 source bytes, 3,141 normalized bytes,
957 significant Python tokens and 1,013 executable AST nodes. The
coordinate minima among the six current draft implementations are
3,817 bytes, 3,486 normalized bytes, 1,089 tokens and 1,154 nodes.
These counts include validation, substitution, schema generation,
falsity conversion and the JSON command-line interface. They are
implementation comparisons, not a proof of absolute minimality.

SOURCE SNAPSHOT

VladimirReshetnikov/ProveIt, docs/drafts, commit:
39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75

https://github.com/VladimirReshetnikov/ProveIt/tree/39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75/docs/drafts

The six current archives are dated 2026-11-06 and named:
ipra_arithmetic_falsity, ipra_checked_presentation, ipra_premise_kernel,
ipra_shared_eliminator, ipra_universal_kernel and ipra_witness_kernel.
The construction integrates their compatible improvements. Provenance
and exact copied comparator sources are included. No repository changes
are required to use this archive.

START HERE

report.pdf        Complete mathematical report and program listing.
report.tex        Main LaTeX source; includes sections/ and validation/*.tex.
checker.py        Entire trusted acceptance program; only json/sys imports.
translate.py      Untrusted forward and reverse certificate compilers.
validate.py       Executable validation and original-checker proof replay.
measure.py        Offline source counts and source-hash verification.
build.py          Two-pass PDF compilation using pdflatex.
AUDIT.txt         Independent implementation audit and boundary reasoning.
certificates/     Accepted examples and deliberate rejection examples.
validation/       Original checker, inherited fixtures and generated results.
comparisons/      Exact principal and embedded source snapshots and index.
SHA256SUMS.txt    Digests of archive contents (excluding this digest file).

REPRODUCTION

Python 3.10+ is needed for structural pattern matching. Measurements here
were run with Python 3.12.14; ast.unparse formatting can differ by version.
The scripts use only the Python standard library.

From the extracted archive directory:

  python3 checker.py certificates/identity.json
  python3 validate.py
  python3 validation/audit_boundary.py
  python3 measure.py
  python3 build.py

The PDF build requires a working pdflatex installation with common
TeX Live/MiKTeX packages: lmodern, amsmath, amssymb, amsthm, mathtools,
geometry, booktabs, longtable, tabularx, microtype, xcolor, fancyhdr,
enumitem, needspace, listings and hyperref. No external network is used.
Run the two validation commands before recompilation if regenerating
their report fragments. The delivered PDF is already compiled.

CERTIFICATE CONTRACT

Input is a finite JSON triple: [assumptions, goal, proof]. Assumptions are
a list of formulas; a nonempty context certifies a sequent, not a theorem.
The number -1 denotes zero, while nonnegative exact integer indices denote
number variables. Other term constructors are ["s",t] and ["r",n,a,h].
The recursion body binds previous state index 0 and counter index 1.
Formulas are ["=",s,t], ["false"], ["pi",A,B], or ["sig",A,B].
Both logical binders bind index 0 in both children. The report describes
the six proof records completely.

Surface falsity is genuine falsity in the specified theory, with an
explicit nonlogical conversion bottom <-> 0=S0. Canonicalization is part
of checker.py. The bare positive reduct without that bridge is not the
ordinary theory claimed to be bi-interpretable with iPRA.

VALIDATION STATUS

254 candidate derivations pass, and all 254 expand into proofs accepted
by the preserved original checker. The suite rejects 46 adversarial
candidate inputs and 30 invalid source inputs before translation, and
performs 246 command-line checks in normal and optimized Python modes.
The independent boundary audit supplies additional adversarial checks;
its exact results are in validation/boundary_audit_results.json.

The broader size audit resolves 230 supplied inventory configurations,
representing 74 distinct source sets and 81 distinct Python files.
No listed configuration lowers the six-main coordinate minima.

The report supplies general mathematical proofs. These finite executions
are not a Lean/Rocq formalization of checker soundness or bi-interpretability.
Proof generators, translators, tests, and comparison scripts are outside
the trusted acceptance program.

FURTHER RESEARCH

The report includes further research questions concerning smaller rule
bases, formal checker verification, explicit substitutions, alternative
finitary domains, and cross-language implementation comparisons.
