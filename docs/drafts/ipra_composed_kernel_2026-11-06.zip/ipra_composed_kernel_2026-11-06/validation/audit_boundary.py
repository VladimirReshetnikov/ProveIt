"""Independent checks of the candidate's annotation-validation boundary.

The generic soundness argument is in AUDIT.txt. These finite checks target
Boolean/numeric aliases, premise-validated syntax, binding and JSON framing.
They do not formalize the metatheory or import any archived comparator.
"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("audited_candidate", ROOT / "checker.py")
K = importlib.util.module_from_spec(spec)
spec.loader.exec_module(K)
T = ["=", -1, -1]
R = ["r", -1, -1, -1]
REFL = ["use", ["rec", R], ["=", 0, -1], ["rec", R]]
ROWS = []
ALLOWED_FAILURES = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def expect(name, data, accepted):
    error = None
    try:
        actual = K.check(copy.deepcopy(data)) is True
    except ALLOWED_FAILURES as exc:
        actual = False
        error = type(exc).__name__
    if actual != accepted:
        raise AssertionError((name, "expected", accepted, "actual", actual))
    ROWS.append({"name": name, "expected_accept": accepted,
                 "actual_accept": actual, "exception": error})


def main():
    expect("base computation", [[], ["=", R, -1], ["rec", R]], True)
    expect("derived reflexivity", [[], T, REFL], True)
    A = ["=", 0, 0]
    pi_identity = ["pi", A, A]
    pi_proof = ["pi", A, ["hyp", A]]
    expect("Pi introduction", [[], pi_identity, pi_proof], True)
    expect("Pi use", [[], T, ["use", pi_proof, -1, REFL]], True)
    witness_equation = ["=", 0, -1]
    pair = ["pair", -1, ["hyp", witness_equation], ["hyp", witness_equation]]
    sig = ["sig", witness_equation, witness_equation]
    expect("witness-equation pair", [[], sig, pair], True)
    expect("Sigma use", [[], T, ["use", pair, T, REFL]], True)
    nat_equation = ["pi", ["sig", T,
        ["pi", A, ["=", ["s", 0], ["s", 0]]]], A]
    expect("equation induction schema", [[], nat_equation, ["nat", A]], True)
    P = ["pi", T, T]
    nat_cases = ["pi", ["sig", P, ["pi", P, P]], P]
    expect("compound-formula numerical cases", [[], nat_cases, ["nat", P]], True)
    expect("public falsity hypothesis", [[["false"]], ["false"],
                                         ["hyp", ["false"]]], True)

    canonical = ["=", 0, 1]
    for label, key in (("Boolean", ["=", False, True]),
                       ("float", ["=", 0.0, 1.0])):
        expect(label + " alias only in hypothesis key",
               [[canonical], canonical, ["hyp", key]], True)
        if K.infer(["hyp", key], [canonical]) is not canonical:
            raise AssertionError("Hypothesis lookup must return the stored entry")

    eq = ["=", 0, 1]
    template = ["pi", ["=", 0, 0], ["=", 1, 2]]
    before = ["pi", ["=", 0, 0], ["=", 1, 1]]
    after = ["pi", ["=", 0, 0], ["=", 2, 1]]
    expect("equality substitution under Pi", [[eq, before], after,
        ["use", ["hyp", eq], template, ["hyp", before]]], True)
    expect("reject capture under Pi", [[eq, before], before,
        ["use", ["hyp", eq], template, ["hyp", before]]], False)
    template = ["=", ["r", 0, -1, 2], 3]
    before = ["=", ["r", 0, -1, 2], 2]
    after = ["=", ["r", 1, -1, 3], 2]
    expect("equality substitution under recursion", [[eq, before], after,
        ["use", ["hyp", eq], template, ["hyp", before]]], True)
    sig_parameter = ["sig", ["=", 0, 1], ["=", 1, 1]]
    expect("Sigma result preserves old parameter", [[sig_parameter], A,
        ["use", ["hyp", sig_parameter], A, ["hyp", ["=", 1, 1]]]], True)
    expect("Sigma witness cannot escape", [[sig], witness_equation,
        ["use", ["hyp", sig], witness_equation, ["hyp", witness_equation]]], False)

    malformed = [
        False, True, 0.0, -1.0, None, "=", "pi", {}, [],
        ["="], ["=", -1], ["=", -1, -1, -1],
        ["=", False, -1], ["=", True, -1], ["=", 0.0, -1],
        ["=", -2, -1], ["pi", A, ["=", True, -1]],
        ["=", ["s", False], -1],
        ["=", ["r", -1, -1, False], -1],
        [["="], -1, -1], [False, -1, -1], ["=", ["false"], -1],
    ]
    sig_truth = ["sig", T, T]
    for i, annotation in enumerate(malformed):
        expect("invalid equality template " + str(i), [[T], T,
            ["use", ["hyp", T], annotation, ["hyp", T]]], False)
        expect("invalid Sigma conclusion " + str(i), [[sig_truth], T,
            ["use", ["hyp", sig_truth], annotation, ["hyp", T]]], False)

    for i, witness in enumerate((False, True, 0.0, -1.0, -2, "s", {}, ["z"])):
        expect("invalid Pi witness " + str(i), [[P, T], T,
            ["use", ["hyp", P], witness, ["hyp", T]]], False)
        expect("invalid pair witness " + str(i), [[], sig_truth,
            ["pair", witness, REFL, REFL]], False)

    for i, invalid_formula in enumerate((["=", False, 0], ["=", 0.0, 0],
                                         ["=", -2, -1], ["=", -1])):
        expect("invalid assumption " + str(i), [[invalid_formula], T, REFL], False)
        expect("invalid goal " + str(i), [[], invalid_formula, REFL], False)
        expect("invalid Pi guard " + str(i), [[], P,
            ["pi", invalid_formula, REFL]], False)
        expect("invalid numerical matrix " + str(i), [[], P,
            ["nat", invalid_formula]], False)

    roots = (None, False, 0, 0.0, "abc", {},
             {"a": [], "b": T, "c": REFL}, [], [[], T],
             [[], T, REFL, None], ["false"])
    for i, data in enumerate(roots):
        expect("invalid JSON envelope " + str(i), data, False)
    expect("unproved falsity", [[], ["false"], ["hyp", ["false"]]], False)
    expect("unknown proof record", [[], T, ["refl", -1]], False)
    expect("Boolean recursion body", [[], T, ["rec", ["r", -1, -1, False]]], False)
    expect("wrong successor recursion result", [[], T,
        ["rec", ["r", ["s", -1], -1, ["s", 0]]]], False)

    cli = []
    cli_cases = (
        ("reflexivity", [[], T, REFL], True),
        ("canonical Boolean key", [[canonical], canonical,
                                    ["hyp", ["=", False, True]]], True),
        ("Boolean template", [[T], T,
            ["use", ["hyp", T], ["=", False, -1], ["hyp", T]]], False),
        ("dictionary root", {"a": [], "b": T, "c": REFL}, False),
        ("closed falsity", [[], ["false"], ["hyp", ["false"]]], False),
    )
    with tempfile.TemporaryDirectory(prefix="ipra_boundary_") as directory:
        for optimized in (False, True):
            for label, data, accepted in cli_cases:
                path = Path(directory) / "certificate.json"
                path.write_text(json.dumps(data))
                command = [sys.executable, *(["-O"] if optimized else []),
                           str(ROOT / "checker.py"), str(path)]
                result = subprocess.run(command, capture_output=True, text=True, timeout=15)
                expected_text = "ACCEPT" if accepted else "REJECT"
                if result.returncode != (0 if accepted else 1) or result.stdout.strip() != expected_text:
                    raise AssertionError((label, optimized, result.returncode,
                                          result.stdout, result.stderr))
                cli.append({"name": label, "optimized_python": optimized,
                            "expected_accept": accepted, "exit_code": result.returncode,
                            "stdout": result.stdout.strip()})
    output = {
        "candidate_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
        "api_cases": len(ROWS),
        "api_acceptances": sum(row["actual_accept"] for row in ROWS),
        "api_rejections": sum(not row["actual_accept"] for row in ROWS),
        "canonical_hypothesis_object_identity_checks": 2,
        "cli_cases": len(cli), "all_passed": True,
        "scope": "Targeted finite boundary regression checks; see AUDIT.txt for the structural soundness argument.",
        "results": ROWS, "cli_results": cli,
    }
    (ROOT / "validation/boundary_audit_results.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({key: value for key, value in output.items()
                      if key not in ("results", "cli_results")}, indent=2))


if __name__ == "__main__":
    main()
