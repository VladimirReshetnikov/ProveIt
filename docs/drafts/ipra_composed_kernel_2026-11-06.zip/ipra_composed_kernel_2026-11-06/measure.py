"""Reproduce complete-source size comparisons without importing any checker.

Run `python3 measure.py` from any working directory. All comparator sources
are frozen in this archive and every recorded SHA-256 is verified first.
"""

import ast
import hashlib
import io
import json
import platform
from pathlib import Path
import tokenize


ROOT = Path(__file__).resolve().parent
AXES = (
    "raw_utf8_bytes", "normalized_utf8_bytes",
    "normalized_python_tokens", "ast_nodes_without_docstrings",
)


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    ignored = {
        tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
        tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
    }
    original_tokens = [
        t for t in tokenize.generate_tokens(io.StringIO(source).readline)
        if t.type not in ignored
        and not any(lo <= t.start and t.end <= hi for lo, hi in spans)
    ]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    normalized_tokens = [
        t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
        if t.type not in ignored
    ]
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "raw_utf8_bytes": len(data),
        "normalized_utf8_bytes": len(normalized.encode("utf-8")),
        "significant_source_tokens": len(original_tokens),
        "normalized_python_tokens": len(normalized_tokens),
        "ast_nodes_without_docstrings": sum(1 for _ in ast.walk(tree)),
        "raw_physical_lines": len(source.splitlines()),
        "normalized_physical_lines": len(normalized.splitlines()),
    }


def minima(rows):
    return {
        key: {
            "value": min(row["metrics"][key] for row in rows),
            "attained_by": [row["id"] for row in rows
                            if row["metrics"][key]
                            == min(r["metrics"][key] for r in rows)],
        }
        for key in AXES
    }


def difference(before, after):
    return {
        key: {
            "absolute": before[key] - after[key],
            "percent": round(100 * (before[key] - after[key]) / before[key], 6),
        }
        for key in AXES
    }


def table_row(label, metrics):
    return label + " & " + " & ".join(
        f"{metrics[key]:,}" for key in AXES) + r" \\"


def main():
    index_path = ROOT / "comparisons/source_index.json"
    index = json.loads(index_path.read_text())
    cache = {}
    for record in index["source_snapshots"]:
        path = ROOT / record["snapshot_path"]
        result = measure(path)
        if result["sha256"] != record["sha256"]:
            raise ValueError("Comparator hash mismatch: " + record["snapshot_path"])
        cache[record["sha256"]] = result
    principal = [dict(record, metrics=cache[record["sha256"]])
                 for record in index["main_checkers"]]
    candidate = measure(ROOT / "checker.py")
    candidate_row = {"id": "candidate", "label": "Candidate: array envelope",
                     "snapshot_path": "checker.py", "metrics": candidate}
    ablation_record = index["dictionary_envelope_ablation"]
    ablation_path = ROOT / ablation_record["snapshot_path"]
    ablation = measure(ablation_path)
    if ablation["sha256"] != ablation_record["sha256"]:
        raise ValueError("Dictionary-envelope ablation hash mismatch")
    old = "    g, a, p = erase(data)\n"
    new = ('    require(type(data) is dict and set(data) == '
           '{"assumptions", "goal", "proof"})\n'
           '    g, a, p = map(erase, (data["assumptions"], '
           'data["goal"], data["proof"]))\n')
    candidate_source = (ROOT / "checker.py").read_text()
    if (candidate_source.count(old) != 1
            or candidate_source.replace(old, new, 1) != ablation_path.read_text()):
        raise ValueError("The control differs by more than the certificate envelope")
    ablation_row = {"id": "dictionary_envelope_control",
                    "label": "Same kernel: dictionary envelope",
                    "snapshot_path": ablation_record["snapshot_path"],
                    "metrics": ablation}

    groups = []
    for number, group in enumerate(index["embedded_groups"]):
        totals = {key: sum(cache[f["sha256"]][key] for f in group["files"])
                  for key in AXES}
        groups.append({**group, "inventory_id": group["id"],
                       "id": "inventory_" + str(number), "metrics": totals})
    envelope = minima(principal)
    expanded_envelope = minima(groups)
    envelope_values = {key: envelope[key]["value"] for key in AXES}
    expanded_values = {key: expanded_envelope[key]["value"] for key in AXES}
    method = (
        "Complete checker source, including validation, binding operations, axiom "
        "construction, input conversion, imports and JSON/CLI. Python and standard "
        "library are the common runtime. Remove only module/function/class "
        "docstrings, then ast.unparse plus one final newline; normalized tokens "
        "exclude comments and layout. Sum every source explicitly listed in a "
        "supplied inventory group; duplicate inventory groups are retained. "
        "No checker or comparator is imported or executed by this program."
    )
    output = ROOT / "validation"
    output.mkdir(exist_ok=True)
    audit = {
        "method": method, "python_version": platform.python_version(),
        "repository_commit": index["repository_commit"],
        "inventory_group_count": len(groups),
        "unique_source_set_count": len({tuple(sorted(f["sha256"] for f in g["files"]))
                                        for g in groups}),
        "unique_source_file_count": len(cache),
        "all_recorded_source_hashes_verified": True,
        "minima": expanded_envelope,
        "no_embedded_group_below_main_coordinate_envelope": expanded_values == envelope_values,
        "qualification": (
            "This broader check verifies source hashes and source sizes for supplied "
            "inventory groups; it does not independently prove every historical "
            "comparator sound. API-only or positive-core groups are not silently "
            "declared to be full public theories. All such groups are at or above "
            "the current-main coordinate envelope."
        ),
        "groups": groups,
    }
    (output / "embedded_inventory_audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    result = {
        "method": method, "python_version": platform.python_version(),
        "repository": index["repository"],
        "repository_commit": index["repository_commit"],
        "source_index_sha256": hashlib.sha256(index_path.read_bytes()).hexdigest(),
        "main_checkers": principal, "candidate": candidate_row,
        "dictionary_envelope_ablation": ablation_row,
        "main_coordinate_minima": envelope,
        "expanded_inventory_coordinate_minima": expanded_envelope,
        "expanded_inventory_group_count": len(groups),
        "expanded_inventory_unique_source_sets": audit["unique_source_set_count"],
        "expanded_inventory_unique_source_files": len(cache),
        "candidate_savings_against_coordinate_minima": difference(envelope_values, candidate),
        "dictionary_envelope_control_savings_against_minima": difference(envelope_values, ablation),
        "array_envelope_only_savings": difference(ablation, candidate),
        "candidate_strictly_below_every_main_coordinate": all(candidate[k] < envelope_values[k]
                                                              for k in AXES),
        "candidate_strictly_below_every_expanded_coordinate": all(candidate[k] < expanded_values[k]
                                                                  for k in AXES),
        "all_recorded_source_hashes_verified": True,
        "dictionary_control_is_exact_interface_ablation": True,
        "limitations": (
            "Implementation-relative attained minima, not a theorem of absolute "
            "program-size optimality. Coordinate minima can come from different "
            "programs. This source counter establishes neither checker soundness "
            "nor proof-length or runtime improvements."
        ),
    }
    (output / "source_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = [r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
             r"Implementation & Source bytes & Norm. bytes & Tokens & AST nodes \\",
             r"\midrule"]
    lines.extend(table_row(row["label"], row["metrics"]) for row in principal)
    lines += [r"\midrule", table_row("Coordinate minima", envelope_values),
              table_row(ablation_row["label"], ablation),
              table_row(candidate_row["label"], candidate), r"\bottomrule", r"\end{tabular}"]
    (output / "comparison_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps({
        "candidate": candidate,
        "coordinate_minima": envelope_values,
        "dictionary_envelope_control": ablation,
        "supplied_inventory_groups": len(groups),
        "unique_supplied_source_sets": audit["unique_source_set_count"],
        "all_hashes_verified": True,
    }, indent=2))


if __name__ == "__main__":
    main()
