"""Compile report.tex twice using an installed LaTeX distribution."""

from pathlib import Path
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("Install pdflatex (TeX Live or MiKTeX) to compile the report.")
    tex_env = os.environ.copy()
    locator = shutil.which("kpsewhich")
    if locator and not subprocess.run([locator, "pdflatex.fmt"],
                                      capture_output=True, text=True).stdout.strip():
        # Some minimal distributions install the sources but omit formats.
        # Initialize a local cache; no system configuration is changed.
        cache = ROOT / ".build"
        cache.mkdir(exist_ok=True)
        initializer = shutil.which("pdftex")
        if initializer is None:
            raise SystemExit("pdflatex.fmt is missing; initialize the TeX installation.")
        if not (cache / "pdflatex.fmt").exists():
            initialize = [initializer, "-ini", "-etex", "-no-shell-escape",
                          "-interaction=nonstopmode", "-halt-on-error",
                          "-jobname=pdflatex", "-progname=pdflatex", "pdflatex.ini"]
            result = subprocess.run(initialize, cwd=cache, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if result.returncode:
                print(result.stdout)
                raise SystemExit(result.returncode)
        tex_env["TEXFORMATS"] = str(cache) + os.pathsep + tex_env.get("TEXFORMATS", "")
    command = [engine, "-no-shell-escape", "-interaction=nonstopmode",
               "-halt-on-error", "report.tex"]
    for _ in range(2):
        result = subprocess.run(command, cwd=ROOT, env=tex_env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        if result.returncode:
            print(result.stdout)
            raise SystemExit(result.returncode)
    print("Compiled report.pdf")


if __name__ == "__main__":
    main()
