#!/usr/bin/env python3
"""Compile the standalone paper with shell escape disabled."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STEM = "ipra_adjacent_symmetry_2026-11-09"


def main():
    log = ROOT / "evidence" / "latex_build.txt"
    with log.open("w") as stream:
        for run in range(2):
            process = subprocess.run(
                ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
                 "-halt-on-error", STEM + ".tex"],
                cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
            if process.returncode:
                print("LaTeX build failed; see " + str(log), file=sys.stderr)
                return process.returncode
    lines = (ROOT / (STEM + ".log")).read_text(errors="replace").splitlines()
    warnings = [line for line in lines
                if "Overfull" in line or "Warning:" in line or "undefined" in line.lower()]
    result = {"pdf": STEM + ".pdf", "bytes": (ROOT / (STEM + ".pdf")).stat().st_size,
              "warnings": warnings, "shell_escape": False, "passes": 2}
    (ROOT / "evidence" / "document_build.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
