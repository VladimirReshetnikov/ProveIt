#!/usr/bin/env python3
"""Independently check the four expanded reflection/latch certificates.

The expected conclusions and targeted corruptions below do not import the
producer. Every corrupted node exercises a required rule, scope, arity, or
matching gate; arbitrary mutations which could remain valid are avoided.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / "code" / "checker.py"
Z = ["0"]
O = ["S", Z]
PRED = ["rec", ["zero", 0], ["proj", 2, 0]]
COND = ["rec", ["proj", 2, 0], ["proj", 4, 3]]
SIGN = ["rec", ["zero", 0], ["comp", 2, ["succ"], [["zero", 2]]]]
SUB = ["rec", ["proj", 1, 0], ["comp", 3, PRED, [["proj", 3, 1]]]]


def v(x):
    return ["v", x]


def s(t):
    return ["S", t]


def app(d, *args):
    return ["app", d, list(args)]


def eq(a, b):
    return ["eq", a, b]


def imp(a, b):
    return ["imp", a, b]


def sign(t):
    return app(SIGN, t)


def probe(a, b):
    return sign(app(SUB, a, b))


def forall(names, body):
    for name in reversed(names):
        body = ["all", name, body]
    return body


def expected_goal(name):
    if name == "probe_reflection":
        a, b = v("a"), v("b")
        return forall(["a", "b"], imp(eq(probe(a, b), probe(b, a)), eq(a, b)))
    if name == "latch_probe":
        parameters = ["a"]
        b = lambda n: probe(n, v("a"))
    elif name == "latch_identity":
        parameters = []
        b = lambda n: n
    elif name == "latch_composite":
        parameters = ["a", "b"]
        b = lambda n: app(COND, sign(n), v("a"), v("b"))
    else:
        raise RuntimeError("Unknown certificate name")
    n = v("n")
    boolean_range = forall(["n"], ["or", eq(b(n), Z), eq(b(n), O)])
    base = eq(b(Z), Z)
    progress = forall(["n"], imp(eq(b(n), Z), eq(b(s(n)), Z)))
    return forall([*parameters, "t"], imp(boolean_range, imp(base, imp(progress, eq(b(v("t")), Z)))))


def nodes(proof, path=("proof",)):
    yield path, proof
    for index, child in enumerate(proof["premises"]):
        yield from nodes(child, path + ("premises", index))


def at_path(packet, path):
    result = packet
    for key in path:
        result = result[key]
    return result


def changes(packet):
    """Return descriptive, deterministic mutations at at least 20 distinct nodes."""
    all_nodes = list(nodes(packet["proof"]))
    by_rule = {}
    for path, node in all_nodes:
        by_rule.setdefault(node["rule"], []).append((path, node))
    outer_name = packet["proof"]["var"]
    missing_name = "__not_in_certificate_scope__"
    while missing_name in json.dumps(packet):
        missing_name += "_"
    alterations = []
    as_path, as_node = by_rule["AS"][0]
    alterations.extend([
        ("AS_wrong_guard", as_path, "premises", [{"rule": "refl", "term": Z, "premises": []}]),
        ("AS_guard_has_wrong_connective", as_path, "premises", [{
            "rule": "or_i", "side": 0, "other": eq(Z, Z), "premises": as_node["premises"]}]),
        ("AS_nonfresh_variable", as_path, "var", outer_name),
        ("AS_target_escape", as_path, "at", v(as_node["var"])),
        ("AS_changed_template", as_path, "template", Z),
        ("AS_extra_premise", as_path, "premises", as_node["premises"] * 2),
        ("AS_missing_premise", as_path, "premises", []),
        ("AS_invented_anchor", as_path, "anchor", O),
    ])
    for index, (path, node) in enumerate(by_rule.get("compute", [])[:8]):
        if index % 3 == 0:
            key, value = "arguments", node["arguments"] + [Z]
        elif index % 3 == 1:
            key, value = "description", ["zero", -1]
        else:
            key, value = "arguments", "not_an_argument_array"
        alterations.append(("compute_gate_" + str(index), path, key, value))
    for index, (path, _) in enumerate(by_rule.get("hyp", [])[:6]):
        value = (-1, True, 10**9)[index % 3]
        alterations.append(("hypothesis_index_" + str(index), path, "index", value))
    for index, (path, node) in enumerate(by_rule.get("transport", [])[:8]):
        if index % 3 == 0:
            key, value = "var", outer_name
        elif index % 3 == 1:
            key, value = "body", ["eq", Z]
        else:
            key, value = "premises", node["premises"][:1]
        alterations.append(("transport_gate_" + str(index), path, key, value))
    refl_path, _ = by_rule["refl"][0]
    alterations.append(("unbound_reflexivity_term", refl_path, "term", v(missing_name)))
    br_path, _ = by_rule["BR"][0]
    alterations.append(("unbound_BR_term", br_path, "term", v(missing_name)))
    if len({tuple(change[1]) for change in alterations}) < 20:
        raise RuntimeError("Insufficient distinct corrupted proof nodes")
    return alterations


def public_run(data, optimized):
    process = subprocess.run([sys.executable, *(["-O"] if optimized else []), str(CHECKER)],
        input=json.dumps(data), text=True, capture_output=True, timeout=30)
    accepted = process.returncode == 0 and process.stdout == "ACCEPT\n" and not process.stderr
    rejected = process.returncode == 1 and not process.stdout and process.stderr.startswith("REJECT:")
    return accepted, rejected


def main():
    spec = importlib.util.spec_from_file_location("AS_checker_for_certificates", CHECKER)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    failures, receipts = [], []
    total_mutations = total_cli = 0
    for name in ("probe_reflection", "latch_probe", "latch_identity", "latch_composite"):
        path = ROOT / "certificates" / (name + ".json")
        raw = path.read_bytes()
        packet = json.loads(raw)
        goal_matches = packet["goal"] == expected_goal(name)
        if not goal_matches:
            failures.append(name + ": unexpected theorem statement")
        if checker.verify(packet) is not True:
            failures.append(name + ": positive API failure")
        positives = []
        for optimized in (False, True):
            accepted, _ = public_run(packet, optimized)
            positives.append({"optimized": optimized, "passed": accepted})
            total_cli += 1
            if not accepted:
                failures.append(name + ": positive CLI failure")
        proof_nodes = list(nodes(packet["proof"]))
        counts = {}
        for _, node in proof_nodes:
            counts[node["rule"]] = counts.get(node["rule"], 0) + 1
        if counts.get("AS") != 1:
            failures.append(name + ": expected exactly one AS node")
        if name == "probe_reflection" and "Sep" in counts:
            failures.append(name + ": reflection unexpectedly used separation")
        mutations = []
        edits = changes(packet)
        for label, edit_path, key, value in edits:
            altered = copy.deepcopy(packet)
            at_path(altered, edit_path)[key] = copy.deepcopy(value)
            try:
                checker.verify(altered)
                api_rejects = False
            except Exception:
                api_rejects = True
            public = []
            for optimized in (False, True):
                _, rejected = public_run(altered, optimized)
                total_cli += 1
                public.append({"optimized": optimized, "passed": rejected})
                if not rejected:
                    failures.append(name + ": mutant CLI accepted " + label)
            if not api_rejects:
                failures.append(name + ": mutant API accepted " + label)
            mutations.append({"label": label, "node_path": list(edit_path), "field": key,
                              "api_rejected": api_rejects, "cli": public})
            total_mutations += 1
        receipts.append({
            "file": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw), "proof_nodes": len(proof_nodes), "rules": counts,
            "goal_matches_independent_construction": goal_matches, "positive_cli": positives,
            "corruptions": len(edits), "distinct_corrupted_proof_nodes": len({tuple(e[1]) for e in edits}),
            "mutation_receipts": mutations,
        })
    result = {
        "python": platform.python_version(), "checker_sha256": hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
        "certificates": receipts, "accepted_certificates": len(receipts),
        "targeted_corruptions": total_mutations, "public_cli_runs": total_cli,
        "failures": failures,
        "scope": "Expanded reflection derivation and three instantiated latch derivations in the complete AS checker. The uniform metatheorem and the full bi-interpretability argument are written proofs, not certified by these finite files.",
    }
    (ROOT / "evidence" / "certificate_validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "certificates"}, indent=2))
    for entry in receipts:
        print(entry["file"], entry["proof_nodes"], "nodes;", entry["corruptions"], "corruptions;",
              entry["distinct_corrupted_proof_nodes"], "distinct nodes")
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
