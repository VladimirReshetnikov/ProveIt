#!/usr/bin/env python3
"""Remeasure frozen complete native comparators and the complete AS checker.

All measurements charge the entire Python module, including the JSON parser
entry, verdict handling, imports, and fixed term descriptions. The normalizer
is copied unchanged from the corpus. This audit does not certify all inherited
mathematical proofs or turn a finite implementation envelope into a lower bound.
"""
import ast
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parents[1]
KEYS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def measure_name_control(module):
    path = ROOT / "reference" / "native_checkers" / "compact_open.py"
    tree = module.StripDocstrings().visit(ast.parse(path.read_text()))
    renaming = {"inst": "i", "check": "c", "take": "q"}
    names = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)}
    names |= {n.arg for n in ast.walk(tree) if isinstance(n, ast.arg)}
    names |= {n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)}
    if names.intersection(renaming.values()):
        raise RuntimeError("Name-control collision")

    class Rename(ast.NodeTransformer):
        def visit_Name(self, node):
            node.id = renaming.get(node.id, node.id)
            return node

        def visit_FunctionDef(self, node):
            self.generic_visit(node)
            node.name = renaming.get(node.name, node.name)
            return node

    tree = ast.fix_missing_locations(Rename().visit(tree))
    text = ast.unparse(tree) + "\n"
    return {"source": str(path.relative_to(ROOT)), "renaming": renaming,
            "normalized_tokens": module.significant(text),
            "ast_nodes": sum(1 for _ in ast.walk(tree)),
            "normalized_bytes": len(text.encode("utf-8")),
            "scope": "Historical naming control; not a source file newly supplied in this corpus."}


def main():
    manifest = json.loads((ROOT / "reference" / "native_comparators.json").read_text())
    normalizer = ROOT / "code" / "source_measure.py"
    if digest(normalizer) != manifest["normalizer_sha256"]:
        raise RuntimeError("Changed frozen source normalizer")
    spec = importlib.util.spec_from_file_location("frozen_measure", normalizer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for entry in manifest["programs"]:
        path = ROOT / entry["file"]
        if digest(path) != entry["sha256"]:
            raise RuntimeError("Changed frozen comparator: " + entry["file"])
        measured = module.metrics(path)
        measured.pop("core")
        rows.append({"file": entry["file"], "profile": entry["profile"], **measured})
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    total = [row for row in rows if row["profile"] != "runtime-qualified iterable aliases"]
    total_minimum = {key: min(row[key] for row in total) for key in KEYS}
    candidate = module.metrics(ROOT / "code" / "checker.py")
    candidate.pop("core")
    raw_reset = module.metrics(ROOT / "reference" / "raw_reset_checker.py")
    raw_reset.pop("core")
    inventory = json.loads((ROOT / "evidence" / "source_inventory.json").read_text())
    accepted_hashes = {entry["sha256"] for entry in manifest["programs"]}
    excluded = {}
    for row in inventory["source_files"]:
        if (row["sha256"] not in accepted_hashes
                and any(row[key] < minimum[key] for key in KEYS)):
            name = Path(row["source_path"]).name
            if not (name.startswith(("build", "measure", "reproduce", "package"))):
                raise RuntimeError("Unclassified small source: " + row["source_path"])
            excluded.setdefault(row["sha256"], {**row,
                "reason": "Build, packaging, measurement, or reproduction driver; not a complete proof checker."})
    result = {
        "repository": manifest["repository"], "commit": manifest["commit"],
        "archive_count": manifest["archive_count"], "python": platform.python_version(),
        "python_sources_scanned": len(inventory["source_files"]),
        "complete_native_comparators": len(rows),
        "normalizer_sha256": manifest["normalizer_sha256"],
        "whole_source_boundary": "Entire module; genuine docstrings and comments removed; no acceptance code, parser, driver, or fixed data excluded.",
        "corpus_minimum": minimum,
        "minimum_attainers": {key: [row["file"] for row in rows if row[key] == minimum[key]] for key in KEYS},
        "minimum_excluding_runtime_qualified_iterable_variant": total_minimum,
        "candidate": candidate,
        "candidate_strictly_below_corpus_minimum": {key: candidate[key] < minimum[key] for key in KEYS},
        "matched_raw_reset_baseline": raw_reset,
        "raw_reset_minus_AS": {key: raw_reset[key] - candidate[key] for key in KEYS},
        "historical_uniform_name_control": measure_name_control(module),
        "excluded_smaller_infrastructure": list(excluded.values()),
        "programs": sorted(rows, key=lambda row: tuple(row[key] for key in KEYS)),
        "limitation": "This measures the pinned source inventory and relies on the stated role of inherited complete checkers. It is not an absolute lower bound, an independent formal proof of all inherited metatheory, or a claim of matching malformed-input languages across every historical variant.",
    }
    evidence = ROOT / "evidence"
    (evidence / "frontier_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    fields = ("file", "profile", "source_tokens", *KEYS, "raw_bytes", "sha256")
    with (evidence / "frontier_metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        writer.writerows(result["programs"])
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("programs", "excluded_smaller_infrastructure")}, indent=2))


if __name__ == "__main__":
    main()
