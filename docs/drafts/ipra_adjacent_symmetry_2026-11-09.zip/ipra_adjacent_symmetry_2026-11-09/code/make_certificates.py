#!/usr/bin/env python3
"""Untrusted proof producer for the complete adjacent-symmetry checker.

No checker, evaluator, theorem table, or proof library is imported. All
arithmetic reductions below emit actual defining-equation and transport
nodes. Named local hypotheses are compiled to checked context indices.
"""
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
Z = ["0"]
O = ["S", Z]
PRED = ["rec", ["zero", 0], ["proj", 2, 0]]
COND = ["rec", ["proj", 2, 0], ["proj", 4, 3]]
SIGN = ["rec", ["zero", 0], ["comp", 2, ["succ"], [["zero", 2]]]]
SUB = ["rec", ["proj", 1, 0], ["comp", 3, PRED, [["proj", 3, 1]]]]
H = ["v", "_hole"]


def v(x): return ["v", x]
def s(t): return ["S", t]
def app(d, *ts): return ["app", d, list(ts)]
def eq(a, b): return ["eq", a, b]
def choose(t, a, b): return app(COND, t, a, b)
def sign(t): return app(SIGN, t)
def probe(a, b): return sign(app(SUB, a, b))
def disj(a, b): return ["or", a, b]
def implies(a, b): return ["imp", a, b]
def boolean(t): return disj(eq(t, Z), eq(t, O))


def node(rule, *ps, **fields):
    return {"rule": rule, **fields, "premises": list(ps)}


def hyp(label): return node("hyp_named", label=label)
def refl(t): return node("refl", term=t)
def assume(label, a, p): return node("imp_i", p, assume=a, _label=label)


def cases(major, llabel, left, rlabel, right):
    return node("or_e", major, left, right, _left_label=llabel, _right_label=rlabel)


def sub(t, name, image):
    if t[0] == "v": return image if t[1] == name else t
    if t[0] == "0": return t
    if t[0] == "S": return s(sub(t[1], name, image))
    return app(t[1], *(sub(a, name, image) for a in t[2]))


def fill(t, image): return sub(t, "_hole", image)


class Equation:
    def __init__(self, left, right, proof):
        self.left, self.right, self.proof = left, right, proof

    def then(self, other):
        if self.right != other.left:
            raise ValueError("Producer transitivity mismatch: " + repr((self.right, other.left)))
        if self.left == self.right and self.proof["rule"] == "refl": return other
        if other.left == other.right and other.proof["rule"] == "refl": return self
        p = node("transport", other.proof, self.proof,
                 var="_hole", body=eq(self.left, H))
        return Equation(self.left, other.right, p)

    def sym(self):
        p = node("transport", self.proof, refl(self.left),
                 var="_hole", body=eq(H, self.left))
        return Equation(self.right, self.left, p)

    def through(self, template):
        a, b = fill(template, self.left), fill(template, self.right)
        if self.left == self.right and self.proof["rule"] == "refl":
            return identity(a)
        p = node("transport", self.proof, refl(a),
                 var="_hole", body=eq(a, template))
        return Equation(a, b, p)


def identity(t): return Equation(t, t, refl(t))
def eh(label, a, b): return Equation(a, b, hyp(label))


def transport(p, e, body):
    return node("transport", e.proof, p, var="_hole", body=body)


def compute(t):
    d, args = t[1], t[2]
    tag = d[0]
    if tag == "zero": r = Z
    elif tag == "succ": r = s(args[0])
    elif tag == "proj": r = args[d[2]]
    elif tag == "comp": r = app(d[2], *(app(f, *args) for f in d[3]))
    elif args[0] == Z: r = app(d[1], *args[1:])
    elif args[0][0] == "S":
        n = args[0][1]
        r = app(d[2], n, app(d, n, *args[1:]), *args[1:])
    else: return identity(t)
    return Equation(t, r, node("compute", description=d, arguments=args))


def reduce_term(t, opaque=()):
    """Symbolically reduce exposed computations, recording every proof step."""
    if t in opaque or t[0] in ("v", "0"): return identity(t)
    result = identity(t)
    if t[0] == "S":
        return reduce_term(t[1], opaque).through(s(H))
    current = t
    for j, child in enumerate(t[2]):
        reduced = reduce_term(child, opaque)
        if reduced.left != reduced.right:
            args = current[2].copy()
            args[j] = H
            result = result.then(reduced.through(app(current[1], *args)))
            current = result.right
    head = compute(current)
    if head.left != head.right:
        result = result.then(head)
        result = result.then(reduce_term(head.right, opaque))
    return result


def generalize(names, p):
    for x in reversed(names): p = node("all_i", p, var=x)
    return p


def forall(names, a):
    for x in reversed(names): a = ["all", x, a]
    return a


def finalize(p, labels=()):
    if p["rule"] == "hyp_named":
        return node("hyp", index=len(labels) - 1 - labels[::-1].index(p["label"]))
    result = {k: copy.deepcopy(x) for k, x in p.items()
              if k != "premises" and not k.startswith("_")}
    if p["rule"] == "imp_i":
        contexts = [labels + (p["_label"],)]
    elif p["rule"] == "or_e":
        contexts = [labels, labels + (p["_left_label"],), labels + (p["_right_label"],)]
    else:
        contexts = [labels] * len(p["premises"])
    result["premises"] = [finalize(q, c) for q, c in zip(p["premises"], contexts)]
    return result


def save(name, goal, proof, description):
    p = {"goal": goal, "proof": finalize(proof)}
    path = ROOT / "certificates" / (name + ".json")
    path.write_text(json.dumps(p, separators=(",", ":")) + "\n")
    count = 0
    stack = [p["proof"]]
    rules = {}
    while stack:
        x = stack.pop(); count += 1
        rules[x["rule"]] = rules.get(x["rule"], 0) + 1
        stack.extend(x["premises"])
    return {"file": str(path.relative_to(ROOT)), "description": description,
            "proof_nodes": count, "rules": rules, "bytes": path.stat().st_size}


def probe_rewrite(a_eq, b_eq):
    return a_eq.through(probe(H, b_eq.left)).then(b_eq.through(probe(a_eq.right, H)))


def reflection_certificate():
    a, b, z = v("a"), v("b"), v("z")
    f = lambda x: choose(sign(x), b, a)
    fs = reduce_term(f(s(z)), opaque=(a, b))
    guard = eq(probe(a, b), probe(b, a))
    branches = []
    for bit, label in ((Z, "ramp0"), (O, "ramp1")):
        fn = eh(label, sign(z), bit).through(choose(H, b, a))
        fn = fn.then(reduce_term(fn.right))
        l = probe_rewrite(fs, fn)
        r = probe_rewrite(fn, fs)
        middle = eh("guard", probe(a, b), probe(b, a)) if bit == Z else identity(probe(a, a))
        branches.append(l.then(middle).then(r.sym()).proof)
    major = cases(node("BR", term=z), "ramp0", branches[0], "ramp1", branches[1])
    rule = Equation(f(O), f(Z), node("AS", major, var="z", template=f(z), at=O))
    conclusion = reduce_term(f(O)).sym().then(rule).then(reduce_term(f(Z)))
    p = generalize(["a", "b"], assume("guard", guard, conclusion.proof))
    goal = forall(["a", "b"], implies(guard, eq(a, b)))
    return save("probe_reflection", goal, p,
                "Whole-domain probe reflection. Only PRE, BR, equality logic and one AS application; no Sep or induction.")


def as_from_stationarity(template, x, at, step):
    """Derive an AS guard from a checked actual-equality step."""
    f = template
    fs = sub(f, x, s(v(x)))
    if (step.left, step.right) != (fs, f):
        raise ValueError("Wrong stationary step supplied to producer")
    left = step.through(probe(H, f))
    right = step.through(probe(f, H))
    guard = left.then(right.sym())
    p = node("AS", guard.proof, var=x, template=f, at=at)
    return Equation(sub(f, x, at), sub(f, x, Z), p)


def compile_description(t, names):
    k = len(names)
    if t[0] == "0": return ["zero", k]
    if t[0] == "v": return ["proj", k, names.index(t[1])]
    if t[0] == "S": return ["comp", k, ["succ"], [compile_description(t[1], names)]]
    return ["comp", k, t[1], [compile_description(a, names) for a in t[2]]]


def expand_compiled(t, names, arguments):
    """Prove compilation correct by finite structural proof expansion.

    Original function applications remain opaque; only the compiler's own
    projection/composition wrappers are reduced.
    """
    d = compile_description(t, names)
    result = compute(app(d, *arguments))
    if t[0] in ("v", "0"):
        return result
    children = [t[1]] if t[0] == "S" else t[2]
    outer = ["succ"] if t[0] == "S" else t[1]
    for j, child in enumerate(children):
        e = expand_compiled(child, names, arguments)
        args = result.right[2].copy()
        args[j] = H
        result = result.then(e.through(app(outer, *args)))
    if t[0] == "S": result = result.then(compute(result.right))
    return result


def latch_certificate(name, btemplate, parameters):
    """Uniform certificate schema for any supplied finite PR term b(n,p).

    Range, base and progress are actual discharged assumptions. The proof
    does not assume coverage, equality reflection or an induction rule.
    """
    bfun = lambda n: sub(btemplate, "n", n)
    params = [v(x) for x in parameters]
    step_template = choose(bfun(v("i")), sign(v("acc")), O)
    desc = ["rec", ["zero", len(params)],
            compile_description(step_template, ["i", "acc", *parameters])]
    L = lambda n: app(desc, n, *params)
    r = lambda n: L(s(n))
    n, z, t = v("n"), v("z"), v("t")
    range_assumption = ["all", "n", boolean(bfun(n))]
    base_assumption = eq(bfun(Z), Z)
    step_assumption = ["all", "n", implies(eq(bfun(n), Z), eq(bfun(s(n)), Z))]

    def br(n): return node("all_e", hyp("range"), term=n)

    def r_unfold(n):
        head = compute(r(n))
        expanded = expand_compiled(step_template, ["i", "acc", *parameters],
                                   [n, L(n), *params])
        return head.then(expanded)

    def r_at_bit(n, bit, label):
        result = r_unfold(n)
        expected = choose(bfun(n), sign(L(n)), O)
        if result.right != expected:
            raise ValueError("Latch computation compiler failed: " + repr(result.right))
        result = result.then(eh(label, bfun(n), bit).through(choose(H, sign(L(n)), O)))
        return result.then(reduce_term(result.right, opaque=(L(n),)))

    def r_boolean(n):
        zero_case = r_at_bit(n, Z, "b_for_range0")
        p0 = transport(node("BR", term=L(n)), zero_case.sym(), boolean(H))
        one_case = r_at_bit(n, O, "b_for_range1")
        p1 = node("or_i", one_case.proof, side=1, other=eq(r(n), Z))
        return cases(br(n), "b_for_range0", p0, "b_for_range1", p1)

    def extract_b(n, r_zero):
        r_one = r_at_bit(n, O, "b_extract1")
        impossible = r_zero.sym().then(r_one)
        contradiction = node("imp_e", node("Sep"), impossible.proof)
        right = node("bot_e", contradiction, **{"as": eq(bfun(n), Z)})
        return Equation(bfun(n), Z,
                        cases(br(n), "b_extract0", hyp("b_extract0"), "b_extract1", right))

    # Base of the successor tail r(n)=L(Sn).
    r0 = r_unfold(Z)
    ql0 = reduce_term(L(Z)).through(sign(H)).then(reduce_term(sign(Z)))
    r0 = r0.then(ql0.through(choose(bfun(Z), H, O)))
    r0 = r0.then(eh("base", bfun(Z), Z).through(choose(H, Z, O)))
    r0 = r0.then(reduce_term(r0.right))

    # Stationary successor under each of the two *proved* range cases of r.
    rz0 = eh("r0case", r(z), Z)
    bz0 = extract_b(z, rz0)
    bsz0 = Equation(bfun(s(z)), Z,
                   node("imp_e", node("all_e", hyp("progress"), term=z), bz0.proof))
    first = r_unfold(s(z))
    qzero = rz0.through(sign(H)).then(reduce_term(sign(Z)))
    first = first.then(qzero.through(choose(bfun(s(z)), H, O)))
    first = first.then(bsz0.through(choose(H, Z, O)))
    first = first.then(reduce_term(first.right)).then(rz0.sym())

    rz1 = eh("r1case", r(z), O)
    second = r_unfold(s(z))
    qone = rz1.through(sign(H)).then(reduce_term(sign(O)))
    second = second.then(qone.through(choose(bfun(s(z)), H, O)))
    eqs = []
    for bit, label in ((Z, "nextb0"), (O, "nextb1")):
        e = eh(label, bfun(s(z)), bit).through(choose(H, O, O))
        eqs.append(e.then(reduce_term(e.right)).proof)
    all_one = Equation(choose(bfun(s(z)), O, O), O,
                       cases(br(s(z)), "nextb0", eqs[0], "nextb1", eqs[1]))
    second = second.then(all_one).then(rz1.sym())
    actual_step = Equation(r(s(z)), r(z),
                           cases(r_boolean(z), "r0case", first.proof, "r1case", second.proof))
    rt0 = as_from_stationarity(r(z), "z", t, actual_step).then(r0)
    conclusion = extract_b(t, rt0)
    p = assume("range", range_assumption,
               assume("base", base_assumption,
                      assume("progress", step_assumption, conclusion.proof)))
    goal = implies(range_assumption, implies(base_assumption, implies(step_assumption, eq(bfun(t), Z))))
    return save(name, forall([*parameters, "t"], goal), generalize([*parameters, "t"], p),
                "Expanded successor-tail latch instance. Discharged hypotheses: Boolean range, zero base, zero-preserving step. No coverage or induction node.")


def main():
    (ROOT / "certificates").mkdir(exist_ok=True)
    rows = [reflection_certificate()]
    rows.append(latch_certificate("latch_probe", probe(v("n"), v("a")), ["a"]))
    rows.append(latch_certificate("latch_identity", v("n"), []))
    rows.append(latch_certificate("latch_composite", choose(sign(v("n")), v("a"), v("b")), ["a", "b"]))
    (ROOT / "evidence/certificate_inventory.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
