ADJACENT SYMMETRY FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
9 November 2026

READ THE STATUS FIRST
=====================
This package establishes a new, fully specified iPRA-equivalent presentation
relative to the inspected current ProveIt drafts. It does NOT establish the
requested complete checker below the full native corpus frontier, and does
not claim absolute simplestness or literature-wide historical priority.

The principal files are:
  ipra_adjacent_symmetry_2026-11-09.tex
  ipra_adjacent_symmetry_2026-11-09.pdf

THE MATHEMATICAL RESULT
======================
Use ordinary intuitionistic first-order equality logic, genuine falsity, and
the complete finite primitive-recursive description grammar and equations.

Fix descriptions
  P(0)=0,        P(Sn)=n
  C(0,a,b)=a,    C(Sn,a,b)=b
  q(0)=0,        q(Sn)=1
  T(0,b)=b,      T(Sa,b)=P(T(a,b))
and define u(a,b)=q(T(a,b)).

Add BR: forall n, q(n)=0 or q(n)=1, and Sep: (0=1) implies false.
The only additional rule is:

  Gamma |- u(f(Sz),f(z)) = u(f(z),f(Sz))
  ------------------------------------
  Gamma |- f(t) = f(0).

The same one finite term template f is used throughout. The eigenvariable z
is fresh for Gamma, t, and all passive parameters. All logical rules, arity
conditions and substitutions are explicitly specified in the paper.

A two-value ramp calibrates the observation: equal opposite observations
imply actual equality on the entire domain. A normalized successor-tail
latch recovers full contextual quantifier-free induction without assuming
numerical coverage. An independent stopped-clock proof validates the rule
inside iPRA using only quantifier-free induction. Consequently the theories
have identical sequents and literal identity bi-interpretations.
The target is the explicitly specified full quantifier-free-induction
first-order theory; no equivalence to a bare atomic-induction basis with
unstated boundary principles is assumed.

The paper also proves:
  * AS is exactly fixed probe antisymmetry plus zero stationarity.
  * Restricting AS to two-valued selector templates preserves the theory.
  * Neither BR nor Sep can simply be deleted from this displayed basis.

IMPLEMENTATION AND VERIFICATION
==============================
code/checker.py is the whole standalone acceptance program. It imports only
Python standard-library JSON/system interfaces. It has no induction oracle,
semantic evaluator, proof producer, or theorem database.
As with any concrete process, finite memory and Python's recursion limit
can reject or fail on sufficiently large valid certificates. Completeness
refers to the abstract recursive proof presentation with sufficient finite
resources for each input.

code/make_certificates.py is an untrusted producer of four fully expanded
proof trees in certificates/. The reflection proof has 198 inference nodes.
The latch instances have 762, 617, and 811 nodes. Every certificate has one AS
node. The reflection proof uses no Sep or induction.

code/validate_certificates.py independently reconstructs the theorem
statements and checks 127 targeted corruptions. code/test_checker.py covers
all 18 primitive rules, including malformed syntax and scope boundaries.
The final run had 450 public CLI executions in ordinary Python and python -O,
with zero failures. Exact receipts are in evidence/.

These finite files certify reflection and three latch instances. They do not
mechanize the uniform characteristic compiler, stopped-clock target proof,
or the full bi-interpretability theorem. Those are written proofs with
independent assistant review, not Lean/Rocq formalizations or external peer
review.

COMPLETE SOURCE MEASUREMENTS
===========================
The whole-module convention removes comments/genuine docstrings and uses
CPython 3.12 ast.unparse; all acceptance code and fixed data remain charged.

                                       tokens   AST    normalized bytes
  Matched complete raw-reset checker     3347    3539      13354
  Complete adjacent-symmetry checker     3242    3447      12919
  Matched savings                         105      92        435
  Current native coordinate envelope      305     340        820

Different native files attain the three coordinate minima. Excluding the
runtime-qualified iterable-alias checker changes the AST minimum to 341.
A historical uniform-name 816-byte control is separately disclosed.
These are finite implementation benchmarks, not mathematical lower bounds.

REPRODUCE
=========
From this extracted directory:
  python3 reproduce.py
  python3 build.py

The first command needs only Python's standard library. It regenerates the
four certificates, reruns both validation suites, and remeasures the frozen
comparators. The second needs pdfLaTeX and the packages in the paper's preamble;
it compiles twice with shell escape disabled.
After rebuilding, python3 package.py creates a ZIP beside this directory,
with SHA256SUMS covering all included payload files. It excludes TeX
intermediates and Python caches and verifies the resulting archive bytes.

To check one certificate directly:
  python3 code/checker.py < certificates/probe_reflection.json

Accepted input prints ACCEPT and returns exit status 0. Rejected input prints
REJECT to stderr and returns status 1.

PROVENANCE
==========
Pinned repository: VladimirReshetnikov/ProveIt
Commit: 195e4becb0a1f99c5598f7e39e2cdeb81461b2e4
All 17 top-level docs/drafts ZIPs were downloaded and Git-blob verified.
The audit inventories 482 extracted Python files and freezes 24 complete
native comparators. Complete artifact provenance is in evidence/provenance.json
and reference/native_comparators.json; exact measurements are in evidence/.

The ordinary checker infrastructure is adapted from the supplied raw-reset
implementation. The fixed observation and the AS rule replace its nested
reset. See ATTRIBUTION.txt and LICENSE.txt.

No repository write or publication was performed.
