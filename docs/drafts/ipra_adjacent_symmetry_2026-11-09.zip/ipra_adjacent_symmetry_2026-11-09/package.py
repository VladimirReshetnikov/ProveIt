#!/usr/bin/env python3
"""Package the current deliverables with a checked SHA-256 manifest.

Run build.py first if the paper changed, and reproduce.py if code changed.
The ZIP is placed beside this directory. TeX intermediates and caches are
excluded; existing deliverables and evidence are retained byte for byte.
"""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
ALLOWED = {".py", ".tex", ".pdf", ".json", ".txt", ".csv"}
MANIFEST = ROOT / "SHA256SUMS"


def main():
    paths = sorted(p for p in ROOT.rglob("*")
                   if p.is_file() and not p.is_symlink()
                   and "__pycache__" not in p.parts
                   and p.suffix in ALLOWED)
    entries = [(p.relative_to(ROOT).as_posix(), p.read_bytes()) for p in paths]
    manifest = "".join(hashlib.sha256(data).hexdigest() + "  " + name + "\n"
                       for name, data in entries)
    MANIFEST.write_text(manifest, encoding="utf-8")
    entries.append((MANIFEST.name, MANIFEST.read_bytes()))
    destination = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for name, data in sorted(entries):
            info = zipfile.ZipInfo(ROOT.name + "/" + name,
                                   date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError("ZIP integrity failure: " + bad)
        for name, data in entries:
            if archive.read(ROOT.name + "/" + name) != data:
                raise RuntimeError("ZIP content mismatch: " + name)
    print(destination)
    print("files:", len(entries))
    print("bytes:", destination.stat().st_size)
    print("sha256:", hashlib.sha256(destination.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
