#!/usr/bin/env python3
"""Reproduce all mathematical certificates, verifier tests, and source metrics."""
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SCRIPTS = ("make_certificates.py", "validate_certificates.py",
           "test_checker.py", "audit_frontier.py")


def main():
    receipts = []
    for name in SCRIPTS:
        process = subprocess.run(
            [sys.executable, str(ROOT / "code" / name)],
            cwd=ROOT, text=True, capture_output=True)
        (ROOT / "evidence" / ("reproduce_" + name[:-3] + ".txt")).write_text(
            process.stdout + process.stderr)
        receipts.append({"script": "code/" + name, "exit_code": process.returncode})
        print(name + ": " + ("PASS" if process.returncode == 0 else "FAIL"), flush=True)
        if process.returncode:
            print(process.stderr, file=sys.stderr)
            return 1
    result = {"python": platform.python_version(), "steps": receipts,
              "all_passed": True,
              "scope": "Certificate reproduction, complete-checker finite validation, and full-source measurements; not a formalization of all metatheory."}
    (ROOT / "evidence" / "reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
