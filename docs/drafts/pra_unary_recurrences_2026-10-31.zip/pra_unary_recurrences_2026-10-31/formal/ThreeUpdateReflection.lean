import ThreeUpdateDiagonal
import SuccessorReflection

/-
Complete finite-syntax linkage through native equality and equation induction.
Every resource of the generic reconstruction certificate is instantiated from
the exact three-update Model + PositiveSchema, with explicit finite Terms for
the single new zero-induction instance and the successor-uniqueness instance.
-/

namespace ThreeUpdateReflection

open FiniteUpdateKernel

universe u
variable {A : Type u} (C : Model A) (PU : PositiveSchema C)

def arithmetic : ThreeUpdates.SuccessorReflection.Arithmetic A where
  zero := C.zero
  succ := C.succ
  pred := pred C
  add := add C
  monus := monus C
  pred_zero := pred_zero C
  pred_succ := pred_succ C
  coverage := coverage C PU
  succ_nonzero := successor_ne_zero C PU
  add_zero_left := add_zero C
  add_zero_right := add_right_zero C PU
  add_succ_left := add_succ C
  add_succ_right := add_right_succ C PU
  monus_zero_left := monus_zero C
  monus_zero_right := monus_zero_right C PU
  monus_succ_left := monus_succ C
  monus_pred_commute := fun x y => (monus_pred_commutes C PU x y).symm
  monus_diagonal := monus_diagonal C PU

def boundTerm : Term := monusTerm .second (monusTerm .first .second)

def reconstructTerm : Term :=
  addTerm (monusTerm (monusTerm .first .second) .second) (monusTerm .second .first)

def boundInduction (a : A) :
    ThreeUpdates.SuccessorReflection.BoundInductionInstance (arithmetic C PU) a :=
  zero_induction C PU boundTerm a

def reconstructUniqueness (a : A) :
    ThreeUpdates.SuccessorReflection.ReconstructionUniquenessInstance
      (arithmetic C PU) a :=
  recursion_uniqueness C PU reconstructTerm (.succ .second) .successor a

include PU in
theorem native_equality :
    (∀ x y, add C (monus C x y) (monus C y x) = C.zero ↔ x = y) ∧
      (∀ x y : A, x = y ∨ x ≠ y) := by
  exact ThreeUpdates.SuccessorReflection.three_update_reflection_bridge
    (arithmetic C PU) (ThreeUpdateDiagonal.strict_complement C PU)
    (boundInduction C PU) (reconstructUniqueness C PU)

def equalityErrorTerm (s t : Term) : Term :=
  addTerm (monusTerm s t) (monusTerm t s)

include PU in
theorem equality_error_reflects (s t : Term) (n a : A) :
    value C (equalityErrorTerm s t) n a = C.zero ↔ value C s n a = value C t n a :=
  (native_equality C PU).1 _ _

include PU in
/-- Contextual induction for arbitrary term equations, with one fixed parameter. -/
theorem equation_induction (s t : Term) (a : A)
    (base : value C s C.zero a = value C t C.zero a)
    (step : ∀ n, value C s n a = value C t n a →
      value C s (C.succ n) a = value C t (C.succ n) a) :
    ∀ n, value C s n a = value C t n a := by
  have error_base := (equality_error_reflects C PU s t C.zero a).2 base
  have error_step (n : A) (h : value C (equalityErrorTerm s t) n a = C.zero) :
      value C (equalityErrorTerm s t) (C.succ n) a = C.zero := by
    exact (equality_error_reflects C PU s t (C.succ n) a).2
      (step n ((equality_error_reflects C PU s t n a).1 h))
  intro n
  exact (equality_error_reflects C PU s t n a).1
    (zero_induction C PU (equalityErrorTerm s t) a error_base error_step n)

#print axioms arithmetic
#print axioms boundInduction
#print axioms reconstructUniqueness
#print axioms native_equality
#print axioms equality_error_reflects
#print axioms equation_induction

end ThreeUpdateReflection
