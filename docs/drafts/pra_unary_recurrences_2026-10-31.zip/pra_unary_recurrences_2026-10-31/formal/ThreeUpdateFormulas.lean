import ThreeUpdateReflection

/-
Constructive finite formula compiler and contextual quantifier-free induction.
Object-language formulas contain equality, falsehood, conjunction,
disjunction, and implication; negation and truth are their usual abbreviations.
Only the two numerical slots of Term are available. No quantified induction,
arbitrary-predicate induction, classical choice, or equality oracle is used.
-/

namespace ThreeUpdateFormulas

open FiniteUpdateKernel ThreeUpdateReflection

universe u

inductive Formula where
  | eq (left right : Term)
  | falsum
  | conj (left right : Formula)
  | disj (left right : Formula)
  | impl (antecedent consequent : Formula)

def satisfies {A : Type u} (C : Model A) : Formula → A → A → Prop
  | .eq s t, n, a => value C s n a = value C t n a
  | .falsum, _, _ => False
  | .conj f g, n, a => satisfies C f n a ∧ satisfies C g n a
  | .disj f g, n, a => satisfies C f n a ∨ satisfies C g n a
  | .impl f g, n, a => satisfies C f n a → satisfies C g n a

def errorTerm : Formula → Term
  | .eq s t => equalityErrorTerm s t
  | .falsum => oneTerm
  | .conj f g => selectTerm (errorTerm f) (errorTerm g) oneTerm
  | .disj f g => selectTerm (errorTerm f) .zero (errorTerm g)
  | .impl f g => selectTerm (errorTerm f) (errorTerm g) .zero

variable {A : Type u} (C : Model A) (PU : PositiveSchema C)

include PU in
theorem formula_reflection (f : Formula) (n a : A) :
    satisfies C f n a ↔ value C (errorTerm f) n a = C.zero := by
  induction f with
  | eq s t => exact (equality_error_reflects C PU s t n a).symm
  | falsum =>
    constructor
    · exact False.elim
    · intro h
      exact successor_ne_zero C PU C.zero h
  | conj f g ihf ihg =>
    change (satisfies C f n a ∧ satisfies C g n a) ↔
      select C (value C (errorTerm f) n a) (value C (errorTerm g) n a) (one C) =
        C.zero
    rcases zero_decision C PU (value C (errorTerm f) n a) with hz | hn
    · rw [hz, select_zero C PU]
      constructor
      · intro h
        exact ihg.1 h.2
      · intro h
        exact ⟨ihf.2 hz, ihg.2 h⟩
    · rw [select_nonzero C PU hn]
      constructor
      · intro h
        exact False.elim (hn (ihf.1 h.1))
      · intro h
        exact False.elim (successor_ne_zero C PU C.zero h)
  | disj f g ihf ihg =>
    change (satisfies C f n a ∨ satisfies C g n a) ↔
      select C (value C (errorTerm f) n a) C.zero (value C (errorTerm g) n a) =
        C.zero
    rcases zero_decision C PU (value C (errorTerm f) n a) with hz | hn
    · rw [hz, select_zero C PU]
      exact ⟨fun _ => rfl, fun _ => Or.inl (ihf.2 hz)⟩
    · rw [select_nonzero C PU hn]
      constructor
      · intro h
        rcases h with hf | hg
        · exact False.elim (hn (ihf.1 hf))
        · exact ihg.1 hg
      · intro h
        exact Or.inr (ihg.2 h)
  | impl f g ihf ihg =>
    change (satisfies C f n a → satisfies C g n a) ↔
      select C (value C (errorTerm f) n a) (value C (errorTerm g) n a) C.zero =
        C.zero
    rcases zero_decision C PU (value C (errorTerm f) n a) with hz | hn
    · rw [hz, select_zero C PU]
      constructor
      · intro h
        exact ihg.1 (h (ihf.2 hz))
      · intro h _
        exact ihg.2 h
    · rw [select_nonzero C PU hn]
      constructor
      · intro _
        rfl
      · intro _ hf
        exact False.elim (hn (ihf.1 hf))

include PU in
theorem formula_decision (f : Formula) (n a : A) :
    satisfies C f n a ∨ ¬ satisfies C f n a := by
  rcases zero_decision C PU (value C (errorTerm f) n a) with hz | hn
  · exact Or.inl ((formula_reflection C PU f n a).2 hz)
  · exact Or.inr (fun h => hn ((formula_reflection C PU f n a).1 h))

include PU in
/-- The complete one-parameter quantifier-free induction principle. -/
theorem quantifier_free_induction (f : Formula) (a : A)
    (base : satisfies C f C.zero a)
    (step : ∀ n, satisfies C f n a → satisfies C f (C.succ n) a) :
    ∀ n, satisfies C f n a := by
  have error_base := (formula_reflection C PU f C.zero a).1 base
  have error_step (n : A) (h : value C (errorTerm f) n a = C.zero) :
      value C (errorTerm f) (C.succ n) a = C.zero :=
    (formula_reflection C PU f (C.succ n) a).1
      (step n ((formula_reflection C PU f n a).2 h))
  intro n
  exact (formula_reflection C PU f n a).2
    (zero_induction C PU (errorTerm f) a error_base error_step n)

#print axioms formula_reflection
#print axioms formula_decision
#print axioms quantifier_free_induction

end ThreeUpdateFormulas
