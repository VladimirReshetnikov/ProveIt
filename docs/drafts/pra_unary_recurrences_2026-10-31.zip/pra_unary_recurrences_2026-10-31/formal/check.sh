#!/usr/bin/env bash
set -euo pipefail

pra_formal_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd -- "$pra_formal_dir"
pra_lean="${1:-lean}"
export LEAN_PATH="$pra_formal_dir${LEAN_PATH:+:$LEAN_PATH}"

for pra_module in \
  FiniteUpdateKernel \
  BooleanDiagonal \
  ThreeUpdateDiagonal \
  SuccessorReflection \
  ThreeUpdateReflection \
  ThreeUpdateFormulas
do
  "$pra_lean" -o "$pra_module.olean" "$pra_module.lean" > "$pra_module.log" 2>&1
done

python3 - <<'PY'
from pathlib import Path
import json

modules = [
    'FiniteUpdateKernel', 'BooleanDiagonal', 'ThreeUpdateDiagonal',
    'SuccessorReflection', 'ThreeUpdateReflection', 'ThreeUpdateFormulas',
]
results = []
for name in modules:
    output = Path(name + '.log').read_text()
    if 'depends on axioms:' in output or 'error:' in output or 'sorryAx' in output:
        raise SystemExit('Failed axiom audit: ' + name)
    count = output.count('does not depend on any axioms')
    if count == 0:
        raise SystemExit('Missing axiom audit: ' + name)
    results.append({'module': name, 'compiled': True, 'clean_axiom_audits': count})

summary = {
    'modules': results,
    'total_clean_axiom_audits': sum(r['clean_axiom_audits'] for r in results),
    'final_theorem': 'ThreeUpdateFormulas.quantifier_free_induction',
    'assumptions': 'FiniteUpdateKernel.Model and its three-update PositiveSchema',
    'scope': 'Finite terms and quantifier-free formulas with one fixed numerical parameter',
}
Path('verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
PY
