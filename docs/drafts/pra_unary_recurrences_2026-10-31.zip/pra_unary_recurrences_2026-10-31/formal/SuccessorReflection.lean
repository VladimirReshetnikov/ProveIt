import Lean

/-!
# Native equality reflection using only successor uniqueness

Lean 4.19.0. This certificate checks the new reconstruction argument on an
arbitrary arithmetic carrier, without induction on that carrier, an equality
oracle, or classical reasoning. It does not assert that every Lean function
is an object-language term.

The arithmetic equations, constructor coverage, and strict comparison
complement are explicit hypotheses. The accompanying manuscript derives
them before this argument, using only the three arithmetic uniqueness
updates successor, predecessor, and identity. Computation descriptions still
allow arbitrary finite counter/state updates.

The only extra proof resources here are ONE specified zero-equation induction
instance, for M(a,M(n,a))=0, and ONE specified successor-uniqueness instance,
for the finite term M(M(n,a),a)+M(a,n). Both have exactly one fixed parameter a.
The first resource follows from the separate bit-latch proof. The second is
an instance of successor-update uniqueness. In particular, no maximum update
and no general equation induction are assumed in this bridge.

Theorem `three_update_reflection_bridge` links these local resources through
the reconstruction theorem to native equality reflection. This file checks
that bridge, not the entire first-order conservative-extension metatheorem.
All assumptions are ordinary theorem parameters. The printed audits should
report no global axiom dependencies.
-/

set_option autoImplicit false

namespace ThreeUpdates.SuccessorReflection

universe u

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  add : A → A → A
  monus : A → A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  coverage : ∀ x, x = zero ∨ x = succ (pred x)
  succ_nonzero : ∀ x, succ x ≠ zero
  add_zero_left : ∀ x, add zero x = x
  add_zero_right : ∀ x, add x zero = x
  add_succ_left : ∀ x y, add (succ x) y = succ (add x y)
  add_succ_right : ∀ x y, add x (succ y) = succ (add x y)
  monus_zero_left : ∀ x, monus zero x = x
  monus_zero_right : ∀ x, monus x zero = zero
  monus_succ_left : ∀ x y, monus (succ x) y = pred (monus x y)
  monus_pred_commute : ∀ x y, pred (monus x y) = monus x (pred y)
  monus_diagonal : ∀ x, monus x x = zero

variable {A : Type u}

theorem zero_decision (m : Arithmetic A) (x : A) :
    x = m.zero ∨ x ≠ m.zero := by
  cases m.coverage x with
  | inl is_zero => exact Or.inl is_zero
  | inr is_succ =>
    apply Or.inr
    intro is_zero
    exact m.succ_nonzero (m.pred x) (is_succ.symm.trans is_zero)

theorem monus_pred_second (m : Arithmetic A) (x y : A) :
    m.pred (m.monus x (m.succ y)) = m.monus x y := by
  exact (m.monus_pred_commute x (m.succ y)).trans
    (congrArg (m.monus x) (m.pred_succ y))

def StrictComplement (m : Arithmetic A) : Prop :=
  ∀ n a, (m.monus n a ≠ m.zero ↔ m.monus a (m.succ n) = m.zero)

def SubtractionBound (m : Arithmetic A) (n a : A) : Prop :=
  m.monus a (m.monus n a) = m.zero

/-- One particular zero-equation induction instance, not arbitrary induction. -/
def BoundInductionInstance (m : Arithmetic A) (a : A) : Prop :=
  SubtractionBound m m.zero a →
    (∀ n, SubtractionBound m n a → SubtractionBound m (m.succ n) a) →
    ∀ n, SubtractionBound m n a

theorem subtraction_bound_base (m : Arithmetic A) (a : A) :
    SubtractionBound m m.zero a := by
  exact (congrArg (m.monus a) (m.monus_zero_left a)).trans
    (m.monus_diagonal a)

theorem subtraction_bound_step (m : Arithmetic A) (n a : A)
    (previous : SubtractionBound m n a) :
    SubtractionBound m (m.succ n) a := by
  calc
    m.monus a (m.monus (m.succ n) a) =
        m.monus a (m.pred (m.monus n a)) :=
      congrArg (m.monus a) (m.monus_succ_left n a)
    _ = m.pred (m.monus a (m.monus n a)) :=
      (m.monus_pred_commute a (m.monus n a)).symm
    _ = m.pred m.zero := congrArg m.pred previous
    _ = m.zero := m.pred_zero

theorem subtraction_bound (m : Arithmetic A)
    (induct : ∀ a, BoundInductionInstance m a) :
    ∀ n a, SubtractionBound m n a := by
  intro n a
  exact induct a (subtraction_bound_base m a)
    (fun k => subtraction_bound_step m k a) n

def reconstruct (m : Arithmetic A) (n a : A) : A :=
  m.add (m.monus (m.monus n a) a) (m.monus a n)

theorem reconstruct_base (m : Arithmetic A) (a : A) :
    reconstruct m m.zero a = m.zero := by
  calc
    reconstruct m m.zero a = m.add (m.monus a a) (m.monus a m.zero) :=
      congrArg (fun z => m.add (m.monus z a) (m.monus a m.zero))
        (m.monus_zero_left a)
    _ = m.add m.zero (m.monus a m.zero) :=
      congrArg (fun z => m.add z (m.monus a m.zero)) (m.monus_diagonal a)
    _ = m.monus a m.zero := m.add_zero_left _
    _ = m.zero := m.monus_zero_right a

theorem reconstruct_step (m : Arithmetic A)
    (complement : StrictComplement m)
    (bound : ∀ n a, SubtractionBound m n a) (n a : A) :
    reconstruct m (m.succ n) a = m.succ (reconstruct m n a) := by
  cases zero_decision m (m.monus n a) with
  | inl remainder_zero =>
    have next_remainder_zero : m.monus (m.succ n) a = m.zero :=
      (m.monus_succ_left n a).trans
        ((congrArg m.pred remainder_zero).trans m.pred_zero)
    have other_next_nonzero : m.monus a (m.succ n) ≠ m.zero := by
      intro other_next_zero
      exact ((complement n a).mpr other_next_zero) remainder_zero
    have other_next_succ :
        m.monus a (m.succ n) = m.succ (m.monus a n) :=
      ((m.coverage _).resolve_left other_next_nonzero).trans
        (congrArg m.succ (monus_pred_second m a n))
    have current : reconstruct m n a = m.add a (m.monus a n) := by
      exact congrArg (fun z => m.add z (m.monus a n))
        ((congrArg (fun z => m.monus z a) remainder_zero).trans
          (m.monus_zero_left a))
    calc
      reconstruct m (m.succ n) a = m.add a (m.monus a (m.succ n)) :=
        congrArg (fun z => m.add z (m.monus a (m.succ n)))
          ((congrArg (fun z => m.monus z a) next_remainder_zero).trans
            (m.monus_zero_left a))
      _ = m.add a (m.succ (m.monus a n)) := congrArg (m.add a) other_next_succ
      _ = m.succ (m.add a (m.monus a n)) := m.add_succ_right _ _
      _ = m.succ (reconstruct m n a) := congrArg m.succ current.symm
  | inr remainder_nonzero =>
    have remainder_succ :=
      (m.coverage (m.monus n a)).resolve_left remainder_nonzero
    have other_next_zero : m.monus a (m.succ n) = m.zero :=
      (complement n a).mp remainder_nonzero
    have other_zero : m.monus a n = m.zero :=
      (monus_pred_second m a n).symm.trans
        ((congrArg m.pred other_next_zero).trans m.pred_zero)
    have reverse_bound :
        m.monus a (m.succ (m.pred (m.monus n a))) = m.zero :=
      (congrArg (m.monus a) remainder_succ).symm.trans (bound n a)
    have inner_nonzero :
        m.monus (m.pred (m.monus n a)) a ≠ m.zero :=
      (complement (m.pred (m.monus n a)) a).mpr reverse_bound
    have inner_pred :
        m.pred (m.monus (m.pred (m.monus n a)) a) =
          m.monus (m.monus n a) a := by
      exact (m.monus_succ_left (m.pred (m.monus n a)) a).symm.trans
        (congrArg (fun z => m.monus z a) remainder_succ.symm)
    have inner_succ :
        m.monus (m.pred (m.monus n a)) a =
          m.succ (m.monus (m.monus n a) a) :=
      ((m.coverage _).resolve_left inner_nonzero).trans
        (congrArg m.succ inner_pred)
    have current : reconstruct m n a = m.monus (m.monus n a) a :=
      (congrArg (m.add (m.monus (m.monus n a) a)) other_zero).trans
        (m.add_zero_right _)
    calc
      reconstruct m (m.succ n) a =
          m.add (m.monus (m.pred (m.monus n a)) a) (m.monus a (m.succ n)) :=
        congrArg (fun z => m.add (m.monus z a) (m.monus a (m.succ n)))
          (m.monus_succ_left n a)
      _ = m.add (m.succ (m.monus (m.monus n a) a)) (m.monus a (m.succ n)) :=
        congrArg (fun z => m.add z (m.monus a (m.succ n))) inner_succ
      _ = m.add (m.succ (m.monus (m.monus n a) a)) m.zero :=
        congrArg (m.add (m.succ (m.monus (m.monus n a) a))) other_next_zero
      _ = m.succ (m.monus (m.monus n a) a) := m.add_zero_right _
      _ = m.succ (reconstruct m n a) := congrArg m.succ current.symm

/-- The one specified U_S instance, with addition as the successor iterator. -/
def ReconstructionUniquenessInstance (m : Arithmetic A) (a : A) : Prop :=
  (∀ n, reconstruct m (m.succ n) a = m.succ (reconstruct m n a)) →
    ∀ n, reconstruct m n a = m.add n (reconstruct m m.zero a)

theorem reconstruction (m : Arithmetic A)
    (complement : StrictComplement m)
    (induct : ∀ a, BoundInductionInstance m a)
    (unique : ∀ a, ReconstructionUniquenessInstance m a) :
    ∀ n a, reconstruct m n a = n := by
  have bound := subtraction_bound m induct
  intro n a
  have result := unique a (fun k => reconstruct_step m complement bound k a) n
  exact result.trans ((congrArg (m.add n) (reconstruct_base m a)).trans
    (m.add_zero_right n))

theorem native_equality_reflection (m : Arithmetic A)
    (reconstruction_law : ∀ n a, reconstruct m n a = n) :
    ∀ x y, (m.monus x y = m.zero ∧ m.monus y x = m.zero) ↔ x = y := by
  intro x y
  constructor
  · intro remainders
    have result := reconstruction_law x y
    have reverse : y = x := by
      simpa only [reconstruct, remainders.1, remainders.2,
        m.monus_zero_left, m.add_zero_right] using result
    exact reverse.symm
  · intro same
    subst y
    exact ⟨m.monus_diagonal x, m.monus_diagonal x⟩

theorem sum_zero_iff (m : Arithmetic A) (x y : A) :
    m.add x y = m.zero ↔ (x = m.zero ∧ y = m.zero) := by
  constructor
  · intro sum_zero
    cases m.coverage x with
    | inl first_zero =>
      have second_zero : y = m.zero := by
        calc
          y = m.add m.zero y := (m.add_zero_left y).symm
          _ = m.add x y := congrArg (fun z => m.add z y) first_zero.symm
          _ = m.zero := sum_zero
      exact ⟨first_zero, second_zero⟩
    | inr first_succ =>
      have impossible : m.succ (m.add (m.pred x) y) = m.zero := by
        exact ((congrArg (fun z => m.add z y) first_succ).trans
          (m.add_succ_left (m.pred x) y)).symm.trans sum_zero
      exact False.elim (m.succ_nonzero _ impossible)
  · intro both_zero
    exact (congrArg (fun z => m.add z y) both_zero.1).trans
      ((m.add_zero_left y).trans both_zero.2)

theorem error_term_reflection (m : Arithmetic A)
    (reconstruction_law : ∀ n a, reconstruct m n a = n) :
    ∀ x y, m.add (m.monus x y) (m.monus y x) = m.zero ↔ x = y := by
  intro x y
  exact (sum_zero_iff m _ _).trans
    (native_equality_reflection m reconstruction_law x y)

theorem native_equality_decision (m : Arithmetic A)
    (reconstruction_law : ∀ n a, reconstruct m n a = n) :
    ∀ x y : A, x = y ∨ x ≠ y := by
  intro x y
  have reflected := error_term_reflection m reconstruction_law x y
  cases zero_decision m (m.add (m.monus x y) (m.monus y x)) with
  | inl error_zero => exact Or.inl (reflected.mp error_zero)
  | inr error_nonzero =>
    exact Or.inr (fun same => error_nonzero (reflected.mpr same))

theorem three_update_reflection_bridge (m : Arithmetic A)
    (complement : StrictComplement m)
    (induct : ∀ a, BoundInductionInstance m a)
    (unique : ∀ a, ReconstructionUniquenessInstance m a) :
    (∀ x y, m.add (m.monus x y) (m.monus y x) = m.zero ↔ x = y) ∧
      (∀ x y : A, x = y ∨ x ≠ y) := by
  have reconstruction_law := reconstruction m complement induct unique
  exact ⟨error_term_reflection m reconstruction_law,
    native_equality_decision m reconstruction_law⟩

#print axioms zero_decision
#print axioms monus_pred_second
#print axioms subtraction_bound_base
#print axioms subtraction_bound_step
#print axioms subtraction_bound
#print axioms reconstruct_base
#print axioms reconstruct_step
#print axioms reconstruction
#print axioms native_equality_reflection
#print axioms sum_zero_iff
#print axioms error_term_reflection
#print axioms native_equality_decision
#print axioms three_update_reflection_bridge

end ThreeUpdates.SuccessorReflection
