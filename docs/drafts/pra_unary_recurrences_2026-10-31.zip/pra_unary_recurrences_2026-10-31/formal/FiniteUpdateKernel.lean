/-
Three unary recurrences: finite-syntax constructive core.
Lean 4.19.0, no imports and no external packages.

The arithmetic carrier A is arbitrary. There is no induction on A.
Term is the actual well-founded binary initialized-iteration syntax.
An iterator's update has its own two bound slots; substitution in an
application does not enter that update descriptor. PU quantifies over finite terms and only three update descriptors: successor,
predecessor, and identity. It never quantifies over arbitrary carrier functions.

Certified here: substitution semantics, PU -> separation, successor laws,
contextual uniqueness for the three allowed updates, constructor coverage, zero
decision, selected arithmetic identities, binary digit retractions, and
contextual zero-equation induction with an arbitrary fixed parameter. The complete manuscript's
formula compiler, pairing and full first-order theory equivalence are not
claimed to be formalized in this file.
-/

namespace FiniteUpdateKernel

universe u

inductive Term where
  | first
  | second
  | zero
  | succ (argument : Term)
  | iter (update counter seed : Term)
  deriving DecidableEq

def substitute : Term → Term → Term → Term
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => .zero
  | .succ t, x, y => .succ (substitute t x y)
  | .iter h n a, x, y => .iter h (substitute n x y) (substitute a x y)

def evaluate {A : Type u} (zero : A) (succ : A → A)
    (run : Term → A → A → A) : Term → A → A → A
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => zero
  | .succ t, x, y => succ (evaluate zero succ run t x y)
  | .iter h n a, x, y =>
      run h (evaluate zero succ run n x y) (evaluate zero succ run a x y)

structure Model (A : Type u) where
  zero : A
  succ : A → A
  run : Term → A → A → A
  run_zero : ∀ h a, run h zero a = a
  run_succ : ∀ h n a,
    run h (succ n) a = evaluate zero succ run h n (run h n a)

def value {A : Type u} (C : Model A) (t : Term) (x y : A) : A :=
  evaluate C.zero C.succ C.run t x y

variable {A : Type u} (C : Model A)

theorem value_substitute (t x y : Term) (n a : A) :
    value C (substitute t x y) n a =
      value C t (value C x n a) (value C y n a) := by
  induction t with
  | first => rfl
  | second => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | iter h n' a' _ ihn iha =>
      change C.run h (value C (substitute n' x y) n a)
          (value C (substitute a' x y) n a) =
        C.run h (value C n' (value C x n a) (value C y n a))
          (value C a' (value C x n a) (value C y n a))
      exact congr (congrArg (C.run h) ihn) iha

def oneTerm : Term := .succ .zero
def predTerm (t : Term) : Term := .iter .first t .zero
def addTerm (s t : Term) : Term := .iter (.succ .second) s t
def gateTerm (s t : Term) : Term := .iter .zero s t
def monusTerm (s t : Term) : Term := .iter (predTerm .second) s t

def one : A := C.succ C.zero
def pred (x : A) : A := C.run .first x C.zero
def add (x y : A) : A := C.run (.succ .second) x y
def gate (x y : A) : A := C.run .zero x y
def monus (x y : A) : A := C.run (predTerm .second) x y

theorem pred_zero : pred C C.zero = C.zero := C.run_zero _ _
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.run_succ _ _ _
theorem add_zero (x : A) : add C C.zero x = x := C.run_zero _ _
theorem add_succ (x y : A) : add C (C.succ x) y = C.succ (add C x y) :=
  C.run_succ _ _ _
theorem gate_zero (x : A) : gate C C.zero x = x := C.run_zero _ _
theorem gate_succ (x y : A) : gate C (C.succ x) y = C.zero := C.run_succ _ _ _
theorem monus_zero (x : A) : monus C C.zero x = x := C.run_zero _ _
theorem monus_succ (x y : A) : monus C (C.succ x) y = pred C (monus C x y) :=
  C.run_succ _ _ _

/-- The ONLY permitted uniqueness updates. All programs still have computation equations. -/
inductive AllowedUpdate : Term → Prop where
  | successor : AllowedUpdate (.succ .second)
  | predecessor : AllowedUpdate (predTerm .second)
  | identity : AllowedUpdate .second

/-- Every quantified object is finite syntax; a is the sole fixed parameter. -/
def PositiveSchema : Prop :=
  ∀ t h : Term, AllowedUpdate h → ∀ a : A,
    (∀ n, value C t (C.succ (C.succ n)) a =
      value C h n (value C t (C.succ n) a)) →
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨
        value C t n a = C.run h (pred C n) (value C t (one C) a)

variable (PU : PositiveSchema C)
include PU

theorem separation : C.zero ≠ C.succ C.zero := by
  exact (PU .first (.succ .second) .successor C.zero (fun _ => rfl)).1

omit PU in
theorem successor_injective {x y : A} (h : C.succ x = C.succ y) : x = y := by
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_succ C] at e
  exact e

theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro h
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_zero C] at e
  have bad : C.succ C.zero = C.zero := (congrArg C.succ e).symm.trans h
  exact separation C PU bad.symm

/-- Ordinary initialized recursion uniqueness, with a term parameter. -/
theorem recursion_uniqueness (t h : Term) (allowed : AllowedUpdate h) (a : A)
    (step : ∀ n, value C t (C.succ n) a = value C h n (value C t n a)) :
    ∀ n, value C t n a = C.run h n (value C t C.zero a) := by
  let delayed := substitute t (predTerm .first) .second
  have delay (x : A) : value C delayed x a = value C t (pred C x) a := by
    exact value_substitute C t (predTerm .first) .second x a
  have positive := PU delayed h allowed a (by
    intro n
    rw [delay, delay, pred_succ C, pred_succ C]
    exact step n)
  intro n
  rcases positive.2 (C.succ n) with hz | he
  · exact False.elim (successor_ne_zero C PU n hz)
  · rw [delay, delay, pred_succ C] at he
    change value C t n a = C.run h n (value C t (pred C (C.succ C.zero)) a) at he
    rw [pred_succ C] at he
    exact he

theorem add_right_zero (x : A) : add C x C.zero = x := by
  have q := recursion_uniqueness C PU .first (.succ .second) .successor C.zero
    (fun _ => rfl) x
  exact q.symm

theorem add_one (x : A) : add C x (one C) = C.succ x := by
  have q := recursion_uniqueness C PU (.succ .first) (.succ .second) .successor C.zero
    (fun _ => rfl) x
  exact q.symm

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  have q := PU .first (.succ .second) .successor C.zero (fun _ => rfl)
  rcases q.2 x with hz | he
  · exact Or.inl hz
  · change x = add C (pred C x) (one C) at he
    rw [add_one C PU] at he
    exact Or.inr he

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases coverage C PU x with hz | hs
  · exact Or.inl hz
  · exact Or.inr (fun hz => successor_ne_zero C PU (pred C x) (hs.symm.trans hz))

theorem add_right_succ (x y : A) : add C x (C.succ y) = C.succ (add C x y) := by
  let t : Term := .succ (addTerm .first .second)
  have step (n : A) : value C t (C.succ n) y =
      value C (.succ .second) n (value C t n y) := by
    change C.succ (add C (C.succ n) y) = C.succ (C.succ (add C n y))
    rw [add_succ C]
  have q := recursion_uniqueness C PU t (.succ .second) .successor y step x
  change C.succ (add C x y) = add C x (C.succ (add C C.zero y)) at q
  rw [add_zero C] at q
  exact q.symm

theorem addition_commutes (x y : A) : add C x y = add C y x := by
  let t := addTerm .second .first
  have step (n : A) : value C t (C.succ n) y =
      value C (.succ .second) n (value C t n y) := by
    exact add_right_succ C PU y n
  have q := recursion_uniqueness C PU t (.succ .second) .successor y step x
  change add C y x = add C x (add C y C.zero) at q
  rw [add_right_zero C PU] at q
  exact q.symm

theorem monus_pred_commutes (x y : A) :
    monus C x (pred C y) = pred C (monus C x y) := by
  let t := predTerm (monusTerm .first .second)
  let h := predTerm .second
  have step (n : A) : value C t (C.succ n) y =
      value C h n (value C t n y) := by
    change pred C (monus C (C.succ n) y) = pred C (pred C (monus C n y))
    rw [monus_succ C]
  have q := recursion_uniqueness C PU t h .predecessor y step x
  change pred C (monus C x y) = monus C x (pred C (monus C C.zero y)) at q
  rw [monus_zero C] at q
  exact q.symm

theorem monus_shift (x y : A) : monus C (C.succ x) (C.succ y) = monus C x y := by
  rw [monus_succ C, ← monus_pred_commutes C PU, pred_succ C]

theorem monus_zero_right (x : A) : monus C x C.zero = C.zero := by
  have q := recursion_uniqueness C PU .zero (predTerm .second) .predecessor C.zero
    (fun _ => (pred_zero C).symm) x
  exact q.symm

theorem monus_diagonal (x : A) : monus C x x = C.zero := by
  let t := monusTerm .first .first
  have step (n : A) : value C t (C.succ n) C.zero =
      value C .second n (value C t n C.zero) := by
    exact monus_shift C PU n n
  have q := recursion_uniqueness C PU t .second .identity C.zero step x
  change monus C x x = C.run .second x (monus C C.zero C.zero) at q
  rw [monus_zero C] at q
  have z := recursion_uniqueness C PU .zero .second .identity C.zero (fun _ => rfl) x
  exact q.trans z.symm

theorem monus_add_cancel (x y : A) : monus C x (add C x y) = y := by
  let t := monusTerm .first (addTerm .first .second)
  have step (n : A) : value C t (C.succ n) y =
      value C .second n (value C t n y) := by
    change monus C (C.succ n) (add C (C.succ n) y) = monus C n (add C n y)
    rw [add_succ C, monus_shift C PU]
  have q := recursion_uniqueness C PU t .second .identity y step x
  change monus C x (add C x y) = C.run .second x (monus C C.zero (add C C.zero y)) at q
  rw [add_zero C, monus_zero C] at q
  have z := recursion_uniqueness C PU .second .second .identity y (fun _ => rfl) x
  exact q.trans z.symm

def selectTerm (z x y : Term) : Term :=
  addTerm (gateTerm z x) (gateTerm (gateTerm z oneTerm) y)

def select (z x y : A) : A :=
  add C (gate C z x) (gate C (gate C z (one C)) y)

theorem select_zero (x y : A) : select C C.zero x y = x := by
  unfold select one
  rw [gate_zero C, gate_zero C, gate_succ C, add_right_zero C PU]

omit PU in
theorem select_succ (z x y : A) : select C (C.succ z) x y = y := by
  unfold select
  rw [gate_succ C, gate_succ C, gate_zero C, add_zero C]

theorem select_nonzero {z : A} (hz : z ≠ C.zero) (x y : A) :
    select C z x y = y := by
  rcases coverage C PU z with h | h
  · exact False.elim (hz h)
  · rw [h, select_succ C]

theorem select_same (z x : A) : select C z x x = x := by
  rcases coverage C PU z with h | h
  · rw [h, select_zero C PU]
  · rw [h, select_succ C]

omit PU in
theorem value_select (z x y : Term) (n a : A) :
    value C (selectTerm z x y) n a =
      select C (value C z n a) (value C x n a) (value C y n a) := rfl

def Bit (x : A) : Prop := x = C.zero ∨ x = one C

def parityUpdate : Term := gateTerm .second oneTerm
def parityTerm (t : Term) : Term := .iter parityUpdate t .zero
def halfUpdate : Term := selectTerm (parityTerm .first) .second (.succ .second)
def halfTerm (t : Term) : Term := .iter halfUpdate t .zero
def doubleUpdate : Term := .succ (.succ .second)
def doubleTerm (t : Term) : Term := .iter doubleUpdate t .zero

def parity (x : A) : A := C.run parityUpdate x C.zero
def half (x : A) : A := C.run halfUpdate x C.zero
def double (x : A) : A := C.run doubleUpdate x C.zero

omit PU in
theorem parity_zero : parity C C.zero = C.zero := C.run_zero _ _
omit PU in
theorem parity_succ (x : A) : parity C (C.succ x) = gate C (parity C x) (one C) :=
  C.run_succ _ _ _
omit PU in
theorem half_zero : half C C.zero = C.zero := C.run_zero _ _
omit PU in
theorem half_succ (x : A) : half C (C.succ x) =
    select C (parity C x) (half C x) (C.succ (half C x)) := C.run_succ _ _ _
omit PU in
theorem double_zero : double C C.zero = C.zero := C.run_zero _ _
omit PU in
theorem double_succ (x : A) : double C (C.succ x) =
    C.succ (C.succ (double C x)) := C.run_succ _ _ _

theorem gate_is_bit (x : A) : Bit C (gate C x (one C)) := by
  rcases coverage C PU x with h | h
  · exact Or.inr (by rw [h, gate_zero C])
  · exact Or.inl (by rw [h, gate_succ C])

theorem parity_is_bit (x : A) : Bit C (parity C x) := by
  rcases coverage C PU x with h | h
  · exact Or.inl (by rw [h, parity_zero C])
  · rw [h, parity_succ C]
    exact gate_is_bit C PU _

theorem parity_twice (x : A) : parity C (C.succ (C.succ x)) = parity C x := by
  rw [parity_succ C, parity_succ C]
  rcases parity_is_bit C PU x with h | h
  · rw [h, gate_zero C]
    exact gate_succ C C.zero (one C)
  · rw [h]
    change gate C (gate C (C.succ C.zero) (one C)) (one C) = one C
    rw [gate_succ C, gate_zero C]

theorem half_twice (x : A) : half C (C.succ (C.succ x)) = C.succ (half C x) := by
  rw [half_succ C, half_succ C, parity_succ C]
  rcases parity_is_bit C PU x with h | h
  · rw [h, gate_zero C, select_zero C PU]
    exact select_succ C C.zero (half C x) (C.succ (half C x))
  · rw [h]
    change select C (gate C (C.succ C.zero) (one C))
      (select C (C.succ C.zero) (half C x) (C.succ (half C x)))
      (C.succ (select C (C.succ C.zero) (half C x) (C.succ (half C x)))) =
      C.succ (half C x)
    rw [gate_succ C, select_succ C, select_zero C PU]

theorem parity_double (x : A) : parity C (double C x) = C.zero := by
  let t := parityTerm (doubleTerm .first)
  have step (n : A) : value C t (C.succ n) C.zero =
      value C .second n (value C t n C.zero) := by
    change parity C (double C (C.succ n)) = parity C (double C n)
    rw [double_succ C, parity_twice C PU]
  have q := recursion_uniqueness C PU t .second .identity C.zero step x
  change parity C (double C x) = C.run .second x (parity C (double C C.zero)) at q
  rw [double_zero C, parity_zero C] at q
  have z := recursion_uniqueness C PU .zero .second .identity C.zero (fun _ => rfl) x
  exact q.trans z.symm

theorem half_double (x : A) : half C (double C x) = x := by
  let t := halfTerm (doubleTerm .first)
  have step (n : A) : value C t (C.succ n) C.zero =
      value C (.succ .second) n (value C t n C.zero) := by
    change half C (double C (C.succ n)) = C.succ (half C (double C n))
    rw [double_succ C, half_twice C PU]
  have q := recursion_uniqueness C PU t (.succ .second) .successor C.zero step x
  change half C (double C x) = add C x (half C (double C C.zero)) at q
  rw [double_zero C, half_zero C, add_right_zero C PU] at q
  exact q

theorem parity_odd (x : A) : parity C (C.succ (double C x)) = one C := by
  rw [parity_succ C, parity_double C PU, gate_zero C]

theorem half_odd (x : A) : half C (C.succ (double C x)) = x := by
  rw [half_succ C, parity_double C PU, select_zero C PU, half_double C PU]

def encodeTerm (a b : Term) : Term := selectTerm b (doubleTerm a) (.succ (doubleTerm a))
def encode (a b : A) : A := select C b (double C a) (C.succ (double C a))

theorem encode_zero (a : A) : encode C a C.zero = double C a :=
  select_zero C PU _ _

omit PU in
theorem encode_one (a : A) : encode C a (one C) = C.succ (double C a) :=
  select_succ C C.zero _ _

theorem half_encode (a b : A) : half C (encode C a b) = a := by
  rcases coverage C PU b with h | h
  · rw [h, encode_zero C PU, half_double C PU]
  · unfold encode
    rw [h, select_succ C, half_odd C PU]

theorem parity_encode (a b : A) (hb : Bit C b) : parity C (encode C a b) = b := by
  rcases hb with h | h
  · rw [h, encode_zero C PU, parity_double C PU]
  · rw [h, encode_one C, parity_odd C PU]

def indicatorTerm (t : Term) : Term := selectTerm t .zero oneTerm
def indicator (x : A) : A := select C x C.zero (one C)

theorem indicator_zero : indicator C C.zero = C.zero := select_zero C PU _ _
theorem indicator_nonzero {x : A} (hx : x ≠ C.zero) : indicator C x = one C :=
  select_nonzero C PU hx _ _

theorem indicator_is_bit (x : A) : Bit C (indicator C x) := by
  rcases zero_decision C PU x with h | h
  · exact Or.inl (by rw [h, indicator_zero C PU])
  · exact Or.inr (indicator_nonzero C PU h)

theorem indicator_reflects (x : A) (hx : indicator C x = C.zero) : x = C.zero := by
  rcases zero_decision C PU x with h | h
  · exact h
  · rw [indicator_nonzero C PU h] at hx
    exact False.elim (separation C PU hx.symm)

omit PU in
theorem value_encode (a b : Term) (n p : A) :
    value C (encodeTerm a b) n p = encode C (value C a n p) (value C b n p) := rfl

omit PU in
theorem value_indicator (t : Term) (n a : A) :
    value C (indicatorTerm t) n a = indicator C (value C t n a) := rfl

/-- Identity is one of the three permitted uniqueness updates. -/
theorem constancy (t : Term) (a : A)
    (step : ∀ n, value C t (C.succ n) a = value C t n a) :
    ∀ n, value C t n a = value C t C.zero a := by
  have trace := recursion_uniqueness C PU t .second .identity a step
  intro n
  have constant := recursion_uniqueness C PU .second .second .identity
    (value C t C.zero a) (fun _ => rfl) n
  exact (trace n).trans constant.symm

def truthTerm (t : Term) : Term := gateTerm t oneTerm
def truth (x : A) : A := gate C x (one C)
def andTerm (b c : Term) : Term := selectTerm b .zero c
def bitAnd (b c : A) : A := select C b C.zero c

omit PU in
theorem truth_zero : truth C C.zero = one C := gate_zero C _

theorem truth_nonzero {x : A} (hx : x ≠ C.zero) : truth C x = C.zero := by
  rcases coverage C PU x with h | h
  · exact False.elim (hx h)
  · exact h ▸ gate_succ C _ _

theorem truth_is_bit (x : A) : Bit C (truth C x) := gate_is_bit C PU x

theorem truth_reflects (x : A) (hx : truth C x = one C) : x = C.zero := by
  rcases zero_decision C PU x with h | h
  · exact h
  · rw [truth_nonzero C PU h] at hx
    exact False.elim (separation C PU hx)

theorem bitAnd_zero (c : A) : bitAnd C C.zero c = C.zero := select_zero C PU _ _

omit PU in
theorem bitAnd_one (c : A) : bitAnd C (one C) c = c := select_succ C C.zero _ _

theorem bitAnd_is_bit (b c : A) (hb : Bit C b) (hc : Bit C c) :
    Bit C (bitAnd C b c) := by
  rcases hb with h | h
  · exact Or.inl (by rw [h, bitAnd_zero C PU])
  · rw [h, bitAnd_one C]
    exact hc

theorem bitAnd_one_right (b c : A) (hb : Bit C b)
    (h : bitAnd C b c = one C) : c = one C := by
  rcases hb with h0 | h1
  · rw [h0, bitAnd_zero C PU] at h
    exact False.elim (separation C PU h)
  · rw [h1, bitAnd_one C] at h
    exact h

/-- This arbitrary update receives computation axioms only, never uniqueness. -/
def latchUpdate (t : Term) : Term :=
  encodeTerm (halfTerm .second)
    (andTerm (parityTerm .second)
      (truthTerm (substitute t .first (halfTerm .second))))

def latchTrace (t : Term) : Term :=
  .iter (latchUpdate t) .first (encodeTerm .second oneTerm)

def trace (t : Term) (n a : A) : A := value C (latchTrace t) n a
def latchBit (t : Term) (n a : A) : A := parity C (trace C t n a)

omit PU in
theorem value_latchUpdate (t : Term) (n v : A) :
    value C (latchUpdate t) n v =
      encode C (half C v)
        (bitAnd C (parity C v) (truth C (value C t n (half C v)))) := by
  unfold latchUpdate andTerm truthTerm
  rw [value_encode C, value_select C]
  change encode C (half C v)
      (select C (parity C v) C.zero
        (truth C (value C (substitute t .first (halfTerm .second)) n v))) = _
  rw [value_substitute C]
  rfl

omit PU in
theorem trace_zero (t : Term) (a : A) :
    trace C t C.zero a = encode C a (one C) := C.run_zero _ _

omit PU in
theorem trace_succ (t : Term) (n a : A) :
    trace C t (C.succ n) a = value C (latchUpdate t) n (trace C t n a) :=
  C.run_succ _ _ _

theorem trace_parameter (t : Term) (n a : A) : half C (trace C t n a) = a := by
  have q := constancy C PU (halfTerm (latchTrace t)) a (by
    intro k
    change half C (trace C t (C.succ k) a) = half C (trace C t k a)
    rw [trace_succ C, value_latchUpdate C, half_encode C PU]) n
  change half C (trace C t n a) = half C (trace C t C.zero a) at q
  rw [trace_zero C, half_encode C PU] at q
  exact q

theorem latchBit_is_bit (t : Term) (n a : A) : Bit C (latchBit C t n a) :=
  parity_is_bit C PU _

theorem latchBit_zero (t : Term) (a : A) : latchBit C t C.zero a = one C := by
  unfold latchBit
  rw [trace_zero C, parity_encode C PU _ _ (Or.inr rfl)]

theorem latchBit_succ (t : Term) (n a : A) :
    latchBit C t (C.succ n) a =
      bitAnd C (latchBit C t n a) (truth C (value C t n a)) := by
  unfold latchBit
  rw [trace_succ C, value_latchUpdate C]
  rw [parity_encode C PU _ _
    (bitAnd_is_bit C PU _ _ (parity_is_bit C PU _) (truth_is_bit C PU _))]
  rw [trace_parameter C PU]

theorem latchBit_reflects (t : Term) (n a : A)
    (h : latchBit C t (C.succ n) a = one C) : value C t n a = C.zero := by
  rw [latchBit_succ C PU] at h
  exact truth_reflects C PU _
    (bitAnd_one_right C PU _ _ (latchBit_is_bit C PU t n a) h)

theorem latch_stationary (t : Term) (a : A)
    (step : ∀ n, value C t n a = C.zero → value C t (C.succ n) a = C.zero) :
    ∀ n, latchBit C t (C.succ (C.succ n)) a = latchBit C t (C.succ n) a := by
  intro n
  rw [latchBit_succ C PU t (C.succ n) a]
  rcases latchBit_is_bit C PU t (C.succ n) a with h | h
  · rw [h, bitAnd_zero C PU]
  · have hz := step n (latchBit_reflects C PU t n a h)
    rw [h, hz, truth_zero C, bitAnd_one C]

/-- Contextual zero induction uses only the three fixed uniqueness updates. -/
theorem zero_induction (t : Term) (a : A)
    (base : value C t C.zero a = C.zero)
    (step : ∀ n, value C t n a = C.zero → value C t (C.succ n) a = C.zero) :
    ∀ n, value C t n a = C.zero := by
  let shifted := substitute (parityTerm (latchTrace t)) (.succ .first) .second
  have shifted_value (n : A) :
      value C shifted n a = latchBit C t (C.succ n) a := by
    exact value_substitute C (parityTerm (latchTrace t)) (.succ .first) .second n a
  have constant := constancy C PU shifted a (by
    intro n
    rw [shifted_value, shifted_value]
    exact latch_stationary C PU t a step n)
  intro n
  have one_trace := constant n
  rw [shifted_value, shifted_value] at one_trace
  have first_bit : latchBit C t (C.succ C.zero) a = one C := by
    rw [latchBit_succ C PU, latchBit_zero C PU, base, truth_zero C, bitAnd_one C]
  rw [first_bit] at one_trace
  exact latchBit_reflects C PU t n a one_trace

#print axioms value_substitute
#print axioms separation
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms recursion_uniqueness
#print axioms coverage
#print axioms zero_decision
#print axioms add_right_zero
#print axioms add_right_succ
#print axioms addition_commutes
#print axioms monus_pred_commutes
#print axioms monus_shift
#print axioms monus_zero_right
#print axioms monus_diagonal
#print axioms monus_add_cancel
#print axioms parity_double
#print axioms half_double
#print axioms half_encode
#print axioms parity_encode
#print axioms constancy
#print axioms value_latchUpdate
#print axioms trace_parameter
#print axioms latchBit_succ
#print axioms latchBit_reflects
#print axioms latch_stationary
#print axioms zero_induction

end FiniteUpdateKernel

