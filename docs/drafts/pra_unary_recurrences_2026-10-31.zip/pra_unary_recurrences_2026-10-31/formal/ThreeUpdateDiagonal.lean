import FiniteUpdateKernel
import BooleanDiagonal

/-
Links the finite three-update syntax certificate to the Boolean diagonal proof.
Every scanner is an actual finite Term, and each induction interface is filled
by FiniteUpdateKernel.zero_induction on the displayed finite error term.
No unrestricted induction or uniqueness is assumed in this linkage.
-/

namespace ThreeUpdateDiagonal

open FiniteUpdateKernel

universe u
variable {A : Type u} (C : Model A) (PU : PositiveSchema C)

def arithmetic : BooleanDiagonal.Arithmetic A where
  zero := C.zero
  succ := C.succ
  pred := pred C
  separation := separation C PU
  coverage := coverage C PU
  pred_zero := pred_zero C
  pred_succ := pred_succ C
  select := select C
  select_zero := select_zero C PU
  select_succ := select_succ C
  add := add C
  add_comm := addition_commutes C PU
  add_succ_right := add_right_succ C PU
  monus := monus C
  monus_zero := monus_zero C
  monus_right_zero := monus_zero_right C PU
  monus_succ := monus_succ C
  monus_shift := monus_shift C PU
  monus_cancel := monus_add_cancel C PU
  monus_diagonal := monus_diagonal C PU

def storage : BooleanDiagonal.BitStorage (arithmetic C PU) where
  half := half C
  parity := parity C
  encode := encode C
  parity_bit := parity_is_bit C PU
  half_encode := fun a b _ => half_encode C PU a b
  parity_encode := parity_encode C PU

def zeroTestTerm (t : Term) : Term := selectTerm t oneTerm .zero

def bitErrorTerm (s t : Term) : Term := selectTerm s t (zeroTestTerm t)

def comparisonTerm : Term :=
  selectTerm (monusTerm .first .second)
    (zeroTestTerm (zeroTestTerm (monusTerm .second (.succ .first))))
    (zeroTestTerm (monusTerm .second (.succ .first)))

theorem comparison_value (n a : A) :
    value C comparisonTerm n a =
      BooleanDiagonal.comparisonCode (arithmetic C PU) n a := rfl

def scannerUpdateTerm : Term :=
  encodeTerm (halfTerm .second)
    (andTerm (parityTerm .second)
      (substitute comparisonTerm .first (monusTerm .first (halfTerm .second))))

def scannerTerm : Term :=
  .iter scannerUpdateTerm .first (encodeTerm .second oneTerm)

def rowTerm : Term := parityTerm scannerTerm

theorem scanner_update_value (n v : A) :
    value C scannerUpdateTerm n v =
      BooleanDiagonal.scannerUpdate (arithmetic C PU) (storage C PU)
        (BooleanDiagonal.comparisonCode (arithmetic C PU)) n v := rfl

def scanner : BooleanDiagonal.ScannerData (arithmetic C PU) (storage C PU)
    (BooleanDiagonal.comparisonCode (arithmetic C PU)) where
  state := value C scannerTerm
  state_zero := fun _ => C.run_zero _ _
  state_succ := fun _ _ => C.run_succ _ _ _
  stored_parameter_unique := fun k => constancy C PU (halfTerm scannerTerm) k

def diagonal : BooleanDiagonal.DiagonalData (arithmetic C PU) :=
  BooleanDiagonal.comparisonData (arithmetic C PU) (storage C PU) (scanner C PU)

theorem row_value (n k : A) :
    value C rowTerm n k = (diagonal C PU).row n k := rfl

def rowShiftError : Term :=
  bitErrorTerm (substitute rowTerm (.succ .first) (.succ (.succ .second))) rowTerm

def fullRowTerm : Term := substitute rowTerm (.succ .first) .first

def pairedRowsError : Term :=
  bitErrorTerm
    (andTerm fullRowTerm (substitute fullRowTerm (.succ .first) .second)) oneTerm

def descendingPrefixError : Term :=
  bitErrorTerm (substitute rowTerm (monusTerm .first (.succ .second)) .second)
    oneTerm

def inductionInputs : BooleanDiagonal.InductionInputs (arithmetic C PU) (diagonal C PU)
    where
  row_shift := fun k => zero_induction C PU rowShiftError k
  paired_rows := zero_induction C PU pairedRowsError C.zero
  descending_prefix := fun k => zero_induction C PU descendingPrefixError k

include PU in
/-- Native monus comparison, now completely linked to the finite three-update schema. -/
theorem strict_complement (n a : A) :
    monus C n a ≠ C.zero ↔ monus C a (C.succ n) = C.zero := by
  exact BooleanDiagonal.comparison_complement (arithmetic C PU)
    (storage C PU) (scanner C PU) (inductionInputs C PU) n a

#print axioms arithmetic
#print axioms storage
#print axioms scanner
#print axioms inductionInputs
#print axioms strict_complement

end ThreeUpdateDiagonal
