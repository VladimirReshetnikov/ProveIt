LEAN CERTIFICATE: THREE UNARY RECURRENCES
=======================================

Reproduce with Lean 4.19.0 (only its standard distribution is required):

  ./check.sh /absolute/path/to/lean

The script sets LEAN_PATH to this directory, compiles the six modules in
order, records the axiom audit logs, and writes verification.json. Portable
.olean files can be regenerated from the .lean sources. No external Lean
package, Mathlib, network access, or package download is needed for the checks.

EXACT ASSUMPTIONS

The arithmetic carrier A is arbitrary. No proof inducts on elements of A.
The structural inductions are on finite term or formula syntax.

Term contains two numerical variables, zero, successor, and initialized
iteration. Substitution never enters the immutable stored update descriptor.
Model supplies the two computation equations for EVERY finite update.

PositiveSchema is an explicit HYPOTHESIS and permits arithmetic uniqueness
only for exactly these three descriptors:

  successor(v) = S(v)
  predecessor(v) = p(v)
  identity(v) = v

AllowedUpdate is an inductive predicate with exactly those constructors.
Every uniqueness invocation must furnish a proof of this predicate. The
arbitrary latch and scanner updates are used solely through their computation
equations; they receive no uniqueness instance.

FULLY LINKED CERTIFIED CHAIN

1. FiniteUpdateKernel.lean
   Finite substitution semantics; separation; successor laws; constructor
   coverage; zero decisions; addition and monus identities; parity and half;
   one-number/one-bit coding; constancy; the retained-parameter latch; and
   contextual zero-equation induction for every finite term t(n,a).

2. BooleanDiagonal.lean
   Generic constructive row-scanner and diagonal propagation proof, copied
   unchanged from the supplied binary positive-uniqueness draft. Its
   arithmetic, scanner, and induction assumptions are explicit records.

3. ThreeUpdateDiagonal.lean
   Instantiates EVERY record in (2) from (1). Scanner updates and the three
   induction-error families are explicit finite Term values. Its theorem
   strict_complement proves

     M(n,a) != 0 <-> M(a,S(n)) = 0

   directly from Model + the exact three-update PositiveSchema. There is
   no unlinked induction or uniqueness assumption.

4. SuccessorReflection.lean
   New generic constructive reconstruction argument, with explicit local
   arithmetic assumptions and just one specified zero-induction instance
   plus one specified successor-uniqueness instance. It derives native
   equality reflection using R(n,a)=M(M(n,a),a)+M(a,n), with R(n,a)=n.

5. ThreeUpdateReflection.lean
   Instantiates EVERY assumption in (4) from the preceding linked modules.
   Its bound and reconstruction functions are explicit finite Term values.
   It proves error-term reflection, native equality decidability, and
   contextual induction for arbitrary term equations s(n,a)=t(n,a).

6. ThreeUpdateFormulas.lean
   Defines finite quantifier-free Formula syntax: equality, falsehood,
   conjunction, disjunction, implication. Negation and truth are their
   standard abbreviations. Its finite errorTerm compiler is proved correct
   constructively. It derives formula decidability and contextual
   quantifier_free_induction for every such formula with one fixed numerical
   parameter. The only arithmetic assumptions are Model + PositiveSchema.

VERIFICATION SCOPE

The linked machine certificate reaches arbitrary finite quantifier-free
formulas with one fixed numerical parameter. It does not formalize the full
first-order derivation calculus, the tuple-pairing construction, arbitrary
finite parameter elimination, or the complete conservative-definitional-
equivalence metatheorem. These remaining steps have written proofs in the
paper. This distinction is a scope statement, not an additional axiom.

All hypotheses remain explicit theorem parameters. The 64 printed declaration
audits all state that the theorem does not depend on any axioms. In particular
no audited proof uses sorryAx, Classical.choice, or propext. "No axioms" does
not mean that Model or PositiveSchema was proved from pure logic: these are
the stipulated arithmetic theory assumptions, visible in the theorem types.

PROVENANCE

FiniteUpdateKernel.lean substantially adapts PositiveUniqueness.lean from the
supplied binary positive-uniqueness archive. This version restricts arithmetic
uniqueness to the three exact descriptors and replaces the former arbitrary-
update zero-induction proof with the new latch/constancy construction.
BooleanDiagonal.lean is reused unchanged and linked without residual proof
interfaces by ThreeUpdateDiagonal.lean. The reconstruction proof, reflection
linkage, and formula compiler are newly checked for the three-update basis.

HELPER PRESENTATIONS

The finite kernel retains the earlier addition-based selector, while the
manuscript uses the seeded selector P(B(z,S(u)),v). Both have the same
constructor branches, and constructor coverage identifies their values.
The certificate defines doubling directly by an iterator with update S(S(v));
the manuscript uses a+a. Both supply the same zero and double-successor
equations used in the bit-retraction proof. These are helper choices inside
the same finite language, not extra arithmetic assumptions or extra allowed
uniqueness updates. In particular S(S(v)) is used for computation only.

AUDIT COUNTS

  FiniteUpdateKernel       26
  BooleanDiagonal          11
  ThreeUpdateDiagonal       5
  SuccessorReflection      13
  ThreeUpdateReflection     6
  ThreeUpdateFormulas        3
  Total                    64
