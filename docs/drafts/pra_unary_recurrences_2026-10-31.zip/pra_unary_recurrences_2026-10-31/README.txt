PRA FROM THREE UNARY RECURRENCES
31 October 2026

MAIN RESULT

The same arithmetic basis axiomatizes classical and intuitionistic PRA:
all binary initialized-iterator computation equations, plus positive
uniqueness with one numerical parameter and only three fixed unary
updates -- successor, predecessor, and identity.

The computation language still allows every finite counter/state update;
it does not allow a separately accessible frozen parameter. Arbitrary
updates used for computation do NOT receive additional uniqueness axioms.

This closes the restricted-language gap left open in the current
unnumbered positive-uniqueness draft. In the same binary language and
one-parameter discipline, the equivalent uniform unary schema has 38
schematic AST nodes, compared with 39 for the current counter-dependent
binary schema. Both have four equality occurrences. The deeper reduction
is replacing every arithmetic update by three fixed descriptions.

The new proof ingredients are:
  * A number-plus-bit latch deriving zero-equation induction using only
    identity-update uniqueness.
  * Reconstruction M(M(n,a),a) + M(a,n) = n, proved by showing the left
    side starts at zero and follows the successor recurrence. Here
    M(n,a) denotes truncated a-n.

Equality reflection, quantifier-free induction, parameter coding, and
ordinary primitive recursion follow constructively. The complete written
proof is in the paper; the source rebuilds with ordinary pdfLaTeX.

CONTENTS

  pra_unary_recurrences.tex/.pdf   Main paper and compiled output
  sections/*.tex                  Complete proof sections
  axioms.txt                      Exact standalone axiom specification
  formal/*.lean                   Six linked Lean 4.19 certificates
  formal/check.sh                 Reproducible dependency-ordered build
  formal/*.log                    Compiler outputs and 64 axiom audits
  formal/verification.json        Machine-readable verification summary
  artifacts/*.py                  Formula counts and bounded diagnostics
  artifacts/*.json                Recorded outputs
  audit/source_manifest.json      Six-source immutable provenance
  audit/*.txt                     Independent proof/review notes
  SHA256SUMS                     Final deliverable checksums

VERIFICATION SCOPE

The linked endpoint
  ThreeUpdateFormulas.quantifier_free_induction
derives contextual induction for arbitrary finite quantifier-free formulas
in variables n,a. Its only arithmetic hypotheses are the precise finite-
syntax computation Model and the three-update PositiveSchema. There are
no unlinked abstract induction assumptions at this endpoint.

All six Lean modules compile with Lean 4.19.0 without Mathlib or external
packages. All 64 printed global-axiom audits report no axioms: no sorryAx,
Classical.choice, or propext. The intended arithmetic hypotheses remain
explicit theorem parameters; 'no global axioms' does not remove them.

The formal endpoint does NOT claim the complete object-language derivability
or conservative-extension theorem. Tuple pairing, arbitrary parameter
recovery, translation of all primitive-recursion descriptions, and that
metatheorem have full written proofs in the paper. Numerical diagnostics
are finite regression checks, not substitutes for the written or Lean proofs.

REBUILD

From this directory, run:

  pdflatex -interaction=nonstopmode -halt-on-error pra_unary_recurrences.tex
  pdflatex -interaction=nonstopmode -halt-on-error pra_unary_recurrences.tex

For the formal certificates:

  bash formal/check.sh /absolute/path/to/lean

The executable must be Lean 4.19.0. The script sets LEAN_PATH, builds all
six modules in order, records logs, and verifies their axiom audits.

For the independent checks:

  python3 artifacts/check_restricted_update_metrics.py
  python3 artifacts/check_constructions.py

These scripts use only the Python 3 standard library.

SOURCE COMPARISON

All six archives in ProveIt docs/drafts were inspected at commit
60cefaa503c2a54dacf2fd03e75c68f9c2c65d80. Their Git blob hashes were checked.
The docs/incoming inventory and index were checked for relevant PRA material;
unrelated Turing-machine archives were not unpacked. Exact identities are
in audit/source_manifest.json.

The binary iterator grammar, positive exception, bit encoding, Boolean
diagonal argument, and triangular completion build on those drafts.
The new latch, successor reconstruction, restricted-update theorem,
and linked finite-syntax proof are the contribution of this package.
See formal/README.txt for certificate provenance and adaptations.

No absolute minimality or historical-priority claim is made.
