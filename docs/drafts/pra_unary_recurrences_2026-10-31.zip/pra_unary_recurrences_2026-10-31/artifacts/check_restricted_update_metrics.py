#!/usr/bin/env python3
"""Recompute schema AST sizes; this is a syntax check, not a proof checker.

One node is charged for each variable, constant, application, equality,
logical connective, bottom, and single-variable quantifier. Bound variable
names are not separate nodes. Program indices are opaque function names.
Schematic f/h calls count their displayed arguments, not substituted bodies.
1 is expanded as S(0); p(x) is expanded as I_counter(x,0).
"""

import json


def node(name, *children):
    return (name, tuple(children))


def size(tree):
    return 1 + sum(map(size, tree[1]))


def occurrences(tree, name):
    return int(tree[0] == name) + sum(occurrences(t, name) for t in tree[1])


zero, n, a, bot = (node(x) for x in ('0', 'n', 'a', 'bottom'))


def suc(t):
    return node('S', t)


one = suc(zero)


def pred(t):
    return node('I_counter', t, zero)


def f(t):
    return node('f', t, a)


def eq(left, right):
    return node('=', left, right)


def all_a(t):
    return node('forall_a', t)


def all_n(t):
    return node('forall_n', t)


def schema(update):
    premise = all_n(eq(f(suc(suc(n))), update(n, f(suc(n)))))
    separation = node('implies', eq(zero, one), bot)
    comparison = eq(f(n), node('I_h', pred(n), f(one)))
    positive = all_n(node('or', eq(n, zero), comparison))
    return all_a(node('implies', premise, node('and', separation, positive)))


updates = {
    'old_binary_update': lambda k, v: node('h', k, v),
    'uniform_unary_update': lambda k, v: node('h', v),
    'fixed_identity_update': lambda k, v: v,
    'fixed_successor_update': lambda k, v: suc(v),
    'fixed_predecessor_update': lambda k, v: pred(v),
}

d0 = all_a(eq(node('I_h', zero, a), a))
ds = all_a(all_n(eq(node('I_h', suc(n), a),
                     node('h', n, node('I_h', n, a)))))
assert (size(d0), size(ds)) == (6, 12)

report = {
    'metric': 'expanded schematic formula AST; description indices opaque',
    'common_computation': {'D0_nodes': size(d0), 'DS_nodes': size(ds),
                           'total_nodes': size(d0) + size(ds)},
    'arithmetic': {},
    'verification_scope': 'Exact finite syntax counts only; no theory-equivalence claim.',
}
expected = (39, 38, 37, 38, 39)
for (name, update), expected_size in zip(updates.items(), expected, strict=True):
    tree = schema(update)
    assert size(tree) == expected_size
    assert occurrences(tree, '=') == 4
    assert sum(occurrences(tree, q) for q in ('forall_a', 'forall_n')) == 3
    report['arithmetic'][name] = {
        'nodes': size(tree),
        'equality_occurrences': occurrences(tree, '='),
        'quantifier_occurrences': 3,
        'with_common_computation_nodes': size(tree) + size(d0) + size(ds),
    }

print(json.dumps(report, indent=2))
