#!/usr/bin/env python3
"""Independent finite diagnostics. These do not prove theory equivalence."""

from itertools import product
import json


def predecessor(n):
    return max(n - 1, 0)


def monus(n, a):
    return max(a - n, 0)


def selector(z, u, v):
    return u if z == 0 else v


def encode(a, b):
    assert b in (0, 1)
    return 2 * a + b


def reconstruction(n, a):
    return monus(monus(n, a), a) + monus(a, n)


def latch_trace(values, parameter):
    state = encode(parameter, 1)
    history = [state]
    for value in values:
        retained, bit = state // 2, state % 2
        state = encode(retained, bit * value)
        history.append(state)
    return history


def main():
    count = 0
    for n, a in product(range(81), repeat=2):
        assert monus(a, monus(n, a)) == 0
        assert (monus(n, a) != 0) == (monus(a, n + 1) == 0)
        assert reconstruction(n, a) == n
        assert reconstruction(n + 1, a) == reconstruction(n, a) + 1
        assert (monus(n, a) + monus(a, n) == 0) == (n == a)
        count += 1

    latch_count = 0
    for values in product((0, 1), repeat=9):
        for a in (0, 1, 7, 25):
            trace = latch_trace(values, a)
            assert all(state // 2 == a for state in trace)
            bits = [state % 2 for state in trace]
            for i, value in enumerate(values):
                assert bits[i + 1] == bits[i] * value
                if i + 1 < len(values) and (value == 0 or values[i + 1] == 1):
                    assert bits[i + 2] == bits[i + 1]
            if values[0] == 1 and all(x == 0 or y == 1
                                     for x, y in zip(values, values[1:])):
                assert all(b == 1 for b in bits)
                assert all(b == 1 for b in values)
            latch_count += 1

    # A minimal finite term descriptor checker: applications substitute
    # their arguments, while iterator descriptions have separate scopes.
    def var(name):
        return ("var", name)

    def app(name, *arguments):
        return ("app", name, arguments)

    def free(term):
        if term[0] == "var":
            return {term[1]}
        return set().union(*(free(t) for t in term[2]))

    k, v = var("k"), var("v")
    half = app("half", v)
    latch = app("encode", half,
                app("and", app("parity", v),
                    app("zero_test", app("f", k, half))))
    scanner = app("encode", half,
                  app("and", app("parity", v),
                      app("Q", k, app("monus", k, half))))
    assert free(latch) == {"k", "v"}
    assert free(scanner) == {"k", "v"}
    for update in (app("S", v), app("P", v, app("zero")), v):
        assert free(update) == {"v"}

    report = {
        "status": "passed",
        "scope": "Bounded numerical diagnostics and concrete free-variable checks only",
        "not_a_proof_of": "Universal axiomatization or conservative equivalence",
        "reconstruction_pairs": count,
        "reconstruction_range_each_variable": [0, 80],
        "latch_traces": latch_count,
        "latch_bits_per_trace": 9,
        "counter_state_only_descriptors": ["latch", "scanner"],
        "arithmetic_updates_ignore_counter": ["successor", "predecessor", "identity"],
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
