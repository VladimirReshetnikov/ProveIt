#!/usr/bin/env python3
"""Reproduce the numerical tables and publication figures.

Requires mpmath, numpy, matplotlib.  Numerical visualization is separate
from the exact rational interval certificates in certify_table.py.
"""
from pathlib import Path
import csv
import json
import mpmath as mp
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
(ROOT/"figures").mkdir(exist_ok=True)
(ROOT/"data").mkdir(exist_ok=True)
mp.mp.dps = 65
PHI = (mp.sqrt(5)-1)/2
PSI = 1-PHI
C0 = mp.mpf("0.38288525")
K0 = mp.mpf("0.500000008685975")
CS = mp.mpf("0.3828852549667978")


def sum_k_log_k(n):
    return n*mp.loggamma(n+1)-mp.log(mp.barnesg(n+1))


def deficit(n):
    # The identity is S(n)=n ln Gamma(n+1)-ln G(n+1).
    # 65-digit arithmetic avoids loss of precision at the plotted sizes.
    return ((sum_k_log_k(2*n)-2*sum_k_log_k(n)
            -n*(n+1)*mp.log(2))/n**2-mp.log(n))


def bound(n, c=PSI, coefficient=PHI):
    logarithm = mp.log(n)
    d = deficit(n)
    k = mp.mpf(2*(n-1))/n*mp.log(mp.mpf(2*n-1)/(2*n-3))
    return (c*logarithm+coefficient*d+coefficient*k/2)/(logarithm+coefficient*k)


def cap(n, epsilon):
    b = (2*np.arange(1, n+1)-1)/n**2
    lo, hi = b[0], b[-1]
    for _ in range(90):
        t = (lo+hi)/2
        if np.minimum(b, t).sum() < 1-epsilon:
            lo = t
        else:
            hi = t
    return b, np.minimum(b, (lo+hi)/2)


def create_table():
    certificates = json.loads((ROOT/"data"/"table_certificate.json").read_text())
    certified = {x["N"]:x["certified_ceiling"] for x in certificates["certificates"]}
    rows = []
    for n in (60, 100, 1000, 10000, 1000000):
        r = bound(n)
        assert int(mp.ceil(n*r)) == certified[n]
        rows.append({"N": n, "D_N": mp.nstr(deficit(n), 25),
                     "R_N": mp.nstr(r, 25), "guaranteed_count": certified[n],
                     "Costa_Sadhu_constant_count": int(mp.ceil(n*CS))})
    with (ROOT/"data"/"frequency_table.csv").open("w", newline="") as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = [r"\begin{tabular}{rrrr}", r"\toprule",
             r"$N$ & $R_N$ (approx.) & $\lceil NR_N\rceil$ & Constant-only comparison\\",
             r"\midrule"]
    for row in rows:
        lines.append(f"{row['N']:,} & {float(row['R_N']):.7f} & "
                     f"{row['guaranteed_count']:,} & {row['Costa_Sadhu_constant_count']:,}\\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (ROOT/"frequency_table.tex").write_text("\n".join(lines)+"\n")


def figures():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.titleweight": "bold", "savefig.bbox": "tight"})
    sizes = np.unique(np.round(np.geomspace(60, 10**12, 155)).astype(np.int64))
    golden = np.array([float(bound(int(n))) for n in sizes])
    stronger = np.array([float(bound(int(n), C0, K0)) for n in sizes])
    fig, ax = plt.subplots(figsize=(7.0, 3.6))
    ax.plot(sizes, golden, color="#176b91", lw=2.2,
            label="Golden-ratio certificate + structural correction")
    ax.plot(sizes, stronger, color="#ad4c22", lw=2,
            label="Jiang certificate + structural correction")
    ax.axhline(float(CS), color="#66747e", ls="--", lw=1.2,
               label="Costa–Sadhu stated universal constant")
    ax.set_xscale("log")
    ax.set_xlabel("Number of members N")
    ax.set_ylabel("Guaranteed maximum element frequency")
    ax.set_ylim(.3818, .4145)
    ax.grid(alpha=.2)
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    fig.tight_layout()
    fig.savefig(ROOT/"figures"/"frequency_bounds.pdf")
    fig.savefig(ROOT/"figures"/"frequency_bounds.png", dpi=180)
    plt.close(fig)
    n = 12
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.85), sharex=True, sharey=True)
    for ax, leakage in zip(axes, (0, 1/12, 7/18)):
        b, s = cap(n, leakage)
        x = np.arange(1, n+1)
        ax.bar(x, s, color="#176b91", alpha=.85, width=.78)
        ax.plot(x, b, color="#ad4c22", lw=1.2, marker=".", markersize=3)
        ax.set_title(f"Escape probability {leakage:.3f}", fontsize=9)
        ax.set_xlabel("Sorted internal output")
        ax.set_xticks([1, 6, 12])
        ax.grid(axis="y", alpha=.2)
    axes[0].set_ylabel("Output probability")
    axes[0].text(.05, .91, "Line: chain\nBars: capped profile",
                 transform=axes[0].transAxes, fontsize=8, va="top")
    fig.tight_layout()
    fig.savefig(ROOT/"figures"/"capped_profiles.pdf")
    fig.savefig(ROOT/"figures"/"capped_profiles.png", dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    create_table()
    figures()
    print("Created frequency table and two figures.")
