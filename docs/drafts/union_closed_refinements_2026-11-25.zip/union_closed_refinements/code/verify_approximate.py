#!/usr/bin/env python3
"""Exhaustive finite checks of the capped union-entropy theorem.

This is supporting verification, not a proof of the infinite theorem.
Only the Python standard library is required.  All partial-sum and cap
checks use exact integer/Fraction arithmetic; entropy and frequency checks
use double precision, with an explicit numerical tolerance.

Default: every family of at least two subsets of a 4-element ground set
for q=2, and every such family on a 3-element ground set for q=3.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction
from itertools import combinations
import json
import math
from pathlib import Path
import time

TOL = 2e-12
PHI = (math.sqrt(5.0) - 1.0) / 2.0


def union_counts(family: tuple[int, ...], q: int) -> Counter[int]:
    counts = Counter(family)
    for _ in range(1, q):
        nxt: Counter[int] = Counter()
        for u, count in counts.items():
            for a in family:
                nxt[u | a] += count
        counts = nxt
    return counts


def capped_counts(n: int, q: int, inside: int) -> tuple[list[Fraction], Fraction]:
    """Return exact s_j*N**q and t*N**q, with total `inside`."""
    increments = [j ** q - (j - 1) ** q for j in range(1, n + 1)]
    assert n <= inside <= n ** q
    for k in range(n):
        t = Fraction(inside - k ** q, n - k)
        lower = 0 if k == 0 else increments[k - 1]
        upper = increments[k]
        if lower <= t <= upper:
            s = [min(Fraction(b), t) for b in increments]
            assert sum(s) == inside
            assert s == sorted(s)
            return s, t
    raise AssertionError((n, q, inside, "cap not found"))


def entropy_from_counts(counts: list[int], denominator: int) -> float:
    return math.log(denominator) - math.fsum(
        count * math.log(count) for count in counts if count
    ) / denominator


def check_family(family: tuple[int, ...], ground: int, q: int) -> dict:
    n = len(family)
    denominator = n ** q
    counts = union_counts(family, q)
    assert sum(counts.values()) == denominator
    family_set = set(family)
    internal = sorted(counts[a] for a in family)
    external = [c for u, c in counts.items() if u not in family_set]
    outside_count = sum(external)
    inside_count = denominator - outside_count
    s, t = capped_counts(n, q, inside_count)
    cap_prefix = Fraction(0)
    internal_prefix = 0
    for j, (actual, cap) in enumerate(zip(internal, s), start=1):
        internal_prefix += actual
        cap_prefix += cap
        assert internal_prefix <= j ** q, (family, q, j, "prefix")
        assert internal_prefix <= cap_prefix, (family, q, j, "majorization")
    assert internal_prefix == cap_prefix == inside_count
    assert outside_count == 0 or len(external) > 0
    assert len(external) <= sum(math.comb(n, j) for j in range(2, min(q, n) + 1))

    actual_entropy = entropy_from_counts(list(counts.values()), denominator)
    internal_upper = -math.fsum(
        (float(c) / denominator) * math.log(float(c) / denominator) for c in s
    )
    eps = outside_count / denominator
    external_upper = eps * math.log(len(external) / eps) if external else 0.0
    upper = internal_upper + external_upper
    entropy_slack = upper - actual_entropy
    assert entropy_slack >= -TOL, (family, q, "entropy", entropy_slack)
    actual_p = max(sum(bool(a & (1 << x)) for a in family) / n for x in range(ground))
    freq_slack = None
    lower_entropy_slack = None
    if q == 2:
        bound = 1.0 - PHI * upper / math.log(n)
        freq_slack = actual_p - bound
        lower_entropy_slack = actual_entropy - (1.0 - actual_p) / PHI * math.log(n)
        assert freq_slack >= -TOL, (family, "frequency", freq_slack)
        assert lower_entropy_slack >= -TOL, (family, "imported lower entropy", lower_entropy_slack)
    equal_profile = all(Fraction(v) == cap for v, cap in zip(internal, s))
    equal_external = not external or len(set(external)) == 1
    if equal_profile and equal_external:
        assert abs(entropy_slack) <= TOL
    return {
        "n": n, "outside_count": outside_count,
        "equal_entropy": equal_profile and equal_external,
        "entropy_slack": entropy_slack, "frequency_slack": freq_slack,
        "lower_entropy_slack": lower_entropy_slack,
    }


def exhaustive(ground: int, q: int) -> dict:
    started = time.perf_counter()
    universe = tuple(range(1 << ground))
    total = 0
    closed = 0
    equal = 0
    min_entropy_slack = float("inf")
    min_frequency_slack = float("inf")
    min_lower_entropy_slack = float("inf")
    by_size: dict[int, int] = Counter()
    for size in range(2, len(universe) + 1):
        for family in combinations(universe, size):
            result = check_family(family, ground, q)
            total += 1
            by_size[size] += 1
            closed += result["outside_count"] == 0
            equal += result["equal_entropy"]
            min_entropy_slack = min(min_entropy_slack, result["entropy_slack"])
            if q == 2:
                min_frequency_slack = min(min_frequency_slack, result["frequency_slack"])
                min_lower_entropy_slack = min(min_lower_entropy_slack, result["lower_entropy_slack"])
    assert total == (1 << len(universe)) - 1 - len(universe)
    return {
        "ground_set_size": ground,
        "number_of_samples_q": q,
        "families_checked": total,
        "families_with_zero_leakage": closed,
        "families_attaining_entropy_upper_bound": equal,
        "families_by_size": dict(sorted(by_size.items())),
        "exact_prefix_and_cap_majorization": "passed",
        "entropy_checks": "passed",
        "frequency_checks": "passed" if q == 2 else "not applicable",
        "minimum_entropy_slack_float": min_entropy_slack,
        "minimum_frequency_slack_float": min_frequency_slack if q == 2 else None,
        "minimum_imported_lower_entropy_slack_float": min_lower_entropy_slack if q == 2 else None,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }


def sharp_family(n: int, ell: int) -> tuple[int, ...]:
    a = n - ell
    core_size = max(0, a - 1)
    core = (1 << core_size) - 1
    lower = [(1 << i) - 1 for i in range(a)]
    d = ((1 << ell) - 1) << core_size
    maxima = [core | (d ^ (1 << (core_size + i))) for i in range(ell)]
    return tuple(lower + maxima)


def check_sharp_examples() -> dict:
    count = 0
    for n in range(2, 21):
        for ell in range(2, n + 1):
            for q in (2, 3, 4, 5):
                family = sharp_family(n, ell)
                ground = max(family).bit_length()
                r = check_family(family, ground, q)
                a = n - ell
                expected_outside = n ** q - (a ** q + ell * ((a + 1) ** q - a ** q))
                assert r["outside_count"] == expected_outside
                assert r["equal_entropy"]
                if q == 2:
                    assert expected_outside == ell * (ell - 1)
                count += 1
    return {"examples_checked": count, "N_range": [2, 20], "q_values": [2, 3, 4, 5],
            "all_predicted_leakages_exact": True, "all_entropy_equalities_verified": True}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("approximate_results.json"))
    args = parser.parse_args()
    results = {
        "description": "Capped-profile entropy theorem supporting finite verification",
        "arithmetic": {"majorization": "exact integers and fractions.Fraction",
                       "entropy": "Python float, natural logarithms", "tolerance": TOL},
        "scope_note": "Finite verification supports but does not prove the general theorem or establish novelty.",
        "exhaustive_checks": [exhaustive(4, 2), exhaustive(3, 3)],
        "sharp_examples": check_sharp_examples(),
    }
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
