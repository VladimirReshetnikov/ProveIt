#!/usr/bin/env python3
"""Exact finite checks of odd/even discrete capped union-entropy profiles.

Run from any directory with Python >=3.9.  This script imports its sibling
verify_approximate.py (both files use only the standard library).  It does
not rely on that file's exhaustive results: each union distribution is
recomputed here.  Finite checks are evidence, not the general proof.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
from itertools import combinations
import json
import math
from pathlib import Path
import time
from verify_approximate import union_counts, capped_counts, entropy_from_counts, PHI, TOL


def discrete_profiles(n: int, outside_count: int, m: int) -> tuple[list[int], list[int]]:
    assert outside_count >= 0 and outside_count % 2 == 0
    inside = n * n - outside_count
    assert inside >= n and (inside - n) % 2 == 0
    z = (inside - n) // 2
    c = max(k for k in range(n) if k * n - k * (k + 1) // 2 <= z)
    r = z - (c * n - c * (c + 1) // 2)
    assert r == 0 if c == n - 1 else 0 <= r < n - c - 1
    u = list(range(1, 2 * c, 2)) + [2 * c + 1] * (n - c - r) + [2 * c + 3] * r
    assert len(u) == n and sum(u) == inside
    assert u == sorted(u) and all(x > 0 and x % 2 == 1 for x in u)
    assert all(sum(u[:j]) <= j * j for j in range(1, n + 1))
    half = outside_count // 2
    if not half:
        assert m == 0
        return u, []
    assert 1 <= m <= half
    b, s = divmod(half, m)
    v = [2 * b] * (m - s) + [2 * b + 2] * s
    assert sum(v) == outside_count
    return u, v


def check_family(family: tuple[int, ...], ground: int) -> dict:
    n = len(family)
    counts = union_counts(family, 2)
    inside = sorted(counts[a] for a in family)
    family_set = set(family)
    outside = sorted(c for a, c in counts.items() if a not in family_set)
    assert all(x % 2 == 1 for x in inside)
    assert all(x % 2 == 0 for x in outside)
    u, v = discrete_profiles(n, sum(outside), len(outside))
    ai = ui = 0
    for a, x in zip(inside, u):
        ai += a
        ui += x
        assert ai <= ui, (family, "internal discrete majorization", inside, u)
    assert ai == ui
    ai = ui = 0
    for a, x in zip(outside, v):
        ai += a
        ui += x
        assert ai <= ui, (family, "external discrete majorization", outside, v)
    assert ai == ui
    denominator = n * n
    actual_entropy = entropy_from_counts(list(counts.values()), denominator)
    discrete_entropy = entropy_from_counts(u + v, denominator)
    real_u, _ = capped_counts(n, 2, sum(inside))
    epsilon = sum(outside) / denominator
    real_entropy = -math.fsum(
        float(x) / denominator * math.log(float(x) / denominator) for x in real_u
    ) + (epsilon * math.log(len(outside) / epsilon) if outside else 0.0)
    discrete_slack = discrete_entropy - actual_entropy
    improvement = real_entropy - discrete_entropy
    assert discrete_slack >= -TOL, (family, "discrete entropy", discrete_slack)
    assert improvement >= -TOL, (family, "continuous comparison", improvement)
    p = max(sum(bool(a & (1 << x)) for a in family) / n for x in range(ground))
    bound = 1 - PHI * discrete_entropy / math.log(n)
    assert p >= bound - TOL
    strict = any(Fraction(x) != y for x, y in zip(u, real_u)) or (outside and (sum(outside) // 2) % len(outside) != 0)
    if strict:
        assert improvement > 0.0
    return {
        "family_as_bitmasks": list(family),
        "internal_counts": inside, "external_counts": outside,
        "discrete_internal_profile": u, "discrete_external_profile": v,
        "actual_entropy": actual_entropy, "discrete_upper_entropy": discrete_entropy,
        "continuous_upper_entropy": real_entropy,
        "entropy_slack": discrete_slack, "improvement": improvement,
        "strict_improvement_exact": bool(strict),
        "discrete_bound_attained_exact": inside == u and outside == v,
        "frequency_lower_bound": bound, "actual_maximum_frequency": p,
    }


def exhaustive() -> dict:
    start = time.perf_counter()
    total = equal = strict = strict_equal = 0
    min_slack = float("inf")
    min_positive_improvement = float("inf")
    max_improvement = 0.0
    max_example = None
    for n in range(2, 17):
        for family in combinations(range(16), n):
            result = check_family(family, 4)
            total += 1
            equal += result["discrete_bound_attained_exact"]
            strict += result["strict_improvement_exact"]
            strict_equal += result["strict_improvement_exact"] and result["discrete_bound_attained_exact"]
            min_slack = min(min_slack, result["entropy_slack"])
            if result["strict_improvement_exact"]:
                min_positive_improvement = min(min_positive_improvement, result["improvement"])
            if result["improvement"] > max_improvement:
                max_improvement = result["improvement"]
                max_example = result
    assert total == 65519
    return {
        "ground_set_size": 4, "families_checked": total,
        "exact_odd_even_and_majorization_checks": "passed",
        "floating_entropy_and_frequency_checks": "passed",
        "families_attaining_discrete_bound": equal,
        "families_with_strict_improvement_over_continuous_bound": strict,
        "families_attaining_discrete_bound_with_strict_continuous_improvement": strict_equal,
        "minimum_entropy_slack_float": min_slack,
        "minimum_positive_entropy_improvement": min_positive_improvement,
        "maximum_entropy_improvement": max_improvement,
        "maximum_improvement_example": max_example,
        "elapsed_seconds": round(time.perf_counter() - start, 3),
    }


def branch_family(c: int, pairs: int, singles: int) -> tuple[int, ...]:
    core_size = max(0, c - 1)
    core = (1 << core_size) - 1
    members = [(1 << i) - 1 for i in range(c)]
    bit = core_size
    for _ in range(pairs):
        members.extend((core | (1 << bit), core | (1 << bit) | (1 << (bit + 1))))
        bit += 2
    for _ in range(singles):
        members.append(core | (1 << bit))
        bit += 1
    return tuple(members)


def verify_examples() -> dict:
    count = 0
    for c in range(6):
        for pairs in range(1, 6):
            for singles in range(6):
                if pairs + singles < 2:
                    continue
                family = branch_family(c, pairs, singles)
                result = check_family(family, max(family).bit_length())
                assert result["discrete_bound_attained_exact"]
                assert result["strict_improvement_exact"]
                assert set(result["external_counts"]) == {2}
                count += 1
    return {
        "infinite_family_instances_checked": count,
        "all_exact_equalities_verified": True,
        "all_strict_continuous_improvements_verified": True,
        "internal_parity_example": check_family((1, 2, 6), 3),
        "external_parity_example": check_family((7, 9, 10), 4),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("discrete_results.json"))
    args = parser.parse_args()
    results = {
        "description": "Discrete odd/even capped-profile entropy theorem supporting finite verification",
        "arithmetic": {"counts_and_majorization": "exact integers", "continuous_cap_comparison": "fractions.Fraction", "entropy": "Python float, natural logarithms", "tolerance": TOL},
        "scope_note": "Finite verification supports but does not prove the general theorem or establish novelty.",
        "exhaustive": exhaustive(), "sharp_examples": verify_examples(),
    }
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
