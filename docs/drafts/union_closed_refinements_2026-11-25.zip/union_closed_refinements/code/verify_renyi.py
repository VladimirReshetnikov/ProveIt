#!/usr/bin/env python3
"""Exhaustive checks of the sharp nonchain Renyi entropy theorem.

Only the Python standard library is required.  Every nonempty subfamily
of the four-element power set is considered, and all nonchain
union-closed families are checked.  The profile/equality tests use exact
integer arithmetic.  Real-valued entropy tests use ordinary floating
point and are sanity checks, not formal proofs or interval certificates.

Run from any directory:
    python3 verify_renyi.py --output renyi_verification_results.json
"""

from __future__ import annotations

import argparse
import json
import math
from itertools import combinations
from pathlib import Path


def verify(ground_size: int = 4) -> dict:
    if not 1 <= ground_size <= 4:
        raise ValueError("This exhaustive checker supports ground sizes 1 to 4.")
    alphas = [0.25, 0.5, 1.5, 2.0, 3.0, 4.0]
    universe_size = 1 << ground_size
    n_nonchain = 0
    n_exact = 0
    n_real = 0
    max_positive_violation = 0.0
    max_equality_residual = 0.0
    min_strict_gap = math.inf
    equality_counts = {str(a): 0 for a in alphas}
    profile_counts: dict[str, int] = {}
    tolerance = 1e-11

    for family_mask in range(1, 1 << universe_size):
        family = [a for a in range(universe_size) if family_mask >> a & 1]
        n = len(family)
        if n < 3:
            continue
        if any(not (family_mask >> (a | b) & 1) for a in family for b in family):
            continue
        incomparable = [(a, b) for a, b in combinations(family, 2)
                        if (a | b) not in (a, b)]
        if not incomparable:
            continue
        n_nonchain += 1

        representation = {a: 0 for a in family}
        for a in family:
            for b in family:
                representation[a | b] += 1
        sorted_representation = sorted(representation.values())
        chain = [2 * i - 1 for i in range(1, n + 1)]

        # A single incomparable pair occurs after exactly k-2 common
        # lower members.  The theorem asserts that these form a chain
        # and every other member above the pair forms the upper chain.
        actual_position = None
        if len(incomparable) == 1:
            a, b = incomparable[0]
            common_lower = sum(x != a and x != b and (x | a) == a
                               and (x | b) == b for x in family)
            actual_position = common_lower + 2
            key = f"N={n},k={actual_position}"
            profile_counts[key] = profile_counts.get(key, 0) + 1

        for k in range(2, n):
            cover = chain.copy()
            cover[k - 1] -= 2
            cover[k] += 2
            if (sorted_representation == cover) != (actual_position == k):
                raise AssertionError({"family": family, "k": k,
                                      "counts": sorted_representation,
                                      "actual_position": actual_position})
            n_exact += 1

        for alpha in alphas:
            extremal_position = 2 if alpha > 2 else n - 1
            cover = chain.copy()
            cover[extremal_position - 1] -= 2
            cover[extremal_position] += 2
            actual = (math.log(sum(x ** alpha for x in sorted_representation))
                      - 2 * alpha * math.log(n)) / (1 - alpha)
            bound = (math.log(sum(x ** alpha for x in cover))
                     - 2 * alpha * math.log(n)) / (1 - alpha)
            gap = bound - actual
            max_positive_violation = max(max_positive_violation, -gap)
            if gap < -tolerance:
                raise AssertionError({"family": family, "alpha": alpha,
                                      "actual": actual, "bound": bound})

            expected_equality = (actual_position is not None) if alpha == 2 \
                else (actual_position == extremal_position)
            if (abs(gap) < tolerance) != expected_equality:
                raise AssertionError({"family": family, "alpha": alpha,
                                      "gap": gap,
                                      "actual_position": actual_position})
            if expected_equality:
                equality_counts[str(alpha)] += 1
                max_equality_residual = max(max_equality_residual, abs(gap))
            else:
                min_strict_gap = min(min_strict_gap, gap)
            n_real += 1

    return {
        "status": "passed",
        "ground_size": ground_size,
        "subfamilies_considered": (1 << universe_size) - 1,
        "nonchain_union_closed_families": n_nonchain,
        "exact_integer_profile_equivalence_checks": n_exact,
        "renyi_orders": alphas,
        "floating_entropy_and_equality_checks": n_real,
        "logarithm_base": "natural; entropy in nats",
        "floating_tolerance": tolerance,
        "max_positive_bound_violation": max_positive_violation,
        "max_equality_residual": max_equality_residual,
        "minimum_observed_strict_gap": None if math.isinf(min_strict_gap)
                                         else min_strict_gap,
        "equality_counts_by_order": equality_counts,
        "single_incomparable_pair_counts": profile_counts,
        "scope": {
            "exact": "profile equality if and only if stated order structure",
            "floating": "Renyi bounds and equality sanity checks only",
            "proof": "general theorems are proved analytically in the report",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ground-size", type=int, default=4)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = verify(args.ground_size)
    encoded = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(encoded, end="")


if __name__ == "__main__":
    main()
