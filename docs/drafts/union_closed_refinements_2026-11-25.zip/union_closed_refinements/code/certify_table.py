#!/usr/bin/env python3
"""Rational interval certificate for the displayed finite-size integer bounds.

No third-party packages are required.  Every endpoint in this calculation is
a Fraction.  Logarithms are enclosed by the atanh series with an explicit
geometric tail; sqrt(5) is enclosed using integer square root.

For N > 1000 we use the proved midpoint remainder bound
  0 <= (ln 2 - 1/2) - D_N
    <= [(ln 2 - 1/2) + (1 + ln(N-1))/12] / N^2.
The first cell has exact error (ln 2 - 1/2)/N^2; for subsequent cells use
f''(x)=2/x and midpoint error <= sup(f'')/(24 N^3), then H_(N-1)<=1+ln(N-1).
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import argparse
import json


@dataclass(frozen=True)
class Interval:
    lo: Q
    hi: Q

    @classmethod
    def point(cls, value):
        return cls(Q(value), Q(value))

    def __add__(self, other):
        other = as_interval(other)
        return Interval(self.lo + other.lo, self.hi + other.hi)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + (-as_interval(other))

    def __rsub__(self, other):
        return as_interval(other) - self

    def __mul__(self, other):
        other = as_interval(other)
        values = [a*b for a in (self.lo, self.hi)
                         for b in (other.lo, other.hi)]
        return Interval(min(values), max(values))

    __rmul__ = __mul__

    def __truediv__(self, other):
        other = as_interval(other)
        if other.lo <= 0 <= other.hi:
            raise ZeroDivisionError("Interval contains zero")
        return self * Interval(1/other.hi, 1/other.lo)


def as_interval(value):
    return value if isinstance(value, Interval) else Interval.point(value)


def log_between_one_and_two(x, terms=36):
    assert Q(1) <= x <= Q(2)
    y = (x-1)/(x+1)
    power = y
    total = Q(0)
    for j in range(terms):
        total += power / (2*j+1)
        power *= y*y
    remainder = 2*power / ((2*terms+1)*(1-y*y))
    return Interval(2*total, 2*total + remainder)


LN2 = log_between_one_and_two(Q(2))


def log_q(x):
    x = Q(x)
    assert x > 0
    exponent = 0
    while x < 1:
        x *= 2
        exponent -= 1
    while x >= 2:
        x /= 2
        exponent += 1
    return exponent*LN2 + log_between_one_and_two(x)


def sqrt5():
    scale = 10**40
    n = isqrt(5*scale*scale)
    return Interval(Q(n, scale), Q(n+1, scale))


PHI = (sqrt5()-1)/2
PSI = 1-PHI


def entropy_deficit(n):
    if n <= 1000:
        result = Interval.point(0)
        for j in range(1, n+1):
            result += Q(2*j-1, n*n)*log_q(Q(2*j-1, n))
        return result, "exact finite sum with rational logarithm enclosures"
    limit = LN2-Q(1, 2)
    error = (limit+(1+log_q(n-1))/12)/(n*n)
    return Interval(limit.lo-error.hi, limit.hi), "proved midpoint remainder bound"


def ceil_q(x):
    return -((-x.numerator)//x.denominator)


def outward_decimal(x, lower, places=18):
    scale = 10**places
    numerator = x*scale
    integer = numerator.numerator//numerator.denominator
    if not lower and numerator.denominator != 1:
        integer += 1
    sign = "-" if integer < 0 else ""
    integer = abs(integer)
    return f"{sign}{integer//scale}.{integer%scale:0{places}d}"


def summary(interval):
    return {"lower": outward_decimal(interval.lo, True),
            "upper": outward_decimal(interval.hi, False)}


def certify(n):
    d, method = entropy_deficit(n)
    logarithm = log_q(n)
    k = Q(2*(n-1), n)*log_q(Q(2*n-1, 2*n-3))
    result = (PSI*logarithm + PHI*d + PHI*k/2)/(logarithm + PHI*k)
    count = result*n
    lower_count, upper_count = ceil_q(count.lo), ceil_q(count.hi)
    assert lower_count == upper_count, (n, summary(count))
    return {"N": n, "D_N": summary(d), "D_N_method": method,
            "R_N": summary(result), "N_times_R_N": summary(count),
            "certified_ceiling": lower_count,
            "interval_ceiling_is_unique": True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1]/"data"/"table_certificate.json")
    args = parser.parse_args()
    result = {"status": "PASS", "arithmetic": "exact rational intervals",
              "log_terms": 36, "sqrt5_decimal_scale_digits": 40,
              "certificates": [certify(n) for n in (60, 100, 1000, 10000, 1000000)]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
