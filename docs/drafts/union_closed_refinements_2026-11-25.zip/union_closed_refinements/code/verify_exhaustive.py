#!/usr/bin/env python3
"""Independent finite checks for the union-entropy research note.

This script checks every set family on at most four labelled elements, and
additional reproducible randomly generated union-closed families.  Counting,
closure, majorization, cover comparisons, and structural equality checks use
Python integers.  Entropy, logarithmic identities, and frequency estimates use
ordinary floating-point arithmetic: these are sanity checks, NOT interval
certificates or substitutes for the written proofs.

Run with Python 3.10 or later; no third-party dependency is required:

    python verify_exhaustive.py --output verification_results.json

An element of a ground set is a bit position.  A member set is an integer
bitmask, and a family is a set of integer bitmasks.  Boolean OR implements union.
"""

from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path
import platform
import random
import sys
import time


PHI = (math.sqrt(5.0) - 1.0) / 2.0
PSI = 1.0 - PHI
TOL = 2e-11


def require(condition: bool, claim: str, family: list[int]) -> None:
    if not condition:
        raise AssertionError(f"{claim}; family={family}")


def majorizes_ascending(x: list[int], y: list[int]) -> bool:
    """Integer test, with both vectors explicitly sorted in ascending order."""
    if len(x) != len(y) or sum(x) != sum(y):
        return False
    sx = sy = 0
    for a, b in zip(sorted(x), sorted(y)):
        sx += a
        sy += b
        if sx > sy:
            return False
    return True


def cover(n: int, k: int) -> list[int]:
    """c^(k), with k one-based: transfer two from position k to k+1."""
    assert 2 <= k <= n - 1
    out = [2 * j - 1 for j in range(1, n + 1)]
    out[k - 1] -= 2
    out[k] += 2
    assert out == sorted(out)
    return out


def new_stats() -> dict:
    return {
        "families_checked": 0,
        "chain_families": 0,
        "nonchain_families": 0,
        "sharp_topfork_families": 0,
        "sizes": Counter(),
        "max_kl_flow_identity_abs_residual": 0.0,
        "max_rank_flow_integer_residual": 0,
        "minimum_golden_refined_bound_slack": None,
        "minimum_golden_refined_bound_slack_family": None,
        "minimum_nonchain_entropy_gap_slack": None,
        "minimum_entropy_lower_bound_slack": None,
    }


def inspect_family(raw_family: set[int], ground_size: int, stats: dict) -> None:
    """Build all representations directly and test independent consequences."""
    f = sorted(raw_family, key=lambda a: (a.bit_count(), a))
    n = len(f)
    assert n >= 2
    index = {a: j for j, a in enumerate(f)}
    r = [0] * n
    incomparable = []
    rank_work = 0

    # This loop also checks closure independently of the construction.
    for a in f:
        for b in f:
            require((a | b) in raw_family, "union closure", f)
            r[index[a | b]] += 1

    for i, a in enumerate(f):
        for j in range(i + 1, n):
            b = f[j]
            if (a | b) not in (a, b):
                k = index[a | b]
                require(k > j, "incomparable union is later", f)
                incomparable.append((i, j, k))
                rank_work += k - j

    count_i = len(incomparable)
    b = [2 * j + 1 for j in range(n)]
    rs = sorted(r)
    require(sum(r) == n * n, "total ordered representations", f)
    require(all(x >= 1 and x % 2 == 1 for x in r), "positive odd counts", f)
    require(rs[0] == 1, "minimal member has one representation", f)
    require(majorizes_ascending(rs, b), "chain majorization", f)

    # A chain is tested on pairs, independently of the multiplicity vector.
    is_chain = count_i == 0
    require((rs == b) == is_chain, "chain iff chain multiplicity vector", f)

    # Check prefixes in the natural inclusion linear extension, not sorted r.
    cumulative = 0
    for k, value in enumerate(r, 1):
        cumulative += value
        require(cumulative <= k * k, "downset prefix bound", f)

    rank_identity = sum((j + 1) * (r[j] - b[j]) for j in range(n)) - 2 * rank_work
    require(rank_identity == 0, "exact representation-rank flow identity", f)
    stats["max_rank_flow_integer_residual"] = max(
        stats["max_rank_flow_integer_residual"], abs(rank_identity)
    )

    if not is_chain:
        require(n >= 3, "nonchain requires at least three members", f)
        qualifying = [k for k in range(2, n) if majorizes_ascending(rs, cover(n, k))]
        require(bool(qualifying), "nonchain dominates at least one cover", f)
        topfork = count_i == 1 and incomparable[0][2] == n - 1
        require((rs == cover(n, n - 1)) == topfork,
                "sharp topfork iff top cover multiplicities", f)
        if topfork:
            # Independently check the remaining structural description.
            a, c, top = incomparable[0]
            lower = [j for j in range(n) if j not in (a, c, top)]
            require(all((f[j] | f[a]) == f[a] and (f[j] | f[c]) == f[c]
                        for j in lower), "topfork lower chain lies under both arms", f)
            require(all((f[x] | f[y]) in (f[x], f[y]) for x in lower for y in lower),
                    "topfork lower members form a chain", f)
            stats["sharp_topfork_families"] += 1

    # Float-only checks begin here. Natural logarithms are used throughout.
    nn = n * n
    p_union = [x / nn for x in r]
    p_chain = [x / nn for x in b]
    deficit = math.fsum(x * math.log(x * n) for x in p_union)
    chain_deficit = math.fsum(x * math.log(x * n) for x in p_chain)
    kl = math.fsum(x * math.log(x / y) for x, y in zip(p_union, p_chain))
    flow = 2.0 / nn * math.fsum(
        math.log((2 * k + 1) / (2 * j + 1)) for _, j, k in incomparable
    )
    residual = abs(deficit - chain_deficit - kl - flow)
    require(residual <= TOL, "floating KL/flow identity", f)
    require(kl >= -TOL, "floating KL nonnegativity", f)
    stats["max_kl_flow_identity_abs_residual"] = max(
        stats["max_kl_flow_identity_abs_residual"], residual
    )
    require(deficit + TOL >= chain_deficit, "floating entropy chain upper bound", f)

    if not is_chain:
        top_cover = cover(n, n - 1)
        second_deficit = math.fsum((x / nn) * math.log(x / n) for x in top_cover)
        slack = deficit - second_deficit
        require(slack >= -TOL, "floating sharp nonchain entropy upper bound", f)
        old = stats["minimum_nonchain_entropy_gap_slack"]
        stats["minimum_nonchain_entropy_gap_slack"] = slack if old is None else min(old, slack)
        is_topfork = count_i == 1 and incomparable[0][2] == n - 1
        require((abs(slack) <= TOL) == is_topfork,
                "floating sharp nonchain entropy equality iff topfork", f)

    frequencies = [sum(bool(a & (1 << j)) for a in f) for j in range(ground_size)]
    max_count = max(frequencies, default=0)
    p = max_count / n
    # Multiplication by two avoids any half-integer or float ambiguity.
    require(2 * count_i >= (n - 1) * (n - 2 * max_count),
            "exact incomparability versus maximum frequency", f)

    coeff = 2.0 * (n - 1) / n * math.log((2 * n - 1) / (2 * n - 3))
    require(deficit + TOL >= chain_deficit + (2.0 * count_i / nn)
            * math.log((2 * n - 1) / (2 * n - 3)),
            "floating incomparability entropy stability", f)
    ln_n = math.log(n)
    refined = (PSI * ln_n + PHI * chain_deficit + PHI * coeff / 2.0) / (
        ln_n + PHI * coeff
    )
    slack = p - refined
    require(slack >= -TOL, "floating refined golden frequency bound", f)
    if (stats["minimum_golden_refined_bound_slack"] is None
            or slack < stats["minimum_golden_refined_bound_slack"]):
        stats["minimum_golden_refined_bound_slack"] = slack
        stats["minimum_golden_refined_bound_slack_family"] = f

    entropy_lower_slack = (ln_n - deficit) - ((1.0 - p) / PHI) * ln_n
    require(entropy_lower_slack >= -TOL, "floating classical entropy lower bound", f)
    old = stats["minimum_entropy_lower_bound_slack"]
    stats["minimum_entropy_lower_bound_slack"] = (
        entropy_lower_slack if old is None else min(old, entropy_lower_slack)
    )
    stats["families_checked"] += 1
    stats["chain_families"] += int(is_chain)
    stats["nonchain_families"] += int(not is_chain)
    stats["sizes"][str(n)] += 1


def all_families(ground_size: int):
    universe = 1 << ground_size
    for family_mask in range(1 << universe):
        f = {a for a in range(universe) if (family_mask >> a) & 1}
        if all((a | b) in f for a in f for b in f):
            yield f


def generated_family(generators: list[int], keep_empty: bool) -> set[int]:
    out = {0}
    for generator in generators:
        out |= {a | generator for a in list(out)}
    if not keep_empty:
        out.discard(0)
    return out


def random_checks(seed: int, count: int) -> dict:
    rng = random.Random(seed)
    stats = new_stats()
    for sample in range(count):
        ground = rng.randrange(5, 9)
        if sample % 8 == 0:
            cutoff = rng.randrange(1, ground)
            f = {a for a in range(1 << ground) if a.bit_count() >= cutoff}
            if rng.getrandbits(1):
                f.add(0)
        else:
            generators = []
            for _ in range(rng.randrange(2, 13)):
                probability = rng.choice((0.15, 0.3, 0.5, 0.7))
                generators.append(sum(1 << j for j in range(ground)
                                      if rng.random() < probability))
            f = generated_family(generators, bool(rng.getrandbits(1)))
        if len(f) < 2:
            f = {0, 1}
        inspect_family(f, ground, stats)
    return stats


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("verification_results.json"))
    parser.add_argument("--max-ground", type=int, default=4, choices=range(1, 5))
    parser.add_argument("--random-samples", type=int, default=96)
    parser.add_argument("--seed", type=int, default=20261125)
    args = parser.parse_args()
    start = time.monotonic()
    exhaustive = {}
    for ground in range(args.max_ground + 1):
        stats = new_stats()
        all_union_closed = 0
        for f in all_families(ground):
            all_union_closed += 1
            if len(f) >= 2:
                inspect_family(f, ground, stats)
        stats["all_union_closed_including_empty_family_and_singletons"] = all_union_closed
        exhaustive[str(ground)] = stats
    random_stats = random_checks(args.seed, args.random_samples)
    result = {
        "status": "PASS",
        "purpose": "Independent finite sanity checks; the manuscript supplies proofs for all sizes.",
        "exact_integer_checks": [
            "Union closure and positive odd ordered-union counts",
            "Chain majorization and inclusion-prefix bounds",
            "Chain iff chain multiplicity vector",
            "Every nonchain majorizes a one-step cover of the chain vector",
            "Top-cover multiplicities iff the poset is a chain with a top fork",
            "Exact rank-flow identity",
            "Incomparability count versus maximum element frequency",
        ],
        "floating_checks_not_formal_certificates": [
            "KL/flow identity and nonnegativity",
            "Sharp nonchain entropy bound and equality characterization",
            "Incomparability entropy stability",
            "Classical entropy lower bound",
            "Refined golden-ratio frequency bound",
        ],
        "float_tolerance": TOL,
        "logarithm_base": "e",
        "seed": args.seed,
        "python_version": platform.python_version(),
        "exhaustive_by_ground_size": exhaustive,
        "reproducible_random_checks": random_stats,
        "elapsed_seconds": round(time.monotonic() - start, 6),
    }
    encoded = json.dumps(result, indent=2, sort_keys=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(encoded + "\n", encoding="utf-8")
    print(encoded)
    return 0


if __name__ == "__main__":
    sys.exit(main())
