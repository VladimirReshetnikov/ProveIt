FINITE-SIZE ENTROPY REFINEMENTS FOR UNION-CLOSED FAMILIES
Prepared for Vladimir Reshetnikov — 25 November 2026

START HERE
==========
Read union_closed_refinements.pdf.  Its complete editable source is
union_closed_refinements.tex, together with approximate_theorem.tex,
discrete_cap.tex, nonchain_theorem.tex, and frequency_table.tex.

This package does not prove Frankl's full half-frequency conjecture.
It proves finite-size frequency refinements, an entropy theorem for
approximately closed families, a sharper odd/even arithmetic version,
and exact entropy maxima among nonchains.  The report includes all
proofs, attaining examples, attribution, and limitations.

NOVELTY AND DEPENDENCIES
======================
The known binary-entropy input, Orlov's 2025 representation-count
majorization, and Quas's 2022 chain calculation are credited.  The
precise refinements proposed here were not located in the reviewed
sources and targeted searches.  This is a limited priority assessment,
not a guarantee that no antecedent exists.

The main golden-ratio frequency bound has a complete analytic derivation
in the report.  An optional stronger-certificate corollary relies on
the stated entropy mixture in Jiang's 2026 preprint; its interval
certificate was not rerun.  No claim of independent certification of
the newest announced universal constants is made.

MAIN FORMULA
============
For a union-closed family with N >= 2 members, let
  phi = (sqrt(5)-1)/2, psi = 1-phi,
  D_N = sum_{j=1}^N (2j-1) ln((2j-1)/N) / N^2,
  K_N = 2(N-1) ln((2N-1)/(2N-3)) / N.
Some element occurs in at least ceil(N R_N) members, where
  R_N = [psi ln N + phi D_N + phi K_N/2] / [ln N + phi K_N].
For N=1000 this guarantees 400 occurrences.
All logarithms are natural.

CONTENTS
========
*.tex, *.pdf             Complete report and its source sections.
figures/                 PDF and PNG versions of the two research figures.
code/verify_exhaustive.py Exact combinatorial checks for union-closed families;
                         labelled floating-point entropy sanity checks.
code/verify_approximate.py Exact rational capped-profile checks for arbitrary
                          families and multiple samples.
code/verify_discrete.py   Exact odd/even profile checks for arbitrary families.
code/verify_renyi.py      Equality-profile and Renyi-extremizer checks.
code/certify_table.py     Rational interval enclosures of table/count values.
code/make_figures.py      Table and figure reproduction.
data/*.json              Generated verification results and certificates.
data/frequency_table.csv Numerical values used in the report.
Makefile                 Standard reproduction commands.
MANIFEST.sha256          SHA-256 of every packaged file other than this manifest.

REPRODUCE
=========
The verification scripts and rational interval certificates require only
Python 3.10 or later and its standard library:

  make checks

The figures additionally require numpy, matplotlib and mpmath:

  python3 -m pip install numpy matplotlib mpmath
  make figures

To compile the paper, install a normal TeX Live distribution containing
latexmk, pdfLaTeX, Latin Modern, microtype, AMS packages, mathtools,
geometry, booktabs, hyperref, enumitem and fancyhdr, then run:

  make pdf

The source uses standard packages and has no network or external-data
dependency.  The supplied PDF is already compiled.  The included figures
and table allow recompilation without rerunning Python.

VALIDATION SCOPE
================
All 65,519 families with at least two members on a four-element labelled
ground set were checked for the approximate and discrete statements.
All 4,943 union-closed families of that size class were separately
checked for the union-closed statements; all 4,660 nonchains were checked
for the Renyi statements.  Larger seeded examples and explicitly proved
sharpness constructions are also included.

Parity, multiplicities, partial sums, structural equality conditions and
majorization use exact integers or rational numbers.  Logarithmic tests
within the exhaustive programs are floating-point sanity checks, NOT
formal or interval proofs.  They do not establish unbounded theorems.

The separate table certificate uses exact Fraction arithmetic, an
atanh-series remainder bound for logarithms and integer square root for
sqrt(5).  It certifies the integer occurrence counts stated in the table.

The mathematical proofs, not the finite experiments, establish the
results for all finite sizes.  No Lean or Rocq formalization is claimed.

AUTHORSHIP
==========
Prepared with ChatGPT in response to the user's research request.
No external publication or submission has been made by this workflow.
Existing results and their authors are identified in the bibliography.
