JOINT REDUCTIONS FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
==============================================================
Prepared for Vladimir Reshetnikov, 7 November 2026.

Start with report.pdf. Its complete editable source is report.tex together
with sections/*.tex. Both acceptance programs and the reproduction evidence
are supplied; no project library is imported by either acceptance program.

ESTABLISHED RESULT

The current six ProveIt archives contain ten root checkers and two maintained
alternatives. Under the unchanged source metric, both delivered complete
programs strictly beat every coordinate of that finite comparison envelope:

                                      Tokens   AST nodes   Normalized bytes
  Current 10-root / 12-program envelope   427         436               1246
  checker.py                             416         430               1215
  checker_absorbed.py                     422         435               1230

Counts use CPython 3.12.14 and include the entire program: imports, JSON input,
syntax validation, scope checks, substitution, inference, verdicts, and exit
handling. The respective raw files have 1267 and 1282 bytes. The main checking
core is 357/368/971 against the current core envelope 367/373/979. The absorbed
companion's core is 363/373/986; its strict dominance claim is for the complete
program, not every core coordinate.

The two presentations have different priorities:

  checker.py uses numerical primitives 0, S, and initialized R, with two
  computation schemas. Its logical language has equality, Q, and the paired
  binder D. Five primitive inference patterns suffice. It is the smaller
  delivered implementation.

  checker_absorbed.py uses 0 and a successor-initialized recursor A, with
  sigma(a) defined as A(0,a;u,v.0). It combines this smaller mathematical
  numerical signature with the same five-pattern paired-binder logic. The
  serialization still has the counted unary abbreviation [a] for sigma(a).
  That parser branch is included in the complete-source metric.

Both have the ordinary full-domain bi-interpretation with iPRA developed in
the paper. The composite isomorphisms are the identity graph x=y, justified by
internal recursion uniqueness, including nonstandard counters. Equiconsistency
and full intuitionistic logic are proved as part of the presentation, not
inferred from the finite Python experiments. Ordinary iPRA here uses fixed
primitive-recursive descriptions and quantifier-free induction with parameters.

The paired binder, successor absorption, retained-base logic, and variadic
opening are inherited from the supplied drafts and combined here. The report
does not claim a new unconditional arithmetic basis, global shortestness, or
the requested major breakthrough. A separate research theorem gives an exact
equational criterion for recovering predecessor from scalar iteration; it does
not construct the required smaller-language term or claim a completed further
recursor reduction.

QUICK START

From the extracted package directory:

  python3 checker.py validation/fixtures/scope/recursion_zero.json
  python3 checker.py validation/fixtures/theorems/022_universal_reflexivity.json
  python3 checker_absorbed.py absorbed/native/A_zero_returns_successor.json
  python3 checker_absorbed.py absorbed/examples/theorems__022_universal_reflexivity.json

Each command prints ACCEPT and exits with status 0. Invalid inputs print REJECT
and exit with status 1. The checker rejects malformed syntax as well as invalid
certificates; a rejection is not a proof that the stated sentence is false.

Use the matching arithmetic format. An ordinary R-zero axiom does not become
an A-zero axiom by renaming its recursor: A(0,a;h) returns sigma(a), not a.
The untrusted compiler in absorbed/ supplies actual translated derivations.

REPRODUCE AND REBUILD

  python3 package.py --verify
  python3 reproduce.py
  python3 build.py
  python3 package.py

The first command verifies the delivered SHA256SUMS.txt against all intended
package files. reproduce.py recomputes the pinned measurements, the main and
absorbed validation suites, and the scalar-criterion sanity checks. build.py
rebuilds the complete PDF with local pdfLaTeX. Alternatively:

  python3 reproduce.py --pdf

After intentionally rebuilding or editing files, run package.py to refresh
SHA256SUMS.txt and create ipra_joint_reductions_2026-11-07.zip in the parent
directory. The ZIP has one root directory of that same stem. Reproduction can
change generated results or PDF metadata, so verify the delivered hashes before
reproduction and regenerate them afterward if a new package is desired.

The checkers require Python 3.10+ for structural matching. Exact normalized
measurements are reported for CPython 3.12.14. All Python validation and build
helpers use the standard library. PDF rebuilding requires pdfLaTeX and the
ordinary TeX packages listed in report.tex. No downloads or network access are
required for reproduction. package.py excludes Python caches, LaTeX temporary
files, temporary directories, and visual-QA contact sheets; results/build.log
is retained as build evidence when present.

EXACT CERTIFICATE CONTRACT

FORMAT.txt specifies the complete JSON grammar, binder coordinates, scope
discipline, and proof instruction order for both kernels. The public goal is
closed and the initial logical context is empty. Negative names are allocated
before use. An already retained hypothesis closes automatically without an
instruction. Unused stream prefixes and wholly unused witness annotations are
inert; every actual goal and every used substitution image is validated.

For reference, the ordinary readings of the native logical binders are

  Q_y B(y)     = B(0) -> forall y B(y)
  D_(x,y) B    = exists x (B(x,0) -> forall y B(x,y)).

The five inference patterns are hypothesis, paired introduction, closure
elimination, paired elimination, and equality transport. The paired introduction
retains its base and adds an induction hypothesis only for a literal equality
matrix. There is no primitive Q-introduction rule. The paper derives that rule,
all ordinary intuitionistic logical operations, and quantifier-free induction.

EXECUTED EVIDENCE

Main kernel:
  * 108 fixed named packets, representing 97 distinct serialized packets:
    63 accepting and 45 rejecting entries.
  * Three malformed-JSON cases and 444 actual CLI executions across candidate
    and reference, under normal and optimized (-O) Python.
  * 3672 opening cases compared with an independently structured named parser:
    2110 valid and 1562 invalid cases.
  * 1200 deterministic mutations, 1139 distinct mutated packets, 45 false-root
    substitutions, and three deliberately defective-program controls.

Successor-absorbed companion:
  * 45 transported packets (43 theorem packets and two coordinate-alias cases),
    checked by the kernel and an adapted independent named oracle.
  * 807 source instructions translated to 3033 target instructions; 3094 target
    inference nodes and 85 eigenparameter allocations independently checked.
  * 21 native controls (11 accepting and 10 rejecting), 132 actual normal/-O
    CLI executions, and three deliberately defective-program controls.
  * 1088 source/target numerical comparisons: 68 terms at 16 assignments each,
    with no case skipped. Decoder inputs 0 through 20 were also checked.

These overlapping execution cohorts are not counts of independent mathematical
theorems. Full results are recorded under results/. Finite tests do not prove
soundness or consistency for all inputs. The mathematical metatheory is written
in the paper; no Lean or Rocq formalization is claimed. Finite runtime limits
can reject very large certificates despite a valid idealized derivation.

CONTENTS

  report.pdf, report.tex, sections/    Complete paper and editable source
  checker.py                          Smaller complete acceptance program
  checker_absorbed.py                  Joint successor-absorbed presentation
  FORMAT.txt                          Exact certificate interface
  comparison/                         Frozen current sources, hashes, metric,
                                      and the earlier 418-token ablation
  validation/                         Main fixtures and independent named oracle
  absorbed/                           Numerical compiler, transported examples,
                                      adapted oracle, and companion validation
  scalar_criterion.py                  Finite sanity checks for the research theorem
  results/                            Measurements, validation, and build evidence
  reproduce.py, build.py, package.py   Offline reproduction and integrity tools
  ATTRIBUTION.txt, ATTRIBUTION_KERNEL.txt, LICENSE_SOURCE.txt
                                      Contribution boundary and inherited license
  SHA256SUMS.txt                       Exact delivered-file integrity manifest

PINNED SOURCE

  https://github.com/VladimirReshetnikov/ProveIt
  commit 5c4724e5550a1b19347ac62c9b02857a7e3fbd19
  directory docs/drafts

All six archive Git blob identities and archive/source SHA-256 hashes are in
comparison/manifest.json. The old 444/457/1313 envelope printed in the source
reports refers to an earlier snapshot and is not the comparison used here.
