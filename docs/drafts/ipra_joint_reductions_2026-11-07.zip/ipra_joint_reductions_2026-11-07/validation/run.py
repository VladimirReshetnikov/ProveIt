"""Finite independent checks of the complete closed-sentence acceptance program.

The unchanged upstream named oracle uses explicit binder names and separate
term/formula parsers.  It does not call the production opening function.
All files in this directory are untrusted validation support, not kernel code.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

from named_oracle import Oracle, opening

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CANDIDATE = ROOT / "checker.py"
REFERENCE = ROOT / "comparison/sources/fused_binder__checker_closed.py"
SEED = 20261107


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def packet_digest(packet):
    raw = json.dumps(packet, sort_keys=True, separators=(",", ":")).encode()
    return sha256(raw).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_module(module, packet):
    stack = deepcopy(packet)
    module.k = 0
    try:
        module.take = stack.pop
        accepted = bool(module.check(module.take(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {"accepted": accepted,
            "remaining": len(stack) if isinstance(stack, (list, dict, str)) else None,
            "final_k": module.k, "error": error}


def run_oracle(packet):
    # The upstream result formatter presumes a list.  Nonlist JSON roots are
    # outside its packet grammar and are rejected before entering that formatter.
    if type(packet) is not list:
        return {"accepted": False, "error": "nonlist packet", "rules": {},
                "allocations": []}
    return Oracle().run(packet)


def compare(candidate, reference, packet, expected=None, label=None):
    actual = run_module(candidate, packet)
    baseline = run_module(reference, packet)
    oracle = run_oracle(packet)
    require(actual["accepted"] == baseline["accepted"] == oracle["accepted"],
            (label, actual, baseline, oracle))
    if expected is not None:
        require(actual["accepted"] == expected, (label, expected, actual))
    if actual["accepted"]:
        for key in ("remaining", "final_k"):
            require(actual[key] == baseline[key] == oracle[key],
                    (label, key, actual, baseline, oracle))
    return actual, baseline, oracle


def cli(checker, certificate, expected, optimized):
    args = [sys.executable, *(["-O"] if optimized else []), str(checker), str(certificate)]
    process = subprocess.run(args, capture_output=True, text=True, timeout=15)
    wanted = (0, "ACCEPT") if expected else (1, "REJECT")
    require((process.returncode, process.stdout.strip()) == wanted and not process.stderr,
            (args, wanted, process.returncode, process.stdout, process.stderr))


def opening_audit(candidate, reference):
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, True, None, {}]
    terms = [*atoms, [], [0], [1], [5], [0, 0], [0, 0, 1], [0, 0, 3],
             [0, 0, 5], [1, 0, [0, 3, 7]], [0, 0, [0, 1, 9]]]
    formulas = [[term, 0] for term in terms]
    formulas += [[[term, 0]] for term in (-2, 0, 1, 2, 3, 4, 5)]
    formulas += [[[term, 0], [1, 2], [3, 4]]
                 for term in (-2, 0, 1, 2, 3, 4, 5, 6)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 9], 5]], [0, 0], [0, 0]]]
    environments = [(), (0,), (-1,), (-3,), (1,), ([0],), ([0, 0, 3],),
                    ([0, 0, 5],), (0, [0])]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2):
                for lower in (0, -2):
                    for images in environments:
                        outputs = []
                        for index, module in enumerate((candidate, reference, None)):
                            try:
                                if module is None:
                                    result = opening(deepcopy(value), deepcopy(images),
                                                     formula=formula, depth=depth, lower=lower)
                                else:
                                    module.k = lower
                                    packed_depth = 2 * depth + (not formula)
                                    if index == 0:
                                        result = module.inst(deepcopy(value), *deepcopy(images),
                                                             d=packed_depth)
                                    else:
                                        result = module.inst(deepcopy(value), deepcopy(images),
                                                             packed_depth)
                                outputs.append((True, result))
                            except Exception:
                                outputs.append((False, None))
                        require(outputs[0] == outputs[1] == outputs[2],
                                (value, images, formula, depth, lower, outputs))
                        counts["valid" if outputs[0][0] else "invalid"] += 1
    return {"cases": sum(counts.values()), **counts,
            "implementations_per_case": 3,
            "description": "Production variadic opening, frozen tuple-environment opening, and independent named opening."}


def paths(value, prefix=()):
    yield prefix
    if type(value) is list:
        for index, child in enumerate(value):
            yield from paths(child, prefix + (index,))


def replaced(value, path, replacement):
    if not path:
        return deepcopy(replacement)
    result = deepcopy(value)
    target = result
    for index in path[:-1]:
        target = target[index]
    target[path[-1]] = deepcopy(replacement)
    return result


def mutations(cases):
    rng = random.Random(SEED)
    replacements = [None, True, False, 0, 0.0, 1, 2, 3, 4, 5, 6,
                    -1, -2, -999, [], {}, [0], [0, 0], [0, [0]],
                    [0, 0, 1], [0, 0, 5], [[0, 0]], "scope"]
    positives = [case for case in cases if case["expected"]]
    for iteration in range(1200):
        source = rng.choice(positives)
        packet = deepcopy(source["packet"])
        path = rng.choice(list(paths(packet)))
        packet = replaced(packet, path, rng.choice(replacements))
        yield "mutation_%04d" % iteration, source["name"], packet


def defect_controls(code, fixtures):
    if "h = [b, inst(b, 0)][len(b) % 2:]" in code:
        restricted = "h = [b, inst(b, 0)][len(b) % 2:]"
        unrestricted = "h = [b, inst(b, 0)]"
    else:
        restricted = "h = [inst(b, 0), b][:2 - len(b) % 2]"
        unrestricted = "h = [inst(b, 0), b]"
    definitions = [
        ("contextual_image_capture", "inst(env[a - d >> 1], d=1)",
         "inst(env[a - d >> 1], d=d)", "boundary/false_inner_capture"),
        ("missing_goal_validation", "if inst(a) in g:", "if a in g:",
         "boundary/false_eigenparameter_escape"),
        ("unrestricted_induction", restricted, unrestricted,
         "boundary/compound_induction_hypothesis"),
    ]
    rows = []
    for name, old, new, fixture in definitions:
        require(code.count(old) == 1, (name, "mutation target missing or ambiguous"))
        module = types.ModuleType(name)
        exec(compile(code.replace(old, new), name, "exec"), module.__dict__)
        result = run_module(module, fixtures[fixture])
        require(result["accepted"], (name, result))
        rows.append({"defect": name, "fixture": fixture, "defective_program_accepts": True,
                     "delivered_program_rejects": True})
    return rows


def main():
    provenance = json.loads((HERE / "fixtures_manifest.json").read_text())
    inventory = json.loads((ROOT / "comparison/manifest.json").read_text())
    oracle_row = provenance["oracle"]
    require(digest(HERE / oracle_row["local_file"]) == oracle_row["sha256"],
            "Frozen independent oracle has changed")
    reference_row = next(row for row in inventory["programs"]
                         if row["label"] == "fused_binder/checker_closed.py")
    require(digest(REFERENCE) == reference_row["sha256"], "Frozen reference has changed")
    candidate = load(CANDIDATE, "tested_candidate")
    reference = load(REFERENCE, "frozen_fused_checker")
    opening_result = opening_audit(candidate, reference)
    fixed = []
    for row in provenance["cases"]:
        path = HERE / row["file"]
        require(digest(path) == row["sha256"], ("Changed fixture", row["name"]))
        fixed.append({**row, "packet": json.loads(path.read_text())})
    # Additional JSON boundary tests are independent of the inherited corpus.
    for name, packet in [("null_packet", None), ("boolean_packet", True),
                         ("numeric_packet", 0), ("object_packet", {}),
                         ("empty_packet", []), ("missing_instruction", [[0, 0]]),
                         ("string_goal", [[], "false"]),
                         ("empty_goal", [[], []])]:
        fixed.append({"name": "outer/" + name, "expected": False, "packet": packet})
    fixed_rows, cli_runs, rule_counts = [], 0, Counter()
    with tempfile.TemporaryDirectory(prefix="ipra-kernel-validation-") as directory:
        temporary = Path(directory) / "packet.json"
        for case in fixed:
            packet, expected = case["packet"], case["expected"]
            actual, baseline, oracle = compare(candidate, reference, packet,
                                                expected, case["name"])
            temporary.write_text(json.dumps(packet))
            for checker in (CANDIDATE, REFERENCE):
                for optimized in (False, True):
                    cli(checker, temporary, expected, optimized)
                    cli_runs += 1
            if expected:
                rule_counts.update(oracle["rules"])
            fixed_rows.append({"name": case["name"], "expected": expected,
                               "packet_sha256": packet_digest(packet),
                               "candidate": actual, "reference": baseline,
                               "named_oracle": oracle})
        malformed_rows = []
        for name, raw in [("empty_file", ""), ("truncated_array", "[0,"),
                          ("invalid_object", "{broken")]:
            temporary.write_text(raw)
            for checker in (CANDIDATE, REFERENCE):
                for optimized in (False, True):
                    cli(checker, temporary, False, optimized)
                    cli_runs += 1
            malformed_rows.append({"name": name, "expected": False,
                                   "utf8_sha256": sha256(raw.encode()).hexdigest()})
    mutation_rows = []
    for name, source, packet in mutations(fixed):
        actual, baseline, oracle = compare(candidate, reference, packet, label=name)
        mutation_rows.append({"name": name, "source": source,
                              "packet_sha256": packet_digest(packet),
                              "accepted": actual["accepted"]})
    false_root_rows = []
    for case in fixed:
        if not case["name"].startswith(("theorems/", "aliases/")):
            continue
        packet = deepcopy(case["packet"])
        packet[-1] = [0, [0]]
        compare(candidate, reference, packet, False, "false_root/" + case["name"])
        false_root_rows.append({"source": case["name"],
                                "packet_sha256": packet_digest(packet), "accepted": False})
    controls = defect_controls(CANDIDATE.read_text(),
                               {case["name"]: case["packet"] for case in fixed})
    fixed_hashes = {row["packet_sha256"] for row in fixed_rows}
    mutant_hashes = {row["packet_sha256"] for row in mutation_rows}
    result = {
        "status": "PASS",
        "python": platform.python_version(),
        "candidate_sha256": digest(CANDIDATE),
        "reference_sha256": digest(REFERENCE),
        "oracle_sha256": digest(HERE / "named_oracle.py"),
        "opening_audit": opening_result,
        "fixed_named_entries": len(fixed_rows),
        "fixed_distinct_packets": len(fixed_hashes),
        "fixed_accept_entries": sum(row["expected"] for row in fixed_rows),
        "fixed_reject_entries": sum(not row["expected"] for row in fixed_rows),
        "malformed_json_cases": len(malformed_rows),
        "public_cli_runs": cli_runs,
        "cli_checkers": 2,
        "cli_modes": ["normal", "-O"],
        "accepted_rule_counts": dict(rule_counts),
        "named_freshness_allocations_checked": sum(
            len(row["named_oracle"]["allocations"]) for row in fixed_rows),
        "mutation_seed": SEED,
        "mutation_runs": len(mutation_rows),
        "mutation_distinct_packets": len(mutant_hashes),
        "mutation_packets_absent_from_fixed": len(mutant_hashes - fixed_hashes),
        "mutation_accept_entries": sum(row["accepted"] for row in mutation_rows),
        "mutation_reject_entries": sum(not row["accepted"] for row in mutation_rows),
        "false_root_substitutions": len(false_root_rows),
        "defect_controls": controls,
        "claim": "Finite implementation evidence; not a formal proof of soundness or consistency. Named entries, distinct packets, and execution totals are reported separately.",
    }
    destination = ROOT / "results"
    destination.mkdir(exist_ok=True)
    (destination / "validation.json").write_text(json.dumps(result, indent=2) + "\n")
    details = {"fixed": fixed_rows, "malformed_json": malformed_rows,
               "mutations": mutation_rows, "false_roots": false_root_rows}
    (destination / "validation_details.json").write_text(json.dumps(details, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
