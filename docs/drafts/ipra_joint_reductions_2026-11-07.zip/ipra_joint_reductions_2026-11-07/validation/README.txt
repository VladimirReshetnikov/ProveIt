INDEPENDENT FINITE VALIDATION
============================

Run from any working directory:

    python3 /path/to/package/validation/run.py

The delivered acceptance program is ../checker.py. It imports no file from
this directory or the comparison directory. The validation code is not part
of the trusted checking boundary and is not included in the checker metric.

THREE IMPLEMENTATIONS

1. The candidate's variadic substitution and inference implementation.
2. The byte-identical current fused-binder closed checker, under comparison/.
3. The unchanged named_oracle.py from the current fused-binder archive.

The oracle uses explicit bound-variable names, separate term/formula parsers,
and explicit rule dispatch. It does not use the production opening helper,
packed sort/depth field, constructor-width table, or Python match statement.
It retains coordinate-alias spelling because the native calculus compares
serialized expression trees literally. It verifies eigenparameter freshness
against explicit free-name sets. The oracle is independently structured but
inherited, not newly written or mechanically certified in this package.

FIXTURES AND SCOPE

fixtures_manifest.json records the exact source archive/member and SHA-256 of
each inherited fixture. There are 43 closed theorem packets, two alias packets,
29 boundary packets, and 26 closed-interface scope entries. The theorem and
boundary files are unchanged copies. Scope entries are serialized from the
upstream scope result records. Several entries describe identical packets;
counts of named entries and distinct packet hashes are reported separately.

The runner adds eight outer-JSON/packet boundary cases and three malformed JSON
files. It compares the two implementations and named oracle in-process, and
runs both real public CLIs under normal Python and python -O. Every accepting
packet must also agree on the remaining instruction count and final fresh-name
bound. Deliberately inert unused annotations and prefixes remain permitted.

The substitution audit checks 3,672 combinations of formula/term sort,
protected binder depth, current parameter bound, malformed constructors,
coordinate aliases, and used/unused substitution images. All three opening
implementations agree, including 2,110 valid and 1,562 invalid cases.

A deterministic seed generates 1,200 local certificate mutations from accepting
fixed packets. These are compared with both references, not assumed invalid.
Forty-five theorem/alias packets also have their public conclusion replaced by
0=S0 and must be rejected. Three deliberately defective candidate variants
must accept their designated attack while the delivered program rejects it:
contextual capture of a substitution image, omitted root-goal validation, and
an induction hypothesis improperly supplied to a compound formula.

EXECUTED RESULTS (CPython 3.12.14)

  Fixed named packets:             108
  Distinct fixed serialized packets: 97
  Fixed accepting/rejecting entries: 63 / 45
  Malformed-JSON files:               3
  Actual public CLI executions:     444 (two programs, two interpreter modes)
  Opening cases:                  3672 (three implementations per case)
  Mutation runs:                  1200
  Distinct mutation packets:       1139
  Mutation packets not in fixtures:1106
  Mutation accepting/rejecting runs:119 / 1081
  False-root substitutions:          45
  Deliberate defect controls:         3

These overlapping cohorts must not be added as independent mathematical
theorems. results/validation.json records the summary and program identities;
results/validation_details.json records individual fixed and mutation outcomes.
The mutation stream is reproducible from the seed and stored fixed fixtures.

Finite tests do not prove consistency, completeness, or implementation soundness
for all inputs. The mathematical claims require the accompanying proofs.
Finite Python recursion, integer-string, time, and memory limits can reject
large certificates that have valid idealized derivations.
