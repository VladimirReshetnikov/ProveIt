"""Offline reproduction of metrics, implementation checks, and research sanity checks."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    scripts = ['comparison/measure.py', 'validation/run.py', 'scalar_criterion.py']
    absorbed = ROOT / 'absorbed' / 'validate.py'
    if absorbed.exists():
        scripts.append('absorbed/validate.py')
    for script in scripts:
        print('Running', script, flush=True)
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    if '--pdf' in sys.argv:
        subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)
    print('All requested reproduction steps passed.')


if __name__ == '__main__':
    main()
