"""Rebuild the supplied paper with local pdfLaTeX; no downloads."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which('pdflatex'):
        raise SystemExit('pdflatex is required to rebuild the supplied PDF.')
    subprocess.run([sys.executable, str(ROOT / 'comparison' / 'measure.py')],
                   cwd=ROOT, check=True, stdout=subprocess.DEVNULL)
    report = json.loads((ROOT / 'results' / 'metrics.json').read_text())
    rows = [r'\begin{small}',
            r'\begin{longtable}{p{8.0cm}rrr}',
            r'\toprule Source & Tokens & AST nodes & Bytes\\\midrule',
            r'\endfirsthead',
            r'\toprule Source & Tokens & AST nodes & Bytes\\\midrule',
            r'\endhead']
    for entry in report['programs']:
        label = entry['label']
        rows.append(r'\path{' + label + '} & ' + ' & '.join(
            str(entry[key]) for key in ('normalized_tokens', 'ast_nodes', 'normalized_bytes')) + r'\\')
    for label, entry in [(r'\midrule Delivered ordinary-recursion kernel', report['candidate']),
                         ('Delivered successor-absorbed kernel', report['companion'])]:
        rows.append(label + ' & ' + ' & '.join(
            str(entry[key]) for key in ('normalized_tokens', 'ast_nodes', 'normalized_bytes')) + r'\\')
    rows.extend([r'\bottomrule\end{longtable}', r'\end{small}'])
    (ROOT / 'results' / 'comparison_table.tex').write_text('\n'.join(rows) + '\n')
    command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
               '-file-line-error', 'report.tex']
    logs = []
    for run in range(3):
        result = subprocess.run(command, cwd=ROOT, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logs.append(f'PDFLATEX PASS {run + 1}\n' + result.stdout)
        if result.returncode:
            (ROOT / 'results' / 'build.log').write_text('\n'.join(logs))
            print(result.stdout[-7000:])
            raise SystemExit(result.returncode)
    (ROOT / 'results' / 'build.log').write_text('\n'.join(logs))
    print('Built', ROOT / 'report.pdf')


if __name__ == '__main__':
    main()
