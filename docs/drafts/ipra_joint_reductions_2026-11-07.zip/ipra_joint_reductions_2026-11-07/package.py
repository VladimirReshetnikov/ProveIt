"""Verify delivered files or refresh their hashes and build the release ZIP.

The archive has a stable root name and reproducible ZIP metadata. Byte hashes
detect accidental changes; they are not a digital signature or proof checker.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path(__file__).resolve().parent
STEM = "ipra_joint_reductions_2026-11-07"
MANIFEST = "SHA256SUMS.txt"
EXCLUDED_DIRS = {
    "__pycache__", "tmp", "temp", "qa", "pdf_qa", "qa_images",
    "contact_sheets", "contact-sheets", "renders", "rendered",
    "pdf_render", "pdf_renders", "tmp_pdfs", ".git", ".cache",
}
EXCLUDED_SUFFIXES = {
    ".pyc", ".pyo", ".aux", ".out", ".toc", ".fls", ".fdb_latexmk",
    ".synctex", ".dvi", ".xdv", ".nav", ".snm", ".vrb", ".blg",
    ".bbl", ".tmp", ".bak", ".zip",
    # The report has no external raster illustration assets. Staged images
    # are temporary PDF-rendering or visual-QA output, not deliverables.
    ".png", ".jpg", ".jpeg", ".webp", ".gif", ".ppm", ".pgm", ".pbm",
}
REQUIRED = (
    "README.txt", "FORMAT.txt", "ATTRIBUTION.txt", "LICENSE_SOURCE.txt",
    "report.tex", "report.pdf", "checker.py", "checker_absorbed.py",
    "reproduce.py", "build.py", "package.py", "comparison/manifest.json",
    "comparison/source_measure.py", "comparison/measure.py",
    "validation/run.py", "validation/named_oracle.py", "absorbed/validate.py",
    "absorbed/transport.py", "results/metrics.json", "results/validation.json",
    "results/absorbed_validation.json", "results/pdf_qa.json",
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def payloads():
    files = {}
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        name = relative.as_posix()
        if any(part.lower() in EXCLUDED_DIRS for part in relative.parts[:-1]):
            continue
        if path.is_symlink():
            raise ValueError("Package symlink is not allowed: " + name)
        if not path.is_file() or name == MANIFEST:
            continue
        if path.suffix.lower() in EXCLUDED_SUFFIXES or name.endswith(".synctex.gz"):
            continue
        if path.suffix.lower() == ".log" and name != "results/build.log":
            continue
        if "\n" in name or "\r" in name or "\\" in name:
            raise ValueError("Unsupported manifest filename: " + repr(name))
        files[name] = path.read_bytes()
    missing = [name for name in REQUIRED if name not in files]
    if missing:
        raise ValueError("Required package files are missing: " + ", ".join(missing))
    return files


def manifest_text(files):
    return "".join(digest(data) + "  " + name + "\n"
                   for name, data in sorted(files.items()))


def read_manifest():
    entries = {}
    for line in (ROOT / MANIFEST).read_text().splitlines():
        checksum, name = line.split("  ", 1)
        relative = PurePosixPath(name)
        if (len(checksum) != 64 or any(c not in "0123456789abcdef" for c in checksum)
                or relative.is_absolute() or ".." in relative.parts
                or name in entries or name == MANIFEST or str(relative) != name):
            raise ValueError("Malformed or duplicate manifest entry: " + line)
        entries[name] = checksum
    return entries


def verify_local():
    files, expected = payloads(), read_manifest()
    if set(files) != set(expected):
        raise ValueError({"missing_files": sorted(set(expected) - set(files)),
                          "unrecorded_files": sorted(set(files) - set(expected))})
    changed = [name for name, data in files.items() if digest(data) != expected[name]]
    if changed:
        raise ValueError("Changed package files: " + ", ".join(changed))
    return files


def verify_archive(path, files):
    wanted = {STEM + "/" + name: data for name, data in files.items()}
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(wanted) or set(names) != set(wanted):
            raise ValueError("ZIP member inventory differs from the intended package")
        for name, data in wanted.items():
            if digest(archive.read(name)) != digest(data):
                raise ValueError("ZIP content differs from the intended file: " + name)


def build_archive():
    files = payloads()
    manifest = manifest_text(files).encode("utf-8")
    temporary_manifest = ROOT / (MANIFEST + ".tmp")
    temporary_manifest.write_bytes(manifest)
    temporary_manifest.replace(ROOT / MANIFEST)
    files[MANIFEST] = manifest
    destination = ROOT.parent / (STEM + ".zip")
    temporary_zip = destination.with_suffix(".zip.tmp")
    try:
        with zipfile.ZipFile(temporary_zip, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9) as archive:
            for name, data in sorted(files.items()):
                entry = zipfile.ZipInfo(STEM + "/" + name,
                                        date_time=(2026, 11, 7, 0, 0, 0))
                entry.create_system = 3
                entry.external_attr = 0o100644 << 16
                archive.writestr(entry, data, compress_type=zipfile.ZIP_DEFLATED,
                                 compresslevel=9)
        verify_archive(temporary_zip, files)
        # A concurrent edit would leave a stale local manifest. Reject before
        # replacing the existing output archive in that situation.
        verify_local()
        temporary_zip.replace(destination)
    finally:
        if temporary_zip.exists():
            temporary_zip.unlink()
    return destination, len(files), digest(destination.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true",
                        help="Verify existing SHA256SUMS.txt without changing files")
    args = parser.parse_args()
    if args.verify:
        files = verify_local()
        print(json.dumps({"status": "PASS", "verified_payload_files": len(files),
                          "manifest": MANIFEST}, indent=2))
    else:
        path, count, checksum = build_archive()
        print(json.dumps({"status": "PASS", "archive": str(path),
                          "archive_root": STEM, "archive_files": count,
                          "archive_sha256": checksum}, indent=2))


if __name__ == "__main__":
    main()
