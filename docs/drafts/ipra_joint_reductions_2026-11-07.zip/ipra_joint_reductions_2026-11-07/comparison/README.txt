PINNED CURRENT COMPARISON
=========================

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 5c4724e5550a1b19347ac62c9b02857a7e3fbd19
Directory: docs/drafts

The six current archives contain ten root checker*.py programs. Two further
maintained alternatives occur in the alternate proof-clock archive. All twelve
are copied byte-for-byte under sources/. Historical comparison copies, test
support, and explicitly experimental research programs are not comparators.
manifest.json states each exact archive name, archive member, and source hash.

Each downloaded archive was independently checked by recomputing

    SHA1(b"blob " + str(len(bytes)).encode() + b"\0" + bytes)

and comparing it with the Git blob identifier returned for the pinned archive.
Archive SHA-256 values are also recorded. The archives themselves are omitted
from this package because the exact comparator source is sufficient to repeat
the measurements. Individual Python files inside ZIP archives do not have
separate repository paths; provenance therefore links through the archive and
its member path. No source hash is represented as a separate repository object.

source_measure.py is an unchanged copy of the metric shipped in the current
fused-binder archive. It strips documentation strings, normalizes with Python's
AST unparser, and measures significant tokens, AST nodes, and normalized UTF-8
bytes. The main boundary is the complete program, including imports, JSON
parsing, scope handling, validation, checking, output, and exit handling.
The checking core is a separately reported diagnostic, not the main boundary.

Run from any working directory:

    python3 /path/to/package/comparison/measure.py

The command verifies every copied source and the metric hash, writes
results/metrics.json and comparison/metrics.csv, and requires both delivered
kernels to beat every coordinate of the expanded complete-source envelope. Exact reported
counts use CPython 3.12.14. The original source_measure.py may also be used
directly, but measure.py additionally distinguishes root and expanded sets.

Observed current root and expanded envelope: 427 tokens / 436 AST / 1246 bytes.
Observed candidate:                         416 tokens / 430 AST / 1215 bytes.
Observed absorbed companion:                422 tokens / 435 AST / 1230 bytes.
Current core envelope:                     367 tokens / 373 AST /  979 bytes.
Candidate core:                            357 tokens / 368 AST /  971 bytes.
The companion's 363/373/986 core is diagnostic; only its complete-program
measures strictly dominate every coordinate of the current envelope.

The former 418/434/1225 candidate is retained unchanged under ablations/ and
measured separately. It is not added to the pinned current-repository envelope.
The final change reorders two reusable local assumptions in the equation branch
and groups imports. ablation_audit.txt explains why acceptance is preserved.

Not all source programs have the same external parameter encoding. The two
proof-clock main programs admit negative parameter names below the initial
proof-length bound. The successor-absorption open program admits arbitrary
negative odd names, reserving even names for local eigenparameters. Three
other programs have explicit finite namespace headers. Six comparators, as well
as the delivered candidate, have a closed-sentence public interface.
These distinctions are recorded in the source manifest; no nonempty external
logical assumption context is accepted by any comparator's public interface.

This is a finite source comparison under a declared host-language metric.
It is not a lower-bound theorem over all possible theories or proof checkers.
The old 444/457/1313 envelope printed in the inspected reports belongs to their
earlier comparison snapshot and is not used for the current claim.
