"""Measure the complete candidate against the pinned current archive programs.

The normalization routine is the unmodified upstream source_measure.py.
No comparator is imported or executed; only its source syntax is measured.
"""
import csv
import hashlib
import json
import platform
from pathlib import Path

from source_measure import metrics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
KEYS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def envelope(rows):
    return {
        "program_count": len(rows),
        "distinct_source_count": len({row["sha256"] for row in rows}),
        "complete": {key: min(row[key] for row in rows) for key in KEYS},
        "core": {key: min(row["core"][key] for row in rows) for key in KEYS},
        "attainers": {
            key: [row["label"] for row in rows
                  if row[key] == min(item[key] for item in rows)]
            for key in KEYS
        },
    }


def main():
    manifest = json.loads((HERE / "manifest.json").read_text())
    metric_path = HERE / manifest["metric"]["local_file"]
    if hashlib.sha256(metric_path.read_bytes()).hexdigest() != manifest["metric"]["sha256"]:
        raise ValueError("Frozen source metric has changed")
    rows = []
    for source in manifest["programs"]:
        row = metrics(HERE / source["local_file"])
        if row["sha256"] != source["sha256"]:
            raise ValueError("Frozen comparator has changed: " + source["label"])
        rows.append({**source, **row})
    root_rows = [row for row in rows if row["root_program"]]
    candidate = metrics(ROOT / "checker.py")
    companion = metrics(ROOT / "checker_absorbed.py")
    expanded, current = envelope(rows), envelope(root_rows)
    ablation_manifest = json.loads((HERE / "ablation_manifest.json").read_text())
    ablations = []
    for source in ablation_manifest["programs"]:
        row = metrics(HERE / source["local_file"])
        if row["sha256"] != source["sha256"]:
            raise ValueError("Frozen ablation has changed: " + source["label"])
        ablations.append({**source, **row})
    result = {
        "status": "PASS",
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "archive_count": len(manifest["archives"]),
        "scope": manifest["scope"],
        "current_root_envelope": current,
        "expanded_envelope": expanded,
        "candidate": {"file": "checker.py", **candidate},
        "companion": {"file": "checker_absorbed.py", **companion},
        "strict_improvement_complete": {
            key: candidate[key] < expanded["complete"][key] for key in KEYS
        },
        "strict_improvement_core": {
            key: candidate["core"][key] < expanded["core"][key] for key in KEYS
        },
        "companion_strict_improvement_complete": {
            key: companion[key] < expanded["complete"][key] for key in KEYS
        },
        "programs": rows,
        "ablations": ablations,
        "claim": "Finite pinned-source comparison, not a universal minimality theorem.",
    }
    if not all(result["strict_improvement_complete"].values()):
        raise ValueError("Candidate does not strictly dominate the complete-source envelope")
    if not all(result["companion_strict_improvement_complete"].values()):
        raise ValueError("Companion does not strictly dominate the complete-source envelope")
    destination = ROOT / "results"
    destination.mkdir(exist_ok=True)
    (destination / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    fields = ("label", "root_program", "interface", *KEYS, "raw_bytes", "sha256")
    with (HERE / "metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        writer.writerow({"label": "candidate/checker.py", "interface": "closed sentences",
                         **candidate})
        writer.writerow({"label": "candidate/checker_absorbed.py", "interface": "closed sentences",
                         **companion})
    print(json.dumps({key: value for key, value in result.items() if key != "programs"}, indent=2))


if __name__ == "__main__":
    main()
