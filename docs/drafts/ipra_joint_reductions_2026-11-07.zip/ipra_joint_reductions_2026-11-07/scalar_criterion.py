#!/usr/bin/env python3
"""Finite numerical sanity checks for the scalar-iterator predecessor criterion.

This script does not construct an order test in the scalar iterator language.
Its numerical predecessor and comparison functions are explicitly external
Python reference functions.  The theorem in the accompanying report is proved
by equation induction; finite tests neither prove that theorem nor eliminate
the recursion counter in the delivered arithmetic checker.

The negative example shows that diagonal and strict-diagonal identities alone
do not imply support persistence and do not validate the displayed reset
construction.  It does not exclude a different predecessor construction.
"""

import argparse
import json
from pathlib import Path


def iterate(n, initial, step):
    """Numerical semantics of I(n, initial; u.step(u))."""
    value = initial
    for _ in range(n):
        value = step(value)
    return value


def gate(q, value):
    """G_q(value), evaluated using the scalar iterator itself."""
    return iterate(q, 0, lambda _: value)


def support(q):
    return gate(q, 1)


def reference_predecessor(n):
    """External numerical oracle, not a purported scalar iterator expression."""
    return max(n - 1, 0)


def difference(y, n):
    """Converse construction, conditional on the supplied predecessor."""
    return iterate(n, y, reference_predecessor)


def reset_iterate(n, y, comparison):
    """F(n,y) = I(n,y; u.G_{c(y,u)}(u+1))."""
    return iterate(n, y, lambda u: gate(comparison(y, u), u + 1))


def near_diagonal(y, n):
    """External counterexample: one exactly when y = n+1."""
    return int(y == n + 1)


def run(bound):
    values = range(bound + 1)
    counts = {}

    def equal(group, left, right, context):
        counts[group] = counts.get(group, 0) + 1
        if left != right:
            raise AssertionError(
                f"{group} failed at {context}: {left!r} != {right!r}"
            )

    contexts = (
        ("successor", lambda t: t + 1),
        ("square_plus_one", lambda t: t * t + 1),
        ("constant", lambda t: 7),
    )

    for q in values:
        for t in values:
            equal("selector_semantics", gate(q, t), 0 if q == 0 else t, (q, t))
            equal("selector_normalization", gate(support(q), t), gate(q, t), (q, t))
            for name, context in contexts:
                equal(
                    "selector_locality",
                    gate(q, context(gate(q, t))),
                    gate(q, context(t)),
                    (name, q, t),
                )
            for r in values:
                equal(
                    "selector_composition",
                    gate(q, gate(r, t)),
                    gate(gate(q, support(r)), t),
                    (q, r, t),
                )
                if gate(q, support(r)) == support(q):
                    equal(
                        "selector_absorption",
                        gate(q, gate(r, t)),
                        gate(q, t),
                        (q, r, t),
                    )

    for a in values:
        for b in values:
            equal("converse_cancellation", difference(a + 1, b + 1), difference(a, b), (a, b))
        equal("converse_diagonal", difference(a, a), 0, a)
        equal("converse_strict_diagonal", difference(a + 1, a), 1, a)
        equal(
            "converse_support_lemma",
            gate(reference_predecessor(a), support(a)),
            support(reference_predecessor(a)),
            a,
        )

    # These are numerical model examples.  No scalar-language representation
    # is claimed for any comparison without the stated conditional input.
    comparisons = (
        ("difference_from_given_predecessor", difference),
        ("boolean_difference", lambda y, n: int(difference(y, n) > 0)),
        ("squared_difference", lambda y, n: difference(y, n) ** 2),
    )
    for name, comparison in comparisons:
        for y in values:
            equal("criterion_diagonal", comparison(y, y), 0, (name, y))
            equal("criterion_strict_diagonal", comparison(y + 1, y), 1, (name, y))
            for n in values:
                q, r = comparison(y, n + 1), comparison(y, n)
                equal(
                    "criterion_persistence",
                    gate(q, support(r)),
                    support(q),
                    (name, y, n),
                )
                equal(
                    "fixed_parameter_invariant",
                    gate(r, reset_iterate(n + 1, y, comparison)),
                    gate(r, n),
                    (name, y, n),
                )
            equal(
                "forward_predecessor",
                reset_iterate(y, y, comparison),
                reference_predecessor(y),
                (name, y),
            )

    for n in values:
        equal("counterexample_diagonal", near_diagonal(n, n), 0, n)
        equal("counterexample_strict_diagonal", near_diagonal(n + 1, n), 1, n)

    # Explicitly inspect the first failing persistence instance and reset value.
    y, n = 2, 0
    persistence_left = gate(near_diagonal(y, n + 1), support(near_diagonal(y, n)))
    persistence_right = support(near_diagonal(y, n + 1))
    bad_reset = reset_iterate(2, 2, near_diagonal)
    equal("counterexample_expected_left", persistence_left, 0, (y, n))
    equal("counterexample_expected_right", persistence_right, 1, (y, n))
    equal("counterexample_expected_reset", bad_reset, 0, 2)
    if persistence_left == persistence_right or bad_reset == reference_predecessor(2):
        raise AssertionError("The stated counterexample did not distinguish the claims.")

    return {
        "status": "passed",
        "scope": "Finite numerical sanity checks; not a formal proof or scalar counter elimination.",
        "bound_inclusive": bound,
        "checks": counts,
        "total_equalities_checked": sum(counts.values()),
        "comparison_examples": [name for name, _ in comparisons],
        "counterexample": {
            "definition": "c(y,n) = 1 exactly when y = n+1; otherwise 0",
            "diagonal_and_strict_diagonal_hold": True,
            "persistence_failure": {
                "y": y,
                "n": n,
                "left": persistence_left,
                "right": persistence_right,
            },
            "reset_failure": {
                "x": 2,
                "constructed_value": bad_reset,
                "predecessor": reference_predecessor(2),
            },
            "limitation": "Refutes this reset construction and persistence from the two diagonal identities alone; does not rule out another predecessor construction.",
        },
        "oracle_notice": "Python predecessor, comparisons, and finite loops provide numerical semantics; no unconditional scalar term for c or p is supplied.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=16)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.bound < 2:
        parser.error("--bound must be at least 2")
    result = json.dumps(run(args.bound), indent=2, sort_keys=True) + "\n"
    if args.output is None:
        print(result, end="")
    else:
        args.output.write_text(result, encoding="utf-8")
        print(f"Passed finite scalar criterion checks; saved {args.output}")


if __name__ == "__main__":
    main()
