"""Untrusted arithmetic transport from fused ordinary recursion to fused R+.

Named syntax, proof constructors, and canonical emitter are adapted from the
pinned fused-binder draft's validation/semantic/translate.py (MIT-0).
The new recorder reads its already validated fused certificates directly;
the new arithmetic compiler maps each old computation to seven R+ nodes.
None of this module is imported by either trusted acceptance program.
"""
from copy import deepcopy
from dataclasses import dataclass
import importlib.util
import itertools
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent
sys.path.insert(0, str(PACKAGE / 'validation'))
from named_oracle import Oracle as SourceOracle, opening
serial = itertools.count()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fresh():
    return 'v' + str(next(serial))


def S(t):
    return ('s', t)


def R(n, a, u, v, h):
    return ('r', n, a, u, v, h)


def Eq(s, t):
    return ('=', s, t)


def Q(x, b):
    return ('q', x, b)


def D(x, y, b):
    return ('d', x, y, b)


def term_key(t, bound=()):
    if t == 0:
        return 0
    if isinstance(t, str):
        return ('bound', bound.index(t)) if t in bound else ('free', t)
    if t[0] == 's':
        return ('s', term_key(t[1], bound))
    _, n, a, u, v, h = t
    return ('r', term_key(n, bound), term_key(a, bound),
            term_key(h, (u, v) + bound))


def key(a, bound=()):
    tag = a[0]
    if tag == '=':
        return ('=', term_key(a[1], bound), term_key(a[2], bound))
    if tag in ('q', 'e'):
        return (tag, key(a[2], (a[1],) + bound))
    return ('d', key(a[3], (a[2], a[1]) + bound))


def same(a, b):
    return key(a) == key(b)


def st(t, variable, image):
    if t == variable:
        return image
    if t == 0 or isinstance(t, str):
        return t
    if t[0] == 's':
        return S(st(t[1], variable, image))
    _, n, a, u, v, h = t
    return R(st(n, variable, image), st(a, variable, image), u, v,
             h if variable in (u, v) else st(h, variable, image))


def sf(a, variable, image):
    tag = a[0]
    if tag == '=':
        return Eq(st(a[1], variable, image), st(a[2], variable, image))
    if tag in ('q', 'e'):
        return a if variable == a[1] else (tag, a[1], sf(a[2], variable, image))
    return a if variable in a[1:3] else D(a[1], a[2], sf(a[3], variable, image))


def instances(a, pairs):
    for variable, image in pairs:
        a = sf(a, variable, image)
    return a


def parse_term(raw, scope, bound=(), holes=()):
    if type(raw) is int:
        if raw == 0:
            return 0
        if raw < 0:
            # Parameters outside retained source scopes are uniformly
            # specialized to zero, as in the inspected upstream transporter.
            return scope.get(raw, 0)
        index = (raw + 1) // 2 - 1
        if index < len(bound):
            return bound[index]
        return holes[index - len(bound)]
    if type(raw) is not list:
        raise ValueError('invalid source term')
    if len(raw) == 1:
        return S(parse_term(raw[0], scope, bound, holes))
    if len(raw) == 3:
        u, v = fresh(), fresh()
        return R(parse_term(raw[0], scope, bound, holes),
                 parse_term(raw[1], scope, bound, holes), u, v,
                 parse_term(raw[2], scope, (u, v) + bound, holes))
    raise ValueError('invalid source term arity')


def witness(raw, scope):
    try:
        return parse_term(raw, scope)
    except (ValueError, IndexError):
        # The source accepts malformed annotations only when never used.
        # The surrounding proof construction checks the resulting premises.
        return 0


@dataclass
class Proof:
    goal: tuple
    rule: str
    data: tuple = ()
    children: tuple = ()


def hyp(a):
    return Proof(a, 'hyp')


def eq_elim(major, variable, matrix, minor):
    require(major.goal[0] == '=', 'equality major is not an equation')
    left, right = major.goal[1:]
    require(same(sf(matrix, variable, left), minor.goal),
            'equality motive has wrong minor premise')
    return Proof(sf(matrix, variable, right), 'eq_elim', (variable, matrix),
                 (major, minor))


def q_elim(major, term, minor):
    require(major.goal[0] == 'q', 'Q major has wrong shape')
    _, x, b = major.goal
    require(same(sf(b, x, 0), minor.goal), 'Q elimination has wrong base')
    return Proof(sf(b, x, term), 'q_elim', (term,), (major, minor))


def d_intro(goal, term, eigen, step):
    require(goal[0] == 'd', 'D introduction has wrong goal')
    _, x, y, b = goal
    expected = instances(b, [(x, term), (y, S(eigen))])
    require(same(expected, step.goal), 'D introduction has wrong step')
    return Proof(goal, 'd_intro', (term, eigen), (step,))


def d_elim(major, eigen, minor):
    require(major.goal[0] == 'd', 'D elimination has wrong major')
    return Proof(minor.goal, 'd_elim', (eigen,), (major, minor))


def q_intro(goal, eigen, step):
    require(goal[0] == 'q', 'derived Q introduction has wrong goal')
    _, y, b = goal
    dummy, discarded = fresh(), fresh()
    major = d_intro(D(dummy, y, b), 0, eigen, step)
    return d_elim(major, discarded, hyp(goal))


def raw_term(t, scope, bound=()):
    if t == 0:
        return 0
    if isinstance(t, str):
        return 2 * bound.index(t) + 1 if t in bound else scope[t]
    if t[0] == 's':
        return [raw_term(t[1], scope, bound)]
    _, n, a, u, v, h = t
    return [raw_term(n, scope, bound), raw_term(a, scope, bound),
            raw_term(h, scope, (u, v) + bound)]


def raw_formula(a, scope, bound=()):
    tag = a[0]
    if tag == '=':
        return [raw_term(a[1], scope, bound), raw_term(a[2], scope, bound)]
    if tag == 'q':
        return [raw_formula(a[2], scope, (a[1],) + bound)]
    if tag == 'd':
        return [raw_formula(a[3], scope, (a[2], a[1]) + bound), [0, 0], [0, 0]]
    raise ValueError('source existential left in target')


class Emitter:
    def __init__(self, initial_scope=None):
        self.initial_scope = {} if initial_scope is None else initial_scope
        self.initial_k = min((0, *self.initial_scope.values()))
        self.k = self.initial_k
        self.cells = []
        self.rule_counts = {}
        self.pruned = 0

    def emit(self, proof, context=(), scope=None):
        scope = {} if scope is None else scope
        goal = raw_formula(proof.goal, scope)
        if goal in context:
            self.pruned += 1
            return
        rule = proof.rule
        self.rule_counts[rule] = self.rule_counts.get(rule, 0) + 1
        if rule == 'hyp':
            raise ValueError('target hypothesis absent from actual context')
        if rule == 'compute':
            self.cells.append([])
        elif rule in ('eq_elim', 'q_elim'):
            major, minor = proof.children
            if rule == 'eq_elim':
                variable, matrix = proof.data
                annotation = raw_formula(matrix, scope, (variable,))
            else:
                annotation = raw_term(proof.data[0], scope)
            self.cells.append([raw_formula(major.goal, scope), annotation])
            self.emit(major, context, scope)
            self.emit(minor, context, scope)
        elif rule == 'd_intro':
            term, eigen = proof.data
            self.cells.append([raw_term(term, scope)])
            self.k -= 1
            local = {**scope, eigen: self.k}
            _, x, y, b = proof.goal
            base = instances(b, [(x, term), (y, 0)])
            added = [raw_formula(base, local)]
            if b[0] == '=':
                added.append(raw_formula(instances(b, [(x, term), (y, eigen)]), local))
            self.emit(proof.children[0], (*context, *added), local)
        elif rule == 'd_elim':
            major, minor = proof.children
            self.cells.append([raw_formula(major.goal, scope), None])
            self.emit(major, context, scope)
            self.k -= 1
            eigen, = proof.data
            local = {**scope, eigen: self.k}
            _, x, y, b = major.goal
            assumption = Q(y, sf(b, x, eigen))
            self.emit(minor, (*context, raw_formula(assumption, local)), local)
        else:
            raise ValueError('unknown target proof rule: ' + rule)

    def packet(self, proof):
        self.emit(proof, scope=self.initial_scope)
        return self.cells[::-1] + [raw_formula(proof.goal, self.initial_scope)]


def parse_formula(raw, scope, bound=(), holes=()):
    """Decode fused Q/D syntax, independently naming all numerical binders."""
    require(type(raw) is list, 'invalid source formula')
    if len(raw) == 2:
        return Eq(*(parse_term(t, scope, bound, holes) for t in raw))
    if len(raw) == 1:
        y = fresh()
        return Q(y, parse_formula(raw[0], scope, (y,) + bound, holes))
    require(len(raw) == 3, 'invalid source formula arity')
    x, y = fresh(), fresh()
    return D(x, y, parse_formula(raw[0], scope, (y, x) + bound, holes))


class FusedRecorder:
    """Record an independently validated source packet as a named proof tree."""
    def __init__(self, packet):
        audit = SourceOracle().run(packet)
        require(audit['accepted'], ('source oracle rejected input', audit))
        self.stack = deepcopy(packet)
        self.raw_goal = self.stack.pop()
        self.lower = 0
        self.counts = {}
        self.audit = audit

    def open(self, value, images=(), *, formula=True, depth=0):
        return opening(value, images, formula=formula, depth=depth, lower=self.lower)

    def step(self, raw, context=(), scope=None):
        scope = {} if scope is None else scope
        self.open(raw)
        goal = parse_formula(raw, scope)
        if raw in context:
            return Proof(goal, 'hyp')
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            first = self.step(major, context, scope)
            if len(major) == 3:
                self.lower -= 1
                eigen = fresh()
                local = {**scope, self.lower: eigen}
                assumption = self.open([major[0]], [self.lower])
                minor = self.step(raw, (*context, assumption), local)
                return Proof(goal, 'd_elim', (eigen,), (first, minor))
            if len(major) == 1:
                matrix, left, right = major[0], 0, annotation
                data = (witness(right, scope),)
                rule = 'q_elim'
            else:
                matrix, (left, right) = annotation, major
                hole = fresh()
                data = (hole, parse_formula(matrix, scope, holes=(hole,)))
                rule = 'eq_elim'
            require(self.open(matrix, [right]) == raw, 'source transport endpoint mismatch')
            second = self.step(self.open(matrix, [left]), context, scope)
            return Proof(goal, rule, data, (first, second))
        if type(instruction) is list and len(instruction) == 1 and len(raw) == 3:
            body = self.open(raw[0], instruction, depth=1)
            extra = [self.open(body, [0])]
            if len(body) == 2:
                extra.append(body)
            self.lower -= 1
            eigen = fresh()
            local = {**scope, self.lower: eigen}
            new_goal = self.open(body, [[self.lower]])
            additions = [self.open(a, [self.lower]) for a in extra]
            minor = self.step(new_goal, (*context, *additions), local)
            return Proof(goal, 'd_intro', (witness(instruction[0], scope), eigen), (minor,))
        require(type(instruction) is list and instruction == [] and len(raw) == 2,
                'unrecognized validated source instruction')
        return Proof(goal, 'compute')

    def proof(self):
        result = self.step(self.raw_goal)
        require(self.lower == self.audit['final_k']
                and len(self.stack) == self.audit['remaining'],
                'source recorder and independent oracle diverged')
        return result


def predecessor(t):
    """p(t)=A(t,0;u,v.v); p(0)=one, while p(sigma(x))=x."""
    u, v = fresh(), fresh()
    return R(t, 0, u, v, v)


def arithmetic_term(t):
    """Compile a fixed ordinary recursor expression to Rstar in A syntax."""
    if t == 0 or isinstance(t, str):
        return t
    if t[0] == 's':
        return S(arithmetic_term(t[1]))
    _, n, a, u, v, h = t
    n, a, h = arithmetic_term(n), arithmetic_term(a), arithmetic_term(h)
    protected = st(h, u, predecessor(u))
    return predecessor(R(n, a, u, v, S(protected)))


def arithmetic_formula(a):
    tag = a[0]
    if tag == '=':
        return Eq(arithmetic_term(a[1]), arithmetic_term(a[2]))
    if tag == 'q':
        return Q(a[1], arithmetic_formula(a[2]))
    require(tag == 'd', 'unrecognized logical constructor')
    return D(a[1], a[2], arithmetic_formula(a[3]))


def absorbed_computation(left, right):
    require(isinstance(left, tuple) and left[0] == 'r', 'not an A application')
    _, n, a, u, v, h = left
    if n == 0:
        expected = S(a)
    else:
        require(isinstance(n, tuple) and n[0] == 's', 'nonliteral successor counter')
        previous = n[1]
        expected = st(st(h, u, R(previous, a, u, v, h)), v, previous)
    require(term_key(expected) == term_key(right), 'incorrect absorbed computation')
    return Proof(Eq(left, right), 'compute')


def absorbed_refl(t):
    source = absorbed_computation(predecessor(S(t)), t)
    x = fresh()
    return eq_elim(source, x, Eq(x, t), source)


def absorbed_sym(p):
    x = fresh()
    return eq_elim(p, x, Eq(x, p.goal[1]), absorbed_refl(p.goal[1]))


def compile_computation(goal):
    """Seven native nodes prove each translated ordinary computation equation."""
    wanted = arithmetic_formula(goal)
    encoded_left, right = wanted[1:]
    require(encoded_left[0] == 'r', 'translated old recursor is not decoded')
    inner = encoded_left[1]
    first = absorbed_computation(inner, S(right))
    second = absorbed_computation(predecessor(S(right)), right)
    hole = fresh()
    proof = eq_elim(absorbed_sym(first), hole, Eq(predecessor(hole), right), second)
    require(same(proof.goal, wanted), 'translated computation conclusion differs')
    return proof


def compile_proof(proof):
    if proof.rule == 'compute':
        return compile_computation(proof.goal)
    goal = arithmetic_formula(proof.goal)
    children = tuple(compile_proof(p) for p in proof.children)
    data = proof.data
    if proof.rule == 'eq_elim':
        data = (data[0], arithmetic_formula(data[1]))
    elif proof.rule == 'q_elim':
        data = (arithmetic_term(data[0]),)
    elif proof.rule == 'd_intro':
        data = (arithmetic_term(data[0]), data[1])
    else:
        require(proof.rule in ('hyp', 'd_elim'), 'unrecognized proof rule')
    return Proof(goal, proof.rule, data, children)


def proof_size(proof):
    return 1 + sum(proof_size(p) for p in proof.children)


def load_kernel(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_kernel(module, packet):
    stream = deepcopy(packet)
    module.k = 0
    module.take = stream.pop
    try:
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'remaining': len(stream),
            'final_k': module.k, 'error': error}


def transport(packet):
    recorded = FusedRecorder(packet)
    source = recorded.proof()
    canonical = Emitter().packet(source)
    canonical_audit = SourceOracle().run(canonical)
    require(canonical_audit['accepted'] and canonical_audit['remaining'] == 0,
            ('canonical source replay failed', canonical_audit))
    target = compile_proof(source)
    emitter = Emitter()
    result = emitter.packet(target)
    require(same(target.goal, arithmetic_formula(source.goal)),
            'arithmetic translation changed its claimed conclusion')
    return result, {'source_instruction_cells': len(packet) - 1 - recorded.audit['remaining'],
                    'source_tree_nodes': proof_size(source),
                    'target_tree_nodes': proof_size(target),
                    'target_instruction_cells': len(result) - 1,
                    'target_eigenparameters': -emitter.k,
                    'target_rules': emitter.rule_counts,
                    'pruned_target_subtrees': emitter.pruned,
                    'source_unused_prefix_cells': recorded.audit['remaining']}


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    result, report = transport(json.loads(args.source.read_text()))
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    args.destination.write_text(json.dumps(result, separators=(',', ':')) + '\n')
    print(json.dumps(report, indent=2))
