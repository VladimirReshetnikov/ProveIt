"""Reproduce finite validation of the joint successor-absorbed/fused kernel.

All compiler, oracle, and evidence code is outside the trusted checker.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import subprocess
import sys
import types

import transport as tr
from absorbed_oracle import Oracle

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent
KERNEL = PACKAGE / 'checker_absorbed.py'
RESULT = PACKAGE / 'results/absorbed_validation.json'


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, separators=(',', ':')) + '\n')


def compare(kernel, packet, expected, name):
    actual = tr.run_kernel(kernel, packet)
    oracle = Oracle().run(packet)
    require(actual['accepted'] == oracle['accepted'] == expected,
            (name, expected, actual, oracle))
    if expected:
        require(actual['remaining'] == oracle['remaining'] == 0,
                (name, 'unused translated proof cells'))
        require(actual['final_k'] == oracle['final_k'],
                (name, 'eigenparameter histories differ'))
    return actual, oracle


def cli(path, expected, optimized):
    command = [sys.executable, *(['-O'] if optimized else []), str(KERNEL), str(path)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=15)
    require((result.returncode, result.stdout.strip(), result.stderr) ==
            ((0, 'ACCEPT', '') if expected else (1, 'REJECT', '')),
            (str(path), command, result.returncode, result.stdout, result.stderr))


def native_cases():
    truth = [0, 0]
    yield 'A_zero_returns_successor', [[], [[0, 0, 0], [0]]], True
    yield 'A_zero_nonzero_initializer', [[], [[0, [0], 0], [[0]]]], True
    yield 'decoder_at_zero_is_one', [[], [[0, 0, 3], [0]]], True
    yield 'decoder_at_successor_zero', [[], [[[0], 0, 3], 0]], True
    yield 'successor_state_reuses_original_initializer', \
        [[], [[[0], 0, 1], [0, 0, 1]]], True
    yield 'old_R_zero_axiom_is_invalid', [[], [[0, 0, 0], 0]], False
    yield 'wrong_decoder_zero_is_invalid', [[], [[0, 0, 3], 0]], False
    yield 'double_wrapped_initializer_is_invalid', \
        [[], [[[0], 0, 1], [0, [0], 1]]], False
    yield 'false_equality', [[], [0, [0]]], False
    yield 'false_closure_step', [[0], [[1, 0], truth, truth]], False
    yield 'first_witness_cannot_be_bound_coordinate', [[1], [[3, 3], truth, truth]], False
    yield 'first_witness_cannot_be_future_parameter', [[-1], [[3, 3], truth, truth]], False
    yield 'boolean_is_not_a_term', [[], [[0, False, 0], [False]]], False
    yield 'unused_padding_is_still_validated', [[0], [truth, None, truth]], False
    yield 'undeclared_parameter_in_padding', [[0], [truth, [-1, -1], truth]], False
    yield 'unused_witness_is_inert', [[{'unused': True}], [truth, truth, truth]], True
    yield 'native_reflexivity', tr.Emitter().packet(tr.absorbed_refl(0)), True
    x, y, eigen = tr.fresh(), tr.fresh(), tr.fresh()
    proof = tr.d_intro(tr.D(x, y, tr.Eq(y, y)), 0, eigen,
                       tr.absorbed_refl(tr.S(eigen)))
    yield 'native_two_binder_reflexivity', tr.Emitter().packet(proof), True
    x, y, eigen = tr.fresh(), tr.fresh(), tr.fresh()
    proof = tr.d_intro(tr.D(x, y, tr.Eq(x, x)), tr.predecessor(tr.S(0)), eigen,
                       tr.Proof(tr.Eq(tr.predecessor(tr.S(0)),
                                      tr.predecessor(tr.S(0))), 'hyp'))
    yield 'native_recursive_witness', tr.Emitter().packet(proof), True
    y, eigen = tr.fresh(), tr.fresh()
    closure = tr.q_intro(tr.Q(y, tr.Eq(y, y)), eigen,
                         tr.absorbed_refl(tr.S(eigen)))
    yield 'native_derived_closure', tr.Emitter().packet(closure), True
    term = tr.predecessor(tr.S(tr.S(0)))
    proof = tr.q_elim(closure, term, tr.absorbed_refl(0))
    yield 'native_closure_at_recursion', tr.Emitter().packet(proof), True


def numerical_validation():
    x, y, u, v, w, z = (tr.fresh() for _ in range(6))
    steps = [0, u, v, tr.S(u), tr.S(v), x, y,
             tr.R(v, u, w, z, tr.S(w))]
    terms = [tr.R(n, a, u, v, h)
             for n in (0, tr.S(0), x, tr.S(x))
             for a in (0, y) for h in steps]
    terms += [tr.R(tr.R(x, y, w, z, tr.S(w)), a, u, v, h)
              for a in (0, y) for h in (u, tr.S(u))]
    translated = [tr.arithmetic_term(t) for t in terms]
    evaluations = 0

    def evaluate(t, environment, absorbed, fuel):
        fuel[0] -= 1
        require(fuel[0] >= 0, 'finite numerical validation exhausted its budget')
        if t == 0:
            return 0
        if isinstance(t, str):
            return environment[t]
        if t[0] == 's':
            return evaluate(t[1], environment, absorbed, fuel) + 1
        _, n, a, previous, counter, h = t
        count = evaluate(n, environment, absorbed, fuel)
        value = evaluate(a, environment, absorbed, fuel) + int(absorbed)
        for i in range(count):
            value = evaluate(h, {**environment, previous: value, counter: i}, absorbed, fuel)
        return value

    for old, new in zip(terms, translated):
        for a in range(4):
            for b in range(4):
                environment = {x: a, y: b}
                left = evaluate(old, environment, False, [100000])
                right = evaluate(new, environment, True, [100000])
                require(left == right, ('interpretation numerical mismatch', old, environment, left, right))
                evaluations += 1
    decoder = []
    for n in range(21):
        numeral = 0
        for _ in range(n):
            numeral = tr.S(numeral)
        value = evaluate(tr.predecessor(numeral), {}, True, [100000])
        require(value == (1 if n == 0 else n - 1), ('decoder value', n, value))
        decoder.append(value)
    return {'source_terms': len(terms), 'assignments_per_term': 16,
            'source_target_comparisons': evaluations, 'skipped_cases': 0,
            'decoder_inputs': list(range(21)), 'decoder_values': decoder,
            'limitation': 'Finite standard-value checks; internal universal identities are proved in the paper.'}


def mutation_controls(code, cases):
    controls = [
        ('omit_successor_at_zero', '            t = [t]\n', '            t = t\n',
         'old_R_zero_axiom_is_invalid'),
        ('double_wrap_recursive_initializer', '[n, *t, r]', '[n, t, r]',
         'double_wrapped_initializer_is_invalid'),
        ('open_inner_binder_as_outer', 'b = inst(b, t, d=2)', 'b = inst(b, t)',
         'false_closure_step'),
    ]
    rows = []
    for name, old, new, attack in controls:
        require(code.count(old) == 1, ('mutation target mismatch', name))
        module = types.ModuleType(name)
        exec(compile(code.replace(old, new), name, 'exec'), module.__dict__)
        packet = cases[attack]
        require(tr.run_kernel(module, packet)['accepted'], ('mutation not detected', name))
        rows.append({'defect': name, 'attack': attack,
                     'mutant_accepts': True, 'delivered_checker_and_oracle_reject': True})
    return rows


def main():
    kernel = tr.load_kernel(KERNEL, 'joint_absorbed_kernel')
    source_kernel = tr.load_kernel(PACKAGE / 'checker.py', 'joint_source_kernel')
    manifest = json.loads((PACKAGE / 'validation/fixtures_manifest.json').read_text())
    source_rows = [r for r in manifest['cases'] if r['name'].split('/')[0] in ('theorems', 'aliases')]
    require(len(source_rows) == 45, 'expected 43 theorem and two alias source fixtures')
    rows, cohorts, rule_counts = [], Counter(), Counter()
    source_cells = target_cells = target_nodes = allocations = cli_runs = 0
    for entry in source_rows:
        path = PACKAGE / 'validation' / entry['file']
        require(sha256(path.read_bytes()).hexdigest() == entry['sha256'], ('source fixture changed', entry['name']))
        packet = json.loads(path.read_text())
        require(tr.run_kernel(source_kernel, packet)['accepted'], ('main checker rejects source fixture', entry['name']))
        translated, report = tr.transport(packet)
        actual, oracle = compare(kernel, translated, True, entry['name'])
        destination = ROOT / 'examples' / (entry['name'].replace('/', '__') + '.json')
        save(destination, translated)
        for optimized in (False, True):
            cli(destination, True, optimized)
            cli_runs += 1
        rows.append({'name': entry['name'], 'source_sha256': entry['sha256'],
                     'file': str(destination.relative_to(ROOT)),
                     'sha256': sha256(destination.read_bytes()).hexdigest(), **report})
        cohorts[entry['name'].split('/')[0]] += 1
        source_cells += report['source_instruction_cells']
        target_cells += report['target_instruction_cells']
        target_nodes += sum(oracle['rules'].values())
        allocations += len(oracle['allocations'])
        rule_counts.update(oracle['rules'])
    native_rows, native_packets = [], {}
    for name, packet, expected in native_cases():
        native_packets[name] = packet
        actual, oracle = compare(kernel, packet, expected, name)
        destination = ROOT / 'native' / (name + '.json')
        save(destination, packet)
        for optimized in (False, True):
            cli(destination, expected, optimized)
            cli_runs += 1
        native_rows.append({'name': name, 'expected': expected,
                            'file': str(destination.relative_to(ROOT)),
                            'sha256': sha256(destination.read_bytes()).hexdigest(),
                            'kernel': actual, 'oracle_rules': oracle['rules']})
    mutations = mutation_controls(KERNEL.read_text(), native_packets)
    numerical = numerical_validation()
    sys.path.insert(0, str(PACKAGE / 'comparison'))
    from source_measure import metrics
    result = {'status': 'PASS', 'python': platform.python_version(),
              'checker': 'checker_absorbed.py', 'metrics': metrics(KERNEL),
              'transported_cohorts': dict(cohorts), 'transported_packets': len(rows),
              'source_instruction_cells': source_cells,
              'target_instruction_cells': target_cells,
              'independently_audited_inference_nodes': target_nodes,
              'eigenparameter_allocations_checked': allocations,
              'independent_oracle_rules': dict(rule_counts),
              'native_packets': len(native_rows),
              'native_accepts': sum(r['expected'] for r in native_rows),
              'native_rejections': sum(not r['expected'] for r in native_rows),
              'public_cli_runs': cli_runs,
              'mutation_controls': mutations, 'numerical_validation': numerical,
              'transported_results': rows, 'native_results': native_rows,
              'limitations': [
                  'Finite tests do not establish soundness or completeness for all certificates.',
                  'Both kernels target closed statements; the corpus already contains closed specializations.',
                  'Canonical serialization normalizes bound-coordinate aliases and inert D annotations.',
                  'The arithmetic compiler and adapted named oracle are untrusted validation support.']}
    RESULT.parent.mkdir(parents=True, exist_ok=True)
    RESULT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('transported_results', 'native_results')}, indent=2))


if __name__ == '__main__':
    main()
