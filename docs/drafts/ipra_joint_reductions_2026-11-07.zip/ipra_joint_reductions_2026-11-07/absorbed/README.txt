JOINT SUCCESSOR ABSORPTION AND BINDER FUSION
==========================================

Trusted acceptance program: ../checker_absorbed.py
Whole program: 422 normalized tokens, 435 AST nodes, 1230 normalized UTF-8 bytes.
Checking core: 363 normalized tokens, 373 AST nodes, 986 normalized bytes.
Counts use the unchanged corpus measurement under CPython 3.12.14.

This companion combines two separately proved reductions in the inspected
corpus. Its logical basis is equality, closure Q, and the fused D binder.
Its mathematical numerical signature is zero and the initialized constructor A:

    sigma(a) = A(0,a;u,v.0)
    A(0,a;u,v.h) = sigma(a)
    A(sigma(n),a;u,v.h) = h[A(n,a;u,v.h)/u, n/v].

The exact serialized term [a] abbreviates sigma(a). Its parser branch is in the
measured program. The signature reduction is not a claim that this serialization
alias disappeared from the checker. The logical proof rules are the same as for
the main fused calculus; only the numerical constructor's zero equation changes.

The decoder p(n)=A(n,0;u,v.v) satisfies p(sigma(n))=n and p(0)=sigma(0).
It is NOT the usual truncated predecessor at zero. Ordinary recursion is:

    Rstar(n,a;u,v.h) = p(A(n,a;u,v.sigma(h[p(u)/u]))).

The paper proves both ordinary computation equations, the reverse universal
identity, and the identity-domain interpretation round trips. The finite tests
in this directory support the implementation; they do not replace those proofs.

WHY THE COMPUTATION BRANCH WORKS
--------------------------------
The checker first changes the local Python initializer t to [t]. Thus, when the
counter is zero, the comparison with the requested right side implements
A(0,t;h)=sigma(t). At a successor counter, [n,*t,r] expands the one-element list
back to [n, original_initializer, r], giving exactly A(n,a;h). The initializer
must not be wrapped a second time. Both mistakes have dedicated negative tests
and deliberately incorrect local-program mutations that accept those tests.

The direct call inst(b,t,d=2) opens the OUTER witness coordinate of D while
protecting its inner closure coordinate. A separate mutation test changes d=2
to zero and then incorrectly accepts the false closure y=0 for every y.

REPRODUCE
---------
From the package root:

    python3 absorbed/validate.py

This reads the 43 theorem fixtures and two alias fixtures already present in
validation/fixtures, verifies their recorded hashes, and checks their source
proofs with the main kernel and an independent named-binder oracle. It records
those fused proofs as named derivations, translates every numerical term via
Rstar, replaces every old computation node by seven native A proof nodes, and
emits ordinary JSON certificates. The companion kernel and its independent
named oracle then check each output. All 45 outputs are saved in examples/.

The named oracle is adapted from ../validation/named_oracle.py. Its sole
arithmetic change is that the zero-computation result is [initial]. It does
not use the production constructor-width table, packed depth calculation,
Python match branches, or production substitution function. Provenance and
source hashes are in provenance.json.

RESULTS
-------
The recorded run in ../results/absorbed_validation.json passed:

  * 45 transported packets: 43 theorem fixtures and two alias regressions;
  * 807 source and 3033 target instruction cells;
  * 3094 independently audited inference nodes and 85 eigenparameter allocations;
  * 21 native cases: 11 accepted and 10 rejected;
  * 132 public command-line runs, covering normal Python and python -O;
  * three deliberate defect controls, each detected by its negative certificate;
  * 1088 numerical interpretation comparisons: 68 source terms under 16
    assignments, with no skipped case;
  * decoder values at inputs zero through twenty, including p(0)=one.

These are overlapping validation cohorts, not counts of independent theorems.

For example, these commands must print ACCEPT:

    python3 checker_absorbed.py absorbed/native/A_zero_returns_successor.json
    python3 checker_absorbed.py absorbed/native/native_two_binder_reflexivity.json

This command must print REJECT and exit with status 1:

    python3 checker_absorbed.py absorbed/native/old_R_zero_axiom_is_invalid.json

BOUNDS OF THE EVIDENCE
---------------------
Both delivered kernels have a closed-statement public interface. Their theory
still has arbitrary numerical parameters internally, and closed encodings of
universal assertions represent open mathematics. The input theorem corpus
already contains closed specializations. This transport does not claim to
construct universal closures of external free parameters.

The named emitter normalizes the paired spellings of bound coordinates and the
semantically inert D annotation fields. Therefore target packets need not retain
the byte spelling of their source statements. Their decoded goals are precisely
the arithmetic translations, up to bound-variable renaming.

No Python validation is claimed as a Lean, Rocq, or other mechanized proof of
soundness, completeness, or bi-interpretability. No claim of absolute minimality
or historical novelty follows from the finite-source comparison.
