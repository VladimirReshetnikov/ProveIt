#!/bin/sh
set -eu
task_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$task_dir"
latexmk -pdf -interaction=nonstopmode -halt-on-error pra_retraction.tex
