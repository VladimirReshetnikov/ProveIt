#!/bin/sh
set -eu
task_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$task_dir"
python3 artifacts/check_retraction.py --bound 64 --output-dir artifacts
if [ -n "${PRA_LEAN:-}" ]; then
  lean_executable=$PRA_LEAN
elif command -v lean >/dev/null 2>&1; then
  lean_executable=lean
else
  printf '%s\n' 'Lean is not on PATH; formal rerun skipped. See the supplied audit log.'
  exit 0
fi
"$lean_executable" --version
"$lean_executable" formal/RetractResources.lean > formal/RetractResources.log
cat formal/RetractResources.log
