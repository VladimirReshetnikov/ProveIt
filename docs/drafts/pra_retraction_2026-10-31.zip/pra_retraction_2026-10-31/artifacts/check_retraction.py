#!/usr/bin/env python3
"""Exact display metrics and bounded diagnostics for the PRA retraction basis.

Only the Python standard library is required.  Run, for example,

    python3 check_retraction.py --bound 64 --output-dir .

To regenerate provenance from the downloaded comparison archives, add
``--source-root /path/to/research_sources``.  That directory must contain
repository_manifest.json and the ZIP files listed in that manifest.

The numerical checks concern ordinary finite natural numbers only.  They
are diagnostics, not a proof of theory equivalence or bi-interpretability.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Iterable
import zipfile


@dataclass(frozen=True)
class Node:
    kind: str
    name: str
    children: tuple["Node", ...] = ()

    def size(self) -> int:
        return 1 + sum(child.size() for child in self.children)

    def occurrences(self, kind: str) -> int:
        return int(self.kind == kind) + sum(
            child.occurrences(kind) for child in self.children
        )

    def sexpr(self) -> str:
        if not self.children:
            return self.name
        head = f"forall {self.name}" if self.kind == "forall" else self.name
        return "(" + head + " " + " ".join(c.sexpr() for c in self.children) + ")"


def var(name: str) -> Node:
    return Node("variable", name)


def app(name: str, *children: Node) -> Node:
    return Node("application", name, tuple(children))


def eq(left: Node, right: Node) -> Node:
    return Node("equality", "=", (left, right))


def connective(name: str, *children: Node) -> Node:
    return Node("connective", name, tuple(children))


def all_of(names: Iterable[str], body: Node) -> Node:
    for name in reversed(tuple(names)):
        body = Node("forall", name, (body,))
    return body


ZERO = Node("constant", "0")
BOTTOM = Node("bottom", "bottom")


def succ(term: Node) -> Node:
    return app("S", term)


def pred(term: Node) -> Node:
    # An actual expansion, not an extra primitive unary symbol.
    return app("P", term, ZERO)


def separation() -> Node:
    # 0 != 1 expands as (0 = S(0)) -> bottom.
    return connective("implies", eq(ZERO, succ(ZERO)), BOTTOM)


def successor_schema(parameter_count: int, delayed: bool = False) -> Node:
    """P^0_S, or the previously available delayed-wrapper version DU_S."""
    n = var("n")
    names = tuple(f"a{i + 1}" for i in range(parameter_count))
    parameters = tuple(var(name) for name in names)

    def f(argument: Node) -> Node:
        return app("f", argument, *parameters)

    premise = all_of(("n",), eq(f(succ(n)), succ(f(n))))
    if delayed:
        comparison = succ(app("D_S", n, f(ZERO)))
    else:
        comparison = app("A", succ(pred(n)), f(ZERO))
    conclusion = connective(
        "and",
        separation(),
        all_of(
            ("n",),
            connective("or", eq(n, ZERO), eq(f(n), comparison)),
        ),
    )
    return all_of(names, connective("implies", premise, conclusion))


def shift_axiom() -> Node:
    n, a = var("n"), var("a")
    return all_of(
        ("n", "a"),
        eq(app("M", succ(n), succ(a)), app("M", n, a)),
    )


def retraction_axiom() -> Node:
    n, a = var("n"), var("a")
    return all_of(("n", "a"), eq(app("M", n, app("A", n, a)), a))


def metrics() -> dict:
    shift, retract = shift_axiom(), retraction_axiom()
    k, v = var("k"), var("v")
    wrapper = app("P", app("B", k, succ(v)), succ(v))
    rows = []
    for count in range(5):
        direct = successor_schema(count)
        delayed = successor_schema(count, delayed=True)
        # Independent arithmetic summaries of the trees are sanity checks.
        assert direct.size() == 31 + 5 * count
        assert delayed.size() == 29 + 5 * count
        assert direct.occurrences("equality") == 4
        assert delayed.occurrences("equality") == 4
        rows.append(
            {
                "parameter_count": count,
                "P0_S_nodes": direct.size(),
                "P0_S_equality_occurrences": direct.occurrences("equality"),
                "P0_S_quantifiers": direct.occurrences("forall"),
                "baseline_P0_S_plus_Shift_nodes": direct.size() + shift.size(),
                "new_P0_S_plus_Ret_nodes": direct.size() + retract.size(),
                "saving_with_same_direct_schema": shift.size() - retract.size(),
                "existing_DU_S_nodes": delayed.size(),
                "optional_DU_S_plus_Ret_nodes": delayed.size() + retract.size(),
                "P0_S_expanded_tree": direct.sexpr(),
                "DU_S_expanded_tree": delayed.sexpr(),
            }
        )
    assert shift.size() == 11
    assert retract.size() == 9
    assert wrapper.size() == 7
    return {
        "metric": {
            "charge": "One node per variable occurrence, constant, application, "
            "equality, connective, falsity, and single-variable quantifier.",
            "expanded_abbreviations": ["1 = S(0)", "p(n) = P(n,0)",
                                       "not A = (A implies bottom)"],
            "schematic_calls": "f is charged as an application with its displayed "
            "arguments; the arbitrarily substituted program body is not expanded.",
            "description_indices": "A stored function-description index is part "
            "of the declared function symbol, not another numerical argument.",
            "common_computation_grammar": "Both direct bases use the same full "
            "L_PR description grammar, including arbitrary finite frozen "
            "parameter tuples. Its computation templates are unchanged and "
            "are excluded from both arithmetic totals; the binary-grammar "
            "18-node total is NOT substituted for this different grammar.",
            "optimality": "These are fixed-convention display comparisons, "
            "not representation-independent minimality claims.",
        },
        "fixed_axioms": {
            "Shift": {"nodes": shift.size(), "tree": shift.sexpr()},
            "Ret": {"nodes": retract.size(), "tree": retract.sexpr()},
        },
        "optional_delayed_wrapper": {
            "status": "The delayed-wrapper trick is already present in the "
            "autonomous_uniqueness comparison archive; it is not a new claim.",
            "definition": "K_S(k,v) = P(B(k,S(v)),S(v)); D_S = I_{K_S}",
            "descriptor_tree": wrapper.sexpr(),
            "descriptor_nodes": wrapper.size(),
            "cost_note": "The descriptor is disclosed separately because the "
            "display convention excludes stored program descriptions. It is "
            "not an additional numerical argument or a free implementation.",
        },
        "rows": rows,
    }


def successor_iteration(n: int, a: int) -> int:
    result = a
    for _ in range(n):
        result += 1
    return result


def predecessor_iteration(n: int, a: int) -> int:
    result = a
    for _ in range(n):
        result = max(result - 1, 0)
    return result


def counting_process(n: int, a: int) -> tuple[int, int, int]:
    """Return (M,C,D) from the actual one-step counting recurrences.

    M(0,a)=a, C(0,a)=D(0,a)=0.
    M decrements with saturation. C counts steps whose old M is nonzero;
    D counts steps whose old M is zero. No min/max closed form for the
    counters is used in this evaluator.
    """
    remaining, consumed, after_zero = a, 0, 0
    for _ in range(n):
        if remaining == 0:
            after_zero += 1
        else:
            consumed += 1
        remaining = max(remaining - 1, 0)
    return remaining, consumed, after_zero


def diagnostics(bound: int) -> dict:
    checks: dict[str, int] = {}

    def check(name: str, condition: bool, point: tuple[int, ...]) -> None:
        if not condition:
            raise AssertionError(f"{name} failed at {point}")
        checks[name] = checks.get(name, 0) + 1

    for n in range(bound + 1):
        check("diagonal_M(n,n)=0", predecessor_iteration(n, n) == 0, (n,))
        check("next_diagonal_M(n,S(n))=1",
              predecessor_iteration(n, n + 1) == 1, (n,))
        for a in range(bound + 1):
            point = (n, a)
            m, c, d = counting_process(n, a)
            check("M_agrees_with_predecessor_iteration",
                  m == predecessor_iteration(n, a), point)
            check("M+C=a", m + c == a, point)
            check("C+D=n", c + d == n, point)
            check("D=0_or_M=0", d == 0 or m == 0, point)
            check("C=min(n,a)", c == min(n, a), point)
            check("D=reverse_M", d == predecessor_iteration(a, n), point)
            check("Ret_M(n,A(n,a))=a",
                  predecessor_iteration(n, successor_iteration(n, a)) == a,
                  point)
            check("baseline_Shift",
                  predecessor_iteration(n + 1, a + 1) == m, point)
            reverse = predecessor_iteration(a, n)
            check("native_equality_reflection",
                  ((m + reverse) == 0) == (n == a), point)
            check("joint_zero_reflection",
                  (m == 0 and reverse == 0) == (n == a), point)
            check("positive_diagonal_counter",
                  n != a or (c == n and d == 0), point)
    return {
        "status": "passed",
        "scope": "Bounded standard-natural-number diagnostics only. These "
        "checks are NOT a theorem proof, a formal derivation audit, or a "
        "verification of arbitrary nonstandard or Kripke models.",
        "input_range_inclusive": [0, bound],
        "grid_points": (bound + 1) ** 2,
        "M_convention": "M(n,a) = a with n saturated predecessor steps",
        "counter_recurrences": {
            "M": "M(0,a)=a; M(Sn,a)=p(M(n,a))",
            "C": "C(0,a)=0; C(Sn,a)=C(n,a)+[M(n,a)!=0]",
            "D": "D(0,a)=0; D(Sn,a)=D(n,a)+[M(n,a)=0]",
        },
        "checks_by_name": checks,
        "total_assertions": sum(checks.values()),
    }


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob_sha1(data: bytes) -> str:
    header = b"blob " + str(len(data)).encode("ascii") + b"\0"
    return hashlib.sha1(header + data).hexdigest()


def source_audit(source_root: Path) -> dict:
    manifest_path = source_root / "repository_manifest.json"
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    commit = manifest["sha"]
    repository = "VladimirReshetnikov/ProveIt"
    archives = []
    for item in manifest["drafts"]:
        archive_path = source_root / item["name"]
        archive_bytes = archive_path.read_bytes()
        observed_blob = git_blob_sha1(archive_bytes)
        if observed_blob != item["sha"]:
            raise ValueError(f"Git blob mismatch: {item['name']}")
        if len(archive_bytes) != item["size"]:
            raise ValueError(f"Size mismatch: {item['name']}")
        members = []
        with zipfile.ZipFile(archive_path) as archive:
            for member in sorted(archive.namelist()):
                if not member.endswith(".tex"):
                    continue
                data = archive.read(member)
                extracted = source_root / "drafts" / archive_path.stem / member
                extracted_matches = None
                if extracted.is_file():
                    extracted_matches = extracted.read_bytes() == data
                    if not extracted_matches:
                        raise ValueError(f"Extracted source mismatch: {member}")
                members.append(
                    {"archive_member": member, "size_bytes": len(data),
                     "sha256": sha256(data),
                     "extracted_copy_matches_archive": extracted_matches}
                )
        archives.append(
            {
                "filename": item["name"],
                "repository_path": item["path"],
                "size_bytes": len(archive_bytes),
                "git_blob_sha1": observed_blob,
                "git_blob_verified": True,
                "sha256": sha256(archive_bytes),
                "immutable_url":
                    f"https://github.com/{repository}/blob/{commit}/{item['path']}",
                "immutable_download_url":
                    f"https://raw.githubusercontent.com/{repository}/{commit}/"
                    f"{item['path']}",
                "latex_members": members,
            }
        )
    index_path = source_root / "incoming_README.md"
    incoming = {
        "repository_path": "docs/incoming/README.md",
        "immutable_url":
            f"https://github.com/{repository}/blob/{commit}/docs/incoming/README.md",
        "inspection_scope": "The incoming index and directory inventory were "
            "checked for PRA material. No PRA-labelled entry was found. "
            "Unrelated PA/Turing-machine archive interiors were not inspected.",
    }
    if index_path.is_file():
        index_bytes = index_path.read_bytes()
        incoming.update({"size_bytes": len(index_bytes),
                         "sha256": sha256(index_bytes),
                         "git_blob_sha1": git_blob_sha1(index_bytes)})
    return {
        "repository": repository,
        "snapshot_commit": commit,
        "snapshot_url": f"https://github.com/{repository}/tree/{commit}",
        "source_manifest_sha256": sha256(manifest_bytes),
        "audit_method": "Downloaded ZIP bytes verified against Git blob "
            "identities and sizes returned by GitHub. LaTeX members have "
            "individual SHA-256 hashes; available extracted copies were "
            "compared byte-for-byte with their archive members.",
        "draft_archives": archives,
        "incoming_index": incoming,
    }


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n",
                    encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=64)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).parent)
    parser.add_argument("--source-root", type=Path)
    args = parser.parse_args()
    if args.bound < 0:
        parser.error("--bound must be nonnegative")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    result = {"formula_metrics": metrics(), "finite_diagnostics": diagnostics(args.bound)}
    results_path = args.output_dir / "retraction_checks.json"
    write_json(results_path, result)
    print(f"Metrics and bounded diagnostics passed: {results_path}")
    print("At one parameter: P0_S=36; Shift=11; Ret=9; "
          "direct totals 47 -> 45. Existing DU_S+Ret=43 (wrapper disclosed).")
    print(f"Finite diagnostics: {result['finite_diagnostics']['total_assertions']} "
          f"assertions on 0..{args.bound}; diagnostic, not a theorem proof.")
    if args.source_root is not None:
        audit_path = args.output_dir / "source_audit.json"
        audit = source_audit(args.source_root)
        write_json(audit_path, audit)
        print(f"Verified {len(audit['draft_archives'])} comparison archives: {audit_path}")


if __name__ == "__main__":
    main()
