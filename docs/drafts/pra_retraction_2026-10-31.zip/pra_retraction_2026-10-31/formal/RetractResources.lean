/-
Constructive certificate for the new retraction bridge.

Lean 4.19.0; no imports, Nat induction, Classical, or admitted proofs.
The carrier is arbitrary. All arithmetic assumptions are explicit parameters.
The final theorem starts with positive successor uniqueness, the computation
equations, finite latch/counter availability, and the fixed retraction
  sub n (add n a) = a.
It derives constructor coverage, separation, ordinary successor uniqueness,
native cancellation, native constancy, zero-test induction, the resource
invariants, the subtraction diagonal, and a test reflecting native equality.

Scope: this is an abstract semantic proof kernel, not a formalization of
first-order syntax or of the recursive description grammar. The two counters
are supplied with their defining equations; their availability as finite
primitive-recursion descriptions is justified separately in the manuscript.
Successor uniqueness and zero induction are quantified over ambient function
objects here. Only the displayed finitely many term instances are used.
-/

universe u

namespace RetractResources

structure Data (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  add : A → A → A
  sub : A → A → A
  sel : A → A → A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  add_zero : ∀ a, add zero a = a
  add_succ : ∀ n a, add (succ n) a = succ (add n a)
  sub_zero : ∀ a, sub zero a = a
  sub_succ : ∀ n a, sub (succ n) a = pred (sub n a)
  sel_zero : ∀ a b, sel zero a b = a
  sel_succ : ∀ n a b, sel (succ n) a b = b

variable {A : Type u}

def Coverage (d : Data A) : Prop :=
  ∀ n, n = d.zero ∨ n = d.succ (d.pred n)

def SuccessorUniqueness (d : Data A) : Prop :=
  ∀ f : A → A, (∀ n, f (d.succ n) = d.succ (f n)) →
    ∀ n, f n = d.add n (f d.zero)

def PositiveSuccessor (d : Data A) : Prop :=
  ∀ f : A → A, (∀ n, f (d.succ n) = d.succ (f n)) →
    d.zero ≠ d.succ d.zero ∧
    ∀ n, n = d.zero ∨ f n = d.add (d.succ (d.pred n)) (f d.zero)

def ZeroInduction (d : Data A) : Prop :=
  ∀ f : A → A, f d.zero = d.zero →
    (∀ n, f n = d.zero → f (d.succ n) = d.zero) →
    ∀ n, f n = d.zero

def Retract (d : Data A) : Prop :=
  ∀ n a, d.sub n (d.add n a) = a

def Latches (d : Data A) : Prop :=
  ∀ e : A → A, ∃ q : A → A,
    q d.zero = d.succ d.zero ∧
    ∀ n, q (d.succ n) = d.sel (e n) (q n) d.zero

structure Counters (d : Data A) where
  c : A → A → A
  z : A → A → A
  c_zero : ∀ a, c d.zero a = d.zero
  z_zero : ∀ a, z d.zero a = d.zero
  c_succ : ∀ n a, c (d.succ n) a =
    d.sel (d.sub n a) (c n a) (d.succ (c n a))
  z_succ : ∀ n a, z (d.succ n) a =
    d.sel (d.sub n a) (d.succ (z n a)) (z n a)

theorem successor_nonzero (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (n : A) : d.succ n ≠ d.zero := by
  intro h
  have hn : n = d.zero := by
    have hp := congrArg d.pred h
    rw [d.pred_succ, d.pred_zero] at hp
    exact hp
  apply sep
  rw [hn] at h
  exact h.symm

theorem positive_successor_constructors (d : Data A) (ps : PositiveSuccessor d) :
    d.zero ≠ d.succ d.zero ∧ Coverage d := by
  have hi := ps (fun n => n) (fun _ => rfl)
  have hz : ∀ n, d.add n d.zero = n := by
    intro n
    cases hi.2 (d.succ n) with
    | inl h => exact False.elim (successor_nonzero d hi.1 n h)
    | inr h =>
      rw [d.pred_succ, d.add_succ] at h
      have hp := congrArg d.pred h
      rw [d.pred_succ, d.pred_succ] at hp
      exact hp.symm
  constructor
  · exact hi.1
  · intro n
    cases hi.2 n with
    | inl h => exact Or.inl h
    | inr h =>
      apply Or.inr
      rw [d.add_succ, hz] at h
      exact h

theorem uniqueness_of_positive_successor (d : Data A) (ps : PositiveSuccessor d) :
    SuccessorUniqueness d := by
  have hc := positive_successor_constructors d ps
  intro f hf n
  cases (ps f hf).2 n with
  | inl hn => rw [hn, d.add_zero]
  | inr he =>
    cases hc.2 n with
    | inl hn => rw [hn, d.add_zero]
    | inr hn =>
      calc
        f n = d.add (d.succ (d.pred n)) (f d.zero) := he
        _ = d.add n (f d.zero) :=
          congrArg (fun x => d.add x (f d.zero)) hn.symm

theorem zero_decision (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (n : A) : n = d.zero ∨ n ≠ d.zero := by
  cases cov n with
  | inl h => exact Or.inl h
  | inr h =>
    apply Or.inr
    intro hz
    exact successor_nonzero d sep (d.pred n) (h.symm.trans hz)

theorem positive_rebuild (d : Data A) (cov : Coverage d)
    (n : A) (hn : n ≠ d.zero) : d.succ (d.pred n) = n := by
  cases cov n with
  | inl h => exact False.elim (hn h)
  | inr h => exact h.symm

theorem select_nonzero (d : Data A) (cov : Coverage d)
    (n a b : A) (hn : n ≠ d.zero) : d.sel n a b = b := by
  rw [← positive_rebuild d cov n hn]
  exact d.sel_succ (d.pred n) a b

theorem select_zero_zero (d : Data A) (cov : Coverage d)
    (n : A) : d.sel n d.zero d.zero = d.zero := by
  cases cov n with
  | inl h => rw [h, d.sel_zero]
  | inr h => rw [h, d.sel_succ]

theorem add_zero_right (d : Data A) (us : SuccessorUniqueness d)
    (n : A) : d.add n d.zero = n := by
  exact (us (fun x => x) (fun _ => rfl) n).symm

theorem add_succ_right (d : Data A) (us : SuccessorUniqueness d)
    (n a : A) : d.add n (d.succ a) = d.succ (d.add n a) := by
  have h := us (fun x => d.succ (d.add x a))
    (fun x => congrArg d.succ (d.add_succ x a)) n
  simp only [d.add_zero] at h
  exact h.symm

theorem native_cancellation (d : Data A) (ret : Retract d)
    (n a b : A) (h : d.add n a = d.add n b) : a = b := by
  have hm := congrArg (d.sub n) h
  rw [ret n a, ret n b] at hm
  exact hm

theorem native_constancy (d : Data A) (us : SuccessorUniqueness d)
    (ret : Retract d) (f : A → A)
    (hf : ∀ n, f (d.succ n) = f n) (n : A) : f n = f d.zero := by
  have hs : ∀ x, d.add (d.succ x) (f (d.succ x)) =
      d.succ (d.add x (f x)) := by
    intro x
    rw [hf x, d.add_succ]
  have h := us (fun x => d.add x (f x)) hs n
  rw [d.add_zero] at h
  exact native_cancellation d ret n (f n) (f d.zero) h

theorem latch_zero_induction (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (us : SuccessorUniqueness d) (ret : Retract d)
    (e q : A → A) (q0 : q d.zero = d.succ d.zero)
    (qs : ∀ n, q (d.succ n) = d.sel (e n) (q n) d.zero)
    (eb : e d.zero = d.zero)
    (es : ∀ n, e n = d.zero → e (d.succ n) = d.zero) :
    ∀ n, e n = d.zero := by
  have q1 : q (d.succ d.zero) = d.succ d.zero := by
    rw [qs, eb, d.sel_zero, q0]
  have stationary : ∀ n, q (d.succ (d.succ n)) = q (d.succ n) := by
    intro n
    cases zero_decision d sep cov (e n) with
    | inl he =>
      rw [qs (d.succ n), es n he, d.sel_zero]
    | inr he =>
      have hq : q (d.succ n) = d.zero := by
        rw [qs n, select_nonzero d cov _ _ _ he]
      rw [qs (d.succ n), hq, select_zero_zero d cov]
  have qtail : ∀ n, q (d.succ n) = d.succ d.zero := by
    intro n
    exact (native_constancy d us ret (fun x => q (d.succ x)) stationary n).trans q1
  intro n
  cases zero_decision d sep cov (e n) with
  | inl he => exact he
  | inr he =>
    have hq : q (d.succ n) = d.zero := by
      rw [qs n, select_nonzero d cov _ _ _ he]
    exact False.elim (sep (hq.symm.trans (qtail n)))

theorem zero_induction_of_latches (d : Data A)
    (sep : d.zero ≠ d.succ d.zero) (cov : Coverage d)
    (us : SuccessorUniqueness d) (ret : Retract d)
    (latches : Latches d) : ZeroInduction d := by
  intro e eb es
  obtain ⟨q, q0, qs⟩ := latches e
  exact latch_zero_induction d sep cov us ret e q q0 qs eb es

theorem sum_zero (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (a b : A) (h : d.add a b = d.zero) :
    a = d.zero ∧ b = d.zero := by
  cases cov a with
  | inl ha =>
    constructor
    · exact ha
    · rw [ha, d.add_zero] at h
      exact h
  | inr ha =>
    have hs : d.succ (d.add (d.pred a) b) = d.zero := by
      calc
        d.succ (d.add (d.pred a) b) = d.add (d.succ (d.pred a)) b :=
          (d.add_succ (d.pred a) b).symm
        _ = d.add a b := congrArg (fun x => d.add x b) ha.symm
        _ = d.zero := h
    exact False.elim (successor_nonzero d sep (d.add (d.pred a) b) hs)

theorem select_zero_test (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (a b : A) :
    d.sel a d.zero b = d.zero ↔ a = d.zero ∨ b = d.zero := by
  cases zero_decision d sep cov a with
  | inl ha =>
    rw [ha, d.sel_zero]
    constructor
    · intro _
      exact Or.inl rfl
    · intro _
      rfl
  | inr ha =>
    rw [select_nonzero d cov a d.zero b ha]
    constructor
    · intro hb
      exact Or.inr hb
    · intro h
      cases h with
      | inl h0 => exact False.elim (ha h0)
      | inr hb => exact hb

theorem resource_invariants (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (us : SuccessorUniqueness d) (ret : Retract d)
    (r : Counters d) (a n : A) :
    d.add (r.c n a) (d.sub n a) = a ∧ d.add (r.c n a) (r.z n a) = n := by
  have hs : ∀ x, d.add (r.c (d.succ x) a) (d.sub (d.succ x) a) =
      d.add (r.c x a) (d.sub x a) := by
    intro x
    cases zero_decision d sep cov (d.sub x a) with
    | inl hm =>
      rw [r.c_succ, d.sub_succ, hm, d.sel_zero, d.pred_zero]
    | inr hm =>
      rw [r.c_succ, select_nonzero d cov _ _ _ hm, d.sub_succ]
      rw [d.add_succ, ← add_succ_right d us]
      rw [positive_rebuild d cov _ hm]
  have hi := native_constancy d us ret
    (fun x => d.add (r.c x a) (d.sub x a)) hs n
  rw [r.c_zero, d.sub_zero, d.add_zero] at hi
  have ht : ∀ x, d.add (r.c (d.succ x) a) (r.z (d.succ x) a) =
      d.succ (d.add (r.c x a) (r.z x a)) := by
    intro x
    cases zero_decision d sep cov (d.sub x a) with
    | inl hm =>
      rw [r.c_succ, r.z_succ, hm, d.sel_zero, d.sel_zero]
      exact add_succ_right d us _ _
    | inr hm =>
      rw [r.c_succ, r.z_succ,
        select_nonzero d cov _ _ _ hm, select_nonzero d cov _ _ _ hm]
      exact d.add_succ _ _
  have hj := us (fun x => d.add (r.c x a) (r.z x a)) ht n
  rw [r.c_zero, r.z_zero, d.add_zero, add_zero_right d us] at hj
  exact ⟨hi, hj⟩

theorem resource_orthogonality (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (zi : ZeroInduction d) (r : Counters d) (a n : A) :
    r.z n a = d.zero ∨ d.sub n a = d.zero := by
  let e : A → A := fun x => d.sel (r.z x a) d.zero (d.sub x a)
  have hb : e d.zero = d.zero := by
    dsimp [e]
    rw [r.z_zero, d.sel_zero]
  have hs : ∀ x, e x = d.zero → e (d.succ x) = d.zero := by
    intro x hx
    apply (select_zero_test d sep cov _ _).2
    have hh := (select_zero_test d sep cov (r.z x a) (d.sub x a)).1 hx
    cases hh with
    | inl hz =>
      cases zero_decision d sep cov (d.sub x a) with
      | inl hm =>
        apply Or.inr
        rw [d.sub_succ, hm, d.pred_zero]
      | inr hm =>
        apply Or.inl
        rw [r.z_succ, select_nonzero d cov _ _ _ hm, hz]
    | inr hm =>
      apply Or.inr
      rw [d.sub_succ, hm, d.pred_zero]
  exact (select_zero_test d sep cov _ _).1 (zi e hb hs n)

theorem subtraction_diagonal (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (us : SuccessorUniqueness d) (ret : Retract d)
    (zi : ZeroInduction d) (r : Counters d) (n : A) : d.sub n n = d.zero := by
  have hi := resource_invariants d sep cov us ret r n n
  have he : d.sub n n = r.z n n :=
    native_cancellation d ret (r.c n n) (d.sub n n) (r.z n n)
      (hi.1.trans hi.2.symm)
  cases resource_orthogonality d sep cov zi r n n with
  | inl hz => exact he.trans hz
  | inr hm => exact hm

theorem subtraction_zero_witness (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (us : SuccessorUniqueness d) (ret : Retract d)
    (r : Counters d) (x y : A) (hm : d.sub x y = d.zero) :
    d.add y (r.z x y) = x := by
  have hi := resource_invariants d sep cov us ret r y x
  have hc : r.c x y = y := by
    have h := hi.1
    rw [hm, add_zero_right d us] at h
    exact h
  rw [hc] at hi
  exact hi.2

theorem double_subtraction_zero (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (us : SuccessorUniqueness d) (ret : Retract d)
    (r : Counters d) (x y : A)
    (hxy : d.sub x y = d.zero) (hyx : d.sub y x = d.zero) : x = y := by
  have hx := subtraction_zero_witness d sep cov us ret r x y hxy
  have hu : r.z x y = d.zero := by
    calc
      r.z x y = d.sub y (d.add y (r.z x y)) := (ret y (r.z x y)).symm
      _ = d.sub y x := congrArg (d.sub y) hx
      _ = d.zero := hyx
  rw [hu, add_zero_right d us] at hx
  exact hx.symm

theorem native_equality_reflection (d : Data A) (sep : d.zero ≠ d.succ d.zero)
    (cov : Coverage d) (us : SuccessorUniqueness d) (ret : Retract d)
    (zi : ZeroInduction d) (r : Counters d) (x y : A) :
    d.add (d.sub x y) (d.sub y x) = d.zero ↔ x = y := by
  constructor
  · intro h
    have hm := sum_zero d sep cov _ _ h
    exact double_subtraction_zero d sep cov us ret r x y hm.1 hm.2
  · intro h
    rw [h, subtraction_diagonal d sep cov us ret zi r, d.add_zero]

theorem selector_equality_reflection (d : Data A)
    (sep : d.zero ≠ d.succ d.zero) (cov : Coverage d)
    (us : SuccessorUniqueness d) (ret : Retract d)
    (zi : ZeroInduction d) (r : Counters d) (x y : A) :
    d.sel (d.sub x y) (d.sub y x) (d.succ d.zero) = d.zero ↔ x = y := by
  constructor
  · intro h
    cases zero_decision d sep cov (d.sub x y) with
    | inl hxy =>
      rw [hxy, d.sel_zero] at h
      exact double_subtraction_zero d sep cov us ret r x y hxy h
    | inr hxy =>
      rw [select_nonzero d cov _ _ _ hxy] at h
      exact False.elim (sep h.symm)
  · intro h
    rw [h, subtraction_diagonal d sep cov us ret zi r, d.sel_zero]

theorem equality_reflection_from_latches (d : Data A)
    (sep : d.zero ≠ d.succ d.zero) (cov : Coverage d)
    (us : SuccessorUniqueness d) (ret : Retract d)
    (latches : Latches d) (r : Counters d) (x y : A) :
    d.sel (d.sub x y) (d.sub y x) (d.succ d.zero) = d.zero ↔ x = y := by
  exact selector_equality_reflection d sep cov us ret
    (zero_induction_of_latches d sep cov us ret latches) r x y

theorem equality_reflection_from_positive_successor (d : Data A)
    (ps : PositiveSuccessor d) (ret : Retract d)
    (latches : Latches d) (r : Counters d) (x y : A) :
    d.sel (d.sub x y) (d.sub y x) (d.succ d.zero) = d.zero ↔ x = y := by
  have hc := positive_successor_constructors d ps
  exact equality_reflection_from_latches d hc.1 hc.2
    (uniqueness_of_positive_successor d ps) ret latches r x y

#print axioms positive_successor_constructors
#print axioms uniqueness_of_positive_successor
#print axioms native_cancellation
#print axioms native_constancy
#print axioms latch_zero_induction
#print axioms zero_induction_of_latches
#print axioms resource_invariants
#print axioms resource_orthogonality
#print axioms subtraction_diagonal
#print axioms double_subtraction_zero
#print axioms native_equality_reflection
#print axioms selector_equality_reflection
#print axioms equality_reflection_from_latches
#print axioms equality_reflection_from_positive_successor

end RetractResources
