PRA FROM SUCCESSOR UNIQUENESS AND ONE RETRACTION
=============================================
Research note prepared for Vladimir Reshetnikov
31 October 2026

RESULT
------
In either classical or intuitionistic first-order equality logic, use:

  (D)   all ordinary finite primitive-recursive defining equations;
  (PS)  positive uniqueness for the fixed successor update;
  (Ret) M(n,A(n,a)) = a, universally quantified in n,a.

Here A(0,a)=a, A(Sn,a)=S(A(n,a)), M(0,a)=a,
M(Sn,a)=p(M(n,a)), p(0)=0, p(Sn)=n.  In the standard model,
A(n,a)=n+a and M(n,a)=max(a-n,0); note the argument order.

This theory and ordinary PRA prove exactly the same formulas in the
same effective description language, separately in the two logics.
Both interpretations and both composite isomorphisms are the identity.

THE IMPROVEMENT
---------------
The matched baseline is the full-language successor-only + Shift variant
in pra_zero_origin_2026-10-31.zip.  The defining grammar and successor
schema are unchanged.  Shift is M(Sn,Sa)=M(n,a); Ret is shorter.
Counting universal quantifiers, Shift has 11 formula-tree nodes and Ret
has 9.  At one schematic parameter, the arithmetic display total falls
from 47 to 45 under the drafts' convention.  The existing delayed wrapper
can give 43, with its additional description compiler explicitly charged.

The main proof improvement is the direct two-counter construction of
native equality reflection.  Ret gives cancellation, which gives
constancy, which gives zero-test induction through a latch.  The counters
then recover native equality without a subtraction-shift axiom or
predecessor uniqueness, and without parity or a Boolean diagonal scanner.

This is not an absolute shortestness theorem.  The strict binary-iterator
language in other drafts has a different resource budget.  The article
compares these alternatives explicitly and does not claim a total-size
win over every row in every language.

FILES
-----
pra_retraction.tex           Self-contained LaTeX article.
pra_retraction.pdf           Compiled article, with the complete proof.
SPECIFICATION.txt            Exact axioms, syntax, and scope.
formal/RetractResources.lean Constructive abstract proof kernel.
formal/RetractResources.log  Compiler endpoint-dependency audit.
formal/RETRACT_SCOPE.txt     Exact formal-verification scope.
artifacts/check_retraction.py  Standard-library metrics and diagnostics.
artifacts/retraction_checks.json  Generated results.
artifacts/validation.json    Package validation record.
source_audit.json            Immutable source paths and verified hashes.
build.sh                    Rebuild the PDF.
check.sh                    Run diagnostics and, when available, Lean.
SHA256SUMS.txt               Digests of packaged files (except itself).

VERIFICATION SCOPE
------------------
The full first-order equivalence and bi-interpretability proof is the
mathematical proof in the article.  The Lean certificate checks its
constructive algebraic kernel through native equality reflection, with
explicit semantic callbacks for the required constructions.  It does
not encode the full finite-term grammar, first-order proof calculus, or
bi-interpretation metatheorem.  See formal/RETRACT_SCOPE.txt.

Lean 4.19.0 compiled the certificate successfully.  All 14 printed
endpoint declarations have no global axiom dependencies; their arithmetic
hypotheses remain explicit.  The Python script passed 46,605 bounded
assertions over inputs 0..64 and reproduced the exact display metrics.
Those numerical checks are diagnostics, not proofs about all models.

REBUILD
-------
Required for the paper: a TeX Live installation with latexmk, pdfLaTeX,
amsmath, amsthm, mathtools, lmodern, microtype, booktabs, tabularx, fancyhdr,
hyperref, and xurl.

  sh build.sh
  sh check.sh

To select a Lean executable explicitly:

  PRA_LEAN=/absolute/path/to/lean sh check.sh

The Python checks need only Python 3.10 or later and its standard library.
If Lean is unavailable, check.sh reports that the formal rerun was skipped;
the supplied successful audit log remains the record of the original run.

To check the delivered bytes before rebuilding:

  sha256sum -c SHA256SUMS.txt

PROVENANCE
----------
Compared all six current docs/drafts ZIPs at ProveIt commit
514b6dfd2c1232848a259549c352b1935d53191c.  The incoming directory inventory
and text index were also inspected.  Exact paths, archive hashes, source
member hashes, and immutable URLs are in source_audit.json.

The positive successor schema and latch method are credited to the
supplied drafts.  The new contributions are the retraction replacement
and the direct two-counter native-equality proof.  The delayed-wrapper
option is explicitly credited to the autonomous-uniqueness archive.
