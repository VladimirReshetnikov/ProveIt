# Research provenance (25 November 2026)

The GitHub connector retrieved the listing of `VladimirReshetnikov/ProveIt`, `main`, `docs/drafts`. ZIP files were read via the connector's base64 file endpoint; the following README files (and selected manuscript keyword matches where indicated) were decoded. This was a selective review, not a full line-by-line comparison of every archive.

| Archive | Observed focus |
|---|---|
| `union_closed_rank_transport_2026-11-25.zip` | principal-filter entropy corrections and majorization |
| `union_closed_redundant_core_2026-11-25.zip` | redundant-incidence core, weighted binomial thresholds |
| `union_closed_dense_core_2026-11-25.zip` | generators omitted by a core point, translates |
| `union_closed_partial_theorems_2026-11-25.zip` | degree-four high-girth result (high-girth README only) |
| `union_closed_antichain_shadows_2026-11-25.zip` | antichains, upper shadows and entropy envelopes |
| `union_closed_local_abundance.zip` | regular incidence girth, pointwise abundance |
| `union_closed_marked_abundance.zip` | graph endpoint bounds, ambient Boolean-cube deletion profiles, tagged generators |
| `union_closed_lopsided_certificates_2026-11-25.zip` | negative-dependency graph and degree thresholds |
| `union_closed_signature_interfaces_2026-11-25.zip` | generator signatures and rank |
| `union_closed_frequency_bounds.zip` | entropy, rare overlapping triples, marked four-point member and tree endpoints |

Directory: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

Public antecedents: Knill's minimal hitting-set argument is classical (see https://arxiv.org/abs/math/9409215 and Nagel's exposition https://www-user.tu-chemnitz.de/~ninag/Masterarbeit_Nicolas_Nagel.pdf). The elementary partition into disjoint/containing/partial members is also classical; see https://mathworld.wolfram.com/Union-ClosedSetsConjecture.html. In particular, the 19-member rare-triple example has a published antecedent according to the community report at https://mathdb.com/p/355601/the-union-closed-sets-conjecture, citing van der Hout and Roos, https://doi.org/10.23952/jano.8.2026.1.02. The community report contains stronger results on the minimum total family size for rare minimal triples. This note addresses a different extremal question with parameters r,b,k and does not supersede those size results.

Public searches included combinations of "union closed", "Frankl", "partial intersections", "transversal", "trace", "abundance", "hitting set", and Knill. No exact match for the general local integer/weighted envelope and its sharpness construction was identified in the inspected material. This is not a certification of historical priority. The results are independently derived and fully argued, but remain candidates for original contributions pending a fuller literature review, inspection of the remaining archive manuscripts and independent mathematical review. No new universal abundance constant or proof of the full conjecture is claimed.
