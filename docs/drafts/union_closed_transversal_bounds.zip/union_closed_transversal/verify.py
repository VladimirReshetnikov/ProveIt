#!/usr/bin/env python3
"""Independent finite audit of the transversal bounds; Python standard library."""
import itertools
import random
import json
import csv
from collections import Counter
from pathlib import Path


def require(condition, *context):
    if not condition:
        raise AssertionError(context)


def uc(family):
    return all((a | b) in family for a in family for b in family)


def submasks(a):
    s = a
    while True:
        yield s
        if not s:
            break
        s = (s - 1) & a


def bits(a):
    return [1 << i for i in range(a.bit_length()) if a >> i & 1]


def parameters(f, a):
    partial = [s for s in f if s & a not in (0, a)]
    z = sum(not (s & a) for s in f)
    t = sum(s & a == a for s in f)
    return partial, z, t


def audit_member(f, a):
    p, z, t = parameters(f, a)
    r, b = len(p), t-z
    require(b >= 0 and len(f) == z+t+r, f, a)
    if not p:
        require(2*t >= len(f))
        return 0
    cases = 0
    for h in submasks(a):
        if not h or not all(s & h for s in p):
            continue
        hbits = bits(h)
        if not all(any(s & h == x for s in p) for x in hbits):
            continue  # not inclusion-minimal
        cases += 1
        k = len(hbits)
        if k == 1:
            require(sum(bool(s & h) for s in f) == t+r)
            require(2*(t+r) >= len(f))
            continue
        s0, c = (1 << k)-2, (1 << (k-1))-1
        q = r-s0
        hist = Counter(s & h for s in p)
        require(all(hist[j] >= 1 for j in submasks(h) if j not in (0,h)))
        e = [sum(bool(s & x) for s in p)-c for x in hbits]
        require(q >= 0 and min(e) >= 0 and sum(e) >= q)
        require(max(e) >= (q+k-1)//k)
        eq = hist[h] == 0 and all(hist[j] == 1 for j in submasks(h) if j not in (0,h) and j.bit_count() >= 2)
        require((sum(e)==q)==eq)
        if 2*((q+k-1)//k) >= q-b:
            require(2*(t+c+max(e)) >= len(f))
        if all(2*sum(bool(s & x) for s in f) < len(f) for x in bits(a)):
            require(k >= 3 and q <= k*((q-b-1)//2))
        w = [i*i for i in range(1,k+1)]
        require(sum(i*j for i,j in zip(w,e)) >= q*min(w))
    return cases


def make_extremizer(k, b, u, extra=0):
    q=sum(u)
    a=(1<<k)-1
    common=((1<<(k+extra))-1)<<k
    d0=1<<(2*k+extra)
    d=[d0<<(j+1) for j in range(q)]
    D=common|d0|sum(d)
    f={0,a}
    for j in range(extra):
        C=((1<<(k+j))-1)<<k
        f.update([C,C|a])
    assign=[1<<i for i,v in enumerate(u) for _ in range(v)]
    for dj,x in zip(d,assign):
        B=D^dj
        f.update([B,B|x,B|a])
    f.update(D|s for s in submasks(a))
    for j in range(b):
        D |= d0<<(q+1+j)
        f.add(D|a)
    return f,a


def threshold(k,b):
    return (1<<k)-2+b+1+2*((b+k-2)//(k-2))


def audit_extremizer(k,b,u,extra=0):
    f,a=make_extremizer(k,b,u,extra)
    require(uc(f),k,b,u)
    p,z,t=parameters(f,a)
    q=sum(u); s0=(1<<k)-2; c=(1<<(k-1))-1
    require(len(p)==s0+q and t-z==b and z==q+2+extra)
    require(min(s.bit_count() for s in f if s)==k)
    require(all(any(s&a==x for s in p) for x in bits(a)))
    require([sum(bool(s&x) for s in f)-t-c for x in bits(a)]==list(u))
    return f,a


def main():
    totals=Counter()
    for n in range(1,5):
        count=0
        for mask in range(1,1<<(1<<n)):
            f={i for i in range(1<<n) if mask>>i&1}
            if not uc(f): continue
            count+=1
            for a in f-{0}:
                totals['exhaustive_member_tests']+=1
                totals['exhaustive_transversal_tests']+=audit_member(f,a)
        totals[f'nonempty_union_closed_families_n{n}']=count
    rng=random.Random(20261125)
    for _ in range(300):
        n=rng.randint(5,9)
        f={0}
        for _ in range(rng.randint(2,12)):
            g=rng.randrange(1,1<<n)
            f|={s|g for s in f}
        if rng.randrange(2): f.discard(0)
        require(uc(f))
        for a in rng.sample(sorted(f-{0}),min(5,len(f-{0}))):
            totals['random_member_tests']+=1
            totals['random_transversal_tests']+=audit_member(f,a)
    for k in range(3,11):
        for b in range(101):
            R=threshold(k,b); s0=(1<<k)-2
            q=R-s0
            require(q<=k*((q-b-1)//2))
            require(all(j>k*((j-b-1)//2) for j in range(q)))
            totals['threshold_arithmetic_tests']+=1
    for k in range(2,8):
        for b in range(6):
            for q in (0,1,2,3,8,13):
                u=[q//k+(i<q%k) for i in range(k)]
                f,a=audit_extremizer(k,b,u,extra=rng.randrange(3))
                require(max(sum(bool(s&x) for s in f) for x in bits(a))==parameters(f,a)[2]+(1<<(k-1))-1+(q+k-1)//k)
                totals['balanced_extremizers']+=1
                v=[0]*(k-1)+[q]
                audit_extremizer(k,b,v)
                totals['weighted_extremizers']+=1
    for k in range(3,8):
        for b in range(13):
            q=threshold(k,b)-((1<<k)-2)
            u=[q//k+(i<q%k) for i in range(k)]
            f,a=audit_extremizer(k,b,u)
            require(all(2*sum(bool(s&x) for s in f)<len(f) for x in bits(a)))
            totals['first_rarity_extremizers']+=1
    f,a=audit_extremizer(3,0,[1,1,1])
    require(len(f)==19 and [sum(bool(s&x) for s in f) for x in bits(a)]==[9,9,9])
    with Path(__file__).with_name('example_19.json').open('w') as out:
        json.dump({'encoding':'integer bit masks; bitwise OR is union','A':a,'members':sorted(f),'frequency_A':[9,9,9]},out,indent=2)
        out.write('\n')
    with Path(__file__).with_name('thresholds.csv').open('w',newline='') as out:
        w=csv.writer(out); w.writerow(['b','k=3','k=4','k=5','k=6','k=7','minimum','minimizers'])
        for b in [0,1,2,4,8,16,32,64,128,256,1024,10000]:
            vals=[]; k=3
            while not vals or (1<<k)-2<=min(v for _,v in vals):
                vals.append((k,threshold(k,b))); k+=1
            mn=min(v for _,v in vals)
            w.writerow([b,*[threshold(k,b) for k in range(3,8)],mn,','.join(str(k) for k,v in vals if v==mn)])
    print(json.dumps({'status':'PASS','seed':20261125,**totals},indent=2,sort_keys=True))


if __name__=='__main__': main()
