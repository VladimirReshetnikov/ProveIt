# Sharp transversal bounds for local abundance

Read `paper.pdf` first. `paper.tex` contains the complete self-contained mathematical proofs. The main result is an exact local frequency envelope in terms of partial intersections, an inclusion-minimal hitting set and the surplus of containing over disjoint members. The bound is optimal in those parameters, with explicit union-closed extremizers. It proves Frankl's half-frequency conclusion under the stated local hypotheses, not in general.

## Reproduce

Requires Python 3.10+ (standard library only) and a normal TeX Live installation with AMS, geometry, Latin Modern, booktabs, xcolor, microtype and hyperref.

```sh
sha256sum -c SHA256SUMS
python3 verify.py > verification.json
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

`verification.json` records the actual run. `thresholds.csv` lists selected exact thresholds and minimizing transversal sizes; `example_19.json` encodes a boundary example. Rebuilding a PDF may change metadata. The finite checks are supplementary to the mathematical proofs and do not constitute proof-assistant verification. The nine-partial-member example is not claimed as new. Priority of the general refinement is provisional; see `provenance.md`. No repository files were modified.
