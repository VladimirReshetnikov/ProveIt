#!/usr/bin/env python3
"""Exact finite audit of the trace-obstruction theorems; standard library only."""
from itertools import combinations, product
from random import Random


def subsets(xs):
    xs = tuple(xs)
    for k in range(len(xs)+1):
        yield from combinations(xs, k)


def meet(xs, top):
    for x in xs:
        top &= x
    return top


def closure(xs, top):
    out = {top}
    for x in xs:
        out |= {d & x for d in out}
    return out


def subset(a, b):
    return (a & b) == a


def outside(d, T, S):
    return not subset(d, T) and not subset(d, S)


def irredundant(J, R):
    d = meet(J, R)
    return all(meet(J[:i]+J[i+1:], R) != d for i in range(len(J)))


def direct_gap(T, S, L, K):
    """Independent primal computation: enumerate generator selections and OR."""
    H = (T,S)+tuple(L)
    generators = [sum(1 << j for j,a in enumerate(H) if not (a >> i & 1))
                  for i in range(K.bit_length()) if K >> i & 1]
    rows = {0}
    for g in generators:
        rows |= {r | g for r in rows}
    N = len(rows)
    fT = sum(bool(r & 1) for r in rows)
    fS = sum(bool(r & 2) for r in rows)
    return N, fT, fS


def audit(T, S, L, K, primal=False):
    R = T & S
    L = tuple(L)
    dct = {}
    for J in subsets(L):
        C = closure(J, K)
        traces = closure(J, R)
        Q = {d for d in C if outside(d,T,S)}
        full = closure((T,S)+J, K)
        N = len(full)
        c, q = len(traces), len(Q)
        fT = sum(not subset(d,T) for d in full)
        fS = sum(not subset(d,S) for d in full)
        assert fT+fS-N == q-c
        if primal:
            assert direct_gap(T,S,J,K) == (N,fT,fS)
        witness = bool(J) and irredundant(J,R) and not outside(meet(J,K),T,S)
        if witness:
            assert len(J) <= R.bit_count()
            assert c == 2**len(J) and q < c
        covered = {d & R for d in Q}
        dct[J] = (c,q,witness,covered,traces,N,fT,fS)
    for J,(c,q,witness,covered,traces,N,fT,fS) in dct.items():
        w = [I for I in subsets(J) if dct[I][2]]
        bad = [I for I in subsets(J) if dct[I][0]>dct[I][1]]
        assert bool(w) == bool(bad)
        # Exact: absence of witnesses is equivalent to full lifting in every subcollection.
        assert bool(w) == any(dct[I][3] != dct[I][4] for I in subsets(J))
        if bad:
            assert min(map(len,bad)) == min(map(len,w))
        if c>q:
            assert w and min(map(len,w)) <= R.bit_count()
        if not w:
            assert covered == traces
        # Approximate lift: every trace with at most s missing labels lifts if no short obstruction.
        for s in range(R.bit_count()+1):
            if not any(len(I)<=s for I in w):
                assert {d for d in traces if (R^d).bit_count()<=s} <= covered
                if not subset(T,S) and not subset(S,T) and s==R.bit_count()-1:
                    assert (fT+fS)*(2**(R.bit_count()+1)+1) >= N*2**(R.bit_count()+1)
    return len(dct), any(v[2] for v in dct.values())


def sharp(t):
    R=(1<<t)-1; Z=R<<t; u=1<<(2*t); v=u<<1; K=R|Z|u|v
    T=R|u; S=R|v
    L=tuple((R^(1<<i)) | (Z^(1<<(t+i))) for i in range(t))
    return T,S,L,K


def robust_example(m):
    pairs=tuple(combinations(range(m),2)); t=len(pairs)
    R=(1<<t)-1; Z=((1<<m)-1)<<t
    u=1<<(t+m); v=u<<1; K=R|Z|u|v
    T=R|u; S=R|v
    L=tuple(sum(1<<j for j,pair in enumerate(pairs) if i in pair)|(Z^(1<<(t+i))) for i in range(m))
    return T,S,L,K


def sat_instance(n, clauses):
    # Literals use +/- 1,...,n. One auxiliary per literal.
    R=(1<<n)-1; u=1<<n; v=u<<1; Z=((1<<n)-1)<<(n+2)
    C=((1<<len(clauses))-1)<<(2*n+2)
    W=((1<<(2*n))-1)<<(2*n+2+len(clauses))
    K=R|u|v|Z|C|W; T=R|u; S=R|v
    aux=[]
    for i in range(n):
        for b in (0,1):
            lit=(i+1)*(1 if b else -1)
            A=(R^(1<<i))|u|(Z^(1<<(n+2+i)))
            A |= sum(1<<(2*n+2+j) for j,cl in enumerate(clauses) if lit not in cl)
            A |= 1<<(2*n+2+len(clauses)+2*i+b)
            aux.append(A)
    H=(T,S)+tuple(aux)
    assert all(not subset(a,b) for a,b in product(H,H) if a!=b)
    assert len(set(H))==2+2*n
    assert meet(H,K)==0  # every generator nonempty
    return T,S,tuple(aux),K


def sat_truth(n, clauses):
    for bits in product((0,1),repeat=n):
        lits={(i+1)*(1 if b else -1) for i,b in enumerate(bits)}
        if all(lits.intersection(cl) for cl in clauses):
            return True
    return False


def main():
    rng=Random(20261125)
    checked=0; cases=0
    # Exhaust all auxiliary families for fixed incomparable marks on five labels.
    T,S,K=7,11,31
    cand=[a for a in range(K) if a not in (T,S) and not subset(a,T)
          and not subset(a,S) and not subset(T,a) and not subset(S,a)]
    for L in (L for k in range(5) for L in combinations(cand,k)):
        n,_=audit(T,S,L,K,primal=True); checked+=n; cases+=1
    print(f'Exhaustive minimal-mark systems (at most four auxiliaries): {cases} systems, {checked} erasures (primal cross-check).')
    # Include comparable/nonminimal marks, a stronger theorem than the antecedent.
    for i in range(160):
        t=rng.randrange(1,7); K=(1<<(t+3))-1; R=(1<<t)-1
        T=R|(1<<t); S=R if i%3==0 else R|(1<<(t+1))
        cand=[a for a in range(K) if a not in (T,S)]
        if i%2==0 and not subset(S,T):
            cand=[a for a in cand if not any(subset(a,b) or subset(b,a) for b in (T,S))]
        L=tuple(rng.sample(cand,min(len(cand),rng.randrange(0,8))))
        n,_=audit(T,S,L,K,primal=True); checked+=n; cases+=1
    print(f'After random/comparable/nonminimal systems: {cases} systems, {checked} erasures.')
    for t in range(2,10):
        T,S,L,K=sharp(t)
        for J in subsets(L):
            c=len(closure(J,T&S)); q=sum(outside(d,T,S) for d in closure(J,K))
            assert c==2**len(J) and q==c-int(len(J)==t)
        N,fT,fS=direct_gap(T,S,L,K)
        assert (N,fT,fS)==(2**(t+1)+1,2**t,2**t)
    print('Sharp obstruction size and sharp near-half approximation: t=2,...,9.')
    for m in range(6,13):
        T,S,L,K=robust_example(m); t=(T&S).bit_count()
        for J in subsets(L):
            c=len(closure(J,T&S)); q=sum(outside(d,T,S) for d in closure(J,K))
            assert q>=c
        N,fT,fS=direct_gap(T,S,L,K)
        assert (N,fT,fS)==(2**m+m+t+3,2**m,2**m)
        H=(T,S)+L
        assert min((a&b).bit_count() for a,b in combinations(H,2))==m-1
        generators=[sum(1<<j for j,h in enumerate(H) if not h>>i&1) for i in range(K.bit_length())]
        assert len(generators)==len(set(generators)) and min(g.bit_count() for g in generators)>=3
        for g in generators:
            proper=[h for h in generators if h!=g and subset(h,g)]
            union=0
            for h in proper: union|=h
            assert union!=g
    print('New unbounded pair-incidence examples: m=6,...,12; all erasures, exact counts, indispensable generators.')
    sat_cases=0; sat_yes=0
    for n in (2,3,4):
        lits=tuple(range(1,n+1))+tuple(range(-n,0))
        tests=[(), ((1,),(-1,)), ((1,),), ((1,-1),)]
        tests += [tuple(tuple(rng.sample(lits,rng.randrange(1,min(3,len(lits))+1)))
                        for _ in range(rng.randrange(1,13))) for _ in range(40)]
        for clauses in tests:
            T,S,L,K=sat_instance(n,clauses)
            truth=sat_truth(n,clauses)
            bad=any(len(closure(J,T&S))>sum(outside(d,T,S) for d in closure(J,K)) for J in subsets(L))
            assert truth==bad
            sat_cases+=1; sat_yes+=truth
    print(f'SAT reduction: {sat_cases} instances ({sat_yes} satisfiable, {sat_cases-sat_yes} unsatisfiable).')
    print('PASS. Finite audits supplement, not replace, the general proofs.')

if __name__=='__main__': main()
