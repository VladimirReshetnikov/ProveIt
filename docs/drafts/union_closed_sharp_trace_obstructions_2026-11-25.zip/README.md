# Sharp trace obstructions for union-closed families

Start with `paper.pdf`. This note proves a sharp all-overlap theorem resolving the obstruction-size question in the supplied five-type draft, plus weighted and approximate consequences, infinite examples, and a complexity theorem.

- `paper.tex`: full LaTeX source and proofs.
- `paper.pdf`: compiled manuscript.
- `verify.py`: standard-library Python exact finite audit.
- `verification.txt`: actual verifier output.
- `provenance.md`: antecedents, scope and limitations.
- `SHA256SUMS`: integrity checks.

Reproduce:

```sh
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
python3 verify.py
sha256sum -c SHA256SUMS
```

The theorem is a partial structural result, not a resolution of the general conjecture. The sharp lower construction is from the predecessor. Historical priority of the new upper bound and extensions remains unconfirmed. No proof depends on the finite audit.
