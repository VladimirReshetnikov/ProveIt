# Source review and status

25 November 2026. The GitHub connector read the `main` branch of the user-provided repository directory:
https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

30 ZIP archives were listed. Ten targeted archives were retrieved via the GitHub connector using base64 file retrieval and in-memory ZIP/DEFLATE extraction. Source abstracts, section inventories, and relevant README passages were screened. The primary antecedent was then retrieved again and its main mathematical development read in detail. No repository modification was made.

Primary antecedents:

- `union_closed_five_type_obstructions_2026-11-25.zip`, blob `031a30363602a04b7a35a4e3194f484a2f076a9c`: distinct-union correspondence, gap identity, general trace compression via meet-irreducibles, exact overlap-three result, sharp lower construction for arbitrary overlap, higher-order criterion. Explicitly leaves the overlap-four optimum between four and seven. Our one-trace argument answers that question and all larger overlaps. The lower-bound example is credited, not claimed new.
- `union_closed_dense_core_2026-11-25.zip`, blob `b1c269b2ae1cdb03f91797a2bf840e96730c5934`: abstract, theorem headings, and README; original marked-pair gap model and small-overlap antecedents.

Other archives targeted in the thematic screen: `union_closed_antichain_shadows_2026-11-25.zip`, `union_closed_rank_transport_2026-11-25.zip`, `union_closed_signature_interfaces_2026-11-25.zip`, `union_closed_redundant_core_2026-11-25.zip`, `union_closed_lopsided_certificates_2026-11-25.zip`, `union_closed_cycle_certificates.zip`, `union_closed_defective_substitution.zip`, and `union_closed_joint_laws_2026-11-25.zip`. This was not a line-by-line review, and output for some of the screen was truncated. The other listed archives were not reviewed. Repository-wide novelty is therefore not certified.

Public comparison: Wikipedia, https://en.wikipedia.org/wiki/Union-closed_sets_conjecture; Costa and Sadhu, https://doi.org/10.5281/zenodo.22727713; Pulaj, https://doi.org/10.1090/mcom/3461; web searches for robust pairs, translations, trace obstructions, and Frankl-complete recognition. A separate current web report claimed a 0.383175... universal bound (Quantavane); it was not independently audited, and this note makes no claim about the latest universal record. The theorem does not depend on any universal entropy bound.

Proof status: ordinary mathematical proofs, supported by exact integer computations. No proof-assistant check. Novelty is relative to the inspected predecessor, not an established publication-priority claim. No full proof of Frankl's conjecture or universal constant improvement is claimed.
