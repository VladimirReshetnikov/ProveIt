#!/usr/bin/env python3
"""Package the complete deliverable, excluding reproducible scratch files."""
from pathlib import Path
import hashlib
import json
import zipfile


ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "SHA256SUMS.txt"
ARCHIVE = ROOT.with_suffix(".zip")
EXCLUDED_SUFFIXES = {".aux", ".out", ".toc", ".pyc"}


def include(path):
    relative = path.relative_to(ROOT)
    return (
        path.is_file()
        and path != MANIFEST
        and "__pycache__" not in relative.parts
        and not any(part.startswith(".") for part in relative.parts)
        and path.suffix not in EXCLUDED_SUFFIXES
        and not (path.parent == ROOT and path.suffix == ".log")
    )


files = sorted(path for path in ROOT.rglob("*") if include(path))
MANIFEST.write_text(
    "".join(
        f"{hashlib.sha256(path.read_bytes()).hexdigest()}  "
        f"{path.relative_to(ROOT).as_posix()}\n"
        for path in files
    ),
    encoding="utf-8",
)
files.append(MANIFEST)
with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9) as output:
    for path in sorted(files):
        item = zipfile.ZipInfo(
            f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}",
            date_time=(2026, 11, 7, 12, 0, 0),
        )
        item.compress_type = zipfile.ZIP_DEFLATED
        item.external_attr = 0o100644 << 16
        output.writestr(item, path.read_bytes())

with zipfile.ZipFile(ARCHIVE) as check:
    assert check.testzip() is None
    for line in check.read(f"{ROOT.name}/SHA256SUMS.txt").decode().splitlines():
        expected, name = line.split("  ", 1)
        assert hashlib.sha256(check.read(f"{ROOT.name}/{name}")).hexdigest() == expected
    for required in ("report.tex", "checker.py", "ipra_reduction_2026-11-07.pdf"):
        assert f"{ROOT.name}/{required}" in check.namelist()

print(json.dumps({
    "archive": str(ARCHIVE),
    "files": len(files),
    "bytes": ARCHIVE.stat().st_size,
    "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
    "archive_integrity": "PASS",
    "all_manifest_hashes": "PASS",
}, indent=2))
