"""Portable whole-program measurement against byte-for-byte frozen sources.

Run from any working directory: python3 /path/to/comparison/measure.py
The inherited normalizer is unmodified and its SHA-256 is checked first.
"""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
MANIFEST = json.loads((HERE / 'manifest.json').read_text())
NORMALIZER = ROOT / MANIFEST['normalizer']['file']
if hashlib.sha256(NORMALIZER.read_bytes()).hexdigest() != MANIFEST['normalizer']['sha256']:
    raise ValueError('Inherited normalizer was modified')
spec = importlib.util.spec_from_file_location('inherited_source_measure', NORMALIZER)
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
DRIVER = '''try:
    take = json.load(open(sys.argv[1])).pop
    if not check(take(), []):
        raise ValueError
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''
ORIGINAL_DRIVER = '''try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
'''


def checked_metrics(record):
    result = measure.metrics(ROOT / record['file'])
    if result['sha256'] != record['sha256']:
        raise ValueError('Source digest mismatch: ' + record['file'])
    return result


def prefix(path):
    body = []
    for node in measure.StripDocstrings().visit(ast.parse(path.read_text())).body:
        if isinstance(node, (ast.Try, ast.If)):
            break
        if not isinstance(node, (ast.Import, ast.ImportFrom)):
            body.append(node)
    return body


def controlled(path, driver=DRIVER):
    body = ast.parse('import json, sys').body + prefix(path) + ast.parse(driver).body
    text = ast.unparse(ast.fix_missing_locations(ast.Module(body=body, type_ignores=[]))) + '\n'
    with tempfile.TemporaryDirectory() as tmp:
        target = Path(tmp) / 'control.py'
        target.write_text(text)
        return measure.metrics(target)


def minimum(rows):
    return {field: min(r[field] for r in rows) for field in FIELDS}


def main():
    (ROOT / 'results').mkdir(exist_ok=True)
    rows = [{**record, 'whole': checked_metrics(record),
             'common_driver': controlled(ROOT / record['file'])}
            for record in MANIFEST['current_roots']]
    primary = MANIFEST['primary']
    candidate = {**primary, 'whole': checked_metrics(primary),
                 'common_driver': controlled(ROOT / primary['file']),
                 'original_driver': controlled(ROOT / primary['file'], ORIGINAL_DRIVER)}
    ablations = [{**record, 'whole': checked_metrics(record)} for record in MANIFEST['ablations']]
    history = {record['sha256']: checked_metrics(record) for record in MANIFEST['historical_sources']}
    historical_reports = []
    for selection in MANIFEST['historical_selection']:
        historical_reports.append({k: v for k, v in selection.items() if k != 'sha256s'} |
                                  {'coordinatewise_minimum': minimum([history[key] for key in selection['sha256s']])})
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'repository': MANIFEST['repository'], 'repository_commit': MANIFEST['repository_commit'],
              'normalizer': MANIFEST['normalizer'], 'current_root_count': len(rows),
              'current_whole_minimum': minimum([r['whole'] for r in rows]),
              'current_common_driver_minimum': minimum([r['common_driver'] for r in rows]),
              'historical_selected_manifests': historical_reports,
              'historical_deduplicated_count': len(history),
              'historical_deduplicated_minimum': minimum(list(history.values())),
              'current_roots': rows, 'candidates': [candidate], 'ablations': ablations,
              'boundary': 'Complete runnable source, including JSON input, main check, output and rejection status. Common-driver control changes only imports and CLI. Not an invariant measure of axiomatic complexity.'}
    (ROOT / 'results/measurement.json').write_text(json.dumps(result, indent=2) + '\n')
    summary = {key: result[key] for key in ('python', 'repository_commit', 'current_root_count',
        'current_whole_minimum', 'current_common_driver_minimum',
        'historical_deduplicated_count', 'historical_deduplicated_minimum')}
    summary['primary'] = {key: candidate['whole'][key] for key in (*FIELDS, 'sha256')}
    summary['primary_original_driver'] = {key: candidate['original_driver'][key] for key in FIELDS}
    summary['ablations'] = [{key: r[key] for key in ('file',)} | {key: r['whole'][key] for key in FIELDS} for r in ablations]
    (ROOT / 'results/measurement_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
