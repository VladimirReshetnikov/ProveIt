Reproducing the measurements
===========================
Run: python3 comparison/measure.py
The script resolves every path relative to its own file and can run from any
working directory. Results are saved to results/measurement.json and the short
results/measurement_summary.json. It prints only the summary.

The full runnable root checker.py is the candidate. production/checker.py is a
byte-identical retained copy. No support module is imported by either program.
Every comparison source and the unchanged inherited normalizer are SHA-256
checked against comparison/manifest.json before measurement.

Current comparison set: the ten checker*.py files directly in the roots of all
six archives at repository commit 25e16049bbc73c92703296181e0696370c987577.
Frozen current files are in comparison/current/. All source identities are in
the manifest, including archive and member names. The whole-program minimum
is 375 normalized tokens, 403 AST nodes, 1117 normalized UTF-8 bytes on CPython
3.12.14. Candidate: 372, 396, 1103. Normalization removes docstrings, then uses
ast.unparse. Formatting/comments are not credited as improvements.

Common-driver control: retain the complete definition/initialization prefix
of each current root, including all nested helpers, and replace imports and
CLI with the same exact driver. Its minimum is 374, 400, 1109; candidate remains
372, 396, 1103. The candidate with the original scope-complement driver is
373, 399, 1111. Therefore the improvement is not confined to a driver change.
No claim relies on the legacy normalizer's heuristic 'core' field.

Historical sensitivity set: the union of the staged-opening broad_sources
selection and context-freshness expanded programs selection. Their 127 and 129
entries have 129 unique source digests. Those exact source bytes are included
in comparison/historical/. Minimum 389, 413, 1159. The manifest includes selected
source identities and original manifest digests. This is a stated historical
corpus, not an absolute or language-independent lower bound.

Ablations, all runnable, are in comparison/ablations/:
- raw_only: change only the singleton-wrapped witness interface to raw witness;
- original_driver: primary inference code with the older complete CLI;
- modulo: primary with its earlier logically equivalent modulo/conjunction guard;
- full: direct primitive recursion companion, a size comparison only. Its
  379 tokens do not beat the 375-token current envelope. The portable independent
  regression suite targets the scalar primary, not this full-recursion file.

Attribution: inherited normalizer and comparator sources originate from the
ProveIt drafts linked by the user. Their MIT No Attribution license is retained
as comparison/LICENSE_SOURCE.txt. The provenance manifest gives exact files.
