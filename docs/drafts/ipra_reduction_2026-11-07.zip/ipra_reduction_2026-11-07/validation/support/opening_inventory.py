"""Opening inventory extracted from the inherited raw-witness audit.
The test function is unchanged apart from AST-unparse formatting. It calls
our independently implemented named-binder opening, not production inst.
"""
from collections import Counter
from copy import deepcopy
from named_oracle import opening

def opening_audit(module):
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 999, True, False, 0.0, None, {}]
    terms = [*atoms, [], [0], [1], [999], [0, 0], [0, 0, 1], [0, 0, 3], [0, 0, 999], [1, 0, [0, 3, 5]], [0, 0, [0, 1, 5]], [0, 0, [0, 1, 999]]]
    formulas = [[t, 0] for t in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5, 999)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 999)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]], [[[5, 1]], [[3, 4]], [[1, 2]]], [[[[0, 0, 999], 5]], [0, 0], [0, 0]]]
    images = [None, 0, -1, -3, 1, 2, [0], [0, 0, 1], [0, 0, 3], True, {}]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2, 3):
                for lower in (0, -2):
                    for image in images:
                        module.k = lower
                        try:
                            actual = module.inst(deepcopy(value), deepcopy(image), d=2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = (None, False)
                        try:
                            expected = opening(deepcopy(value), deepcopy(image), formula=formula, depth=depth, lower=lower)
                            valid_expected = True
                        except Exception:
                            expected, valid_expected = (None, False)
                        assert valid == valid_expected and (not valid or actual == expected), ('opening', value, image, formula, depth, lower, actual, expected)
                        counts['valid' if valid else 'invalid'] += 1
    return dict(counts)
