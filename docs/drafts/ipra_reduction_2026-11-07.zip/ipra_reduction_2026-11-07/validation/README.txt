Reproducing the implementation audit
===================================
Run: python3 validation/verify.py
The command works from any working directory. It prints a summary and saves
results/verification.json, results/verification_summary.json and the converted
raw packets in results/fixtures_raw.json. Source, fixture, oracle and control
hashes are checked before running the audit.

Scope: 280 fixed certificates, 800 seeded packet mutations, 6776 explicit named-
binder opening checks, 130 positive translations from the wrapped-witness
source format, and 572 subprocess calls exercising the exact public checker
both normally and under Python -O. There are seven deliberate faulty-kernel
controls: capture, unchecked goal, compound induction, missing retained base,
undeclared-name retention, implicit zero image, and Boolean-as-integer syntax.

The fixed cohort is 207 shared inherited fixtures, 19 scope-specific fixtures,
53 raw staged-opening scalar fixtures, and one independently supplied failed-
major negative-hole fallback regression. The latter resolves a real format
translation edge case: arbitrary-packet conversion to positive-hole notation
must rewrite reached motives even inside failed attempted proofs. No such
universal trace-preserving converter is claimed here.

All accepted source fixtures are converted by replaying the actual source
instruction consumption. Their closed goal and allocated-name count are
preserved. Conversions of rejected source packets are only test inputs; we do
not claim rejection is preserved by changing certificate formats.

The named-binder syntax and raw-rule interpreter are independent of the packed
production opening table. They are inherited from the cited drafts, with one
import adaptation to combine scope-complement syntax with raw instructions.
The support provenance and retained license are validation/provenance.json
and validation/LICENSE_SOURCE.txt. The opening inventory function is extracted
unchanged at AST level from the inherited raw-witness audit.

The public checker imports none of this support. The finite evidence does not
constitute a machine-checked proof of soundness, equiconsistency or the two
interpretation composites. Those are mathematical report obligations.
