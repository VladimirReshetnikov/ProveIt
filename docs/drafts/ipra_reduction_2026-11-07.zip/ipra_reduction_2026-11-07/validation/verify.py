"""Finite independent implementation audit; no claim of a metatheory proof.

The production checker imports no support file. The named-binder oracle comes
from the scope-complement archive; the raw-rule interpreter comes from the
smaller-kernel archive with only its imported syntax provider changed. Opening
checks, translated positive certificates, malformed JSON, explicit mutation
controls and the unmodified public CLI are exercised independently.
"""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile
import types

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE / 'support'))
from named_oracle import opening
from raw_oracle import RawOracle
from mutation_support import mutate
from opening_inventory import opening_audit


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def kernel(path, replacement=None):
    source = path.read_text()
    if replacement:
        old, new = replacement
        require(source.count(old) == 1, ('nonunique replacement', old))
        source = source.replace(old, new)
    body = []
    for node in ast.parse(source).body:
        if isinstance(node, (ast.Try, ast.If)):
            break
        body.append(node)
    module = types.ModuleType(path.stem)
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), module.__dict__)
    return module


def run(module, packet, trace=False):
    module.k = 0
    stack = deepcopy(packet)
    used = []
    def take():
        value = stack.pop()
        used.append((len(stack), deepcopy(value)))
        return value
    try:
        module.take = take
        accepted = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return dict(accepted=accepted, final_k=module.k,
                remaining=len(stack) if type(stack) is list else None,
                error=error, used=used if trace else None)


def unwrap(cell):
    if type(cell) is list and len(cell) == 1:
        witness = cell[0]
        if type(witness) is int or type(witness) is list and len(witness) in (1, 3):
            return witness
        # A source-accepted malformed witness can only be unused. Use zero.
        return 0
    return cell


def digest(packet):
    return sha256(json.dumps(packet, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def main():
    (ROOT / 'results').mkdir(exist_ok=True)
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    provenance = json.loads((HERE / 'provenance.json').read_text())
    records = [manifest['primary'], manifest['byte_identical_primary_copy'], *manifest['current_roots'], *manifest['ablations'],
               *provenance['fixtures'], *provenance['support']]
    for record in records:
        path = ROOT / record['file']
        require(sha256(path.read_bytes()).hexdigest() == record['sha256'],
                ('input digest changed', record['file']))
    candidate_path = ROOT / 'checker.py'
    candidate = kernel(candidate_path)
    modulo = kernel(ROOT / 'comparison/ablations/checker_modulo.py')
    source = kernel(ROOT / 'comparison/current/scope_complement_checker.py')
    inherited = json.loads((HERE / 'fixtures/source_inherited.json').read_text())
    inherited += json.loads((HERE / 'fixtures/source_new.json').read_text())
    for row in inherited:
        if row['name'] == 'new/used_future_motive_parameter':
            row['expected'] = True
    wrapped = inherited + json.loads((HERE / 'fixtures/source_scope.json').read_text())
    rows = []
    source_counts = Counter()
    for row in wrapped:
        outcome = run(source, row['packet'], trace=True)
        require(outcome['accepted'] == row['expected'], ('source drift', row['name']))
        if outcome['accepted']:
            converted = [unwrap(cell) for _, cell in reversed(outcome['used'])] + [deepcopy(row['packet'][-1])]
            actual = run(candidate, converted)
            require(actual['accepted'], ('positive source translation', row['name'], actual))
            require(actual['final_k'] == outcome['final_k'], ('translation changed eigenparameter count', row['name']))
            require(converted[-1] == row['packet'][-1], 'translation changed goal')
            source_counts['accepted_translated'] += 1
        else:
            # This is only a test-format conversion, not a theorem about rejection.
            converted = ([unwrap(cell) for cell in row['packet'][:-1]] + [row['packet'][-1]]
                         if type(row['packet']) is list and row['packet'] else row['packet'])
            source_counts['rejected_examined'] += 1
        rows.append({'name': row['name'], 'packet': converted, 'source_accepted': outcome['accepted']})

    staged = json.loads((HERE / 'fixtures/staged_scalar.json').read_text())
    rows += [{'name': 'staged/' + r['name'], 'packet': r['packet'], 'declared_expected': r['expected']} for r in staged]
    independent_case = json.loads((HERE / 'fixtures/fallthrough_scope_case.json').read_text())
    rows.append({'name': 'independent/failed_major_negative_hole_fallback',
                 'packet': independent_case['new_packet'], 'declared_expected': True})

    rules = Counter()
    totals = Counter()
    detail = []
    def audit(packet, label, category):
        actual = run(candidate, packet)
        prior = run(modulo, packet)
        oracle = RawOracle().run(packet)
        require(actual['accepted'] == oracle['accepted'], ('independent oracle', label, actual, oracle))
        require(actual['accepted'] == prior['accepted'], ('bit test changed verdict', label, actual, prior))
        if actual['accepted']:
            for field in ('final_k', 'remaining'):
                require(actual[field] == oracle[field] == prior[field], ('successful trace', label, field))
            rules.update(oracle['rules'])
        totals[category + '_cases'] += 1
        totals[category + ('_accepts' if actual['accepted'] else '_rejects')] += 1
        detail.append({'name': label, 'category': category, 'sha256': digest(packet), 'result': actual})
        return actual['accepted']
    for row in rows:
        expected = audit(row['packet'], row['name'], 'fixed')
        if 'declared_expected' in row:
            require(expected == row['declared_expected'], ('staged expected outcome', row['name']))
        row['expected'] = expected

    openings = opening_audit(candidate)

    rng = random.Random(2026110809)
    for i in range(800):
        row = rows[i % len(rows)]
        audit(mutate(row['packet'], rng), f'mutation/{i:04}/{row["name"]}', 'mutation')

    by_name = {r['name']: r for r in rows}
    controls = [
        ('capture', 'inst(t, d=1)', 'inst(t, d=d)', 'new/true_capture_attack', True),
        ('unvalidated_goal', 'if inst(a) in g:', 'if a in g:', 'new/future_eigenparameter_escape', True),
        ('compound_induction', 'h = [a, inst(a, 0)][len(a) % 2:]', 'h = [a, inst(a, 0)]', 'original/compound_induction_hypothesis', True),
        ('missing_retained_base', 'h = [a, inst(a, 0)][len(a) % 2:]', 'h = [a] if len(a) == 2 else [inst(a, 0)]', 'original/retained_base_separation', False),
        ('undeclared_name_rigid', 'k <= a < d', 'a < d', 'new/invalid_unused_update_-999', True),
        ('implicit_zero_image', 'def inst(a, t=None, d=0):', 'def inst(a, t=0, d=0):', 'new/global_initializer_hole', True),
        ('bool_as_integer', '(type(a) is int) & d', 'isinstance(a, int) & d', 'new/invalid_unused_update_True', True),
    ]
    control_results = []
    for name, old, new, case, mutant_expected in controls:
        row = by_name[case]
        outcome = run(kernel(candidate_path, (old, new)), row['packet'])['accepted']
        require(outcome == mutant_expected and outcome != row['expected'], ('mutation was not detected', name, outcome))
        control_results.append({'name': name, 'case': case, 'correct': row['expected'], 'mutant': outcome})

    # Every fixed case is checked through the exact standalone program both
    # normally and under -O. This detects assert-dependent public acceptance.
    cli_calls = 0
    with tempfile.TemporaryDirectory(prefix='ipra_combined_') as tmp:
        path = Path(tmp) / 'packet.json'
        for row in rows:
            path.write_text(json.dumps(row['packet']) + '\n')
            for optimized in (False, True):
                result = subprocess.run([sys.executable, *(['-O'] if optimized else []), str(candidate_path), str(path)], capture_output=True, text=True, timeout=15)
                expected = (0, 'ACCEPT\n', '') if row['expected'] else (1, 'REJECT\n', '')
                require((result.returncode, result.stdout, result.stderr) == expected, ('public driver', row['name'], result))
                cli_calls += 1
        for text in ('', '[', 'not-json', '[0,]', '"x"', '{"x": 0}'):
            path.write_text(text)
            for optimized in (False, True):
                result = subprocess.run([sys.executable, *(['-O'] if optimized else []), str(candidate_path), str(path)], capture_output=True, text=True, timeout=15)
                require((result.returncode, result.stdout, result.stderr) == (1, 'REJECT\n', ''), ('malformed driver', text))
                cli_calls += 1
    summary = {'status': 'PASS', 'python': platform.python_version(), 'checker_sha256': sha256(candidate_path.read_bytes()).hexdigest(),
               'shared_inherited_cases': len(inherited), 'scope_specific_cases': len(wrapped) - len(inherited),
               'raw_staged_cases': len(staged), 'source_translations': dict(source_counts),
               'named_opening_cases': openings, 'certificate_counts': dict(totals),
               'cli_calls_normal_and_optimized': cli_calls, 'successful_rule_executions': dict(rules),
               'deliberate_controls': control_results,
               'evidence_limit': 'Finite independent implementation checks and positive fixture translations. No machine-checked universal metatheory.'}
    (ROOT / 'results/verification.json').write_text(json.dumps({'summary': summary, 'cases': detail}, indent=2) + '\n')
    (ROOT / 'results/fixtures_raw.json').write_text(json.dumps(rows, indent=2) + '\n')
    (ROOT / 'results/verification_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
