"""Record the two untrusted experimental source sizes with the frozen metric."""
import hashlib
import importlib.util
import json
from pathlib import Path
import platform


def main():
    root = Path(__file__).resolve().parent
    normalizer = root.parent / 'comparison' / 'source_measure.py'
    spec = importlib.util.spec_from_file_location('experiment_source_metric', normalizer)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    rows = []
    for name in ('checker_donly.py', 'checker_clauses.py'):
        rows.append({'file': name, 'status': 'untrusted research experiment',
                     **metric.metrics(root / name)})
    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'normalizer': '../comparison/source_measure.py',
        'normalizer_sha256': hashlib.sha256(normalizer.read_bytes()).hexdigest(),
        'programs': rows,
    }
    rendered = json.dumps(result, indent=2) + '\n'
    (root / 'measurements.json').write_text(rendered)
    print(rendered, end='')


if __name__ == '__main__':
    main()
