UNTRUSTED RESEARCH EXPERIMENTS
============================

These files preserve rejected size experiments; neither is imported by the
delivered checker or used as its acceptance boundary. Only ../checker.py is
the delivered acceptance program: these prototypes use different packet
formats and are not certified replacements for it.

checker_donly.py
  Corrected direct equality-plus-paired-binder experiment. It represents a
  closure by a paired binder with an unused outer variable. Its ordinary
  formula contexts need both witness opening and vacuous-binder application.
  The principal-sort check in h=[m[:1]] is intentional and must not be dropped.
  This corrected version received a written rule audit and seven focused
  packet checks; it did not receive the production checker's full validation.
  Recorded normalized counts: 384 tokens, 414 AST nodes, 1123 bytes.

checker_clauses.py
  Uniform clause-context experiment. An ordinary fact is [H]; a closure
  license is [H,P]. A selected clause is specialized and its premise tail
  is checked. This standalone program was measured as an experiment; a
  universal soundness/completeness proof and full validation are not claimed.
  Recorded normalized counts: 410 tokens, 446 AST nodes, 1182 bytes.

The unsafe preliminary D-only consolidation and the assertion-based clause
variant are deliberately excluded. No historical priority is claimed for
the one-binder or closure-license ideas, which already occur in the drafts.

REPRODUCE THE MEASUREMENTS

  python3 experiments/measure.py

Run this from the package root, or invoke the script by its absolute path.
It uses the same frozen ../comparison/source_measure.py normalizer as the
main comparison, records Python and normalizer identities, and writes
measurements.json beside the prototypes. The results concern complete
standalone source files, not a proof that their alternative calculi are
minimal or that their programs correctly implement every intended rule.
