"""Compile the paper and refresh its reported values from recorded results."""
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
JOB = "ipra_reduction_2026-11-07"


def main():
    RESULTS.mkdir(exist_ok=True)
    measurements = json.loads((RESULTS / "measurement.json").read_text())
    verification = json.loads((RESULTS / "verification.json").read_text())["summary"]
    candidate = next(r for r in measurements["candidates"] if Path(r["file"]).name == "checker.py")["whole"]
    baseline = measurements["current_whole_minimum"]
    counts = verification["certificate_counts"]
    values = {
        "BaseTokens": baseline["normalized_tokens"],
        "BaseAST": baseline["ast_nodes"],
        "BaseBytes": baseline["normalized_bytes"],
        "NewTokens": candidate["normalized_tokens"],
        "NewAST": candidate["ast_nodes"],
        "NewBytes": candidate["normalized_bytes"],
        "OpeningCases": sum(verification["named_opening_cases"].values()),
        "FixedCases": counts["fixed_cases"],
        "FixedAccepts": counts["fixed_accepts"],
        "FixedRejects": counts["fixed_rejects"],
        "MutationCases": counts["mutation_cases"],
        "CLICalls": verification["cli_calls_normal_and_optimized"],
    }
    (RESULTS / "numbers.tex").write_text("\n".join(
        "\\newcommand{\\" + name + "}{" + str(value) + "}"
        for name, value in values.items()) + "\n")
    latex = shutil.which("pdflatex")
    if not latex:
        raise SystemExit("pdflatex is required to rebuild the PDF")
    command = [latex, "-interaction=nonstopmode", "-halt-on-error", "-file-line-error",
               "-jobname=" + JOB, "report.tex"]
    for index in range(1, 4):
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        (RESULTS / f"latex_pass_{index}.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            raise SystemExit(f"LaTeX failed; inspect results/latex_pass_{index}.txt")
    log = (ROOT / f"{JOB}.log").read_text(errors="replace")
    findings = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line or "multiply defined" in line]
    output = {"pdf": JOB + ".pdf", "passes": 3, "reported_values": values,
              "layout_or_reference_findings": findings,
              "visual_inspection_is_separate": True}
    (RESULTS / "build.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
