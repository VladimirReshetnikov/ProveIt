A SMALLER CHECKED PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific time)

RESULT AND LIMIT

The complete exact-integer checker measures 372 normalized Python tokens,
396 executable AST nodes, and 1,103 normalized UTF-8 bytes. The ten current
root programs in the six pinned ProveIt archives have separate minima
375 / 403 / 1,117. A common-driver control has minima 374 / 400 / 1,109,
so the reduction survives that control. Measurements used CPython 3.12.14.

This is a modest implementation-relative improvement. No new arithmetic
basis, absolute shortestness theorem, or mathematical breakthrough is
established. The five-rule scalar calculus, its logical reconstruction,
and both ordinary whole-domain interpretations are inherited and credited.
The complete development is included in the paper, together with the new
implementation argument and an honest audit of unsuccessful alternatives.

CONTENTS

  report.tex and sections/     Complete LaTeX source of the paper
  ipra_reduction_2026-11-07.pdf Compiled paper
  checker.py                  Entire trusted project-specific checker
  examples/                   Small public proof packets
  comparison/                 Unchanged normalizer, frozen sources, metrics
  validation/                 Independent oracle, fixtures, and validation
  results/                    Recorded measurements and verification evidence
  source_snapshot.json        Six archive paths, sizes, hashes, pinned commit
  LICENSE-inherited.txt       Source documentation and software permission
  ATTRIBUTION.txt              Provenance and claim boundaries
  build.py                    Rebuild the PDF and its reported-value macros
  package.py                  Rebuild the ZIP and verify its file hashes
  SHA256SUMS.txt               Deliverable file hashes

SOURCE SNAPSHOT

Repository: VladimirReshetnikov/ProveIt
Commit: 25e16049bbc73c92703296181e0696370c987577
Directory: docs/drafts
The six downloaded ZIP files were checked against their Git blob hashes.
No repository change or publication was made for this deliverable.

TRUST BOUNDARY

Only checker.py and Python's standard json/sys modules are needed to check
a certificate. The checker imports no oracle, proof generator, translation
script, comparison source, or other project file. It uses no assertions,
eval, dynamic proof-code loading, or universal arithmetic evaluator.

The idealized checker is sound and complete for canonical proofs of closed
native sentences. Resource limits can reject sufficiently large proofs.
The theorem concerns the accepted closed-theorem relation, not identical
raw-packet behavior with every earlier format. Unused annotations and
unread prefix cells have no mathematical force.

REPRODUCTION

From the extracted package directory:

  python3 comparison/measure.py
  python3 validation/verify.py
  python3 build.py

The first two commands need no network and no third-party Python packages.
For exact measurement reproduction use CPython 3.12.14; ast.unparse output
may change with Python versions. The PDF build needs pdflatex and the common
packages listed in report.tex. It runs three passes and records logs.

To check a packet:

  python3 checker.py examples/reflexivity.json

An accepted packet prints ACCEPT and exits 0. A rejected packet prints
REJECT and exits nonzero. The public program behaves the same under -O.

VALIDATION IS NOT A FORMALIZATION

The written proofs establish the mathematical derivations and both
interpretation composites. The independent executable checks validate
finite examples and implementation boundaries. The package is not a
Lean or Rocq formalization of the full metatheory or the Python runtime.

Only complete-program metrics and explicit common-driver controls support
the comparison claims. Any legacy field named core in the unchanged
inherited normalizer is not used as a separately proved minimal kernel
boundary. No compressed source, renamed-identifier scoring trick, or
unaccounted project library is used by the production checker.
