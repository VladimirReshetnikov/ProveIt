#!/usr/bin/env python3
"""Rebuild the report and local audit, without network access."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-checks", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    verification = root / "verification"
    verification.mkdir(exist_ok=True)
    if not args.skip_checks:
        subprocess.run(
            [sys.executable, "code/checks.py", "--output", "verification/results.json"],
            cwd=root, check=True,
        )
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("pdflatex is required to compile report.tex")
    logs = []
    for pass_no in (1, 2, 3):
        run = subprocess.run(
            [engine, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=root, capture_output=True, text=True,
        )
        log = verification / f"latex_pass_{pass_no}.txt"
        log.write_text(run.stdout + run.stderr, encoding="utf-8")
        logs.append(log.name)
        if run.returncode:
            print((run.stdout + run.stderr)[-6000:])
            raise SystemExit(run.returncode)
    log_text = (root / "report.log").read_text(errors="replace")
    issues = [line for line in log_text.splitlines()
              if "Overfull" in line or "undefined" in line or "multiply defined" in line]
    metadata = {
        "engine": subprocess.check_output([engine, "--version"], text=True).splitlines()[0],
        "passes": 3,
        "pdf": "report.pdf",
        "compile_success": True,
        "layout_or_reference_warnings": issues,
        "logs": logs,
        "verification_scope": "Written mathematical proofs; executable local checks only.",
    }
    (verification / "build.json").write_text(json.dumps(metadata, indent=2) + "\n")
    # The auxiliary files can be regenerated and are omitted from the deliverable.
    for suffix in (".aux", ".log", ".out", ".toc"):
        (root / ("report" + suffix)).unlink(missing_ok=True)
    hashes = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS.txt" and "__pycache__" not in path.parts:
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            hashes.append(f"{digest}  {path.relative_to(root).as_posix()}")
    (root / "SHA256SUMS.txt").write_text("\n".join(hashes) + "\n")
    print(json.dumps(metadata, indent=2))

if __name__ == "__main__":
    main()
