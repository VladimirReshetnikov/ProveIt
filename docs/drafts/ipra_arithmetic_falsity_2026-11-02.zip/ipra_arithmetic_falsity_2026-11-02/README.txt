Arithmetic falsity and split implication chains
A smaller intuitionistic presentation of primitive recursive arithmetic
Research report for Vladimir Reshetnikov - 2 November 2026

START HERE
report.pdf is the complete paper. report.tex and sections/*.tex are its
editable LaTeX sources. AXIOMS.txt is the complete plain-text specification.

RESULT
The clean positive core has one fixed arithmetic sentence, a computation
scheme, and an atomic boundary scheme. Computation derives explosion from
the equation 0=S0. The ordinary intuitionistic wrapper is conventionally
bi-interpretable with iPRA; the smaller positive presentation has explicit
arbitrary-context proof translations and both formula round trips.

Fixed record: 28 ->22 for the three-argument positive presentation.
Four-argument alternative: fixed25, boundaryF+15, endpoint2H+32,
state-free table2H+23, with its larger logical definition fully charged.
Optional bounded normalization removes further redundant boundaries.

The distinction between positive and ordinary bottom-preserving
interpretations is essential and is discussed prominently in the paper.
The positive theory's raw singleton model is not an ordinary iPRA model.
No absolute minimum over arbitrary languages or proof systems is claimed.

SOURCE AUDIT
Repository snapshot: 0593751362f559ccc52e269fe5ecac06a7d6e63c.
All five current packages improve a coordinate over the six archived
packages, so all five survive the requested historical-improvement filter.
provenance/source_manifest.json records exact source identifiers/hashes.
provenance/review_matrix.json records decisions and the surviving bounds.

VERIFICATION
code/checks.py uses only Python's standard library. It constructs actual
ASTs, checks descriptor-frozen substitution, counts all modules, checks
a decreasing rewrite example, and runs bounded scan/Kripke tests.
verification/results.json contains the recorded successful run.
These are local checks, not a mechanization of the full interpretation
theorem. The general results are written proofs.

BUILD
Requirements: Python3, pdflatex with standard LaTeX packages.
From this directory run:
  python3 build.py
For a formatting-only rebuild:
  python3 build.py --skip-checks
The script compiles three times and writes the PDF, logs, and SHA256SUMS.txt.

CONTENTS
report.tex, sections/*.tex   Complete paper source.
report.pdf                  Compiled paper.
AXIOMS.txt                  All axioms, selectors, conventions, and costs.
code/checks.py              Exact syntax and local semantic checks.
verification/               Check results and build/visual QA records.
provenance/                 Fixed source inventory and comparison decisions.
build.py                    Reproducible local build.
SHA256SUMS.txt               Checksums for the packaged files.
