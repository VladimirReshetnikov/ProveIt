#!/usr/bin/env python3
"""Independent, bounded checks for the iPRA presentation.

This is a syntax accountant and a finite semantic regression suite, not a
formal verification of the arithmetic interpretation theorem.  It uses only
Python's standard library.  The complete descriptor is charged at every
recursor application, while substitution and active-occurrence counting do
not descend into a frozen descriptor.
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    args: tuple["Node", ...] = ()
    name: str = ""
    descriptor: "Node | None" = None


def V(name):
    return Node("var", name=name)


ZERO = Node("zero")
FALSE = Node("false")


def S(t):
    return Node("succ", (t,))


def R(h, n, a):
    return Node("rec", (n, a), descriptor=h)


def Eq(s, t):
    return Node("eq", (s, t))


def Imp(a, b):
    return Node("imp", (a, b))


def And(a, b):
    return Node("and", (a, b))


def Or(a, b):
    return Node("or", (a, b))


def K3(a, b, c):
    return Node("k3", (a, b, c))


def K4(a, b, c, d):
    return Node("k4", (a, b, c, d))


def bind(kind, names, body):
    for name in reversed(names.split()):
        body = Node(kind, (body,), name=name)
    return body


def All(names, body):
    return bind("all", names, body)


def Exists(names, body):
    return bind("exists", names, body)


def size(t):
    """One per AST node, plus the entire frozen descriptor at every call."""
    return 1 + sum(map(size, t.args)) + (
        size(t.descriptor) if t.descriptor is not None else 0
    )


def active(t, name):
    return int(t.kind == "var" and t.name == name) + sum(
        active(a, name) for a in t.args
    )


def subst(t, mapping):
    """Active simultaneous term substitution; descriptor identity is retained."""
    if t.kind == "var":
        return mapping.get(t.name, t)
    assert t.kind not in {"all", "exists"}, "Substitution here is on terms only"
    return Node(t.kind, tuple(subst(a, mapping) for a in t.args), t.name,
                t.descriptor)


def show(t):
    if t.kind == "var":
        return t.name
    if t.kind == "zero":
        return "0"
    if t.kind == "false":
        return "false"
    if t.kind == "succ":
        return "S(" + show(t.args[0]) + ")"
    if t.kind == "rec":
        return "R_{" + show(t.descriptor) + "}(" + ",".join(map(show, t.args)) + ")"
    if t.kind in {"all", "exists"}:
        return t.kind + " " + t.name + ". " + show(t.args[0])
    return t.kind + "(" + ",".join(map(show, t.args)) + ")"


a, n, u, x, y, b, v, w = map(V, ("a", "n", "u", "x", "y", "b", "v", "w"))


def modules(h):
    hn = subst(h, {"v": u, "w": n})
    ordinary = (
        All("a", Eq(R(h, ZERO, a), a)),
        All("a n", Eq(R(h, S(n), a),
                        subst(h, {"v": R(h, n, a), "w": n}))),
    )
    g3 = All("a n u", K3(And(Eq(n, ZERO), Eq(u, a)),
                           Eq(R(h, n, a), u), Eq(R(h, S(n), a), hn)))
    gp = All("a n u", Imp(Eq(R(h, n, a), u),
                          And(Imp(Eq(n, ZERO), Eq(u, a)),
                              Eq(R(h, S(n), a), hn))))
    t3 = All("a n", Exists("u",
        And(Imp(Eq(n, ZERO), Eq(u, a)),
            All("x y", K3(And(Eq(x, n), Eq(y, u)),
                           Eq(R(h, x, a), y),
                           Imp(Eq(x, S(n)), Eq(y, hn)))))))
    t4 = All("a n", Exists("u",
        And(Imp(Eq(n, ZERO), Eq(u, a)),
            All("x y", K4(And(Eq(x, n), Eq(y, u)),
                           Eq(R(h, x, a), y), Eq(x, S(n)), Eq(y, hn))))))
    result = {"D": ordinary, "G_K3": g3, "G_plain": gp,
              "T_K3": t3, "T_K4": t4}
    if active(h, "v") == 0:
        h0n = subst(h, {"v": ZERO, "w": n})
        result["V_K3"] = All("a x y", K3(
            And(Eq(x, ZERO), Eq(y, a)), Eq(R(h, x, a), y),
            All("n", Imp(Eq(x, S(n)), Eq(y, h0n)))))
        result["V_K4"] = All("a x y n", K4(
            And(Eq(x, ZERO), Eq(y, a)), Eq(R(h, x, a), y),
            Eq(x, S(n)), Eq(y, h0n)))
    return result


def boundaries(e):
    return {
        "K3": All("a n", Exists("b", All("x", K3(
            Eq(S(x), b), e, Imp(Eq(x, b), Eq(b, n)))))),
        "K4": All("a n", Exists("b", All("x", K4(
            Eq(S(x), b), e, Eq(x, b), Eq(b, n))))),
    }


def descriptor_examples():
    examples = [v, w, ZERO, R(w, v, w), R(v, v, w), R(w, v, v),
                R(w, R(v, v, w), R(w, v, v)),
                R(R(w, v, w), v, S(w))]
    for base in [v, w, ZERO, R(v, v, w), R(w, v, v)]:
        for count in [1, 2, 3, 7, 15, 31, 99]:
            t = base
            for _ in range(count):
                t = S(t)
            examples.append(t)
    return examples


def syntax_checks():
    A, B, C, D = map(V, "ABCD")
    records = {
        "K3": size(K3(A, B, C)) + size(And(Imp(A, B), Imp(B, C))) + 1,
        "K4": size(K4(A, B, C, D)) + size(And(Imp(A, B), Imp(B, Imp(C, D)))) + 1,
    }
    assert records == {"K3": 12, "K4": 15}
    coverage = All("x", Exists("y", Or(Eq(x, ZERO), Eq(x, S(y)))))
    separation = Imp(Eq(ZERO, S(ZERO)), FALSE)
    assert size(coverage) == 10 and size(separation) == 6
    rows = []
    for h in descriptor_examples():
        H, k = size(h), active(h, "v")
        actual = {name: sum(map(size, f)) if isinstance(f, tuple) else size(f)
                  for name, f in modules(h).items()}
        predicted = {"D": 3 * H + 13 + k * (H + 2),
                     "G_K3": 3 * H + 21, "G_plain": 3 * H + 22,
                     "T_K3": 2 * H + 33, "T_K4": 2 * H + 32}
        if k == 0:
            predicted.update({"V_K3": 2 * H + 24, "V_K4": 2 * H + 23})
        assert actual == predicted, (show(h), actual, predicted)
        rows.append({"descriptor": show(h), "H": H, "k": k, "sizes": actual})
    equations = [Eq(x, ZERO), Eq(S(x), a), Eq(R(w, S(x), a), x)]
    equations.extend(Eq(R(h, x, a), S(x)) for h in descriptor_examples())
    boundary_rows = []
    for e in equations:
        actual = {name: size(f) for name, f in boundaries(e).items()}
        assert actual == {"K3": size(e) + 16, "K4": size(e) + 15}
        boundary_rows.append({"equation": show(e), "F": size(e), "sizes": actual})
    # Substituting an active state occurrence must not rewrite the stored one.
    frozen = R(v, v, w)
    replaced = subst(frozen, {"v": S(ZERO), "w": ZERO})
    assert replaced.descriptor is frozen.descriptor
    assert active(frozen, "v") == 1
    assert show(replaced) == "R_{v}(S(0),0)"
    return {"definition_records": records, "coverage": size(coverage),
            "separation": size(separation), "descriptor_cases": len(rows),
            "boundary_cases": len(boundary_rows), "module_results": rows,
            "boundary_results": boundary_rows, "frozen_substitution": "passed"}


def rewrite_once(t):
    """First constructor rewrite that strictly reduces full descriptor cost."""
    if t.kind == "rec":
        index, initial = t.args
        candidate = None
        if index.kind == "zero":
            candidate = initial
        elif index.kind == "succ":
            previous = index.args[0]
            candidate = subst(t.descriptor,
                              {"v": R(t.descriptor, previous, initial), "w": previous})
        if candidate is not None and size(candidate) < size(t):
            return candidate, True
    for i, child in enumerate(t.args):
        rewritten, changed = rewrite_once(child)
        if changed:
            children = t.args[:i] + (rewritten,) + t.args[i + 1:]
            out = Node(t.kind, children, t.name, t.descriptor)
            assert size(out) < size(t)
            return out, True
    return t, False


def normalize(t):
    history = [t]
    while True:
        out, changed = rewrite_once(history[-1])
        if not changed:
            return out, history
        assert size(out) < size(history[-1])
        history.append(out)
        assert len(history) <= size(t)


def eval_term(t, env):
    if t.kind == "var":
        return env[t.name]
    if t.kind == "zero":
        return 0
    if t.kind == "succ":
        return 1 + eval_term(t.args[0], env)
    if t.kind == "rec":
        steps = eval_term(t.args[0], env)
        value = eval_term(t.args[1], env)
        for counter in range(steps):
            value = eval_term(t.descriptor, {"v": value, "w": counter})
        return value
    if t.kind == "eq":
        return eval_term(t.args[0], env) == eval_term(t.args[1], env)
    raise ValueError(t.kind)


def rewrite_checks():
    original = Eq(R(w, S(x), a), x)
    reduced, history = normalize(original)
    assert reduced == Eq(x, x)
    valuations = 0
    for xv, av in itertools.product(range(12), repeat=2):
        env = {"x": xv, "a": av}
        assert eval_term(original, env) == eval_term(reduced, env)
        valuations += 1
    # The normalizer never descends into an unapplied frozen descriptor.
    reducible_descriptor = R(w, S(v), w)
    carrier = R(reducible_descriptor, x, a)
    unchanged, _ = normalize(carrier)
    assert unchanged == carrier and unchanged.descriptor is reducible_descriptor
    return {"before": show(original), "after": show(reduced),
            "sizes": [size(t) for t in history],
            "old_K3_boundary_size": size(boundaries(original)["K3"]),
            "old_K4_boundary_size": size(boundaries(original)["K4"]),
            "normalized_boundary_emitted": False,
            "natural_number_valuations": valuations,
            "frozen_descriptor_normalization": "passed"}


def nat_scan_checks(max_target=9):
    cases = 0
    induction_cases = 0
    for target in range(max_target + 1):
        # Include values beyond the endpoint to catch a misplaced guard.
        for values in itertools.product([False, True], repeat=target + 3):
            failures = [i for i in range(target + 1) if not values[i]]
            witness = failures[0] if failures else target
            for probe, e in enumerate(values):
                assert not (probe + 1 == witness) or e
                assert not e or not (probe == witness) or witness == target
            if values[0] and all(not values[i] or values[i + 1]
                                 for i in range(target)):
                assert values[target]
                induction_cases += 1
            cases += 1
    return {"targets": [0, max_target], "predicate_cases": cases,
            "induction_premise_cases": induction_cases,
            "construction": "least failure in 0..n, otherwise n",
            "result": "all K3/K4 boundary obligations passed"}


def upward_sets(reach):
    worlds = range(len(reach))
    for bits in itertools.product([False, True], repeat=len(reach)):
        if all(not bits[w0] or all(bits[w1] for w1 in reach[w0]) for w0 in worlds):
            yield frozenset(w for w in worlds if bits[w])


def force(formula, world, reach, valuation):
    if formula.kind == "var":
        return world in valuation[formula.name]
    if formula.kind == "and":
        return all(force(f, world, reach, valuation) for f in formula.args)
    if formula.kind == "or":
        return any(force(f, world, reach, valuation) for f in formula.args)
    if formula.kind == "imp":
        lhs, rhs = formula.args
        return all(not force(lhs, q, reach, valuation) or force(rhs, q, reach, valuation)
                   for q in reach[world])
    raise ValueError(formula.kind)


def kripke_checks():
    frames = [({0},), ({0, 1}, {1}), ({0, 1, 2}, {1}, {2}),
              ({0, 1, 2, 3}, {1, 3}, {2, 3}, {3})]
    p, q, bad = map(V, ("p", "q", "bad"))
    formulas = [p, q, bad]
    for op in [And, Or, Imp]:
        formulas.extend(op(s, t) for s in [p, q, bad] for t in [p, q, bad])
    formulas.extend([Imp(Imp(p, q), p), Or(p, Imp(p, bad)),
                     Imp(Imp(p, bad), bad), And(Imp(p, q), Imp(q, p))])
    checks = 0
    admissible = 0
    for reach in frames:
        ups = list(upward_sets(reach))
        for pv, qv, bv in itertools.product(ups, repeat=3):
            if not bv <= pv & qv:
                continue
            admissible += 1
            valuation = {"p": pv, "q": qv, "bad": bv}
            for world in range(len(reach)):
                for formula in formulas:
                    assert force(Imp(bad, formula), world, reach, valuation)
                    checks += 1
    reach = ({0, 1}, {1})
    valuation = {"p": {1}, "q": set(), "bad": set()}
    excluded_middle = Or(p, Imp(p, bad))
    assert not force(excluded_middle, 0, reach, valuation)
    return {"frames": len(frames), "admissible_atomic_valuations": admissible,
            "collapse_implication_checks": checks,
            "excluded_middle_countermodel": {
                "reach": [[0, 1], [1]], "p": [1], "bad": [],
                "root_forces_p_or_not_p": False},
            "scope": "finite propositional check, not an arithmetic Kripke-model construction"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "verification" / "results.json")
    args = parser.parse_args()
    result = {"status": "passed",
              "scope": "exact AST accounting and bounded semantic checks; not a formal proof of bi-interpretability",
              "syntax": syntax_checks(), "normalization": rewrite_checks(),
              "natural_number_scan": nat_scan_checks(), "kripke": kripke_checks()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(args.output),
                      "descriptor_cases": result["syntax"]["descriptor_cases"],
                      "boundary_cases": result["syntax"]["boundary_cases"],
                      "scan_cases": result["natural_number_scan"]["predicate_cases"],
                      "kripke_checks": result["kripke"]["collapse_implication_checks"]}, indent=2))


if __name__ == "__main__":
    main()
