LOCALIZING EQUALITY TRANSPORT IN iPRA
====================================
Prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific).

RESULT AND LIMIT
---------------
The requested strict improvement in complete proof-checker complexity has
NOT been established. This package is not a claim to have found the simplest
axiomatization or the requested significant breakthrough.

It supplies a fully specified alternative native presentation N_K, with a
proved identity translation to and from the strongest inspected K-only
presentation. General equality transport can be restricted to bidirectional
rewrites sourced from computation equations or atomic consequences of local
clauses. The simultaneous proof preserves arbitrary native formulas, not
only the equational fragment. By composing with the supplied internal
arithmetic and logical reconstruction, N_K is whole-domain bi-interpretable
and equiconsistent with full iPRA.

Two additional findings are proved and documented:
* Retaining the induction hypothesis for every native matrix yields a
  calculus bi-interpretable with HA in its PR definitional extension.
* A tempting three-token verifier reduction is false: a three-cell packet
  derives 0=S0 after deleting the initial validation traversal. The unchanged
  current verifier rejects that packet.

The true inspected complete-source minima are 309 normalized tokens,
344 AST nodes, and 864 normalized bytes, all attained by an existing file
in ipra_package_reconstructed.zip. No new complete checker is entered.
Byte comparisons depend on identifier spelling; the report retains the
original uniform-renaming caveat (an older source reaches 816 bytes).

START HERE
----------
report.pdf                 Complete mathematical report.
report.tex, sections/       Complete editable LaTeX source.
code/neutral_demo.py        Local neutral-rewrite compiler and replay checker.
code/audit_frontier.py      Whole-source comparison and finite counterexample.
evidence/                  Executed receipts, certificates, source identities,
                           independent written mathematical review.
reference/checkers/         Eighteen unchanged complete comparator programs.
reference/source_measure.py Unchanged inherited normalizer.
reference/native/          Inherited native decoding and logical account.
reference/ipra_shifted_equational_core_2026-11-08.zip
                           Exact mathematical reference with its full
                           arithmetic and logical dependencies.
ATTRIBUTION.txt             Contribution boundary and sources.
CLAIMS.json                 Machine-readable claim status.
SHA256SUMS                  Payload hashes.

OFFLINE REPRODUCTION
--------------------
  python3 reproduce.py
  python3 build.py
  python3 package.py

Python 3.12 reproduces the exact ast.unparse measurements. The evidence
programs otherwise use the standard library. PDF compilation requires
pdfLaTeX and standard packages listed in report.tex; shell escape is off.
package.py updates hashes and produces a deterministic ZIP in the parent.
It does not rebuild the PDF or prove mathematical claims.

EXECUTED CHECKS
---------------
* 18 complete source profiles; frontier 309/344/864.
* All 147 inherited positive certificates accepted by the unchanged record.
* 13 public protocol cases in normal and -O Python: 26 passing runs.
* Four public runs of the finite 0=S0 counterexample: original rejects,
  rejected modification accepts, in both Python modes.
* Four local neutral-rewrite demonstrations (3, 7, 0, 1 steps).
* Seven changed local certificates and one malformed original proof rejected.

EVIDENCE LIMITS
---------------
The neutral demonstration uses a free term algebra under declared equality
premises. It checks the critical transport conversion, nested binders,
capture avoidance, and alpha equivalence. It does not implement DI or DE,
prove those declared equalities as arithmetic facts, or verify all of iPRA.
It is not measured as a complete arithmetic verifier.

The main theorem is a written mathematical proof with independent review.
The large predecessor and internal PR reconstruction are inherited and
included with explicit attribution. No Lean/Rocq formalization or claim
of literature-wide novelty is included. No remote repository change was
performed.

PINNED REPOSITORY
-----------------
https://github.com/VladimirReshetnikov/ProveIt/tree/89fd4b4c5cd158259b1f2846f63e3d98f053553c/docs/drafts

Eleven current source archives were retrieved and checked against their
Git blob identities. evidence/source_snapshot.json records their exact
paths, pinned URLs, byte counts, and SHA-256 hashes.
