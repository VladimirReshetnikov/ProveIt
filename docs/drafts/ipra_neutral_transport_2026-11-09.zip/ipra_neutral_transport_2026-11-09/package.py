#!/usr/bin/env python3
"""Write payload hashes and a deterministic ZIP; does not rebuild or reprove."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parent
excluded = {'.aux', '.log', '.out', '.toc', '.pyc', '.synctex', '.fls', '.fdb_latexmk'}
files = sorted(p for p in root.rglob('*') if p.is_file()
               and '__pycache__' not in p.parts and p.suffix not in excluded
               and p.name != 'SHA256SUMS')
hashes = ''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n'
                 for p in files)
(root / 'SHA256SUMS').write_text(hashes)
files.append(root / 'SHA256SUMS')
archive = root.parent / (root.name + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files):
        info = zipfile.ZipInfo(root.name+'/'+p.relative_to(root).as_posix(), (2026,11,9,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        z.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None:
        raise SystemExit('ZIP integrity check failed')
print(archive)
print(hashlib.sha256(archive.read_bytes()).hexdigest())
