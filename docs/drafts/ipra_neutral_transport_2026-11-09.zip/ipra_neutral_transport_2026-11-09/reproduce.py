#!/usr/bin/env python3
"""Reproduce the local proof demonstration and complete-source audit offline."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for script in ('code/neutral_demo.py', 'code/audit_frontier.py'):
    subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
