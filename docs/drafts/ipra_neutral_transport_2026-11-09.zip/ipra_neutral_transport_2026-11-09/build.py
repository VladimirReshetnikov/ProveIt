#!/usr/bin/env python3
"""Build the report using pdfLaTeX without shell escape."""
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
engine = shutil.which('pdflatex')
if engine is None:
    raise SystemExit('pdflatex is required to build report.tex')
for _ in range(3):
    subprocess.run([engine, '-no-shell-escape', '-interaction=nonstopmode',
                    '-halt-on-error', 'report.tex'], cwd=root, check=True,
                   stdout=subprocess.DEVNULL)
print(root / 'report.pdf')
