#!/usr/bin/env python3
"""Local certificate demonstration of neutral equality normalization.

Scope: a free first-order term algebra with declared equality premises,
reflexivity, and equality transport. Formula motives may contain equations
and nested paired binders D. The replayer checks capture-avoiding substitution
and alpha equivalence; it does not implement the arithmetic or logical rules
of iPRA, DI, DE, or a full proof checker. No source-size record is claimed.

Run with Python 3.10+ and only the standard library. Certificates and a
verification receipt are written to the sibling evidence directory.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path


HOLE = "_hole"
SIGNATURE = {"b": 0, "c": 0, "f": 1, "g": 1, "h": 2, "j": 2}


class InvalidCertificate(ValueError):
    """A local proof or neutral-rewrite certificate is invalid."""


def require(condition, message):
    if not condition:
        raise InvalidCertificate(message)


def var(name):
    return ("var", name)


def fun(name, *arguments):
    return ("fun", name, tuple(arguments))


def equation(left, right):
    return ("eq", left, right)


def binder(first, second, body):
    return ("D", first, second, body)


def term(raw):
    """Parse and validate a term independently of the producer."""
    require(isinstance(raw, (list, tuple)) and raw, "term node")
    if raw[0] == "var":
        require(len(raw) == 2 and isinstance(raw[1], str) and raw[1], "variable")
        return var(raw[1])
    require(len(raw) == 3 and raw[0] == "fun", "function node")
    name, args = raw[1], raw[2]
    require(isinstance(name, str) and name in SIGNATURE, "function symbol")
    require(isinstance(args, (list, tuple)), "function argument list")
    require(len(args) == SIGNATURE[name], "function arity")
    return fun(name, *(term(child) for child in args))


def formula(raw):
    require(isinstance(raw, (list, tuple)) and raw, "formula node")
    if raw[0] == "eq":
        require(len(raw) == 3, "equation arity")
        return equation(term(raw[1]), term(raw[2]))
    require(len(raw) == 4 and raw[0] == "D", "paired-binder node")
    first, second = raw[1:3]
    require(isinstance(first, str) and first, "first binder")
    require(isinstance(second, str) and second, "second binder")
    require(first != second, "distinct simultaneous binders")
    require(HOLE not in (first, second), "the motive hole may not be bound")
    return binder(first, second, formula(raw[3]))


def term_variables(t):
    if t[0] == "var":
        return {t[1]}
    result = set()
    for child in t[2]:
        result.update(term_variables(child))
    return result


def free_variables(f):
    if f[0] == "eq":
        return term_variables(f[1]) | term_variables(f[2])
    return free_variables(f[3]) - {f[1], f[2]}


def all_names(f):
    if f[0] == "eq":
        return term_variables(f[1]) | term_variables(f[2])
    return {f[1], f[2]} | all_names(f[3])


def substitute_term(t, variable, replacement):
    if t[0] == "var":
        return replacement if t[1] == variable else t
    return fun(t[1], *(substitute_term(a, variable, replacement) for a in t[2]))


def fresh_name(base, forbidden):
    index = 0
    while f"{base}_{index}" in forbidden:
        index += 1
    return f"{base}_{index}"


def substitute_formula(f, variable, replacement):
    """Capture-avoiding substitution on named paired binders."""
    if f[0] == "eq":
        return equation(substitute_term(f[1], variable, replacement),
                        substitute_term(f[2], variable, replacement))
    first, second, body = f[1:]
    if variable in (first, second):
        return f
    names = [first, second]
    for index, name in enumerate(names):
        if name in term_variables(replacement):
            forbidden = all_names(body) | term_variables(replacement) | set(names) | {variable}
            renamed = fresh_name(name, forbidden)
            # Recursive substitution stops at an inner binder of the same name.
            body = substitute_formula(body, name, var(renamed))
            names[index] = renamed
    return binder(*names, substitute_formula(body, variable, replacement))


def plug_term(motive, replacement):
    return substitute_term(motive, HOLE, replacement)


def plug_formula(motive, replacement):
    return substitute_formula(motive, HOLE, replacement)


def alpha_key(f):
    """Canonical comparison key, with bound variables replaced by distances."""
    def key_term(t, environment):
        if t[0] == "var":
            for distance, bound_name in enumerate(reversed(environment)):
                if t[1] == bound_name:
                    return ("bound", distance)
            return ("free", t[1])
        return ("fun", t[1], tuple(key_term(a, environment) for a in t[2]))

    def key_formula(a, environment):
        if a[0] == "eq":
            return ("eq", key_term(a[1], environment), key_term(a[2], environment))
        return ("D", key_formula(a[3], environment + (a[1], a[2])))

    return key_formula(f, ())


def sources():
    """Audited premises, not arithmetic theorems or inferred oracle facts."""
    x, b, c = var("x"), fun("b"), fun("c")
    return {
        "xb": (x, b),
        "fg_x": (fun("f", x), fun("g", x)),
        "hj_fb": (fun("h", fun("f", b), c), fun("j", fun("f", b), c)),
    }


def infer(proof, registry):
    """Independent checker of the original equality proof constructors."""
    require(isinstance(proof, dict), "equality proof")
    tag = proof.get("rule")
    if tag == "refl":
        endpoint = term(proof["term"])
        require(HOLE not in term_variables(endpoint), "closed proof endpoint")
        return endpoint, endpoint
    if tag == "neutral":
        identity = proof.get("source")
        require(identity in registry, "unknown neutral source")
        reverse = proof.get("reverse", False)
        require(type(reverse) is bool, "orientation Boolean")
        left, right = registry[identity]
        return (right, left) if reverse else (left, right)
    require(tag == "Tr", "equality proof constructor")
    r, s = infer(proof["major"], registry)
    minor_left, minor_right = infer(proof["minor"], registry)
    p, q = term(proof["left_motive"]), term(proof["right_motive"])
    require(minor_left == plug_term(p, r), "transport minor left endpoint")
    require(minor_right == plug_term(q, r), "transport minor right endpoint")
    return plug_term(p, s), plug_term(q, s)


def reverse_path(path):
    return [{**edge, "reverse": not edge["reverse"]} for edge in reversed(path)]


def lift_path(path, outer_motive):
    return [{**edge, "motive": plug_term(outer_motive, edge["motive"])} for edge in path]


def compile_equality(proof):
    """Untrusted producer: output only bidirectional neutral-source rewrites."""
    tag = proof["rule"]
    if tag == "refl":
        return []
    if tag == "neutral":
        return [{"source": proof["source"], "reverse": proof.get("reverse", False),
                 "motive": var(HOLE)}]
    major = compile_equality(proof["major"])
    minor = compile_equality(proof["minor"])
    # Exactly: p(s) -> p(r), then p(r) -> q(r), then q(r) -> q(s).
    return (lift_path(reverse_path(major), term(proof["left_motive"]))
            + minor + lift_path(major, term(proof["right_motive"])))


def make_certificate(proof, outer_motive, registry):
    left, right = infer(proof, registry)
    motive = formula(outer_motive)
    steps = []
    for edge in compile_equality(proof):
        a, b = registry[edge["source"]]
        if edge["reverse"]:
            a, b = b, a
        lifted = plug_formula(motive, edge["motive"])
        steps.append({"source": edge["source"], "reverse": edge["reverse"],
                      "motive": lifted, "before": plug_formula(lifted, a),
                      "after": plug_formula(lifted, b)})
    return {"start": plug_formula(motive, left), "finish": plug_formula(motive, right),
            "steps": steps}


def replay(certificate, registry):
    """Check each edge solely from its declared source and formula motive.

    This function never calls compile_equality, infer, reverse_path, or lift_path.
    Its input is the serialized/reloaded neutral certificate, not a proof object.
    """
    require(isinstance(certificate, dict), "certificate record")
    current = formula(certificate["start"])
    expected_finish = formula(certificate["finish"])
    require(HOLE not in free_variables(current), "start has an unfilled hole")
    require(HOLE not in free_variables(expected_finish), "finish has an unfilled hole")
    require(isinstance(certificate["steps"], list), "step list")
    for number, step in enumerate(certificate["steps"]):
        require(isinstance(step, dict), "step record")
        identity = step.get("source")
        require(identity in registry, f"step {number}: unknown source")
        require(type(step.get("reverse")) is bool, "step orientation")
        left, right = registry[identity]
        if step["reverse"]:
            left, right = right, left
        motive = formula(step["motive"])
        before, after = formula(step["before"]), formula(step["after"])
        calculated_before = plug_formula(motive, left)
        calculated_after = plug_formula(motive, right)
        require(alpha_key(before) == alpha_key(calculated_before), f"step {number}: source/motive before")
        require(alpha_key(after) == alpha_key(calculated_after), f"step {number}: source/motive after")
        require(alpha_key(current) == alpha_key(before), f"step {number}: disconnected path")
        current = after
    require(alpha_key(current) == alpha_key(expected_finish), "wrong final formula")
    return len(certificate["steps"])


def must_reject(label, certificate, registry):
    try:
        replay(certificate, registry)
    except (InvalidCertificate, KeyError, TypeError) as error:
        return {"name": label, "rejected": True, "reason": str(error)}
    raise RuntimeError(f"Negative control was accepted: {label}")


def main():
    registry = sources()
    hole, b, c = var(HOLE), fun("b"), fun("c")
    basic = {"rule": "Tr", "major": {"rule": "neutral", "source": "xb"},
             "minor": {"rule": "neutral", "source": "fg_x"},
             "left_motive": fun("f", hole), "right_motive": fun("g", hole)}
    nested = {"rule": "Tr", "major": basic,
              "minor": {"rule": "neutral", "source": "hj_fb"},
              "left_motive": fun("h", hole, c), "right_motive": fun("j", hole, c)}
    outer = binder("x", "y", binder("z", "w",
                   equation(fun("h", hole, var("x")), fun("j", hole, var("y")))))
    cases = [
        ("three_arrow_transport", basic),
        ("nested_transport", nested),
        ("reflexivity", {"rule": "refl", "term": b}),
        ("reverse_neutral", {"rule": "neutral", "source": "xb", "reverse": True}),
    ]
    certificates = {}
    positive = []
    for name, proof in cases:
        certificate = make_certificate(proof, outer, registry)
        # Replay JSON-derived values, independently of producer object identity.
        certificate = json.loads(json.dumps(certificate))
        count = replay(certificate, registry)
        certificates[name] = {"equality_proof": proof, "certificate": certificate}
        positive.append({"name": name, "neutral_steps": count, "accepted": True})

    sample = certificates["three_arrow_transport"]["certificate"]
    controls = []
    damaged = copy.deepcopy(sample)
    damaged["steps"][0]["source"] = "fg_x"
    controls.append(must_reject("changed_source", damaged, registry))
    damaged = copy.deepcopy(sample)
    damaged["steps"][0]["reverse"] = not damaged["steps"][0]["reverse"]
    controls.append(must_reject("swapped_orientation", damaged, registry))
    damaged = copy.deepcopy(sample)
    damaged["steps"][0]["motive"] = equation(var(HOLE), b)
    controls.append(must_reject("incorrect_motive", damaged, registry))
    damaged = copy.deepcopy(sample)
    damaged["steps"][1]["source"] = "not_a_declared_source"
    controls.append(must_reject("unknown_source", damaged, registry))
    damaged = copy.deepcopy(sample)
    damaged["finish"] = sample["start"]
    controls.append(must_reject("incorrect_finish", damaged, registry))
    damaged = copy.deepcopy(sample)
    damaged["steps"] = damaged["steps"][1:]
    controls.append(must_reject("missing_backward_major", damaged, registry))
    changed_registry = dict(registry)
    changed_registry["xb"] = (var("x"), c)
    controls.append(must_reject("altered_declared_source", copy.deepcopy(sample), changed_registry))

    middle = formula(sample["steps"][0]["after"])
    require("x" in free_variables(middle), "capture avoidance lost the source's free x")
    require(middle[1] != "x", "capture avoidance did not rename the colliding binder")
    renamed = binder("alpha", middle[2], substitute_formula(middle[3], middle[1], var("alpha")))
    require(alpha_key(middle) == alpha_key(renamed), "alpha equivalence control")

    proof_rejections = []
    damaged_proof = copy.deepcopy(basic)
    damaged_proof["left_motive"] = fun("g", hole)
    try:
        infer(damaged_proof, registry)
    except InvalidCertificate as error:
        proof_rejections.append({"name": "invalid_original_transport", "rejected": True,
                                 "reason": str(error)})
    else:
        raise RuntimeError("Original proof checker accepted a wrong transport minor")

    root = Path(__file__).resolve().parents[1]
    destination = root / "evidence"
    destination.mkdir(parents=True, exist_ok=True)
    certificate_path = destination / "neutral_demo_certificates.json"
    certificate_path.write_text(json.dumps({"declared_sources": registry, "cases": certificates},
                                           indent=2) + "\n", encoding="utf-8")
    result = {
        "scope": "Local free-algebra equality-transport normalization only; not a complete iPRA checker or a formalization of DI/DE.",
        "source_status": "The three neutral equalities are declared premises, not proved arithmetic facts.",
        "positive_cases": positive,
        "negative_certificate_controls": controls,
        "negative_original_proof_controls": proof_rejections,
        "capture_avoidance": {"nested_D_depth": 2, "source_free_x_preserved": True,
                              "colliding_binder_renamed": True, "alpha_equivalence_checked": True},
        "nontrivial_Tr_step_order": ["backward major", "minor", "forward major"],
        "all_checks_passed": True,
    }
    (destination / "neutral_demo_results.json").write_text(json.dumps(result, indent=2) + "\n",
                                                           encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
