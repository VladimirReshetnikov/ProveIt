#!/usr/bin/env python3
"""Reproduce the complete-source frontier and the rejected validation deletion.

This is an audit driver, not a new iPRA proof checker. The unchanged reference
normalizer measures entire programs, including imports and the public driver.
"""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / 'reference'
EVIDENCE = ROOT / 'evidence'
NORMALIZER_SHA = 'f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc'
BEST_SHA = '6726df4aa9cb5560ac82889c5ff1fcab8838e8752b29eeee2c509ad78e85982e'
COORDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
# The final goal [[],[0]] is a well-formed encoding of 0=S0.
COUNTEREXAMPLE = [[0, [0]], [[0, 0, [], [0]], 0], [[], [0]]]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def definitions(source):
    tree = ast.parse(source)
    tree.body = [node for node in tree.body if not isinstance(node, ast.Try)]
    namespace = {}
    exec(compile(tree, '<audited local reference>', 'exec'), namespace)
    return namespace


def evaluate(namespace, packet):
    stack = copy.deepcopy(packet)
    namespace['k'] = 0
    namespace['q'] = stack.pop
    try:
        verdict = bool(namespace['c'](stack.pop(), []))
    except Exception:
        verdict = False
    return {'accepted': verdict, 'final_floor': namespace['k'],
            'unread_cells': len(stack)}


def cli(path, text, optimized=False):
    command = [sys.executable] + (['-O'] if optimized else []) + [str(path)]
    result = subprocess.run(command, input=text, text=True, capture_output=True,
                            timeout=20)
    return {'exit_code': result.returncode, 'stdout': result.stdout,
            'stderr': result.stderr}


def expected(accepted):
    return {'exit_code': 0 if accepted else 1,
            'stdout': 'ACCEPT\n' if accepted else 'REJECT\n', 'stderr': ''}


def main():
    EVIDENCE.mkdir(exist_ok=True)
    normalizer = REF / 'source_measure.py'
    best = REF / 'checkers/complete_kernel_309.py'
    require(digest(normalizer) == NORMALIZER_SHA, 'Changed source normalizer')
    require(digest(best) == BEST_SHA, 'Changed 309-token reference')
    snapshot = json.loads((EVIDENCE / 'source_snapshot.json').read_text())
    retained_archives = []
    for entry in snapshot['archives']:
        path = REF / entry['name']
        if path.exists():
            data = path.read_bytes()
            git_blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            require(digest(path) == entry['sha256'] and git_blob == entry['git_blob'],
                    'Changed mathematical reference archive')
            retained_archives.append(entry['name'])
    manifest = json.loads((REF / 'checker_manifest.json').read_text())
    for entry in manifest['programs']:
        path = ROOT / entry['file']
        require(digest(path) == entry['sha256'], 'Changed comparator ' + str(path))
    spec = importlib.util.spec_from_file_location('source_measure', normalizer)
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    rows = [{'file': p.name, **measure.metrics(p)}
            for p in sorted((REF / 'checkers').glob('*.py'))]
    minima = {key: min(row[key] for row in rows) for key in COORDS}
    require(tuple(minima[k] for k in COORDS) == (309, 344, 864),
            'Source frontier differs; inspect runtime version and complete files')
    metrics = {'python': platform.python_version(), 'program_count': len(rows),
               'scope': 'whole executable source, inherited normalizer',
               'coordinate_minima': minima, 'programs': rows}
    (EVIDENCE / 'frontier_metrics.json').write_text(json.dumps(metrics, indent=2)+'\n')

    namespace = definitions(best.read_text())
    fixtures = json.loads((REF / 'complete_kernel_fixtures.json').read_text())['records']
    for record in fixtures:
        require(evaluate(namespace, record['packet'])['accepted'],
                'Positive fixture rejected: ' + record['id'])
    cases = json.loads((REF / 'complete_kernel_cli_cases.json').read_text())['cases']
    public_results = []
    for optimized in (False, True):
        for case in cases:
            observed = cli(best, case['input_text'], optimized)
            require(observed == expected(case['expected_accept']),
                    'Public protocol mismatch: ' + case['name'])
            public_results.append({'case': case['name'], 'optimized': optimized,
                                   'passed': True})

    source = best.read_text()
    require(source.count('if i(a) in g:') == 1, 'Unexpected reference lookup')
    relaxed = source.replace('if i(a) in g:', 'if a in g:')
    counter_results = []
    with tempfile.TemporaryDirectory() as temporary:
        rejected_variant = Path(temporary) / 'rejected_variant.py'
        rejected_variant.write_text(relaxed)
        relaxed_metrics = measure.metrics(rejected_variant)
        for optimized in (False, True):
            text = json.dumps(COUNTEREXAMPLE)
            original_result = cli(best, text, optimized)
            variant_result = cli(rejected_variant, text, optimized)
            require(original_result == expected(False), 'Reference accepted 0=S0')
            require(variant_result == expected(True), 'Expected finite counterexample failed')
            counter_results.append({'optimized': optimized,
                                    'original': original_result,
                                    'rejected_variant': variant_result})
    (EVIDENCE / 'validation_counterexample.json').write_text(json.dumps({
        'packet': COUNTEREXAMPLE, 'decoded_goal': '0 = S0',
        'single_source_change': 'if i(a) in g:  ->  if a in g:',
        'variant_status': 'REJECTED; derives a false closed equation',
        'rejected_variant_metrics': relaxed_metrics,
        'public_results': counter_results}, indent=2)+'\n')
    result = {'python': platform.python_version(),
              'retained_archives_verified': retained_archives,
              'inherited_positive_packets_accepted': len(fixtures),
              'public_protocol_checks': public_results,
              'counterexample_public_runs': len(counter_results)*2,
              'new_complete_checker': False,
              'scope': 'finite replay and exact source measurements, not formal metatheory'}
    (EVIDENCE / 'frontier_replay.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'complete_programs': len(rows), 'frontier': minima,
                      'positive_packets': len(fixtures),
                      'public_protocol_runs': len(public_results),
                      'counterexample_runs': len(counter_results)*2}))


if __name__ == '__main__':
    main()
