#!/usr/bin/env python3
"""Enumerate distinct labelled line unions and verify the two incidence encodings."""
import argparse
from collections import Counter
from fractions import Fraction
from itertools import combinations


def field_tables(q):
    if q == 4:
        # Elements 0,1,T,T+1 in F_2[T]/(T^2+T+1).
        add = [[a ^ b for b in range(q)] for a in range(q)]
        def multiply(a, b):
            raw = (a if b & 1 else 0) ^ ((a << 1) if b & 2 else 0)
            return raw ^ (0b111 if raw & 4 else 0)
    else:
        if q < 2 or any(q % p == 0 for p in range(2, int(q**0.5) + 1)):
            raise ValueError("Use a prime order or order four")
        add = [[(a + b) % q for b in range(q)] for a in range(q)]
        def multiply(a, b):
            return a * b % q
    return add, [[multiply(a, b) for b in range(q)] for a in range(q)]


def line_masks(q):
    add, mul = field_tables(q)
    # Points 0..q^2-1 are affine (x,y); next q points are finite slopes,
    # and the final point is the vertical point at infinity.
    lines = []
    for slope in range(q):
        for intercept in range(q):
            line = 1 << (q*q + slope)
            for x in range(q):
                y = add[mul[x][slope]][intercept]
                line |= 1 << (x*q + y)
            lines.append(line)
    for x in range(q):
        lines.append((1 << (q*q+q)) | (((1 << q)-1) << (x*q)))
    lines.append(((1 << (q+1))-1) << (q*q))
    return lines


def verify(q):
    lines = line_masks(q)
    v = q*q + q + 1
    assert len(lines) == v
    assert all(line.bit_count() == q+1 for line in lines)
    assert all((x & y).bit_count() == 1 for x, y in combinations(lines, 2))
    family = {0}
    for line in lines:
        family.update([s | line for s in family])
    point_hits = [0] * v
    holes_histogram = Counter()
    lines_histogram = Counter()
    for s in family:
        a = reconstructed = 0
        for line in lines:
            if line & s == line:
                a += 1
                reconstructed |= line
        b = v - s.bit_count()
        assert reconstructed == s
        assert a * (q + b) <= q * (v - b)
        holes_histogram[b] += 1
        lines_histogram[a] += 1
        for point in range(v):
            point_hits[point] += (s >> point) & 1
    assert len(set(point_hits)) == 1
    assert lines_histogram == holes_histogram  # coordinate polarity of PG(2,q)
    if q == 4:
        # Directly construct the nine point Hermitian curve, then recover
        # each of its 2^9 point traces using the unique tangent lines.
        add, mul = field_tables(q)
        curve = 1 << (q*q+q)
        for x in range(q):
            for y in range(q):
                if add[mul[y][y]][y] == mul[mul[x][x]][x]:
                    curve |= 1 << (x*q+y)
        assert curve.bit_count() == 9
        tangents = [line for line in lines if (curve & line).bit_count() == 1]
        assert len({line & curve for line in tangents}) == len(tangents) == 9
        assert len({s & curve for s in family}) == 2**9
    hits = point_hits[0]
    print(f"q={q} v={v} M={len(family)} hits_per_point={hits} "
          f"frequency={Fraction(hits, len(family))}")
    print(f"  holes (number of points omitted: number of unions) "
          f"{dict(sorted(holes_histogram.items()))}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("orders", nargs="*", type=int, default=[2, 3, 4, 5])
    for order in parser.parse_args().orders:
        verify(order)
