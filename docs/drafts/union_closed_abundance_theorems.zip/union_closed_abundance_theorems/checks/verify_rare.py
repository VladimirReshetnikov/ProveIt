"""Exact checks for the three-block construction and the local defect formula."""

from itertools import combinations


def union_closed(family):
    return all(a | b in family for a, b in combinations(family, 2))


def check_local_fibers():
    count = 0
    zero_score = []
    for selector in range(1 << 8):
        fiber = {x for x in range(8) if selector & (1 << x)}
        if 7 not in fiber or not union_closed(fiber):
            continue
        count += 1
        score = 3 * sum(x.bit_count() for x in fiber) - 4 * len(fiber)
        singles = sum(x.bit_count() == 1 for x in fiber)
        assert score >= (singles - 1) ** 2 + 4 * (0 not in fiber)
        if score == 0:
            zero_score.append(fiber)
    assert len(zero_score) == 3
    assert all({0, 1 << i, 7} in zero_score for i in range(3))
    print(f"{count} union-closed triple fibers containing the top, with 3 zero-score types")


def sharpness_family(m):
    top = (1 << (3 * m)) - 1
    members = {0, 7}
    members.update((top << 3) | trace for trace in range(8))
    for i in range(3):
        block = ((1 << m) - 1) << (m * i)
        for proper in range((1 << m) - 1):
            projection = (top ^ block) | (proper << (m * i))
            members.update((projection << 3) | trace for trace in (0, 1 << i, 7))
    return members


def check_example(m):
    family = sharpness_family(m)
    t = (1 << m) - 1
    n = len(family)
    assert union_closed(family)
    assert n == 9 * t + 10
    degrees = [sum(s >> x & 1 for s in family) for x in range(3 + 3 * m)]
    assert degrees[:3] == [4 * t + 5] * 3
    assert degrees[3:] == [6 * t + 3 * ((1 << (m - 1)) - 1) + 8] * (3 * m)
    assert 9 * max(degrees[:3]) - 4 * n == 5
    print(f"m={m}, N={n}, local degree={degrees[0]}, outside degree={degrees[3]}, "
          f"outside points={3 * m}, excess=5")


if __name__ == "__main__":
    check_local_fibers()
    for dimension in range(2, 8):
        check_example(dimension)
