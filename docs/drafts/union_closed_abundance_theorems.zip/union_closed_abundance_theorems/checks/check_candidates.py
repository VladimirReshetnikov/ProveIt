"""Test the two-sided counting certificate on every labelled union for q <= 4."""
from collections import defaultdict
from fractions import Fraction
from check_planes import line_masks


def verify_candidates(q, theta):
    lines = line_masks(q)
    v = len(lines)
    d = q + 1
    universe = (1 << v) - 1
    family = {0}
    for line in lines:
        family |= {member | line for member in family}

    # The key is the unordered collection of selected lines.
    # Retain the two candidate sizes and count the unions assigned to each key.
    counts = defaultdict(int)
    sizes = {}
    a, b = theta.numerator, theta.denominator
    for member in family:
        contained = [i for i, line in enumerate(lines) if line & member == line]
        remaining = universe
        seed = 0
        steps = 0
        while True:
            threshold = a * d * remaining.bit_count()
            chosen = next((i for i in contained
                           if b * v * (lines[i] & remaining).bit_count() > threshold),
                          None)
            if chosen is None:
                break
            seed |= 1 << chosen
            remaining &= ~lines[chosen]
            steps += 1
        assert seed.bit_count() == steps
        assert (universe ^ member) & ~remaining == 0
        low = {i for i, line in enumerate(lines)
               if b * v * (line & remaining).bit_count() <= threshold}
        assert set(contained) <= low
        r = remaining.bit_count()
        l = len(low)
        # Sharper finite product bound, including the factor 1-r/v.
        assert (b-a)**2 * d*d * l*r <= b*b*q*v*(v-r)
        counts[seed] += 1
        if seed in sizes:
            assert sizes[seed] == (l, r)
        sizes[seed] = l, r

    for seed, count in counts.items():
        assert count <= 2**min(sizes[seed])
    print(f"q={q}, theta={theta}, distinct unions={len(family)}, "
          f"candidate pairs checked by seed={len(counts)}, "
          f"largest seed={max(key.bit_count() for key in counts)}")


if __name__ == "__main__":
    for order in [2, 3, 4]:
        for fraction in [Fraction(1, 2), Fraction(3, 4)]:
            verify_candidates(order, fraction)
