"""Exact enumeration checks for the small complete uniform families.

A bit mask encodes a set. A second mask records a section, which need
only be stable under adjoining pairs. This tests a superset of the
possible union-closed sections.
"""
from itertools import combinations


def check_pair_sections(rank):
    cube_size = 2**rank
    pairs = [(1 << i) | (1 << j) for i, j in combinations(range(rank), 2)]
    eligible = equalities = 0
    for mask in range(1, 1 << cube_size):
        section = [s for s in range(cube_size) if mask >> s & 1]
        if any(not (mask >> (s | edge) & 1) for s in section for edge in pairs):
            continue
        eligible += 1
        size = len(section)
        excess = sum(2 * s.bit_count() - rank for s in section)
        assert excess >= 0
        if rank == 3:
            # s log(8/s) <= 7 log(8/7) * excess
            left = 8**size * 7**(7 * excess)
            right = size**size * 8**(7 * excess)
            omitted = set(range(8)).difference(section)
            expected = not omitted or (len(omitted) == 1 and omitted <= {1, 2, 4})
            assert (left == right) == expected
        else:
            # s log(16/s) <= excess
            left = 16**size
            right = size**size * (1 << excess)
        assert left <= right
        equalities += (left == right)
    print(f'rank {rank}: {eligible} nonempty sections, {equalities} equalities')


def check_four_point_triple_sections():
    triples = {7, 11, 13, 14}
    minimum = [None] * 17
    eligible = 0
    for mask in range(1, 1 << 16):
        section = {i for i in range(16) if (mask >> i) & 1}
        if any((a | b) not in section for a in section for b in section | triples):
            continue
        eligible += 1
        size = len(section)
        excess = sum(2 * s.bit_count() - 4 for s in section)
        assert excess >= 0
        # s log(16/s) <= 6 log(4/3) * D(S)
        assert 16**size * 3**(6*excess) <= size**size * 4**(6*excess)
        if minimum[size] is None or excess < minimum[size]:
            minimum[size] = excess
    assert minimum[1:] == [4, 6, 8, 8, 8, 8, 6, 6, 4, 4, 4, 2, 2, 2, 2, 0]
    print(f'rank 4 triples: {eligible} sections, verified minimum-excess table')


def check_five_point_triple_sections():
    """Choose traces in descending order so all strict unions are decided."""
    cube_size = 32
    triples = [s for s in range(cube_size) if s.bit_count() == 3]
    eligible = equalities = 0

    def visit(candidate, section, size, excess):
        nonlocal eligible, equalities
        if candidate < 0:
            if size:
                assert excess >= 0
                left = cube_size**size
                right = size**size * (1 << excess)
                assert left <= right
                eligible += 1
                equalities += (left == right)
            return
        visit(candidate - 1, section, size, excess)
        for other in triples:
            union = candidate | other
            if union != candidate and union not in section:
                return
        if any((candidate | other) not in section for other in section):
            return
        section.add(candidate)
        visit(candidate - 1, section, size + 1, excess + 2 * candidate.bit_count() - 5)
        section.remove(candidate)

    visit(cube_size - 1, set(), 0, 0)
    assert (eligible, equalities) == (35759, 32)
    print(f'rank 5 triples: {eligible} nonempty union-closed sections, {equalities} equalities')


if __name__ == '__main__':
    check_pair_sections(3)
    check_pair_sections(4)
    check_four_point_triple_sections()
    check_five_point_triple_sections()
