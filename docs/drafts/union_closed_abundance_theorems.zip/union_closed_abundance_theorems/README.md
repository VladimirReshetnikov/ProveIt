# Point frequencies in union-closed families

## The papers

**line_unions.pdf** proves that a uniformly chosen distinct union of lines in the classical projective plane of square order q omits a fixed point with probability asymptotic to 1/(2 sqrt(q)). The logarithm to base two of the number of unions is asymptotic to q^(3/2). The paper includes an error bound, concentration, an inverse theorem for the count, and a half-frequency result at every finite order even without point transitivity.

**local_abundance.pdf** gives two independent results. A three-element member whose largest degree differs from 4N/9 by a subpolynomial amount forces at least (3-o(1)) log_2 N outside elements of relative frequency at least 2/3-o(1). The coefficient three is sharp. A fractional cover by complete uniform configurations gives quantitative lower bounds on mean set size. For blocks of size r at least 2t-1 containing all t-sets, apart from (r,t)=(3,2), the bound is n-(log_2 N)/2. Sharpness examples and boundary cases are included.

The source attributes the previously established inputs and the specific ProveIt constructions. The general union-closed sets conjecture remains open. The literature comparison does not certify priority.

## Build

In the extracted directory, with a standard TeX Live installation, run

    latexmk -pdf line_unions.tex local_abundance.tex

Alternatively run pdflatex at least twice on each of those two main files. Keep geometry.tex, geometry_refs.tex, triples.tex and blocks.tex beside them.

## Reproduce the finite checks

Use Python 3.10 or later, with its standard library. From the extracted directory run

    python3 checks/check_planes.py 2 3 4 5
    python3 checks/check_candidates.py
    python3 checks/verify_rare.py
    python3 checks/check_cliques.py

The four matching transcripts in checks/ are plane_results.txt, candidate_results.txt, triple_results.txt and block_results.txt. The order-five run stores more than 1.5 million distinct sets in memory. Omitting its final argument gives a smaller run. The small-instance checks illustrate the general proofs. The four-point endpoint constant in the companion paper uses an exhaustive finite table with an exact integer verifier.

The count always includes the empty union and counts distinct labelled unions of point sets. The first check tests each union's canonical lines and the dual histogram, as well as the nine-point tangent construction at order four. The second tests the seed and both subset encodings with exact rational thresholds. The third checks the entire local triple classification and the sharp examples. The fourth tests admissible small-block sections and the exact table used in the proof.
