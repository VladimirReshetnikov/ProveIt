FINITE DIAGNOSTICS AND REPRODUCIBLE SIZE COUNTS

Run from the package directory:

    python3 artifacts/verify_basis.py

Python 3.10 or later is sufficient; no external package is needed. The script
writes diagnostic_results.json, schema_metrics.json, and program_descriptions.json
in this directory. Its random formula generation uses the fixed seed 20261101.

What is checked

* Direct evaluation of swapped recursion agrees with the explicit ordinary
  primitive-recursive diagonal fold for eight update families and several frozen
  parameter tuples.
* A deliberately damaged diagonal fold is rejected, with a concrete input recorded.
* The selector C, adjacent difference D, and diagonal eraser T have the stated
  natural-number behavior, as do the derived equality error and zero test.
* Six ordinary recursion families agree with their translation into the source
  language, including nonzero initial values and parameter dependence.
* Formula-to-bit compilation includes conjunction, disjunction, and implication.
* The latch stationarity calculation is checked for arbitrary local registers,
  without assuming that the register is Boolean.
* Formula trees independently reproduce D=19, Sep=6, PE=25, prior O=11 and SS=22
  at one displayed parameter. All parameter lengths 1 through 4 satisfy the stated
  formulas. The selected C,D,T update bodies have sizes 1,1,11, totaling 13.

Scope

These are finite executable diagnostics, not a universal mathematical proof or a
proof-assistant certificate. They do not verify quantified schemata, arbitrary
models, or bi-interpretability. The article supplies those written proofs. Any
separate Lean certificate in the package has its own explicit scope statement.

The template metric does not count descriptor tags, variable-binding metadata,
the schema enumerator, or all concrete instances of the infinite axiom family.
At one displayed parameter the new formula total plus the selected update bodies
is 50+13=63; the inspected initialized-swap presentation has 52+13=65 on that same
limited ledger. No absolute description-length minimality is claimed.

Provenance

The Python implementation is new. Its swap recurrence and diagonal fold reproduce
the mathematics of pra_initialized_swap_2026-10-31.zip in the inspected ProveIt
snapshot e6474c41337c6495c4589970d8d1bfdcfce65b66. Its arithmetic basis is the new
pointed-swap basis. No program from a downloaded archive is executed here.
