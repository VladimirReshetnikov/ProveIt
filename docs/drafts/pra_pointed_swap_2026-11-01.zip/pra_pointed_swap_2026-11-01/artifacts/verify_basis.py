#!/usr/bin/env python3
"""Reproducible finite diagnostics for the pointed-swap PRA presentation.

This file is newly written for this report. The swap recurrence and diagonal
fold are the constructions inspected in the 2026-10-31 initialized-swap draft;
the pointed-swap arithmetic schema is the new 2026-11-01 construction. These
finite computations are diagnostics, not a formal proof of the infinite schema,
of nonstandard-model correctness, or of bi-interpretability.

Run with Python 3.10 or later: python3 artifacts/verify_basis.py
Only the Python standard library is used. No downloaded program is executed.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import random
from typing import Callable


OUT = Path(__file__).resolve().parent
Update = Callable[[int, int, tuple[int, ...], int], int]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def make_swap(update: Update) -> Callable[..., int]:
    """Direct computation of R(0,a)=a and R(Sn,a)=h(n,a,R(a,n))."""
    @lru_cache(maxsize=None)
    def recur(x: int, a: int, frozen: tuple[int, ...] = ()) -> int:
        require(x >= 0 and a >= 0, "Natural-number input required")
        if x == 0:
            return a
        n = x - 1
        return update(n, a, frozen, recur(a, n, frozen))
    return recur


def diagonal_fold(update: Update, x: int, y: int,
                  frozen: tuple[int, ...] = (), *, damaged: bool = False) -> int:
    """Ordinary PR program V(min(x,y), x dotminus y, y dotminus x).

    The damaged option deliberately exchanges the inner update arguments. It
    is used only to confirm that the cross-check detects that specific defect.
    """
    d, e, count = max(x - y, 0), max(y - x, 0), min(x, y)
    value = e if d == 0 else update(d - 1, 0, frozen, d - 1)
    for j in range(count):
        if damaged:
            inner = update(d + j, e + j, frozen, value)
        else:
            inner = update(e + j, d + j, frozen, value)
        value = update(d + j, e + j + 1, frozen, inner)
    return value


def choice(z: int, when_zero: int, when_positive: int) -> int:
    return when_zero if z == 0 else when_positive


raw_choice = make_swap(lambda n, a, b, v: b[0])
raw_difference = make_swap(lambda n, a, b, v: v)


def eraser_update(n: int, a: int, frozen: tuple[int, ...], v: int) -> int:
    return choice(raw_difference(a, n),
                  choice(raw_difference(n, a), a, 0), a)


raw_eraser = make_swap(eraser_update)


def predecessor(x: int) -> int:
    return raw_difference(x, 0)


def zero_error(x: int) -> int:
    """The derived q: zero at zero, one at a positive input."""
    return raw_eraser(x + 1, 1)


def equality_error(x: int, y: int) -> int:
    return raw_eraser(x + 1, y + 1)


def global_choice(z: int, when_zero: int, when_nonzero: int) -> int:
    return choice(zero_error(z), when_zero, when_nonzero)


def ordinary_to_swap(base: Callable[[tuple[int, ...]], int],
                     step: Callable[[int, tuple[int, ...], int], int]):
    """Compile ordinary recursion by the stated diagonal source program."""
    def update(n: int, a: int, frozen: tuple[int, ...], v: int) -> int:
        return global_choice(
            equality_error(a, n), v,
            global_choice(n, base(frozen), step(predecessor(n), frozen, v)),
        )
    recur = make_swap(update)
    return lambda n, frozen=(): recur(n + 1, n + 1, frozen)


@dataclass(frozen=True)
class Tree:
    label: str
    children: tuple["Tree", ...] = ()

    def count(self) -> int:
        return 1 + sum(child.count() for child in self.children)

    def export(self):
        return self.label if not self.children else {
            "node": self.label, "arguments": [c.export() for c in self.children]
        }


def node(label: str, *children: Tree) -> Tree:
    return Tree(label, children)


def bind(names: list[str], body: Tree) -> Tree:
    for name in reversed(names):
        body = node("forall " + name, body)
    return body


def metrics() -> dict:
    zero, one = node("0"), node("S", node("0"))
    n, a, x, y, v = map(node, ["n", "a", "x", "y", "v"])
    sep = node("implies", node("=", zero, one), node("false"))
    old_off_diagonal = bind(
        ["x", "y"], node("or", node("=", node("T", x, y), y), node("=", x, y))
    )
    c_update = node("b")
    d_update = v
    t_update = node("C", node("D", a, n),
                    node("C", node("D", n, a), a, zero), a)
    rows = []
    trees_at_one = {}
    for m in range(1, 5):
        names = ["a"] + [f"b{i}" for i in range(1, m)]
        parameters = list(map(node, names))
        frozen = parameters[1:]
        base = bind(names, node("=", node("R", zero, *parameters), a))
        step = bind(["n"] + names,
                    node("=", node("R", node("S", n), *parameters),
                         node("h", n, a, *frozen, node("R", a, n, *frozen))))
        f_zero = node("f", zero, *parameters)
        f_n = node("f", n, *parameters)
        stationarity = bind(["n"], node("=", node("f", node("S", n), *parameters), f_n))
        pointed = bind(names, node("implies", stationarity,
                         bind(["n"], node("or", node("=", node("T", f_zero, a), a),
                                               node("=", f_n, a)))))
        old_separation = bind(names, node("implies", stationarity,
                            bind(["n"], node("implies",
                                node("=", node("S", f_n), f_zero), node("false")))))
        row = {
            "displayed_parameter_count": m,
            "D_base": base.count(), "D_step": step.count(),
            "D_total": base.count() + step.count(),
            "Sep": sep.count(), "PE": pointed.count(),
            "old_O": old_off_diagonal.count(), "old_SS": old_separation.count(),
        }
        row["new_total"] = row["D_total"] + row["Sep"] + row["PE"]
        row["old_swap_total"] = row["D_total"] + row["old_O"] + row["old_SS"]
        require(row["D_total"] == 6 * m + 13, "D metric formula")
        require(row["PE"] == 5 * m + 20, "PE metric formula")
        require(row["old_SS"] == 5 * m + 17, "SS metric formula")
        require(row["new_total"] == 11 * m + 39, "new total metric formula")
        require(row["old_swap_total"] - row["new_total"] == 2, "uniform saving")
        rows.append(row)
        if m == 1:
            trees_at_one = {key: value.export() for key, value in {
                "D_base": base, "D_step": step, "Sep": sep, "PE": pointed,
                "old_O": old_off_diagonal, "old_SS": old_separation,
            }.items()}
    selected = {"C": c_update.count(), "D": d_update.count(), "T": t_update.count()}
    require(rows[0]["D_total"] == 19 and rows[0]["Sep"] == 6
            and rows[0]["PE"] == 25 and rows[0]["old_O"] == 11
            and rows[0]["old_SS"] == 22, "one-parameter metric")
    require(sum(selected.values()) == 13, "selected descriptor metric")
    return {
        "convention": "One node per variable, constant, application, equality, logical "
                      "connective, falsity, and individual quantifier. Negation is "
                      "implication to falsity; 1 is S(0). No charge for binder names.",
        "rows": rows, "selected_update_body_nodes": selected,
        "selected_update_body_total": sum(selected.values()),
        "one_parameter_formula_trees": trees_at_one,
        "designated_update_trees": {"C": c_update.export(), "D": d_update.export(),
                                    "T": t_update.export()},
        "not_counted": ["descriptor tags", "binding metadata", "schema enumerator",
                        "the full infinite family of concrete axiom instances"],
    }


def numerical_checks() -> dict:
    counts = {name: 0 for name in ["swap_vs_fold", "designated_programs",
                                   "ordinary_recursion", "formula_bits", "latch"]}
    updates: list[tuple[str, Update]] = [
        ("previous_value", lambda n, a, b, v: v),
        ("counter", lambda n, a, b, v: n),
        ("mutable_argument", lambda n, a, b, v: a),
        ("successor_value", lambda n, a, b, v: v + 1),
        ("asymmetric_linear", lambda n, a, b, v: n + 2 * a + v),
        ("frozen_weighted", lambda n, a, b, v: n + a * (b[0] + 1) + v),
        ("bounded_nonlinear", lambda n, a, b, v: (n * a + v * v + sum(b)) % 23),
        ("zero_branch", lambda n, a, b, v: a + 1 if v == 0 else (v + n) % 19),
    ]
    frozen_samples = [(), (0,), (2,), (1, 4)]
    for name, update in updates:
        direct = make_swap(update)
        legal_frozen = frozen_samples[1:] if name == "frozen_weighted" else frozen_samples
        for frozen in legal_frozen:
            for x, y in product(range(17), repeat=2):
                expected, actual = direct(x, y, frozen), diagonal_fold(update, x, y, frozen)
                require(expected == actual, f"swap/fold: {name}, {x,y,frozen}")
                counts["swap_vs_fold"] += 1

    damaged_witness = None
    asymmetric = dict(updates)["asymmetric_linear"]
    direct = make_swap(asymmetric)
    for x, y in product(range(9), repeat=2):
        good, bad = direct(x, y), diagonal_fold(asymmetric, x, y, damaged=True)
        if good != bad:
            damaged_witness = {"x": x, "y": y, "correct": good, "damaged": bad,
                               "defect": "inner update arguments interchanged"}
            break
    require(damaged_witness is not None, "The deliberate compiler defect escaped detection")

    for x, y in product(range(31), repeat=2):
        require(raw_difference(x, y) == max(y - x, 0) + max(x - y - 1, 0),
                f"D numerical meaning at {x,y}")
        require(raw_eraser(x, y) == (0 if x == y else y), f"T meaning at {x,y}")
        require((equality_error(x, y) == 0) == (x == y), f"native equality at {x,y}")
        require(equality_error(x, y) in (0, y + 1), f"e range at {x,y}")
        counts["designated_programs"] += 4
    for z, u, w in product(range(10), range(5), range(5)):
        require(raw_choice(z, u, (w,)) == choice(z, u, w), "C constructor evaluation")
        require(global_choice(z, u, w) == choice(z, u, w), "global J evaluation")
        counts["designated_programs"] += 2
    for x in range(50):
        require(predecessor(x) == max(x - 1, 0), "predecessor")
        require(raw_difference(x, x) == 0 and raw_difference(x, x + 1) == 1,
                "two D diagonals")
        require(zero_error(x) == int(x != 0), "q")
        counts["designated_programs"] += 3

    recurrences = [
        ("nonzero_constant", lambda b: 3, lambda n, b, v: v, [()]),
        ("addition", lambda b: b[0], lambda n, b, v: v + 1, [(0,), (2,), (7,)]),
        ("triangular_shift", lambda b: b[0], lambda n, b, v: v + n + 1, [(0,), (4,)]),
        ("factorial", lambda b: 1, lambda n, b, v: (n + 1) * v, [()]),
        ("powers", lambda b: 1, lambda n, b, v: b[0] * v, [(0,), (2,), (3,)]),
        ("bounded_state", lambda b: b[0],
         lambda n, b, v: (n * v + b[1]) % 29, [(0, 1), (3, 7)]),
    ]
    for name, base, step, parameter_sets in recurrences:
        compiled = ordinary_to_swap(base, step)
        for frozen in parameter_sets:
            value = base(frozen)
            for n in range(13):
                require(compiled(n, frozen) == value,
                        f"ordinary/source compiler: {name}, {n,frozen}")
                counts["ordinary_recursion"] += 1
                value = step(n, frozen, value)

    # Quantifier-free formulas: this syntax intentionally includes implication.
    # Integers 0,1,2 are atoms x=y, x=0, and Sx=y, respectively.
    leaves = [("atom", i) for i in range(3)] + [("false",), ("true",)]
    rng = random.Random(20261101)
    def generate(depth: int):
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice(leaves)
        return (rng.choice(["and", "or", "implies"]),
                generate(depth - 1), generate(depth - 1))
    formulas = leaves + [generate(4) for _ in range(200)]

    def evaluate(formula, x: int, y: int) -> tuple[bool, int]:
        op = formula[0]
        if op == "atom":
            left, right = [(x, y), (x, 0), (x + 1, y)][formula[1]]
            return left == right, zero_error(equality_error(left, right))
        if op == "false":
            return False, 1
        if op == "true":
            return True, 0
        left, left_bit = evaluate(formula[1], x, y)
        right, right_bit = evaluate(formula[2], x, y)
        if op == "and":
            return left and right, global_choice(left_bit, right_bit, 1)
        if op == "or":
            return left or right, global_choice(left_bit, 0, right_bit)
        return (not left) or right, global_choice(left_bit, right_bit, 0)

    for formula in formulas:
        for x, y in product(range(9), repeat=2):
            truth, bit = evaluate(formula, x, y)
            require(bit in (0, 1) and truth == (bit == 0), "formula-to-bit translation")
            counts["formula_bits"] += 1

    # Local latch proof: arbitrary current register, no induction/range assumption.
    for current_bit, next_bit, register in product(range(2), range(2), range(7)):
        if current_bit == 0 and next_bit != 0:
            continue  # This is precisely the excluded failed induction step.
        next_register = global_choice(current_bit, register, 0)
        next_next_register = global_choice(next_bit, next_register, 0)
        require(next_register == next_next_register, "local latch stationarity")
        counts["latch"] += 1
    for length in range(9):
        for bits in product(range(2), repeat=length):
            register = 1
            failed = False
            for bit in bits:
                register = global_choice(bit, register, 0)
                failed = failed or bit != 0
                require(register == int(not failed), "running latch finite semantics")
                counts["latch"] += 1

    return {
        "status": "passed", "counts": counts, "total_checks": sum(counts.values()),
        "swap_update_families": [name for name, _ in updates],
        "swap_input_range": "0 through 16 in each active argument",
        "ordinary_recurrence_families": [row[0] for row in recurrences],
        "ordinary_counter_range": "0 through 12",
        "formula_generation_seed": 20261101, "formula_count": len(formulas),
        "formula_input_range": "0 through 8 for x and y",
        "deliberate_bad_compiler_detected": damaged_witness,
        "scope": "Finite diagnostics only. They do not prove quantified axioms, "
                 "nonstandard-model correctness, induction equivalence, or bi-interpretability.",
    }


def descriptions() -> dict:
    return {
        "recursion_grammar": {
            "base": "R_h(0,a,b)=a",
            "step": "R_h(Sn,a,b)=h(n,a,b,R_h(a,n,b))",
            "restrictions": "h uses only earlier symbols; b is any finite frozen tuple; "
                            "different finite descriptions remain distinct symbols.",
        },
        "designated_updates": {
            "C": "h_C(n,a,b,v)=b",
            "D": "h_D(n,a,v)=v",
            "T": "h_T(n,a,v)=C(D(a,n),C(D(n,a),a,0),a)",
        },
        "abbreviations": {
            "1": "S0", "p(x)": "D(x,0)", "q(z)": "T(Sz,1)",
            "e(x,y)": "T(Sx,Sy)", "J(z,u,v)": "C(q(z),u,v)",
        },
        "arithmetic_basis": {
            "Sep": "0 != S0",
            "PE": "forall a,c ((forall n f(Sn,a,c)=f(n,a,c)) -> "
                  "forall n (T(f(0,a,c),a)=a or f(n,a,c)=a))",
            "schema_scope": "Every finite term f and every finite parameter tuple c. "
                            "The term may ignore the distinguished parameter a. "
                            "Axioms may be used under fixed hypotheses.",
        },
        "ordinary_recursion_compiler": {
            "update": "h(n,a,b,v)=J(e(a,n),v,J(n,G(b),H(p(n),b,v)))",
            "output": "F(n,b)=R_h(Sn,Sn,b)",
        },
        "swap_to_ordinary_compiler": {
            "V_base": "V(0,d,e,b)=C(d,e,h(p(d),0,b,p(d)))",
            "V_step": "V(Sj,d,e,b)=h(d+j,S(e+j),b,h(e+j,d+j,b,V(j,d,e,b)))",
            "output": "Rhat(x,y,b)=V(min(x,y),x dotminus y,y dotminus x,b)",
        },
        "provenance": {
            "source_repository": "VladimirReshetnikov/ProveIt",
            "inspected_commit": "e6474c41337c6495c4589970d8d1bfdcfce65b66",
            "prior_construction_archive": "docs/drafts/pra_initialized_swap_2026-10-31.zip",
            "prior_compiler_member": "pra_initialized_swap_2026-10-31/swap_compiler.tex",
            "new_contribution": "Replace the prior O and SS by Sep and PE, with a "
                                "constructive reconstruction of the omitted principles.",
        },
    }


def main() -> None:
    outputs = {"schema_metrics.json": metrics(), "diagnostic_results.json": numerical_checks(),
               "program_descriptions.json": descriptions()}
    for name, payload in outputs.items():
        (OUT / name).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    result = outputs["diagnostic_results.json"]
    print(json.dumps({"status": result["status"], "total_checks": result["total_checks"],
                      "counts": result["counts"],
                      "one_parameter_metric": outputs["schema_metrics.json"]["rows"][0],
                      "bad_compiler_counterexample": result["deliberate_bad_compiler_detected"]},
                     indent=2))


if __name__ == "__main__":
    main()
