#!/usr/bin/env python3
"""Rebuild the article and rerun the disclosed diagnostics."""

from __future__ import annotations

import argparse
import pathlib
import shutil
import subprocess
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Optional path to the Lean 4.19.0 compiler")
    args = parser.parse_args()
    root = pathlib.Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    subprocess.run([sys.executable, "artifacts/verify_basis.py"], cwd=root, check=True)
    if args.lean:
        result = subprocess.run(
            [args.lean, "formal/PointedSwap.lean"],
            cwd=root, capture_output=True, text=True, check=False,
        )
        (root / "formal/PointedSwap.log").write_text(
            result.stdout + result.stderr, encoding="utf-8"
        )
        if result.returncode:
            print(result.stdout + result.stderr, file=sys.stderr)
            return result.returncode
        print("Lean kernel checked successfully.")
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("pdflatex is required to build the PDF.")
    logs = []
    for pass_number in range(1, 4):
        result = subprocess.run(
            [engine, "-interaction=nonstopmode", "-halt-on-error",
             "-jobname=pra_pointed_swap", "report.tex"],
            cwd=root, capture_output=True, text=True, check=False,
        )
        logs.append(f"LaTeX pass {pass_number}\n" + result.stdout + result.stderr)
        (audit / "latex_build.log").write_text("\n".join(logs), encoding="utf-8")
        if result.returncode:
            print(result.stdout + result.stderr, file=sys.stderr)
            return result.returncode
    print(f"Built {root / 'pra_pointed_swap.pdf'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
