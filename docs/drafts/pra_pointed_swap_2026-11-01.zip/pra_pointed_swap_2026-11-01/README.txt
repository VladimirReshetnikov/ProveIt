POINTED SWAP: A SMALLER BASIS FOR PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 1 November 2026.

MAIN RESULT

Use initialized swap recursion, 0 != S0, and the pointed-erasure schema
specified in specification.txt and report.tex. In classical first-order
equality logic this theory is definitionally equivalent to classical PRA;
in intuitionistic first-order equality logic it is definitionally
equivalent to intuitionistic PRA with quantifier-free induction.
Both interpretations use the full carrier and native equality, and both
round trips have the identity as their internally proved isomorphism.

The measured common-basis display decreases from 52 to 50 expanded
syntax-tree nodes at one displayed parameter. The computation grammar
and selected program bodies are unchanged from the initialized swap
draft. Selected update bodies still cost 13 nodes, so the two disclosed
ledgers together decrease from 65 to 63. This is a strict local comparison,
not an absolute minimum or a complete encoding-length optimum.

START HERE

  pra_pointed_swap.pdf       Complete research article, compiled from LaTeX
  report.tex                Self-contained source; bibliography is embedded
  specification.txt         Complete concise theory specification

SUPPORTING FILES

  formal/PointedSwap.lean    Checked constructive forward kernel
  formal/PointedSwap.log     Successful Lean output and 18 axiom audits
  formal/SCOPE.txt           Exact formalization scope and assumptions
  formal/verification.json  Compiler verification and proof hash
  formal/lean-toolchain      leanprover/lean4:v4.19.0

  artifacts/verify_basis.py  Finite compiler diagnostics and exact AST counter
  artifacts/diagnostic_results.json
  artifacts/schema_metrics.json
  artifacts/program_descriptions.json
  artifacts/README.txt

  audit/source_manifest.json  Seven immutable comparison sources and hashes
  audit/validation.json       Deliverable validation summary
  audit/latex_build.log       Final successful LaTeX build output
  build.py                   Rebuild the PDF and rerun finite diagnostics
  SHA256SUMS                 Checksums for all other delivered files

REPRODUCE

From this directory, with Python 3 and pdflatex installed:

  python3 build.py

This runs the finite diagnostics and three LaTeX passes. It needs common
TeX packages including amsmath, amsthm, lmodern, microtype, booktabs,
tabularx, enumitem, xurl, fancyhdr, and hyperref. No Python package outside
the standard library is required for the diagnostics or the build script.

To check the Lean kernel separately using Lean 4.19.0:

  lean formal/PointedSwap.lean

Or supply a compiler path to the build script:

  python3 build.py --lean /absolute/path/to/lean

The formal file needs no Mathlib dependency. Its final #print axioms
commands should each report that the declaration has no additional axioms.
It still assumes the theory's displayed hypotheses as arguments: an empty
axiom-dependency list does not mean an axiom-free proof of arithmetic.

VALIDATION AND LIMITS

The recorded run passed 33,821 finite diagnostics, including an intentionally
damaged compiler that the tests detect. Exact formula trees independently
reproduce D=19, Sep=6, PE=25 and the 52-node predecessor at one parameter.
All 18 Lean theorem audits passed without extra axiom dependencies.

The complete bi-interpretability theorem is a written mathematical proof.
The Lean file checks a local constructive forward kernel using semantic
per-function interfaces for term-schema instances. It does not formalize
the entire first-order syntax, reverse compiler, or interpretation round
trips. The article supplies those arguments and the finite-term instance
ledger. Finite numerical tests are diagnostics, not universal proofs.

PROVENANCE

All seven archives in the requested ProveIt docs/drafts directory were
downloaded at commit e6474c41337c6495c4589970d8d1bfdcfce65b66, and their
Git blob hashes were verified. Their current specifications and relevant
proofs were read. The source manifest identifies the exact bytes.
The current initialized-swap draft supplies the unchanged computational
architecture; the pointed-constancy drafts supply the comparison-target
idea. The new PE combination and its reordered constructive bootstrap
are the simplification established here. Attribution is also recorded
in the article, Python diagnostics, and adapted Lean kernel.

No GitHub repository files were changed. The comparison archives are not
duplicated in this package; retrieve their exact versions using the manifest.

