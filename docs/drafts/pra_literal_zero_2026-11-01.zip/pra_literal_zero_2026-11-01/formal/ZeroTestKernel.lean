/-
Constructive zero-test kernel for the PRA presentation.

The carrier is an arbitrary type. No natural-number model, decidable equality,
classical reasoning, axiom declarations, or admitted proofs are used.

The two induction/propagation hypotheses are deliberately the particular
first-order instances used in the argument, not induction for arbitrary Lean
predicates. `ZeroProbeInduction` is equation induction for the displayed
residual term. `AtomicDiagonalPropagation` is the admitted matrix
  F(n,a) := (n = a) -> (zero = a).
The surrounding syntactic generator and the full PRA compiler are not
formalized in this file.
-/

set_option autoImplicit false

universe u

namespace ZeroTestKernel

structure Arithmetic (Carrier : Type u) where
  zero : Carrier
  succ : Carrier -> Carrier
  pred : Carrier -> Carrier
  reset : Carrier -> Carrier -> Carrier
  pred_zero : pred zero = zero
  pred_succ : forall n : Carrier, pred (succ n) = n
  reset_zero : forall a : Carrier, reset zero a = a
  reset_succ : forall n a : Carrier, reset (succ n) a = zero
  separation : zero = succ zero -> False

namespace Arithmetic

variable {Carrier : Type u} (A : Arithmetic Carrier)

def zeroProbe (n : Carrier) : Carrier :=
  A.reset n (A.succ A.zero)

def residualTerm (n : Carrier) : Carrier :=
  A.reset (A.zeroProbe n) (A.succ (A.pred n))

def ZeroProbeInduction : Prop :=
  (A.zero = A.residualTerm A.zero) ->
  (forall n : Carrier,
    n = A.residualTerm n -> A.succ n = A.residualTerm (A.succ n)) ->
  forall n : Carrier, n = A.residualTerm n

def AtomicDiagonalPropagation : Prop :=
  forall a : Carrier,
    (forall n : Carrier,
      (n = a -> A.zero = a) -> (A.succ n = a -> A.zero = a)) ->
    forall n : Carrier, n = a -> A.zero = a

def ZeroDecidable : Prop :=
  forall a : Carrier, a = A.zero ∨ (a = A.zero -> False)

def Coverage : Prop :=
  forall a : Carrier, a = A.zero ∨ a = A.succ (A.pred a)

theorem successor_injective {x y : Carrier}
    (h : A.succ x = A.succ y) : x = y := by
  have hp := congrArg A.pred h
  simpa only [A.pred_succ] using hp

theorem successor_ne_zero (n : Carrier) : A.succ n = A.zero -> False := by
  intro h
  have hn : n = A.zero := by
    have hp := congrArg A.pred h
    simpa only [A.pred_succ, A.pred_zero] using hp
  have hzero : A.zero = A.succ A.zero := by
    calc
      A.zero = A.succ n := h.symm
      _ = A.succ A.zero := congrArg A.succ hn
  exact A.separation hzero

theorem zeroProbe_zero : A.zeroProbe A.zero = A.succ A.zero := by
  exact A.reset_zero (A.succ A.zero)

theorem zeroProbe_succ (n : Carrier) : A.zeroProbe (A.succ n) = A.zero := by
  exact A.reset_succ n (A.succ A.zero)

theorem residual_identity (induction : A.ZeroProbeInduction) :
    forall n : Carrier, n = A.residualTerm n := by
  apply induction
  · calc
      A.zero = A.reset (A.succ A.zero) (A.succ (A.pred A.zero)) :=
        (A.reset_succ A.zero (A.succ (A.pred A.zero))).symm
      _ = A.reset (A.zeroProbe A.zero) (A.succ (A.pred A.zero)) :=
        congrArg (fun t => A.reset t (A.succ (A.pred A.zero)))
          A.zeroProbe_zero.symm
      _ = A.residualTerm A.zero := rfl
  · intro n _
    calc
      A.succ n = A.reset A.zero (A.succ n) := (A.reset_zero (A.succ n)).symm
      _ = A.reset (A.zeroProbe (A.succ n)) (A.succ n) :=
        congrArg (fun t => A.reset t (A.succ n)) (A.zeroProbe_succ n).symm
      _ = A.reset (A.zeroProbe (A.succ n)) (A.succ (A.pred (A.succ n))) :=
        congrArg (fun t => A.reset (A.zeroProbe (A.succ n)) (A.succ t))
          (A.pred_succ n).symm
      _ = A.residualTerm (A.succ n) := rfl

theorem negative_coverage (propagation : A.AtomicDiagonalPropagation)
    (a : Carrier) (hnot : a = A.succ (A.pred a) -> False) : a = A.zero := by
  have hall : forall n : Carrier, n = a -> A.zero = a := by
    apply propagation a
    intro n _ hna
    apply False.elim
    apply hnot
    have hp : A.pred a = n := by
      calc
        A.pred a = A.pred (A.succ n) := congrArg A.pred hna.symm
        _ = n := A.pred_succ n
    calc
      a = A.succ n := hna.symm
      _ = A.succ (A.pred a) := congrArg A.succ hp.symm
  exact (hall a rfl).symm

theorem nonzero_probe_implies_zero (propagation : A.AtomicDiagonalPropagation)
    (a : Carrier) (hnot : A.zeroProbe a = A.zero -> False) : a = A.zero := by
  have hall : forall n : Carrier, n = a -> A.zero = a := by
    apply propagation a
    intro n _ hna
    apply False.elim
    apply hnot
    calc
      A.zeroProbe a = A.zeroProbe (A.succ n) := congrArg A.zeroProbe hna.symm
      _ = A.zero := A.zeroProbe_succ n
  exact (hall a rfl).symm

theorem coverage_of_zero_decidable
    (induction : A.ZeroProbeInduction)
    (propagation : A.AtomicDiagonalPropagation)
    (decidable_zero : A.ZeroDecidable) : A.Coverage := by
  intro a
  rcases decidable_zero (A.zeroProbe a) with hzero | hnot
  · apply Or.inr
    calc
      a = A.residualTerm a := A.residual_identity induction a
      _ = A.succ (A.pred a) := by
        change A.reset (A.zeroProbe a) (A.succ (A.pred a)) = A.succ (A.pred a)
        rw [hzero, A.reset_zero]
  · exact Or.inl (A.nonzero_probe_implies_zero propagation a hnot)

theorem zero_decidable_of_coverage (coverage : A.Coverage) : A.ZeroDecidable := by
  intro a
  rcases coverage a with hzero | hsucc
  · exact Or.inl hzero
  · apply Or.inr
    intro hzero
    exact A.successor_ne_zero (A.pred a) (hsucc.symm.trans hzero)

theorem zero_decidability_iff_coverage
    (induction : A.ZeroProbeInduction)
    (propagation : A.AtomicDiagonalPropagation) :
    A.ZeroDecidable ↔ A.Coverage := by
  constructor
  · exact A.coverage_of_zero_decidable induction propagation
  · exact A.zero_decidable_of_coverage

end Arithmetic
end ZeroTestKernel

#print axioms ZeroTestKernel.Arithmetic.successor_ne_zero
#print axioms ZeroTestKernel.Arithmetic.residual_identity
#print axioms ZeroTestKernel.Arithmetic.negative_coverage
#print axioms ZeroTestKernel.Arithmetic.nonzero_probe_implies_zero
#print axioms ZeroTestKernel.Arithmetic.coverage_of_zero_decidable
#print axioms ZeroTestKernel.Arithmetic.zero_decidable_of_coverage
#print axioms ZeroTestKernel.Arithmetic.zero_decidability_iff_coverage
