PRA FROM ORIENTED EQUATIONS AND A DECIDABLE ZERO TEST
Research package prepared for Vladimir Reshetnikov
1 November 2026 (America/Los_Angeles)

MAIN RESULT

The report gives a strict effective subfamily of the 15-node propagation
presentation in the inspected ProveIt drafts. For an equation E(n,a), the
ordinary matrix constructor admits E(0,a) -> E(n,a) and its reverse.
Three exact stationary witness classes recover initialization, successor
computation, and separation. Intuitionistically one additional fixed matrix
expressing decidability of equality to zero suffices.

The central new lemma derives zero-or-successor coverage constructively from
that zero test and atomic propagation. Complete written proofs then recover
one-parameter quantifier-free induction, internal pairing, arbitrary finite
parameter tuples, and all primitive-recursive definitions. The two matching
theories have common conservative definitional extensions with first-order
PRA; both internal interpretation round trips are the identity.

The 15-node outer display is unchanged. The admissible matrix grammar is
strictly smaller and needs neither a rewrite-position search nor comparison
of independently supplied zero instances. In the same 15-node wrapper, the
fixed intuitionistic positive instance decreases from 71 nodes for coverage
to 64 nodes for the zero test. Stating the zero test directly costs 10 nodes
but creates a second displayed component. No absolute minimality is claimed.

FILES

  report.tex / report.pdf       Complete paper and compiled 16-page PDF
  obstruction.tex              Included Kripke countermodel section
  formal/ZeroTestKernel.lean   Constructive abstract-carrier proof kernel
  formal/lean-toolchain        Lean version used for verification
  checks/check_zero_test.py    Standalone finite-syntax checker and AST counts
  checks/syntax_results.json   Recorded successful syntax diagnostics
  audit/source_manifest.json   Snapshot and original archive/source hashes
  audit/verification.json      Build, syntax, and Lean verification summary
  audit/lean_verification.txt  Lean dependency reports
  build.py                    Rebuild and verification driver
  SHA256SUMS.txt              Integrity hashes for the package contents

REPRODUCTION

Python 3.10 or later, a standard TeX Live installation with latexmk, and Lean
4.19.0 are sufficient. No Mathlib dependency is required.

  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

The first command runs syntax diagnostics and compiles the PDF. The second
also recompiles the Lean kernel. The driver locates lean on PATH when --lean
is omitted, and records an explicit skip when it is unavailable. This package's
recorded validation ran Lean successfully, rather than skipping it.

VERIFICATION SCOPE

Lean checks the new zero-test kernel from exact, explicitly stated arithmetic
and propagation hypotheses over an arbitrary carrier. It does not formalize
the complete syntax-to-semantics bridge, arithmetic compiler, or full
bi-interpretability theorem. All seven printed theorem-dependency reports are
empty: no additional axiom dependencies, admitted proofs, or classical choice.

The Python checker checks finite syntax and exact counts. It does not prove
the arithmetic semantics. The complete mathematical argument is in the paper.

The proposed 14-node diagonal-endpoint variant and removal of the final
counter projection in the optional unary-update language remain unproved here.

PROVENANCE

Repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot: 7658d4a30ef9e9b6614e19d5033aab987443992e
Comparison directory: docs/drafts (all seven archives)
Every downloaded archive matched its Git blob identifier. The bibliography and
source manifest credit inherited techniques and identify the exact inputs.
No repository changes are needed to use this standalone package.
