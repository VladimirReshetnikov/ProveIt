#!/usr/bin/env python3
"""Finite-syntax diagnostics for oriented Z15 and its predecessors.

This is a standalone Python 3.10+ program using only the standard library.
It checks the actual finite syntax of selected schemas. It does not prove
arithmetic completeness, soundness in nonstandard models, or bi-interpretability.
Run: python3 check_zero_test.py
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Union


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class App:
    symbol: str
    args: tuple[Term, ...]


Term = Union[Var, Zero, App]


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bottom:
    pass


@dataclass(frozen=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Or:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Imp:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class All:
    binder: str
    body: Formula


@dataclass(frozen=True)
class Placeholder:
    """A schematic formula call, used only to count the outer display."""

    name: str
    args: tuple[Term, ...]


Formula = Union[Eq, Bottom, And, Or, Imp, All, Placeholder]
Signature = dict[str, Term]

ZERO = Zero()
BOT = Bottom()
N, A, B, U, V = map(Var, ("n", "a", "b", "u", "v"))


def succ(t: Term) -> App:
    return App("S", (t,))


def rec(name: str, counter: Term, seed: Term) -> App:
    return App(name, (counter, seed))


def term_fv(t: Term) -> set[str]:
    if isinstance(t, Var):
        return {t.name}
    if isinstance(t, Zero):
        return set()
    return set().union(*(term_fv(s) for s in t.args))


def formula_fv(f: Formula) -> set[str]:
    if isinstance(f, Eq):
        return term_fv(f.left) | term_fv(f.right)
    if isinstance(f, Bottom):
        return set()
    if isinstance(f, Placeholder):
        return set().union(*(term_fv(s) for s in f.args))
    if isinstance(f, All):
        return formula_fv(f.body) - {f.binder}
    return formula_fv(f.left) | formula_fv(f.right)


def formula_names(f: Formula) -> set[str]:
    """All names, including bound ones, for safe fresh-name generation."""
    if isinstance(f, (Eq, Bottom, Placeholder)):
        return formula_fv(f)
    if isinstance(f, All):
        return {f.binder} | formula_names(f.body)
    return formula_names(f.left) | formula_names(f.right)


def substitute_term(t: Term, env: dict[str, Term]) -> Term:
    if isinstance(t, Var):
        return env.get(t.name, t)
    if isinstance(t, Zero):
        return t
    return App(t.symbol, tuple(substitute_term(s, env) for s in t.args))


def substitute_formula(f: Formula, env: dict[str, Term]) -> Formula:
    if isinstance(f, Eq):
        return Eq(substitute_term(f.left, env), substitute_term(f.right, env))
    if isinstance(f, Bottom):
        return f
    if isinstance(f, Placeholder):
        return Placeholder(f.name, tuple(substitute_term(s, env) for s in f.args))
    if isinstance(f, All):
        inner_env = {k: v for k, v in env.items() if k != f.binder}
        inserted = set().union(*(term_fv(t) for t in inner_env.values()))
        binder, body = f.binder, f.body
        if binder in inserted:
            occupied = formula_names(body) | inserted | set(inner_env) | {binder}
            fresh = binder + "_fresh"
            while fresh in occupied:
                fresh += "_"
            body = substitute_formula(body, {binder: Var(fresh)})
            binder = fresh
        return All(binder, substitute_formula(body, inner_env))
    return type(f)(substitute_formula(f.left, env), substitute_formula(f.right, env))


def term_valid(t: Term, available: set[str]) -> bool:
    if isinstance(t, (Var, Zero)):
        return True
    arity = 1 if t.symbol == "S" else 2 if t.symbol in available else None
    return arity == len(t.args) and all(term_valid(s, available) for s in t.args)


def signature_valid(sig: Signature, restricted: bool = False) -> bool:
    earlier: set[str] = set()
    counter_exceptions = 0
    for name, body in sig.items():
        if name == "S" or not term_valid(body, earlier):
            return False
        if not term_fv(body) <= {"u", "v"}:
            return False
        if restricted and not term_fv(body) <= {"v"}:
            if body != U:
                return False
            counter_exceptions += 1
        earlier.add(name)
    return not restricted or counter_exceptions == 1


def formula_valid(f: Formula, sig: Signature) -> bool:
    if isinstance(f, Eq):
        return term_valid(f.left, set(sig)) and term_valid(f.right, set(sig))
    if isinstance(f, Bottom):
        return True
    if isinstance(f, Placeholder):
        return False  # A display placeholder is not an object-language formula.
    if isinstance(f, All):
        return formula_valid(f.body, sig)
    return formula_valid(f.left, sig) and formula_valid(f.right, sig)


def quantifier_free(f: Formula) -> bool:
    if isinstance(f, (Eq, Bottom)):
        return True
    if isinstance(f, (All, Placeholder)):
        return False
    return quantifier_free(f.left) and quantifier_free(f.right)


def initializer(name: str) -> Formula:
    return Imp(Eq(A, A), Eq(rec(name, ZERO, A), A))


def successor_witness(name: str, sig: Signature) -> Formula:
    rhs = substitute_term(sig[name], {"u": A, "v": rec(name, A, B)})
    return Imp(All("b", Eq(rhs, rhs)), All("b", Eq(rec(name, succ(A), B), rhs)))


def separation() -> Formula:
    return Imp(Eq(ZERO, succ(ZERO)), BOT)


def zero_decidable(t: Term) -> Formula:
    atom = Eq(t, ZERO)
    return Or(atom, Imp(atom, BOT))


def zero_test_matrix() -> Formula:
    return Imp(zero_decidable(ZERO), zero_decidable(N))


def oriented_equation_matrices(e: Eq) -> tuple[Formula, Formula]:
    """Generate both permitted orientations directly from one equation.

    There is no admission test on the equation: every well-formed equation
    with free variables contained in {n, a} supplies both matrices.
    """
    if not isinstance(e, Eq):
        raise TypeError("the matrix generator takes a single equation")
    base = substitute_formula(e, {"n": ZERO})
    return Imp(base, e), Imp(e, base)


def z15_case(f: Formula, sig: Signature, intuitionistic: bool) -> str | None:
    """Recognize the output of the oriented Z15 constructor families.

    Equality below is only constructor-pattern recognition. The generating
    definition is oriented_equation_matrices, with no zero-base comparison
    gate and no contraction search.
    """
    if not formula_valid(f, sig) or not formula_fv(f) <= {"n", "a"}:
        return None
    if isinstance(f, Imp) and isinstance(f.left, Eq) and isinstance(f.right, Eq):
        if f == oriented_equation_matrices(f.right)[0]:
            return "forward oriented equation matrix"
        if f == oriented_equation_matrices(f.left)[1]:
            return "reverse oriented equation matrix"
    for name in sig:
        if f == initializer(name):
            return "initializer"
        if f == successor_witness(name, sig):
            return "stationary successor witness"
    if f == separation():
        return "separation"
    if intuitionistic and f == zero_test_matrix():
        return "fixed zero-decidability matrix"
    return None


def literal_z15_case(f: Formula, sig: Signature, intuitionistic: bool) -> str | None:
    """Earlier, broader candidate: compare arbitrary equation zero bases."""
    if not formula_valid(f, sig) or not formula_fv(f) <= {"n", "a"}:
        return None
    if isinstance(f, Imp) and isinstance(f.left, Eq) and isinstance(f.right, Eq):
        if substitute_formula(f.left, {"n": ZERO}) == substitute_formula(
            f.right, {"n": ZERO}
        ):
            return "literal equation base"
    for name in sig:
        if f == initializer(name):
            return "initializer"
        if f == successor_witness(name, sig):
            return "stationary successor witness"
    if f == separation():
        return "separation"
    if intuitionistic and f == zero_test_matrix():
        return "fixed zero-decidability matrix"
    return None


def term_steps(t: Term, sig: Signature) -> list[Term]:
    """All results of ONE old V15 term contraction in the active tree."""
    if not isinstance(t, App):
        return []
    results: list[Term] = []
    if t.symbol in sig and len(t.args) == 2:
        counter, seed = t.args
        if counter == ZERO:
            results.append(seed)
        elif isinstance(counter, App) and counter.symbol == "S":
            previous = counter.args[0]
            results.append(substitute_term(
                sig[t.symbol], {"u": previous, "v": rec(t.symbol, previous, seed)}
            ))
    for index, child in enumerate(t.args):
        for replacement in term_steps(child, sig):
            args = list(t.args)
            args[index] = replacement
            results.append(App(t.symbol, tuple(args)))
    return results


def formula_steps(f: Formula, sig: Signature) -> list[Formula]:
    """Exactly one contextual contraction; no rewrite closure or normalization."""
    if isinstance(f, Eq):
        results: list[Formula] = [BOT] if f == Eq(ZERO, succ(ZERO)) else []
        results += [Eq(t, f.right) for t in term_steps(f.left, sig)]
        results += [Eq(f.left, t) for t in term_steps(f.right, sig)]
        return results
    if isinstance(f, (Bottom, Placeholder)):
        return []
    if isinstance(f, All):
        return [All(f.binder, g) for g in formula_steps(f.body, sig)]
    return ([type(f)(g, f.right) for g in formula_steps(f.left, sig)]
            + [type(f)(f.left, g) for g in formula_steps(f.right, sig)])


def old_shape(f: Formula) -> bool:
    if not formula_fv(f) <= {"n", "a"}:
        return False
    if quantifier_free(f):
        return True
    if not isinstance(f, Imp) or "n" in formula_fv(f):
        return False
    return all(isinstance(side, All) and side.binder == "b"
               and isinstance(side.body, Eq)
               and formula_fv(side.body) <= {"a", "b"}
               for side in (f.left, f.right))


def old_admission_steps(f: Formula, sig: Signature) -> int | None:
    if not formula_valid(f, sig) or not old_shape(f):
        return None
    base = substitute_formula(f, {"n": ZERO})
    reflexive = lambda x: isinstance(x, Imp) and x.left == x.right
    if reflexive(base):
        return 0
    if any(reflexive(g) for g in formula_steps(base, sig)):
        return 1
    return None


def term_nodes(t: Term) -> int:
    return 1 if isinstance(t, (Var, Zero)) else 1 + sum(map(term_nodes, t.args))


def nodes(f: Formula) -> int:
    if isinstance(f, Eq):
        return 1 + term_nodes(f.left) + term_nodes(f.right)
    if isinstance(f, Bottom):
        return 1
    if isinstance(f, Placeholder):
        return 1 + sum(map(term_nodes, f.args))
    if isinstance(f, All):
        return 1 + nodes(f.body)
    return 1 + nodes(f.left) + nodes(f.right)


def schema(f: Formula) -> Formula:
    return All("a", Imp(All("n", Imp(f, substitute_formula(f, {"n": succ(N)}))),
                        All("n", f)))


def coverage(t: Term) -> Formula:
    return Or(Eq(t, ZERO), Eq(t, succ(rec("K", t, ZERO))))


def run_checks() -> dict:
    # A finite, dependency-ordered sample of the optional restricted language.
    # K is the sole counter-reading exception; every other update is unary.
    sig: Signature = {
        "K": U,
        "Z": ZERO,
        "Add": succ(V),
        "Sub": rec("K", V, ZERO),
        "Double": rec("Add", V, V),
        "Hidden": rec("Z", ZERO, V),
    }
    checks: list[str] = []

    def check(name: str, condition: bool) -> None:
        if not condition:
            raise AssertionError(name)
        checks.append(name)

    check("dependency order and restricted unary updates", signature_valid(sig, True))
    check("self-reference rejected", not signature_valid({"Bad": rec("Bad", U, V)}))
    check("later reference rejected", not signature_valid({"Early": rec("Late", U, V),
                                                          "Late": ZERO}))
    check("extra update parameter rejected", not signature_valid({"Bad": A}))
    check("wrong arity rejected", not signature_valid({"Bad": App("S", (U, V))}))
    mixed = {"K": U, "Mix": rec("K", U, V)}
    check("general binary grammar permits mixed updates", signature_valid(mixed))
    check("restricted grammar rejects a mixed update", not signature_valid(mixed, True))

    for name in sig:
        for label, f in (("initializer", initializer(name)),
                         ("successor", successor_witness(name, sig))):
            check(name + " " + label + " is oriented Z15", z15_case(f, sig, False) is not None)
            check(name + " " + label + " enters old V15 in one step",
                  old_admission_steps(f, sig) == 1)
            check(name + " " + label + " has allowed free variables",
                  formula_fv(f) <= {"n", "a"})
    check("separation is oriented Z15", z15_case(separation(), sig, False) == "separation")
    check("separation enters old V15 in one step", old_admission_steps(separation(), sig) == 1)

    equations = [Eq(N, A), Eq(rec("Add", N, A), A), Eq(rec("Sub", N, A), ZERO)]
    z_n = rec("Z", N, succ(ZERO))
    p_n = rec("K", N, ZERO)
    equations.append(Eq(N, rec("Z", z_n, succ(p_n))))
    for index, e in enumerate(equations):
        f, reverse = oriented_equation_matrices(e)
        check(f"equation-induction probe {index} generated forward",
              z15_case(f, sig, False) == "forward oriented equation matrix")
        check(f"equation-induction probe {index} uses zero old contractions",
              old_admission_steps(f, sig) == 0)
        check(f"reverse equation probe {index} generated",
              z15_case(reverse, sig, False) == "reverse oriented equation matrix")
        check(f"reverse equation probe {index} uses zero old contractions",
              old_admission_steps(reverse, sig) == 0)
        check(f"forward equation probe {index} belongs to broader literal family",
              literal_z15_case(f, sig, False) is not None)
        check(f"reverse equation probe {index} belongs to broader literal family",
              literal_z15_case(reverse, sig, False) is not None)
    negative_probe = Imp(Eq(N, A), Eq(ZERO, A))
    check("negative zero-test probe generated in reverse orientation",
          z15_case(negative_probe, sig, False) == "reverse oriented equation matrix")
    check("negative zero-test probe uses zero contractions",
          old_admission_steps(negative_probe, sig) == 0)

    d_matrix = zero_test_matrix()
    check("fixed D matrix intuitionistically admitted",
          z15_case(d_matrix, sig, True) == "fixed zero-decidability matrix")
    check("fixed D matrix omitted from classical axiom set",
          z15_case(d_matrix, sig, False) is None)
    check("fixed D matrix uses zero old contractions", old_admission_steps(d_matrix, sig) == 0)
    c_matrix = Imp(coverage(ZERO), coverage(N))
    check("old coverage exception is not new zero-test exception",
          z15_case(c_matrix, sig, True) is None)
    check("old coverage exception still admitted in V15", old_admission_steps(c_matrix, sig) == 0)

    atom = Eq(N, ZERO)
    conjunction = Imp(And(atom, atom), And(atom, atom))
    check("strict conjunction witness belongs to V15", old_admission_steps(conjunction, sig) == 0)
    check("strict conjunction witness excluded from Z15", z15_case(conjunction, sig, True) is None)
    same_zero = Imp(Eq(N, N), Eq(N, ZERO))
    check("same-zero witness admitted by broader literal family",
          literal_z15_case(same_zero, sig, True) == "literal equation base")
    check("same-zero witness also belongs to original V15",
          old_admission_steps(same_zero, sig) == 0)
    check("same-zero witness excluded from oriented Z15",
          z15_case(same_zero, sig, True) is None)
    wrapped = Imp(Eq(succ(A), succ(A)), Eq(succ(rec("Z", ZERO, A)), succ(A)))
    check("context-wrapped initializer belongs to V15", old_admission_steps(wrapped, sig) == 1)
    check("context-wrapped initializer excluded from oriented Z15",
          z15_case(wrapped, sig, True) is None)
    stationary = Imp(All("b", Eq(B, B)), All("b", Eq(B, B)))
    check("arbitrary stationary tautology belongs to V15", old_admission_steps(stationary, sig) == 0)
    check("arbitrary stationary tautology excluded from Z15", z15_case(stationary, sig, True) is None)

    two_steps = Imp(Eq(A, A), Eq(rec("Z", ZERO, rec("Z", ZERO, A)), A))
    check("two required contractions rejected by V15", old_admission_steps(two_steps, sig) is None)
    check("two required contractions rejected by Z15", z15_case(two_steps, sig, True) is None)
    reversed_bad = Imp(Eq(succ(ZERO), ZERO), BOT)
    check("reversed separation is not silently normalized", old_admission_steps(reversed_bad, sig) is None)
    hidden = Imp(Eq(rec("Hidden", A, A), A), Eq(A, A))
    check("stored bodies are not active syntax occurrences", formula_steps(hidden, sig) == [])
    check("stored bodies are not unfolded by the old gate", old_admission_steps(hidden, sig) is None)
    extra_parameter = Imp(Eq(B, B), Eq(B, B))
    check("extra free parameter rejected", z15_case(extra_parameter, sig, True) is None)
    check("old gate also rejects extra free parameter", old_admission_steps(extra_parameter, sig) is None)
    capture_test = substitute_formula(All("b", Eq(N, B)), {"n": B})
    check("substitution avoids variable capture", formula_fv(capture_test) == {"b"})

    counts = {
        "outer_V15_or_Z15": nodes(schema(Placeholder("F", (N, A)))),
        "coverage_C_n": nodes(coverage(N)),
        "zero_decidability_D_n": nodes(zero_decidable(N)),
        "coverage_matrix": nodes(c_matrix),
        "zero_test_matrix": nodes(d_matrix),
        "coverage_matrix_successor": nodes(substitute_formula(c_matrix, {"n": succ(N)})),
        "zero_test_matrix_successor": nodes(substitute_formula(d_matrix, {"n": succ(N)})),
        "actual_V15_coverage_instance": nodes(schema(c_matrix)),
        "actual_V15_zero_test_instance": nodes(schema(d_matrix)),
        "direct_universal_zero_decidability": nodes(All("n", zero_decidable(N))),
    }
    expected = [15, 10, 9, 21, 19, 24, 21, 71, 64, 10]
    for (name, value), target in zip(counts.items(), expected):
        check("exact AST count " + name, value == target)
    return {
        "result": "PASS",
        "checks_passed": len(checks),
        "main_generator": "oriented Z15: E(0,a)->E(n,a) or E(n,a)->E(0,a)",
        "comparison_chain": "oriented Z15 is a strict subfamily of literal Z15, itself a subfamily of old V15",
        "signature_order": list(sig),
        "exact_AST_counts": counts,
        "fixed_positive_instance_saving": 71 - 64,
        "scope": "Finite syntax and exact display counts only; not a semantic proof.",
        "checks": checks,
    }


if __name__ == "__main__":
    print(json.dumps(run_checks(), indent=2))
