#!/usr/bin/env python3
"""Reproduce syntax diagnostics, the paper, and the optional Lean kernel."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def run(command: list[str]) -> str:
    result = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False,
    )
    if result.returncode:
        raise RuntimeError(
            f"Command failed ({result.returncode}): {command}\n{result.stdout}"
        )
    return result.stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Absolute Lean compiler path")
    args = parser.parse_args()
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)

    syntax_text = run([sys.executable, "checks/check_zero_test.py"])
    syntax = json.loads(syntax_text)
    (ROOT / "checks/syntax_results.json").write_text(
        json.dumps(syntax, indent=2) + "\n"
    )

    run(["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
         "report.tex"])
    log = (ROOT / "report.log").read_text(errors="replace")
    overfull = [line for line in log.splitlines() if "Overfull" in line]
    if overfull:
        raise RuntimeError("Overfull LaTeX boxes: " + repr(overfull))
    unresolved = [line for line in log.splitlines()
                  if "undefined" in line.lower() and "warning" in line.lower()]
    if unresolved:
        raise RuntimeError("Unresolved LaTeX references: " + repr(unresolved))

    lean_binary = args.lean or shutil.which("lean")
    lean_record: dict[str, object] = {"status": "skipped", "reason": "not found"}
    if lean_binary:
        lean_version = run([lean_binary, "--version"]).strip()
        lean_output = run([lean_binary, "formal/ZeroTestKernel.lean"])
        (audit / "lean_verification.txt").write_text(lean_output)
        if "sorryAx" in lean_output or "Classical.choice" in lean_output:
            raise RuntimeError("Unexpected Lean theorem dependencies")
        reports = [line for line in lean_output.splitlines()
                   if "does not depend on any axioms" in line]
        if len(reports) != 7:
            raise RuntimeError("Expected seven empty Lean dependency reports")
        lean_record = {
            "status": "passed", "version": lean_version,
            "source_sha256": hashlib.sha256(
                (ROOT / "formal/ZeroTestKernel.lean").read_bytes()
            ).hexdigest(),
            "empty_dependency_reports": len(reports),
            "scope": "New zero-test kernel under exact abstract-carrier hypotheses",
        }
    record = {
        "syntax": syntax,
        "latex": {"status": "passed", "overfull_boxes": overfull,
                  "unresolved_references": unresolved},
        "lean": lean_record,
        "scope": "Full compiler and bi-interpretability are written proofs",
    }
    (audit / "verification.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"syntax": "passed", "latex": "passed", "lean": lean_record},
                     indent=2))


if __name__ == "__main__":
    main()
