SIMPLER BASES FOR PRIMITIVE RECURSIVE ARITHMETIC
31 October 2026 (Pacific date)
Prepared for Vladimir Reshetnikov

Read pra_simpler_bases.pdf. The main source is pra_simpler_bases.tex,
with section sources in sections/.

MAIN RESULTS

1. In the existing binary initialized-iterator language and one-parameter
   arithmetic discipline, successor and predecessor positive uniqueness
   suffice. The separate identity-update family is redundant.
2. More strongly, successor positive uniqueness plus the fixed subtraction
   shift equation suffices in that same restricted language.
3. Ordinary constancy plus a fixed constructive equality certificate
   replaces the positive-constancy basis: 19 versus 26 recurring schema
   nodes, and 70 versus 83 total displayed nodes under its convention.
4. Elementary arithmetic plus termination of all LOOP programs at each
   fixed external nesting depth gives a finite-language presentation.

Each result concerns full first-order classical PRA and intuitionistic
PRA separately. The report proves definitional equivalence and supplies
identity-domain bi-interpretations, including their composites.
No absolute shortestness or general historical novelty is claimed.

BUILD

  latexmk -pdf -interaction=nonstopmode -halt-on-error pra_simpler_bases.tex

The document needs a conventional TeX Live installation with the packages
listed in its preamble. No bibliography processor is required.

LEAN CHECK

  lean --version
  lean formal/TwoUpdateCancellation.lean

Verified with Lean 4.19.0. There is no Mathlib dependency.
The five printed global-axiom audits are in formal/lean_verification.log.
This certificate checks the new cancellation/constancy proof over an
arbitrary carrier. It has explicit semantic hypotheses, and does NOT
formalize finite term syntax, first-order derivability, or all of the
bi-interpretation theorem. See VALIDATION.txt and the report.

PYTHON CHECKS

  python3 artifacts/schema_metrics.py
  python3 artifacts/loop_certificates.py

Python 3.10 or later, standard library only. The metric script prints
its conventions and exact counts. The LOOP artifact independently checks
bottom-up certificates, exercises snapshot semantics, and rejects altered
certificates. It is a diagnostic implementation, not a universal proof.

PROVENANCE

audit/source_manifest.json records the pinned ProveIt revision, all six
compared archives, Git blob hashes, SHA-256 hashes, immutable URLs, and
the scope of the incoming-directory check. Prior source ZIP files are
not duplicated in this package. SHA256SUMS covers the delivered files.
