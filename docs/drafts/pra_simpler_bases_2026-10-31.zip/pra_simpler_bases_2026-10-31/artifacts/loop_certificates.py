#!/usr/bin/env python3
"""Executable diagnostics for the finite-language LOOP presentation of PRA.

Requires Python 3.10+ and the standard library only. Run this file to generate
``loop_checks.json`` beside it, or specify ``--results PATH``.

Programs are finite lists of instructions:
    ("zero", register)
    ("inc", register)
    ("copy", destination, source)
    ("loop", register, body_program)

A loop snapshots its controlling register on entry. States are finite lists
of nonnegative integers. Every accessed register must already exist.

Certificates are bottom-up tables of the E/R judgments in the report:
E(P,j,s,t) executes a prefix of j instructions; R(P,k,s,t) repeats P k times.
The checker validates each row locally and never invokes the evaluator.

This is an executable semantic diagnostic, NOT a formal arithmetic proof.
Python recursion and integers are implementation facilities, not object-theory
axioms. The evaluator below handles arbitrary syntactic depths as an ordinary
computable procedure; it is NOT claimed to be primitive recursive uniformly
in program depth. The report constructs a different fixed PR description for
each fixed depth. The builder also has an explicit finite resource guard.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import platform
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any


FORMAT = "loop-prefix-trace-v1"
Program = tuple[tuple[Any, ...], ...]
State = tuple[int, ...]


class InvalidCertificate(ValueError):
    """A supplied program, state, or execution certificate is malformed."""


class TraceLimitExceeded(RuntimeError):
    """The diagnostic builder exceeded its explicit certificate-row budget."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise InvalidCertificate(message)


def is_nat(value: Any) -> bool:
    # Booleans are Python integers, but are not accepted as certificate numbers.
    return type(value) is int and value >= 0


def freeze_program(value: Any, active: set[int] | None = None) -> Program:
    """Validate finite list syntax and return an immutable canonical program."""
    require(isinstance(value, (list, tuple)), "program must be a finite list")
    if active is None:
        active = set()
    identity = id(value)
    require(identity not in active, "cyclic program container")
    active.add(identity)
    result: list[tuple[Any, ...]] = []
    try:
        for instruction in value:
            require(isinstance(instruction, (list, tuple)), "instruction is not a list")
            require(bool(instruction), "empty instruction")
            tag = instruction[0]
            require(type(tag) is str, "instruction tag is not a string")
            if tag in ("zero", "inc"):
                require(len(instruction) == 2, f"{tag} requires one register")
                require(is_nat(instruction[1]), f"{tag} register must be natural")
                result.append((tag, instruction[1]))
            elif tag == "copy":
                require(len(instruction) == 3, "copy requires two registers")
                require(all(is_nat(x) for x in instruction[1:]), "bad copy register")
                result.append((tag, instruction[1], instruction[2]))
            elif tag == "loop":
                require(len(instruction) == 3, "loop requires a register and body")
                require(is_nat(instruction[1]), "loop register must be natural")
                body = freeze_program(instruction[2], active)
                result.append((tag, instruction[1], body))
            else:
                raise InvalidCertificate(f"unknown instruction tag: {tag!r}")
    finally:
        active.remove(identity)
    return tuple(result)


def thaw_program(program: Program) -> list[list[Any]]:
    return [
        [tag, register, thaw_program(rest[0])] if tag == "loop"
        else [tag, register, *rest]
        for tag, register, *rest in program
    ]


@lru_cache(maxsize=None)
def register_bound(program: Program) -> int:
    """Number of registers sufficient for this program, including all bodies."""
    result = 0
    for instruction in program:
        tag, register, *rest = instruction
        result = max(result, register + 1)
        if tag == "copy":
            result = max(result, rest[0] + 1)
        elif tag == "loop":
            result = max(result, register_bound(rest[0]))
    return result


@lru_cache(maxsize=None)
def loop_depth(program: Program) -> int:
    return max(
        (1 + loop_depth(instruction[2])
         for instruction in program if instruction[0] == "loop"),
        default=0,
    )


def freeze_state(value: Any) -> State:
    require(isinstance(value, (list, tuple)), "state must be a finite list")
    require(all(is_nat(x) for x in value), "state entries must be natural numbers")
    return tuple(value)


def basic_update(instruction: tuple[Any, ...], state: State) -> State:
    """Apply one basic instruction; loops are deliberately excluded."""
    tag, destination, *rest = instruction
    result = list(state)
    if tag == "zero":
        result[destination] = 0
    elif tag == "inc":
        result[destination] += 1
    elif tag == "copy":
        result[destination] = state[rest[0]]
    else:
        raise InvalidCertificate("basic_update was given a loop")
    return tuple(result)


@dataclass(frozen=True)
class Row:
    kind: str
    program: Program
    count: int
    start: State
    end: State
    prefix: int | None = None
    body: int | None = None

    def as_json(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "program": thaw_program(self.program),
            "count": self.count,
            "start": list(self.start),
            "end": list(self.end),
            "prefix": self.prefix,
            "body": self.body,
        }


ROW_KEYS = {"kind", "program", "count", "start", "end", "prefix", "body"}


def parse_row(raw: Any, index: int) -> Row:
    require(type(raw) is dict and set(raw) == ROW_KEYS, f"row {index}: wrong fields")
    require(raw["kind"] in ("E", "R"), f"row {index}: unknown judgment tag")
    require(is_nat(raw["count"]), f"row {index}: count must be natural")
    program = freeze_program(raw["program"])
    start, end = freeze_state(raw["start"]), freeze_state(raw["end"])
    require(len(start) == len(end), f"row {index}: state lengths differ")
    require(len(start) >= register_bound(program), f"row {index}: missing register")
    for field in ("prefix", "body"):
        pointer = raw[field]
        require(pointer is None or is_nat(pointer), f"row {index}: invalid {field}")
        require(pointer is None or pointer < index, f"row {index}: {field} not earlier")
    return Row(
        raw["kind"], program, raw["count"], start, end, raw["prefix"], raw["body"]
    )


def verify_certificate(certificate: Any) -> State:
    """Check a complete certificate; return its output or raise InvalidCertificate.

    This function calls only syntax/state parsing and local transition checks.
    In particular it never calls build_certificate, evaluate, or repeat.
    """
    expected_keys = {"format", "program", "initial_state", "final_state", "rows"}
    require(type(certificate) is dict, "certificate must be an object")
    require(set(certificate) == expected_keys, "certificate has wrong fields")
    require(certificate["format"] == FORMAT, "unsupported certificate format")
    program = freeze_program(certificate["program"])
    initial = freeze_state(certificate["initial_state"])
    final = freeze_state(certificate["final_state"])
    require(len(initial) >= register_bound(program), "initial state lacks a register")
    require(len(initial) == len(final), "initial/final state lengths differ")
    raw_rows = certificate["rows"]
    require(type(raw_rows) is list and bool(raw_rows), "certificate table is empty")
    rows: list[Row] = []

    for index, raw in enumerate(raw_rows):
        row = parse_row(raw, index)
        if row.kind == "E":
            require(row.count <= len(row.program), f"row {index}: prefix too long")
        if row.count == 0:
            require(row.prefix is None and row.body is None, f"row {index}: base pointer")
            require(row.start == row.end, f"row {index}: nonidentity base execution")
            rows.append(row)
            continue

        require(row.prefix is not None, f"row {index}: missing prefix witness")
        prefix = rows[row.prefix]
        require(prefix.kind == row.kind, f"row {index}: prefix judgment differs")
        require(prefix.program == row.program, f"row {index}: prefix program differs")
        require(prefix.count + 1 == row.count, f"row {index}: nonconsecutive prefix")
        require(prefix.start == row.start, f"row {index}: prefix input differs")
        middle = prefix.end

        if row.kind == "E":
            instruction = row.program[row.count - 1]
            if instruction[0] != "loop":
                require(row.body is None, f"row {index}: basic instruction cites body")
                require(
                    row.end == basic_update(instruction, middle),
                    f"row {index}: incorrect basic instruction output",
                )
                rows.append(row)
                continue
            expected_kind = "R"
            expected_program = instruction[2]
            expected_count = middle[instruction[1]]  # Snapshot at loop entry.
        else:
            expected_kind = "E"
            expected_program = row.program
            expected_count = len(row.program)

        require(row.body is not None, f"row {index}: missing body witness")
        body = rows[row.body]
        require(body.kind == expected_kind, f"row {index}: wrong body judgment")
        require(body.program == expected_program, f"row {index}: body program differs")
        require(body.count == expected_count, f"row {index}: wrong body/snapshot count")
        require(body.start == middle, f"row {index}: body input differs")
        require(body.end == row.end, f"row {index}: body output differs")
        rows.append(row)

    root = rows[-1]
    require(root.kind == "E", "root is not an E judgment")
    require(root.program == program, "root program differs from claimed program")
    require(root.count == len(program), "root is not a complete program execution")
    require(root.start == initial, "root initial state differs")
    require(root.end == final, "root final state differs")
    return final


class _Builder:
    def __init__(self, max_rows: int):
        require(is_nat(max_rows) and max_rows > 0, "max_rows must be positive")
        self.max_rows = max_rows
        self.rows: list[Row] = []

    def append(self, row: Row) -> int:
        if len(self.rows) >= self.max_rows:
            raise TraceLimitExceeded(f"certificate exceeded {self.max_rows} rows")
        self.rows.append(row)
        return len(self.rows) - 1

    def evaluate(self, program: Program, start: State) -> int:
        prefix = self.append(Row("E", program, 0, start, start))
        current = start
        for position, instruction in enumerate(program, start=1):
            body = None
            if instruction[0] == "loop":
                count = current[instruction[1]]
                body = self.repeat(instruction[2], count, current)
                current = self.rows[body].end
            else:
                current = basic_update(instruction, current)
            prefix = self.append(Row("E", program, position, start, current, prefix, body))
        return prefix

    def repeat(self, program: Program, count: int, start: State) -> int:
        prefix = self.append(Row("R", program, 0, start, start))
        current = start
        for repetition in range(1, count + 1):
            body = self.evaluate(program, current)
            current = self.rows[body].end
            prefix = self.append(Row("R", program, repetition, start, current, prefix, body))
        return prefix


def build_certificate(
    program: Any, initial_state: Any, *, max_rows: int = 100_000
) -> dict[str, Any]:
    """Evaluate a small example and build its independently checkable table."""
    program = freeze_program(program)
    initial = freeze_state(initial_state)
    require(len(initial) >= register_bound(program), "initial state lacks a register")
    builder = _Builder(max_rows)
    root = builder.evaluate(program, initial)
    return {
        "format": FORMAT,
        "program": thaw_program(program),
        "initial_state": list(initial),
        "final_state": list(builder.rows[root].end),
        "rows": [row.as_json() for row in builder.rows],
    }


ADD = [("copy", 0, 1), ("loop", 2, [("inc", 0)])]
MULTIPLY = [("zero", 0), ("loop", 1, [("loop", 2, [("inc", 0)])])]
POWER_TWO = [
    ("zero", 0), ("inc", 0),
    ("loop", 1, [("copy", 2, 0), ("loop", 2, [("inc", 0)])]),
]
FACTORIAL = [
    ("zero", 0), ("inc", 0), ("zero", 2),
    ("loop", 1, [
        ("inc", 2), ("copy", 3, 0), ("zero", 0),
        ("loop", 3, [("loop", 2, [("inc", 0)])]),
    ]),
]
SNAPSHOT_INCREMENT = [("loop", 0, [("inc", 0)])]
SNAPSHOT_RESET = [("loop", 0, [("zero", 0), ("inc", 1)])]


def self_check() -> dict[str, Any]:
    """Arithmetic examples, JSON round trips, invalid traces, and resource cap."""
    reports: dict[str, dict[str, Any]] = {}
    checked = 0

    def check_case(name: str, program: Any, initial: list[int], output: int) -> None:
        nonlocal checked
        certificate = build_certificate(program, initial)
        # Check the serialized representation, rather than trusting internal objects.
        certificate = json.loads(json.dumps(certificate))
        final = verify_certificate(certificate)
        assert final[0] == output, (name, initial, final, output)
        checked += 1
        entry = reports.setdefault(name, {
            "depth": loop_depth(freeze_program(program)),
            "cases": 0,
            "max_certificate_rows": 0,
            "last_example": {},
        })
        entry["cases"] += 1
        entry["max_certificate_rows"] = max(
            entry["max_certificate_rows"], len(certificate["rows"])
        )
        entry["last_example"] = {"initial": initial, "final": list(final)}

    for left in range(5):
        for right in range(5):
            check_case("addition", ADD, [0, left, right], left + right)
            check_case("multiplication", MULTIPLY, [0, left, right], left * right)
    for value in range(7):
        check_case("power_two", POWER_TWO, [0, value, 0], 2 ** value)
    for value in range(6):
        check_case("factorial", FACTORIAL, [0, value, 0, 0], math.factorial(value))
        check_case("snapshot_increment", SNAPSHOT_INCREMENT, [value], 2 * value)
    for value in range(1, 6):
        certificate = build_certificate(SNAPSHOT_RESET, [value, 0])
        assert verify_certificate(certificate) == (0, value)
        checked += 1
    check_case("empty_program", [], [7, 8], 7)
    check_case("self_copy", [("copy", 0, 0)], [9], 9)
    assert verify_certificate(build_certificate([], [])) == ()
    checked += 1

    rejected: list[dict[str, str]] = []

    def reject(name: str, certificate: Any) -> None:
        try:
            verify_certificate(certificate)
        except InvalidCertificate as error:
            rejected.append({"mutation": name, "reason": str(error)})
        else:
            raise AssertionError(f"checker accepted mutation: {name}")

    certificate = build_certificate([("inc", 0)], [0])
    certificate["rows"][-1]["end"][0] = 8
    certificate["final_state"][0] = 8  # Keep metadata aligned: local check must fail.
    reject("altered_basic_output", certificate)

    baseline = build_certificate(ADD, [0, 2, 3])
    certificate = copy.deepcopy(baseline)
    certificate["rows"][-1]["end"][0] += 1
    certificate["final_state"][0] += 1
    reject("altered_loop_output", certificate)

    certificate = copy.deepcopy(baseline)
    certificate["rows"][1]["prefix"] = 2  # Existing row, but in the future.
    reject("future_pointer", certificate)

    certificate = copy.deepcopy(baseline)
    certificate["rows"][0]["kind"] = "UNKNOWN"
    reject("unknown_judgment_tag", certificate)

    certificate = copy.deepcopy(baseline)
    certificate["rows"][-1]["count"] += 1
    reject("prefix_outside_program", certificate)

    certificate = copy.deepcopy(baseline)
    certificate["rows"][1]["start"][0] = 1
    reject("inconsistent_prefix_input", certificate)

    certificate = build_certificate(SNAPSHOT_INCREMENT, [3])
    certificate["rows"][-1]["body"] = certificate["rows"][-1]["prefix"]
    reject("wrong_loop_body_judgment", certificate)

    certificate = copy.deepcopy(baseline)
    certificate["rows"][0]["count"] = True
    reject("boolean_in_numeric_field", certificate)

    certificate = copy.deepcopy(baseline)
    certificate["rows"][0]["program"] = [["inc", -1]]
    reject("negative_register", certificate)

    certificate = copy.deepcopy(baseline)
    certificate["rows"][-1]["program"] = [["inc", 0], ["inc", 0]]
    reject("changed_row_program", certificate)

    certificate = copy.deepcopy(baseline)
    certificate["rows"][0]["end"].append(0)
    reject("mismatched_state_lengths", certificate)

    try:
        build_certificate(SNAPSHOT_INCREMENT, [10], max_rows=3)
    except TraceLimitExceeded:
        resource_guard_checked = True
    else:
        raise AssertionError("builder ignored its row budget")

    return {
        "status": "passed",
        "format": FORMAT,
        "scope": (
            "Finite executable diagnostics of LOOP semantics and local certificate "
            "checking. Not a formal proof of the arithmetic bi-interpretation or "
            "a claim of uniform primitive recursive universal evaluation."
        ),
        "python_version": platform.python_version(),
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "valid_certificates_checked": checked,
        "families": reports,
        "snapshot_reset_cases": 5,
        "mutations_rejected": rejected,
        "resource_guard_checked": resource_guard_checked,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--results", type=Path, default=Path(__file__).with_name("loop_checks.json"),
        help="write the deterministic diagnostic report here",
    )
    arguments = parser.parse_args()
    report = self_check()
    arguments.results.parent.mkdir(parents=True, exist_ok=True)
    arguments.results.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": report["status"],
        "valid_certificates_checked": report["valid_certificates_checked"],
        "mutations_rejected": len(report["mutations_rejected"]),
        "results": str(arguments.results),
    }, indent=2))


if __name__ == "__main__":
    main()
