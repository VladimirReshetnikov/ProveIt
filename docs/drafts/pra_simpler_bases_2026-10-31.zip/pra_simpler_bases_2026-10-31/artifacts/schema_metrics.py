#!/usr/bin/env python3
"""Recompute schematic formula sizes. This is a syntax check, not a proof."""
from dataclasses import dataclass
import json


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple = ()


def node(label, *children):
    return Node(label, children)


def size(tree):
    return 1 + sum(map(size, tree.children))


def equalities(tree):
    return int(tree.label == "=") + sum(map(equalities, tree.children))


def eq(x, y):
    return node("=", x, y)


def imp(x, y):
    return node("implies", x, y)


def conj(x, y):
    return node("and", x, y)


def disj(x, y):
    return node("or", x, y)


def forall(variable, body):
    return node("forall:" + variable, body)


def neg(x):
    return imp(x, node("false"))


def iff(x, y):
    return conj(imp(x, y), imp(y, x))


zero = node("0")
n, a, x, y = (node(k) for k in ("n", "a", "x", "y"))
S = lambda t: node("S", t)
one = S(zero)
p = lambda t: node("I_counter", t, zero)
f = lambda t: node("f", t, a)
A = lambda t, u: node("I_successor", t, u)
B = lambda t, u: node("I_zero", t, u)
M = lambda t, u: node("I_predecessor", t, u)
delta = lambda t, u: A(M(t, u), M(u, t))
eta = lambda t, u: B(delta(t, u), one)
rho = lambda t: node("rho", t)


def autonomous(update, delayed=False):
    if delayed:
        rhs = update(node("D_rho", n, f(zero)))
    else:
        rhs = node("J_rho", p(n), f(one))
    return forall("a", imp(
        forall("n", eq(f(S(n)), update(f(n)))),
        conj(neg(eq(zero, one)),
             forall("n", disj(eq(n, zero), eq(f(n), rhs))))))


ordinary = forall("a", imp(
    forall("n", eq(f(S(n)), f(n))),
    forall("n", eq(f(n), f(zero)))))
positive = forall("a", imp(
    forall("n", eq(f(S(S(n))), f(S(n)))),
    forall("n", disj(eq(n, zero), eq(f(n), f(one))))))
old_er = forall("x", forall("y", iff(eq(x, y), neg(eq(eta(x, y), zero)))))
certificate = forall("x", forall("y", conj(
    neg(eq(eta(x, x), zero)), disj(eq(eta(x, y), zero), eq(x, y)))))
shift = forall("n", forall("a", eq(M(S(n), S(a)), M(n, a))))
computation_base = forall("a", eq(node("I_h", zero, a), a))
computation_step = forall("n", forall("a", eq(
    node("I_h", S(n), a), node("h", n, node("I_h", n, a)))))

formulas = {
    "computation_base": computation_base,
    "computation_step": computation_step,
    "autonomous_generic": autonomous(rho),
    "autonomous_successor": autonomous(S),
    "autonomous_predecessor": autonomous(p),
    "delayed_generic": autonomous(rho, True),
    "delayed_successor": autonomous(S, True),
    "delayed_predecessor": autonomous(p, True),
    "fixed_Shift": shift,
    "ordinary_constancy_C": ordinary,
    "previous_positive_constancy_PC": positive,
    "previous_fixed_ER_expanded": old_er,
    "constructive_certificate_EC": certificate,
}
results = {k: {"nodes": size(v), "equalities": equalities(v)}
           for k, v in formulas.items()}
assert results["ordinary_constancy_C"]["nodes"] == 19
assert results["constructive_certificate_EC"]["nodes"] == 33
assert results["previous_positive_constancy_PC"]["nodes"] == 26
assert results["previous_fixed_ER_expanded"]["nodes"] == 39
assert results["delayed_generic"]["nodes"] == 34
assert results["fixed_Shift"]["nodes"] == 11
d_nodes = size(computation_base) + size(computation_step)
assert d_nodes == 18
print(json.dumps({
    "convention": {
        "nodes": "Each variable, constant, application, connective, equality, "
                 "bottom and individual quantifier counts one.",
        "expanded": "1=S0; p(t)=I_counter(t,0); negation=implication to bottom; "
                    "biconditional=two implications and conjunction.",
        "indices": "Function-description indices count as part of a symbol.",
        "metavariables": "Schematic f/rho bodies are not charged, only displayed arguments.",
        "warning": "This is not expanded program size or a shortestness lower bound. "
                   "Two update tags define two infinite families, not two sentences."
    },
    "formulas": results,
    "totals": {
        "D_plus_delayed_generic": d_nodes + size(autonomous(rho, True)),
        "D_plus_AU_successor_plus_Shift": d_nodes + size(autonomous(S)) + size(shift),
        "D_plus_delayed_successor_plus_Shift":
            d_nodes + size(autonomous(S, True)) + size(shift),
        "previous_D_PC_ER": d_nodes + size(positive) + size(old_er),
        "new_D_C_EC": d_nodes + size(ordinary) + size(certificate),
    }
}, indent=2))
