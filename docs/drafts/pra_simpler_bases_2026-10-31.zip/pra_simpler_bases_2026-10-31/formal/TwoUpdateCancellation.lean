/-
An intuitionistic semantic certificate for a restricted PRA proof kernel.

The carrier below is arbitrary.  In particular, no induction principle for
that carrier is used.  `uniqueSucc` is a semantic interface for the permitted
one-parameter successor-uniqueness schema.  Its uses below instantiate actual
binary functions displayed in the proof.  This file does not formalize finite
term syntax, object-language derivability, or the final bi-interpretation.

`shift` is the fixed subtraction equation.  There is no predecessor-uniqueness
or constancy assumption.  The parity and zero-test equations are computation
equations available from the initialized-iterator grammar.
-/

namespace TwoUpdateCancellation

universe u

structure Core (α : Type u) where
  zero : α
  succ : α → α
  pred : α → α
  add : α → α → α
  monus : α → α → α
  zeroTest : α → α
  parity : α → α
  separation : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  coverage : ∀ x, x = zero ∨ x = succ (pred x)
  add_base : ∀ a, add zero a = a
  add_step : ∀ n a, add (succ n) a = succ (add n a)
  monus_base : ∀ a, monus zero a = a
  monus_step : ∀ n a, monus (succ n) a = pred (monus n a)
  shift : ∀ n a, monus (succ n) (succ a) = monus n a
  zeroTest_zero : zeroTest zero = succ zero
  zeroTest_succ : ∀ n, zeroTest (succ n) = zero
  parity_zero : parity zero = zero
  parity_succ : ∀ n, parity (succ n) = zeroTest (parity n)
  uniqueSucc : ∀ (f : α → α → α) (a : α),
    (∀ n, f (succ n) a = succ (f n a)) →
    ∀ n, f n a = add n (f zero a)

namespace Core

variable {α : Type u} (c : Core α)

abbrev one : α := c.succ c.zero

theorem one_ne_zero : c.one ≠ c.zero := by
  intro h
  exact c.separation h.symm

theorem succ_ne_zero (x : α) : c.succ x ≠ c.zero := by
  intro h
  have hx : x = c.zero := by
    calc
      x = c.pred (c.succ x) := (c.pred_succ x).symm
      _ = c.pred c.zero := congrArg c.pred h
      _ = c.zero := c.pred_zero
  apply c.one_ne_zero
  simpa only [hx] using h

theorem zeroTest_bits (x : α) :
    c.zeroTest x = c.zero ∨ c.zeroTest x = c.one := by
  rcases c.coverage x with hx | hx
  · right
    simpa only [hx] using c.zeroTest_zero
  · left
    calc
      c.zeroTest x = c.zeroTest (c.succ (c.pred x)) := congrArg c.zeroTest hx
      _ = c.zero := c.zeroTest_succ (c.pred x)

theorem zeroTest_one_iff (x : α) :
    c.zeroTest x = c.one ↔ x = c.zero := by
  constructor
  · intro h
    rcases c.coverage x with hx | hx
    · exact hx
    · have hz : c.zeroTest x = c.zero := by
        calc
          c.zeroTest x = c.zeroTest (c.succ (c.pred x)) :=
            congrArg c.zeroTest hx
          _ = c.zero := c.zeroTest_succ (c.pred x)
      exact False.elim (c.separation (hz.symm.trans h))
  · intro h
    simpa only [h] using c.zeroTest_zero

theorem parity_bits (x : α) :
    c.parity x = c.zero ∨ c.parity x = c.one := by
  rcases c.coverage x with hx | hx
  · left
    simpa only [hx] using c.parity_zero
  · rw [hx, c.parity_succ]
    exact c.zeroTest_bits (c.parity (c.pred x))

theorem succ_no_fixed_point (x : α) : c.succ x ≠ x := by
  intro h
  have hp : c.zeroTest (c.parity x) = c.parity x := by
    calc
      c.zeroTest (c.parity x) = c.parity (c.succ x) :=
        (c.parity_succ x).symm
      _ = c.parity x := congrArg c.parity h
  rcases c.parity_bits x with hx | hx
  · rw [hx, c.zeroTest_zero] at hp
    exact c.one_ne_zero hp
  · rw [hx, c.zeroTest_succ] at hp
    exact c.separation hp

theorem add_zero (n : α) : c.add n c.zero = n := by
  have h := c.uniqueSucc (fun n _ => n) c.zero (fun _ => rfl) n
  exact h.symm

theorem add_succ_seed (n a : α) :
    c.add n (c.succ a) = c.succ (c.add n a) := by
  have h := c.uniqueSucc (fun n a => c.succ (c.add n a)) a
    (by
      intro n
      dsimp only
      rw [c.add_step]) n
  simpa only [c.add_base] using h.symm

theorem add_one (n : α) : c.add n c.one = c.succ n := by
  calc
    c.add n c.one = c.succ (c.add n c.zero) :=
      c.add_succ_seed n c.zero
    _ = c.succ n := congrArg c.succ (c.add_zero n)

theorem add_comm (n a : α) : c.add n a = c.add a n := by
  have h := c.uniqueSucc (fun k b => c.add b k) n
    (by
      intro k
      exact c.add_succ_seed n k) a
  simpa only [c.add_zero] using h

/- This comparison uses only the two proved Boolean alternatives, not an
   assumed decision procedure for arbitrary native equalities. -/
theorem add_cancel_bits (n x y : α)
    (hx : x = c.zero ∨ x = c.one)
    (hy : y = c.zero ∨ y = c.one)
    (h : c.add n x = c.add n y) : x = y := by
  rcases hx with hx | hx
  · rcases hy with hy | hy
    · exact hx.trans hy.symm
    · rw [hx, hy, c.add_zero, c.add_one] at h
      exact False.elim (c.succ_no_fixed_point n h.symm)
  · rcases hy with hy | hy
    · rw [hx, hy, c.add_one, c.add_zero] at h
      exact False.elim (c.succ_no_fixed_point n h)
    · exact hx.trans hy.symm

theorem bit_constancy (b : α → α → α) (a : α)
    (bits : ∀ n, b n a = c.zero ∨ b n a = c.one)
    (stationary : ∀ n, b (c.succ n) a = b n a)
    (n : α) : b n a = b c.zero a := by
  have h := c.uniqueSucc (fun n a => c.add n (b n a)) a
    (by
      intro k
      dsimp only
      rw [stationary k, c.add_step]) n
  have hramp : c.add n (b n a) = c.add n (b c.zero a) := by
    simpa only [c.add_base] using h
  exact c.add_cancel_bits n (b n a) (b c.zero a)
    (bits n) (bits c.zero) hramp

/- `add k x` denotes x+k: the iterator counter is the first argument. -/
def residual (x k : α) : α := c.monus k (c.add k x)

theorem residual_base (x : α) : c.residual x c.zero = x := by
  unfold residual
  rw [c.add_base, c.monus_base]

theorem residual_stationary (x k : α) :
    c.residual x (c.succ k) = c.residual x k := by
  unfold residual
  rw [c.add_step, c.shift]

theorem residual_zeroTest (x k : α) :
    c.zeroTest (c.residual x k) = c.zeroTest x := by
  have h := c.bit_constancy (fun n a => c.zeroTest (c.residual a n)) x
    (fun n => c.zeroTest_bits (c.residual x n))
    (by
      intro n
      dsimp only
      rw [c.residual_stationary]) k
  simpa only [c.residual_base] using h

theorem residual_zero_iff (x k : α) :
    c.residual x k = c.zero ↔ x = c.zero := by
  constructor
  · intro h
    apply (c.zeroTest_one_iff x).mp
    calc
      c.zeroTest x = c.zeroTest (c.residual x k) :=
        (c.residual_zeroTest x k).symm
      _ = c.zeroTest c.zero := congrArg c.zeroTest h
      _ = c.one := c.zeroTest_zero
  · intro h
    apply (c.zeroTest_one_iff (c.residual x k)).mp
    calc
      c.zeroTest (c.residual x k) = c.zeroTest x := c.residual_zeroTest x k
      _ = c.zeroTest c.zero := congrArg c.zeroTest h
      _ = c.one := c.zeroTest_zero

theorem pred_residual_step (x k : α) :
    c.pred (c.residual (c.succ x) k) = c.residual x k := by
  calc
    c.pred (c.residual (c.succ x) k) =
        c.pred (c.monus k (c.succ (c.add k x))) := by
      rw [residual, c.add_succ_seed]
    _ = c.monus (c.succ k) (c.succ (c.add k x)) :=
      (c.monus_step k (c.succ (c.add k x))).symm
    _ = c.monus k (c.add k x) := c.shift k (c.add k x)
    _ = c.residual x k := rfl

theorem residual_step (x k : α) :
    c.residual (c.succ x) k = c.succ (c.residual x k) := by
  have hn : c.residual (c.succ x) k ≠ c.zero := by
    intro h
    exact c.succ_ne_zero x ((c.residual_zero_iff (c.succ x) k).mp h)
  rcases c.coverage (c.residual (c.succ x) k) with hz | hs
  · exact False.elim (hn hz)
  · exact hs.trans (congrArg c.succ (c.pred_residual_step x k))

theorem subtraction_cancellation (x k : α) :
    c.monus k (c.add k x) = x := by
  have h := c.uniqueSucc (fun n a => c.residual n a) k
    (fun n => c.residual_step n k) x
  have hz : c.residual c.zero k = c.zero :=
    (c.residual_zero_iff c.zero k).mpr rfl
  simpa only [hz, c.add_zero] using h

theorem native_addition_cancellation (x y k : α)
    (h : c.add k x = c.add k y) : x = y := by
  calc
    x = c.monus k (c.add k x) := (c.subtraction_cancellation x k).symm
    _ = c.monus k (c.add k y) := congrArg (c.monus k) h
    _ = y := c.subtraction_cancellation y k

theorem arbitrary_constancy (f : α → α → α) (a : α)
    (stationary : ∀ n, f (c.succ n) a = f n a)
    (n : α) : f n a = f c.zero a := by
  have h := c.uniqueSucc (fun n a => c.add n (f n a)) a
    (by
      intro k
      dsimp only
      rw [stationary k, c.add_step]) n
  have hramp : c.add n (f n a) = c.add n (f c.zero a) := by
    simpa only [c.add_base] using h
  exact c.native_addition_cancellation (f n a) (f c.zero a) n hramp

#print axioms succ_no_fixed_point
#print axioms bit_constancy
#print axioms subtraction_cancellation
#print axioms native_addition_cancellation
#print axioms arbitrary_constancy

end Core

end TwoUpdateCancellation
