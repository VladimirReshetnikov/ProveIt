"""Independent, untrusted construction and replay of derived-rule certificates.

This script does not modify the four checker implementations. It emits ordinary
finite proof trees, then asks the rule and schema kernels to check them. The
proofs exercise genuine-bottom explosion, a numerical zero-case continuation,
and all three rules of the encoded disjunction, including quantified formulas.
"""

from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys


HERE = Path(__file__).resolve().parent
KERNELS = HERE.parent / "kernel_work"


def load(name):
    spec = importlib.util.spec_from_file_location(name, KERNELS / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


rule = load("candidate_rule")
schema = load("candidate_schema")

ZERO = ("0",)
ONE = ("S", ZERO)
F = ("F",)


def V(n):
    return ("v", n)


def S(t):
    return ("S", t)


def Eq(s, t):
    return ("=", s, t)


def And(a, b):
    return ("&", a, b)


def Imp(a, b):
    return (">", a, b)


def All(n, a):
    return ("all", n, a)


def Ex(n, a):
    return ("ex", n, a)


def C(n, a, b):
    return ("R", V(2), (n, a, b))


def pred(n):
    return ("R", V(1), (n, ZERO))


DELTA = Eq(ZERO, ONE)


def insert_context(p, cutoff, amount=1):
    """Insert assumptions before local discharged assumptions in a proof.

    All current uses insert formulas whose variables do not invalidate any
    internal eigenvariable. This changes certificate indices, not inference
    rules; the checker still verifies every resulting scope condition.
    """
    tag = p[0]
    if tag == "hyp":
        return ("hyp", p[1] + amount if p[1] >= cutoff else p[1])
    if tag in ("refl", "ax", "rec"):
        return p
    if tag == "eq":
        return (tag, insert_context(p[1], cutoff, amount), p[2], p[3],
                insert_context(p[4], cutoff, amount))
    if tag in ("&I", ">E"):
        return (tag, insert_context(p[1], cutoff, amount), insert_context(p[2], cutoff, amount))
    if tag in ("&L", "&R"):
        return (tag, insert_context(p[1], cutoff, amount))
    if tag in (">I", "allI"):
        return (tag, p[1], insert_context(p[2], cutoff, amount))
    if tag == "allE":
        return (tag, insert_context(p[1], cutoff, amount), p[2])
    if tag == "exI":
        return (tag, p[1], p[2], p[3], insert_context(p[4], cutoff, amount))
    if tag == "exE":
        return (tag, insert_context(p[1], cutoff, amount), p[2],
                insert_context(p[3], cutoff, amount))
    if tag == "sc":
        return (*p[:5], *(insert_context(q, cutoff, amount) for q in p[5:]))
    raise ValueError(f"unexpected proof tag {tag}")


def fresh(*formulas, extra_terms=()):
    used = set().union(*(rule.formula(a) for a in formulas))
    used |= set().union(*(rule.term(t) for t in extra_terms))
    # Our certificates use small names. Taking a fresh large name also keeps
    # term-template variables clearly separate from descriptor-local slots.
    n = 1000
    while n in used:
        n += 1
    return n


def sym(p, ctx):
    e = rule.infer(p, ctx)
    if e[0] != "=":
        raise ValueError("symmetry requires equality")
    z = fresh(e, *ctx)
    return ("eq", p, z, Eq(V(z), e[1]), ("refl", e[1]))


def trans(p, q, ctx):
    e, d = rule.infer(p, ctx), rule.infer(q, ctx)
    if e[0] != "=" or d[0] != "=" or e[2] != d[1]:
        raise ValueError("transitivity endpoints do not match")
    z = fresh(e, d, *ctx)
    return ("eq", q, z, Eq(e[1], V(z)), p)


def congr(p, f, ctx):
    e = rule.infer(p, ctx)
    if e[0] != "=":
        raise ValueError("congruence requires equality")
    z = fresh(e, *ctx, extra_terms=(f(e[1]), f(e[2])))
    return ("eq", p, z, Eq(f(e[1]), f(V(z))), ("refl", f(e[1])))


def collapse_equation(s, t, p_delta, ctx):
    """From 0=1 derive arbitrary s=t using the one generated selector."""
    base = ("rec", C(ZERO, s, t))
    step = ("rec", C(ONE, s, t))
    z = fresh(*ctx, extra_terms=(s, t))
    transported = ("eq", p_delta, z, Eq(C(V(z), s, t), s), base)
    return trans(sym(transported, ctx), step, ctx)


def explosion(a, p_false, ctx):
    """Expand admissible falsity elimination by structural recursion."""
    tag = a[0]
    if tag == "F":
        return p_false
    if tag == "=":
        return collapse_equation(a[1], a[2], (">E", ("ax", 1), p_false), ctx)
    if tag == "&":
        return ("&I", explosion(a[1], p_false, ctx), explosion(a[2], p_false, ctx))
    if tag == ">":
        return (">I", a[1], explosion(a[2], insert_context(p_false, len(ctx)), ctx + (a[1],)))
    if tag == "all":
        if a[1] in rule.context_variables(ctx):
            raise ValueError("freshen the requested universal binder first")
        return ("allI", a[1], explosion(a[2], p_false, ctx))
    if tag == "ex":
        instance = rule.substitute(a[2], a[1], ZERO)
        return ("exI", a[1], a[2], ZERO, explosion(instance, p_false, ctx))
    raise ValueError("unexpected formula constructor")


def successor_clash(u, p_su_zero, ctx):
    """From Su=0 derive genuine bottom, without induction or predecessor."""
    base = ("rec", C(ZERO, ZERO, ONE))
    step = ("rec", C(S(u), ZERO, ONE))
    z = fresh(*ctx, extra_terms=(u,))
    transported = ("eq", p_su_zero, z, Eq(C(V(z), ZERO, ONE), ONE), step)
    delta = trans(sym(base, ctx), transported, ctx)
    return (">E", ("ax", 0), delta)


def coverage_equation(t):
    return Eq(S(pred(t)), t)


def coverage_successor(u, ctx):
    """A direct computation proof of S(p(Su))=Su."""
    return congr(("rec", pred(S(u))), S, ctx)


def zero_split(t, a, p_zero_imp, p_nonzero_imp, ctx):
    """Derived zero-case elimination from the four-premise arithmetic rule.

    The two supplied proofs conclude (t=0)->a and ((t=0)->F)->a.
    """
    x = fresh(a, *ctx, extra_terms=(t,))
    e = coverage_equation(V(x))
    zero = Eq(t, ZERO)
    ec = coverage_equation(t)
    base = coverage_successor(ZERO, ctx)
    step = coverage_successor(V(x), ctx + (e,))
    p_zero_case = (">E", insert_context(p_zero_imp, len(ctx)), ("hyp", len(ctx)))

    # Under the predecessor equation, a hypothetical t=0 gives Sp(t)=0.
    inner = ctx + (ec, zero)
    sp_zero = trans(("hyp", len(ctx)), ("hyp", len(ctx) + 1), inner)
    p_false = successor_clash(pred(t), sp_zero, inner)
    p_nonzero = (">I", zero, p_false)
    p_equation_case = (">E", insert_context(p_nonzero_imp, len(ctx)), p_nonzero)
    return ("sc", x, e, t, a, base, step, p_zero_case, p_equation_case)


def disj(a, b, name=400):
    if name in rule.formula(a) | rule.formula(b):
        raise ValueError("disjunction tag variable is not fresh")
    is_zero = Eq(V(name), ZERO)
    return Ex(name, And(Imp(is_zero, a), Imp(Imp(is_zero, F), b)))


def disj_left(a, b, p_a, ctx, name=400):
    d = disj(a, b, name)
    zz = Eq(ZERO, ZERO)
    nz = Imp(zz, F)
    left = (">I", zz, insert_context(p_a, len(ctx)))
    p_false = (">E", ("hyp", len(ctx)), ("refl", ZERO))
    right = (">I", nz, explosion(b, p_false, ctx + (nz,)))
    return ("exI", name, d[2], ZERO, ("&I", left, right))


def disj_right(a, b, p_b, ctx, name=400):
    d = disj(a, b, name)
    oz = Eq(ONE, ZERO)
    no = Imp(oz, F)
    p_false = successor_clash(ZERO, ("hyp", len(ctx)), ctx + (oz,))
    left = (">I", oz, explosion(a, p_false, ctx + (oz,)))
    right = (">I", no, insert_context(p_b, len(ctx)))
    return ("exI", name, d[2], ONE, ("&I", left, right))


def disj_eliminate(a, b, c):
    """Produce D(a,b)->(a->c)->(b->c)->c as a closed proof."""
    d = disj(a, b)
    ac, bc = Imp(a, c), Imp(b, c)
    ctx = (d, ac, bc)
    y = fresh(*ctx)
    yy = Eq(V(y), ZERO)
    ny = Imp(yy, F)
    witness_body = rule.substitute(d[2], d[1], V(y))
    inner = ctx + (witness_body,)
    first = ("&L", ("hyp", len(ctx)))
    second = ("&R", ("hyp", len(ctx)))
    pa = (">E", first, ("hyp", len(inner)))
    pb = (">E", second, ("hyp", len(inner)))
    p0c = (">I", yy, (">E", ("hyp", 1), pa))
    pnc = (">I", ny, (">E", ("hyp", 2), pb))
    conclusion = zero_split(V(y), c, p0c, pnc, inner)
    eliminated = ("exE", ("hyp", 0), y, conclusion)
    return (">I", d, (">I", ac, (">I", bc, eliminated)))


def to_schema(p):
    """Untrusted expansion of rule certificates into schema certificates."""
    tag = p[0]
    if tag in ("hyp", "refl", "ax", "rec"):
        return p
    if tag == "eq":
        return (tag, to_schema(p[1]), p[2], p[3], to_schema(p[4]))
    if tag in ("&I", ">E"):
        return (tag, to_schema(p[1]), to_schema(p[2]))
    if tag in ("&L", "&R"):
        return (tag, to_schema(p[1]))
    if tag in (">I", "allI"):
        return (tag, p[1], to_schema(p[2]))
    if tag == "allE":
        return (tag, to_schema(p[1]), p[2])
    if tag == "exI":
        return (tag, p[1], p[2], p[3], to_schema(p[4]))
    if tag == "exE":
        return (tag, to_schema(p[1]), p[2], to_schema(p[3]))
    if tag == "sc":
        _, x, e, t, a, base, step, zero_case, equation_case = p
        result = ("sc", x, e, t, a)
        proofs = (
            to_schema(base),
            ("allI", x, (">I", e, to_schema(step))),
            (">I", Eq(t, ZERO), to_schema(zero_case)),
            (">I", rule.substitute(e, x, t), to_schema(equation_case)),
        )
        for q in proofs:
            result = (">E", result, q)
        return result
    raise ValueError(f"unexpected proof tag {tag}")


def nodes(value):
    if type(value) is tuple:
        return 1 + sum(nodes(x) for x in value)
    return 1


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    out = HERE / "certificates"
    out.mkdir(exist_ok=True)
    results = []

    def cli_replay(implementation, path, expected):
        completed = subprocess.run(
            [sys.executable, "-O", str(KERNELS / f"{implementation}.py")],
            input=path.read_text(), text=True, capture_output=True,
        )
        reply = json.loads(completed.stdout)
        if completed.returncode != (0 if expected else 1) or reply.get("ok") is not expected:
            raise RuntimeError(f"unexpected optimized CLI result: {implementation}, {path.name}")
        return {"python_optimized": True, "returncode": completed.returncode,
                "accepted": reply["ok"]}

    def positive(name, proof, goal, context=()):
        checks = []
        for implementation, module, certificate in (
            ("candidate_rule", rule, proof),
            ("candidate_schema", schema, to_schema(proof)),
        ):
            module.check(certificate, goal, context)
            filename = f"{name}.{implementation}.json"
            path = out / filename
            path.write_text(json.dumps({"proof": certificate, "goal": goal,
                                        "context": context}, indent=2) + "\n")
            checks.append({"kernel": implementation, "accepted": True,
                           "certificate": f"certificates/{filename}",
                           "sha256": digest(path), "tree_nodes": nodes(certificate),
                           "cli": cli_replay(implementation, path, True)})
        results.append({"test": name, "expected": "accept", "checks": checks})

    def negative(name, proof, goal, context=(), modules=(rule, schema)):
        checks = []
        filename = f"{name}.rejected.json"
        path = out / filename
        path.write_text(json.dumps({"proof": proof, "goal": goal,
                                    "context": context}, indent=2) + "\n")
        for module in modules:
            try:
                module.check(proof, goal, context)
            except module.Invalid as exc:
                checks.append({"kernel": module.__name__, "rejected": True,
                               "reason": str(exc),
                               "certificate": f"certificates/{filename}",
                               "sha256": digest(path),
                               "cli": cli_replay(module.__name__, path, False)})
            else:
                raise RuntimeError(f"UNSOUND ACCEPTANCE: {name}, {module.__name__}")
        results.append({"test": name, "expected": "reject", "checks": checks})

    # Nontrivial explosion: all retained constructors, including both
    # quantifiers, occur in the requested conclusion.
    quantified = All(10, Ex(11, And(Eq(V(10), V(11)),
                                    Imp(Eq(V(10), ZERO), Eq(V(11), ONE)))))
    pe = explosion(quantified, ("hyp", 0), (F,))
    positive("explosion_quantified", (">I", F, pe), Imp(F, quantified))

    # The numerical split produces a genuinely arbitrary, quantified
    # continuation; it is not merely equality induction.
    t = V(0)
    conclusion = All(20, Imp(Eq(V(20), t), F))
    zero, nonzero = Eq(t, ZERO), Imp(Eq(t, ZERO), F)
    zc, nc = Imp(zero, conclusion), Imp(nonzero, conclusion)
    ps = zero_split(t, conclusion, ("hyp", 0), ("hyp", 1), (zc, nc))
    positive("zero_case_quantified", (">I", zc, (">I", nc, ps)),
             Imp(zc, Imp(nc, conclusion)))

    # Both encoded disjunction introductions and elimination with quantified
    # formulas. No primitive disjunction or false-elimination proof tag is
    # used in either candidate certificate.
    a = All(30, Eq(V(30), ZERO))
    b = Ex(31, Eq(V(31), ONE))
    c = All(32, Ex(33, Eq(V(32), V(33))))
    d = disj(a, b)
    positive("encoded_or_left", (">I", a, disj_left(a, b, ("hyp", 0), (a,))), Imp(a, d))
    positive("encoded_or_right", (">I", b, disj_right(a, b, ("hyp", 0), (b,))), Imp(b, d))
    positive("encoded_or_elimination", disj_eliminate(a, b, c),
             Imp(d, Imp(Imp(a, c), Imp(Imp(b, c), c))))

    # Frozen descriptor variables are not active variables. This is a
    # positive scope boundary, not a malformed-input test.
    closed_selector = C(ZERO, ZERO, ONE)
    positive("frozen_descriptor_scope", ("allI", 2, ("refl", closed_selector)),
             All(2, Eq(closed_selector, closed_selector)))

    negative("universal_eigenvariable_escape", ("allI", 0, ("hyp", 0)),
             All(0, Eq(V(0), ZERO)), (Eq(V(0), ZERO),))
    existential = Ex(0, Eq(V(0), ZERO))
    negative("existential_eigenvariable_escape", ("exE", ("hyp", 0), 1, ("hyp", 1)),
             Eq(V(1), ZERO), (existential,))
    negative("existential_eigenvariable_in_context", ("exE", ("hyp", 0), 1, ("refl", ZERO)),
             Eq(ZERO, ZERO), (existential, Eq(V(1), ZERO)))

    quantified_hypothesis = All(0, All(1, Eq(V(0), V(1))))
    negative("universal_substitution_capture", ("allE", ("hyp", 0), V(1)),
             All(1, Eq(V(1), V(1))), (quantified_hypothesis,))
    negative("equality_substitution_capture",
             ("eq", ("hyp", 0), 2, All(1, Eq(V(2), V(1))), ("hyp", 1)),
             All(1, Eq(V(1), V(1))),
             (Eq(V(0), V(1)), All(1, Eq(V(0), V(1)))))
    negative("existential_substitution_capture",
             ("exI", 0, All(1, Eq(V(0), V(1))), V(1), ("allI", 1, ("refl", V(1)))),
             Ex(0, All(1, Eq(V(0), V(1)))))

    # The schema kernel needs no side condition forbidding its bound step
    # variable in t or A: those occurrences lie OUTSIDE that binder. These
    # three freshness negatives are therefore specific to the inference-rule
    # interface and deliberately are not applied to the schema interface.
    for name, target, continuation, ctx in (
        ("induction_variable_in_target", V(0), Eq(ZERO, ZERO), ()),
        ("induction_variable_in_conclusion", ZERO, Eq(V(0), V(0)), ()),
        ("induction_variable_in_context", ZERO, Eq(ZERO, ZERO), (Eq(V(0), ZERO),)),
    ):
        e = coverage_equation(V(0))
        proof = ("sc", 0, e, target, continuation,
                 coverage_successor(ZERO, ctx),
                 coverage_successor(V(0), ctx + (e,)),
                 ("refl", continuation[1]), ("refl", continuation[1]))
        negative(name, proof, continuation, ctx, modules=(rule,))

    bad_e = Imp(Eq(V(0), ZERO), Eq(V(0), ZERO))
    negative("non_equational_induction_template_schema", ("sc", 0, bad_e, ZERO, F),
             F, modules=(schema,))
    negative("non_equational_induction_template_rule",
             ("sc", 0, bad_e, ZERO, F, ("refl", ZERO), ("refl", ZERO),
              ("hyp", 0), ("hyp", 0)), F, modules=(rule,))
    negative("descriptor_out_of_scope", ("refl", ("R", V(3), (ZERO, ZERO))),
             Eq(ZERO, ZERO))
    negative("descriptor_negative_slot", ("refl", ("R", V(-1), (ZERO, ZERO))),
             Eq(ZERO, ZERO))
    negative("boolean_variable_index", ("refl", V(True)), Eq(ZERO, ZERO))
    negative("unknown_fixed_axiom", ("ax", 2), F)
    negative("wrong_computation_result", ("rec", C(ONE, ZERO, ONE)),
             Eq(C(ONE, ZERO, ONE), ZERO))
    negative("false_from_reflexivity", ("refl", ZERO), F)

    manifest = {
        "purpose": "Independent replay of finite derivations and soundness-boundary negatives",
        "not_a_full_formalization": True,
        "kernel_hashes": {name: digest(KERNELS / f"{name}.py") for name in
                          ("candidate_rule", "candidate_schema")},
        "positive_cases": sum(r["expected"] == "accept" for r in results),
        "negative_cases": sum(r["expected"] == "reject" for r in results),
        "individual_kernel_checks": sum(len(r["checks"]) for r in results),
        "optimized_cli_checks": sum(len(r["checks"]) for r in results),
        "results": results,
    }
    (HERE / "replay_results.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({k: manifest[k] for k in
                      ("positive_cases", "negative_cases", "individual_kernel_checks", "optimized_cli_checks")}, indent=2))


if __name__ == "__main__":
    main()
