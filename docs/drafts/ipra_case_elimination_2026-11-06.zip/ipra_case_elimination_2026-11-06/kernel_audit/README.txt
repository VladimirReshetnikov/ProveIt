INDEPENDENT DERIVED-RULE REPLAY
==============================

Run from the package root:

    python3 kernel_audit/replay_derived_rules.py

The script reads candidate_rule.py and candidate_schema.py from the sibling
kernel_work directory. It does not modify either checker. It independently
constructs ordinary proof trees, replays them through both Python APIs, writes
the exact JSON certificates, and replays each JSON file through the matching
checker CLI under Python's -O mode.

Accepted derivation families:

1. Genuine-bottom explosion into a formula containing conjunction,
   implication, universal quantification, and existential quantification.
2. Numerical zero-case elimination with a quantified arbitrary conclusion.
3. Left introduction of the existentially encoded disjunction.
4. Right introduction of that encoded disjunction.
5. Elimination of that encoded disjunction, using quantified formulas.
6. Universal introduction across a frozen recursor descriptor: its local
   variable slots are correctly excluded from active free variables.

The first five families are derived proofs. No primitive falsity-elimination
or disjunction rule is used. Rule certificates use the four-premise
arithmetic inference; schema certificates expand that inference into four
modus-ponens steps and the ordinary logical rules.

Rejected boundaries include eigenvariable escape, capture in each
substitution interface, non-equational induction, invalid descriptor slots,
a Boolean masquerading as a natural variable index, an unknown axiom,
an incorrect computation equation, and a requested false conclusion from
reflexivity. The induction-eigenvariable checks belong only to the rule
interface: in a schema instance its universally bound step variable may
also appear free OUTSIDE that binder, and must not be incorrectly forbidden.

Results: 6 positive families and 17 negative cases; 41 direct API checks
and 41 corresponding optimized JSON CLI checks. Every expected acceptance
and rejection passed. See replay_results.json for exact input hashes,
checker hashes, individual outcomes, and rejected-input reasons.

Scope: these are actual finite derivations plus targeted boundary checks.
They are not a Lean/Rocq formalization of iPRA, a verified implementation
of the checker, an exhaustive test of all inputs, or a proof of minimum
possible checker size. The mathematical equivalence proof is separate.
