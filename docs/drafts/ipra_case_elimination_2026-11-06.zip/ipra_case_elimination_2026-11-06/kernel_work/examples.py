"""Create and replay a small set of positive and negative certificates.

This is an untrusted certificate producer, not part of any checker.
The independent audit supplies the larger arithmetic/logic derivations.
"""
from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parent
ZERO, ONE, BOTTOM = ('0',), ('S', ('0',)), ('F',)
V = lambda i: ('v', i)
Q = lambda n, a: ('R', V(1), (n, a))


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write(name, proof, goal, context=()):
    data = {'proof': proof, 'goal': goal, 'context': context}
    (ROOT / 'examples' / (name + '.json')).write_text(json.dumps(data, indent=2) + '\n')
    return data


def main():
    (ROOT / 'examples').mkdir(exist_ok=True)
    results = []
    all_files = ['baseline_rule', 'baseline_schema', 'candidate_rule', 'candidate_schema']
    kernels = {name: load(name) for name in all_files}

    universal = write('universal_reflexivity', ('allI', 0, ('refl', V(0))),
                      ('all', 0, ('=', V(0), V(0))))
    h = ('S', V(0))
    r = ('R', h, (('S', V(10)), V(11), V(12)))
    recursion = write('recursor_step', ('rec', r),
                      ('=', r, ('S', ('R', h, (V(10), V(11), V(12))))))
    for name, kernel in kernels.items():
        for case_name, case in [('universal_reflexivity', universal), ('recursor_step', recursion)]:
            kernel.check(case['proof'], case['goal'], case['context'])
            results.append({'kernel': name, 'case': case_name, 'accepted': True})

    # Derive a=0 from genuine falsity without a primitive bottom-elimination rule.
    # p1: Q(1,a)=a, using 0=1 from the bridge and Q(0,a)=a.
    a = V(10)
    p01 = ('>E', ('ax', 1), ('hyp', 0))
    p1 = ('eq', p01, 17, ('=', Q(V(17), a), a), ('rec', Q(ZERO, a)))
    collapse = ('eq', p1, 18, ('=', V(18), ZERO), ('rec', Q(ONE, a)))
    explosion = write('candidate_arithmetic_collapse',
                      ('>I', BOTTOM, ('allI', 10, collapse)),
                      ('>', BOTTOM, ('all', 10, ('=', a, ZERO))))
    for name in ['candidate_rule', 'candidate_schema']:
        kernels[name].check(explosion['proof'], explosion['goal'])
        results.append({'kernel': name, 'case': 'candidate_arithmetic_collapse', 'accepted': True})

    bad_generalization = write('invalid_eigenvariable', ('allI', 0, ('hyp', 0)),
                               ('all', 0, ('=', V(0), ZERO)), (('=', V(0), ZERO),))
    bound_formula = ('all', 0, ('all', 1, ('=', V(0), V(1))))
    capture = write('invalid_capture', ('allE', ('hyp', 0), V(1)),
                    ('all', 1, ('=', V(1), V(1))), (bound_formula,))
    malformed = write('invalid_descriptor', ('refl', ('R', V(2), (ZERO, ZERO))),
                      ('=', ZERO, ZERO))
    for name, kernel in kernels.items():
        for case_name, case in [('invalid_eigenvariable', bad_generalization),
                                ('invalid_capture', capture), ('invalid_descriptor', malformed)]:
            try:
                kernel.check(case['proof'], case['goal'], case['context'])
            except kernel.Invalid:
                results.append({'kernel': name, 'case': case_name, 'accepted': False})
            else:
                raise RuntimeError(f'{name} accepted {case_name}')

    (ROOT / 'example_results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({'accepted_positive_cases': sum(row['accepted'] for row in results),
                      'rejected_negative_cases': sum(not row['accepted'] for row in results)}))


if __name__ == '__main__':
    main()
