FOUR COMPLETE PROOF CHECKERS: CONTROLLED IMPLEMENTATION COMPARISON
================================================================

FILES AND USE

candidate_schema.py is the smallest of these four implementations. It is
standalone: the generated checkers import no arithmetic or logical engine.
They require Python 3.10 or newer because they use structural pattern matching.
The measured run used Python 3.12.14. The JSON adapter uses only the Python
standard library modules json and sys.

  python3 candidate_schema.py < examples/candidate_arithmetic_collapse.json
  python3 -O candidate_schema.py < examples/invalid_capture.json

Exit status 0 means acceptance; status 1 means rejection. Each writes one
JSON object with ok and either the exact conclusion or an error message.
The first example proves BOTTOM -> forall x (x=0) using arithmetic equations
and the candidate's bridge axiom. The second is deliberately invalid.

The public Python interface is:

  infer(proof, context=())           -> conclusion, or raises Invalid
  check(proof, goal, context=())     -> True, or raises Invalid

All public Python objects use immutable tuples. In JSON, use arrays instead.
The JSON input is an object with required field proof and optional fields
context and goal. context defaults to an empty array. If goal is supplied,
the checker verifies exact syntactic equality with the inferred conclusion.
Unknown top-level fields, duplicate JSON fields, and malformed syntax are
rejected. No Python assert participates in acceptance; -O changes nothing.

  python3 build_kernels.py

regenerates all four standalone files from one common template and writes
metrics.json. The builder is NOT required to use the resulting checkers.

  python3 examples.py

creates the basic positive/negative JSON certificates and replays them through
the public APIs. It writes example_results.json. It is an untrusted certificate
producer, not part of a checker. Mathematical proofs and the independent audit
are separate artifacts; these small examples are not a formal proof of the
interpretation metatheorem.

THE FOUR VARIANTS

baseline_rule.py:    full intuitionistic logic, Sep, recursion, rooted rule.
baseline_schema.py:  same theory, rooted axiom schema instead of rooted rule.
candidate_rule.py:   no primitive OR or BOTTOM elimination; Sep, Bridge,
                    recursion, four-premise equation rule.
candidate_schema.py: same candidate, equation axiom schema instead of its rule.

All four use exactly the same term syntax, shared logical cases, context
representation, substitution helpers, public API, and JSON adapter. Only the
binary-connective grammar, fixed-axiom tuple, disjunction/falsity cases, and
arithmetic case differ. Both schema versions are smaller than their matched
rule versions in every recorded size metric. They are all complete executable
logical certificate checkers, not evaluators of finite numerical instances.

TERMS

The exact tuple grammar is:

  ('v', n)                         a variable; n is a natural-number identifier
  ('0',)                           zero
  ('S', t)                         successor
  ('R', h, (n, a, c0, ..., cm))     initialized primitive recursion

There must be at least two actual R arguments: counter n and initializer a.
The remaining arguments are its declared numerical parameters. The symbol is
identified by its full frozen descriptor h and its argument count. In h the
local formal variable identifiers have the following meaning:

  0 = preceding state; 1 = current counter; 2,3,... = declared parameters.

Every ACTIVE variable of h must be smaller than the argument count. All
parameter slots may be unused. The validator recursively checks nested R
labels, each in its own local slot convention. Nested descriptor slots do not
count as active variables of the enclosing term. The syntax is finite and
well-founded, so there are no cyclic descriptors. This directly implements
the finite dependency grammar without a separate rank certificate.

At an active occurrence R_h(n,a,c), substitution affects only actual argument
terms. It never changes h. Instantiating h in the successor computation axiom
uses a distinct, simultaneous term substitution of its formal slots. No
semantic equality test, normalizer, numerical universal evaluator, optimizer,
or inherited macro table is trusted.

FORMULAS

  ('=', s, t)             equality
  ('F',)                  genuine logical falsity
  ('&', A, B)             conjunction
  ('>', A, B)             implication
  ('all', x, A)           universal quantification
  ('ex', x, A)            existential quantification
  ('|', A, B)             disjunction, admitted only in baseline files

Quantifier identifiers are natural numbers. Falsity is not an equation alias.
All contexts and logical templates may contain arbitrary first-order formulas.
Only the arithmetic index E is restricted to an equality. The candidate
schema's conclusion parameter A is an unrestricted candidate formula.

Substitution is for FREE occurrences only. An attempted variable capture is
rejected, not silently repaired. A proof producer can first choose fresh
bound names and eigenvariables; the countable variable supply is unbounded.
The kernel compares formulas syntactically, not modulo alpha-conversion.
Bound-variable renaming is admissible/derivable in the displayed calculus,
but is not an additional unchecked equality on certificate syntax.

CONTEXTS

A context is a tuple of formulas in order. ('hyp', i) selects its zero-based
ith entry. Every recursive inference checks its premises in the current
context, extended at its END only for the assumptions it discharges. Duplicate
entries are permitted. Weakening, exchange, and contraction are admissible
by transforming hypothesis indices and freshening eigenvariables. None has
a primitive certificate tag. There is no hidden context-subset oracle.

COMPLETE COMMON LOGICAL CERTIFICATE FORMS

Below infer(p,G) means checking the premise in context G. The displayed rule
is accepted only when every formula/term witness is well formed and every
specified syntactic equality and side condition holds.

  ('hyp', i)
    Returns G[i]. Requires a natural index strictly below len(G).

  ('refl', t)
    Returns t=t.

  ('eq', equality, x, A, premise)
    equality must conclude s=t. premise must conclude A[s/x].
    Returns A[t/x]. Both substitutions must avoid capture.

  ('&I', p, q)
    If p concludes A and q concludes B, returns A AND B.

  ('&L', p), ('&R', p)
    p must conclude A AND B. Returns A, respectively B.

  ('>I', A, p)
    Checks p in G appended with A. If it concludes B, returns A -> B.

  ('>E', p, q)
    p must conclude A -> B and q must conclude the same A. Returns B.

  ('allI', x, p)
    x must not be free in G. If p concludes A, returns forall x A.

  ('allE', p, t)
    p must conclude forall x A. Returns A[t/x], with no capture.

  ('exI', x, A, t, p)
    p must conclude A[t/x], with no capture. Returns exists x A.

  ('exE', p, y, q)
    p must conclude exists x A. y must be absent from the free variables
    of G and exists x A. Checks q in G appended with A[y/x], with no
    capture. Its conclusion B must not contain y free. Returns B.

There are no other shared logical axiom schemas or inference rules. No
classical excluded-middle, double-negation-elimination, unbounded induction,
reflection oracle, cut certificate, or arbitrary theorem admission is used.

ADDITIONAL BASELINE LOGICAL FORMS

  ('|L', B, p)
    If p concludes A, returns A OR B.

  ('|R', A, p)
    If p concludes B, returns A OR B.

  ('|E', p, q, r)
    p must conclude A OR B. Checks q in G appended with A and r in G
    appended with B. Their conclusions must be syntactically equal.
    Returns that common conclusion.

  ('FE', A, p)
    p must conclude BOTTOM. Returns A.

Candidate files reject these tags and the primitive disjunction syntax.
They derive explosion arithmetically from the fixed Bridge and recursion;
the supplied report proves this for arbitrary formulas, not just equations.

ALL FIXED NONLOGICAL AXIOMS

Let 1 abbreviate S(0). ('ax', i) returns the ith entry of FIXED_AXIOMS.
No other index is accepted.

  Index 0 in all files:       Sep:    (0=1) -> BOTTOM.
  Index 1 in candidate only:  Bridge: BOTTOM -> (0=1).

The Bridge does not add a classical principle. Its sole purpose here is to
replace the primitive general falsity-elimination case by one fixed equation
consequence; ordinary intuitionistic iPRA proves it by explosion.

ALL COMPUTATION AXIOMS

  ('rec', r)

r must be a well-formed R_h call whose first argument is literally zero or
a successor. The leaf returns precisely one of the following equations:

  R_h(0,a,c) = a
  R_h(Sn,a,c) = h(R_h(n,a,c), n, c).

The right side of the second equation is simultaneous active instantiation
of the frozen descriptor. A counter that is not syntactically zero or a
successor is rejected. The remaining actual terms may be arbitrary and
contain free variables. These open axiom instances are equivalent to their
universal closures under the specified universal introduction/elimination.

ARITHMETIC RULE VARIANTS

In both rule variants, x is a natural variable identifier and E is one
well-formed equality. Subscripts below mean active, capture-free substitution.

baseline_rule.py accepts

  ('sc', x, E, t, p)

with x absent from the free variables of G and t. It checks p in G appended
with x=0 OR E and requires its conclusion to be E[Sx/x]. The returned
conclusion is t=0 OR E[t/x].

candidate_rule.py accepts

  ('sc', x, E, t, A, base, step, zero_case, equation_case)

with x absent from the free variables of G,t,A. It checks:

  base          in G                    concluding E[1/x];
  step          in G appended with E    concluding E[Sx/x];
  zero_case     in G appended with t=0  concluding A;
  equation_case in G appended with E[t/x], concluding the same A.

The returned conclusion is A. All four subproofs must be accepted.

ARITHMETIC SCHEMA VARIANTS

Schema leaves have no premise proof fields. They construct exactly the
following open instances after validating EVERY supplied template and term.
Implications associate to the right.

baseline_schema.py accepts ('sc', x, E, t) and returns

  (forall x ((x=0 OR E) -> E[Sx/x])) -> (t=0 OR E[t/x]).

candidate_schema.py accepts ('sc', x, E, t, A) and returns

  E[1/x]
    -> (forall x (E -> E[Sx/x]))
    -> (t=0 -> A)
    -> (E[t/x] -> A)
    -> A.

Here E must be one equality; A is an arbitrary formula of the variant's
language. There is deliberately no requirement that x be absent from t,A,
or the ambient context. Only the step's displayed quantifier binds x.
Occurrences in external t and A remain free where they were free. The rule
version is obtained after choosing a fresh induction name. Conversely the
schema is derived from the rule after alpha-renaming its internal induction
variable, keeping all external parameters fixed. These names are not a
capture convention or a stronger form of induction.

TRUSTED BOUNDARY AND LIMITS

The mathematical kernel comprises the source preceding the CLI marker. It
includes the complete term/formula validators, descriptor-slot check, active
substitution, capture check, contexts, every logical and arithmetic case,
fixed axioms, and public validation entry points. There are no hidden
arithmetic imports. It relies on the normal semantics of the Python runtime,
its built-in finite tuples/sets/dictionaries/integers, and equality on these
validated objects. Runtime limitations such as recursion depth can prevent
acceptance of very large valid certificates; no such limit permits false
acceptance. Private helpers are not alternate public acceptance interfaces.

The optional standalone CLI additionally trusts the Python standard-library
JSON decoder. It rejects duplicate top-level fields and unsupported JSON
leaves. File parsing, error reporting, and CLI boilerplate are included in
the separate standalone counts. The kernel does not treat an unverified
claimed goal as true: infer computes it; check or the goal field compares it.

These are measured implementations of two specified calculi. The baseline
is a controlled reimplementation of the common elementary core of the six
current drafts; it is not presented as an original checker shipped by any
of them. Their supplied programs were diagnostics, not complete full-logic
checkers. Their optional descriptor reductions are not needed in this raw
baseline and would require additional recognition or certified preprocessing
if incorporated. We make no claim that no alternate implementation of a
baseline calculus could be smaller than these files.

METRICS

metrics.json specifies exact byte, nonblank-line, Python-token, and AST-node
counts, both for the mathematical kernel and complete standalone file. The
same Python measurement functions process all four sources. UTF-8 byte and
line counts include explanatory strings/comments; token counts omit layout
and comments but count string literals/docstrings; AST counts count every
ast.walk node, including Python context/operator nodes. Runtime and standard
library implementation sizes are not included and are common to all four.
The source generator is not in the trusted boundary because the fully
expanded independent modules are delivered and counted. No minifier or
code-golf transformation is used.
