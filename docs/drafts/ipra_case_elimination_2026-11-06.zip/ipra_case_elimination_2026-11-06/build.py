#!/usr/bin/env python3
"""Compile the included mathematical report, preserving diagnostic logs."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import tempfile


def atomic_write(path, data):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(data)
    temporary.replace(path)


def main():
    root = Path(__file__).resolve().parent
    artifacts = root / "artifacts"
    artifacts.mkdir(exist_ok=True)
    if shutil.which("pdflatex") is None:
        raise SystemExit("pdflatex is required (a standard TeX Live installation).")
    with tempfile.TemporaryDirectory(prefix="ipra-case-tex-") as directory:
        build = Path(directory)
        shutil.copyfile(root / "report.tex", build / "report.tex")
        shutil.copytree(root / "sections", build / "sections")
        for iteration in range(1, 4):
            run = subprocess.run(
                ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                cwd=build, capture_output=True, text=True,
            )
            atomic_write(artifacts / f"latex_pass_{iteration}.txt", (run.stdout + run.stderr).encode())
            if run.returncode:
                raise SystemExit(f"LaTeX failed on pass {iteration}; see artifacts/latex_pass_{iteration}.txt")
        log = (build / "report.log").read_text()
        pdf = (build / "report.pdf").read_bytes()
        if not pdf.rstrip().endswith(b"%%EOF"):
            raise SystemExit("LaTeX output is incomplete; existing delivered PDF was not replaced.")
        atomic_write(root / "report.pdf", pdf)
        atomic_write(artifacts / "latex_final.log", log.encode())
    warnings = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()
                or "LaTeX Warning:" in line or "Package hyperref Warning:" in line]
    result = {"status": "compiled", "warnings": warnings,
              "pdf_bytes": (root / "report.pdf").stat().st_size}
    pages = re.search(r"Output written on report.pdf \((\d+) pages", log)
    if pages:
        result["pages"] = int(pages.group(1))
    atomic_write(artifacts / "build_result.json", (json.dumps(result, indent=2) + "\n").encode())
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
