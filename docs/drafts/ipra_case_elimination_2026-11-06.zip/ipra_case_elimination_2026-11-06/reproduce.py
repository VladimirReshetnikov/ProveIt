#!/usr/bin/env python3
"""Rebuild measurements and replay the supplied proof certificates."""
from pathlib import Path
import json
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent
    stages = ["kernel_work/build_kernels.py", "kernel_work/examples.py",
              "kernel_audit/replay_derived_rules.py"]
    records = []
    for script in stages:
        result = subprocess.run([sys.executable, script], cwd=root,
                                capture_output=True, text=True)
        log = root / "artifacts" / (Path(script).stem + "_stdout.txt")
        log.parent.mkdir(exist_ok=True)
        log.write_text(result.stdout + result.stderr)
        records.append({"script": script, "exit_code": result.returncode,
                        "log": str(log.relative_to(root))})
        if result.returncode:
            raise SystemExit(f"Failed: {script}; see {log}")
    audit = json.loads((root / "kernel_audit/replay_results.json").read_text())
    result = {"status": "PASS", "stages": records,
              "positive_families": audit["positive_cases"],
              "negative_families": audit["negative_cases"],
              "independent_api_checks": audit["individual_kernel_checks"],
              "independent_optimized_cli_checks": audit["optimized_cli_checks"],
              "scope": "Finite derivation replay and targeted rejection tests; not a full formalization."}
    (root / "artifacts/reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
