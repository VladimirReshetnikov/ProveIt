IPRA BY NUMERICAL CASE ELIMINATION
6 November 2026
================================

Recommended starting point: report.pdf, then AXIOMS.txt.
Recommended complete proof checker: kernel_work/candidate_schema.py.

RESULT

A fully specified first-order intuitionistic primitive recursive arithmetic
presentation with no primitive disjunction and no primitive falsity-elimination
rule. It keeps genuine falsity. Arithmetic derives both missing mechanisms.
The report proves whole-carrier bi-interpretability and equiconsistency with
full first-order iPRA with quantifier-free induction and all number parameters.

The numerical language uses fixed finite initialized-recursion descriptors.
The extra arithmetic schema is

  E(1) -> [forall x (E(x) -> E(Sx))]
       -> (t=0 -> A) -> (E(t) -> A) -> A,

where E is one equation and A is arbitrary. The only other arithmetic is the
two recursor computation clauses and the fixed implications
  (0=S0) -> FALSE,    FALSE -> (0=S0).

The reduced schema kernel contains 1,555 Python tokens and 1,675 AST nodes,
versus 1,668 tokens and 1,802 AST nodes for the matching baseline schema kernel.
All syntax validation, substitution, axiom data, and arithmetic recognition
are counted. The separate identical JSON adapter is counted too in metrics.json.

This is a controlled implementation-relative reduction over a complete
reimplementation of the six current drafts' shared core. It is not a proof
that no different implementation could be smaller. The source drafts contain
diagnostic programs, not complete arbitrary-proof checkers; their raw file
lengths were not used as checker-size measurements.

CONTENTS

  report.pdf, report.tex, sections/*.tex
    Complete report and all LaTeX source files.
  AXIOMS.txt
    Exact standalone mathematical specification and reconstruction summary.
  kernel_work/
    Four complete standalone checkers, common generator, exact size metrics,
    certificate grammar, and elementary positive/negative examples.
  kernel_audit/
    Independently produced nontrivial derived-rule certificates, rejection
    certificates, replay script, audit explanation, hashes, and results.
  provenance/
    Pinned GitHub source manifest and six exact baseline specifications.
  artifacts/
    Mathematical review notes, build/replay logs, and final validation records.
  build.py
    Compile the report using pdflatex (three passes).
  reproduce.py
    Rebuild checkers and metrics, then replay the supplied checks.
  SHA256SUMS.txt
    Hashes of the delivered package files except this hash list itself.

REPRODUCE THE CHECKERS AND CERTIFICATES

Use Python 3.10 or newer, without third-party packages:

  python3 reproduce.py

The stages regenerate the four standalone checker files, their measurements,
the elementary examples, and the independent replay certificates/results.
The independent replay performs 41 direct API checks and 41 corresponding
JSON CLI checks under Python -O. All are expected to match their stated
acceptance/rejection outcomes. The tests include both-quantifier explosion,
zero-case elimination, and all three encoded-disjunction rules.

To check one certificate directly:

  python3 kernel_work/candidate_schema.py < kernel_audit/certificates/encoded_or_elimination.candidate_schema.json

To compile the PDF, install a standard TeX Live distribution with the packages
listed in report.tex, then run:

  python3 build.py

The checked-in PDF is already compiled. LaTeX source is split into sections;
keep report.tex and sections/ together when rebuilding.

SOURCE SNAPSHOT

Repository: VladimirReshetnikov/ProveIt
Commit: 86b708a209fd20431908347c5aa051d73c8d4682
Directory: docs/drafts
Six archives were fetched and their Git blob SHA-1 values and byte sizes
verified. Full SHA-256 values and URLs are in provenance/source_manifest.json.
The older four-draft snapshot quoted within those archives is not the baseline.

VERIFICATION STATUS

The report has explicit mathematical proofs, two independent mathematical
reviews, complete executable proof checkers, and actual replayed proof trees.
It is not a complete Lean/Rocq formalization, a verified Python implementation,
or an encoding-independent shortest-program theorem. The full equality-test
bootstrap and general interpretation translators are proved in the text;
they are not claimed to have been replayed in full by the Python checker.

No source repository was modified by preparing this package.
