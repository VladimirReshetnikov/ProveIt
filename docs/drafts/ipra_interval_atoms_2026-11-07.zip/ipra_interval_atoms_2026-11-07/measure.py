"""Reproduce complete-source and common-driver measurements, without a network."""
from pathlib import Path
import ast
import csv
import hashlib
import importlib.util
import json
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
KEYS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
DRIVER = """try:
    take = json.load(open(sys.argv[1])).pop
    accepted = check(take(), [])
except:
    accepted = False
print('ACCEPT' if accepted else 'REJECT')
sys.exit(not accepted)
"""


def prefix(source):
    tree = ast.parse(source)
    nodes = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        if isinstance(node, ast.If) and "__name__" in ast.unparse(node.test):
            break
        nodes.append(node)
    return ast.unparse(ast.Module(body=nodes, type_ignores=[])) + "\n"


def main():
    metric_path = ROOT / "comparison/source_measure.py"
    metric_hash = hashlib.sha256(metric_path.read_bytes()).hexdigest()
    if metric_hash != "f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc":
        raise ValueError("The inherited measurement function has changed")
    spec = importlib.util.spec_from_file_location("inherited_metric", metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    corpus = json.loads((ROOT / "comparison/all_kernels.json").read_text())
    prior = json.loads((ROOT / "comparison/current_metrics.json").read_text())
    measured = {}
    for row in corpus["rows"]:
        result = metric.metrics(ROOT / row["local_file"])
        if result["sha256"] != row["sha256"]:
            raise ValueError("Changed comparator: " + row["local_file"])
        measured[row["sha256"]] = result
    current = [{"source": row["file"], "local_file": row["local_file"],
                **measured[row["sha256"]]} for row in prior["rows"]]
    minimum = {key: min(row[key] for row in current) for key in KEYS}
    expanded_minimum = {key: min(row[key] for row in measured.values()) for key in KEYS}
    candidates = [{"file": name, **metric.metrics(ROOT / name)}
                  for name in ("checker.py", "checker_local.py", "comparison/integration_control.py")]
    with tempfile.TemporaryDirectory() as temporary:
        scratch = Path(temporary) / "program.py"

        def common(path):
            scratch.write_text(prefix(path.read_text()) + DRIVER)
            return {key: metric.metrics(scratch)[key] for key in KEYS}

        common_current = [{"source": row["source"], **common(ROOT / row["local_file"])}
                          for row in current]
        common_minimum = {key: min(row[key] for row in common_current) for key in KEYS}
        for row in candidates:
            row["common_driver"] = common(ROOT / row["file"])
    if minimum != expanded_minimum:
        raise ValueError("Expanded corpus has a different minimum")
    expected = dict(zip(KEYS, (367, 392, 1076)))
    if minimum != expected:
        raise ValueError("Unexpected current measurement; inspect Python normalization version")
    primary, local, control = candidates
    if not all(primary[key] < minimum[key] and local[key] < minimum[key] for key in KEYS):
        raise ValueError("A delivered candidate is not below the current as-delivered envelope")
    if not all(primary["common_driver"][key] < common_minimum[key] for key in KEYS):
        raise ValueError("Primary improvement does not survive the common driver")
    result = {
        "status": "PASS", "python": platform.python_version(),
        "implementation": platform.python_implementation(), "commit": prior["commit"],
        "metric_sha256": metric_hash, "root_paths": len(current),
        "distinct_roots": len({row["sha256"] for row in current}),
        "expanded_paths": sum(len(row["paths"]) for row in corpus["rows"]),
        "expanded_sources": len(measured), "minimum": minimum,
        "expanded_minimum": expanded_minimum, "common_driver_minimum": common_minimum,
        "candidates": candidates, "current": current, "common_driver_current": common_current,
        "scope": "Finite-corpus complete-source comparison; no absolute minimality claim.",
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    with (ROOT / "results/current_comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, ["source", *KEYS, "sha256"], extrasaction="ignore")
        writer.writeheader()
        writer.writerows(current)
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("current", "common_driver_current")}, indent=2))


if __name__ == "__main__":
    main()
