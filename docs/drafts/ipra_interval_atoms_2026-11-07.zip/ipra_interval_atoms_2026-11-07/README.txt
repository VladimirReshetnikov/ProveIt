NUMERICAL INTERVALS IN PROOF CERTIFICATES FOR iPRA
================================================
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific time).

MAIN RESULT

checker.py is a complete standalone proof verifier for the scalar native
calculus specified in report.pdf. Its whole-source measures are:

                         Normalized tokens   AST nodes   Normalized bytes
Current supplied minimum          367           392            1076
New checker                       362           386            1064
Local-context companion           364           391            1075

The comparison is pinned to ProveIt commit
ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a, all six current draft ZIPs.
The previous reports' 375/403/1117 envelope is outdated for this snapshot.
Nine root paths represent seven distinct programs. The expanded inventory
has 824 paths and 180 distinct source hashes, with the same minimum.

With one identical conventional public driver, the primary checker is
366/391/1101 against the current 369/395/1105 envelope. Thus the primary
improvement remains strict in all three coordinates after controlling for
driver differences. The local companion is 368/396/1112 under that control:
it is an optional scoping tradeoff, not the smallest delivered kernel.

WHAT IS NEW

The opening routine first distinguishes lists from non-lists. A non-list
leaf is retained only when it passes the already needed integer-bounded
scope interval. Finite numeric labels denote the integers obtained by
flooring them. Since k and d are integers,

  k <= a < d   iff   k <= floor(a) < d.

This justifies a conservative enlargement of the raw certificate syntax
and removes a separate list-coercion guard. The checker does not calculate
floor. The report gives a successful-trace proof, including signed zero,
Boolean aliases, fractional negative names, and nonfinite template holes.

The scalar arithmetic, five-pattern logical basis, truth completion, and
context-length freshness method are inherited and explicitly credited.
The compatible integration of existing truth completion and the compact
driver is measured separately at 365/390/1068. The new interval step saves
three tokens, four AST nodes, and four normalized bytes beyond that control.
This is a modest corpus-relative improvement, not an absolute minimum or
a new foundational arithmetic theory.

MATHEMATICAL CONTENT

The report includes every primitive logical and nonlogical rule: two scalar
iterator computation schemas and five native inference patterns. It derives
full intuitionistic first-order logic, gives an ordinary staged realization,
and supplies whole-domain bi-interpretations with iPRA whose composite
isomorphisms are the identity graph x = y. The inherited scalar predecessor,
quantifier-free reflection, pairing, and primitive-recursion compilation
proofs are reproduced in appendices. The final section gives further
research questions.

The interval quotient changes proof labels, not the arithmetic domain.
In particular, 0.5 in an admitted numerical leaf denotes zero; it is not a
new rational number in the object theory. Canonical certificates can continue
to use integers exclusively. Not every redundant alias spelling is accepted:
for example a raw 0.5 recursion counter rejects.

QUICK START

Python 3.10 or later is required; the complete checkers use only the standard
library. Exact source measurements were reproduced with CPython 3.12.14.

  python3 checker.py examples/zero_computation.json
  python3 checker.py examples/fractional_initializer.json
  python3 -O checker.py examples/false_zero_computation.json

The first two print ACCEPT and exit 0. The third prints REJECT and exits 1.
The JSON packet is consumed from its end, with its final element the goal.
FORMAT.txt describes the representations and instruction conventions.

REPRODUCTION

  python3 reproduce.py
  python3 reproduce.py --pdf

The first command reproduces the measurements and both validation suites.
The second additionally compiles report.tex with pdflatex. No network is
needed. The LaTeX dependencies are the ordinary packages listed in the
report's preamble. Alternatively run python3 build.py to compile only.

CONTENTS

report.tex, report.pdf, sections/, appendices/:
  Complete mathematical report and all sources needed to compile it.
checker.py:
  Smallest delivered complete acceptance program.
checker_local.py:
  Optional program whose fresh-name scope is derived from context length.
comparison/:
  Unchanged inherited metric, frozen comparator sources, complete source
  inventories, archive provenance, and compatible-integration control.
validation/:
  Independent explicit oracle, inherited and new certificates, finite
  differential checks, numerical decoder, public CLI checks, and receipts.
validation_local/:
  Limited proof translator, independent local oracle, scope controls,
  translated certificates, public CLI checks, and receipts.
examples/:
  Small public acceptance and rejection examples.
results/:
  Measurements, validation summaries, and compilation/visual-QA receipts.

LIMITS

The soundness, completeness, and bi-interpretability arguments are written
proofs, not a Lean or Rocq mechanization. Finite tests do not prove those
metatheorems. The checkers do not decide arithmetical truth. Parsing,
recursion, time, and memory limits can reject large valid certificates;
canonical completeness idealizes sufficient finite resources.

The local and global programs need different fresh-name annotations in
some certificates. Their theorem sets agree after interpretation; their
raw accepted packet languages need not agree. The local translator covers
the tested derivation subset and is not claimed to translate every malformed
or noncanonical successful source execution.

See ATTRIBUTION.txt and LICENSE_SOURCE.txt for the inherited material.
