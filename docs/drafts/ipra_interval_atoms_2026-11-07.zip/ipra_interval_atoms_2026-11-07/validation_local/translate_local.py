"""Untrusted extraction and regeneration of global-clock scalar certificates.

The source uses matrix-last truth completion and either integer or interval
atoms. First extract the successful derivation, discarding failed guards.
Then regenerate it with context-length eigenparameters. Auxiliary parameters
from completed or failed source branches are specialized to zero. Successful
source instructions are checked; this is not a claimed compiler for every
possible malformed, noncanonical, or resource-limited packet.
"""
from copy import deepcopy
from dataclasses import dataclass, field
from math import floor, isfinite

from local_oracle import Syntax


@dataclass
class Node:
    rule: str
    goal: object
    floor: int
    data: dict = field(default_factory=dict)
    children: list = field(default_factory=list)


class SourceExtractor:
    def __init__(self):
        self.lower = 0
        self.failed_guards = 0
        self.discarded_allocations = 0
        self.events = []

    def fresh(self):
        self.lower -= 1
        self.events.append(self.lower)
        return self.lower

    def check(self, goal, context):
        entry = self.lower
        syntax = Syntax(entry)
        syntax.formula(goal)
        if goal in context:
            return Node("hypothesis", goal, entry)
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            before = self.lower
            proof = self.check(major, context)
            if proof is not None:
                syntax = Syntax(self.lower)
                if type(major) is not list:
                    raise ValueError("scalar major")
                if len(major) == 3:
                    eigen = self.fresh()
                    extended = Syntax(eigen)
                    assumption = extended.formula([major[2]], eigen)
                    child = self.check(extended.formula(goal, [eigen]),
                                       context + [assumption])
                    if child is None:
                        return None
                    return Node("paired_elimination", goal, entry,
                                {"major": major, "eigen": eigen}, [proof, child])
                if len(major) == 1:
                    template, left, right = major[0], 0, annotation
                    rule = "closure_elimination"
                elif len(major) == 2:
                    template = annotation
                    left, right = major
                    rule = "equality_transport"
                else:
                    raise ValueError("major arity")
                template_floor = self.lower
                if syntax.formula(template, right) != goal:
                    return None
                child = self.check(syntax.formula(template, left), context)
                if child is None:
                    return None
                return Node(rule, goal, entry,
                            {"major": major, "annotation": annotation,
                             "template_floor": template_floor}, [proof, child])
            self.failed_guards += 1
            self.discarded_allocations += before - self.lower
            syntax = Syntax(self.lower)
        if instruction == []:
            (count, initial, update), right = goal
            if count:
                count, = count
                initial = Syntax(self.lower).term(update, [count, initial, update])
            if right != initial:
                return None
            return Node("computation", goal, entry)
        if type(goal) is not list or len(goal) != 3:
            raise ValueError("nonprimitive introduction")
        witness_floor = self.lower
        syntax = Syntax(witness_floor)
        matrix = syntax.formula(goal[2], instruction, 1)
        base = syntax.formula(matrix, 0)
        if type(matrix) is not list:
            raise ValueError("scalar introduction matrix")
        assumptions = [matrix, base] if len(matrix) == 2 else [base]
        eigen = self.fresh()
        extended = Syntax(eigen)
        child = self.check(extended.formula(matrix, [eigen]),
                           context + [extended.formula(a, eigen) for a in assumptions])
        if child is None:
            return None
        return Node("paired_introduction", goal, entry,
                    {"witness": instruction, "witness_floor": witness_floor,
                     "eigen": eigen}, [child])

    def extract(self, packet):
        self.lower = 0
        self.failed_guards = 0
        self.discarded_allocations = 0
        self.events = []
        self.stack = deepcopy(packet)
        if type(self.stack) is not list:
            raise ValueError("packet must be an array")
        result = self.check(self.stack.pop(), [])
        if result is None:
            raise ValueError("source derivation returned false")
        return result


class LocalCompiler:
    def __init__(self):
        self.specialized = set()
        self.hypothesis_prunes = 0
        self.rules = {}

    def renamed_leaf(self, value, source_floor, mapping, protected, formula,
                     template=False):
        if type(value) not in (bool, int, float):
            raise ValueError("noncanonical scalar")
        upper = 2 * protected + (0 if formula else 1)
        if source_floor <= value < upper:
            if value < 0:
                code = floor(value)
                if code in mapping:
                    return mapping[code]
                self.specialized.add(code)
                # Formula scalars are inert truth. A zero scalar is valid
                # under a binder. Root truth scalars need a nonzero-binder
                # canonicalization not attempted by this finite compiler.
                if formula and protected == 0:
                    raise ValueError("root truth scalar needs separate normalization")
                return 0
            return value
        if template:
            return upper
        raise ValueError("exposed source coordinate")

    def term(self, value, source_floor, mapping, protected=0, template=False):
        if type(value) is not list:
            return self.renamed_leaf(value, source_floor, mapping, protected,
                                     False, template)
        if len(value) == 1:
            return [self.term(value[0], source_floor, mapping, protected, template)]
        if len(value) == 3:
            return [self.term(value[0], source_floor, mapping, protected, template),
                    self.term(value[1], source_floor, mapping, protected, template),
                    self.term(value[2], source_floor, mapping, protected + 1, template)]
        raise ValueError("noncanonical numerical arity")

    def formula(self, value, source_floor, mapping, protected=0, template=False):
        if type(value) is not list:
            return self.renamed_leaf(value, source_floor, mapping, protected,
                                     True, template)
        if len(value) == 1:
            return [self.formula(value[0], source_floor, mapping, protected + 1, template)]
        if len(value) == 2:
            return [self.term(part, source_floor, mapping, protected, template)
                    for part in value]
        if len(value) == 3:
            return [self.formula(part, source_floor, mapping, protected + 2, template)
                    for part in value]
        raise ValueError("noncanonical formula arity")

    def image(self, value, source_floor, mapping):
        try:
            return self.term(value, source_floor, mapping)
        except ValueError:
            # A successful source rule can contain an invalid image only
            # when its hole is unused. Zero gives its canonical spelling.
            return 0

    def emit(self, node, context, mapping, expected=None):
        goal = self.formula(node.goal, node.floor, mapping)
        syntax = Syntax(-len(context))
        syntax.formula(goal)
        if expected is not None and goal != expected:
            raise ValueError("regenerated premise does not match translated goal")
        if goal in context:
            if node.rule != "hypothesis":
                self.hypothesis_prunes += 1
            return []
        self.rules[node.rule] = self.rules.get(node.rule, 0) + 1
        if node.rule == "hypothesis":
            raise ValueError("translated hypothesis missing")
        if node.rule == "computation":
            return [[]]
        if node.rule in ("paired_elimination", "closure_elimination", "equality_transport"):
            major_node, minor_node = node.children
            major = self.formula(major_node.goal, major_node.floor, mapping)
            major_proof = self.emit(major_node, context, mapping, major)
            if node.rule == "paired_elimination":
                eigen = -len(context) - 1
                extended = Syntax(eigen)
                assumption = extended.formula([major[2]], eigen)
                scoped = dict(mapping)
                scoped[node.data["eigen"]] = eigen
                minor = self.emit(minor_node, context + [assumption], scoped, goal)
                return [[major, 0]] + major_proof + minor
            source_floor = node.data["template_floor"]
            if node.rule == "closure_elimination":
                annotation = self.image(node.data["annotation"], source_floor, mapping)
                template, left, right = major[0], 0, annotation
            else:
                annotation = self.formula(node.data["annotation"], source_floor,
                                          mapping, template=True)
                template = annotation
                left, right = major
            if syntax.formula(template, right) != goal:
                raise ValueError("translated elimination target changed")
            previous = syntax.formula(template, left)
            minor = self.emit(minor_node, context, mapping, previous)
            return [[major, annotation]] + major_proof + minor
        if node.rule == "paired_introduction":
            witness = self.image(node.data["witness"], node.data["witness_floor"], mapping)
            matrix = syntax.formula(goal[2], witness, 1)
            base = syntax.formula(matrix, 0)
            assumptions = [matrix, base] if len(matrix) == 2 else [base]
            eigen = -len(context) - 1
            extended = Syntax(eigen)
            child_context = context + [extended.formula(a, eigen) for a in assumptions]
            child_goal = extended.formula(matrix, [eigen])
            scoped = dict(mapping)
            scoped[node.data["eigen"]] = eigen
            child = self.emit(node.children[0], child_context, scoped, child_goal)
            return [witness] + child
        raise ValueError("unknown extracted rule")

    def compile(self, packet):
        extractor = SourceExtractor()
        proof = extractor.extract(packet)
        self.specialized = set()
        self.hypothesis_prunes = 0
        self.rules = {}
        goal = self.formula(proof.goal, proof.floor, {})
        instructions = self.emit(proof, [], {})
        result = list(reversed(instructions)) + [goal]
        info = {"source_eigen_allocations": len(extractor.events),
                "failed_guards_discarded": extractor.failed_guards,
                "allocations_in_failed_guards": extractor.discarded_allocations,
                "auxiliary_parameters_specialized_to_zero": sorted(self.specialized),
                "hypothesis_prunes": self.hypothesis_prunes,
                "emitted_rules": dict(self.rules)}
        return result, info
