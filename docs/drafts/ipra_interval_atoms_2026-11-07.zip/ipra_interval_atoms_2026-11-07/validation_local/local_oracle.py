"""Readable independent validator for the local-scope interval checker.

This is validation code, not part of the trusted acceptance boundary. It
does not import the production checker or use its packed depth/arity table.
Bound variables are counted explicitly. A frame's scope is determined by
its own context; a returned or failed major cannot change that scope.
"""
from copy import deepcopy


MISSING = object()


class Syntax:
    def __init__(self, lower):
        self.lower = lower

    def leaf(self, value, image, protected, formula):
        if type(value) not in (bool, int, float):
            raise ValueError("nonnumerical scalar")
        upper = 2 * protected + (0 if formula else 1)
        if self.lower <= value < upper:
            return value
        if image is MISSING:
            raise ValueError("exposed coordinate without image")
        return self.term(image)

    def term(self, value, image=MISSING, protected=0):
        if type(value) is not list:
            return self.leaf(value, image, protected, False)
        if len(value) == 1:
            return [self.term(value[0], image, protected)]
        if len(value) == 3:
            count, initial, update = value
            return [self.term(count, image, protected),
                    self.term(initial, image, protected),
                    self.term(update, image, protected + 1)]
        raise ValueError("numerical constructor arity")

    def formula(self, value, image=MISSING, protected=0):
        if type(value) is not list:
            return self.leaf(value, image, protected, True)
        if len(value) == 1:
            return [self.formula(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.term(value[0], image, protected),
                    self.term(value[1], image, protected)]
        if len(value) == 3:
            return [self.formula(part, image, protected + 2) for part in value]
        raise ValueError("formula constructor arity")


class LocalOracle:
    def __init__(self):
        self.rules = {}
        self.events = []

    def rule(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def eigen(self, context, reason):
        name = -len(context) - 1
        self.events.append({"reason": reason, "context_length": len(context),
                            "new_name": name})
        return name

    def check(self, goal, context):
        syntax = Syntax(-len(context))
        validated = syntax.formula(goal)
        if validated in context:
            self.rule("hypothesis")
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if type(major) is not list:
                    raise ValueError("scalar major")
                if len(major) == 3:
                    self.rule("paired_elimination")
                    eigen = self.eigen(context, "paired_elimination")
                    extended = Syntax(eigen)
                    assumption = extended.formula([major[2]], eigen)
                    conclusion = extended.formula(goal, [eigen])
                    return self.check(conclusion, context + [assumption])
                if len(major) == 1:
                    self.rule("closure_elimination")
                    template, left, right = major[0], 0, annotation
                elif len(major) == 2:
                    self.rule("equality_transport")
                    template = annotation
                    left, right = major
                else:
                    raise ValueError("major arity")
                if syntax.formula(template, right) != goal:
                    return False
                return self.check(syntax.formula(template, left), context)
            self.rule("failed_major_fallthrough")
        if instruction == []:
            if type(goal) is not list or len(goal) != 2:
                raise ValueError("computation goal")
            term, right = goal
            if type(term) is not list or len(term) != 3:
                raise ValueError("computation iterator")
            count, initial, update = term
            if type(count) in (bool, int, float) and count == 0:
                self.rule("computation_zero")
                expected = initial
            elif type(count) is list and len(count) == 1:
                self.rule("computation_successor")
                expected = syntax.term(update, [count[0], initial, update])
            else:
                raise ValueError("computation counter shape")
            return right == expected
        if type(goal) is not list or len(goal) != 3:
            raise ValueError("primitive introduction requires paired formula")
        self.rule("paired_introduction")
        matrix = syntax.formula(goal[2], instruction, 1)
        base = syntax.formula(matrix, 0)
        if type(matrix) is not list:
            raise ValueError("scalar introduction matrix")
        assumptions = [matrix, base] if len(matrix) == 2 else [base]
        eigen = self.eigen(context, "paired_introduction")
        extended = Syntax(eigen)
        child = extended.formula(matrix, [eigen])
        child_context = context + [extended.formula(a, eigen) for a in assumptions]
        return self.check(child, child_context)

    def run(self, packet):
        self.stack = deepcopy(packet)
        self.rules = {}
        self.events = []
        try:
            if type(self.stack) is not list:
                raise ValueError("packet is not an array")
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            accepted = False
            error = type(exc).__name__
        return {"accepted": accepted, "error": error,
                "remaining": len(self.stack) if type(self.stack) is list else None,
                "rules": dict(self.rules), "eigen_events": list(self.events)}
