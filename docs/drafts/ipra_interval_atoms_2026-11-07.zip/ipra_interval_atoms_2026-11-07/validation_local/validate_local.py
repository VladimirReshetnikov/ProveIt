"""Reproduce finite evidence for the inherited local-scope integration.

Tests translated scalar certificates, explicit scope boundaries, failed-major
extraction, sibling-frame reuse, and ordinary versus optimized Python CLI.
No production code is modified. This is not a proof of soundness.
"""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import json
from math import floor
from pathlib import Path
import shutil
import subprocess
import sys
import types

from local_oracle import LocalOracle
from translate_local import LocalCompiler


ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT.parents[1] / "sources" / "ipra_truth_completion_2026-11-07"
          / "ipra_truth_completion_2026-11-07")
CHECKER = ROOT / "checker_local_interval.py"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_prefix(path):
    body = []
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    module = types.ModuleType(path.stem)
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), "exec"), module.__dict__)
    return module


def run_module(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        return bool(module.check(stack.pop(), []))
    except Exception:
        return False


def packet(goal, instructions):
    return list(reversed(deepcopy(instructions))) + [deepcopy(goal)]


def paired(matrix):
    return [deepcopy(matrix) for _ in range(3)]


def reflexivity(term, unused_update=0):
    computation = [[0, deepcopy(term), deepcopy(unused_update)], deepcopy(term)]
    return [[computation, [1, deepcopy(term)]], [], []]


def scope_cases():
    truth = [0, 0]
    exists_truth = paired(truth)
    result = []

    def add(name, data, expected, reason):
        result.append({"name": name, "packet": data, "expected": expected,
                       "reason": reason})

    add("root_next_parameter_rejected", [[], [[0, 0, -1], 0]], False,
        "The initial context declares no negative parameter, including unused update positions.")
    add("root_fractional_next_parameter_rejected", [[], [[0, 0, -0.5], 0]], False,
        "A negative fraction below the initial floor is not a numerical zero alias.")

    for name, parameter, expected in [
        ("one_assumption_existing_parameter", -1, True),
        ("one_assumption_existing_interval_alias", -0.5, True),
        ("one_assumption_future_parameter", -2, False),
        ("one_assumption_fraction_below_floor", -1.5, False),
    ]:
        instructions = [[exists_truth, 0], 0] + reflexivity(0, parameter)
        add(name, packet(truth, instructions), expected,
            "Paired elimination creates exactly one retained closure and floor -1.")

    induction_goal = paired([[1, 0, 0], 0])
    child = [[[-1], 0, 0], 0]
    for name, parameter, expected in [
        ("two_assumptions_actual_eigenparameter", -1, True),
        ("two_assumptions_unused_gap_parameter", -2, True),
        ("two_assumptions_interval_inside_gap", -1.5, True),
        ("two_assumptions_next_parameter", -3, False),
        ("two_assumptions_fraction_below_floor", -2.5, False),
    ]:
        major = [[0, 0, parameter], 0]
        instructions = [0, [major, child], [], []]
        add(name, packet(induction_goal, instructions), expected,
            "Atomic induction appends IH and base: its child has floor -2, although the chosen eigenparameter is -1.")

    computation = [[0, 0, 0], 0]

    def sibling_proof(parameter):
        auxiliary = [[0, 0, parameter], 0]
        return [[exists_truth, 0], 0, [auxiliary, computation], [], []]

    instructions = [[computation, [1, 0]]] + sibling_proof(-1) + sibling_proof(-1)
    add("sibling_frames_reuse_same_name", packet(truth, instructions), True,
        "Independent returned subproofs may each choose -1; no allocation clock is shared.")
    instructions = [[computation, [1, 0]]] + sibling_proof(-1) + sibling_proof(-2)
    add("sibling_frame_does_not_inherit_allocator", packet(truth, instructions), False,
        "The second sibling still has its local floor -1 after its paired elimination.")

    failed_major = paired([[1, 0, 0], [0]])
    equality_goal = paired([1, 1])
    instructions = [[failed_major, 0], 0, []] + reflexivity([-1])
    add("failed_major_does_not_shift_caller_name", packet(equality_goal, instructions), True,
        "A failed induction attempt allocates a local -1; fallback introduction separately chooses -1.")
    instructions = [[failed_major, 0], 0, []] + reflexivity([-2])
    add("failed_major_old_global_name_rejected", packet(equality_goal, instructions), False,
        "Using -2 as the fallback successor target cannot impersonate the actual fresh -1.")

    add("false_closed_equation", packet([0, [0]], reflexivity(0)), False,
        "A genuine reflexivity proof cannot certify zero equals one.")
    add("false_induction", [0, paired([1, 0])], False,
        "The successor goal of y=0 cannot close from its atomic induction hypothesis.")
    add("binary_goal_cannot_use_introduction", [0, [[0], 0]], False,
        "The third-matrix introduction boundary excludes an equation goal.")
    add("malformed_witness_used", ["invalid", paired([3, 3])], False,
        "A used existential witness must be numerical.")
    add("malformed_witness_unused", [{"unused": True}, exists_truth], True,
        "A wholly unused witness may be canonicalized to zero by the untrusted producer.")
    add("boolean_zero_alias", [[], [[0, False, 0], 0]], True,
        "The interval representation accepts bool as numerical zero.")
    add("fractional_zero_alias", [[], [[0, 0.25, 0], 0.25]], True,
        "A finite scalar in [0,1) is a zero alias, with exact raw matching preserved.")
    return result


def global_extraction_examples():
    failed_major = paired([[1, 0, 0], [0]])
    # The failed major allocates global -1. The successful outer induction
    # allocates global -2. Its proof uses the now-auxiliary -1 in an unused
    # numerical update. Regeneration specializes that parameter to zero.
    goal = paired([1, 1])
    instructions = [[failed_major, 0], 0, []] + reflexivity([-2], [-1])
    failed = packet(goal, instructions)

    truth = [0, 0]
    exists_truth = paired(truth)
    computation = [[0, 0, 0], 0]

    def sibling(parameter):
        auxiliary = [[0, 0, parameter], 0]
        return [[exists_truth, 0], 0, [auxiliary, computation], [], []]

    # Each major B-introduction allocates one global name, then B-E allocates
    # the next. Local regeneration uses -1 for either retained witness.
    instructions = [[computation, [1, 0]]] + sibling(-2) + sibling(-4)
    return [("failed_guard_auxiliary_specialization", failed),
            ("sibling_eigenparameter_regeneration", packet(truth, instructions))]


def cli(path, optimized):
    command = [sys.executable] + (["-O"] if optimized else []) + [str(CHECKER), str(path)]
    completed = subprocess.run(command, text=True, capture_output=True, timeout=20)
    accepted = completed.returncode == 0 and completed.stdout == "ACCEPT\n"
    rejected = completed.returncode == 1 and completed.stdout == "REJECT\n"
    return {"accepted": accepted, "valid_verdict": accepted or rejected,
            "returncode": completed.returncode, "stdout": completed.stdout,
            "stderr": completed.stderr}


def evaluate_closed_term(term, environment=()):
    """Direct finite numerical semantics, independent of proof checking."""
    if type(term) is not list:
        coordinate = floor(term)
        if coordinate == 0:
            return 0
        if coordinate < 0:
            raise ValueError("free parameter in closed numerical example")
        return environment[(coordinate - 1) // 2]
    if len(term) == 1:
        return 1 + evaluate_closed_term(term[0], environment)
    if len(term) == 3:
        count = evaluate_closed_term(term[0], environment)
        current = evaluate_closed_term(term[1], environment)
        if not 0 <= count <= 10000:
            raise ValueError("finite numerical example resource bound")
        for _ in range(count):
            current = evaluate_closed_term(term[2], (current,) + environment)
        return current
    raise ValueError("numerical constructor arity")


def main():
    original_hash = digest(CHECKER)
    local = load_prefix(CHECKER)
    reference = ROOT / "reference_global.py"
    if not reference.exists():
        shutil.copyfile(SOURCE / "checker_scalar.py", reference)
    global_checker = load_prefix(reference)
    source_directory = ROOT / "source_global"
    source_directory.mkdir(exist_ok=True)
    translated_directory = ROOT / "translated"
    translated_directory.mkdir(exist_ok=True)
    rows = []
    translation_rows = []
    source_paths = sorted(source_directory.glob("inherited_*.json"))
    if not source_paths:
        source_paths = sorted((SOURCE / "validation" / "translated" / "scalar").glob("*.json"))
    for source_path in source_paths:
        name = (source_path.stem if source_path.stem.startswith("inherited_")
                else "inherited_" + source_path.stem)
        source_packet = json.loads(source_path.read_text())
        stored_source = source_directory / (name + ".json")
        stored_source.write_text(json.dumps(source_packet, separators=(",", ":")) + "\n")
        if not run_module(global_checker, source_packet):
            raise AssertionError("source rejected: " + name)
        translated, info = LocalCompiler().compile(source_packet)
        destination = translated_directory / (name + ".json")
        destination.write_text(json.dumps(translated, separators=(",", ":")) + "\n")
        translation_rows.append({"name": name, "source": str(stored_source.relative_to(ROOT)),
                                 "source_sha256": digest(stored_source),
                                 "translated_sha256": digest(destination), **info})
        rows.append({"name": name, "path": destination, "expected": True,
                     "group": "inherited_translated"})
    for name, source_packet in global_extraction_examples():
        if not run_module(global_checker, source_packet):
            raise AssertionError("extraction source rejected: " + name)
        stored_source = source_directory / (name + ".json")
        stored_source.write_text(json.dumps(source_packet, separators=(",", ":")) + "\n")
        translated, info = LocalCompiler().compile(source_packet)
        destination = translated_directory / (name + ".json")
        destination.write_text(json.dumps(translated, separators=(",", ":")) + "\n")
        translation_rows.append({"name": name, "source": str(stored_source.relative_to(ROOT)),
                                 "source_sha256": digest(stored_source),
                                 "translated_sha256": digest(destination), **info})
        rows.append({"name": name, "path": destination, "expected": True,
                     "group": "extraction_controls"})

    attacks_directory = ROOT / "scope_cases"
    attacks_directory.mkdir(exist_ok=True)
    attack_manifest = []
    for case in scope_cases():
        destination = attacks_directory / (case["name"] + ".json")
        destination.write_text(json.dumps(case["packet"], separators=(",", ":")) + "\n")
        attack_manifest.append({k: v for k, v in case.items() if k != "packet"})
        rows.append({"name": case["name"], "path": destination,
                     "expected": case["expected"], "group": "scope_controls"})

    evidence = []
    rules = Counter()
    for row in rows:
        data = json.loads(row["path"].read_text())
        oracle = LocalOracle().run(data)
        production = run_module(local, data)
        normal = cli(row["path"], False)
        optimized = cli(row["path"], True)
        passed = (production == oracle["accepted"] == row["expected"]
                  and normal["valid_verdict"] and optimized["valid_verdict"]
                  and normal["accepted"] == optimized["accepted"] == row["expected"])
        if oracle["accepted"]:
            rules.update(oracle["rules"])
        evidence.append({**{k: str(v) if isinstance(v, Path) else v for k, v in row.items()},
                         "candidate": production, "oracle": oracle, "normal": normal,
                         "optimized": optimized, "passed": passed})
    if digest(CHECKER) != original_hash:
        raise AssertionError("candidate changed during validation")
    arithmetic = []
    for name, identifier, expected in [("addition_2_3", 142, 5),
                                       ("multiplication_2_3", 143, 6),
                                       ("power_2_3", 144, 8)]:
        path = translated_directory / ("inherited_%03d.json" % identifier)
        left, right = json.loads(path.read_text())[-1]
        values = [evaluate_closed_term(left), evaluate_closed_term(right)]
        if values != [expected, expected]:
            raise AssertionError("numerical semantics mismatch: " + name)
        arithmetic.append({"name": name, "proof": str(path.relative_to(ROOT)),
                           "values": values, "expected": expected})
    summary = {
        "status": "PASS" if all(row["passed"] for row in evidence) else "FAIL",
        "candidate_sha256": original_hash,
        "reference_global_sha256": digest(reference),
        "cases": len(evidence),
        "positive_cases": sum(row["expected"] for row in evidence),
        "negative_cases": sum(not row["expected"] for row in evidence),
        "groups": dict(Counter(row["group"] for row in evidence)),
        "normal_and_optimized_cli_runs": 2 * len(evidence),
        "distinct_translated_packets": len({row["translated_sha256"] for row in translation_rows}),
        "translated_source_packets": len(translation_rows),
        "failed_guards_extracted": sum(row["failed_guards_discarded"] for row in translation_rows),
        "source_allocations_discarded": sum(row["allocations_in_failed_guards"] for row in translation_rows),
        "specialized_parameter_occurrences_by_certificate": sum(len(row["auxiliary_parameters_specialized_to_zero"]) for row in translation_rows),
        "accepted_oracle_rule_counts": dict(rules),
        "independent_closed_numerical_examples": arithmetic,
        "limitations": [
            "Local context scoping is inherited from the historical context-freshness checker, not novel.",
            "The translator deliberately supports the exercised derivation subset, not every noncanonical raw source packet.",
            "A root scalar truth fragment requiring canonical truth normalization is deliberately unsupported by the translator.",
            "The readable oracle shares no implementation with the production checker; the untrusted translator reuses the readable syntax routines.",
            "Finite comparisons and CLI tests are not a soundness or bi-interpretability proof."]}
    (ROOT / "local_validation.json").write_text(json.dumps({"summary": summary,
        "translations": translation_rows, "scope_manifest": attack_manifest,
        "cases": evidence}, indent=2) + "\n")
    (ROOT / "local_validation_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    for row in evidence:
        if not row["passed"]:
            print("FAILED", row["name"], row["expected"], row["candidate"], row["oracle"])
    if summary["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
