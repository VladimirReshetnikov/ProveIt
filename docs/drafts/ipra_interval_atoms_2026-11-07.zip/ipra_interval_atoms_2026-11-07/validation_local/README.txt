LOCAL CONTEXT-SCOPE INTEGRATION: FINITE VALIDATION
================================================

Purpose and attribution
-----------------------
This bundle checks the optional local-scope companion to the interval-atom
checker. Context-length eigenparameter allocation is INHERITED, not novel.
An earlier complete implementation is preserved in the current repository at:

  docs/drafts/ipra_opening_and_witnesses_2026-11-07.zip
  comparison/frozen/ipra_context_freshness_2026-11-07/checker.py

The new integration combines that architecture with the interval atom
representation, the inherited matrix-last truth completion, and the compact
public driver. The mathematical proof is in the enclosing report; finite
tests here do not prove soundness, consistency, or bi-interpretability.

The production file is checker_local_interval.py. Its SHA-256 is:
  e20853e22e25d16868b9623b3c97b4c176a52f4adec9e199cffc425d2f086e02

The enclosing archive may also provide the same bytes as checker_local.py.
The complete source measures 364 normalized tokens, 391 AST nodes, and 1075
normalized UTF-8 bytes under the inherited comparison convention. The
companion is slightly larger than the primary global interval checker.

Reproduce without network access
--------------------------------
From this directory, run:

  python3 validate_local.py

Python 3.10 or later and only its standard library are required. All source
packets, the frozen global source checker, translated packets, scope controls,
and validation code are included. No external source files are required.
The validation writes local_validation.json and local_validation_summary.json.

Try the independently checked arithmetic examples directly:

  python3 checker_local_interval.py translated/inherited_142.json
  python3 checker_local_interval.py translated/inherited_143.json
  python3 -O checker_local_interval.py translated/inherited_144.json

They certify the scalar-language representations of 2+3=5, 2*3=6, and 2^3=8.
The validation also evaluates both sides directly using an independent
finite numerical interpreter, obtaining 5/5, 6/6, and 8/8 respectively.

Observed result
---------------
PASS: 171 cases, with 159 expected acceptances and 12 expected rejections.
Every case agreed between the production checker and the readable local
oracle, and between normal and optimized (-O) public CLI executions.
There were 342 CLI executions in total.

The 171 cases comprise:
  * 147 inherited global-clock positive certificate fixtures, extracted and
    regenerated with local eigenparameters;
  * 2 additional global-to-local extraction controls;
  * 22 explicit scope and syntax controls (10 positive, 12 negative).

The 149 translated source fixtures produce 94 DISTINCT target packets.
The inherited source corpus includes duplicate fixtures; the larger fixture
count is not a claim of that many distinct mathematical proofs.

The extra extraction controls cover both sibling-frame reuse and an actual
failed major proof. In the latter, the failed major allocates one source
eigenparameter. The successful proof later uses that parameter in an unused
numerical update. Extraction discards the failed attempt; regeneration
specializes the now-auxiliary parameter to zero and changes the successful
induction eigenparameter from global -2 to local -1. The regenerated packet
is accepted by both validators and both CLI modes.

Scope controls
--------------
The controls explicitly distinguish:
  * an undeclared root parameter from an available parameter;
  * a one-assumption frame's floor -1 from its forbidden next name -2;
  * an atomic induction frame with two retained assumptions, whose floor is
    -2 although its chosen eigenparameter is -1;
  * the permitted unused gap parameter -2 from forbidden -3;
  * fractional aliases within an interval from fractions below the floor;
  * two independent sibling frames that both choose -1;
  * a failed major's local allocation from the caller's own fresh name;
  * false equality, false induction, and the repaired introduction boundary.

No global allocator state is shared between these frames. The production
checker still consumes instructions from failed major attempts; the scope
reset is not a rewind of the proof tape.

Validation components and limits
-------------------------------
local_oracle.py is a readable implementation of the rules with explicit
term/formula functions and protected-variable counts. It does not import the
production checker or reuse its packed depth/arity table or pattern matcher.
The untrusted translator reuses these readable syntax routines, so the oracle
is independent of production, not an independent implementation of the
translator's opening operation.

translate_local.py first extracts successful source derivations and discards
failed guards. It then assigns eigenparameters according to active context
lengths, specializes escaped auxiliary parameters to zero, and regenerates
instructions. If this creates an earlier hypothesis match, it prunes the
now-unneeded subtree so subsequent instructions remain aligned.

The translator covers every inherited scalar fixture exercised here. It is
NOT a compiler for every possible noncanonical raw source packet. In
particular, it deliberately declines a root scalar truth fragment when that
fragment would require a separate normalization into canonical truth. The
mathematical completeness proof should use canonical proofs, independently
of this finite translator's coverage.

The files in source_global/ are the retained inputs. The files in translated/
are actual resulting proof packets. scope_cases/ contains actual positive
controls and attack packets; their purposes and expected outcomes are listed
in the result manifest. reference_global.py is a frozen inherited scalar
checker, used only as an untrusted validation reference, not imported by the
production checker.

Upstream snapshot
-----------------
All inherited fixtures and the reference scalar checker came from:
  VladimirReshetnikov/ProveIt
  commit ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a
  docs/drafts/ipra_truth_completion_2026-11-07.zip

Fixture paths in that archive:
  validation/translated/scalar/000.json through 146.json

Reference checker path in that archive:
  checker_scalar.py

Reference checker SHA-256:
  282370810d909809fbc4d21905c11bb57060de196534c06d1d06bc01f34c699b

Source packet arrays are reformatted as compact JSON when copied. The
manifests hash those retained copies and their translated outputs. The
enclosing report preserves repository/archive provenance and attribution.
