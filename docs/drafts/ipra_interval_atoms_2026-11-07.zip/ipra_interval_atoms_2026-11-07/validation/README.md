# Interval-leaf checker validation

This is a self-contained finite validation suite for the interval-leaf scalar
iPRA checker. It contains the exact tested checker, an independent readable
oracle, a separate semantic decoder, 147 inherited translated proof packets,
53 new or adversarial packets, source provenance, and observed results.

Run from this directory:

```sh
python3 run.py
```

When this directory is installed as `validation/` inside the complete report
package, the command automatically tests the package's `../checker.py`. An
explicit target can be selected from any working directory:

```sh
python3 /path/to/validation/run.py --checker /path/to/checker.py
```

The selected file must match the exact SHA-256 in `provenance.json`. This avoids
silently attributing recorded tests to a different program. The tested final
file is:

`fa9fdcfed4ff41cbdf233c841bac358492fc3ecd44c49d273b6bfca7efbe6181`.

Only Python's standard library is needed. Normal and optimized (`-O`) public
command-line checks are included. Assertions in validation code do not provide
the acceptance program's rejection behavior.

## What is checked

- **147 inherited integer proofs** are accepted by both the unchanged previous
  truth-completion scalar checker and the new checker. Packet hashes match the
  original archive's translation manifest.
- **147 integral-float translations** of those proofs preserve acceptance,
  including the number of consumed instructions and allocated eigenparameters.
- **53 specific cases** exercise genuine fractional coordinates, both protected
  coordinate aliases, used witnesses, formula truth leaves, fresh-name intervals,
  malformed syntax, zero computation, and the inherited matrix-selection attacks.
- **Differential packet checks** compare production verdicts to a separately
  written rule interpreter. Successful traces also agree on fresh-name floors and
  remaining stack cells. Mutations are not automatically presumed invalid.
- **Opening checks** compare explicit numerical and formula parsers with the
  production opening routine over integer bounds, adjacent representable floats,
  quarter intervals, negative fresh-name boundaries, signed zeros, Booleans,
  nonfinite numbers, malformed values, and nested constructors.
- **Semantic opening checks** decode numerical leaves using mathematical floor,
  explicit zero/parameter/bound-variable meanings and named constructors. They
  check ordinary external one-hole substitution separately from exact raw packet
  equality. Repeated reading of numerical trees as formulas remains truth-only.
- **Three thousand fixed false-conclusion probes** use conclusions with known
  standard-natural-number counterexamples. No accepted false conclusion was found.
- **Five sensitivity controls** deliberately change matrix selection, scope
  bounds, fractional-counter handling, or the new leaf domain. Each changes a
  required fixture's verdict, demonstrating that the new cases exercise those
  behaviors.

The production program imports none of the oracle, semantic decoder, fixtures,
generators, inherited program, or test runner.

## Representation distinctions that matter

A retained finite numerical leaf `a` denotes the existing integer code
`floor(a)`. Thus a fractional value in `[0, 1)` denotes numerical zero, and a
value in `[-1, 0)` denotes allocated eigenparameter `-1` when that parameter is
available. Formula scalar leaves denote truth. Python numeric equality implies
equality of decoded numerical meanings; the converse is not assumed.

The computation instruction distinguishes a zero counter from a successor
array using the production program's actual test. An explicit `0.5` counter
is truthy and is not an array, so it **rejects** instead of silently performing
zero computation. Exact `0.0`, `-0.0`, and `False` counters are valid numeric zero
spellings. Fractional terms can be accepted in other positions, such as an
initializer or a bound-coordinate annotation.

Python's JSON decoder accepts `NaN` and infinity extensions. They can never be
retained by a finite half-open scope interval, and a used numerical image
containing them fails validation. In a template position, however, they can be
replaced as holes by a separately validated finite image. Both situations are
tested. This suite does not falsely report blanket rejection of nonfinite text
in every unused or template position.

## Provenance and results

The inherited source is
`ipra_truth_completion_2026-11-07.zip`, in
`VladimirReshetnikov/ProveIt` at commit
`ea1bd900ee0c8b3d4d108cfc3deb176bab9a039a`.

`provenance.json` records the source archive, each inherited packet and its
original path, the unchanged old checker, the original independent oracle,
and the exact new program hashes. `reference/` retains the old program and
oracle unchanged. The new readable oracle adapts the inherited explicit
constructor parser to the extended numerical leaf domain; its floor-based
semantic decoder and the interval-specific test cases are part of this audit.

Fresh results are in `results/validation.json` and `results/public_cli.json`.
The recorded run checks 8,787 packets, 169,344 opening calls, 3,000 semantic
substitutions, 9,000 successful repeated truth-purity steps, and 122 public CLI
processes. All checks passed. The packet cohort counts and every public CLI
verdict are recorded, rather than inferred from an aggregate success flag.

These are finite implementation checks, **not a formal proof of universal
soundness, completeness, consistency, or bi-interpretability**. Those claims
depend on the mathematical arguments in the accompanying report.
