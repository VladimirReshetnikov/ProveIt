#!/usr/bin/env python3
"""Reproduce finite checks of the interval-leaf iPRA acceptance program.

All inputs, the tested program, the old program, and an independent oracle
are bundled. No network or project-specific installed dependency is needed.
Run: python3 run.py
"""
import argparse
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
import math
from pathlib import Path
import platform
import random
import subprocess
import sys
import types

from oracle import Oracle, numerical, term_meaning, formula_meaning, plug

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
PROGRAM = ROOT / 'checker.py'
SEED = 202611080117


def require(test, detail):
    if not test:
        RESULTS.mkdir(exist_ok=True)
        (RESULTS / 'failure.txt').write_text(repr(detail) + '\n')
        raise AssertionError(detail)


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, allow_nan=True) + '\n')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path=None, source=None):
    if source is None:
        source = Path(path).read_text()
    tree = ast.parse(source)
    body = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    module = types.ModuleType('candidate_prefix')
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), module.__dict__)
    return module


def trace(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'final_k': module.k,
            'remaining': len(stack) if type(stack) is list else None,
            'error': error}


def paths(value, prefix=()):
    yield prefix
    if type(value) is list:
        for index, child in enumerate(value):
            yield from paths(child, prefix + (index,))


def replace(value, path, image):
    if not path:
        return deepcopy(image)
    result = deepcopy(value)
    parent = result
    for index in path[:-1]:
        parent = parent[index]
    parent[path[-1]] = deepcopy(image)
    return result


def transform(value, leaf):
    if type(value) is list:
        return [transform(x, leaf) for x in value]
    return leaf(value)


def pair(body):
    return [deepcopy(body), deepcopy(body), deepcopy(body)]


def reflexivity_steps(term, update=0, hole=100):
    major = [[0, deepcopy(term), deepcopy(update)], deepcopy(term)]
    return [[], [], [major, [hole, deepcopy(term)]]]


def reflexivity(term, update=0, hole=100):
    return reflexivity_steps(term, update, hole) + [[deepcopy(term), deepcopy(term)]]


def specific_fixtures():
    rows = []
    def add(name, packet, expected, reason):
        rows.append({'name': name, 'packet': packet, 'expected': expected, 'reason': reason})
    add('zero_computation', [[], [[0, 0, 0], 0]], True, 'Canonical R0.')
    add('false_zero_computation', [[], [[0, 0, 0], [0]]], False, 'R0 cannot prove zero equals one.')
    add('boolean_false_initializer', [[], [[0, False, 0], 0]], True, 'False is the same numeric zero.')
    add('float_zero_initializer', [[], [[0, 0.0, 0], 0]], True, 'Finite integral float alias.')
    add('signed_zero_counter', [[], [[-0.0, 0, 0], 0]], True, 'Negative zero is actually false in Python.')
    add('boolean_false_counter', [[], [[False, 0, 0], 0]], True, 'False is an actual zero counter.')
    add('fractional_zero_counter', [[], [[0.5, 0, 0], 0]], False, 'A truthy scalar is not a successor array.')
    add('least_positive_zero_counter', [[], [[math.nextafter(0.0, math.inf), 0, 0], 0]], False, 'Even the least positive float is truthy.')
    add('fractional_initializer', [[], [[0, 0.5, 0], 0.5]], True, 'A retained fractional numerical zero alias is allowed.')
    add('fractional_initializer_wrong_target', [[], [[0, 0.5, 0], [0]]], False, 'An alias of zero cannot prove zero equals one.')
    add('distinct_zero_aliases_not_raw_equal', [[], [[0, 0.25, 0], 0.75]], False, 'Semantic equality does not imply raw equality.')
    add('fractional_reflexivity', reflexivity(0.75), True, 'A full equality-transport proof with a nonintegral zero alias.')
    add('root_positive_coordinate', reflexivity(1.5), False, 'No numerical binder protects a root positive coordinate.')
    add('root_boolean_true', reflexivity(True), False, 'True is one, outside root numerical scope.')
    add('future_fractional_parameter_in_unused_update', [[], [[0, 0, -0.5], 0]], False, 'R0 still validates its unused update.')
    add('future_integer_parameter_in_unused_update', [[], [[0, 0, -1], 0]], False, 'Canonical future name is rejected.')
    add('fractional_inner_coordinate', reflexivity_steps([-1]) + [0, pair([1.5, 1.5])], True, 'Paired introduction opens a protected fractional inner coordinate.')
    add('fractional_inner_even_alias', reflexivity_steps([-1]) + [0, pair([2.5, 2.5])], True, 'Both integer coordinate slots denote the same variable.')
    add('boolean_inner_coordinate', reflexivity_steps([-1]) + [0, pair([True, True])], True, 'Boolean True denotes protected coordinate one.')
    add('fractional_outer_coordinate_and_witness', [0.5, pair([3.5, 3.5])], True, 'The outer bound coordinate opens at a fractional numerical witness.')
    add('fractional_outer_even_alias', [0.5, pair([4.5, 4.5])], True, 'The second outer coordinate slot has the same meaning.')
    add('boolean_witness_used', [False, pair([3.5, 3.5])], True, 'A used Boolean zero witness is validated numerically.')
    add('invalid_boolean_witness_used', [True, pair([3.5, 3.5])], False, 'A used Boolean one is not a closed root term.')
    add('fractional_truth_only_pair', [0, pair([0.5])], True, 'A fractional formula leaf denotes truth.')
    add('bare_fractional_truth_root', [0.5], False, 'The theorem decoder does not accept every truth spelling.')
    add('bare_canonical_truth_root', [0], False, 'Inherited bare-root rejection.')
    for name, value, expected in [
        ('exact_fresh_floor', -1.0, True),
        ('inside_fresh_interval', -0.5, True),
        ('just_above_fresh_floor', math.nextafter(-1.0, math.inf), True),
        ('just_below_fresh_floor', math.nextafter(-1.0, -math.inf), False),
        ('just_below_zero_with_fresh_name', math.nextafter(0.0, -math.inf), True),
        ('future_fractional_name', -1.5, False)]:
        packet = reflexivity_steps([-1], update=value) + [0, pair([1.5, 1.5])]
        add(name, packet, expected, 'An update annotation is checked after eigenparameter -1 has been allocated.')
    for label, number in [('nan', math.nan), ('positive_infinity', math.inf), ('negative_infinity', -math.inf), ('overflowed_exponent', float('1e400'))]:
        add(label + '_root_term', reflexivity(number), False, 'Nonfinite leaves cannot survive validation of a root term.')
        add(label + '_template_hole', reflexivity(0, hole=number), True, 'A nonfinite numerical template leaf is replaced by a validated finite term.')
        add(label + '_used_witness', [number, pair([3.5, 3.5])], False, 'Used images must be validated at numerical root scope.')
    for label, invalid in [('null', None), ('string', '0'), ('object', {}), ('empty_array', [])]:
        add(label + '_used_term', reflexivity(invalid), False, 'Invalid used term shape.')
    true = [0, 0]
    bad = [[1, 0, [0]], 0]
    qbad = [bad]
    false_goal = [[[0], 0, [0]], 0]
    add('unguarded_equation_introduction', [0, [[0], 0]], False, 'Catch-all introduction must require the third matrix slot.')
    add('wrong_elimination_matrix', [[], 0, [[bad, true, true], 0], [qbad, [0]], false_goal], False, 'Elimination must select the third meaningful matrix.')
    add('wrong_introduction_matrix', [[], 0, [[true, true, bad], 0], [qbad, [0]], false_goal], False, 'Introduction must select the third meaningful matrix.')
    add('false_induction', [0, pair([1, 0])], False, 'Retaining a base does not prove an invalid equation induction step.')
    add('malformed_packet_object', {}, False, 'The public packet must support stack consumption.')
    return rows


def boundary_values():
    values = [False, True, 0.0, -0.0, math.nan, math.inf, -math.inf,
              10**100, -(10**100), 1e308, -1e308, None, 'x', {}, []]
    for value in range(-8, 16):
        f = float(value)
        values.extend([value, f, f + 0.25, f + 0.5, f + 0.75,
                       math.nextafter(f, -math.inf), math.nextafter(f, math.inf)])
    return values


def opening_audit(module):
    images = [None, 0, -0.0, 0.25, -0.5, -1.5, 1, True, False,
              math.nan, math.inf, {}, 'x', [0], [0.25], [0, 0, 1.5], [0, 0, 3.5], []]
    atoms = boundary_values()
    structures = [[0], [0.5], [1.5], [999], [0, 0], [0.25, 0.75],
                  [0, 0, 1.5], [0, 0, 3.5], [[0], 0], [[0, 0]],
                  [[1.5, 0.5], [3.5, 4.5], [5.5, 6.5]],
                  [[0, 0, -0.5], 0], [0, 0, 0, 0]]
    total = successful = interval_laws = freshness_laws = 0
    for lower in (0, -1, -2, -5):
        for protected in range(6):
            for formula in (False, True):
                ceiling = 2 * protected + (0 if formula else 1)
                for value in atoms:
                    if numerical(value) and (type(value) is not float or math.isfinite(value)):
                        require((lower <= value < ceiling) == (lower <= math.floor(value) < ceiling), ('floor interval', lower, ceiling, value))
                        interval_laws += 1
                        if lower <= value < ceiling:
                            require(math.floor(value) != lower - 1, ('fresh name', lower, ceiling, value))
                            freshness_laws += 1
                for value in atoms + structures:
                    for image in images:
                        module.k = lower
                        try:
                            actual = module.inst(deepcopy(value), deepcopy(image), 2 * protected + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        oracle = Oracle()
                        oracle.lower = lower
                        try:
                            method = oracle.formula if formula else oracle.term
                            expected = method(deepcopy(value), deepcopy(image), protected)
                            expected_valid = True
                        except Exception:
                            expected, expected_valid = None, False
                        require(valid == expected_valid and (not valid or actual == expected), ('opening agreement', formula, lower, protected, value, image, actual, expected))
                        total += 1
                        successful += valid
    return {'cases': total, 'successful': successful, 'floor_interval_cases': interval_laws,
            'fresh_name_cases': freshness_laws, 'floors': [0, -1, -2, -5],
            'protected_binder_counts': list(range(6)),
            'coverage': 'Adjacent binary64 values, quarter intervals, signed zero, Booleans, nonfinite holes, malformed leaves, and constructor nesting.'}


def semantic_opening_audit(module, count=3000):
    rng = random.Random(SEED + 1)
    lower = -5
    module.k = lower
    def term(size, protected, holes):
        if size == 0 or rng.random() < 0.4:
            code = rng.randrange(lower, 2 * protected + 1)
            if holes and rng.random() < 0.22:
                return rng.choice([lower - 0.25, 2 * protected + 1.25, 999.5, math.nan, math.inf, -math.inf])
            return code + rng.choice([0.0, 0.25, 0.5, 0.75])
        if rng.random() < 0.4:
            return [term(size - 1, protected, holes)]
        return [term(size - 1, protected, holes), term(size - 1, protected, holes),
                term(size - 1, protected + 1, holes)]
    def formula(size, protected):
        if size == 0 or rng.random() < 0.3:
            if rng.random() < 0.4:
                return rng.choice([-99.5, -4.75, -0.25, 0.25, 1.5, 999.5, math.nan, math.inf])
            return [term(2, protected, True), term(2, protected, True)]
        if rng.random() < 0.5:
            return [formula(size - 1, protected + 1)]
        return [formula(size - 1, protected + 2) for _ in range(3)]
    repeated = 0
    for index in range(count):
        protected = rng.randrange(5)
        source = formula(3, protected)
        image = term(3, 0, False)
        opened = module.inst(source, image, 2 * protected)
        expected = plug(formula_meaning(source, protected, lower), term_meaning(image, 0, lower))
        actual = formula_meaning(opened, protected, lower)
        require(actual == expected, ('semantic opening', index, protected, source, image, opened, expected, actual))
        pure = deepcopy(image)
        for _ in range(3):
            try:
                pure = module.inst(pure, image, 2 * protected)
            except Exception:
                break
            require(formula_meaning(pure, protected, lower) == ('truth',), ('truth purity', index, pure))
            repeated += 1
    return {'cases': count, 'repeated_truth_purity_steps': repeated, 'seed': SEED + 1,
            'decoder': 'Separate floor-based numerical meanings, named constructors, and external one-hole substitution.'}


def mutation_controls():
    source = PROGRAM.read_text()
    by_name = {row['name']: row for row in specific_fixtures()}
    changes = [
        ('first_matrix_introduction', 'a = inst(a[2], t, 2)', 'a = inst(a[0], t, 2)', 'wrong_introduction_matrix'),
        ('first_matrix_elimination', 'h = [m[2:]]', 'h = [m[:1]]', 'wrong_elimination_matrix'),
        ('lower_scope_bound_removed', 'k <= a < d', 'a < d', 'future_fractional_parameter_in_unused_update'),
        ('fractional_counter_treated_as_zero', 'if n:', 'if n and n != 0.5:', 'fractional_zero_counter'),
        ('new_leaf_domain_disabled', 'if type(a) != list:', 'if type(a) is int:', 'fractional_initializer')]
    rows = []
    correct = load(PROGRAM)
    for name, before, after, fixture in changes:
        require(source.count(before) == 1, ('mutation site', name))
        mutant = load(source=source.replace(before, after))
        packet = by_name[fixture]['packet']
        good = trace(correct, packet)['accepted']
        changed = trace(mutant, packet)['accepted']
        require(good != changed, ('undetected mutation', name, good, changed))
        rows.append({'name': name, 'fixture': fixture, 'correct_accepts': good, 'mutant_accepts': changed})
    return rows


def main():
    global PROGRAM
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, help='Exact production checker to validate; defaults to ../checker.py when this suite is a validation subdirectory.')
    args = parser.parse_args()
    parent_checker = ROOT.parent / 'checker.py'
    PROGRAM = (args.checker or (parent_checker if parent_checker.is_file() else ROOT / 'checker.py')).resolve()
    RESULTS.mkdir(exist_ok=True)
    manifest = json.loads((ROOT / 'provenance.json').read_text())
    require(digest(PROGRAM) == manifest['candidate_sha256'], 'Changed candidate source.')
    require(digest(ROOT / 'reference/truth_scalar.py') == manifest['reference_sha256'], 'Changed inherited source.')
    module = load(PROGRAM)
    old = load(ROOT / 'reference/truth_scalar.py')
    counts = Counter()
    rules = Counter()
    cohorts = {}
    independent = Oracle()
    def agree(packet, name, cohort, expected=None):
        actual = trace(module, packet)
        oracle = independent.run(packet)
        require(actual['accepted'] == oracle['accepted'], ('packet verdict', name, actual, oracle, packet))
        if expected is not None:
            require(actual['accepted'] == expected, ('expected verdict', name, expected, actual, packet))
        if actual['accepted']:
            require((actual['final_k'], actual['remaining']) == (oracle['final_k'], oracle['remaining']), ('successful trace', name, actual, oracle))
        counts['packets'] += 1
        counts['accepted' if actual['accepted'] else 'rejected'] += 1
        cohort_count = cohorts.setdefault(cohort, Counter())
        cohort_count['packets'] += 1
        cohort_count['accepted' if actual['accepted'] else 'rejected'] += 1
        rules.update(oracle['rules'])
        return actual

    positives = []
    for row in manifest['fixtures']:
        path = ROOT / row['file']
        require(digest(path) == row['sha256'], ('fixture changed', row['file']))
        packet = json.loads(path.read_text())
        require(trace(old, packet)['accepted'], ('inherited baseline', row['name']))
        agree(packet, row['name'], 'inherited_canonical', True)
        floated = transform(packet, lambda a: float(a) if type(a) is int and abs(a) <= 2**53 else a)
        agree(floated, row['name'] + '/integral_float_aliases', 'integral_float_aliases', True)
        if path.stat().st_size < 30000:
            positives.append((row['name'], packet))
    print('PASS: 147 inherited proofs and their integral-float translations', flush=True)

    fixed = specific_fixtures()
    new_manifest = []
    for row in fixed:
        result = agree(row['packet'], row['name'], 'specific', row['expected'])
        path = ROOT / 'fixtures/specific' / (row['name'] + '.json')
        save(path, row['packet'])
        new_manifest.append({k: v for k, v in row.items() if k != 'packet'} | {'file': str(path.relative_to(ROOT)), 'sha256': digest(path), 'trace': result})
    save(ROOT / 'fixtures/specific/index.json', new_manifest)
    print('PASS:', len(fixed), 'specific new-domain and adversarial cases', flush=True)

    rng = random.Random(SEED)
    choices = boundary_values() + [[0], [0.5], [1.5], [0, 0], [0, 0, 0], [0, 0, 1.5]]
    for name, packet in positives:
        for mutation in range(10):
            point = rng.choice(list(paths(packet)))
            changed = replace(packet, point, rng.choice(choices))
            agree(changed, name + '/mutation_' + str(mutation), 'mutated_canonical')
    def tree(depth):
        if depth == 0 or rng.random() < 0.45:
            return deepcopy(rng.choice(choices))
        return [tree(depth - 1) for _ in range(rng.randrange(5))]
    for index in range(4000):
        agree(tree(4), 'malformed_' + str(index), 'random_packets')
    false_goals = [[[0], 0], [0, [0]], [[[0]], 0], pair([1.5, 0]), pair([0, 1.5])]
    for index in range(3000):
        name, source_packet = rng.choice(positives)
        changed = deepcopy(source_packet)
        for _ in range(1 + rng.randrange(3)):
            if len(changed) > 1:
                place = rng.randrange(len(changed) - 1)
                point = rng.choice(list(paths(changed[place])))
                changed[place] = replace(changed[place], point, rng.choice(choices))
        changed[-1] = deepcopy(false_goals[index % len(false_goals)])
        agree(changed, 'false_conclusion_' + str(index), 'false_conclusions', False)
    print('PASS: differential packet mutation and fixed false-conclusion probes', flush=True)

    opening = opening_audit(module)
    semantic = semantic_opening_audit(module)
    controls = mutation_controls()
    print('PASS:', opening['cases'], 'opening comparisons and', semantic['cases'], 'semantic substitutions', flush=True)

    public_rows = []
    selected_inherited = [row for row in manifest['fixtures'] if row['name'] in [
        'staged_scalar/atomic_induction_recursion_identity', 'staged_scalar/addition_two_three',
        'staged_scalar/nested_Q_introductions', 'staged_scalar/failed_major_retains_consumed_allocation']]
    cli_rows = [{'file': row['file'], 'expected': True, 'name': row['name']} for row in selected_inherited]
    cli_rows += [{'file': row['file'], 'expected': row['expected'], 'name': row['name']} for row in new_manifest]
    for row in cli_rows:
        for optimized in (False, True):
            command = [sys.executable] + (['-O'] if optimized else []) + [str(PROGRAM), str(ROOT / row['file'])]
            run = subprocess.run(command, text=True, capture_output=True, timeout=20)
            actual = [run.returncode, run.stdout.strip(), run.stderr]
            wanted = [0, 'ACCEPT', ''] if row['expected'] else [1, 'REJECT', '']
            require(actual == wanted, ('public CLI', row, optimized, actual, wanted))
            public_rows.append({'name': row['name'], 'optimized': optimized, 'exit_status': run.returncode, 'stdout': run.stdout.strip()})
    malformed_rows = []
    for name, content in [('truncated_json', '['), ('plain_text', 'not json'), ('duplicate_top_values', '[] []'), ('empty_file', '')]:
        path = ROOT / 'fixtures/specific' / (name + '.txt')
        path.write_text(content)
        for optimized in (False, True):
            run = subprocess.run([sys.executable] + (['-O'] if optimized else []) + [str(PROGRAM), str(path)], capture_output=True, text=True, timeout=20)
            require((run.returncode, run.stdout.strip(), run.stderr) == (1, 'REJECT', ''), ('bad JSON CLI', name, optimized, run))
            malformed_rows.append({'name': name, 'optimized': optimized, 'exit_status': run.returncode, 'stdout': run.stdout.strip()})
    save(RESULTS / 'public_cli.json', {'status': 'PASS', 'processes': len(public_rows) + len(malformed_rows), 'rows': public_rows + malformed_rows})
    print('PASS:', len(public_rows) + len(malformed_rows), 'normal / -O public CLI processes', flush=True)

    result = {'status': 'PASS', 'python': platform.python_version(), 'candidate_sha256': digest(PROGRAM),
              'source_commit': manifest['commit'], 'inherited_source_sha256': manifest['reference_sha256'],
              'packet_differential': dict(counts), 'cohorts': {k: dict(v) for k, v in cohorts.items()},
              'oracle_rule_counts': dict(rules), 'opening_agreement': opening,
              'semantic_opening': semantic, 'mutation_controls': controls,
              'public_cli_processes': len(public_rows) + len(malformed_rows), 'seed': SEED,
              'scope': 'Finite implementation evidence. It is not a proof of universal soundness, completeness, consistency, or bi-interpretability.'}
    save(RESULTS / 'validation.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
