"""Readable interval-leaf oracle, independent of the production dispatch table.

Adapted from the truth-completion archive's semantic_oracle.py; exact source
provenance and an untouched copy are bundled. Changes: finite float and Boolean
leaves obey the same half-open scope intervals as integers; nonfinite numbers
are exposed holes, never retained syntax. Numeric meanings are obtained with
floor(), separately from raw equality used for agreement of packet verdicts.

This module is validation code. The production checker imports none of it.
"""
from copy import deepcopy
from math import floor, isfinite


def numerical(value):
    return type(value) in (int, float, bool)


class Oracle:
    def __init__(self):
        self.lower = 0
        self.rules = {}

    def rule(self, name):
        self.rules[name] = self.rules.get(name, 0) + 1

    def leaf(self, value, image, protected, formula):
        if not numerical(value):
            raise ValueError('non-numerical leaf')
        ceiling = 2 * protected + (0 if formula else 1)
        if self.lower <= value < ceiling:
            return value
        return self.term(image)

    def term(self, value, image=None, protected=0):
        if numerical(value):
            return self.leaf(value, image, protected, False)
        if type(value) is not list:
            raise ValueError('term type')
        if len(value) == 1:
            return [self.term(value[0], image, protected)]
        if len(value) == 3:
            count, initial, update = value
            return [self.term(count, image, protected),
                    self.term(initial, image, protected),
                    self.term(update, image, protected + 1)]
        raise ValueError('term arity')

    def formula(self, value, image=None, protected=0):
        if numerical(value):
            return self.leaf(value, image, protected, True)
        if type(value) is not list:
            raise ValueError('formula type')
        if len(value) == 1:
            return [self.formula(value[0], image, protected + 1)]
        if len(value) == 2:
            return [self.term(value[0], image, protected),
                    self.term(value[1], image, protected)]
        if len(value) == 3:
            return [self.formula(child, image, protected + 2) for child in value]
        raise ValueError('formula arity')

    def fresh(self):
        self.lower -= 1
        return self.lower

    def check(self, goal, context):
        checked = self.formula(goal)
        if checked in context:
            self.rule('hypothesis')
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if type(major) is not list:
                    raise ValueError('scalar major')
                if len(major) == 3:
                    self.rule('paired_elimination')
                    eigen = self.fresh()
                    assumption = self.formula([major[2]], eigen)
                    return self.check(self.formula(goal, [eigen]), context + [assumption])
                if len(major) == 1:
                    self.rule('closure_elimination')
                    matrix, left, right = major[0], 0, annotation
                elif len(major) == 2:
                    self.rule('equality_transport')
                    matrix = annotation
                    left, right = major
                else:
                    raise ValueError('major arity')
                if self.formula(matrix, right) != goal:
                    return False
                return self.check(self.formula(matrix, left), context)
            self.rule('failed_major_fallthrough')
        if type(instruction) is list and not instruction:
            if type(goal) is not list or len(goal) != 2:
                raise ValueError('computation requires equality')
            term, right = goal
            if type(term) is not list or len(term) != 3:
                raise ValueError('computation requires iterator')
            count, initial, update = term
            # Zero computation recognizes actual numeric zero. A positive
            # fractional zero alias is truthy in the production program and
            # cannot be destructured as a successor. It must reject here too.
            if numerical(count) and count == 0:
                expected = initial
                self.rule('computation_zero')
            elif type(count) is list and len(count) == 1:
                smaller = [count[0], initial, update]
                expected = self.term(update, smaller)
                self.rule('computation_successor')
            else:
                raise ValueError('counter shape')
            return right == expected
        if type(goal) is not list or len(goal) != 3:
            raise ValueError('primitive introduction requires paired goal')
        self.rule('paired_introduction')
        matrix = self.formula(goal[2], instruction, 1)
        base = self.formula(matrix, 0)
        if type(matrix) is not list:
            raise ValueError('scalar introduction matrix')
        assumptions = [matrix, base] if len(matrix) == 2 else [base]
        eigen = self.fresh()
        conclusion = self.formula(matrix, [eigen])
        opened = [self.formula(a, eigen) for a in assumptions]
        return self.check(conclusion, context + opened)

    def run(self, packet):
        self.lower = 0
        self.rules = {}
        self.stack = deepcopy(packet)
        try:
            accepted = bool(self.check(self.stack.pop(), []))
            error = None
        except Exception as exc:
            accepted, error = False, type(exc).__name__
        return {'accepted': accepted, 'final_k': self.lower,
                'remaining': len(self.stack) if type(self.stack) is list else None,
                'rules': dict(self.rules), 'error': error}


def term_meaning(value, protected, lower):
    """Decode a term template to named semantic constructors and one hole."""
    if numerical(value):
        if not lower <= value < 2 * protected + 1:
            return ('hole',)
        code = floor(value)
        if code == 0:
            return ('zero',)
        if code < 0:
            return ('parameter', code)
        return ('bound', (code - 1) // 2)
    if type(value) is not list:
        raise ValueError('term type')
    if len(value) == 1:
        return ('successor', term_meaning(value[0], protected, lower))
    if len(value) == 3:
        return ('iterate', term_meaning(value[0], protected, lower),
                term_meaning(value[1], protected, lower),
                term_meaning(value[2], protected + 1, lower))
    raise ValueError('term arity')


def formula_meaning(value, protected, lower):
    if numerical(value):
        return ('truth',)
    if type(value) is not list:
        raise ValueError('formula type')
    if len(value) == 2:
        return ('equality', term_meaning(value[0], protected, lower),
                term_meaning(value[1], protected, lower))
    if len(value) == 1:
        child = formula_meaning(value[0], protected + 1, lower)
        return child if child == ('truth',) else ('closure', child)
    if len(value) == 3:
        child = formula_meaning(value[2], protected + 2, lower)
        return child if child == ('truth',) else ('pair', child)
    raise ValueError('formula arity')


def plug(tree, image):
    if tree == ('hole',):
        return image
    if type(tree) is tuple:
        return tuple(plug(child, image) for child in tree)
    return tree
