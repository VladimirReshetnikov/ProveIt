#!/usr/bin/env python3
"""Independent targeted audit of the factored iPRA checker.

Expected judgments are written directly or constructed with a separate
named-variable syntax.  No certificate compiler or proof builder from the
research packages is imported.  The only imported application is the checker
under audit.  Tests provide finite regression evidence, not a metatheorem.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
DEFAULT_CHECKER = HERE.parent / "checker.py"


def var(name):
    return ("var", name)


ZERO = ("zero",)
BOTTOM = ("bottom",)


def succ(t):
    return ("succ", t)


def rec(n, a, state, counter, body):
    return ("rec", n, a, state, counter, body)


def eq(s, t):
    return ("eq", s, t)


def pi(x, a, b):
    return ("pi", x, a, b)


def sig(x, a, b):
    return ("sig", x, a, b)


def encode(a, names):
    """Encode named syntax; nearest binder is the first name in the list."""
    tag = a[0]
    if tag == "var":
        return names.index(a[1])
    if tag == "zero":
        return -1
    if tag == "bottom":
        return ["false"]
    if tag == "succ":
        return ["s", encode(a[1], names)]
    if tag == "rec":
        _, n, initial, state, counter, body = a
        return ["r", encode(n, names), encode(initial, names),
                encode(body, [state, counter, *names])]
    if tag == "eq":
        return ["=", encode(a[1], names), encode(a[2], names)]
    if tag in ("pi", "sig"):
        _, x, left, right = a
        return [tag, encode(left, [x, *names]), encode(right, [x, *names])]
    raise AssertionError(("bad named fixture", a))


def substitute(a, replacements):
    """Simultaneous substitution on fixtures whose bound names are fresh.

    Insertions are not visited.  Removing locally bound names handles
    shadowing independently of the checker's index arithmetic.
    """
    tag = a[0]
    if tag == "var":
        return replacements.get(a[1], a)
    if tag in ("zero", "bottom"):
        return a
    if tag in ("succ", "eq"):
        return (tag, *(substitute(b, replacements) for b in a[1:]))
    if tag == "rec":
        _, n, initial, state, counter, body = a
        inner = {k: v for k, v in replacements.items() if k not in (state, counter)}
        return rec(substitute(n, replacements), substitute(initial, replacements),
                   state, counter, substitute(body, inner))
    if tag in ("pi", "sig"):
        _, x, left, right = a
        inner = {k: v for k, v in replacements.items() if k != x}
        return (tag, x, substitute(left, inner), substitute(right, inner))
    raise AssertionError(a)


def numerical_schema(matrix, force_induction=False):
    """A named rendering of the mathematical axiom, not checker operations."""
    y, target, unused = "N_step", "N_target", "N_unused"
    base = substitute(matrix, {"x": ZERO})
    if matrix[0] == "eq" or force_induction:
        guard = substitute(matrix, {"x": var(y)})
    else:
        guard = base
    step = pi(y, guard, substitute(matrix, {"x": succ(var(y))}))
    return pi(target, sig(unused, base, step),
              substitute(matrix, {"x": var(target)}))


def recursion_equation(r):
    _, n, initial, state, counter, body = r
    if n == ZERO:
        result = initial
    else:
        assert n[0] == "succ"
        previous = n[1]
        result = substitute(body, {state: rec(previous, initial, state, counter, body),
                                   counter: previous})
    return eq(r, result)


def reflexivity(term, names):
    """The two-recursion-leaf derivation of t=t, explicitly constructed."""
    r = rec(ZERO, term, "refl_state", "refl_counter", ZERO)
    leaf = ["rec", encode(r, names)]
    template = encode(eq(var("refl_slot"), term), ["refl_slot", *names])
    return ["use", leaf, template, leaf]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", type=Path, default=DEFAULT_CHECKER)
    args = parser.parse_args()
    checker_path = args.checker.resolve()
    spec = importlib.util.spec_from_file_location("audited_ipra_checker", checker_path)
    kernel = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(kernel)
    out = HERE / "certificates"
    out.mkdir(exist_ok=True)
    records, helper_records, cli_records = [], [], []

    def trial(name, expected, data, reason):
        # Go through actual JSON parsing before exercising acceptance.
        raw = json.dumps(data, ensure_ascii=True, indent=2, allow_nan=False) + "\n"
        parsed = json.loads(raw)
        exception = None
        try:
            accepted = kernel.check(parsed) is True
        except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError) as error:
            accepted = False
            exception = type(error).__name__
        except Exception as error:
            raise AssertionError(f"Unexpected exception in {name}: {error!r}") from error
        path = out / f"{name}.json"
        path.write_text(raw)
        records.append({"name": name, "expected": "ACCEPT" if expected else "REJECT",
                        "actual": "ACCEPT" if accepted else "REJECT", "pass": accepted == expected,
                        "exception": exception, "reason": reason,
                        "certificate": str(path.relative_to(HERE))})
        if accepted != expected:
            raise AssertionError(f"{name}: expected {expected}, got {accepted}; {path}")

    def judgment(name, expected, assumptions, goal, proof, reason):
        trial(name, expected, {"assumptions": assumptions, "goal": goal, "proof": proof}, reason)

    def named(name, expected, assumptions, goal, proof, names, reason):
        judgment(name, expected, [encode(a, names) for a in assumptions], encode(goal, names), proof, reason)

    def helper(name, actual, expected, reason):
        good = actual == expected
        helper_records.append({"name": name, "pass": good, "reason": reason})
        if not good:
            raise AssertionError(f"{name}: actual={actual!r}, expected={expected!r}")

    raw_zero = -1
    one = ["s", raw_zero]
    truth = ["=", raw_zero, raw_zero]
    clash = ["=", raw_zero, one]
    false = ["false"]

    # Actual formula boundaries.  Strict number syntax differs deliberately
    # from a hypothesis lookup key, which cannot enter a derivation as syntax.
    valid_terms = [raw_zero, 0, 1, 127, 1000000, ["s", raw_zero],
                   ["r", raw_zero, 0, ["s", 0]],
                   ["r", ["s", 0], 1, ["r", 0, 2, ["s", 3]]]]
    for i, term in enumerate(valid_terms):
        a = ["=", term, term]
        judgment(f"valid_term_{i:02d}", True, [a], a, ["hyp", a],
                 "Zero sentinel, nonnegative variables, and well-scoped native terms are legal.")
    invalid_terms = [True, False, 0.0, 1.0, -1.0, -2, -99, None, "0", "-1", "s", "x", [], {},
                     ["z"], ["false"], ["s"], ["s", -1, -1], ["s", True], ["s", "0"],
                     ["r", -1, 0], ["r", -1, 0, -1, -1], ["r", -1, 0, ["=", -1, -1]],
                     ["=", -1, -1], ["pi", truth, truth], ["sig", truth, truth],
                     ["r", 0, 0, {"tag": "s"}]]
    for i, term in enumerate(invalid_terms):
        a = ["=", term, term]
        judgment(f"invalid_term_{i:02d}", False, [a], a, ["hyp", a],
                 "Invalid term syntax must be rejected in assumptions and goal even if it compares equal to valid syntax.")
    valid_formulas = [truth, false, ["pi", truth, false], ["sig", false, truth],
                      ["pi", ["=", 0, 0], ["sig", ["=", 1, -1], ["=", 0, 2]]]]
    for i, a in enumerate(valid_formulas):
        judgment(f"valid_formula_{i:02d}", True, [a], a, ["hyp", a],
                 "The public assertion grammar admits bottom, Pi, and Sigma.")
    invalid_formulas = [-1, 0, True, False, None, "false", [], {}, ["false", 0], ["=", -1],
                        ["=", -1, -1, 0], ["pi", truth], ["sig", truth, truth, truth],
                        ["pi", -1, truth], ["sig", truth, ["s", -1]], ["unknown", truth, truth]]
    for i, a in enumerate(invalid_formulas):
        judgment(f"invalid_formula_{i:02d}", False, [a], a, ["hyp", a],
                 "Wrong formula tags, arities, and sorts are invalid.")

    # Format, wrong proof arities, and exact public falsity conversion.
    valid_root = {"assumptions": [truth], "goal": truth, "proof": ["hyp", truth]}
    malformed_roots = [[], None, True, {}, {"assumptions": [], "goal": truth},
                       {**valid_root, "extra": None}, {**valid_root, "assumptions": {}},
                       {**valid_root, "assumptions": False}, {**valid_root, "proof": []},
                       {**valid_root, "proof": ["hyp"]}, {**valid_root, "proof": ["hyp", truth, truth]},
                       {**valid_root, "proof": ["unknown", truth]},
                       {**valid_root, "proof": {"tag": "hyp", "formula": truth}}]
    for i, root in enumerate(malformed_roots):
        trial(f"malformed_root_{i:02d}", False, root, "The complete JSON interface and proof record arities are checked.")
    for i, (stored, key) in enumerate([(0, False), (1, True), (0, 0.0), (1, 1.0), (-1, -1.0)]):
        a, lookup = ["=", stored, stored], ["=", key, key]
        judgment(f"hyp_lookup_alias_{i:02d}", True, [a], a, ["hyp", lookup],
                 "A non-syntactic lookup key may select a validated stored formula; the key itself is never returned.")
        judgment(f"invalid_alias_goal_{i:02d}", False, [a], lookup, ["hyp", a],
                 "The same numeric alias is forbidden in an asserted goal.")
    judgment("false_to_clash", True, [false], clash, ["hyp", false],
             "Public bottom is converted to the closed contradictory equation.")
    judgment("clash_to_false", True, [clash], false, ["hyp", clash],
             "The public ordinary theory's reverse bridge is represented too.")
    nested_false = ["pi", ["sig", false, truth], ["pi", truth, false]]
    nested_clash = ["pi", ["sig", clash, truth], ["pi", truth, clash]]
    judgment("nested_false_conversion", True, [nested_false], nested_clash, ["hyp", nested_false],
             "Canonicalization descends beneath both binders, including negative positions.")
    judgment("false_is_not_an_axiom", False, [], false, ["hyp", false],
             "Canonicalization does not make contradiction a proof leaf.")
    judgment("false_in_term_position", False, [], ["=", false, -1], ["rec", ["r", -1, false, -1]],
             "Converting a bottom node never makes it a number term.")

    # Pi introduction lifts the retained context; it does not rebind its
    # former index zero to the new eigenvariable.
    bound_reflexive = ["=", 0, 0]
    judgment("pi_identity", True, [], ["pi", bound_reflexive, bound_reflexive],
             ["pi", bound_reflexive, ["hyp", bound_reflexive]],
             "A fresh bound number may occur in both components.")
    old = ["=", 0, one]
    lifted = ["=", 1, one]
    judgment("pi_retained_context", True, [old], ["pi", truth, lifted],
             ["pi", truth, ["hyp", lifted]], "Old parameters are shifted under Pi.")
    judgment("pi_captured_context", False, [old], ["pi", truth, old],
             ["pi", truth, ["hyp", old]], "An old parameter cannot become the freshly generalized number.")
    principal = ["pi", ["=", 0, 0], ["=", ["s", 0], ["s", 0]]]
    guard = ["=", one, one]
    target = ["=", ["s", one], ["s", one]]
    judgment("use_pi", True, [principal, guard], target,
             ["use", ["hyp", principal], one, ["hyp", guard]],
             "The shared eliminator instantiates a Pi term and checks its guard.")
    judgment("use_pi_wrong_guard", False, [principal, truth], target,
             ["use", ["hyp", principal], one, ["hyp", truth]],
             "A proof of another equation does not satisfy the instantiated guard.")
    for i, bad in enumerate([True, 0.0, -2, "0", false, ["s", False]]):
        judgment(f"use_pi_invalid_witness_{i:02d}", False, [principal, guard], target,
                 ["use", ["hyp", principal], bad, ["hyp", guard]],
                 "The Pi instantiation term receives strict syntax validation.")

    # Witness-based Sigma introduction and eigenvariable escape rejection.
    witness_eq = ["=", 0, -1]
    sigma_zero = ["sig", witness_eq, witness_eq]
    judgment("pair_zero_witness", True, [], sigma_zero,
             ["pair", -1, ["hyp", witness_eq], ["hyp", witness_eq]],
             "The two component conclusions are inferred under y=0.")
    judgment("pair_retained_context", True, [["=", 0, -1]],
             ["sig", ["=", 0, 2], ["=", 1, -1]],
             ["pair", 1, ["hyp", ["=", 0, 2]], ["hyp", ["=", 1, -1]]],
             "Both retained context and witness term are lifted under the fresh number.")
    judgment("pair_captured_witness", False, [], ["sig", bound_reflexive, bound_reflexive],
             ["pair", 0, ["hyp", bound_reflexive], ["hyp", bound_reflexive]],
             "A free witness term is shifted; y=t does not become the spurious hypothesis y=y.")
    for i, bad in enumerate([True, 0.0, -1.0, -2, None, "0", false]):
        judgment(f"pair_invalid_witness_{i:02d}", False, [], sigma_zero,
                 ["pair", bad, ["hyp", witness_eq], ["hyp", witness_eq]],
                 "Sigma's supplied witness must be a valid term.")
    old_zero, old_zero_lifted = ["=", 0, -1], ["=", 1, -1]
    judgment("use_sigma_retained_context", True, [sigma_zero, old_zero], old_zero,
             ["use", ["hyp", sigma_zero], old_zero, ["hyp", old_zero_lifted]],
             "Sigma elimination may return a conclusion about an old parameter.")
    judgment("use_sigma_witness_escape", False, [sigma_zero], old_zero,
             ["use", ["hyp", sigma_zero], old_zero, ["hyp", witness_eq]],
             "Existence of a zero witness does not imply that an arbitrary free parameter is zero.")
    judgment("use_sigma_escape_with_retained_context", False, [sigma_zero, old_zero], old_zero,
             ["use", ["hyp", sigma_zero], old_zero, ["hyp", witness_eq]],
             "Even when the goal happens to follow separately, this branch must prove its correctly shifted version.")

    # Transport through nested numerical and logical binders.  All expected
    # index placement here is supplied by the independent named syntax.
    env = ["a", "b", "p"]
    a, b, p, slot = map(var, ("a", "b", "p", "slot"))
    nested_term = rec(var("w"), slot, "u", "k",
                      rec(var("u"), slot, "v", "j", succ(var("k"))))
    template = pi("w", eq(var("w"), slot), eq(nested_term, slot))
    fa = substitute(template, {"slot": a})
    fb = substitute(template, {"slot": b})
    principal = eq(a, b)
    transport = ["use", ["hyp", encode(principal, env)], encode(template, ["slot", *env]),
                 ["hyp", encode(fa, env)]]
    named("transport_under_pi_and_nested_rec", True, [principal, fa], fb, transport, env,
          "Equality transport substitutes only free occurrences under Pi and both nested recursors.")
    wrong_fb = pi("w", eq(var("w"), b), eq(nested_term, b))
    wrong_fb = substitute(wrong_fb, {"slot": a})
    named("transport_partial_substitution", False, [principal, fa], wrong_fb, transport, env,
          "Substitution must reach the recursion body's free parameter too.")
    reverse = ["use", ["hyp", encode(principal, env)], encode(template, ["slot", *env]),
               ["hyp", encode(fb, env)]]
    named("transport_wrong_orientation", False, [principal, fa, fb], fa, reverse, env,
          "The shared transport step requires a proof at the equation's left side.")
    for i, bad in enumerate([True, 0.0, -1, "pi", [], ["=", True, True], ["pi", truth], ["false", 0]]):
        invalid_transport = ["use", ["hyp", encode(principal, env)], bad, ["hyp", encode(fa, env)]]
        named(f"transport_invalid_template_{i:02d}", False, [principal, fa], fb, invalid_transport, env,
              "The elimination annotation must be a valid formula when the principal formula is an equation.")

    # Recursion equations and a derived theorem, including simultaneous
    # substitution beneath a nested recursor in the update body.
    env = ["n", "a", "p"]
    n, a, p = map(var, env)
    terms = [rec(ZERO, a, "u", "k", succ(var("u"))),
             rec(succ(n), a, "u", "k", succ(var("u"))),
             rec(succ(n), a, "u", "k", var("k")),
             rec(succ(n), a, "u", "k", p),
             rec(succ(n), a, "u", "k", rec(var("u"), var("k"), "v", "j", succ(var("k"))))]
    for i, r in enumerate(terms):
        named(f"recursion_equation_{i:02d}", True, [], recursion_equation(r),
              ["rec", encode(r, env)], env, "The expected recursion equation is constructed by named simultaneous substitution.")
    bad_r = rec(n, a, "u", "k", var("u"))
    named("recursion_variable_counter_leaf", False, [], eq(bad_r, a), ["rec", encode(bad_r, env)], env,
          "A rec leaf is only a zero or successor computation equation.")
    r = terms[-1]
    wrong_result = substitute(r[5], {r[3]: r, r[4]: succ(n)})
    named("recursion_wrong_previous_counter", False, [], eq(r, wrong_result),
          ["rec", encode(r, env)], env, "The step inserts the previous counter and previous recursive value, not the current ones.")
    complex_t = rec(n, a, "u", "k", rec(var("u"), p, "v", "j", succ(var("k"))))
    named("derived_reflexivity_nested_rec", True, [], eq(complex_t, complex_t), reflexivity(complex_t, env), env,
          "Reflexivity is obtained from two computation leaves and equality replacement.")

    # Direct numerical-schema fixtures, positive and counterfeit induction.
    x, p, q = map(var, ("x", "p", "q"))
    matrices = [eq(x, x), eq(rec(x, p, "u", "k", succ(var("u"))), q),
                pi("z", eq(var("z"), var("z")), eq(x, var("z"))),
                sig("z", eq(var("z"), x), eq(p, var("z"))),
                BOTTOM, pi("z", BOTTOM, eq(x, p)),
                pi("z", eq(var("z"), x),
                   sig("w", eq(rec(var("z"), p, "u", "k", x), var("w")), eq(q, var("w")))),
                eq(p, q)]
    env = ["p", "q"]
    for i, matrix in enumerate(matrices):
        proof = ["nat", encode(matrix, ["x", *env])]
        named(f"numerical_schema_{i:02d}", True, [], numerical_schema(matrix), proof, env,
              "Named target, step, and dummy witnesses independently determine the numerical axiom's indices.")
        if matrix[0] in ("pi", "sig"):
            named(f"counterfeit_compound_induction_{i:02d}", False, [],
                  numerical_schema(matrix, force_induction=True), proof, env,
                  "A compound matrix receives only its zero premise, never an induction hypothesis at the current counter.")
    outer_matrix = pi("z", eq(var("z"), var("z")), eq(x, var("p")))
    outer_goal = pi("p", eq(var("p"), var("p")), numerical_schema(outer_matrix))
    outer_proof = ["pi", ["=", 0, 0], ["nat", encode(outer_matrix, ["x", "p"])]]
    named("numerical_schema_under_pi", True, [], outer_goal, outer_proof, [],
          "The numerical axiom generator preserves a parameter already bound by an outer Pi.")
    fake_atom = ["=", ["pi", truth, truth], -1]
    judgment("numerical_schema_fake_atom", False, [], truth, ["nat", fake_atom],
             "Placing a quantified formula into an equality's term slot does not bypass the induction restriction.")
    judgment("numerical_schema_old_rule_arity", False, [], truth,
             ["nat", ["=", 0, 0], -1, ["hyp", truth], ["hyp", truth]],
             "A counterfeit old-style numerical rule is not a valid schema leaf.")
    for i, bad in enumerate([True, 0.0, -1, [], ["=", True, True], ["pi", truth], ["false", 0]]):
        judgment(f"numerical_schema_invalid_matrix_{i:02d}", False, [], truth, ["nat", bad],
                 "The matrix must satisfy formula validation before its root determines the induction branch.")

    # Targeted differential binder checks: independent names versus the
    # checker's shift/inst operations.  This is finite coverage, not fuzzing.
    env = ["x", "p", "q"]
    x, p, q = map(var, env)
    syntax = [ZERO, x, p, q, succ(x),
              rec(x, p, "u", "k", succ(var("u"))),
              rec(q, x, "u", "k", rec(var("u"), p, "v", "j", succ(var("k")))),
              eq(x, p),
              pi("b", eq(var("b"), x), eq(rec(x, p, "u", "k", var("b")), q)),
              sig("b", eq(x, var("b")), pi("c", eq(var("b"), q), eq(x, var("c"))))]
    for i, fixture in enumerate(syntax):
        encoded = encode(fixture, env)
        for amount in (0, 1, 2, 4):
            expected = encode(fixture, [*(f"shift_{j}" for j in range(amount)), *env])
            helper(f"shift_named_{i:02d}_{amount}", kernel.shift(encoded, amount), expected,
                   "Fresh named binders give the expected shift without using index-shifting code.")
        for j, term in enumerate([ZERO, p, succ(q), rec(p, q, "v", "j", succ(var("v")))]):
            expected = encode(substitute(fixture, {"x": term}), ["p", "q"])
            actual = kernel.inst(encoded, encode(term, ["p", "q"]))
            helper(f"inst_named_{i:02d}_{j}", actual, expected,
                   "Named simultaneous substitution preserves protected numerical and logical binders.")

    # Run actual entry-point processes for representative successes,
    # rejections, and malformed JSON, not just the in-process API.
    cli_names = ["derived_reflexivity_nested_rec", "transport_under_pi_and_nested_rec",
                 "numerical_schema_06", "pair_retained_context", "false_to_clash", "clash_to_false",
                 "hyp_lookup_alias_01", "invalid_alias_goal_01", "invalid_term_04",
                 "pi_captured_context", "pair_captured_witness", "use_sigma_witness_escape",
                 "counterfeit_compound_induction_06", "numerical_schema_fake_atom", "malformed_root_05"]
    by_name = {row["name"]: row for row in records}
    for name in cli_names:
        row = by_name[name]
        completed = subprocess.run([sys.executable, str(checker_path), str(HERE / row["certificate"])],
                                   capture_output=True, text=True, timeout=20)
        expected_code = 0 if row["expected"] == "ACCEPT" else 1
        good = (completed.returncode == expected_code and completed.stdout.strip() == row["expected"]
                and not completed.stderr)
        cli_records.append({"name": name, "pass": good, "exit_code": completed.returncode,
                            "stdout": completed.stdout.strip(), "stderr": completed.stderr})
        if not good:
            raise AssertionError(("CLI mismatch", name, completed))
    invalid_json = HERE / "malformed.json"
    invalid_json.write_text('{"assumptions": [], "goal": ["=", -1, -1], "proof": ') 
    completed = subprocess.run([sys.executable, str(checker_path), str(invalid_json)],
                               capture_output=True, text=True, timeout=20)
    good = completed.returncode == 1 and completed.stdout.strip() == "REJECT" and not completed.stderr
    cli_records.append({"name": "malformed_json", "pass": good, "exit_code": completed.returncode,
                        "stdout": completed.stdout.strip(), "stderr": completed.stderr})
    if not good:
        raise AssertionError(("malformed JSON CLI mismatch", completed))

    result = {
        "checker": str(checker_path),
        "checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
        "independent_of_compiler": True,
        "expectation_method": "Direct mathematical fixtures plus separate named-variable encoding and simultaneous substitution.",
        "summary": {"certificate_cases": len(records),
                    "expected_accept": sum(row["expected"] == "ACCEPT" for row in records),
                    "expected_reject": sum(row["expected"] == "REJECT" for row in records),
                    "binder_comparisons": len(helper_records), "cli_processes": len(cli_records),
                    "all_passed": all(row["pass"] for row in records + helper_records + cli_records)},
        "certificate_cases": records, "binder_comparisons": helper_records, "cli_processes": cli_records,
        "scope": "Finite targeted source/behavior audit. This does not formally prove checker soundness, bi-interpretability, or host-language semantics.",
        "accepted_key_aliases": "Python-equal numeric aliases are allowed only as hypothesis lookup keys; the stored validated formula is returned. Such aliases in asserted syntax are rejected."
    }
    (HERE / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"checker_sha256": result["checker_sha256"], **result["summary"]}, indent=2))


if __name__ == "__main__":
    main()
