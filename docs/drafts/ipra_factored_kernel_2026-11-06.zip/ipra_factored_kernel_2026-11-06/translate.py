"""Untrusted bidirectional certificate compiler.

The source is the exact supplied checked_presentation checker saved at
ablation/baseline_original.py.  The target is checker.py.  Both source
and resulting certificates are checked.  Neither checker imports this
module.  This file is outside the trusted checking boundary.
"""

import argparse
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


old = load("ipra_baseline", HERE / "ablation/baseline_original.py")
new = load("ipra_candidate", HERE / "checker.py")


def normalize(a):
    """Translate tagged zero to sentinel zero, preserving public falsity."""
    if a == ["z"]:
        return new.ZERO
    return list(map(normalize, a)) if type(a) is list else a


def denormalize(a):
    """Translate sentinel zero to tagged zero, preserving public falsity."""
    if type(a) is int and a == new.ZERO:
        return old.ZERO
    return list(map(denormalize, a)) if type(a) is list else a


def insert_number(a, protected=0):
    """Insert one ambient number below protected local numerical slots."""
    return old.walk(a, lambda i, d: i + d + 1, protected)


def lift_old(proof, context, protected=0):
    """Weaken a baseline proof by one fresh ambient numerical parameter.

    Formula-keyed hypotheses need no separate positional reindexing.
    Proof-level binders protect their number slots; walk handles syntax
    binders independently.  New assumptions may be added by weakening.
    """
    def syntax(a, extra=0):
        return insert_number(a, protected + extra)

    def subproof(p, extra=0, local_context=None):
        return lift_old(p, context if local_context is None else local_context,
                        protected + extra)

    match proof:
        case ["hyp", _]:
            return ["hyp", syntax(old.infer(proof, context))]
        case ["pi", a, q]:
            extended = [*map(old.shift, context), a]
            return ["pi", syntax(a, 1), subproof(q, 1, extended)]
        case ["app", p, t, q]:
            return ["app", subproof(p), syntax(t), subproof(q)]
        case ["pair", a, t, p, q]:
            return ["pair", syntax(a), syntax(t), subproof(p), subproof(q)]
        case ["let", p, c, q]:
            principal = old.infer(p, context)
            extended = [*map(old.shift, context), *principal[1:]]
            return ["let", subproof(p), syntax(c), subproof(q, 1, extended)]
        case ["eq", p, a, q]:
            return ["eq", subproof(p), syntax(a, 1), subproof(q)]
        case ["rec", r]:
            return ["rec", syntax(r)]
        case ["nat", a]:
            return ["nat", syntax(a, 1)]
        case _:
            raise ValueError("unknown baseline proof constructor")


def reflexivity(kernel, elimination_tag, t):
    """Derive t=t from one R0 instance and equality replacement."""
    p = ["rec", ["r", kernel.ZERO, t, kernel.ZERO]]
    return [elimination_tag, p, ["=", 0, kernel.shift(t)], p]


def new_symmetry(p, left):
    return ["use", p, ["=", 0, new.shift(left)],
            reflexivity(new, "use", left)]


def forward_proof(proof, context):
    """Compile any valid baseline proof under its canonical old context."""
    def subproof(p):
        return forward_proof(p, context)

    match proof:
        case ["hyp", _]:
            return ["hyp", normalize(old.infer(proof, context))]
        case ["pi", a, q]:
            extended = [*map(old.shift, context), a]
            return ["pi", normalize(a), forward_proof(q, extended)]
        case ["app", p, t, q]:
            return ["use", subproof(p), normalize(t), subproof(q)]
        case ["let", p, c, q]:
            principal = old.infer(p, context)
            extended = [*map(old.shift, context), *principal[1:]]
            return ["use", subproof(p), normalize(c), forward_proof(q, extended)]
        case ["eq", p, a, q]:
            return ["use", subproof(p), normalize(a), subproof(q)]
        case ["rec", r]:
            return ["rec", normalize(r)]
        case ["nat", a]:
            return ["nat", normalize(a)]
        case ["pair", a, t, p, q]:
            witness_equation = ["=", 0, old.shift(t)]
            extended = [*map(old.shift, context), witness_equation]
            backwards = new_symmetry(["hyp", normalize(witness_equation)], 0)

            def branch(matrix, premise):
                template = new.walk(normalize(matrix), lambda i, d: i + d + 1, 1)
                return ["use", backwards, template,
                        forward_proof(lift_old(premise, context), extended)]

            return ["pair", normalize(t), branch(a[1], p), branch(a[2], q)]
        case _:
            raise ValueError("unknown baseline proof constructor")


def backward_proof(proof, context):
    """Compile any valid candidate proof under its canonical new context."""
    def subproof(p):
        return backward_proof(p, context)

    match proof:
        case ["hyp", _]:
            return ["hyp", denormalize(new.infer(proof, context))]
        case ["pi", a, q]:
            extended = [*map(new.shift, context), a]
            return ["pi", denormalize(a), backward_proof(q, extended)]
        case ["use", p, a, q]:
            principal = new.infer(p, context)
            tag = principal[0]
            if tag == "sig":
                extended = [*map(new.shift, context), *principal[1:]]
                return ["let", subproof(p), denormalize(a),
                        backward_proof(q, extended)]
            old_tag = {"=": "eq", "pi": "app"}[tag]
            return [old_tag, subproof(p), denormalize(a), subproof(q)]
        case ["pair", t, p, q]:
            equation = ["=", 0, new.shift(t)]
            extended = [*map(new.shift, context), equation]
            witness = denormalize(t)
            principal = denormalize(new.infer(proof, context))
            reflexive = reflexivity(old, "eq", witness)

            def branch(premise):
                # Discharge y=t, then instantiate y at t with t=t.
                universal = ["pi", denormalize(equation),
                             backward_proof(premise, extended)]
                return ["app", universal, witness, reflexive]

            return ["pair", principal, witness, branch(p), branch(q)]
        case ["rec", r]:
            return ["rec", denormalize(r)]
        case ["nat", a]:
            return ["nat", denormalize(a)]
        case _:
            raise ValueError("unknown candidate proof constructor")


def forward(document):
    old.check(document)
    context, _, proof = map(old.erase,
                           (document["assumptions"], document["goal"], document["proof"]))
    result = {"assumptions": normalize(document["assumptions"]),
              "goal": normalize(document["goal"]),
              "proof": forward_proof(proof, context)}
    new.check(result)
    return result


def backward(document):
    new.check(document)
    context, _, proof = map(new.erase,
                           (document["assumptions"], document["goal"], document["proof"]))
    result = {"assumptions": denormalize(document["assumptions"]),
              "goal": denormalize(document["goal"]),
              "proof": backward_proof(proof, context)}
    old.check(result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("direction", choices=("forward", "backward"))
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    document = json.loads(args.input.read_text())
    result = {"forward": forward, "backward": backward}[args.direction](document)
    args.output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
