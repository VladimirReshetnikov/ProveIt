"""Reproduce checks, compile the report, and create a portable ZIP archive."""

import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent


def files():
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if (path.is_file() and not any(p in {"build", "__pycache__"} for p in relative.parts)
                and path.suffix != ".pyc" and path.name not in {"SHA256SUMS.txt"}):
            yield path


def package():
    inventory = list(files())
    hashes = "".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  "
                     + path.relative_to(ROOT).as_posix() + "\n" for path in inventory)
    (ROOT / "SHA256SUMS.txt").write_text(hashes)
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in [*inventory, ROOT / "SHA256SUMS.txt"]:
            info = zipfile.ZipInfo((Path(ROOT.name) / path.relative_to(ROOT)).as_posix(),
                                   date_time=(2026, 11, 6, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    print(target.name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        subprocess.run([sys.executable, str(ROOT / "run_checks.py")], cwd=ROOT, check=True)
        build = ROOT / "build"
        build.mkdir(exist_ok=True)
        for extension in ("aux", "toc", "out", "log", "pdf"):
            (build / ("report." + extension)).unlink(missing_ok=True)
        for i in range(3):
            command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                       "-output-directory=" + str(build), "report.tex"]
            completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
            (build / ("pass_" + str(i + 1) + ".txt")).write_text(completed.stdout + completed.stderr)
            if completed.returncode:
                raise RuntimeError("LaTeX compilation failed; inspect build logs")
        log = (build / "report.log").read_text()
        for marker in ("Overfull \\hbox", "Overfull \\vbox", "undefined references",
                       "There were undefined", "Label(s) may have changed"):
            if marker in log:
                raise RuntimeError("Unresolved LaTeX layout/reference issue: " + marker)
        shutil.copy2(build / "report.pdf", ROOT / "report.pdf")
    if not (ROOT / "report.pdf").is_file():
        raise ValueError("Compile report.pdf before packaging")
    package()


if __name__ == "__main__":
    main()
