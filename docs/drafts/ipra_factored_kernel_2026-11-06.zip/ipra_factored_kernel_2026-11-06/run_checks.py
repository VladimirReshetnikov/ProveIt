"""Reproduce the package's finite verification and source-size comparison."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for script in ("make_ablation.py", "verify_compilers.py", "audit/audit.py", "measure.py"):
        completed = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT,
                                   capture_output=True, text=True, timeout=120)
        if completed.returncode:
            raise RuntimeError(script + " failed:\n" + completed.stdout + completed.stderr)
        print(script + ": PASS")
    translations = json.loads((ROOT / "translation_results.json").read_text())
    audit = json.loads((ROOT / "audit/results.json").read_text())
    metrics = json.loads((ROOT / "verification/metrics.json").read_text())
    sha = hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest()
    if translations["candidate_sha256"] != sha or audit["checker_sha256"] != sha:
        raise ValueError("Different checker versions were tested")
    if not audit["summary"]["all_passed"]:
        raise ValueError("Independent audit failed")
    summary = {
        "checker_sha256": sha,
        "baseline_roundtrips": translations["baseline_roundtrips"],
        "native_roundtrips": translations["candidate_roundtrips"],
        "ablation_controls": translations["ablation_controls"],
        "certificates_per_control": translations["certificate_replays_per_control"],
        "exact_public_endpoints": translations["public_goals_and_assumptions_restored_exactly"],
        "independent_audit": audit["summary"],
        "candidate_metrics": metrics["candidate"],
        "all_passed": True,
        "scope": "Finite executable evidence; universal metatheorems are proved in the mathematical report, not in Lean or Rocq.",
    }
    (ROOT / "verification/summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    checks = r"""The delivered run passed all of the following:
\begin{itemize}
\item 53 supplied baseline certificates compiled forward and back, with exactly restored public goals and assumption lists; both verifiers checked their respective certificates.
\item 16 additional native certificates compiled backward and forward, including dependent and nested witnesses, numerical schemas under witnesses, nested recursion, public falsity, and large free parameters.
\item All four matched ablation controls replayed all 53 appropriately translated source certificates. An additional lookup-key alias case was checked beneath an inserted binder.
\item An independent audit, importing neither compiler nor package proof builders, checked 149 JSON cases: 43 intended accepts and 106 intended rejects. It compared 80 binding operations against a separately encoded named-variable syntax and ran 16 actual CLI processes.
\end{itemize}
The independent rejection cases include malformed syntax, invalid numerical aliases in assertions, captured retained contexts, escaping existential witnesses, wrong elimination guards, malformed numerical schemas, and counterfeit induction for compound formulas. Positive controls ensure these checks do not merely reject valid use of parameters or witnesses. The audit and compiler runs checked the identical SHA-256 version of the trusted file.
"""
    (ROOT / "verification/checks.tex").write_text(checks)
    print(json.dumps({"all_passed": True, "checker_sha256": sha,
                      "baseline_roundtrips": summary["baseline_roundtrips"],
                      "native_roundtrips": summary["native_roundtrips"],
                      "audit": audit["summary"]}, indent=2))


if __name__ == "__main__":
    main()
