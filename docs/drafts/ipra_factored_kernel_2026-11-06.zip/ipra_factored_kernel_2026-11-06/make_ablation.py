"""Create matched controls; no output of this script is trusted by a checker."""
from pathlib import Path
import ast
import hashlib
import io
import json
import tokenize

HERE = Path(__file__).resolve().parent
OUT = HERE / 'ablation'
SOURCE = OUT / 'baseline_original.py'
OUT.mkdir(exist_ok=True)
HEADER = '"""Matched complete-checker control. Enabled changes are listed in ablation.json."""\n'

def header(source):
    node = ast.parse(source).body[0]
    assert isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant)
    return HEADER + '\n'.join(source.splitlines()[node.end_lineno:]) + '\n'

original = SOURCE.read_text()
(OUT / 'baseline_original.py').write_text(original)
baseline = header(original)
shared = baseline
start = shared.index('        case ["app",')
end = shared.index('        case ["pair",')
shared = shared[:start] + '''        case ["use", p, a, q]:
            e = infer(p, g)
            tag = e[0]
            require(tag in ("=", "pi", "sig") and wf(a, tag != "pi"))
            if tag == "sig":
                require(infer(q, [*map(shift, g), *e[1:]]) == shift(a))
                return a
            b, c = (inst(a, t) if tag == "=" else inst(t, a) for t in e[1:])
            require(infer(q, g) == b)
            return c
''' + shared[end:]
start = shared.index('        case ["let",')
end = shared.index('        case ["rec",')
shared = shared[:start] + shared[end:]
witness = shared
start = witness.index('        case ["pair",')
end = witness.index('        case ["rec",')
witness = witness[:start] + '''        case ["pair", t, p, q]:
            require(wf(t))
            h = [*map(shift, g), ["=", 0, shift(t)]]
            return ["sig", infer(p, h), infer(q, h)]
''' + witness[end:]
sentinel = witness.replace('ZERO = ["z"]', 'ZERO = -1').replace(
    'return not formula and a >= 0\n        case ["z"]:\n            return not formula',
    'return not formula and a >= -1')
assert sentinel == header((HERE / 'checker.py').read_text())
variants = [
    ('00_baseline.py', 'Baseline, with a common documentation header', baseline),
    ('01_shared.py', 'Shared equality/Pi/Sigma elimination only', shared),
    ('02_witness.py', 'Shared elimination plus witnessed Sigma introduction', witness),
    ('03_sentinel.py', 'Shared elimination, witnessed Sigma, integer sentinel zero', sentinel),
]
for name, _, source in variants:
    (OUT / name).write_text(source)

def measure(path):
    data = path.read_bytes()
    source = data.decode()
    tree = ast.parse(source)
    spans = []
    for node in list(ast.walk(tree)):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
                doc = node.body.pop(0)
                spans.append(((doc.lineno,doc.col_offset),(doc.end_lineno,doc.end_col_offset)))
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in ignored and not any(a <= t.start and t.end <= b for a,b in spans)]
    normalized = ast.unparse(tree) + '\n'
    normalized_tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
                         if t.type not in ignored]
    return {'raw_utf8_bytes': len(data), 'normalized_utf8_bytes': len(normalized.encode()),
            'significant_source_tokens': len(tokens), 'normalized_python_tokens': len(normalized_tokens),
            'ast_nodes_without_docstrings': sum(1 for _ in ast.walk(tree)),
            'physical_lines': len(source.splitlines()), 'sha256': hashlib.sha256(data).hexdigest()}

rows = [{'file': 'ablation/' + name, 'change': description, **measure(OUT / name)}
        for name,description,_ in variants]
keys = ['raw_utf8_bytes', 'normalized_utf8_bytes', 'significant_source_tokens',
        'normalized_python_tokens', 'ast_nodes_without_docstrings']
result = {
    'boundary': 'Every complete checker, including standard-library JSON CLI, syntax validation, and public falsity normalization. Excludes Python runtime and standard library equally; excludes all compilers, tests and measurement scripts.',
    'counting': 'Source significant tokens exclude comments, whitespace/layout, and genuine module/function/class docstrings. Normalized tokens and bytes use ast.unparse after deleting only genuine docstrings. AST nodes exclude those docstrings. Raw bytes include documentation and whitespace.',
    'matched_headers': 'All four controls have identical module documentation, so raw-byte ablation changes describe code rather than header rewriting. baseline_original.py is also an exact source copy; the public candidate differs from control 03 only in module documentation.',
    'baseline_original': {'file':'ablation/baseline_original.py',**measure(OUT/'baseline_original.py')},
    'candidate': {'file':'checker.py',**measure(HERE/'checker.py')},
    'variants': rows,
    'steps': [{'from':a['file'],'to':b['file'],'savings':{k:a[k]-b[k] for k in keys}}
              for a,b in zip(rows,rows[1:])],
    'total_savings': {k: rows[0][k]-rows[-1][k] for k in keys},
    'limitation': 'An implementation-relative finite comparison; neither global minimality nor runtime/proof-length improvement is asserted.'
}
(OUT / 'ablation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'rows': [{k:r[k] for k in ['file']+keys} for r in rows], 'total_savings':result['total_savings']},indent=2))
