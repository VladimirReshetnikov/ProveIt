A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026
================================================

RESULT

The proposed public theory K* is equiconsistent and bi-interpretable with
full first-order intuitionistic primitive recursive arithmetic with
quantifier-free induction. Both interpretations use the whole number domain.
Their composites are internally isomorphic to the identity by equality.

The complete verifier is checker.py: 996 significant Python source tokens,
1,053 AST nodes after docstring removal, and 3,252 normalized executable
UTF-8 bytes. All syntax validation, substitutions, arithmetic data, public
falsity conversion, inference checks, and JSON CLI code are included.

The six current source archives at ProveIt commit
39c2b3c738e4cacbc0b2cb31f093c1eb4f976e75
were inspected. Their identified current candidates and controls have
coordinate minima of 1,089 tokens, 1,154 AST nodes, and 3,486 normalized bytes.
The new verifier is below those minima by 8.54%, 8.75%, and 6.71%.
This is a reproducible finite source comparison, not a global minimality
theorem over all possible languages or certificate representations.

START HERE

report.pdf                  Complete mathematical report and source listing.
report.tex + sections/      Complete rebuildable LaTeX sources.
SPECIFICATION.txt           Concise complete calculus and side conditions.
FORMAT.txt                  Exact public JSON and certificate grammar.
checker.py                  The entire trusted acceptance program.

The reduction combines the supplied drafts' shared elimination and
witness-equation introduction with the smallest current checker's numerical
schema and faithful public falsity encoding. A zero sentinel supplies a
smaller independent serialization reduction. With ordinary tagged zero the
combined checker is already below the current envelope at 1,004 tokens.

THEORY AND FALSITY

Terms have zero, successor, variables, and finite initialized recursion.
Public formulas have equality, genuine bottom, Pi_x(A;B)=forall x(A->B),
and Sigma_x(A;B)=exists x(A and B). The theory has six logical rule patterns,
two computation schemas, one numerical schema, and a fixed bottom bridge.
The numerical schema permits an induction hypothesis only for literal
equations; for other formulas it supplies numerical cases.

The checker encodes public bottom as 0=S0. The report proves exact sequent
adequacy for arbitrary assumptions and quantified formulas. The ordinary
positive reduct alone is NOT the theory claimed bi-interpretable with iPRA:
it has singleton models. The public theory retains genuine logical falsity
and separation, through the proved representation theorem.

VERIFICATION

53 baseline certificates compile in both directions, preserving exactly
their public goals and assumptions. 16 new native certificates also
round-trip. All four matched ablation controls replay all 53 source cases.
An independent audit checks 149 cases (43 accepts, 106 rejects), compares
80 binding operations with named-variable syntax, and runs 16 CLI processes.
The independent audit does not import the compiler or package proof builders.

General soundness, reflection, coherence, and bi-interpretability are written
mathematical proofs. No Lean/Rocq formalization of those metatheorems or of
Python semantics is claimed. The finite tests complement those proofs.

RUN (Python 3.10 or later; standard library only)

  python3 run_checks.py
  python3 checker.py certificates/legacy_reflexivity_derived.json
  python3 checker.py certificates/legacy_equation_induction_addition.json
  python3 measure.py

The checker prints ACCEPT and exits 0 for an accepted certificate; rejected
inputs print REJECT and exit 1. A nonempty assumptions list describes only
the corresponding sequent. Free number parameters are permitted.

PROOF COMPILATION

The comparison baseline is the complete checker from the current
ipra_checked_presentation_2026-11-06.zip package, copied verbatim as
ablation/baseline_original.py.

  python3 translate.py forward OLD.json NEW.json
  python3 translate.py backward NEW.json EXPANDED_OLD.json

Both commands validate their input and output with the relevant complete
checkers. The compiler is not trusted by checker.py. Compiler syntax applies
to this named baseline; it is not a universal adapter for every older draft.

REBUILD PDF AND ARCHIVE

A standard pdflatex installation and the packages listed in report.tex are
required for the report:

  python3 build.py

This runs the checks, generates measurement and verification tables, compiles
three LaTeX passes, rejects overfull boxes/unresolved references, refreshes
SHA256SUMS.txt, and creates the ZIP beside this directory. Temporary build
files and Python bytecode are excluded. To package an already built PDF:

  python3 build.py --package-only

PACKAGE CONTENTS

ablation/                   Matched complete controls and exact baseline.
comparison/                 Exact sources for the current-candidate census.
provenance/                 Pinned archive/member identities and source review.
source_certificates/        The 53 supplied baseline fixtures, unchanged.
certificates/               Their translated candidate proofs.
roundtrip_certificates/     Checked reverse translations.
stress_certificates/        Additional native examples and their translations.
audit/                      Independent audit, fixtures, and detailed results.
verification/               Measurements, combined results, PDF review.
translate.py                Untrusted bidirectional proof compiler.
make_ablation.py            Reconstruct and measure the matched controls.
verify_compilers.py         Replay the compiler and control checks.
measure.py                  Recount all included comparison sources.
run_checks.py               Reproduce finite verification and report tables.
build.py                    PDF/ZIP reproduction.
SHA256SUMS.txt              Integrity hashes of all other packaged files.

ATTRIBUTION

The mathematical basis and component reductions originate in the supplied
ProveIt draft series. The report identifies each contribution and source.
The new contribution is their checked composition, the smaller complete
verifier, the bidirectional compiler, and the updated six-archive comparison.
All claims are pinned to the stated commit. No repository mutation is needed
to use the archive.
