"""Reproduce two checked compiler directions and matched control replays.

The test oracle is the independent supplied baseline checker. These are
finite executions, not a formal proof of universal compiler correctness.
The checker never imports this file.
"""

import hashlib
import json
from pathlib import Path

import translate as tr

HERE = Path(__file__).resolve().parent
K = tr.new


def write(path, document):
    path.parent.mkdir(exist_ok=True, parents=True)
    path.write_text(json.dumps(document, separators=(",", ":")) + "\n")


def check_endpoints(left, right):
    assert left["assumptions"] == right["assumptions"]
    assert left["goal"] == right["goal"]


def shared(proof):
    """Compile only the shared elimination change, retaining old Sigma I."""
    match proof:
        case ["hyp", _] | ["rec", _] | ["nat", _]:
            return proof
        case ["pi", a, q]:
            return ["pi", a, shared(q)]
        case [("app" | "eq" | "let"), p, a, q]:
            return ["use", shared(p), a, shared(q)]
        case ["pair", a, t, p, q]:
            return ["pair", a, t, shared(p), shared(q)]
        case _:
            raise ValueError("unknown baseline constructor")


def new_document(proof, assumptions=(), goal=None):
    assumptions = list(assumptions)
    inferred = K.infer(K.erase(proof), K.erase(assumptions))
    if goal is None:
        goal = inferred
    else:
        assert K.erase(goal) == inferred
    document = {"assumptions": assumptions, "goal": goal, "proof": proof}
    K.check(document)
    return document


def reflexivity(t):
    return tr.reflexivity(K, "use", t)


def native_stress():
    cases = {}
    witnesses = [K.ZERO, 0, 7, 1000000, ["s", 2],
                 ["r", ["s", K.ZERO], 0, ["s", 0]]]
    for i, t in enumerate(witnesses):
        equation = ["=", 0, K.shift(t)]
        proof = ["pair", t, ["hyp", equation], reflexivity(0)]
        goal = ["sig", equation, ["=", 0, 0]]
        cases[f"witness_parameter_{i}"] = new_document(proof, goal=goal)

    t = ["s", 2]
    equation = ["=", 0, K.shift(t)]
    antecedent = ["=", 0, 1]
    universal = ["pi", antecedent, ["hyp", K.shift(equation)]]
    rec = ["r", K.ZERO, 0, ["s", 0]]
    proof = ["pair", t, universal, ["rec", rec]]
    goal = ["sig", ["pi", antecedent, K.shift(equation)], ["=", rec, 0]]
    cases["witness_under_quantifier_and_recursion"] = new_document(proof, goal=goal)

    t = 2
    equation = ["=", 0, K.shift(t)]
    inner_equation = ["=", 0, 1]
    inner = ["pair", 0, ["hyp", inner_equation], ["hyp", K.shift(equation)]]
    proof = ["pair", t, inner, ["hyp", equation]]
    goal = ["sig", ["sig", inner_equation, K.shift(equation)], equation]
    cases["nested_dependent_witnesses"] = new_document(proof, goal=goal)

    cases["numerical_axioms_under_witness"] = new_document(
        ["pair", 4, ["nat", ["=", 0, 1]],
         ["nat", ["pi", ["=", 0, 0], ["=", 1, 1]]]])

    antecedent = ["=", 0, 0]
    pair = ["pair", 0, ["hyp", ["=", 0, 1]], ["hyp", K.shift(antecedent)]]
    cases["witness_under_pi"] = new_document(
        ["pi", antecedent, pair],
        goal=["pi", antecedent,
              ["sig", ["=", 0, 1], K.shift(antecedent)]])

    sigma = ["sig", ["=", 0, 0], ["=", 1, 1]]
    cases["shared_sigma_elimination"] = new_document(
        ["use", ["hyp", sigma], ["=", 0, 0], ["hyp", ["=", 1, 1]]],
        assumptions=[sigma], goal=["=", 0, 0])

    equation = ["=", 0, ["s", 1]]
    cases["shared_equality_elimination"] = new_document(
        ["use", ["hyp", equation], ["=", 1, 0], reflexivity(0)],
        assumptions=[equation], goal=equation)

    t = ["s", 1]
    universal = ["pi", ["=", 0, 0], ["hyp", ["=", 0, 0]]]
    cases["shared_pi_elimination"] = new_document(
        ["use", universal, t, reflexivity(t)], goal=["=", t, t])

    cases["public_falsity_under_witness"] = new_document(
        ["pair", K.ZERO, ["hyp", ["false"]], ["hyp", ["false"]]],
        assumptions=[["false"]], goal=["sig", ["false"], ["false"]])

    nested = ["r", ["s", K.ZERO], 0,
              ["r", ["s", K.ZERO], 0, ["s", 2]]]
    cases["nested_recursion_under_witness"] = new_document(
        ["pair", 6, ["rec", nested], reflexivity(0)])

    cases["hypothesis_alias_beneath_witness"] = new_document(
        ["pair", K.ZERO, ["hyp", ["=", 1.0, K.ZERO]],
         ["hyp", ["=", 1, K.ZERO]]],
        assumptions=[["=", 0, K.ZERO]],
        goal=["sig", ["=", 1, K.ZERO], ["=", 1, K.ZERO]])
    return cases


def main():
    controls = [tr.load(f"ablation_{i}", HERE / "ablation" / name)
                for i, name in enumerate(("00_baseline.py", "01_shared.py",
                                          "02_witness.py", "03_sentinel.py"))]
    archived = sorted((HERE / "source_certificates").glob("*.json"))
    assert len(archived) == 53
    records = []
    for path in archived:
        source = json.loads(path.read_text())
        candidate = tr.forward(source)
        restored = tr.backward(candidate)
        check_endpoints(source, restored)
        shared_document = {**source, "proof": shared(source["proof"])}
        controls[0].check(source)
        controls[1].check(shared_document)
        controls[2].check({k: tr.denormalize(v) for k, v in candidate.items()})
        controls[3].check(candidate)
        write(HERE / "certificates" / path.name, candidate)
        write(HERE / "roundtrip_certificates" / path.name, restored)
        records.append({"name": path.name,
                        "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest()})

    stress = native_stress()
    for name, candidate in stress.items():
        baseline = tr.backward(candidate)
        restored = tr.forward(baseline)
        check_endpoints(candidate, restored)
        write(HERE / "stress_certificates" / "candidate" / (name + ".json"), candidate)
        write(HERE / "stress_certificates" / "baseline" / (name + ".json"), baseline)
        write(HERE / "stress_certificates" / "restored" / (name + ".json"), restored)

    # Formula-keyed hypothesis lookup deliberately returns the stored valid
    # formula when Python equality matches a Boolean/float annotation. This
    # old proof becomes nested beneath a new binder during compilation.
    alias = {"assumptions": [["=", 0, ["z"]]],
             "goal": ["sig", ["=", 1, ["z"]], ["=", 1, ["z"]]],
             "proof": ["pair", ["sig", ["=", 1, ["z"]], ["=", 1, ["z"]]],
                       ["z"], ["hyp", ["=", False, ["z"]]],
                       ["hyp", ["=", 0.0, ["z"]]]]}
    check_endpoints(alias, tr.backward(tr.forward(alias)))
    write(HERE / "stress_certificates" / "source_alias.json", alias)

    result = {
        "scope": "Finite checked proof compilation and source-control replay; no formal universal soundness or bi-interpretability verification.",
        "baseline_roundtrips": len(archived),
        "baseline_records": records,
        "candidate_roundtrips": len(stress),
        "candidate_stress_cases": list(stress),
        "hypothesis_alias_under_inserted_binder": True,
        "public_goals_and_assumptions_restored_exactly": True,
        "ablation_controls": len(controls),
        "certificate_replays_per_control": len(archived),
        "candidate_sha256": hashlib.sha256((HERE / "checker.py").read_bytes()).hexdigest(),
    }
    (HERE / "translation_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("baseline_records", "candidate_stress_cases")}, indent=2))


if __name__ == "__main__":
    main()
