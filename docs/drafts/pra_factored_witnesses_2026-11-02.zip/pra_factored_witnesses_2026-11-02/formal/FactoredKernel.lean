import Std

/-!
# Factored witnesses: independently checked local kernels

The first part works over an arbitrary carrier and proves that the merged
discriminator, computational equations, and nontriviality recover separation,
successor injectivity, successor nonzeroness, and decidable equality.

The second part checks the factored induction argument without using induction
on the carrier. Functions and predicates are metatheoretic parameters here;
the first-order theory does not quantify over functions or predicates.

The last part checks an explicit primitive-recursive boundary scan on Nat.
Its invariant is quantifier-free when the displayed functions are arithmetic
symbols. This validates the local witness construction, not an internalized
PRA derivation checker, the staged syntax, pairing, or the full interpretation
metatheorem. No `sorry`, additional axiom, choice, or classical tactic is used.
-/

namespace FactoredWitnesses

universe u

/-- The two-symbol computational seed; successor is the diagonal of D. -/
structure Seed (A : Type u) where
  zero : A
  D : A → A → A
  Q : A → A → A
  nontrivial : ∃ x, x ≠ zero
  off : ∀ x y, x = y ∨ D x y = zero
  q_zero : ∀ a, Q zero a = a
  q_diagonal : ∀ x a, Q (D x x) a = x

namespace Seed

variable {A : Type u} (K : Seed A)

def succ (x : A) : A := K.D x x

/-- Nontriviality and Q alone imply that zero differs from its successor. -/
theorem separated : K.zero ≠ K.succ K.zero := by
  intro h
  obtain ⟨a, ha⟩ := K.nontrivial
  apply ha
  have he := K.q_diagonal K.zero a
  change K.Q (K.succ K.zero) a = K.zero at he
  rw [← h, K.q_zero] at he
  exact he

theorem succ_injective (x y : A) (h : K.succ x = K.succ y) : x = y := by
  have he := congrArg (fun z => K.Q z K.zero) h
  simpa only [succ, K.q_diagonal] using he

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro h
  have hx : x = K.zero := by
    have he := congrArg (fun z => K.Q z K.zero) h
    simpa only [succ, K.q_diagonal, K.q_zero] using he
  have hz : K.succ K.zero = K.zero := by
    simpa only [hx] using h
  exact K.separated hz.symm

include K in
theorem eq_or_ne (x y : A) : x = y ∨ x ≠ y := by
  rcases K.off x y with he | hz
  · exact Or.inl he
  · refine Or.inr ?_
    intro he
    subst y
    exact K.succ_ne_zero x hz

theorem discriminator_zero_iff (x y : A) : K.D x y = K.zero ↔ x ≠ y := by
  constructor
  · intro hz he
    subst y
    exact K.succ_ne_zero x hz
  · intro hne
    rcases K.off x y with he | hz
    · exact False.elim (hne he)
    · exact hz

/-- Atomic truth values need not be normalized to the numeral one. -/
theorem discriminator_truth (x y : A) :
    (x = y ∧ ∃ z, K.D x y = K.succ z) ∨
      (x ≠ y ∧ K.D x y = K.zero) := by
  rcases K.off x y with he | hz
  · left
    refine ⟨he, x, ?_⟩
    subst y
    rfl
  · right
    exact ⟨(K.discriminator_zero_iff x y).mp hz, hz⟩

end Seed

section InductionKernel

variable {A : Type u} (zero : A) (succ : A → A) (Q : A → A → A)
variable (q_zero : ∀ a, Q zero a = a)
variable (q_succ : ∀ x a, Q (succ x) a = x)

include q_zero q_succ in
/-- The factored witness forces every marker to vanish if vanishing progresses.
No coverage, separation, or induction principle on A is assumed. -/
theorem factored_all_zero (F : A → A)
    (marker : ∀ x, F x = zero ∨ F x = x)
    (witness : ∀ n, ∃ b c, c = Q (F (succ b)) n ∧ F c = zero)
    (progress : ∀ x, F x = zero → F (succ x) = zero) :
    ∀ n, F n = zero := by
  intro n
  obtain ⟨b, c, hc, hfc⟩ := witness n
  have hs : F (succ b) = zero := by
    rcases marker (succ b) with hz | he
    · exact hz
    · have hcb : c = b := by
        simpa only [he, q_succ] using hc
      apply progress b
      simpa only [hcb] using hfc
  have hcn : c = n := by
    simpa only [hs, q_zero] using hc
  simpa only [hcn] using hfc

include q_zero q_succ in
/-- The unshifted variant uses zero-or-successor coverage. -/
theorem unshifted_all_zero (F : A → A)
    (cover : ∀ x, x = zero ∨ ∃ y, x = succ y)
    (marker : ∀ x, F x = zero ∨ F x = x)
    (witness : ∀ n, ∃ b c, c = Q (F b) n ∧ F c = zero)
    (progress : ∀ x, F x = zero → F (succ x) = zero) :
    ∀ n, F n = zero := by
  intro n
  obtain ⟨b, c, hc, hfc⟩ := witness n
  have hb : F b = zero := by
    rcases marker b with hz | he
    · exact hz
    · rcases cover b with hbz | ⟨d, hbd⟩
      · exact he.trans hbz
      · have hfb : F b = succ d := he.trans hbd
        have hcd : c = d := by
          simpa only [hfb, q_succ] using hc
        have hfd : F d = zero := by
          simpa only [hcd] using hfc
        simpa only [hbd] using progress d hfd
  have hcn : c = n := by
    simpa only [hb, q_zero] using hc
  simpa only [hcn] using hfc

/-- A zero marker reflects the predicate under its local induction base. -/
theorem reflect_zero {P : A → Prop} {F : A → A}
    (decideP : ∀ x, P x ∨ ¬P x)
    (when_false : ∀ x, ¬P x → F x = x)
    (base : P zero) (x : A) (hx : F x = zero) : P x := by
  rcases decideP x with hp | hn
  · exact hp
  · have he : x = zero := (when_false x hn).symm.trans hx
    exact he.symm ▸ base

include q_zero q_succ in
/-- The local mathematical deduction of the full induction implication. -/
theorem induction_transfer {P : A → Prop} {F : A → A}
    (decideP : ∀ x, P x ∨ ¬P x)
    (when_true : ∀ x, P x → F x = zero)
    (when_false : ∀ x, ¬P x → F x = x)
    (witness : ∀ n, ∃ b c, c = Q (F (succ b)) n ∧ F c = zero)
    (base : P zero)
    (step : ∀ x, P x → P (succ x)) : ∀ n, P n := by
  have marker : ∀ x, F x = zero ∨ F x = x := by
    intro x
    rcases decideP x with hp | hn
    · exact Or.inl (when_true x hp)
    · exact Or.inr (when_false x hn)
  have progress : ∀ x, F x = zero → F (succ x) = zero := by
    intro x hx
    exact when_true (succ x)
      (step x (reflect_zero zero decideP when_false base x hx))
  have all_zero := factored_all_zero zero succ Q q_zero q_succ
    F marker witness progress
  intro n
  exact reflect_zero zero decideP when_false base n (all_zero n)

end InductionKernel

namespace NatWitness

def selector : Nat → Nat → Nat
  | 0, a => a
  | Nat.succ x, _ => x

def gate : Nat → Nat → Nat
  | 0, a => a
  | Nat.succ _, _ => 0

def mask (t : Nat → Nat) (x : Nat) : Nat := gate (t x) x

/-- The last zero encountered strictly before the current counter. -/
def boundary (F : Nat → Nat) : Nat → Nat
  | 0 => 0
  | Nat.succ n => if F n = 0 then n else boundary F n

/-- This is a quantifier-free invariant in the arithmetic function language. -/
theorem boundary_invariant (F : Nat → Nat) (hzero : F 0 = 0) (n : Nat) :
    F (boundary F n) = 0 ∧
      (F n = 0 ∨ F (Nat.succ (boundary F n)) ≠ 0) := by
  induction n with
  | zero =>
      exact ⟨hzero, Or.inl hzero⟩
  | succ n ih =>
      by_cases hn : F n = 0
      · simp only [boundary, if_pos hn]
        constructor
        · exact hn
        · by_cases hs : F (Nat.succ n) = 0
          · exact Or.inl hs
          · exact Or.inr hs
      · simp only [boundary, if_neg hn]
        constructor
        · exact ih.1
        · by_cases hs : F (Nat.succ n) = 0
          · exact Or.inl hs
          · rcases ih.2 with hprev | hboundary
            · exact False.elim (hn hprev)
            · exact Or.inr hboundary

theorem boundary_is_witness (F : Nat → Nat) (hzero : F 0 = 0)
    (marker : ∀ x, F x = 0 ∨ F x = x) (n : Nat) :
    F (selector (F (Nat.succ (boundary F n))) n) = 0 := by
  have hi := boundary_invariant F hzero n
  rcases marker (Nat.succ (boundary F n)) with hz | he
  · rw [hz, selector]
    rcases hi.2 with hn | hboundary
    · exact hn
    · exact False.elim (hboundary hz)
  · rw [he, selector]
    exact hi.1

theorem shifted_factored_witness (F : Nat → Nat) (hzero : F 0 = 0)
    (marker : ∀ x, F x = 0 ∨ F x = x) (n : Nat) :
    ∃ b c, c = selector (F (Nat.succ b)) n ∧ F c = 0 := by
  refine ⟨boundary F n, selector (F (Nat.succ (boundary F n))) n, rfl, ?_⟩
  exact boundary_is_witness F hzero marker n

theorem unshifted_factored_witness (F : Nat → Nat) (hzero : F 0 = 0)
    (marker : ∀ x, F x = 0 ∨ F x = x) (n : Nat) :
    ∃ b c, c = selector (F b) n ∧ F c = 0 := by
  refine ⟨Nat.succ (boundary F n),
    selector (F (Nat.succ (boundary F n))) n, rfl, ?_⟩
  exact boundary_is_witness F hzero marker n

theorem mask_zero (t : Nat → Nat) : mask t 0 = 0 := by
  unfold mask
  cases t 0 <;> rfl

theorem mask_marker (t : Nat → Nat) (x : Nat) :
    mask t x = 0 ∨ mask t x = x := by
  unfold mask
  cases t x with
  | zero => exact Or.inr rfl
  | succ n => exact Or.inl rfl

/-- Every arithmetic payload admits the required two numerical witnesses. -/
theorem every_payload_has_shifted_witness (t : Nat → Nat) (n : Nat) :
    ∃ b c,
      c = selector (gate (t (Nat.succ b)) (Nat.succ b)) n ∧
      gate (t c) c = 0 := by
  exact shifted_factored_witness (mask t) (mask_zero t) (mask_marker t) n

theorem every_payload_has_unshifted_witness (t : Nat → Nat) (n : Nat) :
    ∃ b c, c = selector (gate (t b) b) n ∧ gate (t c) c = 0 := by
  exact unshifted_factored_witness (mask t) (mask_zero t) (mask_marker t) n

end NatWitness

#print axioms Seed.separated
#print axioms Seed.succ_injective
#print axioms Seed.succ_ne_zero
#print axioms Seed.eq_or_ne
#print axioms Seed.discriminator_zero_iff
#print axioms Seed.discriminator_truth
#print axioms factored_all_zero
#print axioms unshifted_all_zero
#print axioms reflect_zero
#print axioms induction_transfer
#print axioms NatWitness.boundary_invariant
#print axioms NatWitness.boundary_is_witness
#print axioms NatWitness.every_payload_has_shifted_witness
#print axioms NatWitness.every_payload_has_unshifted_witness

end FactoredWitnesses
