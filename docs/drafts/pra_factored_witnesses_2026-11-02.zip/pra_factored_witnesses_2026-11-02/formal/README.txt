LEAN VERIFICATION SCOPE

File: FactoredKernel.lean
Checked with: Lean 4.19.0 (commit 6caaee842e94, Release)
Dependency: the bundled Lean standard library only; no Mathlib.

To reproduce with elan installed:
  cd formal
  lean FactoredKernel.lean

The lean-toolchain file pins the required release. Alternatively, invoke the
lean executable from that release directly on FactoredKernel.lean.

Checked statements:
  1. Off + nontriviality + the Q equations recover separation, successor
     injectivity, successor nonzeroness, and decidable equality on an arbitrary
     carrier. The diagonal discriminator is a successor-valued atomic truth
     representation.
  2. The shifted factored witness, a marker range, and local progress force
     all markers to vanish. This argument assumes no induction or coverage
     principle for the carrier.
  3. The unshifted factored witness has the same consequence when coverage is
     supplied.
  4. Predicate reflection under a local induction base and the shifted witness
     yield the full local induction implication.
  5. An explicit primitive-recursive boundary scan on Nat satisfies the stated
     quantifier-free invariant and supplies both shifted and unshifted witnesses
     for every payload.

The source ends with fourteen `#print axioms` commands. All fourteen checked
theorems report that they do not depend on any axioms. The file contains no
`sorry`, added `axiom` declaration, choice principle, or classical tactic.
Seed fields and theorem arguments are explicit hypotheses, not unproved
conclusions about the proposed first-order theory.

Not formalized here:
  - the effective staged language and axiom-instance enumerator;
  - the complete formula-to-truth-term compiler;
  - the triangular pairing development and general primitive-recursion compiler;
  - formal first-order proof translations or internal PRA derivation checking;
  - the complete bi-interpretation or the syntax-size comparison metatheorems.

The Nat verification checks the local witness construction and its invariant.
The paper separately explains why the construction is primitive recursive and
why its invariant can be proved using PRA's quantifier-free induction. The
checked Nat theorem alone is not represented as a formal proof inside PRA.

See lean_output.txt and verification.json for the actual successful run.
