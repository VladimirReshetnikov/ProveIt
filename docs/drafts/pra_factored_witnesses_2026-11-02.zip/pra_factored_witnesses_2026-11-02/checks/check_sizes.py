#!/usr/bin/env python3
"""Check literal tree sizes for the factored PRA witness schemas.

This is a syntax audit, not a proof of arithmetic equivalence.  Variables,
constants, applications, equality, connectives, falsity, and quantifiers each
cost one active node.  Full size additionally charges the complete frozen
descriptor at every generated-symbol call, recursively.  Binder names cost
no extra node.  Negation is implication to falsity.

The new-theory ASTs have only the primitive symbols and generated R_h calls.
Comparator-only mask symbols model the two archived charging conventions.
Substitution changes active arguments; it never changes a stored descriptor.
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union


@dataclass(frozen=True)
class Symbol:
    name: str
    arity: int
    descriptor: Optional["Term"] = None
    family: str = "primitive"


@dataclass(frozen=True)
class Term:
    tag: str
    name: str = ""
    symbol: Optional[Symbol] = None
    args: tuple["Term", ...] = ()


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple[Union["Formula", Term], ...] = ()
    binder: str = ""


def var(name: str) -> Term:
    return Term("var", name=name)


def app(symbol: Symbol, *args: Term) -> Term:
    assert len(args) == symbol.arity
    return Term("app", symbol=symbol, args=tuple(args))


ZERO = Symbol("0", 0)
D = Symbol("D", 2)
S = Symbol("S", 1)
CHI = Symbol("chi", 2)
zero = app(ZERO)
x, a, b, c, n, u, v, w, y = map(var, ("x", "a", "b", "c", "n", "u", "v", "w", "y"))


def rec(body: Term) -> Symbol:
    assert free(body) <= {"v", "w"}
    return Symbol("R", 2, body, "recursor")


def free(node: Union[Term, Formula]) -> set[str]:
    """Active free variables only: descriptors are frozen syntax."""
    if isinstance(node, Term):
        if node.tag == "var":
            return {node.name}
        return set().union(*(free(arg) for arg in node.args))
    names = set().union(*(free(arg) for arg in node.args))
    if node.tag in {"forall", "exists"}:
        names.discard(node.binder)
    return names


Q, Z = rec(w), rec(zero)


def eq(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


def conj(left: Formula, right: Formula) -> Formula:
    return Formula("and", (left, right))


def disj(left: Formula, right: Formula) -> Formula:
    return Formula("or", (left, right))


def neg(formula: Formula) -> Formula:
    return Formula("imp", (formula, Formula("false")))


def quantify(binders: tuple[tuple[str, str], ...], body: Formula) -> Formula:
    for kind, name in reversed(binders):
        assert kind in {"forall", "exists"}
        body = Formula(kind, (body,), name)
    return body


def size(node: Union[Term, Formula], full: bool = False) -> int:
    total = 1 + sum(size(arg, full) for arg in node.args)
    if isinstance(node, Term) and node.tag == "app":
        assert node.symbol is not None
        if full and node.symbol.descriptor is not None:
            total += size(node.symbol.descriptor, True)
    return total


def occurrences(term: Term, name: str) -> int:
    if term.tag == "var":
        return int(term.name == name)
    return sum(occurrences(arg, name) for arg in term.args)


def all_active_names(node: Union[Term, Formula]) -> set[str]:
    names = free(node)
    if isinstance(node, Formula) and node.tag in {"forall", "exists"}:
        names.add(node.binder)
    for arg in node.args:
        names |= all_active_names(arg)
    return names


def substitute(
    node: Union[Term, Formula], mapping: dict[str, Term]
) -> Union[Term, Formula]:
    """Simultaneous, capture-avoiding substitution outside frozen descriptors."""
    if isinstance(node, Term):
        if node.tag == "var":
            return mapping.get(node.name, node)
        return Term(
            node.tag,
            node.name,
            node.symbol,
            tuple(substitute(arg, mapping) for arg in node.args),
        )
    if node.tag in {"forall", "exists"}:
        binder = node.binder
        body = node.args[0]
        active = {key: value for key, value in mapping.items() if key != binder}
        inserted = set().union(*(free(value) for value in active.values()))
        if binder in inserted:
            used = all_active_names(body) | inserted | set(active)
            suffix = 0
            fresh = f"{binder}_{suffix}"
            while fresh in used:
                suffix += 1
                fresh = f"{binder}_{suffix}"
            body = substitute(body, {binder: var(fresh)})
            binder = fresh
        return Formula(node.tag, (substitute(body, active),), binder)
    return Formula(
        node.tag, tuple(substitute(arg, mapping) for arg in node.args), node.binder
    )


def factored(tail: Term, shift: str) -> Formula:
    assert free(tail) <= {"x", "a"}
    if shift == "D":
        source = app(D, b, b)
    elif shift == "S":
        source = app(S, b)
    elif shift == "none":
        source = b
    else:
        raise ValueError(shift)
    first_test = substitute(tail, {"x": source})
    second_test = substitute(tail, {"x": c})
    selected = app(Q, app(Z, first_test, source), n)
    body = conj(eq(c, selected), eq(app(Z, second_test, c), zero))
    return quantify(
        (("forall", "a"), ("forall", "n"), ("exists", "b"), ("exists", "c")),
        body,
    )


def factored_three_witnesses(tail: Term) -> Formula:
    """Optional explicit naming of both the shifted source and selected index."""
    d = var("d")
    first_test = substitute(tail, {"x": d})
    second_test = substitute(tail, {"x": c})
    source_equation = eq(d, app(D, b, b))
    selected_equation = eq(c, app(Q, app(Z, first_test, d), n))
    final_equation = eq(app(Z, second_test, c), zero)
    return quantify(
        (
            ("forall", "a"),
            ("forall", "n"),
            ("exists", "b"),
            ("exists", "d"),
            ("exists", "c"),
        ),
        conj(source_equation, conj(selected_equation, final_equation)),
    )


def old_module(
    tail: Term, store_whole_mask_body: bool, shifted: bool = False
) -> tuple[Formula, Formula]:
    """The strongest 12-node comparator, with its definition fully charged."""
    descriptor = app(Z, tail, x) if store_whole_mask_body else tail
    mask = Symbol("comparison_mask", 2, descriptor, "comparison_only")
    definition = quantify(
        (("forall", "x"), ("forall", "a")),
        eq(app(mask, x, a), app(Z, tail, x)),
    )
    witness = quantify(
        (("forall", "a"), ("forall", "n"), ("exists", "b")),
        eq(app(mask, app(Q, app(mask, app(S, b) if shifted else b, a), n), a), zero),
    )
    return definition, witness


def check_new_vocabulary(node: Union[Term, Formula]) -> None:
    if isinstance(node, Term) and node.tag == "app":
        assert node.symbol is not None
        assert node.symbol.family in {"primitive", "recursor"}
        if node.symbol.family == "recursor":
            assert node.symbol.arity == 2
            assert node.symbol.descriptor is not None
            check_new_vocabulary(node.symbol.descriptor)
    for arg in node.args:
        check_new_vocabulary(arg)


def pair_size(node: Union[Term, Formula]) -> dict[str, int]:
    return {"active": size(node), "full": size(node, True)}


def designated_recursion_core(merged_successor: bool) -> dict[str, int]:
    successor = app(D, n, n) if merged_successor else app(S, n)
    clauses = []
    for symbol, step_value in ((Q, n), (Z, zero)):
        clauses.append(quantify((("forall", "a"),), eq(app(symbol, zero, a), a)))
        clauses.append(
            quantify(
                (("forall", "a"), ("forall", "n")),
                eq(app(symbol, successor, a), step_value),
            )
        )
    return {
        "active": sum(size(clause) for clause in clauses),
        "full": sum(size(clause, True) for clause in clauses),
    }


def audit_tail(label: str, tail: Term) -> dict:
    m, total, count = size(tail), size(tail, True), occurrences(tail, "x")
    expected = {
        "D_shift": (2 * m + 2 * count + 17, 2 * total + 2 * count + 20),
        "S_bridge": (2 * m + count + 16, 2 * total + count + 19),
        "unshifted": (2 * m + 15, 2 * total + 18),
    }
    actual = {}
    for name, shift in (("D_shift", "D"), ("S_bridge", "S"), ("unshifted", "none")):
        sentence = factored(tail, shift)
        assert not free(sentence)
        check_new_vocabulary(sentence)
        measured = pair_size(sentence)
        assert tuple(measured.values()) == expected[name], (label, name, measured)
        actual[name] = measured
    three_witnesses = factored_three_witnesses(tail)
    assert not free(three_witnesses)
    check_new_vocabulary(three_witnesses)
    extra_factoring = pair_size(three_witnesses)
    assert extra_factoring == {"active": 2 * m + 22, "full": 2 * total + 25}
    old = {}
    for name, whole in (("tail_only_best", False), ("whole_mask_DM12", True)):
        clauses = old_module(tail, whole)
        measured = {
            "active": sum(size(item) for item in clauses),
            "full": sum(size(item, True) for item in clauses),
        }
        assert measured["active"] == m + 20
        assert measured["full"] == 4 * total + (31 if whole else 22)
        old[name] = measured
    assert 0 <= count <= m <= total
    for measured in actual.values():
        assert measured["full"] < old["tail_only_best"]["full"]
    return {
        "label": label,
        "tail": {"active": m, "full": total, "input_occurrences": count},
        "new": actual,
        "archived_comparators": old,
        "optional_three_witnesses": extra_factoring,
        "D_full_saving_against_best": old["tail_only_best"]["full"]
        - actual["D_shift"]["full"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    default = Path(__file__).resolve().parents[1] / "verification" / "sizes.json"
    parser.add_argument("--output", type=Path, default=default)
    args = parser.parse_args()

    off = quantify(
        (("forall", "x"), ("forall", "y")),
        disj(eq(x, y), eq(app(D, x, y), zero)),
    )
    nontrivial = quantify((("exists", "u"),), neg(eq(u, zero)))
    partition = quantify(
        (("forall", "x"), ("exists", "y")),
        neg(eq(app(D, x, zero), app(D, x, app(D, y, y)))),
    )
    assert pair_size(off) == {"active": 11, "full": 11}
    assert pair_size(nontrivial) == {"active": 6, "full": 6}
    assert pair_size(partition) == {"active": 13, "full": 13}

    base_rec = rec(app(D, v, w))
    nested_rec = rec(app(D, app(Q, v, w), app(base_rec, app(Z, v, w), v)))
    nested_tail = app(nested_rec, x, a)
    replaced = substitute(nested_tail, {"x": app(D, b, b), "v": zero})
    assert replaced.symbol is nested_rec
    assert replaced.symbol.descriptor is nested_rec.descriptor
    assert occurrences(replaced, "x") == 0
    assert free(replaced) == {"a", "b"}
    capture_test = quantify((("exists", "b"),), eq(x, b))
    capture_result = substitute(capture_test, {"x": b})
    assert capture_result.binder != "b"
    assert free(capture_result) == {"b"}
    assert capture_result.args[0].args[0] == b

    samples = [
        ("constant_zero", zero),
        ("input_variable", x),
        ("parameter_variable", a),
        ("equality_atom_D(x,a)", app(D, x, a)),
        ("duplicated_input_D(x,x)", app(D, x, x)),
        ("seven_node_payload", app(D, app(D, x, a), app(D, x, a))),
        ("nested_frozen_description", nested_tail),
        ("nested_active_recursion", app(nested_rec, app(base_rec, x, a), x)),
    ]
    rng = random.Random(20261102)
    symbols = (D, Q, Z, base_rec, nested_rec)

    def random_tail(depth: int) -> Term:
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice((zero, x, a))
        return app(rng.choice(symbols), random_tail(depth - 1), random_tail(depth - 1))

    rows = [audit_tail(label, tail) for label, tail in samples]
    fuzz_rows = [
        audit_tail(f"deterministic_random_{index}", random_tail(4))
        for index in range(200)
    ]
    active_counterexample = rows[5]
    assert active_counterexample["tail"]["active"] > 5
    assert active_counterexample["new"]["unshifted"]["active"] > (
        active_counterexample["archived_comparators"]["tail_only_best"]["active"]
    )
    assert active_counterexample["new"]["D_shift"]["active"] > (
        active_counterexample["archived_comparators"]["tail_only_best"]["active"]
    )
    old_atom = app(CHI, x, a)
    old_shifted_atom_clauses = old_module(old_atom, False, shifted=True)
    old_unshifted_atom_clauses = old_module(old_atom, False)
    old_shifted_atom = {
        "active": sum(size(item) for item in old_shifted_atom_clauses),
        "full": sum(size(item, True) for item in old_shifted_atom_clauses),
    }
    old_unshifted_atom = {
        "active": sum(size(item) for item in old_unshifted_atom_clauses),
        "full": sum(size(item, True) for item in old_unshifted_atom_clauses),
    }
    new_atom = pair_size(factored(app(D, x, a), "D"))
    assert new_atom == {"active": 25, "full": 28}
    assert old_shifted_atom == {"active": 24, "full": 35}
    assert old_unshifted_atom == {"active": 23, "full": 34}
    new_core = designated_recursion_core(True)
    old_core = designated_recursion_core(False)
    assert new_core == {"active": 30, "full": 34}
    assert old_core == {"active": 28, "full": 32}
    atom_comparison = {
        "new_payload": "D(x,a)",
        "archived_payload": "chi(x,a)",
        "new_D_shift_module": new_atom,
        "archived_CM13_module": old_shifted_atom,
        "favorable_archived_CM12_module": old_unshifted_atom,
        "fixed_plus_selected_module_only": {
            "new_D_shift": {"active": 17 + new_atom["active"], "full": 17 + new_atom["full"]},
            "archived_CM13": {
                "active": 24 + old_shifted_atom["active"],
                "full": 24 + old_shifted_atom["full"],
            },
            "scope": (
                "Only fixed seeds plus the selected auxiliary module are counted. "
                "Q and Z computation clauses and the rest of the infinite recursion "
                "schema are excluded. In particular, these are not whole-theory sizes. "
                "The favorable CM12 module is not assigned the CM13 fixed basis: "
                "the unshifted schema additionally needs coverage."
            ),
        },
        "fixed_plus_QZ_core_plus_selected_module": {
            "new_D_core": new_core,
            "archived_S_core": old_core,
            "new_D_shift": {
                "active": 17 + new_core["active"] + new_atom["active"],
                "full": 17 + new_core["full"] + new_atom["full"],
            },
            "archived_CM13": {
                "active": 24 + old_core["active"] + old_shifted_atom["active"],
                "full": 24 + old_core["full"] + old_shifted_atom["full"],
            },
            "scope": (
                "The four Q/Z computation clauses are included, with each "
                "successor expanded in its own vocabulary. The resulting "
                "72/79 versus 76/91 counts describe this explicit finite "
                "support recipe, not a shortest proof of atomic induction "
                "and not the whole infinite theory."
            ),
        },
    }
    result = {
        "status": "passed",
        "scope": (
            "Literal AST sizes, simultaneous capture-avoiding substitution, "
            "frozen descriptors, finite samples. This is not a proof of PRA "
            "equivalence, induction recovery, or global optimality."
        ),
        "counting_convention": __doc__,
        "fixed_sentences": {
            "Off": pair_size(off),
            "Nontrivial": pair_size(nontrivial),
            "DPart": pair_size(partition),
            "shifted_fixed_total": 17,
            "unshifted_fixed_total": 24,
        },
        "formulas": {
            "D_shift_active": "2*m + 2*i + 17",
            "D_shift_full": "2*T + 2*i + 20",
            "S_bridge_active": "2*m + i + 16",
            "S_bridge_full": "2*T + i + 19",
            "unshifted_active": "2*m + 15",
            "unshifted_full": "2*T + 18",
            "old_tail_only_active": "m + 20",
            "old_tail_only_full": "4*T + 22",
            "old_DM12_whole_body_full": "4*T + 31",
            "optional_three_witnesses_active": "2*m + 22",
            "optional_three_witnesses_full": "2*T + 25",
        },
        "general_inequality": (
            "i <= T; hence 2*T+2*i+20 <= 4*T+20 < 4*T+22. "
            "The S-bridge and unshifted full sizes are also strictly smaller. "
            "Active-size domination is explicitly not claimed."
        ),
        "substitution_checks": {
            "frozen_descriptor_identity_preserved": True,
            "bound_variable_capture_avoided": True,
        },
        "explicit_samples": rows,
        "atomic_formula_comparison": atom_comparison,
        "active_size_counterexample": active_counterexample,
        "deterministic_random_samples": len(fuzz_rows),
        "all_checked_instances": len(rows) + len(fuzz_rows),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {len(rows) + len(fuzz_rows)} literal AST instances.")
    print("PASS: fixed costs 17 and 24; frozen descriptors; capture avoidance.")
    print("PASS: strict full-size comparison and explicit active-size tradeoff.")
    print(f"Report: {args.output}")
    print("Scope: syntax audit only; no proof of the arithmetic metatheorem.")


if __name__ == "__main__":
    main()
