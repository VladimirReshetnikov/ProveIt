#!/usr/bin/env python3
"""Finite numerical checks for the factored-witness construction.

Run with Python 3 from any directory. Only the standard library is used.
The default output is ../verification/witnesses.json relative to this script.

These are exhaustive finite prefix experiments and concrete arithmetic tests.
They do not prove the first-order theory or its behavior in nonstandard models.
The arbitrary-carrier kernel is checked separately in FactoredKernel.lean.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time
from typing import Callable


def discriminator(x: int, y: int) -> int:
    """The standard interpretation of D."""
    return x + 1 if x == y else 0


def successor(x: int) -> int:
    return discriminator(x, x)


def selector(x: int, a: int) -> int:
    """Q(0,a)=a and Q(Sx,a)=x."""
    return a if x == 0 else x - 1


def gate(x: int, a: int) -> int:
    """Z(0,a)=a and Z(Sx,a)=0."""
    return a if x == 0 else 0


def if_zero(r: int, u: int, v: int) -> int:
    """The literal arithmetic expression Q(Z(r,Su),v)."""
    return selector(gate(r, successor(u)), v)


class Checks:
    def __init__(self) -> None:
        self.counts: Counter[str] = Counter()

    def require(self, condition: bool, name: str, context: object = None) -> None:
        if not condition:
            raise AssertionError(f"{name} failed; context={context!r}")
        self.counts[name] += 1


def check_seed(checks: Checks, limit: int = 64) -> dict[str, int]:
    """Check the standard arithmetic interpretation, including DPart."""
    checks.require(1 != 0, "nontriviality")
    for x in range(limit):
        checks.require(successor(x) != 0, "successor_nonzero", x)
        checks.require(selector(0, x) == x, "q_zero", x)
        checks.require(gate(0, x) == x, "z_zero", x)
        y = 0 if x == 0 else x - 1
        checks.require(
            discriminator(x, 0) != discriminator(x, successor(y)),
            "dpart_explicit_witness", (x, y),
        )
        for a in range(limit):
            context = (x, a)
            checks.require(
                selector(successor(x), a) == x, "q_successor", context
            )
            checks.require(
                gate(successor(x), a) == 0, "z_successor", context
            )
            value = discriminator(x, a)
            checks.require(x == a or value == 0, "off", context)
            checks.require((value == 0) == (x != a), "d_zero_iff", context)
            checks.require(
                x != a or value == successor(x), "d_diagonal_truth", context
            )
            normalized = gate(gate(value, successor(0)), successor(0))
            checks.require(
                normalized == (1 if x == a else 0),
                "normalized_pairing_bit", context,
            )
    return {"argument_range": limit, "argument_pairs": limit * limit}


def check_truth_terms(checks: Checks, limit: int = 9) -> dict[str, int]:
    """True values range over all tested successors, not only the numeral 1."""
    for a in range(limit):
        for b in range(limit):
            context = (a, b)
            and_value = if_zero(a, 0, b)
            or_value = if_zero(a, b, 1)
            implication_value = if_zero(a, 1, b)
            checks.require(
                (and_value != 0) == (a != 0 and b != 0),
                "truth_conjunction", context,
            )
            checks.require(
                (or_value != 0) == (a != 0 or b != 0),
                "truth_disjunction", context,
            )
            checks.require(
                (implication_value != 0) == (a == 0 or b != 0),
                "truth_implication", context,
            )
            for r in range(limit):
                checks.require(
                    if_zero(r, a, b) == (a if r == 0 else b),
                    "if_zero_selector", (r, a, b),
                )
    return {"truth_value_range": limit, "truth_value_pairs": limit * limit}


def check_all_mask_prefixes(
    checks: Checks, maximum_target: int = 14
) -> dict[str, object]:
    """Enumerate every zero-or-index mask on each tested padded prefix.

    For target limit L the mask is defined on 0,...,L+1, its value at zero
    is fixed to zero, and its other L+1 choices are independent. The extra
    position ensures that g(S beta(0)) is available even when L=0.
    All targets 0,...,L are checked, with beta updated by its displayed
    primitive recursion. Prefixes of different lengths are separate cases.
    """
    total_masks = 0
    total_targets = 0
    by_length: list[dict[str, int]] = []
    for target_limit in range(maximum_target + 1):
        choices = target_limit + 1
        mask_count = 1 << choices
        for bits in range(mask_count):
            values = [0] + [
                x if (bits >> (x - 1)) & 1 else 0
                for x in range(1, target_limit + 2)
            ]
            beta = 0
            for n in range(target_limit + 1):
                context = (target_limit, bits, n)
                checks.require(
                    values[beta] == 0, "prefix_boundary_zero", context
                )
                checks.require(
                    values[n] == 0 or values[beta + 1] != 0,
                    "prefix_boundary_alternative", context,
                )
                shifted_b = beta
                shifted_c = selector(values[shifted_b + 1], n)
                checks.require(
                    values[shifted_c] == 0,
                    "prefix_shifted_factored_witness", context,
                )
                unshifted_b = beta + 1
                unshifted_c = selector(values[unshifted_b], n)
                checks.require(
                    values[unshifted_c] == 0,
                    "prefix_unshifted_factored_witness", context,
                )
                total_targets += 1
                if values[n] == 0:
                    beta = n
            total_masks += 1
        by_length.append({
            "maximum_target": target_limit,
            "stored_values_including_padding": target_limit + 2,
            "masks": mask_count,
            "targets_checked": mask_count * (target_limit + 1),
        })
    return {
        "maximum_target": maximum_target,
        "padded_mask_count": total_masks,
        "target_instances": total_targets,
        "shifted_witnesses": total_targets,
        "unshifted_witnesses": total_targets,
        "by_length": by_length,
    }


Payload = Callable[[int, int], int]


def raw_payloads() -> list[tuple[str, Payload]]:
    """Concrete PR examples; no claim to enumerate all PR descriptions."""
    return [
        ("zero", lambda x, a: 0),
        ("one", lambda x, a: 1),
        ("input", lambda x, a: x),
        ("parameter", lambda x, a: a),
        ("sum", lambda x, a: x + a),
        ("product", lambda x, a: x * a),
        ("input_minus_parameter", lambda x, a: max(x - a, 0)),
        ("parameter_minus_input", lambda x, a: max(a - x, 0)),
        ("atomic_discriminator", discriminator),
        ("diagonal_discriminator", lambda x, a: discriminator(x, x)),
        ("residue_five", lambda x, a: (x * x + 3 * a) % 5),
        ("alternating_blocks", lambda x, a: (x // (a + 1)) % 2),
    ]


def check_raw_payloads(
    checks: Checks, parameter_count: int = 25, maximum_target: int = 48
) -> dict[str, object]:
    """Evaluate the actual displayed formulas, with S expanded as D(x,x)."""
    payloads = raw_payloads()
    total_targets = 0
    for name, tail in payloads:
        for a in range(parameter_count):
            beta = 0
            for n in range(maximum_target + 1):
                context = (name, a, n)
                g_beta = gate(tail(beta, a), beta)
                g_n = gate(tail(n, a), n)
                s_beta = discriminator(beta, beta)
                g_s_beta = gate(tail(s_beta, a), s_beta)
                checks.require(
                    g_beta == 0, "raw_boundary_zero", context
                )
                checks.require(
                    g_n == 0 or g_s_beta != 0,
                    "raw_boundary_alternative", context,
                )

                # Shifted F+: b=beta and c is the first conjunct's value.
                b = beta
                c = selector(
                    gate(tail(discriminator(b, b), a), discriminator(b, b)), n
                )
                checks.require(
                    gate(tail(c, a), c) == 0,
                    "raw_shifted_factored_formula", context,
                )

                # Unshifted F0: b=S beta, with a fresh evaluation of c.
                b = discriminator(beta, beta)
                c = selector(gate(tail(b, a), b), n)
                checks.require(
                    gate(tail(c, a), c) == 0,
                    "raw_unshifted_factored_formula", context,
                )
                total_targets += 1
                if g_n == 0:
                    beta = n
    return {
        "payloads": [name for name, _ in payloads],
        "parameter_count": parameter_count,
        "maximum_target": maximum_target,
        "target_instances": total_targets,
    }


def main() -> None:
    default_output = Path(__file__).resolve().parents[1] / "verification"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--maximum-target", type=int, default=14)
    parser.add_argument(
        "--output", type=Path, default=default_output / "witnesses.json"
    )
    args = parser.parse_args()
    if not 0 <= args.maximum_target <= 20:
        parser.error("--maximum-target must be between 0 and 20")
    started = time.perf_counter()
    checks = Checks()
    seed = check_seed(checks)
    truth = check_truth_terms(checks)
    exhaustive = check_all_mask_prefixes(checks, args.maximum_target)
    raw = check_raw_payloads(checks)
    report = {
        "status": "passed",
        "scope": (
            "Exhaustive finite padded mask prefixes and concrete natural-number "
            "tests. Not a proof of the theory, the interpretation metatheorem, "
            "or validity on nonstandard models."
        ),
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "seed": seed,
        "successor_valued_truth_terms": truth,
        "exhaustive_masks": exhaustive,
        "raw_payloads": raw,
        "checks_by_kind": dict(sorted(checks.counts.items())),
        "total_successful_checks": sum(checks.counts.values()),
        "elapsed_seconds": round(time.perf_counter() - started, 6),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": report["status"],
        "exhaustive_masks": exhaustive["padded_mask_count"],
        "exhaustive_target_instances": exhaustive["target_instances"],
        "raw_payload_target_instances": raw["target_instances"],
        "total_successful_checks": report["total_successful_checks"],
        "elapsed_seconds": report["elapsed_seconds"],
    }, indent=2))


if __name__ == "__main__":
    main()
