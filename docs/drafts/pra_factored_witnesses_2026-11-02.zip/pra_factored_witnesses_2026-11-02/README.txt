PRA FROM ONE RECURSOR FAMILY
November 2, 2026

Main deliverable: paper.tex and its compiled paper.pdf.

RESULT

The paper specifies a theory FR_17 with initial symbols 0 and binary D,
one uniformly interpreted family R_h of binary recursors, two fixed axioms,
and three generated clause forms. It proves a common conservative
definitional extension with first-order PRA, separately for classical and
intuitionistic first-order logic. Both interpretation composites have the
identity isomorphism. The complete theory is an effective infinite schema.

The construction removes the entire auxiliary mask-symbol family and its
defining schema. Nontriviality replaces a fixed separation/coverage partition,
reducing the fixed basis from 24 to 17 nodes. A second presentation FR_24
retains coverage in the fixed basis and has a shorter recurring block.

The main size theorem concerns complete supporting blocks and charges all
stored descriptions. It does NOT claim a global shortest axiomatization,
strict improvement in both active and full metrics, or a shorter named
witness than the current 12-node interface. The comparison is explicitly
restricted to a common earlier language and identical stored descriptions;
cross-language formula translations can change payload sizes.

FILES

paper.tex, paper.pdf
  Complete axioms, bootstrap, truth compiler, induction, pairing,
  primitive-recursion compiler, reverse witness, identity round trips,
  covered variant, deletion countermodel, and exact comparison theorems.

theory.txt
  Compact specification of the primary theory and the covered variant.

build.py
  Rebuilds the PDF and reruns checks, with optional Lean verification.

checks/check_sizes.py
  Standard-library Python syntax-tree checker. Charges frozen descriptors,
  checks capture-avoiding active substitution, and includes active-size
  counterexamples. The archived run covers 208 deterministic tail instances.

checks/check_witnesses.py
  Standard-library finite numerical tests: 65,534 padded masks, 917,506
  target instances for both witnesses, and 14,700 direct raw-tail cases.
  These experiments do not prove the theory on nonstandard models.

formal/FactoredKernel.lean
  Checked local arbitrary-carrier and Nat kernels, using only Lean's
  standard library. See formal/README.txt for exact scope and exclusions.
  Lean 4.19.0 successfully checked all fourteen listed theorem reports;
  each reports no axiom dependencies. Seed assumptions are explicit
  hypotheses. The complete first-order bi-interpretation is NOT formalized.

formal/lean-toolchain, formal/lean_output.txt, formal/verification.json
  Pinned toolchain, actual successful output, source hash, and checked scope.

provenance/
  Audit, comparison CSV, source manifest, and snapshot information.
  Covers all six ZIPs and all 58 TeX members at ProveIt commit
  4d5474f10e00412135d659dc7a1f74fc6457656a.
  Source archives are not redistributed in this package.

verification/
  Actual syntax and finite-witness results, PDF build/inspection evidence,
  and the build summary. Mathematical proof remains in the paper.

SHA256SUMS
  Checksums for the packaged files (excluding this checksum file itself).

REPRODUCE

Requirements: Python 3.10 or newer; a LaTeX installation with latexmk,
pdfLaTeX, and the standard packages listed in paper.tex. Lean 4.19.0 is
needed only for the optional formal recheck. No Python packages or network
requests are needed for the numerical and syntax checks.

  python3 build.py

If Lean is on PATH or configured with elan, the build rechecks the Lean file.
To select a specific executable:

  python3 build.py --lean /absolute/path/to/lean

To run only the Python checks:

  python3 build.py --no-pdf --skip-lean

To run the checked formal file directly with the pinned release:

  cd formal
  lean FactoredKernel.lean

The build script reports a missing Lean executable as NOT RUN, not as a
successful formal check. The archived formal result is independent evidence
from the successful original run, with the exact source hash recorded.

SOURCE AND NOVELTY SCOPE

All current archives were read, including their optional 12-node, single-family,
and two-primitive formulations. Their internal historical tables compare
against an older collection and were not treated as the current baseline.
The new contribution is the economical factored presentation and comparison
theorem relative to this exact snapshot; no worldwide priority claim is made
for the standard logical operations of definitional elimination and
existential factoring.
