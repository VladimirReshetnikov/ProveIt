# Audit of the six current PRA drafts

## Scope and provenance

The source is `VladimirReshetnikov/ProveIt`, directory `docs/drafts`, at immutable
commit `4d5474f10e00412135d659dc7a1f74fc6457656a`. The directory listing contained
exactly the six ZIP archives recorded in `source_manifest.json`. Their downloaded
bytes match the Git blob identifiers supplied by GitHub. The manifest additionally
records SHA-256 hashes of the archives and every TeX source member.

The mathematical audit read the complete specifications and comparison sections
of all six packages, including the optional presentations. The principal
induction, reverse-witness, pairing, and interpretation arguments were also
examined. This is a mathematical reading audit, not a formal verification of all
theorems or a reproduction of all historical comparisons.

All six current packages mainly compare against the preceding six-archive
snapshot `41ead086f47172a707910a072eb1a722a17a85ca`. That older inventory comprised
`absorbing_return`, `coverage_boundary`, `exit_witness`, `predecessor_return`,
`predecessor_witness`, and `separated_recursion`. Those historical comparator
tables are not the inventory or lower envelope of the present directory.

## Current constructions and cost conventions

All packages use effective infinite first-order languages with finite, frozen
function descriptions. The main direct-mask witness is

\[
\forall a\,\forall n\,\exists b\quad
M_t\bigl(Q(M_t(Sb,a),n),a\bigr)=0.
\]

It has 13 active syntax nodes. Several optional presentations omit the inner
successor and supply coverage separately, giving a 12-node witness.

The inherited active measure charges one node for a variable, constant,
application, equality, connective, falsity symbol, or quantifier. A binder's
variable name is metadata. Negation is expanded as implication to falsity; a
numeral one is expanded as successor of zero. Full size additionally charges
each generated function's stored description at every occurrence, recursively.

Let `m` and `T` be the active and full size of an earlier tail `t`. A local module
comprises its explicit mask definition and its witness; shared recursion
infrastructure and the fixed arithmetic seed are excluded. The main profiles are
recorded in `draft_comparison.csv`, together with the disclosed optional variants.

| Current presentation | Initial symbols | Generated families | Fixed seed | Witness active | Module active | Module full |
| --- | --- | ---: | ---: | ---: | --- | --- |
| Counterexample masks, primary | `0,S,chi` | 2 | 24 | 13 | `m+21` | `4*T+23` |
| Counterexample masks, covered W12 | `0,S,chi` | 2 | 34 | 12 | `m+20` | `4*T+22` |
| Index filters, primary | `0,S,chi` | 2 | 24 | 13 | `m+21` | `4*T+32` |
| Index filters, partition IF12 | `0,S,chi` | 2 | 30 | 12 | `m+20` | `4*T+31` |
| Marked predecessor, primary | `0,S,chi` | 2 | 24 | 13 | `m+21` | `4*T+32` |
| Masked descent, primary | `0,S,chi` | 2 | 24 | 13 | `m+21` | `4*T+32` |
| Masked descent, covered W12 | `0,S,chi` | 2 | 34 | 12 | `m+20` | `4*T+31` |
| Masked descent, partition W12 | `0,S,chi` | 2 | 30 | 12 | `m+20` | `4*T+31` |
| Masked descent, merged DM12 | `0,D` | 2 | 24 | 12 | `m+20` | `4*T+31` |
| Pointwise masks, primary | `0,S,chi` | 1 | 24 | 13 | `m+21` | `4*T+32` |
| Pointwise masks (1), primary | `0,S,chi` | 1 | 24 | 13 | `m+21` | `4*T+32` |
| Pointwise masks (1), partition M12 | `0,S,chi` | 1 | 30 | 12 | `m+20` | `4*T+31` |

The profiles are not interchangeable encodings of the same syntax. Counterexample
masks declares a special constructor whose stored descriptor is only `t`.
The other presentations store the whole body `Z(t(v,w),v)` or `Q(B(v,w),v)`, of
sizes `m+2,T+3`. This accounts for the nine-node difference between their full
module profiles. The constructor conventions are disclosed in the sources; a
comparison must not silently switch between them. Likewise, identical tail
sizes in the `0,D` and `0,S,chi` languages do not automatically describe identical
predicate compilations.

The coordinatewise minima among the displayed constructions are: two initial
symbols, one generated family, 24 fixed seed nodes, 12 active witness nodes,
`m+20` active module nodes, and `4*T+22` full module nodes under the tail-only
descriptor convention. No single current presentation realizes all these
coordinates. All nonconstant function symbols have arity at most two.

## The strongest compact standalone baseline

The optional `DM12` theory in the masked-descent package deserves separate
attention. It starts with only `0` and binary `D`; successor is the textual
abbreviation `Sx = D(x,x)`. Its fixed axioms are

\[
\forall x\forall y\;(x=y\lor D(x,y)=0),
\qquad
\forall x\exists y\;D(x,0)\ne D(x,D(y,y)).
\]

These cost 11 and 13 nodes, totaling 24. Together with ordinary binary recursors,
explicit pointwise masks, and the unshifted 12-node witness, the paper proves
full first-order bi-interpretability with PRA. The native equality bit is
recovered by a finite term, and the value of `D` is reconstructed from successor
and equality, addressing the round-trip requirement.

Source: `pra_masked_descent_2026-11-02/sections/09_vocabulary.tex`, lines 9-32
(specification), 35-87 (bootstrap and reconstruction), and 90-102 (costs and
qualifications). This is an existing optional construction, not a new result
of the present report.

## The two pointwise-mask archives

The filenames with and without `(1)` designate different archives; they share an
inner directory name but have different hashes and source layouts. Both use a
single family `F_h` with a literal syntax dispatch. A body of the exact form
`Z(t(v,w),v)` receives a pointwise definition and a witness. Other bodies receive
initialized recursion equations. An iterator for a selected mask body is
recovered through the ordinary body `Z(0,h)`.

This escape is used only when `h` is a mask. It adds two active and three full
description nodes and preserves the required equations. Using it indiscriminately
would be incorrect: for `h=v`, the wrapper itself would be a mask.

The `(1)` archive additionally states the partition-based M12 option in
`sections/07_comparison.tex`, lines 199-254. It explicitly restricts certain
historical comparisons to common canonical descriptions, and at lines 188-196
shows that comparing an unnormalized new description with a normalized old one
can reverse a full-size inequality. The archive without `(1)` instead gives an
optional normalized formulation in `04_comparison.tex`, lines 270-297, explaining
how the mode-dependent translation must preserve iterator meaning.

## The raw-address envelope is not a meaningful strict target

The marked-predecessor package includes a seven-case optional axiom serializer.
Its last branch emits `0=0`, of active and full size three, at every unused raw
input. Its own comparison is against the preceding snapshot, and it openly
relocates obligations between aliases.

Source: `pra_marked_predecessor_2026-11-02/sections/optional_emitter.tex`, lines
61-82 (branches) and 177-211 (comparison and scope).

Consequently the current same-address envelope already contains three-node
tautologies. In the inherited syntax, without a primitive truth constant, no
valid closed formula has fewer than three nodes: equality needs two terms and an
equality node, while the smaller closed possibilities built from falsity and
vacuous quantification are false. Strict sound same-address domination is
therefore impossible at those tautological outputs. Counting complete
mathematical obligations or a fully specified generator is a different and more
useful comparison. None of these envelopes is an encoding-independent lower
bound on axiomatizations of PRA.

## Mathematical proof assessment

No fatal gap was found in the principal equivalence arguments examined. The
following features are essential to their validity.

1. Before induction, arbitrary raw masks need not have zero-or-input range on an
   arbitrary carrier. The forward arguments establish range and reflection only
   for selected Boolean tails. They derive coverage afterward. The sources
   explicitly distinguish this from the reverse direction, where PRA already
   proves coverage.
2. The forward proof derives the full induction implication with local base and
   progress hypotheses. It is not merely a theorem-to-theorem induction rule.
3. The shifted witness uses an explicit successor in its failure branch. The
   unshifted formula requires a coverage resource; the papers give infinite
   two-chain countermodels when that resource is removed.
4. The triangular pairing construction first uses one-parameter induction, then
   obtains a pairing retraction, then encodes arbitrary fixed parameter tuples.
   It does not assume general parameter coding before proving it.
5. Reverse witness proofs use explicit primitive-recursive scans with
   quantifier-free invariants. This supplies internal PRA proofs, not merely
   standard-model truth.
6. Round trips use internal uniqueness of fixed primitive recursions and external
   induction on finite descriptors. Explicit mask definitions identify their
   own round trips directly. Both domains and both equality relations are native;
   the composite isomorphisms have graph `x=y`.

The target throughout is first-order PRA with function symbols for finite PR
descriptions and induction for quantifier-free formulas with all fixed finite
parameter tuples. It is not identified with `I Sigma_1`, and the arbitrary
quantified consequences of classical and intuitionistic versions are not
identified with each other.

The formal artifacts verify local kernels, selected reconstruction facts, and
reverse scans. They do not formally verify the complete staged syntax, Boolean
compiler, pairing, PR compiler, or first-order bi-interpretation. Their scope
files disclose this. The present audit did not rerun their proof assistants and
does not convert their recorded successful runs into a full formal verification.

## Relation to the present reduction

The sources explicitly leave economical elimination of the additional mask-name
constructor as further work. See the counterexample-mask package,
`sections/07_verification.tex`, lines 77-82, and the masked-descent package,
`sections/08_verification.tex`, in its first further-research item. Neither
contains the present existentially factored, recursor-only witness and its
uniform full-size comparison theorem.

Eliminating a definition is a standard logical operation. The substantive
comparison must therefore charge the inlined terms, the extra variable and
quantifier used to factor their common argument, and the complete incumbent
definition-plus-witness module. It must also disclose that active size need not
decrease and that equal-size profiles across different initial vocabularies are
not automatically comparisons of the same predicate translation.
