#!/usr/bin/env python3
"""Reproduce the package's checks and PDF; never download dependencies."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path


def run(command: list[str], cwd: Path, log: Path | None = None) -> None:
    if log is None:
        subprocess.run(command, cwd=cwd, check=True)
        return
    with log.open("w", encoding="utf-8") as stream:
        subprocess.run(command, cwd=cwd, stdout=stream,
                       stderr=subprocess.STDOUT, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Absolute path to a Lean executable")
    parser.add_argument("--skip-lean", action="store_true")
    parser.add_argument("--no-pdf", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    results = root / "verification"
    results.mkdir(exist_ok=True)
    status: dict[str, object] = {}

    for name in ("check_sizes.py", "check_witnesses.py"):
        run([sys.executable, str(root / "checks" / name)], root)
        status[name] = "passed"

    lean = args.lean or shutil.which("lean")
    if not args.skip_lean and lean:
        lean = str(Path(lean).resolve())
        version = subprocess.check_output([lean, "--version"], text=True).strip()
        run([lean, "FactoredKernel.lean"], root / "formal",
            results / "lean_recheck.txt")
        status["lean"] = {"status": "passed", "version": version}
    else:
        reason = "explicitly skipped" if args.skip_lean else "executable unavailable"
        status["lean"] = {"status": "not run", "reason": reason}
        print(f"Lean NOT RUN: {reason}. Original checked evidence is in formal/.")

    if not args.no_pdf:
        latexmk = shutil.which("latexmk")
        if not latexmk:
            raise SystemExit("latexmk is required to rebuild paper.pdf")
        run([latexmk, "-pdf", "-interaction=nonstopmode", "-halt-on-error",
             "paper.tex"], root, results / "latex_build.txt")
        status["pdf"] = {"status": "built", "bytes": (root / "paper.pdf").stat().st_size}
    else:
        status["pdf"] = {"status": "not run", "reason": "explicitly skipped"}

    status["paper_tex_sha256"] = hashlib.sha256(
        (root / "paper.tex").read_bytes()).hexdigest()
    (results / "build_summary.json").write_text(
        json.dumps(status, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
