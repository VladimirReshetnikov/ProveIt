#!/usr/bin/env python3
"""Build or verify the complete research payload and its SHA-256 manifest."""
from pathlib import Path
import hashlib
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'SHA256SUMS.txt'
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.synctex.gz'}


def payload():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and p != MANIFEST and '__pycache__' not in p.parts
                  and not (p.parent == ROOT and p.suffix in EXCLUDED_SUFFIXES)
                  and p.suffix != '.pyc')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if '--verify' in sys.argv:
        records = [line.split('  ', 1) for line in MANIFEST.read_text().splitlines()]
        for expected, name in records:
            path = ROOT / name
            if not path.is_file() or digest(path) != expected:
                raise SystemExit('Payload mismatch: ' + name)
        if {name for _, name in records} != {str(p.relative_to(ROOT)) for p in payload()}:
            raise SystemExit('Payload file inventory differs from manifest.')
        print(f'PASS: {len(records)} payload checksums verified.')
        return
    files = payload()
    MANIFEST.write_text(''.join(digest(p) + '  ' + str(p.relative_to(ROOT)) + '\n' for p in files))
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in [*files, MANIFEST]:
            output.write(path, str(Path(ROOT.name) / path.relative_to(ROOT)))
    print(f'{archive.name}: {len(files) + 1} files; {archive.stat().st_size} bytes')
    print('SHA256 ' + digest(archive))


if __name__ == '__main__':
    main()
