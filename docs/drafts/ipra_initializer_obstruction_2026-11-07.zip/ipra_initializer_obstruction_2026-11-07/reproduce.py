#!/usr/bin/env python3
"""Reproduce source comparisons, checker audits, and finite-model evidence."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    steps = []
    for script, log in [('comparison/measure.py', 'measurement_run.json'),
                        ('validation/verify.py', 'validation_run.json'),
                        ('finite_models/finite_models.py', 'finite_models.json')]:
        process = subprocess.run([sys.executable, str(ROOT / script)],
                                 cwd=ROOT, capture_output=True, text=True)
        (results / log).write_text(process.stdout)
        if process.returncode:
            (results / (log + '.stderr')).write_text(process.stderr)
            raise SystemExit(f'{script} failed; inspect results/{log}.stderr')
        parsed = json.loads(process.stdout)
        steps.append({'script': script, 'status': 'PASS', 'output': 'results/' + log})
        print(script + ': PASS')
    comparison = json.loads((results / 'comparison.json').read_text())
    commands = []
    for prefix, data in [('Base', comparison['primary_minimum']),
                         ('Main', comparison['candidates'][0]),
                         ('Alt', comparison['candidates'][1])]:
        for suffix, key in [('Tokens', 'normalized_tokens'), ('AST', 'ast_nodes'),
                            ('Bytes', 'normalized_bytes')]:
            commands.append('\\newcommand{\\' + prefix + suffix + '}{' + str(data[key]) + '}')
    (results / 'numbers.tex').write_text('\n'.join(commands) + '\n')
    summary = {'status': 'PASS', 'steps': steps,
               'checker_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                                  for name in ('checker.py', 'checker_companion.py')}}
    (results / 'reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
    if '--pdf' in sys.argv:
        subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
