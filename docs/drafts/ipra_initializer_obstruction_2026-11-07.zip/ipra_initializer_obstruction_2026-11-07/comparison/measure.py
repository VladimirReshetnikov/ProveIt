"""Reproduce the pinned primary and overinclusive sensitivity comparisons."""
from pathlib import Path
import csv
import hashlib
import json
import platform
import source_measure

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def envelope(rows, core=False):
    values = [r['core'] if core else r for r in rows]
    return {field: min(row[field] for row in values) for field in FIELDS}


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    require(hashlib.sha256((ROOT / 'source_measure.py').read_bytes()).hexdigest()
            == manifest['measurement_source_sha256'], 'The frozen normalizer changed.')
    measured = {}
    rows = []
    for record in manifest['files']:
        if record['sha256'] not in measured:
            value = source_measure.metrics(ROOT / record['local_path'])
            require(value['sha256'] == record['sha256'], 'Changed comparator.')
            measured[record['sha256']] = value
        rows.append(dict(record, **measured[record['sha256']]))
    primary = [row for row in rows if row['current_top_level']]
    require(len(primary) == 10, 'Expected all ten top-level current checkers.')
    result = {
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'boundary': 'Whole standalone source, imports, JSON/CLI, syntax, substitution, '
                    'inference, arithmetic, rejection and verdict; only comments/docstrings excluded.',
        'primary_count': len(primary), 'sensitivity_paths': len(rows),
        'sensitivity_distinct_sources': len(measured),
        'primary_minimum': envelope(primary), 'primary_core_minimum': envelope(primary, True),
        'sensitivity_minimum': envelope(rows), 'sensitivity_core_minimum': envelope(rows, True),
        'primary': primary, 'candidates': [],
    }
    for name in ('checker.py', 'checker_companion.py'):
        row = dict(file=name, **source_measure.metrics(ROOT.parent / name))
        row['whole_reduction'] = {k: result['sensitivity_minimum'][k] - row[k] for k in FIELDS}
        row['core_reduction'] = {k: result['sensitivity_core_minimum'][k] - row['core'][k] for k in FIELDS}
        row['strict_whole_improvement'] = all(x > 0 for x in row['whole_reduction'].values())
        row['strict_core_improvement'] = all(x > 0 for x in row['core_reduction'].values())
        require(row['strict_whole_improvement'], name + ' fails the complete-program target.')
        if name == 'checker.py':
            require(row['strict_core_improvement'], 'Primary checker must beat the core envelope too.')
        result['candidates'].append(row)
    output = ROOT.parent / 'results'
    output.mkdir(exist_ok=True)
    (output / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')
    (output / 'sensitivity.json').write_text(json.dumps(rows, indent=2) + '\n')
    with (output / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['source_path', *FIELDS, 'sha256'], extrasaction='ignore')
        writer.writeheader()
        writer.writerows(primary)
        writer.writerows(dict(row, source_path=row['file']) for row in result['candidates'])
    table = [r'\begin{tabular}{lrrr}', r'\toprule',
             r'Complete checker & Tokens & AST nodes & Bytes\\', r'\midrule',
             'Pinned coordinatewise minimum & ' + ' & '.join(str(result['primary_minimum'][k]) for k in FIELDS) + r'\\']
    for row in result['candidates']:
        table.append(('Protected-depth primary' if row['file'] == 'checker.py' else 'Wrapper companion')
                     + ' & ' + ' & '.join(str(row[k]) for k in FIELDS) + r'\\')
    table += [r'\bottomrule', r'\end{tabular}']
    (output / 'comparison_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'primary'}, indent=2))


if __name__ == '__main__':
    main()
