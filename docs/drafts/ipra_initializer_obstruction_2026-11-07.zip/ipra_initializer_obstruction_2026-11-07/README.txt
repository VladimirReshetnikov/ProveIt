A SMALLER iPRA PRESENTATION AND AN INITIALIZER OBSTRUCTION
=======================================================
Prepared for Vladimir Reshetnikov, 7 November 2026.

START HERE
----------
report.pdf is the complete mathematical paper.
report.tex and sections/*.tex are all its editable LaTeX sources.

ESTABLISHED RESULTS
-------------------
The proposed presentation uses zero, successor, initialized scalar iteration,
equations, and the Q/D logical binders. Five primitive inference patterns and
two computation schemas suffice. The paper gives the complete rules and
whole-domain bi-interpretations with intuitionistic primitive recursive
arithmetic, including both internally proved identity composites.

The arithmetic basis and its internal bootstrap are inherited from the
current scalar draft and explicitly attributed. This iteration makes a
strict, modest reduction in the complete proof checker by combining scalar
iteration, sort separation, and unwrapped introduction witnesses:

                                    Tokens    AST    Normalized bytes
Current coordinatewise envelope       411     425          1207
checker.py                            409     423          1199
checker_companion.py                  407     424          1196

The primary also strictly beats the secondary core envelope:
350/361/955 versus 352/362/957. The companion core is 348/362/952,
tying the old core AST minimum. All measurements use the unchanged
upstream normalizer and CPython 3.12.14. Imports, syntax, substitution,
all rules, JSON input, verdicts, and exception handling are counted.
Both programs import only Python's standard json and sys modules.

The principal new mathematical result concerns fixing the initializer.
For ANY ONE externally fixed numeral r, replacing I(n,a;u.h) by

  K_r(0;u.h) = r
  K_r(Sn;u.h) = h(K_r(n;u.h))

while retaining only the stated computation resources admits a finite
model, even after adding successor separation, numerical coverage, and
FULL induction for every formula. Positive seeds admit a three-element
path-preservation model; zero admits saturated finite chains. Consequently
these weakened theories cannot interpret iPRA by ordinary finite-dimensional
first-order interpretations, including definable quotients.

This theorem deliberately does not add successor injectivity as a separate
axiom. It excludes fixing the initializer alone, not every conceivable
axiomatization involving fixed-seed iteration. Neither the checker comparison
nor the finite-model theorem proves absolute global minimality.

SOURCE SNAPSHOT
---------------
https://github.com/VladimirReshetnikov/ProveIt/tree/b10a56a8f655c607494a3069b31d6679d968797a/docs/drafts

All six current archives were pinned and verified against Git blob hashes.
The primary comparison includes all ten top-level current checkers.
An expanded scan covers 274 source paths, 105 distinct ACCEPT-printing
sources, with the same minima. Its inclusion is a sensitivity analysis,
not a correctness endorsement of all historical comparators.

RUN OFFLINE
-----------
  python3 package.py --verify
  python3 reproduce.py
  python3 checker.py examples/zero_equation.json
  python3 -O checker.py examples/capture_attack.json

The example zero equation prints ACCEPT and exits 0. The capture attack
prints REJECT and exits 1. Python 3.10+ is required for pattern matching;
exact normalized-source metrics use CPython 3.12.14.

To rebuild the PDF:
  python3 build.py

This requires pdfLaTeX and the ordinary packages listed in report.tex.
The supplied PDF can be read without installing LaTeX. All reproduction
uses local files; no network, repository checkout, or external proof
library is required. The original SHA256SUMS.txt identifies the delivered
files; intentional rebuilding can change PDF metadata. Run package.py
again after edits if you want an updated archive and checksum manifest.

VALIDATION
----------
Both checkers agree with a separate named-binder oracle on 84 fixed rows
(83 distinct packets), 3672 opening cases per checker, and 1200 mutation
attempts (1051 distinct packets). There are 336 actual CLI runs including
Python -O, and ten deliberate-mutant controls. These counts overlap and
are not counts of independent mathematical theorems.

The finite-model script exhausts the three monotone unary maps of the
zero-seed two-element model and the seventeen path endomorphisms in each
positive-seed model. General nesting and parameter arity are handled by
the paper's structural proof, not inferred from finite term testing.

The full arithmetic/interpretability metatheorems and Python kernels are
not Lean/Rocq formalizations. Finite tests supplement the written proofs.
The fixture translator is restricted to canonical certificate annotations;
the counter-free source transporter is not a general PR-to-iterator compiler.

CONTENTS
--------
report.pdf, report.tex, sections/   Complete paper and LaTeX sources
checker.py                        Primary complete acceptance program
checker_companion.py              Smaller-token/byte companion
FORMAT.txt                        Exact packet and binding contract
examples/                         Accepted and rejected entry-point packets
comparison/                       Frozen sources, normalizer, provenance
validation/                       Oracles, translators, fixtures, runner
finite_models/                    New finite-model exhaustive verification
results/                          Recomputed metrics and audit receipts
repository_snapshot.json          Pinned six-archive identities
ATTRIBUTION.txt, LICENSE_SOURCE.txt
reproduce.py, build.py, package.py Reproduction, PDF build, archive utilities
SHA256SUMS.txt                     Delivered payload integrity manifest
