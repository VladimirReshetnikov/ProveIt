FIXED-INITIALIZER FINITE MODELS

Run with the Python standard library only:

    python3 finite_models.py

The program prints transparent JSON counts and checks all finite maps
needed for the two countermodel arguments in the accompanying paper.

For initializer zero it checks the three monotone unary maps on the
two-element saturated successor chain.  It checks computation and joint
monotonicity for pointwise ordered updates.

For each positive initializer model it checks all seventeen unary maps
preserving a reflexive three-vertex path.  It checks successor edge
preservation, the orbit identity h^3(c)=h(c), and iteration preservation
for every pair of pointwise adjacent maps at every pair of counters.
The two possible path centers cover every fixed positive numeral:
odd numerals denote 1 and even positive numerals denote 2.

The program also checks full induction for every subset of each finite
domain, and verifies coverage and successor separation.  Successor
injectivity is deliberately absent from the proposed weakened theories;
the three-element models falsify it.

These exhaustive checks supplement the mathematical proof.  They do not
replace its structural induction covering arbitrary finite term nesting,
arbitrary fixed parameter arities, or its interpretation argument.
The conclusion concerns ordinary finite-dimensional first-order
interpretations, including definable quotient interpretations.
