#!/usr/bin/env python3
"""Exhaust finite maps used in the fixed-initializer countermodels.

This is supplementary finite verification.  The accompanying paper proves
closure under arbitrarily nested terms and all finite parameter arities.
Run: python3 finite_models.py
"""

from itertools import product
import json


def orbit(h, seed, length):
    result = [seed]
    for _ in range(length):
        result.append(h[result[-1]])
    return result


def verify_zero_model():
    domain = (0, 1)
    successor = (1, 1)
    maps = [h for h in product(domain, repeat=2) if h[0] <= h[1]]
    assert len(maps) == 3
    computation_checks = 0
    for h in maps:
        values = orbit(h, 0, 2)
        assert values[2] == values[1]
        for n in domain:
            assert values[successor[n]] == h[values[n]]
            computation_checks += 1
    ordered_map_pairs = 0
    joint_monotonicity_checks = 0
    for h, g in product(maps, repeat=2):
        if not all(a <= b for a, b in zip(h, g)):
            continue
        ordered_map_pairs += 1
        hv, gv = orbit(h, 0, 1), orbit(g, 0, 1)
        for n, m in product(domain, repeat=2):
            if n <= m:
                assert hv[n] <= gv[m]
                joint_monotonicity_checks += 1
    assert 0 not in successor
    assert set((0,) + successor) == set(domain)
    induction_subsets = verify_full_induction(domain, successor)
    return {
        "domain": list(domain),
        "successor": list(successor),
        "initializer": 0,
        "monotone_unary_maps": len(maps),
        "successor_computation_checks": computation_checks,
        "pointwise_ordered_map_pairs": ordered_map_pairs,
        "joint_monotonicity_checks": joint_monotonicity_checks,
        "subsets_checked_for_full_induction": induction_subsets,
        "result": "pass",
    }


def verify_full_induction(domain, successor):
    """Check induction for every possible truth set, with parameters fixed."""
    count = 0
    for bits in product((False, True), repeat=len(domain)):
        count += 1
        base = bits[0]
        step = all(not bits[x] or bits[successor[x]] for x in domain)
        if base and step:
            assert all(bits)
    return count


def verify_positive_model(center):
    domain = (0, 1, 2)
    successor = (1, 2, 1)

    def adjacent(a, b):
        return a == b or a == center or b == center

    edges = [(a, b) for a, b in product(domain, repeat=2)
             if adjacent(a, b)]
    for a, b in edges:
        assert adjacent(successor[a], successor[b])
    maps = [h for h in product(domain, repeat=3)
            if all(adjacent(h[a], h[b]) for a, b in edges)]
    assert len(maps) == 17
    computation_checks = 0
    for h in maps:
        values = orbit(h, center, 3)
        assert values[3] == values[1]
        for n in domain:
            assert values[successor[n]] == h[values[n]]
            computation_checks += 1

    pointwise_adjacent_pairs = 0
    joint_preservation_checks = 0
    for h, g in product(maps, repeat=2):
        if not all(adjacent(a, b) for a, b in zip(h, g)):
            continue
        pointwise_adjacent_pairs += 1
        hv, gv = orbit(h, center, 2), orbit(g, center, 2)
        for n, m in product(domain, repeat=2):
            # All counter pairs are checked, even nonadjacent pairs.
            assert adjacent(hv[n], gv[m])
            joint_preservation_checks += 1

    assert 0 not in successor
    assert set((0,) + successor) == set(domain)
    assert successor[0] == successor[2] and 0 != 2
    induction_subsets = verify_full_induction(domain, successor)
    return {
        "domain": list(domain),
        "successor": list(successor),
        "path_center_and_initializer": center,
        "positive_numeral_parity": "odd" if center == 1 else "even",
        "ordered_reflexive_edges": len(edges),
        "successor_edge_preservation_checks": len(edges),
        "nonexpansive_unary_maps": len(maps),
        "orbit_identity_checks": len(maps),
        "successor_computation_checks": computation_checks,
        "pointwise_adjacent_ordered_map_pairs": pointwise_adjacent_pairs,
        "all_counter_pairs_per_map_pair": 9,
        "joint_iteration_preservation_checks": joint_preservation_checks,
        "subsets_checked_for_full_induction": induction_subsets,
        "successor_injectivity_counterexample": {"inputs": [0, 2], "common_output": 1},
        "result": "pass",
    }


def main():
    result = {
        "scope": "Finite exhaustive corroboration; arbitrary nested syntax is handled by the paper's structural proof.",
        "zero_initializer": verify_zero_model(),
        "positive_initializers": [verify_positive_model(1), verify_positive_model(2)],
        "result": "pass",
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
