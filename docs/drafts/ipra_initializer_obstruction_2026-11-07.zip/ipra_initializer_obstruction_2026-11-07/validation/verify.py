"""Independent named-syntax, instruction-format, rejection and CLI audit.

No code in this file is imported by either measured acceptance program.
This finite suite supplements, and does not replace, the mathematical proof.
"""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

from mutation_support import mutate
from named_oracle import Oracle
from opening_audit import audit_opening
from translate_annotations import to_raw
from transport_counter_free import packet as remove_unused_counter

ROOT = Path(__file__).resolve().parent


def require(value, explanation):
    if not value:
        raise ValueError(explanation)


def digest(value):
    return hashlib.sha256(json.dumps(value, separators=(',', ':')).encode()).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(module, packet):
    values = deepcopy(packet)
    module.k = 0
    try:
        module.take = values.pop
        accepted = bool(module.check(values.pop(), []))
        error = None
    except Exception as exception:
        accepted, error = False, type(exception).__name__
    return dict(accepted=accepted, final_k=module.k, error=error,
                remaining=len(values) if type(values) is list else None)


def fixtures():
    source = json.loads((ROOT / 'scalar_fixtures.json').read_text())
    result = [dict(row, packet=to_raw(row['packet']), cohort='scalar') for row in source]
    direct = json.loads((ROOT / 'direct_q_sources.json').read_text())
    for row in direct:
        result.append(dict(row, packet=to_raw(remove_unused_counter(row['packet'])), cohort='direct_closure'))
    zero, one, true, false = 0, [0], [0, 0], [0, [0]]
    q_true = [true]
    d_true = [true, true, true]
    false_major = [[0, 0, 0], [0]]
    extra = [
        ('raw_zero_witness', [0, d_true], True),
        ('raw_successor_witness', [[0], d_true], True),
        ('direct_closure_zero_annotation', [0, q_true], True),
        ('direct_closure_unused_boolean', [True, q_true], True),
        ('used_boolean_witness', [True, [[3, 0], true, true]], False),
        ('equation_cannot_use_introduction', [0, true], False),
        ('literal_false_has_no_introduction', [0, false], False),
        ('term_as_formula_goal', [0, 0], False),
        ('boolean_in_goal', [0, [False, 0]], False),
        ('failed_major_irrelevant_annotation', [[], [false_major, 0], q_true], True),
        ('failed_major_used_bad_witness', [[], [false_major, 0], [[3, 3], true, true]], False),
        ('future_free_parameter_in_goal', [0, [[-1, -1]]], False),
        ('empty_packet', [], False),
        ('nonlist_packet', None, False),
    ]
    result.extend(dict(name=name, packet=packet, expected=expected, cohort='new_boundary')
                  for name, packet, expected in extra)
    return result


def main():
    rows = fixtures()
    paths = [ROOT.parent / 'checker.py', ROOT.parent / 'checker_companion.py']
    modules = [load(path, path.stem) for path in paths]
    reference = load(ROOT / 'reference_scalar.py', 'reference_scalar')
    original = json.loads((ROOT / 'scalar_fixtures.json').read_text())
    for row in original:
        require(run(reference, row['packet'])['accepted'] == row['expected'],
                ('frozen scalar reference', row['name']))
    oracle = Oracle()
    fixed = []
    for row in rows:
        expected = oracle.run(row['packet'])
        require(expected['accepted'] == row['expected'], ('independent oracle fixture', row['name'], expected))
        outcomes = [run(module, row['packet']) for module in modules]
        require(all(x['accepted'] == row['expected'] for x in outcomes), (row['name'], outcomes))
        if row['expected']:
            require(all(x['final_k'] == expected['final_k'] and x['remaining'] == expected['remaining']
                        for x in outcomes), ('positive consumption/allocation mismatch', row['name']))
        fixed.append({k: v for k, v in row.items() if k != 'packet'} |
                     {'packet_sha256': digest(row['packet']), 'outcomes': outcomes,
                      'oracle_rules': expected['rules']})
    openings = [audit_opening(module) for module in modules]
    rng = random.Random(20261107)
    mutations = []
    for index in range(1200):
        base = rows[index % len(rows)]
        packet = mutate(base['packet'], rng)
        expected = oracle.run(packet)['accepted']
        actual = [run(module, packet)['accepted'] for module in modules]
        require(all(value == expected for value in actual),
                ('mutation disagreement', index, base['name'], expected, actual, packet))
        mutations.append(dict(index=index, base=base['name'], accepted=expected, packet_sha256=digest(packet)))
    cli_count = 0
    with tempfile.TemporaryDirectory(prefix='ipra_raw_witness_') as directory:
        temporary = Path(directory) / 'packet.json'
        for row in rows:
            temporary.write_text(json.dumps(row['packet']) + '\n')
            for path in paths:
                for optimized in (False, True):
                    command = [sys.executable, *(['-O'] if optimized else []), str(path), str(temporary)]
                    process = subprocess.run(command, capture_output=True, text=True, timeout=15)
                    expected = (0, 'ACCEPT') if row['expected'] else (1, 'REJECT')
                    require((process.returncode, process.stdout.strip()) == expected,
                            ('CLI', row['name'], path.name, optimized, process.stdout, process.stderr))
                    cli_count += 1
    names = {row['name']: row for row in rows}
    changes = [
        ('image_capture', 'inst(env[a - d >> 1], d=1)', 'inst(env[a - d >> 1], d=d)', 'scalar_contextual_capture', True),
        ('extra_update_binder', "b'\\0\\0\\2'", "b'\\0\\0\\4'", 'nonexistent_counter_slot', True),
        ('unvalidated_goal', 'if inst(a) in g:', 'if a in g:', 'false_eigenparameter_escape', True),
        ('compound_induction', 'h = [b, inst(b, 0)][len(b) % 2:]', 'h = [b, inst(b, 0)]', 'compound_induction_hypothesis', True),
        ('base_removed', 'h = [b, inst(b, 0)][len(b) % 2:]',
         'h = [b] if len(b) == 2 else [inst(b, 0)]', 'retained_base_separation', False),
    ]
    controls = []
    for path in paths:
        source = path.read_text()
        for label, old, new, fixture, expected in changes:
            require(source.count(old) == 1, ('mutation anchor', label, path.name))
            namespace = {'__name__': 'deliberate_mutant'}
            exec(compile(source.replace(old, new), '<deliberate_mutant>', 'exec'), namespace)
            class Mutant:
                pass
            mutant = Mutant()
            # Mutated functions use their own global namespace, so run explicitly.
            values = deepcopy(names[fixture]['packet'])
            namespace['k'] = 0
            namespace['take'] = values.pop
            try:
                accepted = bool(namespace['check'](values.pop(), []))
            except Exception:
                accepted = False
            require(accepted == expected, ('mutant control', path.name, label, accepted))
            controls.append(dict(checker=path.name, mutation=label, fixture=fixture,
                                 mutant_accepts=accepted, original_accepts=names[fixture]['expected']))
    results = {
        'status': 'PASS', 'fixed_packets': len(rows),
        'fixed_positive': sum(row['expected'] for row in rows),
        'fixed_negative': sum(not row['expected'] for row in rows),
        'fixed_distinct_packets': len({digest(row['packet']) for row in rows}),
        'cohorts': {name: sum(row['cohort'] == name for row in rows)
                    for name in ('scalar', 'direct_closure', 'new_boundary')},
        'opening_cases_per_checker': openings, 'actual_cli_runs': cli_count,
        'mutation_packets': len(mutations),
        'distinct_mutation_packets': len({row['packet_sha256'] for row in mutations}),
        'accepted_mutations': sum(row['accepted'] for row in mutations),
        'mutation_controls': controls,
        'checker_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'limitations': 'Finite testing only. Both checkers use the same cohorts. '
                       'No claim of proof-assistant verification, universal correctness, '
                       'or a general primitive-recursion-to-iterator compiler.',
    }
    out = ROOT.parent / 'results'
    out.mkdir(exist_ok=True)
    (out / 'validation.json').write_text(json.dumps(dict(results, fixed=fixed, mutations=mutations), indent=2) + '\n')
    (out / 'validation_summary.json').write_text(json.dumps(results, indent=2) + '\n')
    (ROOT / 'fixtures.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
