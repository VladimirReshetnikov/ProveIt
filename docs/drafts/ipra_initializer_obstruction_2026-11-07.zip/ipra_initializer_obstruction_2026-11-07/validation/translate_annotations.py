"""Untrusted certificate-format change: erase introduction witness wrappers.

Old canonical instructions have arity 0 (computation), 1 (introduction), or
2 (elimination). Only earlier instruction cells are rewritten, never the
last cell, which is the formula to be proved. This does not translate
arbitrary primitive recursion to scalar iteration. This utility handles the
canonical supplied fixtures. For a completeness transformation of arbitrary
accepted source certificates, first replace a malformed but unused witness
annotation by zero in the extracted proof tree; that stronger extraction
procedure is not implemented here.
"""
from copy import deepcopy


def to_raw(packet):
    if type(packet) is not list or not packet:
        return deepcopy(packet)
    return [deepcopy(cell[0]) if type(cell) is list and len(cell) == 1
            else deepcopy(cell) for cell in packet[:-1]] + [deepcopy(packet[-1])]

