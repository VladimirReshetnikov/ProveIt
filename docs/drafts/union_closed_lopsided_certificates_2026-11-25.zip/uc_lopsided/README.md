# Lopsided local certificates for abundant elements

Research note, 25 November 2026. Start with `paper.pdf` (complete mathematical proofs). `paper.tex` is the self-contained source.

## Main results

The paper extends the conditioning argument in ProveIt's `union_closed_joint_laws_2026-11-25.zip`. The co-incidence graph itself, not its square, is a negative dependency graph for unsupported selected vertices. This reduces the regular linear dependency bound from `[d(r-1)]^2` to `d(r-1)`.

For a linear generating system with point degree r and generator size d, all points are abundant at and above the new sufficient thresholds:

| r | earlier draft's explicit threshold | new sufficient threshold | strict guaranteed frequency |
|---:|---:|---:|---:|
| 3 | 32 | 14 | 64% |
| 4 | 89 | 40 | 62% |
| 5 | 221 | 100 | 54% |
| 6 | 517 | 237 | 55% |
| 7 | 1169 | 541 | 56% |
| 8 | 2589 | 1206 | 52% |

The thresholds are sufficient, not claimed optimal. The comparison is against a particular explicit criterion in the prior draft. The main theorem also works on nonregular and nonlinear support hypergraphs, and allows marked subedges to avoid a high-degree center. For linear triple systems of minimum degree 15 with two degree-15 vertices in each support edge, every point has frequency greater than 54%, even with no bound on maximum degree. A nonlinear block example gives greater than 70% for all points.

The full conjecture is not proved, no new unrestricted frequency constant is claimed, and historical priority is provisional. The proofs are human-readable, not proof-assistant formalizations. The GitHub repository was read but not modified.

## Reproduction

Python 3.10+ with standard library; TeX Live with the standard AMS and Latin Modern packages.

```
python3 verify.py > verification.json
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

Use `python3 verify.py --quick` for reduced finite enumeration. Do not use `python -O`: assertions are essential to the checker. All comparison decisions use integers or `fractions.Fraction`. The supplementary tests do not replace the mathematical proofs. `verification.json` records the actual full run. `sha256sum -c SHA256SUMS` checks the supplied files before rebuilding them (a rebuilt PDF may have different metadata).
