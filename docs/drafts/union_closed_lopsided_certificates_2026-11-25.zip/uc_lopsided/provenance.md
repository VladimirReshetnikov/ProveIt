# Source and novelty audit

Date: 2026-11-25. This is an explicitly limited priority investigation, not a comprehensive literature review.

## Repository

GitHub connector directory read: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

The direct antecedent was fetched as base64 and its internal LaTeX source `union_closed_joint_laws/lll_and_tails.tex` decoded and inspected. Archive `union_closed_joint_laws_2026-11-25.zip`, git blob `c497e7f366a6c29bd2002919c0a5e497d6359133`.

The antecedent gives the distinct-union/support-edge-union correspondence, the fair-product-measure conditioning identity, the unsupported-vertex bad events, the ordinary dependency graph of squared co-incidence degree, its symmetric LLL and event-domination inequality, and regular-linear frequency bounds. These are credited, not claimed as inventions of this note. Its explicit certificate is Delta=b^2, z=(1-2^(1-r))^d, Delta*z<=1/2, xi=z/[2(1-Delta*z)], and (1-xi)^t>=2^(1-r), where t=r[1+(d-1)(r-1)]. The comparison in the new note is exactly with this certificate.

The following archives were screened via ZIP directory or README contents, not completely reviewed:

- `union_closed_dense_core_2026-11-25.zip`: omitted generators, core translations, fixed marked points.
- `union_closed_cycle_certificates.zip`: induced directed cycles, feasible in/out-neighbor sets.
- `union_closed_rank_transport_2026-11-25.zip`: entropy refinements, rank/representation-count transport.
- `union_closed_partial_theorems_2026-11-25.zip`: high-girth degree-four MIS theorem; first-order linear regular asymptotics and extremizers.
- `union_closed_refinements_2026-11-25.zip`: entropy-based finite-size, approximate closure, discrete and nonchain bounds.
- `union_closed_substitution.zip`: hypergraph substitution, exact product and local-gadget frequencies.

The large `union_closed_structural_theorems.zip` could not be decoded as a complete ZIP from the retrieved connector response; remaining archives were not all inspected. No modifications to GitHub were requested or made.

## Public sources checked

- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture
- https://arxiv.org/abs/2610.02295 (Costa and Sadhu, recent universal bound)
- https://quantavane.com/major-results/union-closed-sets-conjecture/ (November announcement; not independently audited)
- https://arxiv.org/abs/math/9409215 (Knill, graph-generated dual case)
- https://ocw.mit.edu/courses/18-226-probabilistic-methods-in-combinatorics-fall-2022/ (Zhao, standard lopsided LLL)
- https://doi.org/10.1016/j.ejc.2014.08.030 (Bruhn, Charbit, Schaudt, Telle, graph formulation)
- https://doi.org/10.1002/(SICI)1097-0118(199711)26:3%3C155::AID-JGT6%3E3.0.CO;2-Q (El-Zahar, derived-subgraph formulation)

Targeted search terms included `union closed sets conjecture hypergraph lopsided local lemma`, `hypergraph union closed family local lemma distinct unions linear`, `Frankl conjecture graph induced subgraphs without isolated vertices`, and `lopsided local lemma monotone events product measure Harris inequality`.

No exact match for the new distance-one negative dependency observation, mixed-pattern asymmetric law, marked subedge criterion, or displayed regular/irregular bounds was located in this limited review. The proof is elementary once the observation is made, so independent prior discovery is possible. No claim of priority, independent refereeing, or an improved global constant is made. The new results concern a structural class with a checkable sufficient condition.
