#!/usr/bin/env python3
"""Exact checks for the paper. Requires Python 3.10+; no external packages.
The mathematical proof, not this finite audit, establishes the general claims.
"""
import argparse
from fractions import Fraction as Q
from itertools import combinations
from random import Random
import json
from pathlib import Path

ROWS = [(3,32,14,78,64),(4,89,40,265,62),(5,221,100,739,54),
        (6,517,237,2116,55),(7,1169,541,5637,56),(8,2589,1206,14076,52)]

def regular_table():
    rows=[]
    for r,old,d,k,L in ROWS:
        s=2**(r-1); b=(r-1)*d; t=r*(1+(r-1)*(d-1)); c=r*(r-1)
        assert 2*s**d*(k-1)**b >= (s-1)**d*k**(b+1)
        assert 2**r*(100-L)*(k-1)**t > 100*k**t
        assert t >= c*(s-1)  # propagation
        # Check exact prior explicit threshold: every smaller positive d fails
        # the prerequisite b^2 q^d <= 1/2.
        for j in range(1,old):
            assert 2*((r-1)*j)**2*(s-1)**j > s**j
        B=(r-1)*old; T=r*(1+(r-1)*(old-1)); u=(s-1)**old; v=s**old
        assert 2*B*B*u <= v
        # a = u/[2(v-B^2 u)], use exact integer powers.
        # Very large exponents/operands at r=8: certify by Bernoulli when possible,
        # otherwise compare powers of exact rational interval endpoints.
        a=Q(u,2*(v-B*B*u))
        # Need (1-a)^T >= 2^(1-r). A conservative rational ceiling for a
        # with denominator 10^12 keeps the powers modest.
        scale=10**12
        num=(a.numerator*scale+a.denominator-1)//a.denominator
        assert Q(num,scale)>=a
        assert 2**(r-1)*(scale-num)**T >= scale**T
        rows.append(dict(r=r,prior_threshold=old,new_threshold=d,k=k,
                         guaranteed_strict_percent=L,dependency_degree=b,neighborhood_bound=t))
    return rows

def special():
    assert Q(1,2)*Q(3,4)**15 <= Q(1,100)*Q(99,100)**30
    assert Q(3,4)<Q(99,100)**2
    assert 184*99**59>100**60
    assert Q(5,512)<=Q(1,64)*Q(63,64)**9
    assert 1-Q(1,4)*Q(64,63)**10 > Q(7,10)
    assert 1-Q(1,8)*Q(64,63)**10 > Q(85,100)
    # Independent finite construction of the degree-15 bouquet; no enumeration
    # of its 2^(1+44M) configurations is claimed.
    for M in (1,2,4):
        edges=[]
        for block in range(M):
            def vid(part,i):
                if part==0 and i==0:return 0
                return 1+44*block+(i-1 if part==0 else 14+15*(part-1)+i)
            for i in range(15):
                for j in range(15):
                    edges.append(frozenset((vid(0,i),vid(1,j),vid(2,(i+j)%15))))
        deg=[0]*(1+44*M); pairs=set()
        for e in edges:
            assert len(e)==3
            for v in e:deg[v]+=1
            for p in combinations(sorted(e),2):
                assert p not in pairs; pairs.add(p)
        assert deg[0]==15*M and all(d==15 for d in deg[1:])
        assert all(sum(deg[v]==15 for v in e)>=2 for e in edges)
    # Exact block counts, using independent block contributions conditional on c.
    # c=0: allowed leaf sets have size 0 or >=3; c=1: each block has 0 or >=2
    # leaves, and at least one block must contain >=2 leaves to support c.
    from math import comb
    a0=1+sum(comb(9,j) for j in range(3,10))
    a1=1+sum(comb(9,j) for j in range(2,10))
    for M in (1,2,3,10,100):
        good=a0**M+a1**M-1
        # marked edge containing c and two leaves
        n1=2**7*a1**(M-1)
        # marked edge consisting of three leaves: c=0 and c=1 contributions
        n2=2**6*(a0**(M-1)+a1**(M-1))
        assert 1-Q(n1,good)>Q(7,10)
        assert 1-Q(n2,good)>Q(85,100)
    return {'irregular_bouquets_checked':[1,2,4], 'nonlinear_block_counts_checked':[1,2,3,10,100]}

def subsets(s):
    t=s
    while True:
        yield t
        if t==0:return
        t=(t-1)&s

def product(values):
    a=Q(1)
    for v in values:a*=v
    return a

class Model:
    def __init__(self,n,edges):
        self.n=n; self.edges=tuple(edges); self.V=(1<<n)-1; self.size=1<<n
        self.all=(1<<self.size)-1
        # contain[e] is a bitset of product configurations containing e
        self.contain=[sum(1<<z for z in range(self.size) if z&e==e) for e in range(self.size)]
        self.closed=[]; self.bad=[]
        for i in range(n):
            v=1<<i; K=v; supported=0
            for e in self.edges:
                if e&v:K|=e; supported|=self.contain[e]
            self.closed.append(K)
            self.bad.append(self.contain[v]&~supported)
        self.avoid=[self.all]*self.size
        for s in range(1,self.size):
            v=s&-s; i=v.bit_length()-1
            self.avoid[s]=self.avoid[s^v]&~self.bad[i]
        self.good=self.avoid[self.V]; self.ng=self.good.bit_count()
        self.counts=[b.bit_count() for b in self.bad]
    def nb(self,J):
        s=0
        for i in range(self.n):
            if J>>i&1:s|=self.closed[i]
        return s
    def dual(self):
        # independently enumerate all original unions using arbitrary subsets
        # of generator indices. Original elements are support-edge indices.
        primal={sum(1<<j for j,e in enumerate(self.edges) if e&chosen) for chosen in range(self.size)}
        dual={z for z in range(self.size) if self.good>>z&1}
        assert len(primal)==len(dual)
        image=set()
        B=[sum(1<<j for j,e in enumerate(self.edges) if e>>i&1) for i in range(self.n)]
        for u in primal:
            z=sum(1<<i for i,b in enumerate(B) if b&~u)
            assert z in dual
            assert all(bool(u>>j&1)==(z&e!=e) for j,e in enumerate(self.edges))
            image.add(z)
        assert image==dual
    def negative(self):
        c=0
        for i in range(self.n):
            for s in subsets(self.V^self.closed[i]):
                A=self.avoid[s]; assert A
                assert (A&self.bad[i]).bit_count()*self.size <= self.counts[i]*A.bit_count()
                c+=1
        return c
    def query(self,P,Qzero,weights):
        assert not P&Qzero
        # pattern contains P and contains no bit in Qzero
        mask=self.contain[P]
        for i in range(self.n):
            if Qzero>>i&1:mask&=~self.contain[1<<i]
        D=self.nb(P)|Qzero
        # Check the monotonic Bayes numerator inequality, even without a certificate.
        A=self.avoid[self.V^D]
        assert (mask&A).bit_count()*self.size <= mask.bit_count()*A.bit_count()
        if weights is not None:
            W=product(1-weights[i] for i in range(self.n) if D>>i&1)
            assert (mask&self.good).bit_count()*2**((P|Qzero).bit_count())*W <= self.ng
    def certify(self, weights):
        for i,a in enumerate(weights):
            if Q(self.counts[i],self.size)>a*product(1-weights[j] for j in range(self.n) if (self.closed[i]^(1<<i))>>j&1):return False
        return True
    def conditional(self,weights):
        for i in range(self.n):
            for S in subsets(self.V^(1<<i)):
                A=self.avoid[S]
                assert (A&self.bad[i]).bit_count() <= weights[i]*A.bit_count()
        assert self.ng>=self.size*product(1-a for a in weights)
        for e in self.edges:
            C=(self.contain[e]&self.good).bit_count()
            assert C*2**e.bit_count()>=self.ng
            for J in subsets(e):
                if not J:continue
                W=product(1-weights[i] for i in range(self.n) if self.nb(J)>>i&1)
                assert C*2**J.bit_count()*W<=self.ng

def audit(quick=False):
    rng=Random(20261125); stats=dict(exhaustive_models=0,random_models=0,negative_conditionings=0,
                                   mixed_patterns=0,certified_models=0,asymmetric_models=0)
    def visit(n,edges,exhaustive,idx):
        m=Model(n,edges); m.dual()
        stats['negative_conditionings']+=m.negative()
        stats['exhaustive_models' if exhaustive else 'random_models']+=1
        # For exhaustive n<=3 all patterns. For n=4 use a deterministic subsample,
        # but verify the negative-dependency statement on every model.
        if n<=3 or not exhaustive or idx%97==0:
            weights=None
            for k in (64,32,16,12,10,8,6,5,4,3,2):
                w=[Q(1,k)]*n
                if m.certify(w):weights=w;break
            if weights is not None:
                stats['certified_models']+=1;m.conditional(weights)
                # Lower one coordinate's certificate if possible; tests asymmetry.
                for i in range(n):
                    w=weights.copy(); w[i]/=2
                    if m.certify(w):
                        weights=w;m.conditional(weights);stats['asymmetric_models']+=1;break
            if n<=4:
                for P in range(m.size):
                    for Qz in subsets(m.V^P):
                        m.query(P,Qz,weights);stats['mixed_patterns']+=1
            else:
                for _ in range(40):
                    P=rng.randrange(m.size); Qz=rng.randrange(m.size)&~P
                    m.query(P,Qz,weights);stats['mixed_patterns']+=1
    for n in range(1,4 if quick else 5):
        all_edges=list(range(1,1<<n))
        for idx in range(1<<len(all_edges)):
            visit(n,[e for j,e in enumerate(all_edges) if idx>>j&1],True,idx)
    # Dense and sparse arbitrary support hypergraphs, including overlaps,
    # varying rank, isolated vertices and singleton supports.
    for idx in range(50 if quick else 200):
        n=rng.randrange(5,10)
        candidates=[e for e in range(1,1<<n) if 2<=e.bit_count()<=4]
        density=rng.choice((.1,.25,.5,.85,1.0))
        edges=[e for e in candidates if rng.random()<density]
        if idx%4==0:edges.extend(1<<i for i in range(n) if rng.random()<.5)
        visit(n,edges,False,idx)
    return stats

def main():
    p=argparse.ArgumentParser();p.add_argument('--quick',action='store_true');args=p.parse_args()
    out={'regular_table':regular_table(),'special_certificates':special(),'finite_audit':audit(args.quick),
         'scope':'All comparisons are integer or Fraction exact. Finite audits are supplementary, not a proof of unbounded results.'}
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
