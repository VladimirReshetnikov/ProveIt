"""Reproduce independent finite certificate, binding and public-CLI checks.

This module is untrusted validation support. Finite checks are not proofs of
soundness, consistency, completeness or bi-interpretability. Production source
is loaded only after AST-isolating its inspected imports, constant and function
definitions; every fixture is also exercised through the unchanged public CLI.
"""
import ast
from collections import Counter
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import types

from generate_cases import write_cases
from named_oracle import Oracle, opening, computation_rhs, embed_scalar

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PROGRAMS = {'full': ROOT / 'checker.py',
            'scalar': ROOT / 'checker_scalar.py'}


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def load_kernel(path, source=None):
    source = path.read_text() if source is None else source
    tree = ast.parse(source, filename=str(path))
    body = []
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef)):
            body.append(node)
        elif isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'k'
                                                  for t in node.targets):
            body.append(node)
    module = types.ModuleType(path.stem)
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), module.__dict__)
    return module


def run(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'final_k': module.k,
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def agreement(module, packet, width, name):
    actual = run(module, packet)
    expected = Oracle(width).run(packet)
    require(actual['accepted'] == expected['accepted'], ('oracle verdict', name, actual, expected))
    if actual['accepted']:
        for field in ('final_k', 'remaining'):
            require(actual[field] == expected[field], ('successful trace', name, field, actual, expected))
    return actual, expected


def opening_audit(module, width):
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 999,
             True, False, 0.0, 1.0, None, {}, '0']
    terms = [*atoms, [], [0], [1], [999], [0, 0], [0, 0, 1],
             [0, 0, 3], [0, 0, 5], [0, 0, 999],
             [1, 0, [0, 3, 7]], [0, 0, [0, 1, 999]],
             [3, 1, [5, 7, [1]]]]
    formulas = [[term, 0] for term in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5, 7, 999)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 7, 999)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 999], 5]], [0, 0], [0, 0]]]
    images = [None, 0, -1, -3, 1, 2, [0], [0, 0, 1], [0, 0, 3], True, {}]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2, 3):
                for lower in (0, -2):
                    for image in images:
                        module.k = lower
                        try:
                            actual = module.inst(deepcopy(value), deepcopy(image),
                                                 2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        try:
                            expected = opening(deepcopy(value), deepcopy(image), formula=formula,
                                               depth=depth, lower=lower, width=width)
                            valid_expected = True
                        except Exception:
                            expected, valid_expected = None, False
                        require(valid == valid_expected and (not valid or actual == expected),
                                ('opening', width, value, image, formula, depth, lower, actual, expected))
                        counts['accepted' if valid else 'rejected'] += 1
    return dict(counts)


def random_term(rng, depth, bound, width):
    choices = [0, -1, -2, *range(1, 2 * bound + 1)]
    if depth == 0 or rng.random() < .45:
        return rng.choice(choices)
    if rng.random() < .4:
        return [random_term(rng, depth - 1, bound, width)]
    return [random_term(rng, depth - 1, bound, width),
            random_term(rng, depth - 1, bound, width),
            random_term(rng, depth - 1, bound + width, width)]


def staged_opening_audit(module, count=3000):
    rng = random.Random(2026110801)
    module.k = -2
    for i in range(count):
        counter = random_term(rng, 2, 0, 2)
        initial = random_term(rng, 2, 0, 2)
        update = random_term(rng, 3, 2, 2)
        lhs = [[counter], initial, update]
        actual = module.inst(module.inst(update, counter, 3), [counter, initial, update], 1)
        expected = computation_rhs(lhs, lower=-2, width=2)
        require(actual == expected, ('staged versus simultaneous', i, lhs, actual, expected))
    return {'cases': count, 'seed': 2026110801,
            'comparison': 'production sequential opening versus simultaneous named substitution'}


def embedding_opening_audit(scalar, full, count=2000):
    rng = random.Random(2026110802)
    for i in range(count):
        depth = rng.randrange(4)
        # Generate one more explicit bound coordinate, then treat it as the
        # sole external template hole. Named embedding re-encodes that hole.
        value = random_term(rng, 3, depth + 1, 1)
        image = random_term(rng, 2, 0, 1)
        scalar.k = full.k = -2
        opened = scalar.inst(value, image, 2 * depth + 1)
        embedded_opened = embed_scalar(opened, formula=False, depth=depth, lower=-2)
        template = embed_scalar(value, formula=False, depth=depth, lower=-2, template=True)
        embedded_image = embed_scalar(image, formula=False, lower=-2)
        opened_embedded = full.inst(template, embedded_image, 2 * depth + 1)
        require(embedded_opened == opened_embedded,
                ('embedding/opening', i, depth, value, image, embedded_opened, opened_embedded))
    return {'cases': count, 'seed': 2026110802,
            'comparison': 'scalar opening then embedding versus embedding then full opening'}


def paths(value, path=()):
    result = [path]
    if type(value) is list:
        for i, child in enumerate(value):
            result.extend(paths(child, (*path, i)))
    return result


def mutate(value, rng):
    value = deepcopy(value)
    path = rng.choice(paths(value))
    replacements = [None, True, False, -999, -1, 0, 1, 2, 3, 5, 999,
                    [], [0], [0, 0], [0, 0, 0, 0], {'bad': 0}, 'x', 0.0]
    replacement = deepcopy(rng.choice(replacements))
    if not path:
        return replacement
    parent = value
    for position in path[:-1]:
        parent = parent[position]
    parent[path[-1]] = replacement
    return value


def mutation_agreement(module, rows, width, count=2000):
    rng = random.Random(2026110803 + width)
    eligible = [row['packet'] for row in rows if row['expected'] and len(row['packet']) < 150]
    counts = Counter()
    for i in range(count):
        value = mutate(rng.choice(eligible), rng)
        actual, _ = agreement(module, value, width, 'mutation_' + str(i))
        counts['accepted' if actual['accepted'] else 'rejected'] += 1
    return {'cases': count, 'seed': 2026110803 + width, **dict(counts)}


def controls(path, rows, width):
    source = path.read_text()
    specifications = [
        ('capture_allowed', 'inst(t, d=1)', 'inst(t, d=d)',
         'contextual_capture_attack', True),
        ('compound_induction_allowed', 'h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [a, inst(a, 0)]', 'compound_induction_hypothesis_attack', True),
        ('atomic_base_deleted', 'h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [a] if len(a) == 2 else [inst(a, 0)]', 'retained_false_base_is_used', False),
        ('future_parameters_allowed', ' and a >= k', '',
         'future_parameter_in_unused_update', True),
        ('goal_validation_removed', 'if inst(a) in g:', 'if a in g:',
         'future_parameter_in_unused_update', True),
        ('implicit_zero_image', 'def inst(a, t=None, d=0):', 'def inst(a, t=0, d=0):',
         'global_unused_update_hole', True),
        ('booleans_count_as_integers', 'type(a) is int', 'isinstance(a, int)',
         'boolean_unused_update_is_invalid', True),
    ]
    if width == 2:
        specifications += [
            ('counter_and_state_exchanged',
             't = inst(inst(r, n, 3), [n, t, r], 1)',
             't = inst(inst(r, [n, t, r], 3), n, 1)',
             'counter_and_state_swapped', True),
            ('outer_counter_opening_omitted',
             't = inst(inst(r, n, 3), [n, t, r], 1)',
             't = inst(r, [n, t, r], 1)',
             'counter_and_state_swapped', True),
        ]
    else:
        specifications.append(('phantom_scalar_counter', "b'\\0\\0\\2'", "b'\\0\\0\\4'",
                               'unused_counter_update_coordinate', True))
    by_name = {row['name']: row for row in rows}
    result = []
    for label, before, after, name, expected in specifications:
        require(source.count(before) == 1, ('mutation anchor', label))
        module = load_kernel(path, source.replace(before, after))
        actual = run(module, by_name[name]['packet'])['accepted']
        require(actual == expected, ('sensitivity control', label, name, actual, expected))
        require(actual != by_name[name]['expected'], ('control did not flip verdict', label))
        result.append({'mutant': label, 'fixture': name, 'mutant_accepts': actual,
                       'correct_accepts': by_name[name]['expected']})
    return result


def cli(path, packet_path, expected, optimized=False):
    command = [sys.executable, *(['-O'] if optimized else []), str(path), str(packet_path)]
    process = subprocess.run(command, capture_output=True, text=True, timeout=15)
    actual = (process.returncode, process.stdout.strip(), process.stderr)
    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
    require(actual == wanted, ('public CLI', path.name, packet_path.name, optimized, actual))
    return {'optimized': optimized, 'exit_status': process.returncode,
            'stdout': process.stdout.strip()}


def main():
    cases = write_cases(HERE / 'cases')
    modules = {name: load_kernel(path) for name, path in PROGRAMS.items()}
    result = {'python': platform.python_version(), 'scope': 'finite executable validation',
              'programs': {name: {'path': path.name,
                                  'sha256': sha256(path.read_bytes()).hexdigest()}
                           for name, path in PROGRAMS.items()}, 'profiles': {}}
    for name, width in [('full', 2), ('scalar', 1), ('embedded', 2)]:
        key = 'full' if name == 'embedded' else name
        profile = {'fixtures': [], 'rules_exercised': {}}
        total_rules = Counter()
        for row in cases[name]:
            actual, oracle = agreement(modules[key], row['packet'], width, name + '/' + row['name'])
            require(actual['accepted'] == row['expected'], ('fixture expectation', name, row['name'], actual))
            if row['expected'] and 'producer_allocations' in row:
                require(-actual['final_k'] == row['producer_allocations'],
                        ('producer/oracle allocation', name, row['name'], actual))
            total_rules.update(oracle['rules'])
            checks = [cli(PROGRAMS[key], HERE / 'cases' / name / (row['name'] + '.json'), row['expected'])]
            if row['name'] in ('successor_uses_counter', 'atomic_induction_recursion_identity',
                               'contextual_capture_attack', 'failed_major_retains_consumed_allocation',
                               'power_two_three'):
                checks.append(cli(PROGRAMS[key], HERE / 'cases' / name / (row['name'] + '.json'),
                                  row['expected'], optimized=True))
            profile['fixtures'].append({'name': row['name'], 'expected': row['expected'],
                                        'actual': actual, 'oracle': oracle, 'cli': checks,
                                        'packet_sha256': sha256(json.dumps(row['packet']).encode()).hexdigest()})
        profile['fixture_count'] = len(cases[name])
        profile['accepted_count'] = sum(row['expected'] for row in cases[name])
        profile['rejected_count'] = profile['fixture_count'] - profile['accepted_count']
        profile['rules_exercised'] = dict(total_rules)
        if name != 'embedded':
            profile['opening_audit'] = opening_audit(modules[key], width)
            profile['mutation_agreement'] = mutation_agreement(modules[key], cases[name], width)
            profile['sensitivity_controls'] = controls(PROGRAMS[key], cases[name], width)
        result['profiles'][name] = profile
    result['sequential_opening'] = staged_opening_audit(modules['full'])
    result['embedding_opening'] = embedding_opening_audit(modules['scalar'], modules['full'])
    result['status'] = 'PASS'
    (HERE / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    summary = {'status': result['status'], 'python': result['python'], 'programs': result['programs'],
               'profiles': {name: {key: value for key, value in profile.items() if key != 'fixtures'}
                            for name, profile in result['profiles'].items()},
               'sequential_opening': result['sequential_opening'],
               'embedding_opening': result['embedding_opening']}
    (HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
