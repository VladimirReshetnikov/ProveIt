"""Replay a fixed six-term refutation of the 28 small successor models.

This is independent of the queue-based and random exploratory searches.
It checks only numeral-generated successor structures of sizes 2 through
8 with zero outside the successor range. It does not search for a model.

Run: python3 tied_finite_replay.py > tied_finite_replay_results.json
"""

import json


def iterator_table(update, successor, tail):
    """Return the forced table, or a certificate of its failed last edge."""
    size = len(successor)
    assert len(update) == size
    assert all(0 <= value < size for value in update)
    orbit = [successor[update[0]]]
    for _ in range(size):
        orbit.append(update[orbit[-1]])
    if orbit[size] != orbit[tail]:
        return None, {
            "update_table": list(update),
            "forced_orbit": orbit,
            "last_edge_left": orbit[tail],
            "last_edge_right": orbit[size],
        }
    return tuple(orbit[:size]), None


def refute(size, tail):
    assert 2 <= size <= 8 and 1 <= tail < size
    successor = tuple(range(1, size)) + (tail,)
    tables = {"c0": (0,) * size}
    dependencies = [("c0", "z"), ("z", "a"), ("a", "b"),
                    ("b", "c"), ("c", "unused")]
    for update_name, output_name in dependencies:
        output, failure = iterator_table(tables[update_name], successor, tail)
        if failure is not None:
            return {"size": size, "tail": tail, "cycle": size - tail,
                    "update_expression": update_name, **failure}
        tables[output_name] = output

    # e = a composed with z composed with a. All dependencies have passed.
    a, z = tables["a"], tables["z"]
    e = tuple(a[z[a[index]]] for index in range(size))
    _, failure = iterator_table(e, successor, tail)
    assert failure is not None, (size, tail)
    return {"size": size, "tail": tail, "cycle": size - tail,
            "update_expression": "a o z o a", **failure}


def main():
    certificates = [refute(size, tail)
                    for size in range(2, 9)
                    for tail in range(1, size)]
    assert len(certificates) == 28
    assert all(item["last_edge_left"] != item["last_edge_right"]
               for item in certificates)
    print(json.dumps({
        "scope": "Numeral-generated successor structures; zero not a successor",
        "definitions": {
            "c0": "constant zero",
            "z": "A(c0)",
            "a": "A(z)",
            "b": "A(a)",
            "c": "A(b)",
            "A(h)": "n maps to J(n; u.h(u))",
        },
        "size_range": [2, 8],
        "candidate_count": len(certificates),
        "refuted_count": len(certificates),
        "certificates": certificates,
    }, indent=2))


if __name__ == "__main__":
    main()
