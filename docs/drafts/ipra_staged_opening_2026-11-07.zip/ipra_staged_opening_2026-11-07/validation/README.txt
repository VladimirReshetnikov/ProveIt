VALIDATION OF SEQUENTIAL OPENING FOR FULL PRIMITIVE RECURSION
===========================================================

Run from the package's parent directory:

  python3 validation/verify.py

The runner expects checker.py and checker_scalar.py one level
above validation. Neither production checker imports any validation file.
The runner regenerates the proof packets, checks the named-binder oracle,
exercises each unchanged public CLI, and records exact source SHA-256 hashes.

Independent parts
-----------------
The oracle parses into named bound variables and re-encodes syntax. It does
not use the production byte-string sort/binder table or inst function.
For full recursion it computes the successor equation by SIMULTANEOUS named
substitution of the counter and previous value. The production checker instead
uses two sequential unary openings; their agreement is tested separately.
Scalar-to-full embedding introduces a fresh UNUSED counter name in every
update, then re-encodes all references. This shifts outer variable coordinates
correctly under nested updates. It does not blindly change the binder width.

Concrete proof packets
----------------------
The generated packets exercise both computation schemas; counter alone, state
alone, and both arguments; nested recursors; both paired-binder rules; both
closure rules; equality transport under quantifiers; induction with an actually
used atomic induction hypothesis; and a separately used retained false base.
Arithmetic examples include complete proofs of 2+3=5, 2*3=6, and 2^3=8.
They are verified certificates, not merely computed numerical values.

Negative fixtures include capture, undeclared parameters, cross-sort values,
malformed padding, inappropriate compound induction hypotheses, swapped
counter/state arguments, missing images, and malformed JSON data. Inert unused
annotations are deliberately permitted where the proof format permits them.
Two positive fixtures explicitly exercise a failed elimination guard falling
through into introduction, including a failed major that already consumed an
eigenparameter allocation. A raised exception must NOT trigger this fallback.

Sensitivity controls
--------------------
Seventeen deliberately incorrect kernel variants are tested against fixtures
that change verdict. They remove capture avoidance, permit compound induction,
delete the atomic base, permit future names, remove goal validation, supply an
implicit zero image, accept Boolean coordinates, exchange counter and state,
omit the outer opening, or invent a scalar counter binder.
These controls show that the named risks are actually exercised by the suite.
They are not alternative delivered kernels.

Scope
-----
All results are finite executable evidence. They do not establish universal
soundness, consistency, completeness, or bi-interpretability; those require
the mathematical arguments in the paper. The validation support is untrusted.
No production checker was changed in response to a failed test. One oracle-only
mistake involving exceptions versus False was found by differential mutation
and fixed; its counterexample and explanation are retained.
