"""Reproduce whole-program measurements and the common-driver control offline."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
spec = importlib.util.spec_from_file_location('source_measure', ROOT / 'comparison/source_measure.py')
metric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metric)


def minimum(rows):
    return {k: min(row['metrics'][k] for row in rows) for k in KEYS}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    groups = {}
    for group in ('current_programs', 'expanded_sources', 'broad_sources'):
        rows = []
        for item in manifest[group]:
            path = ROOT / item['file']
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest != item['sha256']:
                raise ValueError('Comparator hash mismatch: ' + item['file'])
            rows.append({**item, 'metrics': metric.metrics(path)})
        groups[group] = rows
    baseline = minimum(groups['current_programs'])
    if any(minimum(rows) != baseline for rows in groups.values()):
        raise ValueError('The expanded frontier differs from the current frontier.')
    candidates = [{'file': name, 'metrics': metric.metrics(ROOT / name)}
                  for name in ('checker.py', 'checker_scalar.py')]
    for item in candidates:
        item['strictly_below_current'] = all(item['metrics'][k] < baseline[k] for k in KEYS)
        if not item['strictly_below_current']:
            raise ValueError('Candidate no longer improves every current coordinate.')

    # Rebuild each program with exactly the direct program's public driver.
    # Retain its imports, constants and all function definitions unchanged.
    direct = ast.parse((ROOT / 'checker.py').read_text())
    first_try = next(i for i, node in enumerate(direct.body) if isinstance(node, ast.Try))
    driver = direct.body[first_try:]
    controlled = []
    sources = groups['current_programs'] + candidates
    with tempfile.TemporaryDirectory(prefix='ipra_common_driver_') as temporary:
        for index, item in enumerate(sources):
            tree = ast.parse((ROOT / item['file']).read_text())
            last_function = max(i for i, node in enumerate(tree.body)
                                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)))
            tree.body = tree.body[:last_function + 1] + driver
            path = Path(temporary) / (str(index) + '.py')
            path.write_text(ast.unparse(tree) + '\n')
            controlled.append({'source_path': item.get('source_path', item['file']),
                               'metrics': metric.metrics(path)})
    common = {'note': 'Identical standalone driver; all imports and checking functions retained.',
              'baseline_minimum': minimum(controlled[:-2]),
              'candidates': controlled[-2:], 'baseline': controlled[:-2]}
    result = {'python': platform.python_version(), 'commit': manifest['commit'],
              'archives': len(manifest['files']),
              'current_program_count': len(groups['current_programs']),
              'expanded_distinct_count': len(groups['expanded_sources']),
              'expanded_path_count': sum(len(r['source_paths']) for r in groups['expanded_sources']),
              'broad_distinct_count': len(groups['broad_sources']),
              'broad_path_count': sum(len(r['source_paths']) for r in groups['broad_sources']),
              'current_minimum': baseline,
              'candidates': candidates, 'groups': groups}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    (ROOT / 'results/common_driver.json').write_text(json.dumps(common, indent=2) + '\n')
    table = ['\\begin{longtable}{@{}p{.60\\linewidth}rrr@{}}',
             '\\toprule Complete current program & Tokens & Nodes & Bytes\\\\\\midrule',
             '\\endhead']
    for row in groups['current_programs']:
        path = Path(row['source_path'])
        label = path.parts[0].replace('ipra_', '').replace('_2026-11-07', '') + ' / ' + path.name
        label = label.replace('_', '\\_')
        nums = [row['metrics'][k] for k in KEYS]
        table.append('\\texttt{' + label + '} & ' + ' & '.join(map(str, nums)) + '\\\\')
    table += ['\\bottomrule', '\\end{longtable}']
    (ROOT / 'results/current_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({'current_minimum': baseline, 'common_driver_minimum': common['baseline_minimum'],
                      'candidates': candidates}, indent=2))


if __name__ == '__main__':
    main()
