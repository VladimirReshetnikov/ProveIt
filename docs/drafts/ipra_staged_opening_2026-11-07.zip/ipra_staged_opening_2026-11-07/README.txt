STAGED OPENING FOR iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
================================================

Read report.pdf; report.tex and all its input sections are included.

RESULT

The direct calculus keeps full primitive recursion, with its counter and
previous value, but opens the two variables one at a time. Its complete
standalone checker has 383 normalized tokens / 409 AST nodes / 1133 bytes.
This is below the current supplied-program envelope 389 / 413 / 1159.
Its arithmetic proof is direct: predecessor is R(n,0;v,u.v), and general
primitive recursion is already available. Five inherited logical inference
patterns reconstruct full intuitionistic first-order logic.

The smallest delivered checker is the integrated scalar companion, at
376 / 403 / 1121. Its arithmetic basis is inherited. The paper includes
its longer internal predecessor/reflection/pairing proof with attribution.

FAIR COMPARISON CONTROL

Giving every current program exactly the same standalone public driver
changes the baseline envelope to 384 / 407 / 1129. The scalar companion
still beats all three coordinates. The direct checker is one token smaller
but two AST nodes and four bytes larger than that controlled envelope.
Do not characterize the direct checker as beating every controlled measure.

NEW MATHEMATICAL OBSTRUCTION

For update-tied initialization J(n;h)=h^n(1+h(0)), numerical terms have
finite rectangular unary dependence. This remains true with arbitrary
unary helpers. No finite list of native terms covers addition or pairing.
No infinite finite-dimensional quotient has an injective pairing with a
fixed finite native-term cover. General graph-defined interpretations
without such a cover remain open. Without decreasing unary helpers, even
a predecessor or exceptional-zero successor decoder has no native term.

RUN

  python3 checker.py validation/cases/full/addition_two_three.json
  python3 checker_scalar.py PATH_TO_SCALAR_PACKET.json
  python3 reproduce.py
  python3 build.py

See validation/cases/full/ for the exact generated example filenames.
The first two commands print ACCEPT and exit 0, or REJECT and exit 1.
The reproduction command verifies all frozen source hashes, recomputes
measurements and the common-driver control, regenerates certificates,
runs the independent named-binder validation, and replays 28 small finite
structures. No network is required. The build uses pdfLaTeX, with shell
escape disabled, and the packages listed in report.tex.

FILES

  checker.py             Complete direct proof checker.
  checker_scalar.py      Complete smaller scalar companion.
  FORMAT.txt             Full raw certificate specification.
  report.tex / report.pdf Mathematical development and evidence.
  sections/              Main proof, staged opening, and obstructions.
  appendices/            Attributed scalar proof and complete code listings.
  comparison/            Pinned manifest, 127 distinct frozen sources, metric.
  validation/            Named oracle, proof fixtures, mutation controls, results.
  results/               Measurements, build logs, document quality checks.
  ATTRIBUTION.txt         Inherited versus new contributions and source snapshot.
  LICENSE.txt             Preserved permissive source license.
  SHA256SUMS              Final file identities (excluding the checksum file).

SCOPE

Both ordinary realizations are proved bi-interpretable and equiconsistent
with full first-order iPRA, with identity-domain internal composites.
These are written mathematical proofs, supported by finite implementation
checks. No Lean/Rocq mechanization or absolute shortestness theorem is claimed.
The smaller numerical scores include some integration of already-known
implementation choices; they are not labeled a new arithmetic foundation.

Pinned ProveIt commit:
6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb
https://github.com/VladimirReshetnikov/ProveIt/tree/6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb/docs/drafts
