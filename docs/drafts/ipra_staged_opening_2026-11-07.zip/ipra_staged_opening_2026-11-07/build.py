"""Build the report with pdfLaTeX in a temporary directory; no shell escape."""
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which('pdflatex'):
        raise SystemExit('Install pdfLaTeX and the packages listed in report.tex.')
    (ROOT / 'results').mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ipra_report_') as temporary:
        directory = Path(temporary)
        for path in ROOT.rglob('*.tex'):
            relative = path.relative_to(ROOT)
            target = directory / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        for name in ('checker.py', 'checker_scalar.py'):
            shutil.copy2(ROOT / name, directory / name)
        for pass_number in range(1, 4):
            process = subprocess.run(['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
                                      '-halt-on-error', 'report.tex'], cwd=directory,
                                     text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            (ROOT / 'results' / ('latex_pass_' + str(pass_number) + '.txt')).write_text(process.stdout)
            if process.returncode:
                print(process.stdout[-10000:])
                raise SystemExit(process.returncode)
        shutil.copy2(directory / 'report.pdf', ROOT / 'report.pdf')
        shutil.copy2(directory / 'report.log', ROOT / 'results/latex_final.log')
    print('Built report.pdf')


if __name__ == '__main__':
    main()
