"""Recompute the frozen measurements and meaningful finite validation offline."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(script, output):
    process = subprocess.run([sys.executable, '-B', str(ROOT / script)], cwd=ROOT,
                             text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ROOT / output).write_text(process.stdout)
    if process.returncode:
        print(process.stdout)
        raise SystemExit(process.returncode)
    print('PASS:', script)


def main():
    (ROOT / 'results').mkdir(exist_ok=True)
    run('measure.py', 'results/measurement_run.txt')
    run('validation/verify.py', 'results/validation_run.txt')
    run('validation/tied_finite_replay.py', 'validation/tied_finite_replay_results.json')
    validation = json.loads((ROOT / 'validation/summary.json').read_text())
    finite = json.loads((ROOT / 'validation/tied_finite_replay_results.json').read_text())
    if validation['status'] != 'PASS' or finite['refuted_count'] != 28:
        raise SystemExit('A required validation condition failed.')
    print('All bundled measurements and finite checks passed.')


if __name__ == '__main__':
    main()
