A SMALLER COMPLETE PRESENTATION OF INTUITIONISTIC PRA
Instantiation at one variable
Prepared for Vladimir Reshetnikov, 6 November 2026

RESULT
The complete checker is strictly smaller than all 16 complete checker
variants in the six current ProveIt drafts at commit
9e8e3161b0dffb54fceb0b75ee818cc9e4ed2b10.

                              Current minimum       This checker
Significant source tokens                  499                494
Normalized tokens                          505                494
Python AST nodes                           510                505
Normalized UTF-8 bytes                    1,554              1,533

The uniformly isolated core also improves every coordinate:
436 normalized tokens / 439 AST nodes / 1,271 normalized bytes,
against 447 / 444 / 1,292. Measurements use CPython 3.12.14.

The claim is relative to the pinned finite corpus and stated Python
boundary. This is not a theorem of absolute shortestness or an
encoding-independent lower bound.

NEW REDUCTION
The inherited unary closure binder means B(0) -> forall x B(x).
The delivered calculus restricts its primitive elimination to current
variable coordinate 1, so the rule has no numerical witness argument.
General elimination at t is recovered by an existential equality witness:
name t by a fresh y, instantiate at y, transport along y=t, and close
the existential. The proof compiler operates on SOURCE derivations by
height, resolving the scope-lifting issue without assuming the desired
target structural admissibility. The checker also combines syntactic
sort and binder depth in the single integer d=2*depth+sort.

THEORY
Numerical terms: zero, variables, successor, initialized primitive recursion.
Formulas: equality, unary numerical closure Q, existential quantification.
Primitive rules: hypothesis, Q introduction, fixed-variable Q elimination,
equality-guarded existential introduction, existential elimination, and
equality transport. Arithmetic axioms: the zero and successor recursor
equations. Q introduction retains its zero base, and additionally gets an
induction hypothesis only when its matrix is literally an equation.

The report reconstructs full intuitionistic first-order logic and all
quantifier-free induction instances. The ordinary realization contains
the explicit falsity bridge 0=S0 -> bottom and numerical coverage. Its
two ordinary interpretations with iPRA have whole-domain identity
isomorphisms, justified by internal recursion uniqueness at arbitrary
counters, including nonstandard ones. The new native calculus has exactly
the same consequence relation as the inherited unrestricted calculus.

FILES
report.pdf / report.tex / sections/  Full paper and complete LaTeX sources.
checker.py                       Entire trusted acceptance program.
FORMAT.txt                       Exact syntax and certificate convention.
validation/transport.py          Untrusted canonical-source proof compiler.
validation/named_reference.py    Independent named-variable rule interpreter.
validation/source_sequents.json  Frozen source derivations with provenance.
validation/verify.py              Corpus, scope, ignored-field, and CLI tests.
validation/audit_packed.py         Independent substitution and syntax audit.
examples/transported/             89 accepted closed target certificates.
comparison/                     All 16 unchanged baseline checkers, hashes,
                                exact archive names, URLs, measurement script.
results/                        Recomputed metrics and complete test records.
LICENSE_SOURCE.txt              MIT-0 license of adapted draft material.
MANIFEST.sha256                 Hashes of all other delivered files.

QUICK START
From inside the extracted directory, with Python 3.10 or later:

  python3 checker.py examples/transported/001_successor_plus_theorem.json
  python3 reproduce.py

The first command should print ACCEPT. Reproduction uses no network and
only the Python standard library. Open-sequent audit cases use a private
validated-context boundary; the public checker accepts only closed-context
documents [goal,proof_stack]. Free numerical parameters remain arbitrary.

To compile the PDF, install a normal pdfLaTeX distribution with the packages
listed at the start of report.tex, then run:

  python3 build.py

Before regenerating any files, verify the delivered snapshot with:

  sha256sum -c MANIFEST.sha256

To regenerate the ZIP and update its manifest after changes:

  python3 package.py

EVIDENCE AND LIMITS
161 unique source derivations translated successfully: 89 closed and 72 open
audit sequents. The candidate and independent named oracle agree on all.
89 valid and 23 invalid documents were checked through the actual CLI.
Additional checks cover 8 richer source proofs under 3 extra parameters,
8 ignored-placeholder variants, 8,000 independent substitution comparisons,
3,614 JSON grammar comparisons,115 malformed goals, and3 fixed-slot cases.
Complete records are in results/.

General soundness, completeness, logical reconstruction, and bi-
interpretability are mathematical proofs in the paper. The finite tests
do not replace those proofs; no completed Lean/Rocq formalization or
verified Python runtime is claimed. The executable compiler parses the
canonical source-certificate subset, not arbitrary permissive encodings.
Unused proof prefixes and designated dummy annotations are harmless data.
Actual formulas, numerical witnesses, and recursor bodies are validated.

ATTRIBUTION
The unary calculus, gates/selectors, arithmetic reflection, ordinary
interpretations, and base-retention obstruction come from the supplied
drafts. They are restated with attribution to make this package self-
contained. The new contributions are the fixed-variable restriction and
its compiler proof, the shared sort/depth implementation, and their
measured integration. Existing arithmetic axioms are preserved.
