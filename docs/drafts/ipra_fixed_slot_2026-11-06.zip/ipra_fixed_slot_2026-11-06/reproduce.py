"""Reproduce the measurements, compiler replay, CLI checks, and independent audit."""
from pathlib import Path
import json
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
commands = [
    [sys.executable, 'comparison/measure.py'],
    [sys.executable, 'validation/verify.py'],
    [sys.executable, 'validation/audit_packed.py', 'checker.py',
     'validation/named_reference.py', 'results/packed_audit.json'],
]
for command in commands:
    subprocess.run(command, cwd=ROOT, check=True)

def read(name):
    return json.loads((ROOT / 'results' / name).read_text())

metrics, verification, audit = map(read, ['metrics.json', 'verification.json', 'packed_audit.json'])
summary = {
    'python_version': platform.python_version(),
    'checker_sha256': metrics['candidates']['checker.py']['sha256'],
    'strict_whole_program_improvement': all(metrics['whole_strict_improvement'].values()),
    'strict_core_improvement': all(metrics['core_strict_improvement'].values()),
    'unique_translated_derivations': verification['unique_source_derivations'],
    'closed_derivations': verification['closed_derivations'],
    'open_derivations': verification['open_derivations_with_validated_contexts'],
    'cli_cases': verification['cli_cases'],
    'verification_failures': verification['failures'],
    'independent_audit': audit,
}
assert summary['strict_whole_program_improvement'] and summary['strict_core_improvement']
assert not summary['verification_failures'] and audit['status'] == 'all passed'
(ROOT / 'results/reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
