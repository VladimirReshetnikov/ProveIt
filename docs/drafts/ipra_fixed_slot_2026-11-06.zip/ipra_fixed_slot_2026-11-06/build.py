"""Compile the complete paper with pdfLaTeX; no network access is needed."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
for _ in range(2):
    subprocess.run(
        ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
        cwd=ROOT, check=True)
print(ROOT / 'report.pdf')
