"""Refresh the integrity manifest and create the distributable ZIP."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDE_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.synctex'}
files = sorted(p for p in ROOT.rglob('*')
               if p.is_file() and '__pycache__' not in p.parts
               and p.suffix not in EXCLUDE_SUFFIXES
               and p.name != 'MANIFEST.sha256')
manifest = ROOT / 'MANIFEST.sha256'
manifest.write_text(''.join(
    hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix() + '\n'
    for p in files))
destination = ROOT.parent / (ROOT.name + '.zip')
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files + [manifest]):
        archive.write(path, ROOT.name + '/' + path.relative_to(ROOT).as_posix())
print(destination)
