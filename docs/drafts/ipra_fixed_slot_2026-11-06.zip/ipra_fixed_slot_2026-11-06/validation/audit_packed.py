"""Independent audits for packed sorted substitution and raw JSON syntax.

Usage: python3 audit_packed.py CHECKER NAMED_REFERENCE [RESULT_JSON]
The named reference uses dataclasses and named variable replacement; it must
not import the checked kernel.  This is finite evidence, not a formal proof.
"""
import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import sys


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def grammar(a, formula=True):
    if not formula and type(a) is int:
        return True
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    table = {'=': (False, False), 'q': (True,), 'ex': (True,)} if formula else {
        's': (False,), 'r': (False, False, False)}
    kinds = table.get(a[0])
    return (kinds is not None and len(a) == len(kinds) + 1
            and all(grammar(x, k) for x, k in zip(a[1:], kinds)))


def main():
    checker_path, reference_path, *output = sys.argv[1:]
    checker = module('packed_candidate', checker_path)
    reference = module('named_substitution_reference', reference_path)
    rng = random.Random(20261106)

    def term(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return rng.choice([0, 1, 2, 3, 4, 5, 8, -1, -17])
        if rng.randrange(2) == 0:
            return ['s', term(depth - 1)]
        return ['r', term(depth - 1), term(depth - 1), term(depth - 1)]

    def formula(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return ['=', term(3), term(3)]
        return [rng.choice(['q', 'ex']), formula(depth - 1)]

    environments = [
        (0,), (1,), (3,), (0, 0), (['s', 1], 0), (-9, -1),
        (['r', 1, -3, ['s', 1]], -1),
        (['r', 2, 1, ['r', 1, 3, ['s', 2]]], ['s', 1], -2),
    ]
    comparisons = 0
    for index in range(250):
        is_formula = index % 2 == 0
        expression = formula(5) if is_formula else term(5)
        for depth in range(4):
            for environment in environments:
                expected = reference.substitution(
                    expression, environment, depth, is_formula)
                actual = checker.subst(copy.deepcopy(expression), environment,
                                       2 * depth + int(not is_formula))
                assert actual == expected, (index, depth, environment, actual, expected)
                comparisons += 1

    malformed = [None, False, True, 0.0, 1.0, -1.0, '', '0', 's', 'r',
                 'q', 'ex', '=', 's0', 'ss0', 'q=', 'ex=', {},
                 {'s': None, 'x': None},
                 {'r': None, '0': None, '1': None, '2': None},
                 {'=': None, '0': None, '1': None},
                 {'q': None, '=': None}, {'ex': None, '=': None}]
    strings = [''.join(s) for n in range(5)
               for s in itertools.product('srq=01', repeat=n)]
    objects = [dict.fromkeys(keys, None) for keys in itertools.product(
        ['s', 'r', 'q', 'ex', '=', '0', '1', 'ss0', 'q='], repeat=2)]
    expressions = malformed + strings + objects + [
        0, 1, -1, ['s', 0], ['r', 0, 1, 2], ['r', ['s', 0], 1, ['s', 1]],
        ['=', 0, 0], ['q', ['=', 1, 1]], ['ex', ['=', 1, 0]],
        ['=', ['r', 0, 0, 0], 0]]
    for bad in malformed:
        expressions.extend([['s', bad], ['r', 0, 0, bad], ['=', bad, 0],
                            ['=', 0, bad], ['q', bad], ['ex', bad]])
    grammar_comparisons = 0
    for expression in expressions:
        for is_formula in (False, True):
            try:
                checker.subst(copy.deepcopy(expression), (0,), int(not is_formula))
                success = True
            except Exception:
                success = False
            assert success == grammar(expression, is_formula), (
                expression, is_formula, success)
            grammar_comparisons += 1

    def accepts(goal, stack, context=()):
        try:
            return bool(checker.check(copy.deepcopy(goal), copy.deepcopy(stack),
                                      copy.deepcopy(list(context))))
        except Exception:
            return False

    assert accepts(['=', ['r', 0, 0, 0], 0], [[]])
    assert accepts(['q', ['=', 0, 0]], [None, []])
    rejections = 0
    for bad in malformed:
        bad_goals = [bad, ['=', ['r', 0, bad, 0], bad],
                     ['=', ['r', 0, 0, bad], 0], ['q', ['=', bad, bad]],
                     ['ex', ['=', 1, bad]]]
        for goal in bad_goals:
            assert not accepts(goal, [None, []]), goal
            rejections += 1
    # Direct restriction: Q(x=0) with its base licenses x_1=0, not x_2=0.
    # These are internal-sequent tests, never assumed to be empty-context theorems.
    major = ['q', ['=', 1, 0]]
    base = ['=', 0, 0]
    stack = [None, None, [major, {'ignored': True}]]
    assert accepts(['=', 1, 0], stack, [major, base])
    assert not accepts(['=', 2, 0], stack, [major, base])
    assert not accepts(['=', ['s', 0], 0], stack, [major, base])
    result = {
        'checker_sha256': hashlib.sha256(Path(checker_path).read_bytes()).hexdigest(),
        'named_reference_sha256': hashlib.sha256(Path(reference_path).read_bytes()).hexdigest(),
        'named_substitution_comparisons': comparisons,
        'json_grammar_comparisons': grammar_comparisons,
        'malformed_goal_rejections': rejections,
        'fixed_slot_checks': 3,
        'status': 'all passed',
        'limits': 'Finite evidence; general correctness is a written mathematical proof.'}
    rendered = json.dumps(result, indent=2) + '\n'
    if output:
        Path(output[0]).write_text(rendered)
    print(rendered, end='')


if __name__ == '__main__':
    main()
