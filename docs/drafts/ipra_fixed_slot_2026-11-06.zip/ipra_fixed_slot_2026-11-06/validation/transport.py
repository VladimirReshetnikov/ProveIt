"""Compile canonical unrestricted-Q derivations into the fixed-slot calculus.

This file is an untrusted certificate producer, never imported by checker.py.
The named reference is adapted from the pinned baseline under MIT-0.  The
compiler and its strengthened recursion below are new to this package.

Parsing validates a source derivation using named variables.  Compilation
recurses on SOURCE child derivations with a larger local-name environment.
It never assumes that an already compiled target proof can be shifted.
Thus the algorithm realizes the height-induction completeness argument.

Usage: python3 transport.py source.json target.json
The canonical subset uses null hypothesis instructions and exact exhaustion.
"""
from copy import deepcopy
from dataclasses import dataclass
from itertools import count
import json
from pathlib import Path
import sys

import named_reference as N


@dataclass(frozen=True)
class Derivation:
    goal: object
    rule: str
    children: tuple = ()
    eigen: object = None
    witness: object = None
    motive: object = None
    hole: object = None


def normalize_tags(data):
    """The inspected baseline families use either u or q for the same binder."""
    if isinstance(data, list):
        return [normalize_tags(value) for value in data]
    return 'q' if data == 'u' else data


class SourceParser(N.Oracle):
    def __init__(self):
        super().__init__(fixed_slot=False)

    def parse(self, goal, stack, context=(), local=()):
        if type(stack) is not list or not stack:
            raise N.Invalid('A nonempty proof stack is required')
        instruction = stack.pop()

        if isinstance(goal, N.Q) and instruction == []:
            eigen = self.fresh('eigen')
            assumptions = [*context, N.instantiate(goal, N.Zero())]
            if isinstance(goal.body, N.Eq):
                assumptions.append(N.instantiate(goal, N.Var(eigen)))
            child = self.parse(N.instantiate(goal, N.Succ(N.Var(eigen))),
                               stack, assumptions, (eigen,) + local)
            return Derivation(goal, 'qi', (child,), eigen=eigen)

        if (isinstance(goal, N.Ex) and type(instruction) is list
                and len(instruction) == 1):
            witness = self.term(instruction[0], local)
            eigen = self.fresh('eigen')
            assumptions = [*context, N.Eq(N.Var(eigen), witness)]
            child = self.parse(N.instantiate(goal, N.Var(eigen)),
                               stack, assumptions, (eigen,) + local)
            return Derivation(goal, 'ei', (child,), eigen=eigen, witness=witness)

        if (type(instruction) is list and len(instruction) == 2
                and type(instruction[0]) is list and instruction[0]):
            raw_major, annotation = instruction
            major = self.formula(raw_major, local)
            major_proof = self.parse(major, stack, context, local)
            if isinstance(major, N.Ex):
                eigen = self.fresh('eigen')
                assumptions = [*context, N.instantiate(major, N.Var(eigen))]
                branch = self.parse(goal, stack, assumptions, (eigen,) + local)
                return Derivation(goal, 'ee', (major_proof, branch), eigen=eigen)
            if isinstance(major, N.Eq):
                hole = self.fresh('template')
                motive = self.formula(annotation, (hole,) + local)
                premise = N.replace(motive, {hole: major.left})
                conclusion = N.replace(motive, {hole: major.right})
                if not N.same(goal, conclusion):
                    raise N.Invalid('Wrong equality-transport conclusion')
                minor = self.parse(premise, stack, context, local)
                return Derivation(goal, 'eq', (major_proof, minor),
                                  motive=motive, hole=hole)
            if isinstance(major, N.Q):
                witness = self.term(annotation, local)
                if not N.same(goal, N.instantiate(major, witness)):
                    raise N.Invalid('Wrong unrestricted-Q conclusion')
                minor = self.parse(N.instantiate(major, N.Zero()),
                                   stack, context, local)
                return Derivation(goal, 'qe', (major_proof, minor), witness=witness)
            raise N.Invalid('Unknown eliminable formula')

        if isinstance(goal, N.Eq) and isinstance(goal.left, N.Rec) and instruction == []:
            term = goal.left
            if isinstance(term.index, N.Zero):
                result = term.initial
            elif isinstance(term.index, N.Succ):
                predecessor = term.index.value
                previous = N.Rec(predecessor, term.initial, term.accumulator,
                                 term.predecessor, term.step)
                result = N.replace(term.step, {term.accumulator: previous,
                                              term.predecessor: predecessor})
            else:
                raise N.Invalid('Computation requires zero or successor')
            if not N.same(goal.right, result):
                raise N.Invalid('Wrong recursion equation')
            return Derivation(goal, 'r')

        if instruction is None and any(N.same(goal, a) for a in context):
            return Derivation(goal, 'hyp')
        raise N.Invalid('Not a canonical source inference')


class Compiler:
    def __init__(self):
        self.counter = count()
        self.source_nodes = 0
        self.eliminations = 0

    def compile(self, node, local=()):
        """Translate one original derivation under the displayed parameter names."""
        self.source_nodes += 1
        if node.rule == 'hyp':
            return [None]
        if node.rule == 'r':
            return [[]]
        if node.rule == 'qi':
            return self.compile(node.children[0], (node.eigen,) + local) + [[]]
        if node.rule == 'ei':
            return self.compile(node.children[0], (node.eigen,) + local) + [
                [N.coordinates(node.witness, local)]]
        major, minor = node.children
        if node.rule == 'ee':
            return (self.compile(minor, (node.eigen,) + local)
                    + self.compile(major, local)
                    + [[N.coordinates(major.goal, local), None]])
        if node.rule == 'eq':
            motive = N.coordinates(node.motive, (node.hole,) + local)
            return (self.compile(minor, local) + self.compile(major, local)
                    + [[N.coordinates(major.goal, local), motive]])
        if node.rule != 'qe':
            raise N.Invalid('Unknown source rule')

        self.eliminations += 1
        eigen = ('transport', next(self.counter))
        inner = (eigen,) + local
        equality = N.Eq(N.Var(eigen), node.witness)
        existence = N.Ex(eigen, equality)
        # These recursive calls act on smaller SOURCE derivations.  Adding
        # a fresh name to local serializes their parameters in the new scope.
        fixed_slot = (self.compile(minor, inner) + self.compile(major, inner)
                      + [[N.coordinates(major.goal, inner), None]])
        motive = N.coordinates(major.goal.body, (major.goal.variable,) + inner)
        transported = fixed_slot + [None, [N.coordinates(equality, inner), motive]]
        existence_proof = [None, [N.coordinates(node.witness, local)]]
        return transported + existence_proof + [[N.coordinates(existence, local), None]]


def translate_sequent(goal, stack, context=()):
    """Audit utility for a source sequent; the public kernel still starts empty."""
    goal, stack, context = normalize_tags(deepcopy([goal, stack, list(context)]))
    parser = SourceParser()
    expected = parser.formula(goal)
    assumptions = [parser.formula(a) for a in context]
    derivation = parser.parse(expected, stack, assumptions)
    if stack:
        raise N.Invalid('Canonical source stack has an unused prefix')
    compiler = Compiler()
    result = [goal, compiler.compile(derivation)]
    return result, {'source_nodes': compiler.source_nodes,
                    'general_q_eliminations': compiler.eliminations,
                    'target_nodes': len(result[1])}


def translate_document(document):
    goal, stack = document
    return translate_sequent(goal, stack)


if __name__ == '__main__':
    source_path, target_path = map(Path, sys.argv[1:])
    result, statistics = translate_document(json.loads(source_path.read_text()))
    target_path.write_text(json.dumps(result, separators=(',', ':')) + '\n')
    print(json.dumps(statistics, indent=2))
