"""Replay pinned source derivations, the fixed-slot compiler, and both oracles.

This is untrusted audit code, outside the acceptance boundary.  Open source
sequents are tested only through the internal function after validation of
their contexts; the delivered CLI always starts from the empty context.
Run: python3 validation/verify.py [package_root]
"""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import named_reference as N
import transport


HERE = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else (
    HERE.parent if HERE.name == 'validation' else HERE)
spec = importlib.util.spec_from_file_location('fixed_slot_audit_kernel', ROOT / 'checker.py')
K = importlib.util.module_from_spec(spec)
spec.loader.exec_module(K)


def accept(goal, stack, context=()):
    try:
        for assumption in context:
            K.subst(assumption)
        return bool(K.check(deepcopy(goal), deepcopy(stack), deepcopy(list(context))))
    except Exception:
        return False


def main():
    corpus = json.loads((HERE / 'source_sequents.json').read_text())
    if corpus['failures']:
        raise AssertionError('The frozen source extraction recorded a failure')
    example_dir = ROOT / 'examples' / 'transported'
    example_dir.mkdir(parents=True, exist_ok=True)
    results_dir = ROOT / 'results'
    results_dir.mkdir(exist_ok=True)
    rows, closed, compiled = [], [], {}

    for source in corpus['rows']:
        goal, stack, context = source['goal'], source['stack'], source['context']
        target, statistics = transport.translate_sequent(goal, stack, context)
        record = {'id': source['id'], 'origins': source['origins'],
                  'open_context': bool(context), **statistics,
                  'source_oracle': N.accept_sequent(goal, stack, context, fixed_slot=False),
                  'candidate': accept(*target, context),
                  'target_oracle': N.accept_sequent(*target, context),
                  'linear_node_count': statistics['target_nodes'] ==
                      statistics['source_nodes'] + 5 * statistics['general_q_eliminations']}
        if not all(record[k] for k in ('source_oracle', 'candidate', 'target_oracle',
                                      'linear_node_count')):
            raise AssertionError(record)
        compiled[source['id']] = target
        if not context:
            original_name = Path(source['origins'][0].split('#')[0]).stem
            name = source['id'][:3] + '_' + original_name + '.json'
            path = example_dir / name
            path.write_text(json.dumps(target, separators=(',', ':')) + '\n')
            closed.append(path)
            record['target_file'] = str(path.relative_to(ROOT))
        rows.append(record)

    # The eight richest Q-elimination examples are serialized beneath three
    # extra parameters.  This tests the strengthened source-height invariant
    # at a different initial scope, including nested recursive witnesses.
    richest = sorted(corpus['rows'], key=lambda r: (
        r['general_q_eliminations'], r['source_nodes']), reverse=True)[:8]
    scope_rows, dummy_rows = [], []
    for source in richest:
        parser = transport.SourceParser()
        goal = parser.formula(source['goal'])
        context = [parser.formula(a) for a in source['context']]
        stack = deepcopy(source['stack'])
        derivation = parser.parse(goal, stack, context)
        if stack:
            raise AssertionError('Canonical parser did not exhaust its source')
        local = (('audit', 0), ('audit', 1), ('audit', 2))
        target_goal = N.coordinates(goal, local)
        target_context = [N.coordinates(a, local) for a in context]
        target_stack = transport.Compiler().compile(derivation, local)
        ok = accept(target_goal, target_stack, target_context)
        named = N.accept_sequent(target_goal, target_stack, target_context)
        if not (ok and named):
            raise AssertionError(('Extra-scope translation', source['id']))
        scope_rows.append({'id': source['id'], 'extra_parameters': 3,
                           'candidate': ok, 'named': named})

        target = deepcopy(compiled[source['id']])
        replacements = 0
        for instruction in target[1]:
            if (type(instruction) is list and len(instruction) == 2
                    and type(instruction[0]) is list and instruction[0]
                    and instruction[0][0] == 'q'):
                instruction[1] = {'unused': ['not', 'a', 'term'], 'flag': True}
                replacements += 1
        if not replacements:
            raise AssertionError('No fixed-slot instruction in a selected example')
        ok = accept(*target, source['context'])
        named = N.accept_sequent(*target, source['context'])
        if not (ok and named):
            raise AssertionError(('Fixed-slot dummy field', source['id']))
        dummy_rows.append({'id': source['id'], 'ignored_fields': replacements,
                           'candidate': ok, 'named': named})

    # Existence still validates its term even when the matrix is vacuous.
    computation = ['=', ['r', 0, 0, 1], 0]
    invalid_terms = [None, True, False, 0.0, 1.5, 'x', {}, [], ['s'],
                     ['s', 0, 0], ['s', True], ['r', 0, 0, ['bad']],
                     ['q', ['=', 0, 0]]]
    negatives = [[['ex', computation], [[], [term]]] for term in invalid_terms]
    negatives += [None, {}, [], [computation], [computation, [[]], []],
                  ['invalid', []],
                  [['=', 0, ['s', 0]], [[]]],
                  [['=', ['r', ['s', 0], 0, ['s', 1]], 0], [[]]],
                  [['=', ['r', 0, 0, ['bad']], 0], [[]]],
                  [['=', 1, 0], [None, None, [0], [['ex', ['=', 1, 0]], None]]]]
    for document in negatives:
        if N.accept_document(document):
            raise AssertionError(('Negative oracle accepted', document))
        if isinstance(document, list) and len(document) == 2 and accept(*document):
            raise AssertionError(('Negative kernel accepted', document))

    cli_rows = []
    with tempfile.TemporaryDirectory() as directory:
        for index, (path, expected) in enumerate([(p, True) for p in closed]
                                                + [(None, False) for _ in negatives]):
            if path is None:
                path = Path(directory) / f'negative_{index}.json'
                path.write_text(json.dumps(negatives[index - len(closed)]) + '\n')
            process = subprocess.run([sys.executable, str(ROOT / 'checker.py'), str(path)],
                                     capture_output=True, text=True)
            correct = ((process.returncode == 0 and process.stdout.strip() == 'ACCEPT')
                       if expected else
                       (process.returncode != 0 and process.stdout.strip() == 'REJECT'))
            if not correct or process.stderr:
                raise AssertionError(('CLI mismatch', str(path), expected,
                                      process.returncode, process.stdout, process.stderr))
            cli_rows.append({'case': index, 'expected': expected, 'passed': True})

    result = {'source_files': corpus['source_file_count'],
              'source_sequents_before_deduplication': corpus['source_sequent_count'],
              'unique_source_derivations': len(rows),
              'closed_derivations': len(closed),
              'open_derivations_with_validated_contexts': len(rows) - len(closed),
              'extra_scope_translations': len(scope_rows),
              'fixed_slot_dummy_variants': len(dummy_rows),
              'negative_public_documents': len(negatives),
              'cli_cases': len(cli_rows),
              'failures': [], 'corpus': rows, 'scope_checks': scope_rows,
              'dummy_checks': dummy_rows, 'cli_checks': cli_rows}
    (results_dir / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in (
        'corpus', 'scope_checks', 'dummy_checks', 'cli_checks')}, indent=2))


if __name__ == '__main__':
    main()
