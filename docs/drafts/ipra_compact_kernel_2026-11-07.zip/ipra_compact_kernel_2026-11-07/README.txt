A SMALLER CHECKED PRESENTATION OF INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 7 November 2026
==========================================================================

START HERE

report.pdf is the complete 31-page paper. report.tex, sections/, appendices/,
and results/*.tex are the editable LaTeX source.

RESULT

The six current draft ZIPs at ProveIt commit
fa69b78013baadf9a4e9d63ef1a57f56ca1eb017 contain eleven complete root checkers.
The measurements are:

                                      tokens   AST nodes   normalized bytes
Current delivered coordinate minima      342        364                978
Current minima with identical stdin      341        362                970
checker.py (exact scalar refinement)      330        360                967
checker_retained.py (smaller companion)   328        360                965

Both delivered programs use the common stdin driver, so their delivered and
controlled measurements agree. The unchanged inherited metric strips genuine
docstrings, normalizes the complete source using ast.unparse, and counts the
whole program, including imports and the acceptance/rejection driver. Exact
counts are recorded for CPython 3.12.14. Raw sizes and hashes are separate.

The result is a modest complete-implementation reduction. It is not a new
arithmetic axiom basis, a foundational breakthrough, or a global minimality
theorem. The two computation schemas and five logical inference patterns are
inherited and fully stated. Their whole-domain bi-interpretation with iPRA,
including both internal identity composites, is proved in the paper.

CHOOSE A PROFILE

checker.py is the main 330-token profile. For the same parsed JSON packet,
its idealized acceptance agrees with the supplied scalar sort-erasure checker.

checker_retained.py is the smallest delivered profile. In-range numeric
formula labels keep their spelling but still mean truth; exposed numeric
formula labels erase to zero, and nonnumeric formula leaves reject. It has
the same decoded native theorems and identical canonical executions, but
arbitrary malformed or redundant packets need not have the same verdict.

Both use scalar iteration. Their two update slots denote the SAME preceding
state. They do not provide the preceding counter as a separate variable.
The paper includes the internal predecessor, reflection, pairing, and general
recursion compiler needed to establish full iPRA strength.

RUN

  python3 checker.py < examples/zero_computation.json
  python3 checker_retained.py < examples/zero_computation.json
  python3 reproduce.py
  python3 build.py

Python 3.10+ supports the checking syntax. Exact source measurements were
made with CPython 3.12.14. Building the PDF needs local pdfLaTeX and the
packages declared in report.tex. All reproduction is offline; no package
downloads, external service, trusted proof producer, or project-specific
runtime dependency is required by either checker.

VALIDATION

For EACH profile: 147 canonical positive certificates, 12 targeted packets,
792 targeted opening comparisons, and 6 actual CLI runs under normal and
optimized Python passed against an independently organized named-rule oracle.

The exact profile also passed 11,911 deterministic differential comparisons
against the unchanged scalar sort-erasure baseline, comparing acceptance,
final fresh-name floor, and remaining packet cells. These are finite tests,
not a proof-assistant formalization of the universal metatheorems.

reproduce.py regenerates the measurements and receipts and verifies that
their source hashes match the delivered files. SHA256SUMS.txt records package
integrity. The complete frozen comparison sources and their provenance and
licenses are included under comparison/.

CONTENTS

  report.tex / report.pdf       Full paper and compiled PDF
  sections/                    Explicit basis, logic, interpretations, decoding,
                               soundness, comparison, and obstruction results
  appendices/                  Internal scalar predecessor, reflection, pairing
  checker.py                   Complete exact-refinement acceptance program
  checker_retained.py          Complete smaller conservative profile
  FORMAT.txt                   Packet format and scope conventions
  examples/                    Small positive and negative packets
  validation/                  Independent oracle, fixtures, and validation code
  comparison/                  Eleven unchanged current checkers, normalizer,
                               source manifests, licenses, and comparison code
  results/                     Reproducible metrics and validation receipts
  github_snapshot.json         Exact current GitHub archive metadata
  ATTRIBUTION.txt               New/inherited contribution boundaries
  reproduce.py / build.py       Offline reproduction and PDF build
  package.py / SHA256SUMS.txt   Repacking and package integrity

No changes have been pushed to the GitHub repository.
