"""Deterministic finite comparison against the unchanged scalar predecessor.

This checks only the exact profile. It is not a soundness proof and makes
no raw-packet equivalence claim for the retained-label companion.
"""
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent.parent


def definitions(path):
    tree = ast.parse(path.read_text())
    if not isinstance(tree.body[-1], ast.Try):
        raise ValueError('Expected complete explicit driver')
    tree.body = tree.body[:-1]
    namespace = {}
    exec(compile(tree, str(path), 'exec'), namespace)
    return namespace


def run(namespace, packet):
    namespace['k'] = 0
    stack = deepcopy(packet)
    try:
        namespace['take'] = stack.pop
        answer = bool(namespace['check'](stack.pop(), []))
    except Exception:
        answer = False
    return answer, namespace['k'], len(stack) if type(stack) is list else None


def main():
    manifest = json.loads((ROOT/'comparison/manifest.json').read_text())
    entry = next(e for e in manifest['programs']
                 if 'sort_erasure' in e['archive'] and e['member'].endswith('/checker_scalar.py'))
    baseline_path = ROOT/'comparison'/entry['local_file']
    candidate_path = ROOT/'checker.py'
    baseline, candidate = definitions(baseline_path), definitions(candidate_path)
    records = json.loads((ROOT/'validation/validation_sources/positive_certificates.json').read_text())['records']
    packets = [r['packet'] for r in records]
    generator = random.Random(20261107)
    leaves = [-3, -2, -1, 0, 1, 2, 3, 4, True, False, None, '', 'a', {}, .5, -1.5]

    def tree(depth=3):
        if not depth or generator.randrange(3) == 0:
            return deepcopy(generator.choice(leaves))
        return [tree(depth-1) for _ in range(generator.randrange(6))]

    for _ in range(10000):
        packets.append([tree(2) for _ in range(generator.randrange(9))])
    for packet in packets[:len(records)]:
        for _ in range(12):
            mutated = deepcopy(packet)
            if mutated:
                mutated[generator.randrange(len(mutated))] = tree(3)
            packets.append(mutated)
    accepted = 0
    for number, packet in enumerate(packets):
        before, after = run(baseline, packet), run(candidate, packet)
        if before != after:
            raise AssertionError((number, before, after, packet))
        accepted += before[0]
    receipt = {
        'status': 'PASS', 'packet_comparisons': len(packets),
        'accepted_packets': accepted, 'canonical_fixture_count': len(records),
        'seed': 20261107,
        'baseline_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
        'candidate_sha256': hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
        'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'compared': ['acceptance', 'final_parameter_floor', 'remaining_packet_cells'],
    }
    (ROOT/'results/differential.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
