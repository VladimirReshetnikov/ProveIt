"""Reproduce exact current-corpus metrics; optionally compare new complete files.

Usage: python3 measure.py [candidate.py ...]
No network, nonstandard modules, execution of checkers, or source rewriting.
"""
import ast
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys
import tempfile
import source_measure as metric

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes', 'source_tokens', 'raw_bytes', 'raw_ast_nodes')
COMMON_DRIVER = '''try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''


def complete_metrics(path):
    result = metric.metrics(path)
    result.pop('core')
    result['raw_ast_nodes'] = sum(1 for _ in ast.walk(ast.parse(path.read_text())))
    return result


def uniform_driver(path):
    tree = ast.parse(path.read_text())
    if not isinstance(tree.body[-1], ast.Try):
        raise ValueError('Expected explicit final acceptance boundary')
    tree.body[-1:] = ast.parse(COMMON_DRIVER).body
    with tempfile.TemporaryDirectory() as tmp:
        probe = Path(tmp) / 'checker.py'
        probe.write_text(ast.unparse(tree) + '\n')
        return complete_metrics(probe)


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    if hashlib.sha256((ROOT / 'source_measure.py').read_bytes()).hexdigest() != manifest['normalizer_sha256']:
        raise ValueError('Supplied normalizer changed')
    programs = []
    for item in manifest['programs']:
        path = ROOT / item['local_file']
        result = complete_metrics(path)
        if result['sha256'] != item['sha256']:
            raise ValueError('Frozen comparator changed: ' + str(path))
        programs.append({**item, 'delivered':result, 'common_stdin':uniform_driver(path)})
    candidates = []
    for name in sys.argv[1:]:
        path = Path(name).resolve()
        candidates.append({'file':str(path),'delivered':complete_metrics(path),
                           'common_stdin':uniform_driver(path)})
    minima = {mode:{field:min(row[mode][field] for row in programs) for field in FIELDS}
              for mode in ('delivered','common_stdin')}
    result = {'python':platform.python_version(), 'implementation':platform.python_implementation(),
              'commit':manifest['commit'], 'normalizer_sha256':manifest['normalizer_sha256'],
              'archive_count':len(manifest['archives']), 'program_count':len(programs),
              'coordinate_minima':minima, 'programs':programs, 'candidates':candidates}
    (ROOT / 'measurements.json').write_text(json.dumps(result,indent=2) + '\n')
    with (ROOT / 'measurements.csv').open('w',newline='') as stream:
        writer = csv.DictWriter(stream,['archive','member','mode',*FIELDS,'sha256'])
        writer.writeheader()
        for row in programs:
            for mode in minima:
                writer.writerow({'archive':row['archive'],'member':row['member'],'mode':mode,
                                 **{key:row[mode][key] for key in (*FIELDS,'sha256')}})
    print(json.dumps({'coordinate_minima':minima,'candidates':candidates},indent=2))


if __name__ == '__main__':
    main()
