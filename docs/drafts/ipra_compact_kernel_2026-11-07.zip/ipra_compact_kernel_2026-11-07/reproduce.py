"""Reproduce the complete measurements and the focused validation offline."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*arguments):
    result = subprocess.run([sys.executable, *map(str, arguments)], cwd=ROOT,
                            capture_output=True, text=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)


def main():
    run(ROOT/'comparison/measure.py', ROOT/'checker.py', ROOT/'checker_retained.py')
    run(ROOT/'validation/validate_profiles.py', ROOT/'checker.py', ROOT/'checker_retained.py')
    run(ROOT/'validation/differential.py')
    measurements = json.loads((ROOT/'comparison/measurements.json').read_text())
    validation = json.loads((ROOT/'validation/star_profile_results.json').read_text())
    for index, (label, filename) in enumerate((('Exact','checker.py'),('Retained','checker_retained.py'))):
        source_hash = hashlib.sha256((ROOT/filename).read_bytes()).hexdigest()
        candidate = measurements['candidates'][index]
        if candidate['delivered']['sha256'] != source_hash or validation['profiles'][index]['sha256'] != source_hash:
            raise ValueError('Receipt/source mismatch: '+filename)
        for mode in ('delivered','common_stdin'):
            for field in ('normalized_tokens','ast_nodes','normalized_bytes'):
                if candidate[mode][field] >= measurements['coordinate_minima'][mode][field]:
                    raise ValueError('Strict comparison failed: '+filename+' '+mode+' '+field)
    lines = []
    for label, candidate in zip(('Exact','Retained'),measurements['candidates']):
        for name, key in (('Tokens','normalized_tokens'),('AST','ast_nodes'),('Bytes','normalized_bytes')):
            lines.append('\\newcommand{\\'+label+name+'}{'+str(candidate['delivered'][key])+'}')
    (ROOT/'results/numbers.tex').write_text('\n'.join(lines)+'\n')
    rows = ['\\begin{center}\\small', '\\begin{tabular}{@{}llrr@{}}',
            '\\toprule', 'Archive family & Variant & Delivered T/A/B & Same driver T/A/B\\\\', '\\midrule']
    for row in measurements['programs']:
        family = row['archive'].removesuffix('_2026-11-07.zip').removeprefix('ipra_').replace('_','\\_')
        variant = Path(row['member']).name.replace('_','\\_')
        values = [' / '.join(str(row[mode][key]) for key in ('normalized_tokens','ast_nodes','normalized_bytes'))
                  for mode in ('delivered','common_stdin')]
        rows.append(f'{family} & \\texttt{{{variant}}} & {values[0]} & {values[1]}\\\\')
    rows += ['\\bottomrule', '\\end{tabular}', '\\end{center}']
    (ROOT/'results/current_table.tex').write_text('\n'.join(rows)+'\n')
    shutil.copy2(ROOT/'comparison/measurements.json', ROOT/'results/measurements.json')
    shutil.copy2(ROOT/'comparison/measurements.csv', ROOT/'results/measurements.csv')
    shutil.copy2(ROOT/'validation/star_profile_results.json', ROOT/'results/validation.json')
    receipt = {'status':'PASS','python':sys.version.split()[0],
               'candidate_metrics':[r['delivered'] for r in measurements['candidates']],
               'minima':measurements['coordinate_minima'],
               'validation_counts':[r['counts'] for r in validation['profiles']],
               'differential':json.loads((ROOT/'results/differential.json').read_text())}
    (ROOT/'results/reproduction.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()
