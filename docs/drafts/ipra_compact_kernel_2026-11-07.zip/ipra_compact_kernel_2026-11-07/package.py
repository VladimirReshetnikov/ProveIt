"""Write a deterministic ZIP and SHA-256 manifest from the final deliverables."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc'}


def files():
    return sorted(p for p in ROOT.rglob('*')
                  if p.is_file() and p.suffix not in SKIP_SUFFIXES
                  and '__pycache__' not in p.parts and p.name != 'SHA256SUMS.txt')


manifest = ROOT/'SHA256SUMS.txt'
manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+
                            p.relative_to(ROOT).as_posix()+'\n' for p in files()))
destination = ROOT.parent/(ROOT.name+'.zip')
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted([*files(), manifest]):
        name = ROOT.name+'/'+path.relative_to(ROOT).as_posix()
        info = zipfile.ZipInfo(name, (2026,11,7,12,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
print(destination)
