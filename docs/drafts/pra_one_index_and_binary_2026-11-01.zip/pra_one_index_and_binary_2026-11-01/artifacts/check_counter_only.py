#!/usr/bin/env python3
"""Fresh standalone diagnostics for the counter-only inline C/D variant.

Grammar: R_h(0,a,b)=a; R_h(Sn,a,b)=h(n,b,R_h(a,n,b)).
The update receives n, frozen b and v, but NOT mutable seed a.
This is distinct from check_inline.py's seed-only counter-free grammar.
No other local or inherited archive script is executed or imported.
Python 3.9+; all checks stay active under -O; output is deterministic.
These finite tests and specified rewrites are not a formal theory proof.
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path

CHECKS=0

def require(c,detail='check failed'):
    global CHECKS
    CHECKS+=1
    if not c:raise AssertionError(detail)

@dataclass(frozen=True)
class Tree:
    kind:str
    label:str
    children:tuple['Tree',...]=()
    def count(self):return 1+sum(c.count() for c in self.children)
    def show(self):
        if not self.children:return self.label
        return self.label+'('+','.join(c.show() for c in self.children)+')'
    def data(self):
        r={'kind':self.kind,'label':self.label}
        if self.children:r['children']=[c.data() for c in self.children]
        return r

def var(s):return Tree('variable',s)
def app(s,*cs):return Tree('application',s,cs)
def eq(x,y):return Tree('equality','=',(x,y))
def impl(x,y):return Tree('connective','implies',(x,y))
def either(x,y):return Tree('connective','or',(x,y))
def all_(v,t):return Tree('quantifier',v.label,(t,))
def close(vs,t):
    for v in reversed(vs):t=all_(v,t)
    return t
ZERO=Tree('constant','0')
BOTTOM=Tree('falsity','bottom')
def S(x):return app('S',x)
ONE=S(ZERO)

def Kterm(x,a):return app('C',app('D',a,x),x,a)
def Eterm(x,y):return app('D',y,Kterm(x,S(y)))

def trees(m):
    n,a=var('n'),var('a')
    bs=tuple(var('b'+str(i)) for i in range(1,m));ps=(a,)+bs
    fn,f0,fs=(app('f',x,*ps) for x in (n,ZERO,S(n)))
    return {
      'D_base':close(ps,eq(app('R',ZERO,*ps),a)),
      'D_step':close((n,)+ps,eq(app('R',S(n),*ps),app('h',n,*bs,app('R',a,n,*bs)))),
      'IP':close(ps,impl(all_(n,eq(fs,fn)),all_(n,either(eq(Kterm(f0,a),a),eq(S(fn),a))))),
      'Sep':impl(eq(ZERO,ONE),BOTTOM)}

def metrics():
    rows=[]
    for m in range(1,13):
        cs={k:t.count() for k,t in trees(m).items()}
        require(cs=={'D_base':4+2*m,'D_step':8+4*m,'IP':25+6*m,'Sep':6},(m,cs))
        display=sum(cs.values());require(display==43+12*m,(m,cs))
        rows.append({'m':m,**cs,'display':display,'bodies':2,'subtotal':display+2,
            'delta_vs_best_counterful_subtotal':m-2})
    # It matters WHICH active input was removed, even though counts coincide.
    m1step=trees(1)['D_step'].children[0].children[0]
    require(m1step.children[1].children[0]==var('n'),'update must receive counter n')
    return {'grammar':'R(0,a,b)=a; R(Sn,a,b)=h(n,b,R(a,n,b)); h has no free mutable seed a',
      'counting_convention':'One node per variable occurrence, constant, application, equality, connective, bottom, individual quantifier. Binder names are metadata. No term sharing. K and 1 are expanded. The two computation equations are separate.',
      'arities':rows,'selected_bodies':{'C':{'text':'b','nodes':1},'D':{'text':'v','nodes':1}},
      'explicit_trees':{str(m):{k:{'text':t.show(),'nodes':t.count(),'tree':t.data()} for k,t in trees(m).items()} for m in (1,2,3)},
      'comparison':'Same 43+12m display and 45+12m subtotal as seed-only inline, but a different update grammar. Against 47+11m counterful subtotal, better only at m=1, equal m=2, worse m>=3.',
      'scope':'Partial syntax counts, not an absolute description-length optimum.'}


def direct(h):
    @lru_cache(None)
    def r(x,a,bs=()):
        require(x>=0 and a>=0,(x,a))
        return a if x==0 else h(x-1,bs,r(a,x-1,bs))
    return r
C=direct(lambda n,b,v:b[0])
D=direct(lambda n,b,v:v)
ADD=direct(lambda n,b,v:v+1)
def p(x):return D(x,0)
def K(x,a):return C(D(a,x),x,(a,))
def E(x,y):return D(y,K(x,y+1))
def eqbit(x,y):return C(E(x,y),1,(0,))
def J(z,u,v):return C(E(z,0),u,(v,))
def Q(x,y,u,v):return C(eqbit(x,y),v,(u,))
def delta(n):return ADD(n,n)
DECODER=direct(lambda n,b,v:Q(n+1,delta(v+1),v+1,v))
def L(t):return DECODER(t,t)


def arithmetic(bound=32):
    for x,y in itertools.product(range(bound+1),repeat=2):
        require(D(x,y)==max(y-x,0)+max(x-y-1,0),('D',x,y))
        require(K(x,y)==(x if y==x+1 else y),('K',x,y))
        require(K(x,y)==y or x+1==y,('off',x,y))
        require(E(x,y)==int(x!=y),('E',x,y))
        require(eqbit(x,y)==int(x==y),('eqbit',x,y))
        require(ADD(x,y)==x+y,('ADD',x,y))
    for n in range(bound+1):
        require(p(n+1)==n)
        require(D(n,n)==0 and D(n,n+1)==1)
        require(K(n,n+1)==n)
        require(delta(n)==2*n and delta(n+1)==delta(n)+2)
        require(L(delta(n))==n and L(delta(n)+1)==n,('tag-inverses',n))
        for u,v in itertools.product(range(4),repeat=2):
            require(J(n,u,v)==(u if n==0 else v),('J',n,u,v))
    require(L(1)==0 and L(2)==1)
    bad=direct(lambda n,b,v:Q(n,delta(v+1),v+1,v))
    require(bad(2,2)!=1,'missing successor in decoder must fail')
    return {'bound':bound,'arithmetic_pairs':(bound+1)**2,'tag_inverse_pairs':bound+1,
      'decoder':'u(n,v)=Q(Sn,delta(Sv),Sv,v); L(t)=R_u(t,t)',
      'negative_control':{'mutation':'replace Sn by n in decoder comparison','detected':True,
        'expected_L2':1,'mutated_L2':bad(2,2)}}


def reverse(h,omit_inner=False):
    def r(x,y,bs=()):
        d,e=max(x-y,0),max(y-x,0)
        value=e if d==0 else h(max(d-1,0),bs,max(d-1,0))
        for j in range(min(x,y)):
            inner=value if omit_inner else h(e+j,bs,value)
            value=h(d+j,bs,inner)
        return value
    return r

def reverse_tests(bound=20):
    cases=[('previous',lambda n,b,v:v,[()]),('counter',lambda n,b,v:n,[()]),
      ('increment',lambda n,b,v:v+1,[()]),('nonlinear',lambda n,b,v:n*n+v,[()]),
      ('one_frozen',lambda n,b,v:(b[0]+1)*v+n,[(0,),(1,),(4,)]),
      ('two_frozen',lambda n,b,v:(b[0]+1)*v+n+b[1],[(0,0),(1,2),(3,1)])]
    rows=[]
    for name,h,tuples in cases:
        rd,rc=direct(h),reverse(h);comparisons=equations=0
        for bs in tuples:
            for x,y in itertools.product(range(bound+1),repeat=2):
                require(rd(x,y,bs)==rc(x,y,bs),(name,x,y,bs))
                require(rc(0,y,bs)==y)
                require(rc(x+1,y,bs)==h(x,bs,rc(y,x,bs)))
                require(rc(x+1,0,bs)==h(x,bs,x))
                require(rc(x+1,y+1,bs)==h(x,bs,h(y,bs,rc(x,y,bs))))
                comparisons+=1;equations+=4
        rows.append({'update':name,'frozen_tuples':tuples,'comparisons':comparisons,'equations':equations})
    h=lambda n,b,v:v+1;good,bad=direct(h),reverse(h,omit_inner=True)
    require(good(1,1)!=bad(1,1))
    return {'bound':bound,'examples':rows,'comparisons':sum(r['comparisons'] for r in rows),
      'equations':sum(r['equations'] for r in rows),
      'V_base':'e if d=0; h(p(d),b,p(d)) otherwise',
      'V_step':'h(d+j,b,h(e+j,b,V(j,d,e,b)))',
      'negative_control':{'mutation':'omit inner update','detected':True,'at':[1,1],
        'correct':good(1,1),'mutated':bad(1,1)}}


def latch_tests(length=10):
    values=stationarity=0
    for bits in itertools.product((0,1),repeat=length):
        h=lambda n,b,v:C(bits[n],1,(v,));r=direct(h)
        ts=[r(n+1,n+1) for n in range(length)]
        require(ts[0]==1-bits[0],('base',bits))
        for n in range(length):
            require(ts[n]==int(0 in bits[:n+1]),('latch',bits,n))
            require(h(n,(),h(n,(),r(n,n)))==ts[n],('double',bits,n))
            require(h(n,(),1)==1)
            if not bits[n]:require(ts[n]==1)
            values+=1
        for n in range(length-1):
            require(ts[n+1]==h(n+1,(),h(n+1,(),ts[n])),('recurrence',bits,n))
            if not bits[n] or bits[n+1]:
                require(ts[n+1]==ts[n],('progress',bits,n))
                stationarity+=1
    # Replacing the new h_n^2 with seed-only h_(n+1)h_n is wrong.
    bits=(1,0,1);h=lambda n,b,v:C(bits[n],1,(v,));r=direct(h)
    wrong=h(1,(),h(0,(),r(0,0)))
    require(wrong!=r(1,1))
    return {'length':length,'all_bit_tables':2**length,'latch_values':values,
      'local_progress_stationarity_checks':stationarity,
      'latch':'h_n(v)=C(b(n),1,v); t(n)=R(Sn,Sn)',
      'literal_diagonal':'R(Sn,Sn)=h_n(h_n(R(n,n)))',
      'finite_characterization':'t(n)=1 iff some b(k)=0 for 0<=k<=n',
      'negative_control':{'mutation':'substitute seed-only mixed diagonal h_(n+1) h_n','detected':True,
        'bits':bits,'actual_R11':r(1,1),'mutated_R11':wrong}}


def tagged_tests():
    specs=[('identity',lambda b:0,lambda n,b,v:v+1,[()],10),
      ('factorial',lambda b:1,lambda n,b,v:(n+1)*v,[()],4),
      ('triangular',lambda b:0,lambda n,b,v:v+n+1,[()],8),
      ('affine',lambda b:b[0],lambda n,b,v:v+b[1],[(0,0),(2,3)],8),
      ('time_parameter',lambda b:b[0]+b[1],lambda n,b,v:v+b[0]*n+b[1],[(0,2),(1,3)],6),
      ('bounded_nonlinear',lambda b:b[0],lambda n,b,v:(v*v+n+b[0])%17,[(1,),(3,)],10)]
    rows=[]
    for name,g,H,tuples,bound in specs:
        def phase(n,bs,z):return J(n,g(bs),H(p(n),bs,z))
        def update(n,bs,v):return Q(v,delta(L(v)),v+1,delta(phase(n,bs,L(v))))
        r=direct(update)
        def Z(n,bs):return r(n,n,bs)
        def F(n,bs):return L(Z(n+1,bs))
        values=transitions=steps=0
        for bs in tuples:
            for n,z in itertools.product(range(7),range(11)):
                require(update(n,bs,delta(z))==delta(z)+1,('pass',name,n,z,bs))
                require(update(n,bs,delta(z)+1)==delta(phase(n,bs,z)),('compute',name,n,z,bs))
                require(update(n,bs,update(n,bs,delta(z)))==delta(phase(n,bs,z)),
                    ('two-step',name,n,z,bs))
                transitions+=3
            require(Z(1,bs)==delta(g(bs)))
            require(F(0,bs)==g(bs))
            expected=g(bs)
            for n in range(bound+1):
                require(F(n,bs)==expected,('F',name,n,bs))
                require(Z(n+1,bs)==delta(F(n,bs)),('invariant',name,n,bs))
                values+=1
                if n<bound:
                    require(F(n+1,bs)==H(n,bs,F(n,bs)),('PRstep',name,n,bs))
                    expected=H(n,bs,expected);steps+=1
        rows.append({'recursion':name,'frozen_tuples':tuples,'bound':bound,
            'F_values':values,'tag_transition_checks':transitions,'ordinary_steps':steps})
    # A seed-only shifted initializer is wrong for this grammar.
    def bad_update(n,bs,v):
        wrong_phase=J(p(n),0,L(v)+1)
        return Q(v,delta(L(v)),v+1,delta(wrong_phase))
    bad=direct(bad_update)
    wrong=L(bad(2,2))
    require(wrong!=1)
    return {'examples':rows,'F_values':sum(r['F_values'] for r in rows),
      'tag_transitions':sum(r['tag_transition_checks'] for r in rows),
      'phase':'B(n,b,z)=J(n,G(b),H(p(n),b,z))',
      'update':'h(n,b,v)=Q(v,delta(L(v)),Sv,delta(B(n,b,L(v))))',
      'output':'Z(n,b)=R_h(n,n,b); F(n,b)=L(Z(Sn,b))',
      'implementation':'delta,L,p,Q,J and equality use their counter-only descriptions and inline C/D terms, not arithmetic shortcuts. Ordinary recurrences are independent finite test oracles.',
      'negative_control':{'mutation':'use seed-only shifted zero test J(p(n),...)','detected':True,
        'expected_identity_F1':1,'mutated_identity_F1':wrong}}


def rewrite_once(t):
    if t.kind!='application':return t
    cs=t.children
    if t.label=='C':
        z,a,b=cs
        if z==ZERO:return a
        if z.label=='S' and z.kind=='application':return b
    if t.label=='D':
        z,a=cs
        if z==ZERO:return a
        if z.label=='S' and z.kind=='application':return app('D',a,z.children[0])
    if t.label=='R':
        z,a,*bs=cs
        if z==ZERO:return a
        if z.label=='S' and z.kind=='application':
            n=z.children[0]
            return app('h',n,*bs,app('R',a,n,*bs))
    return t

def norm(t,hyp=()):
    for _ in range(200):
        replacement=next((r for l,r in hyp if t==l),None)
        if replacement is not None:t=replacement;continue
        nxt=rewrite_once(Tree(t.kind,t.label,tuple(norm(c,hyp) for c in t.children)))
        if nxt==t:return t
        t=nxt
    raise AssertionError('rewrite bound exceeded')

def symbolic():
    x,y,b=map(var,('x','y','b'));d=app('D',x,x)
    cases=[('p0',app('D',ZERO,ZERO),ZERO,()),('pS',app('D',S(x),ZERO),x,()),
      ('K01',Kterm(ZERO,ONE),ZERO,()),('K12',Kterm(ONE,S(ONE)),ONE,()),
      ('D-diagonal',app('D',S(x),S(x)),d,()),
      ('D-next-diagonal',app('D',S(x),S(S(x))),app('D',x,S(x)),()),
      ('K-diagonal',Kterm(x,S(x)),x,((d,ZERO),)),
      ('E-diagonal',Eterm(x,x),ZERO,((d,ZERO),)),
      ('counter-only-axis',app('R',S(x),ZERO,b),app('h',x,b,x),()),
      ('counter-only-joint',app('R',S(x),S(y),b),app('h',x,b,app('h',y,b,app('R',x,y,b))),()),
      ('counter-only-diagonal',app('R',S(x),S(x),b),app('h',x,b,app('h',x,b,app('R',x,x,b))),())]
    rows=[]
    for name,l,r,hyp in cases:
        ln,rn=norm(l,hyp),norm(r,hyp)
        require(ln==rn,(name,ln.show(),rn.show()))
        rows.append({'identity':name,'lhs':l.show(),'rhs':r.show(),
            'explicit_lemma_assumptions':[eq(a,b).show() for a,b in hyp],'normal_form':ln.show()})
    return {'checks':rows,'scope':'Computation rewriting only. Non-computation diagonal lemmas are assumptions, not hidden derived rewrites.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('results_counter_only.json'))
    args=parser.parse_args()
    result={'status':'DIAGNOSTICS_PASS','scope':'Exact ASTs, specified computation rewrites and finite standard-N diagnostics only. Not formal verification of axiom schemas, QFI, nonstandard uniqueness, or bi-interpretations.',
      'metrics':metrics(),'symbolic':symbolic(),'arithmetic_and_tags':arithmetic(),
      'reverse_compiler':reverse_tests(),'direct_latch':latch_tests(),'tagged_ordinary_compiler':tagged_tests(),
      'reproducibility':{'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'python':'Python 3.9+ standard library only','randomness':False,
        'other_local_scripts_imported':False,'inherited_scripts_executed':False,'assert_statements':False}}
    result['active_checks']=CHECKS
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'active_checks':CHECKS,'display':55,'selected_bodies':2,'subtotal':57,
      'reverse_comparisons':result['reverse_compiler']['comparisons'],
      'latch_values':result['direct_latch']['latch_values'],
      'tagged_F_values':result['tagged_ordinary_compiler']['F_values'],
      'tagged_transitions':result['tagged_ordinary_compiler']['tag_transitions'],
      'negative_controls_detected':4,'output':str(args.output)},sort_keys=True))

if __name__=='__main__':main()
