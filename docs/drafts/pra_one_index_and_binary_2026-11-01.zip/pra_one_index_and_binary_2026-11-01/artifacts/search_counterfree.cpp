#include <algorithm>
#include <chrono>
#include <iostream>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std;
struct T { string val, text; };
int main(int argc,char**argv){
 int N=argc>1?stoi(argv[1]):9;
 vector<pair<int,int>> grid;
 for(int a=0;a<=5;a++)for(int v=0;v<=9;v++)grid.push_back({a,v});
 size_t L=grid.size(); vector<vector<T>> ts(N+1); unordered_set<string> seen;
 size_t attempts=0,candidates=0;
 auto accept=[&](int s,string val,string txt){
  attempts++;
  if(!seen.insert(val).second)return;
  bool ok=true;
  for(size_t i=0;i<L;i++) {auto [a,v]=grid[i]; if((a==0||(a!=v&&a!=v+1)) && (unsigned char)val[i]!=a){ok=false;break;}}
  if(ok){int q=(unsigned char)val[10];ok=q!=1&&q<=9&&(unsigned char)val[10+q]==1;}
  if(ok){candidates++;cout<<"CANDIDATE "<<s<<" "<<txt<<" h10="<<int((unsigned char)val[10])<<endl;}
  ts[s].push_back({move(val),move(txt)});
 };
 string z(L,0),a,v;for(auto av:grid){a.push_back(av.first);v.push_back(av.second);}accept(1,z,"0");accept(1,a,"a");accept(1,v,"v");
 for(int s=2;s<=N;s++){
  for(auto &x:ts[s-1]){string w=x.val;for(auto &c:w)c++;accept(s,move(w),"S("+x.text+")");}
  for(int i=1;i<s-1;i++){int j=s-1-i;for(auto& x:ts[i])for(auto& y:ts[j]){string w(L,0);for(size_t k=0;k<L;k++){int d=(unsigned char)x.val[k]-(unsigned char)y.val[k];w[k]=d>0?d-1:-d;}accept(s,move(w),"D("+x.text+","+y.text+")");}}
  for(int i=1;i<s-2;i++)for(int j=1;j<s-1-i;j++){int k=s-1-i-j;if(k<1)continue;for(auto&x:ts[i]){
   bool az=all_of(x.val.begin(),x.val.end(),[](char c){return !c;});bool nz=none_of(x.val.begin(),x.val.end(),[](char c){return !c;});if(az||nz)continue;
   for(auto&y:ts[j])for(auto&z:ts[k]){string w(L,0);for(size_t p=0;p<L;p++)w[p]=x.val[p]?z.val[p]:y.val[p];accept(s,move(w),"C("+x.text+","+y.text+","+z.text+")");}
  }}
  cerr<<"size="<<s<<" unique="<<ts[s].size()<<" total="<<seen.size()<<" attempts="<<attempts<<" candidates="<<candidates<<endl;
 }
}
