#!/usr/bin/env python3
"""Independent raw-syntax check; no semantic deduplication or imported scripts."""
import itertools, json
from functools import lru_cache
from pathlib import Path
MAX_SIZE=9
GRID=tuple(itertools.product(range(6),range(10)))
T={1:[('0',(0,)*len(GRID)),('a',tuple(a for a,v in GRID)),('v',tuple(v for a,v in GRID))]}
def require(condition,message):
    if not condition: raise AssertionError(message)
def D(x,y):return max(y-x,0)+max(x-y-1,0)
def necessary(vals):
    for (a,v),o in zip(GRID,vals):
        if (a==0 or (a!=v and a!=v+1)) and o!=a:return False
    q=vals[10]
    # At size <=9, q=h(1,0) <=9, since only S can increase max(input).
    require(q<=9, f"Size-bound violation: q={q}")
    return q!=1 and vals[10+q]==1
report={'grammar':'h := 0 | a | v | S(h) | D(h,h) | C(h,h,h)',
        'grid':{'a':[0,5],'v':[0,9]},'raw_sizes':{},'survivors':[]}
for size in range(1,MAX_SIZE+1):
    if size>1:
        terms=[]
        for t,v in T[size-1]:terms.append((f'S({t})',tuple(x+1 for x in v)))
        for i in range(1,size-1):
            j=size-1-i
            for (tx,x),(ty,y) in itertools.product(T[i],T[j]):
                terms.append((f'D({tx},{ty})',tuple(D(a,b) for a,b in zip(x,y))))
        for i in range(1,size-2):
            for j in range(1,size-1-i):
                k=size-1-i-j
                if k<1:continue
                for (tx,x),(ty,y),(tz,z) in itertools.product(T[i],T[j],T[k]):
                    terms.append((f'C({tx},{ty},{tz})',tuple(b if a==0 else c for a,b,c in zip(x,y,z))))
        T[size]=terms
    report['raw_sizes'][size]=len(T[size])
    for t,v in T[size]:
        if necessary(v):report['survivors'].append({'size':size,'body':t,'h10':v[10]})
@lru_cache(None)
def U(x,a):
    if x==0:return a
    v=U(a,x-1)
    return v+2 if D(a,v+1)==0 else a
checks=0
for x in range(60):
    for a in range(60):
        require(U(x,a)==(a+1 if x==a and x>0 else a), f"Candidate mismatch at {(x,a)}")
        checks+=1
report['candidate_standard_grid_checks']=checks
controls={
  'C(D(a,v),v,a)':tuple(v if D(a,v)==0 else a for a,v in GRID),
  'C(D(a,v),S(a),a)':tuple(a+1 if D(a,v)==0 else a for a,v in GRID),
}
for body,vals in controls.items():require(not necessary(vals),f'Negative control unexpectedly passed: {body}')
report['negative_controls_rejected']=list(controls)
report['lower_bound']='No term with <=8 nodes survives necessary standard-model conditions for global off-law and U(1,1)!=1.'
path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
