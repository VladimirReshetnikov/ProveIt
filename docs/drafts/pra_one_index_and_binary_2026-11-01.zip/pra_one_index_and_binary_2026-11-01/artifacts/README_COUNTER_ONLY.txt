COUNTER-ONLY INLINE C/D VARIANT: REPRODUCIBLE DIAGNOSTICS

This is a distinct language from check_inline.py's seed-only language:

  R_h(0,a,b) = a
  R_h(Sn,a,b) = h(n,b,R_h(a,n,b)).

The update receives n, frozen b, and v; it does NOT receive mutable seed a.
The ASTs explicitly represent that distinction, although the syntax counts
coincide. C and D still have one-node bodies b and v, so the display-plus-
selected-body subtotal is 55+2=57 at m=1. The full-arity subtotal is 45+12m,
with exactly the same nonuniform comparison caveat as the seed-only basis.

Reproduce from the package root:

  python3 artifacts/check_counter_only.py
  python3 -O artifacts/check_counter_only.py --output artifacts/results_counter_only_optimized.json
  cmp artifacts/results_counter_only.json artifacts/results_counter_only_optimized.json

Both modes pass 134,448 active checks with byte-identical JSON. A further
run from /tmp produces the same bytes. Only Python 3.9+ and its standard
library are required. No inherited or other local script is imported or
executed; no random sampling is used. Checks are explicit require() calls,
not Python assert statements that -O could remove.

Coverage:
- Exact formula ASTs for m=1,...,12, fully recorded at m=1,2,3.
- Eleven symbolic bootstrap/recursion rewrites. Every non-computation
  diagonal assumption is explicitly listed.
- All 1,089 pairs through 32 for D,K,E,native-equality bit and addition;
  selectors and both delta/L tag inverses through 32 are also checked.
- 4,410 direct-versus-reverse-compiler comparisons and 17,640 equations,
  including zero, one, and two frozen parameters.
- All 1,024 bit tables of length 10 for the direct latch: 10,240 diagonal
  values and 6,912 local-progress stationarity cases.
- Six ordinary-recursion families, including factorial, parameterized,
  and nonlinear examples: 79 output values and 2,079 tag-transition checks.
  Actual source-defined delta,L,p,Q,J are evaluated, not replaced by
  multiplication, floor division, or native conditional shortcuts.

The identities particular to this variant are:

  R(Sx,Sy) = h_x(h_y(R(x,y)))
  Z(Sn) = h_n(h_n(Z(n)))
  t(n) = Z(Sn), for h_n(v)=C(b(n),1,v)
  u(n,v) = Q(Sn,delta(Sv),Sv,v), L(t)=R_u(t,t)
  B(n,b,z) = J(n,G(b),H(p(n),b,z))
  h(n,b,v) = Q(v,delta(L(v)),Sv,delta(B(n,b,L(v))))
  F(n,b) = L(R_h(Sn,Sn,b)).

The reverse compiler has:

  V0 = e if d=0; h(p(d),b,p(d)) otherwise
  V(Sj,d,e,b) = h(d+j,b,h(e+j,b,V(j,d,e,b))).

Four detected negative controls distinguish the new grammar from accidental
reuse of the seed-only formulas:
1. Omitting S from the decoder's first comparison breaks L(2)=1.
2. Omitting the reverse compiler's inner update fails at x=y=1.
3. Using the seed-only mixed diagonal h_(n+1) h_n gives a wrong latch base.
4. Using seed-only initialization J(p(n),...) gives identity F(1)=0, not 1.

SCOPE: finite standard-N diagnostics and exact syntax accounting only.
This is not a formal verification of the schema, quantified derivations,
nonstandard uniqueness, or either full bi-interpretation. The constructive
written proof is responsible for those claims. Numerical tests cannot
choose a logic or establish intuitionistic validity by themselves.
