ROUND-4 INLINE C/D AND SHORT-U DIAGNOSTICS

Reproduce from the package root (Python 3.9+, standard library only):

    python3 artifacts/check_inline.py
    python3 -O artifacts/check_inline.py --output artifacts/results_inline_optimized.json
    cmp artifacts/results_inline.json artifacts/results_inline_optimized.json

Both executions pass 180,360 active checks and produce identical JSON.
The checker also ran successfully with /tmp as its current directory and
produced the same bytes. The source contains no Python assert statement;
require() explicitly raises AssertionError, including under -O.

SCOPE
These are exact finite syntax counts, selected explicit term rewrites,
and finite standard-natural-number diagnostics. They are not a formal
verification of the first-order schema, source quantifier-free induction,
nonstandard uniqueness, or either full interpretation round trip. The
algebraic diagnostics are logic-neutral; intuitionistic validity still
rests on the accompanying constructive written derivations.

The checker was freshly assembled, with its attribution stated in the
module docstring. It adapts the inspected round-3 check_counterfree.py's
counter-free evaluator and testing patterns. The shorter two-tag compiler
is adapted from the supplied pra_relative_constancy_2026-11-01 archive's
sections/counterfree.tex. No input-archive or prior diagnostic script was
executed or imported. There is no randomness, third-party dependency,
network access, or import of another local script.

WHAT WAS CHECKED
- Expanded ASTs for all three matched families and arities m=1,...,12;
  complete trees are recorded at m=1,2,3. Repeated terms count separately;
  K/E are expanded terms rather than uncharged symbols or shared nodes.
- Inline computation 12+6m, schema 25+6m, separation 6: display 43+12m,
  selected bodies 2, subtotal 45+12m. At m=1 this is 55+2=57.
- Short-U computation 12+6m, schema 20+5m, separation 6: display 38+11m,
  selected bodies 11, subtotal 49+11m. At m=1 this is 49+11=60.
- Best supplied counterful comparison: display 39+11m, bodies 8,
  subtotal 47+11m. At m=1 this is 50+8=58.
- The inline subtotal difference is m-2: better only at m=1, equal at
  m=2, worse at every m>=3. Short-U's display is always one smaller than
  counterful but its subtotal is always two larger. These remain partial
  syntax metrics, not complete encoding lengths or global minima.
- Fifteen symbolic bootstrap/recursion rewrites, with every additional
  non-computation lemma written explicitly as an assumption.
- All 1,089 pairs x,y<=32 for D, K, E, native equality, addition, order,
  and monus; selector values are also tested. K(x,a)=x at a=Sx and equals
  a otherwise; E(x,y)=0 at equality and 1 at disequality.
- All 1,681 pairs x,a<=40 for the nine-node U update and its equality bit.
- 4,410 direct-versus-ordinary reverse-compiler comparisons and 17,640
  equation checks, with zero, one, and two frozen parameters.
- Idempotent scans, all 256 Boolean tables of length 8 for explicit
  bounded witnesses, and the normalized-base caveat.
- All 1,024 Boolean tables of length 10 for the direct QFI latch:
  9,216 diagonal values and 6,144 local-progress stationarity cases.
- The selected two-tag compiler: delta and L are evaluated by their
  actual counter-free programs, not replaced by multiplication or floor
  division. Both tag inverses are checked through z=30. Six ordinary
  recursion families (including factorial, nonlinear, and parameterized
  examples) give 79 F-values and 1,386 tag-transition checks. Growth-heavy
  examples use explicit smaller bounds recorded in JSON.
- The older guarded-capacity compiler remains as an additional diagnostic:
  637 W-values and 5,733 pairwise cross-capacity coherence checks.

TEN NEGATIVE CONTROLS, ALL DETECTED
1. Omitting S from E=D(y,K(x,Sy)): wrong at x=0,y=1.
2. Six-node candidate C(D(a,v),v,a): U(2,1)=0 violates its off-law.
3. Seven-node candidate C(D(a,v),Sa,a): U(1,0)=1 violates its off-law.
4. Omitting the reverse compiler's inner update: wrong at x=y=1.
5. Canceling h0 from the diagonal base without h0(0)=0: wrong R(1,1).
6. Reversing the latch branches: all-true prefix gives a false failure.
7. Using cap=0 at j=1 in the guarded compiler: identity returns 0.
8. Removing the explicit D(x,x)=0 lemma: K(x,Sx) no longer rewrites to x.
9. Replacing delta(Sv) by delta(v) in the decoder: L(1)=1 instead of 0.
10. Removing the even-tag pass phase: identity gives F(2)=3 instead of 2.

The separate restricted exhaustive search for shortest U bodies belongs
to its own search artifact; this script does not claim to certify it.
