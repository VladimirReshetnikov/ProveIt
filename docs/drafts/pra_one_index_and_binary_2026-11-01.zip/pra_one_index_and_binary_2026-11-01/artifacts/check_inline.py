#!/usr/bin/env python3
"""Deterministic round-4 diagnostics, freshly assembled for the inline C/D basis.

Run: python3 check_inline.py --output results_inline.json
Also run with python3 -O and compare JSON bytes. All checks use require(),
not removable assert statements. Python 3.9+ standard library only.

The counter-free evaluator, AST convention, diagonal compiler, latch and
bounded-capacity compiler tests adapt the explicitly inspected round-3
artifacts/check_counterfree.py. No input-archive or prior script is executed
or imported. Inline K/E arithmetic, exact cross-arity comparisons, symbolic
bootstrap checks and short-U coverage are new here. Finite tests and explicit
rewrites do NOT prove the first-order schemas or either bi-interpretation.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path

CHECKS = 0


def require(condition, detail='check failed'):
    """Active under ordinary Python and Python -O alike."""
    global CHECKS
    CHECKS += 1
    if not condition:
        raise AssertionError(detail)


@dataclass(frozen=True)
class Tree:
    kind: str
    label: str
    children: tuple['Tree', ...] = ()

    def count(self):
        return 1 + sum(c.count() for c in self.children)

    def show(self):
        if not self.children:
            return self.label
        if self.kind == 'quantifier':
            return 'forall ' + self.label + '.(' + self.children[0].show() + ')'
        return self.label + '(' + ','.join(c.show() for c in self.children) + ')'

    def data(self):
        r = {'kind': self.kind, 'label': self.label}
        if self.children:
            r['children'] = [c.data() for c in self.children]
        return r


def var(name): return Tree('variable', name)
def app(name, *xs): return Tree('application', name, xs)
def eq(x, y): return Tree('equality', '=', (x, y))
def implies(x, y): return Tree('connective', 'implies', (x, y))
def either(x, y): return Tree('connective', 'or', (x, y))
def all_(v, f): return Tree('quantifier', v.label, (f,))
def close(vs, f):
    for v in reversed(vs):
        f = all_(v, f)
    return f


ZERO = Tree('constant', '0')
BOTTOM = Tree('falsity', 'bottom')
def S(x): return app('S', x)
ONE = S(ZERO)
TWO = S(ONE)


def K_term(x, a): return app('C', app('D', a, x), x, a)
def E_term(x, y): return app('D', y, K_term(x, S(y)))
def U_body(a, v): return app('C', app('D', a, S(v)), S(S(v)), a)


def formula_trees(m, family):
    require(m >= 1, 'm includes the mutable/probe parameter')
    require(family in ('inline', 'short_U', 'best_counterful'), family)
    n, a = var('n'), var('a')
    bs = tuple(var('b' + str(i)) for i in range(1, m))
    ps = (a,) + bs
    fn, f0, fs = (app('f', arg, *ps) for arg in (n, ZERO, S(n)))
    inner = app('R', a, n, *bs)
    hargs = ((n,) if family == 'best_counterful' else ()) + ps + (inner,)
    compare = K_term(f0, a) if family == 'inline' else app('U' if family == 'short_U' else 'T', f0, a)
    second = S(fn) if family == 'inline' else fn
    return {
        'D_base': close(ps, eq(app('R', ZERO, *ps), a)),
        'D_step': close((n,) + ps, eq(app('R', S(n), *ps), app('h', *hargs))),
        'PC': close(ps, implies(all_(n, eq(fs, fn)), all_(n, either(eq(compare, a), eq(second, a))))),
        'Sep': implies(eq(ZERO, ONE), BOTTOM),
    }


def metrics():
    a, b, n, v = map(var, ('a', 'b', 'n', 'v'))
    bodies = {
        'inline': {'C': b, 'D': v},
        'short_U': {'C': b, 'D': v, 'U': U_body(a, v)},
        'best_counterful': {'C': b, 'D': v, 'T': app('C', app('D', a, n), n, a)},
    }
    expected_bodies = {'inline': 2, 'short_U': 11, 'best_counterful': 8}
    summary, all_rows = {}, []
    for family, programs in bodies.items():
        sizes = {k: t.count() for k, t in programs.items()}
        subtotal = sum(sizes.values())
        require(subtotal == expected_bodies[family], (family, sizes))
        rows = []
        for m in range(1, 13):
            cs = {k: t.count() for k, t in formula_trees(m, family).items()}
            computation = cs['D_base'] + cs['D_step']
            display = sum(cs.values())
            require(cs['D_base'] == 4 + 2*m, cs)
            require(cs['Sep'] == 6, cs)
            require(computation == 12 + 6*m + int(family == 'best_counterful'), cs)
            require(cs['PC'] == (25 + 6*m if family == 'inline' else 20 + 5*m), cs)
            expected = {'inline': 43 + 12*m, 'short_U': 38 + 11*m,
                        'best_counterful': 39 + 11*m}[family]
            require(display == expected, (family, m, cs))
            rows.append({'m': m, **cs, 'computation': computation,
                         'display': display, 'display_plus_selected_bodies': display + subtotal})
        summary[family] = {
            'selected_bodies': {k: {'nodes': t.count(), 'text': t.show(), 'tree': t.data()} for k, t in programs.items()},
            'body_subtotal': subtotal, 'arity_checks': rows,
            'explicit_trees': {str(m): {k: {'nodes': t.count(), 'text': t.show(), 'tree': t.data()}
                for k, t in formula_trees(m, family).items()} for m in (1, 2, 3)},
        }
    for m in range(1, 13):
        ip = summary['inline']['arity_checks'][m-1]['display_plus_selected_bodies']
        cp = summary['best_counterful']['arity_checks'][m-1]['display_plus_selected_bodies']
        require(ip - cp == m - 2, (m, ip, cp))
        all_rows.append({'m': m, 'inline': ip, 'best_counterful': cp, 'inline_minus_counterful': ip-cp})
    require(summary['inline']['arity_checks'][0]['display'] == 55)
    require(summary['short_U']['arity_checks'][0]['display'] == 49)
    return {
        'convention': 'Each variable occurrence, constant, application, equality, connective, bottom, and individual quantifier costs one. Binder names are metadata; 1 expands to S(0), negation to implication-bottom. The computation equations are separate, not conjoined. Repeated f(0,...) occurrences count separately; no DAG sharing or K/E symbol is charged in place of an expanded term.',
        'families': summary,
        'closed_forms': {'inline_display': '43+12m', 'inline_subtotal': '45+12m',
            'short_U_display': '38+11m', 'short_U_subtotal': '49+11m',
            'best_counterful_display': '39+11m', 'best_counterful_subtotal': '47+11m'},
        'cross_arity_comparison': all_rows,
        'honest_comparison': 'Inline subtotal is one node better only at m=1, equal at m=2, and worse at every m>=3. Short-U has a one-node smaller display than the counterful basis but a two-node larger subtotal at every matched m.',
        'limitations': 'Partial display-plus-selected-body metrics, not total encoding lengths. They omit syntax/enumerator metadata, description tags, binding metadata, and arbitrary substituted terms.',
    }


def direct(h):
    """Finite-N diagnostic evaluator; swapped argument sum decreases by one."""
    @lru_cache(None)
    def r(x, a, bs=()):
        require(x >= 0 and a >= 0, (x, a))
        return a if x == 0 else h(a, bs, r(a, x-1, bs))
    return r


C = direct(lambda a, bs, v: bs[0])
D = direct(lambda a, bs, v: v)
U = direct(lambda a, bs, v: C(D(a, v+1), v+2, (a,)))
ADD = direct(lambda a, bs, v: v+1)

def p(x): return D(x, 0)
def K(x, a): return C(D(a, x), x, (a,))
def E(x, y): return D(y, K(x, y+1))
def eqbit(x, y): return C(E(x, y), 1, (0,))
def J(z, u, v): return C(E(z, 0), u, (v,))
def Q(x, y, u, v): return C(eqbit(x, y), v, (u,))
def delta(n): return ADD(n, n)
DECODER = direct(lambda a, bs, v: Q(a, delta(v+1), v+1, v))
def L(t): return DECODER(t, t)
ORDER = direct(lambda a, bs, v: C(eqbit(a, bs[0]), v, (a,)))
def lebit(x, y): return eqbit(ORDER(y, y, (x,)), x)
def monus(x, y): return C(lebit(x, y), D(y, x), (0,))


def arithmetic_tests(bound=32):
    for x, y in itertools.product(range(bound+1), repeat=2):
        require(D(x, y) == max(y-x, 0) + max(x-y-1, 0), ('D', x, y))
        require((D(y, x) == 0) == (y == x or y == x+1), ('D-zero', x, y))
        require(K(x, y) == (x if y == x+1 else y), ('K', x, y))
        require(K(x, y) == y or x+1 == y, ('constant-IP', x, y))
        require(E(x, y) == int(x != y), ('E', x, y))
        require(eqbit(x, y) == int(x == y), ('eqbit', x, y))
        require(ADD(x, y) == x+y and ADD(x+1, y) == ADD(x, y)+1, ('ADD', x, y))
        require(ORDER(y, y, (x,)) == (x if x <= y else 0), ('ORDER', x, y))
        require(lebit(x, y) == int(x <= y), ('lebit', x, y))
        require(monus(x, y) == max(x-y, 0), ('monus', x, y))
        require(monus(x, y+1) == p(monus(x, y)), ('monus-step', x, y))
        require(lebit(x+1, y+1) == lebit(x, y), ('order-shift', x, y))
        require(lebit(x, y+1) == int(bool(lebit(x, y)) or x == y+1), ('order-rec', x, y))
    for x in range(bound+1):
        require(p(x+1) == x and D(x, x) == 0 and D(x, x+1) == 1, ('bootstrap', x))
        require(K(x, x+1) == x, ('K-diagonal', x))
        require(ORDER(0, 0, (x,)) == 0, ('ORDER-base', x))
        for u, v in itertools.product(range(5), repeat=2):
            require(J(x, u, v) == (u if x == 0 else v), ('J', x, u, v))
    bad_error = lambda x, y: D(y, K(x, y))
    witness = next({'x': x, 'y': y, 'correct': E(x, y), 'mutated': bad_error(x, y)}
        for x, y in itertools.product(range(4), repeat=2) if E(x, y) != bad_error(x, y))
    require(witness is not None, 'error mutation must be detected')
    return {'bound': bound, 'pairs': (bound+1)**2,
        'formulas': {'D': 'max(y-x,0)+max(x-y-1,0)', 'K': 'x if a=Sx, otherwise a',
            'E': '0 iff x=y; 1 iff x!=y', 'eqbit': 'C(E(x,y),1,0)',
            'J': 'C(E(z,0),u,v)', 'ORDER': 'R_x(y,y), update C(eqbit(a,x),v,a)',
            'lebit': 'eqbit(ORDER(y,y,x),x)', 'monus': 'C(lebit(x,y),D(y,x),0)'},
        'negative_control': {'mutation': 'omit S on y in E=D(y,K(x,Sy))', 'detected': True, 'witness': witness}}


def short_u_tests(bound=40):
    pairs = 0
    for x, a in itertools.product(range(bound+1), repeat=2):
        require(U(x, a) == (a+1 if x == a and x > 0 else a), ('U', x, a))
        require(U(x, a) == a or x == a, ('U-off', x, a))
        require(D(a+1, U(x+1, a+1)) == int(x == a), ('U-eqbit', x, a))
        require(C(D(a, x+1), x+2, (a,)) == (a+1 if a == x+1 else a), ('U-body', a, x))
        pairs += 1
    require(U(1, 0) == 0 and U(1, 1) == 2)
    bad6 = direct(lambda a, bs, v: C(D(a, v), v, (a,)))
    bad7 = direct(lambda a, bs, v: C(D(a, v), a+1, (a,)))
    require(bad6(2, 1) != 1, 'six-node off-law counterexample')
    require(bad7(1, 0) != 0, 'seven-node off-law counterexample')
    return {'bound': bound, 'pairs': pairs,
        'body': 'C(D(a,Sv),SSv,a)', 'body_nodes': 9,
        'body_behavior': 'Sa iff a=Sv; a otherwise',
        'U_behavior': 'Sa iff x=a and x!=0; a otherwise',
        'bootstrap': {'U(1,0)': U(1,0), 'U(1,1)': U(1,1)},
        'negative_controls': [
            {'mutation': 'six-node h=C(D(a,v),v,a)', 'detected': True,
             'witness': 'U(2,1) must equal 1', 'mutated': bad6(2,1)},
            {'mutation': 'seven-node h=C(D(a,v),Sa,a)', 'detected': True,
             'witness': 'U(1,0) must equal 0', 'mutated': bad7(1,0)}],
        'scope': 'Does not duplicate or certify the separate restricted exhaustive syntax search.'}


def reverse_compiler(h, omit_inner=False):
    def r(x, y, bs=()):
        d, e = max(x-y, 0), max(y-x, 0)
        value = e if d == 0 else h(0, bs, max(d-1, 0))
        for j in range(min(x, y)):
            inner = value if omit_inner else h(d+j, bs, value)
            value = h(e+j+1, bs, inner)
        return value
    return r


def reverse_tests(bound=20):
    cases = [('previous', lambda a,b,v:v, [()]),
             ('mutable', lambda a,b,v:a, [()]),
             ('increment', lambda a,b,v:v+1, [()]),
             ('nonlinear', lambda a,b,v:a*a+v, [()]),
             ('one_frozen', lambda a,b,v:(b[0]+1)*v+a, [(0,), (1,), (4,)]),
             ('two_frozen', lambda a,b,v:(b[0]+1)*v+a+b[1], [(0,0),(1,2),(3,1)])]
    rows = []
    for name, h, tuples in cases:
        rd, rc = direct(h), reverse_compiler(h)
        comparisons = equations = 0
        for bs in tuples:
            for x, y in itertools.product(range(bound+1), repeat=2):
                require(rd(x,y,bs) == rc(x,y,bs), (name,x,y,bs))
                require(rc(0,y,bs) == y, ('base',name,x,y,bs))
                require(rc(x+1,y,bs) == h(y,bs,rc(y,x,bs)), ('step',name,x,y,bs))
                require(rc(x+1,0,bs) == h(0,bs,x), ('axis',name,x,y,bs))
                require(rc(x+1,y+1,bs) == h(y+1,bs,h(x,bs,rc(x,y,bs))), ('joint',name,x,y,bs))
                comparisons += 1
                equations += 4
        rows.append({'update': name, 'frozen_tuples': tuples, 'comparisons': comparisons, 'equations': equations})
    h = lambda a,b,v:v+1
    good, bad = direct(h), reverse_compiler(h, omit_inner=True)
    witness = next({'x':x,'y':y,'correct':good(x,y),'mutated':bad(x,y)}
        for x,y in itertools.product(range(5),repeat=2) if good(x,y) != bad(x,y))
    require(witness is not None)
    return {'bound':bound, 'examples':rows,
        'total_comparisons':sum(r['comparisons'] for r in rows),
        'total_equations':sum(r['equations'] for r in rows),
        'negative_control': {'mutation':'omit inner update in V step','detected':True,'witness':witness}}


def idempotent_and_witness_tests(bound=18, length=8):
    examples = [('identity',lambda a,b,v:v),('overwrite',lambda a,b,v:a),
        ('max',lambda a,b,v:max(a,v)),('min',lambda a,b,v:min(a,v)),
        ('unnormalized_latch',lambda a,b,v:1 if a % 3 == 0 else v)]
    rows=[]
    for name,h in examples:
        for a,v in itertools.product(range(bound+1),repeat=2):
            require(h(a,(),h(a,(),v)) == h(a,(),v),name)
        r=direct(h)
        expected=h(1,(),h(0,(),0))
        require(r(1,1)==expected,name)
        for n in range(1,bound+1):
            require(r(n,n)==expected,name)
            require(r(n+1,n+1)==h(n+1,(),r(n,n)),name)
            expected=h(n+1,(),expected)
        normalized=h(0,(),0)==0
        if normalized:
            require(r(1,1)==h(1,(),r(0,0)),name)
        rows.append({'update':name,'normalized_base':normalized})
    witnesses=captures=0
    for bits in itertools.product((0,1),repeat=length):
        hit=direct(lambda a,bs,v:C(bits[a],v,(a,)))
        miss=direct(lambda a,bs,v:C(1-bits[a],v,(a,)))
        for n in range(length):
            w,wn=hit(n,n),miss(n,n)
            require(0<=w<=n and 0<=wn<=n,('bounds',bits,n))
            require(bool(bits[w])==any(bits[:n+1]),('exists',bits,n,w))
            require(bool(bits[wn])==all(bits[:n+1]),('forall',bits,n,wn))
            require(w==max([a for a in range(n+1) if bits[a]] or [0]),('last-hit',bits,n))
            for a in range(n+1):
                if bits[a]:
                    require(bits[w]==1,('capture',bits,a,n))
                    captures+=1
            witnesses+=1
    bad=direct(examples[-1][1])
    require(bad(1,1)!=examples[-1][1](1,(),bad(0,0)))
    return {'idempotent_examples':rows,'bound':bound,'all_bit_sequences':2**length,
        'sequence_length':length,'witness_values':witnesses,'capture_checks':captures,
        'bounded_exists':'A(W_A(n)) iff exists a<=n A(a)',
        'bounded_forall':'A(W_not_A(n)) iff forall a<=n A(a)',
        'negative_control':{'mutation':'cancel h0 from diagonal base without h0(0)=0','detected':True,
            'actual_R11':bad(1,1),'invalid_h1_R00':examples[-1][1](1,(),bad(0,0))}}


def latch_tests(length=10):
    tables=[]
    for b,c in itertools.product((0,1),repeat=2):
        conj=C(b,0,(c,));disj=C(b,c,(1,));impl=C(b,1,(c,))
        require(conj==int(bool(b) and bool(c)))
        require(disj==int(bool(b) or bool(c)))
        require(impl==int(not bool(b) or bool(c)))
        tables.append({'b':b,'c':c,'and':conj,'or':disj,'implies':impl})
    values=stationary=0
    for bits in itertools.product((0,1),repeat=length):
        h=lambda a,bs,v:C(bits[a],1,(v,))
        r=direct(h)
        ts=[r(n+1,n+1) for n in range(length-1)]
        for n,t in enumerate(ts):
            require(t==int(0 in bits[:n+2]),('latch',bits,n))
            require(h(n,(),1)==1,('fix-one',bits,n))
            if not bits[n]:require(t==1,('failure-detected',bits,n))
            values+=1
        if bits[0] and bits[1]:require(ts[0]==0,('base',bits))
        for n in range(length-2):
            require(ts[n+1]==h(n+2,(),h(n+1,(),ts[n])),('rewrite',bits,n))
            if not bits[n+1] or bits[n+2]:
                require(ts[n+1]==ts[n],('local-progress-stationary',bits,n))
                stationary+=1
    bad_bits=(1,1,1)
    wrong=direct(lambda a,bs,v:C(bad_bits[a],v,(1,)))
    require(wrong(1,1)!=0, 'reversed branches must falsely reject an all-true prefix')
    return {'bit_convention':'1 means true', 'truth_tables':tables,
        'all_bit_sequences':2**length,'sequence_length':length,
        'diagonal_values':values,'local_progress_stationarity_checks':stationary,
        'latch':'h_a(v)=C(b(a),1,v); t(n)=R(Sn,Sn)',
        'finite_characterization':'t(n)=1 iff some b(k)=0 for 0<=k<=n+1',
        'negative_control':{'mutation':'reverse branches to C(b(a),v,1)','detected':True,
            'bits':bad_bits,'expected_t0':0,'mutated_t0':wrong(1,1)},
        'scope':'Exhaustive local finite computations; the contextual induction theorem is still a written proof.'}


def guarded_ordinary_tests(bound=12):
    specs=[('identity',lambda b:0,lambda n,b,v:v+1,[()]),
           ('factorial',lambda b:1,lambda n,b,v:(n+1)*v,[()]),
           ('triangular',lambda b:0,lambda n,b,v:v+n+1,[()]),
           ('affine',lambda b:b[0],lambda n,b,v:v+b[1],[(0,0),(2,3)]),
           ('time_dependent',lambda b:b[0]+b[1],lambda n,b,v:(b[0]+1)*v+n+b[1],[(0,2),(1,3)])]
    rows=[]
    for name,g,h,tuples in specs:
        def update(a,bs,v):
            cap,ps=bs[0],bs[1:]
            return C(lebit(a,cap),v,(J(a,g(ps),h(p(a),ps,v)),))
        r=direct(update)
        def W(j,cap,ps):return r(j+1,ADD(cap,j)+1,(cap,)+ps)
        values=steps=coherence=full_steps=0
        for ps in tuples:
            expected=[g(ps)]
            for n in range(bound):expected.append(h(n,ps,expected[-1]))
            for cap in range(bound+1):
                require(W(0,cap,ps)==g(ps),(name,'base',cap))
                for j in range(cap+1):
                    require(W(j,cap,ps)==expected[j],(name,'value',j,cap,ps))
                    values+=1
                    for other in range(j,bound+1):
                        require(W(j,cap,ps)==W(j,other,ps),(name,'coherence',j,cap,other,ps))
                        coherence+=1
                    if j<cap:
                        require(W(j+1,cap,ps)==h(j,ps,W(j,cap,ps)),(name,'step',j,cap,ps))
                        steps+=1
            for n in range(bound):
                require(W(n+1,n+1,ps)==h(n,ps,W(n,n,ps)),(name,'Fstep',n,ps))
                full_steps+=1
        rows.append({'ordinary_recursion':name,'frozen_tuples':tuples,
            'W_values':values,'within_cap_steps':steps,'all_cross_cap_coherence_checks':coherence,
            'F_steps':full_steps})
    bad=direct(lambda a,bs,v:C(lebit(a,bs[0]),v,(J(a,0,v+1),)))
    wrong=bad(2,ADD(0,1)+1,(0,))
    require(wrong!=1,'unjustified capacity cannot compute identity at 1')
    return {'bound':bound,'examples':rows,'total_W_values':sum(r['W_values'] for r in rows),
        'total_cross_cap_coherence':sum(r['all_cross_cap_coherence_checks'] for r in rows),
        'update':'if a<=N then J(a,G,H(p(a),v)) else v',
        'W':'W(j,N)=R(Sj,S(N+j),N,parameters)','F':'F(n)=W(n,n)',
        'implementation':'All branch, equality, order, predecessor and addition helpers are evaluated through C/D and the inline error term; no U helper is used.',
        'negative_control':{'mutation':'use cap=0 at j=1 for identity recursion','detected':True,
            'expected':1,'mutated':wrong},
        'scope':'Numerical standard-N behavior and bounded coherence, not a formal proof of either interpretation round trip.'}


def tagged_ordinary_tests(tag_bound=30):
    """Fresh tests of the supplied relative-constancy two-tag construction.

    The algorithm's delta and L are evaluated through their own legal
    counter-free descriptions, not replaced by multiplication or //.
    Growth-heavy ordinary examples deliberately use smaller bounds.
    """
    for z in range(tag_bound+1):
        require(delta(z)==2*z, ('delta-value',z))
        require(delta(z+1)==delta(z)+2, ('delta-step',z))
        require(L(delta(z))==z, ('even-inverse',z))
        require(L(delta(z)+1)==z, ('odd-inverse',z))
    specs=[
        ('identity',lambda b:0,lambda n,b,v:v+1,[()],10),
        ('factorial',lambda b:1,lambda n,b,v:(n+1)*v,[()],4),
        ('triangular',lambda b:0,lambda n,b,v:v+n+1,[()],8),
        ('affine',lambda b:b[0],lambda n,b,v:v+b[1],[(0,0),(2,3)],8),
        ('time_and_parameter_dependent',lambda b:b[0]+b[1],
            lambda n,b,v:v+b[0]*n+b[1],[(0,2),(1,3)],6),
        ('bounded_nonlinear',lambda b:b[0],
            lambda n,b,v:(v*v+n+b[0]) % 17,[(1,),(3,)],10),
    ]
    rows=[]
    for name,g,H,tuples,bound in specs:
        def phase_step(a,bs,z):return J(p(a),g(bs),H(p(p(a)),bs,z))
        def update(a,bs,v):
            decoded=L(v)
            return Q(v,delta(decoded),v+1,delta(phase_step(a,bs,decoded)))
        r=direct(update)
        def Z(n,bs):return r(n,n,bs)
        def F(n,bs):return L(Z(n+1,bs))
        values=transitions=equations=0
        for bs in tuples:
            expected=g(bs)
            for a,z in itertools.product(range(7),range(11)):
                require(update(a,bs,delta(z))==delta(z)+1,('pass-tag',name,a,z,bs))
                require(update(a,bs,delta(z)+1)==delta(phase_step(a,bs,z)),
                    ('compute-tag',name,a,z,bs))
                transitions+=2
            require(Z(1,bs)==delta(g(bs)),('initialization',name,bs))
            require(F(0,bs)==g(bs),('base',name,bs))
            for n in range(bound+1):
                require(F(n,bs)==expected,('tagged-F',name,n,bs,F(n,bs),expected))
                require(Z(n+1,bs)==delta(F(n,bs)),('tag-invariant',name,n,bs))
                values+=1
                if n<bound:
                    next_value=H(n,bs,expected)
                    require(F(n+1,bs)==H(n,bs,F(n,bs)),('ordinary-step',name,n,bs))
                    require(Z(n+2,bs)==delta(next_value),('encoded-step',name,n,bs))
                    expected=next_value
                    equations+=1
        rows.append({'ordinary_recursion':name,'frozen_tuples':tuples,'bound':bound,
            'F_values':values,'two_tag_transition_checks':transitions,'ordinary_successor_equations':equations})
    # A decoder must test delta(Sv), not delta(v): the mutation breaks L(1)=0.
    bad_decoder=direct(lambda a,bs,v:Q(a,delta(v),v+1,v))
    require(bad_decoder(1,1)!=0,'mutated decoder must break odd zero tag')
    # Updating an even tag immediately applies two ordinary increments per
    # diagonal step and also loses the pass/initialize protocol.
    bad_update=lambda a,bs,v:delta(J(p(a),0,L(v)+1))
    bad=direct(bad_update)
    witness=next({'n':n,'expected':n,'mutated':L(bad(n+1,n+1))}
        for n in range(5) if L(bad(n+1,n+1))!=n)
    require(witness is not None,'missing pass phase must be detected')
    return {'tag_bound':tag_bound,'delta':'R_(h(a,v)=Sv)(n,n)',
        'decoder':'L(t)=R_u(t,t); u(a,v)=Q(a,delta(Sv),Sv,v)',
        'phase_step':'B(a,b,z)=J(p(a),G(b),H(p(p(a)),b,z))',
        'update':'h(a,b,v)=Q(v,delta(L(v)),Sv,delta(B(a,b,L(v))))',
        'output':'Z(n,b)=R_h(n,n,b); F(n,b)=L(Z(Sn,b))',
        'examples':rows,'total_F_values':sum(r['F_values'] for r in rows),
        'total_tag_transitions':sum(r['two_tag_transition_checks'] for r in rows),
        'implementation':'Q,J,p,delta,L are evaluated through the inline C/D error term and their actual counter-free programs; Python multiplication and expected recursion are test oracles only.',
        'attribution':'Adapted from supplied pra_relative_constancy_2026-11-01.zip, sections/counterfree.tex, two numerical tags and effective ordinary-recursion compiler. The input script was not run or imported.',
        'negative_controls':[
            {'mutation':'replace delta(Sv) with delta(v) in decoder','detected':True,
                'expected_L1':0,'mutated_L1':bad_decoder(1,1)},
            {'mutation':'remove even-tag pass phase','detected':True,'witness':witness}],
        'scope':'Tests encoded inputs only; no exhaustive parity classification of arbitrary carrier elements is presumed or established.'}


def rewrite_once(t):
    if t.kind != 'application':return t
    cs=t.children
    if t.label=='C':
        z,a,b=cs
        if z==ZERO:return a
        if z.kind=='application' and z.label=='S':return b
    if t.label=='D':
        z,a=cs
        if z==ZERO:return a
        if z.kind=='application' and z.label=='S':return app('D',a,z.children[0])
    if t.label=='U':
        z,a=cs
        if z==ZERO:return a
        if z.kind=='application' and z.label=='S':return U_body(a,app('U',a,z.children[0]))
    if t.label=='R':
        z,a,*bs=cs
        if z==ZERO:return a
        if z.kind=='application' and z.label=='S':return app('h',a,*bs,app('R',a,z.children[0],*bs))
    return t


def normalize(t, assumptions=()):
    for _ in range(200):
        for lhs,rhs in assumptions:
            if t==lhs:
                t=rhs
                break
        else:
            rewritten=rewrite_once(Tree(t.kind,t.label,tuple(normalize(c,assumptions) for c in t.children)))
            if rewritten==t:return t
            t=rewritten
    raise AssertionError('symbolic rewrite bound exceeded')


def symbolic_tests():
    x,y,b=map(var,('x','y','b'))
    d=app('D',x,x)
    checks=[
        ('p(0)',app('D',ZERO,ZERO),ZERO,()),
        ('p(Sx)',app('D',S(x),ZERO),x,()),
        ('K(0,1)',K_term(ZERO,ONE),ZERO,()),
        ('K(1,2)',K_term(ONE,TWO),ONE,()),
        ('D diagonal stationarity',app('D',S(x),S(x)),d,()),
        ('D next diagonal stationarity',app('D',S(x),S(S(x))),app('D',x,S(x)),()),
        ('K(x,Sx) conditional on proved diagonal',K_term(x,S(x)),x,((d,ZERO),)),
        ('E diagonal conditional on proved diagonal',E_term(x,x),ZERO,((d,ZERO),)),
        ('E first constant-IP branch',E_term(x,y),ONE,
            ((K_term(x,S(y)),S(y)),(app('D',y,S(y)),ONE))),
        ('U(1,0)',app('U',ONE,ZERO),ZERO,()),
        ('U(1,1)',app('U',ONE,ONE),TWO,()),
        ('U positive diagonal conditional on earlier bootstrap',app('U',S(x),S(x)),S(S(x)),
            ((app('U',S(x),x),x),(d,ZERO))),
        ('generic nonzero axis',app('R',S(x),ZERO,b),app('h',ZERO,b,x),()),
        ('generic joint step',app('R',S(x),S(y),b),
            app('h',S(y),b,app('h',x,b,app('R',x,y,b))),()),
        ('direct latch recurrence',app('R',S(S(x)),S(S(x)),b),
            app('h',S(S(x)),b,app('h',S(x),b,app('R',S(x),S(x),b))),()),
    ]
    rows=[]
    for name,lhs,rhs,hyp in checks:
        left,right=normalize(lhs,hyp),normalize(rhs,hyp)
        require(left==right,(name,left.show(),right.show()))
        rows.append({'identity':name,'lhs':lhs.show(),'rhs':rhs.show(),
            'explicit_lemma_assumptions':[eq(l,r).show() for l,r in hyp],
            'common_normal_form':left.show()})
    require(normalize(K_term(x,S(x))) != x,
        'K diagonal must not silently assume stationarity-derived D(x,x)=0')
    return {'checks':rows,'negative_control':{'mutation':'omit non-computation diagonal lemma from K(x,Sx) rewrite',
        'detected':True,'unreduced_normal_form':normalize(K_term(x,S(x))).show()},
        'scope':'Only explicit finite computation rewrites. Used non-computation lemmas are listed as assumptions, not proved by this rewriter.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=Path(__file__).with_name('results_inline.json'))
    args=parser.parse_args()
    result={'status':'DIAGNOSTICS_PASS',
        'scope':'Exact AST accounting, explicit syntactic computation rewrites, and finite standard-natural-number diagnostics. NOT proof-assistant verification, not an exhaustive model check, and not a formal proof of QFI, the schemas, nonstandard uniqueness, or either bi-interpretation.',
        'metrics':metrics(),'symbolic_bootstrap':symbolic_tests(),
        'inline_arithmetic':arithmetic_tests(),'short_U_variant':short_u_tests(),
        'reverse_compiler':reverse_tests(),'idempotent_and_bounded_witnesses':idempotent_and_witness_tests(),
        'direct_QFI_latch':latch_tests(),'guarded_ordinary_compiler':guarded_ordinary_tests(),
        'tagged_ordinary_compiler':tagged_ordinary_tests(),
        'reproducibility':{'python':'Python 3.9+; standard library only',
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'prior_script_adaptation':'Round-3 artifacts/check_counterfree.py was inspected and adapted explicitly; it was neither executed nor imported.',
            'inherited_archive_scripts_executed':False,'other_local_scripts_imported':False,
            'randomness':False,'checks_use_assert_statements':False}}
    result['active_check_count']=CHECKS
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'active_checks':CHECKS,'inline':'55+2=57',
        'short_U':'49+11=60','best_counterful':'50+8=58',
        'inline_subtotal_delta_vs_counterful':'m-2','negative_controls_detected':10,
        'reverse_comparisons':result['reverse_compiler']['total_comparisons'],
        'latch_values':result['direct_QFI_latch']['diagonal_values'],
        'guarded_W_values':result['guarded_ordinary_compiler']['total_W_values'],
        'guarded_coherence_checks':result['guarded_ordinary_compiler']['total_cross_cap_coherence'],
        'tagged_F_values':result['tagged_ordinary_compiler']['total_F_values'],
        'tagged_transition_checks':result['tagged_ordinary_compiler']['total_tag_transitions'],
        'output':str(args.output)},sort_keys=True))


if __name__=='__main__':main()
