#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check_counter_only.py
python3 artifacts/check_inline.py
python3 artifacts/check_counterfree_search.py
python3 artifacts/structural_metrics.py
python3 artifacts/pair_incidence_check.py
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error report.tex
