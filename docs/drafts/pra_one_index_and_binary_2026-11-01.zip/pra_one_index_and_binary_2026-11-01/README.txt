Smaller Presentations of Primitive Recursive Arithmetic
Prepared for Vladimir Reshetnikov, 1 November 2026.

Reviewed commits:
  5e7cbe46ea2d9e3301371a64cafe2080d7526437
  8dc884c9db3e3a9bf1c54d6e89892b13e23f2e6a
Inventory pin at intake:
  c9698c81fd3050409bea74cdc17eb8e4ad69d720

RESULTS
1. Inline comparison with either of two alternative one-index recursion
   interfaces: 55 displayed nodes + 2 selected-program nodes = 57.
   The counter-only interface gives the shorter proof.
   This subtotal improves the current best 58 at one displayed parameter
   only; it ties at two and is larger at three or more parameters.
2. Keep the 49-node display; replace its comparison update by
   C(D(a,Sv),SSv,a). Selected bodies fall from 14 to 11. Subtotal 60.
   A restricted exhaustive search finds no smaller helper in its stated
   grammar, not a global minimum over arithmetic theories.
3. One binary relation and equality: one universal marker and one pair
   sort reduce expanded structural overhead 2219 to 196 and canonical
   interpretation dimension 5 to 2. This is a separate metric.
4. A nonstandard-cover countermodel shows that all standard numeral
   probes still cannot replace the quantified probe for parameter-free
   bi-interpretability. This is not a failure of equiconsistency alone.

The arithmetic theories have complete written constructive proofs,
matching-logic bi-interpretations and identity round trips. The new graph
coding has complete internal round trips; its application to PRA composes
with the supplied quaternary source theorem, retained under references/.
No absolute optimum or end-to-end proof-assistant certificate is claimed.

CONTENTS
report.pdf: 22-page manuscript.
report.tex and five included TeX sections: editable manuscript sources.
axioms.txt: plain-text arithmetic specifications.
artifacts/: fresh diagnostics, exact AST counts, two restricted-search
implementations and result files.
references/: unmodified source TeX used for the inherited quaternary bridge,
with provenance. These are references, not compiled into the new manuscript.
source_manifest.json: pinned input ZIP/member provenance.
VALIDATION.txt: scope of performed checks.
SHA256SUMS: release payload checksums.

REPRODUCE
Use Python 3.9+ and a normal TeX Live installation:
  sh build.sh

The C++ helper search is an optional independent cross-check:
  g++ -std=c++17 -O2 artifacts/search_counterfree.cpp -o search_counterfree
  ./search_counterfree

All Python checks are standard-library only and import no repository code.
The Python outputs are deterministic; their result files are regenerated
beside the scripts. Numerical checks and finite graph tests are diagnostics,
not proofs of axiom schemas or nonstandard-model statements.
