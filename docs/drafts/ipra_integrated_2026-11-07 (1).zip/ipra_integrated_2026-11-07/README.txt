A SMALLER COMPLETE PRESENTATION OF INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 7 November 2026

RESULT

The integrated strict checker has 468 normalized significant Python tokens,
483 AST nodes, and 1,393 normalized UTF-8 bytes. This strictly improves all
coordinates of the 483 / 491 / 1,462 envelope of the nine top-level checker
variants in the six current ProveIt draft archives at commit:

  c5f42a50d9213259760ee385977481c04dccab28

The comparison includes the smaller demand-validation variants. The new
primary still validates every actual numerical witness, even when unused.
The improvement is relative to this finite corpus and the stated Python
measurement contract. No global shortestness theorem is claimed.

The separate-depth ablation also improves all current minima: 471 tokens,
480 AST nodes, 1,449 bytes. It has fewer AST nodes than the primary, while
the primary has fewer tokens and bytes. Both are provided.

MATHEMATICAL CONTENT

The report states every primitive logical/equality rule and both arithmetic
computation schemas. It reconstructs full intuitionistic first-order logic
and all quantifier-free induction instances. The native presentation is
faithful to an ordinary first-order realization T_cov. Its ordinary
interpretations with iPRA use the full number domain, preserve logic and
equality, and have the definable composite isomorphism x=y in both directions.
The ordinary falsity bridge is explicit. The proof handles nonstandard
counters by internal fixed-recursion uniqueness.

The arithmetic/logical basis is inherited and credited. The new reduction
combines arity syntax, locally closed fresh-parameter opening, a shared
scope/sort state, and one proof stream. There is no hidden logical library,
axiom table, universal evaluator, or newly assumed arithmetic principle.

The combinator analysis proves that unrestricted total numerical SK plus
an applicative representative of successor is inconsistent. Typed or
partial alternatives are not ruled out. Typed implicational proof
combinators are a safe derived interface, but no smaller complete
combinatory kernel or implemented combinator frontend is claimed.

FILES

report.pdf, report.tex, sections/*.tex  Complete 20-page paper and TeX sources.
checker.py                            Entire primary acceptance program.
checker_separate.py                   Non-dominated separate-depth ablation.
FORMAT.txt                            Exact grammar and proof-stream contract.
examples/                             122 closed fixture occurrences,
                                      representing 45 distinct certificates.
validation/                           Frozen reference checker and source
                                      cases; independent grammar/opening audit.
comparison/                           Nine unchanged current checkers,
                                      provenance, hashes and two counters.
results/                              Measurements and validation records.
reviews/                              Independent mathematical and code reviews.
reproduce.py                          Re-run finite evidence offline.
build.py                              Recompile report.pdf with pdfLaTeX.
package.py                            Rebuild clean ZIP and SHA-256 manifest.
MANIFEST.sha256                       Delivered-file hashes.
LICENSE_SOURCE.txt                    Preserved source MIT No Attribution license.
ATTRIBUTION.txt                       Inherited and new contributions.

QUICK START

  python3 checker.py examples/draft_0/basic/reflexivity_zero.json
  python3 reproduce.py
  python3 build.py

The checker prints ACCEPT (exit 0) or REJECT (exit 1). The checker uses only
Python's standard library and Python 3.10+ syntax. Measurements are pinned
to CPython 3.12.14; ast.unparse normalization can vary with Python versions.
PDF rebuilding requires a normally configured pdfLaTeX installation and
the standard packages declared in report.tex. Reproduction needs no network.

PUBLIC INPUT

One JSON list contains proof instructions followed by the goal. The checker
reads it from the right and starts with no assumptions. Negative integers
are rigid variable names, not arithmetic negative numbers. Positive integers
are bound coordinates; no positive coordinate is free in a current goal.

A formula with three fields [B,C,D] denotes exists x B. All three fields
are validated under a binder, but C and D are ignored logical padding.
They never become hypotheses. Canonical padding is [0,0] in each field.
Actual numerical witnesses remain strictly validated.

Inert unread initial prefixes are permitted, as in the baselines. The
mathematical proof relation uses unbounded finite computation; a concrete
Python process can reject on memory or recursion-limit exhaustion.

EVIDENCE AND LIMITS

Primary replay: 143 accepted source-fixture occurrences, comprising 122
closed and 21 open cases; 66 distinct source certificates and 45 distinct
closed target certificates. Also 62 rejection cases and 6 real CLI checks.
Open-sequent cases use the internal function, not the public input contract.

Independent audit: 320 grammar cases, 240 named-binder opening comparisons,
45 distinct public certificates replayed in the unmodified prior checker,
26 boundary cases on both candidates, and 16 actual CLI runs including -O.
All pass. These cohorts overlap and are not added as distinct theorems.
Both source counters agree on every baseline and candidate.

The mathematical metatheory has been independently reviewed, but is not
formalized in Lean/Rocq. Finite tests do not replace the general proofs.
