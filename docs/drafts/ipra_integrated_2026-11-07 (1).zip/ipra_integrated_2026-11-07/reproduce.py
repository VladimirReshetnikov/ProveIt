"""Reproduce source measurements and finite validation, entirely offline."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(arguments, destination):
    completed = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                               capture_output=True, text=True)
    (ROOT / 'results' / destination).write_text(completed.stdout + completed.stderr)
    if completed.returncode:
        raise RuntimeError(completed.stdout + completed.stderr)


def main():
    (ROOT / 'results').mkdir(exist_ok=True)
    run(['comparison/measure.py', 'checker.py', 'checker_separate.py'], 'measurement_log.txt')
    result = json.loads((ROOT / 'comparison/results.json').read_text())
    spec = importlib.util.spec_from_file_location('second_counter', ROOT / 'comparison/source_measure.py')
    second = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(second)
    keys = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    for row in result['programs']:
        measured = second.metrics(ROOT / 'comparison' / row['local_file'])
        if any(row[k] != measured[k] for k in keys):
            raise ValueError('Independent baseline measurement disagrees: ' + row['label'])
    for row in result['candidates']:
        measured = second.metrics(ROOT / row['path'])
        if any(row[k] != measured[k] for k in keys):
            raise ValueError('Independent candidate measurement disagrees: ' + row['path'])
        if not all(row['strict_improvement'].values()):
            raise ValueError('Candidate does not beat every current coordinate: ' + row['path'])
    run(['validate.py'], 'regression_log.txt')
    (ROOT / 'results/validation_results.json').write_bytes((ROOT / 'validation_results.json').read_bytes())
    (ROOT / 'validation_results.json').unlink()
    run(['validation/audit_candidate.py', '.'], 'independent_audit_log.txt')
    (ROOT / 'results/independent_candidate_results.json').write_bytes(
        (ROOT / 'validation/independent_candidate_results.json').read_bytes())
    (ROOT / 'validation/independent_candidate_results.json').unlink()
    summary = {
        'status': 'PASS', 'comparison_commit': result['commit'],
        'independent_count_agreement': True,
        'current_envelope': result['coordinatewise_minimum'],
        'candidates': [{k: row[k] for k in ('path', *keys, 'sha256')} for row in result['candidates']],
        'validation': {k: v for k, v in json.loads((ROOT / 'results/validation_results.json').read_text()).items()
                       if k not in ('replay', 'rejections', 'cli')},
        'independent_audit_status': json.loads((ROOT / 'results/independent_candidate_results.json').read_text())['status'],
    }
    (ROOT / 'results/reproduction_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
