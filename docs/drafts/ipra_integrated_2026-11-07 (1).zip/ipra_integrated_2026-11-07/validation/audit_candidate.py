"""Independent focused audit of the delivered iPRA acceptance program.

Run: python validation/audit_candidate.py PACKAGE_DIRECTORY
The named-binder opening oracle and explicit syntax grammar do not use the
kernel's packed edge table. This file is outside the acceptance boundary.
"""
import copy
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile


def load(path):
    spec = importlib.util.spec_from_file_location('audit_target', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def kernel_inst(module, node, formula=True, depth=0, env=()):
    if 'formula' in inspect.signature(module.inst).parameters:
        return module.inst(node, env, depth, formula)
    return module.inst(node, env, 2 * depth + (not formula))


def grammar(node, formula=True, depth=0):
    if not formula and type(node) is int:
        return node <= depth
    if type(node) is not list:
        return False
    if formula:
        if len(node) == 1:
            return grammar(node[0], True, depth + 1)
        if len(node) == 2:
            return all(grammar(x, False, depth) for x in node)
        if len(node) == 3:
            return all(grammar(x, True, depth + 1) for x in node)
    else:
        if len(node) == 1:
            return grammar(node[0], False, depth)
        if len(node) == 3:
            return (grammar(node[0], False, depth)
                    and grammar(node[1], False, depth)
                    and grammar(node[2], False, depth + 2))
    return False


def negative_names(node):
    if type(node) is int:
        return [node] if node < 0 else []
    if type(node) is list:
        return [i for child in node for i in negative_names(child)]
    return []


def to_named(node, formula, bound, env, path):
    """Decode using explicit names; open free slots to closed named terms."""
    if not formula and type(node) is int:
        if node == 0:
            return ('zero',)
        if node < 0:
            return ('param', node)
        if node <= len(bound):
            return ('var', bound[node - 1])
        return env[node - len(bound) - 1]
    if formula:
        if len(node) == 2:
            return ('equal', *(to_named(x, False, bound, env, path + (i,))
                               for i, x in enumerate(node)))
        binder = ('binder', path)
        bodies = [to_named(x, True, [binder] + bound, env, path + (i,))
                  for i, x in enumerate(node)]
        return ('Q' if len(node) == 1 else 'E', binder, *bodies)
    if len(node) == 1:
        return ('S', to_named(node[0], False, bound, env, path + (0,)))
    previous = ('previous', path)
    counter = ('counter', path)
    return ('R', previous, counter,
            to_named(node[0], False, bound, env, path + (0,)),
            to_named(node[1], False, bound, env, path + (1,)),
            to_named(node[2], False, [previous, counter] + bound,
                     env, path + (2,)))


def from_named(node, bound):
    kind, *data = node
    if kind == 'zero':
        return 0
    if kind == 'param':
        return data[0]
    if kind == 'var':
        return bound.index(data[0]) + 1
    if kind in ('equal', 'S'):
        return [from_named(x, bound) for x in data]
    if kind in ('Q', 'E'):
        binder, *bodies = data
        return [from_named(x, [binder] + bound) for x in bodies]
    previous, counter, n, a, body = data
    return [from_named(n, bound), from_named(a, bound),
            from_named(body, [previous, counter] + bound)]


def named_open(node, formula, depth, env):
    bound = [('outer', i) for i in range(depth)]
    replacements = [to_named(t, False, [], [], ('env', i))
                    for i, t in enumerate(env)]
    return from_named(to_named(node, formula, bound, replacements, ('root',)), bound)


def random_term(rng, depth, height):
    choice = rng.randrange(3) if height else 0
    if choice == 0:
        return rng.choice([0, -1, -7, -1000] + list(range(1, depth + 1)))
    if choice == 1:
        return [random_term(rng, depth, height - 1)]
    return [random_term(rng, depth, height - 1),
            random_term(rng, depth, height - 1),
            random_term(rng, depth + 2, height - 1)]


def random_formula(rng, depth, height):
    choice = rng.randrange(3) if height else 0
    if choice == 0:
        return [random_term(rng, depth, 2), random_term(rng, depth, 2)]
    if choice == 1:
        return [random_formula(rng, depth + 1, height - 1)]
    return [random_formula(rng, depth + 1, height - 1) for _ in range(3)]


def erase(node, formula=True):
    """Decode arity syntax to the unchanged tagged reference language."""
    if not formula and type(node) is int:
        return node
    if formula:
        if len(node) == 1:
            return ['u', erase(node[0])]
        if len(node) == 2:
            return ['=', erase(node[0], False), erase(node[1], False)]
        return ['ex', erase(node[0])]
    if len(node) == 1:
        return ['s', erase(node[0], False)]
    return ['r', *(erase(x, False) for x in node)]


def erase_instruction(item):
    if type(item) is list and len(item) == 1:
        return [erase(item[0], False)]
    if type(item) is list and len(item) == 2:
        major, argument = item
        if len(major) == 1:
            argument = erase(argument, False)
        elif len(major) == 2:
            argument = erase(argument)
        else:
            argument = None
        return [erase(major), argument]
    return item


def accept(module, certificate):
    module.k = 0
    proof = copy.deepcopy(certificate)
    try:
        module.take = proof.pop
        return bool(module.check(module.take(), []))
    except Exception:
        return False


def reference_accept(module, certificate):
    module.k = 0
    proof = [erase_instruction(i) for i in certificate[:-1]]
    try:
        return bool(module.check(erase(certificate[-1]), proof, []))
    except Exception:
        return False


def reflexivity(term=0):
    equation = [[0, term, 0], term]
    return [[], [], [equation, [1, term]]]


def boundary_cases():
    eq = [0, 0]
    q = [eq]
    ex = [[1, 0], eq, eq]
    result = [
        ('reflexivity', [*reflexivity(), eq], True),
        ('recursion_zero', [[], [[0, -7, [1]], -7]], True),
        ('vacuous_Q', [None, [], q], True),
        ('existence', [*reflexivity(), [0], ex], True),
        ('false_padding_is_inert', [*reflexivity(), [0],
                                 [[1, 0], [0, [0]], [[0], 0]]], True),
        ('padding_names_scan', [None, [],
                               [[[1, 1], [-1000, -1000], eq]]], True),
        ('unread_prefix_is_inert', [{'invalid': True}, *reflexivity(), eq], True),
        ('false_equation', [None, [0, [0]]], False),
        ('boolean_term', [None, [False, 0]], False),
        ('free_positive_index', [None, [1, 1]], False),
        ('bad_ex_padding', [*reflexivity(), [0], [[1, 0], 0, eq]], False),
    ]
    for parameter in (-1, -7, -1000):
        result.append(('escaping_eigen_' + str(parameter),
                       [None, *reflexivity(), [0], [ex, None], [parameter, 0]], False))
    for witness in (None, True, 1, [], [0, 0], {'x': 0}):
        result.append(('strict_Q_witness_' + repr(witness),
                       [*reflexivity(), None, [], [q, witness], eq], False))
        result.append(('strict_E_witness_' + repr(witness),
                       [*reflexivity(), [witness], [eq, eq, eq]], False))
    return result


def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    target = load(root / 'checker.py')
    separate = load(root / 'checker_separate.py')
    reference = load(root / 'validation/reference_fresh.py')
    rng = random.Random(20261107)
    results = {
        'candidate_sha256': hashlib.sha256((root / 'checker.py').read_bytes()).hexdigest(),
        'separate_sha256': hashlib.sha256((root / 'checker_separate.py').read_bytes()).hexdigest(),
        'reference_sha256': hashlib.sha256((root / 'validation/reference_fresh.py').read_bytes()).hexdigest(),
    }
    # New packed sort/depth and arity coding: compare with explicit grammar.
    shapes = []
    for i in range(160):
        formula = bool(i % 2)
        depth = i % 4
        node = random_formula(rng, depth, 2) if formula else random_term(rng, depth, 3)
        shapes.append((node, formula, depth))
        pool = [None, True, False, {}, 'x', [], [0, 0, 0, 0], depth + 1]
        mutated = copy.deepcopy(node)
        if type(mutated) is list and mutated:
            mutated[rng.randrange(len(mutated))] = rng.choice(pool)
        else:
            mutated = rng.choice(pool)
        shapes.append((mutated, formula, depth))
    for node, formula, depth in shapes:
        expected = grammar(node, formula, depth)
        for module in (target, separate):
            module.k = 0
            try:
                actual_node = kernel_inst(module, node, formula, depth)
                actual = True
            except Exception:
                actual = False
            if actual != expected:
                raise AssertionError(('grammar', node, formula, depth, expected))
            if actual and (actual_node != node or module.k != min([0] + negative_names(node))):
                raise AssertionError(('identity or fresh-name scan', node))
    results['explicit_grammar_cases'] = len(shapes)
    # Named binders independently verify opening beneath Q/E and double-bound R.
    for i in range(240):
        formula = bool(i % 2)
        depth = i % 3
        count = i % 3
        env = [random_term(rng, 0, 2) for _ in range(count)]
        node = random_formula(rng, depth + count, 2) if formula else random_term(rng, depth + count, 3)
        expected = named_open(node, formula, depth, env)
        for module in (target, separate):
            module.k = 0
            for term in env:
                kernel_inst(module, term, False)
            actual = kernel_inst(module, node, formula, depth, env)
            if actual != expected:
                raise AssertionError(('named opening', node, env, actual, expected))
    results['named_opening_cases'] = 240
    # Reverse the delivered encoding and replay distinct public certificates in
    # the unmodified prior checker; this does not import the new encoder.
    files = sorted((root / 'examples').rglob('*.json'))
    unique = {}
    for path in files:
        data = json.loads(path.read_text())
        unique.setdefault(json.dumps(data, sort_keys=True), (path, data))
    for path, data in unique.values():
        if not accept(target, data) or not accept(separate, data) or not reference_accept(reference, data):
            raise AssertionError(('reverse reference replay', path))
    results['public_certificate_files'] = len(files)
    results['distinct_public_certificates_replayed'] = len(unique)
    cases = boundary_cases()
    for label, certificate, expected in cases:
        for module in (target, separate):
            if accept(module, certificate) != expected:
                raise AssertionError(('boundary', label, certificate, expected))
            if label == 'padding_names_scan' and module.k >= -1000:
                raise AssertionError(('fresh allocation missed padding names', module.k))
    results['boundary_cases'] = [{'name': n, 'expected': e} for n, _, e in cases]
    # Public interfaces in normal and optimized mode; no assert-based gates.
    cli = []
    chosen = cases[:3] + [cases[4], cases[7], cases[8], cases[11], cases[14]]
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / 'case.json'
        for label, certificate, expected in chosen:
            path.write_text(json.dumps(certificate))
            for options in ([], ['-O']):
                process = subprocess.run([sys.executable, *options, str(root / 'checker.py'), str(path)], capture_output=True, text=True)
                if ((process.returncode == 0) != expected
                        or process.stdout != ('ACCEPT\n' if expected else 'REJECT\n')):
                    raise AssertionError(('CLI', label, options, process.returncode, process.stdout))
                cli.append({'name': label, 'optimized': bool(options), 'expected': expected})
    results['cli_runs'] = cli
    results['status'] = 'PASS'
    output = root / 'validation/independent_candidate_results.json'
    output.write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
