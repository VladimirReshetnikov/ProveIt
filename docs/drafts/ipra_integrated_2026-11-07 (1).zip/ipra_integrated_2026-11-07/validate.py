"""Offline regression and syntax-translation checks (outside the trusted kernel).

The tagged, locally nameless source certificates and source checker are copied
from the pinned fresh-parameters draft. The new theorem checker imports neither.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def load(path):
    spec = importlib.util.spec_from_file_location('kernel', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def syntax(a, formula=True):
    if not formula and type(a) is int:
        return a
    tag, *xs = a
    widths = ({'=':(0,0), 'u':(1,), 'q':(1,), 'ex':(1,)} if formula
              else {'s':(0,), 'r':(0,0,2)})[tag]
    result = [syntax(x,w == 1) for x,w in zip(xs,widths,strict=True)]
    return result + [[0,0],[0,0]] if tag == 'ex' else result

def instruction(item):
    if type(item) is list:
        if len(item) == 1:
            return [syntax(item[0],False)]
        if len(item) == 2:
            major, argument = item
            arg = syntax(argument) if major[0] == '=' else syntax(argument,False) if major[0] in ('u','q') else None
            return [syntax(major),arg]
    return item

def encode(data):
    goal, proof, *context = data
    return [*[instruction(item) for item in proof], syntax(goal)], [syntax(h) for h in context]

def accepted(module, certificate, context=()):
    module.k = 0
    proof = copy.deepcopy(certificate)
    module.take = proof.pop
    try:
        for h in context:
            module.inst(h)
        return bool(module.check(module.take(),list(context)))
    except Exception:
        return False

def source_accepted(module, data):
    module.k=0
    a,p,*context=copy.deepcopy(data)
    try:
        for h in context:module.inst(h)
        return bool(module.check(a,p,context))
    except Exception:
        return False

def main():
    module = load(ROOT/'checker.py')
    reference = load(ROOT/'validation/reference_fresh.py')
    source = json.loads((ROOT/'validation/source_cases.json').read_text())
    replay = []
    for case in source['cases']:
        if not source_accepted(reference,case['certificate']):
            raise ValueError(('pinned source case rejected',case['source']))
        data, context=encode(case['certificate'])
        out = ROOT/'examples'/Path(case['source']).relative_to('examples/strict')
        if not context:
            out.parent.mkdir(parents=True,exist_ok=True)
            out.write_text(json.dumps(data,separators=(',',':'))+'\n')
        ok=accepted(module,data,context)
        replay.append({'source':case['source'], 'target':str(out.relative_to(ROOT)) if not context else None,
                       'accepted':ok, 'open_context':bool(context)})
        if not ok: raise ValueError(('translated certificate rejected',case['source']))
    rejection = []
    # Closed false equations are neither computation axioms nor assumptions.
    for false in ([0,[0]], [[0],0], [0,[[0]]], [[-1],-1]):
        for item in (None,[],[0], [None], 0, False, {}, 'junk'):
            certificate=[item,false]
            ok=not accepted(module,certificate)
            rejection.append({'case':'false equation','certificate':certificate,'rejected':ok})
            if not ok: raise ValueError(('false accepted',certificate))
    # Reject out-of-scope indices, sort errors, constructor arities, booleans.
    malformed=[True,False,0,-1,[],[0],[[0]], [0,True], [0,1], [0,-2,0],
               [0,[0,0]], [0,[0,0,0,0]], {'x':0}, [0,{}], [0,'0'],
               [[[0,0],0,0],0], [[0,0,3],0], [[0,0,True],0]]
    for a in malformed:
        ok=not accepted(module,[None,a])
        rejection.append({'case':'malformed goal','certificate':[None,a],'rejected':ok})
        if not ok: raise ValueError(('malformed accepted',a))
    for cert in ([], [[1,1]], [None,[1,1]], [[],[0,0]], [None,[0,0]]):
        ok=not accepted(module,cert)
        rejection.append({'case':'unsupported leaf','certificate':cert,'rejected':ok})
        if not ok: raise ValueError(('bad leaf accepted',cert))
    # Strict opening rejects a malformed witness even when the matrix is vacuous.
    trivial = [0,0]
    existential = [trivial,trivial,trivial]
    refl = [[],[],[[[0,0,0],0],[1,0]]]
    for witness in ([],[0,0],True,1,{},'term'):
        cert=[*refl,[witness],existential]
        ok=not accepted(module,cert)
        rejection.append({'case':'malformed existential witness','certificate':cert,'rejected':ok})
        if not ok:raise ValueError(('malformed witness accepted',cert))
    # Existential inert fields cannot be used as assumptions.
    # Under E_x(T,T,F), elimination to F must fail after a valid major proof.
    false=[0,[0]]
    unusual=[trivial,trivial,false]
    cert=[None,*refl,[0],[unusual,None],false]
    ok=not accepted(module,cert)
    rejection.append({'case':'existential padding not an assumption','certificate':cert,'rejected':ok})
    if not ok:raise ValueError('padding imported as hypothesis')
    cli=[]
    for row in [r for r in replay if not r['open_context']][:6]:
        run=subprocess.run([sys.executable,str(ROOT/'checker.py'),str(ROOT/row['target'])],capture_output=True,text=True)
        cli.append({'target':row['target'],'exit':run.returncode,'stdout':run.stdout.strip()})
        if run.returncode or run.stdout!='ACCEPT\n':raise ValueError(cli[-1])
    result={'translated_positive_certificates':len(replay),
            'closed_positive_certificates':sum(not r['open_context'] for r in replay),
            'open_positive_certificates':sum(r['open_context'] for r in replay),
            'unique_source_certificates':len({json.dumps(c['certificate'],sort_keys=True) for c in source['cases']}),
            'unique_closed_target_certificates':len({(ROOT/r['target']).read_bytes() for r in replay if not r['open_context']}),
            'rejection_cases':len(rejection),'cli_runs':len(cli),'replay':replay,'rejections':rejection,'cli':cli}
    (ROOT/'validation_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('replay','rejections','cli')},indent=2))

if __name__=='__main__':main()
