"""Measure all nine unmodified current checkers and optional new candidates.

The primary boundary is the entire acceptance program, including imports,
input, syntax, inference, error handling and verdict. Comments and genuine
docstrings are omitted uniformly. Identifier spelling is retained.
Run from any directory: python comparison/measure.py checker.py.
"""
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def tree_measures(tree):
    text = ast.unparse(tree) + '\n'
    return {
        'normalized_tokens': sum(t.type not in IGNORED for t in
            tokenize.generate_tokens(io.StringIO(text).readline)),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(text.encode('utf-8')),
    }


def measure(path):
    raw = Path(path).read_bytes()
    tree = StripDocstrings().visit(ast.parse(raw.decode('utf-8')))
    result = {**tree_measures(tree),
              'sha256': hashlib.sha256(raw).hexdigest()}
    core = copy.deepcopy(tree)
    core.body = [n for n in core.body
                 if not isinstance(n, (ast.Import, ast.ImportFrom))
                 and not (isinstance(n, ast.If)
                          and '__name__' in ast.unparse(n.test))]
    result['core'] = tree_measures(core)
    return result


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    rows = []
    for item in manifest['programs']:
        row = measure(ROOT / item['local_file'])
        if row['sha256'] != item['sha256']:
            raise ValueError('Comparator hash mismatch: ' + item['local_file'])
        rows.append({**item, **row})
    minimum = {k: min(r[k] for r in rows) for k in FIELDS}
    core_minimum = {k: min(r['core'][k] for r in rows) for k in FIELDS}
    strict = [r for r in rows if r['archive_member'].endswith('/checker.py')]
    candidates = [{'path': str(Path(p)), **measure(p)} for p in sys.argv[1:]]
    for row in candidates:
        row['strict_improvement'] = {k: row[k] < minimum[k] for k in FIELDS}
        row['core_strict_improvement'] = {
            k: row['core'][k] < core_minimum[k] for k in FIELDS}
    result = {
        'commit': manifest['commit'],
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'archive_count': len(manifest['archives']),
        'program_count': len(rows),
        'coordinatewise_minimum': minimum,
        'strict_coordinatewise_minimum': {
            k: min(r[k] for r in strict) for k in FIELDS},
        'core_coordinatewise_minimum': core_minimum,
        'minimum_attainers': {
            k: [r['label'] for r in rows if r[k] == minimum[k]] for k in FIELDS},
        'programs': rows,
        'candidates': candidates,
    }
    (ROOT / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
