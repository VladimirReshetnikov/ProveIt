"""Rebuild a clean ZIP with reproducible member metadata and a file manifest."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
OMIT = {'.aux', '.log', '.out', '.toc', '.fls', '.fdb_latexmk', '.synctex.gz', '.pyc'}


def deliver(path):
    return (path.is_file() and '__pycache__' not in path.parts
            and path.suffix not in OMIT and path.name != 'MANIFEST.sha256')


paths = sorted(p for p in ROOT.rglob('*') if deliver(p))
manifest = ROOT / 'MANIFEST.sha256'
manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                            + p.relative_to(ROOT).as_posix() + '\n' for p in paths))
archive = ROOT.parent / (ROOT.name + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for path in [*paths, manifest]:
        info = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                               date_time=(2026, 11, 7, 12, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        stream.writestr(info, path.read_bytes())
print(archive)
print('Archive SHA-256:', hashlib.sha256(archive.read_bytes()).hexdigest())
print('Files:', len(paths) + 1)
