"""Compile the complete report; requires a normal pdfLaTeX installation."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
for _ in range(3):
    result = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
                            cwd=ROOT, capture_output=True, text=True)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
print('Built report.pdf')
