#!/usr/bin/env python3
"""Rebuild and check the PRA witnessed-constancy research package."""

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / "verification"


def run_checked(command, log_name):
    result = subprocess.run(
        command, cwd=ROOT, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
    )
    (VERIFY / log_name).write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-5000:])
        raise SystemExit(result.returncode)
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to a Lean 4 executable.")
    parser.add_argument("--skip-pdf", action="store_true")
    args = parser.parse_args()
    VERIFY.mkdir(exist_ok=True)

    for script in ("check_schema.py", "check_arithmetic.py"):
        run_checked(
            [sys.executable, str(ROOT / "checks" / script)],
            script.replace(".py", ".txt"),
        )
        print(script + ": passed")

    lean = args.lean or shutil.which("lean")
    if lean:
        version = subprocess.check_output(
            [lean, "--version"], cwd=ROOT, text=True
        )
        output = run_checked(
            [lean, str(ROOT / "formal" / "RecursorWitnessKernel.lean")],
            "lean_current_run.txt",
        )
        if "sorryAx" in output:
            raise SystemExit("Unexpected sorryAx dependency in Lean output.")
        (VERIFY / "lean_current_run.txt").write_text(
            version + "\n" + output + "\nExit code: 0\n"
        )
        print("Lean kernel: passed")
    else:
        print("Lean unavailable: skipped; supplied original check log retained.")

    if not args.skip_pdf:
        latex = shutil.which("pdflatex")
        if not latex:
            raise SystemExit("pdflatex is required to rebuild the PDF.")
        command = [latex, "-interaction=nonstopmode", "-halt-on-error",
                   "report.tex"]
        for pass_number in range(1, 4):
            run_checked(command, "latex_pass_" + str(pass_number) + ".txt")
        final_log = (ROOT / "report.log").read_text()
        bad = ["Overfull", "undefined references", "undefined on input",
               "Label(s) may have changed"]
        if any(message in final_log for message in bad):
            raise SystemExit("LaTeX needs review; see report.log.")
        print("PDF: built; references resolved; no overfull boxes.")

    schema = json.loads((VERIFY / "schema_audit.json").read_text())
    print("Audited formula trees:", schema["formula_trees_checked"])


if __name__ == "__main__":
    main()
