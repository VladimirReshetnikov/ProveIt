import Std

/-
  Kernel for a recursor-restricted classical witness presentation of PRA.
  The carrier is arbitrary. No natural-number induction is used.
  This checks the witness/constancy equivalence and the latch step that
  recovers induction for one fixed predicate from one selected recursor.
  Descriptor syntax, the finite truth compiler, pairing, and the complete
  bi-interpretability theorem are not formalized by this file.
-/

namespace PRARecursorWitness

universe u
variable {A : Type u}

theorem predecessor_bootstrap
    {zero : A} {succ pred : A → A}
    (separation : zero ≠ succ zero)
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ a, pred (succ a) = a) :
    (∀ a b, succ a = succ b → a = b) ∧ ∀ a, succ a ≠ zero := by
  constructor
  · intro a b hab
    have hp := congrArg pred hab
    simpa only [pred_succ] using hp
  · intro a ha
    have haz : a = zero := by
      have hp := congrArg pred ha
      simpa only [pred_succ, pred_zero] using hp
    exact separation (haz ▸ ha).symm

theorem equality_bit_reflection
    {zero one : A} {eqBit : A → A → A}
    (separation : zero ≠ one)
    (bit : ∀ x y, eqBit x x = zero ∧ (x = y ∨ eqBit x y = one))
    (x y : A) :
    (eqBit x y = zero ↔ x = y) ∧
      (eqBit x y = zero ∨ eqBit x y = one) := by
  obtain ⟨hdiag, hoff⟩ := bit x y
  constructor
  · constructor
    · intro hz
      rcases hoff with heq | hone
      · exact heq
      · exact False.elim (separation (hz.symm.trans hone))
    · intro heq
      simpa only [← heq] using hdiag
  · rcases hoff with heq | hone
    · exact Or.inl (heq ▸ hdiag)
    · exact Or.inr hone

theorem equality_bit_ne
    {zero one : A} {eqBit : A → A → A}
    (bit : ∀ x y, eqBit x x = zero ∧ (x = y ∨ eqBit x y = one))
    (x y : A) (hne : x ≠ y) : eqBit x y = one := by
  rcases (bit x y).2 with heq | hone
  · exact False.elim (hne heq)
  · exact hone

def selector (zero : A) (succ : A → A) (Q Z : A → A → A)
    (r b c : A) : A :=
  Q (Z r (succ b)) (Z (Z r (succ zero)) c)

theorem selector_rules
    {zero : A} {succ : A → A} {Q Z : A → A → A}
    (qzero : ∀ a, Q zero a = a)
    (qstep : ∀ n a, Q (succ n) a = n)
    (zzero : ∀ a, Z zero a = a)
    (zstep : ∀ n a, Z (succ n) a = zero)
    (r b c : A) :
    selector zero succ Q Z zero b c = b ∧
      selector zero succ Q Z (succ r) b c = c := by
  constructor
  · simp only [selector, zzero, zstep, qstep]
  · simp only [selector, zstep, zzero, qzero]

/-- A single witness either identifies a change or gives the common value. -/
def witnessProperty (succ : A → A) (f : A → A) : Prop :=
  ∃ b, ∀ n, f (succ b) = f b → f n = b

theorem witness_iff_constancy (zero : A) (succ : A → A) (f : A → A) :
    witnessProperty succ f ↔
      ((∀ n, f (succ n) = f n) → ∀ n, f n = f zero) := by
  classical
  constructor
  · rintro ⟨b, hb⟩ hstationary n
    exact (hb n (hstationary b)).trans (hb zero (hstationary b)).symm
  · intro hconst
    by_cases hs : ∀ n, f (succ n) = f n
    · refine ⟨f zero, ?_⟩
      intro n _
      exact hconst hs n
    · have hn : ∃ b, f (succ b) ≠ f b := by
        apply Classical.byContradiction
        intro hn
        apply hs
        intro n
        apply Classical.byContradiction
        intro hne
        exact hn ⟨n, hne⟩
      obtain ⟨b, hb⟩ := hn
      exact ⟨b, fun _ he => False.elim (hb he)⟩

noncomputable def latch (zero : A) (pred : A → A) (P : A → A → Prop)
    (v n : A) : A := by
  classical
  exact if P n (pred v) then v else zero

/-- Observe a recursor after its current step; no new recursor is introduced. -/
def probe (eqBit : A → A → A) (succ : A → A)
    (R : A → A → A) (n seed : A) : A :=
  eqBit (R (succ n) seed) seed

theorem latch_eq_mark
    {zero : A} {succ pred : A → A} {P : A → A → Prop}
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (a v n : A) :
    latch zero pred P v n = succ a ↔ v = succ a ∧ P n a := by
  classical
  unfold latch
  by_cases hp : P n (pred v)
  · simp only [if_pos hp]
    constructor
    · intro hv
      refine ⟨hv, ?_⟩
      have hpred : pred v = a := by rw [hv, pred_succ]
      simpa only [hpred] using hp
    · exact fun h => h.1
  · simp only [if_neg hp]
    constructor
    · intro hz
      exact False.elim (succ_ne_zero a hz.symm)
    · intro h
      have hpred : pred v = a := by rw [h.1, pred_succ]
      have hp' : P n (pred v) := by simpa only [hpred] using h.2
      exact False.elim (hp hp')

theorem recursion_eq_mark
    {zero : A} {succ pred : A → A} {P : A → A → Prop}
    {R : A → A → A}
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (step : ∀ n a, R (succ n) a = latch zero pred P (R n a) n)
    (n a : A) :
    R (succ n) (succ a) = succ a ↔
      R n (succ a) = succ a ∧ P n a := by
  rw [step n (succ a)]
  exact latch_eq_mark succ_ne_zero pred_succ a (R n (succ a)) n

theorem marked_successors_iff
    {zero : A} {succ pred : A → A} {P : A → A → Prop}
    {R : A → A → A}
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (step : ∀ n a, R (succ n) a = latch zero pred P (R n a) n)
    (a : A) (progress : ∀ n, P n a → P (succ n) a) (n : A) :
    R (succ (succ n)) (succ a) = succ a ↔
      R (succ n) (succ a) = succ a := by
  constructor
  · intro h
    exact ((recursion_eq_mark succ_ne_zero pred_succ step (succ n) a).mp h).1
  · intro h
    have hp : P n a :=
      ((recursion_eq_mark succ_ne_zero pred_succ step n a).mp h).2
    exact (recursion_eq_mark succ_ne_zero pred_succ step (succ n) a).mpr
      ⟨h, progress n hp⟩

theorem probe_stationary
    {zero one : A} {succ pred : A → A} {P : A → A → Prop}
    {R eqBit : A → A → A}
    (bit_ne : ∀ x y, x ≠ y → eqBit x y = one)
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (step : ∀ n a, R (succ n) a = latch zero pred P (R n a) n)
    (a : A) (progress : ∀ n, P n a → P (succ n) a) (n : A) :
    probe eqBit succ R (succ n) (succ a) = probe eqBit succ R n (succ a) := by
  classical
  have hm := marked_successors_iff succ_ne_zero pred_succ step a progress n
  unfold probe
  by_cases h : R (succ n) (succ a) = succ a
  · have hs : R (succ (succ n)) (succ a) = succ a := hm.mpr h
    rw [h, hs]
  · have hs : R (succ (succ n)) (succ a) ≠ succ a := fun h' => h (hm.mp h')
    rw [bit_ne _ _ h, bit_ne _ _ hs]

/-- One axiom instance, for the selected latch, implies local induction. -/
theorem induction_from_recursor_witness
    {zero one : A} {succ pred : A → A} {P : A → A → Prop}
    {R eqBit : A → A → A}
    (separation : zero ≠ one)
    (bit_refl : ∀ x, eqBit x x = zero)
    (bit_ne : ∀ x y, x ≠ y → eqBit x y = one)
    (succ_ne_zero : ∀ a, succ a ≠ zero)
    (pred_succ : ∀ a, pred (succ a) = a)
    (base : ∀ a, R zero a = a)
    (step : ∀ n a, R (succ n) a = latch zero pred P (R n a) n)
    (witness : ∀ seed, witnessProperty succ (fun n => probe eqBit succ R n seed))
    (a : A) (initial : P zero a)
    (progress : ∀ n, P n a → P (succ n) a) (n : A) : P n a := by
  classical
  have hfirst : R (succ zero) (succ a) = succ a :=
    (recursion_eq_mark succ_ne_zero pred_succ step zero a).mpr
      ⟨base (succ a), initial⟩
  have hprobe0 : probe eqBit succ R zero (succ a) = zero := by
    unfold probe
    rw [hfirst, bit_refl]
  have hs : ∀ k,
      probe eqBit succ R (succ k) (succ a) = probe eqBit succ R k (succ a) :=
    probe_stationary bit_ne succ_ne_zero pred_succ step a progress
  obtain ⟨b, hb⟩ := witness (succ a)
  have hprobe : probe eqBit succ R n (succ a) = zero :=
    ((hb n (hs b)).trans (hb zero (hs b)).symm).trans hprobe0
  by_cases hm : R (succ n) (succ a) = succ a
  · exact ((recursion_eq_mark succ_ne_zero pred_succ step n a).mp hm).2
  · have honezero : one = zero := by
      unfold probe at hprobe
      rw [bit_ne _ _ hm] at hprobe
      exact hprobe
    exact False.elim (separation honezero.symm)

#print axioms predecessor_bootstrap
#print axioms equality_bit_reflection
#print axioms equality_bit_ne
#print axioms selector_rules
#print axioms witness_iff_constancy
#print axioms latch_eq_mark
#print axioms recursion_eq_mark
#print axioms marked_successors_iff
#print axioms probe_stationary
#print axioms induction_from_recursor_witness

end PRARecursorWitness
