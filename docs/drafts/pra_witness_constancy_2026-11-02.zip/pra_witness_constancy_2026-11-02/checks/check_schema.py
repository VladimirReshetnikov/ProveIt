#!/usr/bin/env python3
"""Independent AST checks for PRA constancy/probe candidate templates.

Finite syntax validation only; this does not prove bi-interpretability.
Frozen descriptors are excluded from active size and included recursively
at each occurrence in expanded size. No macros are counted as atomic terms.
"""
from dataclasses import dataclass
from pathlib import Path
import json
import random

@dataclass(frozen=True)
class Node:
    op: str
    xs: tuple = ()
    name: str = ''
    descriptor: object = None

def v(name): return Node('var', name=name)
def op(name, *xs): return Node(name, xs)
def forall(name, x): return Node('forall', (x,), name)
def exists(name, x): return Node('exists', (x,), name)
def rec(h, x, y): return Node('rec', (x,y), descriptor=h)
def s(x): return op('S', x)
def eq(x,y): return op('=',x,y)
def land(x,y): return op('and',x,y)
def lor(x,y): return op('or',x,y)
def imp(x,y): return op('implies',x,y)
def eps(x,y): return op('eps',x,y)
def conditional(x,y,yes,no): return op('if_eq',eq(x,y),yes,no)
z = op('0')
bottom = op('bottom')
n,a,b,k,st,ct = (v(x) for x in ('n','a','b','k','v','w'))
one=s(z)
sigma=imp(eq(z,one),bottom)

def subst(t, d):
    if t.op=='var': return d.get(t.name,t)
    assert t.op not in ('forall','exists')
    return Node(t.op,tuple(subst(x,d) for x in t.xs),t.name,t.descriptor)

size_cache={}
def size(t, expanded=False):
    key=(id(t),expanded)
    if key not in size_cache:
        value=(1+sum(size(x,expanded) for x in t.xs)
               +(size(t.descriptor,True) if expanded and t.descriptor else 0))
        size_cache[key]=(t,value)
    return size_cache[key][1]

def occ(t, name):
    return int(t.op=='var' and t.name==name)+sum(occ(x,name) for x in t.xs)

def fv(t):
    result=({t.name} if t.op=='var' else set()).union(*(fv(x) for x in t.xs))
    if t.op in ('forall','exists'): result.discard(t.name)
    return result

def quant(t, depth=0):
    q=int(t.op in ('forall','exists'))
    profiles=[quant(x,depth+q) for x in t.xs]
    return q+sum(p[0] for p in profiles),max([depth+q]+[p[1] for p in profiles])

def named_rec_count(t,h):
    return int(t.op=='rec' and t.descriptor==h)+sum(named_rec_count(x,h) for x in t.xs)

def body(u): return subst(u,{'n':st,'a':ct})

def B(u):
    h=body(u)
    rn=rec(h,n,a)
    return land(eq(rec(h,z,a),a),
                eq(rec(h,s(n),a),subst(u,{'n':rn,'a':n})))

def at(u,x): return subst(u,{'n':x})

def K_bit():
    return land(eq(eps(a,a),z),lor(eq(a,n),eq(eps(a,n),one)))

def seed():
    return forall('a',forall('n',land(B(z),land(sigma,K_bit()))))

def fixed_seed():
    return forall('a',forall('n',land(sigma,K_bit())))

def ordinary_constancy(u):
    H=forall('k',eq(at(u,s(k)),at(u,k)))
    return forall('a',forall('n',land(B(u),imp(H,eq(u,at(u,z))))))

def witness_constancy(u):
    test=eq(at(u,s(b)),at(u,b))
    return forall('a',exists('b',forall('n',land(B(u),imp(test,eq(u,b))))))

def conditional_witness(u):
    test=eq(at(u,s(b)),at(u,b))
    return forall('a',exists('b',forall('n',land(land(sigma,B(u)),imp(test,eq(u,b))))))

def probe(h,x): return eps(rec(h,s(x),a),a)

def witness_probe(u):
    h=body(u)
    test=eq(probe(h,s(b)),probe(h,b))
    return forall('a',exists('b',forall('n',land(B(u),imp(test,eq(probe(h,n),b))))))

def old_counter(u):
    present=lor(eq(n,z),eq(u,subst(u,{'a':s(a)})))
    after=eq(at(u,s(n)),subst(u,{'n':s(n),'a':s(a)}))
    H=forall('n',imp(present,after))
    return forall('a',forall('n',land(land(sigma,B(u)),imp(H,present))))

def zero_bit(u):
    if u==z:return seed()
    present=eq(u,z)
    H=forall('n',imp(present,eq(at(u,s(n)),z)))
    I=imp(land(eq(at(u,z),z),H),present)
    return forall('a',forall('n',land(B(u),I)))

def all_in_constancy(u):
    H=forall('k',eq(at(u,s(k)),at(u,k)))
    return forall('a',forall('n',land(land(sigma,B(u)),imp(H,eq(u,at(u,z))))))

def mask_fixed():
    return forall('a',forall('n',lor(eq(a,n),eq(op('Delta',a,n),z))))

def mask_schema(u):
    present=eq(op('Delta',n,u),n)
    after=eq(at(u,s(n)),s(n))
    H=forall('n',imp(present,after))
    return forall('a',forall('n',land(land(sigma,B(u)),imp(H,present))))

def pred(x):return rec(ct,x,z)
def diff(x,y):return rec(pred(st),y,x)
def unit_diagonal():return forall('n',eq(diff(s(n),n),one))

def four_occurrence(u,packaged=False):
    present=lor(eq(n,z),eq(u,n))
    H=forall('n',imp(present,eq(at(u,s(n)),s(n))))
    computation=B(u)
    if packaged:computation=land(sigma,land(eq(diff(s(n),n),one),computation))
    return forall('a',forall('n',land(computation,imp(H,present))))

def canonical(t):
    if t.op=='rec' and t.descriptor==ct and t.xs[0].op=='S':
        return canonical(t.xs[0].xs[0])
    return t

def zero_anchor(u):
    h=canonical(body(u))
    base=eq(rec(h,z,a),a)
    if occ(u,'a')==0:
        step=eq(rec(h,s(n),a),rec(h,n,subst(u,{'n':a,'a':z})))
        return forall('a',forall('n',land(sigma,land(base,step))))
    step=eq(rec(h,s(n),a),subst(u,{'n':rec(h,n,a),'a':n}))
    E=eq(u,subst(u,{'a':z}))
    present=lor(eq(n,z),E)
    after=eq(at(u,s(n)),subst(u,{'n':s(n),'a':z}))
    H=forall('n',imp(present,after))
    return forall('a',forall('n',land(land(sigma,land(base,step)),imp(H,present))))

def show(t):
    if t.op=='var':return t.name
    if t.op in ('0','bottom'):return t.op
    if t.op=='rec':return 'R{'+show(t.descriptor)+'}('+','.join(map(show,t.xs))+')'
    if t.op in ('forall','exists'):return t.op+' '+t.name+' ['+show(t.xs[0])+']'
    return t.op+'('+','.join(map(show,t.xs))+')'

def main():
    rng=random.Random(20261102)
    inputs=[z,n,a,s(n),s(a),eps(n,a),rec(ct,n,a),rec(eps(st,ct),n,a),
            conditional(n,a,z,s(z)),conditional(s(n),a,n,rec(ct,a,z))]
    def random_term(depth):
        if depth<=0 or rng.random()<.30:return rng.choice([z,n,a])
        kind=rng.randrange(4)
        if kind==0:return s(random_term(depth-1))
        if kind==1:return eps(random_term(depth-1),random_term(depth-1))
        if kind==3:return conditional(*(random_term(depth-1) for _ in range(4)))
        h=body(random_term(depth-1))
        return rec(h,random_term(depth-1),random_term(depth-1))
    inputs += [random_term(4) for _ in range(250)]
    rows=[]
    assert size(fixed_seed())==25 and size(fixed_seed(),True)==25
    assert size(mask_fixed())==11
    assert size(sigma)==6 and size(unit_diagonal())==8
    assert size(sigma,True)==6 and size(unit_diagonal(),True)==12
    for u in inputs:
        size_cache.clear()
        m,W,i,j=size(u),size(u,True),occ(u,'n'),occ(u,'a')
        templates={
            'old_counter':(old_counter(u),35+7*m+4*i+3*j,35+(9+i)*W+4*i+3*j,(3,3)),
            'ordinary_constancy':(ordinary_constancy(u),18+5*m+3*i,18+(7+i)*W+3*i,(3,3)),
            'all_in_constancy':(all_in_constancy(u),25+5*m+3*i,25+(7+i)*W+3*i,(3,3)),
            'witness_constancy':(witness_constancy(u),19+4*m+3*i,19+(6+i)*W+3*i,(3,3)),
            'conditional_witness':(conditional_witness(u),26+4*m+3*i,
                                    26+(6+i)*W+3*i,(3,3)),
            'witness_probe':(witness_probe(u),38+m+2*i,38+(6+i)*W+2*i,(3,3)),
            'zero_bit':(zero_bit(u),38 if u==z else 26+5*m+3*i,
                        40 if u==z else 26+(7+i)*W+3*i,(2,2) if u==z else (3,3)),
            'equality_mask':(mask_schema(u),35+4*m+3*i,
                             35+(6+i)*W+3*i,(3,3)),
            'four_factored':(four_occurrence(u),32+4*m+3*i,
                             32+(6+i)*W+3*i,(3,3)),
            'four_packaged':(four_occurrence(u,True),47+4*m+3*i,
                             51+(6+i)*W+3*i,(3,3)),
            'zero_anchor_main':(zero_anchor(u),22+m if j==0 else 35+7*m+4*i,
                                None,(2,2) if j==0 else (3,3)),
        }
        result={'input':show(u),'m':m,'W':W,'i':i,'j':j,'templates':{}}
        for name,(formula,active,expanded,q) in templates.items():
            assert not fv(formula),(name,fv(formula))
            assert size(formula)==active,(name,show(u),size(formula),active)
            if expanded is not None:
                assert size(formula,True)==expanded,(name,show(u),size(formula,True),expanded)
            assert quant(formula)==q,(name,quant(formula),q)
            result['templates'][name]={'active':active,'expanded':expanded,'quantifiers':q[0],'depth':q[1]}
        # Expanded descriptors reverse the apparent active-size ordering.
        assert size(witness_probe(u),True)-size(witness_constancy(u),True)==19-i
        if named_rec_count(u,body(u))==0:
            assert named_rec_count(witness_probe(u),body(u))==5+i
        assert (size(witness_probe(u))<=size(witness_constancy(u)))==(3*m+i>=19)
        assert size(all_in_constancy(u))-size(conditional_witness(u))==m-1
        assert size(all_in_constancy(u),True)-size(conditional_witness(u),True)==W-1
        rows.append(result)
    # Fixed ledgers count separate sentences separately, not an extra
    # conjunction collecting an arbitrarily selected finite family.
    for count in range(1,100):
        assert (11+35*count)-(25+19*count)==16*count-14>0
        assert (14+32*count)-(25+19*count)==13*count-11>0
        assert (18+32*count)-(25+19*count)==13*count-7>0
    assert size(sigma,True)+size(unit_diagonal(),True)==18
    E=eps(rec(ct,s(n),a),a)
    assert size(E)==6 and occ(E,'n')==1 and occ(E,'a')==2
    assert 3*size(E)+occ(E,'n')==19
    summary={'status':'passed','input_count':len(rows),'template_count':len(templates),
             'formula_trees_checked':len(templates)*len(rows),
             'scope':'Finite syntax only; no mathematical equivalence claim. Mixed-grammar inputs exercise abstract count identities; they do not assert that every comparator admits every test term.',
             'new_recursor_occurrences':{'raw_witness':'2+i','probe_witness':'5+i'},
             'expanded_probe_minus_expanded_raw':'19-i',
             'fixed_ledgers':{'bit_seed':25,'mask_offdiagonal':11,
                              'four_occurrence_separation':6,'four_occurrence_unit':8},
             'fully_expanded_fixed_ledgers':{'bit_seed':25,'mask_offdiagonal':11,
                                             'four_occurrence_total':18},
             'finite_ledger_saving_vs_mask':'16*N-14 (N>=1)',
             'finite_ledger_saving_vs_four_factored':'13*N-11 (N>=1)',
             'fully_expanded_finite_ledger_saving_vs_four_factored':'13*N-7 (N>=1)',
             'probe_wins_active_iff':'3*m+i >= 19 (equality means tie)',
             'probe_term_profile':{'m':6,'i':1,'j':2,'3m+i':19},
             'same_conditional_language_savings':{'active':'m-1','expanded':'W-1'},
             'examples':rows[:10]}
    destination=Path(__file__).resolve().parent.parent/'verification'/'schema_audit.json'
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({key:value for key,value in summary.items() if key!='examples'},indent=2))

if __name__=='__main__':main()
