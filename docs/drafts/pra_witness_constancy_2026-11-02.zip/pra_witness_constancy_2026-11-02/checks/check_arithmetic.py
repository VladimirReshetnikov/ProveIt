#!/usr/bin/env python3
"""Finite implementation checks for the paper's triangular pairing.

The universal theorems are proved in the paper. This script checks the
literal recurrences and projections on stated finite ranges; it is not
a formal verification of PRA or of the interpretation theorem.
"""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def eq_bit(x, y):
    return int(x != y)


def check():
    parameter_limit = 150
    max_sum = 2 * parameter_limit
    triangular = [0]
    for n in range(max_sum + 1):
        triangular.append(triangular[-1] + n + 1)

    max_code = triangular[max_sum] + parameter_limit
    counter = [0]
    for n in range(max_code):
        state = counter[-1]
        increment = eq_bit(eq_bit(n + 1, triangular[state + 1]), 1)
        counter.append(state + increment)

    block_cases = 0
    for b in range(max_sum):
        assert counter[triangular[b]] == b
        for j in range(b + 1):
            assert counter[triangular[b] + j] == b
            block_cases += 1

    pair_cases = 0
    codes = set()
    for x in range(parameter_limit + 1):
        for y in range(parameter_limit + 1):
            code = triangular[x + y] + y
            right = max(0, code - triangular[counter[code]])
            left = max(0, counter[code] - right)
            assert (left, right) == (x, y)
            assert code not in codes
            codes.add(code)
            pair_cases += 1

    result = {
        "status": "passed",
        "scope": "Finite recurrence and pairing checks only.",
        "pair_coordinate_range": [0, parameter_limit],
        "pair_cases": pair_cases,
        "block_cases": block_cases,
        "maximum_code_checked": max_code,
    }
    target = ROOT / "verification" / "arithmetic_audit.json"
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    check()
