WITNESSED CONSTANCY AND RETURN TESTS
Smaller presentations of classical primitive recursive arithmetic
November 2, 2026

Read report.pdf for the complete specification, proofs, and comparisons.

MAIN RESULT

In the equality-conditional language already used by the current constancy
draft, replace its constancy payload by

    exists b, forall n, u(S b,a) = u(b,a) -> u(n,a) = b.

The witness is either an index of an adjacent change or the common value.
The complete one-input schema retains separation and both counter-recursion
equations. Its active size is 26 + 4m + 3i instead of 25 + 5m + 3i, saving
m - 1. The saving remains M - 1 when stored descriptors are fully charged.
It uses three quantifiers of depth three, including an existential
quantifier, and three variable names.

The ordinary first-order realization uses the explicit 25-node Seed
sentence and a 19 + 4m + 3i recurring formula. The complete printed ledger
saves 16N - 14 nodes against the current equality-mask presentation on
every nonempty matched set of N common inputs. The report also supplies
a narrower return-test schema with size 38 + m + 2i and an optional
adaptive generator, with all descriptor and constructor costs disclosed.

All calibrated theories have a common conservative definitional extension
with classical first-order PRA. Both interpretations preserve the whole
carrier and equality, and both composites are internally the identity.
No absolute minimality or comprehensive historical novelty claim is made.

CONTENTS

report.tex, sections/*.tex       Complete LaTeX source
report.pdf                      Compiled research paper
formal/RecursorWitnessKernel.lean
                                Checked central arbitrary-carrier proof
checks/check_schema.py          AST counts and comparison audit
checks/check_arithmetic.py      Finite triangular pairing implementation checks
verification/*                 Recorded check results and build logs
source_manifest.json            Exact six input archives and immutable hashes
build.py                        Reproducible local checks and PDF build

REBUILD

From this directory:

    python3 build.py

With a specific Lean executable:

    python3 build.py --lean /absolute/path/to/lean

To run only the code checks:

    python3 build.py --skip-pdf

Requirements: Python 3.10 or newer, pdfLaTeX with the packages listed in
report.tex, and optionally Lean 4 with Std. The supplied kernel was checked
with Lean 4.19.0. No Mathlib dependency is required. Without Lean, build.py
explicitly reports that its check was skipped and preserves the original log.

VERIFICATION SCOPE

The Lean file proves the central logical and latch argument over an
arbitrary carrier, plus the stated bootstrap lemmas. It does not formalize
the staged syntax, formula compiler, pairing, full interpretation compiler,
or full bi-interpretability theorem. Those have complete written proofs in
the paper. Python checks validate finite implementation and syntax cases;
they are not proofs of universal mathematical correctness.

CLASSICAL SCOPE

The witness packing uses classical reasoning. No intuitionistic theorem
for this exact schema is asserted. There is no uniform computable selector
for the existential witness; the paper proves the obstruction. No Skolem
function selecting witnesses is added.

SOURCE SNAPSHOT

VladimirReshetnikov/ProveIt
d46d2b97cb3c4d4f3a0154fc5884ea42ffcd5966
docs/drafts

All six source ZIPs were retrieved at this commit and checked against their
Git blob hashes. The manifest also records SHA-256 hashes. Source archives
and toolchain binaries are not redistributed in this package.
