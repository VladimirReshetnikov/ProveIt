/-
Constructive kernel for the rooted-tail reduction of PRA presentations.

Lean 4.19.0; no imports, no classical reasoning, no axioms, no sorry.
Every theorem has explicitly selected first-order instance hypotheses.
The file does NOT postulate a schema over all set-theoretic functions.
See SCOPE.txt for the exact boundary of the formalization.
-/

namespace RootedTail

universe u
variable {A : Type u}

def Endpoint (s : A → A) (t : A → A → A) (n a : A) : Prop :=
  t n a = t n (s a)

def Root (o : A) (s : A → A) (t : A → A → A) (n a : A) : Prop :=
  n = o ∨ Endpoint s t n a

def Progress (o : A) (s : A → A) (t : A → A → A) (a : A) : Prop :=
  ∀ n, Root o s t n a → Endpoint s t (s n) a

/-- The previous displayed one-term sentence. The selected descriptor body is
    the literal zero section `fun v => t v o`. -/
def OldInstance (o : A) (s : A → A) (t d q : A → A → A) : Prop :=
  ∀ a, Progress o s t a → ∀ n,
    Root o s t n a ∧
    (o = s o → False) ∧
    d (q n o) a = a ∧
    d (s (s n)) a = t (d (s n) a) o

/-- The shortened tail shares the zero-root disjunction with Endpoint.
    Reset remains unconditional inside the implication's conclusion. -/
def NewInstance (o : A) (s : A → A) (t d q : A → A → A) : Prop :=
  ∀ a, Progress o s t a → ∀ n,
    (o = s o → False) ∧
    d (q n o) a = a ∧
    (n = o ∨
      (Endpoint s t n a ∧ d (s n) a = t (d n a) o))

/-- Reflexive progress for one explicitly selected parameter-independent term. -/
theorem independent_progress (o : A) (s h : A → A) (a : A) :
    Progress o s (fun n _ => h n) a := by
  intro n _
  rfl

/-- Extraction from the single selected instance with input `t(n,a) = h(n)`. -/
theorem extract_computation (o : A) (s h : A → A) (d q : A → A → A)
    (H : NewInstance o s (fun n _ => h n) d q) :
    (o ≠ s o) ∧
    (∀ n a, d (q n o) a = a) ∧
    (∀ n a, n = o ∨ d (s n) a = h (d n a)) := by
  have hc := H o (independent_progress o s h o) o
  refine ⟨hc.1, ?_, ?_⟩
  · intro n a
    exact (H a (independent_progress o s h a) n).2.1
  · intro n a
    rcases (H a (independent_progress o s h a) n).2.2 with hz | hr
    · exact Or.inl hz
    · exact Or.inr hr.2

/-- Adjacent-parameter propagation is a direct projection of the new sentence. -/
theorem extract_propagation (o : A) (s : A → A) (t d q : A → A → A)
    (H : NewInstance o s t d q) :
    ∀ a, Progress o s t a → ∀ n, Root o s t n a := by
  intro a hp n
  rcases (H a hp n).2.2 with hz | hr
  · exact Or.inl hz
  · exact Or.inr hr.1

/-- Rooted Tail for q = D_(constant one) already computes q(2,0). -/
theorem q_at_two (o : A) (s : A → A) (q : A → A → A)
    (sep : o ≠ s o)
    (qroot : ∀ n a, n = o ∨ q (s n) a = s o) :
    q (s (s o)) o = s o := by
  rcases qroot (s o) o with hz | ht
  · exact False.elim (sep hz.symm)
  · exact ht

theorem one_seed (o : A) (s : A → A) (d q : A → A → A)
    (reset : ∀ n a, d (q n o) a = a)
    (q2 : q (s (s o)) o = s o) :
    ∀ a, d (s o) a = a := by
  intro a
  simpa only [q2] using reset (s (s o)) a

theorem zero_seed (o : A) (s : A → A) (d q : A → A → A)
    (reset : ∀ n a, d (q n o) a = a)
    (q1 : q (s o) o = o) :
    ∀ a, d o a = a := by
  intro a
  simpa only [q1] using reset (s o) a

/-- The critical ordering: successor cannot be zero before predecessor,
    coverage, equality decidability, or induction have been recovered. -/
theorem successor_ne_zero (o : A) (s : A → A) (q : A → A → A)
    (sep : o ≠ s o)
    (q0 : q o o = o)
    (qroot : ∀ n a, n = o ∨ q (s n) a = s o) :
    ∀ x, s x ≠ o := by
  intro x hs
  rcases qroot x o with hx | ht
  · exact sep (hs.symm.trans (congrArg s hx))
  · have ht' : q o o = s o := by
      simpa only [hs] using ht
    exact sep (q0.symm.trans ht')

theorem recover_old_tail (o : A) (s h : A → A) (d : A → A → A)
    (snz : ∀ x, s x ≠ o)
    (rooted : ∀ n a, n = o ∨ d (s n) a = h (d n a)) :
    ∀ n a, d (s (s n)) a = h (d (s n) a) := by
  intro n a
  rcases rooted (s n) a with hz | ht
  · exact False.elim (snz n hz)
  · exact ht

/-- Two selected computational instances suffice for the complete bootstrap
    of one body h: its own independent input, and the constant-one input. -/
theorem bootstrap_selected_instances
    (o : A) (s h : A → A) (d q : A → A → A)
    (Hq : NewInstance o s (fun _ _ => s o) q q)
    (Hh : NewInstance o s (fun n _ => h n) d q) :
    (o ≠ s o) ∧
    (∀ a, d o a = a) ∧
    (∀ a, d (s o) a = a) ∧
    (∀ x, s x ≠ o) ∧
    (∀ n a, d (s (s n)) a = h (d (s n) a)) := by
  rcases extract_computation o s (fun _ => s o) q q Hq with
    ⟨sep, rq, tq⟩
  rcases extract_computation o s h d q Hh with ⟨_, rd, td⟩
  have q2 := q_at_two o s q sep tq
  have q1 : q (s o) o = o := one_seed o s q q rq q2 o
  have q0 : q o o = o := zero_seed o s q q rq q1 o
  have snz := successor_ne_zero o s q sep q0 tq
  exact ⟨sep, zero_seed o s d q rd q1, one_seed o s d q rd q2,
    snz, recover_old_tail o s h d snz td⟩

/-- The logical envelope new -> old once the selected old Tail is recovered. -/
theorem new_to_old_with_tail
    (o : A) (s : A → A) (t d q : A → A → A)
    (H : NewInstance o s t d q)
    (tail : ∀ n a, d (s (s n)) a = t (d (s n) a) o) :
    OldInstance o s t d q := by
  intro a hp n
  have hc := H a hp n
  exact ⟨extract_propagation o s t d q H a hp n,
    hc.1, hc.2.1, tail n a⟩

/-- The complete forward reduction for one arbitrary sentence uses exactly
    the indicated three input instances; no universal semantic schema occurs. -/
theorem recover_old_instance
    (o : A) (s : A → A) (t d q : A → A → A)
    (Hq : NewInstance o s (fun _ _ => s o) q q)
    (Hsection : NewInstance o s (fun n _ => t n o) d q)
    (Ht : NewInstance o s t d q) :
    OldInstance o s t d q := by
  have hb := bootstrap_selected_instances o s (fun v => t v o) d q Hq Hsection
  exact new_to_old_with_tail o s t d q Ht hb.2.2.2.2

/-- The reverse reduction explicitly assumes coverage, as proved in the old
    theory's arithmetic bootstrap. It needs no excluded-middle principle. -/
theorem old_to_new_with_coverage
    (o : A) (s : A → A) (t d q : A → A → A)
    (cov : ∀ n, n = o ∨ ∃ k, n = s k)
    (H : OldInstance o s t d q) :
    NewInstance o s t d q := by
  intro a hp n
  have hc := H a hp n
  refine ⟨hc.2.1, hc.2.2.1, ?_⟩
  rcases hc.1 with hz | he
  · exact Or.inl hz
  · rcases cov n with hz | ⟨k, hk⟩
    · exact Or.inl hz
    · refine Or.inr ⟨he, ?_⟩
      simpa only [hk] using (H a hp k).2.2.2

/- Optional strengthening: Reset may also be placed under the same zero root.
   It does not improve the displayed active-node count, so the report's core
   presentation keeps unconditional Reset and the shorter bootstrap above. -/

theorem zero_seed_from_rooted_reset
    (o : A) (s : A → A) (d q : A → A → A)
    (sep : o ≠ s o)
    (rd : ∀ n a, n = o ∨ d (q n o) a = a)
    (rq : ∀ n a, n = o ∨ q (q n o) a = a) :
    ∀ a, d o a = a := by
  let c := q (s o) o
  have dc : ∀ a, d c a = a := by
    intro a
    rcases rd (s o) a with hz | hr
    · exact False.elim (sep hz.symm)
    · exact hr
  have qc : q c o = o := by
    rcases rq (s o) o with hz | hr
    · exact False.elim (sep hz.symm)
    · exact hr
  intro a
  rcases rd c a with hc | hr
  · simpa only [hc] using dc a
  · simpa only [qc] using hr

theorem rooted_reset_recovers_computation
    (o : A) (s h : A → A) (d q : A → A → A)
    (sep : o ≠ s o)
    (rd : ∀ n a, n = o ∨ d (q n o) a = a)
    (rq : ∀ n a, n = o ∨ q (q n o) a = a)
    (tq : ∀ n a, n = o ∨ q (s n) a = s o)
    (td : ∀ n a, n = o ∨ d (s n) a = h (d n a)) :
    (∀ a, d o a = a) ∧
    (∀ a, d (s o) a = a) ∧
    (∀ x, s x ≠ o) ∧
    (∀ n a, d (s (s n)) a = h (d (s n) a)) := by
  have dz := zero_seed_from_rooted_reset o s d q sep rd rq
  have qz := zero_seed_from_rooted_reset o s q q sep rq rq
  have snz := successor_ne_zero o s q sep (qz o) tq
  have q2 := q_at_two o s q sep tq
  have done : ∀ a, d (s o) a = a := by
    intro a
    rcases rd (s (s o)) a with hz | hr
    · exact False.elim (snz (s o) hz)
    · simpa only [q2] using hr
  exact ⟨dz, done, snz, recover_old_tail o s h d snz td⟩

#print axioms independent_progress
#print axioms extract_computation
#print axioms extract_propagation
#print axioms q_at_two
#print axioms one_seed
#print axioms zero_seed
#print axioms successor_ne_zero
#print axioms recover_old_tail
#print axioms bootstrap_selected_instances
#print axioms new_to_old_with_tail
#print axioms recover_old_instance
#print axioms old_to_new_with_coverage
#print axioms zero_seed_from_rooted_reset
#print axioms rooted_reset_recovers_computation

end RootedTail
