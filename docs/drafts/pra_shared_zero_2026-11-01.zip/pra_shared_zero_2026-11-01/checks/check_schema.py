#!/usr/bin/env python3
"""Independent exact syntax accounting for rooted unshifted-tail PRA.

This implementation was written independently for the new report. It does
not import, copy, or run any earlier draft's checker. It constructs the fully
expanded old and new formula trees and compares those trees with symbolic
counts. It is a finite syntax diagnostic, not a proof of PRA equivalence.

Counting conventions:
  active_nodes: one node per variable, constant, application, atomic
    equality, connective, bottom, and quantifier. Binder labels cost zero.
    A D_h application's stored descriptor is not an active argument.
  expanded_nodes: additionally charge the complete descriptor at EVERY D_h
    occurrence, recursively including its stored dependencies.
  dictionary_storage: store each distinct finite descriptor text once,
    charging its active body tree; its dependencies have separate entries.
    Total shared-description size = active_nodes + dictionary_storage.

Substitution is simultaneous and changes active variable occurrences only.
Stored descriptor bodies are frozen. There are no semantic identifications
between descriptors which happen to compute the same numerical function.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import argparse
import hashlib
import json


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple['Term', ...] = ()
    name: str = ''
    body: 'Term | None' = None


def var(name): return Term('var', name=name)
def zero(): return Term('zero')
def succ(t): return Term('succ', (t,))
def delay(h, x, a): return Term('delay', (x, a), body=h)


def free_vars(t):
    if t.kind == 'var': return frozenset([t.name])
    return frozenset().union(*(free_vars(a) for a in t.args))


def subst(t, mapping):
    if t.kind == 'var': return mapping.get(t.name, t)
    # In particular, t.body is deliberately not recursively substituted.
    return Term(t.kind, tuple(subst(a, mapping) for a in t.args), t.name, t.body)


def active_nodes(t): return 1 + sum(active_nodes(a) for a in t.args)
def occurrences(t, name):
    return int(t.kind == 'var' and t.name == name) + sum(occurrences(a, name) for a in t.args)


def expanded_nodes(t):
    return (1 + sum(expanded_nodes(a) for a in t.args)
            + (expanded_nodes(t.body) if t.body is not None else 0))


def descriptors(t):
    out = set()
    if t.body is not None:
        out.add(t.body)
        out.update(descriptors(t.body))
    for arg in t.args: out.update(descriptors(arg))
    return out


def descriptor_rank(t):
    return max([descriptor_rank(a) for a in t.args]
               + ([1 + descriptor_rank(t.body)] if t.body is not None else [0]))


def valid_term(t):
    expected = {'var': 0, 'zero': 0, 'succ': 1, 'delay': 2}
    if t.kind not in expected or len(t.args) != expected[t.kind]: return False
    if t.kind == 'var' and not t.name: return False
    if t.kind == 'delay':
        if t.body is None or not valid_term(t.body) or not free_vars(t.body) <= {'v'}: return False
    elif t.body is not None: return False
    return all(valid_term(a) for a in t.args)


@dataclass(frozen=True)
class Formula:
    kind: str
    formulas: tuple['Formula', ...] = ()
    terms: tuple[Term, ...] = ()
    binder: str = ''


def eq(s, t): return Formula('eq', terms=(s, t))
def bot(): return Formula('bot')
def conj(p, q): return Formula('and', (p, q))
def disj(p, q): return Formula('or', (p, q))
def implies(p, q): return Formula('imp', (p, q))
def forall(v, p): return Formula('all', (p,), binder=v)


def formula_count(f, term_counter=active_nodes):
    return 1 + sum(term_counter(t) for t in f.terms) + sum(formula_count(p, term_counter) for p in f.formulas)


def formula_descriptors(f):
    out = set()
    for t in f.terms: out.update(descriptors(t))
    for p in f.formulas: out.update(formula_descriptors(p))
    return out


def quantifiers(f):
    return int(f.kind == 'all') + sum(quantifiers(p) for p in f.formulas)


def quantifier_depth(f):
    return int(f.kind == 'all') + max([quantifier_depth(p) for p in f.formulas] + [0])


def names(f):
    out = set([f.binder]) if f.binder else set()
    for t in f.terms: out.update(free_vars(t))
    for p in f.formulas: out.update(names(p))
    return out


def formula_free_vars(f):
    out = set()
    for t in f.terms: out.update(free_vars(t))
    for p in f.formulas: out.update(formula_free_vars(p))
    if f.binder: out.discard(f.binder)
    return out


def render(t):
    if t.kind == 'var': return t.name
    if t.kind == 'zero': return '0'
    if t.kind == 'succ': return 'S(' + render(t.args[0]) + ')'
    return 'D[' + render(t.body) + '](' + ','.join(render(a) for a in t.args) + ')'


def formula_render(f):
    if f.kind == 'eq': return '(' + render(f.terms[0]) + '=' + render(f.terms[1]) + ')'
    if f.kind == 'bot': return 'false'
    if f.kind == 'all': return '(forall ' + f.binder + ' ' + formula_render(f.formulas[0]) + ')'
    op = {'and': ' & ', 'or': ' | ', 'imp': ' -> '}[f.kind]
    return '(' + formula_render(f.formulas[0]) + op + formula_render(f.formulas[1]) + ')'


def make_schema(u, new):
    if not valid_term(u) or not free_vars(u) <= {'n', 'a'}:
        raise ValueError('Input must be a legal finite term with active variables among n,a')
    n, a, v, z = var('n'), var('a'), var('v'), zero()
    one = succ(z)
    h = subst(u, {'n': v, 'a': z})
    assert free_vars(h) <= {'v'}
    endpoint = eq(u, subst(u, {'a': succ(a)}))
    root = disj(eq(n, z), endpoint)
    next_endpoint = eq(subst(u, {'n': succ(n)}), subst(u, {'n': succ(n), 'a': succ(a)}))
    progress = forall('n', implies(root, next_endpoint))
    separation = implies(eq(z, one), bot())
    reset = eq(delay(h, delay(one, n, z), a), a)
    if new:
        inner = delay(h, n, a)
        tail = eq(delay(h, succ(n), a), subst(h, {'v': inner}))
        payload = conj(separation, conj(reset, disj(eq(n, z), conj(endpoint, tail))))
    else:
        inner = delay(h, succ(n), a)
        tail = eq(delay(h, succ(succ(n)), a), subst(h, {'v': inner}))
        payload = conj(root, conj(separation, conj(reset, tail)))
    return forall('a', implies(progress, forall('n', payload)))


def check(u, label=None):
    old, new = make_schema(u, False), make_schema(u, True)
    U, N, A = active_nodes(u), occurrences(u, 'n'), occurrences(u, 'a')
    old_count, new_count = formula_count(old), formula_count(new)
    assert old_count == 38 + 7*U + 5*N + 3*A
    assert new_count == 37 + 7*U + 4*N + 3*A
    assert old_count - new_count == 1 + N
    old_expanded = formula_count(old, expanded_nodes)
    new_expanded = formula_count(new, expanded_nodes)
    assert old_expanded - new_expanded == 1 + N
    old_desc, new_desc = formula_descriptors(old), formula_descriptors(new)
    assert old_desc == new_desc
    storage = sum(active_nodes(h) for h in old_desc)
    for f in (old, new):
        assert quantifiers(f) == 3
        assert quantifier_depth(f) == 2
        assert names(f) == {'n', 'a'}
        assert not formula_free_vars(f)
    return {
        'label': label or render(u), 'term': render(u),
        'active_input_nodes': U, 'active_n_occurrences': N, 'active_a_occurrences': A,
        'descriptor_rank': descriptor_rank(u),
        'old_active_nodes': old_count, 'new_active_nodes': new_count,
        'saving': old_count-new_count,
        'old_expanded_descriptor_nodes': old_expanded,
        'new_expanded_descriptor_nodes': new_expanded,
        'distinct_stored_descriptors': len(old_desc),
        'shared_descriptor_storage_nodes': storage,
        'old_shared_description_nodes': old_count + storage,
        'new_shared_description_nodes': new_count + storage,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('results.json'))
    args = parser.parse_args()
    n, a, v, z = var('n'), var('a'), var('v'), zero()
    # Legal descriptor placeholders are only v, even when nested.
    h_nested = delay(succ(v), v, z)
    h_deeper = delay(h_nested, succ(v), v)
    examples = [
        ('n', n), ('a', a), ('Sn', succ(n)), ('Sa', succ(a)),
        ('0', z), ('one', succ(z)),
        ('duplicated n', delay(succ(v), n, n)),
        ('duplicated n and a', delay(h_nested, delay(succ(v), n, a), delay(z, n, a))),
        ('nested frozen descriptors', delay(h_deeper, n, a)),
        ('nested constant with active argument n', delay(delay(z, v, z), n, z)),
    ]
    rows = [check(t, label) for label, t in examples]
    # A deterministic corpus includes variables, constants, successors,
    # D applications, repeated arguments, and nested descriptor syntax.
    bodies = [z, v, succ(z), succ(v), h_nested, h_deeper]
    atoms = [z, n, a, succ(n), succ(a), succ(z)]
    corpus = list(atoms)
    corpus += [delay(h, x, y) for h in bodies for x in atoms for y in atoms]
    corpus += [succ(t) for t in corpus]
    corpus += [delay(h_deeper, t, t) for t in corpus[:64]]
    corpus = list(dict.fromkeys(corpus))
    for t in corpus: check(t)
    # Positive frozen-substitution controls: descriptors whose own v slots
    # occur several times must remain unchanged even when v is mapped.
    frozen = delay(h_deeper, v, n)
    moved = subst(frozen, {'v': succ(z), 'n': a})
    assert moved.body is frozen.body
    assert moved.args == (succ(z), a)
    assert free_vars(frozen) == {'v', 'n'}
    assert occurrences(frozen, 'v') == 1
    # Simultaneous substitution: inserted terms are not substituted again.
    assert subst(n, {'n': a, 'a': z}) == a
    # A section does not touch existing descriptors.
    t = delay(h_deeper, n, a)
    section = subst(t, {'n': v, 'a': z})
    assert section.body is h_deeper
    assert section.args == (v, z)
    # Negative controls reject illicit active input variables and illicit
    # stored-body parameters, separately.
    rejected = 0
    for bad in [var('b'), delay(var('a'), n, a), Term('succ', (n, a))]:
        try: make_schema(bad, True)
        except ValueError: rejected += 1
        else: raise AssertionError('Malformed input accepted')
    result = {
        'status': 'passed',
        'scope': 'Exact finite syntax diagnostics; not a formal proof of bi-interpretability.',
        'implementation': 'Independent immutable AST implementation; no prior checker imported or copied.',
        'formulas': {
            'old_active_nodes': '38 + 7*U + 5*N + 3*A',
            'new_active_nodes': '37 + 7*U + 4*N + 3*A',
            'saving_all_three_encodings': '1 + N',
        },
        'count_conventions': {
            'active': 'One node per variable, constant, function application, equality, connective, bottom, quantifier; stored bodies excluded.',
            'expanded_descriptors': 'Recursively charge stored body at every D occurrence.',
            'shared_dictionary': 'Each distinct finite descriptor body stored once, charging active nodes; dependencies have separate entries.',
        },
        'examples': rows,
        'generated_distinct_inputs_checked': len(corpus),
        'invalid_inputs_rejected': rejected,
        'frozen_substitution_checks': 'passed',
        'simultaneous_substitution_check': 'passed',
        'descriptor_dictionary_equality_for_every_pair': True,
        'quantifier_count_every_formula': 3,
        'maximum_quantifier_depth_every_formula': 2,
        'active_names_every_formula': ['a', 'n'],
        'all_formulas_closed': True,
        'checker_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k:result[k] for k in ['status','generated_distinct_inputs_checked','invalid_inputs_rejected','checker_sha256']}))
    for r in rows:
        print(f"{r['label']}: old={r['old_active_nodes']}, new={r['new_active_nodes']}, saving={r['saving']}")


if __name__ == '__main__':
    main()
