PRA WITH A SHARED ZERO CASE
Research package prepared for Vladimir Reshetnikov
1 November 2026

MAIN RESULT
A strict uniform reduction of the best current adjacent-parameter schema
in the five reviewed ProveIt/docs/drafts archives. The same zero case now
guards both the induction equation and a shorter iteration recurrence.
For the same input u(n,a), every instance loses exactly
  1 + the number of active occurrences of n in u
syntax-tree nodes. The language, one binary input, one constructor,
three quantifiers, and depth two are unchanged.

Classical and intuitionistic versions use the identical nonlogical schema.
Each is definitionally equivalent, bi-interpretable, and equiconsistent
with first-order PRA in the matching logic. Both interpretations preserve
the full carrier and native equality, with identity round trips.
No absolute shortestness theorem is claimed.

START HERE
  report.pdf       Complete report, proofs, comparison, further questions.
  report.tex       Complete self-contained LaTeX source.
  AXIOMS.txt       Exact complete specification without typesetting.
  build.py         Rebuilds PDF and syntax diagnostics; optional Lean check.

SUPPORTING FILES
  formal/RootedTail.lean   New constructive reduction kernel.
  formal/SCOPE.txt         Precise scope and limits of the formalization.
  formal/lean-toolchain    Lean 4.19.0 version pin.
  formal/verification.log  All 14 theorem dependency reports are empty.
  checks/check_schema.py   Independent immutable syntax/count checker.
  checks/results.json     Actual finite diagnostic results.
  audit/source_manifest.json  Pinned source archives and content hashes.
  audit/                   Mathematical review and build/validation records.
  SHA256SUMS.txt            SHA-256 hashes of all other package files.

SOURCE SNAPSHOT
  Repository: VladimirReshetnikov/ProveIt
  Commit: 9e77f2a2bb9ccf0a4f85934f1f83df8a3f8767be
  Directory: docs/drafts
The five source ZIP blob hashes were verified. Sources themselves are not
duplicated in this package; exact URLs and hashes are in the manifest.
The two archives adjacent_parameter and one_term_one_schema (1) have the
same mathematical schema. The original unnumbered one_term_one_schema
has a different fixed-point input and an additional diagonal identity.

REBUILD
Requirements: Python 3.10+ standard library; pdflatex with standard TeX Live
packages used by report.tex. Lean is needed only for the optional formal run.

From this directory:
  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

Alternatively:
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  python3 checks/check_schema.py
  lean formal/RootedTail.lean

VERIFY PACKAGE HASHES (Linux or another system with sha256sum)
  sha256sum -c SHA256SUMS.txt
Rebuilding changes derived logs/PDF metadata and therefore their hashes.

VERIFICATION BOUNDARY
The full bi-interpretability theorem has a complete written proof and
independent mathematical review. The Lean file checks the new reduction
kernel, not the entire first-order theory or scalar pairing compiler.
Its explicitly selected instance premises do not postulate induction over
all set-theoretic functions. Python performs finite syntax diagnostics.
