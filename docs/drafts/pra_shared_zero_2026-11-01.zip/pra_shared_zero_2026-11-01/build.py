#!/usr/bin/env python3
"""Rebuild this report and exact syntax diagnostics; optionally run Lean."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', help='Lean 4.19.0 executable (optional)')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / 'audit'
    audit.mkdir(exist_ok=True)
    records = []

    def run(name: str, command: list[str]):
        result = subprocess.run(command, cwd=root, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (audit / (name + '.log')).write_text(result.stdout)
        records.append({'name': name, 'command': command,
                        'exit_code': result.returncode})
        print(name, 'exit', result.returncode)
        if result.returncode:
            print(result.stdout[-5000:])
            raise RuntimeError(name + ' failed')
        return result.stdout

    run('syntax', [sys.executable, 'checks/check_schema.py'])
    for i in range(1, 4):
        latex_output = run(f'latex-pass-{i}', ['pdflatex', '-interaction=nonstopmode',
                                              '-halt-on-error', 'report.tex'])
    log = (root / 'report.log').read_text()
    issues = [line for line in log.splitlines()
              if re.search(r'Overfull|Underfull|LaTeX Warning|Package .* Warning', line)]
    if issues:
        raise RuntimeError('Final LaTeX warnings: ' + '\n'.join(issues))
    pdf_path = root / 'report.pdf'
    with pdf_path.open('rb') as stream:
        os.fsync(stream.fileno())
        pdf_data = stream.read()
    size_match = re.search(r'Output written on report.pdf \((\d+) pages?, (\d+) bytes\)',
                           latex_output)
    if not size_match or len(pdf_data) != int(size_match.group(2)):
        raise RuntimeError('PDF size does not match successful TeX output')
    if not pdf_data.startswith(b'%PDF-') or not pdf_data.rstrip().endswith(b'%%EOF'):
        raise RuntimeError('PDF header/trailer validation failed')
    lean_result = {'status': 'not_requested',
                   'existing_checked_source': 'formal/verification.log'}
    if args.lean:
        version = run('lean-version', [args.lean, '--version']).strip()
        output = run('lean-check', [args.lean, 'formal/RootedTail.lean'])
        reports = [line for line in output.splitlines()
                   if 'does not depend on any axioms' in line]
        if len(reports) != 14 or 'depends on axioms:' in output:
            raise RuntimeError('Unexpected Lean dependency reports')
        lean_result = {'status': 'passed', 'version': version,
                       'empty_axiom_reports': len(reports)}
    result = {'status': 'passed', 'runs': records, 'latex_issues': issues,
              'lean_this_run': lean_result,
              'report_tex_sha256': hashlib.sha256((root/'report.tex').read_bytes()).hexdigest(),
              'report_pdf_pages': int(size_match.group(1)),
              'report_pdf_bytes': len(pdf_data),
              'report_pdf_sha256': hashlib.sha256(pdf_data).hexdigest()}
    (audit/'build_results.json').write_text(json.dumps(result, indent=2)+'\n')
    print('Build completed. Visual PDF inspection is a separate step.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
