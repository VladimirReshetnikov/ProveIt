"""Measure all three complete new programs against all ten current comparators.

All source files and the unchanged measurement routine are local. The
comparison snapshot is b10a56a8f655c607494a3069b31d6679d968797a.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform


ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    metric_path = ROOT / 'comparison/source_measure.py'
    if digest(metric_path) != manifest['measurement_sha256']:
        raise ValueError('The frozen measurement function changed')
    spec = importlib.util.spec_from_file_location('frozen_source_metric', metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    programs = []
    for row in manifest['programs']:
        path = ROOT / 'comparison' / row['local_file']
        if digest(path) != row['sha256']:
            raise ValueError('Changed comparator: ' + row['local_file'])
        programs.append({**row, **metric.metrics(path)})
    full_minimum = {key: min(row[key] for row in programs) for key in FIELDS}
    core_minimum = {key: min(row['core'][key] for row in programs) for key in FIELDS}
    candidates = []
    for name in ('checker.py', 'checker_goal_dispatch.py', 'checker_absorbed.py'):
        scores = metric.metrics(ROOT / name)
        full_wins = {key: scores[key] < full_minimum[key] for key in FIELDS}
        core_wins = {key: scores['core'][key] < core_minimum[key] for key in FIELDS}
        if not all(full_wins.values()) or not all(core_wins.values()):
            raise ValueError('No longer strictly below every coordinate: ' + name)
        candidates.append({'file': name, **scores,
                           'strict_full_improvements': full_wins,
                           'strict_core_improvements': core_wins})
    result = {'status': 'PASS', 'python': platform.python_version(),
              'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
              'complete_program_count': len(programs),
              'whole_program_envelope': full_minimum, 'core_envelope': core_minimum,
              'candidates': candidates, 'programs': programs,
              'interpretation': 'Coordinatewise minimum of this pinned finite corpus; '
                                'not a universal proof-checker lower bound.'}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'programs'},
                     indent=2))


if __name__ == '__main__':
    main()
