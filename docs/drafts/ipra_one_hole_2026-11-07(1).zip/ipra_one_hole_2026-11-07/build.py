"""Build the self-contained report with pdfLaTeX."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which('pdflatex')
    if executable is None:
        raise SystemExit('pdflatex is required to build report.pdf')
    logs = []
    for _ in range(3):
        result = subprocess.run(
            [executable, '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
            cwd=ROOT, text=True, capture_output=True)
        logs.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT/'results/pdf_build.log').write_text('\n'.join(logs))
            raise SystemExit(result.stdout[-5000:])
    log = (ROOT/'report.log').read_text(errors='replace')
    warnings = [line for line in log.splitlines()
                if 'Overfull' in line or 'undefined' in line or 'LaTeX Warning' in line]
    (ROOT/'results/pdf_build.log').write_text('\n'.join(logs))
    summary = {'status': 'PASS', 'engine': executable, 'passes': 3,
               'pdf_bytes': (ROOT/'report.pdf').stat().st_size,
               'layout_or_reference_warnings': warnings}
    (ROOT/'results/pdf_build.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
