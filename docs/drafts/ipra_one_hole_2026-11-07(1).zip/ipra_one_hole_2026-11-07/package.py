"""Create a clean ZIP and SHA-256 inventory of this report package."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc'}


def selected():
    return sorted(path for path in ROOT.rglob('*')
                  if path.is_file() and '__pycache__' not in path.parts
                  and path.suffix not in EXCLUDED_SUFFIXES
                  and path.name != 'SHA256SUMS.txt')


def main():
    paths = selected()
    lines = [hashlib.sha256(path.read_bytes()).hexdigest()+'  '+
             path.relative_to(ROOT).as_posix() for path in paths]
    inventory = ROOT/'SHA256SUMS.txt'
    inventory.write_text('\n'.join(lines)+'\n')
    target = ROOT.parent/(ROOT.name+'.zip')
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted([*paths, inventory]):
            archive.write(path, (Path(ROOT.name)/path.relative_to(ROOT)).as_posix())
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('ZIP integrity check failed')
    print(target)
    print('Files:', len(paths)+1)
    print('Bytes:', target.stat().st_size)
    print('SHA256:', hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
