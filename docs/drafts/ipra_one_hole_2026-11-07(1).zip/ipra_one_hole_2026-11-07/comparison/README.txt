PINNED COMPLETE-PROGRAM COMPARISON
================================

Repository: VladimirReshetnikov/ProveIt
Commit: b10a56a8f655c607494a3069b31d6679d968797a
Directory: docs/drafts

The snapshot contains six ZIP archives and ten designated complete root
checker*.py programs. All ten programs, including the maintained complete
alternatives, are copied byte-for-byte under sources/. manifest.json records
their SHA-256 values, original archive members, and the six archive Git-blob
SHA-1 hashes, SHA-256 hashes, byte lengths, and pinned repository URLs. Archive
byte lengths and Git-blob hashes were verified before the sources were copied.

Run from the package root:

  python3 measure.py

The unchanged source_measure.py supplies the metric function. The wrapper
checks the measurement-file and comparator hashes, remeasures the ten complete
programs, measures all three candidates with the same boundary, and requires strict
improvement in all three full-program and all three diagnostic-core scores.
Use measure.py rather than invoking the inherited metric file's old standalone
driver, whose surrounding manifest interface belongs to its source archive.

On CPython 3.12.14:

                               Tokens       AST nodes    Normalized bytes
  Current full-program minima      411             425                1207
  checker.py                       391             420                1193
  checker_goal_dispatch.py         406             420                1197
  checker_absorbed.py              394             424                1203

  Current diagnostic-core minima   352             362                 957
  checker.py core                  332             357                 943
  checker_goal_dispatch.py core    347             357                 947
  checker_absorbed.py core         335             361                 953

The full-program boundary includes imports, JSON reading, syntax/scope checks,
substitution, inference, verdict printing, and rejection exit status. The
diagnostic core removes only imports and the __main__ driver consistently.
It is supplementary and is not substituted for the complete-program result.

The old 427/436/1246 envelope printed in these archives is for an earlier
repository snapshot. It is not the comparison target here. The current token
and byte minima belong to sort separation; the AST minimum belongs to scalar
iteration's complete checker_depth.py alternative.

expanded_inventory.json records an additional deduplicated scan of 107
complete acceptance sources at 277 archive paths, including inherited and
experimental files. It has the same minima. This is a provenance record of
the expanded scan, not an additional offline benchmark: only the ten designated
current comparator sources are frozen for remeasurement in this package.
Its scan predicate, source hashes, member paths, scores, and limitations are
explicit in the JSON.

The reported lower envelope is the coordinatewise minimum of this finite,
pinned corpus under one disclosed source metric. It is not a mathematical
lower bound on every proof checker, a global shortestness theorem, or a
programming-language-independent measure. Normalization counts are tied to
the stated CPython version; verdict behavior is a separate matter.
