UNIFORM UNARY SUBSTITUTION FOR iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026

READ FIRST

report.pdf is the complete mathematical report. report.tex and sections/
contain all its editable LaTeX sources. This package gives a smaller
complete checker for the current scalar-iteration presentation; it does
not claim an absolute simplest axiomatization. A further absorbed-scalar
companion makes successor definable and proves a new compatibility result
for two earlier arithmetic reductions. The inherited mathematics and new
contribution are distinguished
in the report and ATTRIBUTION.txt.

RESULT

The primary complete program has 391 normalized tokens, 420 AST nodes,
and 1193 normalized bytes. The current six archives at ProveIt commit
b10a56a8f655c607494a3069b31d6679d968797a have ten complete root checkers
and separate minima 411 / 425 / 1207. The same-boundary core comparison
is 332 / 357 / 943 against 352 / 362 / 957.

The central observation is that every primitive opening needs at most
one substitution image. Even the two-variable logical binder opens its
outer witness while protecting its inner binder. Scalar iteration only
opens its previous value. Therefore a single optional term replaces the
general substitution environment and its index calculation.

The additional absorbed-scalar checker has 394 tokens, 424 AST nodes, and
1203 normalized bytes (core 335 / 361 / 953), also strictly below the old
coordinatewise minima. It uses A(0,a;h)=S(a) and A(Sn,a;h)=h(A(n,a;h)).
A finite-case decoder and a cyclic predecessor prove equivalence with the
ordinary scalar calculus. Successor is mathematically definable by
S(a)=A(0,a;u.0); the serialized checker still counts its unary notation.

The report states all logical and arithmetic rules, reconstructs full
intuitionistic first-order logic, proves the scalar arithmetic bootstrap
and both interpretation round trips, and gives a zero-support obstruction
to replacing initialized iteration by zero-initialized iteration alone.
A stronger almost-unary bound excludes direct term definitions of addition,
maximum, selection, and injective pairing for every fixed seed, even one.

RUN

  python3 checker.py examples/zero_computation.json
  python3 reproduce.py
  python3 build.py

The first command prints ACCEPT or REJECT and returns exit status 0 or 1.
The second reproduces the measurements and finite validation. The third
builds report.pdf using pdfLaTeX. Python 3.10+ is needed for pattern matching;
the exact source measurements were obtained with CPython 3.12.14.
No network access or files outside this package are needed.

CONTENTS

  checker.py                 Primary complete acceptance program
  checker_goal_dispatch.py   Companion isolating unary substitution
  checker_absorbed.py        Absorbed-scalar arithmetic companion
  FORMAT.txt                 Exact public certificate format
  comparison/               Frozen current comparators, metric, provenance
  validation/               Independent oracle and finite checks
  results/                  Reproducible measurements and validation results
  examples/                 Small public certificate examples
  sections/                 Full mathematical exposition
  ATTRIBUTION.txt            Origins and contribution boundaries
  LICENSE_SOURCE.txt         Supplied MIT No Attribution license
  SHA256SUMS.txt             File checksums

LIMITS

The metatheory is proved in ordinary mathematical prose, not fully
formalized in Lean or Rocq. Finite tests are separate implementation
evidence. Finite memory/stack limits can reject a sufficiently large
valid certificate; the mathematical theorem relation uses the usual
adequate-resource interpretation. The comparison counts the complete
project-specific checker and shares Python/JSON as the ambient runtime.
