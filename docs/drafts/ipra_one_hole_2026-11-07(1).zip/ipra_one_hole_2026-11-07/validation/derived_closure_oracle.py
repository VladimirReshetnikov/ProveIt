"""Explicit derived-Q extension of the frozen scalar named-binder oracle.

This untrusted oracle uses named bound variables and separate term/formula
parsers. It does not import either acceptance program or the packed opening
function. The extra case is the already-derived closure introduction rule.
"""
from copy import deepcopy
from named_oracle import Oracle as FusedOracle


class Oracle(FusedOracle):
    def check(self, goal, context):
        self.open(goal)
        if goal in context:
            self.rule('hypothesis')
            return True
        if (len(goal) == 1 and self.stack and type(self.stack[-1]) is list
                and len(self.stack[-1]) == 1):
            self.stack.pop()  # The witness for an absent outer binder is inert.
            self.rule('derived_closure_introduction')
            body = deepcopy(goal[0])
            assumptions = [self.open(body, [0])]
            if len(body) == 2:
                assumptions.append(body)
            eigen = self.fresh([goal, *context])
            premises = [self.open(value, [eigen]) for value in assumptions]
            return self.check(self.open(body, [[eigen]]), [*context, *premises])
        return super().check(goal, context)
