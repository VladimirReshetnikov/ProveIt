"""Construct native certificates for successor-initialized scalar iteration.

There is no general I-to-A proof compiler here. The arithmetic instances are
actual A0/AS schemas, and the logical examples use A-native computations.
"""
from copy import deepcopy
from pathlib import Path
import json

from named_oracle import opening


def packet(goal, instructions):
    return list(reversed(deepcopy(instructions))) + [deepcopy(goal)]


def reflexivity(term):
    # A(S0,0;u.term)=term, where u is absent from the closed term.
    left = [[0], 0, deepcopy(term)]
    equation = [left, deepcopy(term)]
    return [deepcopy(term), deepcopy(term)], [[equation, [1, deepcopy(term)]], [], []]


def direct_closure_reflexivity():
    goal = [[1, 1]]
    _, step = reflexivity([-1])
    return goal, [[0], *step]


def standard_value(term, environment=()):
    """Ground standard-number semantics, independent of certificate inference."""
    if type(term) is int:
        if term == 0:
            return 0
        if term < 0:
            raise ValueError('A ground numerical check cannot contain rigid parameters')
        return environment[(term - 1) // 2]
    if len(term) == 1:
        return standard_value(term[0], environment) + 1
    counter, initial, update = term
    value = standard_value(initial, environment) + 1
    for _ in range(standard_value(counter, environment)):
        value = standard_value(update, (value, *environment))
    return value


def cases():
    rows = []

    def add(name, goal, instructions, expected=True, **metadata):
        rows.append({'name': name, 'packet': packet(goal, instructions),
                     'expected': expected, **metadata})

    updates = [0, 1, [1], [0, 1, 1], [0, 0, 3], [0, 0, [0, 0, 5]]]
    for initial_index, initial in enumerate((0, [0])):
        for update_index, update in enumerate(updates):
            left = [0, initial, update]
            right = [initial]
            name = 'A0_' + str(initial_index) + '_' + str(update_index)
            add(name, [left, right], [[]], ground_equation=True)
            add(name + '_false', [left, [right]], [[]], False, ground_equation=True)
            for counter_index, previous in enumerate((0, [0])):
                left = [[previous], initial, update]
                right = opening(update, ([previous, initial, update],), formula=False)
                name = 'AS_' + str(initial_index) + '_' + str(update_index) + '_' + str(counter_index)
                add(name, [left, right], [[]], ground_equation=True)
                add(name + '_false', [left, [right]], [[]], False, ground_equation=True)
    for index, update in enumerate((1, [0, 0, 3])):
        previous = [0, 0, 1]
        left = [[previous], 0, update]
        right = opening(update, ([previous, 0, update],), formula=False)
        add('AS_compound_counter_' + str(index), [left, right], [[]], ground_equation=True)
        add('AS_compound_counter_false_' + str(index), [left, [right]], [[]], False,
            ground_equation=True)

    add('old_I_zero_is_not_A_zero', [[0, 0, 0], 0], [[]], False,
        ground_equation=True)
    add('double_wrapped_step_initializer', [[[0], 0, 1], [0, [0], 1]], [[]], False,
        ground_equation=True)
    add('previous_alias_two', [[[0], [0], 2], [0, [0], 2]], [[]],
        ground_equation=True)
    add('deleted_counter_coordinate', [[[0], 0, 3], 0], [[]], False)
    add('malformed_unexecuted_update', [[0, 0, True], [0]], [[]], False)
    add('undeclared_root_parameter', [[0, -9, 0], [-9]], [[]], False)
    add('wrong_instruction', [0, [0]], ['not an instruction'], False)

    truth = [0, 0]
    for index, term in enumerate((0, [0], [0, 0, 1], [[0], [0], [0, 0, 3]])):
        goal, instructions = reflexivity(term)
        add('native_reflexivity_' + str(index), goal, instructions)

    closure, closure_steps = direct_closure_reflexivity()
    add('direct_Q_reflexivity', closure, closure_steps)
    pair = [[1, 1], truth, truth]
    _, step = reflexivity([-1])
    pair_steps = [[0], *step]
    add('D_reflexivity', pair, pair_steps)
    add('Q_via_D_elimination', closure, [[pair, None], *pair_steps])
    recursive_term = [[0], [0], [0, 0, 3]]
    _, base_steps = reflexivity(0)
    add('Q_elimination_at_A_term', [recursive_term, recursive_term],
        [[closure, recursive_term], *closure_steps, *base_steps])

    term = [0, [0], 1]
    major = [[[0], 0, term], term]
    add('transport_through_Q', [[term, term]],
        [[major, [[3, 3]]], [], [0]])
    add('transport_through_D', [[term, term], truth, truth],
        [[major, [[5, 5], truth, truth]], [], [0]])
    add('nested_Q', [[[3, 3]]], [[0], [0]])
    add('Q_D_successor_witness', [[[3, [5]], truth, truth]], [[0], [[[-1]]]])
    add('A_update_under_Q', [[[[0], 0, 3], 1]], [[0], []])
    add('A_initializer_under_Q', [[[0, 1, 1], [1]]], [[0], []])

    # This actual proof uses the retained atomic base 0=S0. The fresh target
    # is S(z)=S0. Two native A computations and transport derive that target.
    one, target = [0], [-1]
    base = [0, one]
    major = [[[0], 0, target], target]
    instructions = [[0], [major, [1, one]], [],
                    [base, [[1, 0, target], one]], []]
    add('retained_base_used', [[1, one], truth, truth], instructions)

    for label, witness in (('null', None), ('object', {}), ('future', -999)):
        add('D_unused_' + label, [truth, truth, truth], [[witness]])
        add('D_used_' + label, [[3, 3], truth, truth], [[witness]], False)
    add('bad_D_padding', [truth, None, truth], [[0]], False)
    add('future_D_padding', [truth, [-1, -1], truth], [[0]], False)
    add('missing_compound_successor_proof', [[[3, [0]]]], [[0]], False)
    return rows


if __name__ == '__main__':
    rows = cases()
    output = Path(__file__).resolve().parent / 'absorbed_cases.json'
    output.write_text(json.dumps(rows, indent=2) + '\n')
    print('Wrote', len(rows), 'native absorbed-scalar packet cases.')
