SUCCESSOR-INITIALIZED SCALAR CHECKER VALIDATION
=============================================

Run from the package root:

  python3 validation/verify_absorbed.py

This validates checker_absorbed.py, whose primitive computation schemas are:

  A(0,a;u.h)    = S(a)
  A(Sn,a;u.h)   = h[A(n,a;u.h)/u]

The successor abbreviation is represented by the already-counted unary term
constructor. The initializer in the recursive state remains a, not S(a).
In particular, an ordinary-initializer I-zero certificate is not an A-zero
certificate. This suite constructs and checks native A certificates directly;
it does not supply or claim a general I-to-A proof compiler.

SUPPORT AND INDEPENDENCE

absorbed_oracle.py extends the explicit scalar named-binder interpreter only
at the zero computation, replacing its result by successor(initial). Its
successor computation, separate syntax parsers, proof-clock checks, and
logical-rule interpreter are inherited. It imports no production checker.

reference_checker_absorbed.py is a separately retained variadic-opening,
goal-paired-dispatch reference with the same A0/AS arithmetic. Both programs
are compared with the named oracle on every fixed and mutated packet.

The production opening function is AST-identical to the previously audited
opening function in checker.py. The suite verifies that identity rather than
repeating its 4,896 opening cases. The prior receipt is results/validation.json.

NATIVE CERTIFICATES

generate_absorbed_cases.py reproduces absorbed_cases.json. The 107 cases are
all distinct: 57 accepted and 50 rejected. They include A0 and AS, both exposed
coordinate aliases, nested updates capturing an outer previous value, updates
inside logical binders, initializer placement, unused malformed annotations,
future names, deleted counter coordinates, and malformed formula padding.

The positive logical examples are actual A-language derivations. For any
closed term t, the constant update gives A(S0,0;u.t)=t. Transporting this equation
through H(x): x=t yields t=t. This supplies the included scalar reflexivity,
direct Q introduction, paired introduction, paired elimination, Q elimination
at an A term, and equality transport through both logical binders. A separate
certificate uses the retained atomic base 0=S0; no extra induction hypothesis
for a compound matrix is postulated.

The named oracle checks 18 eigenparameter allocations. There are also 79
ground standard-number comparisons using a direct iterative evaluator, which
is independent of the proof-inference interpreter. These are checks of the
specific generated equations, not universal interpretation identities.

Exactly 250 deterministic mutation attempts (seed 20261108) yield 235 distinct
packets; 10 attempts accept and 240 reject. Both programs and the named oracle
agree throughout. Three deliberately damaged kernels confirm sensitivity to
omitting successor at zero, inserting an extra successor into the recursive
initializer, and deleting the retained atomic base.

There are 220 actual command-line executions in normal and -O modes, including
three malformed JSON cases. Verdict, exit status, and empty standard-error
output are checked.

QUICK EXAMPLES

  python3 checker_absorbed.py validation/absorbed_examples/A_zero.json
  python3 checker_absorbed.py validation/absorbed_examples/Q_reflexivity.json
  python3 checker_absorbed.py validation/absorbed_examples/retained_base.json

Each accepts. The following rejects, as required:

  python3 checker_absorbed.py validation/absorbed_examples/old_I_zero_rejected.json

RECEIPTS AND LIMITATIONS

  results/absorbed_validation.json         Counts, hashes, controls, and status.
  results/absorbed_fixed_cases.json        Individual certificate receipts.
  results/absorbed_ground_equations.json   Direct standard-value checks.
  validation/absorbed_provenance.json      Support-file hashes and attribution.

Finite validation does not prove the mathematical interpretation theorem,
equiconsistency, or bi-interpretability. The proof is in the report. The
separate arithmetic identity experiments do not count as proof-kernel tests.
These overlapping cohorts are not counts of independent theorems.
