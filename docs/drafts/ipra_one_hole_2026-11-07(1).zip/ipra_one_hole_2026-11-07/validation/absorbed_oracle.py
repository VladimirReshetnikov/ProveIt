"""Independent named-binder oracle with successor at scalar iteration's zero.

The inherited explicit interpreter supplies scalar substitution, the retained
base rules, and direct derived-Q introduction. Only the zero computation changes.
This support file is never imported by a production acceptance program.
"""
from derived_closure_oracle import Oracle as ScalarOracle


class Oracle(ScalarOracle):
    def check(self, goal, context):
        self.open(goal)
        if goal in context:
            self.rule('hypothesis')
            return True
        if (self.stack and self.stack[-1] == [] and len(goal) == 2
                and type(goal[0]) is list and len(goal[0]) == 3
                and type(goal[0][0]) is int and goal[0][0] == 0):
            self.stack.pop()
            self.rule('absorbed_zero')
            return goal[1] == [goal[0][1]]
        return super().check(goal, context)
