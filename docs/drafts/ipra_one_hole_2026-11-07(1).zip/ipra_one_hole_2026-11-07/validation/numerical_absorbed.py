"""Finite semantic checks of a successor-absorbed scalar bootstrap.

All named arithmetic operations below are constructed from zero, successor,
and A(0,a;h)=S(a), A(Sn,a;h)=h(A(n,a;h)).  Python integer loops implement
the intended standard interpretation; tests are not proofs of the metatheory.
"""
from functools import lru_cache
import json


def S(n):
    return n + 1


def A(n, a, h):
    state = S(a)
    for _ in range(n):
        state = h(state)
    return state


@lru_cache(None)
def cp(n, a, b):
    return A(n, a, lambda _: b)


@lru_cache(None)
def Z(n):
    return A(n, 0, lambda _: 0)


@lru_cache(None)
def U(a, b):
    return A(b, a, S)


@lru_cache(None)
def N(n):
    return Z(A(n, 0, Z))


@lru_cache(None)
def j(n):
    return cp(n, 0, cp(Z(N(n)), 1, 0))


@lru_cache(None)
def M(n):
    return j(j(A(n, 0, j)))


@lru_cache(None)
def g(n):
    return cp(M(n), S(S(n)), cp(N(M(n)), S(n), S(n)))


@lru_cache(None)
def F(n):
    return A(n, 0, g)


@lru_cache(None)
def H(n):
    return cp(N(n), F(n), n)


@lru_cache(None)
def B(n):
    return A(n, 7, lambda u: S(S(S(u))))


@lru_cache(None)
def D5(n):
    return S(S(S(S(U(n, n)))))


@lru_cache(None)
def E(n):
    return A(n, 2, D5)


@lru_cache(None)
def T(y, n):
    return A(S(S(S(n))), E(y), H)


@lru_cache(None)
def c(y, n):
    return Z(N(T(y, n)))


@lru_cache(None)
def q(y, u):
    return cp(Z(c(y, u)), u, 0)


@lru_cache(None)
def G(n, y):
    return A(S(n), y, lambda u: q(y, u))


@lru_cache(None)
def P(n):
    return A(U(n, n), n, lambda u: q(n, u))


def test():
    checks = 0
    for n in range(50):
        assert N(n) == n % 2
        assert M(n) == n % 3
        assert F(n) == (3 * n) // 2 + 1
        assert H(n) == (3 * n) // 2 + 2 if n % 2 == 0 else H(n) == n
        assert H(B(n)) == B(H(n))
        assert H(S(D5(n))) == B(S(n))
        checks += 6
    for y in range(5):
        assert E(y) == 2 ** (y + 3) - 5
        assert N(A(2, E(y), H)) == 0
        for n in range(5):
            assert T(S(y), S(n)) == B(T(y, n))
            assert c(y, n) == int(y > n)
            assert not c(y, S(n)) or c(y, n)
            assert G(U(y, n), y) == G(n, y)
            checks += 4
        checks += 2
    values = [P(n) for n in range(6)]
    assert values == [0, 0, 1, 2, 3, 4]
    checks += 6
    return {"status": "PASS", "checked_equalities": checks,
            "predecessor_values": values,
            "qualification": "Finite standard-model checks, not formal proofs."}


if __name__ == "__main__":
    print(json.dumps(test(), indent=2))
