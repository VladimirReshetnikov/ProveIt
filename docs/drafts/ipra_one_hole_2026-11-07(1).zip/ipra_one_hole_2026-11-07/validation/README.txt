FINITE VALIDATION
=================

Run from the package root:

  python3 validation/verify.py

Everything required is included in the package. Neither production checker
imports this directory. The validation programs are untrusted support.

REFERENCE AND INDEPENDENCE

reference_checker.py is the current sort-separation kernel with exactly the
scalar-arithmetic adaptation: its iterator update binds one variable instead
of two, and its computation clause supplies only the previous value. It still
uses the inherited variadic opening function and paired goal/instruction
dispatch. This provides a reference for both new implementation changes.

named_oracle.py is copied unchanged from the scalar-iteration archive. It
parses terms and formulas into named-binder trees with separate routines,
replaces explicit holes, and serializes again. It does not use the packed
depth/sort integer, constructor-weight table, Python match statements, or
production opening code. derived_closure_oracle.py explicitly adds the
already-derived unary-closure introduction rule. This extends its certificate
language to match the sort-separation kernel without changing its theorems.

provenance.json records the sources and hashes of the frozen support and
fixture inputs. The three case cohorts are:

  scalar_cases.json    62 inherited scalar packets: 45 accept, 17 reject.
  closure_cases.json   19 closure/sort boundaries: 5 accept, 14 reject.
  new_cases.json       33 focused packets: 15 accept, 18 reject.

The binary-recursor packet originally named RS uses coordinate 3 for the
previous counter. Its bytes are retained, but scalar rejection is now required
and its old expected verdict is recorded separately. There is no silent
claim that this packet retains its old arithmetic meaning.

CHECKS PERFORMED

The 114 named cases contain 109 distinct serialized packets. Both complete
programs, the variadic reference, and the named-binder oracle agree on every
verdict. For accepted packets the final proof-clock value and unused-prefix
length also agree. The named oracle checks 77 eigenparameter allocations.

The opening audit contains 4,896 cases, compared with the named parser for
both production implementations and the variadic reference. It covers
protected nesting, alias coordinates, malformed terms and formulas, forward
parameters, surplus slots, absent images, and unused or demanded malformed
images. There are 2,569 valid and 2,327 invalid cases. The old opening corpus
contributes 3,264 empty/singleton-image cases; four additional image choices
contribute 1,632 cases. The 408 old two-image cases are explicitly excluded:
the new helper's mathematical contract concerns only nullary/unary opening,
which is all the public proof kernels request. Its third argument is a depth,
not a second substitution image.

Exactly 1,000 deterministic JSON-tree mutation attempts are also compared
with the named oracle. Seed 20261107 gives 851 distinct packets: 41 accepted
attempts and 959 rejected attempts. Acceptance of a mutation is not itself an
error; a mutation can preserve a valid certificate or affect an inert prefix.

Three deliberately damaged copies of the primary program confirm that the
suite detects a removed exposed-slot ceiling, admitted future parameters, and
Booleans admitted as integer tokens. Every damaged copy accepts a designated
invalid packet that the real kernels and oracle reject.

Finally, 468 real subprocess executions check both complete command-line
programs in normal and -O modes, including three malformed JSON inputs. The
printed verdict, exit status, and empty standard-error output are verified.

RESULTS AND LIMITS

  results/validation.json              Counts, hashes, controls, and status.
  results/validation_fixed_cases.json   Individual named-case receipts.

These overlapping cohorts are not counts of independent mathematical
theorems. The tests do not prove soundness, equiconsistency, bi-interpretability,
or universal Python implementation correctness. The mathematical argument is
in the report. Exception types and failure-consumption positions are not part
of the public ACCEPT/REJECT contract. Finite Python resource limits remain.

SUCCESSOR-INITIALIZED SCALAR COMPANION

checker_absorbed.py has its own A0/AS arithmetic language. Its separate suite
is described in ABSORBED_README.txt and run by:

  python3 validation/verify_absorbed.py

The ordinary-initializer I-zero axiom is invalid for A. No claim that the
main fixed I certificates can be reused unchanged for A is made.
