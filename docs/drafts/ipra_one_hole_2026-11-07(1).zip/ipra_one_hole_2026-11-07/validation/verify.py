"""Finite differential validation of the two one-hole acceptance programs.

Run from any working directory. All dependencies are included in this package.
These tests do not claim a formal proof of kernel correctness or consistency.
"""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import hashlib
import importlib.util
import json
import platform
import random
import subprocess
import sys
import tempfile
import types

from derived_closure_oracle import Oracle
from named_oracle import opening
from mutation_support import mutate


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SEED = 20261107


def require(value, detail):
    if not value:
        raise AssertionError(detail)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def packet_digest(packet):
    data = json.dumps(packet, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(data).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(module, packet):
    module.k = 0
    stream = deepcopy(packet)
    try:
        module.take = stream.pop
        accepted = bool(module.check(stream.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'error': error, 'final_k': module.k,
            'remaining': len(stream) if type(stream) is list else None}


def oracle_run(packet):
    if type(packet) is not list:
        return {'accepted': False, 'error': 'nonarray_packet', 'final_k': 0,
                'remaining': None, 'allocations': [], 'rules': {}}
    return Oracle().run(packet)


def outcome(operation):
    try:
        return True, operation()
    except Exception:
        return False, None


def opening_audit(modules):
    # The 408 contexts below are inherited from the scalar draft's named
    # opening audit. Its one two-image environment is outside the new API.
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, True, None, {}]
    terms = [*atoms, [], [0], [1], [5], [0, 0], [0, 0, 1], [0, 0, 3],
             [0, 0, 2], [1, 0, [0, 3, 5]], [0, 0, [0, 1, 5]]]
    formulas = [[term, 0] for term in terms]
    formulas += [[[term, 0]] for term in (-2, 0, 1, 2, 3, 4, 5)]
    formulas += [[[term, 0], [1, 2], [3, 4]]
                 for term in (-2, 0, 1, 2, 3, 4, 5, 6)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 9], 5]], [0, 0], [0, 0]]]
    inherited_images = [(), (0,), (-1,), (-3,), (1,), ([0],),
                        ([0, 0, 3],), ([0, 0, 5],)]
    new_images = [(None,), ({},), ([],), (True,)]
    counts = Counter()
    contexts = 0
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2):
                for lower in (0, -2):
                    contexts += 1
                    for images in inherited_images + new_images:
                        expected = outcome(lambda: opening(
                            deepcopy(value), deepcopy(images), formula=formula,
                            depth=depth, lower=lower))
                        for label, module in modules.items():
                            module.k = lower
                            actual = outcome(lambda: module.inst(
                                deepcopy(value), *deepcopy(images),
                                d=2 * depth + (not formula)))
                            require(actual == expected,
                                    ('opening', label, value, images, formula,
                                     depth, lower, actual, expected))
                        counts['valid' if expected[0] else 'invalid'] += 1
                        counts['nullary' if not images else 'unary'] += 1
    return {'cases': counts['valid'] + counts['invalid'],
            'valid': counts['valid'], 'invalid': counts['invalid'],
            'nullary': counts['nullary'], 'unary': counts['unary'],
            'implementations_compared_with_named_parser': len(modules),
            'inherited_nullary_unary_cases': contexts * len(inherited_images),
            'new_null_malformed_image_cases': contexts * len(new_images),
            'excluded_two_image_cases': contexts,
            'scope': 'Only empty or singleton image environments, at all tested '
                     'protected depths. The public proof kernels never request '
                     'two images. No assertion about arbitrary helper calls is made.'}


def check_packet(modules, packet, expected, label):
    outputs = {name: run(module, packet) for name, module in modules.items()}
    named = oracle_run(packet)
    require(named['accepted'] == expected, ('named oracle', label, expected, named))
    for name, result in outputs.items():
        require(result['accepted'] == expected, (name, label, expected, result))
        if expected:
            require(result['final_k'] == named['final_k'] and
                    result['remaining'] == named['remaining'],
                    ('accepted trace boundary', name, label, result, named))
    return named, outputs


def fault_controls(primary_source, rows):
    by_name = {row['name']: row for row in rows}
    edits = [
        ('ceiling_removed', 'k <= a < d + 2', 'k <= a',
         'surplus_transport_slot'),
        ('forward_names_allowed', 'k <= a < d + 2', 'a < d + 2',
         'future_root_parameter'),
        ('booleans_as_integers', 'type(a) is int', 'isinstance(a, int)',
         'unused_update_boolean'),
    ]
    results = []
    for name, old, new, case_name in edits:
        require(primary_source.count(old) == 1, ('fault anchor', name))
        altered = types.ModuleType('deliberate_fault_' + name)
        # Only this inspected source and the three literal edits are executed.
        # No certificate data is ever evaluated as Python code.
        exec(compile(primary_source.replace(old, new), name, 'exec'), altered.__dict__)
        row = by_name[case_name]
        result = run(altered, row['packet'])
        require(row['expected'] is False and result['accepted'] is True,
                ('fault control did not expose the defect', name, result))
        results.append({'defect': name, 'case': case_name,
                        'correct_verdict': 'REJECT', 'defective_verdict': 'ACCEPT',
                        'detected': True})
    return results


def cli_check(path, packet_path, expected, optimized):
    result = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                             str(path), str(packet_path)], capture_output=True,
                            text=True, timeout=20)
    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
    actual = result.returncode, result.stdout.strip(), result.stderr
    require(actual == wanted, ('CLI', path.name, packet_path.name, optimized, actual))


def main():
    provenance = json.loads((HERE / 'provenance.json').read_text())
    for name, row in provenance['frozen_inputs'].items():
        require(digest(HERE / name) == row['sha256'], ('changed frozen input', name))
    require(digest(HERE / 'new_cases.json') == provenance['new_cases']['sha256'],
            'The focused packet cases changed')
    paths = [ROOT / 'checker.py', ROOT / 'checker_goal_dispatch.py']
    modules = {path.name: load(path, 'candidate_' + path.stem) for path in paths}
    modules['reference_checker.py'] = load(HERE / 'reference_checker.py',
                                           'frozen_variadic_scalar_reference')
    cohorts, rows = {}, []
    for filename in ('scalar_cases.json', 'closure_cases.json', 'new_cases.json'):
        group = json.loads((HERE / filename).read_text())
        cohorts[filename] = {'cases': len(group),
                             'accepted': sum(row['expected'] for row in group),
                             'rejected': sum(not row['expected'] for row in group)}
        rows.extend(group)
    fixed = []
    rule_counts = Counter()
    allocations = 0
    for row in rows:
        named, outputs = check_packet(modules, row['packet'], row['expected'], row['name'])
        rule_counts.update(named.get('rules', {}))
        allocations += len(named.get('allocations', []))
        fixed.append({'name': row['name'], 'expected': row['expected'],
                      'packet_sha256': packet_digest(row['packet']),
                      'programs': outputs, 'named_oracle': named})
    openings = opening_audit(modules)
    rng = random.Random(SEED)
    mutation_counts = Counter()
    mutation_digests = set()
    for index in range(1000):
        packet = mutate(rng.choice(rows)['packet'], rng)
        expected = oracle_run(packet)['accepted']
        check_packet(modules, packet, expected, 'mutation_' + str(index))
        mutation_counts['accepted' if expected else 'rejected'] += 1
        mutation_digests.add(packet_digest(packet))
    faults = fault_controls(paths[0].read_text(), rows)
    cli_executions = 0
    malformed = ['', '[', '[0,]']
    with tempfile.TemporaryDirectory(prefix='ipra_one_hole_') as directory:
        directory = Path(directory)
        for index, row in enumerate(rows):
            packet_path = directory / ('case_' + str(index) + '.json')
            packet_path.write_text(json.dumps(row['packet']))
            for path in paths:
                for optimized in (False, True):
                    cli_check(path, packet_path, row['expected'], optimized)
                    cli_executions += 1
        for index, raw in enumerate(malformed):
            packet_path = directory / ('malformed_' + str(index) + '.json')
            packet_path.write_text(raw)
            for path in paths:
                for optimized in (False, True):
                    cli_check(path, packet_path, False, optimized)
                    cli_executions += 1
    result = {
        'status': 'PASS', 'python': platform.python_version(), 'seed': SEED,
        'programs': [{'file': path.name, 'sha256': digest(path)} for path in paths],
        'reference_sha256': digest(HERE / 'reference_checker.py'),
        'cohorts': cohorts, 'fixed_named_cases': len(rows),
        'fixed_distinct_packets': len({packet_digest(row['packet']) for row in rows}),
        'fixed_accepting_cases': sum(row['expected'] for row in rows),
        'fixed_rejecting_cases': sum(not row['expected'] for row in rows),
        'named_oracle_rule_counts': dict(rule_counts),
        'named_oracle_eigenparameter_allocations': allocations,
        'opening': openings,
        'mutations': {'attempts': 1000, 'distinct_packets': len(mutation_digests),
                      **dict(mutation_counts)},
        'fault_controls': faults,
        'cli': {'executions': cli_executions, 'programs': len(paths),
                'modes': ['normal', '-O'], 'malformed_json_cases': len(malformed),
                'verdict_exit_and_empty_stderr_verified': True},
        'limitations': ['Finite tests are not a formal soundness or consistency proof.',
                        'The cohorts overlap and do not count independent theorems.',
                        'Kernel exception types and rejection-consumption positions '
                        'are not part of the public verdict contract.',
                        'The one-hole API claim covers only nullary and unary opening.'],
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/validation_fixed_cases.json').write_text(
        json.dumps(fixed, indent=2) + '\n')
    (ROOT / 'results/validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
