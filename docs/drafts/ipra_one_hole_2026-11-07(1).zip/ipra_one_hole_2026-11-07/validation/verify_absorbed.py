"""Validate the successor-initialized scalar companion on its own language.

No ordinary-initializer certificate is silently reused as an absorbed one.
The suite checks native A schemas, generated logical proofs, and scope attacks.
"""
from collections import Counter
from pathlib import Path
import ast
import hashlib
import json
import platform
import random
import tempfile
import types

from absorbed_oracle import Oracle
from generate_absorbed_cases import cases, standard_value
from mutation_support import mutate
from verify import cli_check, digest, load, packet_digest, require, run


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SEED = 20261108


def oracle_run(packet):
    if type(packet) is not list:
        return {'accepted': False, 'error': 'nonarray_packet',
                'remaining': None, 'final_k': 0, 'rules': {}, 'allocations': []}
    return Oracle().run(packet)


def compare(modules, packet, expected, name):
    named = oracle_run(packet)
    require(named['accepted'] == expected, ('absorbed oracle', name, expected, named))
    outputs = {label: run(module, packet) for label, module in modules.items()}
    for label, actual in outputs.items():
        require(actual['accepted'] == expected, ('absorbed kernel', label, name, actual))
        if expected:
            require(actual['final_k'] == named['final_k'] and
                    actual['remaining'] == named['remaining'],
                    ('absorbed accepted trace', label, name, actual, named))
    return named, outputs


def opening_source(path):
    tree = ast.parse(path.read_text())
    functions = [node for node in tree.body
                 if isinstance(node, ast.FunctionDef) and node.name == 'inst']
    require(len(functions) == 1, ('one opening function expected', path.name))
    return ast.dump(functions[0], include_attributes=False)


def fault_controls(source, by_name):
    specifications = [
        ('omitted_successor_at_zero', 'return b == [t]', 'return b == t',
         'old_I_zero_is_not_A_zero', True),
        ('doubled_successor_initializer', 'inst(h, [n, t, h], d=1)',
         'inst(h, [n, [t], h], d=1)', 'double_wrapped_step_initializer', True),
        ('atomic_retained_base_removed',
         'h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [inst(a, 0)] if len(a) % 2 else [a]', 'retained_base_used', False),
    ]
    receipts = []
    for name, old, new, example, expected_defective in specifications:
        require(source.count(old) == 1, ('absorbed fault anchor', name))
        module = types.ModuleType('deliberately_defective_' + name)
        exec(compile(source.replace(old, new), name, 'exec'), module.__dict__)
        row = by_name[example]
        actual = run(module, row['packet'])['accepted']
        require(actual == expected_defective and actual != row['expected'],
                ('absorbed fault was not detected', name, actual))
        receipts.append({'defect': name, 'packet': example, 'detected': True,
                         'correct_acceptance': row['expected'],
                         'defective_acceptance': actual})
    return receipts


def main():
    provenance = json.loads((HERE / 'absorbed_provenance.json').read_text())
    for name, expected in provenance['support_sha256'].items():
        require(digest(HERE / name) == expected, ('changed absorbed support', name))
    path = ROOT / 'checker_absorbed.py'
    modules = {'checker_absorbed.py': load(path, 'absorbed_scalar_candidate'),
               'reference_checker_absorbed.py': load(
                   HERE / 'reference_checker_absorbed.py', 'absorbed_variadic_reference')}
    opening = opening_source(path)
    require(opening == opening_source(ROOT / 'checker.py'),
            'The previously audited unary opening routine changed')
    rows = cases()
    require(rows == json.loads((HERE / 'absorbed_cases.json').read_text()),
            'The absorbed native cases do not reproduce')
    fixed, numerical = [], []
    rules = Counter()
    allocations = 0
    for row in rows:
        named, outputs = compare(modules, row['packet'], row['expected'], row['name'])
        rules.update(named.get('rules', {}))
        allocations += len(named.get('allocations', []))
        fixed.append({'name': row['name'], 'expected': row['expected'],
                      'packet_sha256': packet_digest(row['packet']),
                      'programs': outputs, 'named_oracle': named})
        if row.get('ground_equation'):
            left, right = row['packet'][-1]
            values = standard_value(left), standard_value(right)
            require((values[0] == values[1]) == row['expected'],
                    ('absorbed standard-value check', row['name'], values))
            numerical.append({'name': row['name'], 'left_value': values[0],
                              'right_value': values[1], 'equal': values[0] == values[1]})
    require(rules['recursion_zero'] == 0,
            'The ordinary-initializer zero rule must never be used')
    rng = random.Random(SEED)
    mutations = Counter()
    distinct = set()
    for index in range(250):
        packet = mutate(rng.choice(rows)['packet'], rng)
        expected = oracle_run(packet)['accepted']
        compare(modules, packet, expected, 'absorbed_mutation_' + str(index))
        mutations['accepted' if expected else 'rejected'] += 1
        distinct.add(packet_digest(packet))
    controls = fault_controls(path.read_text(), {row['name']: row for row in rows})
    cli_executions = 0
    malformed = ['', '[', '[0,]']
    with tempfile.TemporaryDirectory(prefix='ipra_absorbed_') as temporary:
        directory = Path(temporary)
        for index, row in enumerate(rows):
            example = directory / ('native_' + str(index) + '.json')
            example.write_text(json.dumps(row['packet']))
            for optimized in (False, True):
                cli_check(path, example, row['expected'], optimized)
                cli_executions += 1
        for index, contents in enumerate(malformed):
            example = directory / ('malformed_' + str(index) + '.json')
            example.write_text(contents)
            for optimized in (False, True):
                cli_check(path, example, False, optimized)
                cli_executions += 1
    result = {
        'status': 'PASS', 'python': platform.python_version(),
        'kernel': path.name, 'kernel_sha256': digest(path),
        'reference_sha256': digest(HERE / 'reference_checker_absorbed.py'),
        'fixed_named_cases': len(rows),
        'fixed_distinct_packets': len({packet_digest(row['packet']) for row in rows}),
        'fixed_accepts': sum(row['expected'] for row in rows),
        'fixed_rejects': sum(not row['expected'] for row in rows),
        'independent_named_oracle_rules': dict(rules),
        'eigenparameter_allocations_checked': allocations,
        'ground_standard_value_comparisons': len(numerical),
        'opening': {'ast_identical_to': 'checker.py',
                    'normalized_ast_sha256': hashlib.sha256(opening.encode()).hexdigest(),
                    'prior_audit': 'results/validation.json',
                    'repeated_opening_cases': 0},
        'mutations': {'attempts': 250, 'seed': SEED,
                      'distinct_packets': len(distinct), **dict(mutations)},
        'fault_controls': controls,
        'cli': {'executions': cli_executions, 'modes': ['normal', '-O'],
                'malformed_json_cases': len(malformed),
                'verdict_exit_and_empty_stderr_verified': True},
        'limitations': ['Finite validation is not a proof of the interpretation theorem.',
                        'The cases are native A certificates; no general I-to-A proof '
                        'compiler is supplied or claimed.',
                        'The arithmetic interpretation identity experiments are separate '
                        'from these proof-kernel tests.',
                        'Cohorts overlap and do not count independent theorems.'],
    }
    (ROOT / 'results/absorbed_validation.json').write_text(json.dumps(result, indent=2) + '\n')
    (ROOT / 'results/absorbed_fixed_cases.json').write_text(json.dumps(fixed, indent=2) + '\n')
    (ROOT / 'results/absorbed_ground_equations.json').write_text(json.dumps(numerical, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
