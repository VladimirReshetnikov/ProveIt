"""Reproduce the local measurements and disclosed finite checks."""
from pathlib import Path
import argparse
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(script):
    result = subprocess.run([sys.executable, str(ROOT/script)], cwd=ROOT,
                            text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(script+' failed:\n'+result.stdout+result.stderr)
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', action='store_true', help='also rebuild the PDF')
    args = parser.parse_args()
    for script in ('measure.py', 'validation/verify.py',
                   'validation/verify_absorbed.py'):
        run(script)
        print(script+': PASS')
    numerical = json.loads(run('validation/numerical_absorbed.py'))
    (ROOT/'results/numerical_absorbed.json').write_text(
        json.dumps(numerical, indent=2)+'\n')
    print('validation/numerical_absorbed.py: '+numerical['status'])
    if args.pdf:
        run('build.py')
        print('build.py: PASS')
    print('All disclosed reproduction steps passed.')


if __name__ == '__main__':
    main()
