"""Exact polynomial checks for the local linear-fibre semiring operations.

This checks universal polynomial identities by collecting coefficients.
It is not a model of nonstandard arithmetic and does not verify the
infinite lifting theorem, cancellation implications, or bi-interpretation.
Only Python's standard library is used.
"""
from collections import defaultdict
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VARIABLES = ("m", "n", "p", "v", "w", "u")
UNIT = (0,) * len(VARIABLES)


def const(n):
    return {UNIT: n} if n else {}


def var(name):
    powers = list(UNIT)
    powers[VARIABLES.index(name)] = 1
    return {tuple(powers): 1}


def add(a, b):
    out = defaultdict(int, a)
    for monomial, coefficient in b.items():
        out[monomial] += coefficient
    return {m: c for m, c in out.items() if c}


def mul(a, b):
    out = defaultdict(int)
    for powers_a, coefficient_a in a.items():
        for powers_b, coefficient_b in b.items():
            out[tuple(x + y for x, y in zip(powers_a, powers_b))] += (
                coefficient_a * coefficient_b)
    return {m: c for m, c in out.items() if c}


def plus(a, b):
    return add(a[0], b[0]), add(a[1], b[1])


def times(a, b):
    return mul(a[0], b[0]), add(mul(b[0], a[1]), mul(a[0], b[1]))


def succ(a):
    return add(a[0], const(1)), a[1]


def main():
    a, b, c = (var("m"), var("v")), (var("n"), var("w")), (var("p"), var("u"))
    zero, one = (const(0), const(0)), (const(1), const(0))
    claims = [
        ("addition_commutative", plus(a, b), plus(b, a)),
        ("addition_associative", plus(plus(a, b), c), plus(a, plus(b, c))),
        ("addition_zero", plus(a, zero), a),
        ("multiplication_commutative", times(a, b), times(b, a)),
        ("multiplication_associative", times(times(a, b), c), times(a, times(b, c))),
        ("multiplication_one", times(a, one), a),
        ("multiplication_zero", times(a, zero), zero),
        ("distributivity", times(a, plus(b, c)), plus(times(a, b), times(a, c))),
        ("successor_is_plus_one", succ(a), plus(a, one)),
        ("addition_successor_recurrence", plus(a, succ(b)), succ(plus(a, b))),
        ("multiplication_successor_recurrence", times(a, succ(b)), plus(times(a, b), a)),
    ]
    checked = []
    for name, lhs, rhs in claims:
        if lhs != rhs:
            raise ValueError("False polynomial identity: " + name)
        checked.append({"name": name, "coefficient_residual": [0, 0]})
    # Dropping the m*w term breaks the left identity: 1*a loses a's vector.
    broken_one_product = (mul(one[0], a[0]), mul(a[0], one[1]))
    if broken_one_product == a:
        raise ValueError("Damaged left-identity law was not detected")
    result = {
        "scope": "Exact polynomial normalization of local identities only.",
        "identity_count": len(checked),
        "identities": checked,
        "negative_controls": {"missing_product_term_rejected": True},
        "not_checked": ["nonstandard model existence", "affine bilateral lifting",
                        "cancellation implications", "automorphism obstruction"],
    }
    (ROOT / "evidence/linear_identity_results.json").write_text(
        json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
