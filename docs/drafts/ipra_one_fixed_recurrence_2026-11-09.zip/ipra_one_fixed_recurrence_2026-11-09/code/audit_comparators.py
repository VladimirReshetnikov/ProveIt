"""Reproduce whole-source comparator sizes without executing the checkers."""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    raw = path.read_bytes()
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw)))
    normalized = ast.unparse(tree) + "\n"
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "tokens": sum(t.type not in IGNORED for t in
                      tokenize.generate_tokens(io.StringIO(normalized).readline)),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode("utf-8")),
    }


def main():
    manifest = json.loads((ROOT / "evidence/comparators.json").read_text())
    rows = []
    for entry in manifest["programs"]:
        actual = measure(ROOT / entry["file"])
        if actual["sha256"] != entry["sha256"]:
            raise ValueError("Changed comparator: " + entry["name"])
        if platform.python_version() == "3.12.14":
            for key in ("tokens", "ast_nodes", "normalized_bytes"):
                if actual[key] != entry[key]:
                    raise ValueError("Measurement mismatch: " + entry["name"])
        rows.append({"name": entry["name"], **actual})
    minima = {k: min(r[k] for r in rows)
              for k in ("tokens", "ast_nodes", "normalized_bytes")}
    result = {
        "python": platform.python_version(),
        "snapshot": manifest["snapshot"],
        "program_count": len(rows),
        "scope": "Static parsing only; no comparator code executed.",
        "minimum": minima,
        "attainers": {k: [r["name"] for r in rows if r[k] == value]
                      for k, value in minima.items()},
        "programs": rows,
    }
    (ROOT / "evidence/comparison_results.json").write_text(
        json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "programs"}, indent=2))


if __name__ == "__main__":
    main()
