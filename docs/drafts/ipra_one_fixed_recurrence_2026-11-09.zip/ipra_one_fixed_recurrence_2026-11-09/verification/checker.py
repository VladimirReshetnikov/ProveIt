"""Scoped symbolic replay of the rho derivation; not a complete iPRA checker.

Only the explicitly enumerated elementary interface is retained as proved
lemmas.  Stationarity, action fusion, inverse iteration and rho are NOT axioms.
"""
import json
import re
import sys


class Invalid(ValueError):
    pass


def need(test, message):
    if not test:
        raise Invalid(message)


def freeze(value):
    return tuple(map(freeze, value)) if isinstance(value, list) else value


def T(name, *args):
    return (name, *args)


Z = T("0")
O = T("S", Z)
S = lambda a: T("S", a)
SS = lambda a: S(S(a))
EQ = lambda a, b: ("eq", a, b)
ARITY = {"0": 0, "S": 1, "P": 1, "C": 3, "delta": 1,
         "E": 1, "D": 1, "H": 1, "B": 1, "A": 1, "nu": 1,
         "I": 2, "J": 2, "N": 1, "T": 2, "R": 1,
         "G": 1, "Q": 1, "c": 1}


def free(value):
    if isinstance(value, str):
        return {value}
    return set().union(*(free(v) for v in value[1:])) if len(value) > 1 else set()


def term(value):
    if isinstance(value, str):
        need(re.fullmatch(r"[a-z][a-z0-9_]*", value) is not None,
             "invalid numerical variable")
    else:
        need(isinstance(value, tuple) and value and value[0] in ARITY,
             "unknown numerical term")
        need(len(value) == ARITY[value[0]] + 1, "wrong numerical arity")
        for child in value[1:]:
            term(child)
    return value


def formula(value):
    need(isinstance(value, tuple) and value, "invalid formula")
    if value[0] == "eq":
        need(len(value) == 3, "wrong equation arity")
        term(value[1]); term(value[2])
    elif value[0] == "or":
        need(len(value) == 3, "wrong disjunction arity")
        formula(value[1]); formula(value[2])
    else:
        need(value == ("bot",), "unknown formula constructor")
    return value


def subst(value, mapping):
    if isinstance(value, str):
        return mapping.get(value, value)
    return (value[0], *(subst(v, mapping) for v in value[1:]))


# The equation schemas are fixed independently of the submitted certificate.
# Lower-case strings in these patterns are schematic numerical variables.
BASE_EQ = {
    "P0": EQ(T("P", Z), Z),
    "PS": EQ(T("P", S("u")), "u"),
    "C0": EQ(T("C", Z, "a", "b"), "a"),
    "CS": EQ(T("C", S("u"), "a", "b"), "b"),
    "delta": EQ(T("delta", "u"), T("C", "u", O, Z)),
    "E0": EQ(T("E", Z), Z),
    "ES": EQ(T("E", S("u")), T("delta", T("E", "u"))),
    "D0": EQ(T("D", Z), Z),
    "DS": EQ(T("D", S("u")), SS(T("D", "u"))),
    "H0": EQ(T("H", Z), Z),
    "HS": EQ(T("H", S("u")),
             T("C", T("E", "u"), T("H", "u"), S(T("H", "u")))),
    "Bdef": EQ(T("B", "u"),
               T("C", T("E", "u"), SS("u"), T("P", T("P", "u")))),
    "Adef": EQ(T("A", "u"),
               T("C", T("E", "u"), T("C", "u", O, T("P", T("P", "u"))), SS("u"))),
    "nudef": EQ(T("nu", "u"),
                T("C", T("E", "u"), T("C", "u", Z, T("P", "u")), S("u"))),
    "I0": EQ(T("I", Z, "a"), "a"),
    "IS": EQ(T("I", S("u"), "a"), T("B", T("I", "u", "a"))),
    "J0": EQ(T("J", Z, "a"), "a"),
    "JS": EQ(T("J", S("u"), "a"), T("A", T("J", "u", "a"))),
    "Ndef": EQ(T("N", "u"), T("C", "u", Z, S(T("D", T("P", "u"))))),
    "Tdef": EQ(T("T", "u", "a"),
               T("C", T("E", "u"), T("I", T("H", "u"), "a"),
                 T("J", S(T("H", "u")), "a"))),
    "Rdef": EQ(T("R", "u"),
               T("C", T("E", "u"), T("J", T("H", "u"), "u"),
                 T("I", T("H", "u"), "u"))),
    "Gdef": EQ(T("G", "u"),
               T("C", T("E", "u"), T("R", "u"), T("R", S("u")))),
    "Qdef": EQ(T("Q", "u"),
               T("C", T("E", "u"), T("R", S("u")), T("R", "u"))),
    "cdef": EQ(T("c", "u"), T("H", T("D", "u"))),
}

# These have finite case proofs in the report. They are a disclosed interface,
# not claims established by this relative replay.
ELEMENTARY_EQ = {
    "E2": EQ(T("E", SS("u")), T("E", "u")),
    "H2": EQ(T("H", SS("u")), S(T("H", "u"))),
    "AB": EQ(T("A", T("B", "u")), "u"),
    "BA": EQ(T("B", T("A", "u")), "u"),
    "nu2": EQ(T("nu", T("nu", "u")), "u"),
    "nuA": EQ(T("nu", T("A", "u")), T("B", T("nu", "u"))),
}


def get_path(value, path):
    for index in path:
        need(type(index) is int and isinstance(value, tuple)
             and 1 <= index < len(value), "invalid rewrite path")
        value = value[index]
    return value


def set_path(value, path, replacement):
    if not path:
        return replacement
    index, *tail = path
    return (*value[:index], set_path(value[index], tail, replacement), *value[index + 1:])


def verify(certificate, disabled=()):
    need(certificate.get("task") == "derive_rho", "unknown proof task")
    lines, assumptions, counts = [], set(), {}
    disabled = set(disabled)

    def get(index):
        need(type(index) is int and 0 <= index < len(lines), "invalid premise reference")
        return lines[index]

    def equality(index):
        value, deps = get(index)
        need(value[0] == "eq", "equation premise required")
        return value[1], value[2], deps

    def dependency_variables(deps):
        return set().union(*(free(lines[i][0]) for i in deps)) if deps else set()

    for index, raw in enumerate(certificate["steps"]):
        step = {k: freeze(v) for k, v in raw.items()}
        op, deps = step.get("op"), frozenset()
        counts[op] = counts.get(op, 0) + 1
        try:
            if op in ("axiom", "elementary"):
                source = BASE_EQ if op == "axiom" else ELEMENTARY_EQ
                name = step["name"]
                need(name in source and name not in disabled, "unavailable equation schema")
                mapping = step["map"]
                need(set(mapping) == free(source[name]), "incomplete or extra schema substitution")
                for value in mapping.values():
                    term(freeze(value))
                out = subst(source[name], {k: freeze(v) for k, v in mapping.items()})
            elif op == "range":
                name, arg = step["name"], term(step["arg"])
                need(name in ("coverage", "parity") and name not in disabled, "unavailable case interface")
                out = (("or", EQ(arg, Z), EQ(arg, S(T("P", arg)))) if name == "coverage"
                       else ("or", EQ(T("E", arg), Z), EQ(T("E", arg), O)))
            elif op == "refl":
                out = EQ(term(step["term"]), step["term"])
            elif op == "assume":
                out, deps = formula(step["formula"]), frozenset({index})
                assumptions.add(index)
            elif op == "sym":
                a, b, deps = equality(step["proof"])
                out = EQ(b, a)
            elif op == "trans":
                a, b, da = equality(step["left"])
                c, d, db = equality(step["right"])
                need(b == c, "transitivity middle terms differ")
                out, deps = EQ(a, d), da | db
            elif op == "cong":
                premises = [equality(p) for p in step["proofs"]]
                out = EQ(T(step["symbol"], *(p[0] for p in premises)),
                         T(step["symbol"], *(p[1] for p in premises)))
                deps = frozenset().union(*(p[2] for p in premises))
            elif op == "inst":
                source, deps = get(step["proof"])
                mapping = {k: freeze(v) for k, v in step["map"].items()}
                for variable, value in mapping.items():
                    term(variable); term(value)
                mapping = {k: v for k, v in mapping.items() if k != v}
                need(not (set(mapping) & dependency_variables(deps)),
                     "substitution changes an undischarged assumption")
                out = subst(source, mapping)
            elif op == "rewrite":
                source, ds = get(step["proof"])
                left, right, dr = equality(step["equation"])
                if step.get("reverse", False):
                    left, right = right, left
                path = step["path"]
                need(path and get_path(source, path) == left, "rewrite target does not match")
                out, deps = set_path(source, path, right), ds | dr
            elif op == "cases":
                disj, dd = get(step["disjunction"])
                la, ra = step["left_assumption"], step["right_assumption"]
                need(disj[0] == "or" and la != ra and la in assumptions and ra in assumptions,
                     "case assumptions required")
                need(lines[la][0] == disj[1] and lines[ra][0] == disj[2], "wrong case assumptions")
                left, dl = get(step["left"]); right, dr = get(step["right"])
                need(left == right and ra not in dl and la not in dr and la not in dd and ra not in dd,
                     "invalid case branches")
                out, deps = left, dd | (dl - {la}) | (dr - {ra})
            elif op == "num_cases":
                need("coverage" not in disabled, "numerical coverage unavailable")
                body, z, target = formula(step["body"]), step["counter"], term(step["target"])
                term(z); need(isinstance(z, str) and z != "x", "invalid case variable")
                base, db = get(step["base"]); successor, ds = get(step["successor"])
                deps = db | ds
                need(z not in (free(body) - {"x"}) | free(target) | dependency_variables(deps),
                     "numerical-case freshness failure")
                need(base == subst(body, {"x": Z}) and successor == subst(body, {"x": S(z)}),
                     "wrong zero/successor case endpoints")
                out = subst(body, {"x": target})
            elif op == "unique":
                need(step.get("rule") == "B", "only U_B is available")
                body, z, target = term(step["body"]), step["counter"], term(step["target"])
                term(z); need(isinstance(z, str) and z != "x", "invalid recurrence eigenvariable")
                premise, deps = get(step["proof"])
                need(z not in (free(body) - {"x"}) | free(target) | dependency_variables(deps),
                     "uniqueness freshness failure")
                need(premise == EQ(subst(body, {"x": S(z)}), T("B", subst(body, {"x": z}))),
                     "wrong U_B recurrence")
                out = EQ(subst(body, {"x": target}), T("I", target, subst(body, {"x": Z})))
            elif op == "no_fix":
                need("no_fix_B" not in disabled, "fixed-point-free interface unavailable")
                a, b, deps = equality(step["proof"])
                need(a == T("B", b), "not a B fixed point")
                out = ("bot",)
            elif op == "explode":
                source, deps = get(step["proof"])
                need(source == ("bot",), "falsity premise required")
                out = formula(step["formula"])
            else:
                raise Invalid("unknown inference")
            lines.append((formula(out), deps))
        except (Invalid, KeyError, TypeError, ValueError, IndexError) as error:
            raise Invalid(f"step {index} ({op}): {error}") from error

    goal = EQ(T("H", T("D", "n")), "n")
    need(lines and lines[-1] == (goal, frozenset()), "wrong endpoint or undischarged assumptions")
    milestones = {}
    for name, index in certificate.get("milestones", {}).items():
        value, deps = get(index)
        milestones[name] = {"node": index, "equation": value, "local_assumptions": sorted(deps)}
    return {"accepted": True, "nodes": len(lines), "inferences": counts,
            "milestones": milestones, "elementary_interface": sorted(ELEMENTARY_EQ),
            "additional_interfaces": ["coverage", "parity", "no_fix_B"],
            "scope": "Relative symbolic rho derivation, not a complete iPRA checker"}


if __name__ == "__main__":
    with open(sys.argv[1], encoding="utf-8") as stream:
        print(json.dumps(verify(json.load(stream)), indent=2))
