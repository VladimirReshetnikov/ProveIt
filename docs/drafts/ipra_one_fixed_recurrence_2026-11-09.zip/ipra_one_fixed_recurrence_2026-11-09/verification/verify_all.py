"""Build and replay rho; reject mutations of logical and arithmetic obligations."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from checker import Invalid, verify


ROOT = Path(__file__).resolve().parent


def changed(certificate, action):
    result = copy.deepcopy(certificate)
    action(result)
    return result


def first(certificate, operation):
    return next(step for step in certificate["steps"] if step["op"] == operation)


def main():
    produced = subprocess.run([sys.executable, str(ROOT / "produce.py")], check=True,
                              capture_output=True, text=True)
    certificate = json.loads((ROOT / "rho_certificate.json").read_text(encoding="utf-8"))
    positive = verify(certificate)
    steps = certificate["steps"]
    phase_unique = next(i for i, step in enumerate(steps)
                        if step["op"] == "unique" and steps[step["proof"]]["op"] == "cases")
    phase_case = steps[steps[phase_unique]["proof"]]
    last_case = max(i for i, step in enumerate(steps) if step["op"] == "cases")
    first_refl = next(i for i, step in enumerate(steps) if step["op"] == "refl")
    tests = [
        ("unavailable_A_uniqueness", changed(certificate, lambda c: first(c, "unique").update(rule="A")), ()),
        ("unavailable_successor_uniqueness", changed(certificate, lambda c: first(c, "unique").update(rule="S")), ()),
        ("unchecked_stationarity_rule", changed(certificate, lambda c: first(c, "unique").update(op="Stat")), ()),
        ("rho_cannot_be_an_axiom", changed(certificate, lambda c:
         c["steps"].append({"op": "axiom", "name": "rho", "map": {"n": "n"}})), ()),
        ("inverse_cannot_be_an_elementary_lemma", changed(certificate, lambda c:
         c["steps"].append({"op": "elementary", "name": "inverse_I", "map": {"n": "n"}})), ()),
        ("wrong_U_B_template", changed(certificate, lambda c:
         first(c, "unique").update(body=["I", "x", "a"])), ()),
        ("eigenvariable_captures_passive_parameter", changed(certificate, lambda c:
         first(c, "unique").update(counter="a")), ()),
        ("target_captures_eigenvariable", changed(certificate, lambda c:
         first(c, "unique").update(target="z")), ()),
        ("undischarged_case_in_uniqueness", changed(certificate, lambda c:
         c["steps"][phase_unique].update(proof=phase_case["left"])), ()),
        ("substitution_changes_retained_assumption", changed(certificate, lambda c:
         c["steps"].append({"op": "inst", "proof": c["milestones"]["even_domain_decomposition"],
                             "map": {"n": ["0"]}})), ()),
        ("bad_equality_rewrite_path", changed(certificate, lambda c:
         first(c, "rewrite").update(path=[0])), ()),
        ("wrong_equation_for_rewrite", changed(certificate, lambda c:
         first(c, "rewrite").update(equation=first_refl)), ()),
        ("wrong_case_discharge", changed(certificate, lambda c:
         c["steps"][last_case].update(right_assumption=c["steps"][last_case]["left_assumption"])), ()),
        ("bad_successor_case_endpoint", changed(certificate, lambda c:
         first(c, "num_cases").update(successor=first(c, "num_cases")["base"])), ()),
        ("numerical_case_captures_parameter", changed(certificate, lambda c:
         first(c, "num_cases").update(counter="a")), ()),
        ("malformed_numerical_arity", changed(certificate, lambda c:
         first(c, "refl").update(term=["S", ["0"], ["0"]])), ()),
        ("formula_used_as_term", changed(certificate, lambda c:
         first(c, "refl").update(term=["eq", ["0"], ["0"]])), ()),
        ("forward_premise_reference", changed(certificate, lambda c:
         first(c, "trans").update(left=len(c["steps"]) + 1)), ()),
        ("wrong_fixed_point_equation", changed(certificate, lambda c:
         first(c, "no_fix").update(proof=first_refl)), ()),
        ("wrong_final_endpoint", changed(certificate, lambda c:
         c["steps"].append({"op": "refl", "term": "n"})), ()),
        ("rho_left_as_an_open_assumption", changed(certificate, lambda c:
         c["steps"].append({"op": "assume", "formula": ["eq", ["H", ["D", "n"]], "n"]})), ()),
    ]
    for interface in ("coverage", "parity", "no_fix_B", "E2", "H2", "AB", "BA", "nu2", "nuA"):
        tests.append(("missing_interface_" + interface, certificate, (interface,)))
    rejected = []
    for name, candidate, disabled in tests:
        try:
            verify(candidate, disabled=disabled)
        except Invalid as error:
            rejected.append({"test": name, "rejected": True, "reason": str(error)})
        else:
            raise RuntimeError("Invalid certificate accepted: " + name)

    output = {
        "python": sys.version,
        "optimization_level": sys.flags.optimize,
        "all_checks_passed": True,
        "positive_certificate": positive,
        "negative_controls": rejected,
        "producer_last_line": produced.stdout.strip().splitlines()[-1],
        "sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in sorted(ROOT.glob("*.py")) + [ROOT / "rho_certificate.json"]},
        "scope": "Symbolic derivation relative to the six listed elementary equation schemas, "
                 "parity range, numerical coverage and B fixed-point-freeness. "
                 "No Stat, rho, fusion, cancellation or inverse-iteration axiom. "
                 "Not a complete iPRA checker or a proof-assistant formalization.",
    }
    filename = "results_optimized.json" if sys.flags.optimize else "results.json"
    (ROOT / filename).write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"all_checks_passed": True, "nodes": positive["nodes"],
                      "U_B_applications": positive["inferences"]["unique"],
                      "negative_controls_rejected": len(rejected),
                      "optimization_level": sys.flags.optimize,
                      "receipt": filename}, indent=2))


if __name__ == "__main__":
    main()
