SYMBOLIC REPLAY OF THE NEW RETRACTION DERIVATION
=============================================

Run with Python 3 and the standard library:

    python3 verification/verify_all.py
    python3 -O verification/verify_all.py

Run these commands from the package directory. Each reconstructs the same
rho_certificate.json and replays it using checker.py. The two result receipts
record the ordinary and optimized runs separately. The checker uses explicit
exceptions for all validity conditions, not Python assert statements.

WHAT IS CHECKED

The certificate has 1,167 symbolic proof nodes and 17 explicit applications of
the one fixed-update uniqueness rule U_B. It proves

    H(D(n)) = n

for an arbitrary free numerical variable n, with no remaining local assumptions.
This universally generalizes to the retraction sentence. The trace includes:

* the inherited phase-switch proof of zero stationarity, expanded at every use;
* the doubled clock and negative diagonal, without assuming a retraction;
* each used U_A inference, expanded into U_B applications via sign conjugation;
* both equivariance laws of the new signed action T, including finite cases;
* both fusion equations, with their recurrence premises checked literally;
* explicit two-sided inverses to every I(n,.) on arbitrary inputs;
* every used arbitrary-value stationarity inference, expanded by twisting,
  U_B, and the already proved explicit inverse;
* the raw two-periodic correction and its two stationary phase selections;
* the whole-domain even/odd decomposition;
* the double-speed proof that c=H o D fixes the image of D;
* the final retraction equation.

There is no stationarity, rho, action-fusion, iterator-cancellation, inverse-
iteration, successor-uniqueness, or unrestricted induction axiom in checker.py.
The only uniqueness instruction it accepts is the stated U_B rule.

THE EXACT RETAINED ELEMENTARY INTERFACE

The following six equation schemas are accepted as previously proved finite-
case lemmas, with all numerical arguments arbitrary:

    E(S(S(u))) = E(u)
    H(S(S(u))) = S(H(u))
    A(B(u)) = u
    B(A(u)) = u
    nu(nu(u)) = u
    nu(A(u)) = B(nu(u))

The checker additionally retains:

    E(u)=0 or E(u)=1,
    u=0 or u=S(P(u)),
    B(u)=u implies falsity.

These are exactly the elementary interface assumptions; the report proves
them by the stated finite cases from the PR equations, coverage, and separation.
The replay does not itself expand those finite-case proofs. In particular,
fixed-point-freeness uses separation in the report. No claim of having removed
that logical boundary is intended.

The remaining schemas are the explicit defining equations of P,C,delta,E,D,H,
B,A,nu,I,J and the transparent abbreviations N,T,R,G,Q,c. The full list appears
in BASE_EQ in checker.py. A certificate cannot add a new equation schema.
Descriptions are represented here by these fixed named helpers: the replay
does not implement the grammar of every primitive-recursive description.

CHECKER INFERENCES AND SCOPE

Numerical terms are checked for symbol and arity. Formulas in the replay are
equations, disjunctions and falsity. The primitive proof operations are equality
reflexivity, symmetry, transitivity and congruence; exact-path equality rewrites;
substitution into a universally generalizable previously proved equation;
dependency-tracked assumptions and disjunction elimination; numerical cases;
the fixed-point-free interface and falsity elimination; and U_B.

The numerical-case operation checks both the zero and successor endpoints and
the fresh-variable condition. It is the pointwise zero/successor case rule
derived from coverage, not induction: it supplies no induction hypothesis.

For U_B, the checker verifies the exact recurrence

    f(S(z),p) = B(f(z,p))

and returns exactly f(t,p)=I(t,f(0,p)). It verifies that z is absent from the
target, passive template variables, and every undischarged assumption. Each
proof node carries its local assumption dependencies. A substitution cannot
change the variables of an undischarged assumption. Case elimination removes
only its specified two assumptions, and the fixed final goal must have none.

The producer is untrusted. It uses term rewriting to construct certificates,
but every rewrite emits a previously justified equation and an exact path that
the checker independently replays. The producer shares the fixed syntax and
interface declarations with checker.py; this avoids claiming two independently
invented mathematical interfaces. It never calls the verifier as a theorem
oracle. There is no eval, imported automated prover, numerical test used as a
universal theorem, or implicit appeal to induction.

NEGATIVE CONTROLS

verify_all.py rejects 30 targeted mutations or missing-interface replays. They
cover changed uniqueness updates, an unavailable Stat rule, attempts to inject
rho or an inverse as an axiom, wrong recurrence templates, parameter/target
capture, an undischarged case assumption at U_B, substitution changing retained
data, broken equation paths, wrong rewrite equations, wrong case discharge,
wrong zero/successor endpoints, malformed numerical terms, forward references,
a wrong fixed-point equation, a wrong final goal, and a final open assumption.
Each retained elementary interface is separately disabled and the corresponding
replay must fail. Such a failed replay is not an independence theorem about
removing the interface from arithmetic.

WHAT IS NOT CLAIMED

This is a relative symbolic certificate for the new proof. It is not a complete
iPRA proof checker, not a mechanically verified proof of the checker's own
soundness, not a Lean/Rocq formalization, and not a competitor in the current
complete-checker size benchmark. The mathematical bi-interpretability proof and
the reconstruction of full quantifier-free induction are in the report.

PROVENANCE

The replay follows the dependency-tracking and exact-uniqueness interface design
of the phase-retraction draft's scoped verification package. That older package
checks phase switching and rho-to-successor uniqueness; it assumes rho in its
second proof. The present producer, central derivation, expanded interface,
certificate, validation controls and receipt are new. The old files are not
silently reused as proof of the new theorem. Source draft:

    ipra_phase_retraction_2026-11-08.zip
    ProveIt commit 89fd4b4c5cd158259b1f2846f63e3d98f053553c

