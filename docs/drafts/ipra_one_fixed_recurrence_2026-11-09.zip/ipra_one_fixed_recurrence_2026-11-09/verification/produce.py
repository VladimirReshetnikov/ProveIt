"""Untrusted producer for a large explicit equational rho certificate.

Shared imports specify syntax and the disclosed interface only. No call to the
replay verifier, theorem oracle, evaluator, induction rule or Stat rule occurs.
Every reduction below emits elementary, checkable proof nodes.
"""
import json
from pathlib import Path

from checker import BASE_EQ, ELEMENTARY_EQ, T, Z, O, S, SS, EQ, free, subst


def match(pattern, value, flexible, mapping=None):
    mapping = {} if mapping is None else mapping
    if isinstance(pattern, str):
        if pattern not in flexible:
            return mapping if pattern == value else None
        if pattern in mapping:
            return mapping if mapping[pattern] == value else None
        mapping[pattern] = value
        return mapping
    if not isinstance(value, tuple) or len(pattern) != len(value) or pattern[0] != value[0]:
        return None
    for p, v in zip(pattern[1:], value[1:]):
        mapping = match(p, v, flexible, mapping)
        if mapping is None:
            return None
    return mapping


class Builder:
    def __init__(self):
        self.steps, self.values, self.deps = [], [], []
        self.milestones, self.cache = {}, {}

    def add(self, step, output, deps=frozenset()):
        self.steps.append(step); self.values.append(output); self.deps.append(frozenset(deps))
        return len(self.steps) - 1

    def refl(self, value):
        return self.add({"op": "refl", "term": value}, EQ(value, value))

    def schema(self, name, mapping):
        source = BASE_EQ if name in BASE_EQ else ELEMENTARY_EQ
        key = (name, tuple(sorted(mapping.items())))
        if key not in self.cache:
            self.cache[key] = self.add({"op": "axiom" if name in BASE_EQ else "elementary",
                                       "name": name, "map": mapping}, subst(source[name], mapping))
        return self.cache[key]

    def instantiate(self, proof, mapping):
        mapping = {k: v for k, v in mapping.items() if k != v}
        if not mapping:
            return proof
        key = ("inst", proof, tuple(sorted(mapping.items())))
        if key not in self.cache:
            self.cache[key] = self.add({"op": "inst", "proof": proof, "map": mapping},
                                       subst(self.values[proof], mapping), self.deps[proof])
        return self.cache[key]

    def sym(self, proof):
        _, a, b = self.values[proof]
        return self.add({"op": "sym", "proof": proof}, EQ(b, a), self.deps[proof])

    def tr(self, left, right):
        _, a, b = self.values[left]; _, c, d = self.values[right]
        if b != c:
            raise RuntimeError(f"Bad producer chain at {len(self.steps)}:\n{b}\n{c}")
        return self.add({"op": "trans", "left": left, "right": right}, EQ(a, d), self.deps[left] | self.deps[right])

    def cong(self, name, *proofs):
        return self.add({"op": "cong", "symbol": name, "proofs": proofs},
                        EQ(T(name, *(self.values[p][1] for p in proofs)),
                           T(name, *(self.values[p][2] for p in proofs))),
                        frozenset().union(*(self.deps[p] for p in proofs)))

    def rewrite(self, proof, equation, path, reverse=False):
        old, new = self.values[equation][1:]
        if reverse:
            old, new = new, old
        def replace(v, p):
            if not p:
                if v != old:
                    raise RuntimeError("Producer rewrite mismatch")
                return new
            i, *tail = p
            return (*v[:i], replace(v[i], tail), *v[i + 1:])
        return self.add({"op": "rewrite", "proof": proof, "equation": equation,
                         "path": path, "reverse": reverse}, replace(self.values[proof], path),
                        self.deps[proof] | self.deps[equation])

    def find_rewrite(self, value, rules, path=()):
        for rule in rules:
            reverse = isinstance(rule, tuple)
            rule = rule[0] if reverse else rule
            if isinstance(rule, str):
                spec = (BASE_EQ | ELEMENTARY_EQ)[rule]
                pattern, result = spec[1:]
                flexible = free(spec)
            else:
                spec = self.values[rule]
                pattern, result = spec[1:]
                blocked = set().union(*(free(self.values[i]) for i in self.deps[rule])) if self.deps[rule] else set()
                flexible = free(spec) - blocked
            if reverse:
                pattern, result = result, pattern
            mapping = match(pattern, value, flexible)
            if mapping is not None and free(result) <= set(mapping) | (free(spec) - flexible):
                # Fill schematic variables unused on the matched side with themselves.
                # Such a variable could introduce a new parameter, so never invent it.
                if isinstance(rule, str) and set(mapping) != free(spec):
                    continue
                instance = self.schema(rule, mapping) if isinstance(rule, str) else self.instantiate(rule, mapping)
                if subst(result, mapping) != value:
                    return path, instance, reverse
        if isinstance(value, tuple):
            for i, child in enumerate(value[1:], 1):
                found = self.find_rewrite(child, rules, (*path, i))
                if found is not None:
                    return found
        return None

    def norm(self, value, rules):
        proof = self.refl(value)
        for _ in range(2000):
            found = self.find_rewrite(self.values[proof][2], rules)
            if found is None:
                return proof
            path, equation, reverse = found
            proof = self.rewrite(proof, equation, (2, *path), reverse)
        raise RuntimeError("Producer normalization did not terminate")

    def rhs(self, proof, rules):
        return self.tr(proof, self.norm(self.values[proof][2], rules))

    def prove(self, left, right, rules):
        pl, pr = self.norm(left, rules), self.norm(right, rules)
        if self.values[pl][2] != self.values[pr][2]:
            raise RuntimeError(f"Normalization mismatch at node {len(self.steps)}\nLEFT {self.values[pl][2]}\nRIGHT {self.values[pr][2]}\nRULES {rules}")
        return self.tr(pl, self.sym(pr))

    def finish(self, proof, left, right, rules):
        return self.tr(self.tr(self.prove(left, self.values[proof][1], rules), proof),
                       self.prove(self.values[proof][2], right, rules))

    def assume(self, value):
        return self.add({"op": "assume", "formula": value}, value, {len(self.steps)})

    def range(self, name, arg):
        value = (("or", EQ(arg, Z), EQ(arg, S(T("P", arg)))) if name == "coverage"
                 else ("or", EQ(T("E", arg), Z), EQ(T("E", arg), O)))
        return self.add({"op": "range", "name": name, "arg": arg}, value)

    def split(self, disjunction):
        return self.assume(self.values[disjunction][1]), self.assume(self.values[disjunction][2])

    def cases(self, disj, la, lp, ra, rp):
        if self.values[lp] != self.values[rp]:
            raise RuntimeError("Different case endpoints")
        return self.add({"op": "cases", "disjunction": disj, "left_assumption": la,
                         "left": lp, "right_assumption": ra, "right": rp}, self.values[lp],
                        self.deps[disj] | (self.deps[lp] - {la}) | (self.deps[rp] - {ra}))

    def numeric_cases(self, body, base, successor, counter="z", target="n"):
        return self.add({"op": "num_cases", "body": body, "base": base, "successor": successor,
                         "counter": counter, "target": target}, subst(body, {"x": target}),
                        self.deps[base] | self.deps[successor])

    def unique(self, body, recurrence, counter="z", target="n"):
        return self.add({"op": "unique", "rule": "B", "body": body,
                         "counter": counter, "target": target, "proof": recurrence},
                        EQ(subst(body, {"x": target}), T("I", target, subst(body, {"x": Z}))),
                        self.deps[recurrence])

    def mark(self, name, proof):
        self.milestones[name] = proof
        print(name, proof, flush=True)
        return proof

    def zero_stat(self, body, recurrence, base, target="n", counter="z"):
        """Expand the inherited phase-switch proof; no zero-Stat replay rule."""
        rz = subst(body, {"x": counter})
        rt = subst(body, {"x": target})
        phase = T("C", body, T("I", "x", Z), T("B", T("I", "x", Z)))
        d = self.range("coverage", rz); la, ra = self.split(d)
        left = self.prove(subst(phase, {"x": S(counter)}), T("B", subst(phase, {"x": counter})),
                          [recurrence, la, "IS", "C0", "CS"])
        right = self.prove(subst(phase, {"x": S(counter)}), T("B", subst(phase, {"x": counter})),
                           [recurrence, ra, "IS", "C0", "CS"])
        rec = self.cases(d, la, left, ra, right)
        result = self.unique(phase, rec, counter, target)
        phase0 = self.prove(subst(phase, {"x": Z}), Z, [base, "I0", "C0"])
        result = self.rhs(result, [phase0])
        dt = self.range("coverage", rt); lt, rr = self.split(dt)
        shift = self.prove(subst(phase, {"x": target}), T("B", T("I", target, Z)), [rr, "CS"])
        fixed = self.tr(self.sym(shift), result)
        bot = self.add({"op": "no_fix", "proof": fixed}, ("bot",), self.deps[fixed])
        explosion = self.add({"op": "explode", "proof": bot, "formula": EQ(rt, Z)}, EQ(rt, Z), self.deps[bot])
        return self.cases(dt, lt, lt, rr, explosion)

    def reverse_unique(self, body, recurrence, target="n", counter="z"):
        """Derive this U_A application by two U_B applications and nu."""
        nu_body = T("nu", body)
        rec1 = self.prove(subst(nu_body, {"x": S(counter)}), T("B", subst(nu_body, {"x": counter})),
                          [recurrence, "nuA"])
        p1 = self.unique(nu_body, rec1, counter, target)
        f0 = subst(body, {"x": Z})
        nu_canonical = T("nu", T("J", "x", f0))
        rec2 = self.prove(subst(nu_canonical, {"x": S(counter)}),
                          T("B", subst(nu_canonical, {"x": counter})), ["JS", "nuA"])
        p2 = self.unique(nu_canonical, rec2, counter, target)
        j0 = self.schema("J0", {"a": f0})
        p2 = self.rewrite(p2, j0, (2, 2, 1))
        equal = self.tr(p1, self.sym(p2))
        twice = self.cong("nu", equal)
        return self.finish(twice, subst(body, {"x": target}), T("J", target, f0), ["nu2"])

    def full_stat(self, body, recurrence, inverse, target="n", counter="z"):
        """Expand twisting, U_B, and the already proved inverse equation."""
        twisted = T("I", "x", body)
        step = self.prove(subst(twisted, {"x": S(counter)}),
                          T("B", subst(twisted, {"x": counter})), [recurrence, "IS"])
        unique = self.unique(twisted, step, counter, target)
        unique = self.rhs(unique, ["I0"])
        cancelled = self.cong("T", self.refl(T("N", target)), unique)
        return self.finish(cancelled, subst(body, {"x": target}), subst(body, {"x": Z}),
                           [inverse, "I0", "J0"])


def build():
    b = Builder()
    n, z, a, u = "n", "z", "a", "u"
    B = lambda v: T("B", v)
    A = lambda v: T("A", v)
    D = lambda v: T("D", v)
    E = lambda v: T("E", v)
    H = lambda v: T("H", v)
    N = lambda v: T("N", v)
    I = lambda v, w: T("I", v, w)
    J = lambda v, w: T("J", v, w)
    TT = lambda v, w: T("T", v, w)
    R = lambda v: T("R", v)
    G = lambda v: T("G", v)
    Q = lambda v: T("Q", v)
    c = lambda v: T("c", v)
    small = ["E0", "H0", "D0", "P0", "PS", "C0", "CS", "delta", "ES", "I0", "J0"]
    e1 = b.prove(E(O), O, small)
    h1 = b.prove(H(O), Z, ["HS", *small])
    b0 = b.prove(B(Z), SS(Z), ["Bdef", *small])
    b1 = b.prove(B(O), Z, ["Bdef", *small])

    body = B(I("x", a))
    rec = b.prove(subst(body, {"x": S(z)}), B(subst(body, {"x": z})), ["IS"])
    bi = b.rhs(b.unique(body, rec), ["I0"])
    ib = b.mark("I_commutes_B", b.sym(bi))

    body = E(D("x"))
    rec = b.prove(subst(body, {"x": S(z)}), subst(body, {"x": z}), ["DS", "E2"])
    base = b.prove(subst(body, {"x": Z}), Z, ["D0", "E0"])
    ed = b.mark("doubled_parity", b.zero_stat(body, rec, base))
    rec = b.prove(D(S(z)), B(D(z)), ["DS", "Bdef", ed, "C0"])
    dclock = b.mark("positive_clock", b.sym(b.rhs(b.unique(D("x"), rec), ["D0"])))

    n0 = b.prove(N(Z), Z, ["Ndef", "C0"])
    ns = b.prove(N(S(n)), S(D(n)), ["Ndef", "CS", "PS"])
    neg_body = EQ(B(N(S("x"))), N("x"))
    neg0 = b.prove(B(N(O)), N(Z), [ns, "D0", b1, n0])
    negs = b.prove(B(N(SS(z))), N(S(z)), [ns, "DS", "Bdef", "ES", ed, "delta", "C0", "CS", "PS"])
    bn = b.mark("backward_clock", b.numeric_cases(neg_body, neg0, negs))
    body = I("x", N("x"))
    rec = b.prove(subst(body, {"x": S(z)}), subst(body, {"x": z}), ["IS", bi, bn])
    base = b.prove(subst(body, {"x": Z}), Z, ["I0", n0])
    neg = b.mark("negative_diagonal", b.zero_stat(body, rec, base))

    body = B(J("x", a))
    rec = b.prove(subst(body, {"x": S(z)}), A(subst(body, {"x": z})), ["JS", "BA", "AB"])
    bj = b.rhs(b.reverse_unique(body, rec), ["J0"])
    jb = b.mark("J_commutes_B", b.sym(bj))
    body = A(I("x", a))
    rec = b.prove(subst(body, {"x": S(z)}), B(subst(body, {"x": z})), ["IS", "AB", "BA"])
    ai = b.rhs(b.unique(body, rec), ["I0"])
    ia = b.mark("I_commutes_A", b.sym(ai))

    t0 = b.prove(TT(Z, a), a, ["Tdef", "E0", "H0", "C0", "I0"])
    t1 = b.prove(TT(O, a), A(a), ["Tdef", e1, h1, "CS", "JS", "J0"])
    d = b.range("parity", n); la, ra = b.split(d)
    left = b.prove(TT(n, B(a)), B(TT(n, a)), ["Tdef", la, "C0", ib, jb])
    right = b.prove(TT(n, B(a)), B(TT(n, a)), ["Tdef", ra, "CS", ib, jb])
    t_arg = b.mark("action_state_equivariance", b.cases(d, la, left, ra, right))

    fbody = EQ(TT(B("x"), a), B(TT("x", a)))
    f0 = b.prove(TT(B(Z), a), B(TT(Z, a)), [b0, t0, "Tdef", "E2", "H2", "E0", "H0", "C0", "IS", "I0"])
    f1 = b.prove(TT(B(O), a), B(TT(O, a)), [b1, t0, t1, "BA"])
    du = b.range("parity", u); eu0, eu1 = b.split(du)
    be = b.prove(B(SS(u)), SS(SS(u)), ["Bdef", "E2", eu0, "C0"])
    bo = b.prove(B(SS(u)), u, ["Bdef", "E2", eu1, "CS", "PS"])
    even = b.prove(TT(B(SS(u)), a), B(TT(SS(u), a)), [be, "Tdef", "E2", "H2", eu0, "C0", "IS"])
    odd = b.prove(TT(B(SS(u)), a), B(TT(SS(u), a)), [bo, "Tdef", "E2", "H2", eu1, "CS", "JS", "BA"])
    fss = b.cases(du, eu0, even, eu1, odd)
    fs = b.numeric_cases(subst(fbody, {"x": S("x")}), f1, fss, counter=u, target=z)
    t_counter = b.mark("action_counter_equivariance", b.numeric_cases(fbody, f0, fs))

    body = TT(I("x", "b"), a)
    rec = b.prove(subst(body, {"x": S(z)}), B(subst(body, {"x": z})), ["IS", t_counter])
    fusion1 = b.mark("action_fusion_counter", b.rhs(b.unique(body, rec), ["I0"]))
    body = TT("r", I("x", a))
    rec = b.prove(subst(body, {"x": S(z)}), B(subst(body, {"x": z})), ["IS", t_arg])
    fusion2 = b.mark("action_fusion_state", b.rhs(b.unique(body, rec), ["I0"]))
    p1 = b.instantiate(fusion1, {"n": "p", "b": N("p")})
    p1 = b.finish(p1, a, I("p", TT(N("p"), a)), [neg, t0])
    inv_right = b.mark("explicit_right_inverse", b.sym(p1))
    p2 = b.instantiate(fusion2, {"n": "p", "r": N("p")})
    inv_left = b.mark("explicit_left_inverse", b.tr(p2, inv_right))

    body = I("x", J("x", a))
    rec = b.prove(subst(body, {"x": S(z)}), subst(body, {"x": z}), ["IS", "JS", ia, "BA"])
    ij = b.mark("I_J_inverse_via_derived_Stat", b.rhs(b.full_stat(body, rec, inv_left), ["I0", "J0"]))
    body = J("x", I("x", a))
    rec = b.prove(subst(body, {"x": S(z)}), subst(body, {"x": z}), ["JS", "IS", jb, "AB"])
    ji = b.mark("J_I_inverse_via_derived_Stat", b.rhs(b.full_stat(body, rec, inv_left), ["I0", "J0"]))

    r0 = b.prove(R(Z), Z, ["Rdef", "E0", "H0", "C0", "J0"])
    r1 = b.prove(R(O), O, ["Rdef", e1, h1, "CS", "I0"])
    d = b.range("parity", n); en0, en1 = b.split(d)
    be = b.prove(B(n), SS(n), ["Bdef", en0, "C0"])
    ao = b.prove(A(n), SS(n), ["Adef", en1, "CS"])
    even = b.prove(R(SS(n)), R(n), ["Rdef", "E2", "H2", en0, "C0", (be,), "JS", jb, "AB"])
    odd = b.prove(R(SS(n)), R(n), ["Rdef", "E2", "H2", en1, "CS", (ao,), "IS", ia, "BA"])
    period = b.mark("raw_correction_period", b.cases(d, en0, even, en1, odd))

    def stationary_phase(symbol, definition):
        fn = lambda v: T(symbol, v)
        d = b.range("parity", z); la, ra = b.split(d)
        rules = [definition, "ES", "delta", "C0", "CS", period]
        left = b.prove(fn(S(z)), fn(z), [la, *rules])
        right = b.prove(fn(S(z)), fn(z), [ra, *rules])
        return b.cases(d, la, left, ra, right)
    gs, qs = stationary_phase("G", "Gdef"), stationary_phase("Q", "Qdef")
    gzero = b.mark("even_phase_derived_Stat", b.rhs(b.full_stat(G("x"), gs, inv_left), ["Gdef", "E0", "C0", r0]))
    qone = b.mark("odd_phase_derived_Stat", b.rhs(b.full_stat(Q("x"), qs, inv_left), ["Qdef", "E0", "C0", r1]))
    d = b.range("parity", n); la, ra = b.split(d)
    gr = b.prove(G(n), R(n), ["Gdef", la, "C0"])
    qr = b.prove(Q(n), R(n), ["Qdef", ra, "CS"])
    left = b.tr(b.tr(b.sym(gr), gzero), b.sym(la))
    right = b.tr(b.tr(b.sym(qr), qone), b.sym(ra))
    residue = b.mark("raw_correction_equals_parity", b.cases(d, la, left, ra, right))

    body = S(D("x"))
    rec = b.prove(subst(body, {"x": S(z)}), A(subst(body, {"x": z})),
                  ["DS", "Adef", "ES", ed, "delta", "C0", "CS"])
    odd_clock = b.mark("negative_odd_clock", b.sym(b.rhs(b.reverse_unique(body, rec), ["D0"])))
    d = b.range("parity", n); even_a, odd_a = b.split(d)
    even_branch = b.prove(R(n), J(H(n), n), ["Rdef", even_a, "C0"])
    odd_branch = b.prove(R(n), I(H(n), n), ["Rdef", odd_a, "CS"])
    jeq = b.tr(b.tr(b.sym(even_branch), residue), even_a)
    ieq = b.tr(b.tr(b.sym(odd_branch), residue), odd_a)
    pe = b.cong("I", b.refl(H(n)), jeq)
    po = b.cong("J", b.refl(H(n)), ieq)
    de = b.mark("even_domain_decomposition", b.finish(pe, n, D(H(n)), [ij, dclock]))
    do = b.mark("odd_domain_decomposition", b.finish(po, n, S(D(H(n))), [ji, odd_clock]))

    c0 = b.prove(c(Z), Z, ["cdef", "D0", "H0"])
    cs = b.prove(c(S(n)), S(c(n)), ["cdef", "DS", "H2"])
    body = c(D("x"))
    speed = b.prove(subst(body, {"x": S(z)}), SS(subst(body, {"x": z})), ["DS", cs])
    base = b.prove(subst(body, {"x": Z}), Z, ["D0", c0])
    ebody = E(body)
    erec = b.prove(subst(ebody, {"x": S(z)}), subst(ebody, {"x": z}), [speed, "E2"])
    ebase = b.prove(subst(ebody, {"x": Z}), Z, [base, "E0"])
    even_image = b.zero_stat(ebody, erec, ebase)
    recurrence = b.prove(subst(body, {"x": S(z)}), B(subst(body, {"x": z})), [speed, "Bdef", even_image, "C0"])
    cd = b.mark("c_fixes_double_image", b.rhs(b.unique(body, recurrence), [base, dclock]))

    ce = b.cong("c", de)
    ce = b.rhs(ce, [cd])
    ce = b.tr(ce, b.sym(de))
    co = b.cong("c", do)
    co = b.rhs(co, [cs, cd])
    co = b.tr(co, b.sym(do))
    raw_rho = b.cases(d, even_a, ce, odd_a, co)
    b.mark("rho", b.finish(raw_rho, H(D(n)), n, ["cdef"]))
    return {"task": "derive_rho", "steps": b.steps, "milestones": b.milestones}


if __name__ == "__main__":
    path = Path(__file__).resolve().parent / "rho_certificate.json"
    certificate = build()
    path.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(certificate['steps'])} proof nodes to {path.name}")
