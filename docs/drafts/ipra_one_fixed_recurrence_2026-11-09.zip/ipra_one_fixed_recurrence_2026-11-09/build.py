"""Compile the report with shell escape disabled; reject unresolved references."""
from pathlib import Path
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def tex_environment(outputs):
    env = os.environ.copy()
    probe = subprocess.run(["kpsewhich", "pdflatex.fmt"], env=env,
                           text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if probe.returncode == 0 and probe.stdout.strip():
        return env
    # Some minimal Debian images include the complete TeX trees but omit their
    # generated format databases. Initialize only a local disposable cache.
    trees = [Path("/usr/share/texmf"), Path("/usr/share/texlive/texmf-dist")]
    if not all(p.is_dir() for p in trees):
        raise SystemExit("Configure the installed LaTeX formats before building")
    cache = ROOT / ".texcache"
    cache.mkdir(exist_ok=True)
    env["TEXMF"] = "{" + ",".join(map(str, [cache, *trees])) + "}"
    target = cache / "web2c/pdftex/pdflatex.fmt"
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        bootstrap = subprocess.run(
            ["pdftex", "-ini", "-etex", "-no-shell-escape",
             "-interaction=nonstopmode", "-halt-on-error", "-jobname=pdflatex",
             "-progname=pdflatex", "pdflatex.ini"],
            cwd=cache, env=env, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        outputs.append(bootstrap.stdout)
        if bootstrap.returncode:
            raise SystemExit(bootstrap.stdout[-6000:])
        shutil.move(cache / "pdflatex.fmt", target)
    maps = [trees[0] / "fonts/map/dvips/lm/lm.map"]
    maps += sorted((trees[1] / "fonts/map/dvips/amsfonts").glob("*.map"))
    fontmap = cache / "fonts/map/pdftex/local/pdftex.map"
    fontmap.parent.mkdir(parents=True, exist_ok=True)
    fontmap.write_text("\n".join(p.read_text() for p in maps))
    return env


def main():
    executable = shutil.which("pdflatex")
    if not executable:
        raise SystemExit("pdflatex is required to build report.pdf")
    outputs = []
    env = tex_environment(outputs)
    for _ in range(3):
        proc = subprocess.run(
            [executable, "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "report.tex"],
            cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        outputs.append(proc.stdout)
        if proc.returncode:
            (ROOT / "evidence/latex_build.txt").write_text("\n".join(outputs))
            raise SystemExit(proc.stdout[-6000:])
    (ROOT / "evidence/latex_build.txt").write_text("\n".join(outputs))
    log = (ROOT / "report.log").read_text()
    if "There were undefined references" in log or "undefined citations" in log:
        raise SystemExit("Unresolved references; inspect report.log")
    print("Compiled report.pdf")


if __name__ == "__main__":
    main()
