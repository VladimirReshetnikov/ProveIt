ONE FIXED RECURRENCE SUFFICES FOR iPRA
9 November 2026

MAIN RESULT
The retraction sentence H(D(n))=n in the current phase-retraction proposal
is derivable from its other principles. Ordinary intuitionistic equality
logic, all PR defining equations, numerical coverage, separation, and
uniqueness for one fixed signed-counter update B therefore suffice for
full first-order iPRA, with identity-domain bi-interpretations.

The new proof constructs signed action and explicit inverses of all signed
iterates, derives arbitrary-value stationarity, and reconstructs the raw
parity representation of every element. It uses no hidden induction or
premature cancellation of doubling.

Both remaining numerical boundary sentences are independently necessary
when the rest of this basis is held fixed. Omitting separation leaves a
singleton model; omitting coverage leaves large direct powers with
parameter-fixing involutions, obstructing ordinary bi-interpretability.

LIMITATION
This is a mathematical deletion from a current proposal. It is not a new
complete checker below the existing 309-token / 344-AST / 864-byte source
frontier and is not an absolute-minimality claim. The full PR grammar and
ordinary logic still count. Novelty is relative to the inspected corpus.

SECONDARY RESULT
Linear fibres extend the prior scalar zero-test obstruction to the entire
counter-dependent PR description language, even retaining cancellative
commutative-semiring laws and designated clock/identity iterator repairs.
The construction is not a model of the positive T_B theory.

CONTENTS
report.tex, report.pdf: main manuscript and compiled PDF.
report_standalone.tex: the same complete manuscript in one source file.
sections/: editable mathematical and verification sections.
verification/: symbolic replay with an explicit stated trust boundary.
code/audit_comparators.py: static whole-source comparison; never executes
  the inherited checker sources.
code/check_linear_identities.py: exact local polynomial identities.
comparison/: nineteen unchanged prior sources and their retained license.
evidence/: provenance, measurements, executed verification results, reviews.
build.py: three pdflatex passes, with shell escape disabled.
package.py: standalone-source generation, manifest and verified ZIP creation.
MANIFEST.json: sizes and SHA-256 hashes of packaged files.

REPRODUCTION
Python 3.12.14 reproduces the precise AST/unparser benchmark. Core scripts
use the Python standard library. A LaTeX installation with pdflatex,
amsmath, amsthm, lmodern, microtype, geometry, booktabs, enumitem, fancyhdr,
and hyperref is required only to rebuild the PDF.
If a minimal Debian/TeX Live installation lacks generated formats, build.py
initializes a local disposable .texcache using its installed resources.
It does not download packages or modify the system TeX installation.

From this extracted directory:
  python3 code/audit_comparators.py
  python3 code/check_linear_identities.py
  python3 verification/verify_all.py
  python3 -O verification/verify_all.py
  python3 build.py
  python3 package.py

Read verification/README.txt for the proof-replay scope. The entire
bi-interpretation and nonstandard model construction are written proofs,
not claimed as a Lean or Rocq formalization. The symbolic replayer is not
a complete iPRA checker or a size-record contender.

ACTUAL VERIFICATION
The relative symbolic replay has 1,167 proof nodes, 17 applications of U_B,
and no remaining assumptions at H(D(n))=n. Ordinary and optimized Python
runs accept it and reject all 30 targeted negative controls. Six elementary
equation schemas, coverage, parity range and B fixed-point-freeness form
the retained interface; their finite-case proofs are written in the report.
No stationarity, inverse-iteration, fusion or rho axiom is accepted.
Eleven exact polynomial identity checks and a damaged-law control also pass.

SOURCE SNAPSHOT
VladimirReshetnikov/ProveIt, commit
89fd4b4c5cd158259b1f2846f63e3d98f053553c.
All eleven archives in docs/drafts were inspected. The older relative
falsity archive, used for attribution of the scalar zero-test obstruction,
was read at 7f6aa8877220af774b30f2c132a84be3ae985703.

No repository was modified or published. No network is needed to replay
the included checks or compile the report.
