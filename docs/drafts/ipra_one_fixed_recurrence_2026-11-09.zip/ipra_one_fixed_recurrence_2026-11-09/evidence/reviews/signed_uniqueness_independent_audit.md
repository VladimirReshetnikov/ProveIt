# Independent audit: one signed uniqueness rule derives the missing retraction

Result: the corpus agent's candidate passes an independent algebraic and dependency audit. The proof uses the full fixed PR-description signature, Cov, Sep, ordinary intuitionistic logic, and contextual U_B. It does not use rho, doubling cancellation, general equation induction, quantified induction, or a pre-existing equality detector.

## Setup

C(0,a,b)=a and C(Sn,a,b)=b. P is predecessor; delta is the zero test with delta0=1, delta(Sn)=0. Parity E satisfies E0=0, E(Sn)=delta(E n). Doubling D satisfies D0=0, D(Sn)=S^2 Dn. Half H satisfies H0=0 and H(Sn)=C(E n,Hn,S Hn).

The signed successor is

    B(u)=C(Eu,S^2u,P^2u).

Write I=I_B. The primitive contextual uniqueness rule is

    Gamma |- f(Sz,p)=B(f(z,p))
    ----------------------------------
    Gamma |- f(t,p)=I(t,f(0,p)).

All passive parameters are fixed, and z is absent from retained data. Prior phase-retraction results available without rho are:

- parity is Boolean; E(S^2n)=E n;
- H(S^2n)=S Hn;
- B has no fixed point;
- zero-base stationarity;
- E(Dn)=0 and I(n,0)=Dn;
- negative counter N0=0, N(Sn)=S Dn satisfies B(N(Sn))=Nn;
- I(n,Nn)=0;
- I commutes with B.

These ingredients have explicit proofs in the prior phase draft. Their dependencies do not include rho.

## 1. The inverse update and U_A

Define

    A(u)=C(Eu,C(u,1,P^2u),S^2u),
    sigma(u)=C(Eu,C(u,0,Pu),Su).

Finite zero/successor cases, parity cases, and P's defining equations establish

    AB=BA=id, sigma^2=id, sigma A=B sigma.

There is no induction here. Let J=I_A. From a proposed A recurrence for f, both sigma(f(n)) and sigma(J(n,f0)) satisfy the B recurrence with common initial value sigma(f0). Two U_B instances identify them; apply sigma to obtain the contextual U_A rule. Consequently J commutes with A, and with B using AB=BA=id. Similarly I commutes with A as well as B.

## 2. Full stationarity is available

Define

    T(r,a)=C(Er, I(Hr,a), J(S(Hr),a)).

Then T(0,a)=a and T(Br,a)=B(T(r,a)). For the latter:

- if Er=0, Br=S^2r and H(Br)=S Hr, so use I's successor equation;
- if r=1, Br=0,Hr=0, and B(J(1,a))=B(Aa)=a;
- if Er=1 and r=S^2v, then Ev=1, Br=v, Hr=S Hv, and B(J(S^2 Hv,a))=J(S Hv,a).

Those cases are exhaustive by Cov and the Boolean parity laws. For fixed r, T(r,.) also commutes with B by the I/J commutations. U_B therefore yields, with independent fixed parameters,

    T(I(n,b),a)=I(n,T(b,a)),
    T(r,I(n,a))=I(n,T(r,a)).

Substitute b=Np,n=p only after proving the first uniform identity. Since I(p,Np)=0, these two identities show that T(Np,.) is a two-sided inverse of I(p,.).

For any term r satisfying the stationary premise r(Sn,p)=r(n,p) in a retained context, the term f(n)=I(n,r(n,p)) satisfies the B recurrence. U_B gives

    I(t,r(t,p))=I(t,r(0,p)).

Apply T(Nt,.) to get r(t,p)=r(0,p). This derives arbitrary-value stationarity, not only the prior zero-base instance. Every eigenvariable condition is inherited because the newly inserted functions are fixed terms and the same passive parameters remain fixed.

## 3. I and J are inverse at equal counters

Apply full stationarity to

    F(n)=I(n,J(n,a)), G(n)=J(n,I(n,a)).

For F, the step is

    I(Sn,J(Sn,a))
      = B(I(n,A(J(n,a))))
      = B(A(I(n,J(n,a))))
      = F(n).

The other case uses J's commutation with B. Both bases equal a. Hence

    I(n,J(n,a))=a=J(n,I(n,a)).

This does not assert any injectivity in the counter n. It is only bijectivity in the initializer, with an explicit equal-counter inverse.

## 4. Remove two units and observe the residual phase

Define

    r(n)=C(E n, J(Hn,n), I(Hn,n)).

Its base values are r0=0 and r1=1. It has exact period two:

- If E n=0, Bn=S^2n and H(S^2n)=S Hn, so

      r(S^2n)=J(S Hn,Bn)=A(J(Hn,Bn))
               =A(B(J(Hn,n)))=r(n).

- If E n=1, An=S^2n, so

      r(S^2n)=I(S Hn,An)=B(I(Hn,An))
               =B(A(I(Hn,n)))=r(n).

Now set

    g(n)=C(E n,r(n),r(Sn)),
    h(n)=C(E n,r(Sn),r(n)).

The parity flip and the period-two equation show g(Sn)=g(n) and h(Sn)=h(n). Their bases are g0=0 and h0=1. Full stationarity therefore proves g(n)=0 and h(n)=1. Two Boolean cases imply the exact equation

    r(n)=E n.

This is the key use of full arbitrary-value stationarity: h's initial value is 1. No induction on a pair or conjunction of equations occurs.

## 5. Parity reconstruction of every actual number

If E n=0, the preceding result gives J(Hn,n)=0. Apply I(Hn,.) and use the equal-counter inverse:

    n=I(Hn,0)=D(Hn).

If E n=1, it gives I(Hn,n)=1. Apply J(Hn,.):

    n=J(Hn,1).

The term S(Dk) has base 1 and satisfies the A recurrence, since E(Dk)=0 makes S(Dk) odd and A(S(Dk))=S^3(Dk)=S(D(Sk)). Therefore U_A gives J(k,1)=S(Dk). Thus the whole domain has exact parity reconstruction

    E n=0 -> n=D(Hn),
    E n=1 -> n=S(D(Hn)).

No injectivity of D was used in this argument.

## 6. The missing rho equation follows

Let c(n)=H(Dn). Direct definitions and the two-step half law give c0=0 and c(Sn)=S(cn).

To prove c(Dn)=Dn without any cancellation, put F(n)=c(Dn). Then F0=0 and F(Sn)=S^2(Fn). The term E(Fn) has zero base and is stationary by E(S^2x)=E x. Prior zero-base stationarity yields E(Fn)=0. Hence B(Fn)=S^2(Fn)=F(Sn), so U_B gives

    F(n)=I(n,0)=Dn.

Now use the parity decomposition of n. In its even branch,

    c(n)=c(D(Hn))=D(Hn)=n.

In its odd branch,

    c(n)=c(S(D(Hn)))=S(c(D(Hn)))=S(D(Hn))=n.

Thus c(n)=n for all n, i.e.

    H(Dn)=n.

This is exactly the extra rho axiom of the phase-retraction draft, now derived from U_B alone. Doubling injectivity and U_S may be derived afterward using the prior equivalence theorem; they were not assumed here.

## 7. Consequence and claim boundary

The source with PRE+Cov+Sep+U_B is deductively equivalent to the prior rho-completed theory and hence to full first-order iPRA, assuming the prior completed equivalence theorem is correctly incorporated. Because the languages and all original PR symbols are retained, the resulting ordinary interpretations can use the whole domain and actual equality; their composites are identities after the explicit recursion-uniqueness derivations.

This is a mathematical deletion of one fixed equation, or equivalently the elimination of the second fixed-update uniqueness schema from the earlier two-update presentation. It is not yet a smaller complete proof checker than the current native frontier, and the full PR-description and ordinary logical machinery must remain charged in any implementation comparison.
