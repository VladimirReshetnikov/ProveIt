# Independent audit: completion to full first-order iPRA

Audited file: `output/ipra_full_recursion_2026-11-09/report.tex`, Section
“Recovering all of iPRA and both identity interpretations.”

Verdict: the completion is mathematically valid over the stated `T_B`.
This is an independent mathematical review, not a machine-checked proof
certificate. It assumes the signed-stationarity section's already audited
derivation of `H(Dn)=n`, zero stationarity, the negative diagonal, and the
commutation of `B` with its iterator.

## 1. Commuting iterators

For fixed `k,a`, the template `f(n)=I(k,I(n,a))` has

    f(Sn) = I(k,B(I(n,a))) = B(I(k,I(n,a))).

The second equality is the inherited `I(k,Bx)=B(I(k,x))`, instantiated
only after its uniform proof. Its initial value is `I(k,a)`. Thus one
`U_B` application gives `I(k,I(n,a))=I(n,I(k,a))`. Both `k,a` are
passive, and no freshness condition is lost. No addition law, arithmetic
induction, or previously assumed commutation of arbitrary iterators is
needed.

## 2. Equality reflection

The sign term `sg(x)=C(x,0,1)` has Boolean range by coverage of `x`.
It reflects zero: in the successor branch, `sg(x)=0` yields `1=0`,
which is contradictory by separation. This does not assume a general
numerical equality detector.

For `epsilon(a,b)=sg(I(a,Nb))`, actual equality `a=b` supplies zero
using the negative diagonal. Conversely, a zero characteristic supplies
`I(a,Nb)=0`. Applying `I(b,.)`, commuting the iterators, and applying
the negative diagonal at `b` gives `Db=Da`. Applying the already proved
`H(Dx)=x` gives actual equality `b=a`. This argument is valid for all
source-domain elements, including nonstandard elements; it never replaces
actual equality with equality in an image or quotient.

## 3. The quantifier-free compiler

The characteristic convention is zero for truth and one for falsity.
The displayed clauses for equations, genuine falsity, conjunction,
disjunction, and implication have that convention consistently.

The implication clause needs particular care intuitionistically. If
`b_A=0`, the already established correctness of the smaller characteristic
supplies `A`; thus `A -> B` is equivalent to `B`, and the result is
`b_B`. If `b_A=1`, correctness and separation give `not A`; consequently
`A -> B` follows intuitionistically by falsity elimination, and the
characteristic is zero. There is no use of excluded middle for arbitrary
formulas. The only splits are the proved Boolean ranges of characteristics
of quantifier-free constituents.

External structural induction on a fixed finite formula yields the
compiler and its correctness. It is metatheoretic recursion on syntax,
not induction inside `T_B`, and is not a numerical truth predicate.
No characteristic is assigned to an arbitrary quantified formula.

## 4. The latch's local observations

The PR description

    L(0)=b(0)
    L(Sn)=C(L(n),b(Sn),1)

exists in the full stipulated counter/state/parameter grammar. It is
not available merely from a counter-free scalar iteration grammar;
the report correctly declares and charges the full grammar.

Both local observations can be proved using finite coverage cases,
without any induction hypothesis:

1. At zero, the range of `L` is the known range of `b(0)`.
2. At a successor `Sm`, split coverage of `L(m)`. In its zero branch
   the new value is exactly `b(Sm)`; in its successor branch the new
   value is exactly one. This proves Boolean range of the new value.
3. If the new value is zero, the second branch contradicts separation,
   and the first branch gives `b(Sm)=0`.

It would be circular to assume that the previous latch value already
has Boolean range in this local proof. The report explicitly uses
coverage of that value instead, so there is no such gap.

## 5. Recovering the contextual induction rule

Fix the supplied base and progress derivations under `Gamma`. The base
gives `L(0)=0`. In the zero branch of the now independently proved
range of `L(z)`, the terminal observation gives `F(z)`; inserting the
supplied progress derivation gives `F(Sz)` and therefore `b(Sz)=0`.
The latch successor value equals its current zero value. In the one
branch both its current and successor values are one by computation.
Thus `Gamma` proves `L(Sz)=L(z)`.

Inherited zero stationarity now gives `L(t)=0`; the terminal observation
and characteristic correctness give `F(t)`. This use of stationarity
is legitimate under the unchanged retained context. The induction
variable is fresh for that context, the target, and passive parameters.
Quantified formulas may occur in `Gamma`; the restriction is solely
on the matrix `F`. Thus the result is the full intended first-order
contextual quantifier-free induction rule, not merely its empty-context
or equational fragment.

## 6. Both translations and both round trips

The forward identity translation preserves every computation equation,
logical constructor, actual equality, and genuine falsity. Predecessor
computation proves successor injectivity. Applying `delta` to `Sx=0`
gives `0=1`, so separation gives successor separation. The preceding
latch argument proves every target induction instance.

In reverse, ordinary iPRA proves coverage by quantifier-free induction
on `n=0 or n=S(Pn)`, whose successor step is immediate from predecessor
computation. It proves separation. Each retained-context `U_B` instance
is derived by equation induction on the literal equation

    f(n,p)=I(n,f(0,p)).

The supplied recurrence and the iterator successor equation provide
the inductive step; the iterator zero equation provides the base.
The same context and passive parameters are retained.

No signature extension, quotient, restricted domain, representation
map, or nontrivial decoding is present in either translation. Therefore
both composites act literally as the identity on all formulas, and
the internally definable relation `x=y` is the total bijection providing
each round-trip isomorphism. This applies equally to nonstandard models.
The explicit finite proof transformations preserve genuine falsity,
so they establish metatheoretic equiconsistency without claiming an
internal consistency proof.

## Scope

This audit validates the mathematical completion and full identity
bi-interpretability. It does not validate a complete proof-checker size
record, the mechanical correctness of every generated artifact, or
automatic formal verification of the latch section. Those are separate
claims, and the report keeps them separate.
