# Assessment of a direct integer-domain simplification

The signed update `B` becomes ordinary translation when the domain is
presented as integers. This notation change alone does not simplify the
whole theory: primitive recursion still needs its natural-number counter.

There is a precise obstruction to the most direct proposal. Suppose the
counter successor `T` is surjective, as integer translation is, but the
ordinary unrestricted primitive-recursion scheme is retained:

    R(0,p)=g(p)
    R(Tn,p)=h(n,R(n,p),p).

Choose the constant initializer `g=1` and constant update `h=0`. A
predecessor `a` of zero exists, so the successor equation at `a` gives
`R(0)=0`, while the base equation gives `R(0)=1`. Separation makes the
theory inconsistent. This argument uses only one trivial fixed recursion
description; it is not a subtle nonstandard obstruction.

Therefore an integer-domain presentation must either restrict recursion
to a definable nonnegative cone, use separate natural and integer sorts,
or change its recursion mechanism substantially. The first option needs
the cone, its constructor decomposition, and the permitted recursion
boundary. The second option needs a connection between counter values
and signed states sufficient to recover actual natural-number equality
and whole-domain round trips. The signed action in the new proof supplies
such a connection, but merely postulating it elsewhere does not remove
its complexity.

Changing the encoding of integers while retaining natural counters gives
a conjugate signed update. It may shorten one displayed term but requires
the encoding and inverse to be available and internally inverse on all
elements, not only on standard numerals. No verified net reduction of
the charged theory was obtained in this investigation.

The concrete positive output of this additional investigation is instead
the exact independence of both remaining boundary assumptions, recorded
in `boundary_independence.tex`: the singleton model excludes deletion of
separation; direct powers of standard PR arithmetic exclude deletion of
coverage, with a parameter-robust automorphism obstruction for sufficiently
large powers. These results concern the present basis, not a universal
lower bound for changed domains or different proof-checker encodings.
