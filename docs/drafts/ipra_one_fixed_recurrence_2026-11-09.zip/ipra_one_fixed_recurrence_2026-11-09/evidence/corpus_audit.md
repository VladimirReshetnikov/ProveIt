# Current iPRA corpus audit

Snapshot: `89fd4b4c5cd158259b1f2846f63e3d98f053553c`. All eleven archives were already extracted into `references/`. This audit read their main contribution statements and targeted proof sections; it did not formally verify every metatheorem or execute supplied checker programs. Static whole-source measurements were independently reproduced.

## Findings that change the comparison

1. The actual current literal-source frontier is **309 normalized tokens, 344 AST nodes, 864 normalized bytes**, all attained by a single file: `ipra_package_reconstructed/ipra_reset_2026-11-08/code/complete_kernel.py`. Reports quoting 312/347/878 or 313/347/878 predate that file. Its SHA-256 is `6726df4aa9cb5560ac82889c5ff1fcab8838e8752b29eeee2c509ad78e85982e`.
2. That program checks the inherited native scalar calculus. It does **not** implement the reconstructed package's new anchored-reset theory. The source reduction and mathematical theorem are explicitly separate.
3. Literal byte dominance depends on identifier naming: the package's own uniform-short-name control yields 816 bytes for `compact_open.py`, against 864 for the new checker. The 309-token/344-AST improvements survive this control.
4. The strongest current mathematical signature reduction is already in **shifted equational core**: zero plus a staged family of closed-unary shifted iterators `K_h(n,a)`, successor recovered by `S(a)=K_id(0,a)`, and a predecessor proved in the bare equational calculus, without Boolean range. The full native completion uses equality, one paired formula binder, two computation schemas, and four inference patterns. This reduction must not be presented as new.
5. A finite list of measured programs provides achieved upper bounds and an empirical comparison target, not a mathematical lower bound on arbitrary axiomatizations. No source in the current corpus establishes global simplestness.

## Source-by-source contribution map

| Current archive | Established contribution stated in its report | Limitation / subsumption |
|---|---|---|
| `ipra_fusion_clock_2026-11-08` | Scalar recurrence uniqueness with computation, coverage and separation recovers full iPRA; parameterized fusion plus the successor clock is equivalent to scalar uniqueness. Fusion alone has a canonical fixed-point retract and is equiconsistent with iPRA. | Fusion without the clock is not bi-interpretable: tagged models and involutions lose ambient distinctions under the retract. No new complete checker. |
| `ipra_input_amalgamation_2026-11-08` | Strong all-unary obstruction using copies of an elementary extension glued along the standard part; validates all true universal laws, all true one-input QF existence laws, full parameterized QF induction and decidable equality. Also removes Boolean branching from three-state finite control. | Even tuple/quotient ordinary bi-interpretations fail; changing the logical interpretation remains outside this particular obstruction. Its open bare shifted-predecessor question is solved by shifted equational core. |
| `ipra_intuitionistic_depth_2026-11-08` | For each k>=1 constructs a negative predicate with classical native depth k but intuitionistic provable-equivalence depth k+1; lower bound holds even for HA proofs. Depth-one versus depth-two example is double-negated halting. | Obstruction to normalization of formulas, not checker-size lower bound. Uses total modified-realizability extraction, not merely partial recursive witness search. |
| `ipra_package_reconstructed` | Anchored reset with target f(1), one term template and one premise derives equality reflection, eliminates the prior absorption axiom, and recovers iPRA. Separately supplies the 309/344/864 inherited-calculus checker. | Anchored reset retains full PR description grammar, ordinary logic, Boolean range, separation and a substantial detector; the 309-token program does not implement it. |
| `ipra_phase_retraction_2026-11-08` | Replaces the two-update uniqueness basis by one signed-counter uniqueness schema U_B plus the single retraction equation H(Dn)=n. Derives zero stationarity from U_B without equality reflection. | Still assumes rho. Derives D(H(Dn))=Dn without rho, but cannot cancel D. Proves rho iff doubling injectivity iff admissibility of successor uniqueness, without deciding whether rho is derivable. |
| `ipra_recurrence_uniqueness_2026-11-08` | Two fixed uniqueness updates, successor and a signed-counter map, suffice over full PR equations, coverage, separation and ordinary intuitionistic logic; complete identity-domain interpretations. | Phase retraction reduces this rule inventory. No complete below-frontier implementation. |
| `ipra_reflection_absorption_2026-11-08` | Replaces numerical equality reflection by one normalized absorption equation; replaces coverage in a stationarity reconstruction by sign-function Boolean range; countermodels to deleting the atomic binder's retained base. | Anchored reset later derives the absorption interface. No new smallest checker. |
| `ipra_shifted_equational_core_2026-11-08` | Bare-equational predecessor theorem for closed unary shifted K; mutually inverse term interpretations with initialized closed iteration; integrates with complete native four-pattern calculus. | No smaller complete acceptance program. Structural deletion of successor is a mathematical simplification but existing checkers already share successor and formula-unary syntax. |
| `ipra_shifted_iteration_2026-11-08` | Internal shifted-unary predecessor using Boolean range; explicit ordinary direct checker. | Stronger bare-equational theorem now subsumes its logical-assumption cost. Its direct checker is 2730/2856/10512, not competitive. |
| `ipra_successor_clock_2026-11-09` | Alternative successor-valued clock recovers a predecessor under Boolean range, without primitive successor or extra retraction axiom; separate 312-token inherited-kernel variant. | Bare-equational core removes its Boolean proof dependency; reconstructed checker beats its implementation record. |
| `ipra_unary_barriers_2026-11-09` | Homogeneous-type and zero-seed Kripke fans, fixed-seed majorization, bounded-seed orbit obstruction; covers tuple/quotient interpretations in specified cases. | Pure-unary obstruction strengthened by input amalgamation to full parameterized QF induction and classical decidable equality. Fixed-seed/orbit results retain their separate scopes. |

## Exact strongest native basis already present

Numerical syntax is `x | 0 | K_h(n,a)`, where each `h(u)` is a fixed finite closed-unary description over earlier declarations. It is a staged symbol family, not a numerical universal evaluator. Define `S(a)=K_id(0,a)`. Computation is `K_h(0,a)=S(a)` and `K_h(S(n),a)=h(K_h(n,a))`.

Formula syntax is `s=t | D_{x,y}A`. Its ordinary meaning is `exists x (A(x,0) -> forall y A(x,y))`. Contexts carry clauses `<A; y.B(y)>`. The four primitive patterns are Use (apply a context clause), DI (paired introduction with retained base and an additional induction hypothesis only for literal equations), DE (open a paired formula into a fresh witness and clause), and Tr (formula equality transport). All scope/freshness conditions remain charged. No arbitrary quantified induction is admitted.

The shifted bare predecessor permits ordinary initialized iteration by `I_h(n,a)=P(K_hat_h(n,a))`, with `hat_h(u)=S(h(P(u)))`. It supplies an exact selector, formula gates, all logical macros, characteristic terms for QF formulas, and the original full-PR compiler. Both numerical interpretations use the entire domain and actual equality; equation induction proves every fixed symbol agrees with its double translation, and the native binder composite is proved separately.

This is a compact positive reference already in the corpus, not a new result of this audit. The reports distinguish the bare equational fragment from the faithful ordinary full-logic realization; product models of the former do not contradict the latter's bi-interpretability.

## Focused correctness review

- Input amalgamation: the potentially delicate preservation of all true universal formulas is not asserted merely from unary copywise closure. The proof realizes each finite atomic diagram in N, choosing standard tuples one label-group at a time and avoiding the finite values chosen for earlier groups. This validates cross-copy inequalities. Full parameterized QF induction is then proved by restricting each fixed matrix to a copy and replacing terms of outside parameters by constants, contradictions, or truths. The ordinary bi-interpretability obstruction uses parameter-fixing involutions and the fact that an order-preserving involution of a linear order is identity. I found no gap in these targeted arguments.
- Intuitionistic depth: the extraction lemma explicitly uses total System T realizers interpreted in the full set-theoretic finite-type structure, where truth and existence of a (possibly noneffective) realizer coincide. This supplies a total computable outer witness under a negative premise. The Pi-class bound is applied to the matrix below the outer existential, not to the entire D-formula. The report has correctly separated classical truth sets from HA-provable equivalence. I found no gap in the inspected argument.
- Shifted equational core: the report explicitly avoids cancelling successor before predecessor is available, and flags the freshness condition in finite-table equation induction. I inspected the dependency interfaces and native integration, not every line of the long clock proof; no full formal verification claim should be inferred.
- Current checker measurement is static source inspection only. The 309-token file's extensional equivalence with array_only is argued in its report; this audit has not re-proved full native soundness or independently executed its regression corpus.

## Independent measurement

The independent audit used the inherited whole-module convention: remove actual leading docstrings, AST-unparse, count non-layout Python tokens, count all AST nodes, and count normalized UTF-8 bytes. Imports and CLI stay included. Runtime: CPython 3.12.14. No supplied checker source was executed. The detailed source hashes, copies and profiles are in `audit_metrics.json`.

| Program | Tokens | AST | Normalized bytes |
|---|---:|---:|---:|
| `complete_kernel.py` | 309 | 344 | 864 |
| `array_only.py` | 312 | 348 | 920 |
| `compact_unpack_open.py` | 313 | 347 | 922 |
| `compact_unpack.py` | 314 | 348 | 929 |
| `structural_open.py` | 316 | 347 | 901 |
| `kernels_structural.py` | 317 | 348 | 908 |
| `compact_open.py` | 317 | 351 | 878 |
| `kernels_byte.py` | 318 | 352 | 885 |
| `boolean_core.py` | 319 | 352 | 898 |
| `boxed.py` | 322 | 355 | 903 |
| `context_blocks.py` | 324 | 350 | 954 |
| `context_pairs.py` | 325 | 352 | 952 |
| `context_pairs_exact.py` | 325 | 354 | 948 |
| `fixed_contexts.py` | 325 | 355 | 953 |
| `clausal.py` | 326 | 351 | 938 |
| `normalized_readable.py` | 326 | 354 | 958 |
| `normalized.py` | 327 | 352 | 947 |
| `boxed_compatible.py` | 327 | 354 | 955 |
| `shifted_direct_kernel.py` | 2730 | 2856 | 10512 |

The complete comparison has 19 distinct source identities: 18 compact native implementations and one direct ordinary shifted implementation. Three additional programs in comparator directories are marked unvalidated experiments (`progression_experiment`, `closed_update_prototype`, `anchor_experiment`) and excluded. Including them would not change any minimum.

## Precise remaining opportunities

1. **One signed recurrence without rho.** Settle whether U_B plus the existing boundaries and PR equations proves H(Dn)=n. The current proof reaches only D(H(Dn))=Dn, and identifies exactly the missing injectivity. A proof or countermodel would be new relative to all eleven current packages.
2. **Integrate a mathematical deletion into the full native checker.** Shifted K eliminates a constructor on paper, but current code shares the old unary successor representation with closure syntax, so the deleted name does not automatically delete a branch. Any gain must account for recognition of the derived successor section.
3. **Merge one of the four native inference patterns.** Equality transport, context clause use and paired elimination already share code. A genuine mathematical normalization reducing their logical machinery would need a whole-proof translation, preservation of arbitrary retained contexts, and no extra quantified induction.
4. **A new connective with cheaper complete checking.** Current depth theorems constrain the existing D syntax; they do not rule out a different connective or logic. Ordinary first-order unary-amalgam obstructions likewise do not settle the user-allowed change of logical realization. Full formula and domain round trips would remain necessary.
5. **Do not revive resolved open questions.** Bare shifted predecessor and deletion of the stationarity absorption axiom are already solved in the current sources. Similarly, claiming Boolean range or all unary QF induction repairs a pure-unary language is already refuted.
