"""Reproduce the bundled sizes and deterministic finite audits offline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STEPS = ('comparison/measure_all.py', 'comparison/measure_harmonized.py',
         'validation/audit_raw.py', 'validation/audit_absorbed.py',
         'validation/update_seed_model.py')


def main():
    logs = ROOT / 'results' / 'reproduction_logs'
    logs.mkdir(parents=True, exist_ok=True)
    entries = []
    for step in STEPS:
        process = subprocess.run([sys.executable, str(ROOT / step)], cwd=ROOT,
                                 text=True, capture_output=True, timeout=180)
        log = logs / (Path(step).stem + '.txt')
        log.write_text(process.stdout + process.stderr)
        entries.append({'step': step, 'exit_code': process.returncode,
                        'log': str(log.relative_to(ROOT))})
        print(step, 'PASS' if process.returncode == 0 else 'FAIL', flush=True)
        if process.returncode:
            raise SystemExit(process.stdout + process.stderr)
    (ROOT / 'results' / 'reproduction.json').write_text(json.dumps(
        {'status': 'PASS', 'steps': entries}, indent=2) + '\n')


if __name__ == '__main__':
    main()
