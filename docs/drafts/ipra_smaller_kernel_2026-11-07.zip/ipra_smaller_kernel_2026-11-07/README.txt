SMALLER CERTIFICATES FOR iPRA
============================

Read report.pdf for the complete result, all native axioms and rules,
the inherited internal arithmetic and bi-interpretation, the new
initializer-domination obstruction, and exact limits of the claims.
report.tex and sections/*.tex contain all LaTeX sources.

RESULTS
-------
Current six-archive complete-program envelope: 389 tokens / 413 AST nodes /
1159 normalized bytes. Primary checker.py: 377 / 405 / 1123.
All comparisons count the complete program and use the unchanged inherited
normalization metric on CPython 3.12.14.

After the same wrapper is attached to every checker: current envelope
389 / 413 / 1188; primary 381 / 408 / 1174.
Harmonized checking cores: current envelope 330 / 350 / 938;
primary 322 / 346 / 930.

This positive result combines existing certificate ideas and includes
ordinary source/driver simplifications. It is not a new mathematical
axiom basis. The negative mathematical result proves that a broad mixed
language of fixed-, update-, and diagonally seeded recursion cannot
term-define addition, even with every unary PR operation available.
That is not a universal non-bi-interpretability theorem.

RUN
---
python3 reproduce.py
python3 build.py
python3 checker.py examples/iterator_zero.json
python3 checker.py examples/false_equation.json

Python 3.10+ is needed for the checker; exact metrics were obtained with
CPython 3.12.14. Building needs pdfLaTeX and the packages in report.tex.
No network access is required to reproduce bundled evidence.

The primary CLI prints ACCEPT with status 0, or REJECT with status 1.
It rejects Boolean and floating-point numerical leaves. It may ignore
an unused leading packet prefix, as the supplied certificate formats do.
Resource failure rejects a packet; it does not prove the goal underivable.

CONTENTS
--------
checker.py                 Entire trusted primary program.
checker_absorbed.py         Optional implementation of the supplied A theory.
FORMAT.txt                 Complete concrete certificate conventions.
comparison/                Frozen sources, hashes, and measurement tools.
validation/                Independent syntax oracle, fixtures, finite audits.
examples/                  Small primary certificates.
results/                   Actual measurement and validation outputs.
reproduce.py               Offline evidence reproduction.
build.py                   Three-pass PDF build.
ATTRIBUTION.txt             Inherited and new contributions.
LICENSE_SOURCE.txt         Preserved source license.
SHA256SUMS                  Deliverable content hashes.

Written mathematics and finite executable validation are explicitly
distinguished. No proof-assistant formalization is claimed.
