"""Build the complete report with pdfLaTeX; all inputs are local."""
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    if not (ROOT / 'results' / 'numbers.tex').exists():
        raise SystemExit('Run python3 reproduce.py first to generate the measurements.')
    for pass_number in range(1, 4):
        process = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                                  '-file-line-error', 'report.tex'], cwd=ROOT,
                                 text=True, capture_output=True, timeout=120)
        (ROOT / 'results' / ('latex_pass_' + str(pass_number) + '.txt')).write_text(
            process.stdout + process.stderr)
        if process.returncode:
            raise SystemExit(process.stdout[-12000:] + process.stderr)
    # Verify completion before publishing the PDF through an atomic write.
    data = (ROOT / 'report.pdf').read_bytes()
    expected = re.search(r'Output written on report\.pdf \(\d+ pages, (\d+) bytes\)',
                         process.stdout)
    if expected is None or len(data) != int(expected.group(1)) or not data.rstrip().endswith(b'%%EOF'):
        raise SystemExit('The final PDF is incomplete; refusing to publish it.')
    temporary = ROOT / 'report.pdf.complete'
    temporary.write_bytes(data)
    temporary.replace(ROOT / 'report.pdf')
    print('Built report.pdf:', len(data), 'bytes; complete EOF checked')


if __name__ == '__main__':
    main()
