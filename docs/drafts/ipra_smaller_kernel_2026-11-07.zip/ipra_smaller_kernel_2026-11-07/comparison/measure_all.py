"""Reproduce all located whole-program sizes without executing comparators."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
spec = importlib.util.spec_from_file_location('inherited_measure', HERE / 'source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((HERE / 'expanded_manifest.json').read_text())
    rows = []
    for entry in manifest['programs']:
        path = HERE / entry['local_file']
        actual = measure.metrics(path)
        if actual['sha256'] != entry['sha256']:
            raise ValueError('Changed comparator: ' + entry['local_file'])
        rows.append({**entry, **actual})
    root_rows = [r for r in rows if r['is_current_root']]
    envelope = {f: min(r[f] for r in rows) for f in FIELDS}
    root_envelope = {f: min(r[f] for r in root_rows) for f in FIELDS}
    candidates = {name: measure.metrics(ROOT / name)
                  for name in ('checker.py', 'checker_absorbed.py')}
    assert envelope == root_envelope
    for name, values in candidates.items():
        assert all(values[f] < envelope[f] for f in FIELDS), name
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
              'current_root_programs': len(root_rows), 'distinct_complete_sources': len(rows),
              'envelope': envelope, 'root_envelope': root_envelope,
              'candidates': candidates, 'programs': rows}
    (ROOT / 'results' / 'metrics_all.json').write_text(json.dumps(result, indent=2) + '\n')
    with (ROOT / 'results' / 'metrics_all.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['source_path', 'is_current_root', *FIELDS, 'sha256'],
                                extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    primary = candidates['checker.py']
    macros = {'NewTokens': primary['normalized_tokens'], 'NewAst': primary['ast_nodes'],
              'NewBytes': primary['normalized_bytes']}
    (ROOT / 'results' / 'numbers.tex').write_text(''.join(
        '\\newcommand{\\' + name + '}{' + str(value) + '}\n'
        for name, value in macros.items()))
    print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
