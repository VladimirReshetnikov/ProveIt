"""Measure unchanged current roots and identical-driver versions of every source.

The common wrapper makes driver-only improvements visible separately.
The original metric itself is imported unchanged from the retrieved corpus.
"""
import ast
from hashlib import sha256
import json
import platform
from pathlib import Path
from frozen.source_measure import metrics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
WRAPPER = """
if __name__ == '__main__':
    try:
        take = json.load(open(sys.argv[1])).pop
        if not check(take(), []):
            raise ValueError
        print('ACCEPT')
    except:
        print('REJECT')
        sys.exit(1)
"""


def harmonize(source):
    tree = ast.parse(source)
    body = []
    for node in tree.body:
        if isinstance(node, (ast.If, ast.Try)):
            break
        body.append(node)
    tree.body = body + ast.parse(WRAPPER).body
    return ast.unparse(tree)+'\n'


def main():
    output = HERE/'harmonized'
    output.mkdir(exist_ok=True)
    manifest = json.loads((HERE/'manifest.json').read_text())
    for entry in manifest['programs']:
        if sha256((HERE/entry['local_file']).read_bytes()).hexdigest() != entry['sha256']:
            raise ValueError('Comparator source differs from pinned manifest: '+entry['local_file'])
    roots = [HERE / entry['local_file'] for entry in manifest['programs']]
    fields = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    rows = []
    for i, path in enumerate(sorted(set(roots))):
        target = output/f'current_{i:02}.py'
        target.write_text(harmonize(path.read_text()))
        rows.append({'path': str(path.relative_to(HERE)),
                     'unchanged': metrics(path), 'same_driver': metrics(target)})
    candidates = []
    for name in ('checker.py', 'checker_absorbed.py'):
        path = ROOT/name
        target = output/name
        target.write_text(harmonize(path.read_text()))
        candidates.append({'path': name, 'delivered': metrics(path),
                           'same_driver': metrics(target)})
    result = {'python': platform.python_version(), 'implementation': platform.python_implementation(),
              'commit': manifest['commit'], 'archive_count': len(manifest['archives']),
              'current_root_programs': len(rows),
              'unchanged_envelope': {f: min(r['unchanged'][f] for r in rows) for f in fields},
              'same_driver_envelope': {f: min(r['same_driver'][f] for r in rows) for f in fields},
              'same_driver_core_envelope': {f: min(r['same_driver']['core'][f] for r in rows) for f in fields},
              'candidates': candidates, 'current': rows,
              'scope': 'All checker*.py siblings of current extracted root report.tex files.'}
    (ROOT/'results/metrics_harmonized.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='current'}, indent=2))


if __name__ == '__main__':
    main()
