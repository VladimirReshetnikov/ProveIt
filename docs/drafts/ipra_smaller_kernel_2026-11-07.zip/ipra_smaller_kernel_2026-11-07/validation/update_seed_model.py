"""Check the small finite-model calculation, not the domination theorem."""
import json
from pathlib import Path


def main():
    successor = (1, 2, 1)

    def forced_B(update):
        state = successor[update[0]]
        values = [state]
        for _ in range(2):
            state = update[state]
            values.append(state)
        return tuple(values)

    zero_test = forced_B((0, 0, 0))
    second_update = forced_B(zero_test)
    outer = forced_B(second_update)
    lhs = outer[successor[2]]
    rhs = second_update[outer[2]]
    assert zero_test == (1, 0, 0)
    assert second_update == (2, 0, 1)
    assert outer == (1, 0, 2)
    assert (lhs, rhs) == (0, 1)
    result = {'status': 'PASS', 'successor': successor, 'zero_test': zero_test,
              'second_update': second_update, 'outer_values': outer,
              'required_equation_at_counter_2': [lhs, rhs],
              'conclusion': 'This three-element successor structure cannot model B.',
              'scope': 'One finite calculation; the general domination theorem is a written proof.'}
    (Path(__file__).resolve().parent.parent / 'results' / 'update_seed_model.json').write_text(
        json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
