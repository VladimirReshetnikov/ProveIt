"""Finite audit of the optional successor-initialized companion.

The primary scalar checker is audited separately. This script validates the
two arithmetic changes against native source fixtures and a named oracle.
"""
from hashlib import sha256
from pathlib import Path
import json
import random
import subprocess
import sys
import tempfile
from audit_raw import load_prefix, run, translate, unwrap
from frozen.mutation_support import mutate
from raw_oracle import RawOracle

HERE = Path(__file__).resolve().parent


def agree(module, packet):
    actual = run(module, packet)
    oracle = RawOracle(absorbed=True).run(packet)
    assert actual['accepted'] == oracle['accepted'], (packet, actual, oracle)
    if actual['accepted']:
        assert actual['final_k'] == oracle['final_k']
        assert actual['remaining'] == oracle['remaining']
    return actual


def main():
    path = HERE.parent/'checker_absorbed.py'
    checker = load_prefix(path)
    baseline = load_prefix(HERE/'frozen/absorbed_wrapped.py')
    fixtures = json.loads((HERE/'frozen/absorbed_fixtures.json').read_text())
    packets, rows = [], []
    translated = 0
    for row in fixtures:
        source = row.get('strict_packet', row['packet'])
        original = run(baseline, source)
        assert original['accepted'] == row['expected']
        if original['accepted']:
            target, old = translate(baseline, source)
            translated += 1
        else:
            target = ([unwrap(cell) for cell in source[:-1]]+[source[-1]]
                      if type(source) is list and source else source)
        actual = agree(checker, target)
        assert actual['accepted'] == row['expected'], (row['name'], actual)
        if actual['accepted']:
            assert target[-1] == source[-1]
            assert actual['final_k'] == original['final_k']
        rows.append({'name': row['name'], 'accepted': actual['accepted']})
        packets.append(target)
    rng = random.Random(20261109)
    accepted_mutations = 0
    for i in range(500):
        packet = mutate(packets[i % len(packets)], rng)
        accepted_mutations += agree(checker, packet)['accepted']
    calls = 0
    with tempfile.TemporaryDirectory() as tmp:
        packet_file = Path(tmp)/'packet.json'
        for packet, row in zip(packets, rows):
            packet_file.write_text(json.dumps(packet))
            for optimized in (False, True):
                completed = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                            str(path), str(packet_file)],
                                           capture_output=True, text=True, timeout=15)
                expected = (0, 'ACCEPT\n', '') if row['accepted'] else (1, 'REJECT\n', '')
                assert (completed.returncode, completed.stdout, completed.stderr) == expected
                calls += 1
    result = {'status': 'PASS', 'checker_sha256': sha256(path.read_bytes()).hexdigest(),
              'fixed_entries': len(rows), 'fixed_accepting': sum(r['accepted'] for r in rows),
              'fixed_rejecting': sum(not r['accepted'] for r in rows),
              'positive_source_translations': translated, 'mutation_entries': 500,
              'mutation_accepting': accepted_mutations,
              'cli_calls_normal_and_optimized': calls, 'results': rows,
              'scope': 'Finite implementation evidence, not a formal proof of metatheory.'}
    (HERE.parent/'results/absorbed_kernel_audit.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='results'}, indent=2))


if __name__ == '__main__':
    main()
