"""Independent named-binder interpreter of the raw-witness certificate format.

Untrusted validation support. Production checker does not import this file.
Uses the frozen one-hole named syntax, and an explicit inference interpreter.
"""
from frozen.named_oracle import Oracle as WrappedOracle


class RawOracle(WrappedOracle):
    def __init__(self, absorbed=False):
        super().__init__()
        self.absorbed = absorbed

    def check(self, goal, context):
        self.open(goal)
        if goal in context:
            self.rule('hypothesis')
            return True
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, context):
                if len(major) == 3:
                    self.rule('paired_elimination')
                    eigen = self.fresh([goal, *context, major])
                    assumption = self.open([major[0]], eigen)
                    return self.check(goal, [*context, assumption])
                if len(major) == 1:
                    self.rule('closure_elimination')
                    matrix, left, right = major[0], 0, annotation
                else:
                    self.rule('equality_transport')
                    matrix, (left, right) = annotation, major
                if self.open(matrix, right) != goal:
                    return False
                return self.check(self.open(matrix, left), context)
            self.rule('failed_major_fallback')
        elif instruction == []:
            if len(goal) != 2 or type(goal[0]) is not list or len(goal[0]) != 3:
                raise ValueError('invalid computation request')
            counter, initial, update = goal[0]
            if type(counter) is int and counter == 0:
                self.rule('iteration_zero')
                expected = [initial] if self.absorbed else initial
            elif type(counter) is list and len(counter) == 1:
                self.rule('iteration_successor')
                previous = counter[0]
                expected = self.open(update, [previous, initial, update], False)
            else:
                raise ValueError('counter is not zero or a successor')
            return goal[1] == expected
        if len(goal) not in (1, 3):
            raise ValueError('a numerical equality child is not a formula')
        self.rule('closure_introduction' if len(goal) == 1 else 'paired_introduction')
        body = self.open(goal[0], instruction, depth=1)
        assumptions = [self.open(body, 0)]
        if len(body) == 2:
            assumptions.insert(0, body)
        eigen = self.fresh([goal, *context])
        conclusion = self.open(body, [eigen])
        instantiated = [self.open(a, eigen) for a in assumptions]
        return self.check(conclusion, [*context, *instantiated])
