PORTABLE CHECKER VALIDATION
===========================

Run with Python 3.10 or later, from any working directory:

  python3 validation/audit_raw.py
  python3 validation/audit_absorbed.py
  python3 comparison/measure_harmonized.py

The commands above assume the archive root is the current directory; absolute
script paths work as well. Only the Python standard library is used.

All files in this directory are untrusted validation support. Neither public
checker imports them. The checker's complete source, plus the ordinary Python
runtime and JSON parser shared with the comparators, determines acceptance.

The primary checker uses strict integer syntax: Boolean numerical leaves are
rejected when used. Its final source hash is recorded in the audit results.
Calls replacing d=x by the third positional argument x are semantically exact:
the unchanged signature is inst(a, t=None, d=0). This small source simplification
is not a new inference rule or a new arithmetic basis.

PRIMARY AUDIT

  6,776 opening cases, against a separate named-binder parser:
  3,522 valid openings and 3,254 rejected openings.

  207 named fixed entries, after translation to the raw-witness format:
  126 accepting entries and 81 rejecting entries.

  All 120 source-accepted entries translate successfully. Their closed root
  sentence is literally unchanged, and the eigenparameter clock is unchanged.
  Translation traces actual instruction consumption, discards an inert prefix,
  unwraps used singleton introduction records, and replaces malformed inert
  witnesses by zero when their raw shape would collide with another instruction.

  1,600 deterministic mutations of raw packets, each compared with the named
  oracle; 59 accept and 1,541 reject. Mutations are finite implementation probes,
  not independent mathematical theorem claims.

  420 actual CLI calls: every fixed entry in ordinary and optimized Python,
  plus three malformed JSON inputs in both modes. The checks do not depend on
  Python assert statements; running the measured checkers with -O preserves them.

The named oracle explicitly models a subtle control-flow boundary: a major
premise that returns False permits guard fallback, whereas an exception aborts
the packet. A malformed equality introduction or a malformed computation request
raises in the compact checker and must not be mistaken for a False result.

ABSORBED COMPANION AUDIT

  47 native successor-initialized fixtures: 28 accept and 19 reject.
  All 28 source positives translate with the same sentence and eigenclock.
  500 deterministic raw-packet mutations: 36 accept and 464 reject.
  94 actual CLI calls under ordinary and optimized Python.

These are kernel checks. They do not establish the long arithmetic recovery
proof for successor-initialized iteration; that proof is in the accompanying
mathematical source material, with its own stated status.

SOURCE ATTRIBUTION

The frozen one-hole checker, named-binder syntax, generic mutation function,
and scalar fixtures come from the current archive
ipra_one_hole_2026-11-07.zip, at its root checker.py and validation/ subtree.

The frozen successor-initialized checker and native fixtures come from
ipra_absorbed_scalar_2026-11-07.zip, under kernel_audit/frozen/strict_wrapped_A.py
and kernel_audit/fixtures/native_A_cases.json. Its inherited module docstring
mentions Boolean aliases, but the actual frozen file tests type(a) is int.

The raw instruction interpreter, trace-based packet translation, and audit
integration are new derivatives for this package. Source licensing text is
retained in frozen/LICENSE_SOURCE.txt. The repository commit, ZIP hashes,
Git blob hashes, and 13 current root comparator hashes are pinned separately
in comparison/manifest.json.

LIMITS

Successful finite tests are neither a formalized metatheory nor a consistency
proof. Python's finite memory and stack can reject very large valid proofs.
REJECT means that this certificate was not accepted; it does not mean its
sentence is false or underivable. Named cohorts contain repeated packet bytes,
and the two arithmetic checkers have different zero-computation schemas.
