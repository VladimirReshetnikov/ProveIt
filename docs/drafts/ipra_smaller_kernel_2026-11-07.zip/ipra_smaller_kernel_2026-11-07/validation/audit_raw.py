"""Finite executable audit, separate from the trusted acceptance program.

Run from any directory: python3 audit_raw.py
No claim of formal verification follows from these tests.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import ast
import json
import random
import subprocess
import sys
import tempfile
import types

from frozen.mutation_support import mutate
from frozen.named_oracle import opening
from raw_oracle import RawOracle

HERE = Path(__file__).resolve().parent


def load_prefix(path):
    tree = ast.parse(path.read_text())
    body = []
    for node in tree.body:
        if isinstance(node, (ast.If, ast.Try)):
            break
        body.append(node)
    tree.body = body
    module = types.ModuleType(path.stem)
    exec(compile(tree, str(path), 'exec'), module.__dict__)
    return module


def run(module, packet, trace=False):
    module.k = 0
    stack = deepcopy(packet)
    used = []
    def take():
        value = stack.pop()
        used.append((len(stack), deepcopy(value)))
        return value
    try:
        module.take = take
        accepted = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return dict(accepted=accepted, final_k=module.k,
                remaining=len(stack) if type(stack) is list else None,
                error=error, used=used if trace else None)


def unwrap(cell):
    if type(cell) is list and len(cell) == 1:
        witness = cell[0]
        if type(witness) is int or type(witness) is list and len(witness) in (1, 3):
            return witness
        # An accepted source can use an invalid witness only when it is inert.
        return 0
    return cell


def translate(module, packet):
    result = run(module, packet, trace=True)
    if not result['accepted']:
        raise ValueError('source certificate did not accept')
    target = [unwrap(cell) for _, cell in reversed(result['used'])] + [deepcopy(packet[-1])]
    return target, result


def opening_audit(module):
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 999, True, False, 0.0, None, {}]
    terms = [*atoms, [], [0], [1], [999], [0, 0], [0, 0, 1],
             [0, 0, 3], [0, 0, 999], [1, 0, [0, 3, 5]],
             [0, 0, [0, 1, 5]], [0, 0, [0, 1, 999]]]
    formulas = [[t, 0] for t in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5, 999)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 999)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 999], 5]], [0, 0], [0, 0]]]
    images = [None, 0, -1, -3, 1, 2, [0], [0, 0, 1], [0, 0, 3], True, {}]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2, 3):
                for lower in (0, -2):
                    for image in images:
                        module.k = lower
                        try:
                            actual = module.inst(deepcopy(value), deepcopy(image),
                                                 d=2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        try:
                            expected = opening(deepcopy(value), deepcopy(image),
                                               formula=formula, depth=depth, lower=lower)
                            valid_expected = True
                        except Exception:
                            expected, valid_expected = None, False
                        assert valid == valid_expected and (not valid or actual == expected), (
                            'opening', value, image, formula, depth, lower, actual, expected)
                        counts['valid' if valid else 'invalid'] += 1
    return dict(counts)


def audit(module, packet, name, expected=None):
    actual = run(module, packet)
    oracle = RawOracle().run(packet)
    assert actual['accepted'] == oracle['accepted'], (name, actual, oracle)
    if expected is not None:
        assert actual['accepted'] == expected, (name, expected, actual)
    if actual['accepted']:
        assert actual['final_k'] == oracle['final_k'], (name, 'fresh name clock')
        assert actual['remaining'] == oracle['remaining'], (name, 'unused prefix')
    return actual, oracle


def main():
    candidate_path = HERE.parent / 'checker.py'
    candidate = load_prefix(candidate_path)
    baseline = load_prefix(HERE / 'frozen' / 'one_hole.py')
    fixed = json.loads((HERE/'frozen/inherited_fixtures.json').read_text())
    fixed += json.loads((HERE/'frozen/new_fixtures.json').read_text())
    openings = opening_audit(candidate)
    translated, fixed_results, raw_cohort = [], [], []
    (HERE/'examples').mkdir(exist_ok=True)
    rules = Counter()
    for index, row in enumerate(fixed):
        source = run(baseline, row['packet'])
        assert source['accepted'] == row['expected'], ('frozen source changed', row['name'])
        if source['accepted']:
            target, old = translate(baseline, row['packet'])
            result, oracle = audit(candidate, target, row['name'], True)
            assert result['final_k'] == old['final_k'], ('translation changes eigenparameters', row['name'])
            assert target[-1] == row['packet'][-1], ('translation changes sentence', row['name'])
            translated.append({'name': row['name'], 'cells': len(target),
                               'target_sha256': sha256(json.dumps(target).encode()).hexdigest()})
        else:
            # This conversion is not a proof-producing claim for rejected inputs.
            target = ([unwrap(cell) for cell in row['packet'][:-1]] + [row['packet'][-1]]
                      if type(row['packet']) is list and row['packet'] else row['packet'])
            result, oracle = audit(candidate, target, row['name'])
        rules.update(oracle['rules'])
        fixed_results.append({'name': row['name'], 'accepted': result['accepted'],
                              'source_accepted': source['accepted']})
        raw_cohort.append((row['name'], target, result['accepted']))
        if row['name'].startswith('new/'):
            (HERE/'examples'/f'{index:03}.json').write_text(json.dumps(target)+'\n')
    mutations = []
    rng = random.Random(20261107)
    for i in range(1600):
        parent, packet, _ = raw_cohort[i % len(raw_cohort)]
        mutated = mutate(packet, rng)
        result, oracle = audit(candidate, mutated, f'mutation {i} from {parent}')
        rules.update(oracle['rules'])
        mutations.append({'parent': parent, 'accepted': result['accepted'],
                          'packet_sha256': sha256(json.dumps(mutated).encode()).hexdigest()})
    cli_calls = 0
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp)/'packet.json'
        for name, packet, expected in raw_cohort:
            p.write_text(json.dumps(packet))
            for optimized in (False, True):
                command = [sys.executable, *(['-O'] if optimized else []),
                           str(candidate_path), str(p)]
                process = subprocess.run(command, text=True, capture_output=True, timeout=15)
                wanted = (0, 'ACCEPT\n', '') if expected else (1, 'REJECT\n', '')
                assert (process.returncode, process.stdout, process.stderr) == wanted, (name, process)
                cli_calls += 1
        for text in ('', '{', '[0,]'):
            p.write_text(text)
            for optimized in (False, True):
                process = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                          str(candidate_path), str(p)],
                                         text=True, capture_output=True, timeout=15)
                assert (process.returncode, process.stdout, process.stderr) == (1, 'REJECT\n', '')
                cli_calls += 1
    result = {'status': 'PASS', 'checker_sha256': sha256(candidate_path.read_bytes()).hexdigest(),
              'opening_cases': openings, 'fixed_entries': len(fixed_results),
              'fixed_accepting': sum(r['accepted'] for r in fixed_results),
              'fixed_rejecting': sum(not r['accepted'] for r in fixed_results),
              'positive_source_translations': len(translated),
              'mutation_entries': len(mutations),
              'mutation_accepting': sum(r['accepted'] for r in mutations),
              'cli_calls_normal_and_optimized': cli_calls, 'rules_exercised': dict(rules),
              'scope': 'Finite tests and proof-format translations; no formalized metatheory.',
              'fixed_results': fixed_results, 'translated_positive_sources': translated,
              'mutations': mutations}
    (HERE.parent/'results/audit_results.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('fixed_results', 'translated_positive_sources', 'mutations')}, indent=2))


if __name__ == '__main__':
    main()
