QUANTITATIVE PARTIAL RESULTS FOR UNION-CLOSED FAMILIES
Prepared for Vladimir Reshetnikov, 25 November 2026

START HERE
  union_closed_extensions.pdf is the complete research report.
  union_closed_extensions.tex and sections/*.tex are its editable source.
  This archive does not contain a proof of the unrestricted conjecture.

RESULTS
1. Regular generators with no incidence cycle of length 4, 6, or 8:
   - Each element in r=3 generators; generator size d>=4:
     mean element frequency >5059/10000.
   - Each element in r=4 generators; generator size d>=5:
     mean element frequency >5047/10000.
   More than 59/3750 or 47/4375 of the ground elements, respectively,
   occur in at least half the distinct generated unions.
   A designated regular subsystem can coexist with arbitrary outside
   elements. A separate robustness corollary permits 0.5% bad root
   neighborhoods while retaining mean frequency strictly above one half.

2. Exact nonchain entropy extrema for iterated unions:
   For every sample count s>=2 and every strictly Schur-concave entropy,
   the maximum among nonchain families of N sets is attained by a chain
   with exactly one incomparable pair. An explicit N-2 term list determines
   where that pair is placed, with a full equality classification.
   For Shannon entropy and s=3 it is uniquely at the bottom; the sharp
   loss from chain entropy is (25 ln25 - 7 ln7 - 19 ln19)/N^3.
   The supplied s=2 theorem places the pair at the top instead.

3. Principal-filter refinement of the supplied finite-size entropy bound:
   A telescoping rank-weight estimate improves its integer degree
   guarantees. For N=760 it proves at least 305 occurrences, versus 304
   from the specific previous R_N expression. Five other exact comparisons
   are included. No comparison to all known size-specific results is claimed.

NOVELTY AND ANTECEDENTS
The claims above go beyond the six supplied ProveIt archives at commit
b608a105d79fb6b108f4ad423872ab6b997cf4d5. Their exact forms were not located
in the bounded literature search, whose scope and limitations are recorded
in notes/literature_audit.txt. Historical novelty is provisional.

The chain majorization, two-sample nonchain result, and previous entropy
transfer mechanisms are not claimed as new. A close recent antecedent by
Cinna Davis and GPT-6.2 Astra gives stronger all-point bounds under girth
at least 16 in the element-degree-three case. The present girth-10 result
has a weaker mean conclusion under weaker hypotheses; it does not replace
or improve that antecedent on its own restricted class. Our degree-three
finite witness has exact girth 12, and the degree-four witness girth 10.

REPRODUCE THE CERTIFICATES
Requirements: Python 3.10 or newer; standard library only.
From this directory:
  python3 verify_all.py

This regenerates the JSON files in certificates/ and checks:
  * 15- and 56-term exact rational entropy formulas and strict constants;
  * the 199/200-good-root robustness comparisons;
  * two connected incidence graphs and their absence of short cycles;
  * explicit shortest cycles of lengths 12 and 10;
  * every nonempty union-closed family on at most four labeled points,
    for sample counts 2, 3, 4, and 5 (20,388 checks);
  * 6,154 exact rational transport inequalities over 5,066 families;
  * six integer improvements with outward rational logarithm and sqrt(5)
    intervals. No floating-point quantity decides any certificate.

The structural graph examples are too large for enumeration of all their
distinct unions. Their frequency guarantees are proved analytically.
Small-family computations supplement the proofs; they do not prove the
general statements by themselves.

REBUILD THE PDF
Requires a normal TeX Live or MiKTeX installation with pdfLaTeX, latexmk,
Latin Modern, microtype, AMS packages, mathtools, booktabs, enumitem,
fancyhdr, xcolor, and hyperref.
  make
or:
  latexmk -pdf -interaction=nonstopmode -halt-on-error union_closed_extensions.tex

CONTENTS
  union_closed_extensions.pdf       Compiled report
  union_closed_extensions.tex       Main editable source and bibliography
  sections/high_girth.tex           Generator theorem and complete proof
  sections/multi_union.tex          Sharp multi-sample theorem and proof
  sections/principal_filters.tex    Finite-size refinement and proof
  code/local_entropy.py             Exact entropy certificate
  code/high_girth_examples.py       Connected witness construction
  code/short_cycle_witness.py       Independent exact-girth certificate
  code/verify_multi_union.py        Exhaustive multiplicity checks
  code/verify_filter_refinement.py  Exact combinatorial and numeric checks
  certificates/*.json               Regenerated result data
  notes/literature_audit.txt         Prior-work comparison and search limits
  notes/proof_review.txt             Internal mathematical review
  source_manifest.json              Six input archive hashes and snapshot
  verification_run.txt              Successful complete verifier output
  verify_all.py / Makefile          Reproduction entry points
  SHA256SUMS.txt                    Integrity hashes of deliverable files

PROOF STATUS
Full mathematical proofs with exact finite arithmetic certificates.
Internally reviewed by separate AI agents; not human peer reviewed.
No Lean/Rocq formalization is claimed. The full conjecture remains
unresolved by this work, and the universal limiting abundance constant
is not improved here.
