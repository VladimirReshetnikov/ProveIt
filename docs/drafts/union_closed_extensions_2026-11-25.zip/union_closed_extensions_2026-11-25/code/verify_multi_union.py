"""Exact finite checks for the multi-sample nonchain majorization theorem.

Exhausts every family on at most four labeled points.  This is a check
of a proved theorem, not a finite replacement for the proof.
Only Python's standard library is required.
"""
from collections import Counter
from itertools import product
import json
from pathlib import Path


def union_closed(family):
    present = set(family)
    return all((a | b) in present for a in family for b in family)


def multiplicities(family, samples):
    counts = Counter({a: 1 for a in family})
    for _ in range(1, samples):
        nxt = Counter()
        for a, count in counts.items():
            for b in family:
                nxt[a | b] += count
        counts = nxt
    return sorted(counts.values())


def majorizes(a, b):
    x = y = 0
    for ai, bi in zip(a, b):
        x += ai
        y += bi
        if x > y:
            return False
    return x == y


def profiles(size, samples):
    c = [j**samples - (j - 1)**samples for j in range(1, size + 1)]
    result = []
    for i in range(2, size):
        t = c[i - 1] - c[i - 2]
        d = c.copy()
        d[i - 1] -= t
        d[i] += t
        assert d == sorted(d)
        result.append((i, d))
    return c, result


def check(max_ground=4):
    assert 2**16 * 7**7 * 19**19 - 25**25 == 17960857952228546420317423960691367
    totals = []
    for n in range(max_ground + 1):
        closed = nonchain = tests = equality = 0
        for code in range(1, 1 << (1 << n)):
            fam = [x for x in range(1 << n) if (code >> x) & 1]
            if not union_closed(fam):
                continue
            closed += 1
            fam.sort(key=lambda x: (x.bit_count(), x))
            incomparable = [(i, j) for i in range(len(fam)) for j in range(i + 1, len(fam))
                            if (fam[i] | fam[j]) not in (fam[i], fam[j])]
            if incomparable:
                nonchain += 1
            for s in (2, 3, 4, 5):
                r = multiplicities(fam, s)
                c, candidates = profiles(len(fam), s)
                assert majorizes(r, c)
                assert (r == c) == (not incomparable)
                if incomparable:
                    assert any(majorizes(r, d) for _, d in candidates)
                    for i, d in candidates:
                        expected = len(incomparable) == 1 and incomparable[0] == (i - 2, i - 1)
                        assert (r == d) == expected
                        equality += int(r == d)
                    if s == 3:
                        assert (r == candidates[0][1]) == (incomparable == [(0, 1)])
                if len(fam) <= 4 and s <= 3:
                    brute = Counter()
                    for choices in product(fam, repeat=s):
                        joined = 0
                        for a in choices:
                            joined |= a
                        brute[joined] += 1
                    assert r == sorted(brute.values())
                tests += 1
        totals.append(dict(ground_size=n, nonempty_union_closed_families=closed,
                           nonchain_families=nonchain, sample_count_checks=tests,
                           single_pair_equality_checks=equality))
        print(totals[-1])
    return dict(status="PASS", arithmetic="exact integers", sample_counts=[2, 3, 4, 5],
                maximum_ground_size=max_ground, checks=totals,
                scope="Exhaustive small examples; general validity is established by the written proof.")


if __name__ == "__main__":
    result = check()
    out = Path(__file__).resolve().parents[1] / "certificates"
    out.mkdir(exist_ok=True)
    (out / "multi_union_checks.json").write_text(json.dumps(result, indent=2) + "\n")
