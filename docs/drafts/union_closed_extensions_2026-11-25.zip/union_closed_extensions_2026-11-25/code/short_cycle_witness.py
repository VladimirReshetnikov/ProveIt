"""Check a simple short cycle in each supplied cyclic-lift example.

The witness vertices have format [side, index, residue], with side 0 for
generators and side 1 for ground elements. The cycle closes from its last
vertex to its first. This independent check proves the examples do not
satisfy the girth-at-least-sixteen hypothesis of the Davis antecedent.
"""
from collections import deque
from pathlib import Path
import json


def neighbors(vertex, shifts, modulus):
    side, index, residue = vertex
    if side == 0:
        return [(1, j, (residue + shifts[index][j]) % modulus)
                for j in range(len(shifts[0]))]
    return [(0, i, (residue - shifts[i][index]) % modulus)
            for i in range(len(shifts))]


def cycle_from_edge(left, right, parent):
    left_path = []
    cursor = left
    while cursor is not None:
        left_path.append(cursor)
        cursor = parent[cursor]
    left_positions = {vertex: j for j, vertex in enumerate(left_path)}
    right_path = []
    cursor = right
    while cursor not in left_positions:
        right_path.append(cursor)
        cursor = parent[cursor]
    return left_path[:left_positions[cursor] + 1] + right_path[::-1]


def verify_cycle(cycle, shifts, modulus):
    """Verify distinct vertices, legal bipartition/residues, and every edge."""
    vertices = [tuple(vertex) for vertex in cycle]
    assert len(vertices) >= 4
    assert len(set(vertices)) == len(vertices)
    for vertex in vertices:
        side, index, residue = vertex
        assert side in (0, 1)
        assert 0 <= index < (len(shifts) if side == 0 else len(shifts[0]))
        assert 0 <= residue < modulus
    for j, vertex in enumerate(vertices):
        assert vertices[(j + 1) % len(vertices)] in neighbors(vertex, shifts, modulus)
    return True


def find_short_cycle(shifts, modulus, cutoff=14):
    """Find one cycle of length at most cutoff; no shortest-cycle claim."""
    for root_index in range(len(shifts)):
        root = (0, root_index, 0)
        parent = {root: None}
        depth = {root: 0}
        queue = deque([root])
        while queue:
            vertex = queue.popleft()
            if depth[vertex] >= cutoff // 2:
                continue
            for neighbor in neighbors(vertex, shifts, modulus):
                if neighbor == parent[vertex]:
                    continue
                if neighbor not in parent:
                    parent[neighbor] = vertex
                    depth[neighbor] = depth[vertex] + 1
                    queue.append(neighbor)
                else:
                    candidate = cycle_from_edge(vertex, neighbor, parent)
                    if len(candidate) <= cutoff:
                        assert verify_cycle(candidate, shifts, modulus)
                        return candidate
    raise AssertionError("No short cycle found")


def verify_no_shorter_cycle(shifts, modulus, claimed_girth):
    """Exhaust representative roots for every cycle shorter than the claim.

    Bipartite cycles are even. Translation of residues makes the row-index
    roots representative of every generator vertex. A cycle of length at
    most 2R causes a repeated vertex in the depth-R tree at one of its roots.
    """
    radius = (claimed_girth - 2) // 2
    for root_index in range(len(shifts)):
        root = (0, root_index, 0)
        parent = {root: None}
        queue = deque([(root, 0)])
        while queue:
            vertex, depth = queue.popleft()
            if depth == radius:
                continue
            for neighbor in neighbors(vertex, shifts, modulus):
                if neighbor == parent[vertex]:
                    continue
                assert neighbor not in parent, "Found a cycle shorter than claimed"
                parent[neighbor] = vertex
                queue.append((neighbor, depth + 1))
    return True


if __name__ == "__main__":
    # Written explicitly so this checker also runs as a standalone artifact.
    examples = [
        {"r": 3, "d": 4, "prime": 1009, "shifts": [
            [0, 0, 0, 0], [0, 85, 743, 68], [0, 189, 616, 738]]},
        {"r": 4, "d": 5, "prime": 1009, "shifts": [
            [0, 0, 0, 0, 0], [0, 411, 797, 125, 981],
            [0, 679, 236, 822, 368], [0, 894, 873, 606, 122]]},
    ]
    result = []
    for example in examples:
        cycle = find_short_cycle(example["shifts"], example["prime"])
        assert len(cycle) < 16
        no_shorter = verify_no_shorter_cycle(example["shifts"], example["prime"], len(cycle))
        result.append({
            "r": example["r"], "d": example["d"],
            "modulus": example["prime"], "shifts": example["shifts"],
            "cycle_length": len(cycle), "cycle": cycle,
            "exact_girth": len(cycle), "verified_no_shorter_cycle": no_shorter,
            "verified_simple_cycle": verify_cycle(cycle, example["shifts"], example["prime"]),
            "outside_girth_16_antecedent": True,
        })
        print(f"(r,d)=({example['r']},{example['d']}): verified simple cycle of length {len(cycle)}")
    out = Path(__file__).resolve().parents[1] / "certificates"
    out.mkdir(exist_ok=True)
    (out / "short_cycle_witness.json").write_text(json.dumps(result, indent=2) + "\n")
