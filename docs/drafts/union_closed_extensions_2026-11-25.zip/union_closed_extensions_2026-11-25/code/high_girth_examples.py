"""Construct and verify compact cyclic lifts witnessing the theorem's hypotheses."""
from collections import deque
from random import Random
from pathlib import Path
import json

def neighbors(vertex, shifts, prime):
 side,i,t=vertex
 r,d=len(shifts),len(shifts[0])
 if side==0:return [(1,j,(t+shifts[i][j])%prime) for j in range(d)]
 return [(0,k,(t-shifts[k][i])%prime) for k in range(r)]

def no_short_cycle(shifts,prime):
 # Translation t -> t+a makes these r roots cover all left-side vertices.
 for i in range(len(shifts)):
  root=(0,i,0);seen={root:None};q=deque([(root,0)])
  while q:
   v,depth=q.popleft()
   if depth==4:continue
   for w in neighbors(v,shifts,prime):
    if seen[v]==w:continue
    if w in seen:return False
    seen[w]=v;q.append((w,depth+1))
 return True

def connected(shifts,prime):
 root=(0,0,0);seen={root};q=deque([root])
 while q:
  for w in neighbors(q.popleft(),shifts,prime):
   if w not in seen:seen.add(w);q.append(w)
 return len(seen)==(len(shifts)+len(shifts[0]))*prime

def search(r,d,prime):
 rng=Random(1234+10*r+d)
 for attempt in range(100000):
  shifts=[[0 if i*j==0 else rng.randrange(prime) for j in range(d)] for i in range(r)]
  if no_short_cycle(shifts,prime) and connected(shifts,prime):
   return {'r':r,'d':d,'prime':prime,'left_generators':r*prime,'ground_elements':d*prime,'shifts':shifts,'search_attempt':attempt+1,'girth_at_least':10}
 raise RuntimeError('none')

if __name__=='__main__':
 results=[search(r,d,1009) for r,d in [(3,4),(4,5)]]
 for v in results: print(v)
 out=Path(__file__).resolve().parents[1]/'certificates'
 out.mkdir(exist_ok=True)
 (out/'high_girth_examples.json').write_text(json.dumps(results,indent=2)+'\n')
