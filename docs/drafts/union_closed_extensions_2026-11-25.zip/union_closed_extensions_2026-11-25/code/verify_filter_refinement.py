#!/usr/bin/env python3
"""Exact checks of the principal-filter entropy refinement.

Python standard library only. Place local_entropy.py beside this script.
Every numerical decision uses rational interval arithmetic. Logarithms are
certified by log2_interval's finite artanh series and geometric tail bound.
Their endpoints and every subsequent operation are rounded outward to a
fixed rational grid. Changing logarithms from base e to base 2 leaves all
frequency formulas unchanged.
"""
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from math import isqrt
import json
from local_entropy import log2_interval

OUT = Path(__file__).resolve().parents[1] / 'certificates'
OUT.mkdir(exist_ok=True)
SCALE = 10**30

def floor_fraction(x):
    return x.numerator // x.denominator

def ceil_fraction(x):
    return -((-x.numerator) // x.denominator)

class Interval:
    """Closed interval [lo/SCALE, hi/SCALE] with exact integer endpoints."""
    __slots__ = ('lo', 'hi')
    def __init__(self, lo, hi=None):
        self.lo, self.hi = lo, lo if hi is None else hi
        assert isinstance(self.lo, int) and isinstance(self.hi, int)
        assert self.lo <= self.hi
    @classmethod
    def rational(cls, value):
        v = Fraction(value) * SCALE
        return cls(floor_fraction(v), ceil_fraction(v))
    @classmethod
    def bounds(cls, lo, hi):
        return cls(floor_fraction(lo*SCALE), ceil_fraction(hi*SCALE))
    @staticmethod
    def coerce(other):
        return other if isinstance(other, Interval) else Interval.rational(other)
    def __add__(self, other):
        other = self.coerce(other)
        return Interval(self.lo+other.lo, self.hi+other.hi)
    __radd__ = __add__
    def __neg__(self):
        return Interval(-self.hi, -self.lo)
    def __sub__(self, other):
        return self + (-self.coerce(other))
    def __rsub__(self, other):
        return self.coerce(other) - self
    def __mul__(self, other):
        other = self.coerce(other)
        products = [a*b for a in (self.lo,self.hi) for b in (other.lo,other.hi)]
        return Interval(min(products)//SCALE, -((-max(products))//SCALE))
    __rmul__ = __mul__
    def __truediv__(self, other):
        other = self.coerce(other)
        assert other.lo > 0, 'Only strictly positive denominators are needed.'
        ratios = [Fraction(a*SCALE,b) for a in (self.lo,self.hi)
                  for b in (other.lo,other.hi)]
        return Interval(floor_fraction(min(ratios)), ceil_fraction(max(ratios)))
    def decimal_bounds(self):
        def fmt(v):
            sign = '-' if v < 0 else ''
            whole, frac = divmod(abs(v), SCALE)
            return f'{sign}{whole}.{frac:030d}'
        return [fmt(self.lo),fmt(self.hi)]

def log2(value):
    lo,hi = log2_interval(Fraction(value))
    return Interval.bounds(lo,hi)

def main():
    checked = products = 0
    for ground_n in range(5):
        universe = range(1 << ground_n)
        for mask in range(1,1 << (1 << ground_n)):
            F = [a for a in universe if mask >> a & 1]
            S, N = set(F), len(F)
            if N < 2 or not all(a|b in S for a in F for b in F):
                continue
            # Integer mask order respects subset inclusion.
            eps = int(0 in S)
            ranks = {a:i+1 for i,a in enumerate(F)}
            k = max(sum(a >> x & 1 for a in F) for x in range(ground_n))
            incomp = [(a,b) for a,b in combinations(F,2) if a|b not in (a,b)]
            assert 2*len(incomp) >= (N-k-1)*(N-k)
            if not eps:
                assert 2*len(incomp) >= (N-k)*(N-k+1)
            bcap = max(sum(a|b == b for b in F) for a in F if a)
            for cap in sorted({bcap,k}):
                # Exponentiate the log-transport inequality: exact rationals.
                actual = Fraction(1)
                for a,b in incomp:
                    j, u = max(ranks[a],ranks[b]), ranks[a|b]
                    actual *= Fraction(2*u-1,2*j-1)
                required = Fraction(1)
                for j in range(cap+eps,N):
                    required *= Fraction(2*N-1,2*j-1)
                assert actual >= required, (F,cap,actual,required)
                products += 1
            checked += 1

    sqrt5_floor = isqrt(5*SCALE*SCALE)
    assert sqrt5_floor**2 < 5*SCALE*SCALE < (sqrt5_floor+1)**2
    sqrt5 = Interval(sqrt5_floor,sqrt5_floor+1)
    phi, psi = (sqrt5-1)/2, (3-sqrt5)/2
    rows = []
    for N,K in [(83,34),(88,36),(93,38),(383,154),(506,203),(760,304)]:
        logN = log2(N)
        D = sum(((2*j-1)*log2(Fraction(2*j-1,N))
                 for j in range(1,N+1)),Interval.rational(0))/(N*N)
        oldK = Fraction(2*(N-1),N)*log2(Fraction(2*N-1,2*N-3))
        old = (psi*logN+phi*D+phi*oldK/2)/(logN+phi*oldK)
        scaled_old = N*old
        assert scaled_old.lo > (K-1)*SCALE and scaled_old.hi < K*SCALE
        T = Fraction(2,N*N)*sum((log2(Fraction(2*N-1,2*j-1))
                                for j in range(K+1,N)),Interval.rational(0))
        rhs = psi+phi*(D+T)/logN
        margin = rhs-Fraction(K,N)
        assert margin.lo > 0
        if N == 760:
            assert rhs.lo > 40001878898430*SCALE//10**14
            assert rhs.hi < 40001878898433*SCALE//10**14
        rows.append({'N':N,'old_integer':K,'new_integer':K+1,
                     'old_RN_exact_decimal_interval':old.decimal_bounds(),
                     'new_rhs_at_K_exact_decimal_interval':rhs.decimal_bounds(),
                     'strict_exclusion_margin_exact_decimal_interval':margin.decimal_bounds()})
    result = {'status':'passed',
              'dependencies':'Python standard library; local_entropy.py from this archive',
              'combinatorial_arithmetic':'exact integers and fractions',
              'largest_ground_set_checked':4,
              'union_closed_families_checked':checked,
              'exact_product_inequalities_checked':products,
              'numerical_arithmetic':'exact rational intervals, outward rounding after every operation',
              'interval_grid_denominator':str(SCALE),
              'logarithm_certificate':'log2_interval: 24-term artanh series plus geometric tail bound',
              'square_root_certificate':'integer square root enclosing sqrt(5) on the stated grid',
              'logarithm_base':2,
              'note':'Base changes cancel in every reported frequency formula; decimal endpoints are exact rationals.',
              'integer_examples':rows}
    (OUT/'filter_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(f'PASS: {checked} families; {products} exact product inequalities; {len(rows)} exact rational integer-bound comparisons.')
    for row in rows:
        print(f"N={row['N']}: {row['old_integer']} -> {row['new_integer']}")

if __name__ == '__main__':
    main()
