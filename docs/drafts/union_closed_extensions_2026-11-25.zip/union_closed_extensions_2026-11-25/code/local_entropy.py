"""Exact local entropy certificate for (r,d)=(3,4), incidence girth >=10."""
from fractions import Fraction as F
from math import comb, factorial, log2
import json

def add(a,b):
 c=[F(0)]*max(len(a),len(b))
 for i,v in enumerate(a):c[i]+=v
 for i,v in enumerate(b):c[i]+=v
 return c

def mul(a,b):
 c=[F(0)]*(len(a)+len(b)-1)
 for i,v in enumerate(a):
  for j,w in enumerate(b):c[i+j]+=v*w
 return c

def power(a,k):
 r=[F(1)]
 for _ in range(k):r=mul(r,a)
 return r

def integral(a):return sum((v/F(i+1) for i,v in enumerate(a)),F(0))

def ln_interval(x,N=24):
 assert F(1)<=x<=F(2)
 z=(x-1)/(x+1)
 low=2*sum((z**(2*k+1)/F(2*k+1) for k in range(N)),F(0))
 high=low+2*z**(2*N+1)/(F(2*N+1)*(1-z*z))
 return low,high

def log2_interval(x):
 assert x>0
 k=0
 while x<1:x*=2;k-=1
 while x>=2:x/=2;k+=1
 lo,hi=ln_interval(x);l2,u2=ln_interval(F(2))
 return F(k)+lo/u2,F(k)+hi/l2

def h_interval(x):
 if x==0 or x==1:return F(0),F(0)
 l,u=log2_interval(x);v,w=log2_interval(1-x)
 return -x*u-(1-x)*w,-x*l-(1-x)*v

def phi_interval(z,p):
 b=p+(1-p)*z
 l,u=h_interval(p/b)
 return b*l,b*u

def kl_interval(u,v):
 a,b=log2_interval(u/v);c,d=log2_interval((1-u)/(1-v))
 return u*a+(1-u)*c,u*b+(1-u)*d

def compositions(n,k):
 if k==1:
  yield (n,)
  return
 for i in range(n+1):
  for rest in compositions(n-i,k-1):
   yield (i,)+rest

def certificate(r,d,p,mean_bound):
 c=1-(1-p)**(r-1);q=c**(d-1);b=p+(1-p)*q;s=p/b
 A=[(1-p)*(1-q),(1-p)*q];B=[b,-b]
 weights=[[v*comb(r-1,j) for v in mul(power(A,r-1-j),power(B,j))] for j in range(1,r)]
 weights.append(add([F(1)],[-v for v in power([F(1),-p],r-1)]))
 zvals=[1-(1-s)**j for j in range(1,r)]+[F(1)]
 lower=upper=F(0);mass=F(0);rows=[]
 for counts in compositions(d,r):
  pol=[F(1)];mult=F(factorial(d));z=F(1)
  for k,w,zv in zip(counts,weights,zvals):
   pol=mul(pol,power(w,k));mult/=factorial(k);z*=zv**k
  weight=mult*integral(pol)
  assert weight>=0
  pl,pu=phi_interval(z,p)
  lower+=weight*pl;upper+=weight*pu;mass+=weight
  rows.append({'counts':counts,'weight':str(weight),'z':str(z),'term':float(weight*(pl+pu)/2)})
 hp_l,hp_u=h_interval(p)
 Llo=hp_l-upper;Lhi=hp_u-lower
 deficit_upper=r*(1-Llo);deficit_lower=r*(1-Lhi)
 kl_lo,kl_hi=kl_interval(1-mean_bound,F(1,2**r))
 assert deficit_upper < kl_lo
 if (r,d)==(3,4):
  assert Llo>F(8067679,10000000)
  assert deficit_upper<F(5797,10000)<F(5798,10000)<kl_lo
 if (r,d)==(4,5):
  assert Llo>F(7431163,10000000)
  assert deficit_upper<F(10276,10000)<F(10282,10000)<kl_lo
 eta=F(199,200)
 robust_upper=r*(1-eta*Llo)
 half_kl_lower=kl_interval(F(1,2),F(1,2**r))[0]
 assert robust_upper<half_kl_lower
 if (r,d)==(3,4):
  assert robust_upper<F(592,1000)<F(596,1000)<half_kl_lower
 if (r,d)==(4,5):
  assert robust_upper<F(1043,1000)<F(1046,1000)<half_kl_lower
 certified={
  (3,4):{'L_strict_lower':'8067679/10000000','entropy_deficit_strict_upper':'5797/10000','KL_at_claimed_mean_strict_lower':'5798/10000','robust_deficit_strict_upper':'592/1000','KL_at_half_strict_lower':'596/1000'},
  (4,5):{'L_strict_lower':'7431163/10000000','entropy_deficit_strict_upper':'10276/10000','KL_at_claimed_mean_strict_lower':'10282/10000','robust_deficit_strict_upper':'1043/1000','KL_at_half_strict_lower':'1046/1000'}
 }[(r,d)]
 result={'certified_rational_bounds':certified,'float_values_are_diagnostic':True,'robust_good_proportion':str(eta),'robust_entropy_deficit_upper':float(robust_upper),'half_KL_lower':float(half_kl_lower),'p':str(p),'r':r,'d':d,'s':str(s),'conditional_entropy_interval':[float(lower),float(upper)],'L_interval':[float(Llo),float(Lhi)],'entropy_deficit_interval':[float(deficit_lower),float(deficit_upper)],'mean_bound':str(mean_bound),'mean_bound_decimal':float(mean_bound),'KL_bound_lower':float(kl_lo),'terms':rows}
 print('r,d,p',r,d,p,'L',float(Llo),'deficit',float(deficit_upper),'KL',float(kl_lo),'mean>',mean_bound,'robust deficit',float(robust_upper))
 return result

if __name__=='__main__':
 cases=[(3,4,F(8,25),F(5059,10000)),(4,5,F(4,15),F(5047,10000))]
 results=[certificate(*v) for v in cases]
 from pathlib import Path
 out=Path(__file__).resolve().parents[1]/'certificates'
 out.mkdir(exist_ok=True)
 (out/'local_entropy_certificate.json').write_text(json.dumps(results,indent=2)+'\n')
