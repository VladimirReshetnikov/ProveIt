"""Reproduce every mathematical certificate with Python's standard library."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SCRIPTS = ["local_entropy.py", "high_girth_examples.py", "short_cycle_witness.py",
           "verify_multi_union.py", "verify_filter_refinement.py"]
for name in SCRIPTS:
    print("\nRunning " + name, flush=True)
    subprocess.run([sys.executable, str(ROOT / "code" / name)], cwd=ROOT, check=True)
print("\nPASS: all certificate programs completed successfully.")
