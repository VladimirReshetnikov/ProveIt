PRA BY POSITIVE RECURSION UNIQUENESS
31 October 2026
====================================

MAIN RESULT

A common nonlogical axiomatization for classical and intuitionistic PRA,
using the current drafts' unchanged binary initialized-iterator language
and one fixed numerical parameter per arithmetic instance:

  I_h(0,a)  = a
  I_h(Sn,a) = h(n,I_h(n,a))

  forall a (
    [forall n: f(SSn,a) = h(n,f(Sn,a))]
      -> [0 != 1 AND forall n:
           (n = 0 OR f(n,a) = I_h(p(n),f(1,a)))]
  ).

Here 1=S0 and p(n)=I_[(k,v) maps to k](n,0).
The update h has only its counter and state free. It cannot separately
read a frozen seed/parameter. f is any finite term in n,a. There is no
base-admission test, normalization requirement, or semantic oracle.

The arithmetic formula has FOUR equality occurrences and 39 expanded AST
nodes, compared with FIVE equalities and 39 nodes for the strongest current
reflexive-base draft. The predecessor abbreviation is fully expanded in
this count. Both presentations have the same three axiom templates and
infinite description-indexed signature. This is a precise relative
improvement, not a claim of absolute or historically first minimality.

READ FIRST

  pra_positive_uniqueness.pdf       Complete 16-page research paper.
  axioms.txt                       Exact standalone formal specification.

CONTENTS

  pra_positive_uniqueness.tex       Main LaTeX source.
  sections/*.tex                   Four included source sections.
  formal/*.lean                    Three Lean 4.19.0 certificates.
  formal/*.log                     Actual successful dependency-audit logs.
  formal/README.txt                Precise formalization scope.
  artifacts/check_syntax.py        Formula-tree and allowed-update checker.
  audit/syntax_and_metrics.json    Full reconstructed formulas and results.
  audit/latex.log                  Successful final LaTeX build log.
  audit/verification_summary.json  Recorded verification facts.
  notes/boolean_bootstrap.txt      Detailed restriction/dependency notes.
  source_audit.json                Pinned comparison sources and hashes.
  build.sh                        Rebuild the PDF.
  check.sh                        Replay Python and Lean checks.
  lean-toolchain                  Lean version pin.
  SHA256SUMS                      Integrity manifest.

PROOF OUTLINE

Positive uniqueness gives constructor coverage and ordinary term-recursion
uniqueness. Simple recurrence comparisons give addition and subtraction
identities, including Shift. A number-plus-one-bit encoding then stores the
sole passive parameter, yielding zero-test induction without general pairing.
A Boolean row scanner proves strict comparison complement. The two terms

  n + M(n,a),       a + M(a,n)

share the allowed parameter-free update

  h(n,v) = v + B(M(n,v),1),

where M(x,y) means y truncated-minus x and B is the zero gate. Uniqueness
proves their native equality. Mutual vanishing of the two monus values
therefore implies native equality of n and a. Only then are arbitrary
quantifier-free formulas compiled into zero tests. Internal triangular
pairing and state simulation recover all finite parameter tuples and
ordinary primitive recursion.

The paper proves explicit conservative definitional equivalence with ordinary
PRA in each logic separately. It does not identify the arbitrary quantified
theorems of the classical and intuitionistic first-order theories.

REBUILD

Requirements: Python 3.10+ (standard library only); Lean 4.19.0 (no Mathlib
or external packages); pdfLaTeX with the standard packages named in the
source, including amsmath, amsthm, mathtools, lmodern, microtype, hyperref.

From this directory:

  sh build.sh
  sh check.sh

If Lean is not on PATH:

  LEAN_BIN=/absolute/path/to/lean sh check.sh

For syntax/metric checks alone:

  python3 artifacts/check_syntax.py --output audit/syntax_and_metrics.json

To check the delivered hashes, before regenerating the PDF or audit outputs:

  sha256sum -c SHA256SUMS

VERIFICATION SCOPE

PositiveUniqueness.lean uses genuine finite well-founded iterator syntax and
an arbitrary arithmetic carrier. It checks the new schema through contextual
zero-equation induction for every finite term. BooleanDiagonal.lean and
MaxReflection.lean separately check the subsequent mathematical bridges,
exposing exactly the selected local induction and uniqueness hypotheses.

There are 53 printed dependency audits (27 + 11 + 15), all with no global
Lean axiom dependencies. Their explicit arithmetic/schema theorem inputs
remain assumptions; an empty global dependency list does not erase them.
There are no proof placeholders or classical assumptions in these modules.

The package does NOT claim one linked formalization of the entire first-order
derivability calculus or the complete definitional-equivalence endpoint.
The formula compiler, general pairing, and extension theorem are supplied
with written proofs. The Python finite-natural diagnostics are sanity checks,
not proofs of universal mathematical claims.

COMPARISON AND ATTRIBUTION

All four current draft archives were read at ProveIt commit
66372d99e4f4e1d3a48822b9d322ae9e9ae7e7e3. Their Git blob hashes were checked.
The incoming directory and its index had no PRA-labelled entry; unrelated
archives were not unpacked. The current drafts already achieve zero-rewrite
literal base admission, so that reduction is credited as prior work.

The language, one-parameter goal, positive coverage strategy, formula metric,
and triangular completion are inherited. The new relative contribution is
the positive-uniqueness schema and its noncircular equality bootstrap.
Goodstein's classical recursion-uniqueness work is cited in the paper.

No repository files were changed or committed for this report.
