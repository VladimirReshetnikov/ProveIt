import Lean

/-!
# Native equality reflection from positive recursion uniqueness

This certificate checks the new maximum-identity argument on an arbitrary
carrier. It does not use induction on Lean's natural numbers, classical
logic, an equality oracle, or a postulate for every Lean predicate.

The arithmetic equations, positive constructor coverage, and strict-order
duality below are explicit hypotheses. In the accompanying paper they are
derived before this argument. In particular, strict-order duality comes from
the Boolean diagonal lemma, not from a pre-existing order or equality test.

Exactly one specified Boolean-induction instance is used: its matrix is an
implication between two equations to zero. Exactly two specified recursion-
uniqueness instances are used, for the two displayed maximum terms. Their
common update depends only on the counter and current state.

This file certifies this bridge, not the complete syntax-level conservative
extension theorem. Every printed theorem has its remaining assumptions as
ordinary parameters; the audit should report no global axiom dependencies.
-/

set_option autoImplicit false

namespace PositiveUniqueness.MaxReflection

universe u

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  add : A → A → A
  monus : A → A → A
  gate : A → A → A
  pred_zero : pred zero = zero
  coverage : ∀ x, x = zero ∨ x = succ (pred x)
  succ_nonzero : ∀ x, succ x ≠ zero
  add_zero_left : ∀ x, add zero x = x
  add_zero_right : ∀ x, add x zero = x
  add_succ_left : ∀ x y, add (succ x) y = succ (add x y)
  add_succ_right : ∀ x y, add x (succ y) = succ (add x y)
  monus_zero_left : ∀ x, monus zero x = x
  monus_zero_right : ∀ x, monus x zero = zero
  monus_succ_left : ∀ x y, monus (succ x) y = pred (monus x y)
  monus_shift : ∀ x y, monus (succ x) (succ y) = monus x y
  monus_pred_second : ∀ x y, pred (monus x (succ y)) = monus x y
  monus_cancel : ∀ x y, monus x (add x y) = y
  gate_zero : ∀ x, gate zero x = x
  gate_succ : ∀ x y, gate (succ x) y = zero

variable {A : Type u}

theorem zero_decision (m : Arithmetic A) (x : A) :
    x = m.zero ∨ x ≠ m.zero := by
  cases m.coverage x with
  | inl is_zero => exact Or.inl is_zero
  | inr is_succ =>
    apply Or.inr
    intro is_zero
    exact m.succ_nonzero (m.pred x) (is_succ.symm.trans is_zero)

theorem gate_nonzero (m : Arithmetic A) (x y : A)
    (nonzero : x ≠ m.zero) : m.gate x y = m.zero := by
  have is_succ := (m.coverage x).resolve_left nonzero
  exact (congrArg (fun z => m.gate z y) is_succ).trans
    (m.gate_succ (m.pred x) y)

theorem add_one_right (m : Arithmetic A) (x : A) :
    m.add x (m.succ m.zero) = m.succ x := by
  exact (m.add_succ_right x m.zero).trans
    (congrArg m.succ (m.add_zero_right x))

theorem monus_diagonal (m : Arithmetic A) (x : A) :
    m.monus x x = m.zero := by
  exact (congrArg (m.monus x) (m.add_zero_right x)).symm.trans
    (m.monus_cancel x m.zero)

def maxLeft (m : Arithmetic A) (n a : A) : A :=
  m.add n (m.monus n a)

def maxRight (m : Arithmetic A) (n a : A) : A :=
  m.add a (m.monus a n)

def maxUpdate (m : Arithmetic A) (n v : A) : A :=
  m.add v (m.gate (m.monus n v) (m.succ m.zero))

def StrictDuality (m : Arithmetic A) : Prop :=
  ∀ n a, (m.monus n a ≠ m.zero ↔ m.monus a (m.succ n) = m.zero)

def ZeroOrderInvariant (m : Arithmetic A) (n a : A) : Prop :=
  m.monus n a = m.zero → m.monus n (maxRight m n a) = m.zero

/-- The single induction matrix is a Boolean combination of zero equations. -/
def OrderInductionInstance (m : Arithmetic A) (a : A) : Prop :=
  ZeroOrderInvariant m m.zero a →
    (∀ n, ZeroOrderInvariant m n a → ZeroOrderInvariant m (m.succ n) a) →
    ∀ n, ZeroOrderInvariant m n a

theorem zero_order_base (m : Arithmetic A) (a : A) :
    ZeroOrderInvariant m m.zero a := by
  intro initial
  have a_zero : a = m.zero := (m.monus_zero_left a).symm.trans initial
  calc
    m.monus m.zero (maxRight m m.zero a) = maxRight m m.zero a :=
      m.monus_zero_left _
    _ = m.add a m.zero := congrArg (m.add a) (m.monus_zero_right a)
    _ = a := m.add_zero_right a
    _ = m.zero := a_zero

theorem zero_order_step (m : Arithmetic A) (duality : StrictDuality m)
    (n a : A) (previous : ZeroOrderInvariant m n a) :
    ZeroOrderInvariant m (m.succ n) a := by
  intro next_zero
  cases zero_decision m (m.monus n a) with
  | inl remainder_zero =>
    cases zero_decision m (m.monus a (m.succ n)) with
    | inl other_zero =>
      simpa only [maxRight, other_zero, m.add_zero_right] using next_zero
    | inr other_nonzero =>
      have other_succ : m.monus a (m.succ n) = m.succ (m.monus a n) :=
        ((m.coverage _).resolve_left other_nonzero).trans
          (congrArg m.succ (m.monus_pred_second a n))
      simpa only [maxRight, other_succ, m.add_succ_right, m.monus_shift]
        using previous remainder_zero
  | inr remainder_nonzero =>
    have other_zero := (duality n a).mp remainder_nonzero
    simpa only [maxRight, other_zero, m.add_zero_right] using next_zero

theorem zero_order_invariant (m : Arithmetic A) (duality : StrictDuality m)
    (induct : ∀ a, OrderInductionInstance m a) :
    ∀ n a, ZeroOrderInvariant m n a := by
  intro n a
  exact induct a (zero_order_base m a) (fun k => zero_order_step m duality k a) n

theorem max_left_base (m : Arithmetic A) (a : A) :
    maxLeft m m.zero a = a := by
  exact (m.add_zero_left (m.monus m.zero a)).trans (m.monus_zero_left a)

theorem max_right_base (m : Arithmetic A) (a : A) :
    maxRight m m.zero a = a := by
  exact (congrArg (m.add a) (m.monus_zero_right a)).trans (m.add_zero_right a)

theorem max_left_step (m : Arithmetic A) (n a : A) :
    maxLeft m (m.succ n) a = maxUpdate m n (maxLeft m n a) := by
  cases zero_decision m (m.monus n a) with
  | inl remainder_zero =>
    have current : maxLeft m n a = n :=
      (congrArg (m.add n) remainder_zero).trans (m.add_zero_right n)
    have next_remainder : m.monus (m.succ n) a = m.zero :=
      (m.monus_succ_left n a).trans
        ((congrArg m.pred remainder_zero).trans m.pred_zero)
    have next : maxLeft m (m.succ n) a = m.succ n :=
      (congrArg (m.add (m.succ n)) next_remainder).trans
        (m.add_zero_right (m.succ n))
    have update : maxUpdate m n (maxLeft m n a) = m.succ n := by
      calc
        maxUpdate m n (maxLeft m n a) = maxUpdate m n n :=
          congrArg (maxUpdate m n) current
        _ = m.add n (m.gate m.zero (m.succ m.zero)) :=
          congrArg (fun z => m.add n (m.gate z (m.succ m.zero)))
            (monus_diagonal m n)
        _ = m.add n (m.succ m.zero) :=
          congrArg (m.add n) (m.gate_zero (m.succ m.zero))
        _ = m.succ n := add_one_right m n
    exact next.trans update.symm
  | inr remainder_nonzero =>
    have remainder_succ := (m.coverage (m.monus n a)).resolve_left remainder_nonzero
    have unchanged : maxLeft m (m.succ n) a = maxLeft m n a := by
      calc
        maxLeft m (m.succ n) a =
            m.add (m.succ n) (m.pred (m.monus n a)) :=
          congrArg (m.add (m.succ n)) (m.monus_succ_left n a)
        _ = m.succ (m.add n (m.pred (m.monus n a))) := m.add_succ_left _ _
        _ = m.add n (m.succ (m.pred (m.monus n a))) := (m.add_succ_right _ _).symm
        _ = maxLeft m n a := congrArg (m.add n) remainder_succ.symm
    have test : m.monus n (maxLeft m n a) = m.monus n a :=
      m.monus_cancel n (m.monus n a)
    have gate_zero : m.gate (m.monus n (maxLeft m n a)) (m.succ m.zero) =
        m.zero := by
      rw [test]
      exact gate_nonzero m _ _ remainder_nonzero
    rw [unchanged, maxUpdate, gate_zero, m.add_zero_right]

theorem max_right_step (m : Arithmetic A) (duality : StrictDuality m)
    (invariant : ∀ n a, ZeroOrderInvariant m n a) (n a : A) :
    maxRight m (m.succ n) a = maxUpdate m n (maxRight m n a) := by
  cases zero_decision m (m.monus a (m.succ n)) with
  | inl next_remainder_zero =>
    have remainder_zero : m.monus a n = m.zero :=
      (m.monus_pred_second a n).symm.trans
        ((congrArg m.pred next_remainder_zero).trans m.pred_zero)
    have other_nonzero := (duality n a).mpr next_remainder_zero
    have gate_zero := gate_nonzero m (m.monus n a) (m.succ m.zero) other_nonzero
    have current : maxRight m n a = a :=
      (congrArg (m.add a) remainder_zero).trans (m.add_zero_right a)
    have next : maxRight m (m.succ n) a = a :=
      (congrArg (m.add a) next_remainder_zero).trans (m.add_zero_right a)
    have update : maxUpdate m n (maxRight m n a) = a := by
      calc
        maxUpdate m n (maxRight m n a) = maxUpdate m n a :=
          congrArg (maxUpdate m n) current
        _ = m.add a m.zero := congrArg (m.add a) gate_zero
        _ = a := m.add_zero_right a
    exact next.trans update.symm
  | inr next_remainder_nonzero =>
    have other_zero : m.monus n a = m.zero := by
      cases zero_decision m (m.monus n a) with
      | inl is_zero => exact is_zero
      | inr nonzero =>
        exact False.elim (next_remainder_nonzero ((duality n a).mp nonzero))
    have next_remainder_succ :
        m.monus a (m.succ n) = m.succ (m.monus a n) :=
      ((m.coverage _).resolve_left next_remainder_nonzero).trans
        (congrArg m.succ (m.monus_pred_second a n))
    have test_zero := invariant n a other_zero
    have next : maxRight m (m.succ n) a = m.succ (maxRight m n a) :=
      (congrArg (m.add a) next_remainder_succ).trans
        (m.add_succ_right a (m.monus a n))
    have update : maxUpdate m n (maxRight m n a) = m.succ (maxRight m n a) := by
      calc
        maxUpdate m n (maxRight m n a) =
            m.add (maxRight m n a) (m.gate m.zero (m.succ m.zero)) :=
          congrArg (fun z => m.add (maxRight m n a) (m.gate z (m.succ m.zero)))
            test_zero
        _ = m.add (maxRight m n a) (m.succ m.zero) :=
          congrArg (m.add (maxRight m n a)) (m.gate_zero (m.succ m.zero))
        _ = m.succ (maxRight m n a) := add_one_right m _
    exact next.trans update.symm

/-- This is one specified term-uniqueness instance, not an induction axiom. -/
def UniquenessInstance (m : Arithmetic A) (iterator : A → A → A)
    (term : A → A) : Prop :=
  (∀ n, term (m.succ n) = maxUpdate m n (term n)) →
    ∀ n, term n = iterator n (term m.zero)

theorem symmetric_maximum (m : Arithmetic A) (duality : StrictDuality m)
    (induct : ∀ a, OrderInductionInstance m a) (iterator : A → A → A)
    (left_unique : ∀ a, UniquenessInstance m iterator (fun n => maxLeft m n a))
    (right_unique : ∀ a, UniquenessInstance m iterator (fun n => maxRight m n a)) :
    ∀ n a, maxLeft m n a = maxRight m n a := by
  have invariant := zero_order_invariant m duality induct
  intro n a
  have left_result := left_unique a (fun k => max_left_step m k a)
  have right_result := right_unique a (fun k => max_right_step m duality invariant k a)
  calc
    maxLeft m n a = iterator n (maxLeft m m.zero a) := left_result n
    _ = iterator n a := congrArg (iterator n) (max_left_base m a)
    _ = iterator n (maxRight m m.zero a) :=
      (congrArg (iterator n) (max_right_base m a)).symm
    _ = maxRight m n a := (right_result n).symm

theorem native_equality_reflection (m : Arithmetic A)
    (maximum : ∀ n a, maxLeft m n a = maxRight m n a) :
    ∀ x y, (m.monus x y = m.zero ∧ m.monus y x = m.zero) ↔ x = y := by
  intro x y
  constructor
  · intro remainders
    simpa only [maxLeft, maxRight, remainders.1, remainders.2, m.add_zero_right]
      using maximum x y
  · intro same
    subst y
    exact ⟨monus_diagonal m x, monus_diagonal m x⟩

theorem sum_zero_iff (m : Arithmetic A) (x y : A) :
    m.add x y = m.zero ↔ (x = m.zero ∧ y = m.zero) := by
  constructor
  · intro sum_zero
    cases m.coverage x with
    | inl first_zero =>
      have second_zero : y = m.zero := by
        calc
          y = m.add m.zero y := (m.add_zero_left y).symm
          _ = m.add x y := congrArg (fun z => m.add z y) first_zero.symm
          _ = m.zero := sum_zero
      exact ⟨first_zero, second_zero⟩
    | inr first_succ =>
      have impossible : m.succ (m.add (m.pred x) y) = m.zero := by
        exact ((congrArg (fun z => m.add z y) first_succ).trans
          (m.add_succ_left (m.pred x) y)).symm.trans sum_zero
      exact False.elim (m.succ_nonzero _ impossible)
  · intro both_zero
    exact (congrArg (fun z => m.add z y) both_zero.1).trans
      ((m.add_zero_left y).trans both_zero.2)

theorem native_equality_decision (m : Arithmetic A)
    (maximum : ∀ n a, maxLeft m n a = maxRight m n a) :
    ∀ x y : A, x = y ∨ x ≠ y := by
  intro x y
  have reflected :
      m.add (m.monus x y) (m.monus y x) = m.zero ↔ x = y :=
    (sum_zero_iff m _ _).trans (native_equality_reflection m maximum x y)
  cases zero_decision m (m.add (m.monus x y) (m.monus y x)) with
  | inl error_zero => exact Or.inl (reflected.mp error_zero)
  | inr error_nonzero =>
    exact Or.inr (fun same => error_nonzero (reflected.mpr same))

#print axioms zero_decision
#print axioms gate_nonzero
#print axioms add_one_right
#print axioms monus_diagonal
#print axioms zero_order_base
#print axioms zero_order_step
#print axioms zero_order_invariant
#print axioms max_left_base
#print axioms max_right_base
#print axioms max_left_step
#print axioms max_right_step
#print axioms symmetric_maximum
#print axioms native_equality_reflection
#print axioms sum_zero_iff
#print axioms native_equality_decision

end PositiveUniqueness.MaxReflection
