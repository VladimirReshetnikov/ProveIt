FORMAL CERTIFICATES: EXACT SCOPE
================================

Lean version: 4.19.0. No imports or external packages are needed.
Replay all files with ../check.sh from the package root.

1. PositiveUniqueness.lean -- 27 audited declarations

Actual finite term syntax has zero, successor, two variables, and binary
iterator application indexed by an independently scoped finite update term.
Substitution does not enter an update descriptor. Thus the model interface
matches the original language, not an unrestricted scheme over all functions.
The arithmetic carrier is arbitrary and receives no built-in induction.

Certified: substitution semantics; separation; successor injectivity and
nonzeroness; PU-to-ordinary-uniqueness; coverage; zero decision; the required
addition and monus identities; selector; parity, half and double; number-plus-
one-bit retractions; contextual zero-equation induction for every finite term.

The new zero-induction update explicitly decodes the passive parameter from
the current state. It contains no frozen parameter. Doubling here is the
iterator with update SSv; the manuscript's a+a has the same equations and is
identified with it by the proved uniqueness principle.

2. BooleanDiagonal.lean -- 11 audited declarations

An arbitrary-carrier interface states the already established arithmetic
equations and the two bit-storage decoders. The scanner's allowed recurrence
and the single specified identity-update uniqueness instance imply stored-
parameter preservation and the row recurrence.

The diagonal proof exposes exactly three selected zero-induction families:
the Boolean row-shift equation, the pair of consecutive complete-row values,
and the descending-prefix equation. Each has at most one fixed parameter.
It proves the diagonal lemma and instantiates it with an explicit Boolean
code to derive M(n,a)!=0 iff M(a,Sn)=0.

3. MaxReflection.lean -- 15 audited declarations

An arbitrary-carrier interface states the established arithmetic equations
and coverage. The proof takes strict comparison complement from the preceding
module, one specifically displayed induction instance involving only zero
equations, and the two uniqueness instances for the two maximum terms.

Certified: the zero-test invariant; both maximum recurrences; symmetric
maximum; native equality reflection; sum-zero reflection; native equality
decision. The shared update has only its counter and current state free.

DEPENDENCIES AND LIMITS

All 53 printed #print axioms outputs report no global Lean axioms. Arithmetic,
schema, and explicitly named local induction/uniqueness premises remain
theorem hypotheses. No theorem assumes arbitrary numerical induction,
Classical.choice, native equality decidability, or a standard-natural carrier.

The three modules are intentionally independent certificates. The first uses
actual finite syntax; the latter two check their precise mathematical
interfaces. The manuscript supplies the term instantiations and the links.
This is NOT one fully linked first-order proof-calculus formalization.

The general formula compiler, triangular pairing, arbitrary parameter-tuple
elimination, and conservative definitional-equivalence theorem are proved
in the paper, not asserted to be complete Lean endpoints in these files.
