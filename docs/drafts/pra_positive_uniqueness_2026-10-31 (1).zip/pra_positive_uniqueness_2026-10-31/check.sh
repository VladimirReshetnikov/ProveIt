#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check_syntax.py --output audit/syntax_and_metrics.json
lean_binary=${LEAN_BIN:-lean}
if ! command -v "$lean_binary" >/dev/null 2>&1; then
  printf '%s\n' 'Lean not found. Set LEAN_BIN to a Lean 4.19.0 executable.' >&2
  exit 1
fi
"$lean_binary" --version
for source in PositiveUniqueness BooleanDiagonal MaxReflection; do
  "$lean_binary" "formal/$source.lean" > "formal/$source.log"
  cat "formal/$source.log"
done
