#!/usr/bin/env python3
"""Reproduce formula counts and check the important finite update syntax.

This is not a first-order proof checker. Lean certificates and the manuscript
carry the mathematical claims. Bounded natural-number diagnostics below are
explicitly separated from syntax and formula-tree checks.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    label: str = ""
    args: tuple["Node", ...] = ()

    def data(self):
        return {"kind": self.kind, "label": self.label,
                "args": [a.data() for a in self.args]}


def var(name):
    return Node("variable", name)


ZERO = Node("constant", "0")


def app(name, *args):
    return Node("function", name, tuple(args))


def succ(t):
    return app("S", t)


ONE = succ(ZERO)


def form(kind, *args, label=""):
    return Node(kind, label, tuple(args))


def eq(s, t):
    return form("equality", s, t)


def imp(s, t):
    return form("implies", s, t)


def forall(name, t):
    return form("forall", t, label=name)


def counts(t):
    result = Counter({t.kind: 1})
    for child in t.args:
        result.update(counts(child))
    return result


def formula_metrics():
    n, a = var("n"), var("a")
    sep = imp(eq(ZERO, ONE), form("bottom"))
    E = lambda x: eq(app("s", x, a), app("t", x, a))
    swap = lambda x: eq(app("H", x, ONE, a), app("H", ONE, x, a))
    guarded = lambda e: forall("n", form("or", eq(n, ZERO), e(n)))
    preserve = lambda e: forall("n", imp(e(n), e(succ(n))))
    rb = forall("a", imp(preserve(E), form("and", sep, guarded(E))))
    rb_sep = forall("a", imp(preserve(E), guarded(E)))
    tr = forall("a", imp(preserve(swap), form("and", sep, guarded(swap))))
    f = lambda x: app("f", x, a)
    premise = forall("n", eq(f(succ(succ(n))), app("h", n, f(succ(n)))))
    # Predecessor is NOT a primitive unary symbol: expand p(n)=I_k(n,0).
    conclusion = forall("n", form("or", eq(n, ZERO),
        eq(f(n), app("I_h", app("I_k", n, ZERO), f(ONE)))))
    pu = forall("a", imp(premise, form("and", sep, conclusion)))
    pu_sep = forall("a", imp(premise, conclusion))
    candidates = {
        "current_RB_packed": (rb,),
        "current_RB_separated": (sep, rb_sep),
        "current_transposition": (tr,),
        "new_PU_packed": (pu,),
        "new_PU_separated": (sep, pu_sep),
    }
    expected = {
        "current_RB_packed": (39, 5),
        "current_RB_separated": (38, 5),
        "current_transposition": (51, 5),
        "new_PU_packed": (39, 4),
        "new_PU_separated": (38, 4),
    }
    result = {}
    for name, formulas in candidates.items():
        tally = Counter()
        for formula in formulas:
            tally.update(counts(formula))
        size = sum(tally.values())
        assert (size, tally["equality"]) == expected[name], (name, tally)
        result[name] = {
            "nodes": size,
            "equality_occurrences": tally["equality"],
            "arithmetic_templates": len(formulas),
            "templates_including_computation": len(formulas) + 2,
            "by_kind": dict(sorted(tally.items())),
            "formulas": [f.data() for f in formulas],
        }
    return {
        "metric": "One node per variable, constant, application, equality, "
            "connective, falsehood, or single-variable quantifier. Negation is "
            "implication to falsehood; 1=S0; p(n)=I_k(n,0). Schematic bodies "
            "are excluded, their displayed arguments included. Program indices "
            "are part of function-symbol names, not extra term arguments.",
        "not_counted": ["common computation schemas", "substituted term bodies",
                        "bit length of program indices", "proof length"],
        "rows": result,
    }


def free_vars(t):
    if t.kind == "variable":
        return {t.label}
    result = set()
    for child in t.args:
        result.update(free_vars(child))
    return result


def substitute(t, mapping):
    if t.kind == "variable":
        return mapping.get(t.label, t)
    return Node(t.kind, t.label, tuple(substitute(c, mapping) for c in t.args))


def expand_placeholder(t, name, replacement, slots):
    children = tuple(expand_placeholder(c, name, replacement, slots) for c in t.args)
    if t.kind == "function" and t.label == name:
        assert len(children) == len(slots)
        return substitute(replacement, dict(zip(slots, children)))
    return Node(t.kind, t.label, children)


def validate_term(t, available):
    if t.kind in {"variable", "constant"}:
        assert not t.args
        return
    assert t.kind == "function", t
    if t.label == "S":
        assert len(t.args) == 1
    else:
        assert t.label in available, t.label
        assert len(t.args) == 2, (t.label, len(t.args))
    for child in t.args:
        validate_term(child, available)


def pred(x):
    return app("P", x, ZERO)


def add(x, y):
    return app("A", x, y)


def gate(x, y):
    return app("B", x, y)


def monus(x, y):
    return app("M", x, y)


def select(z, u, v):
    return add(gate(z, u), gate(gate(z, ONE), v))


def zero_test(x):
    return gate(x, ONE)


def parity(x):
    return app("Parity", x, ZERO)


def half(x):
    return app("Half", x, ZERO)


def encode(a, b):
    d = add(a, a)
    return select(b, d, succ(d))


def bit_and(b, c):
    return select(b, ZERO, c)


def syntax_checks():
    k, v = var("k"), var("v")
    n, a = var("n"), var("a")
    # An update descriptor is checked in its own k,v scope. Calls to earlier
    # binary symbols do not substitute into those symbols' stored descriptors.
    declarations = [
        ("P", k),
        ("A", succ(v)),
        ("B", ZERO),
        ("M", pred(v)),
        ("Parity", zero_test(v)),
        ("Half", select(parity(k), v, succ(v))),
        ("Identity", v),
    ]
    available = set()
    summaries = []
    for name, update in declarations:
        validate_term(update, available)
        assert free_vars(update) <= {"k", "v"}
        summaries.append({"symbol": name, "update_free_variables":
                          sorted(free_vars(update)), "update": update.data()})
        available.add(name)

    # F(n,a) and Q(x,y) are syntax metavariables, not added primitive symbols.
    b = lambda x, y: select(app("F", x, y), ZERO, ONE)
    zi_update = encode(half(v), select(parity(v), ZERO, b(succ(k), half(v))))
    row_update = encode(half(v), bit_and(parity(v),
                        app("Q", k, monus(k, half(v)))))
    max_update = add(v, gate(monus(k, v), ONE))
    for update in (zi_update, row_update, max_update):
        validate_term(update, available | {"F", "Q"})
        assert free_vars(update) <= {"k", "v"}

    substitutions = [
        n, a, add(n, a), monus(n, succ(a)),
        add(add(n, a), add(n, a)),
        select(n, monus(a, n), add(n, succ(a))),
    ]
    checked = []
    for idx, term in enumerate(substitutions):
        for name, proto in (("F", zi_update), ("Q", row_update)):
            actual = expand_placeholder(proto, name, term, ("n", "a"))
            validate_term(actual, available)
            assert free_vars(actual) <= {"k", "v"}
            checked.append({"placeholder": name, "substitution": idx,
                            "free_variables": sorted(free_vars(actual))})

    forbidden = add(v, a)
    assert not free_vars(forbidden) <= {"k", "v"}
    unavailable = False
    try:
        validate_term(app("Self", k, v), available)
    except AssertionError:
        unavailable = True
    assert unavailable
    return {
        "declarations": summaries,
        "important_updates": {
            "zero_induction": zi_update.data(),
            "row_scanner": row_update.data(),
            "shared_maximum": max_update.data(),
        },
        "schematic_substitution_checks": checked,
        "rejected_frozen_parameter": sorted(free_vars(forbidden)),
        "rejected_undeclared_self_reference": unavailable,
        "scope": "Finite syntax and free-variable checks, not proof of the "
                 "schemas' arithmetic consequences. F and Q are replaced by "
                 "actual finite terms; they are not new primitive symbols.",
    }


def finite_diagnostics():
    # These are finite checks on ordinary naturals, NOT theorem proofs.
    M = lambda x, y: max(y - x, 0)
    gate_n = lambda z, b: b if z == 0 else 0
    update = lambda n, v: v + gate_n(M(n, v), 1)
    totals = Counter()
    for n in range(31):
        for a in range(25):
            f = lambda k: k + M(k, a)
            g = lambda k: a + M(a, k)
            assert f(n + 1) == update(n, f(n))
            assert g(n + 1) == update(n, g(n))
            assert (M(n, a) != 0) == (M(a, n + 1) == 0)
            assert M(n, a) != 0 or M(n, a + M(a, n)) == 0
            totals["max_and_comparison_instances"] += 1
        for b in (0, 1):
            enc = 2 * n + b
            assert enc // 2 == n and enc % 2 == b
            totals["one_bit_retraction_instances"] += 1
    # The coordinatewise product counterexample at (0,1).
    point = (0, 1)
    p = tuple(max(x - 1, 0) for x in point)
    sp = tuple(x + 1 for x in p)
    assert point != (0, 0) and point != sp
    return {"scope": "Finite standard-natural diagnostics only; not universal "
                     "equivalence, schema soundness, or formal verification.",
            "checks": dict(totals),
            "coverage_counterexample": {"point": point, "S_pred": sp}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = {
        "status": "passed",
        "formula_comparison": formula_metrics(),
        "syntax": syntax_checks(),
        "finite_diagnostics": finite_diagnostics(),
        "not_certified_by_this_script": ["PRA equivalence", "global minimality",
                                        "historical novelty", "Lean proofs"],
    }
    content = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(content)
        print("Passed: all declared formula counts, update scopes, and diagnostics.")
        print(f"Report: {args.output}")
    else:
        print(content, end="")


if __name__ == "__main__":
    main()
