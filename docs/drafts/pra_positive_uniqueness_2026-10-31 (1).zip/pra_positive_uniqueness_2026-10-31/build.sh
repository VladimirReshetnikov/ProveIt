#!/bin/sh
set -eu
cd "$(dirname "$0")"
build_dir=$(mktemp -d)
trap 'rm -rf "$build_dir"' EXIT HUP INT TERM
for pass in first second third; do
  if ! pdflatex -interaction=nonstopmode -halt-on-error \
      -output-directory="$build_dir" pra_positive_uniqueness.tex \
      > "$build_dir/$pass-pass.txt"; then
    cat "$build_dir/$pass-pass.txt" >&2
    exit 1
  fi
done
cp "$build_dir/pra_positive_uniqueness.pdf" pra_positive_uniqueness.pdf
mkdir -p audit
cp "$build_dir/pra_positive_uniqueness.log" audit/latex.log
printf '%s\n' 'Built pra_positive_uniqueness.pdf.'
