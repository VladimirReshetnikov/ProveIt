COMPLETE iPRA CHECKERS: CODE AND CERTIFICATE FORMAT
================================================

Recommended executable: matrix_checker.py

This is a self-contained proof checker for the theory specified in the
accompanying mathematical report. It checks finite, explicitly annotated
proof trees. It does not search for proofs or evaluate all primitive
recursive programs. No third-party Python packages are required.

QUICK START
-----------

    python3 matrix_checker.py examples/matrix_closed_derived_constructor_coverage.json

The output is ACCEPT, with exit status 0. For a rejected certificate the
output is REJECT and the exit status is 1. An invalid input file is reported
as an input error. An example which must be rejected is:

    python3 matrix_checker.py examples/matrix_reject_universal_eigenvariable_escape.json

The standalone file has no dependency on the other delivered Python files.
Its runtime dependencies are the Python 3 interpreter, builtins, and the
standard json and sys libraries. These common runtime implementations are
excluded from both sides of the reported source-size comparison.

The input is a JSON object with exactly these four keys:

    {"scope": n, "context": [A1,...,Al], "conclusion": B, "proof": p}

The assertion being checked is A1,...,Al |- B in a scope with n available
number variables. All contexts, formulas, and explicitly supplied auxiliary
formulas/terms are checked for well-formedness. Natural numbers in syntax
must be genuine JSON integers >=0; JSON booleans do not count as integers.
Malformed input never grants an unchecked axiom or rule. The finite-resource
implementation may reject syntax exceeding Python's recursion limit.

The Python API is:

    from matrix_checker import check
    accepted = check(scope, context, conclusion, proof)

It returns a Boolean. The modular source matrix.py exposes the same API.

NUMBER TERMS AND BINDING
-----------------------

Variables use de Bruijn indices: an integer i denotes the i-th variable
counted from the innermost binding scope, and must satisfy 0 <= i < n.
Terms are exactly:

    i                  a variable
    ["0"]              zero
    ["s", t]           successor
    ["r", n, a, h]     initialized recursion, with body h

The counter n and initializer a have the surrounding scope. The body h
has two additional bound variables: index 0 is the previous state and
index 1 is the previous counter. An outer variable formerly at index i
appears at index i+2 inside h. Nested recursors add their own two slots.

This body is a genuine syntactic binder. Substitution traverses it while
protecting the two local slots. Outer captured variables remain active.
There are no frozen-label environments, arity registries, syntax optimizers,
or calls to a universal numerical evaluator.

For example, in scope 1, ["r",0,["0"],["s",2]] has a body which returns
the successor of the original outer variable. Its local state/counter are
unused. Its successor equation is checked using capture-safe simultaneous
substitution. See the nested-binder examples and tests.

FORMULAS: THE RECOMMENDED UNIFORM BLOCK LANGUAGE
----------------------------------------------

An equation is ["=",s,t]. Every other formula is one of:

    ["P", [[k1,items1],...,[kr,itemsr]]]
    ["D", [[k1,items1],...,[kr,itemsr]]]

Each k is a nonnegative number of newly bound NUMBER variables. Its items
are formulas in the surrounding scope enlarged by k. All P blocks must
have at least one item. D blocks may have no items.

Meaning of a P block [k,[A1,...,Am,B]]:

    forall k number variables, (A1 -> ... -> Am -> B).

A P formula is the conjunction of its blocks. An empty P list is truth.

Meaning of a D block [k,[A1,...,Am]]:

    exists k number variables, (A1 AND ... AND Am).

A D formula is the disjunction of its blocks. An empty D list is genuine
falsity. An empty conjunction in a D block is truth. The number domain is
nonempty, with the term zero.

In each block the newly bound variables have indices 0,...,k-1; previously
available variables have their indices increased by k. A witness list
[t0,...,t(k-1)] substitutes ti for index i and removes these k binding slots.

Usual logical operations have the following effective encodings:

    FALSE:          ["D",[]]
    TRUE:           ["P",[]]
    A -> B:         ["P",[[0,[A,B]]]]
    A OR B:         ["D",[[0,[A]],[0,[B]]]]
    A AND B:        ["D",[[0,[A,B]]]]
    forall x A:     ["P",[[1,[A]]]]
    exists x A:     ["D",[[1,[A]]]]

Conjunction can equally be encoded as ["P",[[0,[A]],[0,[B]]]]. The report
explains the definitional equivalence. The checker does not silently
identify these different syntax trees; their equivalence is derivable.

ALL LOGICAL CERTIFICATE SHAPES
------------------------------

All proofs are finite JSON lists. There are two logical tags, I and E,
with four mathematical cases. The goal or major formula determines which
case applies. Every rule retains the whole ambient context.

P INTRODUCTION

    ["I", [q1,...,qr]]

The goal is P with r blocks. For block [k,[A1,...,Am,B]], q checks B in
scope n+k from the old context shifted by k, followed by A1,...,Am.
All r blocks must be checked. For empty P, ["I",[]] proves truth.

D INTRODUCTION

    ["I", [i,[t0,...,t(k-1)],[q1,...,qm]]]

Choose block i of the goal D, supply exactly k surrounding-scope witness
terms, and prove each of its m instantiated items. The index is zero-based.
No branch of an empty D can be selected.

P ELIMINATION

    ["E", F, pF, [i,[t0,...,t(k-1)],[q1,...,qm]]]

F must be a well-formed P formula and pF must prove F. Choose its i-th
block [k,[A1,...,Am,B]]. Supply k witnesses and proofs of all instantiated
Ai. The goal must be exactly the corresponding instance of B.

D ELIMINATION

    ["E", F, pF, [q1,...,qr]]

F must be a well-formed D formula with r blocks, and pF must prove F.
For its block [k,[A1,...,Am]], q checks the old goal shifted by k, under
the old context shifted by k and then A1,...,Am. This introduces k fresh
eigenvariables that cannot occur in the old goal or retained assumptions.
Every branch is required. For F = ["D",[]], the branch list is empty;
its checked major proof supplies ordinary falsity elimination.

SHARED STRUCTURAL AND EQUALITY CERTIFICATES
------------------------------------------

    ["hyp",i]

The goal must equal context[i]. Context indices are zero-based, from left
to right. Introduction/elimination assumptions are appended after the
retained context. Weakening, exchange, and contraction are implicit in
this use of contexts; there is no separate structural-rule certificate.

    ["refl"]

The goal must be exactly ["=",t,t].

    ["eq",["=",s,t],F,p,q]

F is a formula in scope n+1, with new index 0 as the equality placeholder.
p proves s=t, q proves F[s], and the goal must be F[t]. Both substitutions
remove the placeholder slot and avoid capture inside formula and recursor
binders. This rule allows arbitrary formulas F, including quantified ones.
Symmetry, transitivity, and congruence are derived.

ALL ARITHMETIC CERTIFICATES
---------------------------

    ["r0"]

Checks the goal R(0,a;h)=a, in the exact term syntax above.

    ["rs"]

Checks R(Sn,a;h)=h[R(n,a;h)/state,n/counter]. The simultaneous substitution
protects nested binders and removes the two local slots. Every h must be
well-scoped finite syntax. These are all recursion computation schemas.

    ["sep"]

Checks exactly the fixed formula:

    ["P",[[0,[["=",["0"],["s",["0"]]],["D",[]]]]]]

This is 0=S0 -> FALSE.

    ["ind",E,t,q]

E must be a single equation in scope n+1; index 0 is the fresh induction
variable. t is a term in scope n. Write Z(u,F) for u=0 OR F, encoded by
the two-block D disjunction above. The checked conclusion is Z(t,E[t]).

The premise q is checked in scope n+1, from the old context shifted by 1
and the additional assumption Z(0,E), where this 0 denotes variable index
0, not the zero term ["0"]. Its goal is E with the induction variable
replaced by its successor, retaining the induction-variable slot and every
other variable index. This is the contextual rooted successor rule:

    Gamma, x=0 OR E(x) |- E(Sx)
    --------------------------
        Gamma |- t=0 OR E(t)

Because the old context and target live in scope n, the induction variable
is structurally fresh. E cannot be a quantified or composite formula.
These seven shared tags (hyp,refl,eq,r0,rs,sep,ind) plus I,E are the complete
list. There is no additional theorem oracle, logical axiom matcher,
classical principle, normalization oracle, or induction rule.

THE TWO COMPARISON CHECKERS
--------------------------

baseline_checker.py implements the same arithmetic, term representation,
equality rules, and binding discipline with ordinary formula constructors:

    ["=",s,t], ["bot"], ["and",A,B], ["or",A,B], ["imp",A,B],
    ["all",A], ["ex",A].

The last two bind one number variable. Its logical proof shapes are:

    ["and_i",p,q]                 conjunction introduction
    ["and_l",F,p], ["and_r",F,p]   conjunction projections
    ["or_l",p], ["or_r",p]         disjunction introductions
    ["or_e",F,p,q,r]               disjunction elimination
    ["imp_i",p]                   implication introduction
    ["imp_e",F,p,q]               implication elimination
    ["all_i",p]                   universal introduction
    ["all_e",F,t,p]               universal elimination
    ["ex_i",t,p]                  existential introduction
    ["ex_e",F,p,q]                existential elimination
    ["absurd",p]                  falsity elimination

F is always the explicit major formula, checked in the same context.
All fresh-variable contexts are shifted exactly as in the matrix checker.
This is a newly implemented, deliberately favorable common baseline for
the ordinary logical calculus shared by the current drafts. It is not
an assertion that their supplied diagnostic scripts were proof checkers.

kernel_checker.py is an intermediate comparison variant. It has the same
D constructor as matrix_checker, but P has only one block, encoded as
["P",k,[A1,...,Am],B]. Its proof shapes are ["PI",q],
["PE",F,witnesses,pF,arguments], ["DI",i,witnesses,arguments], and
["DE",F,pF,branches]. It demonstrates that the additional matrix saving
comes from sharing a uniform block grammar and the choose/all rule logic.

REPRODUCING EXPORTS, MEASUREMENTS, AND TESTS
------------------------------------------

From this directory run, in order:

    python3 tests.py
    python3 matrix_tests.py
    python3 measure.py
    python3 verify_exports.py

tests.py checks the modular intermediate/baseline implementations and
writes their exact proof certificates. matrix_tests.py translates those
kernel certificates and adds matrix-specific tests. measure.py exports
the three self-contained checkers by joining common.py with the selected
logical module (removing its common import) and adding the identical JSON
driver. verify_exports.py replays every certificate against both modular
and delivered standalone implementations, and checks the standalone CLI.

comparison.json gives exact SHA-256 hashes and reproducible source metrics.
All trusted checker code and the JSON CLI are included: term and formula
validation, capture-safe substitution, contexts, all logic, all arithmetic,
and input handling. No tests, proof generators, exporters, or measurement
scripts are needed at proof-checking time. Those auxiliary artifacts are
not charged to either minimal checker. Standard Python runtime size is
excluded on both sides.

The main metrics are significant Python tokens (excluding layout/comments),
nonblank/noncomment source lines (including docstrings), bytes including
comments, and Python AST nodes including docstrings. No source is minified.
This is an implementation comparison, not an invariant complexity measure
or a proof of global minimality over all possible implementations.

VALIDATION SCOPE
----------------

The supplied regression suite checks 185 finite certificates: 76 matrix,
63 intermediate-kernel, and 46 ordinary-baseline cases. It includes actual
closed proofs of constructor coverage, successor injectivity, and successor
nonzeroness; recursion with nested capture-sensitive bodies; all logical
rule cases; and rejected counterexamples for eigenvariable escape, missing
branches/premises, forbidden induction formulas, malformed arities, and
Boolean or out-of-scope indices. Both modular and exact standalone exports
are checked. See export_verification.json for results and exact hashes.

These checks validate the implementation on the stated finite cases. They
are not a machine-checked proof of the checker soundness/completeness or
of the infinite iPRA bi-interpretability theorem. Those metatheoretic
arguments are given in the mathematical report and were separately audited.
