"""Executable proof certificates and attacks on binding/rule side conditions."""

import copy
import json
from pathlib import Path

import baseline
import kernel
from common import lift_term


ROOT = Path(__file__).resolve().parent
ZERO = ["0"]
ONE = ["s", ZERO]


def eq(left, right):
    return ["=", left, right]


class Surface:
    def __init__(self, name):
        self.name = name
        self.checker = {"kernel": kernel.Checker, "baseline": baseline.Checker}[name]()

    def bot(self):
        return ["D", []] if self.name == "kernel" else ["bot"]

    def conjunction(self, left, right):
        return (["D", [[0, [left, right]]]] if self.name == "kernel"
                else ["and", left, right])

    def disjunction(self, left, right):
        return (["D", [[0, [left]], [0, [right]]]] if self.name == "kernel"
                else ["or", left, right])

    def implication(self, left, right):
        return ["P", 0, [left], right] if self.name == "kernel" else ["imp", left, right]

    def universal(self, body):
        return ["P", 1, [], body] if self.name == "kernel" else ["all", body]

    def existential(self, body):
        return ["D", [[1, [body]]]] if self.name == "kernel" else ["ex", body]

    def and_i(self, left, right):
        return ["DI", 0, [], [left, right]] if self.name == "kernel" else ["and_i", left, right]

    def and_e(self, source, source_proof, index, context_length):
        return (["DE", source, source_proof, [["hyp", context_length + index]]]
                if self.name == "kernel"
                else [["and_l", "and_r"][index], source, source_proof])

    def or_i(self, index, proof):
        return ["DI", index, [], [proof]] if self.name == "kernel" else [["or_l", "or_r"][index], proof]

    def or_e(self, source, source_proof, left, right):
        return (["DE", source, source_proof, [left, right]] if self.name == "kernel"
                else ["or_e", source, source_proof, left, right])

    def imp_i(self, proof):
        return ["PI", proof] if self.name == "kernel" else ["imp_i", proof]

    def imp_e(self, source, source_proof, argument):
        return (["PE", source, [], source_proof, [argument]] if self.name == "kernel"
                else ["imp_e", source, source_proof, argument])

    def all_i(self, proof):
        return ["PI", proof] if self.name == "kernel" else ["all_i", proof]

    def all_e(self, source, witness, source_proof):
        return (["PE", source, [witness], source_proof, []] if self.name == "kernel"
                else ["all_e", source, witness, source_proof])

    def ex_i(self, witness, proof):
        return ["DI", 0, [witness], [proof]] if self.name == "kernel" else ["ex_i", witness, proof]

    def ex_e(self, source, source_proof, branch):
        return (["DE", source, source_proof, [branch]] if self.name == "kernel"
                else ["ex_e", source, source_proof, branch])

    def absurd(self, proof):
        return ["DE", self.bot(), proof, []] if self.name == "kernel" else ["absurd", proof]


records = []


def add(surface, name, scope, context, conclusion, proof, expected=True):
    record = dict(scope=scope, context=context, conclusion=conclusion, proof=proof)
    actual = surface.checker.check(**record)
    assert actual is expected, (surface.name, name, expected, actual, record)
    records.append(dict(checker=surface.name, name=name, expected=expected,
                        accepted=actual, certificate=record))


for mode in ("kernel", "baseline"):
    s = Surface(mode)
    a, b = eq(ZERO, ZERO), eq(ONE, ONE)
    add(s, "reflexivity", 0, [], a, ["refl"])
    add(s, "hypothesis", 1, [eq(0, ZERO)], eq(0, ZERO), ["hyp", 0])
    add(s, "implication_identity", 0, [], s.implication(a, a), s.imp_i(["hyp", 0]))
    add(s, "universal_reflexivity", 0, [], s.universal(eq(0, 0)), s.all_i(["refl"]))
    add(s, "universal_instantiation", 0, [], b,
        s.all_e(s.universal(eq(0, 0)), ONE, s.all_i(["refl"])))
    add(s, "conjunction_intro", 0, [], s.conjunction(a, b), s.and_i(["refl"], ["refl"]))
    for index, result in enumerate((a, b)):
        add(s, "conjunction_projection_" + str(index), 0, [s.conjunction(a, b)], result,
            s.and_e(s.conjunction(a, b), ["hyp", 0], index, 1))
    for index, result in enumerate((a, b)):
        add(s, "disjunction_intro_" + str(index), 0, [result], s.disjunction(a, b),
            s.or_i(index, ["hyp", 0]))
    add(s, "disjunction_commutes", 0, [s.disjunction(a, b)], s.disjunction(b, a),
        s.or_e(s.disjunction(a, b), ["hyp", 0], s.or_i(1, ["hyp", 1]),
               s.or_i(0, ["hyp", 1])))
    add(s, "existential_witness", 0, [], s.existential(eq(0, ONE)), s.ex_i(ONE, ["refl"]))
    existential = s.existential(eq(0, ONE))
    add(s, "existential_elimination", 0, [existential], existential,
        s.ex_e(existential, ["hyp", 0], s.ex_i(0, ["hyp", 1])))
    add(s, "explosion", 0, [s.bot()], eq(ZERO, ONE), s.absurd(["hyp", 0]))
    add(s, "separation", 0, [], s.checker.separation(), ["sep"])
    add(s, "separation_applied", 0, [eq(ZERO, ONE)], s.bot(),
        s.imp_e(s.checker.separation(), ["sep"], ["hyp", 0]))

    # The equality placeholder is outside an additional quantifier binder.
    template = s.universal(eq(0, 1))
    source = s.universal(eq(0, 1))
    target = s.universal(eq(0, 2))
    add(s, "equality_under_quantifier", 2, [eq(0, 1), source], target,
        ["eq", eq(0, 1), template, ["hyp", 0], ["hyp", 1]])

    captured_body = ["s", 2]
    add(s, "recursion_zero", 1, [], eq(["r", ZERO, 0, captured_body], 0), ["r0"])
    add(s, "recursion_captured_parameter", 1, [],
        eq(["r", ["s", ZERO], ZERO, captured_body], ["s", 0]), ["rs"])
    body = ["r", 0, 2, ["s", 4]]
    previous = ["r", ZERO, ZERO, body]
    right = ["r", previous, 0, ["s", 2]]
    add(s, "recursion_nested_binders", 1, [],
        eq(["r", ["s", ZERO], ZERO, body], right), ["rs"])

    # Coverage is derived by the arithmetic rule, not supplied as an axiom.
    equation = eq(["s", ["r", 0, ZERO, 1]], 0)
    recursive = ["r", ["s", 0], ZERO, 1]
    step_equation = eq(recursive, 0)
    rewrite_template = eq(["s", lift_term(recursive, 1)], ["s", 0])
    step = ["eq", step_equation, rewrite_template, ["rs"], ["refl"]]
    coverage = s.checker.zero_or(0, equation)
    add(s, "derived_constructor_coverage", 1, [], coverage,
        ["ind", equation, 0, step])
    add(s, "closed_derived_constructor_coverage", 0, [], s.universal(coverage),
        s.all_i(["ind", equation, 0, step]))

    # Successor injectivity uses the computed left inverse p(t)=R(t,0,counter).
    def predecessor(value):
        return ["r", value, ZERO, 1]

    sx, sy = ["s", 0], ["s", 1]
    px, py = predecessor(sx), predecessor(sy)
    congruence = ["eq", eq(sx, sy), eq(lift_term(px, 1), predecessor(0)),
                  ["hyp", 0], ["refl"]]
    left_rewrite = ["eq", eq(px, 0), eq(0, lift_term(py, 1)), ["rs"], congruence]
    injectivity = ["eq", eq(py, 1), eq(1, 0), ["rs"], left_rewrite]
    add(s, "derived_successor_injectivity", 2, [eq(sx, sy)], eq(0, 1), injectivity)
    add(s, "closed_derived_successor_injectivity", 0, [],
        s.universal(s.universal(s.implication(eq(sx, sy), eq(0, 1)))),
        s.all_i(s.all_i(s.imp_i(injectivity))))

    # If Sx=0, predecessor congruence gives x=0, then S0=0 contradicts separation.
    pzero = predecessor(ZERO)
    congruence = ["eq", eq(sx, ZERO), eq(lift_term(px, 1), predecessor(0)),
                  ["hyp", 0], ["refl"]]
    left_rewrite = ["eq", eq(px, 0), eq(0, lift_term(pzero, 1)), ["rs"], congruence]
    xzero = ["eq", eq(pzero, ZERO), eq(1, 0), ["r0"], left_rewrite]
    onezero = ["eq", eq(0, ZERO), eq(["s", 0], ZERO), xzero, ["hyp", 0]]
    zeroone = ["eq", eq(ONE, ZERO), eq(0, ONE), onezero, ["refl"]]
    nonzero = s.imp_e(s.checker.separation(), ["sep"], zeroone)
    add(s, "derived_successor_nonzero", 1, [eq(sx, ZERO)], s.bot(), nonzero)
    add(s, "closed_derived_successor_nonzero", 0, [],
        s.universal(s.implication(eq(sx, ZERO), s.bot())),
        s.all_i(s.imp_i(nonzero)))

    # Rejection cases target scope, binder freshness, and local rule validity.
    add(s, "reject_false_reflexivity", 0, [], eq(ZERO, ONE), ["refl"], False)
    add(s, "reject_boolean_variable", 1, [], eq(True, True), ["refl"], False)
    add(s, "reject_negative_variable", 1, [], eq(-1, -1), ["refl"], False)
    add(s, "reject_unbound_variable", 1, [], eq(1, 1), ["refl"], False)
    add(s, "reject_unbound_recursion_body", 0, [], eq(["r", ZERO, ZERO, 2], ZERO), ["r0"], False)
    add(s, "reject_boolean_hypothesis_index", 0, [a], a, ["hyp", False], False)
    add(s, "reject_negative_hypothesis_index", 0, [a], a, ["hyp", -1], False)
    add(s, "reject_unknown_proof_rule", 0, [], a, ["trust_me"], False)
    add(s, "reject_extra_proof_fields", 0, [], a, ["refl", a], False)
    add(s, "reject_bad_term_arity", 0, [], eq(["0", ZERO], ["0", ZERO]), ["refl"], False)
    add(s, "reject_bad_recursion_equation", 1, [],
        eq(["r", ["s", ZERO], ZERO, captured_body], 0), ["rs"], False)
    add(s, "reject_nested_capture", 1, [],
        eq(["r", ["s", ZERO], ZERO, body], ["r", previous, 0, ["s", 1]]), ["rs"], False)
    add(s, "reject_universal_eigenvariable_escape", 1, [eq(0, ZERO)],
        s.universal(eq(0, ZERO)), s.all_i(["hyp", 0]), False)
    add(s, "reject_existential_eigenvariable_escape", 1, [existential], eq(0, ONE),
        s.ex_e(existential, ["hyp", 0], ["hyp", 1]), False)
    add(s, "reject_equality_capture", 2, [eq(0, 1), source], s.universal(eq(0, 1)),
        ["eq", eq(0, 1), template, ["hyp", 0], ["hyp", 1]], False)
    wrong_equation = eq(0, ZERO)
    add(s, "reject_induction_eigenvariable_escape", 1, [eq(["s", 0], ZERO)],
        s.checker.zero_or(0, wrong_equation), ["ind", wrong_equation, 0, ["hyp", 0]], False)
    add(s, "reject_non_equational_induction", 0, [], a,
        ["ind", s.implication(a, a), ZERO, s.imp_i(["hyp", 0])], False)
    add(s, "reject_unbound_induction_target", 0, [], s.checker.zero_or(ZERO, a),
        ["ind", a, 0, ["refl"]], False)
    add(s, "reject_wrong_separation_goal", 0, [], s.bot(), ["sep"], False)
    add(s, "reject_missing_introduction_subproof", 0, [], s.implication(a, a),
        ["PI"] if mode == "kernel" else ["imp_i"], False)


s = Surface("kernel")
a, b = eq(ZERO, ZERO), eq(ONE, ONE)
multi = ["P", 2, [eq(0, 1), eq(1, ZERO)], eq(0, 1)]
add(s, "multi_binder_multi_premise_intro", 0, [], multi, ["PI", ["hyp", 0]])
add(s, "multi_binder_multi_premise_elimination", 0, [], a,
    ["PE", multi, [ZERO, ZERO], ["PI", ["hyp", 0]], [["refl"], ["refl"]]])
package = ["D", [[2, [eq(0, ONE), eq(1, ZERO)]]]]
add(s, "multi_existential_multi_conjunction_intro", 0, [], package,
    ["DI", 0, [ONE, ZERO], [["refl"], ["refl"]]])
add(s, "multi_existential_multi_conjunction_elimination", 0, [package], package,
    ["DE", package, ["hyp", 0], [["DI", 0, [0, 1], [["hyp", 1], ["hyp", 2]]]]])
add(s, "empty_conjunction", 0, [], ["D", [[0, []]]], ["DI", 0, [], []])
add(s, "vacuous_existential_conjunction", 0, [], ["D", [[2, []]]],
    ["DI", 0, [ZERO, ONE], []])
add(s, "zero_argument_universal_wrapper", 0, [], ["P", 0, [], a], ["PI", ["refl"]])
add(s, "zero_argument_universal_elimination", 0, [], a,
    ["PE", ["P", 0, [], a], [], ["PI", ["refl"]], []])
add(s, "reject_universal_witness_count", 0, [], a,
    ["PE", multi, [ZERO], ["PI", ["hyp", 0]], [["refl"], ["refl"]]], False)
add(s, "reject_universal_premise_count", 0, [], a,
    ["PE", multi, [ZERO, ZERO], ["PI", ["hyp", 0]], [["refl"]]], False)
add(s, "reject_sum_missing_branch", 0, [s.disjunction(a, b)], a,
    ["DE", s.disjunction(a, b), ["hyp", 0], [["refl"]]], False)
add(s, "reject_sum_extra_branch", 0, [s.bot()], a,
    ["DE", s.bot(), ["hyp", 0], [["refl"]]], False)
add(s, "reject_conjunction_missing_premise", 0, [], s.conjunction(a, b),
    ["DI", 0, [], [["refl"]]], False)
add(s, "reject_boolean_branch_index", 0, [], ["D", [[0, []]]],
    ["DI", False, [], []], False)
add(s, "reject_negative_branch_index", 0, [], ["D", [[0, []]]],
    ["DI", -1, [], []], False)
add(s, "reject_boolean_binder_count", 0, [], ["P", False, [], a],
    ["PI", ["refl"]], False)
add(s, "reject_negative_binder_count", 0, [], ["D", [[-1, []]]],
    ["DI", 0, [], []], False)


# JSON round-tripping ensures all saved examples use the public wire syntax.
records = json.loads(json.dumps(records))
for record in records:
    checker = {"kernel": kernel.check, "baseline": baseline.check}[record["checker"]]
    assert checker(**record["certificate"]) is record["expected"]

examples = ROOT / "examples"
examples.mkdir(exist_ok=True)
for record in records:
    if record["name"] in {"closed_derived_constructor_coverage", "recursion_nested_binders",
                           "closed_derived_successor_injectivity", "closed_derived_successor_nonzero",
                           "reject_universal_eigenvariable_escape"}:
        filename = record["checker"] + "_" + record["name"] + ".json"
        (examples / filename).write_text(json.dumps(record["certificate"], indent=2) + "\n")

summary = {
    "method": "Complete finite proof certificates and targeted rejected certificates; not a proof-assistant metatheory formalization.",
    "cases": len(records),
    "expected_acceptances": sum(record["expected"] for record in records),
    "expected_rejections": sum(not record["expected"] for record in records),
    "all_passed": True,
    "results": [{key: value for key, value in record.items() if key != "certificate"}
                for record in records],
}
(ROOT / "test_results.json").write_text(json.dumps(summary, indent=2) + "\n")
(ROOT / "test_certificates.json").write_text(json.dumps(records, indent=2) + "\n")
print(json.dumps({key: value for key, value in summary.items() if key != "results"}, indent=2))
