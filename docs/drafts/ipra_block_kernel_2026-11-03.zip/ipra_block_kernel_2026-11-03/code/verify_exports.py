"""Replay every regression against the delivered standalone files and their CLI."""

import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
records = json.loads((ROOT / "test_certificates.json").read_text())
records += json.loads((ROOT / "matrix_test_certificates.json").read_text())
results = {}
for name in ("matrix", "kernel", "baseline"):
    path = ROOT / (name + "_checker.py")
    spec = importlib.util.spec_from_file_location("exported_" + name, path)
    exported = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(exported)
    modular = importlib.import_module(name)
    selected = [record for record in records if record["checker"] == name]
    for record in selected:
        assert modular.check(**record["certificate"]) is record["expected"], record["name"]
        assert exported.check(**record["certificate"]) is record["expected"], record["name"]
    commands = []
    for label, expected in (("closed_derived_constructor_coverage", True),
                            ("reject_universal_eigenvariable_escape", False)):
        certificate = ROOT / "examples" / (name + "_" + label + ".json")
        run = subprocess.run([sys.executable, str(path), str(certificate)],
                             text=True, capture_output=True, check=False)
        assert run.returncode == (0 if expected else 1), (name, label, run.stderr)
        assert run.stdout.strip() == ("ACCEPT" if expected else "REJECT"), (name, label, run.stdout)
        commands.append(dict(certificate=certificate.name, exit_code=run.returncode,
                             stdout=run.stdout.strip()))
    results[name] = dict(cases=len(selected),
                         expected_acceptances=sum(record["expected"] for record in selected),
                         expected_rejections=sum(not record["expected"] for record in selected),
                         modular_and_standalone_passed=True,
                         sha256=hashlib.sha256(path.read_bytes()).hexdigest(), cli=commands)
summary = dict(total_cases=len(records), all_passed=True, files=results,
               scope="Finite regression certificates and CLI checks of exact exported hashes; not a mechanized proof of the checker metatheory.")
(ROOT / "export_verification.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
