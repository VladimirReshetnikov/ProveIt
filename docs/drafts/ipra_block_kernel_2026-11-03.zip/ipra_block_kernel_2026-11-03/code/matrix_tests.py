"""Translate the independent certificates and check the uniform-block variant."""

import json
from pathlib import Path

import matrix


ROOT = Path(__file__).resolve().parent


def formula(value):
    if value[0] == "=":
        return value
    if value[0] == "P":
        _, count, premises, conclusion = value
        return ["P", [[count, [formula(item) for item in premises] + [formula(conclusion)]]]]
    return ["D", [[count, [formula(item) for item in items]] for count, items in value[1]]]


def proof(value):
    tag = value[0]
    if tag == "eq":
        return [tag, formula(value[1]), formula(value[2]), proof(value[3]), proof(value[4])]
    if tag == "ind":
        return [tag, formula(value[1]), value[2], proof(value[3])]
    if tag == "PI":
        return ["I", [proof(value[1])]] if len(value) == 2 else ["I"]
    if tag == "PE":
        return ["E", formula(value[1]), proof(value[3]),
                [0, value[2], [proof(part) for part in value[4]]]]
    if tag == "DI":
        return ["I", [value[1], value[2], [proof(part) for part in value[3]]]]
    if tag == "DE":
        return ["E", formula(value[1]), proof(value[2]), [proof(part) for part in value[3]]]
    return value


records = []


def add(name, record, expected):
    actual = matrix.check(**record)
    assert actual is expected, (name, expected, actual, record)
    records.append(dict(checker="matrix", name=name, expected=expected,
                        accepted=actual, certificate=record))


for source in json.loads((ROOT / "test_certificates.json").read_text()):
    if source["checker"] == "kernel":
        record = source["certificate"]
        converted = dict(scope=record["scope"], context=[formula(item) for item in record["context"]],
                         conclusion=formula(record["conclusion"]), proof=proof(record["proof"]))
        add(source["name"], converted, source["expected"])


ZERO, ONE = ["0"], ["s", ["0"]]
a, b = ["=", ZERO, ZERO], ["=", ONE, ONE]
bundle = ["P", [[0, [a]], [1, [["=", 0, 0]]], [0, [a, b, a]]]]
bundle_proof = ["I", [["refl"], ["refl"], ["hyp", 0]]]
add("conjunctive_universal_blocks", dict(scope=0, context=[], conclusion=bundle,
                                          proof=bundle_proof), True)
for index, witnesses, arguments, conclusion in ((0, [], [], a), (1, [ONE], [], b),
                                               (2, [], [["refl"], ["refl"]], a)):
    add("select_universal_block_" + str(index),
        dict(scope=0, context=[], conclusion=conclusion,
             proof=["E", bundle, bundle_proof, [index, witnesses, arguments]]), True)
add("empty_universal_bundle", dict(scope=0, context=[], conclusion=["P", []], proof=["I", []]), True)
add("reject_elimination_from_empty_universal_bundle",
    dict(scope=0, context=[], conclusion=a, proof=["E", ["P", []], ["I", []], [0, [], []]]), False)
add("reject_empty_universal_clause",
    dict(scope=0, context=[], conclusion=["P", [[0, []]]], proof=["I", [["refl"]]]), False)
add("reject_missing_universal_clause_proof",
    dict(scope=0, context=[], conclusion=bundle, proof=["I", [["refl"], ["refl"]]]), False)
add("reject_wrong_introduction_mode",
    dict(scope=0, context=[], conclusion=bundle, proof=["I", [0, [], []]]), False)
add("reject_unknown_elimination_major",
    dict(scope=0, context=[], conclusion=a, proof=["E", a, ["refl"], []]), False)
add("reject_universal_clause_boolean_index",
    dict(scope=0, context=[], conclusion=a, proof=["E", bundle, bundle_proof, [False, [], []]]), False)
add("reject_universal_clause_out_of_range",
    dict(scope=0, context=[], conclusion=a, proof=["E", bundle, bundle_proof, [3, [], []]]), False)
add("reject_malformed_block",
    dict(scope=0, context=[], conclusion=["D", [[0]]], proof=["I", [0, [], []]]), False)

records = json.loads(json.dumps(records))
for record in records:
    assert matrix.check(**record["certificate"]) is record["expected"]

examples = ROOT / "examples"
for record in records:
    if record["name"] in {"closed_derived_constructor_coverage", "recursion_nested_binders",
                           "closed_derived_successor_injectivity", "closed_derived_successor_nonzero",
                           "reject_universal_eigenvariable_escape", "conjunctive_universal_blocks"}:
        (examples / ("matrix_" + record["name"] + ".json")).write_text(
            json.dumps(record["certificate"], indent=2) + "\n")
summary = {
    "method": "Translated kernel certificates plus tests of multiple universal clauses and empty/invalid blocks.",
    "cases": len(records),
    "expected_acceptances": sum(record["expected"] for record in records),
    "expected_rejections": sum(not record["expected"] for record in records),
    "all_passed": True,
    "results": [{key: value for key, value in record.items() if key != "certificate"}
                for record in records],
}
(ROOT / "matrix_test_results.json").write_text(json.dumps(summary, indent=2) + "\n")
(ROOT / "matrix_test_certificates.json").write_text(json.dumps(records, indent=2) + "\n")
print(json.dumps({key: value for key, value in summary.items() if key != "results"}, indent=2))
