"""Export self-contained checkers and measure all their source, including JSON input."""

import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize


ROOT = Path(__file__).resolve().parent
DRIVER = '''

# Standalone JSON interface; Python and its standard json library are shared dependencies.
if __name__ == "__main__":
    import json
    import sys
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python3 " + sys.argv[0] + " certificate.json")
    try:
        with open(sys.argv[1], encoding="utf-8") as stream:
            record = json.load(stream)
        if type(record) is not dict or set(record) != {"scope", "context", "conclusion", "proof"}:
            raise ValueError("Expected exactly scope, context, conclusion, proof")
        accepted = check(**record)
    except (OSError, ValueError, TypeError, RecursionError) as error:
        raise SystemExit("Invalid input: " + str(error))
    print("ACCEPT" if accepted else "REJECT")
    raise SystemExit(0 if accepted else 1)
'''


def metrics(source):
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE,
               tokenize.NL, tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT}
    tokens = list(tokenize.generate_tokens(io.StringIO(source).readline))
    return {
        "utf8_bytes_including_comments": len(source.encode()),
        "physical_lines": len(source.splitlines()),
        "nonblank_noncomment_lines_including_docstrings": sum(
            bool(line.strip()) and not line.lstrip().startswith("#")
            for line in source.splitlines()),
        "python_tokens_excluding_layout_and_comments": sum(token.type not in ignored for token in tokens),
        "python_ast_nodes_including_docstrings": sum(1 for _ in ast.walk(ast.parse(source))),
        "sha256": hashlib.sha256(source.encode()).hexdigest(),
    }


common = (ROOT / "common.py").read_text()
results = {}
for variant in ("matrix", "kernel", "baseline"):
    logic = (ROOT / (variant + ".py")).read_text()
    logic = "\n".join(line for line in logic.splitlines()
                      if not line.startswith("from common import ")) + "\n"
    combined = common + "\n\n" + logic + DRIVER
    filename = variant + "_checker.py"
    (ROOT / filename).write_text(combined)
    results[variant] = {"file": filename, **metrics(combined)}

comparison = {}
for variant in ("matrix", "kernel"):
    comparison[variant] = {}
    for key, baseline_value in results["baseline"].items():
        if type(baseline_value) is int:
            variant_value = results[variant][key]
            comparison[variant][key] = {"baseline": baseline_value, variant: variant_value,
                                       "difference": variant_value - baseline_value,
                                       "reduction_percent": round(100 * (baseline_value - variant_value) / baseline_value, 3)}

report = {
    "scope": "Complete exported standalone checker source, including term validation, binders/substitution, all logic and arithmetic cases, contexts, and JSON CLI. No test or measurement code is required at checking time.",
    "shared_runtime_dependencies": "Python 3 interpreter and its standard json and sys libraries. Their implementation sizes are not included for either checker.",
    "baseline": "Fresh straightforward implementation of the current drafts' ordinary intuitionistic logic, with the same recursor syntax, arithmetic, equality, binding conventions, and IO as the proposed checker. The drafts themselves provide diagnostics, not a complete baseline proof checker.",
    "logical_tags": {"matrix": ["I", "E"], "kernel": ["PI", "PE", "DI", "DE"],
                     "baseline": ["and_i", "and_l", "and_r", "or_l", "or_r", "or_e",
                                  "imp_i", "imp_e", "all_i", "all_e", "ex_i", "ex_e", "absurd"]},
    "shared_tags": ["hyp", "refl", "eq", "r0", "rs", "sep", "ind"],
    "files": results,
    "comparison": comparison,
    "limits": "These are reproducible implementation measurements, not an invariant or global lower bound. Neither checker is code-golfed; another well-designed implementation or language may change the ordering.",
}
(ROOT / "comparison.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
