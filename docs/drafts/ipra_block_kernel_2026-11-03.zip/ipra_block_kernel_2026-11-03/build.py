"""Reproduce checker evidence, compile the report, and refresh checksums."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "validation" / "build_logs"


def run(name, command, directory):
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    result = subprocess.run(command, cwd=directory, env=environment,
                            text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    (LOGS / (name + ".txt")).write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        raise SystemExit(name + " failed; see validation/build_logs/" + name + ".txt")
    print(name + ": PASS")


def included(path):
    return (path.is_file() and "__pycache__" not in path.parts
            and path.suffix not in {".pyc", ".aux", ".log", ".out", ".toc"})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-pdf", action="store_true")
    parser.add_argument("--zip", action="store_true")
    arguments = parser.parse_args()
    LOGS.mkdir(parents=True, exist_ok=True)
    for name in ("tests", "matrix_tests", "measure", "verify_exports"):
        run(name, [sys.executable, "-B", name + ".py"], ROOT / "code")
    run("independent_audit", [sys.executable, "-B",
        str(ROOT / "validation" / "independent_audit.py"), str(ROOT / "code"),
        "--output", str(ROOT / "validation" / "independent_audit_results.json")], ROOT)
    if not arguments.skip_pdf:
        for number in range(1, 4):
            run("pdflatex_" + str(number),
                ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"], ROOT)
        final_log = (ROOT / "report.log").read_text(errors="replace")
        unwanted = ("Overfull ", "undefined references", "undefined on input",
                    "Rerun to get cross-references", "Label(s) may have changed")
        if any(item in final_log for item in unwanted):
            raise SystemExit("PDF layout or reference warnings remain; inspect report.log")
    metrics = json.loads((ROOT / "code" / "comparison.json").read_text())
    for variant, details in metrics["files"].items():
        source = (ROOT / "code" / details["file"]).read_bytes()
        if hashlib.sha256(source).hexdigest() != details["sha256"]:
            raise SystemExit("Checker digest mismatch: " + variant)
    files = sorted(path for path in ROOT.rglob("*") if included(path)
                   and path.name != "SHA256SUMS.txt")
    sums = [hashlib.sha256(path.read_bytes()).hexdigest() + "  "
            + path.relative_to(ROOT).as_posix() for path in files]
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n")
    print("checksums: PASS (" + str(len(files)) + " files)")
    if arguments.zip:
        destination = ROOT.parent / (ROOT.name + ".zip")
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
            for path in files + [ROOT / "SHA256SUMS.txt"]:
                archive.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
        print("archive: " + destination.name)


if __name__ == "__main__":
    main()
