A SMALLER CHECKING KERNEL FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov -- 3 November 2026

START HERE

report.pdf is the complete mathematical report. report.tex and
implementation.tex are its compilable sources. AXIOMS.txt is a standalone
complete specification of all syntax, logical rules, arithmetic schemas,
and side conditions.

The recommended proof checker is code/matrix_checker.py. It is a complete
self-contained Python program, including JSON input and validation. It
uses only the Python interpreter and standard json/sys libraries; no
third-party package, arithmetic evaluator, or theorem database is needed.

MAIN RESULT

Numerical terms use 0, successor, and a native binding recursor. Formulas
are equations or one of two uniformly stored clause/alternative lists:

  P: conjunctions of universally quantified implication clauses;
  D: disjunctions of existentially quantified conjunction alternatives.

An empty P list is truth. An empty D list is genuine falsity. Four
mathematical logical rules share two certificate tags and two checking
patterns. The arithmetic keeps separation, the two recursor computation
equations, and the current drafts' equation-indexed successor-closure rule.

The report proves full recovery of first-order iPRA, internal recursion
uniqueness, substitution coherence, and both whole-carrier interpretation
round trips. This includes arbitrary quantified formulas and nonstandard
counters. The native syntax is faithfully elaborated to an explicitly
specified ordinary first-order theory bi-interpretable with iPRA.

MEASURED COMPARISON

Measure, including the whole standalone checker and its JSON interface:
                                  Ordinary baseline     Proposed matrix
  UTF-8 bytes                           10,037               8,807
  Nonblank, noncomment lines                183                 162
  Significant Python tokens              2,239               1,912
  Python AST nodes                       2,376               2,051

This is a 14.605% reduction in significant tokens and a 12.255% reduction
in raw bytes. code/comparison.json states exact counting conventions,
hashes, dependencies, and comparison scope. code/measure.py reproduces it.

The baseline is a NEW straightforward implementation of the six drafts'
equivalent common core, not a purported measurement of an existing source
checker. Their supplied scripts are diagnostics. Both sides use the same
term syntax, arithmetic, equality, binding, validation, and input format.
No coding-independent global minimum is claimed.

CHECK AN ACTUAL PROOF

From this directory:

  python3 code/matrix_checker.py code/examples/matrix_closed_derived_constructor_coverage.json

Expected output: ACCEPT, exit status 0.

Other examples prove closed successor injectivity and nonzeroness and
check nested recursor computation. The example whose name contains
reject_universal_eigenvariable_escape must print REJECT and exit 1.
See code/README_CODE.txt for every certificate format.

REPRODUCE EVERYTHING

  python3 build.py

This runs the certificate suites, regenerates the standalone checkers and
source metrics, verifies the exact exports, runs the independent audit,
and compiles the PDF three times with pdflatex. It writes build logs and
refreshes SHA256SUMS.txt. It needs Python 3 and a normal TeX Live installation
with the packages listed in report.tex. Python 3.12 and TeX Live 2023 were
used for the supplied build.

  python3 build.py --skip-pdf

The latter reproduces the code/checking evidence without a TeX installation.
The original PDF is left in place. Optional --zip also refreshes a ZIP
beside this directory. The visual PDF review was performed separately;
code/build checks are not a substitute for a visual review after editing.

VALIDATION

  Matrix checker:       76 cases (39 expected accepts, 37 expected rejects).
  Intermediate kernel: 63 cases (34 expected accepts, 29 expected rejects).
  Ordinary baseline:   46 cases (26 expected accepts, 20 expected rejects).

All 185 cases pass against both modular and exact standalone exports,
with six additional command-line checks. The independent audit additionally
passes 1,000 term substitution cases, 600 formula substitution cases,
33 targeted rule controls, and 30 malformed-proof controls.

These are real proof-checker certificates plus finite implementation checks.
The general equivalence theorem and general checker soundness have written
proofs/reviews, not a complete Lean/Rocq formalization or an exhaustive
machine-verified metatheory. Actual execution is bounded by Python's
recursion and memory limits.

PACKAGE CONTENTS

  report.pdf / report.tex / implementation.tex : complete report and sources
  AXIOMS.txt                                : exact standalone specification
  code/matrix_checker.py                    : recommended standalone checker
  code/baseline_checker.py                   : ordinary-logic comparison
  code/kernel_checker.py                    : intermediate block comparison
  code/README_CODE.txt                      : complete wire-format description
  code/common.py, matrix.py, ...             : modular source and reproduction
  code/examples/                            : ready-to-run proof certificates
  code/*test_certificates.json               : all stored regression inputs
  code/*results.json, export_verification.json: validation results
  code/comparison.json                      : measured code sizes and hashes
  validation/independent_audit.py            : independent validation script
  validation/independent_audit_results.json  : independent result and hashes
  validation/checker_audit.txt               : source-review notes
  source_manifest.json                      : six pinned inputs and byte hashes
  build.py                                  : build/reproduction entry point
  SHA256SUMS.txt                             : checksums for delivered files

SOURCE SNAPSHOT

VladimirReshetnikov/ProveIt
3c85f4fc1c678b20fd7bbb44f9f5c17362baab8e
docs/drafts, six ZIP archives. Commit time: 2026-11-04 01:59:50 UTC
(3 November 2026 in the user's Pacific time zone).

The report credits the supplied drafts for the arithmetic bootstrap and
native-recursion interpretation. The main new contribution is the shared
logical representation, its complete checker, and a measured comparison
using the user's implementation-size criterion.
