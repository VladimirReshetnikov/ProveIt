"""Reproduce the independent finite audit against exported standalone checkers.

Usage:
  python3 -B independent_audit.py CODE_DIRECTORY --output results.json

These are finite substitution and adversarial checks, not a formal soundness
or bi-interpretability proof. No certificate generator is trusted by a checker.
"""

import argparse
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random


ZERO = ["0"]
ONE = ["s", ZERO]
TWO = ["s", ONE]


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def equation(left, right):
    return ["=", left, right]


def load_module(path, name):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def numeral(value):
    result = ["0"]
    for _ in range(value):
        result = ["s", result]
    return result


def generate_term(rng, scope, depth):
    if depth == 0:
        return rng.randrange(scope) if scope and rng.randrange(2) else ["0"]
    tag = rng.randrange(4)
    if tag == 0:
        return rng.randrange(scope) if scope else ["0"]
    if tag == 1:
        return ["s", generate_term(rng, scope, depth - 1)]
    if tag == 2:
        return ["0"]
    return ["r", numeral(rng.randrange(3)),
            generate_term(rng, scope, depth - 1),
            generate_term(rng, scope + 2, depth - 1)]


def evaluate_term(term, environment):
    """A separately written numerical interpreter, independent of substitution."""
    if type(term) is int:
        return environment[term]
    if term[0] == "0":
        return 0
    if term[0] == "s":
        return evaluate_term(term[1], environment) + 1
    count = evaluate_term(term[1], environment)
    value = evaluate_term(term[2], environment)
    for counter in range(count):
        value = evaluate_term(term[3], [value, counter] + environment)
    return value


def generate_formula(rng, scope, depth, matrix):
    if depth == 0 or rng.randrange(3) == 0:
        return equation(generate_term(rng, scope, 2), generate_term(rng, scope, 2))
    if matrix:
        tag = rng.choice(["P", "D"])
        blocks = []
        for _ in range(rng.randrange(3)):
            count = rng.randrange(3)
            item_count = rng.randrange(3) + (tag == "P")
            blocks.append([count, [generate_formula(rng, scope + count, depth - 1, True)
                                   for _ in range(item_count)]])
        return [tag, blocks]
    if rng.randrange(2):
        count = rng.randrange(3)
        return ["P", count,
                [generate_formula(rng, scope + count, depth - 1, False)
                 for _ in range(rng.randrange(3))],
                generate_formula(rng, scope + count, depth - 1, False)]
    blocks = []
    for _ in range(rng.randrange(3)):
        count = rng.randrange(3)
        blocks.append([count, [generate_formula(rng, scope + count, depth - 1, False)
                               for _ in range(rng.randrange(3))]])
    return ["D", blocks]


def evaluate_formula(formula, environment, matrix):
    """Finite quantifier ranges check substitution, not an arithmetic model."""
    if formula[0] == "=":
        return evaluate_term(formula[1], environment) == evaluate_term(formula[2], environment)
    if formula[0] == "P":
        blocks = formula[1] if matrix else [[formula[1], formula[2] + [formula[3]]]]
        return all(not all(evaluate_formula(item, list(values) + environment, matrix)
                           for item in items[:-1])
                   or evaluate_formula(items[-1], list(values) + environment, matrix)
                   for count, items in blocks
                   for values in itertools.product(range(3), repeat=count))
    return any(all(evaluate_formula(item, list(values) + environment, matrix)
                   for item in items)
               for count, items in formula[1]
               for values in itertools.product(range(3), repeat=count))


def term_checks(module):
    rng = random.Random(6352026)
    for number in range(1000):
        scope, count = rng.randrange(1, 5), rng.randrange(4)
        term = generate_term(rng, scope + count, 4)
        values = [generate_term(rng, scope, 3) for _ in range(count)]
        environment = [rng.randrange(5) for _ in range(scope)]
        result = module.instantiate_term(term, values)
        require(module.term(result, scope), ["term-scope", number])
        require(evaluate_term(result, environment) ==
                evaluate_term(term, [evaluate_term(value, environment) for value in values]
                              + environment), ["term-substitution", number])
        extra = rng.randrange(4)
        # Preserve the original audit's deterministic random draw sequence.
        require(evaluate_term(module.lift_term(term, extra),
                              [rng.randrange(5) for _ in range(extra)]
                              + [rng.randrange(5) for _ in range(scope + count)]) >= 0,
                ["nonnegative-evaluation", number])
        original = [rng.randrange(5) for _ in range(scope + count)]
        require(evaluate_term(module.lift_term(term, extra),
                              [rng.randrange(5) for _ in range(extra)] + original)
                == evaluate_term(term, original), ["term-shift", number])
    return rng


def formula_checks(checker, rng, matrix):
    for number in range(300):
        scope, count = rng.randrange(1, 4), rng.randrange(3)
        formula = generate_formula(rng, scope + count, 2, matrix)
        values = [generate_term(rng, scope, 2) for _ in range(count)]
        environment = [rng.randrange(5) for _ in range(scope)]
        result = checker.instantiate(formula, values)
        require(checker.formula(result, scope), ["formula-scope", matrix, number])
        require(evaluate_formula(result, environment, matrix) ==
                evaluate_formula(formula,
                                 [evaluate_term(value, environment) for value in values]
                                 + environment, matrix),
                ["formula-substitution", matrix, number])
        extra = rng.randrange(3)
        original = [rng.randrange(5) for _ in range(scope + count)]
        shifted = checker.lift(formula, extra)
        require(checker.formula(shifted, scope + count + extra),
                ["formula-shift-scope", matrix, number])
        require(evaluate_formula(shifted,
                                 [rng.randrange(5) for _ in range(extra)] + original, matrix)
                == evaluate_formula(formula, original, matrix),
                ["formula-shift", matrix, number])


def rule_checks(checker, matrix):
    cases = []

    def test(name, scope, context, conclusion, proof, expected):
        actual = checker.check(scope, context, conclusion, proof)
        require(actual is expected, [name, "expected", expected, "actual", actual])
        cases.append({"case": name, "expected": expected, "actual": actual})

    bottom = ["D", []]
    positive_truth = ["D", [[0, []]]]
    truth = ["P", []] if matrix else positive_truth
    universal = ["P", [[1, [equation(0, ZERO)]]]] if matrix else ["P", 1, [], equation(0, ZERO)]
    introduce_bad = ["I", [["hyp", 0]]] if matrix else ["PI", ["hyp", 0]]
    test("universal introduction fresh from Gamma", 1, [equation(0, ZERO)],
         universal, introduce_bad, False)
    exists_zero = ["D", [[1, [equation(0, ZERO)]]]]
    major = ["I", [0, [ZERO], [["refl"]]]] if matrix else ["DI", 0, [ZERO], [["refl"]]]
    eliminate = "E" if matrix else "DE"
    test("existential witness cannot escape", 1, [], equation(0, ZERO),
         [eliminate, exists_zero, major, [["hyp", 0]]], False)
    test("existential elimination closed result", 0, [], equation(ZERO, ZERO),
         [eliminate, exists_zero, major, [["refl"]]], True)
    premise = ["eq", equation(0, ONE), equation(["s", 1], ["s", 0]), ["hyp", 0], ["refl"]]
    test("SC shifts Gamma", 1, [equation(0, ONE)], checker.zero_or(ONE, equation(ONE, TWO)),
         ["ind", equation(0, TWO), ONE, premise], False)
    truth_proof = ["I", []] if matrix else ["DI", 0, [], []]
    test("SC admits equations only", 0, [], checker.zero_or(ZERO, truth),
         ["ind", truth, ZERO, truth_proof], False)
    source = ["D", [[0, []], [0, [bottom]]]]
    source_proof = ["I", [0, [], []]] if matrix else ["DI", 0, [], []]
    test("D elimination requires every alternative", 0, [], bottom,
         [eliminate, source, source_proof, []], False)
    bad_intro = ["I", [0, [], []]] if matrix else ["DI", 0, [], []]
    test("empty D has no introduction", 0, [], bottom, bad_intro, False)
    test("D introduction requires every premise", 0, [], ["D", [[0, [bottom]]]], bad_intro, False)
    implication = ["P", [[0, [bottom, bottom]]]] if matrix else ["P", 0, [bottom], bottom]
    implication_proof = ["I", [["hyp", 0]]] if matrix else ["PI", ["hyp", 0]]
    missing_argument = (["E", implication, implication_proof, [0, [], []]] if matrix
                        else ["PE", implication, [], implication_proof, []])
    test("P elimination requires every antecedent", 0, [], bottom, missing_argument, False)
    test("true does not eliminate to false", 0, [], bottom,
         [eliminate, positive_truth, source_proof, [bad_intro]], False)
    extra_witness = ["I", [0, [ZERO], []]] if matrix else ["DI", 0, [ZERO], []]
    test("witness count is exact", 0, [], positive_truth, extra_witness, False)
    nested = ["P", [[2, [equation(2, ZERO)]]]] if matrix else ["P", 2, [], equation(2, ZERO)]
    nested_proof = ["I", [["hyp", 0]]] if matrix else ["PI", ["hyp", 0]]
    test("two binders preserve outer parameter", 1, [equation(0, ZERO)], nested, nested_proof, True)
    test("recursion successor preserves free parameter", 1, [],
         equation(["r", ONE, 0, 2], 0), ["rs"], True)
    if matrix:
        test("empty P introduces truth", 0, [], truth, ["I", []], True)
        test("empty P has no selectable clause", 0, [], bottom,
             ["E", truth, ["I", []], [0, [], []]], False)
        test("P clause must have a conclusion", 0, [], ["P", [[0, []]]], ["I", [["refl"]]], False)
        clauses = ["P", [[0, [equation(ZERO, ZERO)]], [1, [equation(0, 0)]]]]
        proof = ["I", [["refl"], ["refl"]]]
        test("P introduces every clause", 0, [], clauses, proof, True)
        test("P selects first clause", 0, [], equation(ZERO, ZERO),
             ["E", clauses, proof, [0, [], []]], True)
        test("P selects quantified clause", 0, [], equation(ONE, ONE),
             ["E", clauses, proof, [1, [ONE], []]], True)
        test("P introduction cannot omit a clause", 0, [], clauses, ["I", [["refl"]]], False)
    malformed = [None, True, False, -1, 1.5, {}, [], ["I" if matrix else "PI"],
                 ["E" if matrix else "DE"], ["eq"], ["ind"], ["hyp", True],
                 ["hyp", -1], ["r0", "extra"]]
    if matrix:
        malformed += [["I", False], ["E", {}, None, []]]
    for index, proof in enumerate(malformed):
        require(checker.check(0, [], equation(ZERO, ZERO), proof) is False,
                ["malformed-proof", matrix, index])
    return {"rule_controls": cases, "malformed_proof_controls": len(malformed)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("code_directory", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    paths = {name: args.code_directory / (name + "_checker.py")
             for name in ("matrix", "kernel")}
    matrix_module = load_module(paths["matrix"], "independent_standalone_matrix")
    kernel_module = load_module(paths["kernel"], "independent_standalone_kernel")
    matrix_checker, kernel_checker = matrix_module.Checker(), kernel_module.Checker()
    rng = term_checks(matrix_module)
    formula_checks(kernel_checker, rng, False)
    formula_checks(matrix_checker, random.Random(4362026), True)
    results = {
        "status": "PASS",
        "scope": "Independent finite checks of exported standalone checkers; not a formal metatheorem.",
        "source_sha256": {name: hashlib.sha256(path.read_bytes()).hexdigest()
                          for name, path in paths.items()},
        "random_seeds": {"shared_terms_then_kernel_formulas": 6352026, "matrix_formulas": 4362026},
        "semantic_term_substitution_and_shift_cases": 1000,
        "kernel_formula_substitution_and_shift_cases": 300,
        "matrix_formula_substitution_and_shift_cases": 300,
        "kernel": rule_checks(kernel_checker, False),
        "matrix": rule_checks(matrix_checker, True),
        "limits": "Formula evaluation uses finite quantifier ranges only to test substitution. The general soundness and iPRA equivalence arguments are written mathematics, not machine-verified proofs.",
    }
    args.output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"status": results["status"], "term_cases": 1000,
                      "formula_cases": 600,
                      "kernel_rule_controls": len(results["kernel"]["rule_controls"]),
                      "matrix_rule_controls": len(results["matrix"]["rule_controls"]),
                      "malformed_controls": results["kernel"]["malformed_proof_controls"]
                                            + results["matrix"]["malformed_proof_controls"]}))


if __name__ == "__main__":
    main()
