#!/usr/bin/env python3
"""Finite diagnostics for the one-counter-projection construction.

This is not a first-order proof checker. It checks the stated syntax restriction
and computes all functions from their actual dependency-ordered descriptions.
No built-in halving, parity, valuation, subtraction or exponentiation is used by
the term evaluator; those Python operations occur only in expected test values.
"""
from __future__ import annotations
import json
from pathlib import Path


def V(name):
    return ("var", name)


def Z():
    return ("zero",)


def S(t):
    return ("succ", t)


def A(name, *args):
    return ("app", name, *args)


v = V("v")
zero, one = Z(), S(Z())
descriptions = {}


def declare(name, body):
    if name in descriptions:
        raise ValueError("duplicate description")
    if free(body) - {"v"}:
        raise ValueError("non-unary update")
    if dependencies(body) - (set(descriptions) | {"P"}):
        raise ValueError("forward or self dependency")
    descriptions[name] = body


def free(t):
    if t[0] == "var":
        return {t[1]}
    children = t[2:] if t[0] == "app" else t[1:]
    return set().union(*(free(c) for c in children)) if children else set()


def dependencies(t):
    if t[0] in ("var", "zero"):
        return set()
    if t[0] == "app":
        return {t[1]} | set().union(*(dependencies(c) for c in t[2:]))
    return dependencies(t[1])


declare("zero", zero)
declare("successor", S(v))


def pred(t):
    return A("P", t, zero)


declare("predecessor", pred(v))


def add(x, y):
    return A("successor", y, x)


def sub(x, y):
    return A("predecessor", y, x)


def case(z, a, b):
    return add(A("zero", z, a), A("zero", A("zero", z, one), b))


declare("cycle3", case(pred(v), S(v), zero))


def mod3(x):
    return A("cycle3", x, zero)


def bit1(x):
    return case(x, zero, case(pred(x), one, zero))


declare("skip", add(S(v), bit1(mod3(v))))


def F(x):
    return A("skip", x, zero)


def parity(x):
    return mod3(F(x))


def half(x):
    return sub(F(x), x)


declare("strip", case(parity(v), half(v), v))
declare("walk", case(parity(v), half(v), S(S(v))))
declare("double", add(v, v))


def double(x):
    return add(x, x)


def U(x):
    return A("strip", x, x)


def W(x):
    return A("walk", x, x)


def pair(x, y):
    return A("double", x, S(double(y)))


def left(x):
    return half(sub(add(double(x), U(x)), W(x)))


def right(x):
    return half(U(x))


prefixes = {}
eval_count = 0


def evaluate(t, env):
    global eval_count
    eval_count += 1
    tag = t[0]
    if tag == "var":
        return env[t[1]]
    if tag == "zero":
        return 0
    if tag == "succ":
        return evaluate(t[1], env) + 1
    name = t[1]
    n, seed = (evaluate(c, env) for c in t[2:])
    if name == "P":
        return seed if n == 0 else n - 1
    seq = prefixes.setdefault((name, seed), [seed])
    while len(seq) <= n:
        seq.append(evaluate(descriptions[name], {"v": seq[-1]}))
    return seq[n]


checks = 0


def check(claim, label):
    global checks
    checks += 1
    if not claim:
        raise AssertionError(label)


def val(term, **env):
    return evaluate(term, env)


x, y, k = V("x"), V("y"), V("k")
for n in range(65):
    check(val(half(x), x=n) == n // 2, ("half", n))
    check(val(parity(x), x=n) == n % 2, ("parity", n))
    check(val(add(double(half(x)), parity(x)), x=n) == n, ("decomposition", n))
    un, wn = val(U(x), x=n), val(W(x), x=n)
    check(val(descriptions["strip"], v=un) == un, ("fixed", n))
    check(val(U(double(x)), x=n) == un, ("U-double", n))
    if n:
        check(val(parity(x), x=wn) == 1, ("W-odd", n))
        check(val(W(double(x)), x=n) == wn + 2 * (n - 1), ("W-double", n))
    for count in range(65):
        for name in ("strip", "walk"):
            state = val(A(name, k, x), k=count, x=n)
            check(state % 2 == 1 or state <= max(0, n - count),
                  ("descent", name, count, n, state))
            if name == "walk" and n:
                check(state != 0, ("positive", count, n))

for n in range(33):
    for bound in range(33):
        if n and n % 2 == 0 and n <= bound:
            check(val(half(x), x=n) <= max(0, bound - 1), ("descent-lemma", n, bound))

for first in range(5):
    for second in range(5):
        n = val(pair(x, y), x=first, y=second)
        check(n == (2 ** first) * (2 * second + 1), ("pair-value", first, second))
        check(val(left(x), x=n) == first, ("left", first, second))
        check(val(right(x), x=n) == second, ("right", first, second))
        check(val(U(x), x=n) == 2 * second + 1, ("oddpart", first, second))
        check(val(W(x), x=n) + 2 * first == 2 * n + 2 * second + 1,
              ("valuation", first, second))

# Negative controls: doubling without its odd factor is not an injective pair;
# omitting the U(z) summand from L fails the same image test.
check(2 ** 1 * (2 * 2) == 2 ** 2 * (2 * 1), "bad-pair collision")
bad_left = half(sub(double(x), W(x)))
check(any(val(bad_left, x=val(pair(x, y), x=a, y=b)) != a
          for a in range(1, 4) for b in range(4)), "bad-decoder rejected")

result = {
    "status": "passed",
    "proof_scope": "finite syntax and numerical diagnostics only",
    "distinguished_counter_description": "P(0,a)=a; P(Sn,a)=n",
    "pure_iterator_count": len(descriptions),
    "all_other_updates_unary": all(free(t) <= {"v"} for t in descriptions.values()),
    "checks": checks,
    "term_evaluations": eval_count,
    "cached_prefixes": len(prefixes),
    "test_ranges": {"n": [0, 64], "k": [0, 64], "pair_coordinates": [0, 4]},
    "negative_controls_rejected": 2,
}
print(json.dumps(result, indent=2))
Path(__file__).with_name("one_exception_checks.json").write_text(json.dumps(result, indent=2) + "\n")
Path(__file__).with_name("one_exception_descriptions.json").write_text(
    json.dumps(descriptions, indent=2) + "\n")
