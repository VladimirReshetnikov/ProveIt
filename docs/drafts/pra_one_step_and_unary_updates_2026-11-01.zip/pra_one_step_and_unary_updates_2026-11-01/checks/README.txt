Finite-syntax admission diagnostic
==================================

Run with Python 3.10 or later (standard library only):

  python3 admission_diagnostic.py --output validation.json

The checker represents actual finite terms and formulas. Function applications
store an opaque description label and two argument trees. The description body
table is validated separately: an update must be literally the counter u, or
an earlier unary term h(v); references must form a finite acyclic graph.

admission_certificate enumerates all zero-or-one-contraction possibilities
after substituting zero for the running variable. A contraction changes ONE
ordinary syntax-tree occurrence. Stored description bodies are not traversed
by ambient substitution. A newly inserted or exposed redex is not reduced a
second time. The acceptance target is literally B -> B, not arbitrary logical
validity, equality reasoning, or a semantic equality of program descriptions.

Three formula modes are available:

  full_qf: arbitrary quantifier-free formula trees (the broad Lean-kernel mode).
  classical: P -> Q, with equation-or-bottom clauses.
  intuitionistic: P -> Q, with each clause an equation, bottom, or a
                 disjunction of two equations (no bottom disjunct).

The diagnostic cases exercise actual boundaries of the advertised specification:
the stationary axiom probes; zero-contraction induction normalization; rewriting
under implication antecedents; rejecting examples that need two contractions;
refusing to normalize a redex inserted by computation; distinct program labels;
unsupported variables; forbidden quantified matrices; dependency cycles; and the
bounded clause grammars. These finite diagnostics are not arithmetic proofs.

The optional stationary15 variant accepts QF matrices over n,a, or exactly
(forall b s(a,b)=t(a,b)) -> (forall b u(a,b)=v(a,b)). The quantified branch
has NO running variable n. The checker deliberately rejects a varying
quantified matrix even when it is already a literal reflexive implication.
It permits one term contraction under either displayed binder, but still
rejects formulas needing two contractions. This matches StationaryPropagation.lean.

The syntax-tree ledger reconstructs totals 18, 19, 26, 29, 66 and 130,
and S15's outer 15 and expanded subtotals 54, 106 and 56.
For the exposed-matrix totals 66 and 130, each arbitrary arithmetic term is still
a schematic application to three arguments. Thus those numbers expose logical
matrix structure, but do not measure fully expanded arithmetic terms, the
admission program, or the finite-description grammar. For S15's exposed
subtotals, the schematic arithmetic terms have two arguments. Its maximum
classical subtotal is 56 (the stationary branch exceeds the QF branch's 54);
its maximum intuitionistic subtotal is 106. The JSON records the
actual trees rendered as plain formulas and the precise counting convention.
