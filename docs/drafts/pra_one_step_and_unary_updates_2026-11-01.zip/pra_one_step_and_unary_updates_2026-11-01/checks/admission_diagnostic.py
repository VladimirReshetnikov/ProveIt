#!/usr/bin/env python3
"""Finite syntax diagnostic for the proposed one-step propagation scheme.

This is a stand-alone standard-library artifact. It implements real finite
term/formula trees and an exhaustive enumeration of SINGLE contractions, then
checks mathematically chosen boundary cases and the declared AST metric.

It is not a proof of arithmetic or bi-interpretability, and it does not execute
the interpreted primitive-recursive programs. Stored descriptions are labels
of application nodes, never children traversed by ambient substitution.

Usage: python3 admission_diagnostic.py [--output validation.json]
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Iterator, Mapping


@dataclass(frozen=True)
class Node:
    kind: str
    label: str = ""
    children: tuple["Node", ...] = ()


def var(name: str) -> Node:
    return Node("var", name)


ZERO = Node("zero")
BOT = Node("bot")
N, A, B, U, V = map(var, ("n", "a", "b", "u", "v"))


def succ(t: Node) -> Node:
    return Node("succ", children=(t,))


def app(label: str, counter: Node, seed: Node) -> Node:
    return Node("app", label, (counter, seed))


def eq(t: Node, u: Node) -> Node:
    return Node("eq", children=(t, u))


def imp(p: Node, q: Node) -> Node:
    return Node("imp", children=(p, q))


def conj(p: Node, q: Node) -> Node:
    return Node("conj", children=(p, q))


def disj(p: Node, q: Node) -> Node:
    return Node("disj", children=(p, q))


def forall(name: str, p: Node) -> Node:
    """Quantifier used by metrics and S15's strictly stationary equation blocks."""
    return Node("forall", name, (p,))


def term_hole(name: str, *args: Node) -> Node:
    """Metric-only schematic application, with every displayed argument counted."""
    return Node("term_hole", name, args)


def formula_hole(name: str, *args: Node) -> Node:
    return Node("formula_hole", name, args)


def nodes(t: Node) -> int:
    return 1 + sum(nodes(c) for c in t.children)


def substitute(t: Node, substitution: Mapping[str, Node]) -> Node:
    """Simultaneous, one-pass substitution; inserted trees are not revisited."""
    if t.kind == "var":
        return substitution.get(t.label, t)
    if t.kind == "forall":
        active = {k: v for k, v in substitution.items() if k != t.label}
        body = t.children[0]
        if any(k in free_variables(body) and t.label in free_variables(v)
               for k, v in active.items()):
            raise ValueError("capture-creating substitution is outside this canonical syntax API")
        return forall(t.label, substitute(body, active))
    return Node(t.kind, t.label, tuple(substitute(c, substitution) for c in t.children))


def free_variables(t: Node) -> frozenset[str]:
    if t.kind == "var":
        return frozenset((t.label,))
    if t.kind == "forall":
        return free_variables(t.children[0]) - {t.label}
    return frozenset().union(*(free_variables(c) for c in t.children))


def references(t: Node) -> frozenset[str]:
    own = frozenset((t.label,)) if t.kind == "app" else frozenset()
    return own.union(*(references(c) for c in t.children))


def term_well_formed(t: Node, labels: frozenset[str]) -> bool:
    if t.kind == "var":
        return bool(t.label) and not t.children
    if t.kind == "zero":
        return not t.label and not t.children
    if t.kind == "succ":
        return not t.label and len(t.children) == 1 and term_well_formed(t.children[0], labels)
    if t.kind == "app":
        return (t.label in labels and len(t.children) == 2
                and all(term_well_formed(c, labels) for c in t.children))
    return False


def formula_well_formed(f: Node, labels: frozenset[str]) -> bool:
    if f.kind == "bot":
        return not f.label and not f.children
    if f.kind == "eq":
        return (not f.label and len(f.children) == 2
                and all(term_well_formed(c, labels) for c in f.children))
    if f.kind in {"imp", "conj", "disj"}:
        return (not f.label and len(f.children) == 2
                and all(formula_well_formed(c, labels) for c in f.children))
    return False


def validate_descriptions(bodies: Mapping[str, Node]) -> tuple[str, ...]:
    """Check the restricted grammar h=u or h(v), and produce a DAG order.

    Only finite, well-founded dependency descriptions are accepted. Distinct
    labels stay distinct even when their numerical functions agree. There may
    be at most one distinguished counter-projection label. A dependency order
    is constructed; dictionary order is immaterial.
    """
    labels = frozenset(bodies)
    if any(not label for label in labels):
        raise ValueError("empty description label")
    if sum(body == U for body in bodies.values()) > 1:
        raise ValueError("more than one distinguished counter projection")
    for label, body in bodies.items():
        if not term_well_formed(body, labels):
            raise ValueError(f"malformed term or missing dependency in {label}")
        if body != U and not free_variables(body) <= {"v"}:
            raise ValueError(f"update {label} is neither the literal counter u nor a unary body h(v)")
    colors: dict[str, int] = {}
    order: list[str] = []

    def visit(label: str) -> None:
        color = colors.get(label, 0)
        if color == 1:
            raise ValueError(f"cyclic description dependency at {label}")
        if color == 2:
            return
        colors[label] = 1
        for dependency in sorted(references(bodies[label])):
            visit(dependency)
        colors[label] = 2
        order.append(label)

    for label in bodies:
        visit(label)
    return tuple(order)


@dataclass(frozen=True)
class Contraction:
    result: Node
    path: tuple[int, ...]
    rule: str


def term_steps(t: Node, bodies: Mapping[str, Node]) -> Iterator[Contraction]:
    """Enumerate every ordinary term occurrence, changing only that occurrence.

    The produced right-hand side is returned as-is. In particular, a redex
    newly exposed or inserted by successor computation is not contracted.
    """
    if t.kind == "app":
        counter, seed = t.children
        if counter == ZERO:
            yield Contraction(seed, (), "R0")
        elif counter.kind == "succ":
            (u,) = counter.children
            v = app(t.label, u, seed)
            yield Contraction(substitute(bodies[t.label], {"u": u, "v": v}), (), "RS")
    for i, child in enumerate(t.children):
        for step in term_steps(child, bodies):
            children = t.children[:i] + (step.result,) + t.children[i + 1:]
            yield Contraction(Node(t.kind, t.label, children), (i,) + step.path, step.rule)


def formula_steps(f: Node, bodies: Mapping[str, Node]) -> Iterator[Contraction]:
    if f == eq(ZERO, succ(ZERO)):
        yield Contraction(BOT, (), "Sep")
    if f.kind == "eq":
        for i, child in enumerate(f.children):
            for step in term_steps(child, bodies):
                children = f.children[:i] + (step.result,) + f.children[i + 1:]
                yield Contraction(Node("eq", children=children), (i,) + step.path, step.rule)
    elif f.kind in {"imp", "conj", "disj", "forall"}:
        for i, child in enumerate(f.children):
            for step in formula_steps(child, bodies):
                children = f.children[:i] + (step.result,) + f.children[i + 1:]
                yield Contraction(Node(f.kind, f.label, children), (i,) + step.path, step.rule)


def reflexive_implication(f: Node) -> bool:
    return f.kind == "imp" and len(f.children) == 2 and f.children[0] == f.children[1]


def clause_well_formed(f: Node, labels: frozenset[str], mode: str) -> bool:
    atom = lambda p: p.kind in {"eq", "bot"} and formula_well_formed(p, labels)
    if atom(f):
        return True
    return (mode == "intuitionistic" and f.kind == "disj" and len(f.children) == 2
            and all(p.kind == "eq" and atom(p) for p in f.children))


def stationary_block(f: Node, labels: frozenset[str]) -> bool:
    if f.kind != "imp" or len(f.children) != 2:
        return False
    for clause in f.children:
        if clause.kind != "forall" or clause.label != "b" or len(clause.children) != 1:
            return False
        atom = clause.children[0]
        if atom.kind != "eq" or not formula_well_formed(atom, labels):
            return False
        if not free_variables(atom) <= {"a", "b"}:
            return False
    return True


def admission_certificate(f: Node, bodies: Mapping[str, Node],
                          matrix_mode: str = "full_qf",
                          variant: str = "endpoint18") -> dict | None:
    validate_descriptions(bodies)
    if variant not in {"endpoint18", "stationary15"}:
        raise ValueError("unknown propagation variant")
    is_stationary = variant == "stationary15" and stationary_block(f, frozenset(bodies))
    if not is_stationary and not formula_well_formed(f, frozenset(bodies)):
        raise ValueError("matrix is outside the quantifier-free source grammar")
    allowed = {"n", "a", "b"} if variant == "endpoint18" else {"n", "a"}
    if not free_variables(f) <= allowed:
        raise ValueError("matrix has an unsupported free variable")
    if matrix_mode not in {"full_qf", "classical", "intuitionistic"}:
        raise ValueError("unknown matrix grammar")
    if not is_stationary and matrix_mode != "full_qf" and not (
        f.kind == "imp" and all(clause_well_formed(p, frozenset(bodies), matrix_mode)
                                for p in f.children)
    ):
        raise ValueError(f"matrix is outside the {matrix_mode} bounded clause grammar")
    base = substitute(f, {"n": ZERO})
    if reflexive_implication(base):
        return {"contractions": 0, "rule": "literal reflexivity", "path": []}
    for step in formula_steps(base, bodies):
        if reflexive_implication(step.result):
            return {"contractions": 1, "rule": step.rule, "path": list(step.path)}
    return None


def show(t: Node) -> str:
    if t.kind == "var":
        return t.label
    if t.kind == "zero":
        return "0"
    if t.kind == "bot":
        return "false"
    if t.kind == "succ":
        return f"S({show(t.children[0])})"
    if t.kind in {"app", "term_hole", "formula_hole"}:
        return t.label + "(" + ",".join(map(show, t.children)) + ")"
    if t.kind == "forall":
        return f"forall {t.label} [{show(t.children[0])}]"
    operators = {"eq": "=", "imp": "->", "conj": "and", "disj": "or"}
    return f"({show(t.children[0])} {operators[t.kind]} {show(t.children[1])})"


def schema18(matrix) -> Node:
    return forall("a", forall("b", imp(
        forall("n", imp(matrix(N, A, B), matrix(succ(N), A, B))), matrix(B, A, B))))


def schema19(matrix) -> Node:
    return forall("a", forall("b", imp(
        forall("n", imp(matrix(N, A, B), matrix(succ(N), A, B))),
        forall("n", matrix(N, A, B)))))


def schema15(matrix) -> Node:
    return forall("a", imp(forall("n", imp(matrix(N, A), matrix(succ(N), A))),
                           forall("n", matrix(N, A))))


def metrics() -> dict:
    f = lambda n, a, b: formula_hole("F", n, a, b)
    recurrence = eq(app("R_h", succ(N), A), term_hole("h", N, app("R_h", N, A)))
    f2 = lambda n: formula_hole("F", n, A)
    f3 = lambda n: formula_hole("A", n, A, A)

    def legacy(matrix) -> Node:
        return forall("a", imp(forall("n", imp(matrix(N), matrix(succ(N)))),
                               forall("n", conj(matrix(N), recurrence))))

    def atomic_matrix(n: Node, a: Node, b: Node) -> Node:
        terms = [term_hole(name, n, a, b) for name in ("s", "t", "u", "v")]
        return imp(eq(terms[0], terms[1]), eq(terms[2], terms[3]))

    def two_clause_matrix(n: Node, a: Node, b: Node) -> Node:
        terms = [term_hole(name, n, a, b) for name in
                 ("s1", "t1", "s2", "t2", "s3", "t3", "s4", "t4")]
        atoms = [eq(terms[i], terms[i + 1]) for i in range(0, 8, 2)]
        return imp(disj(atoms[0], atoms[1]), disj(atoms[2], atoms[3]))

    def atomic_two_slot(n: Node, a: Node) -> Node:
        terms = [term_hole(name, n, a) for name in ("s", "t", "u", "v")]
        return imp(eq(terms[0], terms[1]), eq(terms[2], terms[3]))

    def clause_two_slot(n: Node, a: Node) -> Node:
        terms = [term_hole(name, n, a) for name in
                 ("s1", "t1", "s2", "t2", "s3", "t3", "s4", "t4")]
        atoms = [eq(terms[i], terms[i + 1]) for i in range(0, 8, 2)]
        return imp(disj(atoms[0], atoms[1]), disj(atoms[2], atoms[3]))

    def stationary_exposed(_n: Node, a: Node) -> Node:
        terms = [term_hole(name, a, B) for name in ("s", "t", "u", "v")]
        return imp(forall("b", eq(terms[0], terms[1])), forall("b", eq(terms[2], terms[3])))

    displays = {
        "diagonal_propagation": schema18(f),
        "universal_propagation": schema19(f),
        "old_two_slot_normalization": legacy(f2),
        "old_three_slot_diagonal": legacy(f3),
        "classical_matrix_exposed": schema18(atomic_matrix),
        "intuitionistic_matrix_exposed": schema18(two_clause_matrix),
        "stationary_quantifier_propagation": schema15(lambda n, a: formula_hole("A", n, a)),
        "S15_classical_qf_matrix_exposed": schema15(atomic_two_slot),
        "S15_intuitionistic_qf_matrix_exposed": schema15(clause_two_slot),
        "S15_stationary_matrix_exposed": schema15(stationary_exposed),
    }
    expected = dict(zip(displays, (18, 19, 26, 29, 66, 130, 15, 54, 106, 56)))
    results = {}
    for name, tree in displays.items():
        size = nodes(tree)
        assert size == expected[name], (name, size, expected[name])
        results[name] = {"nodes": size, "display": show(tree)}
    results["convention"] = (
        "One node for each variable/constant occurrence, function/schematic application, "
        "equality, connective, falsity or individual quantifier. Binder names are labels. "
        "All displayed schematic arguments are counted. The E18 exposed-matrix totals leave "
        "the arbitrary arithmetic term bodies as three-argument schematic applications; "
        "S15 exposes two arguments per schematic term. "
        "These counts exclude the admission algorithm, description grammar and substituted term bodies."
    )
    return results


def run_diagnostics() -> dict:
    bodies = {
        "P": U,
        "Z": ZERO,
        "Id": V,
        "I": succ(V),
        "I_copy": succ(app("Id", V, V)),
        "D": app("P", V, ZERO),
        "Reset": app("I", ZERO, V),
    }
    order = validate_descriptions(bodies)
    findings: list[dict] = []

    def case(name: str, formula: Node, expected: bool,
             *, contractions: int | None = None, rule: str | None = None,
             matrix_mode: str = "full_qf", variant: str = "endpoint18") -> None:
        certificate = admission_certificate(formula, bodies, matrix_mode, variant)
        assert (certificate is not None) == expected, name
        if contractions is not None:
            assert certificate is not None and certificate["contractions"] == contractions, name
        if rule is not None:
            assert certificate is not None and certificate["rule"] == rule, name
        findings.append({"case": name, "matrix": show(formula),
                         "variant": variant, "matrix_mode": matrix_mode,
                         "admitted": expected, "certificate": certificate, "passed": True})

    case("Initialization is a stationary one-contraction probe",
         imp(eq(A, A), eq(app("I", ZERO, A), A)), True, contractions=1, rule="R0")
    rhs = succ(app("I", A, B))
    case("Successor computation keeps counter and seed independent",
         imp(eq(rhs, rhs), eq(app("I", succ(A), B), rhs)), True, contractions=1, rule="RS")
    case("The literal counter exception h(u,v)=u computes correctly",
         imp(eq(A, A), eq(app("P", succ(A), B), A)), True, contractions=1, rule="RS")
    case("Separation is recovered from a stationary probe",
         imp(eq(ZERO, succ(ZERO)), BOT), True, contractions=1, rule="Sep")
    g = disj(eq(app("I", N, A), B), eq(app("P", B, ZERO), N))
    case("Ordinary induction normalization needs zero contractions",
         imp(substitute(g, {"n": ZERO}), g), True, contractions=0)
    case("A contraction inside an implication antecedent is permitted",
         imp(eq(app("I", ZERO, A), A), eq(A, A)), True, contractions=1, rule="R0")
    case("A contraction under a nested negative formula is permitted",
         imp(imp(eq(app("I", ZERO, A), A), BOT), imp(eq(A, A), BOT)),
         True, contractions=1, rule="R0")
    case("Two nested zero redexes are not normalized repeatedly",
         imp(eq(A, A), eq(app("I", ZERO, app("I", ZERO, A)), A)), False)
    reset_rhs = app("Reset", A, B)
    case("A redex inserted by successor computation is not contracted again",
         imp(eq(reset_rhs, reset_rhs), eq(app("Reset", succ(A), B), reset_rhs)), False)
    expanded_rhs = app("I", ZERO, reset_rhs)
    case("The same successor rule is accepted with its unreduced right side",
         imp(eq(expanded_rhs, expanded_rhs), eq(app("Reset", succ(A), B), expanded_rhs)),
         True, contractions=1, rule="RS")
    case("A logical tautology outside literal B implies B is rejected",
         disj(BOT, imp(BOT, BOT)), False)
    case("Semantic symmetry is not syntactic equality",
         imp(eq(A, B), eq(B, A)), False)
    case("Two equivalent description labels are not identified",
         imp(eq(app("I", ZERO, A), A), eq(app("I_copy", ZERO, A), A)), False)
    case("The reversed separation atom is not an admission contraction",
         imp(eq(succ(ZERO), ZERO), BOT), False)

    def reject(name: str, operation) -> None:
        try:
            operation()
        except ValueError as error:
            findings.append({"case": name, "rejected": True,
                             "reason": str(error), "passed": True})
        else:
            raise AssertionError(name)

    c = var("c")
    reject("An extra free numerical parameter is not silently accepted",
           lambda: admission_certificate(imp(eq(c, c), eq(c, c)), bodies))
    reject("Quantified matrices are outside the grammar",
           lambda: admission_certificate(forall("n", imp(BOT, BOT)), bodies))
    reject("A missing description cannot be applied",
           lambda: admission_certificate(imp(eq(app("missing", ZERO, A), A), eq(A, A)), bodies))
    reject("A nonliteral counter-dependent update is rejected",
           lambda: validate_descriptions({"bad": succ(U)}))
    reject("A mixed counter/state update is rejected",
           lambda: validate_descriptions({"P": U, "bad": app("P", U, V)}))
    reject("The counter projection is a single distinguished symbol",
           lambda: validate_descriptions({"P": U, "P_copy": U}))
    reject("A cyclic self-description is rejected",
           lambda: validate_descriptions({"loop": app("loop", V, ZERO)}))
    reject("A mutually cyclic description pair is rejected",
           lambda: validate_descriptions({"X": app("Y", V, ZERO), "Y": app("X", V, ZERO)}))

    atomic_probe = imp(eq(A, A), eq(app("I", ZERO, A), A))
    for mode in ("classical", "intuitionistic"):
        assert admission_certificate(atomic_probe, bodies, mode) is not None
        assert admission_certificate(imp(eq(ZERO, succ(ZERO)), BOT), bodies, mode) is not None
    normalized_clause = imp(substitute(g, {"n": ZERO}), g)
    assert admission_certificate(normalized_clause, bodies, "intuitionistic") is not None
    findings.append({"case": "The advertised bounded grammars accept atomic/separation probes and the intuitionistic two-atom clause",
                     "passed": True})
    reject("The classical bounded grammar excludes a disjunctive clause",
           lambda: admission_certificate(normalized_clause, bodies, "classical"))
    triple = disj(eq(A, A), disj(eq(B, B), eq(N, N)))
    reject("The intuitionistic bounded grammar excludes a three-atom clause",
           lambda: admission_certificate(imp(substitute(triple, {"n": ZERO}), triple),
                                         bodies, "intuitionistic"))
    bottom_disjunction = disj(eq(A, A), BOT)
    reject("A disjunction containing bottom is outside the exact bounded clause grammar",
           lambda: admission_certificate(imp(bottom_disjunction, bottom_disjunction),
                                         bodies, "intuitionistic"))
    nested = imp(imp(eq(A, A), BOT), imp(eq(A, A), BOT))
    reject("Nested implication inside a clause is not admitted by the bounded grammars",
           lambda: admission_certificate(nested, bodies, "intuitionistic"))

    quantified_step = imp(forall("b", eq(rhs, rhs)),
                          forall("b", eq(app("I", succ(A), B), rhs)))
    case("S15 extracts the full successor equation with one contraction under its binder",
         quantified_step, True, contractions=1, rule="RS",
         matrix_mode="classical", variant="stationary15")
    quantified_left = imp(forall("b", eq(app("I", succ(A), B), rhs)),
                          forall("b", eq(rhs, rhs)))
    case("S15 also allows a contraction in its quantified antecedent",
         quantified_left, True, contractions=1, rule="RS", variant="stationary15")
    case("S15 does not collapse two contractions under a quantifier into one",
         imp(forall("b", eq(B, B)),
             forall("b", eq(app("I", ZERO, app("I", ZERO, B)), B))), False,
         variant="stationary15")
    case("S15 retains the ordinary one-parameter induction normalization",
         imp(eq(app("I", ZERO, A), A), eq(app("I", N, A), A)), True,
         contractions=0, variant="stationary15")
    varying_clause = forall("b", eq(N, B))
    reject("S15 forbids free n in a quantified matrix, even in a literal reflexive implication",
           lambda: admission_certificate(imp(varying_clause, varying_clause), bodies,
                                         variant="stationary15"))
    disj_clause = forall("b", disj(eq(A, B), eq(B, B)))
    reject("S15's quantified branch contains equations only",
           lambda: admission_certificate(imp(disj_clause, disj_clause), bodies,
                                         variant="stationary15"))
    reject("S15's quantifier-free branch has only one frozen parameter",
           lambda: admission_certificate(imp(eq(B, B), eq(B, B)), bodies,
                                         variant="stationary15"))

    original_bodies = dict(bodies)
    outer = app("I", N, A)
    assert substitute(outer, {"v": ZERO}) == outer
    assert bodies == original_bodies and bodies["I"] == succ(V)
    assert substitute(V, {"v": succ(V)}) == succ(V)
    findings.append({"case": "Ambient substitution does not enter stored descriptions or revisit inserted trees",
                     "passed": True})

    return {
        "status": "all diagnostic checks passed",
        "description_grammar": "h(u,v)=u literally, or an earlier unary term h(v); finite acyclic dependencies",
        "description_order": order,
        "contraction_policy": "zero or one ordinary syntax-tree occurrence; no rewriting of descriptor labels or stored bodies",
        "matrix_modes": {
            "full_qf": "arbitrary finite quantifier-free formulas; this is the broad logical-kernel mode",
            "classical": "P -> Q, where each clause is an equation or bottom",
            "intuitionistic": "P -> Q, where each clause is an equation, bottom, or a disjunction of two equations",
        },
        "propagation_variants": {
            "endpoint18": "quantifier-free matrices with free variables among n,a,b",
            "stationary15": "QF matrices over n,a, or (forall b equation(a,b))->(forall b equation(a,b)); no running variable in quantified branch",
        },
        "diagnostic_count": len(findings),
        "diagnostics": findings,
        "metrics": metrics(),
        "scope": "Finite syntax and disclosed size checks only; no finite tests are presented as a proof of arithmetic or bi-interpretability.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    options = parser.parse_args()
    results = run_diagnostics()
    data = json.dumps(results, indent=2) + "\n"
    if options.output:
        options.output.parent.mkdir(parents=True, exist_ok=True)
        options.output.write_text(data, encoding="utf-8")
        print(f"{results['diagnostic_count']} diagnostics passed; output: {options.output}")
        print("AST counts: " + ", ".join(f"{k}={v['nodes']}" for k, v in results["metrics"].items()
                                         if isinstance(v, dict)))
    else:
        print(data, end="")


if __name__ == "__main__":
    main()
