PRA FROM ONE-STEP ADMISSION AND UNARY UPDATES
Research report prepared for Vladimir Reshetnikov, 1 November 2026.

START HERE
  report.pdf                 Complete manuscript and proofs
  report.tex                 Main LaTeX source
  sections/one_exception_pairing.tex
                             Included arithmetic and compiler proof
  AXIOMS.txt                 Standalone precise specifications

RESULTS
1. The only counter-dependent stored update needed is h(u,v)=u. Every
   other update may be a unary term h(v). The full one-parameter internal
   pairing proof makes this restricted language definitionally equivalent
   to matching classical or intuitionistic first-order PRA.
2. E18 is one effective axiom family, with zero/one-contraction syntactic
   admission. Stationary probes recover computation and separation;
   endpoint sharing recovers one-parameter QFI. Its partial outer-template
   count is 18 versus the existing smallest complete displays of 26.
3. The optional S15 variant has a 15-node outer display, adding a separate
   stationary quantified-equation matrix family. Its quantified matrices
   never depend on the induction counter.
4. Restricted N26 retains the previous two-variable axiom interface while
   using the new strictly narrower update grammar.

Both interpretations use the whole carrier and native equality. Both
round trips are internally the identity, including on nonstandard inputs.
The common conservative definitional extensions prove more than consistency
equivalence. Classical and intuitionistic theories are treated separately.

COMPARISON AND LIMITS
All eight current docs/drafts archives at ProveIt commit
ab29d2ad2189948d995d6cffa7cea5298cd126a0 were inspected. Both existing
26-node constructions are included in the comparison. Archive Git blob
hashes were verified, and archive/LaTeX hashes are recorded in audit/.

The counts are partial formula-template counts; they exclude the admission
program, descriptions and substituted bodies. E18 uses three variable names
instead of the old two. S15 moves bound quantifiers into stationary bodies;
its two exposed families must be accounted for separately. No absolute
shortestness, full-generator encoding minimum, or uniformly shorter proofs
are claimed. Pure iteration without the exceptional projection and the
earlier T0 initialization problem remain unresolved here.

ATTRIBUTION
Binary recursion, syntactic base admission, one-parameter parameter packing,
and bounded implication templates are inherited from the reviewed drafts.
The dyadic pairing formulas are inherited from pure_iteration_bridge.tex;
the new descent/padding/exchange proof establishes their one-parameter budget.
Lean finite-syntax infrastructure is adapted with attribution from the
supplied DiagonalSchema.lean. The one-step contextual rewrite and endpoint
logical kernels are new.

REBUILD
  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only
  python3 build.py --lean /absolute/path/to/lean

Use Python 3.10+, TeX Live with the packages in report.tex, and optionally
Lean 4.19.0. No Mathlib is required. The build uses no shell escape and
does not download dependencies or execute scripts from comparison ZIPs.
To verify delivered file integrity before rebuilding:
  sha256sum -c SHA256SUMS
Rebuilding may alter PDFs, logs, diagnostics, and metadata.

VERIFICATION SCOPE
formal/ contains the standalone checked logical kernel, exact compiler
output, toolchain pin, and SCOPE.txt. The report's verification section
distinguishes verified kernels from the written arithmetic/pairing/compiler
and bi-interpretability arguments. The Python diagnostics check finite
syntax and actual numerical term descriptions; they are not proofs about
the whole infinite theory or nonstandard models. Independent mathematical
reviews are included under audit/.

The user-linked traditional free-variable PRA calculus is discussed
explicitly. Full first-order bi-interpretability is not confused with merely
having the same quantifier-free theorem consequences.
