#!/usr/bin/env python3
"""Rebuild the manuscript and replay explicitly scoped diagnostics.

Requires Python 3.10+, pdflatex, and optionally Lean 4.19.0.  This script
does not download dependencies or execute code from comparison archives.
"""
from __future__ import annotations
import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(command, log, env=None):
    proc = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, env=env)
    (ROOT / log).write_text(proc.stdout, encoding="utf-8")
    print(f"{'PASS' if proc.returncode == 0 else 'FAIL'}: {' '.join(map(str, command))}")
    if proc.returncode:
        print(proc.stdout[-8000:])
        raise SystemExit(proc.returncode)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="absolute path to the Lean 4.19.0 executable")
    choice = parser.add_mutually_exclusive_group()
    choice.add_argument("--checks-only", action="store_true")
    choice.add_argument("--pdf-only", action="store_true")
    args = parser.parse_args()
    (ROOT / "audit").mkdir(exist_ok=True)
    if not args.pdf_only:
        for name in ("admission_diagnostic.py", "check_one_exception.py"):
            run([sys.executable, str(ROOT / "checks" / name)],
                f"audit/{Path(name).stem}_console.txt")
    if args.lean:
        run([args.lean, "--version"], "audit/lean_version.txt")
        lean_build = ROOT / "build" / "formal"
        lean_build.mkdir(parents=True, exist_ok=True)
        run([args.lean, "-o", str(lean_build / "Propagation.olean"),
             str(ROOT / "formal" / "Propagation.lean")],
            "formal/lean_validation.txt")
        lean_env = dict(os.environ)
        lean_env["LEAN_PATH"] = str(lean_build)
        run([args.lean, str(ROOT / "formal" / "StationaryPropagation.lean")],
            "formal/stationary_lean_validation.txt", env=lean_env)
    elif not args.pdf_only:
        print("Lean replay not requested; recorded validation is retained.")
    if not args.checks_only:
        tex = shutil.which("pdflatex")
        if tex is None:
            raise SystemExit("pdflatex is required for the PDF build.")
        (ROOT / "build").mkdir(exist_ok=True)
        for i in range(3):
            run([tex, "-no-shell-escape", "-interaction=nonstopmode",
                 "-halt-on-error", "-file-line-error", "-output-directory=build",
                 "report.tex"], f"audit/latex_pass_{i+1}.txt")
        shutil.copyfile(ROOT / "build" / "report.pdf", ROOT / "report.pdf")
        print("Compiled report.pdf. Rebuilding may change PDF metadata.")


if __name__ == "__main__":
    main()
