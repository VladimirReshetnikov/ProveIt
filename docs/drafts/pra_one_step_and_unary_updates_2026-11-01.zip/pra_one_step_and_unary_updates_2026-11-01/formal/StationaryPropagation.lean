import Propagation

/-
Optional finite-syntax kernel for the 15-node stationary-quantifier variant.

A matrix is either a two-slot quantifier-free formula F(n,a), or an
implication between two equations universally closed in b. In the latter
constructor, the term slots are (a,b); there is NO running-variable slot n.
Thus stationarity is enforced by the datatype, not a semantic side condition.

The quantified constructor represents exactly
  (forall b, s(a,b)=t(a,b)) -> (forall b, u(a,b)=v(a,b)).
Its admission criterion permits zero or one ordinary term contraction on
either side. Both quantified clauses use the same bound-variable name/slot.
This is the full-QF version. The bounded classical/intuitionistic clause
bridge remains a written theorem, as in the 18-node kernel.
-/

namespace StationaryPropagation

open Propagation

structure Equation where
  lhs : Term Two
  rhs : Term Two
  deriving DecidableEq

def Equation.eval {D : Type} (M : Model D) (a b : D) (E : Equation) : Prop :=
  E.lhs.eval M (envTwo a b) = E.rhs.eval M (envTwo a b)

inductive EquationStep (bodies : Bodies) : Equation → Equation → Prop where
  | left {s t : Term Two} (u : Term Two) :
      TermStep bodies s t → EquationStep bodies ⟨s, u⟩ ⟨t, u⟩
  | right (s : Term Two) {t u : Term Two} :
      TermStep bodies t u → EquationStep bodies ⟨s, t⟩ ⟨s, u⟩

theorem EquationStep.sound {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) {E G : Equation}
    (H : EquationStep bodies E G) (a b : D) : E.eval M a b ↔ G.eval M a b := by
  cases H with
  | left u ht => simp only [Equation.eval, ht.sound M bodies hb hs (envTwo a b)]
  | right s ht => simp only [Equation.eval, ht.sound M bodies hb hs (envTwo a b)]

inductive Matrix where
  | qf : Formula Two → Matrix
  | stationary : Equation → Equation → Matrix

def Matrix.eval {D : Type} (M : Model D) (n a : D) : Matrix → Prop
  | .qf F => F.eval M (envTwo n a)
  | .stationary E G => (∀ b, E.eval M a b) → ∀ b, G.eval M a b

def freeze : Two → Term Two
  | .counter => .zero
  | .state => .var .state

def QFAdmitted (bodies : Bodies) (F : Formula Two) : Prop :=
  ∃ B : Formula Two, F.subst freeze = .imp B B ∨
    FormulaStep bodies (F.subst freeze) (.imp B B)

def Matrix.Admitted (bodies : Bodies) : Matrix → Prop
  | .qf F => QFAdmitted bodies F
  | .stationary E G => E = G ∨ EquationStep bodies E G ∨ EquationStep bodies G E

def Schema15 {D : Type} (M : Model D) (bodies : Bodies) : Prop :=
  ∀ F : Matrix, F.Admitted bodies → ∀ a : D,
    (∀ n, F.eval M n a → F.eval M (M.succ n) a) → ∀ n, F.eval M n a

def initProbe (k : Nat) : Matrix :=
  .qf (.imp (.eq (.var .state) (.var .state))
    (.eq (.app k .zero (.var .state)) (.var .state)))

theorem initProbe_admitted (bodies : Bodies) (k : Nat) :
    (initProbe k).Admitted bodies :=
  ⟨.eq (.var .state) (.var .state), Or.inr
    (.impRight _ (.eqLeft _ (TermStep.init k (Term.var Two.state))))⟩

theorem schema15_base {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema15 M bodies) : Base M := by
  intro k a
  exact H (initProbe k) (initProbe_admitted bodies k) a
    (by intro n hn; exact hn) M.zero rfl

def separationProbe : Matrix := .qf (.imp (.eq .zero (.succ .zero)) .bot)

theorem separationProbe_admitted (bodies : Bodies) : separationProbe.Admitted bodies :=
  ⟨.bot, Or.inr (.impLeft _ .separation)⟩

theorem schema15_separation {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema15 M bodies) : Separation M :=
  H separationProbe (separationProbe_admitted bodies) M.zero
    (by intro n hn; exact hn) M.zero

def stepRhs (bodies : Bodies) (k : Nat) : Term Two :=
  (bodies k).subst (bodySub (.var .counter) (.app k (.var .counter) (.var .state)))

def stepProbe (bodies : Bodies) (k : Nat) : Matrix :=
  .stationary ⟨stepRhs bodies k, stepRhs bodies k⟩
    ⟨.app k (.succ (.var .counter)) (.var .state), stepRhs bodies k⟩

theorem stepProbe_admitted (bodies : Bodies) (k : Nat) :
    (stepProbe bodies k).Admitted bodies :=
  Or.inr (Or.inr (EquationStep.left _
    (TermStep.step k (Term.var Two.counter) (Term.var Two.state))))

theorem eval_stepRhs {D : Type} (M : Model D) (bodies : Bodies) (k : Nat) (a b : D) :
    (stepRhs bodies k).eval M (envTwo a b) =
      (bodies k).eval M (envTwo a (M.app k a b)) := by
  rw [stepRhs, Term.eval_subst]
  have he : (fun v =>
      (bodySub (Term.var Two.counter) (.app k (.var .counter) (.var .state)) v).eval M
        (envTwo a b)) = envTwo a (M.app k a b) := by
    funext v
    cases v <;> rfl
  rw [he]

theorem schema15_step {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema15 M bodies) : Step M bodies := by
  intro k a b
  have hp := H (stepProbe bodies k) (stepProbe_admitted bodies k) a
    (by intro n hn; exact hn) M.zero
  have heq := hp (fun _ => rfl) b
  simpa only [Equation.eval, Term.eval, envTwo, eval_stepRhs] using heq

def normalize (F : Formula Two) : Formula Two := .imp (F.subst freeze) F

theorem normalize_admitted (bodies : Bodies) (F : Formula Two) :
    (Matrix.qf (normalize F)).Admitted bodies := by
  refine ⟨F.subst freeze, Or.inl ?_⟩
  have hh : (fun v => (freeze v).subst freeze) = freeze := by
    funext v
    cases v <;> rfl
  simp only [normalize, Formula.subst, Formula.subst_subst, hh]

theorem eval_freeze {D : Type} (M : Model D) (F : Formula Two) (n a : D) :
    (F.subst freeze).eval M (envTwo n a) ↔ F.eval M (envTwo M.zero a) := by
  have he : (fun v => (freeze v).eval M (envTwo n a)) = envTwo M.zero a := by
    funext v
    cases v <;> rfl
  rw [Formula.eval_subst, he]

theorem eval_normalize {D : Type} (M : Model D) (F : Formula Two) (n a : D) :
    (normalize F).eval M (envTwo n a) ↔
      (F.eval M (envTwo M.zero a) → F.eval M (envTwo n a)) := by
  simp only [normalize, Formula.eval, eval_freeze]

theorem schema15_induction {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema15 M bodies) : QFI1 M := by
  intro F a hz hs n
  have prog : ∀ m, (normalize F).eval M (envTwo m a) →
      (normalize F).eval M (envTwo (M.succ m) a) := by
    intro m hm
    apply (eval_normalize M F (M.succ m) a).2
    intro hbase
    exact hs m ((eval_normalize M F m a).1 hm hbase)
  exact (eval_normalize M F n a).1
    (H (.qf (normalize F)) (normalize_admitted bodies F) a prog n) hz

theorem admitted_qf_base {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) (he : Separation M)
    (F : Formula Two) (had : QFAdmitted bodies F) (a : D) :
    F.eval M (envTwo M.zero a) := by
  obtain ⟨B, H⟩ := had
  have htrue : (Formula.imp B B).eval M (envTwo M.zero a) := fun hB => hB
  apply (eval_freeze M F M.zero a).1
  cases H with
  | inl hsyn => rw [hsyn]; exact htrue
  | inr hstep => exact (hstep.sound M bodies hb hs he (envTwo M.zero a)).2 htrue

/- The quantified case is discharged directly from computation, with no
   induction on a quantified formula anywhere in the argument. -/
theorem admitted_stationary {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) (E G : Equation)
    (had : (Matrix.stationary E G).Admitted bodies) (n a : D) :
    (Matrix.stationary E G).eval M n a := by
  rcases had with hsame | hforward | hbackward
  · subst G
    exact fun hp => hp
  · intro hp b
    exact (hforward.sound M bodies hb hs a b).1 (hp b)
  · intro hp b
    exact (hbackward.sound M bodies hb hs a b).2 (hp b)

theorem explicit_schema15 {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) (he : Separation M) (hi : QFI1 M) :
    Schema15 M bodies := by
  intro F had a hp n
  cases F with
  | qf F =>
    exact hi F a (admitted_qf_base M bodies hb hs he F had a) hp n
  | stationary E G =>
    exact admitted_stationary M bodies hb hs E G had n a

theorem schema15_iff {D : Type} (M : Model D) (bodies : Bodies) :
    Schema15 M bodies ↔ Base M ∧ Step M bodies ∧ Separation M ∧ QFI1 M := by
  constructor
  · intro H
    exact ⟨schema15_base M bodies H, schema15_step M bodies H,
      schema15_separation M bodies H, schema15_induction M bodies H⟩
  · rintro ⟨hb, hs, he, hi⟩
    exact explicit_schema15 M bodies hb hs he hi

#print axioms EquationStep.sound
#print axioms admitted_stationary
#print axioms schema15_iff

end StationaryPropagation
