/-
Finite-syntax constructive kernel for one-step computational propagation.

The generic syntax, substitution and evaluation infrastructure is adapted
from the supplied pra_syntactic_base_2026-11-01/formal/DiagonalSchema.lean
(ProveIt snapshot ab29d2ad2189948d995d6cffa7cea5298cd126a0).
The contextual ONE-step relation, propagation schemas, probes and proofs
below are new for this report. No import outside Lean core is used.

Scope: the bodies table is arbitrary. The external source-language generator
restricts it to well-founded descriptions; no well-foundedness premise is
needed for this logical equivalence. Full arithmetic, pairing, syntax coding,
the executable admission enumerator and the PRA round trips are not formalized
here. All formula variables are finite slots, never arbitrary predicates.
-/

namespace Propagation

inductive Two where
  | counter | state
  deriving DecidableEq

inductive Three where
  | counter | left | right
  deriving DecidableEq

inductive Term (V : Type) where
  | var : V → Term V
  | zero : Term V
  | succ : Term V → Term V
  | app : Nat → Term V → Term V → Term V
  deriving DecidableEq

inductive Formula (V : Type) where
  | eq : Term V → Term V → Formula V
  | bot : Formula V
  | conj : Formula V → Formula V → Formula V
  | disj : Formula V → Formula V → Formula V
  | imp : Formula V → Formula V → Formula V
  deriving DecidableEq

structure Model (D : Type) where
  zero : D
  succ : D → D
  app : Nat → D → D → D

def Term.subst {V W : Type} (s : V → Term W) : Term V → Term W
  | .var v => s v
  | .zero => .zero
  | .succ t => .succ (t.subst s)
  | .app i t u => .app i (t.subst s) (u.subst s)

def Formula.subst {V W : Type} (s : V → Term W) : Formula V → Formula W
  | .eq t u => .eq (t.subst s) (u.subst s)
  | .bot => .bot
  | .conj A B => .conj (A.subst s) (B.subst s)
  | .disj A B => .disj (A.subst s) (B.subst s)
  | .imp A B => .imp (A.subst s) (B.subst s)

def Term.eval {V D : Type} (M : Model D) (e : V → D) : Term V → D
  | .var v => e v
  | .zero => M.zero
  | .succ t => M.succ (t.eval M e)
  | .app i t u => M.app i (t.eval M e) (u.eval M e)

def Formula.eval {V D : Type} (M : Model D) (e : V → D) : Formula V → Prop
  | .eq t u => t.eval M e = u.eval M e
  | .bot => False
  | .conj A B => A.eval M e ∧ B.eval M e
  | .disj A B => A.eval M e ∨ B.eval M e
  | .imp A B => A.eval M e → B.eval M e

theorem Term.subst_subst {U V W : Type} (t : Term U)
    (s : U → Term V) (r : V → Term W) :
    (t.subst s).subst r = t.subst (fun v => (s v).subst r) := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => simp only [Term.subst, ih]
  | app i t u iht ihu => simp only [Term.subst, iht, ihu]

theorem Formula.subst_subst {U V W : Type} (A : Formula U)
    (s : U → Term V) (r : V → Term W) :
    (A.subst s).subst r = A.subst (fun v => (s v).subst r) := by
  induction A with
  | eq t u => simp only [Formula.subst, Term.subst_subst]
  | bot => rfl
  | conj A B ihA ihB => simp only [Formula.subst, ihA, ihB]
  | disj A B ihA ihB => simp only [Formula.subst, ihA, ihB]
  | imp A B ihA ihB => simp only [Formula.subst, ihA, ihB]

theorem Term.eval_subst {V W D : Type} (M : Model D)
    (t : Term V) (s : V → Term W) (e : W → D) :
    (t.subst s).eval M e = t.eval M (fun v => (s v).eval M e) := by
  induction t with
  | var v => rfl
  | zero => rfl
  | succ t ih => simp only [Term.subst, Term.eval, ih]
  | app i t u iht ihu => simp only [Term.subst, Term.eval, iht, ihu]

theorem Formula.eval_subst {V W D : Type} (M : Model D)
    (A : Formula V) (s : V → Term W) (e : W → D) :
    (A.subst s).eval M e ↔ A.eval M (fun v => (s v).eval M e) := by
  induction A with
  | eq t u => simp only [Formula.subst, Formula.eval, Term.eval_subst]
  | bot => rfl
  | conj A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]
  | disj A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]
  | imp A B ihA ihB => simp only [Formula.subst, Formula.eval, ihA, ihB]

def envTwo {D : Type} (n a : D) : Two → D
  | .counter => n
  | .state => a

def envThree {D : Type} (n a b : D) : Three → D
  | .counter => n
  | .left => a
  | .right => b

def bodySub {V : Type} (u v : Term V) : Two → Term V
  | .counter => u
  | .state => v

abbrev Bodies := Nat → Term Two

def Base {D : Type} (M : Model D) : Prop :=
  ∀ k a, M.app k M.zero a = a

def Step {D : Type} (M : Model D) (bodies : Bodies) : Prop :=
  ∀ k n a, M.app k (M.succ n) a =
    (bodies k).eval M (envTwo n (M.app k n a))

def Separation {D : Type} (M : Model D) : Prop :=
  M.zero = M.succ M.zero → False

/- Each derivation contains precisely ONE root contraction. Context rules
   transport it without introducing further contractions. There is no
   reflexivity or transitivity constructor. -/
inductive TermStep (bodies : Bodies) {V : Type} : Term V → Term V → Prop where
  | init (k : Nat) (t : Term V) : TermStep bodies (.app k .zero t) t
  | step (k : Nat) (u t : Term V) :
      TermStep bodies (.app k (.succ u) t)
        ((bodies k).subst (bodySub u (.app k u t)))
  | succ {t u : Term V} : TermStep bodies t u → TermStep bodies (.succ t) (.succ u)
  | appLeft (k : Nat) {t u : Term V} (v : Term V) :
      TermStep bodies t u → TermStep bodies (.app k t v) (.app k u v)
  | appRight (k : Nat) (t : Term V) {u v : Term V} :
      TermStep bodies u v → TermStep bodies (.app k t u) (.app k t v)

inductive FormulaStep (bodies : Bodies) {V : Type} : Formula V → Formula V → Prop where
  | eqLeft {t u : Term V} (v : Term V) :
      TermStep bodies t u → FormulaStep bodies (.eq t v) (.eq u v)
  | eqRight (t : Term V) {u v : Term V} :
      TermStep bodies u v → FormulaStep bodies (.eq t u) (.eq t v)
  | separation : FormulaStep bodies (.eq .zero (.succ .zero)) .bot
  | conjLeft {A B : Formula V} (C : Formula V) :
      FormulaStep bodies A B → FormulaStep bodies (.conj A C) (.conj B C)
  | conjRight (A : Formula V) {B C : Formula V} :
      FormulaStep bodies B C → FormulaStep bodies (.conj A B) (.conj A C)
  | disjLeft {A B : Formula V} (C : Formula V) :
      FormulaStep bodies A B → FormulaStep bodies (.disj A C) (.disj B C)
  | disjRight (A : Formula V) {B C : Formula V} :
      FormulaStep bodies B C → FormulaStep bodies (.disj A B) (.disj A C)
  | impLeft {A B : Formula V} (C : Formula V) :
      FormulaStep bodies A B → FormulaStep bodies (.imp A C) (.imp B C)
  | impRight (A : Formula V) {B C : Formula V} :
      FormulaStep bodies B C → FormulaStep bodies (.imp A B) (.imp A C)

theorem TermStep.sound {V D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) {t u : Term V}
    (H : TermStep bodies t u) (e : V → D) : t.eval M e = u.eval M e := by
  induction H with
  | init k t => exact hb k (t.eval M e)
  | step k u t =>
    rw [Term.eval_subst]
    have he : (fun v => (bodySub u (.app k u t) v).eval M e) =
        envTwo (u.eval M e) (M.app k (u.eval M e) (t.eval M e)) := by
      funext v
      cases v <;> rfl
    rw [he]
    exact hs k (u.eval M e) (t.eval M e)
  | succ H ih => exact congrArg M.succ ih
  | appLeft k v H ih => exact congrArg (fun x => M.app k x (v.eval M e)) ih
  | appRight k t H ih => exact congrArg (M.app k (t.eval M e)) ih

theorem FormulaStep.sound {V D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) (he : Separation M)
    {A B : Formula V} (H : FormulaStep bodies A B) (e : V → D) :
    A.eval M e ↔ B.eval M e := by
  induction H with
  | eqLeft v ht => simp only [Formula.eval, ht.sound M bodies hb hs e]
  | eqRight t ht => simp only [Formula.eval, ht.sound M bodies hb hs e]
  | separation => exact ⟨he, False.elim⟩
  | conjLeft C H ih => exact and_congr ih Iff.rfl
  | conjRight A H ih => exact and_congr Iff.rfl ih
  | disjLeft C H ih => exact or_congr ih Iff.rfl
  | disjRight A H ih => exact or_congr Iff.rfl ih
  | impLeft C H ih => exact imp_congr ih Iff.rfl
  | impRight A H ih => exact imp_congr Iff.rfl ih

def freeze : Three → Term Three
  | .counter => .zero
  | .left => .var .left
  | .right => .var .right

def Admitted (bodies : Bodies) (F : Formula Three) : Prop :=
  ∃ B : Formula Three, F.subst freeze = .imp B B ∨
    FormulaStep bodies (F.subst freeze) (.imp B B)

def QFI2 {D : Type} (M : Model D) : Prop :=
  ∀ F : Formula Three, ∀ a b : D,
    F.eval M (envThree M.zero a b) →
    (∀ n, F.eval M (envThree n a b) → F.eval M (envThree (M.succ n) a b)) →
    ∀ n, F.eval M (envThree n a b)

def QFI1 {D : Type} (M : Model D) : Prop :=
  ∀ F : Formula Two, ∀ a : D,
    F.eval M (envTwo M.zero a) →
    (∀ n, F.eval M (envTwo n a) → F.eval M (envTwo (M.succ n) a)) →
    ∀ n, F.eval M (envTwo n a)

def Schema19 {D : Type} (M : Model D) (bodies : Bodies) : Prop :=
  ∀ F : Formula Three, Admitted bodies F → ∀ a b : D,
    (∀ n, F.eval M (envThree n a b) → F.eval M (envThree (M.succ n) a b)) →
    ∀ n, F.eval M (envThree n a b)

def Schema18 {D : Type} (M : Model D) (bodies : Bodies) : Prop :=
  ∀ F : Formula Three, Admitted bodies F → ∀ a b : D,
    (∀ n, F.eval M (envThree n a b) → F.eval M (envThree (M.succ n) a b)) →
    F.eval M (envThree b a b)

def initProbe (k : Nat) : Formula Three :=
  .imp (.eq (.var .left) (.var .left))
    (.eq (.app k .zero (.var .left)) (.var .left))

theorem initProbe_admitted (bodies : Bodies) (k : Nat) :
    Admitted bodies (initProbe k) :=
  ⟨.eq (.var .left) (.var .left), Or.inr
    (.impRight _ (.eqLeft _ (TermStep.init k (Term.var Three.left))))⟩

def separationProbe : Formula Three := .imp (.eq .zero (.succ .zero)) .bot

theorem separationProbe_admitted (bodies : Bodies) : Admitted bodies separationProbe :=
  ⟨.bot, Or.inr (.impLeft _ .separation)⟩

def stepRhs (bodies : Bodies) (k : Nat) : Term Three :=
  (bodies k).subst (bodySub (.var .left) (.app k (.var .left) (.var .right)))

def stepProbe (bodies : Bodies) (k : Nat) : Formula Three :=
  .imp (.eq (stepRhs bodies k) (stepRhs bodies k))
    (.eq (.app k (.succ (.var .left)) (.var .right)) (stepRhs bodies k))

theorem freeze_stepRhs (bodies : Bodies) (k : Nat) :
    (stepRhs bodies k).subst freeze = stepRhs bodies k := by
  have hh : (fun v =>
      (bodySub (.var Three.left) (.app k (.var .left) (.var .right)) v).subst freeze) =
      bodySub (.var Three.left) (.app k (.var .left) (.var .right)) := by
    funext v
    cases v <;> rfl
  simp only [stepRhs, Term.subst_subst, hh]

theorem stepProbe_admitted (bodies : Bodies) (k : Nat) :
    Admitted bodies (stepProbe bodies k) := by
  refine ⟨.eq (stepRhs bodies k) (stepRhs bodies k), Or.inr ?_⟩
  simp only [stepProbe, Formula.subst, freeze_stepRhs, Term.subst, freeze]
  exact .impRight _ (.eqLeft _ (TermStep.step k (Term.var Three.left) (Term.var Three.right)))

theorem eval_stepRhs {D : Type} (M : Model D) (bodies : Bodies) (k : Nat) (n a b : D) :
    (stepRhs bodies k).eval M (envThree n a b) =
      (bodies k).eval M (envTwo a (M.app k a b)) := by
  rw [stepRhs, Term.eval_subst]
  have he : (fun v =>
      (bodySub (.var Three.left) (.app k (.var .left) (.var .right)) v).eval M
        (envThree n a b)) = envTwo a (M.app k a b) := by
    funext v
    cases v <;> rfl
  rw [he]

theorem eval_stepProbe {D : Type} (M : Model D) (bodies : Bodies) (k : Nat) (n a b : D) :
    (stepProbe bodies k).eval M (envThree n a b) ↔
      ((bodies k).eval M (envTwo a (M.app k a b)) =
        (bodies k).eval M (envTwo a (M.app k a b)) →
       M.app k (M.succ a) b = (bodies k).eval M (envTwo a (M.app k a b))) := by
  simp only [stepProbe, Formula.eval, eval_stepRhs, Term.eval, envThree]

theorem schema18_base {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema18 M bodies) : Base M := by
  intro k a
  exact H (initProbe k) (initProbe_admitted bodies k) a M.zero
    (by intro n hn; exact hn) rfl

theorem schema18_separation {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema18 M bodies) : Separation M :=
  H separationProbe (separationProbe_admitted bodies) M.zero M.zero
    (by intro n hn; exact hn)

theorem schema18_step {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema18 M bodies) : Step M bodies := by
  intro k a b
  have prog : ∀ n, (stepProbe bodies k).eval M (envThree n a b) →
      (stepProbe bodies k).eval M (envThree (M.succ n) a b) := by
    intro n hn
    exact (eval_stepProbe M bodies k (M.succ n) a b).2
      ((eval_stepProbe M bodies k n a b).1 hn)
  have hp := H (stepProbe bodies k) (stepProbe_admitted bodies k) a b prog
  exact (eval_stepProbe M bodies k b a b).1 hp rfl

def normalize (F : Formula Three) : Formula Three := .imp (F.subst freeze) F

theorem normalize_admitted (bodies : Bodies) (F : Formula Three) :
    Admitted bodies (normalize F) := by
  refine ⟨F.subst freeze, Or.inl ?_⟩
  have hh : (fun v => (freeze v).subst freeze) = freeze := by
    funext v
    cases v <;> rfl
  simp only [normalize, Formula.subst, Formula.subst_subst, hh]

theorem eval_freeze {D : Type} (M : Model D) (F : Formula Three) (n a b : D) :
    (F.subst freeze).eval M (envThree n a b) ↔ F.eval M (envThree M.zero a b) := by
  have he : (fun v => (freeze v).eval M (envThree n a b)) =
      envThree M.zero a b := by
    funext v
    cases v <;> rfl
  rw [Formula.eval_subst, he]

theorem eval_normalize {D : Type} (M : Model D) (F : Formula Three) (n a b : D) :
    (normalize F).eval M (envThree n a b) ↔
      (F.eval M (envThree M.zero a b) → F.eval M (envThree n a b)) := by
  simp only [normalize, Formula.eval, eval_freeze]

theorem schema19_induction {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema19 M bodies) : QFI2 M := by
  intro F a b hz hs n
  have prog : ∀ m, (normalize F).eval M (envThree m a b) →
      (normalize F).eval M (envThree (M.succ m) a b) := by
    intro m hm
    apply (eval_normalize M F (M.succ m) a b).2
    intro hbase
    exact hs m ((eval_normalize M F m a b).1 hm hbase)
  exact (eval_normalize M F n a b).1
    (H (normalize F) (normalize_admitted bodies F) a b prog n) hz

def liftOne : Two → Term Three
  | .counter => .var .counter
  | .state => .var .left

theorem eval_liftOne {D : Type} (M : Model D) (F : Formula Two) (n a b : D) :
    (F.subst liftOne).eval M (envThree n a b) ↔ F.eval M (envTwo n a) := by
  have he : (fun v => (liftOne v).eval M (envThree n a b)) = envTwo n a := by
    funext v
    cases v <;> rfl
  rw [Formula.eval_subst, he]

theorem schema18_induction {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema18 M bodies) : QFI1 M := by
  intro F a hz hs n
  let G := F.subst liftOne
  have prog : ∀ m, (normalize G).eval M (envThree m a n) →
      (normalize G).eval M (envThree (M.succ m) a n) := by
    intro m hm
    apply (eval_normalize M G (M.succ m) a n).2
    intro hbase
    apply (eval_liftOne M F (M.succ m) a n).2
    exact hs m ((eval_liftOne M F m a n).1
      ((eval_normalize M G m a n).1 hm hbase))
  have hp := H (normalize G) (normalize_admitted bodies G) a n prog
  apply (eval_liftOne M F n a n).1
  exact (eval_normalize M G n a n).1 hp ((eval_liftOne M F M.zero a n).2 hz)

theorem schema19_to_schema18 {D : Type} (M : Model D) (bodies : Bodies)
    (H : Schema19 M bodies) : Schema18 M bodies := by
  intro F had a b hp
  exact H F had a b hp b

theorem admitted_base {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) (he : Separation M)
    (F : Formula Three) (had : Admitted bodies F) (a b : D) :
    F.eval M (envThree M.zero a b) := by
  obtain ⟨B, H⟩ := had
  have htrue : (Formula.imp B B).eval M (envThree M.zero a b) := fun hB => hB
  apply (eval_freeze M F M.zero a b).1
  cases H with
  | inl hsyn => rw [hsyn]; exact htrue
  | inr hstep => exact (hstep.sound M bodies hb hs he (envThree M.zero a b)).2 htrue

theorem explicit_schema19 {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) (he : Separation M) (hi : QFI2 M) :
    Schema19 M bodies := by
  intro F had a b hp n
  exact hi F a b (admitted_base M bodies hb hs he F had a b) hp n

theorem schema19_iff {D : Type} (M : Model D) (bodies : Bodies) :
    Schema19 M bodies ↔ Base M ∧ Step M bodies ∧ Separation M ∧ QFI2 M := by
  constructor
  · intro H
    have H18 := schema19_to_schema18 M bodies H
    exact ⟨schema18_base M bodies H18, schema18_step M bodies H18,
      schema18_separation M bodies H18, schema19_induction M bodies H⟩
  · rintro ⟨hb, hs, he, hi⟩
    exact explicit_schema19 M bodies hb hs he hi

theorem schema18_extract {D : Type} (M : Model D) (bodies : Bodies) :
    Schema18 M bodies → Base M ∧ Step M bodies ∧ Separation M ∧ QFI1 M := by
  intro H
  exact ⟨schema18_base M bodies H, schema18_step M bodies H,
    schema18_separation M bodies H, schema18_induction M bodies H⟩

theorem explicit_schema18 {D : Type} (M : Model D) (bodies : Bodies)
    (hb : Base M) (hs : Step M bodies) (he : Separation M) (hi : QFI2 M) :
    Schema18 M bodies :=
  schema19_to_schema18 M bodies (explicit_schema19 M bodies hb hs he hi)

#print axioms TermStep.sound
#print axioms FormulaStep.sound
#print axioms schema19_iff
#print axioms schema18_extract
#print axioms explicit_schema18

end Propagation
