"""Reproduce complete-checker size measurements; not trusted kernel code."""

import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize


VARIANTS = (
    ("baseline_nd.py", "Conventional natural deduction"),
    ("baseline_nd_optimized.py", "Natural deduction with elementary reductions"),
    ("baseline_hilbert.py", "Hilbert theorem-list checker"),
    ("kernel_ps.py", "Binary binders with primitive disjunction"),
    ("kernel_compact.py", "Binary binders and numerical cases"),
    ("checker.py", "Final fixed-axiom checker"),
)


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    docstrings = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body.pop(0)
                docstrings.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    tokens = [token for token in tokenize.generate_tokens(io.StringIO(source).readline)
              if token.type not in ignored
              and not any(start <= token.start and token.end <= end for start, end in docstrings)]
    return {
        "file": path.name,
        "bytes": len(data),
        "physical_lines": len(source.splitlines()),
        "meaningful_python_tokens": len(tokens),
        "token_characters": sum(len(t.string) for t in tokens),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "sha256": hashlib.sha256(data).hexdigest(),
    }


def run():
    root = Path(__file__).resolve().parent
    rows = [dict(measure(root / filename), label=label) for filename, label in VARIANTS]
    result = {
        "method": "All executable source and fixed data, input validation, scope operations, rule checks and CLI included. Lexical counts and AST counts exclude every docstring, comments and formatting. Runtime/stdlib are shared dependencies. Builders/tests are not trusted.",
        "variants": rows,
    }
    final = rows[-1]
    for row in rows[:-1]:
        row["final_token_reduction_percent"] = round(100 * (1 - final["meaningful_python_tokens"] / row["meaningful_python_tokens"]), 3)
        row["final_ast_reduction_percent"] = round(100 * (1 - final["ast_nodes"] / row["ast_nodes"]), 3)
    (root / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    macros = {"KernelTokens": final["meaningful_python_tokens"], "KernelAST": final["ast_nodes"],
              "KernelLines": final["physical_lines"], "KernelBytes": final["bytes"]}
    (root / "metrics.tex").write_text("".join("\\newcommand{\\" + key + "}{" + str(value) + "}\n" for key, value in macros.items()))
    table = [r"\begin{center}\small", r"\begin{tabularx}{\textwidth}{@{}Xrrrr@{}}",
             r"\toprule", r"Complete implementation & Bytes & Lines & Tokens & AST nodes\\", r"\midrule"]
    for row in rows:
        table.append(row["label"] + " & " + " & ".join(str(row[key]) for key in ("bytes", "physical_lines", "meaningful_python_tokens", "ast_nodes")) + r"\\")
    table += [r"\bottomrule", r"\end{tabularx}", r"\end{center}"]
    table.append("Relative to conventional natural deduction, the final checker has "
                 + str(rows[0]["final_token_reduction_percent"]) + r"\% fewer meaningful tokens and "
                 + str(rows[0]["final_ast_reduction_percent"]) + r"\% fewer AST nodes. Against the already reduced natural-deduction baseline, the corresponding reductions are "
                 + str(rows[1]["final_token_reduction_percent"]) + r"\% and "
                 + str(rows[1]["final_ast_reduction_percent"]) + r"\%.")
    (root / "comparison_table.tex").write_text("\n".join(table) + "\n")
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    run()
