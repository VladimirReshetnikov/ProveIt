"""Untrusted certificate builders for the logical operations derived in iPRA.

Each builder emits only the primitive rules accepted by kernel_compact.py.
The disjunction eliminator uses numerical cases on (b=x -> C), retaining
all assumptions mentioning b. It never treats such assumptions as fixed
while substituting for b.
"""

import kernel_compact as k


Z, FALSE = k.ZERO, k.FALSE
TRUE = ("=", Z, Z)


def eq(s, t):
    return ("=", s, t)


def successor(t):
    return ("s", t)


def recursor(n, a, h):
    return ("r", n, a, h)


def implies(a, b):
    return ("pi", k.shift(a), k.shift(b))


def conjunction(a, b):
    return ("sig", k.shift(a), k.shift(b))


def all_(a):
    return ("pi", TRUE, a)


def exists(a):
    return ("sig", TRUE, a)


def disjunction(a, b):
    test = eq(0, Z)
    return ("sig", implies(test, k.shift(a)),
            implies(implies(test, FALSE), k.shift(b)))


def reflexivity(t):
    p = ("rec", recursor(Z, t, 0))
    return ("eq", p, eq(0, k.shift(t)), p)


def symmetry(p, left):
    return ("eq", p, eq(0, k.shift(left)), reflexivity(left))


def transitivity(p, q, left):
    return ("eq", q, eq(k.shift(left), 0), p)


def successor_nonzero(n, proof_successor_zero):
    """From an arbitrary proof of S(n)=0 produce genuine falsity."""
    def initializer_equals_n(a):
        p = ("eq", proof_successor_zero,
             eq(recursor(0, k.shift(a), 1), k.shift(n)),
             ("rec", recursor(successor(n), a, 1)))
        return ("eq", ("rec", recursor(Z, a, 1)),
                eq(0, k.shift(n)), p)
    p0 = initializer_equals_n(Z)
    p1 = initializer_equals_n(successor(Z))
    contradiction = transitivity(p0, symmetry(p1, successor(Z)), Z)
    return ("abort", contradiction, FALSE)


def or_left(a, b, assumption=0, context_size=1):
    """From hypothesis a at the specified position produce encoded a OR b."""
    first = ("pi", TRUE, ("hyp", assumption))
    second = ("pi", k.shift(implies(TRUE, FALSE)),
              ("abort", ("app", ("hyp", context_size), Z, reflexivity(Z)),
               k.shift(b)))
    return ("pair", disjunction(a, b), Z, first, second)


def or_right(a, b, assumption=0, context_size=1):
    """From hypothesis b at the specified position produce encoded a OR b."""
    one = successor(Z)
    first = ("pi", eq(one, Z),
             ("abort", symmetry(("hyp", context_size), one), k.shift(a)))
    second = ("pi", k.shift(implies(eq(one, Z), FALSE)), ("hyp", assumption))
    return ("pair", disjunction(a, b), one, first, second)


def or_eliminate(a, b, c):
    """Under [a OR b, a->c, b->c], produce c for arbitrary scoped a,b,c."""
    # Sigma elimination introduces b at index 0, then f and g at hypotheses 3,4.
    # NAT's template uses a new x at index 0, so the existing b becomes 1.
    predicate = implies(eq(1, 0), k.shift(c, 2))
    zero = ("pi", eq(1, Z),
            ("app", ("hyp", 1), Z,
             ("app", ("hyp", 3), Z, ("hyp", 5))))
    # In the successor branch y is index 0; implication introduction makes
    # y index 1 and b index 2, with b=S(y) at hypothesis 5.
    # A second implication introduction makes y index 2 and b index 3.
    successor_equals_zero = ("eq", ("hyp", 5), eq(0, Z), ("hyp", 6))
    not_zero = ("pi", eq(3, Z), successor_nonzero(2, successor_equals_zero))
    positive = ("pi", eq(2, successor(1)),
                ("app", ("hyp", 2), Z,
                 ("app", ("hyp", 4), Z, not_zero)))
    cases = ("nat", predicate, 0, zero, positive)
    conclusion = ("app", cases, Z, reflexivity(0))
    return ("let", ("hyp", 0), c, conclusion)
