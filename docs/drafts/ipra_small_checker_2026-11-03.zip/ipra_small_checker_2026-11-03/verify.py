"""Regenerate and replay all delivered regression certificates and measurements."""

import contextlib
import io
import json
from pathlib import Path

import measure
import test_kernel_minimal


def main():
    root = Path(__file__).resolve().parent
    with contextlib.redirect_stdout(io.StringIO()):
        test_kernel_minimal.run()
        metrics = measure.run()
    results = json.loads((root / "tests_minimal.json").read_text())
    summary = {
        "main_checker": metrics["variants"][-1],
        "accepted_certificates": results["accepted_count"],
        "rejected_certificates": results["rejected_count"],
        "cli_checks": len(results["cli_checks"]),
        "all_checks_passed": True,
        "scope": "Executable certificate regression checks plus written metatheory; not a formal proof of universal checker correctness.",
    }
    (root / "verification.json").write_text(json.dumps(summary, indent=2) + "\n")
    text = ("The final reproducible regression suite accepts " + str(results["accepted_count"])
            + " complete certificates, rejects " + str(results["rejected_count"])
            + " invalid certificates, and passes four command-line checks, including normal and optimized Python. "
            + "The companion compact-calculus tests also check two nested substitution examples and three predecessor-kernel examples. "
            + "An independent review records additional malformed-input and binding attacks in "
            + r"\texttt{audit/independent\_audit.txt}; those review checks are distinguished from the delivered regression counts."
            + "\n")
    (root / "validation_summary.tex").write_text(text)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
