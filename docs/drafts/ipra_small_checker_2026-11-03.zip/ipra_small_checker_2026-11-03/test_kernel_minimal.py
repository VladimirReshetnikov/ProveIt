"""Executable minimal-kernel certificates and adversarial regression checks."""

import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import checker as k
import derived_minimal as derived
import test_kernel_compact as comparator


def run():
    with contextlib.redirect_stdout(io.StringIO()):
        accepted, rejected = comparator.run()
    accepted = {name: derived.certificate(c) for name, c in accepted.items()}
    z, false = k.ZERO, k.FALSE
    true = ("=", z, z)
    bridge = ("sig", derived.SEPARATION, derived.COLLAPSE)
    accepted["fixed_bridge_axiom"] = comparator.certificate(bridge, ("bridge",))
    compound = ("pi", ("=", 0, 1),
                ("sig", ("=", 2, 1), ("pi", false, ("=", 1, 3))))
    accepted["structural_explosion_quantified_parameters"] = comparator.certificate(
        compound, derived.explode(("hyp", 0), compound, 1), 1, (false,))
    accepted["case_on_falsity"] = comparator.certificate(false,
        ("nat", false, 0, ("hyp", 0), ("hyp", 0)), 1, (false,))
    sigma = ("sig", true, true)
    pair = ("pair", sigma, z, comparator.refl(z), comparator.refl(z))
    accepted["case_on_sigma"] = comparator.certificate(sigma,
        ("nat", sigma, z, pair, pair))
    rejected["no_primitive_explosion"] = comparator.certificate(true,
        ("abort", ("hyp", 0), true), 0, (false,))
    rejected["bridge_has_no_witness"] = comparator.certificate(bridge, ("bridge", true))
    for name, certificate in accepted.items():
        if not k.check(json.loads(json.dumps(certificate))):
            raise AssertionError(name)
    for name, certificate in rejected.items():
        try:
            k.check(json.loads(json.dumps(certificate)))
        except (ValueError, TypeError, IndexError, KeyError, RecursionError):
            continue
        raise AssertionError("accepted invalid certificate: " + name)
    root = Path(__file__).parent
    directory = root / "certificates"
    directory.mkdir(exist_ok=True)
    for name, certificate in accepted.items():
        (directory / (name + ".json")).write_text(json.dumps(certificate, indent=2) + "\n")
    # The actual command-line path, including Python -O, must retain validation.
    good = directory / "equation_induction_addition.json"
    bad = root / "invalid_minimal_certificate.json"
    bad.write_text(json.dumps(rejected["forbidden_compound_induction"]) + "\n")
    cli = []
    for optimized in (False, True):
        command = [sys.executable, *(["-O"] if optimized else []), str(root / "checker.py")]
        for path, expected in ((good, 0), (bad, 1)):
            result = subprocess.run([*command, str(path)], capture_output=True, text=True)
            if result.returncode != expected:
                raise AssertionError((optimized, path.name, result.stdout, result.stderr))
            cli.append({"optimized": optimized, "expected_exit": expected,
                        "actual_exit": result.returncode, "output": result.stdout.strip()})
    bad.unlink()
    results = {"accepted_count": len(accepted), "rejected_count": len(rejected),
               "accepted": list(accepted), "rejected": list(rejected),
               "cli_checks": cli,
               "scope": "Actual kernel replay plus finite regression checks; no machine-checked soundness theorem."}
    (root / "tests_minimal.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    run()
