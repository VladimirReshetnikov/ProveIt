"""Recheck certificates and compile the report; this is not trusted kernel code."""

from pathlib import Path
import os
import shutil
import subprocess
import sys
import tempfile


def main():
    root = Path(__file__).resolve().parent
    subprocess.run([sys.executable, str(root / "verify.py")], cwd=root, check=True)
    with tempfile.TemporaryDirectory(prefix="ipra-report-") as name:
        build = Path(name)
        for source in (*root.glob("*.tex"), root / "checker.py"):
            shutil.copyfile(source, build / source.name)
        for _ in range(3):
            process = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                                     cwd=build, capture_output=True, text=True)
            if process.returncode:
                raise RuntimeError(process.stdout[-5000:])
        complete = root / "report_complete.tmp"
        complete.write_bytes((build / "report.pdf").read_bytes())
        os.replace(complete, root / "report.pdf")
    print("Checked certificates and compiled report.pdf")


if __name__ == "__main__":
    main()
