A SMALL COMPLETE PROOF CHECKER FOR INTUITIONISTIC PRA
Prepared for Vladimir Reshetnikov, 3 November 2026

MAIN RESULT

The recommended theory has native initialized recursion and four formula
constructors: equality, genuine falsity, Pi and Sigma. Numerical cases
replace primitive disjunction. A single numerical rule permits an induction
hypothesis only for equations. Equality reflexivity and general explosion
are derived. All details and whole-carrier bi-interpretations are in the
report; AXIOMS.txt is the standalone complete specification.

START HERE

  report.pdf                Compiled report with proofs and full code listing
  report.tex                Main LaTeX source
  mathematics.tex           Complete calculus and mathematical proofs
  AXIOMS.txt                Complete plain-text specification and proof format
  checker.py                Entire recommended trusted proof checker

The checker is 139 physical lines and 4,758 bytes. Meaningful-token and AST
counts include input checks, scope/substitution, all rules, fixed axiom data,
and command-line handling. See metrics.json for exact counts and hashes.
No theorem builder or compiler is imported by checker.py.

REPRODUCE

Python 3.10 or newer, standard library only:

  python3 checker.py certificates/equation_induction_addition.json
  python3 verify.py
  python3 measure.py

The first command prints ACCEPT. verify.py regenerates and checks 31 valid
certificates, rejects 17 malformed/invalid certificates, and checks the CLI
with and without Python -O. It also replays the compact comparator examples.
The accepted certificate directory is regenerated during verification.

To rebuild the report, with the listed ordinary TeX packages installed:

  pdflatex -halt-on-error report.tex
  pdflatex -halt-on-error report.tex

All included TeX inputs are in this directory. The code appendix reads the
same checker.py that is measured and tested.

CERTIFICATES

certificates/ contains complete JSON proof objects, not numerical spot
checks. They include equation induction, successor laws, derived reflexivity
and explosion, both introductions and elimination for encoded disjunction,
and recovered quantifiers. Disjunction examples use closed and parameterized
quantified formulas. A certificate with nonempty assumptions proves a
sequent under those assumptions; only an empty context certifies a theorem.

derived_logic.py and derived_minimal.py are UNTRUSTED proof-producing
utilities. Their output must pass checker.py. test_kernel_compact.py and
test_kernel_minimal.py supply reproducible regression tests.

COMPARATORS

  baseline_nd.py             Conventional full-connective ND + source SC
  baseline_nd_optimized.py   Same after elementary reflexivity/abort reductions
  baseline_hilbert.py        Full-connective Hilbert theorem-list checker
  kernel_ps.py              Pi/Sigma with primitive disjunction and source SC
  kernel_compact.py         Pi/Sigma + mixed numerical rule + direct abort

All comparators already use native recursion; no signature-table overhead
is charged to them. Symmetric logical cases are combined. The Hilbert CLI
has been aligned to the same filename-only input behavior as the others.
These are NEW general checker implementations for comparison, not programs
found in the source archives. The sources supplied only finite diagnostics.

METRICS AND EVIDENCE

  metrics.json              All counts, conventions and checker SHA-256 hashes
  comparison_table.tex      Reproducible report table
  verification.json         Final regression summary
  tests_minimal.json         Detailed accepted/rejected cases and CLI outcomes
  tests_compact.json         Comparator and substitution diagnostics
  audit/                    Independent mathematical and implementation reviews
  provenance/sources.json   Exact six source archives, pinned URLs and hashes
  SHA256SUMS.txt             Digests of delivered files (except this digest file)

The directory was reviewed at ProveIt commit
3c85f4fc1c678b20fd7bbb44f9f5c17362baab8e.

The result is a concrete measured reduction in complete checker size.
It is not an encoding-independent minimum or a uniform proof-length gain.
The full metatheorems have written proofs and independent review; finite
regression tests are not a Lean/Rocq proof of universal soundness.
