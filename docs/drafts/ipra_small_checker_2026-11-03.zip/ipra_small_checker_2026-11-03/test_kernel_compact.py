"""Certificate examples and rejection tests; this file is not trusted kernel code."""

import json
from pathlib import Path
import kernel_compact as k
import kernel_ps as ps
import derived_logic as logic


Z = k.ZERO
F = k.FALSE
T = ("=", Z, Z)
D = k.CONTRADICTION


def S(t):
    return ("s", t)


def E(s, t):
    return ("=", s, t)


def R(n, a, h):
    return ("r", n, a, h)


def refl(t):
    e = ("rec", R(Z, t, 0))
    return ("eq", e, E(0, k.shift(t)), e)


def sym(p, s):
    return ("eq", p, E(0, k.shift(s)), refl(s))


def trans(p, q, s):
    return ("eq", q, E(k.shift(s), 0), p)


def certificate(a, p, d=0, g=()):
    return {"arity": d, "assumptions": list(g), "goal": a, "proof": p}


def successor_injective():
    # Sx=Sy, Q(Sx,0)=x, Q(Sy,0)=y, where Q's body returns the counter.
    p = ("eq", ("hyp", 0), E(R(0, Z, 1), 1),
         ("rec", R(S(0), Z, 1)))
    p = ("eq", p, E(0, 2), ("rec", R(S(1), Z, 1)))
    return certificate(E(0, 1), p, 2, (E(S(0), S(1)),))


def successor_nonzero():
    # From Sx=0 derive both 0=x and 1=x by changing the initializer.
    def initializer_equals_x(a):
        p = ("eq", ("hyp", 0), E(R(0, k.shift(a), 1), 1),
             ("rec", R(S(0), a, 1)))
        return ("eq", ("rec", R(Z, a, 1)), E(0, 1), p)
    p0 = initializer_equals_x(Z)
    p1 = initializer_equals_x(S(Z))
    contradiction = trans(p0, sym(p1, S(Z)), Z)
    return certificate(F, ("abort", contradiction, F), 1, (E(S(0), Z),))


def addition_identity():
    # R(n,0;v,w.Sv)=n, proved by genuine equation induction.
    a = E(R(0, Z, S(0)), 0)
    base = ("rec", R(Z, Z, S(0)))
    step = ("eq", ("hyp", 0), E(R(S(1), Z, S(0)), S(0)),
            ("rec", R(S(0), Z, S(0))))
    return certificate(a, ("nat", a, 0, base, step), 1)


def run():
    accepted = {
        "reflexivity_derived": certificate(E(0, 0), refl(0), 1),
        "pi_identity": certificate(("pi", E(0, Z), E(0, Z)),
                                   ("pi", E(0, Z), ("hyp", 0))),
        "pi_elimination": certificate(E(0, 0),
            ("app", ("hyp", 0), 0, refl(0)), 1,
            (("pi", E(0, 0), E(0, 0)),)),
        "sigma_introduction": certificate(("sig", T, E(0, Z)),
            ("pair", ("sig", T, E(0, Z)), Z, refl(Z), refl(Z))),
        "sigma_elimination": certificate(T,
            ("let", ("hyp", 0), T, ("hyp", 1)), 0,
            (("sig", T, E(0, Z)),)),
        "logical_explosion": certificate(E(0, Z),
            ("abort", ("hyp", 0), E(0, Z)), 1, (F,)),
        "separation_derived": certificate(("pi", D, F),
            ("pi", D, ("abort", ("hyp", 0), F))),
        "base_with_parameter": certificate(E(R(Z, 0, 2), 0),
            ("rec", R(Z, 0, 2)), 1),
        "step_with_parameter": certificate(E(R(S(Z), Z, 2), 0),
            ("rec", R(S(Z), Z, 2)), 1),
        "successor_injective": successor_injective(),
        "successor_nonzero": successor_nonzero(),
        "equation_induction_addition": addition_identity(),
        "compound_numerical_cases": certificate(("pi", T, T),
            ("nat", ("pi", T, T), Z, ("pi", T, ("hyp", 0)),
             ("pi", T, ("hyp", 0)))),
    }
    # The formula variables here are instantiated by quantified formulas.
    # The parameterized second group also exercises every binder-lifting path.
    logical_samples = [
        ("closed", 0, ("pi", T, E(0, 0)), ("sig", T, E(0, S(0))),
         ("pi", E(0, Z), ("sig", E(1, Z), E(0, 0)))),
        ("parameter", 1, ("pi", T, E(1, 1)), ("sig", T, E(0, 1)),
         ("pi", E(0, 1), E(1, 1))),
    ]
    for label, arity, a, b, c in logical_samples:
        encoded = logic.disjunction(a, b)
        accepted["or_left_" + label] = certificate(encoded, logic.or_left(a, b), arity, (a,))
        accepted["or_right_" + label] = certificate(encoded, logic.or_right(a, b), arity, (b,))
        accepted["or_elimination_" + label] = certificate(c,
            logic.or_eliminate(a, b, c), arity,
            (encoded, logic.implies(a, c), logic.implies(b, c)))
        both = logic.conjunction(a, b)
        accepted["and_left_" + label] = certificate(a,
            ("let", ("hyp", 0), a, ("hyp", 1)), arity, (both,))
        accepted["and_right_" + label] = certificate(b,
            ("let", ("hyp", 0), b, ("hyp", 2)), arity, (both,))
    accepted["forall_introduction"] = certificate(logic.all_(E(0, 0)),
        ("pi", T, refl(0)))
    accepted["forall_elimination"] = certificate(E(0, 0),
        ("app", ("hyp", 0), 0, refl(Z)), 1, (logic.all_(E(0, 0)),))
    exists_zero = logic.exists(E(0, Z))
    accepted["exists_introduction"] = certificate(exists_zero,
        ("pair", exists_zero, Z, refl(Z), refl(Z)))
    c = ("pi", T, ("sig", E(1, 1), E(0, 0)))
    accepted["exists_elimination"] = certificate(c,
        ("let", ("hyp", 0), c, ("app", ("hyp", 1), 0, ("hyp", 3))), 0,
        (exists_zero, ("pi", E(0, Z), k.shift(c))))
    rejected = {
        "false_as_theorem": certificate(F, refl(Z)),
        "false_arity_boolean": certificate(T, refl(Z), True),
        "free_variable_out_of_scope": certificate(E(0, 0), refl(0)),
        "recursor_descriptor_escape": certificate(E(R(Z, Z, 2), Z),
            ("rec", R(Z, Z, 2))),
        "compute_unknown_counter": certificate(E(R(0, Z, 0), Z),
            ("rec", R(0, Z, 0)), 1),
        "extra_proof_field": certificate(T, (*refl(Z), "extra")),
        "boolean_hypothesis_index": certificate(T, ("hyp", True), 0, (T, T)),
        "eigenvariable_escape_pi": certificate(("pi", T, E(0, Z)),
            ("pi", T, ("hyp", 0)), 1, (E(0, Z),)),
        "eigenvariable_escape_sigma": certificate(E(0, Z),
            ("let", ("hyp", 0), E(0, Z), ("hyp", 2)), 1,
            (("sig", T, E(0, Z)),)),
        "forbidden_compound_induction": certificate(("pi", T, T),
            ("nat", ("pi", T, T), Z, ("pi", T, ("hyp", 0)), ("hyp", 0))),
        "wrong_equation_step": certificate(E(0, Z),
            ("nat", E(0, Z), 0, refl(Z), ("hyp", 0)), 1),
        "no_primitive_reflexivity": certificate(T, ("refl", Z)),
        "no_primitive_disjunction": certificate(("|", T, F), ("hyp", 0), 0,
            (("|", T, F),)),
        "transport_wrong_premise": certificate(T,
            ("eq", ("hyp", 0), E(0, Z), refl(Z)), 1, (E(0, Z),)),
        "unscoped_sigma_witness": certificate(("sig", T, T),
            ("pair", ("sig", T, T), 0, refl(Z), refl(Z))),
    }
    for name, c in accepted.items():
        if not k.check(json.loads(json.dumps(c))):
            raise AssertionError(name)
    for name, c in rejected.items():
        try:
            k.check(json.loads(json.dumps(c)))
        except (ValueError, TypeError, IndexError, KeyError, RecursionError):
            continue
        raise AssertionError("accepted invalid certificate: " + name)
    # Native binder substitution, checked independently of proof-rule examples.
    term = R(0, 1, S(2))
    actual = k.subst(term, lambda i: (S(Z), Z)[i] if i < 2 else i - 2)
    if actual != R(S(Z), Z, S(S(Z))):
        raise AssertionError("nested recursor substitution")
    body = ("pi", E(0, 1), ("sig", E(0, 2), E(2, 3)))
    expected = ("pi", E(0, S(Z)), ("sig", E(0, S(Z)), E(S(Z), 2)))
    if k.inst(body, S(Z)) != expected:
        raise AssertionError("Pi/Sigma binding substitution")
    # Original Pi/Sigma+OR comparator: nontrivial equation-closure certificate.
    equation = E(S(R(0, Z, 1)), 0)
    predecessor_step = ("rec", R(S(0), Z, 1))
    step = ("eq", predecessor_step,
            E(S(R(S(1), Z, 1)), S(0)), refl(S(R(S(0), Z, 1))))
    source = certificate(("|", E(0, Z), equation),
                         ("sc", equation, 0, step), 1)
    ps.check(source)
    ps.check(certificate(("|", T, F), ("or", 0, F, refl(Z))))
    ps.check(certificate(T, ("case", ("hyp", 0), ("hyp", 1),
                            ("abort", ("hyp", 1), T)), 0, (("|", T, F),)))
    out = Path(__file__).parent / "certificates_compact"
    out.mkdir(exist_ok=True)
    for name, c in accepted.items():
        (out / (name + ".json")).write_text(json.dumps(c, indent=2) + "\n")
    results = {"accepted": list(accepted), "rejected": list(rejected),
               "structural_substitution_checks": 2, "ps_comparator_checks": 3,
               "scope": "Finite regression checks; no machine-checked metatheorem claim."}
    (Path(__file__).parent / "tests_compact.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))
    return accepted, rejected


if __name__ == "__main__":
    run()
