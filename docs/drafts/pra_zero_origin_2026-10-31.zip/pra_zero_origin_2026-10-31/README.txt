PRA FROM ZERO-ORIGIN POSITIVE UNIQUENESS
Prepared for Vladimir Reshetnikov, 31 October 2026

MAIN RESULT
A same-grammar improvement of the strongest current binary-iterator draft:
the arithmetic schema drops from 39 to 37 nodes, and the displayed total
including computation from 57 to 55. The binary language, one-parameter
budget, four equality occurrences, and absence of an admission test remain
unchanged. The full-language unary variant drops from 38 to 36 nodes.

Both classical and intuitionistic PRA are covered by the same nonlogical
schema. Full written constructive proofs and a restricted-language appendix
are included. Two fixed arithmetic updates suffice in the full PR language;
alternatively, successor uniqueness plus a single subtraction-shift equation
suffices there. These are precise resource refinements, not absolute minima.

FILES
  pra_zero_origin.tex / .pdf   Main source and compiled paper
  sections/                   Complete included LaTeX source
  axioms.txt                  Exact standalone specification and scope
  source_audit.json            Reviewed repository commit, paths, and hashes
  comparison.tsv              Reproducible formula counts across parameter arities
  artifacts/check.py          Formula-tree checker and bounded diagnostics
  artifacts/check_results.json
                              Executed results; diagnostics are not proofs
  formal/*.lean / *.lean.log  Three checked constructive kernels and logs
  formal/README.txt           Formalization scope and conditional assumptions
  build.sh / check.sh         Rebuild and verify
  lean-toolchain              Compiler version
  VALIDATION.txt              Validation record and limitations
  SHA256SUMS                 Checksums of all other delivered files

BUILD
  sh build.sh
Requires latexmk and the packages listed in the main source.

CHECK
  sh check.sh
Requires Python 3.10+ and Lean 4.19.0. Set PRA_LEAN to the Lean executable
if it is not on PATH. The check does not need Mathlib or network access.

FORMAL SCOPE
The 34 printed Lean dependency checks report no global axioms. Computation,
uniqueness, coverage, and latch availability are explicit hypotheses where
used. The files operate over an abstract carrier and do not use Nat induction.
They do not formalize the whole first-order proof calculus, finite PR syntax,
parameter-packing compiler, or full conservativity theorem. Those are proved
in the paper. No claim of an entirely machine-checked PRA equivalence is made.

SOURCE COMPARISON
ProveIt commit 60cefaa503c2a54dacf2fd03e75c68f9c2c65d80.
All six current PRA draft archives were inspected. The incoming inventory
and index were checked, with no additional PRA-labelled package; unrelated
archive interiors were not inspected. Prior source archives and external
copyrighted literature are not redistributed.
