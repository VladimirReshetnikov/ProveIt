CONDITIONAL CONSTRUCTIVE LEAN KERNELS

Compiler: Lean 4.19.0, commit 6caaee842e94.
All sources are import-free, have no unfinished proofs, and use no classical
choice or Nat induction. The arithmetic carrier is abstract.

ClampedUniqueness.lean
  13 printed dependency audits. Checks the counter/state CU constructor
  bootstrap, ordinary uniqueness, exact content, and CU iff the previous
  positive-tail uniqueness schema.

ZeroBasedPositiveUniqueness.lean
  9 printed dependency audits. Checks the equivalent unary outer-update
  schema, constructor bootstrap, and exact ordinary-uniqueness content.

TwoUpdateCore.lean
  12 printed dependency audits. Checks the parity no-fixed-point argument,
  successor ramp/latch induction, zero/nonzero/fixed-one tests, commutation
  from a fixed Shift equation, subtraction diagonals, native cancellation,
  and derived native constancy.

IMPORTANT SCOPE
The schemas are modeled using explicit semantic function callbacks. These
are conditional logical kernels, not encodings of the finite-description
grammar or a first-order derivability relation. The relevant computations,
uniqueness principles, and existence of a latch for each admitted term are
theorem hypotheses. "Does not depend on any axioms" in the logs means no
global Lean axioms are used beyond these explicit arguments; it does not
mean the arithmetic assumptions are absent.

The paper establishes that each instantiating callback used by the proof
comes from an allowed finite term, and proves the remaining reflection,
coding, and conservativity metatheorems. The full equivalence theorem is
not claimed completely formalized.

RUN
  lean ClampedUniqueness.lean
  lean ZeroBasedPositiveUniqueness.lean
  lean TwoUpdateCore.lean

Alternatively run the archive's check.sh from its top directory.
