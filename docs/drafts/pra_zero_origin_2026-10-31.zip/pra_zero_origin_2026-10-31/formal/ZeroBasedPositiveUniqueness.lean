/-
Zero-based positive uniqueness: constructive bootstrap and exact content.

Lean 4.19.0. Abstract carrier, no imports, Nat induction, classical choice,
or sorry. This is a conditional semantic kernel: the schema ranges over
function callbacks. It does not formalize finite term syntax or the full
equivalence with first-order PRA. Each paper application is to an explicit
finite primitive-recursive term, with its numerical parameters fixed.
-/

universe u

namespace ZeroBasedPositiveUniqueness

structure Computation (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  iter : (A → A) → A → A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  iter_zero : ∀ h a, iter h zero a = a
  iter_succ : ∀ h n a, iter h (succ n) a = h (iter h n a)

variable {A : Type u}

def One (d : Computation A) : A := d.succ d.zero

def Coverage (d : Computation A) : Prop :=
  ∀ n, n = d.zero ∨ n = d.succ (d.pred n)

def P0For (d : Computation A) (h : A → A) : Prop :=
  ∀ f : A → A, (∀ n, f (d.succ n) = h (f n)) →
    d.zero ≠ One d ∧
      ∀ n, n = d.zero ∨ f n = h (d.iter h (d.pred n) (f d.zero))

def RUFor (d : Computation A) (h : A → A) : Prop :=
  ∀ f : A → A, (∀ n, f (d.succ n) = h (f n)) →
    ∀ n, f n = d.iter h n (f d.zero)

def P0 (d : Computation A) : Prop := ∀ h : A → A, P0For d h

def RU (d : Computation A) : Prop := ∀ h : A → A, RUFor d h

theorem successor_injective (d : Computation A)
    (x y : A) (h : d.succ x = d.succ y) : x = y := by
  have hp := congrArg d.pred h
  rw [d.pred_succ, d.pred_succ] at hp
  exact hp

theorem separation (d : Computation A) (pos : P0For d d.succ) :
    d.zero ≠ One d := by
  exact (pos (fun n => n) (fun _ => rfl)).1

theorem successor_nonzero (d : Computation A)
    (sep : d.zero ≠ One d) : ∀ n, d.succ n ≠ d.zero := by
  intro n hn
  have hn0 : n = d.zero := by
    have hp := congrArg d.pred hn
    rw [d.pred_succ, d.pred_zero] at hp
    exact hp
  apply sep
  change d.zero = d.succ d.zero
  rw [hn0] at hn
  exact hn.symm

theorem successor_iterator_zero (d : Computation A)
    (pos : P0For d d.succ) :
    ∀ n, d.iter d.succ n d.zero = n := by
  intro n
  have inst := pos (fun x => x) (fun _ => rfl)
  cases inst.2 (d.succ n) with
  | inl h => exact False.elim (successor_nonzero d inst.1 n h)
  | inr h =>
      change d.succ n = d.succ (d.iter d.succ (d.pred (d.succ n)) d.zero) at h
      rw [d.pred_succ] at h
      exact (successor_injective d n _ h).symm

theorem coverage (d : Computation A) (pos : P0For d d.succ) :
    Coverage d := by
  intro n
  have inst := pos (fun x => x) (fun _ => rfl)
  cases inst.2 n with
  | inl h => exact Or.inl h
  | inr h =>
      apply Or.inr
      change n = d.succ (d.iter d.succ (d.pred n) d.zero) at h
      rw [successor_iterator_zero d pos] at h
      exact h

theorem uniqueness_for (d : Computation A) (cov : Coverage d)
    (h : A → A) (pos : P0For d h) : RUFor d h := by
  intro f recurrence n
  have result := pos f recurrence
  cases cov n with
  | inl hn =>
      rw [hn, d.iter_zero]
  | inr hn =>
      cases result.2 n with
      | inl hz =>
          rw [hz, d.iter_zero]
      | inr hf =>
          calc
            f n = h (d.iter h (d.pred n) (f d.zero)) := hf
            _ = d.iter h (d.succ (d.pred n)) (f d.zero) :=
              (d.iter_succ h (d.pred n) (f d.zero)).symm
            _ = d.iter h n (f d.zero) :=
              congrArg (fun x => d.iter h x (f d.zero)) hn.symm

theorem p0_for_of_uniqueness (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (h : A → A) (uniq : RUFor d h) : P0For d h := by
  intro f recurrence
  refine ⟨sep, ?_⟩
  intro n
  cases cov n with
  | inl hn => exact Or.inl hn
  | inr hn =>
      apply Or.inr
      calc
        f n = d.iter h n (f d.zero) := uniq f recurrence n
        _ = d.iter h (d.succ (d.pred n)) (f d.zero) :=
          congrArg (fun x => d.iter h x (f d.zero)) hn
        _ = h (d.iter h (d.pred n) (f d.zero)) :=
          d.iter_succ h (d.pred n) (f d.zero)

theorem exact_content (d : Computation A) :
    P0 d ↔ d.zero ≠ One d ∧ Coverage d ∧ RU d := by
  constructor
  · intro pos
    have cov := coverage d (pos d.succ)
    exact ⟨separation d (pos d.succ), cov,
      fun h => uniqueness_for d cov h (pos h)⟩
  · intro h
    exact fun update => p0_for_of_uniqueness d h.1 h.2.1 update (h.2.2 update)

/- The per-update statement allows restriction to S,p, or to S plus Shift. -/
theorem restricted_uniqueness (d : Computation A)
    (pos_succ : P0For d d.succ) (h : A → A)
    (pos_h : P0For d h) : RUFor d h := by
  exact uniqueness_for d (coverage d pos_succ) h pos_h

#print axioms successor_injective
#print axioms separation
#print axioms successor_nonzero
#print axioms successor_iterator_zero
#print axioms coverage
#print axioms uniqueness_for
#print axioms p0_for_of_uniqueness
#print axioms exact_content
#print axioms restricted_uniqueness

end ZeroBasedPositiveUniqueness
