/-
Clamped recurrence uniqueness in the restricted binary iterator language.

Lean 4.19.0. No imports, Nat induction, classical choice, or sorry.
This is an abstract-carrier logical kernel with explicit callbacks for
term instances. It checks the new bootstrap and interderivability with
separation + coverage + ordinary counter-dependent recursion uniqueness.
Finite-description syntax and the remaining PRA completion are not encoded.
-/

universe u

namespace ClampedUniqueness

structure Computation (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  iter : (A → A → A) → A → A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  iter_zero : ∀ h a, iter h zero a = a
  iter_succ : ∀ h n a, iter h (succ n) a = h n (iter h n a)

variable {A : Type u}

def One (d : Computation A) : A := d.succ d.zero

def SuccessorUpdate (d : Computation A) : A → A → A :=
  fun _ v => d.succ v

def Coverage (d : Computation A) : Prop :=
  ∀ n, n = d.zero ∨ n = d.succ (d.pred n)

def CUFor (d : Computation A) (h : A → A → A) : Prop :=
  ∀ f : A → A, (∀ n, f (d.succ n) = h n (f n)) →
    d.zero ≠ One d ∧ ∀ n, n = d.zero ∨
      f n = d.iter h (d.succ (d.pred n)) (f d.zero)

def RUFor (d : Computation A) (h : A → A → A) : Prop :=
  ∀ f : A → A, (∀ n, f (d.succ n) = h n (f n)) →
    ∀ n, f n = d.iter h n (f d.zero)

def CU (d : Computation A) : Prop := ∀ h : A → A → A, CUFor d h

def RU (d : Computation A) : Prop := ∀ h : A → A → A, RUFor d h

def PositiveTailFor (d : Computation A) (h : A → A → A) : Prop :=
  ∀ f : A → A, (∀ n, f (d.succ (d.succ n)) = h n (f (d.succ n))) →
    d.zero ≠ One d ∧ ∀ n, n = d.zero ∨
      f n = d.iter h (d.pred n) (f (One d))

def PositiveTail (d : Computation A) : Prop :=
  ∀ h : A → A → A, PositiveTailFor d h

theorem successor_injective (d : Computation A)
    (x y : A) (h : d.succ x = d.succ y) : x = y := by
  have hp := congrArg d.pred h
  rw [d.pred_succ, d.pred_succ] at hp
  exact hp

theorem separation (d : Computation A)
    (pos : CUFor d (SuccessorUpdate d)) : d.zero ≠ One d := by
  exact (pos (fun n => n) (fun _ => rfl)).1

theorem successor_nonzero (d : Computation A)
    (sep : d.zero ≠ One d) : ∀ n, d.succ n ≠ d.zero := by
  intro n hn
  have hn0 : n = d.zero := by
    have hp := congrArg d.pred hn
    rw [d.pred_succ, d.pred_zero] at hp
    exact hp
  apply sep
  change d.zero = d.succ d.zero
  rw [hn0] at hn
  exact hn.symm

theorem successor_iterator_zero (d : Computation A)
    (pos : CUFor d (SuccessorUpdate d)) :
    ∀ n, d.iter (SuccessorUpdate d) n d.zero = n := by
  intro n
  have inst := pos (fun x => x) (fun _ => rfl)
  cases inst.2 (d.succ n) with
  | inl h => exact False.elim (successor_nonzero d inst.1 n h)
  | inr h =>
      change d.succ n = d.iter (SuccessorUpdate d)
        (d.succ (d.pred (d.succ n))) d.zero at h
      rw [d.pred_succ, d.iter_succ] at h
      change d.succ n = d.succ (d.iter (SuccessorUpdate d) n d.zero) at h
      exact (successor_injective d n _ h).symm

theorem coverage (d : Computation A)
    (pos : CUFor d (SuccessorUpdate d)) : Coverage d := by
  intro n
  have inst := pos (fun x => x) (fun _ => rfl)
  cases inst.2 n with
  | inl h => exact Or.inl h
  | inr h =>
      apply Or.inr
      change n = d.iter (SuccessorUpdate d) (d.succ (d.pred n)) d.zero at h
      rw [successor_iterator_zero d pos] at h
      exact h

theorem uniqueness_for (d : Computation A) (cov : Coverage d)
    (h : A → A → A) (pos : CUFor d h) : RUFor d h := by
  intro f recurrence n
  have result := pos f recurrence
  cases cov n with
  | inl hn => rw [hn, d.iter_zero]
  | inr hn =>
      cases result.2 n with
      | inl hz => rw [hz, d.iter_zero]
      | inr hf =>
          calc
            f n = d.iter h (d.succ (d.pred n)) (f d.zero) := hf
            _ = d.iter h n (f d.zero) :=
              congrArg (fun x => d.iter h x (f d.zero)) hn.symm

theorem cu_for_of_uniqueness (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (h : A → A → A) (uniq : RUFor d h) : CUFor d h := by
  intro f recurrence
  refine ⟨sep, ?_⟩
  intro n
  cases cov n with
  | inl hn => exact Or.inl hn
  | inr hn =>
      apply Or.inr
      calc
        f n = d.iter h n (f d.zero) := uniq f recurrence n
        _ = d.iter h (d.succ (d.pred n)) (f d.zero) :=
          congrArg (fun x => d.iter h x (f d.zero)) hn

theorem exact_content (d : Computation A) :
    CU d ↔ d.zero ≠ One d ∧ Coverage d ∧ RU d := by
  constructor
  · intro pos
    have cov := coverage d (pos (SuccessorUpdate d))
    exact ⟨separation d (pos (SuccessorUpdate d)), cov,
      fun h => uniqueness_for d cov h (pos h)⟩
  · intro h
    exact fun update => cu_for_of_uniqueness d h.1 h.2.1 update (h.2.2 update)

/- This interface also applies to any restricted family containing S. -/
theorem restricted_uniqueness (d : Computation A)
    (pos_succ : CUFor d (SuccessorUpdate d)) (h : A → A → A)
    (pos_h : CUFor d h) : RUFor d h := by
  exact uniqueness_for d (coverage d pos_succ) h pos_h

/- Direct comparison with the strongest supplied binary-language PU draft. -/
theorem positive_tail_of_cu (d : Computation A) (cu : CU d) :
    PositiveTail d := by
  have facts := (exact_content d).1 cu
  intro h f recurrence
  refine ⟨facts.1, ?_⟩
  have orbit := facts.2.2 h (fun n => f (d.succ n)) recurrence
  intro n
  cases facts.2.1 n with
  | inl hn => exact Or.inl hn
  | inr hn =>
      apply Or.inr
      calc
        f n = f (d.succ (d.pred n)) := congrArg f hn
        _ = d.iter h (d.pred n) (f (One d)) := orbit (d.pred n)

theorem old_coverage (d : Computation A) (old : PositiveTail d) :
    d.zero ≠ One d ∧ Coverage d := by
  have inst := old (SuccessorUpdate d) (fun n => n) (fun _ => rfl)
  have one_orbit : ∀ x, d.iter (SuccessorUpdate d) x (One d) = d.succ x := by
    intro x
    cases inst.2 (d.succ x) with
    | inl h => exact False.elim (successor_nonzero d inst.1 x h)
    | inr h =>
        change d.succ x = d.iter (SuccessorUpdate d)
          (d.pred (d.succ x)) (One d) at h
        rw [d.pred_succ] at h
        exact h.symm
  refine ⟨inst.1, ?_⟩
  intro n
  cases inst.2 n with
  | inl h => exact Or.inl h
  | inr h =>
      apply Or.inr
      change n = d.iter (SuccessorUpdate d) (d.pred n) (One d) at h
      exact h.trans (one_orbit (d.pred n))

theorem ordinary_uniqueness_of_old (d : Computation A)
    (old : PositiveTail d) : RU d := by
  intro h f recurrence n
  have inst := old h (fun x => f (d.pred x)) (by
    intro x
    change f (d.pred (d.succ (d.succ x))) =
      h x (f (d.pred (d.succ x)))
    rw [d.pred_succ, d.pred_succ]
    exact recurrence x)
  cases inst.2 (d.succ n) with
  | inl hn => exact False.elim (successor_nonzero d inst.1 n hn)
  | inr hn =>
      change f (d.pred (d.succ n)) = d.iter h (d.pred (d.succ n))
        (f (d.pred (d.succ d.zero))) at hn
      rw [d.pred_succ, d.pred_succ] at hn
      exact hn

theorem cu_iff_positive_tail (d : Computation A) :
    CU d ↔ PositiveTail d := by
  constructor
  · exact positive_tail_of_cu d
  · intro old
    have base := old_coverage d old
    exact (exact_content d).2
      ⟨base.1, base.2, ordinary_uniqueness_of_old d old⟩

#print axioms successor_injective
#print axioms separation
#print axioms successor_nonzero
#print axioms successor_iterator_zero
#print axioms coverage
#print axioms uniqueness_for
#print axioms cu_for_of_uniqueness
#print axioms exact_content
#print axioms restricted_uniqueness
#print axioms positive_tail_of_cu
#print axioms old_coverage
#print axioms ordinary_uniqueness_of_old
#print axioms cu_iff_positive_tail

end ClampedUniqueness
