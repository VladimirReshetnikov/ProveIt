/-
Constructive logical kernel for the two-update reduction and its refinement.

Lean 4.19.0. No imports, sorry, classical choice, or Nat induction.
The carrier is abstract. Function callbacks below expose semantic proof
obligations; they do not encode finite PR descriptions or a first-order
proof calculus. In particular, availability of a latch for a supplied
function is an explicit hypothesis, not an internal universal evaluator.

The refined result uses successor uniqueness and the single fixed Shift
equation, rather than assuming predecessor or identity uniqueness.
-/

universe u

namespace TwoUpdateCore

structure Computation (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  add : A → A → A
  sub : A → A → A
  gate : A → A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  add_zero : ∀ a, add zero a = a
  add_succ : ∀ n a, add (succ n) a = succ (add n a)
  sub_zero : ∀ a, sub zero a = a
  sub_succ : ∀ n a, sub (succ n) a = pred (sub n a)
  gate_zero : ∀ a, gate zero a = a
  gate_succ : ∀ n a, gate (succ n) a = zero

variable {A : Type u}

def One (d : Computation A) : A := d.succ d.zero

def Coverage (d : Computation A) : Prop :=
  ∀ n, n = d.zero ∨ n = d.succ (d.pred n)

def SuccessorUniqueness (d : Computation A) : Prop :=
  ∀ f : A → A, (∀ n, f (d.succ n) = d.succ (f n)) →
    ∀ n, f n = d.add n (f d.zero)

def ZeroInduction (d : Computation A) : Prop :=
  ∀ f : A → A, f d.zero = d.zero →
    (∀ n, f n = d.zero → f (d.succ n) = d.zero) →
    ∀ n, f n = d.zero

def Shift (d : Computation A) : Prop :=
  ∀ n a, d.sub (d.succ n) (d.succ a) = d.sub n a

theorem successor_nonzero (d : Computation A)
    (sep : d.zero ≠ One d) : ∀ n, d.succ n ≠ d.zero := by
  intro n hn
  have hn0 : n = d.zero := by
    have hp := congrArg d.pred hn
    rw [d.pred_succ, d.pred_zero] at hp
    exact hp
  apply sep
  change d.zero = d.succ d.zero
  rw [hn0] at hn
  exact hn.symm

theorem zero_decision (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d) :
    ∀ n, n = d.zero ∨ n ≠ d.zero := by
  intro n
  cases cov n with
  | inl h => exact Or.inl h
  | inr h =>
      apply Or.inr
      intro h0
      exact successor_nonzero d sep (d.pred n) (h.symm.trans h0)

theorem gate_at_nonzero (d : Computation A) (cov : Coverage d)
    (x y : A) (hx : x ≠ d.zero) : d.gate x y = d.zero := by
  cases cov x with
  | inl h => exact False.elim (hx h)
  | inr h =>
      rw [h]
      exact d.gate_succ (d.pred x) y

theorem gate_zero_right (d : Computation A) (cov : Coverage d) :
    ∀ x, d.gate x d.zero = d.zero := by
  intro x
  cases cov x with
  | inl h => rw [h, d.gate_zero]
  | inr h => rw [h, d.gate_succ]

theorem add_zero_right (d : Computation A)
    (us : SuccessorUniqueness d) : ∀ n, d.add n d.zero = n := by
  intro n
  exact (us (fun x => x) (fun _ => rfl) n).symm

theorem add_successor_right (d : Computation A)
    (us : SuccessorUniqueness d) :
    ∀ n a, d.add n (d.succ a) = d.succ (d.add n a) := by
  intro n a
  have h := us (fun x => d.succ (d.add x a)) (by
    intro x
    change d.succ (d.add (d.succ x) a) = d.succ (d.succ (d.add x a))
    rw [d.add_succ]) n
  change d.succ (d.add n a) =
    d.add n (d.succ (d.add d.zero a)) at h
  rw [d.add_zero] at h
  exact h.symm

theorem add_one (d : Computation A) (us : SuccessorUniqueness d) :
    ∀ n, d.add n (One d) = d.succ n := by
  intro n
  change d.add n (d.succ d.zero) = d.succ n
  rw [add_successor_right d us, add_zero_right d us]

/- Parity proves that successor has no fixed point, without induction. -/
theorem no_successor_fixed_point (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (parity : A → A)
    (parity_zero : parity d.zero = d.zero)
    (parity_succ : ∀ n,
      parity (d.succ n) = d.gate (parity n) (One d)) :
    ∀ n, d.succ n ≠ n := by
  have gate_bit : ∀ x,
      d.gate x (One d) = d.zero ∨ d.gate x (One d) = One d := by
    intro x
    cases cov x with
    | inl h => exact Or.inr (by rw [h, d.gate_zero])
    | inr h => exact Or.inl (by rw [h, d.gate_succ])
  have parity_bit : ∀ x, parity x = d.zero ∨ parity x = One d := by
    intro x
    cases cov x with
    | inl h => exact Or.inl (h ▸ parity_zero)
    | inr h =>
        rw [h, parity_succ]
        exact gate_bit (parity (d.pred x))
  intro n hn
  have hf : parity n = d.gate (parity n) (One d) := by
    calc
      parity n = parity (d.succ n) := congrArg parity hn.symm
      _ = d.gate (parity n) (One d) := parity_succ n
  cases parity_bit n with
  | inl h =>
      rw [h, d.gate_zero] at hf
      exact sep hf
  | inr h =>
      rw [h] at hf
      change One d = d.gate (d.succ d.zero) (One d) at hf
      rw [d.gate_succ] at hf
      exact sep hf.symm

/- This is the new ramp-latch argument: it uses only successor uniqueness. -/
theorem zero_test_latch (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (us : SuccessorUniqueness d)
    (nf : ∀ n, d.succ n ≠ n)
    (e q : A → A)
    (q_zero : q d.zero = One d)
    (q_succ : ∀ n, q (d.succ n) = d.gate (e n) (q n))
    (e_zero : e d.zero = d.zero)
    (e_step : ∀ n, e n = d.zero → e (d.succ n) = d.zero) :
    ∀ n, e n = d.zero := by
  have q_one : q (d.succ d.zero) = One d := by
    rw [q_succ, e_zero, d.gate_zero, q_zero]
  have stationary : ∀ n,
      q (d.succ (d.succ n)) = q (d.succ n) := by
    intro n
    cases zero_decision d sep cov (e n) with
    | inl he => rw [q_succ (d.succ n), e_step n he, d.gate_zero]
    | inr he =>
        have hq : q (d.succ n) = d.zero := by
          rw [q_succ n]
          exact gate_at_nonzero d cov (e n) (q n) he
        rw [q_succ (d.succ n), hq, gate_zero_right d cov]
  have ramp : ∀ n, d.add n (q (d.succ n)) = d.succ n := by
    intro n
    have h := us (fun x => d.add x (q (d.succ x))) (by
      intro x
      change d.add (d.succ x) (q (d.succ (d.succ x))) =
        d.succ (d.add x (q (d.succ x)))
      rw [d.add_succ, stationary]) n
    change d.add n (q (d.succ n)) =
      d.add n (d.add d.zero (q (d.succ d.zero))) at h
    rw [d.add_zero, q_one, add_one d us] at h
    exact h
  intro n
  cases zero_decision d sep cov (e n) with
  | inl he => exact he
  | inr he =>
      have hq : q (d.succ n) = d.zero := by
        rw [q_succ n]
        exact gate_at_nonzero d cov (e n) (q n) he
      have h := ramp n
      rw [hq, add_zero_right d us] at h
      exact False.elim (nf n h.symm)

theorem zero_induction_of_latches (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (us : SuccessorUniqueness d) (nf : ∀ n, d.succ n ≠ n)
    (latches : ∀ e : A → A, ∃ q : A → A,
      q d.zero = One d ∧
        ∀ n, q (d.succ n) = d.gate (e n) (q n)) :
    ZeroInduction d := by
  intro e ez es
  obtain ⟨q, qz, qs⟩ := latches e
  exact zero_test_latch d sep cov us nf e q qz qs ez es

theorem zero_test_of_nonzero (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d) (x : A) :
    d.gate x (One d) = d.zero ↔ x ≠ d.zero := by
  constructor
  · intro h hx
    rw [hx, d.gate_zero] at h
    exact sep h.symm
  · intro hx
    exact gate_at_nonzero d cov x (One d) hx

theorem nonzero_induction (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (zi : ZeroInduction d) (f : A → A)
    (fz : f d.zero ≠ d.zero)
    (fs : ∀ n, f n ≠ d.zero → f (d.succ n) ≠ d.zero) :
    ∀ n, f n ≠ d.zero := by
  have h := zi (fun n => d.gate (f n) (One d))
    ((zero_test_of_nonzero d sep cov (f d.zero)).2 fz)
    (by
      intro n hn
      exact (zero_test_of_nonzero d sep cov (f (d.succ n))).2
        (fs n ((zero_test_of_nonzero d sep cov (f n)).1 hn)))
  intro n
  exact (zero_test_of_nonzero d sep cov (f n)).1 (h n)

theorem sum_zero (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d) (x y : A) :
    d.add x y = d.zero ↔ x = d.zero ∧ y = d.zero := by
  constructor
  · intro h
    cases cov x with
    | inl hx =>
        rw [hx, d.add_zero] at h
        exact ⟨hx, h⟩
    | inr hx =>
        rw [hx, d.add_succ] at h
        exact False.elim (successor_nonzero d sep _ h)
  · intro h
    rw [h.1, h.2, d.add_zero]

def OneError (d : Computation A) (x : A) : A :=
  d.add (d.gate x (One d)) (d.pred x)

theorem one_error_correct (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d) (x : A) :
    OneError d x = d.zero ↔ x = One d := by
  constructor
  · intro h
    have parts := (sum_zero d sep cov _ _).1 h
    have hn := (zero_test_of_nonzero d sep cov x).1 parts.1
    cases cov x with
    | inl hx => exact False.elim (hn hx)
    | inr hx =>
        change x = d.succ d.zero
        exact hx.trans (congrArg d.succ parts.2)
  · intro hx
    subst x
    change d.add (d.gate (d.succ d.zero) (One d))
      (d.pred (d.succ d.zero)) = d.zero
    rw [d.gate_succ, d.pred_succ, d.add_zero]

theorem one_induction (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (zi : ZeroInduction d) (f : A → A)
    (fz : f d.zero = One d)
    (fs : ∀ n, f n = One d → f (d.succ n) = One d) :
    ∀ n, f n = One d := by
  have h := zi (fun n => OneError d (f n))
    ((one_error_correct d sep cov (f d.zero)).2 fz)
    (by
      intro n hn
      exact (one_error_correct d sep cov (f (d.succ n))).2
        (fs n ((one_error_correct d sep cov (f n)).1 hn)))
  intro n
  exact (one_error_correct d sep cov (f n)).1 (h n)

theorem sub_zero_right (d : Computation A) (zi : ZeroInduction d) :
    ∀ n, d.sub n d.zero = d.zero := by
  exact zi (fun n => d.sub n d.zero) (d.sub_zero d.zero) (by
    intro n hn
    change d.sub (d.succ n) d.zero = d.zero
    change d.sub n d.zero = d.zero at hn
    rw [d.sub_succ, hn, d.pred_zero])

theorem predecessor_commutes (d : Computation A)
    (cov : Coverage d) (zi : ZeroInduction d) (shift : Shift d) :
    ∀ n a, d.pred (d.sub n a) = d.sub n (d.pred a) := by
  intro n a
  cases cov a with
  | inl ha => rw [ha, sub_zero_right d zi, d.pred_zero, sub_zero_right d zi]
  | inr ha =>
      rw [ha, d.pred_succ]
      exact (d.sub_succ n (d.succ (d.pred a))).symm.trans
        (shift n (d.pred a))

theorem sub_diagonal (d : Computation A)
    (zi : ZeroInduction d) (shift : Shift d) :
    ∀ n, d.sub n n = d.zero := by
  exact zi (fun n => d.sub n n) (d.sub_zero d.zero) (by
    intro n hn
    change d.sub (d.succ n) (d.succ n) = d.zero
    change d.sub n n = d.zero at hn
    rw [shift, hn])

theorem sub_successor_diagonal (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (zi : ZeroInduction d) (shift : Shift d) :
    ∀ n, d.sub n (d.succ n) = One d := by
  exact one_induction d sep cov zi (fun n => d.sub n (d.succ n))
    (d.sub_zero (d.succ d.zero)) (by
      intro n hn
      change d.sub (d.succ n) (d.succ (d.succ n)) = One d
      change d.sub n (d.succ n) = One d at hn
      rw [shift, hn])

/- Main new step: native cancellation from Shift and successor uniqueness. -/
theorem native_cancellation (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (us : SuccessorUniqueness d) (zi : ZeroInduction d)
    (shift : Shift d) :
    ∀ k x, d.sub k (d.add k x) = x := by
  intro k
  let H : A → A := fun x => d.sub k (d.add k x)
  have hz : H d.zero = d.zero := by
    dsimp [H]
    rw [add_zero_right d us, sub_diagonal d zi shift]
  have ho : H (One d) = One d := by
    dsimp [H]
    rw [add_one d us, sub_successor_diagonal d sep cov zi shift]
  have hp : ∀ x, d.pred (H (d.succ x)) = H x := by
    intro x
    dsimp [H]
    rw [add_successor_right d us,
      predecessor_commutes d cov zi shift, d.pred_succ]
  have positive : ∀ x, H (d.succ x) ≠ d.zero := by
    apply nonzero_induction d sep cov zi (fun x => H (d.succ x))
    · intro h
      exact sep (h.symm.trans ho)
    · intro x hx hnext
      have bad := congrArg d.pred hnext
      rw [hp, d.pred_zero] at bad
      exact hx bad
  have hs : ∀ x, H (d.succ x) = d.succ (H x) := by
    intro x
    cases cov (H (d.succ x)) with
    | inl h => exact False.elim (positive x h)
    | inr h => exact h.trans (congrArg d.succ (hp x))
  intro x
  have h := us H hs x
  rw [hz, add_zero_right d us] at h
  exact h

theorem native_constancy (d : Computation A)
    (sep : d.zero ≠ One d) (cov : Coverage d)
    (us : SuccessorUniqueness d) (zi : ZeroInduction d)
    (shift : Shift d) (f : A → A)
    (stationary : ∀ n, f (d.succ n) = f n) :
    ∀ n, f n = f d.zero := by
  intro n
  have h := us (fun x => d.add x (f x)) (by
    intro x
    change d.add (d.succ x) (f (d.succ x)) = d.succ (d.add x (f x))
    rw [d.add_succ, stationary]) n
  change d.add n (f n) = d.add n (d.add d.zero (f d.zero)) at h
  rw [d.add_zero] at h
  have hc := congrArg (d.sub n) h
  rw [native_cancellation d sep cov us zi shift,
    native_cancellation d sep cov us zi shift] at hc
  exact hc

#print axioms no_successor_fixed_point
#print axioms zero_test_latch
#print axioms zero_induction_of_latches
#print axioms nonzero_induction
#print axioms one_error_correct
#print axioms one_induction
#print axioms sub_zero_right
#print axioms predecessor_commutes
#print axioms sub_diagonal
#print axioms sub_successor_diagonal
#print axioms native_cancellation
#print axioms native_constancy

end TwoUpdateCore
