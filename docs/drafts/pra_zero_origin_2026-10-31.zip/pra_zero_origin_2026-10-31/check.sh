#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check.py --output artifacts/check_results.json --tsv comparison.tsv
pra_lean_executable=${PRA_LEAN:-lean}
for source in formal/ClampedUniqueness.lean formal/ZeroBasedPositiveUniqueness.lean formal/TwoUpdateCore.lean
do
  "$pra_lean_executable" "$source" > "$source.log"
done
python3 - <<'PY'
from pathlib import Path
logs = sorted(Path('formal').glob('*.lean.log'))
lines = [line for log in logs for line in log.read_text().splitlines() if line]
assert len(logs) == 3
assert len(lines) == 34, (len(lines), lines)
assert all('does not depend on any axioms' in line for line in lines)
print('PASS: 34 Lean dependency audits, no global axioms.')
PY
