#!/usr/bin/env python3
"""Reproduce formula-tree counts and bounded algebra diagnostics.

This is not a theorem prover. Universal equivalence is proved in the paper;
the separate Lean files check explicitly conditional logical kernels.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    label: str = ""
    children: tuple["Node", ...] = ()

    def data(self):
        return {"kind": self.kind, "label": self.label,
                "children": [c.data() for c in self.children]}


def var(name):
    return Node("variable", name)


def app(name, *args):
    return Node("application", name, tuple(args))


def form(kind, *args, label=""):
    return Node(kind, label, tuple(args))


def eq(a, b):
    return form("equality", a, b)


def imp(a, b):
    return form("implication", a, b)


def all_(name, body):
    return form("forall", body, label=name)


ZERO = Node("constant", "0")
BOTTOM = Node("falsehood", "false")
N = var("n")
S = lambda t: app("S", t)
ONE = S(ZERO)
P = lambda t: app("P", t, ZERO)
SEP = imp(eq(ZERO, ONE), BOTTOM)


def close(params, body):
    for p in reversed(params):
        body = all_(p.label, body)
    return body


def uniqueness(m, *, new, unary, fixed=None, separated=False):
    params = tuple(var(f"a{i}") for i in range(m))
    f = lambda n: app("f", n, *params)
    old_input = S(N) if not new else N
    if fixed == "successor":
        updated = S(f(old_input))
    elif fixed == "predecessor":
        updated = P(f(old_input))
    elif unary:
        updated = app("h", f(old_input))
    else:
        updated = app("h", N, f(old_input))
    premise = all_("n", eq(f(S(old_input)), updated))
    index = S(P(N)) if new else P(N)
    seed = f(ZERO) if new else f(ONE)
    positive = all_("n", form("or", eq(N, ZERO),
                             eq(f(N), app("I_h", index, seed))))
    result = positive if separated else form("and", SEP, positive)
    schema = close(params, imp(premise, result))
    return (SEP, schema) if separated else (schema,)


def tally(tree):
    out = Counter({tree.kind: 1})
    for child in tree.children:
        out.update(tally(child))
    return out


def metrics(trees):
    c = Counter()
    for t in trees:
        c.update(tally(t))
    return {"nodes": sum(c.values()), "equalities": c["equality"],
            "templates": len(trees), "by_kind": dict(sorted(c.items()))}


def formula_report():
    rows = []
    for m in range(5):
        for unary in (False, True):
            for new in (False, True):
                for separated in (False, True):
                    trees = uniqueness(m, new=new, unary=unary,
                                       separated=separated)
                    got = metrics(trees)
                    expected = 34 + 5*m - int(unary) - 2*int(new)
                    expected -= int(separated)
                    assert got["nodes"] == expected
                    assert got["equalities"] == 4
                    rows.append({"fixed_parameters": m,
                                 "update": "unary" if unary else "counter_state",
                                 "origin": "zero" if new else "positive_tail",
                                 "separation": "separate" if separated else "packed",
                                 **got})
    a = var("a")
    d0 = all_("a", eq(app("I_h", ZERO, a), a))
    ds = all_("n", all_("a", eq(app("I_h", S(N), a),
                      app("h", N, app("I_h", N, a)))))
    assert metrics((d0,))["nodes"] == 6
    assert metrics((ds,))["nodes"] == 12
    shift = all_("n", all_("a", eq(app("M", S(N), S(a)), app("M", N, a))))
    assert metrics((shift,))["nodes"] == 11
    ps = uniqueness(1, new=True, unary=True, fixed="successor")
    pp = uniqueness(1, new=True, unary=True, fixed="predecessor")
    assert metrics(ps)["nodes"] == 36
    assert metrics(pp)["nodes"] == 37
    assert metrics(ps + (shift,))["nodes"] == 47
    old = uniqueness(1, new=False, unary=False)
    new = uniqueness(1, new=True, unary=False)
    assert metrics(old + (d0, ds))["nodes"] == 57
    assert metrics(new + (d0, ds))["nodes"] == 55
    return {
        "metric": "One node per variable, constant, function application, equality, "
                  "connective, falsehood and single-variable quantifier. "
                  "1=S(0), p(t)=P(t,0). Iterator descriptions belong to symbol names. "
                  "Schematic calls count their arguments, not arbitrary substituted bodies.",
        "scope": "Display counts only. A zero-parameter count does not claim completeness.",
        "rows": rows,
        "binary_computation": {"base": metrics((d0,)), "step": metrics((ds,))},
        "one_parameter_totals": {"old_binary": metrics(old + (d0, ds)),
                                 "new_binary": metrics(new + (d0, ds)),
                                 "successor_plus_shift": metrics(ps + (shift,))},
        "new_binary_tree": new[0].data(),
        "old_binary_tree": old[0].data(),
    }


def diagnostics():
    """Finite checks for argument orientation and explicit witnesses."""
    count = Counter()
    m = lambda n, a: max(a - n, 0)
    for k in range(65):
        for x in range(65):
            assert m(k, x + k) == x
            assert max(m(k, x + 1 + k) - 1, 0) == m(k, x + k)
            assert m(k, x + 1 + k) != 0
            assert m(k + 1, x + 1) == m(k, x)
            count["cancellation_and_shift_pairs"] += 1
    for a in range(40):
        for b in range(40):
            phi = 0
            j0 = lambda x, y: x + max(y - x, 0)
            j1 = lambda x, y: y + max(x - y, 0)
            for n in range(a + b + 1):
                x, y = m(n, a), m(n, b)
                assert j0(x, y) + phi == j0(a, b)
                assert j1(x, y) + phi == j1(a, b)
                if n < a + b:
                    phi += int(x + y != 0)
                count["descent_prefix_instances"] += 1
            assert phi == max(a, b)
    point = (0, 1)
    clamped = tuple(max(t - 1, 0) + 1 for t in point)
    assert point != (0, 0) and point != clamped
    return {"counts": dict(count),
            "product_witness": {"n": point, "S_pred_n": clamped},
            "scope": "Bounded standard-natural diagnostics, not universal proofs."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--tsv", type=Path)
    args = parser.parse_args()
    report = {"status": "passed", "formulas": formula_report(),
              "numerical_diagnostics": diagnostics(),
              "not_certified": ["full first-order derivability", "absolute minimality",
                                "historical novelty", "finite-description membership"]}
    if args.output:
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    else:
        print(json.dumps(report, indent=2))
    if args.tsv:
        fields = ("fixed_parameters", "update", "origin", "separation",
                  "nodes", "equalities", "templates")
        lines = ["\t".join(fields)]
        lines.extend("\t".join(str(row[k]) for k in fields)
                     for row in report["formulas"]["rows"])
        args.tsv.write_text("\n".join(lines) + "\n")
    if args.output:
        print("PASS: binary arithmetic 39 -> 37; binary total 57 -> 55;")
        print("      full-language unary arithmetic 38 -> 36.")
        print("PASS: finite cancellation, shift, descent, and product diagnostics.")


if __name__ == "__main__":
    main()
