PRA: exact-commit review and a binary-relational presentation

Read report.pdf; report.tex is its editable source.

Conclusion: a fully specified binary-relation presentation is bi-interpretable
with PRA, separately in classical and intuitionistic first-order logic.
This improves maximum relation arity, not total axiom length. No global
'simplest theory' claim is made. The 52-node arithmetic drafts remain the
practical short arithmetic recommendation. The report proves a restricted
unary-relational impossibility result.

Build PDF on a normal TeX Live installation with amsmath, amssymb, amsthm,
geometry, hyperref, booktabs, longtable, microtype, xurl and Latin Modern fonts:
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
The supplied PDF was rendered and all eight pages visually inspected.

Replay (Python 3 standard library only):
  python3 artifacts/verify_manifest.py
  python3 artifacts/checks.py
Expected diagnostics are in artifacts/results.json. The finite checks take
roughly a minute, depending on hardware. They are not a formal proof.

sources/ contains all thirteen original archives added in requested commit
5a840e8c09e7257d9e17e292f4c7902f8bd43977, exact commit metadata, source blob
manifest and separately captured current drafts inventory. All thirteen
archive Git blob hashes have been verified. Source ZIPs preserve their
upstream filenames and authorship. Their original reports and proof sources
are evidence/dependencies; their formal certificates do not verify the new
graph construction.

MANIFEST.sha256 covers every delivered file except itself. Build products
will change manifest validity; replay integrity checks before rebuilding.
