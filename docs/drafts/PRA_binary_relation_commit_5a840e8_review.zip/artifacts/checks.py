#!/usr/bin/env python3
"""Finite diagnostics, not a proof of first-order bi-interpretability."""
import itertools,json,hashlib,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def encode(n,R):
    markers=[(i,0,0,0,0) for i in range(6)]
    objects=[(6,x,0,0,0) for x in range(n)]
    tuples=[(7,*a) for a in sorted(R)]
    roles=[(8+i,*a) for a in sorted(R) for i in range(4)]
    V=set(markers+objects+tuples+roles)
    E={(markers[i],markers[j]) for i in range(6) for j in range(i,6)}
    E|={(o,markers[0]) for o in objects}
    E|={(t,markers[1]) for t in tuples}
    for a in R:
        t=(7,*a)
        for i in range(4):
            v=(8+i,*a);E|={(v,markers[2+i]),(t,v),(v,objects[a[i]])}
    return V,E

def decode(V,E):
    loops={v for v in V if (v,v) in E}
    assert len(loops)==6
    M=sorted(loops,key=lambda v:sum((u,v) in E for u in loops))
    assert all(((M[i],M[j]) in E)==(i<=j) for i in range(6) for j in range(6))
    sorts=[{v for v in V-loops if (v,M[i]) in E} for i in range(6)]
    assert set.union(*sorts)==V-loops and sum(map(len,sorts))==len(V-loops)
    O,T,*S=sorts
    assert O
    vals={}
    for t in T:
        row=[]
        for i in range(4):
            slots={v for v in S[i] if (t,v) in E};assert len(slots)==1
            v=next(iter(slots));assert {u for u in T if (u,v) in E}=={t}
            targets={o for o in O if (v,o) in E};assert len(targets)==1
            row.append(next(iter(targets)))
        vals[t]=tuple(row)
    assert len(set(vals.values()))==len(T)
    assert all(any((t,v) in E for t in T) for Si in S for v in Si)
    allowed={(M[i],M[j]) for i in range(6) for j in range(i,6)}
    allowed|={(v,M[i]) for i in range(6) for v in sorts[i]}
    allowed|={(t,v) for t in T for Si in S for v in Si if (t,v) in E}
    allowed|={(v,o) for Si in S for v in Si for o in O if (v,o) in E}
    assert E==allowed
    return {tuple(o[1] for o in a) for a in vals.values()}

def main():
    tests=0
    for n in [1,2]:
        rows=list(itertools.product(range(n),repeat=4))
        for mask in range(1<<len(rows)):
            R={a for i,a in enumerate(rows) if mask>>i&1}
            V,E=encode(n,R);assert decode(V,E)==R;tests+=1
    V,E=encode(1,{(0,0,0,0)})
    failures=0
    for bad in [E|{((6,0,0,0,0),(6,0,0,0,0))},E-{((7,0,0,0,0),(8,0,0,0,0))}]:
        try:decode(V,bad)
        except AssertionError:failures+=1
    assert failures==2
    manifest=json.loads((ROOT/'sources'/'archive_manifest.json').read_text())
    # Verify requested commit blob identities directly from authoritative commit metadata.
    commit=json.loads((ROOT/'sources'/'commit.json').read_text())
    blobs=0
    for f in commit['files']:
        p=ROOT/'sources'/pathlib.Path(f['filename']).name
        b=p.read_bytes(); actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        assert actual==f['sha'];blobs+=1
    print(json.dumps({'finite_graph_roundtrips':tests,'negative_controls':failures,'source_blobs':blobs,'status':'PASS'},indent=2))
if __name__=='__main__':main()
