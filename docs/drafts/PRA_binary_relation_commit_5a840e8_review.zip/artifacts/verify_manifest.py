#!/usr/bin/env python3
"""Verify all sealed archive files using only Python's standard library."""
import hashlib,pathlib
root=pathlib.Path(__file__).resolve().parents[1]
count=0
for line in (root/'MANIFEST.sha256').read_text().splitlines():
    digest,name=line.split('  ',1)
    p=root/name
    assert p.is_file(),name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
    count+=1
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
expected={line.split('  ',1)[1] for line in (root/'MANIFEST.sha256').read_text().splitlines()}|{'MANIFEST.sha256'}
assert actual==expected,(actual-expected,expected-actual)
print(f'PASS: {count} file digests; exact archive inventory')
