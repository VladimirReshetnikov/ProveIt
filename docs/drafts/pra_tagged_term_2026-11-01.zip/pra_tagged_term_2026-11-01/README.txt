PRA FROM ONE TAGGED TERM
Research prepared for Vladimir Reshetnikov, 1 November 2026.

START HERE
  report.pdf       Complete mathematical report and proofs.
  report.tex       Main LaTeX source (sections/ contains included sources).
  AXIOMS.txt       Exact standalone nonlogical specification.

RESULT
One uniform axiom constructor takes one arbitrary term t(n,a,b), compares
its b=0 and b=1 specializations, and derives its associated computation
laws. The tag disappears before an axiom is emitted. There is no added
diagonal axiom. The emitted axioms have two individual names and one
frozen numerical parameter in the original scalar binary-iterator language.

The new theory is same-language deductively equivalent to the previous
short-propagation basis. Both are definitionally equivalent, hence
bi-interpretable and equiconsistent, with first-order PRA in the matching
classical or intuitionistic logic. The report proves both identity round
trips internally, including scalar pairing and the PR compiler.

SCOPE OF IMPROVEMENT
The single input gains a third syntactic slot. This is an explicit tradeoff,
not a claim of an absolute minimum or that all emitted formulas are shorter.
A separate two-term version uniformly saves exactly five active AST nodes
from every instance of the previous one-schema draft.

REPRODUCE
  python3 build.py
Requires Python 3 and pdflatex with the standard packages named in report.tex.
The build runs the syntax checks and three LaTeX passes.

  python3 build.py --lean /path/to/lean
Also checks formal/TaggedKernel.lean using that compiler. The recorded
verification used Lean 4.19.0; no mathlib dependency is needed.

  python3 checks/check_schema.py --out checks
Runs the syntax/counting diagnostics alone.

VERIFICATION BOUNDARY
The Lean file checks the NEW reduction with actual finite term syntax,
for an arbitrary interpreted carrier. It checks extraction, both seeds,
the raw selector, j(n)=n, full two-term propagation, and the converse.
All 13 audited declarations have empty axiom-dependency lists.
The inherited arithmetic/pairing/bi-interpretation calibration remains
a written proof, independently reviewed. See formal/SCOPE.txt.

CONTENTS
  formal/          Lean kernel, pinned version, output, scope, and review.
  checks/          Reproducible syntax program, exact counts, examples.
  audit/           Source provenance, mathematical review, build/PDF checks.
  SHA256SUMS.txt   Integrity hashes for the final archive contents.

SOURCE COMPARISON
All three current archives in ProveIt/docs/drafts were reviewed at commit
efc26dac89ba0b9e425995f305d7ac4534796e90. Their Git identities and downloaded
SHA-256 hashes are recorded in audit/source_manifest.json.
The scalar arithmetic calibration is inherited from these drafts and is
explicitly attributed. The tagged reduction and shortened merged constructor
are the new results here. The report includes Further research questions.
