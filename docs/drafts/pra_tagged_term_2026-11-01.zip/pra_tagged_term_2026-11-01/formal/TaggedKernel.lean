/-
A single tagged term: constructive compression kernel for PRA.
Lean 4.19.0, core library only.

The theorem tagged_iff_basis checks the NEW reduction in the actual finite
term syntax, for any carrier and interpretation of the delayed symbols.
It does not formalize the inherited arithmetic/pairing/PRA calibration.
There are no postulated axioms, classical reasoning, or admitted proofs.
-/

namespace TaggedPRA

universe u

inductive Unary where
  | var : Unary
  | zero : Unary
  | succ : Unary → Unary
  | delay : Unary → Unary → Unary → Unary
  deriving Repr

/- The stored descriptor is a Unary tree, not an active argument. -/
inductive Term (V : Type) where
  | var : V → Term V
  | zero : Term V
  | succ : Term V → Term V
  | delay : Unary → Term V → Term V → Term V
  deriving Repr

inductive V2 where | n | a
inductive V3 where | n | a | b

abbrev T2 := Term V2
abbrev T3 := Term V3

def oneBody : Unary := .succ .zero
def succBody : Unary := .succ .var

def evalUnary {A : Type u} (zero : A) (succ : A → A)
    (D : Unary → A → A → A) : Unary → A → A
  | .var, v => v
  | .zero, _ => zero
  | .succ t, v => succ (evalUnary zero succ D t v)
  | .delay h s t, v =>
      D h (evalUnary zero succ D s v) (evalUnary zero succ D t v)

def eval {A : Type u} {V : Type} (zero : A) (succ : A → A)
    (D : Unary → A → A → A) : Term V → (V → A) → A
  | .var v, rho => rho v
  | .zero, _ => zero
  | .succ t, rho => succ (eval zero succ D t rho)
  | .delay h s t, rho => D h (eval zero succ D s rho) (eval zero succ D t rho)

def env2 {A : Type u} (n a : A) : V2 → A
  | .n => n
  | .a => a

def env3 {A : Type u} (n a b : A) : V3 → A
  | .n => n
  | .a => a
  | .b => b

def eval2 {A : Type u} (zero : A) (succ : A → A)
    (D : Unary → A → A → A) (t : T2) (n a : A) : A :=
  eval zero succ D t (env2 n a)

def eval3 {A : Type u} (zero : A) (succ : A → A)
    (D : Unary → A → A → A) (t : T3) (n a b : A) : A :=
  eval zero succ D t (env3 n a b)

/- Every old stored descriptor h remains literally unchanged. -/
def instantiate {V : Type} (x : Term V) : Unary → Term V
  | .var => x
  | .zero => .zero
  | .succ t => .succ (instantiate x t)
  | .delay h s t => .delay h (instantiate x s) (instantiate x t)

def diagonal : T3 → Unary
  | .var .n => .var
  | .var .a => .var
  | .var .b => .zero
  | .zero => .zero
  | .succ t => .succ (diagonal t)
  | .delay h s t => .delay h (diagonal s) (diagonal t)

def liftUnary (h : Unary) : T3 := instantiate (.var .n) h

def embed : T2 → T3
  | .var .n => .var .n
  | .var .a => .var .a
  | .zero => .zero
  | .succ t => .succ (embed t)
  | .delay h s t => .delay h (embed s) (embed t)

/- Replace the tag by a two-variable term; n and a are preserved. -/
def endpoint (tag : T2) : T3 → T2
  | .var .n => .var .n
  | .var .a => .var .a
  | .var .b => tag
  | .zero => .zero
  | .succ t => .succ (endpoint tag t)
  | .delay h s t => .delay h (endpoint tag s) (endpoint tag t)

theorem diagonal_lift (h : Unary) : diagonal (liftUnary h) = h := by
  induction h with
  | var => rfl
  | zero => rfl
  | succ t ih => exact congrArg Unary.succ ih
  | delay h s t _ ihs iht =>
      change Unary.delay h (diagonal (liftUnary s)) (diagonal (liftUnary t)) =
        Unary.delay h s t
      rw [ihs, iht]

theorem eval_instantiate {A : Type u} {V : Type}
    (zero : A) (succ : A → A) (D : Unary → A → A → A)
    (x : Term V) (rho : V → A) (h : Unary) :
    eval zero succ D (instantiate x h) rho =
      evalUnary zero succ D h (eval zero succ D x rho) := by
  induction h with
  | var => rfl
  | zero => rfl
  | succ t ih => exact congrArg succ ih
  | delay h s t _ ihs iht =>
      change D h (eval zero succ D (instantiate x s) rho)
          (eval zero succ D (instantiate x t) rho) =
        D h (evalUnary zero succ D s (eval zero succ D x rho))
          (evalUnary zero succ D t (eval zero succ D x rho))
      rw [ihs, iht]

theorem eval_lift {A : Type u}
    (zero : A) (succ : A → A) (D : Unary → A → A → A)
    (h : Unary) (n a b : A) :
    eval3 zero succ D (liftUnary h) n a b = evalUnary zero succ D h n := by
  exact eval_instantiate zero succ D (.var V3.n) (env3 n a b) h

theorem eval_embed {A : Type u}
    (zero : A) (succ : A → A) (D : Unary → A → A → A)
    (t : T2) (n a b : A) :
    eval3 zero succ D (embed t) n a b = eval2 zero succ D t n a := by
  induction t with
  | var v => cases v <;> rfl
  | zero => rfl
  | succ t ih => exact congrArg succ ih
  | delay h s t ihs iht =>
      change D h (eval3 zero succ D (embed s) n a b)
          (eval3 zero succ D (embed t) n a b) =
        D h (eval2 zero succ D s n a) (eval2 zero succ D t n a)
      rw [ihs, iht]

theorem eval_endpoint {A : Type u}
    (zero : A) (succ : A → A) (D : Unary → A → A → A)
    (tag : T2) (t : T3) (n a : A) :
    eval2 zero succ D (endpoint tag t) n a =
      eval3 zero succ D t n a (eval2 zero succ D tag n a) := by
  induction t with
  | var v => cases v <;> rfl
  | zero => rfl
  | succ t ih => exact congrArg succ ih
  | delay h s t ihs iht =>
      change D h (eval2 zero succ D (endpoint tag s) n a)
          (eval2 zero succ D (endpoint tag t) n a) =
        D h (eval3 zero succ D s n a (eval2 zero succ D tag n a))
          (eval3 zero succ D t n a (eval2 zero succ D tag n a))
      rw [ihs, iht]

section Main

variable {A : Type u} (zero : A) (succ : A → A) (D : Unary → A → A → A)

def Computation (h : Unary) (n a : A) : Prop :=
  zero ≠ succ zero ∧
    (D h (D oneBody n zero) a = a ∧
     D h (succ (succ n)) a = evalUnary zero succ D h (D h (succ n) a))

def AllComputation : Prop := ∀ h n a, Computation zero succ D h n a

def EndEq (t : T3) (n a : A) : Prop :=
  eval3 zero succ D t n a zero = eval3 zero succ D t n a (succ zero)

def Rooted (t : T3) (n a : A) : Prop := n = zero ∨ EndEq zero succ D t n a

def Tagged : Prop :=
  ∀ t a,
    (∀ n, Rooted zero succ D t n a → EndEq zero succ D t (succ n) a) →
    ∀ n, Rooted zero succ D t n a ∧ Computation zero succ D (diagonal t) n a

def ShortPropagation : Prop :=
  ∀ s t a,
    (∀ n, (n = zero ∨ eval2 zero succ D s n a = eval2 zero succ D t n a) →
       eval2 zero succ D s (succ n) a = eval2 zero succ D t (succ n) a) →
    ∀ n, n = zero ∨ eval2 zero succ D s n a = eval2 zero succ D t n a

theorem tagged_to_computation (ht : Tagged zero succ D) :
    AllComputation zero succ D := by
  intro h n a
  have he : ∀ k, EndEq zero succ D (liftUnary h) k a := by
    intro k
    unfold EndEq
    rw [eval_lift, eval_lift]
  have hp : ∀ k, Rooted zero succ D (liftUnary h) k a →
      EndEq zero succ D (liftUnary h) (succ k) a := by
    intro k _
    exact he (succ k)
  have hc := (ht (liftUnary h) a hp n).2
  rw [diagonal_lift] at hc
  exact hc

theorem seed_one (hc : AllComputation zero succ D) :
    ∀ h a, D h (succ zero) a = a := by
  intro h a
  have hq : D oneBody (succ (succ zero)) zero = succ zero := by
    simpa [oneBody, evalUnary] using (hc oneBody zero zero).2.2
  have hr := (hc h (succ (succ zero)) a).2.1
  rw [hq] at hr
  exact hr

theorem seed_zero (hc : AllComputation zero succ D) :
    ∀ h a, D h zero a = a := by
  intro h a
  have hq : D oneBody (succ zero) zero = zero :=
    seed_one zero succ D hc oneBody zero
  have hr := (hc h (succ zero) a).2.1
  rw [hq] at hr
  exact hr

def zOp (r x : A) : A := D .zero (succ r) x
def addOp (x y : A) : A := D succBody (succ y) x
def jOp (y : A) : A := addOp succ D zero y
def selectOp (r x y : A) : A :=
  addOp succ D (zOp succ D r x) (zOp succ D (zOp succ D r (succ zero)) y)

theorem z_zero (hc : AllComputation zero succ D) (x : A) :
    zOp succ D zero x = x := seed_one zero succ D hc .zero x

theorem z_succ (hc : AllComputation zero succ D) (r x : A) :
    zOp succ D (succ r) x = zero := by
  simpa [zOp, evalUnary] using (hc .zero r x).2.2

theorem add_zero (hc : AllComputation zero succ D) (x : A) :
    addOp succ D x zero = x := seed_one zero succ D hc succBody x

theorem j_zero (hc : AllComputation zero succ D) :
    jOp zero succ D zero = zero := add_zero zero succ D hc zero

theorem j_succ (hc : AllComputation zero succ D) (n : A) :
    jOp zero succ D (succ n) = succ (jOp zero succ D n) := by
  simpa [jOp, addOp, succBody, evalUnary] using (hc succBody n zero).2.2

theorem select_zero_raw (hc : AllComputation zero succ D) (x y : A) :
    selectOp zero succ D zero x y = x := by
  unfold selectOp
  rw [z_zero zero succ D hc x, z_zero zero succ D hc (succ zero),
      z_succ zero succ D hc zero y, add_zero zero succ D hc x]

theorem select_one_raw (hc : AllComputation zero succ D) (x y : A) :
    selectOp zero succ D (succ zero) x y = jOp zero succ D y := by
  unfold selectOp
  rw [z_succ zero succ D hc zero x, z_succ zero succ D hc zero (succ zero),
      z_zero zero succ D hc y]
  rfl

/- Syntax constructors for the raw selector; these add no primitive symbols. -/
def zTerm {V : Type} (r x : Term V) : Term V := .delay .zero (.succ r) x
def addTerm {V : Type} (x y : Term V) : Term V := .delay succBody (.succ y) x
def selectTerm {V : Type} (r x y : Term V) : Term V :=
  addTerm (zTerm r x) (zTerm (zTerm r (.succ .zero)) y)

def bootTerm : T3 := selectTerm (.var .b) (.var .n) (.var .n)

theorem boot_eq (hc : AllComputation zero succ D) (n a : A) :
    EndEq zero succ D bootTerm n a ↔ n = jOp zero succ D n := by
  change selectOp zero succ D zero n n = selectOp zero succ D (succ zero) n n ↔ _
  rw [select_zero_raw zero succ D hc n n, select_one_raw zero succ D hc n n]

theorem tagged_j_identity (ht : Tagged zero succ D) :
    ∀ n, jOp zero succ D n = n := by
  have hc := tagged_to_computation zero succ D ht
  have resolve : ∀ n, Rooted zero succ D bootTerm n zero →
      n = jOp zero succ D n := by
    intro n hn
    cases hn with
    | inl hz =>
        subst n
        exact (j_zero zero succ D hc).symm
    | inr he => exact (boot_eq zero succ D hc n zero).mp he
  have hp : ∀ n, Rooted zero succ D bootTerm n zero →
      EndEq zero succ D bootTerm (succ n) zero := by
    intro n hn
    apply (boot_eq zero succ D hc (succ n) zero).mpr
    calc
      succ n = succ (jOp zero succ D n) := congrArg succ (resolve n hn)
      _ = jOp zero succ D (succ n) := (j_succ zero succ D hc n).symm
  intro n
  exact (resolve n (ht bootTerm zero hp n).1).symm

theorem select_one (ht : Tagged zero succ D) (x y : A) :
    selectOp zero succ D (succ zero) x y = y := by
  calc
    selectOp zero succ D (succ zero) x y = jOp zero succ D y :=
      select_one_raw zero succ D (tagged_to_computation zero succ D ht) x y
    _ = y := tagged_j_identity zero succ D ht y

def encodePair (s t : T2) : T3 := selectTerm (.var .b) (embed s) (embed t)

theorem encode_pair_eq (ht : Tagged zero succ D) (s t : T2) (n a : A) :
    EndEq zero succ D (encodePair s t) n a ↔
      eval2 zero succ D s n a = eval2 zero succ D t n a := by
  change selectOp zero succ D zero
      (eval3 zero succ D (embed s) n a zero)
      (eval3 zero succ D (embed t) n a zero) =
    selectOp zero succ D (succ zero)
      (eval3 zero succ D (embed s) n a (succ zero))
      (eval3 zero succ D (embed t) n a (succ zero)) ↔ _
  rw [eval_embed, eval_embed, eval_embed, eval_embed]
  rw [select_zero_raw zero succ D (tagged_to_computation zero succ D ht),
      select_one zero succ D ht]

theorem tagged_to_short (ht : Tagged zero succ D) :
    ShortPropagation zero succ D := by
  intro s t a hp n
  have transfer : ∀ k, Rooted zero succ D (encodePair s t) k a →
      k = zero ∨ eval2 zero succ D s k a = eval2 zero succ D t k a := by
    intro k hk
    cases hk with
    | inl hz => exact Or.inl hz
    | inr he => exact Or.inr ((encode_pair_eq zero succ D ht s t k a).mp he)
  have progress : ∀ k, Rooted zero succ D (encodePair s t) k a →
      EndEq zero succ D (encodePair s t) (succ k) a := by
    intro k hk
    exact (encode_pair_eq zero succ D ht s t (succ k) a).mpr (hp k (transfer k hk))
  exact transfer n (ht (encodePair s t) a progress n).1

theorem endpoint_eq (t : T3) (n a : A) :
    eval2 zero succ D (endpoint .zero t) n a =
      eval2 zero succ D (endpoint (.succ .zero) t) n a ↔ EndEq zero succ D t n a := by
  rw [eval_endpoint, eval_endpoint]
  rfl

theorem basis_to_tagged (hc : AllComputation zero succ D)
    (hs : ShortPropagation zero succ D) : Tagged zero succ D := by
  intro t a hp n
  have progress : ∀ k,
      (k = zero ∨ eval2 zero succ D (endpoint .zero t) k a =
        eval2 zero succ D (endpoint (.succ .zero) t) k a) →
      eval2 zero succ D (endpoint .zero t) (succ k) a =
        eval2 zero succ D (endpoint (.succ .zero) t) (succ k) a := by
    intro k hk
    apply (endpoint_eq zero succ D t (succ k) a).mpr
    apply hp k
    cases hk with
    | inl hz => exact Or.inl hz
    | inr he => exact Or.inr ((endpoint_eq zero succ D t k a).mp he)
  have hn := hs (endpoint .zero t) (endpoint (.succ .zero) t) a progress n
  constructor
  · cases hn with
    | inl hz => exact Or.inl hz
    | inr he => exact Or.inr ((endpoint_eq zero succ D t n a).mp he)
  · exact hc (diagonal t) n a

theorem tagged_iff_basis :
    Tagged zero succ D ↔ AllComputation zero succ D ∧ ShortPropagation zero succ D := by
  constructor
  · intro ht
    exact ⟨tagged_to_computation zero succ D ht, tagged_to_short zero succ D ht⟩
  · intro hb
    exact basis_to_tagged zero succ D hb.1 hb.2

end Main

#print axioms diagonal_lift
#print axioms eval_instantiate
#print axioms eval_endpoint
#print axioms tagged_to_computation
#print axioms seed_one
#print axioms seed_zero
#print axioms select_zero_raw
#print axioms select_one_raw
#print axioms tagged_j_identity
#print axioms encode_pair_eq
#print axioms tagged_to_short
#print axioms basis_to_tagged
#print axioms tagged_iff_basis

end TaggedPRA
