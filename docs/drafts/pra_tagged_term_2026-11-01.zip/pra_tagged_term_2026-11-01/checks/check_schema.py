#!/usr/bin/env python3
"""Check the tagged one-term PRA schema and reproduce its exact syntax ledger.

Python 3.10+; standard library only. Run from the archive root with

    python3 checks/check_schema.py --out checks

The outputs are schema_checks.json and schema_examples.txt. This program
checks finite syntax, descriptor staging, active substitution, and exact node
counts. It does NOT prove arithmetic adequacy, consistency, or the written
bi-interpretation theorem. In particular, a test on these finitely many
examples is not a verification of an infinite axiom schema.

Each variable, constant, active function application, equality, connective,
and quantifier counts as one active AST node. Negation is implication to
bottom. A D_h head counts as one node; its stored body is frozen syntax, not
an active argument. Two additional ledgers charge descriptor bodies: once
per distinct symbol, and as a recursively expanded tree at every use. Neither
ledger pretends to specify the bit cost of a binary encoding of symbol names.

The comparison formula for the prior one-schema draft is transcribed from
AXIOMS.txt in pra_one_schema_2026-11-01.zip, at ProveIt commit
efc26dac89ba0b9e425995f305d7ac4534796e90. No prior checker is imported.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping


@dataclass(frozen=True)
class Descriptor:
    """A stored unary body. Legal bodies have only v free and are well-founded."""

    body: Term


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple[Term, ...] = ()
    name: str = ""
    descriptor: Descriptor | None = None


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")
N, A, B, V = (var(x) for x in ("n", "a", "b", "v"))


def succ(t: Term) -> Term:
    return Term("succ", (t,))


ONE = succ(ZERO)


def active_free_vars(t: Term) -> set[str]:
    """Stored bodies are opaque to active-variable operations."""
    if t.tag == "var":
        return {t.name}
    return set().union(*(active_free_vars(arg) for arg in t.args))


def validate_term(t: Term, ancestors: frozenset[int] = frozenset()) -> None:
    """Reject malformed, cyclic, or externally parameterized descriptions."""
    if id(t) in ancestors:
        raise ValueError("cyclic active term or descriptor dependency")
    ancestors = ancestors | {id(t)}
    arities = {"var": 0, "zero": 0, "succ": 1, "delay": 2}
    if t.tag not in arities or len(t.args) != arities[t.tag]:
        raise ValueError("malformed term constructor or arity")
    if t.tag == "var" and not t.name:
        raise ValueError("unnamed variable")
    if t.tag != "var" and t.name:
        raise ValueError("name on a nonvariable term")
    if t.tag == "delay":
        if t.descriptor is None:
            raise ValueError("delayed symbol without a descriptor")
        if id(t.descriptor) in ancestors:
            raise ValueError("cyclic descriptor")
        validate_term(t.descriptor.body, ancestors | {id(t.descriptor)})
        if active_free_vars(t.descriptor.body) - {"v"}:
            raise ValueError("stored descriptor has an external free parameter")
    elif t.descriptor is not None:
        raise ValueError("descriptor on a non-delayed term")
    for arg in t.args:
        validate_term(arg, ancestors)


def delay(body: Term, count: Term, seed: Term) -> Term:
    validate_term(body)
    if active_free_vars(body) - {"v"}:
        raise ValueError("stored descriptor has an external free parameter")
    return Term("delay", (count, seed), descriptor=Descriptor(body))


def substitute(t: Term, mapping: Mapping[str, Term]) -> Term:
    """Simultaneous active substitution. The Descriptor object stays frozen."""
    if t.tag == "var":
        return mapping.get(t.name, t)
    return Term(t.tag, tuple(substitute(arg, mapping) for arg in t.args),
                t.name, t.descriptor)


def dependency_rank(t: Term) -> int:
    """Highest delayed-symbol rank; base terms have rank zero."""
    values = [dependency_rank(arg) for arg in t.args]
    if t.descriptor is not None:
        values.append(1 + dependency_rank(t.descriptor.body))
    return max(values, default=0)


def term_size(t: Term, *, expand_descriptors: bool = False) -> int:
    size = 1 + sum(term_size(arg, expand_descriptors=expand_descriptors)
                   for arg in t.args)
    if expand_descriptors and t.descriptor is not None:
        size += term_size(t.descriptor.body, expand_descriptors=True)
    return size


def occurrences(t: Term, name: str) -> int:
    return int(t.tag == "var" and t.name == name) + sum(
        occurrences(arg, name) for arg in t.args)


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple[Formula, ...] = ()
    terms: tuple[Term, ...] = ()
    binder: str = ""


BOTTOM = Formula("bottom")


def eq(s: Term, t: Term) -> Formula:
    return Formula("eq", terms=(s, t))


def conj(p: Formula, q: Formula) -> Formula:
    return Formula("and", (p, q))


def disj(p: Formula, q: Formula) -> Formula:
    return Formula("or", (p, q))


def implies(p: Formula, q: Formula) -> Formula:
    return Formula("imp", (p, q))


def all_(name: str, p: Formula) -> Formula:
    return Formula("all", (p,), binder=name)


def formula_free_vars(f: Formula) -> set[str]:
    names = set().union(*(active_free_vars(t) for t in f.terms),
                        *(formula_free_vars(c) for c in f.children))
    return names - {f.binder} if f.tag == "all" else names


def active_names(f: Formula) -> set[str]:
    names = set().union(*(active_free_vars(t) for t in f.terms),
                        *(active_names(c) for c in f.children))
    return names | {f.binder} if f.tag == "all" else names


def substitute_formula(f: Formula, mapping: Mapping[str, Term]) -> Formula:
    """Capture-avoiding free substitution, including alpha-renaming if needed."""
    if f.tag == "all":
        binder, body = f.binder, f.children[0]
        relevant = {name: term for name, term in mapping.items()
                    if name != binder and name in formula_free_vars(body)}
        replacement_names = set().union(
            *(active_free_vars(term) for term in relevant.values()))
        if binder in replacement_names:
            forbidden = active_names(body) | replacement_names | set(relevant)
            i = 0
            while f"fresh{i}" in forbidden:
                i += 1
            fresh = f"fresh{i}"
            body = substitute_formula(body, {binder: var(fresh)})
            binder = fresh
        return all_(binder, substitute_formula(body, relevant))
    return Formula(f.tag,
                   tuple(substitute_formula(c, mapping) for c in f.children),
                   tuple(substitute(t, mapping) for t in f.terms), f.binder)


def validate_formula(f: Formula) -> None:
    if f.tag == "bottom":
        valid_shape = not f.children and not f.terms and not f.binder
    elif f.tag == "eq":
        valid_shape = not f.children and len(f.terms) == 2 and not f.binder
    elif f.tag in {"and", "or", "imp"}:
        valid_shape = len(f.children) == 2 and not f.terms and not f.binder
    elif f.tag == "all":
        valid_shape = len(f.children) == 1 and not f.terms and bool(f.binder)
    else:
        valid_shape = False
    if not valid_shape:
        raise ValueError("malformed formula")
    for t in f.terms:
        validate_term(t)
    for c in f.children:
        validate_formula(c)


def formula_size(f: Formula, *, expand_descriptors: bool = False) -> int:
    return 1 + sum(formula_size(c, expand_descriptors=expand_descriptors)
                   for c in f.children) + sum(
        term_size(t, expand_descriptors=expand_descriptors) for t in f.terms)


def quantifier_count(f: Formula) -> int:
    return int(f.tag == "all") + sum(quantifier_count(c) for c in f.children)


def quantifier_depth(f: Formula) -> int:
    return int(f.tag == "all") + max(
        (quantifier_depth(c) for c in f.children), default=0)


def has_shadowing(f: Formula, bound: frozenset[str] = frozenset()) -> bool:
    if f.tag == "all":
        return f.binder in bound or has_shadowing(
            f.children[0], bound | {f.binder})
    return any(has_shadowing(c, bound) for c in f.children)


SIGMA = implies(eq(ZERO, ONE), BOTTOM)


def computation(h: Term) -> Formula:
    reset = eq(delay(h, delay(ONE, N, ZERO), A), A)
    tail = eq(delay(h, succ(succ(N)), A),
              substitute(h, {"v": delay(h, succ(N), A)}))
    return conj(SIGMA, conj(reset, tail))


def rooted(equation: Formula) -> Formula:
    return disj(eq(N, ZERO), equation)


def short_pair(s: Term, u: Term) -> Formula:
    """The prior transparent short-propagation instance, without computation."""
    e = eq(s, u)
    return all_("a", implies(
        all_("n", implies(rooted(e), substitute_formula(e, {"n": succ(N)}))),
        all_("n", rooted(e))))


def one_schema_prior(s: Term, u: Term) -> Formula:
    """Prior two-term one-schema formula, including its actual attached body."""
    if (active_free_vars(s) | active_free_vars(u)) - {"n", "a"}:
        raise ValueError("prior two-term input has an extra variable")
    p = rooted(eq(s, u))
    h = substitute(s, {"n": V, "a": V})
    return all_("a", implies(
        all_("n", implies(p, substitute_formula(p, {"n": succ(N)}))),
        all_("n", conj(p, computation(h)))))


def tagged(t: Term) -> Formula:
    validate_term(t)
    if active_free_vars(t) - {"n", "a", "b"}:
        raise ValueError("tagged input has more than its three formal slots")
    t0, t1 = substitute(t, {"b": ZERO}), substitute(t, {"b": ONE})
    h = substitute(t, {"n": V, "a": V, "b": ZERO})
    e = eq(t0, t1)
    return all_("a", implies(
        all_("n", implies(rooted(e), substitute_formula(e, {"n": succ(N)}))),
        all_("n", conj(rooted(e), computation(h)))))


def iterator(h: Term, count: Term, seed: Term) -> Term:
    return delay(h, succ(count), seed)


def ztest(r: Term, x: Term) -> Term:
    return iterator(ZERO, r, x)


def plus(x: Term, y: Term) -> Term:
    return iterator(succ(V), y, x)


def raw_selector(r: Term, x: Term, y: Term) -> Term:
    """An abbreviation for actual terms, with no extra arithmetic primitive."""
    return plus(ztest(r, x), ztest(ztest(r, ONE), y))


def compile_pair(s: Term, u: Term) -> Term:
    if (active_free_vars(s) | active_free_vars(u)) - {"n", "a"}:
        raise ValueError("pair compiler inputs must have only n,a free")
    return raw_selector(B, s, u)


def encode_term(t: Term) -> list:
    if t.tag == "var":
        return ["var", t.name]
    if t.descriptor is not None:
        return ["D", encode_term(t.descriptor.body),
                *(encode_term(arg) for arg in t.args)]
    return [t.tag, *(encode_term(arg) for arg in t.args)]


def descriptor_id(h: Term) -> str:
    encoded = json.dumps(encode_term(h), separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()[:12]


def descriptor_bodies(formulas: Iterable[Formula]) -> set[Term]:
    found: set[Term] = set()

    def scan_term(t: Term) -> None:
        if t.descriptor is not None and t.descriptor.body not in found:
            found.add(t.descriptor.body)
            scan_term(t.descriptor.body)
        for arg in t.args:
            scan_term(arg)

    def scan_formula(f: Formula) -> None:
        for t in f.terms:
            scan_term(t)
        for c in f.children:
            scan_formula(c)

    for f in formulas:
        scan_formula(f)
    return found


def ledger(f: Formula) -> dict:
    bodies = descriptor_bodies([f])
    active = formula_size(f)
    dictionary = sum(term_size(body) for body in bodies)
    return {
        "active_ast_nodes": active,
        "distinct_D_symbols": len(bodies),
        "descriptor_body_nodes_once": dictionary,
        "active_ast_plus_descriptor_dictionary": active + dictionary,
        "fully_expanded_descriptor_tree_nodes": formula_size(
            f, expand_descriptors=True),
        "maximum_descriptor_rank": max(
            (1 + dependency_rank(body) for body in bodies), default=0),
        "quantifier_occurrences": quantifier_count(f),
        "maximum_quantifier_depth": quantifier_depth(f),
        "active_individual_names": sorted(active_names(f)),
        "free_variables": sorted(formula_free_vars(f)),
        "binder_shadowing": has_shadowing(f),
    }


def term_text(t: Term) -> str:
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "succ":
        return f"S({term_text(t.args[0])})"
    assert t.descriptor is not None
    return f"D_{descriptor_id(t.descriptor.body)}(" + ",".join(
        term_text(arg) for arg in t.args) + ")"


def formula_text(f: Formula) -> str:
    if f.tag == "bottom":
        return "false"
    if f.tag == "eq":
        return f"({term_text(f.terms[0])}={term_text(f.terms[1])})"
    if f.tag == "all":
        return f"forall {f.binder}. {formula_text(f.children[0])}"
    operator = {"and": "AND", "or": "OR", "imp": "->"}[f.tag]
    return "(" + f" {operator} ".join(formula_text(c) for c in f.children) + ")"


def small_terms(bodies: tuple[Term, ...], maximum: int = 4) -> list[Term]:
    by_size = {1: [ZERO, N, A, B]}
    for size in range(2, maximum + 1):
        generated = [succ(t) for t in by_size[size - 1]]
        for left in range(1, size - 1):
            right = size - left - 1
            generated.extend(delay(h, x, y) for h in bodies
                             for x in by_size[left] for y in by_size[right])
        by_size[size] = generated
    return [t for group in by_size.values() for t in group]


def reject(action) -> None:
    try:
        action()
    except ValueError:
        return
    raise AssertionError("a malformed-input control was accepted")


def checked_input(t: Term) -> tuple[Formula, Formula, Term, Term, Term]:
    new = tagged(t)
    t0, t1 = substitute(t, {"b": ZERO}), substitute(t, {"b": ONE})
    h = substitute(t, {"n": V, "a": V, "b": ZERO})
    old = one_schema_prior(t0, t1)
    for f in (new, old):
        validate_formula(f)
        assert not formula_free_vars(f)
        assert active_names(f) <= {"n", "a"}
        assert quantifier_count(f) == 3
        assert quantifier_depth(f) == 2
        assert not has_shadowing(f)
    assert active_free_vars(h) <= {"v"}
    assert h == substitute(t0, {"n": V, "a": V})
    assert dependency_rank(h) == dependency_rank(t)
    assert dependency_rank(delay(h, N, A)) == dependency_rank(t) + 1
    total, bn, nn, an = (term_size(t), occurrences(t, "b"),
                          occurrences(t, "n"), occurrences(t, "a"))
    assert term_size(t0) == total
    assert term_size(t1) == total + bn
    assert term_size(h) == total
    assert formula_size(new) == 38 + 7 * total + 3 * bn + 5 * nn + 3 * an
    assert formula_size(old) == formula_size(new) + 5
    assert descriptor_bodies([new]) == descriptor_bodies([old])
    assert formula_size(old, expand_descriptors=True) - formula_size(
        new, expand_descriptors=True) == 5
    # Check the full expanded descendant computation matrix, not a placeholder.
    conclusion = new.children[0].children[1].children[0]
    assert conclusion.children[1] == computation(h)
    return new, old, t0, t1, h


def check() -> tuple[dict, str]:
    predecessor_body = delay(succ(V), V, ZERO)
    nested = delay(predecessor_body, succ(N), delay(ONE, B, A))
    nested_left = delay(predecessor_body, succ(N), succ(A))
    nested_right = delay(succ(V), A, N)
    samples = {
        "tag_independent_n": N,
        "tag_independent_successor": succ(N),
        "tag_slot_only": B,
        "tag_as_iterator_seed": delay(succ(V), N, B),
        "nested_descriptors": nested,
        "raw_selector_predecessor": compile_pair(N, N),
        "compiled_equation_n_a": compile_pair(N, A),
        "compiled_nested_equation": compile_pair(nested_left, nested_right),
    }
    rows, rendered = {}, []
    for name, t in samples.items():
        new, old, t0, t1, h = checked_input(t)
        rows[name] = {
            "input_term": term_text(t),
            "input_active_nodes": term_size(t),
            "active_occurrences": {x: occurrences(t, x) for x in ("n", "a", "b")},
            "zero_endpoint": term_text(t0),
            "one_endpoint": term_text(t1),
            "attached_body": term_text(h),
            "input_dependency_rank": dependency_rank(t),
            "attached_symbol_rank": dependency_rank(h) + 1,
            "tagged_schema": ledger(new),
            "prior_one_schema_on_identical_endpoints": ledger(old),
            "active_nodes_saved_against_identical_endpoints": 5,
        }
        rendered += [f"[{name}]", f"Input: {term_text(t)}",
                     f"Emitted: {formula_text(new)}", "Stored bodies:"]
        for body in sorted(descriptor_bodies([new]),
                           key=lambda x: (dependency_rank(x), descriptor_id(x))):
            rendered.append(f"  D_{descriptor_id(body)}: {term_text(body)}; "
                            f"rank {1 + dependency_rank(body)}; "
                            f"active body nodes {term_size(body)}")
        rendered.append("")

    exhaustive = small_terms((ZERO, ONE, succ(V), predecessor_body))
    for t in exhaustive:
        checked_input(t)

    bodies = (ZERO, ONE, V, succ(V), predecessor_body,
              delay(predecessor_body, succ(V), succ(V)),
              delay(delay(ZERO, succ(V), V), V, succ(V)))
    for h in bodies:
        t = substitute(h, {"v": N})
        f, _, t0, t1, recovered = checked_input(t)
        assert t0 == t1 and recovered == h
        progress = f.children[0].children[0].children[0]
        assert progress.children[1].tag == "eq"
        assert progress.children[1].terms[0] == progress.children[1].terms[1]

    # Frozen descriptors and simultaneous active substitution.
    stored = delay(predecessor_body, N, A)
    changed = substitute(stored, {"n": A, "a": N, "v": ZERO})
    assert changed.args == (A, N)
    assert changed.descriptor is stored.descriptor
    assert stored.descriptor is not None
    assert stored.descriptor.body == predecessor_body
    assert substitute(delay(succ(V), N, A), {"n": V, "a": V}) == delay(
        succ(V), V, V)
    capture = substitute_formula(all_("a", eq(N, A)), {"n": A})
    assert capture.binder != "a" and formula_free_vars(capture) == {"a"}

    # Negative controls include a cycle that cannot be built through delay().
    cyclic_descriptor = Descriptor(ZERO)
    cyclic_term = Term("delay", (V, ZERO), descriptor=cyclic_descriptor)
    object.__setattr__(cyclic_descriptor, "body", cyclic_term)
    bad_actions = [
        lambda: delay(succ(A), N, A),
        lambda: tagged(var("outside")),
        lambda: validate_term(Term("succ", (N, A))),
        lambda: validate_term(Term("delay", (N, A))),
        lambda: validate_term(Term("zero", descriptor=Descriptor(V))),
        lambda: validate_term(cyclic_term),
        lambda: validate_formula(Formula("eq", terms=(N,))),
        lambda: one_schema_prior(B, A),
    ]
    for action in bad_actions:
        reject(action)

    pair_rows = {}
    pairs = {"n_equals_a": (N, A), "n_equals_n": (N, N),
             "zero_equals_zero": (ZERO, ZERO),
             "nested_equation": (nested_left, nested_right)}
    for name, (s, u) in pairs.items():
        t = compile_pair(s, u)
        new, same_old, t0, t1, h = checked_input(t)
        original = one_schema_prior(s, u)
        direct_dynamic = short_pair(s, u)
        compiled_dynamic = short_pair(t0, t1)
        ls, lu = term_size(s), term_size(u)
        k = occurrences(s, "n") + occurrences(u, "n")
        assert term_size(t) == 12 + ls + lu
        assert term_size(t0) == 12 + ls + lu
        assert term_size(t1) == 14 + ls + lu
        dynamic_overhead = 78 + 3 * (ls + lu) + k
        assert formula_size(compiled_dynamic) - formula_size(direct_dynamic) == dynamic_overhead
        total_overhead = (85 + 3 * ls + 4 * lu + k
                          + 3 * (occurrences(u, "n") + occurrences(u, "a")))
        assert formula_size(new) - formula_size(original) == total_overhead
        pair_rows[name] = {
            "left": term_text(s), "right": term_text(u),
            "compiled_tagged_input": term_text(t),
            "original_pair_prior_one_schema": ledger(original),
            "compiled_tagged_schema": ledger(new),
            "prior_one_schema_on_compiled_endpoints": ledger(same_old),
            "direct_short_dynamic_active_nodes": formula_size(direct_dynamic),
            "compiled_short_dynamic_active_nodes": formula_size(compiled_dynamic),
            "dynamic_compilation_extra_nodes": dynamic_overhead,
            "total_extra_nodes_vs_original_pair_prior_one_schema": total_overhead,
        }

    result = {
        "status": "passed",
        "scope": "Finite syntax, well-founded descriptors, active substitution, exact syntax counts; not a formal arithmetic or interpretation proof.",
        "comparison_commit": "efc26dac89ba0b9e425995f305d7ac4534796e90",
        "source_term_formal_slots": ["n", "a", "b"],
        "emitted_individual_names": ["n", "a"],
        "counts": {"named_examples": len(samples),
                   "small_generated_inputs": len(exhaustive),
                   "reflexive_computation_extractions": len(bodies),
                   "rejected_negative_controls": len(bad_actions),
                   "pair_compilation_examples": len(pairs)},
        "schema_invariants": {"closed": True, "quantifier_occurrences": 3,
                              "maximum_quantifier_depth": 2,
                              "no_binder_shadowing": True,
                              "stored_descriptors_frozen": True,
                              "diagonal_preserves_dependency_rank": True,
                              "attached_symbol_rank_is_input_rank_plus_one": True},
        "counting_convention": {
            "active_ast": "One node per variable, constant, active application, equality, connective, or quantifier; negation expands to implication to bottom.",
            "dictionary": "Each distinct stored unary body is charged once by its active AST size; nested descriptor bodies are distinct entries.",
            "expanded_tree": "Each descriptor body and every nested descriptor is charged again at every D occurrence.",
            "not_counted": "Bit encodings of variable/symbol names, descriptor references, or the schema-generating program itself."},
        "general_active_count": "38 + 7|t| + 3 occ_b(t) + 5 occ_n(t) + 3 occ_a(t)",
        "identical_endpoints_comparison": {
            "prior_formula": "one_schema(t[b:=0], t[b:=1]); its attached body is exactly t(v,v,0)",
            "uniform_saving": 5,
            "reason": "Remove the successor root S(n)=0 and its OR node from the progress consequent.",
            "descriptor_dictionaries_identical": True,
            "caveat": "This is the inherited short-propagation improvement applied to the same endpoints, not a five-node saving for arbitrary equation-to-tag compilation."},
        "pair_compilation_formulae": {
            "context_active_nodes": "12+|s|+|u|",
            "zero_endpoint_nodes": "12+|s|+|u|",
            "one_endpoint_nodes": "14+|s|+|u|",
            "dynamic_extra_nodes": "78+3(|s|+|u|)+occ_n(s)+occ_n(u)",
            "total_extra_vs_original_prior_one_schema": "85+3|s|+4|u|+occ_n(s)+occ_n(u)+3(occ_n(u)+occ_a(u))",
            "caveat": "The selector compiler increases expanded formula length. The gain is one varying tagged-term input and one constructor with no fixed diagonal axiom; its third formal slot is an explicit cost."},
        "rejected_simplification": {
            "variant": "Replace rooted propagation by ordinary equation induction with an explicit base.",
            "status": "rejected; no PRA-equivalence claim",
            "countermodel": "N x N with componentwise operations satisfies computation, separation, and all native equation induction; (0,1) is neither zero nor a successor.",
            "explanation": "An equation defines A1 x A2; its true base makes both factors nonempty, and product progress implies progress of each factor. External induction gives both factors N. Coverage still fails.",
            "limit": "This refutes the intended full-carrier native-equality calibration; it does not alone rule out every exotic interpretation."},
        "sample_ledger": rows,
        "pair_compilation_ledger": pair_rows,
        "not_verified": ["arithmetic truth in arbitrary models", "consistency",
                         "all induction instances", "native equality reflection",
                         "bi-interpretability", "absolute minimality"],
    }
    return result, "\n".join(rendered) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path,
                        help="write schema_checks.json and schema_examples.txt here")
    args = parser.parse_args()
    result, examples = check()
    encoded = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.mkdir(parents=True, exist_ok=True)
        (args.out / "schema_checks.json").write_text(encoded, encoding="utf-8")
        (args.out / "schema_examples.txt").write_text(examples, encoding="utf-8")
    print(json.dumps({"status": result["status"], "counts": result["counts"],
                      "schema_invariants": result["schema_invariants"],
                      "identical_endpoints_nodes_saved": 5}, indent=2))


if __name__ == "__main__":
    main()
