SYNTAX CHECKER

Requirements: Python 3.10 or newer; no external packages.
From the archive's top directory run:

    python3 checks/check_schema.py --out checks

The command prints a compact receipt and writes:
  schema_checks.json   Exact counts, examples, caveats, and negative controls.
  schema_examples.txt  Fully expanded active formulas and stored-body tables.

The checker implements finite, well-founded delayed-iterator descriptions,
simultaneous active substitution with frozen descriptors, capture-avoiding
formula substitution, the exact tagged generator, and the comparison
generator from the prior one-schema draft. There are no evaluator symbols,
schematic placeholders, or new selector primitives in emitted formulas.

It checks 272 small input terms, 8 named examples (including nested
descriptors and the raw selector), 7 exact computation-extraction instances,
8 malformed-input controls, and 4 pair-to-tag compilation examples. Every
tested emitted formula is closed, uses only active names n,a, has three
quantifiers of maximum nesting depth two, and has no binder shadowing.

The exact general active-node count is

    38 + 7|t| + 3 occ_b(t) + 5 occ_n(t) + 3 occ_a(t).

Here stored descriptor bodies are excluded from active node counts. Their
cost is reported separately as a dictionary, counting each distinct body
once, and as a fully expanded descriptor tree. Neither convention counts
the bit representation of symbol names or of descriptor references.

For the same two endpoint terms and exactly the same attached computation
body, the new formula has five fewer nodes than the prior one-schema
formula. This removes the successor zero disjunct from the progress
consequent, a simplification already present in the short-propagation draft.
It is not a claim that compilation from an arbitrary pair makes a shorter
sentence. The raw-selector compilation increases expanded size; the JSON
ledger explicitly reports that increase and the third formal tag slot.

Scope: these are finite syntax and counting checks. They are not an
arithmetic proof, a consistency proof, a proof of all schema instances, or
a formal verification of bi-interpretability. The full calibration is the
written argument in the report.

REJECTED VARIANT

Do not replace the rooted propagation schema by ordinary equation
induction with an explicit base. The componentwise model N x N satisfies
the computational laws, separation, and native equation induction, but
(0,1) is neither zero nor a successor. The rooted disjunction is essential
to the stated full-carrier calibration. The notes and JSON acknowledge
this obstruction; they do not assert that it rules out every possible
exotic interpretation of the weaker theory.
