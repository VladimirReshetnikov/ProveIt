#!/usr/bin/env python3
"""Rebuild the report and diagnostics; optionally rerun the Lean kernel."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to a Lean 4.19.0 executable")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    results = {}
    tasks = [("syntax", [sys.executable, "checks/check_schema.py", "--out", "checks"])]
    if args.lean:
        tasks.append(("lean", [str(Path(args.lean).resolve()), "formal/TaggedKernel.lean"]))
    if not shutil.which("pdflatex"):
        raise SystemExit("pdflatex is required to compile the mathematical report.")
    tasks.extend((f"latex_pass_{i}", ["pdflatex", "-interaction=nonstopmode",
                  "-halt-on-error", "report.tex"]) for i in range(1, 4))
    for name, command in tasks:
        result = subprocess.run(command, cwd=root, capture_output=True, text=True)
        (audit / f"{name}.log").write_text(result.stdout + result.stderr)
        results[name] = {"exit_code": result.returncode}
        print(f"{name}: {'PASS' if result.returncode == 0 else 'FAIL'}", flush=True)
        if result.returncode:
            (audit / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")
            raise SystemExit(f"See audit/{name}.log for the failure.")
    log = (root / "report.log").read_text(errors="replace")
    layout_warnings = [line for line in log.splitlines()
                       if any(x in line for x in ("Overfull", "undefined references",
                                                 "Citation", "Reference"))
                       and ("Warning" in line or "Overfull" in line)]
    results["layout_warnings"] = layout_warnings
    results["report_pdf_bytes"] = (root / "report.pdf").stat().st_size
    results["lean_rerun"] = bool(args.lean)
    (audit / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(f"PDF: {root / 'report.pdf'}")
    if layout_warnings:
        print("Layout/reference warnings require review:")
        print("\n".join(layout_warnings))


if __name__ == "__main__":
    main()
