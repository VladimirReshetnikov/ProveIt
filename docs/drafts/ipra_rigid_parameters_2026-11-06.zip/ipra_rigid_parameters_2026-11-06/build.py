#!/usr/bin/env python3
"""Compile the complete LaTeX report; certificate verification is separate."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("pdflatex is required to rebuild the PDF.")
    destination = ROOT / ".build"
    destination.mkdir(exist_ok=True)
    command = [
        engine, "-interaction=nonstopmode", "-halt-on-error",
        "-output-directory=" + str(destination), "report.tex",
    ]
    for _ in range(3):
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        if result.returncode:
            print(result.stdout[-16000:])
            print(result.stderr)
            raise SystemExit(result.returncode)
    shutil.copyfile(destination / "report.pdf", ROOT / "report.pdf")
    print("Built", ROOT / "report.pdf")


if __name__ == "__main__":
    main()
