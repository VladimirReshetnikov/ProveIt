#!/usr/bin/env python3
"""Create a deterministic ZIP and SHA-256 manifest of this deliverable."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent


def included(path):
    relative = path.relative_to(ROOT)
    return (
        path.is_file()
        and path.name != "MANIFEST.sha256"
        and path.suffix != ".pyc"
        and all(not part.startswith(".") and part != "__pycache__"
                for part in relative.parts)
    )


def main():
    if not (ROOT / "report.pdf").is_file():
        raise SystemExit("Compile report.pdf before packaging.")
    files = sorted(path for path in ROOT.rglob("*") if included(path))
    manifest = ROOT / "MANIFEST.sha256"
    manifest.write_text("".join(
        hashlib.sha256(path.read_bytes()).hexdigest() + "  "
        + path.relative_to(ROOT).as_posix() + "\n" for path in files
    ), encoding="utf-8")
    files.append(manifest)
    output = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(files):
            info = zipfile.ZipInfo(
                ROOT.name + "/" + path.relative_to(ROOT).as_posix(),
                date_time=(2026, 11, 6, 0, 0, 0),
            )
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    print(output)
    print("Files:", len(files))
    print("Bytes:", output.stat().st_size)
    print("SHA-256:", hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
