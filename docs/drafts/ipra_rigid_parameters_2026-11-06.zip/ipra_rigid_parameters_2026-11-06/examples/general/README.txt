THEOREM CERTIFICATES
====================

Each *.json file in this directory has exactly two fields, [goal, proof],
and can be checked with:

  python3 checker.py examples/general/FILE.json

All 24 certificates have been accepted by the strict checker, demand checker,
and the independent named-variable reference checker. Their public CLI
acceptance was checked both normally and with Python -O.

Nineteen examples are adapted from the arity draft, with zero=-1 changed to
zero=0 and variable slots shifted by one. They include:

  reflexivity.json                    universal numerical reflexivity
  successor_injective.json            successor injectivity
  forall_exists_successor.json        existence of each successor as a witness
  coverage.json                       the reconstructed numerical coverage law
  direct_zero_plus_n.json             equation induction for 0+n=n
  direct_successor_plus_n.json        equation induction for successor/addition
  diff_cancel.json                    cancellation for truncated subtraction
  diff_diagonal.json                  d(a,a)=0
  diff_successor_diagonal.json        d(Sa,a)=1
  residual.json                       the residual identity used by equality reflection
  closed_*                           conditional equality-test and collision-detour proofs

The five new examples explicitly exercise the rigid parameter namespace:

  rigid_parameter_reflexivity.json    c=c for parameter c encoded by -1
  rigid_parameter_exists.json        exists x, x=c
  rigid_parameter_identity.json      for every x, x=c implies x=c
  rigid_nested_recursor_reflexivity.json
                                     reflexivity with parameters below nested two-slot recursors
  rigid_successor_counter.json       R(Sc,a;u,v.v)=c for distinct parameters c,a

Negative integers are free number parameters, not negative numerical values.
Positive free slots in older examples are also permitted theorem parameters.
Acceptance certifies the theorem with all such free number parameters left
arbitrary (equivalently, its universal closure).

These are proof examples and implementation checks, not machine-checked
metaproofs of the report's equivalence theorems.

