#!/usr/bin/env python3
"""Reproduce the packaged comparison and certificate verification offline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
STEPS = (
    "comparison/measure.py",
    "validation/validate.py",
    "validation/parameter_translation_tests.py",
)


def main():
    for step in STEPS:
        result = subprocess.run(
            [sys.executable, str(ROOT / step)],
            cwd=ROOT, text=True, capture_output=True,
        )
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
        print("PASS", step)
    metrics = json.loads((ROOT / "results/metrics.json").read_text())
    validation = json.loads((ROOT / "results/validation_summary.json").read_text())
    translations = json.loads((ROOT / "results/parameter_translations.json").read_text())
    summary = {
        "status": "passed",
        "comparison_gates": metrics["gates"],
        "validation": validation,
        "successful_parameter_translations": translations["successful_translations"],
        "invalid_translation_sources_rejected": len(translations["rejected_invalid_sources"]),
    }
    (ROOT / "results/reproduction.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
