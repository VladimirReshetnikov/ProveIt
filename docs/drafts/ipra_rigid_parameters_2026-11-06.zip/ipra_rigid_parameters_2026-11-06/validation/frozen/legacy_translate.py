"""Sequent-preserving certificate translations, outside the trusted checker.

The source is the published strict automatic-introduction checker.  The target
uses reconstructed introduction labels, hypothesis membership, and positive variable indices.  Readback
chooses the first matching hypothesis, so it canonicalizes irrelevant index
choices; it does not claim byte-for-byte certificate preservation.
"""
import argparse
import importlib.util
import json
from pathlib import Path


def load_checker(path):
    path = Path(path)
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepted(checker, goal, proof, context=()):
    try:
        for formula in context:
            checker.subst(formula)
        return bool(checker.check(goal, proof, context))
    except Exception:
        return False


def lift_context(context, hypothesis, subst):
    return [*(subst(formula) for formula in context), hypothesis]


def automatic_premise(guard, body, subst):
    if guard == subst(body, [-1, 0]):
        guard = body if body[0] == '=' else guard
        body = subst(body, [['s', 0], 0])
    return guard, body


def elimination_premise(tag, parts, witness, subst):
    return tuple(subst(witness, [part, -1]) if tag == '='
                 else subst(part, [witness, -1]) for part in parts)


def _forward(goal, proof, context, subst):
    match (goal, proof):
        case [['pi', guard, body], ['lam', branch]]:
            guard, body = automatic_premise(guard, body, subst)
            return [_forward(body, branch,
                             lift_context(context, guard, subst), subst)]
        case [['ex', body], ['pack', witness, branch]]:
            guard = ['=', 0, subst(witness, formula=False)]
            return [witness, _forward(body, branch,
                                     lift_context(context, guard, subst), subst)]
        case [_, [[tag, *parts] as major, major_proof, *arguments]]:
            head = _forward(major, major_proof, context, subst)
            if tag == 'ex':
                [branch] = arguments
                [guard] = parts
                tail = _forward(subst(goal), branch,
                                lift_context(context, guard, subst), subst)
                return [major, head, tail]
            witness, branch = arguments
            premise, _ = elimination_premise(tag, parts, witness, subst)
            tail = _forward(premise, branch, context, subst)
            return [major, head, witness, tail]
        case [['=', ['r', _, _, _], _], 'r']:
            return 'r'
        case _:
            return None


def shift_codes(value, offset):
    """Renumber all numerical syntax leaves; Booleans remain Booleans."""
    if type(value) is int:
        return value + offset
    if isinstance(value, list):
        return [shift_codes(item, offset) for item in value]
    if isinstance(value, dict):
        return {key: shift_codes(item, offset) for key, item in value.items()}
    return value


class NegativeView:
    """The positive target viewed through the inverse syntax bijection."""
    def __init__(self, source, target):
        self.subst = source.subst
        self.target = target

    def check(self, goal, proof, context):
        return self.target.check(shift_codes(goal, 1), shift_codes(proof, 1),
                                 shift_codes(list(context), 1))


def forward(source, target, goal, proof, context=()):
    """Translate a source sequent, renumbering zero -1 to zero 0."""
    context = list(context)
    if not accepted(source, goal, proof, context):
        raise ValueError('The source certificate is not accepted')
    translated = _forward(goal, proof, context, source.subst)
    new_goal, new_proof, new_context = shift_codes(
        [goal, translated, context], 1)
    if not accepted(target, new_goal, new_proof, new_context):
        raise AssertionError('Forward translation failed')
    return [new_goal, new_proof, new_context]


def _readback(goal, proof, context, target):
    subst = target.subst
    match (goal, proof):
        case [['pi', guard, body], [branch]]:
            guard, body = automatic_premise(guard, body, subst)
            return ['lam', _readback(body, branch,
                                     lift_context(context, guard, subst), target)]
        case [['ex', body], [witness, branch]]:
            guard = ['=', 0, subst(witness, formula=False)]
            return ['pack', witness,
                    _readback(body, branch,
                              lift_context(context, guard, subst), target)]
        case [_, [[tag, *parts] as major, major_proof, *arguments]] if target.check(major, major_proof, context):
            head = _readback(major, major_proof, context, target)
            if tag == 'ex':
                [branch] = arguments
                [guard] = parts
                tail = _readback(subst(goal), branch,
                                 lift_context(context, guard, subst), target)
                return [major, head, tail]
            witness, branch = arguments
            premise, _ = elimination_premise(tag, parts, witness, subst)
            tail = _readback(premise, branch, context, target)
            return [major, head, witness, tail]
        case [['=', ['r', _, _, _], _], 'r']:
            return 'r'
        case _:
            return context.index(goal)


def readback(source, target, goal, proof, context=()):
    """Read an accepted positive target certificate into the old syntax."""
    context = list(context)
    if not accepted(target, goal, proof, context):
        raise ValueError('The target certificate is not accepted')
    old_goal, old_proof, old_context = shift_codes([goal, proof, context], -1)
    translated = _readback(old_goal, old_proof, old_context,
                           NegativeView(source, target))
    if not accepted(source, old_goal, translated, old_context):
        raise AssertionError('Readback failed')
    return [old_goal, translated, *old_context]


def canonicalize(source, target, goal, proof, context=()):
    old_goal, old_proof, *old_context = readback(
        source, target, goal, proof, context)
    return forward(source, target, old_goal, old_proof, old_context)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('direction', choices=('forward', 'readback', 'canonicalize'))
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--source-checker', required=True, type=Path)
    parser.add_argument('--target-checker', required=True, type=Path)
    args = parser.parse_args()
    source = load_checker(args.source_checker)
    target = load_checker(args.target_checker)
    data = json.loads(args.input.read_text(encoding='utf-8'))
    if args.direction == 'forward':
        goal, proof, *context = data
        result = forward(source, target, goal, proof, context)
    else:
        goal, proof, *rest = data
        [context] = rest or [[]]
        result = globals()[args.direction](source, target, goal, proof, context)
    args.output.write_text(json.dumps(result, separators=(',', ':')) + '\n',
                           encoding='utf-8')
    print('TRANSLATED')


if __name__ == '__main__':
    main()
