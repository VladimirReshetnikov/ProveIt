"""Untrusted certificate adapters; no acceptance kernel imports this module."""
from copy import deepcopy


def from_automatic(proof):
    """Erase all introduction/computation opcodes and hypothesis selectors."""
    if proof == 'r':
        return None
    if type(proof) is not list:
        return 0
    if proof[0] == 'lam':
        return [from_automatic(proof[1])]
    if proof[0] == 'pack':
        return [deepcopy(proof[1]), from_automatic(proof[2])]
    major, premise, *arguments = proof
    if major[0] == 'ex':
        return [deepcopy(major), from_automatic(premise),
                from_automatic(arguments[0])]
    annotation, minor = arguments
    return [deepcopy(major), from_automatic(premise), deepcopy(annotation),
            from_automatic(minor)]


def to_automatic(goal, proof, context, subst):
    """Read a valid compact proof back into the prior automatic calculus.

    Membership may win over a syntactically inapplicable certificate, so a
    present assumption always gets the canonical hypothesis proof first.
    The caller separately checks the returned proof with its destination.
    """
    if goal in context:
        return context.index(goal)
    lifted = lambda: [subst(a) for a in context]
    match (goal, proof):
        case [['pi', hypothesis, conclusion], [subproof]]:
            if hypothesis == subst(conclusion, [-1, 0]):
                hypothesis = conclusion if conclusion[0] == '=' else hypothesis
                conclusion = subst(conclusion, [['s', 0], 0])
            return ['lam', to_automatic(conclusion, subproof,
                                       [*lifted(), hypothesis], subst)]
        case [['ex', matrix], [witness, subproof]]:
            hypothesis = ['=', 0, subst(witness, formula=False)]
            return ['pack', deepcopy(witness),
                    to_automatic(matrix, subproof, [*lifted(), hypothesis], subst)]
        case [_, [[tag, *parts] as major, major_proof, *arguments]]:
            translated_major = to_automatic(major, major_proof, context, subst)
            if tag == 'ex':
                translated_minor = to_automatic(subst(goal), *arguments,
                                                [*lifted(), *parts], subst)
                return [deepcopy(major), translated_major, translated_minor]
            annotation, minor_proof = arguments
            premise, conclusion = (subst(annotation, [term, -1]) if tag == '='
                                   else subst(term, [annotation, -1]) for term in parts)
            if conclusion != goal:
                raise ValueError('Readback conclusion changed')
            return [deepcopy(major), translated_major, deepcopy(annotation),
                    to_automatic(premise, minor_proof, context, subst)]
        case [['=', ['r', _, _, _], _], None]:
            return 'r'
        case _:
            raise ValueError('No compact rule applies')
