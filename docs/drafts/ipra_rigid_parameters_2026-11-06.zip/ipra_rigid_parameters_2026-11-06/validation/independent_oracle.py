"""Named-variable reference checker for rigid-parameter iPRA certificates.

Adapted from the arity draft's independent oracle (see frozen/provenance.json).
It uses positive de Bruijn slots, rigid negative names, and computation label r.
This file is validation support, not part of the small trusted checker.  It
does not import the production checker, its substitution routine, or a proof
builder.  Raw de Bruijn expressions are parsed into a named-variable syntax.
Opening a binder allocates a fresh eigenvariable; contexts therefore need no
index shifting.  Substitution and alpha-equivalence are separate operations.

Public certificates are [goal, proof].  ``accept_sequent`` additionally checks
an explicit list of assumptions for differential tests of the open interface.
Malformed *used* annotations reject.  A false elimination guard can fall
through to hypothesis membership, but a malformed guard cannot.  This is the
ordered-certificate convention of the small checker, not a soundness shortcut.
"""

from dataclasses import dataclass
import json
import sys


class Invalid(Exception):
    """An ill-formed or committed-but-malformed certificate component."""


@dataclass(frozen=True)
class Name:
    # kind 0: free positive slot; 1: fresh eigenname; 2: rigid negative parameter.
    kind: int
    index: int


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Var:
    name: Name


@dataclass(frozen=True)
class Succ:
    value: object


@dataclass(frozen=True)
class Rec:
    counter: object
    initial: object
    previous: Name
    index: Name
    update: object


@dataclass(frozen=True)
class Eq:
    left: object
    right: object


@dataclass(frozen=True)
class Pi:
    variable: Name
    guard: object
    body: object


@dataclass(frozen=True)
class Exists:
    variable: Name
    body: object


ZERO = Zero()


def free_names(expression):
    """Return the free names of a validated internal expression."""
    if isinstance(expression, Zero):
        return set()
    if isinstance(expression, Var):
        return {expression.name}
    if isinstance(expression, Succ):
        return free_names(expression.value)
    if isinstance(expression, Rec):
        return (free_names(expression.counter)
                | free_names(expression.initial)
                | (free_names(expression.update)
                   - {expression.previous, expression.index}))
    if isinstance(expression, Eq):
        return free_names(expression.left) | free_names(expression.right)
    if isinstance(expression, Pi):
        return (free_names(expression.guard) | free_names(expression.body)) - {expression.variable}
    if isinstance(expression, Exists):
        return free_names(expression.body) - {expression.variable}
    raise Invalid("unknown internal expression")


def substitute(expression, replacements):
    """Simultaneously replace free names by terms.

    The parser and binder-opening operation give every binder a globally fresh
    name.  Thus no name free in an inserted term can be captured by a distinct
    binder.  Entries for a binder's own name are removed when traversing it.
    Replacements are inserted once and are not themselves substituted into.
    """
    if isinstance(expression, Zero):
        return expression
    if isinstance(expression, Var):
        return replacements.get(expression.name, expression)
    if isinstance(expression, Succ):
        return Succ(substitute(expression.value, replacements))
    if isinstance(expression, Rec):
        inner = {name: term for name, term in replacements.items()
                 if name not in (expression.previous, expression.index)}
        return Rec(substitute(expression.counter, replacements),
                   substitute(expression.initial, replacements),
                   expression.previous, expression.index,
                   substitute(expression.update, inner))
    if isinstance(expression, Eq):
        return Eq(substitute(expression.left, replacements),
                  substitute(expression.right, replacements))
    if isinstance(expression, Pi):
        inner = {name: term for name, term in replacements.items()
                 if name != expression.variable}
        return Pi(expression.variable,
                  substitute(expression.guard, inner),
                  substitute(expression.body, inner))
    if isinstance(expression, Exists):
        inner = {name: term for name, term in replacements.items()
                 if name != expression.variable}
        return Exists(expression.variable, substitute(expression.body, inner))
    raise Invalid("unknown internal expression")


def canonical(expression, bound=()):
    """An alpha-invariant key; distinct free names remain distinct."""
    if isinstance(expression, Zero):
        return ("zero",)
    if isinstance(expression, Var):
        if expression.name in bound:
            return ("bound", bound.index(expression.name))
        return ("free", expression.name)
    if isinstance(expression, Succ):
        return ("succ", canonical(expression.value, bound))
    if isinstance(expression, Rec):
        return ("rec", canonical(expression.counter, bound),
                canonical(expression.initial, bound),
                canonical(expression.update,
                          (expression.previous, expression.index) + bound))
    if isinstance(expression, Eq):
        return ("eq", canonical(expression.left, bound),
                canonical(expression.right, bound))
    if isinstance(expression, Pi):
        inner = (expression.variable,) + bound
        return ("pi", canonical(expression.guard, inner),
                canonical(expression.body, inner))
    if isinstance(expression, Exists):
        return ("exists", canonical(expression.body,
                                    (expression.variable,) + bound))
    raise Invalid("unknown internal expression")


def same(left, right):
    return canonical(left) == canonical(right)


class Oracle:
    def __init__(self, strict_witness=True):
        self.next_name = 0
        self.strict_witness = strict_witness

    def fresh(self):
        result = Name(1, self.next_name)
        self.next_name += 1
        return result

    def term(self, raw, environment=()):
        """Validate an exact term tree and resolve its de Bruijn variables."""
        if type(raw) is int:
            if raw == 0:
                return ZERO
            if raw < 0:
                return Var(Name(2, raw))
            if raw <= len(environment):
                return Var(environment[raw - 1])
            return Var(Name(0, raw - len(environment) - 1))
        if type(raw) is not list:
            raise Invalid("term must be an exact integer or array")
        if len(raw) == 2 and raw[0] == "s":
            return Succ(self.term(raw[1], environment))
        if len(raw) == 4 and raw[0] == "r":
            previous, index = self.fresh(), self.fresh()
            return Rec(self.term(raw[1], environment),
                       self.term(raw[2], environment), previous, index,
                       self.term(raw[3], (previous, index) + environment))
        raise Invalid("unknown term constructor or wrong arity")

    def formula(self, raw, environment=()):
        """Validate an exact formula tree, including every bound subterm."""
        if type(raw) is not list:
            raise Invalid("formula must be an array")
        if len(raw) == 3 and raw[0] == "=":
            return Eq(self.term(raw[1], environment),
                      self.term(raw[2], environment))
        if len(raw) == 3 and raw[0] == "pi":
            variable = self.fresh()
            inner = (variable,) + environment
            return Pi(variable, self.formula(raw[1], inner),
                      self.formula(raw[2], inner))
        if len(raw) == 2 and raw[0] == "ex":
            variable = self.fresh()
            return Exists(variable, self.formula(raw[1],
                                                (variable,) + environment))
        raise Invalid("unknown formula constructor or wrong arity")

    def derivation(self, goal, proof, assumptions, environment=()):
        """Check the ordered certificate cases in named-variable syntax."""
        array = type(proof) is list

        # One-element certificates introduce a guarded universal.
        if isinstance(goal, Pi) and array and len(proof) == 1:
            eigen = self.fresh()
            current = Var(eigen)
            zero_body = substitute(goal.body, {goal.variable: ZERO})
            numerical = same(goal.guard, zero_body)
            if numerical:
                local = (substitute(goal.body, {goal.variable: current})
                         if isinstance(goal.body, Eq) else zero_body)
                next_goal = substitute(goal.body,
                                       {goal.variable: Succ(current)})
            else:
                local = substitute(goal.guard, {goal.variable: current})
                next_goal = substitute(goal.body, {goal.variable: current})
            return self.derivation(next_goal, proof[0],
                                   assumptions + [local],
                                   (eigen,) + environment)

        # Two-element certificates introduce an existential via a fresh
        # equality assumption.  Its witness is always strictly validated.
        if isinstance(goal, Exists) and array and len(proof) == 2:
            witness = self.term(proof[0], environment)
            eigen = self.fresh()
            local = Eq(Var(eigen), witness)
            next_goal = substitute(goal.body, {goal.variable: Var(eigen)})
            return self.derivation(next_goal, proof[1],
                                   assumptions + [local],
                                   (eigen,) + environment)

        # A false major-premise derivation falls through to Hyp.  An exception
        # while parsing/checking it propagates and rejects the whole input.
        if (array and len(proof) >= 2 and type(proof[0]) is list
                and len(proof[0]) >= 1):
            major = self.formula(proof[0], environment)
            if self.derivation(major, proof[1], assumptions, environment):
                if isinstance(major, Exists):
                    if len(proof) != 3:
                        raise Invalid("existential elimination arity")
                    eigen = self.fresh()
                    local = substitute(major.body,
                                       {major.variable: Var(eigen)})
                    return self.derivation(goal, proof[2],
                                           assumptions + [local],
                                           (eigen,) + environment)
                if len(proof) != 4:
                    raise Invalid("binary elimination arity")
                if isinstance(major, Eq):
                    hole = self.fresh()
                    motive = self.formula(proof[2], (hole,) + environment)
                    premise = substitute(motive, {hole: major.left})
                    conclusion = substitute(motive, {hole: major.right})
                elif isinstance(major, Pi):
                    used = (major.variable in free_names(major.guard)
                            or major.variable in free_names(major.body))
                    witness = (self.term(proof[2], environment)
                               if self.strict_witness or used else ZERO)
                    premise = substitute(major.guard,
                                         {major.variable: witness})
                    conclusion = substitute(major.body,
                                            {major.variable: witness})
                else:
                    raise Invalid("unknown major formula")
                return same(goal, conclusion) and self.derivation(
                    premise, proof[3], assumptions, environment)

        # Computation commits only for an equality with a recursor on the left.
        if (isinstance(goal, Eq) and isinstance(goal.left, Rec)
                and proof == "r"):
            recursor = goal.left
            if isinstance(recursor.counter, Zero):
                reduct = recursor.initial
            elif isinstance(recursor.counter, Succ):
                counter = recursor.counter.value
                previous = Rec(counter, recursor.initial, recursor.previous,
                               recursor.index, recursor.update)
                reduct = substitute(recursor.update,
                                    {recursor.previous: previous,
                                     recursor.index: counter})
            else:
                raise Invalid("recursor counter is neither zero nor successor")
            return same(goal.right, reduct)

        # Certificates falling through all active cases need no index.  An
        # equal assumption is itself the complete proof at this point.
        return any(same(goal, hypothesis) for hypothesis in assumptions)


def accept_sequent(goal, proof, assumptions=(), strict_witness=True):
    """A total Boolean interface on finite JSON-shaped trees."""
    try:
        oracle = Oracle(strict_witness)
        context = [oracle.formula(raw) for raw in assumptions]
        formula = oracle.formula(goal)
        return oracle.derivation(formula, proof, context) is True
    except Exception:
        return False


def accept_document(document, open_context=False, strict_witness=True):
    if type(document) is not list:
        return False
    if len(document) != 2 and not (open_context and len(document) >= 2):
        return False
    return accept_sequent(document[0], document[1], document[2:], strict_witness)


if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise Invalid("expected one JSON path")
        with open(sys.argv[1], encoding="utf-8") as stream:
            document = json.load(stream)
        accepted = accept_document(document)
    except Exception:
        accepted = False
    print("ACCEPT" if accepted else "REJECT")
    sys.exit(0 if accepted else 1)
