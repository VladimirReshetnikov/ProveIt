"""Reproducible implementation evidence, entirely outside the trusted kernel.

The corpus consists of every top-level examples/*.json file in the six pinned
draft archives.  The reference checker uses fresh named variables and explicit
alpha-equivalence; it never calls the candidate substitution or checker.
This finite audit is not a formalization of soundness or bi-interpretability.
"""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent


def module(name, path):
    specification = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(specification)
    sys.modules[name] = result
    specification.loader.exec_module(result)
    return result


def require(condition, description):
    if not condition:
        raise AssertionError(description)


def digest(value):
    encoded = json.dumps(value, separators=(',', ':'), sort_keys=True).encode()
    return hashlib.sha256(encoded).hexdigest()


def accepted(checker, goal, proof, context=(), variadic=False):
    """Internal sequent test with an independently validated context boundary."""
    try:
        for assumption in context:
            checker.subst(assumption)
        result = (checker.check(goal, proof, *context) if variadic
                  else checker.check(goal, proof, list(context)))
        return result is True
    except Exception:
        return False


def syntax(expression, offset):
    """The old zero=-1 notation is renumbered bijectively by adding one."""
    if type(expression) is int:
        return expression + offset
    if type(expression) is list:
        return [syntax(part, offset) for part in expression]
    return deepcopy(expression)


def proof_format(proof, offset, computation):
    """Untrusted format adapter, not a derivation or proof-search procedure.

    All six current corpora already use arity-directed introductions.  Their
    differences here are the zero/index convention and computation marker.
    Every source and every generated certificate is independently rechecked.
    """
    if proof == computation:
        return 'r'
    if type(proof) is not list or not proof:
        return None
    if len(proof) == 1:
        return [proof_format(proof[0], offset, computation)]
    if len(proof) == 2:
        return [syntax(proof[0], offset),
                proof_format(proof[1], offset, computation)]
    major, branch, *tail = proof
    converted = [syntax(major, offset),
                 proof_format(branch, offset, computation)]
    if major[0] == 'ex':
        [minor] = tail
        return converted + [proof_format(minor, offset, computation)]
    annotation, minor = tail
    return converted + [syntax(annotation, offset),
                        proof_format(minor, offset, computation)]


CONFIG = {
    'ipra_arity_calculus_2026-11-06': (1, [], False, False),
    'ipra_automatic_goal_kernel_2026-11-06': (1, None, False, False),
    'ipra_goal_only_2026-11-06': (0, [], True, False),
    'ipra_implicit_certificates_2026-11-06': (0, 'r', False, False),
    'ipra_shared_introduction_2026-11-06': (1, 'r', False, False),
    'ipra_structural_kernel_2026-11-06': (0, 'r', False, True),
}


def audit_corpus(strict, demand, reference):
    records = json.loads((HERE / 'frozen' / 'corpus.json').read_text())
    sources = {name: module('source_' + name, ROOT / 'comparison' / 'sources'
                            / name / 'checker.py') for name in CONFIG}
    checked = []
    unique = set()
    for record in records:
        name = record['draft']
        offset, computation, variadic, nested_context = CONFIG[name]
        goal, proof, *tail = record['document']
        context = tail[0] if nested_context and tail else tail
        source_ok = accepted(sources[name], goal, proof, context, variadic)
        require(source_ok, 'Frozen source example rejected: ' + name + '/' + record['file'])
        new_goal = syntax(goal, offset)
        new_proof = proof_format(proof, offset, computation)
        new_context = [syntax(item, offset) for item in context]
        strict_ok = accepted(strict, new_goal, new_proof, new_context)
        demand_ok = accepted(demand, new_goal, new_proof, new_context)
        oracle_ok = reference.accept_sequent(new_goal, new_proof, new_context)
        require(strict_ok and demand_ok and oracle_ok,
                'Converted corpus example failed: ' + name + '/' + record['file'])
        fingerprint = digest([new_goal, new_proof, new_context])
        unique.add(fingerprint)
        checked.append({'draft': name, 'file': record['file'],
                        'source_sha256': record['sha256'],
                        'source_accepted': source_ok, 'strict_accepted': strict_ok,
                        'demand_accepted': demand_ok, 'named_oracle_accepted': oracle_ok,
                        'external_assumptions': len(context),
                        'converted_sequent_sha256': fingerprint})
        # This archive has nineteen theorem-boundary examples, including the
        # collision detour and the arithmetic equality-test lemmas.
        if name == 'ipra_arity_calculus_2026-11-06':
            require(not context, 'Chosen theorem example unexpectedly has assumptions')
            target = ROOT / 'examples' / 'general' / record['file']
            target.write_text(json.dumps([new_goal, new_proof], separators=(',', ':')) + '\n')
    return {'records': len(checked), 'distinct_converted_sequents': len(unique),
            'with_external_assumptions': sum(x['external_assumptions'] > 0 for x in checked),
            'without_external_assumptions': sum(x['external_assumptions'] == 0 for x in checked),
            'per_draft': {name: sum(x['draft'] == name for x in checked) for name in CONFIG},
            'checks': checked}


def audit_legacy_translators(strict, reference):
    """Exercise two unchanged earlier translators as untrusted proof producers.

    The automatic-goal adapter reads back to the earlier labeled automatic
    calculus.  The structural draft's forward translator then produces the
    positive-index certificate.  Each intermediate proof is rechecked.
    """
    frozen = HERE / 'frozen'
    adapter = module('rigid_legacy_adapter', frozen / 'legacy_adapter.py')
    translator = module('rigid_legacy_translator', frozen / 'legacy_translate.py')
    labeled = module('rigid_legacy_automatic', frozen / 'legacy_automatic.py')
    draft = 'ipra_automatic_goal_kernel_2026-11-06'
    compact = module('rigid_legacy_compact', ROOT / 'comparison' / 'sources' / draft / 'checker.py')
    corpus = json.loads((frozen / 'corpus.json').read_text())
    checks = []
    for record in corpus:
        if record['draft'] != draft:
            continue
        goal, proof, *context = record['document']
        recovered = adapter.to_automatic(goal, proof, context, compact.subst)
        require(accepted(labeled, goal, recovered, context),
                'Historical intermediate proof rejected: ' + record['file'])
        target_goal, target_proof, target_context = translator.forward(
            labeled, strict, goal, recovered, context)
        require(target_goal == syntax(goal, 1)
                and target_context == [syntax(item, 1) for item in context],
                'Historical translator changed the sequent: ' + record['file'])
        require(accepted(strict, target_goal, target_proof, target_context)
                and reference.accept_sequent(target_goal, target_proof, target_context),
                'Historical target proof rejected: ' + record['file'])
        checks.append({'file': record['file'], 'intermediate_accepted': True,
                       'target_accepted': True, 'named_oracle_accepted': True,
                       'sequent_preserved': True,
                       'target_certificate_sha256': digest([target_goal, target_proof, target_context])})
    return {'cases': len(checks), 'helpers': ['frozen/legacy_adapter.py',
                                             'frozen/legacy_translate.py'],
            'checks': checks}


def eq(left, right):
    return ['=', left, right]


def succ(value):
    return ['s', value]


TRUE = eq(0, 0)
FALSE = eq(0, succ(0))


def reflexivity(term):
    """A producer for a closed/rigid-parameter term; never trusted by checker."""
    major = eq(['r', 0, term, 0], term)
    return [major, 'r', eq(1, term), 'r']


REFL_ZERO = reflexivity(0)


def new_examples():
    nested = ['r', -1, -2, ['r', 2, 1, ['r', 4, -3, 5]]]
    return {
        'rigid_parameter_reflexivity.json': [eq(-1, -1), reflexivity(-1)],
        'rigid_parameter_exists.json': [['ex', eq(1, -1)], [-1, None]],
        'rigid_parameter_identity.json': [['pi', eq(1, -1), eq(1, -1)], [None]],
        'rigid_nested_recursor_reflexivity.json': [eq(nested, nested), reflexivity(nested)],
        'rigid_successor_counter.json':
            [eq(['r', succ(-1), -2, 2], -1), 'r'],
    }


def rule_cases():
    """Expected verdicts follow explicit rules, not a candidate-generated label."""
    result = []

    def add(name, goal, proof, expected, reason, context=(), demand=None):
        result.append({'name': name, 'goal': goal, 'proof': proof,
                       'context': list(context), 'strict': expected,
                       'demand': expected if demand is None else demand,
                       'reason': reason})

    add('derived_reflexivity', TRUE, REFL_ZERO, True,
        'Equality transport of the zero recursion equation yields 0=0.')
    add('wrong_conclusion', FALSE, REFL_ZERO, False,
        'The same proof has no conclusion 0=S0.')
    add('no_primitive_reflexivity_leaf', TRUE, None, False,
        'Reflexivity is derived and is not an extra leaf rule.')
    add('hypothesis', FALSE, None, True, 'An internal sequent can use its assumption.', [FALSE])
    add('missing_hypothesis', FALSE, None, False, 'No assumption is declared.')
    for annotation in (False, True, 4, -4, 'ignored', {}, [], ['unused', 1]):
        add('hypothesis_alias_' + str(len(result)), TRUE, annotation, True,
            'This annotation selects no earlier rule and denotes a context leaf.', [TRUE])

    pi_true = ['pi', TRUE, TRUE]
    bad_terms = [None, False, True, 0.0, 1.0, '', '0', 's', 'ss', [], {},
                 {'s': 0}, ['s'], ['s', 0, 0], ['r', 0, 0],
                 ['r', 0, 0, 0, 0], ['bad', 0], ['=', 0, 0]]
    for index, bad in enumerate(bad_terms):
        add(f'malformed_term_{index}', eq(0, bad), REFL_ZERO, False,
            'A goal must have exact numerical terms, including exact integer leaves.')
        add(f'dead_malformed_update_{index}', eq(['r', 0, 0, bad], 0), 'r', False,
            'The initializer is returned, but the unused update is still validated.')
        add(f'unused_universal_witness_{index}', TRUE,
            [pi_true, [None], bad, REFL_ZERO], False,
            'Strict checking validates an applied witness even when its slot is unused.',
            demand=True)
        add(f'existential_witness_{index}', ['ex', TRUE], [bad, REFL_ZERO], False,
            'Existential introduction validates its witness in both variants.')
    bad_formulas = [None, False, True, 0, 1, -1, 0.0, [], {}, ['=', 0],
                    ['=', 0, 0, 0], ['ex'], ['ex', TRUE, TRUE],
                    ['pi', TRUE], ['pi', TRUE, TRUE, TRUE], ['s', 0]]
    for index, bad in enumerate(bad_formulas):
        add(f'malformed_formula_{index}', bad, None, False,
            'A number, malformed constructor, or wrong sort is not a formula.')
        add(f'malformed_motive_{index}', TRUE, [TRUE, REFL_ZERO, bad, REFL_ZERO], False,
            'Equality transport requires a formula motive even if its slot is unused.')

    for parameter in (-1, -2, -9, -100000):
        add(f'parameter_reflexivity_{-parameter}', eq(parameter, parameter),
            reflexivity(parameter), True, 'Distinct negative codes are legal number parameters.')
        add(f'parameter_not_zero_counter_{-parameter}',
            eq(['r', parameter, 0, 0], 0), 'r', False,
            'A legal negative parameter is not the zero constructor.')
        add(f'parameter_not_zero_{-parameter}', eq(parameter, 0),
            reflexivity(parameter), False, 'Rigid parameters do not collapse to zero.')
    add('parameters_remain_distinct', eq(-1, -2), reflexivity(-1), False,
        'Two different rigid parameter names are distinct syntax.')
    add('zero_computation', eq(['r', 0, -1, -2], -1), 'r', True,
        'The actual zero counter returns its initializer, a rigid parameter.')
    add('wrong_initializer', eq(['r', 0, -1, -2], -2), 'r', False,
        'The zero equation does not return the update or a different parameter.')
    add('successor_previous_counter', eq(['r', succ(-1), -2, 2], -1), 'r', True,
        'Update slot 2 denotes the previous counter.')
    add('successor_previous_value', eq(['r', succ(-1), -2, 1], ['r', -1, -2, 1]),
        'r', True, 'Update slot 1 denotes the previous recursive value.')
    add('successor_swapped_slots', eq(['r', succ(-1), -2, 1], -1), 'r', False,
        'The previous value cannot be exchanged with the counter.')
    update = ['r', 0, 2, 3]
    add('nested_two_binder_substitution',
        eq(['r', succ(-1), -2, update], ['r', 0, -1, ['r', -1, -2, update]]),
        'r', True, 'Both recursive update binders are protected during substitution.')
    add('nested_two_binder_capture',
        eq(['r', succ(-1), -2, update], ['r', 0, -2, ['r', -1, -2, update]]),
        'r', False, 'Changing the substituted previous counter is rejected.')
    add('free_positive_counter', eq(['r', 1, 0, 0], 0), 'r', False,
        'A positive free variable is not a syntactic zero or successor.')
    add('unreduced_counter', eq(['r', ['r', 0, 0, 0], 0, 0], 0), 'r', False,
        'A single computation leaf does not perform recursive normalization.')

    guard = eq(1, 0)
    add('ordinary_introduction', ['pi', guard, guard], [None], True,
        'A nonmatching guard selects ordinary introduction.')
    add('matching_equation_introduction', pi_true, [None], True,
        'A vacuous equation admits the numerical introduction.')
    add('old_introduction_tag', pi_true, ['lam', None], False,
        'The canonical introduction certificate has one child and no opcode.')
    add('existential_parameter', ['ex', eq(1, -1)], [-1, None], True,
        'The new local number is assumed equal to the rigid witness.')
    add('existential_wrong_parameter', ['ex', eq(1, -1)], [-2, None], False,
        'The local witness equality is with the supplied distinct parameter.')
    add('existential_positive_parameter', ['ex', eq(1, succ(2))], [succ(1), None], True,
        'An ambient positive slot is lifted past the new local number.')
    add('existential_positive_capture', ['ex', eq(1, succ(1))], [succ(1), None], False,
        'The ambient witness slot cannot be captured by the fresh number.')
    add('rigid_parameter_under_binder', ['pi', TRUE, eq(-1, 0)], [None], True,
        'Binding a new number preserves rigid parameters.', [eq(-1, 0)])
    add('positive_parameter_under_binder', ['pi', TRUE, eq(2, 0)], [None], True,
        'An existing ambient slot shifts across the new binder.', [eq(1, 0)])
    add('universal_eigenvariable_capture', ['pi', TRUE, eq(1, 0)], [None], False,
        'An ambient assumption cannot become a statement about the fresh number.', [eq(1, 0)])
    ex_zero = ['ex', eq(1, 0)]
    ex_zero_proof = [0, None]
    add('existential_elimination', TRUE, [ex_zero, ex_zero_proof, REFL_ZERO], True,
        'The existential witness can be discarded when the conclusion is independent.')
    add('existential_eigenvariable_escape', eq(1, 0),
        [ex_zero, ex_zero_proof, None], False,
        'The opened witness is local and cannot appear as a free conclusion.')
    nested_leak = ['pi', TRUE, eq(2, 0)]
    nested_major = ['ex', nested_leak]
    add('nested_eigenvariable_escape', nested_leak, [nested_major, None, None], False,
        'Witness freshness is preserved below a further formula binder.', [nested_major])

    step_atomic = ['pi', eq(1, 0), eq(succ(1), 0)]
    add('literal_equation_induction', ['pi', TRUE, eq(1, 0)],
        [[step_atomic, None, 1, None]], True,
        'An equation induction step receives the equation at the current number.', [step_atomic])
    body = ['ex', eq(1, 2)]
    zero_body = ['ex', eq(1, 0)]
    successor_body = ['ex', eq(1, succ(2))]
    step_compound = ['pi', body, successor_body]
    add('forbidden_compound_induction', ['pi', zero_body, body],
        [[step_compound, None, 1, None]], False,
        'A compound matrix receives only its zero instance, not an induction hypothesis.',
        [step_compound])
    add('compound_numerical_cases', ['pi', zero_body, body], [[succ(1), None]], True,
        'The compound branch proves the successor case under its retained zero instance.')
    add('wrong_cases_guard', ['pi', TRUE, body], [[succ(1), None]], False,
        'A nonmatching guard does not authorize a successor-case conclusion.')
    add('valid_universal_elimination', TRUE, [pi_true, [None], -1, REFL_ZERO], True,
        'A legal rigid parameter can instantiate even a vacuous universal.')
    used_major = ['pi', eq(1, 1), eq(1, 1)]
    add('used_malformed_universal_witness', TRUE, [used_major, [None], None, REFL_ZERO], False,
        'Both variants reject an invalid witness whose slot is actually used.')
    add('failed_minor', TRUE, [pi_true, [None], 0, None], False,
        'A proved major does not supply a missing minor derivation.')
    add('failed_major_fallback', TRUE, [['ex', TRUE], None, None], True,
        'A false major permits a genuine hypothesis fallback.', [TRUE])
    add('failed_major_no_new_goal', FALSE, [['ex', TRUE], None, None], False,
        'Fallback cannot establish a goal absent from the context.', [TRUE])
    add('raising_major_no_fallback', TRUE, [['ex', TRUE], [False, REFL_ZERO], None], False,
        'An exception in a proposed major rejects, even when the goal is an assumption.', [TRUE])
    for index, proof in enumerate(([pi_true, [None]], [pi_true, [None], 0],
                                   [pi_true, [None], 0, REFL_ZERO, REFL_ZERO],
                                   [ex_zero, ex_zero_proof],
                                   [ex_zero, ex_zero_proof, REFL_ZERO, REFL_ZERO])):
        add(f'elimination_arity_{index}', TRUE, proof, False,
            'An active elimination has its exact stated arity.')
    return result


def audit_rules(strict, demand, reference):
    fixtures = rule_cases()
    checks = []
    for case in fixtures:
        goal, proof, context = case['goal'], case['proof'], case['context']
        actual = {
            'strict': accepted(strict, goal, proof, context),
            'demand': accepted(demand, goal, proof, context),
            'named_strict': reference.accept_sequent(goal, proof, context),
            'named_demand': reference.accept_sequent(goal, proof, context, strict_witness=False),
        }
        require(actual['strict'] == actual['named_strict'] == case['strict'],
                'Strict rule fixture failed: ' + case['name'] + ' ' + str(actual))
        require(actual['demand'] == actual['named_demand'] == case['demand'],
                'Demand rule fixture failed: ' + case['name'] + ' ' + str(actual))
        checks.append({'name': case['name'], **actual})
    (HERE / 'rule_cases.json').write_text(json.dumps(fixtures, indent=2) + '\n')
    return {'fixtures': len(fixtures),
            'strict_acceptances': sum(case['strict'] for case in fixtures),
            'strict_rejections': sum(not case['strict'] for case in fixtures),
            'demand_acceptances': sum(case['demand'] for case in fixtures),
            'internal_sequent_fixtures': sum(bool(case['context']) for case in fixtures),
            'strict_demand_difference': [case['name'] for case in fixtures
                                         if case['strict'] != case['demand']],
            'checks': checks}, fixtures


def audit_substitution(strict, reference):
    """Compare index substitution with simultaneous substitution of free names."""
    randomizer = random.Random(20261106)

    def term(depth, binders=0):
        if not depth or randomizer.randrange(4) == 0:
            return randomizer.choice([0, -1, -2, -17, -100000,
                                      *range(1, binders + 5)])
        if randomizer.randrange(2) == 0:
            return succ(term(depth - 1, binders))
        return ['r', term(depth - 1, binders), term(depth - 1, binders),
                term(depth - 1, binders + 2)]

    def formula(depth, binders=0):
        if not depth or randomizer.randrange(3) == 0:
            return eq(term(3, binders), term(3, binders))
        if randomizer.randrange(2):
            return ['ex', formula(depth - 1, binders + 1)]
        return ['pi', formula(depth - 1, binders + 1), formula(depth - 1, binders + 1)]

    samples = [
        (True, ['pi', eq(-1, ['r', 1, -2, ['r', 2, 1, 5]]),
                ['ex', eq(2, ['r', 1, -3, ['r', 2, 4, 7]])]]),
        (False, ['r', 1, -1, ['r', 2, 3, ['r', 4, -2, 7]]]),
        (False, -1), (False, -2), (False, 0), (False, 1),
    ]
    samples += [(bool(i % 2), formula(3) if i % 2 else term(4)) for i in range(1200)]
    records = []
    for index, (is_formula, raw) in enumerate(samples):
        protected_count = index % 4
        replacement_count = index % 4
        offset = randomizer.choice([-replacement_count, 0, 1, 2])
        environment = [term(2) for _ in range(replacement_count)] + [offset]
        oracle = reference.Oracle()
        protected = tuple(reference.Name(3, i) for i in range(protected_count))
        parse = oracle.formula if is_formula else oracle.term
        source = parse(raw, protected)
        inserted = [oracle.term(value) for value in environment[:-1]]
        replacements = {}
        for name in reference.free_names(source):
            if name.kind != 0:
                continue
            replacements[name] = (inserted[name.index] if name.index < replacement_count
                                  else reference.Var(reference.Name(0, name.index + offset)))
        expected = reference.substitute(source, replacements)
        output = strict.subst(raw, environment, protected_count, is_formula)
        actual = parse(output, protected)
        require(reference.same(actual, expected),
                'Named substitution mismatch at sample ' + str(index))
        records.append({'source': raw, 'formula': is_formula,
                        'protected': protected_count, 'environment': environment,
                        'output': output})
    return {'cases': len(records), 'seed': 20261106,
            'term_cases': sum(not x['formula'] for x in records),
            'formula_cases': sum(x['formula'] for x in records),
            'protected_depths': sorted({x['protected'] for x in records}),
            'replacement_counts': sorted({len(x['environment']) - 1 for x in records}),
            'evidence_sha256': digest(records),
            'method': 'Parse to distinct named binders; substitute free names simultaneously; '
                      'compare modulo alpha-equivalence. The oracle does not call candidate code.'}


def audit_cli(fixtures, examples):
    """Run actual isolated processes: normal Python and Python -O."""
    checks = []
    with tempfile.TemporaryDirectory(prefix='ipra-rigid-cli-') as folder:
        path = Path(folder) / 'input.json'
        for filename in ('checker.py', 'checker_demand.py'):
            demand_mode = filename == 'checker_demand.py'
            for optimized in (False, True):
                flags = ['-I', '-S', *(['-O'] if optimized else [])]

                def run(name, document, expected, raw=False, extra=()):
                    path.write_text(document if raw else json.dumps(document), encoding='utf-8')
                    process = subprocess.run([sys.executable, *flags, str(ROOT / filename),
                                              str(path), *extra], capture_output=True,
                                             text=True, timeout=20)
                    wanted = 'ACCEPT\n' if expected else 'REJECT\n'
                    passed = (process.returncode == (0 if expected else 1)
                              and process.stdout == wanted and not process.stderr)
                    checks.append({'name': name, 'checker': filename,
                                   'optimized': optimized, 'expected': expected,
                                   'exit_status': process.returncode, 'passed': passed})
                    require(passed, 'CLI failure: ' + name + ' ' + filename + ' ' + repr(process))

                for case in fixtures:
                    if not case['context']:
                        run(case['name'], [case['goal'], case['proof']],
                            case['demand' if demand_mode else 'strict'])
                for name, document in examples.items():
                    run('example_' + name, document, True)
                for index, document in enumerate((None, False, 3, [], [TRUE], {},
                                                   {'a': TRUE, 'p': REFL_ZERO}, '[]',
                                                   [TRUE, REFL_ZERO, []],
                                                   [TRUE, REFL_ZERO, FALSE])):
                    run('outer_record_' + str(index), document, False)
                for index, raw in enumerate(('', 'not json', '[', '[0,null] trailing',
                                             '{"goal":', '[NaN,null]')):
                    run('malformed_json_' + str(index), raw, False, raw=True)
                run('extra_cli_argument', [TRUE, REFL_ZERO], False, extra=('extra',))
    return {'runs': len(checks), 'normal_runs': sum(not x['optimized'] for x in checks),
            'optimized_runs': sum(x['optimized'] for x in checks),
            'strict_runs': sum(x['checker'] == 'checker.py' for x in checks),
            'demand_runs': sum(x['checker'] == 'checker_demand.py' for x in checks),
            'failures': [x for x in checks if not x['passed']], 'checks': checks}


def main():
    strict = module('rigid_strict_validation', ROOT / 'checker.py')
    demand = module('rigid_demand_validation', ROOT / 'checker_demand.py')
    reference = module('rigid_named_reference', HERE / 'independent_oracle.py')
    (ROOT / 'examples' / 'general').mkdir(parents=True, exist_ok=True)
    (ROOT / 'results').mkdir(exist_ok=True)
    corpus = audit_corpus(strict, demand, reference)
    legacy = audit_legacy_translators(strict, reference)
    rules, fixtures = audit_rules(strict, demand, reference)
    substitution = audit_substitution(strict, reference)
    examples = new_examples()
    for name, document in examples.items():
        goal, proof = document
        require(accepted(strict, goal, proof) and accepted(demand, goal, proof)
                and reference.accept_sequent(goal, proof), 'New example failed: ' + name)
        (ROOT / 'examples' / 'general' / name).write_text(
            json.dumps(document, separators=(',', ':')) + '\n')
    all_examples = {path.name: json.loads(path.read_text())
                    for path in sorted((ROOT / 'examples' / 'general').glob('*.json'))}
    cli = audit_cli(fixtures, all_examples)
    result = {
        'status': 'passed', 'python': sys.version,
        'kernel_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                          for name in ('checker.py', 'checker_demand.py')},
        'scope': 'Finite implementation validation; the mathematical metatheorems '
                 'are proved in the report, not machine formalized by these tests.',
        'corpus': corpus, 'legacy_translators': legacy,
        'rules': rules, 'substitution': substitution,
        'theorem_examples': len(all_examples), 'new_rigid_parameter_examples': len(examples),
        'cli': cli,
    }
    (ROOT / 'results' / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
    summary = {
        'status': result['status'], 'corpus_records': corpus['records'],
        'distinct_converted_sequents': corpus['distinct_converted_sequents'],
        'legacy_translator_cases': legacy['cases'],
        'rule_fixtures': rules['fixtures'],
        'strict_rule_acceptances': rules['strict_acceptances'],
        'strict_rule_rejections': rules['strict_rejections'],
        'named_substitution_cases': substitution['cases'],
        'theorem_examples': len(all_examples), 'cli_runs': cli['runs'],
    }
    (ROOT / 'results' / 'validation_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    return result


if __name__ == '__main__':
    main()
