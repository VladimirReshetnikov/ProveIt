#!/usr/bin/env python3
"""Reproduce finite-proof translation checks, including nested binders.

This validation program and its generators are outside the trusted kernel.
It checks both each input theorem and the output in a frozen older checker.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import random
import sys


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import translate_parameters as translation


def digest(value):
    data = json.dumps(value, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def equal(left, right):
    return ["=", left, right]


def rec(counter, initial, update):
    return ["r", counter, initial, update]


def refl(term, source):
    auxiliary = rec(0, term, 0)
    motive = equal(1, source.subst(term, formula=False))
    return [equal(term, term), [equal(auxiliary, term), "r", motive, "r"]]


def computation(counter, initial, update, source):
    if counter == 0:
        rhs = initial
    else:
        tag, predecessor = counter
        if tag != "s":
            raise ValueError("Expected zero or successor")
        rhs = source.subst(update,
                           [rec(predecessor, initial, update), predecessor, -2],
                           formula=False)
    return [equal(rec(counter, initial, update), rhs), "r"]


def named_examples(source):
    examples = {}
    nested = rec(7, -2, rec(0, -4, ["s", 1]))
    examples["zero_nested_recursors"] = computation(
        0, nested, rec(1, -3, 2), source)
    examples["successor_nested_recursors"] = computation(
        ["s", -5], nested, rec(1, ["s", -3], rec(0, 2, 4)), source)
    examples["mixed_parameter_reflexivity"] = refl(rec(5, -1, ["s", -2]), source)
    examples["sparse_large_rigid_label"] = [["ex", equal(1, -(10 ** 80))],
                                            [-(10 ** 80), None]]

    parameter = -7
    existential = ["ex", equal(1, parameter)]
    target, minor = refl(parameter, source)
    examples["existential_elimination"] = [
        target, [existential, [parameter, None], minor]]

    truth = equal(0, 0)
    universal = ["pi", truth, ["ex", equal(1, rec(2, parameter, parameter))]]
    examples["universal_existential"] = [
        universal, [[rec(1, parameter, parameter), None]]]

    body = equal(rec(1, -11, -11), -11)
    examples["automatic_equation_induction"] = [
        ["pi", source.subst(body, [0, 0]), body], ["r"]]

    body = ["ex", equal(1, rec(2, -13, -13))]
    examples["automatic_compound_cases"] = [
        ["pi", source.subst(body, [0, 0]), body],
        [[rec(["s", 1], -13, -13), None]]]

    # Equality's motive has one implicit slot, then Pi and Exists add two
    # lexical slots.  The recursor update adds two more; the inner recursor
    # tests another pair of bound slots.  The rigid parameter must survive all.
    parameter = -17
    left = rec(0, parameter, 0)
    motive = ["pi", truth, ["ex", equal(
        1, rec(2, 3, ["s", rec(0, parameter, 1)]))]]
    left_instance = source.subst(motive, [left, -1])
    right_instance = source.subst(motive, [parameter, -1])
    witness_under_pi = source.subst(left_instance[2][1][2], [0, -1], formula=False)
    minor = [[witness_under_pi, None]]
    examples["equality_motive_nested_binders"] = [
        right_instance, [equal(left, parameter), "r", motive, minor]]

    # A rigid label and an ordinary positive free parameter occur together.
    # An injective translation must preserve the ordinary-introduction choice.
    guard = equal(-1, -1)
    body = equal(2, 2)
    examples["ordinary_guard_and_free_parameter"] = [
        ["pi", guard, body], [refl(2, source)[1]]]
    return examples


def random_term(rng, depth):
    if depth == 0 or rng.randrange(4) == 0:
        return rng.choice([-101, -9, -1, 0, 1, 2, 3, 17])
    if rng.randrange(2):
        return ["s", random_term(rng, depth - 1)]
    return rec(*(random_term(rng, depth - 1) for _ in range(3)))


def plus_one(value):
    """The arity certificate grammar has integer literals only as term leaves."""
    if type(value) is int:
        return value + 1
    if isinstance(value, list):
        return [plus_one(item) for item in value]
    return value


def rigidify_baseline(payload, source, target):
    """Turn external positive parameters into rigid names, untrustedly.

    This auxiliary direction is used to exercise the elimination translator
    on the historical corpus.  It does not appear in the proof checker.
    """
    if not target.check(*payload):
        raise ValueError("Frozen checker rejected converted historical proof")

    def rigidify(number, eigen_depth, lexical_depth):
        external = number - eigen_depth - lexical_depth
        return -external if number > 0 and external > 0 else number

    goal, proof = payload
    result = [
        translation.map_expression(goal, rigidify, 0),
        translation.map_derivation(goal, proof, [], 0, target, rigidify,
                                   source_computation=[], target_computation="r"),
    ]
    if not source.check(*result, []):
        raise ValueError("Candidate rejected rigidified historical proof")
    return result


def main():
    source_path = ROOT / "checker.py"
    source = translation.load_module(source_path, "translation_test_source")
    target = translation.load_module(translation.TARGET, "translation_test_target")
    fixture_dir = ROOT / "examples" / "parameter_translations"
    fixture_dir.mkdir(parents=True, exist_ok=True)
    results = []

    def exercise(name, payload, category, save=False):
        translated, metadata = translation.translate_theorem(payload, source, target)
        if any(number < 0 for number in translation.integers(translated)):
            raise AssertionError("A rigid label remained in the target proof")
        record = {
            "name": name,
            "category": category,
            "source_accepted": metadata["source_accepted"],
            "target_accepted": metadata["target_accepted"],
            "rigid_labels": metadata["rigid_labels_in_input"],
            "fresh_base": metadata["fresh_base"],
            "source_certificate_sha256": digest(payload),
            "translated_certificate_sha256": digest(translated),
        }
        results.append(record)
        if save:
            for suffix, data in [("source", payload), ("translated", translated)]:
                path = fixture_dir / f"{name}_{suffix}.json"
                path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
            record["source_fixture"] = str(
                (fixture_dir / f"{name}_source.json").relative_to(ROOT))
            record["translated_fixture"] = str(
                (fixture_dir / f"{name}_translated.json").relative_to(ROOT))

    for name, payload in named_examples(source).items():
        exercise(name, payload, "named_binding_regression", save=True)

    rng = random.Random(20261106)
    for index in range(24):
        initial = random_term(rng, 3)
        update = random_term(rng, 4)
        predecessor = random_term(rng, 2)
        exercise(f"generated_zero_{index:02}", computation(0, initial, update, source),
                 "generated_nested_computation")
        exercise(f"generated_successor_{index:02}",
                 computation(["s", predecessor], initial, update, source),
                 "generated_nested_computation")

    corpus_path = ROOT / "validation" / "frozen" / "corpus.json"
    corpus = json.loads(corpus_path.read_text(encoding="utf-8"))
    selected = [record for record in corpus
                if record["draft"] == "ipra_arity_calculus_2026-11-06"]
    if len(selected) != 19:
        raise AssertionError("Expected the 19 closed historical arity certificates")
    for record in selected:
        baseline_payload = plus_one(record["document"])
        payload = rigidify_baseline(baseline_payload, source, target)
        exercise(record["file"], payload, "rigidified_historical_theorem")

    rejected = []
    malformed = {
        "false_arithmetic_claim": [equal(0, ["s", 0]), "r"],
        "unused_invalid_witness": [["ex", equal(0, 0)], [False, None]],
        "not_a_formula": [-1, None],
        "external_context_at_theorem_boundary": [equal(-1, -1), None, equal(-1, -1)],
    }
    for name, payload in malformed.items():
        try:
            translation.translate_theorem(payload, source, target)
        except Exception:
            rejected.append(name)
        else:
            raise AssertionError(f"Translator accepted invalid source: {name}")

    output = {
        "scope": "Finite executable translation checks, not a formalized universal correctness proof",
        "source_checker_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest(),
        "target_checker_sha256": hashlib.sha256(translation.TARGET.read_bytes()).hexdigest(),
        "translator_sha256": hashlib.sha256((ROOT / "translate_parameters.py").read_bytes()).hexdigest(),
        "successful_translations": len(results),
        "named_binding_regressions": sum(r["category"] == "named_binding_regression" for r in results),
        "generated_nested_computations": sum(r["category"] == "generated_nested_computation" for r in results),
        "rigidified_historical_theorems": sum(r["category"] == "rigidified_historical_theorem" for r in results),
        "rejected_invalid_sources": rejected,
        "results": results,
    }
    destination = ROOT / "results" / "parameter_translations.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in output.items() if key != "results"}, indent=2))


if __name__ == "__main__":
    main()
