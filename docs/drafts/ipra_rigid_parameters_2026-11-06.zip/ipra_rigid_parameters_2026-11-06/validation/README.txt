VALIDATION SCOPE AND REPRODUCTION
=================================

Run from any directory:

  python3 validation/validate.py

The path above is relative to the archive root. The runner needs only the
Python standard library. It writes results/validation.json and the compact
results/validation_summary.json, and regenerates examples/general/*.json.
No validator, oracle, translator, or proof producer is imported by checker.py.

ACTUAL COMPLETED CHECKS

1. All 112 top-level JSON example files from all six pinned draft archives
   are frozen in validation/frozen/corpus.json. Each original is checked by
   its own unchanged source checker in comparison/sources/. A format adapter
   changes only the zero/index notation and computation certificate marker.
   Every resulting sequent is checked by both new kernels and by the named
   reference checker. There are 35 distinct resulting certificate/sequent
   trees; the count of 112 includes examples repeated between archives.
   Of the 112 records, 97 have no external assumptions and 15 are internal
   open-sequent tests. The new public CLI remains theorem-only.

2. Eighteen automatic-goal examples also pass through the unchanged older
   adapter and structural forward translator in frozen/legacy_*.py. The
   intermediate labeled-calculus proof and final candidate proof are both
   rechecked. This exercises historical translators as untrusted producers;
   their output is never accepted on the authority of the translator.

3. There are 167 explicitly labeled rule and boundary fixtures. The strict
   kernel accepts 29 and rejects 138. The demand kernel additionally accepts
   18 applied universal eliminations whose malformed witness fields are
   syntactically unused by both matrices. Both kernels reject malformed witnesses
   when used, malformed existential witnesses, and malformed equality motives.
   Eighteen fixtures use well-formed internal contexts to test individual
   rules; these do not add an external-context public interface.

   The fixtures distinguish every negative parameter from numerical zero and
   from other parameters; exercise simultaneous substitution under two nested
   recursion binders; reject incorrect recursion reducts; reject arbitrary
   compound induction; check the compound numerical-case guard; and reject
   existential eigenvariable escape and capture under universal introduction.
   Exact labels and explanations are retained in rule_cases.json.

4. The substitution routine passes 1,206 independent comparisons: 605 number
   terms and 601 formulas. These include explicit mixed-binder regressions
   and deterministic generated trees (seed 20261106), protected depths 0--3,
   replacement counts 0--3, and both rigid names and positive variable slots.
   The oracle parses to distinct named binders, performs simultaneous free-
   name substitution, and compares modulo alpha-equivalence. It does not call
   or reproduce the candidate's index-shifting substitution algorithm.

5. The actual complete command-line programs pass 760 isolated subprocess
   runs: 380 normally and 380 with Python -O, split equally between the two
   kernels. These include theorem fixtures, all 24 examples/general theorem
   certificates, malformed JSON, extra outer record fields, and extra command
   arguments. Each run checks both the exit status and exact verdict text.

THE NAMED REFERENCE CHECKER

independent_oracle.py is adapted from the arity draft's independent oracle.
Its internal syntax uses dataclasses, distinct named variables, separately
implemented substitution, and alpha-equivalence. It allocates an eigenname
when a binder is opened and does not shift assumptions' indices. Adaptations
assign zero to code 0, positive slots to 1-based indices, negative integers to
distinct rigid names, and the string r to computation leaves. Provenance and
source hashes are recorded in frozen/provenance.json. The inherited MIT
notice is retained in the archive's LICENSE_SOURCE.txt.

LIMITS

These tests are finite implementation evidence. They are not Lean/Rocq
formalizations of soundness, completeness, primitive-recursion uniqueness, or
bi-interpretability. The mathematical metatheorems are argued in the report.
Very large certificates may exceed host memory, recursion, or time limits;
an exception or process interruption is not an acceptance.

