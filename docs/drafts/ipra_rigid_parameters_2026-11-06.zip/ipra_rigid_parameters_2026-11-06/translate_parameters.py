#!/usr/bin/env python3
"""Untrusted finite-proof elimination of rigid negative parameter labels.

Input is a theorem certificate [goal, proof] for checker.py.  Output is a
theorem certificate for the frozen strict goal-only checker.  The latter
uses zero = 0, positive de Bruijn indices, and [] for a computation leaf.

This program is not imported by checker.py and is outside its acceptance
boundary.  Every output is independently checked by the frozen target.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
from typing import Any, Callable


ROOT = Path(__file__).resolve().parent
TARGET = (
    ROOT / "comparison" / "sources" / "ipra_goal_only_2026-11-06" / "checker.py"
)
SCOPES = ({"s": (0,), "r": (0, 0, 2)},
          {"=": (0, 0), "pi": (1, 1), "ex": (1,)})


def load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load checker: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def integers(value: Any):
    """Enumerate integer literals, including irrelevant certificate fields."""
    if type(value) is int:
        yield value
    elif isinstance(value, list):
        for item in value:
            yield from integers(item)
    elif isinstance(value, dict):
        for item in value.values():
            yield from integers(item)


def map_expression(
    expression: Any,
    integer_map: Callable[[int, int, int], int],
    eigen_depth: int,
    lexical_depth: int = 0,
    formula: bool = True,
) -> Any:
    """Map leaves with explicit proof depth and lexical binding depth.

    An equality motive has an implicit distinguished slot, so callers
    translate it with lexical_depth = 1.  Ordinary witness terms use 0.
    """
    if type(expression) is int and not formula:
        return integer_map(expression, eigen_depth, lexical_depth)
    tag, *children = expression
    widths = SCOPES[formula][tag]
    return [tag, *(
        map_expression(child, integer_map, eigen_depth,
                       lexical_depth + width, width == 1)
        for child, width in zip(children, widths, strict=True)
    )]


def map_derivation(
    goal: Any,
    proof: Any,
    context: list[Any],
    eigen_depth: int,
    source: Any,
    integer_map: Callable[[int, int, int], int],
    source_computation: Any = "r",
    target_computation: Any = None,
) -> Any:
    """Translate an already accepted derivation; do not establish validity.

    The complete source certificate is checked before this function runs.
    Hypotheses are canonicalized first.  Hence an accepted remaining
    elimination necessarily has a successfully proved major premise.
    """
    if target_computation is None:
        target_computation = []

    def expression(value, depth=0, formula=True):
        return map_expression(value, integer_map, eigen_depth, depth, formula)

    def descend(a, p, g=context, e=eigen_depth):
        return map_derivation(a, p, g, e, source, integer_map,
                              source_computation, target_computation)

    def lifted_context(local):
        return [*(source.subst(item) for item in context), local]

    if goal in context:
        return None

    match (goal, proof):
        case [["pi", guard, body], [minor]]:
            if guard == source.subst(body, [0, 0]):
                guard = body if body[0] == "=" else guard
                body = source.subst(body, [["s", 1], 0])
            return [descend(body, minor, lifted_context(guard), eigen_depth + 1)]

        case [["ex", body], [witness, minor]]:
            local = ["=", 1, source.subst(witness, formula=False)]
            return [expression(witness, formula=False),
                    descend(body, minor, lifted_context(local), eigen_depth + 1)]

        case [_, [[tag, *parts] as major, major_proof, *arguments]]:
            translated_major = expression(major)
            translated_proof = descend(major, major_proof)
            if tag == "ex":
                minor, = arguments
                local, = parts
                translated_minor = descend(source.subst(goal), minor,
                                           lifted_context(local), eigen_depth + 1)
                return [translated_major, translated_proof, translated_minor]

            annotation, minor = arguments
            antecedent, consequent = (
                source.subst(annotation, [part, -1]) if tag == "="
                else source.subst(part, [annotation, -1])
                for part in parts
            )
            if consequent != goal:
                raise ValueError("Source elimination does not conclude its goal")
            translated_annotation = expression(
                annotation, depth=int(tag == "="), formula=tag == "="
            )
            return [translated_major, translated_proof, translated_annotation,
                    descend(antecedent, minor)]

        case [["=", ["r", _, _, _], _], _] if proof == source_computation:
            return target_computation

        case _:
            raise ValueError("Unrecognized accepted source derivation")


def translate_theorem(payload: Any, source: Any, target: Any):
    """Return an independently checked target theorem and a renaming record."""
    if not isinstance(payload, list) or len(payload) != 2:
        raise ValueError("Expected exactly [goal, proof]")
    goal, proof = payload
    if not source.check(goal, proof, []):
        raise ValueError("Source checker rejected the theorem")

    literals = set(integers(payload))
    maximum = max([0, *(number for number in literals if number > 0)])
    base = maximum + 1
    labels = sorted((number for number in literals if number < 0), reverse=True)
    root_indices = {label: base + rank for rank, label in enumerate(labels)}

    def replace(number, eigen_depth, lexical_depth):
        if number < 0:
            return root_indices[number] + eigen_depth + lexical_depth
        return number

    translated = [
        map_expression(goal, replace, 0),
        map_derivation(goal, proof, [], 0, source, replace),
    ]
    if not target.check(*translated):
        raise ValueError("Frozen target checker rejected the translated theorem")

    metadata = {
        "source_accepted": True,
        "target_accepted": True,
        "maximum_positive_literal": maximum,
        "fresh_base": base,
        "rigid_labels_in_input": len(labels),
        "renaming": [
            {"rigid_label": label, "target_root_index": root_indices[label]}
            for label in labels
        ],
        "rule": "target index = target_root_index + proof eigenvariable depth + lexical binding depth",
        "equality_motive_extra_depth": 1,
        "target_computation_certificate": [],
        "claim": "Checked finite proof translation; not a machine-checked metatheorem",
    }
    return translated, metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--metadata", type=Path)
    parser.add_argument("--source-checker", type=Path, default=ROOT / "checker.py")
    parser.add_argument("--target-checker", type=Path, default=TARGET)
    args = parser.parse_args()
    source = load_module(args.source_checker, "rigid_source_checker")
    target = load_module(args.target_checker, "frozen_target_checker")
    payload = json.loads(args.input.read_text(encoding="utf-8"))
    translated, metadata = translate_theorem(payload, source, target)
    args.output.write_text(json.dumps(translated, separators=(",", ":")) + "\n",
                           encoding="utf-8")
    if args.metadata:
        args.metadata.write_text(json.dumps(metadata, indent=2) + "\n",
                                 encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
