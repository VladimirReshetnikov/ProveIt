"""Automatic one-premise introduction; demand-validated theorem checker."""
import json
import sys

SCOPES = ({'s': (0,), 'r': (0, 0, 2)},
          {'=': (0, 0), 'pi': (1, 1), 'ex': (1,)})

def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int:
        if formula or a < -1:
            raise ValueError
        i = a - d
        return a if i < 0 else subst(env[i], (d,), formula=False) if i < len(env) - 1 else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1)
                   for b, width in zip(args, SCOPES[formula][tag], strict=True))]

def check(a, p, g):
    subst(a)
    match (a, p):
        case [['pi', h, b], [q]]:
            if h == subst(b, [-1, 0]):
                h = b if b[0] == '=' else h
                b = subst(b, [['s', 0], 0])
        case [['ex', b], [t, q]]:
            h = ['=', 0, subst(t, formula=False)]
        case [_, [[tag, *parts] as m, r, *args]] if check(m, r, g):
            if tag == 'ex':
                b, q, h = subst(a), *args, *parts
            else:
                t, q = args
                b, c = (subst(t, [v, -1]) if tag == '=' else subst(v, [t, -1]) for v in parts)
                return c == a and check(b, q, g)
        case [['=', ['r', n, t, h], b], 'r']:
            if n != -1:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return b == t
        case _:
            return a in g
    return check(b, q, [*map(subst, g), h])

if __name__ == '__main__':
    try:
        _, path = sys.argv
        with open(path, encoding='utf-8') as stream:
            if not check(*json.load(stream), []):
                raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
