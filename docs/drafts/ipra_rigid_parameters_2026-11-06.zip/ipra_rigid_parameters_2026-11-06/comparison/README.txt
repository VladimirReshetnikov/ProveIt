REPRODUCIBLE COMPARISON WITH THE SIX CURRENT DRAFTS
================================================

Snapshot
--------

Repository: VladimirReshetnikov/ProveIt
Commit: fa581763b2bb75e8ba055da8e56280c9fd5dd890
Directory: docs/drafts

The six archives at that snapshot contain thirteen complete top-level
checker programs. Every strict/demand and theorem/open companion is counted.
The current checker source, rather than earlier numbers quoted by the
embedded reports, is the comparison baseline.

manifest.json records each original archive's repository path, pinned URL,
Git blob SHA-1, size, and SHA-256. It also records each copied checker member's
exact original archive path and SHA-256. source_snapshot.json preserves the
initial six-file directory manifest. The downloaded archives reproduced their
Git blob hashes. Their thirteen checker members are copied without edits in
sources/. The archives themselves are not repeated in this deliverable.

Run
---

From the package root:

  python3 comparison/measure.py

The program uses only the Python standard library and works offline. It
parses, but does not import or execute, either baseline or candidate code.
It verifies every frozen checker hash before calculating a comparison.
It writes the following files under results/:

  metrics.json                 Complete provenance, measurements, and gates.
  metrics.csv                  One row per baseline and candidate program.
  numbers.tex                  Numeric macros for the article.
  comparison_table.tex         Complete-program summary.
  comparison_core_table.tex    Uniform core-only summary.
  baseline_table.tex           All thirteen complete baseline programs.
  core_baseline_table.tex      All thirteen uniformly extracted cores.

All four gates must pass: each new candidate must be strictly smaller in
every declared whole-program coordinate and every declared core coordinate.
A nonzero exit indicates a changed source fixture or a failed size claim.

Measurement conventions
-----------------------

The measurement definition follows the arity draft's comparison/measure.py:

* Source tokens exclude comments, whitespace, indentation/newline tokens,
  the tokenizer's end marker, and leading module/class/function docstrings.
  Other string literals, including the scope table, remain counted.
* AST nodes count every node in ast.walk after removing those docstrings.
* Normalized tokens and bytes use ast.unparse of that same complete AST,
  followed by one final newline. Byte counts use UTF-8.
* Raw bytes count the exact entire file, including comments, docstrings,
  imports, command-line code, and whitespace.
* The supplementary core comparison removes top-level imports and the
  conventional if __name__ == '__main__' wrapper identically from every
  program. Every remaining declaration, table, helper, and validation
  operation is retained. It does not select only favored functions.

The recorded run uses CPython 3.12.14. Python's JSON parser and ordinary
standard runtime are common dependencies of the compared programs.

The minima form a coordinatewise envelope. No one previous program needs
to attain every minimum. The most demanding comparison includes demand
programs and theorem/open interfaces together, even though the new primary
candidate validates every active witness and has a theorem-only interface.

Limits and interpretation
-------------------------

The measured reduction is a finite-corpus implementation result. It is not
an absolute lower-bound theorem for all presentations of intuitionistic
primitive recursive arithmetic or for all programming languages.

Normalized and raw byte counts depend on identifier spellings, string
representations, formatting, and Python version. Renaming a variable can
change a byte count without changing the theory. No identifiers were
shortened for this comparison. Token and AST measurements provide additional
evidence less sensitive to such spelling choices; none is a canonical
language-independent complexity measure.

The primary kernel combines the implicit-certificates draft's validated
traversal and proof dispatch, the goal-only draft's printable scope strings,
and the arity draft's theorem interface. Its new syntax gives every negative
integer a defined role as a rigid free numerical parameter. Zero remains
integer 0; positive integers remain one-based de Bruijn slots. The article
justifies that syntax change by injective parameter translation. It should
not be described as deleting an arithmetic axiom or weakening validation of
the old grammar. The optional demand companion removes the separate
elimination-annotation precheck. A universal witness ignored by both matrices
is then an unused annotation; replacing it by zero gives a strict proof.
The acceptance-boundary distinction is explained in the article and tested
separately.

Source licensing
----------------

The inherited archive license is MIT No Attribution (SPDX: MIT-0), reproduced
unchanged in LICENSE_SOURCE.txt. It is not the ordinary attribution-required
MIT license. The manifest and article retain provenance voluntarily.
