"""Reproduce the complete-program and uniform core comparisons offline.

Only comments and leading docstrings are omitted from executable token and
AST measurements. The core comparison additionally removes every top-level
import and the conventional command-line main guard, identically for every
source. It retains all other declarations, tables, and helper functions.
Neither baseline nor candidate checkers are imported or executed here.

The measurement definition follows the frozen arity draft's measure.py.
"""
from pathlib import Path
import ast
import csv
import hashlib
import io
import json
import platform
import sys
import tokenize

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RESULTS = ROOT / 'results'
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes',
          'normalized_bytes', 'raw_bytes')
CORE_FIELDS = FIELDS[:-1]
IGNORED_TOKENS = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}
MACROS = {
    'source_tokens': 'Tokens', 'normalized_tokens': 'NormTokens',
    'ast_nodes': 'AST', 'normalized_bytes': 'Bytes', 'raw_bytes': 'Raw',
}
CANDIDATES = (
    ('primary', 'checker.py', 'Strict theorem checker', 'strict'),
    ('demand', 'checker_demand.py', 'Demand theorem checker', 'demand'),
)


def is_main_guard(node):
    return (
        isinstance(node, ast.If)
        and isinstance(node.test, ast.Compare)
        and isinstance(node.test.left, ast.Name)
        and node.test.left.id == '__name__'
        and len(node.test.ops) == len(node.test.comparators) == 1
        and isinstance(node.test.ops[0], ast.Eq)
        and isinstance(node.test.comparators[0], ast.Constant)
        and node.test.comparators[0].value == '__main__'
    )


def source_span(node):
    first = min([node.lineno]
                + [item.lineno for item in getattr(node, 'decorator_list', [])])
    return ((first, 0), (node.end_lineno, node.end_col_offset))


def measure(path):
    raw = Path(path).read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    omitted = []
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                              ast.AsyncFunctionDef))
                and node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            doc = node.body.pop(0)
            omitted.append(((doc.lineno, doc.col_offset),
                            (doc.end_lineno, doc.end_col_offset)))

    def contains(span, token):
        start, end = span
        return start <= token.start and token.end <= end

    def count(text, excluded=(), retained=None):
        return sum(
            token.type not in IGNORED_TOKENS
            and not any(contains(span, token) for span in excluded)
            and (retained is None
                 or any(contains(span, token) for span in retained))
            for token in tokenize.generate_tokens(io.StringIO(text).readline)
        )

    normalized = ast.unparse(tree) + '\n'
    core_body = [node for node in tree.body
                 if not isinstance(node, (ast.Import, ast.ImportFrom))
                 and not is_main_guard(node)]
    core = ast.Module(body=core_body, type_ignores=[])
    normalized_core = ast.unparse(core) + '\n'
    retained = [source_span(node) for node in core_body]
    return {
        'sha256': hashlib.sha256(raw).hexdigest(),
        'source_tokens': count(source, omitted),
        'normalized_tokens': count(normalized),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'raw_bytes': len(raw),
        'core': {
            'source_tokens': count(source, omitted, retained),
            'normalized_tokens': count(normalized_core),
            'ast_nodes': sum(1 for _ in ast.walk(core)),
            'normalized_bytes': len(normalized_core.encode('utf-8')),
        },
    }


def envelope(rows, fields):
    if not rows:
        raise ValueError('Empty baseline class')
    return {field: min(row[field] for row in rows) for field in fields}


def below(row, bounds):
    return {field: row[field] < limit for field, limit in bounds.items()}


def write_csv(result):
    fields = ['group', 'label', 'source', 'interface', 'witness_validation',
              'sha256', *FIELDS, *('core_' + field for field in CORE_FIELDS)]
    with (RESULTS / 'metrics.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        groups = [*result['baselines'], *result['candidates'].values()]
        for row in groups:
            output = {key: row.get(key, '') for key in fields}
            output.update({'core_' + key: value
                           for key, value in row['core'].items()})
            writer.writerow(output)


def tex_escape(text):
    return text.replace('&', r'\&').replace('_', r'\_').replace('%', r'\%')


def write_table(path, rows, core=False):
    fields = ('ast_nodes', 'source_tokens', 'normalized_tokens',
              'normalized_bytes') + (() if core else ('raw_bytes',))
    headings = ['Presentation', 'AST', 'Source tokens', 'Norm. tokens',
                'Norm. bytes'] + ([] if core else ['Raw bytes'])
    lines = [r'{\small', r'\setlength{\tabcolsep}{4pt}',
             r'\begin{tabular}{l' + 'r' * len(fields) + '}',
             r'\toprule', ' & '.join(headings) + r' \\', r'\midrule']
    for label, row in rows:
        if row is None:
            lines.append(r'\midrule')
        else:
            values = [tex_escape(label), *(str(row[field]) for field in fields)]
            lines.append(' & '.join(values) + r' \\')
    lines.extend([r'\bottomrule', r'\end{tabular}', '}'])
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8')


def write_tex(result):
    summaries = [('Current coordinatewise minimum', result['envelope']),
                 ('New strict theorem checker', result['candidates']['primary']),
                 ('New demand theorem checker', result['candidates']['demand'])]
    core_summaries = [
        ('Current coordinatewise core minimum', result['core_envelope']),
        ('New strict theorem core', result['candidates']['primary']['core']),
        ('New demand theorem core', result['candidates']['demand']['core']),
    ]
    write_table(RESULTS / 'comparison_table.tex', summaries)
    write_table(RESULTS / 'comparison_core_table.tex', core_summaries, core=True)
    write_table(RESULTS / 'baseline_table.tex',
                [(row['label'], row) for row in result['baselines']]
                + [('', None)] + summaries)
    write_table(RESULTS / 'core_baseline_table.tex',
                [(row['label'], row['core']) for row in result['baselines']]
                + [('', None)] + core_summaries, core=True)
    lines = [r'\newcommand{\BaselinePrograms}{' + str(len(result['baselines'])) + '}',
             r'\newcommand{\BaselineArchives}{' + str(result['archive_count']) + '}',
             r'\newcommand{\SnapshotCommit}{' + result['commit'] + '}']
    rows = [('Envelope', result['envelope']),
            ('CoreEnvelope', result['core_envelope']),
            ('Strict', result['candidates']['primary']),
            ('CoreStrict', result['candidates']['primary']['core']),
            ('Demand', result['candidates']['demand']),
            ('CoreDemand', result['candidates']['demand']['core'])]
    for prefix, row in rows:
        for field, suffix in MACROS.items():
            if field in row:
                lines.append('\\newcommand{\\' + prefix + suffix + '}{'
                             + str(row[field]) + '}')
    (RESULTS / 'numbers.tex').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def main():
    RESULTS.mkdir(exist_ok=True)
    manifest = json.loads((HERE / 'manifest.json').read_text(encoding='utf-8'))
    baselines = []
    for entry in manifest['programs']:
        metrics = measure(HERE / entry['source'])
        if metrics['sha256'] != entry['source_sha256']:
            raise ValueError('Changed frozen baseline source: ' + entry['source'])
        baselines.append({'group': 'baseline', **entry, **metrics})
    candidates = {}
    for name, filename, label, policy in CANDIDATES:
        candidates[name] = {
            'group': 'candidate', 'source': filename, 'label': label,
            'interface': 'theorem', 'witness_validation': policy,
            **measure(ROOT / filename),
        }
    bounds = envelope(baselines, FIELDS)
    core_bounds = envelope([row['core'] for row in baselines], CORE_FIELDS)
    reductions = {name: below(row, bounds) for name, row in candidates.items()}
    core_reductions = {name: below(row['core'], core_bounds)
                       for name, row in candidates.items()}
    gates = {name + '_below_all_complete_programs': all(values.values())
             for name, values in reductions.items()}
    gates.update({name + '_core_below_all_reference_cores': all(values.values())
                  for name, values in core_reductions.items()})
    result = {
        'status': 'passed' if all(gates.values()) else 'failed',
        'python': sys.version, 'python_implementation': platform.python_implementation(),
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'archive_count': len(manifest['archives']), 'baselines': baselines,
        'candidates': candidates, 'envelope': bounds, 'core_envelope': core_bounds,
        'strictly_below': reductions, 'core_strictly_below': core_reductions,
        'gates': gates,
        'qualification': (
            'Coordinatewise minima over the 13 frozen complete programs in six current '
            'drafts, including strict/demand and theorem/open interfaces. These are '
            'finite-corpus source-size comparisons, not an absolute minimality theorem. '
            'Core comparison removes imports and CLI identically from every program. '
            'Python, its JSON parser, and the standard runtime are common dependencies. '
            'Byte counts depend on identifier spellings, string encoding, formatting, '
            'and Python normalization version; identifiers were not shortened. '
            'Token and AST counts provide additional, less spelling-sensitive evidence.'
        ),
    }
    (RESULTS / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    write_csv(result)
    write_tex(result)
    print(json.dumps({
        'status': result['status'], 'baseline_programs': len(baselines),
        'envelope': bounds, 'core_envelope': core_bounds,
        'candidates': {name: {key: row[key] for key in (*FIELDS, 'core')}
                       for name, row in candidates.items()},
        'gates': gates,
    }, indent=2))
    if not all(gates.values()):
        raise SystemExit('The claimed strict size reduction no longer holds.')
    return result


if __name__ == '__main__':
    main()
