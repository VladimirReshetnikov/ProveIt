#!/usr/bin/env python3
"""Reproducible formula metrics and bounded checks; not a theorem prover."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json


@dataclass(frozen=True)
class Node:
    kind: str
    args: tuple["Node", ...] = ()

    def size(self):
        return 1 + sum(a.size() for a in self.args)

    def count(self, kind):
        return int(self.kind == kind) + sum(a.count(kind) for a in self.args)


def node(kind, *args):
    return Node(kind, args)


def app(name, *args):
    return node("app:" + name, *args)


def eq(a, b):
    return node("=", a, b)


def imp(a, b):
    return node("implies", a, b)


def all_(variable, body):
    # The quantifier is one node; its bound-variable name is metadata.
    return node("forall:" + variable, body)


def metrics():
    n, a, b, zero, false = [node(k) for k in ("n", "a", "b", "0", "false")]
    S = lambda x: app("S", x)
    one = S(zero)
    sep = imp(eq(zero, one), false)

    def positive_induction(E):
        step = all_("n", imp(E(n), E(S(n))))
        conclusion = node("and", sep, all_("n", node("or", eq(n, zero), E(n))))
        return all_("a", imp(step, conclusion))

    pb = positive_induction(lambda x: eq(app("s", x, a), app("t", x, a)))
    tr = positive_induction(lambda x: eq(app("H", x, one, a), app("H", one, x, a)))
    f = lambda x: app("f", x, a)
    pred = app("R_counter", n, zero, zero)
    recurrence = all_("n", eq(f(S(S(n))), app("h", n, f(S(n)), a)))
    comparison = eq(f(n), app("R_h", pred, f(one), a))
    conclusion = node("and", sep, all_("n", node("or", eq(n, zero), comparison)))
    pu = all_("a", imp(recurrence, conclusion))

    old_d0 = all_("a", eq(app("I_h", zero, a), a))
    old_ds = all_("n", all_("a", eq(app("I_h", S(n), a),
        app("h", n, app("I_h", n, a)))))
    new_d0 = all_("b", all_("a", eq(app("R_h", zero, b, a), b)))
    new_ds = all_("n", all_("b", all_("a", eq(app("R_h", S(n), b, a),
        app("h", n, app("R_h", n, b, a), a)))))
    old_cost, new_cost = old_d0.size() + old_ds.size(), new_d0.size() + new_ds.size()
    assert (old_d0.size(), old_ds.size(), new_d0.size(), new_ds.size()) == (6, 12, 8, 16)
    rows = []
    for name, formula, cost, arity, admission in [
        ("PB0", pb, old_cost, 2, "literal boundary agreement"),
        ("Transposition", tr, old_cost, 2, "none"),
        ("PU", pu, new_cost, 3, "none"),
    ]:
        rows.append({"name": name, "arithmetic_equalities": formula.count("="),
            "arithmetic_ast_nodes": formula.size(), "computation_ast_nodes": cost,
            "total_ast_nodes": formula.size() + cost, "templates": 3,
            "iterator_arity": arity, "admission": admission})
    assert [(r["arithmetic_equalities"], r["arithmetic_ast_nodes"], r["total_ast_nodes"])
            for r in rows] == [(5, 39, 57), (5, 51, 69), (4, 42, 66)]
    return rows


def M(n, a):
    return max(a - n, 0)


def C(z, u, v):
    return u if z == 0 else v


def error(x, y):
    return C(M(x, y), M(y, x), 1)


def complement(n, a):
    return C(M(n, a), a, n + M(n, a))


def complement_update(n, z, a):
    return C(M(n + 1, a), a, z)


def reconstruction(n, a):
    return C(M(n, a), M(M(a, n), n), a)


def reconstruction_update(n, z, a):
    r, t_next = M(n, a), M(a, n + 1)
    return C(r, C(t_next, C(M(a, z + 1), z + 1, z), z), a)


def numerical_checks():
    pairs = 0
    for n in range(101):
        for a in range(101):
            assert complement(0, a) == a
            assert complement(n + 1, a) == complement_update(n, complement(n, a), a)
            assert complement_update(n, a, a) == a
            assert complement(n, a) == a
            assert reconstruction(0, a) == a
            assert reconstruction(n + 1, a) == reconstruction_update(n, reconstruction(n, a), a)
            assert reconstruction_update(n, a, a) == a
            assert reconstruction(n, a) == a
            assert (error(n, a) == 0) == (n == a)
            pairs += 1

    errors = (0, 1, 2, 7)
    truth_pairs = 0
    for x in errors:
        assert (C(x, 1, 0) == 0) == (x != 0)
        for y in errors:
            A, B = x == 0, y == 0
            assert (C(x, y, 1) == 0) == (A and B)
            assert (C(x, 0, y) == 0) == (A or B)
            assert (C(x, y, 0) == 0) == ((not A) or B)
            truth_pairs += 1

    def T(k):
        return k * (k + 1) // 2

    def pair(x, y):
        return T(x + y) + y

    maximum = pair(64, 64)
    q = [0]
    for n in range(maximum):
        v = q[-1]
        q.append(C(error(n + 1, T(v + 1)), v + 1, v))
    pairing_checks = 0
    for x in range(65):
        for y in range(65):
            v = pair(x, y)
            right = M(T(q[v]), v)
            left = M(right, q[v])
            assert (left, right) == (x, y)
            pairing_checks += 1
    intervals = 0
    for k in range(129):
        assert q[T(k)] == k
        for i in range(k + 1):
            v = T(k) + i
            if v <= maximum:
                assert q[v] == k
                intervals += 1

    # The proof's exceptional reconstruction branch is impossible in N.
    # These evaluations do not validate that branch in arbitrary models;
    # its constructive algebraic proof is in the manuscript.
    return {"recurrence_and_reflection_grid": {"n": [0, 100], "a": [0, 100],
        "pairs": pairs}, "truth_table_pairs": truth_pairs,
        "pairing_grid": {"x": [0, 64], "y": [0, 64], "pairs": pairing_checks},
        "triangular_interval_checks": intervals,
        "scope": "Bounded standard-natural-number regression checks only; not universal proofs."}


def main():
    result = {"status": "passed", "metrics": metrics(), "numerical_checks": numerical_checks(),
        "metric_conventions": ["one node per variable/constant/application/logical constructor",
            "quantifier binder names are metadata", "1=S0 is expanded",
            "p(n)=R_counter(n,0,0) is expanded", "schematic term applications include arguments",
            "program bodies and description indices are not expanded"]}
    target = Path(__file__).with_name("check_results.json")
    target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
