/-
Finite-syntax certificate for parameterized, seeded positive uniqueness.

The arithmetic domain A is arbitrary; Nat indexes finite-syntax variables.
The declaration J_h is keyed by the finite update-description h. Distinct
descriptions are not identified extensionally. J_h has numerical arguments
(counter, initial seed, frozen parameter), and h has variables (counter,
current state, frozen parameter). The PU schema is instantiated only by
well-formed finite terms, never arbitrary set-theoretic functions.

Scope: the constructive finite-syntax kernel PU => separation, successor
laws, positive constructor coverage, and contextual recursion uniqueness.
The same single PU instance f(n,a)=n, h(n,v,a)=S(v) suffices for coverage.
Also certified: an actual finite-term selector and a finite-term compiler
recovering contextual induction for every equation t(n,a)=0. The native
equality comparator, pairing, and full PRA equivalence are not certified.
-/

universe u

namespace SeededPositiveUniqueness

inductive Term where
  | var : Nat → Term
  | zero : Term
  | succ : Term → Term
  | iter : Term → Term → Term → Term → Term
  deriving DecidableEq, Repr

def Term.Wf (k : Nat) : Term → Prop
  | .var i => i < k
  | .zero => True
  | .succ t => t.Wf k
  | .iter h n b a => h.Wf 3 ∧ n.Wf k ∧ b.Wf k ∧ a.Wf k

def Term.decWf (k : Nat) : (t : Term) → Decidable (t.Wf k)
  | .var i => inferInstanceAs (Decidable (i < k))
  | .zero => isTrue True.intro
  | .succ t => t.decWf k
  | .iter h n b a =>
      letI := h.decWf 3
      letI := n.decWf k
      letI := b.decWf k
      letI := a.decWf k
      inferInstanceAs (Decidable (h.Wf 3 ∧ n.Wf k ∧ b.Wf k ∧ a.Wf k))

instance (k : Nat) (t : Term) : Decidable (t.Wf k) := t.decWf k

structure Interpretation (A : Type u) where
  zero : A
  succ : A → A
  run : Term → A → A → A → A

def Term.eval {A : Type u} (M : Interpretation A) : Term → (Nat → A) → A
  | .var i, ρ => ρ i
  | .zero, _ => M.zero
  | .succ t, ρ => M.succ (t.eval M ρ)
  | .iter h n b a, ρ => M.run h (n.eval M ρ) (b.eval M ρ) (a.eval M ρ)

def env {A : Type u} (M : Interpretation A) (n a : A) : Nat → A
  | 0 => n
  | 1 => a
  | _ + 2 => M.zero

def env3 {A : Type u} (M : Interpretation A) (n v a : A) : Nat → A
  | 0 => n
  | 1 => v
  | 2 => a
  | _ + 3 => M.zero

def val {A : Type u} (M : Interpretation A) (t : Term) (n a : A) : A :=
  t.eval M (env M n a)

def val3 {A : Type u} (M : Interpretation A) (t : Term) (n v a : A) : A :=
  t.eval M (env3 M n v a)

def predTerm (t : Term) : Term := .iter (.var 0) t .zero .zero

def pred {A : Type u} (M : Interpretation A) (x : A) : A :=
  M.run (.var 0) x M.zero M.zero

structure Computation {A : Type u} (M : Interpretation A) : Prop where
  base : ∀ h, h.Wf 3 → ∀ b a, M.run h M.zero b a = b
  step : ∀ h, h.Wf 3 → ∀ n b a,
    M.run h (M.succ n) b a = val3 M h n (M.run h n b a) a

def PU {A : Type u} (M : Interpretation A) : Prop :=
  ∀ h f, h.Wf 3 → f.Wf 2 → ∀ a,
    (∀ n, val M f (M.succ (M.succ n)) a =
      val3 M h n (val M f (M.succ n) a) a) →
    M.zero ≠ M.succ M.zero ∧
      ∀ n, n = M.zero ∨
        val M f n a = M.run h (pred M n) (val M f (M.succ M.zero) a) a

theorem pred_zero {A : Type u} (M : Interpretation A) (D : Computation M) :
    pred M M.zero = M.zero := by
  exact D.base (.var 0) (by decide) M.zero M.zero

theorem pred_succ {A : Type u} (M : Interpretation A) (D : Computation M) (x : A) :
    pred M (M.succ x) = x := by
  exact D.step (.var 0) (by decide) x M.zero M.zero

def successorUpdate : Term := .succ (.var 1)

theorem identity_instance {A : Type u} (M : Interpretation A) (U : PU M) :
    M.zero ≠ M.succ M.zero ∧
      ∀ n, n = M.zero ∨
        n = M.run successorUpdate (pred M n) (M.succ M.zero) M.zero := by
  exact U successorUpdate (.var 0) (by decide) (by decide) M.zero
    (by intro n; rfl)

theorem separation {A : Type u} (M : Interpretation A) (U : PU M) :
    M.zero ≠ M.succ M.zero := (identity_instance M U).1

theorem succ_injective {A : Type u} (M : Interpretation A) (D : Computation M)
    (x y : A) (e : M.succ x = M.succ y) : x = y := by
  have h := congrArg (pred M) e
  rw [pred_succ M D, pred_succ M D] at h
  exact h

theorem succ_ne_zero {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (x : A) : M.succ x ≠ M.zero := by
  intro e
  have hx := congrArg (pred M) e
  rw [pred_succ M D, pred_zero M D] at hx
  have h1 : M.succ M.zero = M.zero := by simpa [hx] using e
  exact separation M U h1.symm

theorem successor_iteration {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (x : A) :
    M.run successorUpdate x (M.succ M.zero) M.zero = M.succ x := by
  cases (identity_instance M U).2 (M.succ x) with
  | inl e => exact False.elim (succ_ne_zero M D U x e)
  | inr e =>
    rw [pred_succ M D] at e
    exact e.symm

theorem coverage {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (x : A) :
    x = M.zero ∨ x = M.succ (pred M x) := by
  cases (identity_instance M U).2 x with
  | inl e => exact Or.inl e
  | inr e =>
    right
    exact e.trans (successor_iteration M D U (pred M x))

theorem zero_decidable {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (x : A) : x = M.zero ∨ x ≠ M.zero := by
  cases coverage M D U x with
  | inl e => exact Or.inl e
  | inr e =>
    right
    intro h
    exact succ_ne_zero M D U (pred M x) (e.symm.trans h)

def Term.subst (σ : Nat → Term) : Term → Term
  | .var i => σ i
  | .zero => .zero
  | .succ t => .succ (t.subst σ)
  | .iter h n b a => .iter h (n.subst σ) (b.subst σ) (a.subst σ)

theorem Term.eval_subst {A : Type u} (M : Interpretation A) (σ : Nat → Term)
    (t : Term) (ρ : Nat → A) :
    (t.subst σ).eval M ρ = t.eval M (fun i => (σ i).eval M ρ) := by
  induction t with
  | var i => rfl
  | zero => rfl
  | succ t ih => exact congrArg M.succ ih
  | iter h n b a _ ihn ihb iha =>
    change M.run h ((n.subst σ).eval M ρ) ((b.subst σ).eval M ρ)
        ((a.subst σ).eval M ρ) =
      M.run h (n.eval M (fun i => (σ i).eval M ρ))
        (b.eval M (fun i => (σ i).eval M ρ))
        (a.eval M (fun i => (σ i).eval M ρ))
    rw [ihn, ihb, iha]

theorem Term.eval_congr {A : Type u} (M : Interpretation A) (t : Term)
    (ρ σ : Nat → A) (e : ∀ i, ρ i = σ i) : t.eval M ρ = t.eval M σ := by
  induction t with
  | var i => exact e i
  | zero => rfl
  | succ t ih => exact congrArg M.succ ih
  | iter h n b a _ ihn ihb iha =>
    change M.run h (n.eval M ρ) (b.eval M ρ) (a.eval M ρ) =
      M.run h (n.eval M σ) (b.eval M σ) (a.eval M σ)
    rw [ihn, ihb, iha]

theorem Term.wf_subst (t : Term) (k l : Nat) (σ : Nat → Term)
    (wt : t.Wf k) (ws : ∀ i, i < k → (σ i).Wf l) : (t.subst σ).Wf l := by
  induction t with
  | var i => exact ws i wt
  | zero => trivial
  | succ t ih => exact ih wt
  | iter h n b a _ ihn ihb iha => exact ⟨wt.1, ihn wt.2.1, ihb wt.2.2.1, iha wt.2.2.2⟩

def delaySub : Nat → Term
  | 0 => predTerm (.var 0)
  | i + 1 => .var (i + 1)

def delay (f : Term) : Term := f.subst delaySub

theorem delay_wf (f : Term) (wf : f.Wf 2) : (delay f).Wf 2 := by
  apply Term.wf_subst f 2 2 delaySub wf
  intro i hi
  cases i with
  | zero => exact ⟨by decide, by decide, trivial, trivial⟩
  | succ i => exact hi

theorem delay_val {A : Type u} (M : Interpretation A) (f : Term) (n a : A) :
    val M (delay f) n a = val M f (pred M n) a := by
  unfold val delay
  rw [Term.eval_subst]
  apply Term.eval_congr
  intro i
  cases i with
  | zero => rfl
  | succ i => cases i <;> rfl

theorem recursion_unique {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (h f : Term)
    (wh : h.Wf 3) (wf : f.Wf 2) (a : A)
    (step : ∀ n, val M f (M.succ n) a = val3 M h n (val M f n a) a) (n : A) :
    val M f n a = M.run h n (val M f M.zero a) a := by
  have ds : ∀ k, val M (delay f) (M.succ (M.succ k)) a =
      val3 M h k (val M (delay f) (M.succ k) a) a := by
    intro k
    rw [delay_val, delay_val, pred_succ M D, pred_succ M D]
    exact step k
  have p := (U h (delay f) wh (delay_wf f wf) a ds).2 (M.succ n)
  cases p with
  | inl e => exact False.elim (succ_ne_zero M D U n e)
  | inr e =>
    rw [delay_val, delay_val, pred_succ M D, pred_succ M D] at e
    exact e

theorem two_solutions_unique {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (h f g : Term)
    (wh : h.Wf 3) (wf : f.Wf 2) (wg : g.Wf 2) (a : A)
    (base : val M f M.zero a = val M g M.zero a)
    (sf : ∀ n, val M f (M.succ n) a = val3 M h n (val M f n a) a)
    (sg : ∀ n, val M g (M.succ n) a = val3 M h n (val M g n a) a) (n : A) :
    val M f n a = val M g n a := by
  calc
    val M f n a = M.run h n (val M f M.zero a) a :=
      recursion_unique M D U h f wh wf a sf n
    _ = M.run h n (val M g M.zero a) a :=
      congrArg (fun b => M.run h n b a) base
    _ = val M g n a := (recursion_unique M D U h g wh wg a sg n).symm

def add {A : Type u} (M : Interpretation A) (x y : A) : A :=
  M.run successorUpdate x y M.zero

def gate {A : Type u} (M : Interpretation A) (x y : A) : A :=
  M.run .zero x y M.zero

def select {A : Type u} (M : Interpretation A) (x y z : A) : A :=
  add M (gate M x y) (gate M (gate M x (M.succ M.zero)) z)

def Term.add (x y : Term) : Term := .iter successorUpdate x y .zero

def Term.gate (x y : Term) : Term := .iter .zero x y .zero

def Term.select (x y z : Term) : Term :=
  .add (.gate x y) (.gate (.gate x (.succ .zero)) z)

theorem add_zero_left {A : Type u} (M : Interpretation A) (D : Computation M) (y : A) :
    add M M.zero y = y := D.base successorUpdate (by decide) y M.zero

theorem add_zero_right {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (x : A) : add M x M.zero = x := by
  exact (recursion_unique M D U successorUpdate (.var 0)
    (by decide) (by decide) M.zero (by intro n; rfl) x).symm

theorem gate_zero {A : Type u} (M : Interpretation A) (D : Computation M) (y : A) :
    gate M M.zero y = y := D.base .zero (by decide) y M.zero

theorem gate_succ {A : Type u} (M : Interpretation A) (D : Computation M) (x y : A) :
    gate M (M.succ x) y = M.zero := D.step .zero (by decide) x y M.zero

theorem select_zero {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (y z : A) : select M M.zero y z = y := by
  unfold select
  rw [gate_zero M D, gate_zero M D, gate_succ M D, add_zero_right M D U]

theorem select_succ {A : Type u} (M : Interpretation A)
    (D : Computation M) (x y z : A) : select M (M.succ x) y z = z := by
  unfold select
  rw [gate_succ M D, gate_succ M D, gate_zero M D, add_zero_left M D]

theorem select_nonzero {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (x y z : A) (hx : x ≠ M.zero) :
    select M x y z = z := by
  cases coverage M D U x with
  | inl e => exact False.elim (hx e)
  | inr e => rw [e, select_succ M D]

theorem select_same {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (x y : A) : select M x y y = y := by
  cases zero_decidable M D U x with
  | inl e => rw [e, select_zero M D U]
  | inr e => exact select_nonzero M D U x y y e

theorem Term.add_wf (x y : Term) (k : Nat) (wx : x.Wf k) (wy : y.Wf k) :
    (x.add y).Wf k := ⟨by decide, wx, wy, trivial⟩

theorem Term.gate_wf (x y : Term) (k : Nat) (wx : x.Wf k) (wy : y.Wf k) :
    (x.gate y).Wf k := ⟨trivial, wx, wy, trivial⟩

theorem Term.select_wf (x y z : Term) (k : Nat)
    (wx : x.Wf k) (wy : y.Wf k) (wz : z.Wf k) : (x.select y z).Wf k := by
  apply Term.add_wf
  · exact Term.gate_wf x y k wx wy
  · apply Term.gate_wf
    · exact Term.gate_wf x (.succ .zero) k wx trivial
    · exact wz

def advanceSub : Nat → Term
  | 0 => .succ (.var 0)
  | i + 1 => .var (i + 2)

def advance (t : Term) : Term := t.subst advanceSub

theorem advance_wf (t : Term) (wt : t.Wf 2) : (advance t).Wf 3 := by
  apply Term.wf_subst t 2 3 advanceSub wt
  intro i hi
  cases i with
  | zero => exact (by decide)
  | succ i => exact Nat.succ_lt_succ hi

theorem advance_val {A : Type u} (M : Interpretation A) (t : Term) (n v a : A) :
    val3 M (advance t) n v a = val M t (M.succ n) a := by
  unfold val3 val advance
  rw [Term.eval_subst]
  apply Term.eval_congr
  intro i
  cases i with
  | zero => rfl
  | succ i => cases i <;> rfl

def mask (t : Term) : Term := t.select .zero (.succ .zero)

def maskUpdate (t : Term) : Term := (advance t).select .zero (.var 1)

theorem mask_wf (t : Term) (wt : t.Wf 2) : (mask t).Wf 2 :=
  Term.select_wf t .zero (.succ .zero) 2 wt trivial trivial

theorem maskUpdate_wf (t : Term) (wt : t.Wf 2) : (maskUpdate t).Wf 3 :=
  Term.select_wf (advance t) .zero (.var 1) 3 (advance_wf t wt) trivial (by decide)

theorem mask_val {A : Type u} (M : Interpretation A) (t : Term) (n a : A) :
    val M (mask t) n a = select M (val M t n a) M.zero (M.succ M.zero) := rfl

theorem maskUpdate_val {A : Type u} (M : Interpretation A) (t : Term) (n v a : A) :
    val3 M (maskUpdate t) n v a = select M (val M t (M.succ n) a) M.zero v := by
  change select M (val3 M (advance t) n v a) M.zero v = _
  rw [advance_val]

theorem zero_test_induction {A : Type u} (M : Interpretation A)
    (D : Computation M) (U : PU M) (t : Term) (wt : t.Wf 2) (a : A)
    (base : val M t M.zero a = M.zero)
    (step : ∀ n, val M t n a = M.zero → val M t (M.succ n) a = M.zero) (n : A) :
    val M t n a = M.zero := by
  have fb : val M (mask t) M.zero a = val M .zero M.zero a := by
    rw [mask_val, base, select_zero M D U]
    rfl
  have fs : ∀ k, val M (mask t) (M.succ k) a =
      val3 M (maskUpdate t) k (val M (mask t) k a) a := by
    intro k
    rw [mask_val, maskUpdate_val, mask_val]
    cases zero_decidable M D U (val M t k a) with
    | inl e => rw [e, select_zero M D U, step k e, select_zero M D U,
        select_zero M D U]
    | inr e => rw [select_nonzero M D U (val M t k a) M.zero (M.succ M.zero) e]
  have gs : ∀ k, val M .zero (M.succ k) a =
      val3 M (maskUpdate t) k (val M .zero k a) a := by
    intro k
    rw [maskUpdate_val]
    exact (select_same M D U (val M t (M.succ k) a) M.zero).symm
  have fm := two_solutions_unique M D U (maskUpdate t) (mask t) .zero
    (maskUpdate_wf t wt) (mask_wf t wt) trivial a fb fs gs n
  rw [mask_val] at fm
  cases zero_decidable M D U (val M t n a) with
  | inl e => exact e
  | inr e =>
    rw [select_nonzero M D U (val M t n a) M.zero (M.succ M.zero) e] at fm
    exact False.elim (separation M U fm.symm)

#print axioms pred_zero
#print axioms pred_succ
#print axioms identity_instance
#print axioms separation
#print axioms succ_injective
#print axioms succ_ne_zero
#print axioms successor_iteration
#print axioms coverage
#print axioms zero_decidable
#print axioms Term.eval_subst
#print axioms Term.eval_congr
#print axioms Term.wf_subst
#print axioms delay_wf
#print axioms delay_val
#print axioms recursion_unique
#print axioms two_solutions_unique
#print axioms add_zero_left
#print axioms add_zero_right
#print axioms gate_zero
#print axioms gate_succ
#print axioms select_zero
#print axioms select_succ
#print axioms select_nonzero
#print axioms select_same
#print axioms advance_wf
#print axioms advance_val
#print axioms mask_wf
#print axioms maskUpdate_wf
#print axioms mask_val
#print axioms maskUpdate_val
#print axioms zero_test_induction

end SeededPositiveUniqueness
