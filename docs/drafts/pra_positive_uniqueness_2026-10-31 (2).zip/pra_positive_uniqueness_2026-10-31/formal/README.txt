Finite-syntax constructive certificate
=====================================
File: SeededPositiveUniqueness.lean
Lean: 4.19.0. No imports and no external packages.

Run:
  lean formal/SeededPositiveUniqueness.lean
from the archive root, or run check.sh there.

The arithmetic carrier A is arbitrary. Lean's Nat is used only for variable
indices in finite syntax, not as the arithmetic carrier. Iterator descriptions
are finite terms and remain distinct; no function extensionality identifies
them. Each update is checked to have only counter, state, and fixed parameter
free. PU ranges over finite well-formed terms, never all functions A -> A.

Certified deductions:
- one fixed PU instance gives separation and constructor coverage;
- successor injectivity and nonzeroness, positive zero decision;
- substitution and evaluation lemmas, including the delayed-input compiler;
- contextual recursion uniqueness and equality of two trajectories;
- iterator-defined addition units and selector;
- a finite mask/update compiler and contextual zero-test induction.

31 printed theorem dependency audits all report no additional Lean axioms.
The defining equations and PU remain explicit hypotheses. The file uses no
sorry, axiom declaration, classical choice, proof extensionality, or induction
on the arbitrary arithmetic domain. Structural induction on finite syntax
is part of the metatheoretic verification.

Not formalized:
- the entire first-order derivation calculus;
- the complement/reconstruction bootstrap for native equality reflection;
- the general quantifier-free formula compiler;
- pairing retractions and the full definitional-equivalence theorem.
These have complete written proofs in the manuscript.

The certificate's zero-induction proof uses a finite Boolean mask; the paper
uses a shorter direct shared update. Both instantiate exactly the same PU
schema and prove the same contextual zero-test induction conclusion.
