#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check.py
"${PRA_LEAN:-lean}" formal/SeededPositiveUniqueness.lean
