PRA BY POSITIVE RECURSION UNIQUENESS
31 October 2026

RESULT
The manuscript proves a common axiomatization of classical and intuitionistic
PRA: two defining-equation templates for seeded iterators, and one positive
recursion-uniqueness schema (PU). PU has four equality occurrences, no base
premise, and no admission test. Full written constructive proofs are included.

TRADEOFF
The new iterator is ternary and its update can access one fixed parameter.
The strongest current drafts use binary iterators with no separate fixed
parameter available to the update. This report does not prove an improvement
in that exact restricted grammar. Its expanded arithmetic formula has 42 nodes
versus 39 for their literal-boundary schema and 51 for their transposition
schema; including computation templates the totals are 66, 57, and 69.
No absolute minimality or historical-priority claim is made.

CONTENTS
  pra_positive_uniqueness.tex     Complete source, including all written proofs
  pra_positive_uniqueness.pdf     Compiled manuscript
  axioms.txt                     Exact plain-text specification
  comparison.tsv                 Explicit resource comparison
  source_audit.json               Current repository snapshot, files, hashes
  formal/SeededPositiveUniqueness.lean
                                 Checked finite-syntax constructive core
  formal/verification.log         Successful Lean dependency audit
  formal/README.txt               Exact formalization scope and instructions
  lean-toolchain                 Lean version used
  artifacts/check.py             Metrics and bounded numerical checks
  artifacts/check_results.json    Executed check results
  build.sh                       Rebuild PDF using latexmk
  check.sh                       Run Python and Lean checks
  VALIDATION.txt                 Validation scope and outcomes
  SHA256SUMS                     Checksums of deliverable files

BUILD
  sh build.sh
Requires a standard TeX installation with latexmk and the packages named in
the source. No network access is needed once TeX is installed.

CHECK
  sh check.sh
Requires Python 3.10+ and Lean 4.19.0 on PATH (or set PRA_LEAN to its executable).
No Lean imports or external packages are required. The checker writes its JSON
results, and Lean prints 31 dependency audits, all without additional axioms.

FORMAL SCOPE
The Lean source uses an arbitrary carrier and finite, well-formed terms;
it does not identify the arithmetic carrier with Nat. It checks separation,
successor laws, constructor coverage, substitution, recursion uniqueness,
the selector, and contextual zero-test induction. The computation and PU
assumptions remain explicit theorem hypotheses. Native equality reflection,
the general formula compiler, pairing, and full PRA equivalence are proved
in the manuscript, not claimed to be fully formalized here.

SOURCE COMPARISON
ProveIt commit 66372d99e4f4e1d3a48822b9d322ae9e9ae7e7e3.
All four current PRA drafts were reviewed. The incoming inventory and index
had no additional PRA-labelled package. Unrelated archive interiors were not
reviewed. Prior draft texts and the copyrighted Goodstein paper are not
redistributed in this archive.
