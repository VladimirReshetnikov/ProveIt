#!/bin/sh
set -eu
cd "$(dirname "$0")"
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build pra_positive_uniqueness.tex
cp build/pra_positive_uniqueness.pdf pra_positive_uniqueness.pdf
