"""Write a deterministic ZIP and verify every payload hash and CRC."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.fls', '.fdb_latexmk', '.synctex.gz'}


def files():
    return sorted(path for path in ROOT.rglob('*') if path.is_file()
                  and '__pycache__' not in path.parts
                  and path.suffix not in EXCLUDED_SUFFIXES
                  and path.name not in {'MANIFEST.json', 'report.pdf'})


def main():
    payload = files()
    records = [{'path': str(path.relative_to(ROOT)), 'size': path.stat().st_size,
                'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in payload]
    manifest = {'format': 'sha256-payload-v1', 'files': records}
    manifest_path = ROOT / 'MANIFEST.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
        for path in payload + [manifest_path]:
            entry = zipfile.ZipInfo(ROOT.name + '/' + str(path.relative_to(ROOT)), (2026, 11, 9, 12, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o644 << 16
            stream.writestr(entry, path.read_bytes())
    with zipfile.ZipFile(archive) as stream:
        if stream.testzip() is not None:
            raise ValueError('ZIP CRC validation failed')
        for record in records:
            data = stream.read(ROOT.name + '/' + record['path'])
            if len(data) != record['size'] or hashlib.sha256(data).hexdigest() != record['sha256']:
                raise ValueError('Payload hash mismatch: ' + record['path'])
    print(json.dumps({'archive': str(archive), 'payload_files': len(records),
                      'bytes': archive.stat().st_size,
                      'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                      'verification': 'all CRCs and manifested SHA-256 hashes pass'}, indent=2))


if __name__ == '__main__':
    main()
