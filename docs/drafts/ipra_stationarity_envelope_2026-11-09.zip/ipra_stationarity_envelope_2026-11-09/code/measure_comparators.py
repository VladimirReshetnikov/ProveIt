"""Measure unchanged complete comparator modules; do not execute their code."""
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIRECTORY = ROOT / 'code' / 'comparators'


def main():
    spec = importlib.util.spec_from_file_location('source_measure', DIRECTORY / 'source_measure.py')
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    manifest = json.loads((DIRECTORY / 'manifest.json').read_text())
    rows = []
    for entry in manifest['programs']:
        result = measure.metrics(DIRECTORY / entry['local_file'])
        if result['sha256'] != entry['sha256']:
            raise ValueError('Changed source: ' + entry['local_file'])
        rows.append({**entry, **result})
    fields = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    strict = [row for row in rows if row['local_file'] != 'iterable_306.py']
    result = {
        'python': platform.python_version(),
        'commit': manifest['commit'],
        'scope': 'Whole modules; true docstrings/comments removed; ast.unparse normalization.',
        'runtime_inclusive': {key: min(row[key] for row in rows) for key in fields},
        'strict_guarded': {key: min(row[key] for row in strict) for key in fields},
        'rows': rows,
    }
    (ROOT / 'evidence' / 'comparator_metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
