#!/usr/bin/env python3
"""Replay the stated iterator-equation certificate, without induction.

This is a deliberately scoped fragment verifier, not an iPRA proof checker.
The fixed axioms and the U_h rule are listed in README.txt.  F is an
uninterpreted unary context symbol in this schematic calculation.
"""

import argparse
import json
from pathlib import Path


class ProofError(ValueError):
    pass


ARITY = {"0": 0, "S": 1, "h": 1, "j": 1, "F": 1, "L": 2, "A": 2, "T": 2}


def require(value, message):
    if not value:
        raise ProofError(message)


def variable_name(value):
    return type(value) is str and value.isascii() and value.isidentifier()


def term(value):
    require(type(value) is list and bool(value), "term must be a nonempty array")
    head = value[0]
    require(type(head) is str, "term head must be a string")
    if head == "v":
        require(len(value) == 2 and variable_name(value[1]), "invalid variable")
        return ("v", value[1])
    require(head in ARITY and len(value) == ARITY[head] + 1,
            "unknown head or incorrect arity")
    return (head, *(term(child) for child in value[1:]))


def v(name):
    return ("v", name)


def app(head, *args):
    return (head, *args)


ZERO = ("0",)


def free_vars(item):
    if item[0] == "v":
        return {item[1]}
    result = set()
    for child in item[1:]:
        result.update(free_vars(child))
    return result


def subst(item, mapping):
    """Simultaneous, one-pass variable substitution in binder-free terms."""
    if item[0] == "v":
        return mapping.get(item[1], item)
    return (item[0], *(subst(child, mapping) for child in item[1:]))


def r(counter, seed):
    return app("L", counter, app("A", counter, seed))


def targets():
    n, m, a, t = v("n"), v("m"), v("a"), v("t")
    return {
        "rotation": (app("L", n, app("h", a)), app("h", app("L", n, a))),
        "R_zero": (r(ZERO, a), a),
        "R_stationary": (r(app("S", n), a), r(n, a)),
        "context_invariance": (
            app("L", t, app("F", r(t, a))), app("L", t, app("F", a))),
        "context_absorption": (r(t, app("F", r(t, a))), r(t, app("F", a))),
        "idempotence": (r(t, r(t, a)), r(t, a)),
        "iterator_fusion": (
            app("L", app("T", n, m), a), app("L", n, app("L", m, a))),
        "iterator_commutation": (
            app("L", n, app("L", m, a)), app("L", m, app("L", n, a))),
    }


AXIOMS = {
    "L_zero": (app("L", ZERO, v("a")), v("a")),
    "L_successor": (
        app("L", app("S", v("n")), v("a")),
        app("h", app("L", v("n"), v("a")))),
    "A_zero": (app("A", ZERO, v("a")), v("a")),
    "A_successor": (
        app("A", app("S", v("n")), v("a")),
        app("j", app("A", v("n"), v("a")))),
    "section": (app("h", app("j", v("a"))), v("a")),
    "T_zero": (app("T", ZERO, v("a")), v("a")),
    "T_successor": (
        app("T", app("S", v("n")), v("a")),
        app("S", app("T", v("n"), v("a")))),
}


def replay(document):
    require(type(document) is dict, "certificate must be an object")
    require(set(document) == {"format", "nodes", "claims"},
            "incorrect top-level fields")
    require(document["format"] == "directed-envelope-equations-v1", "unknown certificate format")
    nodes = document["nodes"]
    require(type(nodes) is list, "nodes must be an array")
    derived = []
    counts = {}

    def premise(index):
        require(type(index) is int and 0 <= index < len(derived),
                "premise must name an earlier node")
        return derived[index]

    def mapping(value, permitted):
        require(type(value) is dict, "substitution must be an object")
        require(all(variable_name(key) and key in permitted for key in value),
                "substitution names a variable absent from the source")
        return {key: term(item) for key, item in value.items()}

    for index, node in enumerate(nodes):
        try:
            require(type(node) is dict, "node must be an object")
            rule = node.get("rule")
            require(type(rule) is str, "rule must be a string")
            common = {"rule", "conclusion"}
            if "label" in node:
                require(type(node["label"]) is str, "label must be a string")
                common.add("label")

            if rule == "axiom":
                require(set(node) == common | {"name", "substitution"}, "axiom fields")
                name = node["name"]
                require(type(name) is str and name in AXIOMS, "unknown axiom")
                left, right = AXIOMS[name]
                permitted = free_vars(left) | free_vars(right)
                replacement = mapping(node["substitution"], permitted)
                require(set(replacement) == permitted, "axiom instance omits an argument")
                result = (subst(left, replacement), subst(right, replacement))
            elif rule == "reflexivity":
                require(set(node) == common | {"term"}, "reflexivity fields")
                item = term(node["term"])
                result = (item, item)
            elif rule == "symmetry":
                require(set(node) == common | {"premise"}, "symmetry fields")
                left, right = premise(node["premise"])
                result = (right, left)
            elif rule == "transitivity":
                require(set(node) == common | {"first", "second"}, "transitivity fields")
                left, middle = premise(node["first"])
                other, right = premise(node["second"])
                require(middle == other, "transitivity middle terms differ")
                result = (left, right)
            elif rule == "congruence":
                require(set(node) == common | {"head", "premises"}, "congruence fields")
                head = node["head"]
                require(type(head) is str and head in ARITY, "invalid congruence head")
                refs = node["premises"]
                require(type(refs) is list and len(refs) == ARITY[head],
                        "incorrect congruence arity")
                equalities = [premise(ref) for ref in refs]
                result = (app(head, *(eq[0] for eq in equalities)),
                          app(head, *(eq[1] for eq in equalities)))
            elif rule == "instantiation":
                require(set(node) == common | {"premise", "substitution"},
                        "instantiation fields")
                left, right = premise(node["premise"])
                replacement = mapping(node["substitution"], free_vars(left) | free_vars(right))
                result = (subst(left, replacement), subst(right, replacement))
            elif rule == "uniqueness":
                require(set(node) == common | {"premise", "placeholder", "eigenvariable",
                                              "template", "target"}, "uniqueness fields")
                placeholder = node["placeholder"]
                eigen = node["eigenvariable"]
                require(variable_name(placeholder) and variable_name(eigen),
                        "invalid uniqueness variable")
                require(placeholder != eigen, "placeholder cannot be the eigenvariable")
                template = term(node["template"])
                target = term(node["target"])
                require(eigen not in free_vars(template), "eigenvariable occurs in template data")
                require(eigen not in free_vars(target), "eigenvariable occurs in target")
                step = premise(node["premise"])
                at_eigen = subst(template, {placeholder: v(eigen)})
                at_successor = subst(template, {placeholder: app("S", v(eigen))})
                require(step == (at_successor, app("h", at_eigen)),
                        "premise is not the exact recurrence for the stated template")
                result = (subst(template, {placeholder: target}),
                          app("L", target, subst(template, {placeholder: ZERO})))
            else:
                raise ProofError("unknown rule")

            conclusion = node["conclusion"]
            require(type(conclusion) is list and len(conclusion) == 2,
                    "conclusion must contain two terms")
            stated = (term(conclusion[0]), term(conclusion[1]))
            require(stated == result, "stated conclusion does not match the inference")
            derived.append(result)
            counts[rule] = counts.get(rule, 0) + 1
        except (ProofError, KeyError, TypeError) as error:
            raise ProofError(f"node {index}: {error}") from error

    claims = document["claims"]
    require(type(claims) is dict and set(claims) == set(targets()),
            "certificate must prove exactly the eight advertised claims")
    for name, expected in targets().items():
        require(premise(claims[name]) == expected, f"claim {name} does not name its advertised equation")
    return {"status": "ACCEPT", "nodes": len(nodes), "rules": counts,
            "claims": list(targets())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path)
    args = parser.parse_args()
    try:
        document = json.loads(args.certificate.read_text())
        print(json.dumps(replay(document), indent=2))
    except (OSError, ValueError, TypeError, KeyError) as error:
        print(json.dumps({"status": "REJECT", "error": str(error)}, indent=2))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
