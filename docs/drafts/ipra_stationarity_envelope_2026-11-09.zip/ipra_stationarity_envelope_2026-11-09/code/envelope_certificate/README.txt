SCOPED CERTIFICATES FOR THE DIRECTED STATIONARITY ENVELOPE
=======================================================

Status
------
This package checks eight explicit universal equations in a deliberately
specified equational fragment. It is NOT a full iPRA verifier and is NOT
entered into the complete-proof-checker size comparison. In particular, it
does not mechanize the first-order existential definition of the envelope,
its least-congruence universal property, the W-specific singleton-fibre
theorem, or any bi-interpretability assertion.

The two new checked equations are iterator fusion and commutation. The six
earlier projection equations and most of the producer/replayer structure
are adapted from the attributed recurrence-projections package. This is a
supporting certificate, not a formal verification in Lean or Rocq.

Files
-----
produce.py                 untrusted deterministic proof generator
envelope_certificate.json  explicit 79-node proof DAG
replay.py                  standalone acceptance algorithm
test_certificate.py        24 targeted corruption checks and CLI checks
validation_results.json    executed test results
source_manifest.json       exact source provenance and SHA-256 identities
LICENSE-inherited.txt      license supplied with the source package
ATTRIBUTION.txt             precise attribution and contribution boundary
MATHEMATICAL_REVIEW.txt     independent written review of the envelope theorem

Replay does not import or execute produce.py, a theorem library, or any
arithmetic evaluator. The only dependency is Python's standard library.

  python3 replay.py envelope_certificate.json
  python3 test_certificate.py

To regenerate the certificate deterministically:

  python3 produce.py

Exact fragment
--------------
Terms are finite binder-free first-order trees. Variables have the form
["v", "name"]. The declared function heads are:

  0                         arity 0
  S, h, j, F                arity 1
  L, A, T                   arity 2

F is a fixed formal unary context symbol. It is not an object-level
variable ranging over functions. Substituting an admitted fixed numerical
term context for F, after fresh renaming and keeping its parameters passive,
gives the source-theory instance. That schematic interpretation is written
mathematics; the verifier has no function-substitution oracle.

The seven trusted computation schemas are exactly:

  L(0,a)   = a
  L(Sn,a)  = h(L(n,a))
  A(0,a)   = a
  A(Sn,a)  = j(A(n,a))
  h(j(a))  = a
  T(0,a)   = a
  T(Sn,a)  = S(T(n,a)).

Thus A is the j-iterator, while T is the separate successor clock. No
commutativity or associativity of T is assumed or needed. No equation
j(h(a))=a is assumed. No coverage or separation axiom is used by these
certificates.

The equality rules are reflexivity, symmetry, transitivity, congruence for
the declared fixed symbols, and simultaneous one-pass substitution of terms
for variables in previously established universal equations.

The only additional rule is U_h, in EMPTY retained context:

  f(Sz) = h(f(z))
  ---------------------
  f(t) = L(t,f(0)).

A uniqueness node supplies the finite template f(x), its placeholder x,
fresh eigenvariable z, target t, and an earlier proof of the EXACT displayed
recurrence. The verifier requires x != z, z absent from the template's
passive data, and z absent from t. No retained-context field is accepted.
Each node states a conclusion that the verifier reconstructs independently.
Only earlier integer node indices are permitted; Boolean indices are rejected.

Advertised equations
--------------------
Write R_n(a)=L(n,A(n,a)); the certificate expands this abbreviation.

  rotation:               L(n,h(a)) = h(L(n,a))
  R_zero:                 R_0(a) = a
  R_stationary:           R_(Sn)(a) = R_n(a)
  context_invariance:     L(t,F(R_t(a))) = L(t,F(a))
  context_absorption:     R_t(F(R_t(a))) = R_t(F(a))
  idempotence:            R_t(R_t(a)) = R_t(a)
  iterator_fusion:        L(T(n,m),a) = L(n,L(m,a))
  iterator_commutation:   L(n,L(m,a)) = L(m,L(n,a)).

There are six explicit U_h applications: rotation, invariance, absorption,
idempotence, fusion, and commutation. The new fusion proof uses the template
L(T(x,m),a); the commutation proof uses L(m,L(x,a)) and the proved rotation
equation. Every computation, congruence, symmetry, and intermediate equality
is an explicit checked node.

The verifier fixes all eight targets. Redirecting a claimed theorem to an
irrelevant but valid equation therefore rejects.

Specialization to the bouncing predecessor
-----------------------------------------
For W(0)=S0 and W(Sa)=a, put h=W and j=S. In the surrounding arithmetic
theory, choose A and T as names for the SAME fixed primitive-recursive
description I_S. They may then be written with one abbreviation. Merely
postulating two separate function symbols with identical recursion equations
would not justify their equality in the induction-free base.

Evidence limits
---------------
Induction on the finite accepted node list proves elementary relative
soundness: every equality rule preserves universal validity, and every
uniqueness node is exactly an instance of the stated assumed U_h rule. The
tests supplement that mathematical argument; they do not establish the
metatheorem by themselves. Python resource limits can reject sufficiently
large inputs. No claim of formal verification, iPRA consistency, or a
smaller complete arithmetic axiomatization follows from this fragment.
