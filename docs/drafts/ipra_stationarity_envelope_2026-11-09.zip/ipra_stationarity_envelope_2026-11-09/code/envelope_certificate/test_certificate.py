#!/usr/bin/env python3
"""Boundary tests for the scoped certificate replayer, not an iPRA test suite."""

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile

from replay import ProofError, replay


HERE = Path(__file__).resolve().parent
original = json.loads((HERE / "envelope_certificate.json").read_text())
accepted = replay(original)
unique_nodes = [i for i, node in enumerate(original["nodes"])
                if node["rule"] == "uniqueness"]
first_unique = unique_nodes[0]
absorb_unique = unique_nodes[2]
fusion_unique = unique_nodes[4]
commute_unique = unique_nodes[5]
symmetry_node = next(i for i, node in enumerate(original["nodes"])
                     if node["rule"] == "symmetry")
section_node = next(i for i, node in enumerate(original["nodes"])
                    if node.get("name") == "section")
cases = []


def corrupt(name, change, expected_message):
    candidate = copy.deepcopy(original)
    change(candidate)
    try:
        replay(candidate)
    except ProofError as error:
        message = str(error)
        if expected_message not in message:
            raise AssertionError(f"{name}: unexpected rejection: {message}") from error
        cases.append({"name": name, "status": "REJECT", "reason": message})
    else:
        raise AssertionError(f"{name}: corruption was accepted")


corrupt("wrong recurrence premise",
        lambda d: d["nodes"][first_unique].update(premise=0),
        "not the exact recurrence")
corrupt("wrong target with unchanged conclusion",
        lambda d: d["nodes"][first_unique].update(target=["v", "other_target"]),
        "conclusion does not match")
corrupt("wrong template",
        lambda d: d["nodes"][first_unique].update(template=["L", ["v", "x"], ["v", "a"]]),
        "not the exact recurrence")
corrupt("eigenvariable occurs in passive template data",
        lambda d: d["nodes"][first_unique].update(eigenvariable="a"),
        "eigenvariable occurs in template data")
corrupt("eigenvariable occurs in target",
        lambda d: d["nodes"][first_unique].update(target=["v", "z"]),
        "eigenvariable occurs in target")
corrupt("placeholder is eigenvariable",
        lambda d: d["nodes"][first_unique].update(placeholder="z"),
        "placeholder cannot be the eigenvariable")
corrupt("fresh eigenvariable does not match step",
        lambda d: d["nodes"][first_unique].update(eigenvariable="fresh_z"),
        "not the exact recurrence")
corrupt("absorption target is not passive",
        lambda d: d["nodes"][absorb_unique].update(eigenvariable="t"),
        "eigenvariable occurs in template data")
corrupt("forward reference",
        lambda d: d["nodes"][symmetry_node].update(premise=symmetry_node + 1),
        "earlier node")
corrupt("boolean premise index",
        lambda d: d["nodes"][symmetry_node].update(premise=True),
        "earlier node")
corrupt("unknown arithmetic oracle",
        lambda d: d["nodes"][0].update(name="induction"),
        "unknown axiom")
corrupt("extra semantic oracle field",
        lambda d: d["nodes"][first_unique].update(semantic_truth=True),
        "uniqueness fields")
corrupt("reversed right-inverse equation",
        lambda d: d["nodes"][section_node]["conclusion"].__setitem__(
            0, ["j", ["h", ["A", ["v", "n"], ["v", "a"]]]]),
        "conclusion does not match")
corrupt("advertised theorem points to an irrelevant valid equation",
        lambda d: d["claims"].update(idempotence=d["claims"]["R_zero"]),
        "claim idempotence")
corrupt("ill-formed numerical term",
        lambda d: d["nodes"][0]["conclusion"].__setitem__(0, ["L", ["0"]]),
        "incorrect arity")

# New proof obligations specific to the directed-envelope ingredients.
corrupt("fusion uses the j-iterator in place of the successor clock",
        lambda d: d["nodes"][fusion_unique].update(
            template=["L", ["A", ["v", "x"], ["v", "m"]], ["v", "a"]]),
        "not the exact recurrence")
corrupt("fusion eigenvariable captures the passive clock parameter",
        lambda d: d["nodes"][fusion_unique].update(eigenvariable="m"),
        "eigenvariable occurs in template data")
corrupt("fusion target captures the eigenvariable",
        lambda d: d["nodes"][fusion_unique].update(target=["v", "z"]),
        "eigenvariable occurs in target")
corrupt("commutation substitutes the fusion recurrence",
        lambda d: d["nodes"][commute_unique].update(
            premise=d["nodes"][fusion_unique]["premise"]),
        "not the exact recurrence")
corrupt("commutation omits the outer iterate",
        lambda d: d["nodes"][commute_unique].update(
            template=["L", ["v", "x"], ["v", "a"]]),
        "not the exact recurrence")
corrupt("fusion theorem is redirected to commutation",
        lambda d: d["claims"].update(iterator_fusion=d["claims"]["iterator_commutation"]),
        "claim iterator_fusion")
corrupt("commutation theorem is redirected to fusion",
        lambda d: d["claims"].update(iterator_commutation=d["claims"]["iterator_fusion"]),
        "claim iterator_commutation")
corrupt("uniqueness is given a hidden retained context",
        lambda d: d["nodes"][fusion_unique].update(context=["unproved recurrence"]),
        "uniqueness fields")
corrupt("successor clock is removed from the trusted signature",
        lambda d: d["nodes"][fusion_unique].update(
            template=["L", ["oracle_clock", ["v", "x"], ["v", "m"]], ["v", "a"]]),
        "unknown head")

# Confirm that the public command-line interface has the same verdicts.
good_run = subprocess.run(
    [sys.executable, str(HERE / "replay.py"), str(HERE / "envelope_certificate.json")],
    capture_output=True, text=True, check=False)
if good_run.returncode != 0 or json.loads(good_run.stdout)["status"] != "ACCEPT":
    raise AssertionError("valid certificate failed the command-line interface")
with tempfile.TemporaryDirectory() as directory:
    bad = copy.deepcopy(original)
    bad["nodes"][first_unique]["eigenvariable"] = "a"
    path = Path(directory) / "bad.json"
    path.write_text(json.dumps(bad))
    bad_run = subprocess.run([sys.executable, str(HERE / "replay.py"), str(path)],
                             capture_output=True, text=True, check=False)
    if bad_run.returncode != 1 or json.loads(bad_run.stdout)["status"] != "REJECT":
        raise AssertionError("invalid certificate passed the command-line interface")

report = {"scope": "iterator-equation fragment only", "valid_certificate": accepted,
          "corruptions_rejected": len(cases), "corruptions": cases,
          "cli_accept_exit": good_run.returncode, "cli_reject_exit": bad_run.returncode}
(HERE / "validation_results.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
