"""Read-only inventory of the pinned archive corpus.

The normalized whole-module metric follows the supplied source_measure.py:
strip comments and genuine docstrings; ast.unparse; count significant Python
tokens, every AST node, and UTF-8 bytes. No acceptance code is executed.
"""
import ast
import hashlib
import io
import json
import platform
from pathlib import Path
import tokenize

import sys
if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 code/audit_sources.py /absolute/path/to/sources')
SOURCES = Path(sys.argv[1]).resolve()
ROOT = SOURCES.parent
OUT = Path(__file__).resolve().parent.parent / 'evidence'
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(raw):
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw)))
    normalized = ast.unparse(tree) + '\n'
    return {
        'normalized_tokens': sum(t.type not in IGNORED for t in
                                 tokenize.generate_tokens(io.StringIO(normalized).readline)),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized.encode()),
        'raw_bytes': len(raw),
    }


def main():
    manifest = json.loads((SOURCES / 'manifest.json').read_text())
    archive_rows = []
    for item in manifest['files']:
        raw = (SOURCES / item['name']).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        if blob != item['git_blob_sha'] or len(raw) != item['size']:
            raise ValueError('Archive identity mismatch: ' + item['name'])
        archive_rows.append({**item, 'sha256': hashlib.sha256(raw).hexdigest()})
    groups = {}
    for path in sorted(SOURCES.rglob('*.py')):
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        row = groups.setdefault(digest, {'sha256': digest, 'occurrences': []})
        row['occurrences'].append(str(path.relative_to(ROOT)))
        if 'metrics' not in row:
            try:
                row['metrics'] = measure(raw)
                row['has_cli_verdict_literals'] = b'ACCEPT' in raw and b'REJECT' in raw
            except Exception as exc:
                row['parse_error'] = type(exc).__name__ + ': ' + str(exc)
    candidates = sorted((row for row in groups.values()
                         if row.get('has_cli_verdict_literals')
                         and row['metrics']['normalized_tokens'] < 312),
                        key=lambda row: row['metrics']['normalized_tokens'])
    report = {
        'repository': manifest['repository'],
        'commit': manifest['commit'],
        'python': platform.python_version(),
        'metric_scope': 'Whole source; true docstrings/comments removed; ast.unparse normalization.',
        'archive_count': len(archive_rows),
        'python_occurrence_count': sum(len(x['occurrences']) for x in groups.values()),
        'distinct_python_sources': len(groups),
        'archive_integrity': archive_rows,
        'small_cli_candidates': candidates,
        'classification': 'Candidate completeness is based on accompanying reports, not inferred from source size.',
        'observed_complete_coordinate_envelope': {
            'runtime_inclusive': {'normalized_tokens': 305, 'ast_nodes': 340, 'normalized_bytes': 820},
            'strict_guarded': {'normalized_tokens': 305, 'ast_nodes': 341, 'normalized_bytes': 820},
        },
        'caveat': 'The coordinates have different attainers. This is a finite-corpus empirical envelope, not a lower-bound theorem. The inherited normalized-byte metric is identifier-sensitive.',
        'all_distinct_python_sources': list(groups.values()),
    }
    (OUT / 'corpus_audit.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('commit', 'archive_count', 'python_occurrence_count', 'distinct_python_sources', 'observed_complete_coordinate_envelope')}, indent=2))


if __name__ == '__main__':
    main()
