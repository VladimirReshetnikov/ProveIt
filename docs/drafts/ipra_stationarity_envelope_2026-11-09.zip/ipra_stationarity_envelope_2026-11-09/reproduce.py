"""Run the scoped certificate and whole-source measurements offline."""
import json
import platform
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(arguments):
    result = subprocess.run([sys.executable, *arguments], cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return {'arguments': arguments, 'exit_code': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr}


def main():
    commands = [
        ['code/envelope_certificate/replay.py', 'code/envelope_certificate/envelope_certificate.json'],
        ['code/envelope_certificate/test_certificate.py'],
        ['-O', 'code/envelope_certificate/test_certificate.py'],
        ['code/measure_comparators.py'],
    ]
    receipts = [run(command) for command in commands]
    result = {'status': 'PASS', 'python': platform.python_version(), 'receipts': receipts}
    (ROOT / 'evidence' / 'reproduction.json').write_text(json.dumps(result, indent=2) + '\n')
    print('PASS: certificate, 24 rejection controls, CLI checks, optimized replay, seven source measurements.')


if __name__ == '__main__':
    main()
