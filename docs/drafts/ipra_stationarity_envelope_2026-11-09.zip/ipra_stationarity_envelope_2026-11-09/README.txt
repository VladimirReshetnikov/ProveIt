A DEFINABLE STATIONARITY QUOTIENT FOR iPRA CANDIDATES
9 November 2026
==================================================

START WITH ipra_stationarity_envelope.pdf.

OUTCOME
-------
The requested new complete axiomatization below the entire current
proof-checker frontier has NOT been obtained. This package reports a new
structural result relative to the inspected drafts, a full first-order
observational consequence, and the exact remaining gap. It includes a
self-contained, inherited reference theory bi-interpretable with full
first-order iPRA. The reference theory is not claimed as a new improvement.

NEW MATHEMATICAL RESULT
-----------------------
Assume full fixed-description primitive-recursive equations, ordinary
intuitionistic equality logic, h(j(a))=a, and contextual uniqueness U_h for
one fixed recurrence h. Write L=I_h, A=I_j and R_t(a)=L(t,A(t,a)).

The existing draft proves compatible idempotence and congruence for ker R_t.
This report proves those congruences are internally directed, using the
separate successor clock n (+) m=I_S(n,m). Thus

  Theta(a,b)  iff  exists t [R_t(a)=R_t(b)]

is one definable congruence. In every classical source model it is exactly
the least congruence identifying the endpoints of every term trajectory
that is stationary under actual SOURCE equality. No coding of all term
templates or uniform PR evaluator is introduced.

For W(0)=1, W(Sa)=a, with coverage and separation, the quotient has singleton
standard-numeral classes. Every first-order formula built from atoms F=0 is
preserved and reflected by its quotient map. The internal intuitionistic
version says all R_t substitutions preserve that whole fragment, including
arbitrarily alternating quantifiers. Any total injective code for the raw
domain definable in this fragment would force every R_t to be the identity.

THE EXACT UNRESOLVED POINT
-------------------------
A recurrence may become true only modulo Theta. The report does not prove
that the quotient preserves U_h or stationarity for newly stationary
quotient trajectories. It does not construct a nonidentity R_t in a full
T_W model, prove T_W equivalent to iPRA, or claim a smaller complete checker.

FILES
-----
ipra_stationarity_envelope.pdf   Compiled full report.
ipra_stationarity_envelope.tex   Entire report in one compilable TeX file.
report.tex, sections/           Editable modular sources.
reference/                     Attributed arithmetic completion appendix,
                               unchanged source license.
code/envelope_certificate/      Producer, independent scoped replayer,
                               explicit certificate, tests and attribution.
code/comparators/               Seven unchanged compact comparator sources
                               and inherited whole-source normalizer.
code/measure_comparators.py     Offline whole-source metric reproduction.
code/audit_sources.py           Full corpus audit when original archives and
                               extracted members are supplied.
evidence/                      Pinned source identities, full source inventory,
                               actual verification and PDF build receipts.
ATTRIBUTION.txt                 Contribution and provenance boundaries.
MANIFEST.json                  SHA-256 payload manifest.

REPRODUCTION
------------
Python 3.12.14 reproduces the recorded AST/unparser source metrics.
All executable evidence uses the Python standard library.

  python3 reproduce.py
  python3 build.py
  python3 package.py

The first command replays the 79-node, eight-claim certificate, runs its
24 targeted corruptions and CLI checks under ordinary and optimized Python,
and measures the seven unchanged complete comparators. It does not execute
the comparator acceptance programs. The symbolic certificate has seven
explicit computation schemas and six empty-context U_h applications; it
is not a complete iPRA verifier or a Lean/Rocq formalization.

The second command builds the report using pdflatex, with shell escape
disabled, and regenerates its standalone TeX source. Required ordinary
TeX Live packages are listed in report.tex. No network is needed.
The third writes the content-hash manifest, creates a deterministic ZIP,
and verifies CRCs and every manifested payload hash.

To repeat the full 17-archive inventory, supply a directory containing the
original ZIP files, their extracted directories, and evidence/source_manifest.json
renamed manifest.json:

  python3 code/audit_sources.py /absolute/path/to/sources

The 17 original archives are not duplicated inside this deliverable.
The normal offline reproduction covers the exact seven compact comparators.

COMPARISON SNAPSHOT
-------------------
Repository: VladimirReshetnikov/ProveIt
Commit: 195e4becb0a1f99c5598f7e39e2cdeb81461b2e4
https://github.com/VladimirReshetnikov/ProveIt/tree/195e4becb0a1f99c5598f7e39e2cdeb81461b2e4/docs/drafts

17 ZIP identities verified; 482 Python occurrences / 177 distinct sources.
Observed complete-source envelope: 305 tokens / 340 AST nodes / 820 bytes.
Strict guarded envelope: 305 / 341 / 820. Different files attain these
coordinates. These are empirical implementation bounds, not a proved
lower bound or a single simultaneous source-size record.

No repository changes were made.
