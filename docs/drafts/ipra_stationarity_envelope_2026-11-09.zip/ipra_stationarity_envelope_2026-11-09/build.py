"""Compile the modular report and write its complete standalone TeX source."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
STEM = 'ipra_stationarity_envelope'


def expand(path):
    source = path.read_text()
    def replacement(match):
        child = ROOT / match.group(1)
        return '\n% BEGIN ' + match.group(1) + '\n' + expand(child) + '\n% END ' + match.group(1) + '\n'
    return re.sub(r'\\input\{([^}]+)\}', replacement, source)


def main():
    (ROOT / (STEM + '.tex')).write_text(expand(ROOT / 'report.tex'))
    with tempfile.TemporaryDirectory(prefix='ipra-tex-') as name:
        destination = Path(name)
        command = ['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
                   '-halt-on-error', '-output-directory=' + str(destination), 'report.tex']
        for _ in range(3):
            result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT)
            if result.returncode:
                raise RuntimeError(result.stdout)
        log = (destination / 'report.log').read_text(errors='replace')
        warnings = [line for line in log.splitlines()
                    if any(word in line for word in ('Overfull', 'Underfull', 'undefined', 'multiply defined'))]
        shutil.copyfile(destination / 'report.pdf', ROOT / (STEM + '.pdf'))
        receipt = {'status': 'PASS', 'passes': 3, 'shell_escape': False, 'warnings': warnings}
        (ROOT / 'evidence' / 'pdf_build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('Built', STEM + '.pdf')
    for warning in warnings:
        print(warning)


if __name__ == '__main__':
    main()
