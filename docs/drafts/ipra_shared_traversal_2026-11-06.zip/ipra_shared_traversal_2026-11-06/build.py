"""Rebuild the report using pdfLaTeX; run from any directory."""

import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    metrics = json.loads((ROOT / "comparison/results/metrics.json").read_text())
    c, m = metrics["candidate"], metrics["current_main_minima"]
    macros = {"CandidateTokens": c["normalized_tokens"], "CandidateAST": c["ast_nodes"],
              "CandidateBytes": c["raw_bytes"], "CandidateNormBytes": c["normalized_bytes"],
              "MinimumTokens": m["normalized_tokens"], "MinimumAST": m["ast_nodes"],
              "MinimumBytes": m["raw_bytes"], "MinimumNormBytes": m["normalized_bytes"]}
    (ROOT / "validation/metrics_macros.tex").write_text("".join(
        "\\newcommand{\\" + k + "}{" + str(v) + "}\n" for k, v in macros.items()))
    shutil.copyfile(ROOT / "comparison/results/main_table.tex",
                    ROOT / "validation/comparison_table.tex")
    build = ROOT / ".build"
    build.mkdir(exist_ok=True)
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "-output-directory=" + str(build), "report.tex"]
    for _ in range(3):
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        (build / "console.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-6000:])
            raise SystemExit(result.returncode)
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    print("Built report.pdf")


if __name__ == "__main__":
    main()
