"""Independent finite audit of a fused unary iPRA checker.

Usage:
  python3 new_audit.py CHECKER --inherited VALIDATION_DIR --out OUTPUT_DIR

Expected API: check(data), infer(proof, context), erase(data), and
subst(tree, env=(1,), d=0, formula=None).  The source checker is imported
only as the object under test.  Expected substitutions are computed by
decoding variables to free names and fresh bound identities, replacing
free names, then re-encoding.  No candidate scope table, traversal,
builder, or substitution helper is used to construct expectations.

This is finite regression evidence, not a machine-checked soundness proof.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys


ZERO = -1
T = ["=", ZERO, ZERO]
D = ["=", ZERO, ["s", ZERO]]
FALSE = ["false"]
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)
SEED = 2026110607


def parts(a, tag, arity):
    if type(a) is not list or len(a) != arity + 1 or a[0] != tag:
        raise ValueError("wrong node")
    return a[1:]


def read_term(a, bound=()):
    if type(a) is int:
        if a == ZERO:
            return ("zero",)
        if a < 0:
            raise ValueError("negative variable")
        return ("bound", bound[a]) if a < len(bound) else ("free", a - len(bound))
    if type(a) is not list or not a:
        raise ValueError("not a term")
    if a[0] == "s":
        body, = parts(a, "s", 1)
        return ("succ", read_term(body, bound))
    if a[0] == "r":
        counter, initial, body = parts(a, "r", 3)
        state, step = object(), object()
        return ("rec", read_term(counter, bound), read_term(initial, bound),
                state, step, read_term(body, (state, step) + bound))
    raise ValueError("not a term constructor")


def read_formula(a, bound=()):
    if type(a) is not list or not a:
        raise ValueError("not a formula")
    if a[0] == "=":
        left, right = parts(a, "=", 2)
        return ("eq", read_term(left, bound), read_term(right, bound))
    if a[0] == "pi":
        guard, body = parts(a, "pi", 2)
        name = object()
        return ("pi", name, read_formula(guard, (name,) + bound),
                read_formula(body, (name,) + bound))
    if a[0] == "ex":
        body, = parts(a, "ex", 1)
        name = object()
        return ("ex", name, read_formula(body, (name,) + bound))
    raise ValueError("not a native formula constructor")


def write_named(a, bound=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "free":
        return a[1] + len(bound)
    if tag == "bound":
        return bound.index(a[1])
    if tag == "succ":
        return ["s", write_named(a[1], bound)]
    if tag == "rec":
        return ["r", write_named(a[1], bound), write_named(a[2], bound),
                write_named(a[5], (a[3], a[4]) + bound)]
    if tag == "eq":
        return ["=", write_named(a[1], bound), write_named(a[2], bound)]
    if tag == "pi":
        return ["pi", write_named(a[2], (a[1],) + bound),
                write_named(a[3], (a[1],) + bound)]
    if tag == "ex":
        return ["ex", write_named(a[2], (a[1],) + bound)]
    raise ValueError("unknown named node")


def replace_free(a, image):
    tag = a[0]
    if tag == "free":
        return image(a[1])
    if tag in ("zero", "bound"):
        return a
    if tag == "succ":
        return (tag, replace_free(a[1], image))
    if tag == "rec":
        return (tag, replace_free(a[1], image), replace_free(a[2], image),
                a[3], a[4], replace_free(a[5], image))
    if tag == "eq":
        return (tag, replace_free(a[1], image), replace_free(a[2], image))
    if tag == "pi":
        return (tag, a[1], replace_free(a[2], image), replace_free(a[3], image))
    if tag == "ex":
        return (tag, a[1], replace_free(a[2], image))
    raise ValueError("unknown named node")


def oracle_subst(a, env, d, formula):
    bound = tuple(object() for _ in range(d))
    named = read_formula(a, bound) if formula else read_term(a, bound)
    prefix = tuple(read_term(t) for t in env[:-1])
    offset = env[-1]
    if type(offset) is not int or len(prefix) + offset < 0:
        raise ValueError("invalid environment")

    def image(i):
        return prefix[i] if i < len(prefix) else ("free", i + offset)

    return write_named(replace_free(named, image), bound)


def numerical_formula(a, force_induction=False):
    """Construct the stated N schema using fresh names, not index arithmetic."""
    original = read_formula(a)
    x, y, dummy = object(), object(), object()

    def at(value):
        return replace_free(original, lambda i: value if i == 0 else ("free", i - 1))

    base = at(("zero",))
    hypothesis = at(("bound", y)) if a[0] == "=" or force_induction else base
    step = ("pi", y, hypothesis, at(("succ", ("bound", y))))
    return write_named(("pi", x, base, ("pi", dummy, step, at(("bound", x)))))


def random_term(rng, depth, bound=0):
    if depth == 0 or rng.randrange(4) == 0:
        return rng.choice([ZERO, *range(bound + 4)])
    if rng.randrange(2) == 0:
        return ["s", random_term(rng, depth - 1, bound)]
    return ["r", random_term(rng, depth - 1, bound),
            random_term(rng, depth - 1, bound),
            random_term(rng, depth - 1, bound + 2)]


def random_formula(rng, depth, bound=0):
    if depth == 0 or rng.randrange(3) == 0:
        return ["=", random_term(rng, 2, bound), random_term(rng, 2, bound)]
    if rng.randrange(2) == 0:
        return ["ex", random_formula(rng, depth - 1, bound + 1)]
    return ["pi", random_formula(rng, depth - 1, bound + 1),
            random_formula(rng, depth - 1, bound + 1)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checker", type=Path)
    parser.add_argument("--inherited", type=Path, required=True,
                        help="Directory containing certificate_results.json and certificates/")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    fixture_dir = args.out / "new_certificates"
    fixture_dir.mkdir(exist_ok=True)
    spec = importlib.util.spec_from_file_location("audited_checker", args.checker)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    failures = []
    records = []
    counts = {"inherited_accept": 0, "inherited_reject": 0,
              "new_accept": 0, "new_reject": 0,
              "named_substitutions": 0, "formation_rejections": 0,
              "cli_invocations": 0, "canonical_alias_outputs": 0}

    def check_case(name, data, expected, inherited=False, cli=False):
        encoded = json.dumps(data, separators=(",", ":")) + "\n"
        try:
            result = checker.check(copy.deepcopy(data))
            accepted = result is True
            detail = None if accepted else "check did not return True"
        except ERRORS as error:
            accepted, detail = False, type(error).__name__
        except Exception as error:
            accepted, detail = False, "uncaught: " + type(error).__name__
            failures.append({"name": name, "unexpected_exception": repr(error)})
        if accepted != expected:
            failures.append({"name": name, "expected": expected,
                             "actual": accepted, "detail": detail})
        counts[("inherited_" if inherited else "new_") + ("accept" if expected else "reject")] += 1
        record = {"name": name, "expected_accept": expected,
                  "actual_accept": accepted, "sha256": hashlib.sha256(encoded.encode()).hexdigest()}
        if not inherited:
            path = fixture_dir / (name + ".json")
            path.write_text(encoded)
            record["file"] = str(path.relative_to(args.out))
        if cli:
            path = fixture_dir / (name + ".json")
            for optimized in (False, True):
                command = [sys.executable] + (["-O"] if optimized else []) + [str(args.checker.resolve()), str(path.resolve())]
                result = subprocess.run(command, text=True, capture_output=True, timeout=20)
                good = result.returncode == (0 if expected else 1) and result.stdout.strip() == ("ACCEPT" if expected else "REJECT")
                counts["cli_invocations"] += 1
                if not good:
                    failures.append({"name": name, "cli_optimized": optimized,
                                     "returncode": result.returncode, "stdout": result.stdout,
                                     "stderr": result.stderr})
        records.append(record)

    manifest = json.loads((args.inherited / "certificate_results.json").read_text())
    for record in manifest["certificates"]:
        data_bytes = (args.inherited / record["file"]).read_bytes()
        if hashlib.sha256(data_bytes).hexdigest() != record["sha256"]:
            raise ValueError("inherited fixture changed: " + record["name"])
        check_case("inherited/" + record["name"], json.loads(data_bytes), record["accepted"], inherited=True)

    # Every formula-bearing input location that is normalized by public erasure.
    check_case("false_assumption", [[FALSE], D, ["hyp", D]], True, cli=True)
    check_case("false_goal", [[D], FALSE, ["hyp", D]], True)
    check_case("false_hypothesis_key", [[D], D, ["hyp", FALSE]], True)
    check_case("false_pi_guard", [[], ["pi", D, D], ["pi", FALSE, ["hyp", D]]], True)
    check_case("false_pack_body", [[D], ["ex", D], ["pack", ZERO, ["hyp", FALSE]]], True)
    check_case("false_equality_template", [[T, D], D,
               ["use", ["hyp", T], FALSE, ["hyp", D]]], True)
    check_case("false_existential_conclusion", [[["ex", D]], D,
               ["use", ["hyp", ["ex", D]], FALSE, ["hyp", D]]], True)
    check_case("false_nested_assumption", [[["ex", ["pi", FALSE, FALSE]]],
               ["ex", ["pi", D, D]], ["hyp", ["ex", ["pi", D, D]]]], True)
    check_case("false_numerical_template", [[], numerical_formula(D), ["nat", FALSE]], True, cli=True)
    public_matrix = ["ex", ["pi", FALSE, FALSE]]
    native_matrix = ["ex", ["pi", D, D]]
    check_case("false_nested_numerical_template", [[], numerical_formula(native_matrix), ["nat", public_matrix]], True)

    # Complete numerical schemas, expected via named binders, including parameters.
    matrices = [T, D, ["=", 0, 1], ["=", ["r", 0, 1, ["s", 2]], 1],
                ["ex", ["=", 0, 1]], ["pi", ["=", 0, 2], ["ex", ["=", 0, 2]]]]
    for i, matrix in enumerate(matrices):
        check_case(f"named_numerical_schema_{i}", [[], numerical_formula(matrix), ["nat", matrix]], True)
    for i, matrix in enumerate(matrices[-2:]):
        check_case(f"forbidden_quantified_induction_{i}",
                   [[], numerical_formula(matrix, force_induction=True), ["nat", matrix]], False, cli=True)

    # A permissive lookup key must return the stored canonical formula.
    for i, alias in enumerate((False, 0.0)):
        context = [["=", 0, ZERO]]
        key = ["=", alias, ZERO]
        result = checker.infer(["hyp", key], context)
        counts["canonical_alias_outputs"] += 1
        if result is not context[0]:
            failures.append({"name": f"canonical_alias_output_{i}", "error": "did not return stored object"})
        check_case(f"canonical_alias_key_{i}", [context, context[0], ["hyp", key]], True)
        check_case(f"invalid_alias_goal_{i}", [context, key, ["hyp", context[0]]], False)

    # Malformed annotations must be rejected even if the logical result ignores them.
    bad_terms = [False, True, 0.0, -1.0, -2, "0", {}, [], ["s"], ["s", ZERO, ZERO],
                 ["r", ZERO, ZERO, T], ["r", ZERO, ZERO], ["r", ZERO, ZERO, ZERO, ZERO],
                 T, ["ex", T], FALSE]
    pi_t = ["pi", T, T]
    for i, bad in enumerate(bad_terms):
        check_case(f"ignored_pi_witness_{i:02}", [[pi_t, T], T,
                   ["use", ["hyp", pi_t], bad, ["hyp", T]]], False, cli=i == 0)
        check_case(f"ignored_ex_witness_{i:02}", [[T], ["ex", T],
                   ["pack", bad, ["hyp", T]]], False, cli=i == 2)

    # A bad equation produced by a missing recursor check must not be hidden by
    # equality transport through a constant template.
    malformed_bodies = [False, 0.0, -2, "body", {}, [], T, ["ex", T], FALSE,
                        ["s", ZERO, ZERO], ["r", ZERO, ZERO, T]]
    for i, body in enumerate(malformed_bodies):
        rec = ["r", ZERO, ZERO, body]
        check_case(f"ignored_recursion_body_{i:02}", [[T], T,
                   ["use", ["rec", rec], T, ["hyp", T]]], False, cli=i == 0)
    for i, counter in enumerate((0, ["s"], ["s", ZERO, ZERO], False, -1.0)):
        rec = ["r", counter, ZERO, ZERO]
        check_case(f"invalid_recursion_counter_{i}", [[T], T,
                   ["use", ["rec", rec], T, ["hyp", T]]], False)

    bad_formulas = [False, 0.0, ZERO, [], {}, ["="], ["=", ZERO], ["=", ZERO, ZERO, ZERO],
                    ["=", False, ZERO], ["=", ZERO, -1.0], ["s", ZERO],
                    ["ex"], ["ex", T, T], ["ex", ZERO],
                    ["pi", T], ["pi", T, T, T], ["pi", ZERO, T]]
    for i, bad in enumerate(bad_formulas):
        check_case(f"bad_root_assumption_{i:02}", [[T, bad], T, ["hyp", T]], False)
        check_case(f"bad_pi_guard_{i:02}", [[T], ["pi", T, T],
                   ["pi", bad, ["hyp", T]]], False)
        check_case(f"bad_transport_template_{i:02}", [[T], T,
                   ["use", ["hyp", T], bad, ["hyp", T]]], False)
        check_case(f"bad_existential_conclusion_{i:02}", [[["ex", T], T], T,
                   ["use", ["hyp", ["ex", T]], bad, ["hyp", T]]], False)

    check_case("pi_eigenvariable_escape", [[["=", 0, ZERO]], ["pi", T, ["=", 0, ZERO]],
               ["pi", T, ["hyp", ["=", 0, ZERO]]]], False, cli=True)
    ex_zero = ["ex", ["=", 0, ZERO]]
    check_case("existential_witness_escape", [[ex_zero], ["=", 0, ZERO],
               ["use", ["hyp", ex_zero], ["=", 0, ZERO], ["hyp", ["=", 0, ZERO]]]], False)
    for i, proof in enumerate((["hyp", T, T], ["pi", T], ["use", ["hyp", T], T],
                               ["pack", ZERO], ["nat", T, T], ["rec", ["r", ZERO, ZERO, ZERO], T])):
        check_case(f"wrong_proof_arity_{i}", [[T], T, proof], False)

    # Independent binding oracle, with fixed samples covering both binder widths.
    terms = [ZERO, 0, 3, ["s", 0], ["r", 0, 1, ["s", 0]],
             ["r", ["s", 2], 0, ["r", 1, 0, ["s", 4]]]]
    formulas = [T, ["=", 0, 2], ["ex", ["=", 0, 1]],
                ["pi", ["=", 0, 2], ["ex", ["=", 0, 2]]],
                ["ex", ["=", ["r", 1, 0, ["r", 1, 0, 5]], 2]]]
    environments = [(0,), (1,), (2,), (ZERO, -1), (ZERO, 0), (["s", 0], 0),
                    (["r", 1, 0, ["s", 2]], ["s", 1], -2)]
    rng = random.Random(SEED)
    substitution_inputs = []
    for d in range(4):
        for formula, collection in ((False, terms), (True, formulas)):
            for a in collection:
                for env in environments:
                    substitution_inputs.append((a, env, d, formula))
    for _ in range(120):
        formula = bool(rng.randrange(2))
        d = rng.randrange(4)
        a = random_formula(rng, 3, d) if formula else random_term(rng, 4, d)
        prefix_size = rng.randrange(4)
        env = [random_term(rng, 2) for _ in range(prefix_size)] + [rng.randrange(-prefix_size, 3)]
        substitution_inputs.append((a, env, d, formula))
    substitution_records = []
    for i, (a, env, d, formula) in enumerate(substitution_inputs):
        expected = oracle_subst(a, env, d, formula)
        try:
            actual = checker.subst(copy.deepcopy(a), copy.deepcopy(env), d, formula)
        except Exception as error:
            actual = {"error": repr(error)}
        counts["named_substitutions"] += 1
        if actual != expected:
            failures.append({"name": f"named_substitution_{i}", "input": a, "env": env,
                             "d": d, "formula": formula, "expected": expected, "actual": actual})
        substitution_records.append({"tree": a, "env": env, "d": d, "formula": formula,
                                     "expected": expected})
    (args.out / "substitution_cases.json").write_text(json.dumps(substitution_records, indent=2) + "\n")

    # Sort mistakes and exact arities are checked by the traversal directly.
    formation_inputs = [(a, False) for a in bad_terms] + [(a, True) for a in bad_formulas]
    formation_inputs += [(a, True) for a in terms] + [(a, False) for a in formulas]
    for i, (a, formula) in enumerate(formation_inputs):
        try:
            checker.subst(copy.deepcopy(a), (0,), 0, formula)
        except ERRORS:
            pass
        else:
            failures.append({"name": f"formation_{i}", "input": a, "formula": formula})
        counts["formation_rejections"] += 1

    # JSON transport and optimization mode: a small boundary-focused selection.
    for i, raw in enumerate(("[", "NaN", '{"context": [], "goal": 0}', "null")):
        path = args.out / f"malformed_json_{i}.txt"
        path.write_text(raw)
        for optimized in (False, True):
            command = [sys.executable] + (["-O"] if optimized else []) + [str(args.checker.resolve()), str(path.resolve())]
            result = subprocess.run(command, text=True, capture_output=True, timeout=20)
            counts["cli_invocations"] += 1
            if result.returncode != 1 or result.stdout.strip() != "REJECT":
                failures.append({"name": f"json_boundary_{i}", "optimized": optimized,
                                 "returncode": result.returncode, "stdout": result.stdout,
                                 "stderr": result.stderr})

    result = {"status": "passed" if not failures else "failed",
              "python_version": platform.python_version(), "seed": SEED,
              "checker_sha256": hashlib.sha256(args.checker.read_bytes()).hexdigest(),
              "audit_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "counts": counts, "failures": failures, "certificates": records,
              "qualification": "Finite independent regression checks; not a formal proof or exhaustive validation."}
    (args.out / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ("status", "checker_sha256", "counts", "failures")}, indent=2))
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
