"""Reproduce complete-checker size measurements without executing checkers.

Run from any directory with Python 3.10 or later. Only Python's standard
library is required. All frozen baseline and ablation hashes are verified.
"""

import ast
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path


ROOT = Path(__file__).resolve().parent
AXES = ("raw_bytes", "normalized_bytes", "source_tokens",
        "normalized_tokens", "ast_nodes")


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    """Count complete source, excluding only documentation and layout."""
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    excluded = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
                tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in excluded
              and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    normalized_tokens = [
        t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
        if t.type not in excluded]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return dict(
        sha256=hashlib.sha256(data).hexdigest(), raw_bytes=len(data),
        normalized_bytes=len(normalized.encode("utf-8")),
        source_tokens=len(tokens), normalized_tokens=len(normalized_tokens),
        ast_nodes=sum(1 for _ in ast.walk(tree)), lines=len(source.splitlines()),
        imported_modules=sorted(set(imports)))


def envelope(rows):
    return {key: min(row["metrics"][key] for row in rows) for key in AXES}


def verified_rows(records):
    rows = []
    for record in records:
        metrics = measure(ROOT / record["path"])
        if metrics["sha256"] != record["sha256"]:
            raise ValueError("Frozen comparator changed: " + record["path"])
        if metrics["imported_modules"] != ["json", "sys"]:
            raise ValueError("Uncounted import requires review: " + record["path"])
        rows.append(dict(record, metrics=metrics))
    return rows


def tex_table(path, rows, candidate=None, minima=None):
    keys = ("raw_bytes", "normalized_bytes", "normalized_tokens", "ast_nodes")
    out = [r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
           r"Complete checker & Bytes & Norm.\ bytes & Norm.\ tokens & AST \\",
           r"\midrule"]
    for row in rows:
        out.append(row["label"] + " & " + " & ".join(
            f'{row["metrics"][key]:,}' for key in keys) + r" \\")
    if minima is not None:
        out.extend([r"\midrule", "Coordinate minima & " + " & ".join(
            f"{minima[key]:,}" for key in keys) + r" \\"])
    if candidate is not None:
        out.append(r"\textbf{Fused unary kernel} & " + " & ".join(
            r"\textbf{" + f"{candidate[key]:,}" + "}" for key in keys) + r" \\")
    out.extend([r"\bottomrule", r"\end{tabular}"])
    path.write_text("\n".join(out) + "\n")


def main():
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text())
    mains = verified_rows(manifest["current_main"])
    controls = verified_rows(manifest["current_controls"])
    legacy = verified_rows(manifest["legacy_curated"])
    ablations = verified_rows(manifest["ablation_sequence"])
    candidate = measure(ROOT / "checker.py")
    if candidate["imported_modules"] != ["json", "sys"]:
        raise ValueError("Candidate has an uncounted dependency")
    minima = envelope(mains)
    extended = envelope(mains + controls + legacy)
    result = dict(
        repository=manifest["repository"], commit=manifest["commit"],
        python_version=platform.python_version(),
        method=("Full acceptance programs, including formation, binding, "
                "arithmetic schemas, falsity handling where supplied, imports "
                "and JSON CLI. Comments, genuine docstrings and layout are "
                "excluded from significant tokens. Normalized source is "
                "ast.unparse after docstring removal plus one newline. "
                "AST counts include the complete resulting Python AST. "
                "Python and its standard library are a common runtime. "
                "No comparator is imported or executed by this script."),
        current_main=mains, current_controls=controls,
        legacy_curated=legacy, ablation_sequence=ablations,
        current_main_minima=minima, supporting_inventory_minima=extended,
        candidate=candidate,
        below_every_current_main_coordinate=all(
            candidate[key] < minima[key] for key in AXES),
        below_every_supporting_coordinate=all(
            candidate[key] < extended[key] for key in AXES),
        savings_against_main_minima={
            key: dict(absolute=minima[key] - candidate[key],
                      percent=100 * (minima[key] - candidate[key]) / minima[key])
            for key in AXES},
        qualification=("The principal comparison is the six current main "
                       "checkers. Ten immediate matched controls and 34 "
                       "curated previous-iteration sources are supporting "
                       "inventory only. This is a measured implementation "
                       "frontier, not a theorem of absolute minimality."))
    output = ROOT / "comparison/results"
    output.mkdir(exist_ok=True)
    (output / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    tex_table(output / "main_table.tex", mains, candidate, minima)
    tex_table(output / "ablation_table.tex", ablations)
    print(json.dumps({key: result[key] for key in (
        "python_version", "current_main_minima", "supporting_inventory_minima",
        "candidate", "below_every_current_main_coordinate",
        "below_every_supporting_coordinate")}, indent=2))


if __name__ == "__main__":
    main()
