"""Reproduce the measurements, validation, examples, and compiled paper."""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(script, *args):
    subprocess.run([sys.executable, str(ROOT / script), *map(str, args)],
                   cwd=ROOT, check=True)


if __name__ == "__main__":
    run("measure_checkers.py")
    run("verify_ablation_replay.py")
    run("validation/independent_audit.py", ROOT / "checker.py",
        "--inherited", ROOT / "validation/inherited",
        "--out", ROOT / "validation/independent_results")
    run("proof_tools/build_examples.py")
    run("build.py")
    print("Reproduction completed.")
