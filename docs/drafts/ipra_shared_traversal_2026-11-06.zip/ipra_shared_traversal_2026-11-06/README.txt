A SMALLER COMPLETE CHECKER FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
6 November 2026

Start with report.pdf. The complete LaTeX source is report.tex plus sections/.
The entire trusted acceptance implementation is checker.py.

RESULT

  Candidate: 808 normalized Python tokens, 855 executable AST nodes,
             2,618 normalized bytes, 2,928 raw bytes.
  Six current main drafts' coordinate minima:
             864 tokens, 915 AST nodes, 2,730 normalized bytes, 3,088 raw bytes.

The mathematical calculus retains the existing unary-existential basis.
This iteration reduces its complete proof-checker implementation by sharing
validation and finite-prefix substitution, validating witnesses while
performing the required lift, and combining matrix validation, zero
instantiation, and relifting in the numerical schema. Two smaller redundant
parameter eliminations are isolated in the supplied ablations.

This is a strict reproducible improvement over the supplied concrete
implementations. It is not an absolute shortest-program or minimality theorem.

THEORY

The native formula constructors are equality, Pi_x(A;B), and E_x A.
Their ordinary readings are forall x (A -> B) and exists x A.
There are six logical rule patterns, explicit public falsity conversion
bottom <-> 0=S0, two recursor computation schemas, and a single numerical
schema which grants equation induction and otherwise only numerical cases.
Conjunction, disjunction, equality laws, explosion, successor laws,
coverage, and all reference quantifier-free induction are derived.

The report gives whole-domain ordinary first-order bi-interpretations with
full first-order iPRA. The identity relation defines both internal round-trip
isomorphisms. Finite recursion descriptions are elaborated to fixed function
symbols; no universal primitive-recursive evaluator is postulated.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 9e338a5c51a26ac6ae90f2d8f563a44c3879ba68
Directory: docs/drafts

All six current main checkers are frozen unchanged. A supporting inventory
adds ten immediate control programs and 34 explicitly enumerated programs
from the preceding iteration. No supporting source lowers the main minima.
Exact Git blob IDs, ZIP hashes, member paths, source hashes, and attribution
are in comparison/manifest.json and comparison/README.txt.

VALIDATION

Independent audit: 116 inherited and 18 new positive certificates accepted;
60 inherited and 128 new negative certificates rejected; 428 named-variable
substitution comparisons; 44 direct formation checks; 24 CLI checks including
Python optimization mode; two stored-object alias checks. Zero failures.
Matched ablation replay: 176 fixed expectations at each of six stages, all pass.
Five additional closed demonstration theorems are checked by the candidate
and the frozen original unary checker.

The independent oracle uses free names and fresh bound identities, rather
than another copy of the candidate's index arithmetic. Mathematical soundness
and bi-interpretability are proved in the report, not formally verified in
Lean or Rocq. Finite test outcomes are not asserted to be exhaustive.

REPRODUCING

Python 3.10+ and its standard library suffice for the checker and tests.
Measurements were generated with Python 3.12.14. For the PDF, install
pdfLaTeX and the conventional packages named in report.tex.

From this directory:

  python3 checker.py examples/coverage.json
  python3 measure_checkers.py
  python3 verify_ablation_replay.py
  python3 validation/independent_audit.py checker.py --inherited validation/inherited --out validation/independent_results
  python3 proof_tools/build_examples.py
  python3 build.py

Or run the whole sequence with:

  python3 reproduce.py

All scripts also work by absolute path. No network access is needed.
The checker prints ACCEPT or REJECT and uses process status 0 or 1.
An accepted certificate with assumptions proves only that conditional sequent.
See FORMAT.txt for the de Bruijn convention; the integer 0 denotes a variable,
whereas the object-language zero is encoded by -1.

ATTRIBUTION

The supplied unary-existential proposal is the source of the retained
calculus, formula amalgamation, arithmetic reflection, recursion
bi-interpretation, finite-prefix environments, inherited 176 fixtures, and
the unchanged untrusted named builder in proof_tools/builder.py.
The single-traversal and uniform proposals supply the validating traversal
and scope-table design. This report consolidates the mathematical arguments
and contributes the smaller combined complete implementation and audits.

FILES

report.tex, sections/, report.pdf    Complete mathematical report.
checker.py                          Entire trusted checker.
comparison/                         Frozen programs, provenance, metrics,
                                    ablations, and fixed replay cases.
validation/                         Independent audit and materialized results.
proof_tools/                        Untrusted proof builder and demo generator.
examples/                           Five closed theorem certificates.
EXAMPLES.txt, FORMAT.txt             Readings and input specification.
measure_checkers.py                  Reproducible complete-source measurements.
verify_ablation_replay.py            Fixed-expectation matched regressions.
build.py, reproduce.py               PDF build and complete reproduction.
SHA256SUMS.txt                       Packaged-file hashes excluding itself.
