"""Independent bounded differential evidence; not a trusted proof checker."""
import ast
import copy
import hashlib
import json
import random
from pathlib import Path

WORK = Path(__file__).resolve().parent.parent
OLD = WORK / 'comparison'
NEW = WORK / 'code'
FIXTURES = NEW / 'validation'


def load(path):
    tree = ast.parse(path.read_text())
    assert isinstance(tree.body[-1], ast.Try)
    tree.body.pop()
    ns = {}
    exec(compile(tree, str(path), 'exec'), ns)
    return ns


def run(ns, packet):
    data = copy.deepcopy(packet)
    ns['k'] = 0
    try:
        ns['q'] = data.pop
        value = bool(ns['c'](data.pop(), []))
        return value, ns['k'], len(data)
    except BaseException:
        return False, None, None


def paths(value, prefix=()):
    yield prefix
    if isinstance(value, list):
        for j, item in enumerate(value):
            yield from paths(item, prefix + (j,))


def replace(value, path, image):
    if not path:
        return copy.deepcopy(image)
    result = copy.deepcopy(value)
    target = result
    for i in path[:-1]:
        target = target[i]
    target[path[-1]] = copy.deepcopy(image)
    return result


def main():
    pairs = [('choice_tokens.py', 'tokens.py'),
             ('choice_tokens.py', 'structure.py'),
             ('choice_bytes.py', 'bytes.py')]
    engines = [(x, y, load(OLD/x), load(NEW/y)) for x, y in pairs]
    records = json.loads((FIXTURES/'converted_inherited_certificates.json').read_text())['records']
    focused = json.loads((FIXTURES/'focused_certificates.json').read_text())['cases']
    packets = [r['packet'] for r in records + focused]
    seed = 20261109
    rng = random.Random(seed)
    atoms = [None, False, True, 0, 1, 2, -1, -2, 0.0, 1.5,
             '', 'x', {}, {'x': 0}, [], [0], [0, 0], [0, 0, 0], [0, 0, 0, 0]]
    short = [p for p in packets if len(json.dumps(p)) < 10000]
    for _ in range(5000):
        original = rng.choice(short)
        packet = replace(original, rng.choice(list(paths(original))), rng.choice(atoms))
        if isinstance(packet, list) and packet and rng.random() < 0.2:
            del packet[rng.randrange(len(packet))]
        packets.append(packet)
    for _ in range(1000):
        packets.append([rng.choice(atoms) for _ in range(rng.randrange(8))])
    checked = 0
    for number, packet in enumerate(packets):
        for oldname, newname, old, new in engines:
            a, b = run(old, packet), run(new, packet)
            if a[0] != b[0] or (a[0] and a != b):
                raise RuntimeError((number, oldname, newname, a, b, packet))
            checked += 1
    result = {
        'seed': seed,
        'packet_count': len(packets),
        'differential_comparisons': checked,
        'mismatches': 0,
        'claim': 'Bounded differential evidence only; see written trace-equivalence argument.',
        'pairs': [
            {'old': x, 'new': y,
             'old_sha256': hashlib.sha256((OLD/x).read_bytes()).hexdigest(),
             'new_sha256': hashlib.sha256((NEW/y).read_bytes()).hexdigest()}
            for x, y in pairs],
    }
    target = WORK / 'evidence/differential_reproduction.json'
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
