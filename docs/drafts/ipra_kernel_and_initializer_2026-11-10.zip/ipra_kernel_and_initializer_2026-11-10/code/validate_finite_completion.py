#!/usr/bin/env python3
"""Finite standard-value validation of the four-schema zero-seed gate compiler.

This is an executable illustration and regression check of the displayed terms.
It is NOT a proof checker for iPRA, a model-theoretic proof, or a proof-assistant
formalization. G's standard numerical meaning and finite J iteration are supplied.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys


def J(n, update):
    assert type(n) is int and n >= 0
    state = 0
    for _ in range(n):
        state = update(state)
    return state


def G(n, other):
    if n == 0:
        return other + 1
    return n // 2 - 1 if n % 2 == 0 else other


def S(n):
    return G(0, n)


def D(n):
    return J(n, lambda u: S(S(u)))


def E(n):
    return S(S(D(n)))


def F(n):
    return G(n, 0)


def predecessor(n):
    return J(n, lambda u: F(D(n)))


def sigma(n):
    return J(n, lambda u: S(0))


def Z(n):
    return G(S(sigma(n)), S(0))


def C(n, a, b):
    return predecessor(G(J(Z(n), lambda u: E(S(a))), b))


def update_term(u, a, update):
    return C(sigma(u), E(a), E(update(F(u))))


def encoded_orbit(n, a, update):
    return J(S(n), lambda u: update_term(u, a, update))


def initialized(n, a, update):
    return F(encoded_orbit(n, a, update))


def H(n):
    return G(S(S(n)), G(S(n), 0))


def N(n):
    return J(n, Z)


def ordinary_iteration(n, a, update):
    """Used only for the separate bounded pairing-formula checks below."""
    for _ in range(n):
        a = update(a)
    return a


def pair(a, b):
    return ordinary_iteration(a, 1 + D(b), D)


def pair_first(z):
    def reset_half(u):
        return C(N(u), C(N(H(u)), D(H(H(u))), 1), u + 2)
    clock = ordinary_iteration(z + 1, D(z), reset_half)
    return max(z - H(clock), 0)


def pair_second(z):
    def half_until_odd(u):
        return C(N(u), H(u), u)
    return H(ordinary_iteration(z, z, half_until_odd))


def main():
    checks = Counter()

    def check(kind, actual, expected):
        assert actual == expected, (kind, actual, expected)
        checks[kind] += 1

    for n in range(25):
        check('double', D(n), 2 * n)
        check('positive_even_code', E(n), 2 * n + 2)
        check('code_decode', F(E(n)), n)
        check('derived_predecessor', predecessor(n), max(n - 1, 0))
        check('half', H(n), n // 2)
        check('half_even', H(D(n)), n)
        check('half_odd', H(1 + D(n)), n)
        check('positive_test', sigma(n), int(n > 0))
        check('zero_test', Z(n), int(n == 0))
        check('parity', N(n), n % 2)
        check('binary_representation', C(N(n), D(H(n)), 1 + D(H(n))), n)
    for n in range(9):
        for a in range(9):
            for b in range(9):
                check('selector', C(n, a, b), b if n else a)

    updates = {
        'identity': lambda u, p: u,
        'successor': lambda u, p: u + 1,
        'constant_zero': lambda u, p: 0,
        'constant_parameter': lambda u, p: p,
        'add_parameter': lambda u, p: u + p,
        'truncated_countdown': lambda u, p: max(u - p, 0),
        'parity_branch': lambda u, p: p if u % 2 else u + 1,
        'zero_pulse': lambda u, p: int(u == 0),
    }
    for name, operation in updates.items():
        for p in range(4):
            # The parameter is fixed throughout each entire orbit.
            update = lambda u, operation=operation, p=p: operation(u, p)
            for a in range(6):
                check('reset_endpoint', update_term(0, a, update), E(a))
                for value in range(9):
                    check('encoded_update_endpoint', update_term(E(value), a, update),
                          E(update(value)))
                standard = a
                for n in range(7):
                    encoded = encoded_orbit(n, a, update)
                    check('encoded_state_invariant', E(F(encoded)), encoded)
                    check('initialized_iterator', F(encoded), standard)
                    check('successor_equation', initialized(n + 1, a, update),
                          update(F(encoded)))
                    standard = update(standard)
    for a in range(4):
        for b in range(4):
            code = pair(a, b)
            check('pair_first_projection', pair_first(code), a)
            check('pair_second_projection', pair_second(code), b)

    path = Path(__file__).resolve()
    result = {
        'status': 'PASS',
        'scope': 'Finite standard-value validation only; not a proof-assistant theorem or complete iPRA checker.',
        'python_version': sys.version.split()[0],
        'source_file': path.name,
        'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'primitive_semantics': {'G': 'b+1 at n=0; b at odd n; n//2-1 at positive even n',
                                'J': 'literal finite iteration from the constant state 0',
                                'S': 'derived as G(0,n), not an independent primitive'},
        'ranges': {'basic_n': [0, 24], 'selector_n_a_b': [0, 8],
                   'iteration_n': [0, 6], 'initial_a': [0, 5],
                   'passive_parameter_p': [0, 3], 'pair_inputs': [0, 3]},
        'pairing_scope': 'Pairing formulas use the separately validated ordinary iteration behavior; no bounded tests establish the universal compiler theorem.',
        'updates': list(updates),
        'checks': dict(sorted(checks.items())),
        'total_checks': sum(checks.values()),
    }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
