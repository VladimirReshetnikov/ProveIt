A SMALLER iPRA KERNEL AND AN EXPLICIT FINITE INITIALIZER REPLACEMENT
Research report, November 10, 2026 (UTC)

Read report.pdf first. Its complete editable source is report.tex plus theory/.

EXACT RESULT AND STATUS

1. Complete checker improvement, under the repository's own Python metric:

                           tokens       AST nodes       normalized bytes
   Published token file       299             345                    880
   Published structure file   304             340                    902
   Published byte file        307             353                    815
   New code/tokens.py         296             342                    874
   New code/structure.py      298             339                    899
   New code/bytes.py          304             350                    809

   Published coordinate envelope: 299 / 340 / 815
   New coordinate envelope:       296 / 339 / 809

   Different files attain the coordinate minima. No single new file beats
   all three old coordinate minima. The whole standalone programs, including
   JSON input and ACCEPT/REJECT output, are measured. The same Python and JSON
   runtime is assumed on both sides. Docstrings are excluded by the unchanged
   published normalization convention. These are empirical source minima,
   not a mathematical lower bound on every possible axiomatization.

   The public protocol and the Choice-DI calculus are unchanged. The new
   implementation defers assumption selection to the common continuation;
   it does not remove a logical axiom. Its equivalence proof and the inherited
   whole-domain iPRA interpretations are included.

2. A separate mathematical construction has the numerical basis 0, G, J,
   where G is binary and J always starts at zero. Successor is the abbreviation
   S(x) = G(0,x). With D(x) = J(x; u.S(S(u))) and E(x) = S(S(D(x))), its four
   computation schemas are:

       J(0;u.h) = 0
       J(S(n);u.h) = h[J(n;u.h)/u]
       G(S(D(a)),b) = b
       G(E(a),b) = a.

   The full ordinary theory additionally has explicitly specified
   intuitionistic first-order equality logic, zero/successor coverage,
   0=1 -> bottom, and contextual literal-equation induction. The report
   recovers arbitrary initialized iteration, primitive recursion, actual
   equality reflection, full quantifier-free induction, and both internal
   interpretation composites. Both domains are the entire numerical domain
   and both definable isomorphisms are the identity graph x=y.

   This is a finite constructor/computation-pattern presentation, not a claim
   of finite ordinary first-order axiomatizability: J updates and induction
   remain schematic. The initializer compiler uses a single equation invariant.

   This new numerical basis has NOT been implemented as a smaller complete
   kernel. The 296/339/809 measurements apply to result 1, not result 2.

3. The request for a significant global axiomatization breakthrough remains
   open. Neither absolute minimality nor literature-wide priority is claimed.
   Earlier drafts already contain the stronger almost-unary obstruction and
   the tagged-reset method. Their contributions are explicitly attributed.

REPRODUCING THE CONCRETE EVIDENCE

   python3 verify.py

This remeasures all six complete sources; checks 147 inherited positives and
21 focused cases on all three new programs in process; runs those cases again
as 1,008 fresh public CLI processes, both ordinary and optimized Python; checks
the pinned snapshot inventory; runs the separate finite arithmetic examples;
and validates MANIFEST.json when present. It writes evidence/reproduction.json.

The original measurements were made with CPython 3.12.14. Other Python releases
can change ast.unparse and therefore normalized bytes or tokens. The verifier
reports the actual runtime. Finite tests supplement the written proofs; they
are not a proof-assistant formalization of soundness or bi-interpretability.

The separate deterministic mutation suite can be replayed with:

   python3 code/differential_review.py

This performs 18,504 old/new comparisons and checks successful final states,
using the original random seed. It writes evidence/differential_reproduction.json.

For a single checker invocation:

   python3 code/tokens.py < examples/identity_iterator_induction.json

Expected output: ACCEPT and exit status 0.

   python3 code/tokens.py < examples/canonical_false.json

Expected output: REJECT and exit status 1.

All three code/{tokens,structure,bytes}.py files are complete standalone
checkers and import only Python's standard json module. They do not import
the validation scripts, source-measurement code, arithmetic experiments,
theorem producers, or any bundled proof oracle.

BUILDING THE DOCUMENT

   python3 build.py

This uses latexmk when available, otherwise three pdflatex passes. A normal
LaTeX installation with the packages declared in report.tex is required.
The distributed PDF was compiled, checked for unresolved references and
layout warnings, and visually inspected after rendering. Build products are
not included apart from the requested final PDF and a concise build receipt.

FILE GUIDE

report.pdf / report.tex       Main research report and master editable source.
theory/                      New finite-basis proof and attributed bridge inputs.
code/{tokens,structure,bytes}.py
                             New complete Choice-DI kernels.
code/INHERITED_FORMAT.txt     Frozen full syntax and JSON certificate interface.
code/validate_finite_completion.py
                             Finite standard-number illustration of 0,G,J terms.
code/differential_review.py   Portable replay of the independent mutation suite.
code/validation/             All inherited and focused certificate packets.
comparison/                  Exact published leaders and measurement helper.
examples/                    Standalone positive and negative input packets.
evidence/                    Snapshot, measurements, review notes, and receipts.
research/                    Attributed earlier coupled-seed and binary-tail notes.
verify.py / build.py          Portable validation and report-build entry points.
ATTRIBUTION.txt               Exact inherited-source mapping and contribution limits.
MANIFEST.json                 SHA-256 package inventory (excludes itself and outputs
                             deliberately regenerated by validation/build scripts).
LICENSE.txt                   Inherited MIT No Attribution license.

SOURCE SNAPSHOT

Repository: VladimirReshetnikov/ProveIt
Commit: aac8216be66b1a6f043fed87a8d515bc5b5d0790
Directory: docs/drafts
Top-level archives: 30

https://github.com/VladimirReshetnikov/ProveIt/tree/aac8216be66b1a6f043fed87a8d515bc5b5d0790/docs/drafts

The downloaded archives were checked against Git blob SHA-1. The original
archive inventory and verification receipt are retained. The 30 full ZIPs are
not duplicated inside this package; the needed mathematical and source inputs
are included with exact provenance.

REVIEW LIMITS

The independent reviews in evidence/ are separate automated research/source
reviews, not external human peer review. No Lean, Rocq, or Isabelle kernel
checked the metatheory. The standard-value arithmetic validator is expressly
not an iPRA proof checker. The full interpretation arguments are written out
for scrutiny. Real Python resource limits can reject sufficiently large valid
proofs; the mathematical completeness claim assumes sufficient finite resources.
