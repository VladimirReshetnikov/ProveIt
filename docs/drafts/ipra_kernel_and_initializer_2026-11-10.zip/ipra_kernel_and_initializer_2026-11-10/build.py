"""Compile the complete report from its included LaTeX sources."""
import shutil
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
if shutil.which("latexmk"):
    subprocess.run(["latexmk", "-pdf", "-interaction=nonstopmode",
                    "-halt-on-error", "report.tex"], cwd=root, check=True)
elif shutil.which("pdflatex"):
    for _ in range(3):
        subprocess.run(["pdflatex", "-interaction=nonstopmode",
                        "-halt-on-error", "report.tex"], cwd=root, check=True)
else:
    raise SystemExit("Install a LaTeX distribution containing pdflatex or latexmk.")
print(root / "report.pdf")

