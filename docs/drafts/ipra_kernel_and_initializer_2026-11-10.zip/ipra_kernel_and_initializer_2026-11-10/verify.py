"""Reproduce the measured kernel comparison and concrete certificate checks.

This is supporting validation code, not part of any measured checker.
The universal soundness and interpretation arguments are written proofs.
"""
import ast
import copy
import hashlib
import importlib.util
import json
import platform
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROFILES = ("tokens", "structure", "bytes")
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def kernel_namespace(path):
    tree = ast.parse(path.read_text())
    require(isinstance(tree.body[-1], ast.Try), "Expected complete CLI driver")
    tree.body.pop()
    namespace = {}
    exec(compile(tree, str(path), "exec"), namespace)
    return namespace


def verdict(namespace, packet):
    data = copy.deepcopy(packet)
    namespace["k"] = 0
    namespace["q"] = data.pop
    try:
        accepted = bool(namespace["c"](data.pop(), []))
    except BaseException:
        accepted = False
    return accepted


def cli_check(job):
    profile, optimized, case = job
    argv = [sys.executable]
    if optimized:
        argv.append("-O")
    argv.append(str(ROOT / "code" / (profile + ".py")))
    result = subprocess.run(
        argv, input=json.dumps(case["packet"]), text=True,
        capture_output=True, timeout=30
    )
    wanted = case["accept"]
    ok = result.stdout == ("ACCEPT\n" if wanted else "REJECT\n")
    ok = ok and result.returncode == (0 if wanted else 1)
    return {
        "profile": profile, "optimized": optimized,
        "case": case["name"], "expected_accept": wanted,
        "passed": ok, "exit_code": result.returncode,
        "stdout": result.stdout,
    }


def main():
    meter = load_module("source_measure", ROOT / "comparison/source_measure.py")
    rows = []
    for group, prefix in (("published", "comparison/choice_"), ("new", "code/")):
        for profile in PROFILES:
            path = ROOT / (prefix + profile + ".py")
            rows.append({"group": group, "profile": profile,
                         "file": str(path.relative_to(ROOT)), **meter.metrics(path)})
    old = {key: min(row[key] for row in rows if row["group"] == "published")
           for key in FIELDS}
    new = {key: min(row[key] for row in rows if row["group"] == "new")
           for key in FIELDS}
    # CPython versions can change ast.unparse. Preserve the measured receipt
    # and report a differing comparison honestly on another runtime.
    improves = {key: new[key] < old[key] for key in FIELDS}
    require(all(improves.values()), "No strict family-envelope improvement on this runtime")

    folder = ROOT / "code/validation"
    inherited = json.loads((folder / "converted_inherited_certificates.json").read_text())["records"]
    focused = json.loads((folder / "focused_certificates.json").read_text())["cases"]
    cases = [{"name": item["name"], "packet": item["packet"], "accept": True}
             for item in inherited] + focused

    in_process = 0
    for profile in PROFILES:
        namespace = kernel_namespace(ROOT / "code" / (profile + ".py"))
        for case in cases:
            require(verdict(namespace, case["packet"]) == case["accept"],
                    "In-process verdict mismatch: " + profile + "/" + case["name"])
            in_process += 1

    jobs = [(profile, optimized, case)
            for profile in PROFILES for optimized in (False, True) for case in cases]
    with ThreadPoolExecutor(max_workers=6) as executor:
        cli = list(executor.map(cli_check, jobs))
    require(all(item["passed"] for item in cli), "Public CLI verdict mismatch")

    snapshot = json.loads((ROOT / "evidence/repository_snapshot.json").read_text())
    require(snapshot["commit"] == "aac8216be66b1a6f043fed87a8d515bc5b5d0790",
            "Unexpected repository snapshot")
    require(len(snapshot["entries"]) == 30, "Unexpected archive inventory")
    require(all(len(item["sha"]) == 40 and item["size"] > 0
                for item in snapshot["entries"]), "Incomplete archive identities")

    arithmetic = subprocess.run(
        [sys.executable, str(ROOT / "code/validate_finite_completion.py")],
        cwd=ROOT, text=True, capture_output=True, timeout=60
    )
    require(arithmetic.returncode == 0,
            "Finite arithmetic validation failed: " + arithmetic.stderr)

    manifest_path = ROOT / "MANIFEST.json"
    manifest_checked = 0
    if manifest_path.exists():
        for item in json.loads(manifest_path.read_text())["files"]:
            path = ROOT / item["path"]
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            require(actual == item["sha256"], "Changed package file: " + item["path"])
            manifest_checked += 1

    receipt = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "programs": rows, "published_envelope": old, "new_envelope": new,
        "strict_improvement": improves,
        "single_program_below_all_old_coordinates": any(
            all(row[key] < old[key] for key in FIELDS)
            for row in rows if row["group"] == "new"),
        "inherited_cases": len(inherited), "focused_cases": len(focused),
        "in_process_checks": in_process,
        "public_cli_checks": len(cli), "failures": 0,
        "arithmetic_stdout": arithmetic.stdout,
        "manifest_files_checked": manifest_checked,
        "limits": [
            "Finite executions do not prove universal soundness or bi-interpretability.",
            "The numerical compiler validation concerns explicit finite examples.",
            "Source-byte measurements assume the common Python and JSON runtime.",
            "Real execution resources can reject sufficiently large valid proofs."
        ]
    }
    (ROOT / "evidence/reproduction.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in (
        "python", "published_envelope", "new_envelope",
        "single_program_below_all_old_coordinates",
        "in_process_checks", "public_cli_checks", "failures"
    )}, indent=2))


if __name__ == "__main__":
    main()

