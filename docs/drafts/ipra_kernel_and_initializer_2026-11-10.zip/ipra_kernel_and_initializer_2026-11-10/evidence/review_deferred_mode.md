# Independent review of deferred local-assumption selection

Reviewed program families: `kernel_experiments/tokens_lambda.py`,
`tokens_except.py`, and `bytes_lambda.py`, against the corresponding
Choice-DI source programs in the pinned repository.

## Claim that is justified

The refactor removes the default `s=1` state and the assignment
`s = len(a) % 2 == m` from paired introduction. It replaces the final
image `k*s` by `k if m or len(a) % 2 == m else 0`.

On every execution reaching the common final continuation, exactly two
cases are possible:

1. **Paired elimination.** Its major `m` is truthy and has already passed
   its recursive proof check. In the old program `s` is the untouched
   default 1. In the new program `m` selects image `k`. Both therefore
   append exactly the same opened closure to the context.
2. **Paired introduction.** Its head `m` is falsy. In the old program the
   local flag is the Boolean result of `len(a) % 2 == m`. In the new
   program the truthy-major disjunct is false and the identical comparison
   selects `k` or 0. Since a Boolean multiplied by integer `k` is exactly
   `k` or 0, the inserted assumption is identical. Decrementing `k`
   between the comparison's old and new positions cannot change that
   comparison, which mentions only the unchanged local values `a` and `m`.

Equation and unary-closure eliminations return before this continuation;
their endpoint variables are still assigned in their own branches.
Computation also returns before the continuation. The membership check,
syntax traversal, fresh-parameter allocation, strict proof-major check,
target comparisons, recursive calls, and public verdict wrapper are
otherwise unchanged in each matched source pair.

Thus finite canonical proof traces and the full Choice-DI consequence
relation are preserved. The proof also covers the documented falsy raw
head aliases. Rejected malformed executions may differ in their final
freshness-floor value if an exception is thrown after the decrement;
that value is not observable through the public CLI. Finite-resource
limitations remain those of the concrete Python process.

## Claim boundaries

This is an implementation simplification of an existing complete
axiomatization. It introduces no new arithmetic theorem or logical rule,
and it is not a proof of an absolute size lower bound. A coordinate
envelope attained by several programs must be reported as an envelope;
it is not the size of a single dominating implementation.

The removed CLI-reporting experiment, bare-exception experiment, and
attribute-based array guard are not used in this justification. Public
ACCEPT/REJECT output and rejection exit status should remain unchanged.
