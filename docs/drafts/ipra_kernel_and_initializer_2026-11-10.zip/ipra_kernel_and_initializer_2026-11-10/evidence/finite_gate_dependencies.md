# Four-schema gate theory: exact proof dependencies

Final numerical grammar: variables, 0, binary G, and J(n; u.h) with fixed zero seed and arbitrary fixed passive update parameters. Sx abbreviates G(0,x), 1=S0, Dn=J(n;u.S²u), En=S²Dn. Four computation schemas: J0=0; J(Sn)=h(Jn); G(SDa,b)=b; G(Ea,b)=a. Ordinary IQC with actual equality, numerical coverage, 0≠1, and contextual literal-equation induction EI complete the ordinary source theory.

This is a finite constructor/computation-pattern presentation, NOT a finite ordinary first-order axiomatization. The fixed descriptions for J and the EI matrices remain schematic.

## Computation only, before EI and before coverage/separation

1. D0=0; D(Sn)=S²Dn=En.
2. Decoder F(x)=G(x,0) has F(Ea)=a. NOTE F(0)=1, not 0.
3. P(n)=J(n;u.F(Dn)) has P0=0 and P(Sn)=n. The update ignores its state u and retains n as a fixed passive parameter in each instance. At a successor its value is F(D(Sn))=F(En)=n.
4. sigma(n)=J(n;u.1) has sigma0=0, sigma(Sn)=1.
5. Z(n)=G(S sigma(n),1) has Z0=1 (odd gate) and Z(Sn)=0 (E0 decoder).
6. C(n,a,b)=P(G(J(Zn;u.E(Sa)),b)) has C0=a, C(Sn)=b. At zero: positive even code E(Sa) decodes to Sa and P removes S. At successor: zero counter gives zero gate control, G0b is Sb by definition, and P removes S.
7. H(n)=G(S²n,G(Sn,0)) has H(Da)=a and H(SDa)=a by the two gate equations.

## EI, with arbitrary passive parameters; no coverage/separation

8. T_{h,a}(u)=C(sigma(u),Ea,E(h(Fu,p))) has T0=Ea and T(Ev)=E h(v,p) by items 2,4,6.
9. V(n)=J(Sn;u.T(u)), I_h(n,a)=F(Vn). One literal EI on E(F(Vn))=Vn proves I_h(0,a)=a and I_h(Sn,a)=h(I_h(n,a),p). The primitive update h and every numerical passive parameter are fixed during this induction.
10. N(n)=J(n;u.Zu) has N0=0, NSn=Z(Nn); one literal EI proves N(Dn)=0, hence N(SDn)=1.
11. Addition I_S and monus I_P yield standard equational identities. Dn=n+n. The displayed pair and projections in finite_gate_completion.tex use only coded half/parity endpoints, predecessor, scalar I, and separate literal-equation inductions. Their explicit slack equation proves enough loop length; no assertion that every number is a pair is used. Packing an environment, counter, and state gives an internal compiler for every finite PR description.

## Add numerical coverage (still no quantifier-free induction assumed)

12. Coverage makes Z Boolean, and hence N Boolean (split its argument as zero or successor).
13. One literal EI on n=C(Nn,D(Hn),S(D(Hn))) gives actual binary representation. In the Nn=0 branch the IH writes n as an even code; in the Nn=1 branch it writes n as an odd code. Item 7 and the N update prove the respective successor cases.
14. Thus each n is D(Hn) or S(D(Hn)). Split Hn by numerical coverage to obtain gate coverage: n=0 or n=SDa or n=Ea for some a. This proves H's ordinary two-step halving equations as well.

## Add separation; recover full QFI

15. Direct P gives successor injectivity; Z and 0≠1 give successor nonzeroness. Coverage + P give n=0 or n=SPn.
16. The positive-residual equation for monus is proved by literal EI, using Boolean cases under coverage. It proves d(Sa,b)=1 iff a=b. Then epsilon(a,b)=sigma(C(d(Sa,b),1,P(d(Sa,b)))) is Boolean and reflects actual equality.
17. Boolean structural compilation of any quantifier-free formula gives A iff b_A=0. EI on the one equation b_A=0 recovers contextual QFI with all intuitionistic propositional connectives. No induction on quantified matrices is used.

## Interpretation composites (avoid a circular successor identification)

18. Source→iPRA interprets G by: b+1 at n=0, b at odd n, n/2−1 at positive even n; J is PR zero-seed iteration. Thus G(0,b)=S_standard b, so source derived S is ordinary successor. All source axioms/rules are target theorems.
19. iPRA→source maps S_standard to original source G(0,x) and each PR description through item 11; items 15–17 validate all target arithmetic.
20. Source composite: FIRST translate the target theorem G_standard(0,b)=S_standard b to obtain G'(0,b)=S_original b. This identifies the derived successor before assuming G'=G.
21. The special J for S² then has the same base and update on both sides, so EI gives D'=D and E'=E.
22. Translated gate equations plus gate coverage give G'=G on every source element: zero branch by item20, odd/even by item21 and the schemas.
23. External induction on every fixed staged J update, with inner operations already identified, and internal EI on the iterators' equality gives the remaining source composites.
24. Target composite: the successor case is the standard identity G(0,x)=Sx; external induction on PR descriptions and internal equality induction prove all other operations. Both interpretations retain the whole numerical domain and actual equality, so the definable isomorphism graph is x=y.

## Novelty and status

The inherited coupled-seed almost-unary theorem is not new. The earlier binary-tail note already has an odd-marker/even-state strategy with all unary PR primitives imported. The claimed new relative-to-corpus part is the finite gate completion, folding successor into the gate, the four computation patterns, and explicit internal bootstrap/composites. No global priority or below-frontier checker claim follows from the mathematical theorem alone.

Files: finite_gate_completion.tex; validate_finite_gate.py; finite_gate_validation.json (6,988 finite standard-value checks, not a proof-assistant formalization).
