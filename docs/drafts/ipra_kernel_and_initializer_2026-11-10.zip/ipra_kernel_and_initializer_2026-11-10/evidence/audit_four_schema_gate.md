# Independent final audit: successor folded into the binary gate

Final manuscript reviewed:
`research_notes/finite_gate_completion.tex`, SHA-256
`8b763365c0c457327b3c2dec61b82e7dac5cf442da74e4a9488ff8f500ee9945`.
Dependency ledger reviewed:
`research_notes/finite_gate_dependencies.md`, SHA-256
`935e3429a13f1146c132784e325a4b71b1ed462d959d46ff427199e624619053`.

## Decision

**Accepted as a correct finite numerical presentation of iPRA**, when
combined with the explicitly stated ordinary intuitionistic equality
logic, numerical coverage, separation, and contextual literal-equation
induction. The proof below finds no hidden circularity in the compiler,
the direct predecessor and half, or the identity-domain composites.

The numerical language has only 0, one binary primitive G, and staged
fixed-zero iteration J. There are four numerical computation schemas.
The logical rules, coverage, separation, and induction are additional
parts of the full theory and must not be omitted from its complexity bill.
This new theory has not been assigned the size of the separate refined
Choice-DI checker; those are different presentations.

## Language and four schemas

Define the macros

    S(x)=G(0,x),       1=S(0),
    D(n)=J(n;u.S(S(u))),
    E(n)=S(S(D(n))).

The four numerical schemas are

    J(0;u.h)=0,
    J(Sn;u.h)=h(J(n;u.h)),
    G(S(Da),b)=b,
    G(Ea,b)=a.

Every h is a fixed finite earlier-stage term, with u bound and arbitrary
fixed passive parameters. Variables do not range over descriptions.
The source equation induction and coverage use the displayed defined
successor S, not an additional uncharged primitive operation.

The intended standard G is primitive recursive:

    G(0,b)=b+1;
    G(2a+1,b)=b;
    G(2a+2,b)=a.

It witnesses soundness in iPRA. All source derivations below instead use
the four displayed equations and the definition S(x)=G(0,x).

## Direct predecessor: the passive-parameter point

Computation gives D0=0 and D(Sn)=SS(Dn)=E(n). Define

    P(n)=J(n;u.G(D(n),0)).

The update here is constant in u and captures n as a passive parameter.
More formally it is J_h(n,n), for h(u,p)=G(Dp,0). This is permitted by
the declared language. Then

    P0=0,
    P(Sn)=G(D(Sn),0)=G(E(n),0)=n.

These are direct computations. No active induction parameter is changed,
and no counter-dependent recursion is silently added to the update.

In particular, successor injectivity follows by applying P. Successor
cannot be zero: Sx=0 implies x=P0=0, then S0=0, contradicting the stated
separation sentence. These constructor properties need no induction.

## Selector and initialized iteration

Put

    sigma(n)=J(n;u.1),
    Z(n)=G(S(sigma(n)),1),
    F(v)=G(v,0).

Direct computations give sigma0=0, sigma(Sn)=1, Z0=1, Z(Sn)=0,
and F(Ea)=a. The Z endpoints use 1=S(D0) and 2=E0.

The corrected selector is

    C(n,a,b)=P(G(J(Z(n);u.E(Sa)),b)).

At zero, Z0=1, so the iterator returns E(Sa), the outer G returns
Sa, and P returns a. At a successor, Z(Sn)=0, so the iterator returns
0, the outer G returns Sb by the *definition* of S, and P returns b.
Therefore C0ab=a and C(Sn)ab=b internally.

For any finite update h(u,p), define

    T(u,a,p)=C(sigma(u),E(a),E(h(F(u),p))),
    V(n,a,p)=J(Sn;u.T(u,a,p)),
    I*(n,a,p)=F(V(n,a,p)).

Then T0=Ea, while T(Ev)=E(h(v,p)), because E(v)=SS(Dv) is
syntactically a successor and F(Ev)=v. Consequently V0=Ea and
V(Sn)=T(Vn). Literal-equation induction on

    E(F(V(n,a,p)))=V(n,a,p)

gives I*(0,a,p)=a and I*(Sn,a,p)=h(I*(n,a,p),p), exactly as in
the preceding tagged-state proof. Passive a,p remain fixed.

**Important transcription change:** F(0)=G(0,0)=1, not 0. No part of
this proof requires F0=0: at state zero T chooses its first branch Ea,
so its other branch containing F0 is irrelevant.

## Direct half and three-form coverage

The term

    H(n)=G(SSn,G(Sn,0))

has H(Da)=a: the outer first argument is E(a). It also has
H(S(Da))=a: the outer first argument is S(D(Sa)), so the outer
G returns its second argument, which is G(Ea,0)=a.

Set N(n)=J(n;u.Z(u)). N0=0 and N(Sn)=Z(Nn). Coverage first proves
the range of Z is {0,1}, and then proves the same range for N by
splitting its counter into zero or successor. No disjunctive induction
is involved.

The single equation invariant

    n=C(Nn,D(Hn),S(D(Hn)))

is established by literal-equation induction. At a state with Nn=0,
the induction equation says n=D(Hn); then Sn is odd, H(Sn)=Hn,
and N(Sn)=1. At a state with Nn=1, it says n=S(D(Hn)); then
Sn=D(S(Hn)), H(Sn)=S(Hn), and N(Sn)=0. In both cases the next
equation follows from the corresponding selector endpoint.

Thus every element is D(Hn) or S(D(Hn)). Applying coverage to Hn
in the even branch splits the entire domain into

    0,  S(Da),  E(a).

These are exactly the three branches needed to identify the primitive
G everywhere, including at nonstandard elements. The same two binary
cases also prove H(SSn)=S(Hn).

## Remaining arithmetic completion

Direct P and the initialized iterator define addition and truncated
subtraction as scalar terms. The attributed equality-reflection argument
uses only these terms, the selector, coverage, separation, and equation
induction. Its residual reconstruction invariant is a single equation,
so it does not assume quantifier-free induction to establish a faithful
equality characteristic.

Once the characteristic is faithful, the usual finite characteristic
compiler yields quantifier-free induction for the entire rich source
language, including G and arbitrary staged J terms. It treats arbitrary
numerical terms as arguments of the equality characteristic and uses
the original equation induction for the compiled equation. G need not
have been eliminated first. Pairing and the full fixed-description PR
compiler can then be supplied in the standard established order.

## Identity-domain composites: safe dependency order

Interpret source G by the stated standard PR gate and source J by
fixed-zero primitive recursion in iPRA. Then the defined source S
maps to standard successor because G_std(0,b)=S_std(b). The source
coverage, separation, and equation induction are therefore sound.

In the reverse interpretation use the source S, initialized I*, and
the full arithmetic compiler. The source composite is identified in
this order:

1. Translate the iPRA theorem G_std(0,b)=S_std(b). It proves that the
   double-interpreted G at zero equals the original defined source S.
   This does not assume that G already agrees away from zero.
2. The double interpretation of the special doubling update satisfies
   d0=0 and d(Sn)=SS(dn), because its G-at-zero occurrences have just
   been identified with S. Equation induction identifies it with D.
3. Translated target gate equations and the preceding D identity show
   that G and its double interpretation agree at 0, S(Da), and E(a).
   Source three-form coverage now proves agreement at every input pair.
4. Externally induct over all finite staged J descriptions. The full
   G identification and earlier-stage identities identify their updates;
   equation induction then proves fixed-initializer iterator uniqueness.

This avoids the apparent cycle of using full G uniqueness to identify
S, while using S to identify D, and D to identify G. The zero branch
is identified first using the separately translated target theorem.

The opposite composite uses standard primitive-recursion uniqueness.
Both domains and actual equality are unchanged; x=y is the internally
provable isomorphism graph. Ordinary formula composites follow by
external induction on syntax, and the explicit separation sentence
preserves ordinary falsity. Hence the full theories are bi-interpretable
and equiconsistent.

## Final manuscript pairing and completion review

I also checked the full final manuscript rather than only the
short construction. Its explicit pairing construction is internally
valid using separate literal-equation inductions.

For c(x,y)=I_D(x,S(Dy)), the stripping update h has h(Dv)=v and
h(S(Dy))=S(Dy). Rotation therefore gives
I_h(x,c(x,y))=S(Dy), and the odd state remains fixed thereafter.

The manuscript's renamed update R has

    R(D(Dv))=Dv,
    R(D(S(Dv)))=1,
    R(S(Dv))=SS(S(Dv)).

These follow directly from the already proved coded half/parity endpoints.
They justify I_R(Sx,D(c(x,y)))=1 and I_R(k,1)=S(Dk), without a
global assertion about the parity of arbitrary intermediate terms.

The bound is correctly expressed as the single equation

    c(x,y)=Sx+d(c(x,y),Sx).

For its successor step, the induction equation writes z=Sx+r;
doubling gives D(z)=S(Sx)+(x+D(r)), so monus cancellation provides
the next slack. With k=S(d(z,Sx)), this indeed yields z=x+k and
Sz=Sx+k. Iteration addition proves the two stated projection identities.
There is no induction on an order relation or a quantified bound.

The environment/counter/value compiler uses these actual projection
equations. Environment and counter preservation are separate literal
equation inductions; the recursion value equation then follows. It does
not require every number to be a pair code.

The residual equality-reflection proof and Boolean compiler also have
the stated dependency order. In particular, positive residual
reconstruction is one equation invariant using finite coverage cases;
no quantifier-free induction is invoked to establish the characteristic
that subsequently supplies it.

The final successor-composite paragraphs explicitly follow the safe
order in the preceding section, including the special doubling iterator
before general G equality. The F(0)=1 warning is present, and the
pairing update is called R rather than colliding with decoder F.

Final review decision: **accept the written mathematical theorem**.
This is independent assistant review, not external peer review or a
Lean/Rocq verification of the full proof.

## Novelty and benchmark boundary

The older binary-tail note already contains a first-reset/even-tagged-
state compiler with all unary PR primitives. The present four-schema
finite completion, its direct predecessor, and the folding of successor
into the gate are narrower new claims relative to the inspected corpus.
No literature-wide priority or universal minimality is established here.

This is an unmeasured mathematical basis. Its complete proof-checker cost
must include syntax, the four schemas, ordinary intuitionistic logic,
scope, coverage, separation, and equation induction. The separate smaller
Choice-DI source profiles cannot be presented as implementing this theory.
