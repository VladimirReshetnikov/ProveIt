# Independent current-frontier audit

Source snapshot: `VladimirReshetnikov/ProveIt`, commit
`aac8216be66b1a6f043fed87a8d515bc5b5d0790`, 30 top-level ZIP archives
under `docs/drafts`, downloaded and Git-blob checked by the parent process.

## Measured current target

A fresh recursive scan of the extracted archives found 809 Python source
occurrences and 302 distinct byte-identical sources. The scan parsed Python
with CPython 3.12.14, removed genuine module/function/class docstrings,
applied `ast.unparse`, then counted significant tokens, every AST node,
and normalized UTF-8 bytes. It did not execute those source files.
The complete result is `audit_all_python_metrics.json`.

The current leading complete kernels are the three programs in
`ipra_choice_2026-11-09/ipra_choice_2026-11-09/code/native/`:

| Program | Normalized tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| `tokens.py` | 299 | 345 | 880 |
| `structure.py` | 304 | 340 | 902 |
| `bytes.py` | 307 | 353 | 815 |

The current coordinate envelope is therefore **299 / 340 / 815**. These
minima are attained by different programs. A single source strictly below
all three would need at most **298 / 339 / 814**. This is an empirical
finite-source envelope, not a mathematical universal lower bound. The
Python runtime, JSON parser, arithmetic/list primitives, and exception
semantics are common ambient dependencies and are not counted in these
source-only metrics. Byte counts depend on identifier spelling.

No smaller complete candidate was hidden among sources below 299 tokens
in this scan: those files are build, packaging, measurement, or finite
diagnostic tools. This classification is by source inspection and archive
role, not by a mechanized complete-checker recognition procedure.

Independent fresh public-CLI replay of the inherited 21 focused packets
through all three leaders, both ordinary Python and `python -O`, completed
126 runs with zero failures. These include real induction-hypothesis use,
retained false base, captured-counter rejection, failed-major rejection,
false arithmetic, free-parameter rejection, and choice-marker aliases.
Exact checker hashes and stdout/stderr/exit results are recorded in
`audit_choice_replay.json`. No new universal theorem is inferred from
these finite regressions.

## What changed in the leading mathematical basis

Choice-DI permits one local assumption at introduction: the zero case
for an arbitrary formula, or the predecessor case for a literal equation.
The older calculus retained both at atomic introduction. Its reverse
simulation is explicit and credible: outer case introduction retains
the base; an inner progress introduction binds a deliberately unused
existential variable while keeping the original witness as a passive
parameter; paired elimination then provides the needed closure at that
same original witness. This gives identity-language equivalence in
arbitrary contexts with the stated N+5r derivation-node bound.

The later closure-induction and gated-induction archives do not improve
the complete-checker envelope. Gated induction removes a choice annotation
but adds a grammar restriction, with no smaller complete implementation.
Most arithmetic/rewrite archives establish only matched local reductions
or obstructions and explicitly disclaim the global target.

## Raw checker boundary reviewed

I read all three complete Choice-DI programs, their FORMAT.txt, the
native rule-equivalence proof, ordinary bridge, and the detailed sorted
decoder/correctness section. I found no immediate soundness counterexample.
This is an independent written review, not a Lean/Rocq proof or a proof
that all inherited arithmetic arguments are correct.

Material boundary conditions are explicitly addressed in the sources:

* Formula/numerical decoding alternates by sort, with arity increments
  2, 1, 4. The iterator update receives repeated copies of the state,
  not an uncharged recursion-counter argument.
* The initial traversal excludes meaningful free parameters. Fresh
  negative eigenlabels are allocated after the retained conclusion has
  been checked. Parameters used only in a major subproof do not carry
  its local assumptions into the continuation.
* Finite fractional coordinates alias floors; Booleans alias 0/1.
  Formula scalar aliases denote truth. Used malformed numerical images
  reject. Arrays above arity three reject when traversed.
* All three current leaders guard actual array traversal. None depends
  on infinite character-by-character recursion to reject strings.
* A truthy major must succeed: `1/c(m,g)` prevents a false-returning
  major from falling through into introduction. This is essential for
  keeping compound induction forbidden.
* Introduction witnesses must have a truthy representation. A canonical
  zero witness is boxed as the explicit term I(0,0;u.0). The completeness
  proof includes that boxing and equality transport.
* An unread prefix of the packet is intentionally inert. The whole
  claimed theorem is the final packet cell; proof cells are consumed
  from the end.
* Completeness is under sufficient finite resources. Fixed Python
  recursion/memory limits can reject long valid derivations.
* The ordinary realization explicitly includes the falsity bridge
  `(0=S0) -> bottom`; a positive equational singleton model is not
  silently treated as a model of that realization.

## Rejected independent shortcut

Replacing the increment table by `len(a)+1` looks shorter, but changes the
equation increment from 1 to 3. This creates an extra protected dummy slot
inside numerical equation terms. The existing successor-computation
substitution opens all exposed update slots as state, so it would replace
that extra dummy slot by the previous state. A source-equivalence or
soundness claim would fail without additional changes/guards. This is
not a valid free optimization.

Bottom-up proof synthesis is already discussed in the corpus. It must
prevent the existential witness escaping through the synthesized DE
conclusion. The existing top-down checker enforces that by validating
the conclusion before freshness allocation. Earlier scoped synthesis
prototypes were larger; this does not prove synthesis can never help.

## Honest acceptance threshold

An actual new candidate must have a sound complete checker, both internal
interpretation composites, and charged syntax/scope/input handling.
Replacing a rule by a theorem in a much larger ordinary checker is not
below the current native envelope. Neither finite tests nor standard-
numeral agreement establish the full metatheorem. A reduction only in
token/AST/byte implementation count should be described as such and
distinguished from a significant mathematical axiom reduction.
