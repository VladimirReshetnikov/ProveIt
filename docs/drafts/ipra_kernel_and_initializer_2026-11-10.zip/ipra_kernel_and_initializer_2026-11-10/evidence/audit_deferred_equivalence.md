# Independent proof of deferred-selector correctness

## Scope

This note concerns the following frozen sources at the time of review:

* `kernel_experiments/tokens_lambda.py`, SHA-256
  `9e4613074efd848022d82a92512f393fc53e19bfdeebcd13fef388e35df5a5a5`;
* `kernel_experiments/tokens_except.py`, SHA-256
  `2d03af76b3c60b4b0979697c07a96bb9658a9d5dfe0a0d3d345b64ca768e8500`;
* `kernel_experiments/bytes_lambda.py`, SHA-256
  `11cd3fbadf19dfb988cfe55f71eafa6154e468b1e6ed6ee1973c39e86cfc7114`.

The comparison is against the complete Choice-DI sources in the pinned
30-archive snapshot. The token and exception variants are compared with
old `tokens.py`; the byte variant is compared with old `bytes.py`.

The claim is equality of public ACCEPT/REJECT verdicts under sufficient
execution resources on every finite input, and equality of successful
checking states. It is not equality of failed intermediate states, nor
an assertion that fixed implementation resource cutoffs are identical.
The public JSON protocol, closed goal, proof instructions, output strings,
exit codes, and mathematical calculus are unchanged.

## The changed expression

Previously `c(a,g,s=1)` supplied a default selector value for the shared
eigenparameter tail. DI assigned

    s = len(a) % 2 == m

and DE retained the default. After decrementing the floor `k`, the shared
tail added `i(h,k*s)` to its context. The new version removes that default
argument and DI assignment and adds instead

    i(h, k if m or len(a) % 2 == m else 0).

The arithmetic equality/Q dispatch still assigns its own local `s` before
using it. Those branches return before the shared tail.

## Exhaustive successful-tail analysis

There are only two ways to reach the shared tail.

1. **Paired elimination.** The head `m` is truthy and its recursive major
   proof has succeeded. The dispatch has established a paired major.
   The old selector retains its default `s=1`, so `k*s=k`. In the new
   expression `m or ...` short circuits on the truthy head and chooses
   exactly `k`. No matrix length is evaluated on this path.

2. **Paired introduction.** The head `m` is falsy and the witness payload
   is truthy. Both versions set the same matrix `h=a=i(a[2],t,2)`.
   In the old version `s` is the Boolean `(len(a)%2==m)`. Multiplication
   of integer `k` by that Boolean is `k` when true and `0` when false.
   In the new version falsity of `m` reaches exactly that same comparison,
   and the conditional expression chooses the same integer image.

All standard JSON falsy classes are covered by this identity: numeric
zero, negative floating zero, Boolean false, null, empty string, empty
array, and empty object. Equality to integer zero selects the old Ind
choice where applicable; the other falsy heads select the old Case
choice. No falsy JSON head equals integer one, so compound matrices
still cannot acquire the induction assumption. The strict successful-
major requirement remains in place and prevents a truthy malformed
head from reaching DI.

The first recursive argument `i(a,[k])` is evaluated before the new
conditional. The opening function does not mutate `a`, `m`, the proof
stack, or the global floor. Consequently delaying the arity comparison
past that call cannot change a successful comparison. The freshness
floor has already been decremented, but neither truthiness of `m` nor
`len(a)%2==m` depends on it.

## Other paths

Hypothesis closure, primitive computations, equality transport, and unary
closure elimination are unchanged. In the token dispatch, the Q path
sets `s=0` before singleton unpacking; the Eq path assigns `s,u=m`.
In the byte dispatch the successful tuple assignment defines `s` on
both Q and Eq paths. A paired major fails unpacking before assigning
any targets, but the new tail does not use the old `s` variable there.

Malformed major shapes reject during root traversal or dispatch. A
malformed DI scalar matrix can make the old program raise at `len(a)`
before decrementing `k`, while the new program decrements `k` and then
raises. Both reject, and no checking continuation catches that exception
and resumes with the modified floor. Therefore public verdict equivalence
holds even though failed intermediate state equality is false in this
case. The report should not claim the stronger failed-state property.

## Exception-guard variant

The exception variant replaces the strict-list lambda opening with

    try:
        return [i(b,t,d+table[len(a)]) for b in a+[]]
    except:
        return a if k<=a<d else d%2 and i(t,d=1)

On parsed JSON, `a+[]` succeeds exactly for lists. A successful traversal
of a list produces the same list as the old guard. If a descendant
throws, the fallback comparison of the enclosing list with the integer
floor also throws, so no malformed descendant is converted into a valid
scalar. For every non-list JSON value, the concatenation throws and the
fallback is exactly the old scalar clause. This is the already documented
guarded traversal transformation; it introduces no iterable string alias
and is structurally terminating under the same idealized assumptions.

## Whole-program conclusion

Induct on the remaining finite proof-instruction stack, and structurally
on opening calls. Each successful recursive call returns the same value
and preserves the same remaining stack and floor in the two versions.
The branch analysis gives identical next subgoals and contexts. Every
failure leads to the same public rejection; delayed failures cannot be
recovered into successful proof checking. The unchanged parser and outer
driver therefore return the same public verdict.

The new sources consequently inherit soundness, canonical completeness,
and the full iPRA interpretation proof of the old native calculus. This
is a modest complete-program implementation simplification. It neither
removes a mathematical rule nor supplies a new axiomatization theorem.

## Independent finite evidence

The reusable script `audit_deferred_kernels.py` records:

* 147 inherited positives and 21 focused positive/negative cases;
* 504 in-process old/new/expected comparisons;
* 1,292 malformed-head mutation packets per source pair, hence 3,876
  differential comparisons;
* 1,008 fresh public CLI runs across the three candidates in ordinary
  and optimized Python;
* zero failures in every category.

Exact hashes, outputs, expected verdicts, and counts are in
`audit_deferred_kernel_results.json`. Finite executions supplement the
universal source argument and do not replace it.

The candidate profiles are 296/342/874, 298/339/899, and 304/350/809.
Their coordinate envelope 296/339/809 is strictly below the prior
299/340/815 envelope. Different candidates attain the minima; no single
candidate dominates all three prior minima simultaneously.
