"""Reproduce the whole-program comparison and executable evidence offline."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
checker = ROOT / "checker.py"
steps = [
    ["reproducible/compare.py", str(checker)],
    ["reproducible/reencode.py", "--corpus"],
    ["reproducible/validate_corpus.py", str(checker), "--cli"],
    ["validation/kernel_audit.py", "--checker", str(checker),
     "--corpus", "reproducible/corpus/target",
     "--output", "validation/kernel_audit_results.json"],
]
logs = []
for arguments in steps:
    result = subprocess.run(
        [sys.executable, *arguments], cwd=ROOT,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    logs.append({"command": [sys.executable, *arguments],
                 "exit_code": result.returncode, "output": result.stdout})
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
data = json.loads((ROOT / "reproducible/results/comparison.json").read_text())
candidate = data["candidates"][0]
if not all(candidate["strict_below_all_variant_frontier"].values()):
    raise SystemExit("Candidate no longer strictly dominates the current frontier")
names = {
    "ipra_arity_2026-11-06": "Arity",
    "ipra_direct_stream_2026-11-06": "Direct stream",
    "ipra_fixed_slot_2026-11-06": "Fixed slot",
    "ipra_fixed_variable_2026-11-06": "Fixed variable",
    "ipra_fresh_parameters_2026-11-06": "Fresh parameters",
    "ipra_variable_specialization_2026-11-06": "Variable specialization",
}
lines = [r"\begin{center}\small",
         r"\begin{tabular}{@{}llrrr@{}}", r"\toprule",
         r"Current archive & Policy & Tokens & AST & Bytes\\", r"\midrule"]
for row in data["baselines"]:
    name = next((label for stem, label in names.items()
                 if stem in row["local_file"]), row["label"])
    lines.append(f"{name} & {row['witness_policy']} & "
                 f"{row['normalized_tokens']} & {row['ast_nodes']} & "
                 f"{row['normalized_bytes']:,}" + r"\\")
lines.extend([r"\midrule",
              f"Integrated & strict & {candidate['normalized_tokens']} & "
              f"{candidate['ast_nodes']} & {candidate['normalized_bytes']:,}" + r"\\",
              r"\bottomrule", r"\end{tabular}", r"\end{center}"])
(ROOT / "results/comparison_table.tex").write_text("\n".join(lines) + "\n")
summary = {
    "python_version": data["python_version"],
    "commit": data["commit"],
    "all_variant_frontier": data["all_variant_frontier"],
    "candidate": candidate,
    "steps": logs,
}
(ROOT / "results/reproduction.json").write_text(json.dumps(summary, indent=2) + "\n")
print("PASS: comparison, source/target corpus, public CLI, and independent audit")
print("Candidate normalized tokens / AST nodes / bytes:",
      candidate["normalized_tokens"], candidate["ast_nodes"], candidate["normalized_bytes"])
