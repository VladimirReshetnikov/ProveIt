"""Replay the exact source corpus and the re-encoded candidate certificates.

Usage: python3 validate_corpus.py /absolute/path/to/checker.py
       python3 validate_corpus.py /absolute/path/to/checker.py --cli

This finite regression test checks byte-for-byte compilation, all 89 source
derivations, all 89 target derivations, and empty residual proof streams.
--cli additionally invokes the public candidate process, normally and with -O.
It is evidence for an implementation, not a proof of general metatheorems.
"""

import argparse
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

import reencode


ROOT = Path(__file__).resolve().parent


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("--cli", action="store_true")
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "corpus.json")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "corpus_manifest.json").read_text())
    comparison = json.loads((ROOT / "comparison_manifest.json").read_text())
    source_record = next(item for item in comparison["programs"]
                         if item["archive_stem"] == "ipra_fixed_slot_2026-11-06"
                         and item["filename"] == "checker.py")
    source_path = ROOT / source_record["local_file"]
    if digest(source_path) != source_record["sha256"]:
        raise ValueError("The frozen source checker has changed")
    source_checker = module(source_path, "frozen_fixed_slot_checker")
    candidate = module(args.candidate.resolve(), "candidate_checker")
    rows = []
    for item in manifest["examples"]:
        source_path = ROOT / item["source_file"]
        target_path = ROOT / item["target_file"]
        if digest(source_path) != item["source_sha256"]:
            raise ValueError("Source certificate hash mismatch")
        if digest(target_path) != item["target_sha256"]:
            raise ValueError("Target certificate hash mismatch")
        source_document = json.loads(source_path.read_bytes())
        target_document = json.loads(target_path.read_bytes())
        recompilation = reencode.encoded_bytes(reencode.compile_document(source_document))
        source_goal, source_stream = deepcopy(source_document)
        source_ok = source_checker.check(source_goal, source_stream, [])
        target_stream = deepcopy(target_document)
        candidate.take = target_stream.pop
        target_ok = candidate.check(candidate.take(), [])
        row = {
            "id": item["id"],
            "source_file": item["source_file"],
            "target_file": item["target_file"],
            "source_accepted": source_ok is True,
            "source_unread_items": len(source_stream),
            "target_accepted": target_ok is True,
            "target_unread_items": len(target_stream),
            "byte_exact_recompilation": recompilation == target_path.read_bytes(),
        }
        if args.cli:
            row["cli"] = []
            for optimized in (False, True):
                command = [sys.executable]
                if optimized:
                    command.append("-O")
                command += [str(args.candidate.resolve()), str(target_path.resolve())]
                completed = subprocess.run(command, capture_output=True, text=True)
                row["cli"].append({
                    "optimized": optimized,
                    "exit_code": completed.returncode,
                    "stdout": completed.stdout,
                    "stderr": completed.stderr,
                    "passed": completed.returncode == 0
                              and completed.stdout == "ACCEPT\n"
                              and not completed.stderr,
                })
        row["passed"] = (
            row["source_accepted"] and row["target_accepted"]
            and row["source_unread_items"] == 0
            and row["target_unread_items"] == 0
            and row["byte_exact_recompilation"]
            and all(run["passed"] for run in row.get("cli", []))
        )
        rows.append(row)
    result = {
        "candidate": str(args.candidate.resolve()),
        "candidate_sha256": digest(args.candidate),
        "commit": manifest["commit"],
        "source_checker_sha256": source_record["sha256"],
        "example_count": len(rows),
        "passed_count": sum(row["passed"] for row in rows),
        "cli_invocations": sum(len(row.get("cli", [])) for row in rows),
        "failures": [row["id"] for row in rows if not row["passed"]],
        "rows": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "rows"}, indent=2))
    if len(rows) != 89 or result["failures"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
