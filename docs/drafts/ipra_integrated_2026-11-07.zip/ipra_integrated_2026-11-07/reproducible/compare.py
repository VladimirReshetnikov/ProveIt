"""Measure a frozen nine-checker corpus and optional candidate application files.

Usage: python3 compare.py /absolute/path/to/checker.py [more_candidates.py]
Only the Python standard library is required. No measured checker imports this
measurement utility. The checked source boundary is the entire application file;
its shared Python interpreter and standard-library implementation are external.
"""

import argparse
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


ROOT = Path(__file__).resolve().parent
NORMALIZED = ("normalized_tokens", "ast_nodes", "normalized_bytes")
FIELDS = ("source_tokens", *NORMALIZED, "raw_bytes")
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def tokens(source):
    return sum(token.type not in IGNORED for token in
               tokenize.generate_tokens(io.StringIO(source).readline))


def normalized_metrics(tree):
    source = ast.unparse(tree) + "\n"
    return {
        "normalized_tokens": tokens(source),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(source.encode("utf-8")),
    }


def metrics(path):
    raw = Path(path).read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    docstrings = set()
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.FunctionDef,
                              ast.AsyncFunctionDef, ast.ClassDef))
                and node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            value = node.body[0].value
            docstrings.add(((value.lineno, value.col_offset),
                            (value.end_lineno, value.end_col_offset)))
    source_tokens = sum(
        token.type not in IGNORED and (token.start, token.end) not in docstrings
        for token in tokenize.generate_tokens(io.StringIO(source).readline)
    )
    tree = ast.fix_missing_locations(RemoveDocstrings().visit(tree))
    result = {
        "source_tokens": source_tokens,
        **normalized_metrics(tree),
        "raw_bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }
    tree.body = [
        node for node in tree.body
        if not isinstance(node, (ast.Import, ast.ImportFrom))
        and not (isinstance(node, ast.If)
                 and "__name__" in ast.unparse(node.test))
    ]
    result["core"] = normalized_metrics(tree)
    return result


def minima(rows, *, core=False):
    keys = NORMALIZED if core else FIELDS
    return {
        key: min((row["core"] if core else row)[key] for row in rows)
        for key in keys
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidates", nargs="*", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "comparison_manifest.json").read_text())
    rows = []
    for item in manifest["programs"]:
        measured = metrics(ROOT / item["local_file"])
        if measured["sha256"] != item["sha256"]:
            raise ValueError("Frozen baseline changed: " + item["local_file"])
        rows.append({**item, **measured, "kind": "baseline"})
    if len(rows) != 9 or len(manifest["archives"]) != 6:
        raise ValueError("Expected six current archives and nine root checkers")
    strict_rows = [row for row in rows if row["witness_policy"] == "strict"]
    frontier = minima(rows)
    strict_frontier = minima(strict_rows)
    candidates = []
    for path in args.candidates:
        measured = metrics(path)
        candidates.append({
            "label": str(path), "local_file": str(path.resolve()),
            "kind": "candidate", **measured,
            "strict_below_all_variant_frontier": {
                key: measured[key] < frontier[key] for key in NORMALIZED
            },
            "strict_below_strict_frontier": {
                key: measured[key] < strict_frontier[key] for key in NORMALIZED
            },
        })
    result = {
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "archive_count": len(manifest["archives"]),
        "baseline_program_count": len(rows),
        "boundary": "Entire Python application source, including imports and CLI",
        "normalization": "Remove genuine docstrings; ast.unparse(tree) plus newline",
        "all_variant_frontier": frontier,
        "strict_frontier": strict_frontier,
        "core_frontier_diagnostic_only": minima(rows, core=True),
        "all_variant_attainers": {
            key: [row["label"] for row in rows if row[key] == frontier[key]]
            for key in FIELDS
        },
        "baselines": rows,
        "candidates": candidates,
        "limits": [
            "The finite-corpus frontier is not an absolute lower-bound theorem.",
            "Normalized source sizes can depend on the Python version.",
            "The common Python interpreter and standard libraries are not measured.",
            "Core-only figures remove stream initialization from some kernels and are diagnostic.",
            "Nested historical checker copies are excluded from the current corpus.",
        ],
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "comparison.json").write_text(
        json.dumps(result, indent=2) + "\n")
    fields = ("kind", "label", "witness_policy", "input_layout", *FIELDS,
              "core_normalized_tokens", "core_ast_nodes", "core_normalized_bytes",
              "sha256", "local_file")
    with (args.output / "comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fields, extrasaction="ignore")
        writer.writeheader()
        for row in [*rows, *candidates]:
            writer.writerow({**row, **{"core_" + key: value
                                      for key, value in row["core"].items()}})
    print(json.dumps({
        "baseline_program_count": len(rows),
        "all_variant_frontier": frontier,
        "strict_frontier": strict_frontier,
        "candidates": candidates,
    }, indent=2))


if __name__ == "__main__":
    main()
