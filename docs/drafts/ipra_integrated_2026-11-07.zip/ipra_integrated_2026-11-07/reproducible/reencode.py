"""Untrusted compiler: tagged fixed-slot certificates to arity input streams.

Usage: python3 reencode.py source.json target.json
       python3 reencode.py --corpus

The source is the canonical closed [goal, proof_stack] format used by the
fixed-slot draft. The target is a list of re-encoded instructions followed
by the re-encoded goal. Primitive proof rules and de Bruijn indices are
unchanged. The compiler is not imported by any acceptance kernel.
"""

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def term(value):
    if type(value) is int:
        return value
    if type(value) is list:
        if len(value) == 2 and value[0] == "s":
            return [term(value[1])]
        if len(value) == 4 and value[0] == "r":
            return [term(argument) for argument in value[1:]]
    raise ValueError("Not a tagged numerical term")


def formula(value):
    if type(value) is list:
        if len(value) == 3 and value[0] == "=":
            return [term(value[1]), term(value[2])]
        if len(value) == 2 and value[0] in ("q", "u"):
            return [formula(value[1])]
        if len(value) == 2 and value[0] == "ex":
            return [formula(value[1]), [0, 0], [0, 0]]
    raise ValueError("Not a tagged formula")


def instruction(value):
    if value is None:
        return None
    if type(value) is list:
        if len(value) == 0:
            return []
        if len(value) == 1:
            return [term(value[0])]
        if len(value) == 2:
            major, auxiliary = value
            encoded_major = formula(major)
            if major[0] == "=":
                auxiliary = formula(auxiliary)
            else:
                # Q and existential elimination carry an ignored data field.
                # Preserve it exactly rather than silently imposing a policy.
                auxiliary = deepcopy(auxiliary)
            return [encoded_major, auxiliary]
    raise ValueError("Not a canonical fixed-slot instruction")


def compile_document(document):
    if (type(document) is not list or len(document) != 2
            or type(document[1]) is not list):
        raise ValueError("Expected [goal, proof_stack]")
    goal, proof = document
    return [*[instruction(item) for item in proof], formula(goal)]


def encoded_bytes(document):
    return (json.dumps(document, separators=(",", ":")) + "\n").encode("utf-8")


def build_corpus():
    manifest_path = ROOT / "corpus_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    count = 0
    for item in manifest["examples"]:
        source = ROOT / item["source_file"]
        raw = source.read_bytes()
        if hashlib.sha256(raw).hexdigest() != item["source_sha256"]:
            raise ValueError("Frozen source certificate changed: " + str(source))
        target = ROOT / item["target_file"]
        data = encoded_bytes(compile_document(json.loads(raw)))
        if hashlib.sha256(data).hexdigest() != item["target_sha256"]:
            raise ValueError("Compilation differs from the frozen target: " + str(target))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        count += 1
    print(json.dumps({"compiled_examples": count}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", nargs="?", type=Path)
    parser.add_argument("target", nargs="?", type=Path)
    parser.add_argument("--corpus", action="store_true")
    args = parser.parse_args()
    if args.corpus:
        if args.source or args.target:
            parser.error("--corpus does not take positional paths")
        build_corpus()
    else:
        if args.source is None or args.target is None:
            parser.error("Provide source and target paths, or --corpus")
        document = compile_document(json.loads(args.source.read_bytes()))
        args.target.parent.mkdir(parents=True, exist_ok=True)
        args.target.write_bytes(encoded_bytes(document))


if __name__ == "__main__":
    main()
