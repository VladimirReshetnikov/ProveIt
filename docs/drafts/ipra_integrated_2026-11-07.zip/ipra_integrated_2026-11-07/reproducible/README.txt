REPRODUCIBLE COMPARISON AND FIXED-SLOT CORPUS
==========================================

The inspected current repository snapshot is:
  VladimirReshetnikov/ProveIt
  c5f42a50d9213259760ee385977481c04dccab28
  docs/drafts, 7 November 2026

This directory and its sibling comparison_sources/ must remain together.
The six current archives contain nine top-level checker*.py programs.
Historical checker copies nested inside those archives are not counted.

CONTENTS

comparison_manifest.json
  Exact archive filenames, repository paths, Git blob IDs, ZIP SHA-256
  hashes and byte sizes, immutable URLs, member paths, copied checker
  hashes, interfaces, and original license/attribution-file hashes.

../comparison_sources/<archive_stem>/
  All nine exact root checker source files, each archive's original
  LICENSE_SOURCE.txt, and original ATTRIBUTION.txt where present.
  These files are unchanged. They are never imported by the new checker.

compare.py
  Independent whole-application measurement script. All imports, syntax
  tables, substitution, dispatch, input loading, and verdict handling are
  counted. Genuine docstrings and comments are excluded. Normalized source
  is ast.unparse(stripped_tree) plus one newline. Measurements were made
  with CPython 3.12.14. The Python runtime and standard libraries are the
  common external runtime boundary, not part of these source counts.
  Core-only figures remove imports and the CLI uniformly, but are only
  diagnostic: some kernels bind their input reader inside the CLI.

corpus/source/
  The 89 closed fixed-slot draft certificates, copied byte-for-byte.

corpus/target/
  The same derivations in arity syntax, with proof instructions followed
  by the goal in one input stream.

corpus_manifest.json and corpus_mapping.csv
  Exact source/target paths, byte counts, hashes, source archive members,
  and inherited earlier provenance. Earlier origin labels are retained
  as upstream metadata; those older archives were not separately audited.

reencode.py
  An untrusted compiler for the canonical tagged fixed-slot certificate
  subset. Terms and formulas are translated by their grammar. Arity
  existential formulas receive two fixed equality annotations. De Bruijn
  indices and primitive rules are unchanged. The ignored auxiliary fields
  of Q/existential elimination are preserved exactly. Arbitrary permissive
  source encodings outside the canonical subset are not supported.

validate_corpus.py
  Runs the frozen source checker and a candidate arity/shared-stream checker
  on all 89 examples; requires acceptance, exact stream consumption, and
  byte-for-byte recompilation. --cli also runs 178 public subprocess checks:
  each example normally and under python -O.

results/comparison.json and results/comparison.csv
  Complete measurement records, both frontiers, minimizers, candidate
  comparisons, and hashes of the exact candidate measured.

results/corpus.json
  Complete finite regression results and exact candidate/source hashes.

REPRODUCE

From this directory, using Python 3.12.14 for identical normalized counts:

  python3 compare.py /absolute/path/to/candidate_checker.py
  python3 reencode.py --corpus
  python3 validate_corpus.py /absolute/path/to/candidate_checker.py --cli

For one source certificate:

  python3 reencode.py corpus/source/000_successor_plus_conditional.json target.json
  python3 /absolute/path/to/candidate_checker.py target.json

Re-encoding the corpus checks frozen hashes before writing its outputs; it
does not revise the expected mapping. The validation kernel must expose
check(goal, context) and use a module-level take reader, as does the new
single-stream arity candidate. The command-line validation exercises the
actual complete application independently of that internal entry point.

MEASURED CURRENT FRONTIERS

                         Normalized tokens  AST nodes  Normalized bytes
All nine current programs              483        491              1462
Six strict current programs            491        496              1506

These are componentwise minima: one baseline need not attain every minimum.
They are an observed finite-corpus frontier, not a universal minimality
theorem. Finite certificate tests supplement the mathematical proof; they
do not establish general soundness, completeness, or bi-interpretability.

LICENSE AND ATTRIBUTION

See ATTRIBUTION.txt and LICENSE_SOURCE.txt. Original per-archive records
are preserved alongside the unchanged checker sources.
