"""Compile the self-contained article with pdfLaTeX, without network access."""
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
engine = shutil.which("pdflatex")
if engine is None:
    raise SystemExit("pdfLaTeX is required to compile report.tex")
for _ in range(3):
    result = subprocess.run(
        [engine, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    (root / "results" / "latex_build.txt").write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-10000:])
        raise SystemExit(result.returncode)
print("Built " + str(root / "report.pdf"))
