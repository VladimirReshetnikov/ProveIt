A STRICTLY SMALLER INTEGRATED PRESENTATION OF iPRA
7 November 2026

Start with report.pdf. Its complete LaTeX source is report.tex and sections/.
The complete acceptance program is checker.py; FORMAT.txt describes its JSON
syntax and includes two minimal certificates.

RESULT

The strict checker has 468 normalized significant Python tokens, 478 AST nodes,
and 1445 normalized UTF-8 bytes, measured under CPython 3.12.14. It is smaller
in every coordinate than the all-variant minima 483 / 491 / 1462 across all
nine top-level checker variants in the six current ProveIt draft archives.
The inspected commit is c5f42a50d9213259760ee385977481c04dccab28.

The theory is the restricted retained-base unary calculus, with six primitive
rule patterns and two recursion schemas. The paper gives the entire logical
and nonlogical specification, exact consequence translations, full
intuitionistic logic, quantifier-free induction, and ordinary first-order
bi-interpretations with iPRA. Both composite isomorphisms are identity on the
whole original number domain. Its designated contradiction corresponds to
ordinary falsity, giving equiconsistency.

The improvement integrates compatible reductions already present separately
in the current drafts. The underlying arithmetic principles are inherited.
The finite comparison envelope is not a universal mathematical lower bound.
The report makes no global-minimality claim and no Lean/Rocq formalization claim.

CONTENTS

report.tex, sections/, report.pdf       Complete article and compiled PDF
checker.py, FORMAT.txt                  Complete strict acceptance boundary
reproduce.py                           Offline reproduction entry point
build.py                               Offline pdfLaTeX build
comparison_sources/                    Nine frozen baseline programs + licenses
reproducible/compare.py                 Reproducible source metrics
reproducible/comparison_manifest.json   Commit, archive and source provenance
reproducible/reencode.py                Untrusted grammar-aware certificate compiler
reproducible/corpus/source/             89 original fixed-slot proof certificates
reproducible/corpus/target/             89 translated proof certificates
reproducible/corpus_manifest.json       Source/target paths and hashes
reproducible/results/                   Comparison and corpus validation records
validation/                            Independent adversarial/substitution audit
results/                               Reproduction and build records
ATTRIBUTION.txt, LICENSE_SOURCE.txt     Research lineage and license
MANIFEST.sha256                        Delivered-file integrity manifest

REPRODUCE

From this directory:
  python3 reproduce.py
  python3 build.py

The first command checks all frozen comparison sources, re-encodes the corpus,
replays source and target proofs, runs all 89 public target certificates both
normally and under python -O, and runs the independent audit. The second
requires pdfLaTeX and the ordinary LaTeX packages named in report.tex. Neither
command uses the network.

To check a single proof:
  python3 checker.py examples/existential_zero.json
More examples are in reproducible/corpus/target/. Successful certificates print
ACCEPT and exit with status 0. JSON streams may have an unused prefix; the
compiler's canonical proof segments are consumed exactly.

VALIDATION BOUNDARY

The compiler and test utilities are untrusted and never imported by checker.py.
Finite tests test implementation behavior; they do not prove the universal
metatheorems. Those are proved mathematically in the article. Very large proofs
can exceed a particular Python runtime's resource limits. The abstract checker
is a finite-tree algorithm; completeness assumes sufficient resources.

The common Python runtime and json/sys standard libraries are the shared
comparison boundary. Source counts remove actual docstrings and normalize
with ast.unparse; documentation is not counted as kernel source. Raw bytes,
hashes, complete sources, and the normalization script are all supplied.
