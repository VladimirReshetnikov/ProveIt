#!/usr/bin/env python3
"""Independent semantic audit of the arity/fixed-coordinate iPRA kernel.

The oracle converts to named binders, substitutes there, and re-encodes.  The
reference verifier keeps named formulas and eigenvariables in its contexts;
it does not invoke, copy, or import the kernel's substitution routine.

Usage:
  python3 kernel_audit.py --checker checker.py --corpus corpus/target \
      --output kernel_audit_results.json
"""
import argparse
import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile


class Malformed(ValueError):
    pass


serial = itertools.count()


def fresh(kind='bound'):
    return (kind, next(serial))


def decode(a, formula, names=()):
    """Decode de Bruijn syntax to globally named syntax, validating all fields."""
    if not formula:
        if type(a) is int:
            if a == 0:
                return ('Z',)
            if a < 0:
                return ('V', ('rigid', a))
            if a <= len(names):
                return ('V', names[a - 1])
            return ('V', ('free', a - len(names)))
        if type(a) is not list:
            raise Malformed('a numerical term is an integer or a list')
        if len(a) == 1:
            return ('S', decode(a[0], False, names))
        if len(a) == 3:
            u, v = fresh(), fresh()
            return ('R', decode(a[0], False, names),
                    decode(a[1], False, names), u, v,
                    decode(a[2], False, (u, v) + names))
        raise Malformed('incorrect term arity')
    if type(a) is not list:
        raise Malformed('a formula must be a list')
    if len(a) == 2:
        return ('=', decode(a[0], False, names), decode(a[1], False, names))
    if len(a) in (1, 3):
        x = fresh()
        if len(a) == 1:
            return ('Q', x, decode(a[0], True, (x,) + names))
        return ('E', x, *(decode(b, True, (x,) + names) for b in a))
    raise Malformed('incorrect formula arity')


def encode(a, names=()):
    """Re-encode named syntax, independently checking that eigenvariables fit."""
    op = a[0]
    if op == 'Z':
        return 0
    if op == 'V':
        name = a[1]
        if name in names:
            return names.index(name) + 1
        if name[0] == 'rigid':
            return name[1]
        if name[0] == 'free':
            if name[1] <= 0:
                raise Malformed('nonpositive external coordinate')
            return name[1] + len(names)
        raise Malformed('escaping eigenvariable or unbound named variable')
    if op == 'S':
        return [encode(a[1], names)]
    if op == 'R':
        return [encode(a[1], names), encode(a[2], names),
                encode(a[5], (a[3], a[4]) + names)]
    if op == '=':
        return [encode(a[1], names), encode(a[2], names)]
    if op in ('Q', 'E'):
        return [encode(b, (a[1],) + names) for b in a[2:]]
    raise Malformed('unrecognized named constructor')


def replace(a, images):
    """Capture-free named substitution; images are not recursively substituted."""
    op = a[0]
    if op == 'V':
        return images.get(a[1], a)
    if op == 'Z':
        return a
    if op == 'S':
        return ('S', replace(a[1], images))
    if op == '=':
        return ('=', replace(a[1], images), replace(a[2], images))
    if op == 'R':
        body_images = {k: v for k, v in images.items() if k not in a[3:5]}
        return ('R', replace(a[1], images), replace(a[2], images), a[3], a[4],
                replace(a[5], body_images))
    if op in ('Q', 'E'):
        body_images = {k: v for k, v in images.items() if k != a[1]}
        return (op, a[1], *(replace(b, body_images) for b in a[2:]))
    raise Malformed('unrecognized named constructor')


def free_names(a):
    if a[0] == 'V':
        return {a[1]} if a[1][0] == 'free' else set()
    if a[0] == 'Z':
        return set()
    if a[0] in ('S', '='):
        parts = a[1:]
    elif a[0] == 'R':
        parts = (a[1], a[2], a[5])
    else:
        parts = a[2:]
    return set().union(*(free_names(b) for b in parts))


def oracle(a, env=(1,), d=0, formula=True):
    names = tuple(fresh('external-bound') for _ in range(d))
    named = decode(a, formula, names)
    replacements = {}
    for name in free_names(named):
        i = name[1]
        replacements[name] = (decode(env[i], False) if i < len(env)
                              else ('V', ('free', i + env[0])))
    return encode(replace(named, replacements), names)


def same(a, b, names):
    return encode(a, names) == encode(b, names)


class Reference:
    """Straight rule verifier using named eigenvariables and named substitution."""
    def __init__(self, stream):
        self.stream = copy.deepcopy(stream)

    def verify(self, goal, context=(), names=()):
        # Check for escaping names before any rule is used.
        encode(goal, names)
        instruction = self.stream.pop()
        if type(instruction) is list and len(instruction) == 2:
            major = decode(instruction[0], True, names)
            if self.verify(major, context, names):
                if major[0] == 'E':
                    y = fresh('eigen')
                    instance = replace(major[2], {major[1]: ('V', y)})
                    return self.verify(goal, (instance,) + context, (y,) + names)
                if major[0] == 'Q':
                    value = ('V', names[0] if names else ('free', 1))
                    wanted = replace(major[2], {major[1]: value})
                    if not same(goal, wanted, names):
                        return False
                    base = replace(major[2], {major[1]: ('Z',)})
                    return self.verify(base, context, names)
                slot = fresh('motive')
                motive = decode(instruction[1], True, (slot,) + names)
                source = replace(motive, {slot: major[1]})
                target = replace(motive, {slot: major[2]})
                return same(goal, target, names) and self.verify(source, context, names)
            # A failed major has consumed its attempted proof.  The only
            # surviving justification is an already present hypothesis.
            return any(same(goal, old, names) for old in context)
        if instruction == [] and type(instruction) is list:
            if goal[0] == 'Q':
                x, body = goal[1:]
                y = fresh('eigen')
                base = replace(body, {x: ('Z',)})
                step = replace(body, {x: ('S', ('V', y))})
                local = (base,)
                if body[0] == '=':
                    local += (replace(body, {x: ('V', y)}),)
                return self.verify(step, local + context, (y,) + names)
            if goal[0] == '=' and goal[1][0] == 'R':
                _, counter, initial, u, v, body = goal[1]
                if counter[0] == 'Z':
                    value = initial
                elif counter[0] == 'S':
                    predecessor = counter[1]
                    previous = ('R', predecessor, initial, u, v, body)
                    value = replace(body, {u: previous, v: predecessor})
                else:
                    # The actual computation branch raises before an outer
                    # failed-major fallback can be considered.
                    raise Malformed('computation counter is neither zero nor successor')
                return same(goal[2], value, names)
        if (type(instruction) is list and len(instruction) == 1
                and goal[0] == 'E'):
            witness = decode(instruction[0], False, names)
            y = fresh('eigen')
            instance = replace(goal[2], {goal[1]: ('V', y)})
            equality = ('=', ('V', y), witness)
            return self.verify(instance, (equality,) + context, (y,) + names)
        return any(same(goal, old, names) for old in context)

    def accept(self):
        try:
            goal = decode(self.stream.pop(), True)
            return bool(self.verify(goal))
        except (Exception, RecursionError):
            return False


def target_accept(module, stream):
    try:
        work = copy.deepcopy(stream)
        module.take = work.pop
        return bool(module.check(module.take(), []))
    except (Exception, RecursionError):
        return False


def lift(a, formula=False):
    return oracle(a, (1,), formula=formula)


def computation(left):
    n, initial, body = left
    if n == 0:
        right = copy.deepcopy(initial)
    elif type(n) is list and len(n) == 1:
        right = oracle(body, (-2, [n[0], initial, body], n[0]), formula=False)
    else:
        raise Malformed('not a computation axiom')
    return (left, right), [[]]


def reflexivity(t):
    bridge = [[0, t, 0], t]
    motive = [1, lift(t)]
    return [t, t], [[], [], [bridge, motive]]


def reflexive_closure(t):
    body = [lift(t), lift(t)]
    _, proof = reflexivity(lift(t))
    return [body], proof + [[]]


def reflexive_existence(t):
    body = [lift(t), lift(t)]
    _, proof = reflexivity(lift(t))
    return [body, [0, 0], [0, 0]], proof + [[0]]


def own_seeds(rng):
    seeds = {}
    terms = [0, -1, 1, [0], [[0]], [1], [0, 1, 1],
             [[1], [0], [1, 2, [1]]], [0, -3, [3, 1, 5]]]
    for i, t in enumerate(terms):
        a, p = reflexivity(t)
        seeds[f'own_reflexivity_{i}'] = p + [a]
        a, p = reflexive_closure(t)
        seeds[f'own_closure_reflexivity_{i}'] = p + [a]
        a, p = reflexive_existence(t)
        seeds[f'own_existential_reflexivity_{i}'] = p + [a]
        seeds[f'own_equality_witness_{i}'] = [None, [t],
            [[1, lift(t)], [0, 0], [[0, 0]]]]
        # Open an existential witness, then transport y=y along y=t.
        existential = [[1, lift(t)], [0, 0], [0, 0]]
        _, refl_p = reflexivity(1)
        minor = refl_p + [None, [[1, lift(t)], [1, 1]]]
        seeds[f'own_existential_elimination_{i}'] = (
            minor + [None, [t], [existential, {'ignored': True}], [t, t]])
        # Equality transport through a closure/existence binder.
        bridge = [[0, t, 0], t]
        for name, build, motive in (
                ('Q', reflexive_closure, [[2, 2]]),
                ('E', reflexive_existence, [[2, 2], [0, 0], [0, 0]])):
            old, old_p = build(bridge[0])
            new, _ = build(t)
            seeds[f'own_quantified_transport_{name}_{i}'] = (
                old_p + [[], [bridge, motive], new])
        # Genuine equation induction for R(x,t;u,v.u)=t.
        ty = lift(t)
        previous = [1, ty, 1]
        successor = [[1], ty, 1]
        ih = [previous, ty]
        motive = [lift(successor), 1]
        q = [[[1, ty, 1], ty]]
        q_p = [[], None, [ih, motive], []]
        seeds[f'own_equation_induction_{i}'] = q_p + [q]
        base = [[0, t, 1], t]
        seeds[f'own_induction_elimination_{i}'] = (
            [[]] + q_p + [[q, {'ignored-q': True}], [[1, t, 1], t]])
    for i in range(40):
        initial = random_term(rng, 2)
        body = random_term(rng, 3)
        left = [0 if i % 2 else [random_term(rng, 2)], initial, body]
        goal, proof = computation(left)
        seeds[f'own_computation_{i}'] = proof + [list(goal)]
    # The failed major is false, but the current goal really is a hypothesis.
    ex = [[1, 0], [0, 0], [0, 0]]
    seeds['own_guard_fallback'] = [None, [[0, [0]], None], [0], ex]
    seeds['own_inert_prefix'] = [{'unused': [True, 3.5, 'invalid syntax']},
                                None, [0], ex]
    return seeds


def random_term(rng, depth):
    if depth <= 0 or rng.random() < .45:
        return rng.choice([-3, -1, 0, 1, 2, 3, 4, 6])
    if rng.random() < .55:
        return [random_term(rng, depth - 1)]
    return [random_term(rng, depth - 1) for _ in range(3)]


def random_formula(rng, depth):
    if depth <= 0 or rng.random() < .55:
        return [random_term(rng, 2), random_term(rng, 2)]
    if rng.random() < .55:
        return [random_formula(rng, depth - 1)]
    return [random_formula(rng, depth - 1) for _ in range(3)]


def random_json(rng, depth):
    if depth <= 0 or rng.random() < .45:
        return rng.choice([None, True, False, -2, 0, 1, 3, 0.0, 1.5,
                           'q', '', {}, {'arbitrary': 1}])
    return [random_json(rng, depth - 1) for _ in range(rng.randrange(5))]


def paths(a, root=()):
    yield root
    if type(a) is list:
        for i, b in enumerate(a):
            yield from paths(b, root + (i,))


def changed(a, path, replacement):
    if not path:
        return copy.deepcopy(replacement)
    result = copy.deepcopy(a)
    branch = result
    for i in path[:-1]:
        branch = branch[i]
    branch[path[-1]] = copy.deepcopy(replacement)
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checker', required=True, type=Path)
    ap.add_argument('--corpus', action='append', default=[], type=Path)
    ap.add_argument('--output', type=Path, default=Path('kernel_audit_results.json'))
    ap.add_argument('--rounds', type=int, default=4000)
    args = ap.parse_args()
    spec = importlib.util.spec_from_file_location('audited_ipra_kernel', args.checker)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    default_before = copy.deepcopy(module.subst.__defaults__)
    rng = random.Random(20261107)
    errors = []
    result = {
        'checker': str(args.checker),
        'checker_sha256': hashlib.sha256(args.checker.read_bytes()).hexdigest(),
        'python': platform.python_version(),
        'random_seed': 20261107,
        'oracle': 'named binders, named simultaneous substitution, re-encoding',
        'reference': 'named natural-deduction rules with explicit eigenvariables',
    }

    # Validate syntax before deriving anything; malformed unused padding is
    # included, while inactive certificate fields are checked separately.
    formation_cases = []
    atoms = [None, True, False, 0.0, 1.5, 'q', '', {}, [], 0, -1, 1,
             [0], [0, 0], [[0, 0]], [0, 0, 0], [[0, 0], [0, 0], [0, 0]]]
    for formula in (False, True):
        formation_cases.extend((formula, x) for x in atoms)
        for _ in range(args.rounds // 2):
            good = random_formula(rng, 3) if formula else random_term(rng, 4)
            formation_cases.append((formula, good))
            path = rng.choice(list(paths(good)))
            formation_cases.append((formula, changed(good, path, rng.choice(atoms))))
            formation_cases.append((formula, random_json(rng, 3)))
    valid_count = 0
    for formula, raw in formation_cases:
        try:
            decode(raw, formula)
            expected = True
        except Exception:
            expected = False
        try:
            module.subst(copy.deepcopy(raw), formula=formula)
            actual = True
        except Exception:
            actual = False
        valid_count += expected
        if actual != expected and len(errors) < 20:
            errors.append({'phase': 'formation', 'formula': formula,
                           'value': raw, 'expected': expected, 'actual': actual})
    result['formation'] = {'cases': len(formation_cases), 'valid': valid_count,
                           'invalid': len(formation_cases) - valid_count}

    # Use general legal environments as well as every environment shape used
    # by the actual kernel, including nested recursion and logical binders.
    substitution_count = 0
    for _ in range(args.rounds):
        formula = bool(rng.randrange(2))
        raw = random_formula(rng, 3) if formula else random_term(rng, 4)
        d = rng.randrange(5)
        k = rng.randrange(4)
        env = [rng.randrange(-k, 4)] + [random_term(rng, 3) for _ in range(k)]
        expected = oracle(raw, env, d, formula)
        actual = module.subst(copy.deepcopy(raw), copy.deepcopy(env), d, formula)
        substitution_count += 1
        if actual != expected and len(errors) < 20:
            errors.append({'phase': 'substitution', 'formula': formula,
                           'depth': d, 'value': raw, 'environment': env,
                           'expected': expected, 'actual': actual})
    # A named round trip probes all term/formula formation paths separately.
    roundtrip_count = 0
    for _ in range(args.rounds // 4):
        formula = bool(rng.randrange(2))
        raw = random_formula(rng, 3) if formula else random_term(rng, 4)
        if encode(decode(raw, formula)) != raw and len(errors) < 20:
            errors.append({'phase': 'roundtrip', 'value': raw})
        roundtrip_count += 1
    result['substitution'] = {'cases': substitution_count,
                              'named_roundtrips': roundtrip_count,
                              'depths': [0, 1, 2, 3, 4],
                              'general_environment_images': [0, 1, 2, 3]}

    seeds = own_seeds(rng)
    own_count = len(seeds)
    corpus_files = []
    for directory in args.corpus:
        for file in sorted(directory.glob('*.json')):
            key = str(file)
            seeds[key] = json.loads(file.read_text())
            corpus_files.append({'path': key,
                                 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
    actual_accepted = reference_accepted = 0
    for name, seed in seeds.items():
        actual = target_accept(module, seed)
        expected = Reference(seed).accept()
        actual_accepted += actual
        reference_accepted += expected
        if (not actual or not expected) and len(errors) < 20:
            errors.append({'phase': 'valid_seed', 'name': name,
                           'reference': expected, 'target': actual})
    result['proof_seeds'] = {'independently_constructed': own_count,
                             'external_corpus': len(corpus_files),
                             'target_accepted': actual_accepted,
                             'reference_accepted': reference_accepted}

    # Alter arbitrary input positions.  Some mutations are harmless or remain
    # valid proofs; require exact agreement with the independent rule verifier
    # rather than incorrectly demanding rejection of every mutated input.
    all_seeds = list(seeds.items())
    mutated_accepted = mutated_rejected = 0
    replacements = [None, True, False, 0, 1, -1, [0], [0, 0], [], {}, 'q',
                    1.5, [0, [0]], [[0, 0], [0, 0], [0, 0]]]
    for _ in range(args.rounds):
        name, seed = rng.choice(all_seeds)
        path = rng.choice(list(paths(seed)))
        replacement = rng.choice(replacements)
        altered = changed(seed, path, replacement)
        actual = target_accept(module, altered)
        expected = Reference(altered).accept()
        mutated_accepted += actual
        mutated_rejected += not actual
        if actual != expected and len(errors) < 20:
            errors.append({'phase': 'proof_mutation', 'seed': name, 'path': path,
                           'replacement': replacement, 'reference': expected,
                           'target': actual, 'input': altered})
    result['proof_mutations'] = {'cases': args.rounds,
                                  'accepted': mutated_accepted,
                                  'rejected': mutated_rejected}

    contradiction_count = 0
    for name, seed in all_seeds:
        altered = copy.deepcopy(seed)
        altered[-1] = [0, [0]]
        actual = target_accept(module, altered)
        expected = Reference(altered).accept()
        contradiction_count += 1
        if (actual or expected) and len(errors) < 20:
            errors.append({'phase': 'contradiction', 'seed': name,
                           'reference': expected, 'target': actual})
    result['contradiction_goal_mutations'] = contradiction_count

    # Public-interface checks, including strict vacuous existential witnesses,
    # inert Q/ex-elimination fields, and failure of malformed active padding.
    public = {
        'zero_reflexivity': (seeds['own_reflexivity_0'], True),
        'guard_fallback': (seeds['own_guard_fallback'], True),
        'inert_prefix': (seeds['own_inert_prefix'], True),
        'malformed_goal': ([None, True], False),
        'empty_stream': ([], False),
        'nonarray_stream': ({'goal': [0, 0]}, False),
        'false_goal': ([None, [0, [0]]], False),
    }
    vacuous, vac_p = reflexive_existence(0)
    public['strict_vacuous_witness'] = (vac_p[:-1] + [[True], vacuous], False)
    public['strict_unused_padding'] = ([None, [0], [[1, 0], True, [0, 0]]], False)
    public['malformed_major_cannot_fall_back'] = (
        [None, [True, None], [0], [[1, 0], [0, 0], [0, 0]]], False)
    public_results = []
    with tempfile.TemporaryDirectory() as directory:
        for name, (stream, expected) in public.items():
            path = Path(directory) / (name + '.json')
            path.write_text(json.dumps(stream))
            run = subprocess.run([sys.executable, str(args.checker.resolve()), str(path)],
                                 text=True, capture_output=True, timeout=10)
            actual = run.returncode == 0 and run.stdout.strip() == 'ACCEPT'
            rejected_cleanly = run.returncode == 1 and run.stdout.strip() == 'REJECT'
            public_results.append({'name': name, 'expected': expected,
                                   'accepted': actual, 'returncode': run.returncode})
            if actual != expected or (not expected and not rejected_cleanly):
                errors.append({'phase': 'public_cli', 'name': name,
                               'stdout': run.stdout, 'stderr': run.stderr,
                               'returncode': run.returncode})
    if module.subst.__defaults__ != default_before:
        errors.append({'phase': 'mutable_defaults', 'error': 'default changed'})
    result['public_cli'] = public_results
    result['corpus_files'] = corpus_files
    result['errors'] = errors
    result['passed'] = not errors
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('corpus_files', 'public_cli')}, indent=2))
    return 0 if not errors else 1


if __name__ == '__main__':
    raise SystemExit(main())
