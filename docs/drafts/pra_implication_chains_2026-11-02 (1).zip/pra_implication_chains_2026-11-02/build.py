#!/usr/bin/env python3
"""Rebuild the paper and rerun checks using already installed tools."""
from pathlib import Path
import argparse
import json
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', default=os.environ.get('PRA_CHAIN_LEAN', 'lean'),
                        help='Lean executable; defaults to PRA_CHAIN_LEAN or lean')
    parser.add_argument('--skip-lean', action='store_true')
    args = parser.parse_args()
    tex = shutil.which('pdflatex')
    if not tex:
        raise SystemExit('pdflatex is required; install a LaTeX distribution first.')
    build_dir = ROOT / '.build'
    build_dir.mkdir(exist_ok=True)
    for index in (1, 2):
        result = subprocess.run(
            [tex, '-interaction=nonstopmode', '-halt-on-error',
             '-output-directory=.build', 'report.tex'],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (build_dir / f'pdflatex-{index}.txt').write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-8000:])
            raise SystemExit(f'LaTeX pass {index} failed.')
    shutil.copy2(build_dir / 'report.pdf', ROOT / 'report.pdf')
    subprocess.run([sys.executable, str(ROOT / 'artifacts/check_syntax.py')],
                   cwd=ROOT, check=True)
    lean = shutil.which(args.lean)
    if args.skip_lean:
        lean_status = 'not run (--skip-lean)'
    elif lean:
        result = subprocess.run([lean, 'artifacts/LocalKernels.lean'], cwd=ROOT,
                                text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT)
        (build_dir / 'lean-rerun.txt').write_text(result.stdout)
        print(result.stdout, end='')
        if result.returncode:
            raise SystemExit('Lean verification failed.')
        lean_status = 'passed'
    else:
        lean_status = 'not run: Lean executable unavailable; recorded original check retained'
    status = {'pdf': 'compiled twice', 'syntax_checks': 'passed', 'lean_rerun': lean_status}
    (build_dir / 'build_status.json').write_text(json.dumps(status, indent=2) + '\n')
    print(json.dumps(status, indent=2))

if __name__ == '__main__':
    main()
