PRA FROM IMPLICATION CHAINS
Research report for Vladimir Reshetnikov, 2 November 2026

START HERE
  report.pdf                 Complete mathematical report
  report.tex + sections/     Complete editable LaTeX source
  AXIOMS.txt                 Exact standalone specification
  artifacts/LocalKernels.lean
                             Checked constructive local proof kernels
  artifacts/check_syntax.py  Independent syntax/count/finite-scan checks
  artifacts/check_results.json, metrics.csv
                             Check coverage and exact example comparisons
  provenance/source_manifest.json
                             Eleven audited archives, pinned URLs and hashes
  provenance/draft_audit.csv Package eligibility and retained improvements

NEW RESULT
  K(A,B,C) := (A -> B) AND (B -> C).
  This generic logical definition has a 12-node record, the same as
  the current weak conditional. It is not an arithmetic oracle.

  The supported atomic predecessor boundary costs F+16, versus the
  strongest current covered F+18 boundary. Two shared computation
  modules cost 3H+21 and 2H+33, versus 3H+22 and 2H+34.

  Boundary indices need only include equations with an active occurrence
  of the induction variable inside a recursor argument. All omitted
  equation-induction implications follow by finite successor cancellation.

  The report proves a common conservative definitional extension with
  first-order PRA, with full-carrier interpretations and identity composites.
  The proof works classically and separately intuitionistically.

COST QUALIFICATIONS
  Coverage is explicit and costs 10 nodes beyond the uncovered forward
  basis. Including Sep and the K definition, fixed support is 28 nodes,
  versus 18 in the uncovered weak-J mode and 28 in its covered mode.
  Whole-packet fallback to an old complete presentation is required for
  a literal finite-workload non-increase against all applicable old modes.
  No unrestricted language-independent shortestness theorem is claimed.

VERIFICATION SCOPE
  Lean 4.19.0 compiled the local file with no errors/warnings; all 13
  audited theorem axiom lists are empty. The complete staged syntax,
  arithmetic/parameter compiler, and bi-interpretation metatheorem are
  English proofs in the report, not fully formalized in this archive.
  Python checks supplement the proofs; finite examples do not prove
  PRA equivalence.

BUILD
  python3 build.py
  Requires Python 3 and pdflatex with standard AMS/Latin Modern packages.
  If Lean 4.19.0 is installed and on PATH, it is also rerun. Otherwise
  the build reports it as not run and retains the original validation log.
  To specify Lean: python3 build.py --lean /absolute/path/to/lean
  To omit a rerun explicitly: python3 build.py --skip-lean
  Nothing in the build script downloads software.

SOURCE AUDIT
  ProveIt commit 5f9cb0b20a6a83a11917c56efec53714ea85df6f:
  six current ZIPs and five archived ZIPs, all downloaded and Git-hash
  verified. Every current package has an improvement over that archived
  iteration; dominated local templates are excluded from the frontier.

ATTRIBUTION
  Initialized recursion, the predecessor-boundary principle, the arithmetic
  ledger, triangular pairing, and the small equality error/compiler are
  inherited from the audited drafts and cited in the paper. New material
  is the implication-chain serialization, the recursor-input index filter,
  the two chain computation modules, and their supported comparison.
