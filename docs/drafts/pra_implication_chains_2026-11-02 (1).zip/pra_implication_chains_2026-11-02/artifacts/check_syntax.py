#!/usr/bin/env python3
"""Reproducible finite checks for PRA from implication chains.

Python 3.10+, standard library only.  Run from any directory:
    python3 artifacts/check_syntax.py

The AST counts full frozen recursor descriptions at every application.
Substitution operates on active term arguments only.  Formula constructors
below use explicitly fresh bound-variable names; this is not advertised as
a general-purpose first-order proof checker or capture-avoiding exporter.

Checks cover actual syntax-tree counts, a finite staged term inventory,
finite propositional/Heyting calculations, all one- and two-element local
computation structures, and all Boolean scan patterns through target 10.
These finite checks do not establish the infinite arithmetic reconstruction
or bi-interpretability theorem; those have written proofs in report.pdf.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Node:
    op: str
    children: tuple["Node", ...] = ()
    name: str = ""
    descriptor: "Node | None" = None


def V(name: str) -> Node:
    return Node("var", name=name)


ZERO = Node("zero")
FALSE = Node("false")


def S(t: Node) -> Node:
    return Node("S", (t,))


def R(h: Node, t: Node, a: Node) -> Node:
    assert active_variables(h) <= {"v", "w"}
    return Node("R", (t, a), descriptor=h)


def Eq(t: Node, u: Node) -> Node:
    return Node("eq", (t, u))


def And(a: Node, b: Node) -> Node:
    return Node("and", (a, b))


def Or(a: Node, b: Node) -> Node:
    return Node("or", (a, b))


def Imp(a: Node, b: Node) -> Node:
    return Node("imp", (a, b))


def K(a: Node, b: Node, c: Node) -> Node:
    return Node("K", (a, b, c))


def J(a: Node, b: Node, c: Node) -> Node:
    return Node("J", (a, b, c))


def StrongIf(a: Node, b: Node, c: Node) -> Node:
    return Node("If", (a, b, c))


def All(names: str, body: Node) -> Node:
    for name in reversed(names.split()):
        body = Node("forall", (body,), name=name)
    return body


def Exists(names: str, body: Node) -> Node:
    for name in reversed(names.split()):
        body = Node("exists", (body,), name=name)
    return body


@lru_cache(maxsize=None)
def size(t: Node) -> int:
    return 1 + sum(map(size, t.children)) + (
        size(t.descriptor) if t.descriptor is not None else 0
    )


@lru_cache(maxsize=None)
def active_size(t: Node) -> int:
    return 1 + sum(map(active_size, t.children))


@lru_cache(maxsize=None)
def active_variables(t: Node) -> frozenset[str]:
    if t.op == "var":
        return frozenset((t.name,))
    return frozenset().union(*(active_variables(c) for c in t.children))


@lru_cache(maxsize=None)
def occurrences(t: Node, variable: str) -> int:
    return int(t.op == "var" and t.name == variable) + sum(
        occurrences(c, variable) for c in t.children
    )


def substitute_term(t: Node, replacements: dict[str, Node]) -> Node:
    assert t.op in {"var", "zero", "S", "R"}
    if t.op == "var":
        return replacements.get(t.name, t)
    return Node(
        t.op,
        tuple(substitute_term(c, replacements) for c in t.children),
        t.name,
        t.descriptor,  # deliberately frozen
    )


def substitute_equation(e: Node, variable: str, value: Node) -> Node:
    assert e.op == "eq"
    return Eq(*(substitute_term(t, {variable: value}) for t in e.children))


def relevant(t: Node, variable: str = "x", under_recursor: bool = False) -> bool:
    if t.op == "var":
        return t.name == variable and under_recursor
    return any(
        relevant(c, variable, under_recursor or t.op == "R")
        for c in t.children
    )


@lru_cache(maxsize=None)
def rank(t: Node) -> int:
    active_rank = max((rank(c) for c in t.children), default=0)
    symbol_rank = 1 + rank(t.descriptor) if t.descriptor is not None else 0
    return max(active_rank, symbol_rank)


def expand_logical(t: Node) -> Node:
    children = tuple(expand_logical(c) for c in t.children)
    if t.op == "K":
        a, b, c = children
        return And(Imp(a, b), Imp(b, c))
    if t.op == "J":
        a, b, c = children
        return And(Or(a, b), Imp(a, c))
    if t.op == "If":
        a, b, c = children
        return Or(And(a, b), And(Imp(a, FALSE), c))
    return Node(t.op, children, t.name, t.descriptor)


def pretty(t: Node) -> str:
    if t.op == "var":
        return t.name
    if t.op == "zero":
        return "0"
    if t.op == "R":
        return "R[" + pretty(t.descriptor) + "](" + ",".join(map(pretty, t.children)) + ")"
    return t.op + "(" + ",".join(map(pretty, t.children)) + ")"


def computation_modules(h: Node) -> dict[str, tuple[Node, ...]]:
    a, n, u, x, y = map(V, ("a", "n", "u", "x", "y"))
    value = R(h, n, a)
    next_value = R(h, S(n), a)
    body = substitute_term(h, {"v": u, "w": n})
    initialization = Imp(Eq(n, ZERO), Eq(u, a))
    pair = (
        All("a", Eq(R(h, ZERO, a), a)),
        All("a n", Eq(next_value, substitute_term(h, {"v": value, "w": n}))),
    )
    old_g = All("a n u", Imp(Eq(value, u), And(initialization, Eq(next_value, body))))
    new_g = All("a n u", K(And(Eq(n, ZERO), Eq(u, a)), Eq(value, u), Eq(next_value, body)))
    current_endpoint = Imp(Eq(x, n), Eq(y, u))
    successor_endpoint = Imp(Eq(x, S(n)), Eq(y, body))
    graph = Eq(R(h, x, a), y)
    old_t = All("a n", Exists("u", And(initialization,
        All("x y", Imp(graph, And(current_endpoint, successor_endpoint))))))
    new_t = All("a n", Exists("u", And(initialization,
        All("x y", K(And(Eq(x, n), Eq(y, u)), graph, successor_endpoint)))))
    return {"pair": pair, "old_g": (old_g,), "old_t": (old_t,),
            "new_g": (new_g,), "new_t": (new_t,)}


def boundary_modules(e: Node) -> dict[str, Node]:
    a, n, b, x = map(V, ("a", "n", "b", "x"))
    eb = substitute_equation(e, "x", b)
    esb = substitute_equation(e, "x", S(b))
    direct = All("a n", Exists("b", J(eb, Eq(b, ZERO), Imp(esb, Eq(b, n)))))
    forward = All("a n", Exists("b", All("x",
        J(e, Imp(Eq(x, b), Eq(b, ZERO)), Imp(Eq(x, S(b)), Eq(b, n))))))
    covered = All("a n", Exists("b", All("x",
        StrongIf(e, Imp(Eq(x, b), Eq(b, n)), Imp(Eq(S(x), b), FALSE)))))
    chain = All("a n", Exists("b", All("x",
        K(Eq(S(x), b), e, Imp(Eq(x, b), Eq(b, n))))))
    return {"old_j_direct": direct, "old_forward": forward,
            "old_covered": covered, "new_chain": chain}


def ordinary_boundary_modules(e: Node) -> dict[str, Node]:
    """The five archived native serializers, with all value binders charged."""
    n, b, c, x, u, v = map(V, ("n", "b", "c", "x", "u", "v"))
    left, right = e.children
    eb = substitute_equation(e, "x", b)
    esb = substitute_equation(e, "x", S(b))
    ec = substitute_equation(e, "x", c)
    direct = All("a n", Exists("b", And(Or(Eq(b,ZERO),eb), Imp(esb,Eq(b,n)))))
    shared = All("a n", Exists("b c", And(Eq(c,S(b)),
        And(Or(Eq(b,ZERO),eb),Imp(ec,Eq(b,n))))))

    def endpoint_constraints(value_equality: Node) -> Node:
        return And(Imp(Eq(x,b),Or(Eq(b,ZERO),value_equality)),
                   Imp(Eq(x,S(b)),Imp(value_equality,Eq(b,n))))

    both = All("a n", Exists("b", All("x u v", Imp(
        And(Eq(u,left),Eq(v,right)), endpoint_constraints(Eq(u,v))))))
    left_bound = All("a n", Exists("b", All("x u", Imp(
        Eq(u,left), endpoint_constraints(Eq(u,right))))))
    right_bound = All("a n", Exists("b", All("x u", Imp(
        Eq(u,right), endpoint_constraints(Eq(u,left))))))
    return {"ordinary_direct":direct,"ordinary_shared":shared,
            "ordinary_both_values":both,"ordinary_left_value":left_bound,
            "ordinary_right_value":right_bound}


def check_ordinary_sizes(e: Node) -> dict[str, int]:
    F, i = size(e), occurrences(e,"x")
    X, Y = map(size,e.children)
    actual = {name:size(clause) for name,clause in ordinary_boundary_modules(e).items()}
    assert actual == {"ordinary_direct":2*F+i+12,"ordinary_shared":2*F+18,
        "ordinary_both_values":F+35,"ordinary_left_value":X+2*Y+30,
        "ordinary_right_value":2*X+Y+30}
    assert min(actual.values()) == min(2*F+i+12,2*F+18,F+29+min(X,Y,6))
    return actual


def module_size(module: tuple[Node, ...]) -> int:
    return sum(map(size, module))


def descriptor_inventory() -> list[Node]:
    v, w = V("v"), V("w")
    pool = [ZERO, v, w]
    for start in (ZERO, v, w):
        h = start
        for _ in range(24):
            h = S(h)
            pool.append(h)
    h = v
    for _ in range(99):
        h = S(h)
    pool.append(h)
    rng = random.Random(20261102)
    for _stage in range(3):
        earlier = tuple(pool)
        new = []
        for _ in range(120):
            body = rng.choice((ZERO, v, w))
            for _ in range(rng.randrange(1, 5)):
                if rng.randrange(3) == 0:
                    body = S(body)
                else:
                    # Every selected stored body belongs to an earlier stage.
                    desc = rng.choice(earlier[:min(len(earlier), 95)])
                    other = rng.choice((ZERO, v, w, S(v), S(w)))
                    body = R(desc, body, other) if rng.randrange(2) else R(desc, other, body)
            new.append(body)
        pool.extend(new)
    return list(dict.fromkeys(pool))


def staged_terms(max_size: int = 7) -> dict[int, list[Node]]:
    v, w = V("v"), V("w")
    descriptors = [ZERO, v, w, S(ZERO), S(v), S(w),
                   R(v, v, w), R(w, w, v), R(ZERO, v, w)]
    by_size = {1: [ZERO, V("x"), V("a")]}
    for full in range(2, max_size + 1):
        terms = [S(t) for t in by_size[full - 1]]
        for h in descriptors:
            rest = full - 1 - size(h)
            for left_size in range(1, rest):
                right_size = rest - left_size
                if left_size in by_size and right_size in by_size:
                    terms.extend(R(h, l, r) for l in by_size[left_size] for r in by_size[right_size])
        by_size[full] = list(dict.fromkeys(terms))
    return by_size


def syntax_checks() -> dict:
    descriptors = descriptor_inventory()
    savings = {0: 0, 1: 0}
    for h in descriptors:
        H, k = size(h), occurrences(h, "v")
        actual = {name: module_size(m) for name, m in computation_modules(h).items()}
        expected = {"pair": 3*H+13+k*(H+2), "old_g": 3*H+22,
                    "old_t": 2*H+34, "new_g": 3*H+21, "new_t": 2*H+33}
        assert actual == expected, (pretty(h), actual, expected)
        old = min(actual[c] for c in ("pair", "old_g", "old_t"))
        new = min(actual[c] for c in ("pair", "new_g", "new_t"))
        assert 0 <= old-new <= 1
        savings[old-new] += 1
        m = active_size(h)
        assert sum(active_size(t) for t in computation_modules(h)["pair"]) == m+13+2*k
        assert active_size(computation_modules(h)["new_g"][0]) == m+21
        assert active_size(computation_modules(h)["new_t"][0]) == m+33

    frozen = R(V("v"), V("v"), V("w"))
    substituted = substitute_term(frozen, {"v": S(S(V("w"))), "w": ZERO})
    assert substituted.descriptor == V("v")
    assert occurrences(frozen, "v") == 1
    assert size(substituted) == size(frozen) + 2
    assert rank(frozen) == 1

    by_size = staged_terms()
    checked = kept = omitted = large_relevant = 0
    min_f = min_i = None
    exceptions = set()
    module_savings = {}
    for ls, lefts in by_size.items():
        for rs, rights in by_size.items():
            if 1+ls+rs > 10:
                continue
            for l, r in itertools.product(lefts, rights):
                e = Eq(l, r)
                F, i = size(e), occurrences(e, "x")
                clauses = boundary_modules(e)
                expected = {"old_j_direct": 2*F+i+11, "old_forward": F+20,
                            "old_covered": F+18, "new_chain": F+16}
                actual = {name: size(c) for name, c in clauses.items()}
                assert actual == expected, (pretty(e), actual, expected)
                assert size(expand_logical(clauses["new_chain"])) == 2*F+18
                checked += 1
                if i > 0 and min(actual["old_j_direct"], actual["old_forward"]) < actual["new_chain"]:
                    exceptions.add(pretty(e))
                if relevant(e):
                    kept += 1
                    assert F >= 6 and i >= 1
                    min_f = F if min_f is None else min(min_f, F)
                    min_i = i if min_i is None else min(min_i, i)
                    old = min(actual["old_j_direct"], actual["old_forward"])
                    saving = old-actual["new_chain"]
                    assert 2 <= saving <= 4
                    assert actual["new_chain"] == actual["old_covered"]-2
                    module_savings[saving] = module_savings.get(saving, 0)+1
                    if F+i >= 9:
                        # All three incumbent modes must be compared separately.
                        # These are lower bounds on recurring savings; fixed costs
                        # are included in global_envelope_checks below.
                        X,Y = map(size,e.children)
                        ordinary = min(2*F+i+12,2*F+18,F+29+min(X,Y,6))
                        assert old-actual["new_chain"] == 4
                        assert actual["old_covered"]-actual["new_chain"] == 2
                        assert ordinary-actual["new_chain"] >= 5
                        large_relevant += 1
                else:
                    omitted += 1
                    # Syntactic shape lemma for every omitted side.
                    for term in (l, r):
                        if "x" in active_variables(term):
                            while term.op == "S":
                                term = term.children[0]
                            assert term == V("x")
    assert exceptions == {"eq(x,0)", "eq(0,x)", "eq(x,a)", "eq(a,x)"}
    assert (min_f, min_i) == (6, 1)

    sep = Imp(Eq(ZERO, S(ZERO)), FALSE)
    z, y = V("z"), V("y")
    cov = All("z", Exists("y", Or(Eq(z, ZERO), Eq(z, S(y)))))
    A, B, C = map(V, ("A", "B", "C"))
    k_definition = size(K(A,B,C)) + size(expand_logical(K(A,B,C))) + 1
    j_definition = size(J(A,B,C)) + size(expand_logical(J(A,B,C))) + 1
    if_definition = size(StrongIf(A,B,C)) + size(expand_logical(StrongIf(A,B,C))) + 1
    assert (size(sep), size(cov), k_definition, j_definition, if_definition) == (6,10,12,12,14)
    return {"descriptor_count": len(descriptors), "descriptor_max_rank": max(map(rank, descriptors)),
            "descriptor_max_full_size": max(map(size, descriptors)),
            "computation_envelope_saving_counts": savings,
            "term_counts_by_full_size": {str(s): len(ts) for s,ts in by_size.items()},
            "equations_checked": checked, "relevant_equations": kept, "omitted_equations": omitted,
            "relevant_equations_with_F_plus_i_at_least_9":large_relevant,
            "minimum_relevant_F": min_f, "minimum_relevant_i": min_i,
            "boundary_clause_saving_counts": module_savings,
            "unfiltered_small_exceptions": sorted(exceptions),
            "fixed_costs": {"separation": 6, "coverage": 10,
                            "K_definition": 12, "J_definition": 12, "strong_If_definition": 14,
                            "old_forward_fixed_support": 18, "new_chain_fixed_support": 28},
            "frozen_descriptor_substitution_check": "PASS"}


def implies(a: bool, b: bool) -> bool:
    return not a or b


def chain(a: bool, b: bool, c: bool) -> bool:
    return implies(a,b) and implies(b,c)


def propositional_checks() -> dict:
    valuations = list(itertools.product((False,True), repeat=3))
    table = [{"A": int(a), "B": int(b), "C": int(c), "K": int(chain(a,b,c))}
             for a,b,c in valuations]
    mask = lambda values: sum(int(v) << i for i,v in enumerate(values))
    leaves = {mask(row[j] for row in valuations): name for j,name in enumerate(("A","B","C"))}
    leaves[0] = "false"
    target = mask(chain(a,b,c) for a,b,c in valuations)
    exact = {1: set(leaves)}
    for nodes in (3,5,7):
        outputs = set()
        for left_nodes in range(1,nodes-1,2):
            right_nodes = nodes-1-left_nodes
            for l,r in itertools.product(exact[left_nodes], exact[right_nodes]):
                outputs.update((l&r, l|r, ((~l)|r)&255))
        exact[nodes] = outputs
    minimum = min(nodes for nodes, functions in exact.items() if target in functions)
    assert minimum == 7
    himp = lambda a,b: 2 if a <= b else b
    strict_examples = []
    for a,b,c in itertools.product(range(3), repeat=3):
        k = min(himp(a,b), himp(b,c))
        j = min(max(b,himp(a,0)), himp(b,c))  # J(B,not A,C)
        assert himp(min(k,a), b) == 2
        assert himp(min(k,b), c) == 2
        assert himp(j,k) == 2
        if k > j:
            strict_examples.append({"A":a,"B":b,"C":c,"K":k,"J(B,not A,C)":j})
    assert strict_examples
    return {"boolean_truth_table": table, "boolean_K_mask": target,
            "binary_formula_function_counts": {str(n):len(v) for n,v in exact.items()},
            "minimum_binary_formula_tree_size": minimum,
            "lower_bound_grammar": "A,B,C,false; binary and,or,implies; no sharing",
            "three_element_Heyting_valuations": 27,
            "strict_weakness_example": strict_examples[0]}


def finite_computation_checks() -> dict:
    counts = {}
    for cardinality in (1,2):
        d = tuple(range(cardinality))
        count = 0
        for zero in d:
            for successor_values in itertools.product(d, repeat=cardinality):
                for r_values in itertools.product(d, repeat=cardinality**2):
                    for h_values in itertools.product(d, repeat=cardinality**2):
                        rr = lambda n,a: r_values[n*cardinality+a]
                        hh = lambda u,n: h_values[u*cardinality+n]
                        ss = lambda n: successor_values[n]
                        pair = all(rr(zero,a)==a for a in d) and all(
                            rr(ss(n),a)==hh(rr(n,a),n) for a,n in itertools.product(d, repeat=2))
                        old_g = all(implies(rr(n,a)==u,
                            implies(n==zero,u==a) and rr(ss(n),a)==hh(u,n))
                            for a,n,u in itertools.product(d, repeat=3))
                        new_g = all(chain(n==zero and u==a, rr(n,a)==u,
                            rr(ss(n),a)==hh(u,n)) for a,n,u in itertools.product(d, repeat=3))
                        old_t = all(any(implies(n==zero,u==a) and all(
                            implies(rr(x,a)==y, implies(x==n,y==u) and implies(x==ss(n),y==hh(u,n)))
                            for x,y in itertools.product(d, repeat=2)) for u in d)
                            for a,n in itertools.product(d, repeat=2))
                        new_t = all(any(implies(n==zero,u==a) and all(
                            chain(x==n and y==u, rr(x,a)==y, implies(x==ss(n),y==hh(u,n)))
                            for x,y in itertools.product(d, repeat=2)) for u in d)
                            for a,n in itertools.product(d, repeat=2))
                        assert pair == old_g == new_g == old_t == new_t
                        count += 1
        counts[str(cardinality)] = count
    return {"all_structures_by_carrier_size": counts,
            "allows_successor_fixed_points_and_noninjectivity": True,
            "scope": "Finite model checks of local module equivalences, not the infinite theory."}


def scan_checks(max_target: int = 10) -> dict:
    patterns = invariant_instances = endpoint_instances = 0
    for n in range(max_target+1):
        for values in itertools.product((False,True), repeat=n+1):
            b = 0
            for k in range(n+1):
                assert 0 <= b <= k
                assert implies(values[b], b==k)
                assert b==0 or values[b-1]
                invariant_instances += 1
                if k < n and values[b]:
                    b = k+1
            assert b==0 or values[b-1]
            assert implies(values[b], b==n)
            endpoint_instances += 2
            if values[0] and all(implies(values[k],values[k+1]) for k in range(n)):
                assert values[n]
            patterns += 1
    return {"maximum_target":max_target,"Boolean_patterns":patterns,
            "quantifier_free_invariant_instances":invariant_instances,
            "predecessor_and_endpoint_obligations":endpoint_instances,
            "scope":"All predicates on each finite interval[0,n], n<=10; not a proof for arbitrary n."}


def metrics_rows() -> list[dict]:
    rows = []
    for exponent in (0,1,2,3,7,15,99):
        h = V("v")
        for _ in range(exponent):
            h = S(h)
        e = Eq(R(h,V("x"),V("a")), V("a"))
        H, F, i = size(h), size(e), occurrences(e,"x")
        check_ordinary_sizes(e)
        old_boundary = min(2*F+i+11,F+20)
        new_boundary = F+16
        computations = {n:module_size(m) for n,m in computation_modules(h).items()}
        old_computation = min(computations[n] for n in ("pair","old_g","old_t"))
        new_computation = min(computations[n] for n in ("pair","new_g","new_t"))
        rows.append({"equation": f"R[S^{exponent}(v)](x,a)=a", "H":H,"F":F,"i":i,
            "old_forward_fixed_support":18,"new_chain_fixed_support":28,
            "old_forward_boundary":old_boundary,"old_covered_backward_boundary":F+18,
            "new_chain_boundary":new_boundary,"old_descriptor_module":old_computation,
            "new_descriptor_module":new_computation,
            "old_fixed_plus_boundary":18+old_boundary,
            "new_fixed_plus_boundary":28+new_boundary,
            "old_fixed_boundary_descriptor_total":18+old_boundary+old_computation,
            "new_fixed_boundary_descriptor_total":28+new_boundary+new_computation,
            "boundary_only_saving":old_boundary-new_boundary,
            "single_packet_saving_including_descriptor":
                18+old_boundary+old_computation-28-new_boundary-new_computation})
    return rows


def global_envelope_checks() -> tuple[dict, list[dict]]:
    """Compare entire declared modes; never switch their fixed support for free."""
    for m in range(5,31):
        assert 4*m-10 > 0 and 2*m > 0 and 5*m-22 > 0
    equations = []
    for exponent in (34,35,36):
        h = V("v")
        for _ in range(exponent):
            h = S(h)
        e = Eq(R(h,V("x"),V("a")),V("a"))
        assert relevant(e)
        H,F,i = size(h),size(e),occurrences(e,"x")
        assert F+i >= 9
        b = {name:size(clause) for name,clause in boundary_modules(e).items()}
        # Charge the conservative weak J primitive, not a strong If call
        # paired with the weaker primitive's cheaper definition record.
        probe, witness, target = V("x"), V("b"), V("n")
        covered_j_ast = All("a n", Exists("b", All("x", J(e,
            Imp(Eq(S(probe),witness),FALSE),
            Imp(Eq(probe,witness),Eq(witness,target))))))
        assert size(covered_j_ast) == F+18
        ordinary = check_ordinary_sizes(e)
        c = {name:module_size(module) for name,module in computation_modules(h).items()}
        equations.append({"equation":f"R[S^{exponent}(v)](x,a)=a", "H":H,"F":F,"i":i,
            "old_forward_boundary":min(b["old_j_direct"],b["old_forward"]),
            "old_covered_J_boundary":min(b["old_j_direct"],size(covered_j_ast)),
            "old_ordinary_boundary":min(ordinary.values()),
            "new_K_boundary":b["new_chain"],
            "old_computation":min(c[n] for n in ("pair","old_g","old_t")),
            "new_computation":min(c[n] for n in ("pair","new_g","new_t"))})
    assert [e["H"] for e in equations] == [35,36,37]
    assert [e["F"] for e in equations] == [40,41,42]
    old_c = sum(e["old_computation"] for e in equations)
    new_c = sum(e["new_computation"] for e in equations)
    assert (old_c,new_c) == (318,315)
    mode_data = [
        ("old_forward_J",18,"old_forward_boundary",old_c),
        ("old_covered_J",28,"old_covered_J_boundary",old_c),
        ("old_ordinary_native",6,"old_ordinary_boundary",old_c),
        ("new_chain_K",28,"new_K_boundary",new_c),
    ]
    rows = []
    for name,fixed,column,computation in mode_data:
        boundary = sum(e[column] for e in equations)
        rows.append({"mode":name,"equation_count":3,"fixed_support":fixed,
            "boundary_sum":boundary,"descriptor_computation_sum":computation,
            "total_declared_packet_cost":fixed+boundary+computation})
    totals = {row["mode"]:row["total_declared_packet_cost"] for row in rows}
    assert totals == {"old_forward_J":519,"old_covered_J":523,
                      "old_ordinary_native":537,"new_chain_K":514}
    old_minimum = min(totals[name] for name in totals if name.startswith("old_"))
    saving = old_minimum-totals["new_chain_K"]
    assert saving == 5
    return ({"eligible_workload_condition":"m>=5 relevant equations, each F+i>=9",
        "sufficient_recurring_plus_fixed_saving_bounds":{
            "versus_forward_J":"4*m-10","versus_covered_J":"2*m",
            "versus_ordinary_native":"at least 5*m-22"},
        "additional_computation_savings_are_nonnegative":True,
        "bounds_checked_for_m":list(range(5,31)),
        "three_module_example":{
            "equations":equations,"mode_totals":totals,
            "old_computation_sum":old_c,"new_computation_sum":new_c,
            "old_mode_minimum":old_minimum,"saving_below_old_minimum":saving,
            "scope":"Same three equations and complete computation modules of their descriptors. Each mode pays its own fixed arithmetic and logical-definition support. Additional common background, if required for a proof workload, is to be charged equally; these finite packets are not individually claimed to axiomatize PRA."},
        "csv_file":"envelope_packet_metrics.csv"},rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    results = {"status":"PASS", "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "verification_scope":"Finite syntax and semantic checks supplement the written proofs; no full PRA formalization is claimed.",
        "syntax":syntax_checks(), "propositional":propositional_checks(),
        "finite_computation_models":finite_computation_checks(), "scan":scan_checks()}
    rows = metrics_rows()
    with (out/"metrics.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    results["global_envelope"], packet_rows = global_envelope_checks()
    with (out/"envelope_packet_metrics.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(packet_rows[0]))
        writer.writeheader()
        writer.writerows(packet_rows)
    results["metrics"] = {"file":"metrics.csv", "rows":len(rows),
        "scope":"Literal common-equation workloads. Fixed supports18/28 include one logical-definition record. Descriptor columns add this named recursor's complete module. Additional common bootstrap computation support is omitted equally, not asserted absent.",
        "single_equation_packets_are_not_uniformly_smaller":True,
        "large_boundary_packet_saving_excluding_computation":{
            str(k):4*k-10 for k in range(1,7)}}
    assert results["metrics"]["large_boundary_packet_saving_excluding_computation"]["1"] == -6
    assert results["metrics"]["large_boundary_packet_saving_excluding_computation"]["3"] == 2
    (out/"check_results.json").write_text(json.dumps(results, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"status":"PASS", "source_sha256":results["source_sha256"],
                     "descriptors":results["syntax"]["descriptor_count"],
                     "equations":results["syntax"]["equations_checked"],
                     "relevant_equations":results["syntax"]["relevant_equations"],
                     "finite_computation_structures":results["finite_computation_models"]["all_structures_by_carrier_size"],
                     "scan_patterns":results["scan"]["Boolean_patterns"],
                     "packet_totals":results["global_envelope"]["three_module_example"]["mode_totals"],
                     "results":str(out/"check_results.json"), "metrics":str(out/"metrics.csv")}, indent=2))


if __name__ == "__main__":
    main()
