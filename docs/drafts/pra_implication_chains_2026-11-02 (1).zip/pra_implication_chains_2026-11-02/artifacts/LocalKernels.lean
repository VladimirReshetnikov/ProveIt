/-
  Local constructive kernels for PRA with implication chains.

  Lean 4.19.0, core library only.  No Mathlib and no admitted declarations.

  Scope: generic computation-module equivalences; the predecessor-boundary
  induction deduction; a decidable Nat scan with its quantifier-free-shaped
  invariant; and the successor-chain cases omitted by the syntactic filter.
  This file does not formalize the full arithmetic compiler, the syntactic
  classification lemma, or the first-order bi-interpretation metatheorem.
-/

namespace PRAImplicationChains

def Chain (P Q R : Prop) : Prop := (P → Q) ∧ (Q → R)

section Computation

variable {A : Type} (zero : A) (succ : A → A)
variable (F : A → A → A) (h : A → A → A)

def Equations : Prop :=
  (∀ a, F zero a = a) ∧
  (∀ a n, F (succ n) a = h (F n a) n)

def CurrentChain : Prop :=
  ∀ a n u, Chain (n = zero ∧ u = a)
    (F n a = u) (F (succ n) a = h u n)

def EndpointChain : Prop :=
  ∀ a n, ∃ u,
    (n = zero → u = a) ∧
    (∀ x y, Chain (x = n ∧ y = u) (F x a = y)
      (x = succ n → y = h u n))

theorem equations_iff_currentChain :
    Equations zero succ F h ↔ CurrentChain zero succ F h := by
  constructor
  · rintro ⟨base, step⟩ a n u
    constructor
    · rintro ⟨hn, hu⟩
      subst n
      subst u
      exact base a
    · intro hu
      exact (step a n).trans (congrArg (fun v => h v n) hu)
  · intro graph
    constructor
    · intro a
      exact (graph a zero a).1 ⟨rfl, rfl⟩
    · intro a n
      exact (graph a n (F n a)).2 rfl

theorem equations_iff_endpointChain :
    Equations zero succ F h ↔ EndpointChain zero succ F h := by
  constructor
  · rintro ⟨base, step⟩ a n
    refine ⟨F n a, ?_, ?_⟩
    · intro hn
      subst n
      exact base a
    · intro x y
      constructor
      · rintro ⟨hx, hy⟩
        subst x
        exact hy.symm
      · intro hy hx
        subst x
        exact hy.symm.trans (step a n)
  · intro graph
    constructor
    · intro a
      obtain ⟨u, base, endpoints⟩ := graph a zero
      have current : F zero a = u :=
        (endpoints zero u).1 ⟨rfl, rfl⟩
      exact current.trans (base rfl)
    · intro a n
      obtain ⟨u, base, endpoints⟩ := graph a n
      have current : F n a = u :=
        (endpoints n u).1 ⟨rfl, rfl⟩
      have next : F (succ n) a = h u n :=
        (endpoints (succ n) (F (succ n) a)).2 rfl rfl
      exact next.trans (congrArg (fun v => h v n) current.symm)

end Computation

section Boundary

variable {A : Type} (zero : A) (succ : A → A)

def PredecessorBoundary (P : A → Prop) (n b : A) : Prop :=
  ∀ x, Chain (succ x = b) (P x) (x = b → b = n)

theorem predecessor_boundary_induction
    (coverage : ∀ b, b = zero ∨ ∃ x, b = succ x)
    (P : A → Prop) (base : P zero)
    (step : ∀ x, P x → P (succ x))
    (n b : A) (boundary : PredecessorBoundary succ P n b) : P n := by
  have pb : P b := by
    rcases coverage b with h | ⟨x, hx⟩
    · simpa only [h] using base
    · have px : P x := (boundary x).1 hx.symm
      simpa only [hx] using step x px
  have hbn : b = n := (boundary b).2 pb rfl
  simpa only [hbn] using pb

theorem predecessor_scheme_induction
    (coverage : ∀ b, b = zero ∨ ∃ x, b = succ x)
    (P : A → Prop)
    (scheme : ∀ n, ∃ b, PredecessorBoundary succ P n b)
    (base : P zero) (step : ∀ x, P x → P (succ x)) : ∀ n, P n := by
  intro n
  obtain ⟨b, hb⟩ := scheme n
  exact predecessor_boundary_induction zero succ coverage P base step n b hb

end Boundary

section NatScan

variable (P : Nat → Prop) [DecidablePred P]

def scan : Nat → Nat
  | 0 => 0
  | Nat.succ n =>
      if P (scan n) then Nat.succ (scan n) else scan n

/- If P is a quantifier-free arithmetic formula, this displayed invariant
   is quantifier-free as well.  The universally quantified predecessor
   conclusion is derived only after the induction has been completed. -/
def ScanInvariant (n b : Nat) : Prop :=
  (b = 0 ∨ P (Nat.pred b)) ∧ (P b → b = n)

theorem scan_invariant : ∀ n, ScanInvariant P n (scan P n) := by
  intro n
  induction n with
  | zero =>
      exact ⟨Or.inl rfl, fun _ => rfl⟩
  | succ n ih =>
      unfold ScanInvariant at ih ⊢
      simp only [scan]
      by_cases hp : P (scan P n)
      · rw [if_pos hp]
        constructor
        · exact Or.inr hp
        · intro _
          exact congrArg Nat.succ (ih.2 hp)
      · rw [if_neg hp]
        exact ⟨ih.1, fun hb => False.elim (hp hb)⟩

omit [DecidablePred P] in
theorem invariant_to_boundary (n b : Nat)
    (inv : ScanInvariant P n b) : PredecessorBoundary Nat.succ P n b := by
  intro x
  constructor
  · intro hx
    rcases inv.1 with hz | hp
    · exact Nat.noConfusion (hx.trans hz)
    · have hbpred : Nat.pred b = x := (congrArg Nat.pred hx).symm
      exact hbpred ▸ hp
  · intro px hxb
    exact inv.2 (hxb ▸ px)

theorem scan_boundary (n : Nat) :
    PredecessorBoundary Nat.succ P n (scan P n) :=
  invariant_to_boundary P n (scan P n) (scan_invariant P n)

theorem nat_predecessor_scheme :
    ∀ n, ∃ b, PredecessorBoundary Nat.succ P n b := by
  intro n
  exact ⟨scan P n, scan_boundary P n⟩

end NatScan

section SuccessorChains

variable {A : Type} (zero : A) (succ : A → A)

theorem successor_axioms_of_projection
    (Q : A → A → A)
    (sep : zero ≠ succ zero)
    (base : ∀ a, Q zero a = a)
    (step : ∀ n a, Q (succ n) a = n) :
    (∀ x y, succ x = succ y → x = y) ∧
      (∀ x, succ x ≠ zero) := by
  constructor
  · intro x y hxy
    have hq : Q (succ x) zero = Q (succ y) zero :=
      congrArg (fun z => Q z zero) hxy
    exact (step x zero).symm.trans (hq.trans (step y zero))
  · intro x hx
    have hq : Q (succ x) zero = Q zero zero :=
      congrArg (fun z => Q z zero) hx
    have xz : x = zero :=
      (step x zero).symm.trans (hq.trans (base zero))
    have sz : succ zero = zero := (congrArg succ xz).symm.trans hx
    exact sep sz.symm

def iterSucc (succ : A → A) : Nat → A → A
  | 0, x => x
  | Nat.succ k, x => succ (iterSucc succ k x)

theorem iterSucc_injective
    (inj : ∀ x y, succ x = succ y → x = y) :
    ∀ k x y, iterSucc succ k x = iterSucc succ k y → x = y := by
  intro k
  induction k with
  | zero =>
      intro x y hxy
      exact hxy
  | succ k ih =>
      intro x y hxy
      exact ih x y (inj _ _ hxy)

theorem one_sided_induction
    (sep : zero ≠ succ zero)
    (inj : ∀ x y, succ x = succ y → x = y)
    (k : Nat) (c : A)
    (base : iterSucc succ k zero = c)
    (step : ∀ x, iterSucc succ k x = c → iterSucc succ k (succ x) = c) :
    ∀ n, iterSucc succ k n = c := by
  have h : iterSucc succ k zero = iterSucc succ k (succ zero) :=
    base.trans (step zero base).symm
  have bad : zero = succ zero := iterSucc_injective succ inj k zero (succ zero) h
  exact False.elim (sep bad)

theorem iterSucc_zero_injective
    (inj : ∀ x y, succ x = succ y → x = y)
    (nonzero : ∀ x, succ x ≠ zero) :
    ∀ j k, iterSucc succ j zero = iterSucc succ k zero → j = k := by
  intro j
  induction j with
  | zero =>
      intro k hk
      cases k with
      | zero => rfl
      | succ k =>
          exact False.elim (nonzero _ hk.symm)
  | succ j ih =>
      intro k hk
      cases k with
      | zero =>
          exact False.elim (nonzero _ hk)
      | succ k =>
          exact congrArg Nat.succ (ih k (inj _ _ hk))

theorem two_sided_induction
    (inj : ∀ x y, succ x = succ y → x = y)
    (nonzero : ∀ x, succ x ≠ zero)
    (j k : Nat) (base : iterSucc succ j zero = iterSucc succ k zero) :
    ∀ n, iterSucc succ j n = iterSucc succ k n := by
  have hjk : j = k := iterSucc_zero_injective zero succ inj nonzero j k base
  subst k
  exact fun _ => rfl

end SuccessorChains

#print axioms equations_iff_currentChain
#print axioms equations_iff_endpointChain
#print axioms predecessor_boundary_induction
#print axioms predecessor_scheme_induction
#print axioms scan_invariant
#print axioms invariant_to_boundary
#print axioms scan_boundary
#print axioms nat_predecessor_scheme
#print axioms successor_axioms_of_projection
#print axioms iterSucc_injective
#print axioms one_sided_induction
#print axioms iterSucc_zero_injective
#print axioms two_sided_induction

end PRAImplicationChains
