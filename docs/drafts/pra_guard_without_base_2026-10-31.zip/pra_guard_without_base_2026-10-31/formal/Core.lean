/-
Copyright (c) 2026. Research artifact for Vladimir Reshetnikov.

Scope: a schematic metatheorem for the A0 arithmetic kernel. This file proves
constructor separation, successor injectivity, predecessor coverage, and the
direct equation-induction reduction on an arbitrary carrier. It uses neither
the natural-number type nor any natural-number induction principle.

The hypothesis `basis` packages a family of A0 instances using Lean functions.
It is NOT proposed as a second-order axiom of PRA. The proof uses only the
instances (f(n), g(n)) = (n, p(n)) and (S(s(n)), t(n)); these correspond to
legal term substitutions in the first-order schema. Fixed numerical parameters
can be held in the surrounding Lean context. Syntax, the iteration-language
compiler, native equality reflection, and conservativity are not formalized
here. The mathematical paper proves those remaining results separately.
-/

import Init

namespace PRAKernel

universe u

/-- One instance of the proposed guarded-successor schema A0. -/
def GuardedSuccessor {Carrier : Type u}
    (zero : Carrier) (succ : Carrier → Carrier)
    (f g : Carrier → Carrier) : Prop :=
  (∀ n, (n = zero ∨ f n = succ (g n)) →
      f (succ n) = succ (g (succ n))) →
    (zero ≠ succ (g zero)) ∧ ∀ n, n = zero ∨ f n = succ (g n)

/-- Constructor properties obtained from one designated A0 instance. -/
structure ConstructorFacts {Carrier : Type u}
    (zero : Carrier) (succ pred : Carrier → Carrier) : Prop where
  separation : zero ≠ succ zero
  successorNeZero : ∀ n, succ n ≠ zero
  successorInjective : ∀ x y, succ x = succ y → x = y
  coverage : ∀ n, n = zero ∨ n = succ (pred n)

/-- Only the instance f(n) = n, g(n) = p(n) is needed for constructor facts. -/
theorem extractConstructors {Carrier : Type u}
    (zero : Carrier) (succ pred : Carrier → Carrier)
    (predZero : pred zero = zero)
    (predSucc : ∀ n, pred (succ n) = n)
    (identityInstance : GuardedSuccessor zero succ (fun n => n) pred) :
    ConstructorFacts zero succ pred := by
  have guardedStep : ∀ n,
      (n = zero ∨ n = succ (pred n)) →
        succ n = succ (pred (succ n)) := by
    intro n _
    rw [predSucc n]
  have conclusion := identityInstance guardedStep
  have separation : zero ≠ succ zero := by
    simpa only [predZero] using conclusion.1
  have successorInjective : ∀ x y, succ x = succ y → x = y := by
    intro x y equality
    have predecessorEquality := congrArg pred equality
    simpa only [predSucc] using predecessorEquality
  have successorNeZero : ∀ n, succ n ≠ zero := by
    intro n equality
    have predecessorEquality := congrArg pred equality
    have atZero : n = zero := by
      simpa only [predSucc, predZero] using predecessorEquality
    have contradiction : succ zero = zero := by
      simpa only [atZero] using equality
    exact separation contradiction.symm
  exact ⟨separation, successorNeZero, successorInjective, conclusion.2⟩

/-- Direct equation induction; no padded descriptions or equality test occur. -/
theorem equationInductionFromInstance {Carrier : Type u}
    (zero : Carrier) (succ : Carrier → Carrier)
    (successorInjective : ∀ x y, succ x = succ y → x = y)
    (s t : Carrier → Carrier)
    (liftedInstance : GuardedSuccessor zero succ (fun n => succ (s n)) t)
    (base : s zero = t zero)
    (step : ∀ n, s n = t n → s (succ n) = t (succ n)) :
    ∀ n, s n = t n := by
  have guardedStep : ∀ n,
      (n = zero ∨ succ (s n) = succ (t n)) →
        succ (s (succ n)) = succ (t (succ n)) := by
    intro n guardHypothesis
    have current : s n = t n := by
      cases guardHypothesis with
      | inl atZero => simpa only [atZero] using base
      | inr equality => exact successorInjective (s n) (t n) equality
    exact congrArg succ (step n current)
  have conclusion := liftedInstance guardedStep
  intro n
  cases conclusion.2 n with
  | inl atZero => simpa only [atZero] using base
  | inr equality => exact successorInjective (s n) (t n) equality

/-- Uniform statement, with A0 packaged as a metalevel family of instances. -/
theorem equationInduction {Carrier : Type u}
    (zero : Carrier) (succ pred : Carrier → Carrier)
    (predZero : pred zero = zero)
    (predSucc : ∀ n, pred (succ n) = n)
    (basis : ∀ f g : Carrier → Carrier, GuardedSuccessor zero succ f g)
    (s t : Carrier → Carrier)
    (base : s zero = t zero)
    (step : ∀ n, s n = t n → s (succ n) = t (succ n)) :
    ∀ n, s n = t n := by
  have constructors := extractConstructors zero succ pred predZero predSucc
    (basis (fun n => n) pred)
  exact equationInductionFromInstance zero succ constructors.successorInjective
    s t (basis (fun n => succ (s n)) t) base step

/-- The guard has an automatic zero base. -/
theorem guardBase {Carrier : Type u}
    (zero : Carrier) (succ : Carrier → Carrier)
    (f g : Carrier → Carrier) :
    zero = zero ∨ f zero = succ (g zero) :=
  Or.inl rfl

/-- PRA's induction for the positive guard suffices for an A0 instance. -/
theorem guardedSuccessorFromInduction {Carrier : Type u}
    (zero : Carrier) (succ : Carrier → Carrier)
    (successorNeZero : ∀ n, succ n ≠ zero)
    (f g : Carrier → Carrier)
    (guardInduction :
      (zero = zero ∨ f zero = succ (g zero)) →
      (∀ n, (n = zero ∨ f n = succ (g n)) →
        (succ n = zero ∨ f (succ n) = succ (g (succ n)))) →
      ∀ n, n = zero ∨ f n = succ (g n)) :
    GuardedSuccessor zero succ f g := by
  intro step
  have separation : zero ≠ succ (g zero) := by
    intro equality
    exact successorNeZero (g zero) equality.symm
  have positive : ∀ n, n = zero ∨ f n = succ (g n) := by
    apply guardInduction (Or.inl rfl)
    intro n guardHypothesis
    exact Or.inr (step n guardHypothesis)
  exact ⟨separation, positive⟩

end PRAKernel

/- Dependency audit. Each line should report that the theorem has no axioms. -/
#print axioms PRAKernel.extractConstructors
#print axioms PRAKernel.equationInductionFromInstance
#print axioms PRAKernel.equationInduction
#print axioms PRAKernel.guardedSuccessorFromInduction
