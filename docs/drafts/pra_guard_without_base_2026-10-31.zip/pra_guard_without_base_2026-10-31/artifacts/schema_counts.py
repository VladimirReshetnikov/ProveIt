#!/usr/bin/env python3
"""Reproduce the paper's two declared formula-size measures.

This checks syntax counts, not mathematical equivalence or minimality.
Negation is primitive in the skeleton measure and expands to implication
to falsity in the full AST measure. A schematic f/g application is one
function node with all of its numerical arguments as child nodes.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path


def node(tag, *children):
    return (tag, children)


def var(name):
    return node("var:" + name)


ZERO = node("zero")


def succ(t):
    return node("succ", t)


def eq(s, t):
    return node("eq", s, t)


def xor(p, q):
    return node("and", node("or", p, q), node("not", node("and", p, q)))


def forall(name, body):
    return node("forall:" + name, body)


def specifications(parameter_count=1):
    n = var("n")
    parameters = tuple(var("a" + str(i)) for i in range(parameter_count))

    def f(t):
        return node("f", t, *parameters)

    def g(t):
        return node("g", t, *parameters)

    def close(t):
        for i in reversed(range(parameter_count)):
            t = forall("a" + str(i), t)
        return t

    def e(t):
        return eq(f(t), succ(g(t)))

    def guard(t):
        return node("or", eq(t, ZERO), e(t))

    step = forall("n", node("implies", guard(n), e(succ(n))))
    conclusion = node("and", node("not", eq(ZERO, succ(g(ZERO)))),
                      forall("n", guard(n)))
    new = close(node("implies", step, conclusion))
    seeded = close(node("implies", node("and", eq(f(ZERO), ZERO), step),
                        conclusion))
    uniform = close(node("implies", node("and", eq(f(ZERO), ZERO), step),
                         forall("n", xor(eq(n, ZERO), e(n)))))

    def positive(t):
        return node("or", eq(f(t), ZERO), e(t))

    exclusive = close(node(
        "implies",
        node("and", positive(ZERO), forall("n", node(
            "implies", positive(n), positive(succ(n))))),
        forall("n", xor(eq(f(n), ZERO), e(n)))))

    def ordinary_guard(t):
        return node("or", eq(t, ZERO), eq(f(t), g(t)))

    ordinary_step = forall("n", node(
        "implies", ordinary_guard(n), eq(f(succ(n)), g(succ(n)))))
    separate = (close(node("implies", ordinary_step,
                           forall("n", ordinary_guard(n)))),
                node("not", eq(ZERO, succ(ZERO))))
    prescribed = close(node("implies", ordinary_step,
                            forall("n", xor(eq(n, ZERO), eq(f(n), g(n))))))
    return {
        "full_exclusive": (exclusive,),
        "guarded_uniform_exclusive": (uniform,),
        "seeded_factored": (seeded,),
        "present_A": (new,),
        "separate_G_and_separation": separate,
        "prescribed_initial": (prescribed,),
    }


def counts(tree, expand_negation=False):
    tag, children = tree
    if expand_negation and tag == "not":
        return counts(node("implies", children[0], node("bottom")), True)
    result = Counter({tag: 1})
    for child in children:
        result.update(counts(child, expand_negation))
    return result


def report():
    systems = {}
    expected_skeleton = {
        "full_exclusive": (10, 10, 2),
        "guarded_uniform_exclusive": (8, 8, 2),
        "seeded_factored": (7, 7, 2),
        "present_A": (6, 6, 2),
        "separate_G_and_separation": (6, 5, 2),
        "prescribed_initial": (7, 7, 2),
    }
    expected_nodes = {
        "full_exclusive": 82,
        "guarded_uniform_exclusive": 60,
        "seeded_factored": 54,
        "present_A": 48,
        "separate_G_and_separation": 42,
    }
    for name, trees in specifications().items():
        skeleton = Counter()
        expanded = Counter()
        for tree in trees:
            skeleton.update(counts(tree))
            expanded.update(counts(tree, True))
        connectives = sum(skeleton[k] for k in ("and", "or", "implies", "not"))
        skeleton_tuple = (skeleton["eq"], connectives, skeleton["forall:n"])
        assert skeleton_tuple == expected_skeleton[name], (name, skeleton_tuple)
        if name in expected_nodes:
            assert sum(expanded.values()) == expected_nodes[name], name
        systems[name] = {
            "equality_occurrences": skeleton["eq"],
            "connectives_with_primitive_negation": connectives,
            "inner_number_quantifiers": skeleton["forall:n"],
            "arithmetic_templates": len(trees),
            "total_templates_including_computation": len(trees) + 2,
            "full_ast_nodes_one_parameter": sum(expanded.values()),
            "schematic_term_occurrences": skeleton["f"] + skeleton["g"],
            "full_ast_breakdown": dict(sorted(expanded.items())),
        }
    # Check the claimed parameter-dependent formulas independently of the table.
    for k in range(5):
        trees = specifications(k)
        for name, expected in (("present_A", 40 + 8 * k),
                               ("seeded_factored", 45 + 9 * k)):
            assert sum(counts(trees[name][0], True).values()) == expected
    return {
        "scope": "Syntactic audit only; no absolute minimality claim.",
        "skeleton_convention": "Expand XOR, count NOT as one connective; omit "
            "terms, outer parameter closure, and computation equations.",
        "full_ast_convention": "All term/formula nodes count once; NOT expands "
            "to implication and BOTTOM; outer parameter closure included; "
            "computation equations omitted; separate formulas summed.",
        "eligibility_cost": "The prescribed_initial row additionally requires "
            "its bounded computation eligibility rule; not included in nodes.",
        "systems": systems,
        "parameter_formulas": {"present_A": "40+8k", "seeded_factored": "45+9k"},
        "seeded_to_present_reduction": {"nodes": 6, "fraction": "1/9"},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = json.dumps(report(), indent=2) + "\n"
    if args.output:
        args.output.write_text(result, encoding="utf-8")
        print("Schema counts verified: present A has 6 equalities and 48 AST nodes.")
    else:
        print(result, end="")


if __name__ == "__main__":
    main()
