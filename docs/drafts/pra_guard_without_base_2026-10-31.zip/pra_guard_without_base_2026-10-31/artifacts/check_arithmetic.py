#!/usr/bin/env python3
"""Bounded transcription checks for the paper's arithmetic and state compiler.

All arithmetic functions below are built by the restricted counter/state
iteration, not by importing arbitrary primitive recursive definitions.
These finite checks are NOT a proof of the axiom scheme or conservativity.
The exact tested ranges and assertions are reported as JSON.
"""
from __future__ import annotations

import argparse
from functools import lru_cache
import json
from pathlib import Path


def iteration(update):
    """I_h(0,a)=a; I_h(n+1,a)=h(n,I_h(n,a)); update has no seed argument."""
    @lru_cache(maxsize=None)
    def run(n, a):
        if n < 0 or a < 0:
            raise ValueError("Natural-number arguments required")
        state = a
        for counter in range(n):
            state = update(counter, state)
        return state
    return run


predecessor_iteration = iteration(lambda n, r: n)
gate = iteration(lambda n, r: 0)
add = iteration(lambda n, r: r + 1)


def pred(x):
    return predecessor_iteration(x, 0)


def select(z, u, v):
    return add(gate(z, u), gate(gate(z, 1), v))


monus = iteration(lambda n, r: pred(r))


def error(x, y):
    return select(monus(x, y), monus(y, x), 1)


triangle_iteration = iteration(lambda n, r: add(r, n + 1))


def triangle(k):
    return triangle_iteration(k, 0)


rank_iteration = iteration(lambda n, r:
    select(error(n + 1, triangle(r + 1)), r + 1, r))


def rank(z):
    return rank_iteration(z, 0)


def pair(x, y):
    return add(triangle(add(x, y)), y)


def right(z):
    return monus(triangle(rank(z)), z)


def left(z):
    return monus(right(z), rank(z))


def encode(values):
    code = 0
    for value in reversed(values):
        code = pair(value, code)
    return code


def decode(code, count):
    values = []
    for _ in range(count):
        values.append(left(code))
        code = right(code)
    return tuple(values)


def compile_recursion(initial, update, parameter_count):
    """The paper's explicit state construction, returning output and state."""
    def state_step(n, w):
        parameter_code = left(w)
        parameters = decode(parameter_code, parameter_count)
        return pair(parameter_code, update(n, right(w), parameters))
    state_iteration = iteration(state_step)

    def run(n, parameters):
        if len(parameters) != parameter_count:
            raise ValueError("Wrong fixed parameter tuple length")
        code = encode(parameters)
        state = state_iteration(n, pair(code, initial(parameters)))
        return right(state), left(state)
    return run


def check():
    assertions = 0

    def require(condition):
        nonlocal assertions
        assert condition
        assertions += 1

    for x in range(25):
        require(pred(x + 1) == x)
        require(add(x, 0) == x)
        require((x == 0) or x == pred(x) + 1)
        for y in range(25):
            require(add(x, y) == x + y)
            require(monus(x, y) == max(y - x, 0))
            require(monus(x + 1, y + 1) == monus(x, y))
            require(monus(x, add(x, y)) == y)
            require(select(monus(y, x), monus(monus(x, y), y), x) == x)
            require((error(x, y) == 0) == (x == y))

    for k in range(12):
        require(rank(triangle(k)) == k)
        for i in range(k + 1):
            require(rank(add(triangle(k), i)) == k)
    for x in range(10):
        for y in range(10):
            require(left(pair(x, y)) == x)
            require(right(pair(x, y)) == y)

    for a in range(3):
        for b in range(3):
            require(decode(encode((a, b)), 2) == (a, b))

    # The Boolean compiler is checked on all zero/nonzero pairs in this range.
    for e in range(5):
        for f in range(5):
            p, q = e == 0, f == 0
            require((select(e, 1, 0) == 0) == (not p))
            require((select(e, f, 1) == 0) == (p and q))
            require((select(e, 0, f) == 0) == (p or q))
            require((select(e, f, 0) == 0) == ((not p) or q))

    # Source recurrence: F(0,a,b)=a; F(n+1,a,b)=F(n,a,b)+b.
    affine = compile_recursion(lambda p: p[0],
                               lambda n, value, p: add(value, p[1]), 2)
    for a in range(3):
        for b in range(3):
            for n in range(4):
                value, parameter_code = affine(n, (a, b))
                require(value == a + n * b)
                require(parameter_code == encode((a, b)))

    # Source recurrence with no passive parameters: F(0)=0; F(n+1)=F(n)+n+1.
    triangular = compile_recursion(lambda p: 0,
        lambda n, value, p: add(value, n + 1), 0)
    for n in range(7):
        value, parameter_code = triangular(n, ())
        require(value == n * (n + 1) // 2)
        require(parameter_code == 0)

    # Explicit counterexamples to two tempting but invalid textual changes.
    require((0 == 0) and (1 == 0 + 1))  # f=1,g=0: the alternatives overlap.
    product_point = (0, 1)
    product_pred = tuple(pred(x) for x in product_point)
    product_succ_pred = tuple(x + 1 for x in product_pred)
    require(product_point != (0, 0))
    require(product_point != product_succ_pred)

    return {
        "status": "passed",
        "assertions": assertions,
        "scope": "Finite transcription checks only; not a formal proof of PRA.",
        "ranges": {
            "arithmetic_inputs": "0..24 in each coordinate",
            "triangular_intervals": "k=0..11, i=0..k",
            "pairing_retractions": "x,y=0..9",
            "two_parameter_tuples": "a,b=0..2",
            "formula_code_values": "0..4",
            "affine_recursion": "a,b=0..2, n=0..3",
            "parameter_free_triangular_recursion": "n=0..6",
        },
        "counterexamples": {
            "uniform_xor_after_base_deletion": "f=1,g=0 overlap at n=0",
            "positive_coverage_from_negative_conclusion":
                "N^2 with x=(0,1) fails both coverage alternatives",
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = check()
    text = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
        print("Arithmetic and state checks passed: %s assertions." % result["assertions"])
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
