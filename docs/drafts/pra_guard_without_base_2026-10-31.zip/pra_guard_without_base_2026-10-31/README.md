# PRA from guarded induction without a base premise

Prepared for Vladimir Reshetnikov, 31 October 2026.

## Main result

The same arithmetic specification works with classical or intuitionistic
first-order equality logic. Start with 0, successor S, variables, and ordinary
term composition. For each earlier finite term h(n,r), introduce a binary
iteration symbol:

    I_h(0,a)  = a
    I_h(Sn,a) = h(n,I_h(n,a))

The update h has only n,r free. It cannot refer to a passive seed parameter.
For all terms f(n,a),g(n,a) with only n,a free, set E(n,a) := f(n,a)=Sg(n,a).
Add the universal closure in a of:

    [forall n ((n=0 or E(n,a)) -> E(Sn,a))]
      -> [0 != Sg(0,a) and forall n (n=0 or E(n,a))].

There is no premise f(0,a)=0 and no computational eligibility condition.
The paper proves exact conservative definitional equivalence with ordinary
PRA, separately in each logic, including the explicit construction of the
omitted primitive-recursive functions. It also gives the native
quantifier-free contextual rule.

## What is new relative to the reviewed drafts

Compared with the nearest `pra_seeded_guard_2026-10-31.zip` presentation:

- Remove the initial-value equality and its conjunction from the arithmetic
  premise, preserving the same restricted binary iteration grammar, one
  numerical parameter, and three total axiom templates.
- Recover equation induction directly by taking f=S u and g=v. The old
  mask-and-delay construction is unnecessary.
- Establish M(x,x+y)=y before the comparator. Its y=0 and y=1 instances
  replace two separate diagonal inductions, reducing the fixed preparation
  from twelve arithmetic-schema instances to ten.

The arithmetic schema has six equality occurrences instead of seven. Under
the fully specified AST metric it has 48 nodes instead of 54. The older
separate nontriviality plus guarded-induction presentation has 42 nodes and
four total templates; this result is not a global minimum under all metrics.

The source's factored conclusion is essential. After dropping f(0,a)=0, do
not replace its positive disjunction by XOR: f=1,g=0 overlaps at n=0.
The earlier unaugmented one-term proposal remains unresolved.

## Contents

- `pra_guard_without_base.pdf`: complete mathematical paper.
- `pra_guard_without_base.tex`, `sections/*.tex`: all LaTeX sources.
- `formal/Core.lean`: Lean kernel metatheorems on an arbitrary carrier.
- `formal/Core.check.txt`: successful Lean check and dependency audit.
- `lean-toolchain`: pinned Lean 4.19.0 toolchain.
- `artifacts/schema_counts.py`: both formula-size measures.
- `artifacts/check_arithmetic.py`: bounded checks of arithmetic, comparison,
  pairing, Boolean compilation, and representative state translations.
- `audit/source_audit.json`: six-source comparison with immutable URLs and
  hashes at ProveIt commit 1933ee3d1630a43f96bfe16aeb88a8371b52082e.
- `audit/schema_counts.json`, `audit/arithmetic_checks.json`: script outputs.
- `audit/verification.json`: precise validation scope and results.
- `SHA256SUMS`: checksums for all other packaged files.
- `Makefile`: reproducible build and check commands.

## Reproduce

Run from this directory. Python checks require only Python 3's standard
library. The PDF uses a standard TeX Live installation with latexmk and the
packages named at the top of the main source.

    make checks
    make pdf
    make lean

The last command expects Lean 4.19.0 on PATH (or `make lean LEAN=/path/to/lean`).
With elan, the supplied `lean-toolchain` selects the pinned version. No
Mathlib dependency is required.

The PDF build directory is temporary and is not included in the archive.

## Verification scope

Lean 4.19.0 successfully checked four kernel metatheorems, with no axioms in
their dependency audit. Their mathematical hypotheses are explicit theorem
arguments. The file uses an arbitrary type and no natural-number induction;
it proves constructor extraction, direct equation induction, and the
converse reduction. It is a schematic metatheorem, not an encoding of PRA's
syntax or a formal verification of the entire conservativity theorem.

The Python arithmetic checks passed 4,313 finite assertions in the ranges
recorded in their output. They detect transcription errors and do not prove
universal arithmetical statements. The full equality-reflection, pairing,
translation, and conservativity proofs are in the paper. No absolute
minimality or historical-priority theorem is claimed.

The source archive inventory and incoming index were inspected. No source
ZIP is duplicated in this package, and no repository write is needed to use
the results.
