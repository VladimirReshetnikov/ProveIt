"""Finite numerical diagnostics for the closed equational reconstruction.

This is not a proof checker and does not mechanize Boolean gluing, induction,
or the interpretation theorem.  The literal group expands the inherited
closed-term syntax.  The accelerated group uses explicitly labelled ordinary
integer arithmetic for derived operations.
"""
import hashlib
import json
from pathlib import Path

import closed_terms as c


def iterate(function, count, initial):
    value = initial
    for _ in range(count):
        value = function(value)
    return value


# Accelerated ordinary-natural-number interpretations, not kernel primitives.
def choose(n, a, b):
    return a if n == 0 else b


def zero_test(n):
    return int(n == 0)


def j(n):
    return zero_test(n) + 2 * (n % 2)


def factor(n):
    return 3 * (n // 2) if n % 2 == 0 else n


def clock(n):
    return choose(n % 3, choose(n % 2, factor(n), 1), n + 3)


def collapse(n):
    return choose(n % 3, 3 * n, n)


def ramp(n):
    return iterate(lambda u: u + 1 + int(u % 4 == 2), n, 0)


def trajectory(t, n):
    return iterate(clock, t, 3 * 2 ** n)


def a_clock(n):
    return trajectory(ramp(n), n)


def predecessor(n):
    a = a_clock(n)
    return choose(a % 3, int(n % 3 == 2), a + n % 3 + 1)


def pair(x, y):
    return iterate(lambda u: 2 * u, x, 2 * y + 1)


def halver(n):
    return choose(n % 2, n // 2, n)


def tagged_halver(n):
    half = n // 2
    return choose(n % 2, choose(half % 2, 2 * (half // 2), 1), n + 2)


def right_projection(n):
    return iterate(halver, n, n) // 2


def left_projection(n):
    return max(0, n - iterate(tagged_halver, n + 1, 2 * n) // 2)


def main():
    counts = {}

    def check(group, value):
        if not value:
            raise AssertionError(group)
        counts[group] = counts.get(group, 0) + 1

    audit = c.audit()
    # One forbidden ambient variable and one reference to a later declaration.
    rejected = []
    for name, term in [
        ('ambient_variable', c.var(1)),
        ('future_update', ('iter', 'not_yet_declared', c.zero(), c.zero())),
    ]:
        try:
            c.validate(term, 1, set(c.UPDATES))
        except ValueError:
            rejected.append(name)
        else:
            raise AssertionError('A malformed closed update was admitted')

    literal = []
    for n in range(9):
        value = c.evaluate(c.P(c.numeral(n)))
        check('literal_predecessor', value == max(0, n - 1))
        literal.append({'input': n, 'output': value})

    for n in range(25):
        m = n % 3
        w = j(j(m))
        check('accelerated_three_cycle_selector', m == choose(zero_test(w), 2 * (w % 2), 1))
        check('accelerated_ramp_invariant', ramp(n) % 4 == m)
        check('accelerated_ramp_step', ramp(n + 1) == ramp(n) + 1 + int(m == 2))
        check('accelerated_ramp_period', ramp(n + 3) == ramp(n) + 4)
        value = a_clock(n + 3)
        check('accelerated_clock_residue', value % 3 == 1)
        check('accelerated_clock_value', value + m == n + 1)
        check('accelerated_predecessor', predecessor(n) == max(0, n - 1))

    for n in range(100):
        check('accelerated_commutation', clock(collapse(n)) == collapse(clock(n)))
    for n in range(9):
        for t in range(13):
            check('accelerated_diagonal_shift', trajectory(t + 1, n + 1) == collapse(trajectory(t, n)))

    for x in range(5):
        for y in range(6):
            z = pair(x, y)
            r = max(0, z - (x + 1))
            next_z = pair(x + 1, y)
            check('accelerated_slack_invariant', z == x + 1 + r)
            check('accelerated_slack_successor', next_z == x + 2 + x + 2 * r)
            check('accelerated_slack_residual', max(0, next_z - (x + 2)) == x + 2 * r)
            check('accelerated_halver_trajectory', iterate(halver, x, z) == 2 * y + 1)
            check('accelerated_tagged_trajectory', iterate(tagged_halver, x + 1, 2 * z) == 1)
            check('accelerated_left_projection', left_projection(z) == x)
            check('accelerated_right_projection', right_projection(z) == y)

    result = {
        'status': 'PASS',
        'scope': 'finite diagnostics, not formal verification or a proof checker',
        'closed_terms_sha256': hashlib.sha256(Path(c.__file__).read_bytes()).hexdigest(),
        'closed_update_audit': audit,
        'malformed_definitions_rejected': rejected,
        'literal_predecessor': literal,
        'checks_by_group': counts,
        'accelerated_reference_operations': [
            'zero testing and selection use ordinary Python conditionals',
            'parity and cycles use integer remainders',
            'the factor map and halving use integer division',
            'powers of two and monus use ordinary Python arithmetic',
            'R, T, V, A, P and both pairing projections retain their displayed iteration formulas',
        ],
        'not_checked': [
            'the Boolean-gluing proof transformation',
            'universal validity of the induction arguments',
            'the full primitive-recursion compiler or interpretation composites',
            'a complete proof-certificate checker or a new checker-size record',
        ],
    }
    destination = Path(__file__).with_name('diagnostics.json')
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'closed_updates': len(audit),
                      'checks_by_group': counts, 'receipt': destination.name}, indent=2))


if __name__ == '__main__':
    main()
