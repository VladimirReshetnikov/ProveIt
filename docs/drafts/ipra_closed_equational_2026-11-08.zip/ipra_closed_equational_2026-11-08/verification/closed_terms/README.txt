CLOSED-TERM DIAGNOSTICS
======================

Run with Python 3.10 or newer, using only the standard library:

    python3 validate.py

The driver writes diagnostics.json next to itself.  The literal group
evaluates the fully expanded staged closed-term predecessor at 0 through 8.
The closedness/staging audit checks every update description and rejects
representative references to an outer variable or a future declaration.

The accelerated groups evaluate displayed clock, slack and pairing equations
over small finite grids.  Their ordinary Python remainder, division, zero
test, powers and truncated subtraction are reference accelerations, not
primitives of the proposed equational theory.  This distinction is recorded
in the receipt.  The functions R, T, V, A, P and both pairing projections
retain the iteration formulas given in the report.

These programs are numerical and syntactic diagnostics.  They are not a
proof checker and do not formally verify gluing, induction, the compiler or
bi-interpretability.  Universal statements are justified by the written
equational proofs in the report.  See ATTRIBUTION.txt and LICENSE.txt for the
provenance of the unchanged inherited evaluator.
