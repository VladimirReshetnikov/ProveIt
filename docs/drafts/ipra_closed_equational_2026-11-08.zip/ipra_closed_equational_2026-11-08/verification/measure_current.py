#!/usr/bin/env python3
"""Reproduce the complete current six-archive program comparison offline."""
from pathlib import Path
import hashlib
import json
import platform
from measure_inherited import metrics, FIELDS

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "provenance/current_programs.json").read_text())
rows = []
for entry in manifest["programs"]:
    path = root / entry["path"]
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != entry["sha256"]:
        raise ValueError("Changed comparison source: " + entry["path"])
    rows.append({**entry, **metrics(raw)})
assert len(rows) == 15 and len({r["sha256"] for r in rows}) == 15
complete = [r for r in rows if r["status"] == "inherited_complete_program"]
assert len(complete) == 12
result = {
    "current_snapshot": manifest["current_snapshot"],
    "inherited_snapshot": manifest["inherited_snapshot"],
    "python": platform.python_version(),
    "current_archives": 6,
    "distinct_programs": len(rows),
    "inherited_complete_programs": len(complete),
    "experiments": len(rows) - len(complete),
    "complete_minima": {k: min(r[k] for r in complete) for k in FIELDS},
    "all_program_minima": {k: min(r[k] for r in rows) for k in FIELDS},
    "programs": rows,
    "scope": "All measured source is retained. Experiments are not certified complete checkers. No new record is claimed.",
}
(root / "results/current_measurements.json").write_text(json.dumps(result, indent=2) + "\n")
names = {
    "ipra_kernels_and_initializer_obstruction_2026-11-08": "initializer kernel",
    "ipra_boolean_core_2026-11-08": "Boolean core",
    "ipra_boxed_witnesses_2026-11-08": "boxed witnesses",
    "ipra_clausal_kernel_2026-11-08": "clausal kernel",
    "ipra_context_blocks_2026-11-08": "context blocks",
    "ipra_context_pairs_2026-11-08": "context pairs",
    "ipra_fixed_contexts_2026-11-08": "fixed contexts",
    "ipra_normalized_elimination_2026-11-08": "normalized elimination",
}
lines = [r"\begin{center}", r"\small", r"\begin{tabular}{@{}lrrr@{}}",
         r"\toprule", r"Program & Tokens & AST & Bytes\\", r"\midrule"]
for row in rows:
    path = Path(row["path"])
    if row["status"] == "inherited_complete_program":
        label = names[path.parts[2]]
        suffix = path.stem.removeprefix("checker").replace("_", " ").strip()
        if suffix:
            label += " / " + suffix
    else:
        label = path.stem.replace("_", " ")
    lines.append(f"{label} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}" + r"\\")
    if row is complete[-1]:
        lines.append(r"\midrule")
lines += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
(root / "results/current_table.tex").write_text("\n".join(lines) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "programs"}, indent=2))
