"""Run replay, targeted corrupted-certificate diagnostics, and save a receipt."""
import copy
import hashlib
import json
import platform
from pathlib import Path

import checker


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def find_theorem(certificate, name):
    return next(t for t in certificate["theorems"] if t["name"] == name)


def main():
    here = Path(__file__).resolve().parent
    dependencies = json.loads((here / "dependencies.json").read_text())
    certificate = json.loads((here / "certificate.json").read_text())
    positive = checker.verify(dependencies, certificate)
    negatives = []

    damaged = copy.deepcopy(certificate)
    node = find_theorem(damaged, "pairing_slack")["proof"]["nodes"][0]
    node["eigenvariable"] = "y"
    negatives.append(("captured_induction_parameter", damaged))

    damaged = copy.deepcopy(certificate)
    node = find_theorem(damaged, "pairing_slack")["proof"]["nodes"][0]
    node["step"]["nodes"][0]["steps"][1]["path"] = [1, 0]
    negatives.append(("wrong_growth_rewrite_occurrence", damaged))

    damaged = copy.deepcopy(certificate)
    node = find_theorem(damaged, "monus_cancellation")["proof"]["nodes"][0]
    node["step"] = copy.deepcopy(node["base"])
    negatives.append(("base_reused_as_induction_step", damaged))

    damaged = copy.deepcopy(certificate)
    find_theorem(damaged, "first_projection")["equation"][1] = "y"
    negatives.append(("incorrect_projection_conclusion", damaged))

    damaged = copy.deepcopy(certificate)
    step = find_theorem(damaged, "first_projection")["proof"]["nodes"][0]["steps"][4]
    step["source"] = "axiom:undeclared_trajectory"
    negatives.append(("undeclared_mathematical_dependency", damaged))

    negative_results = []
    for name, damaged in negatives:
        try:
            checker.verify(dependencies, damaged)
        except (checker.Rejected, KeyError, TypeError, ValueError, IndexError) as error:
            negative_results.append({"name": name, "status": "REJECT", "reason": str(error)})
        else:
            raise AssertionError("corrupted certificate accepted: " + name)

    receipt = {"format": "closed-equational-replay-receipt-v1", "python": platform.python_version(),
               "positive": positive, "negative_diagnostics": negative_results,
               "checked_files_sha256": {name: digest(here / name) for name in
                  ["checker.py", "produce.py", "dependencies.json", "certificate.json", "verify.py"]},
               "scope": "Symbolic equation proofs replayed relative to the exact 24 equations in dependencies.json. The checker proves neither these trusted equations nor the whole iPRA bi-interpretation. This is not a complete iPRA proof checker or a size-record candidate."}
    (here / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
