"""Produce explicit symbolic proofs.  The separate checker imports none of this.

There is no implicit algebraic normalization in the output: every rewriting
operation below records its equality source, full schema substitution,
orientation, and occurrence path.  The producer may calculate intermediate
syntax, but the checker independently reconstructs every intermediate term.
"""
import json
from pathlib import Path


def app(name, *arguments):
    return [name, *arguments]


Z = app("0")
S = lambda x: app("S", x)
A = lambda x, y: app("+", x, y)
D = lambda x, y: app("d", x, y)
C = lambda x, y: app("c", x, y)
JP = lambda n, a: app("JP", n, a)
P = lambda x: app("P", x)
G = lambda x: app("G", x)
Q = lambda x: app("q", x)
JH = lambda n, a: app("Jh", n, a)
JF = lambda n, a: app("JF", n, a)
H = lambda x: app("h", x)
F = lambda x: app("F", x)
ONE = S(Z)


def variables(term):
    if isinstance(term, str):
        return {term}
    result = set()
    for child in term[1:]:
        result |= variables(child)
    return result


def subst(term, environment):
    if isinstance(term, str):
        return environment.get(term, term)
    return [term[0], *(subst(child, environment) for child in term[1:])]


signature = {"0": 0, "S": 1, "+": 2, "P": 1, "JP": 2,
             "d": 2, "c": 2, "G": 1, "q": 1, "h": 1,
             "F": 1, "Jh": 2, "JF": 2, "pi0": 1, "pi1": 1}
axioms = []
rules = {}
theorems = []


def dependency(name, lhs, rhs, explanation):
    names = sorted(variables(lhs) | variables(rhs))
    axioms.append({"name": name, "variables": names,
                   "equation": [lhs, rhs], "justification": explanation})
    rules["axiom:" + name] = (names, [lhs, rhs])


dependency("add_zero", A("a", Z), "a", "Addition iterator computation at zero.")
dependency("add_successor", A("a", S("b")), S(A("a", "b")), "Addition iterator computation at successor.")
dependency("zero_add", A(Z, "a"), "a", "Earlier literal-equation induction.")
dependency("successor_add", A(S("a"), "b"), S(A("a", "b")), "Earlier literal-equation induction.")
dependency("add_commute", A("a", "b"), A("b", "a"), "Earlier literal-equation induction.")
dependency("add_associate", A(A("a", "b"), "c"), A("a", A("b", "c")), "Earlier literal-equation induction.")
dependency("predecessor_successor", P(S("a")), "a", "Prior closed-update predecessor theorem; its construction is not replayed here.")
dependency("JP_zero", JP(Z, "a"), "a", "Closed iterator computation schema for update P.")
dependency("JP_successor", JP(S("n"), "a"), P(JP("n", "a")), "Closed iterator computation schema for update P.")
dependency("monus_definition", D("a", "b"), JP("b", "a"), "Definitional abbreviation d(a,b)=J_P(b,a).")
dependency("pair_zero", C(Z, "y"), S(A("y", "y")), "Doubler iterator base, using 2y+1=S(2y).")
dependency("pair_successor", C(S("x"), "y"), A(C("x", "y"), C("x", "y")), "Doubler iterator successor equation.")
dependency("ramp_odd", G(S(A("y", "y"))), S(A(A("y", "y"), "y")), "Prior closed ramp equation G(2y+1)=3y+1; not replayed here.")
dependency("half_definition", Q("a"), D(G("a"), "a"), "Definitional abbreviation q(a)=d(G(a),a).")
for name, iterator, update in [("Jh", JH, H), ("JF", JF, F)]:
    dependency(name + "_zero", iterator(Z, "a"), "a", "Closed iterator computation at zero.")
    dependency(name + "_successor", iterator(S("n"), "a"), update(iterator("n", "a")), "Closed iterator computation at successor.")
dependency("halver_trajectory", JH("x", C("x", "y")), S(A("y", "y")), "Prior exact halver trajectory, proved by equation induction from the update endpoint equations.")
dependency("halver_fixed", JH("k", S(A("y", "y"))), S(A("y", "y")), "Prior odd fixed-point trajectory, proved by equation induction.")
dependency("counter_trajectory", JF(S("x"), A(C("x", "y"), C("x", "y"))), ONE, "Prior exact tagged-counter trajectory, proved by equation induction.")
dependency("counter_run", JF("k", ONE), S(A("k", "k")), "Prior counting trajectory, proved by equation induction.")
dependency("pi1_definition", app("pi1", "z"), Q(JH("z", "z")), "Definition of the second projection.")
dependency("pi0_definition", app("pi0", "z"), D("z", Q(JF(S("z"), A("z", "z")))), "Definition of the first projection.")


def edit(term, path, old, new):
    if not path:
        assert term == old, (term, old)
        return new
    result = list(term)
    result[path[0] + 1] = edit(result[path[0] + 1], path[1:], old, new)
    return result


class Proof:
    def __init__(self, hypotheses=None):
        self.nodes = []
        self.local = {}
        self.hypotheses = hypotheses or {}

    def chain(self, name, term):
        node = {"id": name, "kind": "chain", "start": term, "steps": []}
        self.nodes.append(node)
        self.local[name] = [term, term]
        return Chain(self, node)

    def symmetric(self, name, source):
        self.nodes.append({"id": name, "kind": "symmetry", "proof": source})
        self.local[name] = list(reversed(self.local[source]))
        return name

    def transitive(self, name, first, second):
        a, b = self.local[first], self.local[second]
        assert a[1] == b[0], (a[1], b[0])
        self.nodes.append({"id": name, "kind": "transitivity", "left": first, "right": second})
        self.local[name] = [a[0], b[1]]
        return name

    def join(self, left, right, name="joined"):
        rev = self.symmetric(name + "_reverse", right)
        return self.transitive(name, left, rev)

    def finish(self, name):
        return {"nodes": self.nodes, "conclusion": name}


class Chain:
    def __init__(self, proof, node):
        self.proof, self.node = proof, node

    def rw(self, source, environment=None, path=(), reverse=False):
        environment = environment or {}
        if source.startswith("local:"):
            equation = self.proof.local[source.split(":", 1)[1]]
        elif source.startswith("hypothesis:"):
            equation = self.proof.hypotheses[source.split(":", 1)[1]]
        else:
            names, equation = rules[source]
            assert set(names) == set(environment), (source, names, environment)
            equation = [subst(t, environment) for t in equation]
        if reverse:
            equation = list(reversed(equation))
        current = self.proof.local[self.node["id"]][1]
        current = edit(current, list(path), *equation)
        self.proof.local[self.node["id"]][1] = current
        self.node["steps"].append({"source": source, "environment": environment,
                                   "path": list(path), "reverse": reverse})
        return self


def theorem(name, names, equation, proof):
    theorems.append({"name": name, "variables": names, "equation": equation, "proof": proof})
    rules["theorem:" + name] = (names, equation)


def induction(name, names, variable, equation, base_builder, step_builder):
    eigen = "i"
    assert eigen not in names
    base_goal = [subst(t, {variable: Z}) for t in equation]
    hypothesis = [subst(t, {variable: eigen}) for t in equation]
    step_goal = [subst(t, {variable: S(eigen)}) for t in equation]
    base, step = Proof(), Proof({"IH": hypothesis})
    base_result = base_builder(base, base_goal)
    step_result = step_builder(step, step_goal)
    assert base.local[base_result] == base_goal
    assert step.local[step_result] == step_goal
    proof = {"nodes": [{"id": "induction", "kind": "induction", "variable": variable,
                        "eigenvariable": eigen, "hypothesis": "IH", "equation": equation,
                        "base": base.finish(base_result), "step": step.finish(step_result)}],
             "conclusion": "induction"}
    theorem(name, names, equation, proof)


def rotation_base(p, goal):
    p.chain("left", goal[0]).rw("axiom:JP_successor", {"n": Z, "a": "a"}).rw("axiom:JP_zero", {"a": "a"}, [0])
    p.chain("right", goal[1]).rw("axiom:JP_zero", {"a": P("a")})
    return p.join("left", "right")


def rotation_step(p, goal):
    p.chain("left", goal[0]).rw("axiom:JP_successor", {"n": S("i"), "a": "a"}).rw("hypothesis:IH", path=[0])
    p.chain("right", goal[1]).rw("axiom:JP_successor", {"n": "i", "a": P("a")})
    return p.join("left", "right")


induction("predecessor_rotation", ["n", "a"], "n", [JP(S("n"), "a"), JP("n", P("a"))], rotation_base, rotation_step)

p = Proof()
p.chain("proof", D("a", Z)).rw("axiom:monus_definition", {"a": "a", "b": Z}).rw("axiom:JP_zero", {"a": "a"})
theorem("monus_zero", ["a"], [D("a", Z), "a"], p.finish("proof"))

p = Proof()
p.chain("proof", D(S("a"), S("b"))).rw("axiom:monus_definition", {"a": S("a"), "b": S("b")}).rw("theorem:predecessor_rotation", {"n": "b", "a": S("a")}).rw("axiom:predecessor_successor", {"a": "a"}, [1]).rw("axiom:monus_definition", {"a": "a", "b": "b"}, reverse=True)
theorem("monus_successors", ["a", "b"], [D(S("a"), S("b")), D("a", "b")], p.finish("proof"))


def cancel_base(p, goal):
    p.chain("proof", goal[0]).rw("axiom:zero_add", {"a": "b"}, [0]).rw("theorem:monus_zero", {"a": "b"})
    return "proof"


def cancel_step(p, goal):
    p.chain("proof", goal[0]).rw("axiom:successor_add", {"a": "i", "b": "b"}, [0]).rw("theorem:monus_successors", {"a": A("i", "b"), "b": "i"}).rw("hypothesis:IH")
    return "proof"


induction("monus_cancellation", ["a", "b"], "a", [D(A("a", "b"), "a"), "b"], cancel_base, cancel_step)


def slack_base(p, goal):
    yy = A("y", "y")
    p.chain("left", goal[0]).rw("axiom:pair_zero", {"y": "y"})
    p.chain("right", goal[1]).rw("axiom:pair_zero", {"y": "y"}, [1, 0]).rw("theorem:monus_successors", {"a": yy, "b": Z}, [1]).rw("theorem:monus_zero", {"a": yy}, [1]).rw("axiom:successor_add", {"a": Z, "b": yy}).rw("axiom:zero_add", {"a": yy}, [0])
    return p.join("left", "right")


def slack_step(p, goal):
    i, y = "i", "y"
    ci = C(i, y)
    r = D(ci, S(i))
    rr, tail = A(r, r), A(i, A(r, r))
    left = p.chain("growth_left", C(S(i), y))
    left.rw("axiom:pair_successor", {"x": i, "y": y})
    left.rw("hypothesis:IH", path=[0]).rw("hypothesis:IH", path=[1])
    left.rw("axiom:successor_add", {"a": i, "b": r}, [0]).rw("axiom:successor_add", {"a": i, "b": r}, [1])
    left.rw("axiom:successor_add", {"a": A(i, r), "b": S(A(i, r))})
    left.rw("axiom:add_successor", {"a": A(i, r), "b": A(i, r)}, [0])
    left.rw("axiom:add_associate", {"a": i, "b": r, "c": A(i, r)}, [0, 0])
    left.rw("axiom:add_associate", {"a": r, "b": i, "c": r}, [0, 0, 1], reverse=True)
    left.rw("axiom:add_commute", {"a": r, "b": i}, [0, 0, 1, 0])
    left.rw("axiom:add_associate", {"a": i, "b": r, "c": r}, [0, 0, 1])
    p.chain("growth_right", A(S(S(i)), tail)).rw("axiom:successor_add", {"a": S(i), "b": tail}).rw("axiom:successor_add", {"a": i, "b": tail}, [0])
    p.join("growth_left", "growth_right", "growth")
    p.chain("right", goal[1]).rw("local:growth", path=[1, 0]).rw("theorem:monus_cancellation", {"a": S(S(i)), "b": tail}, [1])
    return p.join("growth", "right", "step")


slack = [C("x", "y"), A(S("x"), D(C("x", "y"), S("x")))]
induction("pairing_slack", ["x", "y"], "x", slack, slack_base, slack_step)

p = Proof()
rxy = D(C("x", "y"), S("x"))
p.chain("proof", C("x", "y")).rw("theorem:pairing_slack", {"x": "x", "y": "y"}).rw("axiom:successor_add", {"a": "x", "b": rxy}).rw("axiom:add_successor", {"a": "x", "b": rxy}, reverse=True)
theorem("clock_slack", ["x", "y"], [C("x", "y"), A("x", S(rxy))], p.finish("proof"))

p = Proof()
yy = A("y", "y")
p.chain("proof", Q(S(yy))).rw("axiom:half_definition", {"a": S(yy)}).rw("axiom:ramp_odd", {"y": "y"}, [0]).rw("theorem:monus_successors", {"a": A(yy, "y"), "b": yy}).rw("theorem:monus_cancellation", {"a": yy, "b": "y"})
theorem("half_odd", ["y"], [Q(S(yy)), "y"], p.finish("proof"))


def semigroup(name, iterator, update):
    def base(p, goal):
        p.chain("left", goal[0]).rw("axiom:add_zero", {"a": "r"}, [0])
        p.chain("right", goal[1]).rw("axiom:" + name + "_zero", {"a": iterator("r", "a")})
        return p.join("left", "right")

    def step(p, goal):
        p.chain("left", goal[0]).rw("axiom:add_successor", {"a": "r", "b": "i"}, [0]).rw("axiom:" + name + "_successor", {"n": A("r", "i"), "a": "a"}).rw("hypothesis:IH", path=[0])
        p.chain("right", goal[1]).rw("axiom:" + name + "_successor", {"n": "i", "a": iterator("r", "a")})
        return p.join("left", "right")

    induction(name + "_semigroup", ["r", "s", "a"], "s", [iterator(A("r", "s"), "a"), iterator("s", iterator("r", "a"))], base, step)


semigroup("Jh", JH, H)
semigroup("JF", JF, F)

z = C("x", "y")
k = S(D(z, S("x")))
p = Proof()
p.chain("proof", app("pi1", z)).rw("axiom:pi1_definition", {"z": z}).rw("theorem:clock_slack", {"x": "x", "y": "y"}, [0, 0]).rw("theorem:Jh_semigroup", {"r": "x", "s": k, "a": z}, [0]).rw("axiom:halver_trajectory", {"x": "x", "y": "y"}, [0, 1]).rw("axiom:halver_fixed", {"k": k, "y": "y"}, [0]).rw("theorem:half_odd", {"y": "y"})
theorem("second_projection", ["x", "y"], [app("pi1", z), "y"], p.finish("proof"))

p = Proof()
p.chain("proof", app("pi0", z)).rw("axiom:pi0_definition", {"z": z}).rw("theorem:clock_slack", {"x": "x", "y": "y"}, [1, 0, 0, 0]).rw("axiom:successor_add", {"a": "x", "b": k}, [1, 0, 0], reverse=True).rw("theorem:JF_semigroup", {"r": S("x"), "s": k, "a": A(z, z)}, [1, 0]).rw("axiom:counter_trajectory", {"x": "x", "y": "y"}, [1, 0, 1]).rw("axiom:counter_run", {"k": k}, [1, 0]).rw("theorem:half_odd", {"y": k}, [1]).rw("theorem:clock_slack", {"x": "x", "y": "y"}, [0]).rw("axiom:add_commute", {"a": "x", "b": k}, [0]).rw("theorem:monus_cancellation", {"a": k, "b": "x"})
theorem("first_projection", ["x", "y"], [app("pi0", z), "x"], p.finish("proof"))


def main():
    here = Path(__file__).resolve().parent
    dependencies = {"format": "closed-equational-dependencies-v1", "signature": signature,
                    "axioms": axioms,
                    "scope": "Dependencies are explicitly trusted equations from the earlier closed-update arithmetic and trajectory proofs. No Boolean range, numerical coverage, falsity, order, residual, balance, or non-equational induction is included."}
    certificate = {"format": "closed-equational-certificate-v1", "theorems": theorems}
    (here / "dependencies.json").write_text(json.dumps(dependencies, indent=2) + "\n")
    (here / "certificate.json").write_text(json.dumps(certificate, indent=2) + "\n")
    print(json.dumps({"produced_theorems": [t["name"] for t in theorems],
                      "trusted_equations": len(axioms)}, indent=2))


if __name__ == "__main__":
    main()
