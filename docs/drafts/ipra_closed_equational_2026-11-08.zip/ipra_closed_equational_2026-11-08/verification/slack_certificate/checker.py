"""Replay symbolic equality certificates; imports no certificate producer.

The explicit dependencies.json is the mathematical trust boundary.  A chain
step rewrites one named occurrence using one instantiated dependency,
previous theorem, local proved equality, or current induction hypothesis.
The only proof constructors besides rewriting are symmetry, transitivity,
and literal-equation induction with an explicit fresh eigenvariable.
"""
import json
from pathlib import Path


class Rejected(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Rejected(message)


def free(term):
    if isinstance(term, str):
        return {term}
    result = set()
    for child in term[1:]:
        result.update(free(child))
    return result


def substitute(term, environment):
    if isinstance(term, str):
        return environment.get(term, term)
    return [term[0], *(substitute(child, environment) for child in term[1:])]


def replace(term, path, expected, value):
    if not path:
        require(term == expected, "rewrite occurrence does not match instantiated source")
        return value
    require(isinstance(term, list), "rewrite path enters a variable")
    index = path[0]
    require(type(index) is int and 0 <= index < len(term) - 1,
            "rewrite child index out of range")
    result = list(term)
    result[index + 1] = replace(term[index + 1], path[1:], expected, value)
    return result


class Replay:
    def __init__(self, dependencies):
        require(dependencies.get("format") == "closed-equational-dependencies-v1",
                "wrong dependency format")
        self.signature = dependencies["signature"]
        self.axioms = {}
        self.theorems = {}
        self.counts = {"theorems": 0, "nodes": 0, "rewrite_steps": 0,
                       "induction_nodes": 0}
        for axiom in dependencies["axioms"]:
            name = axiom["name"]
            require(name not in self.axioms, "duplicate dependency")
            variables = set(axiom["variables"])
            require(len(variables) == len(axiom["variables"]), "duplicate schema variable")
            self.equation(axiom["equation"], variables)
            require(variables == free(axiom["equation"][0]) | free(axiom["equation"][1]),
                    "dependency variable list differs from its free variables")
            self.axioms[name] = (variables, axiom["equation"])

    def term(self, term, allowed):
        if isinstance(term, str):
            require(term in allowed, "out-of-scope variable: " + term)
            return
        require(isinstance(term, list) and term, "malformed term")
        require(isinstance(term[0], str) and term[0] in self.signature,
                "unknown function symbol")
        require(len(term) == 1 + self.signature[term[0]], "wrong function arity")
        for child in term[1:]:
            self.term(child, allowed)

    def equation(self, equation, allowed):
        require(isinstance(equation, list) and len(equation) == 2,
                "malformed equality")
        for side in equation:
            self.term(side, allowed)

    def block(self, block, allowed, hypotheses):
        local = {}
        for node in block["nodes"]:
            name = node["id"]
            require(isinstance(name, str) and name not in local, "duplicate proof-node id")
            kind = node["kind"]
            self.counts["nodes"] += 1
            if kind == "chain":
                start = node["start"]
                self.term(start, allowed)
                current = start
                for step in node["steps"]:
                    source = step["source"]
                    namespace, key = source.split(":", 1)
                    if namespace in ("axiom", "theorem"):
                        registry = self.axioms if namespace == "axiom" else self.theorems
                        require(key in registry, "unavailable equality: " + source)
                        variables, equation = registry[key]
                        environment = step.get("environment", {})
                        require(set(environment) == variables,
                                "schema substitution omits or adds a variable")
                        for value in environment.values():
                            self.term(value, allowed)
                        equation = [substitute(side, environment) for side in equation]
                    elif namespace in ("local", "hypothesis"):
                        registry = local if namespace == "local" else hypotheses
                        require(key in registry, "unavailable local equality: " + source)
                        require(not step.get("environment"),
                                "a contextual equality cannot be re-instantiated")
                        equation = registry[key]
                    else:
                        raise Rejected("unknown equality namespace")
                    self.equation(equation, allowed)
                    require(type(step.get("reverse", False)) is bool, "bad rewrite direction")
                    lhs, rhs = reversed(equation) if step.get("reverse", False) else equation
                    require(isinstance(step["path"], list), "bad occurrence path")
                    current = replace(current, step["path"], lhs, rhs)
                    self.counts["rewrite_steps"] += 1
                result = [start, current]
            elif kind == "symmetry":
                require(node["proof"] in local, "missing symmetry premise")
                result = list(reversed(local[node["proof"]]))
            elif kind == "transitivity":
                require(node["left"] in local and node["right"] in local,
                        "missing transitivity premise")
                first, second = local[node["left"]], local[node["right"]]
                require(first[1] == second[0], "transitivity middle terms differ")
                result = [first[0], second[1]]
            elif kind == "induction":
                self.counts["induction_nodes"] += 1
                variable, eigen = node["variable"], node["eigenvariable"]
                require(variable in allowed, "induction variable not in conclusion scope")
                require(isinstance(eigen, str) and eigen not in allowed,
                        "induction eigenvariable is not fresh")
                require(all(variable not in free(side)
                            for eq in hypotheses.values() for side in eq),
                        "induction variable occurs in retained context")
                equation = node["equation"]
                self.equation(equation, allowed)
                parameters = allowed - {variable}
                base_target = [substitute(side, {variable: ["0"]}) for side in equation]
                base = self.block(node["base"], parameters, hypotheses)
                require(base == base_target, "wrong induction base")
                step_hypothesis = [substitute(side, {variable: eigen}) for side in equation]
                step_target = [substitute(side, {variable: ["S", eigen]}) for side in equation]
                label = node["hypothesis"]
                require(isinstance(label, str) and label not in hypotheses,
                        "induction hypothesis label shadows a retained hypothesis")
                extended = dict(hypotheses)
                extended[label] = step_hypothesis
                step_result = self.block(node["step"], parameters | {eigen}, extended)
                require(step_result == step_target, "wrong induction successor conclusion")
                result = equation
            else:
                raise Rejected("unknown proof constructor")
            self.equation(result, allowed)
            local[name] = result
        require(block["conclusion"] in local, "missing block conclusion")
        return local[block["conclusion"]]

    def verify(self, certificate):
        require(certificate.get("format") == "closed-equational-certificate-v1",
                "wrong certificate format")
        for theorem in certificate["theorems"]:
            name = theorem["name"]
            require(name not in self.theorems, "duplicate theorem")
            variables = set(theorem["variables"])
            require(len(variables) == len(theorem["variables"]), "duplicate theorem variable")
            self.equation(theorem["equation"], variables)
            result = self.block(theorem["proof"], variables, {})
            require(result == theorem["equation"], "theorem statement differs from replay result")
            self.theorems[name] = (variables, result)
            self.counts["theorems"] += 1
        return {**self.counts, "theorem_names": list(self.theorems),
                "status": "PASS", "trusted_dependencies": list(self.axioms)}


def verify(dependencies, certificate):
    return Replay(dependencies).verify(certificate)


if __name__ == "__main__":
    import sys
    here = Path(__file__).resolve().parent
    dependencies = json.loads((here / "dependencies.json").read_text())
    certificate_path = Path(sys.argv[1]) if len(sys.argv) > 1 else here / "certificate.json"
    try:
        result = verify(dependencies, json.loads(certificate_path.read_text()))
    except (Rejected, KeyError, TypeError, ValueError, IndexError) as error:
        print(json.dumps({"status": "REJECT", "reason": str(error)}, indent=2))
        raise SystemExit(1)
    print(json.dumps(result, indent=2))
