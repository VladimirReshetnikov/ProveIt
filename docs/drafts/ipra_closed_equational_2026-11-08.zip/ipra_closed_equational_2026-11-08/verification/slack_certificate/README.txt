SYMBOLIC CERTIFICATE FOR THE DIRECT SLACK ARGUMENT
================================================

This package checks symbolic equalities at arbitrary numerical variables.
It does not evaluate finitely many sample natural numbers. The producer
and replay checker are separate programs; checker.py imports no producer
code and reconstructs every intermediate term independently.

Verified results
----------------
The delivered certificate contains eleven theorems:
  1. Rotation of the fixed predecessor iterator.
  2. Monus at zero.
  3. Monus cancellation of two successors.
  4. Universal monus cancellation d(a+b,a)=b, by equation induction.
  5. The new slack invariant
       c(x,y)=Sx+d(c(x,y),Sx),
     by one literal-equation induction.
  6. Its explicit clock decomposition
       c(x,y)=x+S(d(c(x,y),Sx)).
  7. Halving an odd argument q(2y+1)=y.
  8-9. The semigroup equations of the two fixed trajectory iterators.
  10-11. Both projection identities pi1(c(x,y))=y and pi0(c(x,y))=x,
         using the exact trajectory equations listed as dependencies.

Trust boundary
--------------
dependencies.json lists every imported equation and its role. There are
24 explicitly trusted equation schemas: six addition identities, the
predecessor successor theorem, fixed-iterator computation equations,
definitions of monus/pairing/halving/projections, the prior odd ramp
equation, and four exact closed-update trajectory equations. The prior
closed-update predecessor and trajectory proofs are not replayed here.

No Boolean range, numerical coverage, order relation, residual theorem,
balance theorem, falsity bridge, implication, disjunction, or induction
on a non-equation is available to this checker. In particular, the new
slack proof can use none of the dependencies it was designed to remove.

The trust boundary also includes the small equality replay implementation
and Python's ordinary execution semantics. This is a custom symbolic
checker, not a Lean/Rocq formalization, not a complete iPRA verifier, and
not an entry in the proof-checker-size comparison. The full primitive-
recursion compiler and both bi-interpretation composites are mathematical
proofs in the report, not certified by this package.

Format
------
A numerical term is a variable string or a JSON array whose first entry
is a declared function symbol and whose remaining entries are its ordered
arguments. Numerals are repeated S applied to ["0"].

A chain starts from one exact term. Each step records an equality source,
all of its universal-variable substitutions, a direction, and a zero-based
child-occurrence path. The checker confirms that the indicated occurrence
is exactly the instantiated source side and replaces only that occurrence.
There is no hidden simplifier, associative/commutative matching, arithmetic
evaluator, or theorem search in the checker.

Other proof nodes are symmetry, transitivity, and literal-equation induction.
An induction node declares its equation, induction variable, and fresh
eigenvariable. Its zero proof is checked in the fixed-parameter scope.
Its successor proof is checked with exactly one additional equation
hypothesis at the eigenvariable. The successor conclusion is checked
against exact substitution by S(eigenvariable). Eigenvariable capture and
changes to retained parameters are rejected.

Proven local equalities and induction hypotheses cannot be re-instantiated:
they retain precisely their contextual variables. Only closed universal
theorems and explicitly trusted schemas have substitution instances.

Reproduce
---------
Python 3.10 or newer, standard library only, no network:

  python3 produce.py
  python3 checker.py
  python3 verify.py

The final command writes receipt.json. It records eleven accepted theorems,
five equation-induction nodes, explicit rewrite counts, file hashes, and
five rejected corruptions. The corruptions exercise eigenvariable capture,
wrong rewrite occurrences, a missing successor proof, an incorrect
projection conclusion, and an undeclared mathematical dependency.

Attribution
-----------
The numerical terms c, q, h, F, pi0, and pi1 and the exact trajectories
come from ProveIt/docs/drafts/ipra_closed_updates_2026-11-08.zip at commit
9773e5e0376fdaf953567d0e1e6f19570d566bc6. Their definitions and prior
proofs are credited in the main report. The direct slack invariant and
its occurrence-path certificate are the present contribution. The code
in this directory was written for this investigation; no existing
certificate-checker implementation was copied.
