#!/usr/bin/env python3
"""Replay the delivered evidence offline; no source-size record is claimed."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for script in (
    "verification/slack_certificate/verify.py",
    "verification/closed_terms/validate.py",
    "verification/measure_current.py",
):
    print("Running", script, flush=True)
    subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
print("All delivered evidence checks passed.")
