#!/usr/bin/env python3
"""Compile locally, with a format-cache fallback for minimal TeX installations.

Fallback adapted from the supplied closed-update draft; see provenance.
It uses installed files only, does not alter system TeX, and has no shell escape.
"""
from pathlib import Path
import os
import shutil
import subprocess

root = Path(__file__).resolve().parent
env = dict(os.environ)

def run(args, cwd=root):
    p = subprocess.run(args, cwd=cwd, env=env, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if p.returncode:
        print(p.stdout[-12000:])
        raise SystemExit(p.returncode)
    return p.stdout

if not shutil.which("pdflatex"):
    raise SystemExit("A local TeX installation is required.")
fmt = subprocess.run(["kpsewhich", "pdflatex.fmt"], capture_output=True, env=env)
if not fmt.stdout.strip():
    trees = [p for p in ("/usr/share/texlive/texmf-dist", "/usr/share/texmf") if Path(p).is_dir()]
    if trees:
        env["TEXMF"] = "{" + ",".join(trees) + "}"
    cache = root / "build/texformat"
    cache.mkdir(parents=True, exist_ok=True)
    if not (cache / "pdflatex.fmt").is_file():
        run(["pdftex", "-ini", "-etex", "-jobname=pdflatex", "-interaction=nonstopmode",
             "-halt-on-error", "pdflatex.ini"], cwd=cache)
    maps = [Path("/usr/share/texmf/fonts/map/dvips/lm/lm.map")]
    maps += [Path("/usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts") / f
             for f in ("cm.map", "cmextra.map", "symbols.map")]
    if all(p.is_file() for p in maps):
        (cache / "pdftex.map").write_text("\n".join(p.read_text() for p in maps))
        env["TEXFONTMAPS"] = str(cache) + os.pathsep
    env["TEXFORMATS"] = str(cache) + os.pathsep

logs = []
for _ in range(3):
    logs.append(run(["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
                     "-halt-on-error", "report.tex"]))
(root / "results/latex-build.txt").write_text(logs[-1])
print(logs[-1][-1600:])
