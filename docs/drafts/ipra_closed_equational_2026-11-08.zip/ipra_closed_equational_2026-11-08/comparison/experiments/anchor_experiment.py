"""Closed binary anchored updates: explicit grammar, no captured parameters.

The third numerical iterator child is an opaque closed update descriptor.
Descriptor syntax: "state", "anchor", [successor body], or
[counter, initializer, nested closed update]. Every other descriptor means
constant zero. The ambient substitution routine skips every update index.
The independent program application routine validates inserted images.
This is an experimental complete native verifier, not fully validated for
all raw JSON or claimed smaller than the current baseline.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    try:
        if d % 2 and len(a) == 3:
            return [inst(a[0], t, d + 4), inst(a[1], t, d + 4), a[2]]
        return [inst(b, t, d + b'\0\2\1\4'[len(a)]) for b in a + []]
    except:
        return a if k <= a < d else d % 2 and inst(t, d=1)


def apply_update(h, state, anchor):
    match h:
        case "state":
            return inst(state, d=1)
        case "anchor":
            return inst(anchor, d=1)
        case [body]:
            return [apply_update(body, state, anchor)]
        case [counter, initial, update]:
            return [apply_update(counter, state, anchor),
                    apply_update(initial, state, anchor), update]
        case _:
            return 0


def check(a, g):
    global k
    if inst(a) in g:
        return 1
    m, t = take()
    if m and check(m, g):
        match m:
            case [b]:
                m, t = [0, t], b
        if [] in (h := [0, m[2:]]):
            return inst(t, m[1]) == a and check(inst(t, m[0]), g)
    elif t:
        a = inst(a[2], t, 2)
        h = [len(a) % 2 or a, inst(a, 0)]
    else:
        (n, t, r), b = a
        if n:
            n, = n
            t = apply_update(r, [n, t, r], t)
        return b == t
    k -= 1
    return check(inst(a, [k]), g + inst(h, k, -1))


try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    raise SystemExit(1)
