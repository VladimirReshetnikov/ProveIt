"""Experimental mixed progression/reach closure; not yet fully validated."""
import json, sys
k = 0


def inst(a, t=None, d=0):
    try:
        return [inst(b, t, d + b'\0\2\1\4'[len(a)]) for b in a + []]
    except:
        return a if k <= a < d else d % 2 and inst(t, d=1)


def check(a, g):
    global k
    if inst(a) in g:
        return 1
    m, t = take()
    if m and check(m, g):
        match m:
            case [b]:
                s, u = t
                if s and (len(b) % 2 or u != [s]):
                    return
                m, t = [s, u], b
        if not (h := m[2:]):
            return inst(t, m[1]) == a and check(inst(t, m[0]), g)
    elif t:
        a = inst(a[2], t, 2)
        h = inst(a, 0) if len(a) % 2 else a
    else:
        (n, t, r), b = a
        if n:
            n, = n
            t = inst(r, [n, t, r], 1)
        return b == t
    k -= 1
    return check(inst(a, [k]), g + [inst(h, k)])


try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    raise SystemExit(1)
