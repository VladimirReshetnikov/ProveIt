"""Exploratory direct checker for closed unary iterator programs.

Adapted from the current kernel structural profile, whose attribution is
retained in the source corpus. Not a claimed record-size checker. The
arithmetic third child is validated in a fresh one-input program scope
(depth 3, floor 0); numerical substitution never enters that closed scope.
Program application expands its unique input by inst(program, image, 1).
This file is a research prototype, with only focused scope diagnostics so far.
"""
import json, sys
k = 0


def inst(a, t=None, d=0, floor=None):
    if floor is None:
        floor = k
    try:
        child_depth = d + b'\0\2\1\4'[len(a)]
        if d % 2 and len(a) == 3:
            return [inst(a[0], t, child_depth, floor),
                    inst(a[1], t, child_depth, floor),
                    inst(a[2], d=3, floor=0)]
        return [inst(b, t, child_depth, floor) for b in a + []]
    except:
        return a if floor <= a < d else d % 2 and inst(t, d=1, floor=floor)


def check(a, g):
    global k
    if inst(a) in g:
        return 1
    m, t = take()
    if m and check(m, g):
        match m:
            case [b]:
                m, t = [0, t], b
        if [] in (h := [0, m[2:]]):
            return inst(t, m[1]) == a and check(inst(t, m[0]), g)
    elif t:
        a = inst(a[2], t, 2)
        h = [len(a) % 2 or a, inst(a, 0)]
    else:
        (n, t, r), b = a
        if n:
            n, = n
            t = inst(r, [n, t, r], 1)
        return b == t
    k -= 1
    return check(inst(a, [k]), g + inst(h, k, -1))


try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    raise SystemExit(1)
