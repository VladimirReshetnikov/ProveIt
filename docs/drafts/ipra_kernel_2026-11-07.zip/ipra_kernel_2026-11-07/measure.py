"""Reproduce the complete-source comparison with the unchanged upstream metric."""
import ast
import csv
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('upstream_metric', ROOT / 'comparison/source_measure.py')
metric = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metric)
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def uniform_core(path):
    tree = metric.StripDocstrings().visit(ast.parse(path.read_text()))
    tree.body = [n for n in tree.body if isinstance(n, ast.FunctionDef)
                 or (isinstance(n, ast.Assign)
                     and all(isinstance(t, ast.Name) and t.id == 'k' for t in n.targets))]
    normalized = ast.unparse(tree) + '\n'
    return {'normalized_tokens': metric.significant(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode())}


def row(path):
    whole = metric.metrics(path)
    whole.pop('core')  # The upstream heuristic is asymmetric across driver styles.
    return {'whole': whole, 'uniform_core': uniform_core(path)}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    originals = []
    for entry in manifest['programs']:
        measured = row(ROOT / 'comparison' / entry['source'])
        if measured['whole']['sha256'] != entry['sha256']:
            raise ValueError('Comparator source changed: ' + entry['source'])
        originals.append({**entry, **measured})
    minima = {boundary: {field: min(r[boundary][field] for r in originals)
                         for field in FIELDS}
              for boundary in ('whole', 'uniform_core')}
    expanded = json.loads((ROOT / 'comparison/expanded_manifest.json').read_text())
    expanded_rows = []
    for entry in expanded['programs']:
        measured = metric.metrics(ROOT / 'comparison' / entry['source'])
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Expanded comparator changed: ' + entry['source'])
        expanded_rows.append(measured)
    expanded_minima = {f: min(r[f] for r in expanded_rows) for f in FIELDS}
    candidate = row(ROOT / 'checker.py')
    improvements = {b: {f: candidate[b][f] < minima[b][f] for f in FIELDS} for b in minima}
    if not all(value for fields in improvements.values() for value in fields.values()):
        raise ValueError('The claimed strict comparison failed')
    result = {'commit': manifest['commit'], 'python': platform.python_version(),
              'complete_program_count': len(originals), 'minima': minima,
              'candidate': candidate, 'strict_improvements': improvements,
              'expanded_path_count': len(expanded['paths']),
              'expanded_distinct_sources': len(expanded_rows),
              'expanded_whole_minima': expanded_minima, 'originals': originals}
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    names = ('NewTokens', 'NewAST', 'NewBytes')
    macros = ''.join('\\newcommand{\\' + n + '}{' + str(candidate['whole'][f]) + '}\n'
                     for n, f in zip(names, FIELDS))
    (ROOT / 'results/metrics_macros.tex').write_text(macros)
    with (ROOT / 'results/comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ['archive', 'member', *FIELDS])
        writer.writeheader()
        for r in originals:
            writer.writerow({'archive': r['archive'], 'member': r['member'],
                             **{f: r['whole'][f] for f in FIELDS}})
        writer.writerow({'archive': 'DELIVERED', 'member': 'checker.py',
                         **{f: candidate['whole'][f] for f in FIELDS}})
    print(json.dumps({k: v for k, v in result.items() if k != 'originals'}, indent=2))


if __name__ == '__main__':
    main()
