"""Untrusted finite fixture conversion; the result is checked independently.

Changes consumed introduction records [t] into bare witnesses t. Direct Q
introduction uses canonical unused witness 0. It does not alter terms,
formulas, arithmetic equations, parameter identities, or the proof order.
"""
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import types

ROOT = Path(__file__).resolve().parent


def translate(packet):
    source = (ROOT/'frozen/one_hole_checker.py').read_text()
    assert source.count('match take():') == 1
    source = source.replace('match take():','match take(a):')
    module = types.ModuleType('traced_source')
    exec(compile(source, 'traced_source', 'exec'), module.__dict__)
    module.k = 0
    stream = deepcopy(packet)
    result = deepcopy(packet)
    if type(result) is list and result:
        result = [cell[0] if type(cell) is list and len(cell)==1 else cell
                  for cell in result[:-1]] + result[-1:]
    records = []
    def take(goal):
        index = len(stream)-1
        instruction = stream.pop()
        if type(instruction) is list and len(instruction)==1:
            witness = 0 if len(goal)==1 else instruction[0]
            result[index] = deepcopy(witness)
            records.append({'index':index,'closure':len(goal)==1})
        return instruction
    module.take = take
    try:
        accepted = bool(module.check(stream.pop(),[]))
    except Exception:
        accepted = False
    return accepted,result,records


def main():
    rows = json.loads((ROOT/'frozen/one_hole_fixtures.json').read_text())
    out=[]
    admitted_spellings = {
        'original/boolean_in_unused_update': 'Boolean alias for bound coordinate 1',
        'v2/inherited/boundary/boolean_is_not_zero.json': 'Boolean alias for zero',
        'v2/inherited/boundary/scalar_witness_annotation.json': 'Bare numeric witness',
        'v2/inherited/targeted/unmatched_instruction.json': 'Unused null witness is inert',
        'v2/inherited/targeted/used_false_witness.json': 'Boolean alias for witness zero',
    }
    source_verdicts=[]
    for row in rows:
        accepted,packet,records=translate(row['packet'])
        source_verdicts.append({'name':row['name'],'accepted':accepted,'prior_expected':row['expected']})
        out.append({'name':'translated/'+row['name'],'packet':packet,
                    'expected':accepted or row['name'] in admitted_spellings,
                    'source_accepted':accepted,
                    'changed_acceptance_reason':admitted_spellings.get(row['name']),
                    'source_packet_sha256':hashlib.sha256(json.dumps(row['packet'],sort_keys=True).encode()).hexdigest(),
                    'changed_instructions':records})
    # Independent malformed cases are interpreted directly by the new format.
    out.extend([
        {'name':'reject/false_equality','packet':[[],[0,[0]]],'expected':False},
        {'name':'reject/closed_hole','packet':[[],[[0,3,1],3]],'expected':False},
        {'name':'reject/future_parameter','packet':[[],[[0,0,-99],0]],'expected':False},
        {'name':'reject/absent_counter_binder','packet':[[],[[0,0,3],0]],'expected':False},
        {'name':'reject/empty_list_zero','packet':[[],[[[],0,1],0]],'expected':False},
        {'name':'reject/iterator_counter','packet':[[],[[[0,0,1],0,1],0]],'expected':False},
        {'name':'reject/nonarray_packet','packet':{'goal':[0,0]},'expected':False},
        {'name':'accept/Boolean_zero','packet':[[],[[False,False,False],False]],'expected':True},
        {'name':'accept/Boolean_binder','packet':[[],[[0,0,True],0]],'expected':True},
    ])
    (ROOT/'fixtures.json').write_text(json.dumps(out,indent=2)+'\n')
    report={'source_count':len(rows),'source_accepted':sum(x['accepted'] for x in source_verdicts),
            'translated_count':len(out)-9,'explicit_raw_acceptance_changes':admitted_spellings,'new_native_cases':9,'output_count':len(out),
            'source_checker_sha256':hashlib.sha256((ROOT/'frozen/one_hole_checker.py').read_bytes()).hexdigest(),
            'source_verdicts':source_verdicts}
    (ROOT.parent/'results/translation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='source_verdicts'},indent=2))


if __name__=='__main__':main()
