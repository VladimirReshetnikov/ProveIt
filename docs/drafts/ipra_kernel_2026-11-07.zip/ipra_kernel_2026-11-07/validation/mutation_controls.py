"""Discriminating implementation controls for the ordinary iteration variant."""
import ast
from copy import deepcopy
import json
from pathlib import Path
import types
from validate import run

ROOT=Path(__file__).resolve().parent


def load_source(source):
    parsed=ast.parse(source);prefix=[]
    for node in parsed.body:
        if isinstance(node,ast.Try):break
        prefix.append(node)
    module=types.ModuleType('intentional_mutant')
    exec(compile(ast.Module(body=prefix,type_ignores=[]),'intentional_mutant','exec'),module.__dict__)
    return module


def main():
    source=(ROOT.parent/'checker.py').read_text()
    cases={r['name']:r for r in json.loads((ROOT/'fixtures.json').read_text())}
    modifications=[
        ('captured_image','inst(t, d=1)','inst(t, d=d)',
         'translated/original/scalar_contextual_capture',True),
        ('unvalidated_goal','if inst(a) in g:','if a in g:',
         'translated/original/false_eigenparameter_escape',True),
        ('compound_induction','h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [a, inst(a, 0)]','translated/original/compound_induction_hypothesis',True),
        ('false_counter_binder',"b'\\0\\0\\2'","b'\\0\\0\\4'",
         'translated/original/nonexistent_counter_slot',True),
        ('future_parameter_allowed',' and a >= k','',
         'reject/future_parameter',True),
        ('implicit_default_zero','def inst(a, t=None, d=0):','def inst(a, t=0, d=0):',
         'reject/closed_hole',True),
        ('atomic_retained_base_removed','h = [a, inst(a, 0)][len(a) % 2:]',
         'h = [a] if len(a) == 2 else [inst(a, 0)]',
         'translated/original/retained_base_separation',False),
    ]
    results=[]
    for name,old,new,fixture,mutant_expected in modifications:
        assert source.count(old)==1,(name,'source anchor')
        module=load_source(source.replace(old,new))
        case=cases[fixture]
        actual=run(module,case['packet'])['accepted']
        assert actual==mutant_expected,(name,actual,mutant_expected)
        assert actual!=case['expected'],(name,'failed to distinguish defect')
        results.append({'name':name,'fixture':fixture,'correct_accepted':case['expected'],
                        'mutant_accepted':actual})
    result={'status':'PASS','controls':results}
    (ROOT.parent/'results/mutation_controls.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
