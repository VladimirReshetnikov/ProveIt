"""Finite validation of the complete checker with independent oracles.

No verification helper is imported by an acceptance program. This audit is
implementation evidence, not a proof-assistant verification of metatheory.
"""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import types
from named_oracle import Oracle as IterationOracle

ROOT=Path(__file__).resolve().parent


def load_prefix(path):
    parsed=ast.parse(path.read_text())
    prefix=[]
    for node in parsed.body:
        if isinstance(node,ast.Try):break
        prefix.append(node)
    module=types.ModuleType('exact_prefix')
    exec(compile(ast.Module(body=prefix,type_ignores=[]),str(path),'exec'),module.__dict__)
    return module


def run(module,packet):
    module.k=0
    stream=deepcopy(packet)
    try:
        module.take=stream.pop
        accepted=bool(module.check(stream.pop(),[]))
    except Exception:
        accepted=False
    return {'accepted':accepted,'final_k':module.k,
            'remaining':len(stream) if type(stream)is list else None}


def paths(value,prefix=()):
    yield prefix
    if type(value)is list:
        for i,v in enumerate(value):yield from paths(v,(*prefix,i))


def replace(value,path,replacement):
    if not path:return deepcopy(replacement)
    out=deepcopy(value);cursor=out
    for i in path[:-1]:cursor=cursor[i]
    cursor[path[-1]]=deepcopy(replacement)
    return out


def booleanize(v):
    if type(v)is int and v in (0,1):return bool(v)
    if type(v)is list:return [booleanize(w) for w in v]
    return v


def validate(filename,fixture_file,oracle_type,seed):
    source=ROOT.parent/filename
    kernel=load_prefix(source)
    fixtures=json.loads((ROOT/fixture_file).read_text())
    comparisons=0;cli_count=0;rules=Counter();records=[]
    def compare(packet,name,expected=None):
        nonlocal comparisons
        actual=run(kernel,packet);independent=oracle_type().run(packet)
        assert actual['accepted']==independent['accepted'],(filename,name,actual,independent,packet)
        if actual['accepted']:
            assert (actual['final_k'],actual['remaining'])==(independent['final_k'],independent['remaining']), (filename,name,actual,independent)
        if expected is not None:
            assert actual['accepted']==expected,(filename,name,actual,expected)
        comparisons+=1;rules.update(independent['rules'])
        return actual
    for row in fixtures:
        expected=row['expected']
        if row['name']=='Q_unused_witness_empty_array':expected=False
        row['variant_expected']=expected
        actual=compare(row['packet'],row['name'],expected)
        compare(booleanize(row['packet']),row['name']+'/boolean_alias',expected)
        records.append({'name':row['name'],'expected':expected,'result':actual})
    replacements=[None,False,True,0,1,2,3,255,-1,-99,0.0,0.5,'','a',{},[],[0],[0,0],[0,0,0]]
    rng=random.Random(seed)
    for row in fixtures:
        available=list(paths(row['packet']))
        for _ in range(30):
            packet=replace(row['packet'],rng.choice(available),rng.choice(replacements))
            compare(packet,row['name']+'/mutation')
    for _ in range(300):
        def tree(depth):
            if depth==0 or rng.randrange(3)==0:return deepcopy(rng.choice(replacements))
            return [tree(depth-1) for _ in range(rng.randrange(5))]
        compare(tree(4),'random_malformed')
    with tempfile.TemporaryDirectory() as directory:
        packet_path=Path(directory)/'packet.json'
        for row in fixtures:
            packet_path.write_text(json.dumps(row['packet']))
            for flags in ([],['-O']):
                p=subprocess.run([sys.executable,*flags,str(source),str(packet_path)],capture_output=True,text=True,timeout=10)
                wanted=(0,'ACCEPT','') if row['variant_expected'] else (1,'REJECT','')
                assert (p.returncode,p.stdout.strip(),p.stderr)==wanted,(filename,row['name'],p)
                cli_count+=1
    return {'file':filename,'status':'PASS','fixtures':len(fixtures),'comparisons':comparisons,
            'cli_runs':cli_count,'oracle_rule_counts':dict(rules),'fixture_verdicts':records,
            'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}


def main():
    results=[validate('checker.py','fixtures.json',IterationOracle,202611071)]
    (ROOT.parent/'results/validation.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps([{k:v for k,v in r.items() if k!='fixture_verdicts'} for r in results],indent=2))


if __name__=='__main__':main()
