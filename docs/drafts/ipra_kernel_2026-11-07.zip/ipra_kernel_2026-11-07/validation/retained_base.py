"""An explicit certificate for the sentence separating the retained-base rules.

This checks a finite proof and a diagnostic mutant. The infinite countermodel
is proved in the report; this script does not claim to enumerate that model.
"""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types
from validate import run, load_prefix
from named_oracle import Oracle

ROOT = Path(__file__).resolve().parents[1]


def main():
    one = [0]
    sz = [-1]
    r1 = [one, sz, one]
    base = [0, one]
    first_transport = [base, [[1, sz, one], sz]]
    second_transport = [[r1, sz], [1, one]]
    packet = [[], [], first_transport, second_transport, 0, [[1, one]]]
    path = ROOT / 'examples/retained_base_obstruction.json'
    path.write_text(json.dumps(packet, indent=2) + '\n')
    program = ROOT / 'checker.py'
    checked = run(load_prefix(program), packet)
    independent = Oracle().run(packet)
    if not checked['accepted'] or not independent['accepted'] or checked['remaining']:
        raise ValueError('Explicit original proof was not checked')
    source = program.read_text()
    old = 'h = [a, inst(a, 0)][len(a) % 2:]'
    new = 'h = [a] if len(a) == 2 else [inst(a, 0)]'
    if source.count(old) != 1:
        raise ValueError('Mutation anchor changed')
    tree = ast.parse(source.replace(old, new))
    prefix = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        prefix.append(node)
    mutant = types.ModuleType('diagnostic_only')
    exec(compile(ast.Module(body=prefix, type_ignores=[]), 'diagnostic_only', 'exec'), mutant.__dict__)
    mutant_result = run(mutant, packet)
    if mutant_result['accepted']:
        raise ValueError('Deletion unexpectedly accepted the certificate')
    for flags in ([], ['-O']):
        result = subprocess.run([sys.executable, *flags, str(program), str(path)],
                                capture_output=True, text=True, timeout=10)
        if (result.returncode, result.stdout.strip(), result.stderr) != (0, 'ACCEPT', ''):
            raise ValueError(result)
    rows = [{'n': n, 'B_n': n == 1, 'B_next': n + 1 == 1,
             'adjacent_implication': not (n == 1) or n + 1 == 1} for n in range(3)]
    result = {'status': 'PASS', 'goal': 'Q_y(y=1)', 'original': checked,
              'deleted_base': mutant_result, 'actual_cli_runs': 2,
              'strong_semantics_counterexample': rows,
              'source_sha256': hashlib.sha256(program.read_bytes()).hexdigest(),
              'scope': 'The report proves nonderivability; mutant rejection of one proof alone would not.'}
    (ROOT / 'results/retained_base.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
