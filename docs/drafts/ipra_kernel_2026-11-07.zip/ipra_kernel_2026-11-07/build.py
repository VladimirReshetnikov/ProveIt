"""Build the report from its complete LaTeX source; no network required."""
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
def locate(name, env=None):
    found = subprocess.run(['kpsewhich', name], env=env, text=True,
                           capture_output=True)
    return found.stdout.strip() if found.returncode == 0 else ''


def prepare_environment(logs):
    env = os.environ.copy()
    if locate('pdflatex.fmt', env) and locate('article.cls', env):
        return env
    # Some container distributions have TeX source/fonts but no generated
    # filename database or format. Build a private format without installing
    # anything, changing the system, or accessing the network.
    trees = [p for p in (Path('/usr/share/texlive/texmf-dist'),
                        Path('/usr/share/texmf'), Path('/etc/texmf')) if p.is_dir()]
    if not trees:
        raise RuntimeError('Configure a LaTeX distribution with pdflatex before building.')
    private = ROOT.parent / '_tex_runtime'
    private.mkdir(exist_ok=True)
    env['TEXMF'] = '{' + ','.join(str(p) for p in trees) + '}'
    env['TEXINPUTS'] = '.:' + ':'.join(str(p / 'tex') + '//' for p in trees) + ':'
    # Prefer stable LaTeX to the optional latex-dev tree.
    stable = trees[0] / 'tex/latex'
    if stable.is_dir():
        env['TEXINPUTS'] = '.:' + str(stable) + '//:' + env['TEXINPUTS'][2:]
    env['TEXFORMATS'] = str(private) + ':'
    if not (private / 'pdflatex.fmt').exists():
        run = subprocess.run(['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
                              '-halt-on-error', '-jobname=pdflatex',
                              '-progname=pdflatex', 'pdflatex.ini'],
                             cwd=private, env=env, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logs.append(run.stdout)
        if run.returncode:
            raise RuntimeError(run.stdout)
    if not locate('pdftex.map', env):
        maps = []
        for name in ('cm.map', 'cmextra.map', 'symbols.map', 'euler.map',
                     'latxfont.map', 'lm.map'):
            path = locate(name, env)
            if path:
                maps.append(Path(path).read_text())
        (private / 'pdftex.map').write_text('\n'.join(maps))
        env['TEXFONTMAPS'] = str(private) + '//:'
    return env


logs = []
env = prepare_environment(logs)
engine = shutil.which('pdflatex')
if engine is None:
    raise SystemExit('Install pdfLaTeX and the packages listed in report.tex.')
for number in range(3):
    run = subprocess.run([engine, '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
                         cwd=ROOT, env=env, capture_output=True, text=True)
    (ROOT / 'results/latex_console.txt').write_text(run.stdout + run.stderr)
    if run.returncode:
        print((run.stdout + run.stderr)[-7000:])
        raise SystemExit(run.returncode)
log = (ROOT / 'report.log').read_text(errors='replace')
warnings = [line for line in log.splitlines()
            if 'Overfull' in line or 'undefined' in line or 'multiply defined' in line]
(ROOT / 'results/pdf_build.json').write_text(json.dumps(
    {'status': 'PASS', 'passes': 3, 'warnings': warnings,
     'pdf_bytes': (ROOT / 'report.pdf').stat().st_size}, indent=2) + '\n')
print(json.dumps({'pdf': 'report.pdf', 'warnings': warnings}, indent=2))
