"""Create or verify the distributable archive and its SHA-256 manifest."""
import hashlib
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc'}


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts
                  and p.suffix not in EXCLUDED_SUFFIXES
                  and p.name not in {'SHA256SUMS.txt', 'latex_console.txt'})


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = ROOT / 'SHA256SUMS.txt'
    if '--verify' in sys.argv:
        for line in manifest.read_text().splitlines():
            expected, name = line.split('  ', 1)
            if digest(ROOT / name) != expected:
                raise SystemExit('Changed file: ' + name)
        print('PASS: packaged-file hashes')
        return
    payload = files()
    manifest.write_text(''.join(digest(p) + '  ' + p.relative_to(ROOT).as_posix() + '\n'
                                for p in payload))
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in [*payload, manifest]:
            z.write(p, Path(ROOT.name) / p.relative_to(ROOT))
    print(str(archive))


if __name__ == '__main__':
    main()
