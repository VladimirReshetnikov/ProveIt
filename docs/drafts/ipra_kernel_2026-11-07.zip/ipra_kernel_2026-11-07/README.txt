A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
================================================

READ FIRST
----------
report.pdf contains the complete mathematical article.
report.tex and sections/*.tex contain all editable LaTeX sources.
checker.py is the entire delivered acceptance program; it imports only
Python's standard json and sys modules.

RESULT
------
The six current archives at repository commit
6ee66e8e01b8cf39d81f53fce44cbedfede2dfdb contain thirteen root checkers.
The delivered program is strictly below their coordinatewise minima:

                                      Tokens    AST nodes    Normalized bytes
Current complete-source envelope          389          413                1159
Delivered checker.py                     377          404                1133

The reduction also survives uniformly removing each program's driver:

Current uniform-core envelope            330          350                 938
Delivered uniform core                   322          344                 934

All full-source measurements count imports, scope and syntax checks,
substitution, every rule, JSON input, verdicts, and exception handling.
The unchanged inherited normalizer is preserved in comparison/source_measure.py.
Exact measurements use CPython 3.12.14. The checker needs Python 3.10+.
An expanded inventory of 87 byte-distinct complete sources at 369 paths
has the same complete-source minima. That inventory is a sensitivity
check, not a correctness endorsement of all historical programs.

WHAT WAS ACHIEVED
-----------------
This is a modest implementation improvement of the existing scalar
calculus: one-hole opening, bare numerical witnesses, instruction-only
dispatch, and a smaller complete driver are integrated. Positional depth
arguments also reduce source size. No new arithmetic axiom or inference
rule is claimed. Absolute minimality and a new arithmetic breakthrough
have not been established.

The native presentation has numerical terms 0, successor, and initialized
scalar iteration; equations; two logical binders; five inference patterns;
and two computation schemas. Direct closure introduction is checked as an
already-derived rule. The full report reconstructs ordinary intuitionistic
first-order logic, quantifier-free induction, and every fixed primitive
recursion. Its ordinary realization is bi-interpretable with full iPRA on
the entire numerical domain, with both composite isomorphisms x=y.

The arithmetic, logical basis, and reconstruction are inherited and
explicitly attributed. The retained-base progress countermodel is ALSO
inherited: the current one-hole report already states it. The present
analysis supplies complete rule checks, an explicit compound-padding
failure, and an exact repair theorem: paired-binder congruence restores
the original rule set after the proposed base deletion. This extra rule
must be counted if implemented. The failed one-assumption variant is not
offered as an equivalent checker.

REPRODUCE OFFLINE
----------------
  python3 package.py --verify
  python3 reproduce.py

The first command verifies packaged hashes. The second regenerates fixture
conversion, complete/core metrics, oracle comparisons, discriminating
mutations, and the explicit retained-base certificate. It uses only the
Python standard library and files in this archive.

  python3 checker.py examples/iteration_zero.json
  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/retained_base_obstruction.json

These print ACCEPT and exit 0. The last proves Q_y(y=1), the native sentence
separating the original rules from the proposed base deletion.

  python3 checker.py examples/false_equation.json
  python3 -O checker.py examples/capture_rejected.json

These print REJECT and exit 1. Rejection is rejection of that certificate,
not a decision that the formula is unprovable.

  python3 build.py

This compiles the complete article with pdfLaTeX. The build includes a
private, offline fallback for an otherwise installed but unconfigured
TeX Live distribution. The provided PDF can be read without rebuilding.
The rebuilt PDF may differ in metadata; run package.py after intentional
edits to refresh the manifest and ZIP.

VALIDATION
----------
The delivered source passed 5,708 comparisons with an independent
named-variable oracle and 338 real CLI executions, normal and Python -O,
over 169 labelled fixtures. The same test cohorts are reused in mutations;
these numbers are not counts of independent mathematical theorems.
All 100 originally accepted proofs in the 160-fixture source cohort remain
accepted after certificate conversion. Five intentionally broadened raw
spellings are documented in results/translation.json.

Seven deliberate defects are distinguished by dedicated controls: captured
images, missing goal validation, induction for compound formulas, an illicit
counter binder, undeclared parameters, default-zero substitution, and the
deleted atomic retained base. A separate exact certificate checks Q_y(y=1)
and is run through both the oracle and real CLI. The report's countermodel,
not rejection of one certificate, proves nonderivability after the deletion.

These are finite implementation checks. The metatheory is proved in ordinary
mathematical prose and has not been formalized in Lean or Rocq.

FILES
-----
report.pdf, report.tex, sections/  Complete mathematical report and source
checker.py                        Entire trusted acceptance program
FORMAT.txt                        Precise JSON certificate conventions
examples/                         Runnable examples and rejection controls
comparison/                       Frozen comparator sources, hashes, metric
validation/                       Independent oracle, conversion, controls
results/                          Reproducible measurements and test receipts
ATTRIBUTION.txt, LICENSE_SOURCE.txt  Contribution boundaries and permissions
SHA256SUMS.txt                     Packaged file hashes

Finite machine memory/stack limits can reject very large valid certificates.
The mathematical theorem-set claim uses the usual adequate-resource reading
of the finite checking algorithm. The representation is a recursively
specified family of fixed finite update terms, not an arithmetic universal
evaluator or quantification over programs.
