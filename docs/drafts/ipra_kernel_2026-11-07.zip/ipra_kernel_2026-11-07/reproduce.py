"""Reproduce the frozen source comparison and finite validation offline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
scripts = ['validation/translate_fixtures.py', 'measure.py',
           'validation/validate.py', 'validation/mutation_controls.py',
           'validation/retained_base.py']
for name in scripts:
    subprocess.run([sys.executable, str(ROOT / name)], cwd=ROOT, check=True)
(ROOT / 'results/reproduction.json').write_text(
    json.dumps({'status': 'PASS', 'scripts': scripts}, indent=2) + '\n')
