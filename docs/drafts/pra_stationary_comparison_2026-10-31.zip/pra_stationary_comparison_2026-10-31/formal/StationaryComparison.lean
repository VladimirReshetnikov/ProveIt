/-
Constructive kernel for PRA from stationary comparison.

This file checks the bootstrap, a finite quantifier-free formula compiler,
and induction for every compiled formula.  The carrier is arbitrary: there
is no numerical induction assumption.  `IsTerm` restricts the comparison
axiom to a supplied family of unary term denotations with fixed parameters.
The closure fields and the latch constructor are justified by the concrete
finite-description grammar in the manuscript.

Scope limitation: this is a semantic term-family kernel, not a formalization
of the first-order proof calculus, the descriptor compiler, or the two
bi-interpretation round trips.  It does not quantify the comparison axiom
over all functions unless a caller explicitly chooses such an IsTerm.

The logical uses of comparison are exactly: constant terms; the diagonal
eqtest n n; and an arbitrary admitted stationary term with target f zero.
The last use in induction is the admitted shifted latch r (succ n).
All other induction in this file is structural induction on finite formula
syntax.  No Classical, choice, sorry, or admitted axiom is used.
-/

universe u

namespace PRAStationaryComparison

structure Kernel (α : Type u) where
  zero : α
  succ : α → α
  pred : α → α
  gate : α → α → α
  select : α → α → α → α
  eqtest : α → α → α
  zero_ne_one : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ n, pred (succ n) = n
  gate_zero : ∀ a, gate zero a = a
  select_zero : ∀ v w, select zero v w = v
  select_succ : ∀ n v w, select (succ n) v w = w
  eqtest_base : ∀ a, eqtest zero a = gate a (succ zero)
  eqtest_step : ∀ n a,
    eqtest (succ n) a = select a zero (eqtest n (pred a))
  IsTerm : (α → α) → Prop
  constantTerm : ∀ a, IsTerm (fun _ => a)
  variableTerm : IsTerm (fun n => n)
  successorTerm : ∀ f, IsTerm f → IsTerm (fun n => succ (f n))
  comparisonTerm : ∀ f g,
    IsTerm f → IsTerm g → IsTerm (fun n => eqtest (f n) (g n))
  selectionTerm : ∀ f g h,
    IsTerm f → IsTerm g → IsTerm h →
    IsTerm (fun n => select (f n) (g n) (h n))
  substitutionTerm : ∀ f g,
    IsTerm f → IsTerm g → IsTerm (fun n => f (g n))
  stationaryComparison : ∀ f, IsTerm f → ∀ a,
    (∀ n, f (succ n) = f n) →
    (∀ n, f n = a) ∨ eqtest (f zero) a = zero
  latchClosure : ∀ b, IsTerm b → ∃ r : α → α,
    IsTerm r ∧ r zero = succ zero ∧
    ∀ n, r (succ n) = select (b n) zero (r n)

namespace Kernel

variable {α : Type u} (D : Kernel α)

abbrev one : α := D.succ D.zero
abbrev Term := { f : α → α // D.IsTerm f }

theorem one_ne_zero : D.one ≠ D.zero := by
  intro h
  exact D.zero_ne_one h.symm

theorem successor_injective {x y : α} (h : D.succ x = D.succ y) : x = y := by
  calc
    x = D.pred (D.succ x) := (D.pred_succ x).symm
    _ = D.pred (D.succ y) := congrArg D.pred h
    _ = y := D.pred_succ y

theorem successor_nonzero (x : α) : D.succ x ≠ D.zero := by
  intro h
  have hx : x = D.zero := by
    calc
      x = D.pred (D.succ x) := (D.pred_succ x).symm
      _ = D.pred D.zero := congrArg D.pred h
      _ = D.zero := D.pred_zero
  exact D.one_ne_zero ((congrArg D.succ hx).symm.trans h)

theorem eqtest_diagonal_base : D.eqtest D.zero D.zero = D.one := by
  exact (D.eqtest_base D.zero).trans (D.gate_zero D.one)

theorem eqtest_diagonal_step (n : α) :
    D.eqtest (D.succ n) (D.succ n) = D.eqtest n n := by
  calc
    D.eqtest (D.succ n) (D.succ n) =
        D.select (D.succ n) D.zero (D.eqtest n (D.pred (D.succ n))) :=
      D.eqtest_step n (D.succ n)
    _ = D.eqtest n (D.pred (D.succ n)) :=
      D.select_succ n D.zero (D.eqtest n (D.pred (D.succ n)))
    _ = D.eqtest n n := congrArg (D.eqtest n) (D.pred_succ n)

theorem off_diagonal (x a : α) : D.eqtest x a = D.zero ∨ x = a := by
  have h := D.stationaryComparison (fun _ => x) (D.constantTerm x) a
    (fun _ => rfl)
  cases h with
  | inl hx => exact Or.inr (hx D.zero)
  | inr he => exact Or.inl he

theorem eqtest_diagonal_one (x : α) : D.eqtest x x = D.one := by
  have hd : D.IsTerm (fun n => D.eqtest n n) :=
    D.comparisonTerm (fun n => n) (fun n => n) D.variableTerm D.variableTerm
  have h := D.stationaryComparison (fun n => D.eqtest n n) hd D.one
    D.eqtest_diagonal_step
  cases h with
  | inl hdiag => exact hdiag x
  | inr hbad =>
    have h11 : D.eqtest D.one D.one = D.one :=
      (D.eqtest_diagonal_step D.zero).trans D.eqtest_diagonal_base
    have hbase : D.eqtest (D.eqtest D.zero D.zero) D.one = D.one :=
      (congrArg (fun z => D.eqtest z D.one) D.eqtest_diagonal_base).trans h11
    exact False.elim (D.one_ne_zero (hbase.symm.trans hbad))

theorem eqtest_bits (x a : α) :
    D.eqtest x a = D.zero ∨ D.eqtest x a = D.one := by
  cases D.off_diagonal x a with
  | inl hz => exact Or.inl hz
  | inr hxa =>
    cases hxa
    exact Or.inr (D.eqtest_diagonal_one x)

theorem eqtest_one_iff (x a : α) : D.eqtest x a = D.one ↔ x = a := by
  constructor
  · intro h
    cases D.off_diagonal x a with
    | inl hz => exact False.elim (D.one_ne_zero (h.symm.trans hz))
    | inr hxa => exact hxa
  · intro hxa
    cases hxa
    exact D.eqtest_diagonal_one x

theorem eqtest_zero_iff (x a : α) : D.eqtest x a = D.zero ↔ x ≠ a := by
  constructor
  · intro h hxa
    cases hxa
    exact D.one_ne_zero ((D.eqtest_diagonal_one x).symm.trans h)
  · intro hxa
    cases D.off_diagonal x a with
    | inl hz => exact hz
    | inr heq => exact False.elim (hxa heq)

include D in
theorem equality_decision (x a : α) : x = a ∨ x ≠ a := by
  cases D.off_diagonal x a with
  | inl hz => exact Or.inr ((D.eqtest_zero_iff x a).mp hz)
  | inr hxa => exact Or.inl hxa

theorem term_constancy (f : α → α) (hf : D.IsTerm f)
    (stationary : ∀ n, f (D.succ n) = f n) : ∀ n, f n = f D.zero := by
  cases D.stationaryComparison f hf (f D.zero) stationary with
  | inl h => exact h
  | inr h =>
    exact False.elim (D.one_ne_zero
      ((D.eqtest_diagonal_one (f D.zero)).symm.trans h))

theorem shifted_latch_induction
    (P : α → Prop) (b : α → α) (hb : D.IsTerm b)
    (bits : ∀ n, b n = D.zero ∨ b n = D.one)
    (truth : ∀ n, P n ↔ b n = D.one)
    (base : P D.zero) (step : ∀ n, P n → P (D.succ n)) : ∀ n, P n := by
  obtain ⟨r, hr, rbase, rstep⟩ := D.latchClosure b hb
  have select_same (z : α) (hz : z = D.zero ∨ z = D.one) :
      D.select z D.zero D.zero = D.zero := by
    cases hz with
    | inl h => exact h ▸ D.select_zero D.zero D.zero
    | inr h => exact h ▸ D.select_succ D.zero D.zero D.zero
  have bbase : b D.zero = D.one := (truth D.zero).mp base
  have shifted_base : r (D.succ D.zero) = D.one := by
    calc
      r (D.succ D.zero) = D.select (b D.zero) D.zero (r D.zero) := rstep D.zero
      _ = D.select D.one D.zero (r D.zero) := congrArg
        (fun z => D.select z D.zero (r D.zero)) bbase
      _ = r D.zero := D.select_succ D.zero D.zero (r D.zero)
      _ = D.one := rbase
  have shifted_step : ∀ n, r (D.succ (D.succ n)) = r (D.succ n) := by
    intro n
    cases bits n with
    | inl hz =>
      have hn : r (D.succ n) = D.zero := by
        calc
          r (D.succ n) = D.select (b n) D.zero (r n) := rstep n
          _ = D.select D.zero D.zero (r n) := congrArg
            (fun z => D.select z D.zero (r n)) hz
          _ = D.zero := D.select_zero D.zero (r n)
      calc
        r (D.succ (D.succ n)) =
            D.select (b (D.succ n)) D.zero (r (D.succ n)) := rstep (D.succ n)
        _ = D.select (b (D.succ n)) D.zero D.zero := congrArg
          (fun z => D.select (b (D.succ n)) D.zero z) hn
        _ = D.zero := select_same (b (D.succ n)) (bits (D.succ n))
        _ = r (D.succ n) := hn.symm
    | inr hone =>
      have hnext : b (D.succ n) = D.one :=
        (truth (D.succ n)).mp (step n ((truth n).mpr hone))
      calc
        r (D.succ (D.succ n)) =
            D.select (b (D.succ n)) D.zero (r (D.succ n)) := rstep (D.succ n)
        _ = D.select D.one D.zero (r (D.succ n)) := congrArg
          (fun z => D.select z D.zero (r (D.succ n))) hnext
        _ = r (D.succ n) := D.select_succ D.zero D.zero (r (D.succ n))
  have hshift : D.IsTerm (fun n => r (D.succ n)) :=
    D.substitutionTerm r (fun n => D.succ n) hr
      (D.successorTerm (fun n => n) D.variableTerm)
  have shifted_one : ∀ n, r (D.succ n) = D.one := by
    intro n
    exact (D.term_constancy (fun j => r (D.succ j)) hshift shifted_step n).trans
      shifted_base
  intro n
  apply (truth n).mpr
  cases bits n with
  | inl hz =>
    have hn : r (D.succ n) = D.zero := by
      calc
        r (D.succ n) = D.select (b n) D.zero (r n) := rstep n
        _ = D.select D.zero D.zero (r n) := congrArg
          (fun z => D.select z D.zero (r n)) hz
        _ = D.zero := D.select_zero D.zero (r n)
    exact False.elim (D.one_ne_zero ((shifted_one n).symm.trans hn))
  | inr hone => exact hone

inductive Formula (D : Kernel α) : Type u where
  | falsum
  | verum
  | equal (s t : D.Term)
  | conj (A B : Formula D)
  | disj (A B : Formula D)
  | impl (A B : Formula D)

namespace Formula

variable {D : Kernel α}

def meaning : D.Formula → α → Prop
  | .falsum, _ => False
  | .verum, _ => True
  | .equal s t, n => s.val n = t.val n
  | .conj A B, n => meaning A n ∧ meaning B n
  | .disj A B, n => meaning A n ∨ meaning B n
  | .impl A B, n => meaning A n → meaning B n

def bit : D.Formula → α → α
  | .falsum, _ => D.zero
  | .verum, _ => D.one
  | .equal s t, n => D.eqtest (s.val n) (t.val n)
  | .conj A B, n => D.select (bit A n) D.zero (bit B n)
  | .disj A B, n => D.select (bit A n) (bit B n) D.one
  | .impl A B, n => D.select (bit A n) D.one (bit B n)

theorem bit_is_term (A : D.Formula) : D.IsTerm (bit A) := by
  induction A with
  | falsum => exact D.constantTerm D.zero
  | verum => exact D.constantTerm D.one
  | equal s t => exact D.comparisonTerm s.val t.val s.property t.property
  | conj A B ihA ihB =>
    exact D.selectionTerm (bit A) (fun _ => D.zero) (bit B) ihA
      (D.constantTerm D.zero) ihB
  | disj A B ihA ihB =>
    exact D.selectionTerm (bit A) (bit B) (fun _ => D.one) ihA ihB
      (D.constantTerm D.one)
  | impl A B ihA ihB =>
    exact D.selectionTerm (bit A) (fun _ => D.one) (bit B) ihA
      (D.constantTerm D.one) ihB

theorem bit_correct (A : D.Formula) (n : α) :
    (bit A n = D.zero ∨ bit A n = D.one) ∧
    (meaning A n ↔ bit A n = D.one) := by
  induction A with
  | falsum =>
    exact ⟨Or.inl rfl, ⟨False.elim, fun h => D.zero_ne_one h⟩⟩
  | verum =>
    exact ⟨Or.inr rfl, ⟨fun _ => rfl, fun _ => True.intro⟩⟩
  | equal s t =>
    exact ⟨D.eqtest_bits (s.val n) (t.val n),
      (D.eqtest_one_iff (s.val n) (t.val n)).symm⟩
  | conj A B ihA ihB =>
    rcases ihA with ⟨ha, hA⟩
    rcases ihB with ⟨hb, hB⟩
    cases ha with
    | inl ha0 =>
      have hc : bit (.conj A B) n = D.zero :=
        (congrArg (fun z => D.select z D.zero (bit B n)) ha0).trans
          (D.select_zero D.zero (bit B n))
      constructor
      · exact Or.inl hc
      · constructor
        · intro h
          exact False.elim (D.one_ne_zero ((hA.mp h.1).symm.trans ha0))
        · intro h
          exact False.elim (D.one_ne_zero (h.symm.trans hc))
    | inr ha1 =>
      have hc : bit (.conj A B) n = bit B n :=
        (congrArg (fun z => D.select z D.zero (bit B n)) ha1).trans
          (D.select_succ D.zero D.zero (bit B n))
      constructor
      · cases hb with
        | inl hb0 => exact Or.inl (hc.trans hb0)
        | inr hb1 => exact Or.inr (hc.trans hb1)
      · constructor
        · intro h
          exact hc.trans (hB.mp h.2)
        · intro h
          exact ⟨hA.mpr ha1, hB.mpr (hc.symm.trans h)⟩
  | disj A B ihA ihB =>
    rcases ihA with ⟨ha, hA⟩
    rcases ihB with ⟨hb, hB⟩
    cases ha with
    | inl ha0 =>
      have hc : bit (.disj A B) n = bit B n :=
        (congrArg (fun z => D.select z (bit B n) D.one) ha0).trans
          (D.select_zero (bit B n) D.one)
      constructor
      · cases hb with
        | inl hb0 => exact Or.inl (hc.trans hb0)
        | inr hb1 => exact Or.inr (hc.trans hb1)
      · constructor
        · intro h
          cases h with
          | inl hPA =>
            exact False.elim (D.one_ne_zero ((hA.mp hPA).symm.trans ha0))
          | inr hPB => exact hc.trans (hB.mp hPB)
        · intro h
          exact Or.inr (hB.mpr (hc.symm.trans h))
    | inr ha1 =>
      have hc : bit (.disj A B) n = D.one :=
        (congrArg (fun z => D.select z (bit B n) D.one) ha1).trans
          (D.select_succ D.zero (bit B n) D.one)
      exact ⟨Or.inr hc, ⟨fun _ => hc, fun _ => Or.inl (hA.mpr ha1)⟩⟩
  | impl A B ihA ihB =>
    rcases ihA with ⟨ha, hA⟩
    rcases ihB with ⟨hb, hB⟩
    cases ha with
    | inl ha0 =>
      have hc : bit (.impl A B) n = D.one :=
        (congrArg (fun z => D.select z D.one (bit B n)) ha0).trans
          (D.select_zero D.one (bit B n))
      constructor
      · exact Or.inr hc
      · constructor
        · intro _
          exact hc
        · intro _ hPA
          exact False.elim (D.one_ne_zero ((hA.mp hPA).symm.trans ha0))
    | inr ha1 =>
      have hc : bit (.impl A B) n = bit B n :=
        (congrArg (fun z => D.select z D.one (bit B n)) ha1).trans
          (D.select_succ D.zero D.one (bit B n))
      constructor
      · cases hb with
        | inl hb0 => exact Or.inl (hc.trans hb0)
        | inr hb1 => exact Or.inr (hc.trans hb1)
      · constructor
        · intro h
          exact hc.trans (hB.mp (h (hA.mpr ha1)))
        · intro h _
          exact hB.mpr (hc.symm.trans h)

theorem quantifier_free_decision (A : D.Formula) (n : α) :
    meaning A n ∨ ¬ meaning A n := by
  rcases bit_correct A n with ⟨hb, hA⟩
  cases hb with
  | inl hz =>
    exact Or.inr (fun h => D.one_ne_zero ((hA.mp h).symm.trans hz))
  | inr hone => exact Or.inl (hA.mpr hone)

theorem quantifier_free_induction (A : D.Formula)
    (base : meaning A D.zero)
    (step : ∀ n, meaning A n → meaning A (D.succ n)) : ∀ n, meaning A n := by
  exact D.shifted_latch_induction (meaning A) (bit A) (bit_is_term A)
    (fun n => (bit_correct A n).1) (fun n => (bit_correct A n).2) base step

end Formula

#print axioms successor_injective
#print axioms successor_nonzero
#print axioms off_diagonal
#print axioms eqtest_diagonal_one
#print axioms equality_decision
#print axioms term_constancy
#print axioms shifted_latch_induction
#print axioms Formula.bit_is_term
#print axioms Formula.bit_correct
#print axioms Formula.quantifier_free_decision
#print axioms Formula.quantifier_free_induction

end Kernel
end PRAStationaryComparison
