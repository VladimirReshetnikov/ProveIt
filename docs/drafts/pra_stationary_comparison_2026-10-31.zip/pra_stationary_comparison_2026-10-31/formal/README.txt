FORMAL VERIFICATION SCOPE
=========================

File: StationaryComparison.lean
Verified with: Lean 4.19.0
Dependencies: Lean core only; the file has no explicit imports.

Reproduce
---------

Install Lean 4.19.0 and make its `lean` executable available on PATH.
From the directory containing StationaryComparison.lean, run:

    lean --version
    lean StationaryComparison.lean

The checker should exit successfully.  Its eleven printed theorem audits
should each report "does not depend on any axioms".  The verified output
is recorded separately in verification.txt.  No compilation to executable
code or external mathematical library is needed.

What is checked
---------------

The carrier type is arbitrary.  No induction on that carrier is assumed.
The Kernel structure gives explicit hypotheses for the relevant operations,
their computation equations, zero/one separation, a family of admitted
term denotations, and stationary comparison restricted to that family.

The formalized deductions are:

  * successor injectivity and successor nonzeroness;
  * the off-diagonal disjunction, obtained from constant term instances;
  * the reflexive comparator value, obtained from the stationary diagonal;
  * exact equality comparison and decidable native equality;
  * constancy for admitted stationary terms;
  * induction by means of the shifted latch;
  * finite quantifier-free formula syntax with equality, truth, falsity,
    conjunction, disjunction, and implication (negation is implication
    to falsity);
  * compilation of each such formula into an admitted zero/one bit term;
  * constructive correctness of the compiler, including implication;
  * quantifier-free decidability and induction for every such formula.

The only induction used in these Lean proofs is structural induction on
the finite formula syntax.  There is no use of Classical, classical choice,
an admitted proof, or an arithmetic induction principle on the carrier.

The explicit term-family interface
----------------------------------

`IsTerm : (carrier -> carrier) -> Prop` means that a unary function is an
admitted term denotation after fixing any finite tuple of parameters.
It is not a declaration that every function on the carrier is admitted.

The closure hypotheses admit constants, the variable, successor,
comparison, selection, and composition of admitted terms.  A separate
existence-only hypothesis provides an admitted latch with the two literal
primitive-recursion equations used in the proof.  It does not select a
function from an existential witness and requires no choice principle.

For the intended manuscript instance, take admitted denotations to come
from finite terms of its stated description language with arbitrary finite
fixed parameter tuples.  Constants are represented by parameters; closure
operations are term substitution and composition; the latch is an ordinary
identity-substitution recursion already supplied by the grammar.

The comparison interface allows any admitted unary term and any target.
This is justified by the manuscript's SC schema: add a fresh target
parameter to the term while leaving that parameter unused, instantiate SC,
and then substitute the desired target.  If a term already depends on that
value through its fixed parameters, retain those parameters and use a fresh
target position.  Thus the semantic interface does not require comparison
for functions outside the admitted term family.

All hypotheses in Kernel remain hypotheses.  An empty global axiom
dependency list means the checked deductions need no additional Lean
axioms; it does not mean arithmetic is derived from pure logic.

What is not checked
-------------------

This file does not implement the concrete finite-description grammar,
its arities and parameter bookkeeping, or a first-order proof calculus.
The formula atoms carry witnesses for admitted semantic terms rather
than an implementation of that entire recursive function-symbol syntax.

It also does not formally verify the two-pass compiler from recursion
with parameter substitution to ordinary primitive recursion, its internal
bounded-trace uniqueness theorem, the reverse interpretation of SC in
ordinary PRA, or either bi-interpretation round trip.  These are explicit
written proof obligations discharged in the accompanying manuscript.

Accordingly the certified result is the constructive equality and
quantifier-free-induction kernel with its finite formula compiler, not a
single machine-checked theorem covering the complete bi-interpretability
result.
