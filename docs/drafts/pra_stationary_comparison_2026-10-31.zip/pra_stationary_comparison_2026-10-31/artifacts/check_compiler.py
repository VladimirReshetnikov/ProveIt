#!/usr/bin/env python3
"""Deterministic standard-model diagnostics for substitution recursion.

This is an executable transcription check, not a formal proof and not a
verification over arbitrary nonstandard or intuitionistic models.  It uses
only Python's standard library and emits one JSON object on stdout.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import json
from typing import Callable


Frozen = tuple[int, ...]
Base = Callable[[int, Frozen], int]
Step = Callable[[int, int, Frozen, int], int]
Change = Callable[[int], int]


def frozen_value(values: Frozen) -> int:
    """Read every frozen parameter, distinguishing positions."""
    return sum((position + 2) * (value + 1)
               for position, value in enumerate(values))


def predecessor(value: int) -> int:
    return max(value - 1, 0)


def initialized_predecessor(index: int, seed: int) -> int:
    return seed if index == 0 else index - 1


def zero_gate(index: int, seed: int) -> int:
    return seed if index == 0 else 0


def selector(index: int, zero_branch: int, successor_branch: int) -> int:
    """The actual composite P(B(index,S zero_branch),successor_branch)."""
    return initialized_predecessor(
        zero_gate(index, zero_branch + 1), successor_branch
    )


@dataclass(frozen=True)
class Program:
    name: str
    g: Base
    h: Step
    k: Change
    description: str


PROGRAMS = (
    Program(
        "identity_parameter",
        lambda a, b: a + frozen_value(b),
        lambda j, a, b, v: 3 * v + 2 * a + j + frozen_value(b),
        lambda a: a,
        "k(a)=a; the update reads counter, parameter, frozen tuple, and state",
    ),
    Program(
        "predecessor_parameter",
        lambda a, b: 2 * a + 7 * frozen_value(b),
        lambda j, a, b, v: v + (j + 1) * (a + 1) + frozen_value(b),
        predecessor,
        "k(a)=max(a-1,0); the update uses the current changed parameter",
    ),
    Program(
        "successor_parameter",
        lambda a, b: 3 * a + frozen_value(b),
        lambda j, a, b, v: 2 * v + a + 2 * j + frozen_value(b),
        lambda a: a + 1,
        "k(a)=a+1; changed parameters grow during descent",
    ),
    Program(
        "cyclic_parameter",
        lambda a, b: a * a + frozen_value(b),
        lambda j, a, b, v: (5 * v + a * a + 3 * j + frozen_value(b)) % 1009,
        lambda a: (a + 1) % 5,
        "k(a)=(a+1) mod 5; changed parameters need not be monotone",
    ),
    Program(
        "reset_parameter",
        lambda a, b: 2 * a + frozen_value(b),
        lambda j, a, b, v: 7 * v + 2 * a + j + frozen_value(b),
        lambda a: 0,
        "k(a)=0; reset loses the original parameter below the outer step",
    ),
    Program(
        "affine_parameter",
        lambda a, b: a + frozen_value(b),
        lambda j, a, b, v: 3 * v + a + j + frozen_value(b),
        lambda a: 2 * a + 1,
        "k(a)=2*a+1; descent and fold visit different parameter states",
    ),
    Program(
        "equality_program",
        lambda a, b: zero_gate(a, 1),
        lambda j, a, b, v: selector(a, 0, v),
        predecessor,
        "E(0,a)=B(a,1); E(Sn,a)=C(a,0,E(n,p(a)))",
    ),
)


class Evaluator:
    """Two independently arranged evaluations of one fixed description."""

    def __init__(self, program: Program):
        self.program = program

    @lru_cache(maxsize=None)
    def direct(self, n: int, a: int, frozen: Frozen) -> int:
        """Literal recursive call on n-1 with parameter k(a)."""
        p = self.program
        if n == 0:
            return p.g(a, frozen)
        inner = self.direct(n - 1, p.k(a), frozen)
        return p.h(n - 1, a, frozen, inner)

    @lru_cache(maxsize=None)
    def iterate_parameter(self, count: int, a: int) -> int:
        value = a
        for _ in range(count):
            value = self.program.k(value)
        return value

    @lru_cache(maxsize=None)
    def fold_prefixes(self, n: int, a: int, frozen: Frozen) -> tuple[int, ...]:
        """U(0,N,a),...,U(N,N,a), with N=n fixed throughout the fold."""
        p = self.program
        values = [p.g(self.iterate_parameter(n, a), frozen)]
        for j in range(n):
            changed = self.iterate_parameter(max(n - (j + 1), 0), a)
            values.append(p.h(j, changed, frozen, values[-1]))
        return tuple(values)

    def compiled(self, n: int, a: int, frozen: Frozen) -> int:
        return self.fold_prefixes(n, a, frozen)[n]


class Checks:
    def __init__(self) -> None:
        self.counts: dict[str, int] = {}

    def equal(self, kind: str, actual: object, expected: object,
              context: object) -> None:
        self.counts[kind] = self.counts.get(kind, 0) + 1
        if actual != expected:
            raise AssertionError({
                "kind": kind,
                "actual": actual,
                "expected": expected,
                "context": context,
            })


def run(bound: int) -> dict[str, object]:
    checks = Checks()
    frozen_cases: tuple[Frozen, ...] = ((), (0,), (3,), (0, 2), (2, 5, 1))
    reports: list[dict[str, object]] = []
    evaluators = {p.name: Evaluator(p) for p in PROGRAMS}

    for program in PROGRAMS:
        ev = evaluators[program.name]
        before = sum(checks.counts.values())
        for a in range(bound + 1):
            for n in range(bound + 1):
                checks.equal(
                    "parameter_shift",
                    ev.iterate_parameter(n, program.k(a)),
                    ev.iterate_parameter(n + 1, a),
                    (program.name, n, a),
                )
                for frozen in frozen_cases:
                    context = (program.name, n, a, frozen)
                    compiled = ev.compiled(n, a, frozen)
                    direct = ev.direct(n, a, frozen)
                    checks.equal("compiled_equals_direct", compiled, direct,
                                 context)
                    checks.equal(
                        "translated_successor_equation",
                        ev.compiled(n + 1, a, frozen),
                        program.h(n, a, frozen,
                                  ev.compiled(n, program.k(a), frozen)),
                        context,
                    )
                    left = ev.fold_prefixes(n + 1, a, frozen)
                    right = ev.fold_prefixes(n, program.k(a), frozen)
                    trace = ev.fold_prefixes(n, a, frozen)
                    for j in range(n + 1):
                        checks.equal("guarded_U_shift", left[j], right[j],
                                     context + (j,))
                        changed = ev.iterate_parameter(n - j, a)
                        checks.equal(
                            "guarded_trace_uniqueness",
                            ev.direct(j, changed, frozen),
                            trace[j],
                            context + (j,),
                        )
                    if program.name == "identity_parameter":
                        ordinary = program.g(a, frozen)
                        for j in range(n):
                            ordinary = program.h(j, a, frozen, ordinary)
                        checks.equal("identity_is_ordinary_recursion", compiled,
                                     ordinary, context)
            for frozen in frozen_cases:
                checks.equal("translated_base_equation",
                             ev.compiled(0, a, frozen), program.g(a, frozen),
                             (program.name, a, frozen))
        reports.append({
            "name": program.name,
            "description": program.description,
            "checks": sum(checks.counts.values()) - before,
        })

    equality = evaluators["equality_program"]
    for x in range(bound + 1):
        checks.equal("equality_left_corner", equality.direct(0, x + 1, ()), 0, x)
        checks.equal("equality_right_corner", equality.direct(x + 1, 0, ()), 0, x)
        checks.equal("equality_diagonal", equality.direct(x, x, ()), 1, x)
        for y in range(bound + 1):
            checks.equal("equality_characteristic",
                         equality.direct(x, y, ()), int(x == y), (x, y))
            checks.equal("equality_simultaneous_successor",
                         equality.direct(x + 1, y + 1, ()),
                         equality.direct(x, y, ()), (x, y))
            for z in range(bound + 1):
                checks.equal("composite_selector",
                             selector(x, y, z), y if x == 0 else z, (x, y, z))
    checks.equal("equality_zero_corner", equality.direct(0, 0, ()), 1, None)

    # A deliberately wrong fold that always reads the deepest parameter.
    # Detecting this error ensures that h's current-parameter input is tested.
    ev = evaluators["affine_parameter"]
    n, a, frozen = 3, 2, (2, 5)
    deepest = ev.iterate_parameter(n, a)
    wrong = ev.program.g(deepest, frozen)
    for j in range(n):
        wrong = ev.program.h(j, deepest, frozen, wrong)
    correct = ev.compiled(n, a, frozen)
    checks.equal("negative_control_rejects_frozen_deepest_parameter",
                 wrong != correct, True, (n, a, frozen))

    # Exact constant-function counterexample in the coordinatewise N^2 model.
    # Constancy makes the universal stationary premise automatic; no finite
    # sample is being used to establish that universal fact.
    zero = (0, 0)
    one = (1, 1)
    value = (0, 1)
    target = (0, 0)
    equality_value = tuple(
        equality.direct(value[i], target[i], ()) for i in range(2)
    )
    constant_function = lambda index: value
    premise = constant_function((1, 1)) == constant_function((0, 0))
    first_disjunct = value == target
    second_disjunct = equality_value == zero
    checks.equal("product_nontriviality", zero != one, True, None)
    checks.equal("product_stationary_constant", premise, True, None)
    checks.equal("product_first_disjunct_false", first_disjunct, False, None)
    checks.equal("product_second_disjunct_false", second_disjunct, False, None)

    return {
        "status": "passed",
        "scope": "Deterministic standard-natural-number diagnostics only",
        "not_a_formal_proof": True,
        "limitations": [
            "No verification over arbitrary nonstandard models",
            "No formalization of first-order or intuitionistic derivability",
            "Bounded checks cannot replace the manuscript's induction proofs",
        ],
        "bound": bound,
        "principal_inputs": {"n": [0, bound], "a": [0, bound]},
        "boundary_steps_also_checked": bound + 1,
        "frozen_parameter_tuples": [list(b) for b in frozen_cases],
        "programs": reports,
        "invariants": {
            "parameter_shift": "K(t,k(a))=K(t+1,a)",
            "guarded_U_shift": "j<=n -> U(j,n+1,a,b)=U(j,n,k(a),b)",
            "guarded_trace_uniqueness":
                "j<=N -> F(j,K(N-j,a),b)=U(j,N,a,b)",
        },
        "counts": checks.counts,
        "total_checks": sum(checks.counts.values()),
        "negative_control": {
            "wrong_fold_using_deepest_parameter_at_every_step": wrong,
            "correct_fold": correct,
            "detected": wrong != correct,
        },
        "product_countermodel_witness": {
            "structure": "Coordinatewise N^2",
            "zero": list(zero),
            "one": list(one),
            "function": "The constant term f(n,a,b)=b",
            "constant_b": list(value),
            "target_a": list(target),
            "stationary_premise": True,
            "stationarity_reason": "The term is independent of n",
            "universal_first_disjunct": False,
            "equality_bit_E_b_a": list(equality_value),
            "second_disjunct_E_b_a_equals_zero": False,
            "SC_instance": False,
            "explanation":
                "(0,1)!=(0,0), and coordinatewise E((0,1),(0,0))=(1,0)!=(0,0).",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=12,
                        help="Largest principal counter and parameter input")
    parser.add_argument("--output", help="Also write the JSON result to this file")
    args = parser.parse_args()
    if args.bound < 0 or args.bound > 100:
        parser.error("--bound must lie between 0 and 100")
    result = run(args.bound)
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        with open(args.output, "w", encoding="utf-8") as output:
            output.write(rendered)
    print(rendered, end="")


if __name__ == "__main__":
    main()
