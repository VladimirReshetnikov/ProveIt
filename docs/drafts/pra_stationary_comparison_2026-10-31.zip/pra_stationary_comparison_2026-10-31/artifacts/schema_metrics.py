#!/usr/bin/env python3
"""Reproduce the stationary-comparison formula-template counts.

Usage: python3 schema_metrics.py [--output schema_metrics.json]

Requires only Python's standard library. This script reconstructs all compared
formula templates directly. It does not fetch sources or execute archive code.
The six-source table records the documented presentations at repository commit
392757d09455930d2b090b26bd1537799451c91a; provenance belongs in the separate audit.
"""

import argparse
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class AST:
    name: str
    args: tuple = ()

    @property
    def nodes(self):
        return 1 + sum(child.nodes for child in self.args)


def app(name, *args):
    return AST(name, args)


def forall(variables, body):
    for variable in reversed(variables):
        body = app("forall " + variable.name, body)
    return body


def equals(left, right):
    return app("=", left, right)


def implies(left, right):
    return app("implies", left, right)


def negate(formula):
    return implies(formula, AST("bottom"))


def disjoin(left, right):
    return app("or", left, right)


zero, n, a, x, y, v = [AST(s) for s in ("0", "n", "a", "x", "y", "v")]


def successor(term):
    return app("S", term)


one = successor(zero)
separation = negate(equals(zero, one))
off_diagonal = forall((x, y), disjoin(equals(app("e", x, y), zero), equals(x, y)))
involution = forall((x, y), equals(app("R", app("R", x, y), y), x))


def parameters(count):
    if count < 1:
        raise ValueError("SC requires a distinguished target parameter, so m >= 1")
    return (a,) + tuple(AST(f"b{i}") for i in range(1, count))


def schematic_function(params):
    return lambda term: app("f", term, *params)


def computation(params, substituted):
    base = forall(params, equals(app("R", zero, *params), app("g", *params)))
    recparams = ((app("k", params[0]), *params[1:]) if substituted else params)
    step = forall((n, *params), equals(
        app("R", successor(n), *params),
        app("h", n, *params, app("R", n, *recparams))))
    return base, step


def binary_computation():
    base = forall((a,), equals(app("I", zero, a), a))
    step = forall((n, a), equals(
        app("I", successor(n), a), app("h", n, app("I", n, a))))
    return base, step


def stationarity(f):
    return forall((n,), equals(f(successor(n)), f(n)))


def stationary_comparison(params):
    f = schematic_function(params)
    target = params[0]
    return forall(params, implies(stationarity(f), disjoin(
        forall((n,), equals(f(n), target)),
        equals(app("e", f(zero), target), zero))))


def stationary_separation(params):
    f = schematic_function(params)
    return forall(params, implies(stationarity(f),
        forall((n,), negate(equals(successor(f(n)), f(zero))))))


def positive_constancy(params):
    f = schematic_function(params)
    return forall(params, implies(
        forall((n,), equals(f(successor(successor(n))), f(successor(n)))),
        forall((n,), disjoin(equals(n, zero), equals(f(n), f(one))))))


def stationary_zero(params):
    f = schematic_function(params)
    return forall(params, implies(stationarity(f), disjoin(
        forall((n,), equals(f(n), zero)), equals(app("Z", f(zero)), zero))))


def sizes(formulas):
    return sum(formula.nodes for formula in formulas)


def build_report():
    rows = []
    for m in range(1, 9):
        params = parameters(m)
        base, step = computation(params, substituted=True)
        old_base, old_step = computation(params, substituted=False)
        sc = stationary_comparison(params).nodes
        ss = stationary_separation(params).nodes
        new = base.nodes + step.nodes + separation.nodes + sc
        predecessor = base.nodes + step.nodes + off_diagonal.nodes + ss
        assert (base.nodes, step.nodes) == (3*m+4, 4*m+10)
        assert base.nodes + step.nodes == 7*m+14
        assert old_base.nodes + old_step.nodes == 7*m+13
        assert sc == 5*m+20
        assert ss == 5*m+17
        assert new == 12*m+40
        assert predecessor == 12*m+42
        assert predecessor - new == 2
        rows.append({
            "parameters_including_target": m,
            "D_base": base.nodes,
            "D_step": step.nodes,
            "SC": sc,
            "Sep": separation.nodes,
            "new_total": new,
            "SS": ss,
            "Off": off_diagonal.nodes,
            "predecessor_total": predecessor,
            "saving": predecessor-new,
        })

    # The designated equality description is unchanged from the predecessor.
    e_base = app("B", y, one)
    e_step = app("P", app("B", y, one), v)
    e_substitution = app("P", y, zero)
    p_descriptors = (a, n, a)
    b_descriptors = (a, zero, a)
    assert [e_base.nodes, e_step.nodes, e_substitution.nodes] == [4, 6, 3]
    assert [part.nodes for part in p_descriptors] == [1, 1, 1]
    assert [part.nodes for part in b_descriptors] == [1, 1, 1]
    selected_total = (sizes((e_base, e_step, e_substitution))
                      + sizes(p_descriptors) + sizes(b_descriptors))
    assert selected_total == 19
    program = {
        "e_base": e_base.nodes,
        "e_step": e_step.nodes,
        "e_substitution": e_substitution.nodes,
        "e_subtotal": sizes((e_base, e_step, e_substitution)),
        "P_base": p_descriptors[0].nodes,
        "P_step": p_descriptors[1].nodes,
        "P_identity_substitution": p_descriptors[2].nodes,
        "P_subtotal": sizes(p_descriptors),
        "B_base": b_descriptors[0].nodes,
        "B_step": b_descriptors[1].nodes,
        "B_identity_substitution": b_descriptors[2].nodes,
        "B_subtotal": sizes(b_descriptors),
        "selected_program_total": selected_total,
        "scope": ("Every base, update and substitution descriptor body is "
                  "counted, including the identity substitutions for P and B. "
                  "Tags, binder metadata and symbol-name encodings are excluded."),
    }

    params = parameters(1)
    d_full = sizes(computation(params, substituted=False))
    d_sub = sizes(computation(params, substituted=True))
    d_binary = sizes(binary_computation())
    pc = positive_constancy(params).nodes
    sz = stationary_zero(params).nodes
    ss = stationary_separation(params).nodes
    sc = stationary_comparison(params).nodes
    common_fixed = separation.nodes + involution.nodes
    assert (separation.nodes, off_diagonal.nodes, involution.nodes) == (6, 11, 9)
    assert (d_full, d_sub, d_binary, pc, sz, ss, sc) == (20, 21, 18, 26, 24, 22, 25)

    # These associations of names with presentations are documented comparisons,
    # not a network inventory. All numeric components above are reconstructed.
    documented = [
        ("pra_anchored_involution_2026-10-31", "ordinary full PR",
         d_full, pc, common_fixed),
        ("pra_bounded_reflection_2026-10-31", "ordinary full PR",
         d_full, pc, common_fixed),
        ("pra_involutive_difference_2026-10-31", "initialized binary",
         d_binary, pc, common_fixed),
        ("pra_stationary_zero_2026-10-31", "ordinary full PR",
         d_full, sz, common_fixed),
        ("pra_substitution_descent_2026-10-31", "substituted full PR",
         d_sub, ss, off_diagonal.nodes),
        ("pra_transposition_constancy_2026-10-31", "ordinary full PR",
         d_full, pc, common_fixed),
        ("pra_stationary_comparison_2026-10-31", "substituted full PR",
         d_sub, sc, separation.nodes),
    ]
    comparison = [{
        "archive_stem": stem, "grammar": grammar, "computation": d,
        "arithmetic_schema": recurring, "fixed_arithmetic": fixed,
        "total": d+recurring+fixed,
    } for stem, grammar, d, recurring, fixed in documented]
    assert [row["total"] for row in comparison] == [61, 61, 59, 59, 54, 61, 52]

    return {
        "metric": (
            "One node per variable, constant, application, equality, logical "
            "connective, bottom, and single-variable quantifier. Expand 1=S0 "
            "and negation as implication to bottom. Schematic applications "
            "charge displayed arguments, not their substituted program bodies."),
        "caveat": (
            "Formula-template AST size, not full encoded specification length. "
            "Symbols, binding metadata and grammar costs are not byte-counted. "
            "SC has a distinguished target parameter, so m>=1. "
            "The theorem admits all finite parameter tuples; one displayed "
            "parameter does not mean one parameter suffices for the proof."),
        "general_formulas": {
            "D_base": "3m+4", "D_step": "4m+10", "D_total": "7m+14",
            "SC": "5m+20", "Sep": 6,
            "new_total": "12m+40", "predecessor_total": "12m+42",
            "saving": 2,
        },
        "parameter_checks": rows,
        "selected_program_costs": program,
        "documented_source_comparison": comparison,
        "comparison_snapshot": "392757d09455930d2b090b26bd1537799451c91a",
        "source_audit": (
            "Source paths, hashes and retrieval evidence are separate. "
            "This standalone script neither fetches sources nor depends on "
            "downloaded archives."),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("schema_metrics.json"),
                        help="JSON destination (default: schema_metrics.json)")
    args = parser.parse_args()
    report = build_report()
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": "passed",
        "output": str(args.output),
        "parameter_lengths_checked": len(report["parameter_checks"]),
        "one_parameter_new_total": report["parameter_checks"][0]["new_total"],
        "one_parameter_predecessor_total":
            report["parameter_checks"][0]["predecessor_total"],
        "uniform_saving": 2,
    }, indent=2))


if __name__ == "__main__":
    main()
