#!/usr/bin/env python3
"""Compile the self-contained report, with no network access."""

from pathlib import Path
import shutil
import subprocess


def main():
    root = Path(__file__).resolve().parent
    compiler = shutil.which("pdflatex")
    if compiler is None:
        raise SystemExit("Install a TeX distribution providing pdflatex.")
    build = root / "build"
    build.mkdir(exist_ok=True)
    source = root / "pra_stationary_comparison.tex"
    previous_aux = None
    for run in range(1, 5):
        result = subprocess.run(
            [compiler, "-interaction=nonstopmode", "-halt-on-error",
             "-no-shell-escape", f"-output-directory={build}", str(source)],
            cwd=root, capture_output=True, text=True,
        )
        (build / f"pdflatex-{run}.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-6000:])
            raise SystemExit(result.returncode)
        aux = (build / "pra_stationary_comparison.aux").read_bytes()
        if run >= 2 and aux == previous_aux:
            break
        previous_aux = aux
    log = (build / "pra_stationary_comparison.log").read_text()
    bad = [line for line in log.splitlines() if any(marker in line for marker in
           ("Overfull", "undefined references", "undefined on input line"))]
    if bad:
        raise SystemExit("Build needs attention:\n" + "\n".join(bad))
    output = root / "pra_stationary_comparison.pdf"
    shutil.copy2(build / output.name, output)
    print(f"Built {output.name}; {output.stat().st_size} bytes; {run} TeX passes.")


if __name__ == "__main__":
    main()
