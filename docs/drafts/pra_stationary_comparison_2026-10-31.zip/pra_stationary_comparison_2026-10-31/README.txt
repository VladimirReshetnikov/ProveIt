PRA FROM STATIONARY COMPARISON
=============================
Research report prepared for Vladimir Reshetnikov
31 October 2026

MAIN RESULT
-----------
The same nonlogical basis, in the corresponding ambient logic, is
definitionally equivalent and hence bi-interpretable and equiconsistent
with first-order classical PRA or first-order intuitionistic PRA.

The basis consists of:
  * effective primitive-recursion equations with one changing parameter;
  * 0 != S0;
  * one stationary-comparison schema for all finite terms and parameter tuples.

The schema and every designated program are fully specified in
SPECIFICATION.txt and the article. The matched formula-template count is
52 versus 54 for the current substitution-descent draft, using exactly
the same recursion grammar and equality program. The other five current
drafts have counts 59 or 61. The saving is two nodes at every finite
positive parameter length. This is not an absolute minimality claim or
a complete bit-length comparison; an older quoted display also has 52.

START HERE
----------
pra_stationary_comparison.pdf  Complete 14-page mathematical report.
pra_stationary_comparison.tex  Self-contained LaTeX source.
SPECIFICATION.txt             Exact syntax, axioms, translations, and scope.

formal/StationaryComparison.lean
    Constructive Lean kernel over an arbitrary carrier, with an explicit
    admitted-term predicate. It checks native comparison, term constancy,
    finite formula-to-bit compilation, and quantifier-free induction.
formal/README.txt
    Exact scope and reproduction instructions.
formal/verification.txt
    Successful Lean check and axiom-dependency audits.
formal/lean-toolchain
    leanprover/lean4:v4.19.0

artifacts/schema_metrics.py
    Independent formula-AST counts and designated program costs.
artifacts/schema_metrics.json
    Recorded results, including the current six-file comparison.
artifacts/check_compiler.py
    Standard-library Python diagnostics for the changing-parameter
    compiler, its bounded invariants, equality program, and countermodel.
artifacts/compiler_checks.json
    Recorded run: 99,703 finite diagnostic checks passed.

audit/source_manifest.json
    Immutable source URLs, archive hashes, review scope, and incoming check.
audit/validation.json
    Final build/check status and formal-verification boundary.
SHA256SUMS.txt
    SHA-256 digests for the other package files.

REPRODUCE
---------
Requirements: Python 3.10 or later; a standard TeX installation with
pdflatex and the packages named in the source; optional Lean 4.19.0.

From the unpacked package directory:

    python3 build.py
    python3 artifacts/schema_metrics.py --output artifacts/schema_metrics.json
    python3 artifacts/check_compiler.py --bound 12 --output artifacts/compiler_checks.json
    lean formal/StationaryComparison.lean

The build script runs pdflatex until references stabilize (at least twice)
and writes the PDF next to the source. Its temporary files are kept in
build/. No network access is used by these scripts.

VERIFICATION BOUNDARY
---------------------
The article proves both interpretations and both round trips, including
uniqueness for changing-parameter recursion with only quantifier-free
induction. Its appendix supplies the ordinary-PRA arithmetic used there.

Lean checks the constructive admitted-term kernel and complete finite
quantifier-free formula compiler. It does NOT formalize the first-order
proof calculus, finite descriptor grammar, two-pass descriptor compiler,
or bi-interpretation round trips. Explicit Kernel fields remain hypotheses.
The absence of global axiom dependencies does not remove those hypotheses.

The Python checks are standard-model diagnostics, not formal proofs for
arbitrary or nonstandard inputs. Their count is not a proof-strength claim.

PROVENANCE
----------
All six current docs/drafts archives were downloaded and checked at
ProveIt commit 392757d09455930d2b090b26bd1537799451c91a.
Their internal historical comparison tables were not mistaken for the
current directory inventory. The incoming inventory and complete index
were checked; unrelated Busy Beaver archives were not unpacked.

The new contribution is stationary comparison and its direct bootstrap.
The description grammar, comparator, shifted-latch method, and two-pass
compiler build on the supplied research, especially substitution descent.
Historical uniqueness/constancy results and primary PRA references are
cited in the article. Source archives and third-party papers are not
redistributed in this package.

The source repository was read only; this package makes no repository commit.
