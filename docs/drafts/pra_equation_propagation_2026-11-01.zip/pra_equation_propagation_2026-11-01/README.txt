PRA FROM A FIXED FORMULA SHAPE
Research prepared for Vladimir Reshetnikov, 1 November 2026.

READ FIRST
report.pdf is the complete 16-page mathematical report (page count may change
if rebuilt with a different TeX distribution). report.tex and sections/*.tex
are its complete LaTeX source. AXIOMS.txt is an independently readable exact
specification of the new theory.

MAIN RESULT
Retain scalar delayed iteration with Reset and Next. Replace the arbitrary
quantifier-free dynamic matrix input by the rigid shape

  (0 != S0) AND (n=0 OR s(n,a)=t(n,a)),

where only the two terms vary. With the same two stationary computation
matrices and the inherited propagation wrapper, this is bi-interpretable
and equiconsistent with first-order PRA separately in matching classical
and intuitionistic logic. Both interpretations preserve the whole carrier
and native equality; both composites are internally the identity.

The new reduction is in matrix generation: no arbitrary propositional
formula input and no construction of a substituted zero-instance guard.
The outer 15-node subtotal and the two computational schemes are unchanged.
The corresponding expanded coverage instance decreases from 86 to 59 active
AST nodes. No absolute shortestness or complete description-length minimum
is claimed.

PROOF SCOPE
The report gives the complete written argument: restricted propagation,
equation induction, positive coverage, native equality reflection, full
quantifier-free induction, one-parameter numerical pairing, the PR compiler,
and both round trips. The two Lean kernels check specified local constructive
steps over an arbitrary carrier. They do NOT formalize the full first-order
bi-interpretability theorem. Read formal/SCOPE.txt.

REPRODUCE
  python3 build.py

Requires Python 3.10+ and pdflatex with the packages listed in report.tex.
No external Python packages are needed. To run only the finite diagnostics:
  python3 build.py --skip-pdf

To check both kernels as well, supply a Lean 4.19.0 executable:
  python3 build.py --lean /absolute/path/to/lean

No mathlib is required. These files import no classical reasoning.

FILES
  AXIOMS.txt                       Exact standalone axiom generator
  report.tex, sections/*.tex        Complete manuscript source
  report.pdf                       Compiled manuscript
  formal/*.lean, formal/SCOPE.txt   Local formal kernels and their limitations
  checks/*.py                      Syntax/counting and bounded arithmetic diagnostics
  audit/source_manifest.json       Pinned source inventory and hashes
  audit/*                          Review notes and verification results
  SHA256SUMS.txt                    Hashes for every other included file

The hashes describe the delivered version. Rebuilding a PDF may change its
creation-time metadata even when its mathematical content is unchanged.

COMPARISON
All six archives in ProveIt/docs/drafts at commit
13300d26dac24e7e6b75fe38fd21fb5b5d416d41 were reviewed. Their computational
and coding results are explicitly attributed in the report. The reduction
is new relative to that inspected set; no literature-wide priority is claimed.
