#!/usr/bin/env python3
"""Rebuild the report and run finite diagnostics; Python standard library only."""
from __future__ import annotations
import argparse
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent

def checked(args, log):
    result = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    log.write_text(result.stdout)
    if result.returncode:
        sys.stderr.write(result.stdout)
        raise SystemExit(result.returncode)
    return result.stdout

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', help='optional path to a Lean 4.19.0 executable')
    parser.add_argument('--skip-pdf', action='store_true')
    options = parser.parse_args()
    audit = ROOT / 'audit'
    audit.mkdir(exist_ok=True)
    summary = {}
    for name, output in [('check_schema.py', 'schema_check.json'),
                         ('check_arithmetic.py', 'arithmetic_console.txt')]:
        stdout = checked([sys.executable, str(ROOT/'checks'/name)], audit/output)
        summary[name] = json.loads(stdout)
    if not options.skip_pdf:
        exe = shutil.which('pdflatex')
        if not exe:
            raise SystemExit('Install a TeX distribution including pdflatex and the packages in report.tex.')
        for i in range(1, 4):
            checked([exe, '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
                    audit/f'latex_pass_{i}.txt')
        log = (ROOT/'report.log').read_text()
        problems = [line for line in log.splitlines() if
                    'Overfull' in line or 'undefined' in line or 'multiply defined' in line]
        if problems:
            raise SystemExit('LaTeX diagnostics require review:\n'+'\n'.join(problems))
        summary['pdf'] = 'Compiled in three passes; no overfull boxes or unresolved references.'
    if options.lean:
        for source, log in [('GuardedEquationKernel.lean','guarded_kernel_lean.txt'),
                            ('EqualityReflectionKernel.lean','equality_reflection_lean_check.txt')]:
            checked([options.lean, str(ROOT/'formal'/source)], audit/log)
        summary['lean'] = 'Both kernels checked; read formal/SCOPE.txt for exact scope.'
    print(json.dumps({'status':'PASS','checks':{
          k: {'status':v.get('status'), 'checks':v.get('checks', v.get('checks_passed', v.get('total_checks')))} if isinstance(v,dict) else v
          for k,v in summary.items()}}, indent=2))

if __name__ == '__main__':
    main()
