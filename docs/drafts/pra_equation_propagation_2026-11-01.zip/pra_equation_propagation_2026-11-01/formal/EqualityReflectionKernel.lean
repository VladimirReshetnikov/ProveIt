/-
Constructive equality-reflection kernel for the PRA report.

Scope: this checks the residual/equality-bit argument over an arbitrary
carrier. Algebraic laws already proved by source equation induction are
explicit hypotheses. The residual theorem takes precisely the induction
instance it uses, rather than postulating induction over all predicates.
This file does not formalize first-order syntax, the axiom generator,
parameter coding, or the complete bi-interpretation theorem.
-/

universe u

namespace EqualityReflectionKernel

structure Algebra (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  add : A → A → A
  diff : A → A → A
  sel : A → A → A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  succ_injective : ∀ {x y}, succ x = succ y → x = y
  sep : zero ≠ succ zero
  cover : ∀ x, x = zero ∨ x = succ (pred x)
  add_zero : ∀ x, add x zero = x
  add_succ : ∀ x y, add x (succ y) = succ (add x y)
  zero_add : ∀ x, add zero x = x
  succ_add : ∀ x y, add (succ x) y = succ (add x y)
  diff_zero : ∀ x, diff x zero = x
  diff_succ : ∀ x y, diff x (succ y) = pred (diff x y)
  diff_succ_self : ∀ x, diff (succ x) x = succ zero
  sel_zero : ∀ b c, sel zero b c = b
  sel_succ : ∀ z b c, sel (succ z) b c = c

variable {A : Type u}

theorem selector_same (a : Algebra A) (z b : A) : a.sel z b b = b := by
  rcases a.cover z with hz | hs
  · rw [hz, a.sel_zero]
  · rw [hs, a.sel_succ]

def Residual (a : Algebra A) (y n : A) : Prop :=
  a.sel (a.diff y n) y (a.add n (a.diff y n)) = y

theorem residual_base (a : Algebra A) (y : A) : Residual a y a.zero := by
  dsimp [Residual]
  rw [a.diff_zero, a.zero_add]
  exact selector_same a y y

theorem residual_step (a : Algebra A) (y n : A)
    (ih : Residual a y n) : Residual a y (a.succ n) := by
  rcases a.cover (a.diff y n) with hz | hs
  · dsimp [Residual]
    rw [a.diff_succ, hz, a.pred_zero, a.sel_zero]
  · let v := a.pred (a.diff y n)
    have hres : a.diff y n = a.succ v := hs
    have hold : a.add n (a.succ v) = y := by
      dsimp [Residual] at ih
      rw [hres, a.sel_succ] at ih
      exact ih
    have hnext : a.diff y (a.succ n) = v := a.diff_succ y n
    have hadd : a.add (a.succ n) v = y := by
      calc
        a.add (a.succ n) v = a.succ (a.add n v) := a.succ_add n v
        _ = a.add n (a.succ v) := (a.add_succ n v).symm
        _ = y := hold
    dsimp [Residual]
    rw [hnext, hadd]
    exact selector_same a v y

theorem residual (a : Algebra A) (y : A)
    (induction_instance : Residual a y a.zero →
      (∀ n, Residual a y n → Residual a y (a.succ n)) →
      ∀ n, Residual a y n) : ∀ n, Residual a y n := by
  exact induction_instance (residual_base a y) (residual_step a y)

theorem unit_difference_iff (a : Algebra A)
    (res : ∀ y n, Residual a y n) (x y : A) :
    a.diff (a.succ x) y = a.succ a.zero ↔ x = y := by
  constructor
  · intro h
    have hr := res (a.succ x) y
    dsimp [Residual] at hr
    rw [h, a.sel_succ, a.add_succ, a.add_zero] at hr
    exact (a.succ_injective hr).symm
  · intro h
    subst y
    exact a.diff_succ_self x

def chi (a : Algebra A) (r : A) : A :=
  a.sel r (a.succ a.zero) (a.sel (a.pred r) a.zero (a.succ a.zero))

theorem chi_at_zero (a : Algebra A) : chi a a.zero = a.succ a.zero := by
  dsimp [chi]
  exact a.sel_zero _ _

theorem chi_at_one (a : Algebra A) : chi a (a.succ a.zero) = a.zero := by
  dsimp [chi]
  rw [a.sel_succ, a.pred_succ, a.sel_zero]

theorem chi_at_double_succ (a : Algebra A) (r : A) :
    chi a (a.succ (a.succ r)) = a.succ a.zero := by
  dsimp [chi]
  rw [a.sel_succ, a.pred_succ, a.sel_succ]

theorem classify (a : Algebra A) (r : A) :
    r = a.zero ∨ r = a.succ a.zero ∨ ∃ v, r = a.succ (a.succ v) := by
  rcases a.cover r with hz | hs
  · exact Or.inl hz
  · rcases a.cover (a.pred r) with hpz | hps
    · exact Or.inr (Or.inl (hs.trans (congrArg a.succ hpz)))
    · exact Or.inr (Or.inr ⟨a.pred (a.pred r),
        hs.trans (congrArg a.succ hps)⟩)

theorem chi_range (a : Algebra A) (r : A) :
    chi a r = a.zero ∨ chi a r = a.succ a.zero := by
  rcases classify a r with hz | ho | ⟨v, hv⟩
  · exact Or.inr (hz ▸ chi_at_zero a)
  · exact Or.inl (ho ▸ chi_at_one a)
  · exact Or.inr (hv ▸ chi_at_double_succ a v)

theorem chi_zero_iff (a : Algebra A) (r : A) :
    chi a r = a.zero ↔ r = a.succ a.zero := by
  constructor
  · intro h
    rcases classify a r with hz | ho | ⟨v, hv⟩
    · rw [hz, chi_at_zero] at h
      exact False.elim (a.sep h.symm)
    · exact ho
    · rw [hv, chi_at_double_succ] at h
      exact False.elim (a.sep h.symm)
  · intro h
    rw [h, chi_at_one]

def errorBit (a : Algebra A) (x y : A) : A :=
  chi a (a.diff (a.succ x) y)

theorem error_bit_range (a : Algebra A) (x y : A) :
    errorBit a x y = a.zero ∨ errorBit a x y = a.succ a.zero :=
  chi_range a _

theorem error_bit_zero_iff (a : Algebra A)
    (res : ∀ y n, Residual a y n) (x y : A) :
    errorBit a x y = a.zero ↔ x = y := by
  exact (chi_zero_iff a _).trans (unit_difference_iff a res x y)

theorem error_bit_one_iff (a : Algebra A)
    (res : ∀ y n, Residual a y n) (x y : A) :
    errorBit a x y = a.succ a.zero ↔ x ≠ y := by
  constructor
  · intro hone heq
    have hzero := (error_bit_zero_iff a res x y).mpr heq
    exact a.sep (hzero.symm.trans hone)
  · intro hne
    rcases error_bit_range a x y with hzero | hone
    · exact False.elim (hne ((error_bit_zero_iff a res x y).mp hzero))
    · exact hone

theorem native_equality_decidable (a : Algebra A)
    (res : ∀ y n, Residual a y n) (x y : A) : x = y ∨ x ≠ y := by
  rcases error_bit_range a x y with hzero | hone
  · exact Or.inl ((error_bit_zero_iff a res x y).mp hzero)
  · exact Or.inr ((error_bit_one_iff a res x y).mp hone)

#print axioms residual
#print axioms error_bit_zero_iff
#print axioms error_bit_one_iff
#print axioms native_equality_decidable

end EqualityReflectionKernel
