/-
Guarded punctured equations: constructive logical kernel.

SCOPE. A is an arbitrary carrier, never Nat. The function parameters f,g
represent the interpretations of selected finite first-order terms. A
Propagate premise is ONE instance of the source axiom scheme, after a
frozen parameter has been fixed. The file does not add an object-language
function sort, quantify over all definable predicates inside the theory,
or assume induction for arbitrary predicates. Induct below denotes one
selected induction instance, used only for the reverse logical direction.

Checked: separation; ordinary equation induction; predecessor coverage;
stationary extraction; reverse soundness of the guarded matrix; delayed
initial equations from Reset and Next; predecessor and successor laws.
Not checked here: first-order parser, arithmetic/equality reflection,
parameter pairing, PR compiler, or the complete bi-interpretation.

No imports, sorry, added axioms, or classical reasoning.
-/

universe u
namespace GuardedEquationKernel

variable {A : Type u}

def Propagate (s : A -> A) (F : A -> Prop) : Prop :=
  (forall n, F n -> F (s n)) -> forall n, F n

def Guarded (z : A) (s f g : A -> A) (n : A) : Prop :=
  (z ≠ s z) ∧ (n = z ∨ f n = g n)

def EqInd (z : A) (s f g : A -> A) : Prop :=
  f z = g z ->
  (forall n, f n = g n -> f (s n) = g (s n)) ->
  forall n, f n = g n

def Induct (z : A) (s : A -> A) (F : A -> Prop) : Prop :=
  F z -> (forall n, F n -> F (s n)) -> forall n, F n

variable {z : A} {s : A -> A}

theorem separation
    (pg : Propagate s (Guarded z s (fun _ => z) (fun _ => z))) :
    z ≠ s z := by
  have step : forall n,
      Guarded z s (fun _ => z) (fun _ => z) n ->
      Guarded z s (fun _ => z) (fun _ => z) (s n) := by
    intro n hn
    exact ⟨hn.1, Or.inr rfl⟩
  exact (pg step z).1

/-- One guarded punctured-equation instance gives its ordinary equation
    induction instance. The zero disjunct is eliminated using the base. -/
theorem equation_induction (f g : A -> A)
    (pg : Propagate s (Guarded z s f g)) : EqInd z s f g := by
  intro base step
  have progress : forall n, Guarded z s f g n -> Guarded z s f g (s n) := by
    intro n hn
    refine ⟨hn.1, Or.inr ?_⟩
    apply step n
    cases hn.2 with
    | inl hz => exact hz ▸ base
    | inr he => exact he
  intro n
  cases (pg progress n).2 with
  | inl hz => exact hz ▸ base
  | inr he => exact he

/-- Coverage is obtained from one fixed guarded equation after the
    predecessor successor equation is available. -/
theorem coverage (p : A -> A)
    (pSucc : forall n, p (s n) = n)
    (pg : Propagate s (Guarded z s (fun n => n) (fun n => s (p n)))) :
    forall n, n = z ∨ n = s (p n) := by
  have progress : forall n,
      Guarded z s (fun n => n) (fun n => s (p n)) n ->
      Guarded z s (fun n => n) (fun n => s (p n)) (s n) := by
    intro n hn
    exact ⟨hn.1, Or.inr (congrArg s (pSucc n)).symm⟩
  intro n
  exact (pg progress n).2

theorem stationary_extract (z : A) (P : Prop)
    (pg : Propagate s (fun _ : A => P)) : P :=
  pg (fun _ h => h) z

theorem stationary_sound (P : Prop) (hp : P) :
    Propagate s (fun _ : A => P) :=
  fun _ _ => hp

/-- This uses the one QF induction instance for this finite guarded
    formula, rather than an all-predicates induction hypothesis. -/
theorem guarded_sound (f g : A -> A) (sep : z ≠ s z)
    (ind : Induct z s (Guarded z s f g)) :
    Propagate s (Guarded z s f g) := by
  intro step
  exact ind ⟨sep, Or.inl rfl⟩ step

/-- First boundary equation, using one Reset instance and one Next
    equation for the constant-one descriptor q. -/
theorem delayed_at_one (D q : A -> A -> A)
    (qNext : q (s (s z)) z = s z)
    (resetD : forall n a, D (q n z) a = a) :
    forall a, D (s z) a = a := by
  intro a
  have e := resetD (s (s z)) a
  rw [qNext] at e
  exact e

theorem delayed_at_zero (D q : A -> A -> A)
    (qNext : q (s (s z)) z = s z)
    (resetD : forall n a, D (q n z) a = a)
    (resetQ : forall n a, q (q n z) a = a) :
    forall a, D z a = a := by
  have qOne : q (s z) z = z := delayed_at_one q q qNext resetQ z
  intro a
  have e := resetD (s z) a
  rw [qOne] at e
  exact e

/-- D_S(S n,0)=n is the sole equation induction instance used here. -/
theorem delayed_predecessor (D : A -> A -> A)
    (atOne : forall a, D (s z) a = a)
    (atNext : forall n a, D (s (s n)) a = s (D (s n) a))
    (pg : Propagate s (Guarded z s (fun n => D (s n) z) (fun n => n))) :
    forall n, D (s n) z = n := by
  apply equation_induction (fun n => D (s n) z) (fun n => n) pg
  · exact atOne z
  · intro n ih
    exact (atNext n z).trans (congrArg s ih)

theorem successor_injective (p : A -> A)
    (pSucc : forall n, p (s n) = n) {x y : A}
    (e : s x = s y) : x = y := by
  have pe := congrArg p e
  rw [pSucc x, pSucc y] at pe
  exact pe

theorem successor_nonzero (p : A -> A)
    (pZero : p z = z) (pSucc : forall n, p (s n) = n)
    (sep : z ≠ s z) (n : A) : s n ≠ z := by
  intro e
  have pe := congrArg p e
  rw [pSucc n, pZero] at pe
  have se : s z = z := (congrArg s pe).symm.trans e
  exact sep se.symm

end GuardedEquationKernel

#print axioms GuardedEquationKernel.separation
#print axioms GuardedEquationKernel.equation_induction
#print axioms GuardedEquationKernel.coverage
#print axioms GuardedEquationKernel.stationary_extract
#print axioms GuardedEquationKernel.stationary_sound
#print axioms GuardedEquationKernel.guarded_sound
#print axioms GuardedEquationKernel.delayed_at_one
#print axioms GuardedEquationKernel.delayed_at_zero
#print axioms GuardedEquationKernel.delayed_predecessor
#print axioms GuardedEquationKernel.successor_injective
#print axioms GuardedEquationKernel.successor_nonzero
