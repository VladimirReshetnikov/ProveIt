#!/usr/bin/env python3
"""Bounded standard-model diagnostics for the accompanying written proof.

This is not a proof of the first-order scheme, its validity on nonstandard
models, or the complete bi-interpretation. It checks numerical instances of
the displayed equations and a few instances of the state compiler.

The mathematically derived p/add/sub operations use ordinary Python integer
arithmetic. Halving and parity are computed from the report's mod-three
iteration, and pairing decoders use the displayed I_u(z,z), I_w(z,z) terms.
No symbolic evaluator for all primitive-recursive descriptions is asserted.
Only the Python standard library is required.
"""

from collections import Counter
from functools import lru_cache
from pathlib import Path
import json
import math


COUNTS = Counter()


def check(group, condition, context=None):
    COUNTS[group] += 1
    if not condition:
        raise AssertionError((group, context))


def p(n):
    return max(n - 1, 0)


def d(x, y):
    return max(x - y, 0)


def z(n, a):
    return a if n == 0 else 0


def C(t, a, b):
    # The displayed arithmetic selector, not a direct Python conditional.
    return z(t, a) + z(z(t, 1), b)


def iterate(h, n, a):
    for _ in range(n):
        a = h(a)
    return a


def delayed(h, n, a):
    return iterate(h, p(n), a)


def chi(r):
    return C(r, 1, C(p(r), 0, 1))


def equality_bit(x, y):
    # Throughout the report, 0 means true and 1 means false.
    return chi(d(x + 1, y))


def bool_and(a, b):
    return C(a, b, 1)


def bool_or(a, b):
    return C(a, 0, b)


def bool_implies(a, b):
    return C(a, b, 0)


class ModThreeCalibration:
    """Cache exactly the two unary iterations used for H and parity."""

    def __init__(self):
        self.m_values = [0]
        self.G_values = [0]

    @staticmethod
    def cycle(v):
        return C(p(v), v + 1, 0)

    def m(self, n):
        while len(self.m_values) <= n:
            self.m_values.append(self.cycle(self.m_values[-1]))
        return self.m_values[n]

    @staticmethod
    def b(v):
        return z(p(v), v)

    def g(self, v):
        return v + 1 + self.b(self.m(v))

    def G(self, n):
        while len(self.G_values) <= n:
            self.G_values.append(self.g(self.G_values[-1]))
        return self.G_values[n]

    def half(self, n):
        return d(self.G(n), n)

    def parity(self, n):
        return self.m(self.G(n))


CAL = ModThreeCalibration()


def u(v):
    return C(CAL.parity(v), CAL.half(v), v)


def w(v):
    return C(CAL.parity(v), CAL.half(v), v + 2)


def J(x, y):
    return iterate(lambda v: v + v, x, 1 + y + y)


@lru_cache(maxsize=None)
def U(n):
    return iterate(u, n, n)


@lru_cache(maxsize=None)
def W(n):
    return iterate(w, n, n)


@lru_cache(maxsize=None)
def L(n):
    return d(n, CAL.half(d(W(n), U(n))))


@lru_cache(maxsize=None)
def R(n):
    return CAL.half(U(n))


def compiler_run(name, count, parameter=None):
    """A literal scalar (counter,(parameter-code,value)) simulation.

    The one-parameter code is J(a,0); the zero-parameter code is 0.
    The numeric decoders above, rather than tuple unpacking or bit tricks,
    are used at every transition. Only count <= 4 and a <= 2 are tested.
    """
    B = 0 if parameter is None else J(parameter, 0)
    if name == "addition":
        seed_value = parameter
    elif name == "multiplication":
        seed_value = 0
    elif name == "factorial":
        seed_value = 1
    else:
        raise ValueError(name)
    state = J(0, J(B, seed_value))
    max_state = state
    for n in range(count + 1):
        counter, tail = L(state), R(state)
        frozen, value = L(tail), R(tail)
        check("compiler_counter_invariant", counter == n, (name, n, parameter))
        check("compiler_parameter_invariant", frozen == B, (name, n, parameter))
        if parameter is not None:
            check("compiler_parameter_decode", L(frozen) == parameter,
                  (name, n, parameter))
        expected = {
            "addition": (parameter or 0) + n,
            "multiplication": (parameter or 0) * n,
            "factorial": math.factorial(n),
        }[name]
        check("compiler_output", value == expected, (name, n, parameter))
        if n == count:
            return value, max_state
        if name == "addition":
            next_value = value + 1
        elif name == "multiplication":
            next_value = value + L(frozen)
        else:
            next_value = (counter + 1) * value
        state = J(counter + 1, J(frozen, next_value))
        max_state = max(max_state, state)


def main():
    bodies = {
        "zero": lambda v: 0,
        "one": lambda v: 1,
        "identity": lambda v: v,
        "successor": lambda v: v + 1,
        "predecessor": p,
        "doubling": lambda v: v + v,
        "zero_test": lambda v: z(v, 1),
    }
    q = lambda n: delayed(bodies["one"], n, 0)
    for name, h in bodies.items():
        for n in range(9):
            for a in range(9):
                check("delayed_reset", delayed(h, q(n), a) == a, (name, n, a))
                check("delayed_next",
                      delayed(h, n + 2, a) == h(delayed(h, n + 1, a)),
                      (name, n, a))
                check("shifted_iteration",
                      delayed(h, n + 1, a) == iterate(h, n, a), (name, n, a))
        for a in range(9):
            check("delayed_both_bases",
                  delayed(h, 0, a) == a and delayed(h, 1, a) == a,
                  (name, a))

    for n in range(65):
        check("delayed_predecessor", delayed(bodies["successor"], n, 0) == p(n), n)
        check("constructor_coverage", n == 0 or n == p(n) + 1, n)
        check("mod3_calibration", CAL.m(n) == n % 3, n)
        check("halving_calibration", CAL.half(n) == n // 2, n)
        check("parity_calibration", CAL.parity(n) == n % 2, n)
        for y in range(65):
            residual = d(y, n)
            check("residual_identity", C(residual, y, n + residual) == y, (n, y))
            check("unit_difference_reflection", (d(n + 1, y) == 1) == (n == y),
                  (n, y))
            bit = equality_bit(n, y)
            check("equality_bit_range", bit in (0, 1), (n, y))
            check("equality_bit_reflection", (bit == 0) == (n == y), (n, y))
            check("inequality_bit_reflection", (bit == 1) == (n != y), (n, y))

    for a in (0, 1):
        for b in (0, 1):
            check("boolean_conjunction", (bool_and(a, b) == 0) == (a == 0 and b == 0))
            check("boolean_disjunction", (bool_or(a, b) == 0) == (a == 0 or b == 0))
            check("boolean_implication", (bool_implies(a, b) == 0) == (a != 0 or b == 0))

    # A composite formula with conjunction, disjunction, implication, and
    # negation, evaluated by the external Boolean compiler at bounded data.
    for n in range(9):
        for a in range(9):
            atom1 = equality_bit(n, a)
            atom2 = equality_bit(d(n, a), 0)
            atom3 = equality_bit(p(n + 1), n)
            neg1 = bool_implies(atom1, 1)
            compiled = bool_implies(bool_or(atom1, neg1), bool_and(atom2, atom3))
            antecedent = (n == a) or not (n == a)
            consequent = (d(n, a) == 0) and (p(n + 1) == n)
            expected = not antecedent or consequent
            check("composite_truth_term", (compiled == 0) == expected, (n, a))

    for x in range(6):
        for y in range(6):
            code = J(x, y)
            check("pairing_closed_form", code == (2 ** x) * (2 * y + 1), (x, y))
            check("pairing_left_retraction", L(code) == x, (x, y, code))
            check("pairing_right_retraction", R(code) == y, (x, y, code))

    examples = []
    for name in ("addition", "multiplication"):
        for a in range(3):
            for n in range(5):
                value, max_state = compiler_run(name, n, a)
                examples.append({"function": name, "count": n, "parameter": a,
                                 "value": value, "maximum_encoded_state": max_state})
    for n in range(5):
        value, max_state = compiler_run("factorial", n)
        examples.append({"function": "factorial", "count": n,
                         "value": value, "maximum_encoded_state": max_state})

    report = {
        "status": "passed",
        "scope": "Bounded standard-natural-number diagnostics; not a formal proof.",
        "limitations": [
            "No claim of validity in every nonstandard or intuitionistic model.",
            "No full first-order parser, derivation checker, or bi-interpretation formalization.",
            "Derived p/add/sub are implemented by ordinary Python arithmetic.",
            "Halving/parity and pairing decoding use the displayed iterator constructions.",
            "State compilation is tested only on addition, multiplication, and factorial.",
        ],
        "bounds": {"delayed_count_and_seed": [0, 8], "reflection_inputs": [0, 64],
                   "pairing_coordinates": [0, 5], "compiler_counts": [0, 4],
                   "compiler_parameters": [0, 2]},
        "checks_by_group": dict(sorted(COUNTS.items())),
        "total_checks": sum(COUNTS.values()),
        "compiler_examples": examples,
        "maximum_compiler_state": max(e["maximum_encoded_state"] for e in examples),
    }
    target = Path(__file__).resolve().parents[1] / "audit" / "arithmetic_check.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "total_checks": report["total_checks"],
                      "maximum_compiler_state": report["maximum_compiler_state"],
                      "report": str(target)}, indent=2))


if __name__ == "__main__":
    main()
