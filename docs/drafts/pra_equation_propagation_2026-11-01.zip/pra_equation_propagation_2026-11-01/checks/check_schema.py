#!/usr/bin/env python3
"""Finite syntax checks for the rigid PRA propagation generator.

This is a syntax/counting diagnostic, not a proof of the arithmetic theorem.
Term nodes: ('v',name), ('0',), ('S',term), ('D',descriptor_id,count,seed).
Descriptor bodies are stored separately and never changed by active substitution.
All counts charge each active variable, constant, application, connective,
equality, and quantifier once. Stored descriptor text is excluded unless its
body is explicitly substituted into a transition equation.
"""
from __future__ import annotations
import json

def V(x): return ('v', x)
Z = ('0',)
def S(t): return ('S', t)
def D(h,n,a): return ('D', h, n, a)
def Eq(s,t): return ('=',s,t)
Bot = ('bot',)
def And(p,q): return ('and',p,q)
def Or(p,q): return ('or',p,q)
def Imp(p,q): return ('imp',p,q)
def All(x,p): return ('all',x,p)

def tfv(t):
    match t[0]:
        case 'v': return {t[1]}
        case '0': return set()
        case 'S': return tfv(t[1])
        case 'D': return tfv(t[2]) | tfv(t[3])
    raise ValueError(t)

def ffree(p):
    match p[0]:
        case 'bot': return set()
        case '=': return tfv(p[1]) | tfv(p[2])
        case 'and'|'or'|'imp': return ffree(p[1]) | ffree(p[2])
        case 'all': return ffree(p[2]) - {p[1]}
        case 'pred': return set().union(*(tfv(t) for t in p[2:]))
    raise ValueError(p)

def allnames(p):
    if p[0]=='all': return {p[1]} | allnames(p[2])
    if p[0] in {'and','or','imp'}: return allnames(p[1]) | allnames(p[2])
    return ffree(p)

def tsubst(t,x,r):
    match t[0]:
        case 'v': return r if t[1]==x else t
        case '0': return t
        case 'S': return S(tsubst(t[1],x,r))
        case 'D': return D(t[1],tsubst(t[2],x,r),tsubst(t[3],x,r))
    raise ValueError(t)

def fsubst(p,x,r):
    match p[0]:
        case 'bot': return p
        case '=': return Eq(tsubst(p[1],x,r),tsubst(p[2],x,r))
        case 'and'|'or'|'imp': return (p[0],fsubst(p[1],x,r),fsubst(p[2],x,r))
        case 'pred': return ('pred',p[1],*(tsubst(t,x,r) for t in p[2:]))
        case 'all':
            y,body=p[1],p[2]
            if y==x or x not in ffree(body): return p
            if y in tfv(r):
                forbidden=allnames(body)|tfv(r)|{x,y}
                i=0
                while f'{y}_{i}' in forbidden: i+=1
                fresh=f'{y}_{i}'
                body=fsubst(body,y,V(fresh))
                y=fresh
            return All(y,fsubst(body,x,r))
    raise ValueError(p)

def tsize(t):
    match t[0]:
        case 'v'|'0': return 1
        case 'S': return 1+tsize(t[1])
        case 'D': return 1+tsize(t[2])+tsize(t[3])
    raise ValueError(t)

def fsize(p):
    match p[0]:
        case 'bot': return 1
        case '=': return 1+tsize(p[1])+tsize(p[2])
        case 'and'|'or'|'imp': return 1+fsize(p[1])+fsize(p[2])
        case 'all': return 1+fsize(p[2])
        case 'pred': return 1+sum(tsize(t) for t in p[2:])
    raise ValueError(p)

def occ(t,x):
    match t[0]:
        case 'v': return int(t[1]==x)
        case '0': return 0
        case 'S': return occ(t[1],x)
        case 'D': return occ(t[2],x)+occ(t[3],x)
    raise ValueError(t)

def refs(t):
    match t[0]:
        case 'v'|'0': return set()
        case 'S': return refs(t[1])
        case 'D': return {t[1]} | refs(t[2]) | refs(t[3])
    raise ValueError(t)

def admit_body(body,earlier):
    return tfv(body) <= {'v'} and refs(body) <= set(earlier)

N,A=V('n'),V('a')
delta=Eq(Z,S(Z))
sep=Imp(delta,Bot)

def rigid(s,t):
    if not (tfv(s)|tfv(t)) <= {'n','a'}:
        raise ValueError('Only n,a may occur freely in dynamic inputs')
    return And(sep,Or(Eq(N,Z),Eq(s,t)))

def old_guard_for_zero_disjunction(s,t):
    b=Or(Eq(N,Z),Eq(s,t))
    return Imp(Or(fsubst(b,'n',Z),delta),b)

def reset(h): return All('n',Eq(D(h,D('one',N,Z),A),A))

def transition(h,body):
    return All('n',Eq(D(h,S(S(A)),N),tsubst(body,'v',D(h,S(A),N))))

def wrapper(p):
    return All('a',Imp(All('n',Imp(p,fsubst(p,'n',S(N)))),All('n',p)))

def run():
    checks=[]
    def check(label,condition):
        if not condition: raise AssertionError(label)
        checks.append(label)

    bodies={}
    for name,body in [('zero',Z),('one',S(Z)),('succ',S(V('v'))),
                      ('pred',D('succ',V('v'),Z)),
                      ('nested',D('pred',S(V('v')),D('zero',V('v'),S(Z))))]:
        check('well-founded descriptor '+name,admit_body(body,bodies))
        bodies[name]=body
    check('reject descriptor frozen parameter',not admit_body(S(A),bodies))
    check('reject descriptor forward reference',not admit_body(D('future',V('v'),Z),bodies))
    check('reject descriptor self reference',not admit_body(D('self',V('v'),Z),bodies))

    active=D('nested',N,A)
    frozen_before=repr(bodies)
    check('active substitution preserves descriptor id',tsubst(active,'n',S(N))==D('nested',S(N),A))
    check('active substitution does not rewrite stored bodies',repr(bodies)==frozen_before)

    check('separation active size',fsize(sep)==6)
    opaque=('pred','F',N,A)
    check('opaque P15 subtotal',fsize(wrapper(opaque))==15)
    examples=[('constants',Z,Z),('variables',N,A),
              ('coverage',N,S(D('succ',N,Z))),
              ('nested',D('nested',S(N),A),D('zero',N,S(A)))]
    rows=[]
    for name,s,t in examples:
        p=rigid(s,t); old=old_guard_for_zero_disjunction(s,t)
        length=tsize(s)+tsize(t); counter=occ(s,'n')+occ(t,'n')
        check(name+' matrix count',fsize(p)==12+length)
        check(name+' shifted matrix count',fsize(fsubst(p,'n',S(N)))==13+length+counter)
        check(name+' expanded axiom count',fsize(wrapper(p))==42+3*length+counter)
        check(name+' old restricted guard axiom count',fsize(wrapper(old))==54+6*length+counter)
        check(name+' exact active saving',fsize(wrapper(old))-fsize(wrapper(p))==12+3*length)
        check(name+' closed output',not ffree(wrapper(p)))
        check(name+' two object variable names',allnames(wrapper(p)) <= {'n','a'})
        rows.append({'example':name,'term_size_sum':length,'n_occurrences':counter,
                     'rigid_matrix':fsize(p),'rigid_axiom':fsize(wrapper(p)),
                     'old_guard_on_same_A_axiom':fsize(wrapper(old))})

    for name,body in bodies.items():
        r=reset(name); t=transition(name,body)
        check(name+' reset stationary',fsubst(r,'n',S(N))==r)
        check(name+' transition stationary',fsubst(t,'n',S(N))==t)
        check(name+' reset matrix count',fsize(r)==8)
        check(name+' reset expanded count',fsize(wrapper(r))==29)
        check(name+' transition matrix count',fsize(t)==7+tsize(body)+3*occ(body,'v'))
        check(name+' transition expanded count',fsize(wrapper(t))==26+3*tsize(body)+9*occ(body,'v'))
        check(name+' stationary closed outputs',not ffree(wrapper(r)) and not ffree(wrapper(t)))
        check(name+' stationary two names',allnames(wrapper(r))|allnames(wrapper(t)) <= {'n','a'})

    captured=fsubst(All('a',Eq(N,A)),'n',A)
    check('capture-free rename',captured==All('a_0',Eq(A,V('a_0'))))
    check('capture-free resulting free set',ffree(captured)=={'a'})
    try:
        rigid(V('extra'),Z)
    except ValueError:
        check('reject third dynamic variable',True)
    else:
        raise AssertionError('third dynamic variable accepted')
    return {'status':'PASS','checks':len(checks),'scope':'finite syntax and active AST counts only',
            'formulas':{'rigid_matrix':'12+L','rigid_axiom':'42+3L+k',
                        'old_guard_same_A_matrix':'16+2L','old_guard_same_A_axiom':'54+6L+k',
                        'saving_per_expanded_dynamic_axiom':'12+3L'},'examples':rows}

if __name__=='__main__':
    print(json.dumps(run(),indent=2))
