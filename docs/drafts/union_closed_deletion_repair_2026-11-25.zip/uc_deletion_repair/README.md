# Deletion-repair certificates for Frankl abundance

Research note, 25 November 2026. Main deliverable: `paper.pdf` (9 pages), with `paper.tex` as the complete LaTeX source.

## Principal results

The conditional deletion-repair theorem compares exact trace counts of distinct supported subsets of arbitrary hypergraphs. Its consequences for the dual incidence representation of union-closed families include improved sufficient degrees for pointwise strict half-frequency, an irregular degree-sensitive result, and an asymptotic formula for the new sufficient threshold. The improvement is relative to the explicitly identified ProveIt lopsided local lemma draft; at every new tabulated threshold, the earlier asymmetric certificate is infeasible. The full union-closed sets conjecture and historical priority are not established.

## Files and reproduction

- `paper.tex`, `paper.pdf`: complete paper and compiled PDF.
- `verify.py`: Python 3.10+ standard-library-only verifier; fixed-denominator integer interval arithmetic, exact finite counting and construction checks. No dependencies or internet access.
- `thresholds.csv`: generated numerical certificates (strict lower frequencies, old and new sufficient degrees).
- `verification.txt`: actual output of the verifier.
- `provenance.md`: related repository drafts and public references; precise limits of the review.
- `Makefile`: build and audit targets.
- `SHA256SUMS`: content hashes of these files.

From the extracted directory:

```sh
python3 verify.py
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
sha256sum -c SHA256SUMS  # before rebuilding files
```

Run `python3` without `-O` (the verifier uses assertions). The audit is supplemental to the mathematical proof, not a formal proof assistant verification. The PDF was compiled twice and rendered for visual inspection. No changes were made to the GitHub repository.
