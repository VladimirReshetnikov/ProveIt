# Provenance and comparison scope

The user's specified sources were the Wikipedia article on Frankl's conjecture and the ProveIt `docs/drafts` directory. The directory was listed through the GitHub connector. Ten relevant ZIP archives were opened via their base64 file content, and their TeX abstracts and section headings extracted. The central text of the lopsided certificate paper (including the duality, negative-dependence proof, asymmetric certificate, degree thresholds and irregular corollary) was read directly. No repository changes were made.

## Repository antecedents

Directory: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

Direct primary comparator: https://github.com/VladimirReshetnikov/ProveIt/blob/main/docs/drafts/union_closed_lopsided_certificates_2026-11-25.zip

Blob SHA for that archive: `6a4907063eaf84961dcfacea3718ebf7741ff100`. Internal source: `uc_lopsided/paper.tex`.

The ordinary LLL comparison and its earlier joint-laws source are reported in that draft (the joint-laws source was not itself opened in this session). The new deletion-repair comparison uses exactly the asymmetric inequalities in the lopsided draft. The proof of infeasibility is not a statement about every possible LLL variant or every previously known sufficient structural condition.

Ten archives reviewed at abstract/heading level (central text also read for the lopsided archive):

| ZIP name | Git blob SHA |
|---|---|
| union_closed_dense_core_2026-11-25.zip | b1c269b2ae1cdb03f91797a2bf840e96730c5934 |
| union_closed_signature_interfaces_2026-11-25.zip | 7d715274e013371d5d4156b461f970c50c1f9c00 |
| union_closed_rank_transport_2026-11-25.zip | f4c375d5ae9b7337ed4e542950da3d602be537be |
| union_closed_defective_substitution.zip | 14d8202bb57108a1908e62bec65918ac030e7571 |
| union_closed_antichain_shadows_2026-11-25.zip | ce0aa9b6412a1196261afacbb8deb9954fb7ead7 |
| union_closed_lopsided_certificates_2026-11-25.zip | 6a4907063eaf84961dcfacea3718ebf7741ff100 |
| union_closed_five_type_obstructions_2026-11-25.zip | 031a30363602a04b7a35a4e3194f484a2f076a9c |
| union_closed_redundant_core_2026-11-25.zip | 18cd1e26f63dee50486533964e3fbf085660af09 |
| union_closed_cycle_certificates.zip | 78e17f9a3659b69b95c53e3c54e0a8f821a365b8 |
| union_closed_uniform_threshold_2026-11-25.zip | 14fa30e81e9018fbf4664e4c6a4927f74ef8940a |

## Public sources

- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture — statement and background.
- https://arxiv.org/abs/2211.09055 — Gilmer's entropy breakthrough (background).
- https://arxiv.org/abs/2610.02295 — Costa and Sadhu, 2026, reports 0.3828852549667978 universal frequency.
- https://quantavane.com/major-results/union-closed-sets-conjecture/ — November 2026 announcement of 0.38317525996679..., not independently validated in this work.
- https://mathworld.wolfram.com/Union-ClosedSetsConjecture.html — background and status.

Searches concerned regular linear support hypergraphs, union-closed frequency, local-lemma certificates and contemporary universal bounds. No exact match for the deletion-repair inequality or the improved thresholds was located in that limited review. The other archives and all mathematical literature were not exhaustively reviewed. Accordingly, the claims are proved partial results and a concrete improvement over the compared draft, with originality/priority provisional.
