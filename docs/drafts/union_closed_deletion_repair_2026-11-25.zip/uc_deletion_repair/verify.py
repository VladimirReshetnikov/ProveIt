#!/usr/bin/env python3
"""Reproduce numerical certificates and small finite combinatorial audits.
All decisive comparisons use integer intervals or exact fractions.
No network, third-party packages, or floating-point arithmetic required.
"""
from fractions import Fraction as F
from itertools import combinations
from math import comb
from random import Random
from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parent
SCALE = 1 << 128

# Nonnegative intervals with endpoints in SCALE^{-1} Z.
def frac(p, q=1):
    assert p >= 0 and q > 0
    return p*SCALE//q, (p*SCALE+q-1)//q

def add(a,b): return a[0]+b[0], a[1]+b[1]
def sub(a,b):
    assert a[0] >= b[1]
    return a[0]-b[1], a[1]-b[0]
def mul(a,b):
    return a[0]*b[0]//SCALE, (a[1]*b[1]+SCALE-1)//SCALE

def power(a,n):
    assert n >= 0
    ans=frac(1)
    while n:
        if n&1: ans=mul(ans,a)
        n//=2
        if n: a=mul(a,a)
    return ans

def below(a,b): return a[1] < b[0]
def above(a,b): return below(b,a)

def bound(r,d,j=None,D=None):
    # d = min degree, D = upper degree on j chosen vertices.
    if j is None: j=r
    if D is None: D=d
    q=frac((1<<(r-1))-1,1<<(r-1))
    u=power(q,d-1)
    z=sub(frac(1),u)
    L=frac(1)
    for s in range(1,j+1):
        L=add(L,mul(frac(comb(j,s)),power(z,r-s+s*(r-1)*(D-1))))
    return L

def grouping(r,d):
    q=frac((1<<(r-1))-1,1<<(r-1))
    u=power(q,d-1)
    # Sufficient for 1-q^(d-k) >= (1-q^(d-1))^k, all 1<=k<=r.
    return above(mul(power(q,r-1),sub(frac(2),u)),frac(1))

def fixed_floor_frequency(L, places=6):
    # 1 - 1/L is increasing; take lower interval endpoint.
    p=10**places
    numerator=p*(L[0]-SCALE)
    lower=numerator//L[0]
    assert numerator > lower*L[0]  # strict decimal bound
    return lower

def print_dec(n,places=6): return f'{n//10**places}.{n%10**places:0{places}d}'

def numeric():
    rows=[]
    for r,d,old,prior in zip(range(3,9),(11,32,81,195,451,1021),
                             (14,40,100,237,541,1206),(32,89,221,517,1169,2589)):
        M=1<<(r-1);q=frac(M-1,M);b=(r-1)*d
        assert d>r and d-1>=M-1 and grouping(r,d)
        L=bound(r,d)
        assert above(L,frac(2))
        assert grouping(r,d-1) and below(bound(r,d-1),frac(2))
        # On a b-regular co-incidence graph, any asymmetric certificate
        # from the prior draft requires p <= max_a a*(1-a)^b.
        p=mul(frac(1,2),power(q,d))
        max_lll=mul(frac(1,b+1),power(frac(b,b+1),b))
        assert above(p,max_lll)
        lower=print_dec(fixed_floor_frequency(L))
        rows.append((r,prior,old,d,lower,'impossible'))
        print(f'r={r}: threshold {d}, frequency > {lower}; preceding d fails this bound; old asymmetric LLL impossible')
    assert grouping(3,13) and above(bound(3,13,2,13),frac(2))
    assert below(bound(3,12,2,12),frac(2))
    print('Irregular triples: min degree 13, two degree-13 vertices per edge: frequency >',print_dec(fixed_floor_frequency(bound(3,13,2,13))))
    with (ROOT/'thresholds.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(('uniformity','ordinary_LLL_draft','lopsided_LLL_draft','deletion_repair_threshold','strict_frequency_lower_decimal','prior_asymmetric_certificate_at_new_degree'));w.writerows(rows)

# Small exact audits using bit masks.
def submasks(a):
    b=a
    while True:
        yield b
        if b==0: break
        b=(b-1)&a

def good(H,n):
    out=[]
    for y in range(1<<n):
        c=0
        for e in H:
            if e&y==e:c|=e
        if c==y:out.append(y)
    return out

def best_failure(H,w,D,fixed):
    # Minimum product over disjoint residual petals; no petals -> 1.
    petals={e&~(fixed|w) for e in H if e&w and not e&D}
    if 0 in petals: return F(0)
    dp={0:F(1)}
    for p in sorted(petals):
        q=1-F(1,1<<p.bit_count())
        for used,v in list(dp.items()):
            if not p&used:
                a=p|used;dp[a]=min(dp.get(a,F(1)),v*q)
    return min(dp.values())

def check(H,n,P=0,Q=0,all_anchors=True,rng=None):
    H=tuple(e for e in H if not e&Q)
    G=[y for y in good(H,n) if y&P==P]
    if not G:return 0
    anchors=[a for a in good(H,n) if a]
    if not all_anchors: anchors=rng.sample(anchors,min(3,len(anchors)))
    tests=0
    for A in anchors:
        full=[y for y in G if y&A==A]; assert full
        for D in submasks(A&~P):
            if not D:continue
            target=A&~D
            n_target=sum(y&A==target for y in G)
            safe=tuple(e for e in H if not e&D)
            strengthened=[]
            for y in full:
                c=0
                for e in safe:
                    if e&y==e:c|=e
                if c==y&~D:strengthened.append(y)
            assert len(strengthened)==n_target
            assert {y&~D for y in strengthened}=={y for y in G if y&A==target}
            affected=0
            for e in H:
                if e&D:affected|=e&~D
            W=F(1)
            for i in range(n):
                w=1<<i
                if affected&w:W*=1-best_failure(H,w,D,A|P)
            assert F(n_target,len(full))>=W, (H,P,Q,A,D,n_target,len(full),W)
            tests+=1
    return tests

def dual_check(H,n):
    G=good(H,n)
    primal={sum(1<<i for i,e in enumerate(H) if e&s) for s in range(1<<n)}
    dual={sum(1<<i for i,e in enumerate(H) if e&y!=e) for y in G}
    assert primal==dual and len(G)==len(primal)

def systems(edges):
    for m in range(1<<len(edges)):
        yield tuple(e for i,e in enumerate(edges) if m>>i&1)

def finite_audit():
    count=0;families=0
    # Every hypergraph on up to three labeled vertices; every anchor and
    # every positive/negative conditioning on disjoint bits.
    for n in range(1,4):
        for H in systems(list(range(1,1<<n))):
            dual_check(H,n);families+=1
            for P in range(1<<n):
                for Q in submasks(((1<<n)-1)&~P):
                    count+=check(H,n,P,Q)
    print(f'All hypergraphs on <=3 vertices, all P,Q: {families} systems; {count} nonempty deletion tests')
    # All graph and triple systems on five labeled vertices; all anchors.
    n=5;cases=0;checks=0
    for r in (2,3):
        es=[sum(1<<i for i in a) for a in combinations(range(n),r)]
        for H in systems(es):
            dual_check(H,n);cases+=1;checks+=check(H,n)
    print(f'All uniform 2- and 3-edge hypergraphs on 5 vertices: {cases} systems; {checks} deletion tests')
    # Reproducible irregular mixed-edge-size examples with conditioning.
    rng=Random(20261125);checks=0
    for _ in range(300):
        n=6;H=tuple(rng.sample(range(1,1<<n),rng.randrange(1,14)))
        P=rng.randrange(1<<n);Q=rng.randrange(1<<n)&~P
        dual_check(H,n)
        checks+=check(H,n,all_anchors=False,rng=rng)
        checks+=check(H,n,P,Q,all_anchors=False,rng=rng)
    print(f'300 seeded mixed hypergraphs on 6 vertices: {checks} deletion tests')

# Check explicit unbounded-construction parameters on sample primes.
def affine(r,d,m):
    E=[frozenset(i*m+(a+i*b)%m for i in range(r)) for a in range(m) for b in range(d)]
    assert len(set(E))==m*d and all(len(e)==r for e in E)
    deg=[0]*(r*m);pairs=set();adj=[set() for _ in deg]
    for e in E:
        for v in e:deg[v]+=1
        for u,v in combinations(sorted(e),2):
            assert (u,v) not in pairs;pairs.add((u,v));adj[u].add(v);adj[v].add(u)
    assert set(deg)=={d}
    seen={0};todo=[0]
    while todo:
        v=todo.pop()
        for w in adj[v]-seen:seen.add(w);todo.append(w)
    assert len(seen)==r*m
    return E

def examples():
    for r,d,m in ((3,11,11),(3,11,13),(4,32,37),(5,81,83),(3,13,13)):
        affine(r,d,m)
    print('5 affine examples: exact regularity, linearity and connectivity verified')

if __name__=='__main__':
    numeric();finite_audit();examples();print('All checks passed.')
