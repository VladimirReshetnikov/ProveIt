A COUNTDOWN RETRACTION FOR iPRA RESEARCH
9 November 2026 (Pacific time)

Outcome
-------
The report proves the previously unproved bouncing-predecessor retraction
L(n,A(n,a))=a over the stated primitive-recursive source theory with
coverage, separation, and uniqueness for W(0)=1, W(Sx)=x.
A Boolean trajectory lift also derives ordinary predecessor uniqueness;
full actual-value stationarity and absorbing retraction follow.

This is not a claim that the bouncing-predecessor theory alone has been
proved equivalent to full iPRA. Actual equality reflection remains open
in this investigation. No new complete checker below all three pinned
coordinates (299 tokens / 340 AST nodes / 815 bytes) has been found.

A separate, complete QI/Case native presentation is proved equiconsistent
and bi-interpretable with full iPRA. It factors the current Choice calculus
with exact linear proof-node bounds. Its supplied standalone checker has
304 normalized tokens, 339 AST nodes, and 948 normalized bytes.
The one-node AST saving against the pinned drafts is an implementation
effect: the same import/driver cleanup gives Choice 300/334/893. The new
QI/Case presentation is larger than that matched control in all measures.
Rejections preserve an exception traceback on stderr; stdout and status
retain the documented ACCEPT/REJECT interface.

Start here
----------
ipra_countdown_retraction.pdf  Compiled report.
ipra_countdown_retraction.tex  Complete self-contained LaTeX source.
main.tex and sections/        Editable source organization.
code/qi/kernel.py            Complete QI/Case proof checker.
code/qi/FORMAT.txt           Exact raw certificate syntax and aliases.
code/qi/correctness.md       Written soundness/completeness obligations.
code/qi/certificates.json    Focused positive and negative packets.
code/qi/matched_choice.py    Matched implementation control.
code/driver_controls/       Choice profiles with only driver simplification.
code/check_countdown.py      Bounded standard-number arithmetic checks.
reference/choice/           Three unchanged current comparison checkers.
reference/compact_inventory/ 34 frozen compact comparison sources.
evidence/                   Provenance, measurements, and check receipts.

Reproduce
---------
Use CPython 3.12 for the exact reported AST/unparse measurements:

    python3 reproduce.py

To rebuild the PDF, install a standard TeX distribution with latexmk,
pdflatex, and the ordinary packages named in main.tex, then run:

    python3 build.py

The PDF and expanded source are already included; no rebuild is needed
to read the deliverable.

Verification scope
------------------
The source-theory metatheorems are written proofs independently reviewed
by assistant agents. They are not claimed to be Lean/Rocq formalizations.
The complete checker has a written decoding/soundness/completeness argument
and focused public-input tests. Arithmetic numeric tests check finite
standard inputs only and do not establish nonstandard-model validity.

The native introduction translations are new here. The scalar numerical
encoding and scalar-to-PR bridge are inherited from the Choice draft.
The report also gives a self-contained full-PR native equivalence proof.

Provenance
----------
Repository: VladimirReshetnikov/ProveIt
Commit: 1d0d5f030546d707992b4cc4194ea6971fe84938
All 26 top-level docs/drafts ZIP sizes and Git blob hashes were verified.
Exact SHA-256 identities and member paths are in evidence/.
Original repository material is provided under its included license.
The QI/Case code records its inherited kernel license separately.
