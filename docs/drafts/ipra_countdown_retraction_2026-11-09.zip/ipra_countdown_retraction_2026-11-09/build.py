"""Expand the report into one TeX source and compile it."""
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def expand(path, stack=()):
    path = path.resolve()
    if path in stack:
        raise ValueError("Cyclic TeX input")
    text = path.read_text()
    def replace(match):
        child = ROOT / match.group(1)
        if child.suffix != ".tex":
            child = child.with_suffix(".tex")
        return expand(child, stack + (path,))
    return re.sub(r"\\input\{([^}]+)\}", replace, text)


if __name__ == "__main__":
    target = ROOT / "ipra_countdown_retraction.tex"
    target.write_text(expand(ROOT / "main.tex"))
    subprocess.run(["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
                    target.name], cwd=ROOT, check=True)

