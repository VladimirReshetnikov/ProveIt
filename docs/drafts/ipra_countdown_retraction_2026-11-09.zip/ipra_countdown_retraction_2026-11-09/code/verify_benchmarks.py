"""Reproduce whole-module metrics and replay frozen Choice controls."""
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path
from source_measure import metrics

ROOT = Path(__file__).resolve().parents[1]
CHOICE = ROOT / "reference/choice"
EXPECTED = {
    "tokens.py": (299, 345, 880, "b2b3fe22cc787e8150757df73e86e1d702882699f5d632773a7f68f4f9f1a045"),
    "structure.py": (304, 340, 902, "9df771c688e0dae1a9510f85e6a93066e611615a3951519cdc31ff8ec3dbec8c"),
    "bytes.py": (307, 353, 815, "7fdc5c74bb741f76e7909a4ab894fa674f7bb57adda8db6e88d9971862bf65cb"),
}


def main():
    rows, replays = [], 0
    cases = json.loads((CHOICE / "focused_certificates.json").read_text())["cases"]
    for name, expected in EXPECTED.items():
        path = CHOICE / name
        measured = metrics(path)
        actual = tuple(measured[k] for k in ("normalized_tokens", "ast_nodes", "normalized_bytes", "sha256"))
        if actual != expected:
            raise RuntimeError({"changed_frozen_source": name, "actual": actual, "expected": expected})
        rows.append({"file": str(path.relative_to(ROOT)), **measured})
        for case in cases:
            for optimized in (False, True):
                command = [sys.executable] + (["-O"] if optimized else []) + [str(path)]
                process = subprocess.run(command, input=json.dumps(case["packet"]), text=True,
                                         capture_output=True, timeout=10)
                target = ("ACCEPT\n", "", 0) if case["accept"] else ("REJECT\n", "", 1)
                if (process.stdout, process.stderr, process.returncode) != target:
                    raise RuntimeError({"checker": name, "case": case["name"], "optimized": optimized})
                replays += 1
    new = ROOT / "code/qi/kernel.py"
    rows.append({"file": str(new.relative_to(ROOT)), **metrics(new)})
    matched = ROOT / "code/qi/matched_choice.py"
    rows.append({"file": str(matched.relative_to(ROOT)), **metrics(matched)})
    driver_rows, driver_replays = [], 0
    for name in EXPECTED:
        path = ROOT / "code/driver_controls" / name
        measured = metrics(path)
        driver_rows.append({"file": str(path.relative_to(ROOT)), **measured})
        for case in cases:
            for optimized in (False, True):
                command = [sys.executable] + (["-O"] if optimized else []) + [str(path)]
                process = subprocess.run(command, input=json.dumps(case["packet"]), text=True,
                                         capture_output=True, timeout=10)
                target = ("ACCEPT\n", 0) if case["accept"] else ("REJECT\n", 1)
                if (process.stdout, process.returncode) != target:
                    raise RuntimeError({"driver_control": name, "case": case["name"]})
                if case["accept"] and process.stderr:
                    raise RuntimeError("Unexpected stderr on acceptance")
                if not case["accept"] and "Traceback (most recent call last):" not in process.stderr:
                    raise RuntimeError("Missing intentional rejection traceback")
                driver_replays += 1
    source_count = 0
    for entry in json.loads((ROOT / "evidence/comparator_sources.json").read_text())["sources"]:
        path = ROOT / entry["file"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise RuntimeError("Changed comparison source: " + entry["file"])
        source_count += 1
    result = {
        "python": platform.python_version(),
        "commit": "1d0d5f030546d707992b4cc4194ea6971fe84938",
        "archive_count": 26,
        "measurement_boundary": "Whole standalone module including parser, scope/substitution, rules, and verdict driver.",
        "choice_coordinate_envelope": {"normalized_tokens": 299, "ast_nodes": 340, "normalized_bytes": 815},
        "single_program_attains_envelope": False,
        "frozen_compact_source_hashes_verified": source_count,
        "choice_focused_cases": len(cases),
        "choice_complete_CLI_replays": replays,
        "driver_control_CLI_replays": driver_replays,
        "driver_control_coordinate_envelope": {
            key: min(row[key] for row in driver_rows)
            for key in ("normalized_tokens", "ast_nodes", "normalized_bytes")
        },
        "driver_controls": driver_rows,
        "programs": rows,
        "all_passed": True,
    }
    (ROOT / "evidence/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

