"""Complete QI/Case native iPRA checker.

Unary goals admit induction only when their body is a literal equation;
paired goals admit retained-base case introduction for arbitrary matrices.
The inherited numerical, Eq/Q/D and elimination semantics are preserved.
Rejections retain the original exception traceback on stderr. See FORMAT.txt
and correctness.md for decoding and proof obligations. Only standard json
is imported by this standalone checker.
"""
from json import load
k = 0


def i(a, t=None, d=0):
    try:
        return [i(b, t, d + b' \2\1\4'[len(a)]) for b in a + []]
    except:
        return a if k <= a < d else d % 2 and i(t, d=1)


def c(a, g, s=0):
    global k
    if i(a) in g:
        return 1
    m, t = q()
    if m:
        1 / c(m, g)
        u = t
        try:
            try:
                t, = m
            except:
                s, u = m
        except:
            h = m[2:]
        else:
            return i(t, u) == a and c(i(t, s), g)
    elif t:
        try:
            h, = a
            u, v = a = h
        except:
            a = i(a[2], t, 2)
            h = i(a, 0)
    else:
        (n, t, r), b = a
        if n:
            n, = n
            t = i(r, [n, t, r], 1)
        return b == t
    k -= 1
    return c(i(a, [k]), g + [i(h, k)])


try:
    q = load(open(0)).pop
    1 / c(q(), [])
    print('ACCEPT')
except:
    print('REJECT')
    raise
