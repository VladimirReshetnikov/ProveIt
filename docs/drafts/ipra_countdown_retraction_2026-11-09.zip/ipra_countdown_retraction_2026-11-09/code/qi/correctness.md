# QI/Case: exact native equivalence and checking obligations

## Complete inference interface

Numerical syntax and its two initialized-iteration computation schemas are the
inherited ones. Formulas are equations, unary Q, and paired D. Contexts are
finite reusable lists. Their meanings are Q_y B := B(0) -> forall y B(y) and
D_xy B := exists x (B(x,0) -> forall y B(x,y)). Equality remains actual equality.

The rule inventory is I0, IS, Hyp, equality transport, QE, DE, and these two
introductions. Case DI derives D_xy B from Gamma, B(t,0) |- B(t,Sz), for arbitrary
B, with z fresh for Gamma, t and fixed parameters. Atomic QI derives Q_y E from
Gamma, E(z) |- E(Sz), for a literal equation E and z fresh for Gamma and fixed
parameters. QE derives B(t) from Q_y B and B(0). DE opens a proved paired formula
at a fresh existential parameter a, retains Q_y B(a,y), and proves a conclusion
independent of a. Transport replaces a numerical parameter in an arbitrary
native formula motive using an already proved equation. All substitutions are
capture avoiding and every displayed local assumption is discharged.

## Theorem: same entire native consequence relation as Choice-DI

Choice has the same other rules and two choices of D introduction: retain B(t,0)
for any B, or retain E(t,z) when E is a literal equation. Numerical terms and
formula meanings are identical.

For new-to-Choice translation, Case DI is already a Choice rule. Translate a
QI step using Choice progress DI with an unused existential coordinate u and
witness zero. It yields D_{u,y}E(y). DE opens precisely Q_y E(y), and Hyp returns
it. This replaces one QI node by DI, DE and Hyp, preserving the step subtree.
A proof with N nodes and s QI nodes therefore translates to N+2s <= 3N nodes.

For Choice-to-new translation, only progress DI changes. Suppose its step is
pi: Gamma, E(t,z) |- E(t,Sz). Start an outer Case DI with witness t. Under its
newly retained E(t,0), weaken pi and rename its step eigenparameter to a fresh v.
Atomic QI now yields Q_y E(t,y), with t a fixed parameter. QE, supplied with the
retained E(t,0) by Hyp, produces E(t,Sz). Close outer Case DI. The old progress
node has become QI, QE, Hyp and DI; the old premise appears once. Thus N old
nodes with r progress-DI nodes translate to N+3r <= 4N nodes. Case introductions
and every other rule are copied. Freshening preserves all eigenconditions.

Structural weakening, contraction, exchange, ordinary cut, and substitution
are admissible by induction on these finite derivations. Literal equationhood
is invariant under numerical substitution. In the cut step, replace a use of the
cut hypothesis by its proof and freshen all local eigenparameters first.

Consequently every sequent is preserved literally in both directions. This is
stronger than equality of closed equational theorems. The inherited full-iPRA
bi-interpretations retain exactly their syntax maps and internally provable
whole-domain composites. The new result adds no quotient, domain restriction,
equality-reflection assumption, classical axiom, or stronger induction.

## Soundness of the new kernel branch

All unchanged branches and the opening routine are inherited from the frozen
strict structural Choice checker. FORMAT.txt states their complete decoding.
The first traversal i(a) checks the root-scoped goal before a proof cell or fresh
parameter is used. In a unary goal, h,=a selects its matrix. The additional
u,v=a=h forces it to be a literal equation (malformed scalar or nonarray trees
already fail the traversal). The chained assignment then exposes exactly the counter slot in a;
the common tail checks E(Sk) while retaining E(k), with fresh k. This is QI.

If unary parsing fails, the fallback requires a[2]. For a genuinely unary
goal this necessarily fails; in particular a compound Q body cannot acquire
an IH through the fallback. Successful fallback has a paired goal because the
root traversal rejected all arities above three and a[2] excludes shorter ones.
The inherited witness opening gives A(y)=B(t,y). Setting h=i(A,0) fixes the base.
The common tail checks A(Sk) while retaining only A(0), exactly Case DI.

The used witness image was root-checked before decreasing the freshness floor.
It therefore cannot contain the newly allocated rigid label. In QI the payload
is unused metadata and is not a witness; it has no mathematical effect.
Existing meaningful retained parameters stay above the newly decreased floor.
The same common-motive and fresh-label arguments as the inherited checker
therefore apply without change to the two new branch interpretations.

Every successful execution has a finite trace. Induction on that trace extracts
a native derivation: each unchanged branch has its inherited interpretation,
and the two new branch cases are as above. Thus every accepted public goal
decodes to a closed native theorem.

## Canonical completeness

Use the same canonical raw encoding and depth-first proof schedule as Choice.
A QI node is encoded by a unary goal [E] and an instruction [0,[0,0,0]]. The
payload is deliberately a truthy closed zero box but is unused. Compile the
step under the next fresh rigid label; the native counter in E is opened by
the common tail. A Case DI node has a paired goal and [0,box(t)] or [[],box(t)],
where box(t)=I(0,t;u.0) ensures a truthy well-scoped witness representation.
The computation box(t)=t and transport recover the original witness instances.
No Case/Ind head distinction remains.

Compile all unchanged nodes using the inherited compiler schedule, pruning
automatic hypothesis leaves before assigning fresh labels. The branch audit
and opening lemmas identify every recursive call with its intended premise.
Induction on the finite native derivation gives an accepted packet whenever
finite execution resources suffice. Reverse the execution order of instruction
cells and append the closed goal for the public JSON representation.

This is a written universal compiler argument. The provided validate.py is a
focused fixture producer and replay harness, not an implementation of this
universal native-proof compiler and not a Lean/Rocq formalization.

## Termination and honest complexity comparison

Every non-Hyp checking call consumes a remaining packet cell. Opening recurses
through proper subtrees; a substituted image is checked at numerical root with
no further image. Finite parsed JSON trees and finite packet stacks therefore
give mathematical termination. Resource exhaustion can reject large valid
proofs; it does not create an acceptance.

The unchanged whole-source normalizer reports 304 normalized tokens, 339 AST
nodes and 948 normalized bytes for this kernel.py. The AST coordinate is one
below the original pinned corpus envelope 299/340/815, but this is not a matched
mathematical size improvement: applying the same import and rejection-driver
changes to Choice gives matched_choice.py at 300 tokens, 334 AST nodes and
893 bytes. The QI/Case kernel exceeds this matched control in every coordinate.
The theorem factors induction away from existential witnesses, but its
implementation does not satisfy the requested global strict-minimum goal.
No absolute minimality or literature-wide novelty is claimed.

## Local implementation changes and exact preservation argument

The originally validated QI/Case implementation is changed in three ways.

1. `u,v=h` followed by `a=h` is replaced by `u,v=a=h`. Python evaluates the
   right-hand side once and assigns targets left to right. The two-element
   unpack therefore still happens first; if it fails, `a` is not assigned.
   The original exception fallback is unchanged. This preserves every
   inference branch and its literal-equation gate.
2. `from json import load` and `load(open(0))` obtain and invoke exactly the
   same standard JSON-loading function as `import json` and
   `json.load(open(0))`. The input language is still a complete JSON array
   read from stdin, including multiline input.
3. After printing REJECT, a bare `raise` propagates the exception already
   responsible for rejection rather than constructing a replacement
   `SystemExit(1)`. Successful executions are untouched. On a rejected finite
   packet this preserves stdout REJECT and exit status one, and intentionally
   adds the original exception traceback on stderr. No proof-acceptance
   decision is changed. External process interruption is outside this
   finite-certificate interface.

The matched Choice control applies changes 2 and 3 to the unchanged structural
Choice program. It does not apply the QI-specific chained assignment because
that statement is absent from Choice. No producer or test harness is imported
by either checker. These implementation refactorings are distinct from the
mathematical QI/Case equivalence theorem.
