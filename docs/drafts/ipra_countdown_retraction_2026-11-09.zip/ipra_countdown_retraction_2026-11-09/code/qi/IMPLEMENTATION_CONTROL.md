# Selected complete kernels and implementation controls

The selected `kernel.py` implements exactly the QI/Case presentation described
in `FORMAT.txt` and `correctness.md`. The mathematical change is the earlier
witness-free atomic QI / paired Case factorization. The source refinements
below do not add a further mathematical axiom reduction.

| Complete program | Tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| Original QI/Case | 309 | 348 | 971 |
| Selected QI/Case | 304 | 339 | 948 |
| Original structural Choice | 304 | 340 | 902 |
| Choice with the same import and driver changes | 300 | 334 | 893 |

All counts use the unchanged whole-module normalizer. The selected QI/Case
program has one fewer AST node than the pinned 340-node corpus coordinate,
but it is larger than its matched Choice control in all three measures. It
therefore does not establish a matched mathematical checker-size improvement,
nor does it beat the complete pinned envelope 299/340/815.

## Driver-only control for the original Choice family

Changing only the terminal `raise SystemExit(1)` to a bare `raise` gives:

| Original Choice profile after driver-only change | Tokens | AST nodes | Bytes |
|---|---:|---:|---:|
| Token profile | 295 | 341 | 866 |
| Structural profile | 300 | 336 | 888 |
| Byte profile | 303 | 349 | 801 |

The family envelope becomes 295/336/801, attained by different programs.
These are the same proof calculi and the same acceptance decisions. REJECT
still appears on stdout with exit status one; stderr intentionally contains
the original exception traceback. This change exposes an interface-dependent
measurement sensitivity. It must not be described as a mathematical
breakthrough or credited to the QI/Case theorem.

## Validation and limits

`python3 validate.py` replays the QI/Case fixtures, malformed-input controls,
and three explicit fault mutations against the selected kernel. It separately
replays the frozen Choice fixtures and parser controls against the matched
Choice control. Both ordinary and optimized Python executions are checked.
The receipts include exact source hashes and complete-source metrics.

The final reproduction command also measures the three driver-only Choice
controls in code/driver_controls and replays the frozen Choice fixtures against
them. This is finite regression evidence. Universal preservation of the
selected source transformations is the local argument in correctness.md,
while native soundness/completeness and bi-interpretability remain the
separately supplied written mathematical proofs. No formal proof-assistant
verification is claimed.
