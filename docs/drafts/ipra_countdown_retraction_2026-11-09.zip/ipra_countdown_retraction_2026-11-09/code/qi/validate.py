"""Untrusted focused regression harness; not a proof kernel or metatheory proof."""
import ast
import copy
import hashlib
import io
import json
import platform
import subprocess
import sys
import tempfile
import tokenize
from pathlib import Path

HERE = Path(__file__).resolve().parent
KERNEL = HERE / 'kernel.py'
MATCHED = HERE / 'matched_choice.py'


def metrics(path):
    tree = ast.parse(path.read_text())
    class Strip(ast.NodeTransformer):
        def clean(self, node):
            self.generic_visit(node)
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                node.body = node.body[1:]
            return node
        visit_Module = clean
        visit_FunctionDef = clean
        visit_AsyncFunctionDef = clean
        visit_ClassDef = clean
    tree = ast.fix_missing_locations(Strip().visit(tree))
    normalized = ast.unparse(tree) + '\n'
    ignore = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
              tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
              tokenize.ENDMARKER}
    return {'normalized_tokens': sum(t.type not in ignore for t in
                                     tokenize.generate_tokens(io.StringIO(normalized).readline)),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode()),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def fixtures():
    box = [0, 0, 0]
    equation = [[5, [0], 2], [0]]
    hypothesis = [[-1, [0], 2], [0]]
    motive = [[[-1], [0], 2], 1]
    identity = [[0, 0], [hypothesis, motive], [0, box], [equation]]
    missing_minor = copy.deepcopy(identity)
    missing_minor.pop(0)
    wrong_target = copy.deepcopy(identity)
    wrong_target[-1][0][1] = box
    param_equation = [[5, 7, 2], 3]
    param_hypothesis = [[-2, [-1], 2], [-1]]
    param_motive = [[[-2], [-1], 2], 1]
    parameter_identity = [
        [0, 0], [param_hypothesis, param_motive], [0, box], [[], box],
        [[[param_equation], [param_equation], [param_equation]], 0],
        [[param_equation]],
    ]
    captured_counter = copy.deepcopy(parameter_identity)
    captured_counter[1][0][0][0] = -1
    false_base = [
        [0, 0], [[0, [0]], [[5, [0], [-1]], [0]]], [0, 0],
        [[[[0], [0], [-1]], [-1]], [1, [0]]], [0, box],
        [[[1, [0]], [1, [0]], [1, [0]]], 0], [[1, [0]]],
    ]
    old_progress_D = [
        [0, 0], [hypothesis, motive], [0, box],
        [[equation, equation, equation], 0], [equation],
    ]
    cases = []
    def add(name, packet, accept, meaning):
        cases.append({'name': name, 'packet': packet, 'accept': accept,
                      'meaning': meaning})
    add('identity_iterator_QI_uses_IH', identity, True,
        'Q_n[I(n,1;u.u)=1], proved by direct atomic QI with a genuine induction-hypothesis use.')
    add('parameter_and_counter_QI', parameter_identity, True,
        'Q_a Q_n[I(n,a;u.u)=a], with distinct captured initializer and induction counter.')
    add('false_base_case_DI', false_base, True,
        'Q_y(y=1), proved through Case DI using its retained false base.')
    add('positive_used_witness', [[0, box], [0, 0, [3, 0]]], True,
        'The paired matrix uses the supplied closed witness.')
    add('QI_without_successor_computation', missing_minor, False,
        'The equation induction step lacks its computation premise.')
    add('QI_changed_conclusion', wrong_target, False,
        'The announced closure differs from the checked induction equation.')
    add('old_progress_packet_is_not_case_DI', old_progress_D, False,
        'A proof requiring an IH cannot use the new paired Case DI.')
    add('compound_Q_body_not_eligible_for_QI', [[0, box], [[[0, 0]]]], False,
        'Direct QI is forbidden when its body is a unary closure, even if that formula is independently provable.')
    add('compound_D_body_not_eligible_for_QI', [[0, box], [[0, 0, [0, 0]]]], False,
        'Direct QI is forbidden when its body is a paired closure.')
    add('truth_body_not_literal_equation', [[0, box], [[]]], False,
        'Direct QI requires an equation, not the raw truth alias.')
    add('captured_induction_counter', captured_counter, False,
        'The IH incorrectly substitutes the outer parameter for the fresh inner counter.')
    add('future_label_in_used_witness', [[0, 0], [0, -1], [0, 0, [3, 0]]], False,
        'A witness used in the matrix cannot capture the eigenparameter about to be allocated.')
    add('negative_free_parameter_in_goal', [[0, 0], [[0, -1, 0], -1]], False,
        'A closed public goal cannot contain a free negative label.')
    add('failed_major_before_compound_intro',
        [[0, 0], [[[0, 0, 0], 0], 0], [1, box], [0, 0, [[0, 0]]]], False,
        'A failing major cannot fall through to introduction.')
    add('failed_major_before_computation',
        [[0, 0], [[[0, 0, 0], [0]], 0], [[0, 0, 0], 0]], False,
        'A failed major cannot fall through to a valid computation.')
    add('canonical_false', [[0, 0], [0, [0]]], False, 'No computation proves 0=1.')
    add('wrong_zero_computation', [[0, 0], [[0, 0, 0], [0]]], False,
        'The claimed output of a zero iterator is wrong.')
    add('malformed_four_child_goal', [[0, 0], [0, 0, 0, 0]], False,
        'Four-child arrays are outside the inherited raw syntax.')
    add('zero_computation', [[0, 0], [[0, 0, 0], 0]], True,
        'Initialized iteration at zero.')
    add('successor_computation',
        [[0, 0], [[[0], 0, [3]], [[0, 0, [3]]]]], True,
        'One successor computation with a bound update state.')
    return cases


def run(path, raw, optimized, expected):
    command = [sys.executable] + (['-O'] if optimized else []) + [str(path)]
    p = subprocess.run(command, input=raw, text=True, capture_output=True, timeout=10)
    expected_result = ('ACCEPT\n', 0) if expected else ('REJECT\n', 1)
    actual = p.stdout, p.returncode
    if actual != expected_result:
        raise RuntimeError({'checker': str(path), 'optimized': optimized,
                            'expected': expected_result, 'actual': actual,
                            'stderr': p.stderr})
    if expected and p.stderr:
        raise RuntimeError('Unexpected stderr on acceptance')
    if not expected and 'Traceback (most recent call last):' not in p.stderr:
        raise RuntimeError('Missing intentional rejection traceback')


def main():
    cases = fixtures()
    replays = []
    for case in cases:
        for optimized in (False, True):
            run(KERNEL, json.dumps(case['packet']), optimized, case['accept'])
            replays.append({'name': case['name'], 'optimized': optimized,
                            'accepted': case['accept']})
    malformed_packets = ['', '[] []', 'null', '"not a packet"', '{}', '[]']
    for raw in malformed_packets:
        for optimized in (False, True):
            run(KERNEL, raw, optimized, False)
            replays.append({'name': 'parser_' + repr(raw), 'optimized': optimized,
                            'accepted': False})

    # Three focused controls confirm that the fixtures exercise the intended gates.
    source = KERNEL.read_text()
    mutants = [
        ('drop_QI_induction_hypothesis',
         source.replace('            u, v = a = h\n', '            u, v = a = h\n            h = i(h, 0)\n'),
         next(c for c in cases if c['name'] == 'identity_iterator_QI_uses_IH'), False),
        ('drop_QI_equation_guard', source.replace('            u, v = a = h\n', '            a = h\n'),
         next(c for c in cases if c['name'] == 'compound_Q_body_not_eligible_for_QI'), True),
        ('drop_freshness_floor', source.replace('k <= a < d', '-1000000 <= a < d'),
         next(c for c in cases if c['name'] == 'future_label_in_used_witness'), True),
    ]
    mutant_receipts = []
    with tempfile.TemporaryDirectory() as directory:
        for name, code, case, expected in mutants:
            path = Path(directory) / (name + '.py')
            path.write_text(code)
            for optimized in (False, True):
                run(path, json.dumps(case['packet']), optimized, expected)
                mutant_receipts.append({'mutation': name, 'fixture': case['name'],
                                        'optimized': optimized, 'accepted': expected})

    matched_replays = []
    matched_cases = json.loads((HERE / 'choice_certificates.json').read_text())['cases']
    for case in matched_cases:
        for optimized in (False, True):
            run(MATCHED, json.dumps(case['packet']), optimized, case['accept'])
            matched_replays.append({'name': case['name'], 'optimized': optimized,
                                    'accepted': case['accept']})
    for raw in malformed_packets:
        for optimized in (False, True):
            run(MATCHED, raw, optimized, False)
            matched_replays.append({'name': 'parser_' + repr(raw), 'optimized': optimized,
                                    'accepted': False})
    result = {'python': platform.python_version(), 'metrics': metrics(KERNEL),
              'matched_choice_metrics': metrics(MATCHED),
              'matched_choice_CLI_replays': len(matched_replays),
              'matched_choice_replays': matched_replays,
              'rejection_interface': 'REJECT on stdout, status 1, original exception traceback on stderr',
              'positive_fixtures': sum(c['accept'] for c in cases),
              'negative_fixtures': sum(not c['accept'] for c in cases),
              'parser_controls': len(malformed_packets),
              'complete_CLI_replays': len(replays),
              'mutation_control_replays': len(mutant_receipts),
              'all_passed': True,
              'scope': 'Focused public-packet replay and three fault controls. This is not a formal proof of universal soundness, completeness, termination, or bi-interpretability.',
              'replays': replays, 'mutation_controls': mutant_receipts}
    (HERE / 'certificates.json').write_text(json.dumps({'cases': cases}, indent=2) + '\n')
    (HERE / 'validation_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('replays','mutation_controls','matched_choice_replays')}, indent=2))


if __name__ == '__main__':
    main()
