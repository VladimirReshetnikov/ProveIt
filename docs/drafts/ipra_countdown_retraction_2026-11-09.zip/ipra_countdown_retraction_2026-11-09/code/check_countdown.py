"""Bounded arithmetic regression for the countdown constructions.

This executes the displayed primitive recurrences on standard integers.
It is not a proof of their validity in arbitrary or nonstandard models.
The report gives the source-theory proof and its exact assumptions.
No proof-assistant verification is claimed by these finite checks.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def pred(x):
    return 0 if x == 0 else x - 1


def bounce(x):
    return 1 if x == 0 else x - 1


def toggle(x):
    return 1 if x == 0 else 0


def iterate(step, n, initial):
    value = initial
    for _ in range(n):
        value = step(value)
    return value


def L(n, a):
    return iterate(bounce, n, a)


def A(n, a):
    return iterate(lambda u: u + 1, n, a)


def parity(n):
    return iterate(toggle, n, 0)


def state(n, a):
    """Return d(a,n), r(n,a) using exactly their coupled recurrences."""
    remaining, after = a, 0
    for _ in range(n):
        after = after + 1 if remaining == 0 else 0
        remaining = pred(remaining)
    return remaining, after


def lifted(n, a):
    remaining, after = state(n, a)
    return parity(after) if remaining == 0 else remaining


def centered(n, a, b):
    remaining, after = state(n, a)
    return L(after, b) if remaining == 0 else A(remaining, b)


def predecessor_lift(n, initial):
    value, control = initial, 1
    for _ in range(n):
        control = toggle(control) if value == 0 else 1
        value = pred(value)
    lifted_value = control if value == 0 else value + 1
    return value, control, lifted_value


def check_equal(label, left, right, counts):
    if left != right:
        raise AssertionError({"identity": label, "left": left, "right": right})
    counts[label] = counts.get(label, 0) + 1


def main():
    counts = {}
    for a in range(17):
        check_equal("lift_initial", lifted(0, a), a, counts)
        check_equal("absorbing_diagonal", state(a, a)[0], 0, counts)
        check_equal("postzero_diagonal", state(a, a)[1], 0, counts)
        check_equal("absorbing_diagonal_one", state(a, a + 1)[0], 1, counts)
        check_equal("absorbing_diagonal_two", state(a, a + 2)[0], 2, counts)
        for n in range(25):
            check_equal("lift_recurrence", lifted(n + 1, a), bounce(lifted(n, a)), counts)
            check_equal("lift_value", lifted(n, a), L(n, a), counts)
            f, q, g = predecessor_lift(n, a)
            fn, qn, gn = predecessor_lift(n + 1, a)
            check_equal("boolean_control", q in (0, 1), True, counts)
            check_equal("lift_projection", pred(g), f, counts)
            check_equal("predecessor_lift_recurrence", gn, bounce(g), counts)
            check_equal("predecessor_lift_value", g, L(n, a + 1), counts)
            check_equal("predecessor_representation", f, pred(L(n, a + 1)), counts)
            for b in range(8):
                check_equal("centered_recurrence", centered(n + 1, a, b),
                            bounce(centered(n, a, b)), counts)
                check_equal("centered_value", centered(n, a, b), L(n, A(a, b)), counts)
                check_equal("retraction", L(n, A(n, b)), b, counts)
        for b in range(8):
            check_equal("centered_initial", centered(0, a, b), A(a, b), counts)
            check_equal("centered_horizon", centered(a, a, b), b, counts)

    # Fault controls address the essential reset/phase behavior, not source golfing.
    no_phase = lambda n, a: state(n, a)[0]
    lost_phase = any(no_phase(n + 1, a) != bounce(no_phase(n, a))
                     for a in range(4) for n in range(7))
    def wrong_centered(n, a, b):
        remaining, _ = state(n, a)
        return b if remaining == 0 else A(remaining, b)
    lost_tail = any(wrong_centered(n + 1, a, b) != bounce(wrong_centered(n, a, b))
                    for a in range(4) for b in range(4) for n in range(7))
    if not (lost_phase and lost_tail):
        raise AssertionError("A fault control did not detect its intended defect.")
    result = {
        "all_passed": True,
        "scope": "Bounded standard-natural-number regression only; no nonstandard-model or metatheory claim.",
        "ranges": {"a": [0, 16], "b": [0, 7], "n": [0, 24]},
        "identity_checks": counts,
        "total_identity_checks": sum(counts.values()),
        "fault_controls": {"removed_parity_tail_detected": lost_phase,
                           "removed_postzero_iterator_detected": lost_tail},
    }
    (ROOT / "evidence/countdown_checks.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

