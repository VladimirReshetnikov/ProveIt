"""Reproduce the scoped numerical, checker, and measurement evidence."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for relative in ("code/check_countdown.py", "code/qi/validate.py", "code/verify_benchmarks.py"):
    subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT, check=True)
print("All reproduction checks passed. Mathematical scope is stated in the report.")

