PRA FROM ONE TERM AND ONE AXIOM CONSTRUCTOR
Research package prepared for Vladimir Reshetnikov, 1 November 2026.

Read report.pdf for the complete paper and AXIOMS.txt for the exact standalone
nonlogical specification. report.tex plus sections/*.tex are the LaTeX source.

MAIN RESULTS
1. A single direct first-order constructor with one arbitrary term input,
   combining the two different frontiers in the three current drafts.
2. A two-term alternative with no additional diagonal axiom and a uniform
   saving of 5+3*occ_a(s) active syntax nodes in each corresponding axiom.
3. A shifted scalar pairing, 2^x(2y+1)-1, with a simpler one-parameter proof.
4. Complete written proofs of the matching classical and intuitionistic
   bi-interpretations, including both internal identity round trips.

SCOPE
The fixed diagonal identity K is retained in result 1; its redundancy is
unproved. The alternate two-term presentation derives K. Neither result is
claimed to be an absolute shortest axiomatization under every encoding.
The schemas and signature are effective but infinite.

REBUILD
Requirements: Python 3 and a LaTeX installation with pdflatex, amsmath,
amssymb, amsthm, mathtools, lmodern, microtype, geometry, booktabs, array,
longtable, xcolor, fancyhdr, enumitem, hyperref, and url.

  python3 build.py

The command regenerates the Python reports and runs pdflatex three times.
Its working files go under tmp/build; the final result is report.pdf.
To recheck the Lean kernels as well, provide Lean 4.19.0:

  python3 build.py --lean /absolute/path/to/lean

There is no required package-manager download or Mathlib dependency.
The exact original verification version is recorded in audit/lean-version.txt.

CONTENTS
- report.tex, sections/*.tex, report.pdf: complete paper and source.
- AXIOMS.txt: exact main and alternative specifications.
- checks/check_schema.py: literal finite syntax and exact AST ledger.
- checks/check_pairing.py: independent bounded scalar-orbit calculations.
- checks/generated_examples.txt: expanded example schema instances.
- formal/OneTermOneSchema.lean: new constructive compression kernel.
- formal/OneTermKernel.lean: inherited kernel, credited and freshly checked.
- formal/SCOPE.txt: exact formalization boundary.
- audit/: source hashes, successful check outputs, build and review records.
- SHA256SUMS.txt: hashes of the delivered files, excluding this hash list.

PROVENANCE
All three docs/drafts archives were read at ProveIt commit
efc26dac89ba0b9e425995f305d7ac4534796e90. Their Git blob hashes were checked
against the downloaded bytes; SHA-256 hashes are in audit/source_manifest.json.
The report distinguishes the new compression, zero-section simplification,
and shifted pairing from the inherited arithmetic calibration.

VALIDATION LIMIT
The full bi-interpretability proof is mathematical prose. The Lean files
verify the specifically listed local kernels, not the complete final theorem.
Finite numerical tests are diagnostics, not proofs of consistency or of
the behavior of nonstandard elements. Further research questions appear
at the end of the report.

