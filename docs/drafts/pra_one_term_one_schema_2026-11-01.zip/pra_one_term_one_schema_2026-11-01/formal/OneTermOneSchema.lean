/-
PRA from one term and one direct schema: constructive compression kernel.
Prepared 1 November 2026 for Vladimir Reshetnikov.

The finite term syntax is adapted from the reviewed one-schema draft's
formal/Compression.lean at ProveIt commit
efc26dac89ba0b9e425995f305d7ac4534796e90 (archive pra_one_schema_2026-11-01.zip).
The zero-section map, unconditional local wrapper, and proofs below are new.

Scope: exact finite descriptor syntax; zero specialization leaving stored
bodies frozen; its syntactic section; the local one-term wrapper; and the
constructive logical/initial arithmetic reductions needed to compare it with
the diagonal draft. Arithmetic computation and K are abstract predicates in
the wrapper theorem. No first-order soundness metatheorem is formalized here.
The full pairing, PR compiler, and bi-interpretability are written proofs.

Only Init. No classical logic, choice, propext, or admitted proof.
-/
import Init

namespace OneTermOneSchema

inductive UnaryTerm where
  | var : UnaryTerm
  | zero : UnaryTerm
  | succ : UnaryTerm → UnaryTerm
  | delay : UnaryTerm → UnaryTerm → UnaryTerm → UnaryTerm
  deriving DecidableEq, Repr

inductive Term where
  | n : Term
  | a : Term
  | zero : Term
  | succ : Term → Term
  | delay : UnaryTerm → Term → Term → Term
  deriving DecidableEq, Repr

/-- The unary body h_t(v) = t(v,0). Stored descriptor bodies are frozen. -/
def zeroSection : Term → UnaryTerm
  | .n => .var
  | .a => .zero
  | .zero => .zero
  | .succ t => .succ (zeroSection t)
  | .delay h s t => .delay h (zeroSection s) (zeroSection t)

/-- Embed h as the two-variable term h(n), with a unused. -/
def liftUnary : UnaryTerm → Term
  | .var => .n
  | .zero => .zero
  | .succ h => .succ (liftUnary h)
  | .delay h s t => .delay h (liftUnary s) (liftUnary t)

theorem zeroSection_lift (h : UnaryTerm) : zeroSection (liftUnary h) = h := by
  induction h with
  | var => rfl
  | zero => rfl
  | succ h ih => exact congrArg UnaryTerm.succ ih
  | delay h s t _ ihs iht =>
      change UnaryTerm.delay h (zeroSection (liftUnary s))
        (zeroSection (liftUnary t)) = UnaryTerm.delay h s t
      rw [ihs, iht]

section Compression

universe u
variable {A : Type u} (zero : A) (succ : A → A)
variable (value : Term → A → A → A)
variable (computation : UnaryTerm → A → A → Prop) (diagonal : A → Prop)

def Rooted (t : Term) (n a : A) : Prop := n = zero ∨ value t n a = n

def ShortStep (t : Term) (a : A) : Prop :=
  ∀ n, Rooted zero value t n a → value t (succ n) a = succ n

def ShortPropagation : Prop :=
  ∀ t a, ShortStep zero succ value t a → ∀ n, Rooted zero value t n a

def RootedPropagation : Prop :=
  ∀ t a,
    (∀ n, Rooted zero value t n a → Rooted zero value t (succ n) a) →
    ∀ n, Rooted zero value t n a

def AllComputation : Prop := ∀ h n a, computation h n a

/-- Object-language quantifier pattern: forall a forall n [ C and K and
    ((forall n Step_t) -> P_t(n,a)) ]. The local step binder alone shadows n.
    The outer quantification over t here represents the syntactic schema. -/
def Fused : Prop :=
  ∀ t a n,
    computation (zeroSection t) n a ∧ diagonal n ∧
    (ShortStep zero succ value t a → Rooted zero value t n a)

theorem fused_to_computation
    (hf : Fused zero succ value computation diagonal) :
    AllComputation computation := by
  intro h n a
  have hc := (hf (liftUnary h) a n).1
  rw [zeroSection_lift] at hc
  exact hc

theorem fused_to_diagonal
    (hf : Fused zero succ value computation diagonal) : ∀ n, diagonal n := by
  intro n
  exact (hf Term.n zero n).2.1

theorem fused_to_short
    (hf : Fused zero succ value computation diagonal) :
    ShortPropagation zero succ value := by
  intro t a progress n
  exact (hf t a n).2.2 progress

theorem basis_to_fused
    (hc : AllComputation computation)
    (hk : ∀ n, diagonal n)
    (hp : ShortPropagation zero succ value) :
    Fused zero succ value computation diagonal := by
  intro t a n
  exact ⟨hc (zeroSection t) n a, hk n, fun progress => hp t a progress n⟩

theorem fused_iff_basis :
    Fused zero succ value computation diagonal ↔
    AllComputation computation ∧ (∀ n, diagonal n) ∧
      ShortPropagation zero succ value := by
  constructor
  · intro hf
    exact ⟨fused_to_computation zero succ value computation diagonal hf,
      fused_to_diagonal zero succ value computation diagonal hf,
      fused_to_short zero succ value computation diagonal hf⟩
  · intro hb
    exact basis_to_fused zero succ value computation diagonal hb.1 hb.2.1 hb.2.2

theorem rooted_to_short
    (hr : RootedPropagation zero succ value) :
    ShortPropagation zero succ value := by
  intro t a progress
  apply hr t a
  intro n hn
  exact Or.inr (progress n hn)

theorem short_to_rooted
    (nonzero : ∀ n, succ n ≠ zero)
    (hs : ShortPropagation zero succ value) :
    RootedPropagation zero succ value := by
  intro t a progress
  apply hs t a
  intro n hn
  cases progress n hn with
  | inl hz => exact False.elim (nonzero n hz)
  | inr he => exact he

theorem short_iff_rooted (nonzero : ∀ n, succ n ≠ zero) :
    ShortPropagation zero succ value ↔ RootedPropagation zero succ value := by
  exact ⟨short_to_rooted zero succ value nonzero, rooted_to_short zero succ value⟩

end Compression

section LocalBootstrap

universe u
variable {A : Type u} (zero : A) (succ : A → A)

/-- One selected short propagation instance implies its fixed-point induction
    instance, including when base and step are local hypotheses. -/
theorem fixedpoint_induction_from_short (t : A → A)
    (short : (∀ n, (n = zero ∨ t n = n) → t (succ n) = succ n) →
      ∀ n, n = zero ∨ t n = n)
    (base : t zero = zero)
    (step : ∀ n, t n = n → t (succ n) = succ n) : ∀ n, t n = n := by
  have resolve : ∀ n, (n = zero ∨ t n = n) → t n = n := by
    intro n hn
    cases hn with
    | inl hz => simpa only [hz] using base
    | inr he => exact he
  have progress : ∀ n, (n = zero ∨ t n = n) → t (succ n) = succ n := by
    intro n hn
    exact step n (resolve n hn)
  intro n
  exact resolve n (short progress n)

theorem predecessor_from_short (pred : A → A)
    (seed : pred (succ zero) = zero)
    (tail : ∀ n, pred (succ (succ n)) = succ (pred (succ n)))
    (short : (∀ n, (n = zero ∨ pred (succ n) = n) →
      pred (succ (succ n)) = succ n) →
      ∀ n, n = zero ∨ pred (succ n) = n) :
    ∀ n, pred (succ n) = n := by
  apply fixedpoint_induction_from_short zero succ (fun n => pred (succ n)) short seed
  intro n ih
  exact (tail n).trans (congrArg succ ih)

theorem successor_nonzero (pred : A → A)
    (separate : zero ≠ succ zero)
    (predZero : pred zero = zero)
    (predSucc : ∀ n, pred (succ n) = n) : ∀ n, succ n ≠ zero := by
  intro n hz
  have hn : n = zero := by
    have hp := congrArg pred hz
    simpa only [predSucc, predZero] using hp
  exact separate (hz.symm.trans (congrArg succ hn))

theorem coverage_from_short (pred : A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (short : (∀ n, (n = zero ∨ succ (pred n) = n) →
      succ (pred (succ n)) = succ n) →
      ∀ n, n = zero ∨ succ (pred n) = n) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  have h := short (fun n _ => congrArg succ (predSucc n))
  intro n
  cases h n with
  | inl hz => exact Or.inl hz
  | inr he => exact Or.inr he.symm

end LocalBootstrap

#print axioms zeroSection_lift
#print axioms fused_to_computation
#print axioms fused_to_diagonal
#print axioms fused_to_short
#print axioms basis_to_fused
#print axioms fused_iff_basis
#print axioms rooted_to_short
#print axioms short_to_rooted
#print axioms short_iff_rooted
#print axioms fixedpoint_induction_from_short
#print axioms predecessor_from_short
#print axioms successor_nonzero
#print axioms coverage_from_short

end OneTermOneSchema
