#!/usr/bin/env python3
"""Rebuild the checks and PDF; optionally recheck the two Lean 4.19.0 files."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to Lean 4.19.0; omitted by default")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    build = root / "tmp" / "build"
    audit.mkdir(exist_ok=True)
    build.mkdir(parents=True, exist_ok=True)
    results = []

    def run(label: str, command: list[str], log: str) -> str:
        completed = subprocess.run(command, cwd=root, text=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, check=False)
        (audit / log).write_text(completed.stdout, encoding="utf-8")
        results.append({"step": label, "exit_code": completed.returncode,
                        "log": "audit/" + log})
        if completed.returncode:
            print(completed.stdout[-9000:], file=sys.stderr)
            raise SystemExit(f"{label} failed; see audit/{log}")
        print(f"PASS: {label}")
        return completed.stdout

    run("schema syntax and counts", [sys.executable, "checks/check_schema.py"],
        "schema-check.log")
    run("shifted scalar pairing", [sys.executable, "checks/check_pairing.py"],
        "pairing-check.log")

    if args.lean:
        version = run("Lean version", [args.lean, "--version"], "lean-version.txt")
        lean_rows = []
        for name in ("OneTermOneSchema.lean", "OneTermKernel.lean"):
            output = run(name, [args.lean, "formal/" + name], name + ".log")
            lines = [line for line in output.splitlines() if "depends on axioms" in line
                     or "does not depend on any axioms" in line]
            if not lines or any("depends on axioms" in line and "[]" not in line
                                for line in lines):
                raise SystemExit(f"Unexpected axiom dependency output in {name}")
            lean_rows.append({"file": "formal/" + name,
                              "sha256": hashlib.sha256((root / "formal" / name).read_bytes()).hexdigest(),
                              "exit_code": 0, "printed_declarations": len(lines),
                              "all_printed_axiom_dependencies_empty": True,
                              "log": "audit/" + name + ".log"})
        (audit / "lean-verification.json").write_text(json.dumps({
            "lean_version": version.strip(), "files": lean_rows,
            "scope_file": "formal/SCOPE.txt",
            "full_bi_interpretation_formalized": False}, indent=2) + "\n")

    pdflatex = shutil.which("pdflatex")
    if not pdflatex:
        raise SystemExit("pdflatex is required; install the packages listed in README.txt")
    for i in range(1, 4):
        run(f"LaTeX pass {i}", [pdflatex, "-interaction=nonstopmode",
            "-halt-on-error", "-file-line-error", "-output-directory=" + str(build),
            "report.tex"], f"latex-pass-{i}.log")
    shutil.copyfile(build / "report.pdf", root / "report.pdf")
    (audit / "build-results.json").write_text(json.dumps({
        "status": "passed", "steps": results,
        "pdf": "report.pdf", "lean_rechecked_in_this_build": bool(args.lean)
    }, indent=2) + "\n", encoding="utf-8")
    print("Built report.pdf")


if __name__ == "__main__":
    main()
