#!/usr/bin/env python3
"""Finite syntax diagnostics for the one-term/one-constructor PRA report.

This checks the exact displayed ASTs and substitutions, not the mathematical
bi-interpretability theorem. The active-node convention counts each variable,
constant, function application, equality, connective, and quantifier once.
Iterator descriptors are retained as literal syntax, but their spelling is
not included in active-node counts. They are not omitted from language
validation. Run this file with Python 3; it writes two nearby audit artifacts.
"""
from dataclasses import dataclass
from itertools import product
from pathlib import Path
import json


@dataclass(frozen=True)
class Node:
    tag: str
    args: tuple = ()
    descriptor: object = None


def var(name):
    return Node(name)


zero = var("0")
n, a, x, v = map(var, ("n", "a", "x", "v"))
bottom = var("bottom")


def succ(t):
    return Node("S", (t,))


one = succ(zero)


def iterator(h, s, t):
    return Node("D", (s, t), h)


def size(t):
    return 1 + sum(size(child) for child in t.args)


def occurrences(t, name):
    return int(t.tag == name and not t.args) + sum(
        occurrences(child, name) for child in t.args)


def substitute_term(t, mapping):
    """Simultaneous active substitution; never enter stored descriptors."""
    if not t.args and t.tag in mapping:
        return mapping[t.tag]
    return Node(t.tag, tuple(substitute_term(child, mapping)
                             for child in t.args), t.descriptor)


def term_variables(t):
    if t.tag == "0":
        return set()
    if not t.args:
        return {t.tag}
    result = set()
    for child in t.args:
        result.update(term_variables(child))
    return result


def validate_term(t, allowed=frozenset({"n", "a"}), ancestors=()):
    """Validate the scalar grammar and return its finite dependency rank."""
    if not isinstance(t, Node) or id(t) in ancestors:
        raise ValueError("non-finite or malformed term")
    ancestors = ancestors + (id(t),)
    if not t.args:
        if t.tag not in allowed and t.tag != "0":
            raise ValueError("illegal active variable or constant")
        if t.descriptor is not None:
            raise ValueError("descriptor attached to a variable")
        return 0
    if t.tag == "S":
        if len(t.args) != 1 or t.descriptor is not None:
            raise ValueError("malformed successor")
        return validate_term(t.args[0], allowed, ancestors)
    if t.tag == "D":
        if len(t.args) != 2 or not isinstance(t.descriptor, Node):
            raise ValueError("malformed iterator")
        body_rank = validate_term(t.descriptor, frozenset({"v"}), ancestors)
        arg_ranks = [validate_term(child, allowed, ancestors)
                     for child in t.args]
        return max([1 + body_rank] + arg_ranks)
    raise ValueError("unrecognized term constructor")


def eq(s, t):
    return Node("=", (s, t))


def conj(p, q):
    return Node("and", (p, q))


def disj(p, q):
    return Node("or", (p, q))


def imp(p, q):
    return Node("implies", (p, q))


def forall(name, p):
    return Node("all " + name, (p,))


def active_free_variables(t):
    if t.tag.startswith("all "):
        return active_free_variables(t.args[0]) - {t.tag[4:]}
    if t.tag in {"0", "bottom"}:
        return set()
    if not t.args:
        return {t.tag}
    result = set()
    for child in t.args:
        result.update(active_free_variables(child))
    return result


def active_variable_names(t):
    if t.tag.startswith("all "):
        return {t.tag[4:]} | active_variable_names(t.args[0])
    if t.tag in {"0", "bottom"}:
        return set()
    if not t.args:
        return {t.tag}
    result = set()
    for child in t.args:
        result.update(active_variable_names(child))
    return result


def quantifier_count(t):
    return int(t.tag.startswith("all ")) + sum(
        quantifier_count(child) for child in t.args)


def quantifier_depth(t):
    return int(t.tag.startswith("all ")) + max(
        [quantifier_depth(child) for child in t.args] or [0])


def alpha_key(t, binders=()):
    """De Bruijn comparison of active binders; descriptor names stay frozen."""
    if t.tag.startswith("all "):
        return ("all", alpha_key(t.args[0], binders + (t.tag[4:],)))
    if not t.args and t.tag in binders:
        return ("bound", tuple(reversed(binders)).index(t.tag))
    return (t.tag, tuple(alpha_key(child, binders) for child in t.args),
            t.descriptor)


def display(t):
    if t.tag.startswith("all "):
        return "forall " + t.tag[4:] + " (" + display(t.args[0]) + ")"
    if t.tag == "D":
        return "D_[" + display(t.descriptor) + "](" + ",".join(
            display(child) for child in t.args) + ")"
    if not t.args:
        return t.tag
    if t.tag == "S":
        return "S(" + display(t.args[0]) + ")"
    symbol = {"=": "=", "and": "AND", "or": "OR",
              "implies": "->"}[t.tag]
    return "(" + display(t.args[0]) + " " + symbol + " " + display(t.args[1]) + ")"


separation = imp(eq(zero, one), bottom)
predecessor_body = iterator(succ(v), v, zero)


def q(s, t):
    return iterator(one, s, t)


def fixed_diagonal(s):
    return eq(iterator(predecessor_body, s, s), q(s, s))


def payload(h, counter=n, parameter=a, include_diagonal=False):
    reset = eq(iterator(h, q(counter, zero), parameter), parameter)
    r = iterator(h, succ(counter), parameter)
    tail = eq(iterator(h, succ(succ(counter)), parameter),
              substitute_term(h, {"v": r}))
    if include_diagonal:
        return conj(separation, conj(reset, conj(tail, fixed_diagonal(counter))))
    return conj(separation, conj(reset, tail))


def rooted(s, t, counter=n):
    return disj(eq(counter, zero), eq(s, t))


def zero_section(t):
    return substitute_term(t, {"n": v, "a": zero})


def progress(t):
    return forall("n", imp(rooted(t, n),
                            eq(substitute_term(t, {"n": succ(n)}), succ(n))))


def main_schema(t, two_names=False):
    """U: unconditional payload and restricted propagation, three binders."""
    counter = n if two_names else x
    name = "n" if two_names else "x"
    output = rooted(substitute_term(t, {"n": counter}), counter, counter)
    matrix = conj(payload(zero_section(t), counter, a, True),
                  imp(progress(t), output))
    return forall("a", forall(name, matrix))


def main_four_quantifiers(t):
    return forall("a", conj(forall("n", payload(zero_section(t), include_diagonal=True)),
                            imp(progress(t), forall("n", rooted(t, n)))))


def original_one_schema(s, t):
    h = substitute_term(s, {"n": v, "a": v})
    p = rooted(s, t)
    sp = substitute_term(s, {"n": succ(n)})
    tp = substitute_term(t, {"n": succ(n)})
    premise = forall("n", imp(p, rooted(sp, tp, succ(n))))
    return forall("a", imp(premise, forall("n", conj(p, payload(h)))))


def shorter_two_term(s, t):
    p = rooted(s, t)
    sp = substitute_term(s, {"n": succ(n)})
    tp = substitute_term(t, {"n": succ(n)})
    premise = forall("n", imp(p, eq(sp, tp)))
    return forall("a", imp(premise, forall("n", conj(p, payload(zero_section(s))))))


def old_diagonal_dynamic(t):
    p = rooted(t, n)
    pp = rooted(substitute_term(t, {"n": succ(n)}), succ(n), succ(n))
    return forall("a", imp(forall("n", imp(p, pp)), forall("n", p)))


def old_diagonal_computational(h):
    reset = eq(iterator(h, q(n, zero), a), a)
    tail = eq(iterator(h, succ(succ(n)), a),
              substitute_term(h, {"v": iterator(h, succ(n), a)}))
    f = conj(separation, forall("n", conj(reset, conj(tail, fixed_diagonal(n)))))
    # Its only free variable is a, so the old free-n successor substitution
    # leaves the entire f unchanged, including the inner binding of n.
    assert active_free_variables(f) <= {"a"}
    return forall("a", imp(forall("n", imp(f, f)), forall("n", f)))


def short_propagation(s, t, old_successor_disjunct=False):
    p = rooted(s, t)
    sp = substitute_term(s, {"n": succ(n)})
    tp = substitute_term(t, {"n": succ(n)})
    nxt = rooted(sp, tp, succ(n)) if old_successor_disjunct else eq(sp, tp)
    return forall("a", imp(forall("n", imp(p, nxt)), forall("n", p)))


BASELINES = {
    "repository": "VladimirReshetnikov/ProveIt",
    "commit": "efc26dac89ba0b9e425995f305d7ac4534796e90",
    "files": [
        "docs/drafts/pra_one_schema_2026-11-01.zip",
        "docs/drafts/pra_one_term_diagonal_2026-11-01.zip",
        "docs/drafts/pra_short_propagation_2026-11-01.zip",
    ],
}


def run_checks():
    terms = [n, a, zero, succ(n), succ(a), iterator(v, n, a),
             iterator(succ(v), succ(n), a), iterator(predecessor_body, n, n),
             iterator(one, iterator(succ(v), a, n), succ(a)),
             iterator(predecessor_body, iterator(v, n, a), iterator(one, a, a)),
             iterator(v, iterator(one, n, a), iterator(one, n, a)),
             iterator(succ(v), zero, succ(a))]
    unary_bodies = [v, zero, one, succ(v), predecessor_body,
                    iterator(v, v, v), iterator(one, v, zero),
                    iterator(predecessor_body, v, v)]
    ranks, examples = [], []
    for t in terms:
        rank = validate_term(t)
        h = zero_section(t)
        assert validate_term(h, frozenset({"v"})) == rank
        assert term_variables(h) <= {"v"}
        z, num_n, num_a = size(t), occurrences(t, "n"), occurrences(t, "a")
        f3, f2, f4 = main_schema(t), main_schema(t, True), main_four_quantifiers(t)
        assert alpha_key(f3) == alpha_key(f2)
        assert not active_free_variables(f3) and not active_free_variables(f2)
        assert active_variable_names(f3) == {"a", "x", "n"}
        assert active_variable_names(f2) == {"a", "n"}
        assert (quantifier_count(f3), quantifier_depth(f3)) == (3, 3)
        assert (quantifier_count(f4), quantifier_depth(f4)) == (4, 2)
        assert size(f3) == size(f2) == 50 + 4*z + 4*num_n
        assert size(f4) == 51 + 4*z + 4*num_n
        assert size(payload(h, include_diagonal=True)) == 29 + z + 3*num_n
        assert size(old_diagonal_dynamic(t)) == 25 + 3*z + num_n
        assert size(old_diagonal_computational(h)) == 95 + 3*z + 9*num_n
        assert size(shorter_two_term(t, n)) + 8 == size(f3)
        assert size(f3) - size(original_one_schema(t, n)) == 3 - 3*num_a
        ranks.append(rank)
        examples.append({"term": display(t), "term_size": z,
                         "n_occurrences": num_n, "a_occurrences": num_a,
                         "descriptor_rank": rank,
                         "main_three_quantifiers": size(f3),
                         "main_four_quantifiers": size(f4),
                         "old_diagonal_dynamic": size(old_diagonal_dynamic(t)),
                         "old_diagonal_computational_for_section": size(old_diagonal_computational(h))})
    for h in unary_bodies:
        validate_term(h, frozenset({"v"}))
        t = substitute_term(h, {"v": n})
        assert zero_section(t) == h
    # Descriptor substitution is deliberately frozen even if a substitution
    # mapping includes the descriptor's own bound metasyntactic name v.
    before = iterator(predecessor_body, n, a)
    after = substitute_term(before, {"n": succ(n), "a": zero, "v": n})
    assert after.descriptor is before.descriptor
    assert after.args == (succ(n), zero)
    invalid = [var("b"), Node("S", (n,a)), Node("D", (n,a)),
               iterator(a,n,a), iterator(n,n,a), Node("unknown", (n,))]
    for t in invalid:
        try:
            validate_term(t)
        except ValueError:
            pass
        else:
            raise AssertionError("malformed descriptor was accepted")
    for s,t in product(terms, repeat=2):
        zs,zt = size(s),size(t)
        ns,nt,pa = occurrences(s,"n"),occurrences(t,"n"),occurrences(s,"a")
        old,new = original_one_schema(s,t),shorter_two_term(s,t)
        assert size(old) == 43+4*zs+3*zt+4*ns+nt+3*pa
        assert size(new) == 38+4*zs+3*zt+4*ns+nt
        assert size(old)-size(new) == 5+3*pa
        assert size(short_propagation(s,t,True))-size(short_propagation(s,t)) == 5
        assert size(short_propagation(s,t)) == 16+3*zs+3*zt+ns+nt
        assert not active_free_variables(old) and not active_free_variables(new)
        assert active_variable_names(new) == {"n","a"}
        assert (quantifier_count(new),quantifier_depth(new)) == (3,2)
    result = {
        "status": "passed", "baseline": BASELINES,
        "scope": "Finite syntax diagnostics only; no consistency, induction, or bi-interpretability claim is machine proved here.",
        "count_convention": "One node per active variable, constant, function application, equality, connective, quantifier; bottom costs one; not is implication to bottom; stored descriptors are validated but their spelling is charged separately.",
        "checks": {"legal_terms":len(terms), "term_pairs":len(terms)**2,
                   "unary_section_witnesses":len(unary_bodies),
                   "rejected_malformed_terms":len(invalid),
                   "max_tested_descriptor_rank":max(ranks),
                   "frozen_descriptors": True,
                   "two_name_three_name_alpha_equivalence": True},
        "formulas": {
            "U_three_quantifiers": "50 + 4*|t| + 4*occ_n(t)",
            "U_four_quantifiers": "51 + 4*|t| + 4*occ_n(t)",
            "C_zero_section": "29 + |t| + 3*occ_n(t)",
            "old_one_term_dynamic": "25 + 3*|t| + occ_n(t)",
            "old_one_term_computational_for_zero_section": "95 + 3*|t| + 9*occ_n(t)",
            "original_one_schema": "43 + 4*|s| + 3*|t| + 4*occ_n(s) + occ_n(t) + 3*occ_a(s)",
            "A_minus": "38 + 4*|s| + 3*|t| + 4*occ_n(s) + occ_n(t)",
            "A_minus_saving": "5 + 3*occ_a(s)",
            "short_propagation": "16 + 3*|s| + 3*|t| + occ_n(s) + occ_n(t)",
        },
        "comparison_warning": "The main U is not uniformly shorter than every baseline instance. U_t has eight more active nodes than A_minus(t,n), and U_t minus original_one_schema(t,n) is 3-3*occ_a(t). These are correspondences, not total sizes of infinite axiom sets.",
        "examples":examples,
    }
    return result, terms


def main():
    result,terms = run_checks()
    root = Path(__file__).resolve().parent.parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    target = audit / "schema-counts.json"
    target.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    lines = ["GENERATED SYNTAX EXAMPLES", "",
             "D_[body](counter,state) prints a literal stored unary descriptor.",
             "The active-node count does not count that descriptor's spelling.",
             "All descriptor bodies are retained and validated as finite unary terms.",
             "These finite diagnostics are not proofs of the arithmetic theorem.", ""]
    for t in terms[:6]:
        lines += ["INPUT: "+display(t),
                  "ZERO SECTION: "+display(zero_section(t)),
                  "U (three names): "+display(main_schema(t)),
                  "U (two names with local shadowing): "+display(main_schema(t,True)),
                  "ACTIVE NODES: "+str(size(main_schema(t))), ""]
    (root/"checks"/"generated_examples.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({"status":"passed","checks":result["checks"],
                      "audit_file":str(target)},indent=2))


if __name__ == "__main__":
    main()
