#!/usr/bin/env python3
"""Bounded arithmetic checks for the shifted scalar pairing construction.

This is a numerical regression check, not a proof of the first-order
interpretation, induction strength, or consistency. The scalar orbit
definitions of m, G, H, r, u, w, E, J, L, R are evaluated directly.
Previously proved elementary operations are evaluated by their standard
natural-number meanings. In particular, H and r do NOT use // or % in
their definitions; those operations occur only in independent expectations.

Usage: python3 checks/check_pairing.py [--output PATH]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable


def iterate(f: Callable[[int], int], n: int, a: int) -> int:
    assert n >= 0 and a >= 0
    for _ in range(n):
        a = f(a)
    return a


def successor(n: int) -> int:
    return n + 1


def delayed(f: Callable[[int], int], n: int, a: int) -> int:
    return iterate(f, max(n - 1, 0), a)


def pred(n: int) -> int:
    return max(n - 1, 0)


def difference(x: int, y: int) -> int:
    return max(x - y, 0)


def zero_iterate(n: int, a: int) -> int:
    return a if n == 0 else 0


def select(n: int, b: int, c: int) -> int:
    # The selector term Z(n,b) + Z(Z(n,1),c).
    return zero_iterate(n, b) + zero_iterate(zero_iterate(n, 1), c)


def double(n: int) -> int:
    return n + n


def cycle_step(v: int) -> int:
    return select(pred(v), successor(v), 0)


# Each cached entry is generated from its predecessor using the displayed
# scalar iterator equation. No division or residue arithmetic is used here.
cycle_values = [0]


def cycle(n: int) -> int:
    while len(cycle_values) <= n:
        cycle_values.append(cycle_step(cycle_values[-1]))
    return cycle_values[n]


def singleton_bit(v: int) -> int:
    return zero_iterate(pred(v), v)


def growth_step(v: int) -> int:
    return successor(v) + singleton_bit(cycle(v))


growth_values = [0]


def growth(n: int) -> int:
    while len(growth_values) <= n:
        growth_values.append(growth_step(growth_values[-1]))
    return growth_values[n]


def residue(n: int) -> int:
    return cycle(growth(n))


def half(n: int) -> int:
    return difference(growth(n), n)


def f_step(v: int) -> int:
    return successor(double(v))


def expand(x: int, a: int) -> int:
    return iterate(f_step, x, a)


def u_step(v: int) -> int:
    return select(residue(v), v, half(v))


def w_step(v: int) -> int:
    return select(residue(v), successor(successor(v)), half(v))


def pair(x: int, y: int) -> int:
    return expand(x, double(y))


def old_pair(x: int, y: int) -> int:
    return iterate(double, x, successor(double(y)))


def decode(z: int) -> tuple[int, int]:
    u_value = iterate(u_step, z, z)
    w_value = iterate(w_step, z, z)
    left = difference(z, half(difference(w_value, u_value)))
    right = half(u_value)
    return left, right


def run_checks() -> dict[str, object]:
    counts: dict[str, int] = {}

    count = 0
    for n in range(13):
        assert pred(n) == delayed(successor, n, 0)
        for a in range(13):
            assert zero_iterate(n, a) == iterate(lambda _: 0, n, a)
            assert difference(a, n) == iterate(pred, n, a)
            assert a + n == iterate(successor, n, a)
            count += 3
    counts["elementary_operation_comparisons"] = count + 13

    count = 0
    for n in range(13):
        for b in range(9):
            for c in range(9):
                assert select(n, b, c) == (b if n == 0 else c)
                count += 1
    counts["selector_cases"] = count

    for n in range(20001):
        assert cycle(n) == n % 3
        assert half(n) == n // 2
        assert residue(n) == n % 2
    counts["halving_and_parity_inputs"] = 20001

    count = 0
    for x in range(11):
        for a in range(51):
            assert difference(x, expand(x, a)) == 0
            assert successor(expand(x, a)) == iterate(double, x, successor(a))
            count += 1
    counts["unguarded_growth_and_shift_cases"] = count

    count = 0
    for f in (u_step, w_step, f_step):
        for k in range(16):
            for z in range(21):
                assert iterate(f, successor(k), z) == iterate(f, k, f(z))
                count += 1
    counts["exchange_cases"] = count

    count = 0
    for f in (u_step, w_step):
        for n in range(41):
            for x in range(n + 1):
                assert iterate(f, n, n) == iterate(
                    f, difference(n, x), iterate(f, x, n)
                )
                count += 1
    counts["diagonal_split_cases"] = count

    count = 0
    for f in (u_step, w_step):
        for x in range(9):
            for a in range(13):
                assert iterate(f, x, expand(x, a)) == a
                count += 1
    counts["strip_cases"] = count

    count = 0
    for a in range(0, 25, 2):
        for k in range(25):
            assert iterate(u_step, k, a) == a
            assert iterate(w_step, k, a) == a + double(k)
            assert residue(a + double(k)) == 0
            count += 1
    counts["even_orbit_cases"] = count

    count = 0
    maximum_code = 0
    samples = []
    for x in range(11):
        for y in range(25):
            z = pair(x, y)
            assert z == (2**x) * (2 * y + 1) - 1
            assert successor(z) == old_pair(x, y)
            assert decode(z) == (x, y), (x, y, z, decode(z))
            maximum_code = max(maximum_code, z)
            if x < 3 and y < 3:
                samples.append({"x": x, "y": y, "code": z, "decoded": [x, y]})
            count += 1
    counts["pairing_retraction_cases"] = count

    assert pair(0, 0) == 0
    assert decode(0) == (0, 0)
    assert difference(1, iterate(double, 1, 0)) != 0

    return {
        "status": "passed",
        "scope": (
            "Bounded standard-number regression checks only. These do not prove "
            "the first-order interpretation, induction strength, or consistency."
        ),
        "definitions_evaluated": (
            "m, G, H, r, F, E, u, w, J, U, W, L, R use the scalar orbit "
            "definitions in sections/pairing.tex; caches satisfy the exact "
            "iterator recurrence. Elementary operations use their established "
            "natural-number meanings, checked against literal iteration on a "
            "smaller range."
        ),
        "counts": counts,
        "pairing_rectangle": {"x": [0, 10], "y": [0, 24]},
        "maximum_tested_pair_code": maximum_code,
        "zero_code_checked": True,
        "old_unguarded_growth_counterexample": {"x": 1, "a": 0, "iterate": 0},
        "samples": samples,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "audit" / "pairing-checks.json",
    )
    args = parser.parse_args()
    result = run_checks()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
