"""Untrusted expansion from the new numerical rule to the frozen old calculus.

This module is never imported by either acceptance program. It constructs
ordinary finite certificates, which must then be checked independently.
The old kernel supplies expression substitution and scope reconstruction;
the new kernel only identifies the principal formula of an elimination.
"""

import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


old = load("frozen_old_kernel", ROOT / "comparison/reference.py")
new = load("candidate_kernel", ROOT / "checker.py")


def lift(proof, context, amount=1, depth=0):
    """Weaken free numerical parameters in an old-format derivation.

`depth` counts proof-local numerical variables to retain. Formula-local
binders are handled by the old expression substitution. Equality templates
and numerical matrices have one additional distinguished slot.
"""
    def expression(value, extra=0):
        return old.subst(value, (amount,), d=depth + extra)

    match proof:
        case ["hyp", key]:
            canonical = context[context.index(key)]
            return ["hyp", expression(canonical)]
        case ["pi", guard, child]:
            local = [*map(old.subst, context), guard]
            return ["pi", expression(guard, 1),
                    lift(child, local, amount, depth + 1)]
        case ["use", principal, argument, minor]:
            conclusion = old.infer(principal, context)
            tag = conclusion[0]
            local = ([*map(old.subst, context), conclusion[1]]
                     if tag == "ex" else context)
            return ["use", lift(principal, context, amount, depth),
                    expression(argument, int(tag == "=")),
                    lift(minor, local, amount, depth + int(tag == "ex"))]
        case ["pack", witness, child]:
            local = [*map(old.subst, context), ["=", 0, old.subst(witness)]]
            return ["pack", expression(witness),
                    lift(child, local, amount, depth + 1)]
        case ["rec", recursor]:
            return ["rec", expression(recursor)]
        case ["nat", matrix]:
            return ["nat", expression(matrix, 1)]
        case _:
            raise ValueError("not an old-format derivation")


def expand(proof, context):
    match proof:
        case ["lam", guard, child]:
            local = [*map(old.subst, context), guard]
            return ["pi", guard, expand(child, local)]
        case ["pack", witness, child]:
            local = [*map(old.subst, context), ["=", 0, old.subst(witness)]]
            return ["pack", witness, expand(child, local)]
        case ["use", principal, argument, minor]:
            conclusion = new.infer(principal, context)
            local = ([*map(old.subst, context), conclusion[1]]
                     if conclusion[0] == "ex" else context)
            return ["use", expand(principal, context), argument,
                    expand(minor, local)]
        case ["r", _, _, _] as recursor:
            return ["rec", recursor]
        case ["nat", matrix, step]:
            base = old.subst(matrix, [-1, 0])
            raised_matrix = old.subst(matrix, (1,), d=1)
            step_proof = expand(step, context)
            first = ["use", ["nat", raised_matrix], 0, ["hyp", base]]
            body = ["use", first, -1, lift(step_proof, context)]
            return ["pi", base, body]
        case _:
            return ["hyp", proof]


def translate(data):
    canonical = new.erase(data)
    new.check(canonical)
    context, conclusion, proof = canonical
    result = [context, conclusion, expand(proof, context)]
    old.check(result)
    return result


if __name__ == "__main__":
    with open(sys.argv[1], encoding="utf-8") as stream:
        certificate = translate(json.load(stream))
    print(json.dumps(certificate, separators=(",", ":")))
