"""Directly author two new-format arithmetic certificates.

No old certificate is read or translated to construct these proofs.
The intended goals are specified independently of proof inference.
All helpers below merely construct finite expressions and derivations;
the standalone checker and optional reverse expansion validate them.

Example:
  python3 generate.py --checker /path/checker.py \
      --reverse /path/proof_tools/translate_to_old.py --output /path/examples
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ZERO = -1
TRUE = ['=', ZERO, ZERO]
SCOPES = {'s': (0,), 'r': (0, 0, 2), '=': (0, 0),
          'pi': (1, 1), 'ex': (1,)}


def shift(expression, depth=0):
    if type(expression) is int:
        return expression if expression < depth else expression + 1
    tag, *children = expression
    return [tag, *(shift(child, depth + width)
                   for child, width in zip(children, SCOPES[tag], strict=True))]


def successor(term):
    return ['s', term]


def addition(counter, initial):
    return ['r', counter, initial, ['s', 0]]


def equation(left, right):
    return ['=', left, right]


def reflexivity(term):
    recursor = ['r', ZERO, term, 0]
    return ['use', recursor, equation(0, shift(term)), recursor]


def symmetry(proof, left):
    return ['use', proof, equation(0, shift(left)), reflexivity(left)]


def transitivity(first, second, left):
    return ['use', second, equation(shift(left), 0), first]


def successor_congruence(proof, left):
    template = equation(successor(shift(left)), successor(0))
    return ['use', proof, template, reflexivity(successor(left))]


def zero_plus_n():
    # This goal is fixed before constructing its proof.
    goal = ['pi', TRUE, ['=', ['r', 0, -1, ['s', 0]], 0]]
    matrix = equation(addition(0, ZERO), 0)
    # In this lambda's body, the literal matrix is the induction hypothesis.
    # R(Sn,0)=S(R(n,0)) is transported along R(n,0)=n.
    template = equation(addition(successor(1), ZERO), successor(0))
    step = ['lam', matrix,
            ['use', matrix, template, addition(successor(0), ZERO)]]
    proof = ['lam', TRUE,
             ['use', ['nat', matrix, step], 0, addition(ZERO, ZERO)]]
    return [[], goal, proof]


def successor_initial_step(parameter):
    """Prove P(n)->P(Sn), in a number scope with n=0 and the given a."""
    left = addition(0, successor(parameter))
    right = addition(0, parameter)
    left_next = addition(successor(0), successor(parameter))
    right_next = addition(successor(0), parameter)
    matrix = equation(left, successor(right))
    # Left computation, then one actual use of the induction hypothesis.
    transported = ['use', matrix,
                   equation(shift(left_next), successor(0)), left_next]
    # S(R(Sn,a)) = S(S(R(n,a))) by the right computation equation.
    right_computation = successor_congruence(right_next, right_next)
    aligned = symmetry(right_computation, successor(right_next))
    return ['lam', matrix, transitivity(transported, aligned, left_next)]


def successor_initial_base(parameter):
    left = addition(ZERO, successor(parameter))
    right = addition(ZERO, parameter)
    right_computation = successor_congruence(right, right)
    aligned = symmetry(right_computation, successor(right))
    return transitivity(left, aligned, left)


def successor_plus_n():
    # forall a forall n, (S a)+n = S(a+n). Addition recurses on n.
    goal = ['pi', TRUE, ['pi', TRUE,
            ['=', ['r', 0, ['s', 1], ['s', 0]],
                  ['s', ['r', 0, 1, ['s', 0]]]]]]
    # Inside the two outer lambdas: n is index 0 and a is index 1.
    # A numerical matrix adds its own slot, so its parameter a is index 2.
    matrix = equation(addition(0, successor(2)), successor(addition(0, 2)))
    step = successor_initial_step(2)
    body = ['use', ['nat', matrix, step], 0, successor_initial_base(1)]
    proof = ['lam', TRUE, ['lam', TRUE, body]]
    return [[], goal, proof]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path)
    parser.add_argument('--reverse', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    checker = load('direct_example_checker', args.checker) if args.checker else None
    reverse = load('direct_example_reverse', args.reverse) if args.reverse else None
    examples = [
        ('direct_zero_plus_n', 'forall n, 0+n=n', zero_plus_n()),
        ('direct_successor_plus_n', 'forall a forall n, (S a)+n=S(a+n)', successor_plus_n()),
    ]
    results = []
    for name, reading, data in examples:
        path = args.output / (name + '.json')
        path.write_text(json.dumps(data, separators=(',', ':')) + '\n')
        row = dict(name=name, ordinary_reading=reading, assumptions=data[0],
                   intended_goal=data[1], source='Direct new-format construction',
                   real_induction_hypothesis_use=True, bytes=path.stat().st_size,
                   sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        if checker:
            checker.check(data)
            row['new_checker_accepts'] = True
        if reverse:
            expanded = reverse.translate(data)
            old_path = args.output / (name + '.old.json')
            old_path.write_text(json.dumps(expanded, separators=(',', ':')) + '\n')
            row['old_checker_accepts_expansion'] = True
            row['old_expansion_bytes'] = old_path.stat().st_size
            row['old_expansion_sha256'] = hashlib.sha256(old_path.read_bytes()).hexdigest()
        results.append(row)
    (args.output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
