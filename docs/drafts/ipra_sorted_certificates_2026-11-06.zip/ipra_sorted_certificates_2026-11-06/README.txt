A SMALLER COMPLETE CHECKER FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 6 November 2026

START HERE

  report.pdf          Self-contained mathematical report and full checker listing.
  report.tex          Main LaTeX source; remaining source is in sections/.
  checker.py          Entire trusted public acceptance implementation.
  checker_core.py     Entire canonical-input acceptance implementation.
  FORMAT.txt          Exact syntax and all certificate records.

RESULT

  Complete public checker:    750 significant original-source tokens,
                              748 normalized tokens, 798 executable AST nodes,
                              2,409 normalized bytes, 2,721 raw bytes.
  Complete canonical checker:703 significant original-source tokens,
                              701 normalized tokens, 750 executable AST nodes,
                              2,267 normalized bytes, 2,578 raw bytes.

  Strongest current bundled comparator:
                              796 tokens, 839 AST nodes,
                              2,547 normalized bytes, 2,848 raw bytes.

Both new programs are strictly smaller on all five measured coordinates.
The stronger bundled canonical comparator is counted, not just the six
principal checker.py files. The inventory freezes 115 distinct source versions.
This is a finite implementation comparison, not an absolute minimum theorem.

SOURCE SNAPSHOT

  Repository: VladimirReshetnikov/ProveIt
  Commit: 046c84aa5e99f3a437e5bc6873af9f9a1cc797a5
  Directory: docs/drafts

The archive and source hashes, all original member paths, frozen source
versions, and reproducible metrics are in comparison/.

THEORY AND CONTRIBUTION

The native formulas are equality, Pi_x(A;B)=forall x(A->B), and E_x A.
Terms use zero, successor, and finite initialized recursion. Public falsity
is explicitly represented by 0=S0. The canonical companion takes that
representation directly; it is not an unrelated positive reduct.

The six logical patterns, two computation schemas, and one numerical rule
are all specified in the article. The new numerical rule consumes a guarded
successor proof and yields forall x(P(0)->P(x)); an induction hypothesis is
allowed only for a literal-equation matrix. Other matrices receive the fixed
base guard and therefore only numerical cases.

The inherited logic/arithmetic reconstruction is attributed to the draft
series. New reductions use sort-indexed constructor tables, two provably
redundant checks, literal formula hypotheses, direct recursor computation
certificates, shared introductions, and the equivalent numerical rule.

The article derives full intuitionistic logic and all quantifier-free
induction, then proves whole-domain ordinary first-order bi-interpretability
through an explicit realization. Both internal round-trip isomorphisms are
the identity relation. It includes Further research questions.

RUN

Python 3.10+ and its standard library suffice. Counts were obtained with
Python 3.12.14; ast.unparse formatting can differ across versions.

  python3 checker.py examples/direct_zero_plus_n.json
  python3 checker_core.py examples/direct_successor_plus_n.json
  python3 reproduce.py --no-pdf

The checkers print ACCEPT/REJECT and exit 0/1 for handled outcomes.
A nonempty assumption list certifies a conditional sequent, not a theorem.
All unbound number indices are free parameters. The integer -1 is numerical
zero; index 0 is a variable, not the numeral zero.

To compile and package the complete article with a conventional TeX tree:

  python3 reproduce.py

Or rebuild only the article/archive after validation:

  python3 build.py

VALIDATION

  176 fixed inherited cases: 116 accept, 60 reject, for both new checkers.
  116 positive reverse expansions accepted by the frozen predecessor.
  704 actual CLI invocations, including optimized Python.
  63 direct new-rule cases: 16 accept, 47 reject, for both new checkers.
  All 16 positive direct cases also reverse-expand successfully.
  67,156 independent grammar/binding/inference checks per final checker.
  16 inherited demonstrations translated and checked in both directions.
  2 directly authored closed arithmetic proofs using the actual IH.

No failures occurred. The general metatheory is written mathematics,
not a Lean/Rocq formalization. Finite tests do not establish universal
implementation correctness or verify the Python runtime.

PROOF TRANSLATORS

Neither translator is imported by either checker.

  python3 proof_tools/translate_to_new.py OLD_CERTIFICATE.json
  python3 proof_tools/translate_to_old.py NEW_CERTIFICATE.json

These print finite JSON. The reverse translator validates the input with
the new checker and the expansion with the frozen old checker. It explicitly
handles proof-local numerical scopes when weakening a step proof.

CONTENTS

  checker.py, checker_core.py    Entire independent acceptance programs.
  report.tex, sections/          Complete LaTeX sources.
  report.pdf                    Compiled report.
  comparison/                   Frozen sources, provenance, controls, metrics.
  validation/                   Fixed fixtures, independent audit, results.
  proof_tools/                  Untrusted proof translators and generator.
  examples/                     Complete theorem certificates and expansions.
  measure.py                    Static full-source measurement.
  reproduce.py, build.py        Offline reproduction and PDF/ZIP build.
  SHA256SUMS.txt                 Hashes of every other packaged file.
