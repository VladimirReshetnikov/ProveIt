"""Measure complete checker sources, preserving the supplied draft convention.

No checker is imported or run. Documentation and layout are excluded from
token/AST counts; all executable acceptance code and imports are retained.
"""

import ast
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent
AXES = ("raw_bytes", "normalized_bytes", "source_tokens", "normalized_tokens", "ast_nodes")


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    excluded = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
                tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
    significant = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
                   if t.type not in excluded
                   and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    norm_tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
                   if t.type not in excluded]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        if isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return {"sha256": hashlib.sha256(data).hexdigest(), "raw_bytes": len(data),
            "normalized_bytes": len(normalized.encode()), "source_tokens": len(significant),
            "normalized_tokens": len(norm_tokens), "ast_nodes": sum(1 for _ in ast.walk(tree)),
            "lines": len(source.splitlines()), "imported_modules": sorted(set(imports))}


def envelope(rows):
    return {axis: min(r["metrics"][axis] for r in rows) for axis in AXES}


def main():
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text())
    inventory = []
    for record in manifest["inventory"]:
        measured = measure(ROOT / record["path"])
        if measured["sha256"] != record["sha256"]:
            raise ValueError("Frozen comparator changed: " + record["path"])
        inventory.append({**record, "metrics": measured})
    mains = [{**r, "metrics": measure(ROOT / r["path"])} for r in manifest["main"]]
    strongest = measure(ROOT / manifest["strongest_bundled"]["path"])
    public = measure(ROOT / "checker.py")
    native = measure(ROOT / "checker_core.py")
    for record in (public, native):
        if record["imported_modules"] != ["json", "sys"]:
            raise ValueError("Unexpected trusted dependency")
    controls = [{"path": str(p.relative_to(ROOT)), "metrics": measure(p)}
                for p in sorted((ROOT / "comparison/controls").glob("*.py"))]
    minima = envelope(inventory)
    result = {"python_version": platform.python_version(),
              "snapshot_commit": manifest["snapshot"]["commit"],
              "current_main": mains, "current_main_minima": envelope(mains),
              "inventory_count": len(inventory), "inventory_minima": minima,
              "strongest_bundled": strongest, "public": public, "native": native,
              "controls": controls,
              "public_strictly_below_inventory": all(public[k] < minima[k] for k in AXES),
              "native_strictly_below_inventory": all(native[k] < minima[k] for k in AXES),
              "qualification": "Finite source comparison, not absolute program-size minimality; the inventory is not a soundness certification of every historical variant."}
    (ROOT / "comparison/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    labels = {"ipra_shared_traversal_2026-11-06.zip": "Shared traversal",
              "ipra_shared_unary_2026-11-06.zip": "Shared unary",
              "ipra_shared_unary_2026-11-06(1).zip": "Shared unary (1)",
              "ipra_typed_prefix_2026-11-06.zip": "Typed prefix",
              "ipra_typed_substitution_2026-11-06.zip": "Typed substitution",
              "ipra_unified_kernel_2026-11-06.zip": "Unified kernel"}
    table = [r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
             r"Complete acceptance program & Tokens & AST & Norm. bytes & Raw bytes \\", r"\midrule"]
    def row(label, m):
        return label + " & " + " & ".join(f'{m[k]:,}' for k in
                  ("normalized_tokens", "ast_nodes", "normalized_bytes", "raw_bytes")) + r" \\"
    table += [row(labels[r["archive"]], r["metrics"]) for r in mains]
    table += [r"\midrule", row("Smallest bundled canonical checker", strongest),
              r"\midrule", row(r"\textbf{New public checker}", public),
              row(r"\textbf{New canonical checker}", native), r"\bottomrule", r"\end{tabular}"]
    (ROOT / "comparison/table.tex").write_text("\n".join(table) + "\n")
    macros = []
    for prefix, record in (("Public", public), ("Native", native), ("Baseline", strongest)):
        for key, suffix in (("normalized_tokens", "Tokens"), ("source_tokens", "SourceTokens"),
                            ("ast_nodes", "AST"), ("normalized_bytes", "Bytes"), ("raw_bytes", "RawBytes")):
            macros.append("\\newcommand{\\" + prefix + suffix + "}{" + f'{record[key]:,}' + "}")
    (ROOT / "comparison/macros.tex").write_text("\n".join(macros) + "\n")
    print(json.dumps({k: result[k] for k in ("python_version", "inventory_count", "inventory_minima",
                    "public", "native", "public_strictly_below_inventory", "native_strictly_below_inventory")}, indent=2))


if __name__ == "__main__":
    main()
