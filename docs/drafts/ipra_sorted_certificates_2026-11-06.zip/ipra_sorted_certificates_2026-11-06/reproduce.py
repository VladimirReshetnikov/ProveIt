"""Offline reproduction of measurements, audits, translations, and article."""

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(*args):
    subprocess.run([sys.executable, *map(str, args)], cwd=ROOT, check=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-pdf", action="store_true")
    args = parser.parse_args()
    run(ROOT / "measure.py")
    run(ROOT / "validation/replay.py")
    run(ROOT / "validation/direct_checks.py")
    run(ROOT / "validation/independent_audit.py", ROOT / "checker.py", ROOT / "checker_core.py")
    run(ROOT / "proof_tools/generate_direct_examples.py", "--checker", ROOT / "checker.py",
        "--reverse", ROOT / "proof_tools/translate_to_old.py", "--output", ROOT / "examples")
    if not args.no_pdf:
        run(ROOT / "build.py")
