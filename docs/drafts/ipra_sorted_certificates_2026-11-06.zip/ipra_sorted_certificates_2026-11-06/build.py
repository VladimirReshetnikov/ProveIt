"""Compile the article and optionally rebuild its complete ZIP archive."""

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(command, cwd, log):
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True)
    log.write_text(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError("Command failed; see " + str(log))


def compile_pdf():
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    fmt = subprocess.run(["kpsewhich", "pdflatex.fmt"], capture_output=True, text=True)
    if fmt.returncode == 0 and fmt.stdout.strip():
        compiler = ["pdflatex"]
    else:
        format_path = build / "pdflatex.fmt"
        if not format_path.exists():
            run(["pdftex", "-ini", "-etex", "-jobname=pdflatex", "-progname=pdflatex", "pdflatex.ini"],
                build, build / "format.log")
        compiler = ["pdftex", "-fmt=" + str(format_path), "-progname=pdflatex"]
    for number in range(1, 4):
        run([*compiler, "-interaction=nonstopmode", "-halt-on-error", "-file-line-error",
             "-output-directory=" + str(build), "report.tex"], ROOT,
            build / ("pass_" + str(number) + ".txt"))
    log = (build / "report.log").read_text(errors="replace")
    failures = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line or "Rerun to get" in line]
    if failures:
        raise RuntimeError("Layout/reference review required: " + " | ".join(failures))
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    metadata = {"status": "compiled", "passes": 3,
                "overfull_boxes": 0, "unresolved_references": 0,
                "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest()}
    (ROOT / "validation/build_results.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print("Compiled", ROOT / "report.pdf")


def packaged_files():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and "build" not in p.relative_to(ROOT).parts
                  and "__pycache__" not in p.parts
                  and p.suffix != ".pyc" and p.name != "SHA256SUMS.txt")


def package():
    files = packaged_files()
    (ROOT / "SHA256SUMS.txt").write_text("".join(
        hashlib.sha256(p.read_bytes()).hexdigest() + "  " + str(p.relative_to(ROOT)) + "\n"
        for p in files))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in [*files, ROOT / "SHA256SUMS.txt"]:
            output.write(path, ROOT.name + "/" + str(path.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as output:
        if output.testzip() is not None:
            raise RuntimeError("ZIP integrity failed")
        for path in [*files, ROOT / "SHA256SUMS.txt"]:
            if output.read(ROOT.name + "/" + str(path.relative_to(ROOT))) != path.read_bytes():
                raise RuntimeError("ZIP content mismatch")
    shutil.copyfile(ROOT / "report.pdf", ROOT.parent / (ROOT.name + ".pdf"))
    print("Packaged", archive, "with", len(files) + 1, "files")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-only", action="store_true")
    parser.add_argument("--no-package", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        compile_pdf()
    if not args.no_package:
        package()
