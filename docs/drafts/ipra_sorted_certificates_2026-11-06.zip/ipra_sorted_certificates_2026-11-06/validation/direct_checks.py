"""Fixed independently generated cases for the changed numerical interface."""

import hashlib
import json
from pathlib import Path
from replay import ROOT, new, core, reverse, accepts


def main():
    entries = json.loads((ROOT / "validation/direct_manifest.json").read_text())["records"]
    results = []
    for row in entries:
        path = ROOT / "validation" / row["file"]
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != row["sha256"]:
            raise ValueError("Direct fixture changed: " + row["name"])
        data = json.loads(raw)
        if accepts(new, data) != row["expected"] or accepts(core, data) != row["expected"]:
            raise ValueError("Unexpected direct outcome: " + row["name"])
        if row["expected"]:
            back = reverse.translate(data)
            if back[:2] != new.erase(data)[:2]:
                raise ValueError("Direct round trip changed sequent")
        results.append({**row, "passed": True, "reverse_checked": row["expected"]})
    totals = {"status": "passed", "cases": len(results),
              "positive": sum(r["expected"] for r in results),
              "negative": sum(not r["expected"] for r in results), "records": results}
    (ROOT / "validation/direct_results.json").write_text(json.dumps(totals, indent=2) + "\n")
    print(json.dumps({k:v for k,v in totals.items() if k != "records"}, indent=2))


if __name__ == "__main__":
    main()
