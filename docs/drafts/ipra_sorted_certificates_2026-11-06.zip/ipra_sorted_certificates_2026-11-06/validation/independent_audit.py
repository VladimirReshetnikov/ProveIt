"""Independent finite-JSON grammar and named-binding audit.

No candidate substitution, constructor-scope table, or inferred conclusion
is used to construct the expected results. Candidate files are imported
only to exercise them after tests have been constructed.
"""
import argparse
import importlib.util
import itertools
import json
from pathlib import Path
import random
import sys

COUNTER = itertools.count()
Z = -1
T = ['=', Z, Z]
D = ['=', Z, ['s', Z]]


def require(x):
    if not x:
        raise ValueError('invalid grammar')


def grammar(a, formula):
    """A strict, separately written ordinary JSON grammar recognizer."""
    if type(a) is int:
        return not formula and a >= -1
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    tag = a[0]
    if formula:
        if tag == '=' and len(a) == 3:
            return grammar(a[1], False) and grammar(a[2], False)
        if tag == 'pi' and len(a) == 3:
            return grammar(a[1], True) and grammar(a[2], True)
        if tag == 'ex' and len(a) == 2:
            return grammar(a[1], True)
        return False
    if tag == 's' and len(a) == 2:
        return grammar(a[1], False)
    if tag == 'r' and len(a) == 4:
        return all(grammar(x, False) for x in a[1:])
    return False


def named(a, bound=()):
    if type(a) is int:
        if a == -1:
            return ('zero',)
        if a < len(bound):
            return ('bound', bound[a])
        return ('free', a-len(bound))
    tag = a[0]
    if tag == 'r':
        u,v = next(COUNTER), next(COUNTER)
        return ('r', named(a[1], bound), named(a[2], bound), u,v,
                named(a[3], (u,v,*bound)))
    if tag == 'pi':
        x = next(COUNTER)
        return ('pi', x, named(a[1], (x,*bound)), named(a[2], (x,*bound)))
    if tag == 'ex':
        x = next(COUNTER)
        return ('ex', x, named(a[1], (x,*bound)))
    return (tag, *(named(x,bound) for x in a[1:]))


def transform(a, replacements, shift):
    tag = a[0]
    if tag == 'free':
        i = a[1]
        return replacements[i] if i < len(replacements) else ('free',i+shift)
    if tag in ('zero','bound'):
        return a
    if tag == 'r':
        return ('r', transform(a[1],replacements,shift),
                transform(a[2],replacements,shift), a[3],a[4],
                transform(a[5],replacements,shift))
    if tag == 'pi':
        return ('pi',a[1],transform(a[2],replacements,shift),
                transform(a[3],replacements,shift))
    if tag == 'ex':
        return ('ex',a[1],transform(a[2],replacements,shift))
    return (tag, *(transform(x,replacements,shift) for x in a[1:]))


def indexed(a, bound=()):
    tag = a[0]
    if tag == 'zero':
        return -1
    if tag == 'bound':
        return bound.index(a[1])
    if tag == 'free':
        return a[1] + len(bound)
    if tag == 'r':
        return ['r', indexed(a[1],bound), indexed(a[2],bound),
                indexed(a[5],(a[3],a[4],*bound))]
    if tag == 'pi':
        return ['pi',indexed(a[2],(a[1],*bound)),indexed(a[3],(a[1],*bound))]
    if tag == 'ex':
        return ['ex',indexed(a[2],(a[1],*bound))]
    return [tag, *(indexed(x,bound) for x in a[1:])]


def oracle(a, environment, depth=0):
    binders = tuple(next(COUNTER) for _ in range(depth))
    tree = named(a, binders)
    replacements = tuple(named(t) for t in environment[:-1])
    return indexed(transform(tree,replacements,environment[-1]),binders)


def load(path):
    spec = importlib.util.spec_from_file_location('candidate_'+Path(path).stem,path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def calls_ok(f,*args,**kwargs):
    try:
        return True,f(*args,**kwargs)
    except (ValueError,TypeError,KeyError,IndexError,RecursionError):
        return False,None


def erase(a):
    if type(a) is list:
        if a == ['false']:
            return D
        return [erase(x) for x in a]
    return a


def generated(rng,formula,depth):
    if not formula:
        if depth == 0 or rng.randrange(3) == 0:
            return rng.randrange(-1,7)
        if rng.randrange(2):
            return ['s',generated(rng,False,depth-1)]
        return ['r', *(generated(rng,False,depth-1) for _ in range(3))]
    if depth == 0:
        return ['=',generated(rng,False,1),generated(rng,False,1)]
    k=rng.randrange(3)
    if k == 0:
        return ['=',generated(rng,False,depth),generated(rng,False,depth)]
    if k == 1:
        return ['pi',generated(rng,True,depth-1),generated(rng,True,depth-1)]
    return ['ex',generated(rng,True,depth-1)]


def malformed_pool():
    vals=[-1,0,2,T,['s',0],['ex',T],None,False,True,0.0,-1.0,2.5,-2,-100,'','s','ss','r','rrr','=',
          '===','pi','pipipi','ex','exex','0','-1',{},[],['s'],['r'],['='],
          ['pi'],['ex'],['false'],['s',False],['s',0.0],['=',True,False],
          ['r',0,0,False],['r',0,0],['pi',T],['ex',T,T],['bogus',T],
          {'s':-1}, {'s':1,'0':-1}, {'=':0,'0':1,'1':2},
          {'pi':None,'ex':None,'s':None},['ex',{'=':0,'0':1,'1':2}],
          ['=',-1,{'s':-1}],['r',0,0,{'s':-1}]]
    alphabet='sr=pi ex01-'
    for n in range(1,5):
        vals.extend(''.join(v) for v in itertools.product(alphabet,repeat=n))
    for keys in [('s','r'),('r','s','0','1'),('=','s','r'),('pi','=', 'ex'),('ex','=')]:
        vals.append(dict.fromkeys(keys,None))
    return vals


def test_one(path, output, certificate_format):
    mod=load(path)
    name=Path(path).stem
    literal=certificate_format in ('literal','step')
    step_rule=certificate_format=='step'
    public=hasattr(mod, 'erase')
    failures=[]
    counts={}
    def record(label, condition, detail=None):
        counts[label]=counts.get(label,0)+1
        if not condition:
            failures.append({'kind':label,'detail':detail})
    pool=malformed_pool()
    for val in pool:
        for formula in (False,True):
            ok,result=calls_ok(mod.subst,val,(0,),formula=formula)
            expect=grammar(val,formula)
            record('grammar',ok == expect,{'input':val,'sort':formula,'accepted':ok,'expected':expect})
            if ok:
                record('validated_result',grammar(result,formula) and result==val)
    rng=random.Random(490344)
    for i in range(2400):
        formula=bool(i%2)
        a=generated(rng,formula,4)
        depth=i%4
        k=i%4
        env=[generated(rng,False,2) for _ in range(k)]+[rng.randrange(-k,4)]
        expected=oracle(a,env,depth)
        ok,result=calls_ok(mod.subst,a,env,d=depth,formula=formula)
        record('named_substitution',ok and result==expected,
               {'input':a,'environment':env,'depth':depth,'expected':expected,'actual':result})
    def hyp(a):return a if literal else ['hyp',a]
    def lam(a,p):return ['lam' if literal else 'pi',a,p]
    def rec(t):return t if literal else ['rec',t]
    def check(label,data,expected):
        if not public:data=erase(data)
        ok,result=calls_ok(mod.check,data)
        record(label,ok == expected,{'certificate':data,'expected':expected,'accepted':ok})
    # Baseline positives are constructed independently of candidate infer.
    check('positive',[[T],T,hyp(T)],True)
    check('positive',[[['pi',T,T]],['pi',T,T],hyp(['pi',T,T])],True)
    check('positive',[[],['pi',T,T],lam(T,hyp(T))],True)
    r=['r',Z,Z,0]
    check('positive',[[],['=',r,Z],rec(r)],True)
    r2=['r',['s',Z],Z,0]
    check('positive',[[],['=',r2,['r',Z,Z,0]],rec(r2)],True)
    packed=['ex',['=',0,Z]]
    check('positive',[[],packed,['pack',Z,hyp(['=',0,Z])]],True)
    check('positive',[[['ex',T],T],T,['use',hyp(['ex',T]),T,hyp(T)]],True)
    # Every malformed input is tried as a context/goal, including lists whose
    # only defect is a Python Boolean alias of a valid integer term.
    invalid_formulas=[x for x in pool if not grammar(x,True) and x != ['false']]
    for v in invalid_formulas:
        check('malformed_context',[[v],T,hyp(T)],False)
        check('malformed_goal',[[T],v,hyp(T)],False)
    # Strings/dicts and wrong-sort terms are focused also at vacuous witnesses.
    focused=[None,False,True,0.0,'s','ss','r','pi','=',{}, {'s':1,'0':2},[],T,
             ['ex',T],['s',False],['r',0,0,False]]
    for v in focused:
        check('unused_pi_witness',[[['pi',T,T],T],T,
              ['use',hyp(['pi',T,T]),v,hyp(T)]],False)
        check('unused_pack_witness',[[T],['ex',T],['pack',v,hyp(T)]],False)
        if not grammar(v,True):
            check('malformed_pi_guard',[[],['pi',T,T],lam(v,hyp(T))],False)
        check('malformed_rec_body',[[],['=',['r',Z,Z,0],Z],rec(['r',Z,Z,v])],False)
    # Branch mistakes and eigenvariable escapes. All goals here are legal.
    eqx=['=',0,Z]
    check('escape',[[eqx],['pi',T,eqx],lam(T,hyp(eqx))],False)
    check('escape',[[['ex',eqx]],eqx,['use',hyp(['ex',eqx]),eqx,hyp(eqx)]],False)
    if step_rule:
        numerical_templates=[['=',0,0], ['=',0,3], ['ex',['=',0,1]],
                             ['pi',['=',0,1],['=',1,0]],
                             ['ex',['pi',['=',0,2],['=',1,4]]]]
        for P in numerical_templates:
            base=oracle(P,[Z,0])
            H=P if P[0]=='=' else base
            required_step=['pi',H,oracle(P,[['s',0],0])]
            numerical=['pi',base,P]
            check('independent_numerical',[[required_step],numerical,
                  ['nat',P,hyp(required_step)]],True)
            # Check the forward implication has all parameters in their
            # original positions, rather than accepting a smaller closure.
            incorrect=['pi',base,oracle(P,[1])]
            if incorrect != numerical:
                check('numerical_parameter_shift',[[required_step],incorrect,
                      ['nat',P,hyp(required_step)]],False)
            if P[0]!='=':
                forbidden=['pi',P,oracle(P,[['s',0],0])]
                check('quantified_induction',[[forbidden],numerical,
                      ['nat',P,hyp(forbidden)]],False)
                check('quantified_induction',[[],numerical,
                      ['nat',P,lam(base,hyp(P))]],False)
        # A proved step with a fixed arbitrary parameter, nested recursion,
        # and actual dependence on the induction variable. The step itself
        # uses only the zero computation schema, so needs no trusted builder.
        term=['r',0,1,['s',0]]
        P=['=',['r',Z,term,Z],term]
        term_next=oracle(term,[['s',0],0])
        q=lam(P,rec(['r',Z,term_next,Z]))
        conclusion=['pi',oracle(P,[Z,0]),P]
        check('proved_numerical_parameter',[[],conclusion,['nat',P,q]],True)
        # Compound case with fresh witness scope nested inside the step
        # parameter scope. Free parameter a remains free throughout.
        inner=['r',1,2,0]
        C=['ex',['=',['r',Z,inner,Z],inner]]
        cb=oracle(C,[Z,0])
        inner_next=['r',['s',1],2,0]
        cq=lam(cb,['pack',Z,rec(['r',Z,inner_next,Z])])
        check('proved_compound_parameter',[[],['pi',cb,C],['nat',C,cq]],True)
        for bad in (None,True,False,0,'pi',{},['=',True,False],['s',0],['ex',0]):
            check('malformed_numerical_matrix',[[],['pi',T,T],
                  ['nat',bad,lam(T,hyp(T))]],False)
        for bad in (None,False,0,'pi',{},[],['lam'],['nat',T],['r',Z,Z]):
            check('malformed_step_proof',[[],['pi',T,T],['nat',T,bad]],False)
        # The canonical companion uses explicit arithmetic falsity. The
        # public interface independently exercises erasure in matrices,
        # contexts, hypotheses, and nested introduction/packing records.
        F=['false']
        fp=lam(F,hyp(F))
        check('native_false',[[],['pi',F,F],['nat',F,fp]],True)
        ef=['ex',F]
        check('native_false',[[],['pi',ef,ef],['nat',ef,lam(ef,hyp(ef))]],True)
        check('native_false',[[F],ef,['pack',Z,hyp(F)]],True)
        check('native_false',[[F],F,hyp(F)],True)
        check('native_false',[[F],ef,['pack',F,hyp(F)]],False)
    else:
        check('malformed_rule',[[],T,['nat',True]],False)
        check('malformed_rule',[[],T,['nat',['pi',T,T]]],False)
        for P in (['=',0,0], ['ex',['=',0,1]], ['pi',['=',0,1],['=',1,0]]):
            base=oracle(P,[Z,0])
            H=P if P[0]=='=' else base
            numerical_step=['pi',H,oracle(P,[['s',0],0])]
            numerical=['pi',base,['pi',oracle(numerical_step,[2]),oracle(P,[1])]]
            check('independent_numerical',[[],numerical,['nat',P]],True)
            if P[0]!='=':
                wrongstep=['pi',P,oracle(P,[['s',0],0])]
                wrong=['pi',base,['pi',oracle(wrongstep,[2]),oracle(P,[1])]]
                check('quantified_induction',[[],wrong,['nat',P]],False)
    if literal:
        # Previously invalid bare formulas intentionally become hypotheses.
        check('literal_boundary',[[T],T,T],True)
        check('literal_boundary',[[T],T,['hyp',T]],False)
        check('literal_boundary',[[],['pi',T,T],['pi',T,T]],False)
        check('literal_boundary',[[['pi',T,T]],['pi',T,T],['pi',T,T]],True)
        check('literal_boundary',[[],['pi',T,T],['pi',T,T]],False)
        check('literal_boundary',[[T],T,['='] ],False)
        # Boolean equality aliases are harmless only because stored formulas
        # are returned. The malformed spelling is never returned as theorem.
        canonical=['=',0,0]
        check('alias',[[canonical],canonical,['=',False,False]],True)
        check('alias',[[canonical],['=',False,False],canonical],False)
    result={'candidate':str(path),'certificate_format':certificate_format,'counts':counts,'total':sum(counts.values()),
            'failures':failures,'passed':not failures}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='failures'},indent=2))
    if failures:print(json.dumps(failures[:5],indent=2))
    return not failures


def main():
    ap=argparse.ArgumentParser();ap.add_argument('candidates',nargs='+');ap.add_argument('--out',default=str(Path(__file__).resolve().parent / 'audit_results'));ap.add_argument('--format',choices=('legacy','literal','step'),default='step');args=ap.parse_args()
    ok=True
    for path in args.candidates:
        ok=test_one(path,Path(args.out)/(Path(path).stem+'_audit.json'),args.format) and ok
    sys.exit(0 if ok else 1)


if __name__=='__main__':main()
