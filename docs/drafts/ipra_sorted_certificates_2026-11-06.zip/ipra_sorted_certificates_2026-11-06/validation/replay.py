"""Replay fixed old certificates and verify both finite proof translations."""

import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


forward = load("forward_translation", ROOT / "proof_tools/translate_to_new.py")
reverse = load("reverse_translation", ROOT / "proof_tools/translate_to_old.py")
core = load("canonical_kernel", ROOT / "checker_core.py")
new = reverse.new
old = reverse.old


def accepts(kernel, data):
    try:
        kernel.check(data)
        return True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        return False


def main():
    manifest = json.loads((ROOT / "validation/legacy_manifest.json").read_text())
    out = ROOT / "validation/translated"
    out.mkdir(exist_ok=True)
    rows = []
    cli_count = 0
    for entry in manifest["records"]:
        source = ROOT / "validation" / entry["file"]
        raw = source.read_bytes()
        if hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            raise ValueError("fixture changed: " + entry["name"])
        data = json.loads(raw)
        expected = entry["accepted"]
        if accepts(old, data) != expected:
            raise ValueError("frozen reference disagrees: " + entry["name"])
        translated = forward.translate(data)
        for kernel in (new, core):
            if accepts(kernel, translated) != expected:
                raise ValueError("candidate disagrees: " + entry["name"])
        reverse_checked = False
        if expected:
            returned = reverse.translate(translated)
            if returned[:2] != old.erase(data)[:2]:
                raise ValueError("translation changed the sequent")
            reverse_checked = True
        target = out / (entry["name"] + ".json")
        target.write_text(json.dumps(translated, separators=(",", ":")) + "\n")
        for checker in ("checker.py", "checker_core.py"):
            for optimized in (False, True):
                args = [sys.executable, *(["-O"] if optimized else []),
                        str(ROOT / checker), str(target)]
                result = subprocess.run(args, capture_output=True, text=True)
                wanted = (0, "ACCEPT\n") if expected else (1, "REJECT\n")
                if (result.returncode, result.stdout) != wanted:
                    raise ValueError("CLI disagreement: " + repr(args))
                cli_count += 1
        rows.append({**entry, "new_public": expected, "new_canonical": expected,
                     "reverse_checked": reverse_checked,
                     "translated_sha256": hashlib.sha256(target.read_bytes()).hexdigest()})

    examples = []
    for entry in json.loads((ROOT / "validation/legacy_examples.json").read_text()):
        data = json.loads((ROOT / "validation" / entry["file"]).read_text())
        old.check(data)
        translated = forward.translate(data)
        new.check(translated)
        core.check(translated)
        returned = reverse.translate(translated)
        if returned[:2] != old.erase(data)[:2]:
            raise ValueError("demonstration changed its sequent")
        target = ROOT / "examples" / (entry["name"] + ".json")
        target.write_text(json.dumps(translated, separators=(",", ":")) + "\n")
        examples.append({**entry, "accepted_by_public_and_core": True,
                         "reverse_checked": True,
                         "assumptions": len(translated[0]),
                         "bytes": target.stat().st_size,
                         "sha256": hashlib.sha256(target.read_bytes()).hexdigest()})

    result = {"status": "passed", "positive": sum(r["accepted"] for r in rows),
              "negative": sum(not r["accepted"] for r in rows),
              "positive_round_trips": sum(r["reverse_checked"] for r in rows),
              "cli_invocations": cli_count, "records": rows, "examples": examples,
              "qualification": "Finite regression evidence; mathematical equivalence is proved in the article."}
    (ROOT / "validation/replay_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k not in ("records", "examples")}, indent=2))
    print("Additional translated and reverse-checked demonstrations:", len(examples))


if __name__ == "__main__":
    main()
