UNIFORM DISTINCT UNIONS: JOINT LAWS, CONCENTRATION, AND A GAUSSIAN LIMIT
Research package prepared 25 November 2026 (America/Los_Angeles)

STATUS AND SCOPE

This package proves quantitative results for a specified class of generated
union-closed families. It does not prove the full union-closed sets conjecture
and does not improve a universal frequency constant for arbitrary families.
The paper gives mathematical proofs; historical novelty is a separate claim.
Targeted searches found no exact predecessor for the combined conclusions,
but neither publication priority nor an exhaustive literature review is
claimed. The results are presented as candidate original applications of
established tools, with their assumptions and prior ingredients explicit.

MODEL AND NOTATION

Let B_1,...,B_m be finite generators on a ground set X of size n. Every
point belongs to exactly r generators, every generator has d points, and
different generators intersect in at most one point. Assume r>=2, d>=1,
and a nonempty generator system. Then n=md/r. Let F be the family of ALL
DISTINCT unions of generators, including the empty union, and take U
uniformly from F. Repeated representations of one union are counted once.

The comparison law independently selects each generator with probability
1/2 and takes their union. Its point indicators need not be independent:
shared generators create dependence. The main joint law preserves this
dependence rather than replacing the indicators by independent Bernoulli
variables. Write

  a = 1-2^(1-r),   z = a^d,   Delta = d^2(r-1)^2,
  tau = Delta*z,  xi = z/[2(1-tau)],   p = 1-2^(-r).

The count, growing-window, and concentration bounds below require the
explicit sufficient condition 2*Delta*z<=1. Under it xi is rational,
0<xi<=z<1, and xi*(1-xi)^Delta>=z/2. No numerical root finding is needed.

MAIN QUANTITATIVE CONCLUSIONS

1. Number of distinct unions:

     |F| >= [2(1-xi)]^m.

2. Joint law on any k selected ground points: define

     b_k = min(m, r*k*[1+(d-1)(r-1)]).

   The total variation distance from the fair-generator comparison law on
   those points is at most 1-(1-xi)^b_k, and hence at most b_k*xi.
   For fixed r this tends to zero whenever k=o(a^(-d)/d), uniformly in
   the number of generators. The paper gives a more precise neighborhood
   version and a separate switching theorem with exterior conditioning.

3. Every-element frequency: with b_1 as above, every point x satisfies

     max(0, 1-2^(-r)*(1-xi)^(-b_1)) <= P(x in U) <= p.

   For every fixed r and all sufficiently large d, the explicit lower
   bound strictly improves the particular switching bound in the supplied
   draft. The paper gives the asymptotic comparison and certified examples.

4. Size concentration: write Y=|U|/n and use natural logarithms. Define

     D(t||p) = t*log(t/p)+(1-t)*log((1-t)/(1-p)),

   with the continuous endpoint convention. For p<t<=1 the upper tail,
   and for 0<=t<p the lower tail, is bounded respectively by

     min(1, exp{-m*[D(t||p)/r + log(1-xi)]}).

   A fixed nonzero deviation has a positive exponential rate for all
   sufficiently large d. The bound is valid but may be uninformative if
   the bracket is nonpositive. Outward thresholds outside [0,1] have
   empty tails. These estimates concern uniform DISTINCT unions.

5. Gaussian limit: along any sequence of these systems with fixed r,
   d tending to infinity, and m*a^d tending to zero,

     (|U|-n*p)/(2^(-r)*d*sqrt(m))  ==>  N(0,1).

   This theorem does not require a separate local-lemma assumption.
   Its proof uses an exact Walsh expansion. The normalized nonlinear
   remainder has variance (2^r-r-1)/(r*d) in the product comparison model,
   and the conditioning error in total variation is at most m*a^d/2.
   The paper also justifies the corresponding actual-mean and variance
   asymptotics; they do not follow from weak convergence alone.

WHAT IS ADDED, AND WHAT WAS ALREADY KNOWN

The supplied ProveIt generator draft already gives the dual representation,
a one-coordinate switching bound, single-point convergence to 1-2^(-r),
and abundance thresholds. The proposed additions concern a sharper explicit
frequency bound, many coordinates jointly, growing windows, distinct-union
counts, size concentration, and the Gaussian law. The exterior-conditioned
switching extension is separate
from the unconditioned local-lemma argument.

The Lovasz local lemma and its conditional-distribution estimate, read-k
Chernoff bounds, Walsh orthogonality, Parseval, and the classical CLT are
established tools. Their authors and relevant antecedents are cited in the
paper and literature_audit.txt. No generic new version of those tools is
claimed. This package is a research manuscript, not external peer review.

FILES AND REPRODUCTION

paper.tex and paper.pdf contain the complete paper. literature_audit.txt
records the searches and source comparisons. SOURCE_PROVENANCE.txt records
the inspected upstream draft and its digests. The code directory contains
the finite checks and aggregate certificate script, with JSON reports.

From the extracted package directory, run:

  python3 code/check_local.py
  python3 code/check_lll.py
  python3 code/check_gaussian.py
  python3 code/certify_results.py
  latexmk -pdf paper.tex

The Python checks require Python 3.10 or later and use only its standard
library, including exact integer and Fraction arithmetic. No third-party
Python packages are needed. Floating-point fields in reports are for display;
the intervals in numerical_certificates.json are rationally certified.
The KL checks avoid floating logarithms
by converting the tested inequalities to rational inequalities. The
Gaussian checks verify finite Walsh identities and moments; they do not
claim to numerically establish an asymptotic normal limit. The LaTeX build
requires an installed TeX distribution and latexmk. SHA256SUMS records the
delivered files; from the package root, verify it with:

  sha256sum -c SHA256SUMS

These scripts provide reproducible finite evidence and check the reported
certificates. They are not a proof-assistant formalization, and finite
enumeration does not replace the general arguments in paper.tex. The
literature assessment is a manual research audit; failed searches cannot
prove that no differently phrased or unpublished antecedent exists.
