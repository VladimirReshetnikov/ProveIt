#!/usr/bin/env python3
"""Exact rational certificates for the displayed examples.
No third-party dependencies. No floating-point inequality is used.
"""
from fractions import Fraction as F
from pathlib import Path
import json
import math

ROOT = Path(__file__).resolve().parents[1]

def floor_decimal(x, digits=9):
    sign = "-" if x < 0 else ""
    if x < 0:
        return "-" + ceil_decimal(-x, digits)
    scale=10**digits
    n=x.numerator*scale//x.denominator
    return f"{n//scale}.{n%scale:0{digits}d}"

def ceil_decimal(x, digits=9):
    if x < 0:
        return "-" + floor_decimal(-x, digits)
    scale=10**digits
    n=(x.numerator*scale+x.denominator-1)//x.denominator
    return f"{n//scale}.{n%scale:0{digits}d}"

def interval_strings(iv, digits=22):
    return [floor_decimal(iv[0],digits),ceil_decimal(iv[1],digits)]

def log_interval(x, terms=100):
    """Atanh series and an exact absolute remainder bound."""
    assert x > 0
    t=(x-1)/(x+1)
    t2=t*t
    power=t
    total=F(0)
    for j in range(terms):
        total += power/F(2*j+1)
        power *= t2
    remainder=2*abs(power)/(F(2*terms+1)*(1-t2))
    return (2*total-remainder,2*total+remainder)

def binary_kl_interval(s,p):
    assert 0<s<1 and 0<p<1
    a=log_interval(s/p)
    b=log_interval((1-s)/(1-p))
    return (s*a[0]+(1-s)*b[0],s*a[1]+(1-s)*b[1])

def exp_negative_upper(t, terms=250):
    """e^(-t) <= reciprocal of a finite positive Taylor sum."""
    assert t>=0
    term=total=F(1)
    for j in range(1,terms+1):
        term *= t/j
        total += term
    return 1/total

def params(r,d):
    q=F(1,2**r)
    a=1-2*q
    z=a**d
    Delta=d*d*(r-1)**2
    assert 2*Delta*z<=1
    xi=z/(2*(1-Delta*z))
    assert 0<xi<1 and z/2<=xi<=z
    assert xi*(1-Delta*xi)>=z/2
    return q,a,z,Delta,xi,r*(1+(d-1)*(r-1))

def frequency_row(r,d):
    q,a,z,D,xi,R=params(r,d)
    new=1-q/(1-xi)**R
    B=min(F(1),r*a**(d-1)+r*(d-1)*(r-1)*a**(d-r))
    old=1-F(1,1+(2**r-1)*(1-B))
    assert new>old
    return {
        "r":r,"d":d,
        "old_lower_floor":floor_decimal(old,12),
        "new_lower_floor":floor_decimal(new,12),
        "new_lower_interval":interval_strings((new,new)),
        "xi_interval":interval_strings((xi,xi)),
        "strict_improvement_certified":True,
    }

def threshold(r):
    a=1-F(1,2**(r-1))
    d=1
    while True:
        if 2*d*d*(r-1)**2*a**d<=1 and a*(d+1)**2<d*d:
            # All previous degrees (except the isolated r=2,d=1) fail.
            for j in range(2,d):
                assert 2*j*j*(r-1)**2*a**j>1
            return d
        d+=1

def main():
    rows=[frequency_row(3,d) for d in (32,40,60,100)]
    rows += [frequency_row(4,d) for d in (89,100,150)]
    thresholds={str(r):threshold(r) for r in range(2,9)}
    assert list(thresholds.values())==[7,32,89,221,517,1169,2589]

    # Concrete example: r=3,d=40,m>=3000, deviations 1/10.
    q,a,z,D,xi,R=params(3,40)
    p=1-q
    L=log_interval(1-xi)
    rates=[]
    for s in (p-F(1,10),p+F(1,10)):
        kl=binary_kl_interval(s,p)
        rates.append((kl[0]/3+L[0],kl[1]/3+L[1]))
    gamma_lower=min(rate[0] for rate in rates)
    claimed_gamma=F(12727,10**6)
    assert gamma_lower>claimed_gamma
    tail_upper=2*exp_negative_upper(3000*claimed_gamma)
    assert tail_upper < F(53,10**18) # 5.3e-17
    assert 1-q/(1-xi)**R > F(87484,100000)

    # Large-window example: one million ground elements, r=3,d=100.
    q100,a100,z100,D100,xi100,R100=params(3,100)
    tv_linear=10**6*R100*xi100
    assert tv_linear < F(96,10**6) # 0.000096

    # Exact integer primality and connected example parameter checks.
    P=1009
    assert all(P%j for j in range(2,math.isqrt(P)+1))
    assert P>40 and 3*P==3027 and 40*P==40360

    result={
      "status":"PASS",
      "arithmetic":"fractions.Fraction; rational atanh log remainder; reciprocal positive exponential series",
      "frequency_rows":rows,
      "lll_condition_onset_for_all_larger_d":thresholds,
      "example_r3_d40_m_at_least3000":{
        "lower_tail_rate":interval_strings(rates[0]),
        "upper_tail_rate":interval_strings(rates[1]),
        "certified_rate_lower":"0.012727",
        "two_sided_tail_upper":ceil_decimal(tail_upper,25),
        "claimed_tail_upper":"0.000000000000000053",
        "frequency_strict_lower":"0.87484",
        "density_interval":["0.775","0.975"],
      },
      "example_r3_d100_k1000000":{
        "tv_linear_upper_interval":interval_strings((tv_linear,tv_linear)),
        "claimed_strict_upper":"0.000096"
      },
      "affine_example":{"prime":P,"r":3,"d":40,"m":3027,"n":40360},
      "limits":"The certificates verify finite displayed numbers, not historical novelty or the infinite theorems."
    }
    (ROOT/"data"/"numerical_certificates.json").write_text(json.dumps(result,indent=2)+"\n")

    table_lines=[]
    for row in rows:
        table_lines.append(f"{row['r']} & {row['d']} & {row['old_lower_floor']} & {row['new_lower_floor']} \\\\")
    tex=r"""\subsection{Certified numerical consequences}
\label{sec:numerics}
Table~\ref{tab:frequency} gives lower bounds rounded down. Each strict
comparison between the underlying exact rational expressions was checked
with integer arithmetic. Using $R$ instead of $t_1$ makes the new
column valid independently of the number of generators.

\begin{table}[ht]
\centering
\begin{tabular}{rrrr}
\toprule
$r$ & $d$ & Prior draft bound & New bound \\
\midrule
""" + "\n".join(table_lines) + r"""
\bottomrule
\end{tabular}
\caption{Guaranteed frequency of \emph{every} ground element.
The limits are $7/8$ for $r=3$ and $15/16$ for $r=4$.}
\label{tab:frequency}
\end{table}

For $r=3$, $d=40$, and any $m\ge3000$, every element belongs to
more than $87.484\%$ of the distinct unions. The fraction of distinct
unions whose size lies outside the interval $[0.775n,0.975n]$ is
less than
\[
 5.3\times10^{-17}.
\]
Indeed the smaller of the two one-sided rates in
\eqref{eq:tail-upper} is greater than $0.012727$, and
$2e^{-3000(0.012727)}<5.3\times10^{-17}$. Both numerical assertions
are certified by rational series bounds. An explicit connected instance
has $P=1009$ in \cref{sec:examples}, hence $m=3027$ generators
and $n=40360$ ground elements.

For $r=3$, $d=100$, the joint membership law of any one million
distinct ground elements, if that many are present, differs from the
fair-generator reference law in total variation by less than
\[
 0.000096.
\]
This follows already from the linear estimate
$10^6 R\xi<0.000096$, uniformly in $m$. If their generator supports
are disjoint, the reference law consists of independent Bernoulli$(7/8)$
bits; otherwise it includes the prescribed overlaps.

The sufficient local lemma condition is valid for every $d$ at or
above the following values:
\[
\begin{array}{c|rrrrrrr}
 r&2&3&4&5&6&7&8\\ \hline
 d&7&32&89&221&517&1169&2589.
\end{array}
\]
These are thresholds for the sufficient condition used here, not
minimal degrees for Frankl's conjecture. The isolated case $r=2,d=1$
also satisfies the condition. The check for all subsequent $d$ uses
$a(d+1)^2<d^2$ once the listed threshold is reached.
"""
    (ROOT/"numerical_results.tex").write_text(tex)
    print(json.dumps({"status":"PASS","frequency_rows":len(rows),"thresholds":thresholds,
                      "example_rate_lower":"0.012727","tail_upper":"5.3e-17",
                      "million_window_tv":"0.000096"},indent=2))

if __name__=="__main__":
    main()

