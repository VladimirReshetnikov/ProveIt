#!/usr/bin/env python3
"""Exact checks for LLL conditioning and read-d concentration.

The exponential relative-entropy tail bounds are checked after raising
both sides to an integer power, so no floating point or numerical logs
are used in assertions. Floats are only used to report small bounds.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations
from math import comb
from pathlib import Path
import json


def valid_lll(r,d):
    base=1<<(r-1)
    return 2*(d*(r-1))**2*(base-1)**d<=base**d


def parameters(r,d):
    a=1-Q(1,1<<(r-1));x=a**d
    return a,x,(d*(r-1))**2


def lll_parameter(r,d):
    """Refined rational parameter xi; requires the sufficient condition."""
    assert valid_lll(r,d)
    _,z,delta=parameters(r,d)
    xi=z/(2*(1-delta*z))
    assert Q(0)<xi<1
    assert z/2<=xi<=z
    # Bernoulli: (1-xi)^delta >= 1-delta*xi, hence this proves
    # the standard LLL inequality p=z/2 <= xi*(1-xi)^delta.
    assert xi*(1-delta*xi)>=z/2
    return xi


def tail_check(dist,g,r,d,t,upper,conditioned=True):
    """dist is exact probability mass represented by integer counts.

    Product bound: P(tail)<=exp[-g/r * D(t||q)].
    Conditioned bound: divide its RHS by (1-xi)^g.
    """
    q=1-Q(1,1<<r);total=sum(dist.values())
    if upper:
        assert t>q
        count=sum(v for z,v in dist.items() if z>=t)
    else:
        assert t<q
        count=sum(v for z,v in dist.items() if z<=t)
    prob=Q(count,total)
    A=t.numerator;B=t.denominator
    rhsbase=(q/t)**A*((1-q)/(1-t))**(B-A)
    corrected=prob
    if conditioned:
        assert valid_lll(r,d)
        x=lll_parameter(r,d)
        corrected*= (1-x)**g
    assert corrected**(r*B)<=rhsbase**g, (g,r,d,t,upper)
    return {'threshold':str(t),'direction':'upper' if upper else 'lower',
            'actual_probability':str(prob)}


def common_checks(name,g,r,d,dist,fair,local):
    _,z,delta=parameters(r,d)
    good=Q(sum(dist.values()),1<<g)
    assert sum(fair.values())==1<<g
    out={'name':name,'generators':g,'r':r,'d':d,'family_size':sum(dist.values()),
         'good_probability':str(good),'lll_sufficient_condition':valid_lll(r,d)}
    p=1-Q(1,1<<r)
    mean0=sum((z*c for z,c in fair.items()),Q(0))/(1<<g)
    var0=sum(((z-p)**2*c for z,c in fair.items()),Q(0))/(1<<g)
    M=g*d//r
    assert mean0==p
    assert var0==(p*(1-p)+r*(d-1)*Q(1,1<<(2*r)))/M
    tailresults=[]
    if valid_lll(r,d):
        x=lll_parameter(r,d)
        out['refined_lll_parameter']=str(x)
        assert good>=(1-x)**g
        for k,tv,exact_events in local:
            qbound=min(g,r*k*(1+(d-1)*(r-1)))
            assert exact_events<=qbound
            bound=1-(1-x)**qbound
            assert tv<=bound
            tailresults.append({'k':k,'actual_local_tv':str(tv),
                                'tv_bound_float':float(bound)})
        out['local_tv_checks']=tailresults
    tails=[]
    for eps in (Q(1,10),Q(1,5)):
        for upper in (False,True):
            t=p+eps if upper else p-eps
            if not 0<t<1:continue
            tail_check(fair,g,r,d,t,upper,False)
            if valid_lll(r,d):tails.append(tail_check(dist,g,r,d,t,upper,True))
    out['conditioned_tail_checks']=tails
    return out


def complete(n):
    M=comb(n,2);fair=Counter();dist=Counter()
    for s in range(n+1):
        z=1-Q(comb(s,2),M);fair[z]+=comb(n,s)
        if s!=1:dist[z]+=comb(n,s)
    assert sum(dist.values())==(1<<n)-n
    local=[]
    for k in (1,2,3):
        t=2*k
        if t>n:continue
        tv=Q(0)
        for pattern in range(1<<t):
            omitted=(n-t) if pattern==0 else (1 if pattern.bit_count()==1 else 0)
            count=(1<<(n-t))-omitted
            tv+=abs(Q(count,sum(dist.values()))-Q(1,1<<t))
        local.append((k,tv/2,n))
    return common_checks('K_'+str(n),n,2,n-1,dist,fair,local)


def bipartite(d):
    fair=Counter();dist=Counter()
    for left in range(d+1):
        for right in range(d+1):
            z=1-Q(left*right,d*d);count=comb(d,left)*comb(d,right)
            fair[z]+=count
            if (left>0 and right>0) or (left==0 and right==0):dist[z]+=count
    assert sum(dist.values())==1+((1<<d)-1)**2
    # Independently enumerate all 2^(2d) bit patterns through d=8.
    if d<=8:
        brute=Counter();mask=(1<<d)-1
        for t in range(1<<(2*d)):
            left=(t&mask).bit_count();right=(t>>d).bit_count()
            if (left and right) or not t:brute[1-Q(left*right,d*d)]+=1
        assert brute==dist
    local=[]
    for k in (1,2,3):
        if k>d:continue
        tv=Q(0)
        for pl in range(1<<k):
            for pr in range(1<<k):
                count=((1<<(d-k))-(pl==0))*((1<<(d-k))-(pr==0))
                count+=pl==0 and pr==0
                tv+=abs(Q(count,sum(dist.values()))-Q(1,1<<(2*k)))
        local.append((k,tv/2,2*d))
    return common_checks('K_'+str(d)+','+str(d),2*d,2,d,dist,fair,local)


def small_hypergraph(name,g,r,d,edges):
    fair=Counter();dist=Counter()
    for t in range(1<<g):
        contained=[e for e in edges if t&e==e]
        covered=0
        for e in contained:covered|=e
        z=1-Q(len(contained),len(edges));fair[z]+=1
        if covered==t:dist[z]+=1
    return common_checks(name,g,r,d,dist,fair,[])


def threshold_table():
    rows=[]
    for r in range(2,9):
        d=1
        a=1-Q(1,1<<(r-1))
        while not valid_lll(r,d) or (d+1)**2*a>=d**2:d+=1
        a,z,delta=parameters(r,d)
        x=lll_parameter(r,d)
        assert (d+1)**2*a<d**2 # Ensures sufficient condition for all larger d.
        assert d==1 or not valid_lll(r,d-1)
        s=r*(1+(d-1)*(r-1))
        # Bernoulli gives (1-x)^s >= 1-s*x. Use this exact rational
        # relaxation to avoid needlessly huge numerator powers at r=8.
        denominator_lower=1-s*x
        assert denominator_lower>Q(1,1<<(r-1))
        rows.append({'r':r,'first_d_for_sufficient_lll':d,
                     'failure_parameter_float':float(z),
                     'lll_parameter_float':float(x),
                     'proved_coordinate_lower_bound_float':float(1-Q(1,1<<r)/denominator_lower)})
    return rows


def main():
    fano=sorted({(1<<(u-1))|(1<<(v-1))|(1<<((u^v)-1))
                  for u in range(1,8) for v in range(u+1,8)})
    affine=[]
    for a in range(3):
        for b in range(3):affine.append(sum(1<<(3*x+(a*x+b)%3) for x in range(3)))
    for c in range(3):affine.append(sum(1<<(3*c+y) for y in range(3)))
    out={'thresholds':threshold_table(),
         'complete_graphs':[complete(n) for n in range(2,81)],
         'complete_bipartite_graphs':[bipartite(d) for d in range(2,11)],
         'small_hypergraphs':[
             small_hypergraph('Fano plane',7,3,3,fano),
             small_hypergraph('Affine plane of order 3',9,3,4,affine)],
         'status':'all exact assertions passed'}
    dest=Path(__file__).resolve().parents[1]/'data'/'lll_check_results.json'
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'thresholds':out['thresholds'],
         'complete_graph_cases':len(out['complete_graphs']),
         'bipartite_cases':len(out['complete_bipartite_graphs']),
         'hypergraph_cases':len(out['small_hypergraphs'])},indent=2))


if __name__=='__main__':main()
