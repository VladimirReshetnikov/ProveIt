#!/usr/bin/env python3
"""Exact finite checks of the witness lemma and local comparison.

These checks are evidence for implementation and boundary conditions, not
a substitute for the general proof. Only Python's standard library is used.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations
from math import comb
from pathlib import Path
import json


def edge_unions(edges):
    out={0}
    for e in edges:
        out |= {t|e for t in list(out)}
    return sorted(out)


def tv_trace(family,j):
    c=Counter(t&j for t in family)
    # All traces in the Boolean cube on J.
    total=Q(0);s=j
    while True:
        total+=abs(Q(c[s],len(family))-Q(1,1<<j.bit_count()))
        if s==0:break
        s=(s-1)&j
    return total/2


def local_data(edges,j):
    neighborhood=0
    for e in edges:
        if e&j:neighborhood|=e
    lists={};beta=Q(0)
    for w in range(neighborhood.bit_length()):
        bit=1<<w
        if not neighborhood&bit:continue
        ls=[e for e in edges if e&bit and not ((e^bit)&j)]
        # For graph examples, and linear hypergraph examples, petals
        # are disjoint automatically; verify this hypothesis explicitly.
        petals=0
        for e in ls:
            petal=e^bit
            assert not petals&petal
            petals|=petal
        lists[w]=ls
        b=Q(1)
        for e in ls:b*=1-Q(1,1<<(e.bit_count()-1))
        beta+=b
    return neighborhood,lists,min(Q(1),beta)


def verify_case(edges,check_completions=True):
    fam=edge_unions(edges);sfam=set(fam)
    cases=0;nontrivial=0
    for j in fam:
        if not j:continue
        n,lists,beta=local_data(edges,j)
        assert tv_trace(fam,j)<=beta,(edges,j,beta)
        cases+=1;nontrivial+=beta<1
        if not check_completions:continue
        for t in fam:
            if t&j!=j:continue
            good=all(not(t&(1<<w)) or any(t&e==e for e in ls)
                     for w,ls in lists.items())
            if not good:continue
            s=j
            while True:
                assert (t&~j)|s in sfam
                if s==0:break
                s=(s-1)&j
    return {'unions':len(fam),'blocks_checked':cases,
            'bounds_below_one':nontrivial}


def all_small_graphs():
    total=0;blocks=0;nontrivial=0
    per_n=[]
    for n in range(1,6):
        possible=[(1<<i)|(1<<j) for i,j in combinations(range(n),2)]
        subtot=0
        for code in range(1<<len(possible)):
            edges=[e for i,e in enumerate(possible) if code>>i&1]
            s=verify_case(edges)
            total+=1;subtot+=1;blocks+=s['blocks_checked']
            nontrivial+=s['bounds_below_one']
        per_n.append({'vertices':n,'graphs':subtot})
    return {'graphs':total,'blocks_checked':blocks,
            'bounds_below_one':nontrivial,'per_n':per_n}


def variance_check(edges,n,r,d):
    fam=edge_unions(edges);m=len(edges);p=1-Q(1,1<<r)
    ds=[Q(sum(t&e!=e for e in edges),m) for t in fam]
    mean=sum(ds,Q(0))/len(ds)
    second=sum(((x-p)**2 for x in ds),Q(0))/len(ds)
    var=sum(((x-mean)**2 for x in ds),Q(0))/len(ds)
    v0=(p*(1-p)+r*(d-1)*Q(1,1<<(2*r)))/m
    # Independently enumerate all fair generator-bit choices.
    fair=[Q(sum(t&e!=e for e in edges),m) for t in range(1<<n)]
    fair_mean=sum(fair,Q(0))/len(fair)
    fair_var=sum(((x-p)**2 for x in fair),Q(0))/len(fair)
    assert fair_mean==p
    assert fair_var==v0
    if d>=2*r:
        a=1-Q(1,1<<(r-1))
        b2=min(Q(1),2*r*a**(d-2*r)*(a**(r-1)+(d-1)*(r-1)))
        assert abs(second-v0)<=b2
    return {'generator_vertices':n,'ground_elements':m,'r':r,'d':d,
            'unions':len(fam),'actual_mean':str(mean),
            'actual_variance':str(var),'fair_variance':str(v0),
            'actual_centered_second':str(second)}


def fano():
    # Nonzero vectors of F_2^3; lines {u,v,u+v}.
    return sorted({(1<<(u-1))|(1<<(v-1))|(1<<((u^v)-1))
                   for u in range(1,8) for v in range(u+1,8)})


def affine_three(q):
    # Points of F_q^2, and all affine lines, for q=3.
    index=lambda x,y:x*q+y
    es=[]
    for a in range(q):
        for b in range(q):
            es.append(sum(1<<index(x,(a*x+b)%q) for x in range(q)))
    for c in range(q):es.append(sum(1<<index(c,y) for y in range(q)))
    return es


def complete_graph_closed_form(n,k):
    # For K_n, admissible T are precisely the empty set and subsets of
    # size at least 2. Use k disjoint target edges if possible.
    assert 2*k<=n
    d=n-1;r=2;j_size=2*k;den=(1<<n)-n
    tv=Q(0)
    for s in range(1<<j_size):
        deleted=(n-j_size) if s==0 else (1 if s.bit_count()==1 else 0)
        count=(1<<(n-j_size))-deleted
        tv+=abs(Q(count,den)-Q(1,1<<j_size))
    tv/=2
    a=Q(1,2)
    beta=min(Q(1),r*k*a**(d-r*k)*(a**(r-1)+(d-1)*(r-1)))
    assert tv<=beta
    # Verify the formula against actual enumeration at small n.
    if n<=10:
        fam=[t for t in range(1<<n) if t.bit_count()!=1]
        assert tv==tv_trace(fam,(1<<j_size)-1)
    return {'n':n,'k':k,'actual_trace_tv':str(tv),'beta':str(beta),
            'beta_below_one':beta<1}


def main():
    out={'small_graphs':all_small_graphs()}
    ex=[]
    for name,n,r,d,edges in [
        ('Fano plane',7,3,3,fano()),
        ('Affine plane of order 3',9,3,4,affine_three(3)),
        ('Complete graph K8',8,2,7,
         [(1<<i)|(1<<j) for i,j in combinations(range(8),2)])]:
        assert all(e.bit_count()==r for e in edges)
        assert all(sum(bool(e&(1<<i)) for e in edges)==d for i in range(n))
        assert all((a&b).bit_count()<=1 for a,b in combinations(edges,2))
        checks=verify_case(edges)
        checks.update(variance_check(edges,n,r,d));checks['name']=name
        ex.append(checks)
    out['regular_examples']=ex
    out['complete_graph_nontrivial_bounds']=[complete_graph_closed_form(n,k)
        for n in (10,12,16,20,40,80) for k in (1,2,3) if 2*k<n]
    out['status']='all exact checks passed'
    dest=Path(__file__).resolve().parents[1]/'data'/'local_check_results.json'
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
