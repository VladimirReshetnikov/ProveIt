#!/usr/bin/env python3
"""Exact Walsh identities underlying the proposed Gaussian limit.

This program checks finite algebraic identities, not a finite numerical
claim that a distribution is Gaussian. Every assertion is integer or
Fraction arithmetic. The independent general limit proof is in the paper.
"""
from fractions import Fraction as Q
from itertools import combinations
from math import comb
from pathlib import Path
import json


def walsh(mask,t):
    # epsilon_i=+1 on selected generator vertices T, -1 elsewhere.
    return -1 if (mask&~t).bit_count()%2 else 1


def verify(name,m,r,edges,regular_d=None):
    n=len(edges);count=1<<m;scale=1<<r
    assert len(set(edges))==n
    assert all(e.bit_count()==r for e in edges)
    assert all((e&f).bit_count()<=1 for e,f in combinations(edges,2))
    degrees=[sum(bool(e&(1<<i)) for e in edges) for i in range(m)]
    if regular_d is not None:assert degrees==[regular_d]*m
    high=[]
    for e in edges:
        s=e
        while s:
            if s.bit_count()>=2:high.append(s)
            s=(s-1)&e
    assert len(set(high))==len(high)
    assert len(high)==n*(scale-r-1)
    sums={'linear':0,'remainder':0,'linear_square':0,
          'remainder_square':0,'cross':0,'centered_scaled':0,
          'centered_scaled_square':0}
    conditioned=[]
    for t in range(count):
        linear=sum(d*(1 if t&(1<<i) else -1) for i,d in enumerate(degrees))
        rem=sum(walsh(s,t) for s in high)
        present=n-sum(t&e==e for e in edges)
        centered=scale*present-n*(scale-1)
        # W-np=-q*(sum_i d_i epsilon_i + R), q=2^-r.
        assert centered==-linear-rem
        sums['linear']+=linear;sums['remainder']+=rem
        sums['linear_square']+=linear*linear
        sums['remainder_square']+=rem*rem;sums['cross']+=linear*rem
        sums['centered_scaled']+=centered
        sums['centered_scaled_square']+=centered*centered
        covered=0
        for e in edges:
            if t&e==e:covered|=e
        if covered==t:conditioned.append(centered)
    assert sums['linear']==sums['remainder']==sums['centered_scaled']==0
    assert sums['cross']==0
    linear_variance=sum(d*d for d in degrees)
    remainder_variance=n*(scale-r-1)
    assert sums['linear_square']==count*linear_variance
    assert sums['remainder_square']==count*remainder_variance
    assert sums['centered_scaled_square']==count*(linear_variance+remainder_variance)
    result={'name':name,'generator_vertices':m,'ground_elements':n,'r':r,
            'patterns_checked':count,'walsh_terms_degree_at_least_two':len(high),
            'linear_variance':linear_variance,
            'remainder_variance':remainder_variance,
            'linear_remainder_covariance':0,
            'uniform_distinct_family_size':len(conditioned)}
    if regular_d is not None:
        d=regular_d
        assert n*r==m*d
        assert linear_variance==d*d*m
        ratio=Q(remainder_variance,d*d*m)
        assert ratio==Q(scale-r-1,r*d)
        p=1-Q(1,scale);q=Q(1,scale)
        assert q*q*(linear_variance+remainder_variance)==n*(p*q+r*(d-1)*q*q)
        # Z=(W-np)/(q*d*sqrt(m)); only its squared quantities are rational.
        result['d']=d
        result['ideal_normalized_remainder_variance']=str(ratio)
        result['ideal_normalized_second_moment']=str(1+ratio)
        mean_c=Q(sum(conditioned),len(conditioned))
        second_c=Q(sum(c*c for c in conditioned),len(conditioned))
        result['actual_normalized_second_moment']=str(second_c/(d*d*m))
        result['actual_normalized_variance']=str((second_c-mean_c*mean_c)/(d*d*m))
    return result


def small_graphs():
    families=0;patterns=0
    for m in range(1,6):
        possible=[(1<<i)|(1<<j) for i,j in combinations(range(m),2)]
        for code in range(1<<len(possible)):
            edges=[e for i,e in enumerate(possible) if code>>i&1]
            row=verify('small graph',m,2,edges)
            families+=1;patterns+=row['patterns_checked']
    return {'families':families,'patterns_checked':patterns,
            'all_Walsh_identities':'passed'}


def main():
    fano=sorted({(1<<(u-1))|(1<<(v-1))|(1<<((u^v)-1))
                  for u in range(1,8) for v in range(u+1,8)})
    affine=[]
    for a in range(3):
        for b in range(3):affine.append(sum(1<<(3*x+(a*x+b)%3) for x in range(3)))
    for c in range(3):affine.append(sum(1<<(3*c+y) for y in range(3)))
    out={'small_graphs':small_graphs(),'regular_examples':[
        verify('Fano plane',7,3,fano,3),
        verify('Affine plane of order 3',9,3,affine,4),
        verify('Complete graph K12',12,2,
               [(1<<i)|(1<<j) for i,j in combinations(range(12),2)],11),
        verify('Complete bipartite graph K7,7',14,2,
               [(1<<i)|(1<<(7+j)) for i in range(7) for j in range(7)],7)],
        'status':'all exact finite identities passed; no numerical CLT assertion made'}
    dest=Path(__file__).resolve().parents[1]/'data'/'gaussian_check_results.json'
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
