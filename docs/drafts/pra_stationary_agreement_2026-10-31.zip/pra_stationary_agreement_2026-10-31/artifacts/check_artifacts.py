#!/usr/bin/env python3
"""Check syntax, formula-template counts, and finite comparator diagnostics.

This is an executable audit, not a proof of the theory-equivalence theorem.
The mathematical proof is in the paper; the constructive kernel is in Lean.
Only Python's standard library is required.
"""

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import json


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple = ()

    def size(self):
        return 1 + sum(child.size() for child in self.children)

    def text(self):
        if not self.children:
            return self.label
        return self.label + "(" + ",".join(c.text() for c in self.children) + ")"


def node(label, *children):
    return Node(label, children)


def eq(a, b):
    return node("=", a, b)


def implication(a, b):
    return node("implies", a, b)


def neq(a, b):
    return implication(eq(a, b), node("false"))


def forall(variables, body):
    for variable in reversed(variables):
        body = node("forall " + variable.label, body)
    return body


zero, n, a, x, y = map(node, ("0", "n", "a", "x", "y"))
succ = lambda t: node("S", t)
one = succ(zero)


def definitions(params, substitution=False, binary=False):
    if binary:
        base = forall((a,), eq(node("I", zero, a), a))
        step = forall((n, a), eq(node("I", succ(n), a),
                      node("h", n, node("I", n, a))))
        return base.size() + step.size()
    base = forall(params, eq(node("F", zero, *params), node("g", *params)))
    transformed = (node("k", params[0]), *params[1:]) if substitution else params
    step = forall((n, *params), eq(node("F", succ(n), *params),
                  node("h", n, node("F", n, *transformed), *params)))
    return base.size() + step.size()


def stationarity(f):
    return forall((n,), eq(f(succ(n)), f(n)))


def agreement(params):
    f = lambda t: node("f", t, *params)
    return forall(params, implication(stationarity(f),
                  forall((n,), neq(node("E", f(n), f(zero)), zero))))


def stationary_separation(params):
    f = lambda t: node("f", t, *params)
    return forall(params, implication(stationarity(f),
                  forall((n,), neq(succ(f(n)), f(zero)))))


def positive_constancy(params):
    f = lambda t: node("f", t, *params)
    return forall(params, implication(
        forall((n,), eq(f(succ(succ(n))), f(succ(n)))),
        forall((n,), node("or", eq(n, zero), eq(f(n), f(one))))))


def stationary_zero(params):
    f = lambda t: node("f", t, *params)
    return forall(params, implication(stationarity(f), node("or",
        forall((n,), eq(f(n), zero)), eq(node("Z", f(zero)), zero))))


def classical_comparison(params, primitive_iff):
    f = lambda t: node("f", t, *params)
    left = eq(node("E", f(n), params[0]), zero)
    right = neq(f(zero), params[0])
    body = node("iff", left, right) if primitive_iff else node(
        "and", implication(left, right), implication(right, left))
    return forall(params, implication(stationarity(f), forall((n,), body)))


def metrics():
    off = forall((x, y), node("or", eq(node("E", x, y), zero), eq(x, y)))
    inv = forall((x, y), eq(node("R", node("R", x, y), y), x))
    sep = neq(zero, one)
    ordinary = definitions((a,))
    binary = definitions((a,), binary=True)
    substituted = definitions((a,), substitution=True)
    sa = agreement((a,)).size()
    pc = positive_constancy((a,)).size()
    sz = stationary_zero((a,)).size()
    ss = stationary_separation((a,)).size()
    rows = []
    for name, grammar, computation, arithmetic, fixed in [
        ("anchored_involution", "ordinary PR", ordinary, pc, sep.size()+inv.size()),
        ("bounded_reflection", "ordinary PR", ordinary, pc, sep.size()+inv.size()),
        ("transposition_constancy", "ordinary PR", ordinary, pc, sep.size()+inv.size()),
        ("stationary_zero", "ordinary PR", ordinary, sz, sep.size()+inv.size()),
        ("involutive_difference", "initialized binary", binary, pc,
         sep.size()+inv.size()),
        ("substitution_descent", "parameter substitution", substituted, ss, off.size()),
        ("new_stationary_agreement", "ordinary PR", ordinary, sa, off.size()),
    ]:
        rows.append(dict(name=name, grammar=grammar, computation=computation,
                         arithmetic_schema=arithmetic, fixed=fixed,
                         total=computation+arithmetic+fixed))
    assert [r["total"] for r in rows] == [61, 61, 61, 59, 59, 54, 54]
    uniform = []
    for count in range(9):
        params = tuple(node("a"+str(i)) for i in range(count))
        d = definitions(params)
        s = agreement(params).size()
        assert d == 13 + 7*count
        assert s == 18 + 5*count
        assert d + s + off.size() == 42 + 12*count
        uniform.append(dict(parameters=count, computation=d, agreement=s,
                            fixed=off.size(), total=d+s+off.size()))
    k_iff = classical_comparison((a,), True)
    k_expanded = classical_comparison((a,), False)
    assert k_iff.size() == 27 and k_expanded.size() == 43
    return {
        "convention": "One node per variable, constant, application, equality, "
                      "connective, falsity and individual quantifier. Negation is "
                      "implication to falsity; 1 is S(0).",
        "scope": "Counts are displayed templates, including their universal "
                 "closures, not complete presentation bit lengths. Arbitrary "
                 "substituted bodies, symbol encodings and grammar implementation "
                 "are not counted.",
        "current_drafts_and_new_basis": rows,
        "uniform_parameter_counts": uniform,
        "new_formulas": {"O": off.text(), "SA": agreement((a,)).text()},
        "classical_only_variant": {
            "primitive_biconditional": {"schema": k_iff.size(), "total": 47},
            "expanded_biconditional": {"schema": k_expanded.size(), "total": 63},
            "warning": "47 and 54 use different logical-alphabet conventions; "
                       "the fixed-arrow-alphabet comparison is 63 versus 54."
        }
    }


# The base environment consists of the frozen parameters. The update
# environment consists of counter, previous value, then frozen parameters.
def var(i):
    return node("v" + str(i))


PROGRAMS = [
    ("p", 0, zero, var(0)),
    ("M", 1, var(0), node("p", var(1))),
    ("Z", 0, one, zero),
    ("H", 0, zero, node("Z", var(0))),
    ("E", 1, node("Z", var(0)), node("H", node("M", var(0), var(2)))),
]
DECLARATIONS = {}


def check_term(t, variables, available):
    if t.label == "0":
        assert not t.children
    elif t.label.startswith("v"):
        assert not t.children and 0 <= int(t.label[1:]) < variables
    elif t.label == "S":
        assert len(t.children) == 1
    else:
        assert t.label in available, ("forward or unknown dependency", t.label)
        assert len(t.children) == available[t.label][0] + 1
    for child in t.children:
        check_term(child, variables, available)


def value(t, environment):
    if t.label == "0":
        return 0
    if t.label.startswith("v"):
        return environment[int(t.label[1:])]
    if t.label == "S":
        return value(t.children[0], environment) + 1
    return evaluate(t.label, tuple(value(c, environment) for c in t.children))


@lru_cache(maxsize=None)
def evaluate(name, args):
    parameter_count, base, step = DECLARATIONS[name]
    assert len(args) == parameter_count + 1 and all(t >= 0 for t in args)
    counter, *params = args
    result = value(base, tuple(params))
    for index in range(counter):
        result = value(step, (index, result, *params))
    return result


def program_checks():
    ledger = []
    for name, params, base, step in PROGRAMS:
        check_term(base, params, DECLARATIONS)
        check_term(step, params + 2, DECLARATIONS)
        DECLARATIONS[name] = (params, base, step)
        ledger.append(dict(name=name, arity=params+1,
                           base=base.text(), update=step.text(),
                           base_nodes=base.size(), update_nodes=step.size(),
                           total=base.size()+step.size()))
    assert [d["total"] for d in ledger] == [2, 3, 3, 3, 6]
    bound = 100
    for i in range(bound+1):
        assert evaluate("p", (i,)) == max(0, i-1)
        assert evaluate("Z", (i,)) == int(i == 0)
        assert evaluate("H", (i,)) == int(i == 1)
        for j in range(bound+1):
            assert evaluate("M", (i, j)) == max(0, j-i)
            assert evaluate("E", (i, j)) == int(i == j)
    # Evaluate exactly the displayed descriptions, not a replacement comparator.
    return {"syntax": "PASS: finite well-founded ordinary PR descriptions",
            "selected_descriptions": ledger, "body_node_total": 17,
            "numerical_diagnostics": {"status": "PASS", "grid": [0, bound],
                                      "ordered_pairs": (bound+1)**2},
            "scope": "Finite diagnostics do not prove a schema, internal PRA "
                     "correctness, consistency, or bi-interpretability."}


def main():
    result = {"status": "PASS", "metrics": metrics(), "program": program_checks()}
    destination = Path(__file__).with_name("check_results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print("PASS: all six comparison counts, uniform counts for 0..8 parameters,")
    print("      ordinary PR syntax, 17 descriptor nodes, and 10,201 comparator pairs.")
    print("Classical single schema: 47 nodes with primitive iff; 63 with expanded iff.")


if __name__ == "__main__":
    main()
