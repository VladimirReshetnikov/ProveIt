#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p .build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build \
  pra_stationary_agreement.tex > .build/first_pass.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build \
  pra_stationary_agreement.tex > .build/second_pass.log
cp .build/pra_stationary_agreement.pdf pra_stationary_agreement.pdf
echo "Built pra_stationary_agreement.pdf"
