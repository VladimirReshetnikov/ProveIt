import Init

/-!
Local certificate for the optional classical one-schema presentation.

`admissible` restricts the schema to evaluations of admitted finite terms,
after fixing their finite tuples of parameters. An independent compared
element `a` is permitted as a dummy distinguished parameter in the source
schema. No schema is assumed for all set-theoretic functions.

This file checks the logical bridge from the single biconditional schema
to off-diagonal exhaustiveness, diagonal nonvanishing, and stationary
agreement. Reflection and off-diagonal exhaustiveness use classical logic.
It does not formalize PR syntax, first-order derivability, or the converse
arithmetic verification of the designated comparator program.
-/

namespace ClassicalBridge

structure Context (α : Type) where
  zero : α
  succ : α → α
  eqbit : α → α → α
  admissible : (α → α) → Prop
  adm_const : ∀ x, admissible (fun _ => x)
  eqbit_zero_zero : eqbit zero zero = succ zero

namespace Context

variable {α : Type} (B : Context α)

def Stationary (f : α → α) : Prop :=
  ∀ n, f (B.succ n) = f n

def KScheme : Prop :=
  ∀ f, B.admissible f → ∀ a, B.Stationary f →
    ∀ n, B.eqbit (f n) a = B.zero ↔ f B.zero ≠ a

def OffDiagonal : Prop :=
  ∀ x y, B.eqbit x y = B.zero ∨ x = y

def Diagonal : Prop :=
  ∀ x, B.eqbit x x ≠ B.zero

def Agreement : Prop :=
  ∀ f, B.admissible f → B.Stationary f →
    ∀ n, B.eqbit (f n) (f B.zero) ≠ B.zero

def Constancy : Prop :=
  ∀ f, B.admissible f → B.Stationary f → ∀ n, f n = f B.zero

theorem constant_instance (hK : B.KScheme) (x a : α) :
    B.eqbit x a = B.zero ↔ x ≠ a := by
  exact hK (fun _ => x) (B.adm_const x) a (fun _ => rfl) B.zero

theorem diagonal_of_K (hK : B.KScheme) : B.Diagonal := by
  intro x h
  exact (B.constant_instance hK x x).mp h rfl

theorem separation_of_K (hK : B.KScheme) : B.succ B.zero ≠ B.zero := by
  have h := B.diagonal_of_K hK B.zero
  rw [B.eqbit_zero_zero] at h
  exact h

theorem reflection_of_K (hK : B.KScheme) (x a : α)
    (h : B.eqbit x a ≠ B.zero) : x = a := by
  apply Classical.byContradiction
  intro hne
  exact h ((B.constant_instance hK x a).mpr hne)

theorem offDiagonal_of_K (hK : B.KScheme) : B.OffDiagonal := by
  intro x a
  rcases Classical.em (x = a) with he | hne
  · exact Or.inr he
  · exact Or.inl ((B.constant_instance hK x a).mpr hne)

theorem equality_iff_nonzero_of_K (hK : B.KScheme) (x a : α) :
    x = a ↔ B.eqbit x a ≠ B.zero := by
  constructor
  · intro he
    subst x
    exact B.diagonal_of_K hK a
  · exact B.reflection_of_K hK x a

theorem agreement_of_K (hK : B.KScheme) : B.Agreement := by
  intro f hf hs n hzero
  exact (hK f hf (f B.zero) hs n).mp hzero rfl

theorem constancy_of_K (hK : B.KScheme) : B.Constancy := by
  intro f hf hs n
  exact B.reflection_of_K hK (f n) (f B.zero)
    (B.agreement_of_K hK f hf hs n)

/- The converse logical bridge is constructive once the common basis has
   supplied exact off-diagonal testing, diagonal nonvanishing, and constancy. -/
theorem K_of_offDiagonal_diagonal_constancy
    (ho : B.OffDiagonal) (hd : B.Diagonal) (hc : B.Constancy) :
    B.KScheme := by
  intro f hf a hs n
  have hn : f n = f B.zero := hc f hf hs n
  constructor
  · intro hz he
    have hna : f n = a := hn.trans he
    have hdiag : B.eqbit (f n) a ≠ B.zero := by
      rw [hna]
      exact hd a
    exact hdiag hz
  · intro hne
    rcases ho (f n) a with hz | he
    · exact hz
    · exact False.elim (hne (hn.symm.trans he))

end Context

end ClassicalBridge

#print axioms ClassicalBridge.Context.diagonal_of_K
#print axioms ClassicalBridge.Context.separation_of_K
#print axioms ClassicalBridge.Context.reflection_of_K
#print axioms ClassicalBridge.Context.offDiagonal_of_K
#print axioms ClassicalBridge.Context.agreement_of_K
#print axioms ClassicalBridge.Context.constancy_of_K
#print axioms ClassicalBridge.Context.K_of_offDiagonal_diagonal_constancy
