LEAN CERTIFICATE: STATIONARY AGREEMENT
=====================================

File: StationaryAgreement.lean
Lean version: 4.19.0 (release)
Dependency: Init only; no Mathlib, imported local files, or network access.

CHECKED CONSTRUCTIVE RESULT
--------------------------
For an arbitrary carrier alpha, the Basis structure assumes the elementary
computation equations, the fixed off-diagonal sentence O, stationary
agreement SE for admissible programs, and the specific term-formation
closures used by the proof. Lean checks:

  * Constant SE instances give E(x,x) != 0.
  * The equations E(0,x)=Z(x) and Z(0)=S(0) give 1 != 0.
  * Successors are nonzero and injective.
  * O gives computed zero coverage, zero decision, and native equality
    decision; E(x,y) != 0 is equivalent to native x=y.
  * A normalized selector has the correct global behavior.
  * SE and O give ordinary constancy under its fixed stationarity premise.
  * One admitted primitive-recursive latch gives induction for any admitted
    zero equation.
  * An actual inductive Formula datatype, with admitted programs as its
    atomic terms, has a structurally defined error-program compiler.
  * The compiler is correct for equality, falsity, conjunction, disjunction,
    and implication, and transfers zero induction to all these formulas.

The final endpoint is StationaryAgreement.Basis.Formula.induction.
All twelve printed axiom-dependency audits are empty. There is no sorry,
classical tactic, choice axiom, or propositional-extensionality dependency.
The mathematical assumptions are EXPLICIT STRUCTURE FIELDS; empty dependency
audits do not mean that the arithmetic axioms were proved without assumptions.

ADMISSIBILITY IS AN EXPLICIT RESTRICTION
--------------------------------------
The field admissible : (alpha -> alpha) -> Prop is intended to hold exactly
for evaluations of finite admitted terms in the counter variable, allowing
an arbitrary finite tuple of fixed numerical parameters. Such parameters
may vary from one admitted program to another; finite tuples can be joined.

The stationary schema has the form

  agreement : forall f, admissible f -> stationarity f -> ...

It is NOT assumed for all set-theoretic functions. The constant, shift,
composition, and latch fields express only the syntactic constructions
needed in the proof. They are supplied by the ordinary PR description
grammar and computation axioms in the paper. The latch field is existential
and is used by elimination, with no choice operation.

SCOPE BOUNDARY
--------------
The certificate does not define the entire first-order term/description
language, its proof calculus, or the syntactic interpretation translations.
The Formula datatype has admitted semantic term evaluations at its atoms.
The correspondence between this admissibility interface and the paper's
ordinary finite PR syntax is a written argument. Ordinary PRA's converse
proof for the selected E program, full first-order bi-interpretability,
and proof/consistency translations also remain written proofs in the paper.

REPRODUCE
---------
From the package root, with Lean 4.19.0 on PATH:

  lean formal/StationaryAgreement.lean

The included lean_check.log records a successful compilation and all twelve
empty axiom-dependency reports. The log is a convenience; the source is the
certificate to check.
