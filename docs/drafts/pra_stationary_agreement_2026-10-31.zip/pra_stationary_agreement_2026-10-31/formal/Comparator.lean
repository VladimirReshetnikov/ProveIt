import Init

/-!
Certificate for the five explicitly specified comparator descriptions on Nat.

The definitions below are the actual 17-node program in the manuscript.
The guarded reconstruction proof follows the manuscript's internal PRA proof.
This file checks Nat theorems; it does not formalize first-order PRA syntax,
restricted induction, interpretation translations, or their round trips.
-/

namespace StationaryAgreement.Comparator

def p : Nat → Nat
  | 0 => 0
  | Nat.succ n => n

def M : Nat → Nat → Nat
  | 0, a => a
  | Nat.succ n, a => p (M n a)

def Z : Nat → Nat
  | 0 => 1
  | Nat.succ _ => 0

def H : Nat → Nat
  | 0 => 0
  | Nat.succ n => Z n

def E : Nat → Nat → Nat
  | 0, a => Z a
  | Nat.succ n, a => H (M n a)

/- Auxiliary addition is used only in the proof, not in E's description. -/
def A : Nat → Nat → Nat
  | 0, b => b
  | Nat.succ n, b => Nat.succ (A n b)

theorem add_successor_argument (n b : Nat) :
    A n (Nat.succ b) = Nat.succ (A n b) := by
  induction n with
  | zero => rfl
  | succ n ih => exact congrArg Nat.succ ih

theorem add_one (n : Nat) : A n 1 = Nat.succ n := by
  induction n with
  | zero => rfl
  | succ n ih => exact congrArg Nat.succ ih

theorem subtraction_shift (n a : Nat) :
    M (Nat.succ n) (Nat.succ a) = M n a := by
  induction n with
  | zero => rfl
  | succ n ih => exact congrArg p ih

theorem subtraction_diagonal (n : Nat) : M n (Nat.succ n) = 1 := by
  induction n with
  | zero => rfl
  | succ n ih =>
    exact (subtraction_shift n (Nat.succ n)).trans ih

theorem guarded_reconstruction (n a : Nat) :
    M n a ≠ 0 → A n (M n a) = a := by
  induction n with
  | zero => intro _; rfl
  | succ n ih =>
    intro hq
    have hr : M n a ≠ 0 := by
      intro hz
      apply hq
      change p (M n a) = 0
      rw [hz]
      rfl
    have hrs : M n a = Nat.succ (p (M n a)) := by
      cases hm : M n a with
      | zero => exact False.elim (hr hm)
      | succ k => rfl
    calc
      A (Nat.succ n) (M (Nat.succ n) a)
          = Nat.succ (A n (p (M n a))) := rfl
      _ = A n (Nat.succ (p (M n a))) :=
          (add_successor_argument n (p (M n a))).symm
      _ = A n (M n a) := congrArg (A n) hrs.symm
      _ = a := ih hr

theorem subtraction_eq_one (n a : Nat) :
    M n a = 1 ↔ a = Nat.succ n := by
  constructor
  · intro h
    have hn : M n a ≠ 0 := by
      rw [h]
      exact Nat.one_ne_zero
    have hr := guarded_reconstruction n a hn
    rw [h, add_one] at hr
    exact hr.symm
  · intro h
    rw [h]
    exact subtraction_diagonal n

theorem zero_test_range (a : Nat) : Z a = 0 ∨ Z a = 1 := by
  cases a with
  | zero => exact Or.inr rfl
  | succ n => exact Or.inl rfl

theorem zero_test_eq_one (a : Nat) : Z a = 1 ↔ a = 0 := by
  cases a with
  | zero => exact Iff.intro (fun _ => rfl) (fun _ => rfl)
  | succ n =>
    constructor
    · intro h
      exact False.elim (Nat.zero_ne_one h)
    · intro h
      exact False.elim (Nat.noConfusion h)

theorem one_test_range (a : Nat) : H a = 0 ∨ H a = 1 := by
  cases a with
  | zero => exact Or.inl rfl
  | succ n => exact zero_test_range n

theorem one_test_eq_one (a : Nat) : H a = 1 ↔ a = 1 := by
  cases a with
  | zero =>
    constructor
    · intro h
      exact False.elim (Nat.zero_ne_one h)
    · intro h
      exact False.elim (Nat.zero_ne_one h)
  | succ n =>
    constructor
    · intro h
      have hn := (zero_test_eq_one n).mp h
      exact congrArg Nat.succ hn
    · intro h
      have hn : n = 0 := Nat.succ.inj h
      exact (zero_test_eq_one n).mpr hn

theorem equality_range (x y : Nat) : E x y = 0 ∨ E x y = 1 := by
  cases x with
  | zero => exact zero_test_range y
  | succ n => exact one_test_range (M n y)

theorem equality_eq_one (x y : Nat) : E x y = 1 ↔ y = x := by
  cases x with
  | zero => exact zero_test_eq_one y
  | succ n =>
    exact (one_test_eq_one (M n y)).trans (subtraction_eq_one n y)

theorem equality_diagonal (x : Nat) : E x x = 1 := by
  exact (equality_eq_one x x).mpr rfl

theorem off_diagonal (x y : Nat) : E x y = 0 ∨ x = y := by
  rcases equality_range x y with hz | ho
  · exact Or.inl hz
  · exact Or.inr ((equality_eq_one x y).mp ho).symm

theorem equality_nonzero (x y : Nat) : E x y ≠ 0 ↔ x = y := by
  constructor
  · intro hn
    rcases off_diagonal x y with hz | he
    · exact False.elim (hn hz)
    · exact he
  · intro he
    subst y
    rw [equality_diagonal]
    exact Nat.one_ne_zero

theorem equality_zero (x y : Nat) : E x y = 0 ↔ x ≠ y := by
  constructor
  · intro hz he
    exact (equality_nonzero x y).mpr he hz
  · intro hn
    rcases off_diagonal x y with hz | he
    · exact hz
    · exact False.elim (hn he)

#print axioms guarded_reconstruction
#print axioms subtraction_eq_one
#print axioms equality_range
#print axioms off_diagonal
#print axioms equality_diagonal
#print axioms equality_nonzero
#print axioms equality_zero

end StationaryAgreement.Comparator
