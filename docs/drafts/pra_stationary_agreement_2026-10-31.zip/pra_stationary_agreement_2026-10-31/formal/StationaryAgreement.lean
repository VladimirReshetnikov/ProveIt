import Init

/-!
Constructive local certificate for stationary agreement.

`admissible` designates evaluations of admitted finite PR terms, with any fixed
finite tuple of parameters. The stationary schema is assumed ONLY for this
predicate. It is not assumed for every set-theoretic function. The closure
hypotheses below isolate the term constructions used by the written proof.

This file does not formalize first-order derivability, PR description syntax,
or the converse interpretation in PRA. See README.txt for its exact scope.
-/

namespace StationaryAgreement

structure Basis (α : Type) where
  zero : α
  succ : α → α
  pred : α → α
  ztest : α → α
  eqbit : α → α → α
  choose : α → α → α → α
  admissible : (α → α) → Prop
  pred_succ : ∀ x, pred (succ x) = x
  ztest_zero : ztest zero = succ zero
  ztest_succ : ∀ x, ztest (succ x) = zero
  eqbit_zero : ∀ x, eqbit zero x = ztest x
  choose_zero : ∀ u v, choose zero u v = u
  choose_succ : ∀ x u v, choose (succ x) u v = v
  offdiag : ∀ x y, eqbit x y = zero ∨ x = y
  adm_const : ∀ a, admissible (fun _ => a)
  adm_shift : ∀ f, admissible f → admissible (fun n => f (succ n))
  adm_ztest : ∀ f, admissible f → admissible (fun n => ztest (f n))
  adm_eqbit : ∀ f g, admissible f → admissible g →
    admissible (fun n => eqbit (f n) (g n))
  adm_choose : ∀ f g h, admissible f → admissible g → admissible h →
    admissible (fun n => choose (f n) (g n) (h n))
  adm_latch : ∀ f, admissible f → ∃ r, admissible r ∧
    r zero = succ zero ∧
    ∀ n, r (succ n) = choose (ztest (f n)) zero (r n)
  agreement : ∀ f, admissible f → (∀ n, f (succ n) = f n) →
    ∀ n, eqbit (f n) (f zero) ≠ zero

namespace Basis

variable {α : Type} (B : Basis α)

def one : α := B.succ B.zero

theorem diagonal (x : α) : B.eqbit x x ≠ B.zero := by
  exact B.agreement (fun _ => x) (B.adm_const x) (fun _ => rfl) B.zero

theorem separation : B.one ≠ B.zero := by
  have h := B.diagonal B.zero
  rw [B.eqbit_zero, B.ztest_zero] at h
  exact h

theorem successor_nonzero (x : α) : B.succ x ≠ B.zero := by
  intro h
  have hz := congrArg B.ztest h
  rw [B.ztest_succ, B.ztest_zero] at hz
  exact B.separation hz.symm

theorem successor_injective {x y : α} (h : B.succ x = B.succ y) : x = y := by
  have hp := congrArg B.pred h
  simpa only [B.pred_succ] using hp

theorem zero_cover (x : α) : x = B.zero ∨ B.ztest x = B.zero := by
  rcases B.offdiag B.zero x with h | h
  · exact Or.inr ((B.eqbit_zero x).symm.trans h)
  · exact Or.inl h.symm

theorem zero_decision (x : α) : x = B.zero ∨ x ≠ B.zero := by
  rcases B.zero_cover x with h | h
  · exact Or.inl h
  · right
    intro hx
    subst x
    rw [B.ztest_zero] at h
    exact B.separation h

theorem ztest_of_nonzero {x : α} (h : x ≠ B.zero) : B.ztest x = B.zero := by
  rcases B.zero_cover x with hx | hz
  · exact False.elim (h hx)
  · exact hz

theorem ztest_zero_iff (x : α) : B.ztest x = B.zero ↔ x ≠ B.zero := by
  constructor
  · intro h hx
    subst x
    rw [B.ztest_zero] at h
    exact B.separation h
  · exact B.ztest_of_nonzero

theorem ztest_range (x : α) : B.ztest x = B.zero ∨ B.ztest x = B.one := by
  rcases B.zero_cover x with hx | hz
  · subst x
    exact Or.inr B.ztest_zero
  · exact Or.inl hz

theorem equality_iff_nonzero (x y : α) : x = y ↔ B.eqbit x y ≠ B.zero := by
  constructor
  · intro h
    subst x
    exact B.diagonal y
  · intro h
    rcases B.offdiag x y with h0 | he
    · exact False.elim (h h0)
    · exact he

include B in
theorem equality_decision (x y : α) : x = y ∨ x ≠ y := by
  rcases B.offdiag x y with h0 | he
  · right
    intro he
    exact (B.equality_iff_nonzero x y).mp he h0
  · exact Or.inl he

theorem atom_error (x y : α) : x = y ↔ B.ztest (B.eqbit x y) = B.zero := by
  exact (B.equality_iff_nonzero x y).trans (B.ztest_zero_iff _).symm

def select (a u v : α) : α := B.choose (B.ztest a) v u

theorem select_zero (u v : α) : B.select B.zero u v = u := by
  exact (congrArg (fun z => B.choose z v u) B.ztest_zero).trans
    (B.choose_succ B.zero v u)

theorem select_of_nonzero {a : α} (h : a ≠ B.zero) (u v : α) :
    B.select a u v = v := by
  exact (congrArg (fun z => B.choose z v u) (B.ztest_of_nonzero h)).trans
    (B.choose_zero v u)

theorem select_same (a u : α) : B.select a u u = u := by
  rcases B.zero_decision a with h | h
  · subst a
    exact B.select_zero u u
  · exact B.select_of_nonzero h u u

theorem constancy (f : α → α) (hf : B.admissible f)
    (hs : ∀ n, f (B.succ n) = f n) : ∀ n, f n = f B.zero := by
  intro n
  exact (B.equality_iff_nonzero _ _).mpr (B.agreement f hf hs n)

theorem zero_induction (f : α → α) (hf : B.admissible f)
    (h0 : f B.zero = B.zero)
    (hstep : ∀ n, f n = B.zero → f (B.succ n) = B.zero) :
    ∀ n, f n = B.zero := by
  obtain ⟨r, hr, hr0, hrs⟩ := B.adm_latch f hf
  have hrs' : ∀ n, r (B.succ n) = B.select (f n) (r n) B.zero := hrs
  have hbase : r (B.succ B.zero) = B.one := by
    rw [hrs', h0, B.select_zero]
    exact hr0
  have hstationary : ∀ n, r (B.succ (B.succ n)) = r (B.succ n) := by
    intro n
    rcases B.zero_decision (f n) with he | he
    · rw [hrs' (B.succ n), hstep n he, B.select_zero]
    · have hz : r (B.succ n) = B.zero := by
        rw [hrs' n, B.select_of_nonzero he]
      rw [hrs' (B.succ n), hz, B.select_same]
  have hc := B.constancy (fun n => r (B.succ n)) (B.adm_shift r hr) hstationary
  intro n
  rcases B.zero_decision (f n) with he | he
  · exact he
  · have hz : r (B.succ n) = B.zero := by
      rw [hrs' n, B.select_of_nonzero he]
    have hvalue : r (B.succ n) = B.one := (hc n).trans hbase
    exact False.elim (B.separation (hvalue.symm.trans hz))

abbrev Program := {f : α → α // B.admissible f}

namespace Program

def constant (a : α) : B.Program := ⟨fun _ => a, B.adm_const a⟩

def atomicError (f g : B.Program) : B.Program :=
  ⟨fun n => B.ztest (B.eqbit (f.val n) (g.val n)),
    B.adm_ztest _ (B.adm_eqbit _ _ f.property g.property)⟩

def selectProgram (f g h : B.Program) : B.Program :=
  ⟨fun n => B.select (f.val n) (g.val n) (h.val n),
    B.adm_choose _ _ _ (B.adm_ztest _ f.property) h.property g.property⟩

end Program

inductive Formula where
  | atom : B.Program → B.Program → Formula
  | falsum : Formula
  | conj : Formula → Formula → Formula
  | disj : Formula → Formula → Formula
  | impl : Formula → Formula → Formula

namespace Formula

variable {B : Basis α}

def holds : B.Formula → α → Prop
  | .atom f g, n => f.val n = g.val n
  | .falsum, _ => False
  | .conj f g, n => holds f n ∧ holds g n
  | .disj f g, n => holds f n ∨ holds g n
  | .impl f g, n => holds f n → holds g n

def error : B.Formula → B.Program
  | .atom f g => Program.atomicError B f g
  | .falsum => Program.constant B B.one
  | .conj f g => Program.selectProgram B (error f) (error g)
      (Program.constant B B.one)
  | .disj f g => Program.selectProgram B (error f) (Program.constant B B.zero)
      (error g)
  | .impl f g => Program.selectProgram B (error f) (error g)
      (Program.constant B B.zero)

theorem error_spec (A : B.Formula) (n : α) :
    A.holds n ↔ A.error.val n = B.zero := by
  induction A with
  | atom f g => exact B.atom_error (f.val n) (g.val n)
  | falsum =>
      change False ↔ B.one = B.zero
      exact ⟨False.elim, B.separation⟩
  | conj f g ihf ihg =>
      change (f.holds n ∧ g.holds n) ↔
        B.select (f.error.val n) (g.error.val n) B.one = B.zero
      rcases B.zero_decision (f.error.val n) with hz | hn
      · have ht : f.holds n := ihf.mpr hz
        rw [hz, B.select_zero]
        exact ⟨fun h => ihg.mp h.2, fun h => ⟨ht, ihg.mpr h⟩⟩
      · rw [B.select_of_nonzero hn]
        constructor
        · intro h
          exact False.elim (hn (ihf.mp h.1))
        · intro h
          exact False.elim (B.separation h)
  | disj f g ihf ihg =>
      change (f.holds n ∨ g.holds n) ↔
        B.select (f.error.val n) B.zero (g.error.val n) = B.zero
      rcases B.zero_decision (f.error.val n) with hz | hn
      · rw [hz, B.select_zero]
        exact ⟨fun _ => rfl, fun _ => Or.inl (ihf.mpr hz)⟩
      · rw [B.select_of_nonzero hn]
        constructor
        · intro h
          rcases h with h | h
          · exact False.elim (hn (ihf.mp h))
          · exact ihg.mp h
        · intro h
          exact Or.inr (ihg.mpr h)
  | impl f g ihf ihg =>
      change (f.holds n → g.holds n) ↔
        B.select (f.error.val n) (g.error.val n) B.zero = B.zero
      rcases B.zero_decision (f.error.val n) with hz | hn
      · rw [hz, B.select_zero]
        exact ⟨fun h => ihg.mp (h (ihf.mpr hz)), fun h _ => ihg.mpr h⟩
      · rw [B.select_of_nonzero hn]
        constructor
        · intro _
          rfl
        · intro _ hf
          exact False.elim (hn (ihf.mp hf))

theorem induction (A : B.Formula) (h0 : A.holds B.zero)
    (hstep : ∀ n, A.holds n → A.holds (B.succ n)) : ∀ n, A.holds n := by
  have e0 := (A.error_spec B.zero).mp h0
  have es : ∀ n, A.error.val n = B.zero → A.error.val (B.succ n) = B.zero := by
    intro n hn
    exact (A.error_spec (B.succ n)).mp (hstep n ((A.error_spec n).mpr hn))
  have allzero := B.zero_induction A.error.val A.error.property e0 es
  intro n
  exact (A.error_spec n).mpr (allzero n)

end Formula

#print axioms diagonal
#print axioms separation
#print axioms successor_nonzero
#print axioms successor_injective
#print axioms zero_cover
#print axioms zero_decision
#print axioms equality_iff_nonzero
#print axioms equality_decision
#print axioms constancy
#print axioms zero_induction
#print axioms Formula.error_spec
#print axioms Formula.induction

end Basis

end StationaryAgreement
