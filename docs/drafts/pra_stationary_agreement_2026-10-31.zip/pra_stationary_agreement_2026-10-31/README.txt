PRA FROM STATIONARY AGREEMENT
============================
Prepared for Vladimir Reshetnikov, 31 October 2026 (Pacific time).

READ FIRST
----------
pra_stationary_agreement.pdf is the complete research report.
pra_stationary_agreement.tex is its self-contained LaTeX source.
AXIOMS.txt specifies the language and both versions in plain text.

MAIN RESULT
-----------
In the ordinary effective PR-description language, retain the computation
equations D. Choose the explicit ordinary PR comparator E in AXIOMS.txt.
Add the fixed positive sentence

  O:  forall x y, E(x,y)=0 or x=y,

and, for every finite term f(n,a_vec), stationary agreement:

  SA: [forall n, f(Sn,a_vec)=f(n,a_vec)]
        -> forall n, E(f(n,a_vec),f(0,a_vec)) != 0.

All finite parameter tuples are permitted. Every instance is universally
closed and usable under fixed hypotheses. The schema ranges over finite
term syntax, not arbitrary set-theoretic functions.

The resulting theory has exactly the same common-language theorems as
ordinary first-order PRA, separately in classical and intuitionistic logic.
Both interpretations and their composites are identities. Separation,
native equality decisions, and all quantifier-free induction are derived.

Classical logic also permits the single arithmetic SC schema in AXIOMS.txt.
Its proof uses classical double-negation elimination. No intuitionistic
equivalence claim is made for SC alone.

WHAT IMPROVES
-------------
At one displayed parameter, the common basis costs 54 formula-tree nodes:
D=20, O=11, SA=23. This improves the current ordinary-PR stationary-zero
basis's 59, and ties the current substitution-descent basis's 54 while
using ordinary recursion and eliminating its parameter-substitution
compiler. The comparator's designated stored bodies cost 17 term nodes.

These are stated partial syntactic measures, not a theorem of absolute
shortestness or complete presentation bit lengths. The classical SC
variant costs 47 with primitive iff, or 63 with iff expanded into and/arrow.
The paper does not mix these alphabets to claim a numerical record.

CONTENTS
--------
  pra_stationary_agreement.tex / .pdf : full report and proofs
  AXIOMS.txt                         : exact effective specification
  build.sh                           : compile the PDF twice
  check.sh                           : Python audit and three Lean checks
  formal/StationaryAgreement.lean     : constructive forward kernel
  formal/Comparator.lean             : actual comparator on Nat
  formal/ClassicalBridge.lean         : classical SC logical bridge
  formal/*scope*.txt, README.txt      : precise formalization boundaries
  formal/*.log                       : compiler output and dependency audits
  artifacts/check_artifacts.py        : syntax/metric/numerical audit
  artifacts/check_results.json        : reproducible audit results
  audit/source_manifest.json         : six immutable source identities
  audit/review_notes.txt              : comparison and proof-review scope
  audit/validation.json              : build/check summary
  SHA256SUMS                         : hashes of all other package files

VERIFICATION BOUNDARY
---------------------
All three Lean files use Init, not Mathlib, and contain no admitted proofs.
The constructive core and Nat comparator have empty printed axiom audits.
The ClassicalBridge file deliberately uses classical logic at its indicated
steps. Explicit arithmetic assumptions remain structure fields.

This is NOT an end-to-end Lean formalization of PRA syntax, first-order
derivability, or bi-interpretability. The forward certificate restricts its
schema to an explicit admissibility predicate for term evaluations, with
specified finite-term closure properties. The complete description-syntax
connection, internal PRA converse, and interpretation theorem are proved
in the manuscript. The Nat comparator certificate does not by itself prove
that only quantifier-free induction is used inside PRA.

The Python program evaluates the actual five PR descriptions on 10,201
pairs and verifies template counts. Finite tests are diagnostics, not a
substitute for the proofs.

REPRODUCE
---------
  sh build.sh
  sh check.sh

Build requirements: pdflatex with standard AMS, Latin Modern, geometry,
microtype, booktabs/tabularx, enumitem, fancyhdr, xurl, and hyperref packages.
Check requirements: Python 3.10+ and Lean 4.19.0. No external Python packages
or Lean libraries are needed. To select a compiler explicitly:

  PRA_LEAN_BIN=/absolute/path/to/lean sh check.sh

Verify package checksums before rebuilding:

  sha256sum -c SHA256SUMS

SOURCE SNAPSHOT
---------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 392757d09455930d2b090b26bd1537799451c91a

All six current docs/drafts archives were read and their bytes matched to
Git blob hashes. Their internal comparison tables discuss an earlier
collection; the report uses the actual inventory at this commit.
The incoming directory inventory and complete README identified no other
PRA package. Unrelated Turing-machine archives were not unpacked.
No existing draft's scripts were executed. No repository changes are
required to use this independent archive.
