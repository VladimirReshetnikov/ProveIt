#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
python3 artifacts/check_artifacts.py
PRA_LEAN_BIN=${PRA_LEAN_BIN:-lean}
"$PRA_LEAN_BIN" --version
"$PRA_LEAN_BIN" formal/StationaryAgreement.lean
"$PRA_LEAN_BIN" formal/Comparator.lean
"$PRA_LEAN_BIN" formal/ClassicalBridge.lean
echo "PASS: all requested checks completed."
