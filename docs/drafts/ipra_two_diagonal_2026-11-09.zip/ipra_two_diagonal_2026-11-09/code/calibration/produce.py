"""Untrusted certificate producer. Does not import or inspect the replayer."""
import json
from pathlib import Path

def v(name): return ['var',name]
def zero(): return ['zero']
def S(x): return ['S',x]
def one(): return S(zero())
def M(x,y): return ['M',x,y]
def A(x,y): return ['A',x,y]
def Z(x): return M(x,one())
def ell(a,b): return Z(['w',a,b])
def eps(a,b): return ['T',ell(a,b),ell(b,a)]
def c(a): return A(a,zero())
def d(a,b): return M(eps(c(b),b),eps(a,b))
def e(x): return Z(Z(x))
def ramp(x,a,b): return A(M(e(x),a),M(Z(e(x)),b))
def eq(a,b): return ['eq',a,b]
def imp(a,b): return ['imp',a,b]
def all_(x,p): return ['all',x,p]
def both(p,q): return ['and',p,q]
def bit(t): return ['or',eq(t,zero()),eq(t,one())]
def subst(t,x,u):
    if t[0]=='var': return u if t[1]==x else t
    return [t[0],*(subst(a,x,u) for a in t[1:])]
def hyp(name): return {'rule':'hyp','name':name}
def ax(name,*terms): return {'rule':'axiom','name':name,'terms':list(terms)}
def inst(p,t): return {'rule':'all_e','proof':p,'term':t}
def th(name,*args):
    p={'rule':'theorem','name':name}
    for t in args:p=inst(p,t)
    return p
def gen(name,p):return {'rule':'all_i','variable':name,'proof':p}
def intro(name,assumption,p):return {'rule':'imp_i','name':name,'assumption':assumption,'proof':p}
def mp(p,q):return {'rule':'imp_e','major':p,'minor':q}

class P:
    def __init__(self,l,r,node):self.l,self.r,self.node=l,r,node
def refl(t):return P(t,t,{'rule':'eq_refl','term':t})
def sym(p):return P(p.r,p.l,{'rule':'eq_sym','proof':p.node})
def trans(p,q):
    if p.r!=q.l:raise ValueError('Producer transitivity mismatch')
    if p.l==p.r:return q
    if q.l==q.r:return p
    return P(p.l,q.r,{'rule':'eq_trans','left':p.node,'right':q.node})
def cong(template,p):
    return P(subst(template,'hole',p.l),subst(template,'hole',p.r),
             {'rule':'cong','variable':'hole','template':template,'proof':p.node})
def hproof(name,l,r):return P(l,r,hyp(name))
def lemma(name,l,r,*args):return P(l,r,th(name,*args))

def norm(t,rules=()):
    # Every simplification emits a checked computation or equality-congruence
    # proof. This is an untrusted search heuristic, not a trusted evaluator.
    for p in rules:
        if t==p.l and p.l!=p.r:return trans(p,norm(p.r,rules))
    result=refl(t)
    if t[0]=='var':return result
    for i in range(1,len(t)):
        child=norm(result.r[i],rules)
        if child.l!=child.r:
            template=[*result.r];template[i]=v('hole')
            result=trans(result,cong(template,child))
    current=result.r
    for p in rules:
        if current==p.l and p.l!=p.r:return trans(result,trans(p,norm(p.r,rules)))
    if current[0] in {'M','A','T'}:
        tag,n,a=current
        if n==zero():
            step=P(current,a,ax(tag+'0',a))
        elif n[0]=='S':
            if tag=='M':rhs=zero()
            elif tag=='A':rhs=S(A(n[1],a))
            else:rhs=Z(['T',n[1],a])
            step=P(current,rhs,ax(tag+'S',n[1],a))
        else:return result
        return trans(result,trans(step,norm(step.r,rules)))
    return result

serial=0
def cases(major,t,build,rules=()):
    global serial
    serial+=1; left='caseL'+str(serial);right='caseR'+str(serial)
    lp=build([*rules,hproof(left,t,zero())])
    rp=build([*rules,hproof(right,t,one())])
    return {'rule':'or_e','major':major,'left_name':left,'right_name':right,
            'left':lp,'right':rp}
def case_z(arg,build,rules=()):return cases(ax('BR',arg),Z(arg),build,rules)
def case_eps(a,b,build,rules=()):return cases(th('raw_range',a,b),eps(a,b),build,rules)
def range_node(t,rules):
    p=norm(t,rules)
    if p.r not in [zero(),one()]:raise ValueError('Producer did not reduce a bit')
    side=int(p.r==one())
    return {'rule':'or_i','side':side,'other':eq(t,one() if side==0 else zero()),'proof':p.node}
def zero_node(t,rules):
    p=norm(t,rules)
    if p.r!=zero():raise ValueError('Producer did not reduce to zero: '+str(p.r))
    return p.node

a,b,z=v('a'),v('b'),v('z')
claims=[]
def export(name,conclusion,proof):claims.append({'name':name,'conclusion':conclusion,'proof':proof})

# Raw Boolean comparison is XOR of two independently Boolean observations.
pr=case_z(['w',a,b],lambda r:case_z(['w',b,a],lambda s:range_node(eps(a,b),s),r))
export('raw_range',all_('a',all_('b',bit(eps(a,b)))),gen('a',gen('b',pr)))
pr=case_z(['w',a,a],lambda r:zero_node(eps(a,a),r))
export('raw_diagonal',all_('a',eq(eps(a,a),zero())),gen('a',pr))

# Guard M(clock-error,raw-test) masks comparisons until the clock is correct.
pr=case_eps(c(b),b,lambda r:case_eps(a,b,lambda s:range_node(d(a,b),s),r))
export('guard_range',all_('a',all_('b',bit(d(a,b)))),gen('a',gen('b',pr)))
diag=lemma('raw_diagonal',eps(a,a),zero(),a)
pr=case_eps(c(a),a,lambda r:zero_node(d(a,a),[*r,diag]))
export('guard_diagonal',all_('a',eq(d(a,a),zero())),gen('a',pr))
pr=case_eps(c(a),a,lambda r:zero_node(d(c(a),a),r))
export('guard_clock_diagonal',all_('a',eq(d(c(a),a),zero())),gen('a',pr))

# One anchored-reset instance calibrates every clock-image comparison.
fz=ramp(z,a,b); anchor=ramp(one(),a,b)
guard=d(fz,anchor)
H=hproof('comparison',d(c(a),b),zero())
bb=lemma('guard_diagonal',d(b,b),zero(),b)
guard_node=case_z(Z(z),lambda r:zero_node(guard,[*r,H,bb]))
guard_proof=P(guard,zero(),guard_node)
reset=M(guard,S(z))
reset_step=norm(reset,[guard_proof])
if reset_step.r!=S(z):raise ValueError('Reset did not become successor')
premise=cong(ramp(v('hole'),a,b),reset_step)
premise=trans(premise,norm(ramp(S(z),a,b)))
premise=trans(premise,sym(norm(anchor)))
template=ramp(v('x'),a,b)
ar_node={'rule':'AR','variable':'x','template':template,'eigenvariable':'z',
         'target':zero(),'proof':premise.node}
ar=P(ramp(zero(),a,b),anchor,ar_node)
out=trans(sym(norm(ramp(zero(),a,b))),ar)
out=trans(out,norm(anchor))
if out.l!=c(a) or out.r!=b:raise ValueError('Wrong calibration equation')
pr=intro('comparison',eq(d(c(a),b),zero()),out.node)
export('restricted_reflection',all_('a',all_('b',imp(eq(d(c(a),b),zero()),eq(c(a),b)))),gen('a',gen('b',pr)))

pr=mp(th('restricted_reflection',a,a),th('guard_clock_diagonal',a))
export('clock_identity',all_('a',eq(c(a),a)),gen('a',pr))

# Full reflection uses the checked clock theorem, not another unproved rule.
clock=lemma('clock_identity',c(a),a,a)
guard_eq=cong(d(v('hole'),b),clock)
restricted_assumption=trans(guard_eq,hproof('guard',d(a,b),zero()))
ca_b=P(c(a),b,mp(th('restricted_reflection',a,b),restricted_assumption.node))
forward=trans(sym(clock),ca_b)
forward_node=intro('guard',eq(d(a,b),zero()),forward.node)
ab=hproof('actual_equal',a,b)
reverse=trans(cong(d(v('hole'),b),ab),lemma('guard_diagonal',d(b,b),zero(),b))
reverse_node=intro('actual_equal',eq(a,b),reverse.node)
pr={'rule':'and_i','left':forward_node,'right':reverse_node}
goal=both(imp(eq(d(a,b),zero()),eq(a,b)),imp(eq(a,b),eq(d(a,b),zero())))
export('full_reflection',all_('a',all_('b',goal)),gen('a',gen('b',pr)))

certificate={
    'format':'closed-scalar-calibration-v1',
    'trusted_axioms':{
        'M0':'M(0,a)=a','MS':'M(Sn,a)=0','A0':'A(0,a)=a','AS':'A(Sn,a)=S(A(n,a))',
        'T0':'T(0,a)=a','TS':'T(Sn,a)=M(T(n,a),1)','BR':'M(x,1)=0 or M(x,1)=1'},
    'trusted_AR':'From f(M(d(f(z),f(1)),Sz))=f(1), infer f(t)=f(1), with fresh z and the identical fixed template f.',
    'claims':claims}
destination=Path(__file__).with_name('certificate.json')
destination.write_text(json.dumps(certificate,indent=2)+'\n')
print(json.dumps({'certificate':str(destination),'exported_theorems':len(claims),'bytes':destination.stat().st_size}))
