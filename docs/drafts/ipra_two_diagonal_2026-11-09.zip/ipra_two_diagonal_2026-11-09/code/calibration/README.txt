SYMBOLIC CALIBRATION CERTIFICATE
================================

What is verified
----------------
certificate.json gives eight closed theorems with 673 checked proof nodes.
There is exactly one anchored-reset (AR) application, inside the proof of
restricted reflection. The later clock and full-reflection results use
earlier CHECKED closed theorems, never a trusted theorem database.

Run from this directory with Python 3.10 or later:
  python3 produce.py
  python3 replay.py
  python3 validate.py

The producer is untrusted and does not import or inspect the replayer. It
searches for elementary reductions and emits explicit congruence,
transitivity, computation and natural-deduction proof nodes. The replayer
checks these nodes independently; no symbolic simplifier, numerical
evaluator, eval/exec payload or external theorem prover is trusted.

This is a certificate for a SPECIFIC SYMBOLIC FRAGMENT. It is not a complete
iPRA proof checker and is not a source-size competitor. It does not certify
the target-side comparator theorem, the primitive-recursive compilation,
the induction reconstruction, or the bi-interpretability metatheorem.

Numerical language and exact trusted arithmetic
-----------------------------------------------
Use first-order terms 0, S(t), M(t,u), A(t,u), T(t,u), w(t,u), and variables.
All operations have their displayed fixed arities. Here
  M(n,a) = I_0(n,a),
  A(n,a) = I_S(n,a),
  T(n,a) = I_Z(n,a),
  1 = S0,  Z(n) = M(n,1).
The update templates 0, S(u), and Z(u) are closed unary templates.

The exact trusted schemas are:
  M(0,a)=a;       M(Sn,a)=0;
  A(0,a)=a;       A(Sn,a)=S(A(n,a));
  T(0,a)=a;       T(Sn,a)=Z(T(n,a));
  Z(t)=0 or Z(t)=1.                                  (BR)

A(Sn,a)=S(A(n,a)) is declared to identify the complete closed iterator
profile but is not used anywhere in this certificate. The actual occurrence
counts are BR 5, T0 6, TS 3, M0 61, MS 75, A0 17, AS 0.

w is an UNINTERPRETED binary operation: no equation about w is available.
Define exact finite term abbreviations
  ell(a,b) = Z(w(a,b)),
  epsilon(a,b) = T(ell(a,b),ell(b,a)),
  c(a) = A(a,0),
  d(a,b) = M(epsilon(c(b),b),epsilon(a,b)).
The certificate contains the fully expanded M/A/T/w syntax, not trusted
epsilon, d, c, ell or ramp symbols.

In the full proposed theory w(a,b) is replaced everywhere by the fixed
closed-iteration comparator term L(a,b). The certificate's use of an
uninterpreted w makes the source proof independent of that comparator's
standard correctness. It does NOT assert that AR is valid in iPRA for every
arbitrary w; target validity requires the separately proved correctness of
the actual selected L. This distinction is essential.

Exact trusted anchored-reset rule
---------------------------------
For one fixed numerical template f(x,p), define
  anchor = f(1,p),
  rho_f(z) = M(d(f(z,p),anchor),Sz).
From a derivation under retained context Gamma of
  f(rho_f(z),p)=anchor
the rule concludes
  f(t,p)=anchor.

The same literal template f is reconstructed in all occurrences. The
eigenvariable z must be distinct from x and absent from every retained
assumption, t, and the fixed template (including all passive parameters).
No independently supplied anchor, equality-reflection rule, local induction
hypothesis, extra equation-induction principle, or closure axiom is accepted.

The conclusion target t may be any well-formed term satisfying freshness.
The exported restricted-reflection proof uses t=0 and the ramp
  F_ab(y)=A(M(Z(Z(y)),a),M(Z(Z(Z(y))),b)).
Computation gives F_ab(0)=c(a), F_ab(Sy)=b, and F_ab(1)=b.
Case analysis on Z(Z(z)) proves F_ab(z) has value c(a) or b, without
assuming that c is already the identity.

Logical and equality steps
---------------------------
The copied ND engine checks hypotheses, implication introduction and
elimination, conjunction introduction and elimination, disjunction
elimination, universal introduction/elimination, equality reflexivity,
symmetry and substitution. The wrapper adds ordinary disjunction
introduction, equality transitivity, numerical congruence, previously
checked closed-theorem references, and the exact AR rule above.

Transitivity and numerical congruence are standard derived equality rules.
Universal introduction checks freshness against the retained context.
Universal substitution avoids capture. AR has its stricter fresh-template
and target checks. Exported claims must be closed and must match the eight
hard-coded targets exactly, in dependency order. A forward theorem reference
is rejected.

No separation, falsity axiom, numerical coverage, ordinary induction,
successor injectivity, predecessor, pairing, comparator correctness or
semantic arithmetic-equality decision is used in the calibration proof.

Eight exported claims
----------------------
1. Raw range: epsilon(a,b)=0 or epsilon(a,b)=1.
2. Raw diagonal: epsilon(a,a)=0.
3. Guard range: d(a,b)=0 or d(a,b)=1.
4. Guard diagonal: d(a,a)=0.
5. Clock diagonal: d(c(a),a)=0.
6. Restricted reflection: d(c(a),b)=0 implies c(a)=b.
7. Clock identity: c(a)=a.
8. Full reflection: d(a,b)=0 implies a=b, and conversely.

The raw diagonal comes from the same Boolean bit appearing twice as the
inputs of T, which performs XOR on Boolean inputs. The clock diagonal is
the elementary identity M(v,v)=0 for Boolean v. Restricted reflection uses
the ramp and AR exactly once. Substituting b=a and using the clock diagonal
then calibrates the clock. Full reflection follows by ordinary equality
transport; it does not require a second trusted AR application.

Finite enforcement checks
--------------------------
validate.py replays the symbolic certificate and rejects sixteen deliberately
invalid controls, including an invented arithmetic axiom, a future theorem
reference, an AR eigenvariable in passive parameters or in its target, an
independent anchor, a changed template or target, a missing premise, an
unlicensed induction rule, a wrong arity, an unknown term constructor,
loss of the literal bit correlation in the raw diagonal, and an unrelated
reflexivity proof substituted for the clock theorem.

Six command-line checks cover the valid certificate and malformed inputs in
normal and optimized Python. All 16 controls rejected; all 6 CLI checks passed
under CPython 3.12.14. validation.json records exact results and source hashes.
These finite checks exercise implementation enforcement. The successful
symbolic proof itself consists of the displayed elementary inference rules;
there is no numerical sampling in it.

Attribution
------------
shared_nd.py is an unchanged copy of
  ipra_package_reconstructed.zip ::
  ipra_reset_2026-11-08/code/replay_reset_certificate.py
from VladimirReshetnikov/ProveIt, pinned head
  89fd4b4c5cd158259b1f2846f63e3d98f053553c.
Its SHA-256 is
  a4e204864cf4b557e7126d147b9354071724bd397aa61c6afd0c72199726a4a1.
Its original module contains a different default profile and CLI. The new
wrapper imports only its shared logical engine and passes the explicit
new arithmetic provider and extension to every recursive proof check.
The old default arithmetic axioms are never called in the new verification.
The inherited license is preserved as LICENSE-inherited.txt.

The wrapper replay.py, producer produce.py, certificate, validation controls,
and present documentation were prepared for the current investigation.
