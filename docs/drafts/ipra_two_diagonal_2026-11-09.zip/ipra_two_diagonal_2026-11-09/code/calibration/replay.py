"""Symbolic clock/equality calibration replayer; not a complete iPRA kernel.

The ND engine is copied, unchanged and attributed, from the reconstructed
ProveIt draft. The arithmetic signature here is a strictly disclosed profile.
No natural-number evaluator, semantic equality oracle, induction axiom or
predecessor/coding theorem is used. Raw w is an uninterpreted binary function.
"""
import json
from collections import Counter
from pathlib import Path
import sys
import shared_nd as nd

nd.TERM_ARITIES.clear()
nd.TERM_ARITIES.update({'zero': 0, 'S': 1, 'M': 2, 'A': 2, 'T': 2, 'w': 2})

TRUSTED_AXIOMS = {
    'M0': 'M(0,a)=a',
    'MS': 'M(Sn,a)=0',
    'A0': 'A(0,a)=a',
    'AS': 'A(Sn,a)=S(A(n,a))',
    'T0': 'T(0,a)=a',
    'TS': 'T(Sn,a)=M(T(n,a),1)',
    'BR': 'M(x,1)=0 or M(x,1)=1',
}
TRUSTED_AR = 'From f(M(d(f(z),f(1)),Sz))=f(1), infer f(t)=f(1), with fresh z and the identical fixed template f.'

def v(name): return ['var', name]
def zero(): return ['zero']
def S(x): return ['S', x]
def one(): return S(zero())
def M(x,y): return ['M',x,y]
def A(x,y): return ['A',x,y]
def Z(x): return M(x,one())
def ell(a,b): return Z(['w',a,b])
def epsilon(a,b): return ['T',ell(a,b),ell(b,a)]
def clock(a): return A(a,zero())
def d(a,b): return M(epsilon(clock(b),b),epsilon(a,b))
def eq(a,b): return ['eq',a,b]
def imp(a,b): return ['imp',a,b]
def all_(x,p): return ['all',x,p]
def both(p,q): return ['and',p,q]
def bit(t): return ['or',eq(t,zero()),eq(t,one())]

def expected_claims():
    a,b=v('a'),v('b')
    reflection=both(imp(eq(d(a,b),zero()),eq(a,b)),
                    imp(eq(a,b),eq(d(a,b),zero())))
    return {
        'raw_range': all_('a',all_('b',bit(epsilon(a,b)))),
        'raw_diagonal': all_('a',eq(epsilon(a,a),zero())),
        'guard_range': all_('a',all_('b',bit(d(a,b)))),
        'guard_diagonal': all_('a',eq(d(a,a),zero())),
        'guard_clock_diagonal': all_('a',eq(d(clock(a),a),zero())),
        'restricted_reflection': all_('a',all_('b',imp(eq(d(clock(a),b),zero()),eq(clock(a),b)))),
        'clock_identity': all_('a',eq(clock(a),a)),
        'full_reflection': all_('a',all_('b',reflection)),
    }

def axiom(name,arguments):
    nd.require(name in TRUSTED_AXIOMS and type(arguments) is list,'Unlicensed arithmetic axiom')
    for t in arguments: nd.term(t)
    arity=2 if name in {'MS','AS','TS'} else 1
    nd.require(len(arguments)==arity,'Arithmetic axiom arity mismatch')
    if name=='BR': return bit(Z(arguments[0]))
    if name.endswith('0'):
        a,=arguments
        return eq([name[0],zero(),a],a)
    n,a=arguments
    if name=='MS': return eq(M(S(n),a),zero())
    if name=='AS': return eq(A(S(n),a),S(A(n,a)))
    return eq(['T',S(n),a],Z(['T',n,a]))

def verify(certificate):
    nd.require(type(certificate) is dict and set(certificate)=={'format','trusted_axioms','trusted_AR','claims'},'Malformed certificate header')
    nd.require(certificate['format']=='closed-scalar-calibration-v1','Unknown format')
    nd.require(certificate['trusted_axioms']==TRUSTED_AXIOMS,'Trusted arithmetic declaration mismatch')
    nd.require(certificate['trusted_AR']==TRUSTED_AR,'AR declaration mismatch')
    targets=expected_claims()
    claims=certificate['claims']
    nd.require(type(claims) is list and len(claims)==len(targets),'Wrong exported theorem count')
    checked={}
    rows=[]
    def extension(node,context,derive):
        rule=node['rule']
        if rule=='theorem':
            nd.require(set(node)=={'rule','name'} and node['name'] in checked,'Unchecked or malformed theorem reference')
            return checked[node['name']]
        if rule=='or_i':
            nd.require(set(node)=={'rule','side','other','proof'},'Malformed disjunction introduction')
            side=node['side']
            nd.require(type(side) is int and side in (0,1),'Invalid disjunction side')
            proved=derive(node['proof']); other=nd.formula(node['other'])
            return ['or',proved,other] if side==0 else ['or',other,proved]
        if rule=='eq_trans':
            nd.require(set(node)=={'rule','left','right'},'Malformed transitivity')
            left=derive(node['left']); right=derive(node['right'])
            nd.require(left[0]==right[0]=='eq' and left[2]==right[1],'Transitivity middle mismatch')
            return eq(left[1],right[2])
        if rule=='cong':
            nd.require(set(node)=={'rule','variable','template','proof'},'Malformed congruence')
            variable=node['variable']; nd.require(nd.identifier(variable),'Invalid congruence variable')
            template=nd.term(node['template']); equality=derive(node['proof'])
            nd.require(equality[0]=='eq','Congruence needs an equality')
            return eq(nd.substitute_term(template,variable,equality[1]),
                      nd.substitute_term(template,variable,equality[2]))
        nd.require(rule=='AR','Unlicensed inference rule: '+rule)
        nd.require(set(node)=={'rule','variable','template','eigenvariable','target','proof'},'Malformed AR node')
        x,z=node['variable'],node['eigenvariable']
        nd.require(nd.identifier(x) and nd.identifier(z) and x!=z,'Invalid AR variables')
        template=nd.term(node['template']); target=nd.term(node['target'])
        retained=set().union(*(nd.free_variables(f) for f in context.values())) if context else set()
        nd.require(z not in retained|nd.term_variables(target)|nd.term_variables(template),'AR eigenvariable is not fresh')
        f=lambda t:nd.substitute_term(template,x,t)
        anchor=f(one())
        reset=M(d(f(v(z)),anchor),S(v(z)))
        premise=derive(node['proof'])
        nd.require(premise==eq(f(reset),anchor),'AR premise does not match its exact template and guard')
        return eq(f(target),anchor)
    for claim,expected_name in zip(claims,targets):
        nd.require(type(claim) is dict and set(claim)=={'name','conclusion','proof'},'Malformed exported theorem')
        name=claim['name']
        nd.require(name==expected_name and name not in checked,'Theorems must occur in the specified order')
        conclusion=nd.formula(claim['conclusion'])
        nd.require(conclusion==targets[name] and not nd.free_variables(conclusion),'Exported target changed or open')
        counts=Counter()
        actual=nd.replay(claim['proof'],{},counts,axiom,extension)
        nd.require(actual==conclusion,'Proof has the wrong exported conclusion')
        checked[name]=actual
        rows.append({'name':name,'proof_nodes':sum(counts.values()),'rules':dict(sorted(counts.items()))})
    return {'accepted':True,'claims':rows,'proof_nodes':sum(r['proof_nodes'] for r in rows),
            'trusted_axioms':TRUSTED_AXIOMS,'trusted_AR':TRUSTED_AR,
            'scope':'Generic symbolic calibration for raw ell(a,b)=Z(w(a,b)) and uninterpreted w. Not a complete iPRA checker; no target-side comparator correctness or bi-interpretability is certified.'}

def main():
    p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('certificate.json')
    try: result=verify(json.loads(p.read_text()))
    except (nd.InvalidCertificate,KeyError,TypeError,IndexError,RecursionError,ValueError) as error:
        print(json.dumps({'accepted':False,'error':str(error)})); return 1
    print(json.dumps(result,indent=2)); return 0

if __name__=='__main__': raise SystemExit(main())
