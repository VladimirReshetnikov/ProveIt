#!/usr/bin/env python3
"""Read-only source audit of complete iPRA checkers in the extracted corpus.

This script measures source. It does not certify mathematical completeness.
The status classification is supported by the accompanying inventory notes.
"""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize

IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
EXPERIMENTS = {'progression_experiment.py', 'closed_update_prototype.py',
               'anchor_experiment.py'}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def digest(data):
    return hashlib.sha256(data).hexdigest()


def measure(path):
    raw = path.read_bytes()
    tree = StripDocstrings().visit(ast.parse(raw.decode('utf-8')))
    normalized = (ast.unparse(tree) + '\n').encode('utf-8')
    tokens = tokenize.generate_tokens(io.StringIO(normalized.decode()).readline)
    return {
        'sha256': digest(raw),
        'normalized_sha256': digest(normalized),
        'raw_bytes': len(raw),
        'normalized_tokens': sum(t.type not in IGNORED for t in tokens),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized),
    }


def is_checker(path):
    source = path.read_text()
    if not ('ACCEPT' in source and 'REJECT' in source
            and ('json.load' in source or 'json.loads' in source)):
        return False
    tree = ast.parse(source)
    functions = {node.name for node in tree.body if isinstance(node, ast.FunctionDef)}
    return ((bool(functions & {'i', 'inst', 'sub'})
             and bool(functions & {'c', 'check', 'test'})
             and functions <= {'i', 'c', 'inst', 'check', 'take', 'sub', 'test'})
            or path.name in EXPERIMENTS
            or path.name == 'shifted_direct_kernel.py'
            or ('direct_kernel' in path.parts and path.name == 'kernel.py'))


def main():
    workspace = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
    output = Path(__file__).resolve().parent
    manifest = json.loads((workspace / 'reference_archives/manifest.json').read_text())
    archives = []
    for entry in manifest['files']:
        raw = (workspace / 'reference_archives' / entry['name']).read_bytes()
        git_blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        if len(raw) != entry['size'] or git_blob != entry['sha']:
            raise ValueError('Archive integrity failure: ' + entry['name'])
        archives.append({'filename': entry['name'], 'repository_path': entry['path'],
                         'git_blob_sha1': git_blob, 'size_bytes': len(raw),
                         'sha256': digest(raw)})
    programs = {}
    for path in sorted((workspace / 'drafts').rglob('*.py')):
        if not is_checker(path):
            continue
        metrics = measure(path)
        key = metrics['normalized_sha256']
        status = 'unvalidated_experiment' if path.name in EXPERIMENTS else 'complete_inherited_checker'
        row = programs.setdefault(key, {'status': status,
                                       'normalized_tokens': metrics['normalized_tokens'],
                                       'ast_nodes': metrics['ast_nodes'],
                                       'normalized_bytes': metrics['normalized_bytes'],
                                       'normalized_sha256': key, 'occurrences': []})
        if row['status'] != status:
            raise ValueError('Conflicting status classification')
        parts = path.relative_to(workspace / 'drafts').parts
        row['occurrences'].append({
            'archive': parts[0] + '.zip',
            'member': '/'.join(parts[1:]),
            'workspace_relative_path': str(path.relative_to(workspace)),
            'source_sha256': metrics['sha256'], 'source_bytes': metrics['raw_bytes']})
    rows = sorted(programs.values(), key=lambda row: (row['normalized_tokens'], row['ast_nodes'], row['normalized_bytes']))
    complete = [r for r in rows if r['status'] == 'complete_inherited_checker']
    coordinates = ['normalized_tokens', 'ast_nodes', 'normalized_bytes']
    minima = {key: min(row[key] for row in complete) for key in coordinates}
    result = {'repository': manifest['repository'], 'head': manifest['head'],
              'python': platform.python_version(), 'measurement': 'Whole module; strip genuine leading docstrings; ast.unparse plus newline; significant Python tokens, all AST nodes, UTF-8 bytes. Identifiers are not normalized.',
              'scope': 'Source inventory and source measurements, not verification of inherited mathematical metatheory.',
              'archives': archives, 'complete_normalized_program_count': len(complete),
              'experiment_normalized_program_count': len(rows) - len(complete),
              'coordinatewise_minima': minima,
              'minimum_attainers': {key: [row['normalized_sha256'] for row in complete if row[key] == minima[key]] for key in coordinates},
              'programs': rows}
    (output / 'current_checker_audit.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['CURRENT CHECKER INVENTORY', '=' * 25, '',
             'Pinned repository head: ' + manifest['head'],
             'Archives: ' + str(len(archives)),
             'Complete normalized programs: ' + str(len(complete)),
             'Unvalidated experiments: ' + str(len(rows) - len(complete)),
             'Coordinate minima: ' + str(minima),
             'Python: ' + platform.python_version(), '',
             'Tokens  AST  Bytes  Status  Representative archive member']
    for row in rows:
        occurrence = row['occurrences'][0]
        lines.append(f"{row['normalized_tokens']:6} {row['ast_nodes']:4} {row['normalized_bytes']:6} "
                     f"{row['status']}  {occurrence['archive']} :: {occurrence['member']}")
    lines.extend(['', 'Classification note: the three experiment filenames explicitly disclaim completed correctness/completeness validation in their source notes. The readable shifted direct checker is included despite its much larger size. Producers, symbolic-fragment checkers, metric harnesses and validation scripts are excluded. All raw source and archive hashes, every occurrence, and all normalized hashes are in current_checker_audit.json. No inherited source was changed or executed by this audit.'])
    (output / 'current_checker_inventory.txt').write_text('\n'.join(lines) + '\n')
    print(json.dumps({key: result[key] for key in ['head', 'python', 'complete_normalized_program_count', 'experiment_normalized_program_count', 'coordinatewise_minima']}, indent=2))


if __name__ == '__main__':
    main()
