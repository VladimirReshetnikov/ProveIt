"""Reproduce whole-source sizes of the nineteen unchanged complete comparators."""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def run():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "reference/checker_manifest.json").read_text())
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    rows = []
    for frozen in manifest:
        path = root / frozen["file"]
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != frozen["source_sha256"]:
            raise RuntimeError("Frozen comparator changed: " + frozen["file"])
        tree = StripDocstrings().visit(ast.parse(raw.decode()))
        normalized = (ast.unparse(tree) + "\n").encode()
        tokens = tokenize.generate_tokens(io.StringIO(normalized.decode()).readline)
        metrics = {"normalized_tokens": sum(t.type not in ignored for t in tokens),
                   "ast_nodes": sum(1 for _ in ast.walk(tree)),
                   "normalized_bytes": len(normalized)}
        if platform.python_version() == "3.12.14":
            if any(metrics[k] != frozen[k] for k in metrics):
                raise RuntimeError("Pinned-runtime measurement changed")
            if hashlib.sha256(normalized).hexdigest() != frozen["normalized_sha256"]:
                raise RuntimeError("Pinned-runtime normalization changed")
        rows.append({"file": frozen["file"], **metrics})
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    result = {"passed": True, "python": platform.python_version(), "programs": len(rows),
              "source_integrity_checked": True,
              "coordinate_minima": {k: min(row[k] for row in rows) for k in fields},
              "measurements": rows,
              "scope": "Whole-source measurements; inherited programs are parsed, not executed. This does not certify their metatheory."}
    (root / "evidence/frozen_measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
