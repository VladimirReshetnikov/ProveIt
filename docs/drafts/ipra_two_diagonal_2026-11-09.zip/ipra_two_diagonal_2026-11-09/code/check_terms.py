"""Finite transcription diagnostics; these are not nonstandard-model proofs."""
from copy import deepcopy
import json
from pathlib import Path
from closed_terms import DECLARATIONS, InvalidTerm, evaluator, source_digest, tree_node_counts, validate


def run():
    validate(DECLARATIONS)
    direct, direct_iterate = evaluator(successor_acceleration=False)
    fast, fast_iterate = evaluator(successor_acceleration=True)
    counts = {"direct_detector_grid": 0, "accelerated_detector_grid": 0,
              "clock_and_ramp": 0, "state_formula": 0, "malformed_tables_rejected": 0}
    for a in range(4):
        for b in range(4):
            for name in ("epsilon", "d"):
                actual = direct(name, (a, b))
                if actual != int(a != b):
                    raise RuntimeError((name, a, b, actual))
                if actual != fast(name, (a, b)):
                    raise RuntimeError("Direct/accelerated disagreement")
                counts["direct_detector_grid"] += 1
    for a in range(9):
        for b in range(9):
            for name in ("epsilon", "d"):
                if fast(name, (a, b)) != int(a != b):
                    raise RuntimeError((name, a, b))
                counts["accelerated_detector_grid"] += 1
            state = fast_iterate("H", b, fast("pow2", (a,)))
            if state != 3 ** min(a, b) * 2 ** max(a - b, 0):
                raise RuntimeError(("state", a, b, state))
            counts["state_formula"] += 1
    for a in range(17):
        if fast("clock", (a,)) != a:
            raise RuntimeError(("clock", a))
        counts["clock_and_ramp"] += 1
        for b in range(9):
            for n in range(5):
                if fast("ramp", (n, a, b)) != (a if n == 0 else b):
                    raise RuntimeError(("ramp", n, a, b))
                counts["clock_and_ramp"] += 1
    corruptions = []
    changed = deepcopy(DECLARATIONS); changed[0]["body"] = ["v", "a"]; corruptions.append(changed)
    changed = deepcopy(DECLARATIONS); changed[0]["body"] = ["call", "Z", ["v", "u"]]; corruptions.append(changed)
    changed = deepcopy(DECLARATIONS); changed[4]["body"] = ["I", "mask", ["0"], ["0"]]; corruptions.append(changed)
    changed = deepcopy(DECLARATIONS); changed[4]["body"] = ["call", "Z", ["0"], ["0"]]; corruptions.append(changed)
    changed = deepcopy(DECLARATIONS); changed[2]["body"] = ["I", "not_declared", ["0"], ["0"]]; corruptions.append(changed)
    changed = deepcopy(DECLARATIONS); changed[2]["parameters"] = ["n", "n"]; corruptions.append(changed)
    for table in corruptions:
        try:
            validate(table)
        except InvalidTerm:
            counts["malformed_tables_rejected"] += 1
        else:
            raise RuntimeError("Malformed table accepted")
    rows = tree_node_counts(DECLARATIONS)
    return {"passed": True, "declarations": len(DECLARATIONS), "source_sha256": source_digest(),
            "counts": counts, "expanded_tree_sizes": rows,
            "scope": "Finite term/closure/transcription diagnostics; no claim of formal iPRA verification.",
            "evaluation": "Exact declared recurrences with memoization and exact cycle skipping. Larger grid additionally accelerates only the checked update u -> S(u) by addition; detector, H, G, and d are never replaced by their expected formulas."}


if __name__ == "__main__":
    result = run()
    destination = Path(__file__).resolve().parents[1] / "evidence" / "term_diagnostics.json"
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
