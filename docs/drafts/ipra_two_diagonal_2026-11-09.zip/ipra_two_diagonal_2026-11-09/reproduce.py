"""Replay the new proof fragment and reproduce the disclosed diagnostics."""
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
steps = [
    ("calibration", ROOT / "code/calibration/validate.py"),
    ("terms", ROOT / "code/check_terms.py"),
    ("frozen-comparators", ROOT / "code/measure_frozen.py"),
]
receipts = []
for name, script in steps:
    process = subprocess.run([sys.executable, str(script)], cwd=ROOT,
                             text=True, capture_output=True)
    if process.returncode:
        print(process.stdout)
        print(process.stderr, file=sys.stderr)
        raise SystemExit(process.returncode)
    result = json.loads(process.stdout)
    receipts.append({"step": name, "exit_status": process.returncode, "result": result})
(ROOT / "evidence/reproduction.json").write_text(json.dumps(receipts, indent=2) + "\n")
print(json.dumps({"passed": True, "steps": [row["step"] for row in receipts],
                  "scope": "Symbolic source calibration, finite term checks, and source measurements; not a full mechanized bi-interpretability proof."}, indent=2))
