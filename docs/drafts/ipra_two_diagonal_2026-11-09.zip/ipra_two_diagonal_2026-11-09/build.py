"""Compile twice, using an installed TeX tree without system changes.

Adapted from the attributed reconstructed ProveIt report build helper.
An ordinary configured TeX Live installation is used unchanged. The optional
fallback builds a temporary format/map from already installed local sources;
it downloads nothing, changes no system configuration, and disables shell escape.
"""
import os
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def locate(name, env):
    result = subprocess.run(
        ["kpsewhich", "-progname=pdflatex", name],
        env=env, capture_output=True, text=True,
    )
    return result.stdout.strip() if result.returncode == 0 else ""


def run(command, env, cwd, log):
    result = subprocess.run(command, env=env, cwd=cwd, capture_output=True, text=True)
    log.append(result.stdout + result.stderr)
    if result.returncode:
        (ROOT / "evidence/latex_build.txt").write_text("\n".join(log))
        print(result.stdout[-6000:] + result.stderr[-1000:])
        raise SystemExit(result.returncode)


with tempfile.TemporaryDirectory(prefix="ipra-tex-") as temporary:
    env = dict(os.environ)
    log = []
    temp = Path(temporary)
    if not locate("latex.ltx", env):
        trees = [Path(p) for p in (
            "/usr/share/texlive/texmf-dist", "/usr/share/texmf", "/etc/texmf"
        ) if Path(p).is_dir()]
        if trees:
            env["TEXMF"] = "{" + ",".join(map(str, trees)) + "}"
            log.append("Local fallback: traverse installed TeX trees without an ls-R index.")
    if not locate("pdflatex.fmt", env):
        run([
            "pdftex", "-etex", "-ini", "-no-shell-escape",
            "-interaction=nonstopmode", "-halt-on-error",
            "-jobname=pdflatex", "-progname=pdflatex", "pdflatex.ini",
        ], env, temp, log)
        env["TEXFORMATS"] = str(temp) + os.pathsep + env.get("TEXFORMATS", "")
    if not locate("pdftex.map", env):
        maps = [locate(name, env) for name in (
            "lm.map", "cm.map", "cmextra.map", "symbols.map", "latxfont.map"
        )]
        (temp / "pdftex.map").write_text("\n".join(
            Path(path).read_text() for path in maps if path
        ))
        env["TEXFONTMAPS"] = str(temp) + os.pathsep + env.get("TEXFONTMAPS", "")
        log.append("Local fallback: use installed Latin Modern and AMS font maps.")
    for pass_number in (1, 2, 3):
        log.append("PDFLATEX PASS " + str(pass_number))
        run([
            "pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
            "-halt-on-error", "ipra_two_diagonal_2026-11-09.tex",
        ], env, ROOT, log)
    (ROOT / "evidence/latex_build.txt").write_text("\n".join(log))
print("Compiled ipra_two_diagonal_2026-11-09.pdf")
