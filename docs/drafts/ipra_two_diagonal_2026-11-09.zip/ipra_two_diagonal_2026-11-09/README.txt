TWO-DIAGONAL CALIBRATION FOR iPRA
================================
Prepared for Vladimir Reshetnikov, 9 November 2026.

RESULT
------
A new mathematical construction resolves the closed-iteration bootstrap
circle in the existing anchored-reset proposal. It first derives the
successor clock I_S(a,0)=a and then equality reflection. No ordinary
induction, predecessor, coverage, or raw-comparator correctness is assumed
in that source calibration. The complete ordinary theory is whole-domain
bi-interpretable and equiconsistent with full intuitionistic PRA.

The requested strictly smaller COMPLETE proof checker is NOT established.
The current eleven-archive corpus already contains a checker measuring
309 normalized tokens / 344 AST nodes / 864 normalized bytes. This package
does not assign that old checker's size to the new presentation. No
absolute simplestness or literature-wide priority is claimed.

MAIN FILES
----------
ipra_two_diagonal_2026-11-09.pdf   Main report with complete rule inventory.
ipra_two_diagonal_2026-11-09.tex   Standalone editable LaTeX source.
code/calibration/                Symbolic proof producer and replayer.
code/closed_terms.py             Explicit closed numerical term table.
code/check_terms.py              Closure and finite numerical diagnostics.
code/measure_frozen.py           Reproducible complete-source measurements.
evidence/                       Executed receipts and independent reviews.
reference/checkers/              Nineteen unchanged complete comparators.
reference/closed_equational/     Attributed internal arithmetic reconstruction.
research/coupled_seed.txt        Exact safe/unsafe zero-fiber boundary.
research/binary_tail.txt         Further scoped compiler and obstruction results.
ATTRIBUTION.txt                  Inherited/new contribution boundary.
SHA256SUMS                       Integrity hashes of the delivered payload.

CHECKS
------
With Python 3.12 and the standard library:
  python3 reproduce.py

The source calibration certificate exports eight closed theorems, using
673 proof nodes and one explicit AR application. Sixteen invalid controls
are rejected; six CLI checks pass under normal and optimized Python.
The proof uses an uninterpreted inner comparator. Its role is to establish
source derivability independently of the target comparator theorem.

The separate term evaluator follows the fixed definitions. It checks
32 small direct detector cases, 162 larger detector cases, 81 power-state
instances, 782 clock/ramp instances, and six malformed declaration tables.
Only the larger grid accelerates the exactly checked successor update.
Numerical sampling is NOT a proof of nonstandard-model validity.

Measurements cover entire unchanged checker sources after stripping
genuine docstrings and applying ast.unparse. They include parsing,
substitution, rejection, and verdict output. CPython version can affect
AST/unparser metrics; pinned values use CPython 3.12.14.

With a normal TeX installation:
  python3 build.py

The report's standard packages are listed at the top of its source.
Compilation uses no shell escape or network access. The included
closed-equational reference PDF/source is an attributed dependency,
not a newly proved precursor theorem.

VERIFY ORIGINAL PACKAGE
-----------------------
  sha256sum -c SHA256SUMS

Reproduction scripts regenerate evidence files; verify the original
manifest before changing or rebuilding the delivered files.

BOUNDARIES
----------
No Lean/Rocq formalization is claimed. The symbolic replayer checks a
specific source proof fragment, not the target validity of AR, the general
primitive-recursive compiler, or the interpretation composites. Those are
manuscript proofs, using the explicitly attributed internal reconstruction.
The appendix's initializer barrier concerns standard term definability,
not all relational or quotient bi-interpretations.

Repository snapshot:
89fd4b4c5cd158259b1f2846f63e3d98f053553c
https://github.com/VladimirReshetnikov/ProveIt/tree/89fd4b4c5cd158259b1f2846f63e3d98f053553c/docs/drafts
No remote repository changes were made.
