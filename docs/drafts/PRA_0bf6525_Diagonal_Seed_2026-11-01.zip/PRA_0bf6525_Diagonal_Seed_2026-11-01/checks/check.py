import json
from pathlib import Path
def N(tag,*args): return (tag,args)
def size(t):return 1+sum(map(size,t[1]))
v=lambda x:N(x)
f=lambda *x:N('A',*x)
eq=lambda x,y:N('=',x,y)
con=lambda x,y:N('&',x,y)
imp=lambda x,y:N('->',x,y)
alln=lambda x:N('forall',x)
a,n,c,z=map(v,['a','n','c','z']);zero=v('0');sn=N('S',n)
r=lambda x,y:N('R',x,y)
bad=eq(zero,N('S',zero))
def schema(extra):
 last=c if extra else a
 base=N('or',f(zero,r(zero,a),last),bad)
 step=alln(imp(f(n,a,last),f(sn,a,last)))
 rec=eq(r(sn,a),N('h',n,r(n,a)))
 out=alln(con(f(n,a,last),rec))
 t=alln(imp(con(base,step),out))
 return alln(t) if extra else t
assert size(schema(False))==41
assert size(schema(True))==42
# Simultaneous substitution, unlike recursive rewriting of replacements.
def sub(t,d):
 if not t[1] and t[0] in d:return d[t[0]]
 return N(t[0],*(sub(x,d) for x in t[1]))
probe=eq(z,r(zero,c))
b=sub(probe,{'z':r(zero,a),'c':a}); result=sub(probe,{'z':a,'c':a})
assert b[1][0]==b[1][1]
assert result==eq(a,r(zero,a))
wrong=eq(z,r(zero,z));wb=sub(wrong,{'z':r(zero,a)})
assert wb[1][0]!=wb[1][1]
assert size(schema(False))!=40
print(json.dumps({'diagonal':41,'independent_seed':42,'probe_base_reflexive':True,'missing_slot_control_rejected':True},sort_keys=True))
# Closed-seed side condition is syntactic, not 'fixed for this argument'.
def fv(t):
 if not t[1]:return {t[0]} if t[0] in {'a','n','c','z'} else set()
 return set().union(*(fv(x) for x in t[1]))
assert fv(N('S',zero))==set()
assert fv(a)=={'a'}
assert fv(r(zero,a))=={'a'}
closed_t=N('S',zero)
closed_probe=eq(z,r(zero,closed_t))
closed_base=sub(closed_probe,{'z':r(zero,closed_t)})
assert closed_base[1][0]==closed_base[1][1]
print('PASS: closed-seed probe; free-variable seed rejected by side condition')
