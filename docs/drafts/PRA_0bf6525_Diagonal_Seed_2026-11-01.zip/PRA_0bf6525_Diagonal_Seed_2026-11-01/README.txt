PRA with diagonal seed sharing -- review of commit 0bf6525f9b

Read report.pdf or report.tex. The new single schema D is constructively
proved equivalent to binary initialized recursion, separation, and
one-parameter quantifier-free induction. The supplied arithmetic compiler
is explicitly inherited; its original reports are preserved in sources/.

The displayed partial tree count is 41 against 42 at the matched fixed
parameter interface. This does not beat the raw 37-node unrestricted
implicit-initialization display under every measure, and is not a global
minimality claim. No new formal-kernel certificate is claimed.

Verification: python3 replay.py
Rebuild with an ordinary LaTeX installation: sh build.sh

checks/check.py checks syntax-tree counts and the critical simultaneous
substitution, including a negative control. replay.py verifies all sealed
file hashes and original Git blob identities. Neither is a semantic proof
checker. proofs/ contains independent mathematical audit notes.

The original source archives are included unchanged; scripts inside them
were not executed for this review. Their component formal-check claims
remain source-reported rather than independently rebuilt here.

New partial result: the 37-node zero-extra-parameter fragment T0 already
proves all one-parameter QF induction, using a delayed formula and a
closed-seed predecessor. Its remaining arbitrary-seed initialization is
unproved here, so no complete PRA equivalence for T0 is claimed.
