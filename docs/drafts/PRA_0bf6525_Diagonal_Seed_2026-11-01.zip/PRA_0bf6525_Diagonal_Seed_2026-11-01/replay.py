from pathlib import Path
import subprocess,hashlib,json
p=Path(__file__).resolve().parent
for line in (p/'MANIFEST.sha256').read_text().splitlines():
 h,name=line.split('  ',1);assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
for e in json.loads((p/'sources/inventory.json').read_text()):
 b=(p/'sources'/e['name']).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==e['sha']
subprocess.run(['python3',str(p/'checks/check.py')],check=True)
print('PASS: manifest, original Git blobs, syntax counts and substitution controls')
