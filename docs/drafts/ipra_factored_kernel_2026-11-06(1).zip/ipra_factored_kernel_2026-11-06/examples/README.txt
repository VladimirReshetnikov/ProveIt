CURATED EXECUTABLE PROOFS

Each JSON file is a certificate in the format [hypotheses, goal, proof]. Run,
for example, from the archive root:

    python3 checker.py examples/residual.json

Every listed file is checked by validation/run.py and is a selected copy from
the deduplicated validation corpus. index.json links it to the corpus hash
and its archived source label. All terms and logical abbreviations are fully
expanded in the actual JSON; the mathematical notation below is defined in
the accompanying report.

Arithmetic and equality:

  reflexivity.json                    Universal numerical reflexivity.
  successor_injective.json            Successor injectivity.
  zero_plus_n.json                    0 + n = n, by equation induction.
  successor_plus_n.json               Successor and addition identity.
  residual.json                       C(d(y,n),y,n+d(y,n)) = y.
  equality_detector_to_equality.json  epsilon(s,t)=0 implies s=t.
  equality_to_detector.json           s=t implies epsilon(s,t)=0.
  parameter_induction.json            Equation induction with a retained parameter.
  numerical_coverage.json             Zero/successor coverage in the native expansion.

Dependent logic and equality transport:

  forall_exists_successor.json        A dependent universal/existential statement.
  dependent_universal_introduction.json  Guarded universal introduction.
  dependent_existential_elimination.json Dependent existential elimination.
  nested_equality_transport.json      Transport through nested binders and recursors.
  explosion_quantified.json           Contradiction elimination with quantified target.

Derived conjunction and disjunction:

  conjunction_introduction.json       A,B entail the expanded conjunction.
  conjunction_left.json               Its left projection.
  conjunction_right.json              Its right projection.
  disjunction_left.json               Left inclusion into the expanded disjunction.
  disjunction_right.json              Right inclusion into the expanded disjunction.
  disjunction_elimination.json        Elimination with retained assumptions.

Implication is the vacuous-number instance of guarded universal quantification;
its introduction and elimination appear throughout these certificates. The
conjunction/disjunction examples include quantified operands. They validate
the concrete expansions used by the archived mathematical development, rather
than adding primitive conjunction or disjunction rules to checker.py.
