A factored proof calculus for iPRA
================================
Prepared for Vladimir Reshetnikov, 6 November 2026 (Pacific time).

Result
------
The complete checker has 642 executable AST nodes, 603 normalized significant
tokens, and 2,020 normalized source bytes. The current ProveIt draft frontier
is 675 nodes, 634 tokens, and 2,053 normalized bytes. A structural composition
control already beats that frontier (663 / 619 / 2,038).

The mathematical arithmetic basis is inherited from the six current drafts.
This iteration supplies a smaller complete proof presentation and acceptance
program, a self-contained mathematical account, and reproducible evidence.
It does not claim a globally smallest possible axiomatization.

The theory is full first-order intuitionistic primitive recursive arithmetic,
not just its quantifier-free fragment. The paper specifies every primitive
logical and nonlogical rule, reconstructs the remaining logical connectives,
proves quantifier-free induction, and establishes bi-interpretability through
an ordinary full-domain realization whose internal round-trip isomorphisms
are equality. Equiconsistency follows. These metatheorems are mathematical
proofs in the paper, not Lean or Rocq formalizations.

Files
-----
report.pdf                  Compiled self-contained mathematical article.
report.tex, sections/       Complete LaTeX sources.
checker.py                  Entire acceptance program; no project imports.
examples/                   Selected executable mathematical certificates.
validation/                 Proof translations, named-variable oracle,
                            provenance, corpus, and focused boundary checks.
comparison/current/         Exact six current checker sources.
comparison/nested_sources/  Exact 194 distinct historical candidate modules.
comparison/manifest.json    Immutable archive paths, Git blob and SHA-256 IDs.
results/                    Recorded measurements and validation results.
MANIFEST.sha256             File integrity manifest for the final archive.

The source snapshot is:
https://github.com/VladimirReshetnikov/ProveIt/tree/0a86fcbd7c5e0d6a541291b4ac06c7dc77989161/docs/drafts

Usage
-----
Python 3.10 or later is required for structural matching and strict zip.
The recorded measurements use CPython 3.12.14. No third-party Python package
is required by checker.py or the reproduction scripts.

Run an individual certificate:

    python3 checker.py examples/successor_injective.json

Run the complete offline comparison and certificate validation:

    python3 reproduce.py

Optional verification against the six original downloaded draft archives:

    python3 reproduce.py --archives-dir /path/to/ProveIt/docs/drafts

Compile the paper using a local LaTeX installation:

    python3 build.py

Or run both verification and PDF compilation:

    python3 reproduce.py --build

The document uses ordinary TeX Live packages: Latin Modern, microtype,
geometry, AMS mathematics, mathtools, booktabs, array, longtable, tabularx,
xcolor, listings, enumitem, fancyhdr, and hyperref. It does not require shell
escape, downloaded fonts, or network access. python3 package.py rebuilds the
archive and refreshes its SHA-256 manifest.

Certificate contract
--------------------
JSON input is [hypotheses, goal, proof]. Numerical zero is -1; nonnegative
integer term leaves are de Bruijn variable indices. Proof integers index
the hypothesis list, and negative/Boolean proof indices are permitted aliases
for actual list entries. Boolean and floating-point term leaves are forbidden.

The three local constructors are lam, pack, and nat. A recursor term is its
own computation certificate. Application has no 'use' marker: its major
premise determines equality, universal, or existential elimination. The
paper and FORMAT.txt give the complete encoding.

check(g, a, p) returns normally on success and raises an exception on failure.
The CLI prints ACCEPT with exit status 0 or REJECT with status 1. Checks
remain active under python -O. No proof generators or validators participate
in acceptance. Python stack/memory limits can reject very large valid trees;
the mathematical completeness proof is for the ideal recursive algorithm.

Scope of the size claim
-----------------------
All syntax, substitution, rules, I/O, and error handling are counted. The
common Python/json/sys runtime is outside every application-specific count.
The documented new source is larger in raw bytes (2,488 versus 2,205) but
smaller in all three claimed structural/normalized measures. The measures
remove genuine docstrings, comments, and layout consistently, retaining
executable string data and tables. See comparison/README.txt for definitions.

Attribution
-----------
The native arithmetic calculus, formula selector, equality detector, and
bi-interpretation strategy come from the preceding ProveIt draft series.
Frozen comparison sources and adapted validation machinery are identified
by exact paths and hashes. The GitHub repository is distributed under MIT-0
unless a nested license says otherwise. See SOURCES.txt for details.
