"""Reproduce the complete-program comparison without executing compared sources.

Run from any directory with Python 3.11 or later:
    python3 comparison/measure.py
Optionally recheck all original archive bytes:
    python3 comparison/measure.py --archives-dir /path/to/ProveIt/docs/drafts

Outputs are results/metrics.json, results/metrics_table.tex,
results/metrics_numbers.tex, and comparison/numbers.tex. The report may
input either numbers file; they have identical contents.
The Python runtime is recorded because AST normalization is version-dependent.
"""

import argparse
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize
import zipfile


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FIELDS = ("source_tokens", "normalized_tokens", "ast_nodes",
          "normalized_bytes", "raw_bytes", "raw_lines")
PRIMARY = ("normalized_tokens", "ast_nodes", "normalized_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}
DOC_OWNERS = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def real_docstrings(tree):
    """Only the leading string expression of a genuine docstring owner."""
    for node in ast.walk(tree):
        if isinstance(node, DOC_OWNERS) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr)
                    and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                yield first


def source_position(lines, lineno, byte_column):
    # AST columns are UTF-8 byte offsets; tokenizer columns count characters.
    prefix = lines[lineno - 1].encode("utf-8")[:byte_column]
    return lineno, len(prefix.decode("utf-8"))


def token_count(source, omitted=()):
    return sum(token.type not in IGNORED and not any(
        start <= token.start and token.end <= end for start, end in omitted
    ) for token in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(data):
    source = data.decode("utf-8")
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    spans = [
        (source_position(lines, node.lineno, node.col_offset),
         source_position(lines, node.end_lineno, node.end_col_offset))
        for node in real_docstrings(tree)
    ]
    stripped = copy.deepcopy(tree)
    removed = {id(node) for node in real_docstrings(stripped)}
    for node in ast.walk(stripped):
        if isinstance(node, DOC_OWNERS):
            node.body = [child for child in node.body if id(child) not in removed]
    normalized = ast.unparse(stripped) + "\n"
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append("." * node.level + (node.module or ""))
    return {
        "sha256": sha256(data),
        "normalized_sha256": sha256(normalized.encode("utf-8")),
        "source_tokens": token_count(source, spans),
        "normalized_tokens": token_count(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(stripped)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(data),
        "raw_lines": len(source.splitlines()),
        "all_imports": sorted(set(imports)),
    }


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def verified_bytes(path, expected):
    data = path.read_bytes()
    if sha256(data) != expected:
        raise ValueError("Frozen source hash mismatch: " + str(path))
    return data


def verify_archives(directory, manifest, inventory):
    """Recompute the source census directly from the six supplied ZIPs."""
    occurrences = []
    python_members = 0
    for record in manifest["archives"]:
        path = directory / Path(record["archive_path"]).name
        data = verified_bytes(path, record["archive_sha256"])
        blob = hashlib.sha1(b"blob " + str(len(data)).encode("ascii")
                            + b"\0" + data).hexdigest()
        if blob != record["archive_git_blob_sha1"]:
            raise ValueError("Git blob mismatch: " + str(path))
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            checker = archive.read(record["checker_member"])
            if checker != (HERE / record["frozen_checker"]).read_bytes():
                raise ValueError("Checker/archive mismatch: " + str(path))
            for member in sorted(archive.namelist()):
                if not member.endswith(".py"):
                    continue
                python_members += 1
                payload = archive.read(member)
                tree = ast.parse(payload.decode("utf-8"))
                definitions = {node.name for node in tree.body
                               if isinstance(node, (ast.FunctionDef,
                                                    ast.AsyncFunctionDef))}
                if {"infer", "check"} <= definitions:
                    occurrences.append({
                        "archive_path": record["archive_path"],
                        "member_path": member,
                        "sha256": sha256(payload),
                        "bytes": len(payload),
                    })
    occurrences.sort(key=lambda row: (row["archive_path"], row["member_path"]))
    if (occurrences != inventory["occurrences"]
            or python_members != inventory["python_member_count"]):
        raise ValueError("Original ZIP census does not match the frozen inventory")
    return {"archive_hashes_and_git_blobs": "verified",
            "all_python_members": python_members,
            "selected_occurrences": len(occurrences)}


def tex_escape(value):
    replacements = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%",
                    "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{",
                    "}": r"\}", "~": r"\textasciitilde{}",
                    "^": r"\textasciicircum{}"}
    return "".join(replacements.get(char, char) for char in str(value))


def write_tex(result):
    rows = [r"% Generated by comparison/measure.py; requires booktabs.",
            r"\begin{tabular}{@{}lrrrr@{}}", r"\toprule",
            r"Complete program & Tokens & AST nodes & Norm. bytes & Raw bytes \\",
            r"\midrule"]
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes", "raw_bytes")
    def append(label, values, bold=False):
        cells = [tex_escape(label)] + [f"{values[key]:,}" for key in fields]
        if bold:
            cells = [r"\textbf{" + cell + "}" for cell in cells]
        rows.append(" & ".join(cells) + r" \\")
    for record in result["current"]:
        append(record["label"], record)
    rows.append(r"\midrule")
    append("Observed lower envelope", result["combined_envelope"])
    if result["structural_control"] is not None:
        append("Structural composition only", result["structural_control"])
    if result["candidate"] is not None:
        append("Factored kernel", result["candidate"], True)
    rows.extend([r"\bottomrule", r"\end{tabular}", ""])
    (ROOT / "results" / "metrics_table.tex").write_text("\n".join(rows),
                                                            encoding="utf-8")
    names = {"source_tokens": "SourceTokens", "normalized_tokens": "Tokens",
             "ast_nodes": "AST", "normalized_bytes": "Bytes",
             "raw_bytes": "RawBytes", "raw_lines": "Lines"}
    macros = {"ComparedArchiveCount": len(result["current"]),
              "NestedOccurrences": result["nested_occurrence_count"],
              "NestedUnique": result["nested_unique_count"],
              "PythonMemberCount": result["python_member_count"]}
    for field, name in names.items():
        macros["Old" + name] = result["combined_envelope"][field]
        if result["candidate"] is not None:
            macros["New" + name] = result["candidate"][field]
        if result["structural_control"] is not None:
            macros["Control" + name] = result["structural_control"][field]
    lines = ["% Generated by comparison/measure.py."]
    lines += ["\\newcommand{\\" + name + "}{" + str(value) + "}"
              for name, value in macros.items()]
    numbers = "\n".join(lines) + "\n"
    (HERE / "numbers.tex").write_text(numbers, encoding="utf-8")
    (ROOT / "results" / "metrics_numbers.tex").write_text(numbers, encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=ROOT / "checker.py")
    parser.add_argument("--archives-dir", type=Path)
    args = parser.parse_args()
    manifest = json.loads((HERE / "manifest.json").read_text(encoding="utf-8"))
    inventory = json.loads((HERE / "nested_inventory.json").read_text(encoding="utf-8"))
    current = []
    for entry in manifest["archives"]:
        data = verified_bytes(HERE / entry["frozen_checker"], entry["checker_sha256"])
        current.append({"label": entry["label"],
                        "frozen_checker": entry["frozen_checker"], **measure(data)})
    nested = []
    for entry in inventory["sources"]:
        data = verified_bytes(HERE / entry["frozen_source"], entry["sha256"])
        nested.append({"frozen_source": entry["frozen_source"],
                       "occurrence_count": entry["occurrence_count"], **measure(data)})
    candidate = measure(args.candidate.read_bytes()) if args.candidate.exists() else None
    control_path = HERE / "structural_control.py"
    control = measure(control_path.read_bytes()) if control_path.exists() else None
    combined = envelope(current + nested)
    result = {
        "schema_version": 1, "commit": manifest["commit"],
        "runtime": {"implementation": platform.python_implementation(),
                    "version": platform.python_version(),
                    "full_version": sys.version,
                    "platform": platform.platform()},
        "policy": manifest["measurement_policy"],
        "current": current, "current_envelope": envelope(current),
        "nested": nested, "nested_envelope": envelope(nested),
        "combined_envelope": combined, "candidate": candidate,
        "structural_control": control,
        "python_member_count": inventory["python_member_count"],
        "nested_occurrence_count": inventory["occurrence_count"],
        "nested_unique_count": inventory["unique_count"],
        "all_frozen_source_hashes": "verified",
        "original_archives": verify_archives(args.archives_dir, manifest, inventory)
                             if args.archives_dir else "not supplied; frozen sources verified",
        "strictly_below_primary_envelope":
            {field: candidate[field] < combined[field] for field in PRIMARY}
            if candidate is not None else None,
        "control_strictly_below_primary_envelope":
            {field: control[field] < combined[field] for field in PRIMARY}
            if control is not None else None,
        "minimum_witnesses": {
            field: [row["frozen_source"] for row in nested if row[field] == combined[field]]
            for field in FIELDS
        },
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results" / "metrics.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_tex(result)
    print(json.dumps({"current_programs": len(current),
                      "nested_source_occurrences": inventory["occurrence_count"],
                      "nested_unique_sources": len(nested),
                      "envelope": combined,
                      "candidate": {field: candidate[field] for field in FIELDS}
                                   if candidate is not None else None,
                      "structural_control": {field: control[field] for field in FIELDS}
                                            if control is not None else None,
                      "strictly_below_primary_envelope":
                          result["strictly_below_primary_envelope"]}, indent=2))


if __name__ == "__main__":
    main()
