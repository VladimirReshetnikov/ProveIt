"""Check the new measurer against recorded prior results and docstring cases."""

import hashlib
import json
from pathlib import Path
import platform

import measure


ROOT = Path(__file__).resolve().parent.parent
FIELDS = ("source_tokens", "normalized_tokens", "ast_nodes",
          "normalized_bytes", "raw_bytes", "raw_lines")


def main():
    previous = json.loads((ROOT / "comparison" / "baseline_checker_inventory.json")
                          .read_text(encoding="utf-8"))
    previous = {row["sha256"]: row for row in previous["unique"]}
    inventory = json.loads((ROOT / "comparison" / "nested_inventory.json")
                           .read_text(encoding="utf-8"))
    checks = 0
    for record in inventory["sources"]:
        data = (ROOT / "comparison" / record["frozen_source"]).read_bytes()
        current = measure.measure(data)
        old = previous[record["sha256"]]
        for field in FIELDS:
            if current[field] != old[field]:
                raise ValueError((record["sha256"], field, current[field], old[field]))
            checks += 1
    pairs = [
        ('"""module é😀"""\nx = "data"\n', 'x = "data"\n'),
        ('def f():\n    "function"\n    return "value"\n',
         'def f():\n    return "value"\n'),
        ('class C:\n    "class"\n    x="data"\n',
         'class C:\n    x="data"\n'),
        ('async def f():\n    "async"\n    return 1\n',
         'async def f():\n    return 1\n'),
    ]
    for with_docstring, without in pairs:
        first = measure.measure(with_docstring.encode("utf-8"))
        second = measure.measure(without.encode("utf-8"))
        for field in FIELDS[:4]:
            if first[field] != second[field]:
                raise ValueError((with_docstring, field, first[field], second[field]))
            checks += 1
    used = measure.measure(b'x="data"\n')
    shorter = measure.measure(b'x=0\n')
    if used["normalized_bytes"] <= shorter["normalized_bytes"]:
        raise ValueError("String data were incorrectly removed")
    checks += 1
    result = {
        "python_version": platform.python_version(),
        "recorded_legacy_measurement_crosscheck": {
            "unique_sources": len(inventory["sources"]),
            "fields_per_source": len(FIELDS), "all_equal": True,
        },
        "real_docstring_tests": len(pairs),
        "non_docstring_data_retained": True,
        "total_assertions": checks,
        "source_sha256": hashlib.sha256(Path(measure.__file__).read_bytes()).hexdigest(),
    }
    (ROOT / "results" / "metrics_verification.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
