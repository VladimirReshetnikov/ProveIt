"""Explicit independent interpreter of the direct-step certificate rules.

This interpreter deliberately keeps the rules separate. Its substitutions
resolve binders to fresh names through named_syntax, independently of the
candidate's scope table and de Bruijn substitution. No candidate is imported.
Only finite JSON values are part of the certificate interface.
"""

from collections import Counter
from named_syntax import oracle, valid


def require(value):
    if not value:
        raise ValueError("independent rule check failed")


def validate(expression, formula=True):
    require(valid(expression, formula))
    return expression


def infer(proof, context, counts=None):
    if counts is None:
        counts = Counter()
    if type(proof) in (int, bool):
        require(-len(context) <= proof < len(context))
        counts["hypothesis"] += 1
        return context[proof]
    require(type(proof) is list and len(proof) > 0)
    tag = proof[0]
    if tag == "lam":
        require(len(proof) == 3)
        guard = validate(proof[1])
        local = [oracle(a) for a in context] + [guard]
        body = infer(proof[2], local, counts)
        counts["universal_introduction"] += 1
        return ["pi", guard, body]
    if tag == "pack":
        require(len(proof) == 3)
        witness = validate(proof[1], False)
        guard = ["=", 0, oracle(witness, formula=False)]
        local = [oracle(a) for a in context] + [guard]
        body = infer(proof[2], local, counts)
        counts["existential_introduction"] += 1
        return ["ex", body]
    if tag == "nat":
        require(len(proof) == 3)
        matrix = validate(proof[1])
        base = oracle(matrix, [-1, 0])
        guard = matrix if matrix[0] == "=" else base
        local = [oracle(a) for a in context] + [guard]
        body = infer(proof[2], local, counts)
        require(body == oracle(matrix, [["s", 0], 0]))
        counts["equation_induction" if matrix[0] == "=" else "numerical_cases"] += 1
        return ["pi", base, matrix]
    if tag == "use":
        require(len(proof) >= 2)
        principal = infer(proof[1], context, counts)
        if principal[0] == "ex":
            require(len(proof) == 3)
            local = [oracle(a) for a in context] + [principal[1]]
            branch = infer(proof[2], local, counts)
            result = oracle(branch, [None, -1])
            counts["existential_elimination"] += 1
            return result
        require(len(proof) == 4)
        if principal[0] == "pi":
            witness = validate(proof[2], False)
            antecedent = oracle(principal[1], [witness, -1])
            result = oracle(principal[2], [witness, -1])
            counts["universal_elimination"] += 1
        else:
            require(principal[0] == "=")
            template = validate(proof[2])
            antecedent = oracle(template, [principal[1], -1])
            result = oracle(template, [principal[2], -1])
            counts["equality_transport"] += 1
        require(infer(proof[3], context, counts) == antecedent)
        return result
    if tag == "r":
        validate(proof, False)
        counter, initial, update = proof[1:]
        if counter == -1:
            result = initial
            counts["recursion_zero"] += 1
        else:
            require(type(counter) is list and len(counter) == 2 and counter[0] == "s")
            predecessor = counter[1]
            result = oracle(update, [["r", predecessor, initial, update], predecessor, -2], formula=False)
            counts["recursion_successor"] += 1
        return ["=", proof, result]
    raise ValueError("unknown certificate rule")


def check(data):
    require(type(data) is list and len(data) == 3)
    context, conclusion, proof = data
    require(type(context) is list)
    for formula in context + [conclusion]:
        validate(formula)
    counts = Counter()
    require(infer(proof, context, counts) == conclusion)
    return counts
