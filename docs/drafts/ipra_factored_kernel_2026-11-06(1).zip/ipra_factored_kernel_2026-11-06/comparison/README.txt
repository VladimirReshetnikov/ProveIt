Reproducible complete-checker comparison
======================================

Source snapshot
---------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 0a86fcbd7c5e0d6a541291b4ac06c7dc77989161
Directory: docs/drafts

manifest.json records all six current archive names, their Git blob SHA-1
identifiers from the pinned Git tree, their SHA-256 checksums, and the exact
top-level checker member paths and SHA-256 checksums. The archive bytes were
hashed as Git blobs and matched against that tree before these files were
prepared. current/ contains byte-exact copies of the six top-level checkers.

Run from the package root:

    python3 comparison/measure.py
    python3 comparison/verify_measurement.py

The first command verifies every frozen source hash and recomputes the entire
comparison without executing any compared source. It measures the current
checker.py and, if present, comparison/structural_control.py. The second
cross-checks all 194 distinct historical candidate modules against the
independently recorded earlier census, and tests genuine docstring handling.

If the six original ZIPs are available, the following optional command also
recomputes their Git blob hashes and independently rebuilds the census from
the ZIP members:

    python3 comparison/measure.py --archives-dir /path/to/ProveIt/docs/drafts

All six originals were supplied for the recorded run in results/metrics.json.
The archive files themselves are not duplicated in this package.

Accounting boundary
-------------------
Each primary row counts one complete standalone acceptance program: formation,
substitution, numerical and logical inference, input validation, and CLI.
Only the shared Python runtime and standard json/sys modules are outside the
application-specific count. No code generator or translator is imported by
these programs. Explanatory comments and genuine docstrings are excluded
from normalized measurements; executable tables and string data are counted.

Source tokens exclude comments, layout/newline markers, and real docstrings.
Normalized tokens apply the same token count to ast.unparse of the AST after
removing real docstrings. AST nodes count every ast.walk occurrence in that
stripped tree. Normalized bytes are UTF-8 bytes of ast.unparse plus one final
newline. Raw bytes include all comments and formatting. Normalization may
depend on the Python version; the complete runtime version is recorded.

The new checker is larger in raw bytes because its source includes explanatory
documentation. The asserted strict reduction is in normalized tokens, AST
nodes, and normalized bytes. Source formatting is not a mathematical reduction.

The structural control uses the composed structural reductions with the
explicit require helper retained. It already lies below all three primary
baseline minima. The final checker additionally omits the use marker,
inlines the named ZERO sentinel, and uses direct conditional rejection
guards; this additional programming representation saving is
reported separately, rather than attributed to the mathematical theory.

Census and nested comparisons
-----------------------------
The six archives contain 1,042 Python members. Independently parsing each ZIP
member gives 874 occurrences of modules with top-level infer and check
functions, representing 194 distinct byte strings. Every distinct candidate
is copied exactly once into nested_sources/ under its SHA-256 filename.
nested_inventory.json lists every source occurrence, the grouping by checksum,
and the exact frozen paths. all_python_members.json is a sorted inventory of
all Python members, including the unselected modules and their function names.

This census includes old controls, alternative checkers, and ablations. It is
a conservative program inventory, not a claim that every module is a sound or
complete standalone proof checker. Some modules use extra dependencies. Their
individual source measurements do not improve any current primary minimum,
so there is no need to omit them or infer their validity to establish the
comparison. Their complete dependency-accounted implementations could only
add application-specific material under the stated additive boundary.

The separately preserved baseline_checker_inventory.json is the earlier
substring-based census: 875 occurrences and 195 distinct strings. Its one
false positive is uniform_kernel/validation/build_cases.py, a generator that
contains infer/check source in a string. The independent AST census excludes
that generator; its exclusion does not change any minimum. All 194 retained
sources agree with the previous measurement in all six numeric fields under
the recorded runtime.

The exact finite lower envelope is:

    normalized tokens: 634
    AST nodes:         675
    normalized bytes: 2,053
    source tokens:     636
    raw bytes:        2,205

The individual minimizers need not be the same program. metrics.json includes
the hashes and paths witnessing every minimum. No absolute minimality claim
over all possible theories, languages, encodings, or checkers is made.

Generated outputs
-----------------
results/metrics.json              Full machine-readable results and runtime.
results/metrics_table.tex         Publication table including the control.
results/metrics_numbers.tex       Macros, including NewAST/NewTokens/NewBytes,
                                 OldAST/OldTokens/OldBytes, and Control*.
comparison/numbers.tex            Identical macro file for convenient input.
results/metrics_verification.json Recorded comparison cross-checks.

The comparison files and measurement programs are supporting evidence, not
trusted dependencies of checker.py.
