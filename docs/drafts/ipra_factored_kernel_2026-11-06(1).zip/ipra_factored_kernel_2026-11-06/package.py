"""Refresh the SHA-256 manifest and create a ZIP with all deliverables."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
IGNORED = {"__pycache__", "build", "rendered", ".git"}
EXCLUDED = {".aux", ".log", ".out", ".toc", ".fdb_latexmk", ".fls", ".pyc"}
files = sorted(p for p in ROOT.rglob("*")
               if p.is_file() and not any(q in IGNORED for q in p.relative_to(ROOT).parts)
               and p.suffix not in EXCLUDED and p.name != "MANIFEST.sha256")
manifest = ROOT / "MANIFEST.sha256"
manifest.write_text("".join(
    hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.relative_to(ROOT).as_posix() + "\n"
    for p in files), encoding="utf-8")
archive = ROOT.parent / (ROOT.name + ".zip")
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for p in sorted([*files, manifest]):
        output.write(p, arcname=(Path(ROOT.name) / p.relative_to(ROOT)).as_posix())
print(archive)
print(f"{len(files) + 1} files; {archive.stat().st_size:,} bytes")
