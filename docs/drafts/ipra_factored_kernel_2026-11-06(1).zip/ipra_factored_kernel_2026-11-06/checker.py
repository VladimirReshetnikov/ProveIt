"""Complete iPRA checker with shared scope transitions.

Input is [hypotheses, goal, proof]. Inference validates all statement syntax.
check(*data) returns normally on acceptance and raises on rejection.
The CLI prints ACCEPT or REJECT and exits with status 0 or 1.
Zero is the integer -1; nonnegative integers denote de Bruijn variables.
Application has no command tag; fixed constructors are matched first.
"""
import json
import sys


SCOPES = ({'s': (0,), 'r': (0, 0, 2)},
          {'=': (0, 0), 'pi': (1, 1), 'ex': (1,)})


def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int:
        if formula or a < -1:
            raise ValueError
        i = a - d
        return a if i < 0 else subst(env[i], (d,), formula=False) if i < len(env) - 1 else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1)
                   for b, width in zip(args, SCOPES[formula][tag], strict=True))]


def infer(p, g):
    match p:
        case ['lam' | 'pack' | 'nat' as tag, a, q]:
            if tag == 'pack':
                a = ['=', 0, subst(a, formula=False)]
            base = subst(a, [-1, 0] if tag == 'nat' else (0,))
            b = infer(q, [*map(subst, g), a if a[0] == '=' else base])
            if tag == 'nat':
                if b != subst(a, [['s', 0], 0]):
                    raise ValueError
                b = a
            return ['ex', b] if tag == 'pack' else ['pi', base, b]
        case ['r', n, a, h] as r:
            subst(r, formula=False)
            if n == -1:
                b = a
            else:
                _, n = n
                b = subst(h, [['r', n, a, h], n, -2], formula=False)
            return ['=', r, b]
        case [p, *args]:
            tag, *parts = infer(p, g)
            if tag == 'ex':
                return subst(infer(*args, [*map(subst, g), *parts]), [None, -1])
            a, q = args
            b, c = (subst(a, [t, -1]) if tag == '=' else subst(t, [a, -1])
                    for t in parts)
            if infer(q, g) != b:
                raise ValueError
            return c
        case _:
            return g[p]


def check(g, a, p):
    for b in g + [a]:
        subst(b)
    if infer(p, g) != a:
        raise ValueError

if __name__ == '__main__':
    try:
        _, path = sys.argv
        with open(path, encoding='utf-8') as stream:
            check(*json.load(stream))
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
