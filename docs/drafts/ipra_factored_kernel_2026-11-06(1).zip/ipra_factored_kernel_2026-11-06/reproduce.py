"""Recompute the comparison and certificate checks; optionally build the PDF."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--build", action="store_true", help="also compile report.tex")
parser.add_argument("--archives-dir", help="optionally verify the six original ZIP archives")
args = parser.parse_args()
measurement = [sys.executable, "comparison/measure.py"]
if args.archives_dir:
    measurement += ["--archives-dir", str(Path(args.archives_dir).resolve())]
for command in [measurement,
                [sys.executable, "comparison/verify_measurement.py"],
                [sys.executable, "validation/run.py"]]:
    subprocess.run(command, cwd=ROOT, check=True)
if args.build:
    subprocess.run([sys.executable, "build.py"], cwd=ROOT, check=True)
print("All requested reproduction steps completed.")
