"""Compile the accompanying LaTeX article without network access."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / "build"
BUILD.mkdir(exist_ok=True)
if shutil.which("latexmk"):
    subprocess.run([
        "latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
        "-file-line-error", "-outdir=" + str(BUILD), "report.tex"
    ], cwd=ROOT, check=True)
else:
    for _ in range(3):
        subprocess.run([
            "pdflatex", "-interaction=nonstopmode", "-halt-on-error",
            "-file-line-error", "-output-directory=" + str(BUILD), "report.tex"
        ], cwd=ROOT, check=True)
shutil.copyfile(BUILD / "report.pdf", ROOT / "report.pdf")
print("Built report.pdf")
