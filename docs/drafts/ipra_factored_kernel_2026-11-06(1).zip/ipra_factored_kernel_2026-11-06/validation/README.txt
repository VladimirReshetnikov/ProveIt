FOCUSED OFFLINE VALIDATION

From the archive root run:

    python3 validation/run.py

Python 3.10 or newer and its standard library are sufficient. The recorded
run used Python 3.12.14. No network, external repository, proof generator, or
material from the development workspace is required.

The runner writes results/validation.json. It first verifies the exact
SHA-256 identities of checker.py and both complete frozen comparison
programs. Validation helpers are untrusted support and are never imported
by checker.py. Passing these checks is finite implementation evidence; the
mathematical correctness and bi-interpretation proofs are in the report.
The metatheory has not been formalized in a proof assistant.

WHAT THE RUN ESTABLISHES

1. A deduplicated frozen corpus contains 256 certificates: 194 acceptances
   and 62 rejections. These reproduce every one of the 193 distinct accepted
   certificates found under the archived shared-transition checker and all
   150 under the archived scoped-rules checker. Their union has 194 members;
   those two source totals must not be added as independent cases. The one
   extra scoped-rules certificate is equation-only numerical coverage.

2. Every accepted corpus certificate, and all 20 positive focused cases,
   is converted to a tagged proof with explicit valid witnesses. The exact
   archived shared-transition program, the exact strict scoped-rules
   program, and the independently written explicit-rule interpreter all
   accept the reconstructed proof. Its context and conclusion are unchanged.
   All 62 corpus rejections and 22 focused rejections are independently
   rejected as well.

3. The 42 focused cases address hypothesis selectors, fixed-constructor
   precedence, dependent retained assumptions, existential eigenvariable
   escape, nested binders and recursor update scopes, simultaneous recursion
   substitution, strict checking of discarded recursor bodies and existential
   witnesses, and the boundary between equation induction and general cases.

4. Substitution is compared with a fresh-named-variable oracle in 480
   cases on a fixed expression suite at four depths. Eighty partial scope
   deletions and eighty lift/delete round trips are checked separately.
   Eighty-eight grammar comparisons and eighty-two malformed statement
   boundary checks exercise the finite syntax contract. These are operation
   checks, not claims of hundreds of independent mathematical theorems.

5. Twenty curated theorem certificates in examples/ are accepted. Eleven
   command-line cases run in normal Python and the same eleven under -O.
   They cover valid and false claims, malformed JSON, input shape, numerical
   syntax, documented Boolean selectors, unused witness payloads, and
   missing/extra file arguments.

CORPUS PROVENANCE

corpus_index.json records each new certificate's bytes hash and its exact
source archive member(s), source bytes hash(es), and canonical source data
hash. The snapshot is 0a86fcbd7c5e0d6a541291b4ac06c7dc77989161. Duplicate
source appearances are provenance only. Literal inverse translation restores
the original tagged JSON value and checks its canonical hash before replay.
Source archives and original comparison programs are identified in
comparison/manifest.json. Raw source-byte hashes require those archives to
recheck; the local canonical hashes and all executable replays are verified
offline by this bundle.

CERTIFICATE TRANSLATION

    python3 validation/translate.py forward old.json new.json
    python3 validation/translate.py reverse new.json restored.json

Forward translation erases only the application command tag "use". It does
not traverse or alter object-language terms, formulas, or witness payloads.
Fixed proof constructors remain lam, pack, nat, and r. Reverse translation
reinserts application tags, converts valid negative or Boolean hypothesis
selectors to nonnegative integer selectors, and replaces every unused
universal witness payload by numerical zero (-1 in the encoding). A used
witness is preserved and must be a valid term. The occurrence decision uses
independently named binders, including both recursor-local variables.

An ignored witness payload has no object-language meaning. Its acceptance
is justified by reconstruction at zero, not by admitting malformed terms.
Statements, used witnesses, existential introduction witnesses, complete
recursor terms, and equality motives retain strict syntax checking.

INDEPENDENCE AND LIMITS

named_syntax.py and rule_oracle.py are exact archived validators. They
separate all inference rules and use fresh binder identities instead of the
candidate's scoped de Bruijn substitution table. translate.py uses that
oracle for reconstruction, never the candidate substitution routine.
reference.py loads the frozen complete programs only after checking hashes.
run.py and targeted.py supply the new integration and focused fixtures.

The candidate and its ancestors share a mathematical basis, so replay alone
would not exclude an inherited conceptual error. The report supplies the
mathematical proofs, and the independent oracle provides a separate finite
implementation check. No result here proves absolute minimality or replaces
a proof-assistant verification of soundness.
