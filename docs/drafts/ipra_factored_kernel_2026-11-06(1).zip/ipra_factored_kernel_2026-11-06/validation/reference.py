"""Load frozen complete comparison checkers; no code here is trusted by checker.py."""
import hashlib
import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FROZEN = {
    'candidate': ('checker.py', '4e3febd350581e62cc9ec4cd70f919f849b8504941800c1f987c5a0bb14fc565'),
    'shared': ('comparison/current/05_shared_transition.py', '85fdff0eade03c0c74e864a083f4ee2ecea79b78a8a64656c16cfc0d958f40f2'),
    'strict': ('comparison/current/04_scoped_rules.py', '21204fe46d0677f27f5ee1737d6659dbecf2bdbea201a9710fff7d7821cafe8e'),
}


def load(label):
    relative, expected = FROZEN[label]
    path = ROOT / relative
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError('Frozen source changed: ' + relative)
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location('frozen_' + label, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
