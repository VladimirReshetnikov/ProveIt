"""Focused binding and rule-boundary fixtures, independent of checker.py.

The designs are adapted from the pinned shared-transition independent audit.
Expected statements are constructed with the separately named syntax oracle.
No test uses the candidate substitution operation to manufacture its answer.
"""
from named_syntax import oracle
from translate import from_tagged

ZERO = -1
ONE = ['s', ZERO]
TRUE = ['=', ZERO, ZERO]
FALSE = ['=', ZERO, ONE]


def reflexivity(term):
    equation = ['r', ZERO, term, ZERO]
    return ['use', equation, ['=', 0, oracle(term, formula=False)], equation]


def cases():
    out = []
    def add(name, data, expected, group):
        out.append({'name': name, 'data': from_tagged(data), 'expected': expected, 'group': group})
    add('literal_hypothesis', [[TRUE], TRUE, 0], True, 'selectors')
    add('negative_hypothesis', [[FALSE, TRUE], TRUE, -1], True, 'selectors')
    add('boolean_hypothesis', [[FALSE, TRUE], TRUE, True], True, 'selectors')
    add('floating_hypothesis_rejected', [[TRUE], TRUE, 0.0], False, 'selectors')
    add('out_of_range_hypothesis', [[TRUE], TRUE, 1], False, 'selectors')
    add('empty_context_falsity', [[], FALSE, 0], False, 'selectors')
    add('parameter_reflexivity', [[], ['=', 0, 0], reflexivity(0)], True, 'dispatch')
    rec = ['r', ZERO, ZERO, ZERO]
    add('recursor_before_generic_application', [[], ['=', rec, ZERO], rec], True, 'dispatch')
    add('universal_parameter_lift', [[['=', 0, ZERO]], ['pi', TRUE, ['=', 1, ZERO]],
                                     ['lam', TRUE, 0]], True, 'binding')
    add('universal_capture_rejected', [[['=', 0, ZERO]], ['pi', TRUE, ['=', 0, ZERO]],
                                     ['lam', TRUE, 0]], False, 'binding')
    add('existential_parameter_lift', [[], ['ex', ['=', 0, 1]], ['pack', 0, -1]], True, 'binding')
    add('existential_parameter_capture', [[], ['ex', ['=', 0, 0]], ['pack', 0, -1]], False, 'binding')
    ex = ['ex', ['=', 0, ZERO]]
    add('eigenvariable_escape', [[ex], TRUE, ['use', 0, -1]], False, 'binding')
    add('old_parameter_survives_elimination', [[ex, ['=', 0, ZERO]], ['=', 0, ZERO], ['use', 0, 1]], True, 'binding')
    bodies = [
        ['pi', TRUE, ['=', 1, ZERO]],
        ['ex', ['=', 1, ZERO]],
        ['=', ['r', ZERO, ZERO, 2], ZERO],
        ['ex', ['=', ['r', ZERO, ZERO, 3], ZERO]],
        ['pi', ['=', 1, ZERO], TRUE],
    ]
    for index, body in enumerate(bodies):
        add('nested_escape_' + str(index), [[['ex', body]], oracle(body, [ZERO, -1]), ['use', 0, -1]],
            False, 'binding')
        add('nested_old_parameter_' + str(index), [[['ex', oracle(body)]], body, ['use', 0, -1]],
            True, 'binding')
    old = ['r', 2, 1, ['r', 1, 0, ['s', 2]]]
    rec = ['r', ['s', 2], 1, ['r', 1, 0, ['s', 2]]]
    lifted_old = ['r', 4, 3, ['r', 1, 0, ['s', 2]]]
    updated = ['r', 2, old, ['s', lifted_old]]
    add('simultaneous_recursion_binding', [[], ['=', rec, updated], rec], True, 'recursion')
    for number in (0, ['r', ZERO, ZERO, ZERO]):
        rec = ['r', number, ZERO, ZERO]
        add('nonconstructor_counter_' + str(number), [[], ['=', rec, ZERO], rec], False, 'recursion')
    for index, bad in enumerate((None, True, TRUE)):
        malformed = ['r', ZERO, ZERO, bad]
        add('invalid_discarded_update_' + str(index), [[], TRUE, ['use', malformed, TRUE, reflexivity(ZERO)]],
            False, 'strict_syntax')
        add('invalid_discarded_pack_witness_' + str(index), [[], ['ex', TRUE], ['pack', bad, reflexivity(ZERO)]],
            False, 'strict_syntax')
    matrices = [['=', 0, 1], ['ex', ['=', 1, 2]], ['pi', TRUE, ['=', 1, 1]], ['pi', ['=', 1, ZERO], TRUE]]
    for index, matrix in enumerate(matrices):
        base = oracle(matrix, [ZERO, 0])
        successor = oracle(matrix, [['s', 0], 0])
        guard = matrix if matrix[0] == '=' else base
        add('correct_numerical_guard_' + str(index),
            [[['pi', guard, successor]], ['pi', base, matrix], ['nat', matrix, ['use', 0, 0, -1]]],
            True, 'numerical_rules')
        if matrix[0] != '=':
            add('forbidden_quantified_induction_' + str(index),
                [[['pi', matrix, successor]], ['pi', base, matrix], ['nat', matrix, ['use', 0, 0, -1]]],
                False, 'numerical_rules')
    inner = ['ex', ['=', 0, ZERO]]
    add('inner_bound_variable_does_not_demand_witness',
        [[['pi', TRUE, inner], TRUE], inner, ['use', 0, None, 1]], True, 'demand')
    retained = ['=', 1, 1]
    add('vacuous_witness_still_lowers_old_parameter',
        [[['pi', retained, retained], ['=', 0, 0]], ['=', 0, 0], ['use', 0, None, 1]], True, 'demand')
    return out


def substitution_expressions():
    terms = [-1, 0, 1, 4, ['s', 0], ['r', 0, 1, 0], ['r', 0, 1, 1],
             ['r', 0, 1, 2], ['r', 2, 1, ['r', 1, 0, ['s', 2]]],
             ['r', 2, 3, ['r', 1, 0, 4]]]
    formulas = [TRUE, ['=', 0, 1], ['ex', ['=', 0, 1]],
                ['ex', ['=', 1, 2]], ['pi', ['=', 0, 1], ['=', 1, 0]],
                ['pi', TRUE, ['ex', ['=', 1, 2]]],
                ['ex', ['pi', ['=', 2, 0], ['=', 1, 3]]],
                ['=', ['r', 0, 1, ['r', 1, 0, ['s', 2]]], 3],
                ['pi', ['ex', ['=', 2, 0]], ['=', ['r', 1, 0, 3], 2]],
                ['ex', ['=', ['r', 1, 2, ['r', 0, 3, 5]], 0]]]
    return [(a, False) for a in terms] + [(a, True) for a in formulas]


def grammar_cases():
    values = [None, True, False, -3, -2, -1, 0, 1, 0.0, 0.5, '', 's', 'ss', '=',
              'pi', 'ex', {}, {'s': -1}, {'=': 0, 'pi': 1, 'ex': 2}, [],
              ['s'], ['s', -1], ['s', -1, -1], ['s', TRUE],
              ['r', -1, -1], ['r', -1, -1, -1], ['r', -1, -1, -1, -1],
              ['r', -1, -1, ['pi', TRUE, TRUE]],
              ['=', -1], TRUE, ['=', -1, -1, -1], ['=', False, -1],
              ['=', ['s'], -1], ['pi', TRUE], ['pi', TRUE, TRUE],
              ['pi', -1, TRUE], ['pi', TRUE, -1], ['pi', TRUE, TRUE, TRUE],
              ['ex'], ['ex', TRUE], ['ex', TRUE, TRUE], ['ex', 0],
              ['unknown', TRUE], ['ex', ['pi', TRUE, ['=', ['r', 0, 0, True], 0]]]]
    return values
