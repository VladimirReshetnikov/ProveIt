"""Independent named-variable syntax oracle, extracted without modification.

Source: inferred-elimination draft validation/audit.py at ProveIt snapshot
820ef51b6ad3c13ce4a500673a9e81d951fbc06c. Functions resolve numerical
binding to globally fresh names; no candidate code is imported.
"""

import itertools

ZERO = -1
fresh = itertools.count()

def valid(a, formula):
    if not formula and type(a) is int:
        return a >= -1
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    tag = a[0]
    if formula:
        if tag == "=":
            return len(a) == 3 and valid(a[1], False) and valid(a[2], False)
        if tag == "pi":
            return len(a) == 3 and valid(a[1], True) and valid(a[2], True)
        if tag == "ex":
            return len(a) == 2 and valid(a[1], True)
    else:
        if tag == "s":
            return len(a) == 2 and valid(a[1], False)
        if tag == "r":
            return len(a) == 4 and all(valid(t, False) for t in a[1:])
    return False

def named(a, stack=()):
    """Resolve indices into fresh binder identities and named free variables."""
    if type(a) is int:
        if a == ZERO:
            return ("zero",)
        return ("bound", stack[a]) if a < len(stack) else ("free", a - len(stack))
    tag = a[0]
    if tag == "s":
        return ("succ", named(a[1], stack))
    if tag == "r":
        state, counter = next(fresh), next(fresh)
        return ("rec", named(a[1], stack), named(a[2], stack), state, counter,
                named(a[3], (state, counter, *stack)))
    if tag == "=":
        return ("equal", named(a[1], stack), named(a[2], stack))
    variable = next(fresh)
    if tag == "pi":
        return ("all", variable, named(a[1], (variable, *stack)),
                named(a[2], (variable, *stack)))
    if tag == "ex":
        return ("exists", variable, named(a[1], (variable, *stack)))
    raise ValueError("invalid named input")

def indices(a, stack=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "bound":
        return stack.index(a[1])
    if tag == "free":
        return a[1] + len(stack)
    if tag == "succ":
        return ["s", indices(a[1], stack)]
    if tag == "rec":
        return ["r", indices(a[1], stack), indices(a[2], stack),
                indices(a[5], (a[3], a[4], *stack))]
    if tag == "equal":
        return ["=", indices(a[1], stack), indices(a[2], stack)]
    if tag == "all":
        return ["pi", indices(a[2], (a[1], *stack)),
                indices(a[3], (a[1], *stack))]
    if tag == "exists":
        return ["ex", indices(a[2], (a[1], *stack))]
    raise ValueError("invalid named expression")

def replace_named(a, replacements, delta):
    tag = a[0]
    if tag == "free":
        i = a[1]
        if i < len(replacements):
            if replacements[i] is None:
                raise ValueError("deleted variable occurs")
            return replacements[i]
        return ("free", i + delta)
    if tag in ("zero", "bound"):
        return a
    if tag in ("succ",):
        return (tag, replace_named(a[1], replacements, delta))
    if tag == "rec":
        return (tag, replace_named(a[1], replacements, delta),
                replace_named(a[2], replacements, delta), a[3], a[4],
                replace_named(a[5], replacements, delta))
    if tag == "equal":
        return (tag, replace_named(a[1], replacements, delta),
                replace_named(a[2], replacements, delta))
    if tag == "all":
        return (tag, a[1], replace_named(a[2], replacements, delta),
                replace_named(a[3], replacements, delta))
    if tag == "exists":
        return (tag, a[1], replace_named(a[2], replacements, delta))
    raise ValueError("invalid named expression")

def oracle(a, env=(1,), depth=0, formula=True):
    if not valid(a, formula):
        raise ValueError("invalid syntax")
    stack = tuple(next(fresh) for _ in range(depth))
    replacements = [None if t is None else named(t) for t in env[:-1]]
    return indices(replace_named(named(a, stack), replacements, env[-1]), stack)

def term(rng, height=3):
    if height == 0 or rng.randrange(3) == 0:
        return rng.randrange(-1, 9)
    if rng.randrange(2) == 0:
        return ["s", term(rng, height - 1)]
    return ["r", term(rng, height - 1), term(rng, height - 1),
            term(rng, height - 1)]

def formula(rng, height=3):
    if height == 0 or rng.randrange(3) == 0:
        return ["=", term(rng, 2), term(rng, 2)]
    if rng.randrange(2) == 0:
        return ["pi", formula(rng, height - 1), formula(rng, height - 1)]
    return ["ex", formula(rng, height - 1)]
