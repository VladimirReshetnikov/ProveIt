"""Untrusted certificate translations; preserved contexts and conclusions.

forward: exact archived shared/scoped tagged format to the new format.
reverse: accepted new format to fully typed tagged proofs, normalizing all
unused universal witnesses to zero and hypothesis selectors to indices.
The reverse output is checked by both frozen checkers and the independent
explicit-rule interpreter. No acceptance checker imports this module.
"""
import argparse
from copy import deepcopy
import json
from pathlib import Path

from named_syntax import named, oracle, valid
import rule_oracle
from reference import load


def from_tagged_proof(proof):
    """Erase only application tags, leaving all object-language data intact."""
    if type(proof) is not list or not proof:
        return deepcopy(proof)
    tag = proof[0]
    if tag in ('lam', 'pack', 'nat') and len(proof) == 3:
        return [tag, deepcopy(proof[1]), from_tagged_proof(proof[2])]
    if tag == 'use' and len(proof) >= 2:
        major, *args = proof[1:]
        if len(args) == 1:
            args = [from_tagged_proof(args[0])]
        elif len(args) >= 2:
            args = [deepcopy(args[0]), from_tagged_proof(args[1]), *deepcopy(args[2:])]
        return [from_tagged_proof(major), *args]
    return deepcopy(proof)


def from_tagged(data):
    context, conclusion, proof = data
    return [deepcopy(context), deepcopy(conclusion), from_tagged_proof(proof)]


def raw_to_tagged_proof(proof):
    """Literal inverse on the well-shaped archived certificate grammar.

This does not repair witnesses or selectors. It is used to reconstruct the
archived data for provenance and exact finite replay, including negative cases.
"""
    if type(proof) is not list or not proof:
        return deepcopy(proof)
    if type(proof[0]) is str and proof[0] in ('lam', 'pack', 'nat') and len(proof) == 3:
        return [proof[0], deepcopy(proof[1]), raw_to_tagged_proof(proof[2])]
    if proof[0] == 'r':
        return deepcopy(proof)
    major, *args = proof
    if len(args) == 1:
        args = [raw_to_tagged_proof(args[0])]
    elif len(args) >= 2:
        args = [deepcopy(args[0]), raw_to_tagged_proof(args[1]), *deepcopy(args[2:])]
    return ['use', raw_to_tagged_proof(major), *args]


def raw_to_tagged(data):
    context, conclusion, proof = data
    return [deepcopy(context), deepcopy(conclusion), raw_to_tagged_proof(proof)]


def uses_free_zero(expression):
    """Check occurrence after independently resolving every binder to a name."""
    def walk(tree):
        if type(tree) is not tuple:
            return False
        if tree[0] == 'free':
            return tree[1] == 0
        return any(walk(child) for child in tree[1:])
    return walk(named(expression))


def restore_proof(proof, context, repairs):
    """Produce a fully typed proof using only the independent named oracle."""
    if type(proof) in (int, bool):
        index = int(proof)
        if index < 0:
            index += len(context)
        if not 0 <= index < len(context):
            raise ValueError('invalid hypothesis selector')
        if type(proof) is bool or proof < 0:
            repairs['hypothesis_selectors'] += 1
        return index
    if type(proof) is not list or not proof:
        raise ValueError('invalid proof tree')
    if type(proof[0]) is str and proof[0] in ('lam', 'pack', 'nat'):
        tag, parameter, body = proof
        if tag == 'pack':
            if not valid(parameter, False):
                raise ValueError('invalid existential witness')
            guard = ['=', 0, oracle(parameter, formula=False)]
        elif tag == 'lam':
            if not valid(parameter, True):
                raise ValueError('invalid universal guard')
            guard = parameter
        else:
            if not valid(parameter, True):
                raise ValueError('invalid numerical matrix')
            guard = parameter if parameter[0] == '=' else oracle(parameter, [-1, 0])
        local = [oracle(a) for a in context] + [guard]
        return [tag, deepcopy(parameter), restore_proof(body, local, repairs)]
    if proof[0] == 'r':
        return deepcopy(proof)
    major, *args = proof
    restored_major = restore_proof(major, context, repairs)
    principal = rule_oracle.infer(restored_major, context)
    if principal[0] == 'ex':
        body, = args
        local = [oracle(a) for a in context] + [principal[1]]
        return ['use', restored_major, restore_proof(body, local, repairs)]
    parameter, minor = args
    if principal[0] == 'pi' and not any(uses_free_zero(part) for part in principal[1:]):
        if parameter != -1 or type(parameter) is not int:
            repairs['vacuous_witnesses'] += 1
        parameter = -1
    return ['use', restored_major, deepcopy(parameter), restore_proof(minor, context, repairs)]


def restore(data):
    """The caller checks candidate acceptance; outputs include finite repair counts."""
    context, conclusion, proof = data
    repairs = {'vacuous_witnesses': 0, 'hypothesis_selectors': 0}
    result = [deepcopy(context), deepcopy(conclusion), restore_proof(proof, context, repairs)]
    return result, repairs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('direction', choices=('forward', 'reverse'))
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8'))
    candidate, shared, strict = load('candidate'), load('shared'), load('strict')
    if args.direction == 'forward':
        shared.check(data)
        result = from_tagged(data)
        candidate.check(*result)
    else:
        candidate.check(*data)
        result, repairs = restore(data)
        shared.check(result)
        strict.check(result)
        rule_oracle.check(result)
    args.output.write_text(json.dumps(result, ensure_ascii=True, separators=(',', ':')) + '\n', encoding='utf-8')
    print('Translated certificate checked successfully.')


if __name__ == '__main__':
    main()
