"""Reproduce focused, offline implementation checks for the complete iPRA kernel.

Runs frozen corpus replay, bidirectional format conversion, strict proof
reconstruction, an explicit rule interpreter with independent named-variable
substitution, targeted binding checks, and the normal/optimized JSON CLI.
This is finite validation evidence, not a proof-assistant soundness theorem.
"""
import hashlib
import json
import platform
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
from named_syntax import oracle, valid
import rule_oracle
from reference import ROOT, FROZEN, load
from targeted import cases, substitution_expressions, grammar_cases, TRUE, FALSE
from translate import from_tagged, raw_to_tagged, restore

HERE = Path(__file__).resolve().parent


def encode(data):
    return (json.dumps(data, ensure_ascii=True, sort_keys=True, separators=(',', ':')) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def attempt(function, *args, **kwargs):
    try:
        return True, function(*args, **kwargs)
    except Exception:
        return False, None


def run():
    candidate, shared, strict = load('candidate'), load('shared'), load('strict')
    counts, failures = Counter(), []
    rules, repairs_total = Counter(), Counter()
    corpus_results, focused_results = [], []

    def test(group, name, condition):
        counts[group] += 1
        if not condition:
            failures.append({'group': group, 'name': name})

    def verify_accepted(name, data):
        normalized, repairs = restore(data)
        test('preserved_sequents', name, normalized[:2] == data[:2])
        test('strict_reconstruction', name, attempt(strict.check, normalized)[0])
        test('shared_reconstruction', name, attempt(shared.check, normalized)[0])
        okay, visited = attempt(rule_oracle.check, normalized)
        test('independent_rule_interpreter', name, okay)
        if okay:
            rules.update(visited)
        test('normalized_forward_translation', name,
             attempt(candidate.check, *from_tagged(normalized))[0])
        repairs_total.update(repairs)
        return {'normalized_tagged_sha256': digest(encode(normalized)), 'repairs': repairs}

    index_path = HERE / 'corpus_index.json'
    index = json.loads(index_path.read_text(encoding='utf-8'))
    replayed = {'shared': set(), 'scoped': set()}
    positive, negative = 0, 0
    for record in index['records']:
        path = HERE / record['file']
        blob = path.read_bytes()
        test('corpus_integrity', record['file'], digest(blob) == record['sha256'])
        data = json.loads(blob)
        expected = record['expected']
        accepted, _ = attempt(candidate.check, *data)
        test('frozen_corpus_decisions', record['file'], accepted == expected)
        source = raw_to_tagged(data)
        test('literal_format_roundtrip', record['file'], from_tagged(source) == data)
        test('source_canonical_provenance', record['file'],
             digest(encode(source)) == record['archived_canonical_sha256'])
        for label in sorted(set(item['archive'] for item in record['provenance'])):
            reference = shared if label == 'shared' else strict
            test('source_replay', label + ':' + record['file'],
                 attempt(reference.check, source)[0] == expected)
            if expected:
                replayed[label].add(record['archived_canonical_sha256'])
        detail = {'file': record['file'], 'expected': expected, 'candidate_accepted': accepted}
        if expected and accepted:
            detail.update(verify_accepted(record['file'], data))
            positive += 1
        else:
            negative += 1
            test('independent_rejections', record['file'], not attempt(rule_oracle.check, source)[0])
        corpus_results.append(detail)
    test('corpus_totals', 'positive', positive == index['unique_acceptances'])
    test('corpus_totals', 'negative', negative == index['unique_rejections'])
    for label in replayed:
        test('corpus_totals', label,
             len(replayed[label]) == index['source_summaries'][label]['accepted_distinct_canonical_certificates'])

    for item in cases():
        name, data, expected = item['name'], item['data'], item['expected']
        accepted, _ = attempt(candidate.check, *data)
        test('focused_rule_boundaries', name, accepted == expected)
        detail = {'name': name, 'group': item['group'], 'expected': expected, 'candidate_accepted': accepted}
        if expected and accepted:
            detail.update(verify_accepted(name, data))
        else:
            test('independent_rejections', name, not attempt(rule_oracle.check, raw_to_tagged(data))[0])
        focused_results.append(detail)

    environments = [(0,), (1,), [-1, -1], [-1, 0], [['s', 0], 0],
                    [['r', 2, 1, ['s', 0]], 2, -2]]
    for i, (expression, sort) in enumerate(substitution_expressions()):
        for depth in range(4):
            for j, env in enumerate(environments):
                expected = oracle(expression, env, depth, sort)
                okay, result = attempt(candidate.subst, expression, env, depth, formula=sort)
                test('independent_named_substitution', f'{i}:{depth}:{j}', okay and result == expected)
            ref_okay, expected = attempt(oracle, expression, [None, -1], depth, sort)
            okay, result = attempt(candidate.subst, expression, [None, -1], depth, formula=sort)
            test('partial_scope_deletion', f'{i}:{depth}',
                 okay == ref_okay and (not okay or result == expected))
            raised = oracle(expression, (1,), depth, sort)
            okay, result = attempt(candidate.subst, raised, [None, -1], depth, formula=sort)
            test('lift_delete_identity', f'{i}:{depth}', okay and result == expression)

    for i, value in enumerate(grammar_cases()):
        for sort in (False, True):
            okay, _ = attempt(candidate.subst, value, formula=sort)
            test('independent_grammar', f'{i}:{sort}', okay == valid(value, sort))
        if not valid(value, True):
            test('malformed_claims', f'context:{i}', not attempt(candidate.check, [value], TRUE, 0)[0])
            test('malformed_claims', f'goal:{i}', not attempt(candidate.check, [TRUE], value, 0)[0])

    example_index = json.loads((ROOT / 'examples/index.json').read_text(encoding='utf-8'))
    for row in example_index:
        path = ROOT / 'examples' / row['file']
        test('curated_examples', row['file'], digest(path.read_bytes()) == row['sha256']
             and attempt(candidate.check, *json.loads(path.read_text(encoding='utf-8')))[0])

    vacant = ['pi', TRUE, TRUE]
    cli_cases = [
        ('valid', json.dumps([[TRUE], TRUE, 0]), True),
        ('falsity', json.dumps([[], FALSE, 0]), False),
        ('truncated_json', '[', False),
        ('null_input', 'null', False),
        ('nan_in_claim', '[[["=",0,0]],["=",NaN,0],0]', False),
        ('infinity_in_context', '[[["=",Infinity,0]],["=",0,0],0]', False),
        ('boolean_selector', json.dumps([[FALSE, TRUE], TRUE, True]), True),
        ('unused_null_witness', json.dumps([[vacant, TRUE], TRUE, [0, None, 1]]), True),
    ]
    with tempfile.TemporaryDirectory(prefix='ipra-focused-validation-') as directory:
        path = Path(directory) / 'certificate.json'
        for name, source, expected in cli_cases:
            path.write_text(source, encoding='utf-8')
            for flags, group in (([], 'json_cli'), (['-O'], 'optimized_json_cli')):
                result = subprocess.run([sys.executable, *flags, str(ROOT / 'checker.py'), str(path)],
                                        capture_output=True, text=True, timeout=20)
                test(group, name, result.returncode == (0 if expected else 1)
                     and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT'))
        for flags, group in (([], 'json_cli'), (['-O'], 'optimized_json_cli')):
            for name, args in (('missing_filename', []), ('extra_filename', [str(path), str(path)]),
                               ('missing_file', [str(Path(directory) / 'missing.json')])):
                result = subprocess.run([sys.executable, *flags, str(ROOT / 'checker.py'), *args],
                                        capture_output=True, text=True, timeout=20)
                test(group, name, result.returncode == 1 and result.stdout.strip() == 'REJECT')

    support_hashes = {p.name: digest(p.read_bytes()) for p in sorted(HERE.glob('*.py'))}
    result = {
        'status': 'passed' if not failures else 'failed',
        'python_version': platform.python_version(),
        'snapshot_commit': index['snapshot_commit'],
        'frozen_programs': {key: {'file': value[0], 'sha256': value[1]} for key, value in FROZEN.items()},
        'support_sha256': support_hashes,
        'corpus_index_sha256': digest(index_path.read_bytes()),
        'counts': dict(counts), 'total_checks': sum(counts.values()),
        'unique_corpus_acceptances': positive, 'unique_corpus_rejections': negative,
        'accepted_source_certificates_replayed': {key: len(value) for key, value in replayed.items()},
        'focused_certificate_cases': len(focused_results),
        'focused_acceptances': sum(row['expected'] for row in focused_results),
        'focused_rejections': sum(not row['expected'] for row in focused_results),
        'curated_examples': len(example_index),
        'strict_reconstruction_repairs': dict(repairs_total),
        'independent_rule_counts': dict(rules),
        'failures': failures,
        'corpus_results': corpus_results,
        'focused_results': focused_results,
        'qualification': 'Finite implementation evidence. Every accepted corpus and focused certificate is reconstructed into a proof accepted by the exact archived shared-transition and strict scoped-rules programs and by an independent named-variable rule interpreter. No proof-assistant formalization or universal soundness test is asserted.',
    }
    output = ROOT / 'results/validation.json'
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in ('status', 'python_version', 'counts',
        'unique_corpus_acceptances', 'unique_corpus_rejections', 'accepted_source_certificates_replayed',
        'focused_certificate_cases', 'focused_acceptances', 'focused_rejections', 'curated_examples', 'failures')}, indent=2))
    return not failures


if __name__ == '__main__':
    raise SystemExit(0 if run() else 1)
