"""Reproduce the symbolic proof controls and unchanged source comparison."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(relative, cwd):
    result = subprocess.run([sys.executable, str(ROOT / relative)],
                            cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr)
        raise SystemExit(result.returncode)
    return result.stdout

def main():
    manifest = ROOT / 'MANIFEST.json'
    checked = 0
    if manifest.exists():
        for item in json.loads(manifest.read_text())['files']:
            path = ROOT / item['path']
            data = path.read_bytes()
            if len(data) != item['size_bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
                raise SystemExit('Changed member: ' + item['path'])
            checked += 1
    controls = run('finite_control/test.py', ROOT / 'finite_control')
    comparison = run('comparison/measure.py', ROOT / 'comparison')
    summary = {
        'manifest_members_verified': checked,
        'finite_control': json.loads((ROOT / 'finite_control/verification.json').read_text()),
        'comparison': {key: value for key, value in
                       json.loads((ROOT / 'comparison/results.json').read_text()).items()
                       if key != 'programs'},
        'limits': 'No finite test proves the infinite-model theorem; no full Lean/Rocq verification.'
    }
    (ROOT / 'build').mkdir(exist_ok=True)
    (ROOT / 'build/reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(controls)
    print(comparison)
    print('Reproduction completed.')

if __name__ == '__main__':
    main()
