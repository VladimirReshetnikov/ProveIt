"""Regenerate a manifest and deterministic ZIP after deliberate edits."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDE = {'.aux', '.log', '.out', '.toc', '.pyc', '.synctex.gz'}

def members():
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        relative = path.relative_to(ROOT)
        if relative.parts[0] == 'build':
            continue
        if relative == Path('MANIFEST.json'):
            continue
        if path.suffix in EXCLUDE and path.parent == ROOT:
            continue
        if path.suffix == '.pyc':
            continue
        yield path

def main():
    files = []
    for path in members():
        data = path.read_bytes()
        files.append({'path': path.relative_to(ROOT).as_posix(),
                      'size_bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    (ROOT / 'MANIFEST.json').write_text(json.dumps({'files': files}, indent=2) + '\n')
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for path in [*members(), ROOT / 'MANIFEST.json']:
            name = ROOT.name + '/' + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 8, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            out.writestr(info, path.read_bytes())
    print(json.dumps({'archive': str(archive), 'members': len(files) + 1,
                      'size_bytes': archive.stat().st_size,
                      'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))

if __name__ == '__main__':
    main()
