"""Adversarial replay of the checked finite-control fragment."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import checker

HERE = Path(__file__).resolve().parent
PACKET = json.loads((HERE / "certificate.json").read_text(encoding="utf-8"))

def first(rule, predicate=lambda n: True):
    return next(i for i, n in enumerate(PACKET["nodes"]) if n["rule"] == rule and predicate(n))

def run_cli(packet, optimized=False, raw=None):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(HERE / "checker.py"))
    payload = raw if raw is not None else json.dumps(packet)
    result = subprocess.run(command, input=payload, text=True, capture_output=True, timeout=15)
    return result.returncode, result.stdout, result.stderr

def mutate(label, action):
    packet = copy.deepcopy(PACKET)
    action(packet)
    return label, packet

def set_node(packet, index, **fields):
    packet["nodes"][index].update(fields)

def main():
    accepted = checker.verify(PACKET)
    c = first("axiom", lambda n: n["name"] == "j1")
    e = first("ei")
    orbit = PACKET["exports"]["orbit_normalization"]
    h = first("hyp")
    t = first("trans")
    k = first("axiom", lambda n: n["name"] == "k0s")
    controls = [
        mutate("Boolean range rule is not admitted",
               lambda p: set_node(p, c, rule="BR")),
        mutate("Wrong fixed transition value",
               lambda p: set_node(p, c, name="j0")),
        mutate("Missing computation argument",
               lambda p: set_node(p, k, args=[])),
        mutate("Induction target leaks eigenvariable",
               lambda p: set_node(p, e, at=["v", p["nodes"][e]["variable"]])),
        mutate("Induction matrix cannot be a formula",
               lambda p: set_node(p, e, matrix=[["or", ["0"], ["0"]], ["0"]])),
        mutate("Wrong induction base",
               lambda p: set_node(p, orbit, base=PACKET["exports"]["q_one"])),
        mutate("Wrong induction step",
               lambda p: set_node(p, orbit, step=PACKET["exports"]["q_zero"])),
        mutate("An induction assumption cannot be exported",
               lambda p: p["exports"].update(orbit_normalization=h)),
        mutate("A different theorem cannot replace the required theorem",
               lambda p: p["exports"].update(orbit_normalization=PACKET["exports"]["idempotence"])),
        mutate("Forward proof reference",
               lambda p: set_node(p, t, left=len(p["nodes"]))),
        mutate("Boolean is not a proof index",
               lambda p: set_node(p, t, left=True)),
        mutate("Extra axiom fields cannot smuggle conclusions",
               lambda p: set_node(p, c, conclusion=[["0"], ["s", ["0"]]])),
    ]
    receipt = {"baseline": accepted, "controls": [], "cli_runs": 0}
    for optimized in (False, True):
        code, out, err = run_cli(PACKET, optimized)
        receipt["cli_runs"] += 1
        if code != 0:
            raise RuntimeError("Valid certificate rejected: " + err)
        parsed = json.loads(out)
        if parsed != accepted:
            raise RuntimeError("CLI/API mismatch")
    for label, packet in controls:
        try:
            checker.verify(packet)
        except Exception as error:
            diagnostic = str(error)
        else:
            raise RuntimeError("Mutation accepted: " + label)
        for optimized in (False, True):
            code, out, err = run_cli(packet, optimized)
            receipt["cli_runs"] += 1
            if code != 1 or not err.startswith("REJECT: "):
                raise RuntimeError("CLI accepted mutation: " + label)
        receipt["controls"].append({"name": label, "rejected": True, "diagnostic": diagnostic})
    raw = '{"nodes":[],"nodes":[],"exports":{}}'
    for optimized in (False, True):
        code, out, err = run_cli(None, optimized, raw)
        receipt["cli_runs"] += 1
        if code != 1 or "Duplicate JSON key" not in err:
            raise RuntimeError("Duplicate keys accepted")
    receipt["controls"].append({"name": "Duplicate JSON keys", "rejected": True})
    receipt["sha256"] = {
        name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
        for name in ("checker.py", "produce.py", "certificate.json")
    }
    (HERE / "verification.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))

if __name__ == "__main__":
    main()

