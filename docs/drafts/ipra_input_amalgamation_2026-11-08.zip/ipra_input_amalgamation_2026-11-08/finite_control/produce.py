"""Untrusted DAG certificate producer for the finite-control lemma."""
import json
from pathlib import Path
from checker import ZERO, ONE, TWO, V, S, Z, Tau, J, M, K, Q, sub, axiom, verify

nodes = []
equations = []
cache = {}

def emit(node, equation):
    key = json.dumps(node, separators=(",", ":"), sort_keys=True)
    if key in cache:
        return cache[key]
    index = len(nodes)
    nodes.append(node)
    equations.append(equation)
    cache[key] = index
    return index

def refl(t):
    return emit({"rule": "refl", "term": t}, (t, t))

def ax(name, *args):
    return emit({"rule": "axiom", "name": name, "args": args}, axiom(name, args))

def sym(p):
    a, b = equations[p]
    return emit({"rule": "sym", "proof": p}, (b, a))

def trans(p, q):
    a, b = equations[p]
    bb, c = equations[q]
    if b != bb:
        raise ValueError(("Producer mismatch", b, bb))
    return emit({"rule": "trans", "left": p, "right": q}, (a, c))

def chain(*proofs):
    answer = proofs[0]
    for p in proofs[1:]:
        answer = trans(answer, p)
    return answer

def cong(symbol, *proofs):
    e = ((symbol,) + tuple(equations[p][0] for p in proofs),
         (symbol,) + tuple(equations[p][1] for p in proofs))
    return emit({"rule": "cong", "symbol": symbol, "proofs": proofs}, e)

def inst(p, mapping):
    e = tuple(sub(t, mapping) for t in equations[p])
    return emit({"rule": "inst", "proof": p, "mapping": mapping}, e)

def contextual(template, variable, p):
    if template == V(variable):
        return p
    if template[0] == "v":
        return refl(template)
    return cong(template[0], *(contextual(c, variable, p) for c in template[1:]))

def hyp(e):
    return emit({"rule": "hyp", "equation": e}, e)

def ei(variable, e, at, base, step):
    result = tuple(sub(t, {variable: at}) for t in e)
    return emit({"rule": "ei", "variable": variable, "matrix": e,
                 "at": at, "base": base, "step": step}, result)

def normalize(t):
    if t[0] == "v":
        return refl(t)
    p = cong(t[0], *(normalize(a) for a in t[1:]))
    normal = equations[p][1]
    tag, *args = normal
    if tag in ("0", "s"):
        return p
    if tag == "z":
        root = ax("z0") if args[0] == ZERO else ax("zs", args[0][1])
    elif tag == "k0":
        root = ax("k0z", args[1]) if args[0] == ZERO else ax("k0s", args[0][1], args[1])
    elif tag in ("tau", "j"):
        table = {ZERO: 0, ONE: 1, TWO: 2}
        if args[0] not in table:
            raise ValueError("No finite interface value for " + repr(normal))
        root = ax(tag + str(table[args[0]]))
    elif tag == "m":
        root = ax("m0") if args[0] == ZERO else ax("ms", args[0][1])
    else:
        raise ValueError("Cannot normalize " + repr(normal))
    answer = trans(p, root)
    rhs = equations[answer][1]
    if rhs[0] == "0" or (rhs[0] == "s" and all_symbols_numeral(rhs)):
        return answer
    return trans(answer, normalize(rhs))

def all_symbols_numeral(t):
    return t == ZERO or (t[0] == "s" and all_symbols_numeral(t[1]))

def closed_equal(left, right):
    a, b = normalize(left), normalize(right)
    if equations[a][1] != equations[b][1]:
        raise ValueError("Finite table failed")
    return trans(a, sym(b))

def replace_in_equation(e, variable, substitution_proof, table_proof):
    """From v0=v1 and L(v1)=R(v1), derive L(v0)=R(v0)."""
    return chain(contextual(e[0], variable, substitution_proof),
                 table_proof,
                 sym(contextual(e[1], variable, substitution_proof)))

fresh_index = 0

def boolean_lift(e, variable, p0, p1, tester):
    global fresh_index
    fresh_index += 1
    x = "test_" + str(fresh_index)
    matrix = tuple(sub(t, {variable: Z(V(x))}) for t in e)
    base = replace_in_equation(e, variable, ax("z0"), p1)
    step = replace_in_equation(e, variable, ax("zs", V(x)), p0)
    return ei(x, matrix, tester, base, step)

def q(b, c):
    return K(b, Z(c))

def binary_interpolation(e):
    b, c = V("b"), V("c")
    table = {}
    for bv in (ZERO, ONE):
        for cv in (ZERO, ONE):
            instance = tuple(sub(t, {"b": bv, "c": cv}) for t in e)
            table[(bv, cv)] = closed_equal(*instance)
    cproofs = {}
    for cv in (ZERO, ONE):
        em = tuple(sub(t, {"c": cv}) for t in e)
        cproofs[cv] = boolean_lift(em, "b", table[(ZERO, cv)], table[(ONE, cv)], V("x"))
    cmatrix = tuple(sub(t, {"b": Z(V("x"))}) for t in e)
    final = boolean_lift(cmatrix, "c", cproofs[ZERO], cproofs[ONE], V("y"))
    return inst(final, {"x": V("u"), "y": Tau(V("u"))})

def build():
    exports = {}
    exports["q_zero"] = closed_equal(Q(ZERO), ZERO)
    exports["q_one"] = closed_equal(Q(ONE), ONE)
    exports["q_two"] = closed_equal(Q(TWO), TWO)

    b, c = V("b"), V("c")
    closure = binary_interpolation((J(q(b, c)), Q(J(q(b, c)))))
    exports["transition_closure"] = closure
    exports["idempotence"] = binary_interpolation((Q(q(b, c)), q(b, c)))

    r = V("r_orbit")
    matrix = (M(r), Q(M(r)))
    ih = hyp(matrix)
    base = closed_equal(M(ZERO), Q(M(ZERO)))
    ms = ax("ms", r)
    ji = cong("j", ih)
    cl = inst(closure, {"u": M(r)})
    qji = contextual(Q(V("w")), "w", sym(ji))
    qms = contextual(Q(V("w")), "w", sym(ms))
    step = chain(ms, ji, cl, qji, qms)
    exports["orbit_normalization"] = ei("r_orbit", matrix, V("n"), base, step)

    r = V("r_period")
    s3r = S(S(S(r)))
    matrix = (M(s3r), M(r))
    ih = hyp(matrix)
    base = closed_equal(M(S(S(S(ZERO)))), M(ZERO))
    step = chain(ax("ms", s3r), cong("j", ih), sym(ax("ms", r)))
    exports["period_three"] = ei("r_period", matrix, V("n"), base, step)

    packet = json.loads(json.dumps({"nodes": nodes, "exports": exports}))
    result = verify(packet)
    Path(__file__).with_name("certificate.json").write_text(
        json.dumps(packet, indent=2) + "\n", encoding="utf-8")
    return result

if __name__ == "__main__":
    print(json.dumps(build(), indent=2))

