"""Symbolic finite-control derivations over an explicit inherited interface.

This verifies a fragment lemma, not all of iPRA or the inherited tau theorem.
No Boolean range, coverage, falsity, cancellation, or case rule is admitted.
"""
import json
import sys

ARITY = {"0": 0, "v": 1, "s": 1, "z": 1, "tau": 1,
         "j": 1, "m": 1, "k0": 2}
ZERO = ("0",)

def V(name): return ("v", name)
def S(t): return ("s", t)
def Z(t): return ("z", t)
def Tau(t): return ("tau", t)
def J(t): return ("j", t)
def M(t): return ("m", t)
def K(n, a): return ("k0", n, a)
def Q(t): return K(Z(t), Z(Z(Tau(t))))
ONE = S(ZERO)
TWO = S(ONE)

def require(condition, message):
    if not condition:
        raise ValueError(message)

def term(raw):
    require(type(raw) in (list, tuple) and raw, "Malformed term")
    tag = raw[0]
    require(type(tag) is str and tag in ARITY, "Unknown term constructor")
    require(len(raw) == ARITY[tag] + 1, "Wrong term arity")
    if tag == "v":
        require(type(raw[1]) is str and bool(raw[1]), "Malformed variable")
        return (tag, raw[1])
    return (tag,) + tuple(term(x) for x in raw[1:])

def fv(t):
    if t[0] == "v":
        return {t[1]}
    answer = set()
    for child in t[1:]:
        answer |= fv(child)
    return answer

def sub(t, mapping):
    if t[0] == "v":
        return mapping.get(t[1], t)
    return (t[0],) + tuple(sub(x, mapping) for x in t[1:])

def eqsub(equation, mapping):
    return sub(equation[0], mapping), sub(equation[1], mapping)

def eq(raw):
    require(type(raw) in (list, tuple) and len(raw) == 2, "Malformed equation")
    return term(raw[0]), term(raw[1])

def axiom(name, args):
    """The full trusted interface. All RHSs are reconstructed here."""
    count = {"z0": 0, "zs": 1, "k0z": 1, "k0s": 2,
             "tau0": 0, "tau1": 0, "tau2": 0,
             "j0": 0, "j1": 0, "j2": 0, "m0": 0, "ms": 1}
    require(name in count and len(args) == count[name], "Unknown/malformed axiom")
    if name == "z0": return Z(ZERO), ONE
    if name == "zs": return Z(S(args[0])), ZERO
    if name == "k0z": return K(ZERO, args[0]), S(args[0])
    if name == "k0s": return K(S(args[0]), args[1]), ZERO
    if name == "tau0": return Tau(ZERO), ONE
    if name == "tau1": return Tau(ONE), ZERO
    if name == "tau2": return Tau(TWO), TWO
    if name == "j0": return J(ZERO), ONE
    if name == "j1": return J(ONE), TWO
    if name == "j2": return J(TWO), ZERO
    if name == "m0": return M(ZERO), ZERO
    return M(S(args[0])), J(M(args[0]))

def goals():
    n, u = V("n"), V("u")
    return {
        "q_zero": (Q(ZERO), ZERO),
        "q_one": (Q(ONE), ONE),
        "q_two": (Q(TWO), TWO),
        "transition_closure": (J(Q(u)), Q(J(Q(u)))),
        "idempotence": (Q(Q(u)), Q(u)),
        "orbit_normalization": (M(n), Q(M(n))),
        "period_three": (M(S(S(S(n)))), M(n)),
    }

def verify(packet):
    require(type(packet) is dict and set(packet) == {"nodes", "exports"}, "Bad packet")
    require(type(packet["nodes"]) is list, "Bad proof list")
    verified = []
    counts = {}
    for pos, node in enumerate(packet["nodes"]):
        require(type(node) is dict and type(node.get("rule")) is str, "Bad node")
        rule = node["rule"]
        counts[rule] = counts.get(rule, 0) + 1
        def fields(*keys):
            require(set(node) == {"rule", *keys}, "Wrong node fields")
        def ref(number):
            require(type(number) is int and 0 <= number < pos, "Nonprior proof reference")
            return verified[number]
        if rule == "axiom":
            fields("name", "args")
            require(type(node["name"]) is str and type(node["args"]) is list, "Bad axiom")
            result = frozenset(), axiom(node["name"], [term(t) for t in node["args"]])
        elif rule == "refl":
            fields("term")
            t = term(node["term"])
            result = frozenset(), (t, t)
        elif rule == "hyp":
            fields("equation")
            e = eq(node["equation"])
            result = frozenset({e}), e
        elif rule == "sym":
            fields("proof")
            c, (a, b) = ref(node["proof"])
            result = c, (b, a)
        elif rule == "trans":
            fields("left", "right")
            c, (a, b) = ref(node["left"])
            d, (bb, e) = ref(node["right"])
            require(b == bb, "Transitivity middle mismatch")
            result = c | d, (a, e)
        elif rule == "cong":
            fields("symbol", "proofs")
            symbol = node["symbol"]
            require(type(symbol) is str and symbol in ARITY and symbol != "v", "Bad congruence")
            require(type(node["proofs"]) is list and len(node["proofs"]) == ARITY[symbol],
                    "Congruence arity")
            proofs = [ref(i) for i in node["proofs"]]
            context = frozenset().union(*(p[0] for p in proofs))
            result = context, ((symbol,) + tuple(p[1][0] for p in proofs),
                               (symbol,) + tuple(p[1][1] for p in proofs))
        elif rule == "inst":
            fields("proof", "mapping")
            c, e = ref(node["proof"])
            require(type(node["mapping"]) is dict and
                    all(type(k) is str and k for k in node["mapping"]), "Bad substitution")
            mapping = {k: term(v) for k, v in node["mapping"].items()}
            result = frozenset(eqsub(a, mapping) for a in c), eqsub(e, mapping)
        elif rule == "ei":
            fields("variable", "matrix", "at", "base", "step")
            x = node["variable"]
            require(type(x) is str and bool(x), "Bad induction variable")
            e, at = eq(node["matrix"]), term(node["at"])
            bc, be = ref(node["base"])
            sc, se = ref(node["step"])
            require(be == eqsub(e, {x: ZERO}), "Wrong induction base")
            require(se == eqsub(e, {x: S(V(x))}), "Wrong induction step")
            context = bc | (sc - {e})
            require(x not in fv(at), "Induction eigenvariable escaped in target")
            require(all(x not in (fv(a) | fv(b)) for a, b in context),
                    "Induction eigenvariable escaped in retained context")
            result = context, eqsub(e, {x: at})
        else:
            raise ValueError("Unknown inference rule: " + rule)
        verified.append(result)
    exports = packet["exports"]
    require(type(exports) is dict and set(exports) == set(goals()), "Wrong exports")
    for name, expected in goals().items():
        index = exports[name]
        require(type(index) is int and 0 <= index < len(verified), "Bad export reference")
        context, actual = verified[index]
        require(not context, "Export leaks assumptions: " + name)
        require(actual == expected, "Wrong exact theorem: " + name)
    return {"accepted": True, "nodes": len(verified), "rules": counts,
            "exports": list(goals()), "boolean_range_used": False}

def no_duplicates(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, "Duplicate JSON key")
        out[key] = value
    return out

if __name__ == "__main__":
    try:
        packet = json.load(sys.stdin, object_pairs_hook=no_duplicates)
        print(json.dumps(verify(packet), indent=2))
    except Exception as error:
        print("REJECT: " + str(error), file=sys.stderr)
        sys.exit(1)

