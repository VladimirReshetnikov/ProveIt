FINITE CONTROL IN BARE SHIFTED ITERATION
======================================

Status
------
This supplement proves a local equation theorem. It does not supply a new
complete iPRA checker, general Boolean-range conservation, or the full
predecessor theorem in the bare shifted theory.

The new explicit normalizer is
  Q(u) = K_0(Zu, Z(Z(tau u))).
For any fixed closed update j with finite values j0=1, j1=2, j2=0,
and M=J_j, bare equation induction proves
  M(n)=Q(M(n)).
It also proves Q's idempotence, transition closure, and period three.
Three-row equation tables consequently apply to M(n) without invoking
a Boolean-range disjunction.

The mathematical section also proves a general fixed-k version, conditional on
a finitely certified table of separator terms (or a predecessor candidate's
values only at the finitely many state numerals). Nested K_0 terms encode the
length of a Boolean vector's initial zero prefix, giving a finite retraction.
Every certified k-state closed update then has the same equation invariant.
This generalization has a written proof; the symbolic certificate covers the
specific short three-state normalizer, not a compiler for every k.

Contents
--------
finite_control.tex           Standalone LaTeX wrapper.
finite_control_fragment.tex  Self-contained mathematical section, importable.
checker.py                   Standalone symbolic DAG verifier.
produce.py                   Untrusted certificate producer.
certificate.json             Actual generated proof DAG.
test.py                      Positive replay and 13 rejection controls.
verification.json            Recorded executed result.

Reproduction
------------
  python3 produce.py
  python3 test.py
  python3 checker.py < certificate.json

The first command regenerates the certificate and runs the verifier.
The second checks the valid packet, runs 13 rejection controls, and performs
28 CLI runs across ordinary Python and Python -O.
The accepted DAG has 359 proof nodes, 8 actual literal-equation induction
applications, and 7 exact exported equations.

To compile the standalone supplement:
  pdflatex -interaction=nonstopmode -halt-on-error finite_control.tex
  pdflatex -interaction=nonstopmode -halt-on-error finite_control.tex

Exact trusted arithmetic interface
----------------------------------
The verifier admits exactly these schema instances:
  Z(0)=1, Z(Sx)=0;
  K_0(0,a)=Sa, K_0(Sn,a)=0;
  tau(0)=1, tau(1)=0, tau(2)=2;
  j(0)=1, j(1)=2, j(2)=0;
  M(0)=0, M(Sn)=j(Mn).

The LaTeX section states all staged source definitions for the inherited tau,
gives its existing pure-equational bootstrap proof, and defines M as the
derived source term J_j. The verifier treats the displayed interface as its
explicit dependency: it does NOT mechanically expand or verify the entire
tau bootstrap or J_j source translation. Generic j is constrained by the three
listed finite equations. For the concrete clock update, those are computations.

Exact trusted inference machinery
----------------------------------
Reflexivity, symmetry, transitivity, ordinary function congruence, simultaneous
term substitution, equation assumptions, and literal-equation induction.
The checker reconstructs both sides of every inferred equation.

A proof node denotes Gamma |- (s=t), where Gamma is the finite set of its
undischarged equation hypotheses. Congruence/transitivity union contexts.
Substitution acts on both the conclusion and its context. This is the usual
admissible simultaneous-substitution metarule; eigenvariables in a source
derivation can be renamed before it is applied.

An EI node supplies a variable x, equation matrix E(x), target t, base proof,
and step proof. The checker requires exactly E(0) and E(Sx), removes only
the local E(x) hypothesis from the step context, unions remaining contexts,
and rejects if x occurs in the target or in a retained context equation.
All other matrix variables are fixed parameters. The step may ignore its
local induction hypothesis.

The public packet has exactly nodes and exports. References point to earlier
nodes. Each node has exactly its documented fields as enforced by the code.
Unknown constructors/rules and compound equation matrices reject. Variables
are nonempty strings, terms have fixed arities, and proof indices must be
actual integers (not JSON booleans). Duplicate JSON object keys reject.
The exact seven expected endpoints are built into checker.py; accepting a
different equation in place of an export is not permitted.

Uniform Boolean interpolation is NOT a trusted instruction: every such step
in the packet is expanded into endpoint equation induction. No Boolean-range,
coverage, successor-injectivity, falsity, case-elimination, numerical oracle,
or general induction principle is present.

The certificate verifies the new local theorem relative to the stated
arithmetic interface. It does not constitute Lean/Rocq formalization of iPRA,
source-level verification of the entire inherited bootstrap, or a verification
of the full ordinary/native logical equivalence.

Provenance
----------
The tau and J_h source definitions and proofs are inherited from the current
ProveIt shifted-unary and shifted-iteration reports. The relevant current
snapshot is 4890fd00a5cacfc9881ae282120978f95c3ba392.
The Q normalizer and expanded finite-table certificate are the present local
addition. Historical priority beyond the inspected corpus is not claimed.

