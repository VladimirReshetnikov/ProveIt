INPUT AMALGAMATION AND THE iPRA MINIMIZATION PROBLEM
===================================================

Prepared for Vladimir Reshetnikov, November 8, 2026 (Pacific date).
Repository snapshot: 4890fd00a5cacfc9881ae282120978f95c3ba392.

OUTCOME
-------
This archive does NOT establish the requested new complete axiomatization
below the current complexity frontier. It supplies two mathematical results
relative to the 16 inspected drafts, with the retained complete iPRA basis
and an exact current source comparison.

1. A stronger unary obstruction: even every true universal unary-arithmetic
   sentence, every true one-input existential law with quantifier-free
   matrix, and full quantifier-free induction WITH arbitrary parameters
   admit a classical amalgam model incompatible with ordinary
   bi-interpretability with iPRA. Tuple and quotient interpretations are
   covered. The missing binary pairing principle and a specific existential
   induction failure are exhibited.

2. A pure equational normalizer for the shifted theory's three-state orbit.
   Its symbolic certificate verifies seven exact equations, including
   M(n)=Q(M(n)), without a Boolean-range inference. This is a local reduction,
   not a proof of general Boolean-range conservation or a new full checker.
   A written theorem extends the method to every fixed finite transition
   table with the stated finite, certified separation data.

The current complete-source envelope remains 312 tokens / 347 AST nodes /
878 normalized bytes, with different attainers. Output-protocol changes
are not counted as mathematical progress or new comparison records.

START HERE
----------
report.pdf      Main report: exact claims, proofs, inherited complete theory,
                interpretations, current comparison, and further questions.
report.tex      Editable main manuscript; section sources in sections/.

finite_control/ has the local symbolic certificate and its exact dependency
interface. The 359-node certificate contains 8 actual equation inductions.
Thirteen rejection controls and ordinary/optimized Python replays are supplied.
The infinite-model theorem is a written proof reviewed by a separate AI agent; it
is not claimed to be established by finite tests or by Lean/Rocq.

comparison/ contains unchanged inherited acceptance programs, their source
hashes, all current occurrences, the inherited normalizer, and results.
dependencies/closed_equational/ contains the inherited arithmetic paper
and editable source on which the complete reference reconstruction relies.
That dependency retains its earlier snapshot and historical measurements.

REPRODUCE OFFLINE
-----------------
  python3 reproduce.py
  python3 build.py
  python3 package.py

Python 3.10+ suffices for the symbolic checks. Exact source measurements were
recorded with CPython 3.12.14. Building requires local pdflatex and the packages
listed in report.tex; no shell escape or network is used. package.py regenerates
the manifest after intentional edits. Reproduction records are included.

The manifest excludes itself, transient root TeX outputs, and Python caches.
The archive contains the exact source identities of all 16 input ZIPs, not
duplicate copies of those original ZIPs. All comparison source copies are
byte-for-byte unchanged. See ATTRIBUTION.txt and LICENSE-inherited.txt.
