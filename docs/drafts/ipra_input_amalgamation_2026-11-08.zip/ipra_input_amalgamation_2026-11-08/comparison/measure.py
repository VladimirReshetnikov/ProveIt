"""Measure the complete source corpus with its unchanged inherited normalizer.

Run from any directory: python3 path/to/measure.py.
Only the normalizer is imported. Comparator programs are parsed as data and
never imported or executed. All imports, validation, scope machinery, fixed
terms, and acceptance/rejection wrappers remain charged to every comparator.
"""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform

ROOT=Path(__file__).resolve().parent
FIELDS=('normalized_tokens','ast_nodes','normalized_bytes')

def main():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    norm=manifest['normalizer']
    normalizer_path=ROOT/norm['file']
    if hashlib.sha256(normalizer_path.read_bytes()).hexdigest()!=norm['sha256']:
        raise ValueError('Changed inherited normalizer')
    spec=importlib.util.spec_from_file_location('inherited_source_measure',normalizer_path)
    normalizer=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(normalizer)
    rows=[]
    for item in manifest['programs']:
        metric=normalizer.metrics(ROOT/item['file'])
        if metric['sha256']!=item['sha256']:
            raise ValueError('Changed comparator: '+item['file'])
        rows.append({**item,**{key:metric[key]for key in (*FIELDS,'source_tokens','raw_bytes')}})
    complete=[row for row in rows if row['status']=='complete']
    minima={key:min(row[key]for row in complete)for key in FIELDS}
    result={
        'python':platform.python_version(),
        'implementation':platform.python_implementation(),
        'commit':manifest['commit'],
        'archive_count':manifest['archive_count'],
        'distinct_complete_programs':len(complete),
        'distinct_experimental_programs':len(rows)-len(complete),
        'coordinate_minima':minima,
        'attainers':{key:[row['label']for row in complete if row[key]==minima[key]]for key in FIELDS},
        'minima_including_experiments':{key:min(row[key]for row in rows)for key in FIELDS},
        'scope':'Whole programs, unchanged wrapper protocol; excludes helpers and fragment verifiers.',
        'programs':rows,
    }
    (ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    with (ROOT/'results.csv').open('w',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=('label','status',*FIELDS,'sha256'),extrasaction='ignore')
        writer.writeheader();writer.writerows(rows)
    lines=[]
    for row in rows:
        name=row['label'].replace('_',r'\_')
        flag=''if row['status']=='complete'else r'$^\dagger$'
        lines.append(r'\texttt{'+name+'}'+flag+' & '+' & '.join(str(row[key])for key in FIELDS)+r' \\')
    (ROOT/'table_rows.tex').write_text('\n'.join(lines)+'\n')
    header = (r'\begin{longtable}{@{}lrrr@{}}' + '\n' +
              r'\toprule Source label & Tokens & AST nodes & Bytes\\' + '\n' +
              r'\midrule\endfirsthead' + '\n' +
              r'\toprule Source label & Tokens & AST nodes & Bytes\\\midrule\endhead' + '\n')
    footer = (r'\midrule Complete-source coordinate minima & ' +
              ' & '.join(r'\textbf{' + str(minima[key]) + '}' for key in FIELDS) +
              r'\\' + '\n' + r'\bottomrule\end{longtable}' + '\n')
    (ROOT/'table.tex').write_text(header + '\n'.join(lines) + '\n' + footer)
    print(json.dumps({key:value for key,value in result.items()if key!='programs'},indent=2))

if __name__=='__main__':
    main()
