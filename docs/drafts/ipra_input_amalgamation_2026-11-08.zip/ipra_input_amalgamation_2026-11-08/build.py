"""Compile the main manuscript with local LaTeX and no shell escape."""
from pathlib import Path
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent

def environment():
    """Local format-cache fallback adapted from the bundled reference report."""
    env = dict(os.environ)
    probe = subprocess.run(['kpsewhich', 'pdflatex.fmt'], capture_output=True, env=env)
    if probe.stdout.strip():
        return env
    trees = [p for p in ('/usr/share/texlive/texmf-dist', '/usr/share/texmf')
             if Path(p).is_dir()]
    if trees:
        env['TEXMF'] = '{' + ','.join(trees) + '}'
    cache = ROOT / 'build/texformat'
    cache.mkdir(parents=True, exist_ok=True)
    if not (cache / 'pdflatex.fmt').is_file():
        run = subprocess.run(
            ['pdftex', '-ini', '-etex', '-jobname=pdflatex',
             '-interaction=nonstopmode', '-halt-on-error', 'pdflatex.ini'],
            cwd=cache, env=env, text=True, capture_output=True)
        if run.returncode:
            print(run.stdout[-12000:])
            print(run.stderr[-3000:])
            raise SystemExit(run.returncode)
    maps = [Path('/usr/share/texmf/fonts/map/dvips/lm/lm.map')]
    maps += [Path('/usr/share/texlive/texmf-dist/fonts/map/dvips/amsfonts') / name
             for name in ('cm.map', 'cmextra.map', 'symbols.map')]
    if all(p.is_file() for p in maps):
        (cache / 'pdftex.map').write_text('\n'.join(p.read_text() for p in maps))
        env['TEXFONTMAPS'] = str(cache) + os.pathsep
    env['TEXFORMATS'] = str(cache) + os.pathsep
    return env

def main():
    if not shutil.which('pdflatex'):
        raise SystemExit('Install a local LaTeX distribution with pdflatex.')
    evidence = ROOT / 'evidence'
    evidence.mkdir(exist_ok=True)
    env = environment()
    last = ''
    for _ in range(3):
        run = subprocess.run(
            ['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
             '-halt-on-error', 'report.tex'], cwd=ROOT, env=env,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        last = run.stdout
        if run.returncode:
            (evidence / 'latex_build.log').write_text(last)
            print(last[-12000:])
            raise SystemExit(run.returncode)
    (evidence / 'latex_build.log').write_text(last)
    warnings = [line for line in last.splitlines()
                if any(word in line for word in ('Warning', 'Overfull', 'Underfull'))]
    (evidence / 'latex_warnings.txt').write_text('\n'.join(warnings) + '\n')
    print(last[-1800:])

if __name__ == '__main__':
    main()
