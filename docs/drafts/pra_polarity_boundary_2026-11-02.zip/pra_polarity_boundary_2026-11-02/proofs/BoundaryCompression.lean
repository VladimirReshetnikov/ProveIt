import Std

/-!
Local constructive verification kernels for the compressed PRA boundary schemas.

All logical equivalences are proved on an arbitrary carrier with arbitrary
zero and successor, using neither classical choice nor decidability.
The parameter a is fixed and suppressed by currying P, t, or s.

The Nat witness theorems separately verify the primitive-recursive scan
invariants, with explicit DecidablePred hypotheses.  These kernels do not
formalize the full PRA syntax, arithmetic bootstrap, or bi-interpretation.
-/

namespace BoundaryCompression

variable {α : Type}

def Boundary (z : α) (s : α → α) (P : α → Prop) (n : α) : Prop :=
  ∃ b, (b = z ∨ P b) ∧ (P (s b) → b = n)

def SharedBoundary (z : α) (s : α → α) (P : α → Prop) (n : α) : Prop :=
  ∃ b, ∃ c, c = s b ∧ (b = z ∨ P b) ∧ (P c → b = n)

def ZeroGraph (z : α) (s : α → α) (t : α → α) (n : α) : Prop :=
  ∃ b, ∀ x y, t x = y →
    ((x = b → b = z ∨ y = z) ∧
     (x = s b → (y = z → b = n)))

def EquationGraph (z : α) (s : α → α)
    (u v : α → α) (n : α) : Prop :=
  ∃ b, ∀ x y w, (u x = y ∧ v x = w) →
    ((x = b → b = z ∨ y = w) ∧
     (x = s b → (y = w → b = n)))

def DualBoundary (z : α) (s : α → α) (E : α → Prop) (n : α) : Prop :=
  ∃ b, (E b → b = z) ∧ (b = n ∨ E (s b))

def SharedDual (z : α) (s : α → α) (E : α → Prop) (n : α) : Prop :=
  ∃ b, ∃ c, c = s b ∧ (E b → b = z) ∧ (b = n ∨ E c)

def DualZeroGraph (z : α) (s : α → α) (t : α → α) (n : α) : Prop :=
  ∃ b, ∀ x y, t x = y →
    ((x = b → (y = z → b = z)) ∧
     (x = s b → (b = n ∨ y = z)))

def DualEquationGraph (z : α) (s : α → α)
    (u v : α → α) (n : α) : Prop :=
  ∃ b, ∀ x y w, (u x = y ∧ v x = w) →
    ((x = b → (y = w → b = z)) ∧
     (x = s b → (b = n ∨ y = w)))

theorem boundary_iff_shared (z : α) (s : α → α) (P : α → Prop) (n : α) :
    Boundary z s P n ↔ SharedBoundary z s P n := by
  constructor
  · intro h
    cases h with
    | intro b hb => exact ⟨b, s b, rfl, hb.1, hb.2⟩
  · intro h
    cases h with
    | intro b hb =>
      cases hb with
      | intro c hc =>
        exact ⟨b, hc.2.1, fun hs => hc.2.2 (hc.1.symm ▸ hs)⟩

theorem boundary_iff_zeroGraph (z : α) (s : α → α) (t : α → α) (n : α) :
    Boundary z s (fun x => t x = z) n ↔ ZeroGraph z s t n := by
  constructor
  · intro h
    cases h with
    | intro b hb =>
      refine ⟨b, ?_⟩
      intro x y hxy
      constructor
      · intro hxb
        cases hb.1 with
        | inl hz => exact Or.inl hz
        | inr ht =>
          exact Or.inr (hxy.symm.trans ((congrArg t hxb).trans ht))
      · intro hxs hy
        exact hb.2 ((congrArg t hxs).symm.trans (hxy.trans hy))
  · intro h
    cases h with
    | intro b hb =>
      exact ⟨b, (hb b (t b) rfl).1 rfl,
        fun hs => (hb (s b) (t (s b)) rfl).2 rfl hs⟩

theorem boundary_iff_equationGraph (z : α) (s : α → α)
    (u v : α → α) (n : α) :
    Boundary z s (fun x => u x = v x) n ↔ EquationGraph z s u v n := by
  constructor
  · intro h
    cases h with
    | intro b hb =>
      refine ⟨b, ?_⟩
      intro x y w hval
      constructor
      · intro hxb
        cases hb.1 with
        | inl hz => exact Or.inl hz
        | inr huv =>
          exact Or.inr (hval.1.symm.trans ((congrArg u hxb).trans
            (huv.trans ((congrArg v hxb).symm.trans hval.2))))
      · intro hxs hyw
        exact hb.2 ((congrArg u hxs).symm.trans (hval.1.trans
          (hyw.trans (hval.2.symm.trans (congrArg v hxs)))))
  · intro h
    cases h with
    | intro b hb =>
      exact ⟨b, (hb b (u b) (v b) ⟨rfl, rfl⟩).1 rfl,
        fun hs => (hb (s b) (u (s b)) (v (s b)) ⟨rfl, rfl⟩).2 rfl hs⟩

theorem dual_iff_shared (z : α) (s : α → α) (E : α → Prop) (n : α) :
    DualBoundary z s E n ↔ SharedDual z s E n := by
  constructor
  · intro h
    cases h with
    | intro b hb => exact ⟨b, s b, rfl, hb.1, hb.2⟩
  · intro h
    cases h with
    | intro b hb =>
      cases hb with
      | intro c hc =>
        refine ⟨b, hc.2.1, ?_⟩
        cases hc.2.2 with
        | inl hn => exact Or.inl hn
        | inr he => exact Or.inr (hc.1 ▸ he)

theorem dual_iff_zeroGraph (z : α) (s : α → α) (t : α → α) (n : α) :
    DualBoundary z s (fun x => t x = z) n ↔ DualZeroGraph z s t n := by
  constructor
  · intro h
    cases h with
    | intro b hb =>
      refine ⟨b, ?_⟩
      intro x y hxy
      constructor
      · intro hxb hy
        exact hb.1 ((congrArg t hxb).symm.trans (hxy.trans hy))
      · intro hxs
        cases hb.2 with
        | inl hn => exact Or.inl hn
        | inr ht =>
          exact Or.inr (hxy.symm.trans ((congrArg t hxs).trans ht))
  · intro h
    cases h with
    | intro b hb =>
      exact ⟨b, fun ht => (hb b (t b) rfl).1 rfl ht,
        (hb (s b) (t (s b)) rfl).2 rfl⟩

theorem dual_iff_equationGraph (z : α) (s : α → α)
    (u v : α → α) (n : α) :
    DualBoundary z s (fun x => u x = v x) n ↔ DualEquationGraph z s u v n := by
  constructor
  · intro h
    cases h with
    | intro b hb =>
      refine ⟨b, ?_⟩
      intro x y w hval
      constructor
      · intro hxb hyw
        exact hb.1 ((congrArg u hxb).symm.trans (hval.1.trans
          (hyw.trans (hval.2.symm.trans (congrArg v hxb)))))
      · intro hxs
        cases hb.2 with
        | inl hn => exact Or.inl hn
        | inr huv =>
          exact Or.inr (hval.1.symm.trans ((congrArg u hxs).trans
            (huv.trans ((congrArg v hxs).symm.trans hval.2))))
  · intro h
    cases h with
    | intro b hb =>
      exact ⟨b, fun ht => (hb b (u b) (v b) ⟨rfl, rfl⟩).1 rfl ht,
        (hb (s b) (u (s b)) (v (s b)) ⟨rfl, rfl⟩).2 rfl⟩

theorem boundary_induction (z : α) (s : α → α) (P : α → Prop)
    (H : ∀ n, Boundary z s P n)
    (base : P z) (step : ∀ x, P x → P (s x)) : ∀ n, P n := by
  intro n
  cases H n with
  | intro b hb =>
    have pb : P b := hb.1.elim (fun hz => hz.symm ▸ base) (fun hp => hp)
    have hbn : b = n := hb.2 (step b pb)
    exact hbn ▸ pb

theorem dual_induction (z : α) (s : α → α) (E : α → Prop)
    (H : ∀ n, DualBoundary z s E n)
    (base : ¬ E z) (step : ∀ x, ¬ E x → ¬ E (s x)) : ∀ n, ¬ E n := by
  intro n
  cases H n with
  | intro b hb =>
    have nb : ¬ E b := fun he => base (hb.1 he ▸ he)
    have ns : ¬ E (s b) := step b nb
    cases hb.2 with
    | inl hbn => exact hbn ▸ nb
    | inr he => exact False.elim (ns he)

def candidate (P : Nat → Prop) [DecidablePred P] : Nat → Nat
  | 0 => 0
  | Nat.succ n =>
      if P (Nat.succ (candidate P n)) then Nat.succ n else candidate P n

theorem candidate_invariant (P : Nat → Prop) [DecidablePred P] (n : Nat) :
    (candidate P n = 0 ∨ P (candidate P n)) ∧
    (P (Nat.succ (candidate P n)) → candidate P n = n) := by
  induction n with
  | zero => exact ⟨Or.inl rfl, fun _ => rfl⟩
  | succ n ih =>
    simp only [candidate]
    by_cases ht : P (Nat.succ (candidate P n))
    · rw [if_pos ht]
      have he : candidate P n = n := ih.2 ht
      exact ⟨Or.inr (he ▸ ht), fun _ => rfl⟩
    · rw [if_neg ht]
      exact ⟨ih.1, fun h => False.elim (ht h)⟩

theorem nat_boundary (P : Nat → Prop) [DecidablePred P] (n : Nat) :
    Boundary 0 Nat.succ P n :=
  ⟨candidate P n, candidate_invariant P n⟩

def dualCandidate (E : Nat → Prop) [DecidablePred E] : Nat → Nat
  | 0 => 0
  | Nat.succ n =>
      if E (Nat.succ (dualCandidate E n)) then dualCandidate E n else Nat.succ n

theorem dualCandidate_invariant (E : Nat → Prop) [DecidablePred E] (n : Nat) :
    (E (dualCandidate E n) → dualCandidate E n = 0) ∧
    (dualCandidate E n = n ∨ E (Nat.succ (dualCandidate E n))) := by
  induction n with
  | zero => exact ⟨fun _ => rfl, Or.inl rfl⟩
  | succ n ih =>
    simp only [dualCandidate]
    by_cases ht : E (Nat.succ (dualCandidate E n))
    · rw [if_pos ht]
      exact ⟨ih.1, Or.inr ht⟩
    · rw [if_neg ht]
      have he : dualCandidate E n = n := ih.2.resolve_right ht
      exact ⟨fun h => False.elim (ht (he.symm ▸ h)), Or.inl rfl⟩

theorem nat_dual (E : Nat → Prop) [DecidablePred E] (n : Nat) :
    DualBoundary 0 Nat.succ E n :=
  ⟨dualCandidate E n, dualCandidate_invariant E n⟩

#print axioms boundary_iff_shared
#print axioms boundary_iff_zeroGraph
#print axioms boundary_iff_equationGraph
#print axioms dual_iff_shared
#print axioms dual_iff_zeroGraph
#print axioms dual_iff_equationGraph
#print axioms boundary_induction
#print axioms dual_induction
#print axioms candidate_invariant
#print axioms nat_boundary
#print axioms dualCandidate_invariant
#print axioms nat_dual

end BoundaryCompression
