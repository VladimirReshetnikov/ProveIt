#!/usr/bin/env python3
"""Exact syntax counts and finite regression checks for boundary compression.

No external dependencies.  This program does not prove PRA bi-interpretability.
The companion Lean file proves the arbitrary-carrier logical equivalences.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from pathlib import Path
import json
import random


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()
    label: str = ""
    descriptor: "Node | None" = None


def V(name): return Node("var", label=name)
def C(name="0"): return Node("const", label=name)
def App(name, *args, descriptor=None): return Node("app", tuple(args), name, descriptor)
def S(t): return App("S", t)
def Eq(a, b): return Node("eq", (a, b))
def And(a, b): return Node("and", (a, b))
def Or(a, b): return Node("or", (a, b))
def Imp(a, b): return Node("implies", (a, b))
def All(v, f): return Node("forall", (f,), v)
def Ex(v, f): return Node("exists", (f,), v)


def size(t: Node, full: bool = True) -> int:
    return (1 + sum(size(c, full) for c in t.children)
            + (size(t.descriptor, full) if full and t.descriptor is not None else 0))


def occurrences(t: Node, variable: str) -> int:
    if t.tag == "var":
        return int(t.label == variable)
    if t.tag in {"forall", "exists"} and t.label == variable:
        return 0
    return sum(occurrences(c, variable) for c in t.children)


def subst(t: Node, variable: str, replacement: Node) -> Node:
    if t.tag == "var" and t.label == variable:
        return replacement
    if t.tag in {"forall", "exists"} and t.label == variable:
        return t
    # Descriptors are deliberately frozen; only active arguments are changed.
    return Node(t.tag, tuple(subst(c, variable, replacement) for c in t.children),
                t.label, t.descriptor)


x, a, n, b, c, y, u, v = map(V, ("x", "a", "n", "b", "c", "y", "u", "v"))
zero = C()


def close_native(matrix):
    return All("a", All("n", Ex("b", matrix)))


def native(P, dual=False):
    pb, psb = subst(P, "x", b), subst(P, "x", S(b))
    matrix = (And(Imp(pb, Eq(b, zero)), Or(Eq(b, n), psb)) if dual else
              And(Or(Eq(b, zero), pb), Imp(psb, Eq(b, n))))
    return close_native(matrix)


def shared(P, dual=False):
    pb, pc = subst(P, "x", b), subst(P, "x", c)
    inner = (And(Imp(pb, Eq(b, zero)), Or(Eq(b, n), pc)) if dual else
             And(Or(Eq(b, zero), pb), Imp(pc, Eq(b, n))))
    return close_native(Ex("c", And(Eq(c, S(b)), inner)))


def graph_kernel(value_eq, dual=False):
    if dual:
        return And(Imp(Eq(x, b), Imp(value_eq, Eq(b, zero))),
                   Imp(Eq(x, S(b)), Or(Eq(b, n), value_eq)))
    return And(Imp(Eq(x, b), Or(Eq(b, zero), value_eq)),
               Imp(Eq(x, S(b)), Imp(value_eq, Eq(b, n))))


def zero_graph(t, dual=False):
    matrix = All("x", All("y", Imp(Eq(t, y), graph_kernel(Eq(y, zero), dual))))
    return close_native(matrix)


def equation_graph(s, t, dual=False):
    matrix = All("x", All("u", All("v", Imp(
        And(Eq(s, u), Eq(t, v)), graph_kernel(Eq(u, v), dual)))))
    return close_native(matrix)


def syntax_checks():
    rng = random.Random(20261102)
    leaves = [x, a, zero]
    desc0 = App("S", V("v"))
    desc1 = App("R", V("v"), V("w"), descriptor=desc0)

    def term(depth):
        if depth == 0 or rng.random() < .25:
            return rng.choice(leaves)
        choice = rng.randrange(4)
        if choice == 0:
            return S(term(depth - 1))
        return App("R", term(depth - 1), term(depth - 1),
                   descriptor=(V("w"), desc0, desc1)[choice - 1])

    def formula(depth):
        if depth == 0 or rng.random() < .3:
            return Eq(term(3), term(3))
        return rng.choice([And, Or, Imp])(formula(depth - 1), formula(depth - 1))

    assertions = 0
    for _ in range(250):
        P = formula(3)
        s0, t0 = term(5), term(5)
        for full in (False, True):
            F, j = size(P, full), occurrences(P, "x")
            T, i = size(t0, full), occurrences(t0, "x")
            E = size(Eq(s0, t0), full)
            for dual in (False, True):
                assert size(native(P, dual), full) == 2 * F + j + 12
                assert size(shared(P, dual), full) == 2 * F + 18
                assert size(zero_graph(t0, dual), full) == T + 32
                assert size(equation_graph(s0, t0, dual), full) == E + 35
                assertions += 4

    def successor_chain(k):
        t = x
        for _ in range(k): t = S(t)
        return t

    def duplicated_x(k):
        t = x
        for _ in range(k):
            t = App("R", t, t, descriptor=V("w"))
        return t

    examples = []
    for name, s0, t0 in [
        ("atomic equality", x, a),
        ("25 successors", successor_chain(25), a),
        ("repeated input", duplicated_x(3), zero),
        ("nested stored descriptions", App("R", successor_chain(20), a,
          descriptor=App("R", V("v"), V("w"),
            descriptor=subst(successor_chain(20), "x", V("v")))), a),
    ]:
        P = Eq(s0, t0)
        examples.append({"name": name, "active_formula": size(P, False),
                         "full_formula": size(P), "input_occurrences": occurrences(P, "x"),
                         "native_full": size(native(P)), "shared_full": size(shared(P)),
                         "graph_full": size(equation_graph(s0, t0)),
                         "best_full": min(size(native(P)), size(shared(P)),
                                          size(equation_graph(s0, t0)))})
    repeated_formula = Eq(x, a)
    for _ in range(3): repeated_formula = And(repeated_formula, repeated_formula)
    general_example = {
        "name": "eight repeated equality atoms in a conjunction",
        "full_formula": size(repeated_formula),
        "input_occurrences": occurrences(repeated_formula, "x"),
        "native_full": size(native(repeated_formula)),
        "shared_full": size(shared(repeated_formula)),
        "note": "The atomic equation graph template does not directly apply to a conjunction."
    }
    return {"randomized_exact_count_assertions": assertions, "examples": examples,
            "general_formula_sharing_example": general_example}


def implies(a, b): return not a or b


def matrix_native(z, s, P, n0, b0, dual=False):
    if dual:
        return implies(P[b0], b0 == z) and (b0 == n0 or P[s[b0]])
    return (b0 == z or P[b0]) and implies(P[s[b0]], b0 == n0)


def matrix_shared(z, s, P, n0, b0, dual=False):
    for c0 in range(len(s)):
        if c0 != s[b0]: continue
        if dual:
            result = implies(P[b0], b0 == z) and (b0 == n0 or P[c0])
        else:
            result = (b0 == z or P[b0]) and implies(P[c0], b0 == n0)
        if result: return True
    return False


def value_kernel(z, s, n0, b0, x0, value_eq, dual=False):
    if dual:
        return (implies(x0 == b0, implies(value_eq, b0 == z)) and
                implies(x0 == s[b0], b0 == n0 or value_eq))
    return (implies(x0 == b0, b0 == z or value_eq) and
            implies(x0 == s[b0], implies(value_eq, b0 == n0)))


def matrix_zero_graph(z, s, t, n0, b0, dual=False):
    domain = range(len(s))
    return all(implies(t[x0] == y0, value_kernel(
        z, s, n0, b0, x0, y0 == z, dual)) for x0 in domain for y0 in domain)


def matrix_equation_graph(z, s, t, r, n0, b0, dual=False):
    domain = range(len(s))
    return all(implies(t[x0] == u0 and r[x0] == v0, value_kernel(
        z, s, n0, b0, x0, u0 == v0, dual))
        for x0 in domain for u0 in domain for v0 in domain)


def finite_model_checks():
    counts = {"shared_matrix_equivalences": 0, "zero_graph_matrix_equivalences": 0,
              "equation_graph_matrix_equivalences": 0, "induction_implications": 0}
    # Every arbitrary successor map is included, not only injective successors.
    # The designated zero can be fixed at 0 without loss of cases up to relabeling.
    for k in range(1, 5):
        domain = range(k)
        for s in product(domain, repeat=k):
            for P in product((False, True), repeat=k):
                for dual in (False, True):
                    for n0 in domain:
                        for b0 in domain:
                            assert matrix_native(0, s, P, n0, b0, dual) == matrix_shared(
                                0, s, P, n0, b0, dual)
                            counts["shared_matrix_equivalences"] += 1
                    all_boundary = all(any(matrix_native(0, s, P, n0, b0, dual)
                                           for b0 in domain) for n0 in domain)
                    Q = tuple(not p for p in P) if dual else P
                    base = Q[0]
                    progress = all(implies(Q[x0], Q[s[x0]]) for x0 in domain)
                    assert implies(all_boundary and base and progress, all(Q))
                    counts["induction_implications"] += 1

    for k in range(1, 4):
        domain = range(k)
        functions = list(product(domain, repeat=k))
        for s in functions:
            for t in functions:
                P = tuple(value == 0 for value in t)
                for dual in (False, True):
                    for n0 in domain:
                        for b0 in domain:
                            assert matrix_native(0, s, P, n0, b0, dual) == matrix_zero_graph(
                                0, s, t, n0, b0, dual)
                            counts["zero_graph_matrix_equivalences"] += 1
                for r in functions:
                    P = tuple(t[i] == r[i] for i in domain)
                    for dual in (False, True):
                        for n0 in domain:
                            for b0 in domain:
                                assert matrix_native(0, s, P, n0, b0, dual) == matrix_equation_graph(
                                    0, s, t, r, n0, b0, dual)
                                counts["equation_graph_matrix_equivalences"] += 1
    return counts


def scan_checks():
    checks = 0
    last_n = 10
    for P in product((False, True), repeat=last_n + 2):
        b0 = d0 = 0
        for n0 in range(last_n + 1):
            assert (b0 == 0 or P[b0]) and implies(P[b0 + 1], b0 == n0)
            assert implies(P[d0], d0 == 0) and (d0 == n0 or P[d0 + 1])
            checks += 2
            if n0 < last_n:
                b0 = n0 + 1 if P[b0 + 1] else b0
                d0 = d0 if P[d0 + 1] else n0 + 1
    return {"truth_tables": 2 ** (last_n + 2), "targets_per_table": last_n + 1,
            "invariant_checks": checks}


def main():
    result = {"scope": "Exact AST counts and finite regression tests; not a proof of full bi-interpretability.",
              "syntax": syntax_checks(), "finite_models": finite_model_checks(),
              "primitive_recursive_scans": scan_checks()}
    target = Path(__file__).with_name("compression_results.json")
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__": main()
