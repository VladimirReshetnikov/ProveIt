#!/usr/bin/env python3
"""Emit the primary Polarity-aware boundary arithmetic schema in the report.

Usage, from the archive directory:
    python3 checks/emit_axiom.py input.json
    python3 checks/emit_axiom.py --example long-negative-zero
    python3 checks/emit_axiom.py --demo
    python3 checks/emit_axiom.py --self-test

With no file or option, read one JSON formula from standard input.
Example input: ["imp", ["eq", ["var", "x"], ["zero"]], ["false"]]

Input term grammar:
    ["var", name] | ["zero"] | ["S", term]
    ["R", descriptor_h, counter_term, seed_term]
Every descriptor is a finite term whose active variables are only v,w.
Descriptions inside an R call are frozen; its two active arguments are not.
Input formula grammar:
    ["eq", term, term] | ["false"]
    ["and", formula, formula] | ["or", formula, formula]
    ["imp", formula, formula]
Its active free variables must be contained in {x,a}.

The output adds ["forall", variable, formula] and
["exists", variable, formula] nodes.  It includes the selected expanded
first-order AST, active/full sizes, and the sizes of every candidate.
No placeholder predicates, free sharing, numerical evaluator, semantic
simplification, or arbitrary uninterpreted function is accepted.

Exactly one leading implication to ["false"] is removed, selecting the
negative boundary.  No sentence is emitted if x has no active occurrence.
The primary generator does not implement the separate optional covered
emitter discussed in the report.  Full-size ties are broken in this order:
direct, successor-sharing, zero graph, general equation graph.

The self-test uses the independently implemented verify_compression.py
counter and checks the strict comparison with the old three-template
fused-boundary envelope on actual legal binary terms.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import random
import sys


class InputError(ValueError):
    """An input is outside the finite language of the report."""


INPUT_NAMES = frozenset({"x", "a"})
DESCRIPTOR_NAMES = frozenset({"v", "w"})
TIE_ORDER = {"direct": 0, "successor-sharing": 1, "zero-graph": 2,
             "equation-graph": 3}


def _shape(expr, length, path):
    if not isinstance(expr, list) or len(expr) != length:
        raise InputError(f"{path}: expected an array of length {length}")


def validate_term(term, allowed=INPUT_NAMES, path="$"):
    """Return active free variables and maximum finite descriptor rank."""
    if not isinstance(term, list) or not term or not isinstance(term[0], str):
        raise InputError(f"{path}: expected a tagged finite term array")
    tag = term[0]
    if tag == "var":
        _shape(term, 2, path)
        if not isinstance(term[1], str) or term[1] not in allowed:
            raise InputError(f"{path}: active variable must belong to {sorted(allowed)}")
        return {term[1]}, 0
    if tag == "zero":
        _shape(term, 1, path)
        return set(), 0
    if tag == "S":
        _shape(term, 2, path)
        return validate_term(term[1], allowed, path + "[1]")
    if tag == "R":
        _shape(term, 4, path)
        _, hrank = validate_term(term[1], DESCRIPTOR_NAMES, path + "[1]")
        fv1, rank1 = validate_term(term[2], allowed, path + "[2]")
        fv2, rank2 = validate_term(term[3], allowed, path + "[3]")
        # The symbol R_h is introduced strictly after every symbol in h.
        # Its arguments may be terms from any later finite stage.
        return fv1 | fv2, max(hrank + 1, rank1, rank2)
    raise InputError(f"{path}: unsupported term constructor {tag!r}")


def validate_formula(formula, path="$"):
    if not isinstance(formula, list) or not formula or not isinstance(formula[0], str):
        raise InputError(f"{path}: expected a tagged quantifier-free formula array")
    tag = formula[0]
    if tag == "false":
        _shape(formula, 1, path)
        return set(), 0
    if tag == "eq":
        _shape(formula, 3, path)
        fv1, rank1 = validate_term(formula[1], INPUT_NAMES, path + "[1]")
        fv2, rank2 = validate_term(formula[2], INPUT_NAMES, path + "[2]")
        return fv1 | fv2, max(rank1, rank2)
    if tag in {"and", "or", "imp"}:
        _shape(formula, 3, path)
        fv1, rank1 = validate_formula(formula[1], path + "[1]")
        fv2, rank2 = validate_formula(formula[2], path + "[2]")
        return fv1 | fv2, max(rank1, rank2)
    raise InputError(f"{path}: unsupported formula constructor {tag!r}")


def size(expr, full=True):
    """A tree count: repeated descriptions are charged at every call."""
    tag = expr[0]
    if tag in {"var", "zero", "false"}:
        return 1
    if tag == "S":
        return 1 + size(expr[1], full)
    if tag == "R":
        return (1 + size(expr[2], full) + size(expr[3], full)
                + (size(expr[1], full) if full else 0))
    if tag in {"eq", "and", "or", "imp"}:
        return 1 + size(expr[1], full) + size(expr[2], full)
    if tag in {"forall", "exists"}:
        return 1 + size(expr[2], full)
    raise ValueError(f"Unexpected internal node {tag!r}")


def occurrences(expr, name="x"):
    tag = expr[0]
    if tag == "var":
        return int(expr[1] == name)
    if tag in {"zero", "false"}:
        return 0
    if tag == "S":
        return occurrences(expr[1], name)
    if tag == "R":
        return occurrences(expr[2], name) + occurrences(expr[3], name)
    if tag in {"eq", "and", "or", "imp"}:
        return occurrences(expr[1], name) + occurrences(expr[2], name)
    if tag in {"forall", "exists"}:
        return 0 if expr[1] == name else occurrences(expr[2], name)
    raise ValueError(f"Unexpected internal node {tag!r}")


def substitute(expr, replacement, name="x"):
    """Substitute only active occurrences; descriptor syntax stays frozen."""
    tag = expr[0]
    if tag == "var":
        return replacement if expr[1] == name else expr
    if tag in {"zero", "false"}:
        return expr
    if tag == "S":
        return ["S", substitute(expr[1], replacement, name)]
    if tag == "R":
        return ["R", expr[1], substitute(expr[2], replacement, name),
                substitute(expr[3], replacement, name)]
    if tag in {"eq", "and", "or", "imp"}:
        return [tag, substitute(expr[1], replacement, name),
                substitute(expr[2], replacement, name)]
    if tag in {"forall", "exists"}:
        return expr if expr[1] == name else [tag, expr[1], substitute(expr[2], replacement, name)]
    raise ValueError(f"Unexpected internal node {tag!r}")


def Var(name): return ["var", name]
def Zero(): return ["zero"]
def Succ(term): return ["S", term]
def Eq(left, right): return ["eq", left, right]
def And(left, right): return ["and", left, right]
def Or(left, right): return ["or", left, right]
def Imp(left, right): return ["imp", left, right]
def All(name, formula): return ["forall", name, formula]
def Exists(name, formula): return ["exists", name, formula]


def _prefix(matrix):
    return All("a", All("n", Exists("b", matrix)))


def _boundary_matrix(E, second_input, negative):
    eb = substitute(E, Var("b"))
    ec = substitute(E, second_input)
    if negative:
        return And(Imp(eb, Eq(Var("b"), Zero())), Or(Eq(Var("b"), Var("n")), ec))
    return And(Or(Eq(Var("b"), Zero()), eb), Imp(ec, Eq(Var("b"), Var("n"))))


def _graph_matrix(value_equality, negative):
    at_b = Eq(Var("x"), Var("b"))
    at_sb = Eq(Var("x"), Succ(Var("b")))
    if negative:
        return And(Imp(at_b, Imp(value_equality, Eq(Var("b"), Zero()))),
                   Imp(at_sb, Or(Eq(Var("b"), Var("n")), value_equality)))
    return And(Imp(at_b, Or(Eq(Var("b"), Zero()), value_equality)),
               Imp(at_sb, Imp(value_equality, Eq(Var("b"), Var("n")))))


def make_candidates(E, negative):
    result = [
        ("direct", _prefix(_boundary_matrix(E, Succ(Var("b")), negative))),
        ("successor-sharing", _prefix(Exists("c", And(
            Eq(Var("c"), Succ(Var("b"))), _boundary_matrix(E, Var("c"), negative)))))
    ]
    if E[0] == "eq":
        left, right = E[1], E[2]
        # Literal zero, not a term discovered to compute zero.
        if left == ["zero"] or right == ["zero"]:
            tail = right if left == ["zero"] else left
            result.append(("zero-graph", _prefix(All("x", All("y", Imp(
                Eq(tail, Var("y")), _graph_matrix(Eq(Var("y"), Zero()), negative)))))))
        result.append(("equation-graph", _prefix(All("x", All("u", All("v", Imp(
            And(Eq(left, Var("u")), Eq(right, Var("v"))),
            _graph_matrix(Eq(Var("u"), Var("v")), negative))))))))
    return result


def emit(formula):
    fv, rank = validate_formula(formula)
    j = occurrences(formula)
    result = {
        "input_formula": formula,
        "active_free_variables": sorted(fv),
        "input_active_size": size(formula, False),
        "input_full_size": size(formula, True),
        "input_x_occurrences": j,
        "maximum_descriptor_rank": rank,
    }
    if j == 0:
        result.update({"omitted": True, "reason": "No active free occurrence of x.",
                       "polarity": None, "selected_template": None, "selected_ast": None,
                       "active_size": 0, "full_size": 0, "candidates": []})
        return result
    negative = formula[0] == "imp" and formula[2] == ["false"]
    E = formula[1] if negative else formula
    candidates = make_candidates(E, negative)
    counts = [{"template": name, "active_size": size(ast, False), "full_size": size(ast, True)}
              for name, ast in candidates]
    chosen_name, chosen_ast = min(candidates, key=lambda item:
                                 (size(item[1], True), TIE_ORDER[item[0]]))
    result.update({"omitted": False, "polarity": "negative" if negative else "positive",
                   "stripped_outer_negations": int(negative),
                   "boundary_payload": E,
                   "payload_active_size": size(E, False), "payload_full_size": size(E, True),
                   "payload_x_occurrences": occurrences(E),
                   "selected_template": chosen_name, "selected_ast": chosen_ast,
                   "active_size": size(chosen_ast, False), "full_size": size(chosen_ast, True),
                   "candidates": counts,
                   "tie_order": list(TIE_ORDER)})
    return result


def successor_chain(length, variable="x"):
    term = Var(variable)
    for _ in range(length): term = Succ(term)
    return term


def examples():
    repeated = Eq(Var("x"), Var("a"))
    for _ in range(3): repeated = And(repeated, repeated)
    descriptor = successor_chain(40, "v")
    return {
        "atomic-equality": Eq(Var("x"), Var("a")),
        "long-negative-zero": Imp(Eq(successor_chain(39), Zero()), ["false"]),
        "shared-successor": repeated,
        "long-negative-equation": Imp(Eq(successor_chain(25), Var("a")), ["false"]),
        "large-frozen-descriptor": Eq(["R", descriptor, Var("x"), Var("a")], Zero()),
        "zero-on-left": Imp(Eq(Zero(), successor_chain(25)), ["false"]),
        "vacuous-input": Eq(["R", Succ(Var("v")), Zero(), Var("a")], Zero()),
        "strip-one-negation": Imp(Imp(Eq(Var("x"), Var("a")), ["false"]), ["false"]),
    }


def demo():
    output = []
    for name, formula in examples().items():
        result = emit(formula)
        output.append({"name": name, "input_formula": formula,
                       "selected_template": result["selected_template"],
                       "polarity": result["polarity"], "active_size": result["active_size"],
                       "full_size": result["full_size"], "candidates": result["candidates"]})
    return {"usage": "Use --example NAME to obtain the complete emitted AST.", "examples": output}


def self_test():
    import verify_compression as reference

    def convert(expr):
        tag = expr[0]
        if tag == "var": return reference.V(expr[1])
        if tag == "zero": return reference.C()
        if tag == "false": return reference.Node("false")
        if tag == "S": return reference.S(convert(expr[1]))
        if tag == "R":
            return reference.App("R", convert(expr[2]), convert(expr[3]), descriptor=convert(expr[1]))
        if tag in {"eq", "and", "or", "imp"}:
            constructor = {"eq": reference.Eq, "and": reference.And,
                           "or": reference.Or, "imp": reference.Imp}[tag]
            return constructor(convert(expr[1]), convert(expr[2]))
        if tag in {"forall", "exists"}:
            constructor = reference.All if tag == "forall" else reference.Ex
            return constructor(expr[1], convert(expr[2]))
        raise AssertionError(tag)

    rng = random.Random(20261102)
    descriptors = [Var("v"), Var("w"), Zero(), Succ(Var("v")),
                   ["R", Succ(Var("v")), Var("v"), Var("w")]]

    def term(depth):
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice([Var("x"), Var("a"), Zero()])
        if rng.randrange(3) == 0:
            return Succ(term(depth - 1))
        return ["R", rng.choice(descriptors), term(depth - 1), term(depth - 1)]

    def formula(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return Eq(term(3), term(3))
        return rng.choice([And, Or, Imp])(formula(depth - 1), formula(depth - 1))

    formulas = list(examples().values()) + [formula(3) for _ in range(200)]
    # Include both signs for every generated nonnegative source.
    formulas += [Imp(P, ["false"]) for P in list(formulas)]
    comparison_assertions = 0
    for P in formulas:
        emitted = emit(P)
        assert size(P, True) == reference.size(convert(P), True)
        assert size(P, False) == reference.size(convert(P), False)
        assert occurrences(P) == reference.occurrences(convert(P), "x")
        comparison_assertions += 3
        if emitted["omitted"]:
            assert occurrences(P) == 0 and emitted["full_size"] == 0
            continue
        E = emitted["boundary_payload"]
        i, F = occurrences(E), size(E)
        for name, candidate in make_candidates(E, emitted["polarity"] == "negative"):
            assert size(candidate, True) == reference.size(convert(candidate), True)
            assert size(candidate, False) == reference.size(convert(candidate), False)
            comparison_assertions += 2
            if name == "direct": assert size(candidate) == 2 * F + i + 12
            if name == "successor-sharing": assert size(candidate) == 2 * F + 18
            if name == "equation-graph": assert size(candidate) == F + 35
            if name == "zero-graph":
                t = E[2] if E[1] == ["zero"] else E[1]
                assert size(candidate) == size(t) + 32
        lowest = min(emitted["candidates"], key=lambda q:
                     (q["full_size"], TIE_ORDER[q["template"]]))
        assert lowest["template"] == emitted["selected_template"]

    terms = [term(5) for _ in range(500)] + [successor_chain(k) for k in range(65)]
    repeated = Var("x")
    for _ in range(7):
        terms.append(repeated)
        repeated = ["R", Var("w"), repeated, repeated]
    strict_cases = omitted_cases = 0
    for t in terms:
        validate_term(t)
        m, T, i = size(t, False), size(t, True), occurrences(t)
        assert T >= m >= 2 * i - 1
        chosen = emit(Imp(Eq(t, Zero()), ["false"]))
        if i == 0:
            assert chosen["omitted"] and chosen["full_size"] == 0
            omitted_cases += 1
        else:
            new = min(2 * T + i + 16, 2 * T + 22, T + 32)
            old = min(2 * T + i + 17, 2 * T + 22, T + 43)
            assert chosen["full_size"] == new
            assert new <= old - 1
            strict_cases += 1

    invalid = [
        ["eq", ["f", Var("x")], Zero()],
        ["eq", Var("v"), Zero()],
        ["eq", ["R", Var("a"), Var("x"), Zero()], Zero()],
        ["eq", ["R", Var("x"), Var("x"), Zero()], Zero()],
        ["eq", ["R", ["R", Var("a"), Var("v"), Var("w")], Var("x"), Zero()], Zero()],
        ["forall", "x", Eq(Var("x"), Zero())],
        ["S", Var("x")],
        ["false", "extra"],
        ["eq", ["zero", "extra"], Zero()],
    ]
    for P in invalid:
        try:
            emit(P)
        except InputError:
            pass
        else:
            raise AssertionError(f"Invalid input accepted: {P!r}")
    once = emit(examples()["strip-one-negation"])
    assert once["stripped_outer_negations"] == 1
    assert once["boundary_payload"] == examples()["strip-one-negation"][1]
    frozen = ["R", Succ(Var("v")), Var("x"), Var("a")]
    assert substitute(frozen, Succ(Var("b")))[1] == frozen[1]
    return {"status": "passed", "formula_inputs_checked": len(formulas),
            "independent_size_and_occurrence_assertions": comparison_assertions,
            "legal_binary_terms_checked": len(terms),
            "strict_old_envelope_comparisons": strict_cases,
            "vacuous_tail_omissions": omitted_cases,
            "malformed_or_out_of_language_inputs_rejected": len(invalid),
            "one_negation_only_check": True, "frozen_descriptor_check": True,
            "scope": "Generator conformance, independent exact counts, and legal-profile envelope checks; not full PRA proof verification."}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("input", nargs="?", help="JSON formula file; standard input if omitted")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--demo", action="store_true", help="show reproducible input examples and size summaries")
    group.add_argument("--example", choices=sorted(examples()), help="emit the complete AST for a built-in example")
    group.add_argument("--self-test", action="store_true", help="run conformance and independent count checks")
    args = parser.parse_args(argv)
    if args.input and (args.demo or args.example or args.self_test):
        parser.error("a positional input cannot be combined with an example or test option")
    try:
        if args.demo:
            result = demo()
        elif args.example:
            result = emit(examples()[args.example])
        elif args.self_test:
            result = self_test()
        else:
            text = Path(args.input).read_text() if args.input else sys.stdin.read()
            result = emit(json.loads(text))
    except (InputError, json.JSONDecodeError, OSError, RecursionError) as exc:
        print(json.dumps({"error": str(exc), "status": "invalid-input"}), file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
