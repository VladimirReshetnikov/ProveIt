# PRA with polarity-aware boundary axioms

Research report prepared for Vladimir Reshetnikov, 2 November 2026.

## Start here

`pra_polarity_boundary.pdf` is the complete report. Its LaTeX source is
`pra_polarity_boundary.tex` together with `sections/`.

The report audits seven current proposals and six archived proposals at
ProveIt commit `356163ca545206e31dd6b634f9c9bfc1596b3cac`. All seven current
proposals contain a real improvement over the archived iteration. Their
optional constructions, including the existing one-copy term table, are
included in the comparison.

The main new ingredients are a dual boundary for negative predicates and
a one-occurrence numerical value graph. The core language starts with
0 and successor and uses one uniform family of initialized binary
recursors. Its only fixed nonlogical sentence is `0 != S(0)`.

For a common numerical test of full size T and i > 0 active occurrences of
the induction variable, the new cost is

    min(2*T + i + 16, 2*T + 22, T + 32).

It is strictly smaller than the current fused-boundary draft's full
three-template envelope for genuine binary term trees. The report also
compares the native-formula, covered, Boolean-only, and active-size
alternatives, with their support costs and language restrictions stated.
For repeated covered instances, a separately declared presentation adds
the already-provable ten-node coverage sentence. Its fixed seed costs 16
nodes, and its recurring bound is min(2*T+i+16, 2*T+18, T+32). This is
cheaper finite support than deriving coverage through the primary emitter's
28-node atomic boundary instance; the six-node primary seed is unchanged.
This is not an absolute shortest-axiomatization theorem.

## Contents and verification scope

- `AXIOMS.txt`: the complete conceptual core and the optimized schema rules.
- `proofs/BoundaryCompression.lean`: checked constructive equivalences,
  induction kernels, and natural-number witness scans. It has no `sorry`.
- `proofs/lean_check.txt` and `proofs/lean_check.json`: the successful
  Lean 4.19.0 check and exact source hash. Every printed theorem dependency
  report says that it depends on no axioms.
- `checks/verify_compression.py`: exact syntax counts, frozen-descriptor
  substitution checks, finite arbitrary-carrier regressions, and scan checks.
- `checks/compression_results.json`: recorded successful results.
- `checks/emit_axiom.py`: an executable finite syntax emitter for the
  primary optimized theory; see its module documentation and `--help`.
- `provenance/source_manifest.json`: exact source ZIP identifiers, hashes,
  immutable links, and relevant extracted TeX paths.

The complete first-order bi-interpretation, arithmetic bootstrap, pairing,
and identity round trips have written proofs in the report. They are not
claimed to have been fully formalized in Lean. Finite computations are
regression checks, not proofs for arbitrary models.

## Rebuild

From this directory, with a normal TeX Live installation:

```bash
pdflatex -interaction=nonstopmode -halt-on-error pra_polarity_boundary.tex
pdflatex -interaction=nonstopmode -halt-on-error pra_polarity_boundary.tex
```

With Python 3.10 or newer, no third-party packages are needed for the checks:

```bash
python3 checks/verify_compression.py
python3 checks/emit_axiom.py --demo
```

With Lean 4.19.0 installed, no Mathlib project is needed:

```bash
lean proofs/BoundaryCompression.lean
```

The optional covered emitter is proved in the report and its existing
clause is written in full, including the explicit-coverage presentation
with a 16-node fixed seed. The primary Python emitter does not silently
enable either covered option: coverage support is accounted for separately.

## Interpretation convention

PRA means its first-order presentation with quantifier-free induction and
function symbols indexed by finite primitive-recursive descriptions.
Both interpretations have the whole carrier as their domain and preserve
native equality; both definable composite isomorphisms are the identity.
The construction works separately in classical and intuitionistic logic.

## Attribution

The native arithmetic architecture and triangular coding proof are inherited
from the inspected drafts and cited in the report. The polarity-aware
boundary, its value-graph optimization, the combined exact cost comparison,
and the stated restricted optimality argument are the contributions of
this iteration. No authorship or global historical novelty claim is made
for the general idea that an induction counterexample has a boundary.
