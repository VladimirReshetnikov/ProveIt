#!/usr/bin/env python3
"""Exhaustive, unpruned local synthesis for a counter-free swap comparator.

Grammar: t ::= 0 | a | v | S(t) | D(t,t) | C(t,t,t).
Every leaf and application costs one node.  Here C(z,x,y) is x at z=0
and y otherwise, while D(x,y)=max(y-x,0)+max(x-y-1,0).

An update t determines U_t(0,a)=a and
U_t(n+1,a)=t(a,U_t(a,n)).  We test the NECESSARY requirements
    U_t(1,1) != 1,
    x != a ==> U_t(x,a) = a.
Every refuted term has an actual finite numerical counterexample; no
assumed intermediate U value is used in its certificate.  Enumeration
is by complete ordered syntax trees without semantic pruning.

Running this file generates a JSON certificate and then independently
re-evaluates every retained witness.  The unique nine-node survivor on
the stated grid has a separate universal mathematical proof.  Neither
this search nor its local lower bound is a proof of global minimality.
"""
import argparse
import json
from functools import lru_cache
from pathlib import Path


def trees_through(bound):
    """Deterministic order, used as the certificate's term identifier."""
    layers = [[], [(0,), (1,), (2,)]]
    for size in range(2, bound + 1):
        terms = [(3, t) for t in layers[size - 1]]
        for left_size in range(1, size - 1):
            right_size = size - 1 - left_size
            terms.extend((4, x, y) for x in layers[left_size]
                         for y in layers[right_size])
        for test_size in range(1, size - 2):
            for yes_size in range(1, size - 1 - test_size):
                no_size = size - 1 - test_size - yes_size
                if no_size > 0:
                    terms.extend((5, x, y, z) for x in layers[test_size]
                                 for y in layers[yes_size]
                                 for z in layers[no_size])
        layers.append(terms)
    return layers


def body_value(t, a, v):
    op = t[0]
    if op == 0:
        return 0
    if op == 1:
        return a
    if op == 2:
        return v
    if op == 3:
        return body_value(t[1], a, v) + 1
    if op == 4:
        x, y = body_value(t[1], a, v), body_value(t[2], a, v)
        return max(y - x, 0) + max(x - y - 1, 0)
    z = body_value(t[1], a, v)
    return body_value(t[2] if z == 0 else t[3], a, v)


def pretty(t):
    if t[0] < 3:
        return ('0', 'a', 'v')[t[0]]
    return ('S', 'D', 'C')[t[0] - 3] + '(' + ','.join(
        pretty(x) for x in t[1:]) + ')'


def evaluator(t):
    @lru_cache(None)
    def value(x, a):
        if x == 0:
            return a
        return body_value(t, a, value(a, x - 1))
    return value


def first_counterexample(t, grid):
    value = evaluator(t)
    # These are actual executions, not assumed recurrence inputs.
    for x, a in [(1, 0), (2, 0), (1, 2)]:
        if value(x, a) != a:
            return [x, a, value(x, a)]
    if value(1, 1) == 1:
        return [1, 1, 1]
    if value(2, 1) != 1:
        return [2, 1, value(2, 1)]
    for x in range(grid):
        for a in range(grid):
            if x != a and value(x, a) != a:
                return [x, a, value(x, a)]
    return None


def make_certificate(bound=9, grid=9):
    layers = trees_through(bound)
    data = {
        'grammar': '0 | a | v | S(t) | D(t,t) | C(t,t,t)',
        'measure': 'one node per leaf and application',
        'requirements': ['U(1,1) != 1', 'x != a implies U(x,a) = a'],
        'grid': grid, 'bound': bound,
        'witness_format': '[term_index, x, a, U_t(x,a)]',
        'diagonal_witness': '[term_index,1,1,1] refutes the first requirement',
        'layers': [],
        'scope': 'Local grammar only; no global axiomatization minimum',
    }
    for size in range(1, bound + 1):
        witnesses, survivors = [], []
        for index, t in enumerate(layers[size]):
            witness = first_counterexample(t, grid)
            if witness is None:
                survivors.append({'index': index, 'term': pretty(t)})
            else:
                witnesses.append([index, *witness])
        data['layers'].append({'size': size, 'term_count': len(layers[size]),
                               'witnesses': witnesses,
                               'survivors': survivors})
    return data


def verify_certificate(data):
    layers = trees_through(data['bound'])
    checked = 0
    for row in data['layers']:
        size = row['size']
        terms = layers[size]
        assert len(terms) == row['term_count']
        indices = set()
        for index, x, a, expected in row['witnesses']:
            assert index not in indices
            indices.add(index)
            observed = evaluator(terms[index])(x, a)
            assert observed == expected
            if x == a:
                assert (x, a, observed) == (1, 1, 1)
            else:
                assert observed != a
            checked += 1
        for survivor in row['survivors']:
            index = survivor['index']
            assert index not in indices
            indices.add(index)
            assert pretty(terms[index]) == survivor['term']
            assert first_counterexample(terms[index], data['grid']) is None
        assert indices == set(range(len(terms)))
    assert all(not row['survivors'] for row in data['layers'][:8])
    assert [s['term'] for s in data['layers'][8]['survivors']] == [
        'C(D(a,S(v)),S(S(v)),a)']
    return checked


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', default='counterfree_bump_certificate.json')
    p.add_argument('--verify-only', action='store_true')
    args = p.parse_args()
    path = Path(args.output)
    if args.verify_only:
        data = json.loads(path.read_text())
    else:
        data = make_certificate()
        path.write_text(json.dumps(data, separators=(',', ':')) + '\n')
    checked = verify_certificate(data)
    print(json.dumps({
        'term_counts': [r['term_count'] for r in data['layers']],
        'survivor_counts': [len(r['survivors']) for r in data['layers']],
        'verified_finite_counterexamples': checked,
        'minimum_size': 9,
        'survivor': data['layers'][8]['survivors'][0]['term'],
        'certificate_bytes': path.stat().st_size,
        'scope': data['scope'],
    }, indent=2))


if __name__ == '__main__':
    main()
