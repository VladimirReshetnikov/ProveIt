#!/usr/bin/env python3
"""Reproduce the report's partial formula and selected-program ledgers.

All binders, leaves, applications, connectives and equality cost one node.
Binder names are labels. Negation expands to implication to falsity.
These ledgers do not measure the entire axiom enumerator or prove a global
minimum. The formula-schema basis has its own, explicitly separate ledger.
"""
import json
from pathlib import Path


def node(label, *args):
    return (label, *args)


def size(t):
    return 1 + sum(map(size, t[1:]))


def all_(variables, body):
    for v in reversed(variables):
        body = node('forall ' + v[0], body)
    return body


def eq(a, b):
    return node('=', a, b)


def arrow(a, b):
    return node('->', a, b)


def succ(a):
    return node('S', a)


z, n, a, v = [node(x) for x in ('0', 'n', 'a', 'v')]
separator = arrow(eq(z, succ(z)), node('bottom'))


def term_schema(m, fresh, counter):
    frozen = [node('b' + str(i)) for i in range(m - 1)]
    params = [a, *frozen]
    r0 = node('R', z, *params)
    rs = node('R', succ(n), *params)
    recursive = node('R', a, n, *frozen)
    base = all_(params, eq(r0, a))
    update_args = ([n] if counter else []) + params + [recursive]
    step = all_([n, *params], eq(rs, node('h', *update_args)))
    fparams = frozen if fresh else params
    fn = node('f', n, *fparams)
    fs = node('f', succ(n), *fparams)
    f0 = node('f', z, *fparams)
    premise = all_([n], eq(fs, fn))
    conclusion = all_([n], node('or', eq(node('B', f0, a), a), eq(fn, a)))
    if fresh:
        schema = all_(frozen, arrow(premise, all_([a], conclusion)))
    else:
        schema = all_(params, arrow(premise, conclusion))
    trees = {'base': base, 'step': step, 'separator': separator, 'schema': schema}
    return {'parts': {k: size(t) for k, t in trees.items()},
            'display': sum(size(t) for t in trees.values()), 'trees': trees}


def ordinary_schema(k, q):
    frozen = [node('b' + str(i)) for i in range(k)]
    p = [a, *frozen]
    base = all_(p, eq(node('I', z, *p), a))
    step = all_([n, *p], eq(node('I', succ(n), *p),
                           node('h', n, *frozen, node('I', n, *p))))
    fp = [node('c' + str(i)) for i in range(q)]
    an, a0, ass = (node('A', x, *fp) for x in (n, z, succ(n)))
    qfi = all_(fp, arrow(node('and', a0, all_([n], arrow(an, ass))), all_([n], an)))
    parts = {'base': size(base), 'step': size(step),
             'separator': size(separator), 'QFI': size(qfi)}
    return {'parts': parts, 'display': sum(parts.values()),
            'formula_metavariable': True,
            'selected_axiom_helper_bodies': 0,
            'optional_proof_only_predecessor_body': 1}


def compute():
    c = lambda *args: node('C', *args)
    d = lambda *args: node('D', *args)
    bodies = {'C': node('b'), 'D': v,
              'T6': c(d(a, n), n, a),
              'U9': c(d(a, succ(v)), succ(succ(v)), a),
              'U12': c(d(a, v), c(d(v, a), a, succ(a)), a)}
    costs = {k: size(t) for k, t in bodies.items()}
    assert costs == {'C': 1, 'D': 1, 'T6': 6, 'U9': 9, 'U12': 12}
    rows = []
    for m in range(1, 9):
        for name, fresh, counter, helpers, formula in [
            ('current_best', False, True, 8, 11 * m + 39),
            ('independent_probe_P', True, True, 8, 11 * m + 35),
            ('current_counterfree', False, False, 14, 11 * m + 38),
            ('nine_node_counterfree_N', True, False, 11, 11 * m + 34),
        ]:
            row = term_schema(m, fresh, counter)
            assert row['display'] == formula
            row.update(name=name, m=m, helper_bodies=helpers,
                       subtotal=row['display'] + helpers)
            if m != 1:
                row.pop('trees')
            rows.append(row)
    direct = ordinary_schema(0, 1)
    assert direct['parts'] == {'base': 6, 'step': 12, 'separator': 6, 'QFI': 19}
    assert direct['display'] == 43
    for k in range(4):
        for q in range(4):
            assert ordinary_schema(k, q)['display'] == 6 * k + 5 * q + 38
    return {'checks_passed': True, 'body_sizes': costs, 'bodies': bodies,
            'term_schema_rows': rows, 'separate_ordinary_QFI_example_k0_q1': direct,
            'qualifications': [
                'Representative templates, not total-description size.',
                'm counts the initializer/probe plus m-1 extra frozen parameters.',
                'The fresh probe is not an argument of f; extra parameters remain unrestricted.',
                'Recovery of a probe-dependent old instance can add a frozen parameter.',
                'The ordinary QFI ledger uses a formula metavariable, unlike the term-only rows.',
                'Proof-only programs are not charged in the selected axiom-body ledger.']}


if __name__ == '__main__':
    result = compute()
    out = Path(__file__).with_name('schema_metrics.json')
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'checks_passed': True, 'body_sizes': result['body_sizes'],
        'm1': [{k: row[k] for k in ('name', 'display', 'helper_bodies', 'subtotal')}
               for row in result['term_schema_rows'] if row['m'] == 1],
        'ordinary_QFI_display': 43}, indent=2))
