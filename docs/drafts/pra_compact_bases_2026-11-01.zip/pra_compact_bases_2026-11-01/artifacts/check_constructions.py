#!/usr/bin/env python3
"""Finite numerical diagnostics for the report's constructions.

These checks do not establish first-order bi-interpretability or facts about
nonstandard models. Those proofs are in the manuscript. This script checks
actual recursive executions against independently expressed numerical targets.
"""
import json
from functools import lru_cache
from pathlib import Path


def c(z, x, y):
    return x if z == 0 else y


def pred(x):
    return max(x - 1, 0)


def d(x, y):
    return max(y - x, 0) + max(x - y - 1, 0)


def swap(update, frozen=()):
    @lru_cache(None)
    def value(n, a):
        return a if n == 0 else update(n - 1, a, frozen, value(a, n - 1))
    return value


def cf(update, frozen=()):
    return swap(lambda n, a, b, v: update(a, b, v), frozen)


def reverse_fold(update, x, y, frozen=()):
    dx, dy, m = max(x - y, 0), max(y - x, 0), min(x, y)
    value = dy if dx == 0 else update(pred(dx), 0, frozen, pred(dx))
    for j in range(m):
        value = update(dx + j, dy + j + 1, frozen,
                       update(dy + j, dx + j, frozen, value))
    return value


def check():
    results = {}
    direct_d = swap(lambda n, a, b, v: v)
    t = swap(lambda n, a, b, v: c(d(a, n), n, a))
    u9 = cf(lambda a, b, v: c(d(a, v + 1), v + 2, a))
    u12 = cf(lambda a, b, v: c(d(a, v), c(d(v, a), a, a + 1), a))
    count = 0
    for x in range(100):
        for y in range(100):
            assert direct_d(x, y) == d(x, y)
            assert t(x, y) == (pred(y) if x == y else y)
            assert u9(x, y) == (y + 1 if x == y and x != 0 else y)
            assert u9(x, y) == u12(x, y)
            assert d(t(x + 1, y + 1), y + 1) == int(x == y)
            assert d(y + 1, u9(x + 1, y + 1)) == int(x == y)
            count += 1
    results['comparator_and_equality_input_pairs'] = count

    # Full-counter reverse compiler with nontrivial frozen-parameter dependence.
    updates = [lambda n, a, b, v: v,
               lambda n, a, b, v: n,
               lambda n, a, b, v: a,
               lambda n, a, b, v: v + n + b[0],
               lambda n, a, b, v: 2 * v + a + b[0],
               lambda n, a, b, v: a + n + b[0] if v % 3 == 0 else v // 2]
    count = 0
    for update in updates:
        for parameter in (0, 1, 3):
            direct = swap(update, (parameter,))
            for x in range(17):
                for y in range(17):
                    assert direct(x, y) == reverse_fold(update, x, y, (parameter,))
                    count += 1
    results['reverse_compiler_cases'] = count

    delta_r = cf(lambda a, b, v: v + 1)
    delta = lambda n: delta_r(n, n)
    decoder_r = cf(lambda a, b, v: v + 1 if a == delta(v + 1) else v)
    decode = lambda n: decoder_r(n, n)
    for z in range(150):
        assert delta(z) == 2 * z
        assert decode(delta(z)) == z
        assert decode(delta(z) + 1) == z
    results['tag_inverse_values'] = 150

    count = 0
    # The tag compiler uses the recursively computed encoder and decoder.
    examples = [
        ('successor_iterate', lambda b: b, lambda n, b, v: v + 1),
        ('triangular_accumulator', lambda b: b, lambda n, b, v: v + n + 1),
        ('bounded_toggle', lambda b: b % 2, lambda n, b, v: 1 - v),
        ('bounded_affine', lambda b: b, lambda n, b, v: (2 * v + n + b) % 19),
    ]
    for name, base, step in examples:
        for parameter in (0, 1, 3):
            def k(a, z):
                return base(parameter) if pred(a) == 0 else step(pred(pred(a)), parameter, z)
            def update(a, b, v):
                z = decode(v)
                return v + 1 if v == delta(z) else delta(k(a, z))
            recursive = cf(update)
            def out(n):
                return decode(recursive(n + 1, n + 1))
            expected = base(parameter)
            for n in range(12):
                assert out(n) == expected, (name, parameter, n, out(n), expected)
                expected = step(n, parameter, expected)
                count += 1
    results['counterfree_ordinary_compiler_values'] = count

    # Fixed truth tables for the error-bit compiler, including implication.
    for a in (0, 1):
        for b in (0, 1):
            aa, bb = (a == 0), (b == 0)
            assert (c(a, b, 1) == 0) == (aa and bb)
            assert (c(a, 0, b) == 0) == (aa or bb)
            assert (c(a, b, 0) == 0) == ((not aa) or bb)
    results['error_bit_truth_table_rows'] = 4
    results['checks_passed'] = True
    results['scope'] = 'Finite numerical diagnostics; full mathematical proofs are in the report.'
    return results


if __name__ == '__main__':
    result = check()
    Path(__file__).with_name('construction_checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
