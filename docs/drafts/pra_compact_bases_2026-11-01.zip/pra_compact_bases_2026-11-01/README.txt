SMALLER PRESENTATIONS OF PRIMITIVE RECURSIVE ARITHMETIC
1 November 2026

Main report: pra_compact_bases_2026-11-01.pdf
Editable source: pra_compact_bases_2026-11-01.tex

RESULTS

1. A short initialized ordinary-recursion basis with 0 != S0 and full
   quantifier-free induction. Successor injectivity and nonzeroness derive
   from a selected predecessor description. This is the recommended basis
   for readability, not a novelty or absolute minimum claim.

2. An independent-probe term-schema basis with the disclosed partial
   display/body ledger 46 + 8 = 54, versus the current best 50 + 8 = 58.
   The improvement removes a redundant probe input from the schematic
   term. It is a template-interface saving, not a claim that every expanded
   instance or every encoding shrinks by four symbols.

3. A counter-free variant with a new nine-node comparator update
       C(D(a,Sv),SSv,a).
   It replaces the older twelve-node body. Together with the independent
   probe, the partial ledger is 45 + 11 = 56, versus the older 49 + 14 = 63.
   The exhaustive certificate proves a restricted minimum in the fixed
   update grammar, not a globally shortest axiomatization.

For each matching classical or intuitionistic logic, all three theories
have explicit whole-domain, native-equality bi-interpretations with the
specified first-order PRA. Both round trips are provably the identity.
The proofs and all qualifications are in the report.

REPRODUCTION

Python 3, with no third-party Python packages, runs the artifacts:

  python3 artifacts/schema_metrics.py
  python3 artifacts/check_constructions.py
  python3 artifacts/counterfree_bump_exhaustive.py \
    --output artifacts/counterfree_bump_certificate.json --verify-only

To regenerate the exhaustive certificate, omit --verify-only.
The search enumerates all 155,574 ordered body trees through nine nodes
and retains/rechecks 155,573 concrete counterexamples. The unique survivor
has a universal proof in the manuscript; finite-grid survival alone is
not its correctness proof.

To run all checks and rebuild the PDF (requires latexmk and a standard
LaTeX installation with the packages listed in the TeX preamble):

  python3 build.py

The build writes temporary LaTeX output under _build and replaces the PDF
only after successful compilation. To check the archive's delivered bytes:

  sha256sum -c SHA256SUMS.txt

PROVENANCE AND VERIFICATION BOUNDARY

The eight requested drafts were reviewed at ProveIt commit
3abedb526f9557c7817899dbd5fcd9872a95c51d. The source manifest records
immutable URLs and verified Git/SHA-256 archive hashes. The original
archives are not duplicated in this package.

The written proofs cover the full metatheorems. The executable artifacts
are a syntax ledger, finite numerical diagnostics, and a finite exhaustive
program-synthesis certificate. They are not a Lean/Rocq formalization of
bi-interpretability. No end-to-end proof-assistant certificate is claimed.

The report distinguishes inherited constructions from its two new changes.
It includes Further research questions and explicitly labels the tempting
coverage/constancy-only alternative as unproved.
