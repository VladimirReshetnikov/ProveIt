#!/usr/bin/env python3
"""Run the reproducible checks and compile the report using latexmk."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
artifacts = root / 'artifacts'
for name in ('schema_metrics.py', 'check_constructions.py'):
    subprocess.run([sys.executable, str(artifacts / name)], cwd=root, check=True)
subprocess.run([sys.executable, str(artifacts / 'counterfree_bump_exhaustive.py'),
                '--output', str(artifacts / 'counterfree_bump_certificate.json'),
                '--verify-only'], cwd=root, check=True)
if shutil.which('latexmk') is None:
    raise SystemExit('Install latexmk and a standard LaTeX distribution to compile the PDF.')
build = root / '_build'
build.mkdir(exist_ok=True)
name = 'pra_compact_bases_2026-11-01'
with (build / 'latexmk-output.txt').open('w') as log:
    subprocess.run(['latexmk', '-pdf', '-interaction=nonstopmode', '-halt-on-error',
                    '-outdir=' + str(build), str(root / (name + '.tex'))],
                   cwd=root, check=True, stdout=log, stderr=subprocess.STDOUT)
shutil.copy2(build / (name + '.pdf'), root / (name + '.pdf'))
print(json.dumps({'checks_passed': True, 'pdf': name + '.pdf'}, indent=2))
