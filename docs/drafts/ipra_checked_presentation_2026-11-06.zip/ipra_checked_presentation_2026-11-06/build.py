"""Reproduce the checks, measurements, PDF, and deliverable hashes."""

import hashlib
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(arguments):
    result = subprocess.run(arguments, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
    return result.stdout


def main():
    copied = ROOT / "comparison/variants/new_schema/checker_schema.py"
    if (ROOT / "checker.py").read_bytes() != copied.read_bytes():
        raise SystemExit("Selected checker differs from its measured comparison copy")
    test_output = run([sys.executable, "validation/test_selected.py"])
    run([sys.executable, "comparison/measure_all.py"])
    print(test_output.strip())
    directory = ROOT / "build"
    directory.mkdir(exist_ok=True)
    for number in (1, 2, 3):
        output = run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                      "-output-directory=build", "report.tex"])
        (directory / f"latex_pass_{number}.txt").write_text(output)
    shutil.copy2(directory / "report.pdf", ROOT / "report.pdf")
    measurements = json.loads((ROOT / "comparison/comparison.json").read_text())
    selected = next(row for row in measurements["variants"] if row["id"] == "new_schema")
    verification = json.loads((ROOT / "validation/verification.json").read_text())
    log = (directory / "report.log").read_text(errors="replace")
    issues = [line for line in log.splitlines()
              if "Overfull" in line or "undefined" in line.lower()]
    summary = {
        "python": platform.python_version(),
        "source_commit": "b079e5787b1d708049ff0643ce1b534c1a225198",
        "checker_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
        "checker_metrics": {k: selected[k] for k in
                            ("raw_bytes", "canonical_bytes", "significant_tokens", "ast_nodes")},
        "verification": {k: verification[k] for k in
                         ("replayed_count", "new_accepted_count", "new_rejected_count")},
        "latex_passes": 3,
        "latex_layout_or_reference_warnings": issues,
        "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
    }
    (ROOT / "build_results.json").write_text(json.dumps(summary, indent=2) + "\n")
    hashes = []
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if (not path.is_file() or any(part in ("build", "__pycache__") for part in relative.parts)
                or path.name == "SHA256SUMS" or path.suffix in (".pyc", ".aux", ".log", ".out", ".toc")):
            continue
        hashes.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {relative.as_posix()}")
    (ROOT / "SHA256SUMS").write_text("\n".join(hashes) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
