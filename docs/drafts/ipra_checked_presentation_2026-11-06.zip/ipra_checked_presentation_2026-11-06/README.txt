A SMALLER CHECKED PRESENTATION OF iPRA
====================================
Prepared for Vladimir Reshetnikov, 6 November 2026.

Main result
-----------
The mathematical theory T has six logical inference patterns, one fixed
falsity-bridge sentence, two recursion-equation schemas, and one numerical
axiom schema. It is bi-interpretable and equiconsistent with the explicitly
specified full first-order iPRA with quantifier-free induction. Both ordinary
interpretations use the whole number domain and preserve genuine falsity.

The recommended checker uses a proved positive certificate encoding while
keeping genuine falsity in public assertions. It is 3,821 raw source bytes,
3,522 normalized executable bytes, 1,089 significant Python tokens, and
1,154 executable AST nodes. The coordinatewise supplied minima inspected
were 4,170 raw bytes, 3,806 normalized bytes, 1,167 tokens, and 1,248 nodes.
All schema construction, validation, substitution, encoding, and CLI code
are counted. This is a measured implementation improvement, not an absolute
minimality theorem over all possible programming languages or encodings.

Repository snapshot
-------------------
VladimirReshetnikov/ProveIt
b079e5787b1d708049ff0643ce1b534c1a225198
All eleven ZIPs in docs/drafts at that snapshot were reviewed. The comparison
includes 46 supplied variants plus five new candidates/controls. Exact source
hashes, archive hashes, dependency lists, and pinned URLs are included.

Contents
--------
report.pdf               Complete report, proofs, comparison, full code appendix.
report.tex + sections/   Editable LaTeX source; no external bibliography needed.
checker.py               Entire recommended trusted checker (Python 3.10+).
FORMAT.txt               Exact assertion, binding, and proof-certificate format.
validation/              53 translated proofs, 48 focused cases, test runner,
                         source-review notes, and optional legacy regeneration.
comparison/              All comparison sources and reproducible measurements.
provenance/              Pinned source inventory and archive identities.
build.py                 Run verification, measurement, and PDF compilation.
build_results.json       Results from the delivered package's build.
SHA256SUMS               Hashes of deliverable files, excluding temporary builds.

Quick checks
------------
Run these commands from the extracted package directory:

  python3 validation/test_selected.py
  python3 comparison/measure_all.py
  python3 checker.py validation/certificates/legacy_successor_injective.json

The selected verification suite checks 53 translated archived certificates
and 48 named focused cases (9 accepted, 39 rejected), plus stored-object
hypothesis lookup and valid/invalid CLI calls under ordinary Python and -O.
It covers parameterized arithmetic, encoded disjunction, quantified explosion,
binding and capture risks, malformed syntax, and forged compound induction.

To regenerate the translations, before replaying them:

  python3 validation/legacy/adapter.py validation/legacy/original_certificates \
    validation/certificates --bridge schema

Only the standard Python library is needed for checking and measuring.
The adapter is untrusted; its output is checked like any other certificate.

Rebuild the PDF
---------------
  python3 build.py

This runs the same checks and measurements, invokes pdflatex three times, copies
the compiled report to report.pdf, and updates artifact hashes. A standard
LaTeX installation is required (packages are listed in report.tex).
To compile manually:

  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex

Trust and mathematical scope
---------------------------
The positive backend alone admits a singleton model. It is not the ordinary
theory claimed bi-interpretable with iPRA. The public language retains genuine
falsity, and the report proves that public acceptance has exactly the genuine
theory's consequence relation, with arbitrary assumptions and formulas.

The numerical schema permits an induction guard only for literal equations.
For other formulas its guard is the already available fixed base, giving
number cases. The report derives full required quantifier-free induction
through a numerical equality test and formula reflection.

The interpretation and universal checker-correctness results are written
mathematical proofs, with finite executable tests and independent source
reviews. No Lean or Rocq verification of those universal metatheorems is claimed.

Further research questions are included in the report.
