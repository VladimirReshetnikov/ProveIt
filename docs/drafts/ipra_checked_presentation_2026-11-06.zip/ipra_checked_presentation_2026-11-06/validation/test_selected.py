"""Replay the selected iPRA checker's portable validation bundle.

Default kernel: ../checker.py relative to this file. --kernel overrides it.
Only the Python standard library is required; tests and legacy adapters are
not imported by the checker. These are finite tests, not a formal soundness proof.
"""

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(path):
    spec = importlib.util.spec_from_file_location("selected_ipra_kernel", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def accepts(kernel, data):
    try:
        return kernel.check(json.loads(json.dumps(data))) is True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError):
        return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kernel", type=Path, default=ROOT.parent / "checker.py")
    args = parser.parse_args()
    kernel_path = args.kernel.resolve()
    kernel = load(kernel_path)
    proofs = sorted((ROOT / "certificates").glob("*.json"))
    if len(proofs) != 53:
        raise AssertionError(("expected 53 archived proof translations", len(proofs)))
    replayed = []
    for path in proofs:
        if not accepts(kernel, json.loads(path.read_text())):
            raise AssertionError(("archived proof translation rejected", path.name))
        replayed.append({"file": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    cases = json.loads((ROOT / "focused_cases.json").read_text())
    if len(cases) != 48:
        raise AssertionError(("expected 48 focused cases", len(cases)))
    passed, rejected = [], []
    for case in cases:
        actual = accepts(kernel, case["certificate"])
        if actual != case["accepted"]:
            raise AssertionError((case["name"], "actual", actual, "expected", case["accepted"]))
        (passed if actual else rejected).append(case["name"])
    stored = ["=", 0, ["z"]]
    selected = kernel.infer(["hyp", ["=", False, ["z"]]], [stored])
    if selected is not stored:
        raise AssertionError("hypothesis lookup did not return the stored validated object")
    bad = next(case["certificate"] for case in cases
               if case["name"] == "pi_induction_hypothesis_leak")
    cli = []
    with tempfile.TemporaryDirectory(prefix="ipra_check_") as directory:
        invalid = Path(directory) / "forged_compound_induction.json"
        invalid.write_text(json.dumps(bad))
        valid = ROOT / "certificates/new_or_elimination_2.json"
        for optimize in (False, True):
            for path, expected in ((valid, 0), (invalid, 1)):
                command = [sys.executable, *(["-O"] if optimize else []), str(kernel_path), str(path)]
                run = subprocess.run(command, text=True, capture_output=True)
                wanted = "ACCEPT" if expected == 0 else "REJECT"
                if run.returncode != expected or run.stdout.strip() != wanted:
                    raise AssertionError(("CLI", optimize, path.name, run.returncode, run.stdout, run.stderr))
                cli.append({"optimized": optimize, "file": path.name, "exit": run.returncode,
                            "output": run.stdout.strip()})
    result = {
        "scope": "Finite executable-certificate verification; no machine-checked universal soundness or interpretation theorem.",
        "kernel_sha256": hashlib.sha256(kernel_path.read_bytes()).hexdigest(),
        "replayed_count": len(replayed), "replayed": replayed,
        "new_accepted_count": len(passed), "new_accepted": passed,
        "new_rejected_count": len(rejected), "new_rejected": rejected,
        "stored_assumption_identity": True, "cli": cli,
        "legacy_source_commit": "b079e5787b1d708049ff0643ce1b534c1a225198",
        "legacy_archive": "ipra_kernel_2026-11-06.zip",
        "legacy_checker_sha256": "4228564e6bbebbab98246f7879f01cedf80c566edbf814b14afb0cba6d2af0d2",
    }
    (ROOT / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ("replayed_count", "new_accepted_count",
                     "new_rejected_count", "stored_assumption_identity")}, indent=2))


if __name__ == "__main__":
    main()
