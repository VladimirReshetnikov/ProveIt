"""Untrusted adapter from archive-03 indexed proofs to formula hypotheses.

The baseline checker supplies intermediate formulas while translating;
every produced certificate must subsequently pass the selected new checker.
"""

import argparse
import json
from pathlib import Path

import baseline_checker as old


def tree(a):
    return [tree(b) for b in a] if type(a) is tuple else a


def adapt_proof(p, g, bridge="direct"):
    match p:
        case ("hyp", i):
            return ["hyp", tree(g[i])]
        case ("pi", a, q):
            return ["pi", tree(a),
                    adapt_proof(q, (*map(old.shift, g), a), bridge)]
        case ("app", p, t, q):
            return ["app", adapt_proof(p, g, bridge), tree(t),
                    adapt_proof(q, g, bridge)]
        case ("pair", a, t, p, q):
            return ["pair", tree(a), tree(t), adapt_proof(p, g, bridge),
                    adapt_proof(q, g, bridge)]
        case ("let", p, c, q):
            a = old.infer(p, g)
            return ["let", adapt_proof(p, g, bridge), tree(c),
                    adapt_proof(q, (*map(old.shift, g), a[1], a[2]), bridge)]
        case ("bridge", p):
            premise = adapt_proof(p, g, bridge)
            if bridge == "direct":
                return ["bridge", premise]
            if bridge in ("erase", "schema"):
                return premise
            a = old.infer(p, g)
            b = old.CLASH if a == old.FALSE else old.FALSE
            implication = ["pi", tree(a), tree(b)]
            proof = ["hyp", implication]
            if bridge == "single":
                axiom = ["sig", ["pi", tree(old.CLASH), tree(old.FALSE)],
                         ["pi", tree(old.FALSE), tree(old.CLASH)]]
                proof = ["let", ["hyp", axiom], implication, proof]
            return ["app", proof, tree(old.ZERO), premise]
        case ("eq", p, a, q):
            return ["eq", adapt_proof(p, g, bridge), tree(a),
                    adapt_proof(q, g, bridge)]
        case ("rec", r):
            return ["rec", tree(r)]
        case ("nat", a, t, p, q):
            extra = (a,) if a[0] == "=" else ()
            if bridge == "schema":
                base = old.inst(a, old.ZERO)
                h = a if a[0] == "=" else old.shift(base)
                successor = old.subst(a, lambda i: ("s", 0) if i == 0 else i)
                step = ("pi", h, successor)
                premise = ("sig", old.shift(base), old.shift(step))
                step_proof = ["pi", tree(h),
                              adapt_proof(q, (*map(old.shift, g), *extra), bridge)]
                pair = ["pair", tree(premise), tree(old.ZERO),
                        adapt_proof(p, g, bridge), step_proof]
                return ["app", ["nat", tree(a)], tree(t), pair]
            return ["nat", tree(a), tree(t), adapt_proof(p, g, bridge),
                    adapt_proof(q, (*map(old.shift, g), *extra), bridge)]
    raise ValueError("unknown old proof constructor")


def adapt(document, bridge="direct"):
    old.check(document)
    g = tuple(map(old.freeze, document["assumptions"]))
    return {"assumptions": document["assumptions"], "goal": document["goal"],
            "proof": adapt_proof(old.freeze(document["proof"]), g, bridge)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--bridge", choices=["direct", "two", "single", "erase", "schema"],
                        default="direct")
    args = parser.parse_args()
    args.destination.mkdir(parents=True, exist_ok=True)
    count = 0
    for path in sorted(args.source.glob("*.json")):
        output = adapt(json.loads(path.read_text()), args.bridge)
        (args.destination / path.name).write_text(json.dumps(output, separators=(",", ":")) + "\n")
        count += 1
    print(f"Adapted {count} certificates; new checker replay remains required.")
