PORTABLE SELECTED-CHECKER VALIDATION

Place this directory as validation/ beside the selected root checker.py.
From the package root run:

  python3 validation/test_selected.py

An alternative location is supported by --kernel PATH. No workspace-specific
paths are required. The tests load the selected checker, replay all 53 supplied
proof translations, and check 48 named focused cases (9 accepted, 39 rejected).
They also verify that a tolerant hypothesis key returns the exact stored
validated formula, and exercise both accepted and rejected CLI requests under
ordinary Python and Python -O. Results are written to verification.json.

The focused cases are data in focused_cases.json. The compound-induction
attacks request a schema with P(x) as the guard for a genuinely varying Pi or
Sigma template, instead of the permitted fixed P(0) guard. Other checks cover
eigenvariable capture, capture under native recursor binders, equality transport,
variable types, malformed syntax, unknown recursion counters and removed tags.

The 53 original archive proofs and exact old checker are included under legacy/.
To regenerate the selected proofs using the untrusted adapter:

  python3 validation/legacy/adapter.py validation/legacy/original_certificates validation/certificates --bridge schema
  python3 validation/test_selected.py

The adapter replaces integer hypothesis references with lookup keys, removes
bridge steps after falsity encoding, and reconstructs old numerical-rule uses
with Pi/Sigma proof constructors and the new numerical-axiom leaf. It is not
imported by the selected checker. The original proofs include equation induction,
compound numerical cases, zero/successor separation, quantified explosion,
encoded disjunction and cases with free numerical parameters.

Original snapshot: b079e5787b1d708049ff0643ce1b534c1a225198.
Original archive: docs/drafts/ipra_kernel_2026-11-06.zip.
These finite checks do not constitute a Lean/Rocq proof of universal soundness
or bi-interpretability. Those metatheorems are supplied as written mathematics.
