"""Uniform source measurements of the included complete checker variants.

Run from any directory. Only Python's standard library is required. Local
imports are followed from each entry point and manual dynamic dependencies;
each resulting source file is counted exactly once per variant.
"""

import ast
import csv
import hashlib
import io
import json
import sys
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def docstring_nodes(tree):
    found = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    found.append(node.body[0])
    return found


class WithoutDocstrings(ast.NodeTransformer):
    def remove(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        if not node.body and not isinstance(node, ast.Module):
            node.body.append(ast.Pass())
        return node

    visit_Module = remove
    visit_FunctionDef = remove
    visit_AsyncFunctionDef = remove
    visit_ClassDef = remove


def source_metrics(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = [((n.lineno, n.col_offset), (n.end_lineno, n.end_col_offset))
             for n in docstring_nodes(tree)]
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE,
               tokenize.NL, tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in ignored and
              not any(start <= t.start and t.end <= end for start, end in spans)]
    executable = WithoutDocstrings().visit(tree)
    ast.fix_missing_locations(executable)
    canonical = ast.unparse(executable) + "\n"
    # Canonical text remains syntactically valid even for a docstring-only class.
    ast.parse(canonical)
    canonical_tokens = [t for t in tokenize.generate_tokens(io.StringIO(canonical).readline)
                        if t.type not in ignored]
    return {
        "raw_bytes": len(raw), "physical_lines": len(source.splitlines()),
        "significant_tokens": len(tokens),
        "token_bytes": sum(len(t.string.encode("utf-8")) for t in tokens),
        "canonical_bytes": len(canonical.encode("utf-8")),
        "canonical_tokens": len(canonical_tokens),
        "ast_nodes": sum(1 for _ in ast.walk(executable)),
        "match_cases": sum(isinstance(n, ast.match_case) for n in ast.walk(executable)),
        "sha256": hashlib.sha256(raw).hexdigest(),
    }


def imported_modules(path):
    for node in ast.walk(ast.parse(path.read_text())):
        if isinstance(node, ast.Import):
            for alias in node.names:
                yield alias.name, 0
        elif isinstance(node, ast.ImportFrom):
            yield node.module or "", node.level


def dependency_closure(directory, entrypoints, manual):
    pending = [directory / name for name in (*entrypoints, *manual)]
    seen, shared, unresolved = set(), set(), set()
    while pending:
        path = pending.pop().resolve()
        if path in seen:
            continue
        if not path.is_relative_to(directory.resolve()) or not path.is_file():
            raise ValueError(f"Missing or out-of-directory dependency: {path}")
        seen.add(path)
        for module, level in imported_modules(path):
            base = path.parent
            for _ in range(max(level - 1, 0)):
                base = base.parent
            relative = Path(*module.split(".")) if module else Path()
            candidates = [base / relative.with_suffix(".py"),
                          base / relative / "__init__.py",
                          directory / relative.with_suffix(".py"),
                          directory / relative / "__init__.py"]
            local = next((p for p in candidates if p.is_file()), None)
            if local is not None:
                pending.append(local)
            elif module.split(".")[0] in sys.stdlib_module_names or module == "__future__":
                shared.add(module)
            else:
                unresolved.add(module)
    if unresolved:
        raise ValueError(f"Unresolved nonstandard imports: {sorted(unresolved)}")
    return sorted(seen), sorted(shared)


def main():
    manifest = json.loads((ROOT / "manifest.json").read_text())
    variants = []
    sum_fields = ["raw_bytes", "physical_lines", "significant_tokens", "token_bytes",
                  "canonical_bytes", "canonical_tokens", "ast_nodes", "match_cases"]
    for item in manifest["variants"]:
        directory = ROOT / item["directory"]
        closure, shared = dependency_closure(directory, item["entrypoints"],
                                             item.get("manual_dependencies", []))
        relative = [p.relative_to(directory.resolve()).as_posix() for p in closure]
        if relative != sorted(item["files"]):
            raise ValueError((item["id"], "dependency manifest mismatch", relative, item["files"]))
        files = {name: source_metrics(directory / name) for name in relative}
        for name, data in files.items():
            if data["sha256"] != item["source_hashes"][name]:
                raise ValueError((item["id"], name, "source changed"))
        totals = {key: sum(data[key] for data in files.values()) for key in sum_fields}
        digest = hashlib.sha256()
        for name in relative:
            digest.update(name.encode() + b"\0" + (directory / name).read_bytes() + b"\0")
        variants.append({"id": item["id"], "archive_index": item["archive_index"],
                         "label": item["label"], "boundary": item["boundary"],
                         "semantics": item["semantics"], **totals,
                         "source_sha256": digest.hexdigest(), "files": files,
                         "shared_runtime_modules": shared})
    corpus = [v for v in variants if v["archive_index"] is not None]
    complete = [v for v in corpus if v["boundary"] == "complete_cli"]
    envelope = {}
    for key in ["canonical_bytes", "significant_tokens", "canonical_tokens", "ast_nodes"]:
        minimum = min(v[key] for v in corpus)
        envelope[key] = {"value": minimum, "variants": [v["id"] for v in corpus if v[key] == minimum]}
    result = {"method": manifest["method"], "python_version": sys.version.split()[0],
              "variant_count": len(variants), "source_archive_count": len(set(v["archive_index"] for v in corpus)),
              "complete_cli_comparator_count": len(complete),
              "conservative_supplied_lower_envelope": envelope, "variants": variants}
    (ROOT / "comparison.json").write_text(json.dumps(result, indent=2) + "\n")
    columns = ["id", "archive_index", "boundary", "raw_bytes", "canonical_bytes",
               "significant_tokens", "canonical_tokens", "ast_nodes", "source_sha256"]
    with (ROOT / "comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(variants)
    lines = ["id | boundary | raw bytes | canonical bytes | significant tokens | canonical tokens | AST nodes"]
    for v in variants:
        lines.append(" | ".join(str(v[k]) for k in
                     ("id", "boundary", "raw_bytes", "canonical_bytes", "significant_tokens", "canonical_tokens", "ast_nodes")))
    lines.append("\nConservative supplied lower envelope (including favorable core-only comparators):")
    lines.append(json.dumps(envelope, indent=2))
    (ROOT / "comparison.txt").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
