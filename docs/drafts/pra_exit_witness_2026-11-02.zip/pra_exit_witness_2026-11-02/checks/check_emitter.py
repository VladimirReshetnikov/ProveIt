#!/usr/bin/env python3
"""Independent AST accounting for PRA from exit witnesses.

The three current scalar emitters are reconstructed from their AXIOMS.txt
specifications at ProveIt commit 53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4.
No baseline code is imported. Formula construction and closed count
formulas are separate. This is finite syntax verification, not a proof of
the infinite comparison theorem or mathematical bi-interpretability.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import random


@dataclass(frozen=True, slots=True)
class Node:
    op: str
    children: tuple[Node, ...] = ()
    name: str = ""
    descriptor: Node | None = None


def variable(name): return Node("variable", name=name)
ZERO = Node("zero")
FALSE = Node("false")
n, a, b, c, k, v, w = [variable(x) for x in "nabckvw"]
def S(x): return Node("S", (x,))
def chi(x, y): return Node("chi", (x, y))
def EQ(x, y): return Node("=", (x, y))
def AND(x, y): return Node("and", (x, y))
def OR(x, y): return Node("or", (x, y))
def IMP(x, y): return Node("implies", (x, y))
def ALL(name, f): return Node("forall", (f,), name)
def EX(name, f): return Node("exists", (f,), name)
def close(f): return ALL("a", ALL("n", f))


def is_R(t, desc):
    return t.op == "R" and t.descriptor == desc


def normalize(t):
    while is_R(t, w) and t.children[0].op == "S":
        t = t.children[0].children[0]
    return t


def R(desc, x, y):
    return Node("R", (x, y), descriptor=normalize(desc))


def Q(x, y): return R(w, x, y)
def Z(x, y): return R(ZERO, x, y)


def substitute(t, replacements):
    """Simultaneous active substitution, never inside a frozen descriptor."""
    if t.op == "variable":
        return replacements.get(t.name, t)
    return Node(t.op, tuple(substitute(ch, replacements) for ch in t.children),
                t.name, t.descriptor)


def ru(u, x, y):
    return R(substitute(u, {"n": v, "a": w}), x, y)


@lru_cache(None)
def active(t):
    return 1 + sum(active(ch) for ch in t.children)


@lru_cache(None)
def full(t):
    return 1 + sum(full(ch) for ch in t.children) + (
        full(t.descriptor) if t.op == "R" else 0)


@lru_cache(None)
def occurrences(t, name):
    return int(t.op == "variable" and t.name == name) + sum(
        occurrences(ch, name) for ch in t.children)


@lru_cache(None)
def variables(t):
    if t.op == "variable":
        return frozenset([t.name])
    return frozenset().union(*(variables(ch) for ch in t.children))


def sizes(t): return active(t), full(t)


def data(u):
    return active(u), full(u), full(normalize(u)), occurrences(u, "n"), occurrences(u, "a")


def left(u):
    return close(AND(EQ(ru(u, ZERO, a), a),
                     EQ(ru(u, S(n), a), substitute(u, {"n": ru(u, n, a), "a": n}))))


def right(u):
    return close(AND(EQ(ru(u, ZERO, a), a),
                     EQ(ru(u, S(n), a), ru(u, n, substitute(u, {"n": a, "a": ZERO})))) )


def bound_state(u):
    return close(AND(EQ(ru(u, ZERO, a), a),
                     ALL("c", IMP(EQ(ru(u, n, a), c),
                                  EQ(ru(u, S(n), a), substitute(u, {"n": c, "a": n}))))))


SIGMA = IMP(EQ(ZERO, S(ZERO)), FALSE)
K = AND(EQ(chi(a, a), S(ZERO)), OR(EQ(a, n), EQ(chi(a, n), ZERO)))
C = OR(EQ(n, ZERO), EQ(n, S(Q(n, ZERO))))
SEED_S = Q(S(n), a)
SEED_G = Z(chi(n, ZERO), a)
BIT = close(K)
SEPARATION_COVERAGE = ALL("n", AND(SIGMA, C))
OLD_SEED = close(AND(SIGMA, K))


def local_guard(t):
    return Q(Z(chi(a, ZERO), S(t)), n)


def rooted_guard(t):
    return Z(Z(chi(a, ZERO), chi(t, ZERO)), n)


def is_local_guard(u):
    if not is_R(u, w) or u.children[1] != n:
        return False
    zt = u.children[0]
    return is_R(zt, ZERO) and zt.children[0] == chi(a, ZERO) and zt.children[1].op == "S"


def is_rooted_guard(u):
    if not is_R(u, ZERO) or u.children[1] != n:
        return False
    zt = u.children[0]
    if not is_R(zt, ZERO) or zt.children[0] != chi(a, ZERO):
        return False
    ct = zt.children[1]
    return ct.op == "chi" and ct.children[1] == ZERO


def boundary_return(u):
    return close(EX("k", AND(EQ(ru(u, S(k), a), a),
                              IMP(EQ(ru(u, S(S(k)), a), a), EQ(k, n)))))


def local_return(u, shifted=True):
    after = S(S(b)) if shifted else S(b)
    pick = Q(Z(chi(ru(u, after, a), a), S(b)), n)
    target = S(pick) if shifted else pick
    return close(EX("b", EQ(ru(u, target, a), a)))


def exit_return(u):
    pick = Q(Z(chi(ru(u, b, a), a), b), n)
    return close(EX("b", EQ(ru(u, pick, a), a)))


def rooted_return(u):
    return close(IMP(ALL("b", IMP(EQ(ru(u, S(b), a), a), EQ(ru(u, S(S(b)), a), a))),
                     EQ(ru(u, S(n), a), a)))


def old_emit(u, which):
    i, j = occurrences(u, "n"), occurrences(u, "a")
    if u == (SEED_G if which == "rooted" else SEED_S):
        return "seed", OLD_SEED
    if i > 0 and j == 0:
        return "right", right(u)
    if which == "rooted":
        if is_rooted_guard(u): return "rooted", rooted_return(u)
        if i >= 4: return "bound", bound_state(u)
    elif is_local_guard(u):
        if which == "boundary": return "boundary", boundary_return(u)
        if which == "local": return "local", local_return(u)
        raise ValueError(which)
    return "left", left(u)


def computation(u):
    i, j = occurrences(u, "n"), occurrences(u, "a")
    if i > 0 and j == 0:
        return "right", right(u)
    if i >= 4:
        return "bound", bound_state(u)
    return "left", left(u)


def new_emit(u, optional=False):
    if u == SEED_S:
        return "bit", BIT
    if u == SEED_G:
        return "separation_coverage", SEPARATION_COVERAGE
    branch, comp = computation(u)
    if normalize(u) == u:
        ret = exit_return(u)
        m, W, V, i, j = data(u)
        primary_threshold = i > 0 and u != n
        threshold = primary_threshold or (i == 0 and m >= 3 and W >= 5)
        exact = active(ret) <= active(comp) and full(ret) <= full(comp)
        assert threshold == exact, (term_text(u), threshold, exact)
        if threshold if optional else primary_threshold:
            return "exit_return", ret
    return branch, comp


def count_formula(u, branch):
    m, W, V, i, j = data(u)
    if branch == "bit": return 18, 18
    if branch == "separation_coverage": return 18, 19
    if branch == "seed": return 25, 25
    if branch == "right": return 15 + m, 15 + W + 3 * V
    if branch == "left": return 13 + m + 2 * i, 13 + W + 2 * i + (2 + i) * V
    if branch == "bound": return 20 + m, 20 + W + 3 * V
    if branch == "rooted": return 24, 24 + 3 * V
    if branch == "boundary": return 21, 21 + 2 * V
    if branch == "local": return 20, 22 + 2 * V
    if branch == "exit_return": return 16, 18 + 2 * V
    raise ValueError(branch)


def double_pad(u):
    return Q(S(Q(S(u), a)), a)


def term_text(t):
    if t.op == "variable": return t.name
    if t.op == "zero": return "0"
    if is_R(t, w): name = "Q"
    elif is_R(t, ZERO): name = "Z"
    elif t.op == "R": name = "R[" + term_text(t.descriptor) + "]"
    else: name = t.op
    return name + "(" + ",".join(term_text(ch) for ch in t.children) + ")"


def formula_text(f):
    if f.op == "=": return term_text(f.children[0]) + "=" + term_text(f.children[1])
    if f.op in ("forall", "exists"):
        return f.op + " " + f.name + " (" + formula_text(f.children[0]) + ")"
    if f.op == "false": return "FALSE"
    if f.op in ("and", "or", "implies"):
        return "(" + formula_text(f.children[0]) + " " + f.op + " " + formula_text(f.children[1]) + ")"
    raise ValueError(f.op)


def validate(t):
    if t.op == "R":
        assert t.descriptor is not None
        assert normalize(t.descriptor) == t.descriptor
        assert variables(t.descriptor) <= {"v", "w"}
        validate(t.descriptor)
    else:
        assert t.descriptor is None
    for ch in t.children: validate(ch)


def small_terms(descriptors, limit=5):
    by_size = {1: [ZERO, n, a]}
    for size in range(2, limit + 1):
        layer = [S(t) for t in by_size[size - 1]]
        for lsize in range(1, size - 1):
            rsize = size - 1 - lsize
            for x in by_size[lsize]:
                for y in by_size[rsize]:
                    layer.append(chi(x, y))
                    layer.extend(R(d, x, y) for d in descriptors)
        by_size[size] = list(dict.fromkeys(layer))
    return [t for layer in by_size.values() for t in layer]


def random_term(rng, descriptors, depth):
    if depth == 0 or rng.random() < 0.27:
        return rng.choice([ZERO, n, a])
    op = rng.randrange(3)
    if op == 0: return S(random_term(rng, descriptors, depth - 1))
    x, y = [random_term(rng, descriptors, depth - 1) for _ in range(2)]
    return chi(x, y) if op == 1 else R(rng.choice(descriptors), x, y)


def main():
    descriptors = (ZERO, v, w, S(v), S(w), chi(v, w), Q(v, w),
                   R(S(v), v, w), R(chi(Q(v, w), R(S(v), v, w)), v, w))
    exhaustive = small_terms(descriptors[:6])
    rng = random.Random(20261103)
    randoms = [random_term(rng, descriptors, 6) for _ in range(1000)]
    tails = exhaustive[:250] + randoms[:150]
    guarded = [f(t) for t in tails for f in (local_guard, rooted_guard)]
    design = [ZERO, n, a, SEED_S, SEED_G, Q(S(n), ZERO),
              Q(S(SEED_S), a), R(descriptors[-1], n, a)]
    originals = list(dict.fromkeys(exhaustive + randoms + guarded + design))
    inputs = list(dict.fromkeys(originals + [double_pad(u) for u in originals[:1000]]))
    branches = Counter()
    optional_branches = Counter()
    optional_strict = Counter()
    old_branches = {x: Counter() for x in ("boundary", "local", "rooted")}
    strict = Counter()
    minima = {x: [10**100, 10**100] for x in old_branches}
    formula_checks = 0
    recovery_checks = 0
    for u in inputs:
        assert variables(u) <= {"n", "a"}
        validate(u)
        branch, formula = new_emit(u)
        got = sizes(formula)
        assert got == count_formula(u, branch), (term_text(u), branch, got, count_formula(u, branch))
        formula_checks += 1
        opt_branch, opt_formula = new_emit(u, optional=True)
        opt_sizes = sizes(opt_formula)
        assert opt_sizes == count_formula(u, opt_branch)
        assert opt_sizes[0] <= got[0] and opt_sizes[1] <= got[1]
        formula_checks += 1
        optional_branches[opt_branch] += 1
        if opt_sizes[0] < got[0]: optional_strict["active"] += 1
        if opt_sizes[1] < got[1]: optional_strict["full"] += 1
        if opt_sizes[0] < got[0] and opt_sizes[1] < got[1]: optional_strict["both"] += 1
        baseline_sizes = []
        for old in old_branches:
            ob, of = old_emit(u, old)
            os = sizes(of)
            assert os == count_formula(u, ob), (old, term_text(u), ob, os, count_formula(u, ob))
            formula_checks += 1
            assert got[0] <= os[0] and got[1] <= os[1], (old, term_text(u), branch, got, os)
            for i in range(2): minima[old][i] = min(minima[old][i], os[i] - got[i])
            old_branches[old][ob] += 1
            baseline_sizes.append(os)
        envelope = tuple(min(x[i] for x in baseline_sizes) for i in range(2))
        assert got[0] <= envelope[0] and got[1] <= envelope[1]
        if got[0] < envelope[0]: strict["active"] += 1
        if got[1] < envelope[1]: strict["full"] += 1
        if got[0] < envelope[0] and got[1] < envelope[1]: strict["both"] += 1
        if got == envelope: strict["ties_both"] += 1
        if is_local_guard(u) or is_rooted_guard(u) or u in (SEED_S, SEED_G):
            assert got[0] < envelope[0] and got[1] < envelope[1], (term_text(u), got, envelope)
        pad = double_pad(u)
        pb, pf = new_emit(pad)
        assert pb in ("left", "bound")
        assert new_emit(pad, optional=True)[0] == pb
        assert normalize(pad) == normalize(u)
        assert ru(pad, n, a).descriptor == ru(u, n, a).descriptor
        assert substitute(ru(u, n, a), {"n": w, "a": v}).descriptor == ru(u, n, a).descriptor
        assert substitute(n, {"n": a, "a": ZERO}) == a
        formula_checks += 1
        assert sizes(pf) == count_formula(pad, pb)
        recovery_checks += 1
        branches[branch] += 1
    assert set(branches) == {"left", "right", "bound", "bit", "separation_coverage", "exit_return"}
    examples = []
    for u in [ZERO, n, a, SEED_S, SEED_G, local_guard(ZERO), local_guard(n),
              rooted_guard(ZERO), chi(n, a), S(S(n)), double_pad(local_guard(ZERO)),
              R(descriptors[-1], n, a)]:
        branch, formula = new_emit(u)
        old = {name: {"branch": old_emit(u, name)[0], "size": sizes(old_emit(u, name)[1])}
               for name in old_branches}
        envelope = [min(x["size"][i] for x in old.values()) for i in range(2)]
        examples.append({"term": term_text(u), "new_branch": branch, "new_size": sizes(formula),
                         "optional_branch": new_emit(u, optional=True)[0],
                         "optional_size": sizes(new_emit(u, optional=True)[1]),
                         "old": old, "envelope": envelope, "formula": formula_text(formula)})
    report = {
        "status": "all assertions passed",
        "scope": "Finite syntax and branch audit. No machine-checked semantic bi-interpretability claim.",
        "snapshot": "53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4",
        "baseline_scope": "Exact ASTs for boundary-witness, local-return, and rooted-return primary emitters. Autonomous-orbit has a different grammar and is not included as a same-language emitter.",
        "exhaustive_terms_through_active_size_5": len(exhaustive),
        "exhaustive_descriptor_count": 6,
        "random_requests": len(randoms),
        "random_seed": 20261103,
        "unique_inputs": len(inputs),
        "new_branches": dict(branches),
        "primary_selector": "After the two fixed seeds: canonical u, positive n occurrence count, and u != n.",
        "optional_selector": "Also select canonical state-independent u when active size >= 3 and full size >= 5.",
        "optional_branches": dict(optional_branches),
        "optional_strict_savings_over_primary": dict(optional_strict),
        "old_branches": {x: dict(y) for x, y in old_branches.items()},
        "actual_formula_count_checks": formula_checks,
        "double_padding_recoveries_checked": recovery_checks,
        "envelope_comparison": dict(strict),
        "minimum_savings_by_baseline": minima,
        "examples": examples,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    destination = Path(__file__).with_name("new_emitter_results.json")
    destination.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "examples"}, indent=2))


if __name__ == "__main__":
    main()
