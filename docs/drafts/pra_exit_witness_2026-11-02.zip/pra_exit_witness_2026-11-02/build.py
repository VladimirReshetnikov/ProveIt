#!/usr/bin/env python3
"""Rebuild the paper; optionally rerun the delivered syntax/Lean checks."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


def run(command, cwd, log_path):
    result = subprocess.run(command, cwd=cwd, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log_path.write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-8000:], file=sys.stderr)
        raise SystemExit(result.returncode)
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='run the finite syntax audit')
    parser.add_argument('--lean', help='path to a Lean 4.19.0 executable')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    out = root / 'verification'
    out.mkdir(exist_ok=True)
    for i in range(1, 4):
        run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
             '-file-line-error', 'report.tex'], root, out / f'latex_pass_{i}.txt')
    log = (root / 'report.log').read_text(errors='replace')
    issues = [line for line in log.splitlines() if
              ('Overfull' in line or 'undefined' in line.lower() or
               'Rerun to get cross-references right' in line)]
    if issues:
        raise SystemExit('Final LaTeX issues:\n' + '\n'.join(issues))
    record = {'latex_passes': 3, 'latex_exit_code': 0,
              'overfull_or_undefined_issues': issues,
              'pdf_sha256': hashlib.sha256((root / 'report.pdf').read_bytes()).hexdigest(),
              'syntax_audit_run': False, 'lean_run': False}
    if args.check:
        run([sys.executable, 'checks/check_emitter.py'], root,
            out / 'emitter_check_output.txt')
        record['syntax_audit_run'] = True
        record['syntax_audit'] = json.loads((root / 'checks/new_emitter_results.json').read_text())['status']
    if args.lean:
        executable = str(Path(args.lean).expanduser().resolve())
        version = run([executable, '--version'], root / 'formal',
                      root / 'formal/lean_version.txt').strip()
        output = run([executable, 'UnshiftedReturn.lean'], root / 'formal',
                     root / 'formal/lean_output.txt')
        if 'sorryAx' in output or 'Classical.choice' in output:
            raise SystemExit('Unexpected Lean dependency in printed axiom audit')
        source = root / 'formal/UnshiftedReturn.lean'
        verification = {
            'source': source.name, 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'lean_version': version, 'exit_code': 0,
            'contains_sorryAx': False, 'contains_Classical_choice': False,
            'dependencies': sorted(set(re.findall(r'axioms: \[([^\]]+)\]', output))),
            'witness_formula': 'forall n, exists b, F(Q(Z(chi(F(b),a),b),n))=a',
            'scope': 'SCOPE.txt'}
        (root / 'formal/verification.json').write_text(json.dumps(verification, indent=2) + '\n')
        record['lean_run'] = True
        record['lean_version'] = version
    (out / 'build_results.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
