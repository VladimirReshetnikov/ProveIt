PRA FROM EXIT WITNESSES
Prepared for Vladimir Reshetnikov, November 2, 2026

MAIN RESULT
A 16-active-node exit-witness principle replaces the current shifted-return
principles. Its full size is 18+2W on canonical descriptors of full size W.
The coordinatewise old lower envelope on the boundary/local family is
20 active and 21+2W full nodes. The exact six-case emitter never increases
either size at any common input of the three current binary-language
drafts. It is strictly smaller at both old seeds and every old primary
selected induction input. The fourth archive has a different grammar;
the paper gives a qualified numerical-profile comparison, not a false
same-language comparison.

The new theory is proved to have a common conservative definitional
extension with first-order PRA. The interpretations preserve the full
carrier and native equality; both composites are internally identities.
The proof works separately with classical and intuitionistic logic.

CONTENTS
  report.pdf                 Compiled research paper.
  report.tex, sections/      Complete LaTeX source and bibliography.
  AXIOMS.txt                 Exact standalone six-case specification.
  build.py                  Reproducible PDF/check driver.
  checks/check_emitter.py    Independent AST construction and count audit.
  checks/new_emitter_results.json
                            Full audit result and example formulas.
  formal/UnshiftedReturn.lean
                            Checked arbitrary-carrier proof kernel.
  formal/SCOPE.txt           Exact formalization boundary.
  formal/lean-toolchain      Lean 4.19.0.
  formal/lean_output.txt     Compiler output and printed axiom dependencies.
  formal/verification.json   Source hash and successful compiler result.
  provenance/source_manifest.json
                            Pinned sources, Git blob hashes, SHA-256 hashes.
  verification/             Build, independent review, and PDF QA records.
  SHA256SUMS                Integrity hashes of the package contents.

READING ORDER
Start with report.pdf Sections 1-3 for the idea and exact theory.
Section 4 proves parameter coding without an induction-budget shortcut.
Section 5 proves both interpretation maps and their identity composites.
Section 6 proves the exact pointwise comparison for all finite inputs.
Section 7 describes verification, a coverage countermodel, and further
research questions. AXIOMS.txt is a compact implementation reference.

REBUILD
Requires Python 3 and a LaTeX installation with pdflatex, standard AMS
packages, lmodern, microtype, geometry, enumitem, booktabs, tabularx,
fancyhdr, xcolor, xurl, and hyperref.

  python3 build.py

This compiles report.tex three times and checks the final LaTeX log.
To also rerun the syntax audit and the Lean proof:

  python3 build.py --check --lean /absolute/path/to/lean

The Lean compiler should be version 4.19.0. With elan installed, the
formal/lean-toolchain file specifies the version. The proof imports Std
only and requires no mathlib or network access.

You can run the checks separately:
  python3 checks/check_emitter.py
  cd formal
  lean UnshiftedReturn.lean

VERIFICATION BOUNDARY
The complete theorem has written mathematical proofs. The Lean artifact
checks the novel local kernel and the reverse boundary invariant, not the
entire bi-interpretation development. The Python audit is finite and
syntactic; the all-input comparison is proved by cases in the paper.
All source observations are pinned to ProveIt commit
53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4.

The current constructions form a simplicity frontier, not an established
absolute lower bound. This report claims the explicit measured improvement
above and does not claim a shortest axiomatization across all languages.
