import Std

/-!
# Unshifted return arithmetic: arbitrary-carrier kernel

The forward induction bootstrap uses an arbitrary type A, the displayed
arithmetic equations, coverage, and the target-dependent local witness.
It uses neither Nat induction nor an assumed induction principle on A.

Reverse soundness isolates one explicitly stated quantifier-free boundary
invariant induction instance. That instance is available in PRA. The same
proof applies to every initialized trajectory, with no root/zero guard.

Scope: the term/formula compiler, arithmetic pairing, generated signature,
emitter recovery, and complete bi-interpretation are proved in the paper,
not by this file. Several elementary bit/selector and boundary lemmas adapt
the corresponding kernel in the supplied local-return draft; the coverage
bootstrap and unshifted theorem are the new result checked here.
-/

namespace UnshiftedReturn

universe u

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  Q : A → A → A
  Z : A → A → A
  chi : A → A → A
  separated : zero ≠ succ zero
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ n a, Q (succ n) a = n
  z_zero : ∀ a, Z zero a = a
  z_succ : ∀ n a, Z (succ n) a = zero
  chi_diag : ∀ a, chi a a = succ zero
  chi_off : ∀ a b, a = b ∨ chi a b = zero
  coverage : ∀ x, x = zero ∨ x = succ (Q x zero)

namespace Kernel

variable {A : Type u} (K : Kernel A)

def pred (x : A) : A := K.Q x K.zero

theorem pred_succ (x : A) : K.pred (K.succ x) = x :=
  K.q_succ x K.zero

theorem succ_injective (x y : A) (h : K.succ x = K.succ y) : x = y := by
  have hp := congrArg (fun z => K.Q z K.zero) h
  simpa only [K.q_succ] using hp

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro hs
  have hx : x = K.zero := by
    have hp := congrArg (fun z => K.Q z K.zero) hs
    simpa only [K.q_succ, K.q_zero] using hp
  apply K.separated
  exact hs.symm.trans (congrArg K.succ hx)

theorem chi_of_ne (x y : A) (h : x ≠ y) : K.chi x y = K.zero := by
  rcases K.chi_off x y with he | hc
  · exact False.elim (h he)
  · exact hc

include K in
theorem eq_or_ne (x y : A) : x = y ∨ x ≠ y := by
  rcases K.chi_off x y with he | hc
  · exact Or.inl he
  · apply Or.inr
    intro he
    subst x
    apply K.separated
    exact hc.symm.trans (K.chi_diag y)

/-- This is an ordinary term: return n if x=a, and b otherwise. -/
def choose (x a n b : A) : A :=
  K.Q (K.Z (K.chi x a) (K.succ b)) n

theorem choose_of_eq (x a n b : A) (he : x = a) :
    K.choose x a n b = n := by
  subst x
  simp only [choose, K.chi_diag, K.z_succ, K.q_zero]

theorem choose_of_ne (x a n b : A) (he : x ≠ a) :
    K.choose x a n b = b := by
  simp only [choose, K.chi_of_ne x a he, K.z_zero, K.q_succ]

def ReturnClosed (F : A → A) (a : A) : Prop :=
  ∀ k, F k = a → F (K.succ k) = a

/-- The shorter ordinary term: return n on equality, otherwise Q b n. -/
def chooseExit (x a n b : A) : A :=
  K.Q (K.Z (K.chi x a) b) n

theorem chooseExit_of_eq (x a n b : A) (he : x = a) :
    K.chooseExit x a n b = n := by
  subst x
  simp only [chooseExit, K.chi_diag, K.z_succ, K.q_zero]

/-- The witness may depend on n. The successor is absent from the term. -/
def LocalWitness (F : A → A) (a : A) : Prop :=
  ∀ n, ∃ b, F (K.chooseExit (F b) a n b) = a

theorem localWitness_implies_return
    (F : A → A) (a : A)
    (fzero : F K.zero = a)
    (hw : K.LocalWitness F a)
    (closed : K.ReturnClosed F a) : ∀ n, F n = a := by
  intro n
  rcases hw n with ⟨b, hb⟩
  rcases K.chi_off (F b) a with hs | hc
  · simpa only [K.chooseExit_of_eq _ _ _ _ hs] using hb
  · have hfb : F b = a := by
      rcases K.coverage b with hz | hs
      · simpa only [hz] using fzero
      · have hp : F (K.Q b K.zero) = a := by
          have hq : K.Q b n = K.Q b K.zero := by
            calc
              K.Q b n = K.Q (K.succ (K.Q b K.zero)) n :=
                congrArg (fun x => K.Q x n) hs
              _ = K.Q b K.zero := K.q_succ (K.Q b K.zero) n
          simpa only [chooseExit, hc, K.z_zero, hq] using hb
        have hnext := closed (K.Q b K.zero) hp
        rw [← hs] at hnext
        exact hnext
    simpa only [K.chooseExit_of_eq _ _ _ _ hfb] using hb

/-- No root guard: the latch tests P at the NEXT counter. -/
def latch (bit : A → A → A) (v w : A) : A :=
  K.Z (bit (K.succ w) (K.pred v)) v

theorem latch_reflection
    (P : A → A → Prop) (bit : A → A → A)
    (brange : ∀ n a, bit n a = K.zero ∨ bit n a = K.succ K.zero)
    (btruth : ∀ n a, bit n a = K.zero ↔ P n a)
    (v w a : A) :
    K.latch bit v w = K.succ a ↔
      v = K.succ a ∧ P (K.succ w) a := by
  constructor
  · intro hl
    rcases brange (K.succ w) (K.pred v) with hb | hb
    · have hv : v = K.succ a := by
        simpa only [latch, hb, K.z_zero] using hl
      have hba : bit (K.succ w) a = K.zero := by
        simpa only [hv, K.pred_succ] using hb
      exact ⟨hv, (btruth (K.succ w) a).mp hba⟩
    · have hz : K.zero = K.succ a := by
        simpa only [latch, hb, K.z_succ] using hl
      exact False.elim (K.succ_ne_zero a hz.symm)
  · rintro ⟨hv, hp⟩
    have hb : bit (K.succ w) a = K.zero :=
      (btruth (K.succ w) a).mpr hp
    simp only [latch, hv, K.pred_succ, hb, K.z_zero]

/--
Forward bootstrap: coverage and the local witness for the unshifted latch
trajectory give the complete one-parameter induction implication.
No induction principle on A is present among the assumptions.
-/
theorem induction_from_unshifted_witness
    (P : A → A → Prop) (bit : A → A → A)
    (brange : ∀ n a, bit n a = K.zero ∨ bit n a = K.succ K.zero)
    (btruth : ∀ n a, bit n a = K.zero ↔ P n a)
    (R : A → A → A)
    (rzero : ∀ a, R K.zero a = a)
    (rstep : ∀ n a, R (K.succ n) a = K.latch bit (R n a) n)
    (witness : ∀ a, K.LocalWitness (fun n => R n a) a)
    (a : A) (hbase : P K.zero a)
    (hprogress : ∀ n, P n a → P (K.succ n) a) :
    ∀ n, P n a := by
  have reflect : ∀ n, R n (K.succ a) = K.succ a → P n a := by
    intro n hn
    rcases K.coverage n with hz | hs
    · simpa only [hz] using hbase
    · have hl : K.latch bit (R (K.pred n) (K.succ a)) (K.pred n) =
          K.succ a := by
        rw [← rstep]
        change R (K.succ (K.Q n K.zero)) (K.succ a) = K.succ a
        rw [← hs]
        exact hn
      have hp := ((K.latch_reflection P bit brange btruth
        (R (K.pred n) (K.succ a)) (K.pred n) a).mp hl).2
      change P (K.succ (K.Q n K.zero)) a at hp
      rw [← hs] at hp
      exact hp
  have closed : K.ReturnClosed (fun n => R n (K.succ a)) (K.succ a) := by
    intro n hn
    have hp : P (K.succ n) a := hprogress n (reflect n hn)
    change R (K.succ n) (K.succ a) = K.succ a
    rw [rstep]
    exact (K.latch_reflection P bit brange btruth
      (R n (K.succ a)) n a).mpr ⟨hn, hp⟩
  have allReturns := K.localWitness_implies_return
    (fun n => R n (K.succ a)) (K.succ a) (rzero (K.succ a))
    (witness (K.succ a)) closed
  exact fun n => reflect n (allReturns n)

/-- The primitive-recursive boundary search has this quantifier-free invariant. -/
def BoundaryInvariant (F : A → A) (a : A) (c : A → A) (n : A) : Prop :=
  F (c n) = a ∧ (F n = a ∨ F (K.succ (c n)) ≠ a)

theorem boundary_invariant_base
    (F : A → A) (a : A) (c : A → A)
    (fzero : F K.zero = a) (czero : c K.zero = K.zero) :
    K.BoundaryInvariant F a c K.zero := by
  constructor
  · simpa only [czero] using fzero
  · exact Or.inl fzero

theorem boundary_invariant_step
    (F : A → A) (a : A) (c : A → A)
    (cstep : ∀ n, c (K.succ n) = K.choose (F n) a n (c n))
    (n : A) (hi : K.BoundaryInvariant F a c n) :
    K.BoundaryInvariant F a c (K.succ n) := by
  rcases K.eq_or_ne (F n) a with hn | hn
  · have hc : c (K.succ n) = n := by
      rw [cstep, K.choose_of_eq _ _ _ _ hn]
    constructor
    · simpa only [hc] using hn
    · rcases K.eq_or_ne (F (K.succ n)) a with hs | hs
      · exact Or.inl hs
      · apply Or.inr
        simpa only [hc] using hs
  · have hc : c (K.succ n) = c n := by
      rw [cstep, K.choose_of_ne _ _ _ _ hn]
    constructor
    · simpa only [hc] using hi.1
    · apply Or.inr
      have hexit : F (K.succ (c n)) ≠ a := by
        rcases hi.2 with hp | he
        · exact False.elim (hn hp)
        · exact he
      simpa only [hc] using hexit

theorem localWitness_from_boundaryInvariant
    (F : A → A) (a : A) (c : A → A)
    (hinvariant : ∀ n, K.BoundaryInvariant F a c n) :
    K.LocalWitness F a := by
  intro n
  refine ⟨K.succ (c n), ?_⟩
  change F (K.choose (F (K.succ (c n))) a n (c n)) = a
  have hi := hinvariant n
  rcases K.chi_off (F (K.succ (c n))) a with hs | hc
  · have hn : F n = a := by
      rcases hi.2 with hn | he
      · exact hn
      · exact False.elim (he hs)
    simpa only [K.choose_of_eq _ _ _ _ hs] using hn
  · simpa only [choose, hc, K.z_zero, K.q_succ] using hi.1

/--
Constructive reverse soundness. The only induction assumption is exactly
the displayed quantifier-free invariant instance. The auxiliary c has the
two displayed primitive-recursion equations; its existence is external to
this kernel and follows from the function-symbol grammar of PRA.
-/
theorem localWitness_from_boundaryInduction
    (F : A → A) (a : A) (c : A → A)
    (fzero : F K.zero = a) (czero : c K.zero = K.zero)
    (cstep : ∀ n, c (K.succ n) = K.choose (F n) a n (c n))
    (induction : K.BoundaryInvariant F a c K.zero →
      (∀ n, K.BoundaryInvariant F a c n →
        K.BoundaryInvariant F a c (K.succ n)) →
      ∀ n, K.BoundaryInvariant F a c n) :
    K.LocalWitness F a := by
  apply K.localWitness_from_boundaryInvariant F a c
  exact induction
    (K.boundary_invariant_base F a c fzero czero)
    (K.boundary_invariant_step F a c cstep)

/-- Every initialized recursor is covered, with no restriction on its step body. -/
theorem every_initialized_trajectory_has_witness
    (R : A → A → A) (rzero : ∀ a, R K.zero a = a)
    (a : A) (c : A → A)
    (czero : c K.zero = K.zero)
    (cstep : ∀ n, c (K.succ n) = K.choose (R n a) a n (c n))
    (induction : K.BoundaryInvariant (fun n => R n a) a c K.zero →
      (∀ n, K.BoundaryInvariant (fun n => R n a) a c n →
        K.BoundaryInvariant (fun n => R n a) a c (K.succ n)) →
      ∀ n, K.BoundaryInvariant (fun n => R n a) a c n) :
    K.LocalWitness (fun n => R n a) a := by
  exact K.localWitness_from_boundaryInduction
    (fun n => R n a) a c (rzero a) czero cstep induction

end Kernel
end UnshiftedReturn

#print axioms UnshiftedReturn.Kernel.succ_injective
#print axioms UnshiftedReturn.Kernel.succ_ne_zero
#print axioms UnshiftedReturn.Kernel.eq_or_ne
#print axioms UnshiftedReturn.Kernel.localWitness_implies_return
#print axioms UnshiftedReturn.Kernel.latch_reflection
#print axioms UnshiftedReturn.Kernel.induction_from_unshifted_witness
#print axioms UnshiftedReturn.Kernel.boundary_invariant_base
#print axioms UnshiftedReturn.Kernel.boundary_invariant_step
#print axioms UnshiftedReturn.Kernel.localWitness_from_boundaryInvariant
#print axioms UnshiftedReturn.Kernel.localWitness_from_boundaryInduction
#print axioms UnshiftedReturn.Kernel.every_initialized_trajectory_has_witness
