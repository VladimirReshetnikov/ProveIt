/-
  TermKernel.lean -- constructive, arbitrary-carrier kernel for the
  term-pair propagation presentation of primitive recursive arithmetic.

  Scope: each propagation hypothesis below is one explicitly displayed
  schema instance. No arbitrary-formula propagation principle is assumed.
  In the intended first-order application, every displayed function is
  represented by a legal finite term. The syntax, staged descriptor
  compiler, parameter coding, and complete bi-interpretation are not
  formalized here. The residual calculation is also checked, with its
  previously proved elementary equations passed as explicit hypotheses.

  No use is made of Lean's Nat, induction on a built-in datatype,
  Classical, choice, or any unproved declaration.
-/

universe u
namespace TermKernel

variable {A : Type u}

def Separate (zero : A) (succ : A → A) : Prop :=
  zero = succ zero → False

def TermProbe (zero : A) (succ : A → A)
    (left right : A → A → A) (n a : A) : Prop :=
  Separate zero succ ∧ (n = zero ∨ left n a = right n a)

def Propagate (succ : A → A) (F : A → A → Prop) : Prop :=
  ∀ a, (∀ n, F n a → F (succ n) a) → ∀ n, F n a

/-- Separation is forced by the constant reflexive term-pair probe. -/
theorem separation_from_probe (zero : A) (succ : A → A)
    (h : Propagate succ
      (TermProbe zero succ (fun _ _ => zero) (fun _ _ => zero))) :
    Separate zero succ := by
  have all := h zero (fun _ hn => And.intro hn.1 (Or.inr rfl))
  exact (all zero).1

/-- A single term-pair instance gives the corresponding equation induction
    implication, with the one frozen parameter a and arbitrary local
    base/step hypotheses. -/
theorem equation_induction_from_probe (zero : A) (succ : A → A)
    (left right : A → A → A)
    (h : Propagate succ (TermProbe zero succ left right))
    (a : A) (base : left zero a = right zero a)
    (step : ∀ n, left n a = right n a → left (succ n) a = right (succ n) a) :
    ∀ n, left n a = right n a := by
  have progress : ∀ n,
      TermProbe zero succ left right n a →
      TermProbe zero succ left right (succ n) a := by
    intro n hn
    apply And.intro hn.1
    apply Or.inr
    apply step n
    cases hn.2 with
    | inl hz =>
        cases hz
        exact base
    | inr he => exact he
  have all := h a progress
  intro n
  cases (all n).2 with
  | inl hz =>
      cases hz
      exact base
  | inr he => exact he

/-- The two delayed initial values follow from the uniform reset scheme
    and the constant-one iterator's one transition instance. -/
theorem delayed_boundaries (zero : A) (succ : A → A)
    (q D : A → A → A)
    (qnext : q (succ (succ zero)) zero = succ zero)
    (qreset : ∀ n a, q (q n zero) a = a)
    (reset : ∀ n a, D (q n zero) a = a) :
    (∀ a, D zero a = a) ∧ (∀ a, D (succ zero) a = a) := by
  have done : ∀ a, D (succ zero) a = a := by
    intro a
    calc
      D (succ zero) a = D (q (succ (succ zero)) zero) a :=
        congrArg (fun v => D v a) qnext.symm
      _ = a := reset (succ (succ zero)) a
  have qone : q (succ zero) zero = zero := by
    calc
      q (succ zero) zero = q (q (succ (succ zero)) zero) zero :=
        congrArg (fun v => q v zero) qnext.symm
      _ = zero := qreset (succ (succ zero)) zero
  apply And.intro
  · intro a
    calc
      D zero a = D (q (succ zero) zero) a :=
        congrArg (fun v => D v a) qone.symm
      _ = a := reset (succ zero) a
  · exact done

/-- The successor-body delayed iterator is predecessor. The propagation
    instance has no used numerical parameter. -/
theorem delayed_predecessor (zero : A) (succ : A → A)
    (D : A → A → A)
    (base : D (succ zero) zero = zero)
    (next : ∀ n, D (succ (succ n)) zero = succ (D (succ n) zero))
    (h : Propagate succ
      (TermProbe zero succ (fun n _ => D (succ n) zero) (fun n _ => n))) :
    ∀ n, D (succ n) zero = n := by
  apply equation_induction_from_probe zero succ
    (fun n _ => D (succ n) zero) (fun n _ => n) h zero base
  intro n ih
  exact (next n).trans (congrArg succ ih)

/-- Successor injectivity is purely equational once predecessor is known. -/
theorem successor_injective (succ pred : A → A)
    (pred_succ : ∀ n, pred (succ n) = n) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y he
  calc
    x = pred (succ x) := (pred_succ x).symm
    _ = pred (succ y) := congrArg pred he
    _ = y := pred_succ y

/-- Successor nonzeroness uses separation and the two predecessor laws. -/
theorem successor_nonzero (zero : A) (succ pred : A → A)
    (sep : Separate zero succ) (pred_zero : pred zero = zero)
    (pred_succ : ∀ n, pred (succ n) = n) :
    ∀ n, succ n = zero → False := by
  intro n hn
  have nz : n = zero := by
    calc
      n = pred (succ n) := (pred_succ n).symm
      _ = pred zero := congrArg pred hn
      _ = zero := pred_zero
  have sz : succ zero = zero := by
    calc
      succ zero = succ n := congrArg succ nz.symm
      _ = zero := hn
  exact sep sz.symm

/-- Constructive coverage comes directly from one term-pair propagation
    instance; it is not obtained by assuming disjunctive induction. -/
theorem coverage_from_probe (zero : A) (succ pred : A → A)
    (pred_succ : ∀ n, pred (succ n) = n)
    (h : Propagate succ
      (TermProbe zero succ (fun n _ => succ (pred n)) (fun n _ => n))) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  have progress : ∀ n,
      TermProbe zero succ (fun n _ => succ (pred n)) (fun n _ => n) n zero →
      TermProbe zero succ (fun n _ => succ (pred n)) (fun n _ => n)
        (succ n) zero := by
    intro n hn
    exact And.intro hn.1 (Or.inr (congrArg succ (pred_succ n)))
  have all := h zero progress
  intro n
  cases (all n).2 with
  | inl hz => exact Or.inl hz
  | inr hs => exact Or.inr hs.symm

/-- Zero decision is a consequence of positive coverage and nonzeroness. -/
theorem zero_decision (zero : A) (succ pred : A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (nonzero : ∀ n, succ n = zero → False) :
    ∀ n, n = zero ∨ (n = zero → False) := by
  intro n
  cases coverage n with
  | inl hz => exact Or.inl hz
  | inr hs =>
      apply Or.inr
      intro hz
      exact nonzero (pred n) (hs.symm.trans hz)

/-- A selector with the constructor equations acts diagonally on every
    carrier element once positive coverage is available. -/
theorem selector_diagonal (zero : A) (succ pred : A → A)
    (C : A → A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (at_zero : ∀ a b, C zero a b = a)
    (at_succ : ∀ n a b, C (succ n) a b = b) :
    ∀ n a, C n a a = a := by
  intro n a
  cases coverage n with
  | inl hz =>
      exact (congrArg (fun v => C v a a) hz).trans (at_zero a a)
  | inr hs =>
      exact (congrArg (fun v => C v a a) hs).trans (at_succ (pred n) a a)

/-- The base of the equation-only residual invariant. -/
theorem residual_base (zero : A)
    (add diff : A → A → A) (C : A → A → A → A)
    (diff_zero : ∀ y, diff y zero = y)
    (add_zero : ∀ y, add zero y = y)
    (Cdiag : ∀ n a, C n a a = a) :
    ∀ y, C (diff y zero) y (add zero (diff y zero)) = y := by
  intro y
  have last : add zero (diff y zero) = y :=
    (add_zero (diff y zero)).trans (diff_zero y)
  calc
    C (diff y zero) y (add zero (diff y zero)) = C (diff y zero) y y :=
      congrArg (fun v => C (diff y zero) y v) last
    _ = y := Cdiag (diff y zero) y

/-- The successor step of the residual invariant. Its induction variable
    is n, its sole frozen parameter is y, and all case analyses are supplied
    by positive coverage. No implication/disjunction induction is used. -/
theorem residual_step (zero : A) (succ pred : A → A)
    (add diff : A → A → A) (C : A → A → A → A)
    (pred_zero : pred zero = zero)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (diff_step : ∀ y n, diff y (succ n) = pred (diff y n))
    (add_succ_left : ∀ n a, add (succ n) a = succ (add n a))
    (add_succ_right : ∀ n a, add n (succ a) = succ (add n a))
    (Czero : ∀ a b, C zero a b = a)
    (Csucc : ∀ n a b, C (succ n) a b = b)
    (Cdiag : ∀ n a, C n a a = a)
    (n y : A)
    (ih : C (diff y n) y (add n (diff y n)) = y) :
    C (diff y (succ n)) y (add (succ n) (diff y (succ n))) = y := by
  cases coverage (diff y n) with
  | inl hz =>
      have next_zero : diff y (succ n) = zero := by
        calc
          diff y (succ n) = pred (diff y n) := diff_step y n
          _ = pred zero := congrArg pred hz
          _ = zero := pred_zero
      calc
        C (diff y (succ n)) y (add (succ n) (diff y (succ n))) =
            C zero y (add (succ n) (diff y (succ n))) :=
          congrArg (fun v => C v y (add (succ n) (diff y (succ n)))) next_zero
        _ = y := Czero y (add (succ n) (diff y (succ n)))
  | inr hs =>
      have selected : C (diff y n) y (add n (diff y n)) = add n (diff y n) := by
        calc
          C (diff y n) y (add n (diff y n)) =
              C (succ (pred (diff y n))) y (add n (diff y n)) :=
            congrArg (fun v => C v y (add n (diff y n))) hs
          _ = add n (diff y n) := Csucc (pred (diff y n)) y (add n (diff y n))
      have old_value : add n (diff y n) = y := selected.symm.trans ih
      have new_value : add (succ n) (diff y (succ n)) = y := by
        calc
          add (succ n) (diff y (succ n)) = add (succ n) (pred (diff y n)) :=
            congrArg (add (succ n)) (diff_step y n)
          _ = succ (add n (pred (diff y n))) := add_succ_left n (pred (diff y n))
          _ = add n (succ (pred (diff y n))) := (add_succ_right n (pred (diff y n))).symm
          _ = add n (diff y n) := congrArg (add n) hs.symm
          _ = y := old_value
      calc
        C (diff y (succ n)) y (add (succ n) (diff y (succ n))) =
            C (diff y (succ n)) y y :=
          congrArg (fun v => C (diff y (succ n)) y v) new_value
        _ = y := Cdiag (diff y (succ n)) y

/-- The equation residual invariant turns one special difference value
    into native equality. This checks the arithmetic reflection bottleneck. -/
theorem difference_one_reflects_equality (zero : A) (succ : A → A)
    (add diff : A → A → A) (C : A → A → A → A)
    (sinj : ∀ x y, succ x = succ y → x = y)
    (add_one : ∀ n, add n (succ zero) = succ n)
    (Csucc : ∀ n a b, C (succ n) a b = b)
    (self_diff : ∀ x, diff (succ x) x = succ zero)
    (residual : ∀ n y, C (diff y n) y (add n (diff y n)) = y) :
    ∀ x y, diff (succ x) y = succ zero ↔ x = y := by
  intro x y
  apply Iff.intro
  · intro he
    have selected : C (diff (succ x) y) (succ x) (add y (diff (succ x) y)) =
        add y (succ zero) := by
      calc
        C (diff (succ x) y) (succ x) (add y (diff (succ x) y)) =
            C (succ zero) (succ x) (add y (diff (succ x) y)) :=
          congrArg (fun v => C v (succ x) (add y (diff (succ x) y))) he
        _ = add y (diff (succ x) y) := Csucc zero (succ x) (add y (diff (succ x) y))
        _ = add y (succ zero) := congrArg (add y) he
    have sy_sx : succ y = succ x := by
      calc
        succ y = add y (succ zero) := (add_one y).symm
        _ = C (diff (succ x) y) (succ x) (add y (diff (succ x) y)) := selected.symm
        _ = succ x := residual y (succ x)
    exact (sinj y x sy_sx).symm
  · intro he
    cases he
    exact self_diff x

#print axioms separation_from_probe
#print axioms equation_induction_from_probe
#print axioms delayed_boundaries
#print axioms delayed_predecessor
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms coverage_from_probe
#print axioms zero_decision
#print axioms selector_diagonal
#print axioms residual_base
#print axioms residual_step
#print axioms difference_one_reflects_equality

end TermKernel
