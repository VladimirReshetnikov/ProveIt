#!/usr/bin/env python3
"""Executable syntax and finite diagnostics for zero-exception propagation.

This is not a proof assistant.  Passing these checks does not prove induction,
the assertions about nonstandard models, or the written bi-interpretation.
Only the Python standard library is used.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import product
import json
from pathlib import Path
from typing import Union


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple["Term", ...] = ()
    name: str = ""


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple[Union[Term, "Formula"], ...] = ()
    name: str = ""


def V(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def S(t: Term) -> Term:
    return Term("succ", (t,))


def D(name: str, counter: Term, seed: Term) -> Term:
    # The body is deliberately absent from active arguments.  It lives in the
    # descriptor table and can be entered only by explicit body instantiation.
    return Term("delay", (counter, seed), name)


def Eq(t: Term, u: Term) -> Formula:
    return Formula("eq", (t, u))


BOTTOM = Formula("bottom")


def And(p: Formula, q: Formula) -> Formula:
    return Formula("and", (p, q))


def Or(p: Formula, q: Formula) -> Formula:
    return Formula("or", (p, q))


def Imp(p: Formula, q: Formula) -> Formula:
    return Formula("implies", (p, q))


def All(name: str, p: Formula) -> Formula:
    return Formula("forall", (p,), name)


def fv_term(t: Term) -> set[str]:
    if t.kind == "var":
        return {t.name}
    return set().union(*(fv_term(x) for x in t.args))


def fv_formula(p: Formula) -> set[str]:
    if p.kind in {"eq", "opaque"}:
        return set().union(*(fv_term(t) for t in p.args))
    if p.kind == "bottom":
        return set()
    if p.kind == "forall":
        return fv_formula(p.args[0]) - {p.name}
    return set().union(*(fv_formula(q) for q in p.args))


def all_names(p: Formula) -> set[str]:
    if p.kind in {"eq", "opaque"}:
        return set().union(*(fv_term(t) for t in p.args))
    if p.kind == "bottom":
        return set()
    if p.kind == "forall":
        return {p.name} | all_names(p.args[0])
    return set().union(*(all_names(q) for q in p.args))


def subst_term(t: Term, variable: str, replacement: Term) -> Term:
    if t.kind == "var":
        return replacement if t.name == variable else t
    return Term(t.kind, tuple(subst_term(x, variable, replacement)
                              for x in t.args), t.name)


def subst_formula(p: Formula, variable: str, replacement: Term) -> Formula:
    """Capture-avoiding substitution of free individual-variable occurrences."""
    if p.kind in {"eq", "opaque"}:
        return Formula(p.kind, tuple(subst_term(t, variable, replacement)
                                     for t in p.args), p.name)
    if p.kind == "bottom":
        return p
    if p.kind == "forall":
        binder, body = p.name, p.args[0]
        if binder == variable or variable not in fv_formula(body):
            return p
        if binder in fv_term(replacement):
            used = all_names(body) | fv_term(replacement) | {variable, binder}
            index = 0
            while f"b{index}" in used:
                index += 1
            fresh = f"b{index}"
            body = subst_formula(body, binder, V(fresh))
            binder = fresh
        return All(binder, subst_formula(body, variable, replacement))
    return Formula(p.kind, tuple(subst_formula(q, variable, replacement)
                                 for q in p.args), p.name)


class Descriptors:
    """A finite initial segment of the effective well-founded language."""

    def __init__(self) -> None:
        self.bodies: dict[str, Term] = {}

    def validate_term(self, t: Term) -> None:
        arity = {"var": 0, "zero": 0, "succ": 1, "delay": 2}
        if t.kind not in arity or len(t.args) != arity[t.kind]:
            raise ValueError("Malformed term")
        if t.kind == "delay" and t.name not in self.bodies:
            raise ValueError("A stored body refers to a non-earlier descriptor")
        for child in t.args:
            self.validate_term(child)

    def add(self, name: str, body: Term) -> str:
        if name in self.bodies:
            raise ValueError("Descriptor name already declared")
        self.validate_term(body)
        if not fv_term(body) <= {"v"}:
            raise ValueError("A stored body has an external free parameter")
        if body in self.bodies.values():
            raise ValueError("Use the existing name for this literal body")
        self.bodies[name] = body
        return name

    def instantiate(self, name: str, active_term: Term) -> Term:
        return subst_term(self.bodies[name], "v", active_term)


N, A = V("n"), V("a")
ONE = S(ZERO)
DELTA = Eq(ZERO, ONE)
SIGMA = Imp(DELTA, BOTTOM)


def G(t: Term, u: Term, language: Descriptors) -> Formula:
    for term in (t, u):
        language.validate_term(term)
        if not fv_term(term) <= {"n", "a"}:
            raise ValueError("Dynamic terms may use only n and a")
    return And(SIGMA, Or(Eq(N, ZERO), Eq(t, u)))


def R(name: str, language: Descriptors) -> Formula:
    if language.bodies.get("q") != ONE or name not in language.bodies:
        raise ValueError("q must denote the constant-S(0) descriptor")
    return All("n", Eq(D(name, D("q", N, ZERO), A), A))


def T(name: str, language: Descriptors) -> Formula:
    previous = D(name, S(A), N)
    return All("n", Eq(D(name, S(S(A)), N),
                       language.instantiate(name, previous)))


def P15(matrix: Formula) -> Formula:
    shifted = subst_formula(matrix, "n", S(N))
    return All("a", Imp(All("n", Imp(matrix, shifted)), All("n", matrix)))


def classify(matrix: Formula, language: Descriptors) -> str | None:
    # Literal constructor recognition, not arithmetic normalization or search.
    if matrix.kind == "and" and matrix.args[0] == SIGMA:
        right = matrix.args[1]
        if (right.kind == "or" and right.args[0] == Eq(N, ZERO)
                and right.args[1].kind == "eq"):
            t, u = right.args[1].args
            try:
                if G(t, u, language) == matrix:
                    return "G"
            except ValueError:
                return None
    for name in language.bodies:
        if matrix == R(name, language):
            return "R"
        if matrix == T(name, language):
            return "T"
    return None


def size(node: Term | Formula) -> int:
    """Every term/formula node counts once; stored bodies are not expanded."""
    return 1 + sum(size(child) for child in node.args)


def free_occurrences(node: Term | Formula, variable: str) -> int:
    if node.kind == "var":
        return int(node.name == variable)
    if node.kind == "forall" and node.name == variable:
        return 0
    return sum(free_occurrences(child, variable) for child in node.args)


def encode(node: Term | Formula) -> dict:
    result = {"kind": node.kind}
    if node.name:
        result["name"] = node.name
    if node.args:
        result["args"] = [encode(x) for x in node.args]
    return result


def pretty(node: Term | Formula) -> str:
    if node.kind == "var":
        return node.name
    if node.kind == "zero":
        return "0"
    if node.kind == "succ":
        return f"S({pretty(node.args[0])})"
    if node.kind == "delay":
        return f"{node.name}({', '.join(pretty(t) for t in node.args)})"
    if node.kind == "eq":
        return f"({pretty(node.args[0])}={pretty(node.args[1])})"
    if node.kind == "bottom":
        return "bottom"
    if node.kind == "forall":
        return f"forall {node.name} [{pretty(node.args[0])}]"
    if node.kind == "opaque":
        return f"{node.name}({', '.join(pretty(t) for t in node.args)})"
    connective = {"and": "AND", "or": "OR", "implies": "->"}[node.kind]
    return f"({pretty(node.args[0])} {connective} {pretty(node.args[1])})"


def eval_term(t: Term, values: dict[str, int], language: Descriptors) -> int:
    """Standard-natural-number evaluation; not an internal universal evaluator."""
    if t.kind == "var":
        return values[t.name]
    if t.kind == "zero":
        return 0
    if t.kind == "succ":
        return 1 + eval_term(t.args[0], values, language)
    counter, state = (eval_term(x, values, language) for x in t.args)
    if not 0 <= counter <= 10000:
        raise ValueError("Diagnostic evaluation budget exceeded")
    for _ in range(max(counter - 1, 0)):
        state = eval_term(language.bodies[t.name], {"v": state}, language)
    return state


def check_equation(p: Formula, values: dict[str, int],
                   language: Descriptors) -> bool:
    if p.kind != "eq":
        raise ValueError("This bounded diagnostic evaluates equations only")
    return eval_term(p.args[0], values, language) == eval_term(p.args[1], values, language)


def run(output_dir: Path) -> dict:
    language = Descriptors()
    language.add("q", ONE)
    language.add("D_S", S(V("v")))
    language.add("D_0", ZERO)
    language.add("D_id", V("v"))
    language.add("D_p", D("D_S", V("v"), ZERO))
    checks: list[dict] = []

    def record(name: str, passed: bool, detail: str = "") -> None:
        checks.append({"name": name, "passed": bool(passed), "detail": detail})
        if not passed:
            raise AssertionError(name)

    for bad_name, bad_body in (("bad_self", D("bad_self", V("v"), ZERO)),
                               ("bad_parameter", V("a"))):
        rejected = False
        try:
            language.add(bad_name, bad_body)
        except ValueError:
            rejected = True
        record(bad_name + "_rejected", rejected)

    dynamic = [G(ZERO, ZERO, language), G(N, A, language),
               G(D("D_S", S(N), ZERO), N, language),
               G(S(D("D_S", N, ZERO)), N, language)]
    matrices = [(f"G_{i}", f) for i, f in enumerate(dynamic)]
    matrices += [(f"R_{h}", R(h, language)) for h in language.bodies]
    matrices += [(f"T_{h}", T(h, language)) for h in language.bodies]

    for name, matrix in matrices:
        record(name + "_admitted", classify(matrix, language) == name[0])
        record(name + "_closed_axiom", not fv_formula(P15(matrix)))
        record(name + "_two_variable_names", all_names(P15(matrix)) <= {"n", "a"})
        if name[0] in {"R", "T"}:
            record(name + "_stationary", subst_formula(matrix, "n", S(N)) == matrix)

    old_guard = Imp(Or(Eq(ZERO, A), DELTA), Eq(N, A))
    record("old_arbitrary_guard_not_admitted", classify(old_guard, language) is None)
    rejected = False
    try:
        G(V("outside"), ZERO, language)
    except ValueError:
        rejected = True
    record("external_dynamic_variable_rejected", rejected)

    capture_example = All("a", Eq(N, A))
    hygienic = subst_formula(capture_example, "n", A)
    record("capture_avoidance", fv_formula(hygienic) == {"a"}
           and hygienic.name != "a" and hygienic == All("b0", Eq(A, V("b0"))))
    shadowed = All("n", Eq(N, A))
    record("bound_occurrences_untouched", subst_formula(shadowed, "n", S(N)) == shadowed)

    snapshot = {name: encode(body) for name, body in language.bodies.items()}
    active = D("D_p", N, A)
    changed = subst_term(active, "n", S(N))
    record("active_arguments_substituted", changed == D("D_p", S(N), A))
    record("stored_body_not_an_active_occurrence", subst_term(active, "v", A) == active)
    record("descriptor_table_unchanged", snapshot ==
           {name: encode(body) for name, body in language.bodies.items()})
    record("actual_body_substitution", language.instantiate("D_S", active) == S(active))

    opaque = Formula("opaque", (N, A), "F")
    record("opaque_P15_count", size(P15(opaque)) == 15,
           "The subtotal excludes all admitted matrices, descriptors, and the generator.")
    record("fixed_atom_counts", size(DELTA) == 4 and size(SIGMA) == 6
           and size(Eq(N, ZERO)) == 3)
    comparisons = []
    for _, matrix in matrices[:len(dynamic)]:
        equation = matrix.args[1].args[1]
        base_equation = subst_formula(equation, "n", ZERO)
        previous = Imp(Or(base_equation, DELTA), equation)
        record("G_size_identity_" + str(len(comparisons)), size(matrix) == size(equation) + 11)
        record("guard_size_identity_" + str(len(comparisons)),
               size(previous) == size(base_equation) + size(equation) + 6)
        count_n = free_occurrences(equation, "n")
        record("base_substitution_preserves_nodes_" + str(len(comparisons)),
               size(base_equation) == size(equation))
        record("expanded_size_identity_" + str(len(comparisons)),
               size(P15(matrix)) == 3 * size(equation) + 39 + count_n
               and size(P15(previous)) == 6 * size(equation) + 23 + count_n)
        comparisons.append({"equation": pretty(equation),
                            "equation_nodes": size(equation),
                            "free_n_occurrences": count_n,
                            "new_matrix_nodes": size(matrix),
                            "old_atomic_guard_nodes": size(previous),
                            "new_full_axiom_nodes": size(P15(matrix)),
                            "old_full_axiom_nodes": size(P15(previous))})

    # This truth table checks just the logical shape of the reflexive probe:
    # sigma AND (z OR true) has the same truth value at both locations.
    record("reflexive_separation_probe_truth_table", all(
        not (sigma and (at_zero or True)) or (sigma and (next_zero or True))
        for sigma, at_zero, next_zero in product((False, True), repeat=3)),
        "A finite propositional diagnostic; the written intuitionistic proof is separate.")

    bounded_cases = 0
    for h in language.bodies:
        for n in range(7):
            for a in range(5):
                values = {"n": n, "a": a}
                assert check_equation(R(h, language).args[0], values, language)
                # T swaps the counter a and seed n by definition.
                assert check_equation(T(h, language).args[0], values, language)
                assert eval_term(D(h, ZERO, A), values, language) == a
                assert eval_term(D(h, ONE, A), values, language) == a
                bounded_cases += 4
    record("bounded_standard_computation_diagnostics", True,
           f"{bounded_cases} equation evaluations; n=0..6, a=0..4, five descriptors.")

    result = {
        "status": "passed", "scope": "Syntactic and finite standard-model diagnostics only; no formal proof claim.",
        "checks": checks, "check_count": len(checks),
        "literal_matrix_classes": ["G", "R", "T"],
        "formula_metavariables_in_dynamic_constructor": 0,
        "term_inputs_in_dynamic_constructor": 2,
        "dynamic_base_substitution_tests": 0,
        "intuitionistic_only_matrix_classes": 0,
        "opaque_wrapper_nodes": 15,
        "atomic_matrix_comparisons": comparisons,
        "bounded_standard_equation_evaluations": bounded_cases,
    }
    examples = {
        "descriptors_in_dependency_order": [{"name": h, "body": encode(b)}
                                            for h, b in language.bodies.items()],
        "generated": [{"name": name, "matrix": encode(matrix),
                       "axiom": encode(P15(matrix)), "axiom_nodes": size(P15(matrix))}
                      for name, matrix in matrices],
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "diagnostics.json").write_text(json.dumps(result, indent=2) + "\n")
    (output_dir / "generated_examples.json").write_text(json.dumps(examples, indent=2) + "\n")
    text_lines = ["FINITE GENERATED EXAMPLES; descriptor names are abbreviations.", ""]
    text_lines += [f"{name}: h(v) := {pretty(body)}" for name, body in language.bodies.items()]
    for name, matrix in matrices:
        text_lines += ["", name, "Matrix: " + pretty(matrix), "Axiom: " + pretty(P15(matrix))]
    (output_dir / "generated_examples.txt").write_text("\n".join(text_lines) + "\n")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    arguments = parser.parse_args()
    result = run(arguments.output_dir)
    print(json.dumps({"status": result["status"], "check_count": result["check_count"],
                      "bounded_standard_equation_evaluations": result["bounded_standard_equation_evaluations"],
                      "opaque_wrapper_nodes": result["opaque_wrapper_nodes"],
                      "scope": result["scope"]}, indent=2))
