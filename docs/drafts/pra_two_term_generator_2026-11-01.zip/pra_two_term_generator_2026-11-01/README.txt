PRA FROM A TWO-TERM AXIOM GENERATOR
Prepared for Vladimir Reshetnikov, 1 November 2026 (America/Los_Angeles)

MAIN RESULT

Replace the strongest delayed-iteration draft's arbitrary quantifier-free
dynamic input by two terms t(n,a), u(n,a) and the fixed matrix

    F(n,a) = (0=S(0) -> bottom) AND (n=0 OR t(n,a)=u(n,a)).

Keep its two stationary computation matrices and the inherited propagation
wrapper. The resulting theory is constructively equivalent in the same
language to the strongest scalar draft. It has a common conservative
definitional extension with first-order PRA, separately in classical and
intuitionistic logic. Both interpretations preserve the entire carrier and
native equality, and both internal round trips are the identity.

The improvement is the fixed, shallow logical input grammar. There is no
arbitrary formula input, dynamic zero-substitution/copy test, root-unfolding
admission test, or separate intuitionistic matrix class. The outer-template
subtotal stays 15. Small expanded axioms can become longer. No absolute
minimality or new outer-template record is claimed.

CONTENTS

  report.pdf                 Complete compiled research report.
  report.tex                 Main LaTeX source and exact specification.
  arithmetic.tex             Equation-only equality reflection and QFI.
  pairing.tex                Self-contained one-parameter pairing proof.
  interpretations.tex        PR compiler, both interpretations/round trips.
  comparison.tex             Comparison, scope, questions, references.
  AXIOMS.txt                 Standalone plain-text exact specification.
  build.py                   Rebuild PDF and rerun syntax diagnostics.
  checks/check_schema.py     Executable finite-syntax generator/checks.
  checks/diagnostics.json    Results: 82 checks, 700 finite evaluations.
  checks/generated_examples.json / .txt
                             Expanded examples in machine/human form.
  formal/TermKernel.lean     Twelve constructive arbitrary-carrier lemmas.
  formal/verification.*      Successful Lean compiler output and scope.
  formal/SCOPE.txt           Precisely what the formal file verifies.
  audit/source_manifest.json Pinned comparison sources and hashes.
  audit/mathematical_review.txt
                             Independent review of the new proof kernel.
  audit/draft_review.txt     Review of all six current archives.
  audit/build_receipt.json   Reproduction details.
  audit/pdf_validation.json  Final rendering/layout inspection record.
  SHA256SUMS.txt             Hashes of the packaged files except this list.

REPRODUCTION

From this directory:

  python3 build.py

Requires Python 3.10 or later, latexmk, pdfLaTeX, and the standard packages
listed at the start of report.tex. Only Python's standard library is used
by the code artifacts. To rerun the optional formal kernel check:

  python3 build.py --lean /path/to/lean

Lean 4.19.0 was used for the delivered verification. All twelve printed
axiom-dependency reports are empty. No built-in Nat induction or Classical
axiom is used. The entire first-order bi-interpretation is a written proof,
not a fully machine-formalized theorem; the exact boundary is in SCOPE.txt.

SOURCE SNAPSHOT

VladimirReshetnikov/ProveIt, docs/drafts, commit
13300d26dac24e7e6b75fe38fd21fb5b5d416d41.

All six current archive bytes were matched to GitHub's recorded Git blob
hashes. The strongest scalar baseline is the archive whose name ends
pra_delayed_iteration_2026-11-01(1).zip. The delayed constructor, two-clause
reset encoding, P15 wrapper, equation-only arithmetic calibration, and
pairing method are credited to the inspected drafts. The new contribution
is the two-term matrix and its constructive recovery of coverage and full
induction, with complete integration into the interpretation proof.

The accompanying code labels the new dynamic family G; the report uses
the same G/R/T family labels. E denotes the varying equation t=u.
