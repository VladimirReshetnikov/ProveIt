#!/usr/bin/env python3
"""Rebuild the research report and its scoped checks.

Requirements: Python 3.10+, latexmk, pdfLaTeX and the TeX packages listed in
report.tex. Optionally pass --lean /path/to/lean (verified with Lean 4.19.0).
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(command: list[str], log: Path) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout[-6000:])
        raise SystemExit(result.returncode)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Optional Lean compiler executable")
    args = parser.parse_args()
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)
    run([sys.executable, "checks/check_schema.py", "--output-dir", "checks"],
        audit / "syntax_console.txt")
    engine = shutil.which("latexmk")
    if not engine:
        raise SystemExit("latexmk is required to compile report.tex")
    run([engine, "-pdf", "-interaction=nonstopmode", "-halt-on-error",
         "-file-line-error", "-outdir=_build", "report.tex"],
        audit / "latex_console.txt")
    shutil.copy2(ROOT / "_build/report.pdf", ROOT / "report.pdf")
    latex_log = (ROOT / "_build/report.log").read_text(errors="replace")
    warnings = [line for line in latex_log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()
                or "multiply defined" in line.lower()]
    receipt: dict = {"pdf": "report.pdf", "latex_problem_lines": warnings,
                     "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
                     "diagnostics": json.loads((ROOT / "checks/diagnostics.json").read_text()),
                     "lean_rechecked": False}
    if args.lean:
        version = run([args.lean, "--version"], audit / "lean_version.txt").stdout.strip()
        result = run([args.lean, "formal/TermKernel.lean"],
                     ROOT / "formal/verification.txt")
        records = [line for line in result.stdout.splitlines() if "does not depend on any axioms" in line]
        if len(records) != 12:
            raise SystemExit("Expected twelve empty axiom-dependency reports")
        verification = {"compiler": version, "exit_code": result.returncode,
                        "source_sha256": hashlib.sha256((ROOT / "formal/TermKernel.lean").read_bytes()).hexdigest(),
                        "printed_theorem_count": len(records),
                        "all_printed_dependencies_empty": True,
                        "scope": "Arbitrary-carrier kernel under explicit hypotheses; not whole-theory formalization."}
        (ROOT / "formal/verification.json").write_text(json.dumps(verification, indent=2) + "\n")
        receipt["lean_rechecked"] = True
    (audit / "build_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"pdf": str(ROOT / "report.pdf"),
                      "syntax_checks": receipt["diagnostics"]["check_count"],
                      "latex_problem_lines": warnings,
                      "lean_rechecked": receipt["lean_rechecked"]}, indent=2))


if __name__ == "__main__":
    main()
