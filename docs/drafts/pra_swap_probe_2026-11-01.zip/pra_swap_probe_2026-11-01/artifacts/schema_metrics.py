#!/usr/bin/env python3
"""Reproduce explicit formula-tree ledgers; these are not theory bit lengths."""
from pathlib import Path
import json

def node(tag, *children):
    return (tag, *children)

def size(tree):
    return 1 + sum(size(child) for child in tree[1:])

def forall(names, body):
    for name in reversed(names):
        body = node("forall " + name, body)
    return body

def eq(x, y):
    return node("=", x, y)

def implies(x, y):
    return node("implies", x, y)

def either(x, y):
    return node("or", x, y)

def neg(x):
    return implies(x, node("bottom"))

zero, n, a, x, y = (node(s) for s in ("0", "n", "a", "x", "y"))

def S(term):
    return node("S", term)

def formulas(m):
    assert m >= 1
    extras = [node("b" + str(i)) for i in range(m - 1)]
    pars = [a] + extras
    names = [term[0] for term in pars]
    R = lambda first, second: node("R", first, second, *extras)
    F = lambda counter: node("f", counter, *pars)
    base = forall(names, eq(R(zero, a), a))
    step = forall(["n"] + names,
                  eq(R(S(n), a), node("h", n, a, *extras, R(a, n))))
    stationary = forall(["n"], eq(F(S(n)), F(n)))
    probe = forall(names, implies(stationary, forall(["n"], either(
        eq(node("T", F(zero), a), a), eq(F(n), a)))))
    sep = neg(eq(zero, S(zero)))
    old_O = forall(["x", "y"], either(eq(node("T", x, y), y), eq(x, y)))
    old_SS = forall(names, implies(stationary, forall(["n"],
        neg(eq(S(F(n)), F(zero))))))
    return {"base": base, "step": step, "separation": sep,
            "relative_probe": probe, "old_off_diagonal": old_O,
            "old_stationary_separation": old_SS}

def main():
    rows = []
    for m in range(1, 6):
        counts = {name: size(tree) for name, tree in formulas(m).items()}
        computation = counts["base"] + counts["step"]
        new_total = computation + counts["separation"] + counts["relative_probe"]
        old_total = computation + counts["old_off_diagonal"] + counts["old_stationary_separation"]
        assert counts["base"] == 2*m + 4
        assert counts["step"] == 4*m + 9
        assert counts["relative_probe"] == 5*m + 20
        assert counts["separation"] == 6
        assert new_total == 11*m + 39
        assert old_total == 11*m + 41
        rows.append({"passive_parameters_including_a": m, **counts,
                     "computation": computation, "new_display": new_total,
                     "old_swap_display": old_total})
    C = lambda z, u, v: node("C", z, u, v)
    D = lambda u, v: node("D", u, v)
    selected = {"C": node("b"), "D": node("v"), "T": C(D(a, n), n, a)}
    old_selected = {"C": node("b"), "D": node("v"),
                    "T": C(D(a, n), C(D(n, a), a, zero), a)}
    body_counts = {name: size(tree) for name, tree in selected.items()}
    old_body_counts = {name: size(tree) for name, tree in old_selected.items()}
    assert body_counts == {"C": 1, "D": 1, "T": 6}
    assert old_body_counts == {"C": 1, "D": 1, "T": 11}
    result = {
        "convention": "One node per variable, constant, function application, equality, connective, bottom and individual quantifier. Negation expands to implication to bottom. Universal closures included. Stored bodies separate.",
        "scope": "Partial tree ledgers, not total encoded generator length or global minimality. Schematic f/h bodies not substituted into displays. Every finite parameter arity is admitted.",
        "rows": rows,
        "new_selected_body_nodes": body_counts,
        "new_selected_body_total": sum(body_counts.values()),
        "old_swap_selected_body_nodes": old_body_counts,
        "old_swap_selected_body_total": sum(old_body_counts.values()),
        "representative_new_combined_partial_ledger": rows[0]["new_display"] + sum(body_counts.values()),
        "representative_old_combined_partial_ledger": rows[0]["old_swap_display"] + sum(old_body_counts.values()),
        "exact_trees_at_one_passive_parameter": formulas(1),
        "selected_body_trees": selected,
    }
    output = Path(__file__).with_name("schema_metrics_results.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if "trees" not in k}, indent=2))

if __name__ == "__main__":
    main()
