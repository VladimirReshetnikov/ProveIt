#!/usr/bin/env python3
"""Finite diagnostics for initialized swap recursion with a relative probe.

These computations are NOT a proof of the first-order equivalence theorem,
not a model search, and not a formal proof-assistant certificate. They check
the actual selected terms and both numerical compilers on finite examples.
The separate symbolic checks use only the explicitly listed rewrite rules.
"""

from __future__ import annotations

import hashlib
import itertools
import json
from functools import lru_cache
from pathlib import Path


def make_swap(update):
    """Execute the source recursion; each call decreases x+y."""

    @lru_cache(maxsize=None)
    def run(x, a, parameters=()):
        assert x >= 0 and a >= 0
        if x == 0:
            return a
        return update(x - 1, a, parameters, run(a, x - 1, parameters))

    return run


raw_C = make_swap(lambda n, a, parameters, v: parameters[0])
D = make_swap(lambda n, a, parameters, v: v)


def C(z, u, w):
    return raw_C(z, u, (w,))


def p(x):
    return D(x, 0)


T = make_swap(lambda n, a, parameters, v: C(D(a, n), n, a))


def E(x, y):
    return D(y, T(x + 1, y + 1))


def J(z, u, w):
    return C(E(z, 0), u, w)


def diagonal_fold(update, x, y, parameters=()):
    """Ordinary primitive-recursive compiler; independent of raw swap."""
    d, e, m = max(x - y, 0), max(y - x, 0), min(x, y)
    predecessor_d = max(d - 1, 0)
    v = e if d == 0 else update(predecessor_d, 0, parameters, predecessor_d)
    for j in range(m):
        v = update(
            d + j,
            e + j + 1,
            parameters,
            update(e + j, d + j, parameters, v),
        )
    return v


def ordinary_to_swap(base, step):
    def update(n, a, parameters, v):
        # E is already Boolean, so the manuscript uses raw C here.
        return C(
            E(a, n),
            v,
            J(n, base(parameters), step(p(n), parameters, v)),
        )

    raw = make_swap(update)

    def compiled(n, parameters=()):
        return raw(n + 1, n + 1, parameters)

    return compiled


def check_numerical_comparator():
    count = 0
    for x, y in itertools.product(range(41), repeat=2):
        expected_d = max(y - x, 0) + max(max(x - y, 0) - 1, 0)
        assert D(x, y) == expected_d, ("D", x, y)
        assert (D(x, y) == 0) == (x == y or x == y + 1)
        expected_t = max(y - 1, 0) if x == y else y
        assert T(x, y) == expected_t, ("T", x, y)
        assert T(x, y) == y or x == y
        assert E(x, y) == int(x != y), ("E", x, y)
        count += 1
    for z, u, w in itertools.product(range(8), repeat=3):
        assert C(z, u, w) == (u if z == 0 else w)
        assert J(z, u, w) == (u if z == 0 else w)
    return {"pair_grid": "0..40 squared", "pairs_checked": count,
            "selector_triples_checked": 8**3}


def check_swap_compiler():
    updates = [
        ("identity", lambda n, a, b, v: v, [()]),
        ("successor", lambda n, a, b, v: v + 1, [()]),
        ("counter_and_argument", lambda n, a, b, v: n + 3 * a + v, [()]),
        ("nonlinear_bounded", lambda n, a, b, v: (v * v + 2 * n + a) % 257, [()]),
        ("branching", lambda n, a, b, v: n + a if v % 2 == 0 else v + a, [()]),
        ("frozen_affine", lambda n, a, b, v: b[0] * v + n + a + b[1],
         [(0, 0), (1, 3), (2, 1)]),
        ("frozen_nonlinear", lambda n, a, b, v: (v * (a + 1) + n + b[0]) % b[1],
         [(7, 31), (11, 127)]),
    ]
    per_family = {}
    for name, update, choices in updates:
        raw = make_swap(update)
        count = 0
        for parameters in choices:
            for x, y in itertools.product(range(15), repeat=2):
                got = diagonal_fold(update, x, y, parameters)
                want = raw(x, y, parameters)
                assert got == want, (name, x, y, parameters, got, want)
                count += 1
        per_family[name] = count
    return {"grid": "0..14 squared", "families": per_family,
            "total_cases": sum(per_family.values())}


def check_ordinary_compiler():
    tasks = [
        ("sum", lambda b: 0, lambda n, b, v: v + n + 1, [()]),
        ("factorial", lambda b: 1, lambda n, b, v: (n + 1) * v, [()]),
        ("parameterized_affine", lambda b: b[0],
         lambda n, b, v: b[1] * v + n + b[2],
         [(0, 0, 3), (2, 1, 4), (3, 2, 1)]),
        ("parameterized_bounded", lambda b: b[0] % b[1],
         lambda n, b, v: (v * v + b[0] * n + 1) % b[1],
         [(2, 17), (3, 31)]),
    ]
    per_family = {}
    for name, base, step, choices in tasks:
        compiled = ordinary_to_swap(base, step)
        count = 0
        for parameters in choices:
            direct = base(parameters)
            for n in range(11):
                assert compiled(n, parameters) == direct, (
                    name, n, parameters, compiled(n, parameters), direct
                )
                direct = step(n, parameters, direct)
                count += 1
        per_family[name] = count
    return {"counter_range": "0..10", "families": per_family,
            "total_cases": sum(per_family.values())}


# Small first-order term syntax for pure, exact symbolic rewriting.
def var(name):
    return ("var", name)


ZERO = ("zero",)


def app(symbol, *arguments):
    return (symbol, *arguments)


def normalize(term, derived_diagonal=False):
    if term[0] in ("var", "zero"):
        return term
    symbol, *arguments = term
    arguments = [normalize(a, derived_diagonal) for a in arguments]
    term = (symbol, *arguments)
    replacement = None
    if symbol == "D":
        x, a = arguments
        if x == ZERO:
            replacement = a
        elif x[0] == "S":
            replacement = app("D", a, x[1])
        elif derived_diagonal and x == a:
            replacement = ZERO
    elif symbol == "C":
        z, u, w = arguments
        if z == ZERO:
            replacement = u
        elif z[0] == "S":
            replacement = w
    elif symbol == "T":
        x, a = arguments
        if x == ZERO:
            replacement = a
        elif x[0] == "S":
            n = x[1]
            replacement = app("C", app("D", a, n), n, a)
    if replacement is None:
        return term
    return normalize(replacement, derived_diagonal)


def check_symbolic_rewrites():
    x = var("x")
    sx, ssx = app("S", x), app("S", app("S", x))
    one = app("S", ZERO)
    pairs = [
        ("p(0)=0", app("D", ZERO, ZERO), ZERO),
        ("p(Sx)=x", app("D", sx, ZERO), x),
        ("D(Sx,Sx)=D(x,x)", app("D", sx, sx), app("D", x, x)),
        ("D(Sx,SSx)=D(x,Sx)", app("D", sx, ssx), app("D", x, sx)),
        ("D(0,0)=0", app("D", ZERO, ZERO), ZERO),
        ("D(0,1)=1", app("D", ZERO, one), one),
        ("T(1,1)=0", app("T", one, one), ZERO),
    ]
    for name, lhs, rhs in pairs:
        assert normalize(lhs) == normalize(rhs), (name, normalize(lhs), normalize(rhs))
    # The diagonal's general case needs the proved stationary diagonal;
    # we explicitly record that dependency, rather than adding induction.
    diagonal_term = app("T", sx, sx)
    assert normalize(diagonal_term) != x
    assert normalize(diagonal_term, derived_diagonal=True) == x
    return {
        "pure_equation_checks": [q[0] for q in pairs],
        "derived_rule_check": "T(Sx,Sx)=x using D(x,x)=0",
        "derived_rule_is_needed_by_this_rewriter": True,
        "not_used": ["induction", "constructor coverage", "standard-number substitution"],
    }


def formulas_depth_two():
    atoms = [("P",), ("Q",), ("true",), ("false",)]
    depth_one = atoms + [(op, a, b) for op in ("and", "or", "imp")
                         for a in atoms for b in atoms]
    return atoms + [(op, a, b) for op in ("and", "or", "imp")
                    for a in depth_one for b in depth_one]


def evaluate_formula(formula, valuation):
    tag = formula[0]
    if tag in ("P", "Q"):
        truth = valuation[tag]
        return truth, int(not truth)
    if tag in ("true", "false"):
        truth = tag == "true"
        return truth, int(not truth)
    truth_b, error_b = evaluate_formula(formula[1], valuation)
    truth_c, error_c = evaluate_formula(formula[2], valuation)
    if tag == "and":
        return truth_b and truth_c, C(error_b, error_c, 1)
    if tag == "or":
        return truth_b or truth_c, C(error_b, 0, error_c)
    assert tag == "imp"
    return (not truth_b) or truth_c, C(error_b, error_c, 0)


def check_boolean_and_latch():
    formulas = formulas_depth_two()
    count = 0
    for p_value, q_value in itertools.product((False, True), repeat=2):
        for formula in formulas:
            truth, error = evaluate_formula(formula, {"P": p_value, "Q": q_value})
            assert error in (0, 1) and (error == 0) == truth
            count += 1
    local_checks = 0
    full_induction_sequences = 0
    for errors in itertools.product((0, 1), repeat=8):
        running = [1]
        for error in errors:
            running.append(C(error, running[-1], 0))
        for n in range(7):
            if errors[n] != 0 or errors[n + 1] == 0:
                assert running[n + 2] == running[n + 1]
                local_checks += 1
        for n, error in enumerate(errors):
            if error == 1:
                assert running[n + 1] == 0
        if errors[0] == 0 and all(errors[n] != 0 or errors[n + 1] == 0 for n in range(7)):
            assert all(e == 0 for e in errors)
            assert all(v == 1 for v in running)
            full_induction_sequences += 1
    return {"formula_syntax_depth": 2, "formulas": len(formulas),
            "formula_valuation_cases": count, "latch_bit_sequences": 2**8,
            "local_latch_stationarity_checks": local_checks,
            "finite_sequences_satisfying_base_and_all_steps": full_induction_sequences,
            "scope": "Boolean diagnostics only; no proof of intuitionistic or first-order completeness"}


def check_negative_control():
    bad_T = make_swap(lambda n, a, parameters, v: C(D(a, n), a, a))
    diagonal_failures, equality_failures = [], []
    for n in range(5):
        if bad_T(n + 1, n + 1) != n:
            diagonal_failures.append({"n": n, "actual": bad_T(n + 1, n + 1), "expected": n})
    for x, y in itertools.product(range(5), repeat=2):
        got = D(y, bad_T(x + 1, y + 1))
        if got != int(x != y):
            equality_failures.append({"x": x, "y": y, "actual": got, "expected": int(x != y)})
    assert diagonal_failures and equality_failures
    return {"mutated_body": "C(D(a,n),a,a)", "mutation_rejected": True,
            "first_diagonal_counterexample": diagonal_failures[0],
            "first_equality_counterexample": equality_failures[0]}


def main():
    result = {
        "scope": "Finite diagnostics and explicit symbolic rewrites, not an equivalence proof or proof-assistant certificate",
        "selected_update": "T(Sn,a)=C(D(a,n),n,a)",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "checks": {},
    }
    checks = [
        ("selected_terms", check_numerical_comparator),
        ("swap_to_ordinary", check_swap_compiler),
        ("ordinary_to_swap", check_ordinary_compiler),
        ("symbolic_rewrites", check_symbolic_rewrites),
        ("boolean_and_latch", check_boolean_and_latch),
        ("negative_control", check_negative_control),
    ]
    for name, check in checks:
        result["checks"][name] = check()
    result["all_checks_passed"] = True
    output = Path(__file__).with_name("check_swap_probe_results.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
