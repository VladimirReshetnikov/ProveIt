#!/usr/bin/env python3
"""Exhaustive *local* search for a short initialized-swap comparator.

This checks the exact descriptor grammar

    h ::= 0 | n | a | v | S(h) | D(h,h) | C(h,h,h)

at unit tree-node cost.  C(z,u,w) selects u when z=0, otherwise w;
D(x,y) = y-x when x<=y, and x-y-1 otherwise.  Every descriptor h
denotes the numerically well-founded function

    R_h(0,a) = a
    R_h(S n,a) = h(n,a,R_h(a,n)).

The required comparator property is R_h(x,a)=a when x!=a, and
R_h(a,a)!=a for a>0.  A finite counterexample disproves the property.
A finite PASS never proves it.  The manuscript independently proves the
property for C(D(a,n),n,a).  With max-size=6, every smaller descriptor
has a counterexample; this is minimality only in this exact grammar,
with C and D already available, and this exact comparator requirement.
It is not minimality among all arithmetic theories or all signatures.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

Term = tuple


def display(t: Term) -> str:
    if len(t) == 1:
        return t[0]
    return t[0] + "(" + ",".join(map(display, t[1:])) + ")"


def size(t: Term) -> int:
    return 1 + sum(map(size, t[1:]))


def descriptions(max_size: int) -> dict[int, list[Term]]:
    by_size = {1: [(symbol,) for symbol in ("0", "n", "a", "v")]}
    for weight in range(2, max_size + 1):
        row = [("S", t) for t in by_size[weight - 1]]
        for i in range(1, weight - 1):
            j = weight - 1 - i
            row.extend(("D", s, t) for s in by_size[i] for t in by_size[j])
        for i in range(1, weight - 2):
            for j in range(1, weight - 1 - i):
                k = weight - 1 - i - j
                row.extend(("C", r, s, t)
                           for r in by_size[i]
                           for s in by_size[j]
                           for t in by_size[k])
        by_size[weight] = row
    return by_size


def distance(x: int, y: int) -> int:
    return y - x if x <= y else x - y - 1


def evaluate(t: Term, n: int, a: int, v: int) -> int:
    symbol = t[0]
    if symbol == "0":
        return 0
    if symbol == "n":
        return n
    if symbol == "a":
        return a
    if symbol == "v":
        return v
    if symbol == "S":
        return evaluate(t[1], n, a, v) + 1
    if symbol == "D":
        return distance(evaluate(t[1], n, a, v), evaluate(t[2], n, a, v))
    if symbol == "C":
        branch = 2 if evaluate(t[1], n, a, v) == 0 else 3
        return evaluate(t[branch], n, a, v)
    raise ValueError(symbol)


def counterexample(h: Term, bound: int) -> dict | None:
    # The recursive argument (a,x-1) has sum one smaller than (x,a).
    values = {}
    for total in range(2 * bound + 1):
        for x in range(max(0, total - bound), min(bound, total) + 1):
            a = total - x
            r = a if x == 0 else evaluate(h, x - 1, a, values[a, x - 1])
            values[x, a] = r
            if x != a and r != a:
                return {"x": x, "a": a, "value": r, "required": "value = a"}
            if x == a and a > 0 and r == a:
                return {"x": x, "a": a, "value": r, "required": "value != a"}
    return None


def run(max_size: int, bound: int) -> dict:
    grammar = descriptions(max_size)
    summaries = []
    certificates = []
    survivors = []
    all_text = []
    for weight, terms in grammar.items():
        assert len({display(t) for t in terms}) == len(terms)
        assert all(size(t) == weight for t in terms)
        passed = []
        witness_histogram = Counter()
        for t in terms:
            name = display(t)
            all_text.append(name)
            bad = counterexample(t, bound)
            if bad is None:
                passed.append(name)
                survivors.append({"size": weight, "body": name})
            else:
                witness_histogram[f"{bad['x']},{bad['a']}"] += 1
                if weight < 6:
                    certificates.append({"size": weight, "body": name, **bad})
        summaries.append({
            "size": weight,
            "descriptors": len(terms),
            "finite_survivors": passed,
            "counterexample_positions": dict(sorted(witness_histogram.items())),
        })
    return {
        "scope": __doc__.strip(),
        "bound": bound,
        "max_size": max_size,
        "counts": summaries,
        "all_enumerated_descriptions_sha256": hashlib.sha256(
            "\n".join(all_text).encode("ascii")).hexdigest(),
        "finite_survivors": survivors,
        "counterexamples_for_all_bodies_smaller_than_six": certificates,
        "smaller_body_count": len(certificates),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-size", type=int, default=6)
    parser.add_argument("--bound", type=int, default=12)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if not 1 <= args.max_size <= 8 or args.bound < 1:
        parser.error("Use 1<=max-size<=8 and bound>=1.")
    result = run(args.max_size, args.bound)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")
    print(json.dumps({k: result[k] for k in (
        "bound", "max_size", "counts", "finite_survivors", "smaller_body_count"
    )}, indent=2))


if __name__ == "__main__":
    main()
