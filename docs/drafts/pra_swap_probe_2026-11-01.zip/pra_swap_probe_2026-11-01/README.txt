A SMALLER COMMON AXIOMATIZATION OF PRIMITIVE RECURSIVE ARITHMETIC
==============================================================
Prepared for Vladimir Reshetnikov, 1 November 2026.

Main result
-----------
The same nonlogical specification is definitionally equivalent, and hence
bi-interpretable and equiconsistent, with first-order PRA in each matching
ambient logic: classical and intuitionistic.

Compared with the seven current ProveIt drafts at the pinned commit, the
proposed common basis reduces the best display count from 52 to 50 and
the selected descriptor bodies from 13 to 8. Both are partial tree metrics;
neither is an absolute encoded theory size. No global minimality is claimed.

Files
-----
report.tex / report.pdf       Complete constructive proof and comparison.
AXIOMS.txt                    Complete plain-text specification.
build.py                      Rebuild the PDF and run included checks.
artifacts/check_swap_probe.py Finite numerical and exact symbolic checks.
artifacts/schema_metrics.py   Reproducible formula and program tree counts.
artifacts/short_comparator_search.py
                             Exhaustive search in a stated comparator grammar.
artifacts/*_results.json      Recorded executable results and witnesses.
audit/source_manifest.json   Pinned sources, Git blob hashes, SHA-256 hashes.
audit/comparison.json         Current-source comparison table and metric scope.
audit/validation.json         Build and verification record.
SHA256SUMS.txt                Hashes of all other delivered files.

Reproduction
------------
Python 3.10+ and a TeX installation with pdflatex and the packages named in
the preamble are sufficient. No third-party Python packages are required
for the mathematical diagnostics. From this directory:

  python3 build.py

The script runs the three checkers and pdflatex twice. It does not download
dependencies or source archives. The comparison sources are identified by
immutable Git commit and hashes; the original ZIP archives are not duplicated
in this deliverable.

Interpretation of the evidence
------------------------------
The paper proves the theorem, including internal uniqueness and both
round trips on the full carrier. Finite execution cannot prove this theorem.
The accompanying code supplies diagnostics, exact symbolic rewrite checks,
reproducible metric counts, and a scoped finite lower-bound certificate.
There is no claim of an end-to-end Lean or Rocq formalization.

The comparator lower bound is only for the fixed grammar printed in the
paper, with C and D already available. All 628 smaller bodies have explicit
counterexamples. Passing a finite test for a size-six body is not an infinite
correctness proof; the selected body's correctness is proved in the paper.

Source snapshot
---------------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: c5a6a6a4087c9a3a2e9ce4f4ad8ad6a79e466ef7
Seven current PRA draft archives plus docs/incoming inventory and README.
The source paper's Further research questions section records remaining work.
