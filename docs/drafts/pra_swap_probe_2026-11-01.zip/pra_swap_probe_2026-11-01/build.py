#!/usr/bin/env python3
"""Rebuild the research PDF and reproduce the finite diagnostics."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(*arguments):
    subprocess.run(arguments, cwd=ROOT, check=True)

def main():
    run(sys.executable, "artifacts/schema_metrics.py")
    run(sys.executable, "artifacts/check_swap_probe.py")
    run(sys.executable, "artifacts/short_comparator_search.py",
        "--output", "artifacts/short_comparator_search_results.json")
    for _ in range(2):
        run("pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex")
    log = (ROOT / "report.log").read_text(errors="replace")
    defects = [line for line in log.splitlines()
               if "Overfull" in line or "undefined" in line.lower()
               or "duplicate ignored" in line]
    if defects:
        raise RuntimeError("Review TeX diagnostics: " + json.dumps(defects))
    print("PDF rebuilt; finite diagnostics passed. The mathematical theorem is proved in the paper.")

if __name__ == "__main__":
    main()
