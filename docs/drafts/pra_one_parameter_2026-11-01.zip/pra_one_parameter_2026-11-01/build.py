#!/usr/bin/env python3
"""Rebuild the diagnostics and paper. Python 3 standard library only."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone


ROOT = Path(__file__).resolve().parent


def run(command: list[str], log: Path) -> dict:
    completed = subprocess.run(command, cwd=ROOT, text=True,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(completed.stdout, encoding="utf-8")
    result = {"command": command, "exit_code": completed.returncode,
              "log": str(log.relative_to(ROOT))}
    if completed.returncode:
        print(completed.stdout[-6000:], file=sys.stderr)
        raise RuntimeError(f"Command failed: {command}")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--checks-only", action="store_true")
    group.add_argument("--pdf-only", action="store_true")
    args = parser.parse_args()
    records = []
    if not args.pdf_only:
        for name in ("metrics", "binary_terms"):
            records.append(run([sys.executable, f"artifacts/{name}.py"],
                               ROOT / "audit" / f"{name}_execution.log"))
    if not args.checks_only:
        latex = shutil.which("pdflatex")
        if not latex:
            raise RuntimeError("pdflatex is required to compile report.tex")
        for pass_number in range(1, 4):
            records.append(run([latex, "-interaction=nonstopmode",
                                "-halt-on-error", "report.tex"],
                               ROOT / "audit" / f"latex_pass_{pass_number}.log"))
        log = (ROOT / "report.log").read_text(encoding="utf-8", errors="replace")
        bad = [line for line in log.splitlines()
               if "Overfull" in line or "undefined" in line.lower()
               or "Rerun to get" in line]
        if bad:
            raise RuntimeError("Unresolved LaTeX diagnostics: " + "\n".join(bad))
    record = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "checks_only": args.checks_only,
        "pdf_only": args.pdf_only,
        "commands": records,
        "source_sha256": hashlib.sha256((ROOT / "report.tex").read_bytes()).hexdigest(),
        "note": "Build success is not visual QA or a mathematical proof."
    }
    (ROOT / "audit" / "build_results.json").write_text(
        json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "commands": len(records),
                      "pdf": str(ROOT / "report.pdf")}, indent=2))


if __name__ == "__main__":
    main()
