#!/usr/bin/env python3
"""Reproduce the syntax metrics used in the accompanying PRA report.

This is a syntax checker, not a formal verification of the mathematics.
Every variable, constant, function/predicate application, connective, and
quantifier contributes one AST node.  Binder names do not contribute an
additional node.  Negation is expanded as P -> bottom.  Bound-variable
renaming has no cost.

Opaque A(n,c_1,...,c_q) nodes represent a FORMULA METAVARIABLE APPLICATION,
not an added relation symbol of the arithmetic language.  These template
counts do not measure the description length of a complete axiomatization,
its language grammar, its metasyntax, or its proofs.

Run with Python 3, without external dependencies:
    python3 metrics.py
    python3 metrics.py --output /some/path/metrics_results.json
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Node:
    kind: str
    children: tuple["Node", ...] = ()
    name: str = ""


def variable(name: str) -> Node:
    return Node("var", name=name)


def zero() -> Node:
    return Node("const", name="0")


def bottom() -> Node:
    return Node("bottom")


def function(name: str, *arguments: Node) -> Node:
    return Node("function", tuple(arguments), name)


def successor(term: Node) -> Node:
    return function("S", term)


def equality(left: Node, right: Node) -> Node:
    return Node("eq", (left, right))


def conjunction(left: Node, right: Node) -> Node:
    return Node("and", (left, right))


def disjunction(left: Node, right: Node) -> Node:
    return Node("or", (left, right))


def implication(left: Node, right: Node) -> Node:
    return Node("imp", (left, right))


def negation(formula: Node) -> Node:
    return implication(formula, bottom())


def quantify(kind: str, names: Iterable[str], formula: Node) -> Node:
    if kind not in {"forall", "exists"}:
        raise ValueError("Unknown quantifier")
    for name in reversed(tuple(names)):
        formula = Node(kind, (formula,), name)
    return formula


def size(node: Node) -> int:
    return 1 + sum(size(child) for child in node.children)


def free_variables(node: Node) -> set[str]:
    if node.kind == "var":
        return {node.name}
    result: set[str] = set()
    for child in node.children:
        result.update(free_variables(child))
    if node.kind in {"forall", "exists"}:
        result.discard(node.name)
    return result


def free_occurrences(node: Node, name: str) -> int:
    if node.kind == "var":
        return int(node.name == name)
    if node.kind in {"forall", "exists"} and node.name == name:
        return 0
    return sum(free_occurrences(child, name) for child in node.children)


def substitute(node: Node, name: str, replacement: Node) -> Node:
    """Capture-avoiding substitution for the fresh names used below."""
    if node.kind == "var":
        return replacement if node.name == name else node
    if node.kind in {"forall", "exists"}:
        if node.name == name:
            return node
        if node.name in free_variables(replacement):
            raise ValueError("Substitution would capture a free variable")
    return Node(
        node.kind,
        tuple(substitute(child, name, replacement) for child in node.children),
        node.name,
    )


def has_quantifiers(node: Node) -> bool:
    return node.kind in {"forall", "exists"} or any(
        has_quantifiers(child) for child in node.children
    )


def arity_violations(node: Node, maximum: int = 2) -> list[dict]:
    result = []
    if node.kind == "function" and len(node.children) > maximum:
        result.append({"symbol": node.name, "arity": len(node.children)})
    for child in node.children:
        result.extend(arity_violations(child, maximum))
    return result


def audit_predicate(formula: Node, induction_variable: str = "n") -> dict:
    """Audit only syntactic side conditions, not definability of symbols."""
    free = free_variables(formula)
    parameters = sorted(free - {induction_variable})
    violations = arity_violations(formula)
    quantifier_free = not has_quantifiers(formula)
    return {
        "free_variables": sorted(free),
        "frozen_parameters": parameters,
        "frozen_parameter_count": len(parameters),
        "quantifier_free": quantifier_free,
        "function_arity_violations": violations,
        "at_most_one_parameter": len(parameters) <= 1,
        "admissible_for_one_parameter_schema": (
            quantifier_free and len(parameters) <= 1 and not violations
        ),
        "limitation": (
            "Only free-variable and arity conditions are checked. "
            "Membership in the stagewise recursion grammar and proof "
            "correctness are not checked. An unused single parameter "
            "may be added when the formula has none."
        ),
    }


def audit_recursion_update(term: Node) -> dict:
    free = free_variables(term)
    extra = sorted(free - {"n", "u"})
    violations = arity_violations(term)
    return {
        "free_variables": sorted(free),
        "unpermitted_parameters": extra,
        "function_arity_violations": violations,
        "passes_free_variable_and_arity_checks": not extra and not violations,
    }


def separation_failure() -> Node:
    return equality(zero(), successor(zero()))


def recursion_schema() -> Node:
    a, n = variable("a"), variable("n")
    base = equality(function("R_h", zero(), a), a)
    step = equality(
        function("R_h", successor(n), a),
        function("h", n, function("R_h", n, a)),
    )
    return quantify("forall", ("a",), conjunction(base, quantify("forall", ("n",), step)))


def fused_schema(formula: Node, parameters: tuple[str, ...]) -> Node:
    n = variable("n")
    base = disjunction(substitute(formula, "n", zero()), separation_failure())
    progress = quantify(
        "forall", ("n",),
        implication(formula, substitute(formula, "n", successor(n))),
    )
    conclusion = quantify("forall", ("n",), formula)
    return quantify("forall", parameters, implication(conjunction(base, progress), conclusion))


def boundary_schema(formula: Node, parameters: tuple[str, ...]) -> Node:
    if free_variables(formula) & {"x", "y", "z"}:
        raise ValueError("Boundary witness names must be fresh")
    x, y, z = variable("x"), variable("y"), variable("z")
    premise = disjunction(substitute(formula, "n", z), separation_failure())
    boundary = disjunction(
        equality(x, zero()),
        conjunction(equality(x, successor(y)), negation(substitute(formula, "n", y))),
    )
    witnesses = quantify(
        "exists", ("x", "y"),
        conjunction(substitute(formula, "n", x), boundary),
    )
    return quantify("forall", ("z",) + parameters, implication(premise, witnesses))


def opaque_formula(parameters: tuple[str, ...]) -> Node:
    return Node(
        "formula_metavariable",
        (variable("n"),) + tuple(variable(name) for name in parameters),
        "A",
    )


def schematic_atomic_equality(parameters: tuple[str, ...]) -> Node:
    """An n-ary abbreviation example, not a literal binary-language claim."""
    args = (variable("n"),) + tuple(variable(name) for name in parameters)
    return equality(function("s", *args), function("t", *args))


def binary_atomic_equality(parameters: tuple[str, ...], offset: int = 0) -> Node:
    """All function applications have at most two arguments."""
    n = variable("n")
    left = function(f"s{offset}", n, zero())
    right = function(f"t{offset}", n, zero())
    for name in parameters:
        left = function(f"s{offset}", left, variable(name))
        right = function(f"t{offset}", right, variable(name))
    return equality(left, right)


def instance_record(label: str, formula: Node, parameters: tuple[str, ...]) -> dict:
    q, a, d = len(parameters), size(formula), free_occurrences(formula, "n")
    f_ast, b_ast = fused_schema(formula, parameters), boundary_schema(formula, parameters)
    common = size(recursion_schema())
    f_total, b_total = common + size(f_ast), common + size(b_ast)
    assert not free_variables(f_ast)
    assert not free_variables(b_ast)
    assert f_total == 4 * a + d + q + 28
    assert b_total == 3 * a + q + 39
    assert f_total - b_total == a + d - 11
    adaptive_choice = "F" if a + d <= 11 else "B"
    adaptive_total = f_total if adaptive_choice == "F" else b_total
    assert adaptive_total == min(f_total, b_total)
    if a + d > 11:
        assert size(negation(formula)) + free_occurrences(negation(formula), "n") > 11
    return {
        "label": label,
        "q": q,
        "a_formula_size": a,
        "d_induction_variable_occurrences": d,
        "F_schema_nodes": size(f_ast),
        "B_schema_nodes": size(b_ast),
        "F_with_common_recursion": f_total,
        "B_with_common_recursion": b_total,
        "boundary_saving": f_total - b_total,
        "adaptive_choice": adaptive_choice,
        "adaptive_with_common_recursion": adaptive_total,
        "side_condition_audit": audit_predicate(formula),
    }


def run_checks() -> dict:
    recursion_nodes = size(recursion_schema())
    assert recursion_nodes == 18
    template_matrix = []
    nary_atom_matrix = []
    actual_formula_matrix = []
    probe_checks = []

    for q in range(13):
        parameters = tuple(f"c{i}" for i in range(q))
        record = instance_record("opaque_A", opaque_formula(parameters), parameters)
        assert record["F_schema_nodes"] == 19 + 5 * q
        assert record["B_schema_nodes"] == 27 + 4 * q
        assert record["F_with_common_recursion"] == 37 + 5 * q
        assert record["B_with_common_recursion"] == 45 + 4 * q
        template_matrix.append(record)

        atom_record = instance_record(
            "schematic_s(n,c)=t(n,c)", schematic_atomic_equality(parameters), parameters,
        )
        assert atom_record["F_with_common_recursion"] == 50 + 9 * q
        assert atom_record["B_with_common_recursion"] == 54 + 7 * q
        nary_atom_matrix.append(atom_record)

    for q in range(5):
        parameters = tuple(f"c{i}" for i in range(q))
        atom = binary_atomic_equality(parameters)
        other = binary_atomic_equality(parameters, 1)
        examples = {
            "binary_atom": atom,
            "negated_binary_atom": negation(atom),
            "two_binary_atoms_and": conjunction(atom, other),
            "two_binary_atoms_or": disjunction(atom, other),
            "binary_atom_implication": implication(atom, other),
            "four_atoms": conjunction(disjunction(atom, other), implication(other, atom)),
            "bottom": bottom(),
        }
        for label, formula in examples.items():
            actual_formula_matrix.append(instance_record(label, formula, parameters))

        # C is independent of the fresh induction variable n.  Treat all its
        # original variables as frozen parameters in the decidability probe.
        c_formula = substitute(atom, "n", zero())
        probe = disjunction(
            conjunction(equality(variable("n"), zero()), c_formula),
            equality(variable("n"), successor(zero())),
        )
        probe_sum = size(probe) + free_occurrences(probe, "n")
        assert probe_sum == size(c_formula) + 11
        assert probe_sum > 11
        probe_checks.append({
            "q": q,
            "C_size": size(c_formula),
            "probe_size": size(probe),
            "probe_induction_variable_occurrences": free_occurrences(probe, "n"),
            "probe_sum": probe_sum,
            "hybrid_chooses_boundary": True,
        })

    # q = 1 is a restriction on admissible schema parameters, not a claim that
    # all full formula instances have 42 nodes.
    main_template = template_matrix[1]
    assert main_template["F_with_common_recursion"] == 42
    assert audit_predicate(binary_atomic_equality(("c",)))["admissible_for_one_parameter_schema"]
    assert not audit_predicate(binary_atomic_equality(("c0", "c1")))["admissible_for_one_parameter_schema"]
    assert not audit_predicate(quantify("forall", ("w",), equality(variable("w"), variable("n"))))["admissible_for_one_parameter_schema"]
    assert not audit_predicate(equality(function("bad", variable("n"), zero(), zero()), zero()))["admissible_for_one_parameter_schema"]

    update_audits = {
        "counter_projection": audit_recursion_update(variable("n")),
        "state_successor": audit_recursion_update(successor(variable("u"))),
        "forbidden_frozen_parameter": audit_recursion_update(function("f", variable("u"), variable("c"))),
    }
    assert update_audits["counter_projection"]["passes_free_variable_and_arity_checks"]
    assert update_audits["state_successor"]["passes_free_variable_and_arity_checks"]
    assert not update_audits["forbidden_frozen_parameter"]["passes_free_variable_and_arity_checks"]

    return {
        "status": "all assertions passed",
        "scope": (
            "AST counting and syntactic side-condition verification only; "
            "not a proof checker or a minimum-description-length theorem."
        ),
        "node_convention": (
            "One per variable, constant, application, connective, and quantifier; "
            "binder names free; negation expanded as implication to bottom; "
            "universal closure included. Common recursion equations counted once."
        ),
        "opaque_A_warning": (
            "A(n,c) is a formula metavariable application. Its template count "
            "does not add a predicate symbol and does not measure the complete "
            "axiomatization description."
        ),
        "main_new_result": {
            "presentation": "binary initialized recursion plus fused QFI with at most one frozen parameter",
            "fixed_template_parameter_budget": 1,
            "common_recursion_nodes": recursion_nodes,
            "fused_template_nodes_at_q_1": main_template["F_schema_nodes"],
            "combined_template_nodes_at_q_1": 42,
            "comparison": (
                "The prior F presentation allows arbitrary q. The new claim "
                "restricts q to 1 while preserving strength; it does not "
                "claim a smaller representative q=1 template."
            ),
        },
        "exact_template_formulas": {
            "R": "18",
            "F_schema": "19 + 5*q",
            "B_schema": "27 + 4*q",
            "R_plus_F": "37 + 5*q",
            "R_plus_B": "45 + 4*q",
            "boundary_strictly_smaller_for_opaque_A": "q >= 9",
        },
        "exact_full_instance_formulas": {
            "variables": "a=AST size of A; d=free n occurrences in A; q=universally closed frozen parameters",
            "R_plus_F_A": "4*a + d + q + 28",
            "R_plus_B_A": "3*a + q + 39",
            "boundary_saving": "a + d - 11",
            "hybrid": "F when a+d <= 11, otherwise B",
            "hybrid_mathematical_caveat": (
                "The unrestricted-parameter hybrid equivalence is proved in "
                "the report. This script checks only size and threshold identities. "
                "Forcing all its probes to one parameter additionally requires "
                "the separate parameter-packing theorem."
            ),
        },
        "template_matrix_q_0_through_12": template_matrix,
        "schematic_nary_atomic_equality_matrix": {
            "warning": (
                "s(n,c_1,...,c_q) and t(...) here are schematic abbreviations. "
                "For q>1 these displayed applications exceed binary arity and "
                "are not claimed to be literal terms of the restricted language. "
                "The actual binary-term matrix below respects the arity bound."
            ),
            "rows": nary_atom_matrix,
        },
        "actual_binary_formula_matrix": actual_formula_matrix,
        "hybrid_decidability_probe_checks": probe_checks,
        "recursion_update_audits": update_audits,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).with_name("metrics_results.json"),
        help="JSON results destination (default: beside this script)",
    )
    arguments = parser.parse_args()
    results = run_checks()
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print("All AST and side-condition assertions passed.")
    print("Common recursion template: 18 nodes.")
    print("Fixed q=1 fused template: 24 nodes; combined: 42 nodes.")
    print("Boundary saving for a full instance: a + d - 11 nodes.")
    print(f"Results: {arguments.output}")


if __name__ == "__main__":
    main()
