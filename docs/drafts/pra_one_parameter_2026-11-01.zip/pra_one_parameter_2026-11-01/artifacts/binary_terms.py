#!/usr/bin/env python3
"""Audit and execute the actual finite binary-recursion descriptions.

Run with Python 3.10 or later; no third-party packages are required::

    python3 artifacts/binary_terms.py

The only term constructors are variables, 0, S, and binary R_h applications.
The displayed arithmetic helpers are expanded into those constructors.
Finite syntax trees are stored as an interned DAG solely to avoid duplicate
storage. Description bodies refer only to earlier descriptions.

The evaluator implements R_h(0,a)=a and
R_h(Sn,a)=h(n,R_h(n,a)) literally, caching successive values for each seed.
It does not replace a description with a Python arithmetic implementation.
Python arithmetic is used separately for bounded diagnostic expectations.

The syntax audit verifies the eleven induction matrices displayed in the
report, their parameter counts, and their actual closed F1 axiom instances.
It also verifies all admitted update bodies and computation axiom instances.
Neither these syntax checks nor the numerical diagnostics are a proof of
the infinite schemas, of bi-interpretability, or of the universal theorems.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json
from math import isqrt
from pathlib import Path
import time


# ---------------------------------------------------------------------------
# Actual source-language terms and finite recursion descriptions.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Term:
    op: str
    children: tuple[int, ...] = ()
    name: str = ""
    reference: int = -1


TERMS: list[Term] = []
TERM_IDS: dict[Term, int] = {}


def intern(node: Term) -> int:
    existing = TERM_IDS.get(node)
    if existing is not None:
        return existing
    identifier = len(TERMS)
    if any(child >= identifier or child < 0 for child in node.children):
        raise ValueError("A term must refer only to existing child terms")
    TERMS.append(node)
    TERM_IDS[node] = identifier
    return identifier


def var(name: str) -> int:
    return intern(Term("var", name=name))


ZERO = intern(Term("zero"))


def succ(value: int) -> int:
    return intern(Term("succ", (value,)))


ONE = succ(ZERO)


def rec(reference: int, counter: int, seed: int) -> int:
    return intern(Term("rec", (counter, seed), reference=reference))


@lru_cache(maxsize=None)
def term_variables(identifier: int) -> frozenset[str]:
    node = TERMS[identifier]
    if node.op == "var":
        return frozenset((node.name,))
    result: set[str] = set()
    for child in node.children:
        result.update(term_variables(child))
    return frozenset(result)


@lru_cache(maxsize=None)
def term_references(identifier: int) -> frozenset[int]:
    node = TERMS[identifier]
    result = {node.reference} if node.op == "rec" else set()
    for child in node.children:
        result.update(term_references(child))
    return frozenset(result)


@lru_cache(maxsize=None)
def term_tree_nodes(identifier: int) -> int:
    return 1 + sum(term_tree_nodes(child) for child in TERMS[identifier].children)


@lru_cache(maxsize=None)
def pretty_term(identifier: int) -> str:
    node = TERMS[identifier]
    if node.op == "var":
        return node.name
    if node.op == "zero":
        return "0"
    if node.op == "succ":
        return f"S({pretty_term(node.children[0])})"
    if node.op == "rec":
        counter, seed = node.children
        return f"R{node.reference}({pretty_term(counter)},{pretty_term(seed)})"
    raise ValueError(f"Unknown term constructor: {node.op}")


def substitute_term(identifier: int, replacements: dict[str, int]) -> int:
    """Simultaneous variable substitution; function descriptions stay fixed."""
    memo: dict[int, int] = {}

    def visit(current: int) -> int:
        if current in memo:
            return memo[current]
        node = TERMS[current]
        if node.op == "var":
            result = replacements.get(node.name, current)
        elif node.op == "zero":
            result = current
        elif node.op == "succ":
            result = succ(visit(node.children[0]))
        elif node.op == "rec":
            result = rec(node.reference, *(visit(child) for child in node.children))
        else:
            raise ValueError(f"Unknown term constructor: {node.op}")
        memo[current] = result
        return result

    return visit(identifier)


@dataclass(frozen=True)
class Description:
    name: str
    body: int


DESCRIPTIONS: list[Description] = []


def admit(name: str, body: int) -> int:
    identifier = len(DESCRIPTIONS)
    if not term_variables(body) <= {"u", "v"}:
        raise ValueError(f"Illegal update variables in {name}")
    if any(reference >= identifier for reference in term_references(body)):
        raise ValueError(f"Non-earlier description in {name}")
    DESCRIPTIONS.append(Description(name, body))
    return identifier


U, W = var("u"), var("v")
PRED = admit("counter projection: h(u,v)=u", U)
RESET = admit("zero reset: h(u,v)=0", ZERO)
INCREMENT = admit("successor update: h(u,v)=S(v)", succ(W))


def p(x: int) -> int:
    return rec(PRED, x, ZERO)


def Z(n: int, a: int) -> int:
    return rec(RESET, n, a)


def add(x: int, y: int) -> int:
    return rec(INCREMENT, y, x)


DECREMENT = admit("predecessor update: h(u,v)=p(v)", p(W))


def d(x: int, y: int) -> int:
    return rec(DECREMENT, y, x)


def C(z: int, a: int, b: int) -> int:
    return add(Z(z, a), Z(Z(z, ONE), b))


def one_test(r: int) -> int:
    return C(r, ONE, C(p(r), ZERO, ONE))


def e(x: int, y: int) -> int:
    return one_test(d(succ(x), y))


TRIANGLE = admit("triangular update: h(u,v)=v+S(u)", add(W, succ(U)))


def T(n: int) -> int:
    return rec(TRIANGLE, n, ZERO)


INVERSE = admit(
    "endpoint-equality update: h(u,v)=C(e(T(S(v)),S(u)),S(v),v)",
    C(e(T(succ(W)), succ(U)), succ(W), W),
)


def V(n: int) -> int:
    return rec(INVERSE, n, ZERO)


def J(x: int, y: int) -> int:
    return add(T(add(x, y)), x)


def L(z: int) -> int:
    return d(z, T(V(z)))


def P(z: int) -> int:
    return d(V(z), L(z))


def tuple_code(entries: tuple[int, ...]) -> int:
    result = ZERO
    for entry in entries:
        result = J(result, entry)
    return result


def tuple_projection(code: int, arity: int, index: int) -> int:
    """The index is zero based; composition length is fixed externally."""
    if not 0 <= index < arity:
        raise ValueError("Invalid tuple projection")
    for _ in range(arity - index - 1):
        code = L(code)
    return P(code)


# ---------------------------------------------------------------------------
# Actual formulas, substitution, and the report's eleven induction matrices.
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Formula:
    op: str
    terms: tuple[int, ...] = ()
    children: tuple[Formula, ...] = ()
    variable: str = ""


def eq(left: int, right: int) -> Formula:
    return Formula("eq", terms=(left, right))


def connective(op: str, *children: Formula) -> Formula:
    return Formula(op, children=children)


def forall(variable: str, body: Formula) -> Formula:
    return Formula("forall", children=(body,), variable=variable)


def formula_variables(formula: Formula, include_bound: bool = False) -> set[str]:
    result: set[str] = set()
    for term in formula.terms:
        result.update(term_variables(term))
    for child in formula.children:
        result.update(formula_variables(child, include_bound))
    if formula.op == "forall":
        if include_bound:
            result.add(formula.variable)
        else:
            result.discard(formula.variable)
    return result


def formula_tree_nodes(formula: Formula) -> int:
    return (1 + sum(term_tree_nodes(term) for term in formula.terms)
            + sum(formula_tree_nodes(child) for child in formula.children))


def substitute_formula(formula: Formula, replacements: dict[str, int]) -> Formula:
    if formula.op == "forall":
        raise ValueError("Only quantifier-free matrices are substituted here")
    return Formula(
        formula.op,
        terms=tuple(substitute_term(term, replacements) for term in formula.terms),
        children=tuple(substitute_formula(child, replacements)
                       for child in formula.children),
    )


def fused_instance(matrix: Formula) -> Formula:
    """Build the actual F1 axiom for a matrix in the variables n,c."""
    if not formula_variables(matrix) <= {"n", "c"}:
        raise ValueError("F1 matrix has an extra free variable")
    base = substitute_formula(matrix, {"n": ZERO})
    successor = substitute_formula(matrix, {"n": succ(var("n"))})
    progress = forall("n", connective("imp", matrix, successor))
    premise = connective("and", connective("or", base, eq(ZERO, ONE)), progress)
    return forall("c", connective("imp", premise, forall("n", matrix)))


def induction_ledger() -> list[tuple[str, str, Formula]]:
    x, y, n, c, r, t = (var(name) for name in ("x", "y", "n", "c", "r", "t"))
    return [
        ("constructor coverage", "n", connective("or", eq(n, ZERO), eq(n, succ(p(n))))),
        ("left zero for addition", "y", eq(add(ZERO, y), y)),
        ("successor in the left summand", "y", eq(add(succ(x), y), succ(add(x, y)))),
        ("zero minus an argument", "y", eq(d(ZERO, y), ZERO)),
        ("joint successor cancellation", "y", eq(d(succ(x), succ(y)), d(x, y))),
        ("subtract the left summand", "x", eq(d(add(x, c), x), c)),
        ("subtract an extension", "y", eq(d(x, add(x, y)), ZERO)),
        ("predecessor commutes with subtraction", "y", eq(d(p(x), y), p(d(x, y)))),
        ("guarded residual identity", "n", eq(C(d(y, n), y, add(n, d(y, n))), y)),
        ("triangular segment", "r", connective(
            "imp", eq(V(T(t)), t),
            connective("imp", eq(d(r, t), ZERO), eq(V(add(T(t), r)), t)),
        )),
        ("triangular endpoints", "t", eq(V(T(t)), t)),
    ]


def syntax_audit() -> dict:
    ledger = []
    for name, induction_variable, matrix in induction_ledger():
        variables = formula_variables(matrix)
        parameters = sorted(variables - {induction_variable})
        if len(parameters) > 1:
            raise AssertionError(f"Too many frozen parameters: {name}")
        replacements = {induction_variable: var("n")}
        replacements.update({parameter: var("c") for parameter in parameters})
        normalized = substitute_formula(matrix, replacements)
        instance = fused_instance(normalized)
        if formula_variables(instance):
            raise AssertionError(f"Open F1 axiom: {name}")
        all_names = formula_variables(instance, include_bound=True)
        if not all_names <= {"n", "c"}:
            raise AssertionError(f"More than two axiom variable names: {name}")
        ledger.append({
            "name": name,
            "induction_variable": induction_variable,
            "matrix_free_variables": sorted(variables),
            "frozen_parameters": parameters,
            "expanded_matrix_tree_nodes": formula_tree_nodes(matrix),
            "expanded_F1_instance_tree_nodes": formula_tree_nodes(instance),
            "F1_instance_free_variables": [],
            "F1_instance_all_variable_names": sorted(all_names),
            "passes": True,
        })

    descriptions = []
    for reference, description in enumerate(DESCRIPTIONS):
        variables = term_variables(description.body)
        dependencies = term_references(description.body)
        if not variables <= {"u", "v"}:
            raise AssertionError("An update has an additional parameter")
        if not all(dependency < reference for dependency in dependencies):
            raise AssertionError("A description refers to itself or a later description")
        n, a = var("n"), var("a")
        base = forall("a", eq(rec(reference, ZERO, a), a))
        body = substitute_term(description.body, {"u": n, "v": rec(reference, n, a)})
        step = forall("n", forall("a", eq(rec(reference, succ(n), a), body)))
        for axiom in (base, step):
            if formula_variables(axiom):
                raise AssertionError("An actual computation axiom is open")
            if len(formula_variables(axiom, include_bound=True)) > 2:
                raise AssertionError("A computation axiom uses over two variable names")
        descriptions.append({
            "symbol": f"R{reference}",
            "name": description.name,
            "arity": 2,
            "body": pretty_term(description.body),
            "body_tree_nodes": term_tree_nodes(description.body),
            "body_free_variables": sorted(variables),
            "earlier_dependencies": [f"R{dependency}" for dependency in sorted(dependencies)],
            "base_axiom_variable_names": sorted(formula_variables(base, True)),
            "step_axiom_variable_names": sorted(formula_variables(step, True)),
            "passes": True,
        })

    x, y, z, a, b, n, r = (var(name) for name in ("x", "y", "z", "a", "b", "n", "r"))
    helpers = {
        "p(x)": p(x), "Z(n,a)": Z(n, a), "x+y": add(x, y),
        "d(x,y)": d(x, y), "C(z,a,b)": C(z, a, b),
        "u(r)": one_test(r), "e(x,y)": e(x, y), "T(n)": T(n),
        "V(n)": V(n), "J(x,y)": J(x, y), "L(z)": L(z), "P(z)": P(z),
    }
    helper_audit = [{
        "name": name,
        "expanded_binary_term": pretty_term(term),
        "free_variables": sorted(term_variables(term)),
        "tree_nodes": term_tree_nodes(term),
        "description_references": [f"R{reference}" for reference in sorted(term_references(term))],
    } for name, term in helpers.items()]

    # This verifies every interned term, including the expanded computation
    # axioms and induction instances created above, rather than only the helpers.
    allowed_arities = {"var": 0, "zero": 0, "succ": 1, "rec": 2}
    for identifier, node in enumerate(TERMS):
        if node.op not in allowed_arities or len(node.children) != allowed_arities[node.op]:
            raise AssertionError(f"Illegal source term at node {identifier}")
        if any(child >= identifier or child < 0 for child in node.children):
            raise AssertionError("The syntax DAG is not well founded")
        if node.op == "rec" and not 0 <= node.reference < len(DESCRIPTIONS):
            raise AssertionError("Unknown recursion description")

    return {
        "passes": True,
        "allowed_term_constructors": ["variable", "0", "S", "binary R_h"],
        "maximum_function_arity": 2,
        "descriptions": descriptions,
        "helpers": helper_audit,
        "induction_ledger": ledger,
        "ledger_rows": len(ledger),
        "maximum_frozen_parameters_in_ledger": max(len(row["frozen_parameters"]) for row in ledger),
        "maximum_individual_variable_names_per_checked_axiom": 2,
        "interned_term_nodes_checked": len(TERMS),
        "counting_note": (
            "Expanded tree counts here are actual finite instance sizes. They are not "
            "the report's 42-node schematic display metric. Helper abbreviations are "
            "expanded; each R_h symbol retains its separately audited finite body."
        ),
    }


# ---------------------------------------------------------------------------
# Literal evaluator: no arithmetic shortcuts for any R_h description.
# ---------------------------------------------------------------------------

class Evaluator:
    def __init__(self) -> None:
        self.prefixes: dict[tuple[int, int], list[int]] = {}
        self.updates: Counter[int] = Counter()

    def recurrence(self, reference: int, counter: int, seed: int) -> int:
        if counter < 0 or seed < 0:
            raise ValueError("The numerical diagnostic domain is the natural numbers")
        values = self.prefixes.setdefault((reference, seed), [seed])
        body = DESCRIPTIONS[reference].body
        while len(values) <= counter:
            index = len(values) - 1
            value = self.term(body, {"u": index, "v": values[-1]})
            values.append(value)
            self.updates[reference] += 1
        return values[counter]

    def term(self, identifier: int, environment: dict[str, int]) -> int:
        local_cache: dict[int, int] = {}

        def visit(current: int) -> int:
            if current in local_cache:
                return local_cache[current]
            node = TERMS[current]
            if node.op == "var":
                result = environment[node.name]
            elif node.op == "zero":
                result = 0
            elif node.op == "succ":
                result = visit(node.children[0]) + 1
            elif node.op == "rec":
                result = self.recurrence(node.reference, visit(node.children[0]), visit(node.children[1]))
            else:
                raise ValueError(f"Unknown term constructor: {node.op}")
            local_cache[current] = result
            return result

        return visit(identifier)

    def formula(self, formula: Formula, environment: dict[str, int]) -> bool:
        if formula.op == "eq":
            left, right = formula.terms
            return self.term(left, environment) == self.term(right, environment)
        if formula.op == "false":
            return False
        if formula.op == "and":
            return all(self.formula(child, environment) for child in formula.children)
        if formula.op == "or":
            return any(self.formula(child, environment) for child in formula.children)
        if formula.op == "imp":
            left, right = formula.children
            return not self.formula(left, environment) or self.formula(right, environment)
        raise ValueError("Only quantifier-free matrices are numerically evaluated")


def numerical_diagnostics() -> dict:
    evaluator = Evaluator()
    counts: Counter[str] = Counter()
    failures: list[dict] = []

    def check(name: str, term: int, environment: dict[str, int], expected: int) -> None:
        actual = evaluator.term(term, environment)
        counts[name] += 1
        if actual != expected:
            failures.append({"check": name, "inputs": environment, "actual": actual, "expected": expected})

    x, y, n, a, b, z, r = (var(name) for name in ("x", "y", "n", "a", "b", "z", "r"))
    for value in range(41):
        check("predecessor", p(x), {"x": value}, max(value - 1, 0))
        check("one tester", one_test(r), {"r": value}, 0 if value == 1 else 1)
    for counter, seed in product(range(9), repeat=2):
        check("zero reset", Z(n, a), {"n": counter, "a": seed}, seed if counter == 0 else 0)
    for left, right in product(range(17), repeat=2):
        environment = {"x": left, "y": right}
        check("addition", add(x, y), environment, left + right)
        check("truncated subtraction", d(x, y), environment, max(left - right, 0))
        check("native equality error bit", e(x, y), environment, int(left != right))
    for selector, left, right in product(range(9), range(5), range(5)):
        check("selector", C(z, a, b), {"z": selector, "a": left, "b": right},
              left if selector == 0 else right)
    for value in range(31):
        check("triangular numbers", T(n), {"n": value}, value * (value + 1) // 2)
    for value in range(321):
        check("triangular inverse", V(n), {"n": value}, (isqrt(8 * value + 1) - 1) // 2)
    for left, right in product(range(13), repeat=2):
        environment = {"x": left, "y": right}
        code = J(x, y)
        total = left + right
        check("pair code", code, environment, total * (total + 1) // 2 + left)
        check("left pair projection", L(code), environment, left)
        check("right pair projection", P(code), environment, right)

    tuple_cases = []
    for arity in range(5):
        inputs = tuple(var(f"b{index}") for index in range(arity))
        code = tuple_code(inputs)
        tested = 0
        for values in product(range(2), repeat=arity):
            environment = {f"b{index}": value for index, value in enumerate(values)}
            expected_code = 0
            for value in values:
                total = expected_code + value
                expected_code = total * (total + 1) // 2 + expected_code
            check("tuple code", code, environment, expected_code)
            for index, expected in enumerate(values):
                check("tuple projection", tuple_projection(code, arity, index), environment, expected)
            tested += 1
        tuple_cases.append({"arity": arity, "entry_values": [0, 1], "tuples_tested": tested})

    # These are bounded truth checks for the actual eleven matrices, not
    # bounded checks of the quantified induction axiom itself.
    matrix_checks = []
    for name, _, matrix in induction_ledger():
        variables = sorted(formula_variables(matrix))
        tested = 0
        for values in product(range(13), repeat=len(variables)):
            environment = dict(zip(variables, values))
            actual = evaluator.formula(matrix, environment)
            counts["induction ledger matrix values"] += 1
            if not actual:
                failures.append({"check": name, "inputs": environment, "actual": False, "expected": True})
            tested += 1
        matrix_checks.append({"name": name, "variables": variables, "range_inclusive": [0, 12],
                              "assignments_tested": tested})

    return {
        "passes": not failures,
        "total_checks": sum(counts.values()),
        "checks_by_category": dict(sorted(counts.items())),
        "pair_grid_inclusive": {"x": [0, 12], "y": [0, 12]},
        "tuple_tests": tuple_cases,
        "actual_matrix_checks": matrix_checks,
        "failures": failures,
        "literal_recursion_statistics": {
            "cached_seed_tables": len(evaluator.prefixes),
            "cached_values": sum(len(values) for values in evaluator.prefixes.values()),
            "updates_by_description": {f"R{reference}": evaluator.updates[reference]
                                       for reference in range(len(DESCRIPTIONS))},
            "largest_cached_counter": max(len(values) - 1 for values in evaluator.prefixes.values()),
        },
        "scope": (
            "Finite standard-natural-number diagnostics only. The evaluator runs the "
            "literal recurrences; Python arithmetic supplies expected results separately. "
            "These checks do not prove statements in arbitrary or nonstandard models."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().with_name("binary_results.json"))
    arguments = parser.parse_args()
    started = time.perf_counter()
    syntax = syntax_audit()
    diagnostics = numerical_diagnostics()
    # Numerical tests create further expanded tuple terms. Audit those too.
    final_syntax = syntax_audit()
    result = {
        "artifact": "binary_terms.py",
        "schema_version": 1,
        "passes": final_syntax["passes"] and diagnostics["passes"],
        "syntax_audit": final_syntax,
        "numerical_diagnostics": diagnostics,
        "runtime_seconds": round(time.perf_counter() - started, 6),
        "provenance": "New independent standard-library implementation; no inherited archive code executed.",
        "verification_scope": (
            "This artifact checks finite source syntax, the exact eleven displayed "
            "induction matrices, their closed F1 instances, and bounded numerical examples. "
            "The mathematical proofs and their stated formalization scope are in the report."
        ),
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "passes": result["passes"],
        "descriptions": len(DESCRIPTIONS),
        "actual_induction_ledger_rows": final_syntax["ledger_rows"],
        "maximum_frozen_parameters": final_syntax["maximum_frozen_parameters_in_ledger"],
        "numerical_checks": diagnostics["total_checks"],
        "runtime_seconds": result["runtime_seconds"],
        "output": str(arguments.output.resolve()),
    }))
    return 0 if result["passes"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
