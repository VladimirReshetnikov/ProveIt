/-
  One-parameter induction suffices to construct a primitive-recursive
  pairing with term-definable left inverses.

  This is an arbitrary-carrier constructive kernel.  All numerical
  inductions below are explicit instances of a quantifier-free syntax
  with just the running variable and ONE fixed parameter.  There is no
  induction assumption for arbitrary carrier predicates.

  The elementary arithmetic identities in Basis are explicit hypotheses.
  The accompanying manuscript proves them from the binary recursor
  equations and one-parameter quantifier-free induction.  This file
  checks the new triangular-interval argument, endpoint induction,
  pairing inverses, and finite parameter packing.  It does not encode
  the complete recursor-description grammar or the PRA translations.

  Lean 4.19.0; no Mathlib; no Classical; no sorry.
-/

namespace OneParameter

universe u

structure Operations (D : Type u) where
  zero : D
  succ : D → D
  pred : D → D
  add : D → D → D
  sub : D → D → D
  choose : D → D → D → D
  eqBit : D → D → D
  tri : D → D
  inv : D → D

/- A small concrete fragment of quantifier-free term/formula syntax.
   .run and .parameter are its ONLY free-variable constructors. -/
inductive Term where
  | zero
  | run
  | parameter
  | succ (a : Term)
  | pred (a : Term)
  | add (a b : Term)
  | sub (a b : Term)
  | tri (a : Term)
  | inv (a : Term)

inductive Formula where
  | falsity
  | equal (a b : Term)
  | conj (a b : Formula)
  | disj (a b : Formula)
  | impl (a b : Formula)

def Term.eval {D : Type u} (o : Operations D) : Term → D → D → D
  | .zero, _, _ => o.zero
  | .run, n, _ => n
  | .parameter, _, c => c
  | .succ a, n, c => o.succ (a.eval o n c)
  | .pred a, n, c => o.pred (a.eval o n c)
  | .add a b, n, c => o.add (a.eval o n c) (b.eval o n c)
  | .sub a b, n, c => o.sub (a.eval o n c) (b.eval o n c)
  | .tri a, n, c => o.tri (a.eval o n c)
  | .inv a, n, c => o.inv (a.eval o n c)

def Formula.eval {D : Type u} (o : Operations D) : Formula → D → D → Prop
  | .falsity, _, _ => False
  | .equal a b, n, c => a.eval o n c = b.eval o n c
  | .conj a b, n, c => a.eval o n c ∧ b.eval o n c
  | .disj a b, n, c => a.eval o n c ∨ b.eval o n c
  | .impl a b, n, c => a.eval o n c → b.eval o n c

structure Basis (D : Type u) where
  o : Operations D
  sep : o.zero ≠ o.succ o.zero
  succ_injective : ∀ x y, o.succ x = o.succ y → x = y
  pred_zero : o.pred o.zero = o.zero
  pred_succ : ∀ x, o.pred (o.succ x) = x
  add_zero : ∀ x, o.add x o.zero = x
  add_succ : ∀ x y, o.add x (o.succ y) = o.succ (o.add x y)
  sub_succ : ∀ x y, o.sub x (o.succ y) = o.pred (o.sub x y)
  sub_diagonal : ∀ x, o.sub x x = o.zero
  sub_succ_diagonal : ∀ x, o.sub (o.succ x) x = o.succ o.zero
  sub_pred : ∀ x y, o.sub (o.pred x) y = o.pred (o.sub x y)
  sub_add_cancel : ∀ x y, o.sub (o.add x y) x = y
  choose_zero : ∀ x y, o.choose o.zero x y = x
  choose_one : ∀ x y, o.choose (o.succ o.zero) x y = y
  eqBit_equal : ∀ x y, x = y → o.eqBit x y = o.zero
  eqBit_unequal : ∀ x y, x ≠ y → o.eqBit x y = o.succ o.zero
  tri_zero : o.tri o.zero = o.zero
  tri_succ : ∀ n, o.tri (o.succ n) = o.add (o.tri n) (o.succ n)
  inv_zero : o.inv o.zero = o.zero
  inv_succ : ∀ n,
    o.inv (o.succ n) =
      o.choose (o.eqBit (o.tri (o.succ (o.inv n))) (o.succ n))
        (o.succ (o.inv n)) (o.inv n)
  induction_one_parameter : ∀ (a : Formula) (c : D),
    a.eval o o.zero c →
    (∀ n, a.eval o n c → a.eval o (o.succ n) c) →
    ∀ n, a.eval o n c

variable {D : Type u} (b : Basis D)

theorem add_left_cancel (a x y : D)
    (h : b.o.add a x = b.o.add a y) : x = y := by
  have hs := congrArg (fun z => b.o.sub z a) h
  change b.o.sub (b.o.add a x) a = b.o.sub (b.o.add a y) a at hs
  rw [b.sub_add_cancel, b.sub_add_cancel] at hs
  exact hs

theorem triangular_step (t : D) :
    b.o.tri (b.o.succ t) = b.o.succ (b.o.add (b.o.tri t) t) := by
  rw [b.tri_succ, b.add_succ]

/- In this formula, run = r and parameter = t.
   All hypotheses are inside the quantifier-free induction matrix. -/
def segmentFormula : Formula :=
  .impl (.equal (.inv (.tri .parameter)) .parameter)
    (.impl (.equal (.sub .run .parameter) .zero)
      (.equal (.inv (.add (.tri .parameter) .run)) .parameter))

theorem segment (t r : D) :
    b.o.inv (b.o.tri t) = t →
    b.o.sub r t = b.o.zero →
    b.o.inv (b.o.add (b.o.tri t) r) = t := by
  apply b.induction_one_parameter segmentFormula t
  · change (b.o.inv (b.o.tri t) = t) →
      (b.o.sub b.o.zero t = b.o.zero) →
      b.o.inv (b.o.add (b.o.tri t) b.o.zero) = t
    intro ht _
    rw [b.add_zero]
    exact ht
  · intro n ih
    change (b.o.inv (b.o.tri t) = t) →
      (b.o.sub (b.o.succ n) t = b.o.zero) →
      b.o.inv (b.o.add (b.o.tri t) (b.o.succ n)) = t
    change (b.o.inv (b.o.tri t) = t) →
      (b.o.sub n t = b.o.zero) →
      b.o.inv (b.o.add (b.o.tri t) n) = t at ih
    intro ht hle
    have hle' : b.o.sub n t = b.o.zero := by
      calc
        b.o.sub n t = b.o.sub (b.o.pred (b.o.succ n)) t := by
          rw [b.pred_succ]
        _ = b.o.pred (b.o.sub (b.o.succ n) t) := b.sub_pred _ _
        _ = b.o.zero := by rw [hle, b.pred_zero]
    have hnt : n ≠ t := by
      intro h
      rw [h, b.sub_succ_diagonal] at hle
      exact b.sep hle.symm
    have hv : b.o.inv (b.o.add (b.o.tri t) n) = t := ih ht hle'
    have hthreshold :
        b.o.tri (b.o.succ t) ≠ b.o.succ (b.o.add (b.o.tri t) n) := by
      intro h
      have hsum : b.o.add (b.o.tri t) t = b.o.add (b.o.tri t) n := by
        apply b.succ_injective
        exact (triangular_step b t).symm.trans h
      have htn : t = n := add_left_cancel b (b.o.tri t) t n hsum
      exact hnt htn.symm
    rw [b.add_succ, b.inv_succ, hv,
      b.eqBit_unequal _ _ hthreshold, b.choose_one]

/- This matrix uses no parameter.  The permitted extra parameter is
   simply assigned zero and ignored. -/
def endpointFormula : Formula :=
  .equal (.inv (.tri .run)) .run

theorem inverse_triangular (t : D) : b.o.inv (b.o.tri t) = t := by
  apply b.induction_one_parameter endpointFormula b.o.zero
  · change b.o.inv (b.o.tri b.o.zero) = b.o.zero
    rw [b.tri_zero, b.inv_zero]
  · intro n ih
    change b.o.inv (b.o.tri n) = n at ih
    change b.o.inv (b.o.tri (b.o.succ n)) = b.o.succ n
    have hv : b.o.inv (b.o.add (b.o.tri n) n) = n :=
      segment b n n ih (b.sub_diagonal n)
    rw [triangular_step b n, b.inv_succ, hv,
      b.eqBit_equal _ _ (triangular_step b n), b.choose_zero]

/- Here run = y and parameter = x. -/
def belowSumFormula : Formula :=
  .equal (.sub .parameter (.add .parameter .run)) .zero

theorem sub_below_sum (x y : D) :
    b.o.sub x (b.o.add x y) = b.o.zero := by
  apply b.induction_one_parameter belowSumFormula x
  · change b.o.sub x (b.o.add x b.o.zero) = b.o.zero
    rw [b.add_zero, b.sub_diagonal]
  · intro n ih
    change b.o.sub x (b.o.add x n) = b.o.zero at ih
    change b.o.sub x (b.o.add x (b.o.succ n)) = b.o.zero
    rw [b.add_succ, b.sub_succ, ih, b.pred_zero]

def pair (x y : D) : D := b.o.add (b.o.tri (b.o.add x y)) x
def first (z : D) : D := b.o.sub z (b.o.tri (b.o.inv z))
def second (z : D) : D := b.o.sub (b.o.inv z) (first b z)

theorem inverse_pair (x y : D) : b.o.inv (pair b x y) = b.o.add x y := by
  exact segment b (b.o.add x y) x
    (inverse_triangular b (b.o.add x y)) (sub_below_sum b x y)

theorem first_pair (x y : D) : first b (pair b x y) = x := by
  unfold first
  rw [inverse_pair]
  exact b.sub_add_cancel (b.o.tri (b.o.add x y)) x

theorem second_pair (x y : D) : second b (pair b x y) = y := by
  unfold second
  rw [inverse_pair, first_pair]
  exact b.sub_add_cancel x y

theorem pair_injective (x y x' y' : D)
    (h : pair b x y = pair b x' y') : x = x' ∧ y = y' := by
  constructor
  · have h' := congrArg (first b) h
    rw [first_pair, first_pair] at h'
    exact h'
  · have h' := congrArg (second b) h
    rw [second_pair, second_pair] at h'
    exact h'

/- The following recursion is on a finite METATHEORETIC list, not on
   elements of D.  For each fixed list length it expands to a term. -/
def pack : List D → D
  | [] => b.o.zero
  | x :: xs => pair b x (pack xs)

def unpack : Nat → D → List D
  | 0, _ => []
  | k + 1, z => first b z :: unpack k (second b z)

theorem unpack_pack (xs : List D) : unpack b xs.length (pack b xs) = xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
    change first b (pair b x (pack b xs)) ::
      unpack b xs.length (second b (pair b x (pack b xs))) = x :: xs
    rw [first_pair, second_pair, ih]

#print axioms add_left_cancel
#print axioms segment
#print axioms inverse_triangular
#print axioms sub_below_sum
#print axioms first_pair
#print axioms second_pair
#print axioms pair_injective
#print axioms unpack_pack

end OneParameter
