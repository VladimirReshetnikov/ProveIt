TWO-VARIABLE AXIOMS FOR PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 1 November 2026

START HERE

  report.pdf       Complete mathematical paper.
  report.tex       Complete editable LaTeX source.
  AXIOMS.txt       Standalone effective specification.

MAIN RESULT

Use 0,S and only binary initialized recursors:

  R_h(0,a)=a;  R_h(Sn,a)=h(n,R_h(n,a)),

where each earlier update h has only its two displayed variables. Add the
fused induction schema

  forall c (
    [(A(0,c) OR 0=S0) AND forall n(A(n,c)->A(Sn,c))]
      -> forall n A(n,c)
  )

for every quantifier-free A with free variables contained in {n,c}.
There is exactly one optional frozen parameter, no arbitrary tuple.

The same specification is definitionally equivalent to the matching
classical or intuitionistic first-order PRA. Both interpretations retain
the entire carrier and native equality; both round trips are identities.
All function symbols are at most binary, and every nonlogical axiom needs
at most two variable names. The ambient logic remains full first-order
logic and the effective signature remains infinite.

THE IMPROVEMENT

The reviewed drafts already contain the binary recursor grammar and a
42-node representative fused-QFI display. This report eliminates the
unbounded tuple of frozen induction parameters. The new internal pairing
proof uses only one-parameter induction, avoiding circular appeals to
unrestricted induction or an existing general pairing theorem.
The display count stays 42; no global minimum is claimed.

SECONDARY RESULT

A three-occurrence boundary scheme is equivalent to PRA in both logics.
For a concrete matrix of AST size a with d occurrences of the induction
variable, it saves a+d-11 nodes over fused induction when that number is
positive. It is larger as a one-parameter opaque display (49 versus 42).
An optional adaptive scheme chooses the shorter instance, with an explicit
extra size-based admission test. The main recommendation remains F1.

VERIFICATION

  artifacts/metrics.py
      Independent AST counts, expanded-instance metrics, and syntax checks.
  artifacts/binary_terms.py
      Actual finite binary-recursion descriptions, dependency/free-variable
      audit, and bounded numerical/tuple diagnostics.
  artifacts/*_results.json
      Reproducible check results.
  formal/OneParameter.lean
      Constructive Lean 4.19 certificate for the new pairing kernel and
      finite parameter packing, over an arbitrary carrier. Numerical
      induction ranges over concrete two-variable QF syntax.
  formal/SCOPE.txt
      Exact explicit assumptions and limits of the Lean certificate.
  formal/OneParameter.log, formal/verification.json
      Successful compiler output and eight global-axiom dependency audits.
  audit/
      Pinned input provenance, mathematical reviews, build and PDF QA.
  SHA256SUMS.txt
      Hashes of all release files except this manifest itself.

The full arithmetic bootstrap, concrete descriptor compilers, first-order
proof transport, and interpretation round trips are written proofs in the
paper. They are not claimed as one end-to-end Lean theorem. Numerical
diagnostics are not proofs about nonstandard models.

REBUILD

Python 3.10 or later and a standard TeX Live installation are sufficient for:

  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only

To replay the optional Lean certificate, use Lean 4.19.0:

  lean formal/OneParameter.lean

No Mathlib is required. Generated PDF metadata, logs, and result timestamps
may differ on rebuild; byte-for-byte reproducibility is not asserted.
Check the supplied SHA256SUMS.txt before rebuilding to audit the release.

SOURCE SCOPE

All eight archives in ProveIt/docs/drafts were inspected at commit:
  117c275bb0a4486d75e51a707b1187d177dcee07

Downloaded bytes were verified against their Git blob identities. The
source manifest records immutable URLs and hashes. Original source ZIPs
are not duplicated in this delivery, and no repository files were changed.
