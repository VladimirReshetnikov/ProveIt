#!/usr/bin/env python3
"""Build report.pdf with a standard pdfLaTeX installation."""
import json
from pathlib import Path
import shutil
import subprocess


def main():
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    engine = shutil.which("pdflatex")
    if not engine:
        raise SystemExit("pdflatex is required; install a TeX distribution with the report's listed packages.")
    results = []
    for i in range(1, 4):
        proc = subprocess.run([engine, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                              cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (audit / f"latex_pass_{i}.log").write_text(proc.stdout)
        results.append({"pass": i, "exit_code": proc.returncode})
        if proc.returncode:
            (audit / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")
            print(proc.stdout[-6000:])
            raise SystemExit(proc.returncode)
    pdf = root / "report.pdf"
    data = pdf.read_bytes()
    if not data.startswith(b"%PDF-") or b"%%EOF" not in data[-100:]:
        raise SystemExit("LaTeX returned without a complete PDF; inspect build logs.")
    (audit / "build_results.json").write_text(json.dumps({"passes": results, "pdf_bytes": len(data), "pdf_header_and_eof_valid": True}, indent=2) + "\n")
    print(json.dumps({"status": "passed", "pdf": str(root / "report.pdf"), "passes": results}, indent=2))


if __name__ == "__main__":
    main()
