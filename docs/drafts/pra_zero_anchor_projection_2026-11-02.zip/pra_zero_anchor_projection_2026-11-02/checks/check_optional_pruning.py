#!/usr/bin/env python3
"""Tree audit of the optional three-branch HP3 emitter.

Place this script beside check_schema.py.  It imports that
script's term and formula constructors, but builds the optional formula
trees here and counts the trees independently of the announced ledger.
This is a syntax/size audit, not a mechanized arithmetic proof.
"""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path

import check_schema as k


def optional_schema(raw: k.Term) -> k.Formula:
    i, j = k.occurrences(raw, "n"), k.occurrences(raw, "a")
    if i == 0:
        body = k.computation(raw, normalize=True, right=False)
    elif j == 0:
        body = k.computation(raw, normalize=True, right=True)
    else:
        body = k.conjunction(
            k.computation(raw, normalize=True, right=False),
            k.implication(k.progress(raw, True), k.rooted(raw, True)),
        )
    return k.All("a", k.All("n", body))


def run(count: int, output_dir: Path) -> dict:
    rows = []
    branches = Counter()
    total_active_saved = 0
    total_stored_saved = 0
    for raw in k.make_terms(count):
        i, j = k.occurrences(raw, "n"), k.occurrences(raw, "a")
        m, big_u = k.active_size(raw), k.stored_size(raw)
        body = k.descriptor(raw, normalize=True)
        body_u = k.stored_size(body)
        old, main, optional = k.old_schema(raw), k.new_schema(raw), optional_schema(raw)
        active = k.formula_size(optional)
        stored = k.formula_size(optional, include_stored=True)
        assert not k.formula_vars(optional)
        if i == 0:
            branch = "counter_independent_left"
            assert active == 20 + m
            assert stored == 20 + big_u + 2 * body_u
            assert k.quantifiers(optional) == (2, 2)
            # The endpoint equation is literally independent of the counter.
            assert k.endpoint(raw, k.N, True) == k.endpoint(raw, k.Succ(k.N), True)
        elif j == 0:
            branch = "autonomous_right"
            assert active == 22 + m
            assert stored == 22 + big_u + 3 * body_u
            assert k.quantifiers(optional) == (2, 2)
        else:
            branch = "left_with_zero_anchor"
            assert active == 35 + 7 * m + 4 * i
            assert stored == 35 + 7 * big_u + 4 * i + (i + 2) * body_u
            assert k.quantifiers(optional) == (3, 3)
        main_active = k.formula_size(main)
        main_stored = k.formula_size(main, include_stored=True)
        old_active = k.formula_size(old)
        old_stored = k.formula_size(old, include_stored=True)
        assert active <= main_active < old_active
        assert stored <= main_stored < old_stored
        if i == 0 and j == 0:
            assert main_active - active == 2
        elif i == 0:
            assert main_active - active == 15 + 6 * m
        else:
            assert main_active == active
        branches[branch] += 1
        total_active_saved += main_active - active
        total_stored_saved += main_stored - stored
        rows.append({
            "input": k.pretty(raw), "m": m, "i": i, "j": j,
            "branch": branch,
            "optional_active": active, "main_active": main_active,
            "draft_active": old_active,
            "optional_with_descriptors": stored,
            "main_with_descriptors": main_stored,
            "draft_with_descriptors": old_stored,
        })
    summary = {
        "status": "passed",
        "inputs_checked": len(rows),
        "branch_counts": dict(branches),
        "closed_sentences": True,
        "exact_active_formulas_verified": True,
        "exact_descriptor_formulas_verified": True,
        "quantifier_profiles_verified": True,
        "never_larger_than_main": True,
        "strictly_smaller_than_counter_recursion_draft": True,
        "additional_active_nodes_saved_over_main": total_active_saved,
        "additional_descriptor_inclusive_nodes_saved_over_main": total_stored_saved,
        "scope": "Finite formula-tree syntax and size audit; no model-theoretic or arithmetic theorem is mechanically certified.",
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "optional_pruning_cases.json").write_text(json.dumps(rows, indent=2) + "\n")
    (output_dir / "optional_pruning_checks.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=600)
    parser.add_argument("--output-dir", type=Path, default=Path("optional_pruning_checks"))
    args = parser.parse_args()
    print(json.dumps(run(args.count, args.output_dir), indent=2))
