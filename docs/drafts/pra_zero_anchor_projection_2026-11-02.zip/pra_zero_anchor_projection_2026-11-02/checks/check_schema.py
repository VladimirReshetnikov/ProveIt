#!/usr/bin/env python3
"""Independent syntax audit for the projection-pruned PRA schema.

This program builds formula trees, then counts those trees.  It does not
use the announced cost formulas when constructing the formulas.  Its
finite numerical checks are diagnostics, not a mechanized proof of the
bi-interpretation or of induction on arbitrary models.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
import random
from typing import Union


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    term: "Term"


@dataclass(frozen=True)
class Rec:
    # body is a frozen descriptor with local slots v,w, not an active child.
    body: "Term"
    counter: "Term"
    state: "Term"


Term = Union[Var, Zero, Succ, Rec]
ZERO = Zero()
N, A, V, W = (Var(x) for x in ("n", "a", "v", "w"))
ONE = Succ(ZERO)


def q(counter: Term, state: Term) -> Term:
    return Rec(W, counter, state)


def z(counter: Term, state: Term) -> Term:
    return Rec(ZERO, counter, state)


def subst(term: Term, mapping: dict[str, Term]) -> Term:
    """Simultaneous active substitution.  Stored descriptors stay frozen."""
    if isinstance(term, Var):
        return mapping.get(term.name, term)
    if isinstance(term, Zero):
        return term
    if isinstance(term, Succ):
        return Succ(subst(term.term, mapping))
    return Rec(term.body, subst(term.counter, mapping), subst(term.state, mapping))


def prune(term: Term) -> Term:
    """Root-only Q(S t,s) -> t pruning; do not descend into other nodes."""
    while isinstance(term, Rec) and term.body == W and isinstance(term.counter, Succ):
        term = term.counter.term
    return term


@lru_cache(maxsize=None)
def active_size(term: Term) -> int:
    if isinstance(term, (Var, Zero)):
        return 1
    if isinstance(term, Succ):
        return 1 + active_size(term.term)
    return 1 + active_size(term.counter) + active_size(term.state)


@lru_cache(maxsize=None)
def stored_size(term: Term) -> int:
    if isinstance(term, (Var, Zero)):
        return 1
    if isinstance(term, Succ):
        return 1 + stored_size(term.term)
    return 1 + stored_size(term.body) + stored_size(term.counter) + stored_size(term.state)


@lru_cache(maxsize=None)
def active_vars(term: Term) -> frozenset[str]:
    if isinstance(term, Var):
        return frozenset((term.name,))
    if isinstance(term, Zero):
        return frozenset()
    if isinstance(term, Succ):
        return active_vars(term.term)
    return active_vars(term.counter) | active_vars(term.state)


def occurrences(term: Term, variable: str) -> int:
    if isinstance(term, Var):
        return int(term.name == variable)
    if isinstance(term, Zero):
        return 0
    if isinstance(term, Succ):
        return occurrences(term.term, variable)
    return occurrences(term.counter, variable) + occurrences(term.state, variable)


@lru_cache(maxsize=None)
def term_rank(term: Term) -> int:
    if isinstance(term, (Var, Zero)):
        return 0
    if isinstance(term, Succ):
        return term_rank(term.term)
    return max(1 + term_rank(term.body), term_rank(term.counter), term_rank(term.state))


def audit_term(term: Term, allowed: frozenset[str]) -> None:
    assert active_vars(term) <= allowed
    if isinstance(term, Succ):
        audit_term(term.term, allowed)
    elif isinstance(term, Rec):
        assert prune(term.body) == term.body, "noncanonical stored descriptor"
        audit_term(term.body, frozenset(("v", "w")))
        audit_term(term.counter, allowed)
        audit_term(term.state, allowed)


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bottom:
    pass


@dataclass(frozen=True)
class Binary:
    operation: str
    left: "Formula"
    right: "Formula"


@dataclass(frozen=True)
class All:
    variable: str
    body: "Formula"


Formula = Union[Eq, Bottom, Binary, All]


def conjunction(left: Formula, right: Formula) -> Formula:
    return Binary("and", left, right)


def disjunction(left: Formula, right: Formula) -> Formula:
    return Binary("or", left, right)


def implication(left: Formula, right: Formula) -> Formula:
    return Binary("implies", left, right)


SEPARATION = implication(Eq(ZERO, ONE), Bottom())


def quantifiers(formula: Formula) -> tuple[int, int]:
    if isinstance(formula, (Eq, Bottom)):
        return 0, 0
    if isinstance(formula, All):
        count, depth = quantifiers(formula.body)
        return count + 1, depth + 1
    lc, ld = quantifiers(formula.left)
    rc, rd = quantifiers(formula.right)
    return lc + rc, max(ld, rd)


def formula_size(formula: Formula, include_stored: bool = False) -> int:
    size = stored_size if include_stored else active_size
    if isinstance(formula, Eq):
        return 1 + size(formula.left) + size(formula.right)
    if isinstance(formula, Bottom):
        return 1
    if isinstance(formula, All):
        return 1 + formula_size(formula.body, include_stored)
    return 1 + formula_size(formula.left, include_stored) + formula_size(formula.right, include_stored)


def formula_vars(formula: Formula) -> frozenset[str]:
    if isinstance(formula, Eq):
        return active_vars(formula.left) | active_vars(formula.right)
    if isinstance(formula, Bottom):
        return frozenset()
    if isinstance(formula, All):
        return formula_vars(formula.body) - frozenset((formula.variable,))
    return formula_vars(formula.left) | formula_vars(formula.right)


def endpoint(raw: Term, counter: Term, anchor: bool) -> Formula:
    first = subst(raw, {"n": counter, "a": A})
    second = subst(raw, {"n": counter, "a": ZERO if anchor else Succ(A)})
    return Eq(first, second)


def rooted(raw: Term, anchor: bool) -> Formula:
    return disjunction(Eq(N, ZERO), endpoint(raw, N, anchor))


def progress(raw: Term, anchor: bool) -> Formula:
    return All("n", implication(rooted(raw, anchor), endpoint(raw, Succ(N), anchor)))


def descriptor(raw: Term, normalize: bool) -> Term:
    raw_body = subst(raw, {"n": V, "a": W})
    return prune(raw_body) if normalize else raw_body


def computation(raw: Term, normalize: bool, right: bool) -> Formula:
    body = descriptor(raw, normalize)
    base = Eq(Rec(body, ZERO, A), A)
    if right:
        exposed_raw = subst(raw, {"n": A, "a": ZERO})
        update = Eq(Rec(body, Succ(N), A), Rec(body, N, exposed_raw))
    else:
        exposed_raw = subst(raw, {"n": Rec(body, N, A), "a": N})
        update = Eq(Rec(body, Succ(N), A), exposed_raw)
    return conjunction(SEPARATION, conjunction(base, update))


def old_schema(raw: Term) -> Formula:
    body = conjunction(computation(raw, False, False), implication(progress(raw, False), rooted(raw, False)))
    return All("a", All("n", body))


def new_schema(raw: Term) -> Formula:
    if occurrences(raw, "a") == 0:
        body = computation(raw, True, True)
    else:
        body = conjunction(computation(raw, True, False), implication(progress(raw, True), rooted(raw, True)))
    return All("a", All("n", body))


def pretty(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return "S(" + pretty(term.term) + ")"
    if term.body == W:
        name = "Q"
    elif term.body == ZERO:
        name = "Z"
    else:
        name = "R[" + pretty(term.body) + "]"
    return name + "(" + pretty(term.counter) + "," + pretty(term.state) + ")"


def make_terms(count: int = 600) -> list[Term]:
    rng = random.Random(20261102)
    p_body = q(V, ZERO)
    nested_body = Rec(p_body, V, ZERO)
    deeper_body = Rec(nested_body, V, W)
    bodies = [ZERO, V, W, Succ(V), Succ(W), p_body,
              Rec(Succ(V), V, W), Succ(q(Succ(V), W)),
              nested_body, deeper_body]
    result: list[Term] = []
    seen: set[Term] = set()

    def add(term: Term) -> None:
        if term not in seen and active_size(term) <= 20 and stored_size(term) <= 600:
            audit_term(term, frozenset(("n", "a")))
            seen.add(term)
            result.append(term)

    for term in [N, A, ZERO, ONE, Succ(N), Succ(A), q(N, A), z(N, A),
                 q(Succ(N), A), q(Succ(q(Succ(N), ZERO)), A),
                 Succ(q(Succ(N), A)), Rec(p_body, N, A),
                 q(Succ(Rec(p_body, N, ZERO)), A),
                 q(Succ(q(Succ(A), N)), ZERO)]:
        add(term)
    while len(result) < count:
        # A mix of autonomous, parameter-bearing, root-pruned, and nested terms.
        left = rng.choice(result)
        right = rng.choice(result)
        op = rng.randrange(7)
        if op == 0:
            term = Succ(left)
        elif op == 1:
            term = q(Succ(left), right)
        elif op == 2:
            term = q(Succ(q(Succ(left), ZERO)), A)
        elif op == 3:
            term = Rec(rng.choice(bodies), left, right)
        elif op == 4:
            term = subst(left, {"a": ZERO})
        elif op == 5:
            term = q(left, right)
        else:
            term = z(left, right)
        add(term)
    return result[:count]


class EvaluationLimit(Exception):
    pass


class Evaluator:
    """Ordinary standard-N primitive recursion, with a diagnostic fuel limit."""
    def __init__(self, fuel: int = 30000):
        self.fuel = fuel

    def tick(self) -> None:
        self.fuel -= 1
        if self.fuel < 0:
            raise EvaluationLimit

    def term(self, term: Term, values: dict[str, int]) -> int:
        self.tick()
        if isinstance(term, Var):
            return values[term.name]
        if isinstance(term, Zero):
            return 0
        if isinstance(term, Succ):
            result = 1 + self.term(term.term, values)
        else:
            counter = self.term(term.counter, values)
            result = self.term(term.state, values)
            if counter > 256:
                raise EvaluationLimit
            for k in range(counter):
                result = self.term(term.body, {"v": result, "w": k})
        if result > 4096:
            raise EvaluationLimit
        return result

    def formula(self, formula: Formula, values: dict[str, int], bound: int) -> bool:
        self.tick()
        if isinstance(formula, Eq):
            return self.term(formula.left, values) == self.term(formula.right, values)
        if isinstance(formula, Bottom):
            return False
        if isinstance(formula, All):
            return all(self.formula(formula.body, dict(values, **{formula.variable: k}), bound)
                       for k in range(bound + 1))
        left = self.formula(formula.left, values, bound)
        if formula.operation == "and":
            return left and self.formula(formula.right, values, bound)
        if formula.operation == "or":
            return left or self.formula(formula.right, values, bound)
        assert formula.operation == "implies"
        return (not left) or self.formula(formula.right, values, bound)


def frozen_and_pruning_audit() -> dict:
    nested_descriptor = Rec(W, V, W)
    term = Rec(nested_descriptor, V, W)
    changed = subst(term, {"v": Succ(A), "w": ZERO})
    assert isinstance(changed, Rec)
    assert changed.body is nested_descriptor
    assert changed.counter == Succ(A) and changed.state == ZERO
    assert active_vars(changed) == frozenset(("a",))
    assert prune(q(Succ(q(Succ(N), A)), ZERO)) == N
    untouched = Succ(q(Succ(N), A))
    assert prune(untouched) == untouched
    nonmatching = q(N, A)
    assert prune(nonmatching) == nonmatching
    # Raw counter activity can disappear under root pruning: this is deliberate.
    padded = q(Succ(q(N, ZERO)), A)
    assert occurrences(padded, "a") == 1
    assert occurrences(prune(padded), "a") == 0
    return {"active_substitution_preserves_descriptor_identity": True,
            "root_pruning_repeats_at_new_root": True,
            "root_pruning_does_not_descend": True,
            "raw_activity_selects_direction_before_pruning": True}


def run(count: int, output_dir: Path) -> dict:
    terms = make_terms(count)
    rows = []
    right_count = 0
    pruned_count = 0
    numerical_passed = 0
    numerical_skipped = 0
    padding_checks = 0
    for index, term in enumerate(terms):
        old, new = old_schema(term), new_schema(term)
        m, big_w = active_size(term), stored_size(term)
        i, j = occurrences(term, "n"), occurrences(term, "a")
        body = descriptor(term, True)
        body_w = stored_size(body)
        assert prune(body) == body
        assert body_w <= big_w
        assert active_vars(body) <= frozenset(("v", "w"))
        assert not formula_vars(old) and not formula_vars(new)
        assert quantifiers(old) == (3, 3)
        old_active = formula_size(old)
        old_stored = formula_size(old, True)
        new_active = formula_size(new)
        new_stored = formula_size(new, True)
        assert old_active == 35 + 7*m + 4*i + 3*j
        assert old_stored == 35 + 7*big_w + 4*i + 3*j + (i+2)*big_w
        if j == 0:
            right_count += 1
            trivial_endpoint = endpoint(term, N, True)
            assert isinstance(trivial_endpoint, Eq) and trivial_endpoint.left == trivial_endpoint.right
            assert quantifiers(new) == (2, 2)
            assert new_active == 22 + m
            assert new_stored == 22 + big_w + 3*body_w
            assert old_active - new_active == 13 + 6*m + 4*i
        else:
            assert quantifiers(new) == (3, 3)
            assert new_active == 35 + 7*m + 4*i
            assert new_stored == 35 + 7*big_w + 4*i + (i+2)*body_w
            assert old_active - new_active == 3*j
            assert old_stored - new_stored == 3*j + (i+2)*(big_w-body_w)
        assert new_active < old_active
        assert new_stored < old_stored
        # Every canonical autonomous descriptor obtains both orientations:
        # raw h gives right recursion; Q(S h,a) gives left recursion with
        # exactly the same frozen descriptor after root-only pruning.
        if occurrences(body, "w") == 0:
            raw_body = subst(body, {"v": N, "w": A})
            padded_body = q(Succ(raw_body), A)
            assert occurrences(raw_body, "a") == 0
            assert occurrences(padded_body, "a") == 1
            assert descriptor(raw_body, True) == body
            assert descriptor(padded_body, True) == body
            assert quantifiers(new_schema(raw_body)) == (2, 2)
            assert quantifiers(new_schema(padded_body)) == (3, 3)
            padding_checks += 1
        if prune(term) != term:
            pruned_count += 1
        row = {"index": index, "term": pretty(term), "canonical_body": pretty(body),
               "active_input_size": m, "stored_input_size": big_w,
               "canonical_body_stored_size": body_w,
               "occ_n": i, "occ_a": j,
               "direction": "right" if j == 0 else "left",
               "old_active": old_active, "new_active": new_active,
               "old_with_stored": old_stored, "new_with_stored": new_stored}
        rows.append(row)
        if index < min(120, count):
            try:
                for n in range(4):
                    for a in range(4):
                        evaluator = Evaluator()
                        assert evaluator.term(term, {"n": n, "a": a}) == evaluator.term(prune(term), {"n": n, "a": a})
                assert Evaluator(250000).formula(new, {}, 3)
                numerical_passed += 1
            except EvaluationLimit:
                numerical_skipped += 1
    frozen = frozen_and_pruning_audit()
    summary = {
        "status": "passed",
        "distinct_input_terms": len(terms),
        "formulas_built_and_counted": 2*len(terms),
        "right_cases": right_count,
        "left_cases": len(terms)-right_count,
        "raw_terms_changed_by_root_pruning": pruned_count,
        "strict_active_saving_all_cases": True,
        "strict_stored_descriptor_saving_all_cases": True,
        "minimum_active_saving_in_sample": min(r["old_active"]-r["new_active"] for r in rows),
        "minimum_stored_saving_in_sample": min(r["old_with_stored"]-r["new_with_stored"] for r in rows),
        "maximum_descriptor_dependency_rank_in_sample": max(term_rank(t) for t in terms),
        "autonomous_descriptor_padding_checks": padding_checks,
        "omitted_zero_anchor_premises_syntactically_reflexive": True,
        "scope_and_frozen_descriptor_audit": frozen,
        "numerical_standard_N_checks": {"passed": numerical_passed, "fuel_limited_skips": numerical_skipped,
                                        "quantifier_bound": 3,
                                        "meaning": "finite diagnostics only; not a proof of the general interpretation"},
        "cost_formulas": {
            "old_active": "35 + 7*m + 4*i + 3*j",
            "new_active_j_zero": "22 + m",
            "new_active_j_positive": "35 + 7*m + 4*i",
            "old_with_stored": "35 + 7*W + 4*i + 3*j + (i+2)*W",
            "new_with_stored_j_zero": "22 + W + 3*WN",
            "new_with_stored_j_positive": "35 + 7*W + 4*i + (i+2)*WN"
        },
        "limitations": ["The mathematical bootstrap, pairing, and bi-interpretation are not mechanized here.",
                        "The comparison counts formulas and stored descriptors; the two-case generator and pruning grammar are separate stated costs.",
                        "No global minimality result follows from these checks."]
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "syntax_checks.json").write_text(json.dumps(summary, indent=2) + "\n")
    (output_dir / "syntax_cases.json").write_text(json.dumps(rows, indent=2) + "\n")
    examples = rows[:14]
    (output_dir / "syntax_examples.txt").write_text("\n\n".join(
        f"{r['term']}\n  N(body)={r['canonical_body']}\n  branch={r['direction']}; m={r['active_input_size']}, i={r['occ_n']}, j={r['occ_a']}\n"
        f"  active old/new={r['old_active']}/{r['new_active']}; including stored={r['old_with_stored']}/{r['new_with_stored']}"
        for r in examples) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=600)
    parser.add_argument("--output-dir", type=Path, default=Path("checks"))
    args = parser.parse_args()
    if args.count < 14:
        parser.error("--count must be at least 14")
    print(json.dumps(run(args.count, args.output_dir), indent=2))


if __name__ == "__main__":
    main()
