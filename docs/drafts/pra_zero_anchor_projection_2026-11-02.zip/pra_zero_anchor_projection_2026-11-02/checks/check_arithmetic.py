#!/usr/bin/env python3
"""Bounded standard-N diagnostics for the written PRA calibration.

This checks numerical identities through explicit scalar iteration.
It does not prove induction, equality reflection in nonstandard models,
or the first-order bi-interpretation.
"""
import argparse
import json
from pathlib import Path


def rec(body, n, seed):
    state = seed
    for counter in range(n):
        state = body(state, counter)
    return state


def iterate(body, n, seed):
    return rec(lambda v, w: body(v), n, seed)


def q(n, a):
    return rec(lambda v, w: w, n, a)


def p(n):
    return q(n, 0)


def zero_eraser(n, a):
    return rec(lambda v, w: 0, n, a)


def select(r, b, c):
    return q(zero_eraser(r, b + 1), zero_eraser(zero_eraser(r, 1), c))


def difference(x, y):
    return iterate(p, y, x)


def chi(r):
    return select(r, 1, select(p(r), 0, 1))


def equality_bit(x, y):
    return chi(difference(x + 1, y))


def residual(n, a):
    r = difference(a, n)
    return select(r, n, difference(a, r))


def run(bound=18, pairing_bound=7):
    counts = {"selector": 0, "difference_orientations": 0,
              "diagonal": 0, "residual": 0, "equality_bit": 0,
              "pairing": 0}
    for n in range(bound + 1):
        assert p(0) == 0 and p(n + 1) == n
        assert difference(n + 1, n) == 1
        assert difference(n, n) == 0
        assert difference(0, n) == 0
        counts["diagonal"] += 3
        for a in range(bound + 1):
            assert select(0, n, a) == n
            assert select(n + 1, n, a) == a
            counts["selector"] += 2
            assert difference(a, n + 1) == p(difference(a, n))
            assert difference(a, n + 1) == difference(p(a), n)
            counts["difference_orientations"] += 2
            assert residual(n, a) == n
            counts["residual"] += 1
            bit = equality_bit(n, a)
            assert bit in (0, 1) and (bit == 0) == (n == a)
            counts["equality_bit"] += 1

    # The pairing audit uses the proved closed forms for half and parity;
    # the long scalar stripping iterates are still evaluated explicitly.
    # This avoids millions of redundant predecessor calls while retaining
    # the two nontrivial retraction computations from the written proof.
    def parity(x):
        return x % 2

    def half(x):
        return x // 2

    def j0(v):
        return half(v) if parity(v) == 0 else v

    def j1(v):
        return half(v) if parity(v) == 0 else v + 2

    def pair(x, y):
        return iterate(lambda v: v + v, x, 2*y + 1)

    max_code = 0
    for x in range(pairing_bound + 1):
        for y in range(pairing_bound + 1):
            code = pair(x, y)
            max_code = max(max_code, code)
            u = iterate(j0, code, code)
            w = iterate(j1, code, code)
            left = max(0, code - half(max(0, w-u)))
            right = half(u)
            assert (left, right) == (x, y)
            counts["pairing"] += 1
    result = {"status": "passed", "arithmetic_bound_inclusive": bound,
              "pairing_coordinate_bound_inclusive": pairing_bound,
              "largest_pairing_code_checked": max_code,
              "checks": counts,
              "scope": "Finite standard-natural-number diagnostics; full theory equivalence is proved in report.pdf, not by this script.",
              "pairing_implementation_note": "Uses x//2, x%2 and max(0,x-y) for previously proved arithmetic operations; scalar stripping loops are explicit."}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bound", type=int, default=18)
    parser.add_argument("--pairing-bound", type=int, default=7)
    parser.add_argument("--output-dir", type=Path, default=Path("checks/results"))
    args = parser.parse_args()
    result = run(args.bound, args.pairing_bound)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "arithmetic_checks.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
