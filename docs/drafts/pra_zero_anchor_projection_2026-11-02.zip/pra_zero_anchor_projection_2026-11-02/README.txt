ZERO-ANCHOR PRA WITH PROJECTION ALIASES
Prepared for Vladimir Reshetnikov, November 2, 2026.

Read report.pdf for the complete result and proof. AXIOMS.txt is the
standalone exact two-branch specification; AXIOMS_PRUNED.txt gives the
equivalent smaller three-branch emitter recommended when output size is
the objective. The report's source is report.tex with
the files in sections/.

MAIN RESULT
The new theory is definitionally equivalent, bi-interpretable and
equiconsistent with first-order PRA. The result holds separately in
classical and intuitionistic logic. Both interpretations preserve the
entire carrier and native equality; both round trips are identity maps.

The new mechanism is root pruning of Q(S t,s) to t in descriptor names,
combined with a computation-direction choice from raw syntax. A single
autonomous iterator thereby obtains both left and right computation
laws. The missing diagonal for zero-anchor induction becomes provable
by parameter-free induction, and native equality is reflected before
addition or pairing.

COMPARISON
All six current docs/drafts ZIPs were read at ProveIt commit
5ffc596c844086fc26509685c7833b548ebf25c3.
The actual smallest published active template costs 35+7m+4i+3j.
The main two-branch emitter costs 22+m when j=0 and 35+7m+4i when j>0.
The smaller three-branch emitter costs 20+m when i=0, 22+m when
i>0 and j=0, and 35+7m+4i when i>0 and j>0.
The improvement is strict for every corresponding published instance,
including repeated-descriptor counting. The additional two-case printer
and projection-alias rule are real specification costs. No absolute
minimality claim is made; trivial-clause preprocessing is discussed.

BUILD AND CHECK (Python standard library plus a TeX installation)
  python3 checks/check_schema.py --output-dir checks/results
  python3 checks/check_arithmetic.py --output-dir checks/results
  python3 checks/check_optional_pruning.py --output-dir checks/results
  python3 build.py

The default syntax run builds 1200 formula trees for 600 distinct inputs,
checks active/stored counts, substitution, scope, pruning and padding.
Numerical runs are finite diagnostics only. The full bi-interpretation
is a written mathematical proof, not a completed Lean/Rocq formalization.

SOURCE ATTRIBUTION
The scalar pairing and finite-description compiler adapt the current
counter-recursion draft's written proofs. The short residual comes from
the older moving-target draft, where the unit diagonal was assumed.
Here that diagonal is derived using the new mechanism. Exact source
URLs and verified hashes are in audit/source_manifest.json.

CONTENTS
report.pdf; report.tex; sections/*.tex
AXIOMS.txt; AXIOMS_PRUNED.txt; README.txt; build.py
checks/check_schema.py; checks/check_arithmetic.py; checks/check_optional_pruning.py
checks/results/*
audit/source_manifest.json; build and review records
SHA256SUMS.txt

The report includes Further research questions, a full comparison ledger,
the explicit interpretation maps, and a product-model obstruction to
the tempting replacement by atomic-equation induction alone.
