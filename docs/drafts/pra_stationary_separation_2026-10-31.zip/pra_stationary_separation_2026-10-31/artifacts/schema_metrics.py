#!/usr/bin/env python3
"""Reproduce schematic syntax counts; these are not program byte counts."""
import json
from dataclasses import dataclass

@dataclass(frozen=True)
class Node:
    tag: str
    args: tuple = ()
    def size(self):
        return 1 + sum(a.size() for a in self.args)
    def equalities(self):
        return int(self.tag == '=') + sum(a.equalities() for a in self.args)

def N(tag, *args): return Node(tag, args)
def app(name, *args): return N(name, *args)
def eq(x, y): return N('=', x, y)
def neg(x): return N('implies', x, N('bottom'))
def both(x, y): return N('and', x, y)
def either(x, y): return N('or', x, y)
def impl(x, y): return N('implies', x, y)
def all_(name, x): return N('forall:'+name, x)

z, n, a, x, y, k, v = (N(s) for s in ('0','n','a','x','y','k','v'))
S = lambda t: app('S',t)
one = S(z)
f = lambda t: app('f',t,a)
e = lambda u,w: app('e',u,w)
rho = lambda t: app('rho',t)
p = lambda t: app('I_k',t,z)
J = lambda u,w: app('J_rho',u,w)
I = lambda u,w: app('I_h',u,w)

D0 = all_('a',eq(I(z,a),a))
D1 = all_('n',all_('a',eq(I(S(n),a),app('h',n,I(n,a)))))
E = all_('x',all_('y',both(eq(e(x,x),one),either(eq(e(x,y),z),eq(x,y)))))
Flat = all_('x',all_('y',both(eq(app('m',x,x),x),either(eq(app('m',x,y),z),eq(x,y)))))
stationary = all_('n',eq(f(S(n)),f(n)))
SS = all_('a',impl(stationary,all_('n',neg(eq(S(f(n)),f(z))))))
CONST = all_('a',impl(stationary,all_('n',eq(f(n),f(z)))))
PC = all_('a',impl(all_('n',eq(f(S(S(n))),f(S(n)))),
                    all_('n',either(eq(n,z),eq(f(n),f(one))))))
AU = all_('a',impl(all_('n',eq(f(S(n)),rho(f(n)))),
                    both(neg(eq(z,one)),all_('n',either(eq(n,z),eq(f(n),J(p(n),f(one))))))))
DU = all_('a',impl(all_('n',eq(f(S(n)),rho(f(n)))),
                    both(neg(eq(z,one)),all_('n',either(eq(n,z),eq(f(n),rho(app('D_rho',n,f(z)))))))))
transform = app('P',app('B',k,S(v)),rho(v))

def main():
    forms = {'D0':D0,'D1':D1,'E':E,'Flat':Flat,'SS':SS,'CONST':CONST,'PC':PC,'AU':AU,'DU':DU,
             'DU_descriptor_transform':transform}
    result = {s:{'nodes':t.size(),'equality_occurrences':t.equalities()} for s,t in forms.items()}
    assert (D0.size()+D1.size(),E.size(),SS.size(),CONST.size(),PC.size(),AU.size(),DU.size(),transform.size()) == (18,18,22,19,26,36,34,7)
    assert Flat.size()==17
    result['totals'] = {'new_D_E_SS':58,'flat_meet_variant':57,'AU_with_D':54,'DU_with_D':52,
                        'DU_with_D_and_one_descriptor_template':59}
    result['caution'] = ('The final 59 count adds unlike formula and descriptor-template costs; '
                         'it is reported for transparency, not as a global ordering. '
                         'The new system adds one primitive binary equality-bit symbol. '
                         'Stored descriptions and instantiated program sizes are not counted.')
    print(json.dumps(result,indent=2))

if __name__ == '__main__': main()
