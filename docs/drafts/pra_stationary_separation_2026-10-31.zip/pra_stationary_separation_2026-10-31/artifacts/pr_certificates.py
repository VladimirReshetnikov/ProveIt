#!/usr/bin/env python3
"""Strict PR evaluation certificates and the zero-output batch construction.

This is a readable reference checker for the manuscript's local rules.
Program objects/JSON IDs stand for finite syntax, not for equivalence
classes of functions. In particular, ignored arguments ARE evaluated.
This universal Python evaluator is not claimed primitive recursive.
The diagnostics do not formally verify the arithmetical theorem.
"""
from dataclasses import dataclass, replace
from functools import lru_cache
from itertools import product
from pathlib import Path
import json

@dataclass(frozen=True)
class Program:
    tag: str
    arity: int
    data: tuple=()

def zero(r):
    assert r>=0
    return Program('zero',r)
SUCC=Program('succ',1)
def proj(r,i):
    assert 0<=i<r
    return Program('proj',r,(i,))
def comp(g, hs, r):
    hs=tuple(hs)
    assert g.arity==len(hs) and all(h.arity==r for h in hs)
    return Program('comp',r,(g,hs))
def rec(g,h):
    assert h.arity==g.arity+2
    return Program('rec',g.arity+1,(g,h))

@lru_cache(None)
def well_formed(p):
    if not isinstance(p,Program) or not isinstance(p.arity,int) or p.arity<0: return False
    if p.tag=='zero': return p.data==()
    if p.tag=='succ': return p.arity==1 and p.data==()
    if p.tag=='proj':
        return len(p.data)==1 and isinstance(p.data[0],int) and 0<=p.data[0]<p.arity
    if p.tag=='comp' and len(p.data)==2:
        g,hs=p.data
        return (isinstance(hs,tuple) and well_formed(g) and g.arity==len(hs)
                and all(well_formed(h) and h.arity==p.arity for h in hs))
    if p.tag=='rec' and len(p.data)==2:
        g,h=p.data
        return well_formed(g) and well_formed(h) and p.arity==g.arity+1 and h.arity==g.arity+2
    return False

@dataclass(frozen=True)
class Entry:
    program: Program
    inputs: tuple
    value: int
    children: tuple

def evaluate(p,args,nodes):
    args=tuple(args)
    assert len(args)==p.arity and all(isinstance(x,int) and x>=0 for x in args)
    if p.tag=='zero':
        value=0; children=()
    elif p.tag=='succ':
        value=args[0]+1; children=()
    elif p.tag=='proj':
        value=args[p.data[0]]; children=()
    elif p.tag=='comp':
        g,hs=p.data
        inner=tuple(evaluate(h,args,nodes) for h in hs)
        outer=evaluate(g,tuple(nodes[i].value for i in inner),nodes)
        value=nodes[outer].value; children=inner+(outer,)
    else:
        g,h=p.data; n,*parameters=args
        if n==0:
            child=evaluate(g,parameters,nodes)
            value=nodes[child].value; children=(child,)
        else:
            previous=evaluate(p,(n-1,*parameters),nodes)
            step=evaluate(h,(n-1,nodes[previous].value,*parameters),nodes)
            value=nodes[step].value; children=(previous,step)
    nodes.append(Entry(p,args,value,children))
    return len(nodes)-1

def verify(nodes,root_program,root_inputs):
    if not nodes: return False
    for index,node in enumerate(nodes):
        p,args,y,children=node.program,node.inputs,node.value,node.children
        if not well_formed(p): return False
        if len(args)!=p.arity or not isinstance(y,int) or y<0: return False
        if any(not isinstance(t,int) or t<0 for t in args): return False
        if any(not isinstance(i,int) or i<0 or i>=index for i in children): return False
        def matches(i,program,inputs):
            return nodes[i].program==program and nodes[i].inputs==tuple(inputs)
        if p.tag=='zero':
            if y!=0 or children: return False
        elif p.tag=='succ':
            if y!=args[0]+1 or children: return False
        elif p.tag=='proj':
            if y!=args[p.data[0]] or children: return False
        elif p.tag=='comp':
            g,hs=p.data
            if len(children)!=len(hs)+1: return False
            if any(not matches(i,h,args) for h,i in zip(hs,children)): return False
            vals=tuple(nodes[i].value for i in children[:-1])
            if not matches(children[-1],g,vals) or y!=nodes[children[-1]].value: return False
        elif p.tag=='rec':
            g,h=p.data; n,*parameters=args
            if n==0:
                if len(children)!=1 or not matches(children[0],g,parameters): return False
            else:
                if len(children)!=2: return False
                previous,step=children
                if not matches(previous,p,(n-1,*parameters)): return False
                if not matches(step,h,(n-1,nodes[previous].value,*parameters)): return False
            if y!=nodes[children[-1]].value: return False
        else: return False
    return nodes[-1].program==root_program and nodes[-1].inputs==tuple(root_inputs)

ADD=rec(proj(1,0),comp(SUCC,[proj(3,1)],3))
MUL=rec(zero(1),comp(ADD,[proj(3,1),proj(3,2)],3))

def batch(terms,parameter_count):
    """A zero-valued recursion which strictly evaluates terms at each index."""
    r=parameter_count
    assert all(t.arity==r+1 for t in terms)
    discard=zero(len(terms))
    base_args=[zero(r)]+[proj(r,j) for j in range(r)]
    base=comp(discard,[comp(t,base_args,r) for t in terms],r)
    step_args=[comp(SUCC,[proj(r+2,0)],r+2)]+[proj(r+2,j+2) for j in range(r)]
    step=comp(discard,[comp(t,step_args,r+2) for t in terms],r+2)
    return rec(base,step)

def serialize(nodes):
    programs=[]; ids={}
    def pid(p):
        if p in ids: return ids[p]
        d={'tag':p.tag,'arity':p.arity}
        if p.tag=='proj': d['coordinate']=p.data[0]
        if p.tag=='comp':
            d['outer']=pid(p.data[0]);d['inners']=[pid(h) for h in p.data[1]]
        if p.tag=='rec': d['base']=pid(p.data[0]);d['step']=pid(p.data[1])
        i=len(programs);ids[p]=i;programs.append(d);return i
    entries=[{'program':pid(n.program),'inputs':n.inputs,'value':n.value,'children':n.children} for n in nodes]
    return {'format':'human-readable-postorder-pr-certificate-v1',
            'programs':programs,'entries':entries,
            'note':'Array positions are IDs; every child index is strictly smaller than its parent index.'}

def main():
    b=batch([ADD,MUL],1); cases=0; extracted=0; total_nodes=0
    for endpoint,parameter in product(range(7),range(6)):
        nodes=[];root=evaluate(b,(endpoint,parameter),nodes)
        assert root==len(nodes)-1 and nodes[root].value==0
        assert verify(nodes,b,(endpoint,parameter))
        for i in range(endpoint+1):
            av=[n.value for n in nodes if n.program==ADD and n.inputs==(i,parameter)]
            mv=[n.value for n in nodes if n.program==MUL and n.inputs==(i,parameter)]
            assert av and mv and set(av)=={i+parameter} and set(mv)=={i*parameter}
            extracted+=2
        bad=list(nodes);bad[-1]=replace(bad[-1],value=1)
        assert not verify(bad,b,(endpoint,parameter))
        bad=list(nodes);bad[-1]=replace(bad[-1],children=(len(bad)-1,))
        assert not verify(bad,b,(endpoint,parameter))
        cases+=1;total_nodes+=len(nodes)
    sample=[];evaluate(b,(3,2),sample)
    assert not verify([Entry(Program('succ',2),(2,3),3,())],Program('succ',2),(2,3))
    Path(__file__).with_name('sample_certificate.json').write_text(json.dumps(serialize(sample),indent=2)+'\n')
    print(json.dumps({'batch_certificates_checked':cases,'local_nodes_checked':total_nodes,
                      'term_input_pairs_extracted':extracted,'tampered_certificates_rejected':2*cases,
                      'sample_certificate_nodes':len(sample),'ill_typed_program_rejected':True,
                      'status':'PASS: executable local-rule diagnostics, not formal arithmetization'},indent=2))

if __name__=='__main__':main()
