#!/usr/bin/env python3
"""Executable diagnostics for the term constructions in the manuscript.

Every iterator below has only counter and state free in its stored update.
These finite numerical checks do not certify first-order derivations or
bi-interpretability. The manuscript supplies those proofs.
"""
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json

@dataclass(frozen=True)
class Term:
    op: str
    args: tuple = ()

@dataclass(frozen=True)
class Descriptor:
    name: str
    update: Term

def var(name): return Term('var',(name,))
ZERO = Term('zero')
def S(t): return Term('succ',(t,))
ONE = S(ZERO)
def eqbit(t,u): return Term('eqbit',(t,u))
def I(d,n,a): return Term('iter',(d,n,a))

def fv(t):
    if t.op=='var': return {t.args[0]}
    if t.op=='zero': return set()
    args=t.args[1:] if t.op=='iter' else t.args
    return set().union(*(fv(x) for x in args))

declared=[]
def declare(name, update):
    assert fv(update) <= {'k','v'}, (name,fv(update))
    def earlier(t):
        if t.op=='iter':
            d,n,a=t.args
            assert d in declared, (name,d.name)
            earlier(n); earlier(a)
        elif t.op not in ('zero','var'):
            for s in t.args: earlier(s)
    earlier(update)
    d=Descriptor(name,update); declared.append(d); return d

k,v=var('k'),var('v')
P=declare('P',k)
B=declare('B',ZERO)
A=declare('A',S(v))
def pred(t): return I(P,t,ZERO)
M=declare('M',pred(v))
def add(x,y): return I(A,x,y)
def monus(counter,seed): return I(M,counter,seed)
def C(t,u,w): return I(P,I(B,t,S(u)),w)
def Z(t): return eqbit(t,ZERO)
Q=declare('Q',Z(v))
def eps(t): return Z(Z(I(Q,t,ZERO)))
D=declare('D',S(S(v)))
def double(t): return I(D,t,ZERO)
H=declare('H',C(eps(k),v,S(v)))
def half(t): return I(H,t,ZERO)
def enc(t,b): return C(b,double(t),S(double(t)))
T=declare('T',add(v,S(k)))
def triangular(t): return I(T,t,ZERO)
RANK=declare('RANK',C(eqbit(S(k),triangular(S(v))),v,S(v)))
def rank(t): return I(RANK,t,ZERO)
def pair(x,y): return add(triangular(add(x,y)),y)
def right(t): return monus(triangular(rank(t)),t)
def left(t): return monus(right(t),rank(t))

@lru_cache(None)
def evaluate(t, env_tuple=()):
    env=dict(env_tuple)
    if t.op=='var': return env[t.args[0]]
    if t.op=='zero': return 0
    if t.op=='succ': return evaluate(t.args[0],env_tuple)+1
    if t.op=='eqbit': return int(evaluate(t.args[0],env_tuple)==evaluate(t.args[1],env_tuple))
    d,n,a=t.args
    count=evaluate(n,env_tuple); state=evaluate(a,env_tuple)
    for step in range(count):
        state=evaluate(d.update,(('k',step),('v',state)))
    return state

def ev(t, **env): return evaluate(t,tuple(sorted(env.items())))

def make_latch(name, truth_term):
    def subst(t, mapping):
        if t.op=='var': return mapping.get(t.args[0],t)
        if t.op=='zero': return t
        if t.op=='iter':
            d,n,a=t.args
            return I(d,subst(n,mapping),subst(a,mapping))
        return Term(t.op,tuple(subst(a,mapping) for a in t.args))
    truth_update=subst(truth_term,{'n':k,'a':half(v)})
    update=enc(half(v),C(truth_update,ZERO,eps(v)))
    return declare(name,update)

def main():
    x,y,n,a=map(var,('x','y','n','a'))
    counts={}
    for u,w in product(range(5),repeat=2):
        assert ev(C(ZERO,x,y),x=u,y=w)==u
        assert ev(C(ONE,x,y),x=u,y=w)==w
    counts['selector_cases']=50
    for j in range(61):
        assert ev(eps(n),n=j)==j%2
        assert ev(half(n),n=j)==j//2
        assert ev(eps(S(n)),n=j)==1-ev(eps(n),n=j)
    counts['parity_half_inputs']=61
    for u,b in product(range(25),(0,1)):
        code=enc(a,var('b'))
        assert ev(half(code),a=u,b=b)==u
        assert ev(eps(code),a=u,b=b)==b
    counts['bit_storage_cases']=50
    truths=[('equal',eqbit(n,a)),('all',ONE),('none',ZERO),
            ('at_most',eqbit(monus(a,n),ZERO)),('parity',eqbit(eps(n),eps(a)))]
    checked=0
    for name,truth in truths:
        latch=make_latch('LATCH_'+name,truth)
        for parameter in range(7):
            for bound in range(10):
                state=I(latch,n,enc(a,ONE))
                assert ev(half(state),n=bound,a=parameter)==parameter
                expected=int(all(ev(truth,n=i,a=parameter)==1 for i in range(bound)))
                assert ev(eps(state),n=bound,a=parameter)==expected
                checked+=1
    counts['latch_memory_and_prefix_cases']=checked
    local=0
    for b,b_next,r in product((0,1),repeat=3):
        if b==1 and b_next==0: continue
        shifted=r if b else 0
        shifted_next=shifted if b_next else 0
        assert shifted_next==shifted
        local+=1
    assert local==6
    counts['exhaustive_local_latch_cases']=local
    for u,w in product(range(12),repeat=2):
        code=pair(x,y)
        assert ev(left(code),x=u,y=w)==u
        assert ev(right(code),x=u,y=w)==w
    counts['pair_retraction_cases']=144
    gate=lambda t,u: u if t==0 else 0
    meet=lambda u,w: u if u==w else 0
    for u,w in product(range(13),repeat=2):
        normalized=gate(gate(meet(u+1,w+1),1),1)
        assert normalized==int(u==w)
    counts['flat_meet_equality_normalization_cases']=169
    counts['well_formed_binary_descriptors']=len(declared)
    counts['all_updates_have_only_counter_and_state']=True
    counts['status']='PASS: finite diagnostics; not a formal proof certificate'
    print(json.dumps(counts,indent=2))

if __name__=='__main__': main()
