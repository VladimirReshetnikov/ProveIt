PRA FROM STATIONARY SEPARATION AND AN EQUALITY BIT
Prepared for Vladimir Reshetnikov, 31 October 2026.

Main result
-----------
The binary-iterator theory D + E + SS is definitionally equivalent and
therefore bi-interpretable with ordinary first-order PRA, separately in
classical and intuitionistic logic. Both interpretations use the whole
numerical domain; their composite isomorphisms are the identity maps.

The arithmetic schema has one finite term f(n,a), one fixed parameter,
and two equality occurrences (one negated). Its 22-node display replaces
a 34-node delayed-uniqueness display in the current draft frontier, but
the new fixed equality-bit law costs 18 nodes. Full display totals:
  D + E + SS: 58 nodes.
  Flat-meet variant: 57 nodes.
  Existing delayed-uniqueness display: 52 nodes, with a separately
  specified descriptor transformation.
No absolute minimum or total-size record is claimed.

Files
-----
main.tex and sections/*.tex: complete LaTeX source.
pra_stationary_separation.pdf: compiled manuscript.
SOURCES.json: pinned repository snapshot and all six inspected ZIP hashes.
artifacts/schema_metrics.py and schema_metrics.json: exact AST metrics.
artifacts/check_constructions.py and check_results.json: binary term,
  storage, running-test, pairing, and flat-meet diagnostics.
artifacts/pr_certificates.py and certificate_results.json: strict PR
  evaluation-certificate checker and zero-output batch diagnostics.
artifacts/sample_certificate.json: a readable complete sample certificate.

Reproduce
---------
From this directory, with Python 3.10+ and a standard TeX Live installation:

  python3 artifacts/schema_metrics.py
  python3 artifacts/check_constructions.py
  python3 artifacts/pr_certificates.py
  latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The last command builds main.pdf. The delivered PDF has a descriptive name.
The certificate script rewrites its adjacent sample_certificate.json.
The numerical and local-rule checks are diagnostics, not a formal proof
certificate. No Lean or Rocq verification is claimed.

Scope
-----
The main theorem uses first-order envelopes with quantifier-free induction.
The same nonlogical axioms are used in the two logics; the complete
quantified classical and intuitionistic theories are not identified.
The secondary finite-signature theory uses elementary arithmetic plus
one numeral-indexed certificate-totality schema. Its fixed checker and
base have real description cost and are not counted as free compression.
A Further research questions section is included in the manuscript.
