#!/bin/sh
set -eu
cd "$(dirname "$0")"
LEAN_BIN=${LEAN_BIN:-lean}
mkdir -p .build/lean
PRA_LEAN_PATH="$(pwd)/.build/lean"
"$LEAN_BIN" --version
LEAN_PATH="$PRA_LEAN_PATH" "$LEAN_BIN" \
  -o .build/lean/ThreeHelperPRA.olean formal/ThreeHelperPRA.lean
LEAN_PATH="$PRA_LEAN_PATH" "$LEAN_BIN" formal/GuardedSuccessor.lean
python3 artifacts/schema_sizes.py --report artifacts/schema_sizes.json

