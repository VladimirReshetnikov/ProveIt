#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p .build/tex
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  -outdir=.build/tex pra_guarded_successor.tex
cp .build/tex/pra_guarded_successor.pdf pra_guarded_successor.pdf

