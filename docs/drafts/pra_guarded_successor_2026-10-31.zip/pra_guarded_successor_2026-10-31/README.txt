PRA WITH A SHORTER GUARDED SUCCESSOR SCHEMA
=========================================
Prepared for Vladimir Reshetnikov, 31 October 2026.

START HERE
----------
pra_guarded_successor.pdf is the complete 17-page research paper.
axioms.txt is the standalone specification.

RESULT
------
Two ordinary primitive-recursion computation templates plus one arithmetic
schema Y1 axiomatize PRA in either classical or intuitionistic first-order
logic. All newly declared functions can be binary; the arithmetic schema
needs only the induction variable and one fixed numerical parameter.
No separate nontriviality, successor, comparison, or induction axiom is added.

Y1 is a strict shortening of the exclusive X schema in the current drafts:
with one parameter, its expanded pattern has 60 syntax-tree nodes versus 82,
under the exact measure implemented in artifacts/schema_sizes.py.
The older guarded G plus separate 0!=1 remains shorter at 42 nodes.
This is a relative refinement and synthesis, not a global minimality claim.

A SECOND RESULT
---------------
The one induction parameter cannot be eliminated in this defining-equation
architecture. The paper constructs a two-copy model satisfying all recursion
equations, successor laws, positive coverage, and every parameter-free
quantifier-free induction instance. It fails one-parameter equation induction
for K(0,a)=a, K(Sn,a)=K(n,a). The countermodel also preserves all true unary
quantifier-free statements, so adding the unary zero-complement law does not
repair the failure.

CONTENTS
--------
pra_guarded_successor.tex       Main LaTeX source.
sections/comparison.tex         Constructive equality and formula compiler.
sections/pairing.tex            One-parameter pairing and full-language expansion.
sections/parameter_bound.tex    New two-copy countermodel and arity bound.
pra_guarded_successor.pdf       Compiled complete paper.
axioms.txt                     Exact specification in plain text.
formal/GuardedSuccessor.lean    New scoped Lean certificate.
formal/ThreeHelperPRA.lean      Unchanged credited predecessor certificate.
formal/README.txt              Formal scope and dependencies.
formal/verification.txt        Recorded Lean version and axiom audit.
artifacts/schema_sizes.py      Reproducible formula-pattern counter.
artifacts/schema_sizes.json    Recorded counts.
source_audit.json              Pinned source paths and verified archive hashes.
VALIDATION.txt                 Verification record and boundaries.
build.sh                      Rebuild PDF with latexmk.
check.sh                      Check Lean sources and syntax counts.
lean-toolchain                Lean version pin for elan.
SHA256SUMS                    Integrity hashes of all other delivered files.

REBUILD
-------
Run from this directory:
  sh build.sh

Requirements: latexmk and a normal TeX Live installation with the packages
named in the preamble. No network access is required.

CHECK
-----
Lean 4.19.0 and Python 3.10+ are sufficient. No Mathlib is required.
Run:
  sh check.sh

If lean is not on PATH:
  LEAN_BIN=/absolute/path/to/lean sh check.sh

The script compiles the predecessor module into .build/lean, then verifies
the new certificate using it. The delivered archive omits compiled modules
and intermediate TeX output.

For just the syntax counts:
  python3 artifacts/schema_sizes.py --report artifacts/schema_sizes.json

To verify the delivered bytes:
  sha256sum -c SHA256SUMS

WHAT IS AND IS NOT FORMALIZED
----------------------------
The new Lean certificate derives separation from Y, derives coverage,
reduces Y to guarded equation induction, and checks equivalence to
one-parameter quantifier-free induction. The predecessor module checks
the comparator and formula compiler, including intuitionistic implication.

All schemas in the certificate range over actual finite term/formula syntax;
they are not assumptions of induction over arbitrary semantic predicates.
The certificate uses the selector's equations as proved helper facts.
The paper supplies their binary-language construction after a noncircular
bootstrap with a fresh binary recursor.

The complete binary-language bootstrap, pairing, unrestricted first-order
proof translation, and two-copy countermodel are mathematical proofs in
the paper, not claims of complete Lean formalization. No sorryAx or
Classical.choice occurs in the recorded audit. The final evaluator transfer
uses propext and Quot.sound through function extensionality.

PROVENANCE
----------
All five current PRA draft ZIP archives at ProveIt commit
487040529a8792ae3239ae75e695424aee3d665c were retrieved and their Git blob
hashes verified. The binary draft supplies the credited comparator, pairing
construction and unchanged ThreeHelperPRA.lean. The new schema refinement
and parameter countermodel are established in this package.

The docs/incoming directory metadata and README index were inspected;
the unrelated PA-machine archive interiors were not searched.
Exact scope, URLs, and hashes are recorded in source_audit.json.

The earlier one-term X1 candidate remains outside the proved theorem.
No historical priority or absolute shortest-encoding claim is made.

