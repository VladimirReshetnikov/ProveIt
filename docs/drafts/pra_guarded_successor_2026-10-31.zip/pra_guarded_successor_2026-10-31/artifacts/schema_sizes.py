#!/usr/bin/env python3
"""Reproduce an explicit syntax-size comparison of four PRA presentations.

Usage:
    python3 artifacts/schema_sizes.py
    python3 artifacts/schema_sizes.py --report artifacts/schema_sizes.json

Every AST node counts once: function/constant/variable occurrences, equality,
connectives, and quantifier binders. Binder names are metadata. XOR and
negation are expanded using AND, OR, IMPLIES, and BOTTOM. Parameters occur
in every schematic term application. The outer parameter binders count.

For G + Sep, add the sizes of two separate formulas; do not join them with
an invented conjunction. The common computation templates are omitted.
This metric compares displayed templates, not the lengths of all their
instances after inserting particular primitive-recursive programs.
"""

import argparse
import json
from collections import Counter
from pathlib import Path


def node(symbol, *children):
    return (symbol, children)


def var(name):
    return node("variable:" + name)


def zero():
    return node("constant:0")


def suc(term):
    return node("function:S", term)


def eq(left, right):
    return node("equality", left, right)


def land(left, right):
    return node("and", left, right)


def lor(left, right):
    return node("or", left, right)


def imp(left, right):
    return node("implies", left, right)


def bottom():
    return node("bottom")


def xor(left, right):
    return land(lor(left, right), imp(land(left, right), bottom()))


def all_(name, body):
    return node("forall:" + name, body)


def close_parameters(formula, parameter_count):
    for index in reversed(range(parameter_count)):
        formula = all_("a" + str(index), formula)
    return formula


def schema(kind, parameter_count):
    """Return a tuple of separate formula trees for the named presentation."""
    n = var("n")
    parameters = tuple(var("a" + str(i)) for i in range(parameter_count))

    def r(term):
        return node("function:r", term, *parameters)

    def u(term):
        return node("function:u", term, *parameters)

    if kind == "G_plus_Sep":
        def positive(term):
            return lor(eq(term, zero()), eq(r(term), u(term)))

        step = all_("n", imp(positive(n), eq(r(suc(n)), u(suc(n)))))
        conclusion = all_("n", positive(n))
        guarded = close_parameters(imp(step, conclusion), parameter_count)
        separation = imp(eq(zero(), suc(zero())), bottom())
        return guarded, separation

    if kind not in ("X", "X0", "Y"):
        raise ValueError("Unknown schema: " + kind)

    def right(term):
        return eq(r(term), suc(u(term)))

    def left(term):
        return eq(term if kind == "Y" else r(term), zero())

    def positive(term):
        return lor(left(term), right(term))

    base = positive(zero()) if kind == "X" else eq(r(zero()), zero())
    step_target = positive(suc(n)) if kind == "X" else right(suc(n))
    step = all_("n", imp(positive(n), step_target))
    conclusion = all_("n", xor(left(n), right(n)))
    result = close_parameters(imp(land(base, step), conclusion), parameter_count)
    return (result,)


def count(tree):
    symbol, children = tree
    counts = Counter({symbol: 1})
    for child in children:
        counts.update(count(child))
    return counts


def report_for_parameters(parameter_count):
    results = {}
    for kind in ("X", "X0", "Y", "G_plus_Sep"):
        trees = schema(kind, parameter_count)
        counts = Counter()
        separate_sizes = []
        for tree in trees:
            current = count(tree)
            counts.update(current)
            separate_sizes.append(sum(current.values()))
        results[kind] = {
            "total": sum(counts.values()),
            "separate_formula_sizes": separate_sizes,
            "by_node": dict(sorted(counts.items())),
        }
    return results


def make_report():
    expected = {
        "X": (66, 16),
        "X0": (53, 13),
        "Y": (50, 10),
        "G_plus_Sep": (35, 7),
    }
    # Cross-check the independently derived linear formulas at several arities.
    for parameter_count in range(5):
        results = report_for_parameters(parameter_count)
        for kind, (constant, slope) in expected.items():
            actual = results[kind]["total"]
            predicted = constant + slope * parameter_count
            if actual != predicted:
                raise AssertionError((kind, parameter_count, actual, predicted))
    return {
        "metric": {
            "unit": "one node per function, constant, variable, equality, "
                    "connective, or quantifier occurrence",
            "xor_expansion": "(A OR B) AND ((A AND B) -> BOTTOM)",
            "negation_expansion": "A -> BOTTOM",
            "binder_names": "metadata; each quantifier binder counts once",
            "parameters": "k parameters in every r/u application, universally "
                          "closed outside the schema",
            "separate_formulas": "G and Sep are counted separately and added",
            "omissions": "common computation templates; parentheses and commas; "
                         "expansions of schematic terms into particular programs",
            "scope": "an exact comparison in this declared grammar, not an "
                     "absolute minimality theorem",
        },
        "sizes_as_functions_of_k": {
            kind: {"constant": constant, "coefficient_of_k": slope}
            for kind, (constant, slope) in expected.items()
        },
        "zero_parameter_instances": report_for_parameters(0),
        "one_parameter_instances": report_for_parameters(1),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, help="write the JSON report here")
    args = parser.parse_args()
    output = json.dumps(make_report(), indent=2, ensure_ascii=True) + "\n"
    if args.report is None:
        print(output, end="")
    else:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output, encoding="utf-8")
        print("Wrote " + str(args.report))


if __name__ == "__main__":
    main()
