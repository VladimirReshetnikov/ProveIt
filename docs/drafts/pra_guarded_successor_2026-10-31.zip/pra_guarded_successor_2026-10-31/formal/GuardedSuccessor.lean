import ThreeHelperPRA

/-
Copyright 2026. Prepared for Vladimir Reshetnikov.

Constructive certificate for the guarded-successor schema Y.
Lean 4.19.0, no external packages. The only import is the accompanying
ThreeHelperPRA certificate from the audited binary-PRA draft.

The raw arithmetic structure below does not assume separation. Separation
is derived from Y before the existing separated Core is instantiated.
All induction schemas range over syntactic terms with one number parameter;
no induction for arbitrary semantic functions or predicates is assumed.

The selector is a helper with the displayed equations. Its construction
from binary recursion, and the reduction from any finite number of
parameters to one, are proved in the accompanying paper, not in this file.
-/

namespace GuardedSuccessor

open ThreeHelperPRA

universe u v

structure RawCore (M : Type v) where
  zero : M
  succ : M → M
  pred : M → M
  cond : M → M → M → M
  monus : M → M → M
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  cond_zero : ∀ a b, cond zero a b = a
  cond_succ : ∀ x a b, cond (succ x) a b = b
  monus_zero : ∀ y, monus zero y = y
  monus_succ : ∀ x y, monus (succ x) y = pred (monus x y)

variable {M : Type v} {Sigma : Type u} {arity : Sigma → Nat}

def rawEval (R : RawCore M) (E : Extra M Sigma arity) {n : Nat}
    (t : Term Sigma arity n) (rho : Fin n → M) : M :=
  match t with
  | .var i => rho i
  | .zero => R.zero
  | .succ t => R.succ (rawEval R E t rho)
  | .pred t => R.pred (rawEval R E t rho)
  | .cond t s r => R.cond (rawEval R E t rho)
      (rawEval R E s rho) (rawEval R E r rho)
  | .monus t s => R.monus (rawEval R E t rho) (rawEval R E s rho)
  | .extra f args => E f (fun i => rawEval R E (args i) rho)

def Exclusive (A B : Prop) : Prop := (A ∨ B) ∧ ¬ (A ∧ B)

/-- Y before separation has been proved. -/
def RawY (R : RawCore M) (E : Extra M Sigma arity) : Prop :=
  ∀ (r t : Term Sigma arity 2) (a : M),
    rawEval R E r (env2 R.zero a) = R.zero →
    (∀ x, (x = R.zero ∨
      rawEval R E r (env2 x a) = R.succ (rawEval R E t (env2 x a))) →
      rawEval R E r (env2 (R.succ x) a) =
        R.succ (rawEval R E t (env2 (R.succ x) a))) →
    ∀ x, Exclusive (x = R.zero)
      (rawEval R E r (env2 x a) = R.succ (rawEval R E t (env2 x a)))

/-- The constant-zero instance derives separation without computation laws. -/
theorem raw_separation (R : RawCore M) (E : Extra M Sigma arity)
    (Y : RawY R E) : R.zero ≠ R.succ R.zero := by
  intro bad
  have h := Y .zero .zero R.zero rfl (by
    intro _ _
    exact bad) R.zero
  exact h.2 ⟨rfl, bad⟩

def RawCore.withSeparation (R : RawCore M) (h : R.zero ≠ R.succ R.zero) :
    Core M where
  zero := R.zero
  succ := R.succ
  pred := R.pred
  cond := R.cond
  monus := R.monus
  pred_zero := R.pred_zero
  pred_succ := R.pred_succ
  cond_zero := R.cond_zero
  cond_succ := R.cond_succ
  monus_zero := R.monus_zero
  monus_succ := R.monus_succ
  separation := h

theorem rawEval_withSeparation (R : RawCore M) (E : Extra M Sigma arity)
    (h : R.zero ≠ R.succ R.zero) {n : Nat} (t : Term Sigma arity n)
    (rho : Fin n → M) :
    rawEval R E t rho = t.eval (R.withSeparation h) E rho := by
  induction t with
  | var i => rfl
  | zero => rfl
  | succ t ih => exact congrArg R.succ ih
  | pred t ih => exact congrArg R.pred ih
  | cond t s r iht ihs ihr =>
      change R.cond _ _ _ = R.cond _ _ _
      rw [iht, ihs, ihr]
  | monus t s iht ihs =>
      change R.monus _ _ = R.monus _ _
      rw [iht, ihs]
  | extra f args ih =>
      change E f _ = E f _
      apply congrArg (E f)
      funext i
      exact ih i

/-- The same schema, using the existing separated evaluator. -/
def YSchema (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (r t : Term Sigma arity 2) (a : M),
    r.eval C E (env2 C.zero a) = C.zero →
    (∀ x, (x = C.zero ∨
      r.eval C E (env2 x a) = C.succ (t.eval C E (env2 x a))) →
      r.eval C E (env2 (C.succ x) a) =
        C.succ (t.eval C E (env2 (C.succ x) a))) →
    ∀ x, Exclusive (x = C.zero)
      (r.eval C E (env2 x a) = C.succ (t.eval C E (env2 x a)))

theorem raw_to_y (R : RawCore M) (E : Extra M Sigma arity)
    (Y : RawY R E) :
    YSchema (R.withSeparation (raw_separation R E Y)) E := by
  intro r t a base step x
  let h := raw_separation R E Y
  have bridge (q : Term Sigma arity 2) (y : M) :=
    rawEval_withSeparation R E h q (env2 y a)
  have result := Y r t a (by
    rw [bridge r R.zero]
    exact base) (by
    intro n hn
    have hn' : n = R.zero ∨
        r.eval (R.withSeparation h) E (env2 n a) =
          R.succ (t.eval (R.withSeparation h) E (env2 n a)) := by
      simpa only [bridge r n, bridge t n] using hn
    have hs := step n hn'
    simpa only [bridge r (R.succ n), bridge t (R.succ n)] using hs) x
  simpa only [bridge r x, bridge t x] using result

section Transfer

variable (C : Core M) (E : Extra M Sigma arity) (Y : YSchema C E)

include Y

theorem y_coverage (x : M) : x = C.zero ∨ x = C.succ (C.pred x) := by
  have h := Y (.var 0) (.pred (.var 0)) C.zero rfl (by
    intro n _
    change C.succ n = C.succ (C.pred (C.succ n))
    rw [C.pred_succ]) x
  exact h.1

/-- The short direct translation uses r(n)=cond(n,0,S(s(n))). -/
theorem y_implies_guarded : Guarded C E := by
  intro s t a step
  let r : Term Sigma arity 2 := .cond (.var 0) .zero (.succ s)
  have decode (n : M)
      (hn : n = C.zero ∨
        r.eval C E (env2 n a) = C.succ (t.eval C E (env2 n a))) :
      n = C.zero ∨ s.eval C E (env2 n a) = t.eval C E (env2 n a) := by
    rcases hn with hn | hn
    · exact Or.inl hn
    · rcases y_coverage C E Y n with h0 | hs
      · exact Or.inl h0
      · apply Or.inr
        apply successor_injective C
        change C.cond n C.zero (C.succ (s.eval C E (env2 n a))) =
          C.succ (t.eval C E (env2 n a)) at hn
        have hc : C.cond n C.zero (C.succ (s.eval C E (env2 n a))) =
            C.succ (s.eval C E (env2 n a)) := by
          rw [hs, C.cond_succ]
        rw [hc] at hn
        exact hn
  have conclusion := Y r t a (by
    change C.cond C.zero C.zero _ = C.zero
    exact C.cond_zero _ _)
    (by
      intro n hn
      have hst := step n (decode n hn)
      change C.cond (C.succ n) C.zero _ = _
      rw [C.cond_succ]
      exact congrArg C.succ hst)
  intro n
  exact decode n (conclusion n).1

theorem y_implies_quantifier_free : QFInduction C E := by
  exact (guarded_iff_quantifier_free C E).mp (y_implies_guarded C E Y)

end Transfer

theorem quantifier_free_implies_y (C : Core M) (E : Extra M Sigma arity)
    (I : QFInduction C E) : YSchema C E := by
  intro r t a base step
  let A : Formula Sigma arity 2 :=
    .disj (.equal (.var 0) .zero) (.equal r (.succ t))
  have h := I A a (Or.inl rfl) (by
    intro n hn
    exact Or.inr (step n hn))
  intro n
  constructor
  · exact h n
  · intro both
    have h0 := both.1
    have he := both.2
    subst n
    rw [base] at he
    exact successor_nonzero C (t.eval C E (env2 C.zero a)) he.symm

theorem y_iff_quantifier_free (C : Core M) (E : Extra M Sigma arity) :
    YSchema C E ↔ QFInduction C E := by
  exact ⟨y_implies_quantifier_free C E, quantifier_free_implies_y C E⟩

/-- Separation and QF induction follow constructively from the raw Y schema. -/
theorem raw_y_quantifier_free (R : RawCore M) (E : Extra M Sigma arity)
    (Y : RawY R E) :
    QFInduction (R.withSeparation (raw_separation R E Y)) E := by
  exact y_implies_quantifier_free _ E (raw_to_y R E Y)

#print axioms raw_separation
#print axioms y_coverage
#print axioms y_implies_guarded
#print axioms y_iff_quantifier_free
#print axioms raw_y_quantifier_free

end GuardedSuccessor
