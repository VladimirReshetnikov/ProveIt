/-
Copyright 2026. Prepared for Vladimir Reshetnikov.

Lean 4.19.0; no imports and no external packages.

This is a constructive algebraic certificate. Its only arithmetic induction
assumption is the displayed guarded schema for syntactic terms with exactly
two available numerical variables: the induction variable and one parameter.
It does not assume induction for arbitrary functions or predicates on M.

The certificate proves constructor coverage, the three-helper equality
test, compilation of all finite-arity quantifier-free formulas, and the
one-parameter quantifier-free induction schema. The paper's pairing argument
reducing arbitrarily many parameters to one is outside this certificate.
-/

namespace ThreeHelperPRA

universe u v

/-- The three displayed recursion descriptions and ground separation. -/
structure Core (M : Type v) where
  zero : M
  succ : M → M
  pred : M → M
  cond : M → M → M → M
  monus : M → M → M
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  cond_zero : ∀ a b, cond zero a b = a
  cond_succ : ∀ x a b, cond (succ x) a b = b
  monus_zero : ∀ y, monus zero y = y
  monus_succ : ∀ x y, monus (succ x) y = pred (monus x y)
  separation : zero ≠ succ zero

/-- A term has a finite variable context. Extra symbols have stated arities. -/
inductive Term (Sigma : Type u) (arity : Sigma → Nat) (n : Nat) : Type u where
  | var : Fin n → Term Sigma arity n
  | zero : Term Sigma arity n
  | succ : Term Sigma arity n → Term Sigma arity n
  | pred : Term Sigma arity n → Term Sigma arity n
  | cond : Term Sigma arity n → Term Sigma arity n →
      Term Sigma arity n → Term Sigma arity n
  | monus : Term Sigma arity n → Term Sigma arity n → Term Sigma arity n
  | extra : (f : Sigma) → (Fin (arity f) → Term Sigma arity n) →
      Term Sigma arity n

variable {M : Type v} {Sigma : Type u} {arity : Sigma → Nat}

abbrev Extra (M : Type v) (Sigma : Type u) (arity : Sigma → Nat) :=
  (f : Sigma) → (Fin (arity f) → M) → M

def Term.eval (C : Core M) (E : Extra M Sigma arity) {n : Nat}
    (t : Term Sigma arity n) (rho : Fin n → M) : M :=
  match t with
  | .var i => rho i
  | .zero => C.zero
  | .succ t => C.succ (t.eval C E rho)
  | .pred t => C.pred (t.eval C E rho)
  | .cond t s r => C.cond (t.eval C E rho) (s.eval C E rho) (r.eval C E rho)
  | .monus t s => C.monus (t.eval C E rho) (s.eval C E rho)
  | .extra f args => E f (fun i => (args i).eval C E rho)

/-- Variable 0 is the induction variable; variable 1 is the sole parameter. -/
def env2 (x a : M) : Fin 2 → M :=
  fun i => if i.val = 0 then x else a

/-- The one-parameter guarded schema, restricted to actual syntactic terms. -/
def Guarded (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (s t : Term Sigma arity 2) (a : M),
    (∀ x, (x = C.zero ∨
      s.eval C E (env2 x a) = t.eval C E (env2 x a)) →
      s.eval C E (env2 (C.succ x) a) =
        t.eval C E (env2 (C.succ x) a)) →
    ∀ x, x = C.zero ∨ s.eval C E (env2 x a) = t.eval C E (env2 x a)

section Arithmetic

variable (C : Core M) (E : Extra M Sigma arity) (G : Guarded C E)

theorem successor_injective {x y : M} (h : C.succ x = C.succ y) : x = y := by
  have hp := congrArg C.pred h
  simpa only [C.pred_succ] using hp

theorem successor_nonzero (x : M) : C.succ x ≠ C.zero := by
  intro h
  have hc := congrArg (fun q => C.cond q C.zero (C.succ C.zero)) h
  have h10 : C.succ C.zero = C.zero := by
    simpa only [C.cond_succ, C.cond_zero] using hc
  exact C.separation h10.symm

def error (x y : M) : M :=
  C.cond (C.monus x y) (C.monus y x) (C.succ C.zero)

include G

/-- Ordinary equation induction, still only for terms with one parameter. -/
theorem equation_induction (s t : Term Sigma arity 2) (a : M)
    (base : s.eval C E (env2 C.zero a) = t.eval C E (env2 C.zero a))
    (step : ∀ x, s.eval C E (env2 x a) = t.eval C E (env2 x a) →
      s.eval C E (env2 (C.succ x) a) =
        t.eval C E (env2 (C.succ x) a)) :
    ∀ x, s.eval C E (env2 x a) = t.eval C E (env2 x a) := by
  have h := G s t a (by
    intro x hx
    apply step x
    rcases hx with hx | hx
    · subst x
      exact base
    · exact hx)
  intro x
  rcases h x with hx | hx
  · subst x
    exact base
  · exact hx

theorem constructor_coverage (x : M) :
    x = C.zero ∨ x = C.succ (C.pred x) := by
  have h := G (.var 0) (.succ (.pred (.var 0))) C.zero (by
    intro n _
    change C.succ n = C.succ (C.pred (C.succ n))
    rw [C.pred_succ])
  exact h x

theorem zero_cases (x : M) : x = C.zero ∨ x ≠ C.zero := by
  rcases constructor_coverage C E G x with hx | hx
  · exact Or.inl hx
  · apply Or.inr
    intro h0
    exact successor_nonzero C (C.pred x) (hx.symm.trans h0)

theorem conditional_nonzero (x a b : M) (hx : x ≠ C.zero) :
    C.cond x a b = b := by
  rcases constructor_coverage C E G x with h | h
  · exact False.elim (hx h)
  · rw [h, C.cond_succ]

theorem conditional_same (x a : M) : C.cond x a a = a := by
  rcases constructor_coverage C E G x with h | h
  · rw [h, C.cond_zero]
  · rw [h, C.cond_succ]

/-- First exact induction instance: monus(Sx,Sy) = monus(x,y). -/
theorem monus_shift (x y : M) :
    C.monus (C.succ x) (C.succ y) = C.monus x y := by
  let s : Term Sigma arity 2 := .monus (.succ (.var 0)) (.succ (.var 1))
  let t : Term Sigma arity 2 := .monus (.var 0) (.var 1)
  have h := equation_induction C E G s t y
    (by
      change C.monus (C.succ C.zero) (C.succ y) = C.monus C.zero y
      rw [C.monus_succ, C.monus_zero, C.pred_succ, C.monus_zero])
    (by
      intro n hn
      change C.monus (C.succ n) (C.succ y) = C.monus n y at hn
      change C.monus (C.succ (C.succ n)) (C.succ y) =
        C.monus (C.succ n) y
      calc
        C.monus (C.succ (C.succ n)) (C.succ y) =
            C.pred (C.monus (C.succ n) (C.succ y)) := C.monus_succ _ _
        _ = C.pred (C.monus n y) := congrArg C.pred hn
        _ = C.monus (C.succ n) y := (C.monus_succ _ _).symm)
  exact h x

/-- Second exact instance: the diagonal is zero; the parameter is unused. -/
theorem monus_diagonal (x : M) : C.monus x x = C.zero := by
  let s : Term Sigma arity 2 := .monus (.var 0) (.var 0)
  let t : Term Sigma arity 2 := .zero
  have h := equation_induction C E G s t C.zero
    (by
      change C.monus C.zero C.zero = C.zero
      exact C.monus_zero _)
    (by
      intro n hn
      change C.monus n n = C.zero at hn
      change C.monus (C.succ n) (C.succ n) = C.zero
      exact (monus_shift C E G n n).trans hn)
  exact h x

/-- Third exact instance: the adjacent diagonal is one. -/
theorem monus_adjacent (x : M) : C.monus x (C.succ x) = C.succ C.zero := by
  let s : Term Sigma arity 2 := .monus (.var 0) (.succ (.var 0))
  let t : Term Sigma arity 2 := .succ .zero
  have h := equation_induction C E G s t C.zero
    (by
      change C.monus C.zero (C.succ C.zero) = C.succ C.zero
      exact C.monus_zero _)
    (by
      intro n hn
      change C.monus n (C.succ n) = C.succ C.zero at hn
      change C.monus (C.succ n) (C.succ (C.succ n)) = C.succ C.zero
      exact (monus_shift C E G n (C.succ n)).trans hn)
  exact h x

/-- This is merely the shift identity expanded, not another induction. -/
theorem monus_predecessor_shift (x y : M) :
    C.pred (C.monus x (C.succ y)) = C.monus x y := by
  exact (C.monus_succ x (C.succ y)).symm.trans (monus_shift C E G x y)

/-- Fourth exact instance: a selector-guarded subtraction reconstruction. -/
theorem reconstruction (x y : M) :
    C.cond (C.monus y x) (C.monus (C.monus x y) y) x = x := by
  let s : Term Sigma arity 2 :=
    .cond (.monus (.var 1) (.var 0))
      (.monus (.monus (.var 0) (.var 1)) (.var 1)) (.var 0)
  let t : Term Sigma arity 2 := .var 0
  have h := equation_induction C E G s t y
    (by
      change C.cond (C.monus y C.zero)
        (C.monus (C.monus C.zero y) y) C.zero = C.zero
      rw [C.monus_zero, monus_diagonal C E G]
      exact conditional_same C E G _ _)
    (by
      intro n hn
      change C.cond (C.monus y n) (C.monus (C.monus n y) y) n = n at hn
      change C.cond (C.monus y (C.succ n))
        (C.monus (C.monus (C.succ n) y) y) (C.succ n) = C.succ n
      rcases constructor_coverage C E G (C.monus y (C.succ n)) with hb | hb
      · have hb0 : C.monus y n = C.zero := by
          calc
            C.monus y n = C.pred (C.monus y (C.succ n)) :=
              (monus_predecessor_shift C E G y n).symm
            _ = C.pred C.zero := congrArg C.pred hb
            _ = C.zero := C.pred_zero
        have hi : C.monus (C.monus n y) y = n := by
          simpa only [hb0, C.cond_zero] using hn
        rcases constructor_coverage C E G (C.monus n y) with ha | ha
        · have hyn : y = n := by
            simpa only [ha, C.monus_zero] using hi
          have bad : C.succ C.zero = C.zero := by
            calc
              C.succ C.zero = C.monus n (C.succ n) :=
                (monus_adjacent C E G n).symm
              _ = C.monus y (C.succ n) := by rw [hyn]
              _ = C.zero := hb
          exact False.elim (C.separation bad.symm)
        · let r := C.pred (C.monus n y)
          let q := C.monus r y
          have har : C.monus n y = C.succ r := ha
          have hpq : C.pred q = n := by
            calc
              C.pred q = C.monus (C.succ r) y := (C.monus_succ r y).symm
              _ = C.monus (C.monus n y) y :=
                congrArg (fun z => C.monus z y) har.symm
              _ = n := hi
          have hq : q = C.succ n := by
            rcases constructor_coverage C E G q with hq0 | hqs
            · have hn0 : n = C.zero := by
                calc
                  n = C.pred q := hpq.symm
                  _ = C.pred C.zero := congrArg C.pred hq0
                  _ = C.zero := C.pred_zero
              have hyr : y = C.succ r := by
                calc
                  y = C.monus n y := by rw [hn0, C.monus_zero]
                  _ = C.succ r := har
              have hq1 : q = C.succ C.zero := by
                calc
                  q = C.monus r (C.succ r) := congrArg (C.monus r) hyr
                  _ = C.succ C.zero := monus_adjacent C E G r
              exact False.elim (C.separation (hq0.symm.trans hq1))
            · exact hqs.trans (congrArg C.succ hpq)
          have hnext : C.monus (C.succ n) y = r := C.monus_succ n y
          rw [hb, C.cond_zero, hnext]
          exact hq
      · rw [hb, C.cond_succ])
  exact h x

theorem error_correct (x y : M) : error C x y = C.zero ↔ x = y := by
  constructor
  · intro h
    rcases constructor_coverage C E G (C.monus x y) with ha | ha
    · have hb : C.monus y x = C.zero := by
        simpa only [error, ha, C.cond_zero] using h
      have hr := reconstruction C E G x y
      have hyx : y = x := by
        simpa only [hb, C.cond_zero, ha, C.monus_zero] using hr
      exact hyx.symm
    · have bad : C.succ C.zero = C.zero := by
        change C.cond (C.monus x y) (C.monus y x) (C.succ C.zero) = C.zero at h
        rw [ha, C.cond_succ] at h
        exact h
      exact False.elim (C.separation bad.symm)
  · intro h
    subst y
    simp only [error, monus_diagonal C E G, C.cond_zero]

theorem equality_cases (x y : M) : x = y ∨ x ≠ y := by
  rcases zero_cases C E G (error C x y) with h | h
  · exact Or.inl ((error_correct C E G x y).mp h)
  · exact Or.inr (fun he => h ((error_correct C E G x y).mpr he))

end Arithmetic

/-- Quantifier-free formulas include genuine intuitionistic implication. -/
inductive Formula (Sigma : Type u) (arity : Sigma → Nat) (n : Nat) : Type u where
  | equal : Term Sigma arity n → Term Sigma arity n → Formula Sigma arity n
  | truth : Formula Sigma arity n
  | falsehood : Formula Sigma arity n
  | conj : Formula Sigma arity n → Formula Sigma arity n → Formula Sigma arity n
  | disj : Formula Sigma arity n → Formula Sigma arity n → Formula Sigma arity n
  | impl : Formula Sigma arity n → Formula Sigma arity n → Formula Sigma arity n

def Formula.meaning (C : Core M) (E : Extra M Sigma arity) {n : Nat}
    (A : Formula Sigma arity n) (rho : Fin n → M) : Prop :=
  match A with
  | .equal s t => s.eval C E rho = t.eval C E rho
  | .truth => True
  | .falsehood => False
  | .conj A B => A.meaning C E rho ∧ B.meaning C E rho
  | .disj A B => A.meaning C E rho ∨ B.meaning C E rho
  | .impl A B => A.meaning C E rho → B.meaning C E rho

def Formula.compile {n : Nat} (A : Formula Sigma arity n) : Term Sigma arity n :=
  match A with
  | .equal s t => .cond (.monus s t) (.monus t s) (.succ .zero)
  | .truth => .zero
  | .falsehood => .succ .zero
  | .conj A B => .cond A.compile B.compile (.succ .zero)
  | .disj A B => .cond A.compile .zero B.compile
  | .impl A B => .cond A.compile B.compile .zero

def QFInduction (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (A : Formula Sigma arity 2) (a : M),
    A.meaning C E (env2 C.zero a) →
    (∀ x, A.meaning C E (env2 x a) →
      A.meaning C E (env2 (C.succ x) a)) →
    ∀ x, A.meaning C E (env2 x a)

section Compilation

variable (C : Core M) (E : Extra M Sigma arity) (G : Guarded C E)

include G

/-- Correctness for every finite variable context, proved constructively. -/
theorem compiler_correct {n : Nat} (A : Formula Sigma arity n)
    (rho : Fin n → M) :
    A.compile.eval C E rho = C.zero ↔ A.meaning C E rho := by
  induction A with
  | equal s t => exact error_correct C E G (s.eval C E rho) (t.eval C E rho)
  | truth => exact ⟨fun _ => True.intro, fun _ => rfl⟩
  | falsehood =>
      exact ⟨fun h => successor_nonzero C C.zero h, fun h => False.elim h⟩
  | conj A B ihA ihB =>
      change C.cond (A.compile.eval C E rho) (B.compile.eval C E rho)
        (C.succ C.zero) = C.zero ↔ (A.meaning C E rho ∧ B.meaning C E rho)
      rcases zero_cases C E G (A.compile.eval C E rho) with ha | ha
      · rw [ha, C.cond_zero]
        have hA := ihA.mp ha
        exact ⟨fun hb => ⟨hA, ihB.mp hb⟩, fun h => ihB.mpr h.2⟩
      · rw [conditional_nonzero C E G _ _ _ ha]
        have hnA : ¬ A.meaning C E rho := fun h => ha (ihA.mpr h)
        exact ⟨fun h => False.elim (successor_nonzero C C.zero h),
          fun h => False.elim (hnA h.1)⟩
  | disj A B ihA ihB =>
      change C.cond (A.compile.eval C E rho) C.zero (B.compile.eval C E rho) =
        C.zero ↔ (A.meaning C E rho ∨ B.meaning C E rho)
      rcases zero_cases C E G (A.compile.eval C E rho) with ha | ha
      · rw [ha, C.cond_zero]
        exact ⟨fun _ => Or.inl (ihA.mp ha), fun _ => rfl⟩
      · rw [conditional_nonzero C E G _ _ _ ha]
        constructor
        · intro hb
          exact Or.inr (ihB.mp hb)
        · intro h
          rcases h with hA | hB
          · exact False.elim (ha (ihA.mpr hA))
          · exact ihB.mpr hB
  | impl A B ihA ihB =>
      change C.cond (A.compile.eval C E rho) (B.compile.eval C E rho) C.zero =
        C.zero ↔ (A.meaning C E rho → B.meaning C E rho)
      rcases zero_cases C E G (A.compile.eval C E rho) with ha | ha
      · rw [ha, C.cond_zero]
        exact ⟨fun hb _ => ihB.mp hb, fun h => ihB.mpr (h (ihA.mp ha))⟩
      · rw [conditional_nonzero C E G _ _ _ ha]
        exact ⟨fun _ hA => False.elim (ha (ihA.mpr hA)), fun _ => rfl⟩

theorem formula_cases {n : Nat} (A : Formula Sigma arity n) (rho : Fin n → M) :
    A.meaning C E rho ∨ ¬ A.meaning C E rho := by
  rcases zero_cases C E G (A.compile.eval C E rho) with h | h
  · exact Or.inl ((compiler_correct C E G A rho).mp h)
  · exact Or.inr (fun hA => h ((compiler_correct C E G A rho).mpr hA))

/-- Induction transfer within exactly the certified one-parameter scope. -/
theorem quantifier_free_induction (A : Formula Sigma arity 2) (a : M)
    (base : A.meaning C E (env2 C.zero a))
    (step : ∀ x, A.meaning C E (env2 x a) →
      A.meaning C E (env2 (C.succ x) a)) :
    ∀ x, A.meaning C E (env2 x a) := by
  have h := equation_induction C E G A.compile .zero a
    ((compiler_correct C E G A (env2 C.zero a)).mpr base)
    (by
      intro x hx
      exact (compiler_correct C E G A (env2 (C.succ x) a)).mpr
        (step x ((compiler_correct C E G A (env2 x a)).mp hx)))
  intro x
  exact (compiler_correct C E G A (env2 x a)).mp (h x)

end Compilation

/-- Exact equivalence of the two one-parameter induction schemes. -/
theorem guarded_iff_quantifier_free (C : Core M) (E : Extra M Sigma arity) :
    Guarded C E ↔ QFInduction C E := by
  constructor
  · intro G A a base step
    exact quantifier_free_induction C E G A a base step
  · intro I s t a step
    let A : Formula Sigma arity 2 := .disj (.equal (.var 0) .zero) (.equal s t)
    have h := I A a (Or.inl rfl) (by
      intro x hx
      exact Or.inr (step x hx))
    exact h

#print axioms constructor_coverage
#print axioms error_correct
#print axioms compiler_correct
#print axioms quantifier_free_induction
#print axioms guarded_iff_quantifier_free

end ThreeHelperPRA
