LEAN CERTIFICATE
================
Version checked: Lean 4.19.0 (commit 6caaee842e94), no Mathlib.

ThreeHelperPRA.lean is copied unchanged from:
  docs/drafts/pra_simplification_2026-10-31.zip
at ProveIt commit:
  487040529a8792ae3239ae75e695424aee3d665c
The archive's source_audit.json records the original ZIP hash.

GuardedSuccessor.lean imports that module and verifies the new schema Y.

RawCore has computation operations and their displayed defining equations;
it has no separation axiom. raw_separation derives zero != successor zero
from the constant-zero Y instance. Coverage is then obtained from the
identity/predecessor instance. The direct transfer uses the syntactic term
  r(n,a) = c(n,0,S(s(n,a)))
and u(n,a)=t(n,a) to recover the previous guarded schema.

Term and Formula are actual inductive syntax with an explicit finite
variable context. Schema instances in this certificate have two available
variables: the induction variable and one fixed numerical parameter.

Certified:
  - separation from the raw schema;
  - positive predecessor coverage;
  - Y implies the guarded-equation schema;
  - constructive comparison and formula compilation via the credited module;
  - equivalence of Y and one-parameter quantifier-free induction;
  - transfer from RawCore to that equivalence.

Not formalized here:
  - the direct binary-recursion bootstrap using the fresh R in the paper;
  - the construction of the selector from binary symbols;
  - pairing and arbitrary parameter lists;
  - translation of all first-order derivations;
  - the infinite two-copy countermodel.

These remaining statements have mathematical proofs in the PDF.
The selector equations used in the certificate are justified by the paper,
not added as primitives to its advertised binary axiomatization.

Run the parent directory's check.sh. Recorded results are in verification.txt.
The imported module's five audit theorems depend on propext.
The new raw_separation uses no axioms. Most new theorems use propext;
raw_y_quantifier_free also uses Quot.sound through function extensionality.
No theorem in the audit uses sorryAx or Classical.choice.

