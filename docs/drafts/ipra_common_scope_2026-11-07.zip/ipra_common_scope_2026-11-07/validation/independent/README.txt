Independent audit of uniform dummy scopes and ordered atoms

Run from any current directory:
  python3 validation/independent/audit_uniform_semantics.py
when the command path is relative to the package root, or use an absolute
path to this script. All input/output defaults resolve relative to the
package, independently of the current working directory.

Optional explicit paths, in order:
  python3 audit_uniform_semantics.py CHECKER.py POSITIVE_CERTIFICATES.json OUT.json

The result is written to results/independent_semantics.json and records the
exact checker source SHA-256. The audit runs the existing fixed scope:
15,000 independent opener comparisons; every positive fixture; independent
numerical evaluation of their accepted closed root equations; 30,000 random
computation-schema attempts targeting dummy-scope erasure; and ten focused
scope/nonfinite counterexamples. The pseudorandom seed is fixed. Resource
limits in the numerical decoder are explicitly recorded; they are not
counted as successful semantic evaluations.

The two support files are not part of the trusted acceptance program.
The oracle uses explicit sorted recursion and named rules. The mathematical
numerical evaluator is separate and does not call the production opener.
The schema generator uses the production opener to propose right sides, then
both acceptance and independently decoded numerical equality are checked.
This last experiment is a consistency cross-check, not a formal proof of
soundness for all terms. The paper supplies that proof separately.

ATTRIBUTION.txt identifies the adapted oracle and its inherited license.
