# Reproducing the implementation evidence

Run from the package root with Python 3.12:

```sh
python measure.py
python validation/validate.py
python validation/direct_validate.py
python validation/empty_completion.py
```

`checker.py` is the primary direct-recursion checker.
`checker_scalar.py` is the smaller scalar-iteration companion. Both programs
read a JSON packet from the filename passed as the first argument.

`validate.py` runs the scalar certificate corpus, randomized packet and
substitution checks, independent denotational checks, false-conclusion probes,
and normal/optimized command-line tests. `direct_validate.py` repeats the
applicable checks for direct primitive recursion, adds explicit simultaneous
substitution comparisons, and checks two deliberately incorrect mutants.
`empty_completion.py` tests the newly admitted empty-array constructors at
each semantic position, nested direct opening with empties, rejection of
binary numerical constructors and nonlist objects, and public predecessor
and empty-array examples.

The independent oracle, validation architecture, and positive certificate
corpora are adapted from the pinned upstream uniform-scopes draft; source
provenance remains in the fixtures and attribution files. The common-scope
changes add empty-array cases to that oracle and evaluator, and adapt checker
filenames. The acceptance programs import no validation code.

The receipts in `results/` identify the exact program hashes tested. These are
finite implementation checks, not machine-checked metatheory proofs.
