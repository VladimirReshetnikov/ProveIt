#!/usr/bin/env python3
"""Focused tests for nullary completion and the common scope table.

These are finite implementation checks, not a formal proof. The structural
oracle and explicit simultaneous opening do not share the production table.
"""
from copy import deepcopy
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

from validate import ROOT, SEED, digest, load_checker, numerical_tree, numerical_value, save, trace
from oracle_uniform import Oracle
from direct_validate import simultaneous


def numeral(n):
    value = 0
    for _ in range(n):
        value = [value]
    return value


def empty_zeros(value, rng):
    if isinstance(value, list):
        return [empty_zeros(child, rng) for child in value]
    return [] if value == 0 and rng.randrange(2) else value


def outcome(fn):
    try:
        return ('value', fn())
    except Exception:
        return ('error', None)


def main():
    modules = {name: load_checker(ROOT/name) for name in ('checker.py', 'checker_scalar.py')}
    failures = []
    counts = {'typed_openings': 0, 'malformed_numerical_positions': 0,
              'nonlist_rejections': 0, 'staged_empty_openings': 0,
              'staged_empty_denotations': 0, 'explicit_packets': 0, 'public_invocations': 0}
    typed = [
        ('formula_truth', [], None, 0),
        ('formula_closure_matrix', [[]], None, 0),
        ('formula_paired_components', [[], [], []], None, 0),
        ('formula_equality_sides', [[], []], None, 0),
        ('numeric_zero', [], None, 1),
        ('numeric_successor_argument', [[]], None, 1),
        ('numeric_all_recursor_children', [[], [], []], None, 1),
        ('numeric_count', [[], [0], 1], None, 1),
        ('numeric_seed', [[0], [], 1], None, 1),
        ('numeric_update', [[0], [0], []], None, 1),
        ('numeric_nested_positions', [[[], [], []]], None, 1),
        ('used_image', 1, [], 1),
        ('used_image_below_successor', [3], [], 1),
        ('used_image_below_recursion', [5, 5, 5], [], 1),
        ('unused_malformed_image', [], 'x', 1),
        ('unused_malformed_formula_image', [], 'x', 0),
    ]
    malformed = [
        [0, 0], [[0, 0]], [[0, 0], 0, 0], [0, [0, 0], 0],
        [0, 0, [0, 0]], [0, 0, [[0, 0]]], [0, [0, 0, [0, 0]], 0],
    ]
    nonlists = ['', 'x', 'xx', {}, {'': 0}, {'x': []}, None]
    for name, module in modules.items():
        for label, value, image, depth in typed:
            module.k = 0
            oracle = Oracle()
            formula = depth % 2 == 0
            protected = depth // 2
            expected = outcome(lambda: (oracle.formula if formula else oracle.term)(value, image, protected))
            actual = outcome(lambda: module.inst(value, image, depth))
            counts['typed_openings'] += 1
            if actual != expected or actual[0] == 'error':
                failures.append([name, label, repr(actual), repr(expected)])
        for value in malformed:
            module.k = 0
            counts['malformed_numerical_positions'] += 1
            if outcome(lambda: module.inst(value, d=1))[0] != 'error':
                failures.append([name, 'binary numerical node accepted', repr(value)])
        for value in nonlists:
            for depth in (0, 1):
                module.k = 0
                counts['nonlist_rejections'] += 1
                if outcome(lambda: module.inst(value, d=depth))[0] != 'error':
                    failures.append([name, 'nonlist accepted', repr(value), depth])
    direct = modules['checker.py']
    rng = random.Random(SEED + 901)
    for index in range(1000):
        counter = empty_zeros(numerical_tree(rng, 2, 0), rng)
        state = empty_zeros(numerical_tree(rng, 2, 0), rng)
        body = empty_zeros(numerical_tree(rng, 3, 2), rng)
        direct.k = 0
        try:
            staged = direct.inst(direct.inst(body, counter, 3), state, 1)
            parallel = simultaneous(body, state, counter)
            counts['staged_empty_openings'] += 1
            if staged != parallel:
                failures.append(['staged empty opening', index, repr(staged), repr(parallel)])
            expected = numerical_value(body, (numerical_value(state, width=2), numerical_value(counter, width=2)), width=2)
            actual = numerical_value(staged, width=2)
            counts['staged_empty_denotations'] += 1
            if expected != actual:
                failures.append(['staged empty denotation', index, expected, actual])
        except OverflowError:
            pass
        except Exception as exc:
            failures.append(['staged empty exception', index, type(exc).__name__])
    examples = [
        ('predecessor_three.json', [[], [[numeral(3), 0, 3], numeral(2)]], True, 'Direct primitive recursion computes predecessor(3)=2.'),
        ('empty_recursion_zero.json', [[], [[[], [], []], []]], True, 'Empty arrays in count, seed, update, and equality right side denote zero.'),
        ('empty_recursion_successor.json', [[], [[[[]], [], []], []]], True, 'A successor of empty zero with empty update computes empty zero.'),
        ('empty_truth_introduction.json', [0, [[], [], []]], True, 'Primitive introduction with an empty truth matrix.'),
        ('empty_reject_false.json', [[], [[[], [], []], [[]]]], False, 'Reject zero equals successor of empty zero.'),
        ('empty_reject_binary_update.json', [[], [[[], [], [[], []]], []]], False, 'Reject a binary numerical update even when count is zero.'),
        ('empty_reject_object.json', [[], [[{'': 0}, [], []], []]], False, 'Reject a nonlist object with an empty-string key.'),
        ('empty_reject_string.json', [[], [["x", [], []], []]], False, 'Reject a single-character string without traversing its characters.'),
    ]
    public_index = []
    for filename, packet, expected, description in examples:
        path = ROOT/'examples'/filename
        save(path, packet)
        actual = trace(direct, packet)[0]
        oracle = Oracle(2).run(packet)['accepted']
        counts['explicit_packets'] += 1
        if actual != expected or oracle != expected:
            failures.append([filename, expected, actual, oracle])
        for options in ([], ['-O']):
            result = subprocess.run([sys.executable, *options, str(ROOT/'checker.py'), str(path)], capture_output=True, text=True, timeout=10)
            counts['public_invocations'] += 1
            wanted = ('ACCEPT\n', 0) if expected else ('REJECT\n', 1)
            if (result.stdout, result.returncode) != wanted:
                failures.append([filename, options, result.stdout, result.returncode, result.stderr])
        public_index.append({'file': filename, 'expected': expected, 'description': description, 'sha256': digest(path)})
    save(ROOT/'examples/common_scope_index.json', public_index)
    receipt = {'status': 'PASS' if not failures else 'FAIL', 'counts': counts, 'failures': failures,
               'checker_sha256': {name: digest(ROOT/name) for name in modules}, 'runner_sha256': digest(Path(__file__)),
               'note': 'Finite tests support the implementation; they do not establish the metatheory.'}
    save(ROOT/'results/empty_completion.json', receipt)
    print(json.dumps(receipt, indent=2))
    if failures:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
