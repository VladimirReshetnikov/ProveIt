"""Measure the complete programs and identical-driver controls reproducibly."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('source_measure', ROOT/'comparison/source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
DRIVER = '''try:
    take = json.load(open(sys.argv[1])).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
'''
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def common_driver_metrics(path):
    tree = ast.parse(path.read_text())
    assert isinstance(tree.body[-1], ast.Try)
    tree.body[-1] = ast.parse(DRIVER).body[0]
    with tempfile.TemporaryDirectory() as tmp:
        common = Path(tmp)/'checker.py'
        common.write_text(ast.unparse(tree)+'\n')
        return measure.metrics(common)


def main():
    manifest = json.loads((ROOT/'comparison/manifest.json').read_text())
    rows = []
    for row in manifest['programs']:
        path = ROOT/'comparison'/row['file']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        rows.append({**row, 'delivered':measure.metrics(path),
                     'common_filename_driver':common_driver_metrics(path)})
    minima = {mode:{field:min(row[mode][field] for row in rows) for field in FIELDS}
              for mode in ('delivered','common_filename_driver')}
    candidates = []
    for name in ('checker.py','checker_scalar.py'):
        path = ROOT/name
        item = {'file':name, 'delivered':measure.metrics(path),
                'common_filename_driver':common_driver_metrics(path)}
        item['strict_improvement'] = {
            mode:{field:item[mode][field] < minima[mode][field] for field in FIELDS}
            for mode in minima}
        candidates.append(item)
    result = {'python_version':platform.python_version(),
              'python_implementation':platform.python_implementation(),
              'normalizer_sha256':hashlib.sha256((ROOT/'comparison/source_measure.py').read_bytes()).hexdigest(),
              'repository':manifest['repository'],'commit':manifest['commit'],
              'root_program_count':len(rows),'archive_count':len(set(r['archive'] for r in rows)),
              'coordinatewise_minima':minima,'candidates':candidates,'baselines':rows}
    (ROOT/'results/measurements.json').write_text(json.dumps(result,indent=2)+'\n')
    if not all(all(item['strict_improvement']['delivered'].values()) for item in candidates):
        raise ValueError('A delivered candidate does not strictly improve all three current minima')
    scalar = next(item for item in candidates if item['file'] == 'checker_scalar.py')
    if not all(scalar['strict_improvement']['common_filename_driver'].values()):
        raise ValueError('Scalar identical-driver improvement was lost')
    macros = {}
    for item in candidates:
        prefix = 'Direct' if item['file'] == 'checker.py' else 'Scalar'
        for mode, suffix in [('delivered',''),('common_filename_driver','Common')]:
            for field, label in zip(FIELDS, ('Tokens','AST','Bytes')):
                macros[prefix+suffix+label] = item[mode][field]
    for field,label in zip(FIELDS, ('Tokens','AST','Bytes')):
        macros['Baseline'+label] = minima['delivered'][field]
    (ROOT/'results/numbers.tex').write_text(''.join(
        '\\newcommand{\\'+name+'}{'+str(value)+'}\n' for name,value in macros.items()))
    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Program & Tokens & AST nodes & Norm. bytes \\', r'\midrule']
    for item in rows:
        label = item['archive'].removeprefix('ipra_').replace('_2026-11-07.zip','')
        label += '/' + Path(item['member']).name
        values = [label.replace('_',r'\_')] + [str(item['delivered'][field]) for field in FIELDS]
        lines.append(' & '.join(values)+r'\\')
    lines.append(r'\midrule')
    for item in candidates:
        values = [item['file'].replace('_',r'\_')] + [str(item['delivered'][field]) for field in FIELDS]
        lines.append(' & '.join(values)+r'\\')
    lines += [r'\bottomrule', r'\end{tabular}']
    (ROOT/'results/main_table.tex').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='baselines'},indent=2))

if __name__ == '__main__':
    main()
