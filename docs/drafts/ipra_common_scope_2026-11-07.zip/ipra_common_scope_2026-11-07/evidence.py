"""Check that measurements and finite-validation receipts name the shipped code."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()


def main():
    measurements = json.loads((ROOT/'results/measurements.json').read_text())
    snapshot = json.loads((ROOT/'source_snapshot.json').read_text())
    if measurements['commit'] != snapshot['commit']:
        raise ValueError('Comparison and source snapshot use different commits')
    for entry in measurements['candidates']:
        if entry['delivered']['sha256'] != digest(entry['file']):
            raise ValueError('Measurement does not identify current checker')
    for filename in ('direct_validation.json','validation.json'):
        receipt = json.loads((ROOT/'results'/filename).read_text())
        if receipt['status'] != 'PASS' or receipt['failures']:
            raise ValueError('Validation failed: '+filename)
        checker = receipt['checker']
        if checker['sha256'] != digest(checker['path']):
            raise ValueError('Validation names a different checker: '+filename)
        fixture = receipt['fixture']
        if fixture['sha256'] != digest(fixture['path']):
            raise ValueError('Validation fixture has changed: '+filename)
        if receipt['oracle_sha256'] != digest('validation/oracle_uniform.py'):
            raise ValueError('Oracle changed after validation')
        if receipt['runner_sha256'] != digest('validation/validate.py'):
            raise ValueError('Shared validation runner changed')
        if 'direct_runner_sha256' in receipt and receipt['direct_runner_sha256'] != digest('validation/direct_validate.py'):
            raise ValueError('Direct runner changed')
    empty = json.loads((ROOT/'results/empty_completion.json').read_text())
    if empty['status'] != 'PASS' or empty['failures']:
        raise ValueError('Empty completion audit failed')
    for name, value in empty['checker_sha256'].items():
        if value != digest(name):
            raise ValueError('Empty completion receipt names a different checker')
    if empty['runner_sha256'] != digest('validation/empty_completion.py'):
        raise ValueError('Empty completion runner changed')
    result = {'status':'PASS','commit':snapshot['commit'],
              'checkers':{name:digest(name) for name in ('checker.py','checker_scalar.py')},
              'claims':'Exact source and receipt linkage; not a formal proof of metatheory.'}
    (ROOT/'results/evidence.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
