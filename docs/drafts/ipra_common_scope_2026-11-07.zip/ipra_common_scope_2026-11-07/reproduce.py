"""Reproduce measurements and validation offline, retaining each run log."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for relative in ('measure.py','validation/direct_validate.py',
                     'validation/validate.py','validation/empty_completion.py','evidence.py'):
        run = subprocess.run([sys.executable,str(ROOT/relative)],cwd=ROOT,
                             capture_output=True,text=True)
        name = relative.replace('/','__').replace('.py','.log')
        (ROOT/'results'/('reproduce_'+name)).write_text(run.stdout+run.stderr)
        if run.returncode:
            print(run.stdout[-10000:]+run.stderr[-3000:])
            raise SystemExit('FAILED: '+relative)
        print('PASS: '+relative,flush=True)


if __name__ == '__main__':
    main()
