ONE SCOPE PER CONSTRUCTOR: SMALLER CHECKED PRESENTATIONS OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
============================================================

START HERE

report.pdf contains the complete paper. report.tex, sections/, appendices/,
and results/*.tex contain all editable LaTeX sources.

RESULT

The six current draft archives at ProveIt commit
df8beb801d9f3e3eb3a8141722953fb58e63009e contain eleven root checker programs.
Their complete-source coordinate minima, and the new complete programs, are:

                              normalized tokens   AST nodes   normalized bytes
Current coordinate minima:                  356         378               1038
checker_scalar.py (scalar):                 348         369               1009
checker.py (direct recursion):              355         375               1021

The scalar profile is the smallest delivered implementation. The direct profile
has a shorter arithmetic proof: predecessor and the ordinary primitive-recursive
compiler follow immediately, without the scalar pairing bootstrap.

When every checker receives exactly the same filename input/output driver:

Current coordinate minima:                  356         378               1038
Scalar:                                     349         371               1001
Direct:                                     356         377               1013

The scalar improvement survives in all three coordinates. The direct program
ties the token minimum under that control; its strict delivered token reduction
also uses raise SystemExit(1) instead of sys.exit(1). This is disclosed in the
paper, not attributed to scope factoring.

The measure is inherited unchanged from the current corpus, excludes genuine
docstrings, and uses ast.unparse on the entire source. CPython 3.12.14 was used.
Raw sizes and hashes are recorded separately. The standard Python runtime,
json, and sys are the only runtime dependencies of either checker.

CONTRIBUTION AND LIMITS

The new opener uses one scope increment per constructor instead of a vector
of per-child increments and zip. Empty arrays have the conservative numerical
zero / formula truth interpretation credited to the pairing draft. All remaining
mathematical machinery, including the two computation schemas, five logical
patterns, uniform dummy scopes, interval coordinates, and scalar bootstrap,
has explicitly credited predecessors in the supplied drafts.

Both presentations are proved bi-interpretable and equiconsistent with full
first-order intuitionistic primitive recursive arithmetic. Their ordinary
interpretations use the entire numerical domain and have identity composites.
The paper states all primitive schemas, rules, and freshness restrictions,
derives the logical connectives, and gives the exact certificate soundness
argument. It includes a Further research questions section.

This is a strict finite-corpus implementation improvement. It is not a global
minimality theorem or a new arithmetic axiom basis. The universal metatheory
is a written proof, not a Lean/Rocq formalization. Finite executable tests are
reported as implementation evidence, with their limitations and one direct
semantic-evaluator budget skip disclosed.

RUN AND REPRODUCE

  python3 checker.py examples/predecessor_three.json
  python3 checker_scalar.py examples/zero.json
  python3 reproduce.py
  python3 build.py

Use Python 3.10 or later to run the programs; use the recorded Python version
for exact normalized-metric reproduction. Rebuilding the PDF requires pdfLaTeX
and the packages declared in report.tex. The build downloads nothing.

Each checker reads a JSON array from the named file. ACCEPT exits zero;
REJECT exits one. The two profiles give different meanings to update slots.
Do not interchange their certificate corpora. FORMAT.txt specifies the syntax.

The offline reproduction runs both profiles against a separate named-rule
oracle, checks malformed packets, opening semantics, the direct two-stage
substitution, wrong-implementation controls, and the public command-line
boundary under normal and optimized Python. It then checks exact source-hash
agreement between the measurements and validation receipts.

CONTENTS

  report.tex / report.pdf       Full paper and compiled version
  sections/ / appendices/       Mathematical source, including scalar bootstrap
  checker.py                   Complete trusted direct-recursion program
  checker_scalar.py            Complete trusted scalar-iteration program
  FORMAT.txt                   Raw syntax, scope and instruction conventions
  examples/                    Positive and negative public packets
  validation/                  Independent oracle, fixtures and validation code
  comparison/baselines/        Eleven unchanged current comparator programs
  comparison/source_measure.py Unchanged inherited normalization metric
  results/                     Measurements, validation and build receipts
  source_snapshot.json         Pinned archive hashes and Git blob identities
  reproduce.py / measure.py    Offline validation and measurement entry points
  evidence.py / build.py        Receipt linkage and PDF build
  package.py / SHA256SUMS.txt   Repackaging and integrity information
  ATTRIBUTION.txt              New/inherited contribution boundaries
  LICENSE-inherited.txt        Preserved inherited license
