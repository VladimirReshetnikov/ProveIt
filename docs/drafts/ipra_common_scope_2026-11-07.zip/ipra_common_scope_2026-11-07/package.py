"""Create a reproducible-layout ZIP and a manifest of the delivered file bytes."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts
                  and p.suffix not in ('.pyc','.aux','.toc','.out')
                  and p.name != 'SHA256SUMS.txt')


def main():
    entries = files()
    manifest = ''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+
                       p.relative_to(ROOT).as_posix()+'\n' for p in entries)
    (ROOT/'SHA256SUMS.txt').write_text(manifest)
    entries = sorted(entries+[ROOT/'SHA256SUMS.txt'])
    output = ROOT.parent/(ROOT.name+'.zip')
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in entries:
            name = ROOT.name+'/'+path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name,date_time=(2026,11,7,12,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info,path.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP integrity check failed')
    print(output)
    print('files:',len(entries),'bytes:',output.stat().st_size)
    print('sha256:',hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
