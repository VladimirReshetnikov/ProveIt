"""Package the report, proofs, programs, references, and evidence with hashes."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
BUILD_SUFFIXES = {".aux", ".fdb_latexmk", ".fls", ".log", ".out", ".toc", ".pyc"}


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and "__pycache__" not in relative.parts
            and path.suffix not in BUILD_SUFFIXES
            and relative.as_posix() != "MANIFEST.json")


def main():
    files = sorted(p for p in ROOT.rglob("*") if included(p))
    records = [{"file": p.relative_to(ROOT).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
               for p in files]
    manifest = ROOT / "MANIFEST.json"
    manifest.write_text(json.dumps({
        "package": ROOT.name,
        "source_commit": "572c3ef372fb22e30951af30bf1041efcffc8b7d",
        "qualification": "The manifest excludes itself and generated build residue.",
        "files": records,
    }, indent=2) + "\n")
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as bundle:
        for path in sorted(files + [manifest]):
            name = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(archive) as bundle:
        if bundle.testzip() is not None:
            raise RuntimeError("Archive integrity check failed")
        for record in records:
            data = bundle.read(ROOT.name + "/" + record["file"])
            if hashlib.sha256(data).hexdigest() != record["sha256"]:
                raise RuntimeError("Archive content differs from manifest")
        for name in ("report.tex", "report.pdf", "appendix_arithmetic.tex",
                     "appendix_countdown.tex", "code/forward_left_checker.py",
                     "code/neutral_formula_checker.py"):
            bundle.getinfo(ROOT.name + "/" + name)
    pdf = ROOT.parent / (ROOT.name + ".pdf")
    shutil.copy2(ROOT / "report.pdf", pdf)
    print(json.dumps({"archive": str(archive), "archive_bytes": archive.stat().st_size,
                      "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                      "pdf": str(pdf), "pdf_bytes": pdf.stat().st_size,
                      "pdf_sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
                      "manifest_files": len(records), "integrity": "passed"}, indent=2))


if __name__ == "__main__":
    main()
