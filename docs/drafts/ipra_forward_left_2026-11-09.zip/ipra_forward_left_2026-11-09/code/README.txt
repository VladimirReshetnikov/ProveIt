VACUOUS CLOSURES AND FORWARD-LEFT REWRITING
========================================

Run the commands in this file from the code/ directory. The package-root
reproduce.py instead runs both verification suites from any working directory.

The linear theorem comes first
------------------------------
Before restricting the motive to a left term, vacuous closures give a
particularly short transformation from unrestricted formula transport to
forward transport whose only immediate source is a direct clause Use.
If a source proof has N inference nodes and T transport nodes, the translated
proof has exactly N + 5*T nodes. Each translated child proof is inserted
once. This is a linear INFERENCE-NODE bound, not a serialized-byte or
compiler-runtime bound.

neutral_formula_checker.py is an independent standalone complete target
checker with exactly comp, use, di, de, and nr proof tags. It has no
reference modes. neutral_formula_compiler.py is the untrusted producer.
verify_neutral.py runs eight complete source examples (the ninth inherited
example already uses local RW and lies outside the exact source grammar),
checks the exact node relation, replays outputs in ordinary and optimized
Python, and rejects eight malformed controls. The receipt is in
evidence/neutral_verification.json. Reproduce with:

  python3 verify_neutral.py
  python3 neutral_formula_checker.py < examples_neutral/compound_depth_3.json

The further forward-left transformation below is a separate theorem and
does not carry the linear bound.

Mathematical result
-------------------
In the supplied native D/clause calculus, DI proves D_{x,y}A whenever x,y
are unused in A: its successor goal is its retained base A.  DE on this
theorem opens the identity clause <A;y.A>.  Thus any checked proof of an
equation E can be its antecedent, producing a direct clause Use of E.

Consequently the local equality rule needs only:
  - a direct clause Use as its source, with a checked antecedent proof;
  - the forward orientation of that source;
  - rewriting the left side of an equation;
  - one path through actual numerical term arguments.

Computation is still a primitive equation proof. It need not be a permitted
direct rewrite source. Reflexivity, symmetry, right-side rewriting, backward
rewriting, and all-formula transport are derived. proof_note.tex gives the
full finite-derivation proof, including the shifted K variant's reflexivity
bootstrap and freshness conditions. This is a proof-presentation change,
not a different numerical domain, and preserves the existing bi-interpretation.

Files
-----
forward_left_checker.py is standalone: only the standard json module is
imported. It implements the same full-PR declaration grammar and clause
calculus as the inherited readable local checker. The command-line interface
always checks the new calculus. Its Python-only reference modes are retained
and charged in the matched size comparison; certificate data cannot enable
them. The public interface reads a JSON object on stdin and prints ACCEPT
or REJECT, with exit status 0 or 1.

The rw proof object has exactly these fields:
  rule, conclusion, before, source, path
The source must itself be a Use node concluding an equation. The before
proof must conclude an equation. path is a list of nonnegative integer
argument indices (the function-symbol head is not an argument). The empty
path selects the complete LEFT side. Always rewrite the left endpoint of
the source equation to its right endpoint. All other declarations, formulas,
proof objects and scope checks are as in the preserved reference checker.

forward_compiler.py is an untrusted proof producer. The first stage imports
the attributed reference formula-to-atomic transport conversion; the new
second stage boxes equalities with vacuous D binders and builds only
forward-left rewrites. The standalone checker validates every output and
never imports this producer or its reference dependencies.

Reproduction
------------
  python3 verify_forward.py
  python3 forward_left_checker.py < examples/compound_depth_3.json
  python3 forward_compiler.py reference/examples/reflexivity.json /tmp/proof.json

The verification receipt includes all nine inherited reference examples,
including compound formula motives, repeated occurrences, and induction
continuations; each generated proof is checked by the standalone CLI in
ordinary and optimized Python. Twelve malformed controls test the removed
fields, direct computation sources, bad paths, missing antecedents, malformed
scope, forged conclusions, and attempts to enable a reference mode.

Size and limitation
-------------------
Using the inherited whole-source normalizer, the matched readable baseline
is 3287 normalized tokens, 3650 AST nodes, and 16192 normalized bytes.
The new checker is 3218 tokens, 3562 AST nodes, and 15789 bytes: reductions
of 69 tokens, 88 nodes, and 403 bytes. The smaller complete native checkers
in other current drafts remain much smaller. No global-frontier or absolute
minimality claim is made.

The compact_left_prototype.py file in evidence is only a rejected size
experiment. Adapting the existing 306-token compact kernel to left-term
motives produced 316/352/889, because its existing closure/equality dispatch
already shares whole-formula substitution. It is not a verified candidate.

The new proof inserts DI-DE redexes; it is not a cut-free normalization.
It can enlarge certificates substantially. The finite tests do not prove
the general derivation transformation or the iPRA interpretation theorem;
those are written mathematical arguments.

Attribution
-----------
The reference local_checker.py, producer.py, source_measure.py, and the
nine reference examples are unchanged copies from ProveIt/docs/drafts/
ipra_local_rewriting_2026-11-09.zip, pinned repository commit
572c3ef372fb22e30951af30bf1041efcffc8b7d. The preserved inherited license
is reference/LICENSE-inherited.txt. forward_left_checker.py is a derivative
with exactly the rewrite-source, orientation, and side restrictions changed.
The new contribution is vacuous-clause access and its use to remove those
three primitive choices, together with the new second-stage proof compiler.
No historical-priority claim beyond the inspected draft corpus is made.
