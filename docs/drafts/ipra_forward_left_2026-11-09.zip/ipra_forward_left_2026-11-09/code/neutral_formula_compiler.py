"""Untrusted linear-node translation to forward clause-only formula transport.

Every source transport node becomes exactly six target inference nodes.
Subproofs are inserted once each. The resulting packet is checked by the
standalone neutral_formula_checker.py, which has no reference modes.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent / "reference"))
import local_checker as R
import producer as P
import neutral_formula_checker as N


def counts(proof):
    total, transports = 1, int(proof["rule"] in ("tr", "nr"))
    for key in ("premise", "major", "equality", "before", "source"):
        if key in proof:
            a, b = counts(proof[key])
            total += a
            transports += b
    return total, transports


def target_tags(proof):
    out = copy.deepcopy(proof)
    if out["rule"] == "tr":
        out["rule"] = "nr"
    for key in ("premise", "major", "equality", "before", "source"):
        if key in out:
            out[key] = target_tags(out[key])
    return out


class NeutralCompiler(P.Normalizer):
    def identity_box(self, equation, context):
        self.fresh.reserve(equation, context)
        x, y, z = (self.fresh.name(prefix) for prefix in ("_cx", "_cy", "_cz"))
        result = {
            "rule": "di", "conclusion": ["D", x, y, copy.deepcopy(equation)],
            "witness": P.ZERO, "eigen": z,
        }
        result["premise"] = P.ordinary(P.di_context(result, context), len(context))
        return result

    def translate(self, proof, context):
        out = copy.deepcopy(proof)
        rule = proof["rule"]
        if rule == "comp":
            return out
        if rule == "use":
            out["premise"] = self.translate(proof["premise"], context)
        elif rule == "di":
            out["premise"] = self.translate(proof["premise"], P.di_context(proof, context))
        elif rule == "de":
            out["major"] = self.translate(proof["major"], context)
            out["premise"] = self.translate(proof["premise"], P.de_context(proof, context))
        elif rule == "tr":
            equality = self.translate(proof["equality"], context)
            before = self.translate(proof["before"], context)
            equation = equality["conclusion"]
            major = self.identity_box(equation, context)
            a = self.fresh.name("_ca")
            lifted_equality = self.weaken(equality, len(context), 1)
            lifted_before = self.weaken(before, len(context), 1)
            access = {
                "rule": "use", "conclusion": copy.deepcopy(equation),
                "clause": len(context), "term": P.ZERO, "premise": lifted_equality,
            }
            step = {
                "rule": "tr", "conclusion": copy.deepcopy(proof["conclusion"]),
                "equality": access, "before": lifted_before,
                "variable": proof["variable"], "motive": copy.deepcopy(proof["motive"]),
            }
            out = {
                "rule": "de", "conclusion": copy.deepcopy(proof["conclusion"]),
                "major": major, "eigen": a, "premise": step,
            }
        else:
            raise ValueError("Source must use only computation, Use, DI, DE, and Tr")
        return out


def compile_packet(packet):
    source_stats = R.check_packet(packet, mode="general")
    n = NeutralCompiler(packet)
    original = n.freshen(packet["proof"])
    source_nodes, transport_nodes = counts(original)
    result = {**copy.deepcopy(packet), "proof": target_tags(n.translate(original, []))}
    target_stats = N.check_packet(result)
    target_nodes, neutral_nodes = counts(result["proof"])
    if target_nodes != source_nodes + 5 * transport_nodes or neutral_nodes != transport_nodes:
        raise ValueError("The exact inference-node relation failed")
    return result, {
        "source": source_stats, "target": target_stats,
        "N": source_nodes, "T": transport_nodes, "N_prime": target_nodes,
        "exact_relation": "N_prime = N + 5*T", "neutral_nodes": neutral_nodes,
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output, stats = compile_packet(json.loads(args.source.read_text()))
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(stats, indent=2))
