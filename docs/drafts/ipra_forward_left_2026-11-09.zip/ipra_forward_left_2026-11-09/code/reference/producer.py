"""Proof transformations for the complete native local-equality calculus.

This is an untrusted producer.  local_checker.py independently checks its
input (reference mode), intermediate atomic proof, and local output.  The
public local verifier never imports or executes this module.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

import local_checker as L


ZERO = ["0"]
H = ["=", ["id", ZERO], ZERO]


def var(name):
    return ["$", name]


def succ(term):
    return ["S", term]


def eq(left, right):
    return ["=", left, right]


def sub(formula, replacements):
    return L.subst_formula(formula, replacements)


def term_sub(term, replacements):
    if term[0] == "$":
        return copy.deepcopy(replacements.get(term[1], term))
    return [term[0], *(term_sub(t, replacements) for t in term[1:])]


def strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, (list, tuple)):
        for value in obj:
            yield from strings(value)
    elif isinstance(obj, dict):
        for value in obj.values():
            yield from strings(value)


class Fresh:
    def __init__(self, *objects):
        self.used = set(strings(objects))
        self.counter = 0

    def reserve(self, *objects):
        self.used.update(strings(objects))

    def name(self, prefix="_n"):
        while True:
            name = f"{prefix}{self.counter}"
            self.counter += 1
            if name not in self.used:
                self.used.add(name)
                return name


def comp(left, right):
    return {"rule": "comp", "conclusion": eq(left, right)}


def h_proof():
    return comp(["id", ZERO], ZERO)


def use(context, index, term, premise):
    _, binder, body = context[index]
    return {
        "rule": "use", "conclusion": sub(body, {binder: term}),
        "clause": index, "term": copy.deepcopy(term), "premise": premise,
    }


def ordinary(context, index):
    return use(context, index, ZERO, h_proof())


def opened(formula, eigen):
    _, x, y, body = formula
    binder = L.fresh_name(L.all_names(body) | {eigen}, "_b")
    base = sub(body, {x: var(eigen), y: ZERO})
    instance = sub(body, {x: var(eigen), y: var(binder)})
    return (base, binder, instance)


def di_context(proof, context):
    _, x, y, body = proof["conclusion"]
    w, z = proof["witness"], proof["eigen"]
    out = list(context)
    out.append(L.hypothesis(sub(body, {x: w, y: ZERO})))
    if body[0] == "=":
        out.append(L.hypothesis(sub(body, {x: w, y: var(z)})))
    return out


def de_context(proof, context):
    return list(context) + [opened(proof["major"]["conclusion"], proof["eigen"])]


def tr(equality, before, variable, motive):
    return {
        "rule": "tr",
        "conclusion": sub(motive, {variable: equality["conclusion"][2]}),
        "equality": equality, "before": before,
        "variable": variable, "motive": motive,
    }


def replace_term(term, path, replacement):
    if not path:
        return copy.deepcopy(replacement)
    out = copy.deepcopy(term)
    child = path[0] + 1
    out[child] = replace_term(out[child], path[1:], replacement)
    return out


def at_term(term, path):
    for child in path:
        term = term[child + 1]
    return term


def occurrences(term, name, prefix=()):
    if term == var(name):
        yield list(prefix)
    elif term[0] != "$":
        for index, child in enumerate(term[1:]):
            yield from occurrences(child, name, prefix + (index,))


def rename_proof(proof, old, new):
    """Capture-avoiding renaming of a free eigenparameter in a proof.

    A nested rule that allocates the same spelling binds it in its own
    minor premise.  A transport placeholder binds only its motive.
    """
    out = copy.deepcopy(proof)
    replacement = {old: var(new)}
    out["conclusion"] = sub(proof["conclusion"], replacement)
    rule = proof["rule"]
    if rule == "use":
        out["term"] = term_sub(proof["term"], replacement)
        out["premise"] = rename_proof(proof["premise"], old, new)
    elif rule == "di":
        out["witness"] = term_sub(proof["witness"], replacement)
        if proof["eigen"] != old:
            out["premise"] = rename_proof(proof["premise"], old, new)
    elif rule == "de":
        out["major"] = rename_proof(proof["major"], old, new)
        if proof["eigen"] != old:
            out["premise"] = rename_proof(proof["premise"], old, new)
    elif rule == "tr":
        out["equality"] = rename_proof(proof["equality"], old, new)
        out["before"] = rename_proof(proof["before"], old, new)
        if proof["variable"] != old:
            out["motive"] = sub(proof["motive"], replacement)
    elif rule == "rw":
        out["before"] = rename_proof(proof["before"], old, new)
        out["source"] = rename_proof(proof["source"], old, new)
    elif rule != "comp":
        raise ValueError(f"Unknown proof rule {rule!r}")
    return out


def shift_clause_indices(proof, boundary, count):
    out = copy.deepcopy(proof)
    if out["rule"] == "use" and out["clause"] >= boundary:
        out["clause"] += count
    for key in ("premise", "major", "equality", "before", "source"):
        if key in out:
            out[key] = shift_clause_indices(out[key], boundary, count)
    return out


class Normalizer:
    def __init__(self, *objects):
        self.fresh = Fresh(*objects)

    def freshen(self, proof):
        """Clone a proof, allocating globally fresh local eigenvariables."""
        self.fresh.reserve(proof)
        out = copy.deepcopy(proof)
        rule = out["rule"]
        if rule in ("di", "de"):
            old, new = out["eigen"], self.fresh.name("_e")
            out["eigen"] = new
            out["premise"] = self.freshen(rename_proof(out["premise"], old, new))
            if rule == "de":
                out["major"] = self.freshen(out["major"])
        elif rule == "tr":
            new = self.fresh.name("_v")
            out["motive"] = sub(out["motive"], {out["variable"]: var(new)})
            out["variable"] = new
            out["equality"] = self.freshen(out["equality"])
            out["before"] = self.freshen(out["before"])
        elif rule == "use":
            out["premise"] = self.freshen(out["premise"])
        elif rule == "rw":
            out["source"] = self.freshen(out["source"])
            out["before"] = self.freshen(out["before"])
        elif rule != "comp":
            raise ValueError(f"Unknown proof rule {rule!r}")
        return out

    def weaken(self, proof, root_length, additional_count):
        return shift_clause_indices(self.freshen(proof), root_length, additional_count)

    def reflexivity(self, term):
        equation = comp(["id", term], term)
        v = self.fresh.name("_v")
        return tr(equation, copy.deepcopy(equation), v, eq(var(v), term))

    def symmetry(self, equality):
        left = equality["conclusion"][1]
        v = self.fresh.name("_v")
        return tr(equality, self.reflexivity(left), v, eq(var(v), left))

    def transport(self, equality, before, variable, motive, context):
        """General formula transport using only atomic transport nodes."""
        self.fresh.reserve(equality, before, variable, motive, context)
        if motive[0] == "=":
            return tr(equality, before, variable, motive)
        if motive[0] != "D":
            raise ValueError("Motive is not a native formula")

        left, right = equality["conclusion"][1:]
        target = sub(motive, {variable: right})
        _, x, y, body = motive
        a, z = self.fresh.name("_a"), self.fresh.name("_z")
        outer_length = len(context)
        minor_context = list(context) + [opened(before["conclusion"], a)]
        introduction = {
            "rule": "di", "conclusion": target,
            "witness": var(a), "eigen": z,
        }
        inside = di_context(introduction, minor_context)
        lifted = self.weaken(equality, outer_length, len(inside) - outer_length)
        base = ordinary(inside, outer_length + 1)
        base_motive = sub(body, {x: var(a), y: ZERO})
        back = self.transport(self.symmetry(copy.deepcopy(lifted)), base,
                              variable, base_motive, inside)
        step_source = use(inside, outer_length, succ(var(z)), back)
        step_motive = sub(body, {x: var(a), y: succ(var(z))})
        step = self.transport(lifted, step_source, variable, step_motive, inside)
        introduction["premise"] = step
        return {
            "rule": "de", "conclusion": target,
            "major": before, "eigen": a, "premise": introduction,
        }

    def atomic(self, proof, context):
        """Stage 1: remove compound motives, retaining atomic tr nodes."""
        out = copy.deepcopy(proof)
        rule = proof["rule"]
        if rule == "comp":
            return out
        if rule == "use":
            out["premise"] = self.atomic(proof["premise"], context)
        elif rule == "di":
            out["premise"] = self.atomic(proof["premise"], di_context(proof, context))
        elif rule == "de":
            out["major"] = self.atomic(proof["major"], context)
            out["premise"] = self.atomic(proof["premise"], de_context(proof, context))
        elif rule == "tr":
            equality = self.atomic(proof["equality"], context)
            before = self.atomic(proof["before"], context)
            out = self.transport(equality, before, proof["variable"],
                                 proof["motive"], context)
        elif rule == "rw":
            source = self.atomic(proof["source"], context)
            before = self.atomic(proof["before"], context)
            v = self.fresh.name("_v")
            motive = copy.deepcopy(before["conclusion"])
            side = proof["side"] + 1
            motive[side] = replace_term(motive[side], proof["path"], var(v))
            if proof["orientation"]:
                source = self.symmetry(source)
            out = tr(source, before, v, motive)
        else:
            raise ValueError(f"Unknown proof rule {rule!r}")
        if L.alpha_key(out["conclusion"]) != L.alpha_key(proof["conclusion"]):
            raise ValueError("Atomic normalization changed the concluding formula")
        out["conclusion"] = copy.deepcopy(proof["conclusion"])
        return out

    def local_occurrences(self, source, supplied, motive, variable, reverse):
        if motive[0] != "=":
            raise ValueError("Local conversion requires an atomic motive")
        endpoint = source["conclusion"][1 + int(reverse)]
        replacement = source["conclusion"][2 - int(reverse)]
        result = supplied
        for side in (0, 1):
            for path in occurrences(motive[side + 1], variable):
                conclusion = copy.deepcopy(result["conclusion"])
                if at_term(conclusion[side + 1], path) != endpoint:
                    raise ValueError("Selected occurrence does not match the neutral endpoint")
                conclusion[side + 1] = replace_term(conclusion[side + 1], path, replacement)
                result = {
                    "rule": "rw", "conclusion": conclusion,
                    "before": result, "source": copy.deepcopy(source),
                    "orientation": int(reverse), "side": side, "path": path,
                }
        return result

    def convert(self, equation, context, supplied, motive, variable, reverse=False):
        """Strong bidirectional converter, valid for an arbitrary local proof.

        The equation is an atomic-reference derivation under precisely
        context.  Its local eigenparameters are renamed away from the
        supplied proof before a continuation is moved through DE.
        """
        self.fresh.reserve(equation, context, supplied, motive, variable)
        equation = self.freshen(equation)
        if equation["conclusion"][0] != "=":
            raise ValueError("Converter source is not an equation")
        rule = equation["rule"]
        if rule in ("comp", "use"):
            source = self.local(equation, context)
            return self.local_occurrences(source, supplied, motive, variable, reverse)
        if rule == "de":
            major = self.local(equation["major"], context)
            inside = de_context(equation, context)
            lifted = self.weaken(supplied, len(context), 1)
            converted = self.convert(equation["premise"], inside, lifted,
                                     motive, variable, reverse)
            return {
                "rule": "de", "conclusion": converted["conclusion"],
                "major": major, "eigen": equation["eigen"], "premise": converted,
            }
        if rule == "tr":
            major = equation["equality"]
            minor = equation["before"]
            u = equation["variable"]
            atomic_motive = equation["motive"]
            if atomic_motive[0] != "=":
                raise ValueError("Stage 2 received a compound transport motive")
            p, q = atomic_motive[1:]
            left_motive = sub(motive, {variable: p})
            right_motive = sub(motive, {variable: q})
            if not reverse:
                first = self.convert(major, context, supplied, left_motive, u, True)
                middle = self.convert(minor, context, first, motive, variable, False)
                return self.convert(major, context, middle, right_motive, u, False)
            first = self.convert(major, context, supplied, right_motive, u, True)
            middle = self.convert(minor, context, first, motive, variable, True)
            return self.convert(major, context, middle, left_motive, u, False)
        raise ValueError(f"Impossible atomic proof head after stage 1: {rule!r}")

    def local(self, proof, context):
        """Stage 2: neutralize atomic sources and split every occurrence."""
        out = copy.deepcopy(proof)
        rule = proof["rule"]
        if rule == "comp":
            return out
        if rule == "use":
            out["premise"] = self.local(proof["premise"], context)
        elif rule == "di":
            out["premise"] = self.local(proof["premise"], di_context(proof, context))
        elif rule == "de":
            out["major"] = self.local(proof["major"], context)
            out["premise"] = self.local(proof["premise"], de_context(proof, context))
        elif rule == "tr":
            before = self.local(proof["before"], context)
            out = self.convert(proof["equality"], context, before,
                               proof["motive"], proof["variable"])
        else:
            raise ValueError(f"Unexpected rule in atomic intermediate proof: {rule!r}")
        if L.alpha_key(out["conclusion"]) != L.alpha_key(proof["conclusion"]):
            raise ValueError("Local normalization changed the concluding formula")
        out["conclusion"] = copy.deepcopy(proof["conclusion"])
        return out


def normalize_packet(packet):
    """Check reference input, compile both stages, independently check outputs."""
    source_stats = L.check_packet(packet, mode="general")
    n = Normalizer(packet)
    original = n.freshen(packet["proof"])
    atomic_proof = n.atomic(original, [])
    atomic_packet = {**copy.deepcopy(packet), "proof": atomic_proof}
    atomic_stats = L.check_packet(atomic_packet, mode="atomic")
    local_proof = n.local(atomic_proof, [])
    local_packet = {**copy.deepcopy(packet), "proof": local_proof}
    local_stats = L.check_packet(local_packet, mode="local")
    return local_packet, atomic_packet, {
        "source": source_stats, "atomic": atomic_stats, "local": local_stats,
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--atomic-output", type=Path)
    args = parser.parse_args()
    packet = json.loads(args.input.read_text())
    local, atomic, stats = normalize_packet(packet)
    args.output.write_text(json.dumps(local, indent=2) + "\n")
    if args.atomic_output:
        args.atomic_output.write_text(json.dumps(atomic, indent=2) + "\n")
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
