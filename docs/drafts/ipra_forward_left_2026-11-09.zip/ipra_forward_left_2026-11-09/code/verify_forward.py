"""Reproduce the concrete forward-left proof compiler and boundary checks.

These are finite implementation checks.  The metatheorem for all finite
derivations is the written proof, not a conclusion drawn from this corpus.
"""
from pathlib import Path
import copy
import importlib.util
import json
import subprocess
import sys

import forward_compiler as C
import forward_left_checker as F

ROOT = Path(__file__).resolve().parent


def proof_nodes(proof):
    yield proof
    for key in ("premise", "major", "equality", "source", "before"):
        if key in proof:
            yield from proof_nodes(proof[key])


def first_rule(packet, rule):
    return next(node for node in proof_nodes(packet["proof"]) if node["rule"] == rule)


def run_cli(packet, optimized):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(ROOT / "forward_left_checker.py"))
    result = subprocess.run(command, input=json.dumps(packet), text=True,
                            capture_output=True, timeout=30)
    return {"stdout": result.stdout.strip(), "returncode": result.returncode,
            "stderr": result.stderr.strip()}


def main():
    output = []
    for source in sorted((ROOT / "reference/examples").glob("*.json")):
        packet, stats = C.compile_packet(json.loads(source.read_text()))
        for node in proof_nodes(packet["proof"]):
            if node["rule"] == "rw":
                if "orientation" in node or "side" in node:
                    raise ValueError("Removed fields survived compilation")
                if node["source"]["rule"] != "use":
                    raise ValueError("A computation remains a direct rewrite source")
        path = ROOT / "examples" / source.name
        path.write_text(json.dumps(packet, indent=2) + "\n")
        executions = [run_cli(packet, optimized) for optimized in (False, True)]
        if any(row != {"stdout": "ACCEPT", "returncode": 0, "stderr": ""}
               for row in executions):
            raise ValueError((source.name, executions))
        output.append({"file": source.name, **stats, "cli": executions})

    valid = json.loads((ROOT / "examples/reflexivity.json").read_text())
    bad = []

    def mutation(label, mutate):
        packet = copy.deepcopy(valid)
        mutate(packet)
        try:
            F.check_packet(packet)
        except Exception as error:
            api = {"rejected": True, "reason": str(error)}
        else:
            raise ValueError("A malformed packet was accepted: " + label)
        executions = [run_cli(packet, optimized) for optimized in (False, True)]
        if any(row != {"stdout": "REJECT", "returncode": 1, "stderr": ""}
               for row in executions):
            raise ValueError((label, executions))
        bad.append({"label": label, "api": api, "cli": executions})

    mutation("forbidden_orientation", lambda p: first_rule(p, "rw").update(orientation=0))
    mutation("forbidden_equation_side", lambda p: first_rule(p, "rw").update(side=0))
    mutation("direct_computation_source", lambda p: first_rule(p, "rw").update(
        source={"rule": "comp", "conclusion": ["=", ["id", ["0"]], ["0"]]}))
    mutation("negative_path_index", lambda p: first_rule(p, "rw").update(path=[-1]))
    mutation("path_outside_term", lambda p: first_rule(p, "rw").update(path=[9]))
    mutation("boolean_path_index", lambda p: first_rule(p, "rw").update(path=[False]))
    mutation("bad_clause_index", lambda p: first_rule(p, "rw")["source"].update(clause=100))
    mutation("missing_antecedent_proof", lambda p: first_rule(p, "rw")["source"].pop("premise"))
    mutation("unbound_numerical_argument", lambda p: first_rule(p, "rw")["source"].update(
        term=["$", "not_in_scope"]))
    mutation("forged_rewrite_conclusion", lambda p: first_rule(p, "rw").update(
        conclusion=["=", ["0"], ["S", ["0"]]]))
    mutation("reference_mode_injection", lambda p: p.update(mode="general"))
    mutation("false_goal", lambda p: p.update(goal=["=", ["0"], ["S", ["0"]]]))

    spec = importlib.util.spec_from_file_location("measure", ROOT / "reference/source_measure.py")
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    metrics = {name: measure.metrics(ROOT / name) for name in
               ("reference/local_checker.py", "forward_left_checker.py")}
    receipt = {"positive_cases": output, "negative_cases": bad, "metrics": metrics,
               "boundary": "Written metatheorem plus finite independent certificate checks; not a mechanization of the full iPRA interpretation theorem."}
    (ROOT / "evidence/verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"positive_cases": len(output), "negative_cases": len(bad),
                      "cli_runs": 2 * (len(output) + len(bad)), "metrics": metrics}, indent=2))


if __name__ == "__main__":
    main()
