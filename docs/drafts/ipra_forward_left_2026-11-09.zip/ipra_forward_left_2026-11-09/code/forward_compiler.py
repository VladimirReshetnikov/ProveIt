"""Untrusted compiler from the supplied native calculus to forward-left RW.

The standalone acceptance algorithm is forward_left_checker.py.  This producer
uses the attributed reference formula-transport compiler only to obtain atomic
transport.  The new second stage uses vacuous paired binders, not neutral
normalization by induction on equality proofs.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent / "reference"))
import local_checker as R
import producer as P
import forward_left_checker as F


class ForwardCompiler(P.Normalizer):
    def boxed_identity(self, equation, context):
        """A proof of D_{x,y} E with both variables absent from E."""
        self.fresh.reserve(equation, context)
        x, y, z = (self.fresh.name(prefix) for prefix in ("_bx", "_by", "_bz"))
        result = {
            "rule": "di", "conclusion": ["D", x, y, copy.deepcopy(equation)],
            "witness": P.ZERO, "eigen": z,
        }
        inside = P.di_context(result, context)
        result["premise"] = P.ordinary(inside, len(context))
        return result

    def left(self, equality, before, path, context):
        """Forward rewrite of one left-side occurrence using any proved E.

The primitive source is always an actual Use of the fresh identity clause.
The supplied equality proof is its antecedent, with clause indices weakened.
"""
        self.fresh.reserve(equality, before, path, context)
        equation = equality["conclusion"]
        if equation[0] != "=" or before["conclusion"][0] != "=":
            raise ValueError("A numerical equality is required")
        target = copy.deepcopy(before["conclusion"])
        if P.at_term(target[1], path) != equation[1]:
            raise ValueError("The selected occurrence is not the left endpoint")
        target[1] = P.replace_term(target[1], path, equation[2])
        major = self.boxed_identity(equation, context)
        a = self.fresh.name("_ba")
        lifted_equality = self.weaken(equality, len(context), 1)
        lifted_before = self.weaken(before, len(context), 1)
        source = {
            "rule": "use", "conclusion": copy.deepcopy(equation),
            "clause": len(context), "term": P.ZERO, "premise": lifted_equality,
        }
        step = {
            "rule": "rw", "conclusion": target, "before": lifted_before,
            "source": source, "path": list(path),
        }
        return {
            "rule": "de", "conclusion": target, "major": major,
            "eigen": a, "premise": step,
        }

    def reflexivity(self, term, context):
        computation = P.comp(["id", term], term)
        return self.left(computation, copy.deepcopy(computation), [], context)

    def symmetry(self, equality, context):
        left = equality["conclusion"][1]
        return self.left(equality, self.reflexivity(left, context), [], context)

    def atom_transport(self, equality, before, variable, motive, context):
        if motive[0] != "=":
            raise ValueError("The first stage must eliminate compound motives")
        result = before
        for path in P.occurrences(motive[1], variable):
            result = self.left(equality, result, path, context)
        right_paths = list(P.occurrences(motive[2], variable))
        if right_paths:
            result = self.symmetry(result, context)
            for path in right_paths:
                result = self.left(equality, result, path, context)
            result = self.symmetry(result, context)
        return result

    def compile_atomic(self, proof, context):
        result = copy.deepcopy(proof)
        rule = proof["rule"]
        if rule == "comp":
            return result
        if rule == "use":
            result["premise"] = self.compile_atomic(proof["premise"], context)
        elif rule == "di":
            result["premise"] = self.compile_atomic(proof["premise"], P.di_context(proof, context))
        elif rule == "de":
            result["major"] = self.compile_atomic(proof["major"], context)
            result["premise"] = self.compile_atomic(proof["premise"], P.de_context(proof, context))
        elif rule == "tr":
            equality = self.compile_atomic(proof["equality"], context)
            before = self.compile_atomic(proof["before"], context)
            result = self.atom_transport(equality, before, proof["variable"], proof["motive"], context)
        else:
            raise ValueError("Unexpected atomic-stage inference: " + str(rule))
        if not F.alpha_equal(result["conclusion"], proof["conclusion"]):
            raise ValueError("Compilation changed the concluding formula")
        result["conclusion"] = copy.deepcopy(proof["conclusion"])
        return result


def compile_packet(packet):
    original_stats = R.check_packet(packet, mode="general")
    # The first stage must use the unmodified reference class: its symmetry
    # constructor builds reference transport, not forward-left proofs.
    first = P.Normalizer(packet)
    atomic = first.atomic(first.freshen(packet["proof"]), [])
    atomic_packet = {**copy.deepcopy(packet), "proof": atomic}
    atomic_stats = R.check_packet(atomic_packet, mode="atomic")
    second = ForwardCompiler(atomic_packet)
    output = second.compile_atomic(second.freshen(atomic), [])
    result = {**copy.deepcopy(packet), "proof": output}
    output_stats = F.check_packet(result)
    return result, {"source": original_stats, "atomic": atomic_stats, "forward_left": output_stats}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output, stats = compile_packet(json.loads(args.source.read_text()))
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(stats, indent=2))
