"""Replay the exact linear-node compiler against its standalone target."""
from pathlib import Path
import copy
import json
import subprocess
import sys

import neutral_formula_checker as N
import neutral_formula_compiler as C

ROOT = Path(__file__).resolve().parent


def nodes(proof):
    yield proof
    for key in ("premise", "major", "equality", "before", "source"):
        if key in proof:
            yield from nodes(proof[key])


def first_neutral(packet):
    return next(n for n in nodes(packet["proof"]) if n["rule"] == "nr")


def cli(packet, optimized):
    command = [sys.executable] + (["-O"] if optimized else [])
    command.append(str(ROOT / "neutral_formula_checker.py"))
    p = subprocess.run(command, input=json.dumps(packet), text=True,
                       capture_output=True, timeout=30)
    return {"stdout": p.stdout.strip(), "returncode": p.returncode, "stderr": p.stderr}


def main():
    (ROOT / "examples_neutral").mkdir(exist_ok=True)
    positives = []
    for source in sorted((ROOT / "reference/examples").glob("*.json")):
        if source.name == "local_input_roundtrip.json":
            # This one is already a local-RW source rather than the Tr-only
            # source calculus in the exact node theorem.
            continue
        packet, stats = C.compile_packet(json.loads(source.read_text()))
        (ROOT / "examples_neutral" / source.name).write_text(json.dumps(packet, indent=2) + "\n")
        executions = [cli(packet, optimized) for optimized in (False, True)]
        if any(r != {"stdout": "ACCEPT", "returncode": 0, "stderr": ""} for r in executions):
            raise ValueError((source.name, executions))
        positives.append({"file": source.name, **stats, "cli": executions})

    valid = json.loads((ROOT / "examples_neutral/reflexivity.json").read_text())
    negatives = []

    def reject(label, mutate):
        packet = copy.deepcopy(valid)
        mutate(packet)
        try:
            N.check_packet(packet)
        except Exception as error:
            reason = str(error)
        else:
            raise ValueError("A malformed target was accepted: " + label)
        executions = [cli(packet, optimized) for optimized in (False, True)]
        if any(r != {"stdout": "REJECT", "returncode": 1, "stderr": ""} for r in executions):
            raise ValueError((label, executions))
        negatives.append({"label": label, "reason": reason, "cli": executions})

    reject("direct_computation_source", lambda p: first_neutral(p).update(
        equality={"rule": "comp", "conclusion": ["=", ["id", ["0"]], ["0"]]}))
    reject("old_unrestricted_transport_tag", lambda p: first_neutral(p).update(rule="tr"))
    reject("old_local_rewrite_tag", lambda p: first_neutral(p).update(rule="rw"))
    reject("forbidden_orientation", lambda p: first_neutral(p).update(orientation=0))
    reject("missing_antecedent", lambda p: first_neutral(p)["equality"].pop("premise"))
    reject("bad_clause_index", lambda p: first_neutral(p)["equality"].update(clause=999))
    reject("mode_injection", lambda p: p.update(mode="general"))
    reject("false_goal", lambda p: p.update(goal=["=", ["0"], ["S", ["0"]]]))

    receipt = {
        "positive_cases": positives, "negative_cases": negatives,
        "counting": "All comp/use/di/de/tr or nr objects count as one inference; source Use and H computation are explicit.",
        "exact_relation": "N_prime = N + 5*T", "largest_source": max(r["N"] for r in positives),
        "largest_target": max(r["N_prime"] for r in positives),
        "boundary": "Finite implementation check of a written general theorem; no universal claim is inferred from this finite corpus.",
    }
    (ROOT / "evidence/neutral_verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"positive_cases": len(positives), "negative_cases": len(negatives),
                      "cli_runs": 2 * (len(positives) + len(negatives)),
                      "node_relations": [[r["file"], r["N"], r["T"], r["N_prime"]] for r in positives]}, indent=2))


if __name__ == "__main__":
    main()
