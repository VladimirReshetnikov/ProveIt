"""Replay the proof compilers and source measurements; optionally rebuild PDF."""
from pathlib import Path
import argparse
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true", help="also rebuild report.pdf")
    args = parser.parse_args()
    for script in ("verify_neutral.py", "verify_forward.py"):
        subprocess.run([sys.executable, str(ROOT / "code" / script)],
                       cwd=ROOT / "code", check=True)
    spec = importlib.util.spec_from_file_location("source_measure", ROOT / "reference/source_measure.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    inputs = [ROOT / "reference/local_checker.py", ROOT / "code/forward_left_checker.py",
              ROOT / "code/neutral_formula_checker.py"]
    inputs += sorted((ROOT / "reference/compact").glob("*.py"))
    metrics = [{"file": str(p.relative_to(ROOT)), **module.metrics(p)} for p in inputs]
    result = {"python": sys.version, "whole_module_metrics": metrics,
              "qualification": "Compact-comparator classification and proof scopes are explained in report.pdf."}
    (ROOT / "evidence/reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if args.pdf:
        subprocess.run([sys.executable, str(ROOT / "build_pdf.py")], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
