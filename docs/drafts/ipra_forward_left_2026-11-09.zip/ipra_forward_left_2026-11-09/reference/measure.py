"""Reproduce whole-source measurements with the unchanged corpus normalizer."""
import ast
import csv
import hashlib
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NORMALIZER_SHA256 = "f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def naming_control(module):
    """The corpus control renames only inst/check/take to i/c/q."""
    renaming = {"inst": "i", "check": "c", "take": "q"}
    path = ROOT / "reference" / "checkers" / "compact_open.py"
    tree = module.StripDocstrings().visit(ast.parse(path.read_text()))
    names = ({node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
             | {node.arg for node in ast.walk(tree) if isinstance(node, ast.arg)}
             | {node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)})
    if names.intersection(renaming.values()):
        raise RuntimeError("Naming-control target collision")
    if any(isinstance(node, ast.arg) and node.arg in renaming for node in ast.walk(tree)):
        raise RuntimeError("Unexpected argument binding in naming-control source")
    class Rename(ast.NodeTransformer):
        def visit_Name(self, node):
            node.id = renaming.get(node.id, node.id)
            return node
        def visit_FunctionDef(self, node):
            self.generic_visit(node)
            node.name = renaming.get(node.name, node.name)
            return node
    tree = ast.fix_missing_locations(Rename().visit(tree))
    text = ast.unparse(tree) + "\n"
    return {"file": str(path.relative_to(ROOT)), "renaming": renaming,
            "normalized_tokens": module.significant(text),
            "ast_nodes": sum(1 for node in ast.walk(tree)),
            "normalized_bytes": len(text.encode("utf-8")),
            "source": "The uniform-name control in inherited code/verify_complete_kernel.py; no arithmetic change."}


def main():
    normalizer = ROOT / "reference" / "source_measure.py"
    if digest(normalizer) != NORMALIZER_SHA256:
        raise RuntimeError("The frozen source normalizer has changed")
    specification = importlib.util.spec_from_file_location("corpus_measure", normalizer)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    manifest = json.loads((ROOT / "reference" / "checker_manifest.json").read_text())
    rows = []
    for entry in manifest:
        path = ROOT / "reference" / "checkers" / entry["filename"]
        if digest(path) != entry["sha256"]:
            raise RuntimeError("Frozen comparator changed: " + entry["filename"])
        measured = module.metrics(path)
        measured.pop("core")
        rows.append({"file": str(path.relative_to(ROOT)), "kind": "inherited", **measured})
    candidate = ROOT / "code" / "local_checker.py"
    measured = module.metrics(candidate)
    measured.pop("core")
    rows.append({"file": str(candidate.relative_to(ROOT)), "kind": "new", **measured})
    coordinates = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    frontier = {key: min(row[key] for row in rows[:-1]) for key in coordinates}
    result = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "normalizer_sha256": NORMALIZER_SHA256,
        "scope": "Entire source file; imports, parser, verdict, rejection and reference branches included.",
        "corpus_minimum": frontier,
        "candidate_strictly_below": {key: measured[key] < frontier[key] for key in coordinates},
        "uniform_short_name_control": naming_control(module),
        "programs": rows,
    }
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    (evidence / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    fields = ("file", "kind", "source_tokens", *coordinates, "raw_bytes", "sha256")
    with (evidence / "metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        writer.writerows(rows)
    lines = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Complete source & Tokens & AST nodes & Bytes\\\midrule"]
    for row in rows:
        label = Path(row["file"]).name.replace("_", r"\_")
        values = " & ".join(str(row[key]) for key in coordinates)
        lines.append(r"\texttt{" + label + "} & " + values + r"\\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (evidence / "metrics_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
