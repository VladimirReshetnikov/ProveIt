REFERENCE SOURCES
=================

The main comparison snapshot for this package is ProveIt commit
572c3ef372fb22e30951af30bf1041efcffc8b7d. Exact archive/member identities
and hashes are recorded under ../evidence/.

SOURCE.txt and rotation_source.tex are preserved predecessor artifacts.
SOURCE.txt describes that predecessor's earlier snapshot and its former
proof dependency. The present report uses ../appendix_arithmetic.tex for
the arithmetic completion, independently of the rotation proof.

recurrence_boundary_source.tex is an unchanged, self-contained reference
report from the current snapshot. Its countdown diagonal and linear-fibre
countermodel are explicitly attributed in the supplementary appendix.
Its original attribution and license are preserved alongside it. The
supplement's reverse-reset zero-equation induction proof is new relative
to the inspected drafts; the underlying diagonal and countermodel are not.

local_checker.py, producer.py, source_measure.py, and the compact programs
are unchanged inherited comparison/producer sources. The new standalone
checkers do not import them; proof producers and reproduction tools do.
