"""Build the report with an installed TeX distribution.

On a normal installation this simply runs latexmk.  The fallback repairs no
system files: when the prebuilt format is absent, it creates a temporary
format and font map using the already installed TeX source and fonts.
"""
from pathlib import Path
import json
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def capture(command, **kwargs):
    return subprocess.run(command, text=True, capture_output=True, **kwargs)


def main():
    if not shutil.which("latexmk") or not shutil.which("pdflatex"):
        raise SystemExit("Install TeX Live with latexmk and the packages used by report.tex.")
    env = os.environ.copy()
    format_result = capture(["kpsewhich", "pdflatex.fmt"])
    fallback = not format_result.stdout.strip()
    with tempfile.TemporaryDirectory(prefix="ipra_tex_") as temporary:
        tmp = Path(temporary)
        if fallback:
            dist_result = capture(["kpsewhich", "-var-value=TEXMFDIST"])
            dist = Path(dist_result.stdout.strip())
            if not (dist / "tex/latex/base/latex.ltx").is_file():
                raise SystemExit("TeX format and installed LaTeX sources are both unavailable.")
            roots = [Path("/etc/texmf"), Path("/usr/share/texmf"), dist]
            roots = [p for p in roots if p.is_dir()]
            env["TEXMF"] = "{" + ",".join(["."] + [str(p) for p in roots]) + "}"
            result = capture(["pdftex", "-ini", "-etex", "-jobname=pdflatex",
                              "-progname=pdflatex", "-interaction=nonstopmode",
                              "-halt-on-error", "pdflatex.ini"], cwd=tmp, env=env)
            if result.returncode:
                raise SystemExit(result.stdout + result.stderr)
            maps = []
            for root in roots:
                lm = root / "fonts/map/dvips/lm/lm.map"
                if lm.is_file():
                    maps.append(lm)
                maps.extend(sorted((root / "fonts/map/dvips/amsfonts").glob("*.map")))
            (tmp / "pdftex.map").write_text("\n".join(p.read_text() for p in maps))
            env["TEXFORMATS"] = str(tmp) + ":"
            env["TEXFONTMAPS"] = ":".join([str(tmp) + "//"] +
                                            [str(p / "fonts/map") + "//" for p in roots]) + ":"
        result = capture(["latexmk", "-pdf", "-interaction=nonstopmode",
                          "-halt-on-error", "report.tex"], cwd=ROOT, env=env)
        evidence = ROOT / "evidence"
        evidence.mkdir(exist_ok=True)
        (evidence / "pdf_build_stdout.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            raise SystemExit(result.stdout[-12000:] + result.stderr)
        log = (ROOT / "report.log").read_text(errors="replace")
        receipt = {"success": True, "temporary_format_fallback": fallback,
                   "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
                   "overfull_boxes": log.count("Overfull"),
                   "undefined_references": "There were undefined references" in log,
                   "boundary": "Compilation receipt; visual review is separate."}
        (evidence / "pdf_build.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
