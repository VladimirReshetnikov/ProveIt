FORWARD-LEFT EQUALITY FOR iPRA
Vacuous closures, a linear source translation, and a complexity audit
9 November 2026

OUTCOME
=======
The requested construction below the entire current complete-checker frontier
has NOT been obtained. This package contains a proved simplification of the
native equality interface and complete executable artifacts; it does not
claim absolute simplestness or a significant arithmetic breakthrough.

1. An arbitrary equality proof can become a direct retained-clause source
   through a vacuous paired binder. With full formula motives the proof
   transformation has exactly N + 5*T inference nodes, where N is the input
   node count and T its transport count. This is at most 6*N, not a bound
   on serialized bytes, runtime, or the further local lowering.

2. The complete local equality rule needs only a checked clause Use,
   forward rewriting, the left equation side, and one numerical occurrence.
   Symmetry, the other side, direct computation sources, and all-formula
   transport are derived. The whole native consequence relation is preserved.

3. The report gives every primitive rule/schema, the full ordinary logical
   reconstruction, and both formula/domain composites with full iPRA.
   A direct subtraction argument supplies the arithmetic completion from
   equation induction. Whole-domain actual equality is retained.

4. The matched readable checker shrinks from 3287/3650/16192 to
   3218/3562/15789 (normalized tokens / AST nodes / normalized bytes).
   The smaller compact comparators still win. The runtime-inclusive
   coordinate envelope is 306/340/839, attained by different files; the
   strict ordinary all-input-equivalent envelope is 307/341/839.

5. A supplemental reverse-reset proof derives contextual zero-equation
   induction from uniqueness of the countdown recurrence W(0)=1, W(Sn)=n.
   An inherited linear-fibre countermodel explains why this restricted
   induction consequence alone cannot yield actual equality reflection.
   No full iPRA equivalence from countdown uniqueness is claimed.

START HERE
==========
report.pdf                 Main mathematical report.
report.tex                 Main editable LaTeX source.
appendix_arithmetic.tex    Self-contained arithmetic completion proof.
appendix_countdown.tex     Supplementary countdown result and exact boundary.
code/README.txt            Exact implementation scope and local formats.
evidence/                  Measurements, compiler checks, source audit,
                           independent assistant reviews, and research notes.
reference/                 Unchanged attributed comparison sources and license.

The original inherited arithmetic source is preserved for provenance. Its
reference/SOURCE.txt records the predecessor package's earlier snapshot and
dependency status; it does not describe the present report's dependency
chain. The present snapshot is the commit recorded below, and the main
arithmetic proof is appendix_arithmetic.tex. The preserved source is not an
axiom or trusted external oracle in either standalone checker.

REPRODUCE
=========
Python 3.12.14 was used for the recorded source metrics. Other Python versions
can have different AST unparse formatting, so compare on the stated version.
All Python programs use the standard library.

  python3 reproduce.py
  python3 reproduce.py --pdf
  python3 package.py

The first command reruns both proof compilers, accepted/rejected certificate
cases, ordinary and optimized Python CLI replays, and the bundled complete
source measurements. It is not a formal verification of the metatheorems.
The last command rebuilds the ZIP and its content-hash manifest without
including Python caches or TeX build residue. The initial reproduction
console transcript predates the supplementary appendix; pdf_build.json
and visual_review.json describe the final PDF.

For one independently checked certificate:

  python3 code/neutral_formula_checker.py < code/examples_neutral/compound_depth_3.json
  python3 code/forward_left_checker.py < code/examples/compound_depth_3.json

To build the document on a normal TeX Live installation:

  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

Alternatively, build_pdf.py has a temporary, local-only fallback for an
installation whose TeX sources are present but its format cache is absent.
It does not download packages or alter system configuration.

BOUNDARIES
==========
The linear neutral checker has no reference modes. The matched forward-left
checker retains the inherited Python-API-only reference modes and charges
them in its whole-source size; the public JSON interface cannot enable them.
Neither checker imports a proof compiler, examples, source metrics, or an
external theorem library.

The new source translation inserts introduction-elimination redexes. It is
not a cut-free normalization and does not prove a shorter-certificate result
for the stronger forward-left calculus. Python resource limits can reject
large valid proofs. Finite tests supplement the written universal arguments.

The stable-equality research note separates an unconditional negative-
translation lemma from its unverified classical-arithmetic dependency.
That conditional candidate is not used to justify the main theorem.

The compact_left_prototype.py under code/evidence is an explicitly rejected,
unvalidated size experiment, not an additional verified checker.

PROVENANCE
==========
Current comparison snapshot:
  VladimirReshetnikov/ProveIt
  572c3ef372fb22e30951af30bf1041efcffc8b7d
  https://github.com/VladimirReshetnikov/ProveIt/tree/572c3ef372fb22e30951af30bf1041efcffc8b7d/docs/drafts

All twelve current ZIP identities were checked. Exact member provenance is
recorded in evidence/repository_manifest.json, bundled_comparators.json,
current_metrics.json, and code/reference. Inherited material is distributed
under the preserved MIT No Attribution license. New proofs are attributed
as results of this investigation relative to this inspected corpus; no
literature-wide historical-priority claim is made.
