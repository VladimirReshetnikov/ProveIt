import Init

/-!
# A zero guard turns base-free propagation into quantifier-free induction

This constructive local kernel uses an arbitrary carrier, a binary test
that is one on equality and zero off equality, and the two reset equations
Z(0,a)=a and Z(1,a)=0. The guard is the actual term

  G(n,a) = Z(chi(n,0), b(n,a)).

For one fixed predicate P, the only assumption about its compiled truth
term is b(n,a)=0 iff P(n,a). A two-valued range for b is not needed here.
The final theorem derives the full induction implication from one base-free
zero-propagation instance for G. It uses no prior arithmetic induction,
standard-natural-number induction, native `if`, DecidableEq, or classical
axiom. All hypotheses are explicit parameters.

Scope: finite term syntax, recognition of admissible zero guards, the
quantifier-free formula compiler, pairing, the full primitive-recursive
compiler, and the bi-interpretation theorem are NOT formalized here.
-/

namespace GuardedZeroInduction

universe u

structure Basis (A : Type u) where
  zero : A
  one : A
  reset : A → A → A
  chi : A → A → A
  separation : zero ≠ one
  reset_zero : ∀ a, reset zero a = a
  reset_one : ∀ a, reset one a = zero
  chi_diagonal : ∀ a, chi a a = one
  chi_off : ∀ a b, a = b ∨ chi a b = zero

variable {A : Type u} (K : Basis A)

theorem chi_one_iff (a b : A) : K.chi a b = K.one ↔ a = b := by
  constructor
  · intro hone
    cases K.chi_off a b with
    | inl heq => exact heq
    | inr hz => exact False.elim (K.separation (hz.symm.trans hone))
  · intro heq
    cases heq
    exact K.chi_diagonal a

theorem equality_cases (K : Basis A) (a b : A) : a = b ∨ a ≠ b := by
  cases K.chi_off a b with
  | inl heq => exact Or.inl heq
  | inr hz =>
      apply Or.inr
      intro heq
      have hone := (chi_one_iff K a b).mpr heq
      exact K.separation (hz.symm.trans hone)

/-- No range assumption is imposed on the already compiled truth term. -/
structure TruthTerm (K : Basis A) (P : A → A → Prop) where
  value : A → A → A
  reflects : ∀ n a, value n a = K.zero ↔ P n a

variable {P : A → A → Prop} (B : TruthTerm K P)

def guard (n a : A) : A := K.reset (K.chi n K.zero) (B.value n a)

theorem guard_at_zero (a : A) : guard K B K.zero a = K.zero := by
  unfold guard
  rw [K.chi_diagonal, K.reset_one]

/-- The guard adds exactly the root case to the encoded predicate. -/
theorem guard_characterization (n a : A) :
    guard K B n a = K.zero ↔ n = K.zero ∨ P n a := by
  constructor
  · intro hzero
    cases K.chi_off n K.zero with
    | inl hn => exact Or.inl hn
    | inr hchi =>
        have hb : B.value n a = K.zero := by
          unfold guard at hzero
          rw [hchi, K.reset_zero] at hzero
          exact hzero
        exact Or.inr ((B.reflects n a).mp hb)
  · intro h
    cases h with
    | inl hn =>
        rw [hn]
        exact guard_at_zero K B a
    | inr hp =>
        cases K.chi_off n K.zero with
        | inl hn =>
            rw [hn]
            exact guard_at_zero K B a
        | inr hchi =>
            unfold guard
            rw [hchi, K.reset_zero]
            exact (B.reflects n a).mpr hp

/--
Abstract logical deduction: a rooted characterization plus base-free
propagation supplies ordinary induction under local base/progress hypotheses.
-/
theorem induction_from_rooted_propagation
    {zero : A} {succ : A → A} {Q C : A → Prop}
    (rooted : ∀ n, C n ↔ n = zero ∨ Q n)
    (propagation : (∀ n, C n → C (succ n)) → ∀ n, C n)
    (initial : Q zero) (progress : ∀ n, Q n → Q (succ n)) (n : A) : Q n := by
  have remove_root : ∀ k, C k → Q k := by
    intro k hc
    cases (rooted k).mp hc with
    | inl hz => rw [hz]; exact initial
    | inr hq => exact hq
  have hstep : ∀ k, C k → C (succ k) := by
    intro k hc
    exact (rooted (succ k)).mpr (Or.inr (progress k (remove_root k hc)))
  exact remove_root n (propagation hstep n)

/-- The complete local deduction with the actual binary chi/Z guard term. -/
theorem induction_from_guarded_zero
    {succ : A → A}
    (zero_propagation : ∀ a,
      (∀ n, guard K B n a = K.zero → guard K B (succ n) a = K.zero) →
      ∀ n, guard K B n a = K.zero)
    (a : A) (initial : P K.zero a)
    (progress : ∀ n, P n a → P (succ n) a) (n : A) : P n a := by
  exact induction_from_rooted_propagation
    (fun k => guard_characterization K B k a)
    (zero_propagation a) initial progress n

/-- Ordinary induction proves every such guarded base-free instance. -/
theorem guarded_zero_propagation_from_induction
    {succ : A → A}
    (induction : ∀ a,
      guard K B K.zero a = K.zero →
      (∀ n, guard K B n a = K.zero → guard K B (succ n) a = K.zero) →
      ∀ n, guard K B n a = K.zero)
    (a : A)
    (progress : ∀ n, guard K B n a = K.zero → guard K B (succ n) a = K.zero)
    (n : A) : guard K B n a = K.zero := by
  exact induction a (guard_at_zero K B a) progress n

#print axioms chi_one_iff
#print axioms equality_cases
#print axioms guard_at_zero
#print axioms guard_characterization
#print axioms induction_from_rooted_propagation
#print axioms induction_from_guarded_zero
#print axioms guarded_zero_propagation_from_induction

end GuardedZeroInduction
