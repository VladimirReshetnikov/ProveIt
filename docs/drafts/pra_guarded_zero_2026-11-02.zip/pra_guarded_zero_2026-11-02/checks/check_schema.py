#!/usr/bin/env python3
"""Independent syntax audit for the guarded PRA axiom emitter.

This script constructs literal term/formula trees, performs simultaneous active
substitution without touching stored descriptors, and counts the resulting
trees.  It is not a proof assistant and does not establish bi-interpretability.

The comparative templates are evaluated in the union of their term grammars.
The report separates inputs in the original 0/S/recursor grammar from inputs
using the new equality bit.  Extending a template's input grammar is a syntax
comparison convention, not a claim that its original paper admitted that input.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
import random
from typing import Union


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple[Union[Term, "Formula"], ...] = ()
    binder: str = ""


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")
N, A, V, W = (var(name) for name in ("n", "a", "v", "w"))


def succ(t: Term) -> Term:
    return Term("succ", (t,))


ONE = succ(ZERO)


def chi(s: Term, t: Term) -> Term:
    return Term("chi", (s, t))


def rec(body: Term, n: Term, a: Term) -> Term:
    return Term("rec", (n, a), body=body)


def q(n: Term, a: Term) -> Term:
    return rec(W, n, a)


def z(n: Term, a: Term) -> Term:
    return rec(ZERO, n, a)


def guard(tail: Term) -> Term:
    return z(chi(N, ZERO), tail)


SEED = q(succ(N), A)


@lru_cache(maxsize=None)
def term_size(t: Term, full: bool = False) -> int:
    count = 1 + sum(term_size(x, full) for x in t.args)
    if full and t.kind == "rec":
        assert t.body is not None
        count += term_size(t.body, True)
    return count


@lru_cache(maxsize=None)
def occurrences(t: Term, name: str) -> int:
    return int(t.kind == "var" and t.name == name) + sum(
        occurrences(x, name) for x in t.args
    )


def substitute(t: Term, mapping: dict[str, Term]) -> Term:
    """Simultaneous substitution in active arguments; bodies remain frozen."""
    if t.kind == "var":
        return mapping.get(t.name, t)
    return Term(t.kind, tuple(substitute(x, mapping) for x in t.args), t.name, t.body)


def at(t: Term, first: Term, second: Term) -> Term:
    return substitute(t, {"n": first, "a": second})


def descriptor(t: Term) -> Term:
    return at(t, V, W)


def normalize(t: Term) -> Term:
    """Root-only Q(S r,s) -> r; never visit other subterms or descriptors."""
    while t.kind == "rec" and t.body == W and t.args[0].kind == "succ":
        t = t.args[0].args[0]
    return t


def is_guarded(t: Term) -> bool:
    return (
        t.kind == "rec" and t.body == ZERO
        and t.args[0] == chi(N, ZERO)
    )


def equality(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


def conj(p: Formula, r: Formula) -> Formula:
    return Formula("and", (p, r))


def disj(p: Formula, r: Formula) -> Formula:
    return Formula("or", (p, r))


def implies(p: Formula, r: Formula) -> Formula:
    return Formula("imp", (p, r))


def forall(name: str, p: Formula) -> Formula:
    return Formula("forall", (p,), name)


def close(p: Formula) -> Formula:
    return forall("a", forall("n", p))


BOTTOM = Formula("false")
SEPARATION = implies(equality(ZERO, ONE), BOTTOM)


def formula_size(p: Formula, full: bool = False) -> int:
    return 1 + sum(
        term_size(x, full) if isinstance(x, Term) else formula_size(x, full)
        for x in p.args
    )


def quantifiers(p: Formula) -> tuple[int, int]:
    children = [quantifiers(x) for x in p.args if isinstance(x, Formula)]
    return (
        int(p.kind == "forall") + sum(x[0] for x in children),
        int(p.kind == "forall") + max((x[1] for x in children), default=0),
    )


def computation(u: Term, canonical: bool = True, right: bool = False) -> Formula:
    body = descriptor(normalize(u) if canonical else u)
    base = equality(rec(body, ZERO, A), A)
    if right:
        rhs = rec(body, N, at(u, A, ZERO))
    else:
        rhs = at(u, rec(body, N, A), N)
    step = equality(rec(body, succ(N), A), rhs)
    return conj(base, step)


def bit_axiom_payload(true_is_one: bool) -> Formula:
    diagonal, off_diagonal = (ONE, ZERO) if true_is_one else (ZERO, ONE)
    return conj(
        equality(chi(A, A), diagonal),
        disj(equality(A, N), equality(chi(A, N), off_diagonal)),
    )


def zero_induction(u: Term, include_base: bool = True) -> Formula:
    prop = equality(u, ZERO)
    step = forall("n", implies(prop, equality(at(u, succ(N), A), ZERO)))
    premise = conj(equality(at(u, ZERO, A), ZERO), step) if include_base else step
    return implies(premise, prop)


def new_axiom(u: Term) -> tuple[str, Formula]:
    i, j = occurrences(u, "n"), occurrences(u, "a")
    if u == SEED:
        payload = conj(SEPARATION, bit_axiom_payload(True))
        return "seed", close(conj(computation(u), payload))
    if i > 0 and j == 0:
        return "autonomous_right", close(computation(u, right=True))
    if is_guarded(u) and j > 0:
        return "guarded_induction", close(conj(computation(u), zero_induction(u, False)))
    return "left_computation", close(computation(u))


def old_constancy(u: Term) -> Formula:
    premise = forall("n", equality(at(u, succ(N), A), u))
    conclusion = equality(u, at(u, ZERO, A))
    payload = conj(SEPARATION, computation(u, False))
    return close(conj(payload, implies(premise, conclusion)))


def old_bit_factored(u: Term) -> Formula:
    payload = conj(SEPARATION, computation(u, False))
    return close(conj(payload, zero_induction(u)))


def old_bit_seeded(u: Term) -> Formula:
    if u == ZERO:
        payload = conj(SEPARATION, bit_axiom_payload(False))
        return close(conj(computation(u, False), payload))
    return close(conj(computation(u, False), zero_induction(u)))


def old_seeded_rooted(u: Term) -> Formula:
    """The optional rooted-zero kernel in the seeded equality-bit archive."""
    if u == ZERO:
        payload = conj(SEPARATION, bit_axiom_payload(False))
        return close(conj(computation(u, False), payload))
    prop = disj(equality(N, ZERO), equality(u, ZERO))
    step = forall("n", implies(prop, equality(at(u, succ(N), A), ZERO)))
    return close(conj(computation(u, False), implies(step, prop)))


def old_mask(u: Term) -> Formula:
    mask = Term("mask", (N, u))
    prop = equality(mask, N)
    step = forall("n", implies(prop, equality(at(u, succ(N), A), succ(N))))
    payload = conj(SEPARATION, computation(u, False))
    return close(conj(payload, implies(step, prop)))


def old_four_occurrence(u: Term) -> Formula:
    prop = disj(equality(N, ZERO), equality(u, N))
    step = forall("n", implies(prop, equality(at(u, succ(N), A), succ(N))))
    return close(conj(computation(u, False), implies(step, prop)))


def old_hp3(u: Term) -> Formula:
    i, j = occurrences(u, "n"), occurrences(u, "a")
    if i == 0:
        return close(conj(SEPARATION, computation(u)))
    if j == 0:
        return close(conj(SEPARATION, computation(u, right=True)))
    equal_zero_anchor = equality(u, at(u, N, ZERO))
    prop = disj(equality(N, ZERO), equal_zero_anchor)
    shifted_anchor = equality(at(u, succ(N), A), at(u, succ(N), ZERO))
    step = forall("n", implies(prop, shifted_anchor))
    payload = conj(SEPARATION, computation(u))
    return close(conj(payload, implies(step, prop)))


def old_adaptive_orientation(u: Term) -> Formula:
    """AO, exactly as specified in the four-occurrence archive's appendix."""
    i, j = occurrences(u, "n"), occurrences(u, "a")
    payload = conj(SEPARATION, computation(u, False))
    if i >= j:
        endpoints = equality(u, at(u, N, succ(A)))
        prop = disj(equality(N, ZERO), endpoints)
        shifted = equality(at(u, succ(N), A), at(u, succ(N), succ(A)))
        step = forall("n", implies(prop, shifted))
    else:
        endpoints = equality(u, at(u, succ(N), A))
        prop = disj(equality(A, ZERO), endpoints)
        shifted = equality(at(u, N, succ(A)), at(u, succ(N), succ(A)))
        step = forall("a", implies(prop, shifted))
    return close(conj(payload, implies(step, prop)))


OLD_EMITTERS = {
    "constancy_K": old_constancy,
    "equality_bit_factored": old_bit_factored,
    "equality_bit_seeded": old_bit_seeded,
    "equality_bit_seeded_rooted": old_seeded_rooted,
    "equality_mask_core": old_mask,
    "four_occurrence_factored_core": old_four_occurrence,
    "zero_anchor_HP3": old_hp3,
    "adaptive_orientation_AO": old_adaptive_orientation,
}


def expected_new(u: Term, branch: str) -> tuple[int, int]:
    m, width = term_size(u), term_size(u, True)
    canonical_width = term_size(normalize(u), True)
    i = occurrences(u, "n")
    if branch == "seed":
        return 43, 47
    if branch == "autonomous_right":
        return 15 + m, 15 + width + 3 * canonical_width
    if branch == "guarded_induction":
        assert normalize(u) == u
        return 23 + 4 * m + 3 * i, 23 + (6 + i) * width + 3 * i
    return (
        13 + m + 2 * i,
        13 + width + 2 * i + (2 + i) * canonical_width,
    )


def expected_old(name: str, u: Term) -> tuple[int, int]:
    m, width = term_size(u), term_size(u, True)
    canonical_width = term_size(normalize(u), True)
    i, j = occurrences(u, "n"), occurrences(u, "a")
    if name == "constancy_K":
        return 25 + 5 * m + 3 * i, 25 + (7 + i) * width + 3 * i
    if name == "equality_bit_factored":
        return 33 + 5 * m + 3 * i, 33 + (7 + i) * width + 3 * i
    if name == "equality_bit_seeded":
        return ((38, 40) if u == ZERO else
                (26 + 5 * m + 3 * i, 26 + (7 + i) * width + 3 * i))
    if name == "equality_bit_seeded_rooted":
        return ((38, 40) if u == ZERO else
                (31 + 4 * m + 3 * i, 31 + (6 + i) * width + 3 * i))
    if name == "equality_mask_core":
        return 35 + 4 * m + 3 * i, 35 + (6 + i) * width + 3 * i
    if name == "four_occurrence_factored_core":
        return 32 + 4 * m + 3 * i, 32 + (6 + i) * width + 3 * i
    if name == "zero_anchor_HP3":
        if i == 0:
            return 20 + m, 20 + width + 2 * canonical_width
        if j == 0:
            return 22 + m, 22 + width + 3 * canonical_width
        return (35 + 7 * m + 4 * i,
                35 + 7 * width + 4 * i + (2 + i) * canonical_width)
    if name == "adaptive_orientation_AO":
        saving = max(j - i, 0)
        return (35 + 7 * m + 4 * i + 3 * j - saving,
                35 + (9 + i) * width + 4 * i + 3 * j - saving)
    raise ValueError(name)


def render(t: Term, limit: int = 180) -> str:
    def walk(x: Term) -> str:
        if x.kind == "var":
            return x.name
        if x.kind == "zero":
            return "0"
        if x.kind == "succ":
            return "S(" + walk(x.args[0]) + ")"
        if x.kind == "rec":
            name = "Q" if x.body == W else "Z" if x.body == ZERO else "R[" + walk(x.body) + "]"
        else:
            name = x.kind
        return name + "(" + ",".join(walk(a) for a in x.args) + ")"
    value = walk(t)
    return value if len(value) <= limit else value[:limit - 3] + "..."


def uses_chi(t: Term) -> bool:
    return (t.kind == "chi" or any(uses_chi(a) for a in t.args)
            or (t.body is not None and uses_chi(t.body)))


def samples() -> list[Term]:
    """Deterministic bounded examples, plus deep descriptors and both guards."""
    result: set[Term] = {ZERO, N, A, SEED}
    exact: dict[int, list[Term]] = {1: [ZERO, N, A]}
    binary = (q, z, chi)
    for size in range(2, 6):
        level = [succ(t) for t in exact[size - 1]]
        for first_size in range(1, size - 1):
            second_size = size - 1 - first_size
            for s in exact[first_size]:
                for t in exact[second_size]:
                    for constructor in binary:
                        level.append(constructor(s, t))
        exact[size] = level
        result.update(level)
    basic = list(sorted(result, key=lambda t: (term_size(t), render(t, 100000))))
    for tail in basic:
        result.add(guard(tail))
        result.add(guard(q(succ(tail), A)))
        result.add(q(succ(tail), A))
        result.add(q(succ(q(succ(tail), N)), A))

    # A discarded argument may contain the already introduced selected symbol.
    selected_body = succ(V)
    result.add(q(succ(succ(N)), rec(selected_body, N, A)))

    # Fully expanded body weights differ substantially from active term sizes.
    nested_body = V
    for depth in range(1, 9):
        nested_body = rec(nested_body, succ(V), rec(nested_body, W, V))
        t = rec(nested_body, N, A)
        result.add(t)
        result.add(guard(t))
        result.add(q(succ(t), A))

    rng = random.Random(20261102)
    pool = basic[:]
    for _ in range(2500):
        s = rng.choice(pool)
        t = rng.choice(pool)
        choice = rng.randrange(6)
        u = (succ(s) if choice == 0 else q(s, t) if choice == 1 else
             z(s, t) if choice == 2 else chi(s, t) if choice == 3 else
             rec(descriptor(normalize(s)), N, A) if choice == 4 else
             guard(q(succ(t), A)))
        if term_size(u) <= 100 and term_size(u, True) <= 500000:
            result.add(u)
            if len(pool) < 6000:
                pool.append(u)
    return sorted(result, key=lambda t: (term_size(t), render(t, 100000)))


def audit() -> dict:
    inputs = samples()
    branches: Counter[str] = Counter()
    minima = {
        name: {
            "active_saving_min": None, "expanded_saving_min": None,
            "active_witness": "", "expanded_witness": "",
        } for name in OLD_EMITTERS
    }
    examples = []
    max_active = max_expanded = 0
    common_grammar = 0
    for u in inputs:
        branch, sentence = new_axiom(u)
        branches[branch] += 1
        actual = formula_size(sentence), formula_size(sentence, True)
        assert actual == expected_new(u, branch), (render(u), branch, actual, expected_new(u, branch))
        expected_quantifiers = (3, 3) if branch == "guarded_induction" else (2, 2)
        assert quantifiers(sentence) == expected_quantifiers
        if not uses_chi(u):
            common_grammar += 1
        max_active = max(max_active, term_size(u))
        max_expanded = max(max_expanded, term_size(u, True))
        for name, emitter in OLD_EMITTERS.items():
            old_sentence = emitter(u)
            old = formula_size(old_sentence), formula_size(old_sentence, True)
            assert old == expected_old(name, u), (name, render(u), old, expected_old(name, u))
            savings = old[0] - actual[0], old[1] - actual[1]
            assert savings[0] > 0 and savings[1] > 0, (name, render(u), branch, actual, old)
            for field, saving in zip(("active", "expanded"), savings):
                key = field + "_saving_min"
                if minima[name][key] is None or saving < minima[name][key]:
                    minima[name][key] = saving
                    minima[name][field + "_witness"] = render(u)
        if u in (ZERO, N, A, SEED, guard(A), guard(N), guard(q(succ(N), A))):
            examples.append({
                "input": render(u), "branch": branch,
                "m": term_size(u), "i": occurrences(u, "n"),
                "j": occurrences(u, "a"), "W": term_size(u, True),
                "V": term_size(normalize(u), True),
                "active_output": actual[0], "expanded_output": actual[1],
            })

    # Freeze check: simultaneous active replacement must leave descriptors intact.
    protected = rec(q(succ(V), W), N, A)
    changed = at(protected, succ(N), ZERO)
    assert changed.body == protected.body
    assert changed.args == (succ(N), ZERO)
    assert normalize(q(succ(q(succ(N), A)), ZERO)) == N
    under_constructor = succ(q(succ(N), A))
    assert normalize(under_constructor) == under_constructor
    discarded_self = q(succ(succ(N)), rec(succ(V), N, A))
    assert normalize(discarded_self) == succ(N)

    return {
        "status": "passed",
        "scope": "Literal syntax trees, active substitution, root normalization and node counts only; no semantic formalization.",
        "comparison_scope": "Eight old recurring templates from six archives, including the optional seeded rooted-zero kernel and adaptive orientation AO, in a common term-grammar extension; fixed overhead omitted from factored old templates, making those numerical comparisons stronger. Original common-grammar examples are counted separately.",
        "old_template_count": len(OLD_EMITTERS),
        "source_archive_count": 6,
        "paired_template_comparisons": len(inputs) * len(OLD_EMITTERS),
        "cases_checked": len(inputs),
        "original_common_grammar_cases": common_grammar,
        "cases_using_equality_bit": len(inputs) - common_grammar,
        "branch_counts": dict(sorted(branches.items())),
        "largest_active_input": max_active,
        "largest_fully_expanded_input": max_expanded,
        "formulas_verified": {
            "seed": ["43", "47"],
            "left_computation": ["13+m+2i", "13+W+2i+(2+i)V"],
            "autonomous_right": ["15+m", "15+W+3V"],
            "guarded_induction": ["23+4m+3i", "23+(6+i)W+3i"],
        },
        "all_sampled_comparisons_strict": True,
        "minimum_observed_savings": minima,
        "examples": examples,
        "seed_definition": "Literal Q(S(n),a); it supplies separation and the equality-bit laws.",
        "old_seed_exception_checked": "Both old seeded equality-bit emitters (ordinary and rooted-zero) have 38 active / 40 expanded nodes at literal 0.",
        "schema_note": "The infinite strict-dominance claim follows from the displayed algebraic formulas, not from bounded samples.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("schema_results.json"))
    args = parser.parse_args()
    result = audit()
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "cases_checked": result["cases_checked"],
                      "branch_counts": result["branch_counts"], "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
