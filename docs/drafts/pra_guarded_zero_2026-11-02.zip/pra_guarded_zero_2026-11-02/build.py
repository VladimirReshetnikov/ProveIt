#!/usr/bin/env python3
"""Rebuild the local syntax audit, LaTeX report, and optional Lean kernel."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", help="Path to Lean 4.19.0 (optional)")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    verification = root / "verification"
    verification.mkdir(exist_ok=True)
    results: dict[str, object] = {}

    def run(label: str, command: list[str], cwd: Path = root) -> str:
        process = subprocess.run(command, cwd=cwd, text=True,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT)
        (verification / (label + ".log")).write_text(process.stdout)
        results[label] = {"command": command, "exit_code": process.returncode}
        if process.returncode:
            raise RuntimeError(f"{label} failed; see verification/{label}.log")
        return process.stdout

    try:
        run("schema_check", [sys.executable, "checks/check_schema.py"])
        schema_output = root / "checks/schema_results.json"
        if schema_output.exists():
            shutil.copy2(schema_output, verification / "schema_results.json")
            schema_output.unlink()
        run("latex_build", ["latexmk", "-pdf", "-interaction=nonstopmode",
                            "-halt-on-error", "report.tex"])
        latex_log = (root / "report.log").read_text(errors="replace")
        bad = [line for line in latex_log.splitlines()
               if "Overfull" in line or "undefined references" in line
               or "undefined on input" in line or "Missing character" in line]
        results["latex_quality"] = {"unresolved_or_overfull_lines": bad}
        if bad:
            raise RuntimeError("LaTeX quality gate found unresolved/overfull text")
        if args.lean:
            version = run("lean_version", [args.lean, "--version"])
            output = run("lean_kernel", [args.lean, "formal/GuardedZeroInduction.lean"])
            audits = [line for line in output.splitlines()
                      if "does not depend on any axioms" in line]
            if len(audits) != 7:
                raise RuntimeError("Expected seven empty Lean axiom audits")
            results["lean_audits"] = {"empty": len(audits), "version": version.strip()}
        results["status"] = "passed"
        results["report_sha256"] = hashlib.sha256((root / "report.pdf").read_bytes()).hexdigest()
    except Exception as error:
        results["status"] = "failed"
        results["error"] = str(error)
        (verification / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")
        print(str(error), file=sys.stderr)
        return 1
    (verification / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
