ZERO-GUARDED INDUCTION: A SMALLER AXIOMATIZATION OF PRA
Prepared for Vladimir Reshetnikov, November 2, 2026

Main result
===========
Induction is required only for literal zero-guarded terms
G_t(n,a)=Z(chi(n,0),t(n,a)), with chi=1 on equality and 0 otherwise.
Their zero base follows by computation, so only progress is a premise.
All quantifier-free induction is recovered under local hypotheses, then
one-parameter triangular pairing recovers every finite parameter list.

The complete optimized presentation uses one generated binary-recursion
signature and one axiom emitter with four syntactic cases. It has a common
conservative definitional extension with first-order PRA, with unchanged
carrier/equality and identity composites. The matching constructive proof
also gives the corresponding theorem for intuitionistic PRA separately.

Deliverables
============
report.pdf, report.tex, sections/*.tex : complete article and source
AXIOMS.txt                          : exact standalone axiom specification
source_manifest.json                : all six pinned baseline archive hashes
checks/check_schema.py              : executable AST/count comparison audit
verification/schema_results.json    : recorded 6,035-input audit results
formal/GuardedZeroInduction.lean     : constructive local proof kernel
formal/guarded_zero_output.txt       : actual successful Lean compiler output
formal/guarded_zero_verification.json: kernel source hash and audit metadata
formal/SCOPE.txt                    : precise formalization boundary
build.py                           : reproducible checks, PDF, optional Lean
verification/build_results.json     : local final build record
verification/pdf_quality.json       : PDF and visual review record
SHA256SUMS                         : final file checksums, excluding itself

Rebuild
=======
Requirements: Python 3.10+, a LaTeX distribution with pdflatex/latexmk and
the common packages used in report.tex. Lean is optional for rebuilding
the PDF and syntax audit. No Python third-party dependencies are required.

From this directory:
  python3 build.py

To rerun the exact formal kernel too (Lean 4.19.0):
  python3 build.py --lean /absolute/path/to/lean

To run only the syntax audit:
  python3 checks/check_schema.py

The report can also be compiled directly:
  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

Verification limits
===================
The full bi-interpretation is a written proof, independently reviewed.
Lean verifies the local guard/induction-transfer theorem on an arbitrary
carrier under explicit hypotheses; it does not formalize all syntax,
pairing, the PR compiler, or the interpretation composites. All seven
axiom audits in the delivered local kernel are empty.

The Python checker verifies actual syntax/counts. Finite sampling does
not prove semantic equivalence or the universal size inequalities; those
are proved in the article. Comparisons distinguish the actual shared
grammar from matched templates in the extension containing chi.

The improvement is relative to the six actual archives at ProveIt commit
d46d2b97cb3c4d4f3a0154fc5884ea42ffcd5966, including optional smaller
forms. It is not an absolute minimum over arbitrary logical encodings.
The inherited normalization, extra bit, four cases, and seed bookkeeping
are explicitly disclosed. No GitHub files were modified by this package.
