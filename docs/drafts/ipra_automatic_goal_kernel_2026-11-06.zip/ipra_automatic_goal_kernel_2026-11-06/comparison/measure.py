"""Measure complete acceptance programs, retaining all application logic."""
import ast
import csv
import hashlib
import io
import json
import platform
import sys
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
FIELDS = ('ast_nodes', 'source_tokens', 'normalized_tokens', 'normalized_bytes')


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    doc = node.body.pop(0)
                    spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    normalized = ast.unparse(tree) + '\n'

    def count(text, omitted=()):
        return sum(t.type not in IGNORED and not any(a <= t.start and t.end <= b for a, b in omitted)
                   for t in tokenize.generate_tokens(io.StringIO(text).readline))

    return {'source': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(raw).hexdigest(),
            'ast_nodes': sum(1 for _ in ast.walk(tree)), 'source_tokens': count(source, spans),
            'normalized_tokens': count(normalized), 'normalized_bytes': len(normalized.encode()),
            'raw_bytes': len(raw)}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    labels = {
        'automatic_checker.py': 'Automatic, strict open',
        'automatic_checker_demand.py': 'Automatic, demand open',
        'goal_calculus_checker.py': 'Goal calculus',
        'reconstruction_checker.py': 'Reconstruction, demand theorem',
        'reconstruction_checker_strict.py': 'Reconstruction, strict theorem',
        'reconstruction_checker_open.py': 'Reconstruction, demand open',
        'reconstruction_checker_open_strict.py': 'Reconstruction, strict open',
        'obligation_checker.py': 'Obligation calculus',
        'small_checker.py': 'Small kernel',
    }
    for archive in manifest['archives']:
        for entry in archive['programs']:
            row = measure(ROOT / entry['source'])
            if row['sha256'] != entry['sha256']:
                raise ValueError('Baseline changed: ' + entry['source'])
            row.update(label=labels[Path(entry['source']).name], interface=entry['interface'])
            rows.append(row)
    envelope = {k: min(x[k] for x in rows) for k in FIELDS}
    open_envelope = {k: min(x[k] for x in rows if x['interface'] == 'open sequent') for k in FIELDS}
    candidates = {key: measure(ROOT / filename) for key, filename in
                  [('strict_theorem', 'checker.py'), ('strict_open', 'checker_open.py'),
                   ('demand_theorem', 'checker_demand.py')]}
    comparisons = {}
    for key, row in candidates.items():
        target = open_envelope if key == 'strict_open' else envelope
        comparisons[key] = {k: row[k] < target[k] for k in FIELDS}
    if not all(all(x.values()) for x in comparisons.values()):
        raise ValueError('A declared strict improvement does not hold')
    result = {'status': 'passed', 'python': sys.version, 'python_version': platform.python_version(),
              'repository': manifest['repository'], 'commit': manifest['commit'],
              'boundary': 'Entire standalone acceptance program; only comments and docstrings excluded.',
              'baselines': rows, 'all_variant_envelope': envelope, 'open_envelope': open_envelope,
              'candidates': candidates, 'strictly_below': comparisons}
    out = ROOT / 'results'
    out.mkdir(exist_ok=True)
    (out / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (out / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=['source', 'sha256', *FIELDS, 'raw_bytes'], extrasaction='ignore')
        writer.writeheader()
        writer.writerows([*rows, *candidates.values()])
    macros = {'EnvelopeAST': envelope['ast_nodes'], 'EnvelopeTokens': envelope['normalized_tokens'],
              'EnvelopeBytes': envelope['normalized_bytes']}
    for name, key in [('Theorem', 'strict_theorem'), ('Open', 'strict_open'), ('Demand', 'demand_theorem')]:
        for suffix, field in [('AST', 'ast_nodes'), ('SourceTokens', 'source_tokens'),
                              ('Tokens', 'normalized_tokens'), ('Bytes', 'normalized_bytes')]:
            macros[name + suffix] = candidates[key][field]
    (out / 'metrics.tex').write_text(''.join('\\newcommand{\\' + k + '}{' + f'{v:,}' + '}\n' for k, v in macros.items()))
    lines = [r'\begin{table}[htbp]\centering\small', r'\begin{tabular}{lrrrr}', r'\toprule',
             r'Complete program & AST & Source tokens & Norm. tokens & Norm. bytes\\', r'\midrule']
    for row in rows:
        lines.append(row['label'] + ' & ' + ' & '.join(f'{row[k]:,}' for k in FIELDS) + r'\\')
    lines += [r'\midrule', 'Current all-variant minimum & ' + ' & '.join(f'{envelope[k]:,}' for k in FIELDS) + r'\\',
              'Current open minimum & ' + ' & '.join(f'{open_envelope[k]:,}' for k in FIELDS) + r'\\', r'\midrule']
    for key, label in [('strict_theorem', 'New strict theorem'), ('strict_open', 'New strict open'),
                       ('demand_theorem', 'New demand theorem')]:
        lines.append(r'\textbf{' + label + '} & ' + ' & '.join(r'\textbf{' + f'{candidates[key][k]:,}' + '}' for k in FIELDS) + r'\\')
    lines += [r'\bottomrule\end{tabular}',
              r'\caption{All nine current entry points and the three new complete programs. The open candidate is compared to the open-interface envelope; both theorem candidates beat the envelope of every current variant.}',
              r'\label{tab:metrics}\end{table}']
    (out / 'comparison_table.tex').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'all_variant_envelope', 'open_envelope', 'candidates']}, indent=2))


if __name__ == '__main__':
    main()
