A SMALLER COMPLETE PRESENTATION OF iPRA
Automatic introduction and reconstruction from expected goals
Research report prepared for Vladimir Reshetnikov -- 6 November 2026

RESULT

The strict theorem checker in this package is below every coordinate of the
observed complexity envelope of the nine complete acceptance programs in the
five current ProveIt drafts. A strict open-sequent version also beats every
coordinate of the seven comparators having that same public interface.

                                AST     Source     Normalized    Normalized
                              nodes     tokens         tokens         bytes
All nine current programs       582        569            569         1,762
New strict theorem              580        562            564         1,734
New demand theorem              568        552            554         1,689

Seven current open programs     605        580            582         1,811
New strict open                 604        579            581         1,793

The two current-program rows are coordinatewise minima; their coordinates
need not all belong to one program. The complete source files, the exact
counting method, and the recorded measurements are included. All application-
specific acceptance code is counted: syntax validation, the scope table,
substitution, arithmetic and logical rules, JSON input, exception handling,
and the command-line verdict. Only comments and leading docstrings are
excluded from the primary measurements. The common runtime is CPython
3.12.14 with its standard json and sys libraries.

This is a strict, reproducible reduction relative to a pinned finite corpus.
It does not establish that no smaller axiomatization or checker exists.

THE MATHEMATICAL THEORY

The language has one number sort, zero, successor, and an initialized
primitive-recursion binder. Formulas use equality, guarded universal
quantification Pi x [H; B], and existential quantification. The paper gives
all formation rules, logical rules, computation equations, and numerical
principles; it reconstructs the usual intuitionistic connectives and
quantifiers and the full quantifier-free induction scheme.

The presentation combines two advances already present in the drafts:
automatic introduction and reconstruction of proof instructions from the
expected goal. The remaining introduction marker is erased; hypothesis
selection uses membership; and existential elimination shares the fresh-
variable continuation with the introduction rules. The certificate syntax
uses null for a computation proof, a singleton list for guarded introduction,
and a witness/proof pair for existential introduction. The arithmetic terms
and provable well-formed sequents remain those of the automatic calculus.

Automatic introduction requires a substantive completeness argument. When
an ordinary introduction has exactly the shape selected for a numerical
rule, a closed recursor term equal to zero perturbs the guard. Equality
transport then restores the requested conclusion. The report includes this
closed-zero detour and its proof, rather than assuming that erasing an
induction selector preserves every old certificate unchanged.

The paper supplies a written proof that the ordinary first-order theory
presented by the native calculus is bi-interpretable with full first-order
intuitionistic primitive recursive arithmetic. Both interpretations use
the whole number domain. Fixed-recursion uniqueness, with all parameters
held fixed, proves the interpretation round trips internally; identity
equality is the definable isomorphism in each direction. Equiconsistency
follows, with native contradiction 0 = S0 corresponding to ordinary
falsity. This is stronger than agreement only on closed numerical equations.

THREE COMPLETE ACCEPTANCE PROGRAMS

checker.py
    Recommended strict theorem entry point. Public input is [goal, proof].
    It starts with an empty context and validates every numerical witness,
    including an unused one. Free numerical variables are arbitrary
    parameters; the input need not be literally closed. The examples/
    directory supplies 18 literally closed theorem certificates.

checker_open.py
    Strict open-sequent entry point. Public input is
    [goal, proof, hypothesis_0, hypothesis_1, ...]. It validates every public
    hypothesis, even an unused one, and all numerical witnesses. It supports
    a comparison retaining the predecessors' open-sequent interface.

checker_demand.py
    Smaller theorem entry point with the same [goal, proof] interface.
    Like several earlier comparators, it ignores a universal-witness field
    that occurs in neither matrix of the elimination. Replacing that unused
    field by zero gives a strict inference with identical formulas. Every
    actually demanded witness and every public formula is validated. This
    variant proves exactly the same well-formed theorems as checker.py.

Each program is standalone and imports only json and sys. Acceptance means
the complete program prints ACCEPT and exits zero. Rejection prints REJECT
and exits nonzero. No check depends on Python assert, so optimization does
not disable validation. The internal function check(goal, proof, context)
requires an already validated context; a normal return alone is insufficient
because it must return True. Use the complete CLI for untrusted input.

RUN AND REPRODUCE

Use Python 3.10 or later. Use Python 3.12.14 to reproduce the recorded AST
normalization exactly. No third-party Python modules or network connection
are needed. Run these commands from the extracted package directory:

    python3 checker.py examples/reflexivity.json
    python3 checker_open.py examples_open/automatic_collision.json
    python3 checker_demand.py examples/residual.json
    python3 reproduce.py

The final command reruns the complete size comparison and the available
validation drivers. Individual components can also be run:

    python3 comparison/measure.py
    python3 validate_translations.py

To rebuild the supplied paper with a standard pdfLaTeX installation:

    python3 build.py

To rebuild the archive and checksum manifest:

    python3 package.py

LaTeX is needed only to rebuild report.pdf, not to check certificates or
repeat the Python validation. The package includes every TeX source needed
by report.tex.

EVIDENCE AND ITS LIMITS

The translation driver records 231 positive translation/readback runs:
19 automatic-source examples, 194 frozen accepted fixtures, and 18 closed
theorem examples from the reconstruction draft. Each translated proof is
checked by both strict cores and read back into a proof accepted by the old
strict automatic checker, preserving its exact sequent. All 18 closed
examples additionally pass the complete theorem CLI. These are counts of
recorded runs, not claims of 231 distinct theorems. The driver also records
direct negative regression cases.

The independent named-binder audit compares 646 inputs under each of the
three public interfaces (1,938 candidate/reference comparisons): 209 targeted
cases, 37 packaged examples, and 400 deterministic mutations. It records zero
disagreements. A further 588 normal/optimized certificate CLI runs and 51 raw
JSON/argument/file checks all pass. Four specified rule/interface fault
injections are detected by the sensitivity checks. These are overlapping
implementation checks, not independent proofs of mathematical consistency.

See results/translation_checks.json for those records and results/*.json for
the complete, current boundary-audit and measurement results. Supporting
translators, frozen reference checkers, and validation oracles are never
imported by any of the three acceptance programs.

Finite executable tests do not establish the universal mathematical
soundness or completeness statements. Those statements are justified by
the written proofs in report.pdf. The package does not claim Lean or Rocq
formalization, an internal consistency proof, or absolute minimality.
The ideal completeness statement concerns finite derivations without a
particular machine's physical recursion, memory, and time limits.

CONTENTS

    report.pdf                       Compiled mathematical paper.
    report.tex, sections/*.tex        Complete editable TeX sources.
    checker.py                       Strict theorem acceptance program.
    checker_open.py                  Strict open-sequent program.
    checker_demand.py                Smaller theorem companion.
    FORMAT.txt                       Exact term, formula, and proof formats.
    examples/                        18 closed theorem certificates.
    examples_open/                   Automatic-calculus example sequents.
    adapter.py                       Untrusted certificate erasure/readback.
    validate_translations.py          Offline translation regression driver.
    validation/                      Frozen sources and audit support.
    comparison/                      Nine unchanged comparators and provenance.
    results/                         Recorded evidence and measurement tables.
    reproduce.py                     Combined offline reproduction command.
    build.py                         PDF rebuild command.
    package.py                       Archive and checksum rebuild command.
    ATTRIBUTION.txt                   Exact inherited and new contributions.
    LICENSE_SOURCE.txt               License retained from the source drafts.

SOURCE SNAPSHOT

Repository: VladimirReshetnikov/ProveIt
Commit:     1d1b154fb3f071169b6a003b3f9d727166880006
Directory:  docs/drafts
URL:
https://github.com/VladimirReshetnikov/ProveIt/tree/1d1b154fb3f071169b6a003b3f9d727166880006/docs/drafts

comparison/manifest.json identifies all five source archives and all nine
current comparator entry points, with archive Git blob identities and
SHA-256 digests. The comparison remeasures these actual files rather than
reusing an older frontier quoted inside the source reports. See
ATTRIBUTION.txt for the mathematical and implementation lineage.

FURTHER RESEARCH

The paper ends with further research questions: formalize the complete
acceptance relation and both interpretation round trips; find a smaller
substitution-stable introduction principle; simplify the arithmetic term
basis without assuming a primitive-recursive universal evaluator; measure
the tradeoff between checker size and certificate size; compare programs
on a common small abstract machine; and seek a different complete logical
basis that removes a primitive elimination mechanism without concealing
equivalent work in schema recognition.
