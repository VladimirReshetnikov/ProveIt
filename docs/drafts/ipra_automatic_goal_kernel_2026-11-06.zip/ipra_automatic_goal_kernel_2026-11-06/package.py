"""Create a deterministic ZIP containing the complete deliverable."""
from pathlib import Path
import hashlib
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT.parent / 'output'
OUTPUT.mkdir(exist_ok=True)
EXCLUDED = {'.aux', '.log', '.out', '.toc', '.pyc'}


def payloads():
    return [p for p in sorted(ROOT.rglob('*'))
            if p.is_file() and p.suffix not in EXCLUDED and '__pycache__' not in p.parts
            and p.name != 'MANIFEST.sha256']


entries = payloads()
(ROOT / 'MANIFEST.sha256').write_text(''.join(
    hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix() + '\n'
    for p in entries))
archive = OUTPUT / (ROOT.name + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for p in sorted([*entries, ROOT / 'MANIFEST.sha256']):
        name = ROOT.name + '/' + p.relative_to(ROOT).as_posix()
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 12, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        stream.writestr(info, p.read_bytes())
with zipfile.ZipFile(archive) as stream:
    if stream.testzip() is not None:
        raise ValueError('ZIP integrity check failed')
    for p in entries:
        if stream.read(ROOT.name + '/' + p.relative_to(ROOT).as_posix()) != p.read_bytes():
            raise ValueError('Archive payload changed: ' + str(p))
pdf = OUTPUT / (ROOT.name + '.pdf')
shutil.copy2(ROOT / 'report.pdf', pdf)
print('Created ' + archive.name + ' (' + str(archive.stat().st_size) + ' bytes)')
print('Created ' + pdf.name + ' (' + str(pdf.stat().st_size) + ' bytes)')
