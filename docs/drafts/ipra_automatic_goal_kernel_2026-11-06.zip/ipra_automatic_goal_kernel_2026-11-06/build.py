"""Rebuild the supplied paper with an ordinary pdfLaTeX installation."""
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
engine = shutil.which('pdflatex')
if engine is None:
    raise SystemExit('Install pdfLaTeX to rebuild report.pdf. The compiled PDF is supplied.')

def typeset(extra=()):
    for _ in range(3):
        result = subprocess.run([engine, *extra, '-interaction=nonstopmode', '-halt-on-error',
                                 '-file-line-error', 'report.tex'], cwd=ROOT,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (ROOT / 'results/latex_build.txt').write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-12000:])
            raise SystemExit(result.returncode)
    print('Built report.pdf')


found = subprocess.run(['kpsewhich', 'pdflatex.fmt'], capture_output=True, text=True).stdout.strip()
if found:
    typeset()
else:
    with tempfile.TemporaryDirectory(prefix='ipra-tex-format-') as directory:
        result = subprocess.run(['pdftex', '-ini', '-jobname=pdflatex', '-progname=pdflatex',
                                 '-etex', 'pdflatex.ini'], cwd=directory,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        if result.returncode:
            print(result.stdout[-12000:])
            raise SystemExit(result.returncode)
        typeset(['-fmt=' + str(Path(directory) / 'pdflatex.fmt')])
