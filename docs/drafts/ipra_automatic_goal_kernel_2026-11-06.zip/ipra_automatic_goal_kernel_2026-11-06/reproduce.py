"""Reproduce all measurements and executable audits offline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
RESULTS.mkdir(exist_ok=True)
if sys.version_info < (3, 10):
    raise SystemExit('Python 3.10 or later is required')
commands = [
    [sys.executable, '-B', 'comparison/measure.py'],
    [sys.executable, '-B', 'validate_translations.py'],
    [sys.executable, '-B', 'validation/audit.py', '--kernels', str(ROOT),
     '--output', str(RESULTS / 'independent_audit.json')],
    [sys.executable, '-B', 'validation/fault_sensitivity.py', '--kernels', str(ROOT),
     '--output', str(RESULTS / 'fault_sensitivity.json')],
]
logs = []
for command in commands:
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    logs.append(result.stdout + result.stderr)
    if result.returncode:
        (RESULTS / 'reproduction_log.txt').write_text('\n'.join(logs))
        print(logs[-1])
        raise SystemExit(result.returncode)
(RESULTS / 'reproduction_log.txt').write_text('\n'.join(logs))
metrics = json.loads((RESULTS / 'metrics.json').read_text())
translations = json.loads((RESULTS / 'translation_checks.json').read_text())
audit = json.loads((RESULTS / 'independent_audit.json').read_text())
faults = json.loads((RESULTS / 'fault_sensitivity.json').read_text())
if any(item['status'] != 'passed' for item in [metrics, translations, audit, faults]):
    raise SystemExit('A reproduction component failed')
groups = translations['groups']
positive = sum(value for key, value in groups.items() if key != 'negative')
cases = sum(audit['case_groups'].values())
summary = {
    'status': 'passed', 'python': sys.version,
    'snapshot_commit': metrics['commit'], 'current_complete_programs': len(metrics['baselines']),
    'strict_improvements': metrics['strictly_below'],
    'positive_translation_records': positive,
    'translation_groups': groups,
    'independent_cases_per_variant': cases,
    'independent_variants': len(audit['candidate_sha256']),
    'independent_candidate_reference_disagreements': len(audit['failures']),
    'certificate_cli_runs': audit['counts']['cli_runs'],
    'raw_cli_runs': audit['counts']['raw_cli_runs'],
    'qualification': 'Finite record counts overlap; they are not independent mathematical proofs.'
}
(RESULTS / 'reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
tex = r'''\paragraph{Proof translations and readback.}
The final self-contained reproduction passed POSITIVE positive records:
AUTO automatic-source examples, FROZEN frozen accepted source certificates,
and CLOSED closed theorem examples. Each translated proof was accepted by
both strict checker functions and read back into an accepted prior strict
proof of the exact same exterior sequent. The CLOSED closed examples also
passed the complete new theorem command-line interface. NEGATIVE direct
malformed or false certificate records were rejected.

\paragraph{Independent rule and boundary audit.}
A separate rule interpreter uses distinct named binders and independently
implemented substitution; it never calls candidate syntax or substitution
helpers to determine the expected result. It compared CASES inputs with
each of the three complete parsed-entry boundaries: TARGETED targeted
records, PACKAGED packaged examples, and MUTATIONS deterministic mutations.
There were zero candidate/reference disagreements. The audit additionally
passed CLI actual certificate process runs with ordinary and optimized
Python, plus RAWCLI raw-JSON, argument-count, and file-boundary process
checks. The cases cover eigenvariable escape, retained-context lifting,
forbidden full quantified induction, exact recursor computation, equality
motives, strict and unused witnesses, malformed public syntax, and
failed-major hypothesis fallback.

Four deliberately injected rule or interface defects were also detected:
unrestricted quantified induction, missing existential-goal lifting,
missing strict-witness validation, and missing public-goal formation.
These are sensitivity checks for the audit, not four inconsistency proofs;
the witness case specifically tests the strict format rather than the
permitted demand convention.

The record groups overlap between suites and variants. They are not
counts of distinct mathematical theorems. Complete hashes, labeled
records, results, and runtime information are retained in \code{results/}.
'''
values = {
    'POSITIVE': positive, 'AUTO': groups['automatic_example'],
    'FROZEN': groups['frozen_positive'], 'CLOSED': groups['closed_example'],
    'NEGATIVE': groups['negative'], 'CASES': cases,
    'PACKAGED': audit['case_groups']['packaged_example'],
    'MUTATIONS': audit['case_groups']['deterministic_mutation'],
    'TARGETED': cases - audit['case_groups']['packaged_example'] - audit['case_groups']['deterministic_mutation'],
    'RAWCLI': audit['counts']['raw_cli_runs'], 'CLI': audit['counts']['cli_runs'],
}
for key in sorted(values, key=len, reverse=True):
    tex = tex.replace(key, str(values[key]))
(RESULTS / 'validation.tex').write_text(tex)
print(json.dumps(summary, indent=2))
