"""Finite regression and exact certificate readback for the new kernels."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from adapter import from_automatic, to_automatic

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
AUTO = HERE / 'validation/frozen_automatic'
RECON = HERE / 'validation/frozen_reconstruction'


def load(name, path):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


strict = load('new_strict', HERE / 'checker.py')
opened = load('new_open', HERE / 'checker_open.py')
automatic = load('source_auto', AUTO / 'checker.py')
compiler = load('source_auto_compiler', AUTO / 'validation/translate.py')
sys.path.insert(0, str(AUTO / 'validation'))
support = load('source_support', AUTO / 'validation/support.py')
reconstructor = load('source_reconstructor', RECON / 'translate_proofs.py')
recon_kernel = load('source_recon_kernel', RECON / 'checker_strict.py')
records = []


def accepts(module, data):
    try:
        goal, proof, *context = data
        for a in context:
            module.subst(a)
        return module.check(goal, proof, context) is True
    except Exception:
        return False


def check_record(name, data, kind):
    if not accepts(automatic, data):
        raise ValueError(('Invalid automatic source', name))
    goal, proof, *context = data
    translated = [goal, from_automatic(proof), *context]
    if not accepts(strict, translated) or not accepts(opened, translated):
        raise ValueError(('Rejected translation', name))
    readback = [goal, to_automatic(goal, translated[1], context, strict.subst), *context]
    if not accepts(automatic, readback):
        raise ValueError(('Rejected readback', name))
    records.append({'name': name, 'kind': kind, 'sequent_preserved': True,
                    'strict_accepts': True, 'automatic_readback_accepts': True})
    return translated


for path in sorted((AUTO / 'examples').glob('*.json')):
    data = json.loads(path.read_text())
    translated = check_record(path.stem, data, 'automatic_example')
    output = HERE / 'examples_open' / path.name
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(translated, indent=2) + '\n')
for filename, data, entry in support.goal_corpus(strict=True):
    check_record(filename, compiler.translate_data(data), 'frozen_positive')
for path in sorted((RECON / 'examples').glob('*.json')):
    if path.name == 'manifest.json':
        continue
    data = json.loads(path.read_text())
    goal, proof = data
    proof = reconstructor.normalize_accepted(recon_kernel, goal, proof, [])
    old_proof = reconstructor.to_original(goal, proof, [])
    translated = check_record(path.stem, compiler.translate_data([goal, old_proof]), 'closed_example')
    output = HERE / 'examples' / path.name
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(translated, indent=2) + '\n')
    completed = subprocess.run([sys.executable, str(HERE / 'checker.py'), str(output)],
                               capture_output=True, text=True)
    if completed.returncode != 0 or completed.stdout.strip() != 'ACCEPT':
        raise ValueError(('Theorem CLI failed', path.name, completed.stdout, completed.stderr))

negative = [
    ('false_eq', [['=', -1, ['s', -1]], None]),
    ('false_computation', [['=', ['r', -1, -1, -1], ['s', -1]], None]),
    ('malformed_goal', [['=', True, True], None]),
    ('wrong_arity', [['=', ['s', -1, -1], -1], None]),
    ('formula_as_term', [['=', ['ex', ['=', 0, 0]], -1], None]),
    ('unproven_major', [['=', -1, ['s', -1]], [['=', -1, ['s', -1]], None, ['=', 0, ['s', -1]], None]]),
]
for name, data in negative:
    if accepts(strict, data):
        raise ValueError(('Unsound acceptance', name))
    records.append({'name': name, 'kind': 'negative', 'rejected': True})

result = {'status': 'passed', 'records': records, 'groups': {
    key: sum(record['kind'] == key for record in records)
    for key in sorted(set(record['kind'] for record in records))},
    'qualification': 'Finite executable evidence; metatheory requires the written proof.'}
(HERE / 'results/translation_checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))
