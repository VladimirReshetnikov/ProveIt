"""Confirm that four targeted cases detect four specific checker defects.

Only private in-memory program copies are modified. This driver never edits a
checker file. These are sensitivity checks, not alternative accepted kernels.
"""
import argparse
import hashlib
import json
from pathlib import Path
import types

import audit
import reference


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kernels", type=Path, default=None)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("fault_sensitivity_results.json"))
    args = parser.parse_args()
    kernels = args.kernels or audit.find_kernels()
    source_path = kernels / "checker.py"
    source = source_path.read_text(encoding="utf-8")
    cases = {row["name"]: row for row in audit.fixtures()}
    faults = [
        ("unrestricted_quantified_induction",
         "h = b if b[0] == '=' else h", "h = b",
         "forbidden_full_induction_hypothesis_for_existential_matrix"),
        ("missing_existential_goal_lift",
         "b, q, h = subst(a), *args, *parts", "b, q, h = a, *args, *parts",
         "closed_existential_eigenvariable_escape"),
        ("missing_strict_witness_validation",
         "                subst(t, formula=tag == '=')\n", "",
         "unused_universal_witness_0"),
        ("missing_goal_formation_validation",
         "    subst(a)\n", "",
         "unused_recursor_update_is_validated_0"),
    ]
    rows = []
    original = audit.load_module(source_path, "sensitivity_original")
    for name, old, replacement, case_name in faults:
        if source.count(old) != 1:
            raise ValueError("Source text no longer supports the specified fault: " + name)
        private = types.ModuleType("fault_injected_" + name)
        exec(compile(source.replace(old, replacement), name, "exec"), private.__dict__)
        data = cases[case_name]["data"]
        reference_outcome = reference.accepts(data)
        original_outcome = audit.candidate_accept(original, data, False)
        altered_outcome = audit.candidate_accept(private, data, False)
        if reference_outcome or original_outcome or not altered_outcome:
            raise ValueError("Targeted test failed to distinguish the intended fault: " + name)
        rows.append({"fault": name, "case": case_name,
                     "independent_reference": reference_outcome,
                     "unchanged_checker": original_outcome,
                     "fault_injected_copy": altered_outcome,
                     "detected": True})
    result = {"status": "passed", "tests": rows,
              "candidate_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest(),
              "qualification": "Specific finite sensitivity tests; files were not modified."}
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
