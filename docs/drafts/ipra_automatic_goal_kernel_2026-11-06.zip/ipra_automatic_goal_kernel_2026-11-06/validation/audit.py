"""Reproducible independent finite audit of the compact iPRA checkers.

Run: python3 audit.py --kernels /absolute/path/to/package

This driver and its two companion modules are untrusted validation support.
Expected outcomes use named_reference-style substitution from named_oracle.py
and the separate rule interpretation in reference.py. Candidate helpers are
called only to obtain candidate outcomes, never to establish expected results.
The audit also invokes each complete CLI normally and under Python -O.
"""
import argparse
import collections
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

from named_oracle import oracle
import reference


HERE = Path(__file__).resolve().parent
Z = -1


def S(t):
    return ["s", t]


def R(n, a, h):
    return ["r", n, a, h]


def E(s, t):
    return ["=", s, t]


def P(h, b):
    return ["pi", h, b]


def X(b):
    return ["ex", b]


T = E(Z, Z)
F = E(Z, S(Z))


def refl(t):
    """Equality reflexivity derived from two R0 equations, not postulated."""
    major = E(R(Z, t, Z), t)
    return [major, None, E(0, oracle(t, formula=False)), None]


def fixtures():
    rows = []

    def add(name, data, expected, category, demand=None, cli=False):
        rows.append({"name": name, "data": copy.deepcopy(data),
                     "expected": expected,
                     "demand_expected": expected if demand is None else demand,
                     "category": category, "cli": cli})

    add("closed_reflexivity", [T, refl(Z)], True, "arithmetic", cli=True)
    add("free_parameter_reflexivity", [E(0, 0), refl(0)], True, "scope", cli=True)
    add("false_closed_equality", [F, 0], False, "arithmetic", cli=True)
    add("equation_identity", [P(E(0, 0), E(0, 0)), [0]], True, "logic", cli=True)
    add("equation_constant_automatic_case", [P(T, T), [0]], True, "induction", cli=True)
    add("quantified_constant_automatic_case", [P(X(T), X(T)), [0]],
        True, "induction", cli=True)
    add("nested_identity", [P(T, P(E(0, 1), E(0, 1))), [[0]]],
        True, "scope", cli=True)
    add("parameter_witness", [X(E(0, 1)), [0, 0]], True, "scope", cli=True)
    add("fixed_zero_witness", [X(E(0, Z)), [Z, 0]], True, "logic", cli=True)

    exists_zero = X(E(0, Z))
    exists_zero_proof = [Z, 0]
    add("closed_existential_eigenvariable_escape",
        [E(0, Z), [exists_zero, exists_zero_proof, 0]],
        False, "eigenvariable", cli=True)
    add("open_existential_eigenvariable_escape",
        [E(0, Z), [exists_zero, 0, 0], exists_zero],
        False, "eigenvariable", cli=True)
    add("existential_elimination_preserves_outer_parameter",
        [E(0, 0), [exists_zero, exists_zero_proof, refl(1)]],
        True, "eigenvariable", cli=True)
    add("retained_context_is_lifted",
        [E(0, Z), [exists_zero, exists_zero_proof, 0], E(0, Z)],
        True, "eigenvariable", cli=True)
    add("guarded_eigenvariable_escape",
        [P(E(0, 0), E(0, Z)), [0], E(0, Z)],
        False, "eigenvariable", cli=True)
    nested_body = P(T, X(E(2, Z)))
    add("existential_escape_below_two_formula_binders",
        [nested_body, [X(nested_body), 0, 0], X(nested_body)],
        False, "eigenvariable", cli=True)
    dead_update = E(R(Z, Z, 2), R(Z, Z, 2))
    add("existential_escape_in_unused_recursor_update",
        [dead_update, [X(dead_update), 0, 0], X(dead_update)],
        False, "eigenvariable", cli=True)

    nat_body = E(R(0, Z, S(0)), 0)
    nat_base = E(R(Z, Z, S(0)), Z)
    nat_motive = E(R(S(1), Z, S(0)), S(0))
    nat_step = [nat_body, 0, nat_motive, None]
    add("equational_induction_uses_local_hypothesis",
        [P(nat_base, nat_body), [nat_step]], True, "induction", cli=True)
    add("equational_induction_false_step",
        [P(T, E(0, Z)), [0]], False, "induction", cli=True)
    add("general_numerical_cases",
        [P(X(E(0, Z)), X(E(0, 1))), [[S(0), 0]]], True, "induction", cli=True)
    b = X(E(1, 1))
    forbidden = [b, 0, [Z, refl(S(2))]]
    add("forbidden_full_induction_hypothesis_for_existential_matrix",
        [P(X(T), b), [forbidden]], False, "induction", cli=True)

    add("correct_computation_zero", [E(R(Z, S(0), 1), S(0)), None],
        True, "computation", cli=True)
    add("false_computation_zero", [E(R(Z, Z, Z), S(Z)), None],
        False, "computation", cli=True)
    add("counter_not_zero_or_successor", [E(R(0, Z, 0), Z), None],
        False, "computation", cli=True)
    add("computable_zero_is_not_syntactic_zero",
        [E(R(R(Z, Z, Z), Z, 0), Z), None], False, "computation", cli=True)
    for i, body in enumerate([0, 1, 2, R(0, 1, R(2, 3, 4))]):
        previous = R(0, 1, body)
        result = oracle(body, [previous, 0, -2], formula=False)
        add(f"successor_computation_parameter_order_{i}",
            [E(R(S(0), 1, body), result), None], True, "computation", cli=i < 2)
        add(f"false_successor_computation_{i}",
            [E(R(S(0), 1, body), S(result)), None], False, "computation", cli=i < 2)

    eq = E(0, 1)
    add("equality_transport_below_existential",
        [X(E(0, 2)), [eq, 0, X(E(0, 1)), [0, 0]], eq],
        True, "equality", cli=True)
    add("equality_transport_capture_forgery",
        [X(E(0, 2)), [eq, 0, X(E(0, 0)), [0, 0]], eq],
        False, "equality", cli=True)
    motive = E(R(S(Z), Z, 2), 0)
    add("equality_transport_below_recursor",
        [E(R(S(Z), Z, 3), 1), [eq, 0, motive, None], eq],
        True, "equality", cli=True)

    principal = P(T, T)
    principal_proof = [0]
    add("closed_universal_elimination", [T, [principal, principal_proof, Z, refl(Z)]],
        True, "logic", cli=True)
    add("unproved_major_cannot_forge_a_false_theorem",
        [F, [F, 0, E(0, S(Z)), 0]], False, "fallback", cli=True)
    add("failed_major_uses_actual_hypothesis_fallback",
        [T, [P(T, E(0, 0)), 0, Z, 0], T], True, "fallback", cli=True)
    add("malformed_major_raises_instead_of_hypothesis_fallback",
        [T, [E(True, True), 0, Z, 0], T], False, "fallback", cli=True)
    add("failed_computation_does_not_fall_back_to_a_hypothesis",
        [E(R(Z, Z, Z), S(Z)), None, E(R(Z, Z, Z), S(Z))],
        False, "fallback", cli=True)
    for i, payload in enumerate([0, -7, None, True, False, 0.0, "ignored", {}, []]):
        add(f"hypothesis_payload_is_irrelevant_{i}", [T, payload, T],
            True, "fallback", cli=i in (0, 3, 7))

    for name, proof in [
        ("exists_missing_minor", [exists_zero, exists_zero_proof]),
        ("exists_extra_minor", [exists_zero, exists_zero_proof, refl(Z), refl(Z)]),
        ("universal_missing_annotation", [principal, principal_proof, refl(Z)]),
        ("universal_extra_minor", [principal, principal_proof, Z, refl(Z), refl(Z)]),
        ("equality_missing_motive", [T, refl(Z), refl(Z)]),
        ("equality_extra_minor", [T, refl(Z), T, refl(Z), refl(Z)]),
    ]:
        add(name, [T, proof], False, "certificate_arity", cli=True)

    hostile = [None, False, True, -2, -1.0, 0.0, "0", [], {},
               ["s"], ["s", Z, Z], ["r", Z, Z, None], E(Z, Z), X(T)]
    used_antecedent = P(E(0, 0), T)
    used_consequent = P(T, E(0, 0))
    used_update = P(T, E(R(Z, Z, 2), Z))
    for i, bad in enumerate(hostile):
        add(f"unused_universal_witness_{i}",
            [T, [principal, principal_proof, bad, refl(Z)]],
            False, "unused_witness", demand=True, cli=i < 3)
        add(f"unused_existential_witness_{i}", [X(T), [bad, refl(Z)]],
            False, "strict_witness", cli=i < 2)
        add(f"used_universal_antecedent_witness_{i}",
            [T, [used_antecedent, [refl(Z)], bad, refl(Z)]],
            False, "demand_validation", cli=i < 2)
        add(f"used_universal_consequent_witness_{i}",
            [T, [used_consequent, [refl(S(0))], bad, refl(Z)]],
            False, "demand_validation", cli=i < 2)
        add(f"used_witness_in_unused_recursor_update_{i}",
            [E(R(Z, Z, Z), Z), [used_update, [None], bad, refl(Z)]],
            False, "demand_validation", cli=i < 2)
        add(f"unused_recursor_update_is_validated_{i}",
            [E(R(Z, Z, bad), Z), None], False, "public_syntax", cli=i < 2)
        add(f"unused_recursor_initializer_is_validated_{i}",
            [E(R(S(Z), bad, 1), Z), None], False, "public_syntax", cli=i < 2)

    outer_vacuous = P(X(E(0, 0)), P(E(0, 0), E(0, 0)))
    outer_used = P(T, X(P(T, E(2, 2))))
    for i, bad in enumerate([None, {"ignored": [False, 0.0]}]):
        add(f"nested_local_variables_do_not_demand_outer_witness_{i}",
            [P(E(0, 0), E(0, 0)),
             [outer_vacuous, [[0]], bad, [Z, refl(0)]]],
            False, "unused_witness", demand=True, cli=True)
        add(f"outer_witness_used_below_two_binders_{i}",
            [X(P(T, T)), [outer_used, [[Z, [refl(2)]]], bad, refl(Z)]],
            False, "demand_validation", cli=True)

    bad_formulas = [None, False, 0, -1, 1.0, "=", {}, ["=", Z],
                    ["=", Z, Z, Z], ["s", Z], ["ex", Z],
                    ["pi", T], ["pi", T, ["s", Z]], E(True, False)]
    for i, bad in enumerate(bad_formulas):
        add(f"unused_bad_public_hypothesis_{i}", [T, refl(Z), bad],
            False, "public_syntax", cli=i < 2)
        add(f"bad_public_goal_{i}", [bad, 0, bad],
            False, "public_syntax", cli=i < 2)
        add(f"bad_equality_motive_{i}", [T, [T, refl(Z), bad, refl(Z)]],
            False, "equality", cli=i < 2)

    for i, data in enumerate([None, True, False, 0, "ab", {}, [], [T], [T, refl(Z), T, None]]):
        add(f"malformed_public_container_{i}", data, False, "public_boundary", cli=True)
    add("theorem_interface_rejects_external_assumptions", [F, 0, F],
        True, "public_boundary", cli=True)
    return rows


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def candidate_accept(module, data, opened):
    """Emulate the complete CLI after JSON parsing, without inventing a wrapper."""
    try:
        if opened:
            goal, proof, *context = data
            for hypothesis in context:
                module.subst(hypothesis)
            return module.check(goal, proof, context) is True
        return module.check(*data, []) is True
    except Exception:
        return False


def paths(value, prefix=()):
    yield prefix
    if type(value) is list:
        for index, child in enumerate(value):
            yield from paths(child, prefix + (index,))


def mutated(value, address, replacement):
    if not address:
        return copy.deepcopy(replacement)
    out = copy.deepcopy(value)
    parent = out
    for index in address[:-1]:
        parent = parent[index]
    parent[address[-1]] = copy.deepcopy(replacement)
    return out


def find_kernels():
    for folder in [HERE.parent / "agent_kernel", HERE.parent,
                   HERE.parent.parent, HERE.parent.parent.parent]:
        if (folder / "checker.py").is_file() and (folder / "checker_open.py").is_file():
            return folder
    raise ValueError("Use --kernels to identify the three checker files")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kernels", type=Path, default=None)
    parser.add_argument("--output", type=Path, default=HERE / "audit_results.json")
    parser.add_argument("--mutations", type=int, default=400)
    args = parser.parse_args()
    kernels = (args.kernels or find_kernels()).resolve()
    variants = {
        "strict_theorem": (kernels / "checker.py", True, False),
        "strict_open": (kernels / "checker_open.py", True, True),
        "demand_theorem": (kernels / "checker_demand.py", False, False),
    }
    modules = {name: load_module(path, "audit_candidate_" + name)
               for name, (path, _, _) in variants.items()}
    failures = []
    records = []
    tally = collections.Counter()

    with tempfile.TemporaryDirectory(prefix="ipra-independent-audit-") as temporary:
        test_path = Path(temporary) / "certificate.json"

        def run_case(record, expected_known=True):
            row = {"name": record["name"], "category": record["category"], "results": {}}
            data = record["data"]
            for name, (path, strict, opened) in variants.items():
                expected = reference.accepts(data, strict=strict, open_sequent=opened)
                if expected_known:
                    designated = record["expected"] if strict else record["demand_expected"]
                    if not opened and (type(data) is not list or len(data) != 2):
                        designated = False
                    if designated != expected:
                        failures.append({"name": row["name"], "variant": name,
                                         "reason": "Designated/reference disagreement",
                                         "designated": designated, "reference": expected})
                actual = candidate_accept(modules[name], data, opened)
                tally[name + ("_accept" if actual else "_reject")] += 1
                if actual != expected:
                    failures.append({"name": row["name"], "variant": name,
                                     "reason": "Candidate/reference disagreement",
                                     "reference": expected, "candidate": actual,
                                     "data": data})
                result = {"expected": expected, "actual": actual}
                if record.get("cli"):
                    test_path.write_text(json.dumps(data) + "\n", encoding="utf-8")
                    for optimized in [False, True]:
                        command = [sys.executable, *( ["-O"] if optimized else []),
                                   str(path), str(test_path)]
                        completed = subprocess.run(command, capture_output=True, text=True, timeout=15)
                        good = (completed.returncode == (0 if expected else 1)
                                and completed.stdout == ("ACCEPT\n" if expected else "REJECT\n")
                                and not completed.stderr)
                        tally["cli_runs"] += 1
                        result["optimized_cli" if optimized else "normal_cli"] = good
                        if not good:
                            failures.append({"name": row["name"], "variant": name,
                                             "optimized": optimized, "reason": "Full CLI mismatch",
                                             "returncode": completed.returncode,
                                             "stdout": completed.stdout, "stderr": completed.stderr})
                row["results"][name] = result
            if (row["results"]["strict_theorem"]["actual"]
                    and not row["results"]["demand_theorem"]["actual"]):
                failures.append({"name": row["name"], "reason": "Strict-to-demand inclusion failed"})
            records.append(row)

        cases = fixtures()
        for record in cases:
            run_case(record)

        example_data = []
        for subdir in ["examples", "examples_open"]:
            for path in sorted((kernels / subdir).glob("*.json")):
                data = json.loads(path.read_text(encoding="utf-8"))
                if type(data) is not list or len(data) < 2:
                    continue
                example_data.append(data)
                run_case({"name": subdir + "/" + path.name, "data": data,
                          "category": "packaged_example", "expected": True,
                          "demand_expected": True, "cli": subdir == "examples"})

        seeds = [r["data"] for r in cases if r["expected"]] + example_data
        replacements = [None, True, False, -2, -1, 0, 1, 2, 0.0, 1.0, "r", [], {},
                        S(Z), E(Z, Z), X(T), ["s"], ["r", Z, Z, None]]
        rng = random.Random(202611061837)
        for index in range(args.mutations):
            seed = rng.choice(seeds)
            address = rng.choice(list(paths(seed)))
            altered = mutated(seed, address, rng.choice(replacements))
            run_case({"name": "mutation_" + str(index), "data": altered,
                      "category": "deterministic_mutation", "cli": False}, expected_known=False)

        # These checks address parsing and process boundaries that an imported
        # function call cannot exercise.
        malformed_texts = ["", "{broken", "[", "null", "NaN", "[1,2,3,]", "{}"]
        for name, (path, _, _) in variants.items():
            for index, content in enumerate(malformed_texts):
                test_path.write_text(content, encoding="utf-8")
                for optimized in [False, True]:
                    command = [sys.executable, *( ["-O"] if optimized else []), str(path), str(test_path)]
                    completed = subprocess.run(command, capture_output=True, text=True, timeout=15)
                    tally["raw_cli_runs"] += 1
                    if completed.returncode != 1 or completed.stdout != "REJECT\n" or completed.stderr:
                        failures.append({"variant": name, "name": "raw_json_" + str(index),
                                         "optimized": optimized, "reason": "Parsing boundary failed"})
            for tail in [[], [str(test_path), "surplus"], [str(Path(temporary) / "missing.json")]]:
                completed = subprocess.run([sys.executable, str(path), *tail], capture_output=True, text=True, timeout=15)
                tally["raw_cli_runs"] += 1
                if completed.returncode != 1 or completed.stdout != "REJECT\n" or completed.stderr:
                    failures.append({"variant": name, "name": "argv_or_file_boundary",
                                     "reason": "Argument/file boundary failed"})

    result = {
        "status": "passed" if not failures else "failed",
        "python": sys.version,
        "candidate_sha256": {name: hashlib.sha256(path.read_bytes()).hexdigest()
                             for name, (path, _, _) in variants.items()},
        "independent_support_sha256": {
            filename: hashlib.sha256((HERE / filename).read_bytes()).hexdigest()
            for filename in ["audit.py", "reference.py", "named_oracle.py"]},
        "case_groups": dict(collections.Counter(row["category"] for row in records)),
        "counts": dict(tally),
        "failures": failures,
        "records": records,
        "qualification": (
            "Finite deterministic implementation evidence. The independent expected-result "
            "interpreter uses fresh named binders and never calls candidate syntax or "
            "substitution helpers. This is neither a formal metatheorem nor a consistency proof."),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key != "records"}, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
