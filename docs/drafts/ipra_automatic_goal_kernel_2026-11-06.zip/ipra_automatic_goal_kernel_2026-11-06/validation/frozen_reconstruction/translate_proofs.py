"""Untrusted proof translations for the reconstructed iPRA certificate format.

No acceptance checker imports this file. Every translated certificate is
rechecked by the destination checker in roundtrip.py. Numerical zero is -1.
"""
from copy import deepcopy

TRUE = ['=', -1, -1]
SCOPES = {
    False: {'s': ((0, False),), 'r': ((0, False), (0, False), (2, False))},
    True: {'=': ((0, False), (0, False)),
           'pi': ((1, True), (1, True)), 'ex': ((1, True),)},
}


def children(expression, formula):
    if type(expression) is not list or not expression or type(expression[0]) is not str:
        raise ValueError('Malformed expression container')
    tag, *arguments = expression
    signature = SCOPES[formula].get(tag)
    if signature is None or len(arguments) != len(signature):
        raise ValueError('Malformed expression constructor')
    return tag, list(zip(arguments, signature))


def shift(expression, amount=1, cutoff=0, formula=True):
    """Lift free numerical indices, preserving all binder-local indices."""
    if type(expression) is int:
        if formula or expression < -1:
            raise ValueError('Malformed numerical leaf')
        return expression + amount if expression >= cutoff else expression
    tag, arguments = children(expression, formula)
    return [tag, *(shift(arg, amount, cutoff + width, child_formula)
                   for arg, (width, child_formula) in arguments)]


def substitute(expression, replacements, tail_shift, cutoff=0, formula=True):
    """Simultaneously replace leading slots, with a specified free-index shift."""
    if type(expression) is int:
        if formula or expression < -1:
            raise ValueError('Malformed numerical leaf')
        if expression < cutoff:
            return expression
        relative = expression - cutoff
        if relative < len(replacements):
            return shift(replacements[relative], cutoff, formula=False)
        return expression + tail_shift
    tag, arguments = children(expression, formula)
    return [tag, *(substitute(arg, replacements, tail_shift,
                             cutoff + width, child_formula)
                   for arg, (width, child_formula) in arguments)]


def instantiate(expression, witness):
    return substitute(expression, [witness], -1)


def free_variables(expression, depth=0, formula=True):
    if type(expression) is int:
        if formula or expression < -1:
            raise ValueError('Malformed numerical leaf')
        return {expression - depth} if expression >= depth else set()
    _, arguments = children(expression, formula)
    result = set()
    for arg, (width, child_formula) in arguments:
        result.update(free_variables(arg, depth + width, child_formula))
    return result


def repaired_witness(witness, major, repairs, path):
    """Erase an invalid annotation only if both Pi matrices ignore its slot."""
    try:
        shift(witness, 0, formula=False)
        return witness
    except (KeyError, TypeError, ValueError):
        if major[0] != 'pi' or any(0 in free_variables(part) for part in major[1:]):
            raise ValueError('A demanded witness cannot be repaired')
        repairs.append({'path': path, 'annotation': deepcopy(witness), 'replacement': -1})
        return -1


def intro_premise(goal, induction):
    _, hypothesis, conclusion = goal
    if induction:
        if hypothesis != substitute(conclusion, [-1], 0):
            raise ValueError('Incorrect numerical-rule base')
        if conclusion[0] == '=':
            hypothesis = conclusion
        conclusion = substitute(conclusion, [['s', 0]], 0)
    return hypothesis, conclusion


def elimination_premises(major, annotation):
    tag, left, right = major
    if tag == '=':
        return instantiate(annotation, left), instantiate(annotation, right)
    if tag == 'pi':
        return instantiate(left, annotation), instantiate(right, annotation)
    raise ValueError('Not a two-component elimination')


def from_original(goal, proof, context, repairs=None, path='root'):
    """Translate an accepted pinned goal-directed proof, preserving its sequent.

    The caller first checks acceptance in comparison/primary/goal_directed.py.
    Hypotheses become None, introductions use goal-directed annotations, and
    applications lose the redundant use tag. Invalid unused witnesses are
    replaced only after checking both matrices for absence of the relevant slot.
    """
    if repairs is None:
        repairs = []
    shifted_context = lambda: [shift(a) for a in context]
    match proof:
        case ['lam' | 'nat' as tag, subproof]:
            if goal[0] != 'pi':
                raise ValueError('Introduction has the wrong goal')
            induction = tag == 'nat'
            hypothesis, conclusion = intro_premise(goal, induction)
            return [induction, from_original(conclusion, subproof,
                    [*shifted_context(), hypothesis], repairs, path + '/body')]
        case ['pack', witness, subproof]:
            if goal[0] != 'ex':
                raise ValueError('Existential introduction has the wrong goal')
            hypothesis = ['=', 0, shift(witness, formula=False)]
            return [deepcopy(witness), from_original(goal[1], subproof,
                    [*shifted_context(), hypothesis], repairs, path + '/body')]
        case ['use', major, major_proof, *arguments]:
            translated_major = from_original(major, major_proof, context, repairs, path + '/major')
            if major[0] == 'ex':
                if len(arguments) != 1:
                    raise ValueError('Bad existential-elimination arity')
                minor = from_original(shift(goal), arguments[0],
                        [*shifted_context(), major[1]], repairs, path + '/minor')
                return [deepcopy(major), translated_major, minor]
            annotation, minor_proof = arguments
            if major[0] == 'pi':
                annotation = repaired_witness(annotation, major, repairs, path + '/witness')
            else:
                shift(annotation, 0)
            minor_goal, conclusion = elimination_premises(major, annotation)
            if conclusion != goal:
                raise ValueError('Elimination conclusion changed')
            return [deepcopy(major), translated_major, deepcopy(annotation),
                    from_original(minor_goal, minor_proof, context, repairs, path + '/minor')]
        case 'r' if goal[0] == '=' and type(goal[1]) is list and goal[1][0] == 'r':
            return 'r'
        case _:
            if context[proof] != goal:
                raise ValueError('Original hypothesis does not match')
            return None


def normalize_accepted(kernel, goal, proof, context, repairs=None, path='root'):
    """Canonicalize any accepted new-format proof, including harmless aliases."""
    if repairs is None:
        repairs = []
    if not kernel.check(goal, proof, context):
        raise ValueError('Only accepted proofs can be normalized')
    shifted_context = lambda: [shift(a) for a in context]
    match (goal, proof):
        case [['pi', _, _], [False | True as induction, subproof]]:
            hypothesis, conclusion = intro_premise(goal, induction)
            return [induction, normalize_accepted(kernel, conclusion, subproof,
                    [*shifted_context(), hypothesis], repairs, path + '/body')]
        case [['ex', matrix], [witness, subproof]]:
            hypothesis = ['=', 0, shift(witness, formula=False)]
            return [deepcopy(witness), normalize_accepted(kernel, matrix, subproof,
                    [*shifted_context(), hypothesis], repairs, path + '/body')]
        case [_, [[tag, *parts] as major, major_proof, *arguments]] if kernel.check(major, major_proof, context):
            translated_major = normalize_accepted(kernel, major, major_proof, context,
                                                  repairs, path + '/major')
            if tag == 'ex':
                return [deepcopy(major), translated_major,
                        normalize_accepted(kernel, shift(goal), *arguments,
                            [*shifted_context(), *parts], repairs, path + '/minor')]
            annotation, minor_proof = arguments
            if tag == 'pi':
                annotation = repaired_witness(annotation, major, repairs, path + '/witness')
            else:
                shift(annotation, 0)
            minor_goal, conclusion = elimination_premises(major, annotation)
            if conclusion != goal:
                raise ValueError('Normalized elimination conclusion changed')
            return [deepcopy(major), translated_major, deepcopy(annotation),
                    normalize_accepted(kernel, minor_goal, minor_proof, context,
                                       repairs, path + '/minor')]
        case [['=', ['r', _, _, _], _], 'r']:
            return 'r'
        case _:
            if goal not in context:
                raise ValueError('No hypothesis justifies the fallback')
            return None


def to_original(goal, proof, context):
    """Reconstruct an original-format derivation from a canonical strict proof."""
    shifted_context = lambda: [shift(a) for a in context]
    match (goal, proof):
        case [['pi', _, _], [False | True as induction, subproof]]:
            hypothesis, conclusion = intro_premise(goal, induction)
            return ['nat' if induction else 'lam',
                    to_original(conclusion, subproof, [*shifted_context(), hypothesis])]
        case [['ex', matrix], [witness, subproof]]:
            hypothesis = ['=', 0, shift(witness, formula=False)]
            return ['pack', deepcopy(witness),
                    to_original(matrix, subproof, [*shifted_context(), hypothesis])]
        case [_, [[tag, *parts] as major, major_proof, *arguments]]:
            translated_major = to_original(major, major_proof, context)
            if tag == 'ex':
                minor = to_original(shift(goal), *arguments,
                                    [*shifted_context(), *parts])
                return ['use', deepcopy(major), translated_major, minor]
            annotation, minor_proof = arguments
            minor_goal, conclusion = elimination_premises(major, annotation)
            if conclusion != goal:
                raise ValueError('Reconstructed elimination conclusion changed')
            return ['use', deepcopy(major), translated_major, deepcopy(annotation),
                    to_original(minor_goal, minor_proof, context)]
        case [['=', ['r', _, _, _], _], 'r']:
            return 'r'
        case [_, None]:
            return context.index(goal)
        case _:
            raise ValueError('Noncanonical proof')


def lift_proof(proof, cutoff=0):
    """Shift a canonical proof under one new retained fresh number.

    The cutoff rises under every proof rule introducing a fresh number.
    An equality-elimination motive binds its own distinguished slot and is
    therefore shifted at cutoff+1; a Pi-elimination witness binds no slot.
    """
    if proof is None or proof == 'r':
        return proof
    if type(proof) is not list:
        raise ValueError('Noncanonical proof leaf')
    if len(proof) == 2:
        annotation, subproof = proof
        if type(annotation) is bool:
            return [annotation, lift_proof(subproof, cutoff + 1)]
        return [shift(annotation, 1, cutoff, False), lift_proof(subproof, cutoff + 1)]
    major, major_proof, *arguments = proof
    shifted_major = shift(major, 1, cutoff)
    translated_major = lift_proof(major_proof, cutoff)
    if major[0] == 'ex':
        if len(arguments) != 1:
            raise ValueError('Bad existential application')
        return [shifted_major, translated_major, lift_proof(arguments[0], cutoff + 1)]
    annotation, minor_proof = arguments
    if major[0] == '=':
        shifted_annotation = shift(annotation, 1, cutoff + 1)
    elif major[0] == 'pi':
        shifted_annotation = shift(annotation, 1, cutoff, False)
    else:
        raise ValueError('Bad elimination major')
    return [shifted_major, translated_major, shifted_annotation,
            lift_proof(minor_proof, cutoff)]


def discharge_hypotheses(goal, proof, context):
    """Compile a sequent to a hypothesis-free theorem by the deduction rule."""
    current_goal, current_proof = deepcopy(goal), deepcopy(proof)
    for hypothesis in reversed(context):
        current_goal = ['pi', shift(hypothesis), shift(current_goal)]
        current_proof = [False, lift_proof(current_proof)]
    return current_goal, current_proof


def close_parameters(goal, proof):
    """Universally bind all remaining free numerical parameters of the goal."""
    variables = free_variables(goal)
    count = max(variables) + 1 if variables else 0
    current_goal, current_proof = deepcopy(goal), deepcopy(proof)
    for _ in range(count):
        current_goal = ['pi', deepcopy(TRUE), current_goal]
        current_proof = [False, current_proof]
    if free_variables(current_goal):
        raise ValueError('Universal closure left a free parameter')
    return current_goal, current_proof, count


def compile_theorem(goal, proof, context):
    hypothesis_free_goal, hypothesis_free_proof = discharge_hypotheses(goal, proof, context)
    closed_goal, closed_proof, count = close_parameters(hypothesis_free_goal, hypothesis_free_proof)
    return closed_goal, closed_proof, {
        'hypothesis_count': len(context), 'parameter_binders': count,
        'hypothesis_free_goal': hypothesis_free_goal,
    }


def truth_proof():
    """A canonical proof of 0=0 from a computation equation and transport."""
    recursor = ['r', -1, -1, -1]
    computation = ['=', recursor, -1]
    return [computation, 'r', ['=', 0, -1], 'r']


def reopen_theorem(closed_goal, closed_proof, context, parameter_binders):
    """Instantiate a universal closure and discharge-code back to its sequent."""
    goal, proof = deepcopy(closed_goal), deepcopy(closed_proof)
    for variable in reversed(range(parameter_binders)):
        if goal[0] != 'pi' or instantiate(goal[1], variable) != TRUE:
            raise ValueError('Unexpected universal-closure guard')
        proof = [goal, proof, variable, truth_proof()]
        goal = instantiate(goal[2], variable)
    for hypothesis in context:
        if goal[0] != 'pi' or instantiate(goal[1], -1) != hypothesis:
            raise ValueError('Unexpected deduction-code guard')
        proof = [goal, proof, -1, None]
        goal = instantiate(goal[2], -1)
    return goal, proof
