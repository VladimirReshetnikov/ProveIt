"""Independent rule interpretation for the compact iPRA certificates.

No function from a candidate checker is used here. Capture avoidance is
implemented by the attributed named-binder oracle, rather than the candidate's
cutoff/environment traversal. The public-interface rules are interpreted here
as well: theorem inputs have exactly two fields; sequent inputs may retain a
validated finite context.
"""
from named_oracle import named, oracle, valid


def require(condition):
    if not condition:
        raise ValueError("Independent reference rejected a malformed certificate")


def checked(expression, is_formula):
    require(valid(expression, is_formula))
    return expression


def free_zero_occurs(expression):
    if type(expression) is not tuple:
        return False
    return (expression[:2] == ("free", 0)
            or any(free_zero_occurs(child) for child in expression[1:]))


def prove(goal, proof, assumptions, strict=True):
    """Interpret each compact instruction with independently named binders."""
    checked(goal, True)
    if (goal[0] == "pi" and type(proof) is list and len(proof) == 1):
        guard, body = goal[1:]
        local, target = guard, body
        if guard == oracle(body, [-1, 0]):
            if body[0] == "=":
                local = body
            target = oracle(body, [["s", 0], 0])
        retained = [oracle(hypothesis) for hypothesis in assumptions]
        return prove(target, proof[0], retained + [local], strict)

    if goal[0] == "ex" and type(proof) is list and len(proof) == 2:
        witness = checked(proof[0], False)
        local = ["=", 0, oracle(witness, formula=False)]
        retained = [oracle(hypothesis) for hypothesis in assumptions]
        return prove(goal[1], proof[1], retained + [local], strict)

    if (type(proof) is list and len(proof) >= 2
            and type(proof[0]) is list and len(proof[0]) >= 1):
        major = checked(proof[0], True)
        if prove(major, proof[1], assumptions, strict):
            arguments = proof[2:]
            if major[0] == "ex":
                require(len(arguments) == 1)
                retained = [oracle(hypothesis) for hypothesis in assumptions]
                return prove(oracle(goal), arguments[0], retained + [major[1]], strict)
            require(len(arguments) == 2)
            annotation, minor = arguments
            if major[0] == "pi":
                used = any(free_zero_occurs(named(matrix)) for matrix in major[1:])
                witness = checked(annotation, False) if strict or used else -1
                premise = oracle(major[1], [witness, -1])
                conclusion = oracle(major[2], [witness, -1])
            else:
                motive = checked(annotation, True)
                premise = oracle(motive, [major[1], -1])
                conclusion = oracle(motive, [major[2], -1])
            return conclusion == goal and prove(premise, minor, assumptions, strict)

    if (proof is None and goal[0] == "=" and type(goal[1]) is list
            and goal[1][0] == "r"):
        counter, initial, update = goal[1][1:]
        if counter == -1:
            result = initial
        else:
            require(type(counter) is list and len(counter) == 2 and counter[0] == "s")
            predecessor = counter[1]
            previous = ["r", predecessor, initial, update]
            result = oracle(update, [previous, predecessor, -2], formula=False)
        return goal[2] == result

    return goal in assumptions


def accepts(data, strict=True, open_sequent=False):
    try:
        require(type(data) is list and len(data) >= 2)
        if not open_sequent:
            require(len(data) == 2)
        goal, proof, *assumptions = data
        for hypothesis in assumptions:
            checked(hypothesis, True)
        return prove(goal, proof, assumptions, strict) is True
    except (TypeError, ValueError, IndexError, KeyError, RecursionError, OverflowError):
        return False
