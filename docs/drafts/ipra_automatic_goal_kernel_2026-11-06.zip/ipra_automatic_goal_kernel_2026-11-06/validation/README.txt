INDEPENDENT IMPLEMENTATION AUDIT

Run from the extracted package directory:

  python3 validation/audit.py --kernels . --output results/independent_audit.json
  python3 validation/fault_sensitivity.py --kernels . --output results/fault_sensitivity.json

The kernel directory must contain checker.py, checker_open.py, and
checker_demand.py. If present, examples/ and examples_open/ are audited too.
No external packages or network access are used. The default report paths
are audit_results.json and fault_sensitivity_results.json beside these scripts.

audit.py constructs 209 targeted cases, reads 37 packaged examples, and
performs 400 deterministic mutations. Each input is compared against the
independent reference for all three public parsed-input boundaries.
Its 98 selected certificates run through each actual CLI normally and with
Python -O (588 runs). Another 51 process tests cover malformed JSON, argument
count, and missing files. The recorded run has zero failures.

reference.py independently interprets the compact proof instructions.
named_oracle.py gives every binder a fresh identity, substitutes named free
variables, and reconstructs indices. It is a byte-identical, attributed copy
of the independent oracle from the inspected automatic-introduction draft;
oracle_provenance.json records its exact origin and hash. No candidate
syntax or substitution function establishes an expected result.

Candidate helpers are used solely to observe the candidates' parsed-input
behavior. Actual CLI subprocesses independently check the JSON and process
boundaries. All three programs are tested with their actual interfaces:
the two theorem programs reject external hypotheses, whereas the open
program validates every external hypothesis before checking the proof.

The tests explicitly cover eigenvariable escape below logical/recursor
binders, retained-context lifting, equation-only induction hypotheses,
ordinary numerical cases, false computations and recursor argument order,
equality motives, strict and demand witness validation, unused malformed
public syntax, hypothesis-membership fallback, and certificate arity.

fault_sensitivity.py creates only in-memory copies of the strict theorem
program. Four focused cases detect the exact effects of enabling unrestricted
quantified induction, omitting existential conclusion lifting, omitting
strict witness validation, or omitting goal formation validation.

These are finite implementation and sensitivity checks. The written paper
supplies the general soundness, completeness, and bi-interpretability
arguments. No proof-assistant formalization or consistency proof is claimed.
