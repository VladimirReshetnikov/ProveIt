#!/usr/bin/env python3
"""Reproduce the new diagnostics and the LaTeX report; no downloads."""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def checks() -> None:
    out = ROOT / "verification" / "check_diagonal_results.json"
    result = subprocess.run(
        [sys.executable, str(ROOT / "code" / "check_diagonal.py"),
         "--output", str(out)], cwd=ROOT, text=True, capture_output=True,
    )
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
    print("Syntax and finite numerical diagnostics passed.")


def pdf() -> None:
    compiler = shutil.which("pdflatex")
    if compiler is None:
        raise SystemExit("pdflatex is required; see README.txt.")
    temp = ROOT / "_build"
    temp.mkdir(exist_ok=True)
    logs: list[str] = []
    for pass_number in range(1, 4):
        result = subprocess.run(
            [compiler, "-interaction=nonstopmode", "-halt-on-error",
             "-no-shell-escape", f"-output-directory={temp}", "report.tex"],
            cwd=ROOT, text=True, capture_output=True,
        )
        logs.append(f"PASS {pass_number}\n{result.stdout}\n{result.stderr}")
        if result.returncode:
            (ROOT / "verification" / "pdf_build.txt").write_text(
                "\n".join(logs), encoding="utf-8")
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
    last_log = (temp / "report.log").read_text(encoding="utf-8", errors="replace")
    errors = [line for line in last_log.splitlines()
              if "undefined" in line.lower() or "Overfull" in line
              or "multiply-defined" in line]
    (ROOT / "verification" / "pdf_build.txt").write_text(
        "Three pdflatex passes; shell escape disabled.\n"
        + ("Unresolved diagnostics:\n" + "\n".join(errors) if errors
           else "No undefined references, multiply-defined labels, or overfull boxes.\n")
        + "\n" + last_log, encoding="utf-8")
    if errors:
        raise SystemExit("Resolve PDF diagnostics before delivery: " + "; ".join(errors))
    shutil.copy2(temp / "report.pdf", ROOT / "report.pdf")
    print("Compiled report.pdf; visual inspection remains a separate step.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--checks-only", action="store_true")
    group.add_argument("--pdf-only", action="store_true")
    args = parser.parse_args()
    (ROOT / "verification").mkdir(exist_ok=True)
    if not args.pdf_only:
        checks()
    if not args.checks_only:
        pdf()


if __name__ == "__main__":
    main()
