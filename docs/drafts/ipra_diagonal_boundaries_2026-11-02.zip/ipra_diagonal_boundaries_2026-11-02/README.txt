DIAGONAL BOUNDARIES FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 2 November 2026
================================================================

START HERE
  report.pdf                  Complete research report and proofs.
  report.tex                  Main editable LaTeX source.
  sections/arithmetic.tex      Complete arithmetic and interpretation appendix.
  AXIOMS.txt                  Exact standalone recommended specification.

RESULT
Seven direct universal arithmetic equations replace seven full boundary
instances. Every other retained equation gets a diagonal boundary whose
parameter also serves as its induction target. The paper proves ordinary
intuitionistic first-order bi-interpretability with iPRA, including both
whole-carrier identity composites, and equiconsistency.

Under the current drafts' full syntax-tree metric:
  seven special indices: F+16 -> F+2; total274 ->176, saving98;
  every other retained index: F+16 -> F+15;
  omitted indices: no change.
No new numerical primitive or logical connective is introduced. The
current compatible chain computation envelope and safe omissions are kept.

WHY THE PROOF IS NOT CIRCULAR
An auxiliary theory keeps full boundaries at the seven exact indices.
Parameter-free induction already follows from diagonal boundaries. The
seven protected inductions suffice for equality reflection and pairing.
A two-subtraction clamp recovers arbitrary targets from diagonal induction.
The auxiliary theory proves all seven direct universal equations, and each
direct equation gives its full boundary; the presentations are equivalent.

INTERPRETATION OF SIMPLICITY
The strict improvement concerns the emitted axiom-instance ledger, with
descriptors and logical definitions fully charged. The seven-index selector
has a finite description cost. Translated induction proofs may be longer.
No encoding-independent absolute minimum is asserted.

COMPARISON AND ATTRIBUTION
Snapshot: 0593751362f559ccc52e269fe5ecac06a7d6e63c
Repository: VladimirReshetnikov/ProveIt, docs/drafts and docs/drafts/archived
Actual inventory: five current ZIPs and six archived ZIPs. All five current
packages improve an archived coordinate and are retained in the review.
The chain connective, initialized recursors, scanner, arithmetic ledger,
equality error, and triangular pairing are inherited and credited. The new
step is the diagonal transfer with its explicit seven-equation bootstrap.

REPRODUCE
Requirements: Python3.10+ (standard library only), pdflatex, and common
TeX Live packages listed by report.tex. No software is downloaded.
  python3 build.py
or:
  python3 build.py --checks-only
  python3 build.py --pdf-only
The PDF build disables shell escape. Intermediate TeX files go in _build/.

VERIFICATION
  code/check_diagonal.py
    Fresh immutable-AST counting, computation module sizes, exact selectors,
    frozen descriptors, bounded scanners, actual PR pairing/clamp evaluation,
    and finite clamped transfers.
  verification/check_diagonal_results.json
  verification/check_summary.txt
  verification/mathematical_audit.txt
  verification/pdf_build.txt
  verification/pdf_visual_review.txt

The Python checks are diagnostics, not a formal proof certificate for
bi-interpretability. The general proofs are written in the report; the
mathematical audit is an independent review, not a Lean or Rocq compilation.

PROVENANCE
  provenance/source_manifest.json
    Exact source paths, pinned URLs, lengths, Git blob hashes and SHA-256.
  provenance/draft_comparison.csv
    Eligibility and contribution of every inspected current/archived draft.
  SHA256SUMS.txt
    Deliverable integrity manifest, excluding itself and temporary builds.

No repository mutation was performed. No downloaded draft code was executed.
The archive includes a Further research questions section in the report.
