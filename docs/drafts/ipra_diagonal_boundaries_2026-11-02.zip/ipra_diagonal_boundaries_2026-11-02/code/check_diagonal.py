#!/usr/bin/env python3
"""Independent finite diagnostics for diagonal boundary arithmetic.

This program does NOT prove bi-interpretability.  It checks literal AST
accounting, frozen descriptors, syntactic emitters, and finite instances of
the scanner/pairing/clamping identities used by the written proof.

Only Python's standard library is used.  No earlier draft's code is imported.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple["Term | Formula", ...] = ()
    binder: str = ""


def V(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def S(t: Term) -> Term:
    return Term("S", (t,))


def R(body: Term, n: Term, a: Term) -> Term:
    return Term("R", (n, a), body=body)


def Eq(t: Term, u: Term) -> Formula:
    return Formula("eq", (t, u))


BOT = Formula("bottom")


def Imp(a: Formula, b: Formula) -> Formula:
    return Formula("implies", (a, b))


def And(a: Formula, b: Formula) -> Formula:
    return Formula("and", (a, b))


def Or(a: Formula, b: Formula) -> Formula:
    return Formula("or", (a, b))


def K(a: Formula, b: Formula, c: Formula) -> Formula:
    return Formula("K", (a, b, c))


def J(a: Formula, b: Formula, c: Formula) -> Formula:
    return Formula("J", (a, b, c))


def quant(kind: str, names: Iterable[str], f: Formula) -> Formula:
    for name in reversed(tuple(names)):
        f = Formula(kind, (f,), binder=name)
    return f


@lru_cache(maxsize=None)
def size(node: Term | Formula) -> int:
    """Full tree size, without sharing, including every frozen descriptor."""
    return 1 + sum(size(x) for x in node.args) + (
        size(node.body) if isinstance(node, Term) and node.body is not None else 0
    )


def active_count(node: Term | Formula, name: str) -> int:
    if isinstance(node, Term) and node.op == "var":
        return int(node.name == name)
    if isinstance(node, Formula) and node.op in ("forall", "exists") and node.binder == name:
        return 0
    return sum(active_count(x, name) for x in node.args)


def free_vars(node: Term | Formula) -> frozenset[str]:
    if isinstance(node, Term) and node.op == "var":
        return frozenset((node.name,))
    out = frozenset().union(*(free_vars(x) for x in node.args))
    if isinstance(node, Formula) and node.op in ("forall", "exists"):
        out -= {node.binder}
    return out


def subst_term(t: Term, env: dict[str, Term]) -> Term:
    """Simultaneous active substitution.  Stored bodies are never visited."""
    if t.op == "var":
        return env.get(t.name, t)
    return Term(t.op, tuple(subst_term(x, env) for x in t.args), t.name, t.body)


def subst_matrix(f: Formula, env: dict[str, Term]) -> Formula:
    """Substitute in a quantifier-free matrix; bound substitution is not needed."""
    assert f.op not in ("forall", "exists")
    return Formula(f.op, tuple(subst_term(x, env) if isinstance(x, Term)
                              else subst_matrix(x, env) for x in f.args))


def expand_K(f: Formula) -> Formula:
    """Literal conservative expansion, charging both payload occurrences."""
    args = tuple(x if isinstance(x, Term) else expand_K(x) for x in f.args)
    if f.op == "K":
        first, middle, last = args
        return And(Imp(first, middle), Imp(middle, last))
    return Formula(f.op, args, binder=f.binder)


@lru_cache(maxsize=None)
def symbols(node: Term | Formula) -> frozenset[Term]:
    """Return generated-symbol descriptors, including dependency closure."""
    out = frozenset().union(*(symbols(x) for x in node.args))
    if isinstance(node, Term) and node.body is not None:
        out |= {node.body}
        out |= symbols(node.body)
    return out


@lru_cache(maxsize=None)
def rank(node: Term | Formula) -> int:
    r = max((rank(x) for x in node.args), default=0)
    if isinstance(node, Term) and node.body is not None:
        r = max(r, 1 + rank(node.body))
    return r


def occurs_under_rec(node: Term | Formula, name: str, under: bool = False) -> bool:
    if isinstance(node, Term) and node.op == "var":
        return under and node.name == name
    # Deliberately traverse active arguments only, never frozen bodies.
    nested = under or (isinstance(node, Term) and node.op == "R")
    return any(occurs_under_rec(x, name, nested) for x in node.args)


v, w, x, a, n, b, u, y = map(V, ("v", "w", "x", "a", "n", "b", "u", "y"))
ONE = S(ZERO)
Q_BODY = w
Z_BODY = ZERO
ADD_BODY = S(v)


def Q(t: Term, z: Term) -> Term:
    return R(Q_BODY, t, z)


def Z(t: Term, z: Term) -> Term:
    return R(Z_BODY, t, z)


def add(t: Term, z: Term) -> Term:
    return R(ADD_BODY, z, t)


D_BODY = Q(v, ZERO)


def diff(t: Term, z: Term) -> Term:
    return R(D_BODY, z, t)


def error(t: Term, z: Term) -> Term:
    return Q(diff(S(t), z), ONE)


def chi(t: Term, z: Term) -> Term:
    return Z(error(t, z), ONE)


def choose_zero(r: Term, t: Term, z: Term) -> Term:
    return Q(Z(r, S(t)), z)


T_BODY = add(v, S(w))


def triangular(t: Term) -> Term:
    return R(T_BODY, t, ZERO)


KAPPA_BODY = add(v, chi(S(w), triangular(S(v))))


def kappa(t: Term) -> Term:
    return R(KAPPA_BODY, t, ZERO)


BOOTSTRAP = frozenset((Q_BODY, Z_BODY, ADD_BODY, D_BODY, T_BODY, KAPPA_BODY))
BOOTSTRAP_NAMES = dict(zip((Q_BODY, Z_BODY, ADD_BODY, D_BODY, T_BODY, KAPPA_BODY),
                           ("Q", "Z", "addition", "difference", "triangular", "kappa")))


def pair(t: Term, z: Term) -> Term:
    return add(triangular(add(t, z)), z)


def pi2(t: Term) -> Term:
    return diff(t, triangular(kappa(t)))


def pi1(t: Term) -> Term:
    return diff(kappa(t), pi2(t))


def clamp(t: Term, cap: Term) -> Term:
    # This orientation is the one used in the proof: d(cap,d(cap,t)).
    return diff(cap, diff(cap, t))


E_COV = Eq(x, S(Q(x, ZERO)))

# The seven exceptions are EXACT expanded equations, including orientation.
# A symmetric equation is not silently treated as the same index.
EXCEPTION_ROWS = (
    ("left_successor", Eq(add(S(a), x), S(add(a, x)))),
    ("difference_shift", Eq(diff(S(a), S(x)), diff(a, x))),
    ("cancel_right", Eq(diff(add(a, x), x), a)),
    ("cancel_left", Eq(diff(add(x, a), x), a)),
    ("difference_below_sum", Eq(diff(a, add(x, a)), ZERO)),
    ("residual", Eq(choose_zero(diff(a, x), a, add(x, diff(a, x))), a)),
    ("block", Eq(Z(diff(x, a), error(kappa(add(triangular(a), x)), a)), ZERO)),
)
EXCEPTIONS = frozenset(e for _, e in EXCEPTION_ROWS)


def omitted(e: Formula) -> bool:
    assert e.op == "eq" and free_vars(e) <= {"x", "a"}
    return (not occurs_under_rec(e, "x") or e.args[0] == e.args[1]
            or e == E_COV or e == Eq(E_COV.args[1], E_COV.args[0]))


def boundary(e: Formula, family: str = "K", diagonal: bool = False) -> Formula:
    target = a if diagonal else n
    if family == "K":
        matrix = K(Eq(S(x), b), e, Imp(Eq(x, b), Eq(b, target)))
        inner = quant("exists", ("b",), quant("forall", ("x",), matrix))
    elif family == "J_covered":
        matrix = J(e, Imp(Eq(S(x), b), BOT), Imp(Eq(x, b), Eq(b, target)))
        inner = quant("exists", ("b",), quant("forall", ("x",), matrix))
    elif family == "J_forward":
        matrix = J(e, Imp(Eq(x, b), Eq(b, ZERO)), Imp(Eq(x, S(b)), Eq(b, target)))
        inner = quant("exists", ("b",), quant("forall", ("x",), matrix))
    elif family == "J_direct":
        eb = subst_matrix(e, {"x": b})
        esb = subst_matrix(e, {"x": S(b)})
        inner = quant("exists", ("b",), J(eb, Eq(b, ZERO), Imp(esb, Eq(b, target))))
    else:
        raise ValueError(family)
    return quant("forall", ("a",) if diagonal else ("a", "n"), inner)


def direct_identity(e: Formula) -> Formula:
    return quant("forall", ("a", "x"), e)


def emitted_kind(e: Formula, mode: str) -> str:
    if omitted(e):
        return "omitted"
    if mode == "seven_direct_identities":
        return "identity" if e in EXCEPTIONS else "diagonal"
    if mode == "seven_equations":
        keep_full = e in EXCEPTIONS
    elif mode == "six_symbols":
        keep_full = symbols(e) <= BOOTSTRAP
    elif mode == "rank_three":
        keep_full = rank(e) <= 3
    else:
        raise ValueError(mode)
    return "full" if keep_full else "diagonal"


def computation(body: Term) -> dict[str, tuple[Formula, ...]]:
    rn = R(body, n, a)
    rsn = R(body, S(n), a)
    rxy = R(body, x, a)
    h_un = subst_term(body, {"v": u, "w": n})
    direct = (
        quant("forall", ("a",), Eq(R(body, ZERO, a), a)),
        quant("forall", ("a", "n"), Eq(rsn, subst_term(body, {"v": rn, "w": n}))),
    )
    graph = quant("forall", ("a", "n", "u"),
                  K(And(Eq(n, ZERO), Eq(u, a)), Eq(rn, u), Eq(rsn, h_un)))
    end = quant("forall", ("a", "n"), quant("exists", ("u",),
                And(Imp(Eq(n, ZERO), Eq(u, a)), quant("forall", ("x", "y"),
                    K(And(Eq(x, n), Eq(y, u)), Eq(rxy, y),
                      Imp(Eq(x, S(n)), Eq(y, h_un)))))))
    modules = {"ordinary": direct, "current_chain": (graph,), "endpoint_chain": (end,)}
    if active_count(body, "v") == 0:
        statefree = quant("forall", ("a", "x", "y"),
                          K(And(Eq(x, ZERO), Eq(y, a)), Eq(rxy, y),
                            quant("forall", ("n",),
                                  Imp(Eq(x, S(n)), Eq(y, subst_term(body, {"v": ZERO, "w": n}))))))
        modules["statefree_chain"] = (statefree,)
    return modules


@lru_cache(maxsize=None)
def evaluate(t: Term, env_items: tuple[tuple[str, int], ...]) -> int:
    env = dict(env_items)
    if t.op == "var":
        return env[t.name]
    if t.op == "zero":
        return 0
    if t.op == "S":
        return 1 + evaluate(t.args[0], env_items)
    assert t.op == "R" and t.body is not None
    count = evaluate(t.args[0], env_items)
    state = evaluate(t.args[1], env_items)
    for counter in range(count):
        state = evaluate(t.body, (("v", state), ("w", counter)))
    return state


def value(t: Term, **env: int) -> int:
    return evaluate(t, tuple(sorted(env.items())))


def scanner(values: tuple[bool, ...], target: int) -> int:
    assert len(values) > target
    current = 0
    for step in range(target):
        if values[current]:
            current = step + 1
    return current


def check_boundary(values: tuple[bool, ...], target: int, witness: int) -> None:
    # Only probes x=b-1 and x=b can make an antecedent true, so these
    # finite checks verify the whole universally quantified matrix on N.
    assert witness == 0 or values[witness - 1]
    assert not values[witness] or witness == target


def run_checks() -> dict:
    assert len(BOOTSTRAP) == 6
    bootstrap_rows = []
    for body, label in BOOTSTRAP_NAMES.items():
        assert free_vars(body) <= {"v", "w"}
        assert symbols(body) <= BOOTSTRAP
        bootstrap_rows.append({"name": label, "body_size": size(body),
                               "symbol_rank": rank(body) + 1,
                               "dependency_names": sorted(BOOTSTRAP_NAMES[h] for h in symbols(body))})
    assert [r["symbol_rank"] for r in bootstrap_rows] == [1, 1, 1, 2, 2, 3]
    assert len(EXCEPTIONS) == 7
    exception_rows = []
    for label, equation in EXCEPTION_ROWS:
        assert free_vars(equation) == {"x", "a"}
        assert symbols(equation) <= BOOTSTRAP
        assert not omitted(equation)
        assert emitted_kind(equation, "seven_equations") == "full"
        assert emitted_kind(equation, "seven_direct_identities") == "identity"
        assert size(direct_identity(equation)) == size(equation) + 2
        assert not free_vars(direct_identity(equation))
        symmetric = Eq(equation.args[1], equation.args[0])
        assert symmetric not in EXCEPTIONS
        assert emitted_kind(symmetric, "seven_equations") == "diagonal"
        exception_rows.append({"name": label, "F": size(equation),
                               "i": active_count(equation, "x"),
                               "full_boundary_size": size(boundary(equation)),
                               "direct_identity_size": size(direct_identity(equation))})
    assert [r["direct_identity_size"] for r in exception_rows] == [15, 19, 15, 15, 15, 28, 69]
    full_exception_total = sum(r["full_boundary_size"] for r in exception_rows)
    direct_exception_total = sum(r["direct_identity_size"] for r in exception_rows)
    assert full_exception_total == 274 and direct_exception_total == 176
    assert full_exception_total - direct_exception_total == 98

    # An active substitution must not alter even identically named slots
    # inside a descriptor.  The descriptor price must still be charged.
    test_body = add(v, w)
    call = R(test_body, v, w)
    changed = subst_term(call, {"v": ZERO, "w": ONE})
    assert changed.body is test_body and changed.args == (ZERO, ONE)
    assert active_count(call, "v") == 1 and active_count(test_body, "v") == 1
    assert active_count(R(test_body, x, a), "v") == 0
    assert size(R(test_body, x, a)) == size(test_body) + 3
    assert symbols(changed) == symbols(call)

    bodies = [ZERO, v, w, S(v), S(w), Q(v, w), Q(w, v), Z(v, w),
              add(v, w), add(v, v), D_BODY, T_BODY, KAPPA_BODY,
              kappa(v), S(kappa(v)), add(kappa(v), w)]
    for source in (v, w):
        term = source
        for _ in range(18):
            term = S(term)
            bodies.append(term)
    bodies = list(dict.fromkeys(bodies))
    computation_rows = []
    for body in bodies:
        H, k = size(body), active_count(body, "v")
        costs = {name: sum(size(f) for f in fs) for name, fs in computation(body).items()}
        predicted = {"ordinary": 3*H+13+k*(H+2), "current_chain": 3*H+21,
                     "endpoint_chain": 2*H+33}
        if k == 0:
            predicted["statefree_chain"] = 2*H+24
        assert costs == predicted, (costs, predicted)
        chosen = min(costs, key=costs.get)
        computation_rows.append({"H": H, "k": k, "costs": costs, "chosen": chosen})

    terms = [ZERO, ONE, x, a, S(x), S(S(x)), Q(x, a), Z(x, a),
             add(x, a), diff(x, a), triangular(x), kappa(x),
             Q(a, ZERO), S(Q(a, ZERO)), S(Q(x, ZERO))]
    outside = [body for body in bodies if body not in BOOTSTRAP]
    terms += [R(body, x, a) for body in outside]
    equations = [Eq(t, z) for t in terms for z in (ZERO, x, a)]
    equations += [Eq(t, t) for t in terms] + [E_COV, Eq(E_COV.args[1], E_COV.args[0])]
    equations += list(EXCEPTIONS) + [Eq(e.args[1], e.args[0]) for e in EXCEPTIONS]
    equations = list(dict.fromkeys(equations))
    boundary_checks = 0
    kind_counts = {mode: {key: 0 for key in ("omitted", "identity", "full", "diagonal")}
                   for mode in ("seven_direct_identities", "seven_equations", "six_symbols", "rank_three")}
    for e in equations:
        F, i = size(e), active_count(e, "x")
        predictions = {"K": F+16, "J_covered": F+18,
                       "J_forward": F+20, "J_direct": 2*F+i+11}
        for family, full_count in predictions.items():
            full = boundary(e, family, False)
            diagonal = boundary(e, family, True)
            assert size(full) == full_count
            assert size(diagonal) == full_count - 1
            assert not free_vars(full) and not free_vars(diagonal)
            boundary_checks += 1
        assert size(expand_K(boundary(e, "K", False))) == 2*F + 18
        assert size(expand_K(boundary(e, "K", True))) == 2*F + 17
        for mode in kind_counts:
            kind_counts[mode][emitted_kind(e, mode)] += 1
        if emitted_kind(e, "rank_three") == "diagonal":
            assert emitted_kind(e, "six_symbols") == "diagonal"
        if emitted_kind(e, "six_symbols") == "diagonal":
            assert emitted_kind(e, "seven_equations") == "diagonal"
        main_kind = emitted_kind(e, "seven_direct_identities")
        if main_kind != "omitted":
            emitted = direct_identity(e) if main_kind == "identity" else boundary(e, "K", True)
            saving = 14 if main_kind == "identity" else 1
            assert size(boundary(e)) - size(emitted) == saving
        lifted_matrix = subst_matrix(e, {"x": clamp(x, pi2(a)), "a": pi1(a)})
        assert free_vars(lifted_matrix) <= {"x", "a"}
        assert symbols(e) <= symbols(lifted_matrix)
        if not symbols(e) <= BOOTSTRAP:
            assert not symbols(lifted_matrix) <= BOOTSTRAP
        if rank(e) > 3:
            assert rank(lifted_matrix) > 3
    assert emitted_kind(Eq(R(S(S(v)), x, a), ZERO), "six_symbols") == "diagonal"
    assert emitted_kind(Eq(R(S(S(v)), x, a), ZERO), "rank_three") == "full"
    assert emitted_kind(Eq(R(kappa(v), x, a), ZERO), "rank_three") == "diagonal"
    assert omitted(Eq(S(x), Q(a, ZERO)))  # x stays outside every recursor.
    assert omitted(E_COV) and omitted(Eq(Q(x, a), Q(x, a)))
    assert not omitted(Eq(Q(x, a), ZERO))
    assert kind_counts["seven_equations"]["full"] == 7
    assert kind_counts["seven_direct_identities"]["identity"] == 7
    assert kind_counts["seven_direct_identities"]["full"] == 0
    for e in equations:
        if emitted_kind(e, "seven_equations") != "omitted" and "a" not in free_vars(e):
            assert emitted_kind(e, "seven_equations") == "diagonal"

    scanner_checks = 0
    for target in range(9):
        for mask in range(1 << (target + 1)):
            truth_values = tuple(bool(mask & (1 << j)) for j in range(target + 1))
            witness = scanner(truth_values, target)
            check_boundary(truth_values, target, witness)
            scanner_checks += 1

    # Evaluate the actual six-descriptor terms, rather than replacing them
    # with their intended numerical meanings, and compare independently.
    arithmetic_checks = 0
    for av in range(7):
        for nv in range(7):
            env = {"a": av, "n": nv}
            code = value(pair(a, n), **env)
            assert code == (av + nv)*(av + nv + 1)//2 + nv
            assert value(pi1(pair(a, n)), **env) == av
            assert value(pi2(pair(a, n)), **env) == nv
            assert value(diff(n, pair(a, n)), **env) == 0
            for xv in range(code + 2):
                m = value(clamp(x, n), x=xv, n=nv)
                next_m = value(clamp(S(x), n), x=xv, n=nv)
                assert m == min(xv, nv)
                assert next_m == m or next_m == m + 1
                arithmetic_checks += 1
            assert value(clamp(ZERO, n), n=nv) == 0
            assert value(clamp(pair(a, n), n), **env) == nv

    transfer_checks = 0
    for av in range(5):
        for nv in range(6):
            code = value(pair(a, n), a=av, n=nv)
            for mask in range(1 << (nv + 1)):
                truth_values = tuple(bool(mask & (1 << j)) for j in range(nv + 1))
                lifted = tuple(truth_values[value(clamp(x, n), x=j, n=nv)]
                               for j in range(code + 1))
                witness = scanner(lifted, code)
                check_boundary(lifted, code, witness)
                assert lifted[0] == truth_values[0]
                assert lifted[code] == truth_values[nv]
                progresses = all(not truth_values[j] or truth_values[j+1] for j in range(nv))
                if progresses:
                    assert all(not lifted[j] or lifted[j+1] for j in range(code))
                if truth_values[0] and progresses:
                    assert lifted[code] and truth_values[nv]
                transfer_checks += 1

    return {
        "status": "passed",
        "scope": "Exact finite syntax checks and bounded standard-N diagnostics; not a formal proof of the metatheorem.",
        "bootstrap": bootstrap_rows,
        "seven_exact_exceptions": exception_rows,
        "recommended_selector": "seven_direct_identities",
        "exception_totals": {"full_boundaries": full_exception_total,
                             "direct_identities": direct_exception_total,
                             "saving": full_exception_total - direct_exception_total},
        "tested_computation_descriptors": len(bodies),
        "computation_examples": computation_rows,
        "tested_equations": len(equations),
        "boundary_family_checks": boundary_checks,
        "emitter_counts": kind_counts,
        "full_and_diagonal_costs": {
            "K": ["F+16", "F+15"],
            "J_covered": ["F+18", "F+17"],
            "J_forward": ["F+20", "F+19"],
            "J_direct": ["2F+i+11", "2F+i+10"]
        },
        "expanded_K_costs": {"full": "2F+18", "diagonal": "2F+17"},
        "pointwise_saving_against_old_K": {"omitted": 0, "direct_exception": 14, "other_retained": 1},
        "exhaustive_scanner_checks": scanner_checks,
        "actual_term_arithmetic_checks": arithmetic_checks,
        "clamped_diagonal_transfer_checks": transfer_checks,
        "encoding": "c=pair(a,n)=T(a+n)+n; target=pi2(c); parameter=pi1(c)",
        "clamp": "m(x,t)=d(t,d(t,x))",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional JSON check report")
    args = parser.parse_args()
    report = run_checks()
    rendered = json.dumps(report, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    summary = {k: v for k, v in report.items() if k != "computation_examples"}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
