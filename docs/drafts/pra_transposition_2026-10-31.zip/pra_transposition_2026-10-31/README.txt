PRA BY TRANSPOSITION
31 October 2026
============================================================

Read pra_transposition.pdf for the complete paper. Its editable source is
pra_transposition.tex together with sections/*.tex. axioms.txt is a concise
exact specification of both new presentations.

MAIN RESULT

The existing positive-base draft's admission condition allows three
computation rewrites to prove equality at input 1. Zero rewrites suffice:
literal equality after substituting 1 is enough. The same arithmetic
formula and initialized binary iterator grammar recover classical PRA
and intuitionistic PRA, separately in their own logics.

An equivalent version has no admission condition: for a single term
H(x,y,a), use the induction equation H(n,1,a)=H(1,n,a). Its boundary is
automatically reflexive. Three instances give the constructor facts;
an explicit padding term yields arbitrary equation induction.

CONTENTS

  pra_transposition.pdf      Complete 16-page paper with further questions
  pra_transposition.tex      Main LaTeX source
  sections/*.tex             All source sections
  axioms.txt                 Exact syntax, axioms, and scope
  formal/Core.lean           Checked constructive core
  formal/README.txt          Exact scope of the formal certificate
  formal/verification.log    Successful Lean 4.19.0 dependency audit
  lean-toolchain             Version pin
  artifacts/verify_syntax.py Independent syntax/compiler/count checker
  artifacts/verification_results.json  Actual checker results
  source_audit.json          Reviewed repository snapshot and source hashes
  VALIDATION.txt             Build, check, and PDF review record
  SHA256SUMS                SHA-256 manifest of delivered members
  build.sh                  Rebuild the PDF
  check.sh                  Replay syntax checks and Lean when available

REBUILD

From this directory:
  sh build.sh
  sh check.sh

Requirements: pdfLaTeX with common packages, Python 3.10 or later, and
Lean 4.19.0 for the optional local formal replay. No Python third-party
package or Lean library dependency is required. The scripts do not
download dependencies or execute source-archive programs.

VERIFICATION SCOPE

The complete equivalence is proved in the paper. The Lean certificate
checks the NEW logical core through equation induction over an abstract
type, using the schema as a functional callback. It does not formalize
the entire first-order object theory or the downstream pairing and
definitional-extension proof. All eight audited theorem dependencies are
empty. The independent Python checker tests literal finite syntax and
counts; its bounded numeric tests do not establish infinite theorems.

COMPARISON

PB0 has the same 39-node formula as PB3 and a simpler admission rule.
The separated version has 38 nodes. The unrestricted transposition
version has 51 nodes, since its one term has three slots and numeral 1
is expanded as S0. It trades a longer display for no admission condition
and one schematic term. It does not resolve the old two-slot fixed-point
schema's unproved elimination of its subtraction-shift axiom.

Repository snapshot reviewed:
  VladimirReshetnikov/ProveIt
  cb7be7c1b0b39cc05b1d54a3001e54b1159cc000

All six current docs/drafts archives were reviewed. docs/incoming was
checked at the listing/index level only. No repository mutation was
performed. Input archives are not duplicated in this package.
