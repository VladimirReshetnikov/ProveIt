#!/bin/sh
set -eu
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error pra_transposition.tex
pdflatex -interaction=nonstopmode -halt-on-error pra_transposition.tex
