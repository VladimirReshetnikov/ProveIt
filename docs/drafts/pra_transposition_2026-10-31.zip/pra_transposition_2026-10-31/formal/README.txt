LEAN CERTIFICATE SCOPE
============================================================

Core.lean compiles with Lean 4.19.0 without imports or third-party libraries.
It checks the new constructive kernel over an abstract type with fields
for zero, successor, predecessor, addition, and the zero gate.

The schema is supplied as a functional callback over Lean functions.
The paper supplies an explicit finite arithmetic term at every callback
application. This certificate does not encode first-order proof syntax,
the term-indexed schema recognizer, all primitive-recursion descriptions,
the formula compiler, pairing, or the conservative-extension theorem.

Checked reductions include:
  - the gate instance, separation, and native zero decision;
  - successor injectivity and nonzeroness;
  - addition by one from transposition;
  - positive predecessor coverage;
  - the selector requiring only addition by one;
  - the common carrier and padded transposition;
  - arbitrary equation induction under base and step hypotheses.

The eight printed theorem audits in verification.log all report that
they do not depend on any axioms. No sorry/admit, global axioms,
Classical.choice, or excluded-middle invocation is used.

Replay:
  lean Core.lean

The successful supplied log was produced with Lean 4.19.0, commit
6caaee842e94. The full written theorem is stronger in scope than this
kernel certificate; the paper states that distinction explicitly.
