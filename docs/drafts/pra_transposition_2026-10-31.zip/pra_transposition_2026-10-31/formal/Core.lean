/-
  PRA from transposition at one: constructive logical kernel.
  Checked with Lean 4.19.0, with no imports or classical reasoning.

  Scope of this certificate:
  * `Computation` records equations of three explicitly available initialized
    iterators (predecessor, addition, and the zero gate).
  * `Transpose` is an ABSTRACT FUNCTIONAL CALLBACK.  It is quantified over Lean
    functions, not over an encoded first-order term syntax.  In the paper every
    callback application below is supplied by a displayed finite syntactic term.
  * Thus this checks the constructive logical reductions and the concrete
    bootstrap calculations.  It does NOT by itself formalize first-order proof
    syntax, axiom recognition, the full comparison/pairing argument, or the
    conservative definitional equivalence theorem.

  No global axioms, `sorry`, `admit`, `Classical.choice`, or excluded middle are
  used.  The assumptions are ordinary structure fields and theorem arguments.
-/

universe u

namespace PRAAtOne

structure Computation (α : Type u) where
  zero : α
  succ : α → α
  pred : α → α
  add : α → α → α
  gate : α → α → α
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  add_zero : ∀ a, add zero a = a
  add_succ : ∀ n a, add (succ n) a = succ (add n a)
  gate_zero : ∀ a, gate zero a = a
  gate_succ : ∀ n a, gate (succ n) a = zero

variable {α : Type u}

def one (M : Computation α) : α := M.succ M.zero

def Transpose (M : Computation α) : Prop :=
  ∀ (h : α → α → α → α) (a : α),
    (∀ n, h n (one M) a = h (one M) n a →
      h (M.succ n) (one M) a = h (one M) (M.succ n) a) →
    M.zero ≠ one M ∧
      ∀ n, n = M.zero ∨ h n (one M) a = h (one M) n a

theorem pred_one (M : Computation α) : M.pred (one M) = M.zero :=
  M.pred_succ M.zero

theorem gate_one (M : Computation α) (a : α) :
    M.gate (one M) a = M.zero :=
  M.gate_succ M.zero a

theorem add_one_left (M : Computation α) (a : α) :
    M.add (one M) a = M.succ a := by
  change M.add (M.succ M.zero) a = M.succ a
  rw [M.add_succ, M.add_zero]

/- First transposition family: h(x,y,a) = gate(x,a). -/
theorem gate_bootstrap (M : Computation α) (tr : Transpose M) (a : α) :
    M.zero ≠ one M ∧
      ∀ n, n = M.zero ∨ M.gate n a = M.zero := by
  have h := tr (fun x _ a => M.gate x a) a (by
    intro n _
    change M.gate (M.succ n) a = M.gate (one M) a
    rw [M.gate_succ, gate_one])
  refine ⟨h.1, ?_⟩
  intro n
  rcases h.2 n with hz | he
  · exact Or.inl hz
  · exact Or.inr (he.trans (gate_one M a))

theorem separation (M : Computation α) (tr : Transpose M) :
    M.zero ≠ one M :=
  (gate_bootstrap M tr M.zero).1

theorem gate_nonzero (M : Computation α) (tr : Transpose M)
    (x a : α) (hx : x ≠ M.zero) : M.gate x a = M.zero := by
  rcases (gate_bootstrap M tr a).2 x with hz | he
  · exact False.elim (hx hz)
  · exact he

theorem zero_decision (M : Computation α) (tr : Transpose M) (x : α) :
    x = M.zero ∨ x ≠ M.zero := by
  rcases (gate_bootstrap M tr (one M)).2 x with hz | he
  · exact Or.inl hz
  · apply Or.inr
    intro hz
    have ho : one M = M.zero := by
      rw [hz, M.gate_zero] at he
      exact he
    exact separation M tr ho.symm

theorem successor_injective (M : Computation α) {x y : α}
    (h : M.succ x = M.succ y) : x = y := by
  have hp := congrArg M.pred h
  rw [M.pred_succ, M.pred_succ] at hp
  exact hp

theorem successor_nonzero (M : Computation α) (tr : Transpose M) (x : α) :
    M.succ x ≠ M.zero := by
  intro h
  have hp := congrArg M.pred h
  rw [M.pred_succ, M.pred_zero] at hp
  have ho : one M = M.zero := by
    change M.succ M.zero = M.zero
    exact (congrArg M.succ hp.symm).trans h
  exact separation M tr ho.symm

/- Second transposition instance: h(x,y,a) = add(x,y). -/
theorem add_one_right (M : Computation α) (tr : Transpose M) (n : α) :
    M.add n (one M) = M.succ n := by
  have h := tr (fun x y _ => M.add x y) M.zero (by
    intro k he
    change M.add (M.succ k) (one M) = M.add (one M) (M.succ k)
    calc
      M.add (M.succ k) (one M) = M.succ (M.add k (one M)) :=
        M.add_succ k (one M)
      _ = M.succ (M.add (one M) k) := congrArg M.succ he
      _ = M.succ (M.succ k) := congrArg M.succ (add_one_left M k)
      _ = M.add (one M) (M.succ k) := (add_one_left M (M.succ k)).symm)
  rcases h.2 n with hz | he
  · rw [hz, M.add_zero]
    rfl
  · exact he.trans (add_one_left M n)

/- Third transposition instance.  Its two boundary restrictions are exactly
   n and S(pred(n)); this supplies positive constructor coverage. -/
def coverage_term (M : Computation α) (x y : α) : α :=
  M.pred (M.add x (M.succ (M.pred y)))

theorem coverage_term_right (M : Computation α) (tr : Transpose M) (n : α) :
    coverage_term M n (one M) = n := by
  unfold coverage_term
  rw [pred_one]
  change M.pred (M.add n (one M)) = n
  rw [add_one_right M tr, M.pred_succ]

theorem coverage_term_left (M : Computation α) (n : α) :
    coverage_term M (one M) n = M.succ (M.pred n) := by
  unfold coverage_term
  rw [add_one_left, M.pred_succ]

theorem constructor_coverage (M : Computation α) (tr : Transpose M) (n : α) :
    n = M.zero ∨ n = M.succ (M.pred n) := by
  have h := tr (fun x y _ => coverage_term M x y) M.zero (by
    intro k _
    change coverage_term M (M.succ k) (one M) =
      coverage_term M (one M) (M.succ k)
    rw [coverage_term_right M tr, coverage_term_left, M.pred_succ])
  rcases h.2 n with hz | he
  · exact Or.inl hz
  · apply Or.inr
    change coverage_term M n (one M) = coverage_term M (one M) n at he
    rw [coverage_term_right M tr, coverage_term_left] at he
    exact he

/- A selector using addition at one, so no right-zero law is assumed. -/
def choose (M : Computation α) (x a b : α) : α :=
  M.pred (M.add (M.gate x a)
    (M.succ (M.gate (M.gate x (one M)) b)))

theorem choose_zero (M : Computation α) (tr : Transpose M) (a b : α) :
    choose M M.zero a b = a := by
  unfold choose
  rw [M.gate_zero, M.gate_zero, gate_one]
  change M.pred (M.add a (one M)) = a
  rw [add_one_right M tr, M.pred_succ]

theorem choose_nonzero (M : Computation α) (tr : Transpose M)
    (x a b : α) (hx : x ≠ M.zero) : choose M x a b = b := by
  unfold choose
  rw [gate_nonzero M tr x a hx, gate_nonzero M tr x (one M) hx]
  rw [M.gate_zero, M.add_zero, M.pred_succ]

theorem choose_successor (M : Computation α) (tr : Transpose M)
    (x a b : α) : choose M (M.succ x) a b = b :=
  choose_nonzero M tr (M.succ x) a b (successor_nonzero M tr x)

theorem choose_equal (M : Computation α) (tr : Transpose M)
    (x a : α) : choose M x a a = a := by
  rcases zero_decision M tr x with hz | hn
  · rw [hz, choose_zero M tr]
  · exact choose_nonzero M tr x a a hn

/- The common carrier recovers n on either boundary, allowing one term
   and its transpose to encode an arbitrary pair of terms. -/
def carrier (M : Computation α) (x y : α) : α :=
  M.pred (M.add x y)

theorem carrier_right (M : Computation α) (tr : Transpose M) (n : α) :
    carrier M n (one M) = n := by
  unfold carrier
  rw [add_one_right M tr, M.pred_succ]

theorem carrier_left (M : Computation α) (n : α) :
    carrier M (one M) n = n := by
  unfold carrier
  rw [add_one_left, M.pred_succ]

def padded (M : Computation α) (f g : α → α → α) (x y a : α) : α :=
  choose M (M.pred x)
    (f (M.pred (M.pred (carrier M x y))) a)
    (g (M.pred (M.pred (carrier M x y))) a)

theorem padded_left_double (M : Computation α) (tr : Transpose M)
    (f g : α → α → α) (n a : α) :
    padded M f g (M.succ (M.succ n)) (one M) a = g n a := by
  unfold padded
  rw [carrier_right M tr]
  rw [M.pred_succ, M.pred_succ, choose_successor M tr]

theorem padded_right_double (M : Computation α) (tr : Transpose M)
    (f g : α → α → α) (n a : α) :
    padded M f g (one M) (M.succ (M.succ n)) a = f n a := by
  unfold padded
  rw [carrier_left, pred_one]
  rw [choose_zero M tr, M.pred_succ, M.pred_succ]

theorem three_cases (M : Computation α) (tr : Transpose M) (n : α) :
    n = M.zero ∨ n = one M ∨ ∃ k, n = M.succ (M.succ k) := by
  rcases constructor_coverage M tr n with hz | hs
  · exact Or.inl hz
  · apply Or.inr
    rcases constructor_coverage M tr (M.pred n) with hpz | hps
    · apply Or.inl
      calc
        n = M.succ (M.pred n) := hs
        _ = M.succ M.zero := congrArg M.succ hpz
        _ = one M := rfl
    · apply Or.inr
      refine ⟨M.pred (M.pred n), ?_⟩
      exact hs.trans (congrArg M.succ hps)

/- Arbitrary equation induction, with one fixed numerical parameter.
   Every use of `tr` is a term displayed in this file. -/
theorem equation_induction (M : Computation α) (tr : Transpose M)
    (f g : α → α → α) (a : α)
    (base : f M.zero a = g M.zero a)
    (step : ∀ n, f n a = g n a → f (M.succ n) a = g (M.succ n) a) :
    ∀ n, f n a = g n a := by
  have h := tr (padded M f g) a (by
    intro n he
    rcases three_cases M tr n with hz | ho | ⟨k, hk⟩
    · rw [hz]
      change padded M f g (one M) (one M) a =
        padded M f g (one M) (one M) a
      rfl
    · rw [ho]
      change padded M f g (M.succ (M.succ M.zero)) (one M) a =
        padded M f g (one M) (M.succ (M.succ M.zero)) a
      rw [padded_left_double M tr, padded_right_double M tr]
      exact base.symm
    · rw [hk] at he ⊢
      rw [padded_left_double M tr, padded_right_double M tr] at he
      rw [padded_left_double M tr, padded_right_double M tr]
      exact (step k he.symm).symm)
  intro n
  rcases h.2 (M.succ (M.succ n)) with hz | he
  · exact False.elim (successor_nonzero M tr (M.succ n) hz)
  · rw [padded_left_double M tr, padded_right_double M tr] at he
    exact he.symm

#print axioms gate_bootstrap
#print axioms add_one_right
#print axioms constructor_coverage
#print axioms choose_zero
#print axioms padded_left_double
#print axioms padded_right_double
#print axioms three_cases
#print axioms equation_induction

end PRAAtOne
