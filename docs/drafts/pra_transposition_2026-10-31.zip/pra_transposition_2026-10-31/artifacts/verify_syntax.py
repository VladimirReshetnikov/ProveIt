#!/usr/bin/env python3
"""Independent syntax checks for PRA with a literal boundary or transposition.

Only Python's standard library is used.  No source-archive program is imported
or executed.  The finite syntax and numeral checks below are diagnostics and
are not a proof of the arithmetic theory's equivalence with PRA.

Run: python3 verify_syntax.py --output verification_results.json
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping


@dataclass(frozen=True)
class Term:
    kind: str
    label: str = ""
    args: tuple["Term", ...] = ()


def var(name: str) -> Term:
    return Term("variable", name)


ZERO = Term("zero")


def suc(t: Term) -> Term:
    return Term("successor", args=(t,))


ONE = suc(ZERO)
N, A_PARAM = var("n"), var("a")
X, Y = var("x"), var("y")
INDEX, STATE = var("i"), var("v")


def opaque(name: str, *args: Term) -> Term:
    """Syntactic test placeholder, not a declared PR function symbol."""
    return Term("opaque", name, args)


def free_vars(t: Term) -> frozenset[str]:
    if t.kind == "variable":
        return frozenset((t.label,))
    return frozenset().union(*(free_vars(c) for c in t.args))


def subst(t: Term, replacements: Mapping[str, Term]) -> Term:
    # Stored iterator descriptions are separate declarations.  Their bound
    # i,v variables are never affected by substitution in an application.
    if t.kind == "variable":
        return replacements.get(t.label, t)
    return Term(t.kind, t.label, tuple(subst(c, replacements) for c in t.args))


class Descriptions:
    def __init__(self) -> None:
        self.updates: dict[str, Term] = {}

    def declare(self, name: str, update: Term) -> str:
        assert name not in self.updates
        assert free_vars(update) <= {"i", "v"}
        self.check(update, allow_opaque=False)
        # check() precedes insertion: the new symbol cannot refer to itself.
        self.updates[name] = update
        return name

    def check(self, t: Term, *, allow_opaque: bool) -> None:
        if t.kind in ("variable", "zero"):
            assert not t.args
        elif t.kind == "successor":
            assert len(t.args) == 1
        elif t.kind == "iterator":
            assert t.label in self.updates and len(t.args) == 2
        elif t.kind == "opaque":
            assert allow_opaque
        else:
            raise AssertionError(f"Non-arithmetic node: {t.kind}")
        for child in t.args:
            self.check(child, allow_opaque=allow_opaque)


DESC = Descriptions()
P_ID = DESC.declare("P_index", INDEX)
B_ID = DESC.declare("B_zero", ZERO)
A_ID = DESC.declare("A_successor", suc(STATE))


def it(name: str, index: Term, seed: Term) -> Term:
    assert name in DESC.updates
    return Term("iterator", name, (index, seed))


def pred(x: Term) -> Term:
    return it(P_ID, x, ZERO)


def gate(x: Term, y: Term) -> Term:
    return it(B_ID, x, y)


def add(x: Term, y: Term) -> Term:
    return it(A_ID, x, y)


M_ID = DESC.declare("M_predecessor", pred(STATE))


def monus(x: Term, y: Term) -> Term:
    """The intended value is max(y-x,0)."""
    return it(M_ID, x, y)


def constructor_test(x: Term, y: Term) -> Term:
    return pred(add(x, suc(pred(y))))


def choose(x: Term, u: Term, v: Term) -> Term:
    # This version requires only x+1=Sx, not x+0=x.
    return pred(add(gate(x, u), suc(gate(gate(x, ONE), v))))


def mixed(x: Term, y: Term) -> Term:
    return pred(add(x, y))


def boundary(t: Term) -> Term:
    return subst(t, {"n": ONE})


def admitted(f: Term, g: Term) -> bool:
    """PB0 admission: literal tree equality, with ZERO rewrites."""
    return boundary(f) == boundary(g)


def pad(u: Term, v: Term) -> tuple[Term, Term]:
    delayed_n = pred(pred(N))
    uu, vv = subst(u, {"n": delayed_n}), subst(v, {"n": delayed_n})
    return choose(pred(N), uu, vv), choose(pred(ONE), uu, vv)


def transpose_padding(u: Term, v: Term) -> Term:
    delayed = pred(pred(mixed(X, Y)))
    return choose(
        pred(X),
        subst(u, {"n": delayed}),
        subst(v, {"n": delayed}),
    )


def sexpr(t: Term) -> str:
    if t.kind == "zero":
        return "0"
    if t.kind == "variable":
        return t.label
    head = {"successor": "S", "iterator": t.label,
            "opaque": t.label, "mixed_marker": "r"}.get(t.kind, t.kind)
    return "(" + head + " " + " ".join(map(sexpr, t.args)) + ")"


def compile_boundary_ir(f: Term, g: Term) -> Term:
    """Construct H with H(n,1,a)=f(n,a), H(1,n,a)=g(n,a).

    A mixed_marker is a compiler-only proof annotation for p(A(x,y)); it is
    lowered away before the resulting arithmetic term is checked.  It permits
    checking the two section identities structurally without also normalizing
    unrelated subterms of the input.  It is not a new arithmetic symbol.
    """
    assert free_vars(f) | free_vars(g) <= {"n", "a"}
    assert admitted(f, g)
    if f == N and g == N:
        return Term("mixed_marker", args=(X, Y))
    if f == N and g == ONE:
        return X
    if f == ONE and g == N:
        return Y
    assert f.kind == g.kind and f.label == g.label
    assert len(f.args) == len(g.args)
    if not f.args:
        assert f == g and f != N
        return f
    return Term(f.kind, f.label,
                tuple(compile_boundary_ir(a, b) for a, b in zip(f.args, g.args)))


def lower_ir(t: Term) -> Term:
    if t.kind == "mixed_marker":
        return mixed(*(lower_ir(c) for c in t.args))
    return Term(t.kind, t.label, tuple(lower_ir(c) for c in t.args))


def section_certificate(t: Term, side: str) -> Term:
    """Use ONLY r(n,1)=n or r(1,n)=n at compiler-marked positions."""
    assert side in ("left", "right")
    if t.kind == "mixed_marker":
        assert t.args == (X, Y)
        return N
    if t == X:
        return N if side == "left" else ONE
    if t == Y:
        return ONE if side == "left" else N
    return Term(t.kind, t.label,
                tuple(section_certificate(c, side) for c in t.args))


def compile_and_check(f: Term, g: Term) -> Term:
    tree = compile_boundary_ir(f, g)
    assert section_certificate(tree, "left") == f
    assert section_certificate(tree, "right") == g
    h = lower_ir(tree)
    assert free_vars(h) <= {"x", "y", "a"}
    DESC.check(h, allow_opaque=True)
    # Every transposition pair is literally equal at n=1 even before the
    # r-section identities are used.
    lhs = subst(h, {"x": N, "y": ONE})
    rhs = subst(h, {"x": ONE, "y": N})
    assert admitted(lhs, rhs)
    return h


def numeral(t: Term, env: Mapping[str, int],
            opaque_functions: Mapping[str, Callable[..., int]] | None = None) -> int:
    opaque_functions = opaque_functions or {}
    if t.kind == "zero":
        return 0
    if t.kind == "variable":
        return env[t.label]
    if t.kind == "successor":
        return numeral(t.args[0], env, opaque_functions) + 1
    if t.kind == "opaque":
        return opaque_functions[t.label](
            *(numeral(c, env, opaque_functions) for c in t.args))
    assert t.kind == "iterator"
    n, state = (numeral(c, env, opaque_functions) for c in t.args)
    assert n >= 0 and state >= 0
    for i in range(n):
        state = numeral(DESC.updates[t.label], {"i": i, "v": state},
                        opaque_functions)
    return state


@dataclass(frozen=True)
class FormulaTree:
    kind: str
    args: tuple["FormulaTree", ...] = ()
    label: str = ""


def node(kind: str, *args: FormulaTree, label: str = "") -> FormulaTree:
    return FormulaTree(kind, args, label)


def fv(name: str) -> FormulaTree:
    return node("variable", label=name)


def app(name: str, *args: FormulaTree) -> FormulaTree:
    return node("function", *args, label=name)


FZERO = node("constant", label="0")


def fs(t: FormulaTree) -> FormulaTree:
    return app("S", t)


FONE = fs(FZERO)
FN, FA, FX, FY = map(fv, ("n", "a", "x", "y"))


def eq(x: FormulaTree, y: FormulaTree) -> FormulaTree:
    return node("equality", x, y)


def implies(p: FormulaTree, q: FormulaTree) -> FormulaTree:
    return node("implies", p, q)


def all_(name: str, p: FormulaTree) -> FormulaTree:
    return node("forall", p, label=name)


SEP = implies(eq(FZERO, FONE), node("bottom"))


def e_two(n: FormulaTree) -> FormulaTree:
    return eq(app("f", n, FA), app("g", n, FA))


def e_identity(n: FormulaTree) -> FormulaTree:
    return eq(n, app("f", n, FA))


def e_transpose(n: FormulaTree) -> FormulaTree:
    return eq(app("H", n, FONE, FA), app("H", FONE, n, FA))


def propagation(e: Callable[[FormulaTree], FormulaTree], *, guarded: bool,
                packed: bool) -> list[FormulaTree]:
    guard = node("or", eq(FN, FZERO), e(FN))
    premise = all_("n", implies(guard if guarded else e(FN), e(fs(FN))))
    conclusion = all_("n", guard)
    if packed:
        conclusion = node("and", SEP, conclusion)
    f = all_("a", implies(premise, conclusion))
    return [f] if packed else [SEP, f]


def node_counts(t: FormulaTree) -> Counter[str]:
    c = Counter({t.kind: 1})
    for child in t.args:
        c.update(node_counts(child))
    return c


def formula_json(t: FormulaTree) -> dict:
    r: dict = {"kind": t.kind}
    if t.label:
        r["label"] = t.label
    if t.args:
        r["children"] = [formula_json(c) for c in t.args]
    return r


def metric_rows() -> dict:
    shift = all_("x", all_("y", eq(app("M", fs(FX), fs(FY)),
                                   app("M", FX, FY))))
    forms = {
        "old_K_packed": propagation(e_two, guarded=True, packed=True),
        "old_G_plus_Sep": propagation(e_two, guarded=True, packed=False),
        "old_PB3_and_new_PB0_packed": propagation(e_two, guarded=False, packed=True),
        "old_PB3_and_new_PB0_separated": propagation(e_two, guarded=False, packed=False),
        "old_one_term_T_plus_Shift":
            propagation(e_identity, guarded=True, packed=True) + [shift],
        "new_transpose_packed": propagation(e_transpose, guarded=False, packed=True),
        "new_transpose_separated": propagation(e_transpose, guarded=False, packed=False),
    }
    expected = {
        "old_K_packed": 43, "old_G_plus_Sep": 42,
        "old_PB3_and_new_PB0_packed": 39,
        "old_PB3_and_new_PB0_separated": 38,
        "old_one_term_T_plus_Shift": 48,
        "new_transpose_packed": 51,
        "new_transpose_separated": 50,
    }
    out = {}
    for name, formulas in forms.items():
        counts: Counter[str] = Counter()
        for f in formulas:
            counts.update(node_counts(f))
        total = sum(counts.values())
        assert total == expected[name], (name, total)
        out[name] = {
            "nodes": total, "equalities": counts["equality"],
            "arithmetic_templates": len(formulas),
            "total_templates_with_common_two_computation_templates": len(formulas) + 2,
            "counts_by_kind": dict(sorted(counts.items())),
            "formula_trees": [formula_json(f) for f in formulas],
        }
    return out


def enumerate_small_terms(max_size: int = 5) -> list[Term]:
    """Finite exhaustive grammar: 0,n,a; S; the declared binary B and A."""
    by_size: dict[int, set[Term]] = {1: {ZERO, N, A_PARAM}}
    for size in range(2, max_size + 1):
        ts = {suc(t) for t in by_size[size - 1]}
        for left_size in range(1, size - 1):
            right_size = size - 1 - left_size
            for x in by_size[left_size]:
                for y in by_size[right_size]:
                    for name in (B_ID, A_ID):
                        ts.add(it(name, x, y))
        by_size[size] = ts
    return sorted(set().union(*by_size.values()), key=sexpr)


def run_checks() -> dict:
    # Syntactic terms for all fixed constructions have no opaque symbols.
    concrete = {
        "p(n)": pred(N), "B(n,a)": gate(N, A_PARAM),
        "A(n,a)": add(N, A_PARAM), "T(x,y)": constructor_test(X, Y),
        "r(x,y)": mixed(X, Y),
        "C(x,u,v)": choose(X, var("u"), var("v")),
    }
    for t in concrete.values():
        DESC.check(t, allow_opaque=False)
    for update in DESC.updates.values():
        assert free_vars(update) <= {"i", "v"}

    cases = {
        "gate": (gate(N, A_PARAM), gate(ONE, A_PARAM)),
        "plus_one": (add(N, ONE), add(ONE, N)),
        "coverage": (constructor_test(N, ONE), constructor_test(ONE, N)),
    }
    u, v = opaque("u", N, A_PARAM), opaque("v", N, A_PARAM)
    cases["opaque_padding"] = pad(u, v)
    cases["concrete_padding"] = pad(add(N, A_PARAM), monus(N, A_PARAM))
    admission_records = {}
    for name, (left, right) in cases.items():
        assert free_vars(left) | free_vars(right) <= {"n", "a"}
        assert admitted(left, right)
        assert boundary(left) == boundary(right)  # no rewrite function exists here
        h = compile_and_check(left, right)
        admission_records[name] = {
            "literal_boundary_equal": True,
            "computation_rewrites_used": 0,
            "opaque_placeholders_present": "opaque" in name,
            "left": sexpr(left), "right": sexpr(right),
            "common_boundary_tree": sexpr(boundary(left)),
            "compiled_transpose_term": sexpr(h),
        }

    h_pad = transpose_padding(u, v)
    DESC.check(h_pad, allow_opaque=True)
    assert free_vars(h_pad) <= {"x", "y", "a"}
    assert admitted(subst(h_pad, {"x": N, "y": ONE}),
                    subst(h_pad, {"x": ONE, "y": N}))

    # Exhaustive check in the stated small grammar.  The general compiler's
    # mathematical correctness is by structural induction, not this finite run.
    terms = enumerate_small_terms(5)
    groups: dict[Term, list[Term]] = defaultdict(list)
    for t in terms:
        groups[boundary(t)].append(t)
    compiler_pairs = 0
    for group in groups.values():
        for left, right in itertools.product(group, repeat=2):
            compile_and_check(left, right)
            compiler_pairs += 1
    # Additional opaque patterns exercise shared n/n and n/1 holes together.
    opaque_pairs = [
        (opaque("q", N, N, A_PARAM), opaque("q", ONE, N, A_PARAM)),
        (opaque("q", N, ONE, A_PARAM), opaque("q", ONE, N, A_PARAM)),
        (opaque("q", suc(N), gate(N, A_PARAM)),
         opaque("q", suc(ONE), gate(ONE, A_PARAM))),
    ]
    for f, g in opaque_pairs:
        compile_and_check(f, g)

    numerical_assertions = 0

    def checked(b: bool) -> None:
        nonlocal numerical_assertions
        assert b
        numerical_assertions += 1

    opaque_values = {"u": lambda n, a: n + 2 * a,
                     "v": lambda n, a: n * n + a + 1}
    for n in range(10):
        for a in range(6):
            env = {"n": n, "a": a}
            checked(numeral(pred(N), env) == max(n - 1, 0))
            checked(numeral(gate(N, A_PARAM), env) == (a if n == 0 else 0))
            checked(numeral(add(N, ONE), env) == n + 1)
            checked(numeral(constructor_test(N, ONE), env) == n)
            checked(numeral(constructor_test(ONE, N), env) == max(n - 1, 0) + 1)
            checked(numeral(mixed(N, ONE), env) == n)
            checked(numeral(mixed(ONE, N), env) == n)
            f, g = cases["opaque_padding"]
            ef = numeral(f, env, opaque_values)
            eg = numeral(g, env, opaque_values)
            if n <= 1:
                checked(ef == eg)
            else:
                checked(ef == opaque_values["v"](n - 2, a))
                checked(eg == opaque_values["u"](n - 2, a))
            checked(numeral(subst(h_pad, {"x": N, "y": ONE}), env,
                            opaque_values) == ef)
            checked(numeral(subst(h_pad, {"x": ONE, "y": N}), env,
                            opaque_values) == eg)
    for x, u_value, v_value in itertools.product(range(6), repeat=3):
        env = {"x": x, "u": u_value, "v": v_value}
        checked(numeral(concrete["C(x,u,v)"], env) ==
                (u_value if x == 0 else v_value))

    return {
        "status": "All independently implemented checks passed.",
        "scope": {
            "proof_claim": "These executable checks are not a proof of PRA equivalence.",
            "syntax": "Finite tree syntax; descriptions are syntactic and well founded.",
            "admission": "Literal substitution n:=S0 and tree comparison; ZERO rewrites.",
            "compiler": (
                "Compiler-only mixed_marker denotes p(A(x,y)) and is lowered away. "
                "Section certificates use the already proved arithmetic laws "
                "r(n,1)=n and r(1,n)=n; they do not independently prove those laws."
            ),
            "opaque": (
                "Opaque applications are syntax placeholders in selected compiler/padding "
                "tests, not additional declared arithmetic functions. Separate concrete "
                "examples contain only permitted initialized iterators."
            ),
            "numerical": "Finite standard-natural evaluations are transcription diagnostics only.",
        },
        "declarations": [{"name": k, "update": sexpr(v),
                          "free_variables": sorted(free_vars(v))}
                         for k, v in DESC.updates.items()],
        "fixed_terms": {k: sexpr(v) for k, v in concrete.items()},
        "admission_examples": admission_records,
        "compiler_tests": {
            "small_term_grammar": "0,n,a; unary S; binary declared B and A; AST size <=5",
            "terms": len(terms), "boundary_groups": len(groups),
            "ordered_admitted_pairs_checked": compiler_pairs,
            "additional_opaque_pairs_checked": len(opaque_pairs),
        },
        "metric": {
            "unit": "One node per variable, constant, application, equality, connective, bottom, or quantifier binder.",
            "numeral_one": "Expanded as S0, including when it is an argument of H.",
            "negation": "Expanded as implication to bottom.",
            "parameters": "One outer parameter binder; every displayed parameter argument counted.",
            "repeated_subtrees": "Counted separately on each occurrence.",
            "separate_formulas": "Sum their counts without adding an artificial conjunction.",
            "excluded": ["Common two computation templates", "Admission recognizer", "Term-description bodies substituted for placeholders", "Logic and proof translation"],
            "caution": "The transpose presentation has 51/50 nodes under this metric, not 45/44; treating its six 1 arguments as atomic would change the metric.",
        },
        "schema_counts": metric_rows(),
        "numerical_diagnostics": {
            "n_range": [0, 9], "a_range": [0, 5],
            "selector_cube": [0, 5],
            "assertions": numerical_assertions,
            "role": "Finite checks, not a universal or formal arithmetic proof.",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = run_checks()
    payload = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(payload, encoding="utf-8")
        print(json.dumps({
            "status": report["status"], "output": str(args.output),
            "compiler_tests": report["compiler_tests"],
            "schema_nodes": {k: v["nodes"] for k, v in report["schema_counts"].items()},
            "numerical_assertions": report["numerical_diagnostics"]["assertions"],
        }, sort_keys=True))
    else:
        print(payload, end="")


if __name__ == "__main__":
    main()
