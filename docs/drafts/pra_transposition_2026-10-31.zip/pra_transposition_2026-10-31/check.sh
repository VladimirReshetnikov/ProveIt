#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/verify_syntax.py --output artifacts/verification_results.json
if command -v lean >/dev/null 2>&1; then
  lean --version
  lean formal/Core.lean > formal/verification.log
  cat formal/verification.log
else
  printf '%s\n' 'Lean is not on PATH: local formal replay skipped; see the supplied successful verification.log.'
fi
