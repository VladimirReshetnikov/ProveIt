#!/usr/bin/env python3
"""Reproduce syntax, numerical diagnostics, and source measurements offline."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
clock = ROOT / "code/clock"
subprocess.run([sys.executable, "clock_terms.py"], cwd=clock, check=True)
subprocess.run([sys.executable, "evaluate.py"], cwd=clock, check=True)
subprocess.run([sys.executable, str(ROOT / "code/measure_frontier.py")], cwd=ROOT, check=True)
subprocess.run([sys.executable, str(ROOT / "code/checker/reproduce.py")], cwd=ROOT, check=True)
print("PASS: all requested reproductions completed; these are not a formal proof of the report.")
