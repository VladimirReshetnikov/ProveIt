#!/usr/bin/env python3
"""Compile the complete manuscript with an ordinary LaTeX installation."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
engine = shutil.which("pdflatex")
if engine is None:
    raise SystemExit("Install pdflatex with the standard packages listed in report.tex.")
for _ in range(3):
    subprocess.run([engine, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                   cwd=ROOT, check=True)
print(ROOT / "report.pdf")
