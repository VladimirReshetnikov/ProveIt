ARRAY-ONLY COMPLETE CHECKER: 312-TOKEN PROFILE
============================================

This is a small implementation refinement of the inherited scalar/native
iPRA checker. It does not implement the new shifted-unary theory.

Run from this folder:
  python3 array_only.py < theorem.json
  python3 reproduce.py

The reproduction harness can also accept explicit paths:
  python3 reproduce.py --baseline PATH --normalizer PATH

The defaults use ../../reference/checkers/compact_unpack_open.py
and ../../reference/source_measure.py. It recognizes positive_fixtures.json
and cli_cases.json as the bundled inherited test inputs.

REVIEW.txt gives the successful-trace subset proof, canonical completeness,
termination argument, metric scope, and exact diagnostic boundary.
provenance.json records source and fixture hashes; results.json records
reproduced measurements and test outcomes. The inherited MIT No Attribution
license is preserved in LICENSE-inherited.txt.

Whole-program profile: 312 normalized tokens / 348 AST nodes / 920 bytes.
This lowers the inspected token record from 313 to 312. It does not improve
all coordinates. With this checker, the coordinate envelope is 312/347/878,
attained by different programs.

Provenance
----------
Parent source: compact_unpack_open.py in the current successor-from-recursion
archive at ProveIt commit deefab74912eef91a2cd1ba6686589cb8964466e.
Itself a source variant of the initializer kernel from earlier drafts.
Only code change: replace the traversal guard a.copy() with a+[].
The guard and its canonical-syntax justification are already used in the
inherited structural profile. This contribution combines that guard with
the inherited compact unpacking profile and supplies the subset/completeness
argument and regression evidence. No new arithmetic or logical rule is
claimed here.

The 147 positive fixtures are copied unchanged from the original kernel
archive at commit 06e097f723c659030816e0194e5eb7e8c607ba9b. The 13 public
CLI cases are copied unchanged from the current successor archive. Exact
paths and SHA-256 values are in provenance.json. Fixture origins and
original names remain inside those JSON files.
