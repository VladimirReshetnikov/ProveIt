#!/usr/bin/env python3
"""Replay inherited fixtures and measure a one-guard checker refinement.

The written simulation/completeness proof is in REVIEW.txt. Tests are finite
regression evidence, not a proof of the inherited calculus.
"""
from pathlib import Path
import argparse, ast, copy, hashlib, io, json, os, platform, random, runpy, subprocess, sys, tokenize
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--baseline',type=Path)
parser.add_argument('--normalizer',type=Path)
args=parser.parse_args()
CANDIDATE=ROOT/('array_only.py' if (ROOT/'array_only.py').exists() else 'checker.py')
BASELINE=args.baseline or (ROOT/'baseline.py' if (ROOT/'baseline.py').exists() else ROOT/'../../reference/checkers/compact_unpack_open.py')
NORMALIZER=args.normalizer or (ROOT/'source_measure.py' if (ROOT/'source_measure.py').exists() else ROOT/'../../reference/source_measure.py')
POSITIVE=ROOT/('positive_fixtures.json' if (ROOT/'positive_fixtures.json').exists() else 'inherited_positive_fixtures.json')
PUBLIC=ROOT/('cli_cases.json' if (ROOT/'cli_cases.json').exists() else 'inherited_cli_cases.json')
PROGRAMS={'baseline.py':BASELINE,'checker.py':CANDIDATE}
IGNORED={tokenize.ENCODING,tokenize.COMMENT,tokenize.NL,tokenize.NEWLINE,tokenize.INDENT,tokenize.DEDENT,tokenize.ENDMARKER}
class StripDocstrings(ast.NodeTransformer):
    def clean(self,node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0],ast.Expr)
            and isinstance(node.body[0].value,ast.Constant)
            and isinstance(node.body[0].value.value,str)):
            node.body=node.body[1:]
        return node
    visit_Module=clean
    visit_FunctionDef=clean
    visit_AsyncFunctionDef=clean
    visit_ClassDef=clean

def metrics(path):
    raw=path.read_bytes()
    tree=ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw.decode('utf-8'))))
    normalized=ast.unparse(tree)+'\n'
    return {'tokens':sum(t.type not in IGNORED for t in tokenize.generate_tokens(io.StringIO(normalized).readline)),
            'ast_nodes':sum(1 for _ in ast.walk(tree)), 'bytes':len(normalized.encode()),
            'sha256':hashlib.sha256(raw).hexdigest()}

def cli(program,data,optimize=False):
    args=[sys.executable,'-X','utf8']+(['-O'] if optimize else [])+[str(PROGRAMS[program])]
    env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8:strict')
    p=subprocess.run(args,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15,env=env)
    return {'exit_code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()}

def expected(accept):
    return {'exit_code':0 if accept else 1,'stdout':'ACCEPT\n' if accept else 'REJECT\n','stderr':''}

def definitions(name):
    tree=ast.parse(PROGRAMS[name].read_text())
    tree.body=[n for n in tree.body if not isinstance(n,ast.Try)]
    ns={};exec(compile(tree,str(PROGRAMS[name]),'exec'),ns)
    return ns

def run(ns,packet):
    try:
        ns['k']=0
        ns['take']=copy.deepcopy(packet).pop
        return bool(ns['check'](ns['take'](),[]))
    except BaseException:
        return False

provenance=json.loads((ROOT/'provenance.json').read_text())
for filename,key in [(BASELINE,'baseline_sha256'),(CANDIDATE,'candidate_sha256'),(POSITIVE,'positive_fixture_sha256'),(PUBLIC,'public_cli_fixture_sha256'),(NORMALIZER,'normalizer_sha256')]:
    assert hashlib.sha256(filename.read_bytes()).hexdigest()==provenance[key],str(filename)
old_source=BASELINE.read_text();new_source=CANDIDATE.read_text()
old_tree=StripDocstrings().visit(ast.parse(old_source.replace('for b in a.copy()','for b in a + []')))
new_tree=StripDocstrings().visit(ast.parse(new_source))
assert ast.dump(old_tree)==ast.dump(new_tree),'Unreviewed source change'
assert not any(isinstance(n,ast.Assert) for n in ast.walk(new_tree))

fixtures=json.loads(POSITIVE.read_text())['records']
cases=json.loads(PUBLIC.read_text())['cases']
jobs=[]
for f in fixtures:
    data=json.dumps(f['packet'],separators=(',',':')).encode()
    for program in ['baseline.py','checker.py']:
        jobs.append((program,data,False,True,f['name']))
for c in cases:
    for program in ['baseline.py','checker.py']:
        for opt in [False,True]:
            jobs.append((program,c['input_text'].encode(),opt,c['expected_accept'],c['name']))

def job(j):
    program,data,opt,accept,name=j
    got=cli(program,data,opt)
    return None if got==expected(accept) else {'program':program,'case':name,'optimized':opt,'got':got,'expected':expected(accept)}
with ThreadPoolExecutor(max_workers=8) as pool:
    failures=[x for x in pool.map(job,jobs) if x is not None]
assert not failures,failures[:5]

alias_cases=[
    ('ordinary_zero',[[0,0],[[0,0,0],0]],True,True),
    ('used_empty_object',[[0,0],[[0,{},0],{}]],True,False),
    ('unused_object_prefix',[{},[0,0],[[0,0,0],0]],True,True),
    ('used_empty_string',[[0,0],[[0,'',0],'']],False,False),
    ('used_single_character_string',[[0,0],[[0,'x',0],'x']],False,False),
    ('used_nonempty_object',[[0,0],[[0,{'x':0},0],{'x':0}]],False,False),
    ('boolean_alias',[[0,0],[[False,False,False],False]],True,True),
    ('fractional_zero_alias',[[0,0],[[0,.5,0],.5]],True,True),
]
alias_receipts=[]
for name,packet,old_accept,new_accept in alias_cases:
    data=json.dumps(packet).encode()
    old=cli('baseline.py',data);new=cli('checker.py',data)
    assert old==expected(old_accept) and new==expected(new_accept),(name,old,new)
    alias_receipts.append({'name':name,'old_accept':old_accept,'new_accept':new_accept})

# Mutations exercise malformed syntax without prescribing their theorem meaning.
# The required comparison is only candidate acceptance => baseline acceptance.
baseline=definitions('baseline.py');candidate=definitions('checker.py')
rng=random.Random(20261109)
replacements=[{}, {'x':0}, '', 'x', None,0,1,-1,True,.5,1.5,[0],[0,0],[0,0,0,0]]
mutations=1000; accepted_new=0; accepted_old_only=0
for _ in range(mutations):
    packet=copy.deepcopy(rng.choice(fixtures)['packet'])
    paths=[]
    def walk(v,path=()):
        paths.append(path)
        if isinstance(v,list):
            for i,w in enumerate(v):walk(w,path+(i,))
    walk(packet)
    path=rng.choice(paths);replacement=copy.deepcopy(rng.choice(replacements))
    if path:
        target=packet
        for i in path[:-1]:target=target[i]
        target[path[-1]]=replacement
    else:packet=replacement
    a=run(baseline,packet);b=run(candidate,packet)
    assert not b or a,'Simulation counterexample'
    accepted_new+=b;accepted_old_only+=a and not b

inherited_metrics=runpy.run_path(str(NORMALIZER))['metrics']
for program in [BASELINE,CANDIDATE]:
    mine=metrics(program);old=inherited_metrics(program)
    assert (mine['tokens'],mine['ast_nodes'],mine['bytes'])==(old['normalized_tokens'],old['ast_nodes'],old['normalized_bytes'])

result={
    'python':platform.python_version(),
    'baseline':metrics(BASELINE),'candidate':metrics(CANDIDATE),
    'old_corpus_envelope':{'tokens':313,'ast_nodes':347,'bytes':878},
    'new_envelope_with_candidate':{'tokens':312,'ast_nodes':347,'bytes':878},
    'strict_token_record':True,'strict_all_coordinates_improvement':False,
    'source_transform_ast_check':True,'assert_acceptance_gates':0,'inherited_normalizer_agrees':True,'normalizer_sha256':provenance['normalizer_sha256'],
    'inherited_positive_fixtures':len(fixtures),'positive_fixture_cli_runs':2*len(fixtures),
    'inherited_public_cli_cases':len(cases),'public_cli_runs_normal_and_optimized':4*len(cases),
    'additional_alias_cases':alias_receipts,'alias_cli_runs':2*len(alias_cases),
    'total_cli_runs':len(jobs)+2*len(alias_cases),'all_cli_checks_passed':True,
    'mutations':mutations,'mutated_inputs_accepted_by_both':accepted_new,
    'mutated_inputs_accepted_by_old_only':accepted_old_only,
    'mutation_subset_violations':0,
    'scope':'Small source refinement of the inherited scalar/native checker, independent of the new shifted-unary arithmetic. Written trace simulation proves soundness transfer; canonical-language invariance proves completeness transfer. Finite tests do not prove the inherited calculus sound.'}
(ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
