#!/usr/bin/env python3
"""Validate and evaluate the successor-valued shifted-unary clock.

Direct mode evaluates only the defining K recurrence, transparent macros,
memoization, and exact cycle skipping. Accelerated mode additionally uses
the disclosed elementary helper identities listed in ACCELERATED_HELPERS
and generic affine iteration. It never substitutes a predecessor formula,
any clock-tail formula, the formula for R, or a recovered I_h formula.

Successful numerical diagnostics do not prove an equation in all models.
The internal equation proof is a separate mathematical deliverable.
Adapted from the current shifted_unary evaluator; see ATTRIBUTION.txt.
"""

import argparse
import copy
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import random
import sys

from clock_terms import ZERO, call, iterate, signature


ACCELERATED_HELPERS = {
    "s": "n+1, by the definition s(n)=K_id(0,n)",
    "Z": "1 at zero, otherwise 0, by one K_0 step",
    "tau": "interchange 0 and 1; fix n>=2, by the independently checked equations",
    "identity_clock": "n, by zero-initialized successor iteration",
    "N": "n mod 2, by its exact two-state orbit",
    "M": "n mod 3, by its exact three-state orbit",
    "M4": "n mod 4, by its exact four-state orbit",
    "D": "2*n, by zero-initialized double-successor iteration",
    "A3": "3*n, by zero-initialized triple-successor iteration",
    "G": "n+floor(n/2), by its orbit 0,1,3,4,6,7,...",
}
AFFINE_UPDATES = {
    "id": (1, 0),
    "s": (1, 1),
    "s2": (1, 2),
    "s3": (1, 3),
    "initializer_update": (2, 8),
    "double_plus_one": (2, 1),
}


def freeze(term):
    if not isinstance(term, (list, tuple)):
        raise ValueError("term is not an array")
    if tuple(term) == ("0",):
        return ZERO
    if len(term) == 2 and term[0] == "v" and isinstance(term[1], str):
        return tuple(term)
    if len(term) == 3 and term[0] == "F" and isinstance(term[1], str):
        return ("F", term[1], freeze(term[2]))
    if len(term) == 4 and term[0] == "K" and isinstance(term[1], str):
        return ("K", term[1], freeze(term[2]), freeze(term[3]))
    raise ValueError("malformed term")


def inspect_term(term, earlier):
    if term[0] == "0":
        return set(), 1
    if term[0] == "v":
        return {term[1]}, 1
    if term[1] not in earlier:
        raise ValueError("a term refers to an unknown or later declaration: " + term[1])
    variables, nodes = set(), 1
    for child in term[2:]:
        found, count = inspect_term(child, earlier)
        variables |= found
        nodes += count
    return variables, nodes


def validate(data):
    definitions, total_nodes = {}, 0
    for item in data["definitions"]:
        name = item["name"]
        if not isinstance(name, str) or name in definitions:
            raise ValueError("malformed or repeated name")
        term = freeze(item["body"])
        variables, nodes = inspect_term(term, definitions)
        if not variables <= {"u"}:
            raise ValueError("a unary description captures an external variable")
        definitions[name] = term
        total_nodes += nodes
    if definitions.get("id") != ("v", "u"):
        raise ValueError("id must be the identity description")
    if definitions.get("s") != iterate("id", ZERO, ("v", "u")):
        raise ValueError("successor must expand to K_id(0,u)")
    if data.get("target") not in definitions:
        raise ValueError("missing target")
    return definitions, {
        "declarations": len(definitions),
        "nodes_in_declared_bodies": total_nodes,
        "all_descriptions_closed_unary": True,
        "all_references_to_earlier_declarations": True,
        "successor_is_an_abbreviation": True,
    }


class Evaluator:
    def __init__(self, data, accelerated=False, step_limit=5000000):
        self.definitions, self.validation = validate(data)
        if accelerated and self.definitions != validate(signature())[0]:
            raise ValueError("accelerated evaluation requires the exact bundled signature")
        self.accelerated = accelerated
        self.step_limit = step_limit
        self.steps = 0
        self.cycle_skips = 0
        self.affine_calls = 0
        self.helper_calls = 0

    def tick(self):
        self.steps += 1
        if self.steps > self.step_limit:
            raise RuntimeError("literal evaluation step budget exceeded")

    @lru_cache(maxsize=200000)
    def term(self, tree, environment):
        if tree[0] == "0":
            return 0
        if tree[0] == "v":
            return dict(environment)[tree[1]]
        if tree[0] == "F":
            return self.apply(tree[1], self.term(tree[2], environment))
        count = self.term(tree[2], environment)
        initial = self.term(tree[3], environment)
        return self.K(tree[1], count, initial)

    @lru_cache(maxsize=200000)
    def apply(self, name, value):
        if type(value) is not int or value < 0:
            raise ValueError("standard inputs must be nonnegative integers")
        if name not in self.definitions:
            raise ValueError("unknown unary term")
        if self.accelerated and name in ACCELERATED_HELPERS:
            self.helper_calls += 1
            if name == "s":
                return value + 1
            if name == "Z":
                return int(value == 0)
            if name == "tau":
                return 1 - value if value < 2 else value
            if name == "identity_clock":
                return value
            if name in ("N", "M", "M4"):
                return value % {"N": 2, "M": 3, "M4": 4}[name]
            if name == "D":
                return 2 * value
            if name == "A3":
                return 3 * value
            if name == "G":
                return value + value // 2
        return self.term(self.definitions[name], (("u", value),))

    @lru_cache(maxsize=200000)
    def K(self, name, count, initializer):
        if type(count) is not int or type(initializer) is not int or min(count, initializer) < 0:
            raise ValueError("standard iterator arguments must be nonnegative integers")
        if self.accelerated and name in AFFINE_UPDATES:
            self.affine_calls += 1
            coefficient, constant = AFFINE_UPDATES[name]
            if coefficient == 1:
                return initializer + 1 + constant * count
            power = coefficient ** count
            return power * (initializer + 1) + constant * ((power - 1) // (coefficient - 1))
        value, position, seen = initializer + 1, 0, {}
        while position < count:
            self.tick()
            if value in seen:
                period = position - seen[value]
                skip = (count - position) // period
                if skip:
                    position += skip * period
                    self.cycle_skips += 1
                    continue
            else:
                seen[value] = position
            value = self.apply(name, value)
            position += 1
        return value

    def recovered_iterator(self, update, count, initializer):
        # This is a literal source term, with two external inputs.
        term = call("P", iterate("lift_" + update, ("v", "n"), ("v", "a")))
        return self.term(term, (("a", initializer), ("n", count)))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def diagnostics(data):
    direct = Evaluator(data, accelerated=False)
    fast = Evaluator(data, accelerated=True)
    helper_cases = 0
    for name in ACCELERATED_HELPERS:
        for n in range(25):
            require(direct.apply(name, n) == fast.apply(name, n),
                    "helper acceleration disagrees with its source: " + name)
            helper_cases += 1
    affine_cases = 0
    for name in AFFINE_UPDATES:
        for n in range(4):
            for a in range(4):
                require(direct.K(name, n, a) == fast.K(name, n, a),
                        "affine acceleration disagrees with its source: " + name)
                affine_cases += 1
    control_names = ("cycle3", "cycle4", "b", "f", "e", "V", "T", "H", "F", "Psi",
                     "r", "prefix_bit", "prefix_step", "prefix_clock", "c")
    control_cases = 0
    for name in control_names:
        for n in range(17):
            require(direct.apply(name, n) == fast.apply(name, n),
                    "control term differs between evaluators: " + name)
            control_cases += 1

    counts = {}

    def eq(label, observed, expected):
        require(observed == expected,
                label + " failed: observed " + str(observed) + ", expected " + str(expected))
        counts[label] = counts.get(label, 0) + 1

    F = fast.apply
    W = lambda t, a: fast.K("T", t, a)

    # Every expected value below is separate from AST evaluation.
    for x in range(129):
        eq("affine_identity_AFF", F("G", 12 + F("A3", x)),
           fast.K("s", F("N", x), 17 + F("A3", F("G", x))))
        eq("ramp_three_steps", F("R", x + 3), F("R", x) + 4)
        v = x + 7
        expected_T = 3 * v // 2 - 7 if v % 6 == 0 else 1 if v % 3 == 0 else x + 3
        eq("clock_phase_T", F("T", x), expected_T)
        eq("successor_valued_T", F("T", x), F("V", x) + 1)
        expected_F = 3 * x + 17 if (x + 8) % 3 == 0 else x + 1
        eq("coordinate_F", F("F", x), expected_F)
        eq("commutation_COMM", F("T", F("F", x)), F("F", F("V", x + 1)))
        eq("global_commutation_PSI", F("T", F("Psi", x)), F("Psi", F("T", x)))
        for bit in ("b", "f", "e"):
            eq("bit_preservation_" + bit, F(bit, F("F", x)), F(bit, x + 1))
        if F("f", x + 1) == 0:
            eq("inactive_factor_bit", F("f", F("T", F("F", x))), 0)
            eq("inactive_first_observation", F("V", F("F", x)), F("V", x + 1))
            eq("inactive_next_observation", F("V", F("T", F("F", x))),
               F("V", x + 1) + 3)

    seed_cases, exit_cases = [], []
    for n in range(49):
        seed = F("a", n)
        eq("seed_affine_value", seed, 12 * 2 ** n - 8)
        eq("seed_mod3", F("M", seed + 8), 0)
        eq("seed_parity", F("N", seed + 8), 0)
        eq("seed_relation", F("T", F("a", n + 1) + 1), F("F", seed))
        before_exit = W(n + 2, seed)
        eq("exit_bit", F("e", before_exit), 1)
        eq("exit_observation", F("V", before_exit), 0)
        eq("exit_state", W(n + 3, seed), 1)
        seed_cases.append({"n": n, "seed": seed})
        exit_cases.append({"n": n, "pre_exit_state": before_exit,
                           "exit_state": W(n + 3, seed)})
    for n in range(17):
        for t in range(21):
            eq("diagonal_shift_SHIFT", W(t + 2, F("a", n + 1)),
               F("Psi", W(t, F("a", n))))

    observations, predecessor_cases = [], []
    for n in range(129):
        q = F("q", n)
        b = F("B", n)
        eq("inactive_observation", F("f", q), 0)
        eq("observation_expected_value", b, 3 * (n // 3))
        eq("count_identity_COUNT", fast.K("s", F("M", n), b), n + 1)
        eq("observation_recurrence", F("B", n + 1), b + (3 if n % 3 == 2 else 0))
        z = F("Psi", F("obs_p", n))
        eq("q_step", F("q", n + 1), F("T", z) if n % 3 == 2 else z)
        eq("Bminus_shift", F("Bminus", n + 3), b)
        eq("predecessor_tail", F("P", n + 3), n + 2)
        observed = F("P", n)
        eq("predecessor", observed, max(0, n - 1))
        predecessor_cases.append({"n": n, "value": observed})
        observations.append({"n": n, "q": q, "B": b})

    rng, iterator_cases = random.Random(20261108), []
    updates = ["zero", "id", "s", "s2", "tau", "double_plus_one"]
    for update in updates:
        for _ in range(8):
            n, a = rng.randrange(5), rng.randrange(5)
            expected = a
            for _ in range(n):
                expected = F(update, expected)
            observed = fast.recovered_iterator(update, n, a)
            eq("recovered_iterator", observed, expected)
            iterator_cases.append({"update": update, "n": n, "a": a, "value": observed})

    mutations = []
    for name in ("capture", "forward_reference", "nonidentity_anchor", "malformed_term",
                 "duplicate_declaration", "unknown_update"):
        altered = copy.deepcopy(data)
        if name == "capture":
            altered["definitions"][-1]["body"] = ["v", "captured_parameter"]
        elif name == "forward_reference":
            altered["definitions"][0]["body"] = ["F", "P", ["v", "u"]]
        elif name == "nonidentity_anchor":
            altered["definitions"][0]["body"] = ["0"]
        elif name == "malformed_term":
            altered["definitions"][-1]["body"] = ["S", ["v", "u"]]
        elif name == "duplicate_declaration":
            altered["definitions"][-1]["name"] = "id"
        else:
            altered["definitions"][-1]["body"] = ["K", "missing", ["0"], ["0"]]
        try:
            validate(altered)
        except ValueError:
            mutations.append({"name": name, "rejected": True})
        else:
            raise ValueError("invalid signature accepted: " + name)

    # A valid alternate table must not inherit the fixed-table accelerators.
    altered = copy.deepcopy(data)
    next(x for x in altered["definitions"] if x["name"] == "G")["body"] = ["0"]
    validate(altered)
    try:
        Evaluator(altered, accelerated=True)
    except ValueError:
        acceleration_guard_rejected = True
    else:
        raise ValueError("altered helper silently retained old acceleration")

    encoded = (json.dumps(data, indent=2) + "\n").encode()
    return {
        "status": "PASS",
        "scope": "Finite standard-model numerical diagnostics and staged closed-unary syntax validation. This is not an internal proof checker or a formal proof of the report's universal claims.",
        "terms_sha256": hashlib.sha256(encoded).hexdigest(),
        "syntax_validation": fast.validation,
        "direct_helper_cases": helper_cases,
        "direct_affine_iterator_cases": affine_cases,
        "direct_control_cases": control_cases,
        "equation_diagnostic_counts": counts,
        "equation_diagnostic_total": sum(counts.values()),
        "direct_total_iteration_steps": direct.steps,
        "direct_exact_cycle_skips": direct.cycle_skips,
        "accelerated_total_iteration_steps": fast.steps,
        "accelerated_helper_calls": fast.helper_calls,
        "accelerated_affine_iterator_calls": fast.affine_calls,
        "accelerated_helpers": ACCELERATED_HELPERS,
        "affine_updates": AFFINE_UPDATES,
        "acceleration_signature_guard": "The complete table must exactly match clock_terms.signature(); alternate staged terms require direct mode.",
        "altered_helper_acceleration_rejected": acceleration_guard_rejected,
        "seed_cases": seed_cases,
        "exit_cases": exit_cases,
        "observation_cases": observations,
        "predecessor_cases": predecessor_cases,
        "recovered_iterator_cases": iterator_cases,
        "malformed_signature_cases": mutations,
        "deterministic_random_seed": 20261108,
        "python": sys.version,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--terms", type=Path, default=Path(__file__).with_name("terms.json"))
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("diagnostics.json"))
    parser.add_argument("--evaluate", nargs=2, metavar=("UNARY_NAME", "N"))
    parser.add_argument("--direct", action="store_true")
    args = parser.parse_args()
    data = json.loads(args.terms.read_text()) if args.terms.exists() else signature()
    if args.evaluate:
        evaluator = Evaluator(data, accelerated=not args.direct)
        name, number = args.evaluate
        print(evaluator.apply(name, int(number)))
        return
    result = diagnostics(data)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in (
        "status", "scope", "syntax_validation", "direct_helper_cases",
        "direct_affine_iterator_cases", "direct_control_cases",
        "direct_total_iteration_steps", "accelerated_total_iteration_steps")}, indent=2))


if __name__ == "__main__":
    main()
