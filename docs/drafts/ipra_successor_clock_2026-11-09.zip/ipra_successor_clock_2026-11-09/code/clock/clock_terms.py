#!/usr/bin/env python3
"""Finite staged source for the successor-valued shifted-unary clock.

Syntax and the tau / residue bootstrap are adapted from the current
ipra_shifted_unary_2026-11-08/code/clock/clock_terms.py. See ATTRIBUTION.txt.
All numerical terms use 0, variables, and K_h(n,a), with h a previously
declared closed unary description. F(name,t) is transparent abbreviation.
Successor expands to K_id(0,t). No primitive predecessor is introduced.

This is a source declaration table, not a proof checker.
"""

import json
from pathlib import Path

ZERO = ("0",)
U = ("v", "u")


def call(name, argument):
    return ("F", name, argument)


def iterate(name, count, initializer):
    return ("K", name, count, initializer)


def signature():
    definitions = []

    def define(name, body):
        definitions.append({"name": name, "body": body})
        return name

    define("id", U)
    define("zero", ZERO)
    define("s", iterate("id", ZERO, U))

    def s(term, count=1):
        for _ in range(count):
            term = call("s", term)
        return term

    one, three = s(ZERO), s(ZERO, 3)
    define("Z", iterate("zero", U, ZERO))
    define("parity_from_one", iterate("Z", U, ZERO))
    define("bootstrap_H", iterate("zero", call("parity_from_one", U), one))
    define("bootstrap_V", iterate("bootstrap_H", U, ZERO))
    define("bootstrap_B2", call("Z", call("Z", call("bootstrap_V", U))))
    define("bootstrap_U", iterate("bootstrap_H", call("bootstrap_B2", U), U))
    define("tau", iterate("bootstrap_U", U, ZERO))

    def zero_iteration(update, name):
        conjugate = "conjugate_for_" + name
        define(conjugate, call("tau", call(update, call("tau", U))))
        define(name, call("tau", iterate(conjugate, U, ZERO)))
        return name

    def conjunction(b, c):
        return call("Z", call("tau", iterate("zero", call("Z", b), call("Z", c))))

    def disjunction(b, c):
        return call("Z", conjunction(call("Z", b), call("Z", c)))

    zero_iteration("s", "identity_clock")
    zero_iteration("Z", "N")
    define("cycle3", iterate("zero", conjunction(call("Z", call("N", U)),
                                                 call("Z", call("Z", U))), U))
    zero_iteration("cycle3", "M")
    define("cycle4", iterate("zero", conjunction(call("N", U),
                                                 call("Z", call("M", U))), U))
    zero_iteration("cycle4", "M4")
    define("s2", s(U, 2))
    zero_iteration("s2", "D")
    define("s3", s(U, 3))
    zero_iteration("s3", "A3")
    define("g", iterate("s", call("M", U), U))
    zero_iteration("g", "G")

    # A three-step ramp; this source is evaluated, never replaced by its floor formula.
    define("e4", call("Z", call("M4", s(U, 2))))
    define("r", iterate("s", call("e4", U), U))
    zero_iteration("r", "R")

    # New clock. T is literally a successor on all inputs.
    shifted = s(U, 7)
    define("b", call("Z", call("M", shifted)))
    define("f", conjunction(call("b", U), call("Z", call("N", shifted))))
    define("e", conjunction(call("b", U), call("N", shifted)))
    define("V", iterate("zero", call("e", U), iterate("G", call("f", U), U)))
    define("T", s(call("V", U)))
    define("H", s(call("A3", U), 14))
    define("F", iterate("H", call("b", s(U)), U))
    define("Psi", call("F", call("V", U)))
    define("initializer_update", s(call("D", U), 8))
    define("a", iterate("initializer_update", U, three))

    # W(t,a) is exactly K_T(t,a); it has no separate declaration.
    define("obs_p", iterate("T", s(call("R", U), 10), call("a", s(U, 9))))
    define("q", iterate("T", s(call("R", U), 11), call("a", s(U, 9))))
    define("B", call("V", call("q", U)))

    # Inherited finite prefix patch; all indices remain closed unary.
    define("prefix_bit", disjunction(call("Z", call("M4", U)),
                                      call("Z", call("M4", s(U)))))
    define("prefix_step", iterate("zero", call("prefix_bit", U), U))
    define("prefix_clock", iterate("prefix_step", U, ZERO))
    define("c", iterate("zero", call("Z", call("prefix_clock", U)),
                         call("Z", call("M4", s(call("prefix_clock", U))))))
    define("Bminus", call("V", iterate("T", s(call("R", U), 7),
                                         call("a", s(U, 6)))))
    define("P", iterate("Z", call("c", U),
                         iterate("s", call("M", s(U, 6)), call("Bminus", U))))

    # These closed updates and their lifts are only initializer diagnostics.
    define("double_plus_one", iterate("s", U, U))
    for update in ("zero", "id", "s", "s2", "tau", "double_plus_one"):
        define("lift_" + update, s(call(update, call("P", U))))

    return {
        "primitive_syntax": ["zero", "variable", "K indexed by a closed earlier unary term"],
        "standard_meaning": "K_h(n,a)=h^n(a+1)",
        "successor_abbreviation": ["K", "id", ["0"], ["v", "u"]],
        "definitions": definitions,
        "target": "P",
        "status": "Finite staged construction. Numerical diagnostics do not replace the internal proof in the accompanying report.",
    }


if __name__ == "__main__":
    destination = Path(__file__).with_name("terms.json")
    destination.write_text(json.dumps(signature(), indent=2) + "\n")
    print(destination.name)
