SUCCESSOR-VALUED SHIFTED-UNARY CLOCK: REPRODUCIBLE DIAGNOSTICS
===========================================================

Purpose and scope
-----------------
This directory gives a finite staged source description of the new
predecessor P and reproducible numerical diagnostics. The primitive
numerical syntax is zero, variables, and K_h(n,a), with a fixed earlier
closed unary update h. Its standard meaning is h iterated n times from
a+1. Successor s(u) is the abbreviation K_id(0,u).

The accompanying report supplies the internal mathematical proof. These
programs validate staged syntax and finite standard-number instances.
They are not a complete iPRA proof checker, do not verify the internal
induction proof, and do not establish a smaller complete proof checker.
In particular, testing standard inputs does not establish validity in
every nonstandard model of the proposed arithmetic.

Files
-----
clock_terms.py       Constructs the complete staged declaration table.
terms.json           Generated source table; no uninterpreted update.
evaluate.py          Validates and evaluates that table; runs diagnostics.
diagnostics.json     Complete reproducible numerical results.
ATTRIBUTION.txt      Baseline source, adaptation, and contribution boundary.
LICENSE-inherited.txt  The retained inherited code license.

Reproduction (Python 3.10+, standard library only)
-------------------------------------------------
From this directory:

  python3 clock_terms.py
  python3 evaluate.py

Evaluate the actual final source term, for example:

  python3 evaluate.py --evaluate P 40

This prints 39. By default the disclosed elementary helper accelerations
below are used. For literal defining-equation evaluation of a small helper:

  python3 evaluate.py --direct --evaluate tau 12

Direct evaluation of the full clock is deliberately expensive because
the source visits exponentially large states. Direct mode has an explicit
iteration-step budget and can stop with a budget-exceeded error.

Source names and the mathematical construction
---------------------------------------------
id, zero, s          Identity, zero update, and derived successor.
bootstrap_*         Inherited finite-transposition construction.
tau                 Interchanges 0 and 1 and fixes higher numerals.
N, M, M4            Residues modulo 2, 3, and 4.
D, A3               Doubling and tripling by zero-started iteration.
G                   Factor converter with standard value floor(3n/2).
R                   Inherited ramp, evaluated from its source recurrence.
b, f, e             Transient, factor, and exit bits at coordinate u+7.
V, T                New clock, with T literally defined as s(V(u)).
H, F, Psi           The affine update, coordinate map, and commuting map.
a                   New seed, K_{s^8 D}(n,3).
obs_p, q, B         Clock observations used in the internal count proof.
prefix_* and c      The finite prefix patch.
Bminus, P           The final finite staged predecessor construction.
lift_*              Diagnostic updates for recovered initialization.

The table has 59 unary declarations and 375 nodes in their declared
bodies. These counts include named proof helpers and diagnostic-only
updates. They measure a shared declaration table, not fully inlined
syntax and not a complete proof-checker program.

Evaluation contract
-------------------
Direct mode implements only transparent source abbreviation expansion,
K_h(n,a)=h^n(a+1), memoization, and exact cycle skipping. A cycle is skipped
only after an identical integer state actually repeats under the same
fixed update.

Accelerated mode additionally uses these explicitly named identities:

  s(n)=n+1;
  Z(n)=1 at zero and 0 otherwise;
  tau interchanges 0,1 and fixes all n>=2;
  identity_clock(n)=n;
  N(n)=n mod 2, M(n)=n mod 3, M4(n)=n mod 4;
  D(n)=2n, A3(n)=3n;
  G(n)=n+floor(n/2).

It sums iterates of these explicitly declared affine updates exactly:

  id:                 h(u)=u
  s:                  h(u)=u+1
  s2:                 h(u)=u+2
  s3:                 h(u)=u+3
  initializer_update: h(u)=2u+8
  double_plus_one:    h(u)=2u+1

For h(u)=c*u+d with c>1 it uses
  K_h(n,a)=c^n*(a+1)+d*(c^n-1)/(c-1);
for c=1 it uses a+1+d*n.

Accelerated evaluation requires every declaration to match the bundled
source table exactly. A changed but well-staged source can use direct
mode; it cannot silently retain a stale helper shortcut.

The evaluator never replaces P by truncated subtraction, B by its
counting formula, R by a quotient formula, T by its phase formula, F by
its case formula, any observation by a clock-tail formula, or recovered
iteration by ordinary iteration. These appear only as independent
expected values in diagnostic comparisons. Actual T, F, Psi, q, B,
Bminus, P, and lifted iterators are evaluated from their source trees.

Recorded evidence
-----------------
The generated diagnostic result reports PASS for:

  * 250 elementary helper values compared with direct source evaluation;
  * 96 affine iterator instances compared with direct source evaluation;
  * 255 control/clock values compared with direct source evaluation;
  * 3394 finite equation instances for the new construction;
  * 6 malformed staged signatures, each rejected;
  * an altered but valid helper table, rejected in accelerated mode.

The equation instances include AFF, COMM, PSI, the three preserved bits,
the inactive observation equations, seed properties, the diagonal shift,
the pre-exit bit, the count identity, the predecessor, and recovery of
initialized iteration. The final P is checked on 0..128, and its shifted
tail on 3..131. The diagonal shift is checked for n=0..16 and t=0..20;
seed and exit equations are checked for n=0..48. The recovered-iterator
samples use the fixed random seed 20261108.

The direct comparisons require 4622 literal update steps; the remaining
source computations use 50964 update steps plus the disclosed helper and
affine accelerations. These are reproducibility details, not complexity
bounds for the represented functions or for a proof checker.

No finite number of these computations is a replacement for the internal
literal-equation-induction argument, its freshness conditions, or the
two definable interpretation composites.
