#!/usr/bin/env python3
"""Remeasure unchanged complete comparators without executing their code."""
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("inherited_source_measure", ROOT / "reference/source_measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)


def main():
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    rows = []
    for path in sorted((ROOT / "reference/checkers").glob("*.py")):
        result = measure.metrics(path)
        rows.append({"file": path.name, **{key: result[key] for key in fields},
                     "sha256": result["sha256"], "raw_bytes": result["raw_bytes"]})
    envelope = {field: min(row[field] for row in rows) for field in fields}
    result = {"python": platform.python_version(), "programs_measured": len(rows),
              "whole_program_boundary": True, "comparator_code_executed": False,
              "coordinate_envelope": envelope,
              "attainers": {field: [row["file"] for row in rows if row[field] == envelope[field]]
                            for field in fields}, "programs": rows}
    destination = ROOT / "evidence/comparator_measurements.json"
    destination.write_text(json.dumps(result, indent=2) + "\n")
    if len(rows) != 16:
        raise ValueError("The comparison set must contain all sixteen retained sources")
    if platform.python_version_tuple()[:2] == ("3", "12"):
        if envelope != dict(zip(fields, (313, 347, 878))):
            raise ValueError("The reproduced frontier differs from the report")
    print(json.dumps({key: value for key, value in result.items() if key != "programs"}, indent=2))


if __name__ == "__main__":
    main()
