A RETRACTION-FREE SHIFTED-UNARY PRESENTATION OF iPRA
=================================================
Research report, November 9, 2026.
Repository snapshot: deefab74912eef91a2cd1ba6686589cb8964466e

RESULT AND LIMIT
----------------
The report proves a substantive mathematical improvement over the current
shifted_unary draft. Its fixed extra predecessor-retraction axiom can be
deleted. In addition, primitive zero/successor coverage can be replaced
by the simpler zero-test Boolean-range axiom Z(x)=0 or Z(x)=1.

The final source theory has zero and staged shifted closed-unary iteration,
with successor defined as a section of that constructor; two computation
schemas; literal-equation induction; zero-test Boolean range; and the
genuine-falsity bridge. Full ordinary intuitionistic logical rules are
listed explicitly. A new successor-valued clock proves an internal
predecessor without successor cancellation or compound induction. It then
recovers ordinary initialized iteration and full first-order iPRA, with
both interpretation composites proved to be the identity.

Separately, a complete array-only checker lowers the observed token record
from 313 to 312. It measures 312 tokens / 348 AST nodes / 920 bytes, using
the same whole-program normalizer. This is a small traversal change to the
inherited native calculus, independent of the arithmetic theorem above.
One checker strictly below all inherited coordinate minima 313 / 347 / 878
is NOT established. No global simplestness or historical-priority claim
is made. The clock proof is a written mathematical proof, not a Lean/Rocq
formalization; finite numerical diagnostics do not replace that proof.

CONTENTS
--------
report.tex, sections/       Complete LaTeX manuscript and full proofs.
report.pdf                 Compiled manuscript.
code/clock/                Complete staged term table, evaluator, diagnostics.
code/checker/              Complete 312-token checker, preservation argument,
                          source provenance, CLI packets, and replay script.
code/measure_frontier.py   Whole-program comparison reproduction.
evidence/                 Repository identity, measurements, independent review.
reference/checkers/        Sixteen unchanged complete comparator programs.
reference/source_measure.py
                          The unchanged inherited source normalizer.
reference/ipra_closed_equational_2026-11-08.zip
                          Exact inherited internal arithmetic reconstruction,
                          including its LaTeX, PDF, and supporting artifacts.
reference/LICENSE-inherited.txt
                          License retained with comparator sources.
reproduce.py              Runs all offline diagnostic reproductions.
build.py                  Compiles report.tex with pdflatex.
MANIFEST.json             SHA-256 identities of the delivered package members.

REPRODUCTION
------------
  python3 reproduce.py
  python3 build.py

The diagnostics need Python 3.10+ and only its standard library.
Use CPython 3.12 to reproduce the stated ast.unparse source measurements.
Other versions can format the same source differently. PDF compilation
needs a standard pdflatex installation and the packages in report.tex.

For a particular evaluation:
  python3 code/clock/evaluate.py --evaluate P 40

For literal defining-equation evaluation of a small helper:
  python3 code/clock/evaluate.py --direct --evaluate tau 12

The clock evaluator explicitly discloses elementary helper and affine
accelerations. It does not replace the new predecessor, ramp, clock, or
observations by the expected formulas being tested. See its own README
for exact ranges, limits, and the acceleration contract.

ATTRIBUTION
-----------
The transposition/zero-start bootstrap and finite prefix patch are
inherited from the current shifted_unary report. The complete ordinary
closed-iteration reconstruction, logical comparison basis, and comparator
programs are inherited from the ProveIt drafts. The new contribution is
the successor-valued clock, positive-coordinate commutation and observation
proof, resulting internal retraction, and BR-only dependency refinement.
Claims of novelty are relative to the inspected ten-archive corpus.
The separate checker variant combines the inherited array-only guard with
the compact unpacking profile; it claims a new measured token record, not
a new logical rule or a novel traversal mechanism.
This research did not modify the GitHub repository.
