"""Run the offline checks and optionally rebuild the PDF."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--pdf', action='store_true', help='also compile report.tex with three pdflatex passes')
args = parser.parse_args()
for program in ['measure.py', 'validation/verify_both.py']:
    subprocess.run([sys.executable, str(ROOT/program)], cwd=ROOT, check=True)
if args.pdf:
    subprocess.run([sys.executable, str(ROOT/'build.py')], cwd=ROOT, check=True)
print('REPRODUCTION PASSED')
