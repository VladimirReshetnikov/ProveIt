"""Reproduce the pinned whole-program comparison without network access."""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('frozen_measure', ROOT/'comparison/source_measure.py')
measurement = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measurement)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT/'comparison/manifest.json').read_text())
    rows = []
    for item in manifest['programs']:
        path = ROOT/item['local_path']
        value = measurement.metrics(path)
        if value['sha256'] != item['sha256']:
            raise ValueError('Changed comparator: ' + item['label'])
        rows.append(item | value)
    old = {key: min(row[key] for row in rows) for key in KEYS}
    core = {key: min(row['core'][key] for row in rows) for key in KEYS}
    new = measurement.metrics(ROOT/'checker.py')
    fused = measurement.metrics(ROOT/'checker_fused.py')
    assert all(new[key] < old[key] for key in KEYS)
    assert all(new['core'][key] < core[key] for key in KEYS)
    assert all(fused[key] < old[key] for key in KEYS)
    assert all(fused['core'][key] < core[key] for key in KEYS)
    ablation_specs = [
        ('Combined baseline', 'comparison/ablations/combined_closed.py'),
        ('Fusion, explicit environment', 'comparison/ablations/fused_explicit_environment.py'),
        ('Fusion, arguments at check only', 'comparison/ablations/fused_check_arguments.py'),
        ('Opening by arguments (main)', 'checker.py'),
        ('Arguments and fusion', 'checker_fused.py'),
    ]
    ablations = [dict(label=label, local_path=path) | measurement.metrics(ROOT/path)
                 for label, path in ablation_specs]
    result = dict(commit=manifest['commit'], python=platform.python_version(),
                  program_count=len(rows), archive_count=6,
                  coordinatewise_minimum=old, core_coordinatewise_minimum=core,
                  candidate=new, companion=fused, programs=rows, ablations=ablations,
                  whole_program_reduction={key: old[key]-new[key] for key in KEYS},
                  normalized_measurement_source_sha256=hashlib.sha256(
                      (ROOT/'comparison/source_measure.py').read_bytes()).hexdigest())
    (ROOT/'results/metrics.json').write_text(json.dumps(result, indent=2)+'\n')
    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete program & Tokens & AST nodes & Bytes\\', r'\midrule']
    for row in rows:
        name = row['label'].replace('_', r'\_')
        lines.append(name+' & '+' & '.join(str(row[key]) for key in KEYS)+r'\\')
    lines += [r'\midrule', 'Current coordinatewise minimum & '+
              ' & '.join(str(old[key]) for key in KEYS)+r'\\',
              r'\textbf{Delivered checker} & '+
              ' & '.join(r'\textbf{'+str(new[key])+'}' for key in KEYS)+r'\\',
              r'Delivered fused companion & '+
              ' & '.join(str(fused[key]) for key in KEYS)+r'\\',
              r'\bottomrule', r'\end{tabular}']
    (ROOT/'results/comparison_table.tex').write_text('\n'.join(lines)+'\n')
    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete program & Tokens & AST nodes & Bytes\\', r'\midrule']
    for row in ablations:
        lines.append(row['label']+' & '+' & '.join(str(row[key]) for key in KEYS)+r'\\')
    lines += [r'\bottomrule', r'\end{tabular}']
    (ROOT/'results/ablation_table.tex').write_text('\n'.join(lines)+'\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('programs', 'ablations')}, indent=2))


if __name__ == '__main__':
    main()
