OPENING BY ARGUMENTS: A SMALLER iPRA KERNEL
7 November 2026

Start with report.pdf. Its complete LaTeX source is report.tex plus sections/.
The report proves the metatheory and states the limits of the result.

RESULT
The complete main checker is checker.py:
  427 significant normalized tokens / 436 AST nodes / 1,273 normalized bytes.
  Raw file: 1,325 bytes. Core: 368 / 373 / 1,023.
The complete fused companion is checker_fused.py:
  427 significant normalized tokens / 437 AST nodes / 1,277 normalized bytes.
  Raw file: 1,329 bytes. Core: 368 / 374 / 1,027.
The coordinatewise minima among the 13 current root comparators are:
  444 tokens / 457 AST nodes / 1,313 bytes. Core: 381 / 392 / 1,046.

The main reduction passes opening images directly as arguments, removing
repeated environment wrappers. The companion also eliminates redundant
validation traversals, saving 4,020 of 16,895 recursive opening calls (23.794%)
on the 63 accepting case entries. That is a corpus-specific call count.
The ablations separate source-size savings from traversal savings.

The comparison is pinned to ProveIt commit
18e3b9b4071c76fb9e817a2eb50d7b12f7246d18. All six downloaded archives
were checked against their Git blob hashes. The 13 root programs are copied
unchanged under comparison/sources/; measurement verifies their SHA-256 hashes.
Archive byte and Git-blob hashes are in comparison/archive_manifest.json.

This is an incremental implementation improvement. The mathematical six-rule
calculus and two computation schemas are inherited, fully restated, and
attributed. The report supplies full logical reconstruction, quantifier-free
induction, whole-domain ordinary bi-interpretations, and identity composite
isomorphisms. It also proves an almost-unary obstruction to fixed-constant
initializers and a uniform-witness gap in a one-binder proposal.
Global minimality and a new arithmetic axiom basis have not been established.

RUN
  python3 reproduce.py
  python3 checker.py examples/022_universal_reflexivity.json
  python3 checker_fused.py examples/022_universal_reflexivity.json
  python3 reproduce.py --pdf

Python 3.10+ is needed for matching syntax. Metrics were measured on
CPython 3.12.14; use that version for exact normalized figures.
PDF compilation needs pdfLaTeX and the standard packages in report.tex.
build.py can generate a temporary format when a Debian TeX tree lacks one.
The checkers use only Python, json, and sys. Other programs are untrusted
measurement, validation, and build tools; the checkers do not import them.

CERTIFICATE INTERFACE
Each input is a JSON list. Its final cell is a closed goal; preceding cells
are reversed proof instructions. The public checker has no parameter header
and accepts no externally supplied assumption context. Open theorems are
represented by the derived universal closure described in the report.
The checker prints ACCEPT and exits 0, or prints REJECT and exits 1.

An equation is [s,t], closure is [B], existential is [B,C,D] with two
well-formed inert formula matrices. Numerical terms are integer 0, a locally
declared negative parameter, a protected positive bound coordinate, [t] for
successor, and [n,a,h] for the initialized recursor. Tokens 2j-1 and 2j both
name bound coordinate j. The report gives the exact scopes and rule format.
Unread stream prefixes and unused witness annotations are intentionally inert.
Every actual goal and every used substitution image is validated.

VALIDATION
validation/verify.py supplies an explicit-rule oracle with separate term
and formula parsers. validation/verify_both.py audits both delivered files:
  94 fixed-case runs per checker (63 accept, 31 reject).
  188 actual CLI executions in total.
  92 distinct case names; 88 distinct serialized fixed packets.
  1,200 mutation runs per checker; 2,400 candidate mutation comparisons.
  1,013 distinct mutated packets, including 988 absent from the fixed corpus.
All results agree with both the unchanged reference and the oracle.
results/verification.json records individual results, mutation hashes, and
opening call counts. results/metrics.json records the measurements and hashes.
These finite tests do not replace a machine formalization of the metatheory.

CONTENTS
  report.pdf, report.tex, sections/       Complete research report
  checker.py, checker_fused.py           Entire acceptance programs
  examples/                             Small certificate entry points
  comparison/                           Frozen programs, ablations, hashes, metric
  validation/                           Fixtures, reference, independent oracle
  results/                              Measurements, verification, build and QA
  measure.py, reproduce.py, build.py     Offline reproduction tools
  ATTRIBUTION.txt                        Exact source lineage
  SHA256SUMS.txt                         Hashes of delivered files

Finite Python memory, parser, integer-string, and recursion limits can reject
very large otherwise-valid certificates. Completeness and exact equivalence
are mathematical statements with sufficient resources.
No Lean or Rocq verification is included.
