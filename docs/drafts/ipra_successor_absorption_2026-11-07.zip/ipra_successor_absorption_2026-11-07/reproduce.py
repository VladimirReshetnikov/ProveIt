"""Run the offline measurements and executable validation from any directory."""
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    stages = ['comparison/measure.py', 'audit.py',
              'numerical_validation.py', 'native_validation.py']
    for name in stages:
        print('Running ' + name, flush=True)
        subprocess.run([sys.executable, str(ROOT / name)], cwd=ROOT, check=True)
    result = {'status': 'passed', 'python': platform.python_version(), 'stages': stages,
              'metatheory': 'Written proof and audit; no proof-assistant formalization claimed.'}
    (ROOT / 'RESULTS.json').write_text(json.dumps(result, indent=2) + '\n')
    print('All offline reproduction stages passed.')


if __name__ == '__main__':
    main()
