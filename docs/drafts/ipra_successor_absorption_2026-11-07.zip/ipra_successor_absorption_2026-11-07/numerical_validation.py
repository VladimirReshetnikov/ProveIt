"""Independent bounded numerical checks of the untrusted arithmetic compiler.

This evaluator interprets binders with value environments. It never calls
kernel instantiation, proof replay, or the compiler's substitution helpers.
Finite standard-number tests supplement, but cannot replace, the internal
equation proofs in report.tex.
"""
import hashlib
import json
from pathlib import Path
import random

from compiler import compile_term

ROOT = Path(__file__).resolve().parent


class BoundExceeded(Exception):
    pass


def evaluate(term, values=(), free=None, successor_initialized=False, budget=None):
    if budget is None:
        budget = [200000]
    budget[0] -= 1
    if budget[0] < 0:
        raise BoundExceeded('evaluation work bound')
    if type(term) is int:
        if term == 0:
            return 0
        return values[term - 1] if term > 0 else free[term]
    if len(term) == 1:
        return 1 + evaluate(term[0], values, free, successor_initialized, budget)
    counter, initial, update = term
    count = evaluate(counter, values, free, successor_initialized, budget)
    if count > 512:
        raise BoundExceeded('iteration-count bound')
    result = evaluate(initial, values, free, successor_initialized, budget)
    result += int(successor_initialized)
    for index in range(count):
        result = evaluate(update, (result, index) + values, free,
                          successor_initialized, budget)
        if result > 4096:
            raise BoundExceeded('value bound')
    return result


def generate(rng, height, depth=0):
    leaves = [0, -1, -2, *range(1, depth + 1)]
    if height <= 0 or rng.randrange(5) == 0:
        return rng.choice(leaves)
    if rng.randrange(3) == 0:
        return [generate(rng, height - 1, depth)]
    return [generate(rng, height - 1, depth),
            generate(rng, height - 1, depth),
            generate(rng, height - 1, depth + 2)]


def main():
    rng = random.Random(20261107)
    records = []
    attempted = 0
    skipped = 0
    source_terms = [
        [0, -1, 1],                    # arbitrary initializer, never updated
        [[-1], 0, 2],                  # ordinary predecessor at a successor
        [-1, -2, [1]],                 # addition with an arbitrary initial value
        [-1, 0, [1, -2, [1]]],        # nested recursion in an update
        [-1, -2, [[2], 1, 3]],        # reference to an outer accumulator
        [-1, -2, [[1], 2, [3]]],      # outer state beneath new binders
    ]
    source_terms.extend(generate(rng, 4) for _ in range(500))
    for index, term in enumerate(source_terms):
        compiled = compile_term(term)
        digest = hashlib.sha256(json.dumps(term, separators=(',', ':')).encode()).hexdigest()
        for x, y in ((0, 0), (1, 2), (3, 1), (4, 3)):
            attempted += 1
            parameters = {-1: x, -2: y}
            try:
                old = evaluate(term, free=parameters)
                new = evaluate(compiled, free=parameters, successor_initialized=True)
            except BoundExceeded:
                skipped += 1
                continue
            if old != new:
                raise AssertionError((index, term, parameters, old, new))
            records.append({'source_index': index, 'source_sha256': digest,
                            'parameters': [x, y], 'old_value': old, 'new_value': new})
    if len(records) < 1800:
        raise AssertionError('too many bounded cases were skipped')

    decoder_checks = []
    for n in range(21):
        numeral = 0
        for _ in range(n):
            numeral = [numeral]
        p = [numeral, 0, 2]
        pi = compile_term(p)
        actual_decoder = evaluate(p, free={}, successor_initialized=True)
        actual_predecessor = evaluate(pi, free={}, successor_initialized=True)
        expected_decoder = n - 1 if n else 1
        if actual_decoder != expected_decoder or actual_predecessor != max(0, n - 1):
            raise AssertionError((n, actual_decoder, actual_predecessor))
        decoder_checks.append({'n': n, 'decoder': actual_decoder,
                               'truncated_predecessor': actual_predecessor})
    result = {
        'status': 'passed', 'seed': 20261107, 'source_terms': len(source_terms),
        'attempted_comparisons': attempted, 'completed_comparisons': len(records),
        'bounded_cases_skipped': skipped, 'decoder_checks': decoder_checks,
        'records': records,
        'limits': 'Finite standard-number evaluation only; not proof of a metatheorem.'
    }
    (ROOT / 'numerical_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ('records', 'decoder_checks')}, indent=2))


if __name__ == '__main__':
    main()
