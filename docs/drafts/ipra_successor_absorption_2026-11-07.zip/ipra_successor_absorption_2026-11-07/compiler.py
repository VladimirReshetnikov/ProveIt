"""Untrusted proof compiler from ordinary recursion to successor-initialized R+.

All trees in this module use ordinary one-based de Bruijn coordinates. The
separate serializer maps them to paired coordinates and renames parameters.
The compact checker never imports this module or trusts its output.
"""
from copy import deepcopy

from translator import Node, require


def p(term):
    """The partial predecessor, correct on every successor."""
    return [term, 0, 2]


def compile_term(term):
    if type(term) is int:
        return term
    require(type(term) is list, 'invalid source term')
    if len(term) == 1:
        return [compile_term(term[0])]
    require(len(term) == 3, 'invalid source term arity')
    n, initial, update = (compile_term(t) for t in term)
    positive_update = [protect_accumulator(update)]
    return p([n, initial, positive_update])


def protect_accumulator(term, depth=0):
    """Replace the currently bound recursive value u by p(u), preserving binders."""
    if type(term) is int:
        return p(term) if term == depth + 1 else term
    if len(term) == 1:
        return [protect_accumulator(term[0], depth)]
    require(len(term) == 3, 'invalid target term arity')
    return [protect_accumulator(term[0], depth),
            protect_accumulator(term[1], depth),
            protect_accumulator(term[2], depth + 2)]


def compile_formula(formula):
    require(type(formula) is list, 'invalid source formula')
    if len(formula) == 2:
        return [compile_term(t) for t in formula]
    require(len(formula) in (1, 3), 'invalid source formula arity')
    return [compile_formula(a) for a in formula]


def uses_hole(value, sort='formula', depth=0):
    if type(value) is int:
        require(sort == 'term', 'integer in formula sort')
        return value == depth + 1
    require(type(value) is list, 'invalid source syntax')
    if sort == 'term':
        if len(value) == 1:
            return uses_hole(value[0], sort, depth)
        require(len(value) == 3, 'invalid source term arity')
        return (uses_hole(value[0], sort, depth) or uses_hole(value[1], sort, depth)
                or uses_hole(value[2], sort, depth + 2))
    if len(value) == 2:
        return any(uses_hole(t, 'term', depth) for t in value)
    require(len(value) in (1, 3), 'invalid source formula arity')
    return any(uses_hole(a, sort, depth + 1) for a in value)


def opening(value, images, sort='formula', depth=0):
    """Open a raw tree at locally closed numerical images; no kernel helper used."""
    if type(value) is int:
        require(sort == 'term', 'integer in formula sort')
        return deepcopy(images[value - depth - 1]) if value > depth else value
    require(type(value) is list, 'invalid syntax')
    if sort == 'term':
        if len(value) == 1:
            return [opening(value[0], images, sort, depth)]
        require(len(value) == 3, 'invalid term arity')
        return [opening(value[0], images, sort, depth),
                opening(value[1], images, sort, depth),
                opening(value[2], images, sort, depth + 2)]
    if len(value) == 2:
        return [opening(t, images, 'term', depth) for t in value]
    require(len(value) in (1, 3), 'invalid formula arity')
    return [opening(a, images, sort, depth + 1) for a in value]


def computation_rhs(term):
    n, initial, update = term
    if n == 0:
        return [initial]
    require(type(n) is list and len(n) == 1, 'computation counter is not a successor')
    previous = n[0]
    return opening(update, ([previous, initial, update], previous), sort='term')


def axiom(left, right):
    require(computation_rhs(left) == right, 'not a successor-initialized computation')
    return Node([left, right], [], 'compute', accepted=True, consumed=1)


def equality_elimination(major, motive, minor):
    left, right = major.goal
    require(opening(motive, [left]) == minor.goal, 'transport premise does not match')
    goal = opening(motive, [right])
    return Node(goal, [major.goal, motive], 'eq_elim', accepted=True,
                children=[major, minor], consumed=major.consumed + minor.consumed + 1)


def reflexivity(term):
    computation = axiom(p([term]), term)
    return equality_elimination(computation, [1, term], computation)


def symmetry(equation):
    return equality_elimination(equation, [1, equation.goal[0]],
                                reflexivity(equation.goal[0]))


def compile_computation(node):
    """Replace either old recursion axiom by seven primitive R+ proof nodes."""
    goal = compile_formula(node.goal)
    encoded_left, right = goal
    require(encoded_left[1:] == [0, 2], 'translated recursion is not p(C)')
    inner = encoded_left[0]
    inner_step = axiom(inner, [right])
    predecessor_step = axiom(p([right]), right)
    result = equality_elimination(symmetry(inner_step), [p(1), right], predecessor_step)
    require(result.goal == goal, 'compiled recursion computation has the wrong conclusion')
    require(result.consumed == 7, 'unexpected compiled computation proof size')
    return result


def compile_node(node):
    require(node.accepted, 'cannot compile a rejected derivation')
    if node.kind == 'compute':
        return compile_computation(node)
    goal = compile_formula(node.goal)
    children = [compile_node(c) for c in node.children]
    if node.kind in ('hyp', 'q_intro'):
        cell = None if node.kind == 'hyp' else []
    elif node.kind == 'ex_intro':
        witness = compile_term(node.cell[0]) if uses_hole(node.goal[0]) else 0
        cell = [witness]
    elif node.kind in ('eq_elim', 'q_elim', 'ex_elim'):
        major, annotation = node.cell
        if node.kind == 'eq_elim':
            annotation = compile_formula(annotation)
        elif node.kind == 'q_elim':
            annotation = compile_term(annotation) if uses_hole(major[0]) else 0
        else:
            annotation = 0
        cell = [compile_formula(major), annotation]
    else:
        raise ValueError('unrecognized source derivation rule: ' + node.kind)
    return Node(goal, cell, node.kind, accepted=True, children=children, eigen=node.eigen,
                consumed=1 + sum(c.consumed for c in children))
