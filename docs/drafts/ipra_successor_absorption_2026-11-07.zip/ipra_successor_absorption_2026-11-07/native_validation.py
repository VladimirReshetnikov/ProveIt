"""Check the four small native certificates independently and at both CLIs."""
import json
from pathlib import Path
import subprocess
import sys

from audit import oracle_run

ROOT = Path(__file__).resolve().parent


def main():
    rows = []
    cli = []
    examples = sorted((ROOT / 'examples').glob('native_*.json'))
    if len(examples) != 4:
        raise AssertionError('expected the four documented native examples')
    for path in examples:
        certificate = json.loads(path.read_text())
        for closed in (True, False):
            result = oracle_run(certificate, closed=closed)
            if not result['accepted'] or result['remaining']:
                raise AssertionError((path.name, closed, result))
            rows.append({'file': path.name, 'closed': closed, **result})
            for optimized in (False, True):
                command = [sys.executable] + (['-O'] if optimized else [])
                command += [str(ROOT / ('checker.py' if closed else 'checker_open.py')),
                            str(path)]
                run = subprocess.run(command, capture_output=True, text=True, timeout=15)
                if run.returncode != 0 or run.stdout.strip() != 'ACCEPT':
                    raise AssertionError((command, run.returncode, run.stdout, run.stderr))
                cli.append({'file': path.name, 'closed': closed,
                            'optimized': optimized, 'accepted': True})
    result = {'status': 'passed', 'native_certificates': len(examples),
              'audited_replays': len(rows), 'cli_runs': len(cli),
              'records': rows, 'cli': cli}
    (ROOT / 'native_results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('records', 'cli')}, indent=2))


if __name__ == '__main__':
    main()
