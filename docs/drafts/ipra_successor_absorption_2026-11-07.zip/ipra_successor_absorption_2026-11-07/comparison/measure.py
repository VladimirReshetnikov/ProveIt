"""Offline, hash-checked benchmark of the complete R+ acceptance programs."""
from pathlib import Path
import csv
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('frozen_measure', ROOT / 'source_measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def checked(item):
    result = measure.metrics(ROOT / item['local_file'])
    if result['sha256'] != item['sha256']:
        raise ValueError('The frozen comparator has changed: ' + item['local_file'])
    return {**item, **result}


def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    import hashlib
    if hashlib.sha256((ROOT / 'source_measure.py').read_bytes()).hexdigest() != manifest['measurement_source_sha256']:
        raise ValueError('The unchanged measurement program has changed')
    rows = [checked(p) for p in manifest['programs']]
    expanded = [checked(p) for p in manifest['expanded_programs']]
    minimum = {key: min(r[key] for r in rows) for key in KEYS}
    core_minimum = {key: min(r['core'][key] for r in rows) for key in KEYS}
    expanded_minimum = {key: min(r[key] for r in expanded) for key in KEYS}
    if expanded_minimum != minimum:
        raise ValueError('The expanded inventory has a different frontier')
    proposed = measure.metrics(ROOT.parent / 'checker.py')
    companion = measure.metrics(ROOT.parent / 'checker_open.py')
    full_improvement = {key: proposed[key] < minimum[key] for key in KEYS}
    core_improvement = {key: proposed['core'][key] < core_minimum[key] for key in KEYS}
    if not all(full_improvement.values()):
        raise ValueError('The stated complete-program reduction does not reproduce')
    result = {
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'python': platform.python_version(), 'python_implementation': platform.python_implementation(),
        'archive_count': len(manifest['archives']), 'root_programs': len(rows),
        'expanded_paths': manifest['expanded_path_count'], 'expanded_distinct_sources': len(expanded),
        'coordinatewise_minimum': minimum, 'core_coordinatewise_minimum': core_minimum,
        'expanded_coordinatewise_minimum': expanded_minimum,
        'primary_closed_checker': proposed, 'open_companion': companion,
        'strict_complete_program_improvement': full_improvement,
        'strict_core_improvement': core_improvement,
        'scope': 'A finite-corpus complete-program comparison, not an absolute lower bound. The primary checker accepts closed root formulas. The open companion is not below every coordinatewise minimum. After removing CLI/import code, the primary core is smaller in tokens and AST but two normalized bytes larger than the core byte minimum.',
        'programs': rows,
    }
    (ROOT / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (ROOT / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('label', 'interface', *KEYS, 'source_tokens', 'raw_bytes', 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
        writer.writerow({'label': 'R+/checker.py', 'interface': 'closed root', **proposed})
        writer.writerow({'label': 'R+/checker_open.py', 'interface': 'odd free parameters; even generated names', **companion})
    print(json.dumps({k: v for k, v in result.items() if k != 'programs'}, indent=2))


if __name__ == '__main__':
    main()
