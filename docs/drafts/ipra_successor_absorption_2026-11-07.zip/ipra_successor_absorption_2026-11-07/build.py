"""Rebuild report.pdf using ordinary pdfLaTeX; no network access needed."""
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    if shutil.which('pdflatex') is None:
        raise SystemExit('pdfLaTeX is required to rebuild the report.')
    with tempfile.TemporaryDirectory(prefix='ipra-latex-') as tmp:
        command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                   '-file-line-error', '-output-directory=' + tmp, 'report.tex']
        log = ''
        for _ in range(3):
            run = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
            log = run.stdout + run.stderr
            (ROOT / 'build_log.txt').write_text(log)
            if run.returncode:
                print(log[-12000:])
                raise SystemExit(run.returncode)
        final_log = (Path(tmp) / 'report.log').read_text(errors='replace')
        if 'There were undefined references' in final_log:
            raise SystemExit('Unresolved LaTeX references remain; inspect build_log.txt.')
        shutil.copyfile(Path(tmp) / 'report.pdf', ROOT / 'report.pdf')
        (ROOT / 'build_log.txt').write_text(final_log)
        warnings = [line for line in final_log.splitlines()
                    if 'Overfull' in line or 'Underfull' in line or 'Warning' in line]
        print('Compiled report.pdf.')
        for warning in warnings:
            print(warning)


if __name__ == '__main__':
    main()
