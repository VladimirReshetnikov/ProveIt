SUCCESSOR ABSORBED INTO RECURSION
================================
A smaller complete presentation of intuitionistic primitive recursive arithmetic
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date).

START HERE
----------
report.pdf contains the complete article. report.tex and the five included
section TEX files are its editable LaTeX sources.

THE MATHEMATICAL CHANGE
-----------------------
The primitive numerical language has only zero, variables, and A(n,a;u,v.h).
Define sigma(a)=A(0,a;u,v.0). Take:

  A(0,a;h)        = sigma(a)
  A(sigma(n),a;h) = h[A(n,a;h)/u,n/v].

Successor has become a defined term of the recursor. The decoder
p(n)=A(n,0;u,v.v) satisfies p(sigma(x))=x directly. Ordinary initialized
recursion is recovered by

  R*(n,a;u,v.h) = p(A(n,a;u,v.sigma(h[p(u)/u]))).

Its state is stored in successor form. Both ordinary computation equations
follow internally; equation induction proves the reverse identity
A(n,a;h)=R*(n,sigma(a);h). The report gives both ordinary whole-domain
interpretations, composite identity isomorphisms, and equiconsistency with
full first-order intuitionistic PRA with quantifier-free induction.

The decoder p(0) is ONE, not zero. The genuine truncated predecessor is
pi(n)=R*(n,0;u,v.v). The distinction is essential in imported arithmetic.

The logical calculus retains the supplied equality/Q/E basis: six inference
patterns and the two computation schemas are the entire native basis.
The report states every rule and derives full intuitionistic logic,
numerical coverage, and all quantifier-free induction instances.

MEASURED RESULT
---------------
Repository snapshot:
  18e3b9b4071c76fb9e817a2eb50d7b12f7246d18

                                  Tokens    AST nodes    Normalized bytes
  13 supplied root minima           444          457              1313
  checker.py (primary, closed)       439          452              1308
  checker_open.py (companion)        443          459              1317

The primary is below each separate full-program minimum, by five in each
measure. The 183-location / 70-distinct-source expanded inventory has the
same minima. Counts include the complete parser/validator, substitutions,
rules, fresh names, imports, CLI, and rejection handling. Source normalization
uses the unchanged upstream measure under CPython 3.12.14.

The signature reduction and source-size reduction are separate claims.
The checker retains [a] as compact syntax for A(0,a;u,v.0); its parser branch
is counted. No hidden macro compiler is trusted by acceptance.

The main core without imports/CLI is 379 tokens /387 AST /1048 bytes,
compared with inherited core minima 381/392/1046. It improves the two
structural measures but is two bytes above the separate core-byte minimum.
The open companion does not dominate every full-program coordinate.

This is a reproducible improvement over the finite supplied corpus, not a
proof of absolute minimality, a universal lower bound, or historical priority.
The small program-size margin is not described as a major solved open problem.

RUN A CERTIFICATE
-----------------
  python3 checker.py examples/native_successor_definition.json
  python3 checker.py examples/native_reflexivity_zero.json
  python3 checker.py examples/closed_022_universal_reflexivity.json
  python3 checker_open.py examples/open_007_rigid_reflexivity_1.json

Each should print ACCEPT and exit 0. This changed-zero-axiom attack must fail:

  python3 checker.py rejected/old_zero_axiom_is_invalid.json

It should print REJECT and exit 1. FORMAT.txt specifies the complete interface.

REPRODUCE
---------
Before changing generated outputs, verify the delivered manifest:
  python3 package.py --verify

Then run all executable reproduction (offline, standard Python library):
  python3 reproduce.py

Rebuild the PDF (requires pdfLaTeX and its ordinary packages):
  python3 build.py

Regenerate the manifest and ZIP after intentional changes:
  python3 package.py

The kernel needs Python 3.10+; exact AST-unparse counts use CPython 3.12.14.
The concrete process can run out of recursion or memory on very large proofs.

VALIDATION
----------
The main audit passed:
  * 45 inherited public theorem fixtures and 21 internal consequence fixtures;
  * 264 transports through both kernels and both coordinate spellings;
  * 13,188 separately audited primitive inference nodes;
  * 59 hostile documents per kernel and 90 false-root substitutions rejected;
  * 416 normal and optimized (-O) command-line executions.

Numerical validation passed 2,024 comparisons on 506 source terms under four
parameter assignments, with no bounded case skipped. It also checks decoder
and true-predecessor values for 0 through 20. Four native examples are separately
audited and replayed by the reproduction script.

These cohorts overlap and are not added into a count of distinct theorems.
Finite tests do not establish the metatheorems. The article and independent
mathematical_audit.txt give written proofs/review, not Lean/Rocq formalization.

PROOF TRANSLATION BOUNDARIES
--------------------------
The open compiler preserves source external parameters up to an explicit
injective renaming. The closed compiler specializes external parameters to
zero; it does NOT construct universal closures. Already-closed roots keep
their entire translated formulas. Internal open-consequence fixtures use
validated contexts only inside the audit; the public checker has no external
logical-assumption field. General closed-theorem completeness, and use of
derived universal closures for open mathematics, are proved in the report.

CONTENTS
--------
report.pdf, report.tex, section TEX files  Complete article and sources
checker.py, checker_open.py               Entire trusted acceptance programs
FORMAT.txt                               Concrete syntax and instruction contract
compiler.py, translator.py                Untrusted proof compiler and serializer
compiler_notes.txt                       Compilation argument and exact boundaries
audit.py, audit_results.json              Independent typed-tree audit and evidence
numerical_validation.py, numerical_results.json
                                         Separate value-environment checks
native_validation.py, native_results.json Tiny native examples and CLI checks
comparison/                              All frozen baseline sources and measurements
source_checker.py, source_fixtures/       Exact inherited proof source and fixtures
examples/, rejected/                     Emitted public certificates and negative cases
provenance.json, repository_snapshot.json Repository/source identities
mathematical_audit.txt                    Independent written mathematical review
ATTRIBUTION.txt, LICENSE_SOURCE.txt       Research lineage and preserved MIT-0 license
build.py, reproduce.py, package.py        Offline build/reproduction/integrity commands
MANIFEST.sha256                          Payload hashes, excluding the manifest itself

No account credentials, downloaded journal PDFs, temporary PDF renders,
experimental unvalidated kernels, or repository mutations are included.
