"""Verify the payload or rebuild its SHA-256 manifest and deterministic ZIP."""
import argparse
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'MANIFEST.sha256'


def payload():
    return sorted(p for p in ROOT.rglob('*')
                  if p.is_file() and p != MANIFEST
                  and '__pycache__' not in p.parts
                  and p.suffix not in ('.pyc', '.pyo', '.aux', '.toc', '.out', '.log')
                  and not any(part.startswith('.') for part in p.relative_to(ROOT).parts))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    files = payload()
    if args.verify:
        expected = {}
        for line in MANIFEST.read_text().splitlines():
            sha, name = line.split('  ', 1)
            expected[name] = sha
        actual = {p.relative_to(ROOT).as_posix(): digest(p) for p in files}
        if expected != actual:
            differing = sorted(set(expected) ^ set(actual) |
                               {name for name in expected.keys() & actual.keys()
                                if expected[name] != actual[name]})
            raise SystemExit('Manifest mismatch: ' + ', '.join(differing))
        print('Verified ' + str(len(files)) + ' payload files.')
        return
    MANIFEST.write_text(''.join(digest(p) + '  ' + p.relative_to(ROOT).as_posix() + '\n'
                                for p in files))
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in [*files, MANIFEST]:
            info = zipfile.ZipInfo(ROOT.name + '/' + p.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 7, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, p.read_bytes(), compresslevel=9)
    print('Created ' + archive.name + ' (' + str(archive.stat().st_size) + ' bytes).')
    print('SHA-256 ' + digest(archive))


if __name__ == '__main__':
    main()
