PRA WITH TWO VARIABLE NAMES AND STATIONARY EQUATIONS
Research prepared for Vladimir Reshetnikov, 1 November 2026 (Pacific time)

MAIN DELIVERABLE

  report.pdf             Complete mathematical report.
  report.tex             Main LaTeX source.
  sections/*.tex         Arithmetic, pairing, and interpretation proofs.

RESULT

The current supplied drafts already have a 15-node outer propagation
schema. This package simplifies its stationary matrix from an implication
between two universally quantified equations to one universally quantified
equation. A zero-or-one local contraction must turn that equation into
universal reflexivity. The dynamic branch retains atomic implications.

The stationary quantified binder can reuse the outer induction-variable
name, because no occurrence of that variable is free in that branch.
Every emitted axiom therefore uses only the two individual names n,a.

The outer count remains 15. Under the source reports' explicitly partial
term-placeholder ledger, the stationary matrix shrinks 17 -> 8, and its
three occurrences plus the outer axiom syntax shrink 56 -> 29. The gate
acquires an additional reflexive-equality endpoint pattern. The report
does not claim an encoding-independent minimum or shortest complete code.

The function language uses 0,S, a fixed binary counter-projection recursor,
and iterators with unary stored state updates. The classical theory uses
two matrix families. The intuitionistic theory also admits one fixed
constructor-coverage matrix. Each has a common conservative definitional
extension with first-order PRA in the matching logic. The interpretations
preserve the whole carrier and native equality, and both composites are
internally the identity. The report contains all arithmetic calibration
and round-trip proofs, crediting the inherited constructions.

VERIFICATION ARTIFACTS

  artifacts/check_schema.py     Standard-library finite syntax checker.
  artifacts/schema_results.json Named checks, generated probes, sample axioms.
  formal/ReflexiveStationary.lean
                               New constructive semantic logical kernel.
  formal/Propagation.lean       Credited, unmodified finite-syntax support.
  formal/*.log                 Successful Lean 4.19.0 compiler output.
  formal/lean_verification.json Compiler, scope, and source hashes.
  formal/provenance.json        Exact origin of copied/adapted support.
  provenance/source_manifest.json
                               Seven pinned source archives and source hashes.

The Lean theorem checks Schema15 iff Base and Step and Separation and QFI1
for a full-quantifier-free dynamic branch. It does NOT formalize the full
arithmetic compiler, bi-interpretations, narrower atomic grammar bridge,
or the named-binder theorem. Those are written proofs. The Python checker
audits syntax and examples, not mathematical truth or conservativity.

REBUILD

  python3 build.py

This reruns the syntax checker and builds report.pdf with pdflatex.
The Python code needs Python 3.10+ and only the standard library.
The PDF needs standard LaTeX packages listed in report.tex.

To check the Lean kernel as well:

  python3 build.py --lean /absolute/path/to/lean

Use Lean 4.19.0; no Mathlib is needed. To run only syntax and Lean:

  python3 build.py --skip-pdf --lean /absolute/path/to/lean

All intermediate .olean, .aux, and .toc files are made in temporary
directories. Verification logs and JSON receipts are retained.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit:     0e1088217e60a865ee39f86a5563cadbbbc5875f
Directory:  docs/drafts

All seven current archives were inspected. They are not duplicated inside
this package. The provenance manifest contains their immutable URLs,
Git blob identities, SHA-256 digests, and relevant source-member hashes.
Novelty claims are relative to those inspected drafts, not literature-wide
priority claims. The report keeps the two unproved directions explicit:
pure quantifier-free 15-node successor extraction, and internal removal
of the last counter projection.
