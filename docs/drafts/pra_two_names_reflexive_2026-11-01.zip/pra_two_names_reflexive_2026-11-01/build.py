#!/usr/bin/env python3
"""Rebuild the syntax audit, optional Lean kernel, and LaTeX report.

Python 3.10+; standard library only. PDF creation needs pdflatex.
The optional Lean check uses core Lean 4.19.0 and does not need Mathlib.
Intermediate LaTeX and Lean files are kept in temporary directories.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent


def run(command: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        check=False, **kwargs,
    )
    if result.returncode:
        raise RuntimeError(
            f"Command failed ({result.returncode}): {command[0]}\n{result.stdout}"
        )
    return result


def check_lean(executable: str) -> dict[str, object]:
    lean = shutil.which(executable) or executable
    version = run([lean, "--version"]).stdout.strip()
    records = []
    with tempfile.TemporaryDirectory(prefix="pra-reflexive-lean-") as folder:
        destination = Path(folder)
        environment = dict(os.environ)
        environment["LEAN_PATH"] = str(destination)
        for name in ("Propagation", "ReflexiveStationary"):
            source = ROOT / "formal" / f"{name}.lean"
            shutil.copy2(source, destination / source.name)
            result = run(
                [lean, "-o", str(destination / f"{name}.olean"), source.name],
                cwd=destination, env=environment,
            )
            (ROOT / "formal" / f"{name}.log").write_text(result.stdout)
            if "sorryAx" in result.stdout:
                raise RuntimeError("The Lean dependency report contains sorryAx.")
            records.append({
                "source": source.name,
                "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                "returncode": result.returncode,
                "log": f"{name}.log",
            })
    receipt = {
        "compiler": str(lean), "version": version, "success": True,
        "scope": "Full-QF semantic logical kernel only; see source headers.",
        "runs": records,
    }
    (ROOT / "formal" / "lean_rebuild.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
    return receipt


def build_pdf() -> dict[str, object]:
    executable = shutil.which("pdflatex")
    if executable is None:
        raise RuntimeError("pdflatex was not found. Install a LaTeX distribution.")
    with tempfile.TemporaryDirectory(prefix="pra-reflexive-tex-") as folder:
        directory = Path(folder)
        for _ in range(3):
            run([
                executable, "-interaction=nonstopmode", "-halt-on-error",
                f"-output-directory={directory}", "report.tex",
            ], cwd=ROOT)
        log = (directory / "report.log").read_text(errors="replace")
        (ROOT / "artifacts" / "latex_build.log").write_text(log)
        if "There were undefined references" in log:
            raise RuntimeError("The final LaTeX build has undefined references.")
        shutil.copy2(directory / "report.pdf", ROOT / "report.pdf")
    return {
        "pdf": "report.pdf",
        "sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
        "overfull_hboxes": log.count("Overfull \\hbox"),
        "overfull_vboxes": log.count("Overfull \\vbox"),
        "undefined_references": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Optional Lean executable to run")
    parser.add_argument("--skip-pdf", action="store_true")
    args = parser.parse_args()
    syntax = run([sys.executable, str(ROOT / "artifacts" / "check_schema.py")])
    print(syntax.stdout.strip())
    receipt: dict[str, object] = {"syntax": "passed"}
    if args.lean:
        receipt["lean"] = check_lean(args.lean)
        print("Lean logical kernel: passed")
    if not args.skip_pdf:
        receipt["latex"] = build_pdf()
        print("PDF created: report.pdf")
    (ROOT / "artifacts" / "build_receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
