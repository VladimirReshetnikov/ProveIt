#!/usr/bin/env python3
"""Finite-syntax audit of the two-name, reflexive-base PRA presentation.

This is a syntax checker and a collection of reproducible syntax tests.
It is NOT a logical proof kernel, model checker, proof of conservativity,
or end-to-end formalization of the interpretation theorem.

Run with Python 3.10+ and the standard library only:
    python3 check_schema.py

The default output is schema_results.json beside this script.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Mapping


@dataclass(frozen=True)
class Term:
    kind: str
    name: str = ""
    args: tuple["Term", ...] = ()


@dataclass(frozen=True)
class Formula:
    kind: str
    terms: tuple[Term, ...] = ()
    children: tuple["Formula", ...] = ()
    binder: str = ""
    name: str = ""


@dataclass(frozen=True)
class Description:
    name: str
    body: Term
    stage: int


@dataclass(frozen=True)
class Rewrite:
    rule: str
    path: tuple[str, ...]
    result: Term | Formula


class CaptureError(ValueError):
    """A requested substitution would capture a free variable."""


def V(name: str) -> Term:
    return Term("var", name)


ZERO = Term("zero")
N, A, U, W = V("n"), V("a"), V("u"), V("v")


def S(t: Term) -> Term:
    return Term("succ", args=(t,))


def R(name: str, counter: Term, seed: Term) -> Term:
    return Term("rec", name, (counter, seed))


def Eq(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


BOTTOM = Formula("bottom")


def Imp(left: Formula, right: Formula) -> Formula:
    return Formula("imp", children=(left, right))


def Or(left: Formula, right: Formula) -> Formula:
    return Formula("or", children=(left, right))


def All(variable: str, body: Formula) -> Formula:
    return Formula("forall", children=(body,), binder=variable)


def term_fv(term: Term) -> frozenset[str]:
    if term.kind == "var":
        return frozenset((term.name,))
    return frozenset().union(*(term_fv(t) for t in term.args))


def free_vars(formula: Formula) -> frozenset[str]:
    result = frozenset().union(
        *(term_fv(t) for t in formula.terms),
        *(free_vars(f) for f in formula.children),
    )
    if formula.kind == "forall":
        return result - {formula.binder}
    return result


def variable_names(formula: Formula) -> frozenset[str]:
    """Names in active syntax, including binders, excluding symbol metadata."""
    result = frozenset().union(
        *(term_fv(t) for t in formula.terms),
        *(variable_names(f) for f in formula.children),
    )
    if formula.kind == "forall":
        result |= {formula.binder}
    return result


def term_substitute(term: Term, replacements: Mapping[str, Term]) -> Term:
    """Simultaneous substitution; inserted terms are NOT substituted again.

    A recursor's stored description is not an active subtree of the term.
    Consequently substitution changes its arguments, never its symbol name
    or the update body associated with that name.
    """
    if term.kind == "var":
        return replacements.get(term.name, term)
    return Term(
        term.kind,
        term.name,
        tuple(term_substitute(t, replacements) for t in term.args),
    )


def substitute(formula: Formula, replacements: Mapping[str, Term]) -> Formula:
    """Capture-avoiding substitution, rejecting a request needing fresh names.

    All substitutions used by the emitted schema are safe without renaming:
    they replace free n by 0 or S(n).  Under an inner forall n they stop.
    Rejecting other capture-producing requests makes the two-name discipline
    explicit; this routine does not silently introduce a third variable.
    """
    active = dict(replacements)
    if formula.kind == "forall":
        active.pop(formula.binder, None)
        body_fv = free_vars(formula.children[0])
        for key, value in active.items():
            if key in body_fv and formula.binder in term_fv(value):
                raise CaptureError(
                    f"substitution for {key} would be captured by "
                    f"forall {formula.binder}"
                )
    return Formula(
        formula.kind,
        tuple(term_substitute(t, active) for t in formula.terms),
        tuple(substitute(f, active) for f in formula.children),
        formula.binder,
        formula.name,
    )


class Registry:
    """Finite, dependency-ordered prefix of the effective description language."""

    def __init__(self, restricted: bool = False) -> None:
        self.restricted = restricted
        self.descriptions: dict[str, Description] = {}

    def add(self, name: str, body: Term) -> None:
        if name in self.descriptions:
            raise ValueError("duplicate description name")
        # The new symbol has not yet been added: references to it or to any
        # later/unrecognized description are rejected by this validation.
        self.validate_term(body, frozenset(("u", "v")))
        if self.restricted:
            if not self.descriptions and body != U:
                raise ValueError("the distinguished counter projection must be first")
            if body == U and any(d.body == U for d in self.descriptions.values()):
                raise ValueError("only one distinguished counter projection is allowed")
            if body != U and not term_fv(body) <= {"v"}:
                raise ValueError("all updates after the counter projection must be unary")
        self.descriptions[name] = Description(name, body, len(self.descriptions))

    def validate_term(self, term: Term, allowed: frozenset[str]) -> None:
        if term.kind == "var":
            if term.name not in allowed or term.args:
                raise ValueError("illegal variable or malformed variable term")
        elif term.kind == "zero":
            if term.name or term.args:
                raise ValueError("malformed zero")
        elif term.kind == "succ":
            if term.name or len(term.args) != 1:
                raise ValueError("malformed successor")
        elif term.kind == "rec":
            if term.name not in self.descriptions or len(term.args) != 2:
                raise ValueError("unknown description or nonbinary recursor")
        else:
            raise ValueError("unknown term constructor")
        for child in term.args:
            self.validate_term(child, allowed)

    def validate_formula(self, formula: Formula) -> None:
        shapes = {
            "eq": (2, 0),
            "bottom": (0, 0),
            "imp": (0, 2),
            "or": (0, 2),
            "forall": (0, 1),
        }
        if formula.kind not in shapes:
            raise ValueError("unknown formula constructor")
        if (len(formula.terms), len(formula.children)) != shapes[formula.kind]:
            raise ValueError("malformed formula")
        if formula.name:
            raise ValueError("unexpected formula metadata")
        if formula.kind == "forall":
            if formula.binder not in {"n", "a"}:
                raise ValueError("only n and a are active variable names")
        elif formula.binder:
            raise ValueError("unexpected binder")
        for term in formula.terms:
            self.validate_term(term, frozenset(("n", "a")))
        for child in formula.children:
            self.validate_formula(child)

    def instantiate(self, name: str, counter: Term, state: Term) -> Term:
        return term_substitute(
            self.descriptions[name].body, {"u": counter, "v": state}
        )

    def fingerprint(self) -> str:
        data = [
            {"name": d.name, "stage": d.stage, "body": show_term(d.body)}
            for d in self.descriptions.values()
        ]
        raw = json.dumps(data, sort_keys=True).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()


def make_registry(restricted: bool = False) -> Registry:
    reg = Registry(restricted)
    reg.add("counter", U)
    reg.add("identity", W)
    reg.add("zero", ZERO)
    reg.add("successor", S(W))
    reg.add("erased", R("zero", ZERO, W))
    if not restricted:
        reg.add("mixed", R("successor", U, W))
    return reg


def coverage() -> Formula:
    def c(t: Term) -> Formula:
        predecessor = R("counter", t, ZERO)
        return Or(Eq(t, ZERO), Eq(t, S(predecessor)))

    return Imp(c(ZERO), c(N))


def is_atom(formula: Formula) -> bool:
    return formula.kind in {"eq", "bottom"}


def matrix_kind(
    formula: Formula, registry: Registry, intuitionistic: bool = False
) -> str | None:
    try:
        registry.validate_formula(formula)
    except ValueError:
        return None
    if not free_vars(formula) <= {"n", "a"}:
        return None
    if formula.kind == "imp" and all(is_atom(f) for f in formula.children):
        return "ordinary"
    if (
        formula.kind == "forall"
        and formula.binder == "n"
        and formula.children[0].kind == "eq"
        and free_vars(formula) <= {"a"}
    ):
        return "stationary_equation"
    if intuitionistic and formula == coverage():
        return "fixed_coverage"
    return None


def one_term_rewrites(term: Term, registry: Registry) -> Iterable[Rewrite]:
    if term.kind == "rec":
        counter, seed = term.args
        if counter == ZERO:
            yield Rewrite("Z", (), seed)
        elif counter.kind == "succ":
            previous = counter.args[0]
            result = registry.instantiate(
                term.name, previous, R(term.name, previous, seed)
            )
            yield Rewrite("RS", (), result)
    for index, child in enumerate(term.args):
        for rewrite in one_term_rewrites(child, registry):
            assert isinstance(rewrite.result, Term)
            changed = list(term.args)
            changed[index] = rewrite.result
            yield Rewrite(
                rewrite.rule,
                (f"arg[{index}]",) + rewrite.path,
                Term(term.kind, term.name, tuple(changed)),
            )


def one_rewrites(formula: Formula, registry: Registry) -> Iterable[Rewrite]:
    if formula == Eq(ZERO, S(ZERO)):
        yield Rewrite("Sep", (), BOTTOM)
    for index, term in enumerate(formula.terms):
        for rewrite in one_term_rewrites(term, registry):
            assert isinstance(rewrite.result, Term)
            terms = list(formula.terms)
            terms[index] = rewrite.result
            yield Rewrite(
                rewrite.rule,
                (f"term[{index}]",) + rewrite.path,
                Formula(
                    formula.kind,
                    tuple(terms),
                    formula.children,
                    formula.binder,
                    formula.name,
                ),
            )
    for index, child in enumerate(formula.children):
        for rewrite in one_rewrites(child, registry):
            assert isinstance(rewrite.result, Formula)
            children = list(formula.children)
            children[index] = rewrite.result
            yield Rewrite(
                rewrite.rule,
                (f"child[{index}]",) + rewrite.path,
                Formula(
                    formula.kind,
                    formula.terms,
                    tuple(children),
                    formula.binder,
                    formula.name,
                ),
            )


def is_target(formula: Formula) -> bool:
    if formula.kind == "imp":
        return formula.children[0] == formula.children[1]
    if formula.kind == "forall" and formula.binder == "n":
        inner = formula.children[0]
        return inner.kind == "eq" and inner.terms[0] == inner.terms[1]
    return False


def admission(
    formula: Formula, registry: Registry, intuitionistic: bool = False
) -> dict[str, object] | None:
    kind = matrix_kind(formula, registry, intuitionistic)
    if kind is None:
        return None
    base = substitute(formula, {"n": ZERO})
    if is_target(base):
        return {"kind": kind, "contractions": 0, "rule": None, "path": []}
    for rewrite in one_rewrites(base, registry):
        assert isinstance(rewrite.result, Formula)
        if is_target(rewrite.result):
            return {
                "kind": kind,
                "contractions": 1,
                "rule": rewrite.rule,
                "path": list(rewrite.path),
            }
    return None


def emit_axiom(formula: Formula) -> Formula:
    step = substitute(formula, {"n": S(N)})
    return All("a", Imp(All("n", Imp(formula, step)), All("n", formula)))


def show_term(term: Term) -> str:
    if term.kind == "var":
        return term.name
    if term.kind == "zero":
        return "0"
    if term.kind == "succ":
        return f"S({show_term(term.args[0])})"
    args = ",".join(show_term(t) for t in term.args)
    if term.kind == "rec":
        return f"R_{term.name}({args})"
    return f"{term.name}({args})"


def show_formula(formula: Formula) -> str:
    if formula.kind == "eq":
        return f"({show_term(formula.terms[0])}={show_term(formula.terms[1])})"
    if formula.kind == "bottom":
        return "bottom"
    if formula.kind == "forall":
        return f"(forall {formula.binder} {show_formula(formula.children[0])})"
    if formula.kind == "pred":
        return f"{formula.name}({','.join(show_term(t) for t in formula.terms)})"
    operator = {"imp": "->", "or": "or"}[formula.kind]
    return (
        f"({show_formula(formula.children[0])} {operator} "
        f"{show_formula(formula.children[1])})"
    )


def term_nodes(term: Term) -> int:
    return 1 + sum(term_nodes(t) for t in term.args)


def formula_nodes(formula: Formula) -> int:
    return (
        1
        + sum(term_nodes(t) for t in formula.terms)
        + sum(formula_nodes(f) for f in formula.children)
    )


def accounting() -> dict[str, object]:
    # Predicates and opaque term symbols below belong ONLY to the display
    # ledger. They are not accepted by the object-language syntax checker.
    placeholder = Formula("pred", (N, A), name="F")
    outer = emit_axiom(placeholder)
    terms = [Term("opaque", label, (A, N)) for label in ("s", "t", "u", "v")]
    old_matrix = Imp(All("n", Eq(terms[0], terms[1])), All("n", Eq(terms[2], terms[3])))
    new_matrix = All("n", Eq(terms[0], terms[1]))
    return {
        "outer_placeholder_nodes": formula_nodes(outer),
        "outer_ledger": {
            "F(n,a)": 3,
            "F(S(n),a)": 4,
            "conclusion_F(n,a)": 3,
            "quantifiers": 3,
            "implications": 2,
        },
        "old_stationary_matrix_nodes": formula_nodes(old_matrix),
        "new_stationary_matrix_nodes": formula_nodes(new_matrix),
        "old_expanded_stationary_term_placeholder_nodes": formula_nodes(emit_axiom(old_matrix)),
        "new_expanded_stationary_term_placeholder_nodes": formula_nodes(emit_axiom(new_matrix)),
        "convention": (
            "One node per term/formula constructor, individual quantifier, "
            "or variable occurrence; binder names are labels. The outer "
            "count excludes substituted matrix bodies. The stationary "
            "comparison charges each binary term placeholder as a function "
            "node with its two actual variable arguments. Neither metric "
            "counts the complete axiom generator or update-description bodies."
        ),
    }


def run_audit() -> dict[str, object]:
    registry = make_registry()
    restricted = make_registry(True)
    checks: list[dict[str, object]] = []
    examples: list[dict[str, object]] = []

    def check(name: str, condition: bool, detail: object = None) -> None:
        if not condition:
            raise AssertionError(name)
        item: dict[str, object] = {"name": name, "passed": True}
        if detail is not None:
            item["detail"] = detail
        checks.append(item)

    def rejects(name: str, action: Callable[[], object], error: type[Exception] = ValueError) -> None:
        try:
            action()
        except error:
            check(name, True)
        else:
            raise AssertionError(f"{name}: expected {error.__name__}")

    def accepted(name: str, formula: Formula, intuitionistic: bool = False) -> dict[str, object]:
        witness = admission(formula, registry, intuitionistic)
        check(name, witness is not None)
        axiom = emit_axiom(formula)
        registry.validate_formula(axiom)
        check(name + ": emitted axiom is closed and has only n,a", not free_vars(axiom) and variable_names(axiom) <= {"n", "a"})
        examples.append({
            "name": name,
            "matrix": show_formula(formula),
            "zero_instance": show_formula(substitute(formula, {"n": ZERO})),
            "witness": witness,
            "expanded_axiom": show_formula(axiom),
            "active_variable_names": sorted(variable_names(axiom)),
            "free_variables": sorted(free_vars(axiom)),
        })
        assert witness is not None
        return witness

    check("full registry has one genuinely mixed update", term_fv(registry.descriptions["mixed"].body) == {"u", "v"})
    check("restricted registry contains only unary updates and counter projection", all(d.body == U or term_fv(d.body) <= {"v"} for d in restricted.descriptions.values()))
    rejects("self-reference is rejected", lambda: registry.add("self", R("self", U, W)))
    rejects("forward reference is rejected", lambda: registry.add("forward", R("future", U, W)))
    rejects("extra update variable is rejected", lambda: registry.add("extra", V("a")))
    rejects("mixed update is rejected by restricted grammar", lambda: restricted.add("mixed", R("successor", U, W)))
    rejects("counter-dependent nonprojection update is rejected", lambda: restricted.add("bad_counter", S(U)))
    rejects("second counter projection is rejected", lambda: restricted.add("second_counter", U))
    rejects("unary update before distinguished counter is rejected", lambda: Registry(True).add("premature_identity", W))
    rejects("duplicate description is rejected", lambda: registry.add("identity", W))

    zero_probe = All("n", Eq(R("identity", ZERO, N), N))
    check("stationary zero probe retains its bound n", substitute(zero_probe, {"n": ZERO}) == zero_probe)
    check("stationary successor substitution is inert", substitute(zero_probe, {"n": S(N)}) == zero_probe)
    z_witness = accepted("direct stationary initialization probe", zero_probe)
    check("initialization uses exactly one Z contraction", z_witness["rule"] == "Z" and z_witness["contractions"] == 1)

    rhs = registry.instantiate("mixed", A, R("mixed", A, N))
    step_probe = All("n", Eq(R("mixed", S(A), N), rhs))
    rs_witness = accepted("direct stationary binary successor probe", step_probe)
    check("successor probe uses exactly one RS contraction", rs_witness["rule"] == "RS" and rs_witness["contractions"] == 1)
    check("stationary binary successor probe has only a free", free_vars(step_probe) == {"a"})
    check("two nested binder levels still use only n,a", variable_names(emit_axiom(step_probe)) == {"n", "a"})

    sep = Imp(Eq(ZERO, S(ZERO)), BOTTOM)
    sep_witness = accepted("separation probe", sep)
    check("separation uses exactly one Sep contraction", sep_witness["rule"] == "Sep" and sep_witness["contractions"] == 1)
    check("reversed separation is not silently admitted", admission(Imp(Eq(S(ZERO), ZERO), BOTTOM), registry) is None)

    equation = Eq(R("identity", N, A), S(N))
    normalized = Imp(substitute(equation, {"n": ZERO}), equation)
    eq_witness = accepted("generic equation-induction probe", normalized)
    check("equation induction uses zero contractions", eq_witness["contractions"] == 0)
    check("free n is replaced while a is retained", substitute(Eq(N, A), {"n": ZERO}) == Eq(ZERO, A))
    check("free n successor substitution is simultaneous", substitute(Eq(N, A), {"n": S(N)}) == Eq(S(N), A))

    cov = coverage()
    cov_witness = accepted("fixed intuitionistic coverage matrix", cov, True)
    check("coverage needs zero contractions", cov_witness["contractions"] == 0)
    check("coverage is excluded from lean classical grammar", admission(cov, registry, False) is None)
    check("other disjunctive matrices are not admitted by exception", admission(Imp(Or(Eq(N, ZERO), Eq(A, ZERO)), Or(Eq(N, ZERO), Eq(A, ZERO))), registry, True) is None)

    # Stationary formulas now consist of ONE universally quantified equation,
    # not an implication of two universally quantified equations.
    old_stationary = Imp(All("n", Eq(A, N)), All("n", Eq(A, N)))
    check("old implication-of-quantified-atoms grammar is excluded", admission(old_stationary, registry) is None)
    dependent_quantified = Imp(All("n", Eq(A, N)), Eq(N, A))
    check("quantified n-dependent matrix is excluded", admission(dependent_quantified, registry) is None)
    check("wrong stationary binder is excluded", admission(All("a", Eq(N, N)), registry) is None)
    check("quantified non-equation body is excluded", admission(All("n", Imp(Eq(N, N), Eq(N, N))), registry) is None)
    check("third active variable is excluded", admission(All("n", Eq(V("b"), V("b"))), registry) is None)
    check("third bound variable is excluded rather than alpha-normalized", admission(All("b", Eq(V("b"), V("b"))), registry) is None)
    check("unknown recursor symbol is excluded", admission(All("n", Eq(R("unknown", ZERO, N), N)), registry) is None)

    double = Imp(Eq(R("identity", ZERO, A), R("identity", ZERO, A)), Eq(A, A))
    check("two necessary contractions are rejected", admission(double, registry) is None)
    check("double-contraction example has no one-step target", all(not is_target(r.result) for r in one_rewrites(substitute(double, {"n": ZERO}), registry) if isinstance(r.result, Formula)))
    check("double-contraction example really has a two-step target", any(is_target(second.result) for first in one_rewrites(substitute(double, {"n": ZERO}), registry) if isinstance(first.result, Formula) for second in one_rewrites(first.result, registry) if isinstance(second.result, Formula)))

    nested = Imp(Eq(R("identity", ZERO, R("identity", ZERO, A)), A), Eq(A, A))
    check("nested normalization is not silently iterated", admission(nested, registry) is None)
    root_term = R("erased", S(N), A)
    root_rewrite = next(r for r in one_term_rewrites(root_term, registry) if r.path == ())
    check("newly inserted update body is not reduced", root_rewrite.result == R("zero", ZERO, R("erased", N, A)))

    captured = All("n", Eq(A, N))
    rejects("capture-producing substitution is rejected", lambda: substitute(captured, {"a": N}), CaptureError)
    check("irrelevant substitution does not trigger false capture rejection", substitute(All("n", Eq(N, N)), {"a": N}) == All("n", Eq(N, N)))
    check("substitution stops at a shadowing n binder", substitute(All("n", Eq(A, N)), {"n": S(N)}) == All("n", Eq(A, N)))
    check("simultaneous update substitution does not recurse into inserted variables", term_substitute(R("identity", U, W), {"u": W, "v": U}) == R("identity", W, U))

    before = registry.fingerprint()
    changed = term_substitute(R("mixed", N, A), {"n": ZERO, "a": S(A)})
    check("application substitution changes only active arguments", changed == R("mixed", ZERO, S(A)))
    list(one_term_rewrites(R("mixed", S(N), A), registry))
    check("stored description bodies remain immutable", registry.fingerprint() == before)

    generated: dict[str, int] = {}
    seed_terms = (ZERO, N, A, S(N), S(A), R("identity", N, A))
    for label, reg in (("full_binary", registry), ("unary_plus_counter", restricted)):
        zero_count = 0
        successor_count = 0
        for name in reg.descriptions:
            for seed in seed_terms:
                matrix = All("n", Eq(R(name, ZERO, seed), seed))
                assert admission(matrix, reg) is not None
                axiom = emit_axiom(matrix)
                assert not free_vars(axiom) and variable_names(axiom) <= {"n", "a"}
                zero_count += 1
            for counter in seed_terms:
                for seed in seed_terms:
                    rhs = reg.instantiate(name, counter, R(name, counter, seed))
                    matrix = All("n", Eq(R(name, S(counter), seed), rhs))
                    assert admission(matrix, reg) is not None
                    axiom = emit_axiom(matrix)
                    assert not free_vars(axiom) and variable_names(axiom) <= {"n", "a"}
                    successor_count += 1
        generated[label + "_initialization_probes"] = zero_count
        generated[label + "_successor_probes"] = successor_count
        check(label + ": all generated direct computation probes pass", True, {"initialization": zero_count, "successor": successor_count})

    ledger = accounting()
    check("outer display has 15 nodes", ledger["outer_placeholder_nodes"] == 15)
    check("old stationary term-placeholder display has 56 nodes", ledger["old_expanded_stationary_term_placeholder_nodes"] == 56)
    check("direct stationary term-placeholder display has 29 nodes", ledger["new_expanded_stationary_term_placeholder_nodes"] == 29)

    return {
        "audit": "two-name reflexive-base PRA schema",
        "status": "passed",
        "scope": (
            "Finite-syntax checks only. This executable verifies concrete "
            "admissions, rejected near misses, hygienic substitution, staged "
            "descriptions, the one-contraction budget, two-name emitted "
            "axioms, and the stated partial display counts. It is not a "
            "logical proof kernel and does not independently certify "
            "the arithmetic compiler, bi-interpretability, or minimality."
        ),
        "checks_passed": len(checks),
        "checks": checks,
        "generated_probe_instances": generated,
        "generated_probe_total": sum(generated.values()),
        "examples": examples,
        "node_accounting": ledger,
        "full_description_prefix_fingerprint": registry.fingerprint(),
        "restricted_description_prefix_fingerprint": restricted.fingerprint(),
        "description_prefixes": {
            "full_binary": [
                {"name": d.name, "stage": d.stage, "body": show_term(d.body)}
                for d in registry.descriptions.values()
            ],
            "unary_plus_counter": [
                {"name": d.name, "stage": d.stage, "body": show_term(d.body)}
                for d in restricted.descriptions.values()
            ],
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_name("schema_results.json"),
        help="JSON output path (default: alongside this script)",
    )
    args = parser.parse_args()
    result = run_audit()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(
        f"PASS: {result['checks_passed']} named checks; "
        f"{result['generated_probe_total']} generated computation probes. "
        "Outer count 15; stationary comparison 56 -> 29."
    )
    print(f"Results: {args.output.resolve()}")


if __name__ == "__main__":
    main()
