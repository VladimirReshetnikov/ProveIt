"""Reproduce complete trusted-source counts; not part of either checker."""

import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize


HERE = Path(__file__).resolve().parent
IGNORED = {
    tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE, tokenize.NL,
    tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT,
}


def main():
    metrics = {}
    for filename in ("shared.py", "check.py", "baseline.py"):
        raw = (HERE / filename).read_bytes()
        source = raw.decode("utf-8")
        metrics[filename] = {
            "utf8_bytes": len(raw),
            "physical_lines": len(source.splitlines()),
            "nonblank_noncomment_lines": sum(
                bool(line.strip()) and not line.lstrip().startswith("#")
                for line in source.splitlines()
            ),
            "lexical_tokens": sum(
                token.type not in IGNORED
                for token in tokenize.generate_tokens(io.StringIO(source).readline)
            ),
            "python_ast_nodes": sum(1 for _ in ast.walk(ast.parse(source))),
        }
    for label, module in (("candidate", "check.py"), ("baseline", "baseline.py")):
        metrics[label] = {
            key: metrics["shared.py"][key] + metrics[module][key]
            for key in metrics["shared.py"]
        }
    output = {
        "trusted_files": {
            "candidate": ["shared.py", "check.py"],
            "baseline": ["shared.py", "baseline.py"],
        },
        "sha256": {
            name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
            for name in ("shared.py", "check.py", "baseline.py")
        },
        "metrics": metrics,
        "reduction_percent": {
            key: 100 * (1 - metrics["candidate"][key] / metrics["baseline"][key])
            for key in metrics["candidate"]
        },
        "scope": (
            "Complete supplied trusted Python files, including validation and CLI. "
            "Both kernels use identical native recursion and shared infrastructure. "
            "Python, json and sys are common runtime dependencies. "
            "Documentation, tests, certificates and this measurement script are excluded. "
            "Docstring tokens are counted; comments and whitespace tokens are excluded. "
            "No claim of an encoding-independent minimum."
        ),
    }
    (HERE / "measurement.json").write_text(json.dumps(output, indent=2) + "\n")
    rows = []
    labels = {
        "utf8_bytes": "UTF-8 source bytes",
        "physical_lines": "Physical source lines",
        "nonblank_noncomment_lines": "Nonblank, noncomment lines",
        "lexical_tokens": "Python lexical tokens",
        "python_ast_nodes": "Python AST nodes",
    }
    for key, label in labels.items():
        rows.append(
            f"{label} & {metrics['baseline'][key]:,} & "
            f"{metrics['candidate'][key]:,} & "
            f"{output['reduction_percent'][key]:.1f}\\% " + r"\\"
        )
    latex = "\n".join([
        r"The complete candidate is \texttt{shared.py} plus \texttt{check.py};",
        r"the baseline is \texttt{shared.py} plus \texttt{baseline.py}.",
        r"The files are counted in full, including validation and JSON input handling.",
        r"\begin{center}\small",
        r"\begin{tabular}{@{}lrrr@{}}\toprule",
        r"Metric & Draft core & Candidate & Reduction\\\midrule",
        *rows,
        r"\bottomrule\end{tabular}",
        r"\end{center}",
        r"These numbers are generated directly from the supplied files by",
        r"\texttt{code/measure.py}. Lexical counts exclude comments and whitespace",
        r"tokens, but include docstring tokens. Nonblank line counts also include",
        r"docstring lines. Exact file hashes and all component counts are in",
        r"\texttt{code/measurement.json}.",
        "",
    ])
    (HERE.parent / "measurement.tex").write_text(latex)
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
