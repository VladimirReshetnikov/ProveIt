iPRA CHECKER COMPARISON
=======================

Files
-----
shared.py      Shared trusted syntax, capture-avoiding substitution, arithmetic
               leaves, equality rules, document validation, and JSON command line.
check.py       Candidate kernel with guarded Pi/Sigma and merged number rule.
baseline.py    The six drafts' common raw logical/arithmetic core, already given
               the native recursion binder optimization documented in draft2.
test_kernels.py       Finite regression checks and reproducible source measurements.
extra_tests.py  Independent named certificate generator; composed logical
               derivations and focused arithmetic rejection controls.
extra_test_results.json
               Results of the 11 additional targeted checks.
measure.py     Standalone complete-source counts and report table generation.
test_results.json
               Actual results of running test_kernels.py.
examples/      Accepted and intentionally rejected certificates, including
               composed derivations for numerical cases and encoded disjunction.

Python 3.9 or later is required. There are no third-party dependencies.

Run:
  python3 check.py examples/pi_reflexivity.json
  python3 check.py examples/identity_update.json
  python3 check.py examples/rejected_ih_leakage.json
  python3 test_kernels.py
  python3 extra_tests.py

The first two commands accept; the third rejects. Exit status is zero exactly
when a certificate is accepted. A filename '-' reads JSON from standard input.
The command line reports a small JSON result. Neither eval nor exec is used.
Python assertions are not used anywhere in the trusted checker: python3 -O
does not remove its checks. The test driver itself uses assertions.

Comparison scope
----------------
This is a comparison of complete implementations written in the same style,
not an encoding-independent minimum theorem. All trusted Python source in
shared.py plus the respective kernel is charged, including AST validation,
binder handling, substitution, rule recognition, and input handling. Python
itself and its standard json/sys libraries are shared runtime dependencies.
Tests, documentation, proof certificates, and example generation are not
part of the trusted checker. No preprocessing validator, conversion oracle,
termination oracle, semantic equality test, or hidden proof search is assumed.

The baseline is deliberately stronger as an implementation comparison than
a literal translation of the dated draft specifications: it already uses
the same native recursion syntax and substitution infrastructure as the
candidate. It also combines the two conjunction projections and the two
disjunction injections into parameterized proof cases. Weakening is implicit
in inherited contexts in both implementations. Its arithmetic rule is exactly
the common guarded equation successor rule, not unrestricted induction.

Document format
---------------
Every certificate is a JSON object with exactly four fields:

  {
    "scope": n,
    "context": [A1, ..., Ak],
    "goal": A,
    "proof": p
  }

n is a nonnegative integer, not a Boolean. It counts ambient free number
variables. A closed theorem certificate has scope 0 and empty context.
All supplied formulas and terms are checked for their sort, constructor
arity, and variable scope. Every supplied proof node is checked for its
rule's exact arity. Contexts are finite lists; membership implements the
usual reusable assumptions. Exchange, weakening, and contraction are
admissible, with no dedicated proof tags. Only the verifier entry point
verify(document, syntax, check), or the command line that invokes it, is
the supported untrusted-input interface. The recursive check function
internally relies on validated goals and contexts.

Number variables use de Bruijn indices. Variable 0 is the most recently
introduced number variable; entering a binder raises outer variable indices.
There are no proof variables in the object syntax. Assumption proof nodes
refer to their desired formula by matching the inherited goal in the context.

Terms (shared by both kernels)
-----------------------------
  ["v", i]                 variable, requiring 0 <= i < current scope
  ["z"]                    zero
  ["s", t]                 successor
  ["r", n, a, h]           initialized recursion

n and a are terms in the ambient scope. h is a term in scope+2: its index 0
is the state v, its index 1 is the predecessor counter w, and index j+2
refers to ambient variable j. Nested recursion nodes introduce their own
two local variables in their update child only. The update is literal
finite syntax, not a numerical program code or a first-class function.

The defining equations are:
  r(0,a;v,w.h) = a
  r(Sn,a;v,w.h) = h[r(n,a;v,w.h)/v, n/w].

The simultaneous substitution is capture avoiding. The constructor grammar
is finite and recursive, so a finite JSON term cannot contain a cyclic
descriptor. Free outer variables in an update are explicit number parameters.
There is no definitional conversion: these equations need r0 or rs leaves.

Formula syntax
--------------
Both kernels:
  ["eq", s, t]
  ["bot"]                  genuine logical falsity

Candidate:
  ["pi", A, B]             Pi x:A.B = forall x (A -> B)
  ["sigma", A, B]          Sigma x:A.B = exists x (A AND B)

In each case both A and B are formulas in scope+1, sharing the newly bound
number variable at index 0. There is no proof dependency or higher sort.

Baseline:
  ["and", A, B]
  ["or", A, B]
  ["imp", A, B]
  ["all", A]               A is in scope+1
  ["ex", A]                A is in scope+1

The baseline rejects pi/sigma; the candidate rejects the five baseline
connectives. All connective reconstruction belongs to mathematical proof
translations, not to an uncharged trusted parser or elaborator.

Shared proof nodes
------------------
Write C[t] for capture-avoiding instantiation of a template in one extra
number-variable slot by term t. Write up(Gamma) for shifting every ambient
free number variable in the context by one.

  ["hyp"]
    The requested goal must belong to the current context.

  ["refl"]
    The requested goal must be the literal equation t=t.

  ["eqE", s, t, C, p_equal, p_source]
    C is a validated formula in scope+1. The goal must be C[t].
    Check p_equal at s=t, and p_source at C[s], in the current context.
    C may be an arbitrary formula, including nested quantifiers/binders.

  ["abort", p]
    Check p at genuine falsity; conclude the requested arbitrary formula.

  ["sep"]
    The goal must be the fixed separation formula:
      candidate: ["pi", ["eq", ["z"], ["s", ["z"]]], ["bot"]]
      baseline:  ["imp", ["eq", ["z"], ["s", ["z"]]], ["bot"]]
    The candidate's dummy bound number variable is unused.

  ["r0"]
    The goal must be r(0,a;h)=a, literally matching the recursion base.

  ["rs"]
    The goal must match the recursion successor equation above, with its
    explicit right side computed by simultaneous syntactic substitution.

Candidate proof nodes
---------------------
  ["piI", p]
    Goal Pi x:A.B. Check p at B under up(Gamma),A in scope+1.

  ["piE", P, t, p_universal, p_guard]
    P is a validated Pi x:A.B in the current scope; t is a validated term.
    Goal must be B[t]. Check p_universal at P and p_guard at A[t].

  ["sigmaI", t, p_left, p_right]
    Goal Sigma x:A.B. Check p_left at A[t] and p_right at B[t].

  ["sigmaE", P, p_existential, p_branch]
    P is a validated Sigma x:A.B. Check p_existential at P.
    Check p_branch at up(goal), under up(Gamma),A,B in scope+1.
    Consequently, the fresh witness cannot escape into the outer goal.

  ["nat", F, t, p_base, p_step]
    F is a validated formula in scope+1; t is a term in the ambient scope.
    The requested goal must be F[t]. Check p_base at F[0] under Gamma.
    In scope+1, check p_step at F[Sx], under up(Gamma), with the additional
    hypothesis F[x] if and only if F's outer constructor is literally eq.

The last condition is essential. On equations this is equation induction.
On every other formula it permits only constructor cases, with no induction
hypothesis. All ambient hypotheses are retained and shifted. The test suite
includes a certificate that would be accepted if an induction hypothesis
were erroneously supplied for a Pi formula; the checker rejects it.

Baseline proof nodes
--------------------
  ["andI", p_left, p_right]
    Goal A AND B; check the two component proofs.

  ["andE", P, side, p]
    P is A AND B; side is integer 0 or 1, selecting A or B as the goal.

  ["orI", side, p]
    Goal A OR B; check p at the alternative selected by side 0 or 1.

  ["orE", P, p_disjunction, p_left, p_right]
    P is A OR B. Check p_disjunction at P and the branch proofs at the
    requested goal under Gamma,A and Gamma,B respectively.

  ["impI", p]
    Goal A -> B. Check p at B under Gamma,A.

  ["impE", P, p_implication, p_argument]
    P is A -> B and the goal is B. Check the two indicated premises.

  ["allI", p]
    Goal forall x A. Check p at A under up(Gamma) in scope+1.

  ["allE", P, t, p]
    P is forall x A. The goal must be A[t]. Check p at P.

  ["exI", t, p]
    Goal exists x A. Check p at A[t].

  ["exE", P, p_existential, p_branch]
    P is exists x A. Check p_existential at P; check the branch at
    up(goal) under up(Gamma),A in scope+1.

  ["sc", E, t, p_step]
    E must be an equation template in scope+1; t is an ambient term.
    Goal must be t=0 OR E[t]. Check p_step at E[Sx] in scope+1 under
    up(Gamma), (x=0 OR E[x]). No base premise is supplied.

Validation limits
-----------------
The tests check representative accepted proofs and targeted invalid ones:
binder capture, eigenvariable escape, non-atomic induction leakage, malformed
sorts/arities/scopes, and nested recursion substitution. They also exercise
safe JSON input and python3 -O. They do not establish general soundness by
exhaustive testing, and they are not a Lean or Rocq formalization. The report
must carry the mathematical soundness/completeness and bi-interpretation
arguments. Recursion limits and ordinary memory limits can reject excessively
large certificates; they never authorize accepting an unchecked certificate.
