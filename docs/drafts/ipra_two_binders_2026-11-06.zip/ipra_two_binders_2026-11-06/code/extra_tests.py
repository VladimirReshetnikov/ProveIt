"""Untrusted proof generation and targeted checks of the compressed logic.

The named-syntax compiler below is independent of the checker's substitution
functions.  All emitted certificates are checked through the public verifier.
It is a construction aid, not part of either trusted implementation.
"""

import itertools
import json
from pathlib import Path

import check as kernel
import shared as raw


HERE = Path(__file__).resolve().parent
SERIAL = itertools.count()
ZERO = ("z",)
BOTTOM = ("bot",)


def fresh(stem="x"):
    return stem + str(next(SERIAL))


def var(name):
    return ("v", name)


def succ(term):
    return ("s", term)


def equality(left, right):
    return ("eq", left, right)


TOP = equality(ZERO, ZERO)
ONE = succ(ZERO)
HYP = ("hyp",)
REFL = ("refl",)


def implication(left, right):
    return ("pi", fresh("dummy"), left, right)


def negation(formula):
    return implication(formula, BOTTOM)


def universal(name, body):
    return ("pi", name, TOP, body)


def q(counter, initial):
    state, index = fresh("state"), fresh("counter")
    return ("r", counter, initial, state, index, var(index))


def predecessor(term):
    return q(term, ZERO)


def disjunction(left, right):
    name = fresh("tag")
    zero = equality(var(name), ZERO)
    return ("sigma", name, implication(zero, left),
            implication(negation(zero), right))


def replace(node, name, value):
    """Named substitution; globally fresh binder names preclude capture."""
    tag = node[0]
    if tag == "v":
        return value if node[1] == name else node
    if tag in ("z", "bot"):
        return node
    if tag == "r":
        body = node[5] if name in node[3:5] else replace(node[5], name, value)
        return (tag, replace(node[1], name, value), replace(node[2], name, value),
                node[3], node[4], body)
    if tag in ("pi", "sigma"):
        if node[1] == name:
            return node
        return (tag, node[1], replace(node[2], name, value), replace(node[3], name, value))
    return (tag, *(replace(child, name, value) for child in node[1:]))


def encode(node, environment):
    """Independent conversion of named syntax to de Bruijn JSON."""
    tag = node[0]
    if tag == "v":
        return [tag, environment.index(node[1])]
    if tag in ("z", "bot"):
        return [tag]
    if tag == "r":
        return [tag, encode(node[1], environment), encode(node[2], environment),
                encode(node[5], [node[3], node[4]] + environment)]
    if tag in ("pi", "sigma"):
        bound = [node[1]] + environment
        return [tag, encode(node[2], bound), encode(node[3], bound)]
    return [tag, *(encode(child, environment) for child in node[1:])]


def proof_json(proof, goal, environment):
    tag = proof[0]
    if tag in ("hyp", "refl", "sep", "r0", "rs"):
        return [tag]
    if tag == "abort":
        return [tag, proof_json(proof[1], BOTTOM, environment)]
    if tag == "piI":
        return [tag, proof_json(proof[1], goal[3], [goal[1]] + environment)]
    if tag == "piE":
        principal, witness, univ, guard = proof[1:]
        return [tag, encode(principal, environment), encode(witness, environment),
                proof_json(univ, principal, environment),
                proof_json(guard, replace(principal[2], principal[1], witness), environment)]
    if tag == "sigmaI":
        witness, left, right = proof[1:]
        return [tag, encode(witness, environment),
                proof_json(left, replace(goal[2], goal[1], witness), environment),
                proof_json(right, replace(goal[3], goal[1], witness), environment)]
    if tag == "sigmaE":
        principal, existential, branch = proof[1:]
        return [tag, encode(principal, environment),
                proof_json(existential, principal, environment),
                proof_json(branch, goal, [principal[1]] + environment)]
    if tag == "eqE":
        slot, left, right, template, equal, source = proof[1:]
        return [tag, encode(left, environment), encode(right, environment),
                encode(template, [slot] + environment),
                proof_json(equal, equality(left, right), environment),
                proof_json(source, replace(template, slot, left), environment)]
    if tag == "nat":
        slot, template, target, base, step = proof[1:]
        return [tag, encode(template, [slot] + environment), encode(target, environment),
                proof_json(base, replace(template, slot, ZERO), environment),
                proof_json(step, replace(template, slot, succ(var(slot))), [slot] + environment)]
    raise ValueError("Unknown named proof node: " + tag)


def document(goal, proof, context=(), environment=()):
    environment = list(environment)
    return {"scope": len(environment), "context": [encode(f, environment) for f in context],
            "goal": encode(goal, environment), "proof": proof_json(proof, goal, environment)}


def implies_elim(left, right, implication_proof, argument):
    return ("piE", implication(left, right), ZERO, implication_proof, argument)


def symmetry(left, right, proof):
    slot = fresh("eq")
    return ("eqE", slot, left, right, equality(var(slot), left), proof, REFL)


def transitivity(left, middle, right, first, second):
    slot = fresh("eq")
    return ("eqE", slot, middle, right, equality(left, var(slot)), second, first)


def congruence(function, left, right, proof):
    slot = fresh("eq")
    return ("eqE", slot, left, right,
            equality(function(left), function(var(slot))), proof, REFL)


def successor_zero_bottom(n, assumed_equality):
    """Derive bottom from Sn=0 using Q's equations and Sep, no nat rule."""
    sn, psn, pzero = succ(n), predecessor(succ(n)), predecessor(ZERO)
    same_predecessors = congruence(predecessor, sn, ZERO, assumed_equality)
    n_equals_pzero = transitivity(n, psn, pzero,
                                 symmetry(psn, n, ("rs",)), same_predecessors)
    n_equals_zero = transitivity(n, pzero, ZERO, n_equals_pzero, ("r0",))
    sn_equals_one = congruence(succ, n, ZERO, n_equals_zero)
    zero_equals_one = transitivity(ZERO, sn, ONE,
                                  symmetry(sn, ZERO, assumed_equality), sn_equals_one)
    return implies_elim(equality(ZERO, ONE), BOTTOM, ("sep",), zero_equals_one)


def number_cases(term, conclusion, zero_branch, successor_branch):
    """Derive cases from the NON-ATOMIC branch of nat, with no IH."""
    index = fresh("case")
    template = implication(equality(term, var(index)), conclusion)
    target = replace(template, index, term)
    nat = ("nat", index, template, term,
           ("piI", zero_branch), ("piI", successor_branch(var(index))))
    return ("piE", target, ZERO, nat, REFL)


def or_left(left, right, left_proof):
    impossible = negation(equality(ZERO, ZERO))
    explosion = ("abort", ("piE", impossible, ZERO, HYP, REFL))
    return ("sigmaI", ZERO, ("piI", left_proof), ("piI", explosion))


def or_right(left, right, right_proof):
    return ("sigmaI", ONE,
            ("piI", ("abort", successor_zero_bottom(ZERO, HYP))),
            ("piI", right_proof))


def or_eliminate(left, right, conclusion, disjunction_proof, left_implication, right_implication):
    """A proof-producing implementation of the encoded disjunction rule."""
    principal = disjunction(left, right)
    tag = var(principal[1])
    is_zero = equality(tag, ZERO)
    left_result = implies_elim(is_zero, left, HYP, HYP)
    zero_branch = implies_elim(left, conclusion, left_implication, left_result)

    def successor_branch(index):
        sindex_equals_zero = transitivity(succ(index), tag, ZERO,
                                         symmetry(tag, succ(index), HYP), HYP)
        tag_nonzero = ("piI", successor_zero_bottom(index, sindex_equals_zero))
        right_result = implies_elim(negation(is_zero), right, HYP, tag_nonzero)
        return implies_elim(right, conclusion, right_implication, right_result)

    branch = number_cases(tag, conclusion, zero_branch, successor_branch)
    return ("sigmaE", principal, disjunction_proof, branch)


def close(names, formula, proof):
    for name in reversed(names):
        formula, proof = universal(name, formula), ("piI", proof)
    return formula, proof


def successor_nonzero_certificate():
    n = fresh("n")
    goal = negation(equality(succ(var(n)), ZERO))
    return document(*close([n], goal, ("piI", successor_zero_bottom(var(n), HYP))))


def number_cases_certificate():
    t, a, w, n, x = (fresh(stem) for stem in ("t", "a", "w", "n", "x"))
    conclusion = ("sigma", w, equality(var(w), var(a)),
                  universal(n, equality(q(var(n), var(w)), var(t))))
    zero_premise = implication(equality(var(t), ZERO), conclusion)
    successor_premise = universal(x, implication(equality(var(t), succ(var(x))), conclusion))
    zero_branch = implies_elim(equality(var(t), ZERO), conclusion, HYP, HYP)

    def successor_branch(index):
        specialized = ("piE", successor_premise, index, HYP, REFL)
        return implies_elim(equality(var(t), succ(index)), conclusion, specialized, HYP)

    result = number_cases(var(t), conclusion, zero_branch, successor_branch)
    goal = implication(zero_premise, implication(successor_premise, conclusion))
    return document(*close([t, a], goal, ("piI", ("piI", result))))


def sample_formulas():
    a, b, u, v, w, n = (fresh(stem) for stem in ("a", "b", "u", "v", "w", "n"))
    left = universal(u, equality(q(var(u), var(a)), var(b)))
    right = ("sigma", v, equality(q(var(v), var(b)), var(a)), equality(var(v), succ(var(b))))
    conclusion = ("sigma", w, equality(q(var(w), var(a)), var(b)),
                  ("pi", n, equality(q(var(n), var(w)), var(a)),
                   equality(q(var(n), var(b)), var(w))))
    return [a, b], left, right, conclusion


def disjunction_elimination_certificate():
    names, left, right, conclusion = sample_formulas()
    result = or_eliminate(left, right, conclusion, HYP, HYP, HYP)
    goal = implication(disjunction(left, right),
                       implication(implication(left, conclusion),
                                   implication(implication(right, conclusion), conclusion)))
    return document(*close(names, goal, ("piI", ("piI", ("piI", result)))))


def disjunction_commutativity_certificate():
    names, left, right, _ = sample_formulas()
    conclusion = disjunction(right, left)
    left_branch = ("piI", or_right(right, left, HYP))
    right_branch = ("piI", or_left(right, left, HYP))
    result = or_eliminate(left, right, conclusion, HYP, left_branch, right_branch)
    goal = implication(disjunction(left, right), conclusion)
    return document(*close(names, goal, ("piI", result)))


def induction_from_premises(quantified):
    target, index, step_index = (fresh(stem) for stem in ("target", "ih", "step"))

    def formula(term):
        if not quantified:
            return equality(q(term, ZERO), term)
        y, z = fresh("y"), fresh("z")
        return universal(y, ("sigma", z, equality(q(var(z), term), var(y)),
                             equality(var(z), succ(term))))

    template = formula(var(index))
    step_premise = universal(step_index,
                             implication(formula(var(step_index)), formula(succ(var(step_index)))))
    progress = ("piE", step_premise, var(index), HYP, REFL)
    step = implies_elim(template, formula(succ(var(index))), progress, HYP)
    proof = ("nat", index, template, var(target), HYP, step)
    return document(formula(var(target)), proof, [formula(ZERO), step_premise], [target])


def raw_document(goal, proof, scope=0):
    return {"scope": scope, "context": [], "goal": goal, "proof": proof}


def main():
    records = []
    examples = HERE / "examples"
    examples.mkdir(exist_ok=True)

    def exercise(name, certificate, expected, filename=None):
        reason = None
        try:
            raw.verify(certificate, kernel.SYNTAX, kernel.check)
            accepted = True
        except raw.Rejected as error:
            accepted, reason = False, str(error)
        if accepted != expected:
            raise RuntimeError((name, expected, accepted, reason))
        record = {"name": name, "accepted": accepted}
        if reason:
            record["reason"] = reason
        if filename:
            path = examples / (filename + ".json")
            path.write_text(json.dumps(certificate, indent=2) + "\n")
            record["certificate"] = path.name
            record["certificate_bytes"] = path.stat().st_size
        records.append(record)

    for name, factory, filename in (
        ("derived successor nonzeroness without induction", successor_nonzero_certificate, "successor_nonzero"),
        ("derived numerical cases for a nested quantified conclusion", number_cases_certificate, "derived_number_cases"),
        ("encoded disjunction elimination with quantified formula parameters", disjunction_elimination_certificate, "encoded_or_elimination"),
        ("encoded disjunction commutativity composes both injections and elimination", disjunction_commutativity_certificate, "encoded_or_commutativity"),
    ):
        exercise(name, factory(), True, filename)

    exercise("atomic induction uses its permitted induction hypothesis",
             induction_from_premises(False), True, "atomic_induction_from_premises")
    exercise("quantified induction cannot reuse a forbidden induction hypothesis",
             induction_from_premises(True), False, "rejected_quantified_induction")

    counter_update = raw.R(raw.S(raw.V(0)), raw.S(raw.Z), raw.V(1))
    exercise("recursion counter is the predecessor, not its successor",
             raw_document(raw.Eq(counter_update, raw.V(0)), ["rs"], 1), True)
    exercise("off-by-one recursion counter rejected",
             raw_document(raw.Eq(counter_update, raw.S(raw.V(0))), ["rs"], 1), False)
    exercise("previous state cannot replace counter slot",
             raw_document(raw.Eq(counter_update, raw.R(raw.V(0), raw.S(raw.Z), raw.V(1))), ["rs"], 1), False)

    nested = raw.R(raw.S(raw.V(0)), raw.V(1), raw.R(raw.V(1), raw.V(3), raw.V(5)))
    exercise("outer parameter survives two nested recursion binders",
             raw_document(raw.Eq(nested, raw.R(raw.V(0), raw.V(1), raw.V(3))), ["rs"], 2), True)
    exercise("wrong outer parameter under nested recursion rejected",
             raw_document(raw.Eq(nested, raw.R(raw.V(0), raw.V(1), raw.V(2))), ["rs"], 2), False)

    output = {"status": "all targeted checks passed", "checks": records,
              "scope": "Explicit accepted compressed-logic certificates plus focused rejection controls; not a general formal soundness proof.",
              "trust": "extra_tests.py and its named compiler are untrusted certificate generators; shared.py and check.py are unchanged."}
    (HERE / "extra_test_results.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
