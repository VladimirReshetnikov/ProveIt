"""Finite regression checks of the executable kernels, not a formal soundness proof."""

import ast
import io
import json
from pathlib import Path
import subprocess
import sys
import tokenize

import baseline
import check as candidate
from shared import B, Eq, R, Rejected, S, V, Z, verify


HERE = Path(__file__).resolve().parent
TOP = Eq(Z, Z)
results = []


def document(goal, proof, context=None, scope=0):
    return {"scope": scope, "context": [] if context is None else context,
            "goal": goal, "proof": proof}


def exercise(name, kernel, doc, accepted):
    try:
        verify(doc, kernel.SYNTAX, kernel.check)
        actual = True
    except Rejected:
        actual = False
    assert actual is accepted, (name, accepted, actual)
    results.append({"name": name, "kernel": kernel.__name__, "accepted": actual})
    return doc


def main():
    exercise("reflexivity", candidate, document(TOP, ["refl"]), True)
    universal = ["pi", TOP, Eq(V(0), V(0))]
    valid = exercise("Pi introduction with genuine bound variable", candidate,
                     document(universal, ["piI", ["refl"]]), True)
    exercise("Pi elimination and guard", candidate,
             document(Eq(S(Z), S(Z)),
                      ["piE", universal, S(Z), ["piI", ["refl"]], ["refl"]]), True)
    existential = ["sigma", TOP, Eq(V(0), S(Z))]
    exercise("Sigma introduction with witness", candidate,
             document(existential, ["sigmaI", S(Z), ["refl"], ["refl"]]), True)
    impossible = ["sigma", TOP, B]
    exercise("Sigma elimination consumes witness hypothesis", candidate,
             document(Eq(Z, S(Z)), ["sigmaE", impossible, ["hyp"], ["abort", ["hyp"]]],
                      [impossible]), True)
    template = ["pi", TOP, Eq(V(1), V(0))]
    source = ["pi", TOP, Eq(V(1), V(0))]
    target = ["pi", TOP, Eq(Z, V(0))]
    equality_proof = ["eqE", V(0), Z, template, ["hyp"], ["hyp"]]
    context = [Eq(V(0), Z), source]
    exercise("equality substitution under Pi avoids capture", candidate,
             document(target, equality_proof, context, 1), True)
    exercise("capturing equality substitution rejected", candidate,
             document(["pi", TOP, Eq(V(0), V(0))], equality_proof, context, 1), False)
    exercise("recursion base", candidate,
             document(Eq(R(Z, S(V(0)), S(V(0))), S(V(0))), ["r0"], scope=1), True)
    update = R(V(1), V(3), S(V(0)))
    exercise("recursion step keeps nested local binders", candidate,
             document(Eq(R(S(V(0)), V(1), update), R(V(0), V(1), S(V(0)))), ["rs"], scope=2), True)
    nested_update = R(Z, Z, S(V(2)))
    exercise("state substitution shifts beneath nested recursion binder", candidate,
             document(Eq(R(S(V(0)), Z, nested_update),
                         R(Z, Z, S(R(V(2), Z, nested_update)))), ["rs"], scope=1), True)
    induction_template = Eq(R(V(0), V(1), V(0)), V(1))
    step = ["eqE", R(V(0), V(1), V(0)), V(1),
            Eq(R(S(V(1)), V(2), V(0)), V(0)), ["hyp"], ["rs"]]
    induction = document(Eq(R(V(0), V(0), V(0)), V(0)),
                         ["nat", induction_template, V(0), ["r0"], step], scope=1)
    exercise("equation induction proves identity update", candidate, induction, True)
    case_template = ["pi", TOP, Eq(V(1), V(1))]
    exercise("non-atomic constructor cases", candidate,
             document(["pi", TOP, Eq(Z, Z)],
                      ["nat", case_template, Z, ["piI", ["refl"]], ["piI", ["refl"]]]), True)
    constant_predicate = ["pi", TOP, TOP]
    leakage = document(constant_predicate,
                       ["nat", constant_predicate, Z, ["piI", ["hyp"]], ["hyp"]])
    exercise("non-atomic induction hypothesis leakage rejected", candidate, leakage, False)
    exercise("Pi eigenvariable cannot capture ambient hypothesis", candidate,
             document(["pi", TOP, Eq(V(0), Z)], ["piI", ["hyp"]], [Eq(V(0), Z)], 1), False)
    witness_zero = ["sigma", TOP, Eq(V(0), Z)]
    exercise("Sigma witness cannot escape", candidate,
             document(Eq(V(0), Z), ["sigmaE", witness_zero, ["hyp"], ["hyp"]],
                      [witness_zero], 1), False)
    exercise("root variable scope checked", candidate,
             document(Eq(V(0), V(0)), ["refl"]), False)
    exercise("Boolean is not a variable index", candidate,
             document(Eq(V(True), V(True)), ["refl"], scope=2), False)
    exercise("recursion body cannot capture absent outer variable", candidate,
             document(Eq(R(Z, Z, V(2)), Z), ["r0"]), False)
    exercise("formula cannot occur as a number term", candidate,
             document(Eq(TOP, TOP), ["refl"]), False)
    exercise("extra certificate payload rejected", candidate,
             document(TOP, ["refl", ["hyp"]]), False)
    exercise("baseline connective cannot enter candidate syntax", candidate,
             document(["and", TOP, TOP], ["hyp"], [["and", TOP, TOP]]), False)
    exercise("candidate separation", candidate,
             document(candidate.SEPARATION, ["sep"]), True)
    exercise("baseline separation", baseline,
             document(baseline.SEPARATION, ["sep"]), True)
    exercise("baseline guarded equation closure", baseline,
             document(["or", Eq(S(Z), Z), Eq(S(Z), S(Z))],
                      ["sc", Eq(V(0), V(0)), S(Z), ["refl"]]), True)
    alternatives = ["or", TOP, Eq(S(Z), S(Z))]
    exercise("baseline disjunction elimination", baseline,
             document(TOP, ["orE", alternatives, ["hyp"], ["refl"], ["refl"]], [alternatives]), True)
    exercise("baseline universal eigenvariable checked", baseline,
             document(["all", Eq(V(0), Z)], ["allI", ["hyp"]], [Eq(V(0), Z)], 1), False)
    for flag, doc, expected in (([], valid, 0), (["-O"], leakage, 1)):
        run = subprocess.run([sys.executable, *flag, str(HERE / "check.py"), "-"],
                             input=json.dumps(doc), text=True, capture_output=True, check=False)
        assert run.returncode == expected, run
        assert json.loads(run.stdout)["accepted"] is (expected == 0), run.stdout
        results.append({"name": "JSON CLI " + ("optimized Python rejects leakage" if flag else "accepts valid proof"),
                        "kernel": "check", "accepted": expected == 0})
    for name, doc in (("pi_reflexivity", valid), ("identity_update", induction), ("rejected_ih_leakage", leakage)):
        (HERE / "examples" / (name + ".json")).write_text(json.dumps(doc, indent=2) + "\n")
    metrics = {}
    for filename in ("shared.py", "check.py", "baseline.py"):
        text = (HERE / filename).read_text()
        tokens = [token for token in tokenize.generate_tokens(io.StringIO(text).readline)
                  if token.type not in (tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE,
                                        tokenize.NL, tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT)]
        metrics[filename] = {
            "utf8_bytes": len(text.encode()),
            "physical_lines": len(text.splitlines()),
            "nonblank_noncomment_lines": sum(bool(line.strip()) and not line.lstrip().startswith("#")
                                             for line in text.splitlines()),
            "lexical_tokens": len(tokens),
            "python_ast_nodes": sum(1 for _ in ast.walk(ast.parse(text))),
        }
    for label, files in (("candidate_total", ["shared.py", "check.py"]),
                         ("baseline_total", ["shared.py", "baseline.py"])):
        metrics[label] = {key: sum(metrics[name][key] for name in files) for key in metrics["shared.py"]}
    output = {"status": "all regression checks passed", "checks": results, "metrics": metrics,
              "scope": "Finite kernel regressions and exact source counts; no mechanized general soundness proof."}
    (HERE / "test_results.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"checks": len(results), "metrics": metrics}, indent=2))


if __name__ == "__main__":
    (HERE / "examples").mkdir(exist_ok=True)
    main()
