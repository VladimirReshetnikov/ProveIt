"""Rebuild and package the report with its complete reproducible artifacts."""

import hashlib
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent


def run(*arguments):
    subprocess.run(arguments, cwd=ROOT, check=True)


def main():
    run(sys.executable, "code/test_kernels.py")
    if (ROOT / "code/extra_tests.py").exists():
        run(sys.executable, "code/extra_tests.py")
    run(sys.executable, "code/measure.py")
    with tempfile.TemporaryDirectory(prefix="ipra_tex_") as temporary:
        work = Path(temporary)
        for _ in range(3):
            completed = subprocess.run(
                ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", "-output-directory", str(work), "report.tex"],
                cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            )
            if completed.returncode:
                print(completed.stdout)
                raise SystemExit(completed.returncode)
        shutil.copyfile(work / "report.pdf", ROOT / "report.pdf")
        log = (work / "report.log").read_text(errors="replace")
        warnings = [line for line in log.splitlines()
                    if "Warning" in line or "Overfull" in line]
        print("LaTeX warnings:", warnings)
    excluded = {"SHA256SUMS.txt"}
    files = sorted(
        path for path in ROOT.rglob("*")
        if path.is_file()
        and path.name not in excluded
        and "__pycache__" not in path.parts
        and path.suffix not in {".pyc", ".aux", ".log", ".toc", ".out"}
    )
    sums = "\n".join(
        hashlib.sha256(path.read_bytes()).hexdigest() + "  " +
        path.relative_to(ROOT).as_posix() for path in files
    ) + "\n"
    checksums = ROOT / "SHA256SUMS.txt"
    checksums.write_text(sums)
    archive = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for path in files + [checksums]:
            package.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    standalone = ROOT.with_suffix(".pdf")
    shutil.copyfile(ROOT / "report.pdf", standalone)
    print("PDF:", standalone)
    print("ZIP:", archive)


if __name__ == "__main__":
    main()
