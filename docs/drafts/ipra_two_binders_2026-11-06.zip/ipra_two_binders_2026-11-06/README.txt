iPRA WITH TWO LOGICAL BINDERS
6 November 2026
===========================

Recommended entry point: report.pdf
Complete mathematical source: report.tex and measurement.tex
Compact standalone specification: SPECIFICATION.txt

RESULT
------
The report gives a full intuitionistic first-order presentation with only
four formula constructors: equality, genuine falsity, Pi and Sigma.
Pi x[A;B] means forall x(A -> B).
Sigma x[A;B] means exists x(A AND B).
Ordinary connectives, including disjunction, are reconstructed constructively.

Arithmetic uses initialized native primitive recursion, 0 != S0, and a
single number rule. The rule gives an induction hypothesis only for an
equation matrix. For every other formula it gives only constructor cases.
The report proves whole-carrier bi-interpretability with the specified full
first-order iPRA, including both term and arbitrary-formula round trips.

The complete candidate checker occupies 7,796 UTF-8 source bytes / 1,835
Python lexical tokens including its shared code. The comparable complete
checker for the six drafts' common raw core occupies 9,516 bytes / 2,239
tokens. The respective reductions are about 18.1% and 18.0%.
Both receive the same native-recursion notation and infrastructure.
This is a reproducible implementation comparison, not a global minimum.

CONTENTS
--------
report.pdf / report.tex       Complete theory, reconstruction, equivalence,
                              size comparison, limits, further questions.
measurement.tex              Table generated from exact trusted source.
SPECIFICATION.txt            Entire calculus in plain text.
code/shared.py               Trusted shared syntax, substitution, leaves, CLI.
code/check.py                Trusted native candidate checker.
code/baseline.py             Trusted draft-core comparison checker.
code/README.txt              Full JSON certificate and proof-node format.
code/test_kernels.py         Positive and adversarial regression checks.
code/test_results.json       Recorded results of those checks.
code/extra_tests.py          Independent named certificate generator and
                              targeted checks of the compressed logic.
code/extra_test_results.json Results of those checks.
code/measure.py              Reproducible complete-source measurements.
code/measurement.json        Counts, conventions and trusted-file hashes.
code/examples/               Accepted and intentionally rejected certificates.
provenance/                  Pinned source manifest and review notes.
build.py                     Rebuilds checks, measurement, PDF, and ZIP.
SHA256SUMS.txt                Checksums for deliverable files except itself.

RUNNING
-------
Python 3.9 or later, standard library only:

  python3 code/test_kernels.py
  python3 code/extra_tests.py
  python3 code/measure.py
  python3 code/check.py code/examples/identity_update.json
  python3 code/check.py code/examples/rejected_ih_leakage.json

The last command is deliberately rejected (exit status 1).
The others should succeed. A checker filename "-" reads a JSON certificate
from stdin. The public untrusted-input boundary is verify or the CLI, not an
unchecked direct call to the internal recursive check function.

To rebuild the PDF and ZIP, install pdflatex with the packages listed at the
start of report.tex, then run:

  python3 build.py

The archive is written next to this folder. Runtime memory/recursion limits
can cause very large certificates to be rejected; they never authorize
accepting unchecked input. The trusted checkers do not use Python asserts,
eval, exec, semantic normalization or external theorem services.

VALIDATION AND LIMITATIONS
--------------------------
The report supplies written general proofs. All 28 kernel regressions and
11 additional targeted checks pass. Explicit certificates include successor
nonzeroness, numerical cases for a quantified conclusion, encoded disjunction
elimination and commutativity, and rejection of forbidden quantified induction.
The mathematical equivalence theorem and kernel
soundness are not formally verified in Lean or Rocq. The smaller checker
need not give shorter proofs or faster checking of the same user-level
theorem. No source-size global optimality theorem is asserted.

SOURCE SNAPSHOT
---------------
VladimirReshetnikov/ProveIt
86b708a209fd20431908347c5aa051d73c8d4682
All six current docs/drafts ZIPs, inspected on 6 November 2026.
Their Git blob hashes and byte lengths were verified; complete provenance
and SHA-256 hashes are included.
