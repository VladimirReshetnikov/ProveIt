PRA WITH A SHARED ZERO GUARD
Research prepared for Vladimir Reshetnikov
1 November 2026 (America/Los_Angeles)

MAIN RESULT
The sole schema in report.pdf is definitionally equivalent to classical
first-order PRA in classical logic, and to intuitionistic first-order PRA
in intuitionistic logic. Both interpretations have the full carrier and
native equality; both round trips are internally the identity.

The strongest of the five reviewed drafts use adjacent evaluations of
one binary term. Sharing their existing zero guard with the iterator step
allows D_h(SSn,a)=h(D_h(Sn,a)) to be replaced, on the nonzero branch, by
D_h(Sn,a)=h(D_h(n,a)). The theory derives successor nonzeroness before
induction, so the new and old schemas are constructively equivalent.

EXACT IMPROVEMENT
For the same input term u, with active size m, i occurrences of n, and
j occurrences of a:
  old: 38 + 7m + 5i + 3j
  new: 37 + 7m + 4i + 3j
Every instance saves exactly 1+i nodes. Descriptor bodies are unchanged.
The shifts are optimal within the fixed successor-shift Tail template.
No claim of a globally shortest axiomatization is made.

CONTENTS
  report.pdf, report.tex, sections/ : full paper and LaTeX sources
  formal/GuardedTail.lean          : checked constructive reduction kernel
  formal/SCOPE.txt                 : exact mechanization scope
  formal/lean-check.log            : 11 empty axiom-dependency lists
  checks/check_schema.py           : reproducible syntax/size checker
  checks/results.json             : 1,822 checks, 80 representative terms
  checks/examples.txt             : expanded axiom instances
  audit/source_manifest.json      : pinned sources and checksums
  audit/CURRENT_DRAFT_AUDIT.txt    : current five-archive comparison
  build.py                        : rebuild and optional Lean verification
  SHA256SUMS.txt                  : package file checksums

REBUILD
Requirements: Python 3.10+, pdfLaTeX with the packages listed in report.tex.
  python3 build.py
Optional full recorded kernel check (Lean 4.19.0):
  python3 build.py --lean /absolute/path/to/lean
Checks only:
  python3 checks/check_schema.py
  cd formal
  lean GuardedTail.lean

The Lean file checks the new reduction over arbitrary carriers, with an
explicit old-theory coverage hypothesis in the reverse direction. It does
not mechanize the full pairing/PR compiler/bi-interpretability proof.
Those arguments are in the paper. Finite computation checks are diagnostics,
not proofs of the infinite theories.

SOURCE SNAPSHOT
VladimirReshetnikov/ProveIt
9e77f2a2bb9ccf0a4f85934f1f83df8a3f8767be
https://github.com/VladimirReshetnikov/ProveIt/tree/9e77f2a2bb9ccf0a4f85934f1f83df8a3f8767be/docs/drafts

The shifted scalar pairing argument is inherited from the unnumbered
one-term archive. The new mathematical contribution is guard sharing,
its noncircular bootstrap, the uniform shortening theorem, and the local
optimality statement. The zero-endpoint and parameter-free alternatives
remain unproved here and are not claimed as results.
