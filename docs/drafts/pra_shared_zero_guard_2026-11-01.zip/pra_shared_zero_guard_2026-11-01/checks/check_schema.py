#!/usr/bin/env python3
"""Exact AST comparisons for the adjacent and shared-zero-guard PRA schemas.

Python 3.10+, standard library only. Run this file to regenerate results.json
and examples.txt in this directory. Failed checks raise AssertionError.

Adapted from checks/check_schema.py in pra_adjacent_parameter_2026-11-01.zip,
ProveIt/docs/drafts, commit 9e77f2a2bb9ccf0a4f85934f1f83df8a3f8767be.
That archive's Git blob is 0a1bbba9c99b0973c771be05dabec9687a82cc24.
The term/formula AST, frozen-descriptor conventions, and original constructor
are retained in substance. The shared-guard constructor, exact three-way cost
comparison, focused examples, and checks below are new to this package.

This is a finite syntax audit with a small standard-natural-number diagnostic.
It is NOT a formal proof of the infinite schemas, induction, consistency,
or bi-interpretability; see the paper and the separately checked Lean kernel.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple[Term, ...] = ()
    name: str = ""
    body: Term | None = None


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")
n, a, v = (var(name) for name in ("n", "a", "v"))


def succ(x: Term) -> Term:
    return Term("succ", (x,))


ONE = succ(ZERO)


def delayed(body: Term, counter: Term, seed: Term) -> Term:
    return Term("delay", (counter, seed), body=body)


def substitute(t: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous substitution of active variables; never enter t.body."""
    if t.tag == "var":
        return replacements.get(t.name, t)
    return Term(t.tag, tuple(substitute(x, replacements) for x in t.args),
                t.name, t.body)


def free_variables(t: Term) -> set[str]:
    if t.tag == "var":
        return {t.name}
    return set().union(*(free_variables(x) for x in t.args))


def validate(t: Term, allowed: set[str], *, template: bool = False) -> None:
    arities = {"var": 0, "zero": 0, "succ": 1, "delay": 2}
    if template:
        arities["hole"] = 2
    if t.tag not in arities or len(t.args) != arities[t.tag]:
        raise ValueError(f"Malformed or inadmissible term: {t.tag}")
    if t.tag == "var" and t.name not in allowed:
        raise ValueError(f"Unexpected variable: {t.name}")
    if t.tag == "delay":
        if t.body is None:
            raise ValueError("Missing frozen descriptor")
        validate(t.body, {"v"}, template=template)
    elif t.body is not None:
        raise ValueError("Only delay symbols have descriptors")
    for child in t.args:
        validate(child, allowed, template=template)


def term_nodes(t: Term, *, stored: bool = False) -> int:
    result = 1 + sum(term_nodes(x, stored=stored) for x in t.args)
    if stored and t.body is not None:
        result += term_nodes(t.body, stored=True)
    return result


def occurrences(t: Term, name: str) -> int:
    return int(t.tag == "var" and t.name == name) + sum(
        occurrences(x, name) for x in t.args)


def rank(t: Term) -> int:
    values = [0] + [rank(x) for x in t.args]
    if t.body is not None:
        values.append(1 + rank(t.body))
    return max(values)


def descriptors(t: Term) -> set[Term]:
    result = set().union(*(descriptors(x) for x in t.args))
    if t.body is not None:
        result.add(t.body)
        result.update(descriptors(t.body))
    return result


def print_term(t: Term) -> str:
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "succ":
        return f"S({print_term(t.args[0])})"
    if t.tag == "delay":
        return (f"D[{print_term(t.body)}]("  # type: ignore[arg-type]
                f"{print_term(t.args[0])},{print_term(t.args[1])})")
    if t.tag == "hole":
        return f"{t.name}({','.join(print_term(x) for x in t.args)})"
    raise ValueError(t.tag)


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple[Formula | Term, ...] = ()
    bound: str = ""


def eq(x: Term, y: Term) -> Formula:
    return Formula("eq", (x, y))


def binary(tag: str, x: Formula, y: Formula) -> Formula:
    return Formula(tag, (x, y))


def all_(name: str, f: Formula) -> Formula:
    return Formula("all", (f,), name)


def formula_nodes(f: Formula, *, stored: bool = False) -> int:
    return 1 + sum(term_nodes(x, stored=stored) if isinstance(x, Term)
                   else formula_nodes(x, stored=stored) for x in f.args)


def formula_free(f: Formula) -> set[str]:
    result = set().union(*(free_variables(x) if isinstance(x, Term)
                          else formula_free(x) for x in f.args))
    return result - {f.bound} if f.tag == "all" else result


def formula_names(f: Formula) -> set[str]:
    result = set().union(*(free_variables(x) if isinstance(x, Term)
                          else formula_names(x) for x in f.args))
    return result | ({f.bound} if f.tag == "all" else set())


def formula_descriptors(f: Formula) -> set[Term]:
    return set().union(*(descriptors(x) if isinstance(x, Term)
                         else formula_descriptors(x) for x in f.args))


def descriptor_occurrences(node: Formula | Term) -> Counter[Term]:
    """Count frozen bodies with full repeated expansion, including dependencies."""
    result: Counter[Term] = Counter()
    for child in node.args:
        result.update(descriptor_occurrences(child))
    if isinstance(node, Term) and node.body is not None:
        result[node.body] += 1
        result.update(descriptor_occurrences(node.body))
    return result


def logical_profile(f: Formula) -> dict[str, int]:
    result = {f.tag: 1}
    for child in f.args:
        if isinstance(child, Formula):
            for tag, count in logical_profile(child).items():
                result[tag] = result.get(tag, 0) + count
    return result


def quantifier_data(f: Formula, depth: int = 0) -> tuple[int, int]:
    next_depth = depth + int(f.tag == "all")
    count, maximum = int(f.tag == "all"), next_depth
    for child in f.args:
        if isinstance(child, Formula):
            child_count, child_maximum = quantifier_data(child, next_depth)
            count += child_count
            maximum = max(maximum, child_maximum)
    return count, maximum


def print_formula(f: Formula) -> str:
    if f.tag == "bot":
        return "false"
    if f.tag == "eq":
        return f"({print_term(f.args[0])}={print_term(f.args[1])})"
    if f.tag == "all":
        return f"forall {f.bound} ({print_formula(f.args[0])})"
    op = {"and": "AND", "or": "OR", "imp": "->"}[f.tag]
    return f"({print_formula(f.args[0])} {op} {print_formula(f.args[1])})"


def zero_section(u: Term) -> Term:
    return substitute(u, {"n": v, "a": ZERO})


def parts(u: Term, *, template: bool = False) -> dict[str, Formula]:
    validate(u, {"n", "a"}, template=template)
    h = zero_section(u)
    equality = eq(u, substitute(u, {"a": succ(a)}))
    successor = eq(substitute(u, {"n": succ(n)}),
                   substitute(u, {"n": succ(n), "a": succ(a)}))
    root = eq(n, ZERO)
    reset = eq(delayed(h, delayed(ONE, n, ZERO), a), a)
    old_tail = eq(delayed(h, succ(succ(n)), a),
                  substitute(h, {"v": delayed(h, succ(n), a)}))
    new_tail = eq(delayed(h, succ(n), a),
                  substitute(h, {"v": delayed(h, n, a)}))
    sigma = binary("imp", eq(ZERO, ONE), Formula("bot"))
    rooted = binary("or", root, equality)
    premise = all_("n", binary("imp", rooted, successor))
    return dict(equality=equality, root=root, reset=reset, old_tail=old_tail,
                new_tail=new_tail, sigma=sigma, rooted=rooted, premise=premise)


def axiom(u: Term, *, shared_guard: bool, template: bool = False) -> Formula:
    p = parts(u, template=template)
    if shared_guard:
        guarded = binary("or", p["root"],
                         binary("and", p["equality"], p["new_tail"]))
        conclusion = binary("and", p["sigma"],
                            binary("and", p["reset"], guarded))
    else:
        kernel = binary("and", p["sigma"],
                        binary("and", p["reset"], p["old_tail"]))
        conclusion = binary("and", p["rooted"], kernel)
    return all_("a", binary("imp", p["premise"], all_("n", conclusion)))


@lru_cache(maxsize=None)
def unary_value(body: Term, value: int) -> int:
    return evaluate(body, {"v": value})


def evaluate(t: Term, env: dict[str, int]) -> int:
    if t.tag == "zero":
        return 0
    if t.tag == "var":
        return env[t.name]
    if t.tag == "succ":
        return 1 + evaluate(t.args[0], env)
    if t.tag == "delay":
        counter = evaluate(t.args[0], env)
        value = evaluate(t.args[1], env)
        for _ in range(max(counter - 1, 0)):
            value = unary_value(t.body, value)  # type: ignore[arg-type]
        return value
    raise ValueError("Schematic holes are not arithmetic operations")


def evaluate_matrix(f: Formula, env: dict[str, int]) -> bool:
    if f.tag == "eq":
        return evaluate(f.args[0], env) == evaluate(f.args[1], env)
    if f.tag == "bot":
        return False
    if f.tag == "all":
        raise ValueError("No finite approximation to a universal axiom is used")
    left = evaluate_matrix(f.args[0], env)
    right = evaluate_matrix(f.args[1], env)
    return {"and": left and right, "or": left or right,
            "imp": not left or right}[f.tag]


CHECKS: dict[str, int] = {}


def check(group: str, condition: bool, detail: str = "") -> None:
    if not condition:
        raise AssertionError(f"{group}: {detail}")
    CHECKS[group] = CHECKS.get(group, 0) + 1


def cost_row(u: Term, *, template: bool = False) -> dict:
    old = axiom(u, shared_guard=False, template=template)
    new = axiom(u, shared_guard=True, template=template)
    descriptor_table = sum(term_nodes(h) for h in formula_descriptors(old))
    return {
        "input": print_term(u), "zero_section": print_term(zero_section(u)),
        "input_active_nodes": term_nodes(u), "active_n": occurrences(u, "n"),
        "active_a": occurrences(u, "a"),
        "old_active_nodes": formula_nodes(old), "new_active_nodes": formula_nodes(new),
        "old_repeated_descriptor_nodes": formula_nodes(old, stored=True),
        "new_repeated_descriptor_nodes": formula_nodes(new, stored=True),
        "distinct_descriptors": len(formula_descriptors(old)),
        "shared_descriptor_table_nodes": descriptor_table,
        "old_shared_table_total": formula_nodes(old) + descriptor_table,
        "new_shared_table_total": formula_nodes(new) + descriptor_table,
        "saving_in_each_cost_model": 1 + occurrences(u, "n"),
    }


def main() -> None:
    bodies = [v, ZERO, ONE, succ(v), delayed(succ(v), v, ZERO),
              delayed(delayed(succ(v), v, ZERO), succ(v), ZERO)]
    samples = [ZERO, ONE, n, a, succ(n), succ(a)]
    samples += [delayed(h, x, y) for h in bodies
                for x in [n, a, succ(n), succ(a)] for y in [ZERO, n, a]]
    samples += [delayed(bodies[-1], delayed(succ(v), n, a), succ(n)),
                delayed(v, delayed(ZERO, n, n), delayed(ONE, a, n))]
    samples = list(dict.fromkeys(samples))

    for u in samples:
        old = axiom(u, shared_guard=False)
        new = axiom(u, shared_guard=True)
        m, i, j = term_nodes(u), occurrences(u, "n"), occurrences(u, "a")
        check("old_active_formula", formula_nodes(old) == 38 + 7*m + 5*i + 3*j)
        check("new_active_formula", formula_nodes(new) == 37 + 7*m + 4*i + 3*j)
        check("strict_active_saving", formula_nodes(old) - formula_nodes(new) == 1+i)
        check("identical_logical_profile", logical_profile(old) == logical_profile(new))
        check("identical_descriptors", formula_descriptors(old) == formula_descriptors(new))
        check("identical_descriptor_occurrences", descriptor_occurrences(old)
              == descriptor_occurrences(new))
        check("repeated_descriptor_saving", formula_nodes(old, stored=True)
              - formula_nodes(new, stored=True) == 1+i)
        for formula in [old, new]:
            check("closed_axioms", formula_free(formula) == set())
            check("two_active_names", formula_names(formula) == {"n", "a"})
            check("quantifier_profile", quantifier_data(formula) == (3, 2))
        h = zero_section(u)
        validate(h, {"v"})
        check("zero_section_rank", rank(h) == rank(u))
        check("well_founded_generated_descriptor", rank(delayed(h, n, a)) == rank(u)+1)

    for h in bodies:
        u = substitute(h, {"v": n})
        check("every_body_extractable", zero_section(u) == h)
        check("reflexive_progress", substitute(u, {"a": succ(a)}) == u)

    frozen = delayed(bodies[-1], n, a)
    changed = substitute(frozen, {"n": succ(a), "a": ZERO, "v": ONE})
    check("frozen_descriptor_identity", changed.body is frozen.body)
    check("simultaneous_substitution", changed.args == (succ(a), ZERO))
    check("stored_variables_not_active", occurrences(frozen, "v") == 0)
    check("stored_rank_nonzero", rank(frozen) >= 3)
    for bad in [var("b"), delayed(n, n, a), Term("succ", (n, a)),
                Term("hole", (n, a), "U")]:
        try:
            axiom(bad, shared_guard=True)
        except ValueError:
            check("invalid_syntax_rejected", True)
        else:
            raise AssertionError("Invalid syntax was admitted")

    # Standard N diagnostics check only the finite computation matrices.
    # They neither test all universal premises nor certify intuitionistic proofs.
    bound = 4
    for u in [ZERO, n, a, succ(n), succ(a), frozen]:
        p = parts(u)
        for counter in range(bound+1):
            for seed in range(bound+1):
                env = {"n": counter, "a": seed}
                check("standard_reset", evaluate_matrix(p["reset"], env))
                check("standard_old_tail", evaluate_matrix(p["old_tail"], env))
                check("standard_guarded_new_tail", counter == 0
                      or evaluate_matrix(p["new_tail"], env))
                old_local = binary("and", p["rooted"], p["old_tail"])
                new_local = binary("or", p["root"],
                                   binary("and", p["equality"], p["new_tail"]))
                check("standard_conclusion_matrices", evaluate_matrix(old_local, env)
                      == evaluate_matrix(new_local, env))

    # The guard is substantive: at n=0 and h=S the unguarded new tail is false.
    check("guard_is_needed", not evaluate_matrix(parts(succ(n))["new_tail"],
                                                {"n": 0, "a": 0}))

    hole = Term("hole", (n, a), "U")
    template = cost_row(hole, template=True)
    check("schematic_hole_counts", (template["old_active_nodes"],
                                     template["new_active_nodes"]) == (67, 65))
    examples = [cost_row(u) for u in [ZERO, n, a, succ(n), frozen, samples[-1]]]
    result = {
        "status": "passed", "source_archive_blob": "0a1bbba9c99b0973c771be05dabec9687a82cc24",
        "scope": "Finite AST checks and bounded computations in N; no proof of the infinite theory.",
        "sample_input_terms": len(samples), "maximum_sample_descriptor_rank": max(map(rank, samples)),
        "old_active_count": "38 + 7*m + 5*i + 3*j",
        "new_active_count": "37 + 7*m + 4*i + 3*j", "exact_uniform_saving": "1 + i",
        "notation": "m=active term nodes; i=active n occurrences; j=active a occurrences",
        "count_convention": "One node per variable, 0, S, D application, equality, connective, or quantifier; 1=S(0).",
        "descriptor_costs": "Both schemas have exactly the same descriptor occurrences and distinct descriptor table. Saving 1+i persists when bodies are repeated or stored once.",
        "logical_profile": logical_profile(axiom(n, shared_guard=True)),
        "quantifier_count": 3, "maximum_quantifier_depth": 2,
        "semantic_bound_inclusive": bound, "semantic_input_terms": 6,
        "checks_by_group": CHECKS, "total_checks": sum(CHECKS.values()),
        "schematic_hole_example": template, "examples": examples,
    }
    directory = Path(__file__).resolve().parent
    (directory / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = ["EXACT SCHEMA EXAMPLES", "", "D[body](counter,seed) stores body as frozen syntax.",
             "The schematic U hole below is not an arithmetic function symbol.", ""]
    for u in [n, a, hole]:
        lines.extend(["INPUT: " + print_term(u),
                      "OLD: " + print_formula(axiom(u, shared_guard=False, template=u is hole)),
                      "NEW: " + print_formula(axiom(u, shared_guard=True, template=u is hole)), ""])
    (directory / "examples.txt").write_text("\n".join(lines))
    print(json.dumps({"status": "passed", "sample_input_terms": len(samples),
                      "total_checks": result["total_checks"], "template_nodes": [67, 65]}, indent=2))


if __name__ == "__main__":
    main()
