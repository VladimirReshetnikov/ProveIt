import Init

/-!
Constructive kernel for sharing the zero guard with delayed-iterator Tail.
This is a conditional higher-order kernel on arbitrary carriers, not a
formalization of the complete generated first-order syntax or PRA calibration.
-/

namespace GuardedTail

universe u v
variable {A : Type u} {B : Type v}

def Kernel (zero : A) (succ : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B) : Prop :=
  zero ≠ succ zero ∧
  (∀ index n a, iter index (iter oneIndex n zero) a = a) ∧
  (∀ index n a, n = zero ∨ iter index (succ n) a = body index (iter index n a))

theorem guardedSeeds
    (zero : A) (succ : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (constantOne : ∀ x, body oneIndex x = succ zero)
    (kernel : Kernel zero succ iter body oneIndex) :
    (∀ index a, iter index (succ zero) a = a) ∧
    (∀ index a, iter index zero a = a) := by
  obtain ⟨separation, reset, guarded⟩ := kernel
  have oneNotZero : succ zero ≠ zero := fun h => separation h.symm
  have qTwo : iter oneIndex (succ (succ zero)) zero = succ zero := by
    cases guarded oneIndex (succ zero) zero with
    | inl equalZero => exact False.elim (oneNotZero equalZero)
    | inr recurrence => exact recurrence.trans (constantOne _)
  have seedOne : ∀ index a, iter index (succ zero) a = a := by
    intro index a
    have equation := reset index (succ (succ zero)) a
    rw [qTwo] at equation
    exact equation
  constructor
  · exact seedOne
  · intro index a
    have equation := reset index (succ zero) a
    rw [seedOne oneIndex zero] at equation
    exact equation

theorem successorNonzeroBeforeInduction
    (zero : A) (succ : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (constantOne : ∀ x, body oneIndex x = succ zero)
    (kernel : Kernel zero succ iter body oneIndex) :
    ∀ x, succ x ≠ zero := by
  have seedZero := (guardedSeeds zero succ iter body oneIndex constantOne kernel).2
  obtain ⟨separation, _, guarded⟩ := kernel
  intro x successorZero
  cases guarded oneIndex x zero with
  | inl equalZero =>
    rw [equalZero] at successorZero
    exact separation successorZero.symm
  | inr recurrence =>
    rw [successorZero, seedZero] at recurrence
    exact separation (recurrence.trans (constantOne _))

theorem recoverOriginalTail
    (zero : A) (succ : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (constantOne : ∀ x, body oneIndex x = succ zero)
    (kernel : Kernel zero succ iter body oneIndex) :
    ∀ index n a,
      iter index (succ (succ n)) a = body index (iter index (succ n) a) := by
  have nonzero := successorNonzeroBeforeInduction zero succ iter body
    oneIndex constantOne kernel
  intro index n a
  cases kernel.2.2 index (succ n) a with
  | inl equalZero => exact False.elim (nonzero n equalZero)
  | inr recurrence => exact recurrence

theorem guardOriginalTail
    (zero : A) (succ pred : A → A) (iter : B → A → A → A)
    (body : B → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (tail : ∀ index n a,
      iter index (succ (succ n)) a = body index (iter index (succ n) a)) :
    ∀ index n a,
      n = zero ∨ iter index (succ n) a = body index (iter index n a) := by
  intro index n a
  cases coverage n with
  | inl equalZero => exact Or.inl equalZero
  | inr successor =>
    apply Or.inr
    rw [successor]
    exact tail index (pred n) a

theorem extractGuardedComputation
    (zero : A) (succ : A → A) (term : A → A) (reset tail : A → A → Prop)
    (schemaInstance : ∀ a,
      (∀ n, (n = zero ∨ term n = term n) → term (succ n) = term (succ n)) →
      ∀ n, (zero ≠ succ zero) ∧ reset n a ∧
        (n = zero ∨ (term n = term n ∧ tail n a))) :
    (zero ≠ succ zero) ∧ (∀ n a, reset n a) ∧
      (∀ n a, n = zero ∨ tail n a) := by
  have result := fun a => schemaInstance a (fun _ _ => rfl)
  constructor
  · exact (result zero zero).1
  constructor
  · intro n a
    exact (result a n).2.1
  · intro n a
    cases (result a n).2.2 with
    | inl equalZero => exact Or.inl equalZero
    | inr facts => exact Or.inr facts.2

theorem projectPropagation
    (zero : A) (succ : A → A) (term : A → A → A) (kernel : A → A → Prop)
    (tail : A → A → Prop)
    (schemaInstance : ∀ a,
      (∀ n, (n = zero ∨ term n a = term n (succ a)) →
        term (succ n) a = term (succ n) (succ a)) →
      ∀ n, kernel n a ∧ (n = zero ∨ (term n a = term n (succ a) ∧ tail n a))) :
    ∀ a, (∀ n, (n = zero ∨ term n a = term n (succ a)) →
      term (succ n) a = term (succ n) (succ a)) →
      ∀ n, n = zero ∨ term n a = term n (succ a) := by
  intro a progress n
  cases (schemaInstance a progress n).2 with
  | inl equalZero => exact Or.inl equalZero
  | inr facts => exact Or.inr facts.1

theorem mergeGuards
    (root equality tail : Prop)
    (rootedEquality : root ∨ equality) (rootedTail : root ∨ tail) :
    root ∨ (equality ∧ tail) := by
  cases rootedEquality with
  | inl rooted => exact Or.inl rooted
  | inr equal =>
    cases rootedTail with
    | inl rooted => exact Or.inl rooted
    | inr step => exact Or.inr ⟨equal, step⟩


/- The next declarations assemble the exact old and new envelopes. The type
   T indexes legal input terms; the type B indexes legal unary descriptors.
   The hypothesis `realizes` is supplied by the finite-syntax embedding
   u(n,a) := h(n). It does not postulate a universal object-language evaluator.
-/

def Progress (zero : A) (succ : A → A) (term : A → A → A) (a : A) : Prop :=
  ∀ n, (n = zero ∨ term n a = term n (succ a)) →
    term (succ n) a = term (succ n) (succ a)

def OldSchema {T : Type v}
    (zero : A) (succ : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (terms : T → A → A → A) (selected : T → B) : Prop :=
  ∀ term a, Progress zero succ (terms term) a → ∀ n,
    (n = zero ∨ terms term n a = terms term n (succ a)) ∧
    (zero ≠ succ zero) ∧
    iter (selected term) (iter oneIndex n zero) a = a ∧
    iter (selected term) (succ (succ n)) a =
      body (selected term) (iter (selected term) (succ n) a)

def NewSchema {T : Type v}
    (zero : A) (succ : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (terms : T → A → A → A) (selected : T → B) : Prop :=
  ∀ term a, Progress zero succ (terms term) a → ∀ n,
    (zero ≠ succ zero) ∧
    iter (selected term) (iter oneIndex n zero) a = a ∧
    (n = zero ∨ (terms term n a = terms term n (succ a) ∧
      iter (selected term) (succ n) a =
        body (selected term) (iter (selected term) n a)))

theorem newSchemaKernel {T : Type v}
    (zero : A) (succ : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (terms : T → A → A → A) (selected : T → B)
    (realizes : ∀ index, ∃ term, selected term = index ∧
      ∀ n a, terms term n a = body index n)
    (schema : NewSchema zero succ iter body oneIndex terms selected) :
    Kernel zero succ iter body oneIndex := by
  have extract : ∀ index n a,
      (zero ≠ succ zero) ∧ iter index (iter oneIndex n zero) a = a ∧
        (n = zero ∨ iter index (succ n) a = body index (iter index n a)) := by
    intro index n a
    obtain ⟨term, descriptor, evaluations⟩ := realizes index
    have progress : Progress zero succ (terms term) a := by
      intro k _
      rw [evaluations, evaluations]
    have result := schema term a progress n
    rw [descriptor] at result
    refine ⟨result.1, result.2.1, ?_⟩
    cases result.2.2 with
    | inl atZero => exact Or.inl atZero
    | inr facts => exact Or.inr facts.2
  refine ⟨(extract oneIndex zero zero).1, ?_, ?_⟩
  · intro index n a
    exact (extract index n a).2.1
  · intro index n a
    exact (extract index n a).2.2

theorem newToOld {T : Type v}
    (zero : A) (succ : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (terms : T → A → A → A) (selected : T → B)
    (constantOne : ∀ x, body oneIndex x = succ zero)
    (realizes : ∀ index, ∃ term, selected term = index ∧
      ∀ n a, terms term n a = body index n)
    (schema : NewSchema zero succ iter body oneIndex terms selected) :
    OldSchema zero succ iter body oneIndex terms selected := by
  have kernel := newSchemaKernel zero succ iter body oneIndex
    terms selected realizes schema
  have oldTail := recoverOriginalTail zero succ iter body oneIndex constantOne kernel
  intro term a progress n
  have result := schema term a progress n
  refine ⟨?_, result.1, result.2.1, oldTail (selected term) n a⟩
  cases result.2.2 with
  | inl atZero => exact Or.inl atZero
  | inr facts => exact Or.inr facts.1

theorem oldToNew {T : Type v}
    (zero : A) (succ pred : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (terms : T → A → A → A) (selected : T → B)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (schema : OldSchema zero succ iter body oneIndex terms selected) :
    NewSchema zero succ iter body oneIndex terms selected := by
  intro term a progress n
  have result := schema term a progress n
  refine ⟨result.2.1, result.2.2.1, ?_⟩
  have guarded : n = zero ∨
      iter (selected term) (succ n) a =
        body (selected term) (iter (selected term) n a) := by
    cases coverage n with
    | inl atZero => exact Or.inl atZero
    | inr atSucc =>
      apply Or.inr
      rw [atSucc]
      exact (schema term a progress (pred n)).2.2.2
  exact mergeGuards _ _ _ result.1 guarded

theorem schemaEquivalence {T : Type v}
    (zero : A) (succ pred : A → A) (iter : B → A → A → A)
    (body : B → A → A) (oneIndex : B)
    (terms : T → A → A → A) (selected : T → B)
    (constantOne : ∀ x, body oneIndex x = succ zero)
    (realizes : ∀ index, ∃ term, selected term = index ∧
      ∀ n a, terms term n a = body index n)
    (coverageFromOld : OldSchema zero succ iter body oneIndex terms selected →
      ∀ n, n = zero ∨ n = succ (pred n)) :
    OldSchema zero succ iter body oneIndex terms selected ↔
      NewSchema zero succ iter body oneIndex terms selected := by
  constructor
  · intro old
    exact oldToNew zero succ pred iter body oneIndex terms selected
      (coverageFromOld old) old
  · intro new
    exact newToOld zero succ iter body oneIndex terms selected constantOne realizes new

#print axioms guardedSeeds
#print axioms successorNonzeroBeforeInduction
#print axioms recoverOriginalTail
#print axioms guardOriginalTail
#print axioms extractGuardedComputation
#print axioms projectPropagation
#print axioms mergeGuards

#print axioms newSchemaKernel
#print axioms newToOld
#print axioms oldToNew
#print axioms schemaEquivalence

end GuardedTail
