#!/usr/bin/env python3
"""Rerun the syntax checks and rebuild the paper; optionally check Lean."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def run(command: list[str], cwd: Path) -> str:
    result = subprocess.run(command, cwd=cwd, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        print(result.stdout, file=sys.stderr)
        raise SystemExit(result.returncode)
    return result.stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', help='Path to a Lean executable (4.19.0 recorded)')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    print(run([sys.executable, str(root / 'checks' / 'check_schema.py')], root), end='')
    if args.lean:
        lean = str(Path(args.lean).resolve()) if '/' in args.lean else args.lean
        version = run([lean, '--version'], root).strip()
        log = run([lean, 'GuardedTail.lean'], root / 'formal')
        (root / 'formal' / 'lean-check.log').write_text(log)
        lines = [line for line in log.splitlines() if line.startswith("'GuardedTail.")]
        if len(lines) != 11 or any(
                not line.endswith('does not depend on any axioms') for line in lines):
            raise RuntimeError('Unexpected Lean axiom-dependency output')
        (root / 'formal' / 'verification.json').write_text(json.dumps({
            'command': ['lean', 'GuardedTail.lean'], 'toolchain': version,
            'exit_code': 0, 'audited_theorems': len(lines),
            'axiom_dependency_lists_empty': True,
        }, indent=2) + '\n')
        print(version)
        print('Lean: all 11 theorem dependency lists are empty.')
    tex = shutil.which('pdflatex')
    if tex is None:
        raise SystemExit('pdflatex was not found; the syntax checks completed.')
    temporary = root / '.build'
    temporary.mkdir(exist_ok=True)
    command = [tex, '-interaction=nonstopmode', '-halt-on-error',
               '-file-line-error', '-output-directory', str(temporary), 'report.tex']
    outputs = [run(command, root) for _ in range(2)]
    shutil.copyfile(temporary / 'report.pdf', root / 'report.pdf')
    (root / 'audit' / 'latex-build.log').write_text('\n'.join(outputs))
    print('Built report.pdf (two pdfLaTeX passes).')


if __name__ == '__main__':
    main()
