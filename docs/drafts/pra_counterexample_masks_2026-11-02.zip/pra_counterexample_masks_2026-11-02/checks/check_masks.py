#!/usr/bin/env python3
"""Independent finite checks for the counterexample-mask presentation of PRA.

This file counts actual frozen-descriptor syntax trees, not hand-entered
formula lengths. It also tests the reverse witness construction on every
Boolean mask of several finite initial segments, and checks the local
forward kernel and both truth compilers. These finite tests are supporting
evidence; the manuscript supplies the unbounded mathematical proofs.

Run from any directory: python3 checks/check_masks.py
The sole generated file is ../verification/sizes.json.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from pathlib import Path
import json
import random


@dataclass(frozen=True)
class Node:
    kind: str
    name: str = ""
    args: tuple["Node", ...] = ()
    descriptor: "Node | None" = None


def var(name):
    return Node("var", name)


ZERO = Node("constant", "0")


def app(name, *args, descriptor=None):
    return Node("application", name, tuple(args), descriptor)


def succ(x):
    return app("S", x)


ONE = succ(ZERO)
v, w, a, n, b, c = map(var, ("v", "w", "a", "n", "b", "c"))


def chi(x, y):
    return app("chi", x, y)


def q(x, y):
    return app("Q", x, y, descriptor=w)


def z(x, y):
    return app("Z", x, y, descriptor=ZERO)


def rec(h, x, y):
    return app("R", x, y, descriptor=h)


def mask(t, x, y):
    return app("C", x, y, descriptor=t)


def eq(x, y):
    return Node("equality", "=", (x, y))


def conjunction(x, y):
    return Node("and", "and", (x, y))


def implication(x, y):
    return Node("implies", "implies", (x, y))


def forall(name, x):
    return Node("forall", name, (x,))


def exists(name, x):
    return Node("exists", name, (x,))


def all_an(x):
    return forall("a", forall("n", x))


def size(x, full=False):
    total = 1 + sum(size(y, full) for y in x.args)
    if full and x.descriptor is not None:
        total += size(x.descriptor, True)
    return total


def sizes(x):
    return size(x), size(x, True)


def occurrences(x, name):
    # Frozen descriptors do not have active free-variable occurrences.
    return int(x.kind == "var" and x.name == name) + sum(
        occurrences(y, name) for y in x.args
    )


def substitute(x, mapping):
    """Simultaneous substitution of active term slots; indices stay frozen."""
    if x.kind == "var":
        return mapping.get(x.name, x)
    return Node(x.kind, x.name,
                tuple(substitute(y, mapping) for y in x.args), x.descriptor)


def definition(t):
    return all_an(eq(mask(t, n, a), z(t, n)))


def witness13(t):
    return all_an(exists("b", eq(mask(t, q(mask(t, succ(b), a), n), a), ZERO)))


def witness12(t):
    return all_an(exists("b", eq(mask(t, q(mask(t, b, a), n), a), ZERO)))


def base(h):
    return forall("a", eq(rec(h, ZERO, a), a))


def normal_step(h):
    return all_an(eq(rec(h, succ(n), a),
                     substitute(h, {"v": rec(h, n, a), "w": n})))


def bound_step(h):
    return all_an(forall("c", implication(eq(rec(h, n, a), c),
        eq(rec(h, succ(n), a), substitute(h, {"v": c, "w": n})))))


def computation_B(h):
    return all_an(conjunction(eq(rec(h, ZERO, a), a),
        eq(rec(h, succ(n), a), substitute(h, {"v": rec(h, n, a), "w": n}))))


def computation_E(h):
    return all_an(conjunction(eq(rec(h, ZERO, a), a),
        forall("c", implication(eq(rec(h, n, a), c),
            eq(rec(h, succ(n), a), substitute(h, {"v": c, "w": n}))))))


def computation_D(h):
    assert occurrences(h, "w") == 0
    return all_an(conjunction(eq(rec(h, ZERO, a), a),
        eq(rec(h, succ(n), a),
           rec(h, n, substitute(h, {"v": a, "w": ZERO})))))


def old_witness14(h):
    return all_an(exists("b", eq(rec(h, q(z(rec(h, b, a), b), n), a), a)))


def old_latch(payload):
    return z(substitute(payload, {"n": w, "a": q(v, ZERO)}), v)


def selector(r, x, y):
    # Zero selects x; a successor selects y.
    return q(z(r, succ(x)), y)


BOTTOM = Node("false", "false")


def connective(kind, left, right):
    return Node(kind, kind, (left, right))


def truth_one(formula):
    k = formula.kind
    if k == "equality":
        return chi(*formula.args)
    if k == "false":
        return ZERO
    left, right = map(truth_one, formula.args)
    if k == "and":
        return selector(left, ZERO, right)
    if k == "or":
        return selector(left, right, ONE)
    if k == "implies":
        return selector(left, ONE, right)
    raise ValueError(k)


def truth_zero(formula):
    k = formula.kind
    if k == "equality":
        return z(chi(*formula.args), ONE)
    if k == "false":
        return ONE
    left, right = map(truth_zero, formula.args)
    if k == "and":
        return selector(left, right, ONE)
    if k == "or":
        return selector(left, ZERO, right)
    if k == "implies":
        return selector(left, right, ZERO)
    raise ValueError(k)


def logical_count(formula, kind):
    if formula.kind in ("false", "equality"):
        return int(formula.kind == kind)
    return int(formula.kind == kind) + sum(logical_count(x, kind) for x in formula.args)


def eval_term(t, env):
    if t.kind == "var":
        return env[t.name]
    if t.kind == "constant":
        return 0
    values = [eval_term(x, env) for x in t.args]
    if t.name == "S":
        return values[0] + 1
    if t.name == "chi":
        return int(values[0] == values[1])
    if t.name == "Q":
        return values[1] if values[0] == 0 else values[0] - 1
    if t.name == "Z":
        return values[1] if values[0] == 0 else 0
    raise ValueError(t.name)


def eval_formula(f, env):
    if f.kind == "false":
        return False
    if f.kind == "equality":
        return eval_term(f.args[0], env) == eval_term(f.args[1], env)
    left, right = [eval_formula(x, env) for x in f.args]
    if f.kind == "and":
        return left and right
    if f.kind == "or":
        return left or right
    if f.kind == "implies":
        return not left or right
    raise ValueError(f.kind)


def generated_payloads():
    rng = random.Random(20261102)
    seeds = [ZERO, n, a, ONE, chi(n, a), q(succ(n), a), z(n, a),
             rec(succ(v), n, a), rec(z(chi(v, w), v), a, n),
             mask(chi(n, a), a, n)]
    answer = list(seeds)
    for _ in range(700):
        x, y = rng.choice(answer[-100:]), rng.choice(answer[-100:])
        if size(x, True) + size(y, True) > 300:
            x, y = rng.choice(seeds), rng.choice(seeds)
        op = rng.randrange(5)
        if op == 0:
            t = succ(x)
        elif op == 1:
            t = chi(x, y)
        elif op == 2:
            t = q(x, y)
        elif op == 3:
            t = z(x, y)
        else:
            h = substitute(rng.choice(seeds), {"n": v, "a": w})
            t = rec(h, x, y)
        answer.append(t)
    return answer


def check_trees():
    examples = []
    min_saving = [10**9, 10**9]
    source = generated_payloads()
    for index, t in enumerate(source):
        m, W = sizes(t)
        j = occurrences(t, "a")
        i = occurrences(t, "n")
        assert sizes(definition(t)) == (8 + m, 9 + 2 * W)
        assert sizes(witness13(t)) == (13, 14 + 2 * W)
        assert sizes(witness12(t)) == (12, 13 + 2 * W)

        # Match an arbitrary old zero-for-true payload exactly: chi(t,0)
        # is a one-for-true mask payload. Its entire cost is charged.
        converted = chi(t, ZERO)
        new = tuple(x + y for x, y in zip(sizes(definition(converted)),
                                         sizes(witness13(converted))))
        assert new == (23 + m, 31 + 4 * W)

        h = old_latch(t)
        mh, Wh = sizes(h)
        s = occurrences(h, "v")
        assert mh == m + 2 * j + 2
        assert Wh == W + 3 * j + 3
        assert s == j + 1
        assert sizes(base(h)) == (6, 6 + Wh)
        assert sizes(normal_step(h)) == (7 + mh + 2 * s,
                                          7 + 2 * s + (2 + s) * Wh)
        assert sizes(bound_step(h)) == (14 + mh, 14 + 3 * Wh)
        assert sizes(computation_B(h)) == (13 + mh + 2 * s,
                                             13 + 2 * s + (3 + s) * Wh)
        assert sizes(computation_E(h)) == (20 + mh, 20 + 4 * Wh)
        assert sizes(old_witness14(h)) == (14, 16 + 2 * Wh)
        computations = [sizes(computation_B(h)), sizes(computation_E(h))]
        if i == 0:
            assert sizes(computation_D(h)) == (15 + mh, 15 + 4 * Wh)
            computations.append(sizes(computation_D(h)))
        old = tuple(min(x[k] for x in computations) + sizes(old_witness14(h))[k]
                    for k in (0, 1))
        expected_active = 29 + mh if i == 0 else 27 + mh + min(2 * s, 7)
        expected_full = (31 if i == 0 or j == 0 else 36) + 6 * Wh
        assert old == (expected_active, expected_full)
        assert old[0] >= 31 + m + 2 * j
        assert old[1] >= 49 + 6 * W + 18 * j
        savings = (old[0] - new[0], old[1] - new[1])
        assert savings[0] >= 8 + 2 * j
        assert savings[1] >= 18 + 2 * W + 18 * j
        min_saving = [min(x, y) for x, y in zip(min_saving, savings)]
        if index < 10:
            examples.append({"index": index, "payload_active": m,
                "payload_full": W, "counter_occurrences": i,
                "parameter_occurrences": j, "new_module": new,
                "optimistic_old_module": old, "savings": savings})

    # This catches accidental substitution into a frozen descriptor, even
    # though its printed variable names coincide with active names.
    frozen = rec(chi(v, w), n, a)
    replaced = substitute(frozen, {"n": ZERO, "a": ONE, "v": ONE, "w": ZERO})
    assert replaced.descriptor is frozen.descriptor
    assert replaced.args == (ZERO, ONE)
    return {"payloads_checked": len(source), "minimum_observed_module_savings": min_saving,
            "frozen_substitution_checked": True, "examples": examples}


def check_reverse_witnesses():
    arrays = targets = witnesses = 0
    for N in range(13):
        for bits in product((0, 1), repeat=N + 1):
            # F(0)=0 and F(k) is either 0 or k, as proved in PRA.
            F = [0] + [0 if good else k for k, good in enumerate(bits, 1)]
            arrays += 1
            candidate = 0
            for target in range(N + 1):
                b0 = candidate
                assert F[b0] == 0
                assert F[b0 + 1] != 0 or b0 == target
                selected = target if F[b0 + 1] == 0 else F[b0 + 1] - 1
                assert F[selected] == 0
                targets += 1
                # Enumerate all witnesses, not only the constructed one;
                # each is a target success or an actual success-to-failure boundary.
                for chosen in range(N + 1):
                    selected = target if F[chosen + 1] == 0 else F[chosen + 1] - 1
                    if F[selected] == 0:
                        witnesses += 1
                        assert F[target] == 0 or (F[chosen] == 0 and F[chosen + 1] != 0)
                if target < N and F[candidate + 1] == 0:
                    candidate = target + 1
    return {"maximum_target": 12, "arrays_checked": arrays,
            "constructed_witnesses_checked": targets,
            "all_successful_witnesses_classified": witnesses}


def check_forward_local_kernel():
    tested = successful = 0
    for values in product((False, True), repeat=6):
        if not values[0]:
            continue
        for target in range(5):
            for chosen in range(5):
                # Only the local progress instance at this chosen witness
                # is needed, together with the induction base.
                if values[chosen] and not values[chosen + 1]:
                    continue
                F = lambda x: 0 if values[x] else x
                inner = F(chosen + 1)
                selected = target if inner == 0 else inner - 1
                tested += 1
                if F(selected) == 0:
                    successful += 1
                    assert values[target]
    return {"base_and_local_progress_configurations": tested,
            "successful_witness_implications_checked": successful}


def check_truth_compilers():
    rng = random.Random(21413)
    seeds = [eq(n, a), eq(n, ZERO), eq(succ(n), a), BOTTOM]
    formulas = list(seeds)
    for _ in range(600):
        left, right = rng.choice(formulas[-80:]), rng.choice(formulas[-80:])
        if size(left) + size(right) > 100:
            left, right = rng.choice(seeds), rng.choice(seeds)
        formulas.append(connective(rng.choice(("and", "or", "implies")), left, right))
    semantic_cases = 0
    for f in formulas:
        positive, negative = truth_one(f), truth_zero(f)
        e, k = logical_count(f, "equality"), logical_count(f, "and")
        assert size(negative) - size(positive) == 2 * e + 2 * k + 1
        assert size(negative, True) - size(positive, True) == 3 * e + 2 * k + 1
        for x, y in product(range(4), repeat=2):
            env = {"n": x, "a": y}
            truth = eval_formula(f, env)
            assert eval_term(positive, env) == int(truth)
            assert eval_term(negative, env) == int(not truth)
            semantic_cases += 1
    return {"formulas_checked": len(formulas), "semantic_cases_checked": semantic_cases,
        "active_savings_identity": "2*equality_leaves + 2*conjunctions + 1",
        "full_savings_identity": "3*equality_leaves + 2*conjunctions + 1"}


def main():
    result = {"status": "passed", "scope":
        "Actual finite AST counts and finite witness/compiler tests; not a formal proof of bi-interpretability.",
        "syntax": check_trees(), "reverse_witnesses": check_reverse_witnesses(),
        "forward_local_kernel": check_forward_local_kernel(),
        "truth_compilers": check_truth_compilers()}
    destination = Path(__file__).resolve().parent.parent / "verification" / "sizes.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "syntax"}, indent=2))
    print("AST payloads checked:", result["syntax"]["payloads_checked"])
    print("Results:", destination)


if __name__ == "__main__":
    main()
