PRA FROM COUNTEREXAMPLE MASKS
2 November 2026

MAIN FILES
  report.pdf                 Complete research report.
  report.tex, sections/      Editable LaTeX source.
  AXIOMS.txt                 Exact standalone theory specification.
  formal/CounterexampleMasks.lean
                             Verified core forward and reverse arguments.
  checks/check_masks.py      Frozen-descriptor AST and finite witness checks.
  verification/             Results, mathematical audit, build and QA records.
  provenance/source_manifest.json
                             Pinned source archives and verified hashes.

MAIN RESULT
Retain 0,S,chi and ordinary binary seeded recursors R_h.
Let Q=R_w and Z=R_0. For every earlier two-slot term t, define

  C_t(x,a)=Z(t(x,a),x)

and require

  forall a forall n exists b,
    C_t(Q(C_t(S(b),a),n),a)=0.

With separation, the exact equality-bit seed, and ordinary recursion,
this theory is bi-interpretable with first-order PRA. Both interpretation
domains and both round-trip isomorphisms are identities. The construction
works separately with classical and intuitionistic first-order logic.

WHY IT IS SMALLER
The old induction latch is replaced by a direct counterexample mask.
The witness has 13 active nodes. Including the entire mask definition
and all repeated frozen descriptors, its auxiliary induction module costs
21+m active and 23+4T full nodes. The inspected six archived uniform
recipes have a favorable lower envelope at least 32+m and 55+6T under
the same formula workload. See report Section 6 for precise definitions,
proofs, the optional one-call comparisons, and limitations.

The result is not an encoding-independent shortestness theorem.
It does not claim every old raw-input emitter row shrinks, or that all
unused recursive latch symbols disappear from the infinite language.

REPRODUCTION
From this directory:
  python3 checks/check_masks.py
  lean formal/CounterexampleMasks.lean
  python3 build.py

The Lean source was verified with Lean 4.19.0 and bundled Std.
The LaTeX build needs pdflatex and ordinary TeX Live packages.
The Python checker uses only the Python standard library.
The original draft archives and compiler binaries are not bundled.

FORMAL VERIFICATION LIMITS
The nine printed Lean dependency checks report no axioms. There are no
admitted proofs. The forward proof uses an arbitrary carrier and no
coverage assumption. The reverse Nat proof supplies a primitive-recursive
boundary algorithm and its quantifier-free invariant.
The generated syntax, truth compiler, pairing, all-PR compiler, and full
bi-interpretation theorem remain written proofs. See formal/SCOPE.txt.

SOURCE SNAPSHOT
VladimirReshetnikov/ProveIt
41ead086f47172a707910a072eb1a722a17a85ca
docs/drafts: all six ZIP files present in that snapshot.
The archive Git blob hashes were independently verified after download.

The report includes a Further research questions section.
