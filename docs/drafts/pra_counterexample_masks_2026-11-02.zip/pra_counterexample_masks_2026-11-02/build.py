#!/usr/bin/env python3
"""Compile the self-contained manuscript. Requires pdflatex."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    compiler = shutil.which("pdflatex")
    if compiler is None:
        raise SystemExit("pdflatex is required; install a standard TeX Live distribution.")
    verification = ROOT / "verification"
    verification.mkdir(exist_ok=True)
    results = []
    for number in range(1, 4):
        proc = subprocess.run(
            [compiler, "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "report.tex"],
            cwd=ROOT, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, check=False,
        )
        (verification / f"latex_pass_{number}.txt").write_text(proc.stdout)
        results.append({"pass": number, "exit_code": proc.returncode})
        if proc.returncode:
            print(proc.stdout[-9000:])
            raise SystemExit(proc.returncode)
    log = (ROOT / "report.log").read_text(errors="replace")
    issues = [line for line in log.splitlines()
              if "Overfull" in line or "undefined" in line.lower()
              or "multiply defined" in line.lower()]
    record = {
        "status": "passed" if not issues else "needs_review",
        "passes": results,
        "compiler": subprocess.run(
            [compiler, "--version"], text=True, stdout=subprocess.PIPE,
            check=True).stdout.splitlines()[0],
        "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
        "layout_or_reference_issues": issues,
    }
    (verification / "build.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))
    return 0 if not issues else 2


if __name__ == "__main__":
    sys.exit(main())
