import Std

/-!
# Counterexample masks: arbitrary-carrier induction kernel

The forward transfer uses an arbitrary carrier, successor, Q, Z and the
fixed equality-bit seed. No carrier induction, coverage assumption,
excluded-middle axiom or choice principle occurs in that proof.

The reverse direction constructs a primitive-recursive boundary witness on
Nat. Its displayed invariant is quantifier-free once C is a fixed arithmetic
function symbol. The higher-order variables here are metatheoretic parameters;
the proposed first-order axiom scheme does not quantify over functions.

This checks the local mathematical kernels, not the generated language,
truth-term compiler, pairing development, or complete bi-interpretation.
-/

namespace CounterexampleMasks

universe u

/-- The computational seed, without a zero-or-successor coverage field. -/
structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  Q : A → A → A
  Z : A → A → A
  chi : A → A → A
  separated : zero ≠ succ zero
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ n a, Q (succ n) a = n
  z_zero : ∀ a, Z zero a = a
  z_succ : ∀ n a, Z (succ n) a = zero
  chi_diag : ∀ a, chi a a = succ zero
  chi_cases : ∀ a b, a = b ∨ chi a b = zero

namespace Kernel

variable {A : Type u} (K : Kernel A)

theorem succ_injective (x y : A) (h : K.succ x = K.succ y) : x = y := by
  have he := congrArg (fun z => K.Q z K.zero) h
  simpa only [K.q_succ] using he

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro h
  have hx : x = K.zero := by
    have he := congrArg (fun z => K.Q z K.zero) h
    simpa only [K.q_succ, K.q_zero] using he
  exact K.separated (h.symm.trans (congrArg K.succ hx))

include K in
/-- Decidability is extracted constructively from the fixed equality bit. -/
theorem eq_or_ne (x y : A) : x = y ∨ x ≠ y := by
  rcases K.chi_cases x y with he | hc
  · exact Or.inl he
  · refine Or.inr ?_
    intro he
    subst x
    exact K.separated (hc.symm.trans (K.chi_diag y))

theorem chi_of_eq (x y : A) (h : x = y) :
    K.chi x y = K.succ K.zero := by
  subst x
  exact K.chi_diag y

theorem chi_of_ne (x y : A) (h : x ≠ y) : K.chi x y = K.zero := by
  rcases K.chi_cases x y with he | hc
  · exact False.elim (h he)
  · exact hc

/-- A direct mask; its descriptor is t, not a recursively accumulated latch. -/
def mask (t : A → A) (x : A) : A := K.Z (t x) x

theorem mask_of_true {P : A → Prop} {e : A → A}
    (htrue : ∀ x, P x → e x = K.succ K.zero) (x : A) (h : P x) :
    K.mask e x = K.zero := by
  unfold mask
  rw [htrue x h, K.z_succ]

theorem mask_of_false {P : A → Prop} {e : A → A}
    (hfalse : ∀ x, ¬P x → e x = K.zero) (x : A) (h : ¬P x) :
    K.mask e x = x := by
  unfold mask
  rw [hfalse x h, K.z_zero]

/-- Under the induction base, a zero mask reflects the predicate everywhere.
This proof does not inspect whether x is zero or a successor. -/
theorem reflect_zero {P : A → Prop} {F : A → A}
    (pdec : ∀ x, P x ∨ ¬P x)
    (hfalse : ∀ x, ¬P x → F x = x)
    (hbase : P K.zero) (x : A) (hx : F x = K.zero) : P x := by
  rcases pdec x with hp | hn
  · exact hp
  · have he : x = K.zero := (hfalse x hn).symm.trans hx
    exact he.symm ▸ hbase

/-- The shifted witness is exactly the 13-active-node axiom after fixing a.
The proof uses no coverage axiom and no induction on the carrier. -/
theorem induction_transfer {P : A → Prop} {F : A → A}
    (pdec : ∀ x, P x ∨ ¬P x)
    (htrue : ∀ x, P x → F x = K.zero)
    (hfalse : ∀ x, ¬P x → F x = x)
    (hw : ∀ n, ∃ b, F (K.Q (F (K.succ b)) n) = K.zero)
    (hbase : P K.zero)
    (hstep : ∀ x, P x → P (K.succ x)) : ∀ n, P n := by
  intro n
  obtain ⟨b, hb⟩ := hw n
  rcases pdec (K.succ b) with hp | hn
  · rw [htrue (K.succ b) hp, K.q_zero] at hb
    exact K.reflect_zero pdec hfalse hbase n hb
  · rw [hfalse (K.succ b) hn, K.q_succ] at hb
    have hpb : P b := K.reflect_zero pdec hfalse hbase b hb
    exact False.elim (hn (hstep b hpb))

/-- Specialization to masks of one-for-true truth terms. -/
theorem masked_induction {P : A → Prop} {e : A → A}
    (pdec : ∀ x, P x ∨ ¬P x)
    (htrue : ∀ x, P x → e x = K.succ K.zero)
    (hfalse : ∀ x, ¬P x → e x = K.zero)
    (hw : ∀ n, ∃ b,
      K.mask e (K.Q (K.mask e (K.succ b)) n) = K.zero)
    (hbase : P K.zero)
    (hstep : ∀ x, P x → P (K.succ x)) : ∀ n, P n := by
  apply K.induction_transfer pdec (K.mask_of_true htrue) (K.mask_of_false hfalse)
  · exact hw
  · exact hbase
  · exact hstep

end Kernel

namespace NatWitness

/-- Q(0,n)=n and Q(Sb,n)=b. -/
def selector : Nat → Nat → Nat
  | 0, n => n
  | Nat.succ b, _ => b

/-- Primitive recursion with one state and the fixed numerical parameters of C.
It advances until the next mask is nonzero, then retains that boundary. -/
def boundary (C : Nat → Nat) : Nat → Nat
  | 0 => 0
  | Nat.succ n =>
      if C (Nat.succ (boundary C n)) = 0 then Nat.succ n else boundary C n

/-- The exact quantifier-free invariant used for PRA soundness. -/
theorem boundary_invariant (C : Nat → Nat) (hzero : C 0 = 0) (n : Nat) :
    C (boundary C n) = 0 ∧
      (C (Nat.succ (boundary C n)) = 0 → boundary C n = n) := by
  induction n with
  | zero =>
      constructor
      · exact hzero
      · intro _
        rfl
  | succ n ih =>
      by_cases h : C (Nat.succ (boundary C n)) = 0
      · have he : boundary C n = n := ih.2 h
        constructor
        · have hn : C (Nat.succ n) = 0 := by
            simpa only [he] using h
          simpa only [boundary, if_pos h] using hn
        · rw [boundary, if_pos h]
          intro _
          rfl
      · constructor
        · simpa only [boundary, if_neg h] using ih.1
        · intro hh
          have hf : C (Nat.succ (boundary C n)) = 0 := by
            simpa only [boundary, if_neg h] using hh
          exact False.elim (h hf)

/-- The invariant supplies a witness; the only range fact needed is at successors. -/
theorem boundary_is_witness (C : Nat → Nat) (hzero : C 0 = 0)
    (hmarker : ∀ b, C (Nat.succ b) = 0 ∨ C (Nat.succ b) = Nat.succ b)
    (n : Nat) :
    C (selector (C (Nat.succ (boundary C n))) n) = 0 := by
  have hi := boundary_invariant C hzero n
  rcases hmarker (boundary C n) with hz | hs
  · rw [hz, selector]
    have he := hi.2 hz
    simpa only [he] using hi.1
  · rw [hs, selector]
    exact hi.1

theorem shifted_witness (C : Nat → Nat) (hzero : C 0 = 0)
    (hmarker : ∀ b, C (Nat.succ b) = 0 ∨ C (Nat.succ b) = Nat.succ b)
    (n : Nat) : ∃ b, C (selector (C (Nat.succ b)) n) = 0 := by
  exact ⟨boundary C n, boundary_is_witness C hzero hmarker n⟩

/-- The interpretation of Z(t(x),x) in ordinary natural-number arithmetic. -/
def mask (t : Nat → Nat) (x : Nat) : Nat := if t x = 0 then x else 0

theorem mask_zero (t : Nat → Nat) : mask t 0 = 0 := by
  unfold mask
  split <;> rfl

theorem mask_marker (t : Nat → Nat) (b : Nat) :
    mask t (Nat.succ b) = 0 ∨ mask t (Nat.succ b) = Nat.succ b := by
  by_cases h : t (Nat.succ b) = 0
  · exact Or.inr (by unfold mask; rw [if_pos h])
  · exact Or.inl (by unfold mask; rw [if_neg h])

/-- Every individual mask has the required explicit primitive-recursive witness. -/
theorem every_mask_has_shifted_witness (t : Nat → Nat) (n : Nat) :
    ∃ b, mask t (selector (mask t (Nat.succ b)) n) = 0 := by
  exact shifted_witness (mask t) (mask_zero t) (mask_marker t) n

end NatWitness

#print axioms Kernel.succ_injective
#print axioms Kernel.succ_ne_zero
#print axioms Kernel.eq_or_ne
#print axioms Kernel.reflect_zero
#print axioms Kernel.induction_transfer
#print axioms Kernel.masked_induction
#print axioms NatWitness.boundary_invariant
#print axioms NatWitness.boundary_is_witness
#print axioms NatWitness.every_mask_has_shifted_witness

end CounterexampleMasks
