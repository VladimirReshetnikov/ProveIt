# Five-type obstructions and a four-omission theorem

Research note, 25 November 2026. Start with **paper.pdf** (8 pages), which contains the complete mathematical proofs. `paper.tex` is its self-contained source.

## Main results

* Exact robust-pair test for two inclusion-minimal missing-generator types intersecting in at most three labels: inspect at most three auxiliary types at a time. This gives a cubic decision algorithm and answers the overlap-three portion of a research question in the supplied dense-core draft. An explicit 17-member example proves that three auxiliaries are necessary in general.
* General compression to meet-irreducible trace generators, plus a construction giving a lower bound of t auxiliaries at any overlap t >= 2. At overlap four the resulting bounds are four and seven; the exact optimum remains open.
* Exact triple-intersection obstruction when a minimum type has size four and all minimal types pairwise intersect in at least three labels. A higher-order condition gives a robust pair for larger minimum omission sizes.
* Infinite nontrivial cores with arbitrarily large minimum nonempty member size, no private generators, and arbitrarily many members; the robust pair transfers to distinguishable translates, including arbitrarily many additional private generators.

This is a restricted-case result, not a proof of the unrestricted conjecture or an improvement of the unrestricted universal numerical constant. Historical novelty is provisional. The exact proofs are elementary and do not rely on the finite audit; the numerical value b(4)=7 is a separate exhaustive computation. The archive has not been independently refereed or formalized in a proof assistant.

## Reproduce

Requires Python 3.10+ (standard library only; assertions enabled) and ordinary TeX Live with AMS, Latin Modern, microtype, xcolor and hyperref.

```sh
python3 verify.py > verification-new.json
diff -u verification.json verification-new.json
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

`verify.py` exports `marked_pair_obstruction(T,S,aux,K)`. Represent a label set by its nonnegative integer bitmask. `K` is the full mask; each type is a proper subset, `T,S` are distinct inclusion-minimal types, and their intersection has at most three labels. `aux` contains all other distinct original types. A return of `None` certifies the pair in every translate. A returned tuple is a bad subcollection, not a counterexample to Frankl's conjecture. `cq` returns the two exact integer counts from the proof.

## Contents

- `paper.tex`, `paper.pdf`: the manuscript.
- `verify.py`, `verification.json`: executable checks and actual output.
- `provenance.md`: repository and literature audit, scope limitations.
- `Makefile`: rebuild and check.
- `SHA256SUMS`: integrity manifest of the packaged originals.

No changes were made to the GitHub repository. A PDF rebuilt locally may differ in metadata and therefore SHA-256; run `sha256sum -c SHA256SUMS` before rebuilding to check the archive as delivered.
