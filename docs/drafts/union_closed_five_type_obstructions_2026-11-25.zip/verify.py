#!/usr/bin/env python3
"""Exact finite audits and practical marked-pair test. Python 3.10+, no deps."""
from itertools import combinations
from collections import Counter
import json, random


def sublists(xs, limit=None):
    for k in range((len(xs) if limit is None else min(len(xs), limit))+1):
        yield from combinations(xs,k)


def closure(types, top):
    out={top}
    for a in types:
        out |= {a & b for b in out}
    return out


def irreducibles(C,top):
    ans=[]
    for a in C-{top}:
        meet=top
        for b in C:
            if a!=b and a & b == a: meet &= b
        if meet!=a: ans.append(a)
    return sorted(ans)


def cq(T,S,aux,K):
    R=T&S
    c=len(closure([a&R for a in aux],R))
    q=sum(bool(a&~T) and bool(a&~S) for a in closure(aux,K))
    return c,q


def bad(T,S,aux,K):
    c,q=cq(T,S,aux,K)
    return c>q


def marked_pair_obstruction(T,S,aux,K):
    """Returns an obstruction, or None if the pair is robust, for |T&S|<=3.
    Assumes distinct proper types and T,S inclusion-minimal in whole system.
    """
    assert (T&S).bit_count()<=3
    assert T!=S and T!=K and S!=K and T&S!=T and T&S!=S
    assert len(set(aux))==len(aux)
    assert all(a not in (T,S,K) and a&T!=a and a&S!=a for a in aux)
    for xs in sublists(aux,3):
        if bad(T,S,xs,K): return xs
    return None


def all_unions(types,K):
    """Independent construction of original generators and their distinct unions."""
    G=[sum(1<<j for j,a in enumerate(types) if not(a>>i&1)) for i in range(K.bit_length()) if K>>i&1]
    F={0}
    for g in G: F|={a|g for a in F}
    return F,G


def check_direct(T,S,aux,K):
    types=[T,S,*aux]; F,_=all_unions(types,K); C=closure(types,K)
    assert len(F)==len(C)
    for j,a in enumerate(types):
        assert sum(not(x>>j&1) for x in F)==sum(d&a==d for d in C)
    c,q=cq(T,S,aux,K)
    assert c==sum(x&3==0 for x in F) and q==sum(x&3==3 for x in F)


def trace_audit():
    rows=[]
    for t in range(1,5):
        R=(1<<t)-1; seen=set(); hist=Counter(); rank4=[]
        for mask in range(1<<R):
            C=frozenset(closure([a for a in range(R) if mask>>a&1],R))
            if C in seen: continue
            seen.add(C); M=irreducibles(C,R)
            assert closure(M,R)==C
            hist[len(M)]+=1
            if t==3 and len(M)==4:
                pairs=[x for x in M if x.bit_count()==2]
                assert len(pairs) in (1,2)
                assert len(C)==5+len(pairs)
                rank4.append(M)
        rows.append({'t':t,'closures':len(seen),'rank_histogram':dict(sorted(hist.items())),'maximum':max(hist),'rank_four_trace_lists':rank4})
    assert [r['maximum'] for r in rows]==[1,2,4,7]
    return rows


def small_and_random():
    rng=random.Random(20261125); result=Counter()
    for t in (2,3):
        R=(1<<t)-1;T=R|1<<t;S=R|1<<(t+1);K=(1<<(t+2))-1
        pool=[a for a in range(K) if a&T!=a and a&S!=a and a&T!=T and a&S!=S]
        for aux in sublists(pool):
            check_direct(T,S,aux,K)
            ref=any(bad(T,S,x,K) for x in sublists(aux))
            assert ref==(marked_pair_obstruction(T,S,aux,K) is not None)
            result['exhaustive_type_systems']+=1
    for _ in range(2200):
        t=rng.choice([2,3]);R=(1<<t)-1;T=R|1<<t;S=R|1<<(t+1)
        K=(1<<(t+2+rng.randrange(1,6)))-1
        pool=[a for a in range(K) if a&T!=a and a&S!=a and a&T!=T and a&S!=S]
        aux=rng.sample(pool,rng.randrange(min(len(pool),10)+1))
        ref=any(bad(T,S,x,K) for x in sublists(aux))
        assert ref==(marked_pair_obstruction(T,S,aux,K) is not None)
        # A separate verification of the trace-irreducible compression.
        if bad(T,S,aux,K):
            M=irreducibles(closure([a&R for a in aux],R),R)
            selected=[next(a for a in aux if a&R==m) for m in M]
            assert bad(T,S,selected,K)
            result['compression_checks']+=1
        if _<250: check_direct(T,S,aux,K);result['direct_random_checks']+=1
        result['random_type_systems']+=1
    return dict(result)


def sharpness():
    out=[]
    for t in range(2,11):
        R=(1<<t)-1;Z=R<<t;T=R|1<<(2*t);S=R|1<<(2*t+1);K=(1<<(2*t+2))-1
        aux=[(R^1<<i)|(Z^1<<(t+i)) for i in range(t)]
        F,_=all_unions([T,S,*aux],K)
        assert len(F)==2**(t+1)+1
        assert all(sum(bool(x>>i&1) for x in F)==2**t for i in (0,1))
        assert all(sum(bool(x>>i&1) for x in F)==2**t+2 for i in range(2,t+2))
        for J in sublists(aux):
            assert cq(T,S,J,K)==(2**len(J),2**len(J)-(len(J)==t))
        out.append({'t':t,'family_size':len(F),'marked_count':2**t,'other_count':2**t+2,'smallest_obstruction':t})
    return out


def dense_random():
    rng=random.Random(343434); result=Counter()
    T=15; W=((1<<6)-1)<<4;K=T|W
    # Distinct types with trace of size 3 or 4. All pairwise meet >=3.
    for _ in range(1100):
        H=[T]
        for attempt in range(40):
            i=rng.randrange(4);E=rng.randrange(1,1<<6)<<4;A=(T^1<<i)|E
            if A not in H and all((A&B).bit_count()>=3 for B in H):H.append(A)
            if len(H)>=rng.randrange(5,10): break
        for S in H[1:]:
            if any(A!=S and A&S==A for A in H): continue # S not minimal
            i=(T&~S).bit_length()-1;aux=[A for A in H if A not in (T,S)]
            classes=[[A for A in aux if A&T==T^1<<j] for j in range(4) if j!=i]
            obs=any((A&B&C)&~T==0 for A in classes[0] for B in classes[1] for C in classes[2])
            actual=marked_pair_obstruction(T,S,aux,K) is not None
            assert obs==actual
            for J in sublists(aux):
                expected=(len(J)==3 and len({T&~A for A in J})==3 and all(T&~A not in (0,1<<i) for A in J) and (J[0]&J[1]&J[2])&~T==0)
                assert bad(T,S,J,K)==expected
                result['dense_surviving_subcollections']+=1
            result['dense_pairs']+=1;result['dense_bad_pairs']+=actual
    return dict(result)


def dense_examples():
    rows=[]
    from math import comb
    for t,k in [(4,1),(4,2),(4,3),(5,1),(5,2),(6,1),(7,1)]:
        w=(t-1)*k+1; T=(1<<t)-1; W=((1<<w)-1)<<t; K=T|W
        D=[sum(1<<j for j in x) for x in combinations(range(t,t+w),k)]
        H=[T]+[(T^1<<i)|(W^a) for i in range(t) for a in D]
        F,G=all_unions(H,K);N=(2**t-1)*sum(comb(w,j) for j in range(k,w+1))+2
        assert len(F)==N
        assert len(H)==1+t*comb(w,k) and len(set(G))==t+w
        assert all(g.bit_count()>=t for g in G)
        assert all(g&h!=g for g in G for h in G if g!=h)
        assert all(sum(bool(g>>j&1) for g in G)>=2 for j in range(len(H)))
        assert min(x.bit_count() for x in H)==t
        S=H[1]; cT=sum(x&1!=0 for x in F);cS=sum(x&2!=0 for x in F)
        assert cT==N-2**t and cT+cS>=N
        # For k=1, a translate makes the T point strictly rare.
        rare=None
        if k==1:
            keep=[T]+[(T^1<<i)|(W^1<<(t+i)) for i in range(t)]
            C=closure(keep,K); rare=(len(C)-sum(x&T==x for x in C),len(C))
            assert rare==(2**t-1,2**(t+1)-1)
        rows.append({'t':t,'k':k,'generators':len(G),'points':len(H),'sets':N,'min_member_size':min(g.bit_count() for g in G),'marked_counts':[cT,cS],'rare_translate_T':rare})
    return rows

if __name__=='__main__':
    report={'trace_closures':trace_audit(),'pair_checks':small_and_random(),'sharp_obstructions':sharpness(),'dense_checks':dense_random(),'infinite_class_examples':dense_examples()}
    print(json.dumps(report,indent=2))
