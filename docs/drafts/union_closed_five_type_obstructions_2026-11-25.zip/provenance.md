# Source and proof-status audit

## Repository source

The directory `https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts` was inspected via the GitHub connector on 2026-11-25 (Pacific time). It returned 23 ZIP files and a .gitkeep. The relevant primary source was fetched in base64 via the same connector, its ZIP member `paper.tex` decompressed, and the full TeX text read:

- `union_closed_dense_core_2026-11-25.zip`, blob `b1c269b2ae1cdb03f91797a2bf840e96730c5934`, manuscript *Three omitted generators suffice: Erasure-robust abundance and sharp frequency bounds in union-closed families*. Section 2 gives the distinct-row correspondence, Section 3 the marked-pair gap identity and sharp bounds, Section 4 the bad-quartet obstruction for overlap two, and Section 8 asks explicitly for exact robust pair criteria at overlap three and larger. The current note directly addresses that question. The predecessor's disjoint-translate transfer is reused with attribution.

The following additional archive README files were obtained by fetching and decompressing the ZIP members via the connector. These were screened at summary level, not as complete proofs. The blob identifiers below are from the directory response.

| Archive | Git blob | Main scope of README |
|---|---|---|
| union_closed_advances_2026-11-25.zip | 76d24159fb2ef3cff97a5488d023c382efc916a9 | Ranked, entropy, regular incidence |
| union_closed_extensions_2026-11-25.zip | 2b814e8557ebd25e065d10b35d10033b31c60ee1 | High girth, multi-union entropy, filters |
| union_closed_joint_laws_2026-11-25.zip | c497e7f366a6c29bd2002919c0a5e497d6359133 | Joint laws, concentration, Gaussian limit |
| union_closed_rank_transport_2026-11-25.zip | f4c375d5ae9b7337ed4e542950da3d602be537be | Rank and entropy transport |
| union_closed_refinements_2026-11-25.zip | 6477927e6fa8d36b4696f74d46a2591001d809a7 | Finite-size, approximate closure, entropy |
| union_closed_trace_entropy_2026-11-25.zip | 17cb96f215a550ffe9954ca435da5960ac204434 | Trace entropy and multiplicity |
| union_closed_uniform_threshold_2026-11-25.zip | 14fa30e81e9018fbf4664e4c6a4927f74ef8940a | Complete uniform layer FC threshold |
| union_closed_cycle_certificates.zip | 78e17f9a3659b69b95c53e3c54e0a8f821a365b8 | Directed graph cycle certificates |
| union_closed_substitution.zip | ed07cbc73f2d66acf503b5d34206b7bfd65afad1 | Hypergraph substitution |
| union_closed_local_abundance.zip | cc4298e4a6199e5781de56cd7c363d4576ca8c4d | Local high-girth every-point abundance |
| union_closed_marked_abundance.zip | 25495ddc85bae5c765322bf19546314aefa79619 | Graph, local marked-member deletion, five exceptional generators |

Together with the primary archive this makes twelve README files. A fetch attempt for `union_closed_structural_theorems.zip` returned empty base64 content, so that manuscript was not inspected. Other archive titles were listed but their contents were not reviewed. No exhaustive repository novelty claim is made.

## Literature

The following sources and search results were consulted for context and overlap, not as dependencies of the elementary proofs:

- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture — statement and known special cases.
- https://arxiv.org/abs/2610.02295 and https://zenodo.org/records/22727713 — Costa and Sadhu's 2026 preprint reports the lower bound 0.3828852549667978. This is a benchmark, not a claim about the absolute latest accepted bound. A November 2026 announcement at https://quantavane.com/major-results/union-closed-sets-conjecture/ claims 0.38317525996679; its certificates were not independently assessed here.
- https://doi.org/10.1016/0097-3165(92)90068-6 — Poonen's FC family framework.
- https://arxiv.org/abs/1309.3297 — Bruhn and Schaudt's survey.
- https://doi.org/10.1016/j.ejc.2014.08.030 — graph formulation and graph classes.
- https://doi.org/10.1080/10586458.2024.2410964 — Pulaj and Wood on local configurations and generalized Poonen criteria.
- https://doi.org/10.1090/mcom/3461 — Pulaj on cutting planes for FC families.

Search phrases included `union-closed sets conjecture missing generators intersection private elements translate`, `union-closed sets conjecture private generators translate abundance intersection closure`, `Frankl conjecture intersection closure minimal types pair generators frequency`, `union closed conjecture erasure robust minimal types overlap bad quartet`, and broader searches for structural criteria and graph formulations. No exact predecessor for the cubic obstruction test or the higher-order criterion was identified. Search coverage is limited; unpublished manuscripts, equivalent formulations, and independently discovered arguments may exist.

## Proof audit and scope

- The measure is uniform on *distinct* union sets, not generator selections. The explicit row/closure bijection handles duplicate types and erasures; the direct bitwise-OR implementation checks the same counts without using that bijection.
- The minimality of the marked types is indispensable for counting the h auxiliary types as lying outside both ideals. It is explicitly assumed in the obstruction test.
- A bad witness with both marked points present as surviving types is realizable by taking the translate base to contain every point of each excluded type. If either marked representative is in the base its frequency is one, so the pair cannot fail.
- Compression preserves the common-ideal count and can only decrease the outside-both count. The overlap-three improvement beyond compression is proved analytically by classifying irreducibles and counting distinct outside traces; the code corroborates, but is not used as a premise.
- The exact four-omission theorem assumes all minimal pairs meet in at least three labels; its triple test is for a marked pair involving the size-four type. Failure of this test for all such pairs does not disprove Frankl's conjecture or rule out a different pair.
- The higher-order condition is sufficient, not claimed necessary above size four. Its examples have unbounded parameters but may also satisfy other known criteria. The distinction from the repository's earlier three-omission and five-exception hypotheses is verified by the absence of private points and the minimality of every generator.
- Translates must be disjoint by outside projection for the transfer proof; no uncontrolled averaging of overlapping families is used.
- The proofs were checked for the above issues by the producing assistant; there has been no independent human review or Lean/Rocq verification. The unrestricted conjecture and certified publication priority remain open.
