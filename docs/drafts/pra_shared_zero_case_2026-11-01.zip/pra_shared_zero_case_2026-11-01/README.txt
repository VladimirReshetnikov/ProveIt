PRA WITH A SHARED ZERO CASE
A uniformly shorter schema for classical and intuitionistic PRA
Prepared for Vladimir Reshetnikov, 1 November 2026 (America/Los_Angeles)

START HERE
  report.pdf         Complete mathematical report.
  report.tex         Main LaTeX source.
  sections/*.tex     All source sections.
  AXIOMS.txt         Exact specification without LaTeX.

RESULT
The strongest adjacent-parameter drafts can be shortened uniformly:
the existing induction exception n=0 also carries the exceptional
initial transition of delayed iteration. Every generated axiom saves
exactly 1 + occ_n(u) expanded syntax-tree nodes, with no new primitive,
no new term-input slot, no extra axiom, and no extra quantifier.

The full theories are deductively equivalent in the same language.
Each has a common conservative definitional extension with first-order
PRA in the matching logic. The identical nonlogical schema works in
classical and intuitionistic logic, with full-carrier/native-equality
identity round trips.

This is an established further reduction, not a global shortestness
theorem. It does not claim the separately investigated zero-section
probe u(n,0)=u(n,a) is sufficient.

PROOF AND VERIFICATION FILES
  formal/GuardedTailKernel.lean  New constructive reduction, 10 theorems.
  formal/AdjacentPropagation.lean
                                Inherited and rechecked, 17 theorems.
  formal/SCOPE.txt              Exact limits of the formalization.
  formal/*lean-check.log        Successful Lean output and axiom audits.
  formal/verification.json      Machine-readable check summary.
  checks/check_schema.py        Standalone standard-library Python checker.
  checks/schema_checks.json    Exact counts and bounded diagnostics.
  checks/examples.txt          Expanded example formulas.
  audit/mathematical_review.txt Independent mathematical review.
  audit/source_manifest.json   Pinned inputs and archive hashes.
  SHA256SUMS.txt                Checksums of delivered files.

REBUILD
From this directory:
  python3 build.py

Requires Python 3 and pdflatex with the LaTeX packages in report.tex.
This runs the syntax checker and compiles the PDF three times.

Optional full recheck of the two supplied Lean files:
  python3 build.py --lean /absolute/path/to/lean

Use Lean 4.19.0. No Mathlib or network is required.
The existing Lean check logs already record successful verification.

FORMAL SCOPE
The Lean files verify local logical/algebraic interfaces with explicit
premises. All 27 audited theorems print empty axiom-dependency lists.
They do NOT formalize the entire descriptor grammar, first-order proof
calculus, scalar pairing, PR compiler, or bi-interpretation theorem.
Those results have full written proofs and an independent review.
Finite numerical tests are diagnostics, not mathematical proofs.

SOURCES AND ATTRIBUTION
All five archives in ProveIt/docs/drafts were reviewed at snapshot
9e77f2a2bb9ccf0a4f85934f1f83df8a3f8767be.
The new contribution is the shared zero case and its proof/counting.
The selector, parity encoding, arithmetic calibration, pairing, and
interpretation proofs are adapted with attribution from the reviewed
adjacent-parameter and versioned one-term archives. The inherited Lean
file is retained unchanged and credited in its scope file.
No existing repository file was modified.

