#!/usr/bin/env python3
"""Rebuild the report and optionally recheck its local Lean kernels."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(command, log_path, timeout=180):
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    log_path.write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode:
        print((result.stdout + result.stderr)[-10000:], file=sys.stderr)
        raise SystemExit(result.returncode)
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Optional path to Lean 4.19.0.")
    args = parser.parse_args()
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)
    run([sys.executable, "checks/check_schema.py"], audit / "syntax_check.log")
    if shutil.which("pdflatex") is None:
        raise SystemExit("pdflatex is required; see report.tex for its package list.")
    for i in range(1, 4):
        run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            audit / ("latex_pass_" + str(i) + ".log"))
    final_log = (ROOT / "report.log").read_text(errors="replace")
    problems = [x for x in final_log.splitlines()
                if "Overfull" in x or ("undefined" in x and "Warning" in x)]
    if problems:
        raise SystemExit("PDF validation needs attention:\n" + "\n".join(problems))
    if args.lean:
        lean = str(Path(args.lean).resolve()) if "/" in args.lean else args.lean
        run([lean, "--version"], ROOT / "formal" / "lean-version.log")
        for source, log in [
            ("GuardedTailKernel.lean", "guarded-tail-lean-check.log"),
            ("AdjacentPropagation.lean", "adjacent-lean-check.log"),
        ]:
            run([lean, str(ROOT / "formal" / source)], ROOT / "formal" / log)
    checks = json.loads((ROOT / "checks" / "schema_checks.json").read_text())
    print("Syntax checks and PDF compilation succeeded.")
    print("PDF:", ROOT / "report.pdf")
    if args.lean:
        print("Both Lean kernels rechecked successfully.")
    return checks

if __name__ == "__main__":
    main()

