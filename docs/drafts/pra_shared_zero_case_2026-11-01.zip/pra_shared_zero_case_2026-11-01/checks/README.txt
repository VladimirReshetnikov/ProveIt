FINITE SYNTAX CHECKS AND BOUNDED STANDARD-VALUE DIAGNOSTICS

Run from the archive root:

    python3 checks/check_schema.py

Requirements: Python 3.10 or newer; standard library only.
The program does not read, import, or execute any external draft or test data.
Its default seed is 20261101, and its default generation count is 1024.
The exact new and old formulas are constructed directly in the source.

WHAT IS CHECKED

1. Finite immutable term trees, including nested stored unary descriptors.
   Every descriptor uses only earlier finite syntax, and active substitution
   leaves its stored body untouched.
2. The old adjacent-parameter constructor and the new shared-zero constructor.
3. Exact active AST counts:
       old = 38 + 7|u| + 5 occ_n(u) + 3 occ_a(u)
       new = 37 + 7|u| + 4 occ_n(u) + 3 occ_a(u).
4. The same saving, 1 + occ_n(u), when every stored descriptor occurrence is
   recursively expanded and counted. Old and new use the same descriptor set.
5. Closed instances, exactly three quantifier occurrences, maximum nesting
   two, and active individual names exactly n,a.
6. The generated iterator descriptor occurs at a finite later dependency rank.
7. Selected bounded values in the intended standard natural-number model:
       D_h(n,a) = h iterated max(n-1,0) times on a.
   Reset and the old Tail hold; the new one-step equation holds when n is
   positive; the guarded old/new root matrices agree. Failure of the
   unguarded new one-step equation at zero is expected and recorded.

COUNTS

One node is charged for each variable, constant, application, equality,
logical connective, falsity symbol, and universal quantifier. A binder's
printed variable label is not a separate node. The abbreviation 1 expands
to S(0), and separation expands to (0=S(0)) -> false. The active count treats
stored bodies as function-symbol indices. The descriptor-expanded count
recursively charges their contents at every occurrence, without sharing.

OUTPUTS

schema_checks.json contains deterministic aggregate results, all generated
input counts, named examples, and selected bounded numerical values.
examples.txt prints the exact old and new sentences for nine named terms.
Running the checker regenerates these files in the checks directory by
default; --output-dir can select another directory.

SCOPE

These are finite syntax checks and diagnostics. They are not a proof of
the infinite schema, do not evaluate infinite universal quantifiers, and do
not formalize the first-order arithmetic calibration, parameter coding, or
bi-interpretability. The manuscript supplies the mathematical proofs.
The bounded evaluator has explicit fuel and value limits. Larger generated
descriptors are used for syntax only, not for uncontrolled computation.

PROVENANCE

The AST conventions and comparison formula were adapted after inspecting
checks/adjacent_schema_check.py in the supplied
pra_one_term_one_schema_2026-11-01 (1).zip draft from ProveIt/docs/drafts.
This file is standalone; it has no runtime dependency on that draft.
