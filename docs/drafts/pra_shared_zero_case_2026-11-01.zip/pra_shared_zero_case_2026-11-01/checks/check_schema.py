#!/usr/bin/env python3
"""Finite syntax and bounded-value diagnostics for the shared-zero schema.

This program checks explicit finite abstract syntax trees. It does not prove
the first-order calibration theorem or evaluate infinite quantifiers. The AST
conventions adapt the inspected adjacent-schema checker supplied in the
2026-11-01 ProveIt draft; the new constructor and comparisons are implemented
here independently. No draft file is imported, read, or executed.

Run with Python 3.10 or newer; no third-party package is needed.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


def Var(name: str) -> Term:
    return Term("variable", name=name)


ZERO = Term("zero")
N, A, V = (Var(name) for name in ("n", "a", "v"))


def Succ(t: Term) -> Term:
    return Term("successor", (t,))


ONE = Succ(ZERO)
SUCC_BODY = Succ(V)


@lru_cache(maxsize=None)
def free_term_variables(t: Term) -> frozenset[str]:
    """Stored bodies are part of a function's name, not active arguments."""
    if t.kind == "variable":
        return frozenset((t.name,))
    return frozenset().union(*(free_term_variables(x) for x in t.args))


def Delay(body: Term, counter: Term, seed: Term) -> Term:
    if not free_term_variables(body) <= {"v"}:
        raise ValueError("A stored unary body may have only v free")
    # Every body passed here is an already built immutable finite term.
    return Term("delay", (counter, seed), body=body)


def substitute(t: Term, replacement: dict[str, Term]) -> Term:
    """Simultaneous active substitution; never enter a stored descriptor."""
    if t.kind == "variable":
        return replacement.get(t.name, t)
    return Term(t.kind, tuple(substitute(x, replacement) for x in t.args),
                t.name, t.body)


@lru_cache(maxsize=None)
def term_nodes(t: Term, include_descriptors: bool = False) -> int:
    value = 1 + sum(term_nodes(x, include_descriptors) for x in t.args)
    if include_descriptors and t.body is not None:
        value += term_nodes(t.body, True)
    return value


@lru_cache(maxsize=None)
def occurrences(t: Term, name: str) -> int:
    return (int(t.kind == "variable" and t.name == name)
            + sum(occurrences(x, name) for x in t.args))


@lru_cache(maxsize=None)
def descriptor_rank(t: Term) -> int:
    active_rank = max((descriptor_rank(x) for x in t.args), default=0)
    return max(active_rank,
               1 + descriptor_rank(t.body) if t.body is not None else 0)


@lru_cache(maxsize=None)
def stored_bodies(t: Term) -> frozenset[Term]:
    values = frozenset().union(*(stored_bodies(x) for x in t.args))
    if t.body is not None:
        values |= frozenset((t.body,)) | stored_bodies(t.body)
    return values


def render_term(t: Term) -> str:
    if t.kind == "zero":
        return "0"
    if t.kind == "variable":
        return t.name
    if t.kind == "successor":
        return "S(" + render_term(t.args[0]) + ")"
    if t.kind == "delay":
        assert t.body is not None
        return ("D_[" + render_term(t.body) + "](" +
                render_term(t.args[0]) + "," + render_term(t.args[1]) + ")")
    raise ValueError(t.kind)


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple["Term | Formula", ...] = ()
    binder: str = ""


def Equal(left: Term, right: Term) -> Formula:
    return Formula("equal", (left, right))


def Conj(left: Formula, right: Formula) -> Formula:
    return Formula("and", (left, right))


def Disj(left: Formula, right: Formula) -> Formula:
    return Formula("or", (left, right))


def Implies(left: Formula, right: Formula) -> Formula:
    return Formula("implies", (left, right))


def Forall(name: str, f: Formula) -> Formula:
    return Formula("forall", (f,), name)


BOTTOM = Formula("bottom")
SEPARATION = Implies(Equal(ZERO, ONE), BOTTOM)


def formula_substitute(f: Formula, replacement: dict[str, Term]) -> Formula:
    if f.kind == "equal":
        return Equal(*(substitute(t, replacement) for t in f.args))
    if f.kind == "forall":
        reduced = {name: value for name, value in replacement.items()
                   if name != f.binder}
        if any(f.binder in free_term_variables(value)
               for value in reduced.values()):
            raise ValueError("Capture would require explicit alpha-renaming")
        return Forall(f.binder, formula_substitute(f.args[0], reduced))
    return Formula(f.kind, tuple(formula_substitute(x, replacement)
                                for x in f.args))


def formula_nodes(f: Formula, include_descriptors: bool = False) -> int:
    if f.kind == "equal":
        return 1 + sum(term_nodes(t, include_descriptors) for t in f.args)
    return 1 + sum(formula_nodes(x, include_descriptors) for x in f.args)


def formula_free_variables(f: Formula) -> frozenset[str]:
    if f.kind == "equal":
        return frozenset().union(*(free_term_variables(t) for t in f.args))
    values = frozenset().union(*(formula_free_variables(x) for x in f.args))
    return values - {f.binder} if f.kind == "forall" else values


def individual_names(f: Formula) -> frozenset[str]:
    if f.kind == "equal":
        return frozenset().union(*(free_term_variables(t) for t in f.args))
    values = frozenset().union(*(individual_names(x) for x in f.args))
    return values | {f.binder} if f.kind == "forall" else values


def quantifier_count(f: Formula) -> int:
    if f.kind == "equal":
        return 0
    return int(f.kind == "forall") + sum(quantifier_count(x) for x in f.args)


def quantifier_depth(f: Formula) -> int:
    if f.kind == "equal":
        return 0
    return int(f.kind == "forall") + max(
        (quantifier_depth(x) for x in f.args), default=0)


def formula_bodies(f: Formula) -> frozenset[Term]:
    if f.kind == "equal":
        return frozenset().union(*(stored_bodies(t) for t in f.args))
    return frozenset().union(*(formula_bodies(x) for x in f.args))


def formula_rank(f: Formula) -> int:
    if f.kind == "equal":
        return max(descriptor_rank(t) for t in f.args)
    return max((formula_rank(x) for x in f.args), default=0)


def render_formula(f: Formula) -> str:
    if f.kind == "equal":
        return "(" + render_term(f.args[0]) + " = " + render_term(f.args[1]) + ")"
    if f.kind == "bottom":
        return "false"
    if f.kind == "forall":
        return "forall " + f.binder + " (" + render_formula(f.args[0]) + ")"
    token = {"and": "AND", "or": "OR", "implies": "->"}[f.kind]
    return "(" + render_formula(f.args[0]) + " " + token + " " + render_formula(f.args[1]) + ")"


def q(counter: Term, seed: Term) -> Term:
    return Delay(ONE, counter, seed)


def ingredients(u: Term) -> tuple[Term, Formula, Formula, Formula, Formula, Formula]:
    if not free_term_variables(u) <= {"n", "a"}:
        raise ValueError("An input term may have only n,a free")
    h = substitute(u, {"n": V, "a": ZERO})
    e = Equal(u, substitute(u, {"a": Succ(A)}))
    root = Equal(N, ZERO)
    p = Disj(root, e)
    progress = Forall("n", Implies(
        p, formula_substitute(e, {"n": Succ(N)})))
    reset = Equal(Delay(h, q(N, ZERO), A), A)
    return h, e, root, p, progress, reset


def old_axiom(u: Term) -> Formula:
    """Exact strongest adjacent-parameter draft constructor."""
    h, e, root, p, progress, reset = ingredients(u)
    tail = Equal(Delay(h, Succ(Succ(N)), A),
                 substitute(h, {"v": Delay(h, Succ(N), A)}))
    computation = Conj(SEPARATION, Conj(reset, tail))
    return Forall("a", Implies(progress, Forall("n", Conj(p, computation))))


def new_axiom(u: Term) -> Formula:
    """Exact shared-zero constructor; M is inside the root disjunction."""
    h, e, root, p, progress, reset = ingredients(u)
    one_step = Equal(Delay(h, Succ(N), A),
                     substitute(h, {"v": Delay(h, N, A)}))
    result = Conj(SEPARATION, Conj(reset, Disj(root, Conj(e, one_step))))
    return Forall("a", Implies(progress, Forall("n", result)))


def zero_gate(counter: Term, seed: Term) -> Term:
    return Delay(ZERO, Succ(counter), seed)


def selector(tag: Term, yes: Term, no: Term) -> Term:
    return Delay(SUCC_BODY, zero_gate(tag, Succ(yes)),
                 zero_gate(zero_gate(tag, ONE), no))


def named_examples() -> list[tuple[str, Term]]:
    nested_body = Delay(SUCC_BODY, V, ZERO)
    deeper_body = Delay(nested_body, V, Succ(V))
    return [
        ("zero", ZERO),
        ("counter", N),
        ("parameter", A),
        ("successor", Succ(N)),
        ("successor_iterator", Delay(SUCC_BODY, N, A)),
        ("identity_iterator", Delay(V, N, N)),
        ("selector", selector(A, N, Succ(N))),
        ("nested_descriptor", Delay(nested_body, Succ(N), A)),
        ("deeper_descriptor", Delay(deeper_body, N, Succ(A))),
    ]


def random_term(rng: random.Random, depth: int, variables: tuple[Term, ...],
                bodies: tuple[Term, ...]) -> Term:
    if depth <= 0 or rng.randrange(5) == 0:
        return rng.choice((ZERO,) + variables)
    if rng.randrange(3) == 0:
        return Succ(random_term(rng, depth - 1, variables, bodies))
    return Delay(rng.choice(bodies),
                 random_term(rng, depth - 1, variables, bodies),
                 random_term(rng, depth - 1, variables, bodies))


def generated_inputs(count: int, seed: int) -> list[tuple[str, Term]]:
    rng = random.Random(seed)
    bodies: tuple[Term, ...] = (ZERO, V, ONE, SUCC_BODY)
    # Each stage uses only previous bodies: finite acyclic descriptor syntax.
    for stage in range(3):
        previous = bodies
        fresh = tuple(random_term(rng, 2, (V,), previous) for _ in range(6))
        bodies = previous + fresh
    result = named_examples()
    result.extend(("generated_%04d" % i,
                   random_term(rng, 1 + rng.randrange(4), (N, A), bodies))
                  for i in range(count))
    return result


def check_case(name: str, u: Term) -> dict[str, int | str | list[str]]:
    old, new = old_axiom(u), new_axiom(u)
    size, ns, pars = term_nodes(u), occurrences(u, "n"), occurrences(u, "a")
    old_size, new_size = formula_nodes(old), formula_nodes(new)
    assert old_size == 38 + 7 * size + 5 * ns + 3 * pars
    assert new_size == 37 + 7 * size + 4 * ns + 3 * pars
    saving = 1 + ns
    assert old_size - new_size == saving
    old_full, new_full = formula_nodes(old, True), formula_nodes(new, True)
    assert old_full - new_full == saving
    assert formula_bodies(old) == formula_bodies(new)
    for axiom in (old, new):
        assert not formula_free_variables(axiom)
        assert individual_names(axiom) == {"n", "a"}
        assert quantifier_count(axiom) == 3
        assert quantifier_depth(axiom) == 2
        assert formula_rank(axiom) == descriptor_rank(u) + 1
    return {
        "name": name, "input_active_nodes": size,
        "input_descriptor_expanded_nodes": term_nodes(u, True),
        "input_descriptor_rank": descriptor_rank(u),
        "active_counter_occurrences": ns,
        "active_parameter_occurrences": pars,
        "old_active_nodes": old_size, "new_active_nodes": new_size,
        "old_descriptor_expanded_nodes": old_full,
        "new_descriptor_expanded_nodes": new_full,
        "saving_in_both_conventions": saving,
        "quantifier_count": 3, "quantifier_depth": 2,
        "active_individual_names": ["a", "n"],
    }


class EvaluationLimit(RuntimeError):
    pass


@dataclass
class Budget:
    remaining: int = 100_000
    maximum_value: int = 100_000

    def tick(self) -> None:
        self.remaining -= 1
        if self.remaining < 0:
            raise EvaluationLimit("Evaluation fuel exhausted")


def evaluate(t: Term, environment: dict[str, int], budget: Budget) -> int:
    """Intended standard values only; D_h(n,a)=h^(max(n-1,0))(a)."""
    budget.tick()
    if t.kind == "zero":
        value = 0
    elif t.kind == "variable":
        value = environment[t.name]
    elif t.kind == "successor":
        value = evaluate(t.args[0], environment, budget) + 1
    elif t.kind == "delay":
        assert t.body is not None
        counter = evaluate(t.args[0], environment, budget)
        value = evaluate(t.args[1], environment, budget)
        for _ in range(max(counter - 1, 0)):
            value = evaluate(t.body, {"v": value}, budget)
    else:
        raise ValueError(t.kind)
    if not 0 <= value <= budget.maximum_value:
        raise EvaluationLimit("Value outside the diagnostic bound")
    return value


def value(t: Term, n: int, a: int) -> int:
    return evaluate(t, {"n": n, "a": a}, Budget())


def bounded_diagnostics(bound: int) -> dict:
    # Restrict value evaluation to these modest examples. Large generated
    # descriptors above are used for syntax only, never for unbounded runs.
    checked_points = 0
    examples = []
    for name, u in named_examples()[:8]:
        h, e, root, p, progress, reset = ingredients(u)
        for n in range(bound + 1):
            for a in range(bound + 1):
                env = {"n": n, "a": a}
                old_left = value(Delay(h, Succ(Succ(N)), A), n, a)
                old_right = value(substitute(h, {"v": Delay(h, Succ(N), A)}), n, a)
                reset_left = value(Delay(h, q(N, ZERO), A), n, a)
                m_left = value(Delay(h, Succ(N), A), n, a)
                m_right = value(substitute(h, {"v": Delay(h, N, A)}), n, a)
                endpoint_left = value(u, n, a)
                endpoint_right = value(substitute(u, {"a": Succ(A)}), n, a)
                endpoint = endpoint_left == endpoint_right
                old_root = n == 0 or endpoint
                shared_root = n == 0 or (endpoint and m_left == m_right)
                assert reset_left == a
                assert old_left == old_right
                assert n == 0 or m_left == m_right
                assert old_root == shared_root
                checked_points += 1
                if n in (0, 1, 2) and a in (0, 1, 3):
                    examples.append({
                        "input": name, "n": n, "a": a,
                        "endpoint_values": [endpoint_left, endpoint_right],
                        "one_step_values": [m_left, m_right],
                        "one_step_equation": m_left == m_right,
                        "guarded_one_step": n == 0 or m_left == m_right,
                        "old_root": old_root, "shared_root": shared_root,
                        "reset_value": reset_left,
                    })
    return {
        "scope": "Bounded standard-value identities only; no infinite quantifiers evaluated.",
        "bound_inclusive": bound,
        "checked_input_counter_parameter_triples": checked_points,
        "selected_values": examples,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, default=1024,
                        help="Number of generated syntax inputs, in addition to nine named inputs")
    parser.add_argument("--seed", type=int, default=20261101)
    parser.add_argument("--bound", type=int, default=5,
                        help="Inclusive standard-value diagnostic bound")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    if args.count < 0 or not 0 <= args.bound <= 10:
        parser.error("count must be nonnegative; bound must be between 0 and 10")

    # An active substitution must preserve each already stored body literally.
    probe = Delay(SUCC_BODY, N, A)
    replaced = substitute(probe, {"n": Succ(N), "a": ZERO, "v": ZERO})
    assert replaced.body is probe.body
    assert free_term_variables(replaced.body) == {"v"}
    assert replaced.args == (Succ(N), ZERO)

    inputs = generated_inputs(args.count, args.seed)
    records = [check_case(name, u) for name, u in inputs]
    diagnostics = bounded_diagnostics(args.bound)
    summary = {
        "status": "PASS",
        "scope": "Finite syntax checks and bounded standard-value diagnostics, not a formal proof of bi-interpretability.",
        "seed": args.seed,
        "generated_input_count": args.count,
        "named_input_count": len(named_examples()),
        "total_checked_inputs": len(records),
        "distinct_input_terms": len({u for _, u in inputs}),
        "old_active_count_formula": "38 + 7|u| + 5 occ_n(u) + 3 occ_a(u)",
        "new_active_count_formula": "37 + 7|u| + 4 occ_n(u) + 3 occ_a(u)",
        "saving_in_active_and_descriptor_expanded_counts": "1 + occ_n(u)",
        "descriptor_policy": "Immutable finite earlier unary bodies; active substitution never enters a stored body.",
        "maximum_checked_input_descriptor_rank": max(r["input_descriptor_rank"] for r in records),
        "maximum_checked_input_active_nodes": max(r["input_active_nodes"] for r in records),
        "maximum_checked_input_descriptor_expanded_nodes": max(r["input_descriptor_expanded_nodes"] for r in records),
        "named_examples": records[:len(named_examples())],
        "generated_checks": records[len(named_examples()):],
        "bounded_diagnostics": diagnostics,
    }

    lines = [
        "SHARED ZERO CASE: EXACT FINITE SYNTAX EXAMPLES",
        "",
        "One node per variable, constant, application, equality, connective, falsity, or quantifier.",
        "Negation is expanded as implication to falsity; 1 is expanded as S(0).",
        "Descriptors are frozen indices. The second count also expands every stored-body occurrence.",
        "These diagnostics do not constitute a proof of the infinite schema or its bi-interpretability.",
        "",
    ]
    for (name, u), record in zip(named_examples(), records):
        lines.extend([
            "INPUT " + name + ": " + render_term(u),
            "h_u(v) = " + render_term(substitute(u, {"n": V, "a": ZERO})),
            "Active old/new/saving: %d / %d / %d" % (
                record["old_active_nodes"], record["new_active_nodes"],
                record["saving_in_both_conventions"]),
            "Descriptor-expanded old/new: %d / %d" % (
                record["old_descriptor_expanded_nodes"], record["new_descriptor_expanded_nodes"]),
            "OLD: " + render_formula(old_axiom(u)),
            "NEW: " + render_formula(new_axiom(u)),
            "",
        ])
    lines.extend([
        "BOUNDED STANDARD-VALUE DIAGNOSTICS",
        "The unguarded one-step equation can fail at n=0, as intended.",
        "The guarded equation, Reset, and old Tail hold at every checked point.",
        "Old and shared root matrices agree at every checked point.",
        "Checked triples: " + str(diagnostics["checked_input_counter_parameter_triples"]),
        "See schema_checks.json for selected values and all finite syntax counts.",
        "",
    ])
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "schema_checks.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (args.output_dir / "examples.txt").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({
        "status": summary["status"],
        "syntax_inputs": len(records),
        "distinct_inputs": summary["distinct_input_terms"],
        "max_descriptor_rank": summary["maximum_checked_input_descriptor_rank"],
        "bounded_standard_value_triples": diagnostics["checked_input_counter_parameter_triples"],
        "new_active_count": summary["new_active_count_formula"],
        "saving": summary["saving_in_active_and_descriptor_expanded_counts"],
        "outputs": [str(args.output_dir / "schema_checks.json"), str(args.output_dir / "examples.txt")],
    }, indent=2))


if __name__ == "__main__":
    main()
