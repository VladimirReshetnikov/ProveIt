import Init

/-!
Constructive kernels for the adjacent-probe one-binary-term PRA presentation.

Each schema occurrence is an explicit hypothesis for ONE selected finite term
instance. No unrestricted semantic induction scheme is assumed. `AdjacentAt`
abstracts the exact logical envelope; its `C` is the computational conjunction
belonging to that syntax instance. The syntax identity h_U(v)=U(v,0), membership
of all displayed terms in the generated language, the complete arithmetic
calibration, pairing, PR compilation, and bi-interpretation are written proofs,
not formalized by this file.

The parity transfer uses two fixed binary term instances formed from f(n,b) and
g(n,p(b)); neither includes the externally fixed parameter a as a third slot.
The bit-range and flipping lemmas use coverage and computation only, without
an induction hypothesis. All proofs are constructive. There are no added
axioms, sorry/admit placeholders, classical reasoning, or choice.
-/

universe u
namespace AdjacentPropagation
variable {A : Type u}

/-- A selected shortened propagation instance with one frozen parameter. -/
def ShortAt (zero : A) (succ : A → A) (E : A → A → Prop) : Prop :=
  ∀ a, (∀ n, (n = zero ∨ E n a) → E (succ n) a) →
    ∀ n, n = zero ∨ E n a

/-- The exact one-binary-term logical envelope for one selected input. -/
def AdjacentAt (zero : A) (succ : A → A) (term : A → A → A)
    (C : A → A → Prop) : Prop :=
  ∀ a,
    (∀ n, (n = zero ∨ term n a = term n (succ a)) →
      term (succ n) a = term (succ n) (succ a)) →
    ∀ n, (n = zero ∨ term n a = term n (succ a)) ∧ C n a

/-- Parameter-independent inputs recover their computation unconditionally. -/
theorem computation_extract (zero : A) (succ : A → A)
    (h : A → A) (C : A → A → Prop)
    (schemaInstance : AdjacentAt zero succ (fun n _ => h n) C) :
    ∀ a n, C n a := by
  intro a n
  exact (schemaInstance a (fun _ _ => rfl) n).2

/-- The propagation component is a direct projection of its selected instance. -/
theorem propagation_project (zero : A) (succ : A → A)
    (term : A → A → A) (C : A → A → Prop)
    (schemaInstance : AdjacentAt zero succ term C) :
    ShortAt zero succ (fun n a => term n a = term n (succ a)) := by
  intro a progress n
  exact (schemaInstance a progress n).1

/-- Computation and the selected propagation reconstruct the envelope. -/
theorem envelope_from_parts (zero : A) (succ : A → A)
    (term : A → A → A) (C : A → A → Prop)
    (computation : ∀ a n, C n a)
    (propagation : ShortAt zero succ (fun n a => term n a = term n (succ a))) :
    AdjacentAt zero succ term C := by
  intro a progress n
  exact ⟨propagation a progress n, computation a n⟩

/-- Endpoint identities transfer one selected parameter value, with local assumptions. -/
theorem propagation_transfer_at (zero : A) (succ : A → A)
    (term : A → A → A) (C : A → A → Prop) (f g : A → A) (a : A)
    (left : ∀ n, term n a = f n)
    (right : ∀ n, term n (succ a) = g n)
    (schemaInstance : AdjacentAt zero succ term C) :
    (∀ n, (n = zero ∨ f n = g n) → f (succ n) = g (succ n)) →
      ∀ n, n = zero ∨ f n = g n := by
  intro progress n
  have endpoints (k : A) : (term k a = term k (succ a)) ↔ (f k = g k) := by
    rw [left k, right k]
  have sourceProgress : ∀ k, (k = zero ∨ term k a = term k (succ a)) →
      term (succ k) a = term (succ k) (succ a) := by
    intro k premise
    apply (endpoints (succ k)).mpr
    apply progress k
    cases premise with
    | inl hz => exact Or.inl hz
    | inr he => exact Or.inr ((endpoints k).mp he)
  cases (schemaInstance a sourceProgress n).1 with
  | inl hz => exact Or.inl hz
  | inr he => exact Or.inr ((endpoints n).mp he)

/-- Local base and step give induction for this selected equation. -/
theorem equation_induction_at (zero : A) (succ : A → A) (f g : A → A)
    (propagation :
      (∀ n, (n = zero ∨ f n = g n) → f (succ n) = g (succ n)) →
      ∀ n, n = zero ∨ f n = g n) :
    f zero = g zero → (∀ n, f n = g n → f (succ n) = g (succ n)) →
      ∀ n, f n = g n := by
  intro base step n
  have progress : ∀ k, (k = zero ∨ f k = g k) → f (succ k) = g (succ k) := by
    intro k premise
    cases premise with
    | inl hz => exact step k (hz ▸ base)
    | inr he => exact step k he
  cases propagation progress n with
  | inl hz => exact hz ▸ base
  | inr he => exact he

/-- Delayed seeds use computation alone, without induction or separation. -/
theorem delayed_seeds (zero : A) (succ : A → A) (d q : A → A → A)
    (resetD : ∀ n a, d (q n zero) a = a)
    (resetQ : ∀ n a, q (q n zero) a = a)
    (tailQ : ∀ n a, q (succ (succ n)) a = succ zero) :
    (∀ a, d zero a = a) ∧ (∀ a, d (succ zero) a = a) := by
  have qTwo : q (succ (succ zero)) zero = succ zero := tailQ zero zero
  have seedOne : ∀ a, d (succ zero) a = a := by
    intro a
    have result := resetD (succ (succ zero)) a
    rw [qTwo] at result
    exact result
  have qOne : q (succ zero) zero = zero := by
    have result := resetQ (succ (succ zero)) zero
    rw [qTwo] at result
    exact result
  have seedZero : ∀ a, d zero a = a := by
    intro a
    have result := resetD (succ zero) a
    rw [qOne] at result
    exact result
  exact ⟨seedZero, seedOne⟩

/-- The scalar conditional term; it is defined before proving its branch laws. -/
def Select (succ : A → A) (d Z : A → A → A) (one tag left right : A) : A :=
  d (Z tag (succ left)) (Z (Z tag one) right)

/-- Before predecessor calibration, its zero branch is p(S(left)). -/
theorem selector_zero_before (zero : A) (succ : A → A) (d Z : A → A → A)
    (ZZero : ∀ a, Z zero a = a)
    (ZSucc : ∀ n a, Z (succ n) a = zero) (b c : A) :
    Select succ d Z (succ zero) zero b c = d (succ b) zero := by
  unfold Select
  rw [ZZero, ZZero, ZSucc]

/-- The one branch already returns the right argument using only the zero seed. -/
theorem selector_one_before (zero : A) (succ : A → A) (d Z : A → A → A)
    (dZero : ∀ a, d zero a = a)
    (ZZero : ∀ a, Z zero a = a)
    (ZSucc : ∀ n a, Z (succ n) a = zero) (b c : A) :
    Select succ d Z (succ zero) (succ zero) b c = c := by
  unfold Select
  rw [ZSucc, ZSucc, ZZero, dZero]

/-- The selected input U(n,a)=Select(a,n,n), at a=0, gives predecessor calibration. -/
theorem predecessor_recovery (zero : A) (succ : A → A)
    (d Z : A → A → A) (C : A → A → Prop)
    (dZero : ∀ a, d zero a = a)
    (dOne : ∀ a, d (succ zero) a = a)
    (tail : ∀ n, d (succ (succ n)) zero = succ (d (succ n) zero))
    (ZZero : ∀ a, Z zero a = a)
    (ZSucc : ∀ n a, Z (succ n) a = zero)
    (schemaInstance : AdjacentAt zero succ
      (fun n a => Select succ d Z (succ zero) a n n) C) :
    ∀ n, d (succ n) zero = n := by
  have propagation := propagation_transfer_at zero succ
    (fun n a => Select succ d Z (succ zero) a n n) C
    (fun n => d (succ n) zero) (fun n => n) zero
    (fun n => selector_zero_before zero succ d Z ZZero ZSucc n n)
    (fun n => selector_one_before zero succ d Z dZero ZZero ZSucc n n)
    schemaInstance
  have base : d (succ zero) zero = zero := dOne zero
  have step : ∀ n, d (succ n) zero = n →
      d (succ (succ n)) zero = succ n := by
    intro n hn
    exact (tail n).trans (congrArg succ hn)
  exact equation_induction_at zero succ (fun n => d (succ n) zero)
    (fun n => n) propagation base step

/-- Both true selector branches follow, without defining addition. -/
theorem selector_endpoints (zero : A) (succ : A → A) (d Z : A → A → A)
    (dZero : ∀ a, d zero a = a)
    (predSucc : ∀ n, d (succ n) zero = n)
    (ZZero : ∀ a, Z zero a = a)
    (ZSucc : ∀ n a, Z (succ n) a = zero) :
    (∀ b c, Select succ d Z (succ zero) zero b c = b) ∧
    (∀ b c, Select succ d Z (succ zero) (succ zero) b c = c) := by
  constructor
  · intro b c
    exact (selector_zero_before zero succ d Z ZZero ZSucc b c).trans (predSucc b)
  · exact selector_one_before zero succ d Z dZero ZZero ZSucc

/-- A second parameter-zero instance gives positive coverage. -/
theorem coverage_recovery (zero : A) (succ pred : A → A)
    (sel : A → A → A → A) (C : A → A → Prop)
    (left : ∀ b c, sel zero b c = b)
    (right : ∀ b c, sel (succ zero) b c = c)
    (predSucc : ∀ n, pred (succ n) = n)
    (schemaInstance : AdjacentAt zero succ
      (fun n a => sel a (succ (pred n)) n) C) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  have propagation := propagation_transfer_at zero succ
    (fun n a => sel a (succ (pred n)) n) C
    (fun n => succ (pred n)) (fun n => n) zero
    (fun n => left (succ (pred n)) n)
    (fun n => right (succ (pred n)) n) schemaInstance
  have progress : ∀ n, (n = zero ∨ succ (pred n) = n) →
      succ (pred (succ n)) = succ n := by
    intro n _
    exact congrArg succ (predSucc n)
  intro n
  cases propagation progress n with
  | inl hz => exact Or.inl hz
  | inr he => exact Or.inr he.symm

/-- Coverage makes the unary toggle two-valued, with no induction. -/
theorem toggle_range (zero : A) (succ pred toggle : A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (toggleZero : toggle zero = succ zero)
    (toggleSucc : ∀ n, toggle (succ n) = zero) :
    ∀ n, toggle n = zero ∨ toggle n = succ zero := by
  intro n
  cases coverage n with
  | inl hz => exact Or.inr (hz ▸ toggleZero)
  | inr hs => exact Or.inl ((congrArg toggle hs).trans (toggleSucc (pred n)))

/-- One unfolding and coverage also give the parity iterator's bit range. -/
theorem parity_range (zero : A) (succ pred toggle parity : A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (toggleRange : ∀ n, toggle n = zero ∨ toggle n = succ zero)
    (parityZero : parity zero = zero)
    (paritySucc : ∀ n, parity (succ n) = toggle (parity n)) :
    ∀ n, parity n = zero ∨ parity n = succ zero := by
  intro n
  cases coverage n with
  | inl hz => exact Or.inl (hz ▸ parityZero)
  | inr hs =>
    have unfoldParity : parity n = toggle (parity (pred n)) :=
      (congrArg parity hs).trans (paritySucc (pred n))
    cases toggleRange (parity (pred n)) with
    | inl hz => exact Or.inl (unfoldParity.trans hz)
    | inr ho => exact Or.inr (unfoldParity.trans ho)

/-- Parity flips under successor, by computation alone. -/
theorem parity_flips (zero : A) (succ toggle parity : A → A)
    (toggleZero : toggle zero = succ zero)
    (toggleOne : toggle (succ zero) = zero)
    (paritySucc : ∀ n, parity (succ n) = toggle (parity n)) :
    (∀ n, parity n = zero → parity (succ n) = succ zero) ∧
    (∀ n, parity n = succ zero → parity (succ n) = zero) := by
  constructor
  · intro n hn
    exact (paritySucc n).trans ((congrArg toggle hn).trans toggleZero)
  · intro n hn
    exact (paritySucc n).trans ((congrArg toggle hn).trans toggleOne)

/-- First binary input for the even branch; no third parameter slot occurs. -/
def ProbeZero (sel : A → A → A → A) (parity pred : A → A)
    (f g : A → A → A) (n b : A) : A :=
  sel (parity b) (f n b) (g n (pred b))

/-- Second binary input, with the two stored alternatives interchanged. -/
def ProbeOne (sel : A → A → A → A) (parity pred : A → A)
    (f g : A → A → A) (n b : A) : A :=
  sel (parity b) (g n (pred b)) (f n b)

/-- At an even parameter, the first binary term presents the desired endpoints. -/
theorem even_endpoints (zero : A) (succ pred parity : A → A)
    (sel : A → A → A → A) (f g : A → A → A)
    (left : ∀ b c, sel zero b c = b)
    (right : ∀ b c, sel (succ zero) b c = c)
    (predSucc : ∀ n, pred (succ n) = n)
    (flip : ∀ n, parity n = zero → parity (succ n) = succ zero)
    (a : A) (even : parity a = zero) :
    (∀ n, ProbeZero sel parity pred f g n a = f n a) ∧
    (∀ n, ProbeZero sel parity pred f g n (succ a) = g n a) := by
  constructor
  · intro n
    unfold ProbeZero
    rw [even, left]
  · intro n
    unfold ProbeZero
    rw [flip a even, right, predSucc]

/-- At an odd parameter, the second binary term presents those same endpoints. -/
theorem odd_endpoints (zero : A) (succ pred parity : A → A)
    (sel : A → A → A → A) (f g : A → A → A)
    (left : ∀ b c, sel zero b c = b)
    (right : ∀ b c, sel (succ zero) b c = c)
    (predSucc : ∀ n, pred (succ n) = n)
    (flip : ∀ n, parity n = succ zero → parity (succ n) = zero)
    (a : A) (odd : parity a = succ zero) :
    (∀ n, ProbeOne sel parity pred f g n a = f n a) ∧
    (∀ n, ProbeOne sel parity pred f g n (succ a) = g n a) := by
  constructor
  · intro n
    unfold ProbeOne
    rw [odd, right]
  · intro n
    unfold ProbeOne
    rw [flip a odd, left, predSucc]

/-- Two legal binary instances recover the arbitrary selected equation scheme. -/
theorem arbitrary_equation_propagation (zero : A) (succ pred parity : A → A)
    (sel : A → A → A → A) (f g : A → A → A)
    (CZero COne : A → A → Prop)
    (left : ∀ b c, sel zero b c = b)
    (right : ∀ b c, sel (succ zero) b c = c)
    (predSucc : ∀ n, pred (succ n) = n)
    (range : ∀ n, parity n = zero ∨ parity n = succ zero)
    (flipZero : ∀ n, parity n = zero → parity (succ n) = succ zero)
    (flipOne : ∀ n, parity n = succ zero → parity (succ n) = zero)
    (zeroInstance : AdjacentAt zero succ (ProbeZero sel parity pred f g) CZero)
    (oneInstance : AdjacentAt zero succ (ProbeOne sel parity pred f g) COne) :
    ShortAt zero succ (fun n a => f n a = g n a) := by
  intro a progress
  cases range a with
  | inl even =>
    have ends := even_endpoints zero succ pred parity sel f g
      left right predSucc flipZero a even
    exact propagation_transfer_at zero succ (ProbeZero sel parity pred f g)
      CZero (fun n => f n a) (fun n => g n a) a ends.1 ends.2
      zeroInstance progress
  | inr odd =>
    have ends := odd_endpoints zero succ pred parity sel f g
      left right predSucc flipOne a odd
    exact propagation_transfer_at zero succ (ProbeOne sel parity pred f g)
      COne (fun n => f n a) (fun n => g n a) a ends.1 ends.2
      oneInstance progress

#print axioms computation_extract
#print axioms propagation_project
#print axioms envelope_from_parts
#print axioms propagation_transfer_at
#print axioms equation_induction_at
#print axioms delayed_seeds
#print axioms selector_zero_before
#print axioms selector_one_before
#print axioms predecessor_recovery
#print axioms selector_endpoints
#print axioms coverage_recovery
#print axioms toggle_range
#print axioms parity_range
#print axioms parity_flips
#print axioms even_endpoints
#print axioms odd_endpoints
#print axioms arbitrary_equation_propagation

end AdjacentPropagation
