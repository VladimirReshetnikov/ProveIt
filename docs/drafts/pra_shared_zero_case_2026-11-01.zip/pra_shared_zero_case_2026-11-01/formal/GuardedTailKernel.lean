import Init

/-!
Constructive logical kernel for the shared-root guarded-tail reduction.

Every schema hypothesis below is ONE selected finite syntax instance.  The
functions are semantic placeholders for terms, not an assertion that the
theory admits arbitrary semantic functions as schema inputs.  Term syntax,
descriptor generation, the existing adjacent-parameter calibration, pairing,
primitive-recursive compilation and full bi-interpretability are outside this
file's scope.  They are proved in the accompanying written report.

This file verifies precisely the new reduction: computation extraction,
adjacent propagation projection, delayed seed recovery, successor nonzeroness
before predecessor, old Tail recovery, and the constructive converse.
There are no added axioms, sorry/admit placeholders, classical reasoning,
function extensionality or choice.
-/

universe u
namespace GuardedTailKernel
variable {A : Type u}

/-- A selected adjacent-value propagation instance. -/
def AdjacentPropagation (zero : A) (succ : A → A)
    (term : A → A → A) : Prop :=
  ∀ a,
    (∀ n, (n = zero ∨ term n a = term n (succ a)) →
      term (succ n) a = term (succ n) (succ a)) →
    ∀ n, n = zero ∨ term n a = term n (succ a)

/-- The new schema envelope for one selected finite term. -/
def SharedRootAt (zero : A) (succ : A → A) (term : A → A → A)
    (reset middle : A → A → Prop) : Prop :=
  ∀ a,
    (∀ n, (n = zero ∨ term n a = term n (succ a)) →
      term (succ n) a = term (succ n) (succ a)) →
    ∀ n, (zero ≠ succ zero) ∧
      (reset n a ∧ (n = zero ∨
        (term n a = term n (succ a) ∧ middle n a)))

/-- A parameter-independent input extracts all its computation, without induction. -/
theorem computation_extract (zero : A) (succ : A → A)
    (h : A → A) (reset middle : A → A → Prop)
    (schemaInstance : SharedRootAt zero succ (fun n _ => h n) reset middle) :
    (zero ≠ succ zero) ∧
      ((∀ n a, reset n a) ∧ (∀ n a, n = zero ∨ middle n a)) := by
  have compute (n a : A) := schemaInstance a (fun _ _ => rfl) n
  constructor
  · exact (compute zero zero).1
  constructor
  · intro n a
    exact (compute n a).2.1
  · intro n a
    cases (compute n a).2.2 with
    | inl hz => exact Or.inl hz
    | inr hm => exact Or.inr hm.2

/-- The old adjacent propagation is a direct constructive projection. -/
theorem propagation_project (zero : A) (succ : A → A)
    (term : A → A → A) (reset middle : A → A → Prop)
    (schemaInstance : SharedRootAt zero succ term reset middle) :
    AdjacentPropagation zero succ term := by
  intro a progress n
  cases (schemaInstance a progress n).2.2 with
  | inl hz => exact Or.inl hz
  | inr hm => exact Or.inr hm.1

/-- Two root-guarded conclusions share one disjunction, intuitionistically. -/
theorem shared_root_conjoin (P E M : Prop)
    (first : P ∨ E) (second : P ∨ M) : P ∨ (E ∧ M) := by
  cases first with
  | inl hp => exact Or.inl hp
  | inr he =>
    cases second with
    | inl hp => exact Or.inl hp
    | inr hm => exact Or.inr ⟨he, hm⟩

/-- Reconstruct the exact envelope from its three extracted components. -/
theorem envelope_from_parts (zero : A) (succ : A → A)
    (term : A → A → A) (reset middle : A → A → Prop)
    (separation : zero ≠ succ zero)
    (resetAll : ∀ n a, reset n a)
    (guardedMiddle : ∀ n a, n = zero ∨ middle n a)
    (propagation : AdjacentPropagation zero succ term) :
    SharedRootAt zero succ term reset middle := by
  intro a progress n
  exact ⟨separation, resetAll n a,
    shared_root_conjoin _ _ _ (propagation a progress n) (guardedMiddle n a)⟩

/-- Guarded constant-one computation yields q(2,0)=1 using separation alone. -/
theorem constant_one_at_two (zero : A) (succ : A → A)
    (q : A → A → A) (separation : zero ≠ succ zero)
    (guardedQ : ∀ n a, n = zero ∨ q (succ n) a = succ zero) :
    q (succ (succ zero)) zero = succ zero := by
  cases guardedQ (succ zero) zero with
  | inl hz => exact False.elim (separation hz.symm)
  | inr he => exact he

/-- Reset plus guarded constant-one computation recovers BOTH delayed seeds. -/
theorem delayed_seeds (zero : A) (succ : A → A)
    (d q : A → A → A)
    (separation : zero ≠ succ zero)
    (resetD : ∀ n a, d (q n zero) a = a)
    (resetQ : ∀ n a, q (q n zero) a = a)
    (guardedQ : ∀ n a, n = zero ∨ q (succ n) a = succ zero) :
    (∀ a, d zero a = a) ∧ (∀ a, d (succ zero) a = a) := by
  have qTwo : q (succ (succ zero)) zero = succ zero :=
    constant_one_at_two zero succ q separation guardedQ
  have seedOne : ∀ a, d (succ zero) a = a := by
    intro a
    have result := resetD (succ (succ zero)) a
    rw [qTwo] at result
    exact result
  have qOne : q (succ zero) zero = zero := by
    have result := resetQ (succ (succ zero)) zero
    rw [qTwo] at result
    exact result
  have seedZero : ∀ a, d zero a = a := by
    intro a
    have result := resetD (succ zero) a
    rw [qOne] at result
    exact result
  exact ⟨seedZero, seedOne⟩

/--
Successor nonzeroness comes BEFORE predecessor, coverage, or induction.
Apply the constant-zero guarded recurrence at the initial state 1.
-/
theorem successor_nonzero (zero : A) (succ : A → A)
    (dZero : A → A → A)
    (separation : zero ≠ succ zero)
    (seedZero : ∀ a, dZero zero a = a)
    (guardedZero : ∀ n a, n = zero ∨ dZero (succ n) a = zero) :
    ∀ n, succ n ≠ zero := by
  intro n hn
  cases guardedZero n (succ zero) with
  | inl hz =>
    have collapse : succ zero = zero := by
      rw [hz] at hn
      exact hn
    exact separation collapse.symm
  | inr he =>
    rw [hn, seedZero] at he
    exact separation he.symm

/-- Guarded one-step computation at a successor yields the old unguarded Tail. -/
theorem old_tail_recover (zero : A) (succ h : A → A)
    (d : A → A → A)
    (nonzero : ∀ n, succ n ≠ zero)
    (guardedMiddle : ∀ n a,
      n = zero ∨ d (succ n) a = h (d n a)) :
    ∀ n a, d (succ (succ n)) a = h (d (succ n) a) := by
  intro n a
  cases guardedMiddle (succ n) a with
  | inl hz => exact False.elim (nonzero n hz)
  | inr hm => exact hm

/-- Old coverage and Tail recover the new root-guarded one-step computation. -/
theorem guarded_middle_from_old (zero : A) (succ pred h : A → A)
    (d : A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (tail : ∀ n a, d (succ (succ n)) a = h (d (succ n) a)) :
    ∀ n a, n = zero ∨ d (succ n) a = h (d n a) := by
  intro n a
  cases coverage n with
  | inl hz => exact Or.inl hz
  | inr hs =>
    apply Or.inr
    have result := tail (pred n) a
    rw [← hs] at result
    exact result

/-- The old components therefore prove the exact new selected instance. -/
theorem new_instance_from_old (zero : A) (succ pred h : A → A)
    (term d q : A → A → A)
    (separation : zero ≠ succ zero)
    (reset : ∀ n a, d (q n zero) a = a)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (tail : ∀ n a, d (succ (succ n)) a = h (d (succ n) a))
    (propagation : AdjacentPropagation zero succ term) :
    SharedRootAt zero succ term
      (fun n a => d (q n zero) a = a)
      (fun n a => d (succ n) a = h (d n a)) := by
  exact envelope_from_parts zero succ term _ _ separation reset
    (guarded_middle_from_old zero succ pred h d coverage tail) propagation

#print axioms computation_extract
#print axioms propagation_project
#print axioms shared_root_conjoin
#print axioms envelope_from_parts
#print axioms constant_one_at_two
#print axioms delayed_seeds
#print axioms successor_nonzero
#print axioms old_tail_recover
#print axioms guarded_middle_from_old
#print axioms new_instance_from_old

end GuardedTailKernel
