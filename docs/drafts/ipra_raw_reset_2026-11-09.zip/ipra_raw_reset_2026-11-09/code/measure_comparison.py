"""Recompute complete-source and declared term-pattern measurements.

The inherited normalizer is loaded unchanged. All executable source,
including parsers, imports, fixed descriptions and CLI code, is charged.
"""
import ast
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def load_normalizer():
    path = ROOT / "reference" / "source_measure.py"
    spec = importlib.util.spec_from_file_location("frozen_source_measure", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def controlled_change(new_path, old_path):
    new_tree = ast.parse(new_path.read_text())
    old_tree = ast.parse(old_path.read_text())
    new_functions = [n for n in new_tree.body
                     if isinstance(n, ast.FunctionDef) and n.name == "reset_argument"]
    old_functions = [n for n in old_tree.body
                     if isinstance(n, ast.FunctionDef) and n.name == "reset_argument"]
    if len(new_functions) != 1 or len(old_functions) != 1:
        raise ValueError("The reset builder must occur exactly once in both sources.")
    new_function, old_function = new_functions[0], old_functions[0]
    expected_new = "return choose(epsilon(value, anchor), successor(index), zero())"
    expected_old = ("return choose(choose(epsilon(value, value), "
                    "epsilon(value, anchor), zero()), successor(index), zero())")
    for actual, expected in ((new_function.body, expected_new),
                             (old_function.body, expected_old)):
        if ast.dump(ast.Module(body=actual, type_ignores=[])) != ast.dump(ast.parse(expected)):
            raise ValueError("Unexpected arithmetic reset implementation.")
    new_tree.body[new_tree.body.index(new_function)] = old_function
    if ast.dump(new_tree) != ast.dump(old_tree):
        raise ValueError("The comparison changes executable code outside reset_argument.")
    return True


class ShortenInterface(ast.NodeTransformer):
    mapping = {"inst": "i", "check": "c", "take": "q"}

    def visit_Name(self, node):
        node.id = self.mapping.get(node.id, node.id)
        return node

    def visit_FunctionDef(self, node):
        node.name = self.mapping.get(node.name, node.name)
        return self.generic_visit(node)


def node_count(term):
    """A tuple is one operator node followed by its children; strings are leaves."""
    return 1 if isinstance(term, str) else 1 + sum(node_count(t) for t in term[1:])


def main():
    normalizer = load_normalizer()
    manifest_path = ROOT / "reference" / "checker_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    rows = []
    for entry in manifest["programs"]:
        measurement = normalizer.metrics(ROOT / entry["file"])
        if measurement["sha256"] != entry["sha256"]:
            raise ValueError("Changed frozen comparator: " + entry["file"])
        rows.append({**entry, **measurement})
    new_path = ROOT / "code" / "complete_checker.py"
    old_path = ROOT / "code" / "complete_checker_old_reset.py"
    exact_control = controlled_change(new_path, old_path)
    new_measurement = normalizer.metrics(new_path)
    old_measurement = normalizer.metrics(old_path)
    shortest = {field: min(row[field] for row in rows) for field in FIELDS}
    attainers = {field: [row["file"] for row in rows if row[field] == shortest[field]]
                 for field in FIELDS}
    difference = {field: old_measurement[field] - new_measurement[field] for field in FIELDS}

    short_tree = ShortenInterface().visit(ast.parse(
        (ROOT / "reference/checkers/compact_open.py").read_text()))
    with tempfile.TemporaryDirectory(prefix="ipra-naming-control-") as directory:
        renamed_path = Path(directory) / "compact_open.py"
        renamed_path.write_text(ast.unparse(ast.fix_missing_locations(short_tree)) + "\n")
        naming_control = normalizer.metrics(renamed_path)

    # Named-macro term trees: f is unary, epsilon binary, C ternary.
    fz = ("f", "z")
    f1 = ("f", ("S", "0"))
    old_pattern = ("C", ("C", ("epsilon", fz, fz),
                          ("epsilon", fz, f1), "0"), ("S", "z"), "0")
    new_pattern = ("C", ("epsilon", fz, f1), ("S", "z"), "0")
    patterns = {"old": old_pattern, "new": new_pattern,
                "old_nodes": node_count(old_pattern), "new_nodes": node_count(new_pattern),
                "convention": "One node per named operator/application or variable/zero; 1 expanded as S0; trees, not DAGs. C and epsilon not expanded."}
    receipt = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "commit": manifest["commit"],
        "whole_source_boundary": True,
        "normalizer_sha256": hashlib.sha256((ROOT / "reference/source_measure.py").read_bytes()).hexdigest(),
        "frozen_program_count": len(rows),
        "frozen_minimum": shortest,
        "minimum_attainers": attainers,
        "controlled_change_verified": exact_control,
        "old_direct_checker": old_measurement,
        "new_direct_checker": new_measurement,
        "controlled_saving": difference,
        "new_checker_below_frontier": {field: new_measurement[field] < shortest[field] for field in FIELDS},
        "naming_control": {"source": "reference/checkers/compact_open.py",
                           "uniform_renaming": ShortenInterface.mapping,
                           "measurement": naming_control},
        "term_patterns": patterns,
        "comparators": rows,
        "scope": "Empirical whole-program source counts, not a theorem giving an absolute mathematical lower bound."
    }
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    (evidence / "metrics_summary.json").write_text(json.dumps(receipt, indent=2) + "\n")
    with (evidence / "comparator_metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["file", *FIELDS, "source_tokens", "raw_bytes", "sha256"],
                                extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    def table_row(label, measurement):
        return label + " & " + " & ".join(f"{measurement[field]:,}" for field in FIELDS) + r"\\" + "\n"

    table = [r"\begin{center}" + "\n",
             r"\begin{tabular}{@{}lrrr@{}}" + "\n",
             r"\toprule" + "\n",
             r"Complete standalone source & Tokens & AST nodes & Bytes\\" + "\n",
             r"\midrule" + "\n",
             table_row("Existing native frontier", shortest),
             table_row("Matched old reset control", old_measurement),
             table_row("New raw reset implementation", new_measurement),
             r"\midrule" + "\n",
             table_row("Controlled saving (old minus new)", difference),
             r"\bottomrule" + "\n",
             r"\end{tabular}" + "\n",
             r"\end{center}" + "\n"]
    (evidence / "metrics_summary.tex").write_text("".join(table))
    print(json.dumps({key: receipt[key] for key in (
        "python", "frozen_program_count", "frozen_minimum", "controlled_change_verified",
        "controlled_saving", "new_checker_below_frontier")}, indent=2))
    print("Term pattern nodes: " + str(patterns["old_nodes"]) + " -> " + str(patterns["new_nodes"]))
    print("Uniformly shortened compact_open.py bytes: " + str(naming_control["normalized_bytes"]))


if __name__ == "__main__":
    main()
