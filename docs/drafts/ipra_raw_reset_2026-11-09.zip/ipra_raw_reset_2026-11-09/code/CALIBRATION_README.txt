RAW-TEST RESET CALIBRATION: SYMBOLIC CERTIFICATE SCOPE

Run:
  python3 make_calibration.py
  python3 replay_calibration.py
  python3 verify_calibration.py

The producer writes a finite natural-deduction certificate. It does not
import the replayer. The independent replayer reconstructs each conclusion,
checks all numerical arities, substitution, equality motives, hypotheses,
branch scopes, universal eigenvariables, and the exact proposed rule.

There are four exported, universally closed theorems, in dependency order:
  spike_collapse: epsilon(a,a)=1 -> b=a.
  diagonal: epsilon(a,a)=0.
  reflection: epsilon(a,b)=0 -> a=b.
  CAL: (epsilon(a,b)=0 -> a=b) and (a=b -> epsilon(a,b)=0).

Only earlier, fully verified closed exports may be used as lemmas.
The local 'let' node is ordinary cut: its value must be proved in the
retained context before the body may use it as an additional hypothesis.
Equality symmetry is a derived ordinary equality inference accepted as
an explicit abbreviation by this readable fragment replayer.

Exactly seven nonlogical endpoint/range schemas are trusted:
  BR: sg(t)=0 or sg(t)=1.
  sg(0)=0, sg(Sn)=1.
  p(0)=0, p(Sn)=n.
  C(0,a,b)=a, C(Sn,a,b)=b.

epsilon(a,b) is represented literally as sg(w(a,b)). The binary symbol w
has NO trusted equation and NO interpreter. The certified proof is generic
for every fixed binary numerical term w. In the complete paper instantiate
w(a,b)=K(Sa dotminus b), K(r)=C(r,1,p(r)). Thus this representation does
not grant an equality oracle, diagonal theorem, or evaluator to the proof.

The ONE arithmetic inference trusted by this fragment is the proposed
plain raw-reset rule RR itself:
  c=f(1), rho(z)=C(epsilon(f(z),c),Sz,0);
  from f(rho(z))=c infer f(t)=c,
with the stated freshness and fixed-template restrictions. The rule's
anchor and reset image are recomputed from its template; redundant
certificate audit fields must agree literally. They are not trusted.

The library uses two RR nodes: one in spike_collapse and one in reflection.
The diagonal and CAL exports use previously checked lemmas. Proof-node totals count
each export once and count theorem references as reference nodes, not as
copies of the referenced derivation. No claim is made about shortest proofs.

NOT trusted or available: ordinary induction, separation, falsity,
explosion, equality reflection, diagonal normalization, numerical coverage,
decisions of actual arbitrary numerical equality, or numerical sampling.

The verified content is calibration FROM the proposed rule. The separate
paper proof that iPRA validates this rule, the full PR-description scheme,
and the complete bi-interpretation metatheory are outside this certificate.
This program is not a complete iPRA checker and is not a size competitor.

Verification includes normal and optimized Python acceptance and twenty
deliberate corruptions in both modes. These guard the anchor, zero reset,
fresh variable, retained context, assumptions, branch discharge, exact
conclusions, trusted inventory, and closed-lemma dependencies. Finite
negative tests supplement the written soundness argument; they do not
prove a Python implementation correct for every input or resource limit.

Attribution: ordinary ND/substitution and equality-producer patterns were
adapted from make_anchored_reflection.py, replay_anchored_reflection.py,
and replay_reset_certificate.py in the pinned ProveIt archive
ipra_package_reconstructed.zip / ipra_reset_2026-11-08. The isolated-spike
calibration, exact raw-test zero-reset profile, proof library, strict
node checks, and generated certificate are new to this package. Repository
snapshot identifiers and upstream attribution are recorded in the report.
