"""Produce four symbolic raw-test calibration proofs as untrusted JSON data.

This producer does not import or invoke the replayer. It contains no
numerical evaluation. Its equality-proof construction helpers are adapted
from the pinned ipra_reset_2026-11-08 producer, with attribution. The two
ramp arguments and every generated raw-reset inference are new here.
"""
import json
from pathlib import Path

Z = ["zero"]
ONE = ["S", Z]
TWO = ["S", ONE]


def V(name): return ["var", name]
def S(t): return ["S", t]
def C(v, a, b): return ["C", v, a, b]
def sg(t): return ["sg", t]
def p(t): return ["p", t]
def w(a, b): return ["w", a, b]
def raw(a, b): return sg(w(a, b))
def eq(a, b): return ["eq", a, b]


def replace(term, image):
    if term == V("hole"):
        return image
    if term[0] == "var":
        return term
    return [term[0], *(replace(child, image) for child in term[1:])]


class Equation:
    def __init__(self, left, right, proof):
        self.left, self.right, self.proof = left, right, proof

    def then(self, other):
        if self.right != other.left:
            raise ValueError("Producer transitivity mismatch")
        return Equation(self.left, other.right, {
            "rule": "eq_e", "equality": other.proof, "body": self.proof,
            "variable": "hole", "template": eq(self.left, V("hole")),
        })

    def sym(self):
        return Equation(self.right, self.left, {"rule": "eq_sym", "proof": self.proof})

    def through(self, template):
        left, right = replace(template, self.left), replace(template, self.right)
        return Equation(left, right, {
            "rule": "eq_e", "equality": self.proof,
            "body": {"rule": "eq_refl", "term": left},
            "variable": "hole", "template": eq(left, template),
        })


def hypothesis(name, left, right):
    return Equation(left, right, {"rule": "hyp", "name": name})


def axiom(name, args, left, right):
    return Equation(left, right, {"rule": "axiom", "name": name, "terms": args})


def c0(a, b): return axiom("C_zero", [a, b], C(Z, a, b), a)
def cs(n, a, b): return axiom("C_successor", [n, a, b], C(S(n), a, b), b)
def sign0(): return axiom("sg_zero", [], sg(Z), Z)
def signs(n): return axiom("sg_successor", [n], sg(S(n)), ONE)
def pred0(): return axiom("p_zero", [], p(Z), Z)
def preds(n): return axiom("p_successor", [n], p(S(n)), n)


def split_sign(t, name0, proof0, name1, proof1):
    if proof0.left != proof1.left or proof0.right != proof1.right:
        raise ValueError("Producer branch mismatch")
    return Equation(proof0.left, proof0.right, {
        "rule": "or_e", "major": {"rule": "axiom", "name": "BR", "terms": [t]},
        "left_name": name0, "left": proof0.proof,
        "right_name": name1, "right": proof1.proof,
    })


def generalize(names, proof):
    for name in reversed(names):
        proof = {"rule": "all_i", "variable": name, "proof": proof}
    return proof


def specialize(name, terms):
    result = {"rule": "lemma", "name": name}
    for t in terms:
        result = {"rule": "all_e", "proof": result, "term": t}
    return result


def apply(major, minor):
    return {"rule": "imp_e", "major": major, "minor": minor}


def reset(template, target, anchor, image, premise):
    return {"rule": "raw_reset", "matrix_variable": "x", "eigenvariable": "z",
            "template": template, "target": target, "anchor": anchor,
            "image": image, "proof": premise.proof}


a, b, x, z = V("a"), V("b"), V("x"), V("z")


def inner(t): return C(sg(p(t)), ONE, sg(p(p(t))))
def spike(t): return C(inner(t), b, a)


# H(0)=H(1)=a and H(2)=b. No coverage or induction is used.
q0 = pred0().through(sg(V("hole"))).then(sign0())
q1 = preds(Z).through(sg(V("hole"))).then(sign0())
q2 = preds(ONE).through(sg(V("hole"))).then(signs(Z))
r2 = preds(ONE).through(p(V("hole"))).then(preds(Z)).through(sg(V("hole"))).then(sign0())
h0 = (q0.through(C(V("hole"), ONE, sg(p(p(Z)))))
      .then(c0(ONE, sg(p(p(Z))))).through(C(V("hole"), b, a)).then(cs(Z, b, a)))
h1 = (q1.through(C(V("hole"), ONE, sg(p(p(ONE)))))
      .then(c0(ONE, sg(p(p(ONE))))).through(C(V("hole"), b, a)).then(cs(Z, b, a)))
h2 = (q2.through(C(V("hole"), ONE, sg(p(p(TWO)))))
      .then(cs(Z, ONE, sg(p(p(TWO))))).then(r2)
      .through(C(V("hole"), b, a)).then(c0(b, a)))

qz, rz = sg(p(z)), sg(p(p(z)))
level0 = hypothesis("level_zero", qz, Z)
level1 = hypothesis("level_one", qz, ONE)
lower0 = hypothesis("lower_zero", rz, Z)
lower1 = hypothesis("lower_one", rz, ONE)
inner0 = level0.through(C(V("hole"), ONE, rz)).then(c0(ONE, rz))
inner1 = level1.through(C(V("hole"), ONE, rz)).then(cs(Z, ONE, rz))
hz_a0 = inner0.through(C(V("hole"), b, a)).then(cs(Z, b, a))
hz_a1 = inner1.then(lower1).through(C(V("hole"), b, a)).then(cs(Z, b, a))
hz_b = inner1.then(lower0).through(C(V("hole"), b, a)).then(c0(b, a))

# If sg(p(z))=1 then H(Sz)=a, by finite endpoint rewriting and BR(sg(z)).
inner_s = (preds(z).through(sg(V("hole")))
           .through(C(V("hole"), ONE, sg(p(p(S(z))))))
           .then(preds(z).through(sg(p(V("hole")))).through(C(sg(z), ONE, V("hole"))))
           .then(level1.through(C(sg(z), ONE, V("hole")))))
constant0 = hypothesis("sign_zero", sg(z), Z).through(C(V("hole"), ONE, ONE)).then(c0(ONE, ONE))
constant1 = hypothesis("sign_one", sg(z), ONE).through(C(V("hole"), ONE, ONE)).then(cs(Z, ONE, ONE))
constant = split_sign(z, "sign_zero", constant0, "sign_one", constant1)
hs_a = inner_s.then(constant).through(C(V("hole"), b, a)).then(cs(Z, b, a))

rho_h = C(raw(spike(z), spike(ONE)), S(z), Z)


def baseline_premise(hz_a):
    guard = (hz_a.through(raw(V("hole"), spike(ONE)))
             .then(h1.through(raw(a, V("hole"))))
             .then(hypothesis("failed_diagonal", raw(a, a), ONE)))
    image = guard.through(C(V("hole"), S(z), Z)).then(cs(Z, S(z), Z))
    return image.through(spike(V("hole"))).then(h0).then(h1.sym())


base0, base1 = baseline_premise(hz_a0), baseline_premise(hz_a1)
spike_guard = (hz_b.through(raw(V("hole"), spike(ONE)))
               .then(h1.through(raw(b, V("hole")))))
spike_image0 = (spike_guard.then(hypothesis("test_zero", raw(b, a), Z))
                .through(C(V("hole"), S(z), Z)).then(c0(S(z), Z)))
spike_image1 = (spike_guard.then(hypothesis("test_one", raw(b, a), ONE))
                .through(C(V("hole"), S(z), Z)).then(cs(Z, S(z), Z)))
spike_case0 = spike_image0.through(spike(V("hole"))).then(hs_a).then(h1.sym())
spike_case1 = spike_image1.through(spike(V("hole"))).then(h0).then(h1.sym())
spike_case = split_sign(w(b, a), "test_zero", spike_case0, "test_one", spike_case1)
level_case1 = split_sign(p(p(z)), "lower_zero", spike_case, "lower_one", base1)
premise_h = split_sign(p(z), "level_zero", base0, "level_one", level_case1)
reset_h = Equation(spike(TWO), spike(ONE), reset(spike(x), TWO, spike(ONE), rho_h, premise_h))
collapsed = h2.sym().then(reset_h).then(h1)
collapse = {"rule": "imp_i", "name": "failed_diagonal", "assumption": eq(raw(a, a), ONE),
            "proof": collapsed.proof}

# Diagonal first: a failed diagonal forces every b=a by the checked spike
# lemma. Taking b=0 and b=epsilon(a,a) yields the desired zero directly.
to_a = Equation(b, a, apply(specialize("spike_collapse", [a, b]),
                            {"rule": "hyp", "name": "bad_diagonal"}))
all_to_a = generalize(["b"], to_a.proof)
c = raw(a, a)
zero_to_a = Equation(Z, a, {"rule": "all_e", "proof": {"rule": "hyp", "name": "all_to_a"}, "term": Z})
c_to_a = Equation(c, a, {"rule": "all_e", "proof": {"rule": "hyp", "name": "all_to_a"}, "term": c})
c_to_zero = c_to_a.then(zero_to_a.sym())
bad_branch = Equation(c, Z, {"rule": "let", "name": "all_to_a", "proof": all_to_a,
                            "body": c_to_zero.proof})
diagonal = split_sign(w(a, a), "good_diagonal", hypothesis("good_diagonal", c, Z),
                      "bad_diagonal", bad_branch)


def ramp(t): return C(sg(t), a, b)


# The ordinary ramp now reflects equality, using the established diagonal.
at0 = sign0().through(C(V("hole"), a, b)).then(c0(a, b))
at1 = signs(Z).through(C(V("hole"), a, b)).then(cs(Z, a, b))
ats = signs(z).through(C(V("hole"), a, b)).then(cs(Z, a, b))
rho_f = C(raw(ramp(z), ramp(ONE)), S(z), Z)
ramp0 = hypothesis("ramp_zero", sg(z), Z).through(C(V("hole"), a, b)).then(c0(a, b))
ramp1 = hypothesis("ramp_one", sg(z), ONE).through(C(V("hole"), a, b)).then(cs(Z, a, b))
guard0 = (ramp0.through(raw(V("hole"), ramp(ONE)))
          .then(at1.through(raw(a, V("hole"))))
          .then(hypothesis("test_equal", raw(a, b), Z)))
guard1 = (ramp1.through(raw(V("hole"), ramp(ONE)))
          .then(at1.through(raw(b, V("hole"))))
          .then(Equation(raw(b, b), Z, specialize("diagonal", [b]))))
guard_f = split_sign(z, "ramp_zero", guard0, "ramp_one", guard1)
image_f = guard_f.through(C(V("hole"), S(z), Z)).then(c0(S(z), Z))
premise_f = image_f.through(ramp(V("hole"))).then(ats).then(at1.sym())
reset_f = Equation(ramp(Z), ramp(ONE), reset(ramp(x), Z, ramp(ONE), rho_f, premise_f))
reflected = at0.sym().then(reset_f).then(at1)
reflection = {"rule": "imp_i", "name": "test_equal", "assumption": eq(raw(a, b), Z),
              "proof": reflected.proof}

# Full calibration joins reflection with substitution into the diagonal.
diag_at_a = Equation(raw(a, a), Z, specialize("diagonal", [a]))
back_eq = (hypothesis("actual_equal", a, b).sym().through(raw(a, V("hole")))
           .then(diag_at_a))
back = {"rule": "imp_i", "name": "actual_equal", "assumption": eq(a, b), "proof": back_eq.proof}
cal = {"rule": "and_i", "left": specialize("reflection", [a, b]), "right": back}
forward_formula = ["imp", eq(raw(a, b), Z), eq(a, b)]
back_formula = ["imp", eq(a, b), eq(raw(a, b), Z)]

claims = [
    {"name": "spike_collapse", "conclusion": ["all", "a", ["all", "b", ["imp", eq(raw(a, a), ONE), eq(b, a)]]],
     "proof": generalize(["a", "b"], collapse)},
    {"name": "diagonal", "conclusion": ["all", "a", eq(raw(a, a), Z)],
     "proof": generalize(["a"], diagonal.proof)},
    {"name": "reflection", "conclusion": ["all", "a", ["all", "b", forward_formula]],
     "proof": generalize(["a", "b"], reflection)},
    {"name": "CAL", "conclusion": ["all", "a", ["all", "b", ["and", forward_formula, back_formula]]],
     "proof": generalize(["a", "b"], cal)},
]
payload = {
    "format": "raw-reset-calibration-nd-v1",
    "scope": "Symbolic isolated-spike and ramp calibration; the proposed raw-reset rule is trusted, no induction or Sep.",
    "trusted_axiom_schemas": ["BR", "sg_zero", "sg_successor", "p_zero", "p_successor", "C_zero", "C_successor"],
    "trusted_arithmetic_rule": "raw_reset", "claims": claims,
}
destination = Path(__file__).with_name("calibration_certificate.json")
destination.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
print(destination)
