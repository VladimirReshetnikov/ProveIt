"""Independent symbolic replayer for raw-test reset calibration.

This verifies four fixed mathematical claims, not a complete iPRA checker.
The only nonlogical resources are BR, the C/sg/p endpoint equations, and
the explicitly proposed plain raw-reset rule. No equality-reflection axiom,
diagonal normalization, induction, separation, falsity, or numerical
evaluation is available. The arbitrary binary w represents the fixed
residual term in epsilon(a,b)=sg(w(a,b)); no axiom about w is used.

The ordinary natural-deduction engine is adapted, with attribution, from
the pinned ProveIt ipra_reset_2026-11-08 symbolic replayer. The arithmetic
profile, rule, claims, proof-library handling, and strict node validation
are specific to this package. The producer is not imported.
"""
import json
import re
import sys
from collections import Counter
from pathlib import Path

AXIOMS = ["BR", "sg_zero", "sg_successor", "p_zero", "p_successor",
          "C_zero", "C_successor"]
TERM_ARITIES = {"zero": 0, "S": 1, "C": 3, "sg": 1, "p": 1, "w": 2}
CONNECTIVES = {"imp", "and", "or"}
ZERO = ["zero"]
ONE = ["S", ZERO]


class InvalidCertificate(ValueError):
    pass


def require(test, message):
    if not test:
        raise InvalidCertificate(message)


def identifier(value):
    return type(value) is str and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value) is not None


def exact_keys(node, names):
    require(set(node) == {"rule", *names}, "Unexpected or missing proof-node fields")


def term(value):
    require(type(value) is list and value and type(value[0]) is str,
            "Term must be a tagged array")
    tag = value[0]
    if tag == "var":
        require(len(value) == 2 and identifier(value[1]), "Malformed numerical variable")
    else:
        require(tag in TERM_ARITIES and len(value) == TERM_ARITIES[tag] + 1,
                "Numerical arity mismatch")
        for child in value[1:]:
            term(child)
    return value


def formula(value):
    require(type(value) is list and value and type(value[0]) is str,
            "Formula must be a tagged array")
    tag = value[0]
    if tag == "eq":
        require(len(value) == 3, "Equation arity mismatch")
        term(value[1]); term(value[2])
    elif tag in CONNECTIVES:
        require(len(value) == 3, "Connective arity mismatch")
        formula(value[1]); formula(value[2])
    elif tag == "all":
        require(len(value) == 3 and identifier(value[1]), "Malformed universal binder")
        formula(value[2])
    else:
        raise InvalidCertificate("Unknown formula constructor")
    return value


def term_variables(value):
    if value[0] == "var":
        return {value[1]}
    result = set()
    for child in value[1:]:
        result |= term_variables(child)
    return result


def free_variables(value):
    if value[0] == "eq":
        return term_variables(value[1]) | term_variables(value[2])
    if value[0] == "all":
        return free_variables(value[2]) - {value[1]}
    return free_variables(value[1]) | free_variables(value[2])


def all_names(value):
    result = free_variables(value)
    if value[0] == "all":
        return result | {value[1]} | all_names(value[2])
    if value[0] in CONNECTIVES:
        return result | all_names(value[1]) | all_names(value[2])
    return result


def substitute_term(value, variable, image):
    if value[0] == "var":
        return image if value[1] == variable else value
    return [value[0], *(substitute_term(x, variable, image) for x in value[1:])]


def substitute(value, variable, image):
    tag = value[0]
    if tag == "eq":
        return [tag, substitute_term(value[1], variable, image),
                substitute_term(value[2], variable, image)]
    if tag in CONNECTIVES:
        return [tag, substitute(value[1], variable, image),
                substitute(value[2], variable, image)]
    bound, body = value[1], value[2]
    if bound == variable:
        return value
    if bound in term_variables(image) and variable in free_variables(body):
        used = all_names(body) | term_variables(image) | {variable, bound}
        new = bound + "_fresh"
        while new in used:
            new += "_fresh"
        body = substitute(body, bound, ["var", new])
        bound = new
    return ["all", bound, substitute(body, variable, image)]


def raw(a, b):
    return ["sg", ["w", a, b]]


def axiom(name, arguments):
    require(type(arguments) is list, "Axiom arguments must be an array")
    for argument in arguments:
        term(argument)
    if name == "BR":
        require(len(arguments) == 1, "BR takes one term")
        sign = ["sg", arguments[0]]
        return ["or", ["eq", sign, ZERO], ["eq", sign, ONE]]
    if name in {"sg_zero", "p_zero"}:
        require(not arguments, "Zero endpoint takes no arguments")
        symbol = "sg" if name == "sg_zero" else "p"
        return ["eq", [symbol, ZERO], ZERO]
    if name in {"sg_successor", "p_successor"}:
        require(len(arguments) == 1, "Successor endpoint takes one term")
        n = arguments[0]
        symbol = "sg" if name == "sg_successor" else "p"
        output = ONE if name == "sg_successor" else n
        return ["eq", [symbol, ["S", n]], output]
    if name == "C_zero":
        require(len(arguments) == 2, "C_zero takes two terms")
        a, b = arguments
        return ["eq", ["C", ZERO, a, b], a]
    if name == "C_successor":
        require(len(arguments) == 3, "C_successor takes three terms")
        n, a, b = arguments
        return ["eq", ["C", ["S", n], a, b], b]
    raise InvalidCertificate("Unlicensed arithmetic axiom: " + str(name))


def extend(context, name, assumption):
    require(identifier(name) and name not in context,
            "Hypothesis name is invalid or already active")
    return {**context, name: assumption}


def replay(node, context, counts, lemmas):
    require(type(node) is dict and type(node.get("rule")) is str,
            "Malformed proof node")
    rule = node["rule"]
    counts[rule] += 1

    def derive(proof, retained=None):
        return replay(proof, context if retained is None else retained, counts, lemmas)

    if rule == "hyp":
        exact_keys(node, ["name"])
        require(node["name"] in context, "Unbound hypothesis")
        return context[node["name"]]
    if rule == "lemma":
        exact_keys(node, ["name"])
        require(node["name"] in lemmas, "Unverified or forward theorem reference")
        return lemmas[node["name"]]
    if rule == "axiom":
        exact_keys(node, ["name", "terms"])
        return axiom(node["name"], node["terms"])
    if rule == "let":
        exact_keys(node, ["name", "proof", "body"])
        value = derive(node["proof"])
        return derive(node["body"], extend(context, node["name"], value))
    if rule == "imp_i":
        exact_keys(node, ["name", "assumption", "proof"])
        assumption = formula(node["assumption"])
        result = derive(node["proof"], extend(context, node["name"], assumption))
        return ["imp", assumption, result]
    if rule == "imp_e":
        exact_keys(node, ["major", "minor"])
        major, minor = derive(node["major"]), derive(node["minor"])
        require(major[0] == "imp" and major[1] == minor, "Implication antecedent mismatch")
        return major[2]
    if rule == "and_i":
        exact_keys(node, ["left", "right"])
        return ["and", derive(node["left"]), derive(node["right"])]
    if rule == "and_e":
        exact_keys(node, ["proof", "side"])
        result, side = derive(node["proof"]), node["side"]
        require(type(side) is int and side in (0, 1) and result[0] == "and",
                "Invalid conjunction projection")
        return result[side + 1]
    if rule == "or_e":
        exact_keys(node, ["major", "left_name", "left", "right_name", "right"])
        major = derive(node["major"])
        require(major[0] == "or", "Disjunction elimination major is not a disjunction")
        require(node["left_name"] != node["right_name"], "Branch names must be distinct")
        left = derive(node["left"], extend(context, node["left_name"], major[1]))
        right = derive(node["right"], extend(context, node["right_name"], major[2]))
        require(left == right, "Disjunction branches have different conclusions")
        return left
    if rule == "all_i":
        exact_keys(node, ["variable", "proof"])
        variable = node["variable"]
        require(identifier(variable), "Invalid eigenvariable")
        require(all(variable not in free_variables(a) for a in context.values()),
                "Universal eigenvariable occurs in retained context")
        return ["all", variable, derive(node["proof"])]
    if rule == "all_e":
        exact_keys(node, ["proof", "term"])
        result = derive(node["proof"])
        require(result[0] == "all", "Universal elimination major is not universal")
        return substitute(result[2], result[1], term(node["term"]))
    if rule == "eq_sym":
        exact_keys(node, ["proof"])
        result = derive(node["proof"])
        require(result[0] == "eq", "Symmetry premise is not an equation")
        return ["eq", result[2], result[1]]
    if rule == "eq_e":
        exact_keys(node, ["equality", "body", "variable", "template"])
        equality, result = derive(node["equality"]), derive(node["body"])
        require(equality[0] == "eq", "Transport premise is not an equation")
        variable = node["variable"]
        require(identifier(variable), "Invalid equality motive variable")
        template = formula(node["template"])
        require(result == substitute(template, variable, equality[1]),
                "Equality transport source mismatch")
        return substitute(template, variable, equality[2])
    if rule == "eq_refl":
        exact_keys(node, ["term"])
        value = term(node["term"])
        return ["eq", value, value]
    if rule == "raw_reset":
        exact_keys(node, ["matrix_variable", "eigenvariable", "template", "target",
                          "anchor", "image", "proof"])
        variable, eigenvariable = node["matrix_variable"], node["eigenvariable"]
        require(identifier(variable) and identifier(eigenvariable), "Invalid reset variables")
        require(variable != eigenvariable, "Template and eigenvariable must be distinct")
        template, target = term(node["template"]), term(node["target"])
        require(eigenvariable not in term_variables(template) - {variable},
                "Reset eigenvariable is a passive parameter")
        require(eigenvariable not in term_variables(target), "Reset eigenvariable occurs in target")
        require(all(eigenvariable not in free_variables(a) for a in context.values()),
                "Reset eigenvariable occurs in retained context")
        z = ["var", eigenvariable]
        anchor = substitute_term(template, variable, ONE)
        at_z = substitute_term(template, variable, z)
        image = ["C", raw(at_z, anchor), ["S", z], ZERO]
        require(term(node["anchor"]) == anchor, "Reset anchor must be exactly f(1)")
        require(term(node["image"]) == image, "Reset image must have raw test and zero branch")
        expected = ["eq", substitute_term(template, variable, image), anchor]
        require(derive(node["proof"]) == expected, "Reset premise does not match its exact template")
        return ["eq", substitute_term(template, variable, target), anchor]
    raise InvalidCertificate("Unlicensed inference rule: " + rule)


def expected_claims():
    a, b = ["var", "a"], ["var", "b"]
    test_zero, equal = ["eq", raw(a, b), ZERO], ["eq", a, b]
    forward = ["imp", test_zero, equal]
    backward = ["imp", equal, test_zero]
    return {
        "spike_collapse": ["all", "a", ["all", "b",
                           ["imp", ["eq", raw(a, a), ONE], ["eq", b, a]]]],
        "diagonal": ["all", "a", ["eq", raw(a, a), ZERO]],
        "reflection": ["all", "a", ["all", "b", forward]],
        "CAL": ["all", "a", ["all", "b", ["and", forward, backward]]],
    }


def verify(certificate):
    require(type(certificate) is dict and certificate.get("format") == "raw-reset-calibration-nd-v1",
            "Unknown certificate format")
    require(certificate.get("trusted_axiom_schemas") == AXIOMS, "Axiom inventory changed")
    require(certificate.get("trusted_arithmetic_rule") == "raw_reset", "Arithmetic rule changed")
    targets = expected_claims()
    claims = certificate.get("claims")
    require(type(claims) is list and len(claims) == len(targets), "Wrong exported claim count")
    require(all(type(row) is dict for row in claims), "Malformed claim list")
    require([row.get("name") for row in claims] == list(targets), "Claim names or dependency order changed")
    rows, lemmas = [], {}
    for claim in claims:
        require(type(claim) is dict and set(claim) == {"name", "conclusion", "proof"},
                "Malformed claim")
        name = claim["name"]
        declared = formula(claim["conclusion"])
        require(declared == targets[name] and not free_variables(declared), "Exact closed target changed")
        counts = Counter()
        require(replay(claim["proof"], {}, counts, lemmas) == declared,
                "Derived conclusion differs from exact target")
        lemmas[name] = declared
        rows.append({"name": name, "proof_nodes": sum(counts.values()),
                     "raw_reset_uses": counts["raw_reset"], "rules": dict(sorted(counts.items()))})
    return {"accepted": True, "claims": rows,
            "proof_nodes": sum(row["proof_nodes"] for row in rows),
            "raw_reset_uses": sum(row["raw_reset_uses"] for row in rows),
            "trusted_axioms": AXIOMS, "trusted_arithmetic_rule": "raw_reset",
            "trusted_epsilon_definition": "epsilon(a,b)=sg(w(a,b)); no axiom about w",
            "induction_or_separation_or_reflection_axiom_used": False,
            "numeric_sampling_used": False, "full_ipra_checker": False,
            "scope": "Symbolic calibration from the proposed raw-reset rule; not a full equivalence formalization."}


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("calibration_certificate.json")
    try:
        result = verify(json.loads(path.read_text(encoding="utf-8")))
    except (InvalidCertificate, KeyError, TypeError, IndexError, RecursionError, ValueError) as error:
        print(json.dumps({"accepted": False, "error": str(error)}))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
