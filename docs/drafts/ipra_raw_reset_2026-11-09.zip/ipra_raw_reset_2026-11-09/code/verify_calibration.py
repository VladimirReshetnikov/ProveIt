"""Replay the calibration library and focused deliberate corruptions.

This runs the public replayer in normal and optimized Python, checking
printed results and exit status. It never imports the proof producer or
changes the trusted arithmetic profile. This is a finite verifier audit,
not a proof of the replayer's correctness or full iPRA formalization.
"""
import copy
import hashlib
import json
import platform
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ZERO = ["zero"]
ONE = ["S", ZERO]


def nodes(value):
    if type(value) is dict:
        if "rule" in value:
            yield value
        for child in value.values():
            yield from nodes(child)
    elif type(value) is list:
        for child in value:
            yield from nodes(child)


def first(certificate, rule):
    return next(node for node in nodes(certificate) if node["rule"] == rule)


def changed_anchor(c):
    first(c, "raw_reset")["anchor"] = ZERO


def changed_reset_branch(c):
    first(c, "raw_reset")["image"][-1] = ["sg", ["var", "z"]]


def unlicensed_normalizer(c):
    node = first(c, "raw_reset")
    old_raw = node["image"][1]
    node["image"][1] = ["C", old_raw, old_raw, ZERO]


def retained_parameter_as_eigenvariable(c):
    first(c, "raw_reset")["eigenvariable"] = "a"


def target_escape(c):
    first(c, "raw_reset")["target"] = ["var", "z"]


def passive_escape(c):
    node = first(c, "raw_reset")
    node["template"] = ["C", ["sg", ["var", "x"]], ["var", "z"], ["var", "b"]]


def retained_context_escape(c):
    node = first(c, "raw_reset")
    body = copy.deepcopy(node)
    node.clear()
    node.update({"rule": "let", "name": "scope_poison",
                 "proof": {"rule": "eq_refl", "term": ["var", "z"]}, "body": body})


def changed_template(c):
    node = first(c, "raw_reset")
    node["template"] = ["S", node["template"]]


def forged_premise(c):
    first(c, "raw_reset")["proof"] = {"rule": "eq_refl", "term": ZERO}


def missing_assumption(c):
    first(c, "imp_i")["name"] = "removed_test_equal"


def wrong_assumption(c):
    first(c, "imp_i")["assumption"][-1] = ZERO


def erased_branch(c):
    first(c, "or_e")["right"] = {"rule": "eq_refl", "term": ZERO}


def branch_scope_escape(c):
    node = first(c, "or_e")
    node["right"] = {"rule": "hyp", "name": node["left_name"]}


def assumed_reflection(c):
    first(c, "axiom")["name"] = "equality_reflection"


def unlicensed_induction(c):
    first(c, "raw_reset")["rule"] = "equation_induction"


def added_separation(c):
    c["trusted_axiom_schemas"].append("separation")


def false_export(c):
    c["claims"][3]["conclusion"] = ["eq", ZERO, ONE]


def forward_lemma(c):
    c["claims"][0]["proof"] = {"rule": "lemma", "name": "spike_collapse"}


def malformed_numerical_term(c):
    first(c, "raw_reset")["target"] = True


def wrong_equality_motive(c):
    first(c, "eq_e")["template"] = ["eq", ["var", "hole"], ONE]


CONTROLS = [
    ("anchor_must_be_f_one", changed_anchor),
    ("sign_in_place_of_zero_reset", changed_reset_branch),
    ("diagonal_normalizer_not_in_rule", unlicensed_normalizer),
    ("retained_parameter_as_eigenvariable", retained_parameter_as_eigenvariable),
    ("eigenvariable_in_target", target_escape),
    ("eigenvariable_in_passive_parameters", passive_escape),
    ("eigenvariable_in_retained_context", retained_context_escape),
    ("changed_fixed_template", changed_template),
    ("forged_reset_premise", forged_premise),
    ("missing_retained_test_assumption", missing_assumption),
    ("changed_retained_test_assumption", wrong_assumption),
    ("erased_boolean_branch", erased_branch),
    ("boolean_branch_scope_escape", branch_scope_escape),
    ("reflection_used_as_axiom", assumed_reflection),
    ("unlicensed_equation_induction", unlicensed_induction),
    ("separation_added_to_profile", added_separation),
    ("false_exported_conclusion", false_export),
    ("unverified_forward_lemma", forward_lemma),
    ("boolean_as_numerical_term", malformed_numerical_term),
    ("changed_equality_motive", wrong_equality_motive),
]


def cli(path, optimized):
    command = [sys.executable] + (["-O"] if optimized else [])
    command += [str(ROOT / "replay_calibration.py"), str(path)]
    result = subprocess.run(command, capture_output=True, text=True, check=False)
    if not result.stdout:
        raise RuntimeError("Replayer produced no JSON result: " + result.stderr)
    return result.returncode, json.loads(result.stdout)


def main():
    certificate_path = ROOT / "calibration_certificate.json"
    original = json.loads(certificate_path.read_text(encoding="utf-8"))
    positives, negatives = [], []
    for optimized in (False, True):
        code, result = cli(certificate_path, optimized)
        if code != 0 or result.get("accepted") is not True or result.get("raw_reset_uses") != 2:
            raise RuntimeError("Correct calibration certificate failed")
        positives.append({"optimized": optimized, "exit_code": code, "result": result})
    with tempfile.TemporaryDirectory(prefix="raw-reset-controls-") as directory:
        for name, mutation in CONTROLS:
            changed = copy.deepcopy(original)
            mutation(changed)
            path = Path(directory) / (name + ".json")
            path.write_text(json.dumps(changed), encoding="utf-8")
            runs = []
            for optimized in (False, True):
                code, result = cli(path, optimized)
                if code != 1 or result.get("accepted") is not False:
                    raise RuntimeError("Damaged certificate accepted: " + name)
                runs.append({"optimized": optimized, "exit_code": code, "error": result.get("error")})
            negatives.append({"name": name, "rejected": True, "runs": runs})
    names = ["make_calibration.py", "replay_calibration.py", "calibration_certificate.json",
             "verify_calibration.py", "CALIBRATION_README.txt"]
    receipt = {
        "format": "raw-reset-calibration-receipt-v1", "python": platform.python_version(),
        "all_checks_passed": True, "positive_cli_runs": len(positives),
        "negative_controls": len(negatives), "negative_cli_runs": 2 * len(negatives),
        "proof_nodes": positives[0]["result"]["proof_nodes"], "raw_reset_uses": 2,
        "induction_or_separation_or_reflection_axiom_used": False,
        "numeric_sampling_used": False, "full_ipra_checker": False,
        "complete_checker_size_record": False,
        "positive_runs": positives, "rejection_controls": negatives,
        "sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in names},
    }
    destination = ROOT.parent / "evidence" / "calibration_results.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"receipt": str(destination), "all_checks_passed": True,
                      "positive_cli_runs": 2, "negative_controls": len(negatives),
                      "negative_cli_runs": 2 * len(negatives),
                      "proof_nodes": receipt["proof_nodes"], "raw_reset_uses": 2}, indent=2))


if __name__ == "__main__":
    main()
