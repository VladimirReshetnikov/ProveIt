#!/usr/bin/env python3
"""Untrusted fixtures, public-interface regression tests, and source measurements.

The acceptance program never imports this producer. Expected formulas and fixed
descriptions below are constructed independently of its inference functions.
"""
import ast
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tokenize


ROOT = Path(__file__).resolve().parent
CHECKER = ROOT / "complete_checker.py"
ZERO = ["0"]
ONE = ["S", ZERO]
TWO = ["S", ONE]
PRED = ["rec", ["zero", 0], ["proj", 2, 0]]
COND = ["rec", ["proj", 2, 0], ["proj", 4, 3]]
SG = ["rec", ["zero", 0], ["comp", 2, ["succ"], [["zero", 2]]]]
SUB = ["rec", ["proj", 1, 0], ["comp", 3, PRED, [["proj", 3, 1]]]]


def v(name):
    return ["v", name]


def s(t):
    return ["S", t]


def call(desc, *args):
    return ["app", desc, list(args)]


def e(left, right):
    return ["eq", left, right]


def node(rule, *premises, **fields):
    return {"rule": rule, **fields, "premises": list(premises)}


def hyp(index):
    return node("hyp", index=index)


def refl(t):
    return node("refl", term=t)


def forall(names, body):
    for name in reversed(names):
        body = ["all", name, body]
    return body


def generalize(names, proof):
    for name in reversed(names):
        proof = node("all_i", proof, var=name)
    return proof


def packet(goal, proof):
    return {"goal": goal, "proof": proof}


def replace_term(t, name, image):
    if t[0] == "v":
        return image if t[1] == name else t
    if t[0] == "0":
        return t
    if t[0] == "S":
        return s(replace_term(t[1], name, image))
    return call(t[1], *(replace_term(a, name, image) for a in t[2]))


def select(test, left, right):
    return call(COND, test, left, right)


def sign(t):
    return call(SG, t)


def epsilon(a, b):
    residual = call(SUB, b, s(a))
    return sign(select(residual, ONE, call(PRED, residual)))


def reset(value, anchor, index, old=False):
    comparison = epsilon(value, anchor)
    if old:
        comparison = select(epsilon(value, value), comparison, ZERO)
        return select(comparison, s(index), ZERO)
    return select(comparison, s(index), ZERO)


def sr_schema(template, target, parameters, old_premise=False,
              sign_fallback=False, anchor_term=ONE):
    x = "z"
    anchor = replace_term(template, x, anchor_term)
    rho = reset(template, anchor, v(x), old_premise)
    if sign_fallback:
        rho = select(epsilon(template, anchor), s(v(x)), sign(v(x)))
    premise_body = e(replace_term(template, x, rho), anchor)
    assumption = ["all", x, premise_body]
    proof = node("SR", node("all_e", hyp(0), term=v(x)),
                 var=x, template=template, at=target)
    goal = ["imp", assumption, e(replace_term(template, x, target), anchor)]
    return packet(forall(parameters, goal),
                  generalize(parameters, node("imp_i", proof, assume=assumption)))


def fixtures():
    positive = {}
    A, B = e(ZERO, ZERO), e(ONE, ONE)
    false_eq = e(ZERO, ONE)
    positive["reflexivity"] = packet(A, refl(ZERO))
    positive["hypothesis_discharge"] = packet(
        ["imp", false_eq, false_eq], node("imp_i", hyp(0), assume=false_eq))
    positive["falsity_elimination"] = packet(
        ["imp", ["bot"], false_eq],
        node("imp_i", node("bot_e", hyp(0), **{"as": false_eq}), assume=["bot"]))
    conjunction = node("and_i", refl(ZERO), refl(ONE))
    positive["conjunction_introduction"] = packet(["and", A, B], conjunction)
    positive["conjunction_projection"] = packet(B, node("and_e", conjunction, side=1))
    positive["disjunction_left"] = packet(["or", A, B], node("or_i", refl(ZERO), side=0, other=B))
    positive["disjunction_right"] = packet(["or", A, B], node("or_i", refl(ONE), side=1, other=A))
    disjunction = ["or", A, B]
    commutation = node("or_e", hyp(0),
                       node("or_i", hyp(1), side=1, other=B),
                       node("or_i", hyp(1), side=0, other=A))
    positive["disjunction_elimination"] = packet(
        ["imp", disjunction, ["or", B, A]], node("imp_i", commutation, assume=disjunction))
    implication = ["imp", A, B]
    positive["implication_elimination"] = packet(
        ["imp", implication, ["imp", A, B]],
        node("imp_i", node("imp_i", node("imp_e", hyp(0), hyp(1)), assume=A), assume=implication))
    all_refl = generalize(["x"], refl(v("x")))
    positive["universal_introduction"] = packet(forall(["x"], e(v("x"), v("x"))), all_refl)
    positive["universal_specialization"] = packet(B, node("all_e", all_refl, term=ONE))
    existential = ["ex", "x", e(v("x"), v("x"))]
    positive["existential_introduction"] = packet(
        existential, node("ex_i", refl(ZERO), var="x", body=e(v("x"), v("x")), term=ZERO))
    ex_constant = ["ex", "x", A]
    positive["existential_elimination"] = packet(
        ["imp", ex_constant, A],
        node("imp_i", node("ex_e", hyp(0), hyp(1), var="w"), assume=ex_constant))

    # The motive's bound b must be renamed when the equality target is free b.
    source_all = forall(["r"], e(v("a"), v("r")))
    target_all = forall(["q"], e(v("b"), v("q")))
    motive = forall(["b"], e(v("w"), v("b")))
    transported = node("transport", hyp(0), hyp(1), var="w", body=motive)
    positive["capture_avoiding_transport"] = packet(
        forall(["a", "b"], ["imp", e(v("a"), v("b")), ["imp", source_all, target_all]]),
        generalize(["a", "b"], node("imp_i", node("imp_i", transported, assume=source_all),
                                    assume=e(v("a"), v("b")))))

    compute_rows = [
        ("zero", ["zero", 2], [ZERO, ONE], ZERO),
        ("successor", ["succ"], [ZERO], ONE),
        ("projection", ["proj", 2, 1], [ZERO, ONE], ONE),
        ("composition", ["comp", 1, ["succ"], [["zero", 1]]], [ONE],
         call(["succ"], call(["zero", 1], ONE))),
        ("nullary_composition", ["comp", 0, ["succ"], [["zero", 0]]], [],
         call(["succ"], call(["zero", 0]))),
        ("empty_composition", ["comp", 2, ["zero", 0], []], [ZERO, ONE], call(["zero", 0])),
        ("recursion_zero", PRED, [ZERO], call(["zero", 0])),
        ("recursion_successor", PRED, [ONE], call(["proj", 2, 0], ZERO, call(PRED, ZERO))),
    ]
    for label, desc, args, right in compute_rows:
        positive["compute_" + label] = packet(e(call(desc, *args), right),
                                             node("compute", description=desc, arguments=args))

    # A derived universal predecessor equation needs two actual computation nodes.
    x = v("x")
    left = call(PRED, s(x))
    middle = call(["proj", 2, 0], x, call(PRED, x))
    rec_step = node("compute", description=PRED, arguments=[s(x)])
    projection = node("compute", description=["proj", 2, 0], arguments=[x, call(PRED, x)])
    pred_proof = node("transport", projection, rec_step, var="w", body=e(left, v("w")))
    positive["derived_predecessor"] = packet(forall(["x"], e(left, x)), generalize(["x"], pred_proof))

    positive["boolean_range"] = packet(
        forall(["x"], ["or", e(sign(x), ZERO), e(sign(x), ONE)]),
        generalize(["x"], node("BR", term=x)))
    positive["separation"] = packet(["imp", false_eq, ["bot"]], node("Sep"))
    positive["constant_reset"] = packet(A, node("SR", refl(ZERO), var="z", template=ZERO, at=TWO))
    positive["parameter_reset"] = packet(
        forall(["a", "t"], e(v("a"), v("a"))),
        generalize(["a", "t"], node("SR", refl(v("a")), var="z", template=v("a"), at=v("t"))))
    positive["identity_reset_schema"] = sr_schema(v("z"), v("t"), ["t"])
    ramp = select(sign(v("z")), v("a"), v("b"))
    positive["ramp_reset_schema"] = sr_schema(ramp, v("t"), ["a", "b", "t"])
    delayed = select(sign(call(PRED, v("z"))), v("a"), v("b"))
    positive["delayed_ramp_reset_schema"] = sr_schema(delayed, TWO, ["a", "b"])
    positive["nearest_binder_alpha_equivalence"] = packet(
        ["imp", forall(["x", "x"], e(v("x"), v("x"))),
         forall(["a", "b"], e(v("b"), v("b")))],
        node("imp_i", hyp(0), assume=forall(["x", "x"], e(v("x"), v("x")))))

    negative = {}
    negative["false_closed_equation"] = packet(false_eq, refl(ZERO))
    negative["invented_induction"] = packet(A, node("EI", var="z", left=ZERO, right=ZERO, at=ZERO))
    negative["invented_reflection_axiom"] = packet(A, node("reflection"))
    negative["boolean_hypothesis_index"] = packet(["imp", A, A], node("imp_i", hyp(False), assume=A))
    negative["boolean_projection_side"] = packet(A, node("and_e", conjunction, side=False))
    negative["transport_source_mismatch"] = packet(
        A, node("transport", refl(ZERO), refl(ONE), var="w", body=e(v("w"), v("w"))))
    negative["disjunction_branch_mismatch"] = packet(
        A, node("or_e", node("or_i", refl(ZERO), side=0, other=B), refl(ZERO), refl(ONE)))
    negative["existential_escape"] = packet(
        ["imp", existential, A], node("imp_i", node("ex_e", hyp(0), hyp(1), var="w"), assume=existential))
    negative["universal_eigenvariable_reused"] = packet(
        forall(["x", "x"], A), generalize(["x"], node("all_i", refl(ZERO), var="x")))
    negative["template_variable_reused"] = packet(
        forall(["w"], A), generalize(["w"], node("transport", refl(ZERO), refl(ZERO), var="w", body=A)))
    negative["reset_wrong_premise"] = packet(e(ZERO, ONE), node("SR", refl(ZERO), var="z", template=v("z"), at=ZERO))
    negative["reset_target_escape"] = packet(A, node("SR", refl(ZERO), var="z", template=ZERO, at=v("z")))
    negative["reset_template_escape"] = packet(A, node("SR", refl(ZERO), var="z", template=v("unbound"), at=ZERO))
    negative["reset_variable_reused"] = packet(
        forall(["z"], A), generalize(["z"], node("SR", refl(ZERO), var="z", template=ZERO, at=ZERO)))
    negative["reset_formula_as_template"] = packet(A, node("SR", refl(ZERO), var="z", template=A, at=ZERO))
    negative["reset_hidden_induction_hypothesis"] = packet(A, node("SR", hyp(0), var="z", template=ZERO, at=ZERO))
    negative["reset_extra_premise"] = packet(A, node("SR", refl(ZERO), refl(ZERO), var="z", template=ZERO, at=ZERO))
    negative["reset_arbitrary_anchor_field"] = packet(
        A, node("SR", refl(ZERO), var="z", template=ZERO, at=ZERO, anchor=ZERO))
    negative["reset_old_normalized_transition"] = sr_schema(v("z"), v("t"), ["t"], old_premise=True)
    negative["reset_previous_sign_transition"] = sr_schema(v("z"), v("t"), ["t"], sign_fallback=True)
    negative["reset_zero_anchor_instead_of_one"] = sr_schema(v("z"), v("t"), ["t"], anchor_term=ZERO)
    negative["reset_unchecked_target_even_if_unused"] = packet(
        A, node("SR", refl(ZERO), var="z", template=ZERO, at=["not_a_term"]))

    malformed_descriptions = {
        "negative_arity": ["zero", -1], "boolean_arity": ["zero", True],
        "out_of_range_projection": ["proj", 1, 1], "boolean_projection": ["proj", 1, False],
        "composition_outer_mismatch": ["comp", 1, ["succ"], []],
        "composition_inner_mismatch": ["comp", 1, ["succ"], [["zero", 2]]],
        "recursion_step_mismatch": ["rec", ["zero", 0], ["proj", 3, 0]],
        "description_variable_capture": ["v", "x"], "universal_evaluator": ["eval", 0],
        "description_reference": ["ref", 0],
    }
    for label, desc in malformed_descriptions.items():
        negative[label] = packet(A, node("compute", description=desc, arguments=[]))
    negative["application_arity_mismatch"] = packet(A, node("compute", description=["succ"], arguments=[]))
    negative["recursion_arbitrary_counter"] = packet(
        forall(["x"], A), generalize(["x"], node("compute", description=PRED, arguments=[v("x")])))
    negative["unbound_term"] = packet(A, refl(v("x")))
    negative["malformed_successor"] = packet(A, refl(["S", ZERO, ZERO]))
    negative["scalar_term_alias"] = packet(A, refl(False))
    negative["nearest_binder_confusion"] = copy.deepcopy(positive["nearest_binder_alpha_equivalence"])
    negative["nearest_binder_confusion"]["goal"][2] = forall(["a", "b"], e(v("a"), v("a")))
    return positive, negative


def load_checker(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    raw = path.read_bytes()
    tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw.decode("utf-8"))))
    normalized = ast.unparse(tree) + "\n"
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    tokens = sum(t.type not in ignored for t in tokenize.generate_tokens(io.StringIO(normalized).readline))
    return {"normalized_tokens": tokens, "ast_nodes": sum(1 for _ in ast.walk(tree)),
            "normalized_bytes": len(normalized.encode("utf-8")), "raw_bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def derive_old_control():
    source = CHECKER.read_text()
    new = "    return choose(epsilon(value, anchor), successor(index), zero())\n"
    old = ("    return choose(choose(epsilon(value, value), epsilon(value, anchor), zero()),\n"
           "                  successor(index), zero())\n")
    if source.count(new) != 1:
        raise RuntimeError("Expected one exact raw reset builder; refusing unchecked control rewrite.")
    control = ROOT / "complete_checker_old_reset.py"
    control.write_text(source.replace(new, old))
    a, b = ast.parse(source), ast.parse(control.read_text())
    found = 0
    for left, right in zip(a.body, b.body):
        if isinstance(left, ast.FunctionDef) and left.name == "reset_argument":
            found += 1
        elif ast.dump(left) != ast.dump(right):
            raise RuntimeError("Control changed code outside the reset-argument builder.")
    if len(a.body) != len(b.body) or found != 1:
        raise RuntimeError("Control rewrite changed the module structure.")
    return control


def focused_metrics(path):
    module = ast.parse(path.read_text())
    function = next(n for n in module.body
                    if isinstance(n, ast.FunctionDef) and n.name == "reset_argument")
    text = ast.unparse(function) + "\n"
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    return {"function_tokens": sum(t.type not in ignored for t in
                                    tokenize.generate_tokens(io.StringIO(text).readline)),
            "function_ast_nodes": sum(1 for _ in ast.walk(function)),
            "function_bytes": len(text.encode("utf-8")),
            "return_expression_ast_nodes": sum(1 for _ in ast.walk(function.body[0].value))}


def used_rules(proof):
    result = {proof["rule"]}
    for child in proof["premises"]:
        result |= used_rules(child)
    return result


def main():
    checker = load_checker(CHECKER)
    positive, negative = fixtures()
    examples = ROOT / "complete_examples"
    examples.mkdir(exist_ok=True)
    failures, runs = [], []
    coverage = set()
    for label, data in positive.items():
        (examples / ("complete_" + label + ".json")).write_text(json.dumps(data, indent=2) + "\n")
        coverage |= used_rules(data["proof"])
    if coverage != set(checker.RULES):
        failures.append("Rule coverage differs from the full rule inventory: " + repr(coverage))
    (ROOT / "complete_negative_cases.json").write_text(json.dumps(negative, indent=2) + "\n")
    for expected, group in ((True, positive), (False, negative)):
        for label, data in group.items():
            try:
                actual = checker.verify(data) is True
            except Exception:
                actual = False
            if actual != expected:
                failures.append(label + ": API verdict mismatch")
            for flags in ([], ["-O"]):
                process = subprocess.run([sys.executable, *flags, str(CHECKER)],
                                         input=json.dumps(data), text=True, capture_output=True, timeout=20)
                ok = (process.returncode == 0 and process.stdout == "ACCEPT\n" and not process.stderr)
                rejected = (process.returncode == 1 and not process.stdout and process.stderr.startswith("REJECT:"))
                passed = ok if expected else rejected
                runs.append({"case": label, "optimized": bool(flags), "expected": expected, "passed": passed})
                if not passed:
                    failures.append(label + ": public CLI mismatch " + repr(flags) + " " + process.stderr[:200])
    malformed = ["{", "[]", '{"goal":0,"goal":1,"proof":null}',
                 '{"goal":NaN,"proof":null}', '{"goal":Infinity,"proof":null}']
    for i, raw in enumerate(malformed):
        process = subprocess.run([sys.executable, str(CHECKER)], input=raw,
                                 text=True, capture_output=True, timeout=20)
        passed = process.returncode == 1 and not process.stdout and process.stderr.startswith("REJECT:")
        runs.append({"case": "malformed_json_" + str(i), "optimized": False, "expected": False, "passed": passed})
        if not passed:
            failures.append("Malformed JSON case " + str(i))
    control_path = derive_old_control()
    control = load_checker(control_path)
    old_packet = sr_schema(v("z"), v("t"), ["t"], old_premise=True)
    if not control.verify(old_packet):
        failures.append("Matched old reset control rejected its own schema.")
    try:
        control.verify(positive["identity_reset_schema"])
    except Exception:
        pass
    else:
        failures.append("Old reset control accepted the new transition as its primitive schema.")
    (examples / "complete_old_control_schema.json").write_text(json.dumps(old_packet, indent=2) + "\n")
    measurements = {"new_raw_reset": measure(CHECKER), "old_normalized_reset": measure(control_path)}
    measurements["difference_old_minus_new"] = {
        k: measurements["old_normalized_reset"][k] - measurements["new_raw_reset"][k]
        for k in ("normalized_tokens", "ast_nodes", "normalized_bytes")}
    receipt = {"python": platform.python_version(), "accepted_packets": len(positive),
               "rejected_packets": len(negative), "malformed_json_cases": len(malformed),
               "public_cli_runs": len(runs), "rule_coverage": sorted(coverage),
               "whole_source_boundary": "All executable code, standard-library imports, fixed descriptions, validation, and CLI; genuine docstrings only removed.",
               "measurements": measurements, "failures": failures, "runs": runs,
               "focused_reset_builder_metrics": {
                   CHECKER.name: focused_metrics(CHECKER),
                   control_path.name: focused_metrics(control_path)},
               "scope": "Finite implementation evidence for the complete ordinary SR checker. Does not formalize the paper's calibration or bi-interpretability proofs."}
    (ROOT / "complete_validation.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: value for k, value in receipt.items() if k != "runs"}, indent=2))
    return bool(failures)


if __name__ == "__main__":
    raise SystemExit(main())
