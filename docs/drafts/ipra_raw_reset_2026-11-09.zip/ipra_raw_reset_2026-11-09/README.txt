RAW COMPARISON AND RESET INDUCTION FOR iPRA
9 November 2026
Prepared for Vladimir Reshetnikov

RESULT AND LIMIT
================
This package proves a new reduction of the latest successor-anchored
reset presentation of full first-order intuitionistic primitive recursive
arithmetic (iPRA): its diagonal-normalizing wrapper can be deleted.
The replacement is exactly the plain raw reset

    rho_f(z) = C(epsilon(f(z), f(1)), S(z), 0).

The single induction-type rule takes the premise

    Gamma |- f(rho_f(z)) = f(1)

to Gamma |- f(t) = f(1), with z fresh for the retained context,
target, and passive parameters. The same fixed term template f is used
throughout. Full intuitionistic first-order logic, primitive-recursive
defining equations, Boolean range, and 0 != 1 complete the theory.

The new isolated-spike argument first derives the raw comparison's zero
diagonal. A ramp then derives equality reflection. Neither argument uses
separation, numerical coverage, or an additional induction principle.
The full theory is deductively equivalent to iPRA on a common signature,
so both interpretations and their internally provable composites are
literal identities, including on nonstandard elements.

This DOES NOT meet the user's remaining strict complete-checker minimum.
The existing native frontier is 309 normalized tokens / 344 AST nodes /
864 normalized bytes. Our complete readable ordinary checker measures
3347 / 3539 / 13354. A matched old-reset version measures
3361 / 3552 / 13393, so the controlled mathematical change saves
14 tokens / 13 AST nodes / 39 bytes. The source metrics include every
executable instruction and import. These observed corpus minima are not
mathematical lower-bound theorems. No claim of global novelty or an
absolutely simplest axiomatization is made.

START HERE
==========
report.pdf             Complete mathematical report and exact limitations.
report.tex             Main LaTeX source; its section files are alongside it.
reproduce.py           Replays certificates, implementation tests and metrics.
build.py               Rebuilds report.pdf in two pdfLaTeX passes.
MANIFEST.json          Length and SHA-256 of each packaged payload file.
ATTRIBUTION.txt        Provenance and division between inherited/new work.

RUNNING THE CHECKS
==================
Use Python 3.12 or a later compatible interpreter. There are no third-party
Python dependencies and no network calls in reproduction. From this directory:

    python3 reproduce.py
    python3 build.py

The build additionally requires a local TeX distribution with pdfLaTeX
and the standard packages listed in report.tex. Shell escape is disabled.
Changing the Python version may change ast.unparse formatting or counts;
the receipt records the actual interpreter version.

To replay only the calibration proof:

    python3 code/replay_calibration.py code/calibration_certificate.json

To check an ordinary closed certificate through the complete checker:

    python3 code/complete_checker.py < code/complete_examples/complete_identity_reset_schema.json

The checker prints ACCEPT and exits zero for an accepted proof; it prints
a rejection message to stderr and exits one otherwise. An old-control
example is explicitly named complete_old_control_schema.json and belongs
to complete_checker_old_reset.py, not to the new primitive rule.

CALIBRATION TRUST BOUNDARY
=========================
code/make_calibration.py produces the supplied finite symbolic proof.
code/replay_calibration.py independently checks it without importing the
producer. Its arithmetic profile is deliberately restricted to selector,
sign and predecessor endpoints, Boolean range, and the new reset rule.
It treats epsilon(a,b) as sigma(w(a,b)) with arbitrary binary w and no
equations for w. Substitute w(a,b)=K(Sa dotminus b) for the paper's theory.

The four exact closed exports are spike_collapse, diagonal, reflection,
and CAL, in that dependency order. They contain 434 proof/reference
nodes in total and two raw-reset rule nodes. Verified earlier exports
can be reused; no unverified theorem is imported as an axiom.
The positive proof is accepted in normal and optimized Python. Twenty
deliberately corrupted proofs are rejected in both modes (40 rejections).
This replayer is not presented as a complete first-order iPRA checker.

COMPLETE CHECKER TRUST BOUNDARY
==============================
code/complete_checker.py separately implements all ordinary first-order
logic and equality rules, strict syntax and scope checking, finite staged
primitive-recursive descriptions, all defining equations, and BR/Sep/SR.
There is no general induction, reflection, or theorem-library instruction.
code/complete_spec.txt specifies every format and rule and explains the
soundness/completeness correspondence with the displayed theory.

code/complete_tests.py exercises all 18 rule names through accepted and
rejected certificates, including normal and optimized command-line runs.
It also reconstructs the matched old reset control by a checked single
replacement. code/measure_comparison.py separately verifies that every
other executable top-level AST component is identical.

The final suite has 31 accepted packets, 38 rejected packets, five malformed
JSON cases, and 143 command-line runs, with zero failures. This is finite
implementation validation, not a Lean/Rocq formalization or a proof of the
Python interpreter's correctness. The written internal equivalence proof
and the symbolic calibration replay have different stated scopes.

FROZEN COMPARISON
=================
Repository: https://github.com/VladimirReshetnikov/ProveIt
Directory: docs/drafts
Commit: 89fd4b4c5cd158259b1f2846f63e3d98f053553c

All eleven current ZIP archives were retrieved and verified against Git
blob identities. evidence/source_snapshot.json records those identities.
The smallest native programs were extracted from the newest reconstructed
package. Eighteen distinct complete comparators are copied unchanged into
reference/checkers, with source identities in reference/checker_manifest.json.
reference/source_measure.py is the unchanged inherited source normalizer.

evidence/metrics_summary.json and comparator_metrics.csv give complete
measurements. The metric does not normalize identifier names: uniformly
shortening the three interface names in compact_open.py yields 816 bytes.
The native 309-token / 344-node improvements survive that control; literal
byte dominance does not. Identifier shortening is not claimed as a new
mathematical simplification.

ADDITIONAL EVIDENCE
===================
evidence/calibration_results.json       Symbolic proof and corruption runs.
evidence/complete_checker_results.json  Full implementation test receipt.
evidence/mathematical_review.txt         Independent mathematical review.
evidence/implementation_review.txt      Independent implementation review.
evidence/corpus_audit.txt               Corpus inspection and its limits.
evidence/pdf_qa.json                    Final PDF visual verification.
evidence/latex_build.txt                Local two-pass build output.

Inherited source files and inherited checker components retain the
accompanying license and attribution notices. New proof arguments,
documents and support code are identified in ATTRIBUTION.txt.
