"""Standalone iPRA certificate checker with sort-directed scalar erasure.

Numerical unary nodes bind zero; ternary nodes bind two slots. Numerical
binary nodes mean zero and their children are logical annotations. At a
formula position, in-range numeric scalar labels may retain their raw
spelling but always denote truth; exposed numeric labels become zero.
Strings, dictionaries, and null reject at those positions. A whole node arity
determines its uniform child scope increment. No imported project module.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    match a:
        case [*_]:
            return [inst(b, t, d + b'\0\2\1\4'[len(a)]) for b in a]
    return a if k <= a < d else d % 2 and inst(t, d=1)


def check(a, g):
    global k
    if inst(a) in g:
        return 1
    match take():
        case [m, t] if check(m, g):
            h = [m[2:]]
            if [] in h:
                t, s, u = (t, *m) if m[1:] else (*m, 0, t)
                return inst(t, u) == a and check(inst(t, s), g)
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 1)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
