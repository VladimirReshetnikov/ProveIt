"""Complete derived-rule certificate checker for the clausal iPRA presentation.

Numerical unary nodes add a dummy zero slot; ternary nodes add two slots.
Numerical binary nodes mean zero and their children are logical annotations. At a
formula position, in-range numeric scalar labels may retain their raw
spelling but always denote truth; exposed numeric labels become zero.
Strings, dictionaries, and null reject at those positions. A whole node arity
determines its uniform child scope increment. No imported project module.
"""
import json, sys
k = 0


def sub(a, t=None, d=0):
    return (
        [sub(b, t, d + b'\0\2\1\4'[len(a)]) for b in a]
        if type(a) is list
        else a
        if k <= a < d
        else d % 2 and sub(t, d=1)
    )


def test(a, g):
    global k
    if sub(a) in g:
        return 1
    match take():
        case [m, t] if test(m, g):
            match m:
                case [b]:
                    m, t = [0, t], b
            if not (h := [m[2:]])[0]:
                return sub(t, m[1]) == a and test(sub(t, m[0]), g)
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = sub(r, [n, t, r], 1)
            return b == t
        case t:
            a = sub(a[2], t, 2)
            h = [a, sub(a, 0)][len(a) % 2:]
    k -= 1
    return test(sub(a, [k]), g + [sub(c, k) for c in h])


try:
    take = json.load(sys.stdin).pop
    1 / test(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
