import json, sys
k = 0

def inst(a, t=None, d=0):
    try:
        return [inst(b, t, d + b'\0\2\1\4'[len(a)]) for b in a.copy()]
    except:
        return a if k <= a < d else d % 2 and inst(t, d=1)

def check(a, g):
    global k
    if inst(a) in g:
        return 1
    m, t = take()
    if m and check(m, g):
        if [] in (h := [m[2:]]):
            if not m[1:]:
                m, t = [0, t], *m
            return inst(t, m[1]) == a and check(inst(t, m[0]), g)
    elif t:
        a = inst(a[2], t, 2)
        h = [a, inst(a, 0)][len(a) % 2:]
    else:
        (n, t, r), b = a
        if n:
            n, = n
            t = inst(r, [n, t, r], 1)
        return b == t
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])

try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    raise SystemExit(1)
