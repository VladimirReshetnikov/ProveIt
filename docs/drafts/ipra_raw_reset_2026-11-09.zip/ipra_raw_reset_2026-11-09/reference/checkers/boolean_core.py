"""Experimental synthesis of the pinned boxed-witness and context-block kernels.

This file combines existing mathematical normal forms; it does not introduce
a new axiomatization. Complete input, scope checking, proof checking, and
acceptance/rejection are included. See validation/NOTES.md for provenance.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    try:
        return [inst(b, t, d + b'\0\2\1\4'[len(a)]) for b in a.copy()]
    except:
        return a if k <= a < d else d % 2 and inst(t, d=1)


def check(a, g):
    global k
    if inst(a) in g:
        return 1
    m, t = take()
    if m and check(m, g):
        if [] in (h := [0, m[2:]]):
            if not m[1:]:
                m, t = [0, t], *m
            return inst(t, m[1]) == a and check(inst(t, m[0]), g)
    elif t:
        a = inst(a[2], t, 2)
        h = [len(a) % 2 or a, inst(a, 0)]
    else:
        (n, t, r), b = a
        if n:
            n, = n
            t = inst(r, [n, t, r], 1)
        return b == t
    k -= 1
    return check(inst(a, [k]), g + inst(h, k, -1))


try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    raise SystemExit(1)
