"""Write a payload manifest and a ZIP, then verify every packaged hash."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex", ".gz"}


def payloads():
    return sorted(path for path in ROOT.rglob("*")
                  if path.is_file()
                  and "__pycache__" not in path.parts
                  and path.name != "MANIFEST.json"
                  and path.suffix not in EXCLUDED_SUFFIXES)


def main():
    entries = []
    for path in payloads():
        raw = path.read_bytes()
        entries.append({"file": path.relative_to(ROOT).as_posix(),
                        "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
    manifest = {"format": "ipra-raw-reset-payload-v1",
                "repository_snapshot": "89fd4b4c5cd158259b1f2846f63e3d98f053553c",
                "scope": "Every ZIP payload except this manifest itself; transient TeX and Python caches excluded.",
                "files": entries}
    (ROOT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    destination = ROOT.with_suffix(".zip")
    paths = payloads() + [ROOT / "MANIFEST.json"]
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted(paths):
            name = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    with zipfile.ZipFile(destination) as archive:
        failed = archive.testzip()
        if failed is not None:
            raise RuntimeError("ZIP CRC check failed for " + failed)
        for entry in entries:
            raw = archive.read(ROOT.name + "/" + entry["file"])
            if len(raw) != entry["bytes"] or hashlib.sha256(raw).hexdigest() != entry["sha256"]:
                raise RuntimeError("Packaged hash mismatch: " + entry["file"])
    print(json.dumps({"archive": str(destination), "files": len(paths),
                      "bytes": destination.stat().st_size,
                      "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                      "all_crc_and_payload_hashes_verified": True}, indent=2))


if __name__ == "__main__":
    main()
