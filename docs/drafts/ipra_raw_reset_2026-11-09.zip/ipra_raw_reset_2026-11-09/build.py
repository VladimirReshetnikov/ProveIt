"""Build the supplied LaTeX report without shell escape or downloads."""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("Install a local TeX distribution providing pdflatex.")
    logs = []
    for _ in range(2):
        run = subprocess.run(
            [executable, "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "report.tex"],
            cwd=ROOT, capture_output=True, text=True
        )
        logs.append(run.stdout + run.stderr)
        if run.returncode:
            (ROOT / "evidence" / "latex_build.txt").write_text("\n".join(logs))
            sys.stdout.write(logs[-1])
            raise SystemExit(run.returncode)
    (ROOT / "evidence" / "latex_build.txt").write_text("\n".join(logs))
    print(ROOT / "report.pdf")


if __name__ == "__main__":
    main()
