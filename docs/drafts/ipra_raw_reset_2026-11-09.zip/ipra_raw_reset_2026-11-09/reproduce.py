"""Run the supplied finite checks and regenerate evidence with local Python."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    for relative in ("code/verify_calibration.py", "code/complete_tests.py",
                     "code/measure_comparison.py"):
        print("Running " + relative, flush=True)
        subprocess.run([sys.executable, "-B", str(ROOT / relative)],
                       cwd=ROOT, env=environment, check=True)
    source = ROOT / "code/complete_validation.json"
    receipt = json.loads(source.read_text())
    if receipt["failures"]:
        raise RuntimeError("The complete checker validation reported failures.")
    shutil.copyfile(source, ROOT / "evidence/complete_checker_results.json")
    print("All supplied checks passed. This is finite implementation evidence, "
          "not a machine formalization of the full bi-interpretability theorem.")


if __name__ == "__main__":
    main()
