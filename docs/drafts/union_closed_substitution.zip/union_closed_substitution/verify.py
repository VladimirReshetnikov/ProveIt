#!/usr/bin/env python3
"""Exact checks of the substitution identities. Standard library only."""
from itertools import product, combinations
from collections import Counter, defaultdict
from fractions import Fraction
from math import prod, comb
import random
import json


def closure(edges):
    u = {0}
    for e in edges:
        u |= {s | e for s in u}
    return u


def bits(x):
    return [i for i in range(x.bit_length()) if (x >> i) & 1]


def all_hypergraphs(n):
    es = list(range(1, 1 << n))
    for b in range(1, 1 << len(es)):
        yield tuple(e for i, e in enumerate(es) if b >> i & 1)


def make_lift(base, locals_, sizes):
    offsets = [sum(sizes[:i]) for i in range(len(sizes))]
    lifted = []
    for e in base:
        vs = bits(e)
        for fs in product(*(locals_[i] for i in vs)):
            parts = dict(zip(vs, fs))
            mask = sum(f << offsets[i] for i, f in parts.items())
            lifted.append((e, parts, mask))
    assert len({h for _, _, h in lifted}) == len(lifted)
    return lifted, offsets


def check_case(base, local, sizes, joints=False):
    n = len(sizes)
    lifted, offsets = make_lift(base, local, sizes)
    U = closure(base)
    L = [closure(x) for x in local]
    w = [len(x) - 1 for x in L]
    W = {R: prod(w[i] for i in bits(R)) for R in U}
    Z = sum(W.values())
    # Independent method 1: enumerate all unions of lifted edges.
    actual = closure([h for _, _, h in lifted])
    # Independent method 2: enumerate Cartesian fibers indexed by base unions.
    predicted = set()
    for R in U:
        choices = [(L[i] - {0}) if R >> i & 1 else {0} for i in range(n)]
        predicted.update(sum(s << j for s, j in zip(xs, offsets)) for xs in product(*choices))
    assert actual == predicted and len(actual) == Z
    # Independent method 3: build the primal family from incidence stars.
    stars = [sum(1 << j for j, (_, _, h) in enumerate(lifted) if h >> i & 1)
             for i in range(sum(sizes))]
    primal = closure(stars)
    full = (1 << len(lifted)) - 1
    def complement_induced(s):
        return full ^ sum(1 << j for j, (_, _, h) in enumerate(lifted) if (s & h) == h)
    assert len(primal) == len(actual)
    assert primal == {complement_induced(s) for s in actual}

    def check_marks(marked):
        e = 0; mark = 0; parts = defaultdict(int)
        for b, p, h in marked:
            e |= b; mark |= h
            for i, f in p.items():
                parts[i] |= f
        numerator = sum(weight for R, weight in W.items() if R & e == e)
        denominator = 1
        for i, f in parts.items():
            numerator *= sum(t & f == f for t in L[i] if t)
            denominator *= w[i]
        observed = sum(s & mark == mark for s in actual)
        assert observed * denominator == numerator
        # Two-sided sandwich for the joint absence event.
        lower = prod(Fraction(sum(t & f == f for t in L[i]), len(L[i])) for i, f in parts.items())
        upper = prod(Fraction(sum(t & f == f for t in L[i]), w[i]) for i, f in parts.items())
        assert lower <= Fraction(observed, Z) < upper

    for j, entry in enumerate(lifted):
        check_marks([entry])
        assert sum((s >> j) & 1 for s in primal) == Z - sum(s & entry[2] == entry[2] for s in actual)
    if joints:
        for a, b in combinations(lifted, 2):
            check_marks([a, b])
    return len(actual), len(lifted)


def check_clone(base, sizes):
    n = len(sizes)
    local = [tuple(1 << i for i in range(t)) for t in sizes]
    lifted, offsets = make_lift(base, local, sizes)
    U = closure([h for _, _, h in lifted])
    Bfamily = closure(base) - {0}
    count = 0
    for B in Bfamily:
        inside = sum(((1 << sizes[i]) - 1) << offsets[i] for i in bits(B))
        outside_mask = ((1 << sum(sizes)) - 1) ^ inside
        fibres = defaultdict(list)
        for s in U:
            fibres[s & outside_mask].append(s)
        total = 1 << sum(sizes[i] for i in bits(B))
        full_active = prod((1 << sizes[i]) - 1 for i in bits(B))
        for ext, fibre in fibres.items():
            # TV is 1 - fibre/total exactly, since fibre law is uniform.
            assert total >= len(fibre) >= full_active
            assert sum(all((s >> offsets[i]) & ((1 << sizes[i])-1) for i in bits(B)) for s in fibre) == full_active
            for e, _, h in lifted:
                if e & B == e:
                    absent = Fraction(sum(s & h == h for s in fibre), len(fibre))
                    q = prod(Fraction(1 << (sizes[i] - 1), (1 << sizes[i]) - 1) for i in bits(e))
                    assert Fraction(1, 1 << len(bits(e))) <= absent <= q
            count += 1
    # Negative joint absence envelope for disjoint lifted edges (may share base vertices).
    joint_checks = 0
    for a, b in combinations(lifted, 2):
        if a[2] & b[2]:
            continue
        q = prod(Fraction(1 << (sizes[i] - 1), (1 << sizes[i]) - 1)
                 for e in [a[0], b[0]] for i in bits(e))
        h = a[2] | b[2]
        assert Fraction(sum(s & h == h for s in U), len(U)) <= q
        joint_checks += 1
    return count, joint_checks


def petal_formula(r, t, d):
    w = (1 << t) - 1
    L = (1 + w ** (r - 1)) ** d
    A = w * L
    C = w * (L - 1)
    Z = A ** r + (1 + C) ** r - C ** r
    p = 1 - Fraction(A ** r, Z) * Fraction(1 << (t-1), w) ** r
    return Z, p


def complete_formula(r, t, n):
    w = (1 << t) - 1
    Z = (1 + w) ** n - sum(comb(n, j) * w ** j for j in range(1, r))
    p = 1 - Fraction((1 << (t-1)) ** r * (1+w) ** (n-r), Z)
    return Z, p


def petal_base(r, d):
    central = (1 << r) - 1
    E = [central]; n = r
    for v in range(r):
        for _ in range(d):
            E.append((1 << v) | (((1 << (r - 1)) - 1) << n))
            n += r - 1
    return E, n


def main():
    cases = union_members = lifted_edges = 0
    opts = [(1,), (1,2), (3,), (1,3)]
    # All nonempty simple base hypergraphs on at most three labeled vertices;
    # varied two-vertex local hypergraphs (including a non-discrete gadget).
    for n in (1,2,3):
        for B in all_hypergraphs(n):
            for local in product(opts, repeat=n):
                z, m = check_case(B, local, [2]*n, joints=n <= 2)
                cases += 1; union_members += z; lifted_edges += m
    # All local hypergraphs on two labeled vertices, for every two-vertex base.
    all_local = list(all_hypergraphs(2))
    for B in all_hypergraphs(2):
        for local in product(all_local, repeat=2):
            z,m = check_case(B,local,[2,2],joints=True)
            cases+=1; union_members+=z; lifted_edges+=m
    # Seeded broader tests, including unequal local sizes and overlapping local edges.
    rng = random.Random(20261125)
    for _ in range(120):
        n = rng.randint(2,4)
        B = rng.sample(list(range(1,1<<n)), rng.randint(1,min(5,(1<<n)-1)))
        sizes = [rng.randint(1,3) for _ in range(n)]
        local = [rng.sample(list(range(1,1<<t)),rng.randint(1,min(3,(1<<t)-1))) for t in sizes]
        z,m=check_case(B,local,sizes,joints=m_small(B,local,sizes))
        cases+=1; union_members+=z; lifted_edges+=m
    fibres = disjoint_pairs = clone_cases = 0
    for n in (1,2,3):
        for B in all_hypergraphs(n):
            for sizes in ([2]*n, [1+(i%3) for i in range(n)]):
                a,b = check_clone(B,sizes)
                fibres+=a; disjoint_pairs+=b; clone_cases+=1
    for r,t,d in [(2,2,1),(2,2,2),(3,2,1),(2,3,1)]:
        B,n=petal_base(r,d)
        lifted,_=make_lift(B,[tuple(1<<i for i in range(t))]*n,[t]*n)
        U=closure([h for _,_,h in lifted])
        Z,p=petal_formula(r,t,d)
        assert Z==len(U) and p==1-Fraction(sum(s&lifted[0][2]==lifted[0][2] for s in U),Z)
    for r,t,n in [(2,2,3),(2,3,3),(3,2,4),(3,2,5)]:
        B=[sum(1<<i for i in c) for c in combinations(range(n),r)]
        lifted,_=make_lift(B,[tuple(1<<i for i in range(t))]*n,[t]*n)
        U=closure([h for _,_,h in lifted])
        Z,p=complete_formula(r,t,n)
        assert Z==len(U) and p==1-Fraction(sum(s&lifted[0][2]==lifted[0][2] for s in U),Z)
    rows=[]
    for r,t in [(2,2),(3,2),(3,3),(4,2)]:
        lower=1-Fraction(1<<(t-1),(1<<t)-1)**r
        upper=1-Fraction(1,1<<r)
        for d in [1,2,4,8,16]:
            _,p=petal_formula(r,t,d)
            assert lower<p<=upper
            rows.append({'kind':'petal','r':r,'t':t,'d':d,'frequency':float(p),'exact_gap_to_lower':str(p-lower)})
        for n in [r,r+2,r+5,r+10]:
            _,p=complete_formula(r,t,n)
            assert lower<p<=upper
            rows.append({'kind':'complete','r':r,'t':t,'n':n,'frequency':float(p),'exact_gap_to_upper':str(upper-p)})
    result={'status':'PASS','substitution_cases':cases,'members_checked_with_multiplicity':union_members,
            'marked_lifted_edges_checked':lifted_edges,'clone_cases':clone_cases,'exterior_fibres':fibres,
            'disjoint_lifted_pairs':disjoint_pairs,'direct_petal_checks':4,'direct_complete_checks':4,'sharpness_rows':rows}
    with open('verification.json','w') as f: json.dump(result,f,indent=2)
    print(json.dumps({k:v for k,v in result.items() if k!='sharpness_rows'},indent=2))


def m_small(B,local,sizes):
    return sum(prod(len(local[i]) for i in bits(e)) for e in B) <= 40

if __name__ == '__main__':
    main()
