# Source audit (2026-11-25)

## Repository inspection

Directory: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts

The GitHub connector listed 18 ZIP files and .gitkeep. The TeX abstracts and/or section headings were extracted for the following 17 ZIP files; this is a thematic comparison, not a full proof audit of their contents.

| Archive | Main nearby themes observed |
|---|---|
| union-closed-abundance.zip | Four-set bounds, graph-star first correction, linear and regular generators, sunflowers, torus triples |
| union-closed-results.zip | Overlapping triples, translates, intervals, four-set frequency |
| union_closed_abundance.zip | Sharp local frequencies, dense families, deletion thresholds, translates |
| union_closed_abundance_theorems.zip | Overlapping complete blocks, projective plane line unions, local triples |
| union_closed_advances_2026-11-25.zip | Ranked frequencies, exact entropy refinements, first correction for linear generators |
| union_closed_entropy_2026_11_25.zip | Entropy, chain extremizers, finite-size estimates |
| union_closed_entropy_research_2026-11-25.zip | Chain entropy, approximation, collision identities |
| union_closed_extensions_2026-11-25(1).zip | Six-point local bounds, second-neighborhood entropy, excess classification |
| union_closed_extensions_2026-11-25.zip | High girth, multiple unions and principal filters |
| union_closed_frequency_bounds.zip | Prescribed edges, trees, implications, entropy and overlapping triples |
| union_closed_joint_laws_2026-11-25.zip | Dual representation, regular and irregular incidence, local lemma, conditional switching, Gaussian limits |
| union_closed_local_abundance.zip | High-girth pointwise bounds and exterior-conditioned tree messages |
| union_closed_marked_abundance.zip | Prescribed graph edge, deletion cost, common translate certificates for small generator cores |
| union_closed_partial_results.zip | Rare triples; uniform linear and sparse random generator frequencies, elementary upper ceiling |
| union_closed_partial_theorems_2026-11-25.zip | High girth, sharp first corrections for regular linear generator systems |
| union_closed_refinements_2026-11-25.zip | Approximate closure, entropy bounds, discrete cap, nonchain extremizers |
| union_closed_three_results.zip | Nine-billion finite bound, sharp prescribed graph edge, five exceptional generators |

Not inspected: `union_closed_structural_theorems.zip` (listed size 4,265,422 bytes, blob SHA bba38e6abe6445578e551dfc16f678f4fdb4fa56). GitHub connector returned zero-length content even on retry with base64 encoding; direct network access from the execution container was unavailable. Its contents might contain overlapping results. No changes were made to the repository.

## Public literature

The principal external inputs are Poonen's small-family theorem (up to 28 members) and the golden-ratio universal lower bound. The dual representation is established prior art.

- Poonen (1992): https://doi.org/10.1016/0097-3165(92)90068-6
- Knill (1994): https://arxiv.org/abs/math/9409215
- El-Zahar (1997): https://doi.org/10.1002/%28SICI%291097-0118%28199711%2926%3A3%3C155%3A%3AAID-JGT6%3E3.0.CO%3B2-Q
- Chase--Lovett (2022): https://arxiv.org/abs/2211.11689
- Sawin (2022): https://arxiv.org/abs/2211.11504
- Costa--Sadhu (2026): https://arxiv.org/abs/2610.02295 (background only)
- Quantavane November 2026 announcement: https://quantavane.com/major-results/union-closed-sets-conjecture/ (background only, not independently audited)
- Wikipedia: https://en.wikipedia.org/wiki/Union-closed_sets_conjecture

Search terms included `union-closed hypergraph blow-up Frankl frequency`, `union-closed blow-up generators hypergraph`, `derived subgraphs blow-up graph non-residual frequency`, `union-closed hypergraph substitution product generators frequency`, `graph generated union-closed families Knill`, and `union closed conjecture every element belongs to at most two generators graph stars`. These located the classical dual framework and related graph-generated results; no exact match for the arbitrary-local-substitution factorization and its sharp bounds was located. Searches and draft summaries do not establish publication priority. The construction, identities and proofs in paper.tex are proposed research contributions, not a claim that the general conjecture is solved.
