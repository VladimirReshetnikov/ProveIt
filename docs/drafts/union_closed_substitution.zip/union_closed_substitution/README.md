# Sharp abundance under hypergraph substitution

Research archive, November 25, 2026.

- `paper.tex` — complete LaTeX source, with proofs, sharp examples, limitations and references.
- `paper.pdf` — compiled paper.
- `verify.py` — standard-library exact integer/rational verification; checks direct distinct-union enumeration, independent primal/dual construction, marked joint frequency formulas, exterior fibres and sharpness examples.
- `verification.txt`, `verification.json` — executed verification results and exact rational sharpness gaps.
- `SOURCE_AUDIT.md` — source comparison, prior art and explicit access limitation.
- `Makefile`, `SHA256SUMS` — build and integrity information.

Run `python3 verify.py` from this directory (Python 3.8+), and run `make paper.pdf` to compile with pdfLaTeX. `sha256sum -c SHA256SUMS` verifies the packaged versions before any rebuild. A rebuild may change PDF metadata and therefore its checksum.

The theorem is structural: it applies to complete hypergraph substitutions, not arbitrary union-closed families. The lower endpoint is sharp for a prescribed lifted element; no sharp claim is made for the maximum element frequency. The local-gadget 5/9 theorem uses established results (Poonen, Chase--Lovett/Sawin). The cloning result, exact product identities, and limiting examples have elementary proofs. The computation is supplementary, not a formal proof or a Lean/Rocq verification. Historical novelty remains provisional, particularly because one repository ZIP could not be read. No general proof of Frankl's conjecture or improved unrestricted constant is claimed.
