PRA WITH ONE ARITHMETIC SCHEMA
Research package prepared for Vladimir Reshetnikov, 31 October 2026

START HERE

  pra_exclusive.pdf  -- complete research note and proofs
  axioms.txt        -- exact common classical/intuitionistic specification

MAIN RESULT

Two primitive-recursion equation templates plus one arithmetic schema
axiomatize the respective first-order PRA exactly in either logic.
The schema uses ordinary positive induction hypotheses for
  r(n)=0 OR r(n)=S(u(n))
but concludes that exactly one alternative holds. Its constant instance
derives 0!=1, removing the need to state separation separately.

This is a modest reduction from four separately stated templates to three.
It is not a proved minimum, and its expanded formula is longer. The report
also proves a stronger obstruction to restricting induction to tests
against standard numerals, even when positive constructor coverage is given.

CONTENTS

  pra_exclusive.tex                 Main LaTeX source
  sections/obstructions.tex         Countermodel proofs
  sections/one_term.tex             Further candidate and proof boundary
  source_audit.json                 Exact six-draft provenance and hashes
  artifacts/ghost_model.py          Executable two-ray model companion
  artifacts/report.json            Default bounded verification results
  VALIDATION.txt                   Build and verification scope
  Makefile                         Build/check commands
  SHA256SUMS                       Package integrity hashes

BUILD

With a standard TeX Live installation containing latexmk:

  make pdf

Or run pdflatex -interaction=nonstopmode -halt-on-error pra_exclusive.tex
twice from this directory. The included sections must remain beside it.

RUN THE COMPANION

  make check

Equivalent command, from this directory:

  python3 artifacts/ghost_model.py --report artifacts/report.json

Only the Python standard library is required. To use a different root:

  python3 artifacts/ghost_model.py --root-weight 4 --report /tmp/pra-w4.json

VERIFY PACKAGE HASHES

  sha256sum -c SHA256SUMS

SCOPE

The main equivalence and infinite countermodels are mathematical proofs.
The executable checks selected finite samples of the explicit two-ray
model, not the infinite induction schema or the nonstandard model.
No complete proof-assistant formalization is claimed.

The further one-term candidate has a precisely stated literature-dependent
classical route. It is not substituted for the fully proved common basis.

COMPARISON SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Directory: docs/drafts
Commit: a0dd253b72f0ebfd368f674fcf722e0671d4a6ef

All six current archives were read. The package records their exact paths
and hashes without redistributing their complete contents. The report's
A1--A6 labels refer to this snapshot, not the older internal draft labels.
