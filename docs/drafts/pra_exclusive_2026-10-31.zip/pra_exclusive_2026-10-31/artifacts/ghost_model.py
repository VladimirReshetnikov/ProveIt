#!/usr/bin/env python3
"""Evaluate a two-ray countermodel for induction with fixed numeral targets.

Only the Python standard library is required. Run:
    python3 ghost_model.py
    python3 ghost_model.py --root-weight 4 --report weight4_report.json

The domain consists of main(k) and ghost(j), for natural k,j. Its projection
to N sends main(k) to k and ghost(j) to root_weight+j. Successor advances
each ray. Every finite primitive-recursion description is interpreted by
its defining equations on each ray, with a prescribed value at ghost(0).

This file implements a finite description language, checks selected programs
and bounded samples, and displays exact counterexample values. It is NOT a
proof assistant or a model checker for an infinite axiom schema. The paper
supplies the general proof that the entire language can be interpreted and
that every induction instance whose atomic targets are among the designated
numerals is valid. The stronger nonstandard finite-fiber countermodel in
the paper is not implemented here.
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from functools import cache
from pathlib import Path


@dataclass(frozen=True)
class Term:
    """A variable, zero, successor application, or earlier recursor call."""

    kind: str
    payload: str | int | None = None
    args: tuple[Term, ...] = ()


def variable(index: int) -> Term:
    return Term("variable", index)


ZERO = Term("zero")


def successor(term: Term) -> Term:
    return Term("successor", args=(term,))


def call(name: str, *args: Term) -> Term:
    return Term("call", name, tuple(args))


@dataclass(frozen=True)
class Recursor:
    name: str
    parameter_count: int
    base: Term
    step: Term


class Language:
    """Finite well-founded PR descriptions; no extensional identification."""

    def __init__(self) -> None:
        self.descriptions: dict[str, Recursor] = {}

    def validate(self, term: Term, context_size: int) -> None:
        if term.kind == "variable":
            if not isinstance(term.payload, int) or not 0 <= term.payload < context_size:
                raise ValueError("Variable outside the declared context")
            if term.args:
                raise ValueError("A variable has no arguments")
        elif term.kind == "zero":
            if term.args:
                raise ValueError("Zero has no arguments")
        elif term.kind == "successor":
            if len(term.args) != 1:
                raise ValueError("Successor has exactly one argument")
        elif term.kind == "call":
            if term.payload not in self.descriptions:
                raise ValueError("A recursion body may call only earlier descriptions")
            recursor = self.descriptions[term.payload]
            if len(term.args) != recursor.parameter_count + 1:
                raise ValueError("Incorrect recursor arity")
        else:
            raise ValueError(f"Unknown term constructor: {term.kind}")
        for child in term.args:
            self.validate(child, context_size)

    def declare(self, name: str, parameter_count: int, base: Term, step: Term) -> None:
        if name in self.descriptions or parameter_count < 0:
            raise ValueError("A declaration needs a fresh name and nonnegative arity")
        self.validate(base, parameter_count)
        # The step context is (recursion index, previous value, parameters...).
        self.validate(step, parameter_count + 2)
        self.descriptions[name] = Recursor(name, parameter_count, base, step)

    @cache
    def natural_term(self, term: Term, environment: tuple[int, ...]) -> int:
        if term.kind == "variable":
            return environment[int(term.payload)]
        if term.kind == "zero":
            return 0
        if term.kind == "successor":
            return self.natural_term(term.args[0], environment) + 1
        values = tuple(self.natural_term(t, environment) for t in term.args)
        return self.natural_call(str(term.payload), values)

    @cache
    def natural_call(self, name: str, arguments: tuple[int, ...]) -> int:
        recursor = self.descriptions[name]
        if len(arguments) != recursor.parameter_count + 1 or min(arguments) < 0:
            raise ValueError("Incorrect numerical arguments")
        index, *parameters = arguments
        parameters = tuple(parameters)
        value = self.natural_term(recursor.base, parameters)
        for stage in range(index):
            value = self.natural_term(recursor.step, (stage, value) + parameters)
        return value


@dataclass(frozen=True)
class Element:
    ray: str
    index: int

    def __post_init__(self) -> None:
        if self.ray not in {"main", "ghost"} or self.index < 0:
            raise ValueError("An element has a ray and a nonnegative index")

    def __str__(self) -> str:
        return f"{self.ray}({self.index})"


class GhostModel:
    def __init__(self, language: Language, root_weight: int = 2) -> None:
        if root_weight < 2:
            raise ValueError("Use root_weight >= 2, so 0 and 1 have singleton fibers")
        self.language = language
        self.root_weight = root_weight

    def project(self, element: Element) -> int:
        return element.index + (self.root_weight if element.ray == "ghost" else 0)

    @staticmethod
    def succ(element: Element) -> Element:
        return Element(element.ray, element.index + 1)

    @cache
    def term(self, term: Term, environment: tuple[Element, ...]) -> Element:
        if term.kind == "variable":
            return environment[int(term.payload)]
        if term.kind == "zero":
            return Element("main", 0)
        if term.kind == "successor":
            return self.succ(self.term(term.args[0], environment))
        values = tuple(self.term(t, environment) for t in term.args)
        return self.evaluate(str(term.payload), values)

    @cache
    def evaluate(self, name: str, arguments: tuple[Element, ...]) -> Element:
        recursor = self.language.descriptions[name]
        if len(arguments) != recursor.parameter_count + 1:
            raise ValueError("Incorrect model arguments")
        index, *parameters = arguments
        parameters = tuple(parameters)
        if index.ray == "main":
            value = self.term(recursor.base, parameters)
        else:
            projected = (self.root_weight,) + tuple(map(self.project, parameters))
            value = Element("main", self.language.natural_call(name, projected))
        for stage in range(index.index):
            input_value = Element(index.ray, stage)
            value = self.term(recursor.step, (input_value, value) + parameters)
        return value


def example_language() -> Language:
    language = Language()
    n, old, p0, p1 = (variable(i) for i in range(4))
    language.declare("pred", 0, ZERO, n)
    language.declare("zero_test", 0, successor(ZERO), ZERO)
    language.declare("choose", 2, variable(0), p1)
    language.declare("add", 1, variable(0), successor(old))
    language.declare("multiply", 1, ZERO, call("add", old, p0))
    language.declare("countdown", 1, variable(0), call("pred", old))
    language.declare(
        "overflow", 1, ZERO,
        call("choose", call("countdown", n, p0), successor(old), old),
    )
    language.declare("identity_copy", 0, ZERO, successor(old))
    language.declare("zero_copy", 0, ZERO, ZERO)
    language.declare("parity", 0, ZERO, call("choose", old, successor(ZERO), ZERO))
    return language


def run_checks(root_weight: int) -> dict:
    language = example_language()
    model = GhostModel(language, root_weight)
    zero = Element("main", 0)
    sample = tuple(Element("main", k) for k in range(6)) + tuple(
        Element("ghost", j) for j in range(4)
    )
    counts = {"standard_program_values": 0, "base_equations": 0,
              "successor_equations": 0, "term_homomorphism": 0,
              "numeral_target_reflection": 0, "compound_formula_reflection": 0}

    expected = {
        "pred": lambda x: max(x - 1, 0),
        "zero_test": lambda x: int(x == 0),
        "choose": lambda x, y, z: y if x == 0 else z,
        "add": lambda x, y: x + y,
        "multiply": lambda x, y: x * y,
        "countdown": lambda x, y: max(y - x, 0),
        "overflow": lambda x, y: max(x - y, 0),
        "identity_copy": lambda x: x,
        "zero_copy": lambda x: 0,
        "parity": lambda x: x % 2,
    }
    for name, recursor in language.descriptions.items():
        for args in itertools.product(range(6), repeat=recursor.parameter_count + 1):
            assert language.natural_call(name, args) == expected[name](*args)
            counts["standard_program_values"] += 1
        for parameters in itertools.product(sample, repeat=recursor.parameter_count):
            assert model.evaluate(name, (zero,) + parameters) == model.term(
                recursor.base, parameters
            )
            counts["base_equations"] += 1
            for value in sample:
                lhs = model.evaluate(name, (model.succ(value),) + parameters)
                previous = model.evaluate(name, (value,) + parameters)
                rhs = model.term(recursor.step, (value, previous) + parameters)
                assert lhs == rhs
                counts["successor_equations"] += 1

    x, y = variable(0), variable(1)
    terms = [x, y, ZERO, successor(x)]
    for name, recursor in language.descriptions.items():
        arguments = (x,) + (y,) * recursor.parameter_count
        terms.append(call(name, *arguments))
    terms.append(call("add", call("countdown", x, y), call("overflow", x, y)))
    targets = tuple(range(root_weight))
    for term in terms:
        language.validate(term, 2)
        for environment in itertools.product(sample, repeat=2):
            value = model.term(term, environment)
            projected = tuple(map(model.project, environment))
            natural_value = language.natural_term(term, projected)
            assert model.project(value) == natural_value
            counts["term_homomorphism"] += 1
            for target in targets:
                assert (value == Element("main", target)) == (natural_value == target)
                counts["numeral_target_reflection"] += 1
            # Negation, disjunction, conjunction, and classical implication
            # of reflected atoms also reflect. This checks illustrative cases.
            a, b = value == zero, value == Element("main", 1)
            c, d = natural_value == 0, natural_value == 1
            assert (not a, a or b, a and b, (not a) or b) == (
                not c, c or d, c and d, (not c) or d
            )
            counts["compound_formula_reflection"] += 4

    ghost = Element("ghost", 0)
    predecessor = model.evaluate("pred", (ghost,))
    recovered = model.succ(predecessor)
    assert ghost != zero and ghost != recovered
    selector_base = model.evaluate("choose", (zero, ghost, ghost))
    selector_bad = model.evaluate("choose", (ghost, ghost, ghost))
    assert selector_base == ghost and selector_bad != ghost
    for value in sample:
        assert model.evaluate("choose", (model.succ(value), ghost, ghost)) == ghost
    identity_bad = model.evaluate("identity_copy", (ghost,))
    assert identity_bad != ghost

    return {
        "status": "passed",
        "scope": (
            "Finite evaluations of the specified two-ray interpretation. "
            "Not a formal proof or a check of an infinite induction schema."
        ),
        "root_weight": root_weight,
        "singleton_numeral_fibers": list(targets),
        "programs": list(language.descriptions),
        "sample_elements": list(map(str, sample)),
        "counts": counts,
        "coverage_counterexample": {
            "element": str(ghost), "predecessor": str(predecessor),
            "successor_of_predecessor": str(recovered), "coverage_holds": False,
        },
        "equation_induction_counterexample": {
            "matrix": "choose(n, ghost(0), ghost(0)) = ghost(0)",
            "base_value": str(selector_base),
            "successor_instances_sampled": len(sample),
            "failure_input": str(ghost), "failure_value": str(selector_bad),
            "note": (
                "The successor equation makes every successor instance true; "
                "the finite loop above only illustrates that universal identity."
            ),
        },
        "identity_copy_counterexample": {
            "input": str(ghost), "output": str(identity_bad),
            "equal_projections": model.project(ghost) == model.project(identity_bad),
            "equal_elements": ghost == identity_bad,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-weight", type=int, default=2)
    parser.add_argument("--report", type=Path, default=Path(__file__).with_name("report.json"))
    options = parser.parse_args()
    report = run_checks(options.root_weight)
    options.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "counts": report["counts"],
                      "report": str(options.report)}, indent=2))


if __name__ == "__main__":
    main()
