TOWARD A SMALLER AXIOMATIZATION OF iPRA
====================================
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific date).

START WITH report.pdf. The complete editable LaTeX source is report.tex,
sections/, and results/baseline_table.tex.

STATUS
------
This package does NOT claim to have found a significant foundational
breakthrough or a new complete checker below the current draft envelope.
It contains an exact alternative ordinary induction presentation and
proved mathematical obstructions, with explicit limitations.

PROVED RESULTS
--------------
1. Reflexive-base normalization of equation induction.
   For E(n): s(n)=t(n), define
       N(n): C(n,t(0),s(n))=t(n).
   Induction restricted to these normalized families, with no independent
   base premise, has exactly the same deductive closure as full equation
   induction over selector equations, equality, and numerical coverage.
   The corresponding ordinary scalar theory is identity-equivalent to
   the established T_I realization, hence inherits its iPRA bi-interpretation.
   A smaller full checker has not been proved.

2. Bounded positive initialization seeds preserve
       R_M(a,b) iff a>0 or b<=M.
   Thus no finite direct term replacement using positive constant seeds
   defines ordinary addition, predecessor, or the arbitrary selector.
   This is NOT a theorem excluding formula-defined or changed-domain
   interpretations. Mixed zero/positive seeds are not settled.

3. Removing the retained atomic base leaves native closure underdetermined.
   A sound family of interpretations sends Q_y(y=1) to any chosen closed
   iPRA proposition. A separate intensional model refutes a proposed
   gate-based repair. No equiconsistency or complete bi-interpretation
   theorem is asserted for the base-deleted candidate.

4. Closed unary updates with arbitrary initializers still define a selector.
   The internal predecessor construction needed to finish that route is
   unresolved here; standard-model functional completeness is not used
   as a substitute for internal interpretation proofs.

CURRENT BASELINE
----------------
Repository: VladimirReshetnikov/ProveIt
Snapshot: 6fac3001a902d6666186fc4692a96de0ef296cf7
Six current archives; nine complete root checker variants.
Whole-program coordinate envelope under CPython 3.12.14:
    322 normalized tokens / 350 AST nodes / 903 normalized bytes.
These minima belong to different programs. They are not an absolute
lower bound over every possible axiomatization.

CONTENTS
--------
report.pdf / report.tex / sections/  Complete research report and source
comparison/checkers/                Nine unchanged complete baseline programs
comparison/manifest.json            Pinned source and archive identities
comparison/source_measure.py        Unchanged inherited measurement normalizer
comparison/licenses/                Inherited licenses and attribution notices
measure.py                          Offline full-program remeasurement
check_seed_models.py                Exhaustive finite paired-orbit experiment
results/                            Measurement, model-check, build, QA receipts
build.py / reproduce.py              Offline reproduction entry points
package.py                          Rebuild ZIP and SHA-256 manifest
ATTRIBUTION.txt / LICENSE.txt        Contribution boundaries and licensing
SHA256SUMS.txt                       Integrity manifest

REPRODUCE
---------
  python3 reproduce.py
  python3 reproduce.py --pdf
  python3 package.py

The scripts use Python's standard library. Exact source counts were obtained
with CPython 3.12.14; a different Python AST/unparser version can change them.
PDF rebuilding requires pdflatex with the standard packages in report.tex.
No reproduction command downloads anything from the network.

The finite seed experiment checks 131,072 transition-map pairs and
13,558,752 orbit comparisons, plus eight explicit arithmetic counterexamples.
All checks passed. These finite experiments do not prove the infinite
theorems. The report supplies written proofs, not Lean/Rocq formalizations.

No files were changed in the GitHub repository.
