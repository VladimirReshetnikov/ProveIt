#!/usr/bin/env python3
"""Finite sanity checks for the bounded positive-seed relation theorem.

Enumerate every pair of transition maps h_p,h_q on D={0,1,2,3}.  For
M=1,2 retain exactly the pairs satisfying

    R_M(u,v) => R_M(h_p(u),h_q(v))  for every u,v in D,
    R_M(a,b) := (a > 0 or b <= M).

This is the cross-preservation condition obtained by fixing two related
parameter tuples in a relation-preserving update.  For every retained
pair, compare all orbits starting at independently chosen positive seeds
d_1,d_2 in {1,...,M}, at all counter pairs in {0,...,8}^2 by default.

The script also verifies explicit standard-natural-number counterexamples
for addition, predecessor and the numerical selector, and demonstrates
why admitting a zero seed invalidates this particular invariant.

These finite checks are NOT a proof of the infinite theorem.  In
particular they do not certify induction over all function descriptions,
unbounded iteration, or any claim about first-order interpretations.
The first-zero argument in the accompanying report supplies the proof.

Usage:
    python3 check_seed_models.py
    python3 check_seed_models.py --max-counter 6 --output /tmp/seeds.json

Uses only the Python standard library.  Exit status is nonzero if any
claimed preservation or counterexample check fails.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path


DOMAIN = tuple(range(4))
BOUNDS = (1, 2)


def related(a: int, b: int, bound: int) -> bool:
    """The relation on standard nonnegative integers, not truncated values."""
    return a > 0 or b <= bound


def orbit(transition: tuple[int, ...], seed: int, last: int) -> tuple[int, ...]:
    """Return h^0(seed),...,h^last(seed), retaining every intermediate value."""
    values = [seed]
    for _ in range(last):
        values.append(transition[values[-1]])
    return tuple(values)


def require(condition: bool, message: str) -> None:
    """Use an explicit exception so Python -O cannot disable verification."""
    if not condition:
        raise RuntimeError(message)


def example(name: str, first: tuple[int, ...], second: tuple[int, ...],
            operation, bound: int) -> dict:
    input_checks = [related(a, b, bound) for a, b in zip(first, second)]
    first_output, second_output = operation(*first), operation(*second)
    output_check = related(first_output, second_output, bound)
    require(all(input_checks), f"{name}: inputs are not related")
    require(not output_check, f"{name}: outputs did not violate the relation")
    return {
        "operation": name,
        "bound_M": bound,
        "first_input": list(first),
        "second_input": list(second),
        "coordinate_relations": input_checks,
        "first_output": first_output,
        "second_output": second_output,
        "output_relation": output_check,
        "status": "VERIFIED_COUNTEREXAMPLE",
    }


def standard_counterexamples(bound: int) -> list[dict]:
    """These examples live in N; values need not lie in the finite D."""
    examples = [
        example("addition", (0, 0), (bound, bound),
                lambda x, y: x + y, bound),
        example("predecessor", (1,), (bound + 2,),
                lambda x: max(x - 1, 0), bound),
        example("selector_C", (0, 0, 1), (1, 1, bound + 1),
                lambda n, a, b: a if n == 0 else b, bound),
    ]
    zero_seed = example(
        "zero_seed_iteration_of_parameter_projection",
        (0, 1), (1, bound + 1),
        lambda n, p: 0 if n == 0 else p, bound,
    )
    h_p = (1,) * len(DOMAIN)
    h_q = (bound + 1,) * len(DOMAIN)
    cross_preserved = all(
        not related(u, v, bound) or related(h_p[u], h_q[v], bound)
        for u in DOMAIN for v in DOMAIN
    )
    require(cross_preserved, "Zero-seed example lost its update premise")
    zero_seed.update({
        "seed": 0,
        "first_transition": list(h_p),
        "second_transition": list(h_q),
        "cross_preservation_verified_on_D": cross_preserved,
        "explanation": (
            "The update is h_p(u)=p. Related inputs (n,p)=(0,1) and "
            "(m,q)=(1,M+1) give outputs 0 and M+1 from seed zero. "
            "Thus adding a zero-seeded iterator breaks R_M; this does "
            "not establish completeness of a mixed zero/positive basis."
        ),
    })
    examples.append(zero_seed)
    return examples


def finite_check(bound: int, last: int, transitions: tuple) -> dict:
    relation_pairs = tuple(
        (u, v) for u in DOMAIN for v in DOMAIN if related(u, v, bound)
    )
    seeds = tuple(range(1, bound + 1))
    orbits = {
        transition: {seed: orbit(transition, seed, last) for seed in seeds}
        for transition in transitions
    }
    preserving_pairs = 0
    comparisons = 0
    for h_p in transitions:
        for h_q in transitions:
            if not all(related(h_p[u], h_q[v], bound)
                       for u, v in relation_pairs):
                continue
            preserving_pairs += 1
            for first_seed in seeds:
                first_orbit = orbits[h_p][first_seed]
                for second_seed in seeds:
                    second_orbit = orbits[h_q][second_seed]
                    for n, first_value in enumerate(first_orbit):
                        for m, second_value in enumerate(second_orbit):
                            comparisons += 1
                            if not related(first_value, second_value, bound):
                                raise RuntimeError(json.dumps({
                                    "failure": "orbit relation",
                                    "M": bound,
                                    "h_p": h_p, "h_q": h_q,
                                    "seeds": [first_seed, second_seed],
                                    "counters": [n, m],
                                    "outputs": [first_value, second_value],
                                }))

    # Independent counting formula: classify h_p by whether it vanishes
    # nowhere, only possibly at zero, or at some positive input.
    size = len(DOMAIN)
    no_zero = (size - 1) ** size
    zero_only_at_zero = (size - 1) ** (size - 1)
    positive_zero = size ** size - no_zero - zero_only_at_zero
    expected_pairs = (
        no_zero * size ** size
        + zero_only_at_zero * (bound + 1) ** (bound + 1)
        * size ** (size - bound - 1)
        + positive_zero * (bound + 1) ** size
    )
    require(preserving_pairs == expected_pairs,
            f"M={bound}: enumeration and independent pair count disagree")
    require(comparisons == preserving_pairs * bound ** 2 * (last + 1) ** 2,
            f"M={bound}: incorrect number of orbit comparisons")
    return {
        "bound_M": bound,
        "domain": list(DOMAIN),
        "number_of_transition_functions": len(transitions),
        "total_pairs": len(transitions) ** 2,
        "related_state_pairs": len(relation_pairs),
        "preserving_pairs": preserving_pairs,
        "independent_count_formula_result": expected_pairs,
        "first_seed_choices": list(seeds),
        "second_seed_choices": list(seeds),
        "counter_min": 0,
        "counter_max": last,
        "counter_pairs_per_seed_pair": (last + 1) ** 2,
        "orbit_comparisons": comparisons,
        "counter_pairs_required_to_satisfy_R_M": False,
        "failures": 0,
        "status": "PASS",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--max-counter", type=int, default=8,
                        help="largest iteration count checked (default: 8)")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parent /
                        "results" / "seed_model_checks.json",
                        help="JSON results file")
    args = parser.parse_args()
    if args.max_counter < 0:
        parser.error("--max-counter must be nonnegative")

    transitions = tuple(itertools.product(DOMAIN, repeat=len(DOMAIN)))
    checks = [finite_check(bound, args.max_counter, transitions) for bound in BOUNDS]
    result = {
        "experiment": "Bounded positive-seed relation preservation",
        "relation": "R_M(a,b) iff a>0 or b<=M",
        "method": (
            "Exhaust all pairs of maps D->D satisfying cross preservation, "
            "then compare independently seeded orbits at every counter pair."
        ),
        "mathematical_scope": (
            "Necessary finite sanity experiment for the bounded positive-seed "
            "theorem. Finite checks are not a proof of the infinite theorem, "
            "unbounded iteration, term-definability, or bi-interpretability."
        ),
        "finite_checks": checks,
        "total_transition_pairs_examined": sum(c["total_pairs"] for c in checks),
        "total_preserving_pairs": sum(c["preserving_pairs"] for c in checks),
        "total_orbit_comparisons": sum(c["orbit_comparisons"] for c in checks),
        "standard_natural_number_counterexamples": [
            item for bound in BOUNDS for item in standard_counterexamples(bound)
        ],
        "status": "PASS",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "total_transition_pairs_examined": result["total_transition_pairs_examined"],
        "total_preserving_pairs": result["total_preserving_pairs"],
        "total_orbit_comparisons": result["total_orbit_comparisons"],
        "verified_counterexamples": len(result["standard_natural_number_counterexamples"]),
        "results": str(args.output),
    }, indent=2))


if __name__ == "__main__":
    main()
