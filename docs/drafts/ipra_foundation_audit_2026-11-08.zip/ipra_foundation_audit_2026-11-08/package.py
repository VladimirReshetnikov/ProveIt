"""Create a clean ZIP and an integrity manifest from this package."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent


def main():
    files = sorted(p for p in ROOT.rglob("*")
                   if p.is_file() and not any(part.startswith(".") or part == "__pycache__"
                                             for part in p.relative_to(ROOT).parts)
                   and p.name != "SHA256SUMS.txt")
    manifest = ROOT / "SHA256SUMS.txt"
    manifest.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                                + p.relative_to(ROOT).as_posix() + "\n" for p in files))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as output:
        for path in sorted(files + [manifest]):
            member = (Path(ROOT.name) / path.relative_to(ROOT)).as_posix()
            info = zipfile.ZipInfo(member, (2026, 11, 8, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None:
            raise RuntimeError("ZIP CRC verification failed")
    print(f"Created {archive.name}: {archive.stat().st_size} bytes, {len(files) + 1} files")


if __name__ == "__main__":
    main()
