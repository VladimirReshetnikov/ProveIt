"""Build report.pdf from the complete local LaTeX source; no network access."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def main():
    latex = shutil.which("pdflatex")
    if latex is None:
        raise SystemExit("pdflatex is required; install a local TeX distribution.")
    build = ROOT / ".build"
    build.mkdir(exist_ok=True)
    started = time.monotonic()
    command = [latex, "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "-output-directory=" + str(build), "report.tex"]
    for pass_number in (1, 2, 3):
        process = subprocess.run(command, cwd=ROOT, text=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (build / f"pass_{pass_number}.txt").write_text(process.stdout)
        if process.returncode:
            print(process.stdout[-16000:])
            raise SystemExit(process.returncode)
    pdf = ROOT / "report.pdf"
    shutil.copyfile(build / "report.pdf", pdf)
    log = (build / "report.log").read_text(errors="replace")
    warnings = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()
                or "LaTeX Warning" in line]
    receipt = {"status": "built", "engine": "pdflatex", "passes": 3,
               "pdf_bytes": pdf.stat().st_size,
               "pdf_sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
               "warnings": warnings, "seconds": round(time.monotonic() - started, 3)}
    (ROOT / "results/build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    if warnings:
        raise SystemExit("Review the recorded LaTeX warnings before delivery.")


if __name__ == "__main__":
    main()
