"""Recompute the evidence; add --pdf to rebuild the report too."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    scripts = ["measure.py", "check_seed_models.py"]
    if args.pdf:
        scripts.append("build.py")
    for script in scripts:
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
