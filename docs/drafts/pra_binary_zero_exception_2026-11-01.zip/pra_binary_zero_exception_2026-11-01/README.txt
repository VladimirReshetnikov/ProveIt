PRA FROM BINARY RECURSORS AND ZERO-EXCEPTION INDUCTION
Research report prepared for Vladimir Reshetnikov, 1 November 2026.

START HERE

  report.pdf              Complete mathematical paper.
  report.tex              Editable main LaTeX source.
  sections/               Included LaTeX compiler proof.
  AXIOMS.txt              Complete standalone theory specification.

MAIN RESULTS

1. One shared nonlogical basis works separately in classical and
   intuitionistic first-order equality logic. Every generated recursion
   symbol is binary, and its update sees only counter and current state:

     R_h(0,a)=a;  R_h(Sn,a)=h(n,R_h(n,a)).

   Add 0!=S0 and the following schema for arbitrary source equations B(n):

     [forall n ((n=0 OR B(n)) -> B(Sn))]
        -> forall n (n=0 OR B(n)).

   Arbitrary finite frozen parameters are allowed in B, not in h.

2. The zero exception supplies constructor coverage and native-equation
   induction. A staged zero-test argument derives all quantifier-free
   induction without presupposing native equality decidability, pairing,
   or parameterized recursion.

3. Explicit Cantor pairing and state compilers give whole-carrier,
   native-equality term bi-interpretations with matching first-order PRA.
   Both composites are internally proved to be identities. Hence the
   theories have a common conservative definitional extension and are
   equiconsistent.

WHAT IS SIMPLER

The expanded restricted induction presentation has 60 representative
display nodes, versus 94 for the supplied two-equation-disjunction basis.
The readable full-formula presentation remains 43 nodes; its computational
language now has fixed binary arity. The counts are disclosed partial
syntax-tree ledgers, not total encoding lengths or a global minimum.
No historical novelty is claimed for classical parameter-coding ideas.

FILES AND VERIFICATION

  formal/BinaryZeroException.lean
      Scoped constructive Lean 4.19 proof: ZE, coverage, equation induction,
      guarded residual equation, zero-test induction for order transitivity,
      native equality reflection, and source-wide QF-induction kernel.
  formal/SCOPE.txt
      Exact explicit hypotheses, checked scope, limitations, and provenance.
  formal/BinaryZeroException.log, formal/verification.json
      Successful compiler output; all eleven audited endpoints report no
      global axiom dependencies. This does not remove explicit hypotheses.
  artifacts/checks.py
      Literal recurrence evaluator, two syntactic compilers, finite
      diagnostics, a deliberate invalid-projection control, and AST counts.
  artifacts/results.json, artifacts/binary_descriptions.json
      Reproducible results and every generated binary description.
  audit/
      Six-archive pinned provenance, independent mathematical reviews,
      compilation record, and rendered-PDF review record.
  SHA256SUMS.txt
      Release hashes for every included file except this manifest itself.

The concrete full language, first-order derivation calculus, pairing and
description compilers, and complete interpretation round trips are written
proofs. They are not claimed as one end-to-end Lean theorem. Numerical
checks are diagnostics, not universal proofs about nonstandard models.

REPRODUCTION (OFFLINE)

Python 3, standard TeX Live, and the packages in report.tex suffice:

  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only

With Lean 4.19.0 installed:

  lean formal/BinaryZeroException.lean

No Mathlib is required. The checked kernel imports Std only.
Verify SHA256SUMS.txt before rebuilding if release integrity is the goal;
PDF metadata and regenerated logs may change on a rebuild.

SOURCE SCOPE

All six archives present in ProveIt/docs/drafts at commit
9db1e0b1a625767ac54321715f5669d75002360e were inspected. Source ZIP bytes
were verified against the Git blob IDs. The source manifest includes
immutable URLs and SHA-256 values; the original ZIPs are not duplicated.
The repository was read only.
