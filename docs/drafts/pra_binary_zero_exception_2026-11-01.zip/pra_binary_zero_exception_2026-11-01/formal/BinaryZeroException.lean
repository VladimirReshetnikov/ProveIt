import Std

/-!
# Binary-iterator arithmetic from zero-exception induction

Adapted from the supplied `TwoEquation.lean` kernel. Its source archive was
`pra_initialized_induction_2026-11-01.zip` (Git blob
4e1ad9a101b75560a5e219a8376011bc3d91214e), retrieved from ProveIt
at commit 9db1e0b1a625767ac54321715f5669d75002360e.

The carrier is arbitrary. `Core` supplies selected operations, their
computation equations, and an admitted-term interface, but no induction
or coverage. `Basis` adds native-equation induction and one fixed coverage
sentence. `ZeroException` instead adds exactly ZE, and its checked wrapper
constructs `Basis` without additional assumptions.

Zero-atom Boolean compilation is available BEFORE native equality
reflection. The new proof uses a guarded residual equation, the successor
order law, zero-atom induction for transitivity, and antisymmetry. There
is no Phi operation or telescoping-recursion hypothesis in this file.

The exposed ternary selector `cond` represents a derived source term;
it is not a new primitive symbol in the proposed binary-only signature.
The concrete binary-description syntax, the derivation of these selected
operations from that syntax, both description compilers, and first-order
interpretation round trips remain written proofs in the manuscript.
-/

namespace BinaryZeroException

universe u

structure Core (N : Type u) where
  zero : N
  succ : N → N
  pred : N → N
  cond : N → N → N → N
  add : N → N → N
  sub : N → N → N
  sep : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  cond_zero : ∀ a b, cond zero a b = a
  cond_succ : ∀ n a b, cond (succ n) a b = b
  add_zero : ∀ x, add x zero = x
  add_succ : ∀ x y, add x (succ y) = succ (add x y)
  sub_zero : ∀ x, sub x zero = x
  sub_succ : ∀ x y, sub x (succ y) = pred (sub x y)
  adm : (N → N) → Prop
  adm_const : ∀ a, adm (fun _ => a)
  adm_var : adm (fun x => x)
  adm_succ : ∀ f, adm f → adm (fun x => succ (f x))
  adm_pred : ∀ f, adm f → adm (fun x => pred (f x))
  adm_cond : ∀ f g h, adm f → adm g → adm h →
    adm (fun x => cond (f x) (g x) (h x))
  adm_add : ∀ f g, adm f → adm g → adm (fun x => add (f x) (g x))
  adm_sub : ∀ f g, adm f → adm g → adm (fun x => sub (f x) (g x))

structure Basis (N : Type u) extends Core N where
  cover : ∀ x, x = zero ∨ x = succ (pred x)
  ind_eq : ∀ f g, adm f → adm g →
    f zero = g zero →
    (∀ n, f n = g n → f (succ n) = g (succ n)) →
    ∀ n, f n = g n

structure ZeroException (N : Type u) extends Core N where
  zero_exception : ∀ f g, adm f → adm g →
    (∀ n, (n = zero ∨ f n = g n) → f (succ n) = g (succ n)) →
    ∀ n, n = zero ∨ f n = g n

namespace ZeroException

variable {N : Type u} (Z : ZeroException N)

theorem cover (x : N) : x = Z.zero ∨ x = Z.succ (Z.pred x) := by
  apply Z.zero_exception (fun n => n) (fun n => Z.succ (Z.pred n))
    Z.adm_var (Z.adm_succ _ (Z.adm_pred _ Z.adm_var)) ?_ x
  intro n _
  dsimp only
  rw [Z.pred_succ]

theorem atomicInd (f g : N → N) (hf : Z.adm f) (hg : Z.adm g)
    (hb : f Z.zero = g Z.zero)
    (hs : ∀ n, f n = g n → f (Z.succ n) = g (Z.succ n)) :
    ∀ n, f n = g n := by
  have hx := Z.zero_exception f g hf hg (by
    intro n hn
    rcases hn with hn | hn
    · subst n
      exact hs Z.zero hb
    · exact hs n hn)
  intro n
  rcases hx n with hn | hn
  · subst n
    exact hb
  · exact hn

def toBasis : Basis N where
  toCore := Z.toCore
  cover := Z.cover
  ind_eq := Z.atomicInd

end ZeroException

namespace Basis

variable {N : Type u} (B : Basis N)

def one : N := B.succ B.zero

theorem atomicInd (f g : N → N) (hf : B.adm f) (hg : B.adm g)
    (hb : f B.zero = g B.zero)
    (hs : ∀ n, f n = g n → f (B.succ n) = g (B.succ n)) :
    ∀ n, f n = g n := by
  exact B.ind_eq f g hf hg hb hs

theorem succ_injective {x y : N} (h : B.succ x = B.succ y) : x = y := by
  have hp := congrArg B.pred h
  rw [B.pred_succ, B.pred_succ] at hp
  exact hp

theorem succ_ne_zero (x : N) : B.succ x ≠ B.zero := by
  intro h
  have hx : x = B.zero := by
    have hp := congrArg B.pred h
    rw [B.pred_succ, B.pred_zero] at hp
    exact hp
  rw [hx] at h
  exact B.sep h.symm

theorem zero_add (x : N) : B.add B.zero x = x := by
  apply B.atomicInd (fun n => B.add B.zero n) (fun n => n)
    (B.adm_add _ _ (B.adm_const B.zero) B.adm_var) B.adm_var
    (B.add_zero B.zero) ?_ x
  intro n ih
  dsimp only at ih ⊢
  rw [B.add_succ, ih]

theorem succ_add (x y : N) : B.add (B.succ x) y = B.succ (B.add x y) := by
  apply B.atomicInd (fun n => B.add (B.succ x) n)
    (fun n => B.succ (B.add x n))
    (B.adm_add _ _ (B.adm_const _) B.adm_var)
    (B.adm_succ _ (B.adm_add _ _ (B.adm_const _) B.adm_var)) ?_ ?_ y
  · dsimp only
    rw [B.add_zero, B.add_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.add_succ, B.add_succ, ih]

theorem add_one (x : N) : B.add x B.one = B.succ x := by
  unfold one
  rw [B.add_succ, B.add_zero]

theorem sub_succ_succ (x y : N) :
    B.sub (B.succ x) (B.succ y) = B.sub x y := by
  apply B.atomicInd (fun n => B.sub (B.succ x) (B.succ n))
    (fun n => B.sub x n)
    (B.adm_sub _ _ (B.adm_const _) (B.adm_succ _ B.adm_var))
    (B.adm_sub _ _ (B.adm_const _) B.adm_var) ?_ ?_ y
  · dsimp only
    rw [B.sub_succ, B.sub_zero, B.pred_succ, B.sub_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.sub_succ (B.succ x) (B.succ n), ih, B.sub_succ x n]

theorem sub_add_cancel (x c : N) : B.sub (B.add x c) x = c := by
  apply B.atomicInd (fun n => B.sub (B.add n c) n) (fun _ => c)
    (B.adm_sub _ _ (B.adm_add _ _ B.adm_var (B.adm_const _)) B.adm_var)
    (B.adm_const _) ?_ ?_ x
  · dsimp only
    rw [B.zero_add, B.sub_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.succ_add, B.sub_succ_succ, ih]

theorem sub_self (x : N) : B.sub x x = B.zero := by
  have h := B.sub_add_cancel x B.zero
  rw [B.add_zero] at h
  exact h

theorem sub_next (x : N) : B.sub (B.succ x) x = B.one := by
  have h := B.sub_add_cancel x B.one
  rw [B.add_one] at h
  exact h

theorem add_eq_zero {x y : N} (h : B.add x y = B.zero) :
    x = B.zero ∧ y = B.zero := by
  rcases B.cover y with hy | hy
  · constructor
    · rw [hy, B.add_zero] at h
      exact h
    · exact hy
  · have hz : B.succ (B.add x (B.pred y)) = B.zero := by
      rw [hy, B.add_succ] at h
      exact h
    exact False.elim (B.succ_ne_zero _ hz)


theorem cond_same (z a : N) : B.cond z a a = a := by
  rcases B.cover z with hz | hz
  · rw [hz, B.cond_zero]
  · rw [hz, B.cond_succ]

def sign (x : N) : N := B.cond x B.zero B.one

theorem sign_zero : B.sign B.zero = B.zero := B.cond_zero _ _

theorem sign_succ (x : N) : B.sign (B.succ x) = B.one := B.cond_succ _ _ _

theorem sign_adm (f : N → N) (hf : B.adm f) : B.adm (fun n => B.sign (f n)) :=
  B.adm_cond _ _ _ hf (B.adm_const _) (B.adm_const _)

theorem sign_range (x : N) : B.sign x = B.zero ∨ B.sign x = B.one := by
  rcases B.cover x with hx | hx
  · exact Or.inl (by rw [hx, B.sign_zero])
  · exact Or.inr (by rw [hx, B.sign_succ])

theorem sign_eq_zero (x : N) : B.sign x = B.zero ↔ x = B.zero := by
  constructor
  · intro h
    rcases B.cover x with hx | hx
    · exact hx
    · rw [hx, B.sign_succ] at h
      exact False.elim (B.sep h.symm)
  · intro h
    rw [h, B.sign_zero]


structure Encoded (A : N → Prop) where
  bit : N → N
  admitted : B.adm bit
  range : ∀ n, bit n = B.zero ∨ bit n = B.one
  truth : ∀ n, bit n = B.zero ↔ A n

namespace Encoded

variable {B} {A D : N → Prop}

theorem false_of_one (a : B.Encoded A) {n : N} (h : a.bit n = B.one) :
    ¬ A n := by
  intro ha
  have hz := (a.truth n).2 ha
  exact B.sep (hz.symm.trans h)

theorem induction (a : B.Encoded A) (hb : A B.zero)
    (hs : ∀ n, A n → A (B.succ n)) : ∀ n, A n := by
  have hi := B.atomicInd a.bit (fun _ => B.zero) a.admitted
    (B.adm_const _) ((a.truth B.zero).2 hb)
    (fun n hn => (a.truth (B.succ n)).2 (hs n ((a.truth n).1 hn)))
  intro n
  exact (a.truth n).1 (hi n)

end Encoded

def encodedTrue : B.Encoded (fun _ => True) where
  bit := fun _ => B.zero
  admitted := B.adm_const _
  range := fun _ => Or.inl rfl
  truth := fun _ => ⟨fun _ => True.intro, fun _ => rfl⟩

def encodedFalse : B.Encoded (fun _ => False) where
  bit := fun _ => B.one
  admitted := B.adm_const _
  range := fun _ => Or.inr rfl
  truth := fun _ => ⟨fun h => B.sep h.symm, fun h => False.elim h⟩

def encodedAnd {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n ∧ D n) where
  bit := fun n => B.cond (a.bit n) (d.bit n) B.one
  admitted := B.adm_cond _ _ _ a.admitted d.admitted (B.adm_const _)
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact d.range n
    · rw [ha, one, B.cond_succ]
      exact Or.inr rfl
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      constructor
      · intro h
        exact ⟨(a.truth n).1 ha, (d.truth n).1 h⟩
      · intro h
        exact (d.truth n).2 h.2
    · rw [ha, one, B.cond_succ]
      constructor
      · intro h
        exact False.elim (B.sep h.symm)
      · intro h
        exact False.elim (a.false_of_one ha h.1)

def encodedOr {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n ∨ D n) where
  bit := fun n => B.cond (a.bit n) B.zero (d.bit n)
  admitted := B.adm_cond _ _ _ a.admitted (B.adm_const _) d.admitted
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact Or.inl rfl
    · rw [ha, one, B.cond_succ]
      exact d.range n
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact ⟨fun _ => Or.inl ((a.truth n).1 ha), fun _ => rfl⟩
    · rw [ha, one, B.cond_succ]
      constructor
      · intro h
        exact Or.inr ((d.truth n).1 h)
      · intro h
        rcases h with h | h
        · exact False.elim (a.false_of_one ha h)
        · exact (d.truth n).2 h

def encodedImp {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n → D n) where
  bit := fun n => B.cond (a.bit n) (d.bit n) B.zero
  admitted := B.adm_cond _ _ _ a.admitted d.admitted (B.adm_const _)
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact d.range n
    · rw [ha, one, B.cond_succ]
      exact Or.inl rfl
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      constructor
      · intro h _
        exact (d.truth n).1 h
      · intro h
        exact (d.truth n).2 (h ((a.truth n).1 ha))
    · rw [ha, one, B.cond_succ]
      constructor
      · intro _ h
        exact False.elim (a.false_of_one ha h)
      · intro _
        rfl


/-!
The zero-atom compiler is available BEFORE native equality reflection.
Only sign(x)=0 iff x=0 and the already proved Boolean range are used.
-/

def encodedZero (f : N → N) (hf : B.adm f) :
    B.Encoded (fun n => f n = B.zero) where
  bit := fun n => B.sign (f n)
  admitted := B.sign_adm f hf
  range := fun n => B.sign_range (f n)
  truth := fun n => B.sign_eq_zero (f n)

theorem guarded_residual (x n : N) :
    B.cond (B.sub x n) x (B.add n (B.sub x n)) = x := by
  apply B.atomicInd
    (fun k => B.cond (B.sub x k) x (B.add k (B.sub x k)))
    (fun _ => x)
    (B.adm_cond _ _ _ (B.adm_sub _ _ (B.adm_const _) B.adm_var)
      (B.adm_const _) (B.adm_add _ _ B.adm_var
        (B.adm_sub _ _ (B.adm_const _) B.adm_var)))
    (B.adm_const _) ?_ ?_ n
  · dsimp only
    rw [B.sub_zero, B.zero_add, B.cond_same]
  · intro k ih
    dsimp only at ih ⊢
    rcases B.cover (B.sub x k) with hr | hr
    · rw [B.sub_succ, hr, B.pred_zero, B.cond_zero]
    · rw [hr, B.cond_succ, B.add_succ] at ih
      rw [B.sub_succ, hr, B.pred_succ, B.succ_add, ih, B.cond_same]

theorem residual_cases (x n : N) :
    B.sub x n = B.zero ∨ x = B.add n (B.sub x n) := by
  rcases B.cover (B.sub x n) with hr | hr
  · exact Or.inl hr
  · right
    have h := B.guarded_residual x n
    rw [hr, B.cond_succ] at h
    exact h.symm.trans (congrArg (B.add n) hr.symm)

theorem sub_one_eq {x n : N} (h : B.sub x n = B.one) : x = B.succ n := by
  have hg := B.guarded_residual x n
  rw [h, one, B.cond_succ, B.add_succ, B.add_zero] at hg
  exact hg.symm

theorem pred_zero_cases {x : N} (h : B.pred x = B.zero) :
    x = B.zero ∨ x = B.one := by
  rcases B.cover x with hx | hx
  · exact Or.inl hx
  · right
    rw [h] at hx
    exact hx

theorem sub_le_step (x n : N) :
    B.sub x (B.succ n) = B.zero ↔ B.sub x n = B.zero ∨ x = B.succ n := by
  constructor
  · intro h
    rw [B.sub_succ] at h
    rcases B.pred_zero_cases h with hr | hr
    · exact Or.inl hr
    · exact Or.inr (B.sub_one_eq hr)
  · intro h
    rcases h with h | h
    · rw [B.sub_succ, h, B.pred_zero]
    · rw [h, B.sub_self]

/-!
Transitivity is an induction on a propositional combination of ZERO atoms.
The zero-atom encoder above licenses it without any native-equality bit.
-/
theorem le_trans (x y z : N)
    (hxy : B.sub x y = B.zero) (hyz : B.sub y z = B.zero) :
    B.sub x z = B.zero := by
  let a : B.Encoded (fun k =>
      (B.sub x y = B.zero ∧ B.sub y k = B.zero) → B.sub x k = B.zero) :=
    B.encodedImp
      (B.encodedAnd
        (B.encodedZero (fun _ => B.sub x y) (B.adm_const _))
        (B.encodedZero (fun k => B.sub y k)
          (B.adm_sub _ _ (B.adm_const _) B.adm_var)))
      (B.encodedZero (fun k => B.sub x k)
        (B.adm_sub _ _ (B.adm_const _) B.adm_var))
  have hbase : (B.sub x y = B.zero ∧ B.sub y B.zero = B.zero) →
      B.sub x B.zero = B.zero := by
    intro h
    have hy : y = B.zero := (B.sub_zero y).symm.trans h.2
    rw [hy] at h
    exact h.1
  have hstep : ∀ k,
      ((B.sub x y = B.zero ∧ B.sub y k = B.zero) → B.sub x k = B.zero) →
      ((B.sub x y = B.zero ∧ B.sub y (B.succ k) = B.zero) →
        B.sub x (B.succ k) = B.zero) := by
    intro k ih h
    rcases (B.sub_le_step y k).1 h.2 with hyk | hyk
    · exact (B.sub_le_step x k).2 (Or.inl (ih ⟨h.1, hyk⟩))
    · rw [hyk] at h
      exact h.1
  exact a.induction hbase hstep z ⟨hxy, hyz⟩

theorem sub_reflects {x y : N}
    (hxy : B.sub x y = B.zero) (hyx : B.sub y x = B.zero) : x = y := by
  rcases B.cover y with hy | hy
  · rw [hy, B.sub_zero] at hxy
    exact hxy.trans hy.symm
  · have hx : B.sub x (B.succ (B.pred y)) = B.zero := by
      rw [← hy]
      exact hxy
    rcases (B.sub_le_step x (B.pred y)).1 hx with hxp | hxp
    · have hbad := B.le_trans y x (B.pred y) hyx hxp
      rw [hy, B.pred_succ, B.sub_next] at hbad
      exact False.elim (B.sep hbad.symm)
    · exact hxp.trans hy.symm


def eqBit (x y : N) : N :=
  B.cond (B.add (B.sub x y) (B.sub y x)) B.zero B.one

theorem eqBit_adm (f g : N → N) (hf : B.adm f) (hg : B.adm g) :
    B.adm (fun n => B.eqBit (f n) (g n)) := by
  exact B.adm_cond _ _ _
    (B.adm_add _ _ (B.adm_sub _ _ hf hg) (B.adm_sub _ _ hg hf))
    (B.adm_const _) (B.adm_const _)

theorem eqBit_range (x y : N) :
    B.eqBit x y = B.zero ∨ B.eqBit x y = B.one := by
  unfold eqBit
  rcases B.cover (B.add (B.sub x y) (B.sub y x)) with h | h
  · exact Or.inl (by rw [h, B.cond_zero])
  · exact Or.inr (by rw [h, B.cond_succ])

theorem eqBit_zero (x y : N) : B.eqBit x y = B.zero ↔ x = y := by
  constructor
  · intro h
    have hd : B.add (B.sub x y) (B.sub y x) = B.zero := by
      rcases B.cover (B.add (B.sub x y) (B.sub y x)) with hd | hd
      · exact hd
      · have hone : B.one = B.zero := by
          unfold eqBit at h
          rw [hd, B.cond_succ] at h
          exact h
        exact False.elim (B.sep hone.symm)
    have hp := B.add_eq_zero hd
    exact B.sub_reflects hp.1 hp.2
  · intro h
    subst y
    unfold eqBit
    rw [B.sub_self, B.add_zero, B.cond_zero]

theorem eqBit_one (x y : N) : B.eqBit x y = B.one ↔ x ≠ y := by
  constructor
  · intro h hxy
    have hz := (B.eqBit_zero x y).2 hxy
    exact B.sep (hz.symm.trans h)
  · intro h
    rcases B.eqBit_range x y with hz | ho
    · exact False.elim (h ((B.eqBit_zero x y).1 hz))
    · exact ho

include B in
theorem equality_decidable (x y : N) : x = y ∨ x ≠ y := by
  rcases B.eqBit_range x y with hz | ho
  · exact Or.inl ((B.eqBit_zero x y).1 hz)
  · exact Or.inr ((B.eqBit_one x y).1 ho)


def encodedEq (f g : N → N) (hf : B.adm f) (hg : B.adm g) :
    B.Encoded (fun n => f n = g n) where
  bit := fun n => B.eqBit (f n) (g n)
  admitted := B.eqBit_adm f g hf hg
  range := fun n => B.eqBit_range (f n) (g n)
  truth := fun n => B.eqBit_zero (f n) (g n)

/-!
This syntax is parameterized by admitted unary terms. It formalizes the
logical part of the QF compiler; parsing and interpreting the concrete
finite recursion descriptions are outside this file's scope.
-/

inductive QF (B : Basis N) : Type u where
  | atom (f g : N → N) (hf : B.adm f) (hg : B.adm g) : QF B
  | bot : QF B
  | top : QF B
  | conj : QF B → QF B → QF B
  | disj : QF B → QF B → QF B
  | impl : QF B → QF B → QF B

namespace QF

variable {B}

def denote : QF B → N → Prop
  | atom f g _ _ => fun n => f n = g n
  | bot => fun _ => False
  | top => fun _ => True
  | conj a d => fun n => a.denote n ∧ d.denote n
  | disj a d => fun n => a.denote n ∨ d.denote n
  | impl a d => fun n => a.denote n → d.denote n

def encode : (a : QF B) → B.Encoded a.denote
  | atom f g hf hg => B.encodedEq f g hf hg
  | bot => B.encodedFalse
  | top => B.encodedTrue
  | conj a d => B.encodedAnd a.encode d.encode
  | disj a d => B.encodedOr a.encode d.encode
  | impl a d => B.encodedImp a.encode d.encode

theorem induction (a : QF B) (hb : a.denote B.zero)
    (hs : ∀ n, a.denote n → a.denote (B.succ n)) : ∀ n, a.denote n := by
  exact a.encode.induction hb hs

end QF

end Basis

namespace ZeroException

variable {N : Type u} (Z : ZeroException N)

theorem qf_induction (a : Basis.QF Z.toBasis) (hb : a.denote Z.zero)
    (hs : ∀ n, a.denote n → a.denote (Z.succ n)) : ∀ n, a.denote n := by
  exact a.induction hb hs

end ZeroException

namespace Basis

variable {N : Type u} (B : Basis N)

theorem zero_exception (f g : N → N) (hf : B.adm f) (hg : B.adm g)
    (hs : ∀ n, (n = B.zero ∨ f n = g n) → f (B.succ n) = g (B.succ n)) :
    ∀ n, n = B.zero ∨ f n = g n := by
  let a : QF B := .disj (.atom (fun n => n) (fun _ => B.zero)
    B.adm_var (B.adm_const _)) (.atom f g hf hg)
  exact a.induction (Or.inl rfl) (fun n hn => Or.inr (hs n hn))

def toZeroException : ZeroException N where
  toCore := B.toCore
  zero_exception := B.zero_exception

end Basis

end BinaryZeroException

#print axioms BinaryZeroException.ZeroException.cover
#print axioms BinaryZeroException.ZeroException.atomicInd
#print axioms BinaryZeroException.Basis.guarded_residual
#print axioms BinaryZeroException.Basis.sub_le_step
#print axioms BinaryZeroException.Basis.le_trans
#print axioms BinaryZeroException.Basis.sub_reflects
#print axioms BinaryZeroException.Basis.eqBit_zero
#print axioms BinaryZeroException.Basis.encodedZero
#print axioms BinaryZeroException.Basis.QF.induction
#print axioms BinaryZeroException.ZeroException.qf_induction
#print axioms BinaryZeroException.Basis.zero_exception
