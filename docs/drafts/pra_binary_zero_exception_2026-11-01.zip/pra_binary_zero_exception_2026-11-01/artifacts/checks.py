#!/usr/bin/env python3
"""Finite diagnostics and exact syntax counts, not a proof of the metatheorems.

Every target recursion has exactly two arguments. Its stored update has
only counter and accumulator variables. The evaluator executes the literal
recurrences. Pairing and projections are expanded terms, not host shortcuts.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple = ()

    def data(self):
        return [self.tag, *[x.data() if isinstance(x, Term) else x for x in self.args]]


def var(i):
    return Term("var", (i,))


ZERO = Term("zero")


def succ(t):
    return Term("succ", (t,))


ONE = succ(ZERO)


def app(name, *args):
    return Term("app", (name, *args))


def subst(t, env):
    if t.tag == "var":
        return env[t.args[0]]
    if t.tag == "zero":
        return t
    if t.tag == "succ":
        return succ(subst(t.args[0], env))
    return app(t.args[0], *[subst(x, env) for x in t.args[1:]])


def free_vars(t):
    if t.tag == "var":
        return {t.args[0]}
    return set().union(*(free_vars(x) for x in t.args if isinstance(x, Term)))


class BinaryLanguage:
    def __init__(self):
        self.bodies = {}

    def add(self, name, body):
        assert name not in self.bodies
        assert free_vars(body) <= {0, 1}
        self.validate(body)
        self.bodies[name] = body
        return name

    def validate(self, t):
        if t.tag == "app":
            assert t.args[0] in self.bodies
            assert len(t.args) == 3
        for x in t.args:
            if isinstance(x, Term):
                self.validate(x)

    def data(self):
        return [{"name": name, "arity": 2, "update": body.data()}
                for name, body in self.bodies.items()]


class OrdinaryLanguage:
    def __init__(self):
        self.descriptions = {}

    def add(self, name, parameter_count, base, step):
        assert name not in self.descriptions
        assert free_vars(base) <= set(range(parameter_count))
        assert free_vars(step) <= set(range(parameter_count + 2))
        self.validate(base)
        self.validate(step)
        self.descriptions[name] = (parameter_count, base, step)

    def validate(self, t):
        if t.tag == "app":
            assert t.args[0] in self.descriptions
            k = self.descriptions[t.args[0]][0]
            assert len(t.args[1:]) == k + 1
        for x in t.args:
            if isinstance(x, Term):
                self.validate(x)


class Evaluator:
    """Memoized finite execution of the displayed equations, without rewrites."""
    def __init__(self, language):
        self.language = language
        self.cache = {}
        self.updates = 0

    def term(self, t, env):
        if t.tag == "var":
            return env[t.args[0]]
        if t.tag == "zero":
            return 0
        if t.tag == "succ":
            return self.term(t.args[0], env) + 1
        return self.call(t.args[0], tuple(self.term(x, env) for x in t.args[1:]))

    def call(self, name, args):
        key = (name, args)
        if key in self.cache:
            return self.cache[key]
        n, *parameters = args
        if n > 250_000:
            raise RuntimeError("Diagnostic size limit; no mathematical bound is claimed.")
        if isinstance(self.language, BinaryLanguage):
            value = parameters[0]
            body = self.language.bodies[name]
            environment = lambda j, v: (j, v)
        else:
            _, base, body = self.language.descriptions[name]
            value = self.term(base, tuple(parameters))
            environment = lambda j, v: (j, *parameters, v)
        self.cache[(name, (0, *parameters))] = value
        # Reusing already computed prefixes changes cost, not the recurrence.
        for j in range(n):
            next_key = (name, (j + 1, *parameters))
            if next_key in self.cache:
                value = self.cache[next_key]
            else:
                value = self.term(body, environment(j, value))
                self.updates += 1
                self.cache[next_key] = value
        return value


class Helpers:
    def __init__(self, language):
        self.language = language
        n, v = var(0), var(1)
        self.p_name = language.add("predecessor_iterator", n)
        self.z_name = language.add("zero_mask_iterator", ZERO)
        self.a_name = language.add("addition_iterator", succ(v))
        self.d_name = language.add("subtraction_iterator", self.pred(v))
        self.t_name = language.add("triangular_iterator", self.add(v, succ(n)))
        self.v_name = language.add(
            "triangular_inverse_iterator",
            self.case(self.sub(self.tri(succ(v)), succ(n)), succ(v), v),
        )

    def pred(self, x):
        return app(self.p_name, x, ZERO)

    def mask(self, x, a):
        return app(self.z_name, x, a)

    def add(self, x, y):
        return app(self.a_name, y, x)

    def sub(self, x, y):
        return app(self.d_name, y, x)

    def case(self, x, a, b):
        return self.add(self.mask(x, a), self.mask(self.mask(x, ONE), b))

    def tri(self, x):
        return app(self.t_name, x, ZERO)

    def inv(self, x):
        return app(self.v_name, x, ZERO)

    def pair(self, x, y):
        return self.add(self.tri(self.add(x, y)), y)

    def right(self, x):
        return self.sub(x, self.tri(self.inv(x)))

    def left(self, x):
        return self.sub(self.inv(x), self.right(x))

    def encode(self, xs):
        result = ZERO
        for x in xs:
            result = self.pair(result, x)
        return result

    def decode(self, code, length, position):
        result = code
        for _ in range(length - position - 1):
            result = self.left(result)
        return self.right(result)


class ForwardCompiler:
    def __init__(self, source):
        self.source = source
        self.target = BinaryLanguage()
        self.helpers = Helpers(self.target)
        self.roots = {}

    def term(self, t):
        if t.tag in {"var", "zero"}:
            return t
        if t.tag == "succ":
            return succ(self.term(t.args[0]))
        name = t.args[0]
        self.compile(name)
        return subst(self.roots[name], [self.term(x) for x in t.args[1:]])

    def compile(self, name):
        if name in self.roots:
            return
        k, base, step = self.source.descriptions[name]
        h = self.helpers
        base_t = self.term(base)
        step_t = self.term(step)
        counter, state = var(0), var(1)
        code = h.left(state)
        body_step = subst(step_t, [counter]
                          + [h.decode(code, k, i) for i in range(k)]
                          + [h.right(state)])
        target_name = self.target.add("compiled_" + name, h.pair(code, body_step))
        parameters = [var(i + 1) for i in range(k)]
        seed = h.pair(h.encode(parameters), subst(base_t, parameters))
        self.roots[name] = h.right(app(target_name, var(0), seed))


class ReverseCompiler:
    def __init__(self, source):
        self.source = source
        self.target = OrdinaryLanguage()
        self.names = {}

    def term(self, t):
        if t.tag in {"var", "zero"}:
            return t
        if t.tag == "succ":
            return succ(self.term(t.args[0]))
        name = t.args[0]
        self.compile(name)
        return app(self.names[name], *[self.term(x) for x in t.args[1:]])

    def compile(self, name):
        if name in self.names:
            return
        body = self.term(self.source.bodies[name])
        ordinary_name = "ordinary_" + name
        # Ordinary update variables: counter, frozen seed, accumulator.
        self.target.add(ordinary_name, 1, var(0), subst(body, [var(0), var(2)]))
        self.names[name] = ordinary_name


def source_examples():
    s = OrdinaryLanguage()
    s.add("add", 1, var(0), succ(var(2)))
    s.add("pred", 0, ZERO, var(0))
    s.add("sub", 1, var(0), app("pred", var(2)))
    s.add("mul", 1, ZERO, app("add", var(2), var(1)))
    s.add("pow", 1, ONE, app("mul", var(2), var(1)))
    s.add("factorial", 0, ONE, app("mul", succ(var(0)), var(1)))
    # A nonzero, nonconstant base and a frozen parameter used in the update.
    s.add("affine", 1, succ(var(0)), app("add", var(2), succ(var(1))))
    # This unused third parameter checks tuple projection depth and order.
    s.add("parameter_pick", 3, var(1), var(3))
    return s


def compiler_checks():
    source = source_examples()
    forward = ForwardCompiler(source)
    for name in source.descriptions:
        forward.compile(name)
    reverse = ReverseCompiler(forward.target)
    round_roots = {name: reverse.term(t) for name, t in forward.roots.items()}
    source_eval = Evaluator(source)
    target_eval = Evaluator(forward.target)
    back_eval = Evaluator(reverse.target)
    cases = {
        "add": list(itertools.product(range(4), range(4))),
        "pred": [(i,) for i in range(7)],
        "sub": list(itertools.product(range(4), range(4))),
        "mul": list(itertools.product(range(3), range(3))),
        "pow": list(itertools.product(range(3), range(3))),
        "factorial": [(i,) for i in range(5)],
        "affine": list(itertools.product(range(3), range(3))),
        "parameter_pick": [(0, 0, 1, 2), (1, 0, 1, 2), (2, 1, 0, 1)],
    }
    rows = []
    for name, inputs in cases.items():
        for args in inputs:
            a = source_eval.call(name, args)
            b = target_eval.term(forward.roots[name], args)
            c = back_eval.term(round_roots[name], args)
            assert a == b == c, (name, args, a, b, c)
        rows.append({"description": name, "cases": len(inputs)})
    # Check arbitrary seeds in the reverse direction, not just compiled seeds.
    raw_rows = []
    for name in list(forward.target.bodies)[:4]:
        reverse.compile(name)
        for n, a in itertools.product(range(4), range(5)):
            assert target_eval.call(name, (n, a)) == back_eval.call(reverse.names[name], (n, a))
        raw_rows.append({"binary_description": name, "cases": 20})
    h = forward.helpers
    for a, b in itertools.product(range(8), repeat=2):
        code = h.pair(var(0), var(1))
        assert target_eval.term(h.left(code), (a, b)) == a
        assert target_eval.term(h.right(code), (a, b)) == b
    for z in range(128):
        t = var(0)
        assert target_eval.term(h.pair(h.left(t), h.right(t)), (z,)) == z
    # Deliberately corrupted projection must fail a non-symmetric witness.
    corrupted = target_eval.term(h.left(h.pair(var(0), var(1))), (2, 1))
    assert corrupted != 1
    return {
        "ordinary_roundtrip": rows,
        "ordinary_roundtrip_cases": sum(row["cases"] for row in rows),
        "raw_seed_reverse_cases": sum(row["cases"] for row in raw_rows),
        "pair_left_right_cases": 64,
        "pair_reconstruction_cases": 128,
        "all_update_free_variables_subset": [0, 1],
        "all_generated_function_arities": [2],
        "literal_recurrence_updates": {
            "source": source_eval.updates, "target": target_eval.updates,
            "roundtrip": back_eval.updates,
        },
        "negative_control_swapped_projection_rejected": True,
    }, forward.target.data()


def arithmetic_checks():
    pred = lambda x: max(x - 1, 0)
    sub = lambda x, y: max(x - y, 0)
    case = lambda z, a, b: a if z == 0 else b
    guard_count = 0
    for x, n in itertools.product(range(65), repeat=2):
        r = sub(x, n)
        assert case(r, x, n + r) == x
        assert (sub(x, n + 1) == 0) == (sub(x, n) == 0 or x == n + 1)
        assert (sub(x, n) == 0 and sub(n, x) == 0) == (x == n)
        assert case(sub(x, n) + sub(n, x), 0, 1) == int(x != n)
        guard_count += 1
    truth_table_rows = 0
    for a, b in itertools.product((0, 1), repeat=2):
        assert case(a, b, 1) == int(not (a == 0 and b == 0))
        assert case(a, 0, b) == int(not (a == 0 or b == 0))
        assert case(a, b, 0) == int(not (a != 0 or b == 0))
        truth_table_rows += 1
    # The product obstruction: a=(0,1) is neither zero nor S(p(a)).
    a = (0, 1)
    zero = (0, 0)
    successor_pred = tuple(pred(t) + 1 for t in a)
    assert a != zero and a != successor_pred
    return {
        "guard_order_equality_cases": guard_count,
        "boolean_truth_table_rows": truth_table_rows,
        "product_cover_counterexample": list(a),
        "product_successor_pred": list(successor_pred),
    }


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple = ()

    def count(self):
        return 1 + sum(x.count() for x in self.children)


def nd(label, *xs):
    return Node(label, tuple(xs))


def forall(names, body):
    for name in reversed(names):
        body = nd("forall:" + name, body)
    return body


def metrics():
    n, a, z = nd("n"), nd("a"), nd("0")
    sn = nd("S", n)
    base = forall(["a"], nd("=", nd("R", z, a), a))
    step = forall(["n", "a"], nd("=", nd("R", sn, a), nd("h", n, nd("R", n, a))))
    separation = nd("implies", nd("=", z, nd("S", z)), nd("false"))
    rows = []
    for q in range(5):
        parameters = [nd(f"c{i}") for i in range(q)]
        names = [f"c{i}" for i in range(q)]
        A = lambda x: nd("A", x, *parameters)
        E = lambda x: nd("=", nd("s", x, *parameters), nd("t", x, *parameters))
        B = lambda x: nd("or", nd("=", x, z), E(x))
        two = lambda x: nd("or", E(x), nd("=", nd("u", x, *parameters), nd("v", x, *parameters)))
        ind = lambda F: forall(names, nd("implies", nd("and", F(z), forall(["n"], nd("implies", F(n), F(sn)))), forall(["n"], F(n))))
        ze = forall(names, nd("implies", forall(["n"], nd("implies", B(n), E(sn))), forall(["n"], B(n))))
        fixed = base.count() + step.count() + separation.count()
        row = {"induction_parameters": q, "base": base.count(), "step": step.count(),
               "separation": separation.count(), "QFI": ind(A).count(),
               "EqInd": ind(E).count(), "two_equation_induction": ind(two).count(),
               "zero_exception": ze.count(), "binary_QFI_total": fixed + ind(A).count(),
               "binary_ZE_total": fixed + ze.count(), "two_equation_total": fixed + ind(two).count()}
        assert row["binary_QFI_total"] == 38 + 5*q
        assert row["binary_ZE_total"] == 53 + 7*q
        assert row["two_equation_total"] == 77 + 17*q
        rows.append(row)
    return {"convention": "One node per occurrence/application/equality/connective/falsity/individual quantifier; no binding-name child; 1=S0 and negation expanded.",
            "rows": rows, "limits": "Display counts exclude descriptor code, bound-variable metadata, full enumerators, substituted bodies, and proof lengths."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("results.json"))
    args = parser.parse_args()
    compiler, descriptions = compiler_checks()
    result = {"scope": "Finite numerical diagnostics and exact AST counts. Universal proofs and scoped Lean verification are separate.",
              "compiler": compiler, "arithmetic": arithmetic_checks(), "metrics": metrics()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    args.output.with_name("binary_descriptions.json").write_text(json.dumps(descriptions, indent=2) + "\n")
    print(json.dumps({"status": "passed", "ordinary_cases": compiler["ordinary_roundtrip_cases"],
                      "raw_seed_cases": compiler["raw_seed_reverse_cases"],
                      "recurrence_updates": compiler["literal_recurrence_updates"],
                      "metrics_q1": result["metrics"]["rows"][1]}, indent=2))


if __name__ == "__main__":
    main()
