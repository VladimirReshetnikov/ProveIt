#!/usr/bin/env python3
"""Rebuild diagnostics and the PDF without network access."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--pdf-only", action="store_true")
    args = parser.parse_args()
    if args.checks_only and args.pdf_only:
        parser.error("Choose at most one partial build flag.")
    root = Path(__file__).resolve().parent
    if not args.pdf_only:
        subprocess.run([sys.executable, str(root / "artifacts/checks.py")], cwd=root, check=True)
    if args.checks_only:
        return
    build = root / "_build"
    build.mkdir(exist_ok=True)
    engine = shutil.which("pdflatex")
    if not engine:
        raise SystemExit("pdflatex is required to compile the LaTeX source.")
    results = []
    for iteration in range(3):
        p = subprocess.run([engine, "-interaction=nonstopmode", "-halt-on-error",
                            "-output-directory=" + str(build), "report.tex"],
                           cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True)
        (build / f"pass-{iteration+1}.log").write_text(p.stdout)
        results.append({"pass": iteration + 1, "exit_code": p.returncode})
        if p.returncode:
            print(p.stdout[-8000:])
            raise SystemExit(p.returncode)
    shutil.copyfile(build / "report.pdf", root / "report.pdf")
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    shutil.copyfile(build / "report.log", audit / "latex_final.log")
    warnings = [line for line in (build / "report.log").read_text().splitlines()
                if "Warning" in line or "Overfull" in line or "Underfull" in line]
    record = {"passes": results, "warnings": warnings,
              "pdf_size_bytes": (root / "report.pdf").stat().st_size,
              "visual_review": "Separate rendered-page inspection is required."}
    (audit / "build.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
