#!/usr/bin/env python3
"""Executable companion to ``pra_axiomatization.tex`` (Python 3, stdlib only).

This is a reference implementation and a bounded sanity check, not a proof
assistant or a formal verification of PRA.  In particular, numerical checks
do not establish induction, quantify over all primitive recursive definitions,
or verify the metatheorems in the paper.  The symbolic latch check is more
specific: it checks the three displayed selector rewrites with an arbitrary
accumulator variable, rather than guessing a numerical accumulator bound.

Run this file directly.  It writes ``check_report.json`` beside itself.
The AST and declarations below make recursion parameters explicit and fixed.
There is no evaluator function *inside* the represented arithmetic language.
"""

from __future__ import annotations

import argparse
import itertools
import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Mapping, Sequence, Tuple, Union


# The arithmetic term grammar is precisely 0, S(t), variables, and calls.
@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    term: "Term"


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Call:
    name: str
    args: Tuple["Term", ...]


Term = Union[Zero, Succ, Var, Call]
ZERO = Zero()
ONE = Succ(ZERO)


def call(name: str, *args: Term) -> Call:
    return Call(name, tuple(args))


def numeral(value: int) -> Term:
    if value < 0:
        raise ValueError("Numerals must be natural numbers")
    result: Term = ZERO
    for _ in range(value):
        result = Succ(result)
    return result


def pretty(term: Term) -> str:
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return "S(" + pretty(term.term) + ")"
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Call):
        return term.name + "(" + ", ".join(map(pretty, term.args)) + ")"
    raise TypeError(term)


@dataclass(frozen=True)
class Composition:
    name: str
    args: Tuple[str, ...]
    body: Term


@dataclass(frozen=True)
class Recursion:
    name: str
    args: Tuple[str, ...]
    recursion_argument: int
    base: Term
    step: Term
    # The base may use only fixed parameters.  The step may additionally use
    # n (the preceding recursion index) and previous (the preceding value).


Declaration = Union[Composition, Recursion]


class PrimitiveRecursiveSystem:
    """A transparent interpreter for an acyclic list of PR declarations.

    The host-language interpreter is deliberately not claimed to be primitive
    recursive uniformly in an arbitrary input program.  Each declared object
    function is obtained by the usual composition/primitive-recursion syntax.
    """

    def __init__(self) -> None:
        self.declarations: Dict[str, Declaration] = {}
        self.cache: Dict[Tuple[str, Tuple[int, ...]], int] = {}

    def _validate(self, term: Term, variables: set[str]) -> None:
        if isinstance(term, Zero):
            return
        if isinstance(term, Succ):
            self._validate(term.term, variables)
            return
        if isinstance(term, Var):
            if term.name not in variables:
                raise ValueError("Unbound declaration variable: " + term.name)
            return
        if isinstance(term, Call):
            if term.name not in self.declarations:
                raise ValueError("Dependency must be declared earlier: " + term.name)
            if len(term.args) != len(self.declarations[term.name].args):
                raise ValueError("Wrong arity in call to " + term.name)
            for arg in term.args:
                self._validate(arg, variables)
            return
        raise TypeError(term)

    def add(self, declaration: Declaration) -> None:
        if declaration.name in self.declarations:
            raise ValueError("Duplicate definition: " + declaration.name)
        if len(set(declaration.args)) != len(declaration.args):
            raise ValueError("Argument names must be distinct")
        if {"n", "previous"}.intersection(declaration.args):
            raise ValueError("n and previous are reserved recursion variables")
        if isinstance(declaration, Composition):
            self._validate(declaration.body, set(declaration.args))
        else:
            index = declaration.recursion_argument
            if not 0 <= index < len(declaration.args):
                raise ValueError("Invalid recursion argument")
            fixed = set(declaration.args) - {declaration.args[index]}
            self._validate(declaration.base, fixed)
            self._validate(declaration.step, fixed | {"n", "previous"})
        self.declarations[declaration.name] = declaration

    def term(self, expression: Term, environment: Mapping[str, int]) -> int:
        if isinstance(expression, Zero):
            return 0
        if isinstance(expression, Succ):
            return self.term(expression.term, environment) + 1
        if isinstance(expression, Var):
            return environment[expression.name]
        if isinstance(expression, Call):
            return self.function(
                expression.name,
                *(self.term(arg, environment) for arg in expression.args),
            )
        raise TypeError(expression)

    def function(self, name: str, *arguments: int) -> int:
        declaration = self.declarations[name]
        if len(arguments) != len(declaration.args):
            raise ValueError("Wrong arity for " + name)
        if any(type(arg) is not int or arg < 0 for arg in arguments):
            raise ValueError("The arithmetic domain is the natural numbers")
        key = (name, tuple(arguments))
        if key in self.cache:
            return self.cache[key]
        environment = dict(zip(declaration.args, arguments))
        if isinstance(declaration, Composition):
            result = self.term(declaration.body, environment)
            self.cache[key] = result
            return result
        index = declaration.recursion_argument
        target = arguments[index]
        del environment[declaration.args[index]]
        prefix = list(arguments)
        prefix[index] = 0
        base_key = (name, tuple(prefix))
        if base_key not in self.cache:
            self.cache[base_key] = self.term(declaration.base, environment)
        result = self.cache[base_key]
        for preceding_index in range(target):
            prefix[index] = preceding_index + 1
            next_key = (name, tuple(prefix))
            if next_key not in self.cache:
                # No parameter is replaced by the changing recursion index.
                step_environment = dict(environment)
                step_environment.update(n=preceding_index, previous=result)
                self.cache[next_key] = self.term(declaration.step, step_environment)
            result = self.cache[next_key]
        return result

    def manifest(self) -> list[dict]:
        result = []
        for declaration in self.declarations.values():
            entry = {"name": declaration.name, "arguments": list(declaration.args)}
            if isinstance(declaration, Composition):
                entry.update(kind="composition", body=pretty(declaration.body))
            else:
                entry.update(
                    kind="primitive_recursion",
                    recursion_argument=declaration.args[declaration.recursion_argument],
                    fixed_parameters=[
                        name for index, name in enumerate(declaration.args)
                        if index != declaration.recursion_argument
                    ],
                    base=pretty(declaration.base),
                    step=pretty(declaration.step),
                )
            result.append(entry)
        return result


def arithmetic_system() -> PrimitiveRecursiveSystem:
    system = PrimitiveRecursiveSystem()
    x, y, z, a, b = map(Var, ("x", "y", "z", "a", "b"))
    n, previous = Var("n"), Var("previous")
    system.add(Recursion("p", ("x",), 0, ZERO, n))
    system.add(Recursion("c", ("x", "a", "b"), 0, a, b))
    system.add(Recursion("e", ("x",), 0, ZERO, call("c", previous, ONE, ZERO)))
    system.add(Recursion("h", ("x",), 0, ZERO,
                         call("c", call("e", n), previous, Succ(previous))))
    system.add(Recursion("d", ("x",), 0, ZERO, Succ(Succ(previous))))
    pp_x = call("p", call("p", x))
    system.add(Composition("sigma", ("x",),
                           call("c", call("e", x), Succ(Succ(x)), pp_x)))
    system.add(Composition("tau", ("x",),
                           call("c", call("e", x), call("c", x, ONE, pp_x),
                                Succ(Succ(x)))))
    system.add(Recursion("delta", ("x", "y"), 1, call("d", x),
                         call("tau", previous)))
    system.add(Recursion("U", ("z", "y"), 1, z, call("sigma", previous)))
    return system


# Quantifier-free formula syntax.  Negation is implication to Falsehood.
@dataclass(frozen=True)
class AtomicEq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Falsehood:
    pass


@dataclass(frozen=True)
class Conjunction:
    left: "Formula"
    right: "Formula"


@dataclass(frozen=True)
class Disjunction:
    left: "Formula"
    right: "Formula"


@dataclass(frozen=True)
class Implication:
    left: "Formula"
    right: "Formula"


Formula = Union[AtomicEq, Falsehood, Conjunction, Disjunction, Implication]


def compile_boolean(formula: Formula) -> Term:
    """Compile to code 0=true, 1=false, with the paper's selector order."""
    if isinstance(formula, AtomicEq):
        return call("c", call("delta", formula.left, formula.right), ZERO, ONE)
    if isinstance(formula, Falsehood):
        return ONE
    left, right = compile_boolean(formula.left), compile_boolean(formula.right)
    if isinstance(formula, Conjunction):
        return call("c", left, right, ONE)
    if isinstance(formula, Disjunction):
        return call("c", left, ZERO, right)
    if isinstance(formula, Implication):
        return call("c", left, right, ZERO)
    raise TypeError(formula)


def formula_truth(formula: Formula, environment: Mapping[str, int],
                  system: PrimitiveRecursiveSystem) -> bool:
    """Independent ordinary Boolean semantics, without compiled code."""
    if isinstance(formula, AtomicEq):
        return system.term(formula.left, environment) == system.term(formula.right, environment)
    if isinstance(formula, Falsehood):
        return False
    left = formula_truth(formula.left, environment, system)
    right = formula_truth(formula.right, environment, system)
    if isinstance(formula, Conjunction):
        return left and right
    if isinstance(formula, Disjunction):
        return left or right
    if isinstance(formula, Implication):
        return (not left) or right
    raise TypeError(formula)


def selector_normal_form(term: Term) -> Term:
    """Rewrite only c(0,a,b)=a and c(S(t),a,b)=b, under congruence.

    Variables are retained as variables; in particular r has no assumed range.
    """
    if isinstance(term, (Zero, Var)):
        return term
    if isinstance(term, Succ):
        return Succ(selector_normal_form(term.term))
    if isinstance(term, Call):
        args = tuple(selector_normal_form(arg) for arg in term.args)
        if term.name == "c":
            if len(args) != 3:
                raise ValueError("Selector has three arguments")
            if isinstance(args[0], Zero):
                return args[1]
            if isinstance(args[0], Succ):
                return args[2]
        return Call(term.name, args)
    raise TypeError(term)


class Checks:
    def __init__(self) -> None:
        self.counts: Dict[str, int] = {}

    def equal(self, group: str, actual, expected, witness=None) -> None:
        if actual != expected:
            raise AssertionError({"group": group, "actual": actual,
                                  "expected": expected, "witness": witness})
        self.counts[group] = self.counts.get(group, 0) + 1


def integer_encode(value: int) -> int:
    return 2 * value if value >= 0 else -2 * value - 1


def integer_decode(code: int) -> int:
    return code // 2 if code % 2 == 0 else -(code + 1) // 2


def check_signed_arithmetic(system: PrimitiveRecursiveSystem, checks: Checks,
                            bound: int) -> None:
    f = system.function
    for x in range(2 * bound + 5):
        checks.equal("predecessor", f("p", x), max(0, x - 1), x)
        checks.equal("parity", f("e", x), x % 2, x)
        checks.equal("halving", f("h", x), x // 2, x)
        checks.equal("doubling", f("d", x), 2 * x, x)
        checks.equal("sigma_integer_oracle", f("sigma", x), integer_encode(integer_decode(x) + 1), x)
        checks.equal("tau_integer_oracle", f("tau", x), integer_encode(integer_decode(x) - 1), x)
        checks.equal("inverse_shifts", f("sigma", f("tau", x)), x, x)
        checks.equal("inverse_shifts", f("tau", f("sigma", x)), x, x)
    for x, y in itertools.product(range(bound + 1), repeat=2):
        difference = f("delta", x, y)
        checks.equal("signed_difference_oracle", difference, integer_encode(x - y), [x, y])
        checks.equal("equality_detection", difference == 0, x == y, [x, y])
        checks.equal("delta_successor", f("delta", x + 1, y), f("sigma", difference), [x, y])
        checks.equal("difference_reconstruction", f("U", difference, y), f("d", x), [x, y])
        checks.equal("upshift_integer_oracle", f("U", x, y), integer_encode(integer_decode(x) + y), [x, y])
        checks.equal("upshift_tau_commutes", f("U", f("tau", x), y), f("tau", f("U", x, y)), [x, y])
    for x in range(bound + 1):
        checks.equal("delta_diagonal", f("delta", x, x), 0, x)
        checks.equal("upshift_zero", f("U", 0, x), f("d", x), x)
        checks.equal("half_double", f("h", f("d", x)), x, x)


def check_boolean_compiler(system: PrimitiveRecursiveSystem, checks: Checks) -> dict:
    x, y = Var("x"), Var("y")
    atoms: list[Formula] = [
        AtomicEq(x, y),
        AtomicEq(call("p", x), y),
        AtomicEq(call("d", x), call("U", ZERO, y)),
        Falsehood(),
    ]
    formulas = list(atoms)
    formulas += [Implication(atom, Falsehood()) for atom in atoms]
    for constructor in (Conjunction, Disjunction, Implication):
        formulas += [constructor(left, right) for left, right in itertools.product(atoms, repeat=2)]
    a, b, c = atoms[:3]
    formulas += [
        Disjunction(a, Implication(a, Falsehood())),
        Implication(Conjunction(a, Implication(a, b)), b),
        Implication(Implication(a, b), Implication(Implication(b, c), Implication(a, c))),
        Conjunction(Disjunction(a, b), Implication(a, c)),
        Implication(Implication(Implication(a, b), a), a),
        Implication(Implication(a, Falsehood()), Disjunction(b, c)),
    ]
    for number, formula in enumerate(formulas):
        term = compile_boolean(formula)
        for x_value, y_value in itertools.product(range(10), repeat=2):
            environment = {"x": x_value, "y": y_value}
            code = system.term(term, environment)
            checks.equal("compiler_boolean_range", code in (0, 1), True, [number, environment])
            checks.equal("compiler_semantics", code, 0 if formula_truth(formula, environment, system) else 1,
                         [number, environment])
    # Independently exercise the complete truth tables without depending on
    # which assignments happen to be realized by the displayed atomic terms.
    for left, right in itertools.product((0, 1), repeat=2):
        truth_left, truth_right = left == 0, right == 0
        checks.equal("connective_truth_tables", system.function("c", left, right, 1),
                     0 if truth_left and truth_right else 1, ["and", left, right])
        checks.equal("connective_truth_tables", system.function("c", left, 0, right),
                     0 if truth_left or truth_right else 1, ["or", left, right])
        checks.equal("connective_truth_tables", system.function("c", left, right, 0),
                     0 if (not truth_left) or truth_right else 1, ["implies", left, right])
    return {"formula_count": len(formulas), "assignments_per_formula": 100,
            "coding": "0=true, 1=false"}


def check_latch(system: PrimitiveRecursiveSystem, checks: Checks, maximum_length: int) -> dict:
    r = Var("r")
    symbolic_cases = []
    for left, right, expected in ((0, 0, r), (1, 0, ZERO), (1, 1, ZERO)):
        current = call("c", numeral(left), r, ZERO)
        following = call("c", numeral(right), current, ZERO)
        current_normal = selector_normal_form(current)
        following_normal = selector_normal_form(following)
        checks.equal("symbolic_latch_allowed_cases", current_normal, expected, [left, right])
        checks.equal("symbolic_latch_allowed_cases", following_normal, expected, [left, right])
        symbolic_cases.append({"b_n": left, "b_successor_n": right,
                               "L_n": pretty(current_normal), "L_successor_n": pretty(following_normal)})
    forbidden_current = selector_normal_form(call("c", ZERO, r, ZERO))
    forbidden_next = selector_normal_form(call("c", ONE, forbidden_current, ZERO))
    checks.equal("symbolic_latch_forbidden_case", forbidden_current, r)
    checks.equal("symbolic_latch_forbidden_case", forbidden_next, ZERO)

    # One actual family of primitive-recursion declarations, with parameter a
    # held fixed, instantiates the paper's prefix and latch definitions.
    x, a, n, previous = Var("x"), Var("a"), Var("n"), Var("previous")
    system.add(Composition("b_demo", ("x", "a"), compile_boolean(AtomicEq(x, a))))
    system.add(Recursion("P_demo", ("x", "a"), 0, ONE,
                         call("c", call("b_demo", n, a), previous, ZERO)))
    system.add(Composition("L_demo", ("x", "a"),
                           call("c", call("b_demo", x, a), call("P_demo", x, a), ZERO)))
    for index, parameter in itertools.product(range(17), repeat=2):
        f = system.function
        current = f("L_demo", index, parameter)
        checks.equal("declared_latch_prefix_identity", current, f("P_demo", index + 1, parameter),
                     [index, parameter])
        checks.equal("declared_latch_recurrence", f("L_demo", index + 1, parameter),
                     f("c", f("b_demo", index + 1, parameter), current, 0), [index, parameter])

    sequence_count = no_jump_count = induction_hypothesis_count = 0
    masked_forbidden_transitions = unmasked_forbidden_transitions = 0
    for length in range(1, maximum_length + 1):
        for word in itertools.product((0, 1), repeat=length):
            sequence_count += 1
            prefix = 1
            latch_values = []
            prefix_values = []
            for bit in word:
                prefix_values.append(prefix)
                current = prefix if bit == 0 else 0
                latch_values.append(current)
                prefix = current
            for index in range(length - 1):
                pair = word[index:index + 2]
                current, following = latch_values[index:index + 2]
                if pair != (0, 1):
                    checks.equal("finite_latch_allowed_transitions", following, current, [word, index])
                elif prefix_values[index] == 0:
                    masked_forbidden_transitions += 1
                    checks.equal("finite_latch_masked_forbidden", following, current, [word, index])
                else:
                    unmasked_forbidden_transitions += 1
                    checks.equal("finite_latch_unmasked_forbidden", (current, following), (1, 0), [word, index])
            no_jump = all(pair != (0, 1) for pair in zip(word, word[1:]))
            if no_jump:
                no_jump_count += 1
                checks.equal("finite_no_jump_constancy", len(set(latch_values)), 1, word)
                if word[0] == 0:
                    induction_hypothesis_count += 1
                    checks.equal("finite_induction_latch", latch_values, [1] * length, word)
                    checks.equal("finite_induction_boolean_conclusion", word, (0,) * length, word)
    return {
        "prefix_definition": "P(0)=1; P(S(n))=c(b(n),P(n),0)",
        "latch_definition": "L(n)=c(b(n),P(n),0)=P(S(n))",
        "derived_transition": "L(S(n))=c(b(S(n)),L(n),0)",
        "symbolic_accumulator": "r is an unrestricted variable; no range assumption",
        "symbolic_allowed_cases": symbolic_cases,
        "symbolic_forbidden_case": {"b_n": 0, "b_successor_n": 1,
                                    "L_n": pretty(forbidden_current), "L_successor_n": pretty(forbidden_next)},
        "maximum_boolean_word_length": maximum_length,
        "boolean_words_checked": sequence_count,
        "no_zero_to_one_jump_words": no_jump_count,
        "words_with_b_zero_equal_zero_and_no_jump": induction_hypothesis_count,
        "forbidden_transitions_masked_by_zero_accumulator": masked_forbidden_transitions,
        "forbidden_transitions_with_nonzero_accumulator": unmasked_forbidden_transitions,
        "scope": "Symbolic local selector identities plus exhaustive finite-word checks; not an induction proof.",
    }


def check_product_counterexample(system: PrimitiveRecursiveSystem, checks: Checks) -> dict:
    witness = (0, 1)
    zero = (0, 0)
    predecessor = tuple(system.function("p", value) for value in witness)
    successor_of_predecessor = tuple(value + 1 for value in predecessor)
    checks.equal("product_cover_counterexample", witness == zero or witness == successor_of_predecessor, False)
    return {
        "domain": "N x N, with all primitive recursive operations interpreted coordinatewise",
        "zero": list(zero), "witness": list(witness),
        "predecessor_of_witness": list(predecessor),
        "successor_of_predecessor": list(successor_of_predecessor),
        "cover_at_witness": False,
        "scope": "Only the displayed failed cover instance is computed here. The paper proves that all atomic equation-induction instances hold in this product; this script does not enumerate or verify infinitely many instances.",
    }


def run(bound: int = 32, word_length: int = 14) -> dict:
    started = time.perf_counter()
    if not 1 <= bound <= 64:
        raise ValueError("Use an arithmetic bound between 1 and 64")
    if not 1 <= word_length <= 16:
        raise ValueError("Use a Boolean word length between 1 and 16")
    system = arithmetic_system()
    checks = Checks()
    check_signed_arithmetic(system, checks, bound)
    compiler = check_boolean_compiler(system, checks)
    latch = check_latch(system, checks, word_length)
    product = check_product_counterexample(system, checks)
    return {
        "status": "passed",
        "purpose": "Check concrete recursion declarations, selector argument order, arithmetic encodings, Boolean compilation, and the exact latch calculation used in the paper.",
        "not_a_formal_proof": True,
        "limitations": [
            "Bounded numerical identities do not prove universal arithmetic identities or induction schemas.",
            "The host interpreter is not asserted to be a primitive recursive universal evaluator.",
            "The Boolean semantics check is an ordinary finite semantics comparison, not an intuitionistic completeness proof.",
            "The product check is one counterexample instance; its all-equation-induction property is proved mathematically in the paper.",
            "No Lean or Rocq formalization is supplied by this script.",
        ],
        "arithmetic_bound_inclusive": bound,
        "unary_code_bound_inclusive": 2 * bound + 4,
        "checks_by_group": checks.counts,
        "total_checks": sum(checks.counts.values()),
        "compiler": compiler,
        "latch": latch,
        "product_counterexample": product,
        "declarations": system.manifest(),
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=32)
    parser.add_argument("--word-length", type=int, default=14)
    parser.add_argument("--report", type=Path, default=Path(__file__).with_name("check_report.json"))
    args = parser.parse_args()
    report = run(args.bound, args.word_length)
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "total_checks": report["total_checks"],
                      "elapsed_seconds": report["elapsed_seconds"], "report": str(args.report)}, sort_keys=True))


if __name__ == "__main__":
    main()
