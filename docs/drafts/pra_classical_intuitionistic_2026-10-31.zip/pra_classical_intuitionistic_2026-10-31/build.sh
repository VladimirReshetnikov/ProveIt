#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/reference_check.py
latexmk -pdf -interaction=nonstopmode -halt-on-error pra_axiomatization.tex
