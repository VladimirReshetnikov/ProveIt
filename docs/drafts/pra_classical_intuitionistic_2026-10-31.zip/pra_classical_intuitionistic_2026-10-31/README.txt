PRA IN CLASSICAL AND INTUITIONISTIC LOGIC
31 October 2026

MAIN RESULT
-----------
Use ordinary classical or intuitionistic first-order logic with equality.
The arithmetic axioms are the primitive-recursion defining equations D,
0 != S(0), and the following single schema, with all parameters a fixed:

  [forall x ((x=0 or s(x,a)=t(x,a)) -> s(S(x),a)=t(S(x),a))]
       -> forall y (y=0 or s(y,a)=t(y,a)).

Universally quantify a. The schema ranges over pairs of terms, not over
object-language functions. This gives exactly classical PRA in classical
logic, and exactly intuitionistic PRA in intuitionistic logic. Both are
compared in the same effective primitive-recursive language.

The paper proves the equivalence constructively. The schema supplies
constructor cases and equation induction; seven explicit equation inductions
certify an equality detector; numerical Boolean codes then recover every
quantifier-free induction instance.

The paper also supplies a constancy presentation, a literal-induction
classical alternative, a product countermodel to bare equation induction,
a Harrop obstruction in intuitionistic logic, and a review of all six
supplied drafts. See the final section for further research questions.

CONTENTS
--------
pra_axiomatization.pdf       Complete paper.
pra_axiomatization.tex       Main LaTeX source.
sections/*.tex              All included source sections.
axioms.txt                   Standalone exact specification and alternatives.
artifacts/reference_check.py Python 3 reference interpreter and checks.
artifacts/check_report.json  Recorded scope and results of the checks.
sources.json                 Pinned draft filenames, blob hashes and SHA-256s.
build.sh                     Rebuild checks and PDF with Python 3 and latexmk.
SHA256SUMS                   SHA-256 hashes of the delivered archive contents.

BUILD
-----
From this directory, run:

  sh build.sh

Requirements: Python 3.10 or later, a LaTeX installation with latexmk,
pdfLaTeX, and the packages named in pra_axiomatization.tex. The Python
companion needs only the standard library. Alternatively compile the main
TeX file twice with pdfLaTeX. Running the checks rewrites the JSON report
(including its runtime); the original SHA256SUMS describes the delivered
files, not subsequent rebuilds.

VALIDATION STATUS
-----------------
The default companion run passed 413,551 checks, including arithmetic
identities on bounded inputs, 62 Boolean formulas under 100 assignments,
symbolic accumulator transitions with an arbitrary accumulator value, and
all 32,766 Boolean words of lengths 1 through 14.

These checks are NOT a formal verification of the equivalence theorem.
They check concrete program definitions and local identities. The paper
contains the universal mathematical proofs. No Lean or Rocq development
is claimed. The host-language interpreter is not asserted to be a total
primitive-recursive universal evaluator in the arithmetic language.

SOURCE SNAPSHOT
---------------
Six archives from VladimirReshetnikov/ProveIt/docs/drafts were reviewed at:
ffbbfd31452e7188a9e3ba62c81a3bdb64072b82
Exact source metadata is in sources.json. The original draft archives are
not duplicated in this package. No absolute minimality or literature
priority claim is made.
