"""Recompute the reported measurements, tests, arithmetic evidence, and PDF."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
COMMANDS = [
    ['measure.py'],
    ['validation/run.py'],
    ['validation/block_tests.py', 'checker.py', '--output', 'results/block_audit.json'],
    ['validation/predecessor_sanity.py', 'results'],
    ['build.py'],
]


def main():
    for command in COMMANDS:
        subprocess.run([sys.executable, *command], cwd=ROOT, check=True)
    print('All reproduction steps passed.')


if __name__ == '__main__':
    main()
