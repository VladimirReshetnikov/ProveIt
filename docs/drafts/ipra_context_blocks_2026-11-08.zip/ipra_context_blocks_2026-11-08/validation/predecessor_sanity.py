"""Finite checks and exact scalar syntax for the reversed-comparison predecessor.

Run: python3 predecessor_sanity.py [output-directory]
No external packages. Larger checks use L's proved recursion specification;
the expanded inherited scalar comparator is evaluated only at small inputs.
"""
import json
from itertools import count
from pathlib import Path
import sys


def iteration(n, a, h):
    for _ in range(n):
        a = h(a)
    return a


def comparison(x, y):
    """Evaluation by precisely L's zero/successor recursion equations."""
    while x and y:
        x -= 1
        y -= 1
    return int(x == 0)


def choose(n, a, b):
    return a if n == 0 else b


def update(m, u):
    return choose(comparison(m, u + 1), u + 1, u)


def v(t, m):
    return iteration(t, 0, lambda u: update(m, u))


def p(m):
    return v(m, m)


# A finite AST in exactly var / zero / succ / scalar iter.
# Fresh bound names make each expansion capture avoiding by construction.
names = count()
zero = ("zero",)


def var(name):
    return ("var", name)


def succ(t):
    return ("succ", t)


def scalar_iter(n, a, build_update):
    name = "u" + str(next(names))
    return ("iter", n, a, name, build_update(var(name)))


def c(n, a, b):
    return scalar_iter(n, a, lambda unused: b)


def z(n):
    return c(n, succ(zero), zero)


def add(a, b):
    return scalar_iter(b, a, succ)


def parity(n):
    return scalar_iter(n, zero, z)


def j(u):
    return add(add(z(u), parity(u)), parity(u))


def m3(n):
    return scalar_iter(n, zero, j)


def ramp(n):
    return scalar_iter(n, zero, lambda u: succ(add(u, m3(u))))


def factor(u):
    return c(parity(u), ramp(u), u)


def exp2(x):
    return scalar_iter(x, succ(zero), lambda u: add(u, u))


def ell(x, y):
    return parity(scalar_iter(y, exp2(x), factor))


def new_predecessor(m):
    return scalar_iter(m, zero, lambda u: c(ell(m, succ(u)), succ(u), u))


def old_predecessor(m):
    return scalar_iter(m, zero, lambda u: c(ell(succ(succ(u)), m), u, succ(u)))


def evaluate(t, env):
    tag = t[0]
    if tag == "zero":
        return 0
    if tag == "var":
        return env[t[1]]
    if tag == "succ":
        return evaluate(t[1], env) + 1
    assert tag == "iter"
    n, a, name, body = t[1:]
    steps = evaluate(n, env)
    value = evaluate(a, env)
    local = dict(env)
    for _ in range(steps):
        local[name] = value
        value = evaluate(body, local)
    return value


def stats(t, bound=frozenset()):
    tag = t[0]
    if tag == "var":
        return 1, 0, set() if t[1] in bound else {t[1]}
    if tag == "zero":
        return 1, 0, set()
    if tag == "succ":
        nodes, successors, free = stats(t[1], bound)
        return 1 + nodes, 1 + successors, free
    assert tag == "iter"
    pieces = [stats(t[1], bound), stats(t[2], bound), stats(t[4], bound | {t[3]})]
    return (1 + sum(x[0] for x in pieces), sum(x[1] for x in pieces),
            set().union(*(x[2] for x in pieces)))


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent / "results"
    out.mkdir(parents=True, exist_ok=True)
    bound = 30
    counts = {"comparator": 0, "update_shift": 0, "iterate_shift": 0, "predecessor": 0}
    for x in range(bound + 1):
        assert comparison(0, x) == 1
        assert comparison(x + 1, 0) == 0
        for y in range(bound + 1):
            assert comparison(x + 1, y + 1) == comparison(x, y)
            counts["comparator"] += 1
    for m in range(bound + 1):
        assert update(m + 2, 0) == 1
        for u in range(bound + 1):
            assert update(m + 2, u + 1) == update(m + 1, u) + 1
            counts["update_shift"] += 1
        for t in range(bound + 1):
            assert v(t + 1, m + 2) == v(t, m + 1) + 1
            counts["iterate_shift"] += 1
        assert p(m) == max(m - 1, 0)
        assert p(m + 1) == m
        assert p(m + 2) == p(m + 1) + 1
        counts["predecessor"] += 1
    new = new_predecessor(var("m"))
    old = old_predecessor(var("m"))
    new_stats, old_stats = stats(new), stats(old)
    assert new_stats[2] == old_stats[2] == {"m"}
    assert new_stats[0] + 1 == old_stats[0]
    assert new_stats[1] + 1 == old_stats[1]
    expanded_values = []
    for n in range(4):
        actual = evaluate(new, {"m": n})
        assert actual == max(n - 1, 0)
        expanded_values.append({"input": n, "output": actual})
    (out / "predecessor_expanded.json").write_text(json.dumps(new, indent=2) + "\n")
    report = {
        "status": "PASS", "recurrence_check_bound": bound, "checks": counts,
        "expanded_ast_evaluation": expanded_values,
        "old_ast_nodes": old_stats[0], "new_ast_nodes": new_stats[0],
        "old_successor_nodes": old_stats[1], "new_successor_nodes": new_stats[1],
        "free_variables": sorted(new_stats[2]),
        "scope": "finite computational evidence; internal proof is in predecessor_new.tex"
    }
    (out / "predecessor_validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
