"""Reproduce the independent finite audit of a context-block checker.

Usage:
    python3 block_tests.py /absolute/path/to/checker.py --output audit.json

The checker is loaded only for testing; this module is never imported by
its acceptance program. These finite checks are not a soundness proof.
"""
import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import platform
import random

SEED = 20261108
CASES = 30000


def definitions(path):
    tree = ast.parse(path.read_text())
    tree.body = [node for node in tree.body
                 if isinstance(node, (ast.Import, ast.ImportFrom,
                                      ast.Assign, ast.FunctionDef))]
    namespace = {}
    exec(compile(tree, str(path), 'exec'), namespace)
    return namespace


def packet_verdict(namespace, packet):
    namespace['k'] = 0
    stack = copy.deepcopy(packet)
    namespace['take'] = stack.pop
    try:
        return bool(namespace['check'](stack.pop(), []))
    except BaseException:
        return False


def outcome(call):
    try:
        return 'ok', repr(call())
    except BaseException as error:
        return 'error', type(error).__name__


def audit(path):
    namespace = definitions(path)
    major = [0, 0, []]
    truth_cases = [
        ('zero', 0, True),
        ('boolean_true', True, True),
        ('positive_fraction', .5, True),
        ('nan', float('nan'), True),
        ('positive_infinity', float('inf'), True),
        ('string', 'abc', False),
        ('object', {}, False),
        ('null', None, False),
        ('false_equation', [[], [0]], False),
        ('negative_formula_label', -1, False),
    ]
    results = []
    for name, goal, expected in truth_cases:
        actual = packet_verdict(namespace, [0, [major, 0], goal])
        if actual != expected:
            raise ValueError((name, actual, expected))
        results.append({'name': name, 'accepted': actual, 'expected': expected})

    generator = random.Random(SEED)
    leaves = [-4, -3, -2, -1, 0, 1, 2, 3, 4, False, True,
              .5, -1.5, None, 'x', {}, float('nan'), float('inf')]

    def tree(depth):
        if depth == 0 or generator.randrange(3) == 0:
            return copy.deepcopy(generator.choice(leaves))
        return [tree(depth - 1) for _ in range(generator.randrange(6))]

    successful = 0
    for index in range(CASES):
        namespace['k'] = -generator.randrange(1, 5)
        block = [tree(3), tree(3)]
        image = tree(2)
        combined = outcome(lambda: namespace['inst'](block, image, -1))
        separate = outcome(lambda: [namespace['inst'](block[0], image),
                                    namespace['inst'](block[1], image)])
        # The enclosing try/except may alter the final exception type.
        # Acceptance and all successful returned values must coincide.
        if (combined[0] == 'ok') != (separate[0] == 'ok'):
            raise ValueError((index, block, image, combined, separate))
        if combined[0] == 'ok':
            if combined != separate:
                raise ValueError((index, block, image, combined, separate))
            successful += 1

    return {
        'status': 'PASS',
        'scope': 'Finite boundary checks; not a proof-assistant certification.',
        'python': platform.python_version(),
        'seed': SEED,
        'checker_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'auditor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'block_identity_cases': CASES,
        'successful_block_identity_cases': successful,
        'scalar_truth_cases': results,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checker', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = audit(args.checker.resolve())
    text = json.dumps(result, indent=2) + '\n'
    if args.output:
        args.output.write_text(text)
    print(text, end='')


if __name__ == '__main__':
    main()
