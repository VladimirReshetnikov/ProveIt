"""Reproduce focused and differential checks for the block-opening reduction."""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys

import oracle

ROOT = Path(__file__).resolve().parent
FIXTURE = ROOT / 'positive_certificates.json'


def load_core(path):
    tree = ast.parse(path.read_text())
    tree.body = [node for node in tree.body
                 if isinstance(node, (ast.Import, ast.ImportFrom, ast.FunctionDef,
                                      ast.Assign))]
    namespace = {}
    exec(compile(tree, str(path), 'exec'), namespace)
    return namespace


def run_core(namespace, packet):
    namespace['k'] = 0
    stack = deepcopy(packet)
    try:
        namespace['take'] = stack.pop
        verdict = bool(namespace['check'](stack.pop(), []))
    except Exception:
        verdict = False
    return {'accepted': verdict, 'floor': namespace['k'],
            'remaining': len(stack) if type(stack) is list else None}


def observations(result):
    return {key: result[key] for key in ('accepted', 'floor', 'remaining')}


def main():
    generator = random.Random(20261108)
    candidate = load_core(ROOT.parent / 'checker.py')
    direct = load_core(ROOT / 'checker_explicit.py')
    fixtures = json.loads(FIXTURE.read_text())['records']
    focused = json.loads((ROOT / 'focused_cases.json').read_text())
    counters = Counter()
    for record in fixtures:
        packet = record['packet']
        expected = run_core(candidate, packet)
        actual = oracle.run(packet)
        assert expected['accepted'], record['name']
        assert expected == observations(actual), (record['name'], expected, actual)
        assert expected == run_core(direct, packet)
        counters.update(actual['events'])
    for record in focused:
        expected = run_core(candidate, record['packet'])
        actual = oracle.run(record['packet'])
        assert expected['accepted'] == record['expected'], (record, expected)
        assert expected == observations(actual), (record, expected, actual)
        assert expected == run_core(direct, record['packet'])
        counters.update(actual['events'])

    # The important algebraic invariant is exercised independently of proof
    # search: the binary outer block must introduce no scope into its entries.
    leaves = [-3, -2, -1, 0, 1, 2, 3, 4, True, False, None, '', 'x', {},
              0.5, -1.5]

    def tree(depth):
        if depth == 0 or generator.randrange(3) == 0:
            return deepcopy(generator.choice(leaves))
        return [tree(depth - 1) for _ in range(generator.randrange(5))]

    def outcome(call):
        try:
            return True, call()
        except Exception:
            return False, None

    block_checks = 0
    for _ in range(1000):
        a, b, image = tree(2), tree(2), tree(1)
        candidate['k'] = -generator.randrange(5)
        grouped = outcome(lambda: candidate['inst']([a, b], image, -1))
        separate = outcome(lambda: [candidate['inst'](a, image),
                                    candidate['inst'](b, image)])
        assert grouped == separate, (a, b, image, grouped, separate)
        block_checks += 1

    packets = [[tree(2) for _ in range(generator.randrange(8))]
               for _ in range(3000)]
    for record in fixtures:
        for _ in range(6):
            packet = deepcopy(record['packet'])
            packet[generator.randrange(len(packet))] = tree(3)
            packets.append(packet)
    mutation_accepts = 0
    for number, packet in enumerate(packets):
        expected = run_core(candidate, packet)
        actual = oracle.run(packet)
        assert expected == observations(actual), (number, expected, actual, packet)
        assert expected == run_core(direct, packet), number
        mutation_accepts += expected['accepted']
        counters.update(actual['events'])

    required = {'hypothesis', 'closure_elimination', 'transport',
                'paired_elimination', 'computation_successor',
                'computation_zero', 'compound_introduction',
                'atomic_or_empty_introduction', 'failed_major_fallthrough'}
    assert not required - counters.keys(), required - counters.keys()
    # Smoke the complete public CLI, not only extracted definitions.
    cli_count = 0
    for record in focused:
        completed = subprocess.run([sys.executable, str(ROOT.parent / 'checker.py')],
                                   input=json.dumps(record['packet']), text=True,
                                   capture_output=True)
        assert completed.stdout.strip() == ('ACCEPT' if record['expected'] else 'REJECT')
        assert (completed.returncode == 0) == record['expected']
        cli_count += 1
    receipt = {
        'status': 'PASS', 'seed': 20261108,
        'canonical_fixture_count': len(fixtures),
        'focused_case_count': len(focused),
        'public_cli_checks': cli_count,
        'block_identity_checks': block_checks,
        'generated_or_mutated_packets': len(packets),
        'generated_or_mutated_acceptances': mutation_accepts,
        'observations_compared': ['acceptance', 'parameter_floor', 'remaining_stack'],
        'rule_events': dict(sorted(counters.items())),
        'sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                   for name in ('../checker.py', 'checker_explicit.py', 'oracle.py',
                                'run.py', 'positive_certificates.json',
                                'focused_cases.json')},
        'limitation': 'Finite tests support implementation correctness; they are not a proof of soundness or bi-interpretability.'
    }
    (ROOT.parent / 'results/validation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
