"""Readable rule-by-rule reference for the two-formula-block certificate format.

This is validation code, not part of the measured trusted checker.  It does
not traverse hypothesis blocks.  Each premise is opened independently, so a
wrong block depth in the compact checker can be detected by comparison.
"""
from collections import Counter
from copy import deepcopy


class Rejected(Exception):
    pass


class Reference:
    def __init__(self, packet):
        if type(packet) is not list:
            raise Rejected('packet is not an array')
        self.stack = deepcopy(packet)
        self.floor = 0
        self.events = Counter()

    def pop(self):
        if not self.stack:
            raise Rejected('missing proof instruction')
        return self.stack.pop()

    def open(self, node, image=None, depth=0):
        if type(node) is list:
            if len(node) > 3:
                raise Rejected('constructor has too many children')
            increments = {0: 0, 1: 2, 2: 1, 3: 4}
            inner_depth = depth + increments[len(node)]
            return [self.open(child, image, inner_depth) for child in node]
        # JSON numerical aliases include booleans and finite floats.  Testing
        # membership before sort erasure reproduces the retained-label policy.
        if not isinstance(node, (int, float)):
            raise Rejected('non-numerical scalar')
        if self.floor <= node < depth:
            return node
        if depth % 2 == 0:
            return 0
        return self.open(image, None, 1)

    def prove(self, goal, assumptions):
        normalized = self.open(goal)
        if normalized in assumptions:
            self.events['hypothesis'] += 1
            return True
        instruction = self.pop()
        # A failed major proof consumes instructions and names.  It falls
        # through to introduction; exceptions instead reject the whole run.
        if type(instruction) is list and len(instruction) == 2:
            major, auxiliary = instruction
            if self.prove(major, assumptions):
                if type(major) is not list:
                    raise Rejected('scalar major cannot be eliminated')
                if len(major) == 0:
                    raise Rejected('empty major cannot be eliminated')
                if len(major) == 1:
                    self.events['closure_elimination'] += 1
                    body = major[0]
                    target = self.open(body, auxiliary)
                    if target != goal:
                        return False
                    return self.prove(self.open(body, 0), assumptions)
                if len(major) == 2:
                    self.events['transport'] += 1
                    left, right = major
                    target = self.open(auxiliary, right)
                    if target != goal:
                        return False
                    return self.prove(self.open(auxiliary, left), assumptions)
                self.events['paired_elimination'] += 1
                local = [0, [major[2]]]
                self.floor -= 1
                parameter = self.floor
                conclusion = self.open(goal, [parameter])
                # Deliberately open the two formulas separately.
                additions = [self.open(formula, parameter) for formula in local]
                return self.prove(conclusion, assumptions + additions)
            self.events['failed_major_fallthrough'] += 1
        elif type(instruction) is list and not instruction:
            if type(goal) is not list or len(goal) != 2:
                raise Rejected('computation goal is not an equation')
            iterator, right = goal
            if type(iterator) is not list or len(iterator) != 3:
                raise Rejected('computation left side is not an iterator')
            counter, seed, update = iterator
            if counter:
                if type(counter) is not list or len(counter) != 1:
                    raise Rejected('counter is not a successor')
                predecessor = counter[0]
                expected = self.open(update, [predecessor, seed, update], 1)
                self.events['computation_successor'] += 1
            else:
                expected = seed
                self.events['computation_zero'] += 1
            return right == expected
        if type(goal) is not list or len(goal) != 3:
            raise Rejected('introduction goal is not a paired formula')
        body = self.open(goal[2], instruction, 2)
        if type(body) is not list:
            raise Rejected('introduced matrix is scalar')
        if len(body) % 2:
            local = [1, self.open(body, 0)]
            self.events['compound_introduction'] += 1
        else:
            local = [body, self.open(body, 0)]
            self.events['atomic_or_empty_introduction'] += 1
        self.floor -= 1
        parameter = self.floor
        conclusion = self.open(body, [parameter])
        additions = [self.open(formula, parameter) for formula in local]
        return self.prove(conclusion, assumptions + additions)


def run(packet):
    reference = None
    try:
        reference = Reference(packet)
        accepted = bool(reference.prove(reference.pop(), []))
    except Exception:
        accepted = False
    return {
        'accepted': accepted,
        'floor': reference.floor if reference is not None else 0,
        'remaining': len(reference.stack) if reference is not None else None,
        'events': dict(reference.events) if reference is not None else {},
    }
