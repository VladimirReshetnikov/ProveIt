# Independent review of the fixed binary context-block checker

## Scope and conclusion

Reviewed source: `checker.py`, SHA-256
`697cd8a3765496ae7304bb8fc599619f0ffc9cf02683ad5471a5ee0f16512e36`.
The review covers the change from variable-length local-assumption lists to
fixed binary blocks and the public JSON cases affected by this change.
It also checks the claimed implementation-size comparison against the ten
current top-level checker programs at repository commit
`ce3371c9025b5c0ba12543acc2e6475d13ff7a3c`.

**The reviewer found no defect in this change.** The reasoning below is a
mathematical/code review supported by finite tests. It is not a
proof-assistant certification or an exhaustive search of finite inputs.
The inherited scalar arithmetic and full first-order equivalence arguments
were reviewed separately; this change preserves that native calculus.

## Exact block identity

The opener assigns the following common child increments to arrays of
arity zero through three:

```python
b'\0\2\1\4'[len(a)]
```

In particular, a binary array adds one to its entry depth. Consequently,
for every fixed allocation floor `k`, images `t`, and two-item block
`h = [u, v]`, the successful result of

```python
inst(h, t, -1)
```

is exactly

```python
[inst(u, t, 0), inst(v, t, 0)]
```

The two traversals have the same success/failure status in the idealized
semantics. An enclosing `try/except` may change which exception is finally
raised, but cannot turn a failed child into a successful list: its fallback
would compare the whole list to a numerical scope endpoint, which fails.
The new entry depth `-1` is an administrative convention for the context
container; the outer block is not being interpreted as an additional
number or formula of the object theory. Its children are ordinary formulas
at depth zero.

This identity replaces a separate list comprehension over assumptions.
It does not authorize applying the same entry depth to a block of a
variable length.

## Invariants of all successful continuations

Every continuation reaching the final recursive call has exactly two
new context entries.

1. A paired elimination uses `[0, m[2:]]`. A successfully validated major
   that reaches this continuation has arity three, so its tail is the unary
   closure `[m[2]]`. The first entry is an added truth formula.
2. A paired introduction uses
   `[len(a) % 2 or a, inst(a, 0)]`. For a binary equation matrix this is
   the induction equation and its retained base. For unary or ternary
   matrices it is the scalar truth label `1` and the retained base.
   Opening the whole block at formula-root child depth maps that label to
   `0`. For an empty matrix both entries are empty-array truth formulas.

The array-size bound matters. The opener rejects arrays of arity greater
than three through its checked lookup. Thus the parity test cannot
accidentally give an induction hypothesis to an arity-four compound
formula. This checker does not use the saturated-arity convention of the
arithmetic-scopes draft.

All context entries, after successful opening, are **arrays or the scalar
zero truth label**. The earlier compact-kernel invariant claiming that all
entries and all successfully proved majors are arrays must not be reused
unchanged: it is false for this candidate.

## Why the padding is a theorem

Both the scalar formula zero and the empty-array formula decode as
`0 = 0`. Reflexivity is already derivable in the native calculus. For any
term `s`, let `r = I(0, s; u.0)`. The initialization schema gives `r = s`.
Use that equation as both premises of equality transport with motive
`w = s`; the conclusion is `s = s`.

The added truth assumptions therefore add no strength. In an extracted
native proof, replace every use of a padding hypothesis by this reflexivity
derivation, or eliminate it by admissible cut. Empty matrices may receive
two truth assumptions even though they are not literal equations; both
assumptions are removable by the same argument. A genuinely non-atomic
matrix never receives itself as an induction hypothesis.

## Public scalar and malformed-input cases

Truth padding changes raw-packet acceptance. For example, put
`M = [0, 0, []]`. The packet

```json
[0, [[0, 0, []], 0], 0]
```

is accepted: introduction proves the true paired formula `M`, elimination
adds the padding truth assumption, and the final truth goal closes by
membership. Replacing the last goal by `true`, `0.5`, `NaN`, or positive
infinity is also accepted by the Python-JSON boundary with its stated
truth decoding. The last two parser extensions are not standard JSON
numbers; they are nevertheless relevant to Python's default parser.

These are additional spellings of a true formula, not arithmetic
constants with those values. A formula-position scalar is decoded as
truth. At numerical positions the independent scope/image validation
remains necessary and nonfinite coordinates cannot survive a finite
scope interval.

A scalar major can now succeed through the truth hypothesis. It still
cannot complete a major-premise elimination: numeric scalars have no slice
`m[2:]`, so the attempted elimination raises and the public checker rejects.
Strings, dictionaries, and null do not pass this retained-label opener's
scalar comparison in the first place. Empty-array majors reach the
small-arity branch but fail its unary unpacking. Successfully validated
array majors that complete elimination have the intended unary, binary,
or ternary shape. Thus the weakening from the old array-only invariant
does not open an unsound elimination path.

The test packet above rejects a string, object, null, the negative formula
label `-1`, and the false equation `[[], [0]]` when each is used as its
last goal. The negative-label rejection is an operational fact about this
packet, not a claim that a formula scalar denotes a free numerical
parameter. Raw-packet normalization can change hypothesis matching and
instruction consumption, so no unrestricted normalization equivalence is
claimed.

## Freshness, sound extraction, and completeness

The global allocation floor and its decrement are unchanged. The block
opener performs no allocation and introduces no scope beyond the intended
formula-root normalization of each child. The new negative eigenlabel
therefore has the same freshness justification as before. Local assumptions
are confined to the recursive continuation receiving the new block.
Failed major guards may consume instructions and allocate names, but
those failed subtraces contribute no local assumption to a successful
continuation; the inherited extraction argument must retain these effects
rather than pretending to roll them back.

For sound extraction, use the inherited opening, common-motive, scalar
computation, and freshness lemmas. At an introduction or paired elimination,
apply the exact binary block identity and remove its extra truth premise
by cut. Successful non-array truth goals are themselves theorems; the
non-array-major observation above covers the newly reachable elimination
attempts. This accounts for the changed successful traces.

For completeness, compile native formula trees in the canonical array
representation. The extra scalar-zero entry cannot spuriously match one
of those array goals. The existing convention of pruning a derivation when
automatic hypothesis membership succeeds, then allocating labels in the
actual checking order, remains appropriate. The change adds no proof
search, reflection rule, or nonlogical axiom.

## Reproducible finite checks

The supplied `block_tests.py` performs exactly the checks used in this
review. It is a validation utility, not an imported component of the
acceptance program. Run it with the checker path and an optional receipt
path, for example:

```bash
python3 validation/block_tests.py checker.py --output results/block_audit.json
```

The deterministic seed is **20261108**. The test compares the combined
block traversal with the two separate child traversals on **30,000**
mixed-JSON blocks and images, including out-of-range array arities, null,
strings, objects, Boolean aliases, negative and fractional labels, NaN,
and infinity. All success/failure outcomes agree; all **6,843** successful
returned blocks agree. The ten explicit scalar/truth/false-equation
boundary cases also match their expected verdicts. The receipt records
hashes of both the audited checker and the audit script.

These tests exercise the concrete new risks of the binary-container
entry depth and scalar truth assumptions. They are not evidence of an
exhaustive search or a universal proof of arithmetic consistency.

## Independent size comparison

The complete programs were measured using the inherited source-measure
utility on CPython **3.12.14**. The same-driver, same-name, and
definitions-only controls use the arithmetic-scopes draft's transformations.
Each baseline entry is one of the ten current top-level checkers; historical
nested files are excluded.

| Boundary | Current minimum tokens | Candidate tokens | Current minimum AST | Candidate AST | Current minimum bytes | Candidate bytes |
|---|---:|---:|---:|---:|---:|---:|
| Delivered | 328 | 324 | 356 | 350 | 957 | 954 |
| Same stdin driver | 328 | 324 | 356 | 350 | 953 | 950 |
| Same driver and names | 328 | 324 | 356 | 350 | 953 | 950 |
| Definitions only | 283 | 279 | 308 | 302 | 809 | 806 |

The candidate also has 322 source tokens and 948 raw bytes, compared with
current minima 326 and 967. Normalized metrics carry more significance
than raw bytes because comments and docstrings differ. The candidate is
strictly smaller in every displayed coordinate under these fixed
implementation boundaries, including the controls. This is an empirical
comparison against the supplied corpus, not a proof of absolute minimality
and not a reduction of the inherited two-schema, five-pattern native basis.
