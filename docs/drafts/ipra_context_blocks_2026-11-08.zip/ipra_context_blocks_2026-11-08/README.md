# Binary context blocks for a smaller iPRA proof checker

Prepared for Vladimir Reshetnikov on 8 November 2026.

## Result

The complete standalone checker is smaller than the coordinatewise minimum
of all ten current root checkers in the five ProveIt draft archives at
commit `ce3371c9025b5c0ba12543acc2e6475d13ff7a3c`.

| Whole-program metric | Current minimum | New checker |
|---|---:|---:|
| Normalized significant tokens | 328 | 324 |
| AST nodes | 356 | 350 |
| Normalized UTF-8 bytes | 957 | 954 |

The reduction survives identical driver, identical driver and function names,
and definitions-only comparisons. These are finite-corpus minima, not
theoretical lower bounds on every possible proof checker.

Every local assumption block is represented by exactly two formulas, padding
with derived truth when needed. The existing substitution routine opens the
whole block at depth -1, eliminating a separate context traversal. Both the
induction equation and retained base remain present at atomic introduction.
The native two-schema, five-pattern theory is unchanged. This is a small
representation advance, not a new arithmetic axiom basis or an established
absolute simplest theory.

The paper gives complete written proofs of full intuitionistic logical
reconstruction, internal arithmetic, sound extraction, canonical completeness,
and whole-domain bi-interpretations with iPRA. Its ordinary first-order
realization includes the genuine-falsity bridge. Both interpretation composites
are internally isomorphic to the identity. These proofs are not formalized in
Lean or Rocq.

A separate arithmetic simplification replaces the predecessor update by
`C(L(m, S(u)), S(u), u)`, reducing its fully expanded scalar term from 75
nodes to 74. Its proof uses the same two equation inductions as the inherited
shift argument.

## Contents

- `report.pdf`: complete mathematical report.
- `report.tex`, `sections/`, `appendices/`: all LaTeX sources.
- `checker.py`: the entire trusted acceptance program, including JSON input
  and verdict output. It imports no project module.
- `examples/`: individually runnable certificates, with expected outcomes in
  `index.json`.
- `comparison/manifest.json`: source snapshot, ZIP blob and SHA-256 hashes,
  and all ten current comparator identities.
- `comparison/baselines/`: unchanged current root checkers.
- `comparison/source_measure.py`: inherited measurement normalizer.
- `comparison/ablation_no_blocks.py`: isolates the block change.
- `validation/oracle.py`: readable reference interpreter that opens each
  local assumption separately.
- `validation/run.py`: positive-certificate, targeted, differential, and
  complete CLI checks.
- `validation/block_tests.py`: independent mixed-JSON block and scalar-boundary
  audit; `block_audit.md` explains its findings.
- `validation/predecessor_sanity.py`: scalar predecessor expansion and
  finite arithmetic checks.
- `results/`: measurement and validation/build receipts.
- `ATTRIBUTION.txt`, `LICENSE`: provenance and source license.
- `MANIFEST.json`: hashes of the packaged files, except itself.

## Run the checker

Python 3.10 or later is needed for structural pattern matching. Measurements
used CPython 3.12.14; use Python 3.12 to reproduce the normalization comparison.

```bash
python3 checker.py < examples/zero_computation.json
python3 checker.py < examples/reject_false.json
```

The first command prints `ACCEPT` and exits 0; the second prints `REJECT`
and exits 1. A packet is a JSON stack with its closed goal last. Preceding
instructions are consumed from the end. Unconsumed prefix cells are inert.
The paper specifies the syntax, aliases, instruction cases, and freshness.

The actual process has finite recursion and memory limits. The mathematical
soundness and completeness statements use unbounded-resource semantics;
sufficiently large valid proofs can exceed a particular process's limits.
Certificate verification does not decide arbitrary theoremhood.

## Reproduce

Only Python's standard library is required for measurements and tests.
The PDF additionally needs pdfLaTeX with standard AMS, Latin Modern,
microtype, geometry, listings, booktabs, and hyperref packages. No network
access is required.

```bash
python3 reproduce.py
```

Or run components separately:

```bash
python3 measure.py
python3 validation/run.py
python3 validation/block_tests.py checker.py --output results/block_audit.json
python3 validation/predecessor_sanity.py results
python3 build.py
python3 package.py
```

All delivered groups passed: 147 inherited canonical certificates, 32 named
cases through the complete CLI, 3,882 generated or mutated packet comparisons,
1,000 initial block checks, and an independent 30,000-case block audit plus ten
boundary cases. The reference compares verdict, fresh-parameter floor, and
remaining stack. These finite tests support the implementation; they are not
proofs of universal metatheorems.

## Semantic qualification

Added truth hypotheses can close some noncanonical scalar truth goals.
Raw-packet acceptance is therefore not claimed to be identical to a previous
checker. The native consequence relation, sound extraction, and canonical
completeness are preserved. The old array-only context invariant is replaced
by an array-or-scalar-zero invariant in the paper.

No absolute minimality, major foundational breakthrough, or proof-assistant
verification is claimed.
