"""Write a deterministic ZIP with all deliverables and a SHA-256 manifest."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.fls', '.fdb_latexmk'}


def files():
    return [p for p in sorted(ROOT.rglob('*')) if p.is_file()
            and '__pycache__' not in p.parts
            and p.suffix not in EXCLUDED_SUFFIXES
            and p.name != 'MANIFEST.json']


def main():
    if not (ROOT / 'report.pdf').is_file():
        raise SystemExit('Build report.pdf first.')
    manifest = {
        'package': ROOT.name,
        'date': '2026-11-08',
        'source_commit': 'ce3371c9025b5c0ba12543acc2e6475d13ff7a3c',
        'files': {str(p.relative_to(ROOT)): {'size': p.stat().st_size,
                  'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files()},
    }
    manifest_file = ROOT / 'MANIFEST.json'
    manifest_file.write_text(json.dumps(manifest, indent=2) + '\n')
    destination = ROOT.parent / (ROOT.name + '.zip')
    with ZipFile(destination, 'w', compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files() + [manifest_file]):
            name = ROOT.name + '/' + str(path.relative_to(ROOT))
            info = ZipInfo(name, date_time=(2026, 11, 8, 12, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    with ZipFile(destination) as archive:
        if archive.testzip() is not None:
            raise SystemExit('ZIP integrity failure')
    print(destination)
    print('SHA-256:', hashlib.sha256(destination.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
