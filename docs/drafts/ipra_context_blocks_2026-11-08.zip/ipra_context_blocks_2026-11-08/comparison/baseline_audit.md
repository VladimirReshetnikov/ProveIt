# Independent audit of the current iPRA drafts

Snapshot: `ce3371c9025b5c0ba12543acc2e6475d13ff7a3c`.
Python: CPython 3.12.14.

## Complete current checker corpus

All ten top-level `checker*.py` files in the five current ZIP archives were measured. Nested historical comparison copies were excluded.

| Archive | Root checker | Source tokens | Normalized tokens | AST nodes | Normalized bytes | Raw bytes |
|---|---|---:|---:|---:|---:|---:|
| ipra_arithmetic_scopes_2026-11-07 | checker_direct.py | 339 | 341 | 362 | 975 | 978 |
| ipra_arithmetic_scopes_2026-11-07 | checker_scalar.py | 332 | 334 | 356 | 964 | 967 |
| ipra_arity_scopes_2026-11-07 | checker.py | 333 | 333 | 362 | 965 | 1248 |
| ipra_arity_scopes_2026-11-07 | checker_compact.py | 332 | 332 | 361 | 962 | 1244 |
| ipra_compact_kernel_2026-11-07 | checker.py | 328 | 330 | 360 | 967 | 1331 |
| ipra_compact_kernel_2026-11-07 | checker_retained.py | 326 | 328 | 360 | 965 | 1475 |
| ipra_permanent_zero_2026-11-07 | checker.py | 334 | 336 | 361 | 968 | 1330 |
| ipra_permanent_zero_2026-11-07 | checker_direct.py | 341 | 343 | 367 | 980 | 1352 |
| ipra_validated_erasure_2026-11-07 | checker.py | 336 | 338 | 361 | 967 | 1250 |
| ipra_validated_erasure_2026-11-07 | checker_compact.py | 338 | 340 | 360 | 957 | 1185 |

Coordinatewise whole-program minima: **326 source tokens, 328 normalized tokens, 356 AST nodes, 957 normalized bytes, 967 raw bytes**. These are an empirical envelope of delivered checkers, not proved lower bounds on all implementations. Raw bytes are especially sensitive to comments/docstrings.

Using the arithmetic-scopes fairness transforms on the current corpus gives the following minima:

| Boundary | Normalized tokens | AST nodes | Normalized bytes |
|---|---:|---:|---:|
| Delivered | 328 | 356 | 957 |
| Identical stdin driver | 328 | 356 | 953 |
| Identical driver and function names | 328 | 356 | 953 |
| Function definitions and initialization only | 283 | 308 | 809 |

The older source-measure field named `core` is not the definitions-only boundary: it can retain top-level driver code.

## Mathematical audit

All five drafts inherit the same mathematical foundation: one numerical sort; 0, successor, and initialized scalar iteration (direct recursion in some companions); formulas consisting of equations, closures Q, and paired existential closures D; two computation schemas and five patterns Hyp, paired introduction, closure elimination, paired elimination, and equality transport. The current reports explicitly claim representation/checker improvements rather than a new arithmetic axiom basis.

The arithmetic-scopes paper gives a substantive full-first-order equivalence argument: reconstruction of intuitionistic connectives via gates and selectors; atomic induction reflected to quantifier-free induction; an ordinary staged first-order recursor theory with numerical coverage and an explicit genuine-falsity bridge; and whole-domain identity isomorphisms for both interpretation composites using internal recursion uniqueness. This is stronger than numerical conservativity or a statement about primitive-recursive functions in the standard model.

I found no concrete error in those arguments during this audit. I also checked the scalar dependence chain comparator → predecessor → equality reflection → pairing → simulation of direct recursion, with attention to holding induction parameters fixed. No proof-assistant formalization of these results is claimed or supplied. This is a mathematical review, not a formal certification.

## Representation hazards

The arithmetic-scopes representation uses formula depth 2q and numerical depth 2q+3, with saturated child increment `len(a[:3])+1`. Arrays with arity at least three use their first three children semantically and validate remaining padding. This requires:

- Paired elimination to retain exactly `[[m[2]]]`, not `[m[2:]]`.
- The literal-equation test to be exact `len(a)==2`, not parity.
- Independent root validation of any substitution image that is actually used.
- Preservation of monotone fresh-name allocation and packet consumption through failed major guards.
- Separation of canonical completeness from arbitrary raw-packet equivalence.

The public malformed-array regression `[0, [[[], [], [], [0]], 0], [[], [0]]]` derives a false equation in a deliberately broken saturated checker retaining the old elimination-tail logic; the delivered arithmetic-scopes checkers reject it.

## Re-executed evidence

The existing arithmetic-scopes independent certificate validator was rerun successfully in this session. It reported zero failures across 5,236 scalar comparisons and 4,040 direct comparisons; these include 147 scalar and 55 direct inherited positives, plus 524 public CLI invocations. Both profiles checked 400 numerically evaluated true successor equalities. These are finite implementation checks, not proofs of universal soundness or bi-interpretability.

## Useful directions

The inherited reports identify two mathematically meaningful remaining targets: a direct recursor whose state/counter substitution uses one trusted opening, and removing an inference pattern rather than further compressing its syntax. Any candidate should be compared against the current minima above, including identical-driver and definitions-only controls.
