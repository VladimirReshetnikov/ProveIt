"""Reproduce whole-checker size comparisons against the pinned five drafts."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import tempfile

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    'source_measure', ROOT / 'comparison/source_measure.py')
source_measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(source_measure)
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
BOUNDARIES = ('delivered', 'common_stdin', 'common_stdin_and_names',
              'definitions_only')
DRIVER = """
try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
except:
    print('REJECT')
    sys.exit(1)
print('ACCEPT')
"""


def text_metrics(source):
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / 'source.py'
        path.write_text(source)
        return {k: v for k, v in source_measure.metrics(path).items()
                if k != 'core'}


def measure_file(path):
    source = path.read_text()
    tree = ast.parse(source)
    body = [node for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.Assign))]
    definitions = ast.unparse(ast.Module(body=body, type_ignores=[])) + '\n'
    entry = 'test' if any(isinstance(node, ast.FunctionDef) and
                         node.name == 'test' for node in body) else 'check'
    common = 'import json, sys\n' + definitions + DRIVER.replace(
        'check(', entry + '(')

    class CommonNames(ast.NodeTransformer):
        names = {'test': 'check', 'sub': 'inst'}

        def visit_Name(self, node):
            node.id = self.names.get(node.id, node.id)
            return node

        def visit_FunctionDef(self, node):
            node.name = self.names.get(node.name, node.name)
            return self.generic_visit(node)

    renamed = ast.unparse(CommonNames().visit(ast.parse(common))) + '\n'
    return {'delivered': text_metrics(source),
            'common_stdin': text_metrics(common),
            'common_stdin_and_names': text_metrics(renamed),
            'definitions_only': text_metrics(definitions)}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    programs = []
    for item in manifest['programs']:
        path = ROOT / item['local_file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
            raise ValueError('Comparator changed: ' + item['local_file'])
        programs.append({**item, **measure_file(path)})
    floors = {boundary: {field: min(row[boundary][field] for row in programs)
                         for field in FIELDS} for boundary in BOUNDARIES}
    candidate = measure_file(ROOT / 'checker.py')
    ablation = measure_file(ROOT / 'comparison/ablation_no_blocks.py')
    strict = {boundary: {field: candidate[boundary][field] < floors[boundary][field]
                        for field in FIELDS} for boundary in BOUNDARIES}
    if not all(value for row in strict.values() for value in row.values()):
        raise ValueError('Candidate does not strictly beat every controlled floor')
    result = {'python': platform.python_version(),
              'repository': manifest['repository'], 'commit': manifest['commit'],
              'archive_count': manifest['archive_count'],
              'program_count': manifest['program_count'],
              'definition': 'Entire standalone acceptance program, stripped of genuine docstrings, parsed and normalized by ast.unparse; count significant lexical tokens, all AST nodes, and UTF-8 bytes. Parser and interpreter are the common runtime boundary.',
              'floor': floors, 'candidate': candidate, 'ablation': ablation,
              'strict_improvement': strict, 'programs': programs}
    (ROOT / 'results/measurements.json').write_text(json.dumps(result, indent=2) + '\n')

    def row(label, values):
        return label + ' & ' + ' & '.join(str(values[k]) for k in FIELDS) + r'\\'

    lines = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
             r'Complete source or controlled boundary & Tokens & AST & Bytes\\',
             r'\midrule', row('Current delivered minima', floors['delivered']),
             row('New block checker', candidate['delivered']), r'\midrule',
             row('Current common-driver minima', floors['common_stdin']),
             row('New checker, common driver', candidate['common_stdin']),
             r'\midrule', row('Current definitions-only minima', floors['definitions_only']),
             row('New definitions only', candidate['definitions_only']),
             r'\bottomrule', r'\end{tabular}']
    (ROOT / 'results/main_table.tex').write_text('\n'.join(lines) + '\n')
    detailed = [r'\begin{longtable}{@{}llrrr@{}}', r'\toprule',
                r'Draft & Root file & Tokens & AST & Bytes\\',
                r'\midrule\endhead']
    for item in programs:
        draft = item['archive'].removeprefix('ipra_').removesuffix('_2026-11-07.zip')
        draft = draft.replace('_', r'\_')
        filename = item['root_file'].replace('_', r'\_')
        detailed.append(row(draft + ' & ' + filename, item['delivered']))
    detailed += [r'\bottomrule', r'\end{longtable}']
    (ROOT / 'results/baseline_table.tex').write_text('\n'.join(detailed) + '\n')
    values = {'BlockTokens': candidate['delivered']['normalized_tokens'],
              'BlockAST': candidate['delivered']['ast_nodes'],
              'BlockBytes': candidate['delivered']['normalized_bytes']}
    (ROOT / 'results/numbers.tex').write_text(''.join(
        '\\newcommand{\\' + name + '}{' + str(value) + '}\n'
        for name, value in values.items()))
    print(json.dumps({k: result[k] for k in ('python', 'floor', 'strict_improvement')}, indent=2))
    print(json.dumps({boundary: {k: candidate[boundary][k] for k in FIELDS}
                      for boundary in BOUNDARIES}, indent=2))


if __name__ == '__main__':
    main()
