"""Compile and check the LaTeX research report without network access."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    for _ in range(3):
        result = subprocess.run(
            ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
            cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            print(result.stdout[-12000:])
            print(result.stderr)
            raise SystemExit(result.returncode)
    log = (ROOT / 'report.log').read_text(errors='replace')
    if any(text in log for text in ('undefined references', 'Citation `', 'Reference `')):
        raise SystemExit('Unresolved references in report.log')
    receipt = {
        'status': 'PASS',
        'pdf_sha256': hashlib.sha256((ROOT / 'report.pdf').read_bytes()).hexdigest(),
        'overfull_box_warnings': [line for line in log.splitlines() if 'Overfull' in line],
        'tex_sources': {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                        for path in sorted(ROOT.rglob('*.tex'))},
    }
    (ROOT / 'results/build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('Built report.pdf; references resolved.')
    if receipt['overfull_box_warnings']:
        print('\n'.join(receipt['overfull_box_warnings']))


if __name__ == '__main__':
    main()
