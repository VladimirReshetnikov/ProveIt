"""Build a ZIP with complete sources, reproducible evidence, and checksums."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_SUFFIXES = {".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk", ".pyc"}


def selected():
    return [p for p in sorted(ROOT.rglob("*"))
            if p.is_file() and "__pycache__" not in p.parts
            and p.suffix not in SKIP_SUFFIXES and p.name != "SHA256SUMS"]


def main():
    files = selected()
    checksums = "".join(
        hashlib.sha256(p.read_bytes()).hexdigest() + "  " +
        p.relative_to(ROOT).as_posix() + "\n" for p in files)
    sums = ROOT / "SHA256SUMS"
    sums.write_text(checksums)
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as stream:
        for p in [*files, sums]:
            name = ROOT.name + "/" + p.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            stream.writestr(info, p.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(archive) as stream:
        if stream.testzip() is not None:
            raise ValueError("ZIP CRC verification failed")
        for line in checksums.splitlines():
            expected, name = line.split("  ", 1)
            actual = hashlib.sha256(stream.read(ROOT.name + "/" + name)).hexdigest()
            if actual != expected:
                raise ValueError("ZIP checksum mismatch: " + name)
    print({"archive": str(archive), "files": len(files) + 1,
           "bytes": archive.stat().st_size,
           "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()})


if __name__ == "__main__":
    main()
