"""Compile the complete LaTeX paper, then extract a text QA copy."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which("pdflatex"):
        raise SystemExit("pdflatex is required; install a standard TeX distribution.")
    for _ in range(2):
        result = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        if result.returncode:
            print(result.stdout)
            raise SystemExit(result.returncode)
    log = (ROOT / "report.log").read_text(errors="replace")
    issues = [line for line in log.splitlines()
              if ("Overfull" in line or "undefined" in line.lower()
                  or "LaTeX Error:" in line)]
    if issues:
        print("\n".join(issues))
        raise SystemExit("PDF compiled but needs layout/reference review.")
    if shutil.which("pdftotext"):
        subprocess.run(["pdftotext", "-layout", "report.pdf", "results/report_text.txt"],
                       cwd=ROOT, check=True)
    print("Compiled report.pdf without overfull boxes or unresolved references.")


if __name__ == "__main__":
    main()
