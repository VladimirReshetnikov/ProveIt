"""Goal-directed complete iPRA checker, checking introduction certificates."""
import json
import sys

def require(condition):
    if not condition:
        raise ValueError('invalid certificate')
SCOPES = ({'s': (0,), 'r': (0, 0, 2)}, {'=': (0, 0), 'pi': (1, 1), 'ex': (1,)})

def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int:
        require(not formula and a >= -1)
        i = a - d
        return a if i < 0 else subst(env[i], (d,), formula=False) if i < len(env) - 1 else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1) for b, width in zip(args, SCOPES[formula][tag], strict=True))]

def check(a, p, g):
    subst(a)
    match (a, p):
        case [['pi', h, b], ['lam' | 'nat' as rule, q]]:
            if rule == 'nat':
                require(h == subst(b, [-1, 0]))
                h = b if b[0] == '=' else h
                b = subst(b, [['s', 0], 0])
        case [['ex', b], ['pack', t, q]]:
            h = ['=', 0, subst(t, formula=False)]
        case [_, ['use', [tag, *parts] as m, r, *args]]:
            check(m, r, g)
            if tag == 'ex':
                return check(subst(a), *args, [*map(subst, g), *parts])
            else:
                t, q = args
                b, c = (subst(t, [v, -1]) if tag == '=' else subst(v, [t, -1]) for v in parts)
                require(c == a)
                return check(b, q, g)
        case [['=', ['r', n, t, h], b], 'r']:
            if n != -1:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return require(b == t)
        case _:
            return require(a == g[p])
    check(b, q, [*map(subst, g), h])
if __name__ == '__main__':
    try:
        _, path = sys.argv
        with open(path, encoding='utf-8') as stream:
            a, p, *g = json.load(stream)
        for b in g:
            subst(b)
        check(a, p, g)
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
