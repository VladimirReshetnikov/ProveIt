"""Complete iPRA checker with retractable raw recursor equations."""

import json
import sys


def require(condition):
    if not condition:
        raise ValueError("invalid certificate")


SCOPES = ({"s": (0,), "r": (0, 0, 2)},
          {"=": (0, 0), "pi": (1, 1), "ex": (1,)})


def subst(a, env=(1,), d=0, formula=True):
    if type(a) is int:
        require(not formula and a >= -1)
        i = a - d
        return a if i < 0 else subst(env[i], (d,), formula=False) if i < len(env) - 1 else a + env[-1]
    tag, *args = a
    return [tag, *(subst(b, env, d + width, width == 1)
                   for b, width in zip(args, SCOPES[formula][tag], strict=True))]


def infer(p, g):
    match p:
        case [("lam" | "pack" | "nat") as tag, a, q]:
            if tag == "pack":
                a = ["=", 0, subst(a, formula=False)]
            base = subst(a, [-1, 0] if tag == "nat" else (0,))
            b = infer(q, [*map(subst, g), a if a[0] == "=" else base])
            if tag == "nat":
                require(b == subst(a, [["s", 0], 0]))
                b = a
            return ["ex", b] if tag == "pack" else ["pi", base, b]
        case ["r", -1, a, h] as r:
            b = a
        case ["r", ["s", n], a, h] as r:
            b = subst(h, [["r", n, a, h], n, -2], formula=False)
        case [p, *args]:
            tag, *parts = infer(p, g)
            if tag == "ex":
                return subst(infer(*args, [*map(subst, g), *parts]), [None, -1])
            a, q = args
            b, c = (subst(a, [t, -1]) if tag == "=" else subst(t, [a, -1]) for t in parts)
            require(infer(q, g) == b)
            return c
        case _:
            return g[p]
    return ["=", r, b]


def check(g, a, p):
    for b in g + [a]:
        subst(b)
    require(infer(p, g) == a)


if __name__ == "__main__":
    try:
        _, path = sys.argv
        with open(path, encoding="utf-8") as stream:
            check(*json.load(stream))
        print("ACCEPT")
    except Exception:
        print("REJECT")
        sys.exit(1)
