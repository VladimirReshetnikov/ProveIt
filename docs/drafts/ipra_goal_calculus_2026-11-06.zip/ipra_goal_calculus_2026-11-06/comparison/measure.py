"""Reproduce the complete-program comparison. No baseline is executed."""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE,
           tokenize.NL, tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT}


class StripDocs(ast.NodeTransformer):
    def strip(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return node

    visit_Module = strip
    visit_FunctionDef = strip
    visit_AsyncFunctionDef = strip
    visit_ClassDef = strip


def measure(path):
    raw = path.read_bytes()
    tree = StripDocs().visit(ast.parse(raw.decode("utf-8")))
    normalized = ast.unparse(tree) + "\n"
    significant = [t for t in tokenize.generate_tokens(
        io.StringIO(normalized).readline) if t.type not in IGNORED]
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "raw_bytes": len(raw),
        "normalized_tokens": len(significant),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode("utf-8")),
    }


def main():
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text())
    rows = []
    for item in manifest["primary"]:
        row = measure(ROOT / item["source"])
        if row["sha256"] != item["source_sha256"]:
            raise ValueError("Baseline source hash mismatch: " + item["source"])
        rows.append({"label": item["label"], "source": item["source"], **row})
    candidate = measure(ROOT / "checker.py")
    keys = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    envelope = {key: min(row[key] for row in rows) for key in keys}
    below = {key: candidate[key] < envelope[key] for key in keys}
    result = {
        "python": platform.python_version(),
        "repository": manifest["repository"], "commit": manifest["commit"],
        "scope": manifest["snapshot_scope"],
        "boundary": "Entire standalone source including imports, validation, JSON CLI, and failure handling",
        "definitions": {
            "normalized_tokens": "Significant tokenize tokens of ast.unparse after stripping docstrings; comments and structural whitespace excluded",
            "ast_nodes": "All ast.walk nodes after stripping module/function/class docstrings",
            "normalized_bytes": "UTF-8 bytes of ast.unparse after stripping docstrings, plus one final newline",
            "raw_bytes": "Original file bytes including documentation",
        },
        "primary": rows, "envelope": envelope, "candidate": candidate,
        "strictly_below": below,
        "reduction_percent": {
            key: round(100 * (envelope[key] - candidate[key]) / envelope[key], 6)
            for key in keys
        },
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    macros = {
        "NewTokens": candidate["normalized_tokens"],
        "NewAST": candidate["ast_nodes"], "NewBytes": candidate["normalized_bytes"],
        "MinTokens": envelope["normalized_tokens"],
        "MinAST": envelope["ast_nodes"], "MinBytes": envelope["normalized_bytes"],
    }
    (ROOT / "results/metrics_macros.tex").write_text(
        "".join("\\newcommand{\\" + name + "}{" + str(value) + "}\n"
                for name, value in macros.items()))
    names = {
        "compact_calculus": "Compact calculus",
        "factored_kernel": "Factored kernel",
        "integrated_kernel": "Integrated kernel",
        "parameter_axiom": "Parameter axiom",
        "reduction": "Goal-directed reduction",
        "repaired_computation": "Repaired computation",
    }
    lines = [
        r"\begin{tabular}{@{}lrrr@{}}",
        r"\toprule",
        r"Complete program & Tokens & AST nodes & Bytes\\",
        r"\midrule",
    ]
    for row in rows:
        lines.append(names[row["label"]] + " & " +
                     " & ".join(str(row[k]) for k in keys) + r"\\")
    lines.extend([
        r"\midrule",
        "Six-draft lower envelope & " +
        " & ".join(str(envelope[k]) for k in keys) + r"\\",
        r"\textbf{This construction} & " +
        " & ".join(r"\textbf{" + str(candidate[k]) + "}" for k in keys) + r"\\",
        r"\bottomrule", r"\end{tabular}",
    ])
    (ROOT / "results/metrics_table.tex").write_text("\n".join(lines) + "\n")
    if not all(below.values()):
        raise ValueError("The candidate does not beat every current minimum")
    print(json.dumps({"candidate": candidate, "envelope": envelope,
                      "strictly_below": below}, indent=2))


if __name__ == "__main__":
    main()
