A SMALLER GOAL-DIRECTED CALCULUS FOR iPRA
Prepared for Vladimir Reshetnikov, 6 November 2026 (Pacific time)

RESULT

The complete standalone proof checker is strictly smaller than the complete
primary checkers in all six current ProveIt draft archives at commit
edf7ea445673b29301012177998b0cc66bfabbf0.

                                  Six-draft minimum    This construction
Normalized Python tokens                   603                  587
Python AST nodes                           639                  605
Normalized UTF-8 source bytes              1928                 1851

All executable code is counted, including syntax validation, input parsing,
and rejection. Comments/docstrings are removed before normalization.
The three minima are taken separately. The metric is fixed to Python;
this is a strict finite comparison, not a global minimality theorem.

The mathematical basis is inherited from the strongest current drafts.
The improvement is a direct Boolean checking predicate, certificates whose
introduction form is determined by the goal, deletion of redundant
elimination tags, and a positive-index variable representation with zero
encoded as zero. The complete checker has no proof-library dependency.

MATHEMATICAL SCOPE

iPRA means full intuitionistic first-order arithmetic with equality,
genuine falsity, primitive-recursive description symbols and their defining
equations, successor axioms, and induction for all quantifier-free formulas.
This is the explicit convention in the current draft series.

The paper includes every primitive rule and proves reconstruction of full
intuitionistic logic, primitive recursion, and quantifier-free induction.
It gives faithful full-sequent translations to an ordinary first-order
realization, whole-domain bi-interpretability with iPRA, the internal
isomorphisms of both composites, and equiconsistency.

The arithmetic language uses equality, a guarded universal binder, existence,
and initialized recursion. Its numerical rule gives induction for literal
equations and zero/successor cases for compound formulas. This distinction
is essential: a literally bare atomic-induction theory need not prove
numerical coverage. The paper supplies the product countermodel.

The universal metatheorems are paper proofs, independently reviewed.
The included certificate runs and binding checks are finite executable
evidence, not a Lean or Rocq formalization.

FILES

report.tex and sections/       Complete LaTeX source, including all proofs.
report.pdf                    Compiled paper.
checker.py                    Entire trusted standalone acceptance program.
FORMAT.txt                    Complete term/formula/certificate format.
examples/                     Certificates in the new format.
comparison/manifest.json      Pinned archives, Git identities, source hashes.
comparison/sources/           Six original complete checker programs.
comparison/measure.py          Offline reproducible size comparison.
validation/                   Independent binding oracle and finite audits.
evidence/                     Mathematical audit and PDF review record.
results/                      Recomputed measurements and verification results.
reproduce.py                  Run the comparison and verification.
build.py                      Compile the PDF with pdflatex.
SHA256SUMS                    Checksums of the packaged files.
LICENSE_SOURCE.txt            Preserved source license from ProveIt.

RUN

Python 3.10+ and its standard library are sufficient for checking and auditing.
The recorded normalization results use CPython 3.12.14.

    python3 reproduce.py
    python3 checker.py examples/reflexivity.json
    python3 -O checker.py examples/reflexivity.json
    python3 reproduce.py --pdf

The last command also requires a standard TeX installation with the packages
listed in report.tex. The first command is entirely offline.

PUBLIC ACCEPTANCE BOUNDARY

A finite JSON file contains [goal, proof, *hypotheses].
The CLI validates every hypothesis, then checks the goal and certificate.
It prints ACCEPT with exit code 0 or REJECT with nonzero exit code.
Python optimization does not disable any check; the kernel uses no assert.

The internal function check(a, p, g) assumes a well-formed context g.
It returns True on acceptance, False on a failed proof comparison, and
can raise on malformed syntax. Direct callers must validate every context
entry with subst before using it. The CLI already does this.

ZERO AND VARIABLES

Integer 0 denotes numerical zero. Positive integers denote variables:
1 is the nearest binder or first free slot, not the numeral one.
The numeral one is ["s", 0]. Formula binders bind one slot. A recursion
body binds slot 1 for the previous value and slot 2 for the previous counter.
Proof assumption indices are ordinary zero-based list indices, a separate
namespace from term variables.

PROVENANCE

The mathematical sections were adapted from the compact-calculus draft
and reviewed independently. The implementation starts from the goal-directed
reduction draft. Its independent named-variable audit and source fixtures
are preserved with provenance under validation/.
No repository changes or external publication were performed.
