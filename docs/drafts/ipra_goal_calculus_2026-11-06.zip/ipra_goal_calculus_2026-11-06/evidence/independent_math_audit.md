# Independent audit of the mathematical reduction

This is an independent review of the argument in the current compact-calculus draft and of the goal-directed checker in `work/checker_candidate.py`. It does not constitute a Lean/Rocq verification.

## Verdict and exact target

The mathematical argument is coherent for the following explicit theory: full intuitionistic first-order logic with equality and genuine falsity; symbols and defining equations for every fixed primitive-recursive description; successor injectivity and separation; induction for **all quantifier-free formulas**, with parameters. Call this theory `iPRA_qf`.

The argument establishes a whole-domain definitional correspondence between `iPRA_qf` and the ordinary realization of the native calculus. The proposed checker refactoring does not change that calculus. There is no justification for an unqualified claim that the same theorem covers every theory called “iPRA” in the literature.

This convention issue is real. Salehi, *Decidable Formulas of Intuitionistic Primitive Recursive Arithmetic* (2002), pp. 55–56, describes iPRA using defining equations and atomic induction. The product model below shows that a literally bare atomic-induction axiom list does not imply the numerical coverage used here. One should either specify the quantifier-free-induction target, as the drafts already do, or separately establish that another cited convention includes sufficient background arithmetic. Merely calling a cited axiom list abbreviated is not that establishment.

Primary source inspected: https://rml.tcs.uj.edu.pl/rml-36/36-SALEHI.pdf (web reference `turn4view0`, parent must reopen before citing it in the final answer).

## 1. Structural rules and the equality bootstrap

Weakening, exchange, contraction, cut, and numerical substitution are admissible by induction on derivations. At every fresh-number rule, rename the eigenvariable away from terms and derivations being inserted. Numerical substitution preserves a formula's root constructor, so it preserves the induction-versus-cases choice of the numerical rule.

For any term `t`, the zero computation equation gives `r=t`, where `r=R(0,t;u,v.0)`. Equality transport with this same equation both as major and as minor, and template `F(z)=(z=t)`, yields `t=t`. Symmetry, transitivity, and arbitrary term-context congruence then follow from transport. This bootstrap does not presuppose reflexivity.

The witnessed existential-introduction rule is equivalent to ordinary existential introduction, once reflexivity, symmetry, substitution, and cut have been derived. For the forward direction substitute the supplied witness into the local derivation and discharge its reflexive equality; for the reverse direction transport a proof of `A(t)` along the symmetric form of the new assumption `y=t`.

## 2. Explosion does not require a primitive falsity rule in the native calculus

Write `C(n,a,b)=R(n,a;u,v.b)` and `Delta=(0=S0)`. Computation gives `C(0,a,b)=a` and `C(Sn,a,b)=b`. From `Delta`, congruence gives `C(0,a,b)=C(S0,a,b)`, and hence every equation `a=b`. An external induction on a native formula derives every formula: use the consequent for guarded universals, and use witness zero for existentials. Thus native explosion is justified.

The ordinary first-order realization must nevertheless include the bridge `0=S0 -> bottom`, because its genuine logical falsity is a new symbol absent from the native syntax. Native explosion alone does not imply this bridge in a different first-order theory. The drafts retain the bridge correctly.

Predecessor `p(n)=R(n,0;u,v.v)` proves successor injectivity by congruence. Applying `Z(n)=C(n,0,1)` to `0=Sx` proves separation into `Delta`.

## 3. Numerical cases with dependent retained assumptions

It is essential that the cases argument works when the tested term occurs in the retained context. From `Gamma,t=0 |- F` and `Gamma,t=Sy |- F`, choose a fresh slot `x` and apply numerical cases to

`P(x) = (t=x ->* F)`.

The base and successor branches follow by implication introduction. Instantiate the resulting universal at the original, fixed `t` and apply it to `t=t`. This yields `Gamma |- F` without changing occurrences of `t` in `Gamma`. The inherited proof has this necessary repair; applying bare cases directly to a context depending on the tested variable would not suffice.

## 4. The formula selector really preserves quantified formulas

The recursive selector `M_z(A,B)` is sound. It aligns outer guarded universals first, existentials second, and equations last; missing binders are inserted vacuously. The measure “total number of logical binders in the two input operands” decreases in every recursive child, even when padding is used. At least one actual outer binder is removed, while padding merely passes the other operand to a child.

The endpoint equivalences `M_0(A,B) <-> A` and `M_(Sy)(A,B) <-> B` follow by structural induction. For a guarded universal, the guard equivalence is used contravariantly and the consequent equivalence covariantly. Vacuous universal and existential padding is legitimate because zero inhabits the domain. No quantifier has been encoded as a Boolean truth value; the selector retains the quantifiers.

Consequently, universal selection encodes conjunction and existential selection encodes disjunction. Conjunction introduction uses numerical cases on the selector. Disjunction elimination opens the existential and then uses the contextual cases lemma above; this is precisely the place where a naive non-contextual case split would fail. Endpoints hold at every successor, including nonstandard successors, by the recursion equation, so the proof is not restricted to standard numerals.

## 5. Quantifier-free reflection uses only equation induction

The residual identity is the key arithmetic bootstrap:

`C(d(y,n), y, n+d(y,n)) = y`,

where `d` is truncated subtraction and addition recurses in its second argument. Fix `y` and induct on the displayed literal equation in `n`. In the successor step put `r=d(y,n)` and use contextual cases on `r`, retaining the induction equation.

* If `r=0`, the next residual is zero and the selector returns `y`.
* If `r=Sq`, the old selector gives `n+Sq=y`. The defining subtraction equations give the next residual `q`. The already established addition equations give `Sn+q=n+Sq=y`. The new selector becomes `C(q,y,y)=y`.

All inductions used for the needed elementary addition and subtraction identities also have literal-equation matrices. The identity `C(q,y,y)=y` uses cases, not stronger induction.

Now `Q(r,1)=0` is equivalent to `r=1`: split `r` into zero or successor, using retained assumptions correctly. With `epsilon(s,t)=Q(d(Ss,t),1)`, the forward direction `s=t -> epsilon=0` is immediate from `d(Ss,s)=1`; the reverse direction uses the residual identity to infer `t+1=Ss`, then successor injectivity. This establishes equality detection without smuggling quantified or general quantifier-free induction into the weak basis.

The characteristic terms for conjunction, disjunction, and implication use `C` and cases on the left characteristic term. In the zero branch the antecedent is provable; in the successor branch it implies `Delta`. The implication case is therefore constructively valid: decidability of this particular quantifier-free antecedent has been proved through its characteristic term. It is not an application of excluded middle to arbitrary formulas.

Given a source quantifier-free induction, reflect its base and step into the literal equation `rho_F=0`, use native equation induction, and reflect back. Substitution coherence is needed here and is supplied by the term and selector constructions. This recovers all source quantifier-free induction, including retained-context uses.

## 6. Bi-interpretability is stronger than standard-model agreement

The ordinary realization has the full number domain, ordinary intuitionistic logic, one symbol for each fixed initialized-recursion description, the recursion equations, literal-equation induction, numerical coverage, and the falsity bridge.

Interpret each such fixed recursion description in `iPRA_qf` by primitive recursion. Interpret each source primitive-recursive description back by the native recursor and then elaborate it to an ordinary description symbol. Coverage is proved in the source by quantifier-free induction on

`x=0 or S(p(x))=x`.

To prove the composites are internally the identity, use external induction on each **fixed finite description**, and internal equation induction to prove uniqueness of its recursion at arbitrary arguments. This is enough to identify every original symbol with its double translation. The domain is unchanged and equality defines the two internal isomorphisms. These equalities hold at nonstandard arguments as well; agreement merely at standard numerals would not prove bi-interpretability.

For native recursor syntax, an external occurrence of the supplied counter inside the body must be held fixed as a parameter during the internal uniqueness induction. The fresh induction counter must not replace that parameter. The inherited elaboration and coherence discussion correctly makes this distinction.

The native calculus is not itself written in standard first-order syntax: it has term binders and nonstandard logical constructors. The precise claim should therefore name its ordinary first-order realization and separately state the faithful full-sequent translations between that realization and the native calculus.

## 7. Coverage cannot be silently removed

Interpret every primitive-recursive function coordinatewise on `N x N`. A literal equation in one pair variable, with parameters fixed, has a rectangular truth set `U x V`. A true base and true successor-closure premise force every diagonal pair into the rectangle, hence force `U=V=N`. All equation-induction instances hold. Defining equations, injectivity, and successor separation also hold.

The element `(0,1)` is neither zero nor a simultaneous successor. Thus numerical coverage fails. The native formula

`((x=0 ->* Delta) ->* exists y (Sy=x))`

has the required zero and successor cases but fails at `(0,1)`. This is a valid obstruction even in a classical one-node model, so the issue cannot be dismissed as a merely intuitionistic subtlety in the model construction.

## 8. Audit of the goal-directed checker

For the complete command-line program, the following invariant suffices: all context entries are well-formed native formulas, and `check(a,p,g)` can return true only when `g |- a` is derivable. The outer command-line boundary validates every original context entry. Every recursive call validates its expected goal.

* A guarded-universal introduction reads both its local guard and conclusion from an already validated goal. Raising the context enforces eigenvariable freshness.
* A numerical certificate checks that the guard is the exact zero instance of the conclusion. The extra local assumption is the unshifted equation only when the conclusion is literally an equation; otherwise it is the fixed zero instance. Thus it cannot accidentally implement full induction.
* Existential introduction uses the validated witness to create the equation between the fresh variable and the raised witness.
* Elimination first recursively validates and proves the annotated major formula. Its root and number of children are consequently trustworthy. The existential minor is checked against the raised outside conclusion, enforcing nonescape of its eigenvariable.
* Equality and guarded-universal applications instantiate their two components by the existing capture-avoiding substitution procedure. A malformed unused universal-witness payload is harmless only via the explicit reconstruction lemma: if the bound slot is unused in both components, use zero instead; if it is used, substitution validates the witness at that occurrence.
* The recursion-computation certificate can use validation of its expected equation. In the nonzero branch, a well-formed term that can be unpacked into two fields must be a successor; a variable cannot be unpacked, and a recursion term has four fields. This makes ignoring the unpacked successor tag safe.
* Hypothesis leaves use actual list lookup. Negative integers and Boolean indices merely alias actual entries; they add no inference rule. Live mathematical integer leaves are validated with an exact integer type check, so Python's equality between integers, floats, and Booleans cannot corrupt formula comparison.

The complete CLI is an acceptance boundary. The internal function `check(a,p,g)` by itself assumes a valid context; it should not be advertised as an unconditionally validating external API unless a wrapper is supplied. Return `False` and exceptions must both count as rejection. The boolean checker is safe under Python optimization because it does not rely on assertions.

Removing introduction labels is a proof-certificate change only. For a `pi` goal, a two-field certificate `[flag,q]` can distinguish ordinary introduction from the numerical rule; for an `ex` goal `[t,q]` supplies the witness. A computation certificate can be the empty list. Elimination certificates have three or four fields, so their shape remains unambiguous. If non-Boolean flags are admitted through JSON truthiness, explicitly describe them as aliases of the two canonical choices; the choice cannot introduce any additional inference.

## Evidence boundary

The above is a paper proof and independent mathematical/code audit. Executable certificate replay can corroborate local rules, indexing, substitution, and rejection behavior. It is not a machine-checked proof of the universal metatheorems. A strict size improvement over a pinned finite corpus is an engineering theorem about those complete source files and a fixed measurement procedure; it is not an absolute minimality theorem.
