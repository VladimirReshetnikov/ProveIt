"""Reproduce the measurements and finite verification; optionally rebuild PDF."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    for script in ["comparison/measure.py", "validation/verify.py"]:
        subprocess.run([sys.executable, script], cwd=ROOT, check=True)
    metrics = json.loads((ROOT / "results/metrics.json").read_text())
    validation = json.loads((ROOT / "results/validation.json").read_text())
    actual = hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest()
    if metrics["candidate"]["sha256"] != actual:
        raise ValueError("Measured checker hash mismatch")
    if validation["checker_sha256"] != actual:
        raise ValueError("Validated checker hash mismatch")
    if validation.get("failures"):
        raise ValueError("Validation failures remain")
    summary = {
        "status": "passed", "checker_sha256": actual,
        "strictly_below": metrics["strictly_below"],
        "qualification": "Finite executable evidence; universal metatheorems are paper proofs.",
    }
    (ROOT / "results/reproduction.json").write_text(json.dumps(summary, indent=2) + "\n")
    if args.pdf:
        subprocess.run([sys.executable, "build.py"], cwd=ROOT, check=True)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
