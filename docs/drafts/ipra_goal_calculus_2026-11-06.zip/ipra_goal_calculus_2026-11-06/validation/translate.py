"""Untrusted, offline translations between the two certificate formats.

The predecessor format has zero -1, variables starting at 0, and explicit
lam/nat/pack/use/r proof labels. The new format has zero 0, variables starting
at 1, and introductions selected by their goals. Proof-assumption indices and
environment tail shifts are never reindexed.

These are canonical certificate translations, not an assertion that every
malformed raw input has identical acceptance behavior in the two formats.
All substitution used for inverse reconstruction is performed by the inherited
named-binder oracle; this module does not import the target checker.
"""
import argparse
import json
from pathlib import Path

from named_oracle import named, oracle, valid


def reindex(expression, delta):
    """Reindex an expression payload, preserving noninteger JSON leaves."""
    if type(expression) is int:
        return expression + delta
    if type(expression) is list:
        return [reindex(child, delta) for child in expression]
    if type(expression) is dict:
        return {key: reindex(value, delta) for key, value in expression.items()}
    return expression


def require(condition):
    if not condition:
        raise ValueError('not a canonical certificate shape')


def source_proof(proof):
    """Translate structurally well-formed legacy proof data forward."""
    if type(proof) in (int, bool):
        return proof
    if proof == 'r':
        return []
    require(type(proof) is list and bool(proof))
    tag = proof[0]
    if tag in ('lam', 'nat'):
        require(len(proof) == 2)
        return [tag == 'nat', source_proof(proof[1])]
    if tag == 'pack':
        require(len(proof) == 3 and valid(proof[1], False))
        return [reindex(proof[1], 1), source_proof(proof[2])]
    require(tag == 'use' and len(proof) >= 3)
    major, derivation, *args = proof[1:]
    require(valid(major, True))
    head = [reindex(major, 1), source_proof(derivation)]
    if major[0] == 'ex':
        require(len(args) == 1)
        return [*head, source_proof(args[0])]
    require(len(args) == 2)
    if major[0] == '=':
        require(valid(args[0], True))
    # An unused pi witness payload can be noncanonical; its irrelevance is
    # independently checked by the proof interpreters. Preserve the payload.
    return [*head, reindex(args[0], 1), source_proof(args[1])]


def to_target(data):
    """Translate a well-formed legacy record to the new certificate syntax."""
    require(type(data) is list and len(data) >= 2)
    goal, proof, *context = data
    require(all(valid(a, True) for a in [goal, *context]))
    return [reindex(goal, 1), source_proof(proof),
            *(reindex(a, 1) for a in context)]


def substitute(expression, environment=(1,), formula=True):
    """New-index substitution via the independent legacy named oracle."""
    old_environment = [*(reindex(a, -1) for a in environment[:-1]), environment[-1]]
    result = oracle(reindex(expression, -1), old_environment, formula=formula)
    return reindex(result, 1)


def contains_free_zero(expression):
    """Inspect named syntax for the free variable substituted by pi elimination."""
    if type(expression) is not tuple:
        return False
    if expression[0] == 'free':
        return expression[1] == 0
    return any(contains_free_zero(child) for child in expression[1:])


def target_proof(goal, proof):
    """Recover legacy labels from an accepted target proof and its goal.

    For flag aliases, the Boolean truth value selects the recovered rule.
    Contexts are not needed: every recursively required goal is explicit or
    computed by the independent substitution oracle.
    """
    require(valid(reindex(goal, -1), True))
    if type(proof) in (int, bool):
        return proof
    require(type(proof) is list)
    if goal[0] == 'pi' and len(proof) == 2:
        flag, subproof = proof
        body = substitute(goal[2], [['s', 1], 0]) if flag else goal[2]
        return ['nat' if flag else 'lam', target_proof(body, subproof)]
    if goal[0] == 'ex' and len(proof) == 2:
        witness, subproof = proof
        require(valid(reindex(witness, -1), False))
        return ['pack', reindex(witness, -1), target_proof(goal[1], subproof)]
    if proof == []:
        require(goal[0] == '=' and type(goal[1]) is list and goal[1][0] == 'r')
        return 'r'
    require(len(proof) >= 3)
    major, derivation, *args = proof
    old_major = reindex(major, -1)
    require(valid(old_major, True))
    head = ['use', old_major, target_proof(major, derivation)]
    if major[0] == 'ex':
        require(len(args) == 1)
        return [*head, target_proof(substitute(goal), args[0])]
    require(len(args) == 2)
    annotation, subproof = args
    if major[0] == '=':
        premise = substitute(annotation, [major[1], -1])
    else:
        witness = annotation
        if not valid(reindex(witness, -1), False):
            require(not any(contains_free_zero(named(part)) for part in old_major[1:]))
            witness = 0
        premise = substitute(major[1], [witness, -1])
    return [*head, reindex(annotation, -1), target_proof(premise, subproof)]


def to_source(data):
    """Reconstruct a legacy certificate; its proof must still be checked."""
    require(type(data) is list and len(data) >= 2)
    goal, proof, *context = data
    old_goal = reindex(goal, -1)
    old_context = [reindex(a, -1) for a in context]
    require(all(valid(a, True) for a in [old_goal, *old_context]))
    return [old_goal, target_proof(goal, proof), *old_context]


def fixture_proof(proof):
    """Translate legacy negative fixtures without discarding malformed fields.

    This adapter supports the inherited finite regression suite. It is not a
    theorem asserting preservation of rejection on all raw malformed inputs.
    """
    if proof == 'r':
        return []
    if type(proof) is not list or not proof:
        return proof
    if proof[0] in ('lam', 'nat') and len(proof) == 2:
        return [proof[0] == 'nat', fixture_proof(proof[1])]
    if proof[0] == 'pack' and len(proof) == 3:
        return [reindex(proof[1], 1), fixture_proof(proof[2])]
    if proof[0] == 'use' and len(proof) >= 3:
        major, derivation, *args = proof[1:]
        if type(major) is list and major and major[0] == 'ex':
            rest = [fixture_proof(x) for x in args]
        else:
            rest = [reindex(args[0], 1)] if args else []
            if len(args) >= 2:
                rest.append(fixture_proof(args[1]))
            rest.extend(args[2:])
        return [reindex(major, 1), fixture_proof(derivation), *rest]
    return proof


def translate_fixture(data):
    if type(data) is not list or len(data) < 2:
        return data
    goal, proof, *context = data
    return [reindex(goal, 1), fixture_proof(proof),
            *(reindex(a, 1) for a in context)]


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('direction', choices=('forward', 'backward'))
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    operation = to_target if args.direction == 'forward' else to_source
    result = operation(json.loads(args.input.read_text(encoding='utf-8')))
    args.output.write_text(json.dumps(result, separators=(',', ':')) + '\n', encoding='utf-8')
