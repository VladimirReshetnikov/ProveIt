"""Independent finite audit of goal-directed iPRA certificates.

All certificate cases run through the real public JSON/CLI boundary. The
separate rule interpreter uses named_oracle.py, never the target's substitution
or scope table. The target is imported only for random substitution comparisons.
This testing program and its helper are untrusted clients, not kernel imports.
"""

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile

from named_oracle import valid, named, oracle, term, formula


ZERO = -1
ONE = ["s", ZERO]
TRUE = ["=", ZERO, ZERO]
FALSE = ["=", ZERO, ONE]


def ensure(condition):
    if not condition:
        raise ValueError("independent rule interpreter rejected")


def checked(expression, is_formula):
    ensure(valid(expression, is_formula))
    return expression


def uses_outer_variable(expression):
    """Inspect named syntax, so bound variables cannot alias the free slot."""
    if not isinstance(expression, tuple):
        return False
    if expression[0] == "free":
        return expression[1] == 0
    return any(uses_outer_variable(child) for child in expression[1:])


def reference_rule(goal, proof, context, counts, strict_witness):
    """Explicit natural deduction rules with separately implemented binding."""
    checked(goal, True)
    if type(proof) in (int, bool):
        ensure(-len(context) <= proof < len(context))
        ensure(goal == context[proof])
        counts["assumption"] += 1
        return
    if proof == "r":
        ensure(goal[0] == "=" and type(goal[1]) is list and goal[1][0] == "r")
        counter, initial, update = goal[1][1:]
        if counter == ZERO:
            reduct = initial
            counts["recursor_zero"] += 1
        else:
            ensure(type(counter) is list and len(counter) == 2 and counter[0] == "s")
            predecessor = counter[1]
            previous = ["r", predecessor, initial, update]
            reduct = oracle(update, [previous, predecessor, -2], formula=False)
            counts["recursor_successor"] += 1
        ensure(goal[2] == reduct)
        return
    ensure(type(proof) is list and proof and type(proof[0]) is str)
    rule = proof[0]
    if rule == "lam":
        ensure(len(proof) == 2 and goal[0] == "pi")
        guard, body = goal[1:]
        local = [oracle(a) for a in context] + [guard]
        reference_rule(body, proof[1], local, counts, strict_witness)
        counts["guarded_universal_introduction"] += 1
        return
    if rule == "pack":
        ensure(len(proof) == 3 and goal[0] == "ex")
        witness = checked(proof[1], False)
        guard = ["=", 0, oracle(witness, formula=False)]
        local = [oracle(a) for a in context] + [guard]
        reference_rule(goal[1], proof[2], local, counts, strict_witness)
        counts["existential_introduction"] += 1
        return
    if rule == "nat":
        ensure(len(proof) == 2 and goal[0] == "pi")
        base, matrix = goal[1:]
        ensure(base == oracle(matrix, [ZERO, 0]))
        guard = matrix if matrix[0] == "=" else base
        local = [oracle(a) for a in context] + [guard]
        successor = oracle(matrix, [["s", 0], 0])
        reference_rule(successor, proof[1], local, counts, strict_witness)
        counts["equation_induction" if matrix[0] == "=" else "numerical_cases"] += 1
        return
    ensure(rule == "use" and len(proof) >= 4)
    major = checked(proof[1], True)
    reference_rule(major, proof[2], context, counts, strict_witness)
    if major[0] == "ex":
        ensure(len(proof) == 4)
        local = [oracle(a) for a in context] + [major[1]]
        reference_rule(oracle(goal), proof[3], local, counts, strict_witness)
        counts["existential_elimination"] += 1
        return
    ensure(len(proof) == 5)
    annotation, premise_proof = proof[3:]
    if major[0] == "pi":
        used = any(uses_outer_variable(named(part)) for part in major[1:])
        witness = checked(annotation, False) if strict_witness or used else ZERO
        antecedent = oracle(major[1], [witness, -1])
        result = oracle(major[2], [witness, -1])
        counts["guarded_universal_elimination"] += 1
    else:
        ensure(major[0] == "=")
        motive = checked(annotation, True)
        antecedent = oracle(motive, [major[1], -1])
        result = oracle(motive, [major[2], -1])
        counts["equality_transport"] += 1
    ensure(result == goal)
    reference_rule(antecedent, premise_proof, context, counts, strict_witness)


def reference_check(data, strict_witness):
    ensure(type(data) is list and len(data) >= 2)
    goal, proof, *context = data
    for assumption in context:
        checked(assumption, True)
    counts = Counter()
    reference_rule(goal, proof, context, counts, strict_witness)
    return counts


def succeeds(function, *args, **kwargs):
    try:
        return True, function(*args, **kwargs)
    except Exception:
        return False, None


def eq(a, b):
    return ["=", a, b]


def reflexivity(t):
    recursor = ["r", ZERO, t, ZERO]
    major = eq(recursor, t)
    motive = eq(0, oracle(t, formula=False))
    return ["use", major, "r", motive, "r"]


def direct_cases(strict_witness):
    """Named, distinct positive and negative public certificates."""
    cases = []
    seen = {}

    def add(name, goal, proof, context=(), expected=True, category="rules"):
        data = [goal, proof, *context]
        raw(name, data, expected, category)

    def raw(name, data, expected=False, category="public_boundary"):
        key = json.dumps(data, sort_keys=True, separators=(",", ":"))
        if key in seen:
            ensure(seen[key] == expected)
            return
        seen[key] = expected
        cases.append({"name": name, "data": data, "expected": expected, "category": category})

    add("assumption at zero", TRUE, 0, [TRUE])
    add("assumption negative index", TRUE, -1, [FALSE, TRUE])
    add("boolean index is a context alias", TRUE, True, [FALSE, TRUE])
    add("false assumption may be reused", FALSE, 0, [FALSE])
    add("unproved falsity", FALSE, 0, [], False)
    add("hypothesis upper bound", TRUE, 1, [TRUE], False)
    add("hypothesis lower bound", TRUE, -2, [TRUE], False)
    add("float is not a hypothesis index", TRUE, 0.0, [TRUE], False)
    add("null is not a hypothesis index", TRUE, None, [TRUE], False)
    add("unknown proof tag", TRUE, ["unknown", 0], [TRUE], False)

    terms = [ZERO, 0, ["s", 1], ["r", 2, ZERO, ["s", 0]]]
    updates = [ZERO, 0, 1, ["r", 2, 0, ["s", 2]]]
    for i, (initial, update) in enumerate(zip(terms, updates)):
        zero_rec = ["r", ZERO, initial, update]
        add(f"zero computation {i}", eq(zero_rec, initial), "r", category="computation")
        add(f"wrong zero reduct {i}", eq(zero_rec, ["s", initial]), "r", expected=False,
            category="computation")
        predecessor = i
        rec = ["r", ["s", predecessor], initial, update]
        reduct = oracle(update, [["r", predecessor, initial, update], predecessor, -2], formula=False)
        add(f"successor computation {i}", eq(rec, reduct), "r", category="computation")
        add(f"wrong successor reduct {i}", eq(rec, ["s", reduct]), "r", expected=False,
            category="computation")
        add(f"derived reflexivity {i}", eq(initial, initial), reflexivity(initial))
    add("variable counter is not a computation", eq(["r", 0, ZERO, ZERO], ZERO), "r",
        expected=False, category="computation")
    add("recursor counter is not a computation", eq(["r", ["r", ZERO, ZERO, ZERO], ZERO, ZERO], ZERO),
        "r", expected=False, category="computation")
    add("computation marker needs a recursor", TRUE, "r", expected=False, category="computation")

    dependent = eq(0, ZERO)
    add("dependent pi identity", ["pi", dependent, dependent], ["lam", -1])
    add("pi keeps a lifted free parameter", ["pi", TRUE, eq(1, ZERO)], ["lam", 0], [eq(0, ZERO)])
    add("pi cannot capture a free parameter", ["pi", TRUE, eq(0, ZERO)], ["lam", 0],
        [eq(0, ZERO)], False)
    add("pi introduction wrong conclusion", ["pi", TRUE, FALSE], ["lam", -1], expected=False)
    add("lambda wrong goal constructor", TRUE, ["lam", 0], [TRUE], False)
    add("lambda extra formula annotation", ["pi", TRUE, TRUE], ["lam", TRUE, 0], expected=False)

    for i, witness in enumerate(terms[:3]):
        body = eq(0, oracle(witness, formula=False))
        add(f"existential witness declaration {i}", ["ex", body], ["pack", witness, -1])
    add("existential derived reflexivity", ["ex", eq(0, 0)], ["pack", ZERO, reflexivity(0)])
    add("pack cannot capture outer parameter", ["ex", eq(0, 0)], ["pack", 0, -1], expected=False)
    add("pack wrong goal constructor", TRUE, ["pack", ZERO, 0], [TRUE], False)
    add("pack missing branch", ["ex", TRUE], ["pack", ZERO], expected=False)

    matrix = eq(0, 0)
    add("equation induction reflexivity", ["pi", TRUE, matrix], ["nat", reflexivity(["s", 0])])
    add("equation induction constant matrix", ["pi", TRUE, TRUE], ["nat", -1])
    p = eq(0, ZERO)
    step = ["pi", p, oracle(p, [["s", 0], 0])]
    goal = ["pi", oracle(p, [ZERO, 0]), p]
    branch = ["use", oracle(step), 0, 0, -1]
    add("equation induction uses local induction hypothesis", goal, ["nat", branch], [step])
    add("numerical rule rejects wrong base", ["pi", FALSE, matrix], ["nat", reflexivity(["s", 0])],
        expected=False)
    add("numerical rule rejects false successor", ["pi", TRUE, p], ["nat", -1], expected=False)
    compound = ["pi", TRUE, eq(1, 1)]
    base = oracle(compound, [ZERO, 0])
    add("cases for genuinely dependent quantified matrix", ["pi", base, compound],
        ["nat", ["lam", reflexivity(["s", 1])]])
    existential = ["ex", TRUE]
    add("cases for existential constant matrix", ["pi", existential, existential], ["nat", -1])
    compound = ["ex", eq(0, 1)]
    compound_step = ["pi", compound, oracle(compound, [["s", 0], 0])]
    bad_induction = ["use", oracle(compound_step), 0, 0, -1]
    add("quantified matrix does not receive induction hypothesis",
        ["pi", oracle(compound, [ZERO, 0]), compound], ["nat", bad_induction], [compound_step], False)
    add("numerical rule wrong goal constructor", ["ex", TRUE], ["nat", 0], [TRUE], False)

    vacant = ["pi", TRUE, TRUE]
    bad_payloads = [None, False, 0.0, {}, ["s"], ["=", ZERO, ZERO]]
    for i, payload in enumerate(bad_payloads):
        add(f"vacuous pi payload {i}", TRUE, ["use", vacant, 0, payload, 1], [vacant, TRUE],
            not strict_witness, "witness_formation")
    inner_only = ["ex", eq(0, ZERO)]
    major = ["pi", TRUE, inner_only]
    add("inner variable is not the outer witness", inner_only, ["use", major, 0, None, 1],
        [major, TRUE], not strict_witness, "witness_formation")
    old_parameter = eq(1, 1)
    major = ["pi", old_parameter, old_parameter]
    add("vacuous witness still lowers old parameters", eq(0, 0), ["use", major, 0, None, 1],
        [major, eq(0, 0)], not strict_witness, "witness_formation")
    structures = [eq(0, 0), ["ex", eq(1, 0)], ["pi", TRUE, eq(1, 1)],
                  eq(["r", ZERO, ZERO, 2], ZERO)]
    for i, body in enumerate(structures):
        major = ["pi", body, body]
        instantiated = oracle(body, [ZERO, -1])
        add(f"nested pi substitution {i}", instantiated, ["use", major, 0, ZERO, 1],
            [major, instantiated])
        add(f"used malformed witness {i}", instantiated, ["use", major, 0, None, 1],
            [major, instantiated], False, "witness_formation")
    major = ["pi", eq(0, 0), TRUE]
    add("witness demanded by antecedent only", TRUE, ["use", major, 0, None, 1],
        [major, TRUE], False, "witness_formation")
    major = ["pi", TRUE, eq(0, 0)]
    add("witness demanded by consequent only", TRUE, ["use", major, 0, None, 1],
        [major, TRUE], False, "witness_formation")
    add("elimination cannot invent its major", TRUE, ["use", vacant, 0, ZERO, 1], [TRUE, TRUE], False)
    add("elimination rejects wrong result", FALSE, ["use", vacant, 0, ZERO, 1], [vacant, TRUE], False)
    add("elimination rejects wrong antecedent", TRUE, ["use", vacant, 0, ZERO, 1], [vacant, FALSE], False)
    add("pi elimination missing minor", TRUE, ["use", vacant, 0, ZERO], [vacant, TRUE], False)

    major = eq(0, 1)
    motives = [eq(0, ZERO), ["ex", eq(1, 0)], ["pi", eq(1, 1), eq(1, ZERO)],
               eq(["r", 0, ZERO, ["r", 2, 0, 3]], ZERO), TRUE]
    for i, motive in enumerate(motives):
        antecedent = oracle(motive, [0, -1])
        result = oracle(motive, [1, -1])
        add(f"equality transport template {i}", result, ["use", major, 0, motive, 1],
            [major, antecedent])
    for i, payload in enumerate([None, 0, ["s", ZERO], ["=", False, ZERO]]):
        add(f"malformed equality motive {i}", TRUE, ["use", major, 0, payload, 1],
            [major, TRUE], False, "witness_formation")

    major = ["ex", TRUE]
    add("existential elimination local premise", TRUE, ["use", major, 0, -1], [major])
    add("existential elimination keeps parameter", eq(0, 0), ["use", major, 0, 1], [major, eq(0, 0)])
    for i, body in enumerate([eq(0, ZERO), ["ex", eq(1, ZERO)], ["pi", TRUE, eq(1, ZERO)],
                              eq(["r", ZERO, ZERO, 2], ZERO)]):
        major = ["ex", body]
        add(f"existential eigenvariable escape {i}", body, ["use", major, 0, -1], [major], False,
            "scope")
    add("existential elimination extra argument", TRUE, ["use", ["ex", TRUE], 0, TRUE, -1],
        [["ex", TRUE]], False)

    malformed = [None, False, 0, [], ["=", ZERO], ["=", ZERO, ZERO, ZERO],
                 ["pi", TRUE], ["ex", TRUE, TRUE], eq(False, ZERO), eq(0.0, ZERO),
                 eq(["s"], ZERO), eq(["r", ZERO, ZERO], ZERO)]
    for i, expression in enumerate(malformed):
        add(f"malformed goal {i}", expression, 0, [TRUE], False, "formation")
        add(f"malformed unused hypothesis {i}", TRUE, 0, [TRUE, expression], False, "formation")
        add(f"malformed explicit major {i}", TRUE, ["use", expression, 0, ZERO, 1], [TRUE, TRUE],
            False, "formation")
    for i, witness in enumerate([False, 0.0, None, ["s"], ["pi", TRUE, TRUE]]):
        add(f"malformed existential witness {i}", ["ex", TRUE], ["pack", witness, 0], [TRUE],
            False, "witness_formation")
    for i, data in enumerate([None, False, 0, "ab", {"a": TRUE, "b": 0}, [], [TRUE], [[], TRUE, 0]]):
        raw(f"malformed top-level data {i}", data)
    return cases


def main(options):
    checker_path = options.checker.resolve()
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("kernel_goal_under_test", checker_path)
    target = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(target)
    failures = []
    counts = Counter()
    rule_counts = Counter()
    records = []

    def record(category, name, condition):
        counts[category] += 1
        if not condition:
            failures.append({"category": category, "name": name})

    rng = random.Random(617353)
    expressions = []
    for _ in range(12):
        expressions.extend([(term(rng, 3), False), (formula(rng, 3), True)])
    environments = [(0,), (1,), [ZERO, -1], [["s", 0], 0]]
    for i, (expression, sort) in enumerate(expressions):
        for depth in (0, 2):
            for j, environment in enumerate(environments):
                expected = oracle(expression, environment, depth, sort)
                ok, actual = succeeds(target.subst, expression, environment, depth, formula=sort)
                record("named_substitution", f"expression {i}, depth {depth}, environment {j}",
                       ok and actual == expected)

    cases = direct_cases(options.strict_witness)
    direct_count = len(cases)
    if options.corpus:
        for file in sorted(options.corpus.rglob("*.json")):
            cases.append({"name": "corpus " + str(file.relative_to(options.corpus)),
                          "data": json.loads(file.read_text()), "expected": True, "category": "corpus",
                          "source_sha256": hashlib.sha256(file.read_bytes()).hexdigest()})
    with tempfile.TemporaryDirectory(prefix="ipra-goal-audit-") as temporary:
        certificate = Path(temporary) / "certificate.json"
        for case in cases:
            ok, rules = succeeds(reference_check, case["data"], options.strict_witness)
            record("independent_rules", case["name"], ok == case["expected"])
            if ok:
                rule_counts.update(rules)
            certificate.write_text(json.dumps(case["data"]) + "\n")
            process = subprocess.run([sys.executable, str(checker_path), str(certificate)],
                                     text=True, capture_output=True, timeout=20)
            accepted = process.returncode == 0
            good = (process.returncode == (0 if case["expected"] else 1)
                    and process.stdout.strip() == ("ACCEPT" if case["expected"] else "REJECT"))
            record("cli_" + case["category"], case["name"], good)
            records.append({"name": case["name"], "category": case["category"],
                            "expected": case["expected"], "reference_accepted": ok,
                            "candidate_accepted": accepted, "public_cli_validated": True})
        # These are process/decoder boundary checks, not logical rule instances.
        raw_cases = [("truncated JSON", "["), ("NaN in goal", '[["=",NaN,-1],0]'),
                     ("Infinity in unused hypothesis", '[["=",-1,-1],0,["=",-1,-1],["=",Infinity,0]]')]
        for name, data in raw_cases:
            certificate.write_text(data)
            process = subprocess.run([sys.executable, str(checker_path), str(certificate)],
                                     text=True, capture_output=True, timeout=20)
            record("cli_decoder", name, process.returncode == 1 and process.stdout.strip() == "REJECT")
        for name, extra in [("no filename", []), ("extra filename", [str(certificate), str(certificate)]),
                            ("missing file", [str(Path(temporary) / "absent.json")])]:
            process = subprocess.run([sys.executable, str(checker_path), *extra],
                                     text=True, capture_output=True, timeout=20)
            record("cli_arguments", name, process.returncode == 1 and process.stdout.strip() == "REJECT")
        # Run a fixed, small semantic cross-section with assertions disabled.
        optimized = [c for c in cases[:direct_count] if c["name"] in {
            "assumption at zero", "unproved falsity", "zero computation 3", "successor computation 3",
            "dependent pi identity", "pi cannot capture a free parameter", "existential witness declaration 1",
            "equation induction uses local induction hypothesis", "quantified matrix does not receive induction hypothesis",
            "vacuous pi payload 0", "used malformed witness 2", "equality transport template 3",
            "existential eigenvariable escape 2", "malformed unused hypothesis 8"}]
        for case in optimized:
            certificate.write_text(json.dumps(case["data"]) + "\n")
            process = subprocess.run([sys.executable, "-O", str(checker_path), str(certificate)],
                                     text=True, capture_output=True, timeout=20)
            record("optimized_cli", case["name"],
                   process.returncode == (0 if case["expected"] else 1)
                   and process.stdout.strip() == ("ACCEPT" if case["expected"] else "REJECT"))
    report = {"checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
              "audit_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "oracle_sha256": hashlib.sha256(Path(__file__).with_name("named_oracle.py").read_bytes()).hexdigest(),
              "python_version": platform.python_version(), "seed": 617353,
              "strict_witness": options.strict_witness, "counts": dict(counts),
              "direct_certificate_cases": direct_count,
              "corpus_certificate_cases": len(cases) - direct_count,
              "certificate_cases": len(cases), "total_checks": sum(counts.values()),
              "independent_rule_nodes_in_accepted_cases": sum(rule_counts.values()),
              "independent_rule_counts": dict(rule_counts), "failures": failures, "certificates": records,
              "scope": "Finite public-boundary and independent-rule validation; no proof-assistant verification is claimed."}
    options.output.parent.mkdir(parents=True, exist_ok=True)
    options.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("certificates",)}, indent=2))
    return not failures


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--strict-witness", action="store_true")
    parser.add_argument("--corpus", type=Path)
    raise SystemExit(0 if main(parser.parse_args()) else 1)
