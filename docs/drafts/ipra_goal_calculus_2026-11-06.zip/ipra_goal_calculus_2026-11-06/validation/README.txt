OFFLINE VALIDATION AND CERTIFICATE TRANSLATION

Run from the package root:

    python3 validation/verify.py

The authoritative checker is ../checker.py. None of the files in this
directory is imported by it or contributes to certificate acceptance.

The verifier writes ../results/validation.json. A successful run has an empty
failures array and a checker_sha256 equal to the actual checker file. It tests
both normal Python and python -O; the checker does not rely on assertions.
This is finite executable evidence, not a proof-assistant formalization of
the universal metatheorems in the paper.

INDEPENDENT INTERPRETATION

named_oracle.py and inherited_goal_audit.py are unchanged copies from the
ipra_reduction_2026-11-06 archive in the pinned ProveIt snapshot. The oracle
first resolves de Bruijn indices into fresh named binder identities. It
substitutes named free variables and then reconstructs indices, independently
of the candidate checker's SCOPES table and substitution implementation.

The inherited rule interpreter uses the predecessor's zero=-1 serialization.
It is retained unchanged to keep its independence and provenance transparent.
Use verify.py for the new checker; do not pass the new serialization directly
to the inherited standalone audit script.

CORPUS DEDUPLICATION

The predecessor archive contains goal_corpus and strict_corpus, each with 194
files and the same filenames. Exactly 150 pairs are byte-identical. The other
44 differ in their unused-witness payloads. This package stores the 194 goal
files and only the 44 distinct strict variants, avoiding redundant copies and
test counts. It additionally stores the 18 original arithmetic examples.

SOURCES.json records the repository commit, original archive and Git blob,
archive SHA-256, every inherited file's original archive member and SHA-256,
and the complete deduplication decision. The verifier checks the retained
files against these recorded digests. LICENSE_INHERITED.txt retains the
source's MIT No Attribution License and copyright attribution.

TRANSLATIONS

translate.py contains to_target and to_source, plus a command-line interface:

    python3 validation/translate.py forward OLD.json NEW.json
    python3 validation/translate.py backward NEW.json OLD.json

The forward direction removes redundant proof labels and increments each
term/formula integer by one. It never increments hypothesis proof indices
or environment tail shifts. The backward direction uses the current goal
to recover the introduction label and the named oracle to recover recursive
premise goals. Every accepted proof reconstructed during validation is
checked again by the independent inherited rule interpreter.

Canonical flags are false and true. Other finite JSON values alias one of
those flags according to their truth value. The inverse translation selects
the corresponding legacy rule. It does not give an isomorphism between all
malformed raw byte strings, and no such claim is made. The separate negative
fixture adapter preserves malformed fields and extra arguments in the
inherited finite tests; it is not used as a soundness axiom.

The 18 files in ../examples are in the final checker syntax. Their manifest
records both the delivered digests and the corresponding legacy-source
digests. The verifier checks the translations and runs every published
example through the public CLI in both normal and optimized Python.

TEST BOUNDARIES

The internal check(goal, proof, context) predicate presumes a valid context.
The public CLI validates every hypothesis, while check validates every goal
and every explicit major premise. The verifier's direct predicate adapter
performs exactly that context-validation step before calling check.

The tests cover all primitive rules, induction versus cases, fresh-variable
conditions, binding under nested recursors, demand-checked universal witnesses,
malformed statements, explicit-major validation, numerical type aliases,
the new flag aliases, missing/extra CLI arguments, and invalid JSON data.
