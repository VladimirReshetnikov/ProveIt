"""Reproduce the offline finite audit; no file here participates in acceptance.

The copied legacy rule interpreter uses named variables rather than the target
checker's substitution routine. The suite checks canonical translations, their
inverse, numerical reindexing, malformed statement rejection, all new flag
aliases, and the public CLI under normal and optimized Python.
"""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
import inherited_goal_audit as inherited
from named_oracle import formula, oracle, term
from translate import reindex, to_source, to_target, translate_fixture

ROOT = Path(__file__).resolve().parent.parent
VALIDATION = ROOT / 'validation'
CHECKER = ROOT / 'checker.py'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def serialize(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'), allow_nan=False)


def load_checker():
    spec = importlib.util.spec_from_file_location('target_checker', CHECKER)
    target = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(target)
    return target


def accepts(target, data):
    """Mirror the public record boundary, including all context validation."""
    try:
        goal, proof, *context = data
        for assumption in context:
            target.subst(assumption)
        return target.check(goal, proof, context) is True
    except Exception:
        return False


def try_reference(data):
    try:
        return True, inherited.reference_check(data, False)
    except Exception:
        return False, Counter()


def flag_cases():
    true = ['=', 0, 0]
    false = ['=', 0, ['s', 0]]
    goal = ['pi', true, true]
    cases = []
    for name, flag in [('false', False), ('null', None), ('empty_list', []),
                       ('empty_object', {}), ('zero', 0), ('true', True),
                       ('nonempty_string', 'numerical'), ('nonempty_object', {'flag': 0})]:
        cases.append({'name': 'flag_alias_' + name, 'target': [goal, [flag, -1]],
                      'expected': True, 'category': 'flags'})
    cases.append({'name': 'truthy_flag_enforces_numerical_base',
                  'target': [['pi', false, true], ['numerical', -1]],
                  'expected': False, 'category': 'flags'})
    return cases


def main():
    target = load_checker()
    failures = []
    counts = Counter()
    recovered_rules = Counter()
    records = []

    def record(kind, name, condition):
        counts[kind] += 1
        if not condition:
            failures.append({'kind': kind, 'name': name})

    provenance = json.loads((VALIDATION / 'SOURCES.json').read_text())
    for entry in provenance['files']:
        path = ROOT / entry['path']
        record('inherited_file_integrity', entry['path'],
               path.is_file() and digest(path) == entry['sha256'])

    cases = inherited.direct_cases(False)
    direct_count = len(cases)
    for folder in ('goal_corpus', 'strict_differences', 'examples'):
        for path in sorted((VALIDATION / 'legacy' / folder).glob('*.json')):
            cases.append({'name': folder + '/' + path.name,
                          'data': json.loads(path.read_text()),
                          'expected': True, 'category': folder})

    for case in cases:
        source_ok, _ = try_reference(case['data'])
        record('independent_legacy_rules', case['name'], source_ok == case['expected'])
        case['target'] = translate_fixture(case['data'])
        if source_ok:
            try:
                forward = to_target(case['data'])
                backward = to_source(forward)
                good = (serialize(forward) == serialize(case['target'])
                        and serialize(backward) == serialize(case['data']))
            except Exception:
                good = False
            record('canonical_roundtrip', case['name'], good)

    inherited_count = len(cases)
    cases.extend(flag_cases())
    for case in cases:
        answer = accepts(target, case['target'])
        record('target_predicate', case['name'], answer == case['expected'])
        if answer:
            try:
                recovered = to_source(case['target'])
                recovered_ok, rule_nodes = try_reference(recovered)
                statement_ok = (serialize(reindex(case['target'][0], -1)) == serialize(recovered[0])
                                and serialize([reindex(a, -1) for a in case['target'][2:]])
                                == serialize(recovered[2:]))
                good = recovered_ok and statement_ok
                if good:
                    recovered_rules.update(rule_nodes)
            except Exception:
                good = False
            record('independent_reconstruction', case['name'], good)
        records.append({'name': case['name'], 'category': case['category'],
                        'expected': case['expected'], 'accepted': answer})

    rng = random.Random(654020)
    for index in range(24):
        for a, sort in ((term(rng, 4), False), (formula(rng, 4), True)):
            for depth in (0, 1, 3):
                for env in ((0,), (1,), [-1, -1], [['s', 0], 0], [0, -1, -2]):
                    new_env = [*(reindex(x, 1) for x in env[:-1]), env[-1]]
                    expected = reindex(oracle(a, env, depth, sort), 1)
                    actual = target.subst(reindex(a, 1), new_env, depth, formula=sort)
                    record('named_substitution', str(counts['named_substitution']), actual == expected)

    # New examples are delivered in the final proof syntax, not as legacy data.
    example_records = json.loads((ROOT / 'examples' / 'manifest.json').read_text())['examples']
    example_cases = []
    for entry in example_records:
        path = ROOT / 'examples' / entry['filename']
        data = json.loads(path.read_text())
        legacy = json.loads((VALIDATION / 'legacy' / 'examples' / entry['filename']).read_text())
        record('example_integrity', entry['filename'], digest(path) == entry['sha256'])
        record('example_conversion', entry['filename'], serialize(data) == serialize(to_target(legacy)))
        example_cases.append({'name': 'published_example/' + entry['filename'],
                              'target': data, 'expected': True})

    cli_cases = [*cases[:direct_count], *cases[inherited_count:], *example_cases]
    with tempfile.TemporaryDirectory(prefix='ipra-certificate-audit-') as temporary:
        certificate = Path(temporary) / 'certificate.json'
        for optimized in (False, True):
            command = [sys.executable, *(['-O'] if optimized else []), str(CHECKER)]
            kind = 'optimized_cli' if optimized else 'normal_cli'
            for case in cli_cases:
                certificate.write_text(json.dumps(case['target']) + '\n')
                process = subprocess.run([*command, str(certificate)], text=True,
                                         capture_output=True, timeout=20)
                expected = (0, 'ACCEPT') if case['expected'] else (1, 'REJECT')
                record(kind, case['name'],
                       (process.returncode, process.stdout.strip()) == expected)
            raw_cases = [('truncated_json', '['), ('nan_in_goal', '[["=",NaN,0],0]'),
                         ('infinity_in_unused_assumption',
                          '[["=",0,0],0,["=",0,0],["=",Infinity,0]]')]
            for name, raw in raw_cases:
                certificate.write_text(raw)
                process = subprocess.run([*command, str(certificate)], text=True,
                                         capture_output=True, timeout=20)
                record(kind + '_decoder', name,
                       (process.returncode, process.stdout.strip()) == (1, 'REJECT'))
            for name, arguments in [('no_filename', []),
                                    ('extra_filename', [str(certificate), str(certificate)]),
                                    ('missing_file', [str(Path(temporary) / 'missing.json')])]:
                process = subprocess.run([*command, *arguments], text=True,
                                         capture_output=True, timeout=20)
                record(kind + '_arguments', name,
                       (process.returncode, process.stdout.strip()) == (1, 'REJECT'))

    report = {
        'checker_sha256': digest(CHECKER), 'verifier_sha256': digest(Path(__file__)),
        'translator_sha256': digest(VALIDATION / 'translate.py'),
        'named_oracle_sha256': digest(VALIDATION / 'named_oracle.py'),
        'python_version': platform.python_version(), 'random_seed': 654020,
        'direct_legacy_cases': direct_count, 'legacy_corpus_cases': inherited_count - direct_count,
        'additional_flag_cases': len(cases) - inherited_count, 'certificate_cases': len(cases),
        'strict_corpus_byte_duplicates_omitted': 150,
        'counts': dict(counts), 'total_checks': sum(counts.values()),
        'reconstructed_rule_nodes': sum(recovered_rules.values()),
        'reconstructed_rule_counts': dict(recovered_rules),
        'failures': failures, 'certificates': records,
        'scope': ('Finite executable evidence. Mathematical soundness, representability, and '
                  'bi-interpretability are proved in the paper, not by these tests. '
                  'Canonical certificate translation is not equality of all malformed raw '
                  'input languages. No proof-assistant verification is claimed.')}
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results' / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'certificates'}, indent=2))
    return not failures


if __name__ == '__main__':
    raise SystemExit(0 if main() else 1)
