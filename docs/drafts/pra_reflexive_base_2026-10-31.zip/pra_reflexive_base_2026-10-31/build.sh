#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build pra_reflexive_base.tex
cp build/pra_reflexive_base.pdf pra_reflexive_base.pdf
