CONSTRUCTIVE LEAN CERTIFICATE

File: ReflexiveBasePRA.lean
Verified with Lean 4.19.0. No imports or external packages are required.

Run:
  lean ReflexiveBasePRA.lean

Or run check.sh, optionally setting LEAN_BIN to an absolute Lean executable.
The recorded verification.log contains the output of the successful check.
Each of its sixteen dependency checks reports no axioms.

WHAT IS CHECKED

1. Actual finite terms with three numerical variable slots and binary
   function symbols; simultaneous substitution and its evaluation law.
2. Literal syntactic equality of H(n,1,a) and H(1,n,a) after n:=1.
   No defining-equation rewrites or semantic equality test enter this fact.
3. The swap schema, quantified over this finite term datatype rather than
   arbitrary functions on the arithmetic carrier.
4. Separation and A(n,1)=Sn from the single addition-context instance.
5. Positive constructor coverage from the second fixed context A(p(x),y).
6. Successor injectivity, successor nonzeroness, and numerical zero decision.
7. The predecessor-wrapped selector, with both constructor equations; its
   proof does not assume addition's right-zero law.
8. General equation induction for every finite two-variable term pair,
   under its fixed base and step assumptions, using one constructed context.
9. Addition's right-zero law and subtraction Shift as derived examples;
   identity-target and zero-equation induction as immediate corollaries.
10. The converse swap instance from its usual quantifier-free induction
    instance and separation. Reflexivity gives the base at one.

SCOPE AND ASSUMPTIONS

The arithmetic carrier is an arbitrary Type. Its four designated binary
operations satisfy the computation equations for initialized predecessor,
addition, subtraction, and zero gate. Other binary symbols are arbitrary
interpretations. Thus the core applies to the intended expansion by all
well-founded iterator declarations, without assuming their completeness.

Theorem hypotheses include the supplied computation equations and the swap
schema. "No axioms" in Lean's output means the proof constants introduce no
additional Lean axioms; it does not erase their explicit hypotheses.

The certificate is a constructive semantic derivation over finite syntax.
It does not implement a first-order proof calculus or the complete finite
well-founded declaration grammar. The remaining comparator, formula
compilation, pairing, parameter storage, and conservative definitional
extension are established in the manuscript, not claimed as checked here.

No classical principle, propext, funext, choice, sorry, or induction on the
arithmetic carrier is used. The only inductions are on finite term syntax.
