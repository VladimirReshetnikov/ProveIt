/-
PRA from reflexive-base swap induction: constructive core certificate.
Lean 4.19.0. No imports or external packages.

Actual finite syntax has three numerical variables x,y,a and binary function
symbols. Instantiating a term H as H(n,1,a) and H(1,n,a) gives exactly the same
finite term at n=1: this is syntactic equality, with zero computation rewrites.

The arithmetic domain A is arbitrary. Only structural induction on finite
syntax occurs; there is no induction on A and no assumption that A is Nat.
Computation equations for four explicit initialized iterators are supplied.
Other binary symbols are arbitrary interpretations, so the result applies to
every expansion by further well-founded primitive-recursive declarations.

Certified: literal reflexivity of swap boundaries; separation; A(n,1)=Sn;
constructor coverage; successor injectivity and nonzeroness; a selector that
needs no right-zero law; full one-parameter equation induction; subtraction
Shift and addition's right-zero law as consequences; and the converse swap
instance from its ordinary quantifier-free induction instance.

Not formalized here: the full well-founded declaration grammar, a first-order
derivation calculus, the comparator and formula compiler, pairing, or the
conservative definitional-extension theorem. Those have written manuscript
proofs. This certificate verifies the new constructive arithmetic reduction.
-/

namespace ReflexiveBasePRA

universe u

inductive Fn where
  | predecessor
  | addition
  | subtraction
  | gate
  | other (index : Nat)

inductive Term where
  | first
  | second
  | parameter
  | zero
  | succ (argument : Term)
  | app (function : Fn) (left right : Term)

def instantiate : Term → Term → Term → Term → Term
  | .first, x, _, _ => x
  | .second, _, y, _ => y
  | .parameter, _, _, a => a
  | .zero, _, _, _ => .zero
  | .succ t, x, y, a => .succ (instantiate t x y a)
  | .app f s t, x, y, a =>
      .app f (instantiate s x y a) (instantiate t x y a)

def one : Term := .succ .zero
def predTerm (t : Term) : Term := .app .predecessor t .zero
def addTerm (s t : Term) : Term := .app .addition s t
def monusTerm (s t : Term) : Term := .app .subtraction s t
def gateTerm (s t : Term) : Term := .app .gate s t

def selectorTerm (z v w : Term) : Term :=
  predTerm (addTerm (gateTerm z v)
    (.succ (gateTerm (gateTerm z one) w)))

def swapLeft (h : Term) : Term := instantiate h .first one .parameter
def swapRight (h : Term) : Term := instantiate h one .first .parameter
def boundary (t : Term) : Term := instantiate t one .zero .parameter

theorem instantiate_comp (t x y a z w b : Term) :
    instantiate (instantiate t x y a) z w b =
      instantiate t (instantiate x z w b) (instantiate y z w b)
        (instantiate a z w b) := by
  induction t with
  | first => rfl
  | second => rfl
  | parameter => rfl
  | zero => rfl
  | succ t ih => exact congrArg Term.succ ih
  | app f s t ihs iht =>
      have q := congr (congrArg (Term.app f) ihs) iht
      exact q

/-- Every swap instance has a literally identical boundary, without rewriting. -/
theorem boundary_reflexive (h : Term) :
    boundary (swapLeft h) = boundary (swapRight h) := by
  unfold boundary swapLeft swapRight
  rw [instantiate_comp, instantiate_comp]
  rfl

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  function : Fn → A → A → A
  predecessor_zero : ∀ a, function .predecessor zero a = a
  predecessor_succ : ∀ n a, function .predecessor (succ n) a = n
  addition_zero : ∀ a, function .addition zero a = a
  addition_succ : ∀ n a,
    function .addition (succ n) a = succ (function .addition n a)
  subtraction_zero : ∀ a, function .subtraction zero a = a
  subtraction_succ : ∀ n a,
    function .subtraction (succ n) a =
      function .predecessor (function .subtraction n a) zero
  gate_zero : ∀ a, function .gate zero a = a
  gate_succ : ∀ n a, function .gate (succ n) a = zero

def pred {A : Type u} (C : Arithmetic A) (x : A) : A :=
  C.function .predecessor x C.zero
def add {A : Type u} (C : Arithmetic A) : A → A → A := C.function .addition
def monus {A : Type u} (C : Arithmetic A) : A → A → A := C.function .subtraction
def gate {A : Type u} (C : Arithmetic A) : A → A → A := C.function .gate
def select {A : Type u} (C : Arithmetic A) (z v w : A) : A :=
  pred C (add C (gate C z v) (C.succ (gate C (gate C z (C.succ C.zero)) w)))

def eval {A : Type u} (C : Arithmetic A) : Term → A → A → A → A
  | .first, x, _, _ => x
  | .second, _, y, _ => y
  | .parameter, _, _, a => a
  | .zero, _, _, _ => C.zero
  | .succ t, x, y, a => C.succ (eval C t x y a)
  | .app f s t, x, y, a =>
      C.function f (eval C s x y a) (eval C t x y a)

/-- A two-variable term is represented by specializing the y slot to zero. -/
def value {A : Type u} (C : Arithmetic A) (t : Term) (n a : A) : A :=
  eval C t n C.zero a

variable {A : Type u} (C : Arithmetic A)

theorem eval_instantiate (t x y b : Term) (n m a : A) :
    eval C (instantiate t x y b) n m a =
      eval C t (eval C x n m a) (eval C y n m a) (eval C b n m a) := by
  induction t with
  | first => rfl
  | second => rfl
  | parameter => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | app f s t ihs iht =>
      have q := congr (congrArg (C.function f) ihs) iht
      exact q

theorem pred_zero : pred C C.zero = C.zero := C.predecessor_zero C.zero
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.predecessor_succ x C.zero
theorem add_zero (x : A) : add C C.zero x = x := C.addition_zero x
theorem add_succ (x y : A) : add C (C.succ x) y = C.succ (add C x y) :=
  C.addition_succ x y
theorem monus_zero (x : A) : monus C C.zero x = x := C.subtraction_zero x
theorem monus_succ (x y : A) : monus C (C.succ x) y = pred C (monus C x y) :=
  C.subtraction_succ x y
theorem gate_zero (x : A) : gate C C.zero x = x := C.gate_zero x
theorem gate_succ (x y : A) : gate C (C.succ x) y = C.zero := C.gate_succ x y

def Cross (h : Term) (n a : A) : Prop :=
  eval C h n (C.succ C.zero) a = eval C h (C.succ C.zero) n a

def SwapSchema : Prop :=
  ∀ h a, (∀ n, Cross C h n a → Cross C h (C.succ n) a) →
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ Cross C h n a

def additionContext : Term := addTerm .first .second
def coverageContext : Term := addTerm (predTerm .first) .second
def equationContext (s t : Term) : Term :=
  selectorTerm (predTerm .first)
    (instantiate t (predTerm .second) .zero .parameter)
    (instantiate s (predTerm .first) .zero .parameter)

variable (H : SwapSchema C)
include H

theorem separation_and_add_one :
    C.zero ≠ C.succ C.zero ∧ ∀ n, add C n (C.succ C.zero) = C.succ n := by
  have h := H additionContext C.zero (by
    intro n hn
    change add C n (C.succ C.zero) = add C (C.succ C.zero) n at hn
    change add C (C.succ n) (C.succ C.zero) =
      add C (C.succ C.zero) (C.succ n)
    rw [add_succ C, add_succ C, add_zero C]
    rw [add_succ C, add_zero C] at hn
    exact congrArg C.succ hn)
  refine ⟨h.1, ?_⟩
  intro n
  rcases h.2 n with hz | he
  · rw [hz, add_zero C]
  · change add C n (C.succ C.zero) = add C (C.succ C.zero) n at he
    rw [add_succ C, add_zero C] at he
    exact he

theorem add_one (x : A) : add C x (C.succ C.zero) = C.succ x :=
  (separation_and_add_one C H).2 x

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  have h := H coverageContext C.zero (by
    intro n _
    change add C (pred C (C.succ n)) (C.succ C.zero) =
      add C (pred C (C.succ C.zero)) (C.succ n)
    rw [pred_succ C, pred_succ C, add_zero C, add_one C H])
  rcases h.2 x with hz | he
  · exact Or.inl hz
  · change add C (pred C x) (C.succ C.zero) =
      add C (pred C (C.succ C.zero)) x at he
    rw [pred_succ C, add_zero C, add_one C H] at he
    exact Or.inr he.symm

omit H in
theorem successor_injective {x y : A} (h : C.succ x = C.succ y) : x = y := by
  have hp := congrArg (pred C) h
  rw [pred_succ C, pred_succ C] at hp
  exact hp

theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro bad
  have hx := congrArg (pred C) bad
  rw [pred_succ C, pred_zero C] at hx
  have hOne : C.succ C.zero = C.zero := (congrArg C.succ hx).symm.trans bad
  exact (separation_and_add_one C H).1 hOne.symm

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases coverage C H x with hz | hs
  · exact Or.inl hz
  · exact Or.inr (fun hz => successor_ne_zero C H (pred C x) (hs.symm.trans hz))

theorem select_zero (v w : A) : select C C.zero v w = v := by
  unfold select
  rw [gate_zero C, gate_zero C, gate_succ C, add_one C H, pred_succ C]

omit H in
theorem select_succ (z v w : A) : select C (C.succ z) v w = w := by
  unfold select
  rw [gate_succ C, gate_succ C, gate_zero C, add_zero C, pred_succ C]

omit H in
theorem eval_selector (z v w : Term) (x y a : A) :
    eval C (selectorTerm z v w) x y a =
      select C (eval C z x y a) (eval C v x y a) (eval C w x y a) := rfl

omit H in
theorem eval_equation_context (s t : Term) (x y a : A) :
    eval C (equationContext s t) x y a =
      select C (pred C x) (value C t (pred C y) a) (value C s (pred C x) a) := by
  unfold equationContext
  rw [eval_selector C, eval_instantiate C, eval_instantiate C]
  rfl

theorem equation_context_iff (s t : Term) (a : A)
    (base : value C s C.zero a = value C t C.zero a) (n : A) :
    Cross C (equationContext s t) n a ↔
      value C s (pred C n) a = value C t (pred C n) a := by
  unfold Cross
  rw [eval_equation_context C, eval_equation_context C, pred_succ C, select_zero C H]
  rcases coverage C H (pred C n) with hz | hs
  · rw [hz, select_zero C H]
    exact ⟨fun _ => base, fun _ => rfl⟩
  · rw [hs, select_succ C]

theorem equation_induction (s t : Term) (a : A)
    (base : value C s C.zero a = value C t C.zero a)
    (step : ∀ n, value C s n a = value C t n a →
      value C s (C.succ n) a = value C t (C.succ n) a) :
    ∀ n, value C s n a = value C t n a := by
  have hs := H (equationContext s t) a (by
    intro n hn
    have he := (equation_context_iff C H s t a base n).1 hn
    apply (equation_context_iff C H s t a base (C.succ n)).2
    rw [pred_succ C]
    rcases coverage C H n with hz | hnSucc
    · rw [hz]
      exact base
    · rw [hnSucc] at he ⊢
      rw [pred_succ C] at he
      exact step (pred C n) he)
  intro n
  rcases hs.2 (C.succ n) with bad | good
  · exact False.elim (successor_ne_zero C H n bad)
  · have he := (equation_context_iff C H s t a base (C.succ n)).1 good
    rw [pred_succ C] at he
    exact he

theorem addition_right_neutral (x : A) : add C x C.zero = x := by
  have h := equation_induction C H (addTerm .first .zero) .first C.zero (by
    exact add_zero C C.zero) (by
    intro n hn
    change add C n C.zero = n at hn
    change add C (C.succ n) C.zero = C.succ n
    rw [add_succ C, hn])
  exact h x

theorem subtraction_shift (x y : A) :
    monus C (C.succ x) (C.succ y) = monus C x y := by
  have h := equation_induction C H
    (monusTerm (.succ .first) (.succ .parameter)) (monusTerm .first .parameter) y (by
    change monus C (C.succ C.zero) (C.succ y) = monus C C.zero y
    rw [monus_succ C, monus_zero C, pred_succ C, monus_zero C]) (by
    intro n hn
    change monus C (C.succ n) (C.succ y) = monus C n y at hn
    change monus C (C.succ (C.succ n)) (C.succ y) = monus C (C.succ n) y
    calc
      monus C (C.succ (C.succ n)) (C.succ y) =
          pred C (monus C (C.succ n) (C.succ y)) := monus_succ C _ _
      _ = pred C (monus C n y) := congrArg (pred C) hn
      _ = monus C (C.succ n) y := (monus_succ C n y).symm)
  exact h x

theorem identity_induction (s : Term) (a : A)
    (base : value C s C.zero a = C.zero)
    (step : ∀ n, value C s n a = n → value C s (C.succ n) a = C.succ n) :
    ∀ n, value C s n a = n :=
  equation_induction C H s .first a base step

theorem zero_equation_induction (s : Term) (a : A)
    (base : value C s C.zero a = C.zero)
    (step : ∀ n, value C s n a = C.zero → value C s (C.succ n) a = C.zero) :
    ∀ n, value C s n a = C.zero :=
  equation_induction C H s .zero a base step

omit H in
/-- Precisely the ordinary quantifier-free induction instance used in the converse. -/
def GuardedCrossInduction (h : Term) (a : A) : Prop :=
  (C.zero = C.zero ∨ Cross C h C.zero a) →
  (∀ n, (n = C.zero ∨ Cross C h n a) →
    (C.succ n = C.zero ∨ Cross C h (C.succ n) a)) →
  ∀ n, n = C.zero ∨ Cross C h n a

omit H in
theorem reverse_instance (h : Term) (a : A)
    (sep : C.zero ≠ C.succ C.zero)
    (ind : GuardedCrossInduction C h a)
    (step : ∀ n, Cross C h n a → Cross C h (C.succ n) a) :
    C.zero ≠ C.succ C.zero ∧ ∀ n, n = C.zero ∨ Cross C h n a := by
  refine ⟨sep, ind (Or.inl rfl) ?_⟩
  intro n hn
  apply Or.inr
  rcases hn with hz | he
  · rw [hz]
    exact Eq.refl _
  · exact step n he

#print axioms boundary_reflexive
#print axioms eval_instantiate
#print axioms separation_and_add_one
#print axioms coverage
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms zero_decision
#print axioms select_zero
#print axioms select_succ
#print axioms equation_context_iff
#print axioms equation_induction
#print axioms addition_right_neutral
#print axioms subtraction_shift
#print axioms identity_induction
#print axioms zero_equation_induction
#print axioms reverse_instance

end ReflexiveBasePRA
