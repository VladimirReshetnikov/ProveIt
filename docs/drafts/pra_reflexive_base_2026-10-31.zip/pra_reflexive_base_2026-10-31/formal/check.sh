#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
"${LEAN_BIN:-lean}" ReflexiveBasePRA.lean
