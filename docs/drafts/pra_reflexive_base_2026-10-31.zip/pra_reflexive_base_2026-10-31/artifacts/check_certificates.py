#!/usr/bin/env python3
"""Check exact term-syntax certificates and declared formula-size comparisons.

Only Python's standard library is used. This verifies finite syntax,
well-founded iterator descriptions, literal agreement at one, and formula
counts. It is NOT a theorem prover and does not establish full PRA
equivalence. The paper supplies that proof; the Lean file checks its
specified constructive logical kernel.

Run from anywhere:
    python3 artifacts/check_certificates.py --report artifacts/certificates.json
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Term:
    tag: str
    arguments: tuple["Term", ...] = ()
    label: str = ""

    def data(self):
        result = {"tag": self.tag}
        if self.label:
            result["label"] = self.label
        if self.arguments:
            result["arguments"] = [argument.data() for argument in self.arguments]
        return result


def variable(name):
    return Term("variable", label=name)


ZERO = Term("zero")


def successor(term):
    return Term("successor", (term,))


ONE = successor(ZERO)


def iterator(name, counter, seed):
    return Term("iterator", (counter, seed), name)


def replace(term, substitution):
    """Simultaneous capture-free substitution; terms have no binders."""
    if term.tag == "variable":
        return substitution.get(term.label, term)
    return Term(term.tag, tuple(replace(a, substitution) for a in term.arguments),
                term.label)


def free_variables(term):
    if term.tag == "variable":
        return {term.label}
    result = set()
    for argument in term.arguments:
        result.update(free_variables(argument))
    return result


def references(term):
    result = {term.label} if term.tag == "iterator" else set()
    for argument in term.arguments:
        result.update(references(argument))
    return result


def size(term):
    return 1 + sum(size(argument) for argument in term.arguments)


def pretty(term):
    if term.tag == "zero":
        return "0"
    if term.tag == "variable":
        return term.label
    if term.tag == "successor":
        return f"S({pretty(term.arguments[0])})"
    return f"{term.label}({','.join(pretty(a) for a in term.arguments)})"


def pred(term):
    return iterator("P", term, ZERO)


def add(left, right):
    return iterator("A", left, right)


def gate(test, value):
    return iterator("B", test, value)


def monus(counter, seed):
    return iterator("M", counter, seed)


def select(test, if_zero, if_nonzero):
    # C(z,u,v) = p(A(B(z,u), S(B(B(z,1),v)))); all symbols remain binary.
    # Its cases use A(n,1)=S(n), without assuming A(n,0)=n.
    return pred(add(gate(test, if_zero),
                    successor(gate(gate(test, ONE), if_nonzero))))


N, V = variable("n"), variable("v")
DECLARATIONS = (
    ("P", N),
    ("A", successor(V)),
    ("B", ZERO),
    ("M", pred(V)),
)
UPDATES = dict(DECLARATIONS)


def check_declarations():
    earlier = set()
    rows = []
    for name, update in DECLARATIONS:
        assert name not in earlier
        assert free_variables(update) <= {"n", "v"}
        assert references(update) <= earlier
        rows.append({"name": name, "step": pretty(update),
                     "step_ast": update.data(), "earlier_references":
                     sorted(references(update)), "binary": True})
        earlier.add(name)
    return rows


def one_step_reducts(term):
    """All single defining-rule rewrites, including one contextual occurrence."""
    reducts = set()
    if term.tag == "iterator":
        counter, seed = term.arguments
        if counter.tag == "zero":
            reducts.add(seed)
        elif counter.tag == "successor":
            previous = counter.arguments[0]
            reducts.add(replace(UPDATES[term.label], {
                "n": previous, "v": iterator(term.label, previous, seed)}))
    for index, argument in enumerate(term.arguments):
        for reduced in one_step_reducts(argument):
            children = list(term.arguments)
            children[index] = reduced
            reducts.add(Term(term.tag, tuple(children), term.label))
    return reducts


def evaluate(term, environment):
    """Standard-natural interpretation, used for labelled finite sanity checks."""
    if term.tag == "zero":
        return 0
    if term.tag == "variable":
        return environment[term.label]
    if term.tag == "successor":
        return 1 + evaluate(term.arguments[0], environment)
    counter, seed = (evaluate(argument, environment) for argument in term.arguments)
    state = seed
    for step in range(counter):
        state = evaluate(UPDATES[term.label], {"n": step, "v": state})
    return state


def swapped_pair(term):
    return (replace(term, {"x": N, "y": ONE}),
            replace(term, {"x": ONE, "y": N}))


def validate_swap(name, term, role):
    assert free_variables(term) <= {"x", "y", "a"}
    assert references(term) <= set(UPDATES)
    left, right = swapped_pair(term)
    assert free_variables(left) <= {"n", "a"}
    assert free_variables(right) <= {"n", "a"}
    left_at_one = replace(left, {"n": ONE})
    right_at_one = replace(right, {"n": ONE})
    assert left_at_one == right_at_one
    return {"name": name, "role": role, "swap_term": pretty(term),
            "swap_term_ast": term.data(), "left": pretty(left),
            "right": pretty(right), "common_term_at_one": pretty(left_at_one),
            "common_term_ast": left_at_one.data(),
            "left_rewrites": 0, "right_rewrites": 0,
            "literal_agreement": True}


def certificates():
    x, y, a = (variable(name) for name in ("x", "y", "a"))
    # Distinct finite terms with repeated induction-variable occurrences.
    # Their numerical properties are irrelevant to the substitution check.
    s = add(N, add(N, a))
    t = gate(add(N, N), add(a, N))
    s_px = replace(s, {"n": pred(x)})
    t_py = replace(t, {"n": pred(y)})
    examples = (
        ("addition_at_one", add(x, y),
         "Derive A(n,1)=S(n), filling the n=0 case by computation."),
        ("positive_predecessor_coverage", add(pred(x), y),
         "Using A(n,1)=S(n), the equation is S(p(n))=n; no right-zero law is needed."),
        ("arbitrary_equation_induction", select(pred(x), t_py, s_px),
         "Under s(0,a)=t(0,a), the equation is equivalent to s(p(n),a)=t(p(n),a)."),
    )
    rows = [validate_swap(*example) for example in examples]

    duplication_checks = []
    for copies in (1, 2, 4, 8, 16):
        s_family = a
        t_family = ZERO
        for _ in range(copies):
            s_family = add(N, s_family)
            t_family = gate(N, add(a, t_family))
        cross = select(pred(x), replace(t_family, {"n": pred(y)}),
                       replace(s_family, {"n": pred(x)}))
        left, right = swapped_pair(cross)
        assert replace(left, {"n": ONE}) == replace(right, {"n": ONE})
        duplication_checks.append({"copies_per_original_term": copies,
                                   "expanded_cross_term_nodes": size(cross),
                                   "rewrites_required": 0})
    return rows, duplication_checks


@dataclass(frozen=True)
class FormulaNode:
    tag: str
    arguments: tuple["FormulaNode", ...] = ()
    label: str = ""

    def data(self):
        result = {"tag": self.tag}
        if self.label:
            result["label"] = self.label
        if self.arguments:
            result["arguments"] = [argument.data() for argument in self.arguments]
        return result


def ast(tag, *arguments, label=""):
    return FormulaNode(tag, tuple(arguments), label)


def count(tree):
    totals = Counter({tree.tag: 1})
    for argument in tree.arguments:
        totals.update(count(argument))
    return totals


def formula_sizes():
    n = ast("variable", label="n")
    a = ast("variable", label="a")
    zero = ast("constant", label="0")
    succ = lambda term: ast("function", term, label="S")
    one = succ(zero)
    eq = lambda left, right: ast("equality", left, right)
    imp = lambda left, right: ast("implies", left, right)
    conj = lambda left, right: ast("and", left, right)
    disj = lambda left, right: ast("or", left, right)
    all_ = lambda name, body: ast("forall", body, label=name)
    f = lambda term: ast("function", term, a, label="f")
    g = lambda term: ast("function", term, a, label="g")
    e = lambda term: eq(f(term), g(term))
    se = lambda term: eq(f(term), succ(g(term)))
    h = lambda x, y: ast("function", x, y, a, label="H")
    cross_e = lambda term: eq(h(term, one), h(one, term))
    sep = imp(eq(zero, one), ast("bottom"))
    z = lambda term: eq(term, zero)
    conclusion = lambda equation: all_("n", disj(z(n), equation(n)))
    step = lambda equation: all_("n", imp(equation(n), equation(succ(n))))
    guarded_step = lambda equation: all_("n", imp(disj(z(n), equation(n)),
                                                  equation(succ(n))))
    admitted = all_("a", imp(step(e), conj(sep, conclusion(e))))
    cross = all_("a", imp(step(cross_e), conj(sep, conclusion(cross_e))))
    guarded = all_("a", imp(guarded_step(e), conclusion(e)))
    packed_guarded = all_("a", imp(guarded_step(e), conj(sep, conclusion(e))))
    unrestricted_pb = all_("a", imp(conj(e(one), step(e)),
                                     conj(sep, conclusion(e))))
    term_sep = imp(eq(zero, succ(g(zero))), ast("bottom"))
    a_minus = all_("a", imp(guarded_step(se), conj(term_sep, conclusion(se))))
    separated_admitted = all_("a", imp(step(e), conclusion(e)))
    identity_e = lambda term: eq(term, f(term))
    identity_guarded = all_("a", imp(guarded_step(identity_e),
                                    conj(sep, conclusion(identity_e))))
    x = ast("variable", label="x")
    y = ast("variable", label="y")
    m = lambda left, right: ast("function", left, right, label="M")
    shift = all_("x", all_("y", eq(m(succ(x), succ(y)), m(x, y))))
    presentations = {
        "G_plus_Sep": (guarded, sep),
        "K_packed_guarded": (packed_guarded,),
        "PB3_bounded_admission": (admitted,),
        "PB1_bounded_admission": (admitted,),
        "PB0_literal_admission": (admitted,),
        "PB0_plus_separate_Sep": (separated_admitted, sep),
        "cross_term_no_admission": (cross,),
        "PB_unrestricted_explicit_base": (unrestricted_pb,),
        "A_minus": (a_minus,),
        "earlier_identity_guard_T_plus_Shift": (identity_guarded, shift),
    }
    expected = {"G_plus_Sep": 42, "K_packed_guarded": 43,
                "PB3_bounded_admission": 39, "PB1_bounded_admission": 39,
                "PB0_literal_admission": 39, "PB0_plus_separate_Sep": 38,
                "cross_term_no_admission": 51,
                "PB_unrestricted_explicit_base": 49, "A_minus": 48,
                "earlier_identity_guard_T_plus_Shift": 48}
    rows = {}
    for name, formulas in presentations.items():
        total = Counter()
        for formula in formulas:
            total.update(count(formula))
        nodes = sum(total.values())
        assert nodes == expected[name], (name, nodes, expected[name])
        rows[name] = {"nodes": nodes, "equality_occurrences": total["equality"],
                      "arithmetic_templates": len(formulas),
                      "templates_including_computation": len(formulas) + 2,
                      "by_kind": dict(sorted(total.items())),
                      "formulas": [formula.data() for formula in formulas]}
    return {
        "metric": "One node per variable, constant, function application, equality, "
                  "connective, falsehood, or single-variable quantifier occurrence. "
                  "Negation is implication to falsehood; 1 is S(0). Schematic-term "
                  "bodies are excluded, but their displayed arguments are counted. "
                  "One parameter and its universal closure are included. Separate "
                  "axioms are summed without a synthetic conjunction.",
        "limitations": "The common computation templates, term grammar, axiom "
                       "admission recognizer and proof-translation lengths are not "
                       "included. These are not absolute complexity or minimality claims.",
        "rows": rows,
        "observations": [
            "PB0 improves PB3's admission condition, not its displayed formula size.",
            "The one-term cross schema has no admission condition but has a larger "
            "expanded formula: six extra literal arguments 1=S(0) add 12 nodes.",
            "Separating ground nontriviality saves one conjunction node but adds a "
            "displayed arithmetic template.",
        ],
    }


def sanity_checks():
    n, a = N, variable("a")
    equations = (
        ("addition_at_one", add(n, ONE), successor(n)),
        ("addition_seed_successor", add(n, successor(a)), successor(add(n, a))),
        ("addition_right_zero", add(n, ZERO), n),
        ("monus_shift", monus(successor(n), successor(a)), monus(n, a)),
    )
    checked = 0
    for _, left, right in equations:
        for counter in range(13):
            for parameter in range(9):
                env = {"n": counter, "a": parameter}
                assert evaluate(left, env) == evaluate(right, env)
                checked += 1
    for counter in range(13):
        assert counter == 0 or counter == evaluate(successor(pred(n)), {"n": counter})
        checked += 1
    return {"status": "passed", "evaluations_checked": checked,
            "counter_values": "0 through 12", "parameter_values": "0 through 8",
            "scope": "Finite standard-natural sanity checks only; no universal "
                     "mathematical theorem or completeness claim follows from them."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    declarations = check_declarations()
    # Check the one-step implementation independently on each defining form.
    for name, update in DECLARATIONS:
        assert V in one_step_reducts(iterator(name, ZERO, V))
        expected = replace(update, {"n": N, "v": iterator(name, N, V)})
        assert expected in one_step_reducts(iterator(name, successor(N), V))
    rows, duplication = certificates()
    report = {
        "status": "All syntax certificates and declared metric checks passed.",
        "claims_not_checked": ["Full first-order PRA equivalence", "Minimality",
                               "The complete comparator and pairing proofs"],
        "iterator_declarations": declarations,
        "certificates": rows,
        "substituted_term_duplication_checks": duplication,
        "formula_comparison": formula_sizes(),
        "finite_natural_checks": sanity_checks(),
        "source_snapshot": {
            "repository": "https://github.com/VladimirReshetnikov/ProveIt",
            "commit": "cb7be7c1b0b39cc05b1d54a3001e54b1159cc000",
            "baseline_paths": [
                "docs/drafts/pra_positive_base_2026-10-31.zip",
                "docs/drafts/pra_base_free_2026-10-31.zip",
                "docs/drafts/pra_normalized_2026-10-31.zip",
                "docs/drafts/pra_guard_reduction_2026-10-31.zip",
                "docs/drafts/pra_guard_without_base_2026-10-31.zip",
                "docs/drafts/pra_guarded_propagation_2026-10-31.zip",
            ],
            "metric_source": "pra_base_free_2026-10-31/artifacts/schema_metrics.py; "
                             "independently reimplemented above.",
        },
    }
    serialized = json.dumps(report, indent=2, ensure_ascii=True) + "\n"
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(serialized, encoding="utf-8")
        print(f"Passed: {len(rows)} literal certificates, {len(duplication)} duplication "
              f"checks, all declared counts. Wrote {args.report}.")
    else:
        print(serialized, end="")


if __name__ == "__main__":
    main()
