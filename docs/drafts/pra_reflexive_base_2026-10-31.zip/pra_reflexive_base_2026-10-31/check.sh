#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 artifacts/check_certificates.py --report artifacts/certificates.json
sh formal/check.sh
