PRA FROM A REFLEXIVE BASE
31 October 2026
========================

MAIN RESULT

The positive-base PRA schema in the current drafts needs no computation
test at all: literal equality of its two terms after substituting 1 is
enough. An equivalent version uses one arbitrary term H(x,y,a) and the
equation H(n,1,a)=H(1,n,a), whose base at 1 is automatically reflexive.

Both versions use the unchanged initialized binary iterator equations,
one fixed numerical parameter per arithmetic instance, and no separate
successor, coverage, equality-decision, or subtraction-shift axiom.
The same nonlogical basis works in classical and intuitionistic logic.

Two fixed swap instances, followed by a constructed selector context,
recover full equation induction. The paper then gives the complete written
proof of native equality reflection, quantifier-free induction, parameter
coding, and conservative definitional equivalence with ordinary PRA.

FILES

  pra_reflexive_base.pdf     Complete research paper.
  pra_reflexive_base.tex     Self-contained LaTeX source.
  axioms.txt                Exact standalone formal specification.
  source_audit.json          Pinned repository inventory and file hashes.
  comparison.tsv            Comparison under one expanded syntax metric.
  formal/                   Lean 4.19.0 kernel, scope note, check script/log.
  artifacts/                Python syntax/metric checker and its JSON report.
  VALIDATION.txt            Recorded compilation and verification results.
  build.sh                  Rebuild the PDF with latexmk.
  check.sh                  Run syntax and Lean checks.
  lean-toolchain            Exact Lean version.
  SHA256SUMS                Integrity hashes for the delivered contents.

SOURCE BASE

All six archives then in VladimirReshetnikov/ProveIt/docs/drafts were read
at commit cb7be7c1b0b39cc05b1d54a3001e54b1159cc000. The downloaded Git
blob hashes were verified. The docs/incoming listing and index contained
no PRA-labelled archive or PRA entry; unrelated archives were not unpacked.

WHAT IS NEW / WHAT IS INHERITED

New: the zero-rewrite reflexive-base restriction, the unrestricted one-term
swap schema, and the two-fixed-instance bootstrap with an early selector
and direct simulation of arbitrary equation induction.

Inherited and proved again in the paper: initialized binary iteration,
monus reconstruction of native equality, triangular pairing, and storing
passive recursion parameters in the iteration state.

MEASURES

RB has the same 39-node / five-equality arithmetic formula as the current
positive-base draft, but eliminates its three-rewrite admission test.
The one-term swap version uses 51 expanded nodes. A separated RB + ground
0!=1 version uses 38 nodes and one additional displayed template.
No absolute minimum or historical-priority claim is made.

VERIFICATION SCOPE

The Lean certificate uses actual finite term syntax and an arbitrary
arithmetic carrier. It checks the new constructive kernel, equation
induction, and selected consequences; all sixteen printed dependency
checks report no additional Lean axioms. Its computation and swap premises
remain explicit theorem hypotheses. The complete comparator, pairing,
first-order proof calculus, and definitional extension are not claimed
fully machine-checked; they have detailed manuscript proofs.

The Python script validates literal term identity and the stated formula
metrics. Its finite standard-natural checks are only sanity checks and
are explicitly labelled as such.

REBUILD

Requirements: Python 3.10 or later (standard library only), Lean 4.19.0,
and a LaTeX installation with latexmk and the standard packages used by
the source (amsmath, amsthm, mathtools, lmodern, microtype, hyperref, etc.).

From this directory:

  sh build.sh
  sh check.sh

If Lean is not on PATH:

  LEAN_BIN=/absolute/path/to/lean sh check.sh

The build directory is temporary and is not needed to read or verify the
delivered sources. The archive does not include prior draft archives or
unrelated repository files.
