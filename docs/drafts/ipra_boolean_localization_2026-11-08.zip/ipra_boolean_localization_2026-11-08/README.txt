BOOLEAN LOCALIZATION OF iPRA
===========================

Prepared for Vladimir Reshetnikov, 8 November 2026.

MAIN RESULT
The report proves a constructive whole-proof elimination theorem:
if T+ extends the bare closed-update / literal-equation-induction theory
T0 by Boolean zero-test range and the falsity bridge, then every positive
Horn consequence of positive assumptions is already a T0 consequence.
Intermediate implications, disjunctions, and negative temporary
assumptions are unrestricted.

For all ordinary formulas, K(A) = "condition 1 forces A" gives an exact
contextual proof reduction, and K(K(A)) is equivalent to K(A) in T0.
The arithmetic consequence is that closed unary initialized iteration
already gives the full primitive-recursive equational algebra without
Boolean range, coverage, or the falsity bridge.

The completed ordinary theory T+ is explicitly specified and proved
whole-domain bi-interpretable and equiconsistent with full iPRA.
Both interpretation composites have graph x=y.

CLAIM BOUNDARY
The requested strict complete-checker complexity improvement is NOT
established. The numerical comparison envelope reproduced from preserved
historical programs is 317 normalized tokens, 348 AST nodes, and 885
normalized bytes, with different attainers. These are finite measurements,
not universal lower bounds.

Raw T0 is not asserted to be ordinarily bi-interpretable with full iPRA.
The forcing reduction changes logical connectives. The code translates
formulas and runs finite diagnostics; it is neither a full iPRA checker
nor a formal proof verification of the metatheory.

CONTENTS
report.pdf                 Complete compiled research report.
report.tex                 Main TeX source.
sections/                  Full theory, proofs, equivalence, boundaries.
appendices/                Explicit bare closed-update arithmetic proof.
code/                      Hygienic translator and diagnostic tools.
evidence/                  Actual validation results and formula examples.
sources/current_snapshot.json
                           Six pinned source archives and verified hashes.
sources/baselines/         Twelve preserved complete comparison sources.
ATTRIBUTION.txt             Inherited/new material and claim boundaries.
LICENSE.txt                MIT No Attribution license.
SHA256SUMS.txt              Hashes of packaged files.

REPRODUCTION
Python 3.10+ and standard library:
  python3 reproduce.py

Standard TeX installation with pdfLaTeX:
  python3 build.py

Create a deterministic ZIP:
  python3 make_archive.py

The source repository is pinned to:
https://github.com/VladimirReshetnikov/ProveIt/tree/9773e5e0376fdaf953567d0e1e6f19570d566bc6/docs/drafts

The PDF contains a Further research questions section.
