"""Bounded diagnostics for the closed arithmetic terms, not a proof checker.

The literal AST definitions in inherited_closed_terms.py are reproduced
unchanged from the supplied ipra_closed_updates_2026-11-08.zip (z2),
artifacts/closed_terms.py, at ProveIt commit
9773e5e0376fdaf953567d0e1e6f19570d566bc6.
The new report strengthens the proof's assumptions, not these term values.
"""

import json
import inherited_closed_terms as terms


def iterate(update, count, initial):
    for _ in range(count):
        initial = update(initial)
    return initial


def transition(value):
    if value % 3:
        return value + 3
    return 3 * (value // 2) if value % 2 == 0 else 1


def collapse(value):
    return value if value % 3 else 3 * value


def ramp(count):
    return iterate(lambda value: value + 1 + int(value % 4 == 2), count, 0)


def orbit(count):
    return iterate(transition, ramp(count), 3 * 2 ** count)


def predecessor(count):
    state = orbit(count)
    return int(count % 3 == 2) if state % 3 == 0 else state + count % 3 + 1


def halver(value):
    return value if value % 2 else value // 2


def tagged_halver(value):
    if value % 2:
        return value + 2
    half = value // 2
    return 1 if half % 2 else 2 * (half // 2)


def main():
    audit = terms.audit()
    malformed_rejected = 0
    for bad in (terms.var(1), ("iter", "not_an_earlier_update", terms.zero(), terms.zero())):
        try:
            terms.validate(bad, 1, set(terms.UPDATES))
        except ValueError:
            malformed_rejected += 1
    assert malformed_rejected == 2

    literal_values = []
    for n in range(9):
        value = terms.evaluate(terms.P(terms.numeral(n)))
        assert value == max(0, n - 1)
        literal_values.append({"n": n, "P(n)": value})

    counts = {key: 0 for key in ("commutation", "diagonal_shift", "predecessor",
                                "ramp", "readout", "pairing")}
    for value in range(500):
        assert transition(collapse(value)) == collapse(transition(value))
        counts["commutation"] += 1
    for n in range(25):
        for t in range(30):
            lhs = iterate(transition, t + 1, 3 * 2 ** (n + 1))
            rhs = collapse(iterate(transition, t, 3 * 2 ** n))
            assert lhs == rhs
            counts["diagonal_shift"] += 1
    for n in range(121):
        assert predecessor(n) == max(0, n - 1)
        counts["predecessor"] += 1
        assert ramp(n + 3) == ramp(n) + 4
        counts["ramp"] += 1
        value = orbit(n + 3)
        assert value % 3 == 1 and value + n % 3 == n + 1
        counts["readout"] += 1
    for x in range(7):
        for y in range(9):
            code = iterate(lambda value: value * 2, x, 2 * y + 1)
            projection1 = iterate(halver, code, code) // 2
            projection0 = max(0, code - iterate(tagged_halver, code + 1, 2 * code) // 2)
            assert (projection0, projection1) == (x, y)
            counts["pairing"] += 1

    print(json.dumps({
        "status": "PASS",
        "scope": "Finite syntax and numerical diagnostics; not formal proofs or a checker-size result",
        "closed_update_count": len(audit),
        "closed_update_audit": audit,
        "malformed_definitions_rejected": malformed_rejected,
        "literal_predecessor_evaluations": literal_values,
        "accelerated_reference_checks": counts,
        "reference_acceleration": "Uses ordinary modulo, division, powers, and monus to accelerate previously derived unary subterms",
    }, indent=2))


if __name__ == "__main__":
    main()
