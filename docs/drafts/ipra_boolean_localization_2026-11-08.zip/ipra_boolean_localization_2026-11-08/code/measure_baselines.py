"""Reproduce the inherited complete-program comparison, without candidate golfing."""
import json
import platform
from pathlib import Path
from inherited_source_measure import metrics

ROOT = Path(__file__).resolve().parent.parent
LABELS = {
    "ipra_boolean_core_2026-11-08__checker.py": "Boolean core",
    "ipra_boxed_witnesses_2026-11-08__checker.py": "Boxed witnesses",
    "ipra_boxed_witnesses_2026-11-08__checker_compatible.py": "Boxed: compatible",
    "ipra_clausal_kernel_2026-11-08__checker.py": "Clausal kernel",
    "ipra_context_blocks_2026-11-08__checker.py": "Context blocks",
    "ipra_context_pairs_2026-11-08__checker.py": "Context pairs",
    "ipra_context_pairs_2026-11-08__checker_exact_list.py": "Context pairs: exact list",
    "ipra_fixed_contexts_2026-11-08__checker.py": "Fixed contexts",
    "ipra_kernel_2026-11-08__checker.py": "Initializer: byte profile",
    "ipra_kernel_2026-11-08__checker_structural.py": "Initializer: structural",
    "ipra_normalized_elimination_2026-11-08__checker.py": "Normalized elimination",
    "ipra_normalized_elimination_2026-11-08__checker_readable.py": "Normalized: readable",
}

def main():
    paths = sorted((ROOT / "sources" / "baselines").glob("*.py"))
    if len(paths) != 12 or set(p.name for p in paths) != set(LABELS):
        raise ValueError("Historical comparison inventory changed.")
    rows = [{"file": str(p.relative_to(ROOT)), "label": LABELS[p.name],
             **metrics(p)} for p in paths]
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    minimum = {k: min(r[k] for r in rows) for k in fields}
    result = {
        "python": platform.python_version(),
        "scope": "Whole preserved historical programs, not newly certified checkers.",
        "source_archive": "ipra_closed_updates_2026-11-08(1).zip",
        "source_commit": "9773e5e0376fdaf953567d0e1e6f19570d566bc6",
        "program_count": len(rows),
        "coordinatewise_minimum": minimum,
        "minimum_attainers": {
            k: [r["label"] for r in rows if r[k] == minimum[k]]
            for k in fields
        },
        "programs": rows,
    }
    out = ROOT / "evidence"
    out.mkdir(exist_ok=True)
    (out / "baseline_metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    table = [
        r"\begin{tabular}{@{}lrrr@{}}",
        r"\toprule",
        r"Preserved complete program & Tokens & AST & Bytes\\",
        r"\midrule",
    ]
    for r in rows:
        table.append(r["label"] + " & " + " & ".join(str(r[k]) for k in fields) + r"\\")
    table += [
        r"\midrule",
        "Coordinate envelope & " + " & ".join(str(minimum[k]) for k in fields) + r"\\",
        r"\bottomrule",
        r"\end{tabular}",
    ]
    (out / "checker_table.tex").write_text("\n".join(table) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "programs"}, indent=2))

if __name__ == "__main__":
    main()
