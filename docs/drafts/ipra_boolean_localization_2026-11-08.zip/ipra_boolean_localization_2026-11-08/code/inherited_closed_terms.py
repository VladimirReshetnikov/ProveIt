"""Closed-update arithmetic definitions and a literal finite-term evaluator.

This is a syntax audit and evaluator, not an iPRA proof checker.  An iterator
index names a previously registered closed unary term.  Named definitions
are finite abbreviations, not numerical program arguments or a universal
evaluator inside the proposed theory.
"""
from functools import lru_cache

UPDATES = {}

def var(i):
    return ('var', i)

def zero():
    return ('zero',)

def succ(t):
    return ('succ', t)

def numeral(n):
    t = zero()
    for _ in range(n):
        t = succ(t)
    return t

def it(name, n, a):
    if name not in UPDATES:
        raise ValueError('An update must be introduced at an earlier stage')
    return ('iter', name, n, a)

def validate(t, arity, previous):
    tag = t[0]
    if tag == 'zero' and len(t) == 1:
        return
    if tag == 'var' and len(t) == 2 and type(t[1]) is int and 0 <= t[1] < arity:
        return
    if tag == 'succ' and len(t) == 2:
        validate(t[1], arity, previous)
        return
    if tag == 'iter' and len(t) == 4 and t[1] in previous:
        validate(t[2], arity, previous)
        validate(t[3], arity, previous)
        return
    raise ValueError('Ill-formed or nonclosed term: ' + repr(t))

def register(name, body):
    if name in UPDATES:
        raise ValueError('Duplicate update')
    validate(body, 1, set(UPDATES))
    UPDATES[name] = body

u = var(0)
register('zero', zero())
register('succ', succ(u))

def add(a, b):
    return it('succ', b, a)

def twice(a):
    return add(a, a)

def thrice(a):
    return add(twice(a), a)

def Z(n):
    return it('zero', n, numeral(1))

def C(n, a, b):
    return add(it('zero', n, a), it('zero', Z(n), b))

register('zero_test', Z(u))

def N(n):
    return it('zero_test', n, zero())

def j(n):
    return add(Z(n), twice(N(n)))

register('cycle3', j(u))

def M(n):
    return it('cycle3', n, zero())

register('ramp3_step', succ(add(u, M(u))))

def G(n):
    return it('ramp3_step', n, zero())

def H(n):
    return C(N(n), G(n), n)

register('factor', H(u))
register('double', twice(u))

def E(n):
    return it('double', n, numeral(1))

register('cycle4', C(M(u), Z(N(u)), succ(u)))

def M4(n):
    return it('cycle4', n, zero())

def e(n):
    return Z(j(n))

register('ramp4_step', succ(add(u, e(M4(u)))))

def R(n):
    return it('ramp4_step', n, zero())

def T(n):
    return C(M(n), C(N(n), H(n), numeral(1)), add(n, numeral(3)))

def K(n):
    return C(M(n), thrice(n), n)

register('transient_counter', T(u))

def V(t, n):
    return it('transient_counter', t, thrice(E(n)))

def A(n):
    return V(R(n), n)

def P(n):
    return C(M(A(n)), e(M(n)), succ(add(A(n), M(n))))

register('predecessor', P(u))

def monus(a, b):
    return it('predecessor', b, a)

def half(n):
    return monus(G(n), n)

def pair(x, y):
    return it('double', x, succ(twice(y)))

register('halver', C(N(u), half(u), u))
register('tagged_halver', C(N(u), C(N(half(u)), twice(half(half(u))), numeral(1)), add(u, numeral(2))))

def pi1(z):
    return half(it('halver', z, z))

def pi0(z):
    return monus(z, half(it('tagged_halver', succ(z), twice(z))))

@lru_cache(maxsize=None)
def update(name, value):
    return evaluate(UPDATES[name], (value,))

def evaluate(t, values=()):
    tag = t[0]
    if tag == 'zero':
        return 0
    if tag == 'var':
        return values[t[1]]
    if tag == 'succ':
        return evaluate(t[1], values) + 1
    if tag == 'iter':
        name, n, a = t[1:]
        count = evaluate(n, values)
        value = evaluate(a, values)
        for _ in range(count):
            value = update(name, value)
        return value
    raise ValueError('Invalid term')

def node_count(t):
    if t[0] in ('zero', 'var'):
        return 1
    if t[0] == 'succ':
        return 1 + node_count(t[1])
    return 1 + node_count(t[2]) + node_count(t[3])

def free_variables(t):
    if t[0] == 'var':
        return {t[1]}
    if t[0] == 'zero':
        return set()
    if t[0] == 'succ':
        return free_variables(t[1])
    return free_variables(t[2]) | free_variables(t[3])

def audit():
    previous = set()
    result = []
    for name, body in UPDATES.items():
        validate(body, 1, previous)
        result.append({'update': name, 'stage': len(previous), 'body_nodes': node_count(body),
                       'free_variables': sorted(free_variables(body)), 'closed_unary': True})
        previous.add(name)
    return result
