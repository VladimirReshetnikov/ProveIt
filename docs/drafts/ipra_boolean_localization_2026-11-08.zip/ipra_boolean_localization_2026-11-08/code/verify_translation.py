#!/usr/bin/env python3
"""Checks capture avoidance and syntactic invariants of the translator.

These are tests of a formula transformation, not a proof of the forcing
metatheory.  Numerical product semantics are tested in the separate
verify_boolean_forcing.py artifact.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from forcing_translation import (
    And, App, Bottom, Eq, Exists, Forall, Implies, ONE, Or, Var, ZERO,
    all_variables, example_formulas, forcing, free_variables, project,
    substitute, term_variables, to_json, translate, walk_formulas,
)


def alpha_key(formula):
    """Independent bound-variable comparison, using relative binder indices."""
    def term_key(term, bound):
        if isinstance(term, Var):
            for depth, name in enumerate(reversed(bound)):
                if term.name == name:
                    return ("bound", depth)
            return ("free", term.name)
        return ("app", term.symbol, tuple(term_key(t, bound) for t in term.args))

    def visit(node, bound):
        if isinstance(node, Eq):
            return ("eq", term_key(node.left, bound), term_key(node.right, bound))
        if isinstance(node, Bottom):
            return ("bottom",)
        if isinstance(node, (And, Or, Implies)):
            return (type(node).__name__, visit(node.left, bound),
                    visit(node.right, bound))
        return (type(node).__name__, visit(node.body, bound + (node.variable,)))

    return visit(formula, ())


def source_corpus():
    x, y, p, q = (Var(name) for name in ("x", "y", "p", "q"))
    seeds = [Eq(x, y), Eq(p, ZERO), Eq(q, ONE), Bottom(), Eq(ZERO, ZERO)]
    formulas = list(seeds)
    for i, a in enumerate(seeds):
        b = seeds[(i + 1) % len(seeds)]
        formulas.extend([And(a, b), Or(a, b), Implies(a, b),
                         Forall("x", a), Exists("p", b),
                         Forall("x", Exists("x", Or(a, b))),
                         Implies(Exists("q", Or(a, b)), Forall("p", b))])
    adversarial_names = ["p", "q", "r", "_forcing_q_0", "_forcing_r_1",
                         "_forcing_bound_0", "_forcing_q_2"]
    for name in adversarial_names:
        v = Var(name)
        formulas.append(Forall(name, Or(
            Eq(v, Var("_forcing_q_0")),
            Exists("q", Implies(Eq(Var("q"), v),
                                 Eq(Var("r"), Var("_forcing_r_1")))),
        )))
    formulas.extend(example_formulas().values())
    return formulas


def verify():
    checks = []

    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        checks.append(name)

    x, y = Var("x"), Var("y")
    # A condition's x must remain free under a source binder also called x.
    source = Forall("x", Eq(x, y))
    actual = forcing(source, x)
    expected = Forall("w", Eq(project(x, Var("w")), project(x, y)))
    check("condition variable is not captured by source universal",
          alpha_key(actual) == alpha_key(expected))
    check("condition variable remains free", free_variables(actual) == {"x", "y"})

    source = Exists("x", Forall("x", Eq(x, y)))
    expected = Exists("a", Forall("b", Eq(project(x, Var("b")), project(x, y))))
    check("nested source shadowing is alpha-renamed correctly",
          alpha_key(forcing(source, x)) == alpha_key(expected))

    # Substitution must not capture the free y introduced for x.
    actual = substitute(Forall("y", Eq(x, y)), "x", y)
    expected = Forall("fresh", Eq(y, Var("fresh")))
    check("capture-avoiding substitution", alpha_key(actual) == alpha_key(expected))
    check("substitution preserves bound shadowing",
          substitute(Forall("x", Eq(x, y)), "x", ZERO) == Forall("x", Eq(x, y)))

    # Renaming an input binder does not change the translated formula modulo alpha.
    left = Forall("x", Or(Eq(x, y), Exists("y", Eq(x, y))))
    right = Forall("z", Or(Eq(Var("z"), y), Exists("y", Eq(Var("z"), y))))
    check("translation respects alpha-equivalent input",
          alpha_key(translate(left)) == alpha_key(translate(right)))
    check("condition capture avoidance respects alpha-equivalent input",
          alpha_key(forcing(left, x)) == alpha_key(forcing(right, x)))

    corpus = source_corpus()
    conditions = [ONE, Var("p"), Var("x"), Var("_forcing_q_0"),
                  App("C", (Var("p"), ZERO, Var("q")))]
    cases = 0
    for index, source in enumerate(corpus):
        top = translate(source)
        check(f"top free variables {index}", free_variables(top) == free_variables(source))
        for j, condition in enumerate(conditions):
            target = forcing(source, condition)
            cases += 1
            check(f"free variables {index}/{j}",
                  free_variables(target) == free_variables(source) | term_variables(condition))
            check(f"no target disjunction or falsity {index}/{j}",
                  all(not isinstance(n, (Or, Bottom)) for n in walk_formulas(target)))
        if isinstance(source, Eq):
            check(f"literal-equation induction matrix preserved {index}",
                  isinstance(forcing(source, Var("p")), Eq))

    # Explicit constructor behavior matters for preserving induction and quantifiers.
    identity = Forall("x", Exists("y", Eq(y, x)))
    p = Var("p")
    expected = Forall("x", Exists("y", Eq(project(p, y), project(p, x))))
    check("universal-existential structure commutes",
          alpha_key(forcing(identity, p)) == alpha_key(expected))
    check("falsity has zero-condition translation", forcing(Bottom(), p) == Eq(p, ZERO))
    check("source AST remains immutable", source_corpus() == corpus)

    examples = {}
    for name, formula in example_formulas().items():
        examples[name] = {
            "source": to_json(formula),
            "translation_at_one": to_json(translate(formula)),
            "source_free_variables": sorted(free_variables(formula)),
            "target_free_variables": sorted(free_variables(translate(formula))),
        }
    capture_example = Forall("x", Eq(Var("x"), Var("y")))
    examples["condition_capture_avoidance"] = {
        "source": to_json(capture_example), "condition": to_json(Var("x")),
        "translation": to_json(forcing(capture_example, Var("x"))),
        "target_free_variables": sorted(free_variables(forcing(capture_example, Var("x")))),
    }
    result = {
        "status": "pass",
        "scope": "Syntax and hygiene checks only; not a proof checker or metatheory formalization.",
        "source_formula_count": len(corpus),
        "condition_count": len(conditions),
        "condition_translation_cases": cases,
        "assertion_count": len(checks),
        "features": ["all source logical constructors", "named-variable shadowing",
                     "adversarial generated-name collisions", "compound condition terms",
                     "alpha-equivalence", "free-variable preservation",
                     "literal-equation preservation", "target has no Or or Bottom nodes"],
    }
    return result, examples


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path,
                        default=Path(__file__).resolve().parent / "results")
    arguments = parser.parse_args()
    result, examples = verify()
    arguments.output_dir.mkdir(parents=True, exist_ok=True)
    (arguments.output_dir / "translation_validation.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    (arguments.output_dir / "translation_examples.json").write_text(
        json.dumps(examples, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
