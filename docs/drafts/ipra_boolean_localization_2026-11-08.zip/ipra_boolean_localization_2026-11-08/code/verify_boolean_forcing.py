"""Finite diagnostics for the constructive Boolean-forcing translation.

This checks the displayed forcing clauses on a finite product algebra. It
is NOT a proof checker for iPRA and does NOT test arithmetic induction.
The finite carrier uses modular successor/addition solely to remain closed.
The theoretical report, not these finite tests, establishes conservativity.
No third-party dependencies are required.
"""

from functools import lru_cache
from itertools import product
import json


DIMENSION = 2
BASE_SIZE = 3
BASE = tuple(range(BASE_SIZE))
DOMAIN = tuple(product(BASE, repeat=DIMENSION))
CONDITIONS = tuple(range(1 << DIMENSION))
TOP = CONDITIONS[-1]
ZERO = (0,) * DIMENSION
ONE = (1,) * DIMENSION


def var(index):
    return ("var", index)


def const(value):
    return ("const", value)


def eq(left, right):
    return ("eq", left, right)


def binary(tag, left, right):
    return (tag, left, right)


def bind(tag, index, matrix):
    return (tag, index, matrix)


def replace(env, index, value):
    return env[:index] + (value,) + env[index + 1:]


def scalar_term(term, env):
    tag, *args = term
    if tag == "var":
        return env[args[0]]
    if tag == "const":
        return args[0]
    if tag == "succ":
        return (scalar_term(args[0], env) + 1) % BASE_SIZE
    if tag == "add":
        return sum(scalar_term(arg, env) for arg in args) % BASE_SIZE
    raise ValueError(term)


def vector_term(term, env):
    return tuple(
        scalar_term(term, tuple(value[i] for value in env))
        for i in range(DIMENSION)
    )


def restrict(condition, value):
    return tuple(value[i] if condition & (1 << i) else 0
                 for i in range(DIMENSION))


def mix(condition, first, second):
    """C(condition, first, second): second on the support of condition."""
    return tuple(second[i] if condition & (1 << i) else first[i]
                 for i in range(DIMENSION))


def below(smaller, larger):
    return smaller & larger == smaller


@lru_cache(maxsize=None)
def scalar_truth(formula, env):
    tag, *args = formula
    if tag == "eq":
        return scalar_term(args[0], env) == scalar_term(args[1], env)
    if tag == "bottom":
        return False
    if tag == "and":
        return scalar_truth(args[0], env) and scalar_truth(args[1], env)
    if tag == "or":
        return scalar_truth(args[0], env) or scalar_truth(args[1], env)
    if tag == "implies":
        return not scalar_truth(args[0], env) or scalar_truth(args[1], env)
    if tag in ("forall", "exists"):
        values = (scalar_truth(args[1], replace(env, args[0], value))
                  for value in BASE)
        return all(values) if tag == "forall" else any(values)
    raise ValueError(formula)


@lru_cache(maxsize=None)
def product_truth(formula, env):
    """Ordinary classical truth in the finite coordinatewise product."""
    tag, *args = formula
    if tag == "eq":
        return vector_term(args[0], env) == vector_term(args[1], env)
    if tag == "bottom":
        return False
    if tag == "and":
        return product_truth(args[0], env) and product_truth(args[1], env)
    if tag == "or":
        return product_truth(args[0], env) or product_truth(args[1], env)
    if tag == "implies":
        return not product_truth(args[0], env) or product_truth(args[1], env)
    if tag in ("forall", "exists"):
        values = (product_truth(args[1], replace(env, args[0], value))
                  for value in DOMAIN)
        return all(values) if tag == "forall" else any(values)
    raise ValueError(formula)


@lru_cache(maxsize=None)
def forces(condition, formula, env):
    """The report's recursive forcing clauses, with all finite conditions."""
    tag, *args = formula
    if tag == "eq":
        return (restrict(condition, vector_term(args[0], env))
                == restrict(condition, vector_term(args[1], env)))
    if tag == "bottom":
        return condition == 0
    if tag == "and":
        return forces(condition, args[0], env) and forces(condition, args[1], env)
    if tag == "or":
        return any(q | r == condition and forces(q, args[0], env)
                   and forces(r, args[1], env)
                   for q in CONDITIONS for r in CONDITIONS)
    if tag == "implies":
        return all(not below(q, condition) or not forces(q, args[0], env)
                   or forces(q, args[1], env) for q in CONDITIONS)
    if tag in ("forall", "exists"):
        values = (forces(condition, args[1], replace(env, args[0], value))
                  for value in DOMAIN)
        return all(values) if tag == "forall" else any(values)
    raise ValueError(formula)


def support_truth(condition, formula, env):
    return all(not condition & (1 << i)
               or scalar_truth(formula, tuple(value[i] for value in env))
               for i in range(DIMENSION))


def main():
    x, y, z = map(var, range(3))
    zero, one = const(0), const(1)
    a, b, c = eq(x, zero), eq(x, one), eq(x, y)
    bottom = ("bottom",)
    conjunction = lambda left, right: binary("and", left, right)
    disjunction = lambda left, right: binary("or", left, right)
    implication = lambda left, right: binary("implies", left, right)
    exists = lambda matrix: bind("exists", 2, matrix)
    forall = lambda matrix: bind("forall", 2, matrix)
    positive_horn = (
        a, c, conjunction(a, c),
        exists(eq(z, x)),
        exists(conjunction(eq(z, x), eq(z, y))),
        forall(eq(("add", x, z), ("add", z, x))),
        bind("forall", 0, bind("exists", 1, eq(y, ("succ", x)))),
        bind("exists", 0, bind("forall", 1, eq(x, y))),
    )
    positive = positive_horn + (
        bottom, disjunction(a, b),
        exists(disjunction(eq(z, x), eq(z, y))),
        forall(disjunction(eq(z, zero), eq(z, one))),
        conjunction(disjunction(a, b), exists(eq(z, y))),
    )
    formulas = positive + (
        implication(a, b), implication(a, bottom),
        implication(disjunction(a, b), c),
        implication(c, exists(conjunction(eq(z, x), eq(z, y)))),
        forall(implication(eq(z, x), eq(z, y))),
        implication(forall(eq(z, x)), exists(eq(z, y))),
        exists(implication(eq(z, x), eq(z, y))),
        implication(implication(a, bottom), a),
    )
    counts = {key: 0 for key in (
        "support_equivalences", "zero_conditions", "restrictions",
        "locality", "substitutivity", "positive_liftings",
        "positive_horn_reflections", "mixing_identities", "completion_axioms",
    )}

    for first, second in product(DOMAIN, repeat=2):
        for condition in CONDITIONS:
            witness = mix(condition, second, first)
            assert restrict(condition, witness) == restrict(condition, first)
            complement = TOP ^ condition
            assert restrict(complement, witness) == restrict(complement, second)
            counts["mixing_identities"] += 2

    for xv, yv in product(DOMAIN, repeat=2):
        env = (xv, yv, ZERO)
        for formula in formulas:
            values = {p: forces(p, formula, env) for p in CONDITIONS}
            assert values[0]
            counts["zero_conditions"] += 1
            for p in CONDITIONS:
                assert values[p] == support_truth(p, formula, env)
                counts["support_equivalences"] += 1
                for q in CONDITIONS:
                    if below(q, p):
                        assert not values[p] or values[q]
                        counts["restrictions"] += 1
                    assert not (values[p] and values[q]) or values[p | q]
                    counts["locality"] += 1
                for replacement in DOMAIN:
                    if restrict(p, replacement) == restrict(p, xv):
                        assert values[p] == forces(p, formula, replace(env, 0, replacement))
                        counts["substitutivity"] += 1
        for formula in positive:
            for p in CONDITIONS:
                assert not product_truth(formula, env) or forces(p, formula, env)
                counts["positive_liftings"] += 1
        for formula in positive_horn:
            assert forces(TOP, formula, env) == product_truth(formula, env)
            counts["positive_horn_reflections"] += 1

    boolean_range = disjunction(a, b)
    bridge = implication(eq(zero, one), bottom)
    for bits in product((0, 1), repeat=DIMENSION):
        env = (bits, ZERO, ZERO)
        for p in CONDITIONS:
            assert forces(p, boolean_range, env)
            assert forces(p, bridge, env)
            counts["completion_axioms"] += 2

    mixed = (0, 1)
    mixed_env = (mixed, ZERO, ZERO)
    assert not product_truth(boolean_range, mixed_env)
    assert forces(TOP, boolean_range, mixed_env)
    negative_context = conjunction(implication(a, bottom), implication(b, bottom))
    assert product_truth(negative_context, mixed_env)
    assert not forces(TOP, negative_context, mixed_env)

    result = {
        "status": "PASS",
        "scope": "Finite Boolean-product diagnostics; not a proof of conservativity or induction",
        "dimension": DIMENSION,
        "base_size": BASE_SIZE,
        "product_elements": len(DOMAIN),
        "conditions": len(CONDITIONS),
        "formula_fixtures": len(formulas),
        "checks": counts,
        "boundary_examples": {
            "mixed_element": mixed,
            "boolean_range_ordinary_truth": False,
            "boolean_range_forced_at_top": True,
            "negative_context_ordinary_truth": True,
            "negative_context_forced_at_top": False,
        },
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
