#!/usr/bin/env python3
"""Hygienic syntax translation for the Boolean-forcing reduction.

This module implements only a finite formula transformation.  It is not a
proof checker, an arithmetic evaluator, or a formal verification of the
conservativity theorem.  Function symbols denote fixed first-order symbols;
``C`` and ``Z`` are the report's defined scalar terms.

The condition translation is written ``forcing(A, p)``.  Its intended use
assumes B(p)=p.  ``translate(A)`` is the top-condition translation K(A).
Generated condition variables avoid every variable name in the source.
Source binders are alpha-renamed whenever necessary to avoid capturing a
free variable of an explicitly supplied condition term.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class App:
    symbol: str
    args: tuple[Term, ...] = ()


Term = Union[Var, App]


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bottom:
    pass


@dataclass(frozen=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Or:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Implies:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Forall:
    variable: str
    body: Formula


@dataclass(frozen=True)
class Exists:
    variable: str
    body: Formula


Formula = Union[Eq, Bottom, And, Or, Implies, Forall, Exists]
ZERO = App("0")
ONE = App("S", (ZERO,))


def term_variables(term: Term) -> set[str]:
    if isinstance(term, Var):
        return {term.name}
    if isinstance(term, App):
        return set().union(*(term_variables(t) for t in term.args))
    raise TypeError(f"Unknown term type: {type(term).__name__}")


def free_variables(formula: Formula) -> set[str]:
    if isinstance(formula, Eq):
        return term_variables(formula.left) | term_variables(formula.right)
    if isinstance(formula, Bottom):
        return set()
    if isinstance(formula, (And, Or, Implies)):
        return free_variables(formula.left) | free_variables(formula.right)
    if isinstance(formula, (Forall, Exists)):
        return free_variables(formula.body) - {formula.variable}
    raise TypeError(f"Unknown formula type: {type(formula).__name__}")


def all_variables(formula: Formula) -> set[str]:
    if isinstance(formula, (Eq, Bottom)):
        return free_variables(formula)
    if isinstance(formula, (And, Or, Implies)):
        return all_variables(formula.left) | all_variables(formula.right)
    if isinstance(formula, (Forall, Exists)):
        return all_variables(formula.body) | {formula.variable}
    raise TypeError(f"Unknown formula type: {type(formula).__name__}")


class FreshNames:
    """Deterministic, globally fresh names within one translation."""

    def __init__(self, forbidden: set[str]):
        self.used = set(forbidden)
        self.counter = 0

    def get(self, hint: str) -> str:
        while True:
            candidate = f"_forcing_{hint}_{self.counter}"
            self.counter += 1
            if candidate not in self.used:
                self.used.add(candidate)
                return candidate


def substitute_term(term: Term, variable: str, replacement: Term) -> Term:
    if isinstance(term, Var):
        return replacement if term.name == variable else term
    if isinstance(term, App):
        return App(term.symbol, tuple(
            substitute_term(t, variable, replacement) for t in term.args
        ))
    raise TypeError(f"Unknown term type: {type(term).__name__}")


def substitute(
    formula: Formula,
    variable: str,
    replacement: Term,
    fresh: FreshNames | None = None,
) -> Formula:
    """Capture-avoiding substitution for free occurrences of a variable."""
    if fresh is None:
        fresh = FreshNames(all_variables(formula) | term_variables(replacement)
                           | {variable})
    else:
        fresh.used.update(all_variables(formula) | term_variables(replacement)
                          | {variable})
    if isinstance(formula, Eq):
        return Eq(substitute_term(formula.left, variable, replacement),
                  substitute_term(formula.right, variable, replacement))
    if isinstance(formula, Bottom):
        return formula
    if isinstance(formula, (And, Or, Implies)):
        return type(formula)(substitute(formula.left, variable, replacement, fresh),
                             substitute(formula.right, variable, replacement, fresh))
    if isinstance(formula, (Forall, Exists)):
        bound, body = formula.variable, formula.body
        if bound == variable:
            return formula
        if bound in term_variables(replacement):
            new_bound = fresh.get("bound")
            body = substitute(body, bound, Var(new_bound), fresh)
            bound = new_bound
        return type(formula)(bound, substitute(body, variable, replacement, fresh))
    raise TypeError(f"Unknown formula type: {type(formula).__name__}")


def select(condition: Term, zero_value: Term, one_value: Term) -> Term:
    return App("C", (condition, zero_value, one_value))


def zero_test(term: Term) -> Term:
    return App("Z", (term,))


def boolean(condition: Term) -> Formula:
    return Eq(zero_test(zero_test(condition)), condition)


def meet(left: Term, right: Term) -> Term:
    return select(left, ZERO, right)


def join(left: Term, right: Term) -> Term:
    return select(left, right, ONE)


def below(left: Term, right: Term) -> Formula:
    return Eq(meet(left, right), left)


def project(condition: Term, value: Term) -> Term:
    return select(condition, ZERO, value)


def conjunction(*formulas: Formula) -> Formula:
    if not formulas:
        raise ValueError("At least one conjunct is required")
    result = formulas[-1]
    for formula in reversed(formulas[:-1]):
        result = And(formula, result)
    return result


def forcing(formula: Formula, condition: Term) -> Formula:
    """Return the condition translation, with all substitutions hygienic."""
    fresh = FreshNames(all_variables(formula) | term_variables(condition))

    def visit(source: Formula, p: Term) -> Formula:
        if isinstance(source, Eq):
            return Eq(project(p, source.left), project(p, source.right))
        if isinstance(source, Bottom):
            return Eq(p, ZERO)
        if isinstance(source, And):
            return And(visit(source.left, p), visit(source.right, p))
        if isinstance(source, Or):
            q_name, r_name = fresh.get("q"), fresh.get("r")
            q, r = Var(q_name), Var(r_name)
            matrix = conjunction(boolean(q), boolean(r), Eq(join(q, r), p),
                                 visit(source.left, q), visit(source.right, r))
            return Exists(q_name, Exists(r_name, matrix))
        if isinstance(source, Implies):
            q_name = fresh.get("q")
            q = Var(q_name)
            return Forall(q_name, Implies(
                And(boolean(q), below(q, p)),
                Implies(visit(source.left, q), visit(source.right, q)),
            ))
        if isinstance(source, (Forall, Exists)):
            bound, body = source.variable, source.body
            if bound in term_variables(p):
                new_bound = fresh.get("bound")
                body = substitute(body, bound, Var(new_bound), fresh)
                bound = new_bound
            return type(source)(bound, visit(body, p))
        raise TypeError(f"Unknown formula type: {type(source).__name__}")

    return visit(formula, condition)


def translate(formula: Formula) -> Formula:
    """The top-condition formula K(A) = (1 forces A)."""
    return forcing(formula, ONE)


def to_json(expression: Term | Formula) -> dict:
    """Stable, explicit JSON representation for the supplied examples."""
    if isinstance(expression, Var):
        return {"var": expression.name}
    if isinstance(expression, App):
        return {"fn": expression.symbol,
                "args": [to_json(t) for t in expression.args]}
    if isinstance(expression, Eq):
        return {"eq": [to_json(expression.left), to_json(expression.right)]}
    if isinstance(expression, Bottom):
        return {"bottom": True}
    if isinstance(expression, (And, Or, Implies)):
        tag = {And: "and", Or: "or", Implies: "implies"}[type(expression)]
        return {tag: [to_json(expression.left), to_json(expression.right)]}
    if isinstance(expression, (Forall, Exists)):
        tag = "forall" if isinstance(expression, Forall) else "exists"
        return {tag: [expression.variable, to_json(expression.body)]}
    raise TypeError(f"Unknown expression type: {type(expression).__name__}")


def walk_formulas(formula: Formula):
    yield formula
    if isinstance(formula, (And, Or, Implies)):
        yield from walk_formulas(formula.left)
        yield from walk_formulas(formula.right)
    elif isinstance(formula, (Forall, Exists)):
        yield from walk_formulas(formula.body)


def example_formulas() -> dict[str, Formula]:
    n, x, y = Var("n"), Var("x"), Var("y")
    return {
        "boolean_range": Forall("n", Or(Eq(zero_test(n), ZERO),
                                          Eq(zero_test(n), ONE))),
        "falsity_bridge": Implies(Eq(ZERO, ONE), Bottom()),
        "existential_identity": Forall("x", Exists("y", Eq(y, x))),
        "equation_induction_matrix": Eq(App("s", (n, x)), App("t", (n, x))),
    }


if __name__ == "__main__":
    import json
    print(json.dumps({name: {"source": to_json(source),
                             "translation": to_json(translate(source))}
                      for name, source in example_formulas().items()}, indent=2))
