"""Compile report.tex in three passes using pdfLaTeX; requires a standard TeX installation."""
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent

if __name__ == "__main__":
    for _ in range(3):
        subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, check=True,
        )
    print("Created", ROOT / "report.pdf")
