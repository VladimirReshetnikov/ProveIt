"""Regenerate all diagnostic evidence. Python 3.10+; standard library only."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"

def run(script, result_name=None, extra=()):
    completed = subprocess.run(
        [sys.executable, str(ROOT / "code" / script), *extra],
        cwd=ROOT, check=True, text=True, capture_output=True,
    )
    result = json.loads(completed.stdout)
    if result_name:
        (EVIDENCE / result_name).write_text(json.dumps(result, indent=2) + "\n")
    return result

def main():
    EVIDENCE.mkdir(exist_ok=True)
    results = {}
    results["translation"] = run(
        "verify_translation.py", extra=("--output-dir", str(EVIDENCE)))
    results["boolean_forcing"] = run(
        "verify_boolean_forcing.py", "boolean_forcing_validation.json")
    results["closed_arithmetic"] = run(
        "verify_closed_arithmetic.py", "closed_arithmetic_validation.json")
    results["baselines"] = run("measure_baselines.py")
    summary = {
        "status": "PASS",
        "scope": "Formula hygiene, finite algebra/numerical diagnostics, and source metrics; not formal metatheory verification.",
        "translation_assertions": results["translation"]["assertion_count"],
        "forcing_checks": results["boolean_forcing"]["checks"],
        "arithmetic_checks": results["closed_arithmetic"]["accelerated_reference_checks"],
        "baseline_envelope": results["baselines"]["coordinatewise_minimum"],
    }
    (EVIDENCE / "validation_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
