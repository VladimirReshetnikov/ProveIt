"""Create a reproducible ZIP and SHA-256 manifest of the deliverable."""
import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk", ".synctex.gz"}
EXCLUDED_PARTS = {"__pycache__", ".git", "rendered"}
EXCLUDED_NAMES = {"SHA256SUMS.txt"}

def selected():
    return sorted(
        p for p in ROOT.rglob("*")
        if p.is_file()
        and p.suffix not in EXCLUDED_SUFFIXES
        and p.name not in EXCLUDED_NAMES
        and not any(part in EXCLUDED_PARTS for part in p.relative_to(ROOT).parts)
        and not p.name.endswith(".pyc")
    )

if __name__ == "__main__":
    files = selected()
    manifest = ROOT / "SHA256SUMS.txt"
    manifest.write_text("".join(
        hashlib.sha256(p.read_bytes()).hexdigest() + "  " +
        p.relative_to(ROOT).as_posix() + "\n" for p in files))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted([*files, manifest]):
            info = zipfile.ZipInfo(ROOT.name + "/" + p.relative_to(ROOT).as_posix(),
                                  date_time=(2026, 11, 8, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, p.read_bytes())
    print(archive)
    print("SHA-256:", hashlib.sha256(archive.read_bytes()).hexdigest())
