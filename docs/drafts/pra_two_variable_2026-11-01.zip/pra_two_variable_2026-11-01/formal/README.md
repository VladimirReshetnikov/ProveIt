# Checked proof: the one-parameter triangular scan

Run from the archive's top-level directory:

```sh
lean formal/OneParameter.lean
```

The file was checked with Lean 4.19.0. It uses only Lean's standard prelude and has no package dependencies.

## What the kernel verifies

The carrier is an arbitrary type. The proof establishes the conditional triangular scan, the endpoint identity `V(T(x)) = x`, both pairing projection identities, finite tuple decoding, and the logical transfer from a decoded one-parameter induction instance to the corresponding induction instance with a finite parameter tuple.

The proof uses three **specific** carrier-induction instances:

| Name | Matrix | Frozen carrier parameters |
| --- | --- | --- |
| `tail` | `sub x (add x n) = zero` | `x` |
| `scan` | `sub n x = zero -> V (add (T x) n) = x` | `x` |
| `anchor` | `V (T n) = n` | None |

The `InductionInstances` structure contains precisely these three matrices. It does not supply a general induction rule for arbitrary predicates. In the inner scan, the hypothesis `V(T(x)) = x` remains fixed throughout induction on `n`.

The local weakening used by the scan is proved algebraically:

`sub n x = sub (succ n) (succ x) = pred (sub (succ n) x)`.

No order transitivity, additive associativity, right inverse of pairing, or assumption of code surjectivity occurs in this kernel.

Lists and their lengths in the final section represent external finite parameter tuples. The induction on a Lean list proves a family of finite decoding identities. It does not add an induction principle over the interpreted arithmetic carrier. The theorem `transfer_parameters` explicitly receives the induction instance for the decoded matrix; the manuscript supplies the syntactic argument that this matrix is quantifier-free and has only one frozen parameter.

## Explicit inputs and limits

The `Arithmetic` structure supplies elementary arithmetic identities already proved in the manuscript with at most one frozen parameter, the triangular recurrence, and the two guarded transition equations for `V`. Those guarded equations follow from the manuscript's primitive-recursive selector for native equality. This file does not independently formalize their construction from the original description grammar.

The finite first-order description grammar, quantifier-free formula syntax, complete primitive-recursion compiler, and proof-theoretic bi-interpretation are proved in the manuscript, not formalized here. Accordingly this artifact is a checked proof of the new arithmetic and parameter-compression argument, not a complete formalization of the entire bi-interpretability theorem.

The five printed axiom audits report no global axioms. In particular the checked theorems use no `sorryAx`, `Classical.choice`, `propext`, or additional global axiom declarations. Their mathematical premises remain explicit parameters and structure fields.
