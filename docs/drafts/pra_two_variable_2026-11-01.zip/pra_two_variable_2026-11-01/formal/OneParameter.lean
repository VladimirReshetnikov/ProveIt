/-
One-parameter triangular scan, over an arbitrary carrier.

Scope: this file checks the new pairing argument. Arithmetic fields below
are the elementary lemmas established in the manuscript using induction
with at most one frozen parameter. The only induction hypotheses in this
file are the three EXACT quantifier-free matrices in `InductionInstances`:
  * sub x (add x n) = zero                     (one parameter x),
  * sub n x = zero -> V (add (T x) n) = x     (one parameter x),
  * V (T n) = n                              (no parameters).
There is no assumption of induction for arbitrary predicates and no
assumption of pairing, transitivity, associativity, or code surjectivity.
The guarded V equations follow from the primitive-recursive equality
selector constructed in the manuscript; no decidable-equality instance
or classical choice is assumed here.
-/

universe u
namespace OneParameter

structure Arithmetic (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  add : A → A → A
  sub : A → A → A
  T : A → A
  V : A → A
  separation : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  add_zero : ∀ x, add x zero = x
  add_succ : ∀ x y, add x (succ y) = succ (add x y)
  add_comm : ∀ x y, add x y = add y x
  sub_succ : ∀ x y, sub x (succ y) = pred (sub x y)
  sub_both : ∀ x y, sub (succ x) (succ y) = sub x y
  sub_cancel : ∀ x c, sub (add x c) x = c
  T_zero : T zero = zero
  T_succ : ∀ x, T (succ x) = add (T x) (succ x)
  V_zero : V zero = zero
  V_hit : ∀ n, succ n = T (succ (V n)) → V (succ n) = succ (V n)
  V_miss : ∀ n, succ n ≠ T (succ (V n)) → V (succ n) = V n

structure InductionInstances {A : Type u} (K : Arithmetic A) : Prop where
  tail : ∀ x,
    K.sub x (K.add x K.zero) = K.zero →
    (∀ n, K.sub x (K.add x n) = K.zero →
      K.sub x (K.add x (K.succ n)) = K.zero) →
    ∀ n, K.sub x (K.add x n) = K.zero
  scan : ∀ x,
    (K.sub K.zero x = K.zero → K.V (K.add (K.T x) K.zero) = x) →
    (∀ n,
      (K.sub n x = K.zero → K.V (K.add (K.T x) n) = x) →
      (K.sub (K.succ n) x = K.zero → K.V (K.add (K.T x) (K.succ n)) = x)) →
    ∀ n, K.sub n x = K.zero → K.V (K.add (K.T x) n) = x
  anchor : K.V (K.T K.zero) = K.zero →
    (∀ n, K.V (K.T n) = n → K.V (K.T (K.succ n)) = K.succ n) →
    ∀ n, K.V (K.T n) = n

namespace Arithmetic

variable {A : Type u} (K : Arithmetic A)

 theorem succ_injective {x y : A} (h : K.succ x = K.succ y) : x = y := by
  have h' := congrArg K.pred h
  rw [K.pred_succ, K.pred_succ] at h'
  exact h'

 theorem sub_self (x : A) : K.sub x x = K.zero := by
  have h := K.sub_cancel x K.zero
  rw [K.add_zero] at h
  exact h

 theorem sub_next (x : A) : K.sub (K.succ x) x = K.succ K.zero := by
  have h := K.sub_cancel x (K.succ K.zero)
  rw [K.add_succ, K.add_zero] at h
  exact h

 theorem cancel_left {a b c : A} (h : K.add a b = K.add a c) : b = c := by
  have h' := congrArg (fun z => K.sub z a) h
  change K.sub (K.add a b) a = K.sub (K.add a c) a at h'
  rw [K.sub_cancel, K.sub_cancel] at h'
  exact h'

/- Local weakening is an algebraic calculation, with no order theorem. -/
 theorem weaken_left {n x : A}
    (h : K.sub (K.succ n) x = K.zero) : K.sub n x = K.zero := by
  have e := K.sub_both n x
  rw [K.sub_succ, h, K.pred_zero] at e
  exact e.symm

 theorem strict_ne {n x : A}
    (h : K.sub (K.succ n) x = K.zero) : n ≠ x := by
  intro e
  rw [e, K.sub_next] at h
  exact K.separation h.symm

variable (I : InductionInstances K)
include I

 theorem tail_zero (x n : A) : K.sub x (K.add x n) = K.zero := by
  apply I.tail x
  · rw [K.add_zero]
    exact K.sub_self x
  · intro j ih
    rw [K.add_succ, K.sub_succ, ih, K.pred_zero]

 theorem right_le_sum (x y : A) : K.sub y (K.add x y) = K.zero := by
  rw [K.add_comm x y]
  exact K.tail_zero I y x

/- The fixed hypothesis H contains x, never the induction variable n. -/
 theorem scan_from_anchor (x : A) (H : K.V (K.T x) = x) :
    ∀ n, K.sub n x = K.zero → K.V (K.add (K.T x) n) = x := by
  apply I.scan x
  · intro _
    rw [K.add_zero]
    exact H
  · intro n ih hn
    have hn0 : K.sub n x = K.zero := K.weaken_left hn
    have hnX : n ≠ x := K.strict_ne hn
    have Hv : K.V (K.add (K.T x) n) = x := ih hn0
    have miss : K.succ (K.add (K.T x) n) ≠
        K.T (K.succ (K.V (K.add (K.T x) n))) := by
      intro boundary
      rw [Hv, K.T_succ, ← K.add_succ] at boundary
      have ns : K.succ n = K.succ x := K.cancel_left boundary
      exact hnX (K.succ_injective ns)
    rw [K.add_succ, K.V_miss _ miss, Hv]

 theorem triangular_anchor (x : A) : K.V (K.T x) = x := by
  apply I.anchor
  · rw [K.T_zero, K.V_zero]
  · intro n H
    have Hend : K.V (K.add (K.T n) n) = n :=
      K.scan_from_anchor I n H n (K.sub_self n)
    have hit : K.succ (K.add (K.T n) n) =
        K.T (K.succ (K.V (K.add (K.T n) n))) := by
      rw [Hend, K.T_succ, K.add_succ]
    rw [K.T_succ, K.add_succ, K.V_hit _ hit, Hend]

 theorem triangular_scan (x n : A) (h : K.sub n x = K.zero) :
    K.V (K.add (K.T x) n) = x :=
  K.scan_from_anchor I x (K.triangular_anchor I x) n h

 def pair (x y : A) : A := K.add (K.T (K.add x y)) y
 def right (z : A) : A := K.sub z (K.T (K.V z))
 def left (z : A) : A := K.sub (K.V z) (K.right z)

 theorem pair_level (x y : A) : K.V (K.pair x y) = K.add x y := by
  exact K.triangular_scan I (K.add x y) y (K.right_le_sum I x y)

 theorem right_pair (x y : A) : K.right (K.pair x y) = y := by
  unfold right
  rw [K.pair_level I]
  exact K.sub_cancel (K.T (K.add x y)) y

 theorem left_pair (x y : A) : K.left (K.pair x y) = x := by
  unfold left
  rw [K.pair_level I, K.right_pair I, K.add_comm x y]
  exact K.sub_cancel y x

 theorem pairing_retractions (x y : A) :
    K.left (K.pair x y) = x ∧ K.right (K.pair x y) = y := by
  exact ⟨K.left_pair I x y, K.right_pair I x y⟩

/- Lists and their lengths below are external finite parameter tuples.
The List induction proves the family of finite decoding identities; it is
not induction over the interpreted arithmetic carrier. -/
 def encode : List A → A
  | [] => K.zero
  | x :: xs => K.pair x (encode xs)

 def decode : Nat → A → List A
  | 0, _ => []
  | Nat.succ k, z => K.left z :: decode k (K.right z)

 theorem decode_encode (xs : List A) :
    K.decode xs.length (K.encode xs) = xs := by
  induction xs with
  | nil => rfl
  | cons x xs ih =>
      change K.left (K.pair x (K.encode xs)) ::
        K.decode xs.length (K.right (K.pair x (K.encode xs))) = x :: xs
      rw [K.left_pair I, K.right_pair I, ih]

/- Exact logical transfer: the caller supplies the single-parameter
induction instance for the decoded quantifier-free matrix. In the
manuscript its admissibility follows by syntactic term substitution.
No arbitrary-predicate induction is assumed by the pairing proof. -/
 theorem transfer_parameters
    (F : A → List A → Prop) (xs : List A)
    (coded : ∀ c,
      F K.zero (K.decode xs.length c) →
      (∀ n, F n (K.decode xs.length c) →
        F (K.succ n) (K.decode xs.length c)) →
      ∀ n, F n (K.decode xs.length c))
    (base : F K.zero xs)
    (step : ∀ n, F n xs → F (K.succ n) xs) :
    ∀ n, F n xs := by
  have h := coded (K.encode xs)
  rw [K.decode_encode I xs] at h
  exact h base step

#print axioms OneParameter.Arithmetic.scan_from_anchor
#print axioms OneParameter.Arithmetic.triangular_anchor
#print axioms OneParameter.Arithmetic.pairing_retractions
#print axioms OneParameter.Arithmetic.decode_encode
#print axioms OneParameter.Arithmetic.transfer_parameters

end Arithmetic
end OneParameter
