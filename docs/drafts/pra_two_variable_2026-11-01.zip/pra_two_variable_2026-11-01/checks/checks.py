#!/usr/bin/env python3
"""Literal finite-description diagnostics for the two-variable PRA paper.

Standard-natural-number computations only: these are not an arbitrary-model
proof.  The evaluator uses the actual admitted binary recursor equations.
No pairing, predecessor, subtraction, or equality operation is supplied to
the object language by the Python host.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

sys.setrecursionlimit(20000)
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ZERO = ("zero",)


def var(i):
    return ("var", i)


def succ(t):
    return ("succ", t)


class Language:
    def __init__(self):
        self.names = []
        self.bodies = []
        self.series = {}
        self.transitions = 0

    def admit(self, name, body):
        """Require a finite body in counter/state variables and earlier R's."""
        bound = len(self.bodies)

        def validate(t):
            if t[0] == "zero":
                return
            if t[0] == "var":
                assert t[1] in (0, 1), (name, t)
                return
            if t[0] == "succ":
                validate(t[1])
                return
            assert t[0] == "rec" and 0 <= t[1] < bound, (name, t)
            validate(t[2])
            validate(t[3])

        validate(body)
        self.names.append(name)
        self.bodies.append(body)
        return bound

    @staticmethod
    def app(index, counter, seed):
        return ("rec", index, counter, seed)

    def evaluate(self, term, env=()):
        tag = term[0]
        if tag == "zero":
            return 0
        if tag == "var":
            return env[term[1]]
        if tag == "succ":
            return 1 + self.evaluate(term[1], env)
        assert tag == "rec"
        r, n, a = term[1], self.evaluate(term[2], env), self.evaluate(term[3], env)
        values = self.series.setdefault((r, a), [a])
        while len(values) <= n:
            i = len(values) - 1
            values.append(self.evaluate(self.bodies[r], (i, values[-1])))
            self.transitions += 1
        return values[n]


L = Language()
n, v = var(0), var(1)
one = succ(ZERO)
rp = L.admit("predecessor", n)


def pred(x):
    return L.app(rp, x, ZERO)


rz = L.admit("zero_gate", ZERO)


def gate(x, a):
    return L.app(rz, x, a)


ra = L.admit("addition", succ(v))


def add(x, y):
    return L.app(ra, y, x)


rd = L.admit("subtraction", pred(v))


def sub(x, y):
    return L.app(rd, y, x)


def case(x, a, b):
    return add(gate(x, a), gate(gate(x, one), b))


def unit_error(x):
    return case(x, one, case(pred(x), ZERO, one))


def eq_error(x, y):
    return unit_error(sub(succ(x), y))


rt = L.admit("triangular", add(v, succ(n)))


def triangle(x):
    return L.app(rt, x, ZERO)


rv = L.admit("equality_triggered_inverse",
             case(eq_error(succ(n), triangle(succ(v))), succ(v), v))


def inverse(x):
    return L.app(rv, x, ZERO)


def pair(x, y):
    return add(triangle(add(x, y)), y)


def pi2(z):
    return sub(z, triangle(inverse(z)))


def pi1(z):
    return sub(inverse(z), pi2(z))


def code(terms):
    """Right-nested tuple convention, as in the Lean certificate."""
    out = ZERO
    for t in reversed(terms):
        out = pair(t, out)
    return out


def decode(z, i):
    for _ in range(i):
        z = pi2(z)
    return pi1(z)


results = []


def check(name, count, detail):
    results.append({"name": name, "passed_cases": count, "scope": detail})


def run_numerical():
    x, y = var(0), var(1)
    for a in range(21):
        assert L.evaluate(pred(x), (a,)) == max(0, a - 1)
    check("predecessor", 21, "0 <= x <= 20")
    for a, b in itertools.product(range(13), repeat=2):
        assert L.evaluate(add(x, y), (a, b)) == a + b
        assert L.evaluate(sub(x, y), (a, b)) == max(0, a - b)
        assert L.evaluate(eq_error(x, y), (a, b)) == (0 if a == b else 1)
    check("addition_subtraction_native_equality_bit", 169, "0 <= x,y <= 12")
    for a in range(13):
        ta = L.evaluate(triangle(x), (a,))
        assert ta == a * (a + 1) // 2
        assert L.evaluate(inverse(triangle(x)), (a,)) == a
        for b in range(a + 1):
            assert L.evaluate(inverse(add(triangle(x), y)), (a, b)) == a
    check("triangular_anchor_and_scan", 91, "0 <= j <= x <= 12")
    for a in range(121):
        expected = 0
        while (expected + 1) * (expected + 2) // 2 <= a:
            expected += 1
        assert L.evaluate(inverse(x), (a,)) == expected
    check("inverse_standard_values", 121, "0 <= input <= 120; host oracle only")
    for a, b in itertools.product(range(11), repeat=2):
        assert L.evaluate(pi1(pair(x, y)), (a, b)) == a
        assert L.evaluate(pi2(pair(x, y)), (a, b)) == b
    check("pairing_left_inverses", 121, "0 <= x,y <= 10; no right-inverse claim")
    tuple_cases = 0
    for k in range(4):
        ts = [var(i) for i in range(k)]
        for vals in itertools.product(range(2), repeat=k):
            for i in range(k):
                assert L.evaluate(decode(code(ts), i), vals) == vals[i]
            tuple_cases += 1
    check("tuple_left_inverses", tuple_cases, "0 <= arity <= 3; entries 0 or 1")

    # A literal compiled ordinary recursion with THREE frozen parameters:
    # F(0,b,c,d)=b; F(Sn,b,c,d)=F(n,b,c,d)+c+d.
    # Only the counter and encoded state may occur in its admitted update.
    stored = pi1(v)
    prev = pi2(v)
    c, d = decode(stored, 1), decode(stored, 2)
    update = pair(stored, add(add(prev, c), d))
    rf = L.admit("compiled_three_parameter_recursion", update)
    bts = [var(i + 1) for i in range(3)]
    initial = pair(code(bts), bts[0])
    state = L.app(rf, var(0), initial)
    out = pi2(state)
    cases = 0
    for counter in range(5):
        for b, c0, d0 in itertools.product(range(2), repeat=3):
            env = (counter, b, c0, d0)
            assert L.evaluate(out, env) == b + counter * (c0 + d0)
            assert L.evaluate(pi1(state), env) == L.evaluate(code(bts), env)
            cases += 1
    check("compiled_recursion_and_state_invariant", cases,
          "0 <= counter <= 4; three frozen bits; actual binary update grammar")


# Independent abstract syntax-tree ledger for the axiom templates.
def V(name):
    return ("variable", name)


def C(name):
    return ("constant", name)


def app(name, *args):
    return ("apply", name, args)


def eq(a, b):
    return ("equal", a, b)


def conn(tag, a, b):
    return (tag, a, b)


def forall(name, body):
    return ("forall", name, body)


def nodes(t):
    if t[0] in ("variable", "constant", "bottom"):
        return 1
    if t[0] == "apply":
        return 1 + sum(map(nodes, t[2]))
    if t[0] == "forall":
        return 1 + nodes(t[2])
    return 1 + nodes(t[1]) + nodes(t[2])


def variable_names(t):
    if t[0] == "variable":
        return {t[1]}
    if t[0] in ("constant", "bottom"):
        return set()
    if t[0] == "apply":
        return set().union(*(variable_names(a) for a in t[2]))
    if t[0] == "forall":
        return {t[1]} | variable_names(t[2])
    return variable_names(t[1]) | variable_names(t[2])


def ledger():
    n, a, c, z = V("n"), V("a"), V("c"), C("0")
    s = lambda t: app("S", t)
    r0 = forall("a", eq(app("R_h", z, a), a))
    rs = forall("n", forall("a", eq(app("R_h", s(n), a),
                                         app("h", n, app("R_h", n, a)))))
    sep = conn("implies", eq(z, s(z)), ("bottom",))
    rows = []
    for q in (0, 1, 2, 3):
        params = [V(f"c{i}") for i in range(q)]
        A = lambda t: app("A", t, *params)
        E = lambda t: eq(app("s", t, *params), app("t", t, *params))
        fused = conn("implies",
                     conn("and", conn("or", A(z), eq(z, s(z))),
                          forall("n", conn("implies", A(n), A(s(n))))),
                     forall("n", A(n)))
        zero_exception = conn("implies",
                              forall("n", conn("implies", conn("or", eq(n, z), E(n)), E(s(n)))),
                              forall("n", conn("or", eq(n, z), E(n))))
        for p in reversed(params):
            fused = forall(p[1], fused)
            zero_exception = forall(p[1], zero_exception)
        assert nodes(r0) == 6 and nodes(rs) == 12
        assert nodes(r0) + nodes(rs) + nodes(fused) == 37 + 5 * q
        assert nodes(r0) + nodes(rs) + nodes(sep) + nodes(zero_exception) == 53 + 7 * q
        if q <= 1:
            assert len(variable_names(r0)) <= 2
            assert len(variable_names(rs)) <= 2
            assert len(variable_names(fused)) <= 2
            assert len(variable_names(zero_exception)) <= 2
        rows.append({"frozen_induction_parameters": q,
                     "fused_formula_total": nodes(r0) + nodes(rs) + nodes(fused),
                     "zero_exception_total": nodes(r0) + nodes(rs) + nodes(sep) + nodes(zero_exception),
                     "retained_in_new_axiom_generator": q <= 1})
    return {"R0": nodes(r0), "RS": nodes(rs), "separation": nodes(sep),
            "rows": rows, "metric": "partial schema-display AST; substituted bodies not charged"}


def main():
    run_numerical()
    metrics = ledger()
    report = {"status": "passed", "scope": "finite computations and syntax checks, not model-theoretic proofs",
              "tests": results, "metrics": metrics,
              "binary_descriptions": len(L.bodies),
              "all_updates_have_only_counter_and_state": True,
              "all_dependencies_strictly_earlier": True,
              "literal_recursion_transitions": L.transitions,
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    desc = [{"name": name, "index": i, "arity": 2, "body": body}
            for i, (name, body) in enumerate(zip(L.names, L.bodies))]
    (HERE / "descriptions.json").write_text(json.dumps(desc, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "test_groups": len(results),
                      "binary_descriptions": len(desc), "transitions": L.transitions,
                      "metrics": metrics}, indent=2))


if __name__ == "__main__":
    main()
