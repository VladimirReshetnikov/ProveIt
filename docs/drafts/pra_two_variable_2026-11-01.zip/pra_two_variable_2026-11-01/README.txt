A TWO-VARIABLE AXIOMATIZATION OF PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 1 November 2026

MAIN RESULT
The binary initialized-recursion language needs induction with only one
frozen parameter. Thus all nonlogical axioms can be written using at most
two individual variable symbols. The identical nonlogical specification
works in classical and intuitionistic first-order logic, respectively.
Each theory has a common conservative definitional extension with the
matching first-order PRA, with whole-carrier identity bi-interpretations.

The substantive new proof relative to the eight inspected drafts is an
equality-triggered triangular decoder, proved using a one-parameter scan
and parameter-free boundary induction. Its pairing left inverses permit
arbitrary finite induction parameters and recursion states to be coded.

This is a restriction of the axiom generator, not a new display-node
record: the retained one-parameter fused template still has the earlier
42-node partial ledger. No absolute minimality or historical priority is
claimed. The manuscript proves and compares both the short formula basis
F1 and the term-only fixed-zero basis Z1.

CONTENTS
  report.tex / report.pdf       Complete 14-page mathematical report
  build.py                     Rebuild PDF and optional verification
  formal/OneParameter.lean      Checked new core over an arbitrary carrier
  formal/README.md              Exact formal scope and checking instructions
  checks/checks.py              Literal binary-description evaluator/checks
  checks/results.json          Diagnostic results and schema AST counts
  checks/descriptions.json     Executable finite update descriptions
  checks/formal.json            Lean version, exit status, axiom dependencies
  audit/source_manifest.json   Eight immutable comparison inputs and hashes
  audit/review.json             Mathematical/parameter/scope audit
  audit/build.json              PDF build results
  audit/pdf_review.json         Visual PDF review record
  SHA256SUMS.txt                Integrity hashes of all other package files

REBUILD
  python3 build.py

Rebuild and rerun the executable diagnostics:
  python3 build.py --checks

Also rerun the Lean certificate (Lean 4.19.0, no mathlib required):
  python3 build.py --checks --lean /absolute/path/to/lean

DEPENDENCIES
Python 3 standard library; pdflatex with the ordinary AMS, Latin Modern,
microtype, geometry, tabularx, fancyhdr, enumitem, xurl, and hyperref packages.
Lean is optional for rebuilding the PDF; it is needed to replay the kernel
certificate. No network access is needed after these tools are installed.

VERIFICATION SCOPE
The paper contains the complete written bootstrap and bi-interpretation
proof. The Lean certificate checks the new scan, boundary, pairing left
inverses, external finite tuple decoding, and induction-instance transport.
Elementary arithmetic identities and the guarded recursion equations are
explicit hypotheses, derived in the paper. The certificate does not claim
to formalize first-order descriptor syntax or the full bi-interpretation.
All five printed theorem axiom dependencies are empty; the explicit
hypotheses remain hypotheses of the statements.

The numerical checks use actual binary-recursion descriptions and no
host-language arithmetic primitives in the object language. Host arithmetic
is used solely to compare computed results with expected standard values.
Finite checks do not establish truths at arbitrary/nonstandard elements.

SOURCE SNAPSHOT
https://github.com/VladimirReshetnikov/ProveIt/tree/117c275bb0a4486d75e51a707b1187d177dcee07/docs/drafts

The package does not include copies of the eight input archives; their
immutable URLs and cryptographic hashes are in the manifest.
