#!/usr/bin/env python3
"""Rebuild the report, optionally replaying diagnostics and Lean."""
from __future__ import annotations
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(cmd):
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks", action="store_true")
    parser.add_argument("--lean", help="Lean executable for optional certificate replay")
    args = parser.parse_args()
    if args.checks:
        result = run([sys.executable, str(ROOT / "checks/checks.py")])
        print(result.stdout)
    if args.lean:
        version = run([args.lean, "--version"]).stdout.strip()
        result = run([args.lean, str(ROOT / "formal/OneParameter.lean")])
        print(version)
        print(result.stdout)
    compiler = shutil.which("pdflatex")
    if compiler is None:
        raise SystemExit("pdflatex is required; install a TeX distribution.")
    with tempfile.TemporaryDirectory(prefix="pra-two-variable-build-") as temp:
        cmd = [compiler, "-interaction=nonstopmode", "-halt-on-error",
               "-output-directory=" + temp, str(ROOT / "report.tex")]
        for _ in range(3):
            run(cmd)
        log = (Path(temp) / "report.log").read_text()
        problems = [line for line in log.splitlines()
                    if "Overfull" in line or "undefined references" in line
                    or "LaTeX Warning: Reference" in line
                    or "LaTeX Warning: Citation" in line]
        if problems:
            raise SystemExit("PDF build needs review:\n" + "\n".join(problems))
        shutil.copyfile(Path(temp) / "report.pdf", ROOT / "report.pdf")
    record = {"compiler": run([compiler, "--version"]).stdout.splitlines()[0],
              "passes": 3, "exit_code": 0, "overfull_boxes": [],
              "unresolved_references": [],
              "tex_sha256": hashlib.sha256((ROOT / "report.tex").read_bytes()).hexdigest(),
              "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
              "pdf_bytes": (ROOT / "report.pdf").stat().st_size}
    (ROOT / "audit/build.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
