EQUALITY THROUGH ONE FIXED ITERATOR POSITION
Research prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific time)

STATUS

The requested strict improvement below the current complete-checker frontier
was not obtained. This package provides a fully specified iPRA-equivalent
presentation and a proved structural reduction of equality reasoning.
It must not be described as a new smallest axiomatization or the requested
minimization breakthrough.

The new theory preserves every native sequent of the inherited scalar
Choice-DI calculus. It replaces arbitrary equality transport by two fixed
rules: replacement of the whole left endpoint of an equation, and replacement
of the initializer of the outermost iterator on that left endpoint.

Its computation schemas are:
  I(0,a;u.h) = a
  I(1,a;u.h) = h[a/u]
  I(S(Sn),a;u.h) = h[I(Sn,a;u.h)/u]

One-step boxing B_F(a)=I(1,a;u.F(u)) derives arbitrary term congruence.
An N-node proof of s=t gives an (N+8)-node proof of F(s)=F(t), with the
source proof occurring once, independently of the context's depth or number
of free occurrences. This is a proof-node count, not a checker-size claim.

MAIN FILES

report.pdf                Compiled paper, including arithmetic appendices.
report.tex                Editable main LaTeX source with explicit inputs.
report_standalone.tex     Complete expanded source in one file.
appendices/               Attributed scalar-to-iPRA proofs and new supplement.
code/root_seed_checker.py Complete standalone checker for the new theory.
code/root_seed_producer.py Untrusted constructors for the displayed lemmas.
code/test_root_seed.py    Focused positive and negative certificate checks.
code/root_seed_fixtures.json  Closed CLI packets, including capture attack.
code/root_seed_scoped_certificates.json  Fully expanded open-context proofs.
code/matched_transport_checker.py       Matched ordinary-transport control.
evidence/reproduction.json               Current executable/metric receipt.
evidence/source_manifest.json            All 30 pinned archive identities.
evidence/kernel_audit.json                Whole-corpus source audit receipt.
reference/frontier_sources/              28 distinct normalized comparators.
payload_sha256.json                      SHA-256 identities for ZIP payloads.

OFFLINE REPRODUCTION

From this directory:
  python3 reproduce.py
  python3 build.py
  python3 package.py

reproduce.py requires only the Python standard library. It runs 52 focused
API checks and 50 ordinary/optimized CLI executions, rebuilds the matched
control, verifies frozen comparator identities, and recomputes complete-source
metrics. The receipts are intended for CPython 3.12.14; a different Python
AST/unparse version may produce a different byte-level normalization.

build.py needs pdfLaTeX with ordinary TeX Live packages. It disables shell
escape, builds report.pdf, and regenerates report_standalone.tex.

package.py makes a clean ZIP in the parent directory, excluding TeX build
debris and Python bytecode. No network or repository write is involved.

CHECKER INTERFACE

The checker reads a JSON array [closed_goal, proof_tree] from standard input.
It prints ACCEPT with exit 0 or REJECT with exit 1. Its only import is json.
See code/FORMAT.txt for the complete sorted syntax and rule packet format.
Generated proofs are data. Neither checker executes submitted code.

COMPARISON

Whole programs, with comments/docstrings removed and ast.unparse normalization:
  New fixed-position checker:       1860 tokens / 2229 AST / 7601 bytes
  Matched ordinary-transport control:1794 tokens / 2142 AST / 7408 bytes
  Supplied compact envelope:          299 tokens /  340 AST /  815 bytes

Different supplied programs attain the three compact minima. The new checker
is larger even than the matched control. The paper states this directly.

The mathematical equivalence and bi-interpretations are written proofs,
independently reviewed by assistant agents. The executable checks are finite
regressions, not a Lean/Rocq formalization of the universal metatheory.
The complete iPRA proof compiler is described mathematically; the delivered
producer implements the new local equality/transport constructions and the
successor-computation recovery, not a general parser for arbitrary iPRA proofs.

SUPPLEMENT

The supplementary theorem proves that uniqueness for any definable involution
is exactly arbitrary-value stationarity over a specified induction-free PR
base. Adjacent swaps are an example. The implication from this stationarity
theory to full iPRA remains unresolved, and is not used in the main theorem.

SOURCE SNAPSHOT

https://github.com/VladimirReshetnikov/ProveIt/tree/
aac8216be66b1a6f043fed87a8d515bc5b5d0790/docs/drafts

The repository was read without a commit or publication. Attribution and
the inherited MIT No Attribution License are supplied in this package.
