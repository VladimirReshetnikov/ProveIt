#!/usr/bin/env python3
"""Independent adversarial audit of the variable-specialization kernel.

The oracle below uses explicit syntax validation and simultaneous index maps;
it never calls the candidate's substitution routine to build expected terms.
The script does not belong to the trusted checker.
"""
import argparse
import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile


def term_ok(t):
    if type(t) is int:
        return True
    if type(t) is not list:
        return False
    if len(t) == 2 and t[0] == "s":
        return term_ok(t[1])
    return len(t) == 4 and t[0] == "r" and all(term_ok(c) for c in t[1:])


def formula_ok(a):
    if type(a) is not list:
        return False
    if len(a) == 3 and a[0] == "=":
        return term_ok(a[1]) and term_ok(a[2])
    return len(a) == 2 and a[0] in ("q", "ex") and formula_ok(a[1])


def term_map(t, free_index, depth=0):
    """Map free positive indices; zero/negative atoms and binders stay fixed."""
    if type(t) is int:
        if t <= depth:
            return t
        return free_index(t - depth, depth)
    if t[0] == "s":
        return ["s", term_map(t[1], free_index, depth)]
    return ["r", term_map(t[1], free_index, depth),
            term_map(t[2], free_index, depth),
            term_map(t[3], free_index, depth + 2)]


def formula_map(a, free_index, depth=0):
    if a[0] == "=":
        return ["=", term_map(a[1], free_index, depth),
                term_map(a[2], free_index, depth)]
    return [a[0], formula_map(a[1], free_index, depth + 1)]


def lift_term(t, amount, cutoff=0):
    if type(t) is int:
        return t + amount if t > cutoff else t
    if t[0] == "s":
        return ["s", lift_term(t[1], amount, cutoff)]
    return ["r", lift_term(t[1], amount, cutoff),
            lift_term(t[2], amount, cutoff),
            lift_term(t[3], amount, cutoff + 2)]


def lift_formula(a, amount, cutoff=0):
    if a[0] == "=":
        return ["=", lift_term(a[1], amount, cutoff),
                lift_term(a[2], amount, cutoff)]
    return [a[0], lift_formula(a[1], amount, cutoff + 1)]


def reference_subst(a, replacements, offset, depth, formula):
    def free_index(i, binders):
        if i <= len(replacements):
            return lift_term(replacements[i - 1], binders)
        return i + binders + offset
    return (formula_map if formula else term_map)(a, free_index, depth)


def instantiate_formula(a, t):
    return reference_subst(a, [t], -1, 0, True)


def eq(s, t):
    return ["=", s, t]


def succ(t):
    return ["s", t]


def rec(n, a, h):
    return ["r", n, a, h]


def reflexivity(t):
    """R0 twice, followed by equality transport; no Q specialization."""
    axiom = eq(rec(0, t, 0), t)
    motive = eq(1, lift_term(t, 1))
    return [[], [], [axiom, motive]]


def random_term(rng, depth):
    if depth == 0 or rng.randrange(4) == 0:
        return rng.choice([-100, -3, -1, 0, 1, 2, 3, 4, 7, 11])
    if rng.randrange(2):
        return succ(random_term(rng, depth - 1))
    return rec(*(random_term(rng, depth - 1) for _ in range(3)))


def random_formula(rng, depth):
    if depth == 0 or rng.randrange(3) == 0:
        return eq(random_term(rng, 2), random_term(rng, 2))
    return [rng.choice(["q", "ex"]), random_formula(rng, depth - 1)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checker", type=Path, required=True)
    ap.add_argument("--output", type=Path, default=Path("independent_audit.json"))
    ap.add_argument("--examples", type=Path)
    args = ap.parse_args()
    checker_path = args.checker.resolve()
    spec = importlib.util.spec_from_file_location("independently_audited_kernel", checker_path)
    kernel = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(kernel)
    cases = []
    witnesses = {}

    def accept(goal, stream, context=()):
        kernel.p = copy.deepcopy(stream)
        try:
            return bool(kernel.check(copy.deepcopy(goal), *copy.deepcopy(context)))
        except Exception:
            return False

    def expect(name, goal, stream, wanted, context=(), save=False):
        actual = accept(goal, stream, context)
        record = {"name": name, "expected": wanted, "actual": actual,
                  "root_certificate": not context}
        cases.append(record)
        if actual != wanted:
            raise AssertionError((name, goal, stream, context, wanted, actual))
        if save:
            witnesses[name] = [goal, stream]

    # All Q witnesses below are inert fields. Only free coordinate 1 is used.
    major = ["q", eq(1, 1)]
    major_proof = reflexivity(succ(1)) + [[]]
    base_proof = reflexivity(0)
    for i, inert in enumerate([None, 0, 1, 2, -1, succ(1), [], {}, True,
                              ["not-a-term"], {"unused": "metadata"}]):
        stream = base_proof + major_proof + [[major, inert]]
        expect(f"Q_coordinate_1_inert_payload_{i}", eq(1, 1), stream, True)
        for label, other in [("zero", 0), ("slot_2", 2),
                             ("rigid", -1), ("compound", succ(1))]:
            expect(f"Q_reject_{label}_payload_{i}", eq(other, other), stream, False,
                   save=i == 3)
    q_stream = base_proof + major_proof + [[major, 2]]
    expect("Q_coordinate_1_canonical", eq(1, 1), q_stream, True, save=True)
    expect("Q_slot_2_closed_existential_rejected", ["ex", eq(2, 2)],
           q_stream + [[0]], False, save=True)
    expect("Q_slot_1_closed_existential_accepted", ["ex", eq(1, 1)],
           q_stream + [[0]], True, save=True)

    # Direct local sequent test: varying the conclusion cannot change Q's slot.
    specific_major = ["q", eq(1, 0)]
    context = (specific_major, eq(0, 0))
    local_stream = [None, None, [specific_major, 2]]
    expect("Q_local_coordinate_1", eq(1, 0), local_stream, True, context)
    expect("Q_local_coordinate_2_rejected", eq(2, 0), local_stream, False, context)

    # Every genuinely inspected formula, term, and witness must be sorted.
    bad_terms = [None, True, False, 0.0, 1.5, "0", "s", {}, [],
                 ["s"], ["s", 0, 0], ["r", 0, 0], ["r", 0, 0, 0, 0],
                 ["r", 0, 0, ["ex", eq(0, 0)]], ["bogus", 0], ["s", True]]
    bad_formulas = [None, True, 0, 0.0, "=", {}, [], ["="], ["=", 0],
                    ["=", 0, 0, 0], ["q"], ["q", eq(0, 0), eq(0, 0)],
                    ["ex"], ["ex", 0], ["Q", eq(0, 0)], ["s", eq(0, 0)],
                    ["q", ["ex", ["=", 0, True]]]]
    for i, bad in enumerate(bad_terms):
        assert not term_ok(bad)
        expect(f"bad_goal_term_{i}", eq(bad, bad), reflexivity(0), False)
        expect(f"bad_vacuous_existential_witness_{i}", ["ex", eq(0, 0)],
               reflexivity(0) + [[bad]], False)
        expect(f"bad_unused_recursion_update_{i}", eq(rec(0, 0, bad), 0), [[]], False)
        expect(f"bad_equality_motive_{i}", eq(0, 0),
               [[], [], [eq(rec(0, 0, 0), 0), bad]], False)
    for i, bad in enumerate(bad_formulas):
        assert not formula_ok(bad)
        expect(f"bad_goal_formula_{i}", bad, [None], False)
        expect(f"bad_major_formula_{i}", eq(0, 0), [None, [bad, None]], False)

    # A newly introduced existential variable cannot escape through the goal.
    expect("existential_guard_exact", ["ex", eq(1, 0)], [None, [0]], True, save=True)
    expect("existential_witness_outer_parameter_lifted", ["ex", eq(1, 2)], [None, [1]], True)
    expect("existential_witness_cannot_capture_itself", ["ex", eq(1, 1)], [None, [1]], False)
    expect("existential_guard_wrong_slot", ["ex", eq(2, 0)], [None, [0]], False, save=True)
    existential = ["ex", eq(1, 0)]
    existential_proof = [None, [0]]
    expect("existential_elimination_eigenvariable_escape", eq(1, 0),
           [None] + existential_proof + [[existential, None]], False, save=True)
    expect("existential_elimination_valid", eq(0, 0),
           reflexivity(0) + existential_proof + [[existential, None]], True, save=True)

    # Computation: malformed unused code is rejected; binders are not confused.
    expect("R0", eq(rec(0, 2, succ(1)), 2), [[]], True)
    expect("R0_wrong_rhs", eq(rec(0, 2, succ(1)), 1), [[]], False)
    expect("RS_accumulator", eq(rec(succ(2), 3, 1), rec(2, 3, 1)), [[]], True)
    expect("RS_counter", eq(rec(succ(2), 3, 2), 2), [[]], True)
    expect("RS_fixed_outer_parameter", eq(rec(succ(2), 3, 3), 1), [[]], True)
    expect("RS_wrong_outer_parameter", eq(rec(succ(2), 3, 3), 3), [[]], False)
    for n in (2, -7, succ(0), rec(0, 4, 0)):
        h = rec(1, 2, succ(3))
        previous = rec(n, 3, h)
        expected = rec(previous, n, succ(lift_term(previous, 2)))
        expect("RS_nested_capture_" + str(n), eq(rec(succ(n), 3, h), expected), [[]], True)
    expect("counter_not_a_constructor", eq(rec(1, 0, 0), 0), [[]], False)
    expect("rigid_counter_not_a_constructor", eq(rec(-1, 0, 0), 0), [[]], False)

    # Hypothesis lookup is scoped, and proof padding has no semantic role.
    expect("empty_context_hypothesis_rejected", eq(0, 0), [None], False)
    expect("false_equation_rejected", eq(0, succ(0)), reflexivity(0), False, save=True)
    expect("arbitrary_prefix_is_unused", eq(0, 0),
           ["padding", {"ignored": True}] + reflexivity(0), True)
    expect("empty_stream_rejected", eq(0, 0), [], False)
    expect("non_list_stream_rejected", eq(0, 0), {}, False)

    # Independent substitution oracle: no candidate helpers build the answers.
    rng = random.Random(20261106)
    substitution_checks = 0
    for _ in range(2500):
        formula = bool(rng.randrange(2))
        obj = random_formula(rng, 4) if formula else random_term(rng, 4)
        replacements = [random_term(rng, 2) for _ in range(rng.randrange(4))]
        offset = rng.choice([-2, -1, 0, 1, 2, 4])
        depth = rng.randrange(5)
        expected = reference_subst(obj, replacements, offset, depth, formula)
        actual = kernel.subst(copy.deepcopy(obj), copy.deepcopy(replacements) + [offset],
                              depth, formula)
        if actual != expected:
            raise AssertionError(("substitution", obj, replacements, offset, depth,
                                  formula, expected, actual))
        substitution_checks += 1
    if kernel.subst.__defaults__[0] != [1]:
        raise AssertionError("The read-only default substitution environment was mutated")

    # Externally evaluate simple accepted equalities at several environments.
    def value(t, environment):
        if type(t) is int:
            return 0 if t == 0 else environment[t]
        if t[0] == "s":
            return 1 + value(t[1], environment)
        raise ValueError("Only the explicitly small test fragment is evaluated")

    small = [0, succ(0), succ(succ(0)), 1, 2, -1, succ(1), succ(2), succ(-1)]
    seed_streams = [reflexivity(t) for t in small] + [q_stream]
    false_equation_checks = 0
    accepted_equations = 0
    valuations = [{1: i, 2: j, -1: k} for i, j, k in itertools.product(range(3), repeat=3)]
    for s, t, stream in itertools.product(small, small, seed_streams):
        actual = accept(eq(s, t), stream)
        if actual:
            accepted_equations += 1
            if not all(value(s, env) == value(t, env) for env in valuations):
                raise AssertionError(("accepted false equality", s, t, stream))
        false_equation_checks += 1

    # Cross the real command-line boundary, not only an imported convenience API.
    cli_cases = 0
    with tempfile.TemporaryDirectory(prefix="ipra-independent-audit-") as temporary:
        for name in ("Q_coordinate_1_canonical", "Q_slot_2_closed_existential_rejected",
                     "Q_slot_1_closed_existential_accepted", "existential_guard_exact",
                     "existential_guard_wrong_slot", "existential_elimination_eigenvariable_escape",
                     "existential_elimination_valid", "false_equation_rejected"):
            path = Path(temporary) / (name + ".json")
            path.write_text(json.dumps(witnesses[name]), encoding="utf-8")
            result = subprocess.run([sys.executable, str(checker_path), str(path)],
                                    text=True, capture_output=True, timeout=10)
            wanted = next(c["expected"] for c in cases if c["name"] == name)
            if (result.returncode == 0) != wanted or result.stdout.strip() != ("ACCEPT" if wanted else "REJECT"):
                raise AssertionError(("CLI disagreement", name, result.returncode, result.stdout, result.stderr))
            cli_cases += 1
        malformed_json = Path(temporary) / "malformed.json"
        malformed_json.write_text("[not-json", encoding="utf-8")
        result = subprocess.run([sys.executable, str(checker_path), str(malformed_json)],
                                text=True, capture_output=True, timeout=10)
        if result.returncode == 0 or result.stdout.strip() != "REJECT":
            raise AssertionError("Malformed JSON was not rejected")
        cli_cases += 1
        for i, invalid_root in enumerate([
                None, True, 0, {}, [], [eq(0, 0)],
                [eq(0, 0), [None], [eq(0, 0)]],  # No supplied root context.
                [eq(0, 0), {}], [eq(0, 0), True], [eq(0, 0), None]]):
            path = Path(temporary) / f"invalid_root_{i}.json"
            path.write_text(json.dumps(invalid_root), encoding="utf-8")
            result = subprocess.run([sys.executable, str(checker_path), str(path)],
                                    text=True, capture_output=True, timeout=10)
            if result.returncode == 0 or result.stdout.strip() != "REJECT":
                raise AssertionError(("Invalid root certificate accepted", invalid_root))
            cli_cases += 1

    if args.examples:
        args.examples.mkdir(parents=True, exist_ok=True)
        for name, certificate in witnesses.items():
            (args.examples / (name + ".json")).write_text(json.dumps(certificate, indent=2) + "\n")
    output = {
        "checker_sha256": hashlib.sha256(checker_path.read_bytes()).hexdigest(),
        "all_passed": True,
        "targeted_rule_and_malformed_cases": len(cases),
        "targeted_acceptances": sum(c["expected"] for c in cases),
        "targeted_rejections": sum(not c["expected"] for c in cases),
        "independent_substitution_checks": substitution_checks,
        "small_equality_certificate_checks": false_equation_checks,
        "accepted_small_equalities": accepted_equations,
        "valuations_per_small_equality": len(valuations),
        "command_line_checks": cli_cases,
        "notes": [
            "Q elimination ignores its second instruction field and always uses free index 1.",
            "Wrong-slot tests require a changed conclusion; rejecting a payload of 2 alone would be incorrect.",
            "Unused proof-stream prefixes and inert instruction fields are explicitly permitted.",
            "Testing supplies evidence for the implementation; it does not formalize the metatheorems."
        ],
        "cases": cases,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in output.items() if k != "cases"}, indent=2))


if __name__ == "__main__":
    main()
