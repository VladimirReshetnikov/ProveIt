"""Reproduce translation tests; not part of theorem acceptance.

Usage: python3 validate_compiler.py SOURCE_ROOT [OUTPUT_DIRECTORY]
SOURCE_ROOT contains reference_unary.py and source_examples/.
"""

from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import sys

import compile_fixed


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    root = Path(__file__).resolve().parent
    source_root = Path(sys.argv[1])
    output = Path(sys.argv[2]) if len(sys.argv) == 3 else root / "compiler_results"
    output.mkdir(parents=True, exist_ok=True)
    reference = load("source_unary_reference", source_root / "reference_unary.py")
    checker = load("variable_specialization_checker", root / "checker.py")
    cases = {
        "identity": ({}, []),
        "successors": ({1: ["s", 2], 2: ["s", 0], 3: 7}, []),
        "recursion_and_rigid": ({
            1: ["r", ["s", 3], ["s", 2], ["s", 1]],
            2: -7,
            3: ["s", 0],
        }, []),
        "nested_binders": ({
            1: ["r", ["s", -7], ["s", 0], ["r", 2, 1, ["s", 3]]],
            2: ["r", 1000, 0, ["r", 1, 2, ["s", 4]]],
        }, []),
        "context_extension": ({1: ["s", -1], 2: ["r", 3, -2, 2]}, [
            ["q", ["=", 1, 1]],
            ["ex", ["=", 1, ["s", 0]]],
        ]),
    }
    rows = []
    for source_path in sorted((source_root / "source_examples").rglob("*.json")):
        source = json.loads(source_path.read_text())
        relative = source_path.relative_to(source_root / "source_examples")
        require(reference.check(*deepcopy(source)), str(relative) + ": source rejected")
        for label, (images, extra) in cases.items():
            document, counts = compile_fixed.compile_document(source, images, extra)
            goal, stream, *context = document
            checker.p = deepcopy(stream)
            require(checker.check(goal, *context), str((relative, label)) + ": target rejected")
            require(not checker.p, str((relative, label)) + ": unconsumed canonical cells")
            destination = output / label / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(json.dumps(document, separators=(",", ":")) + "\n")
            rows.append({
                "source": str(relative), "substitution": label,
                "source_accepted": True, "target_accepted": True,
                "remaining_cells": 0, "assumptions": len(context),
                "instructions": len(stream), "counts": counts,
            })
    result = {
        "source_proofs": len({row["source"] for row in rows}),
        "substitutions": len(cases), "translations": len(rows),
        "expanded_closure_eliminations": sum(
            row["counts"]["expanded_closure_elimination"] for row in rows),
        "public_theorem_documents": sum(not row["assumptions"] for row in rows),
        "all_accepted": True, "all_canonical_streams_exhausted": True,
        "rows": rows,
    }
    (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "rows"}, indent=2))


if __name__ == "__main__":
    main()
