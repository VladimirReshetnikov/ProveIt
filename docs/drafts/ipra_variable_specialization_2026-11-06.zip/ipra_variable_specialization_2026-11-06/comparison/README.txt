PINNED COMPARISON
=================

Repository: VladimirReshetnikov/ProveIt
Commit: 9e8e3161b0dffb54fceb0b75ee818cc9e4ed2b10
Directory at that commit: docs/drafts

The snapshot contains exactly the 16 checker*.py files at the package
roots of the six ZIP archives present in that directory. The older
comparison sources nested inside those archives are excluded. Every
included program is copied byte for byte. The snapshot includes strict,
demand, theorem-only, open-context, prefix, and exact-stack variants;
thus the baseline is deliberately the coordinatewise minimum of all
these variants, not just a convenient strict variant.

SHORT ARCHIVE IDS
-----------------
D0  ipra_unary_stack_2026-11-06 (1).zip
D1  ipra_unary_stack_2026-11-06 (2).zip
D2  ipra_unary_stack_2026-11-06(1).zip
D3  ipra_unary_stack_2026-11-06(2).zip
D4  ipra_unary_stack_2026-11-06.zip
D5  ipra_unary_stream_2026-11-06.zip

The spaces before parentheses in D0/D1 are significant.
Program suffixes: none = checker.py; D = checker_demand.py;
E = checker_exact.py; O = checker_open.py; OD = checker_open_demand.py;
T = checker_named_table.py. A source file's exact name and archive member
are recorded in manifest.json.

REPRODUCE
---------
From the package directory, run:

    python3 comparison/measure.py

The script always reads the candidate at the package root, checker.py,
independently of the current working directory. It verifies all 16 source
SHA-256 values and byte lengths, the exact source-file set, the retained
license, and the pinned corpus identity before measuring anything.
It parses source as syntax; it does not import or execute any checker.

Outputs are written to results/ at the package root:

    metrics.json          complete metadata, all rows, minima, candidate
    comparison.csv        the 16 source rows and candidate
    comparison_table.tex  the 16 source rows, minima, and candidate
    numbers.tex           numerical macros used by the report

The default command exits with failure unless the candidate strictly
beats the baseline in all three declared whole-program measures. The
core comparison is reported separately as a diagnostic. During package
construction, --baseline-only measures the snapshot without requiring a
candidate; this mode does not certify any candidate improvement.

MEASURES
--------
The algorithm preserves the source drafts' definitions:

1. Parse with Python ast.parse; remove leading module, function, async
   function and class docstrings; normalize with ast.unparse plus one LF.
2. Count significant Python tokenize tokens of the normalized source,
   ignoring encoding, comments, newlines, indentation, and end marker.
3. Count every ast.walk node in the non-docstring program.
4. Count UTF-8 bytes of the normalized source.

The three claims are normalized tokens, AST nodes, and normalized bytes.
The whole-program boundary includes imports, syntax handling, checking,
file input, success/failure output, and exception handling as present in
each source. Source byte lengths in manifest.json serve only to identify
the pinned bytes; there is no raw-source-byte size claim.

For the separately reported core diagnostic, remove only top-level
imports and top-level if statements whose test contains __name__, using
the same procedure for every source and the candidate. The script
records the Python implementation and version because ast.unparse is a
versioned normalizer.

The verified current minima are 505 normalized tokens, 510 AST nodes,
and 1554 normalized bytes, all attained by D2D. Core minima are 447,
444, and 1292, likewise attained by D2D. The older minima quoted within
the source reports refer to earlier corpora and are not reused here.

PROVENANCE
----------
manifest.json records each original ZIP path, size, Git blob SHA,
SHA-256, pinned URL, exact archive member, copied source path, source
SHA-256, and source byte length. During snapshot construction the six
ZIP Git blob identities and sizes were recomputed, and every copied
source was compared with its exact ZIP member. The six original ZIPs
are not required for offline measurement because the source files are
included. The supplied source license is retained verbatim.

The comparison is a finite observed envelope. It is not an absolute
lower-bound theorem for iPRA presentations or proof-checking programs.
