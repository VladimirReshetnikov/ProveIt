"""Independent acceptance, scope, and regression checks; never imported by the kernel."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


KERNEL = load("target_kernel", ROOT / "checker.py")
OLD = load("old_strict_kernel", ROOT / "comparison/sources/draft2/checker.py")
SOURCE = load("source_tree_kernel", ROOT / "reference/reference_unary.py")
COMPILER = load("untrusted_compiler", ROOT / "compile_fixed.py")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def target_accepts(document, allow_context=False):
    try:
        goal, stream, *context = deepcopy(document)
        if context and not allow_context:
            return False
        KERNEL.p = stream
        return bool(KERNEL.check(goal, *context))
    except Exception:
        return False


def old_syntax(value):
    if isinstance(value, list):
        return [old_syntax(x) for x in value]
    return "u" if value == "q" else value


def project_to_old(document):
    """Every active Q elimination is the old witness-1 instance."""
    goal, stream, *context = deepcopy(document)
    for instruction in stream:
        if (isinstance(instruction, list) and len(instruction) == 2
                and isinstance(instruction[0], list) and instruction[0]
                and instruction[0][0] == "q"):
            instruction[1] = 1
    return old_syntax([goal, stream, *context])


def replay_old(document):
    goal, stream, *context = project_to_old(document)
    return OLD.check(goal, stream, context)


def cli(document, optimized=False, raw=False):
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", encoding="utf-8") as f:
        f.write(document if raw else json.dumps(document))
        f.flush()
        command = [sys.executable, *(["-O"] if optimized else []),
                   str(ROOT / "checker.py"), f.name]
        result = subprocess.run(command, capture_output=True, text=True, timeout=30)
    require(result.returncode in (0, 1), "Unexpected process exit: " + repr(result))
    expected = "ACCEPT\n" if result.returncode == 0 else "REJECT\n"
    require(result.stdout == expected and not result.stderr, "Unexpected CLI output")
    return result.returncode == 0


def small_examples():
    examples = ROOT / "examples/basic"
    examples.mkdir(parents=True, exist_ok=True)
    eq = ["=", ["r", 0, 0, 0], 0]
    body = ["=", ["r", 0, 1, 0], 1]
    closure = ["q", body]
    q_stream = [[], [], [], [closure, None]]
    docs = {
        "recursion_zero": [eq, [[]]],
        "existence_of_rigid_parameter": [["ex", ["=", 1, -7]], [None, [-7]]],
        "first_variable_specialization": [body, q_stream],
        "retained_compound_base": [["q", ["ex", ["=", 1, 1]]], [None, []]],
    }
    # An ordinary, unrestricted specialization of a quantified matrix.
    # Its target expansion has equality transport across an existential.
    source_body = ["ex", ["=", 1, 2]]
    source_major = ["u", source_body]
    witness = ["r", ["s", 2], ["s", 0], ["s", 1]]
    source_goal = SOURCE.subst(source_body, [witness, -1])
    source_proof = [source_major, [[["s", 1], None]], witness, [0, None]]
    source = [source_goal, source_proof]
    require(SOURCE.check(*deepcopy(source)), "Constructed source proof failed")
    translated, counts = COMPILER.compile_document(source)
    docs["compound_term_specialization"] = translated
    (examples / "compound_term_specialization_source.json").write_text(
        json.dumps({"source_document": source, "note": "Source-tree format; use compile_fixed.py."}, indent=2) + "\n")
    rows = []
    for name, document in docs.items():
        require(target_accepts(document), name + ": target rejected")
        require(replay_old(document), name + ": old strict replay rejected")
        path = examples / (name + ".json")
        path.write_text(json.dumps(document, indent=2) + "\n")
        rows.append({"name": name, "accepted": True, "instructions": len(document[1])})
    return docs, rows, counts


def adversarial_cases():
    eq = ["=", ["r", 0, 0, 0], 0]
    body = ["=", ["r", 0, 1, 0], 1]
    closure = ["q", body]
    exists0 = ["ex", ["=", 1, 0]]
    compound = ["ex", ["=", 1, 2]]
    cases = [
        ("valid_computation", [eq, [[]]], True),
        ("contradiction", [["=", 0, ["s", 0]], [None]], False),
        ("wrong_computation", [["=", ["r", 0, 0, 0], ["s", 0]], [[]]], False),
        ("wrong_successor_update", [["=", ["r", ["s", 0], 0, 1], ["s", 0]], [[]]], False),
        ("unevaluated_counter", [["=", ["r", 1, 0, 0], 0], [[]]], False),
        ("bool_leaf", [["=", False, 0], [None]], False),
        ("float_leaf", [["=", 0.0, 0], [None]], False),
        ("unknown_constructor", [["unknown", 0, 0], [None]], False),
        ("wrong_equation_arity", [["=", 0], [None]], False),
        ("wrong_successor_arity", [["=", ["s", 0, 0], 0], [None]], False),
        ("wrong_recursor_arity", [["=", ["r", 0, 0], 0], [None]], False),
        ("formula_in_term", [["=", exists0, 0], [None]], False),
        ("term_in_formula", [["q", 0], [[]]], False),
        ("ill_sorted_unused_update", [["=", ["r", 0, 0, ["=", 1, 2]], 0], [[]]], False),
        ("exhausted_stream", [eq, []], False),
        ("non_stream", [eq, {}], False),
        ("existential_escape", [["=", 1, 0], [None, None, [0], [exists0, None]]], False),
        ("existential_capture", [["ex", ["=", 1, 2]], [None, [0]]], False),
        ("compound_IH_forbidden", [["q", compound], [None, [["s", 2]], None, [compound, None], []]], False),
        ("invalid_atomic_step", [["q", ["=", 1, 0]], [None, []]], False),
        ("invalid_equality_motive", [eq, [None, [], [eq, 0]]], False),
        ("invalid_unused_existential_witness", [["ex", eq], [[], [False]]], False),
        ("first_coordinate", [body, [[], [], [], [closure, None]]], True),
        ("second_coordinate_not_primitive", [["=", ["r", 0, 2, 0], 2], [[], [], [], [closure, 2]]], False),
        ("zero_not_primitive_specialization", [["=", ["r", 0, 0, 0], 0], [[], [], [], [closure, 0]]], False),
        ("unused_Q_metadata", [body, [[], [], [], [closure, {"metadata": False}]]], True),
        ("unread_prefix", [eq, [{"metadata": "inert"}, []]], True),
        ("forged_external_assumption", [["=", 1, 0], [None], ["=", 1, 0]], False),
        ("extra_public_field", [eq, [[]], []], False),
        ("empty_document", [], False),
        ("non_document", {"goal": eq}, False),
    ]
    rows = []
    for name, document, wanted in cases:
        for optimized in (False, True):
            got = cli(document, optimized)
            require(got == wanted, name + ": unexpected CLI result")
        if wanted:
            require(replay_old(document), name + ": old strict replay rejected")
        rows.append({"name": name, "accepted": wanted, "normal_and_optimized": True})
    for name, raw in [("malformed_JSON", "["), ("trailing_JSON", "[0,[]] []")]:
        for optimized in (False, True):
            require(not cli(raw, optimized, raw=True), name)
        rows.append({"name": name, "accepted": False, "normal_and_optimized": True})
    return rows


# Independent scope oracle adapted from draft2's named-binder validation.
# It resolves bound occurrences to unique object names, substitutes free
# names, then re-encodes. It does not reproduce the kernel's index arithmetic.
def decode(a, context=(), formula=True):
    if not formula and type(a) is int:
        if a == 0:
            return ("zero",)
        if a < 0:
            return ("rigid", a)
        return ("bound", context[-a]) if a <= len(context) else ("free", a - len(context))
    tag, *children = a
    widths = ({"=": (0, 0), "q": (1,), "ex": (1,)} if formula
              else {"s": (0,), "r": (0, 0, 2)})[tag]
    out = []
    for child, width in zip(children, widths, strict=True):
        names = tuple(object() for _ in range(width))
        out.append((names, decode(child, context + tuple(reversed(names)), width == 1)))
    return ("node", tag, tuple(out))


def encode(a, context=()):
    tag, *parts = a
    if tag == "zero":
        return 0
    if tag == "rigid":
        return parts[0]
    if tag == "free":
        return len(context) + parts[0]
    if tag == "bound":
        return context[::-1].index(parts[0]) + 1
    constructor, children = parts
    return [constructor, *(encode(child, context + tuple(reversed(names)))
                           for names, child in children)]


def transform_named(a, replacements, delta):
    tag, *parts = a
    if tag == "free":
        i = parts[0]
        return replacements[i - 1] if i <= len(replacements) else ("free", i + delta)
    if tag != "node":
        return a
    constructor, children = parts
    return ("node", constructor, tuple((names, transform_named(child, replacements, delta))
                                        for names, child in children))


def reference_subst(a, env, depth, formula):
    protected = tuple(object() for _ in range(depth))
    named = decode(a, protected, formula)
    replacements = [decode(term, (), False) for term in env[:-1]]
    return encode(transform_named(named, replacements, env[-1]), protected)


def scoped_substitution():
    rng = random.Random(20261106)

    def term(depth=0):
        if depth >= 4 or rng.randrange(3) == 0:
            return rng.choice([0, 1, 2, 3, 5, 9, 1000, -1, -7])
        if rng.randrange(2) == 0:
            return ["s", term(depth + 1)]
        return ["r", term(depth + 1), term(depth + 1), term(depth + 1)]

    def formula(depth=0):
        if depth >= 4 or rng.randrange(2) == 0:
            return ["=", term(), term()]
        return [rng.choice(["q", "ex"]), formula(depth + 1)]

    for _ in range(2400):
        is_formula = bool(rng.randrange(2))
        expr = formula() if is_formula else term()
        k = rng.randrange(4)
        env = [term() for _ in range(k)] + [rng.randrange(-k, 4)]
        depth = rng.randrange(4)
        wanted = reference_subst(expr, env, depth, is_formula)
        got = KERNEL.subst(expr, env, depth, is_formula)
        require(got == wanted, "Named scope oracle mismatch")
    trap = ["r", 1, 0, 3]
    require(KERNEL.subst(trap, [1, -1], formula=False) == trap, "Recursor capture")
    trap = ["ex", ["=", 2, -7]]
    require(KERNEL.subst(trap, [1, -1]) == trap, "Quantifier capture")
    before = deepcopy(KERNEL.subst.__defaults__)
    KERNEL.subst(["q", ["=", 1, 2]])
    require(before == KERNEL.subst.__defaults__, "Default environment was mutated")
    return {"seed": 20261106, "random_named_oracle_cases": 2400,
            "explicit_capture_cases": 2, "default_environment_unchanged": True}


def translation_replay():
    root = ROOT / "examples/translations"
    summary = json.loads((root / "results.json").read_text())
    cli_count = 0
    for row in summary["rows"]:
        path = root / row["substitution"] / row["source"]
        document = json.loads(path.read_text())
        require(target_accepts(document, allow_context=True), str(path) + ": target replay failed")
        require(replay_old(document), str(path) + ": independent old-kernel replay failed")
        if not row["assumptions"]:
            for optimized in (False, True):
                require(cli(document, optimized), str(path) + ": public CLI failed")
            cli_count += 1
    return {"translated_sequents": len(summary["rows"]),
            "old_strict_replays": len(summary["rows"]),
            "public_theorems_tested_in_both_modes": cli_count}


def mutation_replay(docs):
    rng = random.Random(6062026)
    originals = list(docs.values())
    accepted = 0
    replacements = [None, False, 0.0, {}, [], 0, 1, -9, ["s", 0], ["bad", 0]]

    def paths(node, prefix=()):
        result = [prefix]
        if isinstance(node, list):
            for i, child in enumerate(node):
                result.extend(paths(child, prefix + (i,)))
        return result

    for _ in range(256):
        document = deepcopy(rng.choice(originals))
        path = rng.choice(paths(document))
        replacement = deepcopy(rng.choice(replacements))
        if not path:
            document = replacement
        else:
            parent = document
            for i in path[:-1]:
                parent = parent[i]
            parent[path[-1]] = replacement
        if target_accepts(document):
            accepted += 1
            require(replay_old(document), "Accepted mutation failed independent old-kernel replay")
    return {"seed": 6062026, "mutations": 256,
            "accepted_and_independently_replayed": accepted}


def main():
    docs, basic, macro_counts = small_examples()
    result = {
        "status": "PASS", "python_version": sys.version.split()[0],
        "basic_examples": basic, "compound_specialization_macro": macro_counts,
        "adversarial_cases": adversarial_cases(),
        "scoped_substitution": scoped_substitution(),
        "translations": translation_replay(),
        "mutation_replay": mutation_replay(docs),
        "formalization_status": "Mathematical metatheorems are not Lean/Rocq formalizations.",
    }
    (ROOT / "results/validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "basic_examples": len(basic),
                      "adversarial_cases": len(result["adversarial_cases"]),
                      **result["scoped_substitution"], **result["translations"],
                      **result["mutation_replay"]}, indent=2))


if __name__ == "__main__":
    main()
