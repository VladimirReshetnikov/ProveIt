iPRA WITH SPECIALIZATION AT ONE VARIABLE
=======================================
Prepared for Vladimir Reshetnikov, 6 November 2026 (Pacific time).

Read report.pdf for the complete mathematical construction. report.tex and
sections/*.tex contain the full LaTeX source. This package is self-contained;
no network connection is needed to reproduce its checks or build its PDF.

RESULT
------
The primitive closure-elimination rule specializes only at the first ambient
numerical variable. Arbitrary term specialization is recovered by existential
equality witnesses and formula transport. A strengthened induction on the
original unrestricted derivation proves exact equivalence of consequence
relations, without first assuming numerical weakening or substitution in the
restricted system.

Full first-order intuitionistic PRA is recovered. Both ordinary composite
interpretations have the identity isomorphism on the whole number domain.
The arithmetic and logical basis is inherited from the cited ProveIt drafts;
the new contribution is the restriction theorem and its smaller implementation.

Whole-program normalized measures (CPython 3.12.14):
                         Current minimum    New checker
  significant tokens           505              497
  executable AST nodes         510              509
  UTF-8 bytes                 1554             1553

The current minimum includes all 16 complete root checkers in the six draft
archives at commit 9e8e3161b0dffb54fceb0b75ee818cc9e4ed2b10. The improvement
is strict but small; it is not an absolute shortest-program theorem.

QUICK START
-----------
  python3 checker.py examples/basic/compound_term_specialization.json
  python3 reproduce.py --checks-only
  python3 reproduce.py

The last command also compiles report.pdf using PDFLaTeX. Python 3.10 or
later is required. The recorded source-normalization measurements use
CPython 3.12.14. FORMAT.txt specifies the exact certificate syntax.

MAIN FILES
----------
  checker.py              The entire acceptance kernel; only json/sys imported.
  compile_fixed.py        Untrusted source-tree to restricted-stream compiler.
  validate_compiler.py    Replays 31 source proofs under five configurations.
  validate.py             Public-input, scope, mutation, and old-kernel replay.
  reproduce.py            Runs validation, comparison, audit, and TeX build.
  FORMAT.txt              Complete public grammar and instruction specification.
  comparison/             Six-archive manifest, 16 exact sources, measurements.
  reference/              Unchanged source checker and 31 inherited source proofs.
  examples/translations/  155 compiled sequent documents and their result table.
  examples/basic/         Small public examples, including the new macro.
  audit/                  Separately prepared implementation audit and results.
  results/                Reproducible measurements and validation evidence.
  MANIFEST.sha256         Checksums of the deliverable files.

PUBLIC THEOREMS VERSUS INTERNAL SEQUENTS
--------------------------------------
The public checker accepts exactly [goal, stream], with an empty root context.
Forty translated documents have this shape and are public theorem certificates.
Some other translation documents contain extra context fields for the internal
sequent tests; these are intentionally NOT public theorem certificates. The
per-file rows in examples/translations/results.json identify the assumptions.

The example ending _source.json is a labelled source-proof record, not a
target certificate. It is included to make the macro example reviewable.

VALIDATION SCOPE
----------------
155/155 source translations accepted and independently replayed against the
frozen old strict checker; all canonical streams exhausted.
40 theorem documents passed both normal and -O command-line execution.
33 public adversarial/policy cases passed in both modes.
2,400 named-binder substitution comparisons and two explicit capture traps
passed. Of 256 seeded mutations, all 28 accepted inputs replayed independently.
The separate audit adds 181 targeted cases, 2,500 substitution comparisons,
810 small equation/certificate checks, and 19 command-line checks.

These tests supplement the mathematical proofs. The metatheorems and checker
have not been formalized in Lean or Rocq. No global minimality claim is made.

SOURCE ATTRIBUTION
------------------
See ATTRIBUTION.txt, the bibliography in report.pdf, reference/manifest.json,
and comparison/manifest.json. The source archives' MIT No Attribution license
is retained verbatim in LICENSE_SOURCE.txt.
