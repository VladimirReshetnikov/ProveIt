"""Untrusted proof compiler from the inherited unrestricted unary calculus.

Input is [goal, source_proof_tree, *assumptions], using either q or u for
the unary closure. Output is [goal, reverse_preorder_stream, *assumptions].
Only assumption-free output is a public theorem certificate for checker.py.

The compiler deliberately expands EVERY unrestricted closure elimination.
Its recursive invariant quantifies over an arbitrary numerical substitution
and an arbitrary extension of the translated assumption context. In the
elimination case it recompiles the ORIGINAL smaller premise derivations
under the lifted substitution. It never assumes that an already compiled
target proof can be weakened, shifted, or substituted.

This file is not imported by checker.py and is not part of acceptance.
"""

from copy import deepcopy
import json
from pathlib import Path
import sys


SCOPES = {
    False: {"s": (0,), "r": (0, 0, 2)},
    True: {"=": (0, 0), "q": (1,), "u": (1,), "ex": (1,)},
}


def renamed(value):
    """Rename the source closure tag; other finite JSON data are preserved."""
    if isinstance(value, list):
        return [renamed(x) for x in value]
    return "q" if value == "u" else value


def raise_free(expr, amount=1, protected=0, formula=True):
    """Independent, explicit de Bruijn raising, including recursion binders."""
    if not formula and type(expr) is int:
        return expr + amount if expr > protected else expr
    tag, *children = expr
    widths = SCOPES[formula][tag]
    if len(children) != len(widths):
        raise ValueError("Malformed source syntax")
    return [tag, *(raise_free(x, amount, protected + width, width == 1)
                   for x, width in zip(children, widths))]


def map_free(expr, image, protected=0, formula=True):
    """Capture-avoiding simultaneous substitution of positive free indices."""
    if not formula and type(expr) is int:
        if expr <= protected:
            return expr
        return raise_free(image(expr - protected), protected, formula=False)
    tag, *children = expr
    widths = SCOPES[formula][tag]
    if len(children) != len(widths):
        raise ValueError("Malformed source syntax")
    return [tag, *(map_free(x, image, protected + width, width == 1)
                   for x, width in zip(children, widths))]


def lifted(image):
    """Extend a substitution across one fresh numerical variable."""
    return lambda i: 1 if i == 1 else raise_free(image(i - 1), formula=False)


def instance(body, term):
    """Remove the distinguished first slot of a formula matrix."""
    return map_free(body, lambda i: term if i == 1 else i - 1)


def retain_slot(body, term):
    """Replace its first free slot without removing that slot from scope."""
    return map_free(body, lambda i: term if i == 1 else i)


def hypothesis(goal, context):
    if goal not in context:
        raise ValueError("Source leaf is not a hypothesis")
    return [None]


def compile_node(goal, proof, source_context, image, target_context, counts):
    """Translate a source derivation under a substitution/context extension."""
    target = map_free(goal, image)
    if any(map_free(a, image) not in target_context for a in source_context):
        raise ValueError("Translation context invariant failed")

    # Every source constructor below decreases source proof-tree height.
    # The target context may grow; this is part of the induction assertion.
    if goal[0] == "q" and isinstance(proof, list) and len(proof) == 1:
        body = goal[1]
        target_body = target[1]
        source_added = [retain_slot(body, 0)] + ([body] if body[0] == "=" else [])
        target_added = [retain_slot(target_body, 0)] + ([target_body] if target_body[0] == "=" else [])
        child = compile_node(
            retain_slot(body, ["s", 1]), proof[0],
            [raise_free(a) for a in source_context] + source_added,
            lifted(image), [raise_free(a) for a in target_context] + target_added,
            counts,
        )
        counts["closure_introduction"] += 1
        return child + [[]]

    if goal[0] == "ex" and isinstance(proof, list) and len(proof) == 2:
        witness, child_proof = proof
        target_witness = map_free(witness, image, formula=False)
        source_added = ["=", 1, raise_free(witness, formula=False)]
        target_added = ["=", 1, raise_free(target_witness, formula=False)]
        child = compile_node(
            goal[1], child_proof,
            [raise_free(a) for a in source_context] + [source_added],
            lifted(image), [raise_free(a) for a in target_context] + [target_added],
            counts,
        )
        counts["existential_introduction"] += 1
        return child + [[target_witness]]

    if proof == "r":
        counts["computation"] += 1
        return [[]]

    if not isinstance(proof, list) or len(proof) not in (3, 4):
        counts["hypothesis"] += 1
        return hypothesis(target, target_context)

    major, major_proof, *annotations = proof
    tag, *parts = major
    mapped_major = map_free(major, image)

    if tag == "ex":
        if len(annotations) != 1:
            raise ValueError("Malformed existential elimination")
        major_stream = compile_node(major, major_proof, source_context,
                                    image, target_context, counts)
        minor_stream = compile_node(
            raise_free(goal), annotations[0],
            [raise_free(a) for a in source_context] + parts,
            lifted(image),
            [raise_free(a) for a in target_context] + mapped_major[1:],
            counts,
        )
        counts["existential_elimination"] += 1
        return minor_stream + major_stream + [[mapped_major, None]]

    annotation, minor_proof = annotations
    if tag == "=":
        motive = map_free(annotation, lifted(image))
        major_stream = compile_node(major, major_proof, source_context,
                                    image, target_context, counts)
        minor_stream = compile_node(instance(annotation, parts[0]), minor_proof,
                                    source_context, image, target_context, counts)
        if instance(motive, mapped_major[2]) != target:
            raise ValueError("Source equality conclusion mismatch")
        counts["equality_elimination"] += 1
        return minor_stream + major_stream + [[mapped_major, motive]]

    if tag != "q":
        raise ValueError("Unknown source elimination")

    witness = map_free(annotation, image, formula=False)
    if instance(mapped_major[1], witness) != target:
        raise ValueError("Source closure conclusion mismatch")

    # In the target, first prove exists y (y = witness) with the guarded
    # existential-introduction rule and its own local equality hypothesis.
    # Then open that existential with a genuinely fresh coordinate 1.
    equality = ["=", 1, raise_free(witness, formula=False)]
    existential = ["ex", equality]
    extended = [raise_free(a) for a in target_context] + [equality]
    scope_image = lambda i: raise_free(image(i), formula=False)

    # Recurse on ORIGINAL source premises under the fresh scope. This is
    # the point that avoids a circular appeal to target weakening.
    major_stream = compile_node(major, major_proof, source_context,
                                scope_image, extended, counts)
    base_stream = compile_node(instance(parts[0], 0), minor_proof,
                               source_context, scope_image, extended, counts)
    scoped_major = raise_free(mapped_major)
    at_fresh = instance(scoped_major[1], 1)
    if at_fresh != mapped_major[1]:
        raise ValueError("Fresh-coordinate identity failed")
    variable_stream = base_stream + major_stream + [[scoped_major, None]]

    # Transport B(y) along y = witness in the full formula motive B(z).
    motive = scoped_major[1]
    if instance(motive, equality[2]) != raise_free(target):
        raise ValueError("Transport under fresh scope failed")
    continuation = variable_stream + [None, [equality, motive]]
    existence_stream = [None, [witness]]
    counts["expanded_closure_elimination"] += 1
    return continuation + existence_stream + [[existential, None]]


def compile_document(document, images=None, extra_context=()):
    """Compile a canonical source sequent and return it with rule counts.

    images optionally maps positive free indices to target terms; all other
    indices are left fixed. It exercises the stronger induction invariant.
    extra_context may be any additional well-formed target assumptions.
    """
    goal, proof, *context = renamed(deepcopy(document))
    images = {} if images is None else images
    image = lambda i: images.get(i, i)
    target_context = [map_free(a, image) for a in context] + list(extra_context)
    counts = dict.fromkeys((
        "hypothesis", "computation", "closure_introduction",
        "existential_introduction", "existential_elimination",
        "equality_elimination", "expanded_closure_elimination",
    ), 0)
    stream = compile_node(goal, proof, context, image, target_context, counts)
    return [map_free(goal, image), stream, *target_context], counts


if __name__ == "__main__":
    source = json.loads(Path(sys.argv[1]).read_text())
    document, counts = compile_document(source)
    encoded = json.dumps(document, separators=(",", ":")) + "\n"
    if len(sys.argv) == 3:
        Path(sys.argv[2]).write_text(encoded)
    else:
        sys.stdout.write(encoded)
