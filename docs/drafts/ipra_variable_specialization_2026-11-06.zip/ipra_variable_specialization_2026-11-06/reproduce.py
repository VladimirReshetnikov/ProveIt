"""Reproduce certificates, validation, measurements, and (unless skipped) the PDF."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(*args):
    subprocess.run(args, cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true", help="Skip the TeX compilation.")
    args = parser.parse_args()
    run(sys.executable, "validate_compiler.py", "reference", "examples/translations")
    run(sys.executable, "validate.py")
    run(sys.executable, "audit/audit.py", "--checker", "checker.py",
        "--output", "audit/results.json", "--examples", "audit/certificates")
    run(sys.executable, "comparison/measure.py")
    if not args.checks_only:
        for _ in range(3):
            run("pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex")


if __name__ == "__main__":
    main()
