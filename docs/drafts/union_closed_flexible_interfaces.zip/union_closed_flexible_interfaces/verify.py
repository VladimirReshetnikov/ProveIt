#!/usr/bin/env python3
"""Exact audit of the flexible-interface theorem (Python 3.10+)."""
from itertools import product
from fractions import Fraction
from random import Random
from collections import defaultdict
from math import prod
import json

def require(ok, message):
    if not ok:
        raise AssertionError(message)

def submasks(mask):
    s = mask
    while True:
        yield s
        if s == 0:
            break
        s = (s-1) & mask

def union_closure(edges):
    out = {0}
    for e in edges:
        out |= {x | e for x in out}
    return out

def bound(k, options, t):
    """Use the actual crossing options, not a single chosen representative."""
    m = (1 << k)-1
    r = len(options)
    # For J proper, C[J] records all ordinary labels supportable by J.
    covers = {j: sum(1 << x for x, opts in enumerate(options)
                     if any(i & j == i for i in opts))
              for j in range(m)}
    A = sum(any(T & covers[m ^ (1 << i)] == T for i in range(k))
            for T in range(1 << r))
    B = sum(1 << covers[j].bit_count() for j in range(1, m))
    R = Fraction(A + ((1 << t)-1)*B, 1 << (r+t))
    return R, R/(1+R)

def make(k, options, t, exterior=(), internal=(), extra_flex=()):
    m = (1 << k)-1
    r = len(options)
    cross = [i | (1 << (k+x)) for x, opts in enumerate(options) for i in opts]
    flex = [(1 << i) | (1 << (k+r+z)) for i in range(k) for z in range(t)]
    edges = [m] + cross + flex + [e << k for e in exterior] + list(internal) + list(extra_flex)
    return list(dict.fromkeys(edges))

def audit(k, options, t, exterior=(), internal=(), extra_flex=(), sharp=False, direct=False):
    m = (1 << k)-1
    r = len(options)
    n = k+r+t
    edges = make(k, options, t, exterior, internal, extra_flex)
    C = union_closure(edges)
    # Independently build the original union-closed family of stars.
    generators = [sum(1 << j for j,e in enumerate(edges) if e & (1 << i))
                  for i in range(n)]
    F = union_closure(generators)
    missing = sum(a & m == m for a in C)
    present = len(C)-missing
    require(len(C) == len(F), 'bijection count')
    require(present == sum(bool(a & 1) for a in F), 'marked count')
    R, p = bound(k, options, t)
    require(present * R.denominator >= missing * R.numerator, 'global bound')
    if sharp:
        require(Fraction(present, len(C)) == p, 'sharpness')
    # Exterior core is the union of exterior-only supports contained in A.
    ex = [e << k for e in exterior]
    fibers = defaultdict(lambda: [0, 0])
    for a in C:
        s = 0
        for e in ex:
            if a & e == e:
                s |= e
        fibers[s][int(a & m == m)] += 1
    for s,(pos,neg) in fibers.items():
        remaining = [opts for x,opts in enumerate(options) if not s & (1 << (k+x))]
        local_R,_ = bound(k, remaining, t)
        require(pos * local_R.denominator >= neg * local_R.numerator, 'fiber bound')
    if direct:
        direct_f = set()
        for I in range(1 << n):
            direct_f.add(sum(1 << j for j,e in enumerate(edges) if e & I))
        require(direct_f == F, 'direct original generator enumeration')
    return Fraction(present,len(C)),len(F)

def run():
    counts = defaultdict(int)
    # Exhaustive unique spokes, every exterior family on up to two labels.
    for k in (2,3,4):
        for r in range(3):
            for masks in product(range(1,1 << k), repeat=r):
                opts = [(a,) for a in masks]
                for exterior_mask in range(1 << ((1 << r)-1)):
                    exterior = [e for e in range(1,1 << r) if exterior_mask & (1 << (e-1))]
                    for t in (0,1):
                        audit(k,opts,t,exterior,sharp=not exterior,direct=True)
                        counts['exhaustive_unique'] += 1
    # All alternative crossing lists for two anchors and two ordinary labels.
    choices = [tuple(e for e in range(1,4) if mask & (1 << (e-1))) for mask in range(1,8)]
    for opts in product(choices,repeat=2):
        for exterior_mask in range(8):
            exterior = [e for e in range(1,4) if exterior_mask & (1 << (e-1))]
            for t in (0,1,2):
                audit(2,opts,t,exterior,direct=True)
                counts['exhaustive_alternative'] += 1
    rng = Random(20261125)
    for _ in range(500):
        k = rng.randrange(2,5); r = rng.randrange(0,5); t = rng.randrange(0,3)
        opts = [tuple(sorted(set(rng.randrange(1,1 << k) for _ in range(rng.randrange(1,5))))) for x in range(r)]
        ext = [e for e in range(1,1 << r) if rng.random() < .22]
        internal = [e for e in range(1,(1 << k)-1) if rng.random() < .12]
        extras = [(1 << (k+r+z)) | rng.randrange(1,1 << k) for z in range(t)]
        audit(k,opts,t,ext,internal,extras,direct=True)
        counts['random_general'] += 1
    examples = []
    for k, a, t in [(2,1,0),(2,1,3),(3,1,1),(4,2,1),(4,2,2),(5,1,1),(3,0,1)]:
        opts = [(1 << i,) for i in range(k) for _ in range(a)]
        q = Fraction(1,1 << a)
        A = 1-(1-q)**k
        B = (1+q)**k-1-q**k
        R = (A+((1 << t)-1)*B)/(1 << t)
        require(bound(k,opts,t)[0] == R, 'closed formula')
        p,N = audit(k,opts,t,sharp=True)
        examples.append(dict(k=k,a=a,t=t,frequency=str(p),family_size=N))
    # The large-minimum-member construction in a manageable parameter instance.
    k=4; a=2; t=1; r=k*a
    opts=[(1 << i,) for i in range(k) for _ in range(a)]
    exterior=[(1 << i)|(1 << j) for i in range(r) for j in range(i+1,r)]
    p,N=audit(k,opts,t,exterior,direct=True)
    edges=make(k,opts,t,exterior)
    degrees=[sum(bool(e & (1 << i)) for e in edges) for i in range(k+r+t)]
    require(min(degrees)==4 and min(e.bit_count() for e in edges)==2,'nontrivial example degrees')
    print(json.dumps(dict(tests=dict(counts),sharp_examples=examples,
                          enlarged_example=dict(k=k,a=a,t=t,minimum_generator_size=min(degrees),
                                                frequency=str(p),family_size=N),
                          status='PASS'),indent=2))

if __name__ == '__main__':
    run()
