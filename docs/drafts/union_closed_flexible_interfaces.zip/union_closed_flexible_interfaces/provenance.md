# Provenance and proof status

## Repository review

Accessed via the GitHub connector: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts (main, 2026-11-25). The directory listed 36 ZIP archives (plus .gitkeep). The following 18 archives were inspected at the README and/or LaTeX title/section level by decoding the returned base64 ZIP entries; this is not a claim to have read every proof in every archive:

- union_closed_rank_transport_2026-11-25.zip
- union_closed_transversal_bounds.zip
- union_closed_exact_obstruction_theorems_2026-11-25.zip
- union_closed_marked_abundance.zip
- union_closed_local_abundance.zip
- union_closed_sharp_trace_obstructions_2026-11-25.zip
- union_closed_signature_interfaces_2026-11-25.zip
- union_closed_dense_core_2026-11-25.zip
- union_closed_advances_2026-11-25.zip
- union_closed_frequency_bounds.zip
- union_closed_partial_results.zip
- union_closed_abundance_theorems.zip
- union_closed_partial_theorems_2026-11-25.zip
- union_closed_refinements_2026-11-25.zip
- union_closed_extensions_2026-11-25(1).zip
- union_closed_redundant_core_2026-11-25.zip
- union_closed_exchange_repair_2026-11-25.zip
- union_closed_cycle_certificates.zip

The large `union_closed_structural_theorems.zip` was attempted but no readable entries were recovered by the text-oriented extraction used here. Other archives were listed but not inspected. No repository writes were made.

Closest antecedents:

- Exact obstruction and sharp trace obstruction drafts: canonical incidence types and robust marked-point certificates. This note uses the same general distinct-union perspective, not a new representation claim.
- Exchange repair: local deletion/reconstruction and defects. Here all anchors may be necessary for some ordinary label; flexible pairs generate multiple distinct proper anchor choices.
- Signature interfaces: exterior-independent bounds via signature/rank hypotheses. Here the hypothesis instead restricts crossing supports to one exterior label and adds flexible pairs, giving a different exact counting formula.
- Marked abundance/frequency bounds: prescribed edge endpoints in unions of graph edges. Our graph specialization counts a prescribed edge in unions of graph vertex-stars; points and labels have reversed roles.
- Redundant/dense core: different local sufficient conditions and sharp thresholds. No general logical independence from all earlier criteria is asserted.

## Public sources

- Bruhn, Charbit, Schaudt, Telle, The graph formulation of the union-closed sets conjecture (2015): https://arxiv.org/abs/1212.4175
- Bruhn and Schaudt, The journey of the union-closed sets conjecture (2015).
- Gilmer, A constant lower bound for the union-closed sets conjecture (2022): https://arxiv.org/abs/2211.09055
- Costa and Sadhu, Beyond Liu's 0.382709 threshold for the union-closed sets conjecture (2026 preprint): https://arxiv.org/abs/2610.02295
- General problem statement and known cases: https://en.wikipedia.org/wiki/Union-closed_sets_conjecture

Targeted public searches covered incidence-support generators, local frequency, graph star unions, and current universal bounds. No exact matching theorem was established from the reviewed material; this is a provisional originality assessment, not certified historical priority. The main proof is self-contained and does not rely on the numerical results cited in the introduction. The verifier is supplemental, not a formal proof or peer review.
