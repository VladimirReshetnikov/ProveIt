# Flexible interfaces in union-closed families

Research note, 25 November 2026. Start with `paper.pdf` (nine pages), a compiled, self-contained mathematical manuscript. The general conjecture remains open here.

## Main result

In the marked incidence-support model of the paper, the frequency of the designated ground element is at least `R/(1+R)`, with `R = 2^(-t) A + (1-2^(-t)) B`. The formula uses only the ordinary crossing options and the number of fully flexible exterior labels. It is valid under arbitrary exterior-only supports, also within every canonical exterior-core class. It is attained exactly for the single-option model.

For disjoint ordinary spoke groups of sizes `a_i`, put `q_i=2^(-a_i)`. Then `A=1-product(1-q_i)` and `B=product(1+q_i)-1-product(q_i)`. The resulting half-frequency criterion is sharp for these parameters. Four anchors with two ordinary labels each and one flexible label guarantee at least `543/1055 > 1/2` marked frequency. There are examples with arbitrarily large minimum nonempty member size, without private ground elements. The graph specialization concerns distinct unions of vertex stars, not unions of graph edges.

## Files

- `paper.tex`, `paper.pdf`: complete mathematical proof and compiled PDF.
- `verify.py`, `verification.json`: standard-library exact finite audit and actual output (6,310 exhaustive/random instances plus eight examples).
- `provenance.md`: source comparison and limitations.
- `Makefile`, `SHA256SUMS`: build and integrity commands.

## Reproduce

Requires Python 3.10+ and a standard TeX Live installation with AMS, Latin Modern, geometry, microtype, booktabs, hyperref and enumitem.

```sh
sha256sum -c SHA256SUMS
python3 verify.py > verification-new.json
diff -u verification.json verification-new.json
make pdf
```

PDF metadata can differ on recompilation. The general mathematical results do not depend on the finite audit. No Lean/Rocq formalization or independent expert referee report is supplied. No repository files were changed. Historical priority is provisional: the targeted literature/repository review did not certify the absence of all antecedents.
