"""Reproduce the frozen proof-checker source census without network access.

Run ``python3 measure.py`` from any working directory. Comparator programs
are parsed as data, never imported or executed. The source snapshots and
their hashes are listed in comparison/provenance.json.
"""

import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import tokenize


ROOT = Path(__file__).resolve().parent
FIELDS = ("raw_bytes", "source_tokens", "normalized_tokens", "ast_nodes",
          "normalized_bytes")
INSIGNIFICANT = {
    tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
    tokenize.NEWLINE, tokenize.NL, tokenize.INDENT, tokenize.DEDENT,
}
CONTAINERS = (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)


def is_docstring(node):
    return (isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str))


def docstring_spans(tree, source):
    """Use character columns for tokenize, converting AST's UTF-8 columns."""
    lines = source.splitlines(keepends=True)

    def position(line, byte_column):
        prefix = lines[line - 1].encode("utf-8")[:byte_column]
        return line, len(prefix.decode("utf-8"))

    spans = []
    for node in ast.walk(tree):
        if isinstance(node, CONTAINERS) and node.body and is_docstring(node.body[0]):
            first = node.body[0]
            spans.append((position(first.lineno, first.col_offset),
                          position(first.end_lineno, first.end_col_offset)))
    return spans


def significant_tokens(source, spans=()):
    return sum(
        token.type not in INSIGNIFICANT
        and not any(start <= token.start and token.end <= end
                    for start, end in spans)
        for token in tokenize.generate_tokens(io.StringIO(source).readline)
    )


def strip_docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, CONTAINERS) and node.body and is_docstring(node.body[0]):
            node.body = node.body[1:]


def source_metrics(raw):
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    source_tokens = significant_tokens(source, docstring_spans(tree, source))
    strip_docstrings(tree)
    normalized = ast.unparse(tree) + "\n"
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "raw_bytes": len(raw),
        "source_tokens": source_tokens,
        "normalized_tokens": significant_tokens(normalized),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "physical_lines": len(source.splitlines()),
    }


def measure_entry(entry):
    path = (ROOT / entry["file"]).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError("Source path escapes this package: " + entry["file"])
    metrics = source_metrics(path.read_bytes())
    if metrics["sha256"] != entry["sha256"]:
        raise ValueError("Frozen source hash mismatch: " + entry["file"])
    result = {key: entry[key] for key in ("id", "label", "file") if key in entry}
    return {**result, **metrics}


def minima(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


def savings(candidate, frontier):
    return {
        field: {
            "absolute": frontier[field] - candidate[field],
            "percent": 100 * (frontier[field] - candidate[field]) / frontier[field],
        }
        for field in FIELDS
    }


def latex_escape(text):
    replacements = {
        "\\": r"\textbackslash{}", "&": r"\&", "%": r"\%",
        "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{",
        "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(char, char) for char in text)


def write_table(path, primary, frontier, candidate):
    lines = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Complete checker & Norm. tokens & AST nodes & Norm. bytes \\",
             r"\midrule"]
    for row in primary:
        values = [latex_escape(row["label"]), str(row["normalized_tokens"]),
                  str(row["ast_nodes"]), str(row["normalized_bytes"])]
        lines.append(" & ".join(values) + r" \\")
    lines.append(r"\midrule")
    values = ["Current primary minimum", str(frontier["normalized_tokens"]),
              str(frontier["ast_nodes"]), str(frontier["normalized_bytes"])]
    lines.append(" & ".join(values) + r" \\")
    values = [latex_escape(candidate["label"]), str(candidate["normalized_tokens"]),
              str(candidate["ast_nodes"]), str(candidate["normalized_bytes"])]
    lines.append(" & ".join(r"\textbf{" + value + "}" for value in values) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_macros(path, candidate, primary, expanded, census):
    macros = {
        "CandidateTokens": candidate["normalized_tokens"],
        "CandidateSourceTokens": candidate["source_tokens"],
        "CandidateNodes": candidate["ast_nodes"],
        "CandidateBytes": candidate["normalized_bytes"],
        "CandidateRawBytes": candidate["raw_bytes"],
        "PrimaryMinTokens": primary["normalized_tokens"],
        "PrimaryMinSourceTokens": primary["source_tokens"],
        "PrimaryMinNodes": primary["ast_nodes"],
        "PrimaryMinBytes": primary["normalized_bytes"],
        "PrimaryMinRawBytes": primary["raw_bytes"],
        "ExpandedMinTokens": expanded["normalized_tokens"],
        "ExpandedMinSourceTokens": expanded["source_tokens"],
        "ExpandedMinNodes": expanded["ast_nodes"],
        "ExpandedMinBytes": expanded["normalized_bytes"],
        "ExpandedMinRawBytes": expanded["raw_bytes"],
        "InventoryCount": census["unique_sources"],
        "InventoryOccurrences": census["qualifying_member_occurrences"],
    }
    lines = ["% Generated by measure.py from the frozen source snapshots."]
    lines.extend("\\newcommand{\\" + key + "}{" + str(value) + "}"
                 for key, value in macros.items())
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 or later is required for match syntax.")
    provenance_bytes = (ROOT / "comparison/provenance.json").read_bytes()
    provenance = json.loads(provenance_bytes)
    index_bytes = (ROOT / provenance["github_index_snapshot"]).read_bytes()
    if hashlib.sha256(index_bytes).hexdigest() != provenance["github_index_snapshot_sha256"]:
        raise ValueError("Frozen GitHub directory snapshot hash mismatch")
    candidate = measure_entry(provenance["candidate"])
    primary = [measure_entry(row) for row in provenance["primary_checkers"]]
    cores = [measure_entry(row) for row in provenance["additional_cores"]]
    controls = [measure_entry(row) for row in provenance["matched_controls"]]
    inventory = provenance["embedded_inventory"]
    embedded = [measure_entry(row) for row in inventory["sources"]]
    primary_min = minima(primary)
    expanded_min = minima(primary + cores + embedded)
    below_primary = {field: candidate[field] < primary_min[field] for field in FIELDS}
    below_expanded = {field: candidate[field] < expanded_min[field] for field in FIELDS}
    census = {
        "classification": inventory["classification"],
        "python_member_occurrences": inventory["python_member_occurrences"],
        "qualifying_member_occurrences": inventory["qualifying_member_occurrences"],
        "unique_sources": len(embedded),
        "coordinate_minima": minima(embedded),
        "sources": embedded,
    }
    result = {
        "schema_version": 1,
        "repository": provenance["repository"],
        "commit": provenance["commit"],
        "python_version": sys.version.split()[0],
        "provenance_sha256": hashlib.sha256(provenance_bytes).hexdigest(),
        "all_source_hashes_verified": True,
        "archive_verification": provenance["archive_verification_note"],
        "method": {
            "boundary": "Entire standalone Python source, including validation, rules, arithmetic schemas, falsity conversion, imports, JSON input and CLI.",
            "source_tokens": "Original-source tokens excluding actual initial docstrings, comments, layout, encoding and end markers. Other string literals and redundant parentheses count.",
            "normalized_source": "ast.unparse after removing initial module/class/function docstrings, plus exactly one terminal newline.",
            "normalized_tokens": "Significant tokens of normalized source using the same layout exclusions.",
            "ast_nodes": "All ast.walk nodes after docstring removal, including operator and context nodes.",
            "bytes": "UTF-8 byte counts; raw bytes include comments and docstrings.",
            "runtime": "Python and its standard library are the common runtime. Comparator programs are not imported or executed.",
        },
        "candidate": candidate,
        "primary_checkers": primary,
        "additional_cores": cores,
        "matched_controls": controls,
        "embedded_inventory": census,
        "primary_coordinate_minima": primary_min,
        "expanded_coordinate_minima": expanded_min,
        "candidate_strictly_below_primary": below_primary,
        "candidate_strictly_below_expanded": below_expanded,
        "all_primary_coordinates_improved": all(below_primary.values()),
        "all_expanded_coordinates_improved": all(below_expanded.values()),
        "savings_against_primary": savings(candidate, primary_min),
        "savings_against_expanded": savings(candidate, expanded_min),
        "qualification": "This is a finite source-size comparison, not a global minimality theorem or a soundness certificate for every comparator. Matched controls isolate implementation choices and are not additional pre-existing drafts.",
    }
    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    (results / "metrics.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    write_macros(results / "metrics_macros.tex", candidate, primary_min, expanded_min, census)
    write_table(results / "current_table.tex", primary, primary_min, candidate)
    print(json.dumps({"candidate": candidate,
                      "primary_minima": primary_min,
                      "expanded_minima": expanded_min,
                      "embedded_unique_sources": len(embedded),
                      "all_hashes_verified": True}, indent=2))


if __name__ == "__main__":
    main()
