"""Reproduce measurements, certificate checks, and optionally the PDF."""

import argparse
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    for command in (["measure.py"], ["validation/run_tests.py", "checker.py"]):
        subprocess.run([sys.executable, *command], cwd=ROOT, check=True)
    records = []
    for path in sorted((ROOT / "examples").glob("*.json")):
        if path.name == "provenance.json":
            continue
        result = subprocess.run([sys.executable, "checker.py", str(path)],
                                cwd=ROOT, text=True, capture_output=True)
        good = result.returncode == 0 and result.stdout == "ACCEPT\n" and not result.stderr
        records.append({"example": path.name, "passed": good})
        if not good:
            raise SystemExit(f"Example failed: {path.name}: {result.stdout} {result.stderr}")
    (ROOT / "results" / "examples.json").write_text(json.dumps(records, indent=2) + "\n")
    if args.pdf:
        subprocess.run([sys.executable, "build.py"], cwd=ROOT, check=True)
    print("All requested reproduction steps passed.")


if __name__ == "__main__":
    main()
