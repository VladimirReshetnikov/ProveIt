"""Compile the complete article and reject unresolved references or overflow."""

from pathlib import Path
import json
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def main():
    subprocess.run([sys.executable, str(ROOT / "measure.py")], cwd=ROOT, check=True)
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "-output-directory=build", "report.tex"]
    for _ in range(3):
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        if result.returncode:
            print(result.stdout[-12000:])
            print(result.stderr)
            raise SystemExit(result.returncode)
    log = (build / "report.log").read_text(errors="replace")
    unwanted = [line for line in log.splitlines() if any(text in line for text in
                ("Overfull", "undefined references", "undefined citations",
                 "Rerun to get cross-references right"))]
    if unwanted:
        raise SystemExit("Unresolved PDF layout/reference issues:\n" + "\n".join(unwanted))
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    summary = {"status": "passed", "passes": 3, "engine": "pdflatex",
               "unresolved_references": False, "overfull_boxes": False,
               "output": "report.pdf"}
    (ROOT / "results" / "build.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
