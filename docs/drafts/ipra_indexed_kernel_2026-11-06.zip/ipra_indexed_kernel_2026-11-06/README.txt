A SMALLER COMPLETE iPRA CHECKER
Indexed hypotheses, shared binders, and an explicit bi-interpretation
6 November 2026

Start with report.pdf. Its complete LaTeX source is report.tex and sections/.
The entire trusted acceptance program is checker.py.

RESULT

The delivered checker has 771 significant source tokens, 769 normalized
tokens, 829 executable AST nodes, 2,519 normalized UTF-8 bytes, and 2,831
original bytes. It is smaller in every one of these measures than the
coordinatewise minimum among the six current principal drafts:
808 source/normalized tokens, 855 AST nodes, 2,618 normalized bytes, and
2,865 original bytes. It also beats the supplied canonical-language core
(796 tokens, 839 AST nodes, 2,547 normalized bytes, 2,848 original bytes),
while retaining public falsity syntax.

These are finite, reproducible comparisons. No claim of an absolutely
shortest possible checker is made. The underlying arithmetic basis is
inherited and attributed; this iteration reduces certificate processing.

THEORY

The target is full first-order intuitionistic primitive recursive arithmetic
with quantifier-free induction. The native terms have zero, successor, and
one finite-body recursor. Formula constructors are numerical equality,
Pi_x(A;B) meaning forall x(A -> B), and E_x A meaning exists x A.
Public falsity is explicitly converted to 0=S0.

The report specifies every logical rule, arithmetic schema, substitution,
and freshness condition. It derives full intuitionistic logic, successor
laws, numerical coverage, and all quantifier-free induction. It supplies
a faithful ordinary first-order realization and whole-domain
bi-interpretations with iPRA. Both internal round trips use the identity
relation; the proof works at arbitrary, including nonstandard, counters.

CHECK ONE CERTIFICATE

    python3 checker.py examples/zero_plus_n.json

Expected: ACCEPT, exit status 0. Rejected inputs print REJECT and exit 1.
Python 3.10+ and its standard library suffice. No producer or test helper is
imported by the checker. The input is [context, goal, proof]. A proof leaf
is an exact signed integer selecting an existing context slot; booleans and
floats are rejected. Negative indices count from the end. See FORMAT.txt.

REPRODUCE

    python3 measure.py
    python3 validation/run_tests.py checker.py
    python3 reproduce.py
    python3 reproduce.py --pdf

The --pdf option additionally needs pdfLaTeX and the packages listed in
report.tex. Alternatively, python3 build.py rebuilds the article alone.
The recorded AST/unparse measurements use Python 3.12.14. Other Python
versions may pretty-print source differently.

AUDIT

The independent named-binding oracle agrees with all 176 inherited labels.
The same 116 accepted and 60 rejected sequents are tested in both nonnegative
and negative index representations. There are 79 new targeted cases
(32 accepted, 47 rejected), 446 actual normal/-O CLI invocations, and four
stored-context-object identity checks. All pass. The two index variants
are representation checks of one corpus, not new mathematical examples.

The final checker SHA-256 is
dd5efc0e9328a6cce99b5c74cd2c068c6be8fc6fcb5cb3177c26d461b1890ccd

The metatheorems are proved mathematically in the report, not formally
verified in Lean or Rocq. Finite tests are not exhaustive. Resource-limited
Python can reject an otherwise valid large certificate. An accepted proof
with assumptions establishes its displayed conditional sequent.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 046c84aa5e99f3a437e5bc6873af9f9a1cc797a5
Directory: docs/drafts

All six current main sources, the supplied canonical control, matched new
controls, and an inventory of embedded standalone-shaped sources are
retained with exact provenance and hashes. The inventory does not certify
the soundness of every historical comparator. The former drafts' own
earlier-baseline metrics are not used as today's comparison.

FILES

report.tex, sections/, report.pdf  Complete mathematics and compiled article.
checker.py                        Entire trusted acceptance implementation.
comparison/                       Frozen comparators, controls, provenance.
measure.py, results/               Reproducible metrics and recorded results.
validation/                       Named oracle, converter, fixtures, audit.
examples/                         Six closed example certificates.
FORMAT.txt                        Certificate grammar and binding convention.
build.py, reproduce.py             Portable reproduction and PDF build.
SHA256SUMS.txt                     Final packaged-file hashes (except itself).

The report ends with Further research questions and an exact checker listing.
