"""Reproduce the signed-position proof-certificate audit.

Run: python3 validation/run_tests.py [path/to/checker.py]

The original 176 fixed sequents and acceptance labels are preserved. Only old
hypothesis-key records are transported, using an independent named-binding
oracle. All 176 primary transported files are checked through the actual CLI
in normal and optimized Python. Negative positions are also exercised on the
same logical corpus in process; these are representation variants, not new
mathematical examples. Targeted new checks cover the changed trust boundary.
"""

from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import argparse
import json
from pathlib import Path
import platform
import subprocess
import sys

from named_oracle import D, T, ZERO, numerical_formula
from transport import SOURCE_ERRORS, convert_certificate, source_check


ROOT = Path(__file__).resolve().parent


def encoded(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode("utf-8")


def load_checker(path):
    spec = spec_from_file_location("target_checker", path)
    checker = module_from_spec(spec)
    spec.loader.exec_module(checker)
    return checker


def new_cases():
    """Expected sequents are handwritten, independent of target inference."""
    cases = []

    def add(name, data, expected, category, cli=False):
        cases.append(dict(name=name, data=data, expected=expected,
                          category=category, cli=cli))

    context_bank = [T, D, ["ex", T], ["pi", T, D]]
    for size in range(5):
        context = context_bank[:size]
        for position in range(size):
            for index in (position, position - size):
                add(f"index_valid_{size}_{index}", [context, context[position], index],
                    True, "signed_index", cli=size == 4 and position in (0, 3))
        for index in (size, -size - 1, 10**80, -(10**80)):
            add(f"index_invalid_{size}_{index}", [context, T, index],
                False, "index_bounds", cli=size == 0 or abs(index) > 10**40)

    bad_leaves = [False, True, 0.0, -1.0, 1.0, "0", "-1", None, {}, [],
                  ["hyp", T], ["hyp", 0], ["0"], [0], {"index": 0}, ["false"]]
    for number, leaf in enumerate(bad_leaves):
        add(f"leaf_type_{number:02}", [[T], T, leaf], False, "exact_integer_leaf",
            cli=number < 8)
    add("negative_index_duplicate_context", [[T, T], T, -2], True, "signed_index")

    parameter = ["=", 0, ZERO]
    shifted_parameter = ["=", 1, ZERO]
    twice_shifted = ["=", 2, ZERO]
    add("pi_guard_last_position", [[], ["pi", T, T], ["pi", T, -1]],
        True, "introduction_context", cli=True)
    add("pi_retained_parameter", [[parameter], ["pi", T, shifted_parameter],
        ["pi", T, 0]], True, "introduction_context", cli=True)
    add("pi_parameter_capture_rejected", [[parameter], ["pi", T, parameter],
        ["pi", T, 0]], False, "eigenvariable", cli=True)
    add("nested_pi_retained_parameter", [[parameter], ["pi", T, ["pi", T, twice_shifted]],
        ["pi", T, ["pi", T, -3]]], True, "introduction_context")
    add("nested_pi_parameter_capture_rejected", [[parameter], ["pi", T, ["pi", T, parameter]],
        ["pi", T, ["pi", T, -3]]], False, "eigenvariable")

    add("pack_variable_witness", [[], ["ex", ["=", 0, 1]], ["pack", 0, -1]],
        True, "witness_context", cli=True)
    add("pack_unlifted_witness_rejected", [[], ["ex", ["=", 0, 0]], ["pack", 0, -1]],
        False, "witness_context", cli=True)
    ex_zero = ["ex", ["=", 0, ZERO]]
    add("existential_retained_constant", [[ex_zero, T], T, ["use", 0, T, 1]],
        True, "elimination_context")
    add("existential_witness_escape_rejected", [[ex_zero], parameter,
        ["use", 0, parameter, -1]], False, "eigenvariable", cli=True)
    add("existential_retained_parameter", [[parameter, ["ex", T]], parameter,
        ["use", -1, parameter, 0]], True, "elimination_context")
    add("existential_wrong_slot_rejected", [[parameter, ["ex", T]], parameter,
        ["use", -1, parameter, -1]], False, "elimination_context")
    add("public_falsity_assumption", [[["false"]], D, 0], True, "public_falsity")
    add("public_falsity_goal", [[D], ["false"], -1], True, "public_falsity")
    add("public_falsity_guard", [[], ["pi", D, D], ["pi", ["false"], -1]],
        True, "public_falsity")

    for number, matrix in enumerate((["ex", ["=", 0, 1]], ["pi", T, ["=", 0, 1]])):
        add(f"quantified_cases_{number}", [[], numerical_formula(matrix), ["nat", matrix]],
            True, "induction_boundary")
        add(f"quantified_induction_rejected_{number}",
            [[], numerical_formula(matrix, force_induction=True), ["nat", matrix]],
            False, "induction_boundary", cli=True)
    add("wrong_leaf_goal_rejected", [[T, D], D, 0], False, "goal_comparison")
    add("malformed_unused_context", [[T, ["=", False, ZERO]], T, 0],
        False, "context_validation", cli=True)
    add("malformed_unused_pack_witness", [[T], ["ex", T], ["pack", False, 0]],
        False, "witness_validation", cli=True)
    add("malformed_unused_recursion_body", [[T], T,
        ["use", ["rec", ["r", ZERO, ZERO, False]], T, 0]],
        False, "recursor_validation", cli=True)
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checker", type=Path, nargs="?", default=ROOT.parent / "checker.py")
    parser.add_argument("--out", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    args.checker = args.checker.resolve()
    args.out.mkdir(parents=True, exist_ok=True)
    converted_dir = ROOT / "fixtures" / "converted"
    converted_dir.mkdir(exist_ok=True)
    new_dir = ROOT / "fixtures" / "new"
    new_dir.mkdir(exist_ok=True)
    checker = load_checker(args.checker)
    manifest = json.loads((ROOT / "fixtures" / "original_manifest.json").read_text())
    failures, records, cli_jobs = [], [], []
    counts = dict(source_oracle_agreement=0, inherited_positive_indices=0,
                  inherited_negative_indices=0, new_index_and_binding_cases=0,
                  cli_invocations=0, canonical_object_identity=0)
    categories = {}

    def api_check(name, data, expected, category):
        try:
            accepted = checker.check(deepcopy(data)) is True
            exception = None
        except Exception as error:
            accepted = False
            exception = type(error).__name__
        if accepted != expected:
            failures.append(dict(name=name, expected=expected, actual=accepted,
                                 exception=exception, phase="api"))
        categories[category] = categories.get(category, 0) + 1
        return dict(name=name, expected=expected, accepted=accepted, category=category,
                    sha256=sha256(encoded(data)).hexdigest(), exception=exception)

    def add_cli(name, path, expected):
        for optimized in (False, True):
            cli_jobs.append(dict(name=name, args=[str(path.resolve())], expected=expected,
                                 optimized=optimized))

    for original in manifest["certificates"]:
        original_path = ROOT / "fixtures" / "original" / Path(original["file"]).name
        original_bytes = original_path.read_bytes()
        if sha256(original_bytes).hexdigest() != original["sha256"]:
            raise ValueError("original fixture checksum mismatch: " + original["name"])
        data = json.loads(original_bytes)
        expected = original["accepted"]
        try:
            oracle_accepts = source_check(data)
        except SOURCE_ERRORS:
            oracle_accepts = False
        if oracle_accepts != expected:
            failures.append(dict(name=original["name"], phase="independent_source_oracle",
                                 expected=expected, actual=oracle_accepts))
        counts["source_oracle_agreement"] += 1

        for negative in (False, True):
            transported, notes = convert_certificate(data, negative_indices=negative)
            if expected and notes:
                failures.append(dict(name=original["name"], phase="transport", notes=notes))
            if type(data) is list and len(data) == 3 and transported[:2] != data[:2]:
                failures.append(dict(name=original["name"], phase="sequent_preservation"))
            kind = "negative" if negative else "positive"
            name = original["name"] + "/" + kind
            record = api_check(name, transported, expected, "inherited_" + original["category"])
            record.update(original_sha256=original["sha256"], transport_notes=notes,
                          index_representation=kind)
            records.append(record)
            counts["inherited_" + kind + "_indices"] += 1
            if not negative:
                path = converted_dir / (original["name"] + ".json")
                path.write_bytes(encoded(transported))
                add_cli(name, path, expected)

    for case in new_cases():
        record = api_check(case["name"], case["data"], case["expected"], case["category"])
        path = new_dir / (case["name"] + ".json")
        path.write_bytes(encoded(case["data"]))
        record["file"] = str(path.relative_to(ROOT))
        records.append(record)
        counts["new_index_and_binding_cases"] += 1
        if case["cli"]:
            add_cli(case["name"], path, case["expected"])

    # The new primitive leaf must return the exact validated stored object.
    context = [deepcopy(T), deepcopy(T)]
    for index, position in ((0, 0), (1, 1), (-1, 1), (-2, 0)):
        counts["canonical_object_identity"] += 1
        if checker.infer(index, context) is not context[position]:
            failures.append(dict(name=f"canonical_object_{index}", phase="identity"))

    raw_inputs = {
        "incomplete_json": b"[",
        "null_envelope": b"null",
        "boolean_envelope": b"true",
        "numeric_envelope": b"0",
        "string_envelope": b'"0"',
        "nan_envelope": b"NaN",
        "invalid_utf8": b"\xff",
        "parser_depth_limit": b"[" * 1500 + b"0" + b"]" * 1500,
    }
    for name, raw in raw_inputs.items():
        path = new_dir / (name + ".txt")
        path.write_bytes(raw)
        add_cli(name, path, False)
    for optimized in (False, True):
        cli_jobs.extend([
            dict(name="missing_filename", args=[], expected=False, optimized=optimized),
            dict(name="excess_arguments", args=["unused", "unused"], expected=False, optimized=optimized),
            dict(name="missing_file", args=[str(new_dir / "missing-input.json")], expected=False, optimized=optimized),
            dict(name="directory_input", args=[str(new_dir.resolve())], expected=False, optimized=optimized),
        ])

    def run_cli(job):
        command = [sys.executable] + (["-O"] if job["optimized"] else [])
        command += [str(args.checker), *job["args"]]
        try:
            result = subprocess.run(command, text=True, capture_output=True, timeout=20)
            expected_stdout = "ACCEPT\n" if job["expected"] else "REJECT\n"
            good = (result.returncode == (0 if job["expected"] else 1)
                    and result.stdout == expected_stdout and result.stderr == "")
            return dict(name=job["name"], optimized=job["optimized"], passed=good,
                        returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
        except Exception as error:
            return dict(name=job["name"], optimized=job["optimized"], passed=False,
                        exception=repr(error))

    with ThreadPoolExecutor(max_workers=4) as pool:
        cli_records = list(pool.map(run_cli, cli_jobs))
    counts["cli_invocations"] = len(cli_records)
    for record in cli_records:
        if not record["passed"]:
            failures.append(dict(phase="cli", **record))

    result = dict(status="passed" if not failures else "failed",
        checker_sha256=sha256(args.checker.read_bytes()).hexdigest(),
        python_version=platform.python_version(), counts=counts, categories=categories,
        failures=failures, certificates=records, cli=cli_records,
        original_labels=dict(accept=manifest["positive_certificates"], reject=manifest["negative_certificates"]),
        method="Named-binding oracle transports only old hypothesis records; original sequents and fixed labels retained.",
        qualification="Finite regression evidence, not an exhaustive test or a formal proof. The two signed-position runs reuse the same 176 logical examples.")
    (args.out / "audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in
        ("status", "checker_sha256", "counts", "original_labels", "failures")}, indent=2))
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
