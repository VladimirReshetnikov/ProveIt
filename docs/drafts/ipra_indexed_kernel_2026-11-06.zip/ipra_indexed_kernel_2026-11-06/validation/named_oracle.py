"""Named-binding oracle adapted from the supplied shared-traversal draft.

This is validation support only and is never imported by the proof checker.
The original source is recorded in provenance.json. It decodes binders to fresh
Python objects, substitutes free named variables, and re-encodes indices; it
does not call the candidate substitution implementation or its scope table.
"""

ZERO = -1
T = ["=", ZERO, ZERO]
D = ["=", ZERO, ["s", ZERO]]
FALSE = ["false"]
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)
SEED = 2026110607


def parts(a, tag, arity):
    if type(a) is not list or len(a) != arity + 1 or a[0] != tag:
        raise ValueError("wrong node")
    return a[1:]


def read_term(a, bound=()):
    if type(a) is int:
        if a == ZERO:
            return ("zero",)
        if a < 0:
            raise ValueError("negative variable")
        return ("bound", bound[a]) if a < len(bound) else ("free", a - len(bound))
    if type(a) is not list or not a:
        raise ValueError("not a term")
    if a[0] == "s":
        body, = parts(a, "s", 1)
        return ("succ", read_term(body, bound))
    if a[0] == "r":
        counter, initial, body = parts(a, "r", 3)
        state, step = object(), object()
        return ("rec", read_term(counter, bound), read_term(initial, bound),
                state, step, read_term(body, (state, step) + bound))
    raise ValueError("not a term constructor")


def read_formula(a, bound=()):
    if type(a) is not list or not a:
        raise ValueError("not a formula")
    if a[0] == "=":
        left, right = parts(a, "=", 2)
        return ("eq", read_term(left, bound), read_term(right, bound))
    if a[0] == "pi":
        guard, body = parts(a, "pi", 2)
        name = object()
        return ("pi", name, read_formula(guard, (name,) + bound),
                read_formula(body, (name,) + bound))
    if a[0] == "ex":
        body, = parts(a, "ex", 1)
        name = object()
        return ("ex", name, read_formula(body, (name,) + bound))
    raise ValueError("not a native formula constructor")


def write_named(a, bound=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "free":
        return a[1] + len(bound)
    if tag == "bound":
        return bound.index(a[1])
    if tag == "succ":
        return ["s", write_named(a[1], bound)]
    if tag == "rec":
        return ["r", write_named(a[1], bound), write_named(a[2], bound),
                write_named(a[5], (a[3], a[4]) + bound)]
    if tag == "eq":
        return ["=", write_named(a[1], bound), write_named(a[2], bound)]
    if tag == "pi":
        return ["pi", write_named(a[2], (a[1],) + bound),
                write_named(a[3], (a[1],) + bound)]
    if tag == "ex":
        return ["ex", write_named(a[2], (a[1],) + bound)]
    raise ValueError("unknown named node")


def replace_free(a, image):
    tag = a[0]
    if tag == "free":
        return image(a[1])
    if tag in ("zero", "bound"):
        return a
    if tag == "succ":
        return (tag, replace_free(a[1], image))
    if tag == "rec":
        return (tag, replace_free(a[1], image), replace_free(a[2], image),
                a[3], a[4], replace_free(a[5], image))
    if tag == "eq":
        return (tag, replace_free(a[1], image), replace_free(a[2], image))
    if tag == "pi":
        return (tag, a[1], replace_free(a[2], image), replace_free(a[3], image))
    if tag == "ex":
        return (tag, a[1], replace_free(a[2], image))
    raise ValueError("unknown named node")


def oracle_subst(a, env, d, formula):
    bound = tuple(object() for _ in range(d))
    named = read_formula(a, bound) if formula else read_term(a, bound)
    prefix = tuple(read_term(t) for t in env[:-1])
    offset = env[-1]
    if type(offset) is not int or len(prefix) + offset < 0:
        raise ValueError("invalid environment")

    def image(i):
        return prefix[i] if i < len(prefix) else ("free", i + offset)

    return write_named(replace_free(named, image), bound)


def numerical_formula(a, force_induction=False):
    """Construct the stated N schema using fresh names, not index arithmetic."""
    original = read_formula(a)
    x, y, dummy = object(), object(), object()

    def at(value):
        return replace_free(original, lambda i: value if i == 0 else ("free", i - 1))

    base = at(("zero",))
    hypothesis = at(("bound", y)) if a[0] == "=" or force_induction else base
    step = ("pi", y, hypothesis, at(("succ", ("bound", y))))
    return write_named(("pi", x, base, ("pi", dummy, step, at(("bound", x)))))


