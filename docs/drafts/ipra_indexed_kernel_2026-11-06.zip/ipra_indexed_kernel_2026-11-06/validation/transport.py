"""Transport the old hypothesis-key certificates to signed integer leaves.

All context changes use the named-binding oracle. No candidate checker is
imported here. Contexts, goals, and non-hypothesis annotations are preserved.
An unresolved old key becomes the first out-of-range nonnegative index.
"""

from copy import deepcopy

from named_oracle import ZERO, numerical_formula, oracle_subst, read_formula, read_term


SOURCE_ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def ensure(condition):
    if not condition:
        raise ValueError("invalid source derivation")


def canonical(a):
    if a == ["false"]:
        return ["=", ZERO, ["s", ZERO]]
    return [canonical(x) for x in a] if type(a) is list else a


def shift(a, formula=True):
    return oracle_subst(a, (1,), 0, formula)


def instantiate(a, t):
    return oracle_subst(a, (t, -1), 0, True)


def source_infer(p, g):
    """Independent reading of the old calculus, using named substitution."""
    match p:
        case ["hyp", key]:
            return g[g.index(key)]
        case ["pi", a, q]:
            read_formula(a)
            return ["pi", a, source_infer(q, [*(shift(b) for b in g), a])]
        case ["pack", t, q]:
            read_term(t)
            context = [*(shift(b) for b in g), ["=", 0, shift(t, False)]]
            return ["ex", source_infer(q, context)]
        case ["use", principal, annotation, minor]:
            e = source_infer(principal, g)
            if e[0] == "ex":
                read_formula(annotation)
                actual = source_infer(minor, [*(shift(b) for b in g), e[1]])
                ensure(actual == shift(annotation))
                return annotation
            if e[0] == "pi":
                read_term(annotation)
                premise = instantiate(e[1], annotation)
                conclusion = instantiate(e[2], annotation)
            elif e[0] == "=":
                read_formula(annotation)
                premise = instantiate(annotation, e[1])
                conclusion = instantiate(annotation, e[2])
            else:
                raise ValueError("unknown principal formula")
            ensure(source_infer(minor, g) == premise)
            return conclusion
        case ["rec", ["r", n, initial, update] as recursor]:
            read_term(recursor)
            if n == ZERO:
                result = initial
            else:
                ensure(type(n) is list and len(n) == 2 and n[0] == "s")
                result = oracle_subst(update,
                    (["r", n[1], initial, update], n[1], -2), 0, False)
            return ["=", recursor, result]
        case ["nat", matrix]:
            return numerical_formula(matrix)
        case _:
            raise ValueError("invalid old proof record")


def source_check(data):
    g, goal, proof = canonical(data)
    ensure(type(g) is list)
    for formula in [*g, goal]:
        read_formula(formula)
    ensure(source_infer(proof, g) == goal)
    return True


def convert_certificate(data, negative_indices=False):
    """Return transported data and an explicit log of failed source prefixes.

    Malformed records keep their shape. If the old principal prefix is already
    invalid, a later continuation may not have a computable local context; the
    converter records that fact and uses the unchanged outer context there.
    Positive source certificates must have no such notes.
    """
    result = deepcopy(data)
    notes = []
    if type(data) is not list or len(data) != 3 or type(data[0]) is not list:
        return result, [{"path": [], "kind": "malformed_envelope_preserved"}]

    def context_under(g, extra, path):
        try:
            return [*(shift(a) for a in g), extra]
        except SOURCE_ERRORS as error:
            notes.append({"path": path, "kind": "invalid_context_prefix",
                          "error": type(error).__name__})
            return [*g, extra]

    def transform(p, g, path):
        match p:
            case ["hyp", key]:
                try:
                    position = g.index(canonical(key))
                except ValueError:
                    notes.append({"path": path, "kind": "unresolved_hypothesis"})
                    return len(g)
                return position - len(g) if negative_indices else position
            case ["pi", guard, body]:
                local = context_under(g, canonical(guard), path)
                return ["pi", deepcopy(guard), transform(body, local, [*path, 2])]
            case ["pack", witness, body]:
                try:
                    equation = ["=", 0, shift(canonical(witness), False)]
                except SOURCE_ERRORS as error:
                    notes.append({"path": path, "kind": "invalid_witness_prefix",
                                  "error": type(error).__name__})
                    equation = ["=", 0, canonical(witness)]
                local = context_under(g, equation, path)
                return ["pack", deepcopy(witness), transform(body, local, [*path, 2])]
            case ["use", principal, annotation, minor]:
                converted = transform(principal, g, [*path, 1])
                try:
                    inferred = source_infer(canonical(principal), g)
                except SOURCE_ERRORS as error:
                    notes.append({"path": [*path, 1], "kind": "invalid_principal_prefix",
                                  "error": type(error).__name__})
                    inferred = None
                local = context_under(g, inferred[1], path) if inferred and inferred[0] == "ex" else g
                return ["use", converted, deepcopy(annotation), transform(minor, local, [*path, 3])]
            case _:
                return deepcopy(p)

    result[2] = transform(data[2], canonical(data[0]), [2])
    ensure(result[:2] == data[:2])
    return result, notes
