DECODER-RESET PROOF CHECKER
==========================

This file documents decoder_checker.py, the coverage-based companion. The
same-base predecessor-reset presentation is documented in UNBOUNDED_README.txt
and implemented independently in unbounded_checker.py. Both production files
are standalone; neither imports the other.

The complete trusted acceptance program is decoder_checker.py together with
the ordinary Python standard library. It imports only json and sys. The test
producer, inherited fixtures, mathematical report, and other reference files
are not imported by the checker and are not trusted proof oracles.

Run from the package root:

  python3 code/test_decoder_checker.py
  python3 code/decoder_checker.py < code/fixtures/identity_reset_schema.json

The first command reproduces the finite validation receipt in
evidence/checker_validation.json. The second prints ACCEPT for the displayed
closed instance of the exact anchored rule schema. Failure prints REJECT to
standard error and exits with status 1. The same behavior is tested under
python3 -O; no acceptance condition relies on assert.

MATHEMATICAL INTERFACE

Positive intuitionistic first-order equality logic has equations, conjunction,
disjunction, implication, universal quantification, and existential
quantification. There is no primitive bot formula and no bot_e rule. The
distinguished contradiction in the presentation is the equation 0=S0. The
report explains its connection with genuine falsity in the ordinary iPRA
realization. The checker contains no independent separation axiom.

The numerical description constructors are zero, succ, proj, comp, rec, and
compare. The last has arity two and no defining equation. Every application,
arity, finite description, free variable, bound variable, and inference field
is checked. There are no recursive references, program-valued variables, or
universal numerical evaluator. Generic computation performs exactly one
defining-equation step; it does not evaluate an arbitrary numerical program.

The two fixed descriptions appearing in primitive arithmetic instructions are

  P = ["rec", ["zero", 0], ["proj", 2, 0]]
  D = ["rec", ["succ"], ["proj", 3, 0]]

Their defining equations give P(0)=0, P(Su)=u, D(0,z)=Sz, and D(Su,z)=u.
The coverage instruction returns the exact formula x=0 or x=S(P(x)).
The sole induction-type instruction FR is

  f(D(e(f(z), f(1)), z)) = f(1)
  --------------------------------
              f(t) = f(1)

The template f is one finite term with a distinguished numerical variable z.
The variable z is fresh for the retained context, target, and passive data.
There is no independent anchor field. The report proves the interpretation
of this inference; the checker merely checks its exact syntactic instance.

PACKET FORMAT

A packet is one JSON object with exactly two fields: goal and proof.
The goal must be closed. The proof is a recursive JSON object with fields
rule, premises (a list), and exactly the extra fields for the selected rule.
Duplicate JSON object fields and nonfinite numeric constants are rejected.

Terms:

  ["0"]
  ["v", "name"]
  ["S", term]
  ["app", description, [argument, ...]]

Formulas:

  ["eq", term, term]
  ["and"|"or"|"imp", formula, formula]
  ["all"|"ex", "bound_name", formula]

The complete instruction table is the RULES dictionary in the checker.
The fixtures exercise all its entries. Named formula substitution avoids
capture, and equality of formulas is checked up to alpha-conversion using
nearest-binder indices. A binder can shadow a name; its nearest binder must
still be respected. Eigenvariables cannot reuse ambient numerical names.

VALIDATION LIMITS

The tests cover all primitive instruction names, exact computation and reset
schemas, strict packet parsing, numerical arities and scope, alpha-conversion,
capture avoidance, eigenvariable escape, removed instructions, and rejection
of alleged computation for the unspecified comparison. They also include a
real derivation of 0=S0 implying x=y, using selector computations and equality
transport, with no falsity instruction.

This is finite implementation evidence. It is not a Lean or Rocq proof of
the checker's soundness or completeness, the finite-spike calibration, or
the whole-language bi-interpretability theorem. The report's mathematical
derivations remain handwritten. Source-size measurements must charge this
entire executable, including descriptions, parser, validators, and driver.
It is a readable reference implementation, not a smallest-checker claim.
