UNBOUNDED PREDECESSOR-RESET CHECKER
=================================

unbounded_checker.py is a complete standalone acceptance program. It uses
the same positive intuitionistic logical, equality, numerical-description,
scope, substitution, alpha-equivalence, and strict JSON interfaces documented
in README.txt for the decoder companion. The production program imports only
json and sys; it imports neither the companion nor either test producer.

Run from the package root:

  python3 code/test_unbounded_checker.py
  python3 code/unbounded_checker.py < code/unbounded_fixtures/identity_reset_schema.json

The validation receipt is evidence/unbounded_checker_validation.json.
Acceptance prints ACCEPT and exits 0. Rejection prints REJECT to standard
error and exits 1. Tests cover both ordinary Python execution and python -O.

THE DIFFERENCE FROM THE DECODER COMPANION

There is no Cov instruction. The boundary instruction is BR, which returns

  sigma(n)=0 or sigma(n)=1.

The fixed descriptions are predecessor P, zero/successor selector C, and
sign sigma, with computation equations

  P(0)=0,          P(Sn)=n,
  C(0,a,b)=a,      C(Sn,a,b)=b,
  sigma(0)=0,      sigma(Sn)=1.

Each is an actual finite PR description, charged in the production source.
For a fixed template f, put c=f(1). The exact checked FR instruction is

  f(C(sigma(e(f(z),c)), Sz, P(e(f(z),c)))) = c
  ------------------------------------------------
                       f(t) = c

The failure argument is P(e(f(z),c)), with no outer sign normalization.
The anchor c is computed by substituting 1 into the same template; it is
not a separately supplied field. The usual eigenvariable conditions and
arbitrary retained first-order contexts are enforced.

The comparison e is an initial binary description with no computation
equation. No evaluator or trusted comparison correctness theorem is present.
There is no primitive falsity syntax, no falsity-elimination instruction,
and no independent separation axiom. As in the companion, the distinguished
contradiction is 0=S0; the report supplies the ordinary genuine-falsity bridge.

EXACT COMPARISON BOUNDARY

Relative to the earlier anchored feedback transition, the mathematical rule
change removes the outer sigma from sigma(P(e(f(z),c))) in the failure
argument. BR remains the boundary premise. The positive logical presentation
and removal of independent separation are a separate, explicitly disclosed
change in the complete implementation. The coverage-based decoder companion
has a different primitive boundary and is not presented as this same-base
single-subterm deletion.

The tests exercise all 16 instruction names, exact reset schemas with several
templates, arbitrary quantified retained contexts, description arities,
capture avoidance and alpha-equivalence, eigenvariable escape, strict packet
fields, malformed JSON, and the absence of computation for e. In particular,
the old sign-normalized failure formula and the Cov instruction are rejected.
An actual derivation of 0=S0 implying x=y is retained as a positive fixture.

The test suite reuses untrusted fixtures from test_decoder_checker.py and
references/upstream_fixtures.py. Neither is part of the accepted proof
program. The finite-pulse calibration, derived coverage, induction recovery,
and bi-interpretability proofs are handwritten mathematics, not mechanized
by these finite public-interface tests. No smallest-checker claim is made.
