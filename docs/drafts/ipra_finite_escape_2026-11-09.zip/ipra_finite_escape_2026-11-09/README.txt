FINITE ESCAPE FOR RESET ARITHMETIC
Prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific time)
=================================================================

START HERE

ipra_finite_escape.pdf is the complete research report.
ipra_finite_escape.tex is its standalone editable LaTeX source.

RESULT AND LIMIT

The new finite-escape theorem removes the requirement that a failed reset
destination be bounded. Three fixed, disjoint Boolean pulses avoid two
arbitrary destinations. This calibrates the initially unspecified comparison;
an exact ramp then forces every failed destination to zero.

Two complete presentations are proved:

  T_U: Boolean sign range BR and anchored reset
       f(C(sign(e(f(z),f(1))), S(z), P(e(f(z),f(1))))) = f(1)
       ------------------------------------------------------
                         f(t) = f(1).

  T_D: Numerical coverage Cov and anchored reset
       f(D(e(f(z),f(1)), z)) = f(1)
       --------------------------------
                 f(t) = f(1),

       where D(0,z)=S(z), D(S(u),z)=u.

Both ordinary theories also include the complete relative-PR defining
equations, ordinary intuitionistic first-order equality logic with genuine
falsity, and separation (0=1)->bottom. They are whole-domain bi-interpretable
and equiconsistent with full first-order iPRA, with identity composite
isomorphisms. The primitive comparison e has no defining equations or
assumed range; its full Boolean specification is derived.

The native checkers encode genuine falsity by 0=1 and derive its elimination
rule. The report distinguishes this precise proof presentation from the bare
positive ordinary theory, which would have a singleton model.

A COMPLETE CHECKER BELOW THE ENTIRE CURRENT CORPUS WAS NOT OBTAINED.
The new complete readable programs have 3184 and 3103 normalized tokens.
Existing native kernels already attain 305 tokens; the coordinate envelope
is 305 tokens / 340 AST nodes / 820 bytes, attained by different programs.
These are implementation upper bounds, not a proved complexity lower bound.
The isolated deletion of one sign operation saves 3 tokens / 3 AST nodes /
6 normalized bytes in the disclosed matched implementation.

The general unbounded-destination calibration is the mathematical advance.
The raw-decoder simplification changes the primitive boundary from BR to Cov;
an explicit two-ray countermodel shows why keeping only BR is insufficient.
No absolute minimality or literature-wide priority is claimed.

REPRODUCTION

From this directory, using Python 3.12.14 for identical source normalization:

  python3 verify_manifest.py
  python3 reproduce.py

To compile the report with an ordinary TeX installation:

  python3 build.py

Reproduction uses Python's standard library only; no network is needed.
Compilation runs pdfLaTeX twice with shell escape disabled. Tests and builds
refresh receipts, so verify the original payload manifest first.

PACKAGE CONTENTS

code/unbounded_checker.py        Complete positive native checker for T_U
code/decoder_checker.py          Complete positive native checker for T_D
code/test_*_checker.py           Public API/CLI verification suites
code/check_finite_escape.py      Exact finite Boolean pulse controls
code/measure_sources.py          Complete-source measurements
code/fixtures/                  Decoder certificates and negative controls
code/unbounded_fixtures/        Unbounded certificates and negative controls
code/README.txt                  Decoder syntax and protocol
code/UNBOUNDED_README.txt         Unbounded syntax and protocol
evidence/                       Validation receipts and mathematical reviews
references/                     Frozen comparators, fixture support, licenses
source_snapshot.json             All 20 pinned source-archive identities
CLAIMS.json                     Explicit proved/inherited/unestablished ledger
MANIFEST.json                   Payload sizes and SHA-256 identities

VALIDATION SCOPE

Unbounded checker: 37 accepted packets, 57 rejected packets, 7 malformed
JSON cases; 94 API checks and 202 ordinary/optimized CLI runs, all passed.
Decoder checker: 37 accepted packets, 51 rejected packets, 7 malformed
JSON cases; 88 API checks and 190 ordinary/optimized CLI runs, all passed.
All 16 primitive instruction names in each checker are exercised.

The independent finite-pulse program checks all 32 abstract Boolean profiles,
96 successor-escape implications, and 1024 ordered profile pairs. Written
mathematics was separately reviewed by two assistant agents. The included
reviews are not external peer review. Finite validation is not a Lean/Rocq
mechanization of the calibration, the checker, or the bi-interpretation.

SOURCE AND ATTRIBUTION

Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: 718c23f33f04b6b914699a0b02face47bd211be3
Directory: docs/drafts

All 20 archives were downloaded and verified against Git blob identities.
The ordinary ramp, earlier bounded spike, anchored reset method, formula
compiler, and checker framework are attributed inherited work. The new
three-support escape and subsequent exact ramp are explained in the report.
The inherited numerical-falsity encoding is separately disclosed.
Detailed code provenance and licenses are included. The remote repository
was not modified.
