# Redundant incidence cores in union-closed families

Research note, 25 November 2026.

## Contents

- `paper.tex` — complete LaTeX source, with all proofs and references.
- `paper.pdf` — compiled eight-page paper.
- `verify.py` — dependency-free exact-integer/rational verification and construction checks.
- `verification.txt` — output of `python3 verify.py --full`.
- `provenance.md` — scope of repository and public-literature review; novelty limitations.

## Reproduction

```sh
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
python3 verify.py --full
```

Without `--full`, the verifier omits the largest exhaustive small-system sweep but runs all randomized and sharpness checks. Python 3.10+ is recommended. The proofs of the finite statements do not depend on computation. The asymptotic every-mark threshold uses the ordinary binomial central limit theorem.

## Principal contribution

Under the redundant-incidence-core condition, there are two exact binomial-sum thresholds for the half-frequency conclusion, one for some marked element and one for every marked element. More generally, a scalar threshold over weighted containment scores gives the best possible infimum for every nonnegative weighting. The sharpness construction works with connected incidence graphs and arbitrarily many generators.

This is a restricted theorem, not a solution to Frankl's conjecture. Historical priority is not established, and there is no proof-assistant formalization in this archive. Rare-mark examples only obstruct stronger marked conclusions; they do not make every element of the entire union-closed family rare.
