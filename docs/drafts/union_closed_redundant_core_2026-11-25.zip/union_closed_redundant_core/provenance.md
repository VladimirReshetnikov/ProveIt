# Provenance and scope of review

Repository: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts (main branch, 25 November 2026).

The GitHub connector listed 24 ZIP archives. For 23 archives, LaTeX source was decoded and the titles/abstracts (where present) and section inventories were inspected to identify overlap. This was a targeted review, not a line-by-line verification of all proofs. The 4,265,422-byte `union_closed_structural_theorems.zip` returned an empty content field in the connector, so it was **not inspected**. This is a real limitation on repository-wide novelty.

## Closest precedents in the inspected archives

- `union_closed_partial_results.zip`: exact generator-incidence representation, uniform distinct unions, regular linear generators and switching under exterior conditions. The representation is used here, with an independent elementary proof; no earlier frequency estimate is used.
- `union_closed_joint_laws_2026-11-25.zip`: joint laws under exterior conditioning and regular linear incidence systems. Here exterior conditioning is retained but the forced local configurations come from a transversal property of edge traces, not linearity or girth.
- `union_closed_substitution.zip`: product substitution in a dual hypergraph and sharp conditional product laws. The present theorem does not require a local-product representation: each exterior edge-pattern may have its own arbitrary collection of core traces. The extremal examples use exterior clauses and replication, not substitution of independent local gadgets into every vertex.
- `union_closed_uniform_threshold_2026-11-25.zip`: exact Frankl-completeness threshold for complete uniform layers on a **ground-element** set. The complete layer here is instead on **generator labels** in the incidence hypergraph, and the theorem controls the associated marked ground-element types. A separate redundancy hypothesis is crucial.
- `union_closed_abundance_theorems.zip`: overlapping complete uniform ground-set blocks, projective-plane lines and rare-triple transfer; not the redundant dual-fibre criterion described here.
- `union_closed_dense_core_2026-11-25.zip`, `union_closed_marked_abundance.zip`, `union_closed_three_results.zip`: private generator exceptions and marked/translate certificates; the present incidence cores need not have private generators or a bounded number of exceptions.
- `union_closed_cycle_certificates.zip`, `union_closed_local_abundance.zip`, `union_closed_partial_theorems_2026-11-25.zip`: local conditional certificates for other graph/incidence configurations, including high-girth tree-message results. The present proof uses forced upper layers, a sharp score optimization, and a realization lemma.

## Other inspected archives (abstracts and section inventories)

- `union-closed-abundance.zip`
- `union-closed-results.zip`
- `union_closed_abundance.zip`
- `union_closed_advances_2026-11-25.zip`
- `union_closed_entropy_2026_11_25.zip`
- `union_closed_entropy_research_2026-11-25.zip`
- `union_closed_extensions_2026-11-25(1).zip`
- `union_closed_extensions_2026-11-25.zip`
- `union_closed_frequency_bounds.zip`
- `union_closed_rank_transport_2026-11-25.zip`
- `union_closed_refinements_2026-11-25.zip`
- `union_closed_trace_entropy_2026-11-25.zip`

These focus principally on ground-set configurations, graph-edge local bounds, regular incidence estimates, entropy profiles, approximate closure or finite-size frequency corrections. No identical statement was identified in the inspected inventories.

## Public literature

- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture — general problem and established special cases.
- https://www.uni-ulm.de/fileadmin/website_uni_ulm/mawi.inst.081/Henning/unionclosedsets.pdf — Bruhn, Charbit, Schaudt and Telle, graph formulation; background for duality.
- https://arxiv.org/abs/2211.09055 — Gilmer's constant lower bound.
- https://arxiv.org/abs/2610.02295 and https://zenodo.org/records/22727713 — Costa–Sadhu, 0.3828852549667978 benchmark. The note does not assert this is the latest record; a more recent claim appeared in search but was not independently checked, and is immaterial to the proof.

Searches combined variants of “union closed sets conjecture”, “dual hypergraph”, “generator incidence”, “complete uniform hypergraph”, “edge containment”, “transversal number”, “local neighborhood”, “maximal independent sets”, “conditional fibres”, and “substitution”. They located related frameworks but not the particular weighted root and sharp realization theorem. This does not rule out unpublished, poorly indexed, or equivalent statements under other terminology. The mathematical proofs are presented as independently derived candidate contributions; priority remains provisional.
