#!/usr/bin/env python3
"""Exact, dependency-free checks for the redundant-core theorem.
Run: python3 verify.py [--full]. No floating-point decisions.
"""
import argparse
import itertools
from fractions import Fraction
from math import comb
from random import Random


def subsets(mask):
    s = mask
    while True:
        yield s
        if s == 0:
            break
        s = (s - 1) & mask


def choose_masks(q, k):
    return [sum(1 << i for i in c) for c in itertools.combinations(range(q), k)]


def sums(q, k, r):
    assert 2 <= k <= q and 1 <= r <= q-k+1
    return sum(comb(q, i) for i in range(r)), sum(comb(q-k, i) for i in range(r))


def rho_exact(q, k, r, weights):
    """Return root via sorted scores, exact rationals (weights normalized here)."""
    E = choose_masks(q, k)
    assert len(E) == len(weights) and min(weights) >= 0 and sum(weights) > 0
    w = [Fraction(x, sum(weights)) for x in weights]
    score = [sum((v for e, v in zip(E, w) if e & s == e), Fraction(0)) for s in range(1 << q)]
    h = q-r+1
    top = [s for s in range(1 << q) if s.bit_count() >= h]
    rest = sorted((s for s in range(1 << q) if s.bit_count() < h), key=score.__getitem__, reverse=True)
    mass, cnt = sum(score[s] for s in top), len(top)
    for s in rest:
        if score[s] <= mass / cnt:
            break
        mass += score[s]
        cnt += 1
    rho = mass / cnt
    assert sum(score[s]-rho for s in top) + sum(max(Fraction(0), score[s]-rho) for s in rest) == 0
    L = set(top) | {s for s in rest if score[s] > rho}
    assert sum(score[s] for s in L) == rho*len(L)
    assert all(s.bit_count() >= k for s in L)
    return rho, L, score


def union_closure(edges):
    C = {0}
    for e in edges:
        C |= {c | e for c in C}
    return C


def direct_duality(edges, n, C):
    gens = [sum(1 << j for j,e in enumerate(edges) if e & (1 << v)) for v in range(n)]
    F = union_closure(gens)
    image = {sum(1 << j for j,e in enumerate(edges) if e & c != e) for c in C}
    assert image == F and len(F) == len(C)


def redundancy(edges, q):
    W=(1<<q)-1
    by_q={}
    for e in edges:
        Q=e & ~W
        if Q:
            by_q.setdefault(Q, []).append(e & W)
    return min((R.bit_count() for traces in by_q.values() for R in range(1<<q)
                if all(R & t for t in traces)), default=q+1)


def check_bound(q,k,r,edges,C=None,weights=None):
    W=(1<<q)-1
    E=choose_masks(q,k)
    assert set(E) <= set(edges)
    if C is None:
        C=union_closure(edges)
    fibers={}
    for c in C:
        fibers.setdefault(c & ~W,set()).add(c & W)
    h=q-r+1
    top={s for s in range(1<<q) if s.bit_count()>=h}
    assert all(top <= v for v in fibers.values())
    A,B=sums(q,k,r)
    assert len(top)==A
    N=len(C)
    absent=[sum((c & e)==e for c in C) for e in E]
    # Finite strictness term, valid because empty union is included.
    assert A*sum(absent) <= B*len(E)*(N-1)
    D=A-B
    for a in absent:
        assert (2**(q-k)+D)*a <= 2**(q-k)*(N-1)
    # Sharper uniform deficit coming from the empty-exterior fiber.
    b0=B*len(E)+sum(comb(q,j)*(B*len(E)-A*comb(j,k)) for j in range(k,h))
    assert A*sum(absent)+b0 <= B*len(E)*N
    if weights is not None:
        rho,_,score=rho_exact(q,k,r,weights)
        assert sum(score[c & W] for c in C) <= rho*(N-1)
        for f in fibers.values():
            assert sum(score[s] for s in f) <= rho*len(f)
    return N


def exhaustive(full):
    checks=0; systems=0
    # All possible trace systems at one exterior vertex; absent trace allowed.
    for q,k in [(2,2),(3,2),(3,3)]+([(4,2)] if full else []):
        core=choose_masks(q,k)
        z=1<<q
        for bits in range(1<<(1<<q)):
            traces=[s for s in range(1<<q) if bits>>s&1]
            edges=core+[z|s for s in traces]
            tau=redundancy(edges,q)
            C=union_closure(edges)
            systems+=1
            for r in range(1,min(q-k+1,tau)+1):
                check_bound(q,k,r,edges,C)
                checks+=1
    print('exhaustive one-exterior systems:',systems,'parameter checks:',checks)


def randomized():
    rng=Random(25112026)
    checked=0; dual=0
    for _ in range(400):
        q=rng.randint(3,6); k=rng.randint(2,q); m=rng.randint(1,3)
        W=(1<<q)-1; n=q+m
        r=rng.randint(1,q-k+1)
        edges=set(choose_masks(q,k))
        # Generate diverse trace systems with a guaranteed transversal lower bound:
        # for each exterior part, at least r singleton traces, or the empty trace.
        for Q in range(1,1<<m):
            if rng.randrange(4)==0:
                continue
            if rng.randrange(5)==0:
                traces={0}
            else:
                traces={1<<i for i in rng.sample(range(q),r)}
            traces.update(rng.randrange(1<<q) for _ in range(rng.randrange(6)))
            edges.update((Q<<q)|s for s in traces)
        # Optional extra core edges; completeness at rank k is maintained.
        edges.update(rng.randrange(1,1<<q) for _ in range(rng.randrange(4)))
        edges=sorted(edges)
        assert redundancy(edges,q)>=r
        C=union_closure(edges)
        weights=[rng.randrange(9) for _ in choose_masks(q,k)]
        if not any(weights): weights[0]=1
        check_bound(q,k,r,edges,C,weights)
        direct_duality(edges,n,C); dual+=1
        checked+=1
    print('random multi-exterior systems / weighted checks / direct duality:',checked,checked,dual)


def clauses_for(q,L):
    W=(1<<q)-1
    return [W^s for s in range(1<<q) if s not in L and all((s|1<<v) in L for v in range(q) if not s>>v&1)]


def clause_count(q,k,clauses,t,s):
    # If |S| >= k, internal edges already support all its vertices.
    active=[b for b in clauses if b&s]
    if s.bit_count()>=k:
        return 1<<(t*len(active))
    # Otherwise every selected core vertex must meet an active selected clone.
    return sum((-1)**J.bit_count() * (1<<(t*sum(not b&J for b in active))) for J in subsets(s))


def sharpness():
    rng=Random(452)
    tests=0; direct=0
    for q in range(2,7):
        for k in range(2,q+1):
            E=choose_masks(q,k)
            for r in range(1,q-k+2):
                A,B=sums(q,k,r)
                for weights,expected in [([1]*len(E),Fraction(B,A)),([1]+[0]*(len(E)-1),Fraction(2**(q-k),2**(q-k)+A-B)),([rng.randrange(1,6) for _ in E],None)]:
                    rho,L,score=rho_exact(q,k,r,weights)
                    if expected is not None: assert rho==expected
                    clauses=clauses_for(q,L)
                    assert all(b.bit_count()>=r for b in clauses)
                    assert L=={s for s in range(1<<q) if all(s&b for b in clauses)}
                    for t in (1,3,8):
                        counts=[clause_count(q,k,clauses,t,s) for s in range(1<<q)]
                        M=len(clauses)
                        assert all(counts[s]==2**(t*M) for s in L)
                        assert all(0<=counts[s]<=2**(t*(M-1)) for s in range(1<<q) if s not in L)
                        mu=sum(a*b for a,b in zip(counts,score))/sum(counts)
                        assert 0<=rho-mu<=Fraction((1<<q)-len(L),len(L)*2**t)
                        if t==1 and q+M<=13:
                            edges=list(E)
                            for j,b in enumerate(clauses):
                                edges.extend((1<<(q+j))|(1<<v) for v in range(q) if b>>v&1)
                            C=union_closure(edges)
                            actual=[0]*(1<<q)
                            for c in C: actual[c&((1<<q)-1)]+=1
                            assert counts==actual
                            check_bound(q,k,r,edges,C,weights)
                            direct+=1
                        tests+=1
    print('sharpness and root tests:',tests,'direct construction comparisons:',direct)


def table():
    print('\nq,k,r_some,r_every')
    for q in (6,8,10,12,20,50,100,500):
        for k in (2,3,4):
            rows=[(r,*sums(q,k,r)) for r in range(1,q-k+2)]
            rs=next((r for r,A,B in rows if A>=2*B),None)
            re=next((r for r,A,B in rows if A-B>=2**(q-k)),None)
            print(q,k,rs,re,sep=',')
    A,B=sums(12,3,4); assert Fraction(A-B,A)==Fraction(13,23)
    A,B=sums(12,3,5); assert Fraction(A-B,2**9+A-B)==Fraction(269,525)
    print('12,3,4: mean >=13/23; 12,3,5: each >=269/525 (both strict)')


if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--full',action='store_true'); args=p.parse_args()
    exhaustive(args.full); randomized(); sharpness(); table()
    print('\nAll exact checks passed.')
