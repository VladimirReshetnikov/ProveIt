PROGRESSION AND CLOSURE
A one-assumption presentation of intuitionistic primitive recursive arithmetic
Research prepared for Vladimir Reshetnikov, 9 November 2026

STATUS
======
The requested strict reduction below the current complete-checker frontier
has NOT been established. This package is a research result and an auditable
record of that limit, not a claim to the simplest possible axiomatization.

The main positive result is a complete native calculus with exactly one
local assumption in each paired introduction. An equation closure expresses
successor progression; a compound closure expresses conditional universal
closure. An explicit local progression elimination repairs the introduction
change. Protected closure, full intuitionistic logic, arbitrary-native-formula
normalization, the numerical compiler and both interpretation composites are
proved in the report. The numerical domain and actual equality are preserved.

This is a reviewed mathematical proof, not a Lean/Rocq formalization. The
executable checks below verify concrete certificates and specified input
boundaries, not the whole metatheory. Progression binders themselves already
appear in the supplied drafts; the report states the narrower contribution.

READ FIRST
==========
report.pdf                  Complete report, with references and appendix.
report.tex                  Main editable LaTeX source.
sections/*.tex              Main construction, proof, comparison and limits.
CLAIMS.json                 Machine-readable claim/status map.
ATTRIBUTION.txt              New and inherited work; exact snapshot.

REPRODUCE
=========
From this directory, using Python 3.12 (measurement baseline: 3.12.14):

  python3 reproduce.py

This checks the new native verifier, both old-kernel refactorings and all
nineteen frozen comparison sources. It writes evidence/reproduction.json.

  python3 build.py

This compiles report.tex with pdflatex three times, with shell escape
disabled. A normal TeX installation with the packages listed in report.tex
is required. The already compiled report.pdf is supplied.

  python3 package.py

This creates a ZIP beside this directory, adds a SHA-256 manifest, verifies
the archive and every member hash, and omits transient TeX/Python outputs.
Archive entry timestamps are fixed; rebuilding the PDF can change its own
metadata and therefore the resulting archive hash.

VERIFICATION AND MEASUREMENT
============================
code/progress_checker/ contains a complete readable verifier, its exact
JSON grammar and rules, two untrusted proof producers, 34 certificate cases
(13 accepted and 21 rejected), six malformed-input cases and an 80-run
public-CLI check in normal and optimized Python. All passed.

The inherited complete_kernel.py is 309 normalized tokens / 344 AST nodes /
864 normalized bytes under the unchanged whole-source metric. The readable
new verifier is 2380 / 2640 / 9682; it is a reference implementation.

code/kernel_variants/ contains two equivalent implementations of the OLD
calculus, separate from the new mathematical presentation:
  local_s.py:          308 tokens / 346 AST nodes / 869 bytes
  lambda_instance.py:  307 tokens / 347 AST nodes / 839 bytes
Neither beats all three inherited coordinates. Both match all 147 positive
packets, including checking state, and all 13 public protocol cases in both
Python modes (26 subprocess runs per candidate). ASSESSMENT.txt gives the
ordinary-input equivalence arguments and the exact limitations.

reference/ contains frozen comparison programs, unchanged measurement code,
fixtures, the inherited scalar arithmetic development, selected mathematical
source sections and the inherited license. evidence/ contains source hashes,
measurement receipts, test results, build receipts and review notes.

AUXILIARY LIMIT
===============
Deleting the last atomic assumption has a direct weaker interpretation.
The tempting further countermodel transfer requires an unproved scalar
substitution-coherence argument, so the report does NOT claim an unconditional
non-bi-interpretability theorem for that deletion. The main positive theorem
does not depend on this auxiliary issue.

SOURCE SNAPSHOT
===============
https://github.com/VladimirReshetnikov/ProveIt/tree/e707d8bd1bcbc036631663e7538efd8b42b1e130/docs/drafts
All eleven source archives were verified by byte length and Git blob SHA-1;
their SHA-256 hashes and immutable URLs are in evidence/source_snapshot.json.
The measurements are empirical implementation bounds, not universal lower
bounds on arithmetic axiomatizations.
