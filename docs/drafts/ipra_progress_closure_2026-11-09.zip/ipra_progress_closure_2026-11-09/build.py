"""Compile the main report with shell escape disabled."""
from pathlib import Path
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which("pdflatex"):
        raise SystemExit("pdflatex is required; install a TeX Live distribution.")
    command = ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "report.tex"]
    runs = []
    for index in range(3):
        result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        log = ROOT / "evidence" / ("latex_pass_" + str(index + 1) + ".txt")
        log.write_text(result.stdout)
        runs.append({"pass": index + 1, "exit_code": result.returncode})
        if result.returncode:
            raise SystemExit("LaTeX failed; inspect " + str(log.relative_to(ROOT)))
    log_text = (ROOT / "report.log").read_text(errors="replace")
    bad = [line for line in log_text.splitlines() if any(x in line for x in ("Undefined control", "undefined references", "undefined citations", "Overfull"))]
    receipt = {"command": command, "runs": runs, "warnings_requiring_review": bad, "pdf_bytes": (ROOT / "report.pdf").stat().st_size}
    (ROOT / "evidence/build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
