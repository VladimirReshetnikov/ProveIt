"""Reproduce whole-source comparator measurements without changing the metric."""
from pathlib import Path
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("inherited_measure", ROOT / "reference/source_measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)


def main():
    manifest = json.loads((ROOT / "reference/checker_manifest.json").read_text())
    rows = []
    for entry in manifest["programs"]:
        path = ROOT / entry["file"]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != entry["sha256"]:
            raise ValueError("Frozen comparator changed: " + entry["file"])
        rows.append({**entry, **measure.metrics(path)})
    rows.sort(key=lambda row: (row["normalized_tokens"], row["ast_nodes"], row["file"]))
    fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    result = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "snapshot": manifest["snapshot"],
        "definition": "Entire executable source; remove docstrings/comments, ast.unparse, count non-layout tokens, all AST nodes and UTF-8 bytes.",
        "comparator_count": len(rows),
        "coordinate_minima": {name: min(row[name] for row in rows) for name in fields},
        "programs": rows,
        "new_reference_checker": {"file": "code/progress_checker/checker.py", **measure.metrics(ROOT / "code/progress_checker/checker.py")},
        "inherited_kernel_variants": [
            {"file": "code/kernel_variants/" + name,
             **measure.metrics(ROOT / "code/kernel_variants" / name)}
            for name in ("local_s.py", "lambda_instance.py")
        ],
        "claim": "No new checker below the inherited frontier is established.",
    }
    (ROOT / "evidence/measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ("python", "comparator_count", "coordinate_minima", "new_reference_checker", "inherited_kernel_variants", "claim")}, indent=2))


if __name__ == "__main__":
    main()
