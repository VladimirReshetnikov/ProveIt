"""Untrusted concrete certificate producer; never imported by checker.py."""

import copy

import produce_advanced as p


def document(proof, context=None):
    return {"context": [] if context is None else context, "proof": proof}


def orbit_step(seed, eigen, hypothesis_index):
    """I(Sz,a;u.u)=a from exactly the local I(z,a;u.u)=a."""
    u = "orbit_update"
    old = p.I(p.V(eigen), seed, u, p.V(u))
    new = p.I(p.S(p.V(eigen)), seed, u, p.V(u))
    hypothesis = p.node("hyp", p.Eq(old, seed), index=hypothesis_index)
    computation = p.istep(p.V(eigen), seed, u, p.V(u))
    return p.node("tr", p.Eq(new, seed), equality=hypothesis, minor=computation,
                  var="orbit_hole", motive=p.Eq(new, p.V("orbit_hole")))


def cases():
    result = []

    def add(label, accepted, doc, description):
        result.append({"name": label, "accept": accepted,
                       "document": doc, "description": description})

    zero, a, b, n = p.Z(), p.V("a"), p.V("b"), p.V("n")
    add("computation_zero", True, document(p.i0(p.S(zero), "u", p.S(p.V("u")))),
        "I0 with a nonzero initializer and a nontrivial unused update.")
    add("computation_successor", True, document(p.istep(n, a, "u", p.S(p.V("u")))),
        "IS substitutes the whole preceding iterate into its fixed update.")
    add("derived_reflexivity", True, document(p.refl(p.I(n, a, "u", p.S(p.V("u"))))),
        "Reflexivity is derived from I0 and Tr, not a trusted primitive rule.")

    # This induction genuinely uses its local induction equation.  The
    # simpler constant-zero iterator example needs only numerical cases.
    y = "orbit_counter"
    matrix = p.Eq(p.I(p.V(y), a, "orbit_update", p.V("orbit_update")), a)
    closure = p.qi([], y, matrix, lambda context, z: orbit_step(a, z, len(context) - 1))
    full_induction = p.node("qe0", p.sf(matrix, y, n), major=closure,
                           minor=p.i0(a, "orbit_update", p.V("orbit_update")), target=n)
    add("identity_iterator_uses_induction_hypothesis", True, document(full_induction),
        "Closed free-counter theorem I(n,a;u.u)=a; its step consumes the actual local IH.")

    # Opening two binders must be simultaneous: the witness's free y must
    # not subsequently be replaced by the successor instance for bound y.
    x, y, z = "x", "y", "z"
    matrix_xy = p.Eq(p.I(p.V(y), p.V(x), "orbit_update", p.V("orbit_update")), p.V(x))
    simultaneous = p.node("di", p.D(x, y, matrix_xy), witness=p.V(y), fresh=z,
                          step=orbit_step(p.V(y), z, 0))
    add("simultaneous_witness_opening", True, document(simultaneous),
        "The free y in an existential witness is distinct from the bound counter y being opened.")

    # A manually specified computation whose substitution must rename an
    # inner iterator binder; the incorrect version captures the seed's v.
    u, v, w = "u", "v", "renamed"
    body = p.I(zero, p.V(u), v, p.V(u))
    previous = p.I(n, p.V(v), u, body)
    left = p.I(p.S(n), p.V(v), u, body)
    correct_rhs = p.I(zero, previous, w, previous)
    bad_rhs = p.I(zero, previous, v, previous)
    add("iterator_capture_avoided", True,
        document(p.node("is", p.Eq(left, correct_rhs))),
        "IS renames an update binder before inserting an iterate with that variable free.")
    add("reject_iterator_capture", False,
        document(p.node("is", p.Eq(left, bad_rhs))),
        "The forged IS right side captures a previously free numerical variable.")

    equality = p.Eq(a, p.V("y"))
    source = p.Q("y", p.Eq(a, p.V("y")))
    context = [equality, source]
    correct = p.Q("renamed", p.Eq(p.V("y"), p.V("renamed")))
    captured = p.Q("y", p.Eq(p.V("y"), p.V("y")))
    transport = p.node("tr", correct, equality=p.node("hyp", equality, index=0),
                       minor=p.node("hyp", source, index=1), var="a", motive=source)
    add("formula_capture_avoided", True, document(transport, context),
        "Tr keeps the inserted free y free by renaming the surrounding Q binder.")
    forged = copy.deepcopy(transport)
    forged["goal"] = captured
    add("reject_formula_capture", False, document(forged, context),
        "Reject a transport conclusion that would capture the replacement's free variable.")

    alpha_source = p.Q("y", p.Eq(p.V("y"), a))
    alpha_goal = p.Q("z", p.Eq(p.V("z"), a))
    add("alpha_renamed_hypothesis", True,
        document(p.node("hyp", alpha_goal, index=0), [alpha_source]),
        "Bound names may change while free parameters remain fixed.")
    bad_alpha = p.Q("z", p.Eq(p.V("z"), b))
    add("reject_free_parameter_renaming", False,
        document(p.node("hyp", bad_alpha, index=0), [alpha_source]),
        "Alpha equivalence never identifies distinct free parameters.")

    wrong_di = copy.deepcopy(closure["major"])
    wrong_di["fresh"] = "a"
    add("reject_di_parameter_freshness", False, document(wrong_di),
        "DI's eigenvariable must avoid every fixed free matrix parameter.")
    witness_collision = p.node("di", p.D("x", "y", p.Eq(p.V("x"), p.V("x"))),
                               witness=p.V("z"), fresh="z", step=p.refl(p.V("z")))
    add("reject_di_witness_freshness", False, document(witness_collision),
        "DI's eigenvariable must not occur free in its chosen witness.")
    trivial_di = p.node("di", p.D("x", "y", p.Eq(zero, zero)), witness=zero,
                        fresh="z", step=p.refl(zero))
    add("reject_di_context_freshness", False, document(trivial_di, [p.Eq(p.V("z"), zero)]),
        "An eigenvariable in a retained assumption cannot be generalized by DI.")
    escaped_de = copy.deepcopy(closure)
    escaped_de["fresh"] = "a"
    add("reject_de_conclusion_freshness", False, document(escaped_de),
        "DE's eigenvariable must not occur free in the concluding formula.")
    retained_de = p.node("de", p.Eq(zero, zero), major=trivial_di, fresh="a", step=p.refl(zero))
    add("reject_de_context_freshness", False, document(retained_de, [p.Eq(a, a)]),
        "DE's witness is fresh for retained assumptions as well as the conclusion.")

    false_base = copy.deepcopy(closure["major"])
    false_base["step"]["equality"]["goal"] = p.sf(matrix, "orbit_counter", zero)
    add("reject_forged_atomic_base", False, document(false_base),
        "Atomic DI supplies the local E(z), never the old retained E(0).")
    no_ih = copy.deepcopy(closure["major"])
    no_ih["step"] = p.node("is", no_ih["step"]["goal"])
    add("reject_dropped_induction_hypothesis", False, document(no_ih),
        "Computation alone cannot replace the consumed induction equation in the orbit proof.")

    bad_computation = p.i0(a, "u", zero)
    bad_computation["goal"][2] = b
    add("reject_changed_computation_result", False, document(bad_computation),
        "A zero-counter computation returns exactly its initializer.")
    add("reject_unbound_hypothesis", False, document(p.node("hyp", p.Eq(zero, zero), index=0)),
        "Empty contexts do not supply proof assumptions.")
    add("reject_negative_hypothesis_index", False,
        document(p.node("hyp", p.Eq(zero, zero), index=-1), [p.Eq(zero, zero)]),
        "Python negative indexing is forbidden in proof certificates.")
    add("reject_boolean_hypothesis_index", False,
        document(p.node("hyp", p.Eq(zero, zero), index=False), [p.Eq(zero, zero)]),
        "JSON booleans are not accepted as numerical hypothesis indices.")
    add("reject_term_in_formula_position", False, document(p.node("hyp", a, index=0)),
        "Numerical and logical syntax are validated as separate sorts.")
    bad_sort = p.i0(a)
    bad_sort["goal"][1][2] = p.Q("x", p.Eq(zero, zero))
    add("reject_formula_in_term_position", False, document(bad_sort),
        "A formula cannot be supplied as an iterator's numerical initializer.")
    malformed_pair = copy.deepcopy(trivial_di)
    malformed_pair["goal"][2] = "x"
    add("reject_repeated_paired_binder", False, document(malformed_pair),
        "The two variables bound by D must be distinct.")
    add("reject_unknown_rule", False, document(p.node("oracle", p.Eq(zero, p.S(zero)))),
        "There is no trusted theorem, evaluation oracle, or arbitrary induction rule.")
    extra = p.i0(a)
    extra["trust_me"] = True
    add("reject_extra_proof_field", False, document(extra),
        "The exact certificate schema rejects ignored or hidden proof fields.")
    return result
