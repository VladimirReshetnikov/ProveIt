#!/usr/bin/env python3
"""Reproduce checked certificates and public CLI accept/reject observations."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

import checker
import produce_advanced
import produce_basic


ROOT = Path(__file__).resolve().parent


def proof_nodes(value):
    if isinstance(value, dict):
        return int("rule" in value) + sum(proof_nodes(x) for x in value.values())
    if isinstance(value, list):
        return sum(proof_nodes(x) for x in value)
    return 0


def cli(payload, optimized):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(ROOT / "checker.py"))
    run = subprocess.run(command, input=payload, text=True, capture_output=True, timeout=20)
    return {"exit_code": run.returncode, "stdout": run.stdout, "stderr": run.stderr}


def expected_cli(accepted):
    return {"exit_code": 0 if accepted else 1,
            "stdout": "ACCEPT\n" if accepted else "REJECT\n", "stderr": ""}


def main():
    certificates = ROOT / "certificates"
    evidence = ROOT / "evidence"
    certificates.mkdir(exist_ok=True)
    evidence.mkdir(exist_ok=True)
    cases = produce_basic.cases() + produce_advanced.cases()
    names = [item["name"] for item in cases]
    if len(names) != len(set(names)):
        raise RuntimeError("duplicate fixture names")
    rows = []
    for item in cases:
        payload = json.dumps(item["document"], indent=2) + "\n"
        (certificates / (item["name"] + ".json")).write_text(payload, encoding="utf-8")
        error = None
        try:
            checker.verify_document(item["document"])
            accepted = True
        except checker.CheckError as exception:
            accepted = False
            error = str(exception)
        normal = cli(payload, False)
        optimized = cli(payload, True)
        rows.append({"name": item["name"], "expected_accept": item["accept"],
                     "accepted": accepted, "description": item["description"],
                     "proof_nodes": proof_nodes(item["document"]), "error": error,
                     "sha256": hashlib.sha256(payload.encode()).hexdigest(),
                     "cli": normal, "cli_optimized": optimized,
                     "passed": accepted == item["accept"]
                     and normal == expected_cli(item["accept"])
                     and optimized == expected_cli(item["accept"])})

    malformed = []
    for label, payload in [("empty_input", ""), ("broken_json", "{"),
                           ("trailing_json", "{} {}"), ("null_document", "null"),
                           ("array_document", "[]"), ("unknown_document_fields", "{}")]:
        normal, optimized = cli(payload, False), cli(payload, True)
        malformed.append({"name": label, "cli": normal, "cli_optimized": optimized,
                          "passed": normal == expected_cli(False) and optimized == expected_cli(False)})

    source_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in ROOT.glob("*.py")}
    receipt = {"python": sys.version, "source_sha256": source_hashes,
               "certificate_cases": len(rows),
               "expected_accepts": sum(row["expected_accept"] for row in rows),
               "expected_rejects": sum(not row["expected_accept"] for row in rows),
               "malformed_cli_cases": len(malformed),
               "public_cli_runs": 2 * (len(rows) + len(malformed)),
               "all_passed": all(row["passed"] for row in rows + malformed),
               "cases": rows, "malformed": malformed}
    (evidence / "results.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in {"cases", "malformed", "source_sha256"}}, indent=2))
    for row in rows + malformed:
        if not row["passed"]:
            print(json.dumps(row, indent=2))
    return 0 if receipt["all_passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
