PROGRESSION / CLOSURE CALCULUS: READABLE REFERENCE VERIFIER
=========================================================

Purpose and scope
-----------------

checker.py implements the complete six-rule mathematical presentation
described in progress_calculus.tex. It checks an explicit finite proof; it
does not search for a proof, decide arithmetic truth, or invoke a trusted
arithmetic simplifier. This is a readable reference implementation. No
claim compares its source size with the small checkers in docs/drafts.

Runtime requirements: Python 3.10 or later, standard library only.
The recorded run uses CPython 3.12.14. No installed project, theorem library,
network service, code generator, or proof producer is imported by checker.py.

    python3 checker.py < certificates/identity_iterator_uses_induction_hypothesis.json

Successful verification prints exactly ACCEPT and exits with status 0.
Rejected input prints exactly REJECT and exits with status 1. The CLI does
not expose a diagnostic traceback; the importable verify_document function
raises CheckError with a reason. Python -O gives the same rule checks: no
acceptance gate is implemented with assert.

    python3 run_tests.py

The runner regenerates the concrete JSON certificates, checks their API
verdicts, runs the public CLI normally and under -O, and writes
evidence/results.json. It checks stdout, stderr, and exit status together.
The receipt, rather than a count copied into this text, is authoritative
for the final number and outcome of the tests.

Files
-----

checker.py          Complete trusted certificate verifier and CLI.
produce_basic.py    Untrusted concrete examples and malformed/scope controls.
produce_advanced.py Untrusted expanded mathematical proof construction.
run_tests.py        Regression runner; never imported by checker.py.
certificates/      Explicit readable JSON proofs and rejected controls.
evidence/results.json
                    Reproduced verdicts, purposes, proof-node counts,
                    source hashes, fixture hashes, and CLI observations.

The producers may use helper functions or assertions. They are outside the
verifier's trust boundary. They supply only explicit JSON proof trees to
the same public verification interface as any other input.

Numerical and logical syntax
----------------------------

Variable names are nonempty ASCII identifiers of the form
[A-Za-z_][A-Za-z_0-9]*. All abstract-syntax nodes are JSON arrays with exact
arities. Numbers, booleans, null, objects, and strings are not numerical
term nodes. In particular, a JSON number is not an encoded numeral.

Terms:

    ["v", "x"]                        variable x
    ["0"]                             zero
    ["s", t]                          successor of t
    ["i", n, a, "u", h]               I(n,a;u.h)

In the iterator only h binds u. The counter n and initializer a are outside
that binder. An update is a fixed finite term and may have free numerical
parameters, as in the inherited scalar-iterator basis. No numerical
argument is treated as a program code, and there is no universal evaluator.

Formulas:

    ["=", s, t]                       equality
    ["q", "y", A]                    unary closure/progression Q_y A
    ["d", "x", "y", A]               paired binder D_{x,y} A

The two D variables must be distinct. Bound names may be shadowed in inner
binders; the verifier compares bound structure by alpha equivalence and
preserves free names exactly. There are no primitive ordinary connectives,
quantifiers, or falsity nodes. The paper constructs those as macros. Its
native contradiction is the equality 0=S0.

An equation is literal only if its outermost tag is "=". An equation
beneath q or d is compound for every atomhood check.

The new interpretation is shape sensitive:

    Q_y E(y) = forall y (E(y) -> E(Sy))       for a literal equation E
    Q_y A(y) = A(0) -> forall y A(y)         for a compound A
    D_{x,y} B = exists x Q_y B.

This is the changed mathematical interface, not the old conditional-closure
meaning applied unchanged to atomic matrices.

Document and proof-node format
------------------------------

The outer JSON object has exactly two fields:

    {"context": [A_0, ..., A_(k-1)], "proof": NODE}

The context is a reusable list of native formulas. It is empty for a
theorem. Free numerical variables are permitted as parameters. Every node
has rule and goal fields, plus exactly the additional fields listed below.
Unknown fields and unknown rules are rejected.

Hypothesis:

    {"rule":"hyp", "goal":A, "index":j}

The index is an actual JSON integer with 0 <= j < context length. Boolean
and negative indices are rejected. The goal must be alpha-equivalent to
the selected assumption. Context indices are absolute, with each local
assumption appended to the end.

Computation schemas:

    {"rule":"i0", "goal": ["=", ["i", ["0"], a, u, h], a]}

    {"rule":"is", "goal":
       ["=", ["i", ["s", n], a, u, h], h[I(n,a;u.h)/u]]}

The right side of IS is checked by capture-avoiding syntactic substitution.
These are the two computation axiom schemas, in their displayed direction.
Reverse equations require an explicit equality derivation.

Paired introduction:

    {"rule":"di", "goal":["d",x,y,B],
     "witness":t, "fresh":z, "step":P}

If B is a literal equation, P is checked with B(t,z) appended. Otherwise
P is checked with B(t,0) appended. Its conclusion must be B(t,Sz).
The variable z must be absent from all retained assumptions, from t, and
from the free fixed parameters of B. Opening x and y is simultaneous:
free variables of the witness are never substituted into by the second
opening operation. DI appends exactly one local assumption.

Base elimination:

    {"rule":"qe0", "goal":B(t), "major":P,
     "minor":R, "target":t}

P proves Q_y B(y) and R proves B(0), both in the retained context.
This rule is available at every matrix and every numerical target.

Atomic progress elimination:

    {"rule":"qep", "goal":E(St), "major":P,
     "minor":R, "target":t}

P proves Q_y E(y), whose matrix must be a literal equation; R proves E(t).
The compound-matrix case is rejected even when an equation occurs beneath
its outer binder. QE0 and QE+ are the expanded six-rule presentation; the
optional syntactic-target dispatcher in the paper is not used here.

Paired elimination:

    {"rule":"de", "goal":F, "major":P, "fresh":a, "step":R}

P proves D_{x,y} B(x,y). R is checked with Q_y B(a,y) appended and must
prove F. The variable a is fresh for the retained context, F, and the free
fixed parameters of B. Forming the local Q assumption avoids capture by
renaming its binder when necessary.

Numerical transport:

    {"rule":"tr", "goal":F(t), "equality":P, "minor":R,
     "var":v, "motive":F(v)}

P proves a literal equation s=t; R proves F(s). The motive is a complete
native formula with any number of free occurrences of v, including zero.
Both instantiations are checked by capture-avoiding substitution. Equality
reflexivity, symmetry, transitivity, and congruence are derived proofs,
not extra trusted branches.

Why the reference verifier matches the rules
-------------------------------------------

Formation. parse_term and parse_formula accept precisely the tagged grammar,
including exact arities, binder names, and distinct paired variables. They
convert it to immutable tuples before a rule uses it. No theorem certificate
can insert a formula as a numerical term or disguise a compound formula as
an equation. Every node's explicit goal is parsed, not merely its root goal.

Binding. Free-variable functions follow the scopes just specified. Term
substitution enters an iterator's actual arguments, removes its bound update
variable from the substitution's scope, and renames a conflicting update
binder before insertion. Formula substitution does the corresponding work
for q and d. Fresh names avoid all names in the body and replacement. Two
simultaneous openings first use fresh temporary holes and then insert the
two replacements, so one replacement never alters the other.

Alpha equivalence. The comparison functions translate bound occurrences to
their relative binder distances and keep free names literal. They include
both formula binders and the iterator's update binder in the same numerical
scope stack. Thus changing a bound name is harmless, while capture and
changing a free parameter are observable.

Inference reconstruction. Induct on the finite proof tree. Hyp uses an
actual retained assumption. I0/IS are exact instances of their schemas.
DI constructs its required single local assumption, checks freshness, and
checks the prescribed successor conclusion. QE0 and QE+ reconstruct the
two instances of the matrix, and QE+ checks literal atomhood. DE constructs
its local closure and checks the witness condition before checking the
continuation. Tr checks both exact motive instances. These exhaust the
accepted rule names. Consequently an accepted certificate gives a derivation
in the six-rule calculus, provided the written syntax/substitution routines
implement the displayed finite operations correctly.

Conversely, every finite derivation in that calculus can be encoded with
these nodes, explicit premises, and context indices. Bound variables may be
renamed as needed. This is rule coverage for a given finite derivation, not
a decision procedure for theoremhood. As with every executable checker,
available memory and Python's recursion depth bound the proofs a concrete
run can process. Resource exhaustion is never treated as acceptance.

Meaningful examples and controls
-------------------------------

The accepted certificates include I0/IS, derived reflexivity, a free-counter
identity-iterator theorem that genuinely consumes its induction hypothesis,
an arbitrary local QE+ step, existential padding introduction/elimination,
the protected closure C_y(y=1), and an outer protected base retained while
an inner atomic induction is run. The last two distinguish the repaired
calculus from the unsound shortcut of deleting the old atomic base while
keeping the old interpretation.

Scope examples cover alpha renaming, simultaneous witness opening, formula
capture avoidance, and capture avoidance inside an iterator update.

Rejected controls include compound QE+, a forged old atomic base, dropping
the induction hypothesis from an orbit step, wrong DI/DE eigenvariables,
capturing substitutions, altered computation values, false hypothesis
indices, type confusion, repeated paired binders, unknown rules, and extra
fields. A separate CLI group checks malformed and ill-shaped JSON inputs.

Limitations
-----------

The test receipt substantiates these explicit finite cases. It is not a
machine-checked proof of soundness, completeness, or the bi-interpretability
theorem. The written induction-on-proof argument is the reference verifier's
correctness argument; the paper supplies the mathematical reconstruction
and relies on the attributed scalar-arithmetic development. No Lean or Rocq
certification is asserted.

The checker and its tests do not establish global minimality, an absolute
proof-checker lower bound, or a reduction below 309 normalized tokens,
344 AST nodes, and 864 normalized bytes. No random-testing count or successful
standard-model computation is substituted for a nonstandard-model argument.

The CLI's standard-library parser and Python runtime are trusted. The
verifier does not use eval, exec, user imports, network access, program-code
decoding, or an external arithmetic oracle. Ordinary logical macros and
derived proof helpers are untrusted producers: their fully expanded
certificates must pass the same kernel as hand-written input.
