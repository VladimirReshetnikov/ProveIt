"""Untrusted proof producer for substantive progression-calculus examples.

This file is not imported by the checker.  Every generated proof is checked
by the public verify_document interface, from its explicit JSON syntax.
The examples exercise equality, contextual equation induction, existential
padding, and the protected closure that replaces the old retained base.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path


_counter = 0


def fresh(prefix="z"):
    global _counter
    _counter += 1
    return f"{prefix}{_counter}"


def V(name):
    return ["v", name]


def Z():
    return ["0"]


def S(a):
    return ["s", a]


def I(n, a, u, h):
    return ["i", n, a, u, h]


def Eq(a, b):
    return ["=", a, b]


def Q(y, a):
    return ["q", y, a]


def D(x, y, a):
    return ["d", x, y, a]


def tfv(t):
    if t[0] == "v":
        return {t[1]}
    if t[0] == "0":
        return set()
    if t[0] == "s":
        return tfv(t[1])
    return tfv(t[1]) | tfv(t[2]) | (tfv(t[4]) - {t[3]})


def st(t, var, value):
    tag = t[0]
    if tag == "v":
        return copy.deepcopy(value) if t[1] == var else copy.deepcopy(t)
    if tag == "0":
        return Z()
    if tag == "s":
        return S(st(t[1], var, value))
    _, n, a, u, h = t
    n, a = st(n, var, value), st(a, var, value)
    if u == var:
        return I(n, a, u, copy.deepcopy(h))
    if u in tfv(value):
        new = fresh("alpha")
        h, u = st(h, u, V(new)), new
    return I(n, a, u, st(h, var, value))


def sf(a, var, value):
    if a[0] == "=":
        return Eq(st(a[1], var, value), st(a[2], var, value))
    if a[0] == "q":
        _, y, body = a
        if y == var:
            return copy.deepcopy(a)
        if y in tfv(value):
            new = fresh("alpha")
            body, y = sf(body, y, V(new)), new
        return Q(y, sf(body, var, value))
    _, x, y, body = a
    if var in {x, y}:
        return copy.deepcopy(a)
    if x in tfv(value):
        new = fresh("alpha")
        body, x = sf(body, x, V(new)), new
    if y in tfv(value):
        new = fresh("alpha")
        body, y = sf(body, y, V(new)), new
    return D(x, y, sf(body, var, value))


def node(rule, goal, **extra):
    return {"rule": rule, "goal": goal, **extra}


def weaken(proof, cutoff, amount=1):
    """Insert assumptions before the local assumptions inside a proof tree.

    Hypothesis indices below cutoff name retained assumptions and do not move.
    Indices at/above cutoff name assumptions appended by nested inference
    nodes; those must move even though this weakening is at the tree root.
    """
    if isinstance(proof, list):
        return [weaken(value, cutoff, amount) for value in proof]
    if not isinstance(proof, dict):
        return proof
    result = {key: weaken(value, cutoff, amount) for key, value in proof.items()}
    if result.get("rule") == "hyp" and result["index"] >= cutoff:
        result["index"] += amount
    return result


def hyp(context, goal):
    return node("hyp", goal, index=context.index(goal))


def i0(a, u=None, h=None):
    u = u or fresh("update")
    h = Z() if h is None else h
    return node("i0", Eq(I(Z(), a, u, h), a))


def istep(n, a, u, h):
    return node("is", Eq(I(S(n), a, u, h), st(h, u, I(n, a, u, h))))


def tr(equality, minor, var, motive):
    return node(
        "tr", sf(motive, var, equality["goal"][2]),
        equality=equality, minor=minor, var=var, motive=motive,
    )


def refl(t):
    equation = i0(t)
    v = fresh("hole")
    return tr(equation, equation, v, Eq(V(v), t))


def sym(equation):
    s = equation["goal"][1]
    v = fresh("hole")
    return tr(equation, refl(s), v, Eq(V(v), s))


def trans(first, second):
    s = first["goal"][1]
    v = fresh("hole")
    return tr(second, first, v, Eq(s, V(v)))


def successor_congruence(equation):
    left = equation["goal"][1]
    v = fresh("hole")
    return tr(equation, refl(S(left)), v, Eq(S(left), S(V(v))))


def selector(n, a, b):
    return I(n, a, fresh("update"), b)


def gate(z, formula):
    if formula[0] == "=":
        return Eq(selector(z, Z(), formula[1]), selector(z, Z(), formula[2]))
    if formula[0] == "q":
        return Q(formula[1], gate(z, formula[2]))
    return D(formula[1], formula[2], gate(z, formula[3]))


def constant_selector_zero(a, b):
    u = fresh("update")
    return i0(a, u, b)


def constant_selector_successor(n, a, b):
    u = fresh("update")
    return istep(n, a, u, b)


def explode(contradiction, left, right):
    """Derive left=right from a proof of 0=S0, using only I0/IS/Tr."""
    u = fresh("update")
    at_zero = i0(left, u, right)
    at_one = istep(Z(), left, u, right)
    hole = fresh("hole")
    motive = Eq(left, I(V(hole), left, u, right))
    left_to_one = tr(contradiction, sym(at_zero), hole, motive)
    return trans(left_to_one, at_one)


def qi(context, y, matrix, build_step):
    """Derived QI. build_step receives the actual one-item local context."""
    x, z, a = fresh("unused"), fresh("eigen"), fresh("witness")
    local = sf(matrix, y, V(z) if matrix[0] == "=" else Z())
    step = build_step(context + [local], z)
    paired = node("di", D(x, y, matrix), witness=Z(), fresh=z, step=step)
    conclusion = Q(y, matrix)
    return node(
        "de", conclusion, major=paired, fresh=a,
        step=hyp(context + [conclusion], conclusion),
    )


def escope(body, x=None, y=None):
    x, y = x or fresh("exists"), y or fresh("gate")
    return {"x": x, "y": y, "body": body, "formula": D(x, y, gate(V(y), body))}


def einst(spec, var, value):
    return {
        "x": spec["x"], "y": spec["y"],
        "body": sf(spec["body"], var, value),
        "formula": sf(spec["formula"], var, value),
    }


def ein(context, spec, witness, body_proof):
    """Existential introduction for an equation body; no logical oracle."""
    z = fresh("eigen")
    body = sf(spec["body"], spec["x"], witness)
    assert body[0] == "="
    left, right = body[1:]
    body_proof = weaken(body_proof, len(context))
    left_endpoint = constant_selector_successor(V(z), Z(), left)
    right_endpoint = constant_selector_successor(V(z), Z(), right)
    successor = trans(trans(left_endpoint, body_proof), sym(right_endpoint))
    return node("di", spec["formula"], witness=witness, fresh=z, step=successor)


def eout(context, spec, major, goal, build_branch):
    """Existential elimination for an equation body, expanded to DE/QE0/Tr."""
    a = fresh("witness")
    instantiated = sf(spec["body"], spec["x"], V(a))
    assert instantiated[0] == "="
    left, right = instantiated[1:]
    _, x, y, matrix = spec["formula"]
    q_matrix = sf(matrix, x, V(a))
    closure = Q(y, q_matrix)
    local_context = context + [closure]
    zero = trans(
        constant_selector_zero(Z(), left),
        sym(constant_selector_zero(Z(), right)),
    )
    at_one = sf(q_matrix, y, S(Z()))
    gate_proof = node(
        "qe0", at_one, major=hyp(local_context, closure), minor=zero,
        target=S(Z()),
    )
    left_endpoint = constant_selector_successor(Z(), Z(), left)
    right_endpoint = constant_selector_successor(Z(), Z(), right)
    body_proof = trans(trans(sym(left_endpoint), gate_proof), right_endpoint)
    return node(
        "de", goal, major=major, fresh=a,
        step=build_branch(local_context, a, body_proof),
    )


def make_examples():
    examples = []

    def add(name, context, proof, expected, purpose):
        examples.append((name, {"context": context, "proof": proof}, expected, purpose))

    # A direct consequence of atomic progression at an arbitrary point.
    y, n = fresh("bound"), fresh("free")
    equation = Eq(V(y), S(Z()))
    closure = Q(y, equation)
    at_n = sf(equation, y, V(n))
    context = [closure, at_n]
    qep = node(
        "qep", sf(equation, y, S(V(n))),
        major=hyp(context, closure), minor=hyp(context, at_n), target=V(n),
    )
    add("atomic_progress_local_step", context, qep, True,
        "QE+ must expose the local progression consequence, with no zero base.")

    # The full zero-initialized equation-induction rule remains available.
    n, y, u = fresh("free"), fresh("bound"), fresh("update")
    equation = Eq(I(V(y), Z(), u, Z()), Z())
    closure_proof = qi([], y, equation, lambda context, z: istep(V(z), Z(), u, Z()))
    all_zero = node(
        "qe0", sf(equation, y, V(n)), major=closure_proof,
        minor=i0(Z(), u, Z()), target=V(n),
    )
    add("zero_iterator_equation_induction", [], all_zero, True,
        "Closed proof of I(n,0;u.0)=0 for arbitrary n via native equation induction.")

    # A theorem expressing the old conditional closure of y=1.
    y, w = fresh("bound"), fresh("unused")
    atom = Eq(V(y), S(Z()))
    padding = escope(atom, x=w)
    matrix = padding["formula"]

    def protected_step(context, z):
        base_spec = einst(padding, y, Z())
        step_spec = einst(padding, y, S(V(z)))
        base = hyp(context, base_spec["formula"])

        def branch(branch_context, unused, contradiction):
            arbitrary_equation = explode(contradiction, S(V(z)), S(Z()))
            return ein(branch_context, step_spec, Z(), arbitrary_equation)

        return eout(context, base_spec, base, step_spec["formula"], branch)

    protected = qi([], y, matrix, protected_step)
    add("protected_closure_y_equals_one", [], protected, True,
        "Closed proof of C_y(y=1)=Q_y E_unused(y=1), using its retained compound base.")

    # The general retained-base atomic introduction is implemented by an
    # inner atomic induction while the existentially padded base is retained.
    # The two free initial states need not be equal without that base.
    y, a, b, u = fresh("bound"), fresh("left"), fresh("right"), fresh("update")
    atom = Eq(I(V(y), V(a), u, S(V(u))), I(V(y), V(b), u, S(V(u))))
    padding = escope(atom)

    def nested_induction_step(context, outer_z):
        base_spec = einst(padding, y, Z())
        step_spec = einst(padding, y, S(V(outer_z)))
        base = hyp(context, base_spec["formula"])

        def branch(branch_context, unused, base_equation):
            def arithmetic_step(inner_context, inner_z):
                induction_equation = sf(atom, y, V(inner_z))
                ih = hyp(inner_context, induction_equation)
                left_step = istep(V(inner_z), V(a), u, S(V(u)))
                right_step = istep(V(inner_z), V(b), u, S(V(u)))
                return trans(trans(left_step, successor_congruence(ih)), sym(right_step))

            progression = qi(branch_context, y, atom, arithmetic_step)
            successor_equation = node(
                "qe0", sf(atom, y, S(V(outer_z))), major=progression,
                minor=base_equation, target=S(V(outer_z)),
            )
            return ein(branch_context, step_spec, Z(), successor_equation)

        return eout(context, base_spec, base, step_spec["formula"], branch)

    nested = qi([], y, padding["formula"], nested_induction_step)
    add("protected_closure_nested_atomic_induction", [], nested, True,
        "Closed protected closure for equality of two successor iterators; retains the outer base while running an inner atomic induction.")

    # The exact failed old-base shortcut: assume 0=1 in atomic DI even
    # though the new rule makes only z=1 available at that point.
    y = fresh("bound")
    atom = Eq(V(y), S(Z()))

    def old_base_step(actual_context, z):
        false_base = node("hyp", Eq(Z(), S(Z())), index=len(actual_context) - 1)
        return explode(false_base, S(V(z)), S(Z()))

    forbidden = qi([], y, atom, old_base_step)
    add("reject_old_retained_atomic_base", [], forbidden, False,
        "Reject the old proof of Q_y(y=1): atomic DI supplies z=1, not 0=1.")

    # Extending QE+ to compound matrices is unsound.  These two assumptions
    # hold in the standard model, but its requested conclusion does not.
    y, w = fresh("bound"), fresh("unused")
    padded = escope(Eq(V(y), S(Z())), x=w)["formula"]
    closure = Q(y, padded)
    at_one = sf(padded, y, S(Z()))
    context = [closure, at_one]
    bad = node(
        "qep", sf(padded, y, S(S(Z()))), major=hyp(context, closure),
        minor=hyp(context, at_one), target=S(Z()),
    )
    add("reject_compound_progress_elimination", context, bad, False,
        "Compound conditional closure plus A(1) does not imply A(2); QE+ must be atomic.")

    # A direct existential introduction and elimination round trip at equality.
    n, w = fresh("free"), fresh("unused")
    identity = Eq(V(n), V(n))
    spec = escope(identity, x=w)
    package = ein([], spec, Z(), refl(V(n)))
    unpacked = eout([], spec, package, identity, lambda context, a, proof: proof)
    add("existential_padding_roundtrip", [], unpacked, True,
        "Explicit E introduction/elimination, including its gated zero premise and DE scope.")

    return examples


def proof_nodes(value):
    if isinstance(value, dict):
        return ("rule" in value) + sum(proof_nodes(v) for v in value.values())
    if isinstance(value, list):
        return sum(proof_nodes(v) for v in value)
    return 0


def cases():
    return [
        {"name": name, "accept": expected, "document": document, "description": purpose}
        for name, document, expected, purpose in make_examples()
    ]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path(__file__).parent / "advanced_fixtures")
    parser.add_argument("--write-only", action="store_true")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if not args.write_only:
        from checker import verify_document
    results = []
    for name, document, expected, purpose in make_examples():
        path = args.out / (name + ".json")
        path.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")
        result = {"name": name, "expected": expected, "purpose": purpose,
                  "proof_nodes": proof_nodes(document), "bytes": path.stat().st_size}
        if not args.write_only:
            try:
                verdict = verify_document(document)
                accepted = verdict is not False
                result["verifier_result"] = str(verdict)
            except Exception as error:
                accepted = False
                result["verifier_error"] = f"{type(error).__name__}: {error}"
            result["accepted"] = accepted
            result["passed"] = accepted == expected
        results.append(result)
    (args.out / "manifest.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))
    if not args.write_only and not all(row["passed"] for row in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
