"""Create a reproducible archive of the complete deliverable and its hashes."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def include(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and "__pycache__" not in relative.parts
            and not any(part.startswith(".") for part in relative.parts)
            and path.suffix not in EXCLUDED_SUFFIXES
            and relative.as_posix() != "MANIFEST.json")


def main():
    files = sorted(path for path in ROOT.rglob("*") if include(path))
    manifest = {path.relative_to(ROOT).as_posix(): {"size": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in files}
    manifest_path = ROOT / "MANIFEST.json"
    manifest_path.write_text(json.dumps({"files": manifest}, indent=2) + "\n")
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted(files + [manifest_path]):
            name = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(name, (2026, 11, 9, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            output.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None:
            raise SystemExit("Archive integrity failure")
        for name, entry in manifest.items():
            data = check.read(ROOT.name + "/" + name)
            if hashlib.sha256(data).hexdigest() != entry["sha256"]:
                raise SystemExit("Archive member mismatch: " + name)
    print(json.dumps({"archive": str(archive), "members": len(files) + 1, "size": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()
