# Critical review and exact boundary tests

Snapshot: `e707d8bd1bcbc036631663e7538efd8b42b1e130`, current
`docs/drafts` corpus, 9 November 2026.

## Reviewed source arguments

1. `ipra_one_fixed_recurrence_2026-11-09/sections/signed_stationarity.tex`.
   The dependency order is sound on paper: finite coverage cases give the
   elementary signed inverse; zero stationarity gives the negative diagonal;
   signed-action fusion gives a two-sided inverse for every internally
   indexed iterator; this gives arbitrary-value stationarity; two-periodic
   correction gives the actual parity decomposition; that decomposition
   proves `H(D(n))=n`. The inverse theorem is proved before it is used for
   cancellation. Passive parameters are independently generalized before
   diagonal substitution. No immediate circularity or numeral-only argument
   was found. Full primitive-recursive descriptions, `Cov`, and `Sep` remain
   substantial assumptions.

2. `ipra_two_diagonal_2026-11-09.tex`, sections 2–7.
   Before induction, the source proves only the range/reflexivity facts its
   raw test needs. The ramp initially has values `Clock(a), b`, not `a, b`.
   The anchored rule derives restricted reflection. The deliberately forced
   clock diagonal then calibrates the clock, after which reflection becomes
   full. Target soundness of the anchored rule is a separate argument using
   target induction. The proof does not silently assume source reflection.
   No immediate gap was found. The source still charges ordinary logic,
   closed-update syntax, `BR`, and `Sep`.

Neither paper gives a complete checker below the present `309 / 344 / 864`
literal-source measurement. Both say this explicitly. Repackaging either
construction is not a new below-frontier result.

## Product test for deleting the logical boundary

Let `N_PR` be the standard natural numbers with every fixed PR description
interpreted by its intended function. Give `A = N_PR × N_PR` all numerical
operations coordinatewise, actual equality, and ordinary classical logical
semantics. This is also a one-node intuitionistic model.

Every numerical term is evaluated coordinatewise. The model satisfies all
computation equations and `0=S0 -> bottom`. It fails numerical coverage at
`(0,1)`: this is neither `(0,0)` nor a coordinatewise successor. It fails the
range sentence for the zero tester, since `Z(0,1)=(1,0)` is neither the
domain's zero nor its one.

The signed uniqueness rule is nevertheless sound in A when `Cov` is omitted.
Fix any assignment satisfying its retained context. Its eigenvariable is
absent from that context. If the recurrence premise holds for every pair z,
then for either coordinate it holds for every natural number z_i with the
corresponding fixed parameter coordinates. The standard factor validates
the rule by ordinary equation induction. Applying it in the two coordinates
gives exactly the required pair equality.

The same argument applies to the anchored-reset rule when `BR` is omitted.
The guard and reset are fixed terms, hence coordinatewise. In each standard
factor the rule has the target soundness already proved in the source
report. Thus its universal premise implies its equality conclusion in A.
Arbitrary retained contexts cause no problem: the rule is checked at a
fixed true assignment, and freshness leaves that assignment fixed during
the eigenvariable variation.

Consequently neither bare deletion can yield the same theory as iPRA. The
coordinate swap is a nonidentity order-two automorphism; parameter-free
definable bi-interpretability with iPRA is impossible because every iPRA
model has a definable strict linear order, and its automorphism group has no
nonidentity finite-order element.

For arbitrary finite interpretation parameters, use `N_PR^I` with I
uncountable. For even countably many parameters across the interpretation
formulas, choose `|I| > 2^(aleph_0)`. All numerical operations remain
coordinatewise and both rule-validity arguments remain unchanged. The
column of parameter values at an index is a countable sequence of natural
numbers; at most continuum many distinct columns occur. Two indices have
the same parameter column. Swapping them is a nonidentity involution fixing
every parameter. It descends through any definable subdomain, finite tuple
domain, or definable quotient used by an interpretation. On the interpreted
iPRA domain it must be identity because it preserves a strict linear order.
On the double interpretation it is therefore also identity. Invariance of
the definable round-trip isomorphism then forces the original swap to be
identity, a contradiction. This makes the obstruction parameter-robust;
it is the established large-product mechanism, not a new global result.

This is an obstruction to those exact deletions, not a lower bound on all
proof checkers. A modified rule with a non-product-preserving logical
conclusion can escape it.

## A genuine but already known separation simplification

For the ordinary two-diagonal presentation one can remove primitive bottom
from the formula grammar and define bottom as `0=1`, deleting `Sep`. Under
`0=1`, the mask computations give

    a = I_0(0,a) = I_0(S0,a) = 0.

Thus all equations hold. External structural induction on formulas using
conjunction, disjunction, implication, and the two quantifiers gives their
explosion. Mapping target bottom to `0=1` and keeping all other logical
constructors gives the usual faithful bottom-free presentation. The native
drafts already use this mechanism, so it is not a novel breakthrough.

## Categorical literature boundary

* Lingyuan Ye, *Categorical Structure in Theory of Arithmetic*,
  arXiv:2304.05477 (published as *Categorical structure in coherent theory of
  arithmetic*, TCS 1071 (2026), 115832), treats initial coherent categories
  with a parametrized natural-numbers object and a Σ1/Π2 fragment of IΣ1.
  Equal provably total function classes are not the required full
  first-order bi-interpretability theorem.
* Ulrik Buchholtz and Johannes Schipp von Branitz, *Primitive Recursive
  Dependent Type Theory*, arXiv:2404.01011, proves the PR nature of definable
  numerical functions under a universe restriction. It likewise does not
  supply this task's internal first-order round-trip identifications.

## Native normalization caution

The current atomic-transport report already proves that restricting all
paired-elimination majors to assumptions loses the equation
`I_id(c,a)=a` at a free numerical parameter c (or its shifted analogue).
An empty-context atomic proof in that restricted calculus has only the
computation equations and equational replacement; the free-counter term
and a are distinct rewrite normal forms. An explicit induction/cases or
cut mechanism must replace the discarded composite derivation. Ordinary
cut cannot just be called inherited after changing allowed major premises.
