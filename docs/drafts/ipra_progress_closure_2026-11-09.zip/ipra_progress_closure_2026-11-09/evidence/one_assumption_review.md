# Independent review of the one-local-assumption calculus

This note reviews the candidate proposed during this session. It does not
certify its Python implementation or claim a measured checker reduction.

## The exact semantic change

For a literal equation E, read `Q_y E(y)` as progress:

    forall y (E(y) -> E(Sy)).

For a compound native matrix A, retain the closure reading:

    A(0) -> forall y A(y).

Read `D_{x,y} B(x,y)` as `exists x Q_y B(x,y)` with this shape-sensitive
meaning. Introduction retains exactly one local assumption: E(z) in the
literal-equation case, A(0) in the compound case. The equality-major,
hypothesis, computation, and paired elimination rules are otherwise the
inherited ones. Q has two eliminations: its old base-to-arbitrary-value
elimination QE0, and its new atomic progress elimination QE+.

Soundness of atomic QE0 uses the target's equation induction. Soundness of
atomic QE+ is direct from its progress reading. Compound QE0 is direct from
its closure reading. Introduction is direct for equations and uses numerical
zero/successor coverage for compound matrices. Thus no induction on an
arbitrary quantified formula has entered the system.

## Why raw mixed-shape binder congruence must not be used

Even if E(y) and A(y) are uniformly interderivable, their native Q formulas
need not have the same meaning when E is atomic and A is compound. Their
meanings are progress and conditional totality respectively. The old
unrestricted binder-congruence proof therefore does not transfer verbatim.

Shape-preserving Q congruence does hold. In the atomic case, to introduce
Q B under B(z), convert to A(z), use QE+ on Q A, and convert A(Sz) back to
B(Sz). In the compound case retain B(0), convert it to A(0), use QE0, and
convert back. Paired congruence uses DE and this same introduction argument.

## Gates and protected constructors

Numerical gates preserve logical shape. Their equation endpoints, lifted
only through the shape-preserving congruence just proved, give a theorem
G_0 A and uniform interderivability `G_{St} A <-> A`.

Define

    Exists_x A := D_{x,y} G_y A,
    Pad(A)     := Exists_w A             (w unused),
    C_y A      := Q_y Pad(A).

`Exists` has the full ordinary existential introduction and elimination
rules for every A. Introduction from A(t) produces G_{Sz} A(t) and ignores
the one optional local assumption. Elimination opens Q G_y A(a), proves its
zero gate, applies QE0 at one, and recovers A(a). The converse construction
is the same. Thus `Pad(A) <-> A`, with Pad(A) always compound.

The protected C constructor therefore has the usual closure meaning and
unrestricted matrix congruence. It is safe across arbitrary changes of
native logical shape. Subsequent selectors and the ordinary logical
constructors must use these protected constructors, or a separately proved
uniform embedding into their grammar.

## Recovering the arithmetic use of the old closure

Atomic equation induction is immediately obtained from atomic QI and QE0.
Suppose a literal matrix E has a supplied base and an induction step. QI
builds its progress formula, and QE0 applies the supplied base at any target.

To reproduce the old retained-base introduction through C, assume Pad(E0),
unpack it to E0, and keep this assumption in the retained context. Under
that context the old supplied step has the form E(z) -> E(Sz). New atomic
QI and QE0 perform equation induction, yielding E(Sz) for the fresh target.
Repack its existential padding and introduce C. This handles precisely the
atomic induction that is not available merely from the compound C rule.

For a compound old matrix, the old premise already has only its retained
base, so unpacking/repacking the padding gives the required C introduction
directly. The protected existential and C thus reproduce the old native
arithmetic/logical basis, rather than only its pure logical fragment.

## Native round trips

After the protected ordinary logical constructors are available:

* For literal E, `Q_y E <-> forall_* y (E(y) ->_* E(Sy))`.
  Forward: under E(y), QE+ gives E(Sy), so introduce implication and
  universal quantification. Reverse: under the DI/QI assumption E(z),
  specialize the supplied universal and apply implication elimination.
* For compound A, `Q_y A <-> (A(0) ->_* forall_* y A(y))`.
  Forward: under A0 apply QE0 at a fresh y. Reverse: under the QI base A0,
  apply the implication and specialize at Sz.
* `D_{x,y} B <-> Exists_x Q_y B`.
  Forward: DE supplies a fresh witness and its Q assumption, then use the
  existential introduction. Reverse: eliminate the protected existential.
  Introduce D with that witness; the atomic case uses QE+ under B(z), while
  the compound case uses QE0 under B0.

These are exact internal native equivalences. They suffice for native
formula round trips by external structural induction, provided the ordinary
logical macros are all interpreted and their own introduction/elimination
rules have been established. Numerical translations are inherited unchanged.
There is no need to assume raw mixed-shape Q congruence.

## Dispatcher specialization

If the concrete checker selects QE+ whenever an atomic instantiation target
is syntactically a successor, and selects QE0 otherwise, no old QE0 instance
is lost. Put

    beta(t) := I(0,t;u.0).

This is not syntactically a successor and has the computation theorem
beta(t)=t. Apply the restricted QE0 to beta(t), then use numerical equality
transport through the matrix. The argument is valid even when t itself is
a successor; beta(t)'s root is the iterator constructor. The implementation
must actually dispatch on this advertised syntactic test and retain the
unrestricted equality-transport rule for this completeness argument.

## Verdict

The repaired mathematical calculus is sound and has a credible complete
bi-interpretation argument. Its proof genuinely differs from the prior
conditional-closure calculus. The unrestricted mixed-shape congruence claim
would be false; the protected constructors are an essential repair. The
extra atomic elimination and its implementation cost must be counted before
claiming a proof-checker improvement.

## Relative sharpness of the remaining atomic assumption

Consider the exact further variant obtained by removing the local equation
E(z) from atomic DI while leaving compound DI and QE-dagger unchanged. Its
atomic Q admits the weaker decoding

    Q_y E(y) := forall y E(Sy).

Keep the old conditional-closure decoding for compound Q. This variant is
sound over ordinary intuitionistic equality logic, PR defining equations,
and numerical coverage, with no induction scheme. Atomic introduction is
universal introduction for its already-proved successor values. QE+ follows
directly from that universal. QE0 combines the supplied value at zero with
the universal successor values by numerical coverage. Compound introduction
and elimination retain their earlier coverage argument, and DE is ordinary
existential elimination.

The current one-fixed-recurrence report supplies a full-recursion
description-indexed linear-fibre model that fails equation induction.
Transferring that model to the present parameterized scalar binder requires
an additional substitution-coherence argument: instantiating a passive
parameter in an update must agree with instantiating the corresponding
parameter of its chosen iterator. Bare defining equations for separately
indexed recursion descriptions do not supply this automatically.

Accordingly, the weaker decoding above is established, but this review does
NOT claim that the cited model has already been transferred to the scalar
language, or that it proves non-bi-interpretability of the modified scalar
calculus. The earlier stronger wording of this note was an overstatement,
identified during the final audit and corrected before delivery. The main
positive bi-interpretation theorem does not use this proposed boundary.

## Final audit of the report's numerical reconstruction

The explicit source-side equality detector is correct:

    K(r)=C(r,1,P(r)),    epsilon(s,t)=K(d(Ss,t)).

Numerical cases give K(r)=0 iff r=1. The single-equation residual induction
gives C(d(y,n),y,n+d(y,n))=y, so epsilon(s,t)=0 gives t+1=Ss and hence s=t.
The non-Boolean quantifier-free characteristic terms are legitimate because
zero means true and numerical coverage makes every alternative a successor;
no unproved Boolean-range assertion is needed. Equation induction then gives
full QFI before the bounded square-root search begins.

For the root search, the increment test contradicts the invariant's strict
upper-square-bound alternative; thus in that branch R_n(i)=i and the new
state is Si. The no-increment branch retains the strict upper bound. This
proves the stated three-part invariant with n fixed. Square pairing
pi(a,b)=(a+b)^2+a has the claimed projections, and surjectivity is unnecessary
because only recursively constructed states are decoded. Captured fixed
parameters in the update are allowed in this scalar language. Both numerical
composites are justified by internal uniqueness induction at arbitrary
counters, combined with external induction on fixed finite descriptions.

The N×N example in the boundary section correctly satisfies contextual
equation induction: to project a global step to one coordinate, keep the
other at zero where the equation base holds. Its swap gives the stated
classical parameter-free bi-interpretability obstruction. Arbitrary
parameters require a larger-power argument; N×N alone is not sufficient.
