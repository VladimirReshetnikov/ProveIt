"""Replay substantive certificates and recompute the frozen comparison table."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(relative):
    result = subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode:
        raise SystemExit(relative + " failed:\n" + result.stdout + result.stderr)
    return {"script": relative, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}


def main():
    runs = [run("code/progress_checker/run_tests.py"),
            run("code/kernel_variants/validate_pareto.py"),
            run("code/measure.py")]
    tests = json.loads((ROOT / "code/progress_checker/evidence/results.json").read_text())
    metrics = json.loads((ROOT / "evidence/measurements.json").read_text())
    variants = json.loads((ROOT / "code/kernel_variants/pareto_validation.json").read_text())
    if not tests["all_passed"]:
        raise SystemExit("A certificate verdict failed")
    result = {
        "all_passed": True,
        "certificate_cases": tests["certificate_cases"],
        "expected_accepts": tests["expected_accepts"],
        "expected_rejects": tests["expected_rejects"],
        "malformed_cli_cases": tests["malformed_cli_cases"],
        "public_cli_runs": tests["public_cli_runs"],
        "frozen_coordinate_minima": metrics["coordinate_minima"],
        "inherited_kernel_variants": [
            {key: candidate[key] for key in ("file", "normalized_tokens", "ast_nodes", "normalized_bytes", "positive_packets", "public_protocol_runs")}
            for candidate in variants["candidates"]
        ],
        "checker_sha256": hashlib.sha256((ROOT / "code/progress_checker/checker.py").read_bytes()).hexdigest(),
        "runs": runs,
        "scope": "Concrete proof checking, malformed-input controls, public normal/-O interface, and unchanged full-source measurement; not a formalized general bi-interpretability proof.",
    }
    (ROOT / "evidence/reproduction.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "runs"}, indent=2))


if __name__ == "__main__":
    main()
