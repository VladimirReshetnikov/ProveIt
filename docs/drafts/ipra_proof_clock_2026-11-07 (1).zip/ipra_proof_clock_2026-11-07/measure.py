"""Recompute complete-program and core comparisons against pinned source bytes."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('source_measure', ROOT / 'comparison/source_measure.py')
measurement = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measurement)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for item in manifest['programs']:
        actual = measurement.metrics(ROOT / item['local_file'])
        if actual['sha256'] != item['sha256']:
            raise ValueError('Changed comparator: ' + item['local_file'])
        rows.append({**item, **actual})
    minima = {key: min(row[key] for row in rows) for key in KEYS}
    core_minima = {key: min(row['core'][key] for row in rows) for key in KEYS}
    expanded = json.loads((ROOT / 'comparison/expanded/manifest.json').read_text())
    extra = []
    for item in expanded['programs']:
        if not item.get('is_complete_checker'):
            continue
        actual = measurement.metrics(ROOT / item['local_file'])
        if actual['sha256'] != item['sha256']:
            raise ValueError('Changed expanded comparator: ' + item['local_file'])
        extra.append(actual)
    expanded_minima = {key: min(row[key] for row in extra) for key in KEYS}
    expanded_core = {key: min(row['core'][key] for row in extra) for key in KEYS}
    if (expanded_minima, expanded_core) != (minima, core_minima):
        raise ValueError('Expanded inventory changes the comparison envelope')
    proposed = measurement.metrics(ROOT / 'checker.py')
    assert all(proposed[key] < minima[key] for key in KEYS)
    assert all(proposed['core'][key] < core_minima[key] for key in KEYS)
    result = {
        'python': platform.python_version(), 'implementation': platform.python_implementation(),
        'snapshot': manifest['commit'], 'archive_count': len(manifest['archives']),
        'root_program_count': len(rows), 'expanded_complete_checker_paths': expanded['complete_checker_paths'],
        'expanded_distinct_checkers': len(extra), 'coordinatewise_minimum': minima,
        'core_coordinatewise_minimum': core_minima, 'expanded_coordinatewise_minimum': expanded_minima,
        'expanded_core_coordinatewise_minimum': expanded_core, 'proposed': proposed, 'programs': rows,
        'reduction_percent': {key: 100 * (minima[key] - proposed[key]) / minima[key] for key in KEYS},
        'measurement_source_sha256': hashlib.sha256((ROOT / 'comparison/source_measure.py').read_bytes()).hexdigest(),
        'scope': 'Finite pinned implementation corpus; no universal minimality claim.'
    }
    dest = ROOT / 'results'
    dest.mkdir(exist_ok=True)
    (dest / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (dest / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, ('archive', 'member', *KEYS, 'sha256'), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    table = ['\\begin{tabular}{@{}llrrr@{}}', '\\toprule',
             'Archive & Checker & Tokens & AST & Bytes\\\\', '\\midrule']
    for row in rows:
        archive = row['archive'].replace('ipra_', '').replace('_2026-11-07.zip', '').replace('_', ' ')
        member = Path(row['member']).name.replace('_', '\\_')
        table.append(f"{archive} & \\texttt{{{member}}} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}\\\\")
    table.extend(['\\midrule',
        f"\\multicolumn{{2}}{{l}}{{Separate minima}} & {minima['normalized_tokens']} & {minima['ast_nodes']} & {minima['normalized_bytes']}\\\\",
        f"\\multicolumn{{2}}{{l}}{{Proof-clock checker}} & \\textbf{{{proposed['normalized_tokens']}}} & \\textbf{{{proposed['ast_nodes']}}} & \\textbf{{{proposed['normalized_bytes']}}}\\\\",
        '\\bottomrule', '\\end{tabular}'])
    (dest / 'comparison_table.tex').write_text('\n'.join(table) + '\n')
    numbers = {'NewTokens': proposed['normalized_tokens'], 'NewAST': proposed['ast_nodes'],
               'NewBytes': proposed['normalized_bytes'], 'BaseTokens': minima['normalized_tokens'],
               'BaseAST': minima['ast_nodes'], 'BaseBytes': minima['normalized_bytes'],
               'NewCoreTokens': proposed['core']['normalized_tokens'], 'NewCoreAST': proposed['core']['ast_nodes'],
               'NewCoreBytes': proposed['core']['normalized_bytes'], 'BaseCoreTokens': core_minima['normalized_tokens'],
               'BaseCoreAST': core_minima['ast_nodes'], 'BaseCoreBytes': core_minima['normalized_bytes']}
    (dest / 'numbers.tex').write_text(''.join('\\newcommand{\\' + key + '}{' + str(value) + '}\n' for key, value in numbers.items()))
    print(json.dumps({key: result[key] for key in ('snapshot', 'root_program_count', 'expanded_distinct_checkers',
          'coordinatewise_minimum', 'core_coordinatewise_minimum', 'proposed')}, indent=2))


if __name__ == '__main__':
    main()
