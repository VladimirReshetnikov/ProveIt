"""Build the report twice and record a concise PDF build report."""
from pathlib import Path
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    runs = []
    for number in (1, 2):
        run = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
                             cwd=ROOT, capture_output=True, text=True)
        runs.append({'run': number, 'exit_code': run.returncode})
        if run.returncode:
            raise RuntimeError(run.stdout[-7000:] + run.stderr)
    log = (ROOT / 'report.log').read_text(errors='replace')
    overfull = [line for line in log.splitlines() if 'Overfull' in line]
    undefined = [line for line in log.splitlines() if 'undefined' in line.lower()]
    info = subprocess.run(['pdfinfo', str(ROOT / 'report.pdf')], capture_output=True, text=True, check=True).stdout
    pages = int(re.search(r'^Pages:\s+(\d+)', info, re.MULTILINE).group(1))
    result = {'runs': runs, 'pages': pages, 'overfull_boxes': overfull, 'undefined_references': undefined,
              'pdf_bytes': (ROOT / 'report.pdf').stat().st_size}
    (ROOT / 'results/pdf_build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if overfull or undefined:
        raise RuntimeError('The final report needs layout or reference corrections')


if __name__ == '__main__':
    main()
