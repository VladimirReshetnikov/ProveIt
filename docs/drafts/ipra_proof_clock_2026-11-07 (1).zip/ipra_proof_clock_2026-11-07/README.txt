USING THE UNREAD PROOF TO CHOOSE FRESH VARIABLES
A smaller complete presentation of intuitionistic primitive recursive arithmetic
7 November 2026

START HERE
  report.pdf       Complete mathematical report and checker listing.
  report.tex       Main LaTeX source; supporting source is in sections/.
  checker.py       The complete measured acceptance program.

RESULT
  Complete program: 438 normalized tokens, 449 AST nodes, 1246 normalized bytes.
  Current separate minima: 444 tokens, 457 AST nodes, 1313 normalized bytes.
  Checking core: 379 tokens, 386 AST nodes, 1001 normalized bytes.
  Current separate core minima: 381 tokens, 392 AST nodes, 1046 bytes.

  Optional closed-sentence integration: 432 tokens / 440 AST nodes / 1253 bytes.
  Optional declared-parameter integration: 438 / 447 / 1272.
  These combine existing refinements and retain a freshness counter.
  The closed integration has fewer tokens and AST nodes; the main new
  proof-length design has fewer normalized bytes. No single one minimizes
  all three coordinates. See alternatives/README.txt for the interfaces.

  The comparison is against ProveIt commit
    18e3b9b4071c76fb9e817a2eb50d7b12f7246d18
  and includes all 13 root checkers from its six current draft archives.
  An expanded inventory of 183 paths / 70 distinct complete checkers has
  the same minima. Exact comparator sources and identities are included.

NEW MECHANISM
  Let L be the number of unread certificate instructions. Negative names
  -L,...,-1 are reserved. A scope opened after consuming instructions uses
  -(L+1) as its fresh name. Earlier validation guarantees the necessary
  freshness. An instruction-free hypothesis requires the special argument
  supplied in the report. A separate freshness register and parameter
  header are unnecessary.

  The arithmetic calculus and its bi-interpretation with iPRA are inherited
  and credited. This work provides a new, smaller certificate discipline.
  It does not prove a globally shortest axiomatization or claim historical
  priority for all uses of input position as a source of fresh names.

RUN A CERTIFICATE (Python 3.10+; measured with CPython 3.12.14)
  python3 checker.py examples/explicit_fresh_existential_witness.json

REPRODUCE
  python3 reproduce.py
  python3 reproduce.py --pdf

  The latter also requires pdflatex, pdfinfo, and the standard LaTeX packages
  listed in report.tex. Python programs use only the standard library.
  Run from any working directory; paths are resolved relative to this package.

INTERFACE
  The input is a JSON array: reversed proof instructions, then the goal.
  There is no header and the initial assumption context is empty.
  Closed statements retain their ordinary reading independently of proof size.
  For open statements with N instruction cells, abstract parameter x_i is
  encoded as -(N+1+i). This explicit codec is part of the format. Arbitrary
  fixed negative spellings are not accepted at every proof length.
  FORMAT.txt gives the exact syntax, instruction order, and boundary rules.

  Unused earlier cells are tolerated by the kernel but affect the open-goal
  codec through N. The supplied translator emits no unused cells.

TRANSPORT A PREDECESSOR CERTIFICATE
  python3 translator.py validation/source_cases/021_reflexivity_zero.json new.json

  The translator is untrusted. The resulting file is checked by checker.py.
  Its default source is the pinned alternation comparator included here.

CONTENTS
  comparison/      Exact source corpus, manifests, unchanged measurement code.
  examples/        Accepted certificates, including new scope-sensitive cases.
  validation/      Source examples, portable validation scripts, and traces.
  alternatives/    Two smaller integrated variants using an explicit counter.
  results/         Reproducible measurements and validation summaries.
  ATTRIBUTION.txt  Origin of inherited code, mathematics, and report text.
  LICENSE_SOURCE.txt  License of inherited ProveIt sources.
  SHA256SUMS       Integrity manifest for this archive's deliverable files.

VERIFICATION STATUS
  The report proves the native calculus's relationship to full first-order
  iPRA, including its whole-domain composite isomorphisms. It separately proves
  the new sequential checker's freshness, soundness, and serialization
  completeness. Executable tests supplement these mathematical arguments.
  The metatheorems and Python kernel are not machine-formalized in Lean/Rocq.

  Ordinary resource limits may reject sufficiently large valid certificates;
  mathematical completeness uses the conventional unbounded-resource model.
