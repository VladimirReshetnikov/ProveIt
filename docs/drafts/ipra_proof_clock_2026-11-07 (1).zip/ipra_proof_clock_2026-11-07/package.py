"""Write an integrity manifest and the portable research archive."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc'}


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and p.suffix not in EXCLUDED_SUFFIXES
                  and p.name != 'SHA256SUMS' and not p.name.startswith('.'))


def main():
    paths = files()
    (ROOT / 'SHA256SUMS').write_text(''.join(
        hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix() + '\n'
        for p in paths))
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for p in paths + [ROOT / 'SHA256SUMS']:
            info = zipfile.ZipInfo((Path(ROOT.name) / p.relative_to(ROOT)).as_posix(),
                                   date_time=(2026, 11, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            output.writestr(info, p.read_bytes())
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None:
            raise ValueError('Archive integrity check failed')
    print(json.dumps({'archive': archive.name, 'files': len(paths) + 1,
                      'bytes': archive.stat().st_size,
                      'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))


if __name__ == '__main__':
    main()
