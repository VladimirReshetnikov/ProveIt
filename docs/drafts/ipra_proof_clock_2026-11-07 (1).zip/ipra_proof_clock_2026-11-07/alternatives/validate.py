"""Measure and test the optional conventional-counter synthesis variants.

Run python3 alternatives/validate.py from the package root, or use an
absolute script path. Tests reuse the 53 pinned/handbuilt source cases.
The declared variant preserves their theorems; the closed variant checks
closed ground instances obtained by sending external free parameters to 0.
Neither this script nor the source-proof compiler is trusted by a checker.
"""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('alternative_source_transport', ROOT / 'translator.py')
t = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = t
spec.loader.exec_module(t)
mspec = importlib.util.spec_from_file_location('unchanged_source_measure', ROOT / 'comparison/source_measure.py')
measure = importlib.util.module_from_spec(mspec)
mspec.loader.exec_module(measure)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def decoded(value):
    if type(value) is int:
        return (value + 1) // 2 if value > 0 else value
    if type(value) is list:
        return [decoded(x) for x in value]
    return value


def ground(value):
    if type(value) is int and value < 0:
        return 0
    if type(value) is list:
        return [ground(x) for x in value]
    return value


class CounterEmitter:
    def __init__(self, module, tree, mode):
        self.module = module
        self.mode = mode
        self.fixed = t.negative_parameters(tree.goal) if mode == 'declared' else set()
        self.bound = max([-value for value in self.fixed], default=0)
        module.k = -self.bound
        self.cells = []
        self.allocations = []
        self.pruned_source_cells = 0

    def rename(self, value, scope):
        if type(value) is int:
            if value < 0:
                return scope.get(value, value if value in self.fixed else 0)
            return 2 * value - 1 if value > 0 else 0
        if type(value) is list:
            return [self.rename(x, scope) for x in value]
        if type(value) is dict:
            return {key: self.rename(x, scope) for key, x in value.items()}
        return value

    def emit(self, node, context, scope, expected=None):
        module = self.module
        goal = self.rename(node.goal, scope)
        t.require(expected is None or goal == expected, 'Renamed source premise mismatch')
        module.inst(goal)
        if goal in context:
            self.pruned_source_cells += node.size()
            return
        t.require(node.kind != 'hyp', 'Substitution lost a source hypothesis')
        cell = self.rename(node.cell, scope)
        self.cells.append(cell)

        def scoped(body, assumptions, child):
            module.k -= 1
            eigen = module.k
            t.require(eigen not in t.negative_parameters([goal, context]),
                      'Conventional counter did not allocate a fresh name')
            new_scope = dict(scope)
            new_scope[node.eigen] = eigen
            self.allocations.append({'source': node.eigen, 'target': eigen, 'rule': node.kind})
            child_goal = module.inst(body, [[eigen]])
            child_context = context + [module.inst(c, [eigen]) for c in assumptions]
            self.emit(child, child_context, new_scope, child_goal)

        if node.kind == 'q_intro':
            body = goal[0]
            assumptions = [body, module.inst(body, [0])][len(body) % 2:]
            scoped(body, assumptions, node.children[0])
        elif node.kind == 'ex_intro':
            self.emit(node.children[0], context, scope, module.inst(goal[0], [cell[0]]))
        elif node.kind in ('ex_elim', 'q_elim', 'eq_elim'):
            major, annotation = cell
            self.emit(node.children[0], context, scope, major)
            if node.kind == 'ex_elim':
                scoped(goal, major[:1], node.children[1])
            else:
                body, images = (major[0], [0, annotation]) if node.kind == 'q_elim' else (annotation, major)
                premise, result = (module.inst(body, [value]) for value in images)
                t.require(result == goal, 'Target elimination result mismatch')
                self.emit(node.children[1], context, scope, premise)
        elif node.kind == 'compute':
            n, initial, update = goal[0]
            if n:
                n, = n
                initial = module.inst(update, ([n, initial, update], n), 1)
            t.require(initial == goal[1], 'Target computation is not an axiom')
        else:
            raise ValueError('Unknown source inference')


def source_tree(certificate):
    source = t.load(t.DEFAULT_SOURCE, 'alternative_pinned_source')
    actual = t.source_run(source, certificate)
    t.require(actual['accepted'], 'Pinned source rejected certificate')
    recorder = t.Recorder(source, certificate)
    tree = recorder.check(recorder.goal, [])
    t.require(len(recorder.stream) == actual['remaining'] and source.k == actual['final_k'],
              'Source replay disagrees with actual source')
    return tree


def run_module(module, certificate, mode):
    stream = deepcopy(certificate)
    module.k = -len(stream.pop()) if mode == 'declared' else 0
    module.take = stream.pop
    accepted = bool(module.check(stream.pop(), []))
    return {'accepted': accepted, 'remaining': len(stream), 'final_counter': module.k}


def cli(checker, path):
    result = subprocess.run([sys.executable, str(checker), str(path)], capture_output=True, text=True)
    return {'accepted': result.returncode == 0 and result.stdout.strip() == 'ACCEPT',
            'exit_code': result.returncode, 'stdout': result.stdout.strip(), 'stderr': result.stderr.strip()}


def refl_instructions(term):
    major = [[0, term, 0], term]
    return [[major, [1, term]], [], []]


def certificate(goal, instructions):
    return list(reversed(instructions)) + [goal]


def focused_rejections(mode):
    true = [0, 0]
    # Each pair is a canonical proof array before an optional declaration header.
    cases = [
        ('empty_array', [], 'No root goal exists.'),
        ('scalar_goal', certificate(0, [[]]), 'A formula must have a permitted list constructor.'),
        ('boolean_in_term', certificate([False, False], refl_instructions(0)),
         'Boolean equality aliases cannot masquerade as integer term leaves.'),
        ('float_in_term', certificate([0.0, 0.0], refl_instructions(0)),
         'Floating-point equality aliases cannot masquerade as integer term leaves.'),
        ('future_name_in_root', certificate([-1, -1], refl_instructions(-1)),
         'No negative root parameter is admitted without a declaration.'),
        ('future_name_as_used_witness', certificate([[1, 1], true, true], [[-1], *refl_instructions(-1)]),
         'A used existential witness cannot mention an unallocated negative label.'),
        ('capture_through_used_image', certificate([[[3, 1], true, true], true, true],
                                                  [[1], [0], *refl_instructions(0)]),
         'The open positive image 1 would be captured by the nested existential if image validation were omitted.'),
        ('dead_update_still_checked', certificate([[0, 0, True], 0], [[]]),
         'A malformed recursion update is rejected even at counter zero.'),
        ('invalid_term_arity', certificate([[0, 0], 0], [[]]),
         'A binary list is not a term constructor.'),
        ('false_equation_without_axiom', certificate([0, [0]], [[]]),
         'The empty instruction does not prove an arbitrary equality.'),
    ]
    for name, data, reason in cases:
        if mode == 'declared':
            data = data + [[]]
        yield name, data, reason
    if mode == 'declared':
        for name, header in [('null_header', None), ('boolean_header', False), ('integer_header', 1), ('float_header', 1.0)]:
            yield name, certificate([0, 0], refl_instructions(0)) + [header], 'The declaration header must have a finite JSON container/string length.'


def main():
    manifest = json.loads((ROOT / 'validation/source_cases/manifest.json').read_text())
    t.require(sha(t.DEFAULT_SOURCE) == manifest['source_checker_sha256'], 'Pinned source checker changed')
    source_cases = []
    for case in manifest['tests']:
        path = ROOT / case['path']
        t.require(sha(path) == case['sha256'], 'Source fixture changed')
        data = json.loads(path.read_text())
        source_cases.append((case, source_tree(data)))
    records = []
    rejection_records = []
    controls = []
    modes = []
    for mode in ('closed', 'declared'):
        checker = HERE / ('checker_' + mode + '.py')
        module = t.load(checker, 'counter_variant_' + mode)
        metrics = measure.metrics(checker)
        examples = HERE / 'examples' / mode
        examples.mkdir(parents=True, exist_ok=True)
        unchanged_closed = 0
        for case, tree in source_cases:
            emitter = CounterEmitter(module, tree, mode)
            emitter.emit(tree, [], {})
            goal = emitter.rename(tree.goal, {})
            expected = ground(tree.goal) if mode == 'closed' else tree.goal
            t.require(decoded(goal) == expected, 'Decoded alternative theorem changed unexpectedly')
            if not t.negative_parameters(tree.goal):
                unchanged_closed += 1
            output = list(reversed(emitter.cells)) + [goal]
            if mode == 'declared':
                output.append([0] * emitter.bound)
            module_result = run_module(module, output, mode)
            t.require(module_result['accepted'] and module_result['remaining'] == 0,
                      'Alternative module rejects or leaves emitted instructions')
            path = examples / (case['name'] + '.json')
            path.write_text(json.dumps(output, indent=2) + '\n')
            result = cli(checker, path)
            t.require(result['accepted'], 'Alternative CLI rejects ' + case['name'])
            records.append({'variant': mode, 'name': case['name'],
                            'source': case['path'], 'source_sha256': case['sha256'],
                            'source_provenance': case['provenance'],
                            'certificate': str(path.relative_to(ROOT)), 'sha256': sha(path),
                            'interpretation': 'closed_ground_instance' if mode == 'closed' else 'same_decoded_theorem',
                            'source_already_closed': not bool(t.negative_parameters(tree.goal)),
                            'instruction_cells': len(emitter.cells), 'declared_bound': emitter.bound,
                            'pruned_source_instruction_cells': emitter.pruned_source_cells,
                            'allocations': emitter.allocations, 'module': module_result, 'cli': result})
        rejected = 0
        rejection_dir = HERE / 'rejections' / mode
        rejection_dir.mkdir(parents=True, exist_ok=True)
        for name, data, reason in focused_rejections(mode):
            path = rejection_dir / (name + '.json')
            path.write_text(json.dumps(data, indent=2) + '\n')
            result = cli(checker, path)
            t.require(not result['accepted'] and result['stdout'] == 'REJECT',
                      'Alternative unexpectedly accepts rejection case: ' + name)
            rejected += 1
            rejection_records.append({'variant': mode, 'name': name, 'reason': reason,
                                      'certificate': str(path.relative_to(ROOT)),
                                      'sha256': sha(path), 'cli': result})
        if mode == 'declared':
            # The contents of a sized header are inert, and cannot add hypotheses.
            for name, header in [('one_parameter_array', [None]), ('one_parameter_string', 'x'),
                                 ('one_parameter_object', {'inert': False})]:
                data = certificate([-1, -1], refl_instructions(-1)) + [header]
                path = examples / (name + '.json')
                path.write_text(json.dumps(data, indent=2) + '\n')
                result = cli(checker, path)
                t.require(result['accepted'], 'Sized declaration header rejected: ' + name)
                controls.append({'name': name, 'variant': mode,
                                 'certificate': str(path.relative_to(ROOT)), 'sha256': sha(path), 'cli': result})
        modes.append({'variant': mode, 'checker': str(checker.relative_to(ROOT)), 'metrics': metrics,
                      'accepted_source_transports': len(source_cases), 'source_already_closed': unchanged_closed,
                      'source_open_goals_grounded': len(source_cases)-unchanged_closed if mode == 'closed' else 0,
                      'focused_rejections': rejected})
    result = {
        'description': 'Optional implementation synthesis with explicit counters; no new logical or arithmetic axioms.',
        'primary_checker': 'checker.py', 'primary_metrics': measure.metrics(ROOT / 'checker.py'),
        'baseline_snapshot': manifest['commit'],
        'measurement_source': 'comparison/source_measure.py',
        'measurement_source_sha256': sha(ROOT / 'comparison/source_measure.py'),
        'provenance': [
            'Paired bound-variable coordinates: paired_coordinates draft.',
            'Instruction-free assumptions: alternation draft.',
            'Flat exact grammar table: parameter_context and alternation drafts.',
            'Direct equality/closure transport: declared_bound draft.',
            'Fused validation/hypothesis check and positional recursion-depth argument: this report\'s implementation synthesis.',
            'The optional variants retain a conventional mutable eigenvariable counter; the main checker derives names from certificate consumption.',
        ],
        'scope': 'Finite tests and complete-program source measurements. Closed-variant transports of open source goals are explicitly ground instances, not the original open judgments.',
        'variants': modes, 'accepted_source_transports': len(records),
        'focused_rejections': len(rejection_records), 'header_controls_accepted': len(controls),
        'validation_program': 'alternatives/validate.py', 'validation_program_sha256': sha(Path(__file__)),
        'records': records, 'rejections': rejection_records, 'header_controls': controls,
    }
    (ROOT / 'results/alternatives.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('records', 'rejections', 'header_controls')}, indent=2))


if __name__ == '__main__':
    main()
