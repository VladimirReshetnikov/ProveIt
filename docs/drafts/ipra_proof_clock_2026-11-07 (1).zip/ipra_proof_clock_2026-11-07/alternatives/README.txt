OPTIONAL CONVENTIONAL-COUNTER IMPLEMENTATIONS
===========================================

These two complete checkers implement the same retained-base iPRA calculus
as the main report. They combine previously supplied implementation ideas
and the report's fused validation/hypothesis check. They are implementation
syntheses, not a new logical or arithmetic axiomatization. They retain an
explicit mutable eigenvariable counter. The main checker instead derives
its local names from consumption of the certificate.

Measured tradeoff
-----------------

All values use the unchanged comparison/source_measure.py and include each
complete program, JSON input and CLI. Whitespace and module docstrings are
normalized exactly as in the pinned drafts.

                              Tokens    AST nodes    Normalized bytes
Main proof-clock checker         438          449                1246
Optional closed checker          432          440                1253
Optional declared checker        438          447                1272

For the separately reported proof cores:

                              Tokens    AST nodes    Normalized bytes
Main proof-clock core            379          386                1001
Optional closed core             373          377                1003
Optional declared core           370          373                 996

The closed alternative uses fewer tokens and AST nodes than the main
checker, but more normalized bytes. The declared alternative trades two
fewer complete-program AST nodes for more normalized bytes. Core measures
exclude the CLI and its declaration-header processing, so the complete
program is the principal comparison boundary. No one program here is
smallest on every measure. All three complete programs lie below each
coordinatewise minimum of the pinned current draft corpus.

Requirements and commands
-------------------------

Python 3.10 or later is required for structural pattern matching. Only the
Python standard library is used. These commands work from the package root:

  python3 alternatives/checker_closed.py CERTIFICATE.json
  python3 alternatives/checker_declared.py CERTIFICATE.json
  python3 alternatives/validate.py

The checkers print ACCEPT and exit successfully on acceptance. They print
REJECT and exit with status 1 otherwise. The public retained hypothesis
context is always empty.

Shared syntax
-------------

The syntax and inference rules are those in report.pdf. Both alternatives
use paired bound-variable coordinates: positive integers 2*j-1 and 2*j
are two codes for bound variable index j. The supplied compiler emits the
odd code 2*j-1. Integer 0 is the numerical constant zero. Negative integer
labels are rigid numerical parameters whose admission is described below.
Top-level positive indices are rejected unless opened from an appropriate
binding position. Booleans and floating-point numbers are not term leaves.

Terms are:

  0 or a well-scoped variable
  [t]                 successor
  [n, a, h]           initialized primitive recursion

The update h binds its previous value and previous counter. Formulas are:

  [s, t]              numerical equality
  [A]                 retained-base closure Q
  [A, B, C]           existential E with matrix A

The last two existential fields are syntactic padding. They must be valid
formula syntax; their semantic contents are ignored. The canonical padding
is [0,0] in both fields. All three fields are parsed under the existential
binder. Used substitution images are validated as locally closed terms;
images cannot silently acquire a binding from their insertion position.

The instruction forms, read in execution order, are:

  []       Closure introduction, or one of the two recursion equations,
           as determined by the goal's outer syntax.
  [t]      Existential introduction with numerical witness t.
  [M, t]   Elimination. The next subproof establishes major premise M.
           If M is a closure, t is its numerical instance; if M is an
           equation, t is a formula motive; if M is existential, t is
           ignored and a fresh witness scope is opened.

A goal already in the retained context consumes no instruction. Every
other accepted node consumes one instruction. The recursive proof order
and the six native inference patterns are exactly those in the report.

Closed-sentence interface: checker_closed.py
-------------------------------------------

The certificate is one JSON array. Its last element is the goal, and the
preceding elements are instructions stored in reverse execution order:

  [last_instruction, ..., first_instruction, goal]

The counter starts at k=0. A negative rigid label a is admitted only when
k <= a. Thus no negative parameter is permitted in the public root goal.
The root may contain properly bound positive indices inside its binders.
Each closure introduction or existential elimination allocates a fresh
local name by decrementing k. The new name is the resulting value of k.

The interface checks closed sentences. It is not an interface for literal
open root judgments with arbitrary fixed negative labels. The calculus
still has its full first-order language; arbitrary closed theorems can be
expressed and checked.

For example, the following one-instruction certificate checks R(0,0;0)=0:

  [[], [[0,0,0],0]]

Declared-parameter interface: checker_declared.py
------------------------------------------------

The final element is a declaration header; the preceding element is the
goal. Earlier elements are reverse-order proof instructions:

  [last_instruction, ..., first_instruction, goal, header]

Let B be len(header) after JSON decoding. The counter starts at k=-B.
The root may therefore use the B external labels -1, -2, ..., -B, in
addition to properly bound positive indices. For example, source external
variable x_i can be represented by -(i+1), independently of proof length.
Each local allocation subsequently decrements k, giving a distinct new
label below every previously admitted label.

The canonical header is an array of B zeros. Its elements are inert: it
supplies a numerical bound, never hypotheses. The implementation also
accepts a JSON string or JSON object as a header and uses its Python length
(number of Unicode code points or number of decoded keys respectively).
Headers that are numbers, booleans, or null have no length and are rejected.
A zero-length header gives the same initial parameter admission as the
closed interface.

For example, a complete reflexivity certificate for the declared external
parameter -1 is:

  [[], [], [[[0,-1,0],-1],[1,-1]], [-1,-1], [0]]

As in the pinned checkers, unused initial array cells are permitted. The
supplied emitted proof examples consume all their instruction cells.

Reproducible evidence and its limits
-----------------------------------

Running alternatives/validate.py reads the 53 source certificates already
recorded in validation/source_cases/manifest.json. It checks their hashes,
replays their accepted derivations using the pinned alternation checker,
and constructs certificates for both alternatives. It verifies emitted
proofs with the actual modules and invokes the actual public JSON CLIs.

  Declared checker: 53/53 accepted, preserving the decoded source theorem.
  Closed checker:   53/53 accepted closed ground instances.

Among the 53 source goals, 17 are already closed and 36 have external free
parameters. The closed tests preserve the 17 closed goals and replace
external free parameters by zero in the other 36. This specialization is
explicit; it is not presented as preservation of the original open
judgments. Local eigenparameters are renamed at their allocations, and
newly available hypothesis goals are pruned after specialization.

Ten focused invalid certificates are rejected by the closed checker.
Fourteen are rejected by the declared checker, including four unsized
header cases. They exercise malformed roots, Boolean/float term aliases,
future negative labels, an open substitution image that would be captured,
a malformed unused recursion update, a forbidden term arity, and an
unsupported equation. Three positive declaration-header controls check
that the length, rather than the header's contents, determines admission.
These are concrete replay and rejection checks, not a fuzzing campaign or
a mechanized proof of the metatheory.

Files produced by reproduction:

  alternatives/examples/closed/       emitted closed ground instances
  alternatives/examples/declared/     emitted declared-parameter proofs
  alternatives/rejections/            the focused invalid inputs
  results/alternatives.json           measurements, hashes, outcomes,
                                      source provenance, and scope details

The alternatives do not participate in the main checker's acceptance.
Neither alternatives/validate.py nor translator.py is imported by any of
the three measured acceptance programs. The inherited source license is
preserved in LICENSE_SOURCE.txt; the provenance of the synthesis is also
recorded in results/alternatives.json.
