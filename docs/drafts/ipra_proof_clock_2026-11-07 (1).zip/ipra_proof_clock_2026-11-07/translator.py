"""Untrusted two-pass transport from the pinned alternation checker.

The first pass records an accepted derivation and counts its non-hypothesis
nodes. The second pass renames parameters and assigns local eigenvariables
using the exact remaining-instruction count. The acceptance kernel does not
import this module. Positive ordinary de Bruijn indices j become 2*j-1.

Usage:
  python3 translator.py SOURCE.json OUTPUT.json [--source-checker PATH]
      [--target-checker PATH] [--trace TRACE.json]

For N output instruction cells, every unscoped source label v<0 is encoded
by v-N. Thus a source external variable x_i represented by -(i+1) is encoded
by -(N+1+i). This preserves the decoded public theorem exactly. Scoped
eigenvariable renamings override the external-label map.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import dataclass, field
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE = ROOT / 'comparison/sources/ipra_alternation_2026-11-07__checker.py'
DEFAULT_TARGET = ROOT / 'checker.py'
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def negative_parameters(value):
    if type(value) is int:
        return {value} if value < 0 else set()
    if type(value) is list:
        return set().union(*(negative_parameters(x) for x in value))
    if type(value) is dict:
        return set().union(*(negative_parameters(x) for x in value.values()))
    return set()


@dataclass
class Node:
    goal: object
    cell: object = None
    kind: str = 'hyp'
    children: list = field(default_factory=list)
    eigen: int | None = None

    def size(self):
        return int(self.kind != 'hyp') + sum(child.size() for child in self.children)


class Recorder:
    """An explicit replay, cross-checked against the actual source kernel."""
    def __init__(self, module, certificate):
        self.module = module
        self.stream = deepcopy(certificate)
        self.goal = self.stream.pop()
        self.calls = 0
        module.k = 0

    def check(self, goal, context):
        self.calls += 1
        module = self.module
        module.inst(goal)
        node = Node(deepcopy(goal))
        if goal in context:
            return node
        cell = self.stream.pop()
        node.cell = deepcopy(cell)

        def scoped(body, assumptions, kind):
            node.kind = kind
            module.k -= 1
            node.eigen = module.k
            child_goal = module.inst(body, [[node.eigen]])
            child_context = context + [module.inst(c, [node.eigen]) for c in assumptions]
            node.children.append(self.check(child_goal, child_context))
            return node

        if type(cell) is list and len(cell) == 2:
            major, annotation = cell
            node.children.append(self.check(major, context))
            if len(major) == 3:
                return scoped(goal, major[:1], 'ex_elim')
            if len(major) == 1:
                node.kind = 'q_elim'
                body, images = major[0], [0, annotation]
            else:
                node.kind = 'eq_elim'
                body, images = annotation, major
            premise, result = (module.inst(body, [value]) for value in images)
            require(result == goal, 'Source elimination result mismatch')
            node.children.append(self.check(premise, context))
            return node

        if cell == [] and len(goal) == 1:
            body = goal[0]
            assumptions = [body, module.inst(body, [0])][len(body) % 2:]
            return scoped(body, assumptions, 'q_intro')

        if type(cell) is list and len(cell) == 1 and len(goal) == 3:
            node.kind = 'ex_intro'
            node.children.append(self.check(module.inst(goal[0], [cell[0]]), context))
            return node

        if (cell == [] and len(goal) == 2 and type(goal[0]) is list
                and len(goal[0]) == 3):
            node.kind = 'compute'
            n, initial, update = goal[0]
            if n:
                n, = n
                initial = module.inst(update, ([n, initial, update], n), d=1)
            require(initial == goal[1], 'Source computation is not an axiom')
            return node
        raise ValueError('Source replay has no inference for this node')


class Emitter:
    def __init__(self, module, tree, certificate):
        self.module = module
        self.total = tree.size()
        self.cells = []
        self.root_parameters = sorted(negative_parameters(tree.goal), reverse=True)
        self.parameters = sorted(negative_parameters(certificate), reverse=True)
        self.external = {name: name - self.total for name in self.parameters}
        self.allocations = []
        self.visits = []
        self.sync()

    def sync(self):
        # Only the length is read by inst; this list is not an accepted proof.
        self.module.p = [None] * (self.total - len(self.cells))

    def rename(self, value, scope):
        if type(value) is int:
            if value < 0:
                return scope[value] if value in scope else self.external[value]
            return 2 * value - 1 if value > 0 else 0
        if type(value) is list:
            return [self.rename(x, scope) for x in value]
        if type(value) is dict:
            return {key: self.rename(x, scope) for key, x in value.items()}
        return value

    def emit(self, node, context, scope, expected=None):
        module = self.module
        goal = self.rename(node.goal, scope)
        require(expected is None or goal == expected, 'Renamed premise mismatch')
        module.inst(goal)
        require((goal in context) == (node.kind == 'hyp'),
                'The injective renaming changed hypothesis pruning')
        self.visits.append({'kind': node.kind, 'remaining': len(module.p),
                            'scope': [[key, value] for key, value in scope.items()]})
        if node.kind == 'hyp':
            return
        cell = self.rename(node.cell, scope)
        self.cells.append(cell)
        self.sync()

        def scoped(body, assumptions, child):
            eigen = ~len(module.p)
            new_scope = dict(scope)
            require(node.eigen is not None, 'Missing source eigenvariable')
            new_scope[node.eigen] = eigen
            active = list(scope.values())
            require(eigen not in active, 'Collision between simultaneously active eigenvariables')
            fixed_names = negative_parameters([goal, context])
            require(eigen not in fixed_names, 'Eigenvariable occurs in retained data')
            self.allocations.append({'rule': node.kind, 'source': node.eigen,
                                     'target': eigen, 'remaining': len(module.p),
                                     'active_parent_names': active})
            child_goal = module.inst(body, [[eigen]])
            child_context = context + [module.inst(c, [eigen]) for c in assumptions]
            self.emit(child, child_context, new_scope, child_goal)

        if node.kind == 'q_intro':
            body = goal[0]
            assumptions = [body, module.inst(body, [0])][len(body) % 2:]
            scoped(body, assumptions, node.children[0])
        elif node.kind == 'ex_intro':
            self.emit(node.children[0], context, scope, module.inst(goal[0], [cell[0]]))
        elif node.kind in ('ex_elim', 'q_elim', 'eq_elim'):
            major, annotation = cell
            self.emit(node.children[0], context, scope, major)
            if node.kind == 'ex_elim':
                require(~len(module.p) not in negative_parameters(major),
                        'Existential eigenvariable occurs in its major premise')
                scoped(goal, major[:1], node.children[1])
            else:
                if node.kind == 'q_elim':
                    body, images = major[0], [0, annotation]
                else:
                    body, images = annotation, major
                premise, result = (module.inst(body, [value]) for value in images)
                require(result == goal, 'Target elimination result mismatch')
                self.emit(node.children[1], context, scope, premise)
        elif node.kind == 'compute':
            n, initial, update = goal[0]
            if n:
                n, = n
                initial = module.inst(update, ([n, initial, update], n), d=1)
            require(goal[1] == initial, 'Target computation is not an axiom')
        else:
            raise ValueError('Unrecognized recorded inference')


def decode_root(value, instruction_count):
    """Read paired bound indices and the proof-length-relative external codec."""
    if type(value) is int:
        if value < 0:
            return value + instruction_count
        return (value + 1) // 2 if value > 0 else 0
    if type(value) is list:
        return [decode_root(x, instruction_count) for x in value]
    return value


def source_run(module, certificate):
    stream = deepcopy(certificate)
    module.k = 0
    module.take = stream.pop
    accepted = bool(module.check(stream.pop(), []))
    return {'accepted': accepted, 'remaining': len(stream), 'final_k': module.k}


def target_run(module, certificate):
    module.p = deepcopy(certificate)
    accepted = bool(module.check(module.p.pop(), []))
    return {'accepted': accepted, 'remaining': len(module.p)}


def transport(certificate, source_path=DEFAULT_SOURCE, target_path=DEFAULT_TARGET):
    require(type(certificate) is list and certificate, 'Nonempty JSON array required')
    source = load(source_path, 'chrono_source')
    target = load(target_path, 'chrono_target')
    actual_source = source_run(source, certificate)
    require(actual_source['accepted'], 'Source kernel rejects')
    recorder = Recorder(source, certificate)
    tree = recorder.check(recorder.goal, [])
    require(len(recorder.stream) == actual_source['remaining'] and
            source.k == actual_source['final_k'], 'Replay differs from source kernel')
    require(tree.size() == len(certificate) - 1 - actual_source['remaining'],
            'Non-hypothesis node count differs from consumed instructions')
    emitter = Emitter(target, tree, certificate)
    emitter.emit(tree, [], {})
    require(len(emitter.cells) == emitter.total, 'Emission count mismatch')
    output = list(reversed(emitter.cells)) + [emitter.rename(tree.goal, {})]
    require(decode_root(output[-1], emitter.total) == tree.goal,
            'Decoded public theorem was changed')
    actual_target = target_run(target, output)
    require(actual_target['accepted'] and actual_target['remaining'] == 0,
            'Target kernel rejects transport or leaves instructions unused')
    summary = {
        'source_run': actual_source, 'target_run': actual_target,
        'source_checker_sha256': hashlib.sha256(Path(source_path).read_bytes()).hexdigest(),
        'target_checker_sha256': hashlib.sha256(Path(target_path).read_bytes()).hexdigest(),
        'source_goal': deepcopy(tree.goal), 'target_goal': deepcopy(output[-1]),
        'initial_instruction_count': emitter.total,
        'root_parameter_map': [[name, emitter.external[name]] for name in emitter.root_parameters],
        'all_external_parameter_map': [[name, emitter.external[name]] for name in emitter.parameters],
        'allocations': emitter.allocations, 'visits': emitter.visits,
        'decoded_goal_equal': True,
        'external_codec': 'Source negative v is encoded as v-N for N instruction cells; source x_i=-(i+1) becomes -(N+1+i).',
        'source_calls': recorder.calls,
        'source_unused_prefix_cells': actual_source['remaining'],
    }
    return output, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--source-checker', type=Path, default=DEFAULT_SOURCE)
    parser.add_argument('--target-checker', type=Path, default=DEFAULT_TARGET)
    parser.add_argument('--trace', type=Path)
    args = parser.parse_args()
    certificate = json.loads(args.source.read_text())
    output, summary = transport(certificate, args.source_checker, args.target_checker)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + '\n')
    # Exercise the actual CLI, including JSON parsing and empty retained context.
    result = subprocess.run([sys.executable, str(args.target_checker), str(args.output)],
                            capture_output=True, text=True)
    require(result.returncode == 0 and result.stdout.strip() == 'ACCEPT',
            'Public target CLI rejects emitted certificate')
    summary['cli'] = {'exit_code': result.returncode, 'stdout': result.stdout.strip(),
                      'stderr': result.stderr.strip()}
    if args.trace:
        args.trace.parent.mkdir(parents=True, exist_ok=True)
        args.trace.write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'accepted': True, 'instruction_cells': len(output) - 1,
                      'allocations': len(summary['allocations']),
                      'root_parameters': summary['root_parameter_map']}))


if __name__ == '__main__':
    main()
