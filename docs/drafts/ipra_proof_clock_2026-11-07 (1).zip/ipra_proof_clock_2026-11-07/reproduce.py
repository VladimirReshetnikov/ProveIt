"""Reproduce the measurements, transported examples, and independent checks."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', action='store_true', help='also compile report.tex using pdflatex')
    args = parser.parse_args()
    for script in ('measure.py', 'validation/transport.py', 'validation/independent.py',
                   'alternatives/validate.py'):
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    if args.pdf:
        subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)


if __name__ == '__main__':
    main()
