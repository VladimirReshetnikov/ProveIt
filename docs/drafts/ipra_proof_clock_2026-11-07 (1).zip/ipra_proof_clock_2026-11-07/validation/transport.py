"""Transport all packaged source proofs and invoke the public target CLI.

Run from any directory:
  python3 /path/to/package/validation/transport.py

The source theorem fixtures and their provenance are fixed by
validation/source_cases/manifest.json. Neither this validation program nor
the translator is imported by the measured acceptance kernel.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('proof_clock_translator', ROOT / 'translator.py')
t = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = t
spec.loader.exec_module(t)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    manifest_path = ROOT / 'validation/source_cases/manifest.json'
    manifest = json.loads(manifest_path.read_text())
    t.require(sha(ROOT / manifest['source_checker']) == manifest['source_checker_sha256'],
              'Frozen source checker differs from the pinned fixture manifest')
    examples = ROOT / 'examples'
    traces = ROOT / 'validation/traces'
    examples.mkdir(parents=True, exist_ok=True)
    traces.mkdir(parents=True, exist_ok=True)
    records = []
    for case in manifest['tests']:
        path = ROOT / case['path']
        t.require(sha(path) == case['sha256'], 'Changed source case: ' + case['name'])
        certificate = json.loads(path.read_text())
        emitted, summary = t.transport(certificate)
        destination = examples / (case['name'] + '.json')
        destination.write_text(json.dumps(emitted, indent=2) + '\n')
        run = subprocess.run([sys.executable, str(t.DEFAULT_TARGET), str(destination)],
                             capture_output=True, text=True)
        accepted = run.returncode == 0 and run.stdout.strip() == 'ACCEPT'
        t.require(accepted, 'Public CLI rejected: ' + case['name'])
        t.require(summary['target_run']['remaining'] == 0,
                  'Target did not consume its emitted instructions')
        t.require(summary['decoded_goal_equal'], 'Decoded theorem changed')
        if 'expected_consumed_cells' in case:
            t.require(len(emitted) - 1 == case['expected_consumed_cells'],
                      'Focused certificate did not exercise its intended instructions')
            t.require(len(summary['allocations']) == case['expected_allocations'],
                      'Focused certificate did not exercise its intended eigenvariable scopes')
            t.require(summary['source_unused_prefix_cells'] == case['expected_unused_source_prefix'],
                      'Focused source proof contains unexecuted instructions')
        if case['name'] == 'safe_label_reuse_after_major_scope':
            allocated = summary['allocations']
            t.require(allocated[0]['target'] == allocated[1]['target'],
                      'Safe temporal label reuse was not exercised')
            t.require(not allocated[0]['active_parent_names'] and not allocated[1]['active_parent_names'],
                      'Reused labels unexpectedly share an active ancestor scope')
        if case['name'] == 'outer_fresh_witness_under_two_scopes':
            allocated = summary['allocations']
            t.require(allocated[0]['target'] in allocated[1]['active_parent_names'],
                      'Focused witness does not have two simultaneously active eigenparameters')
        summary['cli'] = {'exit_code': run.returncode, 'stdout': run.stdout.strip(),
                          'stderr': run.stderr.strip()}
        summary['source_file'] = case['path']
        summary['source_sha256'] = case['sha256']
        summary['source_provenance'] = case['provenance']
        trace = traces / (case['name'] + '.json')
        trace.write_text(json.dumps(summary, indent=2) + '\n')
        records.append({
            'name': case['name'], 'input_path': case['path'],
            'input_sha256': case['sha256'], 'source_provenance': case['provenance'],
            'certificate': str(destination.relative_to(ROOT)),
            'certificate_sha256': sha(destination),
            'trace': str(trace.relative_to(ROOT)), 'trace_sha256': sha(trace),
            'instruction_cells': len(emitted) - 1,
            'allocations': len(summary['allocations']), 'accepted': accepted,
            'decoded_goal_equal': summary['decoded_goal_equal'],
            'root_parameter_map': summary['root_parameter_map'],
            'source_unused_prefix_cells': summary['source_unused_prefix_cells'],
        })
    result = {
        'source_theorems': manifest['pinned_archive_cases'],
        'focused_freshness_theorems': manifest['handbuilt_cases'],
        'total': len(records), 'accepted': sum(row['accepted'] for row in records),
        'all_decoded_goals_preserved': all(row['decoded_goal_equal'] for row in records),
        'source_checker': str(t.DEFAULT_SOURCE.relative_to(ROOT)),
        'source_checker_sha256': sha(t.DEFAULT_SOURCE),
        'target_checker': str(t.DEFAULT_TARGET.relative_to(ROOT)),
        'target_checker_sha256': sha(t.DEFAULT_TARGET),
        'translator': 'translator.py', 'translator_sha256': sha(ROOT / 'translator.py'),
        'validation_program': 'validation/transport.py',
        'validation_program_sha256': sha(Path(__file__)),
        'source_manifest': str(manifest_path.relative_to(ROOT)),
        'source_manifest_sha256': sha(manifest_path),
        'external_codec': 'For N instruction cells, an unscoped source v<0 maps to v-N. The decoded public theorem is preserved exactly.',
        'scope': 'Finite executable evidence, not a machine-formalized metatheorem. All output proofs are checked both through the module and the public JSON CLI.',
        'records': records,
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/transport.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))


if __name__ == '__main__':
    main()
