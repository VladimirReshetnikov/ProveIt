"""Independent public-CLI audit of the proof-length freshness candidate.

Hand-built rule certificates and adversarial packets are not imported from
any candidate translator or validation harness. Defect controls demonstrate
that the capture and temporal-boundary tests detect the stated mistakes.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / 'results'
RESULTS.mkdir(exist_ok=True)
SOURCE = ROOT / 'checker.py'
raw = SOURCE.read_bytes()
SOURCE_SHA = hashlib.sha256(raw).hexdigest()

T = [0, 0]
D = [0, [0]]


def reflexivity(term):
    """R(0,t;0)=t twice, then equality transport with motive z=t."""
    computation = [[0, term, 0], term]
    return [[], [], [computation, [1, term]]]


def symmetry(s, t, proof):
    return reflexivity(s) + proof + [[[s, t], [1, s]]]


def transitivity(s, t, u, first, second):
    return first + second + [[[t, u], [s, 1]]]


def pred(term):
    # Paired coordinate 3 denotes the recursor's previous counter.
    return [term, 0, 3]


cases = []


def case(name, packet, expected, why):
    cases.append({'name': name, 'packet': packet, 'expected': expected, 'reason': why})


case('primitive_zero', [[], [[0, 0, 0], 0]], True,
     'The zero computation axiom.')
case('primitive_successor', [[], [[[0], 0, 3], 0]], True,
     'One successor unfolding returns the previous counter.')
case('derived_reflexivity_zero', reflexivity(0) + [T], True,
     'Reflexivity is derived by computation and equality transport.')
case('empty_instruction_hypothesis_child', [[], [T]], True,
     'Q introduction supplies its constant equality as a hypothesis; its child consumes zero cells.')
case('compound_q_retains_base', [[], [[T, T, T]]], True,
     'The quantified-matrix Q branch retains its base and supplies no induction hypothesis.')
case('existential_introduction', reflexivity(0) + [[0], [[1, 0], T, T]], True,
     'Existential witness zero with a reflexivity proof.')

# Q_x(x=x): the root scope consumes one cell and leaves three for reflexivity.
outer_name = -4
case('q_reflexivity_uses_clock_name', reflexivity([outer_name]) + [[], [[1, 1]]], True,
     'After the Q command three cells remain, so its eigenparameter is -4.')

# E elimination whose major consumes four commands; one minor command remains.
M = [[1, 0], T, T]
major = reflexivity(0) + [[0]]
case('existential_elimination_consuming_major', [[-2]] + major + [[M, None], M], True,
     'After a four-command major one minor cell remains; -2 is introduced and immediately used as an existential witness.')

# The E major below is an existing hypothesis and consumes ZERO instructions.
# Total six instructions: Q, E elimination, E introduction, and three for reflexivity.
y = -6
B = [[1, 3], T, T]  # Under Q_x, E_z(z=x).
case('existential_elimination_hypothesis_major',
     reflexivity([y]) + [[[y]], [M, None], [], [B]], True,
     'The Q base is M. E elimination checks M by an instruction-free hypothesis leaf before choosing its own fresh name.')

# The last scope inside the major and the later outer scope both allocate -1.
# The first scope has closed before the second opens, so reuse is safe.
reuse_major = [[T], T, T]
case('safe_label_reuse_after_major_scope',
     [[], [0], [reuse_major, None], [T]], True,
     'A Q scope closes at unread length zero; the enclosing E elimination then safely reuses -1 in its distinct local scope.')

case('old_rigid_parameter', [[], [[-2, -2]]], True,
     'One unread instruction reserves -1; the independent parameter -2 is permitted.')
case('future_parameter_in_root', [[], [[-1, -1]]], False,
     'A name reserved for the unread proof cannot occur in the root, even in a true equation.')
case('unused_prefix_changes_clock_boundary', [None, [], [[-2, -2]]], False,
     'An unread prefix contributes to the initial clock; it is not inert for name validation.')
case('shifted_parameter_with_unused_prefix', [None, [], [[-3, -3]]], True,
     'Shifting the free parameter below the larger clock restores a valid certificate.')
case('unused_prefix_adds_no_hypotheses', [D, None, D], False,
     'A formula stored as an unused proof cell is not a logical assumption.')
case('irrelevant_prefix_with_closed_computation', [D, [], [[0, 0, 0], 0]], True,
     'An unused prefix cannot affect a name-free one-step computation.')

case('false_equation', [[], D], False, '0=S0 is not a computation axiom.')
case('wrong_successor_result', [[], [[[0], 0, 3], [0]]], False,
     'The previous counter is zero, not S0.')
case('one_unfolding_is_not_normalization', [[], [[[0], 0, [1]], [0]]], False,
     'One unfolding gives S(R(0,0;S(u))), not S0; further equality reasoning is required.')
case('missing_proof', [T], False, 'An empty public context cannot supply a hypothesis.')
case('malformed_instruction', [None, T], False, 'No rule matches this instruction.')
case('malformed_three_field_instruction', [[0, 0, 0], T], False,
     'Unknown instruction arity cannot initialize the scope continuation.')
case('partial_computation_pattern_fallthrough', [[0], [[0, 0, 0], 0]], False,
     'A computation-shaped goal with the wrong instruction must not acquire a scope continuation from partial pattern bindings.')
failed_major = [[0, 0, 0], [0]]
case('failed_major_pattern_fallthrough', [[], [failed_major, None], T], False,
     'A major premise returning False cannot initialize the final scope continuation.')
case('boolean_zero_goal_alias', [[], [False, False]], False,
     'Exact integer typing prevents Python Boolean equality aliases.')
case('float_zero_goal_alias', [[], [0.0, 0.0]], False,
     'Floating leaves are not numerical syntax.')
case('string_term', [[], ['0', 0]], False, 'Strings are not term leaves.')
case('formula_zero_arity', [[], []], False, 'Empty lists are not formulas.')
case('formula_four_arity', [[], [T, T, T, T]], False, 'The formula arity table is exact.')
case('term_two_arity', [[], [[0, 0], 0]], False, 'An equality-shaped pair cannot be used as a term.')
case('unbound_root_coordinate', [[], [1, 1]], False,
     'Positive paired coordinates require actual surrounding binders.')
case('invalid_recursor_initializer_scope', [[], [[0, 1, 1], 1]], False,
     'Recursor update binders do not bind its initializer.')
case('invalid_recursor_counter_scope', [[], [[1, 0, 1], 0]], False,
     'Recursor update binders do not bind its counter.')
case('valid_dead_accumulator_update', [[], [[0, 0, 1], 0]], True,
     'The accumulator coordinate is bound even when the update is not used.')
case('valid_dead_predecessor_update', [[], [[0, 0, 3], 0]], True,
     'The previous-counter coordinate is bound even when the update is not used.')
case('invalid_dead_update_coordinate', [[], [[0, 0, 5], 0]], False,
     'Dead update syntax is still checked, including its binder limit.')
case('valid_nested_update_coordinate', [[], [[0, 0, [0, 0, 5]], 0]], True,
     'A nested update can reference an outer recursor binder.')
case('invalid_nested_update_coordinate', [[], [[0, 0, [0, 0, 9]], 0]], False,
     'Five coordinates do not fit beneath four recursor binders.')
case('invalid_existential_annotation', reflexivity(0) + [[0], [T, [], T]], False,
     'Inert existential formula annotations are still validated.')
case('used_boolean_witness', reflexivity(0) + [[False], [[1, 0], T, T]], False,
     'A used witness is independently checked as a numerical term.')
case('used_escaping_witness', reflexivity(0) + [[1], [[1, 0], T, T]], False,
     'A used positive-coordinate witness is not locally closed.')
case('unused_malformed_witness', reflexivity(0) + [[{'ignored': True}], [T, T, T]], True,
     'Demand validation ignores data that is never substituted; zero supplies a valid witness for the extracted derivation.')
case('unused_escaping_witness', reflexivity(0) + [[99], [T, T, T]], True,
     'An unused substitution image is inert, even if it would not be a legal term.')

# Escaping an existential eigenparameter into its parent end-goal.
case('eigenparameter_escape_into_root', major + [[M, None], [-1, 0]], False,
     'The final E eigenparameter would be -1, which root validation excludes.')

# If E freshness is computed BEFORE proving the major, a free parameter in the
# major can coincide with the later eigenparameter. This produces a false CLOSED
# theorem: there exists a fixed point of successor.
c = -6
fixed_point = [[1, [1]], T, T]
major_with_c = [[1, [c]], T, T]
major_with_c_proof = reflexivity([c]) + [[[c]]]
case('allocation_before_major_false_fixed_point',
     [[c]] + major_with_c_proof + [[major_with_c, None], fixed_point], False,
     'The major proves existence of S(c). Capturing its free c as the eigenparameter would falsely yield exists x (x=Sx).')

# If the goal is checked only AFTER popping its command, the new eigenparameter
# can already occur as a fixed parameter in the Q matrix. The matrix is the usual
# numerical gate C(z,0,c)=C(z,0,p(z)); its Q is equivalent to forall y (c=y).
c = -10
sc = [c]
pc = pred(sc)
left = [sc, 0, c]
right = [sc, 0, pc]
right_equals_c = transitivity(right, pc, c, [[]], [[]])
c_equals_right = symmetry(right, c, right_equals_c)
left_equals_right = transitivity(left, c, right, [[]], c_equals_right)
assert len(left_equals_right) == 9
bad_q_matrix = [[1, 0, c], [1, 0, [5, 0, 3]]]
case('goal_validated_after_pop_capture', left_equals_right + [[], [bad_q_matrix]], False,
     'The literal parameter -10 must be rejected before the ten-command proof starts; otherwise it is captured as the Q eigenparameter.')

# The formula below is E_x Q_z G_z(x=p(z)), equivalent to exists x forall y x=y.
# A malformed witness p(5), if inserted without independent depth-zero validation,
# is captured below Q and the selector recursor and makes both gated terms equal.
c = -4
step_term = [[c], 0, [[c], 0, 3]]
bad_witness = pred(5)
quantified_matrix = [[[1, 0, 7], [1, 0, [5, 0, 3]]]]
no_common_number = [quantified_matrix, T, T]
case('used_image_capture_false_common_number',
     reflexivity(step_term) + [[], [bad_witness], no_common_number], False,
     'Locally closed image validation blocks a proof of exists x forall y x=y obtained by capture under logical and recursor binders.')

# Existential annotations are syntactically checked but must never become assumptions.
annotated_major = [T, D, D]
case('existential_annotations_are_not_hypotheses',
     reflexivity(0) + [[0], [annotated_major, None], D], False,
     'A true existential with false inert annotations cannot supply 0=S0 as a hypothesis.')

for label, raw_text in [
    ('malformed_json', '[['), ('object_input', '{}'), ('null_input', 'null'),
    ('numeric_input', '0'), ('empty_input', '[]')
]:
    cases.append({'name': label, 'raw_text': raw_text, 'expected': False,
                  'reason': 'The public boundary rejects malformed or non-proof JSON.'})

CASE_DIR = ROOT / 'validation/independent_cases'
CASE_DIR.mkdir(exist_ok=True)
for row in cases:
    path = CASE_DIR / (row['name'] + '.json')
    text = row.get('raw_text', json.dumps(row.get('packet'), separators=(',', ':')))
    path.write_text(text + '\n')
    row['local_file'] = str(path.relative_to(ROOT))


def cli(program, row, optimized=False):
    args = [sys.executable] + (['-O'] if optimized else []) + [str(program), str(ROOT / row['local_file'])]
    proc = subprocess.run(args, capture_output=True, text=True, timeout=5)
    verdict = proc.returncode == 0 and proc.stdout.strip() == 'ACCEPT' and proc.stderr == ''
    good_rejection = proc.returncode == 1 and proc.stdout.strip() == 'REJECT' and proc.stderr == ''
    return {'accepted': verdict, 'clean_boundary': verdict or good_rejection,
            'returncode': proc.returncode, 'stdout': proc.stdout.strip(), 'stderr': proc.stderr}

runs = []
for row in cases:
    for optimized in (False, True):
        got = cli(SOURCE, row, optimized)
        runs.append({'name': row['name'], 'optimized': optimized, 'expected': row['expected'],
                     **got, 'passed': got['clean_boundary'] and got['accepted'] == row['expected']})

source = raw.decode()
mutations = {
    'drop_clock_guard': (
        source.replace(' and (not -len(p) <= a < 0)', ''),
        'eigenparameter_escape_into_root'),
    'allocate_before_major': (
        source.replace('    match (a, p.pop()):',
                       '    instruction = p.pop()\n    chosen = [~len(p)]\n    match (a, instruction):')
              .replace('    k = [~len(p)]', '    k = chosen'),
        'allocation_before_major_false_fixed_point'),
    'validate_goal_after_pop': (
        source.replace('    if inst(a) in g:\n        return True\n    match (a, p.pop()):',
                       '    if a in g:\n        return inst(a) in g\n    instruction = p.pop()\n    inst(a)\n    match (a, instruction):'),
        'goal_validated_after_pop_capture'),
    'drop_used_image_validation': (
        source.replace('inst(env[a - d >> 1], d=1)', 'env[a - d >> 1]'),
        'used_image_capture_false_common_number'),
    'assume_existential_annotations': (
        source.replace('h = m[:1]', 'h = m'),
        'existential_annotations_are_not_hypotheses'),
}
controls = []
by_name = {row['name']: row for row in cases}
with tempfile.TemporaryDirectory(prefix='ipra-defect-controls-') as temporary:
    MUTANTS = Path(temporary)
    for name, (changed, challenge) in mutations.items():
        assert changed != source
        path = MUTANTS / (name + '.py')
        path.write_text(changed)
        got = cli(path, by_name[challenge])
        controls.append({'mutation': name, 'challenge': challenge, **got,
                         'passed': got['clean_boundary'] and got['accepted']})

assert SOURCE.read_bytes() == raw, 'Candidate changed during the independent audit.'
result = {
    'candidate': str(SOURCE.relative_to(ROOT)), 'candidate_sha256': SOURCE_SHA,
    'validation_program': 'validation/independent.py',
    'validation_program_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'case_count': len(cases),
    'positive_cases': sum(row['expected'] for row in cases),
    'negative_cases': sum(not row['expected'] for row in cases),
    'normal_cli_runs': len(cases), 'optimized_cli_runs': len(cases),
    'candidate_failures': [r for r in runs if not r['passed']],
    'defect_controls': controls,
    'defect_control_failures': [r for r in controls if not r['passed']],
    'cases': [{k:v for k,v in row.items() if k not in ('packet','raw_text')} for row in cases],
    'runs': runs,
    'scope': 'Hand audit and independent finite CLI tests; not a mechanized soundness proof.',
}
(RESULTS / 'independent.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('cases','runs')}, indent=2))
if result['candidate_failures'] or result['defect_control_failures']:
    sys.exit(1)
