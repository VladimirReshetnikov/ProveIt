import Std

/-!
# The repaired descent kernel

This file checks the central argument on an arbitrary carrier. The main
theorem assumes one fixed decidable predicate A, one function r with its
displayed recursion equations, and only the no-descent instance for that r.
It assumes no induction principle on the carrier and uses no Nat induction.

The primitive-recursive syntax, the compilation of quantifier-free formulas
to decidable tests, and the complete first-order theory equivalence are not
formalized here. The paper supplies those separate syntactic arguments.

The final Nat theorem is an independent standard-model check. Its explicit
Nat induction is not used in the arbitrary-carrier theorem.

Checked with Lean 4.19.0; no Mathlib dependency.
-/

namespace PRAUnitDescent

universe u

variable {Carrier : Type u}

/-- Replace a good state by the designated possible counterexample. -/
def repair (A : Carrier → Prop) [DecidablePred A]
    (bad state : Carrier) : Carrier :=
  if A state then bad else state

/-- The constant-zero no-descent instance supplies separation. -/
theorem separation_from_constant_zero
    (zero : Carrier) (succ : Carrier → Carrier)
    (no_descent_zero : ¬ ∀ _ : Carrier, zero = succ zero) :
    zero ≠ succ zero := by
  intro equality
  exact no_descent_zero (fun _ => equality)

/-- Predecessor's successor equation already gives successor injectivity. -/
theorem successor_injective
    (succ pred : Carrier → Carrier)
    (pred_succ : ∀ x, pred (succ x) = x) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y equality
  calc
    x = pred (succ x) := (pred_succ x).symm
    _ = pred (succ y) := congrArg pred equality
    _ = y := pred_succ y

/-- Separation and the predecessor equations give successor nonzeroness. -/
theorem successor_nonzero
    (zero : Carrier) (succ pred : Carrier → Carrier)
    (separation : zero ≠ succ zero)
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ x, pred (succ x) = x) :
    ∀ x, succ x ≠ zero := by
  intro x equality
  have x_zero : x = zero := by
    calc
      x = pred (succ x) := (pred_succ x).symm
      _ = pred zero := congrArg pred equality
      _ = zero := pred_zero
  apply separation
  calc
    zero = succ x := equality.symm
    _ = succ zero := congrArg succ x_zero

/--
For a fixed possible counterexample b, one repaired recursion and its own
no-descent instance suffice to prove A b under local base and step hypotheses.

Coverage is used twice: first at an arbitrary recursion index, and then at
an arbitrary bad value. This replaces the circular claim that a recursive
trajectory remains bad by induction. No property of r outside its two
explicit computation equations is assumed.

Notice that predecessor equations and successor nonzeroness are not needed
in this lemma: the coverage equation and the predicate's base/step hypotheses
are enough for this particular logical argument.
-/
theorem repaired_descent_forces_value
    (zero : Carrier) (succ pred : Carrier → Carrier)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (A : Carrier → Prop) [DecidablePred A]
    (initial : A zero)
    (progress : ∀ x, A x → A (succ x))
    (b : Carrier) (r : Carrier → Carrier)
    (r_zero : r zero = b)
    (r_step : ∀ n, r (succ n) = pred (repair A b (r n)))
    (no_descent_r : ¬ ∀ n, r n = succ (r (succ n))) :
    A b := by
  by_cases b_good : A b
  · exact b_good
  · have bad_has_predecessor :
        ∀ x, ¬ A x → x = succ (pred x) := by
      intro x x_bad
      rcases coverage x with x_zero | x_successor
      · have x_good : A x := by
          rw [x_zero]
          exact initial
        exact False.elim (x_bad x_good)
      · exact x_successor

    have predecessor_bad : ∀ x, ¬ A x → ¬ A (pred x) := by
      intro x x_bad predecessor_good
      have x_good : A (succ (pred x)) :=
        progress (pred x) predecessor_good
      rw [← bad_has_predecessor x x_bad] at x_good
      exact x_bad x_good

    have repaired_state_bad : ∀ x, ¬ A (repair A b x) := by
      intro x
      by_cases x_good : A x
      · simpa only [repair, if_pos x_good] using b_good
      · simpa only [repair, if_neg x_good] using x_good

    have successor_value_bad : ∀ n, ¬ A (r (succ n)) := by
      intro n
      rw [r_step n]
      exact predecessor_bad (repair A b (r n)) (repaired_state_bad (r n))

    have every_value_bad : ∀ n, ¬ A (r n) := by
      intro n
      rcases coverage n with n_zero | n_successor
      · simpa only [n_zero, r_zero] using b_good
      · rw [n_successor]
        exact successor_value_bad (pred n)

    have strict_descent : ∀ n, r n = succ (r (succ n)) := by
      intro n
      have repair_inactive : repair A b (r n) = r n := by
        exact if_neg (every_value_bad n)
      calc
        r n = succ (pred (r n)) :=
          bad_has_predecessor (r n) (every_value_bad n)
        _ = succ (r (succ n)) := by rw [r_step n, repair_inactive]

    exact False.elim (no_descent_r strict_descent)

/--
The parameterized metatheorem: the displayed family consists exactly of the
repaired recursions for this fixed predicate, one for each possible seed b.
Its assumptions do not quantify over all predicates or all functions.
-/
theorem induction_from_repaired_family
    (zero : Carrier) (succ pred : Carrier → Carrier)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (A : Carrier → Prop) [DecidablePred A]
    (r : Carrier → Carrier → Carrier)
    (r_zero : ∀ b, r b zero = b)
    (r_step : ∀ b n, r b (succ n) = pred (repair A b (r b n)))
    (no_descent_r : ∀ b, ¬ ∀ n, r b n = succ (r b (succ n))) :
    A zero → (∀ x, A x → A (succ x)) → ∀ b, A b := by
  intro initial progress b
  exact repaired_descent_forces_value zero succ pred coverage A initial
    progress b (r b) (r_zero b) (r_step b) (no_descent_r b)

/-- Standard natural numbers admit no infinite unit-successor descent. -/
theorem nat_no_unit_descent (t : Nat → Nat) :
    ¬ ∀ n, t n = Nat.succ (t (Nat.succ n)) := by
  intro descent
  have conserved_sum : ∀ n, t n + n = t 0 := by
    intro n
    induction n with
    | zero => exact Nat.add_zero (t 0)
    | succ n previous =>
      calc
        t (Nat.succ n) + Nat.succ n =
            Nat.succ (t (Nat.succ n) + n) := Nat.add_succ _ _
        _ = Nat.succ (t (Nat.succ n)) + n := (Nat.succ_add _ _).symm
        _ = t n + n := by rw [← descent n]
        _ = t 0 := previous
  have final_zero : t (t 0) = 0 := by
    apply Nat.add_right_cancel
    calc
      t (t 0) + t 0 = t 0 := conserved_sum (t 0)
      _ = 0 + t 0 := (Nat.zero_add (t 0)).symm
  have contradiction : 0 = Nat.succ (t (Nat.succ (t 0))) :=
    final_zero.symm.trans (descent (t 0))
  exact Nat.noConfusion contradiction

#print axioms separation_from_constant_zero
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms repaired_descent_forces_value
#print axioms induction_from_repaired_family
#print axioms nat_no_unit_descent

end PRAUnitDescent
