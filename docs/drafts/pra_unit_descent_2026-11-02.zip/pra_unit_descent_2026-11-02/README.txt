TWO OCCURRENCES SUFFICE: PRA BY FORBIDDEN UNIT DESCENT
Prepared for Vladimir Reshetnikov, November 2, 2026

MAIN RESULT

The report replaces quantifier-free induction by the two-occurrence schema

  forall parameters, NOT forall n,
      t(n,parameters) = S(t(Sn,parameters)).

In the ordinary full primitive-recursive-description language, keep all
defining equations and add exactly two fixed calibrations:

  forall x, x=0 OR x=S(p(x));
  forall x,y, epsilon(x,x)=0 AND (x=y OR epsilon(x,y)=S0).

Here p and epsilon denote explicitly specified PR descriptions; epsilon is
not a new uninterpreted symbol in the main same-language presentation.
The report gives its description and proves its PRA correctness. The zero
term instance of the descent schema supplies 0 != S0.

This theory and first-order PRA have the SAME DEDUCTIVE CLOSURE in the
same language. Both interpretations and both composites are identities.
The repaired predecessor recursion proves the converse without using
induction on its states. The theorem works separately in matching classical
or intuitionistic logic, with the negative descent formulation retained.

There is also a generated-language presentation with one uniform constructor
for initialized primitive recursion with arbitrary fixed finite tuples of
immutable parameters. On common two-slot input profiles its recurring size
is 19+3m+3i, with 29 fixed active nodes (bit plus coverage). This permits
higher function arities than the current binary-only drafts. That cost is
explicit; the result is NOT claimed in their restricted recursion grammar.

SAME-BINARY-LANGUAGE RESULT

A separate scalar theory preserves the current alternate equality-bit
draft's language, descriptors, logic, and 38-node literal-zero seed. Replace
every other zero-induction clause by constancy. The recurring size changes
from 26+5m+3i to 18+5m+3i, an exact eight-node saving for every nonzero input.
Its complete latch, triangular pairing, compiler, and interpretation proofs
are included. No absolute shortestness theorem is claimed.

CONTENTS

  report.pdf                  Complete compiled research report.
  report.tex                  Main LaTeX source.
  sections/*.tex              All included sections; needed to rebuild.
  build.sh                    Rebuild syntax checks, PDF, and optional Lean.
  verification/UnitDescent.lean
                              Checked central repair theorem and helpers.
  verification/lean_output.txt
  verification/lean_version.txt
  verification/lean_results.json
  verification/LEAN_SCOPE.txt  Exact formalization boundary.
  checks/check_syntax.py       Independent finite-syntax AST checker.
  checks/report.json           Successful results on 6,400 finite inputs.
  checks/examples.txt          Actual representative template counts.
  provenance/baseline_manifest.json
                              All six current draft hashes and pinned URLs.
  provenance/source_links.txt Primary background and snapshot links.
  SHA256SUMS.txt               Hashes of the deliverable files.

VERIFICATION

Lean 4.19.0, Std only, exit status 0.
The central arbitrary-carrier repair theorem, its induction corollary, and
three bootstrap helpers have no axiom dependencies. A separately labeled
Nat soundness theorem reports only Lean's built-in propext. No added axioms,
admitted goals, or induction assumption on the arbitrary carrier are used.

The full syntax grammar, truth-term compiler, first-order derivability and
bi-interpretability theorem are proved in the report, not formalized in Lean.
The Python checks verify syntax accounting, not arithmetic soundness.

REBUILD

Requirements: Python 3.10+ (standard library), a LaTeX distribution providing
pdflatex and the packages in report.tex, and optionally Lean 4.19.0.

  bash build.sh

To select a Lean executable:

  LEAN_BIN=/absolute/path/to/lean bash build.sh

Or run components individually:

  python3 checks/check_syntax.py
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  pdflatex -interaction=nonstopmode -halt-on-error report.tex
  lean verification/UnitDescent.lean

The report source uses \input for the section files: distribute the whole
archive, not report.tex alone. The archive omits downloaded baseline ZIPs,
compiler installations, temporary rendered images, and LaTeX auxiliary files.

PROVENANCE

Repository: VladimirReshetnikov/ProveIt
Snapshot:   d46d2b97cb3c4d4f3a0154fc5884ea42ffcd5966
Directory:  docs/drafts
All six archives present at that commit were retrieved and their bytes
verified against their Git blob hashes. No repository changes were published.

The broad connection between induction and absence of recursive descent
is established background. The report claims a precise weak-base repair
theorem and a reduction relative to the supplied drafts, not historical
priority for infinite descent or an encoding-independent global minimum.
