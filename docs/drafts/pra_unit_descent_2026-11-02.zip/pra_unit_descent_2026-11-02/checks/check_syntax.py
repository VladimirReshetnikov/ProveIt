#!/usr/bin/env python3
"""Independent finite syntax audit for the PRA unit-descent report.

This program checks formula-tree accounting, active substitution, and the
well-founded descriptor syntax on a reproducible finite corpus.  It is NOT a
proof checker for the arithmetic equivalence or bi-interpretation theorems.

Run with Python 3.10 or newer.  No third-party dependencies are required:

    python3 checks/check_syntax.py

The generated report.json and examples.txt are placed beside this script.
Stored recursor descriptors are frozen under active substitution.  The
"expanded" count charges a fresh copy of every stored descriptor at every
recursor occurrence, recursively; it is not a shared-dictionary count.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Node:
    kind: str
    name: str = ""
    children: tuple[Node, ...] = ()
    descriptor: Node | None = None


def var(name: str) -> Node:
    return Node("var", name)


ZERO = Node("const", "0")
BOT = Node("bot")
N, A, X, Y, V, W = (var(s) for s in ("n", "a", "x", "y", "v", "w"))


def fun(name: str, *args: Node) -> Node:
    return Node("fun", name, tuple(args))


def succ(t: Node) -> Node:
    return fun("S", t)


ONE = succ(ZERO)


def rec(body: Node, *args: Node) -> Node:
    if len(args) < 2:
        raise ValueError("An initialized recursor has at least two arguments")
    return Node("fun", "R" + str(len(args)), tuple(args), body)


def binary(kind: str, left: Node, right: Node) -> Node:
    return Node(kind, children=(left, right))


def eq(left: Node, right: Node) -> Node:
    return binary("eq", left, right)


def conj(left: Node, right: Node) -> Node:
    return binary("and", left, right)


def disj(left: Node, right: Node) -> Node:
    return binary("or", left, right)


def implies(left: Node, right: Node) -> Node:
    return binary("implies", left, right)


def forall(name: str, formula: Node) -> Node:
    return Node("forall", name, (formula,))


def all_vars(names: Iterable[str], formula: Node) -> Node:
    for name in reversed(tuple(names)):
        formula = forall(name, formula)
    return formula


def size(node: Node, expanded: bool = False) -> int:
    result = 1 + sum(size(child, expanded) for child in node.children)
    if expanded and node.descriptor is not None:
        result += size(node.descriptor, True)
    return result


def occurrences(node: Node, name: str) -> int:
    """Count only active occurrences; do not enter stored descriptors."""
    return int(node.kind == "var" and node.name == name) + sum(
        occurrences(child, name) for child in node.children
    )


def active_variables(node: Node) -> frozenset[str]:
    result = {node.name} if node.kind == "var" else set()
    for child in node.children:
        result.update(active_variables(child))
    return frozenset(result)


def substitute(term: Node, replacements: dict[str, Node]) -> Node:
    """Simultaneous term substitution, preserving every frozen descriptor."""
    if term.kind == "var":
        return replacements.get(term.name, term)
    if term.kind not in ("const", "fun"):
        raise ValueError("substitute is deliberately restricted to terms")
    return Node(
        term.kind,
        term.name,
        tuple(substitute(c, replacements) for c in term.children),
        term.descriptor,
    )


def at(u: Node, n: Node = N, a: Node = A) -> Node:
    return substitute(u, {"n": n, "a": a})


def body_of(u: Node) -> Node:
    return substitute(u, {"n": V, "a": W})


def root_normalize(t: Node) -> Node:
    """The zero-anchor draft's root-only Q(Sr,s) -> r convention."""
    while (
        t.kind == "fun"
        and t.name == "R2"
        and t.descriptor == W
        and t.children[0].kind == "fun"
        and t.children[0].name == "S"
    ):
        t = t.children[0].children[0]
    return t


def validate_term(t: Node, allowed: frozenset[str]) -> int:
    """Check free slots/arity and return maximum descriptor-dependency rank."""
    if not active_variables(t) <= allowed:
        raise AssertionError("An active variable is outside its allowed slots")
    if t.kind in ("var", "const"):
        assert not t.children and t.descriptor is None
        return 0
    assert t.kind == "fun"
    child_rank = max((validate_term(c, allowed) for c in t.children), default=0)
    if t.descriptor is None:
        assert (t.name, len(t.children)) in (("S", 1), ("eps", 2), ("Delta", 2))
        return child_rank
    assert t.name == "R" + str(len(t.children))
    k = len(t.children) - 2
    slots = frozenset(("v", "w", *(f"z{i}" for i in range(1, k + 1))))
    descriptor_rank = validate_term(t.descriptor, slots)
    return max(child_rank, descriptor_rank + 1)


def computational_basis(u: Node, k: int = 0, normalize: bool = False) -> Node:
    z = tuple(var(f"z{i}") for i in range(1, k + 1))
    h = body_of(u)
    if normalize:
        h = root_normalize(h)
    r0 = rec(h, ZERO, A, *z)
    rn = rec(h, N, A, *z)
    rs = rec(h, succ(N), A, *z)
    return conj(eq(r0, A), eq(rs, at(u, rn, N)))


def close_instance(formula: Node, k: int = 0) -> Node:
    return all_vars(("a", *(f"z{i}" for i in range(1, k + 1)), "n"), formula)


SEPARATION = implies(eq(ZERO, ONE), BOT)


def payload(u: Node) -> Node:
    return conj(SEPARATION, computational_basis(u))


def descent_body(u: Node) -> Node:
    return implies(forall("n", eq(u, succ(at(u, succ(N))))), BOT)


def descent_instance(u: Node, k: int = 0) -> Node:
    return close_instance(conj(computational_basis(u, k), descent_body(u)), k)


def standalone_descent(u: Node, parameter_names: tuple[str, ...]) -> Node:
    return all_vars(parameter_names, descent_body(u))


def constancy_envelope(u: Node) -> Node:
    return implies(
        forall("n", eq(at(u, succ(N)), u)),
        eq(u, at(u, ZERO)),
    )


def current_constancy(u: Node) -> Node:
    return close_instance(conj(payload(u), constancy_envelope(u)))


def zero_induction_envelope(u: Node) -> Node:
    base = eq(at(u, ZERO), ZERO)
    progress = forall("n", implies(eq(u, ZERO), eq(at(u, succ(N)), ZERO)))
    return implies(conj(base, progress), eq(u, ZERO))


def current_zero_induction(u: Node) -> Node:
    return close_instance(conj(payload(u), zero_induction_envelope(u)))


def bit_matrix(x: Node, y: Node) -> Node:
    return conj(eq(fun("eps", x, x), ZERO), disj(eq(x, y), eq(fun("eps", x, y), ONE)))


BIT = all_vars(("x", "y"), bit_matrix(X, Y))
BIT_GRAPH = all_vars(
    ("x", "y"),
    disj(
        conj(eq(X, Y), eq(fun("eps", X, Y), ZERO)),
        conj(implies(eq(X, Y), BOT), eq(fun("eps", X, Y), ONE)),
    ),
)
COVERAGE = forall("x", disj(eq(X, ZERO), eq(X, succ(rec(W, X, ZERO)))))
MASK_OFF = all_vars(("x", "y"), disj(eq(X, Y), eq(fun("Delta", X, Y), ZERO)))


def exceptional_zero() -> Node:
    return close_instance(
        conj(computational_basis(ZERO), conj(SEPARATION, bit_matrix(A, N)))
    )


def current_bit_alternate(u: Node) -> Node:
    if u == ZERO:
        return exceptional_zero()
    return close_instance(conj(computational_basis(u), zero_induction_envelope(u)))


def side_constancy(u: Node, prune_counter_free: bool = False) -> Node:
    if u == ZERO:
        return exceptional_zero()
    if prune_counter_free and occurrences(u, "n") == 0:
        return close_instance(computational_basis(u))
    return close_instance(conj(computational_basis(u), constancy_envelope(u)))


def mask_envelope(u: Node) -> Node:
    p = eq(fun("Delta", N, u), N)
    progress = forall("n", implies(p, eq(at(u, succ(N)), succ(N))))
    return implies(progress, p)


def current_mask(u: Node) -> Node:
    return close_instance(conj(payload(u), mask_envelope(u)))


def fixed_point_envelope(u: Node) -> Node:
    p = disj(eq(N, ZERO), eq(u, N))
    progress = forall("n", implies(p, eq(at(u, succ(N)), succ(N))))
    return implies(progress, p)


PREDECESSOR_BODY = rec(W, V, ZERO)
DIAGONAL = eq(rec(PREDECESSOR_BODY, N, succ(N)), ONE)


def current_four_occurrence(u: Node) -> Node:
    fixed_payload = conj(payload(u), DIAGONAL)
    return close_instance(conj(fixed_payload, fixed_point_envelope(u)))


def adjacent_envelope(u: Node) -> Node:
    e = eq(u, at(u, N, succ(A)))
    es = eq(at(u, succ(N)), at(u, succ(N), succ(A)))
    p = disj(eq(N, ZERO), e)
    return implies(forall("n", implies(p, es)), p)


def historical_counter(u: Node) -> Node:
    return close_instance(conj(payload(u), adjacent_envelope(u)))


def current_zero_anchor(u: Node) -> Node:
    h = root_normalize(body_of(u))
    if occurrences(u, "a") == 0:
        right = conj(
            eq(rec(h, ZERO, A), A),
            eq(rec(h, succ(N), A), rec(h, N, at(u, A, ZERO))),
        )
        return close_instance(conj(SEPARATION, right))
    e = eq(u, at(u, N, ZERO))
    es = eq(at(u, succ(N)), at(u, succ(N), ZERO))
    p = disj(eq(N, ZERO), e)
    envelope = implies(forall("n", implies(p, es)), p)
    c = conj(SEPARATION, computational_basis(u, normalize=True))
    return close_instance(conj(c, envelope))


def pretty(t: Node) -> str:
    if t.kind in ("var", "const"):
        return t.name
    if t.kind == "fun":
        label = t.name
        if t.descriptor is not None:
            label = "R[" + pretty(t.descriptor) + "]"
        return label + "(" + ",".join(pretty(c) for c in t.children) + ")"
    raise ValueError("pretty is a term formatter")


CORE_BODIES = (
    ZERO, V, W, succ(V), succ(W), PREDECESSOR_BODY,
    rec(succ(V), W, V), rec(ZERO, V, W), succ(rec(W, W, V)),
)


def make_corpus(count: int, k: int, seed: int, bits: bool = False) -> list[Node]:
    rng = random.Random(seed)
    variables = (N, A, *(var(f"z{i}") for i in range(1, k + 1)))
    base = [ZERO, *variables]
    initial = [*base, *(succ(v) for v in base), rec(W, N, A)]
    pool = list(dict.fromkeys(initial))
    seen = set(pool)
    max_active, max_expanded = 35, 250

    def choose() -> Node:
        return rng.choice(base if rng.random() < 0.33 else pool)

    attempts = 0
    while len(pool) < count:
        attempts += 1
        if attempts > count * 500:
            raise RuntimeError("Corpus generation did not reach its requested size")
        decision = rng.randrange(10)
        if decision < 3:
            candidate = succ(choose())
        elif bits and decision == 3:
            candidate = fun("eps", choose(), choose())
        elif k and decision == 4:
            parameter_body = succ(var("z1")) if decision % 2 == 0 else V
            candidate = rec(parameter_body, *(choose() for _ in range(k + 2)))
        else:
            candidate = rec(rng.choice(CORE_BODIES), choose(), choose())
        if size(candidate) <= max_active and size(candidate, True) <= max_expanded:
            if candidate not in seen:
                seen.add(candidate)
                pool.append(candidate)
    return pool


def expect(name: str, formula: Node, active: int, expanded: int | None = None) -> None:
    actual = size(formula)
    assert actual == active, (name, "active", actual, active)
    if expanded is not None:
        actual_expanded = size(formula, True)
        assert actual_expanded == expanded, (name, "expanded", actual_expanded, expanded)


def check_frozen_substitution() -> None:
    body = rec(succ(V), W, V)
    term = rec(body, N, A)
    changed = substitute(term, {"n": ONE, "a": ZERO, "v": succ(V), "w": ZERO})
    assert changed.descriptor is body
    assert changed.children == (ONE, ZERO)
    assert active_variables(term) == frozenset(("n", "a"))
    assert occurrences(term, "v") == occurrences(term, "w") == 0
    assert size(term, True) == size(term) + size(body, True)
    padded = rec(W, succ(rec(W, succ(N), A)), A)
    assert root_normalize(padded) == N
    assert root_normalize(root_normalize(padded)) == root_normalize(padded)


def check_common_term(u: Node) -> None:
    m, weighted = size(u), size(u, True)
    i, j = occurrences(u, "n"), occurrences(u, "a")
    expect("new initialized unit descent", descent_instance(u),
           19 + 3*m + 3*i, 19 + (5+i)*weighted + 3*i)
    expect("standalone unit descent", standalone_descent(u, ("a",)),
           6 + 2*m + i, 6 + 2*weighted + i)
    expect("current constancy", current_constancy(u),
           25 + 5*m + 3*i, 25 + (7+i)*weighted + 3*i)
    expect("current equality-bit zero induction", current_zero_induction(u),
           33 + 5*m + 3*i, 33 + (7+i)*weighted + 3*i)
    expect("current equality mask", current_mask(u),
           35 + 4*m + 3*i, 35 + (6+i)*weighted + 3*i)
    expect("current four-occurrence packaged", current_four_occurrence(u),
           47 + 4*m + 3*i, 51 + (6+i)*weighted + 3*i)
    expect("historical counter recursion", historical_counter(u),
           35 + 7*m + 4*i + 3*j, 35 + (9+i)*weighted + 4*i + 3*j)
    if u == ZERO:
        expect("current alternate equality-bit zero case", current_bit_alternate(u), 38, 40)
        expect("side constancy zero case", side_constancy(u), 38, 40)
        expect("side pruned constancy zero case", side_constancy(u, True), 38, 40)
    else:
        expect("current alternate equality bit", current_bit_alternate(u),
               26 + 5*m + 3*i, 26 + (7+i)*weighted + 3*i)
        expect("side constancy", side_constancy(u),
               18 + 5*m + 3*i, 18 + (7+i)*weighted + 3*i)
        if i == 0:
            expect("side pruned constancy", side_constancy(u, True),
                   13 + m, 13 + 3*weighted)
        else:
            expect("side pruned constancy", side_constancy(u, True),
                   18 + 5*m + 3*i, 18 + (7+i)*weighted + 3*i)
    # Root normalization changes stored descriptor sizes, so this baseline's
    # expanded count is measured without claiming one unqualified closed form.
    expect("current zero-anchor projection", current_zero_anchor(u),
           22 + m if j == 0 else 35 + 7*m + 4*i)


def sample_row(u: Node, k: int = 0) -> dict[str, object]:
    result: dict[str, object] = {
        "term": pretty(u), "k": k, "m": size(u), "W": size(u, True),
        "i": occurrences(u, "n"), "j": occurrences(u, "a"),
        "descent_active": size(descent_instance(u, k)),
        "descent_expanded": size(descent_instance(u, k), True),
    }
    if k == 0:
        for key, constructor in (
            ("current_constancy", current_constancy),
            ("current_bit", current_zero_induction),
            ("current_bit_alternate", current_bit_alternate),
            ("current_mask", current_mask),
            ("current_four_occurrence", current_four_occurrence),
            ("current_zero_anchor", current_zero_anchor),
            ("side_constancy", side_constancy),
            ("side_constancy_pruned", lambda t: side_constancy(t, True)),
        ):
            formula = constructor(u)
            result[key] = {"active": size(formula), "expanded": size(formula, True)}
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--common-count", type=int, default=4096)
    parser.add_argument("--parameter-count", type=int, default=768)
    args = parser.parse_args()
    assert args.common_count >= 10 and args.parameter_count >= 10
    check_frozen_substitution()
    expect("normalized equality-bit axiom", BIT, 18, 18)
    expect("older explicit bit graph", BIT_GRAPH, 24, 24)
    expect("coverage", COVERAGE, 11, 12)
    expect("mask off-diagonal axiom", MASK_OFF, 11, 11)
    expect("unit diagonal", forall("n", DIAGONAL), 8, 12)
    expect("separation", SEPARATION, 6, 6)
    common = make_corpus(args.common_count, 0, 20261102)
    digest = hashlib.sha256()
    max_rank = 0
    for u in common:
        max_rank = max(max_rank, validate_term(u, frozenset(("n", "a"))))
        check_common_term(u)
        digest.update(("0:" + pretty(u) + "\n").encode())
    general_rows = []
    for k in (1, 2, 3):
        corpus = make_corpus(args.parameter_count, k, 20261102 + k, bits=True)
        allowed = frozenset(("n", "a", *(f"z{i}" for i in range(1, k+1))))
        for u in corpus:
            max_rank = max(max_rank, validate_term(u, allowed))
            m, weighted, i = size(u), size(u, True), occurrences(u, "n")
            expect("general initialized descent", descent_instance(u, k),
                   3*k + 19 + 3*m + (k+3)*i,
                   3*k + 19 + (5+i)*weighted + (k+3)*i)
            parameters = ("a", *(f"z{i}" for i in range(1, k+1)))
            expect("general standalone descent", standalone_descent(u, parameters),
                   5 + len(parameters) + 2*m + i,
                   5 + len(parameters) + 2*weighted + i)
            digest.update((str(k) + ":" + pretty(u) + "\n").encode())
        general_rows.append(sample_row(rec(succ(var("z1")), N, A,
                                            *(var(f"z{i}") for i in range(1, k+1))), k))
    examples = (ZERO, N, A, ONE, succ(N), succ(A), rec(W, N, A),
                rec(PREDECESSOR_BODY, N, A), rec(W, succ(N), A))
    report = {
        "status": "all assertions passed",
        "scope": "finite syntax/accounting checks, not an arithmetic proof checker",
        "python": "standard library only; Python >=3.10",
        "source_snapshot": "d46d2b97cb3c4d4f3a0154fc5884ea42ffcd5966",
        "conventions": {
            "active": "one node per variable, constant, application, equality, connective, falsity, quantifier",
            "negation": "expanded as implication to falsity",
            "quantifier_binders": "variable annotations are not separate nodes",
            "descriptors": "frozen under active substitution",
            "expanded": "recursively charge each stored descriptor at each occurrence",
            "computation_ledger": "initialized-recursion equations included in every combined instance",
        },
        "corpus": {
            "common_two_slot_terms": len(common),
            "additional_terms_per_parameter_count": args.parameter_count,
            "tested_additional_parameter_counts_k": [1, 2, 3],
            "total_terms": len(common) + 3*args.parameter_count,
            "random_seed_base": 20261102,
            "ordered_corpus_sha256": digest.hexdigest(),
            "largest_descriptor_dependency_rank": max_rank,
        },
        "new_formulas": {
            "combined_general_active": "3*k+19+3*m+(k+3)*i",
            "combined_general_expanded": "3*k+19+(5+i)*W+(k+3)*i",
            "combined_binary_active": "19+3*m+3*i",
            "combined_binary_expanded": "19+(5+i)*W+3*i",
            "standalone_q_parameters_active": "5+q+2*m+i",
            "standalone_q_parameters_expanded": "5+q+2*W+i",
            "side_constancy_nonzero_active": "18+5*m+3*i",
            "side_constancy_nonzero_expanded": "18+(7+i)*W+3*i",
            "side_counter_free_pruned_active": "13+m (nonzero input; i=0)",
        },
        "fixed_axioms": {
            "normalized_bit": {"active": 18, "expanded": 18},
            "coverage_with_Rw": {"active": 11, "expanded": 12},
            "total_bit_and_coverage": {"active": 29, "expanded": 30},
            "side_exceptional_zero": {"active": 38, "expanded": 40},
        },
        "current_baselines": {
            "constancy": "25+5*m+3*i; changes logic to equality conditionals",
            "bit": "33+5*m+3*i, plus a fixed 24-node axiom",
            "bit_alternate": "38 at literal zero; 26+5*m+3*i otherwise",
            "mask": "35+4*m+3*i, plus a fixed 11-node axiom",
            "four_occurrence": "47+4*m+3*i, all fixed laws packaged",
            "zero_anchor_projection": "22+m if j=0; 35+7*m+4*i otherwise; root-normalized descriptors",
            "historical_counter_for_reference": "35+7*m+4*i+3*j (not one of current six)",
        },
        "sample_rows": [sample_row(u) for u in examples] + general_rows,
        "limits": [
            "No claim that finite testing proves the metatheorem or a general count identity.",
            "Closed-form count identities require the structural derivations in the paper.",
            "The common corpus uses only 0, S, and scalar recursors; no hidden equality primitive.",
            "General-parameter corpus additionally exercises an equality-bit primitive and larger arities.",
            "Theories have different fixed axioms, grammars, and parameter budgets; counts do not imply uniform global dominance.",
        ],
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    lines = [
        "PRA unit-descent: reproducible syntax examples",
        "Finite accounting checks only; not a formal verification of the theorem.",
        "m=active term size; W=descriptor-expanded term size; i=active n occurrences.",
        "All formula abbreviations and negations are expanded by the AST constructors.",
        "",
    ]
    for row in report["sample_rows"]:
        lines.append(json.dumps(row, sort_keys=True))
    lines.extend(("", "Every assertion passed on " + str(report["corpus"]["total_terms"]) + " terms.",
                  "Ordered corpus SHA-256: " + digest.hexdigest(), ""))
    (args.out / "examples.txt").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"status": report["status"], "terms": report["corpus"]["total_terms"],
                      "corpus_sha256": digest.hexdigest(), "output": str(args.out)}, indent=2))


if __name__ == "__main__":
    main()
