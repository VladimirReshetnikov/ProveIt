#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

python3 checks/check_syntax.py
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex

pra_lean_bin="${LEAN_BIN:-lean}"
if command -v "$pra_lean_bin" >/dev/null 2>&1; then
  "$pra_lean_bin" verification/UnitDescent.lean
else
  printf '%s\n' 'PDF and syntax checks rebuilt. Lean was not on PATH; saved results remain available.'
fi
