A PERMANENT ZERO COORDINATE
==========================
A smaller complete presentation of intuitionistic primitive recursive arithmetic
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date).

START HERE
----------
Read report.pdf. report.tex, sections/ and appendices/ contain its complete
editable LaTeX source. The archive is self-contained for offline reproduction.

RESULT
------
The single primary scalar checker is strictly below the current draft envelope
under the inherited whole-program measure:

                                            Tokens   AST nodes   Bytes
Current eleven delivered checkers               342         364     978
Current envelope with the same stdin driver     341         362     970
New checker.py                                 336         361     968
New checker_direct.py                          343         367     980

The current comparison snapshot is VladimirReshetnikov/ProveIt commit
fa69b78013baadf9a4e9d63ef1a57f56ca1eb017, all six active docs/drafts ZIPs.
All eleven current root checker files are included unchanged, with hashes.
The source normalizer is copied unchanged from that corpus. The reduction
survives identical input/output drivers and identical branch arrangements.
No executable import or acceptance helper is omitted from the count.

The direct companion is useful for its much shorter arithmetic reconstruction,
but it does NOT beat the current scalar frontier. The primary result is scalar.

NEW IDEA
--------
Put a permanent zero slot before every numerical coordinate environment.
Numerical root depth becomes 3 and unary/binary/ternary increments become
2/3/4: constructor arity plus one. A bounded range still checks arity.
Then validate a scalar or numerical image before multiplying by the sort bit.
At formula sort, numbers become zero and lists become empty truth; at numerical
sort they retain their denotation. Eager evaluation prevents malformed arrays
from bypassing validation through a zero mask. The same traversal implements
validation and opening without an explicit list-type branch.

MATHEMATICAL CONTENT AND STATUS
-------------------------------
The inherited native theory has 0, successor and initialized scalar iteration;
two computation schemas; equality, a closure binder and a paired binder;
and five inference patterns. The report explicitly gives every axiom/schema,
rule and eigenvariable condition. Full intuitionistic first-order logic is
derived. The induction hypothesis is restricted to literal equations.

The paper includes the scalar comparator, predecessor, equality reflection,
pairing and fixed-description primitive-recursive compiler. Its ordinary
realization and iPRA have whole-domain interpretations whose composites are
internally the identity, including at nonstandard arguments. Genuine falsity
is handled by the explicit ordinary bridge 0=S0 -> bottom. Equiconsistency
follows from the two interpretations and the faithful native realization.

The new contribution is a smaller certificate representation and complete
checker, with a written correctness proof. The arithmetic/logical basis is
inherited and fully attributed. This is a strict finite-corpus improvement,
not a theorem of global simplestness or the larger foundational breakthrough
requested. No Lean or Rocq formalization is claimed. Executable tests are
finite evidence, not a proof of consistency or universal correctness.

USAGE
-----
Requires Python 3.10 or later for the standalone checkers.

  python3 checker.py < examples/equation_induction_identity.json
  python3 checker.py < examples/encoded_implication_reflexivity.json

Successful verification prints ACCEPT and exits 0. Rejection prints REJECT
and exits 1. Instructions are popped from the packet's end after its closed
goal. Unread prefix cells have no logical effect. FORMAT.txt summarizes the
raw syntax; the report gives the precise decoding.

REPRODUCTION
------------
  python3 measure.py
  python3 validation/run.py

Or run both with:
  python3 reproduce.py

To compile the paper, with ordinary pdfLaTeX packages installed:
  python3 build.py
  python3 reproduce.py --pdf

The build helper includes a local-format/font-map setup adapted from the
supplied drafts for minimal TeX installations. It does not download material
or require shell escape. PDF layout was separately rendered and inspected.

EVIDENCE
--------
All 202 inherited positive certificates pass after the documented coordinate
translation: 147 scalar and 55 direct.
The independent named-rule oracle agrees on acceptance, cells consumed and
allocation state. Nineteen focused boundary cases, seven mutation controls,
ten actual CLI checks (including python -O), and three raw-syntax diagnostics
pass. The selected examples include equation induction, quantified logic,
transport under binders, and genuine failed-major fallthrough.

Concrete bad mutants accept false equations when the numerical-root opening
offset is left at 1, when direct state/counter slots are confused, or when
the negative-label freshness lower bound is removed. The correct programs
reject those packets. The validation README explains which mutations test
soundness and which demonstrate a positive certificate's use of a mechanism.

Raw accepted packet sets need not coincide with earlier checkers. Eager masking
rejects some formerly inert malformed annotations and admits a harmless new
scalar-to-empty truth case. Canonical theorem languages coincide under decoding.

CONTENTS
--------
report.tex, sections/, appendices/     Complete mathematical paper sources
report.pdf                            Compiled paper
checker.py                            Smallest delivered scalar checker
checker_direct.py                     Full primitive-recursion companion
examples/                             Seventeen selected positive certificates
validation/                           Independent oracle, fixtures and controls
comparison/                           Frozen baselines, metric and ablations
results/                              Measurement, validation, build, and QA receipts
measure.py, reproduce.py, build.py     Reproduction commands
source_snapshot.json                  Pinned archive identities and hashes
ATTRIBUTION.txt, LICENSE-inherited.txt Contribution boundaries and license
MANIFEST.sha256                       Integrity information for the final package

See the paper's Further research questions section for the direct one-opening
problem, a possible logical-rule reduction, formal raw-trace verification, and
a more language-independent comparison standard.
