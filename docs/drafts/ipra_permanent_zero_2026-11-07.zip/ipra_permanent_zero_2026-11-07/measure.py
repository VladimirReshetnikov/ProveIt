"""Reproduce whole-checker size measurements and identical-driver controls.

Run with Python 3.12 or later from any working directory. This measurement
program, its generated controls, and its baseline snapshots are outside the
proof-acceptance boundary. Only checker.py accepts the primary certificates.
"""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import platform
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT / "comparison"
RESULTS = ROOT / "results"
COORDINATES = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_normalizer():
    path = COMPARISON / "source_measure.py"
    spec = importlib.util.spec_from_file_location("source_measure", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


NORMALIZER = load_normalizer()


def controlled_source(source, driver):
    """Replace exactly the one top-level CLI try statement, preserving kernel."""
    module = ast.parse(source)
    positions = [i for i, node in enumerate(module.body) if isinstance(node, ast.Try)]
    if len(positions) != 1 or positions[0] != len(module.body) - 1:
        raise ValueError("Expected one final top-level command-line try statement")
    module.body[positions[0]:] = ast.parse(driver).body
    return ast.unparse(ast.fix_missing_locations(module)) + "\n"


def controlled_branch(source, arrangement):
    """Use one of the two already delivered major-premise branch layouts."""
    module = ast.parse(source)
    functions = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == "check"]
    if len(functions) != 1:
        raise ValueError("Expected the named checker function")
    matches = [node for node in functions[0].body if isinstance(node, ast.Match)]
    if len(matches) != 1:
        raise ValueError("Expected one proof-instruction match")
    case = matches[0].cases[0]
    expected_high = ast.parse("h = [m[2:]]").body
    expected_low = ast.parse(
        "if not m[1:]:\n"
        "    t, m = m[0], [0, t]\n"
        "return inst(t, m[1]) == a and check(inst(t, m[0]), g)\n"
    ).body
    positive_test = ast.parse("m[2:]", mode="eval").body
    standard = [ast.If(test=positive_test, body=expected_high, orelse=expected_low)]
    node = [ast.If(test=ast.UnaryOp(op=ast.Not(), operand=positive_test), body=expected_low, orelse=[]), *expected_high]
    def shape(nodes):
        return [ast.dump(item, include_attributes=False) for item in nodes]
    if shape(case.body) not in (shape(standard), shape(node)):
        raise ValueError("Unexpected major-premise branch; refuse a broader rewrite")
    case.body = {"standard": standard, "node": node}[arrangement]
    return ast.unparse(ast.fix_missing_locations(module)) + "\n"


def make_driver(input_expression, conventional=False):
    if conventional:
        decision = "    if not check(take(), []):\n        raise ValueError('invalid proof')"
        handler = "except Exception:"
    else:
        decision = "    1 / check(take(), [])"
        handler = "except:"
    return (
        "try:\n"
        f"    take = json.load({input_expression}).pop\n"
        f"{decision}\n"
        "    print('ACCEPT')\n"
        f"{handler}\n"
        "    print('REJECT')\n"
        "    sys.exit(1)\n"
    )


DRIVERS = {
    "common_stdin": make_driver("sys.stdin"),
    "common_filename": make_driver("open(sys.argv[1])"),
    "conventional_stdin": make_driver("sys.stdin", conventional=True),
    "conventional_filename": make_driver("open(sys.argv[1])", conventional=True),
}


def source_metrics(source):
    # Reuse the supplied corpus normalizer unchanged, including its complete
    # program boundary. Temporary files let us call its original file API.
    with tempfile.TemporaryDirectory(prefix="ipra-size-") as directory:
        path = Path(directory) / "checker.py"
        path.write_text(source, encoding="utf-8")
        return NORMALIZER.metrics(path)


def envelope(rows):
    minimum = {key: min(row[key] for row in rows) for key in COORDINATES}
    return {
        "minimum": minimum,
        "attainers": {
            key: [row["label"] for row in rows if row[key] == minimum[key]]
            for key in COORDINATES
        },
    }


def compare(candidate, minimum):
    return {
        "strictly_smaller": {key: candidate[key] < minimum[key] for key in COORDINATES},
        "absolute_reduction": {key: minimum[key] - candidate[key] for key in COORDINATES},
        "percentage_reduction": {
            key: 100 * (minimum[key] - candidate[key]) / minimum[key]
            for key in COORDINATES
        },
    }


def rows_for(entries, driver=None, branch=None):
    rows = []
    for entry in entries:
        path = ROOT / entry["path"]
        raw_hash = digest(path)
        if "expected_sha256" in entry and raw_hash != entry["expected_sha256"]:
            raise ValueError("Changed frozen comparator: " + entry["path"])
        source = path.read_text(encoding="utf-8")
        if branch is not None:
            source = controlled_branch(source, branch)
        if driver is None and branch is None:
            measured = NORMALIZER.metrics(path)
        else:
            measured = source_metrics(controlled_source(source, driver) if driver is not None else source)
        rows.append({
            "label": entry["label"],
            "source_file": entry["path"],
            "source_sha256": raw_hash,
            **measured,
        })
    return rows


def group(baseline_entries, candidate_entries, driver=None, branch=None):
    baselines = rows_for(baseline_entries, driver, branch)
    candidates = rows_for(candidate_entries, driver, branch)
    lower = envelope(baselines)
    return {
        "baselines": baselines,
        "baseline_envelope": lower,
        "candidates": candidates,
        "comparisons": {
            candidate["label"]: compare(candidate, lower["minimum"])
            for candidate in candidates
        },
    }


def tex_row(label, values):
    return label + " & " + " & ".join(str(values[key]) for key in COORDINATES) + " " + chr(92) * 2


def main():
    manifest_path = COMPARISON / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    baseline_entries = [
        {
            "label": entry["label"],
            "path": str(Path("comparison") / entry["local_file"]),
            "expected_sha256": entry["sha256"],
        }
        for entry in manifest["programs"]
    ]
    candidate_entries = [
        {"label": "new scalar", "path": "checker.py"},
        {"label": "new direct", "path": "checker_direct.py"},
    ]
    delivered = group(baseline_entries, candidate_entries)
    controls = {
        name: {"driver_source": driver, **group(baseline_entries, candidate_entries, driver)}
        for name, driver in DRIVERS.items()
    }
    for branch in ("node", "standard"):
        name = "common_stdin_" + branch + "_branch"
        controls[name] = {
            "driver_source": DRIVERS["common_stdin"],
            "branch_control": branch,
            **group(baseline_entries, candidate_entries, DRIVERS["common_stdin"], branch),
        }
    ablation_manifest = json.loads((COMPARISON / "ablations" / "manifest.json").read_text())
    ablation_entries = [
        {
            "label": entry["label"],
            "path": str(Path("comparison/ablations") / entry["file"]),
            "expected_sha256": entry["sha256"],
        }
        for entry in ablation_manifest["programs"]
    ]
    ablations = rows_for(ablation_entries, DRIVERS["common_stdin"])
    result = {
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "archive_count": len(manifest["archives"]),
        "baseline_program_count": len(baseline_entries),
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "coordinates": list(COORDINATES),
        "definition": (
            "Entire standalone Python acceptance program; genuine docstrings are removed, "
            "the AST is unparsed, significant lexical tokens and AST nodes are counted, "
            "and normalized UTF-8 byte length is recorded. No identifiers are renamed. "
            "Imports, parsing, verdict output, rejection status, and all logical code remain."
        ),
        "normalizer_source": "comparison/source_measure.py",
        "normalizer_sha256": digest(COMPARISON / "source_measure.py"),
        "baseline_manifest_sha256": digest(manifest_path),
        "measure_source_sha256": digest(Path(__file__)),
        "as_delivered": delivered,
        "controls": controls,
        "ablations": {
            "driver": "common_stdin",
            "description": ablation_manifest["description"],
            "programs": ablations,
        },
        "scope": (
            "The coordinatewise lower envelope is an empirical minimum over these "
            "eleven programs, not a lower bound on every possible iPRA presentation. "
            "The direct-recursion companion is measured but is not claimed to dominate "
            "the scalar frontier. Driver controls replace only the final top-level try."
            " The two explicitly named branch controls additionally choose the same "
            "existing major-premise branch arrangement in every program; all other "
            "kernel syntax is preserved."
        ),
    }
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / "measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = [
        r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
        r"Complete program or envelope & Tokens & AST nodes & Bytes\\",
        r"\midrule",
        tex_row("Delivered baseline envelope", delivered["baseline_envelope"]["minimum"]),
        tex_row("New scalar checker", delivered["candidates"][0]),
        tex_row("New direct companion", delivered["candidates"][1]),
        r"\addlinespace",
        tex_row("Common stdin: baseline envelope", controls["common_stdin"]["baseline_envelope"]["minimum"]),
        tex_row("Common stdin: new scalar", controls["common_stdin"]["candidates"][0]),
        tex_row("Common filename: baseline envelope", controls["common_filename"]["baseline_envelope"]["minimum"]),
        tex_row("Common filename: new scalar", controls["common_filename"]["candidates"][0]),
        tex_row("Same stdin and node branch: baseline", controls["common_stdin_node_branch"]["baseline_envelope"]["minimum"]),
        tex_row("Same stdin and node branch: new scalar", controls["common_stdin_node_branch"]["candidates"][0]),
        r"\addlinespace",
        tex_row("Conventional stdin: baseline envelope", controls["conventional_stdin"]["baseline_envelope"]["minimum"]),
        tex_row("Conventional stdin: new scalar", controls["conventional_stdin"]["candidates"][0]),
        r"\bottomrule", r"\end{tabular}", "",
    ]
    (RESULTS / "main_table.tex").write_text("\n".join(lines))
    ablation_lines = [
        r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
        r"Ablation; identical stdin driver & Tokens & AST nodes & Bytes\\",
        r"\midrule",
        *[tex_row(row["label"], row) for row in ablations],
        r"\bottomrule", r"\end{tabular}", "",
    ]
    (RESULTS / "ablation_table.tex").write_text("\n".join(ablation_lines))
    summary = {
        "as_delivered": {
            "baseline_envelope": delivered["baseline_envelope"]["minimum"],
            "new_scalar": {key: delivered["candidates"][0][key] for key in COORDINATES},
            "new_direct": {key: delivered["candidates"][1][key] for key in COORDINATES},
        },
        "controls": {
            name: {
                "baseline_envelope": values["baseline_envelope"]["minimum"],
                "new_scalar": {key: values["candidates"][0][key] for key in COORDINATES},
                "strict": all(values["comparisons"]["new scalar"]["strictly_smaller"].values()),
            }
            for name, values in controls.items()
        },
        "ablations": [
            {"label": row["label"], **{key: row[key] for key in COORDINATES}}
            for row in ablations
        ],
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
