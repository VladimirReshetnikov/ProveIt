"""Compile the report using ordinary LaTeX; all sources are in this archive."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which('pdflatex'):
        raise SystemExit('pdflatex is required to compile report.tex')
    (ROOT / 'results').mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ipra-permanent-zero-') as directory:
        environment = os.environ.copy()
        def locate(name):
            return subprocess.run(['kpsewhich', name], env=environment,
                                  capture_output=True).returncode == 0
        # Inherited portable setup: some minimal TeX installations have all
        # sources but no filename database, generated format, or font map.
        distribution = Path('/usr/share/texlive/texmf-dist')
        if not locate('article.cls') and (distribution/'tex/latex/base/article.cls').exists():
            environment['TEXMF'] = '{/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}'
        if not locate('pdflatex.fmt'):
            setup = subprocess.run(
                ['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
                 '-jobname=pdflatex', '-progname=pdflatex', 'pdflatex.ini'],
                cwd=directory, env=environment, capture_output=True, text=True)
            if setup.returncode:
                raise SystemExit(setup.stdout[-5000:] + setup.stderr)
            environment['TEXFORMATS'] = directory + os.pathsep + environment.get('TEXFORMATS', '')
        if not locate('pdftex.map') and distribution.exists():
            maps = sorted((distribution/'fonts/map/dvips/amsfonts').glob('*.map'))
            latin_modern = Path('/usr/share/texmf/fonts/map/dvips/lm/lm.map')
            if latin_modern.exists():
                maps.append(latin_modern)
            if maps:
                (Path(directory)/'pdftex.map').write_bytes(b'\n'.join(p.read_bytes() for p in maps))
                environment['TEXFONTMAPS'] = directory + os.pathsep + environment.get('TEXFONTMAPS', '')
        for index in range(1, 4):
            result = subprocess.run(
                ['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
                 '-halt-on-error', '-output-directory', directory, 'report.tex'],
                cwd=ROOT, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            (ROOT / 'results' / f'latex_pass_{index}.txt').write_text(result.stdout)
            if result.returncode:
                print(result.stdout[-8000:])
                raise SystemExit(result.returncode)
        log = (Path(directory)/'report.log').read_text(errors='replace')
        (ROOT/'results/report.log').write_text(log)
        shutil.copy2(Path(directory)/'report.pdf', ROOT/'report.pdf')
    problems = [line for line in log.splitlines()
                if 'Overfull' in line or 'undefined' in line
                or 'multiply defined' in line or line.startswith('!')]
    receipt = {'status': 'PASS' if not problems else 'REVIEW',
               'pdf': 'report.pdf', 'pdf_bytes': (ROOT / 'report.pdf').stat().st_size,
               'problems': problems, 'passes': 3}
    (ROOT / 'results' / 'build.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))
    if problems:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
