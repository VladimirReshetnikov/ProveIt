"""Complete iPRA certificate checker: direct primitive recursion.

A permanent zero coordinate makes child scopes affine in constructor arity.
Eager scalar masking validates a leaf or numerical image before erasing it
at formula sort. Input is a JSON packet on stdin; no local module is used.
See report.pdf for the native calculus, decoding, and proof obligations.
"""
import json, sys
k = 0


def inst(a, t=None, d=0):
    try:
        return [inst(b, t, d + range(1, 5)[len(a)]) for b in a + []]
    except:
        return d % 2 * (a if k <= a < d else inst(t, d=3))


def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if not m[2:]:
                if not m[1:]:
                    t, m = m[0], [0, t]
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
            h = [m[2:]]
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(inst(r, n, 5), [n, t, r], 3)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])


try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
