"""Reproduce source measurements, focused evidence, and optionally the PDF."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
for script in ('measure.py', 'validation/run.py'):
    subprocess.run([sys.executable, script], cwd=root, check=True)
if '--pdf' in sys.argv:
    subprocess.run([sys.executable, 'build.py'], cwd=root, check=True)
