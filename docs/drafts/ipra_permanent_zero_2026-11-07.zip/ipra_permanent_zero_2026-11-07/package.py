"""Create the complete ZIP and verify its manifest; no network is needed."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT.parent / (ROOT.name + '.zip')


def included(path):
    rel = path.relative_to(ROOT)
    return (path.is_file() and '__pycache__' not in rel.parts
            and path.suffix not in {'.pyc', '.aux', '.out', '.toc'}
            and path.name != 'MANIFEST.sha256')


def main():
    files = sorted(p for p in ROOT.rglob('*') if included(p))
    manifest = ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  '
                       + p.relative_to(ROOT).as_posix() + '\n' for p in files)
    (ROOT/'MANIFEST.sha256').write_text(manifest)
    files.append(ROOT/'MANIFEST.sha256')
    with zipfile.ZipFile(ARCHIVE, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for path in sorted(files):
            info = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 7, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            out.writestr(info, path.read_bytes())
    with zipfile.ZipFile(ARCHIVE) as source:
        assert source.testzip() is None
        for line in manifest.splitlines():
            expected, rel = line.split('  ', 1)
            payload = source.read(ROOT.name + '/' + rel)
            if hashlib.sha256(payload).hexdigest() != expected:
                raise RuntimeError('ZIP manifest mismatch: ' + rel)
    print(f'{ARCHIVE.name}: {len(files)} files, {ARCHIVE.stat().st_size} bytes')


if __name__ == '__main__':
    main()
