"""Permanent-zero coordinates and affine scope increments; early erasure and node branch.

Measurement ablation, outside the delivered checker acceptance path. Derived from
the attributed pinned sort-erasure scalar checker and the new checker.py.
See comparison/ablations/README.txt. No project-specific imports."""
import json, sys
k = 0

def inst(a, t=None, d=0):
    if isinstance(a, list):
        return [inst(b, t, d + range(1, 5)[len(a)]) for b in a]
    return d % 2 and (a if k <= a < d else inst(t, d=3))

def check(a, g):
    global k
    if inst(a) in g:
        return True
    match take():
        case [m, t] if check(m, g):
            if not m[2:]:
                if not m[1:]:
                    t, m = (m[0], [0, t])
                return inst(t, m[1]) == a and check(inst(t, m[0]), g)
            h = [m[2:]]
        case []:
            (n, t, r), b = a
            if n:
                n, = n
                t = inst(r, [n, t, r], 3)
            return b == t
        case t:
            a = inst(a[2], t, 2)
            h = [a, inst(a, 0)][len(a) % 2:]
    k -= 1
    return check(inst(a, [k]), g + [inst(c, k) for c in h])
try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
