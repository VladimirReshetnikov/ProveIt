VALIDATION: WHAT WAS CHECKED
============================

Run from the archive root:

  python3 validation/run.py

The runner uses only the Python standard library. It produces
results/validation.json, examples/index.json and the documented certificate
examples. Source provenance, original hashes and licenses are retained
inside validation/fixtures/provenance.json, validation/ATTRIBUTION.txt and
LICENSE-inherited.txt. The original scalar/direct fixtures are unchanged.

The last successful run checked:

  202 inherited positive packets: 147 scalar and 55 direct;
   19 targeted public-boundary cases;
    7 mutation controls;
   10 actual process checks, with normal Python and python -O;
    3 raw-syntax diagnostics.

All inherited positive packets passed after the documented coordinate
embedding. The production checkers and independent named-rule oracle agreed
on acceptance, final allocation floor, and remaining packet cells. The
positive cases exercise both computation schemas, every native inference
pattern, equation induction, closure and paired elimination, and equality
transport below nested logical binders. Seventeen selected examples are
exported under examples/; examples/index.json records what they actually do.

THE INDEPENDENT ORACLE

oracle.py uses separate numerical and formula traversals, named inference
rules, and explicit counts of protected numerical slots. It imports neither
production checker and uses no packed depth, range-based scope table, or
structural pattern matcher. Its origin and modifications are documented in
its header and fixtures/provenance.json.

The numerical root ceiling is 2*q+3 for q protected slots. A numerical
binary zero node checks its formula annotations under q+3 protected slots.
The default oracle explicitly models eager masking: a numerical leaf is
opened and multiplied by one; a formula leaf is opened and multiplied by
zero. This preserves the difference between scalar zero and empty-list
truth when an image is a list. Setting eager=False models the earlier
permissive reference only, not the final acceptance boundary.

The source fixture embedding adds two to positive numerical coordinates.
It is used for the inherited canonical fragment, not advertised as a
correct translator for every arbitrary raw packet. The final results
report all rejected translations rather than silently excluding them;
there were none among the 202 retained fixtures.

NEW SEMANTIC MUTATION CONTROLS

1. A stale scalar update-opening depth of 1 treats permanent zero alias 1
   as a state hole. The mutant accepts

     I(1,1;u.0) = I(0,1;u.0),

   whose two numerical values are 0 and 1. The correct checker rejects it.

2. In direct recursion, opening the counter at depth 3 instead of 5
   consumes the state slot prematurely. The supplied mutant certificate
   proves an equation with values 1 and 0.

3. Replacing the two-stage direct opening by scalar opening conflates
   counter and state. Its supplied equation has values 0 and 1.

The small, independent numerical evaluator in run.py computes these value
pairs directly, using the permanent-zero and dummy-slot semantics; they
are not only labels attached to the tests.

4. Removing the lower allocation bound accepts a closed false formula:

     D_{x,y} ( P(y) = C(y,0,x) ),

   where P is direct predecessor and C is the zero/successor selector.
   The y=0 base is true. Its closure would therefore imply all instances;
   y=1 forces x=0, while y=2 forces x=1. The rejected certificate chooses
   future witness -1, then lets it coincide with the next DI eigenparameter.
   Its resulting step only checks P(S(-1))=-1, which computes correctly.
   The proper freshness bound rejects before that allocation.

   run.py constructs this certificate from explicit zero-computation and
   equality-transport derivations of reflexivity, symmetry and transitivity.
   This construction does not call the production opening routine.

5. Deleting the atomic induction hypothesis rejects the selected proof of
   Q_n(I(n,0;u.Su)=n). This establishes that the example actually uses
   equation induction, rather than merely testing numeral calculations.

6. Deleting the retained base rejects the selected proof of Q_n(n=1).
   That closure is valid because its base 0=1 is false; the packet does not
   claim the unconditional sentence forall n n=1.

7. Restoring image validation at numerical root 1 loses a valid proof
   involving permanent-zero alias 1. This is a completeness regression,
   distinct from the false-equation update-depth mutation in item 1.

RAW-SYNTAX DISTINCTIONS AND NEGATIVE CASES

The packet [[0], [0,0,2]] demonstrates the harmless DI scalar-to-empty case.
Its decoded paired matrix is truth. Eager masking validates the list image
and gives 0*[0]=[]; the resulting empty truth assumption closes the step.
The permissive short-circuit reference rejects this particular packet.
Thus arbitrary accepted raw packets are not claimed to coincide between
the two presentations.

A four-child array raises in the final opener. Replacing eager multiplication
by short-circuit conjunction lets the exception handler return scalar truth
instead. The test records this syntax-validation defect only; it does not
claim, without a separate construction, that that entire modified checker
accepts a false arithmetic sentence.

General root-scalar idempotence is not assumed: scalar zero can validate
inside a protected formula position while failing at formula root. The
oracle and runner contain an explicit diagnostic for this distinction.

Two newly written certificates exercise real failed major-premise guards,
including a failed major that consumes an eigenallocation before fallback.
Some inherited fixture names mention failed allocation, but their actual
named-rule traces show successful paired eliminations. The original names
are retained only as provenance, and the selected-example descriptions
state the observed behavior.

Other boundary tests cover unavailable rigid parameters, future witnesses,
malformed used and unused witnesses, oversized unused updates, permanent
zero aliases, binary numerical zero, nonfinite numerical data, inert packet
prefixes, malformed JSON, and non-array packets. The actual normal and -O
process runs check stdout, exit status, and rejection without relying on
assert statements in the acceptance code.

LIMIT OF THE EVIDENCE

These are finite implementation tests and an independent executable
comparison. They are not a formal proof of soundness, completeness,
consistency, or bi-interpretability. The universal mathematical claims
are addressed by the written metatheory in report.pdf, and have not been
mechanized in Lean or Rocq. The validation runner, oracle, producers and
fixtures are outside the trusted acceptance boundary.
