#!/usr/bin/env python3
"""Independent named-rule / canonical embedding checks for affine iPRA.

Validation only: neither this program nor its imported independent oracle
participates in the acceptance boundary. Source fixtures are credited in
output receipts. This runner counts discrepancies, not assumptions of
blanket packet equivalence across different raw language completions.
"""
import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


Oracle = module('independent_affine_oracle', HERE / 'oracle.py').Oracle
OldOracle = module('independent_uniform_oracle', HERE / 'oracle_uniform_inherited.py').Oracle


def lift_tree(value, numerical=False):
    """Canonical embedding: +2 only at positive numerical coordinates.

This static embedding is claimed for canonical numerical syntax, not for
arbitrary noncanonical binary numerical annotations or malformed witnesses.
Logical binders retain their bound-variable count. Every transition from
an equation to a term inserts a permanent zero slot.
"""
    if type(value) is list:
        if len(value) == 2:
            return [lift_tree(child, not numerical) for child in value]
        return [lift_tree(child, numerical) for child in value]
    if numerical and isinstance(value, (int, float)) and value >= 1:
        return value + 2
    return value


def lift_packet(packet):
    def instruction(item):
        if type(item) is list and len(item) == 2:
            major, annotation = item
            is_equality = type(major) is list and len(major) == 2
            return [lift_tree(major), lift_tree(annotation, not is_equality)]
        return lift_tree(item, True)
    return [instruction(item) for item in packet[:-1]] + [lift_tree(packet[-1])]


def load_kernel(path, replacements=()):
    source = path.read_text()
    for before, after in replacements:
        if source.count(before) != 1:
            raise ValueError(('mutation target count', before, source.count(before)))
        source = source.replace(before, after)
    tree = ast.parse(source)
    body = []
    for node in tree.body:
        if isinstance(node, ast.Try):
            break
        body.append(node)
    env = {}
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), env)
    return env


def kernel_result(env, packet):
    stack = deepcopy(packet)
    env['k'] = 0
    try:
        env['take'] = stack.pop
        accepted = bool(env['check'](stack.pop(), []))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {'accepted': accepted, 'final_k': env['k'],
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def numerical_value(tree, width=1, protected=()):
    """Independent denotation for the small closed mutation equations.

    These are numerical syntax coordinates, not literal natural numerals.
    The zero slot has coordinates 0,1,2; subsequent coordinate pairs name
    protected values. Unary syntax prepends a zero dummy. Recursor inputs
    prepend two zero dummies; updates receive state/state or state/counter.
    This evaluator is neither imported by nor called from a checker.
    """
    if type(tree) is not list:
        if not isinstance(tree, (int, float)) or not math.isfinite(tree):
            raise ValueError('nonfinite or nonnumeric coordinate')
        coordinate = math.floor(tree)
        if coordinate < 0:
            raise ValueError('mutation equation unexpectedly has a free parameter')
        if coordinate < 3:
            return 0
        return protected[(coordinate - 3) // 2]
    if len(tree) in (0, 2):
        return 0
    if len(tree) == 1:
        return 1 + numerical_value(tree[0], width, (0,) + protected)
    if len(tree) == 3:
        count, initial, update = tree
        count_value = numerical_value(count, width, (0, 0) + protected)
        state = numerical_value(initial, width, (0, 0) + protected)
        if count_value > 1000:
            raise ValueError('unexpectedly large mutation equation')
        for counter in range(count_value):
            slots = (state, state) if width == 1 else (state, counter)
            state = numerical_value(update, width, slots + protected)
        return state
    raise ValueError('term arity')


def false_future_witness():
    """A closed false direct-recursion claim accepted without freshness.

    Goal: D_xy(P(y)=C(y,0,x)). Its base is true; specialization at one
    forces x=0 and at two forces x=1. The forbidden witness -1 collides
    with the next induction eigenparameter. The step then only checks
    P(S(-1))=-1=C(S(-1),0,-1), whose computation proofs are easy.

    The small proof builder below derives reflexivity, symmetry, and
    transitivity from zero computation and equality transport. It is
    independent of the production opener.
    """
    eigen = -1
    left, right = [[eigen], 0, 5], [[eigen], 0, eigen]

    def reflexivity(term):
        equation = [[0, term, 0], term]
        return [[equation, [3, term]], [], []]

    def symmetry(equation, proof):
        first, _ = equation
        return [[equation, [3, first]]] + proof + reflexivity(first)

    def transitivity(first, proof_first, second, proof_second):
        start, middle = first
        middle_again, _ = second
        if middle != middle_again:
            raise ValueError('transitivity middle')
        return [[second, [start, 3]]] + proof_second + proof_first

    step = transitivity([left, eigen], [[]], [eigen, right],
                        symmetry([right, eigen], [[]]))
    matrix = [[7, 0, 5], [7, 0, 9]]
    goal = [matrix, matrix, matrix]
    return list(reversed([eigen] + step)) + [goal]


def controls(primary, scalar, direct):
    """Small semantic regressions, public-boundary probes, and real drivers."""
    truth = [[0, 0], [0, 0], [0, 0]]
    variable_truth = [[5, 5], [5, 5], [5, 5]]
    failed_matrix = [[0, 0, 0], 3]
    failed_major = [failed_matrix, failed_matrix, failed_matrix]
    zero = [[], [[0, 0, 0], 0]]
    cases = [
        ('empty_packet', [], False),
        ('non_array_packet', {'proof': []}, False),
        ('scalar_goal', [0], False),
        ('false_zero_computation', [[], [[0, 0, 0], [0]]], False),
        ('unavailable_rigid_parameter', [[], [[0, -1, 0], -1]], False),
        ('exposed_root_coordinate', [[], [[0, 3, 0], 3]], False),
        ('future_witness_used', [-1, variable_truth], False),
        ('oversized_unused_update', [[], [[0, 0, [0, 0, 0, 0]], 0]], False),
        ('malformed_used_witness', [None, variable_truth], False),
        ('malformed_unused_witness', [None, truth], True),
        ('erased_scalar_becomes_empty_matrix', [[0], [0, 0, 2]], True),
        ('erased_scalar_remains_scalar_matrix', [0, [0, 0, 2]], False),
        ('permanent_zero_alias_one', [[], [[0, 1, 0], 1]], True),
        ('permanent_zero_alias_two', [[], [[0, 2, 0], 2]], True),
        ('binary_numerical_zero', [[], [[0, [0, 0], 0], [0, 0]]], True),
        ('inert_packet_prefix', ['unused prefix', None] + zero, True),
        ('nonfinite_numerical_goal', [[], [[0, float('inf'), 0], float('inf')]], False),
        ('failed_major_without_allocation',
         [[], [[[0, 0, 0], [0]], 0], truth], True),
        ('failed_major_retains_allocation',
         [[], 0, [failed_major, 0], truth], True),
    ]
    boundary = []
    for name, packet, accepted in cases:
        actual = kernel_result(scalar, packet)
        expected = Oracle(1, eager=True).run(packet)
        boundary.append({'name': name, 'expected_acceptance': accepted,
                         'candidate': actual, 'oracle': expected,
                         'passed': actual['accepted'] == expected['accepted'] == accepted
                         and actual['final_k'] == expected['final_k']
                         and actual['remaining'] == expected['remaining']})
        if name in ('erased_scalar_becomes_empty_matrix',
                    'failed_major_without_allocation', 'failed_major_retains_allocation'):
            (ROOT / 'examples' / (name + '.json')).write_text(json.dumps(packet, indent=2) + '\n')

    mutation = []

    def mutation_test(name, path, replacements, packet, ordinary, mutant,
                      significance, values=None):
        before = kernel_result(scalar if path == primary else direct, packet)
        after = kernel_result(load_kernel(path, replacements), packet)
        row = {'name': name, 'checker': path.name, 'replacements': replacements,
               'correct': before, 'mutant': after, 'significance': significance,
               'packet': packet, 'passed': before['accepted'] == ordinary
               and after['accepted'] == mutant}
        if values is not None:
            width = 1 if path == primary else 2
            actual_values = [numerical_value(t, width) for t in packet[-1]]
            row['decoded_equation_values'] = actual_values
            row['passed'] = row['passed'] and actual_values == values and actual_values[0] != actual_values[1]
        mutation.append(row)
        (HERE / 'fixtures' / (name + '.json')).write_text(json.dumps(packet, indent=2) + '\n')

    mutation_test('stale_state_opening_depth', primary,
                  [('inst(r, [n, t, r], 3)', 'inst(r, [n, t, r], 1)')],
                  [[], [[[0], [0], 1], [0, [0], 1]]], False, True,
                  'Permanent zero alias 1 must not become the previous-state hole; the mutant proves a false equation.',
                  [0, 1])
    direct_path = ROOT / 'checker_direct.py'
    mutation_test('counter_opening_must_protect_state', direct_path,
                  [('inst(inst(r, n, 5), [n, t, r], 3)',
                    'inst(inst(r, n, 3), [n, t, r], 3)')],
                  [[], [[[0], [0], 3], 0]], False, True,
                  'The first direct opening protects the state slot; opening it as the counter proves 1=0.',
                  [1, 0])
    mutation_test('state_counter_must_be_distinct', direct_path,
                  [('inst(inst(r, n, 5), [n, t, r], 3)',
                    'inst(r, [n, t, r], 3)')],
                  [[], [[[0], [0], 5], [0, [0], 5]]], False, True,
                  'Collapsing direct state and counter to the scalar operation proves 0=1.',
                  [0, 1])
    mutation_test('future_witness_must_be_rejected', direct_path,
                  [('k <= a < d', 'a < d')], false_future_witness(), False, True,
                  'The closed claim D_xy(P(y)=C(y,0,x)) is false: its true base and y=1,2 force x=0 and x=1. The forbidden witness -1 collides with the next induction eigenparameter.')
    induction = json.loads((ROOT / 'examples/equation_induction_identity.json').read_text())
    mutation_test('atomic_induction_assumption_is_used', primary,
                  [('h = [a, inst(a, 0)][len(a) % 2:]', 'h = [inst(a, 0)]')],
                  induction, True, False,
                  'This positive certificate actually uses equation induction; it is not merely a sequence of closed computations.')
    retained = json.loads((ROOT / 'examples/retained_false_base.json').read_text())
    mutation_test('retained_base_is_used', primary,
                  [('h = [a, inst(a, 0)][len(a) % 2:]', 'h = [a][len(a) % 2:]')],
                  retained, True, False,
                  'The closure Q_n(n=1) relies on its retained false base 0=1; it does not assert forall n n=1.')
    equation = [[0, 1, 0], 1]
    alias_reflexivity = [[], [], [equation, [3, 1]], [1, 1]]
    mutation_test('image_root_must_retain_zero_slot', primary,
                  [('inst(t, d=3)', 'inst(t, d=1)')], alias_reflexivity, True, False,
                  'A valid image using permanent-zero alias 1 must remain root-valid; the old image depth loses this positive proof.')

    # A short-circuit operator is not interchangeable with eager masking.
    # We record a syntax-validation counterexample, not an unproved claim
    # that this modified full checker accepts a false arithmetic sentence.
    short = load_kernel(primary, [('d % 2 * (', 'd % 2 and (')])
    opener = []
    for name, env in [('correct', scalar), ('short_circuit_mutant', short)]:
        env['k'] = 0
        try:
            value, error = env['inst']([0, 0, 0, 0]), None
        except Exception as exc:
            value, error = None, type(exc).__name__
        opener.append({'name': name, 'value': value, 'error': error})
    strict_shape = {'name': 'short_circuit_rescues_invalid_array',
                    'results': opener,
                    'passed': opener[0]['error'] is not None and opener[1]['error'] is None
                    and opener[1]['value'] == 0,
                    'scope': 'Opening/shape validation only; no false-sentence acceptance claim.'}

    special = [[0], [0, 0, 2]]
    erasure_distinction = {'packet': special,
                          'eager': Oracle(eager=True).run(special),
                          'permissive': Oracle(eager=False).run(special)}
    erasure_distinction['passed'] = (erasure_distinction['eager']['accepted']
                                    and not erasure_distinction['permissive']['accepted'])
    # Root-scalar idempotence is deliberately not assumed by the oracle.
    o = Oracle(eager=True)
    protected_value = o.formula(0, protected=1)
    try:
        o.formula(protected_value)
        reopened_rejects = False
    except Exception:
        reopened_rejects = True
    root_scalar = {'protected_formula_leaf_result': protected_value,
                   'same_scalar_at_formula_root_rejects': reopened_rejects,
                   'passed': protected_value == 0 and reopened_rejects}

    # Exercise the entire actual process boundary, including parser, output,
    # exit status, and optimized Python. In-process function loading above
    # is used only for fine-grained trace comparison and mutation controls.
    cli = []
    probes = [('induction', primary, json.dumps(induction), True),
              ('false_equation', primary, json.dumps(cases[3][1]), False),
              ('freshness_counterexample', direct_path,
               json.dumps(false_future_witness()), False),
              ('invalid_json', primary, '{not json', False),
              ('non_array_packet', primary, 'null', False)]
    for optimized in (False, True):
        for name, path, text, accepted in probes:
            command = [sys.executable] + (['-O'] if optimized else []) + [str(path)]
            run = subprocess.run(command, input=text, text=True, capture_output=True,
                                 timeout=10)
            cli.append({'name': name, 'checker': path.name, 'optimized': optimized,
                        'expected_acceptance': accepted, 'returncode': run.returncode,
                        'stdout': run.stdout.strip(), 'stderr': run.stderr,
                        'passed': run.returncode == (0 if accepted else 1)
                        and run.stdout.strip() == ('ACCEPT' if accepted else 'REJECT')
                        and not run.stderr})
    return {'boundary_cases': boundary, 'mutation_controls': mutation,
            'strict_shape_control': strict_shape,
            'eager_permissive_distinction': erasure_distinction,
            'root_scalar_nonidempotence': root_scalar, 'public_driver_checks': cli}


def main():
    (ROOT / 'examples').mkdir(exist_ok=True)
    primary = ROOT / 'checker.py'
    scalar = load_kernel(primary)
    # Full recursion changes only the successor computation opening.
    direct = load_kernel(ROOT / 'checker_direct.py')
    fixtures = [(1, HERE / 'fixtures/inherited_scalar.json'),
                (2, HERE / 'fixtures/inherited_direct.json')]
    rows = []
    examples = []
    selected = {
        '001': ('implication_nested_identity', 'Inherited encoded implication identity with nested logical binders.'),
        '006': ('encoded_implication_reflexivity', 'Inherited selector encoding of implication reflexivity.'),
        '017': ('compound_numerical_cases', 'Numerical cases with a compound, binder-containing matrix.'),
        '021': ('transport_through_existential', 'Equality transport with a paired-binder/existential template.'),
        '029': ('existential_elimination', 'Paired/existential elimination followed by closure specialization.'),
        '130': ('closure_bound_reflexivity', 'Q_x(x=x), with a genuinely bound numerical coordinate.'),
        '134': ('nested_closure_introductions', 'Nested closures; the outer variable is used beneath the inner binder.'),
        '136': ('paired_then_closure_elimination', 'Paired elimination and closure elimination at a recursor term.'),
        '137': ('transport_under_closure', 'Equality transport under a closure.'),
        '138': ('transport_under_paired_and_closure', 'Equality transport through both paired and closure binders.'),
        '139': ('equation_induction_identity', 'Q_n(I(n,0;u.Su)=n), using the atomic induction hypothesis.'),
        '140': ('induction_specialization', 'Specialize the induction identity at the closed numeral three.'),
        '141': ('retained_false_base', 'Q_n(n=1): the false base 0=1 is retained; the closure is not an unconditional universal claim.'),
        '146': ('nested_paired_allocations', 'Two paired introductions and eliminations; inherited source name mentions failed allocation, but the named-rule trace records successful eliminations.')
    }
    for width, path in fixtures:
        old = OldOracle(width)
        oracle = Oracle(width, eager=True)
        permissive = Oracle(width, eager=False)
        records = json.loads(path.read_text())['records']
        for record in records:
            original = record['packet']
            packet = lift_packet(original)
            before = old.run(original)
            expected = oracle.run(packet)
            actual = kernel_result(scalar if width == 1 else direct, packet)
            broad = permissive.run(packet)
            row = {'id': record['id'], 'name': record['name'], 'width': width,
                   'source_accepted': before['accepted'],
                   'eager_oracle': expected, 'permissive_oracle': broad,
                   'candidate': actual,
                   'agreement': expected['accepted'] == actual['accepted'],
                   'allocation_agreement': expected['final_k'] == actual['final_k'],
                   'consumption_agreement': expected['remaining'] == actual['remaining']}
            rows.append(row)
            if width == 1 and record['id'] in selected:
                name, description = selected[record['id']]
                dest = ROOT / 'examples' / (name + '.json')
                dest.write_text(json.dumps(packet, indent=2) + '\n')
                examples.append({'file': dest.name, 'description': description,
                                 'source_fixture': str(path.relative_to(ROOT)),
                                 'source_record_id': record['id'], 'source_record_name': record['name'],
                                 'packet_sha256': digest(dest), 'instruction_cells': len(packet) - 1,
                                 'rules': expected['rules'], 'accepted': actual['accepted']})
    controlled = controls(primary, scalar, direct)
    for name, description in [
        ('erased_scalar_becomes_empty_matrix',
         'Eager formula masking turns a used list image into empty truth; the decoded goal is D_xy true.'),
        ('failed_major_without_allocation',
         'A failed computation major falls through to introduction with an unused witness.'),
        ('failed_major_retains_allocation',
         'A genuinely failed major allocates one parameter; successful fallback allocates the next.')]:
        path = ROOT / 'examples' / (name + '.json')
        packet = json.loads(path.read_text())
        trace = Oracle().run(packet)
        examples.append({'file': path.name, 'description': description,
                         'source': 'New targeted certificate for this deliverable',
                         'packet_sha256': digest(path), 'instruction_cells': len(packet) - 1,
                         'rules': trace['rules'], 'accepted': trace['accepted']})
    failures = [row for row in rows if not row['agreement'] or not row['allocation_agreement'] or not row['consumption_agreement']]
    lost = [row for row in rows if row['source_accepted'] and not row['candidate']['accepted']]
    counts = {}
    for row in rows:
        if row['candidate']['accepted']:
            for key, value in row['eager_oracle']['rules'].items():
                counts[key] = counts.get(key, 0) + value
    controlled_rows = (controlled['boundary_cases'] + controlled['mutation_controls']
                       + controlled['public_driver_checks']
                       + [controlled['strict_shape_control'],
                          controlled['eager_permissive_distinction'],
                          controlled['root_scalar_nonidempotence']])
    controlled_failures = [r for r in controlled_rows if not r['passed']]
    for row in controlled['boundary_cases']:
        if row['candidate']['accepted']:
            for key, value in row['oracle']['rules'].items():
                counts[key] = counts.get(key, 0) + value
    result = {'status': 'PASS' if not failures and not lost and not controlled_failures else 'FAIL',
              'candidate': str(primary.relative_to(ROOT)), 'candidate_sha256': digest(primary),
              'direct_checker_sha256': digest(ROOT / 'checker_direct.py'),
              'independent_oracle_sha256': digest(HERE / 'oracle.py'),
              'source_fixture_sha256': {str(path.relative_to(ROOT)): digest(path) for _, path in fixtures},
              'fixture_count': len(rows), 'source_accepted': sum(r['source_accepted'] for r in rows),
              'candidate_accepted': sum(r['candidate']['accepted'] for r in rows),
              'oracle_agreement_failures': failures, 'source_positive_rejected_after_static_translation': lost,
              'named_rule_counts': counts, 'controlled_failures': controlled_failures,
              'controls': controlled, 'selected_examples': examples, 'rows': rows,
              'scope': 'Finite implementation validation and independent named-rule agreement; not a formal proof of soundness, completeness, bi-interpretability, or consistency.'}
    (ROOT / 'results/validation.json').write_text(json.dumps(result, indent=2) + '\n')
    (ROOT / 'examples/index.json').write_text(json.dumps(examples, indent=2) + '\n')
    print(json.dumps({
        'status': result['status'], 'inherited_positive_fixtures': len(rows),
        'translated_fixtures_accepted': result['candidate_accepted'],
        'oracle_trace_disagreements': len(failures), 'lost_positive_fixtures': len(lost),
        'boundary_cases': len(controlled['boundary_cases']),
        'mutation_controls': len(controlled['mutation_controls']),
        'driver_checks': len(controlled['public_driver_checks']),
        'extra_raw_syntax_diagnostics': 3, 'controlled_failures': controlled_failures,
        'named_rule_counts': counts, 'example_files': len(examples)
    }, indent=2))
    if result['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
