iPRA BY INDUCTION FROM ONE
Research package for Vladimir Reshetnikov -- 3 November 2026
===========================================================

READING ORDER
1. report.pdf: complete paper, proofs, source comparison, and limitations.
2. AXIOMS.txt: exact standalone specification and theorem statements.
3. draft_audit.csv and source_manifest.json: pinned comparison evidence.

MAIN RESULT
The recommended conventional first-order theory has genuine intuitionistic
logic, 0 and S, one fixed separation sentence, all initialized recursion
equations, and one equation-indexed induction schema:
  [E(1) AND forall x(E(x)->E(Sx))] -> forall x(x=0 OR E(x)).
It is whole-carrier bi-interpretable and equiconsistent with full first-order
iPRA with quantifier-free induction. The report supplies both identity
round trips, including the internal recursion-uniqueness argument.

The guarded form saves exactly five ordinary formula-tree nodes per
equation-closure instance. A separate theorem proves that one exceptional
initial numeral is least sufficient in the explicit finite-exception family.
No absolute cognitive or encoding-independent global minimum is claimed.

CONTENTS
report.tex              Complete self-contained LaTeX source.
report.pdf              Compiled 14-page report (page count may change on rebuild).
AXIOMS.txt              Complete arithmetic specification.
verify.py               Python standard-library finite diagnostics.
verification.txt        Recorded output of the diagnostics.
source_manifest.json    Commit, source paths, sizes, Git blobs, SHA-256 hashes.
draft_audit.csv         Historical and cognitive comparison of all eight packages.
Makefile                Build, verify, and clean commands.
SHA256SUMS.txt          Checksums of delivered files (excluding itself).

BUILD
Requires a normal TeX Live installation with latexmk, pdflatex, and the
packages named at the top of report.tex. No bibliography program is needed.
From this directory:
  make pdf
or directly:
  latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build report.tex
  cp build/report.pdf report.pdf

CHECK
Python 3.10 or later; no third-party Python dependencies:
  python3 verify.py
or:
  make verify

The numerical checks are finite diagnostics, not a formal verification of
the infinite schemas, all nonstandard models, or the bi-interpretations.
The general claims are proved in the paper. Source archive hashes were
verified on retrieval; the original eight packages are not duplicated here.

SOURCE COMPARISON
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 77e7fdf4a46344cc79cc9c88d78954bab1764ec5
Directory: docs/drafts (four current ZIPs), docs/drafts/archived (four ZIPs).

The other current drafts contain valid useful program optimizations, but
those do not simplify their inherited boundary-based arithmetic foundation.
The recommendation builds on equation closure, with explicit credit for
the inherited equality-reflection proof and product-obstruction ideas.
