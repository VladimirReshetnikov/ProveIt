#!/usr/bin/env python3
"""Reproducible finite diagnostics for iPRA by induction starting at one.

Run with Python 3.10 or later; only the standard library is used.

The syntax tests construct the complete formulas and count their trees.
Repeated occurrences are charged separately even when Python objects are
shared. A recursor occurrence pays its frozen description in full; active
substitution does not enter that description. Uninterpreted helper labels
in count-only examples are not claims of free numerical primitives or free
computation support.

The numerical tests are finite diagnostics of identities proved in the
report. They are not a proof-assistant formalization, a decision procedure
for arithmetic, or verification of the full bi-interpretation theorem.

Source comparison snapshot: VladimirReshetnikov/ProveIt,
77e7fdf4a46344cc79cc9c88d78954bab1764ec5.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Callable


@dataclass(frozen=True)
class Term:
    kind: str
    name: str
    arguments: tuple[Term, ...] = ()
    frozen_body: Term | None = None


@dataclass(frozen=True)
class Formula:
    kind: str
    arguments: tuple[Term | Formula, ...] = ()
    bound_variable: str | None = None


def variable(name: str) -> Term:
    return Term("variable", name)


ZERO = Term("constant", "0")
BOTTOM = Formula("bottom")


def function(name: str, *arguments: Term, body: Term | None = None) -> Term:
    return Term("application", name, arguments, body)


def successor(term: Term) -> Term:
    return function("S", term)


ONE = successor(ZERO)


def equation(left: Term, right: Term) -> Formula:
    return Formula("equation", (left, right))


def binary(kind: str, left: Formula, right: Formula) -> Formula:
    if kind not in {"and", "or", "implies"}:
        raise ValueError(f"Unsupported logical operation: {kind}")
    return Formula(kind, (left, right))


def forall(name: str, body: Formula) -> Formula:
    return Formula("forall", (body,), name)


def close(parameters: tuple[str, ...], body: Formula) -> Formula:
    for name in reversed(parameters):
        body = forall(name, body)
    return body


def size(node: Term | Formula) -> int:
    """One node per occurrence; binder names do not add another node."""
    result = 1 + sum(size(child) for child in node.arguments)
    if isinstance(node, Term) and node.frozen_body is not None:
        result += size(node.frozen_body)
    return result


def active_variables(node: Term | Formula) -> set[str]:
    if isinstance(node, Term) and node.kind == "variable":
        return {node.name}
    result: set[str] = set()
    for child in node.arguments:
        result.update(active_variables(child))
    if isinstance(node, Formula) and node.kind == "forall":
        result.discard(node.bound_variable)
    return result


def occurrences(node: Term | Formula, name: str) -> int:
    """Used on equations: count active occurrences, ignoring frozen bodies."""
    if isinstance(node, Term) and node.kind == "variable":
        return int(node.name == name)
    return sum(occurrences(child, name) for child in node.arguments)


def substitute_term(term: Term, name: str, replacement: Term) -> Term:
    if term.kind == "variable" and term.name == name:
        return replacement
    return Term(
        term.kind,
        term.name,
        tuple(substitute_term(arg, name, replacement) for arg in term.arguments),
        term.frozen_body,
    )


def substitute_equation(eq: Formula, name: str, replacement: Term) -> Formula:
    """Only an equation is substituted, before its outer binders are added."""
    if eq.kind != "equation":
        raise ValueError("Expected an equation, not a formula with binders")
    left, right = eq.arguments
    if not isinstance(left, Term) or not isinstance(right, Term):
        raise TypeError("Both sides of an equation must be terms")
    return equation(
        substitute_term(left, name, replacement),
        substitute_term(right, name, replacement),
    )


def descriptors(node: Term | Formula) -> tuple[Term, ...]:
    """Collect frozen labels at active calls, without opening those labels."""
    result: tuple[Term, ...] = ()
    if isinstance(node, Term) and node.frozen_body is not None:
        result += (node.frozen_body,)
    for child in node.arguments:
        result += descriptors(child)
    return result


def schemas(eq: Formula, name: str, parameters: tuple[str, ...]) -> dict[str, Formula]:
    x = variable(name)
    shifted = substitute_equation(eq, name, successor(x))
    at_one = substitute_equation(eq, name, ONE)
    zero_or_eq = binary("or", equation(x, ZERO), eq)
    shifted_zero_or_eq = binary("or", equation(successor(x), ZERO), shifted)
    conclusion = forall(name, zero_or_eq)

    original_z = binary(
        "implies",
        forall(name, binary("implies", zero_or_eq, shifted_zero_or_eq)),
        conclusion,
    )
    guarded_g = binary(
        "implies",
        forall(name, binary("implies", zero_or_eq, shifted)),
        conclusion,
    )
    readable_i1 = binary(
        "implies",
        binary("and", at_one, forall(name, binary("implies", eq, shifted))),
        conclusion,
    )
    return {
        "Z": close(parameters, original_z),
        "G": close(parameters, guarded_g),
        "I1": close(parameters, readable_i1),
    }


def representative_equations() -> list[tuple[str, Formula, str]]:
    x, c1, c2 = map(variable, ("x", "c1", "c2"))
    v, w = variable("v"), variable("w")
    q = lambda n, a: function("R_w", n, a, body=w)
    nested_left = function("f", x, function("g", x, c1))
    nested_right = function("h", successor(x), function("f", c2, x))
    # Local v in the frozen descriptor is distinct from the active input v.
    shadowed = function("R_Sv", v, ZERO, body=successor(v))
    return [
        ("constant", equation(ZERO, ZERO), "x"),
        ("reflexive", equation(x, x), "x"),
        ("zero test", equation(x, ZERO), "x"),
        ("successor", equation(successor(x), ZERO), "x"),
        ("two successors", equation(successor(x), successor(x)), "x"),
        ("one parameter", equation(function("f", x, c1), c1), "x"),
        ("no active x", equation(function("f", c1), function("g", c1, c2)), "x"),
        ("repeated x", equation(function("f", x, x), successor(x)), "x"),
        ("nested functions", equation(nested_left, nested_right), "x"),
        ("coverage equation", equation(successor(q(x, ZERO)), x), "x"),
        ("frozen shadowing", equation(shadowed, v), "v"),
    ]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def check_syntax() -> int:
    print("EXACT SYNTAX COUNTS")
    print("Each row is built as a complete formula tree, with 1 expanded as S(0).")
    print(f"{'equation':22} {'F':>3} {'k':>3} {'p':>3} {'Z':>5} {'G':>5} {'I1':>5}")
    count = 0
    for label, eq, name in representative_equations():
        f, k = size(eq), occurrences(eq, name)
        actual_parameters = tuple(sorted(active_variables(eq) - {name}))
        for extra in (0, 1, 3):
            parameters = actual_parameters + tuple(f"unused_{j}" for j in range(extra))
            p = len(parameters)
            formulas = schemas(eq, name, parameters)
            actual = {key: size(value) for key, value in formulas.items()}
            expected = {
                "Z": 3 * f + k + p + 17,
                "G": 3 * f + k + p + 12,
                "I1": 4 * f + 2 * k + p + 9,
            }
            require(actual == expected, f"Count mismatch for {label}: {actual} != {expected}")
            require(actual["Z"] - actual["G"] == 5, f"Five-node saving failed: {label}")
            require(actual["I1"] - actual["Z"] == f + k - 8, f"I1 comparison: {label}")
            require(all(not active_variables(tree) for tree in formulas.values()),
                    f"An unclosed variable remains in {label}")
            count += 1
            if extra == 0:
                print(f"{label:22} {f:3} {k:3} {p:3} "
                      f"{actual['Z']:5} {actual['G']:5} {actual['I1']:5}")

        for replacement in (ONE, successor(variable(name))):
            substituted = substitute_equation(eq, name, replacement)
            require(size(substituted) == f + k, f"Substitution count: {label}")
            old_descriptors, new_descriptors = descriptors(eq), descriptors(substituted)
            require(len(old_descriptors) == len(new_descriptors), f"Descriptor count: {label}")
            require(all(old is new for old, new in zip(old_descriptors, new_descriptors)),
                    f"Active substitution entered a frozen descriptor: {label}")

    separation = binary("implies", equation(ZERO, ONE), BOTTOM)
    a, n, w = map(variable, ("a", "n", "w"))
    q = lambda t: function("R_w", t, a, body=w)
    q_module = forall("a", binary("and", equation(q(ZERO), a),
                                 forall("n", equation(q(successor(n)), n))))
    require(size(BOTTOM) == 1, "Genuine falsity must cost one node")
    require(size(separation) == 6, "Separation count must be six")
    require(size(q_module) == 16, "The complete Q recursion module must cost sixteen")
    print(f"PASS: {count} schema cases, including unused parameters and frozen labels.")
    print("Verified: Z=3F+k+p+17; G=3F+k+p+12; I1=4F+2k+p+9; Z-G=5.")
    print("Support counted separately: genuine falsity=1, separation=6, complete Q module=16.")
    print("Plain f/g/h labels in count-only examples do not include numerical support axioms.")
    return count


def iterate(update: Callable[[int, int], int], counter: int, initial: int) -> int:
    if counter < 0 or initial < 0:
        raise ValueError("Numerical diagnostics use natural numbers only")
    value = initial
    for previous_counter in range(counter):
        value = update(value, previous_counter)
    return value


def q(counter: int, initial: int) -> int:
    return iterate(lambda value, previous_counter: previous_counter, counter, initial)


def predecessor(n: int) -> int:
    return q(n, 0)


def case(counter: int, at_zero: int, otherwise: int) -> int:
    return iterate(lambda value, previous_counter: otherwise, counter, at_zero)


def addition(a: int, b: int) -> int:
    return iterate(lambda value, previous_counter: value + 1, b, a)


def difference(a: int, b: int) -> int:
    return iterate(lambda value, previous_counter: predecessor(value), b, a)


def equality_bit(s: int, t: int) -> int:
    residual = difference(s + 1, t)
    error = q(residual, 1)
    return case(error, 0, 1)


def check_arithmetic(maximum: int = 12) -> int:
    inputs = range(maximum + 1)
    count = 0
    for y, n in product(inputs, repeat=2):
        residual = difference(y, n)
        require(case(n, y, y) == y, f"Selector diagonal failed at {y}, {n}")
        require(difference(y + 1, n + 1) == residual,
                f"Subtraction shift failed at {y}, {n}")
        reconstruction = case(residual, y, addition(n, residual))
        require(reconstruction == y, f"Residual reconstruction failed at {y}, {n}")
        r = difference(y + 1, n)
        require((r == 1) == (y == n), f"Residual equality test failed at {y}, {n}")
        bit = equality_bit(y, n)
        require(bit in (0, 1), f"Equality bit out of range at {y}, {n}")
        require((bit == 0) == (y == n), f"Equality reflection failed at {y}, {n}")
        require((bit == 1) == (y != n), f"Inequality reflection failed at {y}, {n}")
        count += 1
    for n in inputs:
        require(addition(0, n) == n, f"Zero-initialized addition failed at {n}")
        require(difference(0, n) == 0, f"Zero-initialized subtraction failed at {n}")
    print("\nFINITE ARITHMETIC DIAGNOSTICS")
    print(f"Inputs 0..{maximum}: {count} pairs for each reconstruction and reflection identity.")
    print("Q, predecessor, C, addition, and subtraction are evaluated by initialized iteration.")
    print("PASS: selector diagonal, subtraction shift, residual reconstruction,")
    print("      d(S(s),t)=1 iff s=t, and beta=0 iff equality / beta=1 iff inequality.")
    return count


def check_boolean_tables() -> int:
    print("\nFOUR CONNECTIVE TABLES (0=true, 1=false)")
    print("a b | and or implies")
    count = 0
    for a, b in product((0, 1), repeat=2):
        conjunction = case(a, b, 1)
        disjunction = case(a, 0, b)
        implication = case(a, b, 0)
        expected = ((a == 0) and (b == 0),
                    (a == 0) or (b == 0),
                    (a != 0) or (b == 0))
        for value, truth in zip((conjunction, disjunction, implication), expected):
            require(value in (0, 1) and ((value == 0) == truth), "Boolean reflection failed")
            count += 1
        print(f"{a} {b} |  {conjunction}   {disjunction}    {implication}")
    print("a | not")
    for a in (0, 1):
        negation = case(a, 1, 0)
        require(negation in (0, 1) and ((negation == 0) == (a != 0)),
                "Negation reflection failed")
        print(f"{a} |  {negation}")
        count += 1
    print(f"PASS: {count} connective truth-table entries; falsity has characteristic bit 1.")
    return count


def check_product_obstruction() -> None:
    zero = (0, 0)
    successor_pair = lambda point: (point[0] + 1, point[1] + 1)
    predecessor_pair = lambda point: (predecessor(point[0]), predecessor(point[1]))
    coverage_equation = lambda point: successor_pair(predecessor_pair(point)) == point
    witness = (0, 1)
    require(witness != zero, "The counterexample must be nonzero")
    require(not coverage_equation(witness), "Coverage unexpectedly holds at the witness")
    require(coverage_equation(successor_pair(zero)), "The base at one must hold")
    grid = tuple(product(range(7), repeat=2))
    for point in grid:
        require(coverage_equation(successor_pair(point)),
                f"Successor equation failed at {point}")
    print("\nPRODUCT COUNTEREXAMPLE DIAGNOSTIC")
    print(f"In coordinatewise N^2, witness {witness} is nonzero and fails S(p(x))=x.")
    print(f"The base at (1,1) holds; the successor equation passed at {len(grid)} grid inputs.")
    print("The report proves the universal successor fact and satisfaction of ALL equation")
    print("induction instances in this product. This finite script does not formalize those claims.")


def main() -> None:
    check_syntax()
    check_arithmetic()
    check_boolean_tables()
    check_product_obstruction()
    print("\nALL FINITE DIAGNOSTICS PASSED.")
    print("These checks supplement the written proofs; they are not a formal verification.")


if __name__ == "__main__":
    main()
