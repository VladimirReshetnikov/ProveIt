EXECUTABLE COMPANION: PRA AXIOMATIZATIONS
======================================

Files
-----
formula_compiler.py  Original standard-library-only Python implementation.
verification.json   JSON output from the accompanying deterministic checks.

Run from this directory with Python 3.10 or newer:

    python3 formula_compiler.py --check

To reproduce the saved report:

    python3 formula_compiler.py --check > verification.json

What is implemented
-------------------
The term AST has only variables, zero, successor, and applications of declared
functions. A declaration supplies the base and step of ordinary primitive
recursion on its first argument. Parameter names, variable scope, arities,
and backward-only function dependencies are checked. No source string is
executed and Python eval is never used.

The five recursors are p (predecessor), C (case selector), add, alpha
(countdown), and beta (overflow), with exactly the recurrences in the paper.
The zero test z(x) abbreviates the term C(x,S(0),0), so it needs no additional
declaration. In a step, n is the current recursion index and r is the preceding
value. Parameters remain fixed. The numerical interpreter evaluates these
equations with primitive-recursion loops. It does not replace alpha or beta
by max/subtraction, or replace the comparator by Python equality. Ordinary
integer arithmetic is used separately as an independent check of results.

The formula AST supports equality, negation, conjunction, disjunction,
implication, truth, and falsity. The compiler is a recursion on this finite
syntax. It emits an error term, with zero denoting truth:

    s=t       add(alpha(s,t), beta(s,t))
    not A     z(e_A)
    A and B   add(e_A,e_B)
    A or B    C(e_A,0,e_B)
    A -> B    C(e_A,e_B,0)
    true      0
    false     S(0)

Checks and their limits
-----------------------
The JSON records the actual bounds and number of assertions. Checks cover
the comparator, balance and shift identities, non-Boolean error values,
all displayed gates, a deterministic collection of compound formulas,
and pointwise encodings for the restricted induction matrices.

The intuitionistic interpretation of the finite gate checks is deliberately
limited: the numerical propositions have already been decided. Implication
is evaluated by first deciding its antecedent. This is not a claim that all
propositions of intuitionistic logic satisfy excluded middle.

The product example interprets every function coordinatewise in N x N.
At x=(0,1), the native formula x=0 or x=S(p(x)) is false, while the compiled
error term equals the product zero (0,0). The mismatch is intentional and
illustrates why equation coding cannot by itself recover native disjunction
in every model of the defining equations. Coverage holds at zero and at all
sampled successor pairs. The paper proves the universal model-theoretic
claims; the program does not test infinitely many induction instances.

These are finite executable checks, not a proof of the axiomatization
equivalence, not a trusted proof checker, and not a Lean or Rocq formalization.
In particular, the interpreter is an external metalevel program. No claim
is made that evaluating arbitrary PR program codes is uniformly primitive
recursive in the program code.
