#!/usr/bin/env python3
"""Executable companion to the classical/intuitionistic PRA axiomatization.

This file defines a small, explicitly checked primitive-recursive term language,
a syntax-only compiler of quantifier-free formulas to error terms, and bounded
computational checks.  Zero represents truth.  The evaluator executes the
displayed recurrences; it does not implement subtraction or comparison by an
arithmetic shortcut.  There is no use of Python eval or executable input text.

The checks are not a proof of induction, a first-order equivalence theorem, or
a Lean/Rocq certification.  In particular, finite truth-table calculations
concern already decidable numerical propositions, not arbitrary propositions
of intuitionistic logic.

Python 3.10 or newer; standard library only.
Run: python3 formula_compiler.py --check
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import json
from typing import Callable


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    argument: Term


@dataclass(frozen=True)
class Call:
    name: str
    arguments: tuple[Term, ...]


Term = Var | Zero | Succ | Call
ZERO = Zero()
ONE = Succ(ZERO)


def app(name: str, *arguments: Term) -> Call:
    return Call(name, arguments)


def zero_test(argument: Term) -> Term:
    """The paper's z is the term C(argument, S(0), 0), not another recursor."""
    return app("C", argument, ONE, ZERO)


@dataclass(frozen=True)
class Definition:
    """f(0, parameters)=base; f(Sn, parameters)=step[n, r=f(n, parameters)]."""

    name: str
    parameters: tuple[str, ...]
    base: Term
    step: Term


def natural_number(value: int) -> int:
    if type(value) is not int or value < 0:
        raise ValueError("The numerical interpreter accepts nonnegative integers only.")
    return value


class Kernel:
    """A well-founded list of ordinary primitive-recursion declarations."""

    def __init__(self, declarations: tuple[Definition, ...]):
        self.definitions: dict[str, Definition] = {}
        for declaration in declarations:
            if declaration.name in self.definitions:
                raise ValueError("Duplicate function name: " + declaration.name)
            names = declaration.parameters
            if len(set(names)) != len(names) or set(names) & {"n", "r"}:
                raise ValueError("Parameters must be distinct and avoid n and r.")
            self.validate(declaration.base, set(names))
            self.validate(declaration.step, set(names) | {"n", "r"})
            self.definitions[declaration.name] = declaration

    def validate(self, term: Term, allowed_variables: set[str]) -> None:
        if isinstance(term, Var):
            if term.name not in allowed_variables:
                raise ValueError("Unbound variable: " + term.name)
        elif isinstance(term, Zero):
            return
        elif isinstance(term, Succ):
            self.validate(term.argument, allowed_variables)
        elif isinstance(term, Call):
            if term.name not in self.definitions:
                raise ValueError("Unknown or forward function reference: " + term.name)
            expected = 1 + len(self.definitions[term.name].parameters)
            if len(term.arguments) != expected:
                raise ValueError("Wrong arity for " + term.name)
            for argument in term.arguments:
                self.validate(argument, allowed_variables)
        else:
            raise TypeError("Not a term AST node.")

    def value(self, term: Term, environment: dict[str, int]) -> int:
        if isinstance(term, Var):
            return natural_number(environment[term.name])
        if isinstance(term, Zero):
            return 0
        if isinstance(term, Succ):
            return self.value(term.argument, environment) + 1
        if isinstance(term, Call):
            return self.apply(term.name, tuple(self.value(a, environment)
                                               for a in term.arguments))
        raise TypeError("Not a term AST node.")

    def apply(self, name: str, arguments: tuple[int, ...]) -> int:
        declaration = self.definitions[name]
        if len(arguments) != 1 + len(declaration.parameters):
            raise ValueError("Wrong arity for " + name)
        for argument in arguments:
            natural_number(argument)
        return self._apply_checked(name, arguments)

    @lru_cache(maxsize=None)
    def _apply_checked(self, name: str, arguments: tuple[int, ...]) -> int:
        declaration = self.definitions[name]
        environment = dict(zip(declaration.parameters, arguments[1:]))
        result = self.value(declaration.base, environment)
        # This loop is exactly ordinary primitive recursion on the first input.
        # Calls in the step body refer only to earlier declarations.
        for n in range(arguments[0]):
            result = self.value(declaration.step, environment | {"n": n, "r": result})
        return result


def declarations() -> tuple[Definition, ...]:
    n, r, u, v, y = (Var(name) for name in ("n", "r", "u", "v", "y"))
    return (
        Definition("p", (), ZERO, n),
        Definition("C", ("u", "v"), u, v),
        Definition("add", ("y",), y, Succ(r)),
        Definition("alpha", ("y",), y, app("p", r)),
        Definition("beta", ("y",), ZERO,
                   app("C", app("alpha", n, y), Succ(r), r)),
    )


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Not:
    body: Formula


@dataclass(frozen=True)
class And:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Or:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Implies:
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Top:
    pass


@dataclass(frozen=True)
class Bottom:
    pass


Formula = Eq | Not | And | Or | Implies | Top | Bottom


def compile_formula(formula: Formula) -> Term:
    """Pure structural compilation: no evaluation or logical oracle is used."""
    if isinstance(formula, Eq):
        return app("add", app("alpha", formula.left, formula.right),
                   app("beta", formula.left, formula.right))
    if isinstance(formula, Not):
        return zero_test(compile_formula(formula.body))
    if isinstance(formula, And):
        return app("add", compile_formula(formula.left), compile_formula(formula.right))
    if isinstance(formula, Or):
        return app("C", compile_formula(formula.left), ZERO, compile_formula(formula.right))
    if isinstance(formula, Implies):
        return app("C", compile_formula(formula.left), compile_formula(formula.right), ZERO)
    if isinstance(formula, Top):
        return ZERO
    if isinstance(formula, Bottom):
        return ONE
    raise TypeError("Not a quantifier-free formula AST node.")


def decide_formula(formula: Formula, term_value: Callable[[Term], object]) -> bool:
    """Decide a formula in one specified decidable numerical structure.

    For implication, first decide its antecedent.  A true antecedent requires
    the consequent; a false antecedent yields a true implication.  This is
    the finite decidable-case interpretation used in the constructive proof,
    not a decision procedure for arbitrary intuitionistic propositions.
    """
    if isinstance(formula, Eq):
        return term_value(formula.left) == term_value(formula.right)
    if isinstance(formula, Not):
        return not decide_formula(formula.body, term_value)
    if isinstance(formula, And):
        return (decide_formula(formula.left, term_value)
                and decide_formula(formula.right, term_value))
    if isinstance(formula, Or):
        return (decide_formula(formula.left, term_value)
                or decide_formula(formula.right, term_value))
    if isinstance(formula, Implies):
        if decide_formula(formula.left, term_value):
            return decide_formula(formula.right, term_value)
        return True
    if isinstance(formula, Top):
        return True
    if isinstance(formula, Bottom):
        return False
    raise TypeError("Not a quantifier-free formula AST node.")


def render_term(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return "S(" + render_term(term.argument) + ")"
    if isinstance(term, Call):
        return term.name + "(" + ",".join(map(render_term, term.arguments)) + ")"
    raise TypeError("Not a term AST node.")


def formula_samples() -> list[Formula]:
    x, y = Var("x"), Var("y")
    atoms: list[Formula] = [
        Eq(x, y), Eq(x, ZERO), Eq(app("add", x, y), app("add", y, x)),
        Eq(app("alpha", x, y), ZERO), Eq(app("beta", x, y), ZERO),
        Eq(x, Succ(app("p", x))), Eq(zero_test(x), ZERO),
        Eq(app("C", x, x, y), y), Top(), Bottom(),
    ]
    result = list(atoms)
    for i, a in enumerate(atoms):
        b = atoms[(3 * i + 1) % len(atoms)]
        c = atoms[(i + 4) % len(atoms)]
        result.extend((Not(a), And(a, b), Or(a, b), Implies(a, b)))
        result.append(Implies(Or(a, Not(b)), And(c, Implies(a, b))))
    result.append(Or(Eq(x, ZERO), Eq(x, Succ(app("p", x)))))
    return result


def run_checks() -> dict[str, object]:
    kernel = Kernel(declarations())
    counts: dict[str, int] = {}

    def check(group: str, condition: bool, detail: object = None) -> None:
        if not condition:
            raise AssertionError((group, detail))
        counts[group] = counts.get(group, 0) + 1

    def val(name: str, *arguments: int) -> int:
        return kernel.apply(name, arguments)

    bound = 16
    for x in range(bound + 1):
        check("basic_recursions", val("p", x) == max(x - 1, 0), ("p", x))
        check("basic_recursions", val("C", x, 1, 0) == (1 if x == 0 else 0), ("z", x))
        check("diagonal_identities", val("alpha", x, x) == 0, x)
        check("diagonal_identities", val("beta", x, x) == 0, x)
        check("diagonal_identities", val("alpha", x, x + 1) == 1, x)
        for y in range(bound + 1):
            alpha, beta = val("alpha", x, y), val("beta", x, y)
            # Independent reference values occur only in checks, not in the evaluator.
            check("recursion_reference_values", alpha == max(y - x, 0), (x, y))
            check("recursion_reference_values", beta == max(x - y, 0), (x, y))
            check("basic_recursions", val("add", x, y) == x + y, (x, y))
            check("balance", val("add", x, alpha) == val("add", y, beta), (x, y))
            distance = val("add", alpha, beta)
            check("comparator", (distance == 0) == (x == y), (x, y))
            check("shift_identities", val("alpha", x + 1, y + 1) == alpha, (x, y))
            check("shift_identities", val("beta", x + 1, y + 1) == beta, (x, y))
            check("two_term_equation_encoding",
                  ((x + 1 == 0) or (x + 1 == y + 1)) == (x == y), (x, y))
            # Shared-left-hand-side implication encodings, in the standard model.
            check("three_term_equation_encoding", ((x != x) or (x == y)) == (x == y))
            check("three_term_disequality_encoding",
                  ((x != y) or (x == x + 1)) == (x != y))

    # Check error gates on non-Boolean error values as well as on 0 and 1.
    gate_bound = 5
    for a in range(gate_bound + 1):
        da = a == 0
        check("decidable_error_gates", (val("C", a, 1, 0) == 0) == (not da), ("not", a))
        for b in range(gate_bound + 1):
            db = b == 0
            implication = db if da else True
            check("decidable_error_gates", (val("add", a, b) == 0) == (da and db))
            check("decidable_error_gates", (val("C", a, 0, b) == 0) == (da or db))
            check("decidable_error_gates", (val("C", a, b, 0) == 0) == implication)
    check("decidable_error_gates", kernel.value(compile_formula(Top()), {}) == 0)
    check("decidable_error_gates", kernel.value(compile_formula(Bottom()), {}) != 0)

    samples = formula_samples()
    assignment_bound = 6
    for formula in samples:
        error = compile_formula(formula)
        kernel.validate(error, {"x", "y"})
        for x in range(assignment_bound + 1):
            for y in range(assignment_bound + 1):
                environment = {"x": x, "y": y}
                truth = decide_formula(formula, lambda term: kernel.value(term, environment))
                check("formula_compiler", (kernel.value(error, environment) == 0) == truth,
                      (repr(formula), environment))

    # Product operations are evaluated coordinatewise by exactly the same interpreter.
    x_term = Var("x")
    coverage = Or(Eq(x_term, ZERO), Eq(x_term, Succ(app("p", x_term))))

    def pair_value(term: Term, point: tuple[int, int]) -> tuple[int, int]:
        return tuple(kernel.value(term, {"x": coordinate}) for coordinate in point)

    point = (0, 1)
    product_native = decide_formula(coverage, lambda term: pair_value(term, point))
    product_error = pair_value(compile_formula(coverage), point)
    check("product_counterexample", product_native is False)
    check("product_counterexample", product_error == (0, 0))
    check("product_counterexample", decide_formula(coverage,
          lambda term: pair_value(term, (0, 0))) is True)
    for a in range(assignment_bound + 1):
        for b in range(assignment_bound + 1):
            check("product_successor_cases", decide_formula(coverage,
                  lambda term: pair_value(term, (a + 1, b + 1))) is True)

    example = Implies(Or(Eq(Var("x"), Var("y")), Eq(Var("x"), ZERO)),
                      Eq(Var("x"), Var("y")))
    return {
        "artifact": "PRA primitive-recursion interpreter and QF formula compiler",
        "format_version": 1,
        "status": "all finite checks passed",
        "scope": {
            "formal_proof": False,
            "proof_assistant_certification": False,
            "description": "Deterministic bounded computational checks; see the paper for proofs.",
            "intuitionistic_scope": "Truth tables use explicitly decidable numerical propositions only.",
            "evaluator": "Executes the declared base and step equations by primitive-recursion loops.",
        },
        "declarations": [
            {"name": d.name, "arity": 1 + len(d.parameters),
             "parameters": list(d.parameters), "base": render_term(d.base),
             "step": render_term(d.step)} for d in declarations()
        ],
        "bounds": {"arithmetic_inputs_inclusive": [0, bound],
                   "error_gate_inputs_inclusive": [0, gate_bound],
                   "formula_variable_inputs_inclusive": [0, assignment_bound]},
        "formula_samples": len(samples),
        "assertions_by_group": counts,
        "total_assertions": sum(counts.values()),
        "product_counterexample": {
            "structure": "N x N with componentwise primitive-recursive operations",
            "point": list(point), "zero": [0, 0], "one": [1, 1],
            "predecessor": list(pair_value(app("p", x_term), point)),
            "successor_predecessor": list(pair_value(Succ(app("p", x_term)), point)),
            "zero_test": list(pair_value(zero_test(x_term), point)),
            "native_coverage_formula": "x=0 or x=S(p(x))",
            "native_coverage_at_point": product_native,
            "compiled_error_at_point": list(product_error),
            "compiled_error_equals_product_zero": product_error == (0, 0),
            "meaning": "This mismatch records why arithmetic coding alone does not justify native disjunction in a product model.",
            "not_checked_by_finite_testing": "Satisfaction of all equation-induction instances is proved mathematically in the paper.",
        },
        "example": {
            "formula": "((x=y) or (x=0)) implies (x=y)",
            "compiled_error_term": render_term(compile_formula(example)),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true",
                        help="Run the deterministic finite checks and print their JSON report.")
    arguments = parser.parse_args()
    if not arguments.check:
        parser.error("Use --check to run the executable companion.")
    print(json.dumps(run_checks(), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
