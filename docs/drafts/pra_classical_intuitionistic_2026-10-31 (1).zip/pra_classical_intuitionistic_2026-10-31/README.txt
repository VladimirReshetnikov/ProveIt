A SMALL AXIOMATIZATION OF PRA IN CLASSICAL AND INTUITIONISTIC LOGIC
================================================================
Date: 31 October 2026

Main result
-----------
Both logics can use the same basis:

  primitive-recursion defining equations
  + 0 != S(0)
  + induction only for r(n,a)=0 OR r(n,a)=s(n,a).

The paper proves exact same-language equivalence with the corresponding
ordinary first-order PRA with quantifier-free induction. The two terms
r,s may contain arbitrary fixed numerical parameters.

Contents
--------
pra_classical_intuitionistic.pdf       Complete research paper.
pra_classical_intuitionistic.tex       Main LaTeX source.
sections/                             Three included source files.
axioms.txt                            Standalone exact specification.
sources.json                          Repository snapshot and source hashes.
artifacts/formula_compiler.py          Original executable companion.
artifacts/verification.json            Reproducible bounded-check report.
artifacts/README.txt                   Compiler documentation and limits.
Makefile                              Build and computational-check commands.
SHA256SUMS                            Checksums of the deliverable files.

Build
-----
Requires a normal TeX Live installation with pdfLaTeX, AMS packages,
Latin Modern, microtype, tcolorbox, fancyhdr, hyperref, enumitem and booktabs.

From this directory:

  make pdf

or run twice:

  pdflatex -interaction=nonstopmode -halt-on-error pra_classical_intuitionistic.tex

The source uses only local section files. No bibliography server, external
data download, shell escape, or network access is required.

Computational companion
-----------------------
Requires Python 3.10 or newer, standard library only:

  make check

or:

  python3 artifacts/formula_compiler.py --check

The delivered report records 6,132 successful bounded assertions.
The mathematical theorem is proved in the paper. These computations are
not a proof checker for the infinite axiom schemata and are not a Lean or
Rocq certification.

Provenance and scope
-------------------
The six drafts in VladimirReshetnikov/ProveIt/docs/drafts were read at commit
ffbbfd31452e7188a9e3ba62c81a3bdb64072b82. The manifest records Git blob hashes
and SHA-256 hashes of the downloaded ZIPs; the old archives themselves are
not duplicated here.

The main additions are the common two-term induction template, its fully
constructive equivalence proof, the narrowed classical three-term implication
alternative, and the Harrop obstruction explaining the logic distinction.
The countdown/balance proof builds on draft D5. Goodstein's one-premise
uniqueness rule is attributed to his original 1954 paper.

The minimality claim is restricted to connective count in the stated
equation-based induction-template design. No globally shortest theory,
new historical discovery, or minimum proof-enumerator size is claimed.
