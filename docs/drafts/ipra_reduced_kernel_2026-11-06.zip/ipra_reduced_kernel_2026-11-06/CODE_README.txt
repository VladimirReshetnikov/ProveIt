SINGLE-SUBSTITUTION iPRA KERNEL: EXECUTABLE ARTIFACTS
=================================================

The whole trusted acceptance program is checker.py. It imports only json
and sys. Python 3.10 or later and the standard library suffice; no network,
package installation, theorem prover, or external proof generator is needed.

QUICK START

  python3 checker.py certificates/reflexivity.json
  python3 checker.py certificates/induction_addition.json
  python3 reproduce.py

These commands also work with absolute script and input paths from another
working directory. The checker prints ACCEPT or REJECT and exits with status
0 or 1. A nonempty assumptions array certifies a sequent, not an unconditional
theorem. certificates/index.json records the assumption counts.

reproduce.py runs validation.py and, if the surrounding paper package includes
measure.py, runs the paper's source-size measurements as well. It does not
compile the PDF. validation.py regenerates results/validation.json and the ten
small selected certificates. The 254 proof cases are generated offline from
59 frozen source certificates, wrappers, dependent substitutions and 18 direct
cases; it is not necessary to package hundreds of redundant generated files.

The checker accepts canonical syntax only. Numerical zero is -1; nonnegative
integers are variables. Equality, guarded Pi and guarded Sigma are the three
formula constructors. The genuine-falsity spelling ["false"] is expanded into
0=S0 outside the trusted checker. The report's ordinary realization includes
an explicit bridge between genuine falsity and this equation. Omitting the
surface token from the certificate grammar does not assert that an arbitrary
positive reduct is definitionally equivalent to intuitionistic arithmetic.
See FORMAT.txt for every input record and scope convention.

UNTRUSTED COMPILERS

  python3 translate.py reference/fixtures/baseline/legacy_reflexivity_derived.json translated.json
  python3 checker.py translated.json
  python3 translate.py --backward translated.json expanded.json
  python3 reference/baseline_checker.py expanded.json

Default translation consumes the original fused K certificate format. It
checks the complete source with the frozen original checker BEFORE removing
any bridge node, translates it, then checks the complete canonical output.
Backward translation expands a canonical certificate into that original
checker, using its ordinary Sigma introduction and contextual numerical rule.
Both source and target checks are mandatory compiler operations.

For the six-record syntax with an optional ["false"] shorthand:

  python3 translate.py --canonicalize surface.json canonical.json
  python3 checker.py canonical.json

The optional surface expansion is not imported by checker.py. In particular,
the checker rejects a surface certificate that has not first been compiled.
The translator is not a general parser or elaborator for arbitrary textbook
iPRA notation. Its source language and all promised conversions are explicit.

WHAT THE VERIFICATION CHECKS

The recorded run in results/validation.json contains:

  254 accepted canonical proofs;
  254 expansions accepted by the independently implemented frozen original
      checker, with identical canonical assumptions and conclusion;
   46 adversarial candidate inputs rejected;
   30 invalid original certificates rejected before translation;
   18 command-line checks, split between ordinary and python -O execution;
    2 stored-hypothesis object-identity checks;
   91 frozen provenance hashes verified;
10000 deterministic raw-JSON mutations, with no acceptance disagreement
      against the canonical composed control.

The mutation seed is 61006. Its corpus contains 77 unwrapped source/direct
cases in a fixed order. The recorded run has 256 acceptances by both programs
and 9744 rejections by both. Mutations are fed unchanged to both canonical
checkers: a newly inserted surface ["false"] is not silently expanded.

The suite also checks that the surface control and compiler accept the
corresponding expanded falsity spelling, while the canonical kernel rejects
it directly. It verifies the exact declared transformation from the frozen
composed checker to its canonical control. These are finite checks and
independent proof replays, not a machine-checked metatheorem.

REDUCTION AND COUNTS

The new implementation uses one capture-avoiding substitution traversal for
both substitution and shifting. shift(a,0)=a terminates the mutual definition;
shifting invokes substitution only with integer-valued environments. The
accompanying report proves termination and agreement with the previous
walk-based traversal. Syntax validation is table-driven. The two removed
list guards are redundant on successful finite-JSON computations.

Exact selected checker (comments/docstrings excluded where applicable):
  3174 raw UTF-8 bytes;
  2766 normalized executable UTF-8 bytes;
   864 significant original-source Python tokens;
   872 normalized Python tokens;
   926 executable AST nodes;
    78 effective nonblank, noncomment, non-docstring source lines.

Original-source and normalized token counts differ because ast.unparse adds
parentheses in some generator and expression contexts. They are different
measurements and must not be interchanged. The full CLI and formation checks
are included in every count. The Python interpreter and standard library are
outside the common counting boundary.

The full-surface matched control is 919 normalized tokens / 974 AST nodes,
compared with 957 / 1013 for the original composed checker. The canonical
composed control is 910 / 965, compared with 872 / 926 for this candidate.
The improvement therefore does not rest solely on removing a surface
abbreviation. These are implementation-relative measurements; no absolute
shortest-program theorem is claimed.

FILES AND ATTRIBUTION

  checker.py                       Exact selected acceptance program
  translate.py                     Untrusted compiler and reverse expansion
  validation.py                    Reproducible tests and proof replay
  reproduce.py                     Offline verification entry point
  FORMAT.txt                       Complete canonical wire format
  certificates/                    Ten selected positive examples and index
  results/validation.json           Recorded reproducible outcomes
  controls/checker_surface.py       Candidate with optional surface expansion
  controls/composed_canonical.py    Exact canonical ablation of prior checker
  reference/composed_checker.py     Verbatim original composed checker
  reference/baseline_checker.py     Verbatim older independent fused checker
  reference/baseline_provenance.json Verbatim historical attribution
  reference/fixtures/               Frozen positive, stress and invalid inputs
  provenance/code_sources.json      Current snapshot, hashes and modifications

The calculus, finite numerical recursion, guarded binders, packed numerical
axiom, witness-equation Sigma introduction, original proof fixtures, and most
compiler structure are inherited from ProveIt. The immediate source is
ipra_composed_kernel_2026-11-06.zip at repository commit
36fb791c722edc2549719744c38feef74fa422fb; provenance/code_sources.json identifies
its Git blob and each original archive entry. The older checker attribution
is retained verbatim. The table-driven formation idea comes from the compact
draft. The single-substitution traversal is the present implementation change.

No file in reference/, controls/, or provenance/ is imported by checker.py.
Only the untrusted verification and compiler tools import the frozen original
checker. Large finite proofs remain subject to the host's stack/memory limits.
