"""Independent finite audit of the canonical iPRA checker.

Run:
  python3 candidate_audit.py --checker /absolute/path/checker.py

This script does not import a proof compiler, proof builder, or old checker.
Its substitution oracle converts syntax to fresh named variables, performs
ordinary free-name replacement, and converts back. Thus its replacement
operation contains no de Bruijn index arithmetic or shifting algorithm.
The tests supplement the written soundness argument; they are not a formal
verification of Python semantics or a universal completeness theorem.
"""

import argparse
from collections import Counter
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

Z = -1


def S(t):
    return ["s", t]


def R(n, a, h):
    return ["r", n, a, h]


def E(s, t):
    return ["=", s, t]


def Pi(a, b):
    return ["pi", a, b]


def Sig(a, b):
    return ["sig", a, b]


def strict_equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is list:
        return len(a) == len(b) and all(strict_equal(x, y) for x, y in zip(a, b))
    return a == b


def term(a):
    if type(a) is int:
        return a >= -1
    if type(a) is not list:
        return False
    if len(a) == 2 and a[0] == "s":
        return term(a[1])
    return len(a) == 4 and a[0] == "r" and all(term(x) for x in a[1:])


def formula(a):
    if type(a) is not list or len(a) != 3:
        return False
    if a[0] == "=":
        return term(a[1]) and term(a[2])
    return a[0] in ("pi", "sig") and formula(a[1]) and formula(a[2])


class Names:
    """Fresh-name implementation, independent of the checker traversal."""

    def __init__(self):
        self.serial = 0

    def fresh(self):
        self.serial += 1
        return "b" + str(self.serial)

    def decode(self, a, context=()):
        if type(a) is int:
            if a == -1:
                return ("zero",)
            if a < -1:
                raise ValueError("invalid number slot")
            if a < len(context):
                return ("bound", context[a])
            return ("free", a - len(context))
        if type(a) is not list:
            raise ValueError("invalid syntax")
        tag = a[0]
        if tag == "s" and len(a) == 2:
            return ("s", self.decode(a[1], context))
        if tag == "r" and len(a) == 4:
            u, v = self.fresh(), self.fresh()
            return ("r", self.decode(a[1], context), self.decode(a[2], context),
                    u, v, self.decode(a[3], (u, v, *context)))
        if tag == "=" and len(a) == 3:
            return ("=", self.decode(a[1], context), self.decode(a[2], context))
        if tag in ("pi", "sig") and len(a) == 3:
            x = self.fresh()
            return (tag, x, self.decode(a[1], (x, *context)),
                    self.decode(a[2], (x, *context)))
        raise ValueError("invalid syntax")

    def encode(self, a, context=()):
        tag = a[0]
        if tag == "zero":
            return -1
        if tag == "free":
            return len(context) + a[1]
        if tag == "bound":
            return context.index(a[1])
        if tag == "s":
            return S(self.encode(a[1], context))
        if tag == "r":
            return R(self.encode(a[1], context), self.encode(a[2], context),
                     self.encode(a[5], (a[3], a[4], *context)))
        if tag == "=":
            return E(self.encode(a[1], context), self.encode(a[2], context))
        if tag in ("pi", "sig"):
            return [tag, self.encode(a[2], (a[1], *context)),
                    self.encode(a[3], (a[1], *context))]
        raise ValueError("invalid named syntax")

    def replace(self, a, free=None, bound=None):
        tag = a[0]
        if tag == "free":
            return free(a[1]) if free is not None else a
        if tag == "bound":
            return (bound or {}).get(a[1], a)
        if tag == "zero":
            return a
        rec = lambda x: self.replace(x, free, bound)
        if tag in ("s", "="):
            return (tag, *(rec(x) for x in a[1:]))
        if tag == "r":
            return (tag, rec(a[1]), rec(a[2]), a[3], a[4], rec(a[5]))
        return (tag, a[1], rec(a[2]), rec(a[3]))


def oracle_subst(a, env, protected=0):
    names = Names()
    context = tuple(names.fresh() for _ in range(protected))
    tree = names.decode(a, context)
    result = names.replace(tree, free=lambda i: names.decode(env(i)))
    return names.encode(result, context)


def oracle_shift(a, amount=1):
    names = Names()
    tree = names.decode(a)
    result = names.replace(tree, free=lambda i: ("free", i + amount))
    return names.encode(result)


def oracle_inst(a, t):
    return oracle_subst(a, lambda i: t if i == 0 else i - 1)


def oracle_nat(a, unrestricted=False):
    names = Names()
    x, y, z = names.fresh(), names.fresh(), names.fresh()
    matrix = names.decode(a, (x,))
    base = names.replace(matrix, bound={x: ("zero",)})
    at_y = names.replace(matrix, bound={x: ("bound", y)})
    at_sy = names.replace(matrix, bound={x: ("s", ("bound", y))})
    guard = at_y if a[0] == "=" or unrestricted else base
    step = ("pi", y, guard, at_sy)
    schema = ("pi", x, ("sig", z, base, step), matrix)
    return names.encode(schema)


def oracle_rec(r):
    if r[1] == Z:
        return E(r, r[2])
    if type(r[1]) is not list or len(r[1]) != 2 or r[1][0] != "s":
        raise ValueError("recursion leaf has no numerical constructor")
    names = Names()
    u, v = names.fresh(), names.fresh()
    body = names.decode(r[3], (u, v))
    previous = names.decode(R(r[1][1], r[2], r[3]))
    counter = names.decode(r[1][1])
    value = names.replace(body, bound={u: previous, v: counter})
    return E(r, names.encode(value))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("candidate_audit_results.json"))
    args = parser.parse_args()
    checker_path = args.checker.resolve()
    initial_bytes = checker_path.read_bytes()
    digest = hashlib.sha256(initial_bytes).hexdigest()
    spec = importlib.util.spec_from_file_location("independent_audit_target", checker_path)
    kernel = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(kernel)
    checks = []
    failures = []
    certificates = []

    def record(name, category, passed, detail=None):
        item = {"name": name, "category": category, "passed": bool(passed)}
        if detail is not None:
            item["detail"] = detail
        checks.append(item)
        if not passed:
            failures.append(item)

    def equal(name, category, actual, expected):
        ok = strict_equal(actual, expected)
        record(name, category, ok, None if ok else {"actual": actual, "expected": expected})

    def accept(data):
        try:
            return kernel.check(copy.deepcopy(data)) is True
        except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
            return False

    def certificate(name, data, expected, category="certificate", cli=False):
        # All certificates in this audit are finite JSON values, not Python objects.
        json.loads(json.dumps(data, allow_nan=False))
        actual = accept(data)
        record(name, category, actual is expected,
               {"expected_accept": expected, "actual_accept": actual})
        certificates.append((name, data, expected, cli))

    nested = R(S(2), S(1), R(0, 1, R(2, 3, S(4))))
    objects = [
        Z, 0, 2, 1000003, S(1), R(0, 1, S(0)), nested,
        E(0, S(1)), E(nested, R(S(0), 2, 3)),
        Pi(E(0, 1), Sig(E(0, 2), E(R(1, 2, S(3)), 3))),
        Sig(Pi(E(0, 2), E(1, 3)), Pi(E(0, 1), E(R(2, 3, S(4)), 4))),
        Pi(Sig(E(0, 1), E(1, 3)), Sig(E(0, 2), E(4, R(2, 3, S(5))))),
    ]
    environments = [lambda i: S(i + 1),
                    lambda i: R(S(i), S(i + 2), S(2))]
    for number, obj in enumerate(objects):
        for amount in (0, 1, 2, 7):
            equal(f"shift_{number}_{amount}", "named_shift_oracle",
                  kernel.shift(obj, amount), oracle_shift(obj, amount))
        for env_number, env in enumerate(environments):
            for depth in (0, 1, 3):
                equal(f"subst_{number}_{env_number}_{depth}", "named_substitution_oracle",
                      kernel.subst(obj, env, depth), oracle_subst(obj, env, depth))
        for replacement_number, replacement in enumerate((Z, S(0), nested)):
            equal(f"inst_{number}_{replacement_number}", "named_instantiation_oracle",
                  kernel.inst(obj, replacement), oracle_inst(obj, replacement))
    record("zero_shift_returns_input", "termination_boundary", kernel.shift(nested, 0) is nested)
    equal("integer_mutual_recursion", "termination_boundary", kernel.shift(1000003, 7), 1000010)

    matrices = [
        E(0, 0), E(S(0), S(1)), E(R(0, 1, S(2)), R(S(0), 2, 3)),
        E(1000001, Z), E(Z, S(Z)),
        Pi(E(0, 0), E(1, 2)),
        Sig(E(0, 1), Pi(E(0, 2), E(R(2, 3, S(4)), 4))),
        Pi(Sig(E(0, 1), E(1, 3)), E(R(1, 2, S(4)), 3)),
    ]
    for index, matrix in enumerate(matrices):
        expected = oracle_nat(matrix)
        equal(f"nat_named_{index}", "named_numerical_schema_oracle",
              kernel.infer(["nat", matrix], []), expected)
        certificate(f"nat_valid_{index}", [[], expected, ["nat", matrix]], True,
                    cli=index in (0, 5))
        if matrix[0] != "=":
            strong = oracle_nat(matrix, unrestricted=True)
            record(f"nat_guards_distinct_{index}", "induction_boundary",
                   not strict_equal(expected, strong))
            certificate(f"reject_HA_induction_{index}", [[], strong, ["nat", matrix]],
                        False, "induction_boundary", cli=index == 5)
    certificate("reject_quantified_equation_operand",
                [[], E(Z, Z), ["nat", E(Pi(E(0, 0), E(0, 0)), Z)]],
                False, "induction_boundary")

    recursors = [R(Z, 0, S(0)), R(S(Z), S(0), S(0)),
                 R(S(0), 1, R(0, 1, S(2))),
                 R(S(S(2)), R(1, 0, S(0)), R(0, 1, R(2, 3, S(4))))]
    for index, recursor in enumerate(recursors):
        expected = oracle_rec(recursor)
        equal(f"rec_named_{index}", "named_recursion_oracle",
              kernel.infer(["rec", recursor], []), expected)
        certificate(f"rec_valid_{index}", [[], expected, ["rec", recursor]],
                    True, cli=index in (0, 3))
    for index, count in enumerate((0, 1, R(Z, Z, 0), False, -1.0, -2)):
        certificate(f"rec_bad_counter_{index}",
                    [[], E(Z, Z), ["rec", R(count, Z, 0)]], False,
                    "recursion_boundary", cli=index == 0)

    truth = E(Z, Z)
    clash = E(Z, S(Z))
    g = Pi(E(0, 1), Sig(E(0, 2), E(R(1, 2, S(3)), 3)))
    guard = E(0, S(Z))
    shifted_g = oracle_shift(g)
    certificate("pi_retains_parameter_context",
                [[g], Pi(guard, shifted_g), ["pi", guard, ["hyp", shifted_g]]],
                True, "scope_boundary", cli=True)
    certificate("pi_rejects_unshifted_context",
                [[E(0, Z)], Pi(truth, E(0, Z)),
                 ["pi", truth, ["hyp", E(0, Z)]]],
                False, "scope_boundary", cli=True)

    witness = R(S(0), 1, S(2))
    witness_equation = E(0, oracle_shift(witness))
    certificate("pair_nested_parameter_witness",
                [[], Sig(witness_equation, witness_equation),
                 ["pair", witness, ["hyp", witness_equation], ["hyp", witness_equation]]],
                True, "scope_boundary", cli=True)
    unshifted_witness_equation = E(0, witness)
    certificate("pair_rejects_unshifted_witness",
                [[], Sig(unshifted_witness_equation, unshifted_witness_equation),
                 ["pair", witness, ["hyp", unshifted_witness_equation],
                  ["hyp", unshifted_witness_equation]]], False, "scope_boundary")

    a = E(0, 1)
    b = Sig(E(0, 1), Pi(E(0, 2), E(R(1, 2, S(3)), 3)))
    principal = Pi(a, b)
    at, bt = oracle_inst(a, witness), oracle_inst(b, witness)
    certificate("pi_eliminates_nested_parameter_matrix",
                [[principal, at], bt,
                 ["use", ["hyp", principal], witness, ["hyp", at]]], True,
                "scope_boundary")

    s, t = S(0), R(Z, 1, S(0))
    equality = E(s, t)
    motive = Pi(E(0, 1), Sig(E(0, 2), E(R(1, 2, S(3)), 3)))
    fs, ft = oracle_inst(motive, s), oracle_inst(motive, t)
    certificate("equality_transports_beneath_rec_pi_sigma",
                [[equality, fs], ft,
                 ["use", ["hyp", equality], motive, ["hyp", fs]]],
                True, "scope_boundary", cli=True)
    certificate("equality_rejects_wrong_direction_premise",
                [[equality, ft], ft,
                 ["use", ["hyp", equality], motive, ["hyp", ft]]],
                False, "scope_boundary")

    principal = Sig(E(0, Z), oracle_shift(g))
    certificate("sigma_eliminates_without_parameter_escape",
                [[principal], g,
                 ["use", ["hyp", principal], g, ["hyp", oracle_shift(g)]]],
                True, "scope_boundary", cli=True)
    principal_escape = Sig(E(0, Z), E(0, Z))
    certificate("sigma_rejects_witness_escape",
                [[principal_escape], E(0, Z),
                 ["use", ["hyp", principal_escape], E(0, Z), ["hyp", E(0, Z)]]],
                False, "scope_boundary", cli=True)

    # This acceptance is intentional: lookup returns the validated stored entry,
    # not the untrusted Python-equal key. Canonical roots remain strict.
    stored = E(0, S(1))
    for index, key in enumerate((E(False, S(True)), E(0.0, S(1.0)))):
        context = [stored]
        record(f"hyp_alias_returns_stored_object_{index}", "alias_boundary",
               kernel.infer(["hyp", key], context) is stored)
        certificate(f"hyp_safe_alias_{index}", [context, stored, ["hyp", key]],
                    True, "alias_boundary", cli=index == 0)
        certificate(f"reject_alias_root_{index}", [context, key, ["hyp", key]],
                    False, "alias_boundary", cli=index == 0)
        certificate(f"reject_alias_context_{index}", [[key], stored, ["hyp", stored]],
                    False, "alias_boundary")

    malformed = [None, False, True, 0.0, -1.0, -2, "", "s", "ss", "=ss",
                 {}, {"0": "s"}, [], ["s"], ["s", Z, Z],
                 ["r", Z, Z], ["pi", truth], ["false"], [[], Z],
                 E(False, 0), E(0.0, 0), Pi(truth, 0), E(truth, Z)]
    for index, obj in enumerate(malformed):
        for sort in (False, True):
            try:
                actual = kernel.wf(obj, sort)
            except (ValueError, TypeError, IndexError, KeyError):
                actual = False
            expected = formula(obj) if sort else term(obj)
            record(f"formation_{index}_{int(sort)}", "formation_boundary",
                   actual is expected)

    # Checked premise formation must reject malformed equality motives even
    # though those motives have no explicit wf guard in the acceptance code.
    for index, annotation in enumerate(malformed):
        certificate(f"equality_bad_motive_{index}",
                    [[truth], truth,
                     ["use", ["hyp", truth], annotation, ["hyp", truth]]],
                    False, "omitted_guard_boundary", cli=index in (8, 19))
    constant_sig = Sig(truth, truth)
    for index, annotation in enumerate(malformed):
        certificate(f"sigma_bad_conclusion_{index}",
                    [[constant_sig], truth,
                     ["use", ["hyp", constant_sig], annotation, ["hyp", truth]]],
                    False, "omitted_guard_boundary")
    constant_pi = Pi(truth, truth)
    for index, bad_witness in enumerate((False, 0.0, -2, [], {}, "s", truth)):
        certificate(f"pi_bad_unused_witness_{index}",
                    [[constant_pi, truth], truth,
                     ["use", ["hyp", constant_pi], bad_witness, ["hyp", truth]]],
                    False, "formation_boundary", cli=index == 0)

    certificate("canonical_clash_assumption", [[clash], clash, ["hyp", clash]],
                True, "canonical_root_contract", cli=True)
    certificate("reject_closed_clash_by_hyp", [[], clash, ["hyp", clash]],
                False, "canonical_root_contract")
    certificate("reject_surface_false_goal", [[clash], ["false"], ["hyp", clash]],
                False, "canonical_root_contract", cli=True)
    certificate("reject_surface_false_assumption", [[["false"]], clash, ["hyp", clash]],
                False, "canonical_root_contract")
    valid = [[truth], truth, ["hyp", truth]]
    for index, envelope in enumerate((None, "abc", {}, {"a": [], "b": truth, "c": ["hyp", truth]},
                                      valid[:2], [*valid, 0], ["", truth, ["hyp", truth]])):
        certificate(f"reject_envelope_{index}", envelope, False, "canonical_root_contract")

    cli_count = 0
    with tempfile.TemporaryDirectory(prefix="ipra-independent-audit-") as temp:
        for name, data, expected, cli in certificates:
            if not cli:
                continue
            path = Path(temp) / (name + ".json")
            path.write_text(json.dumps(data, allow_nan=False), encoding="utf-8")
            for optimized in (False, True):
                command = [sys.executable, *( ["-O"] if optimized else []),
                           str(checker_path), str(path)]
                proc = subprocess.run(command, capture_output=True, text=True, timeout=15)
                ok = (proc.returncode == (0 if expected else 1)
                      and proc.stdout.strip() == ("ACCEPT" if expected else "REJECT")
                      and not proc.stderr)
                record(f"cli_{name}_{int(optimized)}", "cli_boundary", ok,
                       None if ok else {"returncode": proc.returncode,
                                        "stdout": proc.stdout, "stderr": proc.stderr})
                cli_count += 1
        malformed_json = Path(temp) / "not_json.json"
        malformed_json.write_text("[", encoding="utf-8")
        for name, arguments in (("missing_argument", []),
                                ("malformed_json", [str(malformed_json)])):
            proc = subprocess.run([sys.executable, str(checker_path), *arguments],
                                  capture_output=True, text=True, timeout=15)
            record("cli_" + name, "cli_boundary",
                   proc.returncode == 1 and proc.stdout.strip() == "REJECT" and not proc.stderr)
            cli_count += 1
    record("source_unchanged_during_audit", "source_identity",
           checker_path.read_bytes() == initial_bytes)

    result = {
        "checker_path": str(checker_path),
        "checker_sha256": digest,
        "python": platform.python_version(),
        "independence": "No compiler, proof builder, or reference checker imported; fresh named-variable oracle.",
        "counts_by_category": dict(sorted(Counter(c["category"] for c in checks).items())),
        "total_checks": len(checks),
        "certificate_cases": len(certificates),
        "expected_certificate_acceptances": sum(expected for _, _, expected, _ in certificates),
        "expected_certificate_rejections": sum(not expected for _, _, expected, _ in certificates),
        "cli_processes": cli_count,
        "all_passed": not failures,
        "failures": failures,
        "checks": checks,
        "scope": "Finite focused tests supplement the written termination, binding, formation-reflection and soundness arguments; not a proof-assistant formalization.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
