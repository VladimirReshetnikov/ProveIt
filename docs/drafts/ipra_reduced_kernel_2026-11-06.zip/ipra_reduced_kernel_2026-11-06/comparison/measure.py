"""Reproduce the complete standalone-checker comparison without importing checkers.

Usage:
  python3 measure.py
  python3 measure.py --candidate /absolute/path/to/checker.py
  python3 measure.py --repository /absolute/path/to/ProveIt

The optional repository check re-verifies all six archive Git blobs. Every run
verifies the SHA-256 of each included exact source snapshot. Measurements count
all checker code, including syntax validation, arithmetic data and the JSON CLI.
"""

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
           tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
AXES = ("significant_source_tokens", "normalized_tokens", "ast_nodes",
        "raw_bytes", "normalized_bytes", "physical_lines", "effective_lines")


class WithoutDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                d = node.body[0]
                spans.append(((d.lineno, d.col_offset),
                              (d.end_lineno, d.end_col_offset)))
    source_tokens = [
        t for t in tokenize.generate_tokens(io.StringIO(source).readline)
        if t.type not in IGNORED
        and not any(lo <= t.start and t.end <= hi for lo, hi in spans)
    ]
    executable_lines = set()
    for t in source_tokens:
        executable_lines.update(range(t.start[0], t.end[0] + 1))
    tree = WithoutDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    normalized_tokens = [
        t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
        if t.type not in IGNORED
    ]
    imports = sorted({
        alias.name.split(".")[0]
        for node in ast.walk(tree) if isinstance(node, ast.Import)
        for alias in node.names
    } | {
        (node.module or "").split(".")[0]
        for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)
    })
    return {
        "sha256": hashlib.sha256(data).hexdigest(),
        "significant_source_tokens": len(source_tokens),
        "normalized_tokens": len(normalized_tokens),
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "raw_bytes": len(data),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "physical_lines": len(source.splitlines()),
        "effective_lines": len(executable_lines),
        "token_characters": sum(len(t.string) for t in source_tokens),
        "imports": imports,
    }


def coordinate_minima(rows):
    return {
        key: {
            "value": min(r["metrics"][key] for r in rows),
            "attained_by": [r["id"] for r in rows
                            if r["metrics"][key] ==
                            min(s["metrics"][key] for s in rows)],
        }
        for key in AXES
    }


def tex_escape(value):
    return str(value).replace("_", r"\_").replace("&", r"\&")


def write_table(path, rows, primary, all_rows, candidate):
    axes = ("significant_source_tokens", "ast_nodes", "normalized_bytes",
            "raw_bytes", "effective_lines")
    lines = [r"\begin{tabular}{lrrrrr}", r"\toprule",
             r"Checker & Tokens & AST nodes & Norm. bytes & Raw bytes & Code lines \\",
             r"\midrule"]
    for kind in ("primary", "direct_variant"):
        if kind == "direct_variant":
            lines.append(r"\midrule")
        for row in rows:
            if row["kind"] == kind:
                lines.append(tex_escape(row["label"]) + " & " + " & ".join(
                    f'{row["metrics"][k]:,}' for k in axes) + r" \\")
    lines.append(r"\midrule")
    for label, minima in (("Six-primary minima", primary),
                           ("All included minima", all_rows)):
        lines.append(label + " & " + " & ".join(
            f'{minima[k]["value"]:,}' for k in axes) + r" \\")
    if candidate is not None:
        lines.append(r"\midrule")
        lines.append("New checker & " + " & ".join(
            f'{candidate["metrics"][k]:,}' for k in axes) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--repository", type=Path)
    parser.add_argument("--output-dir", type=Path, default=ROOT)
    args = parser.parse_args()
    manifest = json.loads((ROOT / "provenance.json").read_text())
    archive_checks = None
    if args.repository is not None:
        archive_checks = []
        for name, item in manifest["archives"].items():
            archive = args.repository / item["repository_path"]
            actual = subprocess.check_output(
                ["git", "hash-object", str(archive)], text=True).strip()
            expected = subprocess.check_output(
                ["git", "rev-parse", manifest["commit"] + ":" +
                 item["repository_path"]], cwd=args.repository,
                text=True).strip()
            if actual != expected or expected != item["git_blob_sha"]:
                raise ValueError("Archive Git hash mismatch: " + name)
            if hashlib.sha256(archive.read_bytes()).hexdigest() != item["sha256"]:
                raise ValueError("Archive SHA-256 mismatch: " + name)
            archive_checks.append({"archive": name, "git_blob_sha": actual,
                                   "verified": True})
    rows = []
    for item in manifest["sources"]:
        metrics = measure(ROOT / item["source_path"])
        if metrics["sha256"] != item["source_sha256"]:
            raise ValueError("Source hash mismatch: " + item["source_path"])
        if metrics["imports"] != item["standard_library_imports"]:
            raise ValueError("Import closure mismatch: " + item["source_path"])
        if item["local_dependencies"]:
            raise ValueError("Unexpected non-standalone source")
        rows.append({**item, "metrics": metrics})
    primary = coordinate_minima([r for r in rows if r["kind"] == "primary"])
    all_rows = coordinate_minima(rows)
    candidate = None
    if args.candidate is not None:
        metrics = measure(args.candidate)
        candidate = {
            "path": str(args.candidate), "metrics": metrics,
            "comparison_to_all_included_minima": {
                key: {"minimum": all_rows[key]["value"],
                      "candidate": metrics[key],
                      "at_or_below": metrics[key] <= all_rows[key]["value"],
                      "saving": all_rows[key]["value"] - metrics[key]}
                for key in AXES
            },
        }
    output = {
        "python": platform.python_version(),
        "repository": manifest["repository"], "commit": manifest["commit"],
        "counting_convention": {
            "source_tokens": "Python tokenize tokens excluding comments, layout, end marker and docstrings.",
            "normalized_tokens": "The same exclusion applied to ast.unparse of the docstring-free AST.",
            "ast_nodes": "Every node yielded by ast.walk after removing module, function and class docstrings.",
            "raw_bytes": "All exact UTF-8 source bytes, including documentation and whitespace.",
            "normalized_bytes": "UTF-8 bytes of ast.unparse(docstring-free AST), followed by one newline.",
            "physical_lines": "len(source.splitlines()), including comments and blank lines.",
            "effective_lines": "Number of original physical lines touched by significant non-docstring tokens.",
            "boundary": manifest["trust_boundary"],
        },
        "all_source_hashes_verified": True,
        "reference_import_closures_verified": True,
        "archive_verification_this_run": archive_checks,
        "sources": rows,
        "six_primary_minima": primary,
        "all_included_minima": all_rows,
        "candidate": candidate,
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "metrics.json").write_text(
        json.dumps(output, indent=2) + "\n", encoding="utf-8")
    write_table(args.output_dir / "comparison_table.tex", rows, primary,
                all_rows, candidate)
    print(json.dumps({
        "python": output["python"], "sources": len(rows),
        "all_source_hashes_verified": True,
        "archive_hashes_reverified": archive_checks is not None,
        "six_primary_minima": {k: v["value"] for k, v in primary.items()},
        "all_included_minima": {k: v["value"] for k, v in all_rows.items()},
        "candidate": candidate,
    }, indent=2))


if __name__ == "__main__":
    main()
