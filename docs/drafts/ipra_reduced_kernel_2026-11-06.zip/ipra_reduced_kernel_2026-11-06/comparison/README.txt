CURRENT-SNAPSHOT CHECKER COMPARISON
===================================

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 36fb791c722edc2549719744c38feef74fa422fb
Directory: docs/drafts

CONTENTS

sources/             Nine exact original standalone checker files.
provenance.json      Commit, archive Git blob SHA and SHA-256, exact archive
                     member paths, source SHA-256, and dependency boundaries.
measure.py           Independent source counter; does not import checkers.
metrics.json         Reproduced full source measurements.
comparison_table.tex Generated booktabs tabular for the article.

The nine sources are all SIX current primary checkers and THREE current
variants that improve a coordinate minimum of those six primary checkers.
The variants improve raw file bytes only:

  factored_sentinel.py       3430 raw bytes
  compact_kernel_1_lists.py  3441 raw bytes
  factored_witness.py        3483 raw bytes

None improves the present executable-content frontier. Over all nine
sources, the coordinatewise minima are 957 significant source tokens,
1013 executable AST nodes, 3127 normalized executable UTF-8 bytes,
3430 raw UTF-8 bytes, and 85 effective physical code lines.

SELECTION AND PROVENANCE

All source copies are exact archived bytes. At assembly, the Git blob
hash of each original ZIP was recomputed with git hash-object and compared
both with the pinned repository tree and with provenance.json. The archive
SHA-256 and exact extracted member SHA-256 were also recorded.

All primary and direct control/alternative checker sources were inspected
for a better coordinate. The three qualifying alternatives are included.
Large nested historical comparators and non-checker proof generators,
translators, tests, and build tools are not copied into this bundle.
The reports' earlier 1089-token / 1154-node benchmark belongs to an older
repository snapshot; it is not the frontier for this comparison.

REPRODUCE OFFLINE

  python3 measure.py

This verifies all nine supplied source hashes and their standard-library
import closures, then regenerates metrics.json and comparison_table.tex.
Only the Python standard library is needed. All reference checkers import
json and sys and have no local source dependency. None is executed by the
source measurement script.

Add a candidate to the table without modifying any reference source:

  python3 measure.py --candidate /absolute/path/to/new_checker.py

Optionally re-verify original archives against a local pinned repository:

  python3 measure.py --repository /absolute/path/to/ProveIt

The output JSON records whether archive verification occurred in that run.
Offline reproduction re-verifies source snapshots; the source archives are
not bundled, so their initial assembly verification is recorded separately
in provenance.json. No network access is required for either command when
the optional local repository already contains the six original ZIPs.

COUNTING CONVENTION

Every checker source file is counted in full: imports, syntax validation,
variable operations, arithmetic data and schema generation, rule checking,
public falsity representation, and JSON command-line interface. The common
Python interpreter and standard-library implementation are excluded.

Significant source tokens exclude tokenize layout/comment/end-marker tokens
and module/function/class docstrings. Normalized tokens use that same rule
after ast.unparse of the docstring-free AST. AST nodes are every ast.walk
node after removing docstrings. Raw bytes include all documentation and
whitespace. Normalized bytes are UTF-8 bytes of ast.unparse of that same AST
plus one terminating newline. Physical lines include blank and comment
lines. Effective lines count original physical lines touched by significant
non-docstring tokens. The exact source and normalized token counts are both
reported because parenthesization may change under ast.unparse.

Counts were reproduced with Python 3.12.14. ast.unparse formatting and AST
node inventories can change with Python versions; use the recorded version
when reproducing exact normalized measurements.

This is a finite, implementation-specific comparison. It does not establish
an absolute shortest-proof-checker theorem across programming languages,
runtimes, certificate representations, or alternative axiomatizations.
