"""Compile the article and build a checksum-verified source/PDF archive."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
NAME = "ipra_reduced_kernel_2026-11-06"


def compile_pdf():
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    env = os.environ.copy()
    engine = shutil.which("pdflatex")
    if engine is None:
        raise RuntimeError("Install pdflatex to rebuild report.pdf")
    probe = subprocess.run(["kpsewhich", "pdflatex.fmt"],
                           capture_output=True, text=True)
    if not probe.stdout.strip() and not (build / "pdflatex.fmt").exists():
        command = ["pdftex", "-ini", "-etex", "-no-shell-escape",
                   "-interaction=nonstopmode", "-halt-on-error",
                   "-jobname=pdflatex", "-progname=pdflatex", "pdflatex.ini"]
        with (build / "format_creation.log").open("w") as log:
            subprocess.run(command, cwd=build, stdout=log,
                           stderr=subprocess.STDOUT, check=True)
    if (build / "pdflatex.fmt").exists():
        env["TEXFORMATS"] = str(build) + os.pathsep + env.get("TEXFORMATS", "")
    command = [engine, "-no-shell-escape", "-interaction=nonstopmode",
               "-halt-on-error", "-output-directory=" + str(build), "report.tex"]
    for number in range(1, 4):
        with (build / f"pass_{number}.txt").open("w") as log:
            subprocess.run(command, cwd=ROOT, env=env, stdout=log,
                           stderr=subprocess.STDOUT, check=True)
    lines = (build / "report.log").read_text().splitlines()
    problems = [line for line in lines if any(text in line for text in
                ("Overfull", "undefined references", "undefined citations", "Rerun to get"))]
    if problems:
        raise RuntimeError("Layout or references need correction: " + " | ".join(problems))
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    result = {"compiled": True, "passes": 3, "overfull_boxes": 0,
              "unresolved_references": 0, "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
              "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest()}
    (results / "build.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


def package():
    if not (ROOT / "report.pdf").is_file():
        raise FileNotFoundError("Compile the PDF before packaging")
    ignored_directories = {"build", "qa", "__pycache__", ".git"}
    ignored_suffixes = {".zip", ".pyc", ".aux", ".log", ".out", ".toc", ".fmt"}
    paths = sorted(p for p in ROOT.rglob("*") if p.is_file()
                   and not any(c in ignored_directories for c in p.relative_to(ROOT).parts)
                   and p.suffix not in ignored_suffixes and p.name != "SHA256SUMS.txt")
    lines = [hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.relative_to(ROOT).as_posix()
             for p in paths]
    checksum = ROOT / "SHA256SUMS.txt"
    checksum.write_text("\n".join(lines) + "\n")
    archive = ROOT.parent / (NAME + ".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in [*paths, checksum]:
            info = zipfile.ZipInfo(NAME + "/" + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 6, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError("ZIP integrity failure")
        for line in lines:
            digest, name = line.split("  ", 1)
            if hashlib.sha256(z.read(NAME + "/" + name)).hexdigest() != digest:
                raise RuntimeError("Archive checksum mismatch: " + name)
    shutil.copyfile(ROOT / "report.pdf", ROOT.parent / (NAME + ".pdf"))
    print(json.dumps({"archive": archive.name, "files": len(paths) + 1,
                      "bytes": archive.stat().st_size,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf-only", action="store_true")
    parser.add_argument("--package-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        compile_pdf()
    if not args.pdf_only:
        package()
