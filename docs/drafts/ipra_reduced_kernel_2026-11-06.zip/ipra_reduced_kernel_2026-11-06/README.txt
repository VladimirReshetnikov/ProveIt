A SMALLER COMPLETE PROOF KERNEL FOR iPRA
========================================
Prepared for Vladimir Reshetnikov, 6 November 2026

START HERE

  report.pdf           Complete research article (rebuildable)
  report.tex           Main LaTeX source; includes the other .tex files
  checker.py           Entire trusted proof-checking program
  SPECIFICATION.txt    All primitive syntax, axioms, schemas and logical rules
  reproduce.py         Offline validation, independent audit and measurements

RESULT

The native calculus K presents full first-order intuitionistic primitive
recursive arithmetic, including every quantifier-free induction instance.
The article proves whole-domain bi-interpretability and equiconsistency;
its ordinary first-order realization is deductively equivalent to reference
iPRA in their common finite primitive-recursive-description signature.

K uses equality, two guarded binders, and initialized numerical recursion.
Its designated absurdity is Delta := 0=S0. The ordinary realization includes
GENUINE intuitionistic falsity and the explicit bridge Delta <-> bottom.
The complete native checker accepts canonical formulas only. This is not a
claim about a bare positive first-order reduct with unrelated falsity.

MEASURED IMPROVEMENT

The current comparison snapshot is ProveIt commit:
  36fb791c722edc2549719744c38feef74fa422fb
  https://github.com/VladimirReshetnikov/ProveIt/tree/36fb791c722edc2549719744c38feef74fa422fb/docs/drafts

The benchmark includes all SIX current primary checkers and THREE supplied
variants that improve a primary coordinate minimum. Exact originals and hashes
are included. Earlier 1089-token claims inside these drafts are not reused.

                                         New checker   Current minimum
  Significant original-source tokens            864               957
  Tokens after AST normalization                872               957
  Executable AST nodes                          926              1013
  Normalized executable UTF-8 bytes            2766              3127
  Raw UTF-8 source bytes                       3174              3430
  Effective code lines                           78                85

All validation, binding operations, schema data, inference checks, imports
and the JSON CLI are included. Python and its standard-library implementation
are held fixed for all programs. Source and normalized token counts are
different measurements: ast.unparse adds parentheses in some expressions.
Raw physical lines, including blanks, are not uniformly improved.

The new source uses one capture-avoiding substitution traversal for both
substitution and variable shifting, together with table-based formation and
two justified guard eliminations. It retains the existing mathematical core.
Matched controls isolate canonical syntax from the other reductions:

                                 Source tokens  Normalized tokens  AST
  Original composed, surface              957                957 1013
  New program, surface                    911                919  974
  Original composed, canonical            910                910  965
  New program, canonical                  864                872  926

The same-interface improvement is therefore 46 source tokens, 38 normalized
tokens, and 39 AST nodes. The result is a reproducible implementation
comparison, not an absolute shortest-checker theorem.

RUN

Python 3.10+ and the standard library are sufficient. Recorded results use
Python 3.12.14. From this directory:

  python3 checker.py certificates/reflexivity.json
  python3 reproduce.py
  python3 measure.py

The checker prints ACCEPT or REJECT. A certificate with assumptions proves
a sequent. Use an EMPTY assumptions array for an unconditional theorem.
The ten small examples and their assumption counts are listed in
certificates/index.json. FORMAT.txt gives the wire format; SPECIFICATION.txt
also states the full mathematical calculus.

To rebuild the PDF and archive, with pdflatex and the listed TeX packages:

  python3 build.py

The builder initializes a local format cache if necessary, compiles three
passes, checks overfull boxes and unresolved references, and creates a ZIP
whose members are verified against SHA256SUMS.txt. PDF metadata can differ
when rebuilt. Mathematical source counts and checker results do not depend
on the PDF build. Temporary build and Python-cache files are not packaged.

VALIDATION

The packaged offline runner reproduces:

  254 accepted canonical derivations;
  254 expansions accepted by an independently structured preserved checker;
   46 rejected adversarial candidate inputs;
   30 invalid source proofs rejected before compilation;
   18 normal/optimized Python CLI checks;
   91 frozen provenance hashes;
10000 deterministic raw-input mutations compared with the matched canonical
      composed control, with zero disagreements (256 accepts, 9744 rejects);
  363 independent audit checks, including a fresh named-variable substitution
      oracle, 101 certificate cases, and 40 additional CLI processes.

The independent audit imports no compiler, proof generator or reference
checker. Its tests address binder escape, nested recursion, retained
parameters, inappropriate quantified induction, malformed JSON, and Python
Boolean/float equality aliases.

These executions supplement the written proofs. They do not constitute a
Lean/Rocq formalization of the kernel or metatheory. The ordinary theory and
canonical calculus have explicit effective proof translations; the included
compiler handles the supplied predecessor certificate format, not arbitrary
textbook iPRA notation. Very large finite proofs can exhaust host resources.

CONTENTS

  report.pdf, *.tex             Article, complete theory and mathematical proofs
  checker.py                   Complete trusted acceptance program
  SPECIFICATION.txt, FORMAT.txt Mathematical and machine-readable conventions
  translate.py                 Untrusted forward/reverse certificate compiler
  validation.py                Original proof corpus and comparison checks
  independent_audit.py          Independent syntax, rule and boundary audit
  reproduce.py, measure.py      Reproduction and measurement entry points
  build.py                     PDF compilation and checksum-verified archive
  certificates/                Ten small canonical examples and index
  results/                     Recorded validation, audit and build outcomes
  controls/                    Matched surface/canonical implementation controls
  comparison/                  Exact current checkers, counts and provenance
  reference/                   Older checker and frozen proof fixtures
  provenance/                  Attribution and source/fixture hashes
  CODE_README.txt               Compiler commands and executable details
  SHA256SUMS.txt                Hashes of every other packaged file

ATTRIBUTION

The native recursion language, guarded binders, numerical schema, witness
introduction, equality detector and interpretation strategy are inherited
from the reviewed drafts. The paper credits those sources explicitly.
The present work reduces the complete implementation, updates the comparison
to the actual current corpus, and makes the canonical/ordinary-theory
correspondence explicit. No remote repository changes were made.
