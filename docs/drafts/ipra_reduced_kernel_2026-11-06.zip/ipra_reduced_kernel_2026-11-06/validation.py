"""Offline regression and independent-baseline cross-checks.

Test generators are adapted from the composed draft; see provenance/.

Every accepted candidate is expanded into the separately implemented,
verbatim fused K checker.  The numerical axioms and witness introductions
therefore pass through the older contextual numerical and ordinary Sigma
rules.  These finite tests are not a machine formalization of soundness.
Neither checker imports this module or the untrusted compiler.
"""

from pathlib import Path
import hashlib
import json
import subprocess
import copy
import importlib.util
import random
import tempfile
import sys

import checker as k
import translate as tr

ROOT = Path(__file__).resolve().parent
OLD = tr.old
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)
Z = k.ZERO
T = ["=", Z, Z]
F = ["=", Z, ["s", Z]]


def json_value(value):
    return json.loads(json.dumps(value))


def eq(s, t):
    return ["=", s, t]


def source_wrap(source, witness):
    """An ordinary Sigma-I wrapper, checked by the original kernel."""
    goal = OLD.freeze(source["goal"])
    principal = ("sig", OLD.shift(goal), ("=", 0, 0))
    result = {"assumptions": source["assumptions"], "goal": principal,
              "proof": ("pair", principal, witness, OLD.freeze(source["proof"]),
                        tr.old_reflexivity(witness))}
    OLD.check(result)
    return result


def direct_positive_cases():
    yield "identity", [[], ["pi", ["false"], ["false"]],
                       ["pi", ["false"], ["hyp", ["false"]]]]
    yield "derived_reflexivity", [[], eq(0, 0), tr.reflexivity(0)]
    large = 10**50
    yield "large_free_parameter", [[eq(large, Z)], eq(large, Z),
                                   ["hyp", eq(large, Z)]]
    yield "surface_bottom_conversion", [[["false"]], ["false"],
                                        ["hyp", F]]
    # A malformed lookup key can be Python-equal to a stored valid formula.
    # The checker deliberately returns that stored formula.  It must not
    # return the key; the latter would violate the formation invariant.
    yield "lookup_returns_stored_formula", [[eq(1, Z)], eq(1, Z),
                                            ["hyp", eq(True, Z)]]
    witness = ["r", ["s", 3], 4, ["r", 1, 0, ["s", 0]]]
    guard = eq(0, k.shift(witness))
    yield "witness_equation_is_available", [[], ["sig", guard, guard],
                                            ["pair", witness,
                                             ["hyp", guard], ["hyp", guard]]]

    # Obtain expected schema conclusions from derivations in original K,
    # not from the candidate's numerical generator.
    templates = [
        ("=", 0, 0),
        ("=", ("r", 0, 1, ("s", 0)), 2),
        OLD.CLASH,
        ("pi", ("=", 0, 1), ("=", 1, 2)),
        ("sig", ("=", 0, 1), ("pi", ("=", 2, 0), ("=", 3, 2))),
        ("pi", ("sig", ("=", 0, 2), ("=", 1, 3)),
         ("=", ("r", 1, 2, ("r", 1, 0, ("s", 0))), 0)),
    ]
    for context_size in (0, 2):
        context = tuple(("=", i, OLD.ZERO) for i in range(context_size))
        for i, template in enumerate(templates):
            derivation = tr.expand_numerical(template, context_size)
            expected = OLD.infer(derivation, context)
            source = {"assumptions": context, "goal": expected, "proof": derivation}
            OLD.check(json_value(source))
            yield f"numerical_schema_{i}_context_{context_size}", [
                tr.encode(context), tr.encode(expected), ["nat", tr.encode(template)]]


def negative_cases():
    g = eq(0, Z)
    yield "pi_eigenvariable_capture", [[g], ["pi", T, g],
                                       ["pi", T, ["hyp", k.shift(g)]]]
    sigma = ["sig", eq(0, Z), T]
    yield "sigma_witness_escape", [[sigma], eq(0, Z),
                                    ["use", ["hyp", sigma], eq(0, Z),
                                     ["hyp", eq(0, Z)]]]
    h = eq(["r", Z, Z, 2], Z)
    sigma_h = ["sig", h, T]
    yield "sigma_escape_beneath_recursion", [[sigma_h], h,
        ["use", ["hyp", sigma_h], h, ["hyp", h]]]
    yield "witness_capture", [[], ["sig", eq(0, 0), eq(0, 0)],
                               ["pair", 0, ["hyp", eq(0, 1)], ["hyp", eq(0, 1)]]]
    template = ["pi", T, eq(1, 0)]
    equality = eq(0, 1)
    premise = k.inst(template, 0)
    yield "transport_capture_under_pi", [[equality, premise],
        ["pi", T, eq(0, 0)], ["use", ["hyp", equality], template, ["hyp", premise]]]
    premise = k.inst(h, 0)
    yield "transport_capture_under_recursion", [[equality, premise],
        eq(["r", Z, Z, 1], Z), ["use", ["hyp", equality], h, ["hyp", premise]]]

    # Forged unrestricted induction: its claimed non-equation step guard
    # contains A(y), whereas the actual leaf supplies only A(0).
    matrix = ["pi", T, eq(1, Z)]
    base = k.inst(matrix, Z)
    successor = k.subst(matrix, lambda i: ["s", 0] if i == 0 else i)
    bad_step = ["pi", matrix, successor]
    forged = ["pi", ["sig", k.shift(base, 2), k.shift(bad_step, 2)], matrix]
    yield "forbidden_quantified_induction", [[], forged, ["nat", matrix]]

    yield "unproved_bottom", [[], ["false"], ["hyp", ["false"]]]
    yield "wrong_guard", [[["pi", F, T], T], T,
                          ["use", ["hyp", ["pi", F, T]], Z, ["hyp", T]]]
    yield "wrong_equality_source", [[equality, eq(2, 2)], eq(1, 0),
        ["use", ["hyp", equality], eq(0, 1), ["hyp", eq(2, 2)]]]
    yield "missing_hypothesis", [[T], F, ["hyp", F]]
    yield "raw_integer_hypothesis_key", [[T], T, ["hyp", 0]]
    yield "boolean_hypothesis_key", [[T], T, ["hyp", False]]

    yield "malformed_equality_template", [[T], T,
        ["use", ["hyp", T], ["=", 0], ["hyp", T]]]
    yield "string_in_equality_template", [[T], T,
        ["use", ["hyp", T], ["=", "z", "z"], ["hyp", T]]]
    yield "boolean_in_equality_template", [[eq(0, Z)], T,
        ["use", ["hyp", eq(0, Z)], eq(True, Z), ["hyp", eq(0, Z)]]]
    ss = ["sig", T, T]
    yield "string_in_sigma_conclusion", [[T, ss], T,
        ["use", ["use", ["hyp", ss], ["=", "z", "z"], ["hyp", T]],
         eq(0, Z), ["hyp", T]]]
    yield "malformed_sigma_conclusion", [[ss], T,
        ["use", ["hyp", ss], ["=", Z], ["hyp", T]]]
    yield "malformed_fresh_pi_guard", [[], ["pi", T, T],
                                       ["pi", ["=", Z], tr.reflexivity(Z)]]
    yield "formula_as_pi_witness", [[["pi", T, T], T], T,
        ["use", ["hyp", ["pi", T, T]], T, ["hyp", T]]]
    for name, witness in [("boolean", True), ("float", 0.0),
                          ("string", "x"), ("formula", T),
                          ("negative", -2), ("unknown", ["unknown"])]:
        yield f"invalid_{name}_witness", [[T], ss,
            ["pair", witness, ["hyp", T], ["hyp", T]]]
    yield "malformed_numerical_matrix", [[], T, ["nat", ["=", Z]]]
    yield "string_in_numerical_matrix", [[], T, ["nat", ["=", "z", "z"]]]

    variable_counter = ["r", 0, Z, 0]
    yield "unknown_recursion_counter", [[], eq(variable_counter, Z),
                                        ["rec", variable_counter]]
    yield "wrong_recursion_arity", [[], T, ["rec", ["r", Z, Z]]]
    yield "formula_recursion_body", [[], T, ["rec", ["r", Z, Z, T]]]
    yield "recursion_is_variable", [[], T, ["rec", 0]]
    yield "primitive_reflexivity_absent", [[], T, ["refl", Z]]
    yield "primitive_explosion_absent", [[F], T, ["abort", ["hyp", F], T]]
    yield "primitive_bridge_absent", [[F], F, ["bridge", ["hyp", F]]]

    yield "boolean_goal", [[eq(1, Z)], eq(True, Z), ["hyp", eq(1, Z)]]
    yield "floating_goal", [[eq(0, Z)], eq(0.0, Z), ["hyp", eq(0, Z)]]
    yield "boolean_assumption", [[eq(True, Z)], eq(1, Z), ["hyp", eq(1, Z)]]
    yield "negative_below_zero_token", [[eq(-2, Z)], eq(-2, Z), ["hyp", eq(-2, Z)]]
    yield "dictionary_envelope", {"assumptions": [T], "goal": T, "proof": ["hyp", T]}
    yield "extra_envelope_item", [[T], T, ["hyp", T], 0]
    yield "missing_envelope_item", [[T], T]
    yield "string_assumption_context", ["", T, tr.reflexivity(Z)]
    yield "object_assumption_context", [{}, T, tr.reflexivity(Z)]
    yield "scalar_input", 0
    yield "string_input", "abc"


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify_sources():
    """Check frozen inputs and the exact declared ablation before replay."""
    manifest = json.loads((ROOT / "provenance/code_sources.json").read_text())
    hashes = []
    for row in manifest["sources"]:
        if "sha256" in row:
            path = ROOT / row["file"]
            if hash_file(path) != row["sha256"]:
                raise AssertionError(("source hash mismatch", row["file"]))
            hashes.append(row["file"])
    for group in manifest["fixture_directories"]:
        folder = ROOT / group["local"]
        if sorted(path.name for path in folder.glob("*.json")) != sorted(
                row["name"] for row in group["files"]):
            raise AssertionError(("fixture inventory mismatch", group["local"]))
        for row in group["files"]:
            path = folder / row["name"]
            if hash_file(path) != row["sha256"]:
                raise AssertionError(("fixture hash mismatch", str(path)))
            hashes.append(str(path.relative_to(ROOT)))
    original = (ROOT / "reference/composed_checker.py").read_text()
    first = original.index("\ndef erase(")
    last = original.index("\ndef check(", first)
    canonical = (original[:first] + original[last:]).replace(
        "g, a, p = erase(data)", "g, a, p = data")
    if (ROOT / "controls/composed_canonical.py").read_text() != canonical:
        raise AssertionError("canonical comparator is not the exact declared ablation")
    return hashes


def accepted_by(module, data):
    try:
        return module.check(data) is True
    except ERRORS:
        return False


def mutation_comparison(corpus, iterations=10000):
    """Deterministic differential checks; no proof-search or soundness claim."""
    control = load_module("composed_canonical_control",
                          ROOT / "controls/composed_canonical.py")
    randomizer = random.Random(61006)
    replacements = [
        None, False, True, 0.0, 1.0, -2, -1, 0, 1, 2, 10**30,
        "", "s", "pi", "sig", "r", "=", [], {}, ["s"], ["s", False],
        ["=", -1, -1], ["r", 0, -1, 0], ["r", -1, -1, 0], ["false"],
    ]
    accepted = 0
    for iteration in range(iterations):
        document = copy.deepcopy(randomizer.choice(corpus))
        paths = []

        def visit(value, path=()):
            paths.append(path)
            if type(value) is list:
                for i, child in enumerate(value):
                    visit(child, (*path, i))

        visit(document)
        path = randomizer.choice(paths)
        replacement = copy.deepcopy(randomizer.choice(replacements))
        if not path:
            document = replacement
        else:
            target = document
            for i in path[:-1]:
                target = target[i]
            target[path[-1]] = replacement
        # Both programs receive identical raw canonical-input JSON. In
        # particular, a newly inserted ["false"] is NOT erased here.
        before = accepted_by(control, document)
        after = accepted_by(k, document)
        if before != after:
            raise AssertionError(("mutation disagreement", iteration,
                                  before, after, document))
        accepted += after
    return {"seed": 61006, "iterations": iterations,
            "source_corpus_size": len(corpus), "accepted_by_both": accepted,
            "rejected_by_both": iterations - accepted, "disagreements": 0,
            "comparison": "canonical candidate versus canonical composed control"}


EXAMPLES = {
    "reflexivity": "baseline/legacy_reflexivity_derived",
    "successor_injective": "baseline/legacy_successor_injective",
    "successor_nonzero": "baseline/legacy_successor_nonzero",
    "disjunction_elimination": "baseline/legacy_or_elimination_parameter",
    "induction_addition": "baseline/legacy_equation_induction_addition",
    "quantified_explosion": "baseline/legacy_structural_explosion_quantified_parameters",
    "recursion_transport": "baseline/transport_valid_under_rec",
    "witness_equation": "direct/witness_equation_is_available",
    "identity": "direct/identity",
    "numerical_cases": "baseline/legacy_compound_numerical_cases",
}


def main():
    hashes = verify_sources()
    positive = {}
    negative = {}
    mutation_corpus = []
    result_folder = ROOT / "results"
    result_folder.mkdir(exist_ok=True)
    example_folder = ROOT / "certificates"
    example_folder.mkdir(exist_ok=True)

    def accept(name, data, mutate=False):
        data = tr.erase(json_value(data))
        k.check(data)
        expanded = tr.backward_certificate(data)
        if tr.encode(expanded["goal"]) != data[1]:
            raise AssertionError(("expanded goal changed", name))
        if tr.encode(expanded["assumptions"]) != data[0]:
            raise AssertionError(("expanded context changed", name))
        if name in positive:
            raise AssertionError(("duplicate case", name))
        positive[name] = data
        if mutate:
            mutation_corpus.append(data)

    def reject(name, data):
        data = tr.erase(json_value(data))
        if accepted_by(k, data):
            raise AssertionError(("negative accepted", name))
        negative[name] = data

    inherited = []
    for folder in ("baseline", "stress"):
        paths = sorted((ROOT / "reference/fixtures" / folder).glob("*.json"))
        expected = 53 if folder == "baseline" else 6
        if len(paths) != expected:
            raise AssertionError(("wrong fixture count", folder, len(paths)))
        for path in paths:
            source = json.loads(path.read_text())
            accept(folder + "/" + path.stem, tr.certificate(source), mutate=True)
            inherited.append((folder + "/" + path.stem, source))
            # One and two witness binders stress local Pi/Sigma scopes,
            # induction hypotheses, and both recursor-bound positions.
            wrapped = source
            for depth, witness in enumerate((13, ("r", ("s", 2), 5,
                                                   ("r", 1, 0, ("s", 0)))), 1):
                wrapped = source_wrap(wrapped, witness)
                accept(f"wrapped_{depth}/{folder}/{path.stem}", tr.certificate(wrapped))

    for name, source in inherited:
        # A dependent substitution traverses nested recursion, logical
        # binders and local hypotheses throughout the translated proof.
        env = lambda i: ["r", ["s", i + 2], i + 5, ["r", 1, 0, ["s", 0]]]
        context = tuple(map(OLD.freeze, source["assumptions"]))
        target = [[tr.expression(a, env) for a in context],
                  tr.expression(OLD.freeze(source["goal"]), env),
                  tr.translate(OLD.freeze(source["proof"]), context, env)]
        accept("substitution/" + name, target)

    for name, data in direct_positive_cases():
        accept("direct/" + name, data, mutate=True)
    for name, data in negative_cases():
        reject(name, data)
    if (len(positive), len(negative)) != (254, 46):
        raise AssertionError(("changed fixture totals", len(positive), len(negative)))

    invalid_source_names = []
    for path in sorted((ROOT / "reference/fixtures/invalid_baseline").glob("*.json")):
        try:
            tr.certificate(json.loads(path.read_text()))
        except ERRORS:
            invalid_source_names.append(path.name)
        else:
            raise AssertionError(("invalid source survived compilation", path.name))
    # These invalid nodes would disappear in erasure. Their rejection tests
    # the source precheck, not the target checker alone.
    for name, source in [
        ("bad_bridge_erasure", {"assumptions": [("=", OLD.ZERO, OLD.ZERO)],
          "goal": OLD.FALSE, "proof": ("bridge", ("hyp", 0))}),
        ("bad_discarded_bottom_step", {"assumptions": [OLD.FALSE],
          "goal": OLD.FALSE, "proof": ("nat", OLD.FALSE, OLD.ZERO,
          ("hyp", 0), ("hyp", 99))})]:
        try:
            tr.certificate(json_value(source))
        except ERRORS:
            invalid_source_names.append(name)
        else:
            raise AssertionError(("invalid erased source survived", name))
    if len(invalid_source_names) != 30:
        raise AssertionError("changed invalid-source count")

    # The canonical interface deliberately has no ["false"] constructor.
    # The surface control and untrusted compiler both expand that spelling.
    surface = load_module("surface_control", ROOT / "controls/checker_surface.py")
    surface_document = [[["false"]], ["false"], ["hyp", ["false"]]]
    if accepted_by(k, surface_document):
        raise AssertionError("canonical kernel accepted an unexpanded surface formula")
    surface.check(surface_document)
    compiled_surface = tr.canonicalize(surface_document)
    k.check(compiled_surface)

    # Aliased hypothesis keys are permitted, but inference must return the
    # validated stored formula, not a malformed key merely equal to it.
    stored = eq(0, 1)
    for key in (eq(False, True), eq(0.0, 1.0)):
        if k.infer(["hyp", key], [stored]) is not stored:
            raise AssertionError("hypothesis lookup did not return the stored formula")

    example_index = []
    for name, case in EXAMPLES.items():
        document = positive[case]
        path = example_folder / (name + ".json")
        path.write_text(json.dumps(document, separators=(",", ":")) + "\n")
        example_index.append({"file": str(path.relative_to(ROOT)),
                              "source_case": case,
                              "assumption_count": len(document[0]),
                              "sha256": hash_file(path)})
    (example_folder / "index.json").write_text(json.dumps(example_index, indent=2) + "\n")

    cli = []
    selected_cli = [
        ("reflexivity", positive[EXAMPLES["reflexivity"]], True),
        ("induction_addition", positive[EXAMPLES["induction_addition"]], True),
        ("disjunction_elimination", positive[EXAMPLES["disjunction_elimination"]], True),
        ("successor_injective", positive[EXAMPLES["successor_injective"]], True),
        ("forbidden_quantified_induction", negative["forbidden_quantified_induction"], False),
        ("sigma_witness_escape", negative["sigma_witness_escape"], False),
        ("boolean_goal", negative["boolean_goal"], False),
        ("dictionary_envelope", negative["dictionary_envelope"], False),
        ("unexpanded_surface_falsity", surface_document, False),
    ]
    with tempfile.TemporaryDirectory(prefix="ipra_single_substitution_") as folder:
        path = Path(folder) / "certificate.json"
        for optimized in (False, True):
            for name, data, expected in selected_cli:
                path.write_text(json.dumps(data))
                command = [sys.executable, *(["-O"] if optimized else []),
                           str(ROOT / "checker.py"), str(path)]
                result = subprocess.run(command, text=True, capture_output=True, timeout=15)
                if (result.returncode != (0 if expected else 1)
                        or result.stdout.strip() != ("ACCEPT" if expected else "REJECT")):
                    raise AssertionError(("CLI mismatch", name, optimized,
                                          result.returncode, result.stdout, result.stderr))
                cli.append({"name": name, "optimized_python": optimized,
                            "accepted": expected, "exit_code": result.returncode})

    mutation = mutation_comparison(mutation_corpus)
    report = {
        "checker_sha256": hash_file(ROOT / "checker.py"),
        "baseline_sha256": hash_file(ROOT / "reference/baseline_checker.py"),
        "verified_provenance_hashes": len(hashes),
        "exact_canonical_composed_ablation_verified": True,
        "positive_acceptances": len(positive),
        "independent_original_kernel_expansions": len(positive),
        "candidate_rejections": len(negative),
        "source_compiler_rejections": len(invalid_source_names),
        "canonical_interface_surface_spelling_rejected": True,
        "surface_control_and_compiler_accept_equivalent_spelling": True,
        "stored_hypothesis_identity_checks": 2,
        "cli_checks": len(cli),
        "mutation_comparison": mutation,
        "positive_names": list(positive),
        "negative_names": list(negative),
        "invalid_source_names": invalid_source_names,
        "cli_results": cli,
        "examples": example_index,
        "all_passed": True,
        "scope": "Finite executions and independent proof replay; no formal verification or absolute minimality claim.",
    }
    (result_folder / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items()
                      if key not in ("positive_names", "negative_names", "invalid_source_names",
                                     "cli_results", "examples")}, indent=2))


if __name__ == "__main__":
    main()
