"""Untrusted, context-sensitive compiler from the supplied fused K checker.

The source certificate is checked before any erasure, and the result is
checked by checker.py.  Neither checker imports this file.  Numerical
substitutions are threaded through the whole proof: introducing an extra
witness shifts their images, whereas entering an original binder lifts
the substitution.  Formula-key hypotheses then tolerate extra assumptions.

The source checker and provenance are in reference/.  The witness-equation
construction follows the inherited witness-kernel translation, adapted to
formula keys, list syntax, sentinel zero and the packed numerical axiom.
"""

from pathlib import Path
import importlib.util
import json
import sys

import checker as new

ROOT = Path(__file__).resolve().parent
_spec = importlib.util.spec_from_file_location(
    "ipra_fused_baseline", ROOT / "reference" / "baseline_checker.py")
old = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(old)


def encode(a):
    """Encode source terms/formulas, erasing only genuine surface bottom."""
    if type(a) in (tuple, list):
        if tuple(a) == old.ZERO:
            return new.ZERO
        if tuple(a) == old.FALSE:
            return ["=", new.ZERO, ["s", new.ZERO]]
        return list(map(encode, a))
    return a


def erase(a):
    """Untrusted abbreviation expansion; the canonical kernel does not use it."""
    if a == ["false"]:
        return ["=", new.ZERO, ["s", new.ZERO]]
    return list(map(erase, a)) if type(a) is list else a


def canonicalize(document):
    """Expand the surface falsity spelling in a six-record certificate."""
    result = erase(document)
    new.check(result)
    return result


def lift(env, count=1):
    """Keep newly bound slots fixed; shift the old substitution images."""
    return lambda i: i if i < count else new.shift(env(i - count), count)


def insert(env):
    """Add a fresh target-only number (the source acquires no new slot)."""
    return lambda i: new.shift(env(i))


def expression(a, env):
    return new.subst(encode(a), env)


def reflexivity(term):
    computation = ["rec", ["r", new.ZERO, term, new.ZERO]]
    return ["use", computation, ["=", 0, new.shift(term)], computation]


def symmetry(equality, left):
    return ["use", equality, ["=", 0, new.shift(left)], reflexivity(left)]


def translate(proof, context, env=lambda i: i):
    """Translate a valid frozen source derivation under numerical env.

    Additional target hypotheses may be present; the generated proof refers
    to original hypotheses by their translated formulas.  This is used for
    witness equations and the harmless non-equation numerical-schema guard.
    """
    def sub(p):
        return translate(p, context, env)

    match proof:
        case ("hyp", i):
            return ["hyp", expression(context[i], env)]
        case ("rec", r):
            return ["rec", expression(r, env)]
        case ("bridge", p):
            return sub(p)
        case ("pi", a, q):
            extended = (*map(old.shift, context), a)
            return ["pi", expression(a, lift(env)),
                    translate(q, extended, lift(env))]
        case (("app" | "eq") as tag, p, a, q):
            scoped = lift(env) if tag == "eq" else env
            return ["use", sub(p), expression(a, scoped), sub(q)]
        case ("let", p, c, q):
            principal = old.infer(p, context)
            extended = (*map(old.shift, context), *principal[1:])
            return ["use", sub(p), expression(c, env),
                    translate(q, extended, lift(env))]
        case ("pair", a, t, p, q):
            witness = expression(t, env)
            equation = ["=", 0, new.shift(witness)]
            backwards = symmetry(["hyp", equation], 0)

            def branch(matrix, premise):
                # matrix has the existential slot 0.  Turn this into the
                # transport slot, inserting the fresh witness at slot 1.
                translated_matrix = expression(matrix, lift(env))
                template = new.subst(translated_matrix, lambda i: i + 1, 1)
                shifted_premise = translate(premise, context, insert(env))
                return ["use", backwards, template, shifted_premise]

            return ["pair", witness, branch(a[1], p), branch(a[2], q)]
        case ("nat", a, t, p, q):
            # Bottom is independent of the numerical slot.  Using its base
            # avoids the changed equation/non-equation classification.
            if a == old.FALSE:
                return sub(p)
            matrix = expression(a, lift(env))
            witness_env = insert(env)
            step_env = lift(witness_env)
            extra = (a,) if a[0] == "=" else ()
            step_context = (*map(old.shift, context), *extra)
            guard = (expression(a, step_env) if extra else
                     new.shift(expression(old.inst(a, old.ZERO), witness_env)))
            step = ["pi", guard, translate(q, step_context, step_env)]
            # The numerical axiom takes a Sigma package containing the
            # base and step.  Its witness is dummy, so each component can
            # ignore the fresh equation z=0 introduced by witness Sigma-I.
            package = ["pair", new.ZERO,
                       translate(p, context, witness_env), step]
            return ["use", ["nat", matrix], expression(t, env), package]
        case _:
            raise ValueError("unknown source proof in untrusted compiler")


def certificate(document):
    old.check(document)
    context = tuple(map(old.freeze, document["assumptions"]))
    result = [list(map(encode, context)), encode(document["goal"]),
              translate(old.freeze(document["proof"]), context)]
    new.check(result)
    return result


def decode(a):
    """Embed canonical candidate syntax in the genuine-falsity baseline.

    An encoded bottom stays the equation 0=S0.  The baseline's bridge
    proves it equivalent to genuine bottom; this is not a new assumption.
    """
    if type(a) is int and a == new.ZERO:
        return old.ZERO
    return tuple(map(decode, a)) if type(a) is list else a


def old_reflexivity(term):
    computation = ("rec", ("r", old.ZERO, term, old.ZERO))
    return ("eq", computation, ("=", 0, old.shift(term)), computation)


def expand_numerical(matrix, context_size):
    """Derive the complete packed axiom using the original numerical rule."""
    base = old.inst(matrix, old.ZERO)
    guard = matrix if matrix[0] == "=" else old.shift(base)
    successor = old.subst(matrix, lambda i: ("s", 0) if i == 0 else i)
    step = ("pi", guard, successor)
    package = ("sig", old.shift(base, 2), old.shift(step, 2))
    # Outer Pi binds the target x.  Eliminating its package introduces an
    # independent z and appends base and step assumptions.  The numerical
    # matrix protects its own counter slot, inserting z and x after it.
    numerical = old.walk(matrix, lambda i, d: i + d + 2, 1)
    ih = context_size + 3 if matrix[0] == "=" else context_size + 1
    successor_proof = ("app", ("hyp", context_size + 2), 0, ("hyp", ih))
    induction = ("nat", numerical, 1,
                 ("hyp", context_size + 1), successor_proof)
    return ("pi", package,
            ("let", ("hyp", context_size), matrix, induction))


def backward(proof, context):
    """Expand a valid canonical candidate derivation into original K."""
    def sub(p):
        return backward(p, context)

    match proof:
        case ["hyp", key]:
            # Match the checker exactly: return the stored formed formula,
            # never an unvalidated user key that is only Python-equal to it.
            return ("hyp", context.index(key))
        case ["rec", r]:
            return ("rec", decode(r))
        case ["nat", a]:
            return expand_numerical(decode(a), len(context))
        case ["pi", a, q]:
            extended = [*map(new.shift, context), a]
            return ("pi", decode(a), backward(q, extended))
        case ["use", p, a, q]:
            principal = new.infer(p, context)
            if principal[0] == "sig":
                extended = [*map(new.shift, context), *principal[1:]]
                return ("let", sub(p), decode(a), backward(q, extended))
            tag = "eq" if principal[0] == "=" else "app"
            return (tag, sub(p), decode(a), sub(q))
        case ["pair", t, p, q]:
            witness = decode(t)
            guard = ["=", 0, new.shift(t)]
            extended = [*map(new.shift, context), guard]
            principal = decode(new.infer(proof, context))

            def branch(r):
                # Abstract the temporary equality y=t, instantiate y=t,
                # and discharge the resulting t=t using derived reflexivity.
                universal = ("pi", decode(guard), backward(r, extended))
                return ("app", universal, witness, old_reflexivity(witness))

            return ("pair", principal, witness, branch(p), branch(q))
        case _:
            raise ValueError("unknown candidate proof in untrusted expansion")


def backward_certificate(document):
    new.check(document)
    context, goal, proof = document
    result = {"assumptions": list(map(decode, context)), "goal": decode(goal),
              "proof": backward(proof, context)}
    old.check(result)
    return result


if __name__ == "__main__":
    arguments = sys.argv[1:]
    convert = certificate
    if arguments and arguments[0] in ("--backward", "--canonicalize"):
        convert = {"--backward": backward_certificate,
                   "--canonicalize": canonicalize}[arguments.pop(0)]
    if len(arguments) not in (1, 2):
        raise SystemExit(
            "usage: translate.py [--backward|--canonicalize] INPUT.json [OUTPUT.json]")
    result = convert(json.loads(Path(arguments[0]).read_text(encoding="utf-8")))
    text = json.dumps(result, separators=(",", ":")) + "\n"
    if len(arguments) == 2:
        Path(arguments[1]).write_text(text, encoding="utf-8")
    else:
        print(text, end="")
