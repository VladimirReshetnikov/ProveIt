"""Run the offline executable checks (and paper measurements when supplied)."""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

if __name__ == "__main__":
    subprocess.run([sys.executable, str(ROOT / "validation.py")], check=True)
    subprocess.run([sys.executable, str(ROOT / "independent_audit.py"),
                    "--checker", str(ROOT / "checker.py"),
                    "--output", str(ROOT / "results/independent_audit.json")], check=True)
    measure = ROOT / "measure.py"
    if measure.is_file():
        subprocess.run([sys.executable, str(measure)], check=True)
