"""Reproduce source comparisons, controls, and LaTeX measurement fragments."""

from pathlib import Path
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("source_metrics", ROOT / "comparison/measure.py")
counter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(counter)


def main():
    subprocess.run([sys.executable, "comparison/measure.py", "--candidate", "checker.py"],
                   cwd=ROOT, check=True, capture_output=True, text=True)
    candidate = counter.measure(ROOT / "checker.py")
    names = {
        "CandidateTokens": "significant_source_tokens",
        "CandidateNormalizedTokens": "normalized_tokens",
        "CandidateAST": "ast_nodes",
        "CandidateNormalizedBytes": "normalized_bytes",
        "CandidateRawBytes": "raw_bytes",
        "CandidateLines": "effective_lines",
    }
    (ROOT / "measurements.tex").write_text("".join(
        "\\newcommand{\\" + macro + "}{" + f"{candidate[key]:,}" + "}\n"
        for macro, key in names.items()), encoding="utf-8")
    controls = [
        ("Composed, surface", "comparison/sources/composed.py"),
        ("New, surface", "controls/checker_surface.py"),
        ("Composed, canonical", "controls/composed_canonical.py"),
        ("New, canonical", "checker.py"),
    ]
    rows = [{"label": label, "path": path, "metrics": counter.measure(ROOT / path)}
            for label, path in controls]
    (ROOT / "controls/metrics.json").write_text(json.dumps(rows, indent=2) + "\n")
    keys = ("significant_source_tokens", "normalized_tokens", "ast_nodes", "normalized_bytes")
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule",
             r"Checker and interface & Source tokens & Norm. tokens & AST & Norm. bytes \\",
             r"\midrule"]
    for row in rows:
        lines.append(row["label"] + " & " + " & ".join(
            f'{row["metrics"][key]:,}' for key in keys) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (ROOT / "control_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps({"candidate": candidate, "controls": rows}, indent=2))


if __name__ == "__main__":
    main()
