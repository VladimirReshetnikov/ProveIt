"""Reproduce the fixed complete-source comparison, including every root variant."""
import csv
import hashlib
import importlib.util
import json
import platform
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location(
    "frozen_source_metric", ROOT / "comparison" / "source_measure.py")
METRIC = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(METRIC)
KEYS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def main():
    manifest = json.loads((ROOT / "comparison" / "manifest.json").read_text())
    rows = []
    for item in manifest["programs"]:
        path = ROOT / "comparison" / item["local_file"]
        result = METRIC.metrics(path)
        if result["sha256"] != item["sha256"]:
            raise ValueError("Changed frozen comparator: " + item["local_file"])
        rows.append({**item, **result})
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    core_minimum = {key: min(row["core"][key] for row in rows) for key in KEYS}
    candidates = {name: METRIC.metrics(ROOT / name)
                  for name in ("checker.py", "checker_closed.py")}
    for name, row in candidates.items():
        if not all(row[key] < minimum[key] for key in KEYS):
            raise ValueError("Candidate does not beat the current envelope: " + name)
        if not all(row["core"][key] < core_minimum[key] for key in KEYS):
            raise ValueError("Candidate core does not beat the current envelope: " + name)
    result = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "repository_commit": manifest["commit"],
        "archive_count": len(manifest["archives"]),
        "complete_root_programs": len(rows),
        "coordinatewise_minimum": minimum,
        "core_coordinatewise_minimum": core_minimum,
        "candidates": candidates,
        "programs": rows,
    }
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    (out / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    with (out / "comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, ["path", *KEYS, "sha256"], extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        for name, row in candidates.items():
            writer.writerow({"path": name, **row})
    numbers = {}
    for prefix, data in [("Min", minimum), ("Open", candidates["checker.py"]),
                         ("Closed", candidates["checker_closed.py"])]:
        for suffix, key in [("Tokens", KEYS[0]), ("Ast", KEYS[1]), ("Bytes", KEYS[2])]:
            numbers[prefix + suffix] = data[key]
    (out / "numbers.tex").write_text("".join(
        "\\newcommand{\\" + name + "}{" + str(value) + "}\n"
        for name, value in numbers.items()))
    table = ["\\begin{longtable}{p{0.57\\textwidth}rrr}",
             "\\toprule Complete root program & Tokens & AST & Bytes\\\\",
             "\\midrule\\endhead"]
    for row in rows:
        archive = row["archive"].removeprefix("ipra_").removesuffix("_2026-11-07.zip")
        label = (archive + " / " + Path(row["path"]).name).replace("_", r"\_")
        table.append(label + " & " + " & ".join(str(row[k]) for k in KEYS) + r"\\")
    table.extend(["\\midrule", "Current envelope & " + " & ".join(str(minimum[k]) for k in KEYS) + r"\\"])
    for name, row in candidates.items():
        table.append("New " + name.replace("_", r"\_") + " & " + " & ".join(str(row[k]) for k in KEYS) + r"\\")
    table.extend(["\\bottomrule", "\\end{longtable}"])
    (out / "comparison_table.tex").write_text("\n".join(table) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "programs"}, indent=2))


if __name__ == "__main__":
    main()
