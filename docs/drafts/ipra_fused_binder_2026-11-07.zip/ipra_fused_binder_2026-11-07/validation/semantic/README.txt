SEMANTIC PROOF TRANSPORT AND INDEPENDENT VALIDATION

Run from any working directory:

    python3 /path/to/package/validation/semantic/verify.py

The entry point is main().  The script has no third-party dependencies and
uses only paths relative to this package.  It invokes the actual public
checker.py and checker_closed.py with ordinary Python and with python -O.
The acceptance programs do not import any code from this directory.

WHAT IS TRANSLATED

The frozen source calculus has equations, Q and ordinary existential E.
The target has equations, Q and D_xy B = exists x Q_y B.  translate.py first
records a successful source execution and then builds a separate derivation
tree with globally fresh named variables.  It translates E_x A to
D_xy G_y N(A), where y is fresh and G is the numerical selector gate.  Gate
zero and successor proofs are constructed directly over target formulas.
Q introduction is derived using D introduction with a dummy first witness
and D elimination.  The emitter finally converts named binders to the raw
paired-coordinate syntax and omits subtrees already present as hypotheses.

The 45 original open source packets retain every free root parameter, with
a recorded dense renaming into the declared initial namespace.  Free
auxiliary parameters outside retained scopes can be specialized to zero.
These 45 packets use 589 source instruction cells and 783 target cells.

The closed group contains 43 distinct zero-specialized packets inherited
from the same 45 source theorem roots; two original packets coincide after
specialization.  Those 43 use 585 source cells and 769 target cells.  Two
additional coordinate-alias source regressions each have translated proofs;
together they use 38 source cells and 38 target cells.  Thus there are 90
transported packet checks, not 90 independent mathematical theorems.  The
open and closed groups overlap substantially.

INDEPENDENT CHECKS

named_oracle.py parses explicit named binders.  It does not use the target's
packed depth/sort value, constructor-width table, match cases or substitution
function.  It independently checks every transported proof and 166 fresh
parameter allocations.  A fixed substitution audit compares 3672 input
cases: 2110 valid and 1562 invalid, with exact agreement on valid outputs.

There are 29 focused boundary packets: eight accepted and 21 rejected.
Each is run against both public interfaces; an additional positive packet
uses an explicitly declared open parameter as an actual D witness.  These
checks overlap with the separate kernel-focused scope suite in this package.
They are regression evidence, not a proof that all malformed packets reject.

Three explicit local mutations give positive controls:

* Validating a used substitution image at insertion depth admits a witness
  captured by D's inner binder.  A 12-cell packet then proves the false
  D_xy G_y(x=p(y)), where p is predecessor.  Its ordinary reading implies
  exists x forall v (x=v).  The real checker and named oracle reject it.
* Omitting public-goal validation permits an existential eigenparameter to
  escape into the public conclusion.  The real checker rejects the packet.
* Always adding an induction hypothesis permits a supplied proof to use a
  compound Q formula as that hypothesis.  The real checker rejects this
  specific proof.  Its conclusion is itself provable by another derivation;
  this control checks the rule restriction, not inconsistency of full
  induction.

The complete suite makes 298 public CLI invocations, split between ordinary
and optimized Python.  Frozen source checksums and upstream attribution are
in provenance.json.  The source checker and 90 source packets are exact
copies of the pinned upstream archive; trace recording, semantic translation,
target oracle and controls are untrusted test tools.

OUTPUTS

    examples/translated/                 emitted and boundary certificates
    results/semantic_summary.json        aggregate counts and target hashes
    results/semantic_theorems.json       per-packet translation/oracle results
    results/semantic_boundaries.json     boundary outcomes and oracle details

These finite tests supplement the mathematical soundness and interpretation
proofs in the report.  They do not establish absolute minimality, universal
novelty, or the correctness of those metamathematical proofs by themselves.
