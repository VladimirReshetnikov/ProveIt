"""Focused public-interface and scope tests for frozen fused kernels."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
CLOSED = ROOT / 'checker_closed.py'
OPEN = ROOT / 'checker.py'
EXPECTED_HASHES = {
    'checker_closed.py': 'f9277000201ef1b1d483ac3a7d4492008e2ee17f000cd63ab9175875812ca619',
    'checker.py': '1c2f1013ad5f54305825938f3ab712b77e65c4415cbf83273b03643c3eb69fb2',
}
for checker in (CLOSED, OPEN):
    if hashlib.sha256(checker.read_bytes()).hexdigest() != EXPECTED_HASHES[checker.name]:
        raise ValueError('Changed checker: ' + checker.name)
T = [0, 0]

def D(body):
    return [body, T, T]

r0 = [0, 0, 0]
m = [r0, 0]
reflexive = [[], [], [m, [1, 0]], T]
rs = [[[[0], 0, [1]], [[0, 0, [1]]]]]
closed_cases = [
    ('recursion_zero', [[], m], True),
    ('recursion_successor', [[], *rs], True),
    ('derived_reflexivity', reflexive, True),
    ('paired_intro_constant', [[0], D(T)], True),
    ('paired_intro_used_witness', [[0], D([3, 3])], True),
    ('paired_intro_closed_recursive_witness', [[[0, 0, 1]], D([3, 3])], True),
    ('derived_closure', [[0], [D(T), None], [T]], True),
    ('old_closure_intro_removed', [[], [T]], False),
    ('false_closure', [[], [[1, 0]]], False),
    ('false_paired_binder', [[0], D([1, 0])], False),
    ('false_equality', [[], [0, [0]]], False),
    ('wrong_recursion_result', [[], [r0, [0]]], False),
    ('capture_by_positive_witness', [[1], D([3, 3])], False),
    ('undeclared_used_witness', [[-1], D([3, 3])], False),
    ('invalid_recursive_witness_base', [[[0, 1, 0]], D([3, 3])], False),
    ('invalid_recursive_witness_parameter', [[[0, 0, -1]], D([3, 3])], False),
    ('unused_witness_is_inert', [[-12345], D(T)], True),
    ('strict_witness_list_required', [None, D(T)], False),
    ('strict_witness_length_required', [[], D(T)], False),
    ('strict_single_witness', [[0, 0, 0], D(T)], False),
    ('boolean_leaf_rejected', [[0], D([False, 0])], False),
    ('float_leaf_rejected', [[0], D([0.0, 0])], False),
    ('unused_padding_validated', [[0], [T, [False, 0], T]], False),
    ('padding_cannot_reference_unbound_coordinate', [[0], [T, [5, 5], T]], False),
    ('padding_can_reference_both_bound_coordinates', [[0], [T, [1, 3], T]], True),
    ('recursion_coordinate_alias', [[0], D([4, 4])], True),
]
parameter_axiom = [[0, -1, 0], -1]
open_cases = [
    ('one_declared_parameter', [[], parameter_axiom, [None]], True),
    ('missing_parameter_declaration', [[], parameter_axiom, []], False),
    ('used_name_outside_budget', [[], [[0, -2, 0], -2], [None]], False),
    ('header_string_alias', [[], parameter_axiom, 'x'], True),
    ('header_object_alias', [[], parameter_axiom, {'x': 0}], True),
    ('header_is_not_logical_context', [[], [0, [0]], [[0, [0]]]], False),
    ('integer_header_rejected', [[], parameter_axiom, 1], False),
    ('null_header_rejected', [[], parameter_axiom, None], False),
]
rows = []
with tempfile.TemporaryDirectory(prefix='fused-scope-') as temp:
    casepath = Path(temp) / 'case.json'
    for checker, cases in ((CLOSED, closed_cases), (OPEN, open_cases)):
        for name, certificate, expected in cases:
            casepath.write_text(json.dumps(certificate))
            result = subprocess.run([sys.executable, str(checker), str(casepath)], text=True, capture_output=True, timeout=10)
            accepted = result.returncode == 0 and result.stdout.strip() == 'ACCEPT'
            row = dict(case=name, checker=checker.name, expected=expected, accepted=accepted,
                       status=result.returncode, stdout=result.stdout.strip(), certificate=certificate)
            rows.append(row)
            expected_result = (0, 'ACCEPT') if expected else (1, 'REJECT')
            if (result.returncode, result.stdout.strip()) != expected_result or result.stderr:
                raise AssertionError(row)
results = {
    'kernels': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (CLOSED, OPEN)},
    'case_count': len(rows), 'accepted_controls': sum(r['expected'] for r in rows),
    'rejected_controls': sum(not r['expected'] for r in rows), 'cases': rows,
    'claim': 'Focused finite public-interface checks, not a proof of semantic soundness.'
}
(ROOT / 'results').mkdir(exist_ok=True)
(ROOT / 'results/scope_results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({k:v for k,v in results.items() if k != 'cases'}, indent=2))
