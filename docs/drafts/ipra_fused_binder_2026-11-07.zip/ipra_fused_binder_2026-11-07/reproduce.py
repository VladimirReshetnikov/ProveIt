"""Reproduce all measurements and finite validation; optionally rebuild the PDF."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(script):
    result = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT,
                            text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
    print("PASS " + script)


def write_evidence_summary():
    data = json.loads((ROOT / "results/semantic_summary.json").read_text())
    if data["status"] != "PASS":
        raise ValueError("Semantic validation did not pass")
    text = r"""The semantic transport suite accepted all 45 original open source
packets with their free numerical parameters preserved by dense renaming.
It also accepted 43 distinct closed specializations and two coordinate-alias
regressions. These are 90 transported packet checks, not 90 independent
mathematical theorems: the closed group specializes the same original roots,
and two original roots coincide after specialization.

\begin{center}
\begin{tabular}{lrr}
\toprule
Transported corpus & Source cells & Fused cells\\
\midrule
45 original open packets & 589 & 783\\
43 distinct closed specializations & 585 & 769\\
2 alias regressions & 38 & 38\\
\bottomrule
\end{tabular}
\end{center}

The named-binder oracle independently checked every transported proof and
166 eigenparameter allocations. Its opening audit agreed with the kernel
on 3,672 cases: 2,110 valid inputs and 1,562 rejected inputs. The semantic
suite additionally tested 29 boundary packets (eight accepted controls,
21 rejecting controls), one further declared open witness, and three
deliberate local mutations. It made 298 actual public CLI invocations
across normal Python and \texttt{-O}. All passed. The separate scope
suite passed 34 public CLI cases: 13 accepted and 21 rejected. These
boundary cohorts overlap and are not summed as distinct theorems or defects.

One mutation control specifically attacks the new binder. With
\(p\) the predecessor, a 12-cell packet targets
\(\Bnd_{x,y}G_y(x=p(y))\), which has ordinary meaning
\(\exists x\,\forall v\,(x=v)\). The correct checker and named
oracle reject it; a mutant that validates a witness at its insertion
depth accepts it. The other controls detect an eigenparameter escaping
the public goal and illicit use of a compound induction hypothesis.
The latter control concerns a forbidden proof of a conclusion that is
itself provable by another derivation; it is not an inconsistency example.
"""
    expected = {
        "theorem_groups": {"declared": 43, "declared_aliases": 2, "open": 45},
        "theorem_cells": {"declared": {"source": 585, "target": 769},
                          "declared_aliases": {"source": 38, "target": 38},
                          "open": {"source": 589, "target": 783}},
        "substitution_oracle": {"invalid": 1562, "valid": 2110},
        "freshness_allocations_checked": 166,
        "public_cli_runs": 298,
        "adversarial_cases": 29,
        "positive_boundary_cases": 8,
        "negative_boundary_cases": 21,
        "extra_declared_open_positive": 1,
    }
    for key, value in expected.items():
        if data[key] != value:
            raise ValueError("Update the evidence narrative after changing cohort: " + key)
    (ROOT / "results/validation_summary.tex").write_text(text)


def main():
    run("measure.py")
    run("validation/semantic/verify.py")
    run("validation/scope/run.py")
    write_evidence_summary()
    if "--pdf" in sys.argv:
        run("build.py")
    print("All reproduction stages passed.")


if __name__ == "__main__":
    main()
