"""Build or verify a clean, checksummed delivery archive."""
import hashlib
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "MANIFEST.sha256"
IGNORED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def payload():
    return sorted(p for p in ROOT.rglob("*")
                  if p.is_file() and p != MANIFEST
                  and "__pycache__" not in p.parts
                  and p.suffix not in IGNORED_SUFFIXES
                  and not p.name.startswith("."))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    expected = {}
    for line in MANIFEST.read_text().splitlines():
        checksum, name = line.split("  ", 1)
        path = ROOT / name
        if not path.is_file() or digest(path) != checksum:
            raise ValueError("Integrity failure: " + name)
        expected[name] = checksum
    if set(expected) != {str(p.relative_to(ROOT)) for p in payload()}:
        raise ValueError("Manifest coverage differs from the package payload")
    print("Verified", len(expected), "payload files.")


def main():
    if "--verify" in sys.argv:
        verify()
        return
    paths = payload()
    MANIFEST.write_text("".join(digest(p) + "  " + str(p.relative_to(ROOT)) + "\n"
                                for p in paths))
    archive = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as stream:
        for path in sorted(paths + [MANIFEST]):
            name = ROOT.name + "/" + str(path.relative_to(ROOT))
            entry = zipfile.ZipInfo(name, date_time=(2026, 11, 7, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            stream.writestr(entry, path.read_bytes())
    with zipfile.ZipFile(archive) as stream:
        damaged = stream.testzip()
        if damaged is not None:
            raise ValueError("ZIP CRC failure: " + damaged)
    verify()
    print("Created", archive.name, "with", len(paths) + 1, "entries.")
    print("Archive SHA256", digest(archive))


if __name__ == "__main__":
    main()
