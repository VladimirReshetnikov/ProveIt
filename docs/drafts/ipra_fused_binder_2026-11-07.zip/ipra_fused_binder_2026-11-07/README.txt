A FUSED INTRODUCTION RULE FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
=======================================================================
Prepared for Vladimir Reshetnikov, 7 November 2026.

RESULT

The new binder is

    D_(x,y) B = exists x (B(x,0) -> forall y B(x,y)).

It fuses the two introduction patterns of the supplied retained-base
calculus. Closure Q remains in the measured formula grammar, but its
introduction rule is derived from D introduction, D elimination, and a
hypothesis leaf. Ordinary existence is recovered through numerical gates.
There are five primitive inference patterns and the same two initialized
primitive-recursion computation schemas.

Complete-program normalized measurements, CPython 3.12.14:

                                    Tokens   AST nodes   UTF-8 bytes
  Current 13-program envelope          444         457          1313
  checker.py, arbitrary parameters     436         454          1265
  checker_closed.py                    430         447          1246

Both programs beat every coordinate of the current envelope, including
closed-sentence comparators. The diagnostic core measures also improve:
367/378/979 and 370/382/986, against the current 381/392/1046 envelope.
The entire program, not just inference dispatch, is included in the main
claim. The frozen source metric is unchanged from the supplied corpus.

This is a calculus-level reduction relative to the six inspected archives,
not only a composition of existing serialization optimizations. It is not
a theorem of global shortestness or a claim of worldwide priority.

START HERE

  report.pdf                     Complete compiled mathematical article
  report.tex, sections/*.tex      Complete editable LaTeX sources
  checker.py                     Entire primary acceptance program
  checker_closed.py              Entire closed-sentence companion
  FORMAT.txt                     Exact syntax, instructions, and scope contract
  examples/translated/open/      45 translated source theorems with parameters
  validation/semantic/           Proof compiler, named oracle, source provenance
  validation/scope/              Separate focused kernel audit
  comparison/                   All 13 unchanged current root comparators
  results/                      Reproduced measurements and validation outcomes
  ATTRIBUTION.txt                 Inherited/new contribution boundary
  LICENSE_SOURCE.txt              Supplied MIT-0 source license

USE THE CHECKER

From this directory:

  python3 checker.py examples/translated/open/022_universal_reflexivity.json
  python3 checker_closed.py examples/translated/declared/022_universal_reflexivity.json

Each prints ACCEPT and returns exit status 0. Malformed or invalid input
prints REJECT and returns status 1. Python 3.10 or later is required for
structural pattern matching. The kernel imports only json and sys.

The primary packet ends with [goal, header], where a canonical header is
an array of n nulls declaring the numerical names -1,...,-n. Header contents
are not logical assumptions. The closed companion omits the header. Both
public interfaces always start with an empty logical assumption context.
Positive integers are bound coordinates, not arithmetic numerals.

REPRODUCE OFFLINE

  python3 reproduce.py

This recomputes complete-program measurements, verifies frozen source
hashes, recompiles all transported proof certificates, runs the independent
named-binder oracle and substitution audit, exercises capture and malformed
input cases, and runs both public interfaces under ordinary Python and -O.

  python3 reproduce.py --pdf

This also rebuilds report.pdf using pdfLaTeX and the ordinary packages
listed in report.tex. Alternatively run python3 build.py to rebuild only
the source-size measurements and paper. The compiled PDF is supplied.

  python3 package.py --verify

This verifies the delivered manifest. Run python3 package.py to refresh
the manifest and recreate the ZIP after intentionally regenerating results
or the PDF. Reproduction can change generated files and therefore their
checksums. The checkers themselves are frozen and hash-checked by validation.

EXECUTED EVIDENCE

The semantic suite passes 45 original open theorem packets, 43 distinct
closed specializations of those roots, and two alias regressions. These
are 90 transported packet checks, not 90 independent mathematical theorems.
All are also accepted by the named-binder proof oracle, which checks 166
eigenparameter allocations. A separate opening audit covers 3672 cases
(2110 valid and 1562 invalid), with exact agreement.

It further passes 29 boundary packets (8 positive and 21 negative), one
additional declared open witness, and three deliberately broken-program
controls. Its actual public CLI runs total 298 across normal and optimized
Python. The separate scope suite passes 34 public CLI cases (13 positive,
21 negative). Boundary cohorts overlap and are not added into a total of
distinct theorems or defects.

The smaller checker can require longer certificates. The 45 original
open source packets use 589 instruction cells; their fused translations
use 783. The size objective is trusted-checker source, not proof length.

MATHEMATICAL STATUS

The paper states every rule and computation schema, proves the missing
introduction rule, gives both derivation translations and internal formula
round trips, reconstructs full intuitionistic first-order logic and
quantifier-free induction, and proves ordinary whole-domain
bi-interpretability with iPRA through T_cov. Both composite isomorphisms
have graph x=y, including at nonstandard recursion counters.

A separate focused calculus uses only D as its non-equality formula
binder and stores closures as typed proof-context records. That theorem
is not presented as a smaller implemented checker; the measured program
uses the full Q,D grammar.

The metatheory is a written proof, not a Lean or Rocq formalization.
Finite implementation tests do not prove consistency. Every used numerical
witness is locally scope-checked; wholly unused witness data can be inert.
Canonical headers are arrays, although finite-length string/object aliases
are harmless and accepted. FORMAT.txt describes these interfaces exactly.

FROZEN REPOSITORY SNAPSHOT

  https://github.com/VladimirReshetnikov/ProveIt
  commit 18e3b9b4071c76fb9e817a2eb50d7b12f7246d18
  directory docs/drafts

All six downloaded archives were checked against their Git blob identities.
Archive SHA256 values and every comparator hash are in comparison/manifest.json.
No repository publication or modification is included in this delivery.
