"""Compile the paper with settled cross-references and retain the compiler log."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    subprocess.run([sys.executable, "measure.py"], cwd=ROOT, check=True,
                   stdout=subprocess.DEVNULL)
    logs = []
    for _ in range(3):
        run = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logs.append(run.stdout)
        if run.returncode:
            (ROOT / "results" / "build_log.txt").write_text("\n".join(logs))
            print(run.stdout)
            raise SystemExit(run.returncode)
    (ROOT / "results" / "build_log.txt").write_text("\n".join(logs))
    print("Built report.pdf")


if __name__ == "__main__":
    main()
