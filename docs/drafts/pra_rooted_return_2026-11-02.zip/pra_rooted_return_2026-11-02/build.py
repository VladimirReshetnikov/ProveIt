#!/usr/bin/env python3
"""Rebuild the syntax audit, PDF, and optionally the Lean kernel offline."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / "verification"


def run(command: list[str], log_name: str) -> dict:
    completed = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False,
    )
    (VERIFY / log_name).write_text(completed.stdout, encoding="utf-8")
    if completed.returncode:
        print(completed.stdout[-8000:], file=sys.stderr)
        raise RuntimeError(f"Command failed ({completed.returncode}): {command[0]}")
    return {"command": command, "exit_code": completed.returncode, "log": log_name}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", type=Path)
    parser.add_argument("--skip-pdf", action="store_true")
    args = parser.parse_args()
    VERIFY.mkdir(exist_ok=True)
    results = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "syntax": run([sys.executable, "checks/check_syntax.py"], "syntax_run.txt"),
        "lean": {"status": "not_rerun", "note": "Original checked log retained."},
    }
    if args.lean is not None:
        lean = str(args.lean.resolve())
        version = subprocess.run(
            [lean, "--version"], text=True, capture_output=True, check=True,
        ).stdout.strip()
        results["lean"] = {
            **run([lean, "formal/RootedReturn.lean"], "lean_rerun.txt"),
            "version": version,
            "sha256": hashlib.sha256(
                (ROOT / "formal/RootedReturn.lean").read_bytes()
            ).hexdigest(),
        }
    if not args.skip_pdf:
        pdflatex = shutil.which("pdflatex")
        if pdflatex is None:
            raise RuntimeError("pdflatex is required unless --skip-pdf is used.")
        passes = []
        for index in range(1, 4):
            passes.append(run(
                [pdflatex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                f"latex_pass_{index}.txt",
            ))
        final_log = (ROOT / "report.log").read_text(errors="replace")
        unresolved = [
            line for line in final_log.splitlines()
            if "undefined" in line.lower() or "Rerun to get" in line
        ]
        overfull = re.findall(r"Overfull [^\n]+", final_log)
        pdf = ROOT / "report.pdf"
        results["pdf"] = {
            "passes": passes, "bytes": pdf.stat().st_size,
            "sha256": hashlib.sha256(pdf.read_bytes()).hexdigest(),
            "unresolved_reference_warnings": unresolved,
            "overfull_boxes": overfull,
        }
    else:
        results["pdf"] = {"status": "not_rerun"}
    (VERIFY / "build_results.json").write_text(
        json.dumps(results, indent=2) + "\n", encoding="utf-8",
    )
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
