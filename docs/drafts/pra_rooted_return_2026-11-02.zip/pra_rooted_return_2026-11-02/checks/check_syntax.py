#!/usr/bin/env python3
"""Literal-tree audit of rooted-return PRA presentations.

No previous draft's checker is imported.  Terms, substitution, frozen
descriptors, formulas, and all counted templates are constructed below.
This checks syntax and exact size claims, not mathematical consistency or
bi-interpretability.  Run from any directory with Python 3.10 or later.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import argparse
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple["Term | Formula", ...] = ()
    binder: str = ""


def var(name: str) -> Term:
    return Term("var", name=name)


N, A, B, C, K, V, W = (var(s) for s in ("n", "a", "b", "c", "k", "v", "w"))
ZERO = Term("zero")


def succ(t: Term) -> Term:
    return Term("succ", (t,))


ONE = succ(ZERO)


def test(s: Term, t: Term) -> Term:
    return Term("test", (s, t))


def rec(body: Term, counter: Term, initial: Term) -> Term:
    return Term("rec", (counter, initial), body=body)


def q(counter: Term, initial: Term) -> Term:
    return rec(W, counter, initial)


def z(counter: Term, initial: Term) -> Term:
    return rec(ZERO, counter, initial)


_SIZE_CACHE: dict[tuple[int, bool], tuple[Term, int]] = {}
_OCC_CACHE: dict[tuple[int, str], tuple[Term, int]] = {}


def reset_count_caches() -> None:
    """Bound memory across independent inputs without changing any count."""
    _SIZE_CACHE.clear()
    _OCC_CACHE.clear()


def term_size(t: Term, full: bool = False) -> int:
    key = (id(t), full)
    cached = _SIZE_CACHE.get(key)
    if cached is not None:
        assert cached[0] is t
        return cached[1]
    result = 1 + sum(term_size(a, full) for a in t.args)
    if full and t.op == "rec":
        assert t.body is not None
        result += term_size(t.body, True)
    # Retain the object itself so Python cannot reuse its identity while
    # the cache entry exists.  Every occurrence still adds its full size;
    # memoizing the calculation does not introduce free descriptor sharing.
    _SIZE_CACHE[key] = (t, result)
    return result


def occ(t: Term, name: str) -> int:
    key = (id(t), name)
    cached = _OCC_CACHE.get(key)
    if cached is not None:
        assert cached[0] is t
        return cached[1]
    result = int(t.op == "var" and t.name == name) + sum(occ(a, name) for a in t.args)
    _OCC_CACHE[key] = (t, result)
    return result


def subst(t: Term, mapping: dict[str, Term]) -> Term:
    """Simultaneous active substitution; descriptor slots stay frozen."""
    if t.op == "var":
        return mapping.get(t.name, t)
    return Term(t.op, tuple(subst(a, mapping) for a in t.args), t.name, t.body)


def at(t: Term, first: Term, second: Term) -> Term:
    return subst(t, {"n": first, "a": second})


def descriptor(t: Term) -> Term:
    return at(t, V, W)


def nf(t: Term) -> Term:
    """Only strip a root Q(Sr,s); never traverse arguments or descriptors."""
    while t.op == "rec" and t.body == W and t.args[0].op == "succ":
        t = t.args[0].args[0]
    return t


def eq(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


def conj(p: Formula, r: Formula) -> Formula:
    return Formula("and", (p, r))


def disj(p: Formula, r: Formula) -> Formula:
    return Formula("or", (p, r))


def imp(p: Formula, r: Formula) -> Formula:
    return Formula("imp", (p, r))


def forall(name: str, p: Formula) -> Formula:
    return Formula("forall", (p,), name)


def exists(name: str, p: Formula) -> Formula:
    return Formula("exists", (p,), name)


BOTTOM = Formula("false")
SEPARATION = imp(eq(ZERO, ONE), BOTTOM)


def close(p: Formula) -> Formula:
    return forall("a", forall("n", p))


def witness_close(p: Formula) -> Formula:
    return forall("a", exists("b", forall("n", p)))


def formula_size(p: Formula, full: bool = False) -> int:
    return 1 + sum(
        term_size(a, full) if isinstance(a, Term) else formula_size(a, full)
        for a in p.args
    )


def quantifier_profile(p: Formula) -> tuple[int, int]:
    children = [quantifier_profile(a) for a in p.args if isinstance(a, Formula)]
    own = int(p.op in {"forall", "exists"})
    return own + sum(x[0] for x in children), own + max((x[1] for x in children), default=0)


def native_bit_matrix(true_is_one: bool = True) -> Formula:
    diagonal, off_diagonal = (ONE, ZERO) if true_is_one else (ZERO, ONE)
    return conj(eq(test(A, A), diagonal), disj(eq(A, N), eq(test(A, N), off_diagonal)))


def computation(u: Term, canonical: bool = True, right: bool = False) -> Formula:
    h = descriptor(nf(u) if canonical else u)
    base = eq(rec(h, ZERO, A), A)
    rhs = rec(h, N, at(u, A, ZERO)) if right else at(u, rec(h, N, A), N)
    return conj(base, eq(rec(h, succ(N), A), rhs))


def bound_computation(u: Term) -> Formula:
    h = descriptor(nf(u))
    base = eq(rec(h, ZERO, A), A)
    step = forall("c", imp(eq(rec(h, N, A), C), eq(rec(h, succ(N), A), at(u, C, N))))
    return conj(base, step)


def constancy(u: Term) -> Formula:
    stationary = forall("k", eq(at(u, succ(K), A), at(u, K, A)))
    return imp(stationary, eq(u, at(u, ZERO, A)))


def guarded(t: Term) -> Term:
    return z(test(N, ZERO), t)


def is_guarded(u: Term) -> bool:
    return u.op == "rec" and u.body == ZERO and u.args[0] == test(N, ZERO)


def root_short(t: Term) -> Term:
    return z(z(test(A, ZERO), test(t, ZERO)), N)


def short_root_tail(u: Term) -> Term | None:
    if not (u.op == "rec" and u.body == ZERO and u.args[1] == N):
        return None
    inner = u.args[0]
    if not (inner.op == "rec" and inner.body == ZERO and inner.args[0] == test(A, ZERO)):
        return None
    bit = inner.args[1]
    if not (bit.op == "test" and bit.args[1] == ZERO):
        return None
    return bit.args[0]


def root_long(t: Term) -> Term:
    return guarded(q(z(test(A, ZERO), succ(z(t, N))), N))


NEW_SEED = guarded(A)
OLD_GUARD_SEED = q(succ(N), A)


def rooted_return(u: Term) -> Formula:
    h = descriptor(nf(u))
    premise = imp(eq(rec(h, succ(B), A), A), eq(rec(h, succ(succ(B)), A), A))
    return imp(forall("b", premise), eq(rec(h, succ(N), A), A))


def new_emitter(u: Term) -> tuple[str, Formula]:
    i, j = occ(u, "n"), occ(u, "a")
    if u == NEW_SEED:
        return "seed", close(conj(SEPARATION, native_bit_matrix()))
    if short_root_tail(u) is not None:
        return "rooted_return", close(rooted_return(u))
    if i > 0 and j == 0:
        return "right_recursion", close(computation(u, right=True))
    if i >= 4:
        return "bound_left_recursion", close(bound_computation(u))
    return "left_recursion", close(computation(u))


def retained_long_root(u: Term) -> Formula:
    return close(conj(bound_computation(u), rooted_return(u)))


def old_guarded_zero(u: Term) -> Formula:
    i, j = occ(u, "n"), occ(u, "a")
    if u == OLD_GUARD_SEED:
        return close(conj(computation(u), conj(SEPARATION, native_bit_matrix())))
    if i > 0 and j == 0:
        return close(computation(u, right=True))
    if j > 0 and is_guarded(u):
        progress = forall("k", imp(eq(at(u, K, A), ZERO), eq(at(u, succ(K), A), ZERO)))
        return close(conj(computation(u), imp(progress, eq(u, ZERO))))
    return close(computation(u))


def old_mask_propagation(u: Term) -> Formula:
    here = eq(test(N, u), N)
    there = eq(test(K, at(u, K, A)), K)
    progress = forall("k", imp(there, eq(at(u, succ(K), A), succ(K))))
    return imp(progress, here)


def old_sparse_mask(u: Term, descriptor_oriented: bool) -> Formula:
    i, j = occ(u, "n"), occ(u, "a")
    if u == ZERO:
        return close(conj(SEPARATION, disj(eq(N, A), eq(test(N, A), ZERO))))
    if i == 0:
        return close(computation(u))
    if j == 0:
        return close(computation(u, right=True))
    payload = constancy(u) if term_size(u, descriptor_oriented) <= 10 else old_mask_propagation(u)
    return close(conj(computation(u), payload))


def old_orbit(u: Term, spelling: str = "update") -> Formula:
    h = descriptor(u)
    if spelling == "shifted":
        base = eq(at(u, A, ZERO), A)
        progress = forall("k", imp(eq(rec(h, succ(K), A), A), eq(at(u, A, succ(K)), A)))
        payload = imp(conj(base, progress), eq(rec(h, succ(N), A), A))
    else:
        step = eq(at(u, A, K), A) if spelling == "update" else eq(rec(h, succ(K), A), A)
        progress = forall("k", imp(eq(rec(h, K, A), A), step))
        payload = imp(progress, eq(rec(h, N, A), A))
    return close(conj(computation(u, canonical=False), payload))


def old_orbit_fused(u: Term, coverage: str = "existential") -> Formula:
    h = descriptor(u)
    if coverage == "shifted":
        progress = forall("k", imp(eq(rec(h, succ(K), A), A), eq(at(u, A, succ(K)), A)))
        premise = conj(eq(at(u, A, ZERO), A), progress)
        payload = imp(premise, eq(rec(h, succ(N), A), A))
        return close(conj(SEPARATION, conj(computation(u, canonical=False), payload)))
    progress = forall("k", imp(eq(rec(h, K, A), A), eq(at(u, A, K), A)))
    payload = imp(progress, eq(rec(h, N, A), A))
    if coverage == "existential":
        cover = disj(eq(N, ZERO), exists("b", eq(N, succ(B))))
    elif coverage == "predecessor":
        cover = disj(eq(N, ZERO), eq(N, succ(q(N, ZERO))))
    else:
        raise ValueError(coverage)
    return close(conj(conj(SEPARATION, cover), conj(computation(u, canonical=False), payload)))


def old_witness(u: Term, return_test: bool = False, conditional: bool = False) -> Formula:
    h = descriptor(u)
    probe = test(rec(h, succ(N), A), A) if return_test else u
    payload = imp(eq(at(probe, succ(B), A), at(probe, B, A)), eq(probe, B))
    comp = computation(u, canonical=False)
    if conditional:
        comp = conj(SEPARATION, comp)
    return witness_close(conj(comp, payload))


def old_unit_descent(u: Term) -> Formula:
    descent = imp(forall("k", eq(at(u, K, A), succ(at(u, succ(K), A)))), BOTTOM)
    return close(conj(computation(u, canonical=False), descent))


def standalone_unit_descent(u: Term) -> Formula:
    return forall("a", imp(forall("k", eq(at(u, K, A), succ(at(u, succ(K), A)))), BOTTOM))


def old_scalar_constancy(u: Term, prune_stationary: bool = False) -> Formula:
    if u == ZERO:
        return close(conj(computation(u, canonical=False), conj(SEPARATION, native_bit_matrix(False))))
    if prune_stationary and occ(u, "n") == 0:
        return close(computation(u, canonical=False))
    return close(conj(computation(u, canonical=False), constancy(u)))


def contains_identity_rec(t: Term) -> bool:
    return (
        (t.op == "rec" and t.body == V)
        or any(contains_identity_rec(a) for a in t.args)
        or (t.body is not None and contains_identity_rec(t.body))
    )


def has_test(t: Term) -> bool:
    return t.op == "test" or any(has_test(a) for a in t.args) or (t.body is not None and has_test(t.body))


def current_templates(u: Term) -> dict[str, Formula]:
    result = {
        "guarded_zero": old_guarded_zero(u),
        "sparse_mask_active": old_sparse_mask(u, False),
        "sparse_mask_descriptor": old_sparse_mask(u, True),
        "orbit_update_core": old_orbit(u),
        "orbit_only_core": old_orbit(u, "orbit"),
        "orbit_shifted_core": old_orbit(u, "shifted"),
        "orbit_fused_existential_coverage": old_orbit_fused(u),
        "orbit_fused_predecessor_coverage": old_orbit_fused(u, "predecessor"),
        "orbit_shifted_fused": old_orbit_fused(u, "shifted"),
        "witness_ordinary_core": old_witness(u),
        "witness_conditional": old_witness(u, conditional=True),
        "witness_return_core": old_witness(u, return_test=True),
        "unit_descent_generated_zero_extra_parameters": old_unit_descent(u),
        "unit_descent_scalar_constancy": old_scalar_constancy(u),
        "unit_descent_scalar_constancy_pruned": old_scalar_constancy(u, True),
    }
    result["witness_adaptive_core"] = (
        result["witness_ordinary_core"] if 3 * term_size(u) + occ(u, "n") <= 19
        else result["witness_return_core"]
    )
    if not contains_identity_rec(u):
        result["witness_projection_alias_variant"] = (
            close(conj(SEPARATION, native_bit_matrix(False))) if u == N
            else result["witness_ordinary_core"]
        )
    return result


def render(t: Term) -> str:
    if t.op == "var":
        return t.name
    if t.op == "zero":
        return "0"
    if t.op == "succ":
        return f"S({render(t.args[0])})"
    if t.op == "test":
        return f"chi({render(t.args[0])},{render(t.args[1])})"
    assert t.body is not None
    name = "Q" if t.body == W else "Z" if t.body == ZERO else f"R[{render(t.body)}]"
    return f"{name}({render(t.args[0])},{render(t.args[1])})"


def assert_formula_ledgers(u: Term) -> None:
    m, fw, h = term_size(u), term_size(u, True), term_size(nf(u), True)
    i, j = occ(u, "n"), occ(u, "a")
    assert formula_size(close(computation(u))) == 13 + m + 2 * i
    assert formula_size(close(computation(u)), True) == 13 + fw + 2 * i + (i + 2) * h
    assert formula_size(close(bound_computation(u))) == 20 + m
    assert formula_size(close(bound_computation(u)), True) == 20 + fw + 3 * h
    assert formula_size(close(computation(u, right=True))) == 15 + m
    assert formula_size(close(computation(u, right=True)), True) == 15 + fw + 3 * h
    for spelling, active, full in (
        ("update", 29 + 2 * m + 2 * i, 29 + (6 + i) * fw + 2 * i),
        ("orbit", 33 + m + 2 * i, 33 + (6 + i) * fw + 2 * i),
        ("shifted", 34 + 3 * m + 2 * i + j, 34 + (7 + i) * fw + 2 * i + j),
    ):
        f = old_orbit(u, spelling)
        assert formula_size(f) == active, (spelling, render(u), formula_size(f), active)
        assert formula_size(f, True) == full, (spelling, render(u), formula_size(f, True), full)
    for coverage, active, full in (
        ("existential", 46 + 2 * m + 2 * i, 46 + (6 + i) * fw + 2 * i),
        ("predecessor", 47 + 2 * m + 2 * i, 48 + (6 + i) * fw + 2 * i),
        ("shifted", 41 + 3 * m + 2 * i + j, 41 + (7 + i) * fw + 2 * i + j),
    ):
        f = old_orbit_fused(u, coverage)
        assert formula_size(f) == active, (coverage, render(u), formula_size(f), active)
        assert formula_size(f, True) == full, (coverage, render(u), formula_size(f, True), full)
    for ret, cond, active, full in (
        (False, False, 19 + 4 * m + 3 * i, 19 + (6 + i) * fw + 3 * i),
        (False, True, 26 + 4 * m + 3 * i, 26 + (6 + i) * fw + 3 * i),
        (True, False, 38 + m + 2 * i, 38 + (6 + i) * fw + 2 * i),
    ):
        f = old_witness(u, ret, cond)
        assert formula_size(f) == active
        assert formula_size(f, True) == full
    assert formula_size(old_unit_descent(u)) == 19 + 3 * m + 3 * i
    assert formula_size(old_unit_descent(u), True) == 19 + (5 + i) * fw + 3 * i
    assert formula_size(standalone_unit_descent(u)) == 6 + 2 * m + i
    assert formula_size(standalone_unit_descent(u), True) == 6 + 2 * fw + i


def generate_inputs(seed: int, count: int) -> list[Term]:
    rng = random.Random(seed)
    descriptors = [ZERO, V, W, succ(V), succ(W), test(V, W), rec(succ(V), V, W)]
    basic = [ZERO, N, A, ONE, succ(N), succ(A), NEW_SEED, OLD_GUARD_SEED]
    inputs = list(basic)
    pool = [ZERO, N, A]
    for k in range(count):
        if k % 5 == 0:
            u = succ(rng.choice(pool))
        elif k % 5 == 1:
            u = test(rng.choice(pool), rng.choice(pool))
        elif k % 5 == 2:
            u = q(rng.choice(pool), rng.choice(pool))
        elif k % 5 == 3:
            u = z(rng.choice(pool), rng.choice(pool))
        else:
            u = rec(rng.choice(descriptors), rng.choice(pool), rng.choice(pool))
        if term_size(u) <= 180:
            pool.append(u)
            inputs.append(u)
        if len(pool) > 120:
            pool = pool[:3] + pool[-100:]
    tails = inputs[: min(300, len(inputs))]
    for t in tails:
        inputs.extend([root_short(t), root_long(t), guarded(t), q(succ(t), A)])
    u = A
    for _ in range(20):
        u = q(N, u)
        inputs.extend([u, root_short(u), root_long(u), q(succ(u), A)])
    return list(dict.fromkeys(inputs))


def sample_row(label: str, u: Term) -> dict:
    branch, f = new_emitter(u)
    old = current_templates(u)
    scores = {name: [formula_size(p), formula_size(p, True)] for name, p in old.items()}
    active_min = min(v[0] for v in scores.values())
    full_min = min(v[1] for v in scores.values())
    return {
        "label": label, "input": render(u), "branch": branch,
        "input_profile": {"m": term_size(u), "W": term_size(u, True), "H": term_size(nf(u), True),
                          "i": occ(u, "n"), "j": occ(u, "a")},
        "comparison_mode": "matched binary-test profiles" if has_test(u) else "common arithmetic grammar",
        "identity_alias_variant_admissible": not contains_identity_rec(u),
        "new": [formula_size(f), formula_size(f, True)],
        "current_minimum": [active_min, full_min],
        "current_minimizers_active": [k for k, v in scores.items() if v[0] == active_min],
        "current_minimizers_full": [k for k, v in scores.items() if v[1] == full_min],
        "current_template_counts": scores,
        "new_quantifier_count_and_depth": list(quantifier_profile(f)),
    }


def audit(seed: int, count: int) -> dict:
    inputs = generate_inputs(seed, count)
    branches: Counter = Counter()
    modes: Counter = Counter()
    strict_active = strict_full = strict_both = 0
    omitted_alias = 0
    for u in inputs:
        reset_count_caches()
        assert nf(nf(u)) == nf(u)
        assert term_size(nf(u), True) <= term_size(u, True)
        assert_formula_ledgers(u)
        branch, f = new_emitter(u)
        branches[branch] += 1
        modes["matched_test_profiles" if has_test(u) else "common_arithmetic_grammar"] += 1
        current = current_templates(u)
        if contains_identity_rec(u):
            omitted_alias += 1
        new_active, new_full = formula_size(f), formula_size(f, True)
        old_active = min(formula_size(p) for p in current.values())
        old_full = min(formula_size(p, True) for p in current.values())
        assert new_active <= old_active, (render(u), branch, new_active, old_active)
        assert new_full <= old_full, (render(u), branch, new_full, old_full)
        strict_active += new_active < old_active
        strict_full += new_full < old_full
        strict_both += new_active < old_active and new_full < old_full
        padded = q(succ(u), A)
        padded_branch, _ = new_emitter(padded)
        assert nf(padded) == nf(u)
        assert padded_branch in {"left_recursion", "bound_left_recursion"}
        tail = short_root_tail(u)
        if tail is not None:
            assert term_size(u) == term_size(tail) + 8
            assert term_size(u, True) == term_size(tail, True) + 10
            assert occ(u, "n") == occ(tail, "n") + 1
            assert occ(u, "a") == occ(tail, "a") + 1
            assert new_active == 24
            assert new_full == 24 + 3 * term_size(u, True)
    long_checks = []
    for tail in (ZERO, N, A, q(N, A), q(N, q(N, q(N, A)))):
        u = root_long(tail)
        f = retained_long_root(u)
        m, fw, i = term_size(u), term_size(u, True), occ(u, "n")
        assert m == term_size(tail) + 13
        assert fw == term_size(tail, True) + 17
        assert i == occ(tail, "n") + 3
        assert formula_size(f) == 43 + m
        assert formula_size(f, True) == 43 + 7 * fw
        # Orbit-only is an actual optional incumbent, and can be smaller
        # actively at i=3 or 4.  Record, rather than conceal, this limit.
        old_only = old_orbit(u, "orbit")
        long_checks.append({"tail": render(tail), "m": m, "W": fw, "i": i,
                            "retained": [formula_size(f), formula_size(f, True)],
                            "old_orbit_only": [formula_size(old_only), formula_size(old_only, True)]})
    nested = A
    for _ in range(4):
        nested = q(N, nested)
    sample_inputs = [
        ("zero", ZERO), ("state slot", N), ("counter slot", A),
        ("successor state", succ(N)), ("counter recursor", q(N, A)),
        ("old guarded seed", OLD_GUARD_SEED), ("new fixed seed", NEW_SEED),
        ("short root of zero", root_short(ZERO)), ("short root of state", root_short(N)),
        ("short root of counter", root_short(A)), ("short root of Q", root_short(q(N, A))),
        ("four state occurrences", nested), ("padded short root", q(succ(root_short(N)), A)),
        ("old long root of zero", root_long(ZERO)),
    ]
    return {
        "status": "passed", "random_seed": seed, "requested_random_iterations": count,
        "tested_distinct_inputs": len(inputs), "branch_counts": dict(branches),
        "comparison_mode_counts": dict(modes),
        "strictly_below_current_minimum": {"active": strict_active, "full": strict_full, "both": strict_both},
        "optional_projection_alias_inadmissible_inputs": omitted_alias,
        "scope": {
            "baseline_commit": "fc604391af372504e9163797c0722069ae49466e",
            "baseline_archives": ["pra_guarded_zero", "pra_orbit", "pra_sparse_mask", "pra_unit_descent", "pra_witness_constancy"],
            "fixed_overheads": "Omitted from factored incumbent recurring cores, strengthening the numerical benchmark; the new seed is counted.",
            "unit_descent": "The compared generated k=0 formula includes scalar computation. Standalone UD is separately checked, not compared as if its required computation equations were free.",
            "vocabulary": "0/S/recursor inputs lie in the common arithmetic grammar. Inputs containing a binary test compare matched syntax profiles; mask, bit, and logical-conditional vocabularies are not asserted identical.",
            "projection_alias": "The optional witness R_v(t,a):=a variant is compared only when the input and every stored descriptor already avoid R_v. Arbitrary translations through this alias can change the input size.",
            "normalization": "Root-only Q(Sr,s) -> r; no semantic simplification, traversal, or descriptor sharing.",
            "counting_implementation": "Identity memoization caches subtree sizes, retaining the objects to prevent identity reuse and clearing caches between inputs. Every occurrence adds the entire cached size; the charged tree measure is unchanged.",
            "proof_scope": "Finite AST/count audit and padding-shape checks only. General inequalities and arithmetic bi-interpretability require the written mathematical proofs.",
            "long_root_limit": "Retaining all computation in the long-root variant improves the main kernels, but not the active orbit-only optional core for i=3 or 4; it ties that core at i=5.",
        },
        "examples": [sample_row(label, u) for label, u in sample_inputs],
        "retained_long_root_examples": long_checks,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20261102)
    parser.add_argument("--count", type=int, default=700)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("syntax_results.json"))
    args = parser.parse_args()
    result = audit(args.seed, args.count)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("status", "tested_distinct_inputs", "branch_counts", "strictly_below_current_minimum")}, indent=2))
    print(f"Detailed result: {args.output.resolve()}")


if __name__ == "__main__":
    main()
