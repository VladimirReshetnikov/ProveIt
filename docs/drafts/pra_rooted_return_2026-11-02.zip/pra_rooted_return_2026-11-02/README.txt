ROOTED RETURN ARITHMETIC
Research package prepared for Vladimir Reshetnikov, November 2, 2026

MAIN RESULT
===========
An exact smaller presentation of first-order primitive recursive arithmetic.
The mathematical principle is induction only for native equalities expressing
return to the initial state, on a family of explicitly rooted recursive
updates. Their base is automatic, so only progression is asserted.

The written proof establishes a common conservative definitional extension
with PRA. Both interpretations preserve the full carrier and native equality;
both round trips are the identity. The construction works separately for
matching classical and intuitionistic logic.

The exact five-case emitter improves the current five-draft matched lower
envelope in both active and fully expanded syntax-tree accounting: it never
increases the counts under the declared comparison and is strictly smaller
on several infinite classes. Some simple instances tie.

The result is not an encoding-independent global minimum. The paper records
the five cases, inherited root normalization, literal update pattern, variable
binding, cross-language comparison conventions, and recovery of omitted
computation from other raw inputs. No shorter-proof-translation claim is made.

START HERE
==========
report.pdf            Full compiled article
report.tex            Main editable source
sections/*.tex        Complete included source
AXIOMS.txt            Standalone exact specification

SUPPORTING ARTIFACTS
===================
checks/check_syntax.py
  Independent standard-library AST/count checker.
checks/syntax_results.json
  Recorded deterministic audit of 1,602 well-formed inputs.
formal/RootedReturn.lean
  Checked arbitrary-carrier proof kernel; no Mathlib dependency.
formal/SCOPE.txt
  Exact formalization boundary.
formal/compiler_version.txt, formal/compiler_output.txt
  Actual Lean 4.19.0 compiler and axiom-audit output.
formal/verification.json
  Formal check metadata.
source_manifest.json
  Exact current snapshot, archive blob/SHA-256 hashes, and reviewed sources.
verification/
  Independent mathematical reviews, build log, and PDF review.
SHA256SUMS
  Final package checksums (excluding the checksum file itself).
build.py
  Rebuild checker/PDF, optionally recheck Lean.

REBUILD
=======
Requirements: Python 3.10+ and pdfLaTeX with the common packages used in
report.tex. Lean 4.19.0 is optional when rebuilding the report.

  python3 build.py

To run the exact formal kernel too:

  python3 build.py --lean /absolute/path/to/lean

To run only the syntax audit:

  python3 checks/check_syntax.py

No build step accesses the network. The full equivalence is a written proof,
not entirely formalized. Finite tests are not a substitute for its universal
mathematical arguments.

BASELINE
========
VladimirReshetnikov/ProveIt
fc604391af372504e9163797c0722069ae49466e
docs/drafts

All five archives currently present at that snapshot were inspected, including
their optional smaller forms. Their own older six-draft inventories are not
the inventory used here. Input archives are not redistributed.
No GitHub repository modification is included in this delivery.
