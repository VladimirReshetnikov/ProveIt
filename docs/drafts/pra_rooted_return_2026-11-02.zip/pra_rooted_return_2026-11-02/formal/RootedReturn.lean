/-
Primitive recursive arithmetic from rooted return induction.
Arbitrary-carrier kernels for the exact short latch, native equality decisions,
and extraction of induction.  See SCOPE.txt for what is not formalized.
-/

namespace RootedReturn

variable {A : Type}

theorem equality_decision
    (zero : A) (succ : A → A) (chi : A → A → A)
    (separation : zero ≠ succ zero)
    (diagonal : ∀ x, chi x x = succ zero)
    (off_diagonal : ∀ x y, x = y ∨ chi x y = zero)
    (x y : A) : x = y ∨ x ≠ y := by
  rcases off_diagonal x y with heq | hzero
  · exact Or.inl heq
  · refine Or.inr ?_
    intro heq
    subst y
    exact separation (hzero.symm.trans (diagonal x))

theorem equality_false_value
    (zero : A) (chi : A → A → A)
    (off_diagonal : ∀ x y, x = y ∨ chi x y = zero)
    (x y : A) (hne : x ≠ y) : chi x y = zero := by
  rcases off_diagonal x y with heq | hzero
  · exact False.elim (hne heq)
  · exact hzero

def latch (zero : A) (chi z : A → A → A)
    (test : A → A → A) (v w : A) : A :=
  z (z (chi w zero) (chi (test v w) zero)) v

theorem latch_zero_counter
    (zero : A) (succ : A → A) (chi z : A → A → A)
    (test : A → A → A)
    (diagonal : ∀ x, chi x x = succ zero)
    (z_zero : ∀ x, z zero x = x)
    (z_succ : ∀ n x, z (succ n) x = zero) (v : A) :
    latch zero chi z test v zero = v := by
  unfold latch
  rw [diagonal zero, z_succ, z_zero]

theorem latch_zero_state
    (zero : A) (succ : A → A) (chi z : A → A → A)
    (test : A → A → A)
    (separation : zero ≠ succ zero)
    (diagonal : ∀ x, chi x x = succ zero)
    (off_diagonal : ∀ x y, x = y ∨ chi x y = zero)
    (z_zero : ∀ x, z zero x = x)
    (z_succ : ∀ n x, z (succ n) x = zero) (w : A) :
    latch zero chi z test zero w = zero := by
  rcases equality_decision zero succ chi separation diagonal off_diagonal w zero
    with hw | hw
  · subst w
    exact latch_zero_counter zero succ chi z test diagonal z_zero z_succ zero
  · unfold latch
    rw [equality_false_value zero chi off_diagonal w zero hw, z_zero]
    rcases equality_decision zero succ chi separation diagonal off_diagonal
      (test zero w) zero with ht | ht
    · rw [ht, diagonal, z_succ]
    · rw [equality_false_value zero chi off_diagonal (test zero w) zero ht, z_zero]

theorem latch_return_iff
    (zero : A) (succ pred : A → A) (chi z : A → A → A)
    (test : A → A → A) (P : A → A → Prop)
    (succ_ne_zero : ∀ x, succ x ≠ zero)
    (pred_succ : ∀ x, pred (succ x) = x)
    (diagonal : ∀ x, chi x x = succ zero)
    (off_diagonal : ∀ x y, x = y ∨ chi x y = zero)
    (z_zero : ∀ x, z zero x = x)
    (z_succ : ∀ n x, z (succ n) x = zero)
    (test_spec : ∀ v w,
      (test v w = succ zero ∧ P w (pred v)) ∨
      (test v w = zero ∧ ¬P w (pred v)))
    (v w a : A) :
    latch zero chi z test v w = succ a ↔
      v = succ a ∧ (w = zero ∨ P w a) := by
  rcases equality_decision zero succ chi (Ne.symm (succ_ne_zero zero))
    diagonal off_diagonal w zero with hw | hw
  · subst w
    rw [latch_zero_counter zero succ chi z test diagonal z_zero z_succ]
    constructor
    · exact fun heq => ⟨heq, Or.inl rfl⟩
    · exact fun hret => hret.1
  · unfold latch
    rw [equality_false_value zero chi off_diagonal w zero hw, z_zero]
    rcases test_spec v w with h | h
    · rw [h.1, equality_false_value zero chi off_diagonal
        (succ zero) zero (succ_ne_zero zero), z_zero]
      constructor
      · intro heq
        refine ⟨heq, Or.inr ?_⟩
        simpa only [heq, pred_succ] using h.2
      · exact fun hret => hret.1
    · rw [h.1, diagonal zero, z_succ]
      have hn : zero ≠ succ a := Ne.symm (succ_ne_zero a)
      constructor
      · intro hfalse
        exact False.elim (hn hfalse)
      · rintro ⟨heq, hgood⟩
        have hp : P w a := hgood.resolve_left hw
        have hnot : ¬P w a := by simpa only [heq, pred_succ] using h.2
        exact False.elim (hnot hp)

/-
F n is the proposition R_H(n, S a) = S a.  The recurrence follows from
the preceding exact latch identity and the recursor step equation.
The return principle is precisely the axiom for this descriptor and seed.
No assumption of induction or successor coverage on A is used.
-/
theorem induction_from_rooted_return
    (zero : A) (succ : A → A) (P F : A → Prop)
    (recurrence : ∀ k, F (succ k) ↔ F k ∧ (k = zero ∨ P k))
    (rooted_return :
      (∀ b, F (succ b) → F (succ (succ b))) → ∀ n, F (succ n))
    (base : P zero) (step : ∀ k, P k → P (succ k)) : ∀ n, P n := by
  have from_return : ∀ k, F (succ k) → P k := by
    intro k hk
    rcases ((recurrence k).mp hk).2 with hz | hp
    · simpa only [hz] using base
    · exact hp
  have returned_step : ∀ k, F (succ k) → F (succ (succ k)) := by
    intro k hk
    exact (recurrence (succ k)).mpr ⟨hk, Or.inr (step k (from_return k hk))⟩
  intro n
  exact from_return n (rooted_return returned_step n)

/- The shared-state graph is exactly an ordinary computation equation. -/
theorem shared_state_iff (r s : A) (h : A → A) :
    (∀ c, r = c → s = h c) ↔ s = h r := by
  constructor
  · intro hc
    exact hc r rfl
  · intro heq c hrc
    cases hrc
    exact heq

#print axioms equality_decision
#print axioms equality_false_value
#print axioms latch_zero_counter
#print axioms latch_zero_state
#print axioms latch_return_iff
#print axioms induction_from_rooted_return
#print axioms shared_state_iff

end RootedReturn
