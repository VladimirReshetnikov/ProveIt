"""Measure all current top-level checker variants without editing references."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tokenize

ROOT = Path(__file__).resolve().parents[1]
IGNORE = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
          tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}

class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean

def metrics(tree):
    text = ast.unparse(tree) + '\n'
    return {'normalized_tokens': sum(t.type not in IGNORE for t in tokenize.generate_tokens(io.StringIO(text).readline)),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(text.encode('utf-8'))}

def main():
    directory = Path(__file__).resolve().parent
    manifest = json.loads((directory / 'manifest.json').read_text())
    rows = []
    for entry in manifest['programs']:
        path = directory / entry['local_file']
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != entry['sha256']:
            raise ValueError('Changed comparator: ' + entry['local_file'])
        tree = ast.fix_missing_locations(StripDocstrings().visit(ast.parse(raw)))
        row = {'label': entry['label'], 'file': str(path.relative_to(ROOT)),
               'raw_bytes': len(raw), 'sha256': digest, **metrics(tree)}
        tree.body = [n for n in tree.body if not isinstance(n, (ast.Import, ast.ImportFrom))
                     and not (isinstance(n, ast.If) and '__name__' in ast.unparse(n.test))]
        row['core'] = metrics(tree)
        rows.append(row)
    result = {'count': len(rows), 'rows': rows,
              'minima': {k: min(r[k] for r in rows) for k in ('normalized_tokens', 'ast_nodes', 'normalized_bytes')}}
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
