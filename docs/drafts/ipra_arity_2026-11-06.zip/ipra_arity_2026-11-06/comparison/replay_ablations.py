"""Replay the fixed logical corpus through every sound ablation variant.

This optional diagnostic imports the untrusted encoder and the frozen named
oracle corpus.  Acceptance programs never import this file.
"""
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from validation import replay


def tagged(a):
    if type(a) is list:
        return [tagged(x) for x in a]
    return 'u' if a == 'q' else a


def main():
    manifest = json.loads((ROOT / 'comparison' / 'ablation_manifest.json').read_text())
    corpus = [row for row in replay.suite.source_derivations()
              if row['provenance'] == 'frozen logical encoding']
    if len(corpus) != 58:
        raise ValueError('Expected the fixed 58-certificate logical corpus')
    rows = []
    for index, entry in enumerate(manifest['programs']):
        kernel = replay.load(ROOT / entry['file'], 'ablation_' + str(index))
        arity = int(entry['stage'][:2]) >= 3
        failures = []
        for row in corpus:
            if arity:
                goal = replay.encode(row['goal'])
                stack = replay.stack_encode(row['stack'])
                context = [replay.encode(x) for x in row.get('context', ())]
            else:
                goal, stack, context = tagged([row['goal'], row['stack'], row.get('context', [])])
            accepted, remaining = replay.accept(kernel, goal, stack, context)
            if not accepted or remaining:
                failures.append(row['name'])
        # The conclusion Qx.x=0 does not follow from exists x.x=0.  This detects
        # accidental reuse of a partially bound matrix as the lifted goal.
        body = ['=', 1, 0]
        existential = ['ex', body]
        regression = [['q', body], [None, None, [existential, None]], [existential]]
        if arity:
            goal = replay.encode(regression[0])
            stack = replay.stack_encode(regression[1])
            context = [replay.encode(x) for x in regression[2]]
        else:
            goal, stack, context = tagged(regression)
        if replay.accept(kernel, goal, stack, context)[0]:
            failures.append('failed-pattern saved-lift regression')
        for invalid in [[], 'x', True]:
            if replay.accept(kernel, deepcopy(invalid), [None], [deepcopy(invalid)])[0]:
                failures.append('invalid formula ' + repr(invalid))
        rows.append({'file': entry['file'], 'witness_policy': entry['witness_policy'],
                     'logical_certificates': len(corpus), 'regressions': 4,
                     'failures': failures})
    result = {'status': 'PASS' if all(not row['failures'] for row in rows) else 'FAIL',
              'programs': len(rows), 'logical_replays': len(rows) * len(corpus),
              'regression_replays': len(rows) * 4, 'rows': rows}
    (ROOT / 'comparison' / 'ablation_validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'rows'}, indent=2))
    if result['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
