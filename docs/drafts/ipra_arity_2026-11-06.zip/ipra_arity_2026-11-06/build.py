"""Compile the self-contained report using a normal pdfLaTeX installation."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
subprocess.run([sys.executable, 'render_tables.py'], cwd=ROOT, check=True)
log = []
for attempt in range(3):
    result = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                             'report.tex'], cwd=ROOT, capture_output=True, text=True)
    log.append(result.stdout + result.stderr)
    if result.returncode:
        (ROOT / 'results' / 'latex_build.txt').write_text('\n'.join(log))
        raise SystemExit(result.stdout[-6000:] + result.stderr)
(ROOT / 'results' / 'latex_build.txt').write_text('\n'.join(log))
print('Built report.pdf')
