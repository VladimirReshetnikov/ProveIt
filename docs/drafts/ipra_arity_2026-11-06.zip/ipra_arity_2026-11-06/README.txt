AN ARITY PRESENTATION OF INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 6 November 2026 (Pacific time)

RESULT

The complete strict checker has 492 normalized significant Python tokens,
504 AST nodes, and 1,506 normalized UTF-8 bytes. These are strictly below
the respective 505 / 510 / 1,554 minima of all sixteen complete top-level
checker variants in the six current ProveIt draft archives at commit:

  9e8e3161b0dffb54fceb0b75ee818cc9e4ed2b10

The strict core is 434 / 438 / 1,244, below every current core minimum.
The optional demand checker is 484 / 496 / 1,462 for the whole program,
and 426 / 430 / 1,200 for its core.

This is a measured improvement over a pinned finite comparison corpus,
not a proof of a globally shortest axiomatization. The underlying retained-
base unary calculus and its arithmetic strength are inherited. The new
representation removes constructor labels, validates sorts by arity, and
safely reuses the initial goal lift in existential elimination.

MATHEMATICAL CLAIM

The archive gives all primitive logical/equality rules and arithmetic
computation schemas. It reconstructs full intuitionistic first-order logic,
quantifier-free induction, and an ordinary first-order realization T_cov.
That realization is bi-interpretable with iPRA on the whole number domain;
both composite isomorphisms are x=y. The falsity bridge 0=S0 -> bottom is
explicit. Proof translations preserve inconsistency in both directions.

The report contains mathematical proofs of the metatheory. No Lean/Rocq
formalization of the general soundness or bi-interpretation theorem is
claimed. Finite executable checks are supporting evidence.

FILES

report.tex, sections/*.tex     Complete LaTeX report
report.pdf                    Compiled report
checker.py                    Complete strict standalone theorem checker
checker_demand.py             Optional unused-witness relaxation
FORMAT.txt                    Syntax, input contract, proof instructions
examples/*.json               Closed runnable theorem certificates
measure.py                    Full/core counts and hash verification
comparison/                   All 16 current reference sources and ablations
validation/                   Encoder, independent named oracle, focused audit
results/                      Reproduced test outcomes and report tables
reproduce.py                  One-command measurements and checks
build.py                      Rebuild PDF with pdfLaTeX
package.py                    Rebuild ZIP and file hash manifest
MANIFEST.sha256               Final delivered file hashes

QUICK START

  python3 checker.py examples/reflexivity_zero.json
  python3 checker.py examples/universal_existence.json
  python3 reproduce.py
  python3 build.py

The checker prints ACCEPT (exit 0) or REJECT (exit 1). It needs only Python's
standard library. Python 3.10 or later supports the required syntax;
measurements in this archive were made under CPython 3.12.14.
Rebuilding the PDF also needs a normal pdfLaTeX installation.
All supplied reproduction commands work offline.

IMPORTANT BOUNDARIES

Input is [goal, stack], starting with no assumptions. Negative integer
leaves are rigid variable names, not negative arithmetic values. Two
existential formula fields are logically unused but must still be valid
formula syntax. They never become assumptions. Canonical encoding fills
both with [0,0]. The strict checker validates every numerical witness.

The demand companion can ignore an ill-formed unary-elimination witness
only when its bound coordinate occurs nowhere in the matrix, including
the otherwise ignored annotations. The two programs prove the same theory.

Canonical compiled certificates exhaust their own stacks. An inert unread
initial segment is allowed. A failed major attempt may fall back to an
actual hypothesis. Consequently, erasing annotations in an arbitrary raw
stack need not preserve that stack's acceptance. The valid translation is:
extract its successful derivation, erase annotations, then recompile.

EVIDENCE

The main replay records 1,200 independent named-variable substitution
comparisons; 688 translated derivations, of which 463 are closed; 58
noncanonical-padding derivations; 80 well-formed source fixtures; 900 typed
mutations; 43 new-grammar adversarial cases; and 11 real CLI executions.
All pass. Fifty-nine malformed-source cases that the well-formed encoder
cannot transport are explicitly skipped, not counted as passes.

The separate audit rechecks the same 688 source derivations and adds 40
focused cases plus 20 CLI runs for each policy. These are overlapping test
cohorts, not additional distinct theorem counts. Ablation replay checks all
16 strict/demand stage records. Complete results and source hashes are saved.

SOURCE ATTRIBUTION

The arithmetic/logic basis and independent oracle are adapted from the
current ProveIt drafts. All current archive names, Git blob identities,
source member paths, and SHA-256 hashes are in comparison/manifest.json.
Original licenses are retained. The strict primary uses the same logical
and arithmetic principles, with a new arity representation and scheduling.
