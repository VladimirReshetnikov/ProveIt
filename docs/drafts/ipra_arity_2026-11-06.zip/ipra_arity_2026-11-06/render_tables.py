"""Render report tables from the reproduced measurement JSON."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
data = json.loads((ROOT / 'comparison' / 'complexity.json').read_text())
lines = [r'\begin{center}\small', r'\begin{tabular}{llrrr}', r'\toprule',
         r'Draft / file & Policy & Tokens & AST & Bytes\\', r'\midrule']
for row in data['baselines']:
    label = str(row['archive_index']) + ': ' + Path(row['local_file']).name
    lines.append(r'\code{' + label + '} & ' + row['witness_policy'] + ' & '
                 + ' & '.join(str(row[key]) for key in ('normalized_tokens','ast_nodes','normalized_bytes')) + r'\\')
lines.extend([r'\midrule', r'\textbf{New strict checker} & strict & \textbf{492} & \textbf{504} & \textbf{1506}\\',
              r'New companion & demand & 484 & 496 & 1462\\', r'\bottomrule', r'\end{tabular}', r'\end{center}',
              r'\paragraph{Archive key.} The IDs distinguish filenames whose spaces and parenthetical suffixes differ.'])
manifest = json.loads((ROOT / 'comparison' / 'manifest.json').read_text())
for i, entry in enumerate(manifest['entries']):
    lines.append(r'\noindent ' + str(i) + r': \code{' + entry['name'] + r'}\par')
(ROOT / 'results' / 'comparison_table.tex').write_text('\n'.join(lines) + '\n')

groups = {}
for row in data['ablations']:
    groups.setdefault(row['stage'], {})[row['witness_policy']] = row
lines = [r'\begin{center}\small', r'\begin{tabular}{lrrr}', r'\toprule',
         r'Strict implementation stage & Tokens & AST & Bytes\\', r'\midrule']
for stage, policies in sorted(groups.items()):
    row = policies['strict']
    lines.append(row['label'] + ' & ' + ' & '.join(str(row[key]) for key in
                 ('normalized_tokens','ast_nodes','normalized_bytes')) + r'\\')
lines.extend([r'\bottomrule', r'\end{tabular}', r'\end{center}'])
(ROOT / 'results' / 'ablation_table.tex').write_text('\n'.join(lines) + '\n')
print('Rendered report tables.')
