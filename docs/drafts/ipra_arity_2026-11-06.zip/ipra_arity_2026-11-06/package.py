"""Create a deterministic ZIP and final file hash manifest."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
IGNORED = {'.aux', '.log', '.out', '.toc', '.pyc'}

def included(path):
    return (path.is_file() and '__pycache__' not in path.parts
            and path.suffix not in IGNORED and path.name != 'MANIFEST.sha256')

files = sorted(path for path in ROOT.rglob('*') if included(path))
manifest = ''.join(hashlib.sha256(path.read_bytes()).hexdigest() + '  '
                   + path.relative_to(ROOT).as_posix() + '\n' for path in files)
(ROOT / 'MANIFEST.sha256').write_text(manifest)
files.append(ROOT / 'MANIFEST.sha256')
target = ROOT.with_suffix('.zip')
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        entry = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                               date_time=(2026, 11, 6, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, path.read_bytes())
print(target)
print('Files:', len(files), 'Bytes:', target.stat().st_size)
