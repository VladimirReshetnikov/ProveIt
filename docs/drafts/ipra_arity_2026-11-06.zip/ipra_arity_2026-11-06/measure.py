"""Reproduce the complete-source comparison, with an independent second count.

No acceptance program imports this measurement utility.  Run with Python 3.12
or later from any directory.  The archived baselines and frozen candidates are
hash checked before their normalized source, AST, and core are measured.
"""
import ast
import csv
from copy import deepcopy
import json
from pathlib import Path
import platform

from comparison import independent_measure
from comparison import source_measure


ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT / 'comparison'
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def independent_counts(path):
    tree = ast.fix_missing_locations(
        independent_measure.StripDocstrings().visit(ast.parse(path.read_bytes())))
    whole = independent_measure.metrics(tree)
    core = deepcopy(tree)
    core.body = [node for node in core.body
                 if not isinstance(node, (ast.Import, ast.ImportFrom))
                 and not (isinstance(node, ast.If)
                          and '__name__' in ast.unparse(node.test))]
    return whole, independent_measure.metrics(core)


def checked(entry, path):
    result = source_measure.metrics(path)
    if result['sha256'] != entry['sha256']:
        raise ValueError('Changed measured source: ' + str(path.relative_to(ROOT)))
    independent, independent_core = independent_counts(path)
    for key in KEYS:
        if result[key] != independent[key] or result['core'][key] != independent_core[key]:
            raise ValueError('Independent measurement disagrees: ' + str(path))
    return {**entry, **result, 'file': str(path.relative_to(ROOT))}


def minima(rows, core=False):
    return {key: min((row['core'] if core else row)[key] for row in rows)
            for key in KEYS}


def main():
    manifest = json.loads((COMPARISON / 'manifest.json').read_text())
    ablation_manifest = json.loads((COMPARISON / 'ablation_manifest.json').read_text())
    baselines = [checked(entry, COMPARISON / entry['local_file'])
                 for entry in manifest['programs']]
    ablations = [checked(entry, ROOT / entry['file'])
                 for entry in ablation_manifest['programs']]
    candidates = [row for row in ablations if row['stage'] == '07_final_cached']
    if len(baselines) != 16 or len(candidates) != 2:
        raise ValueError('Expected all 16 current baselines and both candidates')
    whole_minimum = minima(baselines)
    core_minimum = minima(baselines, core=True)
    improvements = {}
    for candidate in candidates:
        name = candidate['witness_policy']
        improvements[name] = {
            'whole': {key: candidate[key] < whole_minimum[key] for key in KEYS},
            'core': {key: candidate['core'][key] < core_minimum[key] for key in KEYS}}
        if not all(improvements[name]['whole'].values()) or not all(improvements[name]['core'].values()):
            raise ValueError('Candidate does not improve every measured coordinate: ' + name)
    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'commit': manifest['commit'],
        'archive_count': len(manifest['archives']),
        'baseline_count': len(baselines),
        'ablation_count': len(ablations),
        'coordinatewise_minimum': whole_minimum,
        'core_coordinatewise_minimum': core_minimum,
        'minimum_attainers': {
            key: [row['label'] for row in baselines if row[key] == whole_minimum[key]]
            for key in KEYS},
        'candidate_improvements': improvements,
        'independent_count_agreement': True,
        'baselines': baselines,
        'candidates': candidates,
        'ablations': ablations}
    (COMPARISON / 'complexity.json').write_text(json.dumps(result, indent=2) + '\n')
    (COMPARISON / 'ablation_metrics.json').write_text(json.dumps(ablations, indent=2) + '\n')
    fields = ('kind', 'label', 'witness_policy', 'file', *KEYS,
              *('core_' + key for key in KEYS), 'source_tokens', 'raw_bytes', 'sha256')
    with (COMPARISON / 'complexity.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fields, extrasaction='ignore')
        writer.writeheader()
        for kind, rows in [('baseline', baselines), ('ablation', ablations)]:
            for row in rows:
                writer.writerow({**row, 'kind': kind,
                                 **{'core_' + key: row['core'][key] for key in KEYS}})
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('baselines', 'ablations')}, indent=2))


if __name__ == '__main__':
    main()
