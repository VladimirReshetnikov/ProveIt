"""Reproduce finite checks of the untrusted proof transformations.

Keep this script beside build_examples.py and proof_transforms.py. Example:
  python3 validation/run_transform_checks.py --checker checker.py \
      --corpus examples/generated_sequents.json --output results/transforms.json

These tests establish finite executable evidence only. They are not a formal
proof of the general substitution or cut theorems.
"""
import argparse
import hashlib
import importlib.util
import json
import platform
from pathlib import Path

import build_examples as b
from proof_transforms import cut, lift_proof, substitute_proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', required=True, type=Path)
    parser.add_argument('--corpus', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    checker_path = args.checker.resolve()
    spec = importlib.util.spec_from_file_location('transform_test_checker', checker_path)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    corpus = json.loads(args.corpus.read_text(encoding='utf-8'))
    records = []

    def verify(name, kind, proof, context):
        try:
            # Internal check assumes a well-formed context; validate explicitly.
            for hypothesis in context:
                checker.subst(hypothesis)
            success = checker.check(*proof, context) is True
            error = None
        except Exception as caught:
            success = False
            error = repr(caught)
        records.append({'name': name, 'kind': kind, 'passed': success,
                        'error': error})

    for record in corpus:
        proof = record['goal'], record['proof']
        context = record['context']
        for amount in (1, 2, 4):
            renamed = lift_proof(proof, amount)
            changed_context = [b.lift(a, amount) for a in context]
            verify(record['name'] + '/' + str(amount), 'injective_renaming',
                   renamed, changed_context)
        for index, assumption in enumerate(context):
            changed = cut(proof, assumption, b.hyp(assumption))
            verify(record['name'] + '/' + str(index), 'identity_cut', changed, context)

    # Replace a genuine retained assumption by a closed-context derivation.
    # Q and E examples exercise lifting of the replacement under a fresh number.
    assumption = b.eq(1, 1)
    replacement = b.reflexivity(1)
    for name, proof in (
            ('direct', (assumption, None)),
            ('under_ex', (['ex', b.eq(2, 2)], [0, None])),
            ('under_q', (['q', b.eq(2, 2)], [None]))):
        verify(name, 'derived_cut', cut(proof, assumption, replacement), [])

    # These environments may identify parameters or replace them with compound
    # terms. They therefore test more than the injective-renaming special case.
    environments = (([0], -1), ([b.succ(0)], -1), ([2], 0),
                    ([b.rec(1, 0, b.succ(1)), b.succ(2)], -2), ([], 2))
    for record in corpus:
        proof = record['goal'], record['proof']
        for index, (images, offset) in enumerate(environments):
            changed = substitute_proof(proof, images, offset)
            changed_context = [b.substitute(a, images, offset) for a in record['context']]
            verify(record['name'] + '/' + str(index), 'general_substitution',
                   changed, changed_context)

    counts = {}
    for record in records:
        counts[record['kind']] = counts.get(record['kind'], 0) + 1
    failures = [record for record in records if not record['passed']]
    result = {
        'passed': not failures,
        'python': platform.python_version(),
        'checker_sha256': hashlib.sha256(checker_path.read_bytes()).hexdigest(),
        'source_derivations': len(corpus),
        'transformation_checks': len(records),
        'counts': counts,
        'records': records,
        'failures': failures,
        'scope': ('Finite derivation tests for structural proof transformations. '
                  'The transformations and this runner are untrusted utilities; '
                  'the standalone checker imports neither.'),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: result[key] for key in
                      ('passed', 'source_derivations', 'transformation_checks', 'counts')}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
