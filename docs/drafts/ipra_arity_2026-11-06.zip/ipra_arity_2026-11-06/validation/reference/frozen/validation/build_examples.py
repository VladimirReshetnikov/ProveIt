"""Untrusted proof builders and examples for the unary-Q calculus.

The acceptance program imports none of this file.  A Proof is a pair
(formula, certificate).  Numerical zero is 0 and free indices start at 1.
"""
from pathlib import Path
import importlib.util
import json
import sys


def eq(a, b):
    return ['=', a, b]


def succ(a):
    return ['s', a]


def rec(n, a, h):
    return ['r', n, a, h]


def substitute(a, images=(), offset=1, depth=0):
    """Readable independent simultaneous substitution on well-formed syntax."""
    if type(a) is int:
        relative = a - depth
        if relative <= 0:
            return a
        if relative <= len(images):
            return substitute(images[relative - 1], offset=depth)
        return a + offset
    tag, *children = a
    widths = {'s': (0,), 'r': (0, 0, 2), '=': (0, 0),
              'q': (1,), 'ex': (1,)}[tag]
    return [tag, *(substitute(child, images, offset, depth + width)
                    for child, width in zip(children, widths, strict=True))]


def lift(a, amount=1):
    return substitute(a, offset=amount)


def instance(a, t):
    return substitute(a, [t], -1)


def hyp(a):
    return a, None


def computation(term):
    tag, n, initial, update = term
    assert tag == 'r'
    if n == 0:
        rhs = initial
    else:
        tag, counter = n
        assert tag == 's'
        rhs = substitute(update, [rec(counter, initial, update), counter], -2)
    return eq(term, rhs), 'r'


def transport(major, motive, minor):
    (tag, left, right), p = major
    assert tag == '='
    source = instance(motive, left)
    assert source == minor[0], (source, minor[0])
    target = instance(motive, right)
    return target, [major[0], p, motive, minor[1]]


def reflexivity(t):
    major = computation(rec(0, t, 0))
    return transport(major, eq(1, lift(t)), major)


def symmetry(major):
    _, left, right = major[0]
    return transport(major, eq(1, lift(left)), reflexivity(left))


def transitivity(first, second):
    _, left, middle = first[0]
    assert second[0][1] == middle
    return transport(second, eq(lift(left), 1), first)


def congruence(major, term_motive):
    left = instance(term_motive, major[0][1])
    return transport(major, eq(lift(left), term_motive), reflexivity(left))


def q_intro(body, step):
    assert step[0] == substitute(body, [succ(1)], 0)
    return ['q', body], [step[1]]


def q_elim(major, t, base):
    tag, body = major[0]
    assert tag == 'q' and base[0] == instance(body, 0)
    return instance(body, t), [major[0], major[1], t, base[1]]


def ex_intro(body, t, premise):
    assert premise[0] == body
    return ['ex', body], [t, premise[1]]


def ex_elim(major, target, premise):
    assert major[0][0] == 'ex' and premise[0] == lift(target)
    return target, [major[0], major[1], premise[1]]


def collapse_from_false(left, right, falsehood=None):
    """From 0=S0 derive an arbitrary equation using a two-valued recursor."""
    falsehood = hyp(eq(0, succ(0))) if falsehood is None else falsehood
    r0 = rec(0, left, lift(right, 2))
    r1 = rec(succ(0), left, lift(right, 2))
    selector = rec(1, lift(left), lift(right, 3))
    first = congruence(falsehood, selector)
    assert first[0] == eq(r0, r1)
    second = transport(computation(r0), eq(1, lift(r1)), first)
    return transport(computation(r1), eq(lift(left), 1), second)


def explosion(formula):
    """From the closed hypothesis 0=S0 derive any native formula."""
    tag, *parts = formula
    if tag == '=':
        return collapse_from_false(*parts)
    if tag == 'ex':
        return ex_intro(parts[0], 0, explosion(parts[0]))
    body, = parts
    return q_intro(body, explosion(substitute(body, [succ(1)], 0)))


def main():
    here = Path(__file__).resolve().parent
    checker_path = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else here / 'q_final_strict.py'
    output = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else here / 'q_examples'
    spec = importlib.util.spec_from_file_location('unary_q_candidate', checker_path)
    candidate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(candidate)
    output.mkdir(parents=True, exist_ok=True)
    records = []

    def save(name, proof, context=()):
        goal, certificate = proof
        assert candidate.check(goal, certificate, list(context)), name
        payload = [goal, certificate]
        entry = {'name': name, 'goal': goal, 'proof': certificate,
                 'context': list(context), 'accepted': True}
        records.append(entry)
        if not context:
            (output / (name + '.json')).write_text(json.dumps(payload, indent=2) + '\n')

    save('reflexivity_zero', reflexivity(0))
    save('reflexivity_parameter', reflexivity(17))
    save('reflexivity_nested_recursion', reflexivity(rec(1, 2, rec(2, 1, succ(3)))))
    save('symmetry_of_computation', symmetry(computation(rec(0, 1, succ(3)))))

    for i, update in enumerate((1, 2, succ(1), rec(2, 1, succ(3)),
                                 rec(3, rec(2, 1, 4), rec(2, 3, succ(5))))):
        save('recursion_nested_update_' + str(i), computation(rec(succ(1), 2, update)))

    # Equation induction: iteration of successor from zero is the identity.
    body = eq(rec(1, 0, succ(1)), 1)
    step_term = rec(succ(1), 0, succ(1))
    step = transport(hyp(body), eq(lift(step_term), succ(1)), computation(step_term))
    induction = q_intro(body, step)
    save('equation_induction', induction)
    save('equation_induction_at_parameter', q_elim(induction, 1, computation(rec(0, 0, succ(1)))))
    save('equation_induction_at_compound_term',
         q_elim(induction, rec(2, 1, succ(1)), computation(rec(0, 0, succ(1)))))

    # A step using the retained base, with the induction assumption unused.
    body = eq(rec(1, 2, 4), 3)
    rbase = rec(0, 2, 4)
    rstep = rec(succ(1), 2, 4)
    base = hyp(eq(rbase, 3))
    middle = transport(computation(rbase), eq(1, 4), base)
    step = transport(symmetry(computation(rstep)), eq(1, 4), middle)
    save('equation_rule_uses_retained_base', q_intro(body, step))

    # Non-equational Q uses cases, with no induction assumption.
    body = ['ex', eq(1, 2)]
    step_body = eq(1, succ(2))
    step = ex_intro(step_body, succ(1), hyp(step_body))
    cases = q_intro(body, step)
    save('compound_numerical_cases', cases)
    base = ex_intro(eq(1, 0), 0, hyp(eq(1, 0)))
    save('q_elimination_existential', q_elim(cases, 1, base))
    save('existential_elimination', ex_elim(base, eq(0, 0), reflexivity(0)))

    # Equality motives range over arbitrary nested formulas.
    equality = computation(rec(0, 1, 0))
    motive = ['ex', eq(1, 2)]
    source = ex_intro(eq(1, lift(equality[0][1])), equality[0][1],
                      hyp(eq(1, lift(equality[0][1]))))
    save('transport_through_existential', transport(equality, motive, source))

    # These are explicit retained-context derivations, not public theorem files.
    d = eq(0, succ(0))
    for name, target in (
        ('explosion_equation', eq(1, succ(2))),
        ('explosion_existential', ['ex', eq(succ(1), 0)]),
        ('explosion_q', ['q', eq(1, 0)]),
        ('explosion_nested', ['q', ['ex', ['q', eq(2, 5)]]]),
    ):
        save(name, explosion(target), [d])
    save('symmetry_under_assumption', symmetry(hyp(eq(1, 2))), [eq(1, 2)])
    save('transitivity_under_assumptions', transitivity(hyp(eq(1, 2)), hyp(eq(2, 3))),
         [eq(1, 2), eq(2, 3)])

    (output / 'generated_sequents.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps({'accepted_derivations': len(records),
                      'public_theorem_examples': sum(not r['context'] for r in records),
                      'open_sequent_examples': sum(bool(r['context']) for r in records),
                      'output': str(output)}, indent=2))


if __name__ == '__main__':
    main()
