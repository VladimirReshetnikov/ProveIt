"""Untrusted finite proof builders for the unary-Q reconstruction of logic.

No acceptance program imports this file. Every generated certificate is
checked both by the compact kernel and an independently named-variable
reference. The builders use ordinary structural proof transformations;
they do not add trusted inference rules.
"""
from dataclasses import dataclass
from pathlib import Path
import argparse
import importlib.util
import json
import sys

import build_examples as b
import proof_transforms as p


def choose(z, first, second):
    return b.rec(z, first, b.lift(second, 2))


def predecessor(t):
    return b.rec(t, 0, 2)


@dataclass
class Equivalence:
    left: list
    right: list
    forward_proof: tuple
    backward_proof: tuple

    def __post_init__(self):
        assert self.forward_proof[0] == self.right
        assert self.backward_proof[0] == self.left

    def forward(self, proof):
        assert proof[0] == self.left
        return p.cut(self.forward_proof, self.left, proof)

    def backward(self, proof):
        assert proof[0] == self.right
        return p.cut(self.backward_proof, self.right, proof)

    def reversed(self):
        return Equivalence(self.right, self.left,
                           self.backward_proof, self.forward_proof)


def identity(formula):
    return Equivalence(formula, formula, b.hyp(formula), b.hyp(formula))


def compose(first, second):
    assert first.right == second.left
    return Equivalence(first.left, second.right,
                       second.forward(first.forward_proof),
                       first.backward(second.backward_proof))


def substitute_equivalence(equivalence, images=(), offset=1):
    return Equivalence(
        b.substitute(equivalence.left, images, offset),
        b.substitute(equivalence.right, images, offset),
        p.substitute_proof(equivalence.forward_proof, images, offset),
        p.substitute_proof(equivalence.backward_proof, images, offset),
    )


def ordinary_ex_intro(body, witness, premise):
    """Derive usual existential introduction using the fresh-equation rule."""
    assert premise[0] == b.instance(body, witness)
    local_equation = b.eq(1, b.lift(witness))
    # The motive has its own hole; the fresh witness variable is a second slot.
    motive = b.substitute(body, offset=1, depth=1)
    opened = b.transport(b.symmetry(b.hyp(local_equation)), motive,
                         p.lift_proof(premise))
    assert opened[0] == body
    return b.ex_intro(body, witness, opened)


def q_congruence(equivalence):
    """Lift a pointwise equivalence through Q, always retaining the base."""
    def direction(conversion):
        zero_conversion = substitute_equivalence(conversion, [0], 0)
        base = zero_conversion.backward(b.hyp(zero_conversion.right))
        major = b.hyp(b.lift(['q', conversion.left]))
        source_step = b.q_elim(major, b.succ(1), base)
        step_conversion = substitute_equivalence(conversion, [b.succ(1)], 0)
        target_step = step_conversion.forward(source_step)
        return b.q_intro(conversion.right, target_step)

    return Equivalence(['q', equivalence.left], ['q', equivalence.right],
                       direction(equivalence), direction(equivalence.reversed()))


def ex_congruence(equivalence):
    """Open a fresh witness, convert its matrix, and close existence again."""
    def direction(conversion):
        source = ['ex', conversion.left]
        target = ['ex', conversion.right]
        converted = conversion.forward(b.hyp(conversion.left))
        branch = ordinary_ex_intro(b.lift(target)[1], 1, converted)
        return b.ex_elim(b.hyp(source), target, branch)

    return Equivalence(['ex', equivalence.left], ['ex', equivalence.right],
                       direction(equivalence), direction(equivalence.reversed()))


def equation_computations(left, right):
    """Convert an equation using separately proved left/right computations."""
    _, left_term, left_value = left[0]
    _, right_term, right_value = right[0]
    source = b.eq(left_term, right_term)
    target = b.eq(left_value, right_value)
    intermediate = b.transport(left, b.eq(1, b.lift(right_term)), b.hyp(source))
    forward = b.transport(right, b.eq(b.lift(left_value), 1), intermediate)
    intermediate = b.transport(b.symmetry(left), b.eq(1, b.lift(right_value)),
                               b.hyp(target))
    backward = b.transport(b.symmetry(right), b.eq(b.lift(left_term), 1),
                           intermediate)
    return Equivalence(source, target, forward, backward)


def gate(formula, z):
    tag, *parts = formula
    if tag == '=':
        return b.eq(choose(z, 0, parts[0]), choose(z, 0, parts[1]))
    assert tag in ('q', 'ex')
    return [tag, gate(parts[0], b.lift(z))]


def gate_zero(formula):
    """A theorem Gate_0(F), for every native F and all its parameters."""
    tag, *parts = formula
    if tag == '=':
        conversion = equation_computations(
            b.computation(choose(0, 0, parts[0])),
            b.computation(choose(0, 0, parts[1])),
        )
        return conversion.backward(b.reflexivity(0))
    body, = parts
    if tag == 'q':
        step_formula = b.substitute(body, [b.succ(1)], 0)
        return b.q_intro(gate(body, 0), gate_zero(step_formula))
    assert tag == 'ex'
    # This theorem needs no use of the added fresh equality assumption.
    return b.ex_intro(gate(body, 0), 0, gate_zero(body))


def gate_successor(formula, n=0):
    """Equivalence Gate_{S n}(F) <-> F, with arbitrary numerical n."""
    tag, *parts = formula
    if tag == '=':
        return equation_computations(
            b.computation(choose(b.succ(n), 0, parts[0])),
            b.computation(choose(b.succ(n), 0, parts[1])),
        )
    inner = gate_successor(parts[0], b.lift(n))
    return q_congruence(inner) if tag == 'q' else ex_congruence(inner)


def q_padding(formula):
    """Equivalence Q_x Gate_x(F) <-> F, for a fresh unused x."""
    body = gate(b.lift(formula), 1)
    padded = ['q', body]
    endpoint = b.q_elim(b.hyp(padded), b.succ(0), gate_zero(formula))
    forward = gate_successor(formula).forward(endpoint)
    successor_conversion = gate_successor(b.lift(formula), 1)
    step = successor_conversion.backward(b.hyp(b.lift(formula)))
    backward = b.q_intro(body, step)
    return Equivalence(padded, formula, forward, backward)


def ex_padding(formula):
    """Equivalence E_x F <-> F, for fresh unused x."""
    padded = ['ex', b.lift(formula)]
    forward = b.ex_elim(b.hyp(padded), formula, b.hyp(b.lift(formula)))
    backward = b.ex_intro(b.lift(formula), 0, b.hyp(b.lift(formula)))
    return Equivalence(padded, formula, forward, backward)


def expose(formula, constructor):
    if formula[0] == constructor:
        return formula[1]
    if constructor == 'q':
        return gate(b.lift(formula), 1)
    assert constructor == 'ex'
    return b.lift(formula)


def selector(left, right, z):
    """Q-priority selector; virtual Gate padding preserves logical-node count."""
    if left[0] == 'q' or right[0] == 'q':
        return ['q', selector(expose(left, 'q'), expose(right, 'q'), b.lift(z))]
    if left[0] == 'ex' or right[0] == 'ex':
        return ['ex', selector(expose(left, 'ex'), expose(right, 'ex'), b.lift(z))]
    assert left[0] == right[0] == '='
    return b.eq(choose(z, left[1], right[1]), choose(z, left[2], right[2]))


def selector_endpoint(left, right, branch, n=0):
    """M_0(A,B) <-> A or M_{S n}(A,B) <-> B."""
    assert branch in (0, 1)
    selected = right if branch else left
    if left[0] == 'q' or right[0] == 'q':
        inner = selector_endpoint(expose(left, 'q'), expose(right, 'q'),
                                  branch, b.lift(n))
        lifted = q_congruence(inner)
        return lifted if selected[0] == 'q' else compose(lifted, q_padding(selected))
    if left[0] == 'ex' or right[0] == 'ex':
        inner = selector_endpoint(expose(left, 'ex'), expose(right, 'ex'),
                                  branch, b.lift(n))
        lifted = ex_congruence(inner)
        return lifted if selected[0] == 'ex' else compose(lifted, ex_padding(selected))
    z = b.succ(n) if branch else 0
    return equation_computations(
        b.computation(choose(z, left[1], right[1])),
        b.computation(choose(z, left[2], right[2])),
    )


def implication(left, right):
    return ['q', selector(b.lift(left), b.lift(right), 1)]


def implication_intro(left, right, premise):
    """Given Gamma,A |- B, produce Gamma |- (A=>B)."""
    assert premise[0] == right
    left_lifted, right_lifted = b.lift(left), b.lift(right)
    zero_conversion = selector_endpoint(left_lifted, right_lifted, 0)
    source = zero_conversion.forward(b.hyp(zero_conversion.left))
    target = p.cut(p.lift_proof(premise), left_lifted, source)
    successor_conversion = selector_endpoint(left_lifted, right_lifted, 1, 1)
    step = successor_conversion.backward(target)
    return b.q_intro(implication(left, right)[1], step)


def implication_elim(left, right, major, minor):
    assert major[0] == implication(left, right) and minor[0] == left
    base = selector_endpoint(left, right, 0).backward(minor)
    result = b.q_elim(major, b.succ(0), base)
    return selector_endpoint(left, right, 1).forward(result)


def universal(body):
    instantiated = b.substitute(body, [predecessor(1)], 0)
    return ['q', gate(instantiated, 1)]


def universal_intro(body, premise):
    """Given Gamma |- F(y), fresh y in slot 1, produce Gamma |- All_x F."""
    assert premise[0] == body
    predecessor_computation = b.computation(predecessor(b.succ(1)))
    motive = b.substitute(body, offset=1, depth=1)
    substituted = b.transport(b.symmetry(predecessor_computation), motive, premise)
    formula = b.substitute(body, [predecessor(b.succ(1))], 0)
    step = gate_successor(formula, 1).backward(substituted)
    return b.q_intro(universal(body)[1], step)


def universal_elim(body, major, t):
    assert major[0] == universal(body)
    base = gate_zero(b.instance(body, predecessor(0)))
    result = b.q_elim(major, b.succ(t), base)
    formula = b.instance(body, predecessor(b.succ(t)))
    result = gate_successor(formula, t).forward(result)
    return b.transport(b.computation(predecessor(b.succ(t))), body, result)


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main():
    here = Path(__file__).resolve().parent
    package = here.parent
    parser = argparse.ArgumentParser()
    parser.add_argument('--checker', type=Path,
                        default=package / 'checker.py')
    parser.add_argument('--reference', type=Path,
                        default=here / 'reference.py')
    parser.add_argument('--output', type=Path, default=package / 'examples' / 'logic')
    args = parser.parse_args()
    checker = load_module(args.checker, 'unary_q_logic_kernel')
    reference = load_module(args.reference, 'unary_q_logic_reference')
    args.output.mkdir(parents=True, exist_ok=True)
    records = []

    def save(name, proof, context=()):
        goal, certificate = proof
        assert checker.check(goal, certificate, list(context)), ('kernel', name)
        assert reference.accept_sequent(goal, certificate, context), ('reference', name)
        record = {'name': name, 'goal': goal, 'proof': certificate,
                  'context': list(context), 'kernel_accepted': True,
                  'independent_reference_accepted': True}
        records.append(record)
        if not context:
            (args.output / (name + '.json')).write_text(
                json.dumps([goal, certificate], separators=(',', ':')) + '\n')

    def save_equivalence(name, equivalence):
        save(name + '_forward', equivalence.forward_proof, [equivalence.left])
        save(name + '_backward', equivalence.backward_proof, [equivalence.right])

    formulas = [
        b.eq(1, 2),
        ['q', b.eq(1, 2)],
        ['ex', b.eq(1, b.succ(2))],
        ['q', ['ex', b.eq(1, 3)]],
        ['ex', ['q', b.eq(2, 3)]],
        ['q', ['ex', ['q', b.eq(2, 5)]]],
        ['ex', ['q', b.eq(b.rec(1, 3, b.succ(1)), 2)]],
    ]
    for index, formula in enumerate(formulas):
        save('gate_zero_' + str(index), gate_zero(formula))
        save_equivalence('gate_successor_' + str(index), gate_successor(formula, 1))

    save_equivalence('q_congruence_gate', q_congruence(gate_successor(formulas[2], 2)))
    for index, formula in enumerate(formulas[:4]):
        save_equivalence('q_padding_' + str(index), q_padding(formula))

    pairs = [
        (formulas[0], b.eq(b.succ(1), 0)),
        (formulas[1], formulas[0]),
        (formulas[0], formulas[2]),
        (formulas[1], formulas[2]),
        (formulas[3], formulas[4]),
    ]
    for index, (left, right) in enumerate(pairs):
        for branch in (0, 1):
            endpoint = selector_endpoint(left, right, branch, 1)
            expected_selector = b.succ(1) if branch else 0
            assert endpoint.left == selector(left, right, expected_selector)
            save_equivalence('selector_' + str(index) + '_' + str(branch), endpoint)

    left = b.eq(1, 2)
    right = b.eq(2, 1)
    implication_proof = implication_intro(left, right, b.symmetry(b.hyp(left)))
    save('implication_symmetry', implication_proof)
    save('implication_symmetry_elimination',
         implication_elim(left, right, implication_proof, b.hyp(left)), [left])
    nested = formulas[3]
    save('implication_nested_identity', implication_intro(nested, nested, b.hyp(nested)))

    body = b.eq(1, 1)
    all_reflexivity = universal_intro(body, b.reflexivity(1))
    save('universal_reflexivity', all_reflexivity)
    save('universal_reflexivity_at_recursion',
         universal_elim(body, all_reflexivity, b.rec(1, 2, b.succ(1))))
    body = ['ex', b.eq(1, 2)]
    existence = b.ex_intro(b.eq(1, 2), 1, b.hyp(b.eq(1, 2)))
    all_existence = universal_intro(body, existence)
    save('universal_existence', all_existence)
    save('universal_existence_at_successor', universal_elim(body, all_existence, b.succ(1)))

    (args.output / 'logic_sequents.json').write_text(
        json.dumps(records, separators=(',', ':')) + '\n')
    summary = {'accepted_derivations': len(records),
               'public_theorems': sum(not item['context'] for item in records),
               'contextual_derivations': sum(bool(item['context']) for item in records),
               'kernel_accepted': True, 'independent_reference_accepted': True,
               'scope': 'Finite certificates for Gate, Q congruence, padding, mixed-root '
                        'selectors, implication, and universal quantification.'}
    (args.output / 'logic_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
