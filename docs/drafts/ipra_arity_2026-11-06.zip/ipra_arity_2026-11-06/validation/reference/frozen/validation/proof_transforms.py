"""Untrusted structural proof transformations for canonical unary-Q proofs.

No acceptance program imports this module.  These functions transform proof
trees; every result must be rechecked by the independent acceptance program.
"""
from copy import deepcopy

import build_examples as b


def _substitute_expression(expression, images, offset, protected):
    return b.substitute(expression, images, offset, protected)


def substitute_proof(proof, images=(), offset=1, protected=0):
    """Substitute free numerical indices, preserving eigenvariables/motives.

    ``protected`` leading free slots are retained.  Entering a proof premise
    with a new eigenvariable increases this number; an equality motive has
    its own additional protected hole, independent of logical binders.
    """
    goal, certificate = proof
    changed_goal = _substitute_expression(goal, images, offset, protected)
    if certificate is None or certificate == 'r':
        return changed_goal, certificate
    if goal[0] == 'q' and type(certificate) is list and len(certificate) == 1:
        child_goal = b.substitute(goal[1], [b.succ(1)], 0)
        _, child = substitute_proof((child_goal, certificate[0]), images, offset, protected + 1)
        return changed_goal, [child]
    if goal[0] == 'ex' and type(certificate) is list and len(certificate) == 2:
        witness, child = certificate
        changed_witness = _substitute_expression(witness, images, offset, protected)
        _, changed_child = substitute_proof((goal[1], child), images, offset, protected + 1)
        return changed_goal, [changed_witness, changed_child]
    major, major_proof, *arguments = certificate
    changed_major, changed_major_proof = substitute_proof((major, major_proof), images, offset, protected)
    if major[0] == 'ex':
        child, = arguments
        _, changed_child = substitute_proof((b.lift(goal), child), images, offset, protected + 1)
        return changed_goal, [changed_major, changed_major_proof, changed_child]
    annotation, child = arguments
    if major[0] == '=':
        changed_annotation = _substitute_expression(annotation, images, offset, protected + 1)
        child_goal = b.instance(annotation, major[1])
    else:
        assert major[0] == 'q'
        changed_annotation = _substitute_expression(annotation, images, offset, protected)
        child_goal = b.instance(major[1], 0)
    _, changed_child = substitute_proof((child_goal, child), images, offset, protected)
    return changed_goal, [changed_major, changed_major_proof, changed_annotation, changed_child]


def lift_proof(proof, amount=1, protected=0):
    """Injective renaming as the empty-prefix substitution special case."""
    return substitute_proof(proof, offset=amount, protected=protected)


def cut(proof, assumption_formula, replacement_proof):
    """Replace uses of one hypothesis by a proof of that same formula.

    Contexts are reusable, so the replacement may be weakened at every use.
    At fresh-variable premises both the hypothesis and its proof are lifted.
    Local assumptions with the same formula may also be replaced: this is
    sound and avoids relying on a particular context-list position.
    """
    assert replacement_proof[0] == assumption_formula
    goal, certificate = proof
    if certificate is None:
        return deepcopy(replacement_proof) if goal == assumption_formula else deepcopy(proof)
    if certificate == 'r':
        return deepcopy(proof)

    def below_fresh(child):
        return cut(child, b.lift(assumption_formula), lift_proof(replacement_proof))

    if goal[0] == 'q' and type(certificate) is list and len(certificate) == 1:
        child_goal = b.substitute(goal[1], [b.succ(1)], 0)
        _, child = below_fresh((child_goal, certificate[0]))
        return deepcopy(goal), [child]
    if goal[0] == 'ex' and type(certificate) is list and len(certificate) == 2:
        witness, child = certificate
        _, changed_child = below_fresh((goal[1], child))
        return deepcopy(goal), [deepcopy(witness), changed_child]
    major, major_proof, *arguments = certificate
    changed_major, changed_major_proof = cut((major, major_proof), assumption_formula, replacement_proof)
    if major[0] == 'ex':
        child, = arguments
        _, changed_child = below_fresh((b.lift(goal), child))
        return deepcopy(goal), [changed_major, changed_major_proof, changed_child]
    annotation, child = arguments
    if major[0] == '=':
        child_goal = b.instance(annotation, major[1])
    else:
        assert major[0] == 'q'
        child_goal = b.instance(major[1], 0)
    _, changed_child = cut((child_goal, child), assumption_formula, replacement_proof)
    return deepcopy(goal), [changed_major, changed_major_proof, deepcopy(annotation), changed_child]
