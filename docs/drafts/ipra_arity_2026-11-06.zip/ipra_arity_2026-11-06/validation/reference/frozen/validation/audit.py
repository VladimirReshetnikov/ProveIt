"""Independent logical, binding, and public-boundary audit for the Q kernel."""
import argparse
import copy
import hashlib
import importlib.util
import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path

import reference

ROOT = Path(__file__).resolve().parent


def load(path, name='candidate'):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


def accepted(kernel, goal, proof, context=()):
    try:
        return bool(kernel.check(copy.deepcopy(goal), copy.deepcopy(proof),
                                 copy.deepcopy(list(context))))
    except Exception:
        return False


def document_accepted(kernel, document):
    try:
        return bool(kernel.check(*copy.deepcopy(document), []))
    except Exception:
        return False


def E(a, b):
    return ['=', a, b]


def S(a):
    return ['s', a]


def R(n, a, h):
    return ['r', n, a, h]


def lift(expression, width=1, formula=True):
    return reference.substitution(expression, (width,), formula=formula)


def instance(expression, term):
    return reference.substitution(expression, (term, -1))


def reflexivity(term):
    major = E(R(0, term, 0), term)
    return [major, 'r', E(1, lift(term, formula=False)), 'r']


def iteration_equation(term):
    return E(R(term, 0, S(1)), term)


def induction_step(term):
    major = iteration_equation(term)
    left = R(S(term), 0, S(1))
    motive = E(lift(left, formula=False), S(1))
    return [major, None, motive, 'r']


def fixtures():
    rows = json.loads((ROOT / 'generated_sequents.json').read_text())

    def add(name, goal, proof, context=(), expected=False):
        rows.append(dict(name=name, goal=goal, proof=proof,
                         context=list(context), accepted=expected))

    true = E(0, 0)
    zero_q = ['q', true]
    major = ['q', E(1, 0)]
    add('q_elimination_with_base', E(1, 0),
        [major, None, 1, reflexivity(0)], [major], True)
    add('q_elimination_missing_base', E(1, 0),
        [major, None, 1, None], [major])
    add('q_elimination_wrong_base', E(1, 0),
        [major, None, 1, 'r'], [major, E(0, S(0))])
    add('q_elimination_wrong_witness', E(1, 0),
        [major, None, S(1), reflexivity(0)], [major])
    add('q_elimination_unproved_major', true,
        [zero_q, None, 0, reflexivity(0)])

    bad_matrix = ['ex', lift(iteration_equation(1))]
    bad_induction = [[bad_matrix, None, [0, induction_step(3)]]]
    add('forbidden_quantified_induction_hypothesis', ['q', bad_matrix], bad_induction)

    add('existential_witness_parameter', ['ex', E(1, 2)], [1, None], expected=True)
    add('existential_witness_capture', ['ex', E(1, 1)], [1, None])
    add('existential_wrong_witness', ['ex', E(1, 0)], [1, None])
    existential = ['ex', E(1, 0)]
    add('existential_eigenvariable_escape', E(1, 0),
        [existential, None, None], [existential])
    add('existential_elimination_preserves_old_parameter', E(1, 0),
        [existential, None, None], [existential, E(1, 0)], True)
    add('existential_elimination_wrong_branch_count', true,
        [existential, None, None, None], [existential])

    equality = E(1, 0)
    motive = ['ex', E(1, 2)]
    add('equality_transport_beneath_binder', ['ex', E(1, 0)],
        [equality, None, motive, [1, None]], [equality], True)
    add('equality_transport_missing_minor', E(0, 1),
        [equality, None, E(1, 2), None], [equality])
    add('equality_transport_reverses_with_correct_motive', E(0, 1),
        [equality, None, E(1, 2), reflexivity(1)], [equality], True)
    add('equality_transport_wrong_orientation', E(1, 0),
        [equality, None, E(1, 2), reflexivity(1)], [equality])
    add('equality_major_unproved', true,
        [equality, None, true, reflexivity(0)])

    add('recursion_non_successor_variable', E(R(1, 0, 1), 0), 'r')
    add('recursion_non_successor_recursive_index', E(R(R(0, 0, 0), 0, 1), 0), 'r')
    add('recursion_wrong_accumulator_coordinate',
        E(R(S(1), 2, 1), 1), 'r')
    add('recursion_wrong_predecessor_coordinate',
        E(R(S(1), 2, 2), R(1, 2, 2)), 'r')
    add('recursion_wrong_outer_parameter_shift',
        E(R(S(1), 2, 3), 3), 'r')
    add('recursion_outer_parameter_correct',
        E(R(S(1), 2, 3), 1), 'r', expected=True)
    add('free_parameter_is_not_an_out_of_scope_error', E(1000, 1000),
        reflexivity(1000), expected=True)

    malformed = [False, True, 0.0, -1, '0', [], ['s'], ['s', 0, 0],
                 ['q', true], ['r', 0, 0], ['r', 0, 0, ['=', 0, 0]],
                 {'s': 0}, None]
    for index, term in enumerate(malformed):
        add('strict_vacuous_q_witness_%02d' % index, true,
            [zero_q, [None], term, reflexivity(0)])
        add('strict_existential_witness_%02d' % index, ['ex', E(1, 1)],
            [term, reflexivity(1)])

    for index, formula in enumerate([False, 0, 'q', [], ['q'], ['q', true, true],
                                     ['ex', 0], E(False, 0), E(0.0, 0),
                                     ['pi', true, true], ['bot'], ['=', 0],
                                     ['=', 0, 0, 0], ['ex', ['q', ['=', -1, 0]]]]):
        add('malformed_goal_%02d' % index, formula, None)
        add('malformed_equality_motive_%02d' % index, true,
            [true, reflexivity(0), formula, reflexivity(0)])
    add('invalid_boolean_in_computation', E(R(0, False, 0), False), 'r')
    return rows


def term(rng, depth=2, width=4):
    if depth == 0 or rng.randrange(3) == 0:
        return rng.randrange(width + 1)
    if rng.randrange(2) == 0:
        return S(term(rng, depth - 1, width))
    return R(term(rng, depth - 1, width), term(rng, depth - 1, width),
             term(rng, depth - 1, width + 2))


def formula(rng, depth=2, width=3):
    if depth == 0 or rng.randrange(3) == 0:
        return E(term(rng, 2, width), term(rng, 2, width))
    return [rng.choice(['q', 'ex']), formula(rng, depth - 1, width + 1)]


def generated_rules(seed=1907, count=90):
    rng = random.Random(seed)
    rows = []
    for index in range(count):
        a, b, n, h = (term(rng) for _ in range(4))
        f = formula(rng)
        q = ['q', f]
        eq = E(a, b)
        left, right = instance(f, a), instance(f, b)
        zero, output = instance(f, 0), instance(f, n)
        step_left = R(S(n), a, h)
        step_right = reference.substitution(h, (R(n, a, h), n, -2), formula=False)
        records = [
            ('reflexivity', E(a, a), reflexivity(a), []),
            ('zero_computation', E(R(0, a, h), a), 'r', []),
            ('successor_computation', E(step_left, step_right), 'r', []),
            ('constant_q', ['q', lift(f)], [None], []),
            ('existence', ['ex', E(1, lift(a, formula=False))], [a, None], []),
            ('q_elimination', output, [q, None, n, None], [q, zero]),
            ('equality_elimination', right, [eq, None, f, None], [eq, left]),
        ]
        for name, goal, proof, context in records:
            rows.append(dict(name='generated_%s_%03d' % (name, index),
                             goal=goal, proof=proof, context=context, accepted=True))
    return rows


def paths(data, prefix=()):
    yield prefix
    if type(data) is list:
        for index, value in enumerate(data):
            yield from paths(value, (*prefix, index))


def changed(data, path, replacement):
    if not path:
        return replacement
    output = copy.deepcopy(data)
    cursor = output
    for index in path[:-1]:
        cursor = cursor[index]
    cursor[path[-1]] = replacement
    return output


def run(checker, mutation_count=1200, substitution_count=900):
    kernel = load(checker)
    explicit = fixtures()
    generated = generated_rules()
    failures = []
    for row in explicit + generated:
        oracle = reference.accept_sequent(row['goal'], row['proof'], row['context'])
        candidate = accepted(kernel, row['goal'], row['proof'], row['context'])
        if oracle != row['accepted'] or candidate != row['accepted']:
            failures.append({'kind': 'fixture', 'case': row,
                             'oracle': oracle, 'candidate': candidate})

    rng = random.Random(73491)
    accepted_mutations = 0
    sources = [row for row in explicit + generated if row['accepted']]
    simple = [False, True, 0.0, -1, 0, 1, 2, 3, None, 'r', 'x', [],
              ['s'], ['=', 0, 0], ['q', ['=', 1, 1]], {'x': 0}]
    for index in range(mutation_count):
        row = rng.choice(sources)
        pair = [row['goal'], row['proof']]
        where = rng.choice(list(paths(pair)))
        replacement = copy.deepcopy(rng.choice(simple)) if index % 3 else (
            term(rng) if index % 2 else formula(rng))
        mutant = changed(pair, where, replacement)
        if type(mutant) is not list or len(mutant) != 2:
            oracle = reference.accept_document(mutant)
            candidate = document_accepted(kernel, mutant)
        else:
            oracle = reference.accept_sequent(*mutant, row['context'])
            candidate = accepted(kernel, *mutant, row['context'])
        accepted_mutations += candidate
        if oracle != candidate:
            failures.append({'kind': 'mutation', 'number': index, 'data': mutant,
                             'context': row['context'], 'oracle': oracle,
                             'candidate': candidate})

    for index in range(substitution_count):
        is_formula = bool(index % 2)
        syntax = formula(rng) if is_formula else term(rng)
        prefix = [term(rng) for _ in range(index % 4)]
        environment = prefix + [-len(prefix) if index % 3 else index % 4]
        depth = index % 4
        expected = reference.substitution(syntax, environment, depth, is_formula)
        actual = kernel.subst(syntax, environment, depth, is_formula)
        if actual != expected:
            failures.append({'kind': 'substitution', 'number': index,
                             'syntax': syntax, 'environment': environment,
                             'depth': depth, 'formula': is_formula,
                             'expected': expected, 'actual': actual})

    public = [
        ('theorem', [E(0, 0), reflexivity(0)], True),
        ('conditional_sequent_is_not_a_theorem', [E(0, S(0)), None], False),
        ('third_field_cannot_supply_context', [E(0, S(0)), None, [E(0, S(0))]], False),
        ('third_field_empty_context_rejected', [E(0, 0), reflexivity(0), []], False),
        ('untrusted_context_object', [E(0, S(0)), None, {'=': 'anything'}], False),
        ('missing_proof', [E(0, 0)], False),
        ('root_is_null', None, False),
        ('root_is_object', {'goal': E(0, 0), 'proof': reflexivity(0)}, False),
    ]
    for row in explicit:
        if row['name'] in ('forbidden_quantified_induction_hypothesis',
                           'strict_vacuous_q_witness_00',
                           'invalid_boolean_in_computation',
                           'equation_rule_uses_retained_base'):
            public.append((row['name'], [row['goal'], row['proof']], row['accepted']))
    cli_runs = 0
    with tempfile.TemporaryDirectory() as temporary:
        for optimized in (False, True):
            for name, document, expected in public:
                path = Path(temporary) / (name + '.json')
                path.write_text(json.dumps(document))
                command = [sys.executable, *(['-O'] if optimized else []),
                           str(checker), str(path)]
                result = subprocess.run(command, capture_output=True, text=True, timeout=15)
                ok = result.returncode == (0 if expected else 1)
                ok = ok and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT')
                if not ok:
                    failures.append({'kind': 'cli', 'name': name, 'optimized': optimized,
                                     'stdout': result.stdout, 'stderr': result.stderr,
                                     'exit': result.returncode})
                cli_runs += 1

    # Check that the logical attacks really exercise the corresponding protections.
    source = checker.read_text()
    faults = [
        ('unrestricted_induction', "([b] if b[0] == '=' else [])", '[b]',
         'forbidden_quantified_induction_hypothesis'),
        ('omitted_q_base', 'return c == a and check(b, q, g)', 'return c == a',
         'q_elimination_missing_base'),
        ('existential_goal_capture', 'b, q, h = subst(a), *args, parts',
         'b, q, h = a, *args, parts', 'existential_eigenvariable_escape'),
        ('unchecked_vacuous_witness', '                    subst(t, formula=False)\n', '',
         'strict_vacuous_q_witness_00'),
    ]
    sensitivity = []
    for name, old, new, fixture in faults:
        if old not in source:
            sensitivity.append({'fault': name, 'status': 'source pattern not applicable'})
            continue
        namespace = {'__name__': 'audit_fault'}
        exec(compile(source.replace(old, new, 1), '<audit_fault>', 'exec'), namespace)
        mutant = type('Fault', (), {'check': staticmethod(namespace['check'])})
        row = next(row for row in explicit if row['name'] == fixture)
        detects = accepted(mutant, row['goal'], row['proof'], row['context'])
        sensitivity.append({'fault': name, 'fixture': fixture,
                            'status': 'detected' if detects else 'not detected'})
        if not detects:
            failures.append({'kind': 'fault sensitivity', 'fault': name, 'fixture': fixture})

    result = {
        'status': 'passed' if not failures else 'failed',
        'checker': str(checker),
        'checker_sha256': hashlib.sha256(checker.read_bytes()).hexdigest(),
        'reference_sha256': hashlib.sha256((ROOT / 'reference.py').read_bytes()).hexdigest(),
        'method': 'Sorted named-variable dataclasses, capture-free named substitution, '
                  'alpha equivalence, independent explicit rule interpretation',
        'targeted_fixtures': len(explicit),
        'targeted_accepts': sum(row['accepted'] for row in explicit),
        'targeted_rejects': sum(not row['accepted'] for row in explicit),
        'generated_rule_derivations': len(generated),
        'mutations': mutation_count,
        'accepted_mutations': accepted_mutations,
        'rejected_mutations': mutation_count - accepted_mutations,
        'named_substitution_comparisons': substitution_count,
        'public_cli_runs': cli_runs,
        'fault_sensitivity': sensitivity,
        'failures': failures,
        'limits': 'Finite regression evidence; no machine-checked general soundness '
                  'or completeness theorem is claimed. Internal open-sequent tests '
                  'use validated assumptions; the public interface remains theorem-only.',
    }
    (ROOT / 'fixtures.json').write_text(json.dumps(explicit, indent=2) + '\n')
    (ROOT / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--checker', type=Path, required=True)
    arguments = parser.parse_args()
    run(arguments.checker.resolve())
