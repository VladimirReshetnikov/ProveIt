"""Audit a strict unary-Q stack checker against a named interpreter and old trees."""
import argparse
from collections import Counter
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

import codec
import stack_reference as reference

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'frozen' / 'validation'))
import audit as legacy


def load(path, name):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    sys.modules[name] = module
    specification.loader.exec_module(module)
    return module


def clone(value):
    # This reproduces the intended unaliased finite-JSON storage boundary.
    return json.loads(json.dumps(value))


def candidate_accept(kernel, goal, stack, context=()):
    try:
        a, p, g = clone([goal, stack, list(context)])
        return kernel.check(a, p, g) is True
    except Exception:
        return False


def candidate_document(kernel, document):
    try:
        return kernel.check(*clone(document), []) is True
    except Exception:
        return False


def new_fixtures():
    E, S, R = legacy.E, legacy.S, legacy.R
    true, false = E(0, 0), E(0, S(0))
    rows = []

    def add(name, goal, stack, context=(), expected=False):
        rows.append({'name': name, 'goal': goal, 'stack': stack,
                     'context': list(context), 'accepted': expected, 'provenance': 'new stack fixture'})

    def tree(name, goal, proof, context=(), expected=True):
        add(name, goal, codec.to_stack(goal, proof), context, expected)

    def rigid_reflexivity(term):
        major = E(R(0, term, 0), term)
        return [major, 'r', E(1, reference.substitution(term, formula=False)), 'r']

    for parameter in (-1, -2, -1000):
        tree('rigid_reflexivity_' + str(-parameter), E(parameter, parameter), rigid_reflexivity(parameter))
        tree('rigid_existential_' + str(-parameter), ['ex', E(1, parameter)], [parameter, None])
    tree('rigid_constant_Q_under_eigenvariable', ['q', E(-1, -1)], [None])
    tree('rigid_recursion_outer_parameter', E(R(S(-1), -2, -3), -3), 'r')
    matrix = legacy.iteration_equation(1)
    tree('genuine_induction_at_rigid_parameter', legacy.iteration_equation(-1),
         [['q', matrix], [legacy.induction_step(1)], -1, 'r'])
    equality = E(-1, 0)
    tree('rigid_transport_beneath_existential', ['ex', E(1, 0)],
         [equality, None, ['ex', E(1, 2)], [-1, None]], [equality])
    add('distinct_rigid_parameters_do_not_collapse', E(-1, -2), [None], [E(-1, -1)])
    add('rigid_and_positive_parameters_do_not_collapse', E(-1, 1), [None], [E(-1, -1)])
    add('rigid_is_not_zero', E(-1, 0), [None])

    valid = codec.to_stack(true, legacy.reflexivity(0))
    add('unused_initial_stack_data_is_inert', true, [{'unused': [False, -7]}, 'ignored', *valid], expected=True)
    add('unread_suffix_changes_selected_instruction', true, [*valid, None])
    add('empty_stack_rejects_even_a_hypothesis', true, [], [true])
    for index, stack in enumerate([None, False, True, 0, 'stack', {}]):
        add('nonlist_stack_%02d' % index, true, stack)
    for length in range(len(valid)):
        add('truncated_reflexivity_%02d' % length, true, valid[length + 1:])
    add('incorrect_elimination_group_missing_annotation', true, [[true]])
    add('incorrect_elimination_group_extra_annotation', true, [[true, None, None]])
    add('unguarded_contradiction_hypothesis_is_absent', false, [None])

    # A selected malformed rule cannot be reinterpreted as a successful axiom.
    q = ['q', E(1, 0)]
    add('Q_hypothesis_can_use_fallback', q, [None], [q], True)
    add('selected_Q_intro_cannot_fall_back_after_missing_child', q, [[]], [q])
    bad_computation = E(R(1, 0, 1), 0)
    add('computation_hypothesis_can_use_fallback', bad_computation, [None], [bad_computation], True)
    add('selected_invalid_computation_cannot_fall_back', bad_computation, [[]], [bad_computation])
    add('failed_major_can_fall_back_to_hypothesis', true, [None, [false, None]], [true], True)
    add('failed_major_discards_only_its_consumed_trace', true,
        [{'unread': 1}, None, [], [q, 0]], [true], True)
    add('malformed_major_cannot_fall_back', true, [None, [['unknown', 0], None]], [true])
    add('exception_in_major_cannot_fall_back', true,
        [[], [bad_computation, None]], [true])

    existential = ['ex', E(1, 0)]
    exproof = [existential, [0, None], legacy.reflexivity(0)]
    stack = codec.to_stack(true, exproof)
    stack[-1][1] = {'unused': ['bad', False]}
    add('existential_elimination_ignores_its_placeholder', true, stack, expected=True)
    add('existential_branch_missing_from_stack', true, [None, [existential, None]], [existential])
    return rows


def legacy_cases():
    rows, skipped, adaptations = [], [], []
    for record in legacy.fixtures():
        try:
            stack = codec.to_stack(record['goal'], record['proof'], allow_malformed=True)
        except codec.Unsupported as error:
            skipped.append({'name': record['name'], 'reason': str(error)})
            continue
        expected = record['accepted']
        if record['name'] in ('strict_vacuous_q_witness_03', 'strict_existential_witness_03'):
            expected = True
            adaptations.append({'name': record['name'], 'reason': '-1 is now a legal rigid parameter',
                                'old_expected': False, 'new_expected': True})
        rows.append({'name': record['name'], 'goal': record['goal'], 'stack': stack,
                     'context': record['context'], 'accepted': expected,
                     'provenance': 'frozen predecessor fixture'})
    return rows, skipped, adaptations


def source_derivations():
    generated = legacy.generated_rules()
    logic = json.loads((ROOT / 'frozen' / 'examples' / 'logic' / 'logic_sequents.json').read_text())
    rows = []
    for record in [*generated, *logic]:
        rows.append({'name': record['name'], 'goal': record['goal'],
                     'stack': codec.to_stack(record['goal'], record['proof']),
                     'context': record['context'], 'accepted': True,
                     'provenance': 'generated predecessor rule' if record in generated else 'frozen logical encoding'})
    return rows


def verify_frozen_sources():
    manifest = json.loads((ROOT / 'frozen' / 'manifest.json').read_text())
    for entry in manifest['files']:
        actual = hashlib.sha256((ROOT / entry['local_file']).read_bytes()).hexdigest()
        if actual != entry['sha256']:
            raise ValueError('Changed frozen source: ' + entry['local_file'])
    return len(manifest['files'])


def run(checker, output, mutation_count=1200, substitution_count=360):
    verified_sources = verify_frozen_sources()
    kernel = load(checker, 'stack_candidate')
    predecessor = load(ROOT / 'frozen' / 'checker.py', 'frozen_tree_checker')
    legacy_rows, skipped, adaptations = legacy_cases()
    extras = new_fixtures()
    generated = source_derivations()
    fixtures = [*legacy_rows, *extras]
    rows = [*fixtures, *generated]
    failures = []
    event_counts = Counter()
    extraction_count = 0
    canonical_count = 0
    normalizations = 0

    def check_case(record, expected=None, require_exhaustion=False):
        nonlocal extraction_count, canonical_count, normalizations
        result = reference.analyze(record['goal'], record['stack'], record['context'])
        observed = candidate_accept(kernel, record['goal'], record['stack'], record['context'])
        if observed != result['accepted'] or expected is not None and observed != expected:
            failures.append({'kind': 'acceptance disagreement', 'name': record['name'],
                             'expected': expected, 'candidate': observed, 'oracle': result,
                             'case': record})
        if observed and result['accepted']:
            event_counts.update(result['events'])
            renamed_goal, renamed_tree, renamed_context, mapping = codec.eliminate_rigid(
                record['goal'], result['tree'], record['context'])
            old_named = reference.old.accept_sequent(renamed_goal, renamed_tree, renamed_context)
            old_compact = candidate_accept(predecessor, renamed_goal, renamed_tree, renamed_context)
            extraction_count += 1
            normalizations += bool(mapping)
            if not old_named or not old_compact:
                failures.append({'kind': 'extracted tree rejected', 'name': record['name'],
                                 'named': old_named, 'old_compact': old_compact,
                                 'mapping': mapping})
            canonical = codec.to_stack(record['goal'], result['tree'])
            rebuilt = reference.analyze(record['goal'], canonical, record['context'])
            if not rebuilt['accepted'] or rebuilt['remaining'] or not candidate_accept(
                    kernel, record['goal'], canonical, record['context']):
                failures.append({'kind': 'canonical round trip', 'name': record['name']})
            canonical_count += 1
            if require_exhaustion and result['remaining']:
                failures.append({'kind': 'canonical source left unread cells', 'name': record['name'],
                                 'remaining': result['remaining']})
        return observed

    for record in rows:
        check_case(record, record['accepted'], require_exhaustion=record in generated)

    rng = random.Random(73491)
    positives = [row for row in rows if row['accepted']]
    simple = [False, True, 0.0, -1, -9, 0, 1, 2, 3, None, 'r', 'x', [],
              ['s'], ['=', 0, 0], ['q', ['=', 1, 1]], {'x': 0}]
    accepted_mutations = 0
    for index in range(mutation_count):
        source = rng.choice(positives)
        pair = [source['goal'], source['stack']]
        where = rng.choice(list(legacy.paths(pair)))
        replacement = copy.deepcopy(rng.choice(simple)) if index % 3 else (
            legacy.term(rng) if index % 2 else legacy.formula(rng))
        mutant = legacy.changed(pair, where, replacement)
        if type(mutant) is list and len(mutant) == 2:
            record = {'name': 'stack_mutation_%04d' % index, 'goal': mutant[0],
                      'stack': mutant[1], 'context': source['context']}
            accepted_mutations += check_case(record)
        else:
            independent = reference.accept_document(mutant)
            observed = candidate_document(kernel, mutant)
            accepted_mutations += observed
            if independent != observed:
                failures.append({'kind': 'mutated document', 'number': index,
                                 'candidate': observed, 'oracle': independent, 'document': mutant})

    def add_rigids(data):
        if type(data) is int:
            return -rng.randrange(1, 6) if rng.randrange(4) == 0 else data
        if type(data) is list:
            return [add_rigids(v) for v in data]
        return data

    for index in range(substitution_count):
        formula = bool(index % 2)
        data = add_rigids(legacy.formula(rng) if formula else legacy.term(rng))
        prefix = [add_rigids(legacy.term(rng)) for _ in range(index % 4)]
        environment = prefix + [-len(prefix) if index % 3 else index % 4]
        depth = index % 4
        named = reference.substitution(data, environment, depth, formula)
        compact = kernel.subst(data, environment, depth, formula)
        if named != compact:
            failures.append({'kind': 'named substitution', 'number': index,
                             'data': data, 'environment': environment, 'depth': depth,
                             'formula': formula, 'named': named, 'compact': compact})

    source = checker.read_text()
    faults = [
        ('unrestricted_formula_induction', "([b] if b[0] == '=' else [])", '[b]',
         'forbidden_quantified_induction_hypothesis'),
        ('removed_equation_induction_hypothesis', "([b] if b[0] == '=' else [])", '[]',
         'equation_induction'),
        ('removed_retained_base', "[subst(b, [0, 0])] + ([b] if b[0] == '=' else [])",
         "([b] if b[0] == '=' else [])", 'equation_rule_uses_retained_base'),
        ('omitted_Q_elimination_minor', 'return c == a and check(b, p, g)', 'return c == a',
         'q_elimination_missing_base'),
        ('existential_eigenvariable_capture', 'b, h = subst(a), parts', 'b, h = a, parts',
         'existential_eigenvariable_escape'),
        ('unchecked_vacuous_witness', '                    subst(t, formula=False)\n', '',
         'strict_vacuous_q_witness_00'),
        ('shifted_rigid_parameter', 'return a if i <= 0 else', 'return a if i == 0 else',
         'rigid_existential_1'),
    ]
    sensitivities = []
    for name, old, new, fixture in faults:
        if source.count(old) != 1:
            failures.append({'kind': 'fault not applied exactly once', 'name': name,
                             'occurrences': source.count(old)})
            continue
        namespace = {'__name__': 'fault_injected_kernel'}
        exec(compile(source.replace(old, new, 1), '<fault_injected_kernel>', 'exec'), namespace)
        mutant = type('Fault', (), {'check': staticmethod(namespace['check'])})
        record = next(row for row in fixtures if row['name'] == fixture)
        observed = candidate_accept(mutant, record['goal'], record['stack'], record['context'])
        detected = observed != record['accepted']
        sensitivities.append({'fault': name, 'fixture': fixture,
                              'expected': record['accepted'], 'mutant_accepts': observed,
                              'detected': detected})
        if not detected:
            failures.append({'kind': 'undetected fault', 'name': name, 'fixture': fixture})

    true, false = legacy.E(0, 0), legacy.E(0, legacy.S(0))
    certificate = codec.to_stack(true, legacy.reflexivity(0))
    public = [
        ('canonical_theorem', [true, certificate], True),
        ('false_theorem', [false, [None]], False),
        ('third_field_cannot_supply_context', [false, [None], [false]], False),
        ('third_empty_field_is_not_allowed', [true, certificate, []], False),
        ('missing_proof', [true], False),
        ('missing_goal', [], False),
        ('null_document', None, False),
        ('object_document', {'goal': true, 'stack': certificate}, False),
        ('inert_prefix_is_allowed', [true, [{'unused': True}, *certificate]], True),
    ]
    for name in ('forbidden_quantified_induction_hypothesis', 'strict_vacuous_q_witness_00',
                 'invalid_boolean_in_computation', 'equation_rule_uses_retained_base',
                 'genuine_induction_at_rigid_parameter', 'rigid_existential_1'):
        row = next(row for row in fixtures if row['name'] == name)
        if row['context']:
            raise ValueError('CLI fixture has assumptions: ' + name)
        public.append((name, [row['goal'], row['stack']], row['accepted']))
    cli_count = 0
    cli_records = []
    with tempfile.TemporaryDirectory() as temp:
        directory = Path(temp)
        for optimized in (False, True):
            command = [sys.executable, *(['-O'] if optimized else []), str(checker)]
            for name, document, expected in public:
                path = directory / (name + '.json')
                path.write_text(json.dumps(document))
                result = subprocess.run([*command, str(path)], capture_output=True, text=True, timeout=15)
                passed = (result.returncode == (0 if expected else 1)
                          and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT'))
                cli_records.append({'name': name, 'optimized': optimized, 'passed': passed,
                                    'exit': result.returncode, 'stdout': result.stdout.strip()})
                if not passed:
                    failures.append({'kind': 'CLI', 'case': cli_records[-1], 'stderr': result.stderr})
                cli_count += 1
            bad = directory / 'malformed.json'
            invalid_utf8 = directory / 'invalid_utf8.json'
            bad.write_bytes(b'{this is not JSON')
            invalid_utf8.write_bytes(b'\xff')
            argument_cases = [([], 'no_filename'), ([str(bad)], 'malformed_JSON'),
                              ([str(invalid_utf8)], 'invalid_UTF8'),
                              ([str(directory / 'missing.json')], 'missing_file'),
                              ([str(bad), str(bad)], 'too_many_arguments')]
            for arguments, name in argument_cases:
                result = subprocess.run([*command, *arguments], capture_output=True, text=True, timeout=15)
                passed = result.returncode == 1 and result.stdout.strip() == 'REJECT'
                cli_records.append({'name': name, 'optimized': optimized, 'passed': passed,
                                    'exit': result.returncode, 'stdout': result.stdout.strip()})
                if not passed:
                    failures.append({'kind': 'CLI', 'case': cli_records[-1], 'stderr': result.stderr})
                cli_count += 1

    output.mkdir(parents=True, exist_ok=True)
    examples = output / 'examples'
    examples.mkdir(exist_ok=True)
    example_rows = [row for row in fixtures + generated if row['accepted'] and not row['context']
                    and row['provenance'] != 'generated predecessor rule'
                    and row['name'] not in ('unused_initial_stack_data_is_inert',
                                           'existential_elimination_ignores_its_placeholder')]
    emitted = []
    for row in example_rows:
        outcome = reference.analyze(row['goal'], row['stack'])
        canonical = codec.to_stack(row['goal'], outcome['tree'])
        path = examples / (row['name'] + '.json')
        path.write_text(json.dumps([row['goal'], canonical], indent=2) + '\n')
        emitted.append({'name': row['name'], 'file': 'examples/' + path.name,
                        'instructions': len(canonical)})
    (output / 'fixtures.json').write_text(json.dumps(fixtures, indent=2) + '\n')
    (output / 'examples_manifest.json').write_text(json.dumps(emitted, indent=2) + '\n')
    result = {
        'status': 'passed' if not failures else 'failed',
        'checker_sha256': hashlib.sha256(checker.read_bytes()).hexdigest(),
        'named_stack_oracle_sha256': hashlib.sha256((ROOT / 'stack_reference.py').read_bytes()).hexdigest(),
        'frozen_files_verified': verified_sources,
        'legacy_targeted_fixtures': len(legacy_rows),
        'legacy_layout_cases_not_translatable': skipped,
        'rigid_syntax_adaptations': adaptations,
        'new_stack_fixtures': len(extras),
        'targeted_fixtures': len(fixtures),
        'targeted_accepts': sum(row['accepted'] for row in fixtures),
        'targeted_rejects': sum(not row['accepted'] for row in fixtures),
        'translated_generated_and_logical_derivations': len(generated),
        'mutations': mutation_count, 'accepted_mutations': accepted_mutations,
        'rejected_mutations': mutation_count - accepted_mutations,
        'named_substitution_comparisons': substitution_count,
        'accepted_traces_rechecked_by_both_frozen_tree_checkers': extraction_count,
        'accepted_traces_canonicalized_and_exhausted': canonical_count,
        'extractions_with_rigid_parameter_elimination': normalizations,
        'named_interpreter_rule_visits_on_accepted_inputs': dict(event_counts),
        'fault_sensitivity': sensitivities, 'public_CLI_runs': cli_count,
        'canonical_theorem_example_files': len(emitted), 'CLI_records': cli_records,
        'failures': failures,
        'limits': 'Finite regression evidence; no general proof of soundness, completeness or '
                  'bi-interpretability is formalized here. Internal open-sequent tests use '
                  'well-formed assumptions. The public CLI remains theorem-only. The original '
                  'named oracle and compact tree checker are preserved unchanged.'}
    (output / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('CLI_records', 'failures')}, indent=2))
    if failures:
        print(json.dumps({'failures': failures[:12]}, indent=2))
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', required=True, type=Path)
    parser.add_argument('--output', type=Path, default=ROOT / 'results')
    parser.add_argument('--mutations', type=int, default=1200)
    arguments = parser.parse_args()
    run(arguments.checker.resolve(), arguments.output.resolve(), arguments.mutations)
