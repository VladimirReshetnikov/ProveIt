INDEPENDENT VALIDATION OF THE UNARY-Q STACK PRESENTATION

RUN
    python3 validation/verify.py --checker checker.py
    python3 validation/verify_demand.py --strict checker.py --demand checker_demand.py

The commands assume this directory has been placed at validation/ beside the
acceptance programs. Every path internal to the harness is relative to its own
location. Both programs use only the Python standard library. They do not
modify the candidate. Output defaults to validation/results/.

PRIMARY CHECKER: EXECUTED EVIDENCE
    139 targeted fixtures: 48 accepted and 91 rejected
    688 generated/logical derivations: 630 rule instances and 58 logic proofs
    1,200 bounded deterministic stack/formula mutations: 116 accepted
    360 substitutions compared with independent named substitution
    40 actual command-line runs, including ordinary Python and Python -O
    852 accepted executions reconstructed and checked by both frozen oracles
    852 successful canonical round trips to completely consumed stacks
    24 reconstructed accepted executions needed rigid-parameter elimination
    Seven deliberately injected faults detected by focused fixtures
    44 canonical theorem files emitted in results/examples/

The seven fault checks are unrestricted formula induction, removal of the
atomic induction hypothesis, removal of the retained base hypothesis, omission
of the Q-elimination base minor, existential eigenvariable capture, omission of
strict validation of a vacuous witness, and accidental shifting of a rigid
parameter. Each mutation changes exactly one candidate source location. Tests
cover both unsound acceptance and incomplete rejection where relevant.

DEMAND COMPANION: EXECUTED EVIDENCE
    All 736 canonical positive strict fixture derivations also accepted demand
    24 malformed but syntactically unused witnesses accepted and repaired
      (12 at the matrix root and 12 beneath an existential binder)
    36 malformed syntactically used witnesses rejected
      (including occurrences in arithmetically dead recursion branches)
    760 accepted demand traces rebuilt as fully consumed strict stacks
    760 extracted repaired trees checked by both unchanged frozen oracles
    12 actual strict/demand command-line comparisons, including Python -O

The demand rule only skips checking an annotation when its distinguished
variable does not occur syntactically in the matrix. The named interpreter
checks occurrence by names and substitutes zero in the extracted strict tree
when a witness is unused. It separately records 79 erased annotations, of which
24 were malformed. The corresponding main and repaired concrete examples are
results/demand_example.json and results/demand_example_repaired.json.

METHOD AND TRUST BOUNDARY
stack_reference.py parses formulas and terms into sorted named-variable
objects from the unchanged predecessor reference. It generates fresh names,
substitutes by names, compares alpha-normal forms, and reads the certificate
with an explicit cursor. It does not use the candidate's substitution routine,
width table, pattern dispatch, or proof checker.

Each successful stack execution produces an ordinary predecessor proof tree.
Failed major attempts can consume instructions before a hypothesis fallback;
such unsuccessful attempts are omitted from the extracted tree. Any selected
malformed inference raises an exception and cannot silently fall back. Unread
initial stack data are ignored by the prefix interface. Canonical compilation
uses no unused prefix and its reconstructed proof exhausts the stack.

Rigid negative codes are eliminated injectively into fresh positive free
number parameters above every positive coordinate occurring in the entire
finite proof. The renaming accounts separately for logical binders, recursion
binders, equality-motive holes, and proof eigenvariables. After this renaming,
every accepted extracted tree is checked with BOTH unchanged files:
    frozen/checker.py
    frozen/validation/reference.py
Thus the old numerical-binder code remains exactly as supplied in its archive;
its original refusal of negative syntax codes is not patched or bypassed.

codec.py is an untrusted tree-to-stack producer and rigid renamer. It compiles
the canonical explicit tree-rule shapes. A general arbitrary malformed tree
format is not claimed to translate losslessly. Of 102 inherited targeted
fixtures, 101 have comparable stack encodings. The old existential-elimination
wrong-branch-count shape cannot occur in a flat stack; it is recorded as not
translatable and replaced by missing-premise/wrong-instruction stack tests.
Two inherited rejection expectations change because the witness -1 is now a
legal rigid parameter. Those changes are explicit in results/results.json.
All remaining negative fixtures retain the intended protection.

The in-process check(goal,stack,context) method has a well-formed-context
precondition. Open-sequent fixtures use independently validated assumptions;
they are not unconditional theorem claims. The public interface is exactly
[goal,stack] and always starts with an empty context. Public attempts to supply
an assumption list or any third field are rejected.

All tests use finite JSON-shaped trees without mutable aliases. JSON parsing
provides that storage discipline. Python resource limits are not proof-theoretic
bounds. These are finite regression and differential checks; they are not a
machine-checked general soundness, completeness or bi-interpretability proof.
Several groups overlap, so their counts must not be summed as distinct theorems.

FILES
    verify.py                 Main independent test runner and example producer
    verify_demand.py          Focused strict inclusion and zero-erasure audit
    stack_reference.py        Named stack interpreter with tree extraction
    codec.py                  Untrusted tree producer and rigid renaming
    frozen/                   Unchanged source proofs, checker, oracle, builders
    frozen/manifest.json      Exact archive provenance and hashes for 11 files
    results/results.json      Main executed results and all CLI outcomes
    results/demand_results.json Focused companion results
    results/fixtures.json     Explicit main test data
    results/demand_fixtures.json Focused witness erasure test data
    results/examples/         Forty-four canonical accepted theorem inputs
    results/examples_manifest.json Their names and instruction counts

The frozen material comes from ipra_unary_numerical_binder_2026-11-06.zip,
Git blob c21c9e7112903e433e695fb453ad3661f08e4b0e in the pinned six-archive
comparison corpus. Its original source-license record is retained in
frozen/LICENSE_SOURCE.txt. No acceptance program imports any audit file.
