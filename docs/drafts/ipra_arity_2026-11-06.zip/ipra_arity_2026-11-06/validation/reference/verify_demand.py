"""Focused demand-witness erasure check; every accepted trace becomes strict."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import codec
import stack_reference as reference
import verify

ROOT = Path(__file__).resolve().parent


def run(strict_path, demand_path, output):
    strict = verify.load(strict_path, 'strict_for_erasure')
    demand = verify.load(demand_path, 'demand_for_erasure')
    predecessor = verify.load(ROOT / 'frozen' / 'checker.py', 'tree_for_erasure')
    verify.verify_frozen_sources()
    old_fixtures, _, _ = verify.legacy_cases()
    old_generated = verify.source_derivations()
    positives = [r for r in [*old_fixtures, *verify.new_fixtures(), *old_generated] if r['accepted']]
    failures = []
    strict_inclusions = 0
    repairs = 0
    erased = 0
    malformed_erased = 0

    def inspect(row, expected=True, canonical=False):
        nonlocal repairs, erased, malformed_erased
        outcome = reference.analyze(row['goal'], row['stack'], row['context'], demand=True)
        observed = verify.candidate_accept(demand, row['goal'], row['stack'], row['context'])
        if observed != expected or observed != outcome['accepted']:
            failures.append({'kind': 'demand acceptance', 'name': row['name'],
                             'expected': expected, 'candidate': observed, 'oracle': outcome})
        if observed and outcome['accepted']:
            tree = outcome['tree']
            repaired = codec.to_stack(row['goal'], tree)
            strict_trace = reference.analyze(row['goal'], repaired, row['context'])
            g, p, assumptions, mapping = codec.eliminate_rigid(row['goal'], tree, row['context'])
            if (not strict_trace['accepted'] or strict_trace['remaining']
                    or not verify.candidate_accept(strict, row['goal'], repaired, row['context'])
                    or not reference.old.accept_sequent(g, p, assumptions)
                    or not verify.candidate_accept(predecessor, g, p, assumptions)):
                failures.append({'kind': 'erasure to strict proof', 'name': row['name']})
            if canonical and outcome['remaining']:
                failures.append({'kind': 'canonical demand input left cells', 'name': row['name']})
            repairs += 1
            erased += outcome['erased_witnesses']
            malformed_erased += outcome['erased_malformed_witnesses']
        return observed

    for row in positives:
        trace = reference.analyze(row['goal'], row['stack'], row['context'])
        canonical = {**row, 'stack': codec.to_stack(row['goal'], trace['tree'])}
        if not verify.candidate_accept(strict, canonical['goal'], canonical['stack'], canonical['context']):
            failures.append({'kind': 'strict source fixture', 'name': row['name']})
        inspect(canonical, canonical=True)
        strict_inclusions += 1

    # The predecessor's exact strict-unused-witness corpus is reused. It includes
    # malformed booleans, floats, unknown constructors, wrong arities and objects.
    unused = [row for row in old_fixtures if row['name'].startswith('strict_vacuous_q_witness_')
              and not row['accepted']]
    for row in unused:
        if verify.candidate_accept(strict, row['goal'], row['stack'], row['context']):
            failures.append({'kind': 'strict accepted malformed unused witness', 'name': row['name']})
        inspect(row)

    E, S, R = verify.legacy.E, verify.legacy.S, verify.legacy.R
    true = E(0, 0)
    malformed = [False, True, 0.0, '0', [], ['s'], ['s', 0, 0], ['q', true],
                 ['r', 0, 0], ['r', 0, 0, true], {'s': 0}, None]
    used = []
    nested_unused = []
    for index, witness in enumerate(malformed):
        for kind, body, goal, minor in (
                ('equation', E(1, 0), true, verify.legacy.reflexivity(0)),
                ('nested_existential', ['ex', E(1, 2)], ['ex', E(1, 0)], [0, None]),
                ('syntactically_used_in_dead_recursion', E(R(0, 0, 3), 0), E(R(0, 0, 0), 0), 'r')):
            major = ['q', body]
            tree = [major, None, witness, minor]
            row = {'name': 'used_' + kind + '_%02d' % index,
                   'goal': goal, 'stack': codec.to_stack(goal, tree), 'context': [major]}
            used.append(row)
            inspect(row, False)
        body = ['ex', E(1, 1)]
        major = ['q', body]
        goal = body
        tree = [major, [None], witness, [0, verify.legacy.reflexivity(1)]]
        row = {'name': 'unused_beneath_existential_%02d' % index,
               'goal': goal, 'stack': codec.to_stack(goal, tree), 'context': []}
        nested_unused.append(row)
        inspect(row)
        if verify.candidate_accept(strict, row['goal'], row['stack'], row['context']):
            failures.append({'kind': 'strict nested-vacuous validation', 'name': row['name']})

    # Real CLI comparison exposes the policy difference and its strict repair.
    source = unused[0]
    result = reference.analyze(source['goal'], source['stack'], demand=True)
    repaired = codec.to_stack(source['goal'], result['tree'])
    nonvacuous_major = ['q', E(1, 1)]
    nonvacuous_tree = [nonvacuous_major, [verify.legacy.reflexivity(S(1))],
                        False, verify.legacy.reflexivity(0)]
    nonvacuous = {'goal': true, 'stack': codec.to_stack(true, nonvacuous_tree)}
    public = [('malformed_unused', [source['goal'], source['stack']], False, True),
              ('repaired_unused', [source['goal'], repaired], True, True),
              ('malformed_used', [nonvacuous['goal'], nonvacuous['stack']], False, False)]
    cli_count = 0
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary)
        for optimized in (False, True):
            for name, document, strict_expected, demand_expected in public:
                path = directory / (name + '.json')
                path.write_text(json.dumps(document))
                for program, expected in ((strict_path, strict_expected), (demand_path, demand_expected)):
                    completed = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                                str(program), str(path)], capture_output=True,
                                               text=True, timeout=15)
                    if (completed.returncode != (0 if expected else 1)
                            or completed.stdout.strip() != ('ACCEPT' if expected else 'REJECT')):
                        failures.append({'kind': 'demand CLI', 'name': name, 'program': program.name,
                                         'optimized': optimized, 'exit': completed.returncode,
                                         'stdout': completed.stdout, 'stderr': completed.stderr})
                    cli_count += 1

    output.mkdir(parents=True, exist_ok=True)
    result = {'status': 'passed' if not failures else 'failed',
              'strict_sha256': hashlib.sha256(strict_path.read_bytes()).hexdigest(),
              'demand_sha256': hashlib.sha256(demand_path.read_bytes()).hexdigest(),
              'canonical_strict_derivations_also_accepted_demand': strict_inclusions,
              'malformed_unused_witness_cases': len(unused),
              'malformed_unused_witnesses_under_quantifier': len(nested_unused),
              'malformed_used_witnesses_rejected': len(used),
              'accepted_demand_traces_repaired_to_exhausted_strict_stacks': repairs,
              'extracted_repairs_checked_by_both_unchanged_tree_oracles': repairs,
              'vacuous_annotations_erased': erased,
              'malformed_vacuous_annotations_erased': malformed_erased,
              'actual_CLI_comparisons': cli_count,
              'failures': failures,
              'scope': 'Focused finite evidence for strict inclusion and erasure. Only syntactic '
                       'vacuity permits witness omission; a witness occurring inside a recursion '
                       'branch still has to be a term even if that branch is arithmetically dead. '
                       'General equality of theorem sets requires the mathematical erasure proof.'}
    (output / 'demand_results.json').write_text(json.dumps(result, indent=2) + '\n')
    (output / 'demand_fixtures.json').write_text(json.dumps([*unused, *nested_unused, *used], indent=2) + '\n')
    (output / 'demand_example.json').write_text(json.dumps([source['goal'], source['stack']], indent=2) + '\n')
    (output / 'demand_example_repaired.json').write_text(json.dumps([source['goal'], repaired], indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--strict', required=True, type=Path)
    parser.add_argument('--demand', required=True, type=Path)
    parser.add_argument('--output', type=Path, default=ROOT / 'results')
    arguments = parser.parse_args()
    run(arguments.strict.resolve(), arguments.demand.resolve(), arguments.output.resolve())
