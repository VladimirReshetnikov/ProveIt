"""Untrusted tree/stack conversion and rigid-parameter elimination.

Every emitted proof must be checked. No acceptance kernel imports this module.
"""
from copy import deepcopy
import json
from pathlib import Path
import sys

import stack_reference as reference


class Unsupported(ValueError):
    pass


def shifted(formula):
    return reference.substitution(formula)


def instance(formula, term):
    return reference.substitution(formula, (term, -1))


def _child_goal(action, fallback=False):
    try:
        return action()
    except Exception:
        if fallback:
            return ['=', 0, 0]
        raise


def preorder(goal, proof, allow_malformed=False):
    """Convert the explicit tree-rule shapes into root-first instructions.

    allow_malformed is solely for transporting adversarial fixtures. A malformed
    motive's unvisited child may use a placeholder goal; the malformed motive
    itself is preserved and must be rejected before that child can be reached.
    Source trees with incompatible branch counts are explicitly unsupported.
    """
    is_list = type(proof) is list
    if (type(goal) is list and len(goal) == 2 and goal[0] == 'q'
            and is_list and len(proof) == 1):
        child = _child_goal(lambda: reference.substitution(goal[1], (['s', 1], 0)), allow_malformed)
        return [[], *preorder(child, proof[0], allow_malformed)]
    if (type(goal) is list and len(goal) == 2 and goal[0] == 'ex'
            and is_list and len(proof) == 2):
        witness, child = proof
        return [[deepcopy(witness)], *preorder(goal[1], child, allow_malformed)]
    if is_list and len(proof) >= 2 and type(proof[0]) is list and proof[0]:
        major, major_proof, *arguments = proof
        tag = major[0]
        if tag == 'ex' and len(major) == 2 and len(arguments) == 1:
            minor_goal = _child_goal(lambda: shifted(goal), allow_malformed)
            annotation, minor = None, arguments[0]
        elif tag in ('q', '=') and len(arguments) == 2:
            annotation, minor = arguments
            minor_goal = _child_goal(lambda: instance(major[1], 0) if tag == 'q'
                                     else instance(annotation, major[1]), allow_malformed)
        else:
            raise Unsupported('Tree elimination has incompatible major or branch count')
        return [[deepcopy(major), deepcopy(annotation)],
                *preorder(major, major_proof, allow_malformed),
                *preorder(minor_goal, minor, allow_malformed)]
    if (type(goal) is list and len(goal) == 3 and goal[0] == '='
            and type(goal[1]) is list and len(goal[1]) == 4 and goal[1][0] == 'r'
            and proof == 'r'):
        return [[]]
    return [None]


def to_stack(goal, proof, allow_malformed=False):
    return list(reversed(preorder(goal, proof, allow_malformed)))


def integers(data):
    if type(data) is int:
        yield data
    elif type(data) is list:
        for child in data:
            yield from integers(child)


def eliminate_rigid(goal, proof, context=()):
    """Injectively rename rigid codes to new positive free number parameters.

    Choose fresh positive coordinates larger than every positive integer code
    anywhere in the entire derivation. Under a local binder/eigenvariable, add
    its depth; this preserves old positive coordinates and prevents capture.
    """
    values = list(integers([goal, proof, list(context)]))
    start = max([0, *[n for n in values if n > 0]])
    mapping = {n: start + i + 1 for i, n in enumerate(sorted(set(n for n in values if n < 0)))}

    def term(data, depth):
        if type(data) is int:
            return mapping[data] + depth if data < 0 else data
        if data[0] == 's':
            return ['s', term(data[1], depth)]
        if data[0] == 'r':
            return ['r', term(data[1], depth), term(data[2], depth), term(data[3], depth + 2)]
        raise ValueError('Malformed canonical term')

    def formula(data, depth):
        if data[0] == '=':
            return ['=', term(data[1], depth), term(data[2], depth)]
        if data[0] in ('q', 'ex'):
            return [data[0], formula(data[1], depth + 1)]
        raise ValueError('Malformed canonical formula')

    def derivation(current, certificate, depth):
        if certificate is None or certificate == 'r':
            return certificate
        if current[0] == 'q' and len(certificate) == 1:
            child_goal = reference.substitution(current[1], (['s', 1], 0))
            return [derivation(child_goal, certificate[0], depth + 1)]
        if current[0] == 'ex' and len(certificate) == 2:
            witness, child = certificate
            return [term(witness, depth), derivation(current[1], child, depth + 1)]
        major, major_proof, *arguments = certificate
        first = formula(major, depth)
        first_proof = derivation(major, major_proof, depth)
        if major[0] == 'ex':
            child, = arguments
            return [first, first_proof, derivation(shifted(current), child, depth + 1)]
        annotation, child = arguments
        if major[0] == 'q':
            changed_annotation = term(annotation, depth)
            premise = instance(major[1], 0)
        else:
            changed_annotation = formula(annotation, depth + 1)
            premise = instance(annotation, major[1])
        return [first, first_proof, changed_annotation, derivation(premise, child, depth)]

    return (formula(goal, 0), derivation(goal, proof, 0),
            [formula(item, 0) for item in context], mapping)


def main():
    source, target = map(Path, sys.argv[1:])
    document = json.loads(source.read_text())
    if type(document) is not list or len(document) != 2:
        raise ValueError('Expected a predecessor theorem [goal, proof]')
    goal, tree = document
    stack = to_stack(goal, tree)
    outcome = reference.analyze(goal, stack)
    if not outcome['accepted'] or outcome['remaining']:
        raise ValueError('Converted theorem does not have a canonical accepted stack')
    renamed_goal, renamed_tree, renamed_context, _ = eliminate_rigid(goal, outcome['tree'])
    if not reference.old.accept_sequent(renamed_goal, renamed_tree, renamed_context):
        raise ValueError('Independent predecessor rejects the extracted derivation')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps([goal, stack], indent=2) + '\n')


if __name__ == '__main__':
    main()
