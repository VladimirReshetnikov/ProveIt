"""Independent named-variable comparisons for the arity checker.

The kernel imports none of this file or the frozen oracle. This is evidence,
not a formalized proof of the checker or its bi-interpretation theorem.
"""
from pathlib import Path
import copy
import importlib.util
import json
import random
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / 'validation' / 'reference'
sys.path.insert(0, str(REF))


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


suite = load(REF / 'verify.py', 'frozen_suite')
oracle = suite.reference
strict = load(ROOT / 'checker.py', 'arity_strict')
demand = load(ROOT / 'checker_demand.py', 'arity_demand')


def encode(a, formula=True, pad=None):
    """Untrusted syntax encoder; does not call candidate substitution."""
    if not formula and type(a) is int:
        return a
    if type(a) is not list or not a:
        raise ValueError('Not a source expression')
    tag, *args = a
    if formula:
        if tag == '=' and len(args) == 2:
            return [encode(x, False, pad) for x in args]
        if tag in ('q', 'u') and len(args) == 1:
            return [encode(args[0], True, pad)]
        if tag == 'ex' and len(args) == 1:
            padding = [[0, 0], [0, 0]] if pad is None else copy.deepcopy(pad)
            return [encode(args[0], True, pad), *padding]
    elif tag in ('s', 'r') and len(args) == (1 if tag == 's' else 3):
        return [encode(x, False, pad) for x in args]
    raise ValueError('Source sort/arity error')


def stack_encode(stack, pad=None):
    result = []
    for instruction in stack:
        if type(instruction) is list and len(instruction) == 1:
            result.append([encode(instruction[0], False, pad)])
        elif type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            encoded_major = encode(major, True, pad)
            if major[0] == '=':
                annotation = encode(annotation, True, pad)
            elif major[0] in ('q', 'u'):
                annotation = encode(annotation, False, pad)
            result.append([encoded_major, copy.deepcopy(annotation)])
        else:
            result.append(copy.deepcopy(instruction))
    return result


def accept(kernel, goal, stack, context=()):
    try:
        a, p, g = copy.deepcopy([goal, stack, list(context)])
        result = kernel.check(a, p, g)
        return result is True, len(p)
    except Exception:
        return False, None


def run():
    failures, checks, skipped = [], [], []
    examples = ROOT / 'examples'
    examples.mkdir(exist_ok=True)

    def compare(row, kind, exact=False, pad=None):
        try:
            a = encode(row['goal'], pad=pad)
            p = stack_encode(row['stack'], pad)
            g = [encode(x, pad=pad) for x in row.get('context', ())]
        except (ValueError, TypeError, IndexError) as error:
            skipped.append({'name': row['name'], 'kind': kind, 'reason': str(error)})
            return
        named = oracle.analyze(row['goal'], row['stack'], row.get('context', ()))
        observed, remaining = accept(strict, a, p, g)
        if observed != named['accepted'] or (exact and observed and remaining):
            failures.append({'kind': kind, 'name': row['name'], 'candidate': observed,
                             'oracle': named['accepted'], 'remaining': remaining})
        demand_result, _ = accept(demand, a, p, g)
        if demand_result != observed:
            failures.append({'kind': 'wellformed policy mismatch', 'name': row['name']})
        checks.append({'kind': kind, 'name': row['name'], 'accepted': observed,
                       'closed': not g, 'remaining': remaining})
        if exact and not g and row['provenance'] == 'frozen logical encoding':
            (examples / (row['name'] + '.json')).write_text(json.dumps([a, p], indent=2) + '\n')

    positive = suite.source_derivations()
    for row in positive:
        compare(row, 'translated_derivation', True)
    for row in suite.legacy_cases()[0] + suite.new_fixtures():
        compare(row, 'wellformed_source_fixture')

    # Closed noncanonical annotations commute with all numerical substitutions.
    for row in positive[-58:]:
        compare(row, 'noncanonical_existential_padding', True,
                pad=[[0, [0]], [[[0, 0]]]])

    rng = random.Random(20261106)
    for i in range(1200):
        formula = bool(i % 2)
        a = suite.legacy.formula(rng) if formula else suite.legacy.term(rng)
        depth = i % 4
        count = i % 3
        env = [suite.legacy.term(rng) for _ in range(count)] + [rng.choice([-count, 0, 1, 3])]
        expected = oracle.substitution(a, env, depth, formula)
        actual = strict.subst(encode(a, formula), [*(encode(x, False) for x in env[:-1]), env[-1]], depth, formula)
        if actual != encode(expected, formula):
            failures.append({'kind': 'named substitution disagreement', 'index': i})

    # Mutations preserve source syntax when possible. Truth is decided by the
    # independent named interpreter, not by an expected blanket rejection.
    for i in range(900):
        row = copy.deepcopy(rng.choice(positive))
        row['name'] = 'typed_mutation_%04d' % i
        if i % 4 == 0:
            row['goal'] = suite.legacy.formula(rng)
        elif i % 4 == 1 and row['stack']:
            del row['stack'][rng.randrange(len(row['stack']))]
        elif i % 4 == 2 and len(row['stack']) > 1:
            x, y = rng.sample(range(len(row['stack'])), 2)
            row['stack'][x], row['stack'][y] = row['stack'][y], row['stack'][x]
        elif row['stack']:
            row['stack'][rng.randrange(len(row['stack']))] = rng.choice([None, []])
        compare(row, 'typed_mutation')

    adversarial = []

    def case(name, a, p, g=(), want=False, want_demand=None):
        got, _ = accept(strict, a, p, g)
        got_demand, _ = accept(demand, a, p, g)
        if want_demand is None:
            want_demand = want
        if (got, got_demand) != (want, want_demand):
            failures.append({'kind': 'adversarial', 'name': name,
                             'got': [got, got_demand], 'expected': [want, want_demand]})
        adversarial.append({'name': name, 'strict': got, 'demand': got_demand,
                            'expected': want, 'demand_expected': want_demand})

    truth = [0, 0]
    false = [0, [0]]
    refl = [[], [], [[[0, 0, 0], 0], [1, 0]]]
    case('reflexivity_zero', truth, refl, want=True)
    case('unproved_contradiction', false, [None])
    case('unread_stack_padding', truth, [{'inert': False}, *refl], want=True)
    for i, value in enumerate([True, False, 0.0, 'x', {}, None, [], [0, 0], [0, 0, 0, 0]]):
        bad = [value, value]
        case('bad_term_%02d' % i, bad, [None], [bad])
    for i, value in enumerate([True, 0, 0.0, 'ab', {}, None, [], [0], [0, 0, 0], [truth] * 4]):
        case('bad_formula_%02d' % i, value, [None], [value])
    ex = [[1, 0], truth, truth]
    case('existential_zero', ex, [None, [0]], want=True)
    case('false_padding_is_not_an_assumption', false, [None, None, [ex, None]], [ex])
    decorated = [[1, 0], false, [truth]]
    case('wellformed_arbitrary_padding', decorated, [None, [0]], want=True)
    for i, badpad in enumerate([0, True, [], [0], [0, 0, 0], ['s', 0]]):
        case('malformed_ignored_padding_%02d' % i, [[1, 0], badpad, truth], [None, [0]])
    case('eigenvariable_escape', [1, 0], [None, None, [ex, None]], [ex])
    case('failed_pattern_saved_lift_regression', [[1, 0]], [None, None, [ex, None]], [ex])
    case('successor_computation', [[[0], 0, 2], 0], [[]], want=True)
    case('zero_computation', [[0, [0], 0], [0]], [[]], want=True)
    case('variable_is_not_a_successor', [[1, 0, 0], 0], [[]])
    case('rigid_parameter_is_not_a_successor', [[-1, 0, 0], 0], [[]])
    case('recursor_is_not_a_successor', [[[0, 0, 0], 0, 0], 0], [[]])
    qtrue = [truth]
    # Canonical Q proof uses its retained base, and the minor proves 0=0.
    case('vacuous_witness_policy', truth, [*refl, None, [], [qtrue, {'invalid': True}]],
         want=False, want_demand=True)
    case('used_malformed_witness', truth, [*refl, None, [], [[[1, 1]], {'invalid': True}]])
    case('missing_Q_base', false, [None, [[false], 0]], [[false]])
    case('vacuous_nested_closure', [[[[1, 0], truth, truth]]], [None, []], want=True)
    forbidden = next(row for row in suite.legacy_cases()[0]
                     if row['name'] == 'forbidden_quantified_induction_hypothesis')
    case('forbidden_compound_induction_hypothesis', encode(forbidden['goal']),
         stack_encode(forbidden['stack']))

    # Exercise the actual public JSON interface, including malformed JSON and
    # attempted injection of assumptions. Runtime optimization does not remove
    # any syntax checks in this checker.
    cli = []
    documents = [('true', [truth, refl], True), ('false', [false, [None]], False),
                 ('extra_context', [false, [None], [false]], False),
                 ('padding_theorem', [decorated, [None, [0]]], True),
                 ('bad_goal', [True, [None]], False)]
    with tempfile.TemporaryDirectory() as directory:
        for mode in ([], ['-O']):
            for name, document, expected in documents:
                file = Path(directory) / (name + '.json')
                file.write_text(json.dumps(document))
                process = subprocess.run([sys.executable, *mode, str(ROOT / 'checker.py'), str(file)],
                                         text=True, capture_output=True, timeout=10)
                good = process.returncode == (0 if expected else 1) and process.stdout.strip() == ('ACCEPT' if expected else 'REJECT')
                cli.append({'name': name, 'optimized': bool(mode), 'passed': good})
                if not good:
                    failures.append({'kind': 'CLI', 'name': name, 'mode': mode})
        file = Path(directory) / 'invalid.json'
        file.write_text('[this is not JSON')
        process = subprocess.run([sys.executable, str(ROOT / 'checker.py'), str(file)], text=True,
                                 capture_output=True, timeout=10)
        good = process.returncode == 1 and process.stdout.strip() == 'REJECT'
        cli.append({'name': 'invalid_json', 'optimized': False, 'passed': good})
        if not good:
            failures.append({'kind': 'CLI invalid JSON'})

    summary = {'status': 'PASS' if not failures else 'FAIL',
               'named_substitution_comparisons': 1200,
               'comparison_cases': len(checks),
               'translated_derivations': sum(x['kind'] == 'translated_derivation' for x in checks),
               'closed_translated_derivations': sum(x['kind'] == 'translated_derivation' and x['closed'] for x in checks),
               'noncanonical_padding_derivations': sum(x['kind'] == 'noncanonical_existential_padding' for x in checks),
               'typed_mutations_compared': sum(x['kind'] == 'typed_mutation' for x in checks),
               'typed_mutations_accepted': sum(x['kind'] == 'typed_mutation' and x['accepted'] for x in checks),
               'adversarial_cases': len(adversarial), 'cli_executions': len(cli),
               'skipped_source_malformed_cases': len(skipped), 'failures': failures,
               'scope': 'Finite executable evidence; no mechanized general metatheorem.'}
    (ROOT / 'results' / 'validation.json').write_text(json.dumps({'summary': summary,
        'comparisons': checks, 'adversarial': adversarial, 'cli': cli, 'skipped': skipped}, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    run()
