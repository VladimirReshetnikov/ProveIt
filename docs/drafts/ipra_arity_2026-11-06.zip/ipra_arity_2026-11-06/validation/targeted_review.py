"""Independent focused review of the arity candidate; never imported by it."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--candidate',type=Path,default=ROOT/'checker.py')
parser.add_argument('--demand',action='store_true')
args=parser.parse_args()
CANDIDATE=args.candidate.resolve()
V=ROOT/'validation/reference'
sys.path.insert(0,str(V))
import codec
import stack_reference as named
sys.path.insert(0,str(V/'frozen/validation'))
import audit as old_cases

spec=importlib.util.spec_from_file_location('arity_audit_candidate',CANDIDATE)
candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
T=[0,0]
D=[0,[0]]

def term(a):
    if type(a) is int:return a
    if type(a) is not list:raise ValueError('not a term')
    if len(a)==2 and a[0]=='s':return [term(a[1])]
    if len(a)==4 and a[0]=='r':return [term(x) for x in a[1:]]
    raise ValueError('not a source term')

def formula(a):
    if type(a) is not list:raise ValueError('not a source formula')
    if len(a)==3 and a[0]=='=':return [term(a[1]),term(a[2])]
    if len(a)==2 and a[0]=='q':return [formula(a[1])]
    if len(a)==2 and a[0]=='ex':return [formula(a[1]),T.copy(),T.copy()]
    raise ValueError('not a source formula')

def instruction(x):
    if type(x) is not list or not x:return copy.deepcopy(x)
    if len(x)==1:return [term(x[0])]
    if len(x)==2:
        m,t=x
        if m[0]=='q':t=term(t)
        elif m[0]=='=':t=formula(t)
        return [formula(m),copy.deepcopy(t)]
    raise ValueError('not a canonical source instruction')

def accepted(a,p,g=()):
    try:return candidate.check(*copy.deepcopy([a,p,list(g)])) is True
    except Exception:return False

rows=[]
def check(name,a,p,want,g=()):
    result=accepted(a,p,g)
    rows.append({'name':name,'expected':want,'observed':result})
    assert result==want,(name,result,want,a,p,g)
    return [a,p]

# Recheck positive logic/rule trees with the unchanged named tree oracle, then
# compile and encode independently. Every context is well formed.
logic=json.loads((V/'frozen/examples/logic/logic_sequents.json').read_text())
source=[*old_cases.generated_rules(),*logic]
for row in source:
    assert named.old.accept_sequent(row['goal'],row['proof'],row['context']),row['name']
    stack=codec.to_stack(row['goal'],row['proof'])
    a,p,g=formula(row['goal']),list(map(instruction,stack)),list(map(formula,row['context']))
    assert accepted(a,p,g),row['name']

# Direct reflexivity and existence proofs, with deliberately false padding.
M=[[0,0,0],0]
refl=[[],[],[M,[1,0]]]
ex=[T,D,D]
exp=[*refl,[0]]
check('reflexivity',T,refl,True)
check('false_existential_annotations_are_inert',ex,exp,True)
check('existential_padding_cannot_be_used_as_hypotheses',D,[None,*exp,[ex,None]],False)
check('existential_body_can_be_used',T,[None,*exp,[ex,None]],True)
# Different padding has equal semantic decoding, but is not a literal hyp.
other=[T,[1,1],[[T]]]
check('padding_is_not_literal_hypothesis_equality',other,[None],False,[ex])
check('padding_change_has_a_derivation',other,[None,[0],None,[ex,None]],True,[ex])

for i,pad in enumerate([None,False,True,0,0.0,[],[0],{},'x',[T,T,T,T]]):
    check('invalid_existential_annotation_'+str(i),[T,pad,T],exp,False)

# Demand-erasure remains syntactic, including occurrences in padding.
vacuous=[ex]
check('vacuous_unary_bad_witness_policy',ex,[None,None,[vacuous,False]],args.demand,[ex,vacuous])
body=[T,[2,0],T]
quantified=[body]
base=[T,T,T]
check('bad_witness_used_only_in_annotation_is_rejected',base,[None,None,[quantified,False]],False,[base,quantified])

# Boolean/float equality coercions cannot reach validated numeric leaves.
for i,bad in enumerate([False,True,0.0,1.0,None,{},'x',[],[0,0],[[0],0,0,0]]):
    check('invalid_numeric_leaf_'+str(i),[[0,bad,0],bad],[[]],False)

check('zero_computation',M,[[]],True)
check('successor_computation',[[[0],0,2],0],[[]],True)
check('variable_recursion_counter',[[1,0,0],0],[[]],False)
check('rigid_recursion_counter',[[-1,0,0],0],[[]],False)
check('recursive_recursion_counter',[[[0,0,0],0,0],0],[[]],False)
bad_induction=next(row for row in old_cases.fixtures() if row['name']=='forbidden_quantified_induction_hypothesis')
check('non_equation_induction_hypothesis_not_given',formula(bad_induction['goal']),list(map(instruction,codec.to_stack(bad_induction['goal'],bad_induction['proof'],allow_malformed=True))),False)
check('unused_prefix',T,[{'unused':D},*refl],True)
check('failed_major_falls_back_to_actual_hypothesis',T,[None,[D,None]],True,[T])
check('malformed_major_does_not_fall_back',T,[None,[0,None]],False,[T])
canonical_ex=[T,T,T]
check('padding_difference_can_make_major_fail',T,[None,[ex,None]],True,[T,canonical_ex])
check('raw_erasure_can_change_stack_dispatch',T,[None,[canonical_ex,None]],False,[T,canonical_ex])
check('contradiction_is_not_a_theorem',D,[None],False)

# Focused real CLI checks under normal and optimized Python. List concatenation
# enforces the JSON list category independently of Python optimization.
cli=[]
with tempfile.TemporaryDirectory() as temp:
    path=Path(temp)/'case.json'
    documents=[('valid',[T,refl],True),('false_padding',[ex,exp],True),
        ('annotation_leak',[D,[None,*exp,[ex,None]]],False),
        ('boolean',[M,[[],[],[M,False]]],False),
        ('string_goal',['x',[None]],False),('dict_goal',[{'0':0},[None]],False),
        ('object_root',{'a':0,'b':0},False),('forged_context',[D,[None],D],False),
        ('array_arity_zero',[[],[None]],False),('array_arity_four',[[0,0,0,0],[None]],False)]
    for optimize in (False,True):
        for name,doc,want in documents:
            path.write_text(json.dumps(doc))
            result=subprocess.run([sys.executable,*(['-O'] if optimize else []),str(CANDIDATE),str(path)],capture_output=True,text=True,timeout=10)
            got=result.returncode==0 and result.stdout=='ACCEPT\n'
            assert got==want,(name,optimize,result.returncode,result.stdout,result.stderr)
            assert result.returncode==(0 if want else 1),(name,optimize,result)
            cli.append({'name':name,'optimized':optimize,'accepted':got})

result={'status':'PASS','candidate_sha256':hashlib.sha256(CANDIDATE.read_bytes()).hexdigest(),
    'policy':'demand' if args.demand else 'strict',
    'independently_named_source_derivations':len(source),'logic_instances':len(logic),
    'focused_cases':rows,'cli_cases':cli,
    'scope':'Finite targeted evidence plus source review. Does not mechanize general soundness or bi-interpretability.'}
(ROOT/('results/independent_demand_review.json' if args.demand else 'results/independent_strict_review.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('focused_cases','cli_cases')},indent=2))
print('focused_cases',len(rows),'cli_cases',len(cli))
