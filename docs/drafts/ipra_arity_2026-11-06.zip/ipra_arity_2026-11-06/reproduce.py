"""Reproduce measurements and finite verification without network access."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
commands = [
    ['measure.py'],
    ['validation/replay.py'],
    ['validation/targeted_review.py'],
    ['validation/targeted_review.py', '--candidate', 'checker_demand.py', '--demand'],
    ['comparison/replay_ablations.py'],
]
for command in commands:
    print('RUN', ' '.join(command), flush=True)
    subprocess.run([sys.executable, *command], cwd=ROOT, check=True)
print('PASS: all measurements and packaged verification commands completed.')
