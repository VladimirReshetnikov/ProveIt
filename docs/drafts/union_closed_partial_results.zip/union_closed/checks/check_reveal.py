"""Exact random-order entropy certificates. Run alongside check_switching.py."""

from collections import defaultdict
from fractions import Fraction as F
from math import comb

from check_switching import entropy_interval, log2_interval


def certificate(r, k, p):
    """Lower bound on entropy per generator using k witness coordinates."""
    M = k*(r-1)
    state = {(0, F(1)): F(1)}
    for _ in range(k):
        successor = defaultdict(F)
        for (s, z), weight in state.items():
            for c in range(r):
                mass = weight*comb(r-1, c)
                none_active = (1-p)**c
                if none_active < 1:
                    successor[s+c, z] += mass*(1-none_active)
                given_no_active = 1 - (1-p)**(r-1-c)
                if given_no_active > 0:
                    successor[s+c, z*given_no_active] += mass*none_active
        state = successor
    # All states of zero weight, or with z=0, contribute zero entropy.
    probability_by_z = defaultdict(F)
    for (s, z), weight in state.items():
        probability_by_z[z] += weight/((M+1)*comb(M, s))
    conditional_upper = F(0)
    for z, probability in probability_by_z.items():
        b = p+(1-p)*z
        conditional_upper += probability*b*entropy_interval(p/b)[1]
    L = entropy_interval(p)[0] - conditional_upper
    return r*(1-L)


if __name__ == "__main__":
    for r, k, p, max_left, min_right in [
            (3, 5, F(1, 3), F(591, 1000), F(596, 1000)),
            (4, 7, F(2, 7), F(951, 1000), F(1046, 1000))]:
        upper = certificate(r, k, p)
        z = F(1, 2**r)
        right_lower = log2_interval(1/(4*z*(1-z)))[0]/2
        print(f"r={r}, d>={k}: left {float(upper):.9f} "
              f"< {float(max_left):.3f}; right > {float(min_right):.3f}")
        assert upper < max_left < min_right < right_lower
