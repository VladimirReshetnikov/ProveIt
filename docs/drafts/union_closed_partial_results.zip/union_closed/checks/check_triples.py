"""Finite checks accompanying An abundant element outside a nearly extremal triple."""
from fractions import Fraction
from itertools import product
from math import sqrt


def joined(family):
    return all(left | right in family for left in family for right in family)


def check_fibers():
    top = 7
    singles = (1, 2, 4)
    ordinary = [{0, single, top} for single in singles]
    count = 0
    for indicator in range(1 << 7, 1 << 8):
        fiber = {mask for mask in range(8) if (indicator >> mask) & 1}
        if not joined(fiber):
            continue
        count += 1
        size = len(fiber)
        defect = 3 * sum(mask.bit_count() for mask in fiber) - 4 * size
        assert defect >= 0
        assert (defect == 0) == (fiber in ordinary)
        if defect:
            for single in singles:
                appearances = sum(bool(mask & single) for mask in fiber)
                assert 3 * appearances - size <= 4 * defect
    for i, j in product(range(3), repeat=2):
        union_set = {u | v for u in ordinary[i] for v in ordinary[j]}
        if i != j:
            assert len(union_set) >= 5
    print(f"Local fiber inequalities verified on all {count} possible fibers.")


def make_family(r, deleted):
    """Encode S in the low three bits and the outside blocks in higher bits."""
    block = (1 << r) - 1
    outside = (1 << (3 * r)) - 1
    result = {0, 7} | {(outside << 3) | trace for trace in range(8)}
    for i in range(3):
        start = deleted if i == 2 else 0
        fixed = outside ^ (block << (i * r))
        for local in range(start, block):
            proj = fixed | (local << (i * r))
            for trace in (0, 1 << i, 7):
                result.add((proj << 3) | trace)
    return result


def check_examples():
    cases = 0
    for r in range(2, 6):
        t = (1 << r) - 1
        for s in (0, 1, t // 2, t - 1):
            family = make_family(r, s)
            assert joined(family)
            assert all(a == 7 or a.bit_count() > 3 for a in family if a)
            size = len(family)
            counts = [sum(bool(a & (1 << i)) for a in family)
                      for i in range(3 + 3 * r)]
            peak = max(counts[:3])
            assert size == 9 * t - 3 * s + 10
            assert peak == 4 * t - s + 5
            assert 9 * peak - 4 * size == 3 * s + 5
            if s == 0:
                expected = 6 * t + 3 * ((1 << (r - 1)) - 1) + 8
                assert set(counts[3:]) == {expected}
                print(f"r={r}: {size} sets, triple frequency {Fraction(peak,size)}, "
                      f"outside frequency {Fraction(expected,size)}")
            cases += 1
    print(f"Closure and incidence formulas verified on {cases} example checks.")


def check_block_description():
    """Check all ordered equal-size block triples on two points per block."""
    families = []
    for code in range(8, 16):
        block_family = {s for s in range(4) if (code >> s) & 1}
        if len(block_family) >= 2 and joined(block_family):
            families.append(block_family)
    cases = 0
    for blocks in product(families, repeat=3):
        m = len(blocks[0])
        if any(len(block) != m for block in blocks):
            continue
        top = 63
        members = {0, 7} | {(top << 3) | trace for trace in range(8)}
        for i, block in enumerate(blocks):
            for b in block - {3}:
                proj = (top ^ (3 << (2*i))) | (b << (2*i))
                members.update((proj << 3) | a for a in (0, 1 << i, 7))
        assert len(members) == 9*m + 1 and joined(members)
        for i, block in enumerate(blocks):
            for j in range(2):
                d = sum(bool(b & (1 << j)) for b in block)
                observed = sum(bool(a & (1 << (3+2*i+j))) for a in members)
                assert observed == 6*m + 3*d - 1
        cases += 1
    print(f"Classification construction checked on {cases} ordered triples of blocks.")


if __name__ == "__main__":
    check_fibers()
    check_examples()
    check_block_description()
    phi = (sqrt(5) - 1) / 2
    gamma = (3 * sqrt(5) - 1) / 8
    print(f"Golden-ratio bound at bounded excess: {1-phi/3:.10f}")
    print(f"Threshold exponent: {gamma:.10f}")
    print(f"Endpoint constant: {2*3**(-1.5-gamma):.10f}")
