"""Exact arithmetic and small finite checks for the generator-incidence results.

Run with Python 3.9 or later. Only the standard library is required.
"""

from fractions import Fraction as F


def log_interval(y):
    """Natural logarithm bounds for 1 <= y <= 2 from the atanh series."""
    assert 1 <= y <= 2
    z = (y - 1) / (y + 1)
    low = 2 * sum(z ** (2 * j + 1) / (2 * j + 1) for j in range(10))
    remainder = 2 * z**21 / (21 * (1 - z*z))
    return low, low + remainder


def log2_interval(x):
    """Return rational lower and upper bounds on log_2(x)."""
    assert x > 0
    shift = 0
    while x < 1:
        x *= 2
        shift -= 1
    while x > 2:
        x /= 2
        shift += 1
    low, high = log_interval(x)
    ln2_low, ln2_high = log_interval(F(2))
    return shift + low/ln2_high, shift + high/ln2_low


def entropy_interval(p):
    q = 1 - p
    pl, pu = log2_interval(p)
    ql, qu = log2_interval(q)
    return -p*pu - q*qu, -p*pl - q*ql


def verify_entropy(r, d, p, left_bound, right_bound):
    q = (1 - (1 - p)**(r - 1))**d
    b = p + (1 - p)*q
    lower_L = entropy_interval(p)[0] - b*entropy_interval(p/b)[1]
    z = F(1, 2**r)
    lower_divergence = log2_interval(1/(4*z*(1-z)))[0] / 2
    assert r*(1 - lower_L) < left_bound < right_bound < lower_divergence
    print(f"mean-frequency criterion r={r}, d={d}: "
          f"left < {left_bound}, right > {right_bound}")


def all_unions(edges):
    family = {0}
    for edge in edges:
        family.update([t | edge for t in family])
    return family


def transversal(r, d, prime):
    return [sum(1 << (t*prime + (a*t+b) % prime) for t in range(r))
            for a in range(d) for b in range(prime)]


def verify_duality(r, d, prime):
    edges = transversal(r, d, prime)
    stars = [sum(1 << x for x, edge in enumerate(edges) if edge >> i & 1)
             for i in range(r*prime)]
    primal = all_unions(stars)
    dual = all_unions(edges)
    assert len(dual) == len(primal)
    for u in primal:
        t = sum(1 << i for i, star in enumerate(stars) if star & ~u)
        assert t in dual
        assert u == sum(1 << x for x, edge in enumerate(edges) if edge & ~t)
    freqs = [F(sum((u >> x) & 1 for u in primal), len(primal))
             for x in range(len(edges))]
    assert all(f <= 1 - F(1, 2**r) for f in freqs)
    print(f"transversal r={r}, d={d}, p={prime}: |F|={len(primal)}, "
          f"frequency range [{min(freqs)}, {max(freqs)}]")


def verify_conditioned_local_estimate():
    # The target 3-edge has alternative two-element witnesses. Its four
    # outside neighbors have singleton witnesses. Edges reaching vertices
    # 7 and 8 create a nontrivial choice of remote conditions.
    edge = 0b111
    roots, neighbors = range(3), range(3, 7)
    edges = [edge] + [1 << j for j in neighbors]
    edges += [(1 << i) | (1 << j) for i in roots for j in neighbors]
    edges += [sum(1 << j for j in row) for row in [(3, 7, 8), (5, 7)]]
    family = all_unions(edges)
    beta = F(3, 16)
    for remote in {t >> 7 for t in family}:
        subset = [t for t in family if t >> 7 == remote]
        law = [F(sum((t & edge) == s for t in subset), len(subset))
               for s in range(8)]
        tv = sum(abs(u - F(1, 8)) for u in law) / 2
        assert F(1, 8) <= law[-1] <= 1/(1 + 7*(1 - beta))
        assert tv <= beta
        print(f"remote trace {remote:02b}: edge probability {law[-1]}, TV {tv}")


if __name__ == "__main__":
    assert 42 * 3**13 < 4**13
    assert 156 * 7**38 < 8**38
    verify_entropy(3, 6, F(1, 3), F(573, 1000), F(596, 1000))
    verify_entropy(4, 8, F(2, 7), F(959, 1000), F(1046, 1000))
    verify_duality(3, 2, 5)
    verify_duality(3, 3, 5)
    verify_duality(3, 4, 5)
    verify_conditioned_local_estimate()
