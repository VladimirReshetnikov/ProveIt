"""Exact finite checks for the pendant inequalities and the two star moments."""
from itertools import combinations
from math import comb, factorial, perm


def subsets_as_masks(n, size):
    return [sum(1 << v for v in e) for e in combinations(range(n), size)]


def pendant_counts(n, edges):
    degrees = [sum(bool(e & (1 << v)) for e in edges) for v in range(n)]
    petals = []
    for v in range(n):
        bit = 1 << v
        count = sum(
            bool(e & bit) and e != bit and
            all(degrees[u] == 1 for u in range(n) if e & (1 << u) and u != v)
            for e in edges
        )
        petals.append(count)
    return degrees, petals


def check_sandwich(n, rank):
    candidates = subsets_as_masks(n, rank)
    for mask in range(1 << len(candidates)):
        edges = [e for j, e in enumerate(candidates) if mask & (1 << j)]
        unions = {0}
        for e in edges:
            unions |= {u | e for u in unions}
        degrees, petals = pendant_counts(n, edges)
        for v in range(n):
            absent = sum(not (u & (1 << v)) for u in unions)
            assert (absent << petals[v]) <= len(unions) <= (absent << degrees[v])
    print(f"Pendant inequalities: all {1 << len(candidates)} labeled rank-{rank} systems on {n} points.")


def choose(n, k):
    return comb(n, k) if 0 <= k <= n else 0


def star_specs(n, rank, k):
    leaves = (rank - 1) * k
    if n < 1 + leaves:
        return 0
    return n * perm(n - 1, leaves) // (factorial(rank - 1) ** k * factorial(k))


def check_star_moments(n, rank, k):
    candidates = subsets_as_masks(n, rank)
    N = len(candidates)
    first = [0] * (N + 1)
    second = [0] * (N + 1)
    for mask in range(1 << N):
        edges = [e for j, e in enumerate(candidates) if mask & (1 << j)]
        degrees, petals = pendant_counts(n, edges)
        stars = sum(d == k == p for d, p in zip(degrees, petals))
        first[len(edges)] += stars
        second[len(edges)] += stars * (stars - 1)
    vertices = 1 + (rank - 1) * k
    single = star_specs(n, rank, k)
    paired = single * star_specs(n - vertices, rank, k)
    for m in range(N + 1):
        expected_first = single * choose(choose(n - vertices, rank), m - k)
        expected_second = paired * choose(choose(n - 2 * vertices, rank), m - 2 * k)
        assert first[m] == expected_first
        assert second[m] == expected_second
    print(f"First and second factorial moments: all {1 << N} rank-{rank} systems on {n} points, k={k}, grouped by edge count.")


if __name__ == "__main__":
    for rank in (2, 3):
        check_sandwich(5, rank)
    check_star_moments(6, 2, 2)
    check_star_moments(5, 3, 2)
