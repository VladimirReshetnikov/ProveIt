#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p .tex-cache
export TEXMFVAR="$(pwd)/.tex-cache"
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
