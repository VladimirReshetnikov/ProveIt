#!/usr/bin/env python3
"""Deterministic syntax and finite-arithmetic checks; not a proof kernel."""
import hashlib, itertools, json, pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def v(x): return ('v',x)
def const(x='0'): return ('c',x)
def f(name,*args,desc=None): return ('f',name,desc,args)
def op(name,*args): return (name,*args)
def q(name,var,a): return (name,var,a)
def eq(a,b): return op('eq',a,b)
def neg(a): return op('imp',a,('bot',))
def size(t,full=False):
 k=t[0]
 if k in ('v','c','bot'): return 1
 if k=='f': return 1+sum(size(a,full) for a in t[3])+(size(t[2],True) if full and t[2] is not None else 0)
 if k in ('all','ex'): return 1+size(t[2],full)
 return 1+sum(size(a,full) for a in t[1:])
def sub(t,name,u):
 k=t[0]
 if k=='v': return u if t[1]==name else t
 if k in ('c','bot'):return t
 if k=='f':return f(t[1],*(sub(a,name,u) for a in t[3]),desc=t[2])
 if k in ('all','ex'):
  assert t[1]!=name
  return q(k,t[1],sub(t[2],name,u))
 return op(k,*(sub(a,name,u) for a in t[1:]))
def occ(t,name):
 if t[0]=='v':return int(t[1]==name)
 if t[0] in ('c','bot'):return 0
 if t[0]=='f':return sum(occ(a,name) for a in t[3])
 if t[0] in ('all','ex'):return occ(t[2],name)
 return sum(occ(a,name) for a in t[1:])
x,z,b,c,n,a,w=map(v,('x','z','b','c','n','a','w'))
zero=const(); S=lambda t:f('S',t); one=S(zero)
Q=lambda r,s:f('R',r,s,desc=w)
Z=lambda r,s:f('R',r,s,desc=zero)
C=lambda r,u,t:Q(Z(r,S(u)),t)
def truth(A):
 k=A[0]
 if k=='eq':return f('chi',A[1],A[2])
 if k=='bot':return zero
 p,r=map(truth,A[1:])
 return {'and':lambda:C(p,zero,r),'or':lambda:C(p,r,one),'imp':lambda:C(p,one,r)}[k]()
def induction(A,bound):
 A0=sub(A,'x',zero);Ab=sub(A,'x',b);An=sub(A,'x',n)
 if bound: step=q('all','b',q('all','c',op('imp',eq(c,S(b)),op('imp',Ab,sub(A,'x',c)))))
 else:step=q('all','b',op('imp',Ab,sub(A,'x',S(b))))
 return q('all','z',op('imp',op('and',A0,step),q('all','n',An)))
def induction3(A):
 step=q('all','b',q('all','c',op('imp',op('or',eq(c,zero),op('and',eq(c,S(b)),sub(A,'x',b))),sub(A,'x',c))))
 return q('all','z',op('imp',step,q('all','n',sub(A,'x',n))))
def inline(t,merged=False,shift=True):
 sb=(f('D',b,b) if merged else S(b)) if shift else b
 d=v('d')
 body=op('and',eq(d,Q(Z(sub(t,'x',sb),sb),n)),eq(Z(sub(t,'x',d),d),zero))
 return q('all','z',q('all','n',q('ex','b',q('ex','d',body))))
def mask_package(t,whole,shift,merged=False):
 suc=lambda u:f('D',u,u) if merged else S(u)
 desc=Z(t,x) if whole else t
 M=lambda u,r:f('M',u,r,desc=desc)
 definition=q('all','x',q('all','z',eq(M(x,z),Z(t,x))))
 witness=q('all','z',q('all','n',q('ex','b',eq(M(Q(M(suc(b) if shift else b,z),n),z),zero))))
 return definition,witness
terms=[x,z,zero,S(x),Q(x,z),f('R',x,z,desc=Q(v('v'),w))]
forms=[eq(t,u) for t in terms for u in terms]+[('bot',)]
for depth in range(2):
 old=forms[-25:]
 forms += [op(k,p,r) for k in ('and','or','imp') for p in old for r in old[:8]]
for A in forms:
 for full in (False,True):
  L=size(A,full)
  assert size(induction(A,True),full)==12+4*L
  assert size(induction3(A),full)==15+3*L
  assert size(induction(A,False),full)==6+4*L+occ(A,'x')
 assert size(truth(A),True)>=size(A,True)
 t=truth(A); W=size(t,True);m=size(t);i=occ(t,'x')
 assert i<=m<=W
 assert size(inline(t))==16+2*m+i
 assert size(inline(t),True)==19+2*W+i
 assert size(inline(t,True))==17+2*m+2*i
 assert size(inline(t,True),True)==20+2*W+2*i
 assert size(inline(t,True,False))==15+2*m
 assert size(inline(t,True,False),True)==18+2*W
 assert 22+4*W-size(inline(t),True)>=3+W
 assert 31+4*W-size(inline(t,True),True)>=11
 assert 24+22+4*W-(17+size(inline(t,True),True))>=9
 for whole in (False,True):
  for shift in (False,True):
   d,wi=mask_package(t,whole,shift)
   expected=(32 if whole else 23)-(not shift)+4*W
   assert size(d,True)+size(wi,True)==expected
   assert size(wi)==12+shift
   assert size(induction(A,True),True)<=size(d,True)+size(wi,True)-10
# Frozen descriptors are never entered by active substitution.
frozen=f('R',x,z,desc=f('S',x))
changed=sub(frozen,'x',S(b))
assert changed[2]==frozen[2] and occ(frozen,'x')==1
assert size(changed,True)==size(frozen,True)+1
# Same-language merged discriminator variant.
D=lambda u,r:f('D',u,r)
off=q('all','x',q('all','z',op('or',eq(x,z),eq(D(x,z),zero))))
nontriv=q('ex','x',neg(eq(x,zero)))
part=q('all','x',q('ex','b',neg(eq(D(x,zero),D(x,D(b,b))))))
assert size(off)==11 and size(nontriv)==6 and size(part)==13
for t in terms:
 for shift in (False,True):
  d,wi=mask_package(t,True,shift,True)
  H=size(Z(t,x),True)
  assert size(wi)==12+2*shift
  assert size(wi,True)==13+2*shift+2*H
assert [24+12*N-(17+14*N) for N in range(1,6)]==[5,3,1,-1,-3]
# Numerical checks of explicit inherited bootstrap and pairing, not model proofs.
subn=lambda u,r:max(u-r,0)
choose=lambda r,u,t:u if r==0 else t
for y in range(100):
 for nn in range(100):
  assert choose(subn(y,nn),y,nn+subn(y,nn))==y
for xx in range(100):
 for yy in range(100):
  d=subn(xx+1,yy)
  bit=choose(d,0,choose(max(d-1,0),1,0))
  assert (d==1)==(xx==yy)
  assert bit==int(xx==yy)
tri=lambda u:u*(u+1)//2
def row(u):
 k=0
 for j in range(u):k+=int(j+1==tri(k+1))
 return k
rows=[row(i) for i in range(tri(80)+1)]
for xx in range(40):
 for yy in range(40):
  code=tri(xx+yy)+yy; k=rows[code];r=code-tri(k)
  assert r==yy and max(k-r,0)==xx
# Exhaust all masks on a finite prefix with f(0)=0; source scan witnesses W13.
checked=0
for bits in itertools.product((0,1),repeat=10):
 good=[True]+list(map(bool,bits)); mask=lambda i:0 if good[i] else i
 candidate=0
 for nn in range(10):
  assert mask(candidate)==0
  assert mask(nn)==0 or mask(candidate+1)!=0
  inner=mask(candidate+1)
  chosen=nn if inner==0 else inner-1
  assert mask(chosen)==0
  if mask(nn)==0:candidate=nn
  checked+=1
# Original immutable archives and git blob identifiers, if packaged.
manifest=json.loads((ROOT/'provenance/source_manifest.json').read_text())
for item in manifest:
 p=ROOT/'sources'/item['name'];data=p.read_bytes()
 assert hashlib.sha256(data).hexdigest()==item['sha256']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['git_blob']
result={'status':'PASS','formula_cases':len(forms),'mask_scan_cases':checked,'archive_count':len(manifest),'bound_induction':'12+4L','short_induction':'6+4L+i','tail_only_mask_W13':'23+4W','tail_only_mask_W12':'22+4W','local_full_saving_at_least':10,'merged_fixed_old':24,'merged_fixed_new':17,'three_copy_induction':'15+3L','ordinary_inline':'19+2W+i','merged_inline':'20+2W+2i','merged_unshifted_inline':'18+2W','merged_actual_N_saving':'7+sum(11+2*(W-i))','merged_favorable_N_saving':'7+sum(2+2*(W-i))','scope':'Syntax and finite arithmetic checks only; written proofs establish theorems. No Lean kernel replay.'}
print(json.dumps(result,indent=2))
