PRA without auxiliary mask symbols
Research snapshot: f6530de455c06348fab66350f6469a826bcb974d

Contents
  report.tex and report.pdf: complete specification, proofs, comparisons.
  checks/check.py: syntax counts, finite arithmetic checks and source hashes.
  checks/results.json: recorded output of the checks.
  sources/: the six immutable source archives, unchanged.
  provenance/source_manifest.json: source paths, Git blob IDs and SHA-256.
  build.sh: compile the report with an existing TeX installation.
  SHA256SUMS.txt: checksums of this package's files.

Run sh build.sh to rebuild with an existing TeX installation.
Run python3 checks/check.py from any directory. Only Python's standard
library is needed. These checks validate syntax counts and finite examples;
they are not a formal proof kernel and do not replace the written proofs.

The reduction concerns complete fresh definition-and-witness packages in
an explicitly stated full-description tree metric, on a common earlier
term language. Displayed active size, amortized existing definitions,
translations of richer signatures, generator byte lengths and a global
minimum are separate questions. The report states both matching-logics
bi-interpretations and their identity round trips.

The source archives' computations and proof files are included for
provenance. Their inclusion is not a claim that their Lean projects were
rebuilt during this work. No new Lean or other formal-kernel certificate
is claimed.
