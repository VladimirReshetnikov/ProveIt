#!/usr/bin/env python3
"""Reproduce finite diagnostics and compile the accompanying research report."""
import argparse
from pathlib import Path
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

def run(command, log_path, working_directory=ROOT):
    result = subprocess.run(
        command, cwd=working_directory, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False,
    )
    log_path.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout[-12000:])
        raise SystemExit(f"FAILED ({result.returncode}): {command[0]}")
    print(f"PASS: {log_path.relative_to(ROOT)}")

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf-only", action="store_true",
                        help="Reuse existing diagnostic results during layout-only edits.")
    args = parser.parse_args()
    artifacts = ROOT / "artifacts"
    artifacts.mkdir(exist_ok=True)
    if not args.pdf_only:
        for name in ("check_core", "check_numeral_fusion", "check_linear_statefree"):
            run([sys.executable, str(artifacts / f"{name}.py")],
                artifacts / f"{name}_stdout.txt")
    executable = shutil.which("pdflatex")
    if not executable:
        raise SystemExit("pdflatex is required to compile report.tex.")
    for old_log in artifacts.glob("latex_pass_*.txt"):
        old_log.unlink()
    with tempfile.TemporaryDirectory(prefix="ipra_latex_") as temporary:
        working = Path(temporary)
        shutil.copy2(ROOT / "report.tex", working / "report.tex")
        shutil.copytree(ROOT / "sections", working / "sections")
        for pass_number in range(1, 5):
            run([executable, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                artifacts / f"latex_pass_{pass_number}.txt", working)
            log = (working / "report.log").read_text(errors="replace")
            needs_rerun = (
                "There were undefined references" in log
                or "Label(s) may have changed" in log
                or "Rerun to get" in log
            )
            if pass_number >= 2 and not needs_rerun:
                break
        if needs_rerun or "Undefined control sequence" in log:
            raise SystemExit("Unresolved LaTeX problem; inspect artifacts/latex_final.log.")
        (artifacts / "latex_final.log").write_text(log)
        pdf = (working / "report.pdf").read_bytes()
        if not pdf.startswith(b"%PDF-") or not pdf.rstrip().endswith(b"%%EOF"):
            raise SystemExit("LaTeX output is not a complete PDF.")
        temporary_output = ROOT / "report.pdf.part"
        with temporary_output.open("wb") as stream:
            stream.write(pdf)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_output, ROOT / "report.pdf")
        print(f"Complete PDF: {len(pdf)} bytes.")
    print("Complete. See report.pdf and artifacts/*_results.json.")

if __name__ == "__main__":
    main()
