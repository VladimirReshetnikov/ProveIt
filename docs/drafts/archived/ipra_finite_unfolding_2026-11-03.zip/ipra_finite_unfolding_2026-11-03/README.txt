iPRA with Direct Parameters and Certified Finite Unfolding
=========================================================

Start with report.pdf. AXIOMS.txt gives the complete elementary theory and
the canonical refinement without requiring the paper's explanatory prose.

The construction preserves the strongest audited direct-parameter core,
shortens the ordinary-connective boundary by four nodes, and deletes
further recursor descriptions using certified finite numeral unfolding
and linear parameter-only selector dispatch. It preserves full first-order
intuitionistic bi-interpretability and genuine falsity.

The report also proves a product/automorphism obstruction to removing
coverage through further equational or Horn axioms, including when
interpretation domains are finite tuples or definable quotients.

Contents
--------
report.tex and sections/*.tex    Complete LaTeX sources
report.pdf                      Compiled report
AXIOMS.txt                      Exact standalone specification
artifacts/check_*.py            Standard-library diagnostic programs
artifacts/*_results.json        Completed finite-check receipts
provenance/source_manifest.json Pinned source paths, Git blobs, SHA-256
provenance/comparison.csv       Exact interface ledger
provenance/audit_decisions.json Historical-filter decisions
build.py                       Diagnostics and stable-reference LaTeX rebuild
SHA256SUMS.txt                  Delivery checksums

Rebuild
-------
Run: python3 build.py

Python requires only its standard library. PDF compilation requires
pdflatex and the standard packages named in report.tex.
The script fails on a failed check or LaTeX error and stores build output
under artifacts/. Rebuilding may change PDF metadata/checksums.

Verification scope
------------------
The mathematical interpretation theorem is established by written proofs.
The Python diagnostics verify finite trees, exact costs, freezing of
stored descriptors, concrete normalization families, and bounded scans.
They are not a Lean/Rocq formalization.

Research scope
--------------
The audit is pinned to ProveIt commit
62494ae438e7518d7d9d3b923b506d2223672cdc.
All three current drafts improve on the immediately archived iteration.
No universal shortestness or arbitrary proof-length bound is claimed.
The infinite axiom schemas, effective description generator, and common
intuitionistic background calculus are separate from finite core counts.
