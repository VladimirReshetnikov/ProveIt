#!/usr/bin/env python3
"""Uniform substitution checks for linear parameter-only recursion dispatch."""
from check_numeral_fusion import T,Z,V,W,A0,N,op,S,rec,size,subst,vars_active,has_old_redex
from pathlib import Path
import json


def body(m):
    result=T('c'+str(m))
    for j in range(m-1,0,-1):
        result=rec(S(V),T('c'+str(j)),result)
    return result


def main():
    tested=0;examples=[]
    for m in range(2,33):
        h=body(m)
        assert size(h)==4*m-3
        assert vars_active(h)=={'c'+str(j) for j in range(1,m+1)}
        assert not has_old_redex(h,'direct_native_p')
        assert not has_old_redex(h,'direct_generated_p')
        for depth in range(7):
            params=[]
            for j in range(1,m+1):
                t=T('b'+str(j))
                for _ in range(depth+j%3):t=S(t)
                params.append(t)
            hargs=subst(h,{'c'+str(j):c for j,c in enumerate(params,1)})
            source=rec(h,N,A0,*params)
            image=rec(T('c1'),N,A0,hargs)
            assert size(source)-size(image)==m-1
            tested+=1
        if m in {2,3,8,16,32}:
            params=[T('c'+str(j)) for j in range(1,m+1)]
            source=rec(h,N,A0,*params)
            image=rec(T('c1'),N,A0,h)
            examples.append({'parameters':m,'body_size':size(h),
                'old_variable_call_size':size(source),
                'new_variable_call_size':size(image),'saved_nodes':m-1})
    # The state-free criterion must exclude state or counter dependencies.
    assert 'v' in vars_active(rec(S(V),T('c1'),V))
    assert 'w' in vars_active(rec(S(V),W,T('c1')))
    results={'status':'PASS','substitution_cases':tested,
        'scope':'Linear parameter-only bodies; descriptor freezing and arbitrary argument sizes.',
        'claim':'Finite syntax checks only; theoretical uniform inequality is proved separately.',
        'examples':examples}
    Path(__file__).with_name('linear_statefree_results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':main()
