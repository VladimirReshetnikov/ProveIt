#!/usr/bin/env python3
"""Finite diagnostics for the direct iPRA core, schemas, and scan witness.

Run with Python 3.10+ and no third-party packages:
    python3 artifacts/check_core.py

The program constructs actual syntax trees, fully charges every frozen
recursor description, and checks the stated sizes independently of the
closed-form size formulas. Active substitution never enters a descriptor.
It also exhausts every Boolean predicate on {0,...,t}, for 0 <= t <= 12,
and verifies one scan witness against every relevant probe, plus two probes
beyond t with all four possible predicate-value extensions.

These are finite syntax and bounded numerical diagnostics. They are not a
formal proof of the infinite theory, bi-interpretability, or minimality.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import random
import sys


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    descriptor: "Term | None" = None

    def size(self) -> int:
        return 1 + sum(t.size() for t in self.args) + (
            self.descriptor.size() if self.descriptor is not None else 0)


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple["Term | Formula", ...] = ()
    binder: str = ""

    def size(self) -> int:
        # The bound variable's printed name is an annotation, not a node.
        return 1 + sum(t.size() for t in self.children)


def var(name: str) -> Term:
    return Term("var:" + name)


def app(name: str, *args: Term) -> Term:
    return Term(name, tuple(args))


ZERO = Term("0")
BOTTOM = Formula("bottom")
V, W, N, A, X, B, TARGET = map(var, ("v", "w", "n", "a", "x", "b", "t"))


def succ(t: Term) -> Term:
    return app("S", t)


def pred(t: Term) -> Term:
    return app("p", t)


def rec(h: Term, n: Term, a: Term, *parameters: Term) -> Term:
    return Term("Rec", (n, a, *parameters), h)


def eq(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


def conjunction(a: Formula, b: Formula) -> Formula:
    return Formula("and", (a, b))


def disjunction(a: Formula, b: Formula) -> Formula:
    return Formula("or", (a, b))


def implies(a: Formula, b: Formula) -> Formula:
    return Formula("implies", (a, b))


def k4(a: Formula, b: Formula, c: Formula, d: Formula) -> Formula:
    return Formula("K4", (a, b, c, d))


def k3(a: Formula, b: Formula, c: Formula) -> Formula:
    return Formula("K3", (a, b, c))


def quantify(kind: str, names: tuple[str, ...], f: Formula) -> Formula:
    for name in reversed(names):
        f = Formula(kind, (f,), name)
    return f


def forall(names: tuple[str, ...], f: Formula) -> Formula:
    return quantify("forall", names, f)


def exists(names: tuple[str, ...], f: Formula) -> Formula:
    return quantify("exists", names, f)


def substitute(t: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous ACTIVE substitution: the descriptor is left frozen."""
    if t.tag.startswith("var:"):
        return replacements.get(t.tag[4:], t)
    return Term(t.tag, tuple(substitute(a, replacements) for a in t.args),
                t.descriptor)


def occurrences(t: Term, name: str) -> int:
    return int(t.tag == "var:" + name) + sum(
        occurrences(a, name) for a in t.args)


def active_variables(t: Term) -> set[str]:
    variables = {t.tag[4:]} if t.tag.startswith("var:") else set()
    for a in t.args:
        variables.update(active_variables(a))
    return variables


def active_skeleton_size(t: Term) -> int:
    """Ignore all descriptor charges, solely for a diagnostic comparison."""
    return 1 + sum(active_skeleton_size(a) for a in t.args)


def frozen_charge(t: Term) -> int:
    # The descriptor's size ALREADY charges its recursively nested labels.
    return (t.descriptor.size() if t.descriptor is not None else 0) + sum(
        frozen_charge(a) for a in t.args)


def active_descriptors(t: Term) -> tuple[Term, ...]:
    result = (t.descriptor,) if t.descriptor is not None else ()
    for a in t.args:
        result += active_descriptors(a)
    return result


def support_checks() -> dict:
    y = var("y")
    p0 = eq(pred(ZERO), ZERO)
    sep = implies(eq(ZERO, succ(ZERO)), BOTTOM)
    cov = forall(("x",), exists(("y",),
        disjunction(eq(X, ZERO), eq(X, succ(y)))))
    pc = forall(("x",), conjunction(eq(pred(succ(X)), X),
        disjunction(eq(X, ZERO), eq(succ(pred(X)), X))))
    aa, bb, cc, dd = (Formula("meta:" + s) for s in "ABCD")
    def3 = Formula("definition", (k3(aa, bb, cc),
        conjunction(implies(aa, bb), implies(bb, cc))))
    def4 = Formula("definition", (k4(aa, bb, cc, dd),
        conjunction(implies(aa, bb), implies(bb, implies(cc, dd)))))
    observed = {"Sep": sep.size(), "Cov": cov.size(), "P0": p0.size(),
                "PC": pc.size(), "K3_definition_record": def3.size(),
                "K4_definition_record": def4.size()}
    expected = {"Sep": 6, "Cov": 10, "P0": 4, "PC": 16,
                "K3_definition_record": 12, "K4_definition_record": 15}
    assert observed == expected, (observed, expected)
    return {"observed": observed,
            "fixed_T0_K4": sep.size() + cov.size() + def4.size(),
            "fixed_Tp_K4": sep.size() + p0.size() + pc.size() + def4.size()}


def ordinary_module(h: Term, m: int) -> Formula:
    names = tuple("c" + str(j) for j in range(1, m + 1))
    parameters = tuple(map(var, names))
    base = eq(rec(h, ZERO, A, *parameters), A)
    old_value = rec(h, N, A, *parameters)
    # The active actual argument variables already use c1,...,cm.
    updated_body = substitute(h, {"v": old_value, "w": N})
    step = eq(rec(h, succ(N), A, *parameters), updated_body)
    return forall(("a", *names), conjunction(base, forall(("n",), step)))


def boundary_formulas(e: Formula, m: int) -> tuple[Formula, Formula, Formula, Formula]:
    names = ("t", *("c" + str(j) for j in range(1, m + 1)))
    left, at, end = eq(succ(X), B), eq(X, B), eq(B, TARGET)
    compact = k4(left, e, at, end)
    expanded = conjunction(implies(left, e), implies(e, implies(at, end)))
    wrap = lambda f: forall(names, exists(("b",), forall(("x",), f)))
    assert e.tag == "eq"
    endpoint_e = eq(*(substitute(t, {"x": B}) for t in e.children))
    scoped = forall(names, exists(("b",), conjunction(
        forall(("x",), implies(left, e)), implies(endpoint_e, end))))
    with_k3 = wrap(k3(left, e, implies(at, end)))
    return wrap(compact), wrap(expanded), scoped, with_k3


ADD_BODY = succ(V)


def add(n: Term, a: Term) -> Term:
    return rec(ADD_BODY, n, a)


def descriptor_cases() -> list[tuple[str, int, Term]]:
    inner = add(add(V, succ(W)), var("c1"))
    seeds = [ZERO, V, W, succ(V), pred(V), succ(W),
             add(V, W), add(V, add(V, W)), add(W, add(W, succ(W))),
             rec(inner, V, W, ZERO), rec(inner, succ(W), succ(V), ZERO)]
    cases = []
    for m in range(7):
        for i, h in enumerate(seeds):
            # At least one case for every arity retains unused formal slots;
            # other cases exercise parameter substitution in active positions.
            if i % 2:
                for j in range(1, m + 1):
                    h = add(h, var("c" + str(j)))
            cases.append((f"structured_m{m}_{i:02d}", m, h))
    rng = random.Random(20261103)

    def make(depth: int, m: int) -> Term:
        atoms = [ZERO, V, W, *(var("c" + str(j)) for j in range(1, m + 1))]
        if depth == 0 or rng.randrange(5) == 0:
            return rng.choice(atoms)
        choice = rng.randrange(5)
        if choice == 0:
            return succ(make(depth - 1, m))
        if choice == 1:
            return pred(make(depth - 1, m))
        if choice == 2:
            return add(make(depth - 1, m), make(depth - 1, m))
        if choice == 3:
            return rec(inner, make(depth - 1, m), make(depth - 1, m),
                       make(depth - 1, m))
        return add(make(depth - 1, m), add(make(depth - 1, m), W))

    for i in range(70):
        m = i % 7
        cases.append((f"seeded_m{m}_{i:02d}", m, make(4, m)))
    return cases


def scope_and_schema_checks() -> dict:
    rows = []
    for name, m, h in descriptor_cases():
        assert active_variables(h) <= {"v", "w", *("c" + str(j)
                                                  for j in range(1, m + 1))}
        h_size = h.size()
        k = occurrences(h, "v")
        formula = ordinary_module(h, m)
        expected = 3 * h_size + 3 * m + 13 + k * (h_size + m + 2)
        assert formula.size() == expected, (name, formula.size(), expected)
        params = tuple(var("c" + str(j)) for j in range(1, m + 1))
        # E contains the target t, as allowed in the boundary schema.
        e = eq(rec(h, X, TARGET, *params), succ(TARGET))
        compact, expanded, scoped, with_k3 = boundary_formulas(e, m)
        assert compact.size() == e.size() + m + 14
        assert expanded.size() == 2 * e.size() + m + 17
        assert scoped.size() == 2 * e.size() + m + 13
        assert expanded.size() - scoped.size() == 4
        assert with_k3.size() == e.size() + m + 15
        # Independently check recursive descriptor charging on every body.
        assert h.size() == active_skeleton_size(h) + frozen_charge(h)
        changed = substitute(h, {"v": succ(var("alpha")), "w": ZERO,
                                 **{"c" + str(j): succ(var("z" + str(j)))
                                    for j in range(1, m + 1)}})
        assert active_descriptors(changed) == active_descriptors(h)
        rows.append({"name": name, "m": m, "H": h_size, "active_state_occurrences": k,
                     "ordinary_module": formula.size(), "boundary_index": e.size(),
                     "boundary_K4": compact.size(), "boundary_expanded": expanded.size(),
                     "boundary_scoped": scoped.size(), "boundary_K3": with_k3.size()})

    # Frozen variables are in their own lexical scope even when their names
    # coincide with outer variables; replacement is simultaneous, not iterated.
    deep_label = add(add(V, succ(W)), var("c1"))
    outer = rec(deep_label, V, W, var("c1"))
    assert [occurrences(outer, s) for s in ("v", "w", "c1")] == [1, 1, 1]
    replacement = substitute(outer, {"v": succ(W), "w": ZERO,
                                     "c1": succ(var("outside"))})
    assert replacement.descriptor is deep_label
    assert replacement.args == (succ(W), ZERO, succ(var("outside")))
    assert active_variables(replacement) == {"w", "outside"}
    assert frozen_charge(outer) == deep_label.size()
    assert outer.size() == 4 + deep_label.size()

    named = {"Q": ordinary_module(W, 0).size(),
             "C0": ordinary_module(var("c1"), 1).size(),
             "A": ordinary_module(ADD_BODY, 0).size()}
    assert named == {"Q": 16, "C0": 19, "A": 23}
    crossover = []
    for count in range(1, 21):
        packet = rows[:count]
        # Count the chosen logical definition record exactly once, as in the
        # report's finite unshared packet convention. All packets use T0.
        paid_k4 = 16 + 15 + sum(row["boundary_K4"] for row in packet)
        paid_k3 = 16 + 12 + sum(row["boundary_K3"] for row in packet)
        paid_scoped = 16 + sum(row["boundary_scoped"] for row in packet)
        assert paid_k4 - paid_k3 == 3 - count
        assert paid_scoped - paid_k4 == sum(
            row["boundary_index"] - 1 for row in packet) - 15
        assert paid_scoped - paid_k3 == sum(
            row["boundary_index"] - 2 for row in packet) - 12
        assert (paid_k3 <= paid_k4) == (count <= 3)
        assert (paid_k3 == paid_k4) == (count == 3)
        crossover.append({"boundary_count": count, "paid_K4_packet": paid_k4,
                          "paid_K3_packet": paid_k3, "paid_scoped_packet": paid_scoped,
                          "K4_minus_K3": paid_k4 - paid_k3})
    return {"descriptor_cases": len(rows), "ordinary_formula_checks": len(rows),
            "boundary_formula_checks": 4 * len(rows),
            "scoped_four_node_savings_checked": len(rows),
            "logical_packet_crossover_checks": len(crossover),
            "logical_packet_crossover": crossover,
            "frozen_scope_checks": len(rows) + 1,
            "named_ordinary_modules": named,
            "deep_scope_example": {"descriptor_size": deep_label.size(),
                "full_call_size": outer.size(), "active_call_size": 4,
                "active_occurrences": {"v": 1, "w": 1, "c1": 1}},
            "cases": rows}


@dataclass(frozen=True)
class ScanWitness:
    target: int
    value: int
    predicate_bits: int


def scan_once(target: int, bits: int) -> tuple[ScanWitness, int]:
    """Compute one b BEFORE any probe is inspected; also check the invariant."""
    p = lambda x: bool(bits & (1 << x))
    state = 0
    invariant_checks = 0
    for n in range(target + 1):
        assert 0 <= state <= n
        assert state == 0 or p(state - 1)
        assert not p(state) or state == n
        invariant_checks += 1
        if n != target:
            state = n + 1 if p(state) else state
    return ScanWitness(target, state, bits), invariant_checks


def boundary_matrix(x: int, b: int, target: int, px: bool) -> tuple[bool, bool]:
    return (x + 1 != b or px,
            not (px and x == b) or b == target)


def require_uniform_table(table: tuple[tuple[int, int], ...]) -> int:
    """Reject pointwise witnesses, which would only test forall x exists b."""
    values = {b for _, b in table}
    if len(values) != 1:
        raise ValueError("The existential witness must be fixed before all probes.")
    return next(iter(values))


def scan_checks(max_target: int) -> dict:
    predicates = witnesses_created = invariant_checks = 0
    probe_instances = implication_checks = extension_cases = 0
    by_target = {}
    for target in range(max_target + 1):
        at_target = 0
        for bits in range(1 << (target + 1)):
            witness, checks = scan_once(target, bits)
            witnesses_created += 1
            invariant_checks += checks
            original_value = witness.value
            assert 0 <= original_value <= target
            # All four valuations of P(t+1), P(t+2) are tested. Neither may
            # affect the already computed witness or the matrix's truth.
            for extension in range(4):
                extended_bits = bits | (extension << (target + 1))
                table = tuple((x, witness.value) for x in range(target + 3))
                assert require_uniform_table(table) == original_value
                for x, b in table:
                    px = bool(extended_bits & (1 << x))
                    first, second = boundary_matrix(x, b, target, px)
                    assert first and second, (target, bits, extension, x, b)
                    if x > target:
                        # Explicit beyond-target probe guards.
                        assert x + 1 != b and x != b
                    probe_instances += 1
                    implication_checks += 2
                assert witness.value == original_value
                extension_cases += 1
            predicates += 1
            at_target += 1
        by_target[str(target)] = at_target
    assert predicates == (1 << (max_target + 2)) - 2
    assert witnesses_created == predicates
    assert extension_cases == 4 * predicates

    # Negative control: every pointwise matrix passes with b_x=x+2 and an
    # always-false P, but the existential witness illegally depends on x.
    fake_table = tuple((x, x + 2) for x in range(4))
    assert all(all(boundary_matrix(x, b, 1, False)) for x, b in fake_table)
    rejected = False
    try:
        require_uniform_table(fake_table)
    except ValueError:
        rejected = True
    assert rejected
    return {"maximum_target": max_target, "predicate_cases": predicates,
            "witnesses_created_before_probes": witnesses_created,
            "scan_invariant_instances": invariant_checks,
            "two_extra_probe_extension_cases": extension_cases,
            "probe_instances": probe_instances, "implication_checks": implication_checks,
            "predicate_cases_by_target": by_target,
            "probe_dependent_negative_control_rejected": rejected,
            "scope": "Every Boolean predicate on 0..t; all four extensions at t+1,t+2; "
                     "probes 0..t+2. The same single b is used for all probes. "
                     "The written proof, not this finite run, covers arbitrary t and all x."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scan-bound", type=int, default=12)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("core_results.json"))
    args = parser.parse_args()
    if not 0 <= args.scan_bound <= 16:
        parser.error("--scan-bound must be between 0 and 16")
    support = support_checks()
    syntax = scope_and_schema_checks()
    scans = scan_checks(args.scan_bound)
    result = {"status": "PASS", "python": sys.version.split()[0],
              "verifier_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "scope": "Finite syntax and bounded numerical diagnostics only. "
                       "Not a formal proof of iPRA, the interpretations, or minimality.",
              "support": support, "syntax": syntax, "scan": scans}
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    summary = {"status": result["status"], "output": str(args.output),
               "support": support, "descriptor_cases": syntax["descriptor_cases"],
               "named_ordinary_modules": syntax["named_ordinary_modules"], "scan": scans}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
