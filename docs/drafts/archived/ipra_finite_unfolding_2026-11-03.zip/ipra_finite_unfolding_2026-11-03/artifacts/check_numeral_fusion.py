#!/usr/bin/env python3
"""Finite syntax checks for a proved numeral-fusion identity family.

The tests model frozen descriptors and fully charged tree sizes. They are
executable checks of finite syntax, not a formal verification of iPRA.
"""
from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
import json
from pathlib import Path

@dataclass(frozen=True)
class T:
    tag: str
    args: tuple['T', ...] = ()
    body: 'T | None' = None

    def __str__(self):
        if self.tag == 'R':
            return 'R[' + str(self.body) + '](' + ','.join(map(str,self.args)) + ')'
        return self.tag if not self.args else self.tag + '(' + ','.join(map(str,self.args)) + ')'

Z=T('0'); V=T('v'); W=T('w'); A0=T('a'); N=T('n')
def op(s,*a): return T(s,tuple(a))
def S(t): return op('S',t)
def rec(h,n,a,*c): return T('R',(n,a,*c),h)
def numeral(k):
    t=Z
    for _ in range(k): t=S(t)
    return t

def as_numeral(t):
    k=0
    while t.tag=='S': k+=1; t=t.args[0]
    return k if t==Z else None

@lru_cache(None)
def size(t): return 1+sum(map(size,t.args))+(size(t.body) if t.body is not None else 0)

def subst(t,slots):
    if not t.args and t.body is None:
        return slots.get(t.tag,t)
    return T(t.tag,tuple(subst(a,slots) for a in t.args),t.body)

def vars_active(t):
    if not t.args:
        return {t.tag} if t.tag not in {'0'} else set()
    return set().union(*(vars_active(a) for a in t.args))

def ordinary_step(t):
    if t.tag!='R' or t.args[0].tag!='S': return None
    counter=t.args[0].args[0]
    state=rec(t.body,counter,*t.args[1:])
    slots={'v':state,'w':counter}
    slots.update({'c'+str(i):c for i,c in enumerate(t.args[2:],1)})
    return subst(t.body,slots)

def fused_numeral(t):
    if t.tag!='R': return None
    k=as_numeral(t.args[0])
    if k is None: return None
    value=t.args[1]
    for j in range(k):
        slots={'v':value,'w':numeral(j)}
        slots.update({'c'+str(i):c for i,c in enumerate(t.args[2:],1)})
        value=subst(t.body,slots)
    return value if size(value)<size(t) else None

# Root contraction from each source's OLD displayed reduction list.
def old_root(t,profile):
    if profile=='direct_native_p' and t.tag=='p':
        u=t.args[0]
        if u==Z: return Z
        if u.tag=='S': return u.args[0]
    if profile in {'direct_native_p','direct_generated_p'}:
        if t.tag=='R' and t.body==S(V) and t.args[1]==Z:
            return t.args[0]
    if profile=='shifted_u':
        if t.tag in {'L','Rproj'} and t.args[0].tag=='U':
            u,a=t.args[0].args
            if u==Z: return a if t.tag=='L' else Z
            if u.tag=='S': return u.args[0] if t.tag=='L' else a
        if t.tag=='U':
            u,a=t.args
            if u.tag=='S' and u.args[0].tag=='L' and a.tag=='Rproj' and u.args[0].args[0]==a.args[0]:
                return a.args[0]
            if u.tag=='L' and a.tag=='S' and a.args[0].tag=='Rproj' and u.args[0]==a.args[0].args[0]:
                return S(u.args[0])
    if profile=='shifted_b':
        if t.tag in {'L','Rproj'}:
            u=t.args[0]
            if u==Z: return Z
            if u.tag=='B': return u.args[0 if t.tag=='L' else 1]
            if u.tag=='S' and u.args[0].tag=='B':
                b,c=u.args[0].args
                if b==Z: return S(c) if t.tag=='L' else Z
                if b.tag=='S': return b.args[0] if t.tag=='L' else S(c)
        if t.tag=='B':
            b,c=t.args
            if b==Z and c==Z: return Z
            if b.tag=='L' and c.tag=='Rproj' and b.args[0]==c.args[0]: return b.args[0]
        if t.tag=='S' and t.args[0].tag=='B':
            b,c=t.args[0].args
            if b.tag=='S': return op('B',b.args[0],S(c))
    if t.tag=='R':
        if t.args[0]==Z: return t.args[1]
        if profile=='shifted_b' and t.args[0]==S(Z):
            r=fused_numeral(t)
            if r is not None: return r
        r=ordinary_step(t)
        if r is not None and size(r)<size(t): return r
    return None

def has_old_redex(t,profile):
    return old_root(t,profile) is not None or any(has_old_redex(a,profile) for a in t.args)

def normalize(t,profile,new):
    steps=0
    def one(t):
        for i,a in enumerate(t.args):
            aa,changed=one(a)
            if changed:
                args=list(t.args);args[i]=aa
                return T(t.tag,tuple(args),t.body),True
        r=old_root(t,profile)
        if r is None and new: r=fused_numeral(t)
        if r is not None:
            assert size(r)<size(t),(t,r)
            return r,True
        return t,False
    while True:
        t,changed=one(t)
        if not changed: return t,steps
        steps+=1

def predecessor(t,profile):
    if profile=='direct_native_p': return op('p',t)
    if profile=='direct_generated_p': return rec(W,t,Z)
    if profile=='shifted_u': return op('L',op('U',t,Z))
    if profile=='shifted_b': return op('L',S(op('B',t,Z)))
    raise ValueError(profile)

def family(k,profile):
    t=rec(S(V),numeral(k),V)
    for _ in range(k): t=predecessor(t,profile)
    return t


def main():
    profiles={'direct_native_p':2,'direct_generated_p':4,'shifted_u':4,'shifted_b':5}
    examples=[]
    for profile,coef in profiles.items():
        for k in range(2,65):
            inner=rec(S(V),numeral(k),V)
            raw=ordinary_step(inner)
            assert size(inner)==k+5 and size(raw)==k+5
            assert size(fused_numeral(inner))==k+1
            h=family(k,profile)
            assert vars_active(h)=={'v'}
            assert size(h)==coef*k+5
            assert not has_old_redex(h,profile),(profile,k)
            out,steps=normalize(h,profile,True)
            assert out==V
            call=rec(h,N,A0)
            assert size(call)==coef*k+8
            if k in {2,3,8,16,64}:
                examples.append({'profile':profile,'k':k,'descriptor_size':size(h),
                    'old_call_size':size(call),'new_call_size':1,
                    'saved_nodes':size(call)-1,'new_normalization_steps':steps})
    # Descriptor freezing: substituting active v never changes the frozen A body.
    t=rec(S(V),S(S(Z)),V)
    translated=subst(t,{'v':op('S',A0)})
    assert translated.body==S(V) and translated.args[1]==S(A0)
    # Literal numeral expansion agrees with repeated substitution in a body
    # depending on state, counter, and parameter slots, even if it grows.
    h=op('f',V,W,T('c1'))
    val=A0
    for j in range(4): val=op('f',val,numeral(j),T('b'))
    growing=rec(h,numeral(4),A0,T('b'))
    assert size(val)>size(growing) and fused_numeral(growing) is None
    result={'status':'PASS','range':'2 <= k <= 64','profiles':len(profiles),
            'family_cases':len(profiles)*63,
            'claim':'Finite symbolic checks only; proof is supplied separately.',
            'examples':examples}
    out=Path(__file__).with_name('numeral_fusion_results.json')
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
