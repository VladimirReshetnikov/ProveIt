#!/usr/bin/env python3
"""Structural and bounded numerical diagnostics for the accompanying paper.

This script checks finite syntax, explicit substitutions, exact displayed costs,
and bounded standard-natural-number examples. It is not a proof assistant and
it does not certify the full interpretation theorem or arbitrary models.
Only the Python standard library is required. Run: python3 code/verify.py
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from itertools import product


# A recursor node is ("R", frozen_descriptor, active_counter, active_initial).
# Frozen descriptors are counted, but active substitution never traverses them.
def var(name):
    return ("var", name)


ZERO = ("zero",)
v, w, a, n, u, x, y, b, m, z = map(var, "vwanuxybmz")


def S(t):
    return ("S", t)


def R(h, t, initial):
    return ("R", h, t, initial)


def eq(s, t):
    return ("eq", s, t)


def imp(A, B):
    return ("imp", A, B)


def conj(A, B):
    return ("and", A, B)


def conjunction(formulas):
    """Right-associated conjunction with one node per binary connective."""
    assert formulas
    result = formulas[-1]
    for formula in reversed(formulas[:-1]):
        result = conj(formula, result)
    return result


def K3(A, B, C):
    return ("K3", A, B, C)


def K4(A, B, C, D):
    return ("K4", A, B, C, D)


def bind(kind, names, body):
    for name in reversed(names):
        body = (kind, name, body)
    return body


def forall(names, body):
    return bind("forall", names, body)


def exists(names, body):
    return bind("exists", names, body)


def size(tree):
    """Full tree size, including every stored descriptor without sharing."""
    if tree[0] in ("var", "zero", "bottom"):
        return 1
    if tree[0] in ("forall", "exists"):
        return 1 + size(tree[2])
    return 1 + sum(size(child) for child in tree[1:])


def subst(term, mapping):
    """Active simultaneous substitution; stored descriptors remain frozen."""
    tag = term[0]
    if tag == "var":
        return mapping.get(term[1], term)
    if tag == "zero":
        return term
    if tag == "R":
        return R(term[1], subst(term[2], mapping), subst(term[3], mapping))
    return (tag, *(subst(child, mapping) for child in term[1:]))


def active_children(term):
    if term[0] == "R":
        return (2, 3)
    if term[0] == "S":
        return (1,)
    return ()


def occurrences(term, needle):
    return int(term == needle) + sum(
        occurrences(term[i], needle) for i in active_children(term)
    )


def probes(term):
    """Count active literal S(w) subtrees, never frozen descriptor subtrees."""
    if term == S(w):
        return 1
    return sum(probes(term[i]) for i in active_children(term))


def adapted(term, state, counter, successor_probe):
    """Replace S(w) first, then remaining active v and w leaves."""
    if term == S(w):
        return successor_probe
    if term == v:
        return state
    if term == w:
        return counter
    tag = term[0]
    if tag in ("var", "zero"):
        return term
    if tag == "R":
        return R(term[1], adapted(term[2], state, counter, successor_probe),
                 adapted(term[3], state, counter, successor_probe))
    return (tag, *(adapted(c, state, counter, successor_probe) for c in term[1:]))


def data(h):
    H, k, ell, j = size(h), occurrences(h, v), occurrences(h, w), probes(h)
    return H, k, ell, j, ell - j


Q = lambda t, c: R(w, t, c)
Z = lambda t, c: R(ZERO, t, c)
p = lambda t: Q(t, ZERO)
I = lambda t, c, d: Q(Z(t, S(c)), d)
ADD_BODY = S(v)
add = lambda s, t: R(ADD_BODY, t, s)
SUB_BODY = Q(v, ZERO)
diff = lambda s, t: R(SUB_BODY, t, s)
TRI_BODY = add(v, S(w))
triangle = lambda t: R(TRI_BODY, t, ZERO)
ONE = S(ZERO)
error = lambda s, t: Q(diff(S(s), t), ONE)
chi = lambda s, t: Z(error(s, t), ONE)
OLD_INDEX_BODY = add(v, chi(S(w), triangle(S(v))))
old_index = lambda t: R(OLD_INDEX_BODY, t, ZERO)
INDEX_BODY = add(v, Z(diff(triangle(S(v)), S(w)), ONE))
index = lambda t: R(INDEX_BODY, t, ZERO)


def ordinary(h):
    base = forall(["a"], eq(R(h, ZERO, a), a))
    step = forall(["a", "n"],
                  eq(R(h, S(n), a), subst(h, {"v": R(h, n, a), "w": n})))
    return base, step


def graph3(h):
    return forall(["a", "n", "u"],
                  K3(conj(eq(n, ZERO), eq(u, a)), eq(R(h, n, a), u),
                     eq(R(h, S(n), a), subst(h, {"v": u, "w": n}))))


def graph_plain(h):
    return forall(["a", "n", "u"],
                  imp(eq(R(h, n, a), u),
                      conj(imp(eq(n, ZERO), eq(u, a)),
                           eq(R(h, S(n), a), subst(h, {"v": u, "w": n})))))


def endpoint(h, arity):
    A, B, C = conj(eq(x, n), eq(y, u)), eq(R(h, x, a), y), eq(x, S(n))
    D = eq(y, adapted(h, u, n, x))
    matrix = K3(A, B, imp(C, D)) if arity == 3 else K4(A, B, C, D)
    return forall(["a", "n"], exists(["u"],
                  conj(imp(eq(n, ZERO), eq(u, a)), forall(["x", "y"], matrix))))


def folded(h):
    body = adapted(h, R(h, p(n), a), p(n), n)
    return forall(["a", "n"], eq(R(h, n, a), I(n, a, body)))


def predecessor_binding(h):
    assert occurrences(h, v) == 0
    body = adapted(h, ZERO, u, n)
    return forall(["a", "n", "u"],
                  imp(eq(p(n), u), eq(R(h, n, a), I(n, a, body))))


def identity():
    return forall(["a", "n"], eq(R(v, n, a), a))


def module_costs(h, arity):
    """Actual chosen modules in the combined, supported K3 or K4 profile."""
    D = sum(size(t) for t in ordinary(h))
    # Q and Z must not select a formula relying on their own helper equations.
    if h in (w, ZERO):
        return {"D_protected": D}
    costs = {}
    if h == v:
        costs["I"] = size(identity())
    costs["D"] = D
    costs["G3" if arity == 3 else "G_plain"] = size(
        graph3(h) if arity == 3 else graph_plain(h))
    costs[f"T{arity}_dagger"] = size(endpoint(h, arity))
    costs["P_dagger"] = size(folded(h))
    if occurrences(h, v) == 0:
        costs["L_dagger"] = size(predecessor_binding(h))
    return costs


def select(h, arity):
    costs = module_costs(h, arity)
    name = min(costs, key=costs.get)  # Dict order specifies deterministic ties.
    return {"module": name, "cost": costs[name]}


def old_recurring_cost(h):
    """Minimum current recurring module, with required bases paid separately.

    This is a comparison of native module prices across paid vocabularies, not
    a claim that one current theory has every option at one definition fee.
    """
    H, k, ell, j, r = data(h)
    if h in (w, ZERO):
        return 16
    candidates = [3*H + 13 + k*(H+2), 3*H + 21, 3*H + 22,
                  2*H + 32, 2*H - j + 33, 2*H - j + 32,
                  2*H + 13 + k*(H+5) + 3*ell]
    if k == 0:
        candidates.extend([2*H + 23, 2*H + 24, 2*H - j + 3*r + 22,
                           2*H + 21])
    if h == v:
        candidates.append(8)
    return min(candidates)


def norm_qz(term):
    """Unrestricted constructor reductions for Q,Z only; descriptors frozen."""
    tag = term[0]
    if tag in ("var", "zero"):
        return term
    if tag == "R":
        h, t, c = term[1], norm_qz(term[2]), norm_qz(term[3])
        if h in (w, ZERO):
            if t == ZERO:
                return c
            if t[0] == "S":
                return t[1] if h == w else ZERO
        return R(h, t, c)
    return (tag, *(norm_qz(child) for child in term[1:]))


def root_rewrite(term):
    """A root rewrite is eligible only if its RAW RHS is strictly smaller."""
    if term[0] != "R":
        return None
    h, counter, initial = term[1:]
    if counter == ZERO:
        return initial
    if counter[0] == "S":
        predecessor = counter[1]
        raw = subst(h, {"v": R(h, predecessor, initial), "w": predecessor})
        if size(raw) < size(term):
            return raw
    if h == v:
        return initial
    return None


def rewrite_once(term):
    """Root-first, left-to-right search for one eligible active rewrite."""
    changed = root_rewrite(term)
    if changed is not None:
        assert size(changed) < size(term)
        return changed
    for i in active_children(term):
        child = rewrite_once(term[i])
        if child is not None:
            result = list(term)
            result[i] = child
            result = tuple(result)
            assert size(result) < size(term)
            return result
    return None


def normalize_term(term):
    while True:
        rewritten = rewrite_once(term)
        if rewritten is None:
            return term
        term = rewritten


def serial(term):
    return json.dumps(term, ensure_ascii=True, separators=(",", ":"))


def normalize_equation(E):
    left, right = normalize_term(E[1]), normalize_term(E[2])
    while left[0] == "S" and right[0] == "S":
        left, right = left[1], right[1]
    if serial(right) < serial(left):
        left, right = right, left
    return eq(left, right)


def under_recursor(term, needle, inside=False):
    if term == needle:
        return inside
    return any(under_recursor(term[i], needle, inside or term[0] == "R")
               for i in active_children(term))


def false_base(E):
    base = normalize_equation(eq(subst(E[1], {"x": ZERO}),
                                 subst(E[2], {"x": ZERO})))
    left, right = base[1:]
    return ((left == ZERO and right[0] == "S") or
            (right == ZERO and left[0] == "S"))


def defining_equation(E):
    """Recognize actual defining instances, allowing normalized right sides."""
    for left, right in ((E[1], E[2]), (E[2], E[1])):
        if left[0] != "R":
            continue
        h, counter, initial = left[1:]
        if counter == ZERO:
            expected = initial
        elif counter[0] == "S":
            t = counter[1]
            expected = subst(h, {"v": R(h, t, initial), "w": t})
        elif h == v:
            expected = initial
        else:
            continue
        if normalize_term(expected) == normalize_term(right):
            return True
    return False


def diagonal_reflexivity(E):
    diagonal = normalize_equation(eq(subst(E[1], {"x": a}),
                                     subst(E[2], {"x": a})))
    return diagonal[1] == diagonal[2]


def omission_reason(E):
    # The axiom generator enumerates normalized, canonically oriented equations.
    # Canonicalize here as a convenience; omission depends only on this result.
    E = normalize_equation(E)
    if E[1] == E[2]:
        return "reflexive"
    if occurrences(E[1], x) + occurrences(E[2], x) == 0:
        return "x_independent"
    if not any(under_recursor(t, x) for t in E[1:]):
        return "no_x_under_recursor"
    if false_base(E):
        return "false_base"
    if defining_equation(E):
        return "defining_equation"
    if diagonal_reflexivity(E):
        return "diagonal_reflexivity"
    return None


def full_boundary(E, arity):
    args = eq(S(x), b), E, eq(x, b), eq(b, n)
    matrix = K3(args[0], args[1], imp(args[2], args[3])) if arity == 3 else K4(*args)
    return forall(["a", "n"], exists(["b"], forall(["x"], matrix)))


def diagonal_boundary(E, arity):
    args = eq(S(x), b), E, eq(x, b), eq(b, a)
    matrix = K3(args[0], args[1], imp(args[2], args[3])) if arity == 3 else K4(*args)
    return forall(["a"], exists(["b"], forall(["x"], matrix)))


def F(t):
    """Computation identity padding; its inner successor rewrite is a size tie."""
    return Q(add(t, ONE), ZERO)


# An additional, independent padding example whose raw expansion grows.
F_ALT_BODY = Q(S(v), v)
F_alt = lambda t: R(F_ALT_BODY, ONE, t)


def iterate(function, count, term):
    for _ in range(count):
        term = function(term)
    return term


def descriptor_samples():
    leaves = [ZERO, v, w, S(ZERO), S(v), S(w), S(S(w))]
    samples = leaves + [R(h, t, c) for h in [ZERO, w, S(v)]
                        for t, c in product(leaves[:6], repeat=2)]
    samples += [TRI_BODY, INDEX_BODY, OLD_INDEX_BODY, F_ALT_BODY,
                R(S(w), S(w), v),
                iterate(S, 99, w), iterate(S, 99, ZERO), iterate(S, 99, v)]
    return list(dict.fromkeys(samples))


def check_syntax():
    samples = descriptor_samples()
    state_free = 0
    for h in samples:
        H, k, ell, j, r = data(h)
        assert ell == j + r
        assert sum(size(t) for t in ordinary(h)) == 3*H + 13 + k*(H+2)
        assert size(graph3(h)) == 3*H + 21
        assert size(graph_plain(h)) == 3*H + 22
        assert size(endpoint(h, 3)) == 2*H - j + 33
        assert size(endpoint(h, 4)) == 2*H - j + 32
        assert size(folded(h)) == 2*H - j + 13 + k*(H+5) + 3*r
        # Symbolic base/step extraction uses only protected Q,Z equations.
        body = I(n, a, adapted(h, R(h, p(n), a), p(n), n))
        assert norm_qz(subst(body, {"n": ZERO})) == a
        extracted = norm_qz(subst(body, {"n": S(m)}))
        ordinary_step = norm_qz(subst(h, {"v": R(h, m, a), "w": m}))
        assert extracted == ordinary_step
        assert probes(adapted(h, u, n, x)) == 0
        if k == 0:
            state_free += 1
            assert size(predecessor_binding(h)) == 2*H - j + 21
        for arity in (3, 4):
            chosen = select(h, arity)
            assert chosen["cost"] == min(module_costs(h, arity).values())
    assert size(identity()) == 8
    for h in (ZERO, w):
        assert select(h, 3) == select(h, 4) == {"module": "D_protected", "cost": 16}
    # Substitution/normalization must not enter the frozen descriptor.
    frozen = R(Q(S(v), v), n, a)
    assert subst(frozen, {"v": ZERO, "w": ZERO}) == frozen
    assert normalize_term(frozen)[1] == frozen[1]
    nested = R(S(w), S(w), v)
    assert probes(nested) == 1
    assert adapted(nested, u, n, x)[1] == S(w)
    equations = [eq(R(h, x, a), a) for h in samples]
    for E in equations:
        f = size(E)
        assert size(full_boundary(E, 3)) == f + 16
        assert size(full_boundary(E, 4)) == f + 15
        assert size(diagonal_boundary(E, 3)) == f + 15
        assert size(diagonal_boundary(E, 4)) == f + 14
    return {"descriptors": len(samples), "state_free_descriptors": state_free,
            "symbolic_base_and_step": len(samples),
            "boundary_equations": len(equations), "frozen_descriptor_checks": 4}


def check_seed_sizes():
    old = [eq(add(S(a), x), S(add(a, x))),
           eq(diff(S(a), S(x)), diff(a, x)),
           eq(diff(add(a, x), x), a),
           eq(diff(add(x, a), x), a),
           eq(diff(a, add(x, a)), ZERO),
           eq(I(diff(a, x), a, add(x, diff(a, x))), a),
           eq(Z(diff(x, a), error(old_index(add(triangle(a), x)), a)), ZERO)]
    new = [eq(diff(add(a, x), x), a),
           eq(diff(a, add(a, x)), ZERO),
           eq(index(add(x, triangle(add(a, x)))), add(a, x))]
    assert size(TRI_BODY) == 6
    assert size(OLD_INDEX_BODY) == 30
    assert size(INDEX_BODY) == 25
    assert [size(E) for E in old] == [13, 17, 13, 13, 13, 26, 67]
    old_costs = [size(forall(["a", "x"], E)) for E in old]
    new_costs = [size(forall(["a", "x"], E)) for E in new]
    assert sum(old_costs) == 176
    assert new_costs == [15, 15, 52] and sum(new_costs) == 82
    old_shared = size(forall(["a", "x"], conjunction(old)))
    new_shared = size(forall(["a", "x"], conjunction(new)))
    assert old_shared == 170 and new_shared == 80
    # Normalizing exceptions can only decrease their equation sizes.
    normalized = [normalize_equation(E) for E in old + new]
    assert all(size(E) <= 67 for E in normalized)
    return {"triangle_descriptor": 6, "old_index_descriptor": 30,
            "new_index_descriptor": 25, "old_seven_closures": old_costs,
            "old_seven_total": 176, "old_seven_shared_closure": old_shared,
            "new_three_closures": new_costs, "new_three_total": 82,
            "new_three_shared_closure": new_shared,
            "exception_equation_size_upper_bound": 67}, normalized


def check_bootstrap_profiles(seed_cost):
    """Count finite supported bootstrap fragments, not finite axiomatizations."""
    coverage = forall(["z"], exists(["y"], ("or", eq(z, ZERO), eq(z, S(y)))))
    separation = imp(eq(ZERO, ONE), ("bottom",))
    k3_record = size(K3(a, b, x)) + size(conj(imp(a, b), imp(b, x))) + 1
    k4_record = size(K4(a, b, x, y)) + size(conj(imp(a, b), imp(b, imp(x, y)))) + 1
    assert (size(coverage), size(separation), k3_record, k4_record) == (10, 6, 12, 15)
    bodies = [("Q", w), ("Z", ZERO), ("A", ADD_BODY), ("D", SUB_BODY),
              ("U", TRI_BODY), ("lambda", INDEX_BODY)]
    profiles = {}
    for basis in ("K3", "K4", "K3_K4"):
        selected = []
        for name, h in bodies:
            if basis == "K3_K4":
                costs = module_costs(h, 3)
                costs.update(module_costs(h, 4))
                chosen_name = min(costs, key=costs.get)
                chosen = {"module": chosen_name, "cost": costs[chosen_name]}
            else:
                chosen = select(h, 3 if basis == "K3" else 4)
            selected.append({"symbol": name, "descriptor_size": size(h), **chosen})
        modules = sum(row["cost"] for row in selected)
        definitions = (k3_record if basis == "K3" else
                       k4_record if basis == "K4" else k3_record + k4_record)
        fixed = size(coverage) + size(separation) + definitions
        profiles[basis] = {"modules": selected, "module_total": modules,
                           "shared_three_seed_sentence": seed_cost,
                           "coverage": size(coverage), "separation": size(separation),
                           "logical_definition_records": definitions,
                           "fixed_record": fixed, "ordinary_total": modules + seed_cost + fixed,
                           "positive_total": modules + seed_cost + fixed - size(separation)}
    assert [profiles[key]["module_total"] for key in ("K3", "K4", "K3_K4")] == [202, 201, 201]
    assert [profiles[key]["ordinary_total"] for key in ("K3", "K4", "K3_K4")] == [310, 312, 324]
    return {"scope": "Finite supported bootstrap fragments; boundary schema is additional",
            "profiles": profiles}


def check_normalizer(exceptions):
    tests = 0
    for h in descriptor_samples():
        term = R(h, S(x), a)
        nf = normalize_term(term)
        assert size(nf) <= size(term)
        assert normalize_term(nf) == nf
        tests += 1
    # The stated strictness concerns the raw RHS, not a normalized RHS.
    assert size(add(a, ONE)) == size(S(add(a, ZERO))) == 5 + size(a)
    assert root_rewrite(add(a, ONE)) is None
    for t in (x, a, ZERO, Q(x, a)):
        t = normalize_term(t)
        assert size(F(t)) == 8 + size(t)
        assert normalize_term(F(t)) == F(t)
        # Explicit ordinary computation proves F(t)=t, despite the blocked tie.
        one_step = Q(S(add(t, ZERO)), ZERO)
        explicit = Q(S(t), ZERO)  # The addition base is now applied.
        assert norm_qz(explicit) == t
        assert size(one_step) == size(F(t))
        assert size(F_alt(t)) == 8 + size(t)
        raw_alt = subst(F_ALT_BODY, {"v": R(F_ALT_BODY, ZERO, t), "w": ZERO})
        assert size(raw_alt) == 17 + 2*size(t)
        assert normalize_term(F_alt(t)) == F_alt(t)
        explicit_alt = subst(F_ALT_BODY, {"v": t, "w": ZERO})
        assert norm_qz(explicit_alt) == t
        tests += 1
    E = eq(F(x), F(a))
    assert not false_base(E) and not defining_equation(E)
    assert under_recursor(E[1], x)
    assert omission_reason(E) == "diagonal_reflexivity"
    assert omission_reason(eq(Q(S(x), a), x)) == "reflexive"
    assert omission_reason(eq(x, a)) == "no_x_under_recursor"
    assert omission_reason(eq(x, S(p(x)))) == "false_base"
    # Padding remains visible and exceeds every finite exception's size.
    padded_cases = 0
    for E in exceptions:
        left, right = E[1:]
        repetitions = 0
        while size(eq(left, right)) <= 67:
            left, right = F(left), F(right)
            repetitions += 1
        padded = normalize_equation(eq(left, right))
        assert size(padded) > 67
        assert padded not in exceptions
        assert size(padded) == size(E) + 16*repetitions
        padded_cases += 1
    return {"normalization_examples": tests, "omission_examples": 4,
            "finite_exception_padding_cases": padded_cases,
            "padding_full_size_increment_per_side": 8,
            "alternative_padding_raw_expansion": "17+2|t|",
            "strict_tie_rejected": True, "normalizer_idempotence": True}


def comparison_table():
    examples = [("S(w)", S(w)), ("S^99(w)", iterate(S, 99, w)),
                ("S^99(0)", iterate(S, 99, ZERO)),
                ("v+S(w)", TRI_BODY),
                ("Q(v,v)", Q(v, v)),
                ("threshold lambda update", INDEX_BODY),
                ("literal identity", v)]
    rows = []
    for name, h in examples:
        H, k, ell, j, r = data(h)
        rows.append({"descriptor": name, "H": H, "k": k, "ell": ell,
                     "j": j, "r": r, "current_recurring_minimum": old_recurring_cost(h),
                     "new_K3": select(h, 3), "new_K4": select(h, 4)})
    lookup = {row["descriptor"]: row for row in rows}
    assert lookup["v+S(w)"]["current_recurring_minimum"] == 39
    assert lookup["v+S(w)"]["new_K4"]["cost"] == 35
    assert lookup["S^99(w)"]["current_recurring_minimum"] == 216
    assert lookup["S^99(w)"]["new_K4"]["cost"] == 212
    assert lookup["Q(v,v)"]["new_K3"]["cost"] == 33
    assert lookup["Q(v,v)"]["new_K4"]["cost"] == 34
    return rows


def check_numerics(bound=20):
    """Diagnostics in standard N, not an argument about nonstandard models."""
    tri = lambda k: k*(k+1)//2
    sub = lambda s, t: max(s-t, 0)
    pair = lambda first, second: second + tri(first+second)
    limit = max(pair(first, second) for first, second in product(range(bound), repeat=2))
    # Evaluate the actual new primitive recursion once up to every needed code.
    lam = [0]
    for counter in range(limit):
        previous = lam[-1]
        test = sub(tri(previous+1), counter+1)
        lam.append(previous + int(test == 0))
    assert all(lam[t] == (math.isqrt(8*t+1)-1)//2 for t in range(limit+1))
    seeds = 0
    pairing = 0
    domination = 0
    for first, second in product(range(bound), repeat=2):
        assert sub(first+second, second) == first
        assert sub(first, first+second) == 0
        assert lam[second+tri(first+second)] == first+second
        seeds += 3
        code = pair(first, second)
        second_projection = sub(code, tri(lam[code]))
        first_projection = sub(lam[code], second_projection)
        assert (first_projection, second_projection) == (first, second)
        pairing += 2
        assert sub(second, code) == 0
        domination += 1
    clamp = lambda t, target: sub(target, sub(target, t))
    clamp_base = clamp_step = clamp_endpoint = 0
    for target in range(bound):
        assert clamp(0, target) == 0
        clamp_base += 1
        for t in range(limit+1):
            assert clamp(t+1, target) in (clamp(t, target), clamp(t, target)+1)
            clamp_step += 1
            if sub(target, t) == 0:
                assert clamp(t, target) == target
                clamp_endpoint += 1
    return {"parameter_bound_exclusive": bound, "largest_pair_code": limit,
            "lambda_recursion_values": len(lam), "three_seed_instances": seeds,
            "pairing_projection_equalities": pairing,
            "pair_dominates_second_coordinate": domination,
            "clamp_base": clamp_base, "clamp_step": clamp_step,
            "clamp_endpoint": clamp_endpoint}


def main():
    syntax = check_syntax()
    seeds, exceptions = check_seed_sizes()
    bootstrap = check_bootstrap_profiles(seeds["new_three_shared_closure"])
    normalizer = check_normalizer(exceptions)
    table = comparison_table()
    numerical = check_numerics()
    result = {
        "status": "all checks passed",
        "source_snapshot": "6f293758d174c06a313e3de5caa25a4c16ad392b",
        "scope": "Exact syntax and bounded standard-N diagnostics; not a full formal proof",
        "syntax": syntax, "seed_sizes": seeds, "normalizer": normalizer,
        "bootstrap_fragments": bootstrap,
        "comparison_scope": "Native recurring module prices; logical bases and support paid separately",
        "comparison_examples": table, "bounded_numeric_diagnostics": numerical,
        "protected_support": {"Q_ordinary": 16, "Z_ordinary": 16},
        "fixed_records": {"positive_K3": 22, "positive_K4": 25,
                          "ordinary_K3": 28, "ordinary_K4": 31,
                          "positive_K3_K4": 37},
        "full_metatheorem_machine_formalized": False,
    }
    destination = Path(__file__).resolve().parents[1] / "verification" / "results.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "syntax": syntax,
                      "seed_sizes": seeds, "normalizer": normalizer,
                      "bootstrap_fragment_totals": {
                          key: value["ordinary_total"]
                          for key, value in bootstrap["profiles"].items()},
                      "bounded_numeric_diagnostics": numerical}, indent=2))


if __name__ == "__main__":
    main()
