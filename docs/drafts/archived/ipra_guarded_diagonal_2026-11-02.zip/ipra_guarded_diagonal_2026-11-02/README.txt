THREE SEED EQUATIONS FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Guarded folds, diagonal induction, and finite omissions
Prepared for Vladimir Reshetnikov, 2 November 2026
====================================================================

MAIN RESULT
The complete effective first-order theories T3, T4, T34 in report.tex
are bi-interpretable and equiconsistent with full intuitionistic PRA.
Both domains are the whole numerical carrier, equality and genuine
falsity are preserved, and both composite isomorphisms are x=y.
The recommended compact boundary profile is T4; T3 and the paid mixed
profile retain useful alternatives for different computation clauses.

NEW REDUCTIONS
- Three direct arithmetic equations replace the diagonal draft's seven.
  Separate closures: 176 -> 82 nodes.
  Equally bundled universal prefixes: 170 -> 80 nodes.
- The new threshold decoder has descriptor size25 instead of30.
- Guarded folded recursion saves4j over the old folded branch.
  The state-free predecessor-binding branch savesj.
- A diagonal-reflexivity test removes an infinite family of boundaries.
- Computation-provable padding justifies finite exception deletion,
  including the seven old protected indices, without circular induction.

These figures use the full-tree descriptor accounting of the inspected
drafts. They do not establish an encoding-independent absolute minimum.
Logical bases and finite proof support must be charged separately.
Three seed equations are not the whole axiom set: the theory also has
computation, separation, coverage, and an infinite boundary schema.

CONTENTS
report.pdf                  Compiled mathematical paper
report.tex                  Complete, standalone LaTeX source
AXIOMS.txt                  Exact plain-text theory specification
build.py                    Re-run diagnostics and compile the PDF
code/verify.py              Standard-library Python structural checker
provenance/source_manifest.json
                            Immutable snapshot and archive hashes
provenance/draft_audit.json  Ten-package audit
provenance/review.csv        Compact audit table
verification/results.json  Exact syntax and bounded numerical results
verification/build.json    Build summary
verification/latex_build.txt
                            Reproducible compilation log
verification/visual_review.json
                            PDF layout review record
SHA256SUMS.txt              Hashes of the delivered files

REPRODUCTION
Run from any working directory:
  python3 path/to/package/build.py

The mathematical checker uses only Python's standard library.
The PDF build requires pdflatex and the LaTeX packages listed in report.tex.
Run only the diagnostics with:
  python3 path/to/package/code/verify.py

PROOF STATUS
The full theorem is proved in the paper. The Python checks establish
exact finite syntax counts, selected symbolic computations, the concrete
normalizer/padding side conditions, and bounded standard-N examples.
They are not a complete Lean/Rocq verification and are not being used
as substitutes for the mathematical proof.

IMPORTANT NORMALIZER DETAIL
Only a strict decrease of the RAW one-step right-hand side permits a
constructor rewrite. Equal-size rewrites and normalized-RHS look-ahead
are excluded. Frozen function descriptors are never rewritten.
This exact policy is used by the padding proof.

SOURCE SNAPSHOT
Repository: VladimirReshetnikov/ProveIt
Commit: 6f293758d174c06a313e3de5caa25a4c16ad392b
Directory: docs/drafts, including archived
Inventory: five current ZIPs and five archived ZIPs
The research package is a standalone deliverable; it does not alter
the inspected repository.
