#!/usr/bin/env python3
"""Reproduce the mathematical diagnostics and compile the accompanying paper."""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / "verification"
VERIFY.mkdir(exist_ok=True)


def main():
    checked = subprocess.run(
        [sys.executable, str(ROOT / "code" / "verify.py")],
        cwd=ROOT, text=True, capture_output=True, check=True,
    )
    if not shutil.which("pdflatex"):
        raise SystemExit("pdflatex is required to build report.pdf.")
    logs = []
    with tempfile.TemporaryDirectory(prefix="ipra-tex-") as work:
        for number in range(1, 4):
            command = [
                "pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                "-file-line-error", "-output-directory", work,
                str(ROOT / "report.tex"),
            ]
            result = subprocess.run(
                command, cwd=ROOT, text=True, capture_output=True,
            )
            logs.append(f"PASS {number}\n{result.stdout}\n{result.stderr}")
            if result.returncode:
                (VERIFY / "latex_build.txt").write_text(
                    "\n".join(logs), encoding="utf-8",
                )
                raise SystemExit(f"LaTeX failed on pass {number}; see the build log.")
        shutil.copyfile(Path(work) / "report.pdf", ROOT / "report.pdf")
        final_log = (Path(work) / "report.log").read_text(
            encoding="utf-8", errors="replace",
        )
    (VERIFY / "latex_build.txt").write_text("\n".join(logs), encoding="utf-8")
    warnings = [
        line for line in final_log.splitlines()
        if ("Warning" in line or "Overfull" in line or "Undefined" in line)
    ]
    match = re.search(r"Output written on .*?\((\d+) pages?", final_log, re.S)
    summary = {
        "mathematical_checks": "passed",
        "latex_passes": 3,
        "pdf": "report.pdf",
        "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
        "pages": int(match.group(1)) if match else None,
        "final_pass_warnings": warnings,
        "full_theorem_machine_formalized": False,
        "visual_review": "separate from this build script",
    }
    (VERIFY / "build.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
