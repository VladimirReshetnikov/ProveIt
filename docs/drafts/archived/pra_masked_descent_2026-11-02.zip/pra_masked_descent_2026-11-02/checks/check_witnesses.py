#!/usr/bin/env python3
"""Finite executable checks complementing, not replacing, the proofs."""
import itertools
import json
from pathlib import Path


def q(x, a):
    return a if x == 0 else x - 1


def z(x, a):
    return a if x == 0 else 0


def neg(a):
    return z(a, 1)


def conjunction(a, b):
    return z(neg(a), b)


def disjunction(a, b):
    return neg(conjunction(neg(a), neg(b)))


def implication(a, b):
    return neg(conjunction(a, neg(b)))


boolean_cases = 0
for a, b in itertools.product((0, 1), repeat=2):
    assert neg(a) == int(not a)
    assert conjunction(a, b) == int(bool(a and b))
    assert disjunction(a, b) == int(bool(a or b))
    assert implication(a, b) == int(bool((not a) or b))
    boolean_cases += 1

patterns = targets = 0
for length in range(2, 16):
    for bits in itertools.product((0, 1), repeat=length - 1):
        # 1 designates a nonzero mask value; f(0)=0 is compulsory.
        f = [0] + [i if bit else 0 for i, bit in enumerate(bits, start=1)]
        c = [0] * length
        for n in range(length - 1):
            c[n + 1] = n if f[n] == 0 else c[n]
        for n in range(length):
            b = c[n]
            assert f[b] == 0
            assert f[n] == 0 or f[b + 1] != 0
            assert f[q(f[b + 1], n)] == 0  # W13
            b12 = b + 1
            assert f[q(f[b12], n)] == 0  # W12, same witness shifted
            targets += 1
        patterns += 1

def triangle(n):
    return n * (n + 1) // 2

grid = 80
max_code = triangle(2 * grid) + grid
k = [0] * (max_code + 1)
for n in range(max_code):
    k[n + 1] = k[n] + int(n + 1 == triangle(k[n] + 1))
for x, y in itertools.product(range(grid + 1), repeat=2):
    code = triangle(x + y) + y
    right = max(code - triangle(k[code]), 0)
    left = max(k[code] - right, 0)
    assert (left, right) == (x, y)

# Exhaust all zero-or-input masks on a finite part of two chains.
# This is an illustration of the proved infinite countermodel, not
# a finite first-order model of successor injectivity/non-surjectivity.
carrier = [(n, side) for side in (0, 1) for n in range(6)]
zero = (0, 0)
extra_root = (0, 1)
nonzero = [x for x in carrier if x != zero]

def forest_q(x, a):
    if x == zero:
        return a
    if x == extra_root:
        return zero
    return (x[0] - 1, x[1])

forest_patterns = forest_targets = 0
for bits in itertools.product((0, 1), repeat=len(nonzero)):
    f = {zero: zero}
    f.update({x: (x if bad else zero) for x, bad in zip(nonzero, bits)})
    for n in carrier:
        assert any(f[forest_q(f[b], n)] == zero for b in carrier)
        forest_targets += 1
    forest_patterns += 1

# The coverage mask is zero on every successor and nonzero only at e.
# For any b, inner f(Sb)=0, so W13 at e selects e and fails.
assert forest_q(zero, extra_root) == extra_root

results = {
    "status": "PASS",
    "scope": "Finite witness and syntax-related checks; mathematical proofs are in report.tex and Lean kernels.",
    "boolean_truth_table_pairs": boolean_cases,
    "zero_or_input_pattern_lengths": [2, 15],
    "zero_or_input_patterns": patterns,
    "targets_tested_for_each_of_W13_and_W12": targets,
    "pairing_grid": [0, grid],
    "pairing_pairs_tested": (grid + 1) ** 2,
    "two_chain_prefix_length_per_chain": 6,
    "two_chain_mask_patterns": forest_patterns,
    "two_chain_targets": forest_targets,
    "arbitrary_carrier_forward_claims": "Lean kernels plus written proof, not inferred from finite tests"
}
output = Path(__file__).resolve().parent / "witness_results.json"
output.write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))

