from dataclasses import dataclass
from typing import Optional
import json
from pathlib import Path

records=[]

@dataclass(frozen=True)
class Node:
    tag: str
    args: tuple=()
    descriptor: Optional['Node']=None

def V(n): return Node(n)
def F(n,*xs,descriptor=None): return Node(n,xs,descriptor)
def S(x): return F('S',x)
def E(a,b): return F('=',a,b)
def And(a,b): return F('and',a,b)
def Imp(a,b): return F('imp',a,b)
def All(n,a): return F('all:'+n,a)
def Ex(n,a): return F('ex:'+n,a)
def forall(ns,a):
    for n in reversed(ns): a=All(n,a)
    return a

def size(t,full=False):
    return 1+sum(size(a,full) for a in t.args)+(size(t.descriptor,True) if full and t.descriptor is not None else 0)

def counts(t): return size(t),size(t,True)
def occ(t,v): return (1 if not t.args and t.tag==v else 0)+sum(occ(a,v) for a in t.args)
def subst(t,m):
    if not t.args and t.tag in m: return m[t.tag]
    return Node(t.tag,tuple(subst(a,m) for a in t.args),t.descriptor)

x,z,v,w,n,a,b,c=(V(s) for s in ('x','z','v','w','n','a','b','c'))
zero=V('0')
one=S(zero)
def Q(x,y): return F('Q',x,y,descriptor=w)
def Z(x,y): return F('Z',x,y,descriptor=zero)
def chi(x,y): return F('chi',x,y)
def R(h,x,y): return F('R',x,y,descriptor=h)
def M(t,x,y): return F('M',x,y,descriptor=Z(t,V('x')))

def old(t):
    ht=Z(chi(subst(t,{'x':w,'z':Q(v,zero)}),zero),v)
    rn=R(ht,n,a)
    base=E(R(ht,zero,a),a)
    step=E(R(ht,S(n),a),subst(ht,{'v':rn,'w':n}))
    bound=All('c',Imp(E(rn,c),E(R(ht,S(n),a),subst(ht,{'v':c,'w':n}))))
    direct=forall(('a','n'),And(base,step))
    bounded=forall(('a','n'),And(base,bound))
    wit=forall(('a','n'),Ex('b',E(R(ht,Q(Z(R(ht,b,a),b),n),a),a)))
    return ht,direct,bounded,wit

def new(t,shift=True):
    definition=forall(('x','z'),E(M(t,x,z),Z(t,x)))
    wit=forall(('z','n'),Ex('b',E(M(t,Q(M(t,S(b) if shift else b,z),n),z),zero)))
    return definition,wit

samples=[x,z,zero,chi(x,z),chi(z,z),chi(S(x),Q(z,zero)),R(S(v),x,z),chi(R(S(v),x,z),R(v,z,z))]
for t in samples:
    m,W=counts(t); j=occ(t,'z')
    ht,di,bo,p14=old(t)
    assert counts(ht)==(m+2*j+4,W+3*j+5)
    assert counts(p14)==(14,16+2*(W+3*j+5))
    old_d=tuple(sum(vals) for vals in zip(counts(di),counts(p14)))
    old_b=tuple(sum(vals) for vals in zip(counts(bo),counts(p14)))
    assert old_d==(m+4*j+33,31+2*j+(6+j)*(W+3*j+5))
    assert old_b==(m+2*j+38,36+6*(W+3*j+5))
    for shift in (True,False):
        de,wi=new(t,shift)
        assert counts(de)==(m+8,12+2*W)
        assert counts(wi)==(13 if shift else 12,(20 if shift else 19)+2*W)
        total=tuple(sum(vals) for vals in zip(counts(de),counts(wi)))
        assert total==(m+(21 if shift else 20),(32 if shift else 31)+4*W)
        assert all(a>b for a,b in zip(old_d,total))
        assert all(a>b for a,b in zip(old_b,total))
    records.append({'tail':str(t),'m':m,'W':W,'j':j,'old_direct':old_d,'old_bound':old_b,'new_shifted':(m+21,32+4*W),'new_unshifted':(m+20,31+4*W)})
print('All independent expanded-AST counts and inequalities passed.')

def comp_for_body(h):
    rn=R(h,n,a)
    base=E(R(h,zero,a),a)
    direct=forall(('a','n'),And(base,E(R(h,S(n),a),subst(h,{'v':rn,'w':n}))))
    bound=forall(('a','n'),And(base,All('c',Imp(E(rn,c),E(R(h,S(n),a),subst(h,{'v':c,'w':n}))))))
    return direct,bound

def separated(t):
    ht=old(t)[0]
    gt=Q(Z(chi(w,zero),S(ht)),v)
    step_tail=subst(ht,{'v':a,'w':S(b)})
    q=Q(Z(chi(step_tail,a),S(b)),n)
    one=forall(('a','n'),Ex('b',E(R(gt,S(q),a),a)))
    tail=forall(('a','n'),Ex('b',And(E(R(gt,S(b),a),a),Imp(E(step_tail,a),E(b,n)))))
    direct,bound=comp_for_body(gt)
    return gt,one,tail,direct,bound

for t in samples:
    m,W=counts(t); j=occ(t,'z'); i=occ(t,'x')
    gt,one,tail,direct,bound=separated(t)
    WG=W+3*j+14
    assert counts(gt)==(m+2*j+11,WG)
    assert occ(gt,'v')==j+2
    assert counts(one)==(m+2*j+i+19,8+2*WG+i)
    assert counts(tail)==(m+2*j+i+20,7+2*WG+i)
    direct_total=tuple(sum(vals) for vals in zip(counts(direct),counts(one)))
    bound_total=tuple(sum(vals) for vals in zip(counts(bound),counts(one)))
    assert direct_total==(2*m+6*j+i+47,25+2*j+i+(7+j)*WG)
    assert bound_total==(2*m+4*j+i+50,28+6*WG+i)
    c13=(m+21,32+4*W)
    assert tuple(old-new for old,new in zip(direct_total,c13))==(m+6*j+i+26,(j+3)*W+3*j*j+37*j+i+91)
    assert tuple(old-new for old,new in zip(bound_total,c13))==(m+4*j+i+29,2*W+18*j+i+80)
print('All Separated One/Tail full-support AST counts passed.')

def absorbing(t):
    tail=chi(subst(t,{'x':w,'z':Q(v,zero)}),zero)
    dt=Z(chi(v,zero),Z(tail,S(Q(v,zero))))
    ht=Q(Z(chi(w,zero),S(dt)),v)
    q=Q(Z(R(ht,S(S(b)),a),S(b)),n)
    wit=forall(('a','n'),Ex('b',E(R(ht,S(q),a),a)))
    direct,bound=comp_for_body(ht)
    return ht,wit,direct,bound

for t in samples:
    m,W=counts(t); j=occ(t,'z')
    ht,wit,direct,bound=absorbing(t)
    WH=W+3*j+23
    assert counts(ht)==(m+2*j+18,WH)
    assert occ(ht,'v')==j+3
    assert counts(wit)==(18,20+2*WH)
    dtot=tuple(sum(vs) for vs in zip(counts(direct),counts(wit)))
    btot=tuple(sum(vs) for vs in zip(counts(bound),counts(wit)))
    assert dtot==(m+4*j+55,39+2*j+(8+j)*WH)
    assert btot==(m+2*j+56,40+6*WH)
    c13=(m+21,32+4*W)
    assert tuple(o-n for o,n in zip(dtot,c13))==(4*j+34,(4+j)*W+3*j*j+49*j+191)
    assert tuple(o-n for o,n in zip(btot,c13))==(2*j+35,2*W+18*j+146)
print('All Absorbing complete-support AST counts passed.')

for t in samples:
    if occ(t,'x')!=0: continue
    m,W=counts(t); j=occ(t,'z'); ht,_,_,wit=old(t)
    base=E(R(ht,zero,a),a)
    right=forall(('a','n'),And(base,E(R(ht,S(n),a),R(ht,n,subst(ht,{'v':a,'w':zero})))))
    WH=W+3*j+5
    assert counts(right)==(15+m+2*j+4,15+4*WH)
    total=tuple(sum(vs) for vs in zip(counts(right),counts(wit)))
    assert total==(m+2*j+33,31+6*WH)
    assert tuple(o-n for o,n in zip(total,(m+21,32+4*W)))==(2*j+12,2*W+18*j+29)
print('All eligible autonomous-right P14 support AST counts passed.')

for t in samples:
    m,W=counts(t); j=occ(t,'z'); gt,_,_,direct,bound=separated(t)
    BW=forall(('a','n'),Ex('b',And(E(R(gt,S(b),a),a),Imp(E(R(gt,S(S(b)),a),a),E(b,n)))))
    WG=W+3*j+14
    assert counts(BW)==(21,21+2*WG)
    dtot=tuple(sum(vs) for vs in zip(counts(direct),counts(BW)))
    btot=tuple(sum(vs) for vs in zip(counts(bound),counts(BW)))
    assert tuple(o-n for o,n in zip(dtot,(m+21,32+4*W)))==(4*j+28,(j+3)*W+3*j*j+37*j+104)
    assert tuple(o-n for o,n in zip(btot,(m+21,32+4*W)))==(2*j+31,2*W+18*j+93)
print('All Separated primary boundary support AST counts passed.')

y=V('y'); bot=V('bottom')
sep=Imp(E(zero,S(zero)),bot)
bit=forall(('x','y'),And(E(chi(x,x),S(zero)),F('or',E(x,y),E(chi(x,y),zero))))
cov=All('x',Ex('y',F('or',E(x,zero),E(x,S(y)))))
part=All('x',Ex('y',Imp(E(chi(x,zero),chi(x,S(y))),bot)))
assert counts(sep)==(6,6)
assert counts(bit)==(18,18)
assert counts(cov)==(10,10)
assert counts(part)==(12,12)
print('Fixed bases: Sep+Bit=24, Sep+Bit+Cov=34, Bit+Part=30 in both metrics.')

def D(x,y): return F('D',x,y)
off=forall(('x','y'),F('or',E(x,y),E(D(x,y),zero)))
dpart=All('x',Ex('y',Imp(E(D(x,zero),D(x,D(y,y))),bot)))
assert counts(off)==(11,11)
assert counts(dpart)==(13,13)
print('Merged discriminator fixed basis: 11+13=24 in both metrics.')

report={'status':'PASS','sample_tails':len(samples),'families':['P14 direct','P14 bound','eligible P14 right','Separated primary','Separated One','Separated Tail','Absorbing direct','Absorbing bound','Mask W13','Mask W12'],'scope':'Actual formula trees and frozen-descriptor costs; general inequalities are proved in report.tex.','examples':records}
Path(__file__).with_name('count_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='examples'},indent=2))
