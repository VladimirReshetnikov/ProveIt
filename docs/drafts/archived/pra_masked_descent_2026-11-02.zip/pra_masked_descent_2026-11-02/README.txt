PRA FROM POINTWISE MASKS
Prepared for Vladimir Reshetnikov, 2 November 2026

START HERE
  report.pdf       Complete research report and mathematical proofs.
  report.tex       Main TeX source; includes sections/*.tex.
  AXIOMS.txt       Exact standalone theories and grammar.

RESULT
  A direct pointwise mask replaces the recursive truth-carrying orbit.
  Main witness: 13 active nodes, no separate coverage axiom.
  Alternative: 12 active nodes with a 10-node coverage sentence.
  Both theories are bi-interpretable and equiconsistent with first-order
  PRA via common conservative definitional extensions. All arithmetic
  symbols are at most binary. Both composites are internally identities.
  An additional version DM12 has initial symbols only 0,D, a 24-node
  fixed basis and the 12-node witness. Its larger expanded successor
  and equality terms are disclosed as a vocabulary/size tradeoff.

HONEST COMPARISON
  All six current drafts at the pinned commit were examined.
  Uniform witness profiles improve on the best 14-node predecessor
  witness. The new composition definitions are charged in a separate
  finite-support comparison, with strict inequalities proved in the report.
  This is not a global shortestness theorem, a total-size comparison of
  infinite axiom sets, or pointwise domination of every old scheduler.
  In particular, canonical six-node base equations remain a separate
  scheduling phenomenon.

VERIFICATION
  formal/MaskedIndex.lean: ten audited local kernels, Lean 4.19.0 / Std.
  All printed axiom dependencies are empty. The entire bi-interpretation
  is NOT claimed to be mechanized; see formal/SCOPE.txt.
  formal/MergedDiscriminator.lean adds eight checked bootstrap and
  identity-reconstruction theorems for the two-primitive-symbol variant.
  checks/check_counts.py: expanded syntax trees and frozen-descriptor costs.
  checks/check_witnesses.py: exhaustive finite masks, scans, pairing checks.
  provenance/source_manifest.json: six pinned input archives and hashes.
  verification/: actual build and inspection records.

REPRODUCE
  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

Requirements: Python 3.10+, pdflatex and ordinary TeX Live packages
named in report.tex. The optional Lean run uses Lean 4.19.0 and Std.
No third-party Python package is needed by the mathematical checks.

SOURCE SNAPSHOT
  VladimirReshetnikov/ProveIt
  41ead086f47172a707910a072eb1a722a17a85ca
  docs/drafts, six ZIP archives; bytes verified against Git blob hashes.
  No repository changes were published.

The report includes Further research questions and a two-chain
countermodel explaining exactly why the 12-node form needs coverage.

