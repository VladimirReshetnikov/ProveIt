import Std

/-!
# Successor and equality discriminator merged into one binary operation

Arbitrary-carrier bootstrap from the two displayed fixed axioms and the
two Q computation equations. All assumptions are explicit theorem parameters.
There are no axioms, admitted goals, or uses of classical choice.
-/

namespace MergedDiscriminator

universe u
variable {A : Type u}

theorem separation
    (z : A) (D : A → A → A)
    (off : ∀ x y, x = y ∨ D x y = z)
    (part : ∀ x, ∃ y, D x z ≠ D x (D y y)) :
    z ≠ D z z := by
  intro bad
  have row : ∀ y, D z y = z := by
    intro y
    rcases off z y with h | h
    · rw [← h]
      exact bad.symm
    · exact h
  obtain ⟨y, hy⟩ := part z
  exact hy ((row z).trans (row (D y y)).symm)

theorem successor_nonzero
    (z : A) (D Q : A → A → A)
    (off : ∀ x y, x = y ∨ D x y = z)
    (part : ∀ x, ∃ y, D x z ≠ D x (D y y))
    (qzero : ∀ a, Q z a = a)
    (qsucc : ∀ x a, Q (D x x) a = x) :
    ∀ x, D x x ≠ z := by
  intro x hx
  have h := congrArg (fun t => Q t z) hx
  dsimp only at h
  rw [qsucc, qzero] at h
  subst x
  exact separation z D off part hx.symm

theorem successor_injective
    (z : A) (D Q : A → A → A)
    (qsucc : ∀ x a, Q (D x x) a = x) :
    ∀ x y, D x x = D y y → x = y := by
  intro x y h
  have hq := congrArg (fun t => Q t z) h
  dsimp only at hq
  rw [qsucc, qsucc] at hq
  exact hq

theorem coverage
    (z : A) (D : A → A → A)
    (off : ∀ x y, x = y ∨ D x y = z)
    (part : ∀ x, ∃ y, D x z ≠ D x (D y y)) :
    ∀ x, x = z ∨ ∃ y, x = D y y := by
  intro x
  obtain ⟨y, hy⟩ := part x
  rcases off x z with hx | hx
  · exact Or.inl hx
  · rcases off x (D y y) with he | he
    · exact Or.inr ⟨y, he⟩
    · exact False.elim (hy (hx.trans he.symm))

theorem decidable_equality
    (z : A) (D Q : A → A → A)
    (off : ∀ x y, x = y ∨ D x y = z)
    (part : ∀ x, ∃ y, D x z ≠ D x (D y y))
    (qzero : ∀ a, Q z a = a)
    (qsucc : ∀ x a, Q (D x x) a = x) :
    ∀ (x y : A), x = y ∨ x ≠ y := by
  intro x y
  rcases off x y with h | h
  · exact Or.inl h
  · refine Or.inr ?_
    intro he
    subst y
    exact successor_nonzero z D Q off part qzero qsucc x h

def equalityBit (z : A) (D Z : A → A → A) (x y : A) : A :=
  Z (Z (D x y) (D z z)) (D z z)

theorem bit_diagonal
    (z : A) (D Z : A → A → A)
    (zzero : ∀ a, Z z a = a)
    (zsucc : ∀ x a, Z (D x x) a = z) :
    ∀ x, equalityBit z D Z x x = D z z := by
  intro x
  unfold equalityBit
  rw [zsucc, zzero]

theorem bit_off_diagonal
    (z : A) (D Z : A → A → A)
    (off : ∀ x y, x = y ∨ D x y = z)
    (zzero : ∀ a, Z z a = a)
    (zsucc : ∀ x a, Z (D x x) a = z) :
    ∀ x y, x = y ∨ equalityBit z D Z x y = z := by
  intro x y
  rcases off x y with h | h
  · exact Or.inl h
  · apply Or.inr
    unfold equalityBit
    rw [h, zzero, zsucc]

theorem reconstruction
    (z : A) (D Z : A → A → A)
    (off : ∀ x y, x = y ∨ D x y = z)
    (zzero : ∀ a, Z z a = a)
    (zsucc : ∀ x a, Z (D x x) a = z) :
    ∀ x y, Z (Z (equalityBit z D Z x y) (D z z)) (D x x) = D x y := by
  intro x y
  rcases off x y with h | h
  · subst y
    rw [bit_diagonal z D Z zzero zsucc x, zsucc, zzero]
  · unfold equalityBit
    rw [h, zzero, zsucc, zzero, zsucc]

#print axioms separation
#print axioms successor_nonzero
#print axioms successor_injective
#print axioms coverage
#print axioms decidable_equality
#print axioms bit_diagonal
#print axioms bit_off_diagonal
#print axioms reconstruction

end MergedDiscriminator
