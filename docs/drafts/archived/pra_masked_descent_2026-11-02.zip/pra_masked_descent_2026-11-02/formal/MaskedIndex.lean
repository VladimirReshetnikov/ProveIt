import Std

/-!
# Masked-index induction kernels

This file checks the local mathematical kernels, not a syntactic interpretation
of an entire first-order theory. All arithmetic assumptions occur as explicit
arguments to theorems. The forward theorems hold on an arbitrary carrier.
The generic reverse theorem takes only the displayed quantifier-free invariant
induction as a hypothesis. A separate computable Nat scan verifies the same
reverse witness without an assumed induction principle.

There are no `axiom`, `sorry`, or `admit` declarations.
-/

namespace MaskedIndex

universe u
variable {A : Type u}

theorem successor_nonzero
    (z : A) (s : A → A) (Q : A → A → A)
    (qz : ∀ a, Q z a = a)
    (qs : ∀ x a, Q (s x) a = x)
    (sep : z ≠ s z) : ∀ x, s x ≠ z := by
  intro x hx
  have h := congrArg (fun t => Q t z) hx
  dsimp only at h
  rw [qs, qz] at h
  subst x
  exact sep hx.symm

theorem successor_injective
    (s : A → A) (Q : A → A → A) (z : A)
    (qs : ∀ x a, Q (s x) a = x) :
    ∀ x y, s x = s y → x = y := by
  intro x y h
  have hq := congrArg (fun t => Q t z) h
  dsimp only at hq
  simpa only [qs] using hq

/-- Range at zero already implies the masked function has zero base. -/
theorem mask_base
    (z : A) (f : A → A)
    (range : ∀ x, f x = z ∨ f x = x) : f z = z := by
  rcases range z with h | h
  · exact h
  · exact h

/-- The 13-node witness recovers progress without zero-or-successor coverage. -/
theorem shifted_witness_elimination
    (z : A) (s : A → A) (Q : A → A → A) (f : A → A)
    (qz : ∀ a, Q z a = a)
    (qs : ∀ x a, Q (s x) a = x)
    (sep : z ≠ s z)
    (range : ∀ x, f x = z ∨ f x = x)
    (witness : ∀ n, ∃ b, f (Q (f (s b)) n) = z)
    (progress : ∀ x, f x = z → f (s x) = z) :
    ∀ n, f n = z := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  rcases range (s b) with hz | hs
  · rw [hz, qz] at hb
    exact hb
  · rw [hs, qs] at hb
    have hp := progress b hb
    exact False.elim (successor_nonzero z s Q qz qs sep b (hs.symm.trans hp))

/-- The 12-node witness suffices when coverage is supplied separately. -/
theorem unshifted_witness_elimination
    (z : A) (s : A → A) (Q : A → A → A) (f : A → A)
    (qz : ∀ a, Q z a = a)
    (qs : ∀ x a, Q (s x) a = x)
    (sep : z ≠ s z)
    (coverage : ∀ x, x = z ∨ ∃ y, x = s y)
    (range : ∀ x, f x = z ∨ f x = x)
    (witness : ∀ n, ∃ b, f (Q (f b) n) = z)
    (progress : ∀ x, f x = z → f (s x) = z) :
    ∀ n, f n = z := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  rcases range b with hz | hi
  · rw [hz, qz] at hb
    exact hb
  · rcases coverage b with hbzero | ⟨c, hbc⟩
    · rw [hi, hbzero, qz] at hb
      exact hb
    · subst b
      rw [hi, qs] at hb
      have hp := progress c hb
      exact False.elim (successor_nonzero z s Q qz qs sep c (hi.symm.trans hp))

/-- Merely dropping the successor restriction weakens the witness sentence. -/
theorem shifted_implies_unshifted
    (z : A) (s : A → A) (Q : A → A → A) (f : A → A)
    (witness : ∀ n, ∃ b, f (Q (f (s b)) n) = z) :
    ∀ n, ∃ b, f (Q (f b) n) = z := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  exact ⟨s b, hb⟩

/-- Pointwise masking needs coverage only for arbitrary, non-Boolean tails. -/
theorem mask_range_of_coverage
    (z : A) (s : A → A) (Z : A → A → A) (t : A → A)
    (zz : ∀ a, Z z a = a)
    (zs : ∀ x a, Z (s x) a = z)
    (coverage : ∀ x, x = z ∨ ∃ y, x = s y) :
    ∀ x, Z (t x) x = z ∨ Z (t x) x = x := by
  intro x
  rcases coverage (t x) with hz | ⟨c, hc⟩
  · right
    rw [hz, zz]
  · left
    rw [hc, zs]

/-- A Boolean tail supplies range and reflection before any induction. -/
theorem boolean_mask_facts
    (z : A) (s : A → A) (Z : A → A → A)
    (t : A → A) (P : A → Prop)
    (zz : ∀ a, Z z a = a)
    (zs : ∀ x a, Z (s x) a = z)
    (bits : ∀ x, t x = z ∨ t x = s z)
    (truth : ∀ x, P x ↔ t x = s z) :
    (∀ x, Z (t x) x = z ∨ Z (t x) x = x) ∧
    (∀ x, Z (t x) x = z → x = z ∨ P x) ∧
    (∀ x, P x → Z (t x) x = z) := by
  refine ⟨?_, ?_, ?_⟩
  · intro x
    rcases bits x with hz | hs
    · right
      rw [hz, zz]
    · left
      rw [hs, zs]
  · intro x hx
    rcases bits x with hz | hs
    · left
      simpa only [hz, zz] using hx
    · exact Or.inr ((truth x).mpr hs)
  · intro x hx
    rw [(truth x).mp hx, zs]

/-- The 13-node scheme yields the entire induction implication under hypotheses. -/
theorem shifted_mask_induction
    (z : A) (s : A → A) (Q Z : A → A → A)
    (t : A → A) (P : A → Prop)
    (qz : ∀ a, Q z a = a)
    (qs : ∀ x a, Q (s x) a = x)
    (sep : z ≠ s z)
    (zz : ∀ a, Z z a = a)
    (zs : ∀ x a, Z (s x) a = z)
    (bits : ∀ x, t x = z ∨ t x = s z)
    (truth : ∀ x, P x ↔ t x = s z)
    (witness : ∀ n, ∃ b, Z (t (Q (Z (t (s b)) (s b)) n))
      (Q (Z (t (s b)) (s b)) n) = z)
    (base : P z) (step : ∀ x, P x → P (s x)) :
    ∀ x, P x := by
  obtain ⟨range, reflect, erase⟩ := boolean_mask_facts z s Z t P zz zs bits truth
  have progress : ∀ x, Z (t x) x = z → Z (t (s x)) (s x) = z := by
    intro x hx
    apply erase
    apply step
    rcases reflect x hx with hz | hp
    · simpa only [hz] using base
    · exact hp
  have allzero := shifted_witness_elimination z s Q (fun x => Z (t x) x)
    qz qs sep range witness progress
  intro x
  rcases reflect x (allzero x) with hz | hp
  · simpa only [hz] using base
  · exact hp

/-- The corresponding 12-node schema yields induction over a covered carrier. -/
theorem unshifted_mask_induction
    (z : A) (s : A → A) (Q Z : A → A → A)
    (t : A → A) (P : A → Prop)
    (qz : ∀ a, Q z a = a)
    (qs : ∀ x a, Q (s x) a = x)
    (sep : z ≠ s z)
    (coverage : ∀ x, x = z ∨ ∃ y, x = s y)
    (zz : ∀ a, Z z a = a)
    (zs : ∀ x a, Z (s x) a = z)
    (bits : ∀ x, t x = z ∨ t x = s z)
    (truth : ∀ x, P x ↔ t x = s z)
    (witness : ∀ n, ∃ b, Z (t (Q (Z (t b) b) n))
      (Q (Z (t b) b) n) = z)
    (base : P z) (step : ∀ x, P x → P (s x)) :
    ∀ x, P x := by
  obtain ⟨range, reflect, erase⟩ := boolean_mask_facts z s Z t P zz zs bits truth
  have progress : ∀ x, Z (t x) x = z → Z (t (s x)) (s x) = z := by
    intro x hx
    apply erase
    apply step
    rcases reflect x hx with hz | hp
    · simpa only [hz] using base
    · exact hp
  have allzero := unshifted_witness_elimination z s Q (fun x => Z (t x) x)
    qz qs sep coverage range witness progress
  intro x
  rcases reflect x (allzero x) with hz | hp
  · simpa only [hz] using base
  · exact hp

def BoundaryInv (z : A) (s f c : A → A) (n : A) : Prop :=
  f (c n) = z ∧ (f n = z ∨ f (s (c n)) ≠ z)

/-- Reverse witness from exactly one displayed invariant induction instance. -/
theorem shifted_witness_converse
    (z : A) (s : A → A) (Q : A → A → A) (f c : A → A)
    (qz : ∀ a, Q z a = a)
    (qs : ∀ x a, Q (s x) a = x)
    (range : ∀ x, f x = z ∨ f x = x)
    (decideZero : ∀ x, f x = z ∨ f x ≠ z)
    (cz : c z = z)
    (ctrue : ∀ n, f n = z → c (s n) = n)
    (cfalse : ∀ n, f n ≠ z → c (s n) = c n)
    (induction :
      BoundaryInv z s f c z →
      (∀ n, BoundaryInv z s f c n → BoundaryInv z s f c (s n)) →
      ∀ n, BoundaryInv z s f c n) :
    ∀ n, ∃ b, f (Q (f (s b)) n) = z := by
  have fzero := mask_base z f range
  have inv0 : BoundaryInv z s f c z := by
    exact ⟨by simpa only [cz] using fzero, Or.inl fzero⟩
  have invstep : ∀ n, BoundaryInv z s f c n → BoundaryInv z s f c (s n) := by
    intro n hn
    rcases decideZero n with hz | hne
    · have hc := ctrue n hz
      refine ⟨?_, ?_⟩
      · simpa only [hc] using hz
      · rcases decideZero (s n) with hnext | hnext
        · exact Or.inl hnext
        · exact Or.inr (by simpa only [hc] using hnext)
    · have hc := cfalse n hne
      refine ⟨?_, ?_⟩
      · simpa only [hc] using hn.1
      · rcases hn.2 with hnzero | hexit
        · exact False.elim (hne hnzero)
        · exact Or.inr (by simpa only [hc] using hexit)
  have inv := induction inv0 invstep
  intro n
  refine ⟨c n, ?_⟩
  rcases range (s (c n)) with hz | hs
  · rw [hz, qz]
    rcases (inv n).2 with hn | hn
    · exact hn
    · exact False.elim (hn hz)
  · rw [hs, qs]
    exact (inv n).1

/-! The following executable scan is separate from the arbitrary-carrier proof. -/

def lastGood (P : Nat → Prop) [DecidablePred P] : Nat → Nat
  | 0 => 0
  | n + 1 => if P n then n else lastGood P n

theorem lastGood_invariant
    (P : Nat → Prop) [DecidablePred P] (base : P 0) :
    ∀ n, P (lastGood P n) ∧ (P n ∨ ¬ P (Nat.succ (lastGood P n))) := by
  intro n
  induction n with
  | zero => exact ⟨base, Or.inl base⟩
  | succ n ih =>
      by_cases hp : P n
      · rw [lastGood, if_pos hp]
        refine ⟨hp, ?_⟩
        by_cases hn : P (Nat.succ n)
        · exact Or.inl hn
        · exact Or.inr hn
      · rw [lastGood, if_neg hp]
        refine ⟨ih.1, ?_⟩
        rcases ih.2 with hi | hi
        · exact False.elim (hp hi)
        · exact Or.inr hi

def natQ : Nat → Nat → Nat
  | 0, a => a
  | n + 1, _ => n

theorem nat_shifted_witness
    (f : Nat → Nat) (range : ∀ x, f x = 0 ∨ f x = x) :
    ∀ n, ∃ b, f (natQ (f (Nat.succ b)) n) = 0 := by
  intro n
  have fzero := mask_base 0 f range
  let b := lastGood (fun k => f k = 0) n
  have inv := lastGood_invariant (fun k => f k = 0) fzero n
  refine ⟨b, ?_⟩
  rcases range (Nat.succ b) with hz | hs
  · rw [hz, natQ]
    rcases inv.2 with hn | hn
    · exact hn
    · exact False.elim (hn hz)
  · rw [hs, natQ]
    exact inv.1

theorem nat_unshifted_witness
    (f : Nat → Nat) (range : ∀ x, f x = 0 ∨ f x = x) :
    ∀ n, ∃ b, f (natQ (f b) n) = 0 :=
  shifted_implies_unshifted 0 Nat.succ natQ f (nat_shifted_witness f range)

#print axioms successor_nonzero
#print axioms shifted_witness_elimination
#print axioms unshifted_witness_elimination
#print axioms boolean_mask_facts
#print axioms shifted_mask_induction
#print axioms unshifted_mask_induction
#print axioms shifted_witness_converse
#print axioms lastGood_invariant
#print axioms nat_shifted_witness
#print axioms nat_unshifted_witness

end MaskedIndex
