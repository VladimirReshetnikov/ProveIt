#!/usr/bin/env python3
"""Reproduce mathematical checks and compile the complete report."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--lean", help="Absolute path to Lean 4.19.0 (optional)")
args = parser.parse_args()
verification = root / "verification"
verification.mkdir(exist_ok=True)
records = []

def run(command, log):
    result = subprocess.run(command, cwd=root, capture_output=True, text=True)
    (verification / log).write_text(result.stdout + result.stderr)
    records.append({"command": command, "exit_code": result.returncode, "log": log})
    if result.returncode:
        print(result.stdout[-6000:] + result.stderr[-6000:])
        raise SystemExit(result.returncode)

run([sys.executable, "checks/check_counts.py"], "counts_output.txt")
run([sys.executable, "checks/check_witnesses.py"], "witness_output.txt")
if args.lean:
    run([args.lean, "formal/MaskedIndex.lean"], "lean_recheck.txt")
    run([args.lean, "formal/MergedDiscriminator.lean"], "merged_lean_recheck.txt")
for index in range(3):
    run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        f"latex_pass_{index + 1}.txt")
log = (root / "report.log").read_text(errors="replace")
bad = [line for line in log.splitlines() if any(text in line for text in
       ("Overfull", "undefined", "There were undefined", "LaTeX Error", "same identifier"))]
record = {"status": "PASS" if not bad else "REVIEW",
          "commands": records, "layout_or_reference_warnings": bad,
          "pdf_sha256": hashlib.sha256((root / "report.pdf").read_bytes()).hexdigest()}
(verification / "build.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"status": record["status"], "warnings": bad,
                  "pdf": str(root / "report.pdf")}, indent=2))

