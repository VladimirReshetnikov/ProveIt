#!/usr/bin/env python3
"""Portable explicit-exception validation; no supplied programs are run."""
from pathlib import Path
import ast,json,subprocess,sys,hashlib
ROOT=Path(__file__).resolve().parent
COMMANDS=['artifacts/review/check_source_frontier.py','artifacts/review/check_frontiers.py','artifacts/review/check_compiler_envelope.py',
 'artifacts/review/check_restricted_boolean_masks.py',
 'artifacts/recursion/check_merged_discriminator.py','artifacts/recursion/check_boolean_compiler.py','artifacts/recursion/check_linear_contexts.py',
 'artifacts/induction/check_mask_boundaries.py','artifacts/relational/validate_relational.py']
def main():
 inventory=[]
 for f in sorted(ROOT.rglob('*.py')):
  if any(x in ('_build','__pycache__') for x in f.relative_to(ROOT).parts):continue
  n=sum(isinstance(x,ast.Assert) for x in ast.walk(ast.parse(f.read_text())))
  if n:raise RuntimeError('Removable assertion in '+str(f.relative_to(ROOT)))
  inventory.append({'path':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'assert_count':0})
 results=[]
 for rel in COMMANDS:
  f=ROOT/rel;outputs=[]
  for opt in ([],['-O']):
   q=subprocess.run([sys.executable,*opt,str(f)],cwd=f.parent,capture_output=True,text=True,check=True);outputs.append(q.stdout)
  if outputs[0]!=outputs[1]:raise RuntimeError('Normal/-O mismatch: '+rel)
  d=json.loads(outputs[0])
  if str(d.get('status','')).lower() not in ('pass','passed'):raise RuntimeError('Non-PASS: '+rel)
  results.append({'script':rel,'normal_optimized_byte_identical':True,'stdout_sha256':hashlib.sha256(outputs[0].encode()).hexdigest()})
  print('PASS '+rel,flush=True)
 out={'status':'PASS','script_inventory':inventory,'checks':results,'scope':'Finite authored checks only; not proof-assistant certification.'}
 (ROOT/'artifacts/replay_validation.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
