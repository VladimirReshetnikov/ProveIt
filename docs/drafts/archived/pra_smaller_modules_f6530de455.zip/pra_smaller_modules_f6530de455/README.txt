SMALLER PRA INDUCTION MODULES
============================
Requested commit f6530de455c06348fab66350f6469a826bcb974d.
Main at intake 4d5474f10e00412135d659dc7a1f74fc6457656a had the identical
six-file docs/drafts inventory. Sources were downloaded and safely extracted
read-only, with Git blob and supplied SHA256 checks; no source program ran.

Start with report.pdf. Editable sources are report.tex and its seven included
proof sections. AXIOMS.txt gives the complete recommended generator and the
separate D-language and binary-relation alternatives.

What is new here
- Unary-only general recursive updates plus one fixed counter projection;
  masks have a literal three-production Boolean grammar, not arbitrary tails.
- Smaller native-equality Boolean contexts and exact complete-module savings
  over all six current uniform source compilers at matched numerical inputs.
  Compound full-size savings persist even against a relaxed best-connective,
  tail-only, covered12 benchmark; active-size dominance is not claimed there.
- A 17-node merged-discriminator seed with a 14-node shifted witness and an
  explicitly charged positive compiler; it is a Pareto tradeoff, not dominance.
- Finite-parameter non-bi-interpretability for two specific weakened mask
  interfaces, not an absolute 12-node impossibility theorem.
- Finite graph seed 159 -> 155, unchanged recurring overhead 30; optionally
  157 -> 153 with overhead39 and the prior larger reverse definition.

What is inherited or deliberately qualified
The 13-node shifted witness and covered12 variants are already in the current
drafts. Tail-only mask descriptors are already in Counterexample Masks. The
one-parameter dyadic pairing is credited to the earlier Unary Updates proof.
The report fully includes the arithmetic bootstrap, compiler and round trips.
The graph supplement states its entire new finite seed, decoder and recurring
scheme, proves finite equivalence before arithmetic, and uses the exact prior
calibration/round-trip foundation bundled below. Both logics are treated in
matching pairs. Nothing claims an encoding-independent shortest PRA theory.

Offline reproduction (Python3 standard library, TeX Live/pdflatex)
  sh checks.sh              # all authored diagnostics, normal and -O
  sh build.sh               # checks, then three-pass PDF build, no shell escape
  sh build.sh --pdf-only    # PDF only
Build products go in _build/, which is not shipped. build.sh creates a local
TeX format/font-map cache when needed by this environment; it does not install
packages or need network access. All executed Python is audited to contain no
ast.Assert nodes, so optimization does not silently remove substantive checks.
The diagnostics are finite transcription/AST checks, not formal certification.

Optional rule interface
supplements/zero_equation_rule.tex proves a context-sensitive zero-equation
induction rule equivalent to QFI1. It is not part of the main PDF or a new
node-count record; its premise derivations and freshness conditions are explicit.

Source and provenance files
sources/: pinned commit/main metadata, six-archive manifests, every source
payload hash, duplicate audit, and verified earlier unary proof provenance.
audit/: independent mathematical reviews and all-page visual inspection notes.
artifacts/: authored checkers, exact ASTs, deterministic JSON and replay evidence.
references/graph_foundation/: exact static inherited graph proof texts, not built.
references/pra_literal_axioms_0e1088217e.zip: exact sealed round8 release,
SHA256 633d9f96a1f4e607b648b18f756ed35cfed43a59f77fcd29e0e196ec600fb92e.
This nested ZIP is an UNEXECUTED REFERENCE. None of its programs, TeX, or build
scripts is run by this package. It contains the complete older graph calibration
and both round trips, plus its own historical evidence. Historical validations
are not represented as new reruns. Relevant proof paths in its top-level folder
pra_literal_axioms_0e1088217e/ are graph49_proof.tex, two_tag_source_proof.tex,
combined_graph159_proof.tex, constant_column_bootstrap.tex and source_calibration.tex.
The final column proof supersedes the row orientation in the intermediate text.

The requested immutable repository view is
https://github.com/VladimirReshetnikov/ProveIt/tree/f6530de455c06348fab66350f6469a826bcb974d/docs/drafts
The source comparison includes all six current archives, not just their own
historical tables. The final manifest records all delivered file hashes; the
separate final seal records the ZIP and visually approved PDF hashes.
