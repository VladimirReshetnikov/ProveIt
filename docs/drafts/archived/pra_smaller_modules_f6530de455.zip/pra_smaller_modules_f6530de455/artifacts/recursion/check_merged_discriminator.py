#!/usr/bin/env python3
"""Authored positive-discriminator, grammar and exact-ledger diagnostics."""
import json

def V(x):return ('var',x)
def O():return ('zero',)
def F(f,*a):return ('fn',f,tuple(a))
def D(a,b):return F('D',a,b)
def Q(a,b):return F('Q',a,b)
def Z(a,b):return F('Z',a,b)
def Eq(a,b):return ('eq',a,b)
def Or(a,b):return ('or',a,b)
def Imp(a,b):return ('imp',a,b)
def All(x,p):return ('all',x,p)
def Ex(x,p):return ('ex',x,p)
BOT=('bot',)
ONE=D(O(),O())
x,y,n,a,b=map(V,('x','y','n','a','b'))

def size(t,full=False,descriptor=None):
 tag=t[0]
 if tag in ('var','zero','bot'):return 1
 if tag=='fn':
  extra=(1 if t[1] in ('Q','Z') else size(descriptor,True) if t[1]=='C' and descriptor is not None else 0) if full else 0
  return 1+extra+sum(size(v,full,descriptor) for v in t[2])
 if tag in ('eq','or','imp','and'):return 1+size(t[1],full,descriptor)+size(t[2],full,descriptor)
 if tag in ('all','ex'):return 1+size(t[2],full,descriptor)
 raise ValueError(t)
def ev(t,e):
 if t[0]=='zero':return 0
 if t[0]=='var':return e[t[1]]
 f=t[1];u,v=[ev(a,e) for a in t[2]]
 if f=='D':return u+1 if u==v else 0
 if f=='Q':return v if u==0 else u-1
 if f=='Z':return v if u==0 else 0
 raise ValueError(f)
def validterm(t):
 return t[0] in ('var','zero') or (t[0]=='fn' and len(t[2])==2 and t[1] in ('D','Q','Z') and all(validterm(v) for v in t[2]))
def positive(t):
 if t==O():return True
 if t[0]!='fn':return False
 if t[1]=='D':return all(validterm(v) for v in t[2])
 if t[1]=='Z':return t[2][0][0]=='fn' and t[2][0][1]=='D' and validterm(t[2][0]) and positive(t[2][1])
 return False

def new(op,u,v):
 return {'and':lambda:Z(D(u,O()),v),'or':lambda:D(Z(u,D(v,O())),O()),'imp':lambda:D(Z(v,u),O())}[op]()
def N(u):return Z(u,ONE)
def A(u,v):return Z(N(u),v)
def old(op,u,v):
 return {'and':lambda:A(u,v),'or':lambda:N(A(N(u),N(v))),'imp':lambda:N(A(u,N(v)))}[op]()
checks=[]
def ck(s,ok):
 if not ok:raise RuntimeError(s)
 checks.append(s)
for op in ('and','or','imp'):
 for u in range(6):
  for v in range(6):
   expected={'and':u>0 and v>0,'or':u>0 or v>0,'imp':not(u>0) or v>0}[op]
   ck(op+' positive truth '+str((u,v)),(ev(new(op,x,y),{'x':u,'y':v})>0)==expected)
 expected={'and':(3,4),'or':(5,6),'imp':(3,4)}[op]
 ck(op+' new active overhead',size(new(op,x,y))-2==expected[0])
 ck(op+' new full overhead',size(new(op,x,y),True)-2==expected[1])
 expectedold={'and':(5,7),'or':(17,22),'imp':(13,17)}[op]
 ck(op+' old active overhead',size(old(op,x,y))-2==expectedold[0])
 ck(op+' old full overhead',size(old(op,x,y),True)-2==expectedold[1])
atom=D(x,y); oldatom=Z(Z(atom,ONE),ONE)
ck('equality leaf active saving8',size(oldatom)-size(atom)==8)
ck('equality leaf full saving10',size(oldatom,True)-size(atom,True)==10)
off=All('x',All('y',Or(Eq(x,y),Eq(D(x,y),O()))))
nt=Ex('x',Imp(Eq(x,O()),BOT))
part=All('x',Ex('y',Imp(Eq(D(x,O()),D(x,D(y,y))),BOT)))
ck('Off seed11',size(off)==11)
ck('Nontriviality seed6',size(nt)==6)
ck('new seed17',size(off)+size(nt)==17)
ck('DPart13',size(part)==13)
ck('old seed24',size(off)+size(part)==24)
C=lambda x,a:F('C',x,a)
w14=All('a',All('n',Ex('b',Eq(C(Q(C(D(b,b),a),n),a),O()))))
w12=All('a',All('n',Ex('b',Eq(C(Q(C(b,a),n),a),O()))))
ck('witness14',size(w14)==14)
ck('witness12',size(w12)==12)
qbase=All('a',Eq(Q(O(),a),a))
qstep=All('a',All('n',Eq(Q(D(n,n),a),n)))
ck('D fixedQ active15',size(qbase)+size(qstep)==15)
ck('D fixedQ full17',size(qbase,True)+size(qstep,True)==17)

def payload(p,which):
 if p[0]=='eq':
  atom=D(p[1],p[2]);return Z(Z(atom,ONE),ONE) if which=='old' else atom
 if p[0]=='bot':return O()
 return (old if which=='old' else new)(p[0],payload(p[1],which),payload(p[2],which))
def prof(p):
 if p[0]=='eq':return (1,0,0,0)
 if p[0]=='bot':return (0,0,0,0)
 out=[u+v for u,v in zip(prof(p[1]),prof(p[2]))]
 out[{'and':1,'or':2,'imp':3}[p[0]]]+=1;return tuple(out)
forms=[Eq(x,a),BOT]
for depth in range(3):
 previous=forms[:]
 forms += [(op,previous[i],previous[-1-i]) for op in ('and','or','imp') for i in range(min(6,len(previous)))]
for j,p in enumerate(forms):
 pn=payload(p,'new');po=payload(p,'old');e,c,o,i=prof(p)
 ck('positive grammar '+str(j),positive(pn))
 da=8*e+2*c+12*o+10*i;df=10*e+3*c+16*o+13*i
 ck('payload active profile '+str(j),size(po)-size(pn)==da)
 ck('payload full profile '+str(j),size(po,True)-size(pn,True)==df)
 newdef=All('x',All('a',Eq(C(x,a),Z(pn,x))))
 olddef=All('x',All('a',Eq(C(x,a),Z(po,x))))
 newfull=size(newdef,True,pn)+size(w12,True,pn)
 oldfull=size(olddef,True,Z(po,x))+size(w12,True,Z(po,x))
 ck('actual full modules '+str(j),oldfull-newfull==9+4*df)
 ck('actual active modules '+str(j),size(olddef)+size(w12)-size(newdef)-size(w12)==da)
 ck('D14 module ledger '+str(j),size(newdef)+size(w14)==22+size(pn) and size(newdef,True,pn)+size(w14,True,pn)==24+4*size(pn,True))
ck('arbitrary unary Z tail rejected',not positive(Z(O(),O())))
ck('positive zero accepted',positive(O()))
ck('arbitrary numeric inputs in D accepted',positive(D(Q(x,a),Z(y,a))))
print(json.dumps({'status':'passed','check_count':len(checks),'checks':checks,
 'scope':'Finite authored truth/grammar/AST/profile diagnostics only; written proofs supply arbitrary-model claims.'},indent=2))
