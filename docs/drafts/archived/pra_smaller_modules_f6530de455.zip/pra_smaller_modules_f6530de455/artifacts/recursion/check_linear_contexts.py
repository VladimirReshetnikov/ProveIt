#!/usr/bin/env python3
"""Authored bounded exhaustive enumeration of read-once two-hole Q/Z/chi/S/0 contexts.
Costs charge a literal generated Q/Z descriptor at each call in full mode.
No source programs imported; no arithmetic-theory minimality is claimed.
"""
import json

ASSIGN=((0,0),(0,1),(1,0),(1,1))
TARGETS={'and':(0,0,0,1),'or':(0,1,1,1),'imp':(1,1,0,1)}

def run(full,cap):
 levels=[{} for _ in range(cap+1)]
 # key (holemask, four outputs); expression retained only as a witness.
 levels[1][(0,(0,0,0,0))]='0'
 levels[1][(1,tuple(x for x,y in ASSIGN))]='a'
 levels[1][(2,tuple(y for x,y in ASSIGN))]='b'
 first={}
 for cost in range(1,cap+1):
  if cost>=2:
   for (mask,values),expr in levels[cost-1].items():
    levels[cost].setdefault((mask,tuple(v+1 for v in values)),'S('+expr+')')
  for op in ('Q','Z','chi'):
   weight=1+int(full and op in ('Q','Z'))
   for c1 in range(1,cost-weight):
    c2=cost-weight-c1
    for (m1,v1),e1 in levels[c1].items():
     for (m2,v2),e2 in levels[c2].items():
      if m1&m2: continue  # each hole occurs at most once
      if op=='Q': out=tuple(y if x==0 else x-1 for x,y in zip(v1,v2))
      elif op=='Z': out=tuple(y if x==0 else 0 for x,y in zip(v1,v2))
      else: out=tuple(int(x==y) for x,y in zip(v1,v2))
      levels[cost].setdefault((m1|m2,out),op+'('+e1+','+e2+')')
  for name,target in TARGETS.items():
   if name not in first and (3,target) in levels[cost]:
    first[name]={'cost':cost,'context':levels[cost][(3,target)]}
 return {'mode':'full' if full else 'active','cap':cap,'first':first,
         'semantic_states_by_exact_cost':[len(x) for x in levels[1:]]}
results=[run(False,7),run(True,8)]
expected=[{'and':5,'or':7,'imp':5},{'and':6,'or':8,'imp':6}]
for r,e in zip(results,expected):
 for op,cost in e.items():
  if r['first'].get(op,{}).get('cost')!=cost:raise RuntimeError((r,op,cost))
print(json.dumps({'status':'passed','results':results,
 'scope':'Exhaustive finite grammar enumeration to the displayed costs only. Establishes no optimum over different primitives, shared/DAG terms, repeated payload occurrences, changed polarity, or arbitrary recursion symbols.'},indent=2))
