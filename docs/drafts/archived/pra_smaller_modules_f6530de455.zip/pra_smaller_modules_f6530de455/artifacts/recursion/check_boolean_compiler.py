#!/usr/bin/env python3
"""Authored Boolean/AST diagnostics. No source scripts imported or executed."""
import json

def V(x): return ('var',x)
def Z(): return ('zero',)
def F(f,*xs): return ('fn',f,tuple(xs))
def S(x): return F('S',x)
def Q(x,y): return F('Q',x,y)
def ZZ(x,y): return F('Z',x,y)
def X(x,y): return F('chi',x,y)
ONE=S(Z())
a,b=V('a'),V('b')
new={'and':Q(X(a,Z()),b),'or':X(Q(a,X(b,Z())),Z()),'imp':X(Q(b,a),Z())}
def I(r,u,v): return Q(ZZ(r,S(u)),v)
old={'and':I(a,Z(),b),'or':I(a,b,ONE),'imp':I(a,ONE,b)}

def size(t,full=False):
 if t[0] in ('var','zero'): return 1
 return 1+(int(full and t[1] in ('Q','Z')))+sum(size(x,full) for x in t[2])
def val(t,env):
 if t[0]=='var': return env[t[1]]
 if t[0]=='zero': return 0
 f=t[1]; xs=[val(x,env) for x in t[2]]
 if f=='S': return xs[0]+1
 if f=='Q': return xs[1] if xs[0]==0 else xs[0]-1
 if f=='Z': return xs[1] if xs[0]==0 else 0
 if f=='chi': return int(xs[0]==xs[1])
 raise ValueError(f)
def occurrences(t,var):
 if t[0]=='var': return int(t[1]==var)
 if t[0]=='zero': return 0
 return sum(occurrences(x,var) for x in t[2])
checks=[]
def check(name,ok):
 if not ok: raise RuntimeError(name)
 checks.append(name)
for op in new:
 for x in (0,1):
  for y in (0,1):
   target={'and':x and y,'or':x or y,'imp':(not x) or y}[op]
   check(op+' truth '+str((x,y)),val(new[op],{'a':x,'b':y})==int(target))
   check(op+' agrees with source '+str((x,y)),val(new[op],{'a':x,'b':y})==val(old[op],{'a':x,'b':y}))
 check(op+' first child exactly once',occurrences(new[op],'a')==1)
 check(op+' second child exactly once',occurrences(new[op],'b')==1)
 expected={'and':(3,4),'or':(5,6),'imp':(3,4)}[op]
 check(op+' exact active overhead',size(new[op])-2==expected[0])
 check(op+' exact full overhead',size(new[op],True)-2==expected[1])
 old_expected={'and':(4,6),'or':(5,7),'imp':(5,7)}[op]
 check(op+' source active overhead',size(old[op])-2==old_expected[0])
 check(op+' source full overhead',size(old[op],True)-2==old_expected[1])

# Formula syntax has equality leaves with arbitrary finite term costs.
def payload(f,which):
 tag=f[0]
 if tag=='eq': return X(f[1],f[2])
 if tag=='bot': return Z()
 l=payload(f[1],which); r=payload(f[2],which)
 template=(new if which=='new' else old)[tag]
 def subst(t):
  if t==a:return l
  if t==b:return r
  if t[0] in ('var','zero'):return t
  return F(t[1],*(subst(x) for x in t[2]))
 return subst(template)
def profile(f):
 if f[0] in ('eq','bot'):return {'and':0,'or':0,'imp':0}
 p=profile(f[1]);q=profile(f[2]);p={k:p[k]+q[k] for k in p};p[f[0]]+=1;return p
leaf=('eq',S(V('x')),Q(V('x'),V('a')))
forms=[leaf,('bot',)]
for depth in range(3):
 prev=forms[:]
 forms += [(op,prev[i],prev[-1-i]) for op in ('and','or','imp') for i in range(min(8,len(prev)))]
for i,f in enumerate(forms):
 p=profile(f); oldt=payload(f,'old'); newt=payload(f,'new')
 da=p['and']+2*p['imp']; df=2*p['and']+3*p['imp']+p['or']
 check('profile active '+str(i),size(oldt)-size(newt)==da)
 check('profile full '+str(i),size(oldt,True)-size(newt,True)==df)
 check('module active '+str(i),(21+size(oldt))-(21+size(newt))==da)
 check('module full '+str(i),(23+4*size(oldt,True))-(23+4*size(newt,True))==4*df)
print(json.dumps({'status':'passed','check_count':len(checks),'checks':checks,
 'overheads':{op:{'new_active':size(new[op])-2,'new_full':size(new[op],True)-2,
 'source_active':size(old[op])-2,'source_full':size(old[op],True)-2} for op in new},
 'scope':'Finite authored truth tables, linear-hole counts, AST sizes, and profile identities; not a global optimality theorem or proof-assistant certification.'},indent=2))
