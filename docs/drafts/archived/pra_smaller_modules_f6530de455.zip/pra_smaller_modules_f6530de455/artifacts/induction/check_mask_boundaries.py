#!/usr/bin/env python3
"""Authored boundary diagnostics; no supplied archive code is imported.
Explicit exception checks remain active with -O. Finite samples are not
finite arithmetic models and do not prove the infinite-model theorems.
"""
import json
from functools import lru_cache
from itertools import product


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def N(op, *args):
    return op, tuple(args)


zero,x,a,n,b,v,w=[N(s) for s in ('0','x','a','n','b','v','w')]
S=lambda q:N('S',q)
Chi=lambda p,q:N('chi',p,q)
R=lambda h,p,q:N('R:'+h,p,q)
C=lambda h,p,q:N('C:'+h,p,q)
Eq=lambda p,q:N('=',p,q)
All=lambda name,q:N('all:'+name,q)
Ex=lambda name,q:N('exists:'+name,q)
updates={'Q':w,'Z':zero,'id':v,'inc':S(v),'eq':Chi(v,w),
         'eqzero':Chi(v,zero),'select':R('Q',v,w),'zeroselect':R('Z',v,w)}
Q=lambda p,q:R('Q',p,q)
Z=lambda p,q:R('Z',p,q)
Ite=lambda r,u,z:Q(Z(r,S(u)),z)
Pbit=Ite(Chi(x,zero),Chi(x,S(Q(x,zero))),S(zero))
Pbit_b3=Chi(Q(Chi(x,zero),Chi(Chi(x,S(Q(x,zero))),zero)),zero)
masks={'eq':Chi(x,a),'nested':Q(C('eq',x,a),a),'cov':Pbit,'cov_b3':Pbit_b3}


def active(t):
    return 1+sum(map(active,t[1]))


def full(t):
    op,args=t
    stored=full(updates[op[2:]]) if op.startswith('R:') else (
        full(masks[op[2:]]) if op.startswith('C:') else 0)
    return 1+stored+sum(map(full,args))


def definition(name):
    return All('x',All('a',Eq(C(name,x,a),Z(masks[name],x))))


def shifted(name):
    return All('a',All('n',Ex('b',Eq(C(name,Q(C(name,S(b),a),n),a),zero))))


def unshifted(name):
    return All('a',All('n',Ex('b',Eq(C(name,Q(C(name,b,a),n),a),zero))))


def diagonal(name,endpoint=a):
    return All('a',Ex('b',Eq(C(name,Q(C(name,S(b),a),endpoint),a),zero)))


counts=[]
for name,t in masks.items():
    m,T=active(t),full(t)
    d,s,u,g=definition(name),shifted(name),unshifted(name),diagonal(name)
    need((active(d),full(d))==(8+m,9+2*T),'definition count')
    need((active(s),full(s))==(13,14+2*T),'shifted count')
    need((active(u),full(u))==(12,13+2*T),'unshifted count')
    need((active(g),full(g))==(12,13+2*T),'diagonal count')
    for endpoint in (a,S(a),Q(a,zero),C('eq',a,a)):
        need(active(diagonal(name,endpoint))==11+active(endpoint),'endpoint active count')
        need(full(diagonal(name,endpoint))==12+2*T+full(endpoint),'endpoint full count')
    counts.append({'payload':name,'payload_active':m,'payload_full':T,
                   'definition':[active(d),full(d)],'shifted':[active(s),full(s)],
                   'unshifted':[active(u),full(u)],'diagonal':[active(g),full(g)]})

# Infinite extra-root model evaluated on finite sets of inputs. Values are
# (chain label, finite height); label0 is the distinguished standard chain.
z0=(0,0);one=(0,1)
succ=lambda q:(q[0],q[1]+1)
chi=lambda q,r:one if q==r else z0
perm=lambda q:({0:0,1:2,2:1,3:3}[q[0]],q[1])


@lru_cache(None)
def rec(h,counter,seed):
    tag,k=counter
    state=seed if tag==0 else z0
    for height in range(k):
        state=evaluate(updates[h],{'v':state,'w':(tag,height)})
    return state


def evaluate(t,env):
    op,args=t
    if op=='0':return z0
    if not args:return env[op]
    vals=[evaluate(q,env) for q in args]
    if op=='S':return succ(vals[0])
    if op=='chi':return chi(*vals)
    if op.startswith('R:'):return rec(op[2:],*vals)
    if op.startswith('C:'):
        xx,aa=vals
        tail=evaluate(masks[op[2:]],{'x':xx,'a':aa})
        return rec('Z',tail,xx)
    raise RuntimeError('unexpected numerical AST '+op)


points=[(tag,k) for tag in range(4) for k in range(4)]
rec_checks=0
for h,counter,seed in product(updates,points,points):
    need(rec(h,z0,seed)==seed,'recursion zero equation')
    need(rec(h,succ(counter),seed)==evaluate(updates[h],{'v':rec(h,counter,seed),'w':counter}),
         'recursion successor equation')
    need(rec(h,perm(counter),perm(seed))==perm(rec(h,counter,seed)),'recursor equivariance')
    rec_checks+=1
for q,r in product(points,repeat=2):
    need(chi(q,q)==one and (q==r or chi(q,r)==z0),'native equality bit')

tails=[zero,S(zero),x,a,Chi(x,a),Q(x,a),R('id',x,a),R('eq',x,a),
       Z(x,a),C('eq',x,a),C('nested',x,a),Pbit]
mask_checks=0
for tail,parameter,target in product(tails,points,points):
    def f(q):
        return rec('Z',evaluate(tail,{'x':q,'a':parameter}),q)
    need(f(z0)==z0 and f(target) in (z0,target),'all raw mask range')
    if f(target)==z0:
        witness=z0
    else:
        tag,k=target
        witness=next((tag,j) for j in range(k+1) if f((tag,j))!=z0)
    need(f(rec('Q',f(witness),target))==z0,'unshifted witness construction')
    other=evaluate(tail,{'x':perm(target),'a':perm(parameter)})
    need(other==perm(evaluate(tail,{'x':target,'a':parameter})),'tail equivariance')
    mask_checks+=1

# Exhaust all pointwise masks on two finite root-to-height3 segments.
# This tests the local witness lemma, NOT closure of a finite structure.
small=[(tag,k) for tag in range(2) for k in range(4)]
nonzero=[q for q in small if q!=z0]
exhaustive_cases=0
for flags in product((False,True),repeat=len(nonzero)):
    table={z0:z0};table.update({q:q if bit else z0 for q,bit in zip(nonzero,flags)})
    for target in small:
        if table[target]==z0:witness=z0
        else:
            tag,k=target
            witness=next((tag,j) for j in range(k+1) if table[(tag,j)]!=z0)
        need(table[rec('Q',table[witness],target)]==z0,'exhaustive pointwise witness')
        exhaustive_cases+=1

# The shifted law and the partition genuinely reject the extra-root model.
shifted_failures=0
for root in ((1,0),(2,0),(3,0)):
    def covmask(q):return rec('Z',evaluate(Pbit,{'x':q,'a':z0}),q)
    need(covmask(root)==root,'coverage payload at extra root')
    for candidate in points:
        need(covmask(rec('Q',covmask(succ(candidate)),root))==root,'shifted failure')
        need(chi(root,z0)==chi(root,succ(candidate))==z0,'partition failure')
        shifted_failures+=1

# Exact new B3 grammar, and Q-mask / Z-mask agreement on the primary reduct.
def is_b3(t):
    if t==zero:return True
    if t[0]=='chi' and len(t[1])==2:return True
    return (t[0]=='R:Q' and len(t[1])==2 and t[1][0][0]=='chi'
            and len(t[1][0][1])==2 and is_b3(t[1][1]))
B3_examples=[zero,Chi(x,a),Pbit_b3,Q(Chi(x,zero),Chi(x,a)),
             Q(Chi(Q(x,a),S(zero)),zero),Chi(C('eq',x,a),zero)]
need(not is_b3(Q(zero,zero)) and not is_b3(S(zero)),'strict B3 grammar')
primary_checks=0
for tail,parameter,target in product(B3_examples,points,points):
    need(is_b3(tail),'primary sample outside B3')
    value=evaluate(tail,{'x':target,'a':parameter})
    need(value in (z0,one),'primary B3 range')
    need(rec('Q',value,target)==rec('Z',value,target),'Q/Z Boolean mask agreement')
    def fq(q):return rec('Q',evaluate(tail,{'x':q,'a':parameter}),q)
    if fq(target)==z0:witness=z0
    else:
        tag,k=target
        witness=next((tag,j) for j in range(k+1) if fq((tag,j))!=z0)
    need(fq(rec('Q',fq(witness),target))==z0,'primary unshifted Q-mask witness')
    primary_checks+=1
for root in ((1,0),(2,0),(3,0)):
    def fqcov(q):return rec('Q',evaluate(Pbit_b3,{'x':q,'a':z0}),q)
    for candidate in points:
        need(fqcov(rec('Q',fqcov(succ(candidate)),root))==root,'primary shifted Q-mask failure')

# Symbolic nonstandard-chain diagnostic for canonical tagged-copy identity J.
# It does not supply a finite model of full M; that construction is in TeX.
def st(k):return ('std',k)
def ns(chain,k,tag):return ('ns',chain,k,tag)
def S2(q):return st(q[1]+1) if q[0]=='std' else ns(q[1],q[2]+1,q[3])
def Q2(q,seed):
    if q==st(0):return seed
    if q[0]=='std':return st(q[1]-1)
    return ns(q[1],q[2]-1,q[3])
def J2(counter,seed):
    if counter[0]=='std' or seed[0]=='std':return seed
    return ns(seed[1],seed[2],counter[3])
def mask2(q,seed):return st(0) if J2(q,seed)==seed else q
seed=ns('r',0,1);target=ns('m',0,2)
candidates=[st(k) for k in range(4)]+[ns(chain,k,tag) for chain in ('m','r') for k in range(-3,4) for tag in range(3)]
tag_checks=0
for counter in candidates:
    need(J2(S2(counter),seed)==J2(counter,seed),'tagged identity successor equation')
    need(mask2(Q2(mask2(S2(counter),seed),target),seed)!=st(0),'missing full shifted witness')
    tag_checks+=1
for endpoint in (seed,S2(seed),Q2(seed,st(0)),J2(S2(seed),seed),st(0),st(1)):
    need(mask2(Q2(mask2(S2(st(0)),seed),endpoint),seed)==st(0),'sample diagonal endpoint')
need(J2(target,seed)!=seed and J2(seed,seed)==seed,'cross-tag vs diagonal identity')
same_coordinate_a=ns('r',0,1);same_coordinate_b=ns('r',0,2)
need(same_coordinate_a!=same_coordinate_b and same_coordinate_a[1:3]==same_coordinate_b[1:3],
     'native equality cannot be globally projection preserving')

report={
 'status':'PASS',
 'counts':counts,
 'general_diagonal_profile':{'active':'11+active(endpoint)','full':'12+2*full(payload)+full(endpoint)'},
 'root_model_recursion_cases':rec_checks,
 'root_model_term_mask_witness_cases':mask_checks,
 'primary_B3_Qmask_agreement_and_witness_cases':primary_checks,
 'exhaustive_pointwise_mask_target_cases':exhaustive_cases,
 'shifted_and_partition_failures_checked':shifted_failures,
 'symbolic_tag_identity_and_full_witness_failures':tag_checks,
 'scope':[
  'All checks are explicit exceptions and remain active under python -O.',
  'No supplied/downloaded source program is imported or executed.',
  'Finite point samples are NOT finite first-order arithmetic models.',
  'The full infinite-family model and finite-parameter non-biinterpretability arguments are written proofs in the two companion TeX sections.',
  'The explicit primary-language corollaries retain fixed Q, unary iterators and B3 Q-masks; the diagnostics check Boolean range and Q(B,x)=Z(B,x).',
  'Full counts charge every frozen payload occurrence and Q/Z descriptor recursively; the mask descriptor is its tail, as in the counterexample/index-filter baseline.',
  'Unshifted12 without coverage and diagonal12 even with coverage are distinct local deletions, not a global lower bound on all twelve-node presentations.'
 ]}
print(json.dumps(report,indent=2,sort_keys=True))
