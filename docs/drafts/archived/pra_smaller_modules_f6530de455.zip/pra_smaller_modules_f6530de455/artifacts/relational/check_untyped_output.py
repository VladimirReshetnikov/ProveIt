#!/usr/bin/env python3
"""Finite seed-guard recovery checks; not finite models of PRA.
Fresh authored code only; all checks remain active with -O.
"""
import itertools,json,pathlib
from untyped_output_seed import *
def need(ok,msg='check failed'):
 if not ok:raise RuntimeError(msg)
def structure(V,Ee,m):
 oo={x for x in V if (x,m) in Ee}
 return not any((m,x) in Ee for x in V) and all(x==m or (x in oo and not any((x,y) in Ee for y in oo)) or any(all((b,p) not in Ee or (p,c) not in Ee or p==x for p in V) for b in oo for c in oo) for x in V)
def data(V,Ee,m):
 oo={x for x in V if (x,m) in Ee};nxt={x:{y for y in V if (x,y) in Ee} for x in V};prev={y:{x for x in V if (x,y) in Ee} for y in V}
 out={}
 for t,x,y in itertools.product(oo,repeat=3):
  qs=set().union(*(nxt[p]&nxt[t] for p in nxt[x]&prev[y])) if nxt[x]&prev[y] else set()
  out[t,x,y]=set().union(*(nxt[q] for q in qs)) if qs else set()
 return oo,out

def allowed(V,oo,out,z,a,t,x,y,weak):
 selected=t in (z,a);outputs=out[t,x,y];typed=outputs&oo
 return {u for u in (V if weak else oo) if (not(t==a and y==z) or u==z) and (not selected or u in outputs) and all(selected and w==u for w in typed)}
def H(V,oo,out,z,a,weak):return z in oo and a in oo and all(allowed(V,oo,out,z,a,t,x,y,weak) for t,x,y in itertools.product(oo,repeat=3))
def ev(t,V,Ee,env):
 op=t[0]
 if op=='var':return env[t[1]]
 if op=='false':return False
 if op=='E':return (ev(t[1],V,Ee,env),ev(t[2],V,Ee,env)) in Ee
 if op=='=':return ev(t[1],V,Ee,env)==ev(t[2],V,Ee,env)
 if op=='and':return ev(t[1],V,Ee,env) and ev(t[2],V,Ee,env)
 if op=='or':return ev(t[1],V,Ee,env) or ev(t[2],V,Ee,env)
 if op=='imp':return not ev(t[1],V,Ee,env) or ev(t[2],V,Ee,env)
 if op in ('forall','exists'):return (all if op=='forall' else any)(ev(t[2],V,Ee,{**env,t[1]:x}) for x in V)
 raise ValueError(op)
def canonical(n,rel):
 m=('m',);oo={i:('o',i) for i in range(n)};pp={(x,y):('p',x,y) for x in range(n) for y in range(n)}
 V={m}|set(oo.values())|set(pp.values());Ee={(oo[x],m) for x in range(n)}|{(oo[x],pp[x,y]) for x in range(n) for y in range(n)}|{(pp[x,y],oo[y]) for x in range(n) for y in range(n)}|{(pp[x,y],pp[t,w]) for t,x,y,w in rel};return V,Ee,m

def main():
 graphs=accepted=degenerate=ast=0
 for n in range(1,5):
  V=set(range(n));edges=list(itertools.product(V,repeat=2))
  for bits in range(1<<len(edges)):
   Ee={e for i,e in enumerate(edges) if bits>>i&1}
   for m in V:
    graphs+=1
    if not structure(V,Ee,m):continue
    oo,out=data(V,Ee,m)
    for z,a in itertools.product(oo,repeat=2):
     weak=H(V,oo,out,z,a,True);strong=H(V,oo,out,z,a,False)
     need(weak==strong,'finite seed equivalence counterexample')
     if weak:
      accepted+=1;degenerate+=int((z,z) in Ee)
      env={'m':m,'z':z,'a':a}
      need(ev(translate(H48(),True),V,Ee,env) and ev(translate(H48()),V,Ee,env),'exact AST mismatch');ast+=1
      for t,x,y in itertools.product(oo,repeat=3):
       if t in (z,a):need(allowed(V,oo,out,z,a,t,x,y,True)<=oo,'selected output not typed')
 tables=mutations=0;inputs=list(itertools.product(range(2),repeat=2))
 for plus in itertools.product(range(2),repeat=4):
  for last in itertools.product(range(2),repeat=2):
   times=(0,last[0],0,last[1]);rel={(0,x,y,w) for (x,y),w in zip(inputs,plus)}|{(1,x,y,w) for (x,y),w in zip(inputs,times)}
   V,Ee,m=canonical(2,rel);z,a=('o',0),('o',1);oo,out=data(V,Ee,m)
   need(structure(V,Ee,m) and H(V,oo,out,z,a,True) and H(V,oo,out,z,a,False));tables+=1
   for edge in itertools.product(V,repeat=2):
    EE=Ee^{edge};mutations+=1
    if structure(V,EE,m):
     oo,out=data(V,EE,m)
     need(H(V,oo,out,z,a,True)==H(V,oo,out,z,a,False),'mutation equivalence failed')
 # Outside selected tags, arbitrary untyped output witnesses really occur;
 # they are repaired to the existing object z, not claimed already typed.
 rel={(t,x,y,0) for t in (0,1) for x,y in itertools.product(range(3),repeat=2)}
 V,Ee,m=canonical(3,rel);z,a=('o',0),('o',1);oo,out=data(V,Ee,m)
 need(structure(V,Ee,m) and H(V,oo,out,z,a,True) and H(V,oo,out,z,a,False))
 for x,y in itertools.product(oo,repeat=2):
  loose=allowed(V,oo,out,z,a,('o',2),x,y,True)
  need(m in loose and ('p',0,0) in loose and z in loose,'unselected witness repair control')
 out={'status':'PASS','graph_marker_cases_through_four_vertices':graphs,'satisfying_finite_seed_parameter_cases':accepted,'degenerate_object_loop_cases':degenerate,'exact_seed_AST_comparisons':ast,'arbitrary_operation_table_models':tables,'single_edge_mutations':mutations,'unselected_tag_untyped_output_repair_control':True,'all_checks_active_under_python_O':True,'scope':'Finite diagnostics of the before-arithmetic seed equivalence; not full PRA models or a formal proof certificate.'}
 pathlib.Path(__file__).with_name('untyped_output_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
