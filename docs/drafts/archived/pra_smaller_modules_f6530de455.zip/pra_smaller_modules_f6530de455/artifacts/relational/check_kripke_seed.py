#!/usr/bin/env python3
"""Fresh finite constant-domain Kripke diagnostics, not a proof certificate."""
import functools,itertools,json,pathlib,random
from untyped_output_seed import *
from check_untyped_output import canonical,data

def need(ok,message):
 if not ok:raise RuntimeError(message)

@functools.lru_cache(None)
def free(t):
 op=t[0]
 if op=='var':return frozenset([t[1]])
 if op=='false':return frozenset()
 if op in ('forall','exists'):return free(t[2])-{t[1]}
 return frozenset().union(*(free(x) for x in t[1:]))

class Kripke:
 def __init__(self,domain,futures,relations):
  self.V=tuple(domain);self.future=futures;self.E=relations
  for world in futures:
   for future in futures[world]:need(relations[world]<=relations[future],'Nonpersistent edge valuation')
  self.cache={}
 def at(self,t,world,env):
  key=(t,world,tuple(sorted((v,env[v]) for v in free(t))))
  if key in self.cache:return self.cache[key]
  op=t[0]
  if op=='var':value=env[t[1]]
  elif op=='false':value=False
  elif op=='E':value=(self.at(t[1],world,env),self.at(t[2],world,env)) in self.E[world]
  elif op=='=':value=self.at(t[1],world,env)==self.at(t[2],world,env)
  elif op=='and':value=self.at(t[1],world,env) and self.at(t[2],world,env)
  elif op=='or':value=self.at(t[1],world,env) or self.at(t[2],world,env)
  elif op=='imp':value=all(not self.at(t[1],v,env) or self.at(t[2],v,env) for v in self.future[world])
  elif op=='forall':value=all(self.at(t[2],v,{**env,t[1]:x}) for v in self.future[world] for x in self.V)
  elif op=='exists':value=any(self.at(t[2],world,{**env,t[1]:x}) for x in self.V)
  else:raise ValueError(op)
  self.cache[key]=value;return value

def main():
 typed=translate(H48());weak=translate(H48(),True)
 seed=AND(O('z'),O('a'),FA('x',structure_body('x')),weak)
 frames=[({0:(0,1),1:(1,)},[(),(1,),(0,1)]),({0:(0,1,2),1:(1,),2:(2,)},[(),(1,),(2,),(1,2),(0,1,2)])]
 cases=accepted=valuations=0;rng=random.Random(15530)
 for future,upsets in frames:
  for n in (1,2,3):
   V=tuple(range(n));edges=tuple(itertools.product(V,repeat=2))
   choices=itertools.product(range(len(upsets)),repeat=len(edges)) if n<=2 else (tuple(rng.randrange(len(upsets)) for e in edges) for _ in range(60))
   for choice in choices:
    vals={w:{edge for edge,which in zip(edges,choice) if w in upsets[which]} for w in future};K=Kripke(V,future,vals);valuations+=1
    for m,z,a in itertools.product(V,repeat=3):
     env={'m':m,'z':z,'a':a};cases+=1
     if K.at(seed,0,env):
      accepted+=1;need(K.at(typed,0,env),'Kripke weak-to-typed counterexample');need(K.at(L13(),0,env),'Kripke finite L bootstrap counterexample')
 # Nonconstant six-vertex finite pre-arithmetic incidence model. Both
 # operations are constant zero; this is deliberately not a PRA model.
 V=tuple(range(6));base={(1,0),(2,0),(1,3),(2,3),(1,4),(2,5),(3,1),(4,2),(5,2),(3,3),(4,3),(5,3)}
 nonconstant=0
 for future,upsets in frames:
  for upset in upsets:
   vals={w:base|({(5,1)} if w in upset else set()) for w in future};K=Kripke(V,future,vals);env={'m':0,'z':1,'a':2}
   need(K.at(seed,0,env),'Incidence model weak seed failed');need(K.at(typed,0,env),'Incidence model typed seed failed');need(K.at(L13(),0,env),'Incidence model guard failed')
   nonconstant+=int(bool(upset) and 0 not in upset)
 # Two leaves separately destroy every possible private coordinate for
 # one vertex. Source clauses persist, but the structural premise fails.
 future={0:(0,1,2),1:(1,),2:(2,)};K=Kripke(V,future,{0:base,1:base|{(4,1)},2:base|{(5,1)}});env={'m':0,'z':1,'a':2}
 need(K.at(weak,0,env),'Fork control source unexpectedly failed');need(not K.at(FA('x',structure_body('x')),0,env),'Fork control lost dependent private-coordinate obstruction')
 # Exact canonical edge witness showing why the universal output guard
 # must remain. Restriction to a finite window is not a full PRA model.
 rel={(t,x,y,(x+y if t==0 else x*y)) for t,x,y in itertools.product(range(2),repeat=3) if (x+y if t==0 else x*y)<2}
 V,Ee,m=canonical(2,rel);oo,outputs=data(V,Ee,m);target=outputs[('o',1),('o',0),('o',0)]
 need(('o',0) in target and ('p',0,1) in target,'Canonical untyped-output counterexample absent')
 for e in [(('o',0),('p',0,0)),(('p',0,0),('o',0)),(('o',1),('p',1,0)),(('p',0,0),('p',1,0)),(('p',1,0),('p',0,1))]:need(e in Ee,'Canonical counterexample edge missing')
 out={'status':'PASS','frames':'two-world chain and three-world fork, constant domains','edge_valuations':valuations,'parameter_cases':cases,'satisfying_seed_cases':accepted,'genuinely_nonconstant_incidence_models':nonconstant,'fork_private_coordinate_negative_control':True,'universal_output_guard_negative_control':{'first_witness':'P(0,0)','second_witness':'P(1,0)','distinct_decoded_outputs':['O(0)','P(0,1)']},'scope':'Finite intuitionistic diagnostics, not a formal proof certificate or finite models of full PRA.','all_checks_active_under_python_O':True}
 pathlib.Path(__file__).with_name('kripke_seed_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
