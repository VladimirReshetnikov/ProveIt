"""Independent AST reconstruction; never imports the proposal's generator."""
from pathlib import Path
import json,re,hashlib

def check(b,m):
 if not b: raise RuntimeError(m)
def atom(op,*args):return (op,*args)
def E(x,y):return atom('E',x,y)
def eq(x,y):return atom('=',x,y)
def imp(A,B):return atom('imp',A,B)
def con(*xs):
 r=xs[0]
 for x in xs[1:]:r=atom('and',r,x)
 return r
def dis(*xs):
 r=xs[0]
 for x in xs[1:]:r=atom('or',r,x)
 return r
def every(x,A):return atom('forall',x,A)
def some(x,A):return atom('exists',x,A)
def many(op,xs,A):
 for x in reversed(xs):A=op(x,A)
 return A
def O(x):return E(x,'marker')
def no(A):return imp(A,'false')
def decoder(t,x,y,u,suffix):
 p,q='input'+suffix,'output'+suffix
 return many(some,[p,q],con(E(x,p),E(p,y),E(t,q),E(q,u),E(p,q)))
def matrix():
 T=dis(eq('tag','zero'),eq('tag','one'))
 return con(imp(con(eq('tag','one'),eq('right','zero')),eq('value','zero')),imp(T,decoder('tag','left','right','value','A')),imp(decoder('tag','left','right','test','B'),con(T,eq('test','value'))))
def h_tail(typed):
 A=every('test',imp(O('test'),matrix()))
 if typed:A=con(O('value'),A)
 A=some('value',A)
 for x in ['tag','right']:
  A=every(x,imp(O(x),A))
 return imp(O('left'),A)
def structure(x):
 B=con(O(x),every('j',imp(O('j'),no(E(x,'j')))))
 D=many(some,['c','d'],con(O('c'),O('d'),every('k',imp(con(E('c','k'),E('k','d')),eq('k',x)))))
 return con(no(E('marker',x)),dis(eq(x,'marker'),B,D))
def fixed(typed):
 return many(some,['marker','zero','one'],con(O('zero'),O('one'),every('left',con(structure('left'),h_tail(typed)))))
def guard():return some('q',con(E('one','q'),every('p',imp(E('p','zero'),E('p','q')))))
def scheme():
 B=many(every,['zero','one'],imp(O('zero'),imp(O('one'),imp(guard(),eq('v','v')))))
 return every('marker',dis(some('r',E('marker','r')),B))
def size(t):
 if isinstance(t,str):return 1
 if t[0] in ['forall','exists']:return 1+size(t[2])
 return 1+sum(size(a) for a in t[1:])
def serialize(t):
 if isinstance(t,str):return t
 return '('+' '.join([t[0]]+[serialize(a) for a in t[1:]])+')'
def parse(s):
 tok=re.findall(r'\(|\)|[^\s()]+',s); pos=0
 def take():
  nonlocal pos
  v=tok[pos];pos+=1
  if v!='(':return v
  a=[]
  while tok[pos]!=')':a.append(take())
  pos+=1;return tuple(a)
 r=take();check(pos==len(tok),'Parser trailing tokens');return r
def alpha(t,scope=()):
 if isinstance(t,str):
  if t in scope:return ('bound',scope[::-1].index(t))
  return ('free',t)
 if t[0] in ['forall','exists']:return (t[0],alpha(t[2],scope+(t[1],)))
 return (t[0],*(alpha(x,scope) for x in t[1:]))
proposal=Path(__file__).resolve().parent; outdir=proposal
forms={'baseline_fixed159':fixed(True),'untyped_output_fixed155':fixed(False),'L13':guard(),'scheme30_test':scheme()}
expected={'baseline_fixed159':159,'untyped_output_fixed155':155,'L13':13,'scheme30_test':33}
results={}
for name,t in forms.items():
 check(size(t)==expected[name],f'Wrong independently computed count for {name}: {size(t)}')
 source=(proposal/(name+'.sexp')).read_text(); p=parse(source)
 # L13 is open in z,a,m; map those free variables explicitly.
 if name=='L13':
  def rename(t):
   if isinstance(t,str):return {'z':'zero','a':'one','m':'marker'}.get(t,t)
   return (t[0],*(rename(x) for x in t[1:]))
  p=rename(p)
 check(alpha(t)==alpha(p),f'Independent formula differs for {name}')
 outdir.joinpath('independent_'+name+'.sexp').write_text(serialize(t)+'\n')
 results[name]={'nodes':size(t),'alpha_match':True,'proposal_sha256':hashlib.sha256(source.encode()).hexdigest()}
print(json.dumps({'status':'PASS','forms':results,'finite_seed_saving':4,'scheme_overhead':size(forms['scheme30_test'])-3,'note':'Independent construction; proposal code was read but not executed/imported.'},sort_keys=True,indent=2))
