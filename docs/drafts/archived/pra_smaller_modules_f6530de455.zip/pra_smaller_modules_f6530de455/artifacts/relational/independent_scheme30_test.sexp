(forall marker (or (exists r (E marker r)) (forall zero (forall one (imp (E zero marker) (imp (E one marker) (imp (exists q (and (E one q) (forall p (imp (E p zero) (E p q))))) (= v v))))))))
