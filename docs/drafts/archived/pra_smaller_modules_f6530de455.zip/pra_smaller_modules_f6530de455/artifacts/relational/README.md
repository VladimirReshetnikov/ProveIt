# Relational PRA: fixed seed 155, recurrent overhead 30

Run `python3 validate_relational.py` with standard Python 3; no third-party
dependencies or previous workspace are needed. It replays only four fresh
round-nine programs in clean temporary directories, normally and under `-O`,
and checks byte-identical generated ASTs/JSON/stdout. All checks use explicit
exceptions; the validator checks that there are zero Python `assert` nodes.

## Main theorem and exact language

`untyped_output_seed_proof.tex` states the full 155-node binary fixed seed,
the 21-node decoder, the 13-node column guard, and the complete recurrent
scheme. The signature is `{E,=}`. For a relation-only arithmetic body of
size N with r quaternary-relation occurrences and q quantifiers, its
recurrent graph axiom has `N + 16r + 4q + 30` nodes. Variables, logical
constants, predicate/function symbols, connectives, and quantifiers each
cost one AST node; bound-variable names at binder nodes are not extra nodes.
Negation is implication to false; biconditionals are expanded when used.

Only the finite source seed's existential output `u` loses its object guard.
All universal guards and both selected-parameter guards remain. Arbitrary
arithmetic bodies keep ordinary fully guarded translation. Source variables
are alpha-renamed away from the chosen marker when bound, and decoder
variables are fresh. The specified arithmetic inputs are sentences with
only the selected constants represented by free parameters `z,a`.

The new and old **finite** seeds are intuitionistically logically equivalent
before arithmetic. Thus the complete old and new theories have the same
models in either ambient logic, and the old full parameter-free
bi-interpretations and equiconsistency transfer unchanged. This is not a
claim that the finite seed alone is PRA, nor a claim of global minimality.

## Proof foundation, not an unavailable reference

The exact round-eight archive is `pra_literal_axioms_0e1088217e.zip`, SHA-256
`633d9f96a1f4e607b648b18f756ed35cfed43a59f77fcd29e0e196ec600fb92e`.
The enclosing deliverable supplies it as an explicitly unexecuted reference.
This folder also contains byte-for-byte static proof copies:

1. `baseline/source_calibration.tex` and `baseline/references/alternate_signature.tex`
   specify the infinite arithmetic source and inherited fixed-program trace
   calibration with matching-logic PRA.
2. `baseline/two_tag_source_proof.tex` supplies source interpretation,
   reconstruction and whole-carrier composites.
3. `baseline/graph49_proof.tex` gives source-backed graph separation,
   coordinate rigidity, intrinsic sink and whole-domain graph composites.
4. `baseline/combined_graph159_proof.tex` gives the integrated seed and
   outgoing-edge outer wrapper (historical row-guard stage).
5. `baseline/constant_column_bootstrap.tex` transposes the annihilator to
   `y=z`, proves the 13-node column guard before arithmetic, proves canonical
   guard uniqueness, and gives the final baseline 159/30 theory.
6. `untyped_output_seed_proof.tex` changes only that finite seed to 155.

These are written mathematical proofs, not formal-kernel certificates.
All archived files in this folder are static text; no archived code was
executed. `PORTABILITY_PROVENANCE.json` records their hashes and the sole
path-only portability patch to the independently authored AST auditor.

## Machine evidence and limits

* `untyped_output_seed.py`: exact AST generator, complete expanded formulas,
  generic translation ledgers and optional alternate-source 153/39 costs.
* `check_graph155_independent.py`: independently rebuilds four principal
  ASTs, without importing the proposal generator, then alpha-compares them.
* `check_untyped_output.py`: exhaustive graph-marker cases through four
  vertices, arbitrary operation tables, edge mutations, and the genuinely
  untyped unselected-tag witness repair control.
* `check_kripke_seed.py`: persistent edge valuations on a chain and fork,
  genuine nonconstant incidence models, and negative controls for private
  coordinate uniformity and deletion of the universal output guard.
* `graph155_finite_equivalence.txt`: independent mathematical audit.

The finite diagnostics do not prove intuitionistic validity or certify full
PRA models; the written constructive proof does the mathematical work.
`final_relational_validation.json` records fresh counts, hashes and replay
results. The optional default-to-projection source has fixed153/recurring39,
but a larger reverse relation definition. Main155/30 is smaller in summed
node count for every nonempty common finite arithmetic-axiom prefix.
