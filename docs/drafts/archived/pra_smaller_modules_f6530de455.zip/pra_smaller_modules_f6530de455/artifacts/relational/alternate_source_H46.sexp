(forall x (forall y (forall t (exists u (forall w (and (and (and (imp (and (= t a) (= x z)) (= u z)) (R t x y u)) (imp (R t x y w) (= w u))) (imp (imp (or (= t z) (= t a)) false) (= u y))))))))
