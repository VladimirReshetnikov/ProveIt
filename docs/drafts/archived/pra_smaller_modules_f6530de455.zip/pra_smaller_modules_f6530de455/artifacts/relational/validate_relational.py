#!/usr/bin/env python3
"""Replay only fresh round9 programs in clean folders, normally and with -O."""
from pathlib import Path
import ast,hashlib,json,os,re,shutil,subprocess,sys,tempfile

HERE=Path(__file__).resolve().parent
SCRIPTS=['untyped_output_seed.py','check_graph155_independent.py','check_untyped_output.py','check_kripke_seed.py']
GENERATED=['untyped_output_seed_metrics.json','untyped_output_checks.json','kripke_seed_checks.json']

def need(ok,message):
 if not ok:raise RuntimeError(message)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(s):
 tokens=re.findall(r'\(|\)|[^\s()]+',s);position=0
 def take():
  nonlocal position
  need(position<len(tokens),'Unexpected end of AST');token=tokens[position];position+=1
  if token!='(':return token
  row=[]
  while position<len(tokens) and tokens[position]!=')':row.append(take())
  need(position<len(tokens),'Unclosed AST');position+=1;return tuple(row)
 t=take();need(position==len(tokens),'Trailing AST tokens');return t
def alpha(t,scope=()):
 if isinstance(t,str):return ('bound',scope[::-1].index(t)) if t in scope else ('free',t)
 if t[0] in ('forall','exists'):return (t[0],alpha(t[2],scope+(t[1],)))
 return (t[0],*(alpha(x,scope) for x in t[1:]))
def size(t):
 if isinstance(t,str):return 1
 if t[0] in ('forall','exists'):return 1+size(t[2])
 return 1+sum(size(x) for x in t[1:])

def main():
 for file in [*SCRIPTS,Path(__file__).name]:
  tree=ast.parse((HERE/file).read_text())
  need(not any(isinstance(node,ast.Assert) for node in ast.walk(tree)),f'Disabled-by-O assertion in {file}')
 provenance=json.loads((HERE/'PORTABILITY_PROVENANCE.json').read_text())
 for relative,wanted in provenance['baseline_static_file_hashes'].items():need(sha(HERE/relative)==wanted,'Baseline static reference changed: '+relative)
 comparisons={}
 for old,new in [('column_fixed159','baseline_fixed159'),('native_guard_L13','L13'),('scheme30_test','scheme30_test'),('source_column_H48','source_H48'),('integrated157','alternate_baseline_fixed157')]:
  a=parse((HERE/'baseline/ast'/f'{old}.sexp').read_text());b=parse((HERE/f'{new}.sexp').read_text())
  need(alpha(a)==alpha(b),'Archived baseline AST mismatch: '+old)
  comparisons[old]={'nodes':size(a),'alpha_match':True}
 for name,wanted in [('old_arithmetic_R_definition',55),('default_arithmetic_R_definition',83)]:
  need(size(parse((HERE/'baseline/ast'/f'{name}.sexp').read_text()))==wanted,'Reverse-definition ledger mismatch')
 modes={};reports={}
 with tempfile.TemporaryDirectory(prefix='pra_graph155_replay_') as temporary:
  for mode,flags in [('normal',[]),('optimized',['-O'])]:
   work=Path(temporary)/mode;work.mkdir()
   for file in SCRIPTS:shutil.copy2(HERE/file,work/file)
   logs={};parsed={}
   for file in SCRIPTS:
    run=subprocess.run([sys.executable,*flags,file],cwd=work,text=True,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=180)
    need(run.returncode==0,f'{mode} {file}: {run.stderr} {run.stdout}')
    parsed[file]=json.loads(run.stdout);need(parsed[file].get('status')=='PASS',f'{file} did not report PASS')
    logs[file]=hashlib.sha256(run.stdout.encode()).hexdigest()
   generated={p.name:sha(p) for p in sorted(work.iterdir()) if p.suffix in ('.sexp','.json')}
   modes[mode]={'stdout_sha256':logs,'generated_sha256':generated};reports[mode]=parsed
   if mode=='normal':
    for p in work.iterdir():
     if p.suffix in ('.sexp','.json'):shutil.copy2(p,HERE/p.name)
  need(modes['normal']==modes['optimized'],'Normal/-O outputs differ')
 metrics=reports['normal']['untyped_output_seed.py'];finite=reports['normal']['check_untyped_output.py'];kripke=reports['normal']['check_kripke_seed.py']
 result={'status':'PASS','fixed_seed':metrics['fixed_seed'],'recurrent_overhead':metrics['recurrent_overhead'],'optional_alternate_fixed_seed':153,'optional_alternate_recurrent_overhead':39,'python_assert_nodes':0,'normal_and_optimized_outputs_identical':True,'archived_baseline_AST_comparisons':comparisons,'baseline_zip_sha256':provenance['baseline_zip_sha256'],'fresh_script_sha256':{p:sha(HERE/p) for p in SCRIPTS+[Path(__file__).name]},'finite_diagnostics':finite,'intuitionistic_diagnostics':kripke,'replay_evidence':modes,'limitations':'Finite checks and exact syntax ledgers are diagnostics, not a formal proof certificate. No finite graph is claimed to model full PRA. Full inherited calibration is in the bundled exact baseline reference. No archived program was executed.'}
 (HERE/'final_relational_validation.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print(json.dumps(result,sort_keys=True,indent=2))
if __name__=='__main__':main()
