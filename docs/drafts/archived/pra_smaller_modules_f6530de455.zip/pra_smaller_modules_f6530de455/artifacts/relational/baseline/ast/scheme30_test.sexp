(forall m (or (exists r (E m r)) (forall z (forall a (imp (E z m) (imp (E a m) (imp (exists q (and (E a q) (forall p (imp (E p z) (E p q))))) (= v v))))))))
