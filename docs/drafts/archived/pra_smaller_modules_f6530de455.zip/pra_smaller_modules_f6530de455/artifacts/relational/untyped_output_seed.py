#!/usr/bin/env python3
"""Fresh exact ASTs: weaken only the fixed seed's existential output guard.
No downloaded programs or prior-package modules are imported.
"""
from functools import reduce
import pathlib,json
V=lambda x:('var',x)
BOT=('false',)
def E(x,y):return ('E',V(x),V(y))
def R(t,x,y,w):return ('R',V(t),V(x),V(y),V(w))
def eq(x,y):return ('=',V(x),V(y))
def imp(a,b):return ('imp',a,b)
def neg(a):return imp(a,BOT)
def AND(*xs):return reduce(lambda a,b:('and',a,b),xs)
def OR(*xs):return reduce(lambda a,b:('or',a,b),xs)
def FA(x,t):return ('forall',x,t)
def EX(x,t):return ('exists',x,t)
def ALL(xs,t):return reduce(lambda t,x:FA(x,t),reversed(xs),t)
def SOME(xs,t):return reduce(lambda t,x:EX(x,t),reversed(xs),t)
def count(t):
 if t[0] in ('var','false'):return 1
 if t[0] in ('forall','exists'):return 1+count(t[2])
 return 1+sum(count(x) for x in t[1:])
def sexpr(t):
 if t[0]=='var':return t[1]
 if t[0]=='false':return 'false'
 if t[0] in ('forall','exists'):return f'({t[0]} {t[1]} {sexpr(t[2])})'
 return '('+' '.join([t[0]]+[sexpr(x) for x in t[1:]])+')'
def O(x):return E(x,'m')
def H48():
 tags=OR(eq('t','z'),eq('t','a'))
 return ALL(['x','y','t'],EX('u',FA('w',AND(imp(AND(eq('t','a'),eq('y','z')),eq('u','z')),imp(tags,R('t','x','y','u')),imp(R('t','x','y','w'),AND(tags,eq('w','u')))))))
def H46():
 tags=OR(eq('t','z'),eq('t','a'))
 return ALL(['x','y','t'],EX('u',FA('w',AND(imp(AND(eq('t','a'),eq('x','z')),eq('u','z')),R('t','x','y','u'),imp(R('t','x','y','w'),eq('w','u')),imp(neg(tags),eq('u','y'))))))
def variable_names(t):
 if t[0]=='var':return {t[1]}
 if t[0]=='false':return set()
 if t[0] in ('forall','exists'):return {t[1]}|variable_names(t[2])
 return set().union(*(variable_names(x) for x in t[1:]))
def alpha_away_marker(t):
 occupied=variable_names(t)|{'m'};next_id=[0]
 def go(t,renaming):
  if t[0]=='var':return V(renaming.get(t[1],t[1]))
  if t[0]=='false':return t
  if t[0] in ('forall','exists'):
   op,x,b=t;y=x
   if x=='m':
    while True:
     next_id[0]+=1;y='source_bound_'+str(next_id[0])
     if y not in occupied:break
    occupied.add(y)
   return (op,y,go(b,{**renaming,x:y}))
  return (t[0],*(go(x,renaming) for x in t[1:]))
 return go(t,{})
def translate(t,omit_seed_output_guard=False,serial=None):
 if serial is None:
  t=alpha_away_marker(t);serial=[0,variable_names(t)|{'m'}]
 if t[0] in ('var','false'):return t
 if t[0] in ('forall','exists'):
  op,x,b=t;b=translate(b,omit_seed_output_guard,serial)
  if op=='forall':b=imp(O(x),b)
  elif not (omit_seed_output_guard and x=='u'):b=AND(O(x),b)
  return (op,x,b)
 if t[0]=='R':
  tag,x,y,w=[v[1] for v in t[1:]]
  while True:
   serial[0]+=1;p,q=f'dp{serial[0]}',f'dq{serial[0]}'
   if p not in serial[1] and q not in serial[1]:break
  serial[1].update([p,q])
  return SOME([p,q],AND(E(x,p),E(p,y),E(tag,q),E(q,w),E(p,q)))
 return (t[0],*(translate(x,omit_seed_output_guard,serial) for x in t[1:]))
def structure_body(x):
 B=AND(O(x),FA('r',imp(O('r'),neg(E(x,'r')))))
 D=SOME(['b','c'],AND(O('b'),O('c'),FA('r',imp(AND(E('b','r'),E('r','c')),eq('r',x)))))
 return AND(neg(E('m',x)),OR(eq(x,'m'),B,D))
def fixed(omit=False,source=None):
 h=translate(H48() if source is None else source,omit)
 return SOME(['m','z','a'],AND(O('z'),O('a'),FA('x',AND(structure_body('x'),h[2]))))
def L13():return EX('q',AND(E('a','q'),FA('p',imp(E('p','z'),E('p','q')))))
def scheme30(theta):return FA('m',OR(EX('r',E('m','r')),ALL(['z','a'],imp(O('z'),imp(O('a'),imp(L13(),translate(theta)))))))
def scheme39(theta):return FA('m',OR(EX('r',E('m','r')),ALL(['z','a'],imp(O('a'),imp(translate(FA('v',R('a','z','v','z'))),translate(theta))))))
def main():
 forms={'source_H48':H48(),'typed_graph_H100':translate(H48()),'untyped_output_graph_H96':translate(H48(),True),'baseline_fixed159':fixed(),'untyped_output_fixed155':fixed(True),'L13':L13(),'scheme30_test':scheme30(eq('v','v')),'alternate_source_H46':H46(),'alternate_typed_H98':translate(H46()),'alternate_untyped_H94':translate(H46(),True),'alternate_baseline_fixed157':fixed(source=H46()),'alternate_untyped_fixed153':fixed(True,H46()),'alternate_scheme39_test':scheme39(eq('v','v'))}
 expected={'source_H48':48,'typed_graph_H100':100,'untyped_output_graph_H96':96,'baseline_fixed159':159,'untyped_output_fixed155':155,'L13':13,'scheme30_test':33,'alternate_source_H46':46,'alternate_typed_H98':98,'alternate_untyped_H94':94,'alternate_baseline_fixed157':157,'alternate_untyped_fixed153':153,'alternate_scheme39_test':42}
 for name,t in forms.items():
  if count(t)!=expected[name]:raise RuntimeError((name,count(t),expected[name]))
 # Counts apply to every normally translated arithmetic body. Include
 # bound marker names and decoder-like names as capture-avoidance tests.
 def occurrences(t,ops):
  if t[0] in ('var','false'):return 0
  if t[0] in ('forall','exists'):return int(t[0] in ops)+occurrences(t[2],ops)
  return int(t[0] in ops)+sum(occurrences(x,ops) for x in t[1:])
 tests=[eq('x','x'),R('a','x','y','z'),FA('x',R('z','x','x','x')),EX('m',R('a','m','z','m')),R('a','dp1','dq1','z')]
 tests+=[imp(t,EX('y',t)) for t in list(tests)]
 for t in tests:
  wanted=count(t)+16*occurrences(t,{'R'})+4*occurrences(t,{'forall','exists'})+30
  if count(scheme30(t))!=wanted:raise RuntimeError('Generic translation ledger failed')
 here=pathlib.Path(__file__).parent
 for name,t in forms.items():(here/(name+'.sexp')).write_text(sexpr(t)+'\n')
 out={'status':'PASS','nodes':{name:count(t) for name,t in forms.items()},'fixed_seed':155,'recurrent_overhead':30,'generic_scheme':'N + 16r + 4q + 30','only_removed_guard':'O(u) at the fixed source condition existential output; all universal guards and typed seed parameters remain','ordinary_arithmetic_axiom_translation_unchanged':True,'all_checks_active_under_python_O':True}
 (here/'untyped_output_seed_metrics.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
