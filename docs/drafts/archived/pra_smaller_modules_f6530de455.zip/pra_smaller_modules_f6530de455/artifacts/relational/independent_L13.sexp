(exists q (and (E one q) (forall p (imp (E p zero) (E p q)))))
