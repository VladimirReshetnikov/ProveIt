"""Independent local diagnostic. Does not import or execute source-package code."""
import itertools, json
from pathlib import Path

def require(p,msg):
    if not p: raise RuntimeError(msg)

def leaf(s): return (s,(),None)
def app(s,*args,body=None): return (s,args,body)
def size(t,full=False):
    return 1+sum(size(a,full) for a in t[1])+(size(t[2],True) if full and t[2] else 0)
def quant(v,t): return app('quant:'+v,t)
def allq(vs,t):
    for v in reversed(vs): t=quant(v,t)
    return t
zero=leaf('0'); x=leaf('x'); y=leaf('y'); a=leaf('a'); n=leaf('n'); b=leaf('b'); v=leaf('v'); w=leaf('w')
def S(t):return app('S',t)
def D(t,u):return app('D',t,u)
def eq(t,u):return app('=',t,u)
def neg(t):return app('implies',t,leaf('false'))
def Q(t,u):return app('Q',t,u,body=w)
def Z(t,u):return app('Z',t,u,body=zero)
def I(t,u,v):return Q(Z(t,S(u)),v)
def C(t,r,s,whole=False):return app('C',r,s,body=Z(t,x) if whole else t)
def formulas(t,whole=False,shift=True):
    definition=allq(('x','a'),eq(C(t,x,a,whole),Z(t,x)))
    witness=allq(('a','n','b'),eq(C(t,Q(C(t,S(b) if shift else b,a,whole),n),a,whole),zero))
    return definition,witness
payloads=[zero,x,app('chi',x,a),Q(x,a),Z(app('chi',Q(x,a),S(a)),x)]
counts=[]
for t in payloads:
    m,T=size(t),size(t,True)
    for whole in (False,True):
      for shift in (False,True):
        de,wi=formulas(t,whole,shift)
        actual=[size(de),size(de,True),size(wi),size(wi,True)]
        expected=[8+m,9+2*T+(3 if whole else 0),12+int(shift),13+int(shift)+2*T+(6 if whole else 0)]
        require(actual==expected,f'Cost mismatch {actual} != {expected}')
        counts.append({'tail_active':m,'tail_full':T,'whole_descriptor':whole,'shifted':shift,'definition_active_full':actual[:2],'witness_active_full':actual[2:]})
sep=neg(eq(zero,S(zero)))
bit=allq(('x','y'),app('and',eq(app('chi',x,x),S(zero)),app('or',eq(x,y),eq(app('chi',x,y),zero))))
off=allq(('x','y'),app('or',eq(x,y),eq(D(x,y),zero)))
part=allq(('x','y'),neg(eq(D(x,zero),D(x,D(y,y)))))
require([size(z) for z in (sep,bit,off,part)]==[6,18,11,13],'Seed counts')
oldimp=I(x,S(zero),y); newimp=Q(Q(y,x),S(zero))
require(size(oldimp)-size(newimp)==1,'Implication active saving')
require(size(oldimp,True)-size(newimp,True)==1,'Implication full saving')
def q(r,s):return s if r==0 else r-1
def z(r,s):return s if r==0 else 0
for A,B in itertools.product((0,1),repeat=2):
    old=q(z(A,2),B); new=q(q(B,A),1)
    require(old==new==int((not A) or B),'Boolean implication table')
# Finite diagnostic on actual Nat prefixes, not finite arithmetic models.
# Every listed mask obeys F(0)=0 and F(x) in {0,x}; arbitrary Boolean tails.
mask_targets=0
for limit in range(1,11):
  for bits in itertools.product((0,1),repeat=limit):
    f=[0]+[i*bits[i-1] for i in range(1,limit+1)]
    # At target n<=limit-1 the boundary scan only reads through index limit.
    c=0; e=0
    for n0 in range(limit):
      require(f[c]==0 and (f[c+1]!=0 or c==n0),'Shifted boundary invariant')
      require(f[q(f[c+1],n0)]==0,'W13 reverse witness')
      good=(f[e]==0 and e==n0) or (f[e]!=0 and e>0 and f[e-1]==0)
      require(good,'W12 first-failure invariant')
      require(f[q(f[e],n0)]==0,'W12 reverse witness')
      c=n0+1 if f[c+1]==0 else c
      e=n0+1 if f[e]==0 else e
      mask_targets+=1
report={'status':'PASS','scope':'Independent AST/count/Boolean/Nat-prefix diagnostics; no downloaded code executed; not a formal PRA proof or finite-model check.','cost_cases':counts,'seed_counts':{'Sep':size(sep),'Bit':size(bit),'DM_Off':size(off),'DM_Part':size(part)},'implication_compiler':{'old_active_full':[size(oldimp),size(oldimp,True)],'new_active_full':[size(newimp),size(newimp,True)],'saving_per_implication':[1,1]},'reverse_mask_target_cases':mask_targets}
print(json.dumps(report,indent=2,sort_keys=True))
