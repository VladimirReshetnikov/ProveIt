"""Independent grammar/Boolean/count diagnostics. No proposal imports."""
from pathlib import Path
import json,itertools

def need(p,msg):
 if not p: raise RuntimeError(msg)
# Leaves are strings; generated Q alone has one-node fixed descriptor.
def f(op,*args):return (op,*args)
def Q(a,b):return f('Q',a,b)
def chi(a,b):return f('chi',a,b)
def S(a):return f('S',a)
def fv(t):
 if isinstance(t,str):return set() if t=='0' else {t}
 return set().union(*(fv(a) for a in t[1:]))
def admissible(t):
 if t=='0':return True
 if isinstance(t,str):return False
 if t[0]=='chi' and len(t)==3:return fv(t)<= {'x','a'}
 if t[0]=='Q' and len(t)==3:
  return isinstance(t[1],tuple) and t[1][0]=='chi' and len(t[1])==3 and fv(t[1])<={'x','a'} and admissible(t[2])
 return False
def size(t,full=False):
 if isinstance(t,str):return 1
 return 1+sum(size(a,full) for a in t[1:])+(int(full) if t[0] in ['Q','Z'] else 0)
def compile(P):
 if P=='false':return '0'
 op,*args=P
 if op=='=':return chi(*args)
 a,b=map(compile,args)
 if op=='and':return Q(chi(a,'0'),b)
 if op=='or':return chi(Q(a,chi(b,'0')),'0')
 if op=='imp':return chi(Q(b,a),'0')
 raise RuntimeError(P)
def evalterm(t,env):
 if isinstance(t,str):return 0 if t=='0' else env[t]
 op=t[0];a=[evalterm(x,env) for x in t[1:]]
 if op=='chi':return int(a[0]==a[1])
 if op=='Q':return a[1] if a[0]==0 else a[0]-1
 if op=='S':return a[0]+1
 raise RuntimeError(t)
def evalformula(P,env):
 if P=='false':return False
 op,*args=P
 if op=='=':return evalterm(args[0],env)==evalterm(args[1],env)
 a,b=[evalformula(x,env) for x in args]
 return (a and b) if op=='and' else ((a or b) if op=='or' else ((not a) or b))
leaves=['false',('=','x','a'),('=',Q('x','a'),S('a'))]
first=leaves+[(op,a,b) for op in ['and','or','imp'] for a in leaves for b in leaves]
formulas=leaves+[(op,a,b) for op in ['and','or','imp'] for a in first for b in first]
count=0
for P in formulas:
 B=compile(P)
 need(admissible(B),'Compiler escaped the restricted grammar')
 for x,a in itertools.product(range(4),repeat=2):
  value=evalterm(B,{'x':x,'a':a})
  need(value in [0,1] and bool(value)==evalformula(P,{'x':x,'a':a}),'Truth/range mismatch')
  mask=evalterm(Q(B,'x'),{'x':x,'a':a})
  need(mask==(0 if value else x),'Mask Q(B,x) mismatch')
  count+=1
need(not admissible(Q('0','0')),'Strict subgrammar witness admitted')
need(not admissible(S('0')),'Literal one should not be a grammar production')
need(admissible(chi('0','0')),'Available true bit rejected')
need(not admissible(chi('x','third')),'Captured numerical parameter admitted')
# Compiler contexts with free holes use x,a and are valid B contexts except
# the bare second conjunction hole; substitute atomic Boolean payloads.
u,v='x','a'
contexts={'and':Q(chi(u,'0'),v),'or':chi(Q(u,chi(v,'0')),'0'),'imp':chi(Q(v,u),'0')}
expected={'and':[3,4],'or':[5,6],'imp':[3,4]}
for name,t in contexts.items():
 got=[size(t)-2,size(t,True)-2]
 need(got==expected[name],f'Cost mismatch {name}: {got}')
 for A,B in itertools.product((0,1),repeat=2):
  ans=evalterm(t,{'x':A,'a':B})
  truth=(A and B) if name=='and' else ((A or B) if name=='or' else ((not A) or B))
  need(ans==int(truth),'Boolean context truth mismatch')
print(json.dumps({'status':'PASS','formula_instances':len(formulas),'truth_and_mask_cases':count,'three_production_admission':True,'strict_subgrammar_counterexample':'Q(0,0)','literal_one_excluded_true_bit_chi00_admitted':True,'free_variable_check':True,'context_overheads_active_full':expected,'scope':'Fresh grammar, finite semantic and AST checks; no imported/downloaded code; proof still required for arbitrary carriers and BI.'},indent=2,sort_keys=True))
