#!/usr/bin/env python3
"""Independent authored AST/truth-table audit of six current Boolean compilers.
No supplied Python, formal source, or TeX is executed/imported.
"""
from dataclasses import dataclass
from itertools import product
import json
@dataclass(frozen=True)
class T:
 op:str
 args:tuple=()
 def active(self):return 1+sum(a.active() for a in self.args)
 def full(self):return 1+(1 if self.op in ('Q','Z') else 0)+sum(a.full() for a in self.args)
def t(op,*a):return T(op,a)
z=t('0');one=t('S',z);A=t('A');B=t('B')
def Q(a,b):return t('Q',a,b)
def Z(a,b):return t('Z',a,b)
def eq(a,b):return t('chi',a,b)
def C(a,b,c):return Q(Z(a,t('S',b)),c)
def N(a):return Z(a,one)
def ZA(a,b):return Z(N(a),b)
def emit(style,op,a,b):
 if style=='proposed':return {'and':lambda:Q(eq(a,z),b),'or':lambda:eq(Q(a,eq(b,z)),z),'imp':lambda:eq(Q(b,a),z)}[op]()
 if style=='conditional':return {'and':lambda:C(a,z,b),'or':lambda:C(a,b,one),'imp':lambda:C(a,one,b)}[op]()
 if style=='marked_Q':return {'and':lambda:Q(Q(a,one),b),'or':lambda:Q(Q(a,Q(b,one)),one),'imp':lambda:Q(Q(b,a),one)}[op]()
 if style=='relaxed_hybrid':return emit('marked_Q' if op=='imp' else 'conditional',op,a,b)
 if style=='nested_Z':return {'and':lambda:ZA(a,b),'or':lambda:N(ZA(N(a),N(b))),'imp':lambda:N(ZA(a,N(b)))}[op]()
 raise RuntimeError(style)
def check(c,m):
 if not c:raise RuntimeError(m)
def ev(a,e):
 if a.op=='0':return 0
 if a.op in ('A','B'):return e[a.op]
 v=[ev(x,e) for x in a.args]
 if a.op=='S':return v[0]+1
 if a.op=='chi':return int(v[0]==v[1])
 if a.op=='Q':return v[1] if v[0]==0 else v[0]-1
 if a.op=='Z':return v[1] if v[0]==0 else 0
 raise RuntimeError(a.op)
profiles={};truth_cases=0
for style in ['proposed','conditional','marked_Q','nested_Z']:
 profiles[style]={}
 for op in ['and','or','imp']:
  term=emit(style,op,A,B);profiles[style][op]=[term.active()-2,term.full()-2]
  for a,b in product([0,1],repeat=2):
   target={'and':a and b,'or':a or b,'imp':not a or b}[op]
   check(ev(term,{'A':a,'B':b})==int(target),'Truth table '+style+op);truth_cases+=1
expected={'proposed':{'and':[3,4],'or':[5,6],'imp':[3,4]},'conditional':{'and':[4,6],'or':[5,7],'imp':[5,7]},'marked_Q':{'and':[4,6],'or':[7,10],'imp':[4,6]},'nested_Z':{'and':[4,6],'or':[13,18],'imp':[10,14]}}
check(profiles==expected,'Expanded overhead profiles')
# Formula trees share exact atom terms and their descriptor costs.
base=['A','B','bottom'];level1=base+[(op,a,b) for op in ['and','or','imp'] for a in base for b in base]
formulas=level1+[(op,a,b) for op in ['and','or','imp'] for a in level1 for b in level1]
def compile(f,style):
 if f=='A':return A
 if f=='B':return B
 if f=='bottom':return z
 op,a,b=f;return emit(style,op,compile(a,style),compile(b,style))
def counts(f):
 if isinstance(f,str):return [0,0,0]
 op,a,b=f;u=counts(a);v=counts(b);w=[x+y for x,y in zip(u,v)];w[['and','or','imp'].index(op)]+=1;return w
strict_full=0
for f in formulas:
 a,o,i=counts(f);new=compile(f,'proposed');oldC=compile(f,'conditional');oldQ=compile(f,'marked_Q');oldZ=compile(f,'nested_Z')
 check(oldC.active()-new.active()==a+2*i,'Conditional active')
 check(oldC.full()-new.full()==2*a+o+3*i,'Conditional full')
 check(oldQ.active()-new.active()==a+2*o+i,'Q active')
 check(oldQ.full()-new.full()==2*a+4*o+2*i,'Q full')
 check(oldZ.active()>=oldC.active() and oldZ.full()>=oldC.full(),'Nested Z domination')
 # Counterexample uses tail-only; all remaining sources whole-body.
 old_active=min(21+oldC.active(),21+oldQ.active(),21+oldZ.active())
 old_full=min(23+4*oldC.full(),32+4*oldQ.full(),32+4*oldZ.full())
 check(old_active-(21+new.active())==a+min(2*i,i+2*o),'Exact active envelope')
 check(old_full-(23+4*new.full())==min(8*a+12*i+4*o,9+8*a+8*i+16*o),'Exact full envelope')
 hybrid=compile(f,'relaxed_hybrid')
 check((20+hybrid.active())-(21+new.active())==a+i-1,'Relaxed covered12 active')
 check((22+4*hybrid.full())-(23+4*new.full())==8*a+4*o+8*i-1,'Relaxed covered12 full')
 if a+o+i:
  check(old_full>23+4*new.full(),'Compound matched13 full strictness')
  check(22+4*hybrid.full()>23+4*new.full(),'Compound relaxed12 full strictness')
  strict_full+=1
 if a+i:check(old_active>21+new.active(),'AND/IMP active strictness')
 for x,y in product([0,1],repeat=2):
  env={'A':x,'B':y};expected_value=ev(oldC,env)
  check(ev(new,env)==expected_value and ev(oldQ,env)==expected_value and ev(oldZ,env)==expected_value,'Composite truth');truth_cases+=1
# Negative control: whole-body32 must NOT be credited as tail-only23.
check(32+4*3 != 23+4*3,'Descriptor convention negative control')
print(json.dumps({'status':'PASS','connective_active_full_overheads':profiles,'formula_trees_checked':len(formulas),'truth_cases_checked':truth_cases,'compound_strict_full_cases':strict_full,'relaxed_hybrid_covered12_minus_new13':{'active':'a+i-1','full':'8*a+4*o+8*i-1','strict_full_for_every_compound':True},'exact_matched13_six_source_envelope_savings':{'active':'a+min(2*i,i+2*o)','full':'min(8*a+12*i+4*o,9+8*a+8*i+16*o)'},'scope':['Matched identical earlier atomic term trees and frozen descriptors.','The tail-only constructor is already in current Counterexample Masks; no novelty credit for its 9-node convention difference.','All source templates charged as actually stated, not optimized arbitrary alternatives.','Matched13 comparison: atomic formulas tie; OR-only formulas can tie active size.','Stronger relaxed benchmark grants best per-connective hybrid, tail-only metadata, and a free covered12 discount; compound full-size savings remain strict, but OR-only active size may be larger by one.','Coverage seed and D-vocabulary costs must be compared separately.','Finite AST diagnostics support, but do not replace, structural-induction proofs.','All checks are explicit exceptions and remain active under python -O.']},indent=2,sort_keys=True))
