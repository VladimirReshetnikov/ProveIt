#!/usr/bin/env python3
"""Authored literal AST ledger; no supplied source/checker is imported or run."""
from dataclasses import dataclass
import json
@dataclass(frozen=True)
class T:
 name:str
 args:tuple=()
 body:object=None
 def active(self):return 1+sum(x.active() for x in self.args)
 def full(self):return 1+sum(x.full() for x in self.args)+(0 if self.body is None else self.body.full())
def v(n):return T(n)
def app(n,*a,body=None):return T(n,a,body)
def eq(a,b):return app('=',a,b)
def implies(a,b):return app('->',a,b)
def both(a,b):return app('&',a,b)
def either(a,b):return app('|',a,b)
def forall(n,a):return app('forall '+n,a)
def exists(n,a):return app('exists '+n,a)
def neq(a,b):return implies(eq(a,b),v('bottom'))
def check(c,m):
 if not c:raise RuntimeError(m)
x,y,a,n,b,w=map(v,['x','y','a','n','b','w']);zero=v('0')
def S(x):return app('S',x)
def D(x,y):return app('D',x,y)
def chi(x,y):return app('chi',x,y)
def Q(x,y):return app('Q',x,y,body=w)
def Z(x,y):return app('Z',x,y,body=zero)
def maskcall(body,x,y):return app('Mask',x,y,body=body)
def witness(body,shift):return forall('a',forall('n',exists('b',eq(maskcall(body,Q(maskcall(body,S(b) if shift else b,a),n),a),zero))))
def subst(t,m):
 if not t.args and t.body is None and t.name in m:return m[t.name]
 return T(t.name,tuple(subst(q,m) for q in t.args),t.body)
seed={'Sep':neq(zero,S(zero)),'Bit':forall('x',forall('y',both(eq(chi(x,x),S(zero)),either(eq(x,y),eq(chi(x,y),zero))))),'Part':forall('x',exists('y',neq(chi(x,zero),chi(x,S(y))))),'Cov':forall('x',exists('y',either(eq(x,zero),eq(x,S(y))))),'Off':forall('x',forall('y',either(eq(x,y),eq(D(x,y),zero)))),'DPart':forall('x',exists('y',neq(D(x,zero),D(x,D(y,y)))))}
expected={'Sep':6,'Bit':18,'Part':12,'Cov':10,'Off':11,'DPart':13}
for k,t in seed.items():check(t.active()==expected[k] and t.full()==expected[k],'Seed count '+k)
tails=[zero,x,a,S(zero),chi(x,a),Q(x,a),Z(x,a)]
base=tails[:]
for u in base:
 tails += [S(u),Q(u,a),Z(u,x),chi(u,a),app('nested',u,a,body=Z(chi(x,a),x))]
for t in tails:
 m,Tf=t.active(),t.full();body=Z(t,x)
 for stored,extra in [(body,9),(t,0)]:
  definition=forall('x',forall('a',eq(maskcall(stored,x,a),body)))
  w13=witness(stored,True);w12=witness(stored,False)
  check(w13.active()==13 and w12.active()==12,'Witness nodes')
  check(definition.active()+w13.active()==21+m,'Active package')
  check(definition.full()+w13.full()==23+4*Tf+extra,'Full package')
  check(w13.full()-w12.full()==1,'Shift delta')
  check(subst(maskcall(stored,x,a),{'x':S(x)}).body==stored,'Frozen descriptor changed')
check((21+3,32+4*3)==(24,44),'Whole body sample')
check((21+3,23+4*3)==(24,35),'Tail-only sample')
check(32+4*3 != 23+4*3,'Negative control must detect mixed conventions')
print(json.dumps({'status':'PASS','seed_counts':expected,'whole_body_mask':{'witness13_active':13,'witness12_active':12,'witness13_full':'14+2H = 20+2T','definition_plus13_active':'19+m_body = 21+m_tail','definition_plus13_full':'20+4H = 32+4T','definition_plus12_full':'19+4H = 31+4T'},'tail_only_constructor':{'witness13_full':'14+2T','definition_plus13_full':'23+4T','wrapper_charge_difference':9},'fixed_recurring_frontiers':{'0_S_chi_shifted':[24,13],'0_S_chi_partition':[30,12],'0_D_merged':[24,12]},'finite_tail_examples':len(tails),'negative_control':'Mixing tail-only and whole-body descriptor conventions rejected','scope':'Exact finite AST diagnostics; neither arbitrary-model equivalence proof nor minimum theorem. No downloaded code executed.'},sort_keys=True,indent=2))
