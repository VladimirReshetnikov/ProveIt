#!/usr/bin/env python3
"""Reproduce the finite checks and PDF; optionally package the deliverable."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


ROOT = Path(__file__).resolve().parent
ARTIFACTS = ROOT / "artifacts"


def run_check(name: str, result_name: str) -> dict:
    completed = subprocess.run(
        [sys.executable, str(ARTIFACTS / name)],
        cwd=ROOT, check=True, capture_output=True, text=True
    )
    data = json.loads(completed.stdout)
    if data.get("status") != "passed":
        raise RuntimeError(f"{name} did not report passed")
    (ARTIFACTS / result_name).write_text(
        json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(f"{name}: passed")
    return data


def deliverable_files() -> list[Path]:
    return [
        path for path in sorted(ROOT.rglob("*"))
        if path.is_file()
        and "build" not in path.relative_to(ROOT).parts
        and "__pycache__" not in path.relative_to(ROOT).parts
        and path.suffix != ".pyc"
        and path.name != "SHA256SUMS.txt"
    ]


def write_checksums() -> None:
    lines = [
        f"{hashlib.sha256(path.read_bytes()).hexdigest()}  "
        f"{path.relative_to(ROOT).as_posix()}"
        for path in deliverable_files()
    ]
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()

    boundaries = run_check("check_boundaries.py", "boundary_results.json")
    normalization = run_check(
        "check_normalization.py", "normalization_results.json"
    )
    scan = boundaries["scan"]
    summary = (
        "FINITE VERIFICATION RESULTS\n"
        "===========================\n\n"
        "These are finite diagnostics, not a full Lean/Rocq formalization.\n"
        "The infinite metatheorems are established by the written proofs.\n\n"
        f"Source snapshot: {boundaries['source_commit']}\n"
        f"Ordinary-module AST cases: "
        f"{boundaries['schema_counts']['ordinary_modules']}\n"
        f"Each compressed/expanded boundary AST family: "
        f"{boundaries['schema_counts']['new_compressed_boundaries']}\n"
        f"Binder/substitution alpha-commutation cases: "
        f"{boundaries['capture_and_frozen_scope']['expansion_substitution_commutation_checks']}\n"
        f"Exhaustive scan horizons: 0..{scan['max_horizon']}\n"
        f"Complete Boolean truth vectors: {scan['truth_vectors']}\n"
        f"Scan states: {scan['scan_states']}\n"
        f"Quantifier-free invariant checks: "
        f"{scan['quantifier_free_invariant_checks']}\n"
        f"Witnessed-boundary clause checks: "
        f"{scan['witnessed_boundary_clause_checks']}\n"
        f"Contextual cancellation rows: "
        f"{len(normalization['contextual_family'])}\n"
        f"Absorbing-family rows: {len(normalization['absorbing_family'])}\n"
        f"Bounded standard-N equalities: "
        f"{normalization['bounded_semantic_equalities_checked']}\n"
        f"Sample nonincreasing axiom packets: "
        f"{len(normalization['sample_axiom_packets'])}\n"
        f"Retained frozen-label identity checks: "
        f"{normalization['retained_frozen_label_checks']}\n\n"
        "Scope limitations:\n"
        "- Old-rule models cover the heads relevant to the displayed\n"
        "  strict families; they do not reimplement unrelated source optimizers.\n"
        "- Numerical checks are finite; nonstandard inputs are handled by\n"
        "  the internal induction proofs in the paper.\n"
        "- Source-wise image size checks concern axiom formulas, not arbitrary\n"
        "  formal derivations or all supporting proof certificates.\n"
    )
    (ARTIFACTS / "verification_summary.txt").write_text(summary)

    if not args.checks_only:
        if shutil.which("pdflatex") is None:
            raise RuntimeError("pdflatex is required to rebuild report.pdf")
        build = ROOT / "build"
        build.mkdir(exist_ok=True)
        for number in (1, 2):
            completed = subprocess.run(
                ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                 "-output-directory=build", "report.tex"],
                cwd=ROOT, capture_output=True, text=True
            )
            (build / f"latex_pass_{number}.txt").write_text(
                completed.stdout + completed.stderr
            )
            if completed.returncode:
                raise RuntimeError(
                    f"pdflatex pass {number} failed; inspect build logs"
                )
        shutil.copy2(build / "report.pdf", ROOT / "report.pdf")
        print("report.pdf: compiled")

    write_checksums()
    if args.archive:
        destination = ROOT.with_suffix(".zip")
        with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
            files = deliverable_files() + [ROOT / "SHA256SUMS.txt"]
            for path in sorted(files):
                archive.write(
                    path, (Path(ROOT.name) / path.relative_to(ROOT)).as_posix()
                )
        print(f"Archive: {destination.name}")


if __name__ == "__main__":
    main()
