#!/usr/bin/env python3
"""Finite diagnostics for two certified iPRA normalization refinements.

This is NOT a proof assistant and does not establish the interpretation theorem.
It checks exact charged syntax, frozen-description substitution, the explicit
strict families, bounded arithmetic examples, and sample homomorphic images.
The old-rule model includes the rule heads relevant to the displayed families,
not every unrelated module/sharing optimizer in the source archives.
Python 3.10+; standard library only. Run with no arguments to print JSON.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from math import isqrt
import json


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple[Term, ...] = ()
    name: str = ""
    label: Label | None = None


@dataclass(frozen=True)
class Label:
    name: str
    body: Term
    parameters: tuple[str, ...] = ()


def var(name: str) -> Term:
    return Term("var", name=name)


def op(name: str, *args: Term) -> Term:
    return Term(name, tuple(args))


def call(label: Label, *args: Term) -> Term:
    assert len(args) == len(label.parameters) + 2
    return Term("rec", tuple(args), label=label)


ZERO = op("0")
V, W = var("v"), var("w")
A = Label("A", op("S", V))
Q = Label("Q", W)


@lru_cache(maxsize=None)
def size(term: Term) -> int:
    """Every occurrence pays its full frozen descriptor, recursively."""
    return 1 + sum(map(size, term.args)) + (
        size(term.label.body) if term.op == "rec" else 0
    )


def free_variables(term: Term) -> set[str]:
    """Active variables only: frozen labels have their own formal slots."""
    if term.op == "var":
        return {term.name}
    return set().union(*(free_variables(a) for a in term.args))


def substitute(term: Term, values: dict[str, Term]) -> Term:
    if term.op == "var":
        return values.get(term.name, term)
    return Term(term.op, tuple(substitute(a, values) for a in term.args),
                term.name, term.label)


def instantiate(label: Label, state: Term, counter: Term,
                params: tuple[Term, ...]) -> Term:
    assert len(params) == len(label.parameters)
    values = {"v": state, "w": counter}
    values.update(zip(label.parameters, params))
    return substitute(label.body, values)


def numeral(n: int) -> Term:
    result = ZERO
    for _ in range(n):
        result = op("S", result)
    return result


MODES = {
    "direct_native_p": 1,
    "direct_generated_Q": 3,
    "shifted_origin": 4,
    "shifted_pairing": 3,
}


def predecessor(term: Term, mode: str) -> Term:
    if mode == "direct_native_p":
        return op("p", term)
    if mode == "direct_generated_Q":
        return call(Q, term, ZERO)
    if mode == "shifted_origin":
        return op("L", op("S", op("B", term, ZERO)))
    if mode == "shifted_pairing":
        return op("L", op("U", term, ZERO))
    raise ValueError(mode)


def unwrap_predecessor(term: Term, mode: str) -> Term | None:
    """Recognize precisely D(t), including its literal zero argument."""
    if mode == "direct_native_p":
        if term.op == "p":
            return term.args[0]
    elif mode == "direct_generated_Q":
        if term.op == "rec" and term.label == Q and term.args[1] == ZERO:
            return term.args[0]
    elif mode == "shifted_origin":
        if term.op == "L" and term.args[0].op == "S":
            inner = term.args[0].args[0]
            if inner.op == "B" and inner.args[1] == ZERO:
                return inner.args[0]
    elif mode == "shifted_pairing":
        if term.op == "L":
            inner = term.args[0]
            if inner.op == "U" and inner.args[1] == ZERO:
                return inner.args[0]
    return None


def routing_rewrite(term: Term, mode: str) -> Term | None:
    """Relevant old constructor/pairing rules; each is charged decreasing."""
    if mode == "direct_native_p" and term.op == "p":
        arg = term.args[0]
        if arg == ZERO:
            return ZERO
        if arg.op == "S":
            return arg.args[0]
    if mode == "shifted_origin":
        if term.op == "B":
            left, right = term.args
            if left == ZERO and right == ZERO:
                return ZERO
            if left.op == "L" and right.op == "R" and left.args == right.args:
                return left.args[0]
        if term.op in {"L", "R"}:
            arg = term.args[0]
            if arg == ZERO:
                return ZERO
            if arg.op == "B":
                return arg.args[0 if term.op == "L" else 1]
            if arg.op == "S" and arg.args[0].op == "B":
                a, n = arg.args[0].args
                if a == ZERO:
                    return op("S", n) if term.op == "L" else ZERO
                if a.op == "S":
                    return a.args[0] if term.op == "L" else op("S", n)
    if mode == "shifted_pairing":
        if term.op in {"L", "R"} and term.args[0].op == "U":
            a, n = term.args[0].args
            if a == ZERO:
                return n if term.op == "L" else ZERO
            if a.op == "S":
                return a.args[0] if term.op == "L" else n
        if term.op == "U":
            left, right = term.args
            if left.op == "S" and left.args[0].op == "L" and right.op == "R":
                if left.args[0].args == right.args:
                    return right.args[0]
            if left.op == "L" and right.op == "S" and right.args[0].op == "R":
                if left.args == right.args[0].args:
                    return op("S", left.args[0])
    return None


def old_root_rewrite(term: Term, mode: str) -> Term | None:
    route = routing_rewrite(term, mode)
    if route is not None:
        assert size(route) < size(term)
        return route
    if term.op != "rec":
        return None
    n, a, *params = term.args
    if n == ZERO:
        return a
    if n.op == "S":
        prev = n.args[0]
        rhs = instantiate(term.label, call(term.label, prev, a, *params),
                          prev, tuple(params))
        if size(rhs) < size(term):
            return rhs
        if mode == "shifted_origin" and prev == ZERO:
            fused = instantiate(term.label, a, ZERO, tuple(params))
            if size(fused) < size(term):
                return fused
    if mode.startswith("direct_") and term.label == A and a == ZERO:
        return n
    return None


@lru_cache(maxsize=None)
def normalize_old(term: Term, mode: str) -> Term:
    """Strictly decreasing active rewriting, never traversing a label."""
    current = Term(term.op, tuple(normalize_old(a, mode) for a in term.args),
                   term.name, term.label)
    result = old_root_rewrite(current, mode)
    if result is None:
        return current
    assert size(result) < size(current)
    return normalize_old(result, mode)


def fresh_counter(term: Term) -> str:
    used = free_variables(term)
    name = "fresh_counter"
    while name in used:
        name += "_"
    return name


def new_root_rewrite(term: Term, mode: str) -> Term | None:
    # Contextual cancellation is a proved composite of the old step equation
    # and D(Sz)=z; its intermediate term is allowed to tie in size.
    inside = unwrap_predecessor(term, mode)
    if inside is not None and inside.op == "rec" and inside.label == A:
        n, a = inside.args
        if n.op == "S":
            result = call(A, n.args[0], a)
            assert size(result) < size(term)
            return result
    # The side checker is OLD normalization only. Calling normalize_new here
    # would obscure termination and is intentionally forbidden.
    if term.op == "rec":
        _, a, *params = term.args
        test = instantiate(term.label, a, var(fresh_counter(term)), tuple(params))
        if normalize_old(test, mode) == a:
            assert size(a) < size(term)
            return a
    return None


@lru_cache(maxsize=None)
def normalize_new(term: Term, mode: str) -> Term:
    current = Term(term.op, tuple(normalize_new(a, mode) for a in term.args),
                   term.name, term.label)
    current = normalize_old(current, mode)
    result = new_root_rewrite(current, mode)
    if result is None:
        return current
    assert size(result) < size(current)
    return normalize_new(result, mode)


def old_grammar_admits(body: Term, mode: str) -> bool:
    if body == V:
        return False
    if mode == "shifted_origin" and body in {ZERO, W}:
        return False
    if mode == "shifted_pairing" and "v" not in free_variables(body):
        return False
    return normalize_old(body, mode) == body


def pairing(a: int, n: int) -> int:
    total = a + n
    return total * (total + 1) // 2 + n


def unpair(z: int) -> tuple[int, int]:
    total = (isqrt(8 * z + 1) - 1) // 2
    n = z - total * (total + 1) // 2
    return total - n, n


def evaluate(term: Term, env: dict[str, int]) -> int:
    """Standard-N examples, not a nonstandard-model verification."""
    if term.op == "var":
        return env[term.name]
    if term.op == "0":
        return 0
    args = tuple(evaluate(a, env) for a in term.args)
    if term.op == "S":
        return args[0] + 1
    if term.op == "p":
        return max(0, args[0] - 1)
    if term.op == "B":
        return pairing(*args)
    if term.op == "U":
        a, n = args
        return pairing(n, 0) if a == 0 else pairing(a - 1, n)
    if term.op == "L":
        return unpair(args[0])[0]
    if term.op == "R":
        return unpair(args[0])[1]
    if term.op == "rec":
        n, state, *params = args
        base = dict(zip(term.label.parameters, params))
        for counter in range(n):
            local = {**base, "v": state, "w": counter}
            state = evaluate(term.label.body, local)
        return state
    raise ValueError(f"Cannot numerically evaluate logical node {term.op}")


def eq(left: Term, right: Term) -> Term:
    return op("eq", left, right)


def all_(name: str, formula: Term) -> Term:
    # Each binder is one node; the annotation is not charged as a second leaf.
    return Term("all", (formula,), name=name)


def some(name: str, formula: Term) -> Term:
    return Term("exists", (formula,), name=name)


def active_labels(term: Term) -> dict[str, Label]:
    result = {term.label.name: term.label} if term.op == "rec" else {}
    for arg in term.args:
        result.update(active_labels(arg))
    return result


def erase(term: Term, erased_names: set[str]) -> Term:
    """Homomorphic active erasure; all surviving label objects stay frozen."""
    if term.op == "rec" and term.label.name in erased_names:
        return erase(term.args[1], erased_names)
    return Term(term.op, tuple(erase(a, erased_names) for a in term.args),
                term.name, term.label)


def sample_packet(label: Label) -> list[Term]:
    a, n, x, b, t = map(var, ("a", "n", "x", "b", "t"))
    base = all_("a", eq(call(label, ZERO, a), a))
    step = all_("a", all_("n", eq(
        call(label, op("S", n), a),
        instantiate(label, call(label, n, a), n, ()),
    )))
    ex = eq(call(label, x, a), a)
    boundary = all_("a", all_("t", some("b", all_("x", op(
        "K4", eq(op("S", x), b), ex, eq(x, b), eq(b, t),
    )))))
    # Retained label contains an erased function in its FROZEN source metadata.
    # The active interpretation leaves that complete code byte-for-byte intact.
    keeper = Label("keep_" + label.name, op("S", call(label, W, V)))
    metadata_example = all_("a", all_("n", eq(
        call(keeper, n, a), call(keeper, n, a),
    )))
    return [base, step, boundary, metadata_example]


def run_checks() -> dict:
    contextual_rows = []
    absorbing_rows = []
    samples: list[Label] = []
    semantic_checks = 0

    # Active substitution must not alter either descriptor variable or label.
    frozen_test = call(A, V, W)
    changed = substitute(frozen_test, {"v": ZERO, "w": numeral(2)})
    assert changed.label is A and changed.label.body == op("S", V)
    assert changed.args == (ZERO, numeral(2))
    assert free_variables(changed) == set()
    assert size(changed) == 1 + 2 + 1 + 3

    for mode, d in MODES.items():
        for j in range(2, 9):
            inner = call(A, numeral(j), V)
            old_step_rhs = op("S", call(A, numeral(j - 1), V))
            assert size(inner) == size(old_step_rhs) == j + 5
            body = inner
            for _ in range(j):
                body = predecessor(body, mode)
            expected_h = (d + 1) * j + 5
            assert size(body) == expected_h
            assert old_grammar_admits(body, mode)
            assert normalize_old(body, mode) == body
            assert normalize_new(body, mode) == V
            label = Label(f"context_{mode}_{j}", body)
            call_size = size(call(label, var("n"), var("a")))
            assert call_size == expected_h + 3
            contextual_rows.append({
                "mode": mode, "j": j, "D_overhead": d,
                "body_size": expected_h, "old_step_ties": True,
                "identity_call_size": call_size,
                "erasure_saving": expected_h + 2,
                "old_body_unchanged": True, "new_body": "v",
            })
            samples.append(label)
            for v in range(6):
                for w in range(3):
                    assert evaluate(body, {"v": v, "w": w}) == v
                    semantic_checks += 1

    g = V
    for j in range(1, 8):
        g = call(A, g, g)
        g_label = Label(f"g_{j}", g)
        k = call(A, call(g_label, W, ZERO), V)
        h_g, h_k = 4 * 2**j - 3, 4 * 2**j + 4
        assert size(g) == h_g and size(k) == h_k
        for mode in MODES:
            assert old_grammar_admits(g, mode)
            assert old_grammar_admits(k, mode)
            assert normalize_old(g, mode) == g
            assert normalize_old(k, mode) == k
            side = instantiate(g_label, ZERO, var("fresh_counter"), ())
            assert normalize_old(side, mode) == ZERO
            assert normalize_new(k, mode) == V
        k_label = Label(f"absorb_k_{j}", k)
        samples.append(k_label)
        absorbing_rows.append({
            "j": j, "g_size": h_g, "k_size": h_k,
            "identity_call_size": h_k + 3,
            "erasure_saving": h_k + 2,
            "old_bodies_unchanged_in_all_modes": True,
            "old_side_checker_result": "0", "new_k_body": "v",
        })
        for v in range(5):
            assert evaluate(g, {"v": v, "w": 0}) == 2**j * v
            semantic_checks += 1
            for w in range(4):
                assert evaluate(k, {"v": v, "w": w}) == v
                semantic_checks += 1
        for n in range(4):
            for a in range(4):
                assert evaluate(call(k_label, numeral(n), numeral(a)), {}) == a
                semantic_checks += 1

    packet_rows = []
    retained_metadata_checks = 0
    for label in samples:
        original = sample_packet(label)
        image = [erase(formula, {label.name}) for formula in original]
        before = sum(map(size, original)) + 15  # unchanged paid K4 definition
        after = sum(map(size, image)) + 15
        assert after < before
        for old_formula, new_formula in zip(original, image):
            assert size(new_formula) <= size(old_formula)
            old_labels = active_labels(old_formula)
            for name, surviving in active_labels(new_formula).items():
                assert surviving is old_labels[name]
                assert surviving.body == old_labels[name].body
                retained_metadata_checks += 1
        # The keeper's full label still contains the source identity label.
        kept = active_labels(image[-1])["keep_" + label.name]
        assert label.name in active_labels(kept.body)
        assert size(original[-1]) == size(image[-1])
        packet_rows.append({"identity_label": label.name,
                            "before_with_K4_record": before,
                            "after_with_K4_record": after,
                            "saving": before - after})

    return {
        "status": "passed",
        "scope": (
            "Exact finite syntax and bounded standard-N examples only; "
            "not a formalization of induction, infinite schemas, "
            "bi-interpretability, or arbitrary proof-length bounds."
        ),
        "counting": (
            "One node per active application/variable/constant/logical "
            "symbol/binder, plus the entire frozen label body at every "
            "recursor occurrence. Binder annotations are not extra nodes."
        ),
        "baseline_snapshot": "62494ae438e7518d7d9d3b923b506d2223672cdc",
        "old_rule_model_scope": (
            "Rules with heads occurring in these explicit families; not a "
            "complete implementation of every source optimization. The paper "
            "also checks that the remaining old heads cannot match."
        ),
        "fresh_substitution_preserves_frozen_label": True,
        "absorbing_side_checker": "old normalizer only; no recursive new-rule test",
        "contextual_family": contextual_rows,
        "absorbing_family": absorbing_rows,
        "bounded_semantic_equalities_checked": semantic_checks,
        "sample_axiom_packets": packet_rows,
        "sample_packet_count": len(packet_rows),
        "retained_frozen_label_checks": retained_metadata_checks,
        "nonincrease_claim": "sample axiom-formula packets, not arbitrary proof lengths",
    }


if __name__ == "__main__":
    print(json.dumps(run_checks(), indent=2, sort_keys=True))
