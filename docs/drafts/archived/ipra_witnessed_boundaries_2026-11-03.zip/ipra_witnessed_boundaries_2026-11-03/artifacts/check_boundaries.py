#!/usr/bin/env python3
"""Finite AST and bounded-scan checks for witnessed-boundary iPRA.

Standard library only. Run without arguments for JSON on stdout, or pass
--output PATH to write exactly that JSON file. No other files are written.

These checks validate finite syntax/accounting and all finite truth tables
through the stated horizon. They are not a proof-assistant formalization of
the infinite interpretation theorem. Frozen recursor descriptions are charged
at every occurrence, but active substitution never enters a description.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


SOURCE_COMMIT = "62494ae438e7518d7d9d3b923b506d2223672cdc"


@dataclass(frozen=True)
class Term:
    tag: str
    name: str = ""
    arguments: tuple[Term, ...] = ()
    description: Term | None = None
    parameter_arity: int = 0


@dataclass(frozen=True)
class Formula:
    tag: str
    formulas: tuple[Formula, ...] = ()
    terms: tuple[Term, ...] = ()
    binder: str = ""
    name: str = ""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def var(name: str) -> Term:
    return Term("variable", name=name)


ZERO = Term("constant", name="0")


def app(name: str, *arguments: Term) -> Term:
    return Term("application", name=name, arguments=arguments)


def succ(term: Term) -> Term:
    return app("S", term)


def rec(description: Term, counter: Term, initial: Term,
        *parameters: Term) -> Term:
    return Term("recursor", arguments=(counter, initial, *parameters),
                description=description, parameter_arity=len(parameters))


def eq(left: Term, right: Term) -> Formula:
    return Formula("equality", terms=(left, right))


def binary(tag: str, left: Formula, right: Formula) -> Formula:
    return Formula(tag, formulas=(left, right))


def conjunction(left: Formula, right: Formula) -> Formula:
    return binary("and", left, right)


def disjunction(left: Formula, right: Formula) -> Formula:
    return binary("or", left, right)


def implication(left: Formula, right: Formula) -> Formula:
    return binary("implies", left, right)


def forall(name: str, body: Formula) -> Formula:
    return Formula("forall", formulas=(body,), binder=name)


def exists(name: str, body: Formula) -> Formula:
    return Formula("exists", formulas=(body,), binder=name)


def universal_prefix(names: tuple[str, ...], body: Formula) -> Formula:
    for name in reversed(names):
        body = forall(name, body)
    return body


def j_call(bound: str, antecedent: Formula, predecessor: Formula,
           predicate: Formula, value: Term, conclusion: Formula) -> Formula:
    """bound binds only predecessor and predicate, never the other slots."""
    return Formula("J", formulas=(antecedent, predecessor, predicate,
                                  conclusion), terms=(value,), binder=bound)


def term_size(term: Term) -> int:
    return (1 + sum(term_size(arg) for arg in term.arguments)
            + (term_size(term.description) if term.description else 0))


def formula_size(formula: Formula) -> int:
    # A definition record is an AST node too: its root is the paid marker.
    # A J call stores its concrete B and P trees exactly once each.
    return (1 + sum(formula_size(child) for child in formula.formulas)
            + sum(term_size(term) for term in formula.terms))


def free_term_variables(term: Term) -> set[str]:
    if term.tag == "variable":
        return {term.name}
    result: set[str] = set()
    for argument in term.arguments:
        result.update(free_term_variables(argument))
    return result  # The description has its own frozen formal slots.


def free_formula_variables(formula: Formula) -> set[str]:
    if formula.tag == "J":
        a, b, p, c = formula.formulas
        return (free_formula_variables(a)
                | ((free_formula_variables(b) | free_formula_variables(p))
                   - {formula.binder})
                | free_term_variables(formula.terms[0])
                | free_formula_variables(c))
    result: set[str] = set()
    for child in formula.formulas:
        result.update(free_formula_variables(child))
    for term in formula.terms:
        result.update(free_term_variables(term))
    if formula.tag in {"forall", "exists"}:
        result.discard(formula.binder)
    return result


def all_formula_variable_names(formula: Formula) -> set[str]:
    result = {formula.binder} if formula.binder else set()
    for child in formula.formulas:
        result.update(all_formula_variable_names(child))
    for term in formula.terms:
        result.update(free_term_variables(term))
    return result


def substitute_term(term: Term, replacement: Mapping[str, Term]) -> Term:
    """Simultaneous active substitution; replacement terms are not resubstituted."""
    if term.tag == "variable":
        return replacement.get(term.name, term)
    return Term(term.tag, name=term.name,
                arguments=tuple(substitute_term(a, replacement)
                                for a in term.arguments),
                description=term.description,
                parameter_arity=term.parameter_arity)


def fresh_name(base: str, avoid: set[str]) -> str:
    index = 0
    while f"{base}_{index}" in avoid:
        index += 1
    return f"{base}_{index}"


def substitute_formula(formula: Formula,
                       replacement: Mapping[str, Term]) -> Formula:
    """Capture-avoiding simultaneous substitution, respecting J's partial scope."""
    if formula.tag in {"forall", "exists", "J"}:
        bound = formula.binder
        effective = {name: value for name, value in replacement.items()
                     if name != bound}
        replacement_free: set[str] = set()
        for value in effective.values():
            replacement_free.update(free_term_variables(value))
        scoped = (formula.formulas[1:3] if formula.tag == "J"
                  else formula.formulas)
        if bound in replacement_free:
            avoid = (all_formula_variable_names(formula)
                     | set(replacement) | replacement_free)
            renamed = fresh_name(bound, avoid)
            scoped = tuple(substitute_formula(child, {bound: var(renamed)})
                           for child in scoped)
            bound = renamed
        scoped = tuple(substitute_formula(child, effective) for child in scoped)
        if formula.tag == "J":
            a, _, _, c = formula.formulas
            return j_call(
                bound, substitute_formula(a, replacement), scoped[0], scoped[1],
                substitute_term(formula.terms[0], replacement),
                substitute_formula(c, replacement))
        return Formula(formula.tag, formulas=scoped, binder=bound)
    return Formula(
        formula.tag,
        formulas=tuple(substitute_formula(child, replacement)
                       for child in formula.formulas),
        terms=tuple(substitute_term(term, replacement) for term in formula.terms),
        binder=formula.binder, name=formula.name)


def expand(formula: Formula) -> Formula:
    """Expand K3, K4 and J into ordinary first-order intuitionistic syntax."""
    children = tuple(expand(child) for child in formula.formulas)
    if formula.tag == "K3":
        a, b, c = children
        return conjunction(implication(a, b), implication(b, c))
    if formula.tag == "K4":
        a, b, c, d = children
        return conjunction(implication(a, b), implication(b, implication(c, d)))
    if formula.tag == "J":
        a, b, p, c = children
        instantiated = substitute_formula(p, {formula.binder: formula.terms[0]})
        return conjunction(
            disjunction(a, exists(formula.binder, conjunction(b, p))),
            implication(instantiated, c))
    return Formula(formula.tag, formulas=children, terms=formula.terms,
                   binder=formula.binder, name=formula.name)


def term_alpha_key(term: Term, environment: tuple[str, ...] = ()) -> tuple:
    if term.tag == "variable":
        if term.name in environment:
            return ("bound", environment[::-1].index(term.name))
        return ("free", term.name)
    frozen = (term_alpha_key(term.description, ()) if term.description else None)
    return (term.tag, term.name, term.parameter_arity, frozen,
            tuple(term_alpha_key(a, environment) for a in term.arguments))


def formula_alpha_key(formula: Formula,
                      environment: tuple[str, ...] = ()) -> tuple:
    if formula.tag == "J":
        a, b, p, c = formula.formulas
        local = environment + (formula.binder,)
        return ("J", formula_alpha_key(a, environment),
                formula_alpha_key(b, local), formula_alpha_key(p, local),
                term_alpha_key(formula.terms[0], environment),
                formula_alpha_key(c, environment))
    local = (environment + (formula.binder,)
             if formula.tag in {"forall", "exists"} else environment)
    return (formula.tag, formula.name,
            tuple(formula_alpha_key(child, local) for child in formula.formulas),
            tuple(term_alpha_key(term, local) for term in formula.terms))


def alpha_equal(left: Formula, right: Formula) -> bool:
    return formula_alpha_key(left) == formula_alpha_key(right)


def active_occurrences(term: Term, name: str) -> int:
    if term.tag == "variable":
        return int(term.name == name)
    return sum(active_occurrences(arg, name) for arg in term.arguments)


def fixed_counts() -> dict:
    x, y, z = (var(name) for name in ("x", "y", "z"))
    separation = implication(eq(ZERO, succ(ZERO)), Formula("bottom"))
    coverage = forall("z", exists("y", disjunction(eq(z, ZERO), eq(z, succ(y)))))
    p_zero = eq(app("p", ZERO), ZERO)
    p_successor = forall("x", eq(app("p", succ(x)), x))
    a, b, c, d = (Formula("formula_metavariable", name=name)
                  for name in ("A", "B", "C", "D"))
    k3 = Formula("K3", formulas=(a, b, c))
    k4 = Formula("K4", formulas=(a, b, c, d))
    j = j_call("x", a, Formula("predicate_metavariable", terms=(x,), name="B"),
               Formula("predicate_metavariable", terms=(x,), name="P"),
               var("v"), c)

    def record(call: Formula) -> dict:
        rhs = expand(call)
        definition = Formula("definition", formulas=(call, rhs))
        return {"left": formula_size(call), "right": formula_size(rhs),
                "marker": 1, "total": formula_size(definition)}

    result = {
        "separation": formula_size(separation),
        "old_coverage": formula_size(coverage),
        "native_predecessor_equations": [formula_size(p_zero),
                                         formula_size(p_successor)],
        "native_predecessor_packet": formula_size(p_zero) + formula_size(p_successor),
        "K3_definition": record(k3), "K4_definition": record(k4),
        "J_definition": record(j),
    }
    require(result["separation"] == 6, "Sep must have size 6")
    require(result["old_coverage"] == 10, "Cov must have size 10")
    require(result["native_predecessor_packet"] == 10, "Predecessor packet must cost 10")
    require(result["K3_definition"] == {"left": 4, "right": 7, "marker": 1,
                                       "total": 12}, "K3 record mismatch")
    require(result["K4_definition"] == {"left": 5, "right": 9, "marker": 1,
                                       "total": 15}, "K4 record mismatch")
    require(result["J_definition"] == {"left": 8, "right": 13, "marker": 1,
                                      "total": 22}, "J record mismatch")
    return result


def ordinary_module(body: Term, parameter_names: tuple[str, ...]) -> Formula:
    a, n = var("a"), var("n")
    parameters = tuple(var(name) for name in parameter_names)
    previous = rec(body, n, a, *parameters)
    step = substitute_term(body, {"v": previous, "w": n})
    equations = conjunction(
        eq(rec(body, ZERO, a, *parameters), a),
        forall("n", eq(rec(body, succ(n), a, *parameters), step)))
    return universal_prefix(("a", *parameter_names), equations)


def new_boundary(predicate: Formula, parameters: tuple[str, ...]) -> Formula:
    x, b, t = var("x"), var("b"), var("t")
    matrix = j_call("x", eq(b, ZERO), eq(succ(x), b), predicate, b, eq(b, t))
    return universal_prefix(("t", *parameters), exists("b", matrix))


def old_boundary(predicate: Formula, parameters: tuple[str, ...]) -> Formula:
    x, b, t = var("x"), var("b"), var("t")
    matrix = Formula("K4", formulas=(eq(succ(x), b), predicate,
                                      eq(x, b), eq(b, t)))
    return universal_prefix(("t", *parameters), exists("b", forall("x", matrix)))


def sample_bodies(parameter_count: int) -> tuple[Term, ...]:
    v, w = var("v"), var("w")
    add = lambda n, a: rec(succ(v), n, a)
    counter = lambda n, a: rec(w, n, a)
    bodies = [ZERO, v, w, succ(v), succ(w), succ(succ(v)),
              add(w, v), add(v, w), add(v, v), add(succ(w), v),
              succ(add(w, v)), add(w, add(v, w)),
              rec(add(w, v), w, v), counter(add(w, v), succ(v)),
              counter(v, add(w, v)), add(add(v, v), add(w, w))]
    for index in range(1, parameter_count + 1):
        c = var(f"c{index}")
        bodies.extend([c, add(c, v), add(w, c), succ(add(v, c)),
                       rec(var("c1"), w, v, c)])
    carried = v
    for index in range(1, parameter_count + 1):
        carried = add(var(f"c{index}"), carried)
    bodies.append(carried)
    return tuple(dict.fromkeys(bodies))


def check_schema_counts() -> dict:
    rows = []
    x, t = var("x"), var("t")
    v = var("v")
    for m in range(5):
        parameters = tuple(f"c{i}" for i in range(1, m + 1))
        bodies = sample_bodies(m)
        for index, body in enumerate(bodies):
            h = term_size(body)
            k = active_occurrences(body, "v")
            expected_module = 3 * h + 3 * m + 13 + k * (h + m + 2)
            actual_module = formula_size(ordinary_module(body, parameters))
            require(actual_module == expected_module,
                    f"Ordinary module mismatch at m={m}, body={index}")
            # The extra addition call guarantees an active x even for body=0.
            active_body = substitute_term(body, {"v": x, "w": t})
            predicate = eq(rec(succ(v), x, active_body), t)
            matrix_size = formula_size(predicate)
            new = new_boundary(predicate, parameters)
            old = old_boundary(predicate, parameters)
            require(formula_size(new) == matrix_size + m + 14,
                    "Compressed J boundary size mismatch")
            require(formula_size(old) == matrix_size + m + 14,
                    "Compressed old K4 boundary size mismatch")
            expected_expansion = 2 * matrix_size + m + 17
            require(formula_size(expand(new)) == expected_expansion,
                    "Expanded witnessed boundary size mismatch")
            require(formula_size(expand(old)) == expected_expansion,
                    "Expanded old boundary size mismatch")
            require(free_formula_variables(new) == free_formula_variables(expand(new)),
                    "J expansion changed free variables")
        rows.append({"parameter_count": m, "descriptors": len(bodies)})
    total = sum(row["descriptors"] for row in rows)
    return {
        "by_parameter_count": rows, "ordinary_modules": total,
        "new_compressed_boundaries": total, "old_compressed_boundaries": total,
        "new_expanded_boundaries": total, "old_expanded_boundaries": total,
        "ordinary_module_formula": "3H + 3m + 13 + k(H+m+2)",
        "compressed_boundary_formula": "F + m + 14",
        "both_expanded_boundary_formula": "2F + m + 17",
        "note": "H is update-body size; F is the actual atomic equation size.",
    }


def check_capture_and_frozen_scope() -> dict:
    x, y, z, a = (var(name) for name in ("x", "y", "z", "a"))
    nested = forall("y", implication(eq(x, y), exists("x", eq(y, x))))
    expected = forall("r", implication(eq(y, var("r")),
                                        exists("x", eq(var("r"), x))))
    instantiated = substitute_formula(nested, {"x": y})
    require(alpha_equal(instantiated, expected), "Nested binder capture")
    require(free_formula_variables(instantiated) == {"y"},
            "Inserted y was captured by a nested binder")

    inner_description = succ(var("v"))
    outer_description = rec(inner_description, var("w"), var("v"))
    frozen_term = rec(outer_description, x, a)
    changed = substitute_term(frozen_term, {"x": var("v"), "a": succ(var("w")),
                                            "v": ZERO, "w": ZERO})
    require(changed.description is outer_description, "Frozen outer body changed")
    require(changed.description.description is inner_description,
            "Nested frozen body changed")
    require(changed.arguments == (var("v"), succ(var("w"))),
            "Substitution was not simultaneous")
    require(free_term_variables(frozen_term) == {"x", "a"},
            "Frozen slots leaked into free-variable calculation")

    partial_scope = j_call("x", eq(x, y), eq(succ(x), z), nested, y, eq(x, y))
    require(free_formula_variables(partial_scope) == {"x", "y", "z"},
            "J binder captured an unscoped slot")
    nested_j = j_call(
        "y", eq(x, y), eq(y, z),
        j_call("x", eq(y, z), eq(x, y), exists("z", eq(x, z)), y, eq(x, y)),
        x, eq(y, x))
    frozen_formula = forall("v", eq(frozen_term, var("v")))
    cases = [partial_scope, nested_j, forall("y", partial_scope),
             exists("x", nested_j), frozen_formula,
             j_call("x", eq(x, ZERO), eq(succ(x), z),
                    forall("y", eq(x, y)), y, eq(x, z))]
    substitutions = [{"x": y}, {"y": x}, {"x": z, "y": x},
                     {"z": y, "a": x}, {"x": succ(y), "y": succ(z)},
                     {"v": x, "a": var("v"), "x": a}, {}]
    commutation_checks = 0
    for case in cases:
        require(free_formula_variables(case) == free_formula_variables(expand(case)),
                "Expansion changed a free-variable set")
        for replacement in substitutions:
            left = expand(substitute_formula(case, replacement))
            right = substitute_formula(expand(case), replacement)
            require(alpha_equal(left, right),
                    "Capture-avoiding expansion/substitution commutation failed")
            commutation_checks += 1
    return {
        "nested_binder_instantiation": "passed",
        "J_partial_scope": "passed", "frozen_description_identity": "passed",
        "nested_frozen_description_identity": "passed",
        "simultaneous_active_substitution": "passed",
        "expansion_substitution_commutation_checks": commutation_checks,
        "comparison": "alpha-equivalence with binder-aware structural keys",
    }


def check_scan(max_horizon: int) -> dict:
    vectors = states = updates = witness_checks = probe_valuations = 0
    rows = []
    for target in range(max_horizon + 1):
        row_vectors = 0
        for bits in range(1 << (target + 1)):
            truth = tuple(bool((bits >> position) & 1)
                          for position in range(target + 1))
            d = 0
            for n in range(target + 1):
                require(0 <= d <= n, "Scan escaped its current horizon")
                predecessor = max(d - 1, 0)
                first = (d == 0 or
                         (predecessor + 1 == d and truth[predecessor]))
                second = not truth[d] or d == n
                require(first, "First quantifier-free scan invariant failed")
                require(second, "Second quantifier-free scan invariant failed")
                states += 1
                if n < target:
                    d = n + 1 if truth[d] else d
                    updates += 1
            # One witness is selected here, before any universal probe.
            witness = d
            predecessor = max(witness - 1, 0)
            require(witness == 0 or
                    (predecessor + 1 == witness and truth[predecessor]),
                    "Witnessed-boundary predecessor clause failed")
            require(not truth[witness] or witness == target,
                    "Witnessed-boundary endpoint clause failed")
            witness_checks += 2
            for probe in range(target + 2):
                # All possible truth values at the one out-of-horizon probe.
                # Every larger probe is also distinct from witness and has
                # successor distinct from witness because witness <= target.
                possible_values = ((truth[probe],) if probe <= target
                                   else (False, True))
                for holds in possible_values:
                    require(probe + 1 != witness or holds,
                            "Old boundary predecessor implication failed")
                    require(not holds or probe != witness or witness == target,
                            "Old boundary endpoint implication failed")
                    probe_valuations += 1
            vectors += 1
            row_vectors += 1
        rows.append({"target": target, "truth_vectors": row_vectors})
    return {
        "max_horizon": max_horizon, "truth_vectors": vectors,
        "scan_states": states, "quantifier_free_invariant_checks": 2 * states,
        "scan_updates": updates, "witnessed_boundary_clause_checks": witness_checks,
        "old_boundary_probe_valuations": probe_valuations,
        "old_boundary_implication_checks": 2 * probe_valuations,
        "by_target": rows,
        "first_invariant": "d_n=0 or (S(p(d_n))=d_n and E(p(d_n)))",
        "second_invariant": "E(d_n) implies d_n=n",
        "witness": "b=d_t, selected once before all probes",
        "probe_scope": ("All 0<=x<=t, and x=t+1 with both truth values; "
                        "larger x are algebraically vacuous since b<=t."),
        "limit": "Finite exhaustive diagnostic; not an internal formal proof.",
    }


def run(max_horizon: int = 12) -> dict:
    require(max_horizon >= 0, "The horizon must be nonnegative")
    return {
        "status": "passed", "artifact": "check_boundaries.py",
        "source_commit": SOURCE_COMMIT,
        "counting_convention": {
            "node_cost": 1, "binder_annotation_extra_cost": 0,
            "frozen_descriptions": "fully charged at each recursor application",
            "active_substitution": "simultaneous and frozen-description preserving",
            "J_binder_scope": "B and P only; A, value and C are outside its scope",
        },
        "fixed_counts": fixed_counts(), "schema_counts": check_schema_counts(),
        "capture_and_frozen_scope": check_capture_and_frozen_scope(),
        "scan": check_scan(max_horizon),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write JSON to this path instead of stdout")
    parser.add_argument("--max-horizon", type=int, default=12,
                        help="Maximum exhaustive truth-table horizon (default: 12)")
    arguments = parser.parse_args()
    output = json.dumps(run(arguments.max_horizon), indent=2, sort_keys=True) + "\n"
    if arguments.output is None:
        print(output, end="")
    else:
        arguments.output.write_text(output, encoding="utf-8")


if __name__ == "__main__":
    main()
