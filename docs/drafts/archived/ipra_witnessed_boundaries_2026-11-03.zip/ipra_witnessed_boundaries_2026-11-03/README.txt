WITNESSED-BOUNDARY AXIOMATIZATIONS OF INTUITIONISTIC PRA
3 November 2026
=====================================================

Start with report.pdf. Its complete source is report.tex.
AXIOMS.txt is a standalone exact specification of the arithmetic theory,
the optional logical binder, and the reference signature refinements.

The report establishes:
  * A one-fixed-sentence, two-schema presentation of full first-order iPRA.
  * Both internally proved identity composites and equiconsistency.
  * Removal of the separate coverage axiom without increasing the
    ordinary-logic boundary size.
  * A generic paid formula binder: fixed record28 versus old31,
    with the same elementary boundary size.
  * Two certified simplifications missed by all three active drafts.
  * Source-wise bi-interpretable images with nonincreasing finite axiom
    packets and unbounded strict savings for explicit families.

Important distinctions are part of the result:
  * The fixed prefix is not the size of the infinite theory.
  * The new complete constructor bootstrap can be larger.
  * Axiom-packet nonincrease is not a theorem of proof-length nonincrease.
  * The finite Python checks are diagnostics, not a proof-assistant
    verification of the infinite interpretation theorem.
  * No absolute minimum over all logical languages or encodings is proved.

Contents
--------
report.tex, report.pdf                  Full mathematical report
AXIOMS.txt                             Exact standalone specification
artifacts/check_boundaries.py          Syntax, binder, scope and scan checks
artifacts/boundary_results.json         Reproducible results
artifacts/check_normalization.py       Two new reductions and exact counts
artifacts/normalization_results.json   Reproducible results
artifacts/verification_summary.txt     Human-readable verification scope
provenance/source_manifest.json        Pinned repository and eight archives
build.py                               Rebuild, check, checksum and package
SHA256SUMS.txt                          Checksums of delivered files

Rebuild
-------
Python 3.10+ is sufficient for the checking programs; no Python packages
are required. The PDF uses pdflatex and the packages listed in report.tex.

  python3 build.py

This runs both checking programs, compiles the paper twice, copies the
finished PDF to report.pdf, and refreshes SHA256SUMS.txt. The intermediate
TeX files stay under build/.

To rerun only the finite diagnostics:

  python3 build.py --checks-only

To also create a ZIP alongside this directory:

  python3 build.py --archive

Individual programs print JSON on stdout. check_boundaries.py also accepts
--output PATH. Numerical tests are deterministic.

Source snapshot
---------------
https://github.com/VladimirReshetnikov/ProveIt
62494ae438e7518d7d9d3b923b506d2223672cdc

All three active drafts at that snapshot improve on some component of
the five archived predecessors and are retained in the audit.
The source archive manifest makes this comparison reproducible.
