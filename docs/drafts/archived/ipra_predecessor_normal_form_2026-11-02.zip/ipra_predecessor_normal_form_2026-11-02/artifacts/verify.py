#!/usr/bin/env python3
"""Reproducible syntax and finite-semantic checks for the iPRA refinement.

Python 3 standard library only. Run from any directory; outputs are written
beside this file. This is NOT a proof assistant certificate. General
intuitionistic soundness and the interpretation theorem are proved in the
accompanying paper, not inferred from these finite checks.

Each recursor occurrence charges its full, frozen descriptor recursively.
Active substitution and active-occurrence counts NEVER enter descriptors.
Q and Z below are literal R_w and R_0, not free primitive abbreviations.
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple[Term, ...] = ()
    name: str = ""
    descriptor: Term | None = None


def V(name: str) -> Term:
    return Term("var", name=name)


O = Term("zero")


def S(t: Term) -> Term:
    return Term("succ", (t,))


def R(h: Term, n: Term, a: Term) -> Term:
    return Term("rec", (n, a), descriptor=h)


def term_size(t: Term) -> int:
    if t.kind in ("var", "zero"):
        return 1
    if t.kind == "succ":
        return 1 + term_size(t.args[0])
    assert t.kind == "rec" and t.descriptor is not None
    return 1 + term_size(t.descriptor) + sum(map(term_size, t.args))


def active_count(t: Term, variable: str) -> int:
    if t.kind == "var":
        return int(t.name == variable)
    return sum(active_count(u, variable) for u in t.args)


def active_vars(t: Term) -> set[str]:
    if t.kind == "var":
        return {t.name}
    return set().union(*(active_vars(u) for u in t.args)) if t.args else set()


def subst(t: Term, replacements: Mapping[str, Term]) -> Term:
    """Simultaneous, active substitution; stored descriptors stay frozen."""
    if t.kind == "var":
        return replacements.get(t.name, t)
    if t.kind == "zero":
        return t
    return Term(t.kind, tuple(subst(u, replacements) for u in t.args),
                descriptor=t.descriptor)


def body(h: Term, state: Term, counter: Term) -> Term:
    return subst(h, {"v": state, "w": counter})


def Q(n: Term, a: Term) -> Term:
    return R(V("w"), n, a)


def Z(n: Term, a: Term) -> Term:
    return R(O, n, a)


def pred(n: Term) -> Term:
    return Q(n, O)


def choose(n: Term, a: Term, b: Term) -> Term:
    return Q(Z(n, S(a)), b)


def zero_normal(t: Term) -> Term:
    """Only active R_h(0,u) -> u; structural, total, and size-decreasing."""
    if t.kind in ("var", "zero"):
        return t
    if t.kind == "succ":
        return S(zero_normal(t.args[0]))
    assert t.kind == "rec" and t.descriptor is not None
    n, a = map(zero_normal, t.args)
    return a if n == O else R(t.descriptor, n, a)


def under_recursor(t: Term, variable: str, inside: bool = False) -> bool:
    if t.kind == "var":
        return inside and t.name == variable
    return any(under_recursor(u, variable, inside or t.kind == "rec")
               for u in t.args)


def constructor_clash(left: Term, right: Term) -> bool:
    while left.kind == right.kind == "succ":
        left, right = left.args[0], right.args[0]
    return (left == O and right.kind == "succ") or (
        right == O and left.kind == "succ")


def is_computation_equation(left: Term, right: Term) -> bool:
    """An exact defining equation, allowing active zero normalization."""
    for lhs, rhs in ((left, right), (right, left)):
        if lhs.kind != "rec":
            continue
        assert lhs.descriptor is not None
        n, a = lhs.args
        if n == O:
            expected = a
        elif n.kind == "succ":
            m = n.args[0]
            expected = body(lhs.descriptor, R(lhs.descriptor, m, a), m)
        else:
            continue
        if zero_normal(rhs) == zero_normal(expected):
            return True
    return False


def boundary_status(left: Term, right: Term) -> dict[str, object]:
    """A finite syntactic test; never tests truth, theoremhood, or extensionality.

    Both original and normalized equations are inspected for a defining
    equation. Normalization may either obscure a base-case recursor head or
    expose a defining step beneath an active zero call. A non-normal
    requested equation is represented by its normal form.
    """
    if (active_vars(left) | active_vars(right)) - {"x", "a"}:
        raise ValueError("Boundary matrix has an unauthorized active variable")
    computation = is_computation_equation(left, right)
    lnorm, rnorm = zero_normal(left), zero_normal(right)
    computation = computation or is_computation_equation(lnorm, rnorm)
    normalized = (lnorm, rnorm) != (left, right)
    if lnorm == rnorm:
        reason = "normal_reflexive"
    elif not (under_recursor(lnorm, "x") or under_recursor(rnorm, "x")):
        reason = "no_x_under_recursor"
    elif constructor_clash(
        zero_normal(subst(lnorm, {"x": O})),
        zero_normal(subst(rnorm, {"x": O})),
    ):
        reason = "constructor_clash_at_base"
    elif computation:
        reason = "defining_computation_equation"
    else:
        reason = "retained"
    f_original = 1 + term_size(left) + term_size(right)
    f_normal = 1 + term_size(lnorm) + term_size(rnorm)
    return {
        "reason": reason,
        "omitted": reason != "retained",
        "normalized": normalized,
        "original_F": f_original,
        "normal_F": f_normal,
        "normal_active_x": active_count(lnorm, "x") + active_count(rnorm, "x"),
        "old_unpruned_K_boundary": f_original + 16,
        "new_K_boundary": 0 if reason != "retained" else f_normal + 16,
        "new_J_boundary": 0 if reason != "retained" else f_normal + 18,
    }


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple[Formula, ...] = ()
    terms: tuple[Term, ...] = ()
    binder: str = ""


def Eq(t: Term, u: Term) -> Formula:
    return Formula("eq", terms=(t, u))


def F(kind: str, *args: Formula) -> Formula:
    return Formula(kind, args)


BOTTOM = F("bottom")


def Forall(names: str, phi: Formula) -> Formula:
    for name in reversed(names.split()):
        phi = Formula("forall", (phi,), binder=name)
    return phi


def Exists(names: str, phi: Formula) -> Formula:
    for name in reversed(names.split()):
        phi = Formula("exists", (phi,), binder=name)
    return phi


def formula_size(phi: Formula) -> int:
    return 1 + sum(map(formula_size, phi.args)) + sum(map(term_size, phi.terms))


def module_formulas(h: Term) -> dict[str, tuple[Formula, ...]]:
    a, n, u, x, y, z = map(V, ("a", "n", "u", "x", "y", "z"))
    rn, rs, graph = R(h, n, a), R(h, S(n), a), Eq(R(h, x, a), y)
    initial = F("imp", Eq(n, O), Eq(u, a))
    near = F("and", Eq(x, n), Eq(y, u))
    step = F("imp", Eq(x, S(n)), Eq(y, body(h, u, n)))
    modules = {
        "D": (Forall("a", Eq(R(h, O, a), a)),
              Forall("a n", Eq(rs, body(h, rn, n)))),
        "G_K": (Forall("a n u", F("K", F("and", Eq(n, O), Eq(u, a)),
                                             Eq(rn, u), Eq(rs, body(h, u, n)))),),
        "G_plain": (Forall("a n u", F("imp", Eq(rn, u),
                         F("and", initial, Eq(rs, body(h, u, n))))),),
        "T_K": (Forall("a n", Exists("u", F("and", initial,
                        Forall("x y", F("K", near, graph, step))))),),
        "W_J": (Forall("a n", Exists("u", Forall("x y",
                        F("J", graph, initial,
                          F("J", Eq(x, n), step, Eq(y, u)))))),),
        "M_KJ": (Forall("a n", Exists("u", Forall("x y",
                         F("K", near, graph,
                           F("J", Eq(x, O), step, Eq(y, a)))))),),
        "P": (Forall("a n", Eq(rn, choose(n, a,
                 body(h, R(h, pred(n), a), pred(n))))),),
    }
    if active_count(h, "v") == 0:
        modules["L"] = (Forall("a n z", F("imp", Eq(pred(n), z),
                         Eq(rn, choose(n, a, body(h, O, z))))),)
        modules["V_K"] = (Forall("a x y", F("K",
            F("and", Eq(x, O), Eq(y, a)), graph,
            Forall("n", F("imp", Eq(x, S(n)), Eq(y, body(h, O, n)))))),)
    return modules


def predicted_costs(h: Term) -> dict[str, int]:
    H, k, ell = term_size(h), active_count(h, "v"), active_count(h, "w")
    result = {
        "D": 3 * H + 13 + k * (H + 2),
        "G_K": 3 * H + 21,
        "G_plain": 3 * H + 22,
        "T_K": 2 * H + 33,
        "W_J": 2 * H + 32,
        "M_KJ": 2 * H + 32,
        "P": (k + 2) * H + 13 + 5 * k + 3 * ell,
    }
    if k == 0:
        result.update(L=2 * H + 21, V_K=2 * H + 24)
    return result


def select(h: Term, costs: Mapping[str, int], architecture: str) -> tuple[str, int]:
    if h in (V("w"), O):
        return "D_protected", costs["D"]
    candidates = {
        "old_K": ("D", "G_K", "T_K", "V_K"),
        "old_J": ("D", "G_plain", "W_J"),
        "new_K": ("D", "G_K", "T_K", "P", "L"),
        "new_J": ("D", "G_plain", "W_J", "P", "L"),
        "new_mixed": ("D", "G_K", "M_KJ", "P", "L"),
    }[architecture]
    available = [name for name in candidates if name in costs]
    winner = min(available, key=lambda name: costs[name])
    return winner, costs[winner]


def nat_value(t: Term, env: Mapping[str, int]) -> int:
    if t.kind == "zero":
        return 0
    if t.kind == "var":
        return env[t.name]
    if t.kind == "succ":
        return 1 + nat_value(t.args[0], env)
    assert t.kind == "rec" and t.descriptor is not None
    count, state = (nat_value(arg, env) for arg in t.args)
    for counter in range(count):
        state = nat_value(t.descriptor, {"v": state, "w": counter})
    return state


def matrix_truth(phi: Formula, env: Mapping[str, int]) -> bool:
    """Classical truth on Nat only, for quantifier-free finite spot checks."""
    if phi.kind == "eq":
        return nat_value(phi.terms[0], env) == nat_value(phi.terms[1], env)
    if phi.kind == "bottom":
        return False
    values = [matrix_truth(a, env) for a in phi.args]
    if phi.kind == "and":
        return values[0] and values[1]
    if phi.kind == "or":
        return values[0] or values[1]
    if phi.kind == "imp":
        return not values[0] or values[1]
    if phi.kind == "K":
        A, B, C = values
        return (not A or B) and (not B or C)
    if phi.kind == "J":
        A, U, V_ = values
        return (A or U) and (not A or V_)
    raise ValueError("Quantifiers must be removed with explicit witnesses")


def strip_quantifiers(phi: Formula) -> Formula:
    while phi.kind in ("forall", "exists"):
        phi = phi.args[0]
    return phi


def successive(t: Term, number: int) -> Term:
    for _ in range(number):
        t = S(t)
    return t


def descriptor_suite() -> list[tuple[str, Term]]:
    result = [("Z_body", O), ("Q_body", V("w")), ("identity", V("v"))]
    for H in (2, 3, 4, 5, 6, 8, 10, 12, 14, 20, 50, 100):
        for leaf, description in ((O, "closed"), (V("v"), "state"),
                                  (V("w"), "counter")):
            result.append((f"{description}_H{H}", successive(leaf, H - 1)))
    pairs = [("mixed", Z(V("v"), V("w"))),
             ("twice_state", R(V("v"), V("v"), V("v"))),
             ("twice_counter", R(V("v"), V("w"), V("w"))),
             ("frozen_counter", Q(V("v"), V("w")))]
    for name, h in pairs:
        for H in (4, 5, 8, 12, 20, 50, 100):
            result.append((f"{name}_H{H}", successive(h, H - term_size(h))))
    state, counter = V("v"), V("w")
    for depth in range(1, 5):
        state = R(V("v"), state, state)
        counter = R(V("v"), counter, counter)
        result += [(f"state_tree_depth{depth}", state),
                   (f"counter_tree_depth{depth}", counter)]
    return result


def run() -> dict[str, object]:
    here = Path(__file__).resolve().parent
    suite = descriptor_suite()
    syntax_checks = 0
    ledger = []
    for name, h in suite:
        assert active_vars(h) <= {"v", "w"}
        actual = {label: sum(map(formula_size, formulas))
                  for label, formulas in module_formulas(h).items()}
        expected = predicted_costs(h)
        assert actual == expected, (name, actual, expected)
        syntax_checks += len(actual)
        row: dict[str, object] = {
            "descriptor": name, "H": term_size(h),
            "k": active_count(h, "v"), "ell": active_count(h, "w"), **actual,
        }
        for architecture in ("old_K", "old_J", "new_K", "new_J", "new_mixed"):
            winner, cost = select(h, actual, architecture)
            row[architecture + "_module"] = winner
            row[architecture + "_cost"] = cost
        assert row["new_K_cost"] <= row["old_K_cost"]
        assert row["new_J_cost"] <= row["old_J_cost"]
        assert row["new_mixed_cost"] <= min(row["old_K_cost"], row["old_J_cost"])
        ledger.append(row)

    # A fixed descriptor stays frozen even when it uses the replaced letter.
    frozen_probe = Q(V("v"), V("w"))
    replaced = subst(frozen_probe, {"v": O, "w": S(O)})
    assert replaced.descriptor == V("w") and replaced.args == (O, S(O))
    assert active_count(frozen_probe, "w") == 1
    assert term_size(pred(V("n"))) == 4
    assert term_size(choose(V("n"), V("a"), V("b"))) == 8

    # Literal count for generic connective records and the retained boundaries.
    A, B, C = F("A"), F("B"), F("C")
    k_record = formula_size(F("K", A, B, C)) + formula_size(
        F("and", F("imp", A, B), F("imp", B, C))) + 1
    j_record = formula_size(F("J", A, B, C)) + formula_size(
        F("and", F("or", A, B), F("imp", A, C))) + 1
    assert k_record == j_record == 12
    a, n, b, x = map(V, ("a", "n", "b", "x"))
    boundary_checks = []
    for name, h in suite:
        e = Eq(R(h, x, a), a)
        fsize = formula_size(e)
        bk = Forall("a n", Exists("b", Forall("x", F("K",
                     Eq(S(x), b), e, F("imp", Eq(x, b), Eq(b, n))))))
        bj = Forall("a n", Exists("b", Forall("x", F("J", e,
                     F("imp", Eq(S(x), b), BOTTOM),
                     F("imp", Eq(x, b), Eq(b, n))))))
        assert formula_size(bk) == fsize + 16
        assert formula_size(bj) == fsize + 18
        false_base = boundary_status(R(h, x, O), S(O))
        assert false_base["reason"] == "constructor_clash_at_base"
        assert false_base["original_F"] == term_size(h) + 6
        step = boundary_status(R(h, S(x), a), body(h, R(h, x, a), x))
        assert step["omitted"]
        assert step["reason"] in ("defining_computation_equation", "normal_reflexive")
        boundary_checks.append({"descriptor": name, "false_base": false_base,
                                "step_equation": step})
    extra = {
        "reflexivity": boundary_status(R(V("v"), x, a), R(V("v"), x, a)),
        "zero_normal_reflexivity": boundary_status(R(V("v"), O, x), x),
        "leaf": boundary_status(x, a),
        "old_coverage_exception": boundary_status(x, S(Q(x, O))),
        "retained_example": boundary_status(R(S(V("v")), x, a), a),
        "normalized_step_wrapper": boundary_status(
            Z(O, R(S(V("v")), S(x), a)), S(R(S(V("v")), x, a))),
    }
    assert extra["reflexivity"]["reason"] == "normal_reflexive"
    assert extra["zero_normal_reflexivity"]["reason"] == "normal_reflexive"
    assert extra["leaf"]["reason"] == "no_x_under_recursor"
    assert extra["old_coverage_exception"]["reason"] == "constructor_clash_at_base"
    assert extra["retained_example"]["reason"] == "retained"
    assert extra["normalized_step_wrapper"]["normalized"]
    assert extra["normalized_step_wrapper"]["reason"] == "defining_computation_equation"
    all_statuses = [v for entry in boundary_checks for v in
                    (entry["false_base"], entry["step_equation"])] + list(extra.values())
    for status in all_statuses:
        assert status["normal_F"] <= status["original_F"]
        if not status["omitted"]:
            assert status["normal_F"] >= 6 and status["normal_active_x"] >= 1
            fsize, i = status["normal_F"], status["normal_active_x"]
            assert fsize + 18 <= 2 * fsize + i + 11

    # Finite symbolic parameter grid. Not every triple is a realizable descriptor.
    grid_checks = 0
    for H in range(1, 101):
        for k in range(min(H, 8) + 1):
            for ell in range(min(H - k, 8) + 1):
                D = 3 * H + 13 + k * (H + 2)
                GK, GP, TK, M = 3 * H + 21, 3 * H + 22, 2 * H + 33, 2 * H + 32
                P = (k + 2) * H + 13 + 5 * k + 3 * ell
                old_k = min(D, GK, TK, 2 * H + 24 if k == 0 else 10**9)
                old_j = min(D, GP, M)
                L = 2 * H + 21 if k == 0 else 10**9
                assert min(D, GK, TK, P, L) <= old_k
                assert min(D, GP, M, P, L) <= old_j
                assert min(D, GK, M, P, L) <= min(old_k, old_j)
                grid_checks += 3

    # Ordinary Nat calculations. These are examples, NOT Kripke-model checks.
    semantic_checks = 0
    semantic_descriptors = [("zero", O), ("counter", V("w")),
        ("identity", V("v")), ("successor", S(V("v"))),
        ("counter_plus2", S(S(V("w")))), ("closed7", successive(O, 7)),
        ("nested_mixed", Z(V("v"), V("w"))),
        ("frozen_counter", Q(O, V("w"))),
        ("counter_twice", R(V("v"), V("w"), V("w")))]
    for _, h in semantic_descriptors:
        modules = module_formulas(h)
        p_matrix = strip_quantifiers(modules["P"][0])
        for av in range(4):
            for nv in range(6):
                env = {"a": av, "n": nv}
                assert matrix_truth(p_matrix, env)
                semantic_checks += 1
                uv = nat_value(R(h, V("n"), V("a")), env)
                for label in ("W_J", "M_KJ"):
                    matrix = strip_quantifiers(modules[label][0])
                    for xv in range(7):
                        actual_y = nat_value(R(h, V("x"), V("a")),
                                             {"x": xv, "a": av})
                        for yv in {0, 1, actual_y, actual_y + 1}:
                            assert matrix_truth(matrix, dict(env, u=uv, x=xv, y=yv))
                            semantic_checks += 1
                if "L" in modules:
                    matrix = strip_quantifiers(modules["L"][0])
                    for zv in range(7):
                        assert matrix_truth(matrix, dict(env, z=zv))
                        semantic_checks += 1
                # Semantic normal-form agreement; descriptors are not rewritten.
                term = R(h, O, S(V("a")))
                assert nat_value(term, env) == nat_value(zero_normal(term), env)
                semantic_checks += 1

    fields = ["descriptor", "H", "k", "ell", "D", "G_K", "G_plain", "T_K",
              "W_J", "M_KJ", "P", "L", "V_K"]
    for architecture in ("old_K", "old_J", "new_K", "new_J", "new_mixed"):
        fields.extend((architecture + "_module", architecture + "_cost"))
    with (here / "ledger.csv").open("w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fields)
        writer.writeheader()
        writer.writerows(ledger)
    example_names = {"Z_body", "Q_body", "closed_H4", "closed_H20", "closed_H100",
                     "state_H4", "state_H6", "state_H12", "state_H14", "state_H100",
                     "counter_H100", "twice_counter_H100",
                     "counter_tree_depth3", "twice_state_H8"}
    result = {
        "status": "PASS",
        "scope": "Exact finite AST checks and finite ordinary-Nat examples; not a full formal proof",
        "counts": {"real_descriptors": len(suite), "module_AST_equalities": syntax_checks,
                   "boundary_AST_equalities": 2 * len(suite),
                   "omission_cases": len(all_statuses),
                   "envelope_grid_inequalities": grid_checks,
                   "finite_Nat_assertions": semantic_checks},
        "logic_definition_records": {"K": k_record, "J": j_record, "K_and_J": 24},
        "protected_descriptors": {"Q": {"body": "w", "module": "D", "cost": 16},
                                  "Z": {"body": "0", "module": "D", "cost": 16}},
        "formulas": {
            "D": "3H+13+k(H+2)", "G_K": "3H+21", "G_plain": "3H+22",
            "T_K": "2H+33", "W_J": "2H+32", "M_KJ": "2H+32",
            "P": "(k+2)H+13+5k+3ell", "L_if_k0": "2H+21",
            "V_K_if_k0": "2H+24", "P_if_k0": "2H+13+3ell",
            "K_boundary": "F+16", "J_boundary": "F+18"},
        "selected_examples": [r for r in ledger if r["descriptor"] in example_names],
        "boundary_family_checks": boundary_checks,
        "boundary_examples": extra,
        "parameter_grid": {"H": [1, 100], "k": "0..min(H,8)",
                           "ell": "0..min(H-k,8)",
                           "warning": "Formal parameter triples; not all represent real descriptors"},
        "limitations": [
            "Finite natural-number checks do not establish universal or intuitionistic validity.",
            "No proof-assistant verification of the full arithmetic reconstruction or bi-interpretation.",
            "M requires successor nonzeroness; W requires its stated arithmetic bootstrap.",
            "The module ledger excludes fixed arithmetic and paid logical-definition records.",
            "Finite exported packets must charge any missing Q/Z and other bootstrap support.",
            "Normalization/omission generator source cost is disclosed by this complete file.",
            "False-base omission establishes an induction implication; the stronger omitted boundary"
            " is recovered only after calibration to iPRA.",
            "This does not prove global minimality, minimum generator length, or shortest proofs.",
        ],
    }
    (here / "verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "counts": result["counts"],
                      "outputs": [str(here / "verification.json"), str(here / "ledger.csv")]},
                     indent=2))
    return result


if __name__ == "__main__":
    run()
