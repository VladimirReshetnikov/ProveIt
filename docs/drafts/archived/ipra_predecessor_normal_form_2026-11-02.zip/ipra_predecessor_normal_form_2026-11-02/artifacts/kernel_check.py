#!/usr/bin/env python3
"""Check local predecessor-normal-form proof certificates, without a solver.

This is a small first-order natural-deduction/equality checker and three
explicit proof-certificate generators.  Its only trusted inputs are the
rules in ``check`` and the displayed, tracked assumptions.  It does not
verify the whole iPRA interpretation, the generated language, or induction.

Run with Python 3.10 or newer, without third-party packages:

    python3 artifacts/kernel_check.py

The JSON output states each checked conclusion, its actual open premises,
the rules used, and the results of deliberately invalid proof attempts.
No primitive-recursive evaluator or numerical test substitutes for a proof.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import json
from typing import Callable


class CertificateError(Exception):
    """A proposed inference does not follow by the claimed kernel rule."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise CertificateError(message)


@dataclass(frozen=True)
class Term:
    name: str
    args: tuple[Term, ...] | None = None


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple


@dataclass(frozen=True, eq=False)
class Proof:
    rule: str
    data: tuple = ()
    premises: tuple[Proof, ...] = ()


@dataclass(frozen=True)
class Sequent:
    assumptions: frozenset[Formula]
    conclusion: Formula


# A fixed first-order signature for these local lemmas.  h is an arbitrary
# binary update, g an arbitrary unary update.  None has an implicit meaning.
ARITY = {"0": 0, "S": 1, "R": 2, "h": 2, "g": 1, "p": 1, "I": 3}


def var(name: str) -> Term:
    return Term(name)


def fn(name: str, *args: Term) -> Term:
    return Term(name, tuple(args))


def eq(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


def conj(left: Formula, right: Formula) -> Formula:
    return Formula("and", (left, right))


def disj(left: Formula, right: Formula) -> Formula:
    return Formula("or", (left, right))


def imp(left: Formula, right: Formula) -> Formula:
    return Formula("imp", (left, right))


def all_(name: str, body: Formula) -> Formula:
    return Formula("all", (name, body))


def exists(name: str, body: Formula) -> Formula:
    return Formula("exists", (name, body))


def close(names: list[str], body: Formula) -> Formula:
    for name in reversed(names):
        body = all_(name, body)
    return body


def term_vars(term: Term) -> set[str]:
    if term.args is None:
        return {term.name}
    return set().union(*(term_vars(arg) for arg in term.args))


def formula_vars(formula: Formula) -> set[str]:
    kind, args = formula.kind, formula.args
    if kind == "eq":
        return term_vars(args[0]) | term_vars(args[1])
    if kind in {"all", "exists"}:
        return formula_vars(args[1]) - {args[0]}
    return formula_vars(args[0]) | formula_vars(args[1])


def context_vars(context: frozenset[Formula]) -> set[str]:
    return set().union(*(formula_vars(formula) for formula in context))


def subst_term(term: Term, name: str, value: Term) -> Term:
    if term.args is None:
        return value if term.name == name else term
    return fn(term.name, *(subst_term(arg, name, value) for arg in term.args))


def subst(formula: Formula, name: str, value: Term) -> Formula:
    """Capture-free substitution; reject a substitution needing renaming."""
    kind, args = formula.kind, formula.args
    if kind == "eq":
        return eq(*(subst_term(term, name, value) for term in args))
    if kind in {"all", "exists"}:
        bound, body = args
        if bound == name:
            return formula
        require(
            bound not in term_vars(value) or name not in formula_vars(body),
            "Substitution would capture a free variable",
        )
        return Formula(kind, (bound, subst(body, name, value)))
    return Formula(kind, tuple(subst(arg, name, value) for arg in args))


def well_formed_term(term: Term) -> None:
    require(isinstance(term, Term), "Expected a term")
    require(isinstance(term.name, str) and bool(term.name), "Bad term name")
    if term.args is not None:
        require(term.name in ARITY, "Undeclared function symbol")
        require(len(term.args) == ARITY[term.name], "Wrong function arity")
        for arg in term.args:
            well_formed_term(arg)


def well_formed(formula: Formula) -> None:
    require(isinstance(formula, Formula), "Expected a formula")
    require(len(formula.args) == 2, "Wrong formula arity")
    if formula.kind == "eq":
        for arg in formula.args:
            well_formed_term(arg)
    elif formula.kind in {"all", "exists"}:
        require(isinstance(formula.args[0], str), "Bad bound variable")
        well_formed(formula.args[1])
    else:
        require(formula.kind in {"and", "or", "imp"}, "Unknown connective")
        for arg in formula.args:
            well_formed(arg)


def show_term(term: Term) -> str:
    if term.args is None or not term.args:
        return term.name
    return term.name + "(" + ",".join(map(show_term, term.args)) + ")"


def show(formula: Formula) -> str:
    kind, args = formula.kind, formula.args
    if kind == "eq":
        return show_term(args[0]) + "=" + show_term(args[1])
    if kind in {"all", "exists"}:
        return f"({kind} {args[0]}. {show(args[1])})"
    symbol = {"and": " & ", "or": " | ", "imp": " -> "}[kind]
    return "(" + show(args[0]) + symbol + show(args[1]) + ")"


def check(root: Proof) -> tuple[Sequent, dict[str, int]]:
    """The trusted kernel.  Assumptions are tracked and discharged locally."""
    cache: dict[Proof, Sequent] = {}
    active: set[Proof] = set()
    counts: Counter = Counter()

    def visit(node: Proof) -> Sequent:
        require(isinstance(node, Proof), "Expected a proof node")
        if node in cache:
            return cache[node]
        require(node not in active, "Cyclic proof graph")
        active.add(node)
        premises = [visit(child) for child in node.premises]
        rule, data = node.rule, node.data

        def shape(n: int, d: int) -> None:
            require(len(premises) == n and len(data) == d,
                    "Wrong number of premises or rule parameters")

        context = frozenset().union(*(p.assumptions for p in premises))

        if rule == "assume":
            shape(0, 1)
            conclusion = data[0]
            context = frozenset({conclusion})
        elif rule == "eq_refl":
            shape(0, 1)
            conclusion = eq(data[0], data[0])
        elif rule == "eq_sym":
            shape(1, 0)
            premise = premises[0].conclusion
            require(premise.kind == "eq", "Symmetry needs equality")
            conclusion = eq(premise.args[1], premise.args[0])
        elif rule == "eq_trans":
            shape(2, 0)
            left, right = [p.conclusion for p in premises]
            require(left.kind == right.kind == "eq", "Transitivity needs equalities")
            require(left.args[1] == right.args[0], "Transitivity middle mismatch")
            conclusion = eq(left.args[0], right.args[1])
        elif rule == "eq_cong":
            shape(1, 2)
            name, template = data
            require(isinstance(name, str), "Bad congruence variable")
            well_formed_term(template)
            premise = premises[0].conclusion
            require(premise.kind == "eq", "Congruence needs equality")
            conclusion = eq(*(subst_term(template, name, t) for t in premise.args))
        elif rule == "and_i":
            shape(2, 0)
            conclusion = conj(*(p.conclusion for p in premises))
        elif rule in {"and_e_left", "and_e_right"}:
            shape(1, 0)
            premise = premises[0].conclusion
            require(premise.kind == "and", "Conjunction elimination needs conjunction")
            conclusion = premise.args[int(rule == "and_e_right")]
        elif rule == "imp_i":
            shape(1, 1)
            well_formed(data[0])
            context = premises[0].assumptions - {data[0]}
            conclusion = imp(data[0], premises[0].conclusion)
        elif rule == "imp_e":
            shape(2, 0)
            major, minor = [p.conclusion for p in premises]
            require(major.kind == "imp", "Implication elimination needs implication")
            require(major.args[0] == minor, "Implication antecedent mismatch")
            conclusion = major.args[1]
        elif rule == "all_i":
            shape(1, 1)
            name = data[0]
            require(isinstance(name, str), "Bad universal eigenvariable")
            require(name not in context_vars(context),
                    "Universal eigenvariable occurs in an open assumption")
            conclusion = all_(name, premises[0].conclusion)
        elif rule == "all_e":
            shape(1, 1)
            well_formed_term(data[0])
            premise = premises[0].conclusion
            require(premise.kind == "all", "Universal elimination needs forall")
            conclusion = subst(premise.args[1], premise.args[0], data[0])
        elif rule in {"or_i_left", "or_i_right"}:
            shape(1, 1)
            well_formed(data[0])
            parts = [premises[0].conclusion, data[0]]
            if rule == "or_i_right":
                parts.reverse()
            conclusion = disj(*parts)
        elif rule == "or_e":
            shape(3, 0)
            major, left, right = premises
            require(major.conclusion.kind == "or", "Case split needs disjunction")
            require(left.conclusion == right.conclusion, "Case conclusions differ")
            a, b = major.conclusion.args
            context = (major.assumptions | (left.assumptions - {a})
                       | (right.assumptions - {b}))
            conclusion = left.conclusion
        elif rule == "exists_i":
            shape(1, 3)
            name, body, witness = data
            require(isinstance(name, str), "Bad existential binder")
            well_formed(body)
            well_formed_term(witness)
            require(subst(body, name, witness) == premises[0].conclusion,
                    "Existential witness does not prove its matrix")
            conclusion = exists(name, body)
        elif rule == "exists_e":
            shape(2, 1)
            major, branch = premises
            require(major.conclusion.kind == "exists", "Existential elimination needs exists")
            eigen = data[0]
            require(isinstance(eigen, str), "Bad existential eigenvariable")
            bound, body = major.conclusion.args
            instance = subst(body, bound, var(eigen))
            residual = branch.assumptions - {instance}
            forbidden = (context_vars(major.assumptions | residual)
                         | formula_vars(major.conclusion)
                         | formula_vars(branch.conclusion))
            require(eigen not in forbidden, "Existential eigenvariable escapes")
            context = major.assumptions | residual
            conclusion = branch.conclusion
        else:
            raise CertificateError("Unknown inference rule: " + rule)

        well_formed(conclusion)
        for assumption in context:
            well_formed(assumption)
        result = Sequent(frozenset(context), conclusion)
        cache[node] = result
        active.remove(node)
        counts[rule] += 1
        return result

    result = visit(root)
    return result, dict(sorted(counts.items()))


# Everything below constructs certificates.  It is outside the kernel.
def assume(formula: Formula) -> Proof:
    return Proof("assume", (formula,))


def refl(term: Term) -> Proof:
    return Proof("eq_refl", (term,))


def sym(proof: Proof) -> Proof:
    return Proof("eq_sym", premises=(proof,))


def trans(*proofs: Proof) -> Proof:
    require(bool(proofs), "An equality chain must be nonempty")
    result = proofs[0]
    for proof in proofs[1:]:
        result = Proof("eq_trans", premises=(result, proof))
    return result


def congr(proof: Proof, template: Term, name: str = "q") -> Proof:
    return Proof("eq_cong", (name, template), (proof,))


def inst(proof: Proof, *terms: Term) -> Proof:
    for term in terms:
        proof = Proof("all_e", (term,), (proof,))
    return proof


def generalize(proof: Proof, names: list[str]) -> Proof:
    for name in reversed(names):
        proof = Proof("all_i", (name,), (proof,))
    return proof


def implication(assumption: Formula, proof: Proof) -> Proof:
    return Proof("imp_i", (assumption,), (proof,))


zero = fn("0")
a, n, m, b, z, q = map(var, ["a", "n", "m", "b", "z", "q"])


def successor(term: Term) -> Term:
    return fn("S", term)


def pred(term: Term) -> Term:
    return fn("p", term)


def rec(counter: Term, initial: Term) -> Term:
    return fn("R", counter, initial)


def select(counter: Term, initial: Term, other: Term) -> Term:
    return fn("I", counter, initial, other)


PRED_ZERO = eq(pred(zero), zero)
PRED_SUCCESSOR = all_("m", eq(pred(successor(m)), m))
SELECT_ZERO = close(["a", "b"], eq(select(zero, a, b), a))
SELECT_SUCCESSOR = close(["m", "a", "b"], eq(select(successor(m), a, b), b))
COVERAGE = all_("n", disj(eq(n, zero), exists("m", eq(n, successor(m)))))
HELPERS = frozenset({PRED_SUCCESSOR, SELECT_ZERO, SELECT_SUCCESSOR, COVERAGE})


def predecessor_certificate(update: Callable[[Term, Term], Term]) -> dict:
    """Build D <-> P, retaining all helper assumptions explicitly."""
    base = all_("a", eq(rec(zero, a), a))
    step = close(["a", "n"], eq(rec(successor(n), a), update(rec(n, a), n)))
    direct = conj(base, step)

    def tail(counter: Term) -> Term:
        return update(rec(pred(counter), a), pred(counter))

    normal_body = eq(rec(n, a), select(n, a, tail(n)))
    normal = close(["a", "n"], normal_body)
    direct_hyp = assume(direct)
    base_hyp = Proof("and_e_left", premises=(direct_hyp,))
    step_hyp = Proof("and_e_right", premises=(direct_hyp,))
    pred_hyp = assume(PRED_SUCCESSOR)
    zero_hyp = assume(SELECT_ZERO)
    successor_hyp = assume(SELECT_SUCCESSOR)

    # Forward direction: fix a,n; split the explicit coverage premise.
    n_is_zero = assume(eq(n, zero))
    left_to_a = trans(congr(n_is_zero, rec(q, a)), inst(base_hyp, a))
    right_to_a = trans(
        congr(n_is_zero, select(q, a, tail(n))),
        inst(zero_hyp, a, tail(n)),
    )
    zero_branch = trans(left_to_a, sym(right_to_a))

    n_is_successor = assume(eq(n, successor(m)))
    left_to_update = trans(
        congr(n_is_successor, rec(q, a)), inst(step_hyp, a, m)
    )
    predecessor_value = trans(
        congr(n_is_successor, pred(q)), inst(pred_hyp, m)
    )
    tail_to_update = congr(predecessor_value, update(rec(q, a), q))
    right_to_update = trans(
        congr(n_is_successor, select(q, a, tail(n))),
        inst(successor_hyp, m, a, tail(n)),
        tail_to_update,
    )
    successor_branch = trans(left_to_update, sym(right_to_update))
    existential_case = Proof(
        "exists_e", ("m",),
        (assume(exists("m", eq(n, successor(m)))), successor_branch),
    )
    cases = Proof(
        "or_e", premises=(inst(assume(COVERAGE), n), zero_branch, existential_case)
    )
    forward = implication(direct, generalize(cases, ["a", "n"]))

    # Reverse direction: evaluate P at 0 and at Sm.  Coverage is unnecessary.
    normal_hyp = assume(normal)
    reverse_base = trans(
        inst(normal_hyp, a, zero), inst(zero_hyp, a, tail(zero))
    )
    reverse_step = trans(
        inst(normal_hyp, a, successor(m)),
        inst(successor_hyp, m, a, tail(successor(m))),
        congr(inst(pred_hyp, m), update(rec(q, a), q)),
    )
    # Rename the proof's free counter from m to n by constructing a universal
    # theorem first, then instantiating it; no untrusted proof substitution.
    reverse_step_at_n = inst(generalize(reverse_step, ["m"]), n)
    reverse_direct = Proof(
        "and_i", premises=(generalize(reverse_base, ["a"]),
                            generalize(reverse_step_at_n, ["a", "n"]))
    )
    reverse = implication(normal, reverse_direct)
    equivalence = Proof("and_i", premises=(forward, reverse))
    return {
        "proof": equivalence,
        "conclusion": conj(imp(direct, normal), imp(normal, direct)),
        "assumptions": HELPERS,
        "directions": {"direct_to_normal": forward, "normal_to_direct": reverse},
        "normal": normal,
    }


def named_predecessor_certificate(normal: Formula) -> dict:
    """Prove F <-> L for a state-free update g, using equality logic only."""
    named_body = imp(eq(pred(n), z), eq(rec(n, a), select(n, a, fn("g", z))))
    named = close(["a", "n", "z"], named_body)
    premise = eq(pred(n), z)
    rewriting = congr(assume(premise), select(n, a, fn("g", q)))
    target = trans(inst(assume(normal), a, n), rewriting)
    forward = implication(
        normal, generalize(implication(premise, target), ["a", "n", "z"])
    )
    specialized = inst(assume(named), a, n, pred(n))
    reflected = Proof("imp_e", premises=(specialized, refl(pred(n))))
    reverse = implication(named, generalize(reflected, ["a", "n"]))
    return {
        "proof": Proof("and_i", premises=(forward, reverse)),
        "conclusion": conj(imp(normal, named), imp(named, normal)),
        "assumptions": frozenset(),
        "directions": {"normal_to_named": forward, "named_to_normal": reverse},
    }


def rejection_checks() -> list[str]:
    """Check concrete mistakes that would invalidate the claimed proof logic."""
    examples = {
        "mismatched_equality_chain": Proof(
            "eq_trans", premises=(refl(zero), refl(successor(zero)))
        ),
        "universal_generalization_over_open_assumption": Proof(
            "all_i", ("n",), (assume(eq(n, zero)),)
        ),
        "escaping_existential_witness": Proof(
            "exists_e", ("m",),
            (assume(exists("z", eq(z, zero))), assume(eq(m, zero))),
        ),
        "different_disjunction_case_conclusions": Proof(
            "or_e", premises=(assume(disj(eq(n, zero), eq(n, successor(m)))),
                               refl(zero), refl(successor(zero)))
        ),
        "wrong_implication_antecedent": Proof(
            "imp_e", premises=(assume(imp(eq(n, zero), eq(a, zero))), refl(n))
        ),
        "capturing_quantifier_substitution": Proof(
            "all_e", (n,), (assume(all_("a", all_("n", eq(a, n)))),)
        ),
    }
    rejected = []
    for label, proof in examples.items():
        try:
            check(proof)
        except CertificateError:
            rejected.append(label)
        else:
            raise CertificateError("Invalid test certificate was accepted: " + label)
    return rejected


def summarize(label: str, certificate: dict) -> dict:
    result, counts = check(certificate["proof"])
    require(result.conclusion == certificate["conclusion"], "Wrong final theorem")
    require(result.assumptions == certificate["assumptions"],
            "Unexpected final open assumptions")
    directions = {}
    for name, proof in certificate["directions"].items():
        direction, _ = check(proof)
        directions[name] = sorted(map(show, direction.assumptions))
    return {
        "name": label,
        "status": "checked",
        "conclusion": show(result.conclusion),
        "open_assumptions": sorted(map(show, result.assumptions)),
        "assumptions_by_direction": directions,
        "distinct_proof_nodes": sum(counts.values()),
        "rule_counts": counts,
    }


def main() -> None:
    general = predecessor_certificate(lambda value, counter: fn("h", value, counter))
    state_free = predecessor_certificate(lambda value, counter: fn("g", counter))
    named = named_predecessor_certificate(state_free["normal"])
    report = {
        "status": "all_local_certificates_checked",
        "scope": (
            "First-order intuitionistic natural deduction with native equality. "
            "Only the displayed local computation equivalences are checked. "
            "This is not a machine verification of the complete iPRA theory, "
            "the syntax-size comparison, or either bi-interpretation."
        ),
        "numerical_axioms_are_explicit_assumptions": True,
        "unused_helper": show(PRED_ZERO),
        "unused_helper_explanation": (
            "p(0)=0 is unnecessary: at zero, I ignores its third argument."
        ),
        "certificates": [
            summarize("general_predecessor_normal_form", general),
            summarize("state_free_predecessor_normal_form", state_free),
            summarize("state_free_named_predecessor", named),
        ],
        "invalid_certificates_rejected": rejection_checks(),
    }
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
