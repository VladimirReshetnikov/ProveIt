#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 artifacts/verify.py
python3 artifacts/kernel_check.py > artifacts/kernel_verification.json
pdflatex -interaction=nonstopmode -halt-on-error ipra_predecessor_normal_form.tex
pdflatex -interaction=nonstopmode -halt-on-error ipra_predecessor_normal_form.tex

