A PREDECESSOR NORMAL FORM FOR INTUITIONISTIC PRA
Research report for Vladimir Reshetnikov — 2 November 2026

Read ipra_predecessor_normal_form.pdf.
The main LaTeX source is ipra_predecessor_normal_form.tex.
All included TeX sections are in sections/.

Target
------
Full first-order intuitionistic primitive recursive arithmetic, with
quantifier-free induction and arbitrary finite tuples of parameters.
The report proves ordinary whole-carrier bi-interpretations with identity
round trips, and syntactic equiconsistency. It does not identify classical
and intuitionistic quantified arithmetic.

New results
-----------
1. The predecessor normal form replaces the two defining equations of an
   initialized recursor by one ordinary equality axiom. Its full tree cost
   is (k+2)H + 13 + 5k + 3ell.
2. For updates independent of their state, a shared-predecessor formula has
   full cost 2H+21, improving the old 2H+24 branch. The unshared version
   can reach 2H+13 for closed updates.
3. A terminating zero normalization and certified omission tests reduce the
   boundary schema. Entire infinite families of previously emitted induction
   boundaries disappear.
4. A mixed K/J computation module meets the existing 2H+32 branch with only
   successor separation, simplifying its bootstrap.
5. A two-branch countermodel shows why deleting the induction parameter is
   invalid in the sparse initialized-recursion language.

What "simpler" means
-------------------
The report uses the inspected drafts' full syntax-tree cost, charging stored
descriptors at every occurrence and logical definitions separately.
T_K is the small-basis recommendation. T_KJ meets the joint recurring
frontier and pays for both logical definitions. Fixed costs, finite proof
support, instance counts, generator bytes, and proof length are not conflated.
No absolute minimum across unrestricted languages or logics is claimed.

Verification
------------
python3 artifacts/kernel_check.py
python3 artifacts/verify.py
bash build.sh

kernel_check.py is an actual small natural-deduction/equality proof-certificate
checker for the LOCAL computation equivalences. It does not check the full
arithmetic reconstruction or bi-interpretations. Its assumptions are printed.

verify.py performs exact literal AST counts and supplementary finite natural-
number checks; finite checking is not substituted for a universal proof.

Files
-----
AXIOMS.txt                    Standalone complete specifications.
artifacts/kernel_check.py     Local logical proof checker and certificates.
artifacts/kernel_verification.json
                              Recorded local proof-check results.
artifacts/verify.py           AST counter, selectors, omissions, finite checks.
artifacts/verification.json   Complete recorded syntax/numerical results.
artifacts/ledger.csv          Actual descriptor/module comparison rows.
provenance/source_manifest.json
                              Source snapshot and archive hashes/member lists.
provenance/draft_comparison.csv
                              All eleven draft archives and filter decisions.
provenance/frontier_audit.txt  Detailed source comparison notes.
SHA256SUMS                    Hashes of packaged files other than this manifest.

Source comparison is pinned to ProveIt commit:
0593751362f559ccc52e269fe5ecac06a7d6e63c

The package is self-contained apart from the ordinary Python and TeX tools
needed to rebuild it.

