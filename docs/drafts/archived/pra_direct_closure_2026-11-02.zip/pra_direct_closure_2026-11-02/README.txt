PRA FROM DIRECT CLOSURE
A three-occurrence axiomatization
Prepared for Vladimir Reshetnikov, 2 November 2026

START HERE
  report.pdf          Complete manuscript with proofs and comparisons.
  report.tex          Main editable LaTeX source.
  sections/*.tex      Source sections.
  AXIOMS.txt          Exact standalone theory specification.

RESULT
Use only initial 0,S and one generated family of binary initialized
recursors R_h. Retain separation and the two recursion equations. For
each two-slot quantifier-free formula A(x,a), require

  forall a:
    [forall x: ((x=0 or A(x,a)) -> A(S(x),a))]
    -> [forall x: (x=0 or A(x,a))].

This theory and matching first-order PRA have a common conservative
definitional extension. Both interpretations use the full domain and
native equality, and both round-trip isomorphisms are identities. The
proof works separately in classical and intuitionistic logic.

A further proved reduction restricts the closure schema to single
equations A(x,a) of the form s(x,a)=t(x,a). It is deductively equivalent in the
same language. The unrestricted version is retained for the direct
same-formula cost comparison; atomic compilation has separate costs.

WHY THIS IS SIMPLER
The primitive equality bit, its fixed axiom, and all mask definitions
are absent from the axiomatization. For a common input formula of full
size F with k active induction-variable occurrences, the closure instance
costs 3F+k+13 full nodes. The six current uniform mask recipes cost at
least 22+4F for their complete definition+witness units. The saving is
at least 10 full nodes per unit, with the fixed seed reduced from 24 to 6.

The report includes successor propagation as a second frontier point:
16 fixed nodes with explicit coverage, 3F+2k+9 nodes per instance, and
at least 12 full nodes saved per complete matched unit.

SCOPE
No absolute shortestness theorem is claimed. The isolated 12-node ACTIVE
mask witness is still shorter than a large direct formula; its supporting
definition and stored bodies are what the FULL comparison counts.
The comparison is over genuinely shared earlier arithmetic syntax and
separately charged selected modules, not every serializer address or
arbitrary proofs with preexisting reusable definitions.

VERIFICATION
  formal/ZeroExemptKernel.lean  Local arbitrary-carrier proof kernels.
  formal/verification.log      Actual Lean 4.19.0 successful compilation.
  formal/verification.json     Version, source hash, return code, scope.
  formal/SCOPE.txt             Exact boundaries of formal verification.
  checks/check_sizes.py        Independent standard-library AST checker.
  checks/count_results.json    Actual counts and representative trees.
  provenance/sources.json     Six pinned input archives and verified hashes.
  verification/               Build and final artifact validation.

Eighteen Lean theorem dependency checks report no axioms. The full
generated syntax, arithmetic/pairing bootstrap, compiler, and first-order
bi-interpretation are written proofs, not claimed to be fully mechanized.
The Python corpus is an accounting check, not a proof of the infinite
theory. The structural comparison proof is in the manuscript.

REPRODUCE
  python3 build.py
  lean formal/ZeroExemptKernel.lean

Or run:
  python3 build.py --lean /absolute/path/to/lean

Python uses only its standard library. The report uses pdfLaTeX and
ordinary TeX Live packages listed in report.tex. Lean uses 4.19.0 and
its bundled Init library; no Mathlib or network access is needed.

SOURCE SNAPSHOT
  VladimirReshetnikov/ProveIt
  4d5474f10e00412135d659dc7a1f74fc6457656a
  docs/drafts (six archives, including two distinct pointwise-mask ZIPs)

This package includes a Further research questions section. It contains
new research deliverables; no changes were published to the repository.
