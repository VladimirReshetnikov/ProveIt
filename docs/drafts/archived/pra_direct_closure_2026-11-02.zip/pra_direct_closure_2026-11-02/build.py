#!/usr/bin/env python3
"""Recheck syntax accounting and rebuild the research manuscript."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(args: list[str], log: Path) -> dict:
    result = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(result.stdout, encoding="utf-8")
    record = {"command": args, "returncode": result.returncode,
              "log": str(log.relative_to(ROOT))}
    if result.returncode:
        print(result.stdout[-12000:])
        raise SystemExit(result.returncode)
    return record

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", help="Optional path to Lean 4.19.0")
    args = parser.parse_args()
    verification = ROOT / "verification"
    verification.mkdir(exist_ok=True)
    records = [run([sys.executable, "checks/check_sizes.py",
                    "checks/count_results.json"], verification / "counts.log")]
    if args.lean:
        version = subprocess.check_output([args.lean, "--version"], text=True).strip()
        result = run([args.lean, "formal/ZeroExemptKernel.lean"],
                     ROOT / "formal/verification.log")
        records.append(result)
        log = (ROOT / "formal/verification.log").read_text()
        audited = log.count("does not depend on any axioms")
        if audited != 18:
            raise SystemExit(f"Expected 18 axiom-free audit reports, found {audited}")
        (ROOT / "formal/verification.json").write_text(json.dumps({
            "compiler": version,
            "source_sha256": hashlib.sha256((ROOT / "formal/ZeroExemptKernel.lean").read_bytes()).hexdigest(),
            "returncode": 0, "theorems_printed_axiom_free": audited,
            "scope": "Local arbitrary-carrier kernels only; see formal/SCOPE.txt."
        }, indent=2) + "\n")
    for i in range(3):
        records.append(run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                            "report.tex"], verification / f"latex_pass_{i+1}.log"))
    log = (ROOT / "report.log").read_text(errors="replace")
    issues = [line for line in log.splitlines()
              if "Overfull" in line or "undefined" in line or "LaTeX Warning" in line]
    output = {"status": "passed", "commands": records,
              "pdf_bytes": (ROOT / "report.pdf").stat().st_size,
              "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
              "layout_or_reference_warnings": issues}
    (verification / "build.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"status": output["status"], "pdf": str(ROOT / "report.pdf"),
                      "pdf_bytes": output["pdf_bytes"], "warnings": issues}, indent=2))

if __name__ == "__main__":
    main()
