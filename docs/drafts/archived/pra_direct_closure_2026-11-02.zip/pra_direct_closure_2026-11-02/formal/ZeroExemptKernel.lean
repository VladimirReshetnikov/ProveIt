import Init

/-!
# Zero-exempt closure and successor propagation: local proof kernels

All forward results hold on an arbitrary type.  There is no use of `Nat`,
natural-number induction, excluded middle, or choice.  The function and
predicate variables below are METATHEORETIC parameters of the local lemmas;
the proposed first-order theory has an external quantifier-free schema and
does not quantify over predicates or functions.

This file checks the local equivalence of the closure/propagation schemata
and induction, the successor consequences of initialized recursion, coverage,
and uniqueness of initialized recursors.  It does NOT formalize the syntax of primitive
recursive descriptions, the pairing construction, or the whole first-order
bi-interpretation.
-/

namespace ZeroExempt

universe u v w

variable {A : Type u}

/-- The single closure instance for P. -/
def Closure (zero : A) (succ : A → A) (P : A → Prop) : Prop :=
  (∀ x, (x = zero ∨ P x) → P (succ x)) →
  ∀ x, x = zero ∨ P x

/-- The ordinary induction implication for one fixed predicate. -/
def Induction (zero : A) (succ : A → A) (P : A → Prop) : Prop :=
  P zero → (∀ x, P x → P (succ x)) → ∀ x, P x

/-- One closure instance proves the induction implication for the SAME P.
The two induction premises are local hypotheses, not required theorems. -/
theorem closure_implies_induction
    (zero : A) (succ : A → A) (P : A → Prop)
    (closure : Closure zero succ P) : Induction zero succ P := by
  intro base step
  have advance : ∀ x, (x = zero ∨ P x) → P (succ x) := by
    intro x hx
    apply step x
    rcases hx with hz | hp
    · exact hz.symm ▸ base
    · exact hp
  intro x
  rcases closure advance x with hz | hp
  · exact hz.symm ▸ base
  · exact hp

/-- Conversely, induction for the quantifier-free enlargement x=0 or P(x)
proves the closure instance for P.  No arithmetic property is used. -/
theorem closure_of_enlarged_induction
    (zero : A) (succ : A → A) (P : A → Prop)
    (induction : Induction zero succ (fun x => x = zero ∨ P x)) :
    Closure zero succ P := by
  intro advance
  apply induction (Or.inl rfl)
  intro x hx
  exact Or.inr (advance x hx)

/-- A schematic equivalence at the metatheoretic level.
In the intended application, the predicate class is the quantifier-free
formulas; that class is closed under adjoining the equality x=0. -/
theorem schema_equivalence (zero : A) (succ : A → A) :
    (∀ P : A → Prop, Closure zero succ P) ↔
    (∀ P : A → Prop, Induction zero succ P) := by
  constructor
  · intro closures P
    exact closure_implies_induction zero succ P (closures P)
  · intro inductions P
    exact closure_of_enlarged_induction zero succ P
      (inductions (fun x => x = zero ∨ P x))

/-- The local proof is uniform in arbitrary retained parameters.  No encoding
of parameters is used in this theorem; an object-level one-parameter scheme
is obtained by taking Param=A. -/
theorem parameterized_transfer
    {Param : Type v}
    (zero : A) (succ : A → A) (P : A → Param → Prop)
    (closures : ∀ a, Closure zero succ (fun x => P x a)) :
    ∀ a, P zero a →
      (∀ x, P x a → P (succ x) a) → ∀ x, P x a := by
  intro a
  exact closure_implies_induction zero succ (fun x => P x a) (closures a)

/-- A still shorter successor-only conclusion; full coverage is not assumed
in the definition. -/
def Propagation (zero : A) (succ : A → A) (P : A → Prop) : Prop :=
  (∀ x, (x = zero ∨ P x) → P (succ x)) →
  ∀ x, P (succ x)

/-- QF induction for x=0 or P(x) proves the propagation instance for P. -/
theorem propagation_of_enlarged_induction
    (zero : A) (succ : A → A) (P : A → Prop)
    (induction : Induction zero succ (fun x => x = zero ∨ P x)) :
    Propagation zero succ P := by
  intro advance x
  have enlarged : ∀ y, y = zero ∨ P y := by
    apply induction (Or.inl rfl)
    intro y hy
    exact Or.inr (advance y hy)
  exact advance x (enlarged x)

/-- Once coverage is available, the SAME propagation instance gives the
full ordinary induction implication for P under its local premises. -/
theorem propagation_implies_induction_of_coverage
    (zero : A) (succ : A → A) (P : A → Prop)
    (coverage : ∀ x, x = zero ∨ ∃ y, x = succ y)
    (propagation : Propagation zero succ P) :
    Induction zero succ P := by
  intro base step
  have advance : ∀ x, (x = zero ∨ P x) → P (succ x) := by
    intro x hx
    apply step x
    rcases hx with hz | hp
    · exact hz.symm ▸ base
    · exact hp
  have on_successors := propagation advance
  intro x
  rcases coverage x with hz | ⟨y, hy⟩
  · exact hz.symm ▸ base
  · exact hy.symm ▸ on_successors y

/-- The canonical quantifier-free coverage predicate. -/
def Cover (zero : A) (succ pred : A → A) (x : A) : Prop :=
  x = zero ∨ x = succ (pred x)

/-- Coverage is derivable from ONE specially selected propagation instance.
Only pred(succ x)=x is required; neither pred(0)=0 nor separation is used.
The conjunction remembers coverage one predecessor earlier. -/
theorem coverage_of_special_propagation
    (zero : A) (succ pred : A → A)
    (pred_succ : ∀ x, pred (succ x) = x)
    (propagation : Propagation zero succ
      (fun x => Cover zero succ pred x ∧ Cover zero succ pred (pred x))) :
    ∀ x, Cover zero succ pred x := by
  have cover_zero : Cover zero succ pred zero := Or.inl rfl
  have cover_succ : ∀ x, Cover zero succ pred (succ x) := by
    intro x
    exact Or.inr (congrArg succ (pred_succ x).symm)
  have advance : ∀ x,
      (x = zero ∨ (Cover zero succ pred x ∧ Cover zero succ pred (pred x))) →
      (Cover zero succ pred (succ x) ∧ Cover zero succ pred (pred (succ x))) := by
    intro x hx
    have cover_x : Cover zero succ pred x := by
      rcases hx with hz | hb
      · exact hz.symm ▸ cover_zero
      · exact hb.1
    exact ⟨cover_succ x, (pred_succ x).symm ▸ cover_x⟩
  intro x
  have hx := (propagation advance x).2
  exact (pred_succ x) ▸ hx

/-- Schematic equivalence over a predecessor left inverse.  This is a
metatheorem; the object-level schema only ranges over quantifier-free formulas.
Every predicate constructed in the proof is quantifier-free when P is. -/
theorem propagation_schema_equivalence
    (zero : A) (succ pred : A → A)
    (pred_succ : ∀ x, pred (succ x) = x) :
    (∀ P : A → Prop, Propagation zero succ P) ↔
    (∀ P : A → Prop, Induction zero succ P) := by
  constructor
  · intro propagations
    have canonical : ∀ x, Cover zero succ pred x :=
      coverage_of_special_propagation zero succ pred pred_succ
        (propagations (fun x =>
          Cover zero succ pred x ∧ Cover zero succ pred (pred x)))
    have coverage : ∀ x, x = zero ∨ ∃ y, x = succ y := by
      intro x
      rcases canonical x with hz | hs
      · exact Or.inl hz
      · exact Or.inr ⟨pred x, hs⟩
    intro P
    exact propagation_implies_induction_of_coverage zero succ P coverage
      (propagations P)
  · intro inductions P
    exact propagation_of_enlarged_induction zero succ P
      (inductions (fun x => x = zero ∨ P x))

theorem parameterized_propagation_transfer
    {Param : Type v}
    (zero : A) (succ : A → A) (P : A → Param → Prop)
    (coverage : ∀ x, x = zero ∨ ∃ y, x = succ y)
    (propagations : ∀ a, Propagation zero succ (fun x => P x a)) :
    ∀ a, P zero a →
      (∀ x, P x a → P (succ x) a) → ∀ x, P x a := by
  intro a
  exact propagation_implies_induction_of_coverage zero succ (fun x => P x a)
    coverage (propagations a)

/-- The selector is the initialized recursor with body equal to its counter.
These fields are equations and separation, not induction or coverage. -/
structure SelectorKernel (A : Type u) where
  zero : A
  succ : A → A
  Q : A → A → A
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ n a, Q (succ n) a = n
  separated : zero ≠ succ zero

namespace SelectorKernel

variable (K : SelectorKernel A)

def pred (x : A) : A := K.Q x K.zero

theorem pred_zero : K.pred K.zero = K.zero := K.q_zero K.zero

theorem pred_succ (x : A) : K.pred (K.succ x) = x := K.q_succ x K.zero

theorem successor_injective (x y : A)
    (equal_successors : K.succ x = K.succ y) : x = y := by
  have h := congrArg K.pred equal_successors
  simpa only [K.pred_succ] using h

theorem successor_nonzero (x : A) : K.succ x ≠ K.zero := by
  intro hz
  have hx : x = K.zero := by
    have h := congrArg K.pred hz
    simpa only [K.pred_succ, K.pred_zero] using h
  exact K.separated (hz.symm.trans (congrArg K.succ hx))

/-- Coverage follows from one closure instance directly.  Its premise holds
unconditionally at successors, so no carrier induction has been assumed. -/
theorem coverage
    (closure : Closure K.zero K.succ
      (fun x => x = K.succ (K.pred x))) :
    ∀ x, x = K.zero ∨ x = K.succ (K.pred x) := by
  apply closure
  intro x _
  exact congrArg K.succ (K.pred_succ x).symm

theorem existential_coverage
    (closure : Closure K.zero K.succ
      (fun x => x = K.succ (K.pred x))) :
    ∀ x, ∃ y, x = K.zero ∨ x = K.succ y := by
  intro x
  exact ⟨K.pred x, K.coverage closure x⟩

end SelectorKernel

/-- Uniqueness of a recursion solution needs only the induction instance for
the pointwise equality of the two proposed solutions. -/
theorem recursion_unique_of_induction
    {B : Type v}
    (zero : A) (succ : A → A)
    (h : B → A → B) (f g : A → B)
    (induction : Induction zero succ (fun n => f n = g n))
    (base : f zero = g zero)
    (f_step : ∀ n, f (succ n) = h (f n) n)
    (g_step : ∀ n, g (succ n) = h (g n) n) :
    ∀ n, f n = g n := by
  apply induction base
  intro n same
  exact (f_step n).trans ((congrArg (fun x => h x n) same).trans
    (g_step n).symm)

/-- The closure schema supplies precisely that uniqueness instance. -/
theorem recursion_unique_of_closure
    {B : Type v}
    (zero : A) (succ : A → A)
    (h : B → A → B) (f g : A → B)
    (closure : Closure zero succ (fun n => f n = g n))
    (base : f zero = g zero)
    (f_step : ∀ n, f (succ n) = h (f n) n)
    (g_step : ∀ n, g (succ n) = h (g n) n) :
    ∀ n, f n = g n :=
  recursion_unique_of_induction zero succ h f g
    (closure_implies_induction zero succ (fun n => f n = g n) closure)
    base f_step g_step

/-- Binary initialized recursors are unique, pointwise in their initial state.
Every displayed induction predicate has only n and a as free object variables. -/
theorem initialized_recursors_unique
    (zero : A) (succ : A → A)
    (h : A → A → A) (F G : A → A → A)
    (closures : ∀ a, Closure zero succ (fun n => F n a = G n a))
    (F_zero : ∀ a, F zero a = a)
    (G_zero : ∀ a, G zero a = a)
    (F_step : ∀ n a, F (succ n) a = h (F n a) n)
    (G_step : ∀ n a, G (succ n) a = h (G n a) n) :
    ∀ n a, F n a = G n a := by
  intro n a
  exact recursion_unique_of_closure zero succ h (fun k => F k a)
    (fun k => G k a) (closures a)
    ((F_zero a).trans (G_zero a).symm)
    (fun k => F_step k a) (fun k => G_step k a) n

#print axioms closure_implies_induction
#print axioms closure_of_enlarged_induction
#print axioms schema_equivalence
#print axioms parameterized_transfer
#print axioms propagation_of_enlarged_induction
#print axioms propagation_implies_induction_of_coverage
#print axioms coverage_of_special_propagation
#print axioms propagation_schema_equivalence
#print axioms parameterized_propagation_transfer
#print axioms SelectorKernel.pred_zero
#print axioms SelectorKernel.pred_succ
#print axioms SelectorKernel.successor_injective
#print axioms SelectorKernel.successor_nonzero
#print axioms SelectorKernel.coverage
#print axioms SelectorKernel.existential_coverage
#print axioms recursion_unique_of_induction
#print axioms recursion_unique_of_closure
#print axioms initialized_recursors_unique

end ZeroExempt
