#!/usr/bin/env python3
"""Reconstruct syntax trees for the PRA closure/mask comparison.

Standard-library-only reproducible checks.  This program is an independent
finite syntax-accounting check, not a formal proof of the universal comparison
theorem or of bi-interpretability.  The universal inequalities follow from the
structural arguments in the accompanying mathematical notes.

Usage: python3 check_sizes.py [output.json]
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    args: tuple["Node", ...] = ()
    label: str = ""
    descriptor: "Node | None" = None


def var(name: str) -> Node:
    return Node("var", label=name)


def app(name: str, *args: Node, descriptor: Node | None = None) -> Node:
    return Node("app", tuple(args), name, descriptor)


ZERO = Node("const", label="0")
BOT = Node("bot")
x, a, n, b, v, w, y = map(var, ("x", "a", "n", "b", "v", "w", "y"))


def S(t: Node) -> Node:
    return app("S", t)


ONE = S(ZERO)


def Q(t: Node, u: Node) -> Node:
    return app("Q", t, u, descriptor=w)


def Z(t: Node, u: Node) -> Node:
    return app("Z", t, u, descriptor=ZERO)


def chi(t: Node, u: Node) -> Node:
    return app("chi", t, u)


def eq(t: Node, u: Node) -> Node:
    return Node("eq", (t, u))


def con(kind: str, t: Node, u: Node) -> Node:
    assert kind in ("and", "or", "imp")
    return Node(kind, (t, u))


def all_(name: str, t: Node) -> Node:
    return Node("all", (t,), name)


def ex(name: str, t: Node) -> Node:
    return Node("ex", (t,), name)


def neg(t: Node) -> Node:
    return con("imp", t, BOT)


def subst(t: Node, name: str, value: Node) -> Node:
    """Substitute in active arguments only; frozen descriptors stay frozen."""
    if t.kind == "var" and t.label == name:
        return value
    if t.kind in ("all", "ex") and t.label == name:
        return t
    return Node(t.kind, tuple(subst(u, name, value) for u in t.args),
                t.label, t.descriptor)


@lru_cache(maxsize=None)
def active(t: Node) -> int:
    return 1 + sum(active(u) for u in t.args)


@lru_cache(maxsize=None)
def full(t: Node) -> int:
    return (1 + sum(full(u) for u in t.args)
            + (0 if t.descriptor is None else full(t.descriptor)))


@lru_cache(maxsize=None)
def occurs(t: Node, name: str) -> int:
    if t.kind == "var":
        return int(t.label == name)
    if t.kind in ("all", "ex") and t.label == name:
        return 0
    return sum(occurs(u, name) for u in t.args)


def max_active_arity(t: Node) -> int:
    return max([len(t.args)] + [max_active_arity(u) for u in t.args])


def sizes(t: Node) -> dict[str, int]:
    return {"active": active(t), "full": full(t)}


def show(t: Node) -> str:
    if t.kind in ("var", "const"):
        return t.label
    if t.kind == "bot":
        return "false"
    if t.kind == "app":
        return t.label + "(" + ",".join(show(u) for u in t.args) + ")"
    if t.kind in ("all", "ex"):
        return t.kind + " " + t.label + ". " + show(t.args[0])
    symbol = {"eq": "=", "and": " & ", "or": " | ", "imp": " -> "}[t.kind]
    return "(" + show(t.args[0]) + symbol + show(t.args[1]) + ")"


def ze(A: Node) -> Node:
    premise = all_("x", con("imp", con("or", eq(x, ZERO), A),
                             subst(A, "x", S(x))))
    conclusion = all_("n", con("or", eq(n, ZERO), subst(A, "x", n)))
    return all_("a", con("imp", premise, conclusion))


def sp(A: Node) -> Node:
    premise = all_("x", con("imp", con("or", eq(x, ZERO), A),
                             subst(A, "x", S(x))))
    conclusion = all_("n", subst(A, "x", S(n)))
    return all_("a", con("imp", premise, conclusion))


def ordinary_induction(A: Node) -> Node:
    step = all_("x", con("imp", A, subst(A, "x", S(x))))
    base = subst(A, "x", ZERO)
    return all_("a", con("imp", con("and", base, step),
                          all_("n", subst(A, "x", n))))


def ite(r: Node, u: Node, t: Node) -> Node:
    return Q(Z(r, S(u)), t)


def compiler(A: Node, mode: str) -> Node:
    """The actual three current compiler recipes, with macros expanded."""
    if A.kind == "eq":
        return chi(*A.args)
    if A.kind == "bot":
        return ZERO
    assert A.kind in ("and", "or", "imp")
    P, R = (compiler(u, mode) for u in A.args)
    if mode == "ite":
        if A.kind == "and":
            return ite(P, ZERO, R)
        if A.kind == "or":
            return ite(P, R, ONE)
        return ite(P, ONE, R)
    if mode == "q":
        if A.kind == "and":
            return Q(Q(P, ONE), R)
        if A.kind == "or":
            return Q(Q(P, Q(R, ONE)), ONE)
        return Q(Q(R, P), ONE)
    assert mode == "z"

    def N(t: Node) -> Node:
        return Z(t, ONE)

    def AND(t: Node, u: Node) -> Node:
        return Z(N(t), u)

    if A.kind == "and":
        return AND(P, R)
    if A.kind == "or":
        return N(AND(N(P), N(R)))
    return N(AND(P, N(R)))


def logical_counts(A: Node) -> dict[str, int]:
    if A.kind in ("eq", "bot"):
        return {"and": 0, "or": 0, "imp": 0}
    answer = {key: int(A.kind == key) for key in ("and", "or", "imp")}
    for child in A.args:
        count = logical_counts(child)
        for key in answer:
            answer[key] += count[key]
    return answer


FULL_EXCESS = {
    "ite": {"and": 5, "or": 6, "imp": 6},
    "q": {"and": 5, "or": 9, "imp": 5},
    "z": {"and": 5, "or": 17, "imp": 13},
}


def mask_package(t: Node, whole_body: bool, shifted: bool) -> tuple[Node, Node]:
    stored = Z(t, x) if whole_body else t

    def M(u: Node, z: Node) -> Node:
        return app("M_t", u, z, descriptor=stored)

    definition = all_("x", all_("a", eq(M(x, a), Z(t, x))))
    witness_arg = S(b) if shifted else b
    witness = all_("a", all_("n", ex("b", eq(M(Q(M(witness_arg, a), n), a), ZERO))))
    return definition, witness


def package_sizes(t: Node, whole_body: bool, shifted: bool) -> dict[str, object]:
    definition, witness = mask_package(t, whole_body, shifted)
    return {"definition": sizes(definition), "witness": sizes(witness),
            "sum": {"active": active(definition) + active(witness),
                    "full": full(definition) + full(witness)}}


def audit_formula(A: Node) -> dict[str, object]:
    f, F, k = active(A), full(A), occurs(A, "x")
    assert max_active_arity(A) <= 2
    assert 2*k <= f+1 <= F+1
    assert k <= F-1
    assert active(ze(A)) == 3*f+k+13
    assert full(ze(A)) == 3*F+k+13
    assert active(sp(A)) == 3*f+2*k+9
    assert full(sp(A)) == 3*F+2*k+9
    assert full(ordinary_induction(A)) == 4*F+k+6
    assert full(ze(A)) <= 4*F+12
    assert full(sp(A)) <= 4*F+10
    compiler_rows = {}
    lc = logical_counts(A)
    for mode in ("ite", "q", "z"):
        t = compiler(A, mode)
        T, m = full(t), active(t)
        assert T == F + sum(lc[key]*FULL_EXCESS[mode][key] for key in lc)
        assert T >= F
        packages = {}
        for whole_body in (False, True):
            for shifted in (False, True):
                result = package_sizes(t, whole_body, shifted)
                c = (31 if whole_body else 22) + int(shifted)
                assert result["sum"]["full"] == c+4*T
                assert result["sum"]["active"] == 20+m+int(shifted)
                assert result["sum"]["full"] - full(ze(A)) >= 10
                assert result["sum"]["full"] - full(sp(A)) >= 12
                key = ("whole" if whole_body else "tail") + ("_W13" if shifted else "_W12")
                packages[key] = result
        compiler_rows[mode] = {"truth_term": sizes(t), "packages": packages}
    return {"formula": show(A), "formula_sizes": {"active": f, "full": F},
            "active_x_occurrences": k, "connective_counts": lc,
            "ZE": sizes(ze(A)), "SP": sizes(sp(A)),
            "ordinary_induction": sizes(ordinary_induction(A)),
            "optimistic_old_full_floor": 22+4*F,
            "ZE_saving_against_floor": 22+4*F-full(ze(A)),
            "SP_saving_against_floor": 22+4*F-full(sp(A)),
            "compilers": compiler_rows}


def main() -> None:
    sep = neg(eq(ZERO, ONE))
    bit = all_("x", all_("y", con("and", eq(chi(x, x), ONE),
                                       con("or", eq(x, y), eq(chi(x, y), ZERO)))))
    cov = all_("x", ex("y", con("or", eq(x, ZERO), eq(x, S(y)))))
    part = all_("x", ex("y", neg(eq(chi(x, ZERO), chi(x, S(y))))))
    assert sizes(sep) == {"active": 6, "full": 6}
    assert sizes(bit) == {"active": 18, "full": 18}
    assert sizes(cov) == {"active": 10, "full": 10}
    assert sizes(part) == {"active": 12, "full": 12}

    # A legal shared arithmetic body with a genuinely nested frozen descriptor.
    h0 = S(v)
    h1 = app("R_h0", v, w, descriptor=h0)
    nested_left = app("R_h1", S(x), a, descriptor=h1)
    nested_right = app("R_h0", x, S(a), descriptor=h0)
    frozen_call = app("R_h1", v, a, descriptor=h1)
    replaced = subst(frozen_call, "v", S(v))
    assert replaced.descriptor == frozen_call.descriptor
    assert active(replaced) == active(frozen_call)+1
    assert full(replaced) == full(frozen_call)+1
    assert occurs(frozen_call, "v") == 1  # Does not descend into h1 or h0.

    atoms = [BOT, eq(x, a), eq(x, x), eq(nested_left, nested_right)]
    one_connective = [con(op, P, R)
                     for op in ("and", "or", "imp") for P in atoms for R in atoms]
    two_connectives = [con(op, P, R)
                      for op in ("and", "or", "imp")
                      for smaller, larger in ((atoms, one_connective),
                                              (one_connective, atoms))
                      for P in smaller for R in larger]
    corpus = atoms + one_connective + two_connectives
    minimum_ze = None
    minimum_sp = None
    for A in corpus:
        checked = audit_formula(A)
        minimum_ze = min(minimum_ze if minimum_ze is not None else 10**9,
                         checked["ZE_saving_against_floor"])
        minimum_sp = min(minimum_sp if minimum_sp is not None else 10**9,
                         checked["SP_saving_against_floor"])

    C = con("or", eq(x, ZERO), eq(x, S(Q(x, ZERO))))
    BC = con("and", C, subst(C, "x", Q(x, ZERO)))
    coverage_bootstrap = sp(BC)
    assert full(coverage_bootstrap) == 117
    assert active(coverage_bootstrap) == 102

    samples = {
        "equality_parameter": eq(x, a),
        "equality_diagonal": eq(x, x),
        "falsity": BOT,
        "successor_congruence": con("imp", eq(x, a), eq(S(x), S(a))),
        "nested_frozen_recursors": eq(nested_left, nested_right),
        "mixed_connectives": con("or", con("and", eq(x, a), eq(x, x)),
                                  con("imp", eq(S(x), a), BOT)),
    }
    result = {
        "status": "passed",
        "scope": "Finite AST accounting checks; universal theorems require the written structural proofs.",
        "corpus": {"formulas": len(corpus), "maximum_connective_nodes": 2,
                   "compiler_modes": ["ite", "q", "z"],
                   "minimum_ZE_saving_against_22_plus_4F": minimum_ze,
                   "minimum_SP_saving_against_22_plus_4F": minimum_sp},
        "fixed_bases": {"Sep": sizes(sep), "Bit": sizes(bit), "Cov": sizes(cov),
                        "Part": sizes(part), "direct_ZE": 6,
                        "SP_with_explicit_Cov": 16,
                        "current_Sep_plus_Bit": 24,
                        "current_Bit_plus_Part": 30},
        "SP_coverage_bootstrap": {"formula_sizes": sizes(BC),
                                  "active_x_occurrences": occurs(BC, "x"),
                                  "axiom_sizes": sizes(coverage_bootstrap),
                                  "note": "A one-time additional schema instance needed by the no-Cov SP route."},
        "frozen_substitution": {"passed": True, "before": sizes(frozen_call),
                                "after": sizes(replaced)},
        "formulas": {name: audit_formula(A) for name, A in samples.items()},
    }
    destination = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("count_results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(destination),
                      "corpus": result["corpus"], "fixed_bases": result["fixed_bases"],
                      "sample_counts": {name: {"F": row["formula_sizes"]["full"],
                                               "k": row["active_x_occurrences"],
                                               "ZE": row["ZE"]["full"],
                                               "SP": row["SP"]["full"]}
                                        for name, row in result["formulas"].items()}}, indent=2))


if __name__ == "__main__":
    main()
