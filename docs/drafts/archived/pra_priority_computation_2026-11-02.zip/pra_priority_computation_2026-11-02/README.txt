A SMALLER COMPUTATION AXIOM FOR PRA
Research iteration, 2 November 2026
Source snapshot: df8fb0bbd19b6b8442b78569d38b9d888e4e7a0d

START HERE
  report.pdf                 Complete report and proofs (compiled from TeX).
  AXIOMS.txt                 Exact recommended specification and selectors.
  report.tex                 Main LaTeX source.
  arithmetic_appendix.tex    Complete arithmetic and interpretation proofs.

RESULTS
1. Complete computation envelope:
   min(3H+13+k(H+2), 3H+22, 2H+32),
   improving the current 2H+34 table alternative.
2. Retain one literal 27-node forward boundary for x=S(R_w(x,0)); use
   min(2F+i+11,F+18) for all other equations. This derives coverage without
   its separate ten-node axiom. On coverage-complete common packets, the
   eight-node net saving is explicit: delete10 and pay2 at the exception.
3. The new theory and matching classical/intuitionistic first-order PRA
   are bi-interpretable and equiconsistent, with full domains, native equality,
   and identity composites. This is proved in writing, not inferred from
   standard-model computation or a mere conservation theorem.

LIMITS
These are improvements under the inspected drafts' full syntax-tree metric,
not an absolute minimum over all signatures and logics. A finite export must
charge any missing bootstrap and the J definition. Alternative discriminator,
unary-iterator, and relational languages have independent interpretation costs.
No uniform priority-table-only axiomatization is claimed: the minimum selector
retains the small seed recursor equations needed to prove the table's converse.

REBUILD
  python3 build.py

This runs the standard-library Python checks and pdflatex three times. It does
not automatically install or run Lean. To replay the OPTIONAL local Lean source
with a functioning Lean 4.19.0 installation:
  lean formal/PriorityComputation.lean

VERIFICATION
  checks.py                   Literal AST construction, frozen substitution,
                              selectors, cost identities, countermodels,
                              bounded computation/scanner diagnostics.
  verification/results.json   Recorded check results and emitted example ASTs.
  verification/checks.txt     Human-readable checker output.
  verification/pdf_build.txt  Recorded final build diagnostics.
  verification/STATUS.txt     Scope and final validation record.
  formal/PriorityComputation.lean
                              Supplemental constructive local kernel source.
  formal/VERIFICATION_STATUS.txt
                              Explicit UNCOMPILED status and runtime diagnostic.

SOURCES AND INTEGRITY
  provenance/sources.json     Six current and five archived ZIPs: immutable URLs,
                             Git blob hashes, SHA-256 hashes, and filter result.
  SHA256SUMS.txt              Integrity manifest for the deliverable files.

ATTRIBUTION
The arithmetic reconstruction, weak conditional, direct and predecessor
boundary architectures, and prior shared-computation table are inherited
from the reviewed ProveIt reports and credited in the PDF. New claims concern
the 2H+32 table with its noncircular counter-toggle bootstrap, the literal
coverage exception, and the resulting compatible cost comparisons.
