#!/usr/bin/env python3
"""Rebuild the mathematical report and its Python checks; never downloads tools."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
VER = ROOT / "verification"
VER.mkdir(exist_ok=True)

def run(args, log):
    result = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, check=False)
    log.write_text(result.stdout)
    if result.returncode:
        sys.stderr.write(result.stdout)
        raise SystemExit(result.returncode)
    return result.stdout

run([sys.executable, "checks.py"], VER / "checks.txt")
outputs = []
for i in range(3):
    output = run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                 VER / "pdf_build.txt")
    outputs.append(output)
last = outputs[-1]
bad = [line for line in last.splitlines() if "Overfull" in line or
       "undefined references" in line or "multiply defined" in line or
       "destination with the same identifier" in line]
if bad:
    sys.stderr.write("Build produced review diagnostics:\n" + "\n".join(bad) + "\n")
    raise SystemExit(2)
print("PASS: Python checks; three-pass PDF build; no selected layout/reference warnings.")
print("Lean was not run. See formal/VERIFICATION_STATUS.txt.")
