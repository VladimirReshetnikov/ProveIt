import Std

/-!
A constructive kernel for the priority computation table.
This file uses no arithmetic library, no `axiom`, no `sorry`, and no
classical-choice tactic. All arithmetic assumptions are displayed.
-/

namespace PriorityComputation

universe u
variable {α : Type u}

/-- The weak logical conditional used in the source drafts. -/
def W (A U V : Prop) : Prop := (A ∨ U) ∧ (A → V)

/-- The ordinary initialized-recursion equations. -/
def RecursionLaws (z : α) (s : α → α) (R h : α → α → α) : Prop :=
  (∀ a, R z a = a) ∧ (∀ a n, R (s n) a = h (R n a) n)

/-- A table containing the generated symbol R exactly once. -/
def PriorityTable (z : α) (s : α → α) (R h : α → α → α) : Prop :=
  ∀ a n, ∃ u, ∀ x y, R x a = y →
    W (x = n)
      (W (x = z) (x = s n → y = h u n) (y = a))
      (y = u)

/-- The forward direction needs no arithmetic assumption or equality decision. -/
theorem recursion_implies_priority
    (z : α) (s : α → α) (R h : α → α → α)
    (laws : RecursionLaws z s R h) : PriorityTable z s R h := by
  rcases laws with ⟨base, step⟩
  intro a n
  refine ⟨R n a, ?_⟩
  intro x y graph
  constructor
  · apply Or.inr
    constructor
    · apply Or.inr
      intro endpoint
      calc
        y = R x a := graph.symm
        _ = R (s n) a := congrArg (fun t => R t a) endpoint
        _ = h (R n a) n := step a n
    · intro endpoint
      calc
        y = R x a := graph.symm
        _ = R z a := congrArg (fun t => R t a) endpoint
        _ = a := base a
  · intro endpoint
    calc
      y = R x a := graph.symm
      _ = R n a := congrArg (fun t => R t a) endpoint

/-- Recover both equations from the table after the two constructor facts. -/
theorem priority_implies_recursion
    (z : α) (s : α → α) (R h : α → α → α)
    (successor_ne_zero : ∀ n, s n ≠ z)
    (successor_ne_self : ∀ n, s n ≠ n)
    (table : PriorityTable z s R h) : RecursionLaws z s R h := by
  constructor
  · intro a
    obtain ⟨u, probe⟩ := table a (s z)
    have at_zero := probe z (R z a) rfl
    rcases at_zero.1 with impossible | inner
    · exact False.elim (successor_ne_zero z impossible.symm)
    · exact inner.2 rfl
  · intro a n
    obtain ⟨u, probe⟩ := table a n
    have current : R n a = u := (probe n (R n a) rfl).2 rfl
    have at_next := probe (s n) (R (s n) a) rfl
    rcases at_next.1 with impossible | inner
    · exact False.elim (successor_ne_self n impossible)
    · rcases inner.1 with impossible | update
      · exact False.elim (successor_ne_zero n impossible)
      · calc
          R (s n) a = h u n := update rfl
          _ = h (R n a) n := congrArg (fun t => h t n) current.symm

theorem priority_iff_recursion
    (z : α) (s : α → α) (R h : α → α → α)
    (successor_ne_zero : ∀ n, s n ≠ z)
    (successor_ne_self : ∀ n, s n ≠ n) :
    PriorityTable z s R h ↔ RecursionLaws z s R h :=
  ⟨priority_implies_recursion z s R h successor_ne_zero successor_ne_self,
   recursion_implies_priority z s R h⟩

/-- Q's constructor equations supply injectivity without induction. -/
theorem successor_injective_of_Q
    (z : α) (s : α → α) (Q : α → α → α)
    (Q_step : ∀ n a, Q (s n) a = n) : ∀ x y, s x = s y → x = y := by
  intro x y equal_successors
  calc
    x = Q (s x) z := (Q_step x z).symm
    _ = Q (s y) z := congrArg (fun t => Q t z) equal_successors
    _ = y := Q_step y z

/-- Q plus the sole separation sentence rules out a zero successor. -/
theorem successor_ne_zero_of_Q
    (z : α) (s : α → α) (Q : α → α → α)
    (separation : z ≠ s z)
    (Q_base : ∀ a, Q z a = a)
    (Q_step : ∀ n a, Q (s n) a = n) : ∀ n, s n ≠ z := by
  intro n impossible
  have n_zero : n = z := by
    calc
      n = Q (s n) z := (Q_step n z).symm
      _ = Q z z := congrArg (fun t => Q t z) impossible
      _ = z := Q_base z
  have : s z = z := by
    calc
      s z = s n := congrArg s n_zero.symm
      _ = z := impossible
  exact separation this.symm

/-- A single actual universal atomic boundary gives coverage. -/
theorem coverage_of_boundary
    (z : α) (s : α → α) (Q : α → α → α)
    (Q_step : ∀ n a, Q (s n) a = n)
    (boundary : ∀ n, ∃ b, ∀ x,
      W (x = s (Q x z)) (x = b → b = z) (x = s b → b = n)) :
    ∀ n, n = z ∨ ∃ p, n = s p := by
  intro n
  obtain ⟨b, probe⟩ := boundary n
  have after : s b = s (Q (s b) z) :=
    congrArg s (Q_step b z).symm
  have target : b = n := (probe (s b)).2 after rfl
  rcases (probe b).1 with covered | zero
  · exact Or.inr ⟨Q b z, target.symm.trans covered⟩
  · exact Or.inl (target.symm.trans (zero rfl))

/--
Coverage and the zero-toggle recurrence rule out fixed points.
No induction, order, Boolean test, or equality decision is used.
-/
theorem successor_ne_self_of_toggle
    (z : α) (s : α → α) (Z : α → α → α) (t : α → α)
    (separation : z ≠ s z)
    (successor_ne_zero : ∀ n, s n ≠ z)
    (coverage : ∀ n, n = z ∨ ∃ p, n = s p)
    (Z_base : ∀ a, Z z a = a)
    (Z_step : ∀ n a, Z (s n) a = z)
    (toggle_step : ∀ n, t (s n) = Z (t n) (s z)) :
    ∀ n, s n ≠ n := by
  intro n impossible
  have toggle_fixed : t n = Z (t n) (s z) := by
    calc
      t n = t (s n) := congrArg t impossible.symm
      _ = Z (t n) (s z) := toggle_step n
  rcases coverage (t n) with zero | ⟨p, successor⟩
  · have false_separation : z = s z := by
      calc
        z = t n := zero.symm
        _ = Z (t n) (s z) := toggle_fixed
        _ = Z z (s z) := congrArg (fun v => Z v (s z)) zero
        _ = s z := Z_base (s z)
    exact separation false_separation
  · have false_successor : s p = z := by
      calc
        s p = t n := successor.symm
        _ = Z (t n) (s z) := toggle_fixed
        _ = Z (s p) (s z) := congrArg (fun v => Z v (s z)) successor
        _ = z := Z_step p (s z)
    exact successor_ne_zero p false_successor


/-- The cheaper counter-toggle body Z(v,w) supplies the same bootstrap. -/
theorem successor_ne_self_of_counter_toggle
    (z : α) (s : α → α) (Z : α → α → α) (t : α → α)
    (successor_ne_zero : ∀ n, s n ≠ z)
    (coverage : ∀ n, n = z ∨ ∃ p, n = s p)
    (Z_base : ∀ a, Z z a = a)
    (Z_step : ∀ n a, Z (s n) a = z)
    (toggle_step : ∀ n, t (s n) = Z (t n) n) :
    ∀ n, s n ≠ n := by
  intro n impossible
  have n_ne_zero : n ≠ z := by
    intro equal_zero
    exact successor_ne_zero n (impossible.trans equal_zero)
  have toggle_fixed : t n = Z (t n) n := by
    calc
      t n = t (s n) := congrArg t impossible.symm
      _ = Z (t n) n := toggle_step n
  rcases coverage (t n) with zero | ⟨p, successor⟩
  · have false_zero : z = n := by
      calc
        z = t n := zero.symm
        _ = Z (t n) n := toggle_fixed
        _ = Z z n := congrArg (fun v => Z v n) zero
        _ = n := Z_base n
    exact n_ne_zero false_zero.symm
  · have false_successor : s p = z := by
      calc
        s p = t n := successor.symm
        _ = Z (t n) n := toggle_fixed
        _ = Z (s p) n := congrArg (fun v => Z v n) successor
        _ = z := Z_step p n
    exact successor_ne_zero p false_successor

#print axioms recursion_implies_priority
#print axioms priority_implies_recursion
#print axioms priority_iff_recursion
#print axioms successor_injective_of_Q
#print axioms successor_ne_zero_of_Q
#print axioms coverage_of_boundary
#print axioms successor_ne_self_of_counter_toggle
#print axioms successor_ne_self_of_toggle

end PriorityComputation
