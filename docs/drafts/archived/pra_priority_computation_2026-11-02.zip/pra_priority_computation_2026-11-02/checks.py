#!/usr/bin/env python3
"""Literal AST checks and bounded semantic diagnostics for the accompanying report.

No third-party packages are required. This is NOT a formalization of first-order
PRA or of its interpretation theorem. The full proofs are in the report.
Run: python3 checks.py [--output verification/results.json]
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass
import itertools
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Node:
    tag: str
    kids: tuple["Node", ...] = ()
    value: str = ""
    descriptor: "Node | None" = None


def V(name): return Node("var", value=name)
Z0 = Node("0")
BOT = Node("false")
def S(t): return Node("S", (t,))
def R(h, t, a): return Node("R", (t, a), descriptor=h)
def Eq(l, r): return Node("=", (l, r))
def Imp(l, r): return Node("->", (l, r))
def And(l, r): return Node("and", (l, r))
def Or(l, r): return Node("or", (l, r))
def J(a, u, v): return Node("J", (a, u, v))
def All(names, body):
    for name in reversed(names.split()):
        body = Node("forall", (body,), value=name)
    return body
def Ex(name, body): return Node("exists", (body,), value=name)


def size(t):
    return 1 + sum(map(size, t.kids)) + (size(t.descriptor) if t.descriptor else 0)


def occurrences(t, name):
    if t.tag == "var": return int(t.value == name)
    if t.tag in ("forall", "exists") and t.value == name: return 0
    # The stored descriptor is deliberately not an active argument.
    return sum(occurrences(k, name) for k in t.kids)


def free(t):
    if t.tag == "var": return {t.value}
    out = set().union(*(free(k) for k in t.kids)) if t.kids else set()
    if t.tag in ("forall", "exists"): out.discard(t.value)
    return out


def subst(t, mapping):
    """Simultaneous, capture-checked substitution; descriptors remain frozen."""
    if t.tag == "var": return mapping.get(t.value, t)
    if t.tag in ("forall", "exists"):
        mapping = {k: v for k, v in mapping.items() if k != t.value}
        active = free(t.kids[0]) & mapping.keys()
        if any(t.value in free(mapping[k]) for k in active):
            raise ValueError("capture would occur; alpha-rename first")
    return Node(t.tag, tuple(subst(k, mapping) for k in t.kids),
                t.value, t.descriptor)


def sexp(t):
    if t.tag == "var": return t.value
    if not t.kids: return t.tag
    if t.tag == "R":
        return ["R", ["frozen", sexp(t.descriptor)], *map(sexp, t.kids)]
    if t.tag in ("forall", "exists"):
        return [t.tag, t.value, sexp(t.kids[0])]
    return [t.tag, *map(sexp, t.kids)]


a, n, u, x, y, b, v, w = map(V, "a n u x y b v w".split())


def computations(h):
    if not free(h) <= {"v", "w"}: raise ValueError("captured descriptor parameter")
    hn = subst(h, {"v": u, "w": n})
    rn = R(h, n, a)
    direct = (
        All("a", Eq(R(h, Z0, a), a)),
        All("a n", Eq(R(h, S(n), a), subst(h, {"v": rn, "w": n}))),
    )
    graph = All("a n u", Imp(Eq(rn, u), And(
        Imp(Eq(n, Z0), Eq(u, a)), Eq(R(h, S(n), a), hn))))
    endpoints = And(Imp(Eq(x, n), Eq(y, u)), Imp(Eq(x, S(n)), Eq(y, hn)))
    old_graph = All("x y", Imp(Eq(R(h, x, a), y), endpoints))
    old_table = All("a n", Ex("u", And(Imp(Eq(n, Z0), Eq(u, a)), old_graph)))
    inner = J(Eq(x, Z0), Imp(Eq(x, S(n)), Eq(y, hn)), Eq(y, a))
    outer = J(Eq(x, n), inner, Eq(y, u))
    priority = All("a n", Ex("u", All("x y", Imp(Eq(R(h, x, a), y), outer))))
    return {"O": direct, "G": (graph,), "T34": (old_table,), "P32": (priority,)}


E_STAR = Eq(x, S(R(w, x, Z0)))


def boundaries(e):
    if e.tag != "=" or not free(e) <= {"x", "a"}:
        raise ValueError("boundary index must be an equation in x,a")
    eb = subst(e, {"x": b})
    esb = subst(e, {"x": S(b)})
    d = All("a n", Ex("b", J(eb, Eq(b, Z0), Imp(esb, Eq(b, n)))))
    uf = All("a n", Ex("b", All("x", J(e,
        Imp(Eq(x, b), Eq(b, Z0)), Imp(Eq(x, S(b)), Eq(b, n))))))
    back = All("a n", Ex("b", All("x", J(e,
        Imp(Eq(S(x), b), BOT), Imp(Eq(x, b), Eq(b, n))))))
    dn = All("a n", Ex("b", J(eb, Or(Eq(b, n), esb), Eq(b, Z0))))
    return {"D": d, "U": uf, "B": back, "negative_D": dn}


def select_computation(h):
    options = computations(h)
    return min(("O", "G", "P32"), key=lambda key: sum(map(size, options[key])))


def select_boundary(e):
    if not occurrences(e, "x"): return None
    if e == E_STAR: return "U"
    options = boundaries(e)
    # B wins ties; there is no semantic or provability test.
    return min(("B", "D"), key=lambda key: size(options[key]))


def c_old(H, k): return min(3*H + 13 + k*(H+2), 3*H+22, 2*H+34)
def c_new(H, k): return min(3*H + 13 + k*(H+2), 3*H+22, 2*H+32)
def m20(F, i): return min(2*F+i+11, F+20)
def m18(F, i): return min(2*F+i+11, F+18)


def computation_export_cost(profiles, missing_bootstrap, conditional_available):
    """A conservative fallback. Missing support is an explicit input, never zero by default."""
    if missing_bootstrap < 0: raise ValueError("negative support cost")
    old = sum(c_old(H, k) for H, k in profiles)
    new = sum(c_new(H, k) for H, k in profiles)
    new += missing_bootstrap + (0 if conditional_available else 12)
    return {"old_unconditional": old, "new_with_support": new, "chosen": min(old, new)}


def boundary_export_cost(equations):
    """Sep + J + boundary interfaces; computation modules are separate, as disclosed."""
    es = set(e for e in equations if occurrences(e, "x"))
    saturated = es | {E_STAR}
    recommended = 6 + 12 + sum(size(boundaries(e)[select_boundary(e)]) for e in saturated)
    covered = 16 + 12 + sum(m18(size(e), occurrences(e, "x")) for e in es)
    forward = 6 + 12 + sum(m20(size(e), occurrences(e, "x")) for e in es)
    return {"recommended": recommended, "covered": covered,
            "forward_only": forward, "chosen": min(recommended, covered, forward)}


def W(A, U, V): return (A or U) and ((not A) or V)


def priority_holds(domain, successor, rec, update):
    def probe(a0, n0, u0, x0, y0):
        return rec(x0, a0) != y0 or W(x0 == n0,
            W(x0 == 0, x0 != successor(n0) or y0 == update(u0, n0), y0 == a0),
            y0 == u0)
    return all(any(all(probe(a0, n0, u0, x0, y0)
                       for x0 in domain for y0 in domain) for u0 in domain)
               for a0 in domain for n0 in domain)


def recursion_holds(domain, successor, rec, update):
    return all(rec(0, a0) == a0 for a0 in domain) and all(
        rec(successor(n0), a0) == update(rec(n0, a0), n0)
        for a0 in domain for n0 in domain)


def generated_descriptors():
    out = [Z0, v, w]
    for seed in (Z0, v, w):
        t = seed
        for _ in range(1, 130):
            t = S(t)
            out.append(t)
    rng = random.Random(20261102)
    frozen = (Z0, v, w, S(v), R(Z0, v, w), R(w, v, Z0))
    def term(depth):
        if depth == 0 or rng.randrange(5) == 0: return rng.choice((Z0, v, w))
        if rng.randrange(3) == 0: return S(term(depth-1))
        return R(rng.choice(frozen), term(depth-1), term(depth-1))
    out.extend(term(4) for _ in range(1200))
    return list(dict.fromkeys(out))


def run_checks():
    descriptors = generated_descriptors()
    for h in descriptors:
        H, k = size(h), occurrences(h, "v")
        mods = computations(h)
        got = {name: sum(map(size, module)) for name, module in mods.items()}
        expected = {"O": 3*H+13+k*(H+2), "G": 3*H+22,
                    "T34": 2*H+34, "P32": 2*H+32}
        assert got == expected, (sexp(h), got, expected)
        assert got[select_computation(h)] == c_new(H, k)
        assert all(not free(f) for module in mods.values() for f in module)

    # A targeted check detects accidental substitution inside frozen descriptions.
    frozen_example = R(v, v, w)
    replaced = subst(frozen_example, {"v": S(n), "w": a})
    assert replaced.descriptor == v and occurrences(replaced, "v") == 0
    assert size(replaced) == 5
    try:
        subst(All("n", Eq(x, n)), {"x": n})
        raise AssertionError("capture was not rejected")
    except ValueError:
        pass

    equations = [E_STAR, Eq(x, a), Eq(Z0, a)]
    equations += [Eq(subst(h, {"v": x, "w": a}), a) for h in descriptors]
    equations = list(dict.fromkeys(equations))
    for e in equations:
        F, i = size(e), occurrences(e, "x")
        bs = boundaries(e)
        assert size(bs["D"]) == size(bs["negative_D"]) == 2*F+i+11
        assert size(bs["U"]) == F+20
        assert size(bs["B"]) == F+18
        chosen = select_boundary(e)
        if i:
            actual = size(bs[chosen])
            assert actual == m18(F, i) + (2 if e == E_STAR else 0)
            assert actual <= m20(F, i)
        else:
            assert chosen is None
    assert (size(E_STAR), occurrences(E_STAR, "x"), select_boundary(E_STAR)) == (7, 2, "U")
    assert size(boundaries(E_STAR)["U"]) == 27

    seeds = [w, Z0, R(Z0, v, w)]
    seed_results = []
    for h in seeds:
        mods = computations(h)
        costs = {name: sum(map(size, module)) for name, module in mods.items()}
        assert select_computation(h) == "O"
        seed_results.append({"descriptor": sexp(h), "H": size(h),
                             "k": occurrences(h, "v"), "costs": costs})
    assert sum(item["costs"]["O"] for item in seed_results) == 63
    grid = 0
    for H in range(1, 251):
        for k in range(51):
            gap = max(0, min(2, H-10, H-19+k*(H+2)))
            assert c_old(H, k)-c_new(H, k) == gap
            grid += 1

    # Both local arithmetic hypotheses are necessary for P32 -> O.
    domain = (0, 1)
    rec = lambda t, a0: a0 if t == 0 else 0
    cases = [
        ("fixed_point", lambda _: 1, lambda v0, n0: n0),
        ("successor_zero", lambda t: 1-t, lambda v0, n0: 0),
    ]
    countermodels = []
    for name, successor, update in cases:
        assert priority_holds(domain, successor, rec, update)
        assert not recursion_holds(domain, successor, rec, update)
        countermodels.append({"name": name, "priority": True, "ordinary_recursion": False,
            "successor": [successor(t) for t in domain],
            "R_rows": [[rec(t, a0) for a0 in domain] for t in domain],
            "h_rows": [[update(v0, n0) for n0 in domain] for v0 in domain]})

    # Bounded natural computations exercise the forward table with its actual witness.
    natural_probes = 0
    updates = [lambda vv, ww: 0, lambda vv, ww: ww, lambda vv, ww: vv+1,
               lambda vv, ww: vv+ww, lambda vv, ww: (vv*vv+ww) % 17]
    for update in updates:
        for a0 in range(5):
            values = [a0]
            for n0 in range(25): values.append(update(values[-1], n0))
            for n0 in range(20):
                u0 = values[n0]
                for x0 in range(25):
                    y0 = values[x0]
                    assert W(x0 == n0,
                        W(x0 == 0, x0 != n0+1 or y0 == update(u0, n0), y0 == a0), y0 == u0)
                    natural_probes += 1

    # All Boolean predicates on a finite initial segment, forward and lagged scans.
    scanner_checks = 0
    for bits in itertools.product((False, True), repeat=9):
        cf = cb = 0
        for n0 in range(8):
            assert (cf == 0 or bits[cf]) and (not bits[cf+1] or cf == n0)
            assert (cb == 0 or bits[max(0, cb-1)]) and (not bits[cb] or cb == n0)
            for x0 in range(9):
                assert W(bits[x0], x0+1 != cb, x0 != cb or cb == n0)
            if bits[cf+1]: cf += 1
            if bits[cb]: cb += 1
            scanner_checks += 1

    # For an Ecov-saturated packet the saved fixed/boundary cost is exactly eight.
    boundary_packet = boundary_export_cost([E_STAR, Eq(S(S(S(x))), S(S(S(a))))])
    assert boundary_packet["covered"] - boundary_packet["recommended"] == 8
    isolated = computation_export_cost([(100, 1)], 90, True)
    common = computation_export_cost([(100, 1)], 0, True)
    no_j = computation_export_cost([(100, 1)], 0, False)
    assert isolated["chosen"] == 234 and common["chosen"] == 232
    assert no_j["chosen"] == 234  # Paying a missing definition changes the optimum.

    example_h = v
    for _ in range(99): example_h = S(example_h)
    return {"status": "PASS", "scope": "AST identities and bounded diagnostics, not a proof assistant",
        "distinct_descriptors": len(descriptors), "distinct_equations": len(equations),
        "saving_grid_cases": grid, "natural_table_probes": natural_probes,
        "scanner_invariant_cases": scanner_checks, "bootstrap": seed_results,
        "coverage_exception": {"F": 7, "i": 2, "cost": 27, "selected": "U"},
        "boundary_packet": boundary_packet, "computation_examples": {
            "missing_bootstrap": isolated, "common_bootstrap": common, "missing_J": no_j},
        "countermodels": countermodels,
        "example_axioms": {"h100_P32": sexp(computations(example_h)["P32"][0]),
                           "coverage_U": sexp(boundaries(E_STAR)["U"]),
                           "x_equals_a_selected": sexp(boundaries(Eq(x, a))[select_boundary(Eq(x, a))])}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("verification/results.json"))
    args = parser.parse_args()
    result = run_checks()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "example_axioms"}, indent=2))


if __name__ == "__main__": main()
