#!/usr/bin/env python3
"""Offline authored-report builder. Never executes input archives."""
from pathlib import Path
import argparse,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--pdf-only',action='store_true');args=p.parse_args()
 if not args.pdf_only:subprocess.run([sys.executable,str(ROOT/'run_checks.py')],cwd=ROOT,check=True)
 exe=shutil.which('pdflatex')
 if exe is None:raise SystemExit('Install/configure TeX Live with pdflatex, then rerun.')
 out=ROOT/'_build';out.mkdir(exist_ok=True)
 for i in range(1,4):
  q=subprocess.run([exe,'-interaction=nonstopmode','-halt-on-error','-no-shell-escape','-output-directory='+str(out),'report.tex'],cwd=ROOT,text=True,capture_output=True)
  (out/f'pass-{i}.txt').write_text(q.stdout+q.stderr)
  if q.returncode:raise SystemExit('TeX failed; see '+str(out/f'pass-{i}.txt'))
 log=(out/'report.log').read_text(errors='replace')
 if any(x in log for x in ('Undefined control sequence','undefined references',r'Overfull \hbox',r'Overfull \vbox')):raise RuntimeError('TeX warning requires correction')
 shutil.copy2(out/'report.pdf',ROOT/'report.pdf')
 print('Built report.pdf. Visually inspect every page before redistribution.')
