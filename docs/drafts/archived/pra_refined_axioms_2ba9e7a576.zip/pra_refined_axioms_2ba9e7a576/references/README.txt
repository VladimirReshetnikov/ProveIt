STATIC INHERITED PROOF REFERENCES

These exact historical TeX texts are supplied for transparent source credit
and proof dependencies. They are never inputs to report.tex or build.sh.
The new report contains adapted, self-contained arithmetic bootstrap and
dyadic compiler proofs and its entire new relational-domain argument.

pairing_proof.tex is the original Unary Updates pairing proof, SHA256
d5e352980ae2801667b49647060c84bbd34fac02d7b4d85fb41af0ed626026bb.
literal_anchored_endpoint.tex is the earlier anchored arithmetic bootstrap;
the new report reconstructs all needed steps for its new boundary interface.

The top-level source_calibration.tex and two_tag_source_proof.tex, together
with references/alternate_signature.tex, retain the explicit inherited
finite-signature arithmetic/trace calibration and source graph translation.
The historical two-tag file uses the zero ROW; the new marker-free proof
states and proves its own zero COLUMN condition. Do not substitute the
old row formula into the new target seed.

Only these necessary proof texts are included, not the earlier full ZIPs
or PDFs. Historical references inside the exact originals to other sections
or older sealed reports retain their original meaning; they do not assert
those complete old archives are bundled here. Source hashes are recorded in
sources/reference_manifest.json. No downloaded TeX or program was executed.
