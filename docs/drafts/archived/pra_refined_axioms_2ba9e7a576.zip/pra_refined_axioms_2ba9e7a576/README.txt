PRA WITH SIGNED BOUNDARIES AND PRODUCT DOMAINS
Requested revision/main:2ba9e7a5767fee450c6611868fdf0c4d3a27754e
2 November2026

START HERE
report.pdf/report.tex contain the mathematical report; AXIOMS.txt extracts
complete recommended specifications. The latest benchmark is the five new
current proposals versus the eight newly archived predecessors. All five
improve an archived coordinate; current dominance is a separate question.
See sources/update_2ba9/update_2ba9_comparison.txt and its filter CSV/JSON.
The initial b306 snapshot is retained only as explicitly superseded history.

WHAT IS NEW AND WHAT IS RETAINED
The new scalar synthesis strips a literal outer negation before applying
an already-current strong conditional, with a constructive negative kernel.
For stripped native matrix size F it gives min(2F+i+12,F+20). In the literal
0,S,R_h language without primitive chi, nonvacuous raw tails have full cost
min(2T+i+15,T+22), versus the favorable current unrestricted-raw envelope
min(2T+i+15,T+24): up to two nodes saved, with exact support costs stated.
The strong conditional's definition skeleton is 14; its complete rules and
expansion are explicit, not free old-basis notation. Expanded raw cost is
2T+28. A separately priced primitive-chi companion retains eligible Boolean
4T+i+8 clauses; their small-tail exception is NOT silently discarded.
An optional literal maximal-negation-prefix scan works intuitionistically,
including even prefixes, without assuming double-negation elimination.
The D17 companion has min(2T+2i+15,T+23); its D24 covered companion keeps
DB/U/CB and has min(2T+2i+15,2T+18,T+23), with distinct fixed seed prices.

The primary structural theory has0,S,p, autonomous unary iteration, and
one initialized-iterator-anchored boundary equation with one arbitrary
later right term. Its fixed basis16 improves the matched intermediate
fixed-Q unary core's20active/22full nodes. It adds primitivep relative to
the current native0,S signature, while restricting computation/admission.
Its complete arbitrary-model bootstrap, pairing, parameter compiler and
both identity composites are included. Inherited proof components are credited.

Domain alternatives are fully priced. A standard two-sort product interface
has64fixed nodes in the old basis or42with ordinary primitive iff; recurring
translated source bodies costN+2r. The function-free E(binary),O(unary)
interface has134fixed and N+16r+3q+22 recurring. Named-constant variants are
separate. These are not one-symbol or arbitrary-arity minimum claims; the
named quaternary source itself has36/22fixed and direct recurringN.

The current rawT+28 and native strong-conditionalF+20 results are INPUTS,
not new counts. Earlier in-progressE35/iff34/D41 candidates were superseded
by the user update and are not recommendations or the final generator.
No SC outerQ-to-Z substitution is asserted: its input can be2.

OFFLINE BUILD AND CHECKS
Requirements: Python3.10+ standard library, TeX Live with pdflatex and
amsmath/amssymb/amsthm/mathtools/lmodern/booktabs/array/longtable/needspace/
hyperref/geometry. Poppler is used separately for visual QA.
  python3 run_checks.py
  sh build.sh --pdf-only
  sh build.sh                 # checks then build
The builder creates only local _build formats/maps/logs and disables shell
escape. Static historical texts in references/, source_calibration.tex and
two_tag_source_proof.tex are NOT build inputs. The report's included texts
are authored or explicitly adapted proof sections.

Every executed Python file is checked for zero ast.Assert nodes; exceptions
remain active under -O. Normal/-O byte identity is recorded as well. Scripts
include exact syntax ledgers, current-source comparisons, scalar core and
finite relational/Kripke diagnostics; some audit diagnostics retain historical
candidate profiles solely to reproduce the supersession review. Finite checks
are not proof-assistant certificates or substitutes for the written proofs.

ARTIFACTS AND PROVENANCE
artifacts/relational/ contains portable fresh AST generators,37serialized
formulas, independent auditors, finite diagnostics and a standalone validator.
They execute only locally authored code, never the static source references.
sources/update_2ba9/ pins all13 current-snapshot archives and every extracted
payload hash;429regular payloads and373 supplied checksums were verified.
The eight archived files are byte-identical moves from the initial snapshot.
No downloaded code, Lean object, build script or TeX source was executed;
no repository mutation occurred. No old ZIP/PDF is nested in this package.
source_manifest.json records all delivered sources and authored adaptations.

SUPPLEMENTS
Optional tuple/function-domain scope notes and a minimal-logic derivation of
explosion are included as unbuilt TeX. The latter applies only to a theory
with an actually present separation clause and the stated zero iterator;
its extra logical primitive and finite support are explicitly priced.
These supplements are not additional numerical frontier records.

See VALIDATION.txt and audit/ for independent mathematical reviews, complete
page-by-page PDF QA, and an isolated extracted-ZIP checks/build replay.
