#!/usr/bin/env python3
"""Offline validation of authored round10 diagnostics, with explicit checks."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
COMMANDS = [
    'artifacts/review/check_current_profiles.py',
    'artifacts/review/check_frontier_counts_independent.py',
    'artifacts/review/check_raw_once_copy.py',
    'artifacts/induction/check_boundary_reductions.py',
    'artifacts/review/check_updated_frontier.py',
    'artifacts/induction/check_signed_boundary.py',
    'artifacts/review/check_signed_conditional.py',
    'artifacts/recursion/check_predecessor_core.py',
]

def main():
    inventory = []
    for f in sorted(ROOT.rglob('*.py')):
        if any(x in ('_build', '__pycache__') for x in f.relative_to(ROOT).parts):
            continue
        count = sum(isinstance(x, ast.Assert) for x in ast.walk(ast.parse(f.read_text())))
        if count:
            raise RuntimeError('Removable assertion: '+str(f.relative_to(ROOT)))
        inventory.append({'path': str(f.relative_to(ROOT)), 'sha256': hashlib.sha256(f.read_bytes()).hexdigest(), 'assert_count': 0})
    commands = COMMANDS[:]
    if (ROOT/'artifacts/relational/validate_relational.py').exists():
        commands.append('artifacts/relational/validate_relational.py')
    results = []
    for rel in commands:
        f = ROOT/rel
        outputs = []
        for flags in ([], ['-O']):
            p = subprocess.run([sys.executable, *flags, str(f)], cwd=f.parent,
                               capture_output=True, text=True, check=True)
            outputs.append(p.stdout)
        if outputs[0] != outputs[1]:
            raise RuntimeError('Normal/-O mismatch: '+rel)
        result = json.loads(outputs[0])
        if str(result.get('status', '')).lower() not in ('pass', 'passed'):
            raise RuntimeError('Non-PASS: '+rel)
        evidence = f.with_name(f.stem+'.replay.json')
        evidence.write_text(outputs[0])
        results.append({'script': rel, 'normal_optimized_byte_identical': True,
                        'stdout_sha256': hashlib.sha256(outputs[0].encode()).hexdigest()})
        print('PASS '+rel, flush=True)
    output = {'status': 'PASS', 'script_inventory': inventory, 'checks': results,
              'scope': 'Authored finite syntax and semantic diagnostics only; not theorem certification.'}
    (ROOT/'artifacts/replay_validation.json').write_text(json.dumps(output, indent=2)+'\n')

if __name__ == '__main__':
    main()
