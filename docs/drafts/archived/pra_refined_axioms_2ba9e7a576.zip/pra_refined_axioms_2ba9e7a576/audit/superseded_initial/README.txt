These audit notes concern mathematically valid candidates developed before
commit2ba9e7a576. Their node improvements were superseded by the new input.
They are preserved only to document the review history, not as final frontier
claims. The associated candidate TeX/emitter is not a build input or final
recommended generator. See sources/update_2ba9/update_2ba9_comparison.txt.
