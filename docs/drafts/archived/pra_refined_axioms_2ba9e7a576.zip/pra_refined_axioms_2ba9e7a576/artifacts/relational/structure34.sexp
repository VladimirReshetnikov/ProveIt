(forall x (or (and (O x) (forall r (imp (O r) (imp (E x r) false)))) (exists b (exists c (and (and (O b) (O c)) (forall r (imp (and (E b r) (E r c)) (= r x))))))))
