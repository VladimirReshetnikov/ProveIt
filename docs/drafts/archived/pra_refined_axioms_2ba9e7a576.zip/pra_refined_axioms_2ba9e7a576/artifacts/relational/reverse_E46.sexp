(or (and (= u 0) (= r (+ v 1))) (exists b (and (= u (+ b 1)) (or (or (and (= r 0) (= v s)) (and (= r 1) (= s (+ b v)))) (and (= r (+ 1 1)) (= s (* b v)))))))
