(forall p (exists x (exists y (forall t (forall w (iff (= p (pi t w)) (and (= t x) (= w y))))))))
