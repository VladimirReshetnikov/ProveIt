(forall t (forall x (forall y (exists u (forall w (iff (Data (pi x y) (pi t w)) (and (or (= t z) (= t a)) (= w u))))))))
