# PRA domain/signature alternatives — round 10

Run `python3 validate_relational.py` using standard Python 3. It replays only
freshly authored scripts in two clean directories, normally and under `-O`.
No third-party dependency, previous workspace, archived program or network
access is needed. Checks use explicit exceptions; the runner verifies zero
Python `assert` statements and byte-identical AST/JSON/stdout across modes.

## Frozen results, not interchangeable metrics

* **Function-free, one sort, E binary + O unary:** one 134-node fixed sentence;
  each arithmetic body costs `N+16r+3q+22`. Reverse domain is the whole square;
  reverse E has 46 nodes in `{0,1,+,*}`, with no predecessor primitive.
* **Named E,O,z,a option:** four fixed sentences total 118 nodes (one integrated
  sentence120); recurring `N+16r+3q`. The two constants are explicitly charged.
* **Two sorts A,P; pi:A×A→P, Data:P×P; z,a:A:** two fixed sentences total 64
  nodes in the original expanded-connective basis; each arithmetic body costs
  `N+2r`. With primitive biconditional those two sentences total 42 instead.
  Conjoining the clauses adds one node. Literal expansion of the42-node
  presentation is76, not64;64 is an equivalent factored presentation.

These change signature and/or domains. They do not dominate the inherited
one-binary-relation155/30 presentation in symbol count. `basis_comparison.tex`
also reprices that incumbent129/30 with primitive biconditional, so comparisons
do not silently switch connective bases. The source axiom family is infinite;
N,r,q measure its complete relation-only body in the stated basis.

Every term-variable/constant occurrence, predicate/function occurrence,
connective and quantifier costs one syntax-tree node; binder labels are not
extra nodes. Negation is expanded as implication to false. Primitive iff is
used only in explicitly labelled native-iff columns. Sort/function/constant
declarations are stated as signature/interface costs, not hidden predicates.
Labels z,a in named ASTs denote the declared constants; in the unnamed ASTs
they are bound by the displayed quantifiers. The unrestricted reverse square
needs no domain restriction; its explicit tautology `u=u` would cost3, and
coordinate equality costs7.

## Complete mathematical sources

`marker_free_proof.tex` provides all axioms, the finite noncircular bootstrap,
weak-output recovery, guard uniqueness, coordinate rigidity, every edge class,
whole-square reverse interpretation and both complete definable composites.
`product_sort_proof.tex` gives the ordinary many-sorted theory, exact data
reconstruction and both whole-sort composites. Both proofs apply separately
in intuitionistic and classical logic; no initiality or categorical-number
axiom is used. `basis_comparison.tex` isolates the connective/signature prices.

The static `source_references/` files retain the credited arithmetic source:
`source_calibration.tex`, `two_tag_source_proof.tex`, and
`references/alternate_signature.tex`. They specify the effective full source
axiom generator and inherited fixed-program trace calibration with PRA.
There is no assumed total universal primitive-recursive evaluator. These
reference texts were copied byte-for-byte from the sealed prior archive,
whose hash is recorded in `PORTABILITY_PROVENANCE.json`; no old executable
is included or run. They are written proofs, not formal-kernel certificates.

## Reproducibility

* `marker_free.py`, `product_sort.py`, `basis_table.py`: fully expanded ASTs,
  target/body translation rules, reverse definitions, and all exact costs.
* `check_domains.py`: exhaustive small E/O structures; arbitrary operation
  tables; edge mutations; reverse edge/decoder comparisons; pair-interface
  and typed source logical equivalences over finite sets.
* `check_marker_free_kripke.py`: persistent E and O valuations on chain/fork
  frames, genuinely nonconstant models, and a private-coordinate negative control.
* `check_unary_object_graph.py`, `check_product_sort_independent.py`: independent
  authoring of the principal ledgers and finite tests; copied unchanged.
* `check_guard_obstructions.py`: rejected fixed-guard deletion countermodels,
  not an advertised smaller theory.
* `final_relational_validation.json`: fresh two-mode replay and source/output
  hashes. The validator independently parses and recounts the serialized ASTs.

All finite checks are diagnostics, not finite models of full PRA or proofs of
arbitrary-model validity. The constructive mathematical proofs carry those
obligations. The two-sorted interface has explicit bijection axioms covering
its whole pair sort, so no unmatched extra elements or data tuples are ignored.
