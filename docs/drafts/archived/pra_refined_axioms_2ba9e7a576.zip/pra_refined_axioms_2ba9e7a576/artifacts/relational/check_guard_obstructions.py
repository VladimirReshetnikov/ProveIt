#!/usr/bin/env python3
"""Fresh finite controls for round10 guard-deletion proposals.
No archived or downloaded executable is imported. All checks survive -O.
"""
import itertools,json,pathlib

def require(test,message):
 if not test:raise RuntimeError(message)
def graph(n,relation):
 marker=('marker',);objects={i:('object',i) for i in range(n)}
 pairs={(i,j):('pair',i,j) for i,j in itertools.product(range(n),repeat=2)}
 vertices={marker}|set(objects.values())|set(pairs.values())
 edges={(objects[i],marker) for i in range(n)}
 edges|={(objects[i],pairs[i,j]) for i,j in pairs}
 edges|={(pairs[i,j],objects[j]) for i,j in pairs}
 edges|={(pairs[x,y],pairs[t,w]) for t,x,y,w in relation}
 return vertices,edges,marker,objects,pairs
def neighborhoods(vertices,edges):
 return ({v:{w for vv,w in edges if vv==v} for v in vertices},
         {v:{w for w,vv in edges if vv==v} for v in vertices})
def L(z,a,nxt,prev):return any(prev[z]<=prev[q] for q in nxt[a])
def structure(vertices,edges,m,nxt,prev):
 objects=prev[m]
 return not nxt[m] and all(v==m or (v in objects and not nxt[v]&objects) or any(nxt[b]&prev[c]<={v} for b,c in itertools.product(objects,repeat=2)) for v in vertices)
def decoded(t,x,y,nxt,prev):
 first=nxt[x]&prev[y]
 seconds=set().union(*(nxt[p]&nxt[t] for p in first)) if first else set()
 return set().union(*(nxt[q] for q in seconds)) if seconds else set()
def weak_H(vertices,objects,z,a,nxt,prev):
 for x,y,t in itertools.product(objects,repeat=3):
  outputs=decoded(t,x,y,nxt,prev);typed=outputs&objects;selected=t==z or t==a
  if not any((t!=a or y!=z or u==z) and (not selected or u in outputs) and all(selected and w==u for w in typed) for u in vertices):return False
 return True

def main():
 # One tagged XOR operation has no constant column. The typed L13 guard
 # consequently never holds, so the entire arithmetic family is vacuous.
 relation={(0,x,y,x^y) for x,y in itertools.product(range(2),repeat=2)}
 V,E,m,objects,pairs=graph(2,relation);nxt,prev=neighborhoods(V,E)
 require(structure(V,E,m,nxt,prev),'Canonical finite graph lost structure49')
 require(all(nxt[v] for v in V-{m}),'Nonmarker lacks wrapper witness')
 require(not any(L(z,a,nxt,prev) for z,a in itertools.product(prev[m],repeat=2)),'Unexpected arithmetic guard')
 for omitted,z,a in [('unit',objects[0],m),('zero',m,objects[0])]:
  require(weak_H(V,prev[m],z,a,nxt,prev),'Weak source failed for missing '+omitted+' guard')
  require((z in prev[m]) != (a in prev[m]),'Exactly one parameter must be typed')
 # A uniform wrapper deletion is not valid even on canonical arithmetic:
 # local marker O1, parameters z=a=P11, witness q=P11.
 # Its L clause is tautological, while the valid test body zero!=one fails.
 relation={(t,x,y,(x+y if t==0 else x*y)) for t,x,y in itertools.product(range(2),repeat=3) if (x+y if t==0 else x*y)<2}
 V,E,m,objects,pairs=graph(2,relation);nxt,prev=neighborhoods(V,E)
 fake_marker=objects[1];z=a=q=pairs[1,1]
 require((z,fake_marker) in E and (a,fake_marker) in E and (a,q) in E,'Wrapper control edges missing')
 require(L(z,a,nxt,prev) and z==a,'Wrapper control failed')
 # The same local edge/identity argument persists in the full infinite
 # canonical arithmetic graph; truncation is not used for its universal.
 result={'status':'PASS','source_commit':'b306aef970d43d582765a1daef9d1734aa83978e','certified_new_graph_reduction':False,'surviving_main_frontier':{'fixed':155,'recurring_overhead':30},'missing_seed_parameter_guards':{'vertices':7,'operation':'XOR on two objects, sole tag0','missing_unit_guard':'a=marker, z=object0','missing_zero_guard':'z=marker, a=object0','all_recurrent_arithmetic_instances_vacuous':True},'outer_wrapper_control':{'local_marker':'object1','zero_unit_and_column_witness':'pair(1,1)','valid_test_body':'zero != unit','scope':'Rejects the uniform transformation for arbitrary valid arithmetic bodies; does not assert that this test sentence is a literal member of every supplied axiom listing.'},'all_checks_active_under_python_O':True,'scope':'Finite countermodels for the two fixed-guard deletions; local exact witness for wrapper deletion. No claim of global optimality.'}
 pathlib.Path(__file__).with_name('guard_obstructions.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
