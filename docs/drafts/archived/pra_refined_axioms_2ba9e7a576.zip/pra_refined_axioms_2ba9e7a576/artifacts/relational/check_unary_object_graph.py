"""Fresh independent E/O syntax and small finite bootstrap diagnostics.
No downloaded source is imported/executed. All checks survive python -O.
"""
from dataclasses import dataclass
from itertools import product
import json
@dataclass(frozen=True)
class A:
 op:str
 args:tuple=()
def f(op,*args):return A(op,args)
def V(s):return f('v:'+s)
def E(x,y):return f('E',V(x),V(y))
def O(x):return f('O',V(x))
def Eq(x,y):return f('=',V(x),V(y))
def R(t,x,y,w):return f('R',V(t),V(x),V(y),V(w))
def Imp(a,b):return f('imp',a,b)
def Neg(a):return Imp(a,f('false'))
def And(*xs):
 t=xs[0]
 for x in xs[1:]:t=f('and',t,x)
 return t
def Or(a,b):return f('or',a,b)
def Q(op,x,t):return f(op+':'+x,t)
def close(ops,t):
 for op,x in reversed(ops):t=Q(op,x,t)
 return t
def count(t):return 1+sum(map(count,t.args))
def quant(t):return int(t.op.startswith(('all:','ex:')))+sum(map(quant,t.args))
def rc(t):return int(t.op=='R')+sum(map(rc,t.args))
def B(x):return And(O(x),Q('all','r',Imp(O('r'),Neg(E(x,'r')))))
def D(x):return close([('ex','b'),('ex','c')],And(O('b'),O('c'),Q('all','r',Imp(And(E('b','r'),E('r','c')),Eq('r',x)))))
def Sbody(x):return Or(B(x),D(x))
def source(annihilator=True):
 tags=Or(Eq('t','z'),Eq('t','a'))
 clauses=[Imp(tags,R('t','x','y','u')),Imp(R('t','x','y','w'),And(tags,Eq('w','u')))]
 if annihilator:clauses.insert(0,Imp(And(Eq('t','a'),Eq('y','z')),Eq('u','z')))
 return close([('all','x'),('all','y'),('all','t'),('ex','u'),('all','w')],And(*clauses))
def trans(t,weak=False,serial=None):
 if serial is None:
  def names(u):
   out={u.op[2:]} if u.op.startswith('v:') else ({u.op.split(':')[1]} if u.op.startswith(('all:','ex:')) else set())
   for child in u.args:out.update(names(child))
   return out
  serial=[0,names(t)]
 if t.op=='R':
  tag,x,y,w=[v.op[2:] for v in t.args]
  while True:
   serial[0]+=1;p,q='P'+str(serial[0]),'Q'+str(serial[0])
   if p not in serial[1] and q not in serial[1]:break
  serial[1].update([p,q])
  return close([('ex',p),('ex',q)],And(E(x,p),E(p,y),E(tag,q),E(q,w),E(p,q)))
 if t.op.startswith(('all:','ex:')):
  op,x=t.op.split(':');body=trans(t.args[0],weak,serial)
  if op=='all':body=Imp(O(x),body)
  elif not (weak and x=='u'):body=And(O(x),body)
  return Q(op,x,body)
 return f(t.op,*(trans(a,weak,serial) for a in t.args))
def fixed(named=False,annihilator=True):
 body=And(O('z'),O('a'),Q('all','x',And(Sbody('x'),trans(source(annihilator),True).args[0])))
 return body if named else close([('ex','z'),('ex','a')],body)
def L():return Q('ex','q',And(E('a','q'),Q('all','p',Imp(E('p','z'),E('p','q')))))
def scheme(t):return close([('all','z'),('all','a')],Imp(O('z'),Imp(O('a'),Imp(L(),trans(t)))))
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
forms={'B':B('x'),'D':D('x'),'structure':Q('all','x',Sbody('x')),'source_H':source(),'typed_H':trans(source()),'weak_H':trans(source(),True),'fixed':fixed(),'named_fixed':fixed(True),'guard':L(),'test_scheme':scheme(Eq('x','x')),'H36':source(False),'weak_H80':trans(source(False),True),'named120':fixed(True,False)}
expected={'B':12,'D':20,'structure':34,'source_H':48,'typed_H':95,'weak_H':92,'fixed':134,'named_fixed':132,'guard':13,'test_scheme':25,'H36':36,'weak_H80':80,'named120':120}
def eqt(x,y):return f('=',x,y)
def num(n):return f('c:'+str(n))
u,v,r,s,b=map(V,['u','v','r','s','b']);zero,one=num(0),num(1)
plus=lambda x,y:f('+',x,y)
mult=lambda x,y:f('*',x,y)
reverse=Or(And(eqt(u,zero),eqt(r,plus(v,one))),Q('ex','b',And(eqt(u,plus(b,one)),Or(Or(And(eqt(r,zero),eqt(v,s)),And(eqt(r,one),eqt(s,plus(b,v)))),And(eqt(r,plus(one,one)),eqt(s,mult(b,v)))))))
forms.update({'reverse_E':reverse,'reverse_O':eqt(u,zero),'reverse_equality':And(eqt(u,r),eqt(v,s))})
expected.update({'reverse_E':46,'reverse_O':3,'reverse_equality':7})
for name,t in forms.items():need(count(t)==expected[name],name+': '+str(count(t)))
for t in [Eq('x','y'),R('a','x','y','w'),Q('all','x',R('a','x','y','w')),Q('ex','t',Imp(R('t','x','y','w'),Eq('x','y')))]:
 need(count(scheme(t))==count(t)+16*rc(t)+3*quant(t)+22,'generic ledger')
# Exhaustive finite E/O structures up to3 vertices. The typed z,a are source
# parameters, not additional relation symbols in the unnamed variant.
structures=seeds=collapsed=noncollapsed=0
for n in range(1,4):
 U=range(n)
 for edges in range(1<<(n*n)):
  ee=lambda x,y:bool(edges & (1<<(x*n+y)))
  for omask in range(1,1<<n):
   obs=[i for i in U if omask>>i&1]
   bs=[v in obs and all(not ee(v,o) for o in obs) for v in U]
   ds=[any(all(not(ee(b,r) and ee(r,c)) or r==v for r in U) for b in obs for c in obs) for v in U]
   structures+=1
   if not all(bs[v] or ds[v] for v in U):continue
   chains={(x,y):[p for p in U if ee(x,p) and ee(p,y)] for x in U for y in U}
   decoded={(t,x,y,w):any(ee(p,q) for p in chains[x,y] for q in chains[t,w]) for t in U for x in U for y in U for w in U}
   for z,a in product(obs,repeat=2):
    def condition(x,y,t,u):
     return (not(t==a and y==z) or u==z) and (t not in (z,a) or decoded[t,x,y,u]) and all(not decoded[t,x,y,w] or (t in (z,a) and w==u) for w in obs)
    weak=all(any(condition(x,y,t,u) for u in U) for x,y,t in product(obs,repeat=3))
    if not weak:continue
    seeds+=1
    need(all(any(condition(x,y,t,u) for u in obs) for x,y,t in product(obs,repeat=3)),'weak to typed finite bootstrap')
    need(any(ee(a,q) and all(not ee(p,z) or ee(p,q) for p in U) for q in U),'column guard bootstrap')
    if ds[z]:collapsed+=1;need(len(obs)==1,'D(z) object collapse')
    else:noncollapsed+=1;need(all(bs[o] for o in obs),'B(z) all objects B')
print(json.dumps({'status':'PASS','nodes':{k:count(v) for k,v in forms.items()},'generic_recurrence':'N+16r+3q+22','finite_structures':structures,'finite_seed_cases':seeds,'D_z_cases':collapsed,'B_z_cases':noncollapsed,'scope':'Exact AST and exhaustive finite bootstrap diagnostics only; arbitrary-model proof audited separately.'},indent=2,sort_keys=True))
