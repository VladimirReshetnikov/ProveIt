#!/usr/bin/env python3
"""Fresh finite/edge diagnostics for marker-free and product-sort proofs."""
from pathlib import Path
import itertools,json
from marker_free import reverse_E

def need(ok,message):
 if not ok:raise RuntimeError(message)
def neighbors(V,E):return ({x:{y for a,y in E if a==x} for x in V},{x:{y for y,b in E if b==x} for x in V})
def structure(V,O,nxt,prev):return all((x in O and not nxt[x]&O) or any(nxt[b]&prev[c]<={x} for b,c in itertools.product(O,repeat=2)) for x in V)
def decoded(t,x,y,nxt,prev):
 p=nxt[x]&prev[y];q=set().union(*(nxt[r]&nxt[t] for r in p)) if p else set()
 return set().union(*(nxt[r] for r in q)) if q else set()
def H(V,O,z,a,nxt,prev,weak,ann=True):
 for x,y,t in itertools.product(O,repeat=3):
  outs=decoded(t,x,y,nxt,prev);selected=t==z or t==a
  if not any((not ann or t!=a or y!=z or u==z) and (not selected or u in outs) and all(selected and w==u for w in outs&O) for u in (V if weak else O)):return False
 return True
def L(z,a,nxt,prev):return any(prev[z]<=prev[q] for q in nxt[a])
def canonical(n,relation):
 O={(0,b) for b in range(n)};P={(b+1,c) for b,c in itertools.product(range(n),repeat=2)};V=O|P
 E={((0,b),(b+1,c)) for b,c in itertools.product(range(n),repeat=2)}|{((b+1,c),(0,c)) for b,c in itertools.product(range(n),repeat=2)}|{((x+1,y),(t+1,w)) for t,x,y,w in relation}
 return V,O,E
def arith(f,env):
 op=f[0]
 if op=='var':return env[f[1]]
 if op=='const':return int(f[1])
 if op in ('+','*'):
  a,b=(arith(t,env) for t in f[1:]);return a+b if op=='+' else a*b
 if op=='=':return arith(f[1],env)==arith(f[2],env)
 if op=='and':return arith(f[1],env) and arith(f[2],env)
 if op=='or':return arith(f[1],env) or arith(f[2],env)
 if op=='exists':return any(arith(f[2],{**env,f[1]:b}) for b in range(env['u']+1))
 raise ValueError(op)

def main():
 cases=accepted=collapse=named_cases=0
 for n in range(1,4):
  V=set(range(n));edge_list=list(itertools.product(V,repeat=2))
  for obits in range(1,1<<n):
   O={v for v in V if obits>>v&1}
   for bits in range(1<<len(edge_list)):
    E={e for i,e in enumerate(edge_list) if bits>>i&1};nxt,prev=neighbors(V,E);cases+=1
    if not structure(V,O,nxt,prev):continue
    for z,a in itertools.product(O,repeat=2):
     for ann in (False,True):
      weak=H(V,O,z,a,nxt,prev,True,ann);typed=H(V,O,z,a,nxt,prev,False,ann)
      need(weak==typed,'Weak output equivalence failed')
      if weak:
       if ann:
        accepted+=1;collapse+=int((z,z) in E);need(L(z,a,nxt,prev),'Finite column guard failed')
       else:named_cases+=1
 tables=mutations=0;inputs=list(itertools.product(range(2),repeat=2))
 for plus in itertools.product(range(2),repeat=4):
  for times in itertools.product(range(2),repeat=4):
   relation={(0,x,y,w) for (x,y),w in zip(inputs,plus)}|{(1,x,y,w) for (x,y),w in zip(inputs,times)}
   V,O,E=canonical(2,relation);nxt,prev=neighbors(V,E);z,a=(0,0),(0,1)
   need(structure(V,O,nxt,prev) and H(V,O,z,a,nxt,prev,True,False) and H(V,O,z,a,nxt,prev,False,False),'Arbitrary operation table failed');tables+=1
   if times[0]==times[2]==0:
    need(H(V,O,z,a,nxt,prev,True) and L(z,a,nxt,prev),'Zero-column table failed')
    for e in itertools.product(V,repeat=2):
     EE=E^{e};nn,pp=neighbors(V,EE);mutations+=1
     if structure(V,O,nn,pp):need(H(V,O,z,a,nn,pp,True)==H(V,O,z,a,nn,pp,False),'Edge-mutation weak equivalence failed')
 reverse_edges=decoded_tuples=0
 for n in range(1,6):
  relation={(t,x,y,(x+y if t==0 else x*y)) for t,x,y in itertools.product(range(n),repeat=3) if t in (0,1) and (x+y if t==0 else x*y)<n}
  V,O,E=canonical(n,relation);nxt,prev=neighbors(V,E)
  for (u,v),(r,s) in itertools.product(V,repeat=2):
   need(arith(reverse_E(),{'u':u,'v':v,'r':r,'s':s})==(((u,v),(r,s)) in E),'Reverse E46 mismatch');reverse_edges+=1
  for t,x,y,w in itertools.product(range(n),repeat=4):
   need(((0,w) in decoded((0,t),(0,x),(0,y),nxt,prev))==((t,x,y,w) in relation),'Decoded arithmetic relation mismatch');decoded_tuples+=1
 # Product-interface axiom equivalence for every function A^2->P on
 # two objects and four candidate pairs, including non-bijections.
 A=range(2);P=range(4);pairs=list(itertools.product(A,repeat=2));maps=bijections=0
 for table in itertools.product(P,repeat=4):
  pi=dict(zip(pairs,table));maps+=1
  native=all(any(all((p==pi[t,w])==((t==x) and (w==y)) for t,w in pairs) for x,y in pairs) for p in P)
  expanded=all(any(p==pi[x,y] and all(p!=pi[t,w] or ((t==x) and (w==y)) for t,w in pairs) for x,y in pairs) for p in P)
  need(native==expanded,'Pair interface equivalence failed');bijections+=int(native)
 relations=source_accept=0;triples=list(itertools.product(A,repeat=3))
 for outputs in itertools.product(range(4),repeat=8):
  row={k:{w for w in A if code>>w&1} for k,code in zip(triples,outputs)}
  for z,a in pairs:
   native=all(any(all((w in row[t,x,y])==((t in (z,a)) and w==u) for w in A) for u in A) for t,x,y in triples)
   expanded=all(any((t not in (z,a) or u in row[t,x,y]) and all(w not in row[t,x,y] or (t in (z,a) and w==u) for w in A) for u in A) for t,x,y in triples)
   need(native==expanded,'Typed source equivalence failed');relations+=1;source_accept+=int(native)
 out={'status':'PASS','marker_free_nonempty_O_structures':cases,'finite_H48_seed_cases':accepted,'collapse_cases':collapse,'finite_named_H36_seed_cases':named_cases,'arbitrary_two_operation_tables':tables,'single_edge_mutations':mutations,'reverse_E46_edge_comparisons':reverse_edges,'decoded_arithmetic_tuple_comparisons':decoded_tuples,'product_constructor_functions':maps,'product_bijections':bijections,'product_source_relation_parameter_cases':relations,'product_source_satisfying_cases':source_accept,'all_checks_active_under_python_O':True,'scope':'Finite diagnostics and bounded edge/tuple tests, not full PRA models or proof certificates.'}
 Path(__file__).with_name('domain_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
