(forall t (forall x (forall y (exists u (forall w (iff (R t x y w) (and (or (= t z) (= t a)) (= w u))))))))
