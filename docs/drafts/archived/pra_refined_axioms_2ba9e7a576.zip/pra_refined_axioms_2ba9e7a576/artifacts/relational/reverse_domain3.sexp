(= u u)
