(forall p (exists x (exists y (and (= p (pi x y)) (forall t (forall w (imp (= p (pi t w)) (and (= t x) (= w y)))))))))
