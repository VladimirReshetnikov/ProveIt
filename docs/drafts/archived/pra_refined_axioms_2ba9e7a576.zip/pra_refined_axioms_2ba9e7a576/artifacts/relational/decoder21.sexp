(exists p (exists q (and (and (and (and (E x p) (E p y)) (E t q)) (E q w)) (E p q))))
