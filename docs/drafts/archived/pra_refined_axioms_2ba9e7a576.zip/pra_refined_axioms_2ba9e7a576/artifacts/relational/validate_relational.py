#!/usr/bin/env python3
"""Standalone clean-folder replay of fresh round10 domain artifacts."""
from pathlib import Path
import ast,hashlib,json,os,re,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
SCRIPTS=['marker_free.py','product_sort.py','basis_table.py','check_domains.py','check_marker_free_kripke.py','check_unary_object_graph.py','check_product_sort_independent.py','check_guard_obstructions.py']
def need(ok,message):
 if not ok:raise RuntimeError(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def parse(text):
 tokens=re.findall(r'\(|\)|[^\s()]+',text);pos=0
 def take():
  nonlocal pos
  need(pos<len(tokens),'Truncated AST');token=tokens[pos];pos+=1
  if token!='(':return token
  row=[]
  while pos<len(tokens) and tokens[pos]!=')':row.append(take())
  need(pos<len(tokens),'Unclosed AST');pos+=1;return tuple(row)
 result=take();need(pos==len(tokens),'Trailing AST');return result
def size(t):
 if isinstance(t,str):return 1
 if t[0] in ('forall','exists'):return 1+size(t[2])
 return 1+sum(size(x) for x in t[1:])
def main():
 for script in SCRIPTS+[Path(__file__).name]:
  need(not any(isinstance(node,ast.Assert) for node in ast.walk(ast.parse((HERE/script).read_text()))),'Disabled-by-O assert in '+script)
 provenance=json.loads((HERE/'PORTABILITY_PROVENANCE.json').read_text())
 for relative,wanted in provenance['static_reference_sha256'].items():need(sha(HERE/relative)==wanted,'Static calibration reference changed')
 modes={};reports={}
 with tempfile.TemporaryDirectory(prefix='pra_round10_domains_') as tmp:
  for mode,flags in [('normal',[]),('optimized',['-O'])]:
   work=Path(tmp)/mode;work.mkdir()
   for script in SCRIPTS:shutil.copy2(HERE/script,work/script)
   logs={};parsed={}
   for script in SCRIPTS:
    run=subprocess.run([sys.executable,*flags,script],cwd=work,text=True,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=240)
    need(run.returncode==0,mode+' '+script+' failed: '+run.stderr+' '+run.stdout)
    parsed[script]=json.loads(run.stdout);need(parsed[script].get('status')=='PASS',script+' lacks PASS')
    logs[script]=hashlib.sha256(run.stdout.encode()).hexdigest()
   ast_checks=0
   for generator in ['marker_free.py','product_sort.py','basis_table.py']:
    for name,wanted in parsed[generator]['nodes'].items():
     need(size(parse((work/(name+'.sexp')).read_text()))==wanted,'Independent serialized-AST count differs: '+name);ast_checks+=1
   generated={p.name:sha(p) for p in sorted(work.iterdir()) if p.suffix in ('.json','.sexp')}
   modes[mode]={'stdout_sha256':logs,'generated_sha256':generated,'independent_serialized_AST_counts':ast_checks};reports[mode]=parsed
   if mode=='normal':
    for p in work.iterdir():
     if p.suffix in ('.json','.sexp'):shutil.copy2(p,HERE/p.name)
  need(modes['normal']==modes['optimized'],'Normal and -O results differ')
 r=reports['normal'];eo=r['marker_free.py'];prod=r['product_sort.py']
 need(eo['fixed']==134 and prod['native_iff_fixed_total']==42 and prod['expanded_optimized_fixed_total']==64,'Frozen frontier mismatch')
 result={'status':'PASS','normal_and_optimized_outputs_identical':True,'python_assert_nodes':0,'marker_free':{'signature':'E binary, O unary','fixed_one_sentence':134,'recurring':'N+16r+3q+22','named_four_sentence_sum':118,'named_single_sentence':120,'named_recurring':'N+16r+3q','reverse_E_nodes':46,'reverse_domain':'entire N^2'},'product_sort':{'signature':'pi binary function, Data binary relation, z,a constants; sorts A,P','native_iff_two_sentence_sum':42,'expanded_optimized_two_sentence_sum':64,'literal_native_expansion':76,'recurring':'N+2r'},'basis_table':r['basis_table.py']['rows'],'finite_diagnostics':r['check_domains.py'],'intuitionistic_diagnostics':r['check_marker_free_kripke.py'],'independent_audits':{s:r[s] for s in ['check_unary_object_graph.py','check_product_sort_independent.py']},'fresh_executable_sha256':{s:sha(HERE/s) for s in SCRIPTS+[Path(__file__).name]},'replay_evidence':modes,'limitations':'Exact syntax and finite/Kripke diagnostics are not formal-kernel proof certificates. No finite structure is claimed to satisfy full PRA. Complete constructive proofs and credited static arithmetic calibration are supplied. No archived executable is used.'}
 (HERE/'final_relational_validation.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result,sort_keys=True,indent=2))
if __name__=='__main__':main()
