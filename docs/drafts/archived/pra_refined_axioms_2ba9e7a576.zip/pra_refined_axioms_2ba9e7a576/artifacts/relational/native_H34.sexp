(forall x (forall y (forall t (exists u (forall w (and (imp (and (= t a) (= y z)) (= u z)) (iff (R t x y w) (and (or (= t z) (= t a)) (= w u)))))))))
