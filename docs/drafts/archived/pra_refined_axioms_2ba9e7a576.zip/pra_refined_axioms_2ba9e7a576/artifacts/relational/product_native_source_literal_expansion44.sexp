(forall t (forall x (forall y (exists u (forall w (and (imp (Data (pi x y) (pi t w)) (and (or (= t z) (= t a)) (= w u))) (imp (and (or (= t z) (= t a)) (= w u)) (Data (pi x y) (pi t w)))))))))
