"""Fresh, independent product-sort AST and finite logical diagnostics."""
from dataclasses import dataclass
from itertools import product
import json
@dataclass(frozen=True)
class A:
 op:str
 args:tuple=()
def f(op,*xs):return A(op,xs)
def v(x):return f('v:'+x)
z,a,t,x,y,u,w,p,r,s=map(v,['z','a','t','x','y','u','w','p','r','s'])
def eq(t,u):return f('=',t,u)
def pi(x,y):return f('pi',x,y)
def relation(t,x,y,w):return f('R',t,x,y,w)
def and_(x,y):return f('and',x,y)
def or_(x,y):return f('or',x,y)
def imp(x,y):return f('imp',x,y)
def iff(x,y):return f('iff',x,y)
def close(bs,A):
 for op,q in reversed(bs):A=f(op+':'+q.op,A)
 return A
def size(A):return 1+sum(map(size,A.args))
C=or_(eq(t,z),eq(t,a))
coordinates=and_(eq(t,x),eq(w,y))
P18=close([('all',p),('ex',x),('ex',y),('all',t),('all',w)],iff(eq(p,pi(t,w)),coordinates))
P24=close([('all',p),('ex',x),('ex',y)],and_(eq(p,pi(x,y)),close([('all',t),('all',w)],imp(eq(p,pi(t,w)),coordinates))))
H22=close([('all',t),('all',x),('all',y),('ex',u),('all',w)],iff(relation(t,x,y,w),and_(C,eq(w,u))))
H36=close([('all',x),('all',y),('all',t),('ex',u),('all',w)],and_(imp(C,relation(t,x,y,u)),imp(relation(t,x,y,w),and_(C,eq(w,u)))))
def trans(A):
 if A.op=='R':
  t,x,y,w=A.args
  return f('D',pi(x,y),pi(t,w))
 return f(A.op,*(trans(a) for a in A.args))
def expand(A):
 args=tuple(expand(t) for t in A.args)
 if A.op=='iff':return and_(imp(args[0],args[1]),imp(args[1],args[0]))
 return f(A.op,*args)
zero,one=f('0'),f('1')
reverse=or_(and_(eq(t,zero),eq(w,f('+',x,y))),and_(eq(t,one),eq(w,f('*',x,y))))
forms={'Pair18':P18,'Pair24':P24,'Hsource22':H22,'Hproduct24':trans(H22),'Hsource36':H36,'Hproduct40':trans(H36),'literalPair32':expand(P18),'literalH44':expand(trans(H22)),'nativeConjunction43':and_(P18,trans(H22)),'expandedConjunction65':and_(P24,trans(H36)),'reverseD19':reverse,'constructorGraph7':and_(eq(r,x),eq(s,y))}
expected=[18,24,22,24,36,40,32,44,43,65,19,7]
def need(b,m):
 if not b:raise RuntimeError(m)
need(list(map(size,forms.values()))==expected,'AST count mismatch')
mapchecks=0
for acard in [1,2]:
 aa=list(product(range(acard),repeat=2))
 for pcard in range(1,5):
  for values in product(range(pcard),repeat=len(aa)):
   table=dict(zip(aa,values))
   axiom=all(any(all((pp==table[tw])==(tw==xy) for tw in aa) for xy in aa) for pp in range(pcard))
   bijective=len(set(values))==len(aa)==pcard
   need(axiom==bijective,'Pair iff is exactly bijection')
   mapchecks+=1
hchecks=0
for acard in range(1,5):
 for mask in range(1<<acard):
  for selected in [False,True]:
   rw=lambda w:bool(mask>>w&1)
   h22=any(all(rw(w)==(selected and w==u) for w in range(acard)) for u in range(acard))
   h36=any(all((not selected or rw(u)) and (not rw(w) or (selected and w==u)) for w in range(acard)) for u in range(acard))
   need(h22==h36,'H equivalence')
   need(h22==(mask.bit_count()==1 if selected else mask==0),'support/function interpretation')
   hchecks+=1
print(json.dumps({'status':'PASS','nodes':{k:size(v) for k,v in forms.items()},'fixed_native_two_sentences':42,'fixed_expanded_factored_two_sentences':64,'literal_expanded_two_sentences':76,'recurrence':'N+2r','finite_pair_maps':mapchecks,'finite_output_profiles':hchecks,'scope':'Fresh exact AST and finite diagnostics, not arbitrary-model proof certification.'},indent=2,sort_keys=True))
