(and (= u r) (= v s))
