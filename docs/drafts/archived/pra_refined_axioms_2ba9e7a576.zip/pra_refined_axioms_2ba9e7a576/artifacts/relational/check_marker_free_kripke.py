#!/usr/bin/env python3
"""Fresh finite Kripke diagnostics with both E and O persistent valuations."""
from pathlib import Path
import functools,itertools,json,random
from marker_free import *

def need(ok,message):
 if not ok:raise RuntimeError(message)
@functools.lru_cache(None)
def free(f):
 if f[0]=='var':return frozenset([f[1]])
 if f[0] in ('false','true','const'):return frozenset()
 if f[0] in ('forall','exists'):return free(f[2])-{f[1]}
 return frozenset().union(*(free(x) for x in f[1:]))
class K:
 def __init__(self,V,future,edges,objects):
  self.V=V;self.future=future;self.E=edges;self.O=objects;self.cache={}
  for w in future:
   for v in future[w]:need(edges[w]<=edges[v] and objects[w]<=objects[v],'Nonpersistent valuation')
 def at(self,f,w,env):
  key=f,w,tuple(sorted((x,env[x]) for x in free(f)))
  if key in self.cache:return self.cache[key]
  op=f[0]
  if op=='var':value=env[f[1]]
  elif op=='false':value=False
  elif op=='true':value=True
  elif op=='E':value=(self.at(f[1],w,env),self.at(f[2],w,env)) in self.E[w]
  elif op=='O':value=self.at(f[1],w,env) in self.O[w]
  elif op=='=':value=self.at(f[1],w,env)==self.at(f[2],w,env)
  elif op=='and':value=self.at(f[1],w,env) and self.at(f[2],w,env)
  elif op=='or':value=self.at(f[1],w,env) or self.at(f[2],w,env)
  elif op=='imp':value=all(not self.at(f[1],v,env) or self.at(f[2],v,env) for v in self.future[w])
  elif op=='iff':value=all(self.at(f[1],v,env)==self.at(f[2],v,env) for v in self.future[w])
  elif op=='forall':value=all(self.at(f[2],v,{**env,f[1]:x}) for v in self.future[w] for x in self.V)
  elif op=='exists':value=any(self.at(f[2],w,{**env,f[1]:x}) for x in self.V)
  else:raise ValueError(op)
  self.cache[key]=value;return value

def main():
 frames=[({0:(0,1),1:(1,)},[(),(1,),(0,1)]),({0:(0,1,2),1:(1,),2:(2,)},[(),(1,),(2,),(1,2),(0,1,2)])]
 typed48,weak48=translate(H48()),translate(H48(),True)
 typed36,weak36=translate(H36()),translate(H36(),True)
 skeleton=FA('x',S('x'));rng=random.Random(13422);valuations=cases=seeds=named=0
 for future,upsets in frames:
  for n in (1,2,3):
   V=tuple(range(n));atoms=[('E',x,y) for x,y in itertools.product(V,repeat=2)]+[('O',x) for x in V]
   assignments=itertools.product(range(len(upsets)),repeat=len(atoms)) if n<=2 else (tuple(rng.randrange(len(upsets)) for atom in atoms) for _ in range(80))
   for assignment in assignments:
    edges={w:{(a[1],a[2]) for a,u in zip(atoms,assignment) if a[0]=='E' and w in upsets[u]} for w in future}
    objects={w:{a[1] for a,u in zip(atoms,assignment) if a[0]=='O' and w in upsets[u]} for w in future}
    model=K(V,future,edges,objects);valuations+=1
    for z,a in itertools.product(objects[0],repeat=2):
     env={'z':z,'a':a};cases+=1
     if not model.at(skeleton,0,env):continue
     if model.at(weak36,0,env):named+=1;need(model.at(typed36,0,env),'Named weak-output recovery failed')
     if model.at(weak48,0,env):seeds+=1;need(model.at(typed48,0,env) and model.at(L(),0,env),'Full finite bootstrap failed')
 # A genuinely growing data/coordinate edge valuation, not a constant
 # classical model relabelled as intuitionistic evidence.
 V=tuple(range(1,6));base={(1,3),(2,3),(1,4),(2,5),(3,1),(4,2),(5,2),(3,3),(4,3),(5,3)};nonconstant=0
 for future,upsets in frames:
  for upset in upsets:
   model=K(V,future,{w:base|({(5,1)} if w in upset else set()) for w in future},{w:{1,2} for w in future});env={'z':1,'a':2}
   need(model.at(skeleton,0,env) and model.at(weak48,0,env) and model.at(typed48,0,env) and model.at(L(),0,env),'Growing incidence model failed')
   nonconstant+=int(bool(upset) and 0 not in upset)
 future={0:(0,1,2),1:(1,),2:(2,)};model=K(V,future,{0:base,1:base|{(4,1)},2:base|{(5,1)}},{w:{1,2} for w in future});env={'z':1,'a':2}
 need(model.at(weak48,0,env) and not model.at(skeleton,0,env),'Private-coordinate fork negative control failed')
 out={'status':'PASS','frames':'chain and fork, constant domains; both E and O may grow persistently','persistent_valuations':valuations,'typed_parameter_cases':cases,'full_seed_cases':seeds,'named_no_annihilator_seed_cases':named,'genuinely_nonconstant_incidence_models':nonconstant,'fork_private_coordinate_negative_control':True,'all_checks_active_under_python_O':True,'scope':'Finite Kripke diagnostics, not a proof certificate or an exhaustion of intuitionistic models.'}
 Path(__file__).with_name('marker_free_kripke_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
