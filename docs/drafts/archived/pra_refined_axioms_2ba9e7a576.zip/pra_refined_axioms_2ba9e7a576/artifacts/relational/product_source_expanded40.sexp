(forall x (forall y (forall t (exists u (forall w (and (imp (or (= t z) (= t a)) (Data (pi x y) (pi t u))) (imp (Data (pi x y) (pi t w)) (and (or (= t z) (= t a)) (= w u)))))))))
