(forall z (forall a (imp (O z) (imp (O a) (imp (exists q (and (E a q) (forall p (imp (E p z) (E p q))))) (= v v))))))
