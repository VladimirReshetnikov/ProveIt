(forall p (exists x (exists y (forall t (forall w (and (imp (= p (pi t w)) (and (= t x) (= w y))) (imp (and (= t x) (= w y)) (= p (pi t w)))))))))
