(and (O a) (exists z (and (O z) (exists q (and (E a q) (forall p (imp (E p z) (E p q))))))))
