#!/usr/bin/env python3
"""Reprice each signature in both explicitly separated connective bases."""
from pathlib import Path
import json
from marker_free import *
from product_sort import expand_iff
def iff(a,b):return ('iff',a,b)
def Hnative(ann):
 f=iff(R('t','x','y','w'),AND(OR(eq('t','z'),eq('t','a')),eq('w','u')))
 if ann:f=AND(imp(AND(eq('t','a'),eq('y','z')),eq('u','z')),f)
 return ALL(['x','y','t'],EX('u',FA('w',f)))
def unary_fixed():
 h=translate(Hnative(True))
 return SOME(['z','a'],AND(O('z'),O('a'),FA('x',AND(S('x'),h[2]))))
def replace_unary_O(f):
 if f[0] in ('var','const','false','true'):return f
 if f[0] in ('forall','exists'):return (f[0],f[1],replace_unary_O(f[2]))
 if f[0]=='O':return E(f[1],'m')
 return (f[0],*(replace_unary_O(x) for x in f[1:]))
def binary_fixed():
 sm=AND(neg(E('m','x')),OR(eq('x','m'),replace_unary_O(B('x')),replace_unary_O(D('x'))))
 h=replace_unary_O(translate(Hnative(True)))
 return SOME(['m','z','a'],AND(E('z','m'),E('a','m'),FA('x',AND(sm,h[2]))))
def main():
 fs={'native_H22':Hnative(False),'native_H34':Hnative(True),'native_unary_H53':translate(Hnative(False)),'native_unary_H65':translate(Hnative(True)),'native_unary_fixed107':unary_fixed(),'native_incumbent_fixed129':binary_fixed(),'native_unary_literal_expansion141':expand_iff(unary_fixed()),'native_incumbent_literal_expansion163':expand_iff(binary_fixed())}
 expected={'native_H22':22,'native_H34':34,'native_unary_H53':53,'native_unary_H65':65,'native_unary_fixed107':107,'native_incumbent_fixed129':129,'native_unary_literal_expansion141':141,'native_incumbent_literal_expansion163':163}
 for name,f in fs.items():
  if size(f)!=expected[name]:raise RuntimeError((name,size(f),expected[name]))
  Path(__file__).with_name(name+'.sexp').write_text(sexp(f)+'\n')
 rows=[{'signature':'one binary E, one sort','clauses':1,'expanded_optimized':155,'native_iff':129,'literal_native_expansion':163,'scheme':'N+16r+4q+30'}, {'signature':'binary E + unary O, one sort','clauses':1,'expanded_optimized':134,'native_iff':107,'literal_native_expansion':141,'scheme':'N+16r+3q+22'}, {'signature':'E,O plus constants z,a, one sort','clauses':4,'expanded_optimized':118,'native_iff':91,'literal_native_expansion':125,'scheme':'N+16r+3q'}, {'signature':'binary pi + binary Data + constants z,a, two sorts','clauses':2,'expanded_optimized':64,'native_iff':42,'literal_native_expansion':76,'scheme':'N+2r'}]
 if 34+size(translate(Hnative(False)))+4!=91:raise RuntimeError('Named unary native count')
 result={'status':'PASS','rows':rows,'nodes':{k:size(f) for k,f in fs.items()},'caveat':'N and r are measured in the same connective basis used for that row. Signature, sorts, clause count, literal expansion and optimized equivalent expanded presentation are distinct metrics.','all_checks_active_under_python_O':True}
 Path(__file__).with_name('basis_table_metrics.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
