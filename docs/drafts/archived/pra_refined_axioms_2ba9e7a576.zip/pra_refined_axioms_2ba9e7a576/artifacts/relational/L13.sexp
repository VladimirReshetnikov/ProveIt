(exists q (and (E a q) (forall p (imp (E p z) (E p q)))))
