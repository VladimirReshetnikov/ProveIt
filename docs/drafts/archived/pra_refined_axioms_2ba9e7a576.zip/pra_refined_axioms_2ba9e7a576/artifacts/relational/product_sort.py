#!/usr/bin/env python3
"""Exact two-sorted product interface. Native iff and expanded bases separated."""
from pathlib import Path
import json
from marker_free import var,atom,eq,AND,OR,imp,FA,EX,ALL,SOME,size,sexp,H36,occurrences
def pi(x,y):return atom('pi',x,y)
def D(x,y):return atom('Data',x,y)
def iff(a,b):return ('iff',a,b)
def R(t,x,y,w):return atom('R',t,x,y,w)
def pair18():
 return FA('p',SOME(['x','y'],ALL(['t','w'],iff(eq('p',pi('t','w')),AND(eq('t','x'),eq('w','y'))))))
def pair24():
 return FA('p',SOME(['x','y'],AND(eq('p',pi('x','y')),ALL(['t','w'],imp(eq('p',pi('t','w')),AND(eq('t','x'),eq('w','y')))))))
def H22():
 return ALL(['t','x','y'],EX('u',FA('w',iff(R('t','x','y','w'),AND(OR(eq('t','z'),eq('t','a')),eq('w','u'))))))
def translate(f):
 if f[0] in ('var','const','false','true'):return f
 if f[0] in ('forall','exists'):return (f[0],f[1],translate(f[2]))
 if f[0]=='R':
  t,x,y,w=f[1:];return D(pi(x,y),pi(t,w))
 return (f[0],*(translate(x) for x in f[1:]))
def expand_iff(f):
 if f[0] in ('var','const','false','true'):return f
 if f[0] in ('forall','exists'):return (f[0],f[1],expand_iff(f[2]))
 if f[0]=='iff':
  a,b=map(expand_iff,f[1:]);return AND(imp(a,b),imp(b,a))
 return (f[0],*(expand_iff(x) for x in f[1:]))
def main():
 forms={'product_pair_native18':pair18(),'product_pair_expanded24':pair24(),'product_source_native22':H22(),'product_source_native24':translate(H22()),'product_source_expanded36':H36(),'product_source_expanded40':translate(H36()),'product_native_single43':AND(pair18(),translate(H22())),'product_expanded_single65':AND(pair24(),translate(H36())),'product_native_pair_literal_expansion32':expand_iff(pair18()),'product_native_source_literal_expansion44':expand_iff(translate(H22()))}
 expected={'product_pair_native18':18,'product_pair_expanded24':24,'product_source_native22':22,'product_source_native24':24,'product_source_expanded36':36,'product_source_expanded40':40,'product_native_single43':43,'product_expanded_single65':65,'product_native_pair_literal_expansion32':32,'product_native_source_literal_expansion44':44}
 for name,f in forms.items():
  if size(f)!=expected[name]:raise RuntimeError((name,size(f)))
 for f in [H22(),H36(),ALL(['x','y'],R('z','x','y','z'))]:
  if size(translate(f))!=size(f)+2*occurrences(f,{'R'}):raise RuntimeError('Product decoder ledger')
 here=Path(__file__).parent
 for name,f in forms.items():(here/(name+'.sexp')).write_text(sexp(f)+'\n')
 result={'status':'PASS','sorts':['A: arithmetic objects','P: ordered pairs'],'signature':{'binary_function':'pi: A x A -> P','binary_relation':'Data: P x P','constants':['z:A','a:A']},'native_iff_two_sentence_costs':[18,24],'native_iff_fixed_total':42,'native_iff_single_sentence':43,'expanded_optimized_two_sentence_costs':[24,40],'expanded_optimized_fixed_total':64,'expanded_optimized_single_sentence':65,'literal_expansion_of_native_two_sentences':76,'scheme':'N + 2r','additional_recurrent_overhead':0,'decoder_nodes':7,'reverse_domains':{'A':'N','P':'entire N^2'},'nodes':{name:size(f) for name,f in forms.items()},'all_checks_active_under_python_O':True,'warning':'Counts are a typed function/relational signature tradeoff. Native iff42 is not its expanded-basis count; no categorical initiality is assumed.'}
 (here/'product_sort_metrics.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
