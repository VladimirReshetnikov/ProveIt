#!/usr/bin/env python3
"""Fresh exact ASTs for the E,O marker-free alternate signature."""
from functools import reduce
from pathlib import Path
import json
def var(x):return ('var',x)
def const(x):return ('const',str(x))
def term(x):return var(x) if isinstance(x,str) else x
def atom(op,*xs):return (op,*(term(x) for x in xs))
def E(x,y):return atom('E',x,y)
def O(x):return atom('O',x)
def R(t,x,y,w):return atom('R',t,x,y,w)
def eq(x,y):return atom('=',x,y)
def add(x,y):return atom('+',x,y)
def mul(x,y):return atom('*',x,y)
BOT=('false',);TOP=('true',)
def imp(a,b):return ('imp',a,b)
def neg(a):return imp(a,BOT)
def AND(*xs):return reduce(lambda a,b:('and',a,b),xs)
def OR(*xs):return reduce(lambda a,b:('or',a,b),xs)
def FA(x,f):return ('forall',x,f)
def EX(x,f):return ('exists',x,f)
def ALL(xs,f):return reduce(lambda f,x:FA(x,f),reversed(xs),f)
def SOME(xs,f):return reduce(lambda f,x:EX(x,f),reversed(xs),f)
def size(f):
 if f[0] in ('var','const','false','true'):return 1
 if f[0] in ('forall','exists'):return 1+size(f[2])
 return 1+sum(size(x) for x in f[1:])
def sexp(f):
 if f[0] in ('var','const'):return f[1]
 if f[0] in ('false','true'):return f[0]
 if f[0] in ('forall','exists'):return '('+f[0]+' '+f[1]+' '+sexp(f[2])+')'
 return '('+' '.join([f[0]]+[sexp(x) for x in f[1:]])+')'
def names(f):
 if f[0]=='var':return {f[1]}
 if f[0] in ('const','false','true'):return set()
 if f[0] in ('forall','exists'):return {f[1]}|names(f[2])
 return set().union(*(names(x) for x in f[1:]))
def decoder(t,x,y,w,p='p',q='q'):
 return SOME([p,q],AND(E(x,p),E(p,y),E(t,q),E(q,w),E(p,q)))
def translate(f,weak_seed=False,state=None):
 if state is None:state=[0,names(f)]
 op=f[0]
 if op in ('var','const','false','true'):return f
 if op in ('forall','exists'):
  _,x,b=f;b=translate(b,weak_seed,state)
  if op=='forall':b=imp(O(x),b)
  elif not (weak_seed and x=='u'):b=AND(O(x),b)
  return (op,x,b)
 if op=='R':
  while True:
   state[0]+=1;p,q='ip'+str(state[0]),'op'+str(state[0])
   if p not in state[1] and q not in state[1]:break
  state[1].update([p,q]);return decoder(*(x[1] for x in f[1:]),p,q)
 return (op,*(translate(x,weak_seed,state) for x in f[1:]))
def H48():
 C=OR(eq('t','z'),eq('t','a'))
 return ALL(['x','y','t'],EX('u',FA('w',AND(imp(AND(eq('t','a'),eq('y','z')),eq('u','z')),imp(C,R('t','x','y','u')),imp(R('t','x','y','w'),AND(C,eq('w','u')))))))
def H36():
 C=OR(eq('t','z'),eq('t','a'))
 return ALL(['x','y','t'],EX('u',FA('w',AND(imp(C,R('t','x','y','u')),imp(R('t','x','y','w'),AND(C,eq('w','u')))))))
def B(x):return AND(O(x),FA('r',imp(O('r'),neg(E(x,'r')))))
def D(x):return SOME(['b','c'],AND(O('b'),O('c'),FA('r',imp(AND(E('b','r'),E('r','c')),eq('r',x)))))
def S(x):return OR(B(x),D(x))
def fixed(typed=False,named=False,no_annihilator=False):
 h=translate(H36() if no_annihilator else H48(),not typed)
 body=AND(O('z'),O('a'),FA('x',AND(S('x'),h[2])))
 return body if named else SOME(['z','a'],body)
def L():return EX('q',AND(E('a','q'),FA('p',imp(E('p','z'),E('p','q')))))
def scheme(theta):return ALL(['z','a'],imp(O('z'),imp(O('a'),imp(L(),translate(theta)))))
def reverse_E():
 zero,one=const(0),const(1)
 coordinate=AND(eq('u',zero),eq('r',add('v',one)))
 pair=EX('b',AND(eq('u',add('b',one)),OR(AND(eq('r',zero),eq('v','s')),AND(eq('r',one),eq('s',add('b','v'))),AND(eq('r',add(one,one)),eq('s',mul('b','v'))))))
 return OR(coordinate,pair)
def occurrences(f,ops):
 if f[0] in ('var','const','false','true'):return 0
 if f[0] in ('forall','exists'):return int(f[0] in ops)+occurrences(f[2],ops)
 return int(f[0] in ops)+sum(occurrences(x,ops) for x in f[1:])
def main():
 forms={'structure34':FA('x',S('x')),'source_H48':H48(),'typed_H95':translate(H48()),'weak_H92':translate(H48(),True),'typed_fixed137':fixed(True),'fixed134':fixed(),'named_fixed132':fixed(named=True),'source_H36':H36(),'weak_H80':translate(H36(),True),'named_fixed120':fixed(named=True,no_annihilator=True),'decoder21':decoder('t','x','y','w'),'L13':L(),'scheme22_test':scheme(eq('v','v')),'reverse_E46':reverse_E(),'reverse_O3':eq('u',const(0)),'reverse_domain3':eq('u','u'),'reverse_equality7':AND(eq('u','r'),eq('v','s')),'zero_definition20':AND(O('z'),EX('a',AND(O('a'),L()))),'unit_definition20':AND(O('a'),EX('z',AND(O('z'),L())))}
 expected={'structure34':34,'source_H48':48,'typed_H95':95,'weak_H92':92,'typed_fixed137':137,'fixed134':134,'named_fixed132':132,'source_H36':36,'weak_H80':80,'named_fixed120':120,'decoder21':21,'L13':13,'scheme22_test':25,'reverse_E46':46,'reverse_O3':3,'reverse_domain3':3,'reverse_equality7':7,'zero_definition20':20,'unit_definition20':20}
 for name,formula in forms.items():
  if size(formula)!=expected[name]:raise RuntimeError((name,size(formula),expected[name]))
 tests=[eq('x','x'),R('a','x','y','z'),FA('x',R('z','x','x','x')),EX('u',R('a','u','z','u')),R('a','ip1','op1','z')]
 tests += [imp(t,EX('y',t)) for t in list(tests)]
 for theta in tests:
  expected_size=size(theta)+16*occurrences(theta,{'R'})+3*occurrences(theta,{'forall','exists'})+22
  if size(scheme(theta))!=expected_size:raise RuntimeError('Generic body ledger failed')
 here=Path(__file__).parent
 for name,formula in forms.items():(here/(name+'.sexp')).write_text(sexp(formula)+'\n')
 result={'status':'PASS','signature':{'binary_relation':'E','unary_relation':'O','named_option_additional_constants':['z','a']},'nodes':{name:size(f) for name,f in forms.items()},'fixed':134,'scheme':'N + 16r + 3q + 22','named_fixed_single_sentence':120,'named_fixed_four_sentence_sum':118,'named_fixed_sentence_costs':[2,2,34,80],'named_scheme':'N + 16r + 3q','reverse_domain':'entire N^2','reverse_E_in_L0_nodes':46,'reverse_O_nodes':3,'predecessor_symbol_used':False,'relation_decoder_nodes':21,'forward_zero_and_one_definition_nodes_each':20,'all_checks_active_under_python_O':True,'comparison':'Adds unary O; not a one-symbol domination of 155/30.'}
 (here/'marker_free_metrics.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
