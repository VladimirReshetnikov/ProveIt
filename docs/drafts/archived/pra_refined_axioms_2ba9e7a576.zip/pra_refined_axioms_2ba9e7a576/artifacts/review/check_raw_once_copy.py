"""Independently authored AST/count and finite witness diagnostics.
No downloaded scripts or modules are executed/imported. Assertions are explicit
exceptions, so python -O retains all checks. This is not a formal proof.
"""
from dataclasses import dataclass
from itertools import product
import json
@dataclass(frozen=True)
class N:
 op:str
 args:tuple=()
 desc:object=None

def f(op,*args,desc=None):return N(op,args,desc)
def v(s):return f('v:'+s)
a,b,c,d,n,x,y,r,s,w=[v(t) for t in ('a','b','c','d','n','x','y','r','s','w')]
z=f('0');bot=f('bottom')
def S(t):return f('S',t)
def DS(t):return f('D',t,t)
def Eq(t,u):return f('=',t,u)
def Imp(A,B):return f('imp',A,B)
def And(A,B):return f('and',A,B)
def Or(A,B):return f('or',A,B)
def Iff(A,B):return f('iff',A,B)
def Not(A):return Imp(A,bot)
def Q(t,u):return f('Q',t,u,desc=w)
def Z(t,u):return f('Z',t,u,desc=z)
def pref(bs,A):
 for op,var in reversed(bs):A=f(op+':'+var.op,A)
 return A

def sz(A,full=False):return 1+sum(sz(t,full) for t in A.args)+(sz(A.desc,True) if full and A.desc is not None else 0)
def subst(A,u):return u if A==x else N(A.op,tuple(subst(t,u) for t in A.args),A.desc)
def occ(A):return int(A==x)+sum(occ(t) for t in A.args)
def expanded(A):
 args=tuple(expanded(t) for t in A.args)
 if A.op=='iff':return And(Imp(args[0],args[1]),Imp(args[1],args[0]))
 return N(A.op,args,A.desc)
def OT(t,succ=S):
 h=Imp(Imp(Eq(x,succ(b)),Eq(b,n)),Eq(x,b))
 u=Imp(Eq(t,z),Eq(x,z))
 return pref([('all',a),('all',n),('ex',b)],And(Not(Eq(b,succ(b))),pref([('all',x)],Imp(h,Iff(u,Eq(x,b))))))
def FR(t,succ=DS,shifted=True):
 inp=succ(b) if shifted else b
 return pref([('all',a),('all',n),('ex',b),('ex',c)],And(Eq(c,Q(Z(subst(t,inp),inp),n)),Eq(Z(subst(t,c),c),z)))
def FRS(t):
 return pref([('all',a),('all',n),('ex',b),('ex',d),('ex',c)],And(And(Eq(d,DS(b)),Eq(c,Q(Z(subst(t,d),d),n))),Eq(Z(subst(t,c),c),z)))
def FRtable(t,shifted=True):
 inp=DS(b) if shifted else b
 kernel=And(Eq(c,Q(Z(r,inp),n)),Eq(Z(s,c),z))
 table=pref([('all',x),('all',y)],Imp(Or(And(Eq(x,inp),Eq(y,r)),And(Eq(x,c),Eq(y,s))),Eq(t,y)))
 return pref([('all',a),('all',n),('ex',b),('ex',c),('ex',r),('ex',s)],And(kernel,table))
def FB(t,succ_shared=False,table=False):
 if table:
  kernel=Eq(f('chi',b,Q(Z(r,S(b)),n)),S(Z(s,b)))
  tab=pref([('all',x),('all',y)],Imp(Or(And(Eq(x,b),Eq(y,s)),And(Eq(x,S(b)),Eq(y,r))),Eq(t,y)))
  return pref([('all',a),('all',n),('ex',b),('ex',r),('ex',s)],And(kernel,tab))
 inp=d if succ_shared else S(b)
 kernel=Eq(f('chi',b,Q(Z(subst(t,inp),inp),n)),S(Z(subst(t,b),b)))
 if succ_shared:return pref([('all',a),('all',n),('ex',b),('ex',d)],And(Eq(d,S(b)),kernel))
 return pref([('all',a),('all',n),('ex',b)],kernel)
def need(c,m):
 if not c:raise RuntimeError(m)
terms=[z,x,a,S(x),DS(x),Q(x,a),Z(DS(x),x),f('R',x,a,desc=Q(x,DS(a)))]
terms += [f('D',t,u) for t in terms[:8] for u in terms[:8]]
for t in terms:
 i=occ(t)
 for full in [False,True]:
  L=sz(t,full);dd=3 if full else 0
  need(sz(OT(t),full)==L+34,'OT count')
  need(sz(OT(t,DS),full)==L+36,'D OT count')
  need(sz(expanded(OT(t)),full)==2*L+45,'expanded OT count')
  need(sz(expanded(OT(t,DS)),full)==2*L+47,'expanded D OT count')
  need(sz(FR(t),full)==2*L+2*i+17+dd,'FR D count')
  need(sz(FRS(t),full)==2*L+22+dd,'FR D shared count')
  need(sz(FR(t,shifted=False),full)==2*L+15+dd,'FR D covered count')
  need(sz(FB(t),full)==2*L+i+14+dd,'FB count')
  need(sz(FB(t,True),full)==2*L+19+dd,'FB shared count')
  need(sz(FB(t,table=True),full)==L+40+dd,'FB table count')
  need(sz(FRtable(t),full)==L+44+dd,'FR D table count')
  need(sz(FRtable(t,False),full)==L+40+dd,'FR D covered table count')
# Full-cost profiles, relaxing grammar constraints only enlarges checked set.
profiles=0
for T in range(1,101):
 for i in range(T+1):
  old=min(2*T+i+17,2*T+22,T+43)
  new=min(2*T+i+17,2*T+22,T+34)
  need(new<=old,'S weak envelope')
  need((new<old)==(T>12 and T+i>17),'S strict condition')
  oldD=min(2*T+2*i+20,2*T+25)
  newD=min(oldD,T+36)
  need((newD<oldD)==(T>11 and T+2*i>16),'D strict condition')
  need(T+36<T+47,'D table comparison')
  need(T+36<T+43,'D covered table comparison')
  profiles+=1
# Reverse-witness diagnostics: finite truth tables, all targets with next-point
# available. Scan chooses a native-boundary witness; OT universal is then checked.
checks=0
for bits in product([False,True],repeat=10):
 witness=0
 for target in range(8):
  if target and bits[witness+1]:witness=target
  b0=witness
  need(b0==0 or bits[b0],'NB anchor')
  need(not bits[b0+1] or b0==target,'NB endpoint')
  need(b0!=b0+1,'local nofix')
  for xx in range(10):
   implies=lambda p,q:(not p) or q
   h=implies(implies(xx==b0+1,b0==target),xx==b0)
   u=implies(not bits[xx],xx==0)
   need(implies(h,u==(xx==b0)),'OT reverse finite witness')
   checks+=1
print(json.dumps({'status':'PASS','tail_ast_cases':len(terms),'full_profiles':profiles,'finite_reverse_checks':checks,'full_costs':{'OT':'T+34','OT_D':'T+36','OT_expanded_iff':'2T+45','OT_D_expanded_iff':'2T+47','D17_factored':'2T+2i+20','D17_shared':'2T+25','D24_covered':'2T+18','D17_hypothetical_once_table':'T+47','D24_hypothetical_once_table':'T+43'},'strict_conditions':{'saturated_S_envelope':'T>12 and T+i>17','D17_envelope':'T>11 and T+2i>16'},'scope':'Written intuitionistic proof audited separately; finite syntax/truth tests are diagnostics only.'},indent=2,sort_keys=True))
