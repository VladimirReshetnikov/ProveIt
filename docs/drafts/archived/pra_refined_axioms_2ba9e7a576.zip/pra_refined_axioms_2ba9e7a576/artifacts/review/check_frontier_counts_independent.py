"""Fresh independent counts; no downloaded module is executed or imported."""
from dataclasses import dataclass
import json
@dataclass(frozen=True)
class N:
 op:str
 args:tuple=()
 desc:object=None

def V(x):return N('var:'+x)
def f(op,*a,desc=None):return N(op,a,desc)
def q(op,x,A):return N(op+':'+x,(A,))
def prefix(ops,A):
 for op,x in reversed(ops):A=q(op,x,A)
 return A
z=f('0');a,b,c,n,x,y,w=[V(s) for s in 'abcnxyw']
def S(t):return f('S',t)
def D(t,u):return f('D',t,u)
def Q(t,u):return f('Q',t,u,desc=w)
def Z(t,u):return f('Z',t,u,desc=z)
def eq(t,u):return f('=',t,u)
def OR(t,u):return f('or',t,u)
def AND(t,u):return f('and',t,u)
def IMP(t,u):return f('imp',t,u)
def neg(t):return IMP(t,f('false'))
def sub(t,new):
 if t==x:return new
 return N(t.op,tuple(sub(v,new) for v in t.args),t.desc)
def sz(t,full=False):return 1+sum(sz(v,full) for v in t.args)+(sz(t.desc,True) if full and t.desc is not None else 0)
def occ(t):return int(t==x)+sum(occ(v) for v in t.args)
def NB(A):return prefix([('all','a'),('all','n'),('ex','b')],AND(OR(eq(b,z),sub(A,b)),IMP(sub(A,S(b)),eq(b,n))))
def B3(A):return prefix([('all','a'),('all','n'),('ex','b'),('ex','c')],AND(IMP(sub(A,b),sub(A,n)),OR(eq(b,z),AND(eq(b,S(c)),sub(A,c)))))
def DC(A):return q('all','a',IMP(q('all','x',IMP(OR(eq(x,z),A),sub(A,S(x)))),q('all','x',OR(eq(x,z),A))))
def IND(A):return q('all','a',IMP(AND(sub(A,z),q('all','x',IMP(A,sub(A,S(x))))),q('all','n',sub(A,n))))
def BIND(A):return q('all','a',IMP(AND(sub(A,z),prefix([('all','x'),('all','y')],IMP(eq(y,S(x)),IMP(A,sub(A,y))))),q('all','n',sub(A,n))))
def SP(A):return q('all','a',IMP(q('all','x',IMP(OR(eq(x,z),A),sub(A,S(x)))),q('all','x',sub(A,S(x)))))
def FR(t,merged=False,shift=True):
 sb=D(b,b) if merged else S(b)
 at=sb if shift else b
 return prefix([('all','a'),('all','n'),('ex','b'),('ex','c')],AND(eq(c,Q(Z(sub(t,at),at),n)),eq(Z(sub(t,c),c),z)))
def FB(t):return prefix([('all','a'),('all','n'),('ex','b')],eq(f('chi',b,Q(Z(sub(t,S(b)),S(b)),n)),S(Z(sub(t,b),b))))
def FBshare(t):
 d=V('d')
 return prefix([('all','a'),('all','n'),('ex','b'),('ex','d')],AND(eq(d,S(b)),eq(f('chi',b,Q(Z(sub(t,d),d),n)),S(Z(sub(t,b),b)))))
def FBtable(t):
 r,s=V('r'),V('s')
 K=eq(f('chi',b,Q(Z(r,S(b)),n)),S(Z(s,b)))
 tab=prefix([('all','x'),('all','y')],IMP(OR(AND(eq(x,b),eq(y,s)),AND(eq(x,S(b)),eq(y,r))),eq(t,y)))
 return prefix([('all','a'),('all','n'),('ex','b'),('ex','r'),('ex','s')],AND(K,tab))
def NBshare(A):
 d=V('d')
 return prefix([('all','a'),('all','n'),('ex','b'),('ex','d')],AND(AND(eq(d,S(b)),OR(eq(b,z),sub(A,b))),IMP(sub(A,d),eq(b,n))))
def FRDshare(t):
 d=V('d')
 return prefix([('all','a'),('all','n'),('ex','b'),('ex','d'),('ex','c')],AND(AND(eq(d,D(b,b)),eq(c,Q(Z(sub(t,d),d),n))),eq(Z(sub(t,c),c),z)))
def C(t,r):return f('C',r,a,desc=t)
def fused_mask(t,shift=True):
 w=eq(C(t,Q(C(t,S(b) if shift else b),n)),z)
 de=eq(C(t,n),Z(sub(t,n),n))
 return prefix([('all','a'),('all','n'),('ex','b')],AND(de,w))
def require(p,m):
 if not p:raise RuntimeError(m)
terms=[z,x,a,S(x),Q(x,a),f('chi',x,a),Q(Q(x,x),a),f('R',x,a,desc=Q(x,S(a)))]
formulas=[f('false')]+[eq(t,u) for t in terms for u in terms]
formulas += [AND(formulas[1],formulas[2]),IMP(formulas[3],OR(formulas[4],formulas[5]))]
for A in formulas:
 F,j=sz(A,True),occ(A);m=sz(A)
 for full,L in [(False,m),(True,F)]:
  expected=[2*L+j+12,3*L+15,3*L+j+13,4*L+j+6,4*L+12,3*L+2*j+9]
  got=[sz(fn(A),full) for fn in [NB,B3,DC,IND,BIND,SP]]
  require(got==expected,f'Formula counts {got} != {expected}')
  require(sz(B3(A),full)-sz(NB(A),full)>=4,'B3 domination')
  require(sz(DC(A),full)-sz(NB(A),full)==L+1,'DC domination')
  require(sz(NBshare(A),full)==2*L+18,'NB successor sharing')
for t in terms:
 m,T,i=sz(t),sz(t,True),occ(t)
 for full,L in [(False,m),(True,T)]:
  d=3 if full else 0
  require(sz(FR(t),full)==2*L+i+16+d,'FRS')
  require(sz(FR(t,True),full)==2*L+2*i+17+d,'FR17')
  require(sz(FR(t,True,False),full)==2*L+15+d,'FR24')
  require(sz(FB(t),full)==2*L+i+14+d,'FB')
  require(sz(FBshare(t),full)==2*L+19+d,'FB sharing')
  require(sz(FBtable(t),full)==L+40+d,'FB table')
  require(sz(FRDshare(t),full)==2*L+22+d,'FRD sharing')
 require(sz(fused_mask(t),False)==m+20,'F13 active')
 require(sz(fused_mask(t),True)==4*T+22,'F13 full')
 require(sz(fused_mask(t,False),False)==m+19,'F12 active')
 require(sz(fused_mask(t,False),True)==4*T+21,'F12 full')
coverage=eq(x,S(Q(x,z)))
print(json.dumps({'status':'PASS','formula_cases':len(formulas),'tail_cases':len(terms),'counts_full':{'native_boundary':'2F+j+12','boundary_schema':'3F+15','direct_closure':'3F+j+13','ordinary_induction':'4F+j+6','bound_step_induction':'4F+12','successor_propagation':'3F+2j+9','factored_S':'2T+i+19','factored_D17':'2T+2i+20','factored_D24':'2T+18','fused_boundary':'2T+i+17','fused_successor_shared':'2T+22','fused_single_table':'T+43','factored_D_successor_shared':'2T+25','native_boundary_successor_shared':'2F+18','fused_named_mask13':'4T+22','fused_named_mask12':'4T+21'},'atomic_NB_coverage_instance':{'active':sz(NB(coverage)),'full':sz(NB(coverage),True),'equation_active':sz(coverage),'equation_full':sz(coverage,True),'input_occurrences':occ(coverage)},'scope':'Exact finite syntax checks, not formal proof or global optimality.'},indent=2,sort_keys=True))
