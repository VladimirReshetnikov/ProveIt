#!/usr/bin/env python3
"""Fresh AST audit of current round10 templates; no supplied code imported."""
from dataclasses import dataclass
import json
@dataclass(frozen=True)
class E:
 op:str
 args:tuple=()
 desc:object=None
 def size(self,full=False):return 1+sum(x.size(full) for x in self.args)+(self.desc.size(True) if full and self.desc else 0)
def e(op,*a,desc=None):return E(op,a,desc)
x,a,n,b,c,u,d,r,s,y=[e(k) for k in 'x a n b c u d r s y'.split()];z=e('0');bot=e('bottom')
def S(t):return e('S',t)
def Q(t,v):return e('Q',t,v,desc=e('w'))
def Z(t,v):return e('Z',t,v,desc=z)
def chi(t,v):return e('chi',t,v)
def eq(t,v):return e('=',t,v)
def land(t,v):return e('and',t,v)
def lor(t,v):return e('or',t,v)
def imp(t,v):return e('implies',t,v)
def binder(kind,v,body):return e(kind+':'+v.op,body)
def bind(bs,body):
 for kind,v in reversed(bs):body=binder(kind,v,body)
 return body
def subst(t,k,v):
 if not t.args:return v if t.op==k else t
 return E(t.op,tuple(subst(q,k,v) for q in t.args),t.desc)
def at(t,v):return subst(t,'x',v)
def occ(t,k='x'):return int(not t.args and t.op==k)+sum(occ(q,k) for q in t.args)
def need(c,m):
 if not c:raise RuntimeError(m)
bs=[('forall',a),('forall',n),('exists',b)]
def nb(P):return bind(bs,land(lor(eq(b,z),at(P,b)),imp(at(P,S(b)),eq(b,n))))
def boundary(P):return bind(bs+[('exists',c)],land(imp(at(P,b),at(P,n)),lor(eq(b,z),land(eq(b,S(c)),at(P,c)))))
def dc(P):return binder('forall',a,imp(binder('forall',x,imp(lor(eq(x,z),P),at(P,S(x)))),binder('forall',x,lor(eq(x,z),P))))
def i3(P):return binder('forall',a,imp(bind([('forall',b),('forall',c)],imp(lor(eq(c,z),land(eq(c,S(b)),at(P,b))),at(P,c))),binder('forall',n,at(P,n))))
def ji(t):return bind(bs+[('forall',u)],imp(eq(u,Q(Z(at(t,S(b)),S(b)),n)),eq(Z(at(t,u),u),z)))
def fb(t):return bind(bs,eq(chi(b,Q(Z(at(t,S(b)),S(b)),n)),S(Z(at(t,b),b))))
def fbs(t):return bind(bs+[('exists',d)],land(eq(d,S(b)),eq(chi(b,Q(Z(at(t,d),d),n)),S(Z(at(t,b),b)))))
def fbt(t):
 K=eq(chi(b,Q(Z(r,S(b)),n)),S(Z(s,b)))
 table=bind([('forall',x),('forall',y)],imp(lor(land(eq(x,b),eq(y,s)),land(eq(x,S(b)),eq(y,r))),eq(t,y)))
 return bind(bs+[('exists',r),('exists',s)],land(K,table))
def fused12(t):
 def C(v,w):return e('C',v,w,desc=t)
 return bind(bs,land(eq(C(n,a),Z(at(t,n),n)),eq(C(Q(C(b,a),n),a),z)))
tails=[z,x,a,S(x),chi(x,a),Q(x,a),Z(Q(x,S(a)),x),e('R',x,a,desc=S(e('v')))]
for k in range(1,10):tails.append(chi(tails[-1],x))
rows=[]
for t in tails:
 m,T,i=t.size(),t.size(True),occ(t)
 expected={'J':[16+2*m+i,19+2*T+i],'FB':[14+2*m+i,17+2*T+i],'FB-S':[19+2*m,22+2*T],'FB-T':[40+m,43+T],'fused12':[19+m,21+4*T]}
 actual={name:[f(t).size(),f(t).size(True)] for name,f in [('J',ji),('FB',fb),('FB-S',fbs),('FB-T',fbt),('fused12',fused12)]}
 need(actual==expected,'Raw-tail profile '+str((actual,expected)))
 rows.append({'m':m,'T':T,'i':i,'counts':actual})
forms=[bot,eq(x,a),eq(Q(x,a),S(x)),imp(eq(x,a),bot),land(eq(x,a),eq(x,z))]
for t in tails:forms.append(eq(t,a))
formula_rows=[]
for P in forms:
 f,F,j=P.size(),P.size(True),occ(P)
 actual={name:[q(P).size(),q(P).size(True)] for name,q in [('NB',nb),('Boundary3',boundary),('DC',dc),('I3',i3)]}
 expected={'NB':[12+2*f+j,12+2*F+j],'Boundary3':[15+3*f,15+3*F],'DC':[13+3*f+j,13+3*F+j],'I3':[15+3*f,15+3*F]}
 need(actual==expected,'Native formula profile')
 need(actual['NB'][0]<actual['DC'][0] and actual['NB'][1]<actual['DC'][1],'NB/DC strict comparison')
 need(actual['Boundary3'][1]-actual['NB'][1]>=4,'Formula root strict bound')
 formula_rows.append({'f':f,'F':F,'j':j,'counts':actual})
print(json.dumps({'status':'PASS','raw_tail_profiles':rows,'native_formula_profiles':formula_rows,'scope':['Exact expanded AST checks, with one-node descriptors of Q,Z charged at every call.','Every frozen descriptor is unchanged by active substitution.','Current eligibility versus archived and dominance among eligible current proposals are distinct tests.','No global minimum or cross-language equal-cost identification is asserted.','Finite diagnostics only; arbitrary-carrier adequacy is a written proof obligation.']},indent=2,sort_keys=True))
