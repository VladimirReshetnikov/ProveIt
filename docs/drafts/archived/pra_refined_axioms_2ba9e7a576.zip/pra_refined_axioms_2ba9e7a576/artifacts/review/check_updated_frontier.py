"""Fresh independent AST checks for the updated2ba9 numerical benchmark.
No downloaded source is executed or imported.
"""
from dataclasses import dataclass
from itertools import product
import json
@dataclass(frozen=True)
class N:
 op:str
 args:tuple=()
 desc:object=None
def f(op,*args,desc=None):return N(op,args,desc)
def V(s):return f('v:'+s)
x,a,b,c,n,y,w=map(V,['x','a','b','c','n','y','w']);z=f('0')
def S(t):return f('S',t)
def DS(t):return f('D',t,t)
def D(t,u):return f('D',t,u)
def X(t,u):return f('chi',t,u)
def Q(t,u):return f('Q',t,u,desc=w)
def Z(t,u):return f('Z',t,u,desc=z)
def eq(t,u):return f('=',t,u)
def And(t,u):return f('and',t,u)
def Or(t,u):return f('or',t,u)
def Imp(t,u):return f('imp',t,u)
def Not(t):return Imp(t,f('bottom'))
def pre(bs,t):
 for op,v in reversed(bs):t=f(op+':'+v.op,t)
 return t
base=[('all',a),('all',n),('ex',b)]
def sub(t,v):return v if t==x else N(t.op,tuple(sub(s,v) for s in t.args),t.desc)
def sz(t,full=False):return 1+sum(sz(s,full) for s in t.args)+(sz(t.desc,True) if full and t.desc is not None else 0)
def occ(t):return int(t==x)+sum(map(occ,t.args))
def SC(t):
 A=Q(X(b,z),X(x,b));B=Q(X(b,n),X(x,S(b)))
 return pre(base+[('all',x)],eq(Q(Z(t,S(A)),B),z))
def DB(t,succ=S):return pre(base,And(eq(Z(sub(t,b),b),z),Or(eq(sub(t,succ(b)),z),eq(b,n))))
def DBS(t,succ=S):return pre(base+[('ex',c)],And(And(eq(c,succ(b)),eq(Z(sub(t,b),b),z)),Or(eq(sub(t,c),z),eq(b,n))))
def TB(t,succ=S):
 guard=Or(And(eq(x,b),eq(y,z)),And(And(eq(x,succ(b)),eq(y,x)),Not(eq(b,n))))
 return pre(base+[('all',x),('all',y)],Imp(guard,eq(Z(t,x),y)))
def CT(t,merged=False,algebraic=False):
 succ=DS if merged else S
 guard=Or(eq(x,b),And(eq(x,succ(b)),Not(eq(b,n))))
 if merged:
  right=eq(Z(t,x),Z(D(x,b),x))
  if algebraic:guard=eq(x,Q(D(x,b),Q(D(b,n),succ(b))))
 else:right=eq(X(Z(t,x),z),X(x,b))
 return pre(base+[('all',x)],Imp(guard,right))
def AT(s,t):return pre(base+[('all',x)],Imp(Or(eq(x,b),eq(x,S(b))),Or(eq(X(s,t),X(x,b)),eq(b,Q(X(x,b),n)))))
def need(p,s):
 if not p:raise RuntimeError(s)
terms=[z,x,a,S(x),DS(x),Q(x,a),Z(Q(x,x),a),f('R',x,a,desc=Q(x,S(a)))]
terms += [X(t,u) for t in terms[:] for u in terms[:]]
for t in terms:
 i=occ(t)
 for full in [False,True]:
  L=sz(t,full);d=int(full)
  expected=[L+24+4*d,2*L+i+14+d,2*L+20+d,L+32+d,2*L+2*i+14+d,2*L+21+d,L+33+d,L+27+d,L+28+2*d,L+26+4*d]
  actual=[sz(fn,full) for fn in [SC(t),DB(t),DBS(t),TB(t),DB(t,DS),DBS(t,DS),TB(t,DS),CT(t),CT(t,True),CT(t,True,True)]]
  need(expected==actual,'Numerical profiles: '+str((expected,actual)))
  P=eq(t,a);F=sz(P,full)
  need(sz(AT(t,a),full)==F+25+d,'Atomic table profile')
profiles=0
for T in range(1,101):
 for i in range(T+1):
  old=min(2*T+i+17,2*T+22,T+43)
  sc=min(2*T+i+17,2*T+22,T+28)
  need(old-sc==max(0,min(T+i-11,T-6,15)),'SC savings')
  term=min(2*T+i+15,2*T+21,T+33)
  need(term<old,'Term strict S envelope')
  combined=min(2*T+i+15,2*T+21,T+28)
  need(combined<=sc and combined<=term,'S combined')
  oldD=min(37+2*T+2*i,42+2*T)
  newD=17+2*T+min(2*i+15,22)
  need(oldD-newD==(5 if i<=2 else 4 if i==3 else 3),'D singleton profile')
  profiles+=1
# Reverse SC/TB finite diagnostics using arbitrary multivaluedraw terms.
checks=0
for vals in product(range(3),repeat=8):
 witness=0
 for target in range(6):
  if target and vals[witness+1]!=0:witness=target
  b0=witness
  need(b0==0 or vals[b0]!=0,'NB anchor')
  need(vals[b0+1]==0 or b0==target,'NB endpoint')
  for xx in range(8):
   A=int(b0!=0 and xx==b0)
   B=int(b0!=target and xx==b0+1)
   need((A if vals[xx]==0 else B)==0,'SC reverse')
   mask=xx if vals[xx]==0 else 0
   if xx==b0:need(mask==0,'TB first row')
   if xx==b0+1 and b0!=target:need(mask==xx,'TB second row')
   checks+=1
print(json.dumps({'status':'PASS','tail_profiles':len(terms),'envelope_profiles':profiles,'multivalued_reverse_cases':checks,'full_costs':{'SC':'T+28','DB_S':'2T+i+15','DBS_S':'2T+21','TB_S':'T+33','DB_D':'2T+2i+15','DBS_D':'2T+22','TB_D':'T+34','CT_chi':'T+28','CT_D':'T+30','AT':'F+26'},'scope':'Finite diagnostics of independently read written proofs; not a formal proof certificate.'},indent=2,sort_keys=True))
