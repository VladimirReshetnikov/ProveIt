"""Fresh independent signed-strong-conditional AST/finite-kernel checks.
No downloaded module or script is imported/executed.
"""
from dataclasses import dataclass
from itertools import product
import json
@dataclass(frozen=True)
class N:
 op:str
 args:tuple=()
 desc:object=None
def f(op,*a,desc=None):return N(op,a,desc)
def V(s):return f('v:'+s)
x,a,b,n,w=map(V,['x','a','b','n','w']);z=f('0');bottom=f('bottom')
def S(t):return f('S',t)
def DS(t):return f('D',t,t)
def Q(t,u):return f('Q',t,u,desc=w)
def Z(t,u):return f('Z',t,u,desc=z)
def eq(t,u):return f('=',t,u)
def And(t,u):return f('and',t,u)
def Or(t,u):return f('or',t,u)
def Imp(t,u):return f('imp',t,u)
def Not(t):return Imp(t,bottom)
def If(c,u,v):return f('If',c,u,v)
def pre(bs,t):
 for op,v in reversed(bs):t=f(op+':'+v.op,t)
 return t
base=[('all',a),('all',n),('ex',b)]
def sub(t,u):return u if t==x else N(t.op,tuple(sub(v,u) for v in t.args),t.desc)
def sz(t,full=False):return 1+sum(sz(v,full) for v in t.args)+(sz(t.desc,True) if full and t.desc is not None else 0)
def occ(t):return int(t==x)+sum(map(occ,t.args))
def direct(E,negative=False,succ=S):
 B,SB=sub(E,b),sub(E,succ(b))
 matrix=And(Imp(B,eq(b,z)),Or(eq(b,n),SB)) if negative else And(Or(eq(b,z),B),Imp(SB,eq(b,n)))
 return pre(base,matrix)
def conditional(E,negative=False,succ=S):
 left,right=Imp(eq(x,succ(b)),eq(b,n)),Imp(eq(x,b),eq(b,z))
 if negative:left,right=right,left
 return pre(base+[('all',x)],If(E,left,right))
def expand(t):
 args=tuple(expand(s) for s in t.args)
 if t.op=='If':
  c,u,v=args
  return Or(And(c,u),And(Not(c),v))
 return N(t.op,args,t.desc)
def DB(t,succ=S):return pre(base,And(eq(Z(sub(t,b),b),z),Or(eq(sub(t,succ(b)),z),eq(b,n))))
def need(p,m):
 if not p:raise RuntimeError(m)
terms=[z,x,a,S(x),DS(x),Q(x,a),Z(Q(x,x),a),f('R',x,a,desc=Q(x,S(a)))]
terms += [f('D',t,u) for t in terms[:] for u in terms[:]]
formulas=[eq(t,u) for t in terms[:8] for u in terms[:8]]
formulas += [Not(formulas[0]),And(formulas[1],formulas[2]),Imp(formulas[3],Or(formulas[4],formulas[5]))]
for E in formulas:
 i=occ(E)
 for full in [False,True]:
  G=sz(E,full)
  for negative in [False,True]:
   need(sz(direct(E,negative),full)==2*G+i+12,'direct S')
   need(sz(direct(E,negative,DS),full)==2*G+2*i+12,'direct D')
   need(sz(conditional(E,negative),full)==G+20,'If S')
   need(sz(conditional(E,negative,DS),full)==G+21,'If D')
   need(sz(expand(conditional(E,negative)),full)==2*G+24,'expanded S')
   need(sz(expand(conditional(E,negative,DS)),full)==2*G+25,'expanded D')
for t in terms:
 i=occ(t)
 for full in [False,True]:
  T=sz(t,full);d=int(full)
  need(sz(DB(t),full)==2*T+i+14+d,'DB S')
  need(sz(DB(t,DS),full)==2*T+2*i+14+d,'DB D')
  need(sz(conditional(eq(t,z),True),full)==T+22,'raw negative S')
  need(sz(conditional(eq(t,z),True,DS),full)==T+23,'raw negative D')
meta=If(f('A'),f('U'),f('V'))
need(sz(f('rewrite',meta,expand(meta)))==14,'logical header14')
profiles=0
for T in range(1,101):
 for i in range(1,(T+1)//2+1):
  old=min(2*T+i+15,T+24)
  new=min(2*T+i+15,T+22)
  need(old-new==max(0,min(T+i-7,2)),'raw S favorable saving')
  generous=min(2*T+i+15,2*T+21,T+28,T+29,T+32,T+24,2*T+18)
  need(old==generous,'all compatible S candidates including free coverage')
  oldD=min(2*T+2*i+15,T+25)
  newD=min(2*T+2*i+15,T+23)
  need(oldD-newD==max(0,min(T+2*i-8,2)),'raw D favorable saving')
  need(newD<=min(2*T+2*i+15,2*T+22,T+34),'newD vs printed D17')
  profiles+=1
# Finite reverse checks on arbitrary predicate sequences, all points tested.
reverse=0
for bits in product([False,True],repeat=10):
 for negative in [False,True]:
  P=[not e for e in bits] if negative else list(bits)
  witness=0
  for target in range(8):
   if target and P[witness+1]:witness=target
   bb=witness
   need(bb==0 or P[bb],'NB anchor')
   need(not P[bb+1] or bb==target,'NB endpoint')
   for xx in range(10):
    implication=lambda a,b:not a or b
    if negative:U,V=implication(xx==bb,bb==0),implication(xx==bb+1,bb==target)
    else:U,V=implication(xx==bb+1,bb==target),implication(xx==bb,bb==0)
    need((bits[xx] and U) or (not bits[xx] and V),'reverse strong If')
    reverse+=1
# Pure finite kernel checks with arbitrary successor maps, including fixed points.
# These are diagnostics; the arbitrary-model intuitionistic proof is written.
kernels=0
for card in range(1,4):
 for successor in product(range(card),repeat=card):
  for E in product([False,True],repeat=card):
   for negative in [False,True]:
    P=[not e for e in E] if negative else list(E)
    if not(P[0] and all(not P[k] or P[successor[k]] for k in range(card))):continue
    for target,bb in product(range(card),repeat=2):
     imp=lambda a,b:not a or b
     def matrix(xx):
      U,V=imp(xx==successor[bb],bb==target),imp(xx==bb,bb==0)
      if negative:U,V=V,U
      return (E[xx] and U) or (not E[xx] and V)
     if all(matrix(xx) for xx in range(card)):need(P[target],'pure forward kernel')
     kernels+=1
print(json.dumps({'status':'PASS','formula_AST_profiles':len(formulas),'raw_AST_profiles':len(terms),'legal_size_profiles':profiles,'reverse_point_cases':reverse,'arbitrary_successor_kernel_cases':kernels,'costs':{'signed_direct':'2G+i+12','signed_conditional':'G+20','raw_S':'min(2T+i+15,T+22)','raw_D':'min(2T+2i+15,T+23)','raw_S_expanded_conditional':'2T+28','raw_D_expanded_conditional':'2T+29','If_header':14},'scope':'Exact independent syntax and finite diagnostics, not an intuitionistic proof certificate.'},indent=2,sort_keys=True))
