#!/usr/bin/env python3
"""Authored finite AST diagnostics; no downloaded code or removable asserts."""
from dataclasses import dataclass
import json
from itertools import product

@dataclass(frozen=True)
class N:
    op: str
    args: tuple = ()
    body: object = None

def v(name): return N('var:'+name)
def app(op, *args, body=None): return N(op, tuple(args), body)
z=app('0'); x=v('x'); a=v('a'); n=v('n'); state=v('v'); w=v('w')
def S(t): return app('S',t)
def p(t): return app('p',t)
def Q(t,u): return app('Q',t,u,body=w)
def I(g,t,u): return app('I',t,u,body=g)
def eq(t,u): return app('=',t,u)
def all_(t): return app('forall',t)
def count(t,full=False):
    return 1+sum(count(c,full) for c in t.args)+(count(t.body,True) if full and t.body is not None else 0)
def pp(t,full=False):
    return (t.op=='p')+sum(pp(c,full) for c in t.args)+(pp(t.body,True) if full and t.body is not None else 0)
def sub(t,name,val):
    if t.op=='var:'+name:return val
    return N(t.op,tuple(sub(c,name,val) for c in t.args),t.body)
def translate(t):
    args=tuple(translate(c) for c in t.args)
    if t.op=='p': return Q(args[0],z)
    return N(t.op,args,translate(t.body) if t.body is not None else None)
checks=0
def check(condition,message):
    global checks
    checks+=1
    if not condition:raise RuntimeError(message)
def sizes(ts):return [sum(count(t,k) for t in ts) for k in (False,True)]
p_core=[eq(p(z),z),all_(eq(p(S(x)),x))]
q_core=[all_(eq(Q(z,a),a)),all_(all_(eq(Q(S(n),a),n)))]
check(sizes(p_core)==[10,10],'p core')
check(sizes(q_core)==[14,16],'Q core')
# Finite staged syntax, including nested frozen iterator descriptions.
terms=[z,x,a,p(x),p(p(a)),S(p(x))]
bodies=[z,state,S(state),p(state),p(p(state)),app('chi',state,z)]
for round_ in range(3):
    earlier=terms[-40:]
    new=[]
    for idx,t in enumerate(earlier):
        new.extend([p(t),S(t),I(bodies[idx%len(bodies)],t,a)])
    terms.extend(new)
    bodies.extend([p(I(bodies[-1],state,z)),I(bodies[-2],p(state),state)])
expressions=terms+[all_(eq(t,p(t))) for t in terms]
for j,t in enumerate(expressions):
    old=translate(t)
    check(count(old)-count(t)==pp(t),f'active hereditary {j}')
    check(count(old,True)-count(t,True)==2*pp(t,True),f'full hereditary {j}')
# Formula and descriptor substitution remain separate.
for j,g in enumerate(bodies):
    base=all_(eq(I(g,z,a),a))
    step=all_(all_(eq(I(g,S(n),a),sub(g,'v',I(g,n,a)))))
    m=count(g); H=count(g,True)
    def occ(t):return (t.op=='var:v')+sum(occ(c) for c in t.args)
    k=occ(g)
    check(count(base)+count(step)==13+m+2*k,f'iterator active {j}')
    check(count(base,True)+count(step,True)==13+2*k+(3+k)*H,f'iterator full {j}')
flip=app('chi',state,z)
flipbase=all_(eq(I(flip,z,a),a))
flipstep=all_(all_(eq(I(flip,S(n),a),sub(flip,'v',I(flip,n,a)))))
check(sizes([flipbase])==[6,9],'flip base')
check(sizes([flipstep])==[12,18],'flip step')
# Primitive-standard-biconditional audit: exact once-P and expanded syntax.
b=v('b')
P=app('predicate',x,a)
def imp(t,u):return app('->',t,u)
def neg(t):return imp(t,app('false'))
left=app('or',P,eq(x,z)); right=eq(x,b)
guard=imp(imp(eq(x,S(b)),eq(b,n)),right)
bi=app('iff',left,right)
expanded=app('and',imp(left,right),imp(right,left))
def close(matrix):
    return all_(all_(app('exists',all_(matrix))))
once=close(imp(guard,bi))
once_expanded=close(imp(guard,expanded))
local=all_(all_(app('exists',app('and',neg(eq(b,S(b))),all_(imp(guard,bi))))))
check(count(guard)==12,'implication guard')
check(count(once)==count(P)+25,'once-P primitive')
check(count(once_expanded)==2*count(P)+34,'once-P expanded')
check(count(local)==count(P)+32,'once-P local no-fix')
raw=app('rawtail',x,a)
rawleft=imp(eq(raw,z),eq(x,z))
rawbi=app('iff',rawleft,right)
rawbiexp=app('and',imp(rawleft,right),imp(right,rawleft))
def localize(matrix):return all_(all_(app('exists',app('and',neg(eq(b,S(b))),all_(imp(guard,matrix))))))
check(count(localize(rawbi))==count(raw)+34,'once-raw primitive')
check(count(localize(rawbiexp))==2*count(raw)+45,'once-raw expanded')
bad=eq(z,S(z)); bottom=app('false')
crash=app('iff',bottom,bad)
crash_expanded=app('and',imp(bottom,bad),imp(bad,bottom))
check(count(crash)==6,'Crash primitive')
check(count(crash_expanded)==13,'Crash expanded')
check(count(imp(bottom,bad))+count(imp(bad,bottom))==12,'Crash split')
# Same-D fallback and once-raw shapes, with frozen Q/Z descriptors explicit.
def D(t,u):return app('D',t,u)
def Z(t,u):return app('Z',t,u,body=z)
def ex(t):return app('exists',t)
c=v('c'); d=v('d')
dtails=[D(x,a),D(x,D(x,a)),I(D(state,z),x,a),D(I(Q(state,z),x,a),x)]
for j,t in enumerate(dtails):
    m=count(t); T=count(t,True)
    def xocc(t):return (t.op=='var:x')+sum(xocc(c) for c in t.args)
    i=xocc(t)
    tb=sub(t,'x',D(b,b)); tc=sub(t,'x',c); td=sub(t,'x',d)
    outer=eq(Z(tc,c),z)
    direct=all_(all_(ex(ex(app('and',eq(c,Q(Z(tb,D(b,b)),n)),outer)))))
    shared=all_(all_(ex(ex(ex(app('and',eq(d,D(b,b)),app('and',eq(c,Q(Z(td,d),n)),outer)))))))
    unshifted=all_(all_(ex(ex(app('and',eq(c,Q(Z(sub(t,'x',b),b),n)),outer)))))
    DG=imp(imp(eq(x,D(b,b)),eq(b,n)),eq(x,b))
    DL=imp(eq(t,z),eq(x,z)); DR=eq(x,b)
    dot=all_(all_(ex(app('and',neg(eq(b,D(b,b))),all_(imp(DG,app('iff',DL,DR)))))))
    dot_exp=all_(all_(ex(app('and',neg(eq(b,D(b,b))),all_(imp(DG,app('and',imp(DL,DR),imp(DR,DL))))))))
    check(sizes([direct])==[2*m+2*i+17,2*T+2*i+20],f'D direct {j}')
    check(sizes([shared])==[2*m+22,2*T+25],f'D shared {j}')
    check(sizes([unshifted])==[2*m+15,2*T+18],f'D covered {j}')
    check(sizes([dot])==[m+36,T+36],f'D OT {j}')
    check(sizes([dot_exp])==[2*m+47,2*T+47],f'D OT expanded {j}')
    Dmatrix=app('or',eq(x,z),eq(Z(t,D(x,x)),D(x,D(b,b))))
    dzt_body=app('and',neg(eq(b,D(b,b))),all_(imp(DG,Dmatrix)))
    dzt=all_(all_(ex(dzt_body)))
    check(sizes([dzt])==[m+40,T+41],f'D old-basis one-copy {j}')
    direct_new=all_(all_(ex(app('and',eq(Z(sub(t,'x',b),b),z),app('or',eq(tb,z),eq(b,n))))))
    Dcond=app('If',eq(t,z),imp(eq(x,b),eq(b,z)),imp(eq(x,D(b,b)),eq(b,n)))
    Dcond_clause=all_(all_(ex(all_(Dcond))))
    condE=eq(t,z); condU=imp(eq(x,b),eq(b,z)); condV=imp(eq(x,D(b,b)),eq(b,n))
    Dcond_exp=app('or',app('and',condE,condU),app('and',neg(condE),condV))
    check(sizes([direct_new])==[2*m+2*i+14,2*T+2*i+15],f'current D direct {j}')
    check(sizes([Dcond_clause])==[m+23,T+23],f'D signed conditional {j}')
    check(sizes([all_(all_(ex(all_(Dcond_exp))))])==[2*m+29,2*T+29],f'D signed conditional expanded {j}')

Off=all_(all_(app('or',eq(x,a),eq(D(x,a),z))))
Nontriv=ex(neg(eq(x,z)))
DPart=all_(ex(neg(eq(D(x,z),D(x,D(a,a))))))
check(sizes([Off,Nontriv])==[17,17],'D17 seed')
check(sizes([Off,DPart])==[24,24],'D24 seed')
A=app('A'); U=app('U'); V=app('V')
Ifdef=app('definition',app('If',A,U,V),app('or',app('and',A,U),app('and',neg(A),V)))
check(count(Ifdef)==14,'strong If definition header')
Ifpositive=all_(all_(ex(all_(app('If',P,imp(eq(x,S(b)),eq(b,n)),imp(eq(x,b),eq(b,z)))))))
Ifnegative=all_(all_(ex(all_(app('If',P,imp(eq(x,b),eq(b,z)),imp(eq(x,S(b)),eq(b,n)))))))
check(count(Ifpositive)==count(P)+20,'current positive If')
check(count(Ifnegative)==count(P)+20,'new negative If')
for G in range(3,51):
    for i in range(1,G+1):
        phi=lambda F:min(2*F+i+12,F+20)
        for hereditary in range(8):
            check(phi(G+2*hereditary)-phi(G)>=2*hereditary,'conditional predecessor minimum')
for T in range(1,101):
    for i in range(T+1):
        current=min(2*T+2*i+15,2*T+22,T+34,T+25)
        new=min(2*T+2*i+15,T+23)
        check(new<=current,'signed D fair latest arithmetic envelope')
        check(current-new==max(0,min(T+2*i-8,2)),'signed D exact fair gain')
        covered_new=min(2*T+2*i+15,2*T+18,T+23)
        covered_old=min(2*T+2*i+15,2*T+18,T+25)
        check(covered_new<=covered_old,'covered D DB/U/CB envelope')

# Exhaustive small standard raw tails; values2 are intentionally non-Boolean.
raw_cases=0
for tail in product(range(3),repeat=6):
    for target in range(5):
        bval=0
        for counter in range(target):
            if tail[bval+1]!=0:bval+=1
        check((bval==0 or tail[bval]!=0) and (tail[bval+1]==0 or bval==target),'finite boundary invariant')
        valid=True
        dvalid=True
        for xv in range(7):
            inner=(xv!=bval+1 or bval==target)
            guarded=(not inner or xv==bval)
            if guarded:
                left=(tail[xv]!=0 or xv==0)
                valid=valid and (left==(xv==bval))
                dleft=(xv+1 if tail[xv]==0 else 0)
                dright=(xv+1 if xv==bval+1 else 0)
                dvalid=dvalid and (xv==0 or dleft==dright)
        check(bval!=bval+1 and valid,'finite OT raw witness')
        check(bval!=bval+1 and dvalid,'finite old-basis D raw witness')
        conditional_valid=all(((xv!=bval or bval==0) if tail[xv]==0 else (xv!=bval+1 or bval==target)) for xv in range(6))
        check(conditional_valid,'finite signed conditional raw witness')

        mask=lambda j: j if tail[j]==0 else 0
        innermask=mask(bval+1)
        selected=target if innermask==0 else innermask-1
        check(mask(selected)==0,'finite shared raw witness')
        raw_cases+=1


print(json.dumps({'status':'PASS','always_active_checks':checks,'expressions':len(expressions),'finite_raw_tail_cases':raw_cases,'primitive_p_core':sizes(p_core),'fixed_Q_core':sizes(q_core),'flip_base':sizes([flipbase]),'flip_step':sizes([flipstep]),'once_P_overhead':25,'once_P_expanded_overhead':34,'once_P_local_nofix_overhead':32,'once_raw_local_nofix_overhead':34,'once_raw_expanded_overhead':45,'Crash_primitive':6,'Crash_expanded':13,'Crash_split':12,'D17_seed':17,'D24_seed':24,'D_once_raw_overhead':36,'D_once_raw_expanded_overhead':47,'D_old_basis_once_raw_active_overhead':40,'D_old_basis_once_raw_full_overhead':41,'D_signed_If_raw_overhead':23,'D_signed_If_expanded_overhead':29,'strong_If_definition_header':14,'scope':'Finite syntax and standard-model diagnostics; not arbitrary-model proof certification.'},sort_keys=True,indent=2))
