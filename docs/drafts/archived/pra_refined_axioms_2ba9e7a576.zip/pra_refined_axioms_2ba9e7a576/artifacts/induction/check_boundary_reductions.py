#!/usr/bin/env python3
"""Authored round10 exact-AST and finite diagnostics. No supplied code imported.
All checks remain active under python -O. Finite truth tables are not proofs
about arbitrary models, nonstandard numbers, or the complete compiler.
"""
from dataclasses import dataclass
from itertools import product
import json

@dataclass(frozen=True)
class N:
    op: str
    args: tuple = ()
    desc: object = None

def V(s): return N('var:'+s)
def C(s): return N('const:'+s)
def A(s,*args,desc=None): return N('app:'+s,tuple(args),desc)
def E(a,b): return N('=',(a,b))
def B(op,a,b): return N(op,(a,b))
def All(v,b): return N('forall:'+v,(b,))
def Ex(v,b): return N('exists:'+v,(b,))
def Neg(p): return B('imp',p,N('bottom'))
def S(a): return A('S',a)
def Chi(a,b): return A('chi',a,b)
def p(a): return A('p',a)
def Q(a,b): return A('Q',a,b,desc=V('w'))
def Z(a,b): return A('Z',a,b,desc=C('0'))
def I(g,a,b): return A('I',a,b,desc=g)
def qs(spec,body):
    for kind,v in reversed(spec): body=(All if kind=='A' else Ex)(v,body)
    return body

def size(n,full=False):
    return 1+sum(size(q,full) for q in n.args)+(size(n.desc,True) if full and n.desc is not None else 0)
def occ(n,v):
    return int(n.op=='var:'+v)+sum(occ(q,v) for q in n.args)
def sub(n,v,t):
    if n.op=='var:'+v: return t
    # Stored description slots are frozen, and never substituted here.
    return N(n.op,tuple(sub(q,v,t) for q in n.args),n.desc)
def iff_expand(n):
    aa=tuple(iff_expand(a) for a in n.args)
    if n.op=='iff':
        x,y=aa
        return B('and',B('imp',x,y),B('imp',y,x))
    return N(n.op,aa,n.desc)

x,a,n,b,c,r,s,y=map(V,('x','a','n','b','c','r','s','y'))
z=C('0')
checks=0

def check(condition,message):
    global checks
    checks+=1
    if not condition: raise RuntimeError(message)

def nb(P):
    return qs([('A','a'),('A','n'),('E','b')],B('and',B('or',E(b,z),sub(P,'x',b)),B('imp',sub(P,'x',S(b)),E(b,n))))
def nbs(P):
    return qs([('A','a'),('A','n'),('E','b'),('E','c')],B('and',E(c,S(b)),B('and',B('or',E(b,z),sub(P,'x',b)),B('imp',sub(P,'x',c),E(b,n)))))
def H(): return B('imp',B('imp',E(x,S(b)),E(b,n)),E(x,b))
def ob(P):
    return qs([('A','a'),('A','n'),('E','b'),('A','x')],B('imp',H(),B('iff',B('or',P,E(x,z)),E(x,b))))
def ot(t,local=True):
    body=All('x',B('imp',H(),B('iff',B('imp',E(t,z),E(x,z)),E(x,b))))
    if local: body=B('and',Neg(E(b,S(b))),body)
    return qs([('A','a'),('A','n'),('E','b')],body)
def oe(t,local=True):
    matrix=B('or',E(x,z),E(Chi(t,z),Chi(x,S(b))))
    body=All('x',B('imp',H(),matrix))
    if local: body=B('and',Neg(E(b,S(b))),body)
    return qs([('A','a'),('A','n'),('E','b')],body)
def fb(t):
    return qs([('A','a'),('A','n'),('E','b')],E(Chi(b,Q(Z(sub(t,'x',S(b)),S(b)),n)),S(Z(sub(t,'x',b),b))))
def fbs(t):
    mat=E(Chi(b,Q(Z(sub(t,'x',c),c),n)),S(Z(sub(t,'x',b),b)))
    return qs([('A','a'),('A','n'),('E','b'),('E','c')],B('and',E(c,S(b)),mat))
def fbt(t):
    K=E(Chi(b,Q(Z(r,S(b)),n)),S(Z(s,b)))
    guard=B('or',B('and',E(x,b),E(y,s)),B('and',E(x,S(b)),E(y,r)))
    table=All('x',All('y',B('imp',guard,E(t,y))))
    return qs([('A','a'),('A','n'),('E','b'),('E','r'),('E','s')],B('and',K,table))

terms=[z,x,a,S(x),p(x),Chi(x,a),Q(x,a),Z(Chi(x,a),x)]
# Nested descriptions have their own frozen state slots. Substitution
# below independently verifies that such slots are never active arguments.
gs=[V('v'),S(V('v')),p(V('v')),Chi(V('v'),z),I(S(V('v')),V('v'),z)]
check(sub(I(V('v'),V('v'),a),'v',S(x))==I(V('v'),S(x),a),'frozen descriptor substitution')
for g in gs:
    terms += [I(g,x,a),I(g,S(x),Q(a,x)),Chi(I(g,x,a),p(x))]
terms += [A('binary',x,x),A('binary',A('binary',x,x),A('binary',x,x))]
formulas=[E(x,a),E(x,S(p(x))),N('bottom')]
for t in terms:
    formulas.extend([E(t,z),B('imp',E(t,a),E(S(x),a)),B('or',E(t,a),E(x,z))])
profiles=[]
for P in formulas:
    f,F,j=size(P),size(P,True),occ(P,'x')
    check(size(nb(P))==2*f+j+12,'NB active')
    check(size(nb(P),True)==2*F+j+12,'NB full')
    check(size(nbs(P),True)==2*F+18,'NB shared')
    check(size(ob(P))==f+25,'OB active')
    check(size(ob(P),True)==F+25,'OB full')
    check(size(iff_expand(ob(P)),True)==2*F+34,'OB expanded')
for t in terms:
    m,T,i=size(t),size(t,True),occ(t,'x')
    check(size(oe(t))==m+35,'ordinary E active')
    check(size(oe(t),True)==T+35,'ordinary E full')
    check(size(oe(t,False))==m+28 and size(oe(t,False),True)==T+28,'ordinary global NF')
    check(size(ot(t))==m+34,'OT active')
    check(size(ot(t),True)==T+34,'OT full')
    check(size(ot(t,False),True)==T+27,'OT amortized full')
    check(size(iff_expand(ot(t)),True)==2*T+45,'OT expanded')
    check(size(fb(t))==2*m+i+14,'FB active')
    check(size(fb(t),True)==2*T+i+17,'FB full')
    check(size(fbs(t))==2*m+19,'FB shared active')
    check(size(fbs(t),True)==2*T+22,'FB shared full')
    check(size(fbt(t))==m+40,'FB table active')
    check(size(fbt(t),True)==T+43,'FB table full')
    for g in gs:
        P=E(I(g,x,a),t)
        G=size(g,True)
        check(size(nb(P))==2*m+i+21,'AB active')
        check(size(nb(P),True)==2*T+2*G+i+21,'AB full')
    profiles.append({'m':m,'T':T,'i':i,'old_min':min(2*T+i+17,2*T+22,T+43),'new_min':min(2*T+i+17,2*T+22,T+35),'optional_iff_min':min(2*T+i+17,2*T+22,T+34)})

nf=All('x',Neg(E(S(x),x)))
de=All('x',All('a',B('or',E(x,a),Neg(E(x,a)))))
check(size(nf)==7,'NoFix7')
check(size(de)==11,'DecEq11')
check(size(Neg(E(z,S(z))))==6,'Sep6')
check(size(E(p(z),z))==4,'p0=0 size4')
check(size(All('x',E(p(S(x)),x)))==6,'pSx=x size6')
check(size(All('a',E(Q(z,a),a)))==6,'Q base active6')
check(size(All('a',E(Q(z,a),a)),True)==7,'Q base full7')
check(size(qs([('A','a'),('A','x')],E(Q(S(x),a),x)))==8,'Q step active8')
check(size(qs([('A','a'),('A','x')],E(Q(S(x),a),x)),True)==9,'Q step full9')
g=Chi(V('v'),z)
flipstep=qs([('A','a'),('A','x')],E(I(g,S(x),a),Chi(I(g,x,a),z)))
check(size(flipstep)==12 and size(flipstep,True)==18,'flip step12/18')
check((size(nb(E(I(S(V('v')),x,a),x))),size(nb(E(I(S(V('v')),x,a),x)),True))==(24,28),'calibration24/28')
check((size(nb(E(I(S(V('v')),x,a),S(p(x))))),size(nb(E(I(S(V('v')),x,a),S(p(x)))),True))==(28,32),'coverage28/32')

check((size(fb(a)),size(fb(a),True))==(16,19),'minimal-seed normalization16/19')
check(size(fb(a),True)<min(size(fbs(a),True),size(oe(a),True)), 'scheduler preserves normalization')
# Exhaustive numerical envelope check, not a generator-minimality proof.
for T in range(1,161):
    for i in range(T+1):
        old=min(2*T+i+17,2*T+22,T+43)
        new=min(2*T+i+17,2*T+22,T+35)
        check(new<=old,'ordinary envelope monotonic')
        check((new<old)==(T>13 and T+i>18),'ordinary strict region')
        if T>=21 and T+i>=26: check(old-new==8,'ordinary old-table saving8')
        optional=min(2*T+i+17,2*T+22,T+34)
        check(optional<=new,'optional iff envelope')
        check((optional<old)==(T>12 and T+i>17),'optional strict region')

# Boolean prefix scans and finite guard/OB checks, on standard integer samples.
def imp(A,B): return (not A) or B
def guard(x,b,n): return imp(imp(x==b+1,b==n),x==b)
def boundary(P,n):
    b=0
    for k in range(n):
        if P[b+1]: b+=1
    return b
boolean_cases=0
for vals in product((False,True),repeat=7):
    for target in range(6):
        chosen=boundary(vals,target)
        check((chosen==0 or vals[chosen]) and imp(vals[chosen+1],chosen==target),'native scan')
        for xx in range(7):
            rhs=((vals[xx] or xx==0)==(xx==chosen))
            check(imp(guard(xx,chosen,target),rhs),'OB finite witness')
            boolean_cases+=1
raw_cases=0
for vals in product(range(3),repeat=6):
    pred=tuple(v!=0 for v in vals)
    for target in range(5):
        chosen=boundary(pred,target)
        check(chosen!=chosen+1,'local NoFix')
        for xx in range(6):
            left=imp(vals[xx]==0,xx==0)
            check(left==(pred[xx] or xx==0),'raw implication compression')
            check(imp(guard(xx,chosen,target),left==(xx==chosen)),'OT finite witness')
            ordinary=(xx==0 or int(vals[xx]==0)==int(xx==chosen+1))
            check(imp(guard(xx,chosen,target),ordinary),'ordinary E finite witness')
            raw_cases+=1
for xx,bb,nn in product(range(9),repeat=3):
    check(guard(xx,bb,nn)==(xx==bb or (xx==bb+1 and bb!=nn)),'implication guard equivalence')

print(json.dumps({'status':'PASS','checks':checks,'predicate_examples':len(formulas),'tail_examples':len(terms),
 'boolean_prefix_point_cases':boolean_cases,'raw_tail_point_cases':raw_cases,
 'profiles':{'NB':'2F+j+12','NB_shared':'2F+18','OB_primitive_iff':'F+25','OB_expanded':'2F+34',
             'ordinary_E_original_basis':'T+35','ordinary_E_global_NoFix_seed25':'T+28','OT_local_primitive_iff':'T+34','OT_local_expanded':'2T+45','OT_global_NoFix_seed25':'T+27 with seed25 instead of24',
             'old_fused_envelope':'min(2T+i+17,2T+22,T+43)','new_envelope':'min(2T+i+17,2T+22,T+35)','optional_iff_envelope':'min(2T+i+17,2T+22,T+34)',
             'anchor_AB_active':'2m+k+21','anchor_AB_full':'2T+2V+k+21','fixed_p_basis':16,
             'coverage_support_active_full':[[24,28],[28,32]],'NoFix':7,'DecEq':11},
 'sample_payload_profiles':profiles,
 'scope':'Exact authored AST counts and finite standard-prefix diagnostics; not an arbitrary-model proof, proof-assistant certificate, or absolute-minimum claim.'},indent=2,sort_keys=True))
