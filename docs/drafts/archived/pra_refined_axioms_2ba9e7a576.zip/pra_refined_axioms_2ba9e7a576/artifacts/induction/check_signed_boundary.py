#!/usr/bin/env python3
"""Authored exact syntax and finite diagnostics for signed conditional synthesis.
No supplied programs are imported. Explicit checks remain active under -O.
Finite arithmetic/Boolean/Kripke tests are not the full interpretation proof.
"""
from dataclasses import dataclass
from itertools import product
import json

@dataclass(frozen=True)
class N:
    op: str
    args: tuple=()
    desc: object=None

def v(s): return N('v:'+s)
def zero(): return N('0')
def ap(s,*args,desc=None): return N(s,tuple(args),desc)
def eq(a,b): return ap('=',a,b)
def imp(a,b): return ap('->',a,b)
def neg(a): return imp(a,N('bottom'))
def conj(a,b): return ap('&',a,b)
def disj(a,b): return ap('|',a,b)
def iff(a,b): return conj(imp(a,b),imp(b,a))
def S(a): return ap('S',a)
def Z(a,b): return ap('Z',a,b,desc=zero())
def Q(a,b): return ap('Q',a,b,desc=v('w'))
def chi(a,b): return ap('chi',a,b)
def If(a,b,c): return ap('If',a,b,c)
def bind(q,name,body): return ap(q+name,body)
def prefix(spec,body):
    for q,name in reversed(spec): body=bind(q,name,body)
    return body

def size(a,full=False):
    return 1+sum(size(c,full) for c in a.args)+(size(a.desc,True) if full and a.desc is not None else 0)
def occ(a,name): return int(a.op=='v:'+name)+sum(occ(c,name) for c in a.args)
def sub(a,name,t):
    if a.op=='v:'+name: return t
    return N(a.op,tuple(sub(c,name,t) for c in a.args),a.desc)
def expand_if(a):
    aa=tuple(expand_if(c) for c in a.args)
    if a.op=='If':
        e,u,w=aa
        return disj(conj(e,u),conj(neg(e),w))
    return N(a.op,aa,a.desc)
def strip_one(P):
    return ('-',P.args[0]) if P.op=='->' and P.args[1].op=='bottom' else ('+',P)
def strip_all(P):
    r=0
    while P.op=='->' and P.args[1].op=='bottom':
        P=P.args[0];r+=1
    return r,('-' if r%2 else '+'),P

x,a,n,b,c=map(v,('x','a','n','b','c'));z=zero()
checks=0

def ck(ok,why):
    global checks
    checks+=1
    if not ok: raise RuntimeError(why)

def direct(E,sign):
    eb,es=sub(E,'x',b),sub(E,'x',S(b))
    body=conj(disj(eq(b,z),eb),imp(es,eq(b,n))) if sign=='+' else conj(imp(eb,eq(b,z)),disj(eq(b,n),es))
    return prefix([('A','a'),('A','n'),('E','b')],body)
def conditional(E,sign):
    u,w=imp(eq(x,S(b)),eq(b,n)),imp(eq(x,b),eq(b,z))
    if sign=='-': u,w=w,u
    return prefix([('A','a'),('A','n'),('E','b'),('A','x')],If(E,u,w))
def db(t):
    return prefix([('A','a'),('A','n'),('E','b')],conj(eq(Z(sub(t,'x',b),b),z),disj(eq(sub(t,'x',S(b)),z),eq(b,n))))
def booldb(t):
    return prefix([('A','a'),('A','n'),('E','b')],eq(Q(sub(t,'x',S(b)),sub(t,'x',b)),Q(sub(t,'x',n),sub(t,'x',z))))

terms=[z,x,a,S(x),ap('p',x),chi(x,a),Q(x,a),Z(x,a),chi(S(x),a)]
for g in [v('v'),S(v('v')),ap('p',v('v')),ap('I',v('v'),z,desc=S(v('v')))]:
    terms.extend([ap('I',x,a,desc=g),ap('I',S(x),Q(a,x),desc=g)])
terms.extend([ap('f',x,x),ap('f',ap('f',x,x),ap('f',x,x))])
formulas=[N('bottom'),eq(x,a)]
for t in terms: formulas.extend([eq(t,z),imp(eq(t,a),eq(x,z)),disj(eq(t,a),eq(S(x),a))])
for E in formulas:
    e,F,i=size(E),size(E,True),occ(E,'x')
    for sign in ('+','-'):
        ck(size(direct(E,sign))==2*e+i+12,'direct active')
        ck(size(direct(E,sign),True)==2*F+i+12,'direct full')
        ck(size(conditional(E,sign))==e+20,'conditional active')
        ck(size(conditional(E,sign),True)==F+20,'conditional full')
        ck(size(expand_if(conditional(E,sign)),True)==2*F+24,'expanded conditional')
    ck(strip_one(neg(E))==('-',E),'one literal negation')
    for r in range(7):
        P=E
        for j in range(r): P=neg(P)
        # E may itself start with negation; compare reconstruction instead.
        k,sign,A=strip_all(P)
        rebuilt=A
        for j in range(k): rebuilt=neg(rebuilt)
        ck(rebuilt==P,'all-prefix syntactic roundtrip')
        ck(sign==('-' if k%2 else '+'),'prefix parity')
for t in terms:
    m,T,i=size(t),size(t,True),occ(t,'x')
    ck(size(db(t))==2*m+i+14,'DB active')
    ck(size(db(t),True)==2*T+i+15,'DB full')
    ck(size(conditional(eq(t,z),'-'),True)==T+22,'raw signed If')
    ck(size(booldb(t),True)==4*T+i+8,'retained Boolean DB full')
    ck(size(booldb(t))==4*m+i+6,'retained Boolean DB active')
ck(size(If(v('A'),v('U'),v('V')))+size(expand_if(If(v('A'),v('U'),v('V'))))+1==14,'fixed If rewrite14')
ck(sub(ap('I',v('v'),a,desc=v('v')),'v',S(x))==ap('I',S(x),a,desc=v('v')),'frozen descriptor')

# All applicable unrestricted-raw prices, even granting the old side free
# coverage. Bracketed Boolean candidates are retained in a priced chi core.
for T in range(1,121):
    for i in range(1,(T+1)//2+1):
        old=min(2*T+i+15,2*T+21,T+24,T+28,T+29,T+32,2*T+i+16,2*T+22,2*T+18)
        ck(old==min(2*T+i+15,T+24),'latest unrestricted raw envelope')
        new=min(2*T+i+15,T+22)
        ck(new<=old,'new raw no worse')
        ck(old-new==min(2,max(0,T+i-7)),'exact raw gain')
        old_bool=min(old,4*T+i+8,T+25)
        new_bool=min(new,4*T+i+8)
        ck(new_bool<=old_bool,'retained Boolean envelope no worse')
        if T>=4: ck(2*T+i+15<=4*T+i+8,'Boolean domination for T>=4')
# Explicit exception that must never be silently removed.
ck(4*3+1+8==21 and min(2*3+1+15,3+22)==22,'three-node Boolean exception')

# Arbitrary finite-carrier Boolean kernels; no arithmetic axioms are assumed.
def Im(A,B): return (not A) or B
def Ifv(A,U,V): return (A and U) or ((not A) and V)
carrier_cases=0
for d in range(1,4):
    for succ in product(range(d),repeat=d):
        for E in product((False,True),repeat=d):
            for sign in ('+','-'):
                P=E if sign=='+' else tuple(not q for q in E)
                for nn,bb in product(range(d),repeat=2):
                    direct_h=((bb==0 or E[bb]) and Im(E[succ[bb]],bb==nn)) if sign=='+' else (Im(E[bb],bb==0) and (bb==nn or E[succ[bb]]))
                    cond_h=all(Ifv(E[xx],Im(xx==succ[bb],bb==nn),Im(xx==bb,bb==0)) if sign=='+' else Ifv(E[xx],Im(xx==bb,bb==0),Im(xx==succ[bb],bb==nn)) for xx in range(d))
                    if P[0] and all(Im(P[k],P[succ[k]]) for k in range(d)):
                        ck(not direct_h or P[nn],'direct arbitrary-carrier kernel')
                        ck(not cond_h or P[nn],'conditional arbitrary-carrier kernel')
                    carrier_cases+=1

# Standard-prefix explicit reverse witness, for both signs and raw tails.
def boundary(P,n):
    bb=0
    for k in range(n):
        if P[bb+1]: bb+=1
    return bb
reverse_cases=0
for E in product((False,True),repeat=7):
    for sign in ('+','-'):
        P=E if sign=='+' else tuple(not q for q in E)
        for nn in range(6):
            bb=boundary(P,nn)
            ck((bb==0 or P[bb]) and Im(P[bb+1],bb==nn),'scan invariant')
            for xx in range(7):
                val=Ifv(E[xx],Im(xx==bb+1,bb==nn),Im(xx==bb,bb==0)) if sign=='+' else Ifv(E[xx],Im(xx==bb,bb==0),Im(xx==bb+1,bb==nn))
                ck(val,'signed conditional reverse')
                reverse_cases+=1
raw_cases=0
for t in product(range(3),repeat=6):
    P=tuple(q!=0 for q in t)
    for nn in range(5):
        bb=boundary(P,nn)
        zz=bb if t[bb]==0 else 0
        ck(zz==0 and (t[bb+1]==0 or bb==nn),'raw DB reverse')
        raw_cases+=1

# The critical double-negative kernel is also tested in finite intuitionistic
# Kripke frames with every upward-closed atom assignment. Written proof is
# the general justification; these checks are diagnostics, not completeness.
ab,ass,an,ee=[N('atom:'+q) for q in ('Ab','As','An','Eq')]
prem=conj(conj(neg(neg(ab)),neg(neg(ass))),conj(imp(ass,ee),imp(ee,imp(ab,an))))
kernel=imp(prem,neg(neg(an)))
triple=iff(neg(neg(neg(ab))),neg(ab))
frames=[[(0,1,2),(1,2),(2,)],[(0,1,2),(1,),(2,)],[(0,1,2,3),(1,3),(2,3),(3,)]]
kripke_cases=0
for up in frames:
    d=len(up)
    sets=[bits for bits in product((False,True),repeat=d) if all(not bits[w] or all(bits[z] for z in up[w]) for w in range(d))]
    for assign in product(sets,repeat=4):
        val=dict(zip(('atom:Ab','atom:As','atom:An','atom:Eq'),assign))
        def forces(f,w):
            if f.op.startswith('atom:'): return val[f.op][w]
            if f.op=='bottom': return False
            if f.op=='&': return forces(f.args[0],w) and forces(f.args[1],w)
            if f.op=='|': return forces(f.args[0],w) or forces(f.args[1],w)
            if f.op=='->': return all(not forces(f.args[0],z) or forces(f.args[1],z) for z in up[w])
            raise RuntimeError('unsupported Kripke operator')
        for w in range(d):
            ck(forces(kernel,w),'double-negative transport Kripke diagnostic')
            ck(forces(triple,w),'triple-negation collapse Kripke diagnostic')
            kripke_cases+=1

print(json.dumps({'status':'PASS','checks':checks,'predicate_ast_examples':len(formulas),'tail_ast_examples':len(terms),
 'arbitrary_carrier_boolean_cases':carrier_cases,'standard_reverse_point_cases':reverse_cases,'raw_DB_reverse_cases':raw_cases,'finite_Kripke_world_cases':kripke_cases,
 'profiles':{'signed_direct':'2F+i+12','signed_conditional':'F+20','expanded_conditional':'2F+24','DB_active':'2m+i+14','DB_full':'2T+i+15','raw_signed_If':'T+22','latest_unrestricted_raw':'min(2T+i+15,T+24)','new_unrestricted_raw':'min(2T+i+15,T+22)','optional_Boolean_companion':'retain bracketed4T+i+8 at pricedchi24 seed','logical_definition_fixed':14},
 'scope':'Exact authored syntax counts and finite Boolean/Kripke diagnostics only; general constructive kernels and full arithmetic bi-interpretations are the separately audited written proofs.'},indent=2,sort_keys=True))
