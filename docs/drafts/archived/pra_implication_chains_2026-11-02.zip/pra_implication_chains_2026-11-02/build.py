#!/usr/bin/env python3
"""Reproduce checks and the PDF. Requires Python 3.10+ and pdflatex."""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path


def run_checked(command: list[str], log: Path, root: Path) -> None:
    completed = subprocess.run(
        command, cwd=root, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, text=True, check=False,
    )
    log.write_text(completed.stdout, encoding="utf-8")
    if completed.returncode:
        print(completed.stdout[-8000:], file=sys.stderr)
        raise RuntimeError(f"Command failed with code {completed.returncode}: {command[0]}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf-only", action="store_true")
    parser.add_argument("--checks-only", action="store_true")
    options = parser.parse_args()
    if options.pdf_only and options.checks_only:
        parser.error("Choose at most one restriction.")
    root = Path(__file__).resolve().parent
    work = root / "_build"
    verification = root / "verification"
    work.mkdir(exist_ok=True)
    verification.mkdir(exist_ok=True)
    checks = ("verify_sizes", "check_logic_scan")
    if not options.pdf_only:
        for name in checks:
            command = [sys.executable, str(root / "code" / f"{name}.py"),
                       "--output", str(verification / f"{name}_results.json")]
            run_checked(command, work / f"{name}.log", root)
            print(f"PASS: {name}")
    if not options.checks_only:
        compiler = shutil.which("pdflatex")
        if compiler is None:
            raise RuntimeError("pdflatex is required to compile the supplied LaTeX.")
        command = [compiler, "-no-shell-escape", "-interaction=nonstopmode",
                   "-halt-on-error", "-file-line-error", "-output-directory=_build",
                   "report.tex"]
        stable = False
        for number in range(1, 5):
            run_checked(command, work / f"pdflatex_pass_{number}.txt", root)
            log = (work / "report.log").read_text(encoding="utf-8", errors="replace")
            unresolved = "There were undefined references" in log
            changed = "Label(s) may have changed" in log
            if number >= 2 and not unresolved and not changed:
                stable = True
                break
        if not stable:
            raise RuntimeError("References did not stabilize within four LaTeX passes.")
        shutil.copy2(work / "report.pdf", root / "report.pdf")
        print(f"PASS: PDF compiled in {number} passes without shell escape; references stable")
    summary = {"status": "PASS", "checks_rerun": not options.pdf_only,
               "pdf_rebuilt": not options.checks_only, "python": sys.version.split()[0]}
    (verification / "build_result.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
