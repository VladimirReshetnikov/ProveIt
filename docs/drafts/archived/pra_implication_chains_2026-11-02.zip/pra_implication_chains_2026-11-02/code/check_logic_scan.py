#!/usr/bin/env python3
"""Finite diagnostics for the implication-chain connective and backward scan.

These exhaustive finite checks are not a proof-assistant certificate and do
not replace the written proofs for arbitrary formulas, models, or numbers.
The program uses only the Python standard library and has no assert statements.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path


class VerificationError(RuntimeError):
    """A claimed finite property failed."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def formula_size(expression: str | tuple) -> int:
    if isinstance(expression, str):
        return 1
    return 1 + sum(formula_size(child) for child in expression[1:])


def render(expression: str | tuple) -> str:
    if isinstance(expression, str):
        return expression
    symbols = {"and": "&", "or": "|", "implies": "->"}
    operator, left, right = expression
    return f"({render(left)} {symbols[operator]} {render(right)})"


def boolean_minimum() -> dict:
    """Semantic dynamic programming covers every formula tree through size 7."""
    assignments = list(itertools.product((False, True), repeat=3))
    full_mask = (1 << len(assignments)) - 1
    names = ("A", "B", "D")
    atom_masks = {
        name: sum(int(values[index]) << row for row, values in enumerate(assignments))
        for index, name in enumerate(names)
    }
    atom_masks["false"] = 0
    target = sum(
        int(((not a) or b) and ((not b) or d)) << row
        for row, (a, b, d) in enumerate(assignments)
    )
    exact: dict[int, dict[int, str | tuple]] = {
        1: {mask: name for name, mask in atom_masks.items()}
    }
    minimum = {mask: 1 for mask in exact[1]}
    syntactic_counts = {1: len(atom_masks)}
    row_metadata = []
    operation_evaluations = 0

    for size in (1, 3, 5, 7):
        if size > 1:
            level: dict[int, str | tuple] = {}
            syntax_count = 0
            for left_size in range(1, size - 1, 2):
                right_size = size - 1 - left_size
                syntax_count += (
                    3 * syntactic_counts[left_size] * syntactic_counts[right_size]
                )
                for left_mask, left_expression in exact[left_size].items():
                    for right_mask, right_expression in exact[right_size].items():
                        values = {
                            "and": left_mask & right_mask,
                            "or": left_mask | right_mask,
                            "implies": ((~left_mask) | right_mask) & full_mask,
                        }
                        operation_evaluations += len(values)
                        for operator, mask in values.items():
                            level.setdefault(
                                mask, (operator, left_expression, right_expression)
                            )
            exact[size] = level
            syntactic_counts[size] = syntax_count
        newly_seen = 0
        for mask, expression in exact[size].items():
            require(formula_size(expression) == size, "DP witness has wrong size")
            if mask not in minimum:
                minimum[mask] = size
                newly_seen += 1
        if size == 1:
            newly_seen = len(exact[1])
        row_metadata.append(
            {
                "nodes": size,
                "distinct_truth_functions_at_exact_size": len(exact[size]),
                "new_minimal_truth_functions": newly_seen,
                "syntactic_formula_trees_represented": syntactic_counts[size],
                "target_representable": target in exact[size],
            }
        )

    require(minimum.get(target) == 7, "The chain's Boolean minimum is not seven")
    require(target not in exact[1], "Target unexpectedly has a one-node formula")
    require(target not in exact[3], "Target unexpectedly has a three-node formula")
    require(target not in exact[5], "Target unexpectedly has a five-node formula")
    require(target in exact[7], "Target has no seven-node DP witness")
    return {
        "status": "passed",
        "grammar": {
            "atoms": list(atom_masks),
            "binary_connectives": ["and", "or", "implies"],
            "node_charge": "one per leaf and one per binary connective",
            "maximum_nodes": 7,
            "even_sizes": "impossible for binary trees with atomic leaves",
        },
        "target": "(A -> B) & (B -> D)",
        "target_truth_mask": target,
        "valuation_order": [dict(zip(names, values)) for values in assignments],
        "minimum_nodes": minimum[target],
        "minimal_witness": render(exact[7][target]),
        "dynamic_program_rows": row_metadata,
        "boolean_operation_evaluations": operation_evaluations,
        "all_syntactic_formula_trees_through_seven": sum(syntactic_counts.values()),
        "distinct_truth_functions_seen": len(minimum),
        "scope": "Exact Boolean tree minimum in the displayed finite grammar only.",
    }


def rooted_posets(world_count: int):
    """Enumerate all labeled partial orders with world 0 a least element."""
    optional_pairs = [
        (left, right)
        for left in range(1, world_count)
        for right in range(1, world_count)
        if left != right
    ]
    for relation_code in range(1 << len(optional_pairs)):
        future = [(1 << world) for world in range(world_count)]
        future[0] = (1 << world_count) - 1
        for bit, (left, right) in enumerate(optional_pairs):
            if relation_code & (1 << bit):
                future[left] |= 1 << right
        antisymmetric = all(
            not ((future[left] >> right) & 1 and (future[right] >> left) & 1)
            for left in range(world_count)
            for right in range(left + 1, world_count)
        )
        if not antisymmetric:
            continue
        transitive = all(
            not (future[left] & (1 << middle))
            or (future[middle] & ~future[left]) == 0
            for left in range(world_count)
            for middle in range(world_count)
        )
        if transitive:
            yield tuple(future)


def upward_closed_sets(future: tuple[int, ...]) -> list[int]:
    return [
        valuation
        for valuation in range(1 << len(future))
        if all(
            not (valuation & (1 << world)) or (future[world] & ~valuation) == 0
            for world in range(len(future))
        )
    ]


def kripke_implies(left: int, right: int, future: tuple[int, ...]) -> int:
    return sum(
        int((successors & left & ~right) == 0) << world
        for world, successors in enumerate(future)
    )


def kripke_formula(expression: str | tuple, values: dict, future: tuple) -> int:
    if isinstance(expression, str):
        return values[expression] if expression != "false" else 0
    operator, left_expression, right_expression = expression
    left = kripke_formula(left_expression, values, future)
    right = kripke_formula(right_expression, values, future)
    if operator == "and":
        return left & right
    if operator == "or":
        return left | right
    if operator == "implies":
        return kripke_implies(left, right, future)
    raise VerificationError(f"Unknown formula operator: {operator}")


def primitive_chain(a: int, b: int, d: int, future: tuple[int, ...]) -> int:
    """An independent direct forcing implementation of the chain rules."""
    result = 0
    for world in range(len(future)):
        valid = True
        for extension in range(len(future)):
            if not (future[world] & (1 << extension)):
                continue
            a_holds = bool(a & (1 << extension))
            b_holds = bool(b & (1 << extension))
            d_holds = bool(d & (1 << extension))
            if (a_holds and not b_holds) or (b_holds and not d_holds):
                valid = False
                break
        if valid:
            result |= 1 << world
    return result


def kripke_checks() -> dict:
    definition = ("and", ("implies", "A", "B"), ("implies", "B", "D"))
    totals = {
        "frames": 0,
        "atomic_valuation_triples": 0,
        "worldwise_definition_checks": 0,
        "worldwise_elimination_checks": 0,
        "context_valuation_quadruples": 0,
        "applicable_contextual_introductions": 0,
        "applicable_contextual_first_eliminations": 0,
        "applicable_contextual_second_eliminations": 0,
    }
    rows = []
    for world_count in range(1, 5):
        frame_count = 0
        triple_count = 0
        context_count = 0
        for future in rooted_posets(world_count):
            frame_count += 1
            upsets = upward_closed_sets(future)
            for a, b, d in itertools.product(upsets, repeat=3):
                triple_count += 1
                values = {"A": a, "B": b, "D": d}
                expanded = kripke_formula(definition, values, future)
                primitive = primitive_chain(a, b, d, future)
                require(primitive == expanded, "Kripke definition mismatch")
                require(primitive in upsets, "Primitive chain forcing is not persistent")
                require((primitive & a & ~b) == 0, "First C elimination failed")
                require((primitive & b & ~d) == 0, "Second C elimination failed")
                introductions = kripke_implies(a, b, future) & kripke_implies(
                    b, d, future
                )
                require((introductions & ~primitive) == 0, "Local C introduction failed")
                totals["worldwise_definition_checks"] += world_count
                totals["worldwise_elimination_checks"] += 2 * world_count

                for context in upsets:
                    context_count += 1
                    # Contextual introduction discharges A and B separately.
                    # Persistent Gamma is represented by the upset 'context'.
                    if (context & a & ~b) == 0 and (context & b & ~d) == 0:
                        totals["applicable_contextual_introductions"] += 1
                        require(
                            (context & ~primitive) == 0,
                            "Contextual C introduction failed",
                        )
                    if (context & ~primitive) == 0 and (context & ~a) == 0:
                        totals["applicable_contextual_first_eliminations"] += 1
                        require((context & ~b) == 0, "Contextual first elimination failed")
                    if (context & ~primitive) == 0 and (context & ~b) == 0:
                        totals["applicable_contextual_second_eliminations"] += 1
                        require((context & ~d) == 0, "Contextual second elimination failed")
            rows.append(
                {
                    "worlds": world_count,
                    "frame_number_at_size": frame_count,
                    "future_masks": list(future),
                    "upward_closed_valuations_per_atom": len(upsets),
                }
            )
        totals["frames"] += frame_count
        totals["atomic_valuation_triples"] += triple_count
        totals["context_valuation_quadruples"] += context_count
        expected_count = {1: 1, 2: 1, 3: 3, 4: 19}[world_count]
        require(frame_count == expected_count, "Rooted-poset enumeration count mismatch")

    return {
        "status": "passed",
        "maximum_worlds": 4,
        "frame_class": (
            "Every labeled finite partial order on {0,...,n-1}, n<=4, "
            "with 0 a least element; isomorphic labeled copies are retained."
        ),
        "valuation_class": "Every upward-closed truth set for each of A,B,D and Gamma.",
        "checks": [
            "Direct primitive forcing equals expanded (A -> B) & (B -> D).",
            "Primitive forcing is upward closed.",
            "C,A entails B and C,B entails D at every world.",
            "Contextual introduction and both contextual elimination rules.",
        ],
        "counts": totals,
        "frames": rows,
        "scope": "Exhaustive finite Kripke diagnostics, not an arbitrary-model proof.",
    }


def backward_scan_checks(maximum_trace_length: int = 12) -> dict:
    trace_count = 0
    target_count = 0
    scan_step_count = 0
    table_entry_count = 0
    rows = []
    for length in range(1, maximum_trace_length + 1):
        local_traces = 0
        local_targets = 0
        local_entries = 0
        for predicate in itertools.product((False, True), repeat=length):
            local_traces += 1
            witness = 0
            for target in range(length):
                local_targets += 1
                require(0 <= witness <= target, "Scan witness escaped the prefix")
                invariant_left = witness == 0 or predicate[witness - 1]
                invariant_right = not predicate[witness] or witness == target
                require(invariant_left and invariant_right, "Scan invariant failed")
                first_false = next(
                    (index for index in range(target + 1) if not predicate[index]),
                    target,
                )
                require(witness == first_false, "Scan disagrees with first-failure oracle")

                for probe in range(length):
                    local_entries += 1
                    antecedent = probe + 1 == witness
                    middle = predicate[probe]
                    consequent = probe != witness or witness == target
                    chain = (not antecedent or middle) and (not middle or consequent)
                    require(chain, "Backward boundary table failed")

                if target + 1 < length:
                    scan_step_count += 1
                    if predicate[witness]:
                        witness = target + 1

        require(local_traces == 1 << length, "Boolean trace enumeration count mismatch")
        require(local_targets == length * (1 << length), "Target count mismatch")
        require(local_entries == length * length * (1 << length), "Table count mismatch")
        trace_count += local_traces
        target_count += local_targets
        table_entry_count += local_entries
        rows.append(
            {
                "trace_length": length,
                "traces": local_traces,
                "target_invariants_and_oracle_checks": local_targets,
                "boundary_table_entries": local_entries,
            }
        )

    return {
        "status": "passed",
        "maximum_trace_length": maximum_trace_length,
        "length_convention": "A length-L trace records P(0),...,P(L-1).",
        "scan": "c(0)=0; c(k+1)=k+1 if P(c(k)), otherwise c(k).",
        "invariant": "(c(k)=0 or P(c(k)-1)) and (P(c(k)) -> c(k)=k)",
        "boundary": "C(x+1=c(k), P(x), x=c(k) -> c(k)=k)",
        "oracle": "c(k) is the first false index through k, or k if none exists.",
        "outside_probe_range": (
            "For x>=L and c(k)<=k<L, both endpoint equalities are false, "
            "so the boundary holds for either truth value of P(x)."
        ),
        "counts": {
            "all_boolean_traces": trace_count,
            "target_invariants_checked": target_count,
            "independent_first_failure_oracle_checks": target_count,
            "scan_transitions_checked": scan_step_count,
            "boundary_table_entries_checked": table_entry_count,
        },
        "rows": rows,
        "scope": "Finite natural-number traces only; the report supplies the general proof.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_name("check_logic_scan_results.json"),
    )
    options = parser.parse_args()
    source_bytes = Path(__file__).read_bytes()
    result = {
        "status": "passed",
        "verification_kind": "Fresh standard-library finite diagnostics",
        "limitations": [
            "Not a proof-assistant certificate.",
            "Not a substitute for the written arbitrary-model and unbounded proofs.",
            "No claim of an absolute shortest axiomatization of PRA.",
        ],
        "script_sha256": hashlib.sha256(source_bytes).hexdigest(),
        "boolean_minimum": boolean_minimum(),
        "kripke_semantics": kripke_checks(),
        "backward_scan": backward_scan_checks(),
    }
    options.output.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(result, indent=2, sort_keys=True, ensure_ascii=True) + "\n"
    options.output.write_text(serialized, encoding="utf-8")
    print(
        json.dumps(
            {
                "status": result["status"],
                "output": str(options.output.resolve()),
                "boolean_minimum_nodes": result["boolean_minimum"]["minimum_nodes"],
                "kripke_counts": result["kripke_semantics"]["counts"],
                "scan_counts": result["backward_scan"]["counts"],
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
