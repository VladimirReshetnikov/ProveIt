#!/usr/bin/env python3
"""Reproducible full-AST checks for PRA from implication-chain boundaries.

No code is imported from the reviewed drafts. Every occurrence of a generated
recursor carries its entire frozen descriptor. Substitution changes active
arguments only. These finite checks verify syntax counts and finite local
semantics; they are not a proof of the arithmetic interpretation theorem.
"""

from __future__ import annotations

SOURCE_REPOSITORY = "VladimirReshetnikov/ProveIt"
SOURCE_REF = "5f9cb0b20a6a83a11917c56efec53714ea85df6f"
BASELINE_SOURCES = {
    "ordinary_atomic_A": {
        "path": "docs/drafts/archived/pra_atomic_boundary_2026-11-02.zip",
        "member": "pra_atomic_boundary_2026-11-02/sections/comparison.tex",
        "full_cost": "min(2F+i+12,2F+18,F+29+min(X,Y,6))",
    },
    "weak_forward_M": {
        "path": "docs/drafts/pra_shorter_boundary_2026-11-02.zip",
        "member": "pra_shorter_boundary_2026-11-02/sections/comparison.tex",
        "full_cost": "min(2F+i+11,F+20)",
        "definition_record": 12,
    },
    "strong_predecessor_K": {
        "path": "docs/drafts/pra_predecessor_boundary_2026-11-02.zip",
        "member": "pra_predecessor_boundary_2026-11-02/sections/09_native.tex",
        "full_cost": "min(2F+i+12,F+18)",
        "coverage_and_definition_records": 24,
    },
    "computation_L": {
        "path": "docs/drafts/pra_shared_computation_2026-11-02.zip",
        "member": "pra_shared_computation_2026-11-02/sections/02_computation.tex",
        "full_cost": "min(3H+13+k(H+2),3H+22,2H+34)",
    },
}

from dataclasses import dataclass
from itertools import product
from pathlib import Path
import argparse
import ast
import json
import random


def require(condition: bool, message: str) -> None:
    """Raise an explicit exception on failure; python -O cannot disable this."""
    if not condition:
        raise RuntimeError(message)


@dataclass(frozen=True)
class Term:
    tag: str
    name: str = ""
    args: tuple["Term", ...] = ()
    body: "Term | None" = None


def var(name: str) -> Term:
    return Term("var", name)


def zero() -> Term:
    return Term("zero")


def succ(t: Term) -> Term:
    return Term("succ", args=(t,))


def free_variables(t: Term) -> set[str]:
    if t.tag == "var":
        return {t.name}
    return set().union(*(free_variables(a) for a in t.args))


def rec(body: Term, n: Term, a: Term) -> Term:
    if not free_variables(body) <= {"v", "w"}:
        raise ValueError("A descriptor may have only the active state/counter slots")
    return Term("rec", args=(n, a), body=body)


def tsize(t: Term) -> int:
    return 1 + sum(tsize(a) for a in t.args) + (
        tsize(t.body) if t.body is not None else 0
    )


def has_rec(t: Term) -> bool:
    return t.tag == "rec" or any(has_rec(a) for a in t.args)


def active(t: Term, name: str) -> int:
    return int(t.tag == "var" and t.name == name) + sum(
        active(a, name) for a in t.args
    )


def subst(t: Term, mapping: dict[str, Term]) -> Term:
    if t.tag == "var":
        return mapping.get(t.name, t)
    return Term(t.tag, t.name, tuple(subst(a, mapping) for a in t.args), t.body)


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple["Formula", ...] = ()
    terms: tuple[Term, ...] = ()
    binder: str = ""


def eq(s: Term, t: Term) -> Formula:
    return Formula("eq", terms=(s, t))


def bot() -> Formula:
    return Formula("bot")


def arrow(a: Formula, b: Formula) -> Formula:
    return Formula("arrow", (a, b))


def land(a: Formula, b: Formula) -> Formula:
    return Formula("and", (a, b))


def lor(a: Formula, b: Formula) -> Formula:
    return Formula("or", (a, b))


def j(a: Formula, u: Formula, v: Formula) -> Formula:
    return Formula("J", (a, u, v))


def c(a: Formula, b: Formula, d: Formula) -> Formula:
    return Formula("C", (a, b, d))


def quantify(prefix: tuple[tuple[str, str], ...], f: Formula) -> Formula:
    for kind, name in reversed(prefix):
        f = Formula(kind, (f,), binder=name)
    return f


def fsize(f: Formula) -> int:
    return 1 + sum(fsize(a) for a in f.args) + sum(tsize(t) for t in f.terms)


def fsubst(f: Formula, mapping: dict[str, Term]) -> Formula:
    if f.binder:
        raise ValueError("This helper substitutes only into unquantified matrices")
    return Formula(
        f.tag,
        tuple(fsubst(a, mapping) for a in f.args),
        tuple(subst(t, mapping) for t in f.terms),
    )


a, n, u, x, y, b, v, w = map(var, ("a", "n", "u", "x", "y", "b", "v", "w"))
z = zero()
one = succ(z)


def direct_j(e: Formula) -> Formula:
    return quantify(
        (("forall", "a"), ("forall", "n"), ("exists", "b")),
        j(fsubst(e, {"x": b}), eq(b, z),
          arrow(fsubst(e, {"x": succ(b)}), eq(b, n))),
    )


def forward_j(e: Formula) -> Formula:
    return quantify(
        (("forall", "a"), ("forall", "n"), ("exists", "b"), ("forall", "x")),
        j(e, arrow(eq(x, b), eq(b, z)), arrow(eq(x, succ(b)), eq(b, n))),
    )


def current_strong_predecessor(e: Formula) -> Formula:
    return quantify(
        (("forall", "a"), ("forall", "n"), ("exists", "b"), ("forall", "x")),
        Formula("If", (e, arrow(eq(x, b), eq(b, n)), arrow(eq(succ(x), b), bot()))),
    )


def backward_c(e: Formula) -> Formula:
    return quantify(
        (("forall", "a"), ("forall", "n"), ("exists", "b"), ("forall", "x")),
        c(eq(succ(x), b), e, arrow(eq(x, b), eq(b, n))),
    )


def original_pair(h: Term) -> tuple[Formula, Formula]:
    base = quantify((("forall", "a"),), eq(rec(h, z, a), a))
    rhs = subst(h, {"v": rec(h, n, a), "w": n})
    step = quantify((("forall", "a"), ("forall", "n")),
                    eq(rec(h, succ(n), a), rhs))
    return base, step


def current_graph(h: Term) -> Formula:
    return quantify(
        (("forall", "a"), ("forall", "n"), ("forall", "u")),
        arrow(eq(rec(h, n, a), u),
              land(arrow(eq(n, z), eq(u, a)),
                   eq(rec(h, succ(n), a), subst(h, {"v": u, "w": n})))),
    )


def endpoint_graph_old(h: Term) -> Formula:
    table = quantify(
        (("forall", "x"), ("forall", "y")),
        arrow(eq(rec(h, x, a), y),
              land(arrow(eq(x, n), eq(y, u)),
                   arrow(eq(x, succ(n)), eq(y, subst(h, {"v": u, "w": n}))))),
    )
    return quantify(
        (("forall", "a"), ("forall", "n"), ("exists", "u")),
        land(arrow(eq(n, z), eq(u, a)), table),
    )


def current_graph_c(h: Term) -> Formula:
    return quantify(
        (("forall", "a"), ("forall", "x"), ("forall", "y")),
        c(land(eq(x, z), eq(y, a)), eq(rec(h, x, a), y),
          eq(rec(h, succ(x), a), subst(h, {"v": y, "w": x}))),
    )


def endpoint_graph_c(h: Term) -> Formula:
    table = quantify(
        (("forall", "x"), ("forall", "y")),
        c(land(eq(x, n), eq(y, u)), eq(rec(h, x, a), y),
          arrow(eq(x, succ(n)), eq(y, subst(h, {"v": u, "w": n})))),
    )
    return quantify(
        (("forall", "a"), ("forall", "n"), ("exists", "u")),
        land(arrow(eq(n, z), eq(u, a)), table),
    )


def state_free_graph_c(h: Term) -> Formula:
    require(active(h, "v") == 0, 'Check failed: active(h, "v") == 0')
    return quantify(
        (("forall", "a"), ("forall", "x"), ("forall", "y")),
        c(land(eq(x, z), eq(y, a)), eq(rec(h, x, a), y),
          quantify((("forall", "n"),),
            arrow(eq(x, succ(n)), eq(y, subst(h, {"v": z, "w": n}))))),
    )


def descriptor_profile(name: str, h: Term) -> dict:
    size, k = tsize(h), active(h, "v")
    costs = {
        "original": sum(fsize(f) for f in original_pair(h)),
        "current_value_graph": fsize(current_graph(h)),
        "old_endpoint_graph": fsize(endpoint_graph_old(h)),
        "C_current_graph": fsize(current_graph_c(h)),
        "C_endpoint_graph": fsize(endpoint_graph_c(h)),
    }
    require(costs["original"] == 3 * size + 13 + k * (size + 2), 'Check failed: costs["original"] == 3 * size + 13 + k * (size + 2)')
    require(costs["current_value_graph"] == 3 * size + 22, 'Check failed: costs["current_value_graph"] == 3 * size + 22')
    require(costs["old_endpoint_graph"] == 2 * size + 34, 'Check failed: costs["old_endpoint_graph"] == 2 * size + 34')
    require(costs["C_current_graph"] == 3 * size + 21, 'Check failed: costs["C_current_graph"] == 3 * size + 21')
    require(costs["C_endpoint_graph"] == 2 * size + 33, 'Check failed: costs["C_endpoint_graph"] == 2 * size + 33')
    if k == 0:
        costs["C_state_free_graph"] = fsize(state_free_graph_c(h))
        require(costs["C_state_free_graph"] == 2 * size + 24, 'Check failed: costs["C_state_free_graph"] == 2 * size + 24')
    old_min = min(costs[key] for key in (
        "original", "current_value_graph", "old_endpoint_graph"))
    new_min = min(value for key, value in costs.items()
                  if key == "original" or key.startswith("C_"))
    require(new_min <= old_min, 'Check failed: new_min <= old_min')
    return {"name": name, "H": size, "k": k, **costs,
            "old_min": old_min, "new_C_min": new_min,
            "is_Q_descriptor": h == w}


def boundary_profile(name: str, s: Term, t: Term) -> dict:
    e = eq(s, t)
    size, i = fsize(e), active(s, "x") + active(t, "x")
    direct, forward, backward = map(fsize, (direct_j(e), forward_j(e), current_strong_predecessor(e)))
    chain = fsize(backward_c(e))
    signed = fsize(backward_c(arrow(e, bot())))
    require(direct == 2 * size + i + 11, 'Check failed: direct == 2 * size + i + 11')
    require(forward == size + 20, 'Check failed: forward == size + 20')
    require(backward == size + 18, 'Check failed: backward == size + 18')
    require(chain == size + 16, 'Check failed: chain == size + 16')
    require(signed == size + 18, 'Check failed: signed == size + 18')
    optimized = 0 if i == 0 or not (has_rec(s) or has_rec(t)) else chain
    return {"name": name, "F": size, "i": i, "direct_j": direct,
            "forward_j": forward, "current_strong_predecessor_uniform": backward,
            "C_backward": chain, "C_signed_negative": signed,
            "C_optimized": optimized,
            "C_optimized_scope": "whole theory, where Q computation is present",
            "active_recursor_free_omission_needs_Q_support":
                bool(i and not (has_rec(s) or has_rec(t))),
            "current_forward_min": min(direct, forward),
            "current_strong_predecessor_min": min(2 * size + i + 12, backward)}


def finite_computation_checks() -> dict:
    """Check C graphs in all two-element structures, without arithmetic axioms."""
    checked = 0
    state_free_checked = 0
    for size in (1, 2):
        domain = tuple(range(size))
        tables = tuple(product(domain, repeat=size * size))
        for zero_value in domain:
            for successor in product(domain, repeat=size):
                for rt in tables:
                    r = lambda q, p: rt[q * size + p]
                    for ht in tables:
                        h = lambda q, p: ht[q * size + p]
                        original = all(r(zero_value, p) == p for p in domain) and all(
                            r(successor[q], p) == h(r(q, p), q)
                            for p in domain for q in domain
                        )
                        gc = all(
                            (not (q == zero_value and value == p) or r(q, p) == value)
                            and (r(q, p) != value or r(successor[q], p) == h(value, q))
                            for p in domain for q in domain for value in domain
                        )
                        tc = all(any(
                            (q != zero_value or state == p) and all(
                                (not (t == q and value == state) or r(t, p) == value)
                                and (r(t, p) != value or t != successor[q]
                                     or value == h(state, q))
                                for t in domain for value in domain
                            )
                            for state in domain
                        ) for p in domain for q in domain)
                        checked += 1
                        require(original == gc == tc, 'Check failed: original == gc == tc')
                        state_free = all(h(t, q) == h(zero_value, q)
                                         for t in domain for q in domain)
                        if state_free:
                            vc = all(
                                (not (q == zero_value and value == p) or r(q, p) == value)
                                and (r(q, p) != value or all(
                                    q != successor[counter] or value == h(zero_value, counter)
                                    for counter in domain))
                                for p in domain for q in domain for value in domain
                            )
                            state_free_checked += 1
                            require(original == vc, 'Check failed: original == vc')
    return {"all_structures_checked": checked,
            "state_free_structures_checked": state_free_checked,
            "all_tested_C_G_and_T_agree_with_original": True,
            "all_tested_state_free_C_V_agree_with_original": True}


def pure_successor_case(s: Term, t: Term) -> str:
    """Classify the written induction-free proof, not search for a proof."""
    if has_rec(s) or has_rec(t):
        raise ValueError("This classifier applies only to the 0,S term grammar")
    if active(s, "x") + active(t, "x") == 0:
        return "input_absent"
    def peel(q: Term) -> tuple[int, Term]:
        exponent = 0
        while q.tag == "succ":
            exponent += 1
            q = q.args[0]
        return exponent, q
    left_exponent, left_leaf = peel(s)
    right_exponent, right_leaf = peel(t)
    if (left_leaf == x) != (right_leaf == x):
        return "base_and_first_step_contradict_separation"
    require(left_leaf == x and right_leaf == x, 'Check failed: left_leaf == x and right_leaf == x')
    if left_exponent == right_exponent:
        return "reflexive"
    return "base_equates_distinct_numerals"


def packet_check() -> dict:
    """Packet inequalities with all different logical bases paid separately.

    C graphs are charged only on C branches. Ordinary and weak-J forward
    fallbacks retain old computation L. The C boundary branch pays Cov10
    plus C-definition12. Its old comparator pays Cov10 plus If-definition14.
    The generated examples are actual finite term/descriptor syntax.
    """
    rng = random.Random(20261102)
    descriptor_pool = [z, v, w, succ(v), rec(v, v, w), rec(v, w, z)]
    for leaf in (z, v, w):
        term = leaf
        for _ in range(20):
            descriptor_pool.append(term)
            term = succ(term)
    duplicate = v
    for _ in range(7):
        descriptor_pool.append(duplicate)
        duplicate = rec(v, duplicate, duplicate)
    def term(depth: int) -> Term:
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice((z, x, a))
        if rng.randrange(2) == 0:
            return succ(term(depth-1))
        return rec(rng.choice(descriptor_pool), term(depth-1), term(depth-1))
    profiles = []
    for _ in range(600):
        left, right = term(3), term(3)
        size = 1 + tsize(left) + tsize(right)
        i = active(left, "x") + active(right, "x")
        omission_needs_q = bool(i and not (has_rec(left) or has_rec(right)))
        if i == 0:
            ordinary = forward = predecessor = chain = 0
        else:
            ordinary = min(2*size+i+12, 2*size+18,
                           size+29+min(tsize(left), tsize(right), 6))
            forward = min(2*size+i+11, size+20)
            predecessor = min(2*size+i+12, size+18)
            chain = size+16
            if not omission_needs_q:
                require(size >= 6, "A retained recursor equation must have F>=6")
                require(chain <= forward-2, "Retained core equation must save at least two recurring nodes")
        # This comparison holds even when Q is absent and an R-free axiom
        # must be emitted. N_packet<=M need not hold in that case.
        require(chain <= predecessor, "Packet C clause exceeds current predecessor envelope")
        profiles.append((ordinary, forward, predecessor, chain, omission_needs_q))
    computation_profiles = [descriptor_profile(str(j), h)
                            for j, h in enumerate(descriptor_pool)]
    checked = 0
    strict = 0
    q_supported_packets = 0
    for _ in range(2000):
        packet = [rng.choice(profiles) for _ in range(rng.randrange(0, 30))]
        a_sum, m_sum, k_sum = (sum(row[j] for row in packet) for j in range(3))
        computations = [rng.choice(computation_profiles)
                        for _ in range(rng.randrange(0, 30))]
        has_q_support = any(row["is_Q_descriptor"] for row in computations)
        n_sum = sum(0 if row[4] and has_q_support else row[3] for row in packet)
        require(n_sum <= k_sum, "Supported C packet exceeds predecessor packet")
        q_supported_packets += has_q_support
        old_l_sum = sum(row["old_min"] for row in computations)
        new_l_sum = sum(row["new_C_min"] for row in computations)
        old = 6+old_l_sum+min(a_sum, 12+m_sum, 24+k_sum)
        new = 6+min(old_l_sum+a_sum, 12+old_l_sum+m_sum, 22+new_l_sum+n_sum)
        require(new <= old, "New native packet family exceeds current composite frontier")
        strict += new < old
        checked += 1
    # No computation modules are present in this specific R-free packet.
    # Its induction implication is trivial in the whole theory, but using
    # that proof in a finite packet would require the missing Q equations.
    # We therefore emit the 19-node C clause instead of claiming cost zero.
    no_q_example = boundary_profile("x=a with empty computation support", x, a)
    no_q_n = no_q_example["C_backward"]
    no_q_old = 6+min(19, 12+18, 24+19)
    no_q_new = 6+min(19, 12+18, 22+no_q_n)
    require(no_q_n == 19, "Unsupported R-free example must charge all 19 clause nodes")
    require(no_q_old == no_q_new == 25, "Empty-support example must preserve the old fallback")
    return {"packets_checked": checked, "strictly_smaller_examples": strict,
            "packets_with_Q_in_common_computation_support": q_supported_packets,
            "generated_boundary_profiles": len(profiles),
            "generated_computation_profiles": len(computation_profiles),
            "old_native_ledger": "6+sum L+min(sum A,12+sum M,24+sum K)",
            "new_family_ledger": "6+min(sum L+sum A,12+sum L+sum M,22+sum LC+sum N_packet)",
            "additional_legal_ordinary_boundary_C_computation_branch": "12+sum LC+sum A",
            "additional_legal_J_boundary_C_computation_branch": "24+sum LC+sum M",
            "C_basis_fixed_cost_including_Sep": 28,
            "finite_packet_omission_policy": (
                "Input-absent equations cost zero without computational support. "
                "Active R-free equations cost zero only if the Q=R_w module "
                "is in the common computation support; otherwise charge F+16."
            ),
            "empty_computation_support_example": {
                "equation": "x=a", "F": 3, "i": 1,
                "common_computation_modules": [], "Q_common": False,
                "whole_theory_C_omission_cost": 0,
                "finite_packet_C_boundary_cost": no_q_n,
                "old_selected_total": no_q_old,
                "new_selected_total": no_q_new,
            },
            "proof": (
                "LC<=L and N_packet<=K pointwise, so the new paid-covered C "
                "branch is no larger than the old paid-covered If branch. "
                "The other branches are retained unchanged. N_core<=M uses "
                "the whole theory's Q support; it is not asserted for "
                "unsupported finite packets. Cov10 and each logical "
                "definition remain charged. The single C presentation is "
                "not asserted to win on every small finite packet."
            )}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("verify_sizes_results.json"))
    args = parser.parse_args()
    assert_nodes = sum(isinstance(node, ast.Assert)
                       for node in ast.walk(ast.parse(Path(__file__).read_text())))
    require(assert_nodes == 0, "All verification checks must remain active under python -O")
    q_body, z_body = w, z
    toggle = rec(z_body, v, one)
    huge = v
    huge_state_free = w
    for _ in range(99):
        huge = succ(huge)
        huge_state_free = succ(huge_state_free)
    nested = rec(v, v, w)
    nested_changed = subst(nested, {"v": succ(z), "w": one})
    require(nested_changed.body is nested.body, 'Check failed: nested_changed.body is nested.body')
    require(nested_changed.body == v, 'Check failed: nested_changed.body == v')
    require(active(nested, "v") == 1, 'Check failed: active(nested, "v") == 1')
    require(tsize(nested_changed) == tsize(nested) + 2, 'Check failed: tsize(nested_changed) == tsize(nested) + 2')
    descriptors = [
        descriptor_profile("Q", q_body),
        descriptor_profile("Z", z_body),
        descriptor_profile("toggle_R_Z(v,1)", toggle),
        descriptor_profile("S^99(v)", huge),
        descriptor_profile("S^99(w)", huge_state_free),
        descriptor_profile("nested_R_v(v,w)", nested),
        descriptor_profile("state_free_with_frozen_v", rec(v, w, z)),
    ]
    for profile in descriptors[:3]:
        require(profile["new_C_min"] == profile["original"], 'Check failed: profile["new_C_min"] == profile["original"]')
    e_cov_left, e_cov_right = x, succ(rec(q_body, x, z))
    boundaries = [
        boundary_profile("x=a", x, a),
        boundary_profile("x=x", x, x),
        boundary_profile("Sx=a", succ(x), a),
        boundary_profile("Ecov", e_cov_left, e_cov_right),
        boundary_profile("nested_R_v(x,a)=a", rec(v, x, a), a),
    ]
    pure_terms = []
    for leaf in (z, x, a):
        q = leaf
        for _ in range(6):
            pure_terms.append(q)
            q = succ(q)
    pure_cases = {}
    for left, right in product(pure_terms, repeat=2):
        case = pure_successor_case(left, right)
        pure_cases[case] = pure_cases.get(case, 0) + 1
        require(boundary_profile("pure", left, right)["C_optimized"] == 0, 'Check failed: boundary_profile("pure", left, right)["C_optimized"] == 0')
    cov = next(row for row in boundaries if row["name"] == "Ecov")
    require((cov["F"], cov["i"], cov["forward_j"]) == (7, 2, 27), 'Check failed: (cov["F"], cov["i"], cov["forward_j"]) == (7, 2, 27)')
    descriptor_families_checked = 0
    h = v
    for level in range(9):
        descriptor_profile(f"duplication_level_{level}", h)
        descriptor_families_checked += 1
        h = rec(v, h, h)
    # A definition record consists of 4 LHS nodes, 1 rewrite marker,
    # and the 7-node ordinary-connective RHS.
    a_atom, u_atom, v_atom = (Formula("placeholder") for _ in range(3))
    j_rhs = land(lor(a_atom, u_atom), arrow(a_atom, v_atom))
    c_rhs = land(arrow(a_atom, u_atom), arrow(u_atom, v_atom))
    require(fsize(c_rhs) == 7, 'Check failed: fsize(c_rhs) == 7')
    require(fsize(j_rhs) == 7, 'Check failed: fsize(j_rhs) == 7')
    results = {
        "status": "PASS",
        "python_assert_statements": assert_nodes,
        "check_mechanism": "explicit require calls raising exceptions; active under python -O",
        "source_repository": SOURCE_REPOSITORY,
        "source_ref": SOURCE_REF,
        "baseline_source_constants": BASELINE_SOURCES,
        "admission_rule": "Omit input-absent and recursor-free equations; otherwise emit C predecessor",
        "pure_successor_syntax_classification": pure_cases,
        "metric": "full AST size, stored descriptor charged at every generated call",
        "descriptor_substitution_freezes_stored_bodies": True,
        "boundary_profiles": boundaries,
        "descriptor_profiles": descriptors,
        "additional_descriptor_family_members_checked": descriptor_families_checked,
        "J_definition_record_nodes": 4 + 1 + fsize(j_rhs),
        "C_definition_record_nodes": 4 + 1 + fsize(c_rhs),
        "arithmetic_seed_nodes": {
            "Sep": fsize(arrow(eq(z, one), bot())),
            "Cov": fsize(quantify((("forall", "x"),),
                lor(eq(x, z), quantify((("exists", "y"),), eq(x, succ(y)))))),
        },
        "finite_computation_semantics": finite_computation_checks(),
        "finite_packet_comparison": packet_check(),
        "scope": [
            "C graphs recover original equations without NoFix or any arithmetic assumption.",
            "Q,Z,toggle retain original pairs under the C computation selector.",
            "The new C boundary requires explicit coverage Cov10.",
            "All recursor-free equations have induction-free proofs using Q-derived successor laws; the syntactic classifier records their cases.",
            "The infinite core automatically includes Q. Finite packets omit active R-free axioms only when Q is in their common computation support.",
            "Counts and finite checks do not formalize full PRA bi-interpretability.",
        ],
    }
    out = args.output
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
