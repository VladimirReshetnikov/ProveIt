PRA FROM CHAINED IMPLICATIONS
Research report prepared for Vladimir Reshetnikov, 2 November 2026.

START HERE
  report.pdf       Complete mathematical report.
  report.tex       Main LaTeX source; sections/ contains all included text.
  AXIOMS.txt       Complete uniform and optimized theory specifications.
  provenance/comparison.csv  Audit of all six current and five archived proposals.

MAIN RESULTS
  C(A,B,D) = (A -> B) and (B -> D), definition record 12 nodes.
  Positive atomic boundary: F+16, versus current F+18 covered / F+20 forward.
  Computation: 3H+21, 2H+33, and state-free 2H+24 complete modules.
  Optional syntactic omission of recursor-free induction equations.
  Constructive bi-interpretability and equiconsistency with first-order PRA.
  Full-carrier identity composites, separately for classical and intuitionistic logic.

FIXED SUPPORT AND SCOPE
Coverage is explicit and costs ten nodes. The new covered C presentation
can lose on a tiny workload to an uncovered presentation. The report's
finite-packet family retains the existing ordinary and weak-conditional
routes and proves non-increase against their compatible current envelope.
Different payload languages (primitive equality bits, discriminators,
product sorts) are not assigned the same unit costs. No absolute shortest
axiomatization over all encodings is claimed. The current predecessor
draft already has signed raw T+20; that raw bound is not relabeled as new.

REPRODUCE
Requirements: Python 3.10+ standard library; TeX Live with pdflatex,
lmodern, amsmath, amssymb, amsthm, mathtools, booktabs, array, longtable,
geometry, microtype, url, hyperref.
  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only
The PDF build disables shell escape. Temporary compiler files go in _build/.
Poppler was used separately for the delivered PDF's visual review.

VERIFICATION
Fresh immutable-AST counting, frozen-descriptor substitution checks,
exhaustive small arbitrary structures for computation equivalence,
finite Kripke checks, an exact Boolean connective-size search, and
exhaustive finite backward-scan tests accompany the written proofs.
These checks are not a Lean/Rocq formalization of the full theorem.
The complete general proofs are in the report.

PROVENANCE
Repository: VladimirReshetnikov/ProveIt
Snapshot: 5f9cb0b20a6a83a11917c56efec53714ea85df6f
All eleven input ZIPs were checked against advertised lengths and Git
blob identifiers. See provenance/source_manifest.json and comparison.csv.
No downloaded code was executed; no repository mutation was performed.
The source architecture and arithmetic compiler are credited explicitly.

FILES
code/           Fresh verification scripts, standard library only.
verification/   Machine-readable results, build and visual review records.
provenance/     Immutable source identity and per-proposal comparison.
SHA256SUMS      Checksums of the delivered files (excluding this checksum file).
