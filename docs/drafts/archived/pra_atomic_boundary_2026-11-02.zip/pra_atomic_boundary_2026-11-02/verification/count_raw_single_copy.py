#!/usr/bin/env python3
"""Independent literal AST counts for the single-copy boundary formulas."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Node:
    op: str
    children: tuple = ()
    descriptor: object = None

    def size(self, full=False):
        return (1 + sum(x.size(full) for x in self.children)
                + (self.descriptor.size(True)
                   if full and self.descriptor is not None else 0))


def app(op, *children, descriptor=None):
    return Node(op, children, descriptor)


def var(name):
    return app(name)


def eq(left, right):
    return app("=", left, right)


def dis(left, right):
    return app("or", left, right)


def imp(left, right):
    return app("implies", left, right)


def conj(left, right):
    return app("and", left, right)


def occurs(node, name):
    return int(node.op == name and not node.children) + sum(
        occurs(child, name) for child in node.children
    )


def subst(node, name, value):
    if node.op == name and not node.children:
        return value
    # A frozen function descriptor is intentionally not traversed here.
    return Node(node.op, tuple(subst(child, name, value)
                               for child in node.children), node.descriptor)


def quant(body, count):
    for _ in range(count):
        body = app("binder", body)
    return body


a, n, b, x, z = [var(v) for v in ("a", "n", "b", "x", "0")]
w = var("w")
S = lambda term: app("S", term)
C = lambda u, v: app("chi", u, v)
D = lambda u, v: app("D", u, v)
Q = lambda u, v: app("R_w", u, v, descriptor=w)
Z = lambda u, v: app("R_0", u, v, descriptor=z)


def st(tail, boolean=False, zero_polarity=False):
    r = C(x, b)
    left = tail if boolean else C(tail, z)
    right = r if boolean or zero_polarity else C(x, S(b))
    return quant(imp(dis(eq(x, b), eq(x, S(b))),
                     dis(eq(b, Q(r, n)), eq(left, right))), 4)


def dst(tail):
    r = D(x, b)
    return quant(imp(dis(eq(x, b), eq(x, D(b, b))),
                     dis(eq(b, Z(r, n)), eq(D(tail, z), D(r, z)))), 4)


def old_fb(tail):
    at_b = subst(tail, "x", b)
    at_sb = subst(tail, "x", S(b))
    return quant(eq(C(b, Q(Z(at_sb, S(b)), n)), S(Z(at_b, b))), 3)


def old_fb_shared(tail):
    dvar = var("d")
    at_b = subst(tail, "x", b)
    at_d = subst(tail, "x", dvar)
    core = eq(C(b, Q(Z(at_d, dvar), n)), S(Z(at_b, b)))
    return quant(conj(eq(dvar, S(b)), core), 4)


def old_fb_table(tail):
    r, s, y = map(var, ("r", "s", "y"))
    core = eq(C(b, Q(Z(r, S(b)), n)), S(Z(s, b)))
    relation = dis(conj(eq(x, b), eq(y, s)),
                   conj(eq(x, S(b)), eq(y, r)))
    table = quant(imp(relation, eq(tail, y)), 2)
    return quant(conj(core, table), 5)


tails = [x, a, z, C(x, a), S(C(S(x), a)),
         Q(C(x, a), S(z)),
         app("R_nested", x, a, descriptor=Q(C(w, z), S(z)))]
for tail in tails:
    m, T = tail.size(), tail.size(True)
    i = occurs(tail, "x")
    shifted = subst(tail, "x", S(b))
    assert (shifted.size(), shifted.size(True)) == (m + i, T + i)
    for name, formula, expected in (
        ("ST", st(tail), (m + 28, T + 29)),
        ("BST", st(tail, boolean=True), (m + 25, T + 26)),
        ("ST_zero", st(tail, zero_polarity=True), (m + 27, T + 28)),
        ("DST", dst(tail), (m + 30, T + 31)),
        ("old_FB", old_fb(tail), (2 * m + i + 14, 2 * T + i + 17)),
        ("old_FB_S", old_fb_shared(tail), (2 * m + 19, 2 * T + 22)),
        ("old_FB_T", old_fb_table(tail), (m + 40, T + 43)),
    ):
        actual = (formula.size(), formula.size(True))
        assert actual == expected, (name, actual, expected)

for T in range(1, 150):
    for i in range(T + 1):
        old = min(2 * T + i + 17, 2 * T + 22, T + 43)
        new = min(2 * T + i + 17, 2 * T + 22, T + 29)
        boolean = min(2 * T + i + 17, 2 * T + 22, T + 26)
        c = min(i, 5)
        assert old - new == max(0, min(T + c - 12, 14))
        assert old - boolean == max(0, min(T + c - 9, 17))

parity_desc = C(var("v"), z)
R = lambda u, v: app("R_parity", u, v, descriptor=parity_desc)
base = quant(eq(R(z, a), a), 1)
step = quant(eq(R(S(n), a), C(R(n, a), z)), 2)
assert (base.size(), base.size(True)) == (6, 9)
assert (step.size(), step.size(True)) == (12, 18)

print("49 independent AST formula counts passed, including all old FB variants.")
print("All exact envelope savings passed for 11,324 (T,i) profiles.")
print("Parity recursion base: 6 active / 9 full.")
print("Parity recursion step: 12 active / 18 full.")

