#!/usr/bin/env python3
"""Exhaustive checks of the new raw boundary tables and their scan witness.

These are finite verification artifacts, not a formal proof over nonstandard
models.  The accompanying paper proves the first-order statements internally.
Every tested prefix assigns an arbitrary pattern of zero/nonzero truth values;
positive values vary with the input, so the raw tests are not restricted to
Boolean-valued numerical tails.  A table's guarded universal can matter only
at b and b+1, and those two points are evaluated exactly.
"""
from itertools import product
import json


def chi(u, v):
    return int(u == v)


def q(u, seed):
    return seed if u == 0 else u - 1


def z(u, seed):
    return seed if u == 0 else 0


def d(u, v):
    return u + 1 if u == v else 0


def boundary(values, target, witness):
    return ((witness == 0 or values[witness] != 0)
            and (witness == target or values[witness + 1] == 0))


def raw_table(values, target, witness):
    return all(
        witness == q(chi(x, witness), target)
        or chi(values[x], 0) == chi(x, witness + 1)
        for x in (witness, witness + 1)
    )


def boolean_table(bits, target, witness):
    return all(
        witness == q(chi(x, witness), target)
        or bits[x] == chi(x, witness)
        for x in (witness, witness + 1)
    )


def d_table(values, target, witness):
    return all(
        witness == z(d(x, witness), target)
        or d(values[x], 0) == d(d(x, witness), 0)
        for x in (witness, witness + 1)
    )


def incorrect_endpoint_table(values, target, witness):
    """A tempting but invalid replacement of the endpoint exemption."""
    return all(
        x == 0 or x == target + 1
        or chi(values[x], 0) == chi(x, witness + 1)
        for x in (witness, witness + 1)
    )


def main():
    prefixes = comparisons = witnesses = 0
    for length in range(2, 13):
        for bits in product((0, 1), repeat=length):
            prefixes += 1
            values = tuple((1 + x % 5) if bit else 0
                           for x, bit in enumerate(bits))
            for target in range(length - 1):
                for candidate in range(length - 1):
                    expected = boundary(values, target, candidate)
                    assert raw_table(values, target, candidate) == expected
                    assert boolean_table(bits, target, candidate) == expected
                    assert d_table(values, target, candidate) == expected
                    comparisons += 1

            candidate = 0
            for target in range(length - 1):
                # This is exactly the paper's quantifier-free scan invariant.
                assert candidate == 0 or values[candidate] != 0
                assert values[candidate + 1] == 0 or candidate == target
                assert candidate <= target
                assert raw_table(values, target, candidate)
                assert boolean_table(bits, target, candidate)
                assert d_table(values, target, candidate)
                witnesses += 1
                if values[candidate + 1] != 0:
                    candidate = target + 1

    # The witness b=Sn can exploit the incorrect x=Sn exception at x=b.
    wrong_values, wrong_target, wrong_witness = (1, 0, 0), 0, 1
    assert incorrect_endpoint_table(wrong_values, wrong_target, wrong_witness)
    assert not boundary(wrong_values, wrong_target, wrong_witness)
    assert not raw_table(wrong_values, wrong_target, wrong_witness)

    result = {
        "prefix_lengths": [2, 12],
        "exhaustive_zero_nonzero_prefixes": prefixes,
        "boundary_pairs_per_table": comparisons,
        "tables_checked": 3,
        "recursive_witness_targets": witnesses,
        "rejected_endpoint_counterexample": {
            "values": wrong_values,
            "target": wrong_target,
            "witness": wrong_witness,
        },
        "status": "all assertions passed",
        "scope": "finite exhaustive checks; nonstandard-model proof is in the paper",
    }
    assert prefixes == 8188
    assert comparisons == 835572
    assert witnesses == 81924
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
