#!/usr/bin/env python3
"""Exhaustively compare the five witness formulas on small arbitrary carriers.

Successor may have fixed points or be noninjective. Function values need not
be standard arithmetic. This validates the pure-logical serializer kernel,
not the arithmetic interpretation theorem. Only standard Python is required.
"""
from itertools import product
import json
from pathlib import Path
from atomic_serialization import application, templates, x, a


def evaluate(node, env, domain, functions):
    if node.kind == "var":
        return env[node.name]
    if node.kind == "const":
        return 0
    if node.kind == "app":
        args = tuple(evaluate(c, env, domain, functions) for c in node.children)
        return functions[node.name](*args)
    if node.kind == "eq":
        return (evaluate(node.children[0], env, domain, functions)
                == evaluate(node.children[1], env, domain, functions))
    if node.kind == "and":
        return (evaluate(node.children[0], env, domain, functions)
                and evaluate(node.children[1], env, domain, functions))
    if node.kind == "or":
        return (evaluate(node.children[0], env, domain, functions)
                or evaluate(node.children[1], env, domain, functions))
    if node.kind == "implies":
        return (not evaluate(node.children[0], env, domain, functions)
                or evaluate(node.children[1], env, domain, functions))
    if node.kind in ("forall", "exists"):
        values = (evaluate(node.children[0], {**env, node.name: value},
                           domain, functions) for value in domain)
        return all(values) if node.kind == "forall" else any(values)
    raise ValueError(node.kind)


def run():
    all_forms = templates(application("t", x, a), application("s", x, a))
    bodies = {}
    for name, formula in all_forms.items():
        # Fix a,n,b externally. Existential b is the same witness in all forms.
        for expected_kind in ("forall", "forall", "exists"):
            assert formula.kind == expected_kind
            formula = formula.children[0]
        bodies[name] = formula
    structures = witnesses = 0
    for cardinality in (1, 2, 3):
        domain = tuple(range(cardinality))
        tables = list(product(domain, repeat=cardinality))
        for successor, t_values, s_values in product(tables, repeat=3):
            functions = {"S": lambda y: successor[y],
                         "t": lambda y, parameter: t_values[y],
                         "s": lambda y, parameter: s_values[y]}
            structures += 1
            for target, witness in product(domain, repeat=2):
                env = {"a": 0, "n": target, "b": witness}
                values = {name: evaluate(body, env, domain, functions)
                          for name, body in bodies.items()}
                assert len(set(values.values())) == 1, (
                    cardinality, successor, t_values, s_values, env, values)
                witnesses += 1
        print(f"Completed all carriers of size {cardinality}", flush=True)
    result = {"structures_checked": structures,
              "target_witness_pairs_checked": witnesses,
              "forms_per_pair": len(bodies),
              "allowed_successor_fixed_points": True,
              "scope": "Finite classical models of the serializer equivalences"}
    Path(__file__).with_name("atomic_semantics.json").write_text(
        json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run()
