#!/usr/bin/env python3
"""Literal AST serializer and size checks; frozen descriptors are fully charged.

No third-party dependencies. Run from this directory with Python 3.10+.
This verifies syntax accounting, not the complete PRA interpretation theorem.
"""
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    name: str = ""
    children: tuple = ()
    descriptor: object = None

    def size(self, full=True):
        extra = self.descriptor.size(True) if full and self.descriptor else 0
        return 1 + extra + sum(c.size(full) for c in self.children)

    def occurrences(self, name):
        return int(self.kind == "var" and self.name == name) + sum(
            c.occurrences(name) for c in self.children
        )

    def substitute(self, name, value):
        if self.kind == "var" and self.name == name:
            return value
        if self.kind in ("forall", "exists"):
            raise ValueError("Only substitute in unbound term trees")
        return Node(self.kind, self.name,
                    tuple(c.substitute(name, value) for c in self.children),
                    self.descriptor)

    def to_dict(self):
        result = {"kind": self.kind}
        if self.name:
            result["name"] = self.name
        if self.children:
            result["children"] = [c.to_dict() for c in self.children]
        if self.descriptor:
            result["descriptor"] = self.descriptor.to_dict()
        return result


def variable(name):
    return Node("var", name)


def application(name, *children, descriptor=None):
    return Node("app", name, children, descriptor)


def operation(kind, *children):
    return Node(kind, children=children)


def quantify(prefix, body):
    for kind, name in reversed(prefix):
        body = Node(kind, name, (body,))
    return body


zero = Node("const", "0")
a, n, b, c, x, u, v = map(variable, ("a", "n", "b", "c", "x", "u", "v"))
S = lambda arg: application("S", arg)
Eq = lambda left, right: operation("eq", left, right)
And = lambda left, right: operation("and", left, right)
Or = lambda left, right: operation("or", left, right)
Imp = lambda left, right: operation("implies", left, right)
PREFIX = (("forall", "a"), ("forall", "n"), ("exists", "b"))


def pair_at(t, s, point):
    return Eq(t.substitute("x", point), s.substitute("x", point))


def constraints(left_value, right_value):
    equal_values = Eq(left_value, right_value)
    return And(Imp(Eq(x, b), Or(Eq(b, zero), equal_values)),
               Imp(Eq(x, S(b)), Imp(equal_values, Eq(b, n))))


def templates(t, s):
    literal = quantify(PREFIX, And(Or(Eq(b, zero), pair_at(t, s, b)),
                                  Imp(pair_at(t, s, S(b)), Eq(b, n))))
    shared = quantify(PREFIX + (("exists", "c"),),
                      And(Eq(c, S(b)),
                          And(Or(Eq(b, zero), pair_at(t, s, b)),
                              Imp(pair_at(t, s, c), Eq(b, n)))))
    both = quantify(PREFIX + (("forall", "x"), ("forall", "u"),
                              ("forall", "v")),
                    Imp(And(Eq(u, t), Eq(v, s)), constraints(u, v)))
    left = quantify(PREFIX + (("forall", "x"), ("forall", "u")),
                    Imp(Eq(u, t), constraints(u, s)))
    right = quantify(PREFIX + (("forall", "x"), ("forall", "v")),
                     Imp(Eq(v, s), constraints(t, v)))
    return {"AB": literal, "AB-S": shared, "AB-V": both,
            "AB-L": left, "AB-R": right}


def expected_counts(t, s, full=True):
    T, U = t.size(full), s.size(full)
    F, i = T + U + 1, t.occurrences("x") + s.occurrences("x")
    return {"AB": 2 * F + i + 12, "AB-S": 2 * F + 18,
            "AB-V": F + 35, "AB-L": T + 2 * U + 30,
            "AB-R": 2 * T + U + 30}


def emit(t, s):
    forms = templates(t, s)
    name = min(forms, key=lambda key: forms[key].size(True))
    return name, forms[name]


def succs(term, count):
    for _ in range(count):
        term = S(term)
    return term


def run_checks():
    w, state = variable("w"), variable("v")
    q = lambda r, z: application("R_w", r, z, descriptor=w)
    nested_body = q(S(state), S(w))
    nested = application("R_nested", x, a, descriptor=nested_body)
    samples = [x, a, zero, S(x), q(x, a), nested,
               q(nested, q(x, S(a))), succs(x, 19), succs(x, 99)]
    count = 0
    for t in samples:
        for s in samples:
            for full in (False, True):
                expected = expected_counts(t, s, full)
                for name, node in templates(t, s).items():
                    assert node.size(full) == expected[name], (name, t, s)
                    count += 1
            i = t.occurrences("x") + s.occurrences("x")
            P = Eq(t, s)
            for full in (False, True):
                shifted = P.substitute("x", S(b))
                assert shifted.size(full) == P.size(full) + i
            T, U = t.size(), s.size()
            F = T + U + 1
            chosen, emitted = emit(t, s)
            cost = min(2 * F + i + 12, 2 * F + 18,
                       F + 29 + min(T, U, 6))
            assert emitted.size() == cost
            assert chosen in templates(t, s)

    # Algebraic inequalities are proved in the paper; enumerate profiles as
    # an independent regression check of their executable expressions.
    profiles = 0
    for T in range(1, 81):
        for U in range(1, 81):
            F = T + U + 1
            for i in range(F + 1):
                old = min(2 * F + i + 12, 2 * F + 18, F + 43)
                new3 = min(2 * F + i + 12, 2 * F + 18, F + 35)
                new5 = min(2 * F + i + 12, 2 * F + 18,
                           F + 29 + min(T, U, 6))
                assert new5 <= new3 <= old
                assert old - new3 == max(0, min(F + min(i, 6) - 23, 8))
                profiles += 1

    rows = []
    for T, U, i, expected_old, expected_new in (
        (1, 1, 1, 19, 19), (20, 20, 2, 84, 76),
        (100, 1, 1, 145, 132), (100, 100, 2, 244, 236)
    ):
        t = succs(x, T - 1)
        s = succs(x if i == 2 else a, U - 1)
        name, selected = emit(t, s)
        F = T + U + 1
        old = min(2 * F + i + 12, 2 * F + 18, F + 43)
        assert (old, selected.size()) == (expected_old, expected_new)
        rows.append({"T": T, "U": U, "F": F, "i": i,
                     "old_relaxed": old, "new": selected.size(),
                     "selected": name})
    result = {"ast_counts_checked": count, "profiles_checked": profiles,
              "examples": rows, "verification_scope":
              "Literal syntax counts and finite arithmetic regression only"}
    output = Path(__file__).with_name("atomic_counts.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    example = templates(succs(x, 19), succs(x, 19))["AB-V"]
    Path(__file__).with_name("example_atomic_instance.json").write_text(
        json.dumps(example.to_dict(), indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run_checks()
