PRIMITIVE RECURSIVE ARITHMETIC FROM ATOMIC BOUNDARIES
Prepared for Vladimir Reshetnikov, 2 November 2026.

START HERE
  report.pdf       Complete research paper.
  report.tex       Main LaTeX source; sections/ contains all included sources.

RESULT
  Initial symbols: 0,S. One generated family of binary initialized recursors.
  Fixed axiom: 0 != S(0).
  Boundary scheme, for any two earlier terms t(x,a),s(x,a):
    forall a,n exists b,
      (b=0 or t(b,a)=s(b,a)) and
      (t(S(b),a)=s(S(b),a) -> b=n).
  The paper proves a common conservative definitional extension with
  first-order PRA, with whole domains, native equality and identity round
  trips, separately in classical and intuitionistic logic.

  The atomic restriction and native boundary mechanism are attributed to
  the existing drafts. The improvement is their combination with fully
  charged value-binding serializations. For F=|t=s|, sizes T=|t|,U=|s|,
  and i active input occurrences, the new exact full-size envelope is
    min(2F+i+12, 2F+18, F+29+min(T,U,6)).
  It is no larger than the favorable surviving-draft atomic benchmark
    min(2F+i+12, 2F+18, F+43).
  A separate raw-tail construction replaces T+43 by T+29 with the same
  17-node fixed seed as the fused-boundary draft.

  These are precise common-workload syntax comparisons, not absolute
  shortestness or whole-proof-length theorems. Active-size domination
  and uniform same-formula gains for all non-atomic formulas are not claimed.

SOURCES
  All 7 current packages and 6 archived packages were inspected at
  356163ca545206e31dd6b634f9c9bfc1596b3cac.
  All 7 current packages improve on the archived iteration and are retained.
  provenance/source_manifest.json records verified Git hashes, SHA-256
  hashes, sizes, and direct TeX member hashes.
  provenance/draft_audit.txt contains the detailed audit and qualifications.

VERIFICATION
  Python 3.10+; standard library only:
    python3 verification/atomic_serialization.py
    python3 verification/check_atomic_semantics.py
    python3 verification/count_raw_single_copy.py
    python3 verification/check_raw_single_copy.py

  The first script also emits a literal JSON example axiom and count table.
  The atomic semantic check exhausts all successor and two term-value maps
  on carriers of sizes 1,2,3, including fixed points and noninjective maps.
  The raw semantic check exhausts finite zero/nonzero prefixes and checks
  the recursive boundary candidate. See report Section 8 for exact scope.
  The complete interpretation theorem is proved in writing, not fully
  formalized in Lean or Rocq. Finite checks do not replace its proof.

REBUILD
  Requires pdfLaTeX with the packages in report.tex:
    python3 build.py
  To run all checks and rebuild:
    python3 build.py --checks
  Build intermediates are written in build/ and need not be retained.

FURTHER OBSTRUCTION
  Restricting the scheme to t(x,a)=0 in the 0,S recursor language is not
  bi-interpretable with PRA. The paper proves this using an infinite
  additional-chain model and a finite-order automorphism obstruction.

All comparison counts charge generated-symbol descriptors at every
occurrence. No universal evaluator, hidden pairing axiom, or semantic
program-equivalence test is assumed.
