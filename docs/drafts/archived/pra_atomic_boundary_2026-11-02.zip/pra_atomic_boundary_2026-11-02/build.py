#!/usr/bin/env python3
"""Run optional checks and compile the complete paper with pdfLaTeX."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checks", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if args.checks:
        for name in ("atomic_serialization.py", "check_atomic_semantics.py",
                     "count_raw_single_copy.py", "check_raw_single_copy.py"):
            subprocess.run([sys.executable, str(root / "verification" / name)],
                           cwd=root, check=True)
    executable = shutil.which("pdflatex")
    if executable is None:
        raise SystemExit("pdfLaTeX is required to rebuild report.pdf")
    build = root / "build"
    build.mkdir(exist_ok=True)
    command = [executable, "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "-output-directory", str(build), "report.tex"]
    for _ in range(3):
        subprocess.run(command, cwd=root, check=True, stdout=subprocess.DEVNULL)
    shutil.copy2(build / "report.pdf", root / "report.pdf")
    print(f"Built {root / 'report.pdf'}")


if __name__ == "__main__":
    main()
