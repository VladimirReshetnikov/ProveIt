#!/usr/bin/env python3
"""Check finite equational certificates for the 38-node pairing kernel.

This checks only the local algebraic replacement, not the infinite iPRA
bi-interpretability theorem. The checker trusts ordinary equational logic
(hypotheses, reflexivity, symmetry, transitivity, congruence, and instances of
the explicitly permitted axioms). PR's two conjuncts are separately named.
No rule for cancellation, arithmetic simplification, induction, case splits,
or an already derived theorem is trusted. Recursor descriptors are frozen
during every substitution. Coverage supplies the two-case logical assembly
of the separately checked converse certificates in the written report.

Run: python3 code/pairing_certificate.py
Outputs are written under verification/ relative to this script's package.
Uses only the Python standard library.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from math import isqrt
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    descriptor: "Term | None" = None


def var(name: str) -> Term:
    return Term("var:" + name)


ZERO = Term("0")


def app(op: str, *args: Term) -> Term:
    return Term(op, tuple(args))


def S(t: Term) -> Term:
    return app("S", t)


def B(a: Term, n: Term) -> Term:
    return app("B", a, n)


def L(x: Term) -> Term:
    return app("L", x)


def R(x: Term) -> Term:
    return app("R", x)


def Q(n: Term, a: Term) -> Term:
    return Term("rec", (n, a), var("w"))


def Z(n: Term, a: Term) -> Term:
    return Term("rec", (n, a), ZERO)


def F(a: Term, n: Term) -> Term:
    """An abbreviation expanded before checking or counting."""
    return B(Q(a, S(n)), Q(Z(a, S(ZERO)), S(n)))


def subst(t: Term, sigma: dict[str, Term]) -> Term:
    if t.op.startswith("var:"):
        return sigma.get(t.op[4:], t)
    # Intentionally do not substitute into t.descriptor.
    return Term(t.op, tuple(subst(a, sigma) for a in t.args), t.descriptor)


ARITIES = {"0": 0, "S": 1, "B": 2, "L": 1, "R": 1, "rec": 2}


def valid_term(t: Term) -> None:
    if t.op.startswith("var:"):
        assert t.op[4:] and not t.args and t.descriptor is None
        return
    assert t.op in ARITIES and len(t.args) == ARITIES[t.op]
    assert (t.op == "rec") == (t.descriptor is not None)
    for a in t.args:
        valid_term(a)
    if t.descriptor is not None:
        valid_term(t.descriptor)


def term_size(t: Term) -> int:
    return 1 + sum(map(term_size, t.args)) + (
        term_size(t.descriptor) if t.descriptor is not None else 0
    )


def show(t: Term) -> str:
    if t.op.startswith("var:"):
        return t.op[4:]
    if t.op == "0":
        return "0"
    head = t.op
    if head == "rec":
        head = "R[" + show(t.descriptor) + "]"
    return head + "(" + ",".join(map(show, t.args)) + ")"


Equation = tuple[Term, Term]
x, y, a, n = map(var, ("x", "y", "a", "n"))

AXIOMS: dict[str, Equation] = {
    "Q0": (Q(ZERO, a), a),
    "QS": (Q(S(n), a), n),
    "Z0": (Z(ZERO, a), a),
    "ZS": (Z(S(n), a), ZERO),
    "PR_left": (L(B(a, n)), a),
    "PR_right": (R(B(a, n)), n),
    "J": (S(x), F(L(x), R(x))),
    "PE": (B(L(x), R(x)), x),
    "PH": (S(B(S(a), n)), B(a, S(n))),
    "PV": (S(B(ZERO, n)), B(S(n), ZERO)),
}
QZ = frozenset(("Q0", "QS", "Z0", "ZS"))
NEW = QZ | frozenset(("PR_left", "PR_right", "J"))
OLD = QZ | frozenset(("PR_left", "PR_right", "PE", "PH", "PV"))


@dataclass(frozen=True)
class Proof:
    rule: str
    data: Any = None
    children: tuple["Proof", ...] = ()


def check(p: Proof, hypotheses: tuple[Equation, ...], allowed: frozenset[str]) -> Equation:
    """The trusted checking kernel. All derived algebra is outside this."""
    if p.rule == "refl":
        assert not p.children
        valid_term(p.data)
        return p.data, p.data
    if p.rule == "hyp":
        assert not p.children and isinstance(p.data, int)
        assert 0 <= p.data < len(hypotheses)
        lhs, rhs = hypotheses[p.data]
        valid_term(lhs)
        valid_term(rhs)
        return lhs, rhs
    if p.rule == "axiom":
        assert not p.children
        name, sigma = p.data
        assert name in allowed and name in AXIOMS
        assert isinstance(sigma, dict)
        for term in sigma.values():
            valid_term(term)
        lhs, rhs = AXIOMS[name]
        return subst(lhs, sigma), subst(rhs, sigma)
    if p.rule == "sym":
        assert p.data is None and len(p.children) == 1
        lhs, rhs = check(p.children[0], hypotheses, allowed)
        return rhs, lhs
    if p.rule == "trans":
        assert p.data is None and len(p.children) == 2
        lhs, mid = check(p.children[0], hypotheses, allowed)
        mid2, rhs = check(p.children[1], hypotheses, allowed)
        assert mid == mid2, "transitivity middle terms differ"
        return lhs, rhs
    if p.rule == "cong":
        op, descriptor = p.data
        assert op in ARITIES and len(p.children) == ARITIES[op]
        assert (op == "rec") == (descriptor is not None)
        if descriptor is not None:
            valid_term(descriptor)
        eqs = [check(c, hypotheses, allowed) for c in p.children]
        return (
            Term(op, tuple(e[0] for e in eqs), descriptor),
            Term(op, tuple(e[1] for e in eqs), descriptor),
        )
    raise AssertionError("unknown proof rule: " + p.rule)


# Untrusted certificate-building conveniences. Their results are checked above.
def refl(t: Term) -> Proof:
    return Proof("refl", t)


def ax(name: str, **sigma: Term) -> Proof:
    return Proof("axiom", (name, sigma))


def sym(p: Proof) -> Proof:
    return Proof("sym", None, (p,))


def chain(*ps: Proof) -> Proof:
    assert ps
    result = ps[0]
    for p in ps[1:]:
        result = Proof("trans", None, (result, p))
    return result


def cg(op: str, *ps: Proof, descriptor: Term | None = None) -> Proof:
    return Proof("cong", (op, descriptor), tuple(ps))


def lift(template: Term, replacements: dict[str, Proof]) -> Proof:
    if template.op.startswith("var:"):
        return replacements.get(template.op[4:], refl(template))
    return cg(
        template.op,
        *(lift(t, replacements) for t in template.args),
        descriptor=template.descriptor,
    )


def cancel_successor(p: Proof, left: Term, right: Term) -> Proof:
    # This is a proof builder, NOT a trusted cancellation rule.
    return chain(
        sym(ax("QS", n=left, a=ZERO)),
        cg("rec", p, refl(ZERO), descriptor=var("w")),
        ax("QS", n=right, a=ZERO),
    )


def f_zero(t: Term) -> Proof:
    """F(0,t)=B(St,0), entirely from four computation axioms."""
    return cg(
        "B",
        ax("Q0", a=S(t)),
        chain(
            cg("rec", ax("Z0", a=S(ZERO)), refl(S(t)), descriptor=var("w")),
            ax("QS", n=ZERO, a=S(t)),
        ),
    )


def f_successor(b: Term, t: Term) -> Proof:
    """F(Sb,t)=B(b,St), entirely from four computation axioms."""
    return cg(
        "B",
        ax("QS", n=b, a=S(t)),
        chain(
            cg("rec", ax("ZS", n=b, a=S(ZERO)), refl(S(t)), descriptor=var("w")),
            ax("Q0", a=S(t)),
        ),
    )


def eta_certificate() -> Proof:
    t = B(L(x), R(x))
    same_successor = chain(
        ax("J", x=t),
        lift(F(a, n), {
            "a": ax("PR_left", a=L(x), n=R(x)),
            "n": ax("PR_right", a=L(x), n=R(x)),
        }),
        sym(ax("J", x=x)),
    )
    return cancel_successor(same_successor, t, x)


def horizontal_certificate() -> Proof:
    return chain(
        ax("J", x=B(S(a), n)),
        lift(F(var("u"), var("v")), {
            "u": ax("PR_left", a=S(a), n=n),
            "v": ax("PR_right", a=S(a), n=n),
        }),
        f_successor(a, n),
    )


def vertical_certificate() -> Proof:
    return chain(
        ax("J", x=B(ZERO, n)),
        lift(F(a, var("v")), {
            "a": ax("PR_left", a=ZERO, n=n),
            "v": ax("PR_right", a=ZERO, n=n),
        }),
        f_zero(n),
    )


def converse_zero_certificate() -> Proof:
    hypothesis = Proof("hyp", 0)  # Lx=0
    route = chain(
        cg("S", sym(ax("PE", x=x))),
        cg("S", cg("B", hypothesis, refl(R(x)))),
        ax("PV", n=R(x)),
    )
    rhs = chain(
        lift(F(a, n), {"a": hypothesis, "n": refl(R(x))}),
        f_zero(R(x)),
    )
    return chain(route, sym(rhs))


def converse_successor_certificate() -> Proof:
    hypothesis = Proof("hyp", 0)  # Lx=Sa
    route = chain(
        cg("S", sym(ax("PE", x=x))),
        cg("S", cg("B", hypothesis, refl(R(x)))),
        ax("PH", a=a, n=R(x)),
    )
    rhs = chain(
        lift(F(var("u"), n), {"u": hypothesis, "n": refl(R(x))}),
        f_successor(a, R(x)),
    )
    return chain(route, sym(rhs))


def collapse_certificate() -> Proof:
    # Under Sx=0, derive 0=S0. Sep then gives the contradiction in IQC.
    def x_equals(t: Term) -> Proof:
        return chain(
            sym(ax("QS", n=x, a=t)),
            cg("rec", Proof("hyp", 0), refl(t), descriptor=var("w")),
            ax("Q0", a=t),
        )
    return chain(sym(x_equals(ZERO)), x_equals(S(ZERO)))


def proof_nodes(p: Proof) -> int:
    return 1 + sum(map(proof_nodes, p.children))


def axioms_used(p: Proof) -> set[str]:
    names = {p.data[0]} if p.rule == "axiom" else set()
    for c in p.children:
        names |= axioms_used(c)
    return names


def encode(item: Any) -> Any:
    if isinstance(item, Term):
        data = {"op": item.op, "args": [encode(t) for t in item.args]}
        if item.descriptor is not None:
            data["descriptor"] = encode(item.descriptor)
        return data
    if isinstance(item, Proof):
        return {"rule": item.rule, "data": encode(item.data),
                "children": [encode(p) for p in item.children]}
    if isinstance(item, (tuple, list)):
        return [encode(t) for t in item]
    if isinstance(item, dict):
        return {k: encode(v) for k, v in item.items()}
    return item


def equation_size(eq: Equation) -> int:
    return 1 + term_size(eq[0]) + term_size(eq[1])


def counts() -> dict[str, int]:
    j = equation_size(AXIOMS["J"]) + 1
    pr = equation_size(AXIOMS["PR_left"]) + equation_size(AXIOMS["PR_right"]) + 1 + 2
    pe = equation_size(AXIOMS["PE"]) + 1
    ph = equation_size(AXIOMS["PH"]) + 2
    pv = equation_size(AXIOMS["PV"]) + 1
    qz = sum(equation_size(AXIOMS[key]) + binders
             for key, binders in (("Q0", 1), ("QS", 2), ("Z0", 1), ("ZS", 2)))
    old_common = (pe - 1) + (ph - 2) + (pv - 1) + (pr - 2) + 3 + 2
    new_common = (j - 1) + (pr - 2) + 1 + 2
    result = {"J": j, "PR": pr, "PE": pe, "PH": ph, "PV": pv,
              "QZ_protected_support": qz, "old_separate_kernel": pe + ph + pv + pr,
              "old_common_prefix_kernel": old_common, "new_separate_kernel": j + pr,
              "new_common_prefix_kernel": new_common,
              "old_kernel_and_QZ": pe + ph + pv + pr + qz,
              "new_kernel_and_QZ": j + pr + qz}
    assert result == {"J": 23, "PR": 15, "PE": 8, "PH": 12, "PV": 10,
                      "QZ_protected_support": 32, "old_separate_kernel": 45,
                      "old_common_prefix_kernel": 44, "new_separate_kernel": 38,
                      "new_common_prefix_kernel": 38,
                      "old_kernel_and_QZ": 77, "new_kernel_and_QZ": 70}
    return result


def numerical_diagnostics() -> dict[str, int]:
    def triangle(k: int) -> int:
        return k * (k + 1) // 2

    def pair(a: int, n: int) -> int:
        return triangle(a + n) + n

    def coordinates(z: int) -> tuple[int, int]:
        k = (isqrt(8 * z + 1) - 1) // 2
        right = z - triangle(k)
        return k - right, right

    def q(n: int, a: int) -> int:
        return a if n == 0 else n - 1

    def zfun(n: int, a: int) -> int:
        return a if n == 0 else 0

    pair_checks = 0
    for a in range(33):
        for n in range(33):
            assert coordinates(pair(a, n)) == (a, n)
            assert pair(a + 1, n) + 1 == pair(a, n + 1)
            pair_checks += 1
    for z in range(4096):
        left, right = coordinates(z)
        assert pair(left, right) == z
        assert z + 1 == pair(q(left, right + 1), q(zfun(left, 1), right + 1))
        next_right = coordinates(z + 1)[1]
        assert next_right == 0 or next_right == right + 1
    return {"beta_and_horizontal_grid_points": pair_checks,
            "master_eta_reset_values": 4096}


def main() -> None:
    tasks = [
        ("successor_injectivity", ((S(x), S(y)),), QZ,
         (x, y), cancel_successor(Proof("hyp", 0), x, y)),
        ("successor_zero_implies_0_equals_S0", ((S(x), ZERO),), QZ,
         (ZERO, S(ZERO)), collapse_certificate()),
        ("eta_from_new_kernel", (), NEW, AXIOMS["PE"], eta_certificate()),
        ("horizontal_from_new_kernel", (), NEW, AXIOMS["PH"], horizontal_certificate()),
        ("vertical_from_new_kernel", (), NEW, AXIOMS["PV"], vertical_certificate()),
        ("master_from_old_when_Lx_zero", ((L(x), ZERO),), OLD,
         AXIOMS["J"], converse_zero_certificate()),
        ("master_from_old_when_Lx_successor", ((L(x), S(a)),), OLD,
         AXIOMS["J"], converse_successor_certificate()),
    ]
    lines = ["FINITE EQUATIONAL CERTIFICATE CHECK", "===================================",
             "Seven finite derivations; no induction or iPRA metatheorem is machine-certified.",
             "Each converse case retains its displayed equality hypothesis.",
             "Coverage combines the converse cases in the written intuitionistic proof.", ""]
    certificates = []
    for name, hypotheses, allowed, expected, proof in tasks:
        actual = check(proof, hypotheses, allowed)
        assert actual == expected, name + ": unexpected conclusion"
        used = sorted(axioms_used(proof))
        context = "; ".join(show(l) + "=" + show(r) for l, r in hypotheses) or "none"
        lines.extend([
            name + ": PASS",
            "  Hypotheses: " + context,
            "  Conclusion: " + show(actual[0]) + " = " + show(actual[1]),
            "  Axioms used: " + ", ".join(used),
            "  Proof-tree nodes: " + str(proof_nodes(proof)),
        ])
        certificates.append({"name": name, "hypotheses": encode(hypotheses),
                             "allowed_axioms": sorted(allowed), "conclusion": encode(actual),
                             "proof": encode(proof)})
    # Confirm the kernel rejects an invalid transitivity application.
    malformed = chain(refl(ZERO), refl(S(ZERO)))
    try:
        check(malformed, (), NEW)
    except AssertionError:
        lines.append("Malformed transitivity proof rejected: PASS")
    else:
        raise AssertionError("checker accepted malformed transitivity")
    # Recursor-descriptor substitution must remain frozen.
    assert subst(Q(var("w"), a), {"w": S(ZERO)}) == Q(S(ZERO), a)
    lines.extend(["Frozen-descriptor substitution: PASS", "", "EXACT FULL-TREE COUNTS"])
    count_data = counts()
    for key, value in count_data.items():
        lines.append("  " + key + ": " + str(value))
    lines.extend(["", "BOUNDED STANDARD-N DIAGNOSTICS (not proof certificates)"])
    for key, value in numerical_diagnostics().items():
        lines.append("  " + key + ": " + str(value) + " checked")
    payload = {"scope": "finite local equational replacement only",
               "axioms": encode(AXIOMS), "certificates": certificates, "counts": count_data}
    serialized = json.dumps(payload, sort_keys=True, indent=2) + "\n"
    digest = sha256(serialized.encode()).hexdigest()
    lines.extend(["", "Certificate JSON SHA-256: " + digest,
                  "General induction transfer, canonicality, and bi-interpretability:",
                  "proved in the written report; not checked by this program.", ""])
    out = Path(__file__).resolve().parents[1] / "verification"
    out.mkdir(parents=True, exist_ok=True)
    (out / "pairing_certificate.json").write_text(serialized)
    text = "\n".join(lines)
    (out / "pairing_certificate.txt").write_text(text)
    print(text)


if __name__ == "__main__":
    main()
