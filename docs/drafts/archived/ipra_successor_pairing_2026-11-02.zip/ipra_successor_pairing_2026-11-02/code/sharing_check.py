#!/usr/bin/env python3
"""Exact AST checks for the report's explicit first-order sharing transforms.

This checks syntactic sizes and the finite minimizer on the displayed examples.
It is not a machine formalization of the intuitionistic metatheorems. Frozen
recursor descriptors are charged in full and are never substitution targets.
Run from any working directory; JSON is printed to standard output.
"""
from __future__ import annotations

import json
from collections import Counter
from functools import lru_cache
from itertools import combinations


def V(name):
    return ("var", name)


ZERO = ("zero",)


def S(t):
    return ("fun", "S", (t,))


def Fun(name, *args):
    return ("fun", name, tuple(args))


def Rec(h, n, a):
    return ("rec", h, n, a)


def Eq(s, t):
    return ("eq", s, t)


def And(a, b):
    return ("and", a, b)


def Imp(a, b):
    return ("imp", a, b)


def K4(a, b, c, d):
    return ("k4", a, b, c, d)


def K3(a, b, c):
    return ("k3", a, b, c)


def All(name, body):
    return ("all", name, body)


def Exists(name, body):
    return ("exists", name, body)


def Forall(names, body):
    for name in reversed(names):
        body = All(name, body)
    return body


@lru_cache(None)
def tsize(t):
    tag = t[0]
    if tag in {"var", "zero"}:
        return 1
    if tag == "fun":
        return 1 + sum(map(tsize, t[2]))
    if tag == "rec":
        return 1 + tsize(t[1]) + tsize(t[2]) + tsize(t[3])
    raise ValueError(tag)


@lru_cache(None)
def fsize(f):
    tag = f[0]
    if tag == "eq":
        return 1 + tsize(f[1]) + tsize(f[2])
    if tag in {"all", "exists"}:
        return 1 + fsize(f[2])
    if tag in {"and", "or", "imp", "k3", "k4"}:
        return 1 + sum(map(fsize, f[1:]))
    if tag == "bottom":
        return 1
    raise ValueError(tag)


def children(t):
    if t[0] == "fun":
        return t[2]
    if t[0] == "rec":
        return t[2:4]  # Stored descriptor t[1] is deliberately frozen.
    return ()


@lru_cache(None)
def tfree(t):
    if t[0] == "var":
        return frozenset([t[1]])
    return frozenset().union(*(tfree(c) for c in children(t)))


def ffree(f):
    if f[0] == "eq":
        return tfree(f[1]) | tfree(f[2])
    if f[0] in {"all", "exists"}:
        return ffree(f[2]) - {f[1]}
    return frozenset().union(*(ffree(c) for c in f[1:]))


def replace_term(t, replacements):
    if t in replacements:
        return replacements[t]
    if t[0] == "fun":
        return Fun(t[1], *(replace_term(c, replacements) for c in t[2]))
    if t[0] == "rec":
        return Rec(t[1], replace_term(t[2], replacements),
                   replace_term(t[3], replacements))
    return t


def replace_formula(f, replacements):
    if f[0] == "eq":
        return Eq(replace_term(f[1], replacements),
                  replace_term(f[2], replacements))
    if f[0] in {"all", "exists"}:
        # Alpha-renaming is assumed; nevertheless reject capture explicitly.
        usable = {t: u for t, u in replacements.items()
                  if f[1] not in tfree(t) and f[1] not in tfree(u)}
        return (f[0], f[1], replace_formula(f[2], usable))
    return (f[0], *(replace_formula(c, replacements) for c in f[1:]))


def active_subterms(f):
    """First-occurrence postorder, keeping only terms available at this scope."""
    available = ffree(f)
    result = []
    seen = set()

    def visit_term(t):
        for child in children(t):
            visit_term(child)
        if t[0] != "var" and tfree(t) <= available and t not in seen:
            seen.add(t)
            result.append(t)

    def visit_formula(g):
        if g[0] == "eq":
            visit_term(g[1])
            visit_term(g[2])
        elif g[0] in {"all", "exists"}:
            visit_formula(g[2])
        else:
            for child in g[1:]:
                visit_formula(child)

    visit_formula(f)
    return result


def factor(f, selected):
    replacements = {}
    definitions = []
    occupied = set(ffree(f))
    for i, term in enumerate(selected):
        name = "let_" + str(i)
        assert name not in occupied
        value = replace_term(term, replacements)
        definitions.append((name, value))
        replacements[term] = V(name)
    body = replace_formula(f, replacements)
    for name, value in reversed(definitions):
        body = Exists(name, And(Eq(V(name), value), body))
    return body


def exact_scope_minimum(f):
    terms = active_subterms(f)
    best = fsize(f)
    best_selection = ()
    considered = 0
    for count in range(len(terms) + 1):
        for indexes in combinations(range(len(terms)), count):
            considered += 1
            candidate = factor(f, [terms[i] for i in indexes])
            value = fsize(candidate)
            if (value, count, indexes) < (best, len(best_selection), best_selection):
                best = value
                best_selection = indexes
    return best, best_selection, considered


v, w, a, x, n = map(V, ("v", "w", "a", "x", "n"))
one = S(ZERO)
Q = lambda n, a: Rec(w, n, a)
Z = lambda n, a: Rec(ZERO, n, a)
A = lambda n, a: Rec(S(v), n, a)
add = lambda a, n: A(n, a)
d_body = Q(v, ZERO)
d = lambda a, n: Rec(d_body, n, a)
tri_body = add(v, S(w))
T = lambda n: Rec(tri_body, n, ZERO)
lambda_body = add(v, Z(d(T(S(v)), S(w)), one))
lam = lambda n: Rec(lambda_body, n, ZERO)


def seed_checks():
    assert [tsize(t) for t in (w, ZERO, S(v), d_body, tri_body, lambda_body)] == [1, 1, 2, 4, 6, 25]
    t = add(a, x)
    equations = (Eq(d(t, x), a), Eq(d(a, t), ZERO),
                 Eq(lam(add(x, T(t))), t))
    assert list(map(fsize, equations)) == [13, 13, 50]
    separate = sum(fsize(Forall(("a", "x"), eq)) for eq in equations)
    matrix = And(equations[0], And(equations[1], equations[2]))
    combined = Forall(("a", "x"), matrix)
    shared = Forall(("a", "x"), factor(matrix, [t]))
    assert (separate, fsize(combined), fsize(shared)) == (82, 80, 73)
    return {"equation_sizes": list(map(fsize, equations)),
            "separate_closures": separate,
            "shared_quantifiers": fsize(combined),
            "scope_shared_packet": fsize(shared)}


def boundary_matrix(equation, witness):
    b = V(witness)
    return K4(Eq(S(x), b), equation, Eq(x, b), Eq(b, a))


def sharing_family():
    rows = []
    rx = Fun("R", x)
    la = Fun("L", a)
    t = la
    for m in range(1, 10):
        t = A(rx, t)
        assert tsize(t) == 5 * m + 2
        e0, e1 = Eq(t, la), Eq(t, S(la))
        atom0, _, _ = exact_scope_minimum(e0)
        atom1, _, _ = exact_scope_minimum(e1)
        assert atom0 == min(5 * m + 5, 4 * m + 11)
        assert atom1 == min(5 * m + 6, 4 * m + 12)
        old_total = atom0 + atom1 + 28
        matrix = And(boundary_matrix(e0, "b"), boundary_matrix(e1, "c"))
        # Four outer binders: forall a exists b exists c forall x.
        explicit = min(4 + fsize(factor(matrix, [t])),
                       4 + fsize(factor(matrix, [rx, t])))
        expected = min(5 * m + 42, 4 * m + 48)
        assert explicit == expected
        optimum, _, searched = exact_scope_minimum(matrix)
        optimum += 4
        assert optimum <= explicit < old_total
        if m >= 6:
            assert old_total == 8 * m + 51
            assert old_total - explicit == 4 * m + 3
        rows.append({"m": m, "term_size": tsize(t),
                     "old_atom_local_total": old_total,
                     "new_explicit_packet": explicit,
                     "new_scope_minimum": optimum,
                     "saving_at_least": old_total - explicit,
                     "scope_candidates_checked": searched})
    return rows


def alias_checks():
    h = Q(ZERO, S(v))
    g = S(v)
    H, G = tsize(h), tsize(g)
    alias = Forall(("a", "n"), Eq(Rec(h, n, a), Rec(g, n, a)))
    original_base = All("a", Eq(Rec(h, ZERO, a), a))
    evaluated = replace_term(h, {v: Rec(h, n, a), w: n})
    original_step = Forall(("a", "n"), Eq(Rec(h, S(n), a), evaluated))
    assert (H, G, fsize(alias)) == (5, 2, 16)
    assert fsize(original_base) + fsize(original_step) == 35
    assert fsize(alias) == H + G + 9
    identity_h = Q(ZERO, v)
    identity = Forall(("a", "n"), Eq(Rec(identity_h, n, a), a))
    assert tsize(identity_h) == 4
    assert fsize(identity) == tsize(identity_h) + 7 == 11
    # Active substitution does not modify either frozen descriptor.
    substituted = replace_term(Rec(h, n, a), {v: ZERO, w: one, n: ZERO})
    assert substituted[1] == h
    return {"original_descriptor_size": H,
            "normalized_descriptor_size": G,
            "ordinary_original_module": 35,
            "explicit_alias_module": fsize(alias),
            "normalized_identity_module": fsize(identity),
            "frozen_descriptor_substitution_check": True}


def nonvariable_occurrences(f):
    """Overapproximate sharing opportunities across all active formula scopes."""
    counts = Counter()

    def visit_term(t):
        if t[0] != "var":
            counts[t] += 1
        for child in children(t):
            visit_term(child)

    def visit_formula(g):
        if g[0] == "eq":
            visit_term(g[1])
            visit_term(g[2])
        elif g[0] in {"all", "exists"}:
            visit_formula(g[2])
        else:
            for child in g[1:]:
                visit_formula(child)

    visit_formula(f)
    return counts


def strict_normal_form(t):
    """Deterministic root-first strict-size-decreasing active computation."""
    def one_step(s):
        if s[0] == "rec":
            body, counter, initial = s[1:]
            candidates = []
            if counter == ZERO:
                candidates.append(initial)
            if counter[0] == "fun" and counter[1] == "S":
                before = counter[2][0]
                candidates.append(replace_term(body, {
                    v: Rec(body, before, initial), w: before}))
            if body == v:
                candidates.append(initial)
            for candidate in candidates:
                if tsize(candidate) < tsize(s):
                    return candidate, True
        old_children = children(s)
        for i, child in enumerate(old_children):
            changed_child, changed = one_step(child)
            if changed:
                new_children = list(old_children)
                new_children[i] = changed_child
                if s[0] == "rec":
                    return Rec(s[1], *new_children), True
                return Fun(s[1], *new_children), True
        return s, False

    while True:
        next_t, changed = one_step(t)
        if not changed:
            return t
        assert tsize(next_t) < tsize(t)
        t = next_t


def normalized_fold_family():
    """Strict mixed-body improvement beyond raw candidates plus Alias."""
    rows = []
    u, y = V("u"), V("y")
    selector = lambda n, a, body: Q(Z(n, S(a)), body)
    dagger = lambda h, previous, counter, successor: replace_term(
        h, {S(w): successor, v: previous, w: counter})

    for q in (1, 2, 3, 5, 10, 50):
        m = q + 5
        g = ZERO
        for _ in range(m):
            g = A(S(w), g)
        h = g
        for _ in range(q):
            h = Q(ZERO, h)
        H, G = tsize(h), tsize(g)
        assert (H, G) == (8 * q + 26, 5 * q + 26)
        assert strict_normal_form(h) == g
        assert strict_normal_form(g) == g
        assert tfree(h) == tfree(g) == frozenset({"w"})

        previous = Rec(h, n, a)
        evaluated = replace_term(h, {v: previous, w: n})
        evaluated_u = replace_term(h, {v: u, w: n})
        base = All("a", Eq(Rec(h, ZERO, a), a))
        step_matrix = Eq(Rec(h, S(n), a), evaluated)
        direct = (base, Forall(("a", "n"), step_matrix))
        graph3_matrix = K3(And(Eq(n, ZERO), Eq(u, a)),
                           Eq(previous, u),
                           Eq(Rec(h, S(n), a), evaluated_u))
        graph0_matrix = Imp(Eq(previous, u),
                            And(Imp(Eq(n, ZERO), Eq(u, a)),
                                Eq(Rec(h, S(n), a), evaluated_u)))
        table4 = Forall(("a", "n"), Exists("u", And(
            Imp(Eq(n, ZERO), Eq(u, a)),
            Forall(("x", "y"), K4(
                And(Eq(x, n), Eq(y, u)), Eq(Rec(h, x, a), y),
                Eq(x, S(n)), Eq(y, dagger(h, u, n, x)))))))
        pred = Q(n, ZERO)
        fold = Forall(("a", "n"), Eq(
            previous, selector(n, a, dagger(h, Rec(h, pred, a), pred, n))))
        let_fold = Forall(("a", "n", "u"), Imp(Eq(pred, u), Eq(
            previous, selector(n, a, dagger(h, Rec(h, u, a), u, n)))))
        endpoint4 = Forall(("a", "n"), Exists("u", Forall(("x", "y"), K4(
            And(Eq(S(x), n), Eq(y, u)), Eq(Rec(h, x, a), y), Eq(x, n),
            Eq(y, selector(n, a, dagger(h, u, ZERO, n)))))))
        alias = Forall(("a", "n"), Eq(previous, Rec(g, n, a)))
        mixed = Forall(("a", "n"), Eq(
            previous, selector(n, a, dagger(g, Rec(h, pred, a), pred, n))))

        raw = {
            "D": sum(map(fsize, direct)),
            "G3": fsize(Forall(("a", "n", "u"), graph3_matrix)),
            "G0": fsize(Forall(("a", "n", "u"), graph0_matrix)),
            "T4": fsize(table4), "F": fsize(fold), "L": fsize(let_fold),
            "N4": fsize(endpoint4), "Alias": fsize(alias)}
        expected = {"D": 24*q+91, "G3": 24*q+99, "G0": 24*q+100,
                    "T4": 15*q+79, "F": 15*q+60, "L": 15*q+68,
                    "N4": 15*q+78, "Alias": 13*q+61}
        assert raw == expected

        # The winning candidates have no repeated nonvariable active term
        # except the one-node constant0, which no explicit let can compress.
        for formula in (fold, alias, mixed, table4, let_fold, endpoint4):
            repetitions = {term: count for term, count in
                           nonvariable_occurrences(formula).items() if count > 1}
            assert all(term == ZERO for term in repetitions)
        # D/G can share repeated S(n), saving exactly q nodes here. This is
        # already granted to the comparator rather than ignored.
        for matrix in (step_matrix, graph3_matrix, graph0_matrix):
            repetitions = {term: count for term, count in
                           nonvariable_occurrences(matrix).items() if count > 1}
            assert set(repetitions) <= {ZERO, S(n)}
            assert repetitions[S(n)] == m + 1
            assert fsize(matrix) - fsize(factor(matrix, [S(n)])) == q
        after_sharing = dict(raw)
        for key in ("D", "G3", "G0"):
            after_sharing[key] -= q
        assert min(after_sharing.values()) == raw["Alias"] == 13*q+61
        assert fsize(mixed) == H+G-m+13 == 12*q+60
        assert min(after_sharing.values()) - fsize(mixed) == q + 1
        rows.append({"q": q, "m": m, "H": H, "G": G,
                     "raw_fold": raw["F"],
                     "old_best_with_alias_and_sharing": min(after_sharing.values()),
                     "mixed_fold": fsize(mixed), "saving": q+1})
    return rows


def main():
    data = {"status": "all assertions passed",
            "scope": "exact syntax counts and finite optimizer checks; not a formal proof of the metatheorem",
            "seed_packet": seed_checks(),
            "boundary_family": sharing_family(),
            "normalized_alias": alias_checks(),
            "normalized_fold_family": normalized_fold_family()}
    print(json.dumps(data, indent=2))


if __name__ == "__main__":
    main()
