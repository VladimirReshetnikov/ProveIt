A SMALLER PAIRING CORE FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov -- 2 November 2026 (Pacific time)

START HERE
----------
report.pdf is the complete 21-page mathematical report.
report.tex and sections/*.tex are its complete LaTeX source.
AXIOMS.txt is the compact independent specification.

MAIN RESULTS
------------
1. Replace the old native-pairing eta and routing clauses by one
   successor equation, retaining the two projection retractions.
   Pairing costs 38 rather than 45 nodes (44 after old prefix sharing).
   Matched pairing plus already-required Q/Z computations: 70 versus77
   (or76 after old prefix sharing). No induction is needed for this
   replacement. Every stored recursor description is fully charged.
2. Restrict both variables of diagonal boundary indices to their native
   projections: every active x inside R(x), every active a inside L(a).
   Full contextual equation induction still follows by the lift E(Rx,La).
3. Include the best recursion modules of all four current drafts. Normalize
   evaluated updates while retaining and paying for the original stored
   recursor label. An explicit family improves13q+61 to12q+60.
4. Share terms across legal formula scopes with explicit quantified
   equations. A finite-export family improves8m+51 to4m+48; the older
   three-seed bundle independently improves80 to73 in its own signature.
5. Both whole-carrier intuitionistic interpretations and both internal
   identity round trips are proved. Genuine falsity is retained.

WHAT IS AND IS NOT MINIMIZED
---------------------------
The report uses the source drafts' full-tree size metric, charges logical
definition records and numerical support, and distinguishes infinite schemes
from finite blocks. It gives strict improvements and nonincrease relative
to the surviving local candidate envelope. It does not prove an absolute
shortestness theorem across arbitrary languages/logics, or a reduction in
every possible finite proof's length. No arithmetic or classical principle
is hidden in the chain connectives.

AUDITED SOURCES
---------------
Repository: VladimirReshetnikov/ProveIt
Snapshot: 85560eb1cf1cdc96767951e3317716392e5c5496
Last observed drafts-changing commit:
44d32ed7bce61b58f6a28c03979cc95dd935acf7

Four current archives and five immediately archived archives were read.
All four current packages have genuine improvements over the prior
iteration. Dominated components, rather than entire useful packages,
are discarded. provenance/sources.json records exact source paths,
byte counts, Git blob hashes, SHA-256 hashes, and pinned URLs.
The original comparison archives are not duplicated in this deliverable.

VERIFICATION
------------
Run with Python3.10 or later, using only the standard library:

    python3 code/pairing_certificate.py
    python3 code/sharing_check.py > verification/sharing_check.json

The first command checks seven finite equational derivations in a small
explicit kernel. Its full proof trees and exact counts are written under
verification/. Numerical diagnostics are separately identified.
The second checks AST sizes and finite exact sharing examples, including
the two unbounded saving families. The full infinite axiom generator,
induction transfer, and bi-interpretability theorem have written proofs;
they are not fully machine-formalized in Lean or Rocq.

REBUILD THE PDF
---------------
Run from this directory:

    bash build.sh

Requires latexmk, pdflatex, and the usual TeX Live packages listed in
report.tex (including lmodern, amsmath, amsthm, mathtools, microtype,
booktabs, enumitem, hyperref, and fancyhdr). No bibliography download or
external source checkout is needed. Rebuilding writes temporary files
under build/ and copies the completed PDF to report.pdf.

CONTENTS
--------
report.pdf, report.tex, sections/       Complete report and source
AXIOMS.txt                             Compact complete specification
code/                                  Reproducible finite checks
verification/                          Check outputs and proof certificates
provenance/                            Source identities and comparison audit
build.sh                               PDF rebuild command
SHA256SUMS.txt                         Integrity hashes for delivered files

The report includes a Further research questions section.
