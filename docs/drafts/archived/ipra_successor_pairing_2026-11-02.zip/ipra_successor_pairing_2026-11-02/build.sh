#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build verification
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build report.tex > verification/latex_build.txt 2>&1
cp build/report.pdf report.pdf
