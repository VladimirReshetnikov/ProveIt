PRA WITHOUT AUXILIARY MASKS: A FUSED BOUNDARY EQUATION
Prepared for Vladimir Reshetnikov, 2 November 2026

READ FIRST
  pra_fused_boundary.pdf  Complete research manuscript.
  report.tex             Main LaTeX source; sections/ contains its chapters.

MAIN RESULT
  A recursion-only staged language with primitives 0,S,chi is enough.
  Fixed axioms: 0 != S0 and forall x y (x=y or chi(x,y)=0).
  Every R_h has R_h(0,a)=a and R_h(Sn,a)=h(R_h(n,a),n).
  Write Q=R_w, Z=R_0. For each finite earlier two-slot term t, use

  forall a n exists b:
    chi(b,Q(Z(t(Sb,a),Sb),n)) = S(Z(t(b,a),b)).

  The schema recovers the omitted diagonal chi(x,x)=S0 through t(x,a)=a.
  The manuscript proves a common conservative definitional extension with
  first-order PRA, including all finite parameter tuples and identity
  round trips. This holds separately in classical and intuitionistic logic.

PRECISE SIMPLICITY CLAIM
  With active/full tail sizes m,T and i active first-slot occurrences,
  the complete new induction module costs 2m+i+14 / 2T+i+17.
  The strongest currently disclosed named-mask module costs m+20 / 4T+22.
  Full size therefore decreases by 2T-i+5 >= T+5 for every matched tail.
  Active-only size does not uniformly decrease. Full definitions and
  frozen descriptors are charged; common earlier arithmetic is retained.

  Fixed seed: 17 nodes. The one-time normalization instance costs 16 active
  and 19 full. The equivalent saturated presentation retains the redundant
  7-node diagonal law, yielding the same 24-node seed as the comparison.
  The manuscript charges the bootstrap when comparing minimal-seed finite
  supports. It makes no encoding-independent shortestness claim and no
  claim to beat tautological serializer outputs at each address.

VERIFICATION
  python3 checks/check_fused.py
  lean formal/FusedBoundary.lean          (Lean 4.19.0, bundled Std)
  python3 build.py                       (pdflatex required)

  formal/verification.txt records successful compilation and thirteen
  theorem dependency checks with no axioms. This formalizes local kernels,
  not the entire first-order syntax or bi-interpretation metatheorem.
  verification/checks.json records finite AST and witness checks.
  sources.json identifies the six inspected input archives at commit
  4d5474f10e00412135d659dc7a1f74fc6457656a.

CONTENTS AND SCOPE
  The ZIP includes the complete PDF, all LaTeX sources, the Lean kernel
  proof, the independent Python checker, build instructions and provenance.
  Source archives and compiler binaries are not duplicated.
  Optional successor sharing and single-copy evaluation-table schemes are
  proved equivalent in section 7; their exact counts are checked by Python.

  No repository changes, commits, or pull requests were made by this work.
