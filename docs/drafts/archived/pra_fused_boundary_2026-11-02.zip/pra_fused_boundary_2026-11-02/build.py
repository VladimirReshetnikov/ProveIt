#!/usr/bin/env python3
"""Compile the complete manuscript; only standard Python and TeX are needed."""
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
build_dir = root / "build"
build_dir.mkdir(exist_ok=True)
(root / "verification").mkdir(exist_ok=True)
if shutil.which("pdflatex") is None:
    raise SystemExit("pdflatex is required (TeX Live or MiKTeX with standard packages).")
for run in range(3):
    proc = subprocess.run(
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
         "-file-line-error", "-output-directory=" + str(build_dir), "report.tex"],
        cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
    )
    (root / "verification" / "build.txt").write_text(proc.stdout)
    if proc.returncode:
        print(proc.stdout[-16000:])
        raise SystemExit(proc.returncode)
log = (build_dir / "report.log").read_text(errors="replace")
warnings = [line for line in log.splitlines()
            if any(s in line for s in ("Overfull", "Undefined", "undefined",
                                       "LaTeX Warning", "Package hyperref Warning"))]
shutil.copyfile(build_dir / "report.pdf", root / "pra_fused_boundary.pdf")
print("Compiled pra_fused_boundary.pdf")
if warnings:
    print("Warnings:\n" + "\n".join(warnings))
else:
    print("No overfull boxes, unresolved references, or LaTeX warnings.")
