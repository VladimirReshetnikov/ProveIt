#!/usr/bin/env python3
"""Finite audits for the fused PRA schema.

The AST ledger counts quantifiers, connectives, equality, applications,
variables, and constants as one node each. Frozen descriptors are charged at
every generated application in full size, and never substituted into.
Finite standard-model tests are checks, not a proof for arbitrary models.
"""

from dataclasses import dataclass
from itertools import product
import json
import random


@dataclass(frozen=True)
class Node:
    name: str
    args: tuple = ()
    descriptor: object = None


def V(name):
    return Node("var:" + name)


ZERO = Node("0")


def S(x):
    return Node("S", (x,))


def Q(x, y):
    return Node("Q", (x, y), V("w"))


def Z(x, y):
    return Node("Z", (x, y), ZERO)


def Chi(x, y):
    return Node("chi", (x, y))


def EQ(x, y):
    return Node("=", (x, y))


def ALL(name, body):
    return Node("forall:" + name, (body,))


def EX(name, body):
    return Node("exists:" + name, (body,))


def AND(left, right):
    return Node("and", (left, right))


def OR(left, right):
    return Node("or", (left, right))


def IMPLIES(left, right):
    return Node("implies", (left, right))


def active(x):
    return 1 + sum(active(a) for a in x.args)


def full(x):
    return 1 + sum(full(a) for a in x.args) + (
        full(x.descriptor) if x.descriptor is not None else 0
    )


def occurrences(x, name):
    return int(x.name == "var:" + name) + sum(
        occurrences(a, name) for a in x.args
    )


def substitute(x, env):
    if x.name.startswith("var:"):
        return env.get(x.name[4:], x)
    return Node(x.name, tuple(substitute(a, env) for a in x.args), x.descriptor)


def at(t, first, second):
    return substitute(t, {"x": first, "a": second})


def fused(t):
    a, n, b = V("a"), V("n"), V("b")
    selector = Q(Z(at(t, S(b), a), S(b)), n)
    body = EQ(Chi(b, selector), S(Z(at(t, b, a), b)))
    return ALL("a", ALL("n", EX("b", body)))


def shared_successor(t):
    a, n, b, d = (V(k) for k in ("a", "n", "b", "d"))
    selector = Q(Z(at(t, d, a), d), n)
    kernel = EQ(Chi(b, selector), S(Z(at(t, b, a), b)))
    body = AND(EQ(d, S(b)), kernel)
    return ALL("a", ALL("n", EX("b", EX("d", body))))


def one_copy_table(t):
    a, n, b, r, s, x, y = (V(k) for k in ("a", "n", "b", "r", "s", "x", "y"))
    kernel = EQ(Chi(b, Q(Z(r, S(b)), n)), S(Z(s, b)))
    guard = OR(AND(EQ(x, b), EQ(y, s)), AND(EQ(x, S(b)), EQ(y, r)))
    table = ALL("x", ALL("y", IMPLIES(guard, EQ(at(t, x, a), y))))
    body = AND(kernel, table)
    return ALL("a", ALL("n", EX("b", EX("r", EX("s", body)))))


def old_block(t, whole_body=False, shifted=False):
    """The two clauses forming one direct-mask implementation block."""
    a, n, b, x = (V(k) for k in ("a", "n", "b", "x"))
    desc = Z(t, x) if whole_body else t

    def C(u, v):
        return Node("C", (u, v), desc)

    definition = ALL("x", ALL("a", EQ(C(x, a), Z(t, x))))
    inner_arg = S(b) if shifted else b
    witness = ALL("a", ALL("n", EX("b", EQ(C(Q(C(inner_arg, a), n), a), ZERO))))
    return definition, witness


def corpus():
    x, a = V("x"), V("a")
    terms = [x, a, ZERO, S(ZERO), S(x), Chi(x, a), Q(x, a), Z(a, x)]
    # Frozen descriptors containing their own copies of Q and Z, and their
    # formal variables, must not be changed by substituting the active x.
    for depth in range(1, 6):
        desc = Q(Z(V("v"), S(V("w"))), V("v"))
        for level in range(depth):
            desc = Node("R_nested_%s" % level, (V("v"), V("w")), desc)
        terms.extend([Node("R", (x, a), desc), Chi(Node("R", (x, x), desc), a)])
    rng = random.Random(20261102)
    for _ in range(600):
        left = rng.choice(terms[-120:])
        right = rng.choice(terms[-120:])
        if active(left) + active(right) > 500:
            left, right = x, a
        terms.append(rng.choice([Q, Z, Chi])(left, right))
    return terms


def syntax_checks():
    x, y = V("x"), V("y")
    separation = IMPLIES(EQ(ZERO, S(ZERO)), Node("false"))
    off = ALL("x", ALL("y", OR(EQ(x, y), EQ(Chi(x, y), ZERO))))
    diag = ALL("x", EQ(Chi(x, x), S(ZERO)))
    assert (active(separation), full(separation)) == (6, 6)
    assert (active(off), full(off)) == (11, 11)
    assert (active(diag), full(diag)) == (7, 7)
    assert (active(fused(V("a"))), full(fused(V("a")))) == (16, 19)
    cases = corpus()
    largest_active = largest_full = 0
    min_full_saving = None
    for t in cases:
        m, T, i = active(t), full(t), occurrences(t, "x")
        formula = fused(t)
        assert active(formula) == 2 * m + i + 14
        assert full(formula) == 2 * T + i + 17
        assert active(shared_successor(t)) == 2 * m + 19
        assert full(shared_successor(t)) == 2 * T + 22
        assert active(one_copy_table(t)) == m + 40
        assert full(one_copy_table(t)) == T + 43
        assert i <= m <= T
        for whole in (False, True):
            for shifted in (False, True):
                definition, witness = old_block(t, whole, shifted)
                assert active(definition) + active(witness) == m + 20 + int(shifted)
                expected_full = 4 * T + (31 if whole else 22) + int(shifted)
                old_full = full(definition) + full(witness)
                assert old_full == expected_full
                assert full(formula) < old_full
        savings = (4 * T + 22) - full(formula)
        assert savings == 2 * T - i + 5 and savings >= T + 5
        min_full_saving = savings if min_full_saving is None else min(min_full_saving, savings)
        largest_active = max(largest_active, m)
        largest_full = max(largest_full, T)
    return {
        "reduced_seed_active_and_full": 17,
        "saturated_seed_active_and_full": 24,
        "normalization_instance_active": 16,
        "normalization_instance_full": 19,
        "tails_checked": len(cases),
        "largest_tail_active": largest_active,
        "largest_tail_full": largest_full,
        "minimum_full_saving_against_best_12_node_block": min_full_saving,
        "example_x_equals_a": {
            "tail_active": active(Chi(V("x"), V("a"))),
            "tail_full": full(Chi(V("x"), V("a"))),
            "fused_active": active(fused(Chi(V("x"), V("a")))),
            "fused_full": full(fused(Chi(V("x"), V("a")))),
        },
    }


def natural_Q(x, a):
    return a if x == 0 else x - 1


def finite_masks(max_target=10):
    count = witness_checks = 0
    for bits in product((0, 1), repeat=max_target + 2):
        # bits[x] is the nonzeroness of a raw payload at x. The exact positive
        # value does not affect Z or the fused formula, so Boolean patterns
        # exhaust all zero/nonzero behaviours on this finite interval.
        def f(x):
            return 0 if bits[x] else x

        b = 0
        for n in range(max_target + 1):
            assert 0 <= b <= n
            assert f(b) == 0
            selector = natural_Q(f(b + 1), n)
            assert b == selector
            assert int(b == selector) == 1 + f(b)
            witness_checks += 1
            if n < max_target:
                b = natural_Q(f(b + 1), b + 1)
        count += 1
    packing_checks = 0
    for b, c, value in product(range(12), repeat=3):
        assert (int(b == c) == 1 + value) == (b == c and value == 0)
        packing_checks += 1
    return {
        "payload_zero_patterns": count,
        "targets_checked_per_pattern": max_target + 1,
        "fused_witness_checks": witness_checks,
        "packing_equivalence_checks": packing_checks,
    }


if __name__ == "__main__":
    print(json.dumps({
        "syntax": syntax_checks(),
        "finite_standard_model": finite_masks(),
        "status": "All finite checks passed; not a formal proof assistant verification.",
    }, indent=2))
