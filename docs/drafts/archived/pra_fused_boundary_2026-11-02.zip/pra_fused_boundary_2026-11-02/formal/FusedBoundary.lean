import Std

/-!
# Fused boundary witnesses: independently checked local kernels

This file adapts the arbitrary-carrier setup from the supplied draft
`pra_counterexample_masks_2026-11-02/formal/CounterexampleMasks.lean`.
The conjunction-packing lemma, fused induction transfer, and exact selector
climb recurrence below are the new arguments.

The forward proofs use an arbitrary carrier, with no carrier induction,
zero-or-successor coverage, choice, or unrestricted excluded middle.
The reverse proof uses induction on Nat and an explicit primitive recursion.
Its invariant is a conjunction of two equations, so its arithmetic analogue
is an instance of quantifier-free induction in PRA.

The higher-order variables are metatheoretic parameters. They are not function
quantifiers in the proposed first-order theory. This checks the local kernels;
it does not formalize the generated syntax, truth-term compiler, pairing,
primitive-recursive compiler, or full bi-interpretation theorem.
-/

namespace FusedBoundary

universe u

/-- The reduced computational seed. The equality bit has only its off-diagonal
clause; its diagonal normalization will follow from one fused-schema instance. -/
structure Seed (A : Type u) where
  zero : A
  succ : A → A
  Q : A → A → A
  Z : A → A → A
  chi : A → A → A
  separated : zero ≠ succ zero
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ n a, Q (succ n) a = n
  z_zero : ∀ a, Z zero a = a
  z_succ : ∀ n a, Z (succ n) a = zero
  chi_cases : ∀ a b, a = b ∨ chi a b = zero

/-- The convenient derived kernel, still with no coverage or induction field. -/
structure Kernel (A : Type u) extends Seed A where
  chi_diag : ∀ a, chi a a = succ zero

namespace Seed

variable {A : Type u} (K : Seed A)

/-- An off-diagonal bit clause and a positive witness in each column force
the missing diagonal normalization, constructively. -/
theorem recover_diagonal
    (hw : ∀ n, ∃ b, K.chi b n = K.succ K.zero) :
    ∀ n, K.chi n n = K.succ K.zero := by
  intro n
  obtain ⟨b, hb⟩ := hw n
  rcases K.chi_cases b n with he | hz
  · simpa only [he] using hb
  · exact False.elim (K.separated (hz.symm.trans hb))

/-- The raw fused instance with constant tail t(x)=S0 supplies the omitted
diagonal axiom. This proof uses no induction or equality-bit normalization. -/
theorem diagonal_from_constant_tail
    (hw : ∀ n, ∃ b,
      K.chi b (K.Q (K.Z (K.succ K.zero) (K.succ b)) n) =
        K.succ (K.Z (K.succ K.zero) b)) :
    ∀ n, K.chi n n = K.succ K.zero := by
  apply K.recover_diagonal
  intro n
  obtain ⟨b, hb⟩ := hw n
  rw [K.z_succ, K.q_zero, K.z_succ] at hb
  exact ⟨b, hb⟩

/-- The smaller raw tail t(x,a)=a suffices: specialize its parameter to S0.
This is the one-time normalization instance used by the reduced theory. -/
theorem diagonal_from_parameter_tail
    (hw : ∀ a n, ∃ b,
      K.chi b (K.Q (K.Z a (K.succ b)) n) = K.succ (K.Z a b)) :
    ∀ n, K.chi n n = K.succ K.zero := by
  exact K.diagonal_from_constant_tail (hw (K.succ K.zero))

/-- All later lemmas may use the derived diagonal law without adding an axiom. -/
def derivedKernel
    (hw : ∀ n, ∃ b,
      K.chi b (K.Q (K.Z (K.succ K.zero) (K.succ b)) n) =
        K.succ (K.Z (K.succ K.zero) b)) : Kernel A where
  toSeed := K
  chi_diag := K.diagonal_from_constant_tail hw

/-- The derived kernel obtained directly from the smaller parameter-tail
instance. Later proofs use its derived diagonal law, not an additional axiom. -/
def kernelFromParameterTail
    (hw : ∀ a n, ∃ b,
      K.chi b (K.Q (K.Z a (K.succ b)) n) = K.succ (K.Z a b)) : Kernel A where
  toSeed := K
  chi_diag := K.diagonal_from_parameter_tail hw

end Seed

namespace Kernel

variable {A : Type u} (K : Kernel A)

theorem succ_injective (x y : A) (h : K.succ x = K.succ y) : x = y := by
  have he := congrArg (fun z => K.Q z K.zero) h
  simpa only [K.q_succ] using he

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro h
  have hx : x = K.zero := by
    have he := congrArg (fun z => K.Q z K.zero) h
    simpa only [K.q_succ, K.q_zero] using he
  exact K.separated (h.symm.trans (congrArg K.succ hx))

/-- The equality bit packs two equations into one equation. -/
theorem packed_iff (x y r : A) :
    K.chi x y = K.succ r ↔ x = y ∧ r = K.zero := by
  constructor
  · intro h
    rcases K.chi_cases x y with he | hc
    · subst x
      have hs : K.succ r = K.succ K.zero :=
        h.symm.trans (K.chi_diag y)
      exact ⟨rfl, K.succ_injective r K.zero hs⟩
    · exact False.elim (K.succ_ne_zero r (h.symm.trans hc))
  · rintro ⟨he, hr⟩
    subst x
    subst r
    exact K.chi_diag y

/-- A pointwise mask is only a term abbreviation in the proposed theory. -/
def mask (t : A → A) (x : A) : A := K.Z (t x) x

theorem mask_of_true {P : A → Prop} {e : A → A}
    (htrue : ∀ x, P x → e x = K.succ K.zero) (x : A) (h : P x) :
    K.mask e x = K.zero := by
  unfold mask
  rw [htrue x h, K.z_succ]

theorem mask_of_false {P : A → Prop} {e : A → A}
    (hfalse : ∀ x, ¬P x → e x = K.zero) (x : A) (h : ¬P x) :
    K.mask e x = x := by
  unfold mask
  rw [hfalse x h, K.z_zero]

/-- Under the retained induction base, zero masks reflect their predicates. -/
theorem reflect_zero {P : A → Prop} {F : A → A}
    (pdec : ∀ x, P x ∨ ¬P x)
    (hfalse : ∀ x, ¬P x → F x = x)
    (hbase : P K.zero) (x : A) (hx : F x = K.zero) : P x := by
  rcases pdec x with hp | hn
  · exact hp
  · have he : x = K.zero := (hfalse x hn).symm.trans hx
    exact he.symm ▸ hbase

/-- The new fused principle implies induction on an arbitrary carrier.
The proof contains no induction, coverage, or range-invariant argument. -/
theorem fused_induction_transfer {P : A → Prop} {F : A → A}
    (pdec : ∀ x, P x ∨ ¬P x)
    (htrue : ∀ x, P x → F x = K.zero)
    (hfalse : ∀ x, ¬P x → F x = x)
    (hw : ∀ n, ∃ b,
      K.chi b (K.Q (F (K.succ b)) n) = K.succ (F b))
    (hbase : P K.zero)
    (hstep : ∀ x, P x → P (K.succ x)) : ∀ n, P n := by
  intro n
  obtain ⟨b, hb⟩ := hw n
  have hp := (K.packed_iff b (K.Q (F (K.succ b)) n) (F b)).mp hb
  have hpb : P b := K.reflect_zero pdec hfalse hbase b hp.2
  have hz : F (K.succ b) = K.zero := htrue (K.succ b) (hstep b hpb)
  have he : b = n := by
    have heq := hp.1
    rw [hz, K.q_zero] at heq
    exact heq
  exact he ▸ hpb

/-- Exactly the displayed raw schema after a numerical parameter is fixed. -/
theorem raw_fused_induction {P : A → Prop} {e : A → A}
    (pdec : ∀ x, P x ∨ ¬P x)
    (htrue : ∀ x, P x → e x = K.succ K.zero)
    (hfalse : ∀ x, ¬P x → e x = K.zero)
    (hw : ∀ n, ∃ b,
      K.chi b (K.Q (K.Z (e (K.succ b)) (K.succ b)) n) =
        K.succ (K.Z (e b) b))
    (hbase : P K.zero)
    (hstep : ∀ x, P x → P (K.succ x)) : ∀ n, P n := by
  exact K.fused_induction_transfer pdec (K.mask_of_true htrue)
    (K.mask_of_false hfalse) hw hbase hstep

end Kernel

namespace Seed

variable {A : Type u} (K : Seed A)

/-- Complete local transfer from the reduced seed: the diagonal normalization
is recovered from the parameter-tail instance, then used for the target tail.
No diagonal axiom is a hypothesis of this theorem. -/
theorem normalized_raw_fused_induction {P : A → Prop} {e : A → A}
    (hbootstrap : ∀ a n, ∃ b,
      K.chi b (K.Q (K.Z a (K.succ b)) n) = K.succ (K.Z a b))
    (pdec : ∀ x, P x ∨ ¬P x)
    (htrue : ∀ x, P x → e x = K.succ K.zero)
    (hfalse : ∀ x, ¬P x → e x = K.zero)
    (hw : ∀ n, ∃ b,
      K.chi b (K.Q (K.Z (e (K.succ b)) (K.succ b)) n) =
        K.succ (K.Z (e b) b))
    (hbase : P K.zero)
    (hstep : ∀ x, P x → P (K.succ x)) : ∀ n, P n := by
  exact (K.kernelFromParameterTail hbootstrap).raw_fused_induction
    pdec htrue hfalse hw hbase hstep

end Seed

namespace NatWitness

/-- Q(0,n)=n and Q(Sb,n)=b. -/
def selector : Nat → Nat → Nat
  | 0, n => n
  | Nat.succ b, _ => b

/-- Z(0,n)=n and Z(Sb,n)=0. -/
def zeroSelect : Nat → Nat → Nat
  | 0, n => n
  | Nat.succ _, _ => 0

/-- The exact equality bit in the standard natural-number interpretation. -/
def equalityBit (x y : Nat) : Nat := if x = y then 1 else 0

/-- The explicit primitive-recursive witness, using Q alone as its branch.
It advances while the next mask is zero and remains at a boundary otherwise. -/
def climb (F : Nat → Nat) : Nat → Nat
  | 0 => 0
  | Nat.succ n =>
      selector (F (Nat.succ (climb F n))) (Nat.succ (climb F n))

/-- The precise invariant is quantifier-free: just two equations. -/
theorem climb_invariant (F : Nat → Nat) (hzero : F 0 = 0)
    (hmarker : ∀ b, F (Nat.succ b) = 0 ∨ F (Nat.succ b) = Nat.succ b)
    (n : Nat) :
    F (climb F n) = 0 ∧
      climb F n = selector (F (Nat.succ (climb F n))) n := by
  induction n with
  | zero =>
      change F 0 = 0 ∧ 0 = selector (F (Nat.succ 0)) 0
      constructor
      · exact hzero
      · rcases hmarker 0 with hz | hs
        · rw [hz, selector]
        · rw [hs, selector]
  | succ n ih =>
      rcases hmarker (climb F n) with hz | hs
      · have he : climb F n = n := by
          have h := ih.2
          rw [hz, selector] at h
          exact h
        have hn : climb F (Nat.succ n) = Nat.succ n := by
          rw [climb, hz, selector, he]
        constructor
        · rw [hn]
          simpa only [he] using hz
        · rw [hn]
          rcases hmarker (Nat.succ n) with hzeroNext | hsuccNext
          · rw [hzeroNext, selector]
          · rw [hsuccNext, selector]
      · have hn : climb F (Nat.succ n) = climb F n := by
          rw [climb, hs, selector]
        constructor
        · rw [hn]
          exact ih.1
        · rw [hn, hs, selector]

/-- The explicit candidate satisfies the new packed equation. -/
theorem climb_is_fused_witness (F : Nat → Nat) (hzero : F 0 = 0)
    (hmarker : ∀ b, F (Nat.succ b) = 0 ∨ F (Nat.succ b) = Nat.succ b)
    (n : Nat) :
    equalityBit (climb F n) (selector (F (Nat.succ (climb F n))) n) =
      Nat.succ (F (climb F n)) := by
  have hi := climb_invariant F hzero hmarker n
  unfold equalityBit
  rw [if_pos hi.2, hi.1]

/-- Interpretation of the raw term Z(t(x),x). -/
def mask (t : Nat → Nat) (x : Nat) : Nat := zeroSelect (t x) x

theorem mask_zero (t : Nat → Nat) : mask t 0 = 0 := by
  unfold mask
  cases ht : t 0 <;> rfl

theorem mask_marker (t : Nat → Nat) (b : Nat) :
    mask t (Nat.succ b) = 0 ∨ mask t (Nat.succ b) = Nat.succ b := by
  unfold mask
  cases ht : t (Nat.succ b) with
  | zero => exact Or.inr rfl
  | succ k => exact Or.inl rfl

/-- Every raw tail has a fused witness, with the exact climb as its witness. -/
theorem every_raw_tail_has_fused_witness (t : Nat → Nat) (n : Nat) :
    ∃ b, equalityBit b (selector (zeroSelect (t (Nat.succ b)) (Nat.succ b)) n) =
      Nat.succ (zeroSelect (t b) b) := by
  exact ⟨climb (mask t) n,
    climb_is_fused_witness (mask t) (mask_zero t) (mask_marker t) n⟩

end NatWitness

#print axioms Seed.recover_diagonal
#print axioms Seed.diagonal_from_constant_tail
#print axioms Seed.diagonal_from_parameter_tail
#print axioms Kernel.succ_injective
#print axioms Kernel.succ_ne_zero
#print axioms Kernel.packed_iff
#print axioms Kernel.reflect_zero
#print axioms Kernel.fused_induction_transfer
#print axioms Kernel.raw_fused_induction
#print axioms Seed.normalized_raw_fused_induction
#print axioms NatWitness.climb_invariant
#print axioms NatWitness.climb_is_fused_witness
#print axioms NatWitness.every_raw_tail_has_fused_witness

end FusedBoundary
