# iPRA by shifted pairing

Research report prepared 2 November 2026 for Vladimir Reshetnikov.

## Main result

The numerical primitives are `0,S,U,L,R`, of arities `0,1,2,1,1`.
Four equations form a 36-node kernel under the reviewed drafts' full-tree
metric. Separation and coverage bring the fixed numerical support to 52;
the explicitly paid K4 definition makes the fixed record 67, versus 74 in
the strongest current helper-free draft. Infinite schemas and the common
intuitionistic calculus are not included in that finite number.

The report proves full first-order intuitionistic bi-interpretability and
equiconsistency, with whole-carrier domains, preserved genuine falsity,
and internally verified identity composites. It also eliminates every
state-free recursor declaration and supplies exact occurrence costs.

## Files

- `report.pdf`: complete 24-page report (pagination may vary on another TeX installation).
- `report.tex`, `sections/*.tex`: full LaTeX source.
- `AXIOMS.txt`: concise exact reference to the theory and its effective schemas.
- `code/check_kernel.py`: explicit equational certificate generator and independent replay.
- `code/check_examples.py`: finite arithmetic/scan diagnostics and independent syntax counts.
- `verification/`: saved certificates, results, and validation summaries.
- `provenance/sources.json`: all five current and four archived source identities.

## Reproduce

Run from this directory, with Python 3.10+ and a normal TeX Live installation:

```sh
python3 code/check_kernel.py
python3 code/check_kernel.py --check verification/kernel_certificates.json
python3 code/check_examples.py
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
```

The Python scripts use the standard library only. The LaTeX source uses
common packages: amsmath, amssymb, amsthm, mathtools, geometry, lmodern,
microtype, booktabs, array, longtable, enumitem, xcolor, fancyhdr, hyperref,
and bookmark. No external bibliography processor is required.

## Verification scope

The equational replay checks 11 finite theorems in 83 proof nodes and
rejects two deliberately corrupted certificates. The numerical examples
are finite diagnostics, never substitutes for the quantified proofs.
The complete infinite generator and first-order bi-interpretability theorem
have written proofs in the report, not a claimed Lean or Rocq formalization.

## Comparison snapshot

Repository: https://github.com/VladimirReshetnikov/ProveIt

Commit: `d171b68f822c40d6e7884d4911ac4b03edd0048c`.

All five current proposals improve on some part of the four-file immediately
archived iteration. Their inherited results are attributed in the report.
The new result is a strict supported frontier improvement; no absolute
minimum over arbitrary logical languages and encodings is claimed.

The report also includes fully paid native-B and native-Q/Z companion
interfaces and a section titled “Further research questions.”
