#!/usr/bin/env python3
"""Finite equational certificates and exact syntax counts for the U36 kernel.

Python 3.10+, standard library only. Run this file to construct and independently
replay the certificates, write ../verification/kernel_certificates.json and
kernel_verification.json, and print a short status. Alternatively:

    python3 check_kernel.py --check PATH_TO_CERTIFICATES

The trusted proof checker is replay_certificate(), together with the elementary
term parser, simultaneous substitution, and four explicitly displayed axiom
matrices. Its rules are axiom instance, retained hypothesis, reflexivity,
symmetry, transitivity, and function congruence. No arithmetic evaluator,
normalizer, sample testing, induction, or untrusted rewriting is a proof rule.

Scope: this checks the finite equational bootstrap only. It does not mechanize
coverage case analysis, falsity elimination, the boundary/induction argument,
the infinite signature generator, or full first-order bi-interpretability.
All abbreviations B,Q,V,C are expanded in certificates and counts.
"""

from __future__ import annotations

import argparse
import copy
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


ARITIES = {"0": 0, "S": 1, "U": 2, "L": 1, "R": 1}


@dataclass(frozen=True)
class Term:
    symbol: str
    args: tuple["Term", ...] = ()
    variable: bool = False

    def __post_init__(self) -> None:
        if self.variable:
            if self.args or not self.symbol:
                raise ValueError("A variable must have a name and no arguments")
        elif self.symbol not in ARITIES or len(self.args) != ARITIES[self.symbol]:
            raise ValueError(f"Malformed function application: {self.symbol}")

    def encode(self) -> list[Any]:
        if self.variable:
            return ["var", self.symbol]
        return [self.symbol, *(arg.encode() for arg in self.args)]

    def size(self) -> int:
        return 1 + sum(arg.size() for arg in self.args)


def var(name: str) -> Term:
    return Term(name, variable=True)


def app(symbol: str, *args: Term) -> Term:
    return Term(symbol, tuple(args))


ZERO = app("0")


def S(t: Term) -> Term:
    return app("S", t)


def U(s: Term, t: Term) -> Term:
    return app("U", s, t)


def L(t: Term) -> Term:
    return app("L", t)


def R(t: Term) -> Term:
    return app("R", t)


# These are Python term constructors, not extra symbols of the checked theory.
def B(s: Term, t: Term) -> Term:
    return U(S(s), t)


def Q(n: Term, a: Term) -> Term:
    return L(U(n, a))


def V(n: Term, a: Term) -> Term:
    return R(U(n, a))


def C(n: Term, a: Term, b: Term) -> Term:
    return Q(V(n, S(b)), a)


def parse_term(data: Any) -> Term:
    if not isinstance(data, list) or not data or not isinstance(data[0], str):
        raise ValueError("Malformed term serialization")
    if data[0] == "var":
        if len(data) != 2 or not isinstance(data[1], str):
            raise ValueError("Malformed variable serialization")
        return var(data[1])
    return app(data[0], *(parse_term(item) for item in data[1:]))


def free_variables(t: Term) -> set[str]:
    if t.variable:
        return {t.symbol}
    result: set[str] = set()
    for child in t.args:
        result.update(free_variables(child))
    return result


def substitute(t: Term, environment: dict[str, Term]) -> Term:
    if t.variable:
        return environment[t.symbol]
    return app(t.symbol, *(substitute(child, environment) for child in t.args))


@dataclass(frozen=True)
class Equation:
    left: Term
    right: Term

    def encode(self) -> dict[str, Any]:
        return {"left": self.left.encode(), "right": self.right.encode()}

    def size(self) -> int:
        return 1 + self.left.size() + self.right.size()


def parse_equation(data: Any) -> Equation:
    if not isinstance(data, dict) or set(data) != {"left", "right"}:
        raise ValueError("Malformed equation serialization")
    return Equation(parse_term(data["left"]), parse_term(data["right"]))


a, n, x, y, b = map(var, ("a", "n", "x", "y", "b"))
AXIOMS = {
    "ret_left": Equation(L(U(S(a), n)), a),
    "ret_right": Equation(R(U(S(a), n)), n),
    "u_zero": Equation(U(ZERO, a), U(S(a), ZERO)),
    "successor_step": Equation(S(x), U(L(x), S(R(x)))),
}
HYPOTHESES = {
    "successors_equal": Equation(S(x), S(y)),
    "successor_is_zero": Equation(S(x), ZERO),
}


def axiom_instance(name: str, environment: dict[str, Term]) -> Equation:
    if name not in AXIOMS:
        raise ValueError(f"Unknown axiom: {name}")
    schema = AXIOMS[name]
    slots = free_variables(schema.left) | free_variables(schema.right)
    if set(environment) != slots:
        raise ValueError("An axiom instance must supply exactly its free slots")
    return Equation(substitute(schema.left, environment),
                    substitute(schema.right, environment))


def replay_certificate(document: dict[str, Any]) -> dict[str, Any]:
    """Replay an ordered proof DAG; no certificate-produced claim is trusted."""
    expected_axioms = {key: value.encode() for key, value in AXIOMS.items()}
    if document.get("axioms") != expected_axioms:
        raise ValueError("Certificate axiom matrices differ from the U36 kernel")
    hypotheses = {key: parse_equation(value)
                  for key, value in document["hypotheses"].items()}
    proved: list[tuple[Equation, frozenset[str]]] = []
    for index, node in enumerate(document["nodes"]):
        if node.get("id") != index:
            raise ValueError("Proof node IDs must be consecutive")
        premise_ids = node.get("premises", [])
        if any(type(i) is not int or not 0 <= i < index for i in premise_ids):
            raise ValueError("A premise must refer to an earlier proof node")
        premises = [proved[i] for i in premise_ids]
        context = frozenset().union(*(ctx for _, ctx in premises))
        rule = node["rule"]
        if rule == "axiom":
            if premises:
                raise ValueError("An axiom instance has no premises")
            environment = {key: parse_term(value)
                           for key, value in node["substitution"].items()}
            conclusion = axiom_instance(node["axiom"], environment)
        elif rule == "hypothesis":
            if premises or node["hypothesis"] not in hypotheses:
                raise ValueError("Invalid retained hypothesis")
            label = node["hypothesis"]
            conclusion = hypotheses[label]
            context = frozenset({label})
        elif rule == "reflexivity":
            if premises:
                raise ValueError("Reflexivity has no premises")
            term = parse_term(node["term"])
            conclusion = Equation(term, term)
        elif rule == "symmetry":
            if len(premises) != 1:
                raise ValueError("Symmetry has one premise")
            equation = premises[0][0]
            conclusion = Equation(equation.right, equation.left)
        elif rule == "transitivity":
            if len(premises) != 2:
                raise ValueError("Transitivity has two premises")
            first, second = (item[0] for item in premises)
            if first.right != second.left:
                raise ValueError("Transitivity middle terms do not match")
            conclusion = Equation(first.left, second.right)
        elif rule == "congruence":
            symbol = node["function"]
            if symbol not in ARITIES or len(premises) != ARITIES[symbol]:
                raise ValueError("Congruence must provide one premise per argument")
            conclusion = Equation(app(symbol, *(eq.left for eq, _ in premises)),
                                  app(symbol, *(eq.right for eq, _ in premises)))
        else:
            raise ValueError(f"Unrecognized inference rule: {rule}")
        if parse_equation(node["equation"]) != conclusion:
            raise ValueError(f"Node {index}: claimed equation is not its conclusion")
        if set(node["assumptions"]) != set(context):
            raise ValueError(f"Node {index}: retained assumptions were altered")
        proved.append((conclusion, context))

    checked = []
    for theorem in document["theorems"]:
        root = theorem["root"]
        if type(root) is not int or not 0 <= root < len(proved):
            raise ValueError("Invalid theorem root")
        conclusion, context = proved[root]
        if parse_equation(theorem["equation"]) != conclusion:
            raise ValueError("Theorem conclusion differs from its proof root")
        if set(theorem["assumptions"]) != set(context):
            raise ValueError("Theorem retained assumptions differ from its proof")
        checked.append({"name": theorem["name"], "root": root,
                        "assumptions": sorted(context), "verified": True})
    return {"proof_nodes": len(proved), "theorems": checked}


class Builder:
    """Untrusted certificate construction; its output must be independently replayed."""

    def __init__(self) -> None:
        self.nodes: list[dict[str, Any]] = []
        self.equations: list[Equation] = []
        self.contexts: list[frozenset[str]] = []
        self.theorems: list[dict[str, Any]] = []

    def add(self, rule: str, equation: Equation, premises: Iterable[int] = (),
            *, context: frozenset[str] | None = None, **details: Any) -> int:
        premises = list(premises)
        if context is None:
            context = frozenset().union(*(self.contexts[i] for i in premises))
        index = len(self.nodes)
        self.nodes.append({"id": index, "rule": rule, "premises": premises,
                           "equation": equation.encode(),
                           "assumptions": sorted(context), **details})
        self.equations.append(equation)
        self.contexts.append(context)
        return index

    def ax(self, name: str, **environment: Term) -> int:
        return self.add("axiom", axiom_instance(name, environment), axiom=name,
                        substitution={k: t.encode() for k, t in environment.items()})

    def hypothesis(self, name: str) -> int:
        return self.add("hypothesis", HYPOTHESES[name],
                        context=frozenset({name}), hypothesis=name)

    def refl(self, term: Term) -> int:
        return self.add("reflexivity", Equation(term, term), term=term.encode())

    def sym(self, proof: int) -> int:
        equation = self.equations[proof]
        return self.add("symmetry", Equation(equation.right, equation.left), [proof])

    def chain(self, *proofs: int) -> int:
        if not proofs:
            raise ValueError("A proof chain must be nonempty")
        result = proofs[0]
        for following in proofs[1:]:
            left, right = self.equations[result], self.equations[following]
            if left.right != right.left:
                raise ValueError("Builder attempted a mismatched transitivity")
            result = self.add("transitivity", Equation(left.left, right.right),
                              [result, following])
        return result

    def cong(self, symbol: str, *proofs: int) -> int:
        equations = [self.equations[i] for i in proofs]
        return self.add("congruence",
                        Equation(app(symbol, *(e.left for e in equations)),
                                 app(symbol, *(e.right for e in equations))),
                        proofs, function=symbol)

    def q_cong(self, counter: int, initial: int) -> int:
        return self.cong("L", self.cong("U", counter, initial))

    def q_zero(self, initial: Term) -> int:
        return self.chain(self.cong("L", self.ax("u_zero", a=initial)),
                          self.ax("ret_left", a=initial, n=ZERO))

    def q_successor(self, counter: Term, initial: Term) -> int:
        return self.ax("ret_left", a=counter, n=initial)

    def v_zero(self, initial: Term) -> int:
        return self.chain(self.cong("R", self.ax("u_zero", a=initial)),
                          self.ax("ret_right", a=initial, n=ZERO))

    def v_successor(self, counter: Term, initial: Term) -> int:
        return self.ax("ret_right", a=counter, n=initial)

    def injectivity(self, equality_of_successors: int) -> int:
        equation = self.equations[equality_of_successors]
        if equation.left.symbol != "S" or equation.right.symbol != "S":
            raise ValueError("Builder injectivity helper expects two successors")
        first, second = equation.left.args[0], equation.right.args[0]
        return self.chain(
            self.sym(self.q_successor(first, ZERO)),
            self.q_cong(equality_of_successors, self.refl(ZERO)),
            self.q_successor(second, ZERO))

    def theorem(self, name: str, root: int, conclusion: Equation,
                assumptions: Iterable[str] = ()) -> None:
        if self.equations[root] != conclusion:
            raise ValueError(f"Builder theorem {name} has the wrong equation")
        if self.contexts[root] != frozenset(assumptions):
            raise ValueError(f"Builder theorem {name} has the wrong assumptions")
        self.theorems.append({"name": name, "root": root,
                              "equation": conclusion.encode(),
                              "assumptions": sorted(assumptions)})

    def document(self) -> dict[str, Any]:
        return {"format": "ipra-u36-equational-certificates-v1",
                "axioms": {key: value.encode() for key, value in AXIOMS.items()},
                "hypotheses": {key: value.encode()
                               for key, value in HYPOTHESES.items()},
                "nodes": self.nodes, "theorems": self.theorems}


def build_certificates() -> dict[str, Any]:
    p = Builder()
    p.theorem("Q_zero", p.q_zero(a), Equation(Q(ZERO, a), a))
    p.theorem("Q_successor", p.q_successor(n, a), Equation(Q(S(n), a), n))
    p.theorem("V_zero", p.v_zero(a), Equation(V(ZERO, a), ZERO))
    p.theorem("V_successor", p.v_successor(n, a), Equation(V(S(n), a), a))

    c_zero = p.chain(p.q_cong(p.v_zero(S(b)), p.refl(a)), p.q_zero(a))
    p.theorem("C_zero", c_zero, Equation(C(ZERO, a, b), a))
    c_successor = p.chain(p.q_cong(p.v_successor(n, S(b)), p.refl(a)),
                          p.q_successor(b, a))
    p.theorem("C_successor", c_successor, Equation(C(S(n), a, b), b))

    injective = p.injectivity(p.hypothesis("successors_equal"))
    p.theorem("successor_injectivity", injective, Equation(x, y),
              ["successors_equal"])

    sx_zero = p.hypothesis("successor_is_zero")
    x_zero = p.chain(p.sym(p.q_successor(x, ZERO)),
                     p.q_cong(sx_zero, p.refl(ZERO)), p.q_zero(ZERO))
    s0_zero = p.chain(p.sym(p.cong("S", x_zero)), sx_zero)
    p.theorem("Sx_zero_implies_S0_zero", s0_zero, Equation(S(ZERO), ZERO),
              ["successor_is_zero"])

    reconstructed = B(L(x), R(x))
    left = p.ax("ret_left", a=L(x), n=R(x))
    right = p.ax("ret_right", a=L(x), n=R(x))
    same_successor = p.chain(p.ax("successor_step", x=reconstructed),
                             p.cong("U", left, p.cong("S", right)),
                             p.sym(p.ax("successor_step", x=x)))
    eta = p.injectivity(same_successor)
    p.theorem("pairing_eta", eta, Equation(reconstructed, x))

    horizontal_input = B(S(a), n)
    horizontal = p.chain(
        p.ax("successor_step", x=horizontal_input),
        p.cong("U", p.ax("ret_left", a=S(a), n=n),
               p.cong("S", p.ax("ret_right", a=S(a), n=n))))
    p.theorem("horizontal_routing", horizontal,
              Equation(S(B(S(a), n)), B(a, S(n))))

    vertical_input = B(ZERO, n)
    vertical = p.chain(
        p.ax("successor_step", x=vertical_input),
        p.cong("U", p.ax("ret_left", a=ZERO, n=n),
               p.cong("S", p.ax("ret_right", a=ZERO, n=n))),
        p.ax("u_zero", a=S(n)))
    p.theorem("vertical_routing", vertical,
              Equation(S(B(ZERO, n)), B(S(n), ZERO)))
    return p.document()


# Formula trees are separate from proof rules and are used only for exact counts.
# A binder stores its variable annotation but charges only the binder node.
def formula_size(formula: tuple[Any, ...]) -> int:
    head = formula[0]
    if head == "eq":
        return 1 + formula[1].size() + formula[2].size()
    if head == "bottom" or head == "prop":
        return 1
    if head in {"forall", "exists"}:
        return 1 + formula_size(formula[2])
    if head in {"and", "or", "implies", "K3", "K4"}:
        return 1 + sum(formula_size(item) for item in formula[1:])
    raise ValueError(f"Unknown formula constructor: {head}")


def eq_formula(equation: Equation) -> tuple[Any, ...]:
    return ("eq", equation.left, equation.right)


def conjunction(formulas: list[tuple[Any, ...]]) -> tuple[Any, ...]:
    if not formulas:
        raise ValueError("Nonempty conjunction required")
    result = formulas[-1]
    for formula in reversed(formulas[:-1]):
        result = ("and", formula, result)
    return result


def exact_ledger() -> dict[str, Any]:
    matrices = [AXIOMS["ret_left"], AXIOMS["ret_right"], AXIOMS["u_zero"],
                axiom_instance("successor_step", {"x": a})]
    kernel = ("forall", "a", ("forall", "n",
              conjunction([eq_formula(equation) for equation in matrices])))
    separation = ("implies", ("eq", ZERO, S(ZERO)), ("bottom",))
    z = var("z")
    coverage = ("forall", "z", ("exists", "y", ("or", ("eq", z, ZERO),
                                                          ("eq", z, S(y)))))
    A, D, E, H = (("prop", name) for name in "ADEH")
    k3_lhs = ("K3", A, D, E)
    k3_rhs = ("and", ("implies", A, D), ("implies", D, E))
    k4_lhs = ("K4", A, D, E, H)
    k4_rhs = ("and", ("implies", A, D),
              ("implies", D, ("implies", E, H)))
    k4_nested_rhs = ("K3", A, D, ("implies", E, H))
    record3 = formula_size(k3_lhs) + 1 + formula_size(k3_rhs)
    record4 = formula_size(k4_lhs) + 1 + formula_size(k4_rhs)
    record34 = record3 + formula_size(k4_lhs) + 1 + formula_size(k4_nested_rhs)
    numerical_support = formula_size(kernel) + formula_size(separation) + formula_size(coverage)
    result = {
        "metric": "Each term/formula node costs one; binder annotation is not a second node.",
        "U36": {
            "matrices": [item.size() for item in matrices],
            "conjunction_nodes": 3, "quantifier_nodes": 2,
            "kernel": formula_size(kernel), "separation": formula_size(separation),
            "coverage": formula_size(coverage), "numerical_support": numerical_support,
            "K3_record": record3, "K4_record": record4, "joint_record": record34,
            "K3_total": numerical_support + record3,
            "K4_total": numerical_support + record4,
            "joint_total": numerical_support + record34,
        },
        "expanding_helper_sizes": {"B(a,n)": B(a, n).size(), "Q(n,a)": Q(n, a).size(),
                                   "V(n,a)": V(n, a).size(), "C(n,a,b)": C(n, a, b).size()},
    }
    if result["U36"]["matrices"] != [7, 7, 8, 9]:
        raise AssertionError("U36 matrix ledger disagrees with the stated formula")
    if (formula_size(kernel), numerical_support, numerical_support + record4) != (36, 52, 67):
        raise AssertionError("U36 support ledger mismatch")

    # Count the optional native-B interface with a general AST; B is deliberately
    # not admitted as a primitive by the proof checker above.
    def tree_size(tree: Any) -> int:
        return 1 if isinstance(tree, str) else 1 + sum(tree_size(c) for c in tree[1:])

    native_b_matrices = [
        ("=", ("L", ("B", "a", "n")), "a"),
        ("=", ("R", ("B", "a", "n")), "n"),
        ("=", ("U", "0", "a"), ("B", "a", "0")),
        ("=", ("U", ("S", "n"), "a"), ("B", "n", "a")),
        ("=", ("S", "a"), ("U", ("L", "a"), ("S", ("R", "a")))),
    ]
    native_b_sizes = list(map(tree_size, native_b_matrices))
    native_b_kernel = sum(native_b_sizes) + 4 + 2
    result["native_B_interface"] = {
        "matrices": native_b_sizes, "conjunction_nodes": 4, "quantifier_nodes": 2,
        "kernel": native_b_kernel, "numerical_support": native_b_kernel + 16,
        "K4_total": native_b_kernel + 16 + record4,
        "caveat": "B is an additional primitive here, with its two U defining equations paid.",
    }
    if native_b_sizes != [6, 6, 7, 8, 9] or native_b_kernel != 42:
        raise AssertionError("Native-B interface ledger mismatch")
    return result


def negative_checks(document: dict[str, Any]) -> list[dict[str, Any]]:
    """Show that the replay rejects a false output and erased assumptions."""
    changes = []
    false_equation = copy.deepcopy(document)
    root = false_equation["theorems"][0]["root"]
    false_equation["nodes"][root]["equation"]["right"] = S(a).encode()
    changes.append(("false_Q_zero_conclusion", false_equation))
    erased_context = copy.deepcopy(document)
    conditional = next(item for item in erased_context["theorems"]
                       if item["name"] == "successor_injectivity")
    conditional["assumptions"] = []
    changes.append(("erased_injectivity_hypothesis", erased_context))
    results = []
    for name, altered in changes:
        try:
            replay_certificate(altered)
        except (ValueError, KeyError, TypeError) as exc:
            results.append({"name": name, "rejected": True, "reason": str(exc)})
        else:
            raise AssertionError(f"Negative check {name} was accepted")
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", type=Path, help="Replay an existing certificate JSON")
    parser.add_argument("--output-dir", type=Path,
                        default=Path(__file__).resolve().parents[1] / "verification")
    args = parser.parse_args()
    if args.check:
        report = replay_certificate(json.loads(args.check.read_text(encoding="utf-8")))
        print(json.dumps(report, indent=2))
        return
    args.output_dir.mkdir(parents=True, exist_ok=True)
    document = build_certificates()
    certificate_path = args.output_dir / "kernel_certificates.json"
    certificate_path.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")
    # Read the serialized document back, so the saved artifact is what is replayed.
    saved = json.loads(certificate_path.read_text(encoding="utf-8"))
    replay = replay_certificate(saved)
    report = {
        "status": "all finite equational certificates verified",
        "scope": "Finite equational bootstrap only; no claim of complete first-order formalization.",
        "replay": replay, "negative_checks": negative_checks(saved),
        "ledger": exact_ledger(),
        "sample_testing_used_as_proof": False,
    }
    (args.output_dir / "kernel_verification.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"Verified {len(replay['theorems'])} equational theorems in {replay['proof_nodes']} proof nodes.")
    print("U36: matrix sizes [7,7,8,9], kernel 36, numerical support 52, K4 fixed record 67.")
    print("Optional native-B interface: kernel 42, numerical support 58, K4 fixed record 73.")
    print("Negative checks rejected a false equation and a deleted retained hypothesis.")
    print("Coverage, induction, infinite generators, and bi-interpretability remain prose proofs.")


if __name__ == "__main__":
    main()
