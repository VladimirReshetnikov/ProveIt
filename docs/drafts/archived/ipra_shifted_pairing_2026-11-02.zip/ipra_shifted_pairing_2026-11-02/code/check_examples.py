#!/usr/bin/env python3
"""Finite diagnostics for the shifted-pairing presentation of iPRA.

Run from any working directory with Python 3.10 or newer.  The program uses
only the Python standard library and writes a JSON record beside the report.

These are executable finite checks, not formal proofs, not a model checker
for nonstandard models, and not an implementation of the full infinite
signature or axiom generator.  The report supplies the mathematical proofs.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from math import isqrt
from pathlib import Path
from typing import Callable


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "verification" / "examples_verification.json"


def triangular(n: int) -> int:
    assert n >= 0
    return n * (n + 1) // 2


def B(a: int, n: int) -> int:
    """Canonical triangular pairing B(a,n) = T(a+n)+n."""
    assert a >= 0 and n >= 0
    return triangular(a + n) + n


def unpair(z: int) -> tuple[int, int]:
    """Exact integer inversion; no floating-point square roots are used."""
    assert z >= 0
    diagonal = (isqrt(8 * z + 1) - 1) // 2
    right = z - triangular(diagonal)
    left = diagonal - right
    assert left >= 0 and right >= 0
    return left, right


def L(z: int) -> int:
    return unpair(z)[0]


def R(z: int) -> int:
    return unpair(z)[1]


def U(n: int, a: int) -> int:
    """The intended shifted pairing, defined on all natural inputs."""
    assert n >= 0 and a >= 0
    return B(a, 0) if n == 0 else B(n - 1, a)


def Q(n: int, a: int) -> int:
    return L(U(n, a))


def C(n: int, a: int, b: int) -> int:
    return L(U(R(U(n, b + 1)), a))


def check_kernel_and_helpers(bound: int = 40) -> dict:
    """Check the actual numerical equations, without calling check_kernel."""
    checks = {"four_kernel_matrices": 0, "pairing_round_trips": 0,
              "predecessor_helper": 0, "case_helper": 0,
              "routing_and_root": 0}
    for a in range(bound + 1):
        for n in range(bound + 1):
            assert L(U(a + 1, n)) == a
            assert R(U(a + 1, n)) == n
            assert U(0, a) == U(a + 1, 0)
            assert a + 1 == U(L(a), R(a) + 1)
            checks["four_kernel_matrices"] += 4

            assert B(a, n) == U(a + 1, n)
            assert unpair(B(a, n)) == (a, n)
            checks["pairing_round_trips"] += 2

            assert Q(0, a) == a
            assert Q(n + 1, a) == n
            checks["predecessor_helper"] += 2

            assert B(a + 1, n) + 1 == B(a, n + 1)
            assert B(0, n) + 1 == B(n + 1, 0)
            checks["routing_and_root"] += 2

            for b in range(bound + 1):
                assert C(0, a, b) == a
                assert C(n + 1, a, b) == b
                checks["case_helper"] += 2

    for z in range(B(bound, bound) + 1):
        assert B(L(z), R(z)) == z
        checks["pairing_round_trips"] += 1
    assert (L(0), R(0), B(0, 0), U(0, 0)) == (0, 0, 0, 0)
    checks["routing_and_root"] += 4
    return {"status": "passed", "grid": {"a": [0, bound], "n": [0, bound],
            "b_for_case_helper": [0, bound]}, "checks": checks,
            "total_assertions": sum(checks.values())}


def scan_witness(values: tuple[bool, ...], target: int,
                 audit: Callable[[int, int], None]) -> int:
    """Stop at the first failure at or before target, or at target itself.

    At stage k, the invariant checked by the caller is b<=k, every index
    below b succeeds, and success at b implies b=k.  An actual arithmetic
    construction replaces the Python conditional by the derived C helper.
    """
    assert 0 <= target < len(values)
    b = 0
    audit(0, b)
    for k in range(target):
        if values[b]:
            b = k + 1
        audit(k + 1, b)
    return b


def check_bounded_scan(length: int = 8) -> dict:
    invariant_checks = 0
    witness_checks = 0
    boundary_x_checks = 0
    for mask in range(1 << length):
        values = tuple(bool(mask & (1 << i)) for i in range(length))
        for target in range(length):
            def audit(k: int, b: int) -> None:
                nonlocal invariant_checks
                assert 0 <= b <= k
                assert all(values[i] for i in range(b))
                assert not values[b] or b == k
                invariant_checks += 1

            b = scan_witness(values, target, audit)
            expected = next((i for i in range(target + 1)
                             if not values[i]), target)
            assert b == expected
            assert b == 0 or values[b - 1]
            assert not values[b] or b == target
            witness_checks += 1
            for x in range(length):
                # Expansion of K4(Sx=b, E(x), x=b, b=target).
                assert x + 1 != b or values[x]
                assert not values[x] or x != b or b == target
                boundary_x_checks += 1

    return {"status": "passed", "predicate_domain": [0, length - 1],
            "all_boolean_predicates": 1 << length,
            "targets": [0, length - 1],
            "witnesses_checked": witness_checks,
            "invariant_stages_checked": invariant_checks,
            "boundary_variable_assignments_checked": boundary_x_checks,
            "invariant": ["0 <= b <= k", "every i < b satisfies E(i)",
                          "E(b) implies b = k"],
            "limitation": "Exhaustive only on this finite Boolean domain; "
                          "not a formal verification of the general scan proof."}


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()

    @property
    def size(self) -> int:
        # Count occurrences, not object identities: descriptors and repeated
        # terms are charged each time.  An explicit stack also supports long
        # successor chains without depending on Python's recursion limit.
        total = 0
        pending = [self]
        while pending:
            current = pending.pop()
            total += 1
            pending.extend(current.children)
        return total


def node(tag: str, *children: Node) -> Node:
    return Node(tag, children)


def succ(t: Node, times: int = 1) -> Node:
    for _ in range(times):
        t = node("S", t)
    return t


def rec(h: Node, n: Node, a: Node) -> Node:
    # Store the descriptor as a charged child, counting it at every call.
    return node("R_h", h, n, a)


def case_term(n: Node, a: Node, b: Node) -> Node:
    return node("L", node("U", node("R", node("U", n, succ(b))), a))


def ordinary_state_free_module(m: int) -> tuple[Node, Node]:
    assert m >= 1
    a, n, w, zero = (node(s) for s in ("a", "n", "w", "0"))
    h = succ(w, m)
    # Binder names are annotations, not charged syntax children.
    base = node("forall:a", node("=", rec(h, zero, a), a))
    step = node("forall:a", node("forall:n",
                node("=", rec(h, succ(n), a), succ(n, m))))
    return base, step


def explicit_state_free_iteration(m: int, n: int, a: int) -> int:
    """Actually run the update h_m(v,w)=w+m, rather than use its formula."""
    assert m >= 1 and n >= 0 and a >= 0
    state = a
    for counter in range(n):
        state = counter + m
    return state


def check_state_free_family(max_m: int = 32, max_n: int = 32,
                            max_a: int = 16) -> dict:
    numerical_checks = 0
    for m in range(1, max_m + 1):
        for n in range(max_n + 1):
            for a in range(max_a + 1):
                guarded = C(n, a, n + m - 1)
                assert guarded == explicit_state_free_iteration(m, n, a)
                numerical_checks += 1

    n, a, w = (node(s) for s in ("n", "a", "w"))
    rows = []
    for m in range(1, 1001):
        body = succ(w, m)
        ordinary_base, ordinary_step = ordinary_state_free_module(m)
        old_call = rec(body, n, a)
        new_call = case_term(n, a, succ(n, m - 1))
        ordinary_size = ordinary_base.size + ordinary_step.size
        old_packet = 74 + ordinary_size + old_call.size
        new_packet = 67 + new_call.size
        assert body.size == m + 1
        assert ordinary_base.size == m + 7
        assert ordinary_step.size == 2 * m + 9
        assert ordinary_size == 3 * m + 16
        assert old_call.size == m + 4
        assert new_call.size == m + 7
        assert old_packet == 4 * m + 94
        assert new_packet == m + 74
        assert old_packet - new_packet == 3 * m + 20
        if m in (1, 2, 3, 4, 8, 16, 32, 100, 1000):
            rows.append({"m": m, "body_nodes": body.size,
                         "ordinary_module_nodes": ordinary_size,
                         "old_call_nodes": old_call.size,
                         "guarded_call_nodes": new_call.size,
                         "old_packet_nodes": old_packet,
                         "new_packet_nodes": new_packet,
                         "saving_nodes": old_packet - new_packet})
    return {"status": "passed",
            "numerical_ranges": {"m": [1, max_m], "n": [0, max_n],
                                 "a": [0, max_a]},
            "numerical_comparisons": numerical_checks,
            "AST_size_range_m": [1, 1000],
            "formulas": {"h_m": "S^m(w)",
                         "virtual_J": "C(n,a,S^(m-1)(n))",
                         "old_packet": "74+(3*m+16)+(m+4)=4*m+94",
                         "new_packet": "67+(m+7)=m+74",
                         "saving": "3*m+20"},
            "sample_rows": rows,
            "limitation": "These packets use the specified old ordinary "
                          "computation module and one call. They do not "
                          "count the whole infinite theory, nor establish "
                          "a lower bound over all old optimized modules."}


def U_weak(n: int, a: int) -> int:
    return B(0, 1) if (n, a) == (0, 0) else U(n, a)


def check_weakened_zero_counterexample(bound: int = 64) -> dict:
    checks = 0
    for a in range(bound + 1):
        for n in range(bound + 1):
            assert L(U_weak(a + 1, n)) == a
            assert R(U_weak(a + 1, n)) == n
            assert L(U_weak(0, a)) == a
            assert a + 1 == U_weak(L(a), R(a) + 1)
            checks += 4
    left, right = U_weak(0, 0), U_weak(1, 0)
    assert left != right
    return {"status": "passed", "changed_input": [0, 0],
            "changed_value": B(0, 1), "canonical_value": U(0, 0),
            "grid": {"a": [0, bound], "n": [0, bound]},
            "weakened_matrix_assertions": checks,
            "failed_original_instance": {"a": 0, "U_weak(0,a)": left,
                                         "U_weak(Sa,0)": right},
            "structural_explanation": "The retractions call U only at "
                "positive first arguments, and the successor equation "
                "calls U only at positive second arguments. At (0,0), "
                "the weakened left-projection condition holds because "
                "L(B(0,1))=0. Thus this single modified value evades the "
                "weakened equations but violates the original zero law.",
            "limitation": "The executable checks above are finite. The "
                          "accompanying structural explanation identifies "
                          "why the explicitly defined modification works "
                          "on every natural input."}


def main() -> None:
    result = {
        "artifact": "Finite diagnostics for shifted pairing",
        "independent_of": "code/check_kernel.py and its proof-certificate replay",
        "kernel_and_helpers": check_kernel_and_helpers(),
        "bounded_scan": check_bounded_scan(),
        "state_free_family": check_state_free_family(),
        "weakened_zero_counterexample": check_weakened_zero_counterexample(),
        "overall_status": "passed",
        "limitations": [
            "Finite numerical checks do not prove universal statements.",
            "No nonstandard or Kripke models are exhaustively checked.",
            "The full infinite normalizer, signature generator, optimized "
            "module selector and boundary emitter are not implemented here.",
            "The general mathematical results rely on the report's proofs."
        ],
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print("PASS: numerical kernel/helper diagnostics")
    print("PASS: all 256 Boolean predicates on eight positions, eight targets each")
    print("PASS: guarded state-free calls versus explicit iteration")
    print("PASS: independent AST counts for m=1,...,1000")
    print("PASS: explicit counterexample to the weakened zero law")
    print("These are finite diagnostics, not a formal proof of the full theory.")
    print(f"JSON record: {OUTPUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
