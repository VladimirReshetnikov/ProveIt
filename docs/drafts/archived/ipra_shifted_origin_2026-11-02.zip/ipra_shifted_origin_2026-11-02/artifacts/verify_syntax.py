#!/usr/bin/env python3
"""Finite AST diagnostics for the shifted-origin iPRA report.

Checks full descriptor charges, frozen active substitution, source-rule
irreducibility and fused normalization, exact prefix/boundary costs,
module counts, atom-local factoring, and the image-pruning size argument
on explicit finite examples. This is NOT a proof-assistant formalization.
Only Python's standard library is required; no source-draft code is imported.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path


def V(name): return ("var", name)
ZERO = ("0",)
BOT = ("bot",)
v, w, a, n, u, x, y, b, z = map(V, ("v", "w", "a", "n", "u", "x", "y", "b", "z"))


def S(t): return ("S", t)
def B(s, t): return ("B", s, t)
def L(t): return ("L", t)
def R(t): return ("R", t)
def Rec(h, t, a): return ("rec", h, t, a)
def Eq(s, t): return ("eq", s, t)
def And(p, q): return ("and", p, q)
def Or(p, q): return ("or", p, q)
def Imp(p, q): return ("imp", p, q)
def K3(p, q, r): return ("K3", p, q, r)
def K4(p, q, r, s): return ("K4", p, q, r, s)
def P(t): return ("p", t)
def C(t, a, b): return ("C", t, a, b)


def quant(tag, names, formula):
    for name in reversed(names):
        formula = (tag, name, formula)
    return formula


def size(node):
    if node[0] in {"var", "0", "bot"}:
        return 1
    if node[0] in {"all", "ex"}:
        return 1 + size(node[2])
    return 1 + sum(size(child) for child in node[1:])


def active_children(term):
    if term[0] in {"var", "0"}:
        return ()
    if term[0] == "rec":
        return term[2:]
    return term[1:]


def rebuild(term, children):
    if term[0] == "rec":
        return ("rec", term[1], *children)
    return (term[0], *children)


def substitute(term, env):
    """Simultaneous ACTIVE substitution; recursor labels remain frozen."""
    if term[0] == "var":
        return env.get(term[1], term)
    if term[0] == "0":
        return term
    return rebuild(term, tuple(substitute(c, env) for c in active_children(term)))


def dagger(term, state, counter, next_counter):
    if term == S(w):
        return next_counter
    if term == v:
        return state
    if term == w:
        return counter
    if term[0] in {"var", "0"}:
        return term
    return rebuild(term, tuple(dagger(c, state, counter, next_counter)
                               for c in active_children(term)))


OLD_RULES = {
    "canonical_presentation": {"beta", "eta", "rec_zero", "counter"},
    "normal_signature": {"beta", "eta", "native_helpers", "rec_zero", "rec_step"},
    "reduced_signature": {"rec_zero", "counter"},
    "successor_pairing": {"rec_zero", "counter"},
    "reduced_pairing": {"projected_routes", "rec_zero", "rec_step", "literal_identity", "native_helpers"},
}
OLD_UNION = set().union(*OLD_RULES.values())
NEW_RULES = {"beta", "eta", "roots", "horizontal", "projected_routes",
             "rec_zero", "fusion", "rec_step"}


def root_rewrite(t, rules):
    tag = t[0]
    if "beta" in rules and tag in {"L", "R"} and t[1][0] == "B":
        return t[1][1 if tag == "L" else 2], "pair_beta"
    if ("eta" in rules and tag == "B" and t[1][0] == "L"
            and t[2][0] == "R" and t[1][1] == t[2][1]):
        return t[1][1], "pair_eta"
    if "roots" in rules:
        if tag in {"L", "R"} and t[1] == ZERO:
            return ZERO, "root_projection"
        if t == B(ZERO, ZERO):
            return ZERO, "root_pair"
    if ("horizontal" in rules and tag == "S" and t[1][0] == "B"
            and t[1][1][0] == "S"):
        return B(t[1][1][1], S(t[1][2])), "horizontal"
    if ("projected_routes" in rules and tag in {"L", "R"}
            and t[1][0] == "S" and t[1][1][0] == "B"):
        first, second = t[1][1][1:]
        if first == ZERO:
            return (S(second) if tag == "L" else ZERO), "projected_zero"
        if first[0] == "S":
            return (first[1] if tag == "L" else S(second)), "projected_successor"
    if "native_helpers" in rules:
        if tag == "p":
            if t[1] == ZERO:
                return ZERO, "native_p_zero"
            if t[1][0] == "S":
                return t[1][1], "native_p_step"
        if tag == "C":
            if t[1] == ZERO:
                return t[2], "native_C_zero"
            if t[1][0] == "S":
                return t[3], "native_C_step"
        if tag in {"Q", "Z"}:
            if t[1] == ZERO:
                return t[2], "native_QZ_zero"
            if t[1][0] == "S":
                return (t[1][1] if tag == "Q" else ZERO), "native_QZ_step"
    if tag == "rec":
        body, counter, initial = t[1:]
        if "rec_zero" in rules and counter == ZERO:
            return initial, "rec_zero"
        if "literal_identity" in rules and body == v:
            return initial, "literal_identity"
        if "counter" in rules and body == w and counter[0] == "S":
            return counter[1], "counter"
        if "fusion" in rules and counter == S(ZERO):
            endpoint = substitute(body, {"v": initial, "w": ZERO})
            if size(endpoint) < size(t):
                return endpoint, "fused_initialization"
        if "rec_step" in rules and counter[0] == "S":
            previous = counter[1]
            endpoint = substitute(body, {"v": Rec(body, previous, initial), "w": previous})
            if size(endpoint) < size(t):
                return endpoint, "ordinary_step"
    return None


def rewrite_once(term, rules):
    """First eligible active occurrence in left-to-right postorder."""
    children = active_children(term)
    for i, child in enumerate(children):
        result = rewrite_once(child, rules)
        if result is not None:
            changed, name = result
            new_children = list(children)
            new_children[i] = changed
            return rebuild(term, tuple(new_children)), name
    return root_rewrite(term, rules)


def normalize(term, rules):
    current = term
    trace = []
    while True:
        step = rewrite_once(current, rules)
        if step is None:
            return current, trace
        changed, name = step
        before, after = size(current), size(changed)
        assert after < before, (name, before, after)
        trace.append({"rule": name, "before": before, "after": after})
        current = changed


def pi(term):
    return L(S(B(term, ZERO)))


def family(m):
    body = v
    for _ in range(m):
        body = S(body)
    original = Rec(body, S(ZERO), v)
    wrapped = original
    for _ in range(m):
        wrapped = pi(wrapped)
    return body, original, wrapped


def active_subterms(term):
    for child in active_children(term):
        yield from active_subterms(child)
    yield term


def factor_atom_size(equation):
    """Exact search over repeated nonvariable active subterms of an atom.

    A singly occurring term cannot improve a minimum: eliminating its
    binding saves five nodes and preserves all other bindings. Labels
    are never traversal sites, but remain fully charged by size().
    """
    assert equation[0] == "eq"
    counts = Counter()
    order = []
    seen = set()
    for side in equation[1:]:
        for term in active_subterms(side):
            counts[term] += 1
            if term not in seen:
                seen.add(term)
                order.append(term)
    candidates = [t for t in order if t[0] != "var" and counts[t] > 1]
    best = size(equation)
    for mask in range(1, 1 << len(candidates)):
        selected = [t for i, t in enumerate(candidates) if mask & (1 << i)]
        names = {t: V(f"fresh_{i}") for i, t in enumerate(selected)}

        def replace(term, skip_root=False):
            if not skip_root and term in names:
                return names[term]
            if term[0] in {"var", "0"}:
                return term
            return rebuild(term, tuple(replace(c) for c in active_children(term)))

        candidate_size = 1 + sum(size(replace(s)) for s in equation[1:])
        candidate_size += sum(size(replace(t, True)) + 4 for t in selected)
        best = min(best, candidate_size)
    return best


def factored_formula_size(formula):
    if formula[0] == "eq":
        return factor_atom_size(formula)
    if formula[0] in {"all", "ex"}:
        return 1 + factored_formula_size(formula[2])
    if formula[0] in {"bot", "var"}:
        return 1
    return 1 + sum(factored_formula_size(c) for c in formula[1:])


def modules(h):
    """Generous source menu with native p,C and both chain connectives."""
    ordinary = (
        quant("all", ["a"], Eq(Rec(h, ZERO, a), a)),
        quant("all", ["a", "n"], Eq(Rec(h, S(n), a),
              substitute(h, {"v": Rec(h, n, a), "w": n}))),
    )
    graph = (quant("all", ["a", "n", "u"], K3(
        And(Eq(n, ZERO), Eq(u, a)), Eq(Rec(h, n, a), u),
        Eq(Rec(h, S(n), a), substitute(h, {"v": u, "w": n})))),)
    table = (quant("all", ["a", "n"], quant("ex", ["u"], And(
        Imp(Eq(n, ZERO), Eq(u, a)),
        quant("all", ["x", "y"], K4(And(Eq(x, n), Eq(y, u)),
            Eq(Rec(h, x, a), y), Eq(x, S(n)), Eq(y, dagger(h, u, n, x))))))),)
    folded = (quant("all", ["a", "n"], Eq(Rec(h, n, a),
        C(n, a, dagger(h, Rec(h, P(n), a), P(n), n)))),)
    bound = (quant("all", ["a", "n", "u"], Imp(Eq(P(n), u),
        Eq(Rec(h, n, a), C(n, a, dagger(h, Rec(h, u, a), u, n))))),)
    shifted = (quant("all", ["a", "n"], quant("ex", ["u"],
        quant("all", ["x", "y"], K4(And(Eq(S(x), n), Eq(y, u)),
            Eq(Rec(h, x, a), y), Eq(x, n),
            Eq(y, C(n, a, dagger(h, u, P(n), n))))))),)
    return {"D": ordinary, "G3": graph, "T4": table,
            "F": folded, "L": bound, "N4": shifted}


def prune_term(term):
    """Exact-image J: erase certified identities, retain ORIGINAL labels."""
    if term[0] in {"var", "0"}:
        return term
    if term[0] == "rec" and normalize(term[1], NEW_RULES)[0] == v:
        return prune_term(term[3])
    return rebuild(term, tuple(prune_term(c) for c in active_children(term)))


def prune_formula(formula):
    if formula[0] == "eq":
        return Eq(prune_term(formula[1]), prune_term(formula[2]))
    if formula[0] in {"all", "ex"}:
        return (formula[0], formula[1], prune_formula(formula[2]))
    if formula[0] in {"bot", "var"}:
        return formula
    return (formula[0], *(prune_formula(c) for c in formula[1:]))


def prefix_checks():
    sep = Imp(Eq(ZERO, S(ZERO)), BOT)
    cov = quant("all", ["z"], quant("ex", ["y"], Or(Eq(z, ZERO), Eq(z, S(y)))))
    cov_b = quant("all", ["z"], quant("ex", ["y"],
        Or(Eq(z, B(ZERO, ZERO)), Eq(z, S(y)))))
    eta = quant("all", ["z"], Eq(B(L(z), R(z)), z))
    horizontal = Eq(S(B(S(a), n)), B(a, S(n)))
    left, right = Eq(L(B(a, n)), a), Eq(R(B(a, n)), n)
    j = quant("all", ["a", "n"], And(horizontal, And(left, right)))
    vertical = quant("all", ["n"], Eq(S(B(ZERO, n)), B(S(n), ZERO)))
    vertical_left = quant("all", ["n"], Eq(L(S(B(ZERO, n))), S(n)))
    aa, bb, cc, dd = map(V, ["A", "P", "C", "D"])
    record = ("definition", K4(aa, bb, cc, dd), And(Imp(aa, bb), Imp(bb, Imp(cc, dd))))
    values = {"Sep": size(sep), "Cov_B": size(cov_b), "J": size(j),
              "V": size(vertical), "K4_record": size(record),
              "Cov": size(cov), "Eta": size(eta), "V_left": size(vertical_left)}
    assert values == {"Sep": 6, "Cov_B": 12, "J": 26, "V": 10,
                      "K4_record": 15, "Cov": 10, "Eta": 8, "V_left": 9}
    main = sum(size(t) for t in [sep, cov_b, j, vertical])
    companion = sum(size(t) for t in [sep, cov, eta, j, vertical_left])
    assert (main, main + size(record), companion, companion + size(record)) == (54, 69, 59, 74)
    projected = Eq(Rec(S(v), R(x), L(a)), S(L(a)))
    carry = Eq(B(B(L(x), R(x)), projected[1]), B(x, projected[2]))
    boundary = quant("all", ["a"], quant("ex", ["b"], quant("all", ["x"],
        K4(Eq(S(x), b), carry, Eq(x, b), Eq(b, a)))))
    expanded = quant("all", ["a"], quant("ex", ["b"], quant("all", ["x"],
        And(Imp(Eq(S(x), b), carry), Imp(carry, Imp(Eq(x, b), Eq(b, a)))))))
    assert size(carry) == size(projected) + 8
    assert size(boundary) == size(projected) + 22
    assert size(expanded) == 2 * size(projected) + 33
    return {"components": values, "main_arithmetic": main, "main_with_K4": main + 15,
            "companion_arithmetic": companion, "companion_with_K4": companion + 15,
            "carry_overhead": 8, "boundary_overhead": 22,
            "ordinary_boundary_formula": "2F+33"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("syntax_results.json"))
    args = parser.parse_args()
    rows = []
    for m in range(1, 31):
        g, inner, h = family(m)
        assert (size(g), size(inner), size(h)) == (m + 1, m + 5, 5 * m + 5)
        immediate = substitute(g, {"v": Rec(g, ZERO, v), "w": ZERO})
        endpoint = substitute(g, {"v": v, "w": ZERO})
        assert (size(immediate), size(endpoint)) == (2 * m + 4, m + 1)
        assert size(immediate) >= size(inner)
        for name, rules in OLD_RULES.items():
            normal, trace = normalize(h, rules)
            assert normal == h and trace == [], (m, name)
        assert normalize(h, OLD_UNION) == (h, [])
        new_normal, trace = normalize(h, NEW_RULES)
        assert new_normal == v
        # Innermost postorder sees horizontal routing before its enclosing
        # projected-route redex, then removes the outer projection by beta.
        assert Counter(step["rule"] for step in trace) == {
            "fused_initialization": 1, "horizontal": m, "pair_beta": m}
        assert normalize(new_normal, NEW_RULES) == (v, [])
        old = modules(h)
        raw = {name: sum(size(f) for f in packet) for name, packet in old.items()}
        factored = {name: sum(factored_formula_size(f) for f in packet)
                    for name, packet in old.items()}
        expected = {"D": 20*m+35, "G3": 15*m+36, "T4": 10*m+42,
                    "F": 15*m+27, "L": 15*m+32, "N4": 10*m+37}
        assert raw == expected and factored == raw
        if m >= 2:
            assert min(factored.values()) == 10*m+37
        image = {name: sum(size(prune_formula(f)) for f in packet)
                 for name, packet in old.items()}
        for name in old:
            assert raw[name] - image[name] >= size(h) + 2
        assert prune_term(Rec(h, n, a)) == a
        rows.append({"m": m, "descriptor_size": size(h),
                     "old_normalizers_irreducible": True,
                     "immediate_step_size": size(immediate),
                     "fused_endpoint_size": size(endpoint),
                     "new_rewrite_steps": len(trace),
                     "old_generous_modules": raw, "exact_image_modules": image,
                     "canonical_extra_module_size": 0,
                     "source_call_size": size(Rec(h, n, a)), "canonical_call_size": 1})

    # Substitution changes arguments but not local variables in the label.
    frozen_example = Rec(B(v, w), v, w)
    substituted = substitute(frozen_example, {"v": S(ZERO), "w": ZERO})
    assert substituted == Rec(B(v, w), S(ZERO), ZERO)
    # A retained image symbol may have a code containing an erased source name.
    identity_body = family(3)[2]
    retained_body = B(Rec(identity_body, v, w), v)
    retained_call = Rec(retained_body, n, a)
    image_call = prune_term(retained_call)
    assert image_call[1] == retained_body
    assert prune_term(retained_body) == B(w, v)
    assert size(image_call) <= size(retained_call)
    result = {
        "status": "passed", "family_parameters": "m=1,...,30",
        "prefix_and_boundary_checks": prefix_checks(),
        "frozen_substitution_checked": True,
        "original_image_labels_retained": True,
        "families": rows,
        "limits": "Finite syntax/count/rewrite diagnostics only; not a Lean/Rocq formalization or a proof of the full bi-interpretability theorem.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "families": len(rows),
                      "prefixes": [54, 69, 59, 74], "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
