A SMALLER PRESENTATION OF INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
2 November 2026
===================================================================

Start with report.pdf. Complete editable LaTeX is report.tex + sections/.
AXIOMS.txt gives the complete compact specification and scope of claims.

RESULTS
1. Four fixed arithmetic sentences of full-tree cost 54, or 69 with the
   same paid four-place logical definition as the current drafts.
   Two effective schemas complete the theory. Full first-order iPRA
   bi-interpretability and equiconsistency are proved in the report.
2. The fixed-prefix saving has an explicit tradeoff: a lifted boundary
   costs F+22 rather than F+14. A separately specified 74-node companion
   preserves the shorter boundary shape.
3. Fused initialization detects an infinite family of identity recursors
   missed by every current normalizer. The source-wise exact image
   construction never increases a finite source axiom packet, so it
   preserves each source's own supported lower-envelope comparison.

The comparison is not an encoding-independent shortestness theorem.
For a fully supported packet with k>=1 matched induction boundaries,
the 69-node variant is 8k-5 nodes larger than the 74-node companion before
sharing. Prefer the identity-pruned image of the suitable current source
for actual export size; the shifted-origin kernel is a separate tradeoff.
No global nonincrease is claimed for the pairing-only canonical term
compiler: its virtual zero/counter recursors may expand.
Genuine falsity and the full intuitionistic first-order language are kept.

CONTENTS
report.tex, report.pdf, sections/     Complete report and proofs.
AXIOMS.txt                           Exact theory and improvement interfaces.
artifacts/verify_syntax.py            Frozen-descriptor syntax and count checks.
artifacts/verify_models.py            Explicitly bounded numerical diagnostics.
artifacts/*_results.json             Reproducible check outputs.
artifacts/mathematical_review.txt     Dependency and claim review.
build.py                             Runs checks; compiles until references settle.
provenance/source_manifest.json      Pinned sources and verified archive hashes.
provenance/reference_axioms/         Exact source AXIOMS specifications.
SHA256SUMS.txt                       Hashes of delivered files.

REBUILD
    python3 build.py
Requires Python 3.10+ and pdflatex with standard AMS/Latin Modern packages.
No network or Python third-party package is needed by the two checkers.
Their finite checks do not constitute a Lean/Rocq proof of the metatheorem.

SOURCES
VladimirReshetnikov/ProveIt at
d171b68f822c40d6e7884d4911ac4b03edd0048c.
All five current and all four immediate archived ZIPs were inspected.
All five current drafts contain improvements over the archived iteration.
The repository was read only; this deliverable does not modify it.
