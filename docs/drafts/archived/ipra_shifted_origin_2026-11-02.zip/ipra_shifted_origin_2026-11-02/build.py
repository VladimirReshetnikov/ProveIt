#!/usr/bin/env python3
"""Regenerate finite diagnostics and compile the accompanying LaTeX report.

Requires Python 3.10+ and pdflatex with standard AMS/Latin Modern packages.
The checks are not a formalization of the infinite metatheorem.
"""
from pathlib import Path
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(command, log_name):
    completed = subprocess.run(command, cwd=ROOT, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ROOT / 'artifacts' / log_name).write_text(completed.stdout)
    if completed.returncode:
        print(completed.stdout)
        raise SystemExit(completed.returncode)
    return completed

def main():
    run([sys.executable, 'artifacts/verify_syntax.py'], 'syntax_stdout.txt')
    run([sys.executable, 'artifacts/verify_models.py'], 'models_stdout.txt')
    latex = shutil.which('pdflatex')
    if not latex:
        raise SystemExit('pdflatex is required to compile report.tex.')
    def reference_state():
        return tuple((ROOT/name).read_bytes() if (ROOT/name).exists() else b''
                     for name in ('report.aux', 'report.toc', 'report.out'))
    for pass_no in (1, 2, 3, 4):
        previous_references = reference_state()
        result = run([latex, '-interaction=nonstopmode', '-halt-on-error', 'report.tex'],
                     f'latex_pass_{pass_no}.txt')
        unstable = (previous_references != reference_state() or
                    'Label(s) may have changed' in result.stdout or
                    'There were undefined references' in result.stdout)
        if pass_no >= 2 and not unstable:
            break
    if unstable:
        raise SystemExit('Cross references did not stabilize within four passes.')
    data = {'syntax_checks': 'passed', 'bounded_model_checks': 'passed',
            'pdflatex_passes': pass_no, 'pdf_exists': (ROOT/'report.pdf').is_file(),
            'formal_metatheorem_verified_by_proof_assistant': False}
    (ROOT/'artifacts/build_results.json').write_text(json.dumps(data, indent=2)+'\n')
    print(json.dumps(data, indent=2))

if __name__ == '__main__':
    main()
