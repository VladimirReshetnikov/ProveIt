iPRA: certified zero stability
Prepared for Vladimir Reshetnikov, 3 November 2026

Main deliverable
  ipra_zero_stability.pdf

Result
  A canonical first-order intuitionistic presentation with the existing
  smallest bare arithmetic core: separation and zero-or-successor coverage.
  The new admission test certifies updates that preserve zero and uses the
  derived identity R_h(n,0,c)=0 to eliminate redundant recursor descriptions.

  The report proves full whole-carrier bi-interpretability and
  equiconsistency with iPRA, including internal identity round trips.
  A separate source-wise image construction never enlarges any finite
  packet of axioms from any of the three surviving current proposals.

  A common strict family has descriptor size 7j+5 and recursor-call size
  7j+8; the new canonical image is the initializer alone.

Accounting
  Fixed arithmetic: 16 nodes.
  With the paid K4 connective record: 31.
  With the paid K3 record: 28, with a one-node increase per boundary.
  The explicit generated-Q constructor bootstrap adds 16 nodes.
  These are finite support counts, not the size of the infinite theory.

  The fixed arithmetic core is not smaller than the current best one.
  The strict advance is the certified description pruning and its exact
  finite-axiom-packet guarantee. Absolute minimality and universal
  proof-length improvement are not claimed.

Contents
  report.tex                 Main source and raw-theory proofs
  sections_new.tex           Canonical pruning, strict family, image theorem
  sections_comparison.tex    Module costs, independence, research questions
  ipra_zero_stability.pdf    Compiled report
  SPECIFICATION.txt          Compact exact theory specification
  verify.py                  Standard-library finite diagnostics
  verification_results.json  Recorded diagnostic results
  build.py                   Rebuild/check/package script
  build_logs/                Compilation and diagnostic output
  source_audit.csv           Current/archive comparison and inclusion decisions
  source_provenance.json     Pinned source metadata and hashes
  SHA256SUMS.txt             Checksums of packaged files, excluding itself

Rebuild
  python3 build.py

  This runs the diagnostics and compiles three times with pdflatex.
  Python 3.10 or later and a LaTeX installation with the packages in report.tex
  are required. Verification uses only the Python standard library.

  python3 build.py --archive

  This also creates the ZIP in the package directory's parent.

Verification scope
  The Python checks construct actual syntax trees, preserve frozen
  descriptor scope, verify exact costs and representative reductions,
  and exhaustively test the bounded scan over small Boolean predicates.
  They are not a proof-assistant formalization of the universal
  mathematical theorems. The complete mathematical proofs are in the PDF.

Source snapshot
  Repository: VladimirReshetnikov/ProveIt
  Commit: 62494ae438e7518d7d9d3b923b506d2223672cdc
  Three current archives and five archived archives were inspected.
  All three current proposals survive the requested improvement filter.
  Original source archives are referenced, not duplicated in this package.
