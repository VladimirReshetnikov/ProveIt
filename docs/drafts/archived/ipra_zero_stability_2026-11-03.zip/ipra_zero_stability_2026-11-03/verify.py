#!/usr/bin/env python3
"""Finite syntax and scan diagnostics for the iPRA zero-stability report.

Python 3.10+; standard library only.  Run ``python3 verify.py`` to write
``verification_results.json`` next to this script.  These tests are NOT a
formalization of the interpretation theorem, internal induction, or the
infinite canonical language.  Those claims require the written proofs.

The AST charges every stored descriptor recursively at every recursor
occurrence.  Active substitution and rewriting never enter a descriptor.
There is no implicit sharing in the size function.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Callable, Iterable


@dataclass(frozen=True)
class Node:
    kind: str
    value: object = None
    children: tuple["Node", ...] = ()


@dataclass(frozen=True)
class Recursor:
    body: Node
    parameter_count: int
    label: str = field(default="R", compare=False, hash=False)


def var(name: str) -> Node:
    return Node("var", name)


ZERO = Node("zero")
BOTTOM = Node("bottom")
V, W = var("v"), var("w")


def suc(term: Node) -> Node:
    return Node("fun", "S", (term,))


def call(symbol: Recursor, *arguments: Node) -> Node:
    assert len(arguments) == symbol.parameter_count + 2
    return Node("rec", symbol, tuple(arguments))


def eq(left: Node, right: Node) -> Node:
    return Node("eq", None, (left, right))


def connective(name: str, *arguments: Node) -> Node:
    return Node("connective", name, tuple(arguments))


def conjunction(left: Node, right: Node) -> Node:
    return connective("and", left, right)


def disjunction(left: Node, right: Node) -> Node:
    return connective("or", left, right)


def implies(left: Node, right: Node) -> Node:
    return connective("implies", left, right)


def bind(kind: str, names: Iterable[str], body: Node) -> Node:
    for name in reversed(tuple(names)):
        body = Node(kind, name, (body,))
    return body


def forall(names: Iterable[str], body: Node) -> Node:
    return bind("forall", names, body)


def exists(names: Iterable[str], body: Node) -> Node:
    return bind("exists", names, body)


@lru_cache(maxsize=None)
def size(node: Node) -> int:
    charge = 1 + sum(size(child) for child in node.children)
    if node.kind == "rec":
        assert isinstance(node.value, Recursor)
        charge += size(node.value.body)
    return charge


@lru_cache(maxsize=None)
def serialize(node: Node) -> str:
    if node.kind == "var":
        return str(node.value)
    if node.kind == "zero":
        return "0"
    if node.kind == "bottom":
        return "bottom"
    if node.kind == "rec":
        symbol = node.value
        assert isinstance(symbol, Recursor)
        head = f"R[{serialize(symbol.body)};m={symbol.parameter_count}]"
    elif node.kind in {"forall", "exists"}:
        head = f"{node.kind} {node.value}"
    else:
        head = str(node.value) if node.value is not None else node.kind
    return head + "(" + ",".join(serialize(x) for x in node.children) + ")"


def substitute(term: Node, mapping: dict[str, Node]) -> Node:
    """Simultaneous active TERM substitution, with frozen symbol descriptors."""
    assert term.kind not in {"forall", "exists"}, "Use only on terms."
    if term.kind == "var":
        return mapping.get(str(term.value), term)
    return Node(term.kind, term.value,
                tuple(substitute(child, mapping) for child in term.children))


def occurrences(term: Node, name: str) -> int:
    return int(term.kind == "var" and term.value == name) + sum(
        occurrences(child, name) for child in term.children
    )


def parameter_variables(m: int) -> tuple[Node, ...]:
    return tuple(var(f"c{i}") for i in range(m))


def replace_successor_counter(term: Node, replacement: Node) -> tuple[Node, int]:
    """Replace active literal S(w) subtrees, returning their count."""
    if term == suc(W):
        return replacement, 1
    output = []
    total = 0
    for child in term.children:
        changed, count = replace_successor_counter(child, replacement)
        output.append(changed)
        total += count
    return Node(term.kind, term.value, tuple(output)), total


def ordinary_module(symbol: Recursor) -> Node:
    a, n = var("a"), var("n")
    params = parameter_variables(symbol.parameter_count)
    body = substitute(symbol.body, {"v": call(symbol, n, a, *params), "w": n})
    initial = eq(call(symbol, ZERO, a, *params), a)
    step = forall(("n",), eq(call(symbol, suc(n), a, *params), body))
    return forall(("a", *(str(p.value) for p in params)), conjunction(initial, step))


def graph_module(symbol: Recursor) -> Node:
    a, n, u = var("a"), var("n"), var("u")
    params = parameter_variables(symbol.parameter_count)
    initial = implies(eq(n, ZERO), eq(u, a))
    step = eq(call(symbol, suc(n), a, *params),
              substitute(symbol.body, {"v": u, "w": n}))
    graph = implies(eq(call(symbol, n, a, *params), u), conjunction(initial, step))
    return forall(("a", "n", *(str(p.value) for p in params), "u"), graph)


def table_module(symbol: Recursor) -> Node:
    a, n, u, x, y = (var(name) for name in ("a", "n", "u", "x", "y"))
    params = parameter_variables(symbol.parameter_count)
    replaced, _ = replace_successor_counter(symbol.body, x)
    dagger = substitute(replaced, {"v": u, "w": n})
    table = connective(
        "K4", conjunction(eq(x, n), eq(y, u)),
        eq(call(symbol, x, a, *params), y), eq(x, suc(n)), eq(y, dagger)
    )
    formula = conjunction(implies(eq(n, ZERO), eq(u, a)), forall(("x", "y"), table))
    return forall(("a", "n", *(str(p.value) for p in params)), exists(("u",), formula))


def boundary(matrix: Node, m: int = 0, expanded: bool = False) -> Node:
    t, b, x = var("t"), var("b"), var("x")
    arguments = (eq(suc(x), b), matrix, eq(x, b), eq(b, t))
    if expanded:
        aa, bb, cc, dd = arguments
        body = conjunction(implies(aa, bb), implies(bb, implies(cc, dd)))
    else:
        body = connective("K4", *arguments)
    return forall(("t", *(f"c{i}" for i in range(m))),
                  exists(("b",), forall(("x",), body)))


A = Recursor(suc(V), 0, "A")
Q = Recursor(W, 0, "Q")
M = Recursor(call(A, V, V), 0, "M")


def root_reducts(term: Node, zero_flags: frozenset[Recursor]) -> set[Node]:
    """Certified basic rules only, each subjected to strict full-size descent."""
    result: set[Node] = set()
    if term.kind != "rec":
        return result
    symbol = term.value
    assert isinstance(symbol, Recursor)
    counter, initial, *params = term.children
    environment = {f"c{i}": p for i, p in enumerate(params)}
    if counter == ZERO:
        result.add(initial)
    if counter == suc(ZERO):
        # Fused initialization: its raw endpoint can shrink even when the
        # intermediate ordinary successor unfolding grows.
        result.add(substitute(symbol.body, {**environment, "v": initial, "w": ZERO}))
    if counter.kind == "fun" and counter.value == "S":
        prior = counter.children[0]
        result.add(substitute(symbol.body, {
            **environment, "v": call(symbol, prior, initial, *params), "w": prior
        }))
    if symbol == A and initial == ZERO:
        result.add(counter)
    if symbol in zero_flags and initial == ZERO:
        result.add(ZERO)
    return {candidate for candidate in result if size(candidate) < size(term)}


@lru_cache(maxsize=None)
def one_step_reducts(term: Node, zero_flags: frozenset[Recursor]) -> frozenset[Node]:
    result = root_reducts(term, zero_flags)
    for index, child in enumerate(term.children):
        for changed in one_step_reducts(child, zero_flags):
            children = term.children[:index] + (changed,) + term.children[index + 1:]
            result.add(Node(term.kind, term.value, children))
    # Deliberately do not visit term.value.body when term.kind == "rec".
    return frozenset(result)


@lru_cache(maxsize=None)
def normal_form(term: Node, zero_flags: frozenset[Recursor] = frozenset()) -> Node:
    """Least fully charged reachable term, with serialization as tie-breaker."""
    candidates = [term]
    candidates.extend(normal_form(child, zero_flags)
                      for child in one_step_reducts(term, zero_flags))
    return min(candidates, key=lambda item: (size(item), serialize(item)))


def check_fixed_records() -> dict:
    z, y = var("z"), var("y")
    separation = implies(eq(ZERO, suc(ZERO)), BOTTOM)
    coverage = forall(("z",), exists(("y",), disjunction(eq(z, ZERO), eq(z, suc(y)))))
    aa, bb, cc, dd = (var(x) for x in ("P", "Q", "C", "D"))
    k3_lhs = connective("K3", aa, bb, dd)
    k3_rhs = conjunction(implies(aa, bb), implies(bb, dd))
    k4_lhs = connective("K4", aa, bb, cc, dd)
    k4_rhs = conjunction(implies(aa, bb), implies(bb, implies(cc, dd)))
    # One definition marker, actual left tree, actual right tree.
    records = {
        "separation": size(separation), "coverage": size(coverage),
        "K3_definition": 1 + size(k3_lhs) + size(k3_rhs),
        "K4_definition": 1 + size(k4_lhs) + size(k4_rhs),
    }
    assert records == {"separation": 6, "coverage": 10,
                       "K3_definition": 12, "K4_definition": 15}
    records["arithmetic_fixed_support"] = 16
    records["fixed_with_K3"] = 28
    records["fixed_with_K4"] = 31
    return records


def descriptor_catalogue(m: int) -> list[Node]:
    result = [ZERO, V, W, suc(V), suc(W), suc(suc(W)),
              call(A, V, V), call(A, W, V), call(Q, V, ZERO),
              call(M, W, V), call(M, call(A, W, V), ZERO),
              call(A, suc(W), call(Q, V, suc(W))),
              call(A, call(M, suc(W), V), call(Q, W, V))]
    if m:
        params = parameter_variables(m)
        result.extend([*params, call(A, params[0], V),
                       call(M, suc(W), params[-1]),
                       call(A, call(A, V, params[0]), params[-1])])
        nested = Recursor(call(A, V, var("c0")), 1, "nested")
        result.append(call(nested, W, V, params[0]))
    return result


def check_modules() -> dict:
    descriptor_count = 0
    equations_checked = 0
    largest_descriptor = 0
    nested_descriptor_count = 0
    for m in range(4):
        for body in descriptor_catalogue(m):
            symbol = Recursor(body, m)
            h, k = size(body), occurrences(body, "v")
            replaced, j = replace_successor_counter(body, var("x"))
            assert size(replaced) == h - j
            dagger = substitute(replaced, {"v": var("u"), "w": var("n")})
            lhs = substitute(dagger, {"x": suc(var("n"))})
            rhs = substitute(body, {"v": var("u"), "w": var("n")})
            assert lhs == rhs
            observed = (size(ordinary_module(symbol)), size(graph_module(symbol)),
                        size(table_module(symbol)))
            expected = (3*h + 3*m + 13 + k*(h+m+2),
                        3*h + 3*m + 22, 2*h-j + 2*m + 32)
            assert observed == expected, (m, serialize(body), observed, expected)
            matrix = eq(substitute(body, {"v": var("x"), "w": var("t")}), ZERO)
            f = size(matrix)
            assert size(boundary(matrix, m)) == f + m + 14
            assert size(boundary(matrix, m, expanded=True)) == 2*f + m + 17
            descriptor_count += 1
            equations_checked += 3
            largest_descriptor = max(largest_descriptor, h)
            nested_descriptor_count += int(any_nested_rec(body))
    return {"descriptors": descriptor_count, "parameter_counts": [0, 1, 2, 3],
            "module_size_identities": equations_checked,
            "boundary_size_identities": 2*descriptor_count,
            "dagger_substitution_identities": descriptor_count,
            "descriptors_with_stored_subdescriptors": nested_descriptor_count,
            "largest_descriptor_size": largest_descriptor}


def any_nested_rec(term: Node) -> bool:
    return term.kind == "rec" or any(any_nested_rec(x) for x in term.children)


def check_frozen_scopes() -> dict:
    term = call(M, V, W)
    changed = substitute(term, {"v": ZERO, "w": suc(ZERO)})
    assert changed == call(M, ZERO, suc(ZERO))
    assert changed.value is M and M.body == call(A, V, V)
    # The inner descriptor contains a visible base redex, but an outer active
    # rewrite must not rewrite that frozen descriptor or change the symbol.
    hidden = Recursor(call(A, ZERO, V), 0, "hidden_redex")
    opaque = call(hidden, var("n"), var("a"))
    assert normal_form(hidden.body) == V
    assert not one_step_reducts(opaque, frozenset())
    assert normal_form(opaque) == opaque
    assert occurrences(call(M, W, ZERO), "v") == 0
    assert occurrences(call(M, W, ZERO), "w") == 1
    # Descriptor cost is charged anew at each call, regardless of Python object
    # identity or hash caching.  The cache saves runtime, never AST cost.
    duplicated = call(A, call(M, W, ZERO), call(M, W, ZERO))
    expected = 1 + size(A.body) + 2*size(call(M, W, ZERO))
    assert size(duplicated) == expected
    return {"active_substitution_preserves_descriptor_identity": True,
            "frozen_redex_is_not_rewritten": True,
            "frozen_variable_occurrences_are_not_active": True,
            "duplicated_descriptor_occurrences_are_fully_charged": True}


def check_zero_family() -> dict:
    zero_test = substitute(M.body, {"v": ZERO})
    # The new flag is proved using earlier rules only; M is not already flagged.
    assert zero_test == call(A, ZERO, ZERO)
    assert normal_form(zero_test) == ZERO
    flags = frozenset((M,))
    s = W
    cases = []
    for j in range(1, 21):
        s = call(M, s, ZERO)
        body = call(A, s, V)
        symbol = Recursor(body, 0, f"h{j}")
        assert size(s) == 7*j+1
        assert size(body) == 7*j+5
        assert occurrences(body, "v") == 1 and occurrences(body, "w") == 1
        assert size(call(symbol, var("n"), var("a"))) == 7*j+8
        assert not one_step_reducts(body, frozenset())
        assert normal_form(body) == body
        new_body = normal_form(body, flags)
        assert new_body == V
        # A symbol whose canonical update is v is interpreted homomorphically
        # by its initial argument, not by normalizing arbitrary formulas.
        image = var("a") if new_body == V else call(Recursor(new_body, 0), var("n"), var("a"))
        assert serialize(image) == "a"
        modules = {"ordinary": size(ordinary_module(symbol)),
                   "G0": size(graph_module(symbol)), "T": size(table_module(symbol))}
        assert modules == {"ordinary": 28*j+35, "G0": 21*j+37, "T": 14*j+42}
        cases.append({"j": j, "s_size": size(s), "descriptor_size": size(body),
                      "original_call_size": 7*j+8, "old_irreducible": True,
                      "new_body": serialize(new_body), "image_call": serialize(image),
                      "unshared_module_sizes": modules})
    support_matrix = eq(call(M, var("x"), ZERO), ZERO)
    support = {"A_module": size(ordinary_module(A)),
               "M_module": size(ordinary_module(M)),
               "M_zero_boundary": size(boundary(support_matrix))}
    assert support == {"A_module": 23, "M_module": 42, "M_zero_boundary": 24}
    assert size(support_matrix) == 10
    support["total"] = sum(support.values())
    assert support["total"] == 89
    support["M_complete_graph_module"] = size(graph_module(M))
    assert support["M_complete_graph_module"] == 37
    support["optimized_total"] = (
        support["A_module"] + support["M_complete_graph_module"]
        + support["M_zero_boundary"]
    )
    assert support["optimized_total"] == 84
    return {"earlier_rank_zero_test": serialize(zero_test),
            "earlier_rank_normal_form": "0", "zero_flag_uses_no_own_rule": True,
            "cases": cases, "support": support,
            "scope": "Strict family in the shared direct-parameter language; not a global proof-size minimum."}


def scan(predicate: Callable[[int, int, tuple[int, ...]], bool],
         length: int, target: int, parameters: tuple[int, ...] = ()) -> int:
    boundary_value = 0
    for step in range(length):
        if predicate(boundary_value, target, parameters):
            boundary_value = step + 1
    return boundary_value


def scan_invariants(predicate: Callable[[int], bool], target: int) -> tuple[int, int]:
    d = 0
    checks = 0
    for step in range(target + 1):
        assert 0 <= d <= step
        assert d == 0 or predicate(d - 1)
        assert not predicate(d) or d == step
        checks += 3
        if step < target and predicate(d):
            d = step + 1
    return d, checks


def check_scan() -> dict:
    predicates = implications = invariants = 0
    for target in range(13):
        for mask in range(1 << (target + 1)):
            def predicate(x: int, mask: int = mask) -> bool:
                return bool((mask >> x) & 1)
            b, checked = scan_invariants(predicate, target)
            invariants += checked
            assert b == scan(lambda x, frozen_target, params: predicate(x), target, target)
            for probe in range(target + 1):
                assert probe + 1 != b or predicate(probe)
                assert not (predicate(probe) and probe == b) or b == target
                implications += 2
            predicates += 1
    assert predicates == 16382 and implications == 393220
    # The numerical target is passed unchanged to the predicate during each
    # scan.  These examples depend on target and on additional parameters.
    dependent_tests = 0
    families = [
        lambda x, t, p: x < t,
        lambda x, t, p: x <= t // 2,
        lambda x, t, p: (x + t + p[0]) % 3 != 0,
        lambda x, t, p: x != (2*t + p[0]) % (t + 1),
    ]
    for target in range(25):
        for parameter in range(4):
            for predicate in families:
                recorded_targets: list[int] = []
                def checked_predicate(x: int, t: int, p: tuple[int, ...]) -> bool:
                    recorded_targets.append(t)
                    return predicate(x, t, p)
                b = scan(checked_predicate, target, target, (parameter,))
                assert all(t == target for t in recorded_targets)
                fixed = lambda x: predicate(x, target, (parameter,))
                assert b == scan_invariants(fixed, target)[0]
                for probe in range(target + 1):
                    assert probe + 1 != b or fixed(probe)
                    assert not (fixed(probe) and probe == b) or b == target
                dependent_tests += 1
    # Negative control: replacing the frozen target by the moving scan index
    # is detected.  At t=3, E(x,t) := x<t, that error returns b=2.
    wrong_b = 0
    for step in range(3):
        if wrong_b < step:
            wrong_b = step + 1
    assert wrong_b == 2 and wrong_b < 3 and wrong_b != 3
    return {"horizons": [0, 12], "all_boolean_predicates": predicates,
            "pointwise_boundary_implications": implications,
            "scan_invariant_checks": invariants,
            "target_and_parameter_dependent_cases": dependent_tests,
            "moving_target_negative_control_detected": True,
            "negative_control": {"target": 3, "incorrect_boundary": wrong_b,
                                 "predicate": "x < target", "failed_edge": "E(b) implies b=target"},
            "limitation": "Finite exhaustive diagnostics; the written proof establishes the unbounded schema inside iPRA."}


def run() -> dict:
    return {
        "status": "passed",
        "verification_kind": "Finite AST accounting, finite rewrite diagnostics, and finite exhaustive scan checks",
        "not_verified_by_this_program": [
            "The internal induction derivations and intuitionistic soundness of every inference",
            "The infinite canonical-language and bi-interpretation theorems",
            "An absolute shortest axiomatization or universal proof-length domination",
        ],
        "fixed_records": check_fixed_records(),
        "module_accounting": check_modules(),
        "frozen_scopes": check_frozen_scopes(),
        "zero_stability_family": check_zero_family(),
        "boundary_scan": check_scan(),
    }


if __name__ == "__main__":
    output = Path(__file__).resolve().with_name("verification_results.json")
    results = run()
    output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": results["status"],
        "descriptors": results["module_accounting"]["descriptors"],
        "module_size_identities": results["module_accounting"]["module_size_identities"],
        "strict_family_cases": len(results["zero_stability_family"]["cases"]),
        "finite_predicates": results["boundary_scan"]["all_boolean_predicates"],
        "boundary_implications": results["boundary_scan"]["pointwise_boundary_implications"],
        "support_packet": results["zero_stability_family"]["support"]["total"],
        "results_file": output.name,
    }, indent=2))
