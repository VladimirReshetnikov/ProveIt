#!/usr/bin/env python3
"""Reproduce the diagnostics, PDF, checksums, and optional ZIP."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
JOB = "ipra_zero_stability"
PACKAGE = "ipra_zero_stability_2026-11-03"
LOGS = ROOT / "build_logs"


def run_logged(command: list[str], filename: str) -> str:
    result = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False
    )
    (LOGS / filename).write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout[-12000:], file=sys.stderr)
        raise SystemExit(f"Command failed; see build_logs/{filename}")
    return result.stdout


def package_files() -> list[Path]:
    excluded_suffixes = {".aux", ".out", ".toc", ".log", ".pyc"}
    return sorted(
        p for p in ROOT.rglob("*")
        if p.is_file()
        and "__pycache__" not in p.parts
        and not any(part.startswith(".") for part in p.relative_to(ROOT).parts)
        and p.suffix not in excluded_suffixes
        and not (p.parent == LOGS and p.suffix == ".pdf")
        and p.name != "SHA256SUMS.txt"
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    LOGS.mkdir(exist_ok=True)
    run_logged([sys.executable, "verify.py"], "verification.txt")
    compiler = shutil.which("pdflatex")
    if not compiler:
        raise SystemExit("pdflatex is required to rebuild the PDF.")
    for number in range(1, 4):
        output = run_logged(
            [compiler, "-interaction=nonstopmode", "-halt-on-error",
             f"-jobname={JOB}", "-output-directory=build_logs", "report.tex"],
            f"compile_pass_{number}.txt",
        )
    fatal_warnings = [
        "Overfull", "There were undefined references",
        "Rerun to get cross-references right",
    ]
    for warning in fatal_warnings:
        if warning in output:
            raise SystemExit(f"Resolve PDF warning before release: {warning}")
    shutil.copyfile(LOGS / f"{JOB}.pdf", ROOT / f"{JOB}.pdf")
    files = package_files()
    checksums = [
        f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}"
        for p in files
    ]
    (ROOT / "SHA256SUMS.txt").write_text(
        "\n".join(checksums) + "\n", encoding="utf-8"
    )
    if args.archive:
        destination = ROOT.parent / f"{PACKAGE}.zip"
        with zipfile.ZipFile(
            destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
        ) as archive:
            for path in files + [ROOT / "SHA256SUMS.txt"]:
                archive.write(
                    path, f"{PACKAGE}/{path.relative_to(ROOT).as_posix()}"
                )
        print(f"Archive: {destination}")
    print(f"PDF: {ROOT / f'{JOB}.pdf'}")
    print(f"Checksummed files: {len(files)}")


if __name__ == "__main__":
    main()
