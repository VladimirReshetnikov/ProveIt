SIMPLER PRESENTATIONS OF PRA
2 November 2026

START HERE
  pra_axiomatization.pdf  Complete mathematical report.
  report.tex       Main source; includes sections/*.tex.
  AXIOMS.txt       Standalone exact specifications and comparison scope.
  build.py         Rechecks the artifacts and compiles the PDF.

MAIN FINDINGS
1. Structurally simple theory T:
   Initial symbols 0,S; one generated family R_h of binary initialized
   recursors; fixed axiom 0 != S0; one-parameter induction for native
   quantifier-free formulas. A successor-variable formulation makes a
   complete induction instance cost 4F+12 full syntax nodes, where F is
   the full size of the native formula. For shared R-only formulas this
   saves at least 10 full nodes over the best compatible current-draft
   mask module and removes the equality-bit/mask primitives. This is a
   familiar induction-based theory, not a historical novelty claim;
   it does not uniformly improve the ACTIVE-size metric.

2. Strict improvement in BOTH archived module metrics:
   Fuse the mask definition and witness under the same forall a,n exists b
   prefix. With m,T the active/full size of the stored payload, F12 costs
   m+19 / 4T+21, versus the favorable incumbent m+20 / 4T+22.
   F13 costs m+20 / 4T+22 and needs a 24-node fixed basis instead of 30.
   The improvement is exactly one node per complete mask module.

3. DF12 uses initial symbols only 0 and binary D, reconstructing successor
   as D(x,x). It combines an explicitly credited existing discriminator
   construction with the tail-only descriptor convention and new fusion.
   Its fixed seed costs 24 and its fused module m+19 / 4T+21 after all
   successor and equality-test abbreviations have been expanded.

4. A direct Boolean boundary equality removes the mask constructor.
   It costs 4m+i+6 / 4T+i+8 (i=input occurrences); for B=chi(x,a), 19/21.
   This is useful for small tests, not a uniform improvement over T or F12.

CALIBRATION
Every stated complete theory is bi-interpretable and equiconsistent with
FIRST-ORDER PRA: finite PR-description functions and full finite-parameter
quantifier-free induction. Interpretations use the whole carrier, native
equality, and identity round trips. The proofs work classically and also
intuitionistically, separately. They are effective INFINITE schemas.

VERIFICATION
verification/ contains a custom first-order natural-deduction checker,
explicit proof certificates, AST size checks, finite Boolean scan checks,
and their exact result logs. The checker is not Lean or Rocq. The full
language/coding/compiler/bi-interpretation metatheorem is proved in the
paper, not completely encoded in that checker. Its README states scope
and credits the source checker from the current numbered pointwise draft.

REBUILD
  python3 build.py
Requires Python 3 and pdflatex with the standard packages in report.tex.
Python verification itself uses the standard library only. To run a checker
alone, invoke its script under verification/ from any working directory.

SOURCE SNAPSHOT
VladimirReshetnikov/ProveIt, docs/drafts
Commit: 4d5474f10e00412135d659dc7a1f74fc6457656a
Six archives; each downloaded archive matched its Git blob SHA.
provenance/ records exact filenames, paths, SHA-256 hashes, and the audit.
No repository files were modified by this research task.

LIMITS
No language-independent simplicity lower bound is known or claimed here.
Raw-input serializer outputs sometimes equal the already-minimal atom 0=0.
The strict claims use explicit complete-module workloads. Arbitrary axiom
batching changes tree costs; no global optimum follows. Further research
questions and two rejected reductions are documented in the report.
