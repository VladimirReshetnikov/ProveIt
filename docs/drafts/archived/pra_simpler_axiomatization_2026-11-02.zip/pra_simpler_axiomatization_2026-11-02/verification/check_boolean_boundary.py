#!/usr/bin/env python3
"""Finite Boolean checks for the equality-boundary witness construction.

These checks supplement the written PRA proof. They do not establish the
unbounded arithmetic theorem or the complete bi-interpretation.
"""
from itertools import product
import json
from pathlib import Path


def q(left, right):
    assert left in (0, 1) and right in (0, 1)
    return right if left == 0 else 0


def zero_edge(bits):
    # E(0) can be 1 only when B(0)=1 and B(1)=0. Then E(1)=0.
    return 1 if bits[0] == 1 and bits[1] == 0 else 0


def main():
    zero_cases = 0
    for bits in product((0, 1), repeat=3):
        b = zero_edge(bits)
        assert q(bits[b + 1], bits[b]) == 0
        zero_cases += 1
    target_checks = 0
    invariant_checks = 0
    length = 12
    for bits in product((0, 1), repeat=length):
        candidate = 0
        for n in range(length - 1):
            if bits[0] == 1:
                assert bits[candidate] == 1
                assert bits[candidate + 1] == 0 or candidate == n
                invariant_checks += 1
            endpoint = q(bits[n], bits[0])
            b = candidate if endpoint == 1 else zero_edge(bits)
            edge = q(bits[b + 1], bits[b])
            assert edge == endpoint
            target_checks += 1
            if bits[candidate + 1] == 1:
                candidate = n + 1
    result = {
        "status": "VERIFIED",
        "zero_edge_cases": zero_cases,
        "boolean_sequences": 2 ** length,
        "sequence_length": length,
        "target_checks": target_checks,
        "guarded_scan_invariant_checks": invariant_checks,
        "scope": "finite Boolean sanity checks; the unbounded PRA proof is in the paper",
    }
    Path(__file__).with_name("boolean_boundary_results.json").write_text(
        json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
