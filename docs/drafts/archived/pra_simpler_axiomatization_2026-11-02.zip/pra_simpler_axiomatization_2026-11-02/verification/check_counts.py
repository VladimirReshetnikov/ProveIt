#!/usr/bin/env python3
"""Independent syntax-tree counts for fused pointwise-mask axioms.

This checks finite syntactic counts, not arithmetic truth or PRA equivalence.
Frozen descriptions are counted recursively at every generated-symbol call.
They are never changed by substitution in active arguments.
Python 3 standard library only.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Symbol:
    name: str
    arity: int
    description: "Term | None" = None


@dataclass(frozen=True)
class Term:
    symbol: Symbol | None
    arguments: tuple["Term", ...] = ()
    variable: str | None = None

    def __post_init__(self):
        if self.symbol is None:
            assert self.variable is not None and not self.arguments
        else:
            assert self.variable is None
            assert len(self.arguments) == self.symbol.arity


def var(name):
    return Term(None, variable=name)


def app(symbol, *arguments):
    return Term(symbol, tuple(arguments))


def size_term(term, full=False):
    if term.symbol is None:
        return 1
    descriptor = term.symbol.description
    return (1 + sum(size_term(t, full) for t in term.arguments)
            + (size_term(descriptor, True) if full and descriptor is not None else 0))


def substitute(term, replacements):
    if term.symbol is None:
        return replacements.get(term.variable, term)
    # The symbol, including its frozen description, is retained verbatim.
    return app(term.symbol, *(substitute(t, replacements) for t in term.arguments))


def eq(left, right):
    return ("eq", left, right)


def conjunction(left, right):
    return ("and", left, right)


def quantify(kind, name, body):
    assert kind in ("forall", "exists")
    return (kind, name, body)


def size_formula(formula, full=False):
    tag = formula[0]
    if tag == "false":
        return 1
    if tag == "eq":
        return 1 + size_term(formula[1], full) + size_term(formula[2], full)
    if tag in ("and", "or", "imp"):
        return 1 + size_formula(formula[1], full) + size_formula(formula[2], full)
    if tag in ("forall", "exists"):
        return 1 + size_formula(formula[2], full)
    raise ValueError(tag)


ZERO = Symbol("0", 0)
SUCC = Symbol("S", 1)
CHI = Symbol("chi", 2)
zero = app(ZERO)
v, w, a, n, b = map(var, ("v", "w", "a", "n", "b"))
Q = Symbol("Q", 2, w)
Z = Symbol("Z", 2, zero)


def clauses(body, shifted):
    C = Symbol("C", 2, body)
    exposed = substitute(body, {"v": n, "w": a})
    definition_matrix = eq(app(C, n, a), app(Z, exposed, n))
    witness_input = app(SUCC, b) if shifted else b
    witness_matrix = eq(app(C, app(Q, app(C, witness_input, a), n), a), zero)
    definition = quantify("forall", "a", quantify("forall", "n", definition_matrix))
    witness = quantify("forall", "a", quantify("forall", "n",
                       quantify("exists", "b", witness_matrix)))
    fused = quantify("forall", "a", quantify("forall", "n",
                     quantify("exists", "b", conjunction(definition_matrix, witness_matrix))))
    return definition, witness, fused


def input_occurrences(term):
    if term.symbol is None:
        return int(term.variable == "v")
    return sum(input_occurrences(t) for t in term.arguments)


def direct_boundary(body, equality_variant):
    evaluate = lambda x: substitute(body, {"v": x, "w": a})
    edge = app(Q, evaluate(app(SUCC, b)), evaluate(b))
    endpoint = app(Q, evaluate(n), evaluate(zero))
    matrix = eq(edge, endpoint) if equality_variant else eq(app(Q, edge, endpoint), zero)
    return quantify("forall", "a", quantify("forall", "n",
                    quantify("exists", "b", matrix)))


def four_clause_sizes(body, shifted):
    R = Symbol("R", 2, body)
    base = eq(app(R, zero, a), a)
    exposed = substitute(body, {"v": app(R, n, a), "w": n})
    step = eq(app(R, app(SUCC, n), a), exposed)
    definition, witness, _ = clauses(body, shifted)
    definition_matrix = definition[2][2]
    witness_matrix = witness[2][2][2]
    closed_base = quantify("forall", "a", base)
    closed_step = quantify("forall", "a", quantify("forall", "n", step))
    fused_matrix = conjunction(base, conjunction(step, conjunction(definition_matrix, witness_matrix)))
    fused = quantify("forall", "a", quantify("forall", "n",
                     quantify("exists", "b", fused_matrix)))
    separate_sizes = tuple(sum(size_formula(f, full) for f in
                         (closed_base, closed_step, definition, witness)) for full in (False, True))
    fused_sizes = tuple(size_formula(fused, full) for full in (False, True))
    return separate_sizes, fused_sizes


def fixed_seed_checks():
    x, y = var("x"), var("y")
    one = app(SUCC, zero)
    chi = lambda r, s: app(CHI, r, s)
    neq = lambda r, s: ("imp", eq(r, s), ("false",))
    close = lambda f: quantify("forall", "x", quantify("forall", "y", f))
    sep = neq(zero, one)
    bit = close(conjunction(eq(chi(x, x), one), ("or", eq(x, y), eq(chi(x, y), zero))))
    part = quantify("forall", "x", quantify("exists", "y", neq(chi(x, zero), chi(x, app(SUCC, y)))))
    D = Symbol("D", 2)
    dd = lambda r, s: app(D, r, s)
    off = close(("or", eq(x, y), eq(dd(x, y), zero)))
    dpart = quantify("forall", "x", quantify("exists", "y", neq(dd(x, zero), dd(x, dd(y, y)))))
    result = {name: tuple(size_formula(f, full) for full in (False, True))
              for name, f in (("Sep", sep), ("Bit", bit), ("Part", part),
                              ("Off", off), ("DPart", dpart))}
    assert result == {"Sep": (6, 6), "Bit": (18, 18), "Part": (12, 12),
                      "Off": (11, 11), "DPart": (13, 13)}
    return result


def substitute_qf(formula, replacements):
    if formula[0] == "false":
        return formula
    if formula[0] == "eq":
        return eq(substitute(formula[1], replacements), substitute(formula[2], replacements))
    assert formula[0] in ("and", "or", "imp")
    return (formula[0], substitute_qf(formula[1], replacements),
            substitute_qf(formula[2], replacements))


def formula_input_occurrences(formula):
    if formula[0] == "false":
        return 0
    if formula[0] == "eq":
        return input_occurrences(formula[1]) + input_occurrences(formula[2])
    return formula_input_occurrences(formula[1]) + formula_input_occurrences(formula[2])


def native_induction(formula, bound_successor):
    x, y = var("x"), var("y")
    evaluate = lambda t: substitute_qf(formula, {"v": t, "w": a})
    if bound_successor:
        step = quantify("forall", "x", quantify("forall", "y",
               ("imp", eq(y, app(SUCC, x)), ("imp", evaluate(x), evaluate(y)))))
    else:
        step = quantify("forall", "x", ("imp", evaluate(x), evaluate(app(SUCC, x))))
    return quantify("forall", "a", ("imp", conjunction(evaluate(zero), step),
                     quantify("forall", "n", evaluate(n))))


def example_bodies():
    # Deliberately include multiple active-slot occurrences and nested stored
    # descriptions, so full size is not merely active size with a constant.
    result = [v, w, zero, app(SUCC, v), app(CHI, v, w), app(Q, v, w),
              app(Z, app(CHI, v, w), v)]
    for level in range(6):
        previous = result[-1]
        R = Symbol("R_" + str(level), 2, previous)
        result.append(app(R, app(CHI, v, w), app(Q, v, w)))
        result.append(app(Q, app(CHI, result[-1], v), result[-1]))
    return result


def main():
    rows, direct_rows, four_rows, native_rows = [], [], [], []
    for index, body in enumerate(example_bodies()):
        m, T = size_term(body), size_term(body, True)
        i = input_occurrences(body)
        for shifted in (False, True):
            definition, witness, fused = clauses(body, shifted)
            d = tuple(size_formula(definition, full) for full in (False, True))
            wsize = tuple(size_formula(witness, full) for full in (False, True))
            f = tuple(size_formula(fused, full) for full in (False, True))
            shift = int(shifted)
            assert d == (m + 8, 2 * T + 9)
            assert wsize == (12 + shift, 2 * T + 13 + shift)
            assert f == (m + 19 + shift, 4 * T + 21 + shift)
            assert tuple(d[i] + wsize[i] - f[i] for i in range(2)) == (1, 1)
            rows.append({"body_index": index, "shifted": shifted,
                         "body_active": m, "body_full": T,
                         "definition": d, "witness": wsize, "fused": f})
            four_separate, four_fused = four_clause_sizes(body, shifted)
            assert four_separate == (33 + shift + 2 * m + 2 * i,
                                     35 + shift + 2 * i + (7 + i) * T)
            assert four_fused == (31 + shift + 2 * m + 2 * i,
                                 33 + shift + 2 * i + (7 + i) * T)
            assert tuple(four_separate[k] - four_fused[k] for k in range(2)) == (2, 2)
            four_rows.append({"body_index": index, "shifted": shifted,
                              "separate": four_separate, "fused": four_fused})
        # Counts are purely syntactic; Booleanity is a separate side condition
        # for the arithmetic validity of these direct-boundary instances.
        old_db = direct_boundary(body, False)
        new_db = direct_boundary(body, True)
        old_size = tuple(size_formula(old_db, full) for full in (False, True))
        new_size = tuple(size_formula(new_db, full) for full in (False, True))
        assert old_size == (4 * m + i + 8, 4 * T + i + 11)
        assert new_size == (4 * m + i + 6, 4 * T + i + 8)
        assert tuple(old_size[k] - new_size[k] for k in range(2)) == (2, 3)
        direct_rows.append({"body_index": index, "body_active": m, "body_full": T,
                            "input_occurrences": i, "implication_boundary": old_size,
                            "equality_boundary": new_size})
        formula = eq(body, w) if index % 2 == 0 else (
            "imp", ("and", eq(body, v), eq(v, w)), ("or", eq(v, zero), ("false",)))
        p, P = size_formula(formula), size_formula(formula, True)
        j = formula_input_occurrences(formula)
        ordinary = tuple(size_formula(native_induction(formula, False), full)
                         for full in (False, True))
        bound = tuple(size_formula(native_induction(formula, True), full)
                      for full in (False, True))
        assert ordinary == (4 * p + j + 6, 4 * P + j + 6)
        assert bound == (4 * p + 12, 4 * P + 12)
        assert tuple(min(ordinary[k], bound[k]) for k in range(2)) == (
            4 * p + 6 + min(j, 6), 4 * P + 6 + min(j, 6))
        native_rows.append({"body_index": index, "formula_active": p, "formula_full": P,
                            "input_occurrences": j, "standard_induction": ordinary,
                            "bound_successor_induction": bound})
    # Frozen-descriptor negative control: active substitution must not replace v
    # inside a generated symbol's stored body.
    R = Symbol("frozen_control", 2, v)
    old = app(R, v, w)
    new = substitute(old, {"v": app(SUCC, v)})
    assert new.symbol is old.symbol and new.symbol.description == v
    assert size_term(new, True) == size_term(old, True) + 1
    result = {"status": "VERIFIED", "checked_instances": len(rows),
              "counts": {
                  "fused_shifted": {"active": "m+20", "full": "4T+22"},
                  "fused_unshifted": {"active": "m+19", "full": "4T+21"},
                  "direct_equality_boundary": {"active": "4m+i+6", "full": "4T+i+8"}},
              "direct_boundary_checked_instances": len(direct_rows),
              "four_clause_checked_instances": len(four_rows),
              "native_induction_checked_instances": len(native_rows),
              "fixed_seed_counts": fixed_seed_checks(),
              "scope": "actual syntax-tree counts; not a proof of arithmetic equivalence",
              "rows": rows, "direct_boundary_rows": direct_rows, "four_clause_rows": four_rows,
              "native_induction_rows": native_rows}
    destination = Path(__file__).with_name("count_results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("rows", "direct_boundary_rows", "four_clause_rows", "native_induction_rows")}, indent=2))


if __name__ == "__main__":
    main()
