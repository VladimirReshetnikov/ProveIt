#!/usr/bin/env python3
"""A small first-order natural-deduction certificate checker.

Adapted from the checker in the inspected pra_pointwise_masks_2026-11-02(1)
archive. This version adds conjunction, implication introduction, existential
introduction, equality reflexivity, and uninterpreted predicates; it checks
five EXACT statements.
The certificate and its builder are untrusted. This is not Lean or a full
formalization of PRA. See README.txt for provenance and precise scope.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path


class InvalidProof(Exception):
    pass


SIGNATURE = {"0": 0, "S": 1, "Q": 2, "F": 1, "G": 1}
PREDICATES = {"D": 2, "W": 3}
RULES = {
    "assumption": {"rule", "name"},
    "forall_intro": {"rule", "variable", "body"},
    "forall_elim": {"rule", "proof", "term"},
    "exists_intro": {"rule", "variable", "formula", "term", "proof"},
    "exists_elim": {"rule", "proof", "variable", "assumption", "body"},
    "and_intro": {"rule", "left", "right"},
    "and_elim": {"rule", "proof", "side"},
    "or_elim": {"rule", "proof", "left", "right"},
    "imp_intro": {"rule", "assumption", "formula", "body"},
    "imp_elim": {"rule", "implication", "premise"},
    "eq_refl": {"rule", "term"},
    "eq_subst": {"rule", "equality", "premise", "variable", "template"},
    "false_elim": {"rule", "proof", "conclusion"},
}


def require(condition, message):
    if not condition:
        raise InvalidProof(message)


def variable_name(value):
    require(isinstance(value, str) and value.isidentifier(), "Invalid variable name")


def check_term(term):
    require(isinstance(term, list) and term, "Term must be a nonempty list")
    if term[0] == "var":
        require(len(term) == 2, "Variable has wrong length")
        variable_name(term[1])
        return
    require(term[0] == "app" and len(term) >= 2, "Expected function application")
    symbol = term[1]
    require(isinstance(symbol, str) and symbol in SIGNATURE, "Unknown function symbol")
    require(len(term) == 2 + SIGNATURE[symbol], "Wrong function arity")
    for argument in term[2:]:
        check_term(argument)


def check_formula(formula):
    require(isinstance(formula, list) and formula, "Formula must be a nonempty list")
    tag = formula[0]
    if tag == "false":
        require(len(formula) == 1, "Falsity has wrong length")
    elif tag == "eq":
        require(len(formula) == 3, "Equality has wrong length")
        check_term(formula[1])
        check_term(formula[2])
    elif tag == "pred":
        require(len(formula) >= 2 and formula[1] in PREDICATES, "Unknown predicate")
        require(len(formula) == 2 + PREDICATES[formula[1]], "Wrong predicate arity")
        for argument in formula[2:]:
            check_term(argument)
    elif tag in ("and", "or", "imp"):
        require(len(formula) == 3, "Binary connective has wrong length")
        check_formula(formula[1])
        check_formula(formula[2])
    elif tag in ("forall", "exists"):
        require(len(formula) == 3, "Quantifier has wrong length")
        variable_name(formula[1])
        check_formula(formula[2])
    else:
        raise InvalidProof("Unknown formula constructor")


def term_variables(term):
    if term[0] == "var":
        return {term[1]}
    return set().union(*(term_variables(t) for t in term[2:]))


def free_variables(formula):
    tag = formula[0]
    if tag == "false":
        return set()
    if tag == "eq":
        return term_variables(formula[1]) | term_variables(formula[2])
    if tag == "pred":
        return set().union(*(term_variables(t) for t in formula[2:]))
    if tag in ("and", "or", "imp"):
        return free_variables(formula[1]) | free_variables(formula[2])
    return free_variables(formula[2]) - {formula[1]}


def all_variables(formula):
    tag = formula[0]
    if tag in ("false", "eq", "pred"):
        return free_variables(formula)
    if tag in ("and", "or", "imp"):
        return all_variables(formula[1]) | all_variables(formula[2])
    return all_variables(formula[2]) | {formula[1]}


def substitute_term(term, name, replacement):
    if term[0] == "var":
        return replacement if term[1] == name else term
    return ["app", term[1], *(substitute_term(t, name, replacement) for t in term[2:])]


def substitute(formula, name, replacement):
    tag = formula[0]
    if tag == "false":
        return formula
    if tag == "eq":
        return ["eq", substitute_term(formula[1], name, replacement),
                substitute_term(formula[2], name, replacement)]
    if tag == "pred":
        return ["pred", formula[1],
                *(substitute_term(t, name, replacement) for t in formula[2:])]
    if tag in ("and", "or", "imp"):
        return [tag, substitute(formula[1], name, replacement),
                substitute(formula[2], name, replacement)]
    binder, body = formula[1], formula[2]
    if binder == name or name not in free_variables(body):
        return formula
    if binder in term_variables(replacement):
        forbidden = all_variables(body) | term_variables(replacement) | {name}
        index = 0
        while "fresh_" + str(index) in forbidden:
            index += 1
        fresh = "fresh_" + str(index)
        body = substitute(body, binder, ["var", fresh])
        binder = fresh
    return [tag, binder, substitute(body, name, replacement)]


def context_variables(context):
    return set().union(*(free_variables(f) for f in context.values()))


def extend(context, name, formula):
    require(isinstance(name, str) and name and name not in context,
            "An assumption name must be fresh")
    return {**context, name: formula}


class Checker:
    def __init__(self):
        self.rule_count = {}

    def derive(self, node, context):
        require(isinstance(node, dict), "Proof node must be an object")
        rule = node.get("rule")
        require(isinstance(rule, str) and rule in RULES, "Unknown proof rule")
        require(set(node) == RULES[rule], "Unexpected or missing rule fields")
        self.rule_count[rule] = self.rule_count.get(rule, 0) + 1
        if rule == "assumption":
            require(isinstance(node["name"], str) and node["name"] in context,
                    "Unbound assumption")
            return context[node["name"]]
        if rule == "forall_intro":
            name = node["variable"]
            variable_name(name)
            require(name not in context_variables(context),
                    "Universal eigenvariable occurs in an open assumption")
            return ["forall", name, self.derive(node["body"], context)]
        if rule == "forall_elim":
            premise = self.derive(node["proof"], context)
            require(premise[0] == "forall", "Universal elimination needs forall")
            check_term(node["term"])
            return substitute(premise[2], premise[1], node["term"])
        if rule == "exists_intro":
            variable_name(node["variable"])
            check_formula(node["formula"])
            check_term(node["term"])
            premise = self.derive(node["proof"], context)
            require(substitute(node["formula"], node["variable"], node["term"]) == premise,
                    "Existential introduction instance mismatch")
            return ["exists", node["variable"], node["formula"]]
        if rule == "exists_elim":
            premise = self.derive(node["proof"], context)
            require(premise[0] == "exists", "Existential elimination needs exists")
            name = node["variable"]
            variable_name(name)
            require(name not in context_variables(context) | free_variables(premise),
                    "Existential eigenvariable is not fresh")
            instance = substitute(premise[2], premise[1], ["var", name])
            inner = extend(context, node["assumption"], instance)
            conclusion = self.derive(node["body"], inner)
            require(name not in free_variables(conclusion),
                    "Existential eigenvariable escapes in the conclusion")
            return conclusion
        if rule == "and_intro":
            return ["and", self.derive(node["left"], context),
                    self.derive(node["right"], context)]
        if rule == "and_elim":
            premise = self.derive(node["proof"], context)
            require(premise[0] == "and", "Conjunction elimination needs and")
            require(type(node["side"]) is int and node["side"] in (1, 2),
                    "Conjunction side must be 1 or 2")
            return premise[node["side"]]
        if rule == "or_elim":
            premise = self.derive(node["proof"], context)
            require(premise[0] == "or", "Disjunction elimination needs or")
            conclusions = []
            for key, formula in (("left", premise[1]), ("right", premise[2])):
                branch = node[key]
                require(isinstance(branch, dict) and set(branch) == {"assumption", "body"},
                        "Malformed disjunction branch")
                conclusions.append(self.derive(branch["body"],
                                   extend(context, branch["assumption"], formula)))
            require(conclusions[0] == conclusions[1],
                    "Disjunction branches have different conclusions")
            return conclusions[0]
        if rule == "imp_intro":
            check_formula(node["formula"])
            conclusion = self.derive(node["body"],
                         extend(context, node["assumption"], node["formula"]))
            return ["imp", node["formula"], conclusion]
        if rule == "imp_elim":
            implication = self.derive(node["implication"], context)
            premise = self.derive(node["premise"], context)
            require(implication[0] == "imp", "Implication elimination needs imp")
            require(implication[1] == premise, "Implication antecedent mismatch")
            return implication[2]
        if rule == "eq_subst":
            equality = self.derive(node["equality"], context)
            premise = self.derive(node["premise"], context)
            require(equality[0] == "eq", "Equality substitution needs equality")
            variable_name(node["variable"])
            check_formula(node["template"])
            require(substitute(node["template"], node["variable"], equality[1]) == premise,
                    "Equality-substitution source formula mismatch")
            return substitute(node["template"], node["variable"], equality[2])
        if rule == "eq_refl":
            check_term(node["term"])
            return ["eq", node["term"], node["term"]]
        if rule == "false_elim":
            premise = self.derive(node["proof"], context)
            require(premise == ["false"], "Falsity elimination needs falsity")
            check_formula(node["conclusion"])
            return node["conclusion"]
        raise InvalidProof("Unreachable unknown rule")


def var(name):
    return ["var", name]


def app(symbol, *arguments):
    return ["app", symbol, *arguments]


def eq(left, right):
    return ["eq", left, right]


def forall(name, body):
    return ["forall", name, body]


def fusion_formulas():
    a, n, b = map(var, ("a", "n", "b"))
    d, w = ["pred", "D", a, n], ["pred", "W", a, n, b]
    fused = forall("a", forall("n", ["exists", "b", ["and", d, w]]))
    separated = ["and", forall("a", forall("n", d)),
                 forall("a", forall("n", ["exists", "b", w]))]
    return fused, separated


def native_induction_formulas():
    a, x, y, n = map(var, ("a", "x", "y", "n"))
    zero = app("0")
    predicate = lambda t: ["pred", "D", t, a]
    standard_step = forall("x", ["imp", predicate(x), predicate(app("S", x))])
    bound_step = forall("x", forall("y", ["imp", eq(y, app("S", x)),
                                          ["imp", predicate(x), predicate(y)]]))
    conclusion = forall("n", predicate(n))
    induction = lambda step: forall("a", ["imp", ["and", predicate(zero), step], conclusion])
    return induction(standard_step), induction(bound_step)


def exact_statement(theorem):
    if theorem == "fusion_equivalence":
        fused, separated = fusion_formulas()
        return {}, ["and", ["imp", fused, separated], ["imp", separated, fused]]
    if theorem == "native_induction_equivalence":
        standard, bound = native_induction_formulas()
        return {}, ["and", ["imp", standard, bound], ["imp", bound, standard]]
    if theorem == "equality_boundary_induction_kernel":
        x, y, n, b = map(var, ("x", "y", "n", "b"))
        zero = app("0")
        one = app("S", zero)
        f = lambda t: app("F", t)
        q = lambda t, u: app("Q", t, u)
        hypotheses = {
            "separation": ["imp", eq(zero, one), ["false"]],
            "q_zero": forall("y", eq(q(zero, y), y)),
            "q_one": forall("y", eq(q(one, y), zero)),
            "bits": forall("x", ["or", eq(f(x), zero), eq(f(x), one)]),
            "base": eq(f(zero), one),
            "progress": forall("x", ["imp", eq(f(x), one), eq(f(app("S", x)), one)]),
            "boundary_witness": forall("n", ["exists", "b",
                eq(q(f(app("S", b)), f(b)), q(f(n), f(zero)))]),
        }
        return hypotheses, forall("n", eq(f(n), one))
    require(theorem in ("shifted_induction_kernel", "unshifted_induction_kernel"),
            "Unknown exact theorem")
    x, y, n, b = map(var, ("x", "y", "n", "b"))
    zero = app("0")
    sx = app("S", x)
    f = lambda t: app("F", t)
    shifted = theorem == "shifted_induction_kernel"
    marker_input = sx if shifted else x
    witness_input = app("S", b) if shifted else b
    hypotheses = {
        "nonzero": forall("x", ["imp", eq(sx, zero), ["false"]]),
        "q_zero": forall("y", eq(app("Q", zero, y), y)),
        "q_succ": forall("x", forall("y", eq(app("Q", sx, y), x))),
        "range": forall("x", ["or", eq(f(marker_input), zero),
                               eq(f(marker_input), marker_input)]),
        "progress": forall("x", ["imp", eq(f(x), zero), eq(f(sx), zero)]),
        "fused_witness": forall("n", ["exists", "b", ["and",
            eq(f(n), app("G", n)), eq(f(app("Q", f(witness_input), n)), zero)]]),
    }
    if not shifted:
        hypotheses["coverage"] = forall("x", ["or", eq(x, zero),
                                    ["exists", "y", eq(x, app("S", y))]])
    return hypotheses, forall("n", eq(f(n), zero))


def verify(certificate):
    fields = {"format", "theorem", "signature", "predicates", "hypotheses", "conclusion", "proof"}
    require(isinstance(certificate, dict) and set(certificate) == fields,
            "Unexpected certificate fields")
    require(certificate["format"] == "fused-mask-natural-deduction-v2", "Wrong format")
    require(certificate["signature"] == SIGNATURE, "Wrong function signature")
    require(certificate["predicates"] == PREDICATES, "Wrong predicate signature")
    hypotheses, conclusion = exact_statement(certificate["theorem"])
    require(certificate["hypotheses"] == hypotheses, "Not the exact advertised hypotheses")
    require(certificate["conclusion"] == conclusion, "Not the exact advertised conclusion")
    for formula in hypotheses.values():
        check_formula(formula)
    check_formula(conclusion)
    checker = Checker()
    require(checker.derive(certificate["proof"], hypotheses) == conclusion,
            "Final derived conclusion mismatch")
    return checker


def self_tests(certificate):
    x, y, z = map(var, ("x", "y", "z"))
    zero = app("0")
    p, q = eq(x, zero), eq(y, zero)
    ref = lambda name: {"rule": "assumption", "name": name}
    tests = [
        ("unbound assumption", ref("missing"), {}),
        ("universal eigenvariable", {"rule": "forall_intro", "variable": "x",
          "body": ref("p")}, {"p": p}),
        ("escaping existential", {"rule": "exists_elim", "proof": ref("e"),
          "variable": "y", "assumption": "local", "body": ref("local")},
          {"e": ["exists", "x", p]}),
        ("wrong equality source", {"rule": "eq_subst", "equality": ref("e"),
          "premise": ref("p"), "variable": "z", "template": eq(z, zero)},
          {"e": eq(x, y), "p": q}),
        ("explosion without false", {"rule": "false_elim", "proof": ref("p"),
          "conclusion": q}, {"p": p}),
        ("wrong implication premise", {"rule": "imp_elim", "implication": ref("i"),
          "premise": ref("p")}, {"i": ["imp", p, q], "p": q}),
        ("wrong conjunction index", {"rule": "and_elim", "proof": ref("c"), "side": 0},
          {"c": ["and", p, q]}),
        ("non-conjunction elimination", {"rule": "and_elim", "proof": ref("p"), "side": 1},
          {"p": p}),
        ("wrong existential instance", {"rule": "exists_intro", "variable": "x",
          "formula": p, "term": y, "proof": ref("p")}, {"p": p}),
        ("implication assumption shadowing", {"rule": "imp_intro", "assumption": "p",
          "formula": q, "body": ref("p")}, {"p": p}),
        ("ill-formed equality reflexivity", {"rule": "eq_refl", "term": ["app", "S"]}, {}),
    ]
    for label, proof, context in tests:
        try:
            Checker().derive(proof, context)
        except InvalidProof:
            continue
        raise InvalidProof("Accepted negative control: " + label)
    captured = substitute(forall("y", eq(x, y)), "x", y)
    require(free_variables(captured) == {"y"}, "Capture-avoidance failed")
    damaged = copy.deepcopy(certificate)
    damaged["conclusion"] = ["false"]
    try:
        verify(damaged)
    except InvalidProof:
        pass
    else:
        raise InvalidProof("Accepted changed theorem statement")
    return len(tests) + 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificates", nargs="*")
    args = parser.parse_args()
    paths = [Path(p) for p in args.certificates] or sorted(Path(__file__).parent.glob("*_proof.json"))
    require(bool(paths), "No certificates found")
    results = []
    for path in paths:
        certificate = json.loads(path.read_text())
        checker = verify(certificate)
        controls = self_tests(certificate)
        results.append({"file": path.name, "theorem": certificate["theorem"],
                        "status": "VERIFIED", "proof_nodes": sum(checker.rule_count.values()),
                        "rule_counts": dict(sorted(checker.rule_count.items())),
                        "negative_and_capture_controls_passed": controls})
    result = {"status": "VERIFIED", "logic": "intuitionistic first-order natural deduction with equality",
              "certificates": results,
              "scope": "logical fusion, mask kernels, equality-boundary kernel, and native-induction equivalence only; not full PRA bi-interpretation"}
    Path(__file__).with_name("kernel_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (InvalidProof, OSError, ValueError, TypeError, KeyError) as error:
        raise SystemExit("REJECTED: " + str(error))
