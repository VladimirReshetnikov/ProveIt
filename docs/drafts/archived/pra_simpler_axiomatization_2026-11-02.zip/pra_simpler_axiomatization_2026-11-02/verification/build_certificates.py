#!/usr/bin/env python3
"""Construct proof trees; only check_kernel.py verifies their correctness."""
import json
from pathlib import Path
from check_kernel import (SIGNATURE, PREDICATES, app, eq, exact_statement,
                          fusion_formulas, native_induction_formulas, var)


def ref(name):
    return {"rule": "assumption", "name": name}


def ui(proof, term):
    return {"rule": "forall_elim", "proof": proof, "term": term}


def ug(name, body):
    return {"rule": "forall_intro", "variable": name, "body": body}


def ei(name, formula, term, proof):
    return {"rule": "exists_intro", "variable": name, "formula": formula,
            "term": term, "proof": proof}


def ee(proof, name, assumption, body):
    return {"rule": "exists_elim", "proof": proof, "variable": name,
            "assumption": assumption, "body": body}


def ai(left, right):
    return {"rule": "and_intro", "left": left, "right": right}


def ae(proof, side):
    return {"rule": "and_elim", "proof": proof, "side": side}


def ii(assumption, formula, body):
    return {"rule": "imp_intro", "assumption": assumption,
            "formula": formula, "body": body}


def mp(implication, premise):
    return {"rule": "imp_elim", "implication": implication, "premise": premise}


def rewrite(equality, premise, template):
    return {"rule": "eq_subst", "equality": equality, "premise": premise,
            "variable": "z", "template": template}


def cases(proof, left_name, left, right_name, right):
    return {"rule": "or_elim", "proof": proof,
            "left": {"assumption": left_name, "body": left},
            "right": {"assumption": right_name, "body": right}}


def explode(contradiction, target):
    return {"rule": "false_elim", "proof": contradiction, "conclusion": target}


def reflexivity(term):
    return {"rule": "eq_refl", "term": term}


def fusion_proof():
    a, n, b, c = map(var, ("a", "n", "b", "c"))
    d = ["pred", "D", a, n]
    w = ["pred", "W", a, n, b]
    fused, separated = fusion_formulas()
    source = ui(ui(ref("fused"), a), n)
    all_d = ug("a", ug("n", ee(source, "c", "chosen_d", ae(ref("chosen_d"), 1))))
    all_w = ug("a", ug("n", ee(source, "c", "chosen_w",
                ei("b", w, c, ae(ref("chosen_w"), 2)))))
    forward = ii("fused", fused, ai(all_d, all_w))
    d_proof = ui(ui(ae(ref("separated"), 1), a), n)
    w_proof = ui(ui(ae(ref("separated"), 2), a), n)
    join = ei("b", ["and", d, w], c, ai(d_proof, ref("chosen")))
    reverse = ii("separated", separated,
                 ug("a", ug("n", ee(w_proof, "c", "chosen", join))))
    return ai(forward, reverse)


def shifted_kernel():
    n, b, z = map(var, ("n", "b", "z"))
    zero = app("0")
    sb = app("S", b)
    f = lambda t: app("F", t)
    q = lambda t, u: app("Q", t, u)
    target = eq(f(n), zero)
    witness = ae(ref("chosen_witness"), 2)
    witness_context, zero_context = eq(f(q(z, n)), zero), eq(f(z), zero)
    left = rewrite(ref("zero_case"), witness, witness_context)
    left = rewrite(ui(ref("q_zero"), n), left, zero_context)
    right = rewrite(ref("successor_case"), witness, witness_context)
    right = rewrite(ui(ui(ref("q_succ"), b), n), right, zero_context)
    right = mp(ui(ref("progress"), b), right)
    right = rewrite(ref("successor_case"), right, eq(z, zero))
    right = explode(mp(ui(ref("nonzero"), b), right), target)
    split = cases(ui(ref("range"), b), "zero_case", left, "successor_case", right)
    return ug("n", ee(ui(ref("fused_witness"), n), "b", "chosen_witness", split))


def unshifted_kernel():
    n, b, c, z = map(var, ("n", "b", "c", "z"))
    zero = app("0")
    sc = app("S", c)
    f = lambda t: app("F", t)
    q = lambda t, u: app("Q", t, u)
    target = eq(f(n), zero)
    witness = ae(ref("chosen_witness"), 2)
    witness_context, zero_context = eq(f(q(z, n)), zero), eq(f(z), zero)
    left = rewrite(ref("zero_case"), witness, witness_context)
    left = rewrite(ui(ref("q_zero"), n), left, zero_context)
    at_b = rewrite(ref("index_case"), witness, witness_context)
    at_zero = rewrite(ref("b_zero"), at_b, witness_context)
    at_zero = rewrite(ui(ref("q_zero"), n), at_zero, zero_context)
    at_succ = rewrite(ref("b_successor"), at_b, witness_context)
    at_c = rewrite(ui(ui(ref("q_succ"), c), n), at_succ, zero_context)
    at_sc = mp(ui(ref("progress"), c), at_c)
    mask_sc = rewrite(ref("b_successor"), ref("index_case"), eq(f(z), z))
    sc_zero = rewrite(mask_sc, at_sc, eq(z, zero))
    false_proof = mp(ui(ref("nonzero"), c), sc_zero)
    succ_branch = ee(ref("b_has_predecessor"), "c", "b_successor",
                     explode(false_proof, target))
    coverage_split = cases(ui(ref("coverage"), b), "b_zero", at_zero,
                           "b_has_predecessor", succ_branch)
    range_split = cases(ui(ref("range"), b), "zero_case", left,
                        "index_case", coverage_split)
    return ug("n", ee(ui(ref("fused_witness"), n), "b", "chosen_witness", range_split))


def equality_boundary_kernel():
    n, b, z = map(var, ("n", "b", "z"))
    zero = app("0")
    one = app("S", zero)
    sb = app("S", b)
    f = lambda t: app("F", t)
    q = lambda t, u: app("Q", t, u)
    edge = q(f(sb), f(b))
    target = eq(f(n), one)
    # In the failed-target branch, normalize the endpoint to 1.
    edge_one = rewrite(ref("target_zero"), ref("chosen_boundary"),
                       eq(edge, q(z, f(zero))))
    edge_one = rewrite(ui(ref("q_zero"), f(zero)), edge_one, eq(edge, z))
    edge_one = rewrite(ref("base"), edge_one, eq(edge, z))
    # If F(b)=0 then either value of F(Sb) makes the edge zero.
    edge_one_if_b_zero = rewrite(ref("b_zero"), edge_one, eq(q(f(sb), z), one))
    zero_case = rewrite(ref("sb_zero"), edge_one_if_b_zero, eq(q(z, zero), one))
    zero_case = rewrite(ui(ref("q_zero"), zero), zero_case, eq(z, one))
    zero_case = explode(mp(ref("separation"), zero_case), target)
    one_case = rewrite(ref("sb_one"), edge_one_if_b_zero, eq(q(z, zero), one))
    one_case = rewrite(ui(ref("q_one"), zero), one_case, eq(z, one))
    one_case = explode(mp(ref("separation"), one_case), target)
    b_zero_branch = cases(ui(ref("bits"), sb), "sb_zero", zero_case, "sb_one", one_case)
    # If F(b)=1 then progress makes F(Sb)=1, also making the edge zero.
    next_one = mp(ui(ref("progress"), b), ref("b_one"))
    b_one_branch = rewrite(next_one, edge_one, eq(q(z, f(b)), one))
    b_one_branch = rewrite(ui(ref("q_one"), f(b)), b_one_branch, eq(z, one))
    b_one_branch = explode(mp(ref("separation"), b_one_branch), target)
    failed_target = cases(ui(ref("bits"), b), "b_zero", b_zero_branch,
                          "b_one", b_one_branch)
    target_cases = cases(ui(ref("bits"), n), "target_zero", failed_target,
                         "target_one", ref("target_one"))
    return ug("n", ee(ui(ref("boundary_witness"), n), "b", "chosen_boundary", target_cases))


def native_induction_equivalence():
    a, x, y, z = map(var, ("a", "x", "y", "z"))
    predicate = lambda t: ["pred", "D", t, a]
    sx = app("S", x)
    standard, bound = native_induction_formulas()
    standard_premise = standard[2][1]
    bound_premise = bound[2][1]
    # Standard induction entails the bound-successor presentation: instantiate
    # y=Sx and discharge the reflexive equality to obtain its ordinary step.
    selected_step = ui(ui(ae(ref("bound_premise"), 2), x), sx)
    ordinary_implication = mp(selected_step, reflexivity(sx))
    ordinary_step = ug("x", ii("point", predicate(x),
                               mp(ordinary_implication, ref("point"))))
    conclusion = mp(ui(ref("standard"), a), ai(ae(ref("bound_premise"), 1), ordinary_step))
    forward = ii("standard", standard,
                 ug("a", ii("bound_premise", bound_premise, conclusion)))
    # Conversely, ordinary progress extends to any y identified with Sx.
    successor_instance = mp(ui(ae(ref("standard_premise"), 2), x), ref("point"))
    # Derive symmetry y=Sx -> Sx=y using only reflexivity and substitution.
    symmetry = rewrite(ref("identified"), reflexivity(y), eq(z, y))
    identified_instance = rewrite(symmetry, successor_instance, predicate(z))
    guarded_step = ug("x", ug("y", ii("identified", eq(y, sx),
                       ii("point", predicate(x), identified_instance))))
    conclusion = mp(ui(ref("bound"), a), ai(ae(ref("standard_premise"), 1), guarded_step))
    reverse = ii("bound", bound,
                 ug("a", ii("standard_premise", standard_premise, conclusion)))
    return ai(forward, reverse)


def main():
    builders = {"fusion_equivalence": fusion_proof,
                "shifted_induction_kernel": shifted_kernel,
                "unshifted_induction_kernel": unshifted_kernel,
                "equality_boundary_induction_kernel": equality_boundary_kernel,
                "native_induction_equivalence": native_induction_equivalence}
    for theorem, build in builders.items():
        hypotheses, conclusion = exact_statement(theorem)
        certificate = {"format": "fused-mask-natural-deduction-v2", "theorem": theorem,
                       "signature": SIGNATURE, "predicates": PREDICATES,
                       "hypotheses": hypotheses, "conclusion": conclusion, "proof": build()}
        path = Path(__file__).with_name(theorem + "_proof.json")
        path.write_text(json.dumps(certificate, indent=2) + "\n")
        print(path.name)


if __name__ == "__main__":
    main()
