FUSED MASKS: VERIFICATION ARTIFACTS

Run with Python 3 (standard library only):
  python3 build_certificates.py
  python3 check_kernel.py
  python3 check_counts.py
  python3 check_boolean_boundary.py

WHAT IS CHECKED

1. A closed intuitionistic first-order theorem of quantifier fusion:

   (forall a n exists b, D(a,n) and W(a,n,b))
      iff
   ((forall a n, D(a,n)) and (forall a n exists b, W(a,n,b))).

   D and W are arbitrary uninterpreted predicates of arities 2 and 3.
   In the arithmetic application D is the mask defining equation and
   W is its witness equation. The equivalence is not a finite-model test:
   its explicit natural-deduction proof tree is checked rule by rule.

2. A shifted arbitrary-carrier induction kernel, after fixing the numerical
   parameter and a mask F. Its exact hypotheses are: successor nonzeroness;
   Q(0,n)=n; Q(Sb,n)=b; F(Sb)=0 or F(Sb)=Sb; zero progress
   F(b)=0 -> F(Sb)=0; and the fused witness
     forall n exists b, F(n)=G(n) and F(Q(F(Sb),n))=0.
   The conclusion is forall n, F(n)=0. G stands for the defining right side.
   There is no coverage assumption and no induction rule in this kernel.

3. The corresponding unshifted kernel, with range F(b)=0 or F(b)=b,
   the unshifted witness, and zero-or-successor coverage. The certificate
   again concludes forall n F(n)=0.

4. The direct EQUALITY-boundary induction kernel, with a Boolean-valued F:
     forall n exists b, Q(F(Sb),F(b)) = Q(F(n),F(0)).
   Assuming 0!=1, the Boolean Q tables, F(0)=1, and local progress
   F(x)=1 -> F(Sx)=1, the checked conclusion is forall n F(n)=1.
   No arithmetic induction, coverage, or mask constructor is used.

5. A closed pure-logical equivalence between ordinary one-parameter induction
   and its bound-successor form. The latter replaces the step by
     forall x y, y=Sx -> (A(x,a) -> A(y,a)).
   A is an arbitrary uninterpreted predicate. The proof uses no arithmetic
   axiom and no induction rule: it instantiates y=Sx in one direction and
   uses equality substitution in the other. Equality reflexivity is an
   explicit checked rule; symmetry is derived from reflexivity/substitution.

The checker validates the EXACT signatures, hypotheses, and conclusions.
Only standard natural-deduction rules and capture-avoiding equality
substitution are admitted. Eigenvariable conditions are checked. The proof
builder and JSON certificates are untrusted; they cannot introduce axioms.
The checker is a small custom Python checker, not a Lean or Rocq kernel.
Its implementation can be independently read and audited.

6. Independent concrete syntax-tree counts include genuinely nested frozen
   descriptions and multiple active-slot occurrences. For body sizes m,T:
     shifted fused:   active m+20, full 4T+22;
     unshifted fused: active m+19, full 4T+21.
   Each saves exactly one node in BOTH metrics against the corresponding
   separately closed mask definition and witness. Frozen bodies are charged
   recursively at every symbol occurrence and are not affected by active
   substitution. These are finite syntax checks, not arithmetic proofs.
   The direct equality-boundary clause is also checked:
     active 4m+i+6, full 4T+i+8,
   where i counts active occurrences of the input slot. This saves two
   active and three full nodes against Q(E,V)=0. There are 38 mask-clause
   count checks and 19 direct-boundary count checks. An additional 38
   four-clause checks confirm the two-node saving when recursion base,
   recursion step, mask definition, and witness share one prefix.
   The five fixed seed clauses Sep, Bit, Part, Off, and DPart are checked
   at sizes 6, 18, 12, 11, and 13, respectively, in both metrics.
   For 19 quantifier-free native formulas with sizes f,F and i active input
   occurrences, the checker verifies standard induction at 4f+i+6 / 4F+i+6,
   and bound-successor induction at 4f+12 / 4F+12. Choosing the smaller
   syntax therefore costs 4f+6+min(i,6) / 4F+6+min(i,6).

7. Exhaustive three-bit truth tables check that a zero edge E(b)=0 exists
   at b=0 or b=1. Supplementary finite scans check the reverse witness
   construction on all 4,096 Boolean sequences of length 12, for 45,056
   target instances. This is a finite sanity check, not a substitute for
   the written unbounded quantifier-free induction proof inside PRA.

WHAT IS NOT FORMALIZED HERE

The staged language generator, Boolean truth-term compiler, numerical
pairing, general primitive-recursion compilation, PRA's reverse witness
construction, and the entire bi-interpretation metatheorem are not certified
by this artifact. Those require the written proofs in the accompanying paper.
No claim of complete machine formalization, global minimality, or historical
novelty is made by these scripts.

PROVENANCE AND MODIFICATIONS

The kernel's syntax validation, substitution, equality rule, and original
shifted induction proof follow the supplied draft:
  pra_pointwise_masks_2026-11-02(1).zip
  inner path: pra_pointwise_masks_2026-11-02/verification/kernel/
  files: check_kernel.py, build_certificate.py
  inspected Git commit: 4d5474f10e00412135d659dc7a1f74fc6457656a
  archive Git blob: 0870e7009f6c96b3b144ac4db799b1861bfde0e3

This version adds conjunction rules, existential introduction, implication
introduction, predicate atoms, exact-theorem selection, a fusion certificate,
an unshifted certificate, a direct equality-boundary induction certificate,
a native-induction equivalence certificate, equality reflexivity,
and fused-witness projection in the shifted proof.
The AST counter is newly written independently of the archived size scripts.
