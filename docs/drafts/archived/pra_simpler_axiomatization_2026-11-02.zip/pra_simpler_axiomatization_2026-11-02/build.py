#!/usr/bin/env python3
"""Recheck the local artifacts and compile the complete LaTeX report."""
from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / "verification"

def run(command, logname):
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (VERIFY / logname).write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout[-10000:])
        raise SystemExit(result.returncode)
    return result.stdout

def main():
    VERIFY.mkdir(exist_ok=True)
    for script in ("check_kernel.py", "check_counts.py", "check_boolean_boundary.py"):
        print(f"Running {script}")
        run([sys.executable, str(VERIFY / script)], script + ".log")
    if shutil.which("pdflatex") is None:
        raise SystemExit("Python verification passed; install pdflatex to build the PDF.")
    with tempfile.TemporaryDirectory(prefix="pra-latex-") as build_dir:
        for index in range(1, 4):
            print(f"Compiling PDF, pass {index}")
            output = run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                          "-file-line-error", "-output-directory=" + build_dir,
                          "report.tex"], f"latex_pass_{index}.txt")
        data = (Path(build_dir) / "report.pdf").read_bytes()
        if not data.rstrip().endswith(b"%%EOF"):
            raise SystemExit("The compiled PDF is incomplete.")
        staged = ROOT / "pra_axiomatization.pdf.part"
        staged.write_bytes(data)
        os.replace(staged, ROOT / "pra_axiomatization.pdf")
    problems = [line for line in output.splitlines()
                if "Overfull" in line or "undefined" in line.lower()
                or "LaTeX Error" in line]
    results = {"python_checks_passed": True, "pdflatex_passes": 3,
               "pdf_bytes": (ROOT / "pra_axiomatization.pdf").stat().st_size,
               "layout_or_reference_messages": problems}
    (VERIFY / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))
    if problems:
        raise SystemExit("Review the reported LaTeX messages before delivery.")

if __name__ == "__main__":
    main()
