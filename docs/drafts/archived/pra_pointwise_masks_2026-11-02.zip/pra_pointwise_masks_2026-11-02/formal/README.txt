LEAN VERIFICATION: POINTWISE MASK KERNEL

Compiler used
  Lean 4.19.0, x86_64-unknown-linux-gnu
  Lean commit 6caaee842e94 (Release)
  Only Lean's bundled Std library is imported. Mathlib is not required.

Files
  MaskKernel.lean    Checked source, including theorem dependency audits.
  MaskKernel.olean   Compiled proof object produced by Lean 4.19.0.
  verification.log  Actual successful compiler/version output.

Reproduce, from this directory with Lean 4.19.0 on PATH
  lean --version
  lean -o MaskKernel.olean MaskKernel.lean

Checked scope
  1. SelectorCore.succ_injective and succ_ne_zero derive the standard successor
     facts from Q(0,a)=a, Q(Sx,a)=x, and 0!=S0 on an arbitrary carrier.
  2. SelectorCore.shifted_extraction proves the arbitrary-carrier witness kernel:
     given successor-mask range, local zero-progress, and the shifted witness,
     every target value returns zero. No arithmetic induction or coverage is
     assumed in this theorem.
  3. MaskCore.pointwise_reflection proves exact reflection for Boolean masks on
     every carrier element, including elements not known to be zero/successors.
  4. SelectorCore.mask_induction and MaskCore.pointwise_induction prove the full
     induction implication with base/progress as local hypotheses. Numerical
     parameters can be fixed in their ambient context.
  5. MaskCore.escape_recursion_step checks the algebraic identity used by the
     escape body Z(0,h). It does not formalize the syntactic test that this body
     is non-mask when h is a mask.
  6. NaturalScan.lastReturn_invariant proves the displayed scan invariant for a
     structurally recursive candidate function on Lean's Nat.
  7. NaturalScan.parameterized_soundness verifies the shifted witness on Nat
     for every arbitrary-tail pointwise mask, with its parameter explicit.

The dependency audit reports that all seven listed main theorems depend on no
axioms. There are no sorry/admit placeholders and no custom axiom declarations.
All hypotheses in the arbitrary-carrier results are explicit theorem parameters
or fields of the stated core structures. Lean's kernel checks their conclusions
conditionally on those hypotheses; this is not a claim that the hypotheses hold
in every structure.

Scope limits
  This is a formal verification of the new mathematical kernel, not a complete
  first-order formalization of PRA or of its bi-interpretation. In particular,
  the finite description grammar, truth-term compiler, pairing/state coding,
  round-trip interpretation proof, and comparison with the six draft archives
  are justified in the paper, not verified by this Lean file.

  The reverse scan is checked here over Lean's standard Nat. The paper separately
  gives the internal PRA proof: its function is primitive recursive, its invariant
  is quantifier-free, and the proof uses quantifier-free induction. The Lean Nat
  theorem alone is not being presented as a mechanization of that internal proof
  or of its validity in nonstandard models.
