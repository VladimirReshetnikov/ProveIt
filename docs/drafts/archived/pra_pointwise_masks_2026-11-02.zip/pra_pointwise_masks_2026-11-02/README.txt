POINTWISE MASKS IN PRIMITIVE RECURSIVE ARITHMETIC
Research package prepared for Vladimir Reshetnikov
2 November 2026

MAIN RESULT

The report gives a first-order theory definitionally equivalent to PRA.
Literal bodies h(v,w)=Z(t(v,w),v) denote pointwise masks; other finite
descriptions denote initialized primitive recursion. The mask witness is

  forall a forall n exists b
    F_h(Q(F_h(S(b),a),n),a)=0.

It has 13 active nodes and 14+2W full nodes, where W includes the WHOLE
frozen body h. Its definition and witness together cost 19+m active and
20+4W full nodes. The paper proves the exact comparison with complete
incumbent latch packages, with all source and accounting qualifications.

The theorem includes both interpretations, all finite parameters, and
identity round-trip isomorphisms. It works separately in classical and
intuitionistic first-order logic. No claim of an absolute shortest theory,
finite signature, or all-alias output domination is made.

CONTENTS

  report.pdf                       Compiled research paper.
  report.tex                       Main LaTeX source.
  01_...tex through 06_...tex       Complete article sections and references.
  formal/MaskKernel.lean           Checked arbitrary-carrier kernel and scan.
  formal/MaskKernel.olean          Lean 4.19.0 compiled proof object.
  formal/verification.log          Actual successful Lean compilation/audit.
  formal/README.txt                Exact checked scope and reproduction details.
  checks/check_sizes.py            Independent syntax-tree accounting.
  checks/size_results.json         Actual count-check output.
  checks/check_semantics.py        Scan and extra-root-model finite checks.
  checks/semantic_results.json     Actual semantic-check output.
  provenance/sources.json          Immutable source URLs and archive hashes.
  build.log                       Final successful LaTeX build output.
  SHA256SUMS.txt                    Checksums of deliverable files.

REBUILD THE PAPER

  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

Alternatively run pdflatex twice (three runs if references need another pass).
The paper uses conventional TeX Live packages including amsmath, amsthm,
mathtools, lmodern, microtype, booktabs, tabularx, fancyhdr, hyperref, cleveref.

RECHECK THE ARTIFACTS

  python3 checks/check_sizes.py
  python3 checks/check_semantics.py
  cd formal
  lean --version
  lean -o MaskKernel.olean MaskKernel.lean

The formal file was verified with Lean 4.19.0 (commit 6caaee842e94).
Only its bundled Std library is required; no Mathlib download is needed.
The full syntax/interpretation theorem is a written proof, not a completed
Lean formalization. The Lean Nat scan is distinguished from the report's
internal PRA derivation. See formal/README.txt for exact scope.

SOURCE SNAPSHOT

  Repository: https://github.com/VladimirReshetnikov/ProveIt
  Commit: 41ead086f47172a707910a072eb1a722a17a85ca
  Directory: docs/drafts
  Six archives were read and their Git blob hashes verified.

This package is a new deliverable. The source repository was not modified.
