#!/usr/bin/env python3
"""Reproducible finite checks of two constructions in the paper.

These checks do not prove PRA equivalence. The infinite arguments are in
report.pdf; the arbitrary-carrier kernel is checked separately in Lean.
Only Python's standard library is needed.
"""
from itertools import product
from pathlib import Path
import json


def scan_checks():
    """Check every zero/index pattern through index 12, with f(0)=0."""
    patterns = 0
    targets = 0
    examples = []
    for bits in product((False, True), repeat=12):
        f = [0] + [i if bit else 0 for i, bit in enumerate(bits, 1)]
        candidate = 0
        for n in range(12):
            assert f[candidate] == 0
            assert f[n] == 0 or f[candidate + 1] != 0
            b = candidate
            q = n if f[b + 1] == 0 else f[b + 1] - 1
            assert f[q] == 0
            targets += 1
            if len(examples) < 4 and n == 8 and bits[:4] == (False, True, False, True):
                examples.append({"values": f, "target": n, "witness": b, "selected": q})
            if f[n] == 0:
                candidate = n
        patterns += 1
    return {"patterns": patterns, "targets": targets, "examples": examples}


ZERO = (0, 0)


def successor(x):
    return (x[0] + 1, x[1])


def select(x, fallback):
    if x == ZERO:
        return fallback
    if x[0] == 0:
        return ZERO
    return (x[0] - 1, x[1])


def root_path(x):
    height, chain = x
    if chain == 0:
        return [(i, 0) for i in range(height + 1)]
    return [ZERO] + [(i, chain) for i in range(height + 1)]


def forest_checks():
    """Finite paths in the infinite model, not a finite closed arithmetic model."""
    nodes = [(i, j) for j in range(3) for i in range(4)]
    nonzero = [x for x in nodes if x != ZERO]
    masks = 0
    targets = 0
    for bits in product((False, True), repeat=len(nonzero)):
        f = {ZERO: ZERO}
        f.update({x: x if bit else ZERO for x, bit in zip(nonzero, bits)})
        for n in nodes:
            if f[n] == ZERO:
                b = ZERO
            else:
                b = next(x for x in root_path(n) if f[x] != ZERO)
            assert f[select(f[b], n)] == ZERO
            targets += 1
        masks += 1

    def coverage_mask(x):
        coverage = x == ZERO or x == successor(select(x, ZERO))
        return ZERO if coverage else x

    extra_root = (0, 1)
    assert coverage_mask(extra_root) == extra_root
    failures = 0
    for b in nodes:
        assert coverage_mask(successor(b)) == ZERO
        q = select(coverage_mask(successor(b)), extra_root)
        assert coverage_mask(q) != ZERO
        failures += 1
    return {"prefix_nodes": len(nodes), "masks": masks,
            "unshifted_target_checks": targets,
            "shifted_counterexample_checks": failures}


def main():
    result = {
        "scope": "Finite checks only; infinite and internal-PRA proofs are in the paper.",
        "scan": scan_checks(),
        "infinite_forest_prefix": forest_checks(),
        "status": "all assertions passed",
    }
    output = Path(__file__).with_name("semantic_results.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
