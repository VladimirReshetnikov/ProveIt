#!/usr/bin/env python3
"""Reproduce syntax-tree costs for pointwise masks and six draft profiles.

This checks finite syntax and integer inequalities, not mathematical validity.
The comparison concerns complete local *formula bundles*: a defining or
computational component and its witness component.  It does not compare the
drafts' raw-input alias emitters, proof lengths, generator bytes, or the costs
of every finite fragment needed to interpret another theory.  In particular,
the new F_h is pointwise on mask descriptions, whereas the old R_h is an
iterator.  Shared description syntax is not a claim of shared semantics.

The optional Separated One/Tail and Absorbing profiles use the same raw tail
but their own literal wrappers; their wrapper costs are fully charged.  For
an optimistic old computational benchmark we take coordinatewise minima of
the valid ordinary, bound-state, and (when autonomous) right-recursion forms.
The coordinatewise minimum is a numerical benchmark, not one emitted axiom.

Only Python's standard library is required.  Run this file with Python 3.10+.
"""

from __future__ import annotations

import argparse
import json
import random
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Node:
    """An active tree node, with an optional frozen recursor description."""

    tag: str
    children: tuple["Node", ...] = ()
    label: str = ""
    description: "Node | None" = None


def var(name: str) -> Node:
    return Node("variable", label=name)


ZERO = Node("constant", label="0")
V, W = var("v"), var("w")
A, N, B, C = (var(name) for name in ("a", "n", "b", "c"))


def succ(term: Node) -> Node:
    return Node("application", (term,), "S")


def chi(left: Node, right: Node) -> Node:
    return Node("application", (left, right), "chi")


def rec(body: Node, counter: Node, seed: Node) -> Node:
    return Node("application", (counter, seed), "F/R", body)


def q(left: Node, right: Node) -> Node:
    return rec(W, left, right)


def z(left: Node, right: Node) -> Node:
    return rec(ZERO, left, right)


def eq(left: Node, right: Node) -> Node:
    return Node("equality", (left, right))


def conj(left: Node, right: Node) -> Node:
    return Node("conjunction", (left, right))


def implies(left: Node, right: Node) -> Node:
    return Node("implication", (left, right))


def quantify(kind: str, names: tuple[str, ...], formula: Node) -> Node:
    for name in reversed(names):
        formula = Node(kind, (formula,), name)
    return formula


def all_(names: tuple[str, ...], formula: Node) -> Node:
    return quantify("forall", names, formula)


def exists(name: str, formula: Node) -> Node:
    return quantify("exists", (name,), formula)


@lru_cache(maxsize=None)
def active_size(node: Node) -> int:
    return 1 + sum(active_size(child) for child in node.children)


@lru_cache(maxsize=None)
def full_size(node: Node) -> int:
    stored = 0 if node.description is None else full_size(node.description)
    return 1 + stored + sum(full_size(child) for child in node.children)


def sizes(node: Node) -> tuple[int, int]:
    return active_size(node), full_size(node)


@lru_cache(maxsize=None)
def occurrences(node: Node, name: str) -> int:
    if node.tag == "variable":
        return int(node.label == name)
    # A frozen description is deliberately not an active child.
    return sum(occurrences(child, name) for child in node.children)


def substitute(node: Node, replacements: dict[str, Node]) -> Node:
    """Simultaneously substitute active variables, never frozen descriptions."""
    if node.tag == "variable":
        return replacements.get(node.label, node)
    return Node(
        node.tag,
        tuple(substitute(child, replacements) for child in node.children),
        node.label,
        node.description,
    )


def body_at(body: Node, state: Node, counter: Node) -> Node:
    return substitute(body, {"v": state, "w": counter})


def is_mask(body: Node) -> bool:
    return (
        body.tag == "application"
        and body.description == ZERO
        and len(body.children) == 2
        and body.children[1] == V
    )


def mask(tail: Node) -> Node:
    return z(tail, V)


def ordinary_wrapper(body: Node) -> Node:
    return z(ZERO, body)


def identity_guard(tail: Node) -> Node:
    return q(z(chi(W, ZERO), succ(tail)), V)


def absorbing_guard(tail: Node) -> Node:
    inner = z(chi(V, ZERO), z(tail, succ(q(V, ZERO))))
    return identity_guard(inner)


def base(body: Node) -> Node:
    return all_(("a",), eq(rec(body, ZERO, A), A))


def bound_step(body: Node) -> Node:
    return all_(
        ("a", "n", "c"),
        implies(
            eq(rec(body, N, A), C),
            eq(rec(body, succ(N), A), body_at(body, C, N)),
        ),
    )


def old_b(body: Node) -> Node:
    return all_(
        ("a", "n"),
        conj(
            eq(rec(body, ZERO, A), A),
            eq(
                rec(body, succ(N), A),
                body_at(body, rec(body, N, A), N),
            ),
        ),
    )


def old_d(body: Node) -> Node:
    return all_(
        ("a", "n"),
        conj(
            eq(rec(body, ZERO, A), A),
            eq(rec(body, succ(N), A), rec(body, N, body_at(body, A, ZERO))),
        ),
    )


def old_e(body: Node) -> Node:
    return all_(
        ("a", "n"),
        conj(
            eq(rec(body, ZERO, A), A),
            all_(
                ("c",),
                implies(
                    eq(rec(body, N, A), C),
                    eq(rec(body, succ(N), A), body_at(body, C, N)),
                ),
            ),
        ),
    )


def pointwise_definition(body: Node) -> Node:
    return all_(("v", "w"), eq(rec(body, V, W), body))


def pointwise_witness(body: Node) -> Node:
    selected = q(rec(body, succ(B), A), N)
    return all_(("a", "n"), exists("b", eq(rec(body, selected, A), ZERO)))


def predecessor_witness(body: Node) -> Node:
    selected = q(z(rec(body, B, A), B), N)
    return all_(("a", "n"), exists("b", eq(rec(body, selected, A), A)))


def exit_witness(body: Node) -> Node:
    selected = q(z(chi(rec(body, B, A), A), B), N)
    return all_(("a", "n"), exists("b", eq(rec(body, selected, A), A)))


def predecessor_return(body: Node) -> Node:
    selected = q(q(chi(rec(body, B, A), A), B), N)
    return all_(("a", "n"), exists("b", eq(rec(body, selected, A), A)))


def boundary(body: Node, shifted: bool) -> Node:
    first = succ(B) if shifted else B
    second = succ(first)
    return all_(
        ("a", "n"),
        exists(
            "b",
            conj(
                eq(rec(body, first, A), A),
                implies(eq(rec(body, second, A), A), eq(B, N)),
            ),
        ),
    )


def separated_one(tail: Node) -> Node:
    body = identity_guard(tail)
    tested = body_at(tail, A, succ(B))
    selected = q(z(chi(tested, A), succ(B)), N)
    return all_(
        ("a", "n"), exists("b", eq(rec(body, succ(selected), A), A))
    )


def separated_tail(tail: Node) -> Node:
    body = identity_guard(tail)
    return all_(
        ("a", "n"),
        exists(
            "b",
            conj(
                eq(rec(body, succ(B), A), A),
                implies(eq(body_at(tail, A, succ(B)), A), eq(B, N)),
            ),
        ),
    )


def absorbing_witness(body: Node) -> Node:
    later = rec(body, succ(succ(B)), A)
    selected = q(z(later, succ(B)), N)
    return all_(
        ("a", "n"), exists("b", eq(rec(body, succ(selected), A), A))
    )


def add_costs(*pairs: tuple[int, int]) -> tuple[int, int]:
    return tuple(sum(pair[index] for pair in pairs) for index in (0, 1))


def optimistic_computation(body: Node) -> tuple[int, int]:
    """Coordinatewise envelope; it may not be attained by one formula."""
    alternatives = [sizes(old_b(body)), sizes(old_e(body))]
    if occurrences(body, "v") > 0 and occurrences(body, "w") == 0:
        alternatives.append(sizes(old_d(body)))
    alternatives.append(add_costs(sizes(base(body)), sizes(bound_step(body))))
    return tuple(min(pair[index] for pair in alternatives) for index in (0, 1))


def generate_tails() -> list[Node]:
    """Deterministic varied samples, including recursively charged descriptors."""
    initial = [ZERO, V, W, succ(V), succ(W), chi(V, W), z(V, W), q(V, W)]
    pool = list(initial)
    seen = set(initial)
    rng = random.Random(20261102)
    descriptors = [ZERO, V, W, succ(V), chi(V, W)]
    for stage in range(4):
        earlier = tuple(pool)
        for _ in range(160):
            left = rng.choice(earlier)
            right = rng.choice(earlier)
            choice = rng.randrange(5)
            if choice == 0:
                term = succ(left)
            elif choice == 1:
                term = chi(left, right)
            elif choice == 2:
                term = q(left, right)
            elif choice == 3:
                term = z(left, right)
            else:
                term = rec(rng.choice(descriptors), left, right)
            if term not in seen:
                pool.append(term)
                seen.add(term)
        # These finite earlier descriptions remain frozen in later calls.
        descriptors.extend(rng.sample(pool, min(10, len(pool))))
    deep = succ(V)
    for _ in range(7):
        deep = rec(deep, rec(deep, V, ZERO), W)
        term = rec(deep, V, W)
        if term not in seen:
            pool.append(term)
            seen.add(term)
    return pool


def check_exact(actual: tuple[int, int], expected: tuple[int, int], label: str) -> None:
    if actual != expected:
        raise AssertionError(f"{label}: measured {actual}, expected {expected}")


def run_checks() -> dict:
    tails = generate_tails()
    minima: dict[str, list[int]] = {}
    examples = []
    count_identities = 0
    optional_count = 0
    for index, tail in enumerate(tails):
        tail_m, tail_w = sizes(tail)
        counter_occurrences = occurrences(tail, "w")
        body = mask(tail)
        m, full = sizes(body)
        state_occurrences = occurrences(body, "v")
        assert is_mask(body)
        ordinary = ordinary_wrapper(body)
        assert not is_mask(ordinary)
        check_exact(sizes(ordinary), (m + 2, full + 3), "ordinary wrapper")

        frozen_probe = rec(tail, V, W)
        frozen_result = substitute(frozen_probe, {"v": succ(V), "w": ZERO})
        assert frozen_result.description is tail
        assert frozen_result.children == (succ(V), ZERO)

        identities = {
            "mask body": (sizes(body), (tail_m + 2, tail_w + 3)),
            "new definition": (sizes(pointwise_definition(body)), (6 + m, 6 + 2 * full)),
            "new witness": (sizes(pointwise_witness(body)), (13, 14 + 2 * full)),
            "old P14": (sizes(predecessor_witness(body)), (14, 16 + 2 * full)),
            "old Exit": (sizes(exit_witness(body)), (16, 18 + 2 * full)),
            "old predecessor return": (
                sizes(predecessor_return(body)), (16, 18 + 2 * full)
            ),
            "old Coverage boundary": (sizes(boundary(body, False)), (19, 19 + 2 * full)),
            "old B": (
                sizes(old_b(body)),
                (13 + m + 2 * state_occurrences,
                 13 + (3 + state_occurrences) * full + 2 * state_occurrences),
            ),
            "old D": (sizes(old_d(body)), (15 + m, 15 + 4 * full)),
            "old E": (sizes(old_e(body)), (20 + m, 20 + 4 * full)),
            "separate base": (sizes(base(body)), (6, 6 + full)),
            "separate bound step": (sizes(bound_step(body)), (14 + m, 14 + 3 * full)),
        }
        new_cost = add_costs(sizes(pointwise_definition(body)), sizes(pointwise_witness(body)))
        identities["new package"] = (new_cost, (19 + m, 20 + 4 * full))

        guarded = identity_guard(tail)
        gm, gw = sizes(guarded)
        absorbing = absorbing_guard(tail)
        am, aw = sizes(absorbing)
        identities.update({
            "Separated identity guard": (sizes(guarded), (tail_m + 7, tail_w + 9)),
            "Separated boundary": (sizes(boundary(guarded, True)), (21, 21 + 2 * gw)),
            "Separated optional One": (
                sizes(separated_one(tail)),
                (15 + tail_m + counter_occurrences, 8 + 2 * gw + counter_occurrences),
            ),
            "Separated alternative Tail": (
                sizes(separated_tail(tail)),
                (16 + tail_m + counter_occurrences, 7 + 2 * gw + counter_occurrences),
            ),
            "Absorbing guard": (sizes(absorbing), (tail_m + 16, tail_w + 21)),
            "Absorbing witness": (sizes(absorbing_witness(absorbing)), (18, 20 + 2 * aw)),
        })
        for label, (actual, expected) in identities.items():
            check_exact(actual, expected, label)
        count_identities += len(identities)

        plain_comp = optimistic_computation(body)
        guarded_comp = optimistic_computation(guarded)
        absorbing_comp = optimistic_computation(absorbing)
        old_packages = {
            "P14_plus_B": add_costs(sizes(predecessor_witness(body)), sizes(old_b(body))),
            "P14_plus_E": add_costs(sizes(predecessor_witness(body)), sizes(old_e(body))),
            "P14_plus_separated_base_step": add_costs(
                sizes(predecessor_witness(body)), sizes(base(body)), sizes(bound_step(body))
            ),
            "predecessor_witness_optimistic": add_costs(
                plain_comp, sizes(predecessor_witness(body))
            ),
            "exit_witness_optimistic": add_costs(plain_comp, sizes(exit_witness(body))),
            "predecessor_return_optimistic": add_costs(
                plain_comp, sizes(predecessor_return(body))
            ),
            "coverage_boundary_profile_optimistic": add_costs(
                plain_comp, sizes(boundary(body, False))
            ),
            "separated_primary_same_tail_optimistic": add_costs(
                guarded_comp, sizes(boundary(guarded, True))
            ),
            "separated_one_same_tail_profile": add_costs(
                guarded_comp, sizes(separated_one(tail))
            ),
            "separated_tail_same_tail_profile": add_costs(
                guarded_comp, sizes(separated_tail(tail))
            ),
            "absorbing_same_tail_optimistic": add_costs(
                absorbing_comp, sizes(absorbing_witness(absorbing))
            ),
        }
        if occurrences(body, "w") == 0:
            old_packages["P14_plus_D_autonomous_only"] = add_costs(
                sizes(predecessor_witness(body)), sizes(old_d(body))
            )
        if tail_m + counter_occurrences <= 5:
            optional_count += 1

        for label, old_cost in old_packages.items():
            difference = [old_cost[k] - new_cost[k] for k in (0, 1)]
            assert all(value > 0 for value in difference), (label, new_cost, old_cost)
            if label not in minima:
                minima[label] = difference
            else:
                minima[label] = [min(minima[label][k], difference[k]) for k in (0, 1)]

        if index < 8 or index >= len(tails) - 3:
            examples.append({
                "tail_index": index,
                "tail_active_full": [tail_m, tail_w],
                "tail_state_counter_occurrences": [occurrences(tail, "v"), counter_occurrences],
                "mask_body_active_full": [m, full],
                "new_definition_active_full": list(sizes(pointwise_definition(body))),
                "new_witness_active_full": list(sizes(pointwise_witness(body))),
                "new_complete_package_active_full": list(new_cost),
                "old_complete_packages_active_full": {key: list(value) for key, value in old_packages.items()},
                "separated_optional_threshold_applies": tail_m + counter_occurrences <= 5,
            })

    return {
        "status": "all assertions passed",
        "sample_seed": 20261102,
        "distinct_tail_trees": len(tails),
        "exact_count_identities_checked": count_identities,
        "samples_with_separated_optional_threshold": optional_count,
        "max_tail_active_nodes": max(active_size(tail) for tail in tails),
        "max_tail_fully_charged_nodes": max(full_size(tail) for tail in tails),
        "minimum_observed_savings_active_full": minima,
        "proved_symbolic_package_counts": {
            "notation": "m=active(h), W=full(h), h=Z(t,v), i=occ_v(h)",
            "new_definition": ["6+m", "6+2W"],
            "new_witness": ["13", "14+2W"],
            "new_complete_package": ["19+m", "20+4W"],
            "P14_plus_B": ["27+m+2i", "29+(5+i)W+2i"],
            "P14_plus_D_when_autonomous": ["29+m", "31+6W"],
            "P14_plus_E": ["34+m", "36+6W"],
            "P14_plus_separated_base_step": ["34+m", "36+6W"],
        },
        "same_raw_tail_wrapper_counts": {
            "notation": "M=active(t), T=full(t), j=occ_w(t)",
            "new_mask": ["M+2", "T+3"],
            "separated_identity_guard": ["M+7", "T+9"],
            "absorbing_guard": ["M+16", "T+21"],
            "separated_one_witness": ["15+M+j", "26+2T+j"],
            "separated_tail_witness": ["16+M+j", "25+2T+j"],
        },
        "scope": {
            "verified": [
                "Tree counts with recursively repeated frozen descriptions",
                "Active substitution leaves descriptions frozen",
                "Z(0,h) is an ordinary description for each tested mask h",
                "Strict local-package inequalities for the tested profile instances",
                "Literal identity and absorbing wrapper overheads",
            ],
            "not_claimed": [
                "A mathematical proof of equivalence or bi-interpretability",
                "Strict domination of each old raw-input alias output",
                "A minimum over arbitrary languages, encodings, or proof systems",
                "A cost-free same-function identification of old and new descriptor meanings",
                "A bound on complete formula-to-induction proof translations",
            ],
            "isolated_base_caveat": "The six-draft raw-input envelope has canonical base outputs of size 6/(6+W); the new package is not shorter than those isolated outputs.",
            "optional_witness_caveat": "The old One/Tail full witness alone can be shorter than the new full witness at the same hypothetical W. The asserted comparisons include computation and each construction's literal wrapper.",
            "recovered_recursion_caveat": "The ordinary wrapper Z(0,h), needed to recover iteration for a mask description, costs m+2/W+3. Its own computational axioms are separate obligations elsewhere in the infinite generated theory; no claim about arbitrary finite-fragment totals is made.",
            "coverage_profile_caveat": "The generic U_h profile is from Coverage's equivalent readable basis; small masks need not receive that sentence at their own raw emitter input.",
        },
        "examples": examples,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).resolve().with_name("size_results.json"),
    )
    arguments = parser.parse_args()
    results = run_checks()
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": results["status"],
        "distinct_tail_trees": results["distinct_tail_trees"],
        "exact_count_identities_checked": results["exact_count_identities_checked"],
        "output": str(arguments.output),
        "minimum_observed_savings_active_full": results["minimum_observed_savings_active_full"],
    }, indent=2))


if __name__ == "__main__":
    main()
