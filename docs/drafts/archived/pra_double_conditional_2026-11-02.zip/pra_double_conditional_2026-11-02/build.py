#!/usr/bin/env python3
"""Build the supplied LaTeX and optionally rerun its fresh checks."""
from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    verify = root / "verification"
    verify.mkdir(exist_ok=True)
    if args.checks:
        commands = [
            [sys.executable, "code/axiom_generator.py", "--examples", "--output",
             "verification/generator_examples.json"],
            [sys.executable, "code/verify_kernels.py", "--output",
             "verification/kernel_checks.json"],
            [sys.executable, "code/verify_boundary_seed.py", "--output",
             "verification/boundary_seed_checks.json"],
        ]
        for cmd in commands:
            subprocess.run(cmd, cwd=root, check=True)
    if not shutil.which("pdflatex"):
        raise SystemExit("pdflatex is required; install a standard TeX Live distribution")
    cmd = ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
           "-halt-on-error", "report.tex"]
    passes = []
    for n in range(1, 4):
        completed = subprocess.run(cmd, cwd=root, text=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (verify / f"latex_pass_{n}.txt").write_text(completed.stdout)
        passes.append({"pass": n, "exit_code": completed.returncode})
        if completed.returncode:
            print(completed.stdout)
            raise SystemExit(completed.returncode)
    (verify / "build.json").write_text(json.dumps({
        "command": cmd, "passes": passes,
        "pdf_size_bytes": (root / "report.pdf").stat().st_size,
        "note": "Visual review is recorded separately, not inferred from compilation."
    }, indent=2) + "\n")
    print("Built report.pdf")


if __name__ == "__main__":
    main()
