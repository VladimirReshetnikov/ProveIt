PRA WITH A SMALLER CONDITIONAL COMPUTATION MODULE
Research report prepared for Vladimir Reshetnikov
2 November 2026

START HERE
report.pdf is the complete mathematical report. report.tex and sections/
are the complete buildable LaTeX source. AXIOMS.txt is an exact standalone
specification, including all generators, tie rules, support, and scope.

The compact recommendation is P15, presented in the report section
"A fifteen-node arithmetic seed and the compact recommendation": one 15-node
fixed arithmetic sentence, the new computation minimum ending in 2H+32, and
the covered atomic boundary minimum ending in F+18. The report also retains a
six-node-separation companion with one explicitly charged coverage instance
for an exact comparison against the prior thin-schema frontier.

PROVED RESULTS
* A new double-use of the already present weak conditional reduces the
  current complete shared computation module from 2H+34 to 2H+32.
* A new single 15-node fixed sentence combines the prior 16-node separation
  and coverage basis, over explicitly common direct Q support.
* Weak predecessor boundaries combine with the shorter direct boundaries
  to give min(2F+i+11,F+18). The protected companion is pointwise no worse
  than the incumbent thin boundary selector, including its critical tie.
* All complete presentations have identity bi-interpretations with the
  first-order companion of PRA and are equiconsistent, separately in
  classical and intuitionistic logic. The arithmetic compiler, tuple
  parameters, and both interpretation composites are proved internally.

SOURCE REVIEW
Repository: VladimirReshetnikov/ProveIt
Checkout head: df8fb0bbd19b6b8442b78569d38b9d888e4e7a0d
Latest drafts change: 5f9cb0b20a6a83a11917c56efec53714ea85df6f
Six current and five archived ZIPs were reviewed. All six current packages
contribute an improvement on some stated coordinate. Inherited or dominated
individual components are identified. The latest drafts-change query was
rechecked before finalization and was unchanged.
provenance/source_manifest.json records every archive's Git blob hash,
SHA-256, size, exact immutable URL, and LaTeX payload hashes.
No downloaded source program/build was run. No repository write was made.

VERIFICATION ARTIFACTS
code/axiom_generator.py
  Actual finite syntax generator for computation and boundary clauses in
  the three presentations. It freezes descriptors under active substitution,
  emits complete sentences, and checks full/active/expanded counts.
code/verify_kernels.py
  Independently written AST and exhaustive finite computation checks;
  includes the countermodel without the no-fixed-point assumption.
code/verify_boundary_seed.py
  Independent seed/boundary counts, selector checks, bounded scan witnesses,
  and finite seed tests. Vacuous full finite Q tests are explicitly labeled.
verification/*.json
  Results, examples, build information, and the visual review record.

Checks support the complete written proofs; they are not a proof-assistant
formalization of the full first-order interpretation theorem.

BUILD
Requirements: Python 3.10+ standard library; pdflatex/TeX Live with standard
amsmath, amssymb, amsthm, mathtools, lmodern, booktabs, array, longtable,
tabularx, enumitem, needspace, geometry, and hyperref packages.

  python3 build.py --checks

For PDF only:
  python3 build.py

The builder runs three pdflatex passes with shell escape disabled. It writes
build logs under verification/. Poppler or another PDF viewer can be used for
independent visual inspection; the delivered PDF was already rendered and
reviewed. The source is self-contained and needs no downloaded repository.

GENERATOR EXAMPLES
  python3 code/axiom_generator.py --examples --output examples.json
  python3 code/axiom_generator.py --descriptor update.json
  python3 code/axiom_generator.py --equation equation.json

Descriptor JSON uses one of:
  {"var":"v"}, {"var":"w"}, {"zero":true}, {"S":<term>},
  {"R":{"body":<descriptor>,"counter":<term>,"initial":<term>}}.
A descriptor permits only the active slots v, w. An equation file is
  {"s":<term>,"t":<term>}
with only the active slots x, a. The nested R body is frozen and validated
separately. This is a syntax generator, not a universal numerical evaluator.

HOW TO READ THE COUNTS
Count every variable, constant, application, equality, connective, falsity,
and individual quantifier as one node. At every R_h use also count the full
stored h recursively. Initial symbol/logic declarations, generator bytes,
proof lengths, and finite bootstrap support are separate coordinates.
The weak J definition record costs 12. Its expansion is not free. The seed
costs 15 only in this declared basis (20 when expanded); the new W costs
2H+32 (3H+44 when expanded). See the report for exact finite-support caveats.

RESEARCH SCOPE
The archive gives verified improvements in the surviving drafts' compatible
ledgers, not a representation-independent absolute shortestness theorem.
Alternative primitive-bit, discriminator, autonomous-iteration, and
relational domains are assessed as distinct signatures. Further research
questions are included in the report.
