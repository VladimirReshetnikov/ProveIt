#!/usr/bin/env python3
"""Fresh finite tests for the 15-node seed and protected weak boundaries.

The full Q axioms have no finite models of size two or three: their finite
checks are explicitly marked VACUOUS.  Other checks below are nonvacuous
classical finite semantics, literal syntax counts, or bounded standard-N
witness calculations.  None replaces the general constructive written proof.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path


def weak(a, u, v):
    return (a or u) and ((not a) or v)


def seed_A15(successor):
    return all(any(weak(x == 0, x == successor[y], y != 0)
                   for y in range(len(successor)))
               for x in range(len(successor)))


def coverage(successor):
    return all(x == 0 or any(x == successor[y] for y in range(len(successor)))
               for x in range(len(successor)))


def q_tables_with_base(size):
    for rest in itertools.product(range(size), repeat=size * (size - 1)):
        rows = [tuple(range(size))]
        rows.extend(tuple(rest[i * size:(i + 1) * size]) for i in range(size - 1))
        yield tuple(rows)


def finite_seed_checks(size):
    successors = list(itertools.product(range(size), repeat=size))
    q_tables = list(q_tables_with_base(size))
    full_q_models = full_q_true = fragment_models = fragment_true = 0
    for successor in successors:
        a15 = seed_A15(successor)
        cov = coverage(successor)
        sep = successor[0] != 0
        assert not a15 or cov
        for q in q_tables:
            # This nonvacuous fragment is used only for finite Boolean tests.
            if all(q[successor[0]][a] == 0 for a in range(size)):
                fragment_models += 1
                if a15 != (sep and cov):
                    raise AssertionError((size, successor, q, "seed equivalence"))
                fragment_true += int(a15)
            if all(q[successor[n]][a] == n
                   for n in range(size) for a in range(size)):
                full_q_models += 1
                full_q_true += int(a15)
                if a15 != (sep and cov):
                    raise AssertionError((size, successor, q, "full Q equivalence"))
    assert full_q_models == 0
    assert fragment_models > 0
    return {
        "domain_size": size,
        "successor_maps": len(successors),
        "all_binary_Q_tables_in_principle": size ** (size * size),
        "base_compatible_Q_tables_actually_enumerated": len(q_tables),
        "successor_base_Q_pairs_checked": len(successors) * len(q_tables),
        "full_Q_axioms": {
            "models": full_q_models,
            "models_satisfying_seed": full_q_true,
            "status": "VACUOUS: no full Q models exist on this finite domain",
            "reason": "Q(0,a)=a and Q(Sn,a)=n force successor injective and zero outside its image when the carrier has two distinct elements; impossible on a finite carrier.",
            "evidence_value": "Not counted as substantive validation of equivalence.",
        },
        "nonvacuous_Q_fragment": {
            "axioms": ["Q(0,a)=a", "Q(S0,a)=0"],
            "models": fragment_models,
            "models_satisfying_seed": fragment_true,
            "seed_iff_separation_and_coverage": True,
            "scope": "Finite classical semantics only; this does not claim an intuitionistic completeness result for the weakened fragment.",
        },
        "seed_implies_coverage_without_Q": True,
    }


def missing_Q_countermodel():
    successor = (0, 1)
    assert seed_A15(successor) and coverage(successor) and successor[0] == 0
    return {
        "domain": [0, 1],
        "zero": 0,
        "successor": list(successor),
        "A15": True,
        "coverage": True,
        "separation_0_ne_S0": False,
        "witnesses": {"x=0": 1, "x=1": 1},
        "scope": "Without Q's initialization and zero-step equations, A15 does not imply separation.",
    }


def bounded_nat_seed_checks(limit=10000):
    for x in range(limit + 1):
        y = 1 if x == 0 else x - 1
        if not weak(x == 0, x == y + 1, y != 0):
            raise AssertionError((x, y))
    return {
        "points_checked": limit + 1,
        "witness_at_zero": "y=1",
        "witness_at_successor": "y=x-1",
        "status": "passed",
        "scope": "Bounded standard natural number witnesses, not a nonstandard-model proof.",
    }


# Independent literal AST. Frozen recursor descriptors contribute to full size
# but are not entered when substituting active variables.
def V(name): return ("V", name)
def Z(): return ("0",)
def S(t): return ("S", t)
def R(h, n, a): return ("R", h, n, a)
def EQ(t, u): return ("=", t, u)
def BOT(): return ("bottom",)
def IMP(a, b): return ("implies", a, b)
def OR(a, b): return ("or", a, b)
def J(a, b, c): return ("J", a, b, c)
def ALL(name, body): return ("all", name, body)
def EX(name, body): return ("exists", name, body)


def count(ast):
    if ast[0] in ("V", "0", "bottom"):
        return 1
    if ast[0] in ("all", "exists"):
        return 1 + count(ast[2])
    return 1 + sum(map(count, ast[1:]))


def substitute(ast, name, value):
    if ast[0] == "V":
        return value if ast[1] == name else ast
    if ast[0] in ("0", "bottom"):
        return ast
    if ast[0] == "R":
        return ("R", ast[1], *(substitute(t, name, value) for t in ast[2:]))
    return (ast[0], *(substitute(t, name, value) for t in ast[1:]))


def active_count(ast, name):
    if ast[0] == "V":
        return int(ast[1] == name)
    if ast[0] in ("0", "bottom"):
        return 0
    children = ast[2:] if ast[0] == "R" else ast[1:]
    return sum(active_count(t, name) for t in children)


def boundary_trees(equation):
    a, n, b, x = map(V, ("a", "n", "b", "x"))
    eb = substitute(equation, "x", b)
    esb = substitute(equation, "x", S(b))
    b_matrix = J(eb, EQ(b, Z()), IMP(esb, EQ(b, n)))
    u_matrix = J(equation, IMP(EQ(x, b), EQ(b, Z())),
                 IMP(EQ(x, S(b)), EQ(b, n)))
    k_matrix = J(equation, IMP(EQ(S(x), b), BOT()),
                 IMP(EQ(x, b), EQ(b, n)))
    return (
        ALL("a", ALL("n", EX("b", b_matrix))),
        ALL("a", ALL("n", EX("b", ALL("x", u_matrix)))),
        ALL("a", ALL("n", EX("b", ALL("x", k_matrix)))),
    )


def selected_name(F, i, scheme, is_coverage=False):
    if i == 0:
        return "omit"
    if scheme == "base":
        return "B" if F + i <= 8 else "U"
    if scheme == "P15":
        return "B" if F + i <= 6 else "K"
    if scheme == "protected":
        if is_coverage:
            return "U"
        return "B" if F + i <= 6 else "K"
    raise ValueError(scheme)


def formula_count_checks():
    x, a, y, w = map(V, ("x", "a", "y", "w"))
    a15 = ALL("x", EX("y", J(EQ(x, Z()), EQ(x, S(y)), IMP(EQ(y, Z()), BOT()))))
    sep = IMP(EQ(Z(), S(Z())), BOT())
    cov = ALL("x", OR(EQ(x, Z()), EX("y", EQ(x, S(y)))))
    assert count(a15) == 15 and count(sep) == 6 and count(cov) == 10
    coverage_equation = EQ(x, S(R(w, x, Z())))
    examples = [EQ(x, a), EQ(x, x), coverage_equation, EQ(a, Z())]
    for left_seed in (x, a, Z()):
        left = left_seed
        for _ in range(25):
            left = S(left)
            examples.extend((EQ(left, a), EQ(left, x)))
    examples.extend(EQ(R(h, left, right), a)
                    for h in (Z(), V("v"), w, S(V("v")))
                    for left in (x, a, Z()) for right in (x, a, Z()))
    for equation in examples:
        F, i = count(equation), active_count(equation, "x")
        actual = tuple(map(count, boundary_trees(equation)))
        expected = (2 * F + i + 11, F + 20, F + 18)
        if actual != expected:
            raise AssertionError((equation, F, i, actual, expected))
        B, U, K = actual
        costs = {"B": B, "U": U, "K": K, "omit": 0}
        old_choice = selected_name(F, i, "base")
        new_choice = selected_name(F, i, "protected", equation == coverage_equation)
        if costs[new_choice] > costs[old_choice]:
            raise AssertionError("Protected boundary exceeds incumbent")
        if i > 0 and equation != coverage_equation:
            assert costs[old_choice] - costs[new_choice] == max(0, min(F + i - 7, 2))
    cov_counts = tuple(map(count, boundary_trees(coverage_equation)))
    assert count(coverage_equation) == 7 and active_count(coverage_equation, "x") == 2
    assert cov_counts == (27, 27, 25)
    assert selected_name(7, 2, "base") == "U"
    assert selected_name(7, 2, "protected", True) == "U"
    strict_equation = x
    for _ in range(4):
        strict_equation = S(strict_equation)
    strict_equation = EQ(strict_equation, a)
    strict_counts = tuple(map(count, boundary_trees(strict_equation)))
    assert strict_counts == (26, 27, 25)
    return {
        "seed_counts": {"A15": count(a15), "Sep": count(sep), "Cov": count(cov), "Sep_plus_Cov": count(sep) + count(cov)},
        "equation_trees_checked": len(examples),
        "boundary_formulas": {"B_direct": "2F+i+11", "U_forward_table": "F+20", "K_predecessor_table": "F+18"},
        "base_selector": "omit i=0; otherwise B if F+i<=8, U otherwise (U on ties)",
        "P15_selector": "omit i=0; otherwise B if F+i<=6, K otherwise (K on ties)",
        "protected_selector": "same as P15 except literal x=S(Q(x,0)) uses U",
        "generic_saving_against_base": "max(0,min(F+i-7,2)) for nonvacuous nonprotected inputs",
        "protected_coverage_input": {"equation": "x=S(Q(x,0))", "F": 7, "i": 2, "B": 27, "U": 27, "K": 25, "base_selected": "U", "protected_selected": "U", "saving": 0},
        "strict_example": {"equation": "S^4(x)=a", "F": 7, "i": 1, "B": 26, "U": 27, "K": 25, "base_selected_cost": 26, "protected_selected_cost": 25, "saving": 1},
        "status": "passed",
    }


def scan_checks(max_target=8):
    predicates = stages = u_points = k_points = 0
    for horizon in range(max_target + 1):
        for bits in itertools.product((False, True), repeat=horizon + 2):
            predicates += 1
            forward = backward = 0
            for n in range(horizon + 1):
                stages += 1
                b = forward
                ordinary = (b == 0 or bits[b]) and ((not bits[b + 1]) or b == n)
                direct = weak(bits[b], b == 0, (not bits[b + 1]) or b == n)
                if not (0 <= b <= n and ordinary and direct):
                    raise AssertionError((bits, n, b, "forward invariant"))
                for x in range(horizon + 2):
                    u_points += 1
                    if not weak(bits[x], x != b or b == 0, x != b + 1 or b == n):
                        raise AssertionError((bits, n, b, x, "U"))
                b = backward
                predecessor_invariant = (b == 0 or bits[b - 1]) and ((not bits[b]) or b == n)
                if not (0 <= b <= n and predecessor_invariant):
                    raise AssertionError((bits, n, b, "backward invariant"))
                for x in range(horizon + 2):
                    k_points += 1
                    if not weak(bits[x], x + 1 != b, x != b or b == n):
                        raise AssertionError((bits, n, b, x, "K"))
                if n < horizon:
                    forward = n + 1 if bits[forward + 1] else forward
                    backward = n + 1 if bits[backward] else backward
    return {
        "largest_target": max_target,
        "predicate_truth_tables": predicates,
        "scan_stages": stages,
        "U_matrix_points": u_points,
        "K_matrix_points": k_points,
        "forward_scan": "c(0)=0; c(k+1)=k+1 if P(c(k)+1), else c(k)",
        "forward_invariant": "0<=b<=k and (b=0 or P(b)) and (P(b+1) -> b=k)",
        "backward_scan": "d(0)=0; d(k+1)=k+1 if P(d(k)), else d(k)",
        "backward_invariant": "0<=b<=k and (b=0 or P(b-1)) and (P(b) -> b=k)",
        "status": "passed",
        "scope": "Exhaustive bounded standard-N predicate tables and scans. The general PRA/nonstandard correctness requires the written quantifier-free induction proof.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("verify_boundary_seed_results.json"))
    args = parser.parse_args()
    result = {
        "verification_status": "Nonvacuous finite tests and literal counts passed; full finite Q tests explicitly vacuous.",
        "proof_status": "This is supporting executable evidence, not a formal proof of the constructive interpretation theorem.",
        "finite_seed_checks": [finite_seed_checks(2), finite_seed_checks(3)],
        "missing_Q_countermodel": missing_Q_countermodel(),
        "standard_N_seed_witnesses": bounded_nat_seed_checks(),
        "literal_counts_and_selectors": formula_count_checks(),
        "predicate_scans": scan_checks(),
        "general_seed_argument": [
            "A15 gives coverage by its first disjunction, and at x=0 it gives a nonzero witness y.",
            "If S0=0, Q(0,a)=a and Q(S0,a)=0 force every a=0, contradicting that witness; hence separation.",
            "Over the full Q equations and separation, every successor is nonzero. Split coverage: at x=0 use y=S0; at x=Sz use y=z and the impossibility x=0 to satisfy the guarded nonzero condition.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"output": str(args.output.resolve()),
                      "nonvacuous_Q_fragment_models": sum(x["nonvacuous_Q_fragment"]["models"] for x in result["finite_seed_checks"]),
                      "full_Q_models": 0,
                      "full_Q_status": "VACUOUS",
                      "predicate_tables": result["predicate_scans"]["predicate_truth_tables"],
                      "scan_stages": result["predicate_scans"]["scan_stages"],
                      "literal_equations": result["literal_counts_and_selectors"]["equation_trees_checked"],
                      "status": "passed"}, indent=2))


if __name__ == "__main__":
    main()
