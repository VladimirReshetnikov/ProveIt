#!/usr/bin/env python3
"""Independent finite checks and literal-tree counts for double-J recursion.

This is fresh verification code, not a proof assistant development.  Exhaustive
finite tests support, but do not replace, the general written proof.  The
three-element check enumerates every successor map without fixed points and
every local R/h column needed at each a,n; this is not enumeration of all
simultaneous three-element binary tables.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path


def J(a: bool, u: bool, v: bool) -> bool:
    return (a or u) and ((not a) or v)


def original_local(zero, successor, r_column, h_column, a, n):
    """h_column[v] is h(v,n); r_column[x] is R(x,a)."""
    base = n != zero or r_column[n] == a
    step = r_column[successor[n]] == h_column[r_column[n]]
    return base and step


def double_j_witnesses(zero, successor, r_column, h_column, a, n):
    size = len(successor)
    answers = []
    for u in range(size):
        initialization = n != zero or u == a
        valid = True
        for x in range(size):
            for y in range(size):
                inner = J(
                    x == n,
                    x != successor[n] or y == h_column[u],
                    y == u,
                )
                if not J(r_column[x] == y, initialization, inner):
                    valid = False
                    break
            if not valid:
                break
        if valid:
            answers.append(u)
    return answers


def check_local_columns(size):
    values = range(size)
    columns = list(itertools.product(values, repeat=size))
    successors = [s for s in columns if all(s[n] != n for n in values)]
    count = true_count = 0
    for successor in successors:
        for a in values:
            for n in values:
                for r_column in columns:
                    for h_column in columns:
                        old = original_local(0, successor, r_column, h_column, a, n)
                        witnesses = double_j_witnesses(
                            0, successor, r_column, h_column, a, n
                        )
                        new = bool(witnesses)
                        if old != new:
                            raise AssertionError(
                                (size, successor, a, n, r_column, h_column, old, witnesses)
                            )
                        if witnesses != ([r_column[n]] if old else []):
                            raise AssertionError("The current-value witness was not unique")
                        count += 1
                        true_count += int(old)
    return {
        "domain_size": size,
        "successor_maps_without_fixed_points": len(successors),
        "all_R_columns": len(columns),
        "all_step_columns": len(columns),
        "local_cases_checked": count,
        "true_equivalent_cases": true_count,
        "witness_uniqueness_checked": True,
        "status": "passed",
    }


def full_model_values(successor, r_rows, h_rows):
    size = len(successor)
    old_values = []
    new_values = []
    witnesses = []
    for a in range(size):
        r_column = tuple(r_rows[x][a] for x in range(size))
        for n in range(size):
            h_column = tuple(h_rows[v][n] for v in range(size))
            old_values.append(original_local(0, successor, r_column, h_column, a, n))
            ws = double_j_witnesses(0, successor, r_column, h_column, a, n)
            new_values.append(bool(ws))
            witnesses.append({"a": a, "n": n, "u": ws})
    return all(old_values), all(new_values), witnesses


def check_full_two_element_models():
    size = 2
    tables = []
    for entries in itertools.product(range(size), repeat=size * size):
        tables.append(tuple(tuple(entries[i * size:(i + 1) * size]) for i in range(size)))
    successors = [s for s in itertools.product(range(size), repeat=size)
                  if all(s[n] != n for n in range(size))]
    count = true_count = 0
    for successor in successors:
        for r_rows in tables:
            for h_rows in tables:
                old, new, _ = full_model_values(successor, r_rows, h_rows)
                if old != new:
                    raise AssertionError((successor, r_rows, h_rows, old, new))
                count += 1
                true_count += int(old)
    return {
        "domain_size": size,
        "successor_maps_without_fixed_points": len(successors),
        "arbitrary_binary_R_tables": len(tables),
        "arbitrary_binary_h_tables": len(tables),
        "full_models_checked": count,
        "models_satisfying_both_modules": true_count,
        "status": "passed",
    }


def countermodel_without_no_fixed_points():
    # Zero is 0; S(0)=1 is distinct.  S(1)=1 is the missing hypothesis.
    successor = (1, 1)
    # Rows are counter x; columns are initial a.
    r_rows = ((0, 1), (0, 0))
    # Rows are previous state v; columns are counter n.
    h_rows = ((0, 1), (0, 0))
    old, new, witnesses = full_model_values(successor, r_rows, h_rows)
    assert successor[0] != 0
    assert not old and new
    assert r_rows[successor[1]][0] != h_rows[r_rows[1][0]][1]
    return {
        "domain": [0, 1],
        "zero": 0,
        "successor": list(successor),
        "R_rows_x_columns_a": [list(row) for row in r_rows],
        "h_rows_v_columns_n": [list(row) for row in h_rows],
        "separation_0_ne_S0": True,
        "fixed_points": [1],
        "double_J_module": new,
        "original_module": old,
        "failed_step": {"a": 0, "n": 1, "left": 0, "right": 1},
        "witnesses": witnesses,
        "scope": "Countermodel to the bare module equivalence without no-fixed-points; not a model of all arithmetic bootstrap axioms.",
    }


# A small literal AST independent of the supplied archives' checkers.
# R includes a frozen descriptor as a separately charged child.
def var(name): return ("var", name)
def zero(): return ("zero",)
def succ(term): return ("S", term)
def rec(descriptor, counter, initial): return ("R", descriptor, counter, initial)
def eq(left, right): return ("eq", left, right)
def imp(left, right): return ("imp", left, right)
def conj(left, right): return ("and", left, right)
def weak_j(a, u, v): return ("J", a, u, v)


def quant(kind, names, body):
    for name in reversed(names):
        body = (kind, name, body)
    return body


def nodes(tree):
    tag = tree[0]
    if tag in ("var", "zero"):
        return 1
    if tag in ("forall", "exists"):
        return 1 + nodes(tree[2])
    return 1 + sum(nodes(child) for child in tree[1:])


def active_occurrences(tree, name):
    if tree[0] == "var":
        return int(tree[1] == name)
    if tree[0] == "zero":
        return 0
    children = tree[2:] if tree[0] == "R" else tree[1:]
    return sum(active_occurrences(child, name) for child in children)


def substitute_active(tree, replacements):
    tag = tree[0]
    if tag == "var":
        return replacements.get(tree[1], tree)
    if tag == "zero":
        return tree
    if tag == "R":
        return ("R", tree[1], *(substitute_active(child, replacements) for child in tree[2:]))
    return (tag, *(substitute_active(child, replacements) for child in tree[1:]))


def computation_trees(h):
    a, n, u, x, y = map(var, ("a", "n", "u", "x", "y"))
    rz = rec(h, zero(), a)
    rn = rec(h, n, a)
    rs = rec(h, succ(n), a)
    rx = rec(h, x, a)
    hu = substitute_active(h, {"v": u, "w": n})
    hr = substitute_active(h, {"v": rn, "w": n})
    base = imp(eq(n, zero()), eq(u, a))
    graph = eq(rx, y)
    current_row = imp(eq(x, n), eq(y, u))
    next_row = imp(eq(x, succ(n)), eq(y, hu))
    j_table = weak_j(eq(x, n), next_row, eq(y, u))
    direct = (quant("forall", ("a",), eq(rz, a)),
              quant("forall", ("a", "n"), eq(rs, hr)))
    current_graph = quant("forall", ("a", "n", "u"),
                          imp(eq(rn, u), conj(base, eq(rs, hu))))
    endpoint = quant("forall", ("a", "n"), quant("exists", ("u",),
                     conj(base, quant("forall", ("x", "y"),
                          imp(graph, conj(current_row, next_row))))))
    single_j = quant("forall", ("a", "n"), quant("exists", ("u",),
                     conj(base, quant("forall", ("x", "y"), imp(graph, j_table)))))
    double_j = quant("forall", ("a", "n"), quant("exists", ("u",),
                     quant("forall", ("x", "y"), weak_j(graph, base, j_table))))
    return direct, current_graph, endpoint, single_j, double_j


def descriptor_examples():
    v, w = var("v"), var("w")
    examples = [zero(), v, w]
    for seed in (zero(), v, w):
        h = seed
        for _ in range(32):
            h = succ(h)
            examples.append(h)
    # Legal calls with earlier descriptors, including frozen occurrences of v.
    for descriptor in (zero(), v, w, succ(v), rec(w, v, zero())):
        for left in (v, w, zero(), succ(v)):
            for right in (v, w, zero()):
                examples.append(rec(descriptor, left, right))
    h = v
    for _ in range(20):
        h = rec(w, h, h)
        examples.append(h)
        if nodes(h) > 2000:
            break
    return examples


def check_literal_counts():
    profiles = []
    for h in descriptor_examples():
        H = nodes(h)
        k = active_occurrences(h, "v")
        direct, current, endpoint, single_j, double_j = computation_trees(h)
        actual = (sum(map(nodes, direct)), nodes(current), nodes(endpoint),
                  nodes(single_j), nodes(double_j))
        expected = (3 * H + 13 + k * (H + 2), 3 * H + 22,
                    2 * H + 34, 2 * H + 33, 2 * H + 32)
        if actual != expected:
            raise AssertionError((h, H, k, actual, expected))
        profiles.append((H, k))
    # A descriptor containing v as frozen code has no active v if its call arguments do not.
    v, w = var("v"), var("w")
    frozen = rec(v, w, zero())
    assert active_occurrences(frozen, "v") == 0
    assert substitute_active(frozen, {"v": succ(v)}) == frozen
    return {
        "literal_descriptors_checked": len(profiles),
        "distinct_size_profiles": len(set(profiles)),
        "largest_full_descriptor": max(H for H, _ in profiles),
        "frozen_substitution_test": "passed",
        "formulas": {
            "original_pair_D": "3H+13+k(H+2)",
            "current_value_G": "3H+22",
            "ordinary_endpoint_T": "2H+34",
            "one_J_endpoint": "2H+33",
            "double_J_endpoint": "2H+32",
        },
        "status": "passed",
    }


def check_savings():
    cases = 0
    examples = []
    for H in range(1, 201):
        for k in range(H + 1):
            D = 3 * H + 13 + k * (H + 2)
            G = 3 * H + 22
            T = 2 * H + 34
            TJ = T - 1
            TJJ = T - 2
            old = min(D, G, T)
            one = min(D, G, TJ)
            two = min(D, G, TJJ)
            expected_one = int(H >= 12 and H + k * (H + 2) >= 21)
            expected_two = min(2, max(0, min(H - 10, H + k * (H + 2) - 19)))
            if old - one != expected_one or old - two != expected_two:
                raise AssertionError((H, k, D, G, T, old, one, two))
            cases += 1
            if (H, k) in {(10, 1), (11, 1), (12, 1), (19, 0), (20, 0), (21, 0), (100, 1)}:
                examples.append({"H": H, "k": k, "old": old, "new": two, "saving": old - two})
    return {
        "integer_profiles_checked": cases,
        "scope": "Algebraic identities checked for 1<=H<=200 and 0<=k<=H; this does not assert every profile is realizable syntax.",
        "double_J_saving_formula": "min(2,max(0,min(H-10,H+k(H+2)-19)))",
        "piecewise_for_k_at_least_1": "0 for H<=10; 1 for H=11; 2 for H>=12",
        "piecewise_for_k_equal_0": "0 for H<=19; 1 for H=20; 2 for H>=21",
        "examples": examples,
        "status": "passed",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("verify_kernels_results.json"))
    args = parser.parse_args()
    results = {
        "verification_status": "finite checks and exact literal counts; not a formal proof of the general theorem",
        "kernel": "forall a n exists u forall x y J(R_h(x,a)=y, n=0 -> u=a, J(x=n, x=S(n) -> y=h(u,n), y=u))",
        "J_definition": "J(A,U,V)=(A or U) and (A -> V)",
        "general_proof_requirements": [
            "At least two distinct elements for recovering the initialization implication from universal outer disjunctions.",
            "S(n)!=n for recovering the successor row from the inner J.",
            "The arithmetic theory separately derives these facts before replacing its other defining modules.",
        ],
        "full_two_element_models": check_full_two_element_models(),
        "local_column_checks": [check_local_columns(2), check_local_columns(3)],
        "no_fixed_point_countermodel": countermodel_without_no_fixed_points(),
        "literal_counts": check_literal_counts(),
        "savings": check_savings(),
        "support_warning": "All finite-packet comparisons must charge the support used to derive no-fixed-points, unless it is already common. These checks do not establish unrestricted shortestness.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"output": str(args.output.resolve()),
                      "full_models": results["full_two_element_models"]["full_models_checked"],
                      "local_cases": sum(x["local_cases_checked"] for x in results["local_column_checks"]),
                      "literal_descriptors": results["literal_counts"]["literal_descriptors_checked"],
                      "integer_profiles": results["savings"]["integer_profiles_checked"],
                      "status": "passed"}, indent=2))


if __name__ == "__main__":
    main()
