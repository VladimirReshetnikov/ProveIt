#!/usr/bin/env python3
"""Literal generator for the three completely specified PRA presentations.

This implements syntax and size selection, not arithmetic evaluation or a
proof search. Stored descriptors are frozen under active substitution.
Python 3.10+, standard library only. See --help and the README.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Term:
    kind: str
    args: tuple = ()
    name: str = ""
    body: "Term | None" = None


def V(name):
    return Term("var", name=name)


ZERO = Term("zero")


def S(t):
    return Term("S", (t,))


def R(h, n, a):
    if not free(h) <= {"v", "w"}:
        raise ValueError("A descriptor may have only active slots v and w")
    return Term("R", (n, a), body=h)


def free(t):
    if t.kind == "var":
        return {t.name}
    return set().union(*(free(a) for a in t.args)) if t.args else set()


def tsz(t, full=True):
    return 1 + sum(tsz(a, full) for a in t.args) + (
        tsz(t.body, True) if full and t.body is not None else 0)


def occurrences(t, variable):
    return int(t.kind == "var" and t.name == variable) + sum(
        occurrences(a, variable) for a in t.args)


def subst(t, replacements):
    if t.kind == "var":
        return replacements.get(t.name, t)
    # Deliberately do not traverse t.body.
    return Term(t.kind, tuple(subst(a, replacements) for a in t.args),
                t.name, t.body)


def render_term(t):
    if t.kind == "var":
        return t.name
    if t.kind == "zero":
        return "0"
    if t.kind == "S":
        return "S(" + render_term(t.args[0]) + ")"
    if t.kind == "R":
        return "R[" + render_term(t.body) + "](" + ",".join(
            render_term(a) for a in t.args) + ")"
    raise ValueError(t.kind)


def parse_term(data):
    if not isinstance(data, dict) or len(data) != 1:
        raise ValueError("Term JSON must be a single-key object")
    tag, value = next(iter(data.items()))
    if tag == "var" and isinstance(value, str) and value.isidentifier():
        return V(value)
    if tag == "zero" and value is True:
        return ZERO
    if tag == "S":
        return S(parse_term(value))
    if tag == "R" and isinstance(value, dict):
        if set(value) != {"body", "counter", "initial"}:
            raise ValueError("R needs body, counter, initial")
        return R(parse_term(value["body"]), parse_term(value["counter"]),
                 parse_term(value["initial"]))
    raise ValueError("Unknown or malformed term constructor")


def term_json(t):
    if t.kind == "var":
        return {"var": t.name}
    if t.kind == "zero":
        return {"zero": True}
    if t.kind == "S":
        return {"S": term_json(t.args[0])}
    return {"R": {"body": term_json(t.body),
                  "counter": term_json(t.args[0]),
                  "initial": term_json(t.args[1])}}


@dataclass(frozen=True)
class Formula:
    kind: str
    args: tuple = ()
    binder: str = ""


def Eq(s, t):
    return Formula("=", (s, t))


BOT = Formula("false")


def And(a, b):
    return Formula("and", (a, b))


def Or(a, b):
    return Formula("or", (a, b))


def Imp(a, b):
    return Formula("->", (a, b))


def J(a, u, v):
    return Formula("J", (a, u, v))


def bind(kind, names, f):
    for name in reversed(names):
        f = Formula(kind, (f,), name)
    return f


def fsz(f, full=True):
    return 1 + sum(tsz(a, full) if isinstance(a, Term) else fsz(a, full)
                   for a in f.args)


def expand_j(f):
    if f.kind == "=":
        return f
    args = tuple(expand_j(a) for a in f.args)
    if f.kind == "J":
        a, u, v = args
        return And(Or(a, u), Imp(a, v))
    return Formula(f.kind, args, f.binder)


def render(f):
    if f.kind == "=":
        return "(" + render_term(f.args[0]) + "=" + render_term(f.args[1]) + ")"
    if f.kind == "false":
        return "FALSE"
    if f.kind in {"forall", "exists"}:
        return f.kind + " " + f.binder + ", " + render(f.args[0])
    if f.kind == "J":
        return "J(" + ", ".join(render(a) for a in f.args) + ")"
    return "(" + (" " + f.kind + " ").join(render(a) for a in f.args) + ")"


def module_record(formulas):
    return {"full_nodes": sum(fsz(f) for f in formulas),
            "active_nodes": sum(fsz(f, False) for f in formulas),
            "ordinary_expansion_nodes": sum(fsz(expand_j(f)) for f in formulas),
            "sentences": [render(f) for f in formulas]}


def computation_modules(h):
    if not free(h) <= {"v", "w"}:
        raise ValueError("Invalid active descriptor slots")
    a, n, u, x, y = map(V, ("a", "n", "u", "x", "y"))
    rn = R(h, n, a)
    rh = lambda t: R(h, t, a)
    hu = subst(h, {"v": u, "w": n})
    base_guard = Imp(Eq(n, ZERO), Eq(u, a))
    graph = Eq(rh(x), y)
    row_n = Imp(Eq(x, n), Eq(y, u))
    row_s = Imp(Eq(x, S(n)), Eq(y, hu))
    direct = [bind("forall", ["a"], Eq(rh(ZERO), a)),
              bind("forall", ["a", "n"], Eq(rh(S(n)),
                   subst(h, {"v": rn, "w": n})))]
    graph_module = [bind("forall", ["a", "n", "u"],
                         Imp(Eq(rn, u), And(base_guard, Eq(rh(S(n)), hu))))]
    table = [bind("forall", ["a", "n"], bind("exists", ["u"],
             And(base_guard, bind("forall", ["x", "y"],
                                  Imp(graph, And(row_n, row_s))))))]
    double = [bind("forall", ["a", "n"], bind("exists", ["u"],
              bind("forall", ["x", "y"],
                   J(graph, base_guard, J(Eq(x, n), row_s, Eq(y, u))))))]
    records = {key: module_record(fs) for key, fs in
               (("D", direct), ("G", graph_module), ("T_old", table), ("W", double))}
    selected = min(("D", "G", "W"), key=lambda k: records[k]["full_nodes"])
    old = min(("D", "G", "T_old"), key=lambda k: records[k]["full_nodes"])
    H, k = tsz(h), occurrences(h, "v")
    expected = {"D": 3 * H + 13 + k * (H + 2), "G": 3 * H + 22,
                "T_old": 2 * H + 34, "W": 2 * H + 32}
    for key, count in expected.items():
        if records[key]["full_nodes"] != count:
            raise RuntimeError((key, records[key]["full_nodes"], count))
    if records["W"]["ordinary_expansion_nodes"] != 3 * H + 44:
        raise RuntimeError("Unexpected expanded W size")
    return {"descriptor": term_json(h), "printed_descriptor": render_term(h),
            "H": H, "k": k, "modules": records, "selected": selected,
            "old_selected": old,
            "saving": records[old]["full_nodes"] - records[selected]["full_nodes"]}


def boundary_modules(s, t):
    if not (free(s) | free(t)) <= {"x", "a"}:
        raise ValueError("Boundary terms have active slots x,a only")
    x, a, n, b = map(V, ("x", "a", "n", "b"))
    equation = Eq(s, t)
    at = lambda z: Eq(subst(s, {"x": z}), subst(t, {"x": z}))
    direct = J(at(b), Eq(b, ZERO), Imp(at(S(b)), Eq(b, n)))
    universal = J(equation, Imp(Eq(x, b), Eq(b, ZERO)),
                  Imp(Eq(x, S(b)), Eq(b, n)))
    covered = J(equation, Imp(Eq(S(x), b), BOT), Imp(Eq(x, b), Eq(b, n)))
    neg_direct = J(at(b), Or(Eq(b, n), at(S(b))), Eq(b, ZERO))
    neg_covered = J(equation, Imp(Eq(x, b), Eq(b, n)), Imp(Eq(S(x), b), BOT))
    outer = lambda f: bind("forall", ["a", "n"], bind("exists", ["b"], f))
    records = {key: module_record([outer(f)]) for key, f in
               (("B", direct), ("U", bind("forall", ["x"], universal)),
                ("K", bind("forall", ["x"], covered)), ("B_negative", neg_direct),
                ("K_negative", bind("forall", ["x"], neg_covered)))}
    F = fsz(equation)
    i = occurrences(s, "x") + occurrences(t, "x")
    for key, expected in {"B": 2 * F + i + 11, "U": F + 20,
                          "K": F + 18, "B_negative": 2 * F + i + 11,
                          "K_negative": F + 18}.items():
        if records[key]["full_nodes"] != expected:
            raise RuntimeError((key, records[key]["full_nodes"], expected))
    cov = Eq(x, S(R(V("w"), x, ZERO)))
    thin = "omit" if i == 0 else ("B" if F + i <= 8 else "U")
    p15 = "omit" if i == 0 else ("B" if F + i <= 6 else "K")
    star = "U" if equation == cov else p15
    return {"s": term_json(s), "t": term_json(t), "F": F, "i": i,
            "equation": render(equation), "is_protected_coverage": equation == cov,
            "modules": records,
            "selected": {"thin": thin, "star": star, "P15": p15}}


def fixed_records():
    x, y, z = map(V, ("x", "y", "z"))
    sep = Imp(Eq(ZERO, S(ZERO)), BOT)
    cov = bind("forall", ["z"], bind("exists", ["y"],
               Or(Eq(z, ZERO), Eq(z, S(y)))))
    seed = bind("forall", ["x"], bind("exists", ["y"],
                J(Eq(x, ZERO), Eq(x, S(y)), Imp(Eq(y, ZERO), BOT))))
    result = {name: module_record([f]) for name, f in
              (("Sep", sep), ("Cov", cov), ("A15", seed))}
    for name, expected in (("Sep", 6), ("Cov", 10), ("A15", 15)):
        if result[name]["full_nodes"] != expected:
            raise RuntimeError("Fixed size mismatch")
    return result


def examples():
    v, w, x, a = map(V, ("v", "w", "x", "a"))
    p_body = R(w, v, ZERO)
    h11 = v
    for _ in range(11):
        h11 = S(h11)
    x4 = x
    for _ in range(4):
        x4 = S(x4)
    return {"scope": "Literal generation and counts, not a proof assistant",
            "fixed": fixed_records(),
            "computations": [computation_modules(h) for h in
                             (w, ZERO, p_body, h11)],
            "boundaries": [boundary_modules(s, t) for s, t in
                           ((x, a), (x, S(R(w, x, ZERO))),
                            (x4, a), (S(x4), a), (a, ZERO))]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--examples", action="store_true")
    group.add_argument("--descriptor", type=Path, help="JSON finite term, slots v,w")
    group.add_argument("--equation", type=Path, help="JSON object with s,t, slots x,a")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.examples:
        result = examples()
    elif args.descriptor:
        result = computation_modules(parse_term(json.loads(args.descriptor.read_text())))
    else:
        value = json.loads(args.equation.read_text())
        if set(value) != {"s", "t"}:
            raise ValueError("Equation input needs s and t")
        result = boundary_modules(parse_term(value["s"]), parse_term(value["t"]))
    text = json.dumps(result, indent=2, ensure_ascii=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
