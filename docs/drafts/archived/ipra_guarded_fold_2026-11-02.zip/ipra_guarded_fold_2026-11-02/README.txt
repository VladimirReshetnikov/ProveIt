GUARDED FOLD RECURSION FOR iPRA
Prepared for Vladimir Reshetnikov, 2 November 2026

MAIN DELIVERABLES
  report.pdf                 Complete mathematical report
  report.tex, sections/*.tex  Complete editable LaTeX source
  AXIOMS.txt                 Standalone exact specification
  provenance/source_manifest.json   Snapshot, file hashes and archive inventory
  verification/check_compression.py Exact syntax and comparison checks
  verification/compression_results.json  Recorded deterministic check results
  verification/independent_counts.py    Second independently written AST checker
  verification/check_bootstrap.py       Complete finite arithmetic packet ledger
  verification/bootstrap_results.json   Its deterministic result
  verification/STATUS.txt    Explicit verification scope
  SHA256SUMS.txt             Checksums of deliverable members

BUILD
  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

VERIFY
  python3 verification/check_compression.py
  python3 verification/independent_counts.py
  python3 verification/check_bootstrap.py
  sha256sum -c SHA256SUMS.txt

No external Python packages are required by the verification scripts.
LaTeX uses standard TeX Live packages listed in report.tex.

RESULT
Three new clauses improve computation modules of the current iPRA drafts.
The report specifies pure K3, pure K4 and paid joint-basis presentations.
All have ordinary full-carrier, bottom-preserving intuitionistic
bi-interpretations with first-order iPRA and internally proved identity
round trips. The finite-rank signature and axiom schemes are infinite.

The pure K3 arithmetic packet costs 415 nodes versus 420 for the compatible
current frontier in the same basis. The pure K4 packet costs 417 and has
one-node-shorter retained boundaries. Fixed support and logical definitions
are counted; an unrestricted absolute shortestness claim is not made.

PROOF STATUS
Complete written mathematical proofs; exact executable syntax checks.
No complete Lean/Rocq formalization is claimed. Finite tests do not prove
the interpretation theorem. See report Sections 3--5 and verification/STATUS.txt.

SOURCES
All five current and five archived proposals were retrieved at ProveIt
commit 6f293758d174c06a313e3de5caa25a4c16ad392b. The manifest records the
exact sources; source archives are not redistributed in this package.
