#!/usr/bin/env python3
"""Verify the report's finite bootstrap ledger using the full AST.

This is a syntax/size check, not a formal arithmetic proof.
"""
from pathlib import Path
import json
import check_compression as c

Q, Z, A = 'w', '0', c.S('v')
def q(x, a): return c.R(Q, x, a)
def z(x, a): return c.R(Z, x, a)
def add(a, b): return c.R(A, b, a)
D = q('v', '0')
def d(a, b): return c.R(D, b, a)
def e(s, t): return q(d(c.S(s), t), c.S('0'))
def chi(s, t): return z(e(s, t), c.S('0'))
U = add('v', c.S('w'))
def tri(x): return c.R(U, x, '0')
V = add('v', chi(c.S('w'), tri(c.S('v'))))
def kappa(x): return c.R(V, x, '0')

def costs(h, basis):
    H,k,j,r = c.stats(h)
    if h in ('w','0'): return {'protected':16}
    out = {'D':3*H+13+k*(H+2),
           'G':3*H+(22 if basis=='4' else 21),
           'T':2*H-j+(33 if basis=='3' else 32),
           'F':c.size(c.Pdagger(h)), 'L':c.size(c.Ldagger(h))}
    if r==0: out['N']=c.size(c.Ngraph(h,3 if basis=='3' else 4))
    return out

def main():
    bodies=[Q,Z,A,D,U,V]
    assert [c.size(h) for h in bodies]==[1,1,2,4,6,30]
    a,x='a','x'
    eqs=[c.Eq(add(c.S(a),x),c.S(add(a,x))),
         c.Eq(d(c.S(a),c.S(x)),d(a,x)),
         c.Eq(d(add(a,x),x),a),
         c.Eq(d(add(x,a),x),a),
         c.Eq(d(a,add(x,a)),'0'),
         c.Eq(c.I(d(a,x),a,add(x,d(a,x))),a),
         c.Eq(z(d(x,a),e(kappa(add(tri(a),x)),a)),'0')]
    sizes=[c.size(t) for t in eqs]
    assert sizes==[13,17,13,13,13,26,67],sizes
    assert sum(c.size(c.close(('a','x'),t)) for t in eqs)==176
    current=[min(c.old_candidates(h,False).values()) for h in bodies]
    assert current==[16,16,23,30,39,92],current
    new={basis:[min(costs(h,basis).values()) for h in bodies]
         for basis in ('3','4','34')}
    assert new['3']==[16,16,23,30,35,91],new
    assert new['4']==new['34']==[16,16,23,30,35,90],new
    sep=c.size(c.Imp(c.Eq('0',c.S('0')),'FALSE'))
    cov=c.size(c.All('z',c.Ex('y',('or',c.Eq('z','0'),c.Eq('z',c.S('y'))))))
    k3=c.size(c.K3('A','B','C'))+c.size(c.And(c.Imp('A','B'),c.Imp('B','C')))+1
    k4=c.size(c.K4('A','B','C','D'))+c.size(c.And(c.Imp('A','B'),c.Imp('B',c.Imp('C','D'))))+1
    relative_k4=c.size(c.K4('A','B','C','D'))+c.size(c.K3('A','B',c.Imp('C','D')))+1
    assert (sep,cov,k3,k4,relative_k4)==(6,10,12,15,12)
    fixed={'3':sep+cov+k3,'4':sep+cov+k4,'34':sep+cov+k3+relative_k4}
    totals={basis:fixed[basis]+sum(values)+176 for basis,values in new.items()}
    assert totals=={'3':415,'4':417,'34':426},totals
    result={'status':'PASS','scope':'exact finite syntax counts, not an interpretation proof',
            'descriptors':dict(zip(('Q','Z','A','D','U','V'),map(c.stats,bodies))),
            'equation_sizes':sizes,'direct_identity_cost':176,
            'current_compatible_K3_computation':current,
            'new_computation':new,'fixed':fixed,
            'definition_records':{'K3':k3,'K4_standalone':k4,'K4_given_K3':relative_k4},
            'new_packet_totals':totals,
            'current_compatible_K3_packet_total':28+sum(current)+176}
    dest=Path(__file__).with_name('bootstrap_results.json')
    dest.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
