#!/usr/bin/env python3
"""Deterministic independent syntax-tree checks for guarded folding.

Run with Python 3; only the standard library is used. The script checks full
syntax-tree sizes (including frozen descriptors), literal substitution identities,
and exact comparison families. It writes compression_results.json next to itself.

WARNING: these calculations are not a formal proof of arithmetic equivalence,
intuitionistic validity, bi-interpretability, or equiconsistency. Those require the
mathematical arguments in the report. The old "union" is a module-cost envelope
across the priced logical bases; its entries cannot be combined while pretending
all logical-definition and finite-support costs are free. The exact fixed-record
costs and support qualifications are stated in the report.
"""
from random import Random
from pathlib import Path
import json

# A term is a variable/0 string or a tuple S(t), R(frozen_h,t,u).
# A formula is an equality, connective tuple, or quantifier plus one body.
def S(t): return ('S',t)
def R(h,t,u): return ('R',h,t,u)
def Eq(s,t): return ('=',s,t)
def Imp(p,q): return ('implies',p,q)
def All(name,p): return ('forall',name,p)
def Ex(name,p): return ('exists',name,p)
def And(p,q): return ('and',p,q)
def K4(a,b,c,d): return ('K4',a,b,c,d)
def K3(a,b,c): return ('K3',a,b,c)
def size(t):
    if isinstance(t,str): return 1
    if t[0] in ('forall','exists'): return 1+size(t[2])
    return 1+sum(size(x) for x in t[1:])
def subst(t,env):
    if isinstance(t,str): return env.get(t,t)
    if t[0]=='R': return R(t[1],subst(t[2],env),subst(t[3],env))
    return (t[0],*(subst(x,env) for x in t[1:]))
def occurrences(t,var):
    if isinstance(t,str): return int(t==var)
    if t[0]=='R': return occurrences(t[2],var)+occurrences(t[3],var)
    return sum(occurrences(x,var) for x in t[1:])
def contract(t):
    if t==S('w'): return 'x',1
    if isinstance(t,str): return t,0
    if t[0]=='R':
        a,j=contract(t[2]); b,k=contract(t[3]); return R(t[1],a,b),j+k
    vals=[contract(x) for x in t[1:]]
    return (t[0],*(x for x,j in vals)),sum(j for x,j in vals)
def dagger(h,u,z,x):
    t,_=contract(h)
    return subst(t,{'v':u,'w':z,'x':x})
def p(n): return R('w',n,'0')
def I(n,a,b): return R('w',R('0',n,S(a)),b)
def close(vars,f):
    for v in reversed(vars): f=All(v,f)
    return f

def Pdagger(h):
    rhs=I('n','a',dagger(h,R(h,p('n'),'a'),p('n'),'n'))
    return close(('a','n'),Eq(R(h,'n','a'),rhs))
def Ldagger(h):
    rhs=I('n','a',dagger(h,R(h,'z','a'),'z','n'))
    return close(('a','n','z'),Imp(Eq(p('n'),'z'),Eq(R(h,'n','a'),rhs)))
def Ngraph(h,arity=4):
    a=And(Eq(S('x'),'n'),Eq('y','u'))
    b=Eq(R(h,'x','a'),'y')
    c=Eq('x','n')
    d=Eq('y',I('n','a',dagger(h,'u',p('n'),'n')))
    matrix=K4(a,b,c,d) if arity==4 else K3(a,b,Imp(c,d))
    return close(('a','n'),Ex('u',close(('x','y'),matrix)))
def stats(h):
    h2,j=contract(h)
    return size(h),occurrences(h,'v'),j,occurrences(h2,'w')
def check(h):
    H,k,j,r=stats(h)
    assert size(contract(h)[0])==H-j
    assert occurrences(h,'w')==j+r
    assert dagger(h,'u','t',S('t'))==subst(h,{'v':'u','w':'t'})
    assert size(Pdagger(h))==2*H+13-j+k*(H+5)+3*r
    assert size(Ldagger(h))==2*H+21-j+k*(H+2)
    assert size(Ngraph(h))==2*H-j+31+3*r
    assert size(Ngraph(h,3))==2*H-j+32+3*r
    return H,k,j,r

def old_candidates(h,mixed=True):
    """Complete applicable old module envelope; retain dominated options for audit.

    mixed=True allows the union of K3, K4, J and mixed K3/J presentations.
    mixed=False restricts to the pure K3 options. Protected Q and Z cannot
    select the folded clauses which would circularly rely on their own support.
    """
    H,k,j,r=stats(h); ell=j+r
    if h in ('0','w'): return {'protected_D':16}
    d={'D':3*H+13+k*(H+2),'G_K3':3*H+21,'G_plain':3*H+22,
       'T_K3_unguarded':2*H+33,'T_K3_guarded':2*H-j+33,
       'P_folded':2*H+13+k*(H+5)+3*ell}
    if mixed:
        d.update({'M_K3J_guarded':2*H-j+32,'T_K4_unguarded':2*H+32,
                  'W_J_unguarded':2*H+32,'M_K3J_unguarded':2*H+32})
    if k==0:
        d.update({'L_folded':2*H+21,'V_K3':2*H+24,
                  'A_K3_guarded':2*H-j+3*r+22})
        if mixed: d['V_K4']=2*H+23
    if h=='v': d['identity']=8
    return d

def new_candidates(h,mixed=True):
    d=old_candidates(h,mixed)
    if h not in ('0','w'):
        d.update({'Pdagger':size(Pdagger(h)),'Ldagger':size(Ldagger(h)),
                  'N3':size(Ngraph(h,3))})
        if mixed: d['N4']=size(Ngraph(h,4))
    return d

def A(t,u): return R(S('v'),t,u)


def main():
    rng=Random(12729)
    pool=['0','v','w',S('w'),S('v'),S(S('w')),R('w','v','w'),R(S('v'),S('w'),'v')]
    for _ in range(500):
        op=rng.randrange(4)
        if op==0: t=S(rng.choice(pool))
        else: t=R(rng.choice(['w','0',S('v')]),rng.choice(pool),rng.choice(pool))
        if size(t)<300: pool.append(t)
    for h in pool: check(h)

    rows=[]
    t='0'; u=A('w',A('w',A('w','w'))); v='v'
    for m in range(21):
        H,k,j,r=check(t)
        assert (H,k,j,r)==(5*m+1,0,m,0)
        old=old_candidates(t)
        new=size(Pdagger(t))
        assert new==9*m+15
        if m>=3: assert min(old.values())==9*m+24
        rows.append({'family':1,'m':m,'H':H,'old_union_min':min(old.values()),
            'new_Pdagger':new,'new_union_min':min(new_candidates(t).values()),'old_winners':[n for n,c in old.items() if c==min(old.values())]})
        H,k,j,r=check(u)
        assert (H,k,j,r)==(5*m+13,0,m,4)
        old=old_candidates(u)
        pure=old_candidates(u,mixed=False)
        new=size(Ldagger(u))
        assert new==9*m+47 and size(Pdagger(u))==9*m+51
        if m>=12: assert min(old.values())==9*m+58
        if m>=13: assert min(pure.values())==9*m+59
        rows.append({'family':2,'m':m,'H':H,'old_union_min':min(old.values()),
            'new_Ldagger':new,'new_union_min':min(new_candidates(u).values()),'old_pure_K_min':min(pure.values())})
        H,k,j,r=check(v)
        assert (H,k,j,r)==(5*m+1,1,m,0)
        old=old_candidates(v); pure=old_candidates(v,mixed=False)
        new=size(Ngraph(v))
        assert new==9*m+33
        if m>=3:
            assert min(old.values())==9*m+34
            assert min(pure.values())==9*m+35
            assert size(Pdagger(v))>new and size(Ldagger(v))>new
        rows.append({'family':3,'m':m,'H':H,'old_union_min':min(old.values()),
            'new_N4':new,'new_union_min':min(new_candidates(v).values()),'old_pure_K_min':min(pure.values()),'new_N3':size(Ngraph(v,3))})
        for descriptor in (t,u,v):
            assert min(new_candidates(descriptor).values())<=min(old_candidates(descriptor).values())
            assert min(new_candidates(descriptor,False).values())<=min(old_candidates(descriptor,False).values())
        t=A(S('w'),t); u=A(S('w'),u); v=A(S('w'),v)
    assert size(Pdagger(S('w')))==16
    assert min(old_candidates(S('w')).values())==19
    out={'status':'PASS','random_and_seed_descriptors':len(pool),
         'family_descriptors':63,'scope':'Exact AST size and substitution checks; no full formal verification',
         'protected_helpers':{'Q':min(new_candidates('w').values()),'Z':min(new_candidates('0').values())},
         'small_strict_example':{'descriptor':'S(w)','old_min':min(old_candidates(S('w')).values()),'new_Pdagger':size(Pdagger(S('w')))},
         'logical_definition_costs':{'K3':12,'K4':15},
         'rows':rows}
    Path(__file__).with_name('compression_results.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))


if __name__ == "__main__":
    main()
