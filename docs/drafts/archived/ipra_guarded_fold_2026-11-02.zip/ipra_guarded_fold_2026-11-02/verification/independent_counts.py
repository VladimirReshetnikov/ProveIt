#!/usr/bin/env python3
"""Independent AST count audit. Finite syntax checks, not a proof checker."""
from dataclasses import dataclass
from random import Random

@dataclass(frozen=True)
class Node:
    op: str
    args: tuple = ()
    desc: object = None

def v(name): return Node(name)
def S(x): return Node('S',(x,))
def R(h,n,a): return Node('R',(n,a),h)
def node(op,*xs): return Node(op,xs)
def size(t):
    return 1+sum(size(x) for x in t.args)+(size(t.desc) if t.desc else 0)
def active(t,name):
    return int(not t.args and t.op==name)+sum(active(c,name) for c in t.args)
def factor(t,uu,tt,nn):
    if t==S(v('w')): return nn
    if t==v('v'): return uu
    if t==v('w'): return tt
    return Node(t.op,tuple(factor(c,uu,tt,nn) for c in t.args),t.desc)
def count_sw(t):
    if t==S(v('w')): return 1
    return sum(count_sw(c) for c in t.args)
def q(t,a): return R(v('w'),t,a)
def z(t,a): return R(v('0'),t,a)
def p(t): return q(t,v('0'))
def sel(n,a,b): return q(z(n,S(a)),b)
def eq(s,t): return node('=',s,t)
def imp(s,t): return node('->',s,t)
def conj(s,t): return node('&',s,t)
def bind(k,t):
    for _ in range(k): t=node('quantifier',t)
    return t

a,n,u,x,y=map(v,('a','n','u','x','y'))
def checks(h):
    H=size(h); k=active(h,'v'); ell=active(h,'w'); j=count_sw(h); r=ell-j
    direct=bind(2,eq(R(h,n,a),sel(n,a,factor(h,R(h,p(n),a),p(n),n))))
    let=bind(3,imp(eq(p(n),u),eq(R(h,n,a),sel(n,a,factor(h,R(h,u,a),u,n)))))
    A=conj(eq(S(x),n),eq(y,u)); B=eq(R(h,x,a),y)
    C=eq(x,n); D=eq(y,sel(n,a,factor(h,u,p(n),n)))
    graph4=bind(5,node('K4',A,B,C,D))
    graph3=bind(5,node('K3',A,B,imp(C,D)))
    expected=(2*H+13-j+k*(H+5)+3*r,
              2*H+21-j+k*(H+2),
              2*H-j+31+3*r,
              2*H-j+32+3*r)
    actual=tuple(map(size,(direct,let,graph4,graph3)))
    assert expected==actual,(h,expected,actual)
    assert factor(h,u,n,S(n))==subst(h,{'v':u,'w':n})
    return H,k,j,r,actual

def subst(t,env):
    if not t.args: return env.get(t.op,t)
    return Node(t.op,tuple(subst(c,env) for c in t.args),t.desc)

def main():
    rng=Random(417)
    pool=[v('0'),v('v'),v('w'),S(v('v')),S(v('w'))]
    descriptors=pool[:]
    tested=0
    for _ in range(2000):
        left=rng.choice(pool)
        if rng.randrange(3)==0:
            t=S(left)
        else:
            t=R(rng.choice(descriptors),left,rng.choice(pool))
        if size(t)<=300:
            checks(t);tested+=1;pool.append(t)
    triangular=R(S(v('v')),S(v('w')),v('v'))
    H,k,j,r,actual=checks(triangular)
    assert (H,k,j,r)==(6,1,1,0)
    assert actual[0]==35
    print('Independent AST audit passed:',tested,'generated bodies plus all seeds.')
    print('Triangular body H,k,j,r =',H,k,j,r)
    print('Pdagger, Lgeneral, N4, N3 sizes =',actual)
    for h in descriptors: checks(h)
    print('The identity hdagger(u,n,S(n))=h(u,n) passed by literal substitution.')
    print('These are finite syntax checks; mathematical generality comes from the written proofs.')

if __name__=='__main__': main()
