#!/usr/bin/env python3
"""Run the supporting checks and rebuild report.pdf with pdfLaTeX."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--checks-only", action="store_true")
parser.add_argument("--lean", action="store_true", help="also compile the local Lean kernel")
args = parser.parse_args()
result = subprocess.run([sys.executable, str(root / "verification/check.py")],
                        cwd=root, capture_output=True, text=True)
(root / "verification/checks.stdout.txt").write_text(result.stdout + result.stderr)
print(result.stdout, end="")
if result.returncode:
    raise SystemExit(result.returncode)
if args.lean:
    lean = os.environ.get("PRA_LEAN") or shutil.which("lean")
    if not lean:
        raise SystemExit("Lean not found; install Lean 4.19.0 or set PRA_LEAN.")
    result = subprocess.run([lean, "verification/Boundary.lean"], cwd=root,
                            capture_output=True, text=True)
    (root / "verification/Boundary.compiler.txt").write_text(result.stdout + result.stderr)
    if result.returncode:
        print(result.stderr)
        raise SystemExit(result.returncode)
if not args.checks_only:
    build = root / "build"
    build.mkdir(exist_ok=True)
    for number in range(1, 4):
        result = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                                 "-file-line-error", "-output-directory=build", "report.tex"],
                                cwd=root, capture_output=True, text=True)
        (build / f"pass_{number}.txt").write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-8000:])
            raise SystemExit(result.returncode)
    log = (build / "report.log").read_text()
    (root / "verification/latex_final.txt").write_text((build / "pass_3.txt").read_text())
    if "Overfull" in log or "undefined references" in log or "undefined on input line" in log:
        raise SystemExit("Review the TeX log: overflow or unresolved references remain.")
    shutil.copy2(build / "report.pdf", root / "report.pdf")
    print("Compiled report.pdf")
