/-
  Constructive local kernels for PRA with a ternary connective.
  Lean 4.19.0, core/Std only. No `sorry`, axioms, or Classical namespace.

  Scope: the propositional and first-order boundary deductions, the coverage
  bootstrap, and a natural-number witness scan. This file does not formalize
  the staged arithmetic syntax, the full arithmetic bootstrap, the compiler
  for all primitive-recursive descriptions, or the bi-interpretation theorem.
-/
import Std

namespace Boundary

/-- The proposed ternary connective, interpreted in intuitionistic logic. -/
def J (A U V : Prop) : Prop := (A ∨ U) ∧ (A → V)

theorem j_and (A B : Prop) : J A False B ↔ (A ∧ B) := by
  constructor
  · intro h
    have ha : A := h.1.elim id False.elim
    exact ⟨ha, h.2 ha⟩
  · intro h
    exact ⟨Or.inl h.1, fun _ => h.2⟩

theorem j_or (A B : Prop) : J A B True ↔ (A ∨ B) := by
  exact ⟨fun h => h.1, fun h => ⟨h, fun _ => True.intro⟩⟩

theorem j_imp (A B : Prop) : J A True B ↔ (A → B) := by
  exact ⟨fun h => h.2, fun h => ⟨Or.inr True.intro, h⟩⟩

variable {α : Type} (zero : α) (succ : α → α) (P : α → Prop)

def Native (n b : α) : Prop :=
  (b = zero ∨ P b) ∧ (P (succ b) → b = n)

def Direct (n b : α) : Prop :=
  J (P b) (b = zero) (P (succ b) → b = n)

def Universal (n b : α) : Prop :=
  ∀ x, J (P x) (x = b → b = zero) (x = succ b → b = n)

theorem universal_to_native {n b : α}
    (h : Universal zero succ P n b) : Native zero succ P n b := by
  constructor
  · cases (h b).1 with
    | inl hp => exact Or.inr hp
    | inr hb => exact Or.inl (hb rfl)
  · intro hp
    exact (h (succ b)).2 hp rfl

theorem native_to_direct {n b : α}
    (h : Native zero succ P n b) : Direct zero succ P n b := by
  constructor
  · exact h.1.elim Or.inr Or.inl
  · intro _
    exact h.2

theorem native_to_universal [DecidableEq α] {n b : α}
    (h : Native zero succ P n b) : Universal zero succ P n b := by
  intro x
  constructor
  · by_cases hxb : x = b
    · subst x
      cases h.1 with
      | inl hb => exact Or.inr (fun _ => hb)
      | inr hp => exact Or.inl hp
    · exact Or.inr (fun he => False.elim (hxb he))
  · intro hp hxs
    rw [hxs] at hp
    exact h.2 hp

theorem universal_iff_native [DecidableEq α] {n b : α} :
    Universal zero succ P n b ↔ Native zero succ P n b := by
  exact ⟨universal_to_native zero succ P, native_to_universal zero succ P⟩

theorem direct_induction
    (witness : ∀ n, ∃ b, Direct zero succ P n b)
    (base : P zero) (step : ∀ x, P x → P (succ x)) : ∀ n, P n := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  have hpb : P b := by
    cases hb.1 with
    | inl hp => exact hp
    | inr hz => simpa only [hz] using base
  have hbn : b = n := hb.2 hpb (step b hpb)
  simpa only [hbn] using hpb

theorem native_induction
    (witness : ∀ n, ∃ b, Native zero succ P n b)
    (base : P zero) (step : ∀ x, P x → P (succ x)) : ∀ n, P n := by
  apply direct_induction zero succ P _ base step
  intro n
  obtain ⟨b, hb⟩ := witness n
  exact ⟨b, native_to_direct zero succ P hb⟩

theorem universal_induction
    (witness : ∀ n, ∃ b, Universal zero succ P n b)
    (base : P zero) (step : ∀ x, P x → P (succ x)) : ∀ n, P n := by
  apply native_induction zero succ P _ base step
  intro n
  obtain ⟨b, hb⟩ := witness n
  exact ⟨b, universal_to_native zero succ P hb⟩

/-- Selecting either template separately for each target still suffices. -/
theorem mixed_induction
    (witness : ∀ n, ∃ b,
      Direct zero succ P n b ∨ Universal zero succ P n b)
    (base : P zero) (step : ∀ x, P x → P (succ x)) : ∀ n, P n := by
  apply direct_induction zero succ P _ base step
  intro n
  obtain ⟨b, hb⟩ := witness n
  refine ⟨b, ?_⟩
  cases hb with
  | inl hd => exact hd
  | inr hu =>
    exact native_to_direct zero succ P (universal_to_native zero succ P hu)

/-- No induction or equality decision is used in this coverage deduction. -/
theorem coverage (pred : α → α) (pred_succ : ∀ x, pred (succ x) = x)
    (witness : ∀ n, ∃ b,
      Universal zero succ (fun x => x = succ (pred x)) n b) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  have hn := universal_to_native zero succ (fun x => x = succ (pred x)) hb
  have hs : succ b = succ (pred (succ b)) := by rw [pred_succ b]
  have hbn : b = n := hn.2 hs
  simpa only [hbn] using hn.1

/-- A negative-polarity direct clause; `P` here is the unnegated equation. -/
def DirectNeg (n b : α) : Prop :=
  J (P b) (b = n ∨ P (succ b)) (b = zero)

def UniversalNeg (n b : α) : Prop :=
  ∀ x, J (P x) (x = succ b → b = n) (x = b → b = zero)

theorem direct_negative_induction
    (witness : ∀ n, ∃ b, DirectNeg zero succ P n b)
    (base : ¬ P zero) (step : ∀ x, ¬ P x → ¬ P (succ x)) :
    ∀ n, ¬ P n := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  have hnpb : ¬ P b := by
    intro hp
    have hz : b = zero := hb.2 hp
    rw [hz] at hp
    exact base hp
  have hnps : ¬ P (succ b) := step b hnpb
  have hbn : b = n := by
    cases hb.1 with
    | inl hp => exact False.elim (hnpb hp)
    | inr hs =>
      cases hs with
      | inl he => exact he
      | inr hp => exact False.elim (hnps hp)
  simpa only [hbn] using hnpb

theorem universal_negative_induction
    (witness : ∀ n, ∃ b, UniversalNeg zero succ P n b)
    (base : ¬ P zero) (step : ∀ x, ¬ P x → ¬ P (succ x)) :
    ∀ n, ¬ P n := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  have hnpb : ¬ P b := by
    intro hp
    have hz : b = zero := (hb b).2 hp rfl
    rw [hz] at hp
    exact base hp
  have hnps : ¬ P (succ b) := step b hnpb
  have hbn : b = n := by
    cases (hb (succ b)).1 with
    | inl hp => exact False.elim (hnps hp)
    | inr he => exact he rfl
  simpa only [hbn] using hnpb

/-- Negative equality at target `a` supplies a separate coverage proof. -/
theorem coverage_from_negative
    (witness : ∀ a, ∃ b, DirectNeg zero succ (fun x => x = a) a b) :
    ∀ a, a = zero ∨ ∃ b, a = succ b := by
  intro a
  obtain ⟨b, hb⟩ := witness a
  cases hb.1 with
  | inl hba =>
    exact Or.inl (hba.symm.trans (hb.2 hba))
  | inr hs =>
    cases hs with
    | inl hba => exact Or.inl (hba.symm.trans (hb.2 hba))
    | inr hsa => exact Or.inr ⟨b, hsa.symm⟩

section Scan

variable (A : Nat → Prop) [DecidablePred A]

/-- For primitive-recursive `A`, this same recursion is a PR witness scan. -/
def scan : Nat → Nat
  | 0 => 0
  | Nat.succ n =>
      if A (Nat.succ (scan n)) then Nat.succ n else scan n

theorem scan_boundary (n : Nat) : Native 0 Nat.succ A n (scan A n) := by
  induction n with
  | zero =>
    change (0 = 0 ∨ A 0) ∧ (A (Nat.succ 0) → 0 = 0)
    exact ⟨Or.inl rfl, fun _ => rfl⟩
  | succ n ih =>
    by_cases hs : A (Nat.succ (scan A n))
    · have he : scan A n = n := ih.2 hs
      have hn : A (Nat.succ n) := by simpa only [he] using hs
      change Native 0 Nat.succ A (Nat.succ n)
        (if A (Nat.succ (scan A n)) then Nat.succ n else scan A n)
      rw [if_pos hs]
      exact ⟨Or.inr hn, fun _ => rfl⟩
    · change Native 0 Nat.succ A (Nat.succ n)
        (if A (Nat.succ (scan A n)) then Nat.succ n else scan A n)
      rw [if_neg hs]
      exact ⟨ih.1, fun hp => False.elim (hs hp)⟩

theorem scan_le (n : Nat) : scan A n ≤ n := by
  induction n with
  | zero => exact Nat.le_refl 0
  | succ n ih =>
    change (if A (Nat.succ (scan A n)) then Nat.succ n else scan A n) ≤
      Nat.succ n
    split
    · exact Nat.le_refl _
    · exact Nat.le_trans ih (Nat.le_succ n)

theorem scan_direct (n : Nat) : Direct 0 Nat.succ A n (scan A n) := by
  exact native_to_direct 0 Nat.succ A (scan_boundary A n)

theorem scan_universal (n : Nat) : Universal 0 Nat.succ A n (scan A n) := by
  exact native_to_universal 0 Nat.succ A (scan_boundary A n)

end Scan

-- Kernel axiom audits. Each theorem below is checked in Lean's kernel.
#print axioms j_and
#print axioms j_or
#print axioms j_imp
#print axioms universal_to_native
#print axioms native_to_direct
#print axioms native_to_universal
#print axioms direct_induction
#print axioms universal_induction
#print axioms mixed_induction
#print axioms coverage
#print axioms direct_negative_induction
#print axioms universal_negative_induction
#print axioms coverage_from_negative
#print axioms scan_boundary
#print axioms scan_le
#print axioms scan_direct
#print axioms scan_universal

end Boundary
