#!/usr/bin/env python3
"""Reproduce syntax, finite logical, witness, and logical-basis checks.

Python 3.10+, standard library only. These are finite checks, not a proof of
the full arithmetic compiler or bi-interpretation. The literal AST convention
follows the audited atomic serialization, with a fresh implementation of the
J templates and a retained native fallback for honest finite-packet costs.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from pathlib import Path
import json


@dataclass(frozen=True)
class Tree:
    tag: str
    label: str = ""
    args: tuple["Tree", ...] = ()
    body: "Tree | None" = None

    def size(self, full=True):
        return (1 + sum(t.size(full) for t in self.args)
                + (self.body.size(True) if full and self.body is not None else 0))

    def occurrences(self, variable):
        return int(self.tag == "var" and self.label == variable) + sum(
            t.occurrences(variable) for t in self.args)

    def subst(self, variable, replacement):
        if self.tag in ("all", "ex"):
            raise ValueError("Substitution is restricted to unbound input terms")
        if self.tag == "var" and self.label == variable:
            return replacement
        return Tree(self.tag, self.label,
                    tuple(t.subst(variable, replacement) for t in self.args), self.body)

    def data(self):
        result = {"tag": self.tag}
        if self.label:
            result["label"] = self.label
        if self.args:
            result["args"] = [t.data() for t in self.args]
        if self.body is not None:
            result["frozen_body"] = self.body.data()
        return result


def var(label):
    return Tree("var", label)


def op(tag, *args):
    return Tree(tag, args=tuple(args))


def S(t):
    return Tree("app", "S", (t,))


def R(body, n, a):
    return Tree("app", "R", (n, a), body)


def bind(prefix, t):
    for tag, name in reversed(prefix):
        t = Tree(tag, name, (t,))
    return t


zero = Tree("const", "0")
false = Tree("false")
x, a, n, b, c, u, v, w = map(var, ("x", "a", "n", "b", "c", "u", "v", "w"))
Eq = lambda s, t: op("eq", s, t)
Or = lambda p, q: op("or", p, q)
And = lambda p, q: op("and", p, q)
Imp = lambda p, q: op("imp", p, q)
J = lambda p, q, r: op("J", p, q, r)
If = lambda p, q, r: op("If", p, q, r)
prefix = (("all", "a"), ("all", "n"), ("ex", "b"))


def at(equation, point):
    return equation.subst("x", point)


def j_templates(equation):
    direct = bind(prefix, J(at(equation, b), Eq(b, zero),
                           Imp(at(equation, S(b)), Eq(b, n))))
    universal = bind(prefix + (("all", "x"),),
                     J(equation, Imp(Eq(x, b), Eq(b, zero)),
                       Imp(Eq(x, S(b)), Eq(b, n))))
    return {"D": direct, "U": universal}


def negative_j_templates(equation):
    return {
        "D-": bind(prefix, J(at(equation, b),
                              Or(Eq(b, n), at(equation, S(b))), Eq(b, zero))),
        "U-": bind(prefix + (("all", "x"),),
                    J(equation, Imp(Eq(x, S(b)), Eq(b, n)),
                      Imp(Eq(x, b), Eq(b, zero))))}


def native_templates(equation):
    """The five existing native atomic candidates, explicitly serialized."""
    s, t = equation.args

    def constraints(left, right):
        p = Eq(left, right)
        return And(Imp(Eq(x, b), Or(Eq(b, zero), p)),
                   Imp(Eq(x, S(b)), Imp(p, Eq(b, n))))

    return {
        "B": bind(prefix, And(Or(Eq(b, zero), at(equation, b)),
                              Imp(at(equation, S(b)), Eq(b, n)))),
        "B-shared": bind(prefix + (("ex", "c"),),
                         And(Eq(c, S(b)), And(Or(Eq(b, zero), at(equation, b)),
                                              Imp(at(equation, c), Eq(b, n))))),
        "B-values": bind(prefix + (("all", "x"), ("all", "u"), ("all", "v")),
                         Imp(And(Eq(u, s), Eq(v, t)), constraints(u, v))),
        "B-left": bind(prefix + (("all", "x"), ("all", "u")),
                       Imp(Eq(u, s), constraints(u, t))),
        "B-right": bind(prefix + (("all", "x"), ("all", "v")),
                        Imp(Eq(v, t), constraints(s, v)))}


def old_if_universal(equation):
    return bind(prefix + (("all", "x"),),
                If(equation, Imp(Eq(x, S(b)), Eq(b, n)),
                   Imp(Eq(x, b), Eq(b, zero))))


def expand_j(t):
    children = tuple(expand_j(c) for c in t.args)
    if t.tag == "J":
        p, q, r = children
        return And(Or(p, q), Imp(p, r))
    return Tree(t.tag, t.label, children, t.body)


def emit(equation):
    i = equation.occurrences("x")
    if not i:
        return "omitted", None
    # Full size is indispensable here. At F+i=9 choose U.
    name = "D" if equation.size(True) + i <= 8 else "U"
    return name, j_templates(equation)[name]


def chain(t, count):
    for _ in range(count):
        t = S(t)
    return t


def packet(equations):
    """Choose existing native or new J basis for a literal finite packet.

    Include every actual boundary-support instance in the input. Computational
    support is a separately specified common cost. This is not a finite PRA
    axiomatization or a shortest-proof search. Duplicate literal inputs are
    removed, in keeping with axiom-set rather than multiset accounting.
    """
    inputs = list(dict.fromkeys(equations))
    native_costs, old_if_costs, new_j_costs = [], [], []
    native_forms, new_forms = [], []
    for e in inputs:
        if e.occurrences("x") == 0:
            continue
        forms = native_templates(e)
        native_name = min(forms, key=lambda name: forms[name].size())
        native_costs.append(forms[native_name].size())
        native_forms.append({"template": native_name, "ast": forms[native_name].data()})
        F, i = e.size(), e.occurrences("x")
        old_if_costs.append(min(2*F+i+12, F+20))
        new_name, new_form = emit(e)
        new_j_costs.append(new_form.size())
        new_forms.append({"template": new_name, "ast": new_form.data()})
    native_total = 6 + sum(native_costs)
    old_total = min(native_total, 20 + sum(old_if_costs))
    j_total = 18 + sum(new_j_costs)
    choice = "existing_native" if native_total <= j_total else "new_J"
    return {"old_best": old_total, "new_best": min(native_total, j_total),
            "native_total": native_total, "old_conditional_total": 20 + sum(old_if_costs),
            "new_J_total": j_total, "selected_basis": choice,
            "modules": native_forms if choice == "existing_native" else new_forms}


def syntax_checks():
    q = lambda r, z: R(w, r, z)
    nested_body = q(S(v), S(w))
    nested = R(nested_body, x, a)
    samples = [x, a, zero, S(x), S(a), q(x, zero), q(a, x),
               R(zero, x, a), nested, q(nested, q(x, S(a))),
               chain(x, 19), chain(a, 19), chain(x, 99)]
    checks = 0
    for s in samples:
        for t in samples:
            e = Eq(s, t)
            i = e.occurrences("x")
            for full in (False, True):
                F = e.size(full)
                assert at(e, S(b)).size(full) == F + i
                forms = j_templates(e)
                assert forms["D"].size(full) == 2*F+i+11
                assert forms["U"].size(full) == F+20
                for name, node in negative_j_templates(e).items():
                    assert node.size(full) == (2*F+i+11 if name == "D-" else F+20)
                assert expand_j(forms["D"]).size(full) == 3*F+i+13
                assert expand_j(forms["U"]).size(full) == 2*F+22
                assert old_if_universal(e).size(full) == F+20
                natives = native_templates(e)
                T, U = s.size(full), t.size(full)
                expected = {"B": 2*F+i+12, "B-shared": 2*F+18,
                            "B-values": F+35, "B-left": T+2*U+30,
                            "B-right": 2*T+U+30}
                for name, node in natives.items():
                    assert node.size(full) == expected[name]
                checks += 13
            name, chosen = emit(e)
            if i:
                F = e.size()
                assert chosen.size() == min(2*F+i+11, F+20)
                assert name == ("D" if F+i <= 8 else "U")
                old = min(2*F+i+12, F+20)
                assert old - chosen.size() == int(F+i <= 8)
            else:
                assert chosen is None and name == "omitted"
    # Descriptor substitution must leave the stored program unchanged.
    assert nested.subst("x", S(b)).body == nested_body
    assert nested.subst("w", zero).body == nested_body
    coverage = Eq(x, S(q(x, zero)))
    assert (coverage.size(), coverage.size(False), coverage.occurrences("x")) == (7, 6, 2)
    assert emit(coverage)[0] == "U"
    assert coverage.size(False) + coverage.occurrences("x") == 8
    assert [node.size() for node in j_templates(coverage).values()] == [27, 27]
    A, U, V = Tree("meta", "A"), Tree("meta", "U"), Tree("meta", "V")
    j_record = J(A, U, V).size() + expand_j(J(A, U, V)).size() + 1
    if_record = (If(A, U, V).size()
                 + Or(And(A, U), And(Imp(A, false), V)).size() + 1)
    assert (j_record, if_record) == (12, 14)
    assert Imp(Eq(zero, S(zero)), false).size() == 6
    packets = []
    for obligations in ([Eq(x, a)], [coverage, Eq(chain(x, 19), chain(a, 19))],
                        [coverage, Eq(chain(x, 39), zero), Eq(chain(x, 40), zero)]):
        result = packet(obligations)
        assert result["new_best"] <= result["old_best"]
        packets.append(result)
    return {"literal_AST_size_checks": checks,
            "coverage": {"full": 7, "active": 6, "i": 2, "selected": "U", "size": 27},
            "definition_records": {"J": j_record, "strong_conditional": if_record},
            "packet_examples": packets}


def implies(a, b):
    return not a or b


def j(a, u, v):
    return (a or u) and implies(a, v)


def finite_logic_checks():
    cases = 0
    for m in range(1, 5):
        for successor in product(range(m), repeat=m):
            for pred in product((False, True), repeat=m):
                step = all(implies(pred[y], pred[successor[y]]) for y in range(m))
                for target in range(m):
                    for witness in range(m):
                        b0, bn = witness == 0, witness == target
                        pb, ps = pred[witness], pred[successor[witness]]
                        native = (b0 or pb) and implies(ps, bn)
                        direct = j(pb, b0, implies(ps, bn))
                        universal = all(j(pred[y], implies(y == witness, b0),
                                          implies(y == successor[witness], bn))
                                        for y in range(m))
                        assert implies(universal, native)
                        assert implies(native, direct)
                        assert implies(native, universal)
                        assert implies(direct and pred[0] and step, pred[target])
                        neg_step = all(implies(not pred[y], not pred[successor[y]]) for y in range(m))
                        direct_neg = j(pb, bn or ps, b0)
                        universal_neg = all(j(pred[y], implies(y == successor[witness], bn),
                                              implies(y == witness, b0)) for y in range(m))
                        assert implies(direct_neg and not pred[0] and neg_step, not pred[target])
                        assert implies(universal_neg and not pred[0] and neg_step, not pred[target])
                        cases += 1
    return cases


def scan_checks():
    cases = 0
    for length in range(2, 13):
        for trace in product((False, True), repeat=length):
            witness = 0
            for target in range(length-1):
                if target:
                    if trace[witness+1]:
                        witness = target
                native = (witness == 0 or trace[witness]) and implies(trace[witness+1], witness == target)
                assert native and 0 <= witness <= target
                for probe in range(length):
                    assert j(trace[probe], implies(probe == witness, witness == 0),
                             implies(probe == witness+1, witness == target))
                assert j(trace[witness], witness == 0, implies(trace[witness+1], witness == target))
                cases += 1
    return cases


def basis_checks():
    # Three-element Heyting chain: 0=false, 1=undecided, 2=true.
    hi = lambda p, q: 2 if p <= q else q
    hj = lambda p, q, r: min(max(p, q), hi(p, r))
    for p, q in product(range(3), repeat=2):
        assert hj(p, 0, q) == min(p, q)
        assert hj(p, q, 2) == max(p, q)
        assert hj(p, 2, q) == hi(p, q)
    weak = hj(1, 2, 2)
    strong = max(min(1, 2), min(hi(1, 0), 2))
    assert (weak, strong) == (2, 1)
    # Enumerate all truth functions represented by binary formulas through
    # seven nodes. Deduplicating truth tables preserves all later possibilities.
    mask = 255
    atoms = []
    for coordinate in range(3):
        atoms.append(sum(((assignment >> coordinate) & 1) << assignment for assignment in range(8)))
    A, U, V = atoms
    target = (A | U) & (((~A) & mask) | V)
    functions = {1: set(atoms + [0])}
    minimum = None
    for size in (1, 3, 5, 7):
        if size > 1:
            current = set()
            for left in range(1, size-1, 2):
                right = size-1-left
                for p, q in product(functions[left], functions[right]):
                    current.update((p & q, p | q, ((~p) & mask) | q))
            functions[size] = current
        if target in functions[size] and minimum is None:
            minimum = size
    assert minimum == 7
    return {"Heyting_counterexample": {"A": 1, "U": 2, "V": 2,
                                        "J": weak, "strong_conditional": strong},
            "minimum_binary_formula_size_for_classical_J": minimum,
            "truth_functions_by_exact_size": {str(k): len(v) for k, v in functions.items()}}


def main():
    result = {"syntax": syntax_checks(),
              "finite_arbitrary_carrier_cases": finite_logic_checks(),
              "finite_scan_invariants": scan_checks(),
              "logical_basis": basis_checks(),
              "scope": "Finite supporting checks only; full interpretation proofs are in report.pdf."}
    here = Path(__file__).resolve().parent
    (here / "checks.json").write_text(json.dumps(result, indent=2) + "\n")
    compact = {k: v for k, v in result.items() if k != "syntax"}
    compact["syntax"] = {k: v for k, v in result["syntax"].items() if k != "packet_examples"}
    compact["packet_totals"] = [{k: v for k, v in packet.items() if k != "modules"}
                                for packet in result["syntax"]["packet_examples"]]
    print(json.dumps(compact, indent=2))


if __name__ == "__main__":
    main()
