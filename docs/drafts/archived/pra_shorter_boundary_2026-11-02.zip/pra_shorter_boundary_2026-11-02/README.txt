A SMALLER BOUNDARY AXIOMATIZATION OF PRA
Prepared for Vladimir Reshetnikov, 2 November 2026.

START HERE
  report.pdf          Full report, proofs, audit, and research questions.
  report.tex          LaTeX entry point; sections/ contains its included files.
  AXIOMS.txt          Standalone exact theory, size rule, and critical tie.

NEW RESULT
  J(A,U,V) := (A OR U) AND (A -> V).
  Initial arithmetic symbols: 0,S.
  One staged family of binary initialized recursors R_h.
  One fixed arithmetic sentence: 0 != S(0).
  Boundary generation is indexed only by equations E(x,a).

  For full equation size F and i>0 active induction-variable occurrences,
  the new envelope is min(2F+i+11,F+20), versus min(2F+i+12,F+20).
  J's explicit logical-definition record is 12 nodes, versus the current
  strong conditional's 14. Computation and proof support remain separate.

  The universal branch must be chosen on ties. The atomic coverage input
  x=S(Q(x,0)), with Q=R_w, has F=7,i=2 and selects that branch at cost27.
  A proved product countermodel rules out even finite-parameter
  bi-interpretability for the direct-only atomic theory.

  Complete written proofs establish common conservative definitional
  extensions with first-order PRA and whole-carrier identity composites,
  separately classically and intuitionistically.

COMPARISON HONESTY
  All five current packages improve the eight archived packages in some
  respect and are retained. The atomic restriction and arithmetic
  bootstrap are inherited and credited. A new named connective may lose
  on an isolated finite workload. The included packet exporter retains
  existing native serializers when cheaper; see report Section 5.
  No absolute shortestness over arbitrary logics or signatures is claimed.

CHECKS
  python3 build.py --checks-only
  lean verification/Boundary.lean

  Lean 4.19.0 compiled 17 printed theorem dependency audits with no axioms.
  This is a local kernel check, NOT a full formalization of the compiler
  or bi-interpretation. Python uses only its standard library.

REBUILD PDF
  python3 build.py
  Optional combined check: python3 build.py --lean
  Set PRA_LEAN if the Lean executable is not on PATH.
  A normal pdfLaTeX installation with the packages in report.tex suffices.

CONTENTS
  verification/Boundary.lean        Constructive local logical proofs.
  verification/Boundary.compiler.txt Recorded successful Lean output.
  verification/check.py             Literal AST emitter and finite checks.
  verification/checks.json           Results and literal packet exports.
  verification/checks.stdout.txt     Compact checker output.
  verification/latex_final.txt       Final LaTeX compilation output.
  verification/pdf_review.json      Rendering and visual QA record.
  provenance/source_manifest.json   Input archives, hashes, immutable URLs.
  MANIFEST.sha256                    Hashes of package files except itself.

SOURCE SNAPSHOT
  ProveIt commit 2ba9e7a5767fee450c6611868fdf0c4d3a27754e.
  The current directory and its archived subdirectory were both reviewed.
  Inputs are referenced, not duplicated. No repository changes were posted.
