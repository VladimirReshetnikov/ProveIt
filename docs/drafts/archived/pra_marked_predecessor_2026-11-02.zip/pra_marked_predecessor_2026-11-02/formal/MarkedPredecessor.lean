import Init

/-
  Marked predecessor witnesses: the arbitrary-carrier logical core.

  This file checks the local induction argument and a concrete boundary
  witness over Nat.  It does not formalize the generated first-order
  language, the PR compiler, pairing, or the full bi-interpretation.
  All arithmetic assumptions in the abstract part are theorem parameters.
-/

namespace MarkedPredecessor

universe u

section Abstract

variable {A : Type u}

theorem successor_injective
    (z : A) (s : A → A) (q : A → A → A)
    (qSucc : ∀ x a, q (s x) a = x) :
    ∀ x y, s x = s y → x = y := by
  intro x y h
  calc
    x = q (s x) z := (qSucc x z).symm
    _ = q (s y) z := congrArg (fun v => q v z) h
    _ = y := qSucc y z

theorem successor_ne_zero
    (z : A) (s : A → A) (q : A → A → A)
    (qZero : ∀ a, q z a = a)
    (qSucc : ∀ x a, q (s x) a = x)
    (separate : z ≠ s z) :
    ∀ x, s x ≠ z := by
  intro x hx
  have hxz : x = z := by
    calc
      x = q (s x) z := (qSucc x z).symm
      _ = q z z := congrArg (fun v => q v z) hx
      _ = z := qZero z
  have hsz : s z = z := by
    calc
      s z = s x := congrArg s hxz.symm
      _ = z := hx
  exact separate hsz.symm

def marker (q : A → A → A) (τ : A → A) (x : A) : A :=
  q (τ x) x

theorem marker_cases
    (z : A) (s : A → A) (q : A → A → A) (τ : A → A)
    (qZero : ∀ a, q z a = a)
    (qSucc : ∀ x a, q (s x) a = x)
    (bits : ∀ x, τ x = z ∨ τ x = s z) :
    ∀ x, marker q τ x = z ∨ marker q τ x = x := by
  intro x
  cases bits x with
  | inl h =>
      exact Or.inr (calc
        marker q τ x = q z x := congrArg (fun v => q v x) h
        _ = x := qZero x)
  | inr h =>
      exact Or.inl (calc
        marker q τ x = q (s z) x := congrArg (fun v => q v x) h
        _ = z := qSucc z x)

theorem marker_zero
    (z : A) (s : A → A) (q : A → A → A) (τ : A → A)
    (qZero : ∀ a, q z a = a)
    (qSucc : ∀ x a, q (s x) a = x)
    (bits : ∀ x, τ x = z ∨ τ x = s z) :
    marker q τ z = z := by
  cases marker_cases z s q τ qZero qSucc bits z with
  | inl h => exact h
  | inr h => exact h

theorem marker_reflection
    (z : A) (s : A → A) (q : A → A → A) (τ : A → A)
    (P : A → Prop)
    (qZero : ∀ a, q z a = a)
    (qSucc : ∀ x a, q (s x) a = x)
    (bits : ∀ x, τ x = z ∨ τ x = s z)
    (truth : ∀ x, τ x = s z ↔ P x)
    (base : P z) :
    ∀ x, marker q τ x = z ↔ P x := by
  intro x
  constructor
  · intro hm
    cases bits x with
    | inl h =>
        have hx : marker q τ x = x := by
          calc
            marker q τ x = q z x := congrArg (fun v => q v x) h
            _ = x := qZero x
        have hxz : x = z := hx.symm.trans hm
        exact hxz.symm ▸ base
    | inr h => exact (truth x).mp h
  · intro hp
    have ht := (truth x).mpr hp
    calc
      marker q τ x = q (s z) x := congrArg (fun v => q v x) ht
      _ = z := qSucc z x

/-
  This is the central witness-elimination kernel.  It has no assumption
  that every carrier element is zero or a successor.
-/
theorem witness_progress
    (z : A) (s : A → A) (q : A → A → A) (m : A → A)
    (qZero : ∀ a, q z a = a)
    (qSucc : ∀ x a, q (s x) a = x)
    (succNe : ∀ x, s x ≠ z)
    (rangeAtSucc : ∀ x, m (s x) = z ∨ m (s x) = s x)
    (witness : ∀ n, ∃ b, m (q (m (s b)) n) = z)
    (progress : ∀ x, m x = z → m (s x) = z) :
    ∀ n, m n = z := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  cases rangeAtSucc b with
  | inl h =>
      simpa only [h, qZero] using hb
  | inr h =>
      have hb0 : m b = z := by
        simpa only [h, qSucc] using hb
      have hs0 := progress b hb0
      exact False.elim (succNe b (h.symm.trans hs0))

/-
  P is arbitrary here, but is accompanied by a Boolean term realization τ.
  The manuscript constructs that realization syntactically for each
  quantifier-free formula; this Lean theorem does not assume unrestricted
  induction for arbitrary P.
-/
theorem local_induction
    (z : A) (s : A → A) (q : A → A → A) (τ : A → A)
    (P : A → Prop)
    (qZero : ∀ a, q z a = a)
    (qSucc : ∀ x a, q (s x) a = x)
    (separate : z ≠ s z)
    (bits : ∀ x, τ x = z ∨ τ x = s z)
    (truth : ∀ x, τ x = s z ↔ P x)
    (witness : ∀ n, ∃ b,
      marker q τ (q (marker q τ (s b)) n) = z)
    (base : P z)
    (step : ∀ x, P x → P (s x)) :
    ∀ n, P n := by
  have reflection := marker_reflection z s q τ P qZero qSucc bits truth base
  have prog : ∀ x, marker q τ x = z → marker q τ (s x) = z := by
    intro x hx
    exact (reflection (s x)).mpr (step x ((reflection x).mp hx))
  have allZero := witness_progress z s q (marker q τ) qZero qSucc
    (successor_ne_zero z s q qZero qSucc separate)
    (fun x => marker_cases z s q τ qZero qSucc bits (s x)) witness prog
  intro n
  exact (reflection n).mp (allZero n)

end Abstract

section NaturalWitness

def natQ : Nat → Nat → Nat
  | 0, n => n
  | b + 1, _ => b

def boundaryCandidate (m : Nat → Nat) : Nat → Nat
  | 0 => 0
  | n + 1 =>
      if m (boundaryCandidate m n + 1) = 0 then n + 1
      else boundaryCandidate m n

/- The invariant corresponds to one quantifier-free induction in PRA. -/
theorem boundary_invariant
    (m : Nat → Nat) (base : m 0 = 0) :
    ∀ n, m (boundaryCandidate m n) = 0 ∧
      (m (boundaryCandidate m n + 1) = 0 → boundaryCandidate m n = n) := by
  intro n
  induction n with
  | zero =>
      constructor
      · exact base
      · intro _
        rfl
  | succ n ih =>
      by_cases htest : m (boundaryCandidate m n + 1) = 0
      · have hidx : boundaryCandidate m n = n := ih.2 htest
        have hc : boundaryCandidate m (n + 1) = n + 1 := by
          exact if_pos htest
        rw [hc]
        constructor
        · exact (congrArg (fun k => m (k + 1)) hidx).symm.trans htest
        · intro _
          rfl
      · have hc : boundaryCandidate m (n + 1) = boundaryCandidate m n := by
          exact if_neg htest
        rw [hc]
        exact ⟨ih.1, fun h => False.elim (htest h)⟩

theorem natural_witness
    (m : Nat → Nat) (base : m 0 = 0)
    (range : ∀ x, m x = 0 ∨ m x = x) :
    ∀ n, ∃ b, m (natQ (m (b + 1)) n) = 0 := by
  intro n
  let b := boundaryCandidate m n
  have hi : m b = 0 ∧ (m (b + 1) = 0 → b = n) :=
    boundary_invariant m base n
  refine ⟨b, ?_⟩
  cases range (b + 1) with
  | inl h =>
      rw [h, natQ]
      have hidx : b = n := hi.2 h
      exact hidx ▸ hi.1
  | inr h =>
      rw [h, natQ]
      exact hi.1

end NaturalWitness

#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms marker_cases
#print axioms marker_zero
#print axioms marker_reflection
#print axioms witness_progress
#print axioms local_induction
#print axioms boundary_invariant
#print axioms natural_witness

end MarkedPredecessor
