PRA FROM A MARKED PREDECESSOR PRINCIPLE
November 2, 2026

MAIN RESULT
The readable theory replaces recursive induction latches by pointwise
Boolean markers. Its witness sentence has 13 active syntax-tree nodes,
against the current drafts' 14-node recurring minimum. It needs no
separate zero-or-successor coverage axiom. The two fixed seeds total 24
nodes. A separate seven-case serializer strictly improves both inherited
tree metrics at every shared raw input of the six inspected drafts.

The theories are proved bi-interpretable and equiconsistent with the
matching first-order PRA, with full carriers, native equality, and
identity round trips. All marker bodies and defining equations are
explicitly charged. No absolute or encoding-independent minimum is claimed.

START HERE
  report.pdf       Complete mathematical report and proofs.
  report.tex       Main LaTeX source; supporting files are in sections/.
  AXIOMS.txt       Complete readable theory and optional serializer.

SUPPORTING ARTIFACTS
  checks/check_theory.py    Exact tree counts, Boolean compiler, finite
                            scan checks, and actual-draft comparisons.
  checks/optional_emitter.py
                            All six old emitters and the new serializer.
  checks/results.json      Reproducible core results and formula trees.
  checks/optional_results.json
                            Sampled serializer audit, with every branch.
  formal/MarkedPredecessor.lean
                            Lean-checked local kernel and Nat witness.
  formal/SCOPE.txt          Exact limits of the formal verification.
  provenance/              Repository snapshot, archive identifiers/hashes.
  verification/            Build, mathematical-review, and PDF-QA records.
  SHA256SUMS               Checksums of the packaged files.

BUILD AND CHECK
Python 3.10+ and a TeX installation with pdflatex are required.
LaTeX packages: lmodern, microtype, geometry, amsmath, amssymb, amsthm,
mathtools, booktabs, longtable, array, xcolor, enumitem, hyperref.

From the extracted package directory:
  python3 build.py

This runs both Python checkers and compiles report.pdf in three passes.
The Python programs use only the standard library. They do not fetch
source archives or require an internet connection.

To check the formal kernel with Lean 4.19.0:
  cd formal
  lean MarkedPredecessor.lean

All nine recorded theorem axiom reports are empty. The file uses only
Lean Init. No Lean binary or compiled object is included in the archive.

VERIFICATION SCOPE
The full bi-interpretation, pairing, Boolean syntax compiler, and infinite
serializer comparison are written mathematical proofs. Lean verifies the
local logical kernel and the reverse witness construction over Nat; it
does not encode the full metatheorem or PRA proof syntax. Finite Python
checks support the manuscript but are not proofs of infinite schemas.

SOURCE COMPARISON
Repository: https://github.com/VladimirReshetnikov/ProveIt
Snapshot: 41ead086f47172a707910a072eb1a722a17a85ca
Folder: docs/drafts
Six archives: absorbing_return, coverage_boundary, exit_witness,
predecessor_return, predecessor_witness, separated_recursion,
each with the pra_ prefix and _2026-11-02.zip suffix.

The report distinguishes the literal pointwise serializer improvement
from the conceptual 13-node marker principle. The serializer pays for
seven scheduling cases and emits harmless tautologies at unused inputs.
These costs prevent a claim of a globally shortest presentation.
