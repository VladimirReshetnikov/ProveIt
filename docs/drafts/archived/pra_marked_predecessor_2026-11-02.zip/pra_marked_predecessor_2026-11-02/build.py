#!/usr/bin/env python3
"""Run the included finite checks and compile report.pdf reproducibly."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / "verification"
VERIFY.mkdir(exist_ok=True)

def run(args, filename):
    result = subprocess.run(args, cwd=ROOT, text=True, capture_output=True)
    (VERIFY / filename).write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode:
        raise SystemExit(f"Command failed; see verification/{filename}")
    return {"command": args, "exit_code": result.returncode, "log": filename}

def main():
    if not shutil.which("pdflatex"):
        raise SystemExit("Install pdflatex with the packages listed in README.txt.")
    results = [
        run([sys.executable, "checks/check_theory.py"], "python_core.txt"),
        run([sys.executable, "checks/optional_emitter.py"], "python_optional.txt"),
    ]
    for i in range(1, 4):
        results.append(run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex"], f"latex_pass_{i}.txt"))
    result = {
        "status": "passed",
        "commands": results,
        "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
        "scope": "Build and finite-check results; mathematical proof scope is stated in the manuscript and formal/SCOPE.txt.",
    }
    (VERIFY / "build_results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "pdf": str(ROOT / "report.pdf")}, indent=2))

if __name__ == "__main__":
    main()
