EXECUTABLE CHECKS
=================

Requirements: Python 3.10 or later, standard library only.
From the package root:

    python3 checks/check_theory.py

This regenerates checks/results.json and prints a concise summary.
An alternative JSON path can be given with --output PATH.

The checker constructs literal abstract syntax trees. Each variable,
constant, application, equality, connective and quantifier costs one node.
Full size charges the entire frozen function description at every occurrence.
Substitution into active arguments does not change stored descriptions.

Checks performed:

* Exact sizes of the fixed seed, recursion templates, marker definitions,
  shifted witnesses, and complete marker-definition/witness units.
  The primary separate separation and bit axioms total 24 nodes; the optional
  conjoined seed costs 25 nodes. The JSON distinguishes these presentations.
* Independent semantic evaluation of the Boolean compiler on all 2,703
  formulas of connective depth at most two over two equality atoms and false,
  in 25 numerical environments each. The marker's 0-or-input range and
  truth reflection are checked in the same environments.
* The explicit last-good-index scan, its quantifier-free invariant, and the
  resulting witness on all 4,096 self-indexed marker sequences through
  index 12, for all 13 targets in each sequence.
* Exact witness costs obtained by transcribing the actual equality-predicate
  compiler from each of the six inspected drafts. Both supplementary
  one-transition formulas in the separated-recursion draft are included.
  Source filenames and text hashes are recorded in the script and JSON.
  Readable base-plus-step-plus-witness units are also counted for each old
  compiler. Direct and bound-state steps are retained separately; a reported
  coordinatewise minimum need not be realized by one formula.

The equality example is P(n,a) := n=a. The complete newly added marker body
is stored and charged. Its definition costs 11 active/18 full nodes, its
witness 13 active/26 full nodes, and their sum 24 active/44 full nodes.

The finite checks do not establish the infinite axiom schema, arithmetic
induction, or bi-interpretability. Those statements require the mathematical
proofs in the manuscript. The comparison is about the specified actual
compiler outputs; it is not an encoding-independent lower bound or a
comparison of entire axiom emitters and generator byte lengths.

OPTIONAL SAME-INPUT EMITTER CHECK
--------------------------------

    python3 checks/optional_emitter.py

This writes checks/optional_results.json. It constructs the exact six current
primary emitters, their relevant recorded optional variants, and the new
seven-case scheduler on a common OLD R-only raw-input grammar. New composition
names do not occur in raw inputs or their frozen descriptions. Every reserved
branch and every branch of the six source emitters occurs in the finite sample.
For each sample input the new sentence is strictly smaller than every
comparator in both active and full size. The exact step envelope at the
reserved nonexceptional pad depths is checked independently as well.

The accompanying unbounded case proof is necessary: this finite sample is not
an enumeration of all legal terms. The scheduling result measures emitted
formula trees; the extra emitter cases, aliases, and composition-name family
remain real specification costs.
