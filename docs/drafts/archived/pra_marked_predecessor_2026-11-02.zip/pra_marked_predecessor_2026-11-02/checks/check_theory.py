#!/usr/bin/env python3
"""Reproducible finite checks for the marked-predecessor presentation of PRA.

Run with Python 3.10 or later; no third-party packages are needed:
    python3 checks/check_theory.py

This checks literal formula-tree counts, finite Boolean compilation, and the
explicit boundary-witness algorithm on finite trajectories. It is not a proof
of the infinite axiom schema or of the bi-interpretation theorem.

Every function occurrence charges its frozen descriptor again in full size.
Descriptors are never substituted when active arguments are substituted.
The comparison formulas are transcribed from the seven identified source
sections in SOURCE_FILES, belonging to the six inspected GitHub archives.
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Mapping


@dataclass(frozen=True)
class Node:
    kind: str
    name: str = ""
    children: tuple[Node, ...] = ()
    descriptor: Node | None = None


def var(name: str) -> Node:
    return Node("var", name)


ZERO = Node("const", "0")
FALSE = Node("false")


def app(name: str, *args: Node, descriptor: Node | None = None) -> Node:
    return Node("app", name, tuple(args), descriptor)


def succ(t: Node) -> Node:
    return app("S", t)


ONE = succ(ZERO)


def chi(t: Node, u: Node) -> Node:
    return app("chi", t, u)


def q(t: Node, u: Node) -> Node:
    return app("Q", t, u, descriptor=var("w"))


def z(t: Node, u: Node) -> Node:
    return app("Z", t, u, descriptor=ZERO)


def rec(h: Node, t: Node, u: Node) -> Node:
    return app("R", t, u, descriptor=h)


def comp(h: Node, t: Node, u: Node) -> Node:
    return app("C", t, u, descriptor=h)


def eq(t: Node, u: Node) -> Node:
    return Node("eq", children=(t, u))


def logical(kind: str, p: Node, r: Node) -> Node:
    assert kind in {"and", "or", "imp"}
    return Node(kind, children=(p, r))


def forall(names: tuple[str, ...], body: Node) -> Node:
    for name in reversed(names):
        body = Node("all", name, (body,))
    return body


def exists(name: str, body: Node) -> Node:
    return Node("ex", name, (body,))


def witness_closure(body: Node) -> Node:
    return forall(("a", "n"), exists("b", body))


@lru_cache(maxsize=None)
def active_size(t: Node) -> int:
    return 1 + sum(active_size(c) for c in t.children)


@lru_cache(maxsize=None)
def full_size(t: Node) -> int:
    return (
        1
        + sum(full_size(c) for c in t.children)
        + (full_size(t.descriptor) if t.descriptor is not None else 0)
    )


def counts(t: Node) -> dict[str, int]:
    return {"active": active_size(t), "full": full_size(t)}


def subst(t: Node, replacements: Mapping[str, Node]) -> Node:
    """Simultaneous numerical-term substitution; descriptors stay frozen.

    There are no binders in the active numerical terms accepted here. This is
    intentionally not a general formula-substitution or alpha-renaming tool.
    """
    if t.kind not in {"var", "const", "app"}:
        raise ValueError("Active substitution here accepts numerical terms only")
    if t.kind == "var":
        return replacements.get(t.name, t)
    return Node(
        t.kind,
        t.name,
        tuple(subst(c, replacements) for c in t.children),
        t.descriptor,
    )


def occurrences(t: Node, name: str) -> int:
    return int(t.kind == "var" and t.name == name) + sum(
        occurrences(c, name) for c in t.children
    )


def display(t: Node) -> str:
    if t.kind in {"var", "const"}:
        return t.name
    if t.kind == "false":
        return "false"
    if t.kind == "app":
        label = t.name
        if t.name in {"R", "C"}:
            label += "[" + display(t.descriptor) + "]"
        return label + "(" + ",".join(map(display, t.children)) + ")"
    if t.kind in {"all", "ex"}:
        return ("forall " if t.kind == "all" else "exists ") + t.name + ". " + display(t.children[0])
    op = {"eq": "=", "and": "and", "or": "or", "imp": "->"}[t.kind]
    return "(" + display(t.children[0]) + " " + op + " " + display(t.children[1]) + ")"


def is_boolean_term(t: Node) -> bool:
    if t in {ZERO, ONE}:
        return True
    if t.kind == "app" and t.name == "chi":
        return True
    return (
        t.kind == "app"
        and t.name == "Q"
        and all(is_boolean_term(c) for c in t.children)
    )


@lru_cache(maxsize=None)
def compile_boolean(p: Node) -> Node:
    if p.kind == "false":
        return ZERO
    if p.kind == "eq":
        return chi(*p.children)
    a, b = map(compile_boolean, p.children)
    if p.kind == "and":
        return q(q(a, ONE), b)
    if p.kind == "or":
        return q(q(a, q(b, ONE)), ONE)
    if p.kind == "imp":
        return q(q(b, a), ONE)
    raise ValueError(f"Not a quantifier-free formula: {p.kind}")


def eval_term(t: Node, env: Mapping[str, int]) -> int:
    if t.kind == "var":
        return env[t.name]
    if t == ZERO:
        return 0
    if t.kind != "app":
        raise ValueError("Not an evaluable numerical term")
    args = [eval_term(c, env) for c in t.children]
    if t.name == "S":
        return args[0] + 1
    if t.name == "chi":
        return int(args[0] == args[1])
    if t.name == "Q":
        return args[1] if args[0] == 0 else args[0] - 1
    if t.name == "Z":
        return args[1] if args[0] == 0 else 0
    if t.name == "C":
        return eval_term(t.descriptor, {"x": args[0], "a": args[1]})
    raise ValueError("General recursors are counted, not evaluated by this checker")


def eval_formula(p: Node, env: Mapping[str, int]) -> bool:
    if p.kind == "false":
        return False
    if p.kind == "eq":
        return eval_term(p.children[0], env) == eval_term(p.children[1], env)
    a, b = (eval_formula(c, env) for c in p.children)
    if p.kind == "and":
        return a and b
    if p.kind == "or":
        return a or b
    if p.kind == "imp":
        return (not a) or b
    raise ValueError("Only quantifier-free formulas are evaluated")


def marker_formulas(boolean: Node) -> tuple[Node, Node, Node]:
    """boolean uses active x,a; the entire h=Q(boolean,x) is stored."""
    assert is_boolean_term(boolean)
    h = q(boolean, var("x"))
    a, n, b = map(var, ("a", "n", "b"))
    definition = forall(
        ("a", "n"),
        eq(comp(h, n, a), subst(h, {"x": n})),
    )
    witness = witness_closure(
        eq(comp(h, q(comp(h, succ(b), a), n), a), ZERO)
    )
    return h, definition, witness


def verify_sizing() -> dict:
    x, a = var("x"), var("a")
    examples = [
        ZERO,
        ONE,
        chi(x, a),
        q(chi(x, a), ONE),
        compile_boolean(logical("imp", eq(x, a), eq(succ(x), a))),
        # Frozen recursion descriptors deliberately exceed the active size.
        chi(rec(succ(succ(var("v"))), x, a), ZERO),
    ]
    rows = []
    for boolean in examples:
        h, definition, witness = marker_formulas(boolean)
        m, w = active_size(boolean), full_size(boolean)
        v = full_size(h)
        assert active_size(h) == m + 2
        assert v == w + 3
        assert counts(definition) == {"active": 8 + m, "full": 12 + 2 * w}
        assert counts(witness) == {"active": 13, "full": 14 + 2 * v}
        assert full_size(witness) == 20 + 2 * w
        assert active_size(definition) + active_size(witness) == 21 + m
        assert full_size(definition) + full_size(witness) == 32 + 4 * w
        rows.append({
            "boolean": display(boolean), "boolean_counts": counts(boolean),
            "stored_body": display(h), "stored_body_counts": counts(h),
            "definition": counts(definition), "witness": counts(witness),
            "unit": {"active": 21 + m, "full": 32 + 4 * w},
        })

    # Distinguish active substitution from substitution into a function name.
    descriptor = q(var("x"), var("a"))
    original = rec(descriptor, x, a)
    changed = subst(original, {"x": succ(x), "a": ZERO})
    assert changed.descriptor is descriptor
    assert changed.children == (succ(x), ZERO)
    assert active_size(changed) == active_size(original) + 1
    assert full_size(changed) == full_size(original) + 1
    doubled = chi(original, original)
    assert full_size(doubled) == active_size(doubled) + 2 * full_size(descriptor)

    # Literal fixed-seed and computation templates, with no alias normalization.
    n, b = var("n"), var("b")
    separation = logical("imp", eq(ZERO, ONE), FALSE)
    bit = logical("and", eq(chi(a, a), ONE), logical("or", eq(a, n), eq(chi(a, n), ZERO)))
    seed = forall(("a", "n"), logical("and", separation, bit))
    bit_sentence = forall(("a", "n"), bit)
    assert counts(seed) == {"active": 25, "full": 25}
    assert counts(separation) == {"active": 6, "full": 6}
    assert counts(bit_sentence) == {"active": 18, "full": 18}
    h = chi(var("v"), var("w"))
    base = forall(("a",), eq(rec(h, ZERO, a), a))
    step = forall(("a", "n", "b"), logical("imp", eq(rec(h, n, a), b), eq(rec(h, succ(n), a), subst(h, {"v": b, "w": n}))))
    assert counts(base) == {"active": 6, "full": 6 + full_size(h)}
    assert counts(step) == {"active": 14 + active_size(h), "full": 14 + 3 * full_size(h)}
    return {"examples": rows, "fixed_seed": {"primary_split": {"separation": counts(separation), "bit": counts(bit_sentence), "total": {"active": 24, "full": 24}}, "combined_variant": counts(seed)}, "descriptor_substitution": "passed", "recursion_templates": {"base": counts(base), "bound_state_step": counts(step)}}


def verify_boolean_compiler() -> dict:
    atoms = {FALSE, eq(var("x"), var("a")), eq(succ(var("x")), var("a"))}
    formulas = set(atoms)
    for _ in range(2):
        old = tuple(formulas)
        formulas |= {
            logical(op, left, right)
            for op in ("and", "or", "imp")
            for left in old for right in old
        }
    checks = 0
    marker_checks = 0
    for formula in formulas:
        boolean = compile_boolean(formula)
        assert is_boolean_term(boolean)
        h, _, _ = marker_formulas(boolean)
        for x, a in itertools.product(range(5), repeat=2):
            env = {"x": x, "a": a}
            b = eval_term(boolean, env)
            truth = eval_formula(formula, env)
            assert b in (0, 1)
            assert b == int(truth)
            checks += 1
            value = eval_term(h, env)
            assert value in (0, x)
            assert (value == 0) == (x == 0 or truth)
            marker_checks += 1
    return {"formula_depth_bound": 2, "formulas": len(formulas), "environments_per_formula": 25, "compiler_evaluations": checks, "marker_evaluations": marker_checks, "status": "passed"}


def verify_boundary_scan(max_index: int = 12) -> dict:
    trajectories = 0
    targets = 0
    zero_branch = 0
    predecessor_branch = 0
    for pattern in itertools.product((False, True), repeat=max_index):
        # Each nonzero index independently has marker value0 or its own index.
        values = [0] + [0 if good else i for i, good in enumerate(pattern, 1)]
        c = 0
        for n in range(max_index + 1):
            assert values[c] == 0
            assert values[n] == 0 or values[c + 1] != 0
            b = c
            inner = values[b + 1]
            selected = n if inner == 0 else inner - 1
            assert selected == (n if inner == 0 else b)
            assert values[selected] == 0
            if inner == 0:
                zero_branch += 1
            else:
                predecessor_branch += 1
            targets += 1
            if n < max_index:
                c = n if values[n] == 0 else c
        trajectories += 1
    return {"max_index": max_index, "trajectories": trajectories, "targets": targets, "zero_selector_branch": zero_branch, "predecessor_selector_branch": predecessor_branch, "status": "passed", "scope": "Finite exhaustive checks of the explicit scan and invariant; not a proof of the infinite schema."}


SOURCE_FILES = [
    {"archive": "pra_absorbing_return_2026-11-02.zip", "file": "02_absorbing_kernel.tex", "sha256": "d052c49bcee7ae8dfde5676c662aa7ffabf99d21b681a4def8220707a0801593"},
    {"archive": "pra_coverage_boundary_2026-11-02.zip", "file": "sections/induction.tex", "sha256": "da99ff0ed12871d90de88e9a6e5a936e8852511933e874d5e813c6dd1c33bf7d"},
    {"archive": "pra_exit_witness_2026-11-02.zip", "file": "sections/03_induction.tex", "sha256": "2a7ee0f2ef8f5a15a5b393f8ed661c0ef21fae1d3245df8e75626c7d88d2b9f8"},
    {"archive": "pra_predecessor_return_2026-11-02.zip", "file": "AXIOMS.txt", "sha256": "7619eb47ae94a6c138d209d2ec13409cbef3c8f8c32d263b6c4f1423bd63a00d"},
    {"archive": "pra_predecessor_witness_2026-11-02.zip", "file": "sections/core.tex", "sha256": "05bdf52f1d0ecd5b2d767ad5937539371ff2590e1986a5a0f13c1d4935e1d291"},
    {"archive": "pra_separated_recursion_2026-11-02.zip", "file": "sections/03_induction.tex", "sha256": "841261d5cbf4a3399fe2baabc444ed21eb30b13896f454ac2a5ad9a24e947332"},
    {"archive": "pra_separated_recursion_2026-11-02.zip", "file": "sections/07_one_transition.tex", "sha256": "28c73825bf2bf6ee1f0da75a1550e1f739351290057d370cfe9ef666d4befc61"},
]


def comparison_example() -> dict:
    """Actual compiler bodies for P(n,a) := n=a, not arbitrary matched sizes."""
    v, w, a, n, b = map(var, ("v", "w", "a", "n", "b"))
    pv = q(v, ZERO)
    zero_bit = z(chi(w, pv), ONE)
    shifted_zero_bit = z(chi(succ(w), pv), ONE)
    rows = []

    def add(label: str, h: Node, formula: Node, *, note: str = "") -> None:
        row = {"presentation": label, "body": display(h), "body_counts": counts(h), "formula": display(formula), "witness": counts(formula), "note": note}
        if label != "marked_predecessor":
            base = forall(("a",), eq(rec(h, ZERO, a), a))
            direct = forall(("a", "n"), eq(rec(h, succ(n), a), subst(h, {"v": rec(h, n, a), "w": n})))
            c = var("c")
            bound = forall(("a", "n", "c"), logical("imp", eq(rec(h, n, a), c), eq(rec(h, succ(n), a), subst(h, {"v": c, "w": n}))))
            costs = {"base": counts(base), "direct_step": counts(direct), "bound_step": counts(bound)}
            for step_name in ("direct_step", "bound_step"):
                costs["unit_with_" + step_name] = {
                    measure: costs["base"][measure] + costs[step_name][measure] + counts(formula)[measure]
                    for measure in ("active", "full")
                }
            costs["coordinatewise_unit_envelope"] = {
                measure: min(costs["unit_with_direct_step"][measure], costs["unit_with_bound_step"][measure])
                for measure in ("active", "full")
            }
            winner = min(("direct_step", "bound_step"), key=lambda name: (costs[name]["full"], costs[name]["active"]))
            costs["minimum_full_concrete_unit"] = {"step_form": winner, **costs["unit_with_" + winner]}
            costs["scope"] = "One canonical recursor base plus one actual step form plus this witness. This readable-unit comparison is not an exact raw-alias emitter output comparison. The coordinatewise envelope need not be realized by a single step form."
            row["computation_plus_witness"] = costs
        rows.append(row)

    # Absorbing return: tail b_P(w,p(v)), regularized absorbing update.
    d = z(chi(v, ZERO), z(zero_bit, succ(pv)))
    h = q(z(chi(w, ZERO), succ(d)), v)
    r = lambda x: rec(h, x, a)
    f = witness_closure(eq(r(succ(q(z(r(succ(succ(b))), succ(b)), n))), a))
    assert counts(f) == {"active": 18, "full": 20 + 2 * full_size(h)}
    add("absorbing_return", h, f)

    # Coverage boundary uses the true-on-truth tau, whose equality clause is chi.
    h = z(chi(chi(w, pv), ZERO), v)
    r = lambda x: rec(h, x, a)
    f = witness_closure(logical("and", eq(r(b), a), logical("imp", eq(r(succ(b)), a), eq(b, n))))
    assert counts(f) == {"active": 19, "full": 19 + 2 * full_size(h)}
    add("coverage_boundary", h, f)

    # Exit witness shifts the predicate to P(Sw,p(v)).
    h = z(shifted_zero_bit, v)
    r = lambda x: rec(h, x, a)
    f = witness_closure(eq(r(q(z(chi(r(b), a), b), n)), a))
    assert counts(f) == {"active": 16, "full": 18 + 2 * full_size(h)}
    add("exit_witness", h, f)

    # Predecessor return uses the unshifted P(w,p(v)).
    h = z(zero_bit, v)
    r = lambda x: rec(h, x, a)
    f = witness_closure(eq(r(q(q(chi(r(b), a), b), n)), a))
    assert counts(f) == {"active": 16, "full": 18 + 2 * full_size(h)}
    add("predecessor_return", h, f)

    # Predecessor witness uses the shifted latch and its raw14-node formula.
    h = z(shifted_zero_bit, v)
    r = lambda x: rec(h, x, a)
    f = witness_closure(eq(r(q(z(r(b), b), n)), a))
    assert counts(f) == {"active": 14, "full": 16 + 2 * full_size(h)}
    add("predecessor_witness", h, f)

    # Separated recursion: guarded latch, plus both recorded one-call variants.
    tail = z(zero_bit, v)
    h = q(z(chi(w, ZERO), succ(tail)), v)
    r = lambda x: rec(h, x, a)
    f = witness_closure(logical("and", eq(r(succ(b)), a), logical("imp", eq(r(succ(succ(b))), a), eq(b, n))))
    assert counts(f) == {"active": 21, "full": 21 + 2 * full_size(h)}
    add("separated_recursion_primary", h, f)
    exposed = subst(tail, {"v": a, "w": succ(b)})
    selector = q(z(chi(exposed, a), succ(b)), n)
    one = witness_closure(eq(r(succ(selector)), a))
    tailored = witness_closure(logical("and", eq(r(succ(b)), a), logical("imp", eq(exposed, a), eq(b, n))))
    j = occurrences(tail, "w")
    assert counts(one) == {"active": 15 + active_size(tail) + j, "full": 8 + 2 * full_size(h) + j}
    assert counts(tailored) == {"active": 16 + active_size(tail) + j, "full": 7 + 2 * full_size(h) + j}
    add("separated_recursion_One", h, one, note="Recorded equivalent formula; its optional emitter threshold is not satisfied by this equality compiler tail.")
    add("separated_recursion_Tail", h, tailored, note="Recorded equivalent tailored boundary formula, not the primary emitter output.")

    boolean = chi(var("x"), a)
    h, definition, f = marker_formulas(boolean)
    add("marked_predecessor", h, f)
    new = rows[-1]
    new["definition"] = counts(definition)
    new["definition_formula"] = display(definition)
    new["definition_plus_witness"] = {"active": active_size(definition) + active_size(f), "full": full_size(definition) + full_size(f)}
    assert new["witness"] == {"active": 13, "full": 26}
    assert new["definition_plus_witness"] == {"active": 24, "full": 44}
    return {"predicate": "P(n,a) := n=a", "comparison_scope": "Actual finite compiler bodies and their witness formulas. This is not a comparison of complete axiom emitters, generator byte lengths, or all possible encodings.", "sources": SOURCE_FILES, "rows": rows}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("results.json"))
    args = parser.parse_args()
    result = {
        "status": "passed",
        "comparison_snapshot": "VladimirReshetnikov/ProveIt@41ead086f47172a707910a072eb1a722a17a85ca",
        "scope": "Executable finite checks supplement, and do not replace, the written mathematical proofs.",
        "sizing": verify_sizing(),
        "boolean_compiler": verify_boolean_compiler(),
        "boundary_scan": verify_boundary_scan(),
        "equality_example": comparison_example(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "boolean_compiler": result["boolean_compiler"], "boundary_scan": result["boundary_scan"], "comparison": [{"presentation": r["presentation"], "body_counts": r["body_counts"], "witness": r["witness"]} for r in result["equality_example"]["rows"]]}, indent=2))


if __name__ == "__main__":
    main()
