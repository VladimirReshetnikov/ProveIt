#!/usr/bin/env python3
"""Finite literal-AST audit of the optional seven-case axiom emitter.

Uses the OLD R-only raw-input grammar, with Q=R_w and Z=R_0 and frozen
canonical descriptions. The new composition names never occur in raw inputs
or their stored descriptors. This separation is part of the specification.

All six inspected primary emitters are transcribed below. The recorded
separated-recursion One/Tail alternatives and Exit's optional broader selector
are also compared. Finite checks support the unbounded proof in the report;
they do not establish that proof by enumeration.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from check_theory import (
    FALSE, ONE, ZERO, Node, active_size, app, chi, comp, counts, display, eq,
    exists, forall, full_size, logical, occurrences, q, rec, subst, succ, var,
    witness_closure, z,
)


N, A, B, C = map(var, ("n", "a", "b", "c"))
V, W = var("v"), var("w")


def is_app(t: Node, name: str, arity: int = 2) -> bool:
    if t.kind != "app" or len(t.children) != arity:
        return False
    if name == "Q":
        return t.name == "Q" or (t.name == "R" and t.descriptor == W)
    if name == "Z":
        return t.name == "Z" or (t.name == "R" and t.descriptor == ZERO)
    return t.name == name


def nf(t: Node) -> Node:
    """Strip consecutive Q(Sr,s) ROOTS only, even when s is not the slot a."""
    while is_app(t, "Q") and is_app(t.children[0], "S", 1):
        t = t.children[0].children[0]
    return t


def pad(t: Node, k: int = 1) -> Node:
    for _ in range(k):
        t = q(succ(t), A)
    return t


def literal_pad_depth(t: Node) -> tuple[int, Node]:
    k = 0
    while is_app(t, "Q") and t.children[1] == A and is_app(t.children[0], "S", 1):
        k += 1
        t = t.children[0].children[0]
    return k, t


def descriptor(h: Node) -> Node:
    return subst(h, {"n": V, "a": W})


def rcall(h: Node, x: Node, a: Node) -> Node:
    return rec(descriptor(h), x, a)


def ccall(h: Node, x: Node, a: Node) -> Node:
    return comp(descriptor(h), x, a)


def is_old_term(t: Node, allowed_variables: frozenset[str] = frozenset({"n", "a"})) -> bool:
    if t.kind == "var":
        return t.name in allowed_variables
    if t == ZERO:
        return True
    if t.kind != "app" or t.name not in {"S", "chi", "Q", "Z", "R"}:
        return False
    if not all(is_old_term(c, allowed_variables) for c in t.children):
        return False
    if t.descriptor is not None:
        return nf(t.descriptor) == t.descriptor and is_old_term(t.descriptor, frozenset({"v", "w"}))
    return True


def is_bool(t: Node) -> bool:
    if t in {ZERO, ONE}:
        return True
    if is_app(t, "chi"):
        return all(is_old_term(c) for c in t.children)
    return is_app(t, "Q") and all(is_bool(c) for c in t.children)


def marker_body(h: Node) -> bool:
    return is_app(h, "Q") and h.children[1] == N and is_bool(h.children[0])


def guard(tail: Node) -> Node:
    return q(z(chi(A, ZERO), succ(tail)), N)


def guard_tail(h: Node) -> Node | None:
    if not is_app(h, "Q") or h.children[1] != N:
        return None
    term = h.children[0]
    if not is_app(term, "Z") or term.children[0] != chi(A, ZERO):
        return None
    term = term.children[1]
    return term.children[0] if is_app(term, "S", 1) else None


def absorbing(tail: Node) -> Node:
    p = q(N, ZERO)
    d = z(chi(N, ZERO), z(tail, succ(p)))
    return guard(d)


def is_absorbing(h: Node) -> bool:
    d = guard_tail(h)
    if d is None or not is_app(d, "Z") or d.children[0] != chi(N, ZERO):
        return False
    inner = d.children[1]
    return is_app(inner, "Z") and inner.children[1] == succ(q(N, ZERO))


SEP = logical("imp", eq(ZERO, ONE), FALSE)
BIT_MATRIX = logical("and", eq(chi(A, A), ONE), logical("or", eq(A, N), eq(chi(A, N), ZERO)))
BIT = forall(("a", "n"), BIT_MATRIX)
SEED = forall(("a", "n"), logical("and", SEP, BIT_MATRIX))
FIXED_INPUT_S = pad(N)
FIXED_INPUT_G = z(chi(N, ZERO), A)
X, Y = var("x"), var("y")
PARTITION = forall(("x",), exists("y", logical("imp", eq(chi(X, ZERO), chi(X, succ(Y))), FALSE)))
COV_PW = forall(("x",), exists("y", logical("or", eq(X, ZERO), eq(X, succ(Y)))))
COV_BODY = logical("or", eq(N, ZERO), eq(N, succ(q(N, ZERO))))
COVER_CB = logical("and", SEP, forall(("n",), COV_BODY))
COVER_EXIT = forall(("n",), logical("and", SEP, COV_BODY))


def base(h: Node) -> Node:
    return forall(("a",), eq(rcall(h, ZERO, A), A))


def canonical_step(h: Node) -> Node:
    return forall(("a", "n", "c"), logical("imp", eq(rcall(h, N, A), C), eq(rcall(h, succ(N), A), subst(h, {"n": C, "a": N}))))


def old_computation(u: Node, which: str) -> Node:
    h = nf(u)
    b = eq(rcall(h, ZERO, A), A)
    if which == "B":
        step = eq(rcall(h, succ(N), A), subst(u, {"n": rcall(h, N, A), "a": N}))
    elif which == "D":
        step = eq(rcall(h, succ(N), A), rcall(h, N, subst(u, {"n": A, "a": ZERO})))
    elif which == "E":
        step = forall(("c",), logical("imp", eq(rcall(h, N, A), C), eq(rcall(h, succ(N), A), subst(u, {"n": C, "a": N}))))
    else:
        raise ValueError(which)
    return forall(("a", "n"), logical("and", b, step))


def computation_choice(u: Node) -> str:
    i, j = occurrences(u, "n"), occurrences(u, "a")
    return "D" if i > 0 and j == 0 else "E" if i >= 4 else "B"


def boundary(h: Node, shifted: bool) -> Node:
    first = succ(B) if shifted else B
    second = succ(first)
    return witness_closure(logical("and", eq(rcall(h, first, A), A), logical("imp", eq(rcall(h, second, A), A), eq(B, N))))


def exit_witness(h: Node, raw: bool = False) -> Node:
    value = rcall(h, B, A)
    tested = value if raw else chi(value, A)
    return witness_closure(eq(rcall(h, q(z(tested, B), N), A), A))


def predecessor_return(h: Node) -> Node:
    selected = q(q(chi(rcall(h, B, A), A), B), N)
    return witness_closure(eq(rcall(h, selected, A), A))


def absorbing_witness(h: Node) -> Node:
    value = rcall(h, succ(succ(B)), A)
    selected = q(z(value, succ(B)), N)
    return witness_closure(eq(rcall(h, succ(selected), A), A))


def one_or_tail(h: Node, tail: Node, which: str) -> Node:
    exposed = subst(tail, {"n": A, "a": succ(B)})
    if which == "One":
        selected = q(z(chi(exposed, A), succ(B)), N)
        return witness_closure(eq(rcall(h, succ(selected), A), A))
    return witness_closure(logical("and", eq(rcall(h, succ(B), A), A), logical("imp", eq(exposed, A), eq(B, N))))


def emit_absorbing(u: Node) -> tuple[str, Node]:
    if u == pad(N, 4):
        return "seed", SEED
    if u == nf(u):
        return "base", base(u)
    depth, core = literal_pad_depth(u)
    if depth == 1 and is_absorbing(core):
        return "absorbing", absorbing_witness(core)
    return "step", canonical_step(nf(u))


def emit_separated(u: Node, variant: str = "primary") -> tuple[str, Node]:
    if u == pad(N, 4):
        return "seed", SEED
    depth, core = literal_pad_depth(u)
    tail = guard_tail(core) if depth == 1 else None
    if tail is not None:
        if variant == "One" or (variant == "conditional_One" and active_size(tail) + occurrences(tail, "a") <= 5):
            return "one", one_or_tail(core, tail, "One")
        if variant == "Tail":
            return "tail", one_or_tail(core, tail, "Tail")
        return "boundary", boundary(core, True)
    if u == nf(u):
        return "base", base(u)
    return "step", canonical_step(nf(u))


def emit_coverage(u: Node) -> tuple[str, Node]:
    if u == FIXED_INPUT_S:
        return "bit", BIT
    if u == FIXED_INPUT_G:
        return "cover", COVER_CB
    which = computation_choice(u)
    formula = old_computation(u, which)
    if u == nf(u) and active_size(formula) >= 19:
        return "boundary", boundary(u, False)
    return which, formula


def emit_exit(u: Node, broader: bool = False) -> tuple[str, Node]:
    if u == FIXED_INPUT_S:
        return "bit", BIT
    if u == FIXED_INPUT_G:
        return "cover", COVER_EXIT
    i = occurrences(u, "n")
    selected = i > 0 and u != N
    if broader:
        selected = selected or (i == 0 and active_size(u) >= 3 and full_size(u) >= 5)
    if u == nf(u) and selected:
        return "exit", exit_witness(u)
    which = computation_choice(u)
    return which, old_computation(u, which)


def emit_predecessor_return(u: Node) -> tuple[str, Node]:
    if u == FIXED_INPUT_S:
        return "bit", BIT
    if u == FIXED_INPUT_G:
        return "partition", PARTITION
    if u == nf(u) and occurrences(u, "n") > 0 and u != N:
        return "return", predecessor_return(u)
    which = computation_choice(u)
    return which, old_computation(u, which)


def emit_predecessor_witness(u: Node) -> tuple[str, Node]:
    if u == ZERO:
        return "coverage", COV_PW
    if u == FIXED_INPUT_S:
        return "separation", SEP
    if u == FIXED_INPUT_G:
        return "bit", BIT
    if is_app(u, "Z") and u.children[1] == N:
        return "raw", exit_witness(nf(u), True)
    if u == nf(u) and occurrences(u, "n") > 0 and u != N:
        return "generic", exit_witness(u)
    which = computation_choice(u)
    return which, old_computation(u, which)


def emit_new(u: Node) -> tuple[str, Node]:
    if u == pad(ZERO, 4):
        return "separation", SEP
    if u == pad(N, 4):
        return "bit", BIT
    depth, h = literal_pad_depth(u)
    if h == nf(h):
        if depth == 2:
            return "base", base(h)
        if depth == 3:
            definition = forall(("a", "n"), eq(ccall(h, N, A), h))
            return "composition", definition
        if depth == 5:
            step = forall(("a", "n"), eq(rcall(h, succ(N), A), ccall(h, rcall(h, N, A), N)))
            return "factored_step", step
        if depth == 6 and marker_body(h):
            f = witness_closure(eq(ccall(h, q(ccall(h, succ(B), A), N), A), ZERO))
            return "marker", f
    return "tautology", eq(ZERO, ZERO)


EMITTERS = {
    "absorbing_return": emit_absorbing,
    "coverage_boundary": emit_coverage,
    "exit_witness": emit_exit,
    "predecessor_return": emit_predecessor_return,
    "predecessor_witness": emit_predecessor_witness,
    "separated_recursion": emit_separated,
    "separated_conditional_One": lambda u: emit_separated(u, "conditional_One"),
    "separated_One_everywhere": lambda u: emit_separated(u, "One"),
    "separated_Tail_everywhere": lambda u: emit_separated(u, "Tail"),
    "exit_broader_selector": lambda u: emit_exit(u, True),
}


def make_corpus() -> tuple[list[Node], int]:
    atoms = (N, A, ZERO, ONE)
    seed = set(atoms) | {succ(N), succ(A), FIXED_INPUT_G}
    for fn in (q, z, chi):
        seed.update(fn(left, right) for left in atoms for right in atoms)
    descriptors = [V, W, ZERO, succ(V), succ(succ(V)), chi(V, W), q(V, W)]
    for h in descriptors:
        if h in {W, ZERO}:
            continue  # Q and Z already have their designated spellings.
        seed.update(rec(h, left, right) for left in atoms for right in atoms)
    seed |= {
        chi(chi(N, N), chi(N, N)),
        z(chi(chi(N, N), chi(N, N)), A),
        q(succ(N), ZERO),  # root-normalizable but not a literal Pad root.
        q(succ(q(succ(N), ZERO)), A),
    }
    tails = [N, A, ZERO, ONE, chi(N, A), rec(succ(V), N, A), z(chi(A, q(N, ZERO)), N)]
    for tail in tails:
        seed.add(guard(tail))
        seed.add(absorbing(tail))
        seed.add(z(tail, N))
    booleans = [ZERO, ONE, chi(N, A), q(chi(N, A), ONE), q(q(chi(N, A), ONE), chi(succ(N), A))]
    seed.update(q(boolean, N) for boolean in booleans)
    canonical = {nf(t) for t in seed}
    inputs = set(seed)
    for h in canonical:
        inputs.update(pad(h, depth) for depth in range(9))
    for h in sorted(canonical, key=display)[:30]:
        inputs.add(q(succ(h), ZERO))
        inputs.add(pad(q(succ(h), ZERO), 3))
    assert all(is_old_term(u) for u in inputs)
    return sorted(inputs, key=lambda u: (active_size(u), full_size(u), display(u))), len(canonical)


def verify_template_counts() -> dict:
    assert counts(SEP) == {"active": 6, "full": 6}
    assert counts(BIT) == {"active": 18, "full": 18}
    assert counts(SEED) == {"active": 25, "full": 25}
    assert counts(PARTITION) == {"active": 12, "full": 12}
    assert counts(COV_PW) == {"active": 10, "full": 10}
    assert counts(COVER_CB) == counts(COVER_EXIT) == {"active": 18, "full": 19}
    h = chi(N, A)
    mu, v = active_size(h), full_size(h)
    expected = {
        2: ("base", {"active": 6, "full": 6 + v}),
        3: ("composition", {"active": 6 + mu, "full": 6 + 2 * v}),
        5: ("factored_step", {"active": 12, "full": 12 + 3 * v}),
    }
    for depth, (expected_branch, expected_count) in expected.items():
        branch, formula = emit_new(pad(h, depth))
        assert branch == expected_branch
        assert counts(formula) == expected_count
    h = q(chi(N, A), N)
    branch, f = emit_new(pad(h, 6))
    assert branch == "marker"
    assert counts(f) == {"active": 13, "full": 14 + 2 * full_size(h)}
    # Literal B=1 is deliberately normalized to0 and is not a canonical marker.
    assert nf(q(ONE, N)) == ZERO
    assert emit_new(pad(q(ONE, N), 6))[0] == "tautology"
    return {"status": "passed", "literal_one_marker": "normalizes to0; its witness follows from the C_0 definition rather than the depth6 branch"}


def run() -> dict:
    template_result = verify_template_counts()
    inputs, canonical_count = make_corpus()
    branches = Counter()
    old_branches = {name: Counter() for name in EMITTERS}
    margins = {name: {"active": 10**9, "full": 10**9} for name in EMITTERS}
    envelope_margin = {"active": 10**9, "full": 10**9}
    examples = {}
    depth_checks = 0
    for u in inputs:
        branch, formula = emit_new(u)
        new = counts(formula)
        branches[branch] += 1
        old_counts = {}
        for name, emitter in EMITTERS.items():
            old_branch, old_formula = emitter(u)
            old = counts(old_formula)
            old_branches[name][old_branch] += 1
            old_counts[name] = old
            assert new["active"] < old["active"], (name, display(u), new, old)
            assert new["full"] < old["full"], (name, display(u), new, old)
            for measure in ("active", "full"):
                margins[name][measure] = min(margins[name][measure], old[measure] - new[measure])
        envelope = {measure: min(old[measure] for old in old_counts.values()) for measure in ("active", "full")}
        for measure in envelope:
            envelope_margin[measure] = min(envelope_margin[measure], envelope[measure] - new[measure])
        if branch not in examples:
            examples[branch] = {"input": display(u), "formula": display(formula), "new": new, "old_coordinatewise_envelope": envelope, "old": old_counts}
        depth, h = literal_pad_depth(u)
        if depth in {2, 3, 5, 6} and h == nf(h):
            expected = {"active": 14 + active_size(h), "full": 14 + 3 * full_size(h)}
            assert envelope == expected, (display(u), envelope, expected)
            depth_checks += 1
        if u == pad(N, 4):
            assert envelope == {"active": 25, "full": 25}
        if u == pad(ZERO, 4):
            assert envelope == {"active": 15, "full": 17}
    assert set(branches) == {"separation", "bit", "base", "composition", "factored_step", "marker", "tautology"}
    for name, counts_by_branch in old_branches.items():
        assert counts_by_branch, name
    required_branches = {
        "absorbing_return": {"seed", "base", "absorbing", "step"},
        "coverage_boundary": {"bit", "cover", "boundary", "B", "D", "E"},
        "exit_witness": {"bit", "cover", "exit", "B", "D", "E"},
        "predecessor_return": {"bit", "partition", "return", "B", "D", "E"},
        "predecessor_witness": {"coverage", "separation", "bit", "raw", "generic", "B", "D", "E"},
        "separated_recursion": {"seed", "base", "boundary", "step"},
    }
    for name, required in required_branches.items():
        assert set(old_branches[name]) == required, (name, old_branches[name])
    return {
        "status": "passed",
        "comparison_snapshot": "VladimirReshetnikov/ProveIt@41ead086f47172a707910a072eb1a722a17a85ca",
        "scope": "Finite AST audit only. Strict inequalities for all legal raw inputs require the unbounded case proof in the report.",
        "input_grammar": "Old R-only raw grammar; no C names in inputs or frozen input descriptions. NF strips consecutive Q(Sr,s) roots only.",
        "sample_generation": {"canonical_bodies": canonical_count, "pad_depths": list(range(9)), "raw_inputs": len(inputs), "construction": "All unary/binary applications over four seed atoms for selected old symbols, additional nested descriptors and special branch patterns, all pads0..8 of their canonical roots, and non-Pad root-normalization examples."},
        "template_checks": template_result,
        "new_branch_counts": dict(branches),
        "old_branch_counts": {name: dict(c) for name, c in old_branches.items()},
        "minimum_strict_savings_by_comparator": margins,
        "minimum_strict_savings_over_coordinatewise_envelope": envelope_margin,
        "exact_step_envelope_cases_checked": depth_checks,
        "examples": examples,
        "overhead": "This optional scheduling proof does not make generator branches, alias descriptions, or the new composition-name family free. It is a strict per-emitted-formula comparison on a fixed raw-input grammar, not a global minimality theorem.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("optional_results.json"))
    args = parser.parse_args()
    results = run()
    args.output.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({k: results[k] for k in ("status", "sample_generation", "new_branch_counts", "old_branch_counts", "minimum_strict_savings_over_coordinatewise_envelope", "exact_step_envelope_cases_checked")}, indent=2))


if __name__ == "__main__":
    main()
