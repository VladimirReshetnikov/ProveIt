A SMALLER FIRST-ORDER AXIOMATIZATION OF iPRA
Direct parameters and constructive identity round trips
2 November 2026

READ FIRST
  ipra_direct_parameters.pdf -- complete research report and proofs
  AXIOMS.txt                -- concise exact theory specification

MAIN RESULTS
  T0: initial symbols 0,S; two fixed arithmetic sentences.
      Bare fixed record 31 including paid K4; explicit ordinary-Q
      constructor bootstrap 47. The Q computation module is not free.
  Tp: initial symbols 0,S,p; three fixed arithmetic sentences.
      Complete fixed constructor record 41 including paid K4.
  TpC: add paid native case C; fixed record 58.
  Current smallest retained paired record: 74 in the same K4 ledger.

  The change is to explicitly parameterized finite-arity recursors and
  a boundary schema with a separate target and finite parameters.
  Both whole-carrier interpretation composites are proved internally
  equal to the identity. Genuine falsity and full intuitionistic
  first-order formulas, including quantified formulas, are preserved.

  The derived normalization A(n,0)=n, where A=R_[S(v)], eliminates
  an unbounded family of descriptions left by the specified current
  normalizers. Its finite proof dependencies are explicitly charged.

COMPARISON LIMITS
  These numbers are fixed support records, not sizes of the infinite
  theories. All actual parameter arguments and descriptor copies count.
  The report does not claim absolute minimality or nonincreasing size
  for every formula or proof across all primitive signatures.

CONTENTS
  ipra_direct_parameters.tex -- main LaTeX source
  sections_optimization.tex  -- canonicalization and complete modules
  sections_comparison.tex    -- interfaces, comparison, verification, refs
  artifacts/                -- standalone Python verifiers and JSON results
  provenance/               -- source inventory, hashes, and audit decisions
  build.py                  -- run checks and compile the PDF
  SHA256SUMS.txt            -- checksums of the delivered files

REBUILD
  python3 build.py
  Requires Python 3.10+ and pdflatex with the packages in the preamble.
  Verification uses only the Python standard library.

STATUS
  Written mathematical proof, with independently checked finite ledgers
  and exhaustive bounded scan diagnostics. Not a complete Lean/Rocq
  formalization, and no universal shortestness theorem is claimed.

SOURCE SNAPSHOT
  VladimirReshetnikov/ProveIt
  d171b68f822c40d6e7884d4911ac4b03edd0048c
  Five current archives and four archived predecessors reviewed.
