#!/usr/bin/env python3
"""Rebuild the report and rerun its finite verification artifacts."""
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    root = Path(__file__).resolve().parent
    for name in ("verify_presentation.py", "verify_cores_and_normalization.py"):
        subprocess.run([sys.executable, str(root / "artifacts" / name)],
                       cwd=root, check=True)
    latex = shutil.which("pdflatex")
    if latex is None:
        raise SystemExit("pdflatex is required to rebuild the PDF; finite checks passed.")
    for _ in range(3):
        result = subprocess.run(
            [latex, "-interaction=nonstopmode", "-halt-on-error",
             "ipra_direct_parameters.tex"], cwd=root, text=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        )
        if result.returncode:
            print(result.stdout)
            raise SystemExit(result.returncode)
    print("Built", root / "ipra_direct_parameters.pdf")
    print("Archive SHA256SUMS records the delivered files; regenerate it after edits.")


if __name__ == "__main__":
    main()
