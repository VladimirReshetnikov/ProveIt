#!/usr/bin/env python3
"""Finite diagnostics for the direct-parameter iPRA presentation.

Run with Python 3.10+ and no third-party dependencies:
    python3 artifacts/verify_presentation.py

This independently builds actual syntax trees, charges frozen descriptors
at every recursor occurrence, checks the reported formula sizes, and tests
the bounded-scan boundary witness for every Boolean predicate through a
chosen finite endpoint. These checks are not a proof of the infinite
axiomatization, its interpretations, or its claimed minimality.

The grouped ordinary module uses one shared parameter/initial-value prefix:
  forall a,c. (R(0,a,c)=a AND forall n. R(Sn,a,c)=h(R(n,a,c),n,c)).
Two separately closed sentences would cost m additional quantifier nodes.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import itertools
import json
from pathlib import Path
import random
import sys
from typing import Optional


@dataclass(frozen=True)
class Term:
    kind: str
    name: str = ""
    args: tuple["Term", ...] = ()
    descriptor: Optional["Term"] = None

    def size(self) -> int:
        charge = self.descriptor.size() if self.descriptor is not None else 0
        return 1 + charge + sum(child.size() for child in self.args)


@dataclass(frozen=True)
class Formula:
    kind: str
    children: tuple = ()
    binder: str = ""

    def size(self) -> int:
        # A binder's name is an annotation, not another syntax-tree node.
        return 1 + sum(child.size() for child in self.children)


def var(name: str) -> Term:
    return Term("var", name)


ZERO = Term("constant", "0")
BOTTOM = Formula("bottom")


def app(name: str, *args: Term) -> Term:
    return Term("application", name, tuple(args))


def succ(t: Term) -> Term:
    return app("S", t)


def pred(t: Term) -> Term:
    return app("p", t)


def case(n: Term, a: Term, b: Term) -> Term:
    return app("C", n, a, b)


def rec(h: Term, n: Term, a: Term, *parameters: Term) -> Term:
    return Term("recursor", "R", (n, a, *parameters), h)


def eq(left: Term, right: Term) -> Formula:
    return Formula("equality", (left, right))


def conj(left: Formula, right: Formula) -> Formula:
    return Formula("conjunction", (left, right))


def disj(left: Formula, right: Formula) -> Formula:
    return Formula("disjunction", (left, right))


def implies(left: Formula, right: Formula) -> Formula:
    return Formula("implication", (left, right))


def k3(a: Formula, b: Formula, c: Formula) -> Formula:
    return Formula("K3", (a, b, c))


def k4(a: Formula, b: Formula, c: Formula, d: Formula) -> Formula:
    return Formula("K4", (a, b, c, d))


def forall(names: tuple[str, ...], f: Formula) -> Formula:
    for name in reversed(names):
        f = Formula("forall", (f,), name)
    return f


def exists(names: tuple[str, ...], f: Formula) -> Formula:
    for name in reversed(names):
        f = Formula("exists", (f,), name)
    return f


def substitute(t: Term, mapping: dict[str, Term]) -> Term:
    """Active substitution: never traverse or change a frozen descriptor."""
    if t.kind == "var":
        return mapping.get(t.name, t)
    return Term(t.kind, t.name, tuple(substitute(a, mapping) for a in t.args),
                t.descriptor)


def guarded(t: Term, state: Term, counter: Term, successor: Term) -> Term:
    """Replace literal S(w) first, then active v,w; descriptors stay frozen."""
    if t == succ(var("w")):
        return successor
    if t == var("v"):
        return state
    if t == var("w"):
        return counter
    return Term(t.kind, t.name,
                tuple(guarded(a, state, counter, successor) for a in t.args),
                t.descriptor)


def occurrences(t: Term, name: str) -> int:
    return int(t.kind == "var" and t.name == name) + sum(
        occurrences(a, name) for a in t.args)


def guarded_count(t: Term) -> int:
    if t == succ(var("w")):
        return 1
    return sum(guarded_count(a) for a in t.args)


def frozen_charge(t: Term) -> int:
    return ((t.descriptor.size() if t.descriptor is not None else 0)
            + sum(frozen_charge(a) for a in t.args))


def frozen_descriptors(t: Term) -> tuple[Term, ...]:
    result = (t.descriptor,) if t.descriptor is not None else ()
    return result + tuple(itertools.chain.from_iterable(
        frozen_descriptors(a) for a in t.args))


def profile(h: Term, m: int) -> dict[str, int]:
    H = h.size()
    k = occurrences(h, "v")
    j = guarded_count(h)
    prepared = guarded(h, var("u"), var("n"), var("x"))
    r = occurrences(prepared, "n")
    assert prepared.size() == H - j
    assert occurrences(h, "w") == j + r
    assert guarded(h, var("u"), var("n"), succ(var("n"))) == substitute(
        h, {"v": var("u"), "w": var("n")})
    assert frozen_descriptors(prepared) == frozen_descriptors(h)
    assert all(occurrences(h, f"c{i}") > 0 for i in range(m))
    return {"H": H, "k": k, "j": j, "r": r, "m": m,
            "frozen_descriptor_charge": frozen_charge(h)}


def modules(h: Term, m: int) -> dict[str, Formula | tuple[Formula, Formula]]:
    a, n, u, x, y = map(var, ("a", "n", "u", "x", "y"))
    names = tuple(f"c{i}" for i in range(m))
    parameters = tuple(var(name) for name in names)

    def f(counter: Term, initial: Term = a) -> Term:
        return rec(h, counter, initial, *parameters)

    def body(state: Term, counter: Term) -> Term:
        return substitute(h, {"v": state, "w": counter})

    def dag(state: Term, counter: Term, successor: Term) -> Term:
        return guarded(h, state, counter, successor)

    base = eq(f(ZERO), a)
    step = eq(f(succ(n)), body(f(n), n))
    ordinary = forall(("a", *names), conj(base, forall(("n",), step)))
    separate = (forall(("a", *names), base),
                forall(("a", "n", *names), step))
    graph = forall(("a", "n", *names, "u"), implies(
        eq(f(n), u), conj(implies(eq(n, ZERO), eq(u, a)),
                         eq(f(succ(n)), body(u, n)))))
    endpoint = forall(("a", "n", *names), exists(("u",), conj(
        implies(eq(n, ZERO), eq(u, a)),
        forall(("x", "y"), k4(conj(eq(x, n), eq(y, u)),
                                  eq(f(x), y), eq(x, succ(n)),
                                  eq(y, dag(u, n, x)))))))
    folded = forall(("a", "n", *names),
                    eq(f(n), case(n, a, dag(f(pred(n)), pred(n), n))))
    bound = forall(("a", "n", *names, "u"), implies(
        eq(pred(n), u), eq(f(n), case(n, a, dag(f(u), u, n)))))
    shifted = forall(("a", "n", *names), exists(("u",),
        forall(("x", "y"), k4(conj(eq(succ(x), n), eq(y, u)),
            eq(f(x), y), eq(x, n), eq(y, case(n, a, dag(u, pred(n), n)))))))
    return {"O_grouped": ordinary, "O_separate": separate, "G0": graph,
            "T4": endpoint, "F": folded, "L": bound, "N4": shifted}


def expected_costs(p: dict[str, int]) -> dict[str, int]:
    H, k, j, r, m = (p[name] for name in ("H", "k", "j", "r", "m"))
    return {
        "O_grouped": 3 * H + 3 * m + 13 + k * (H + m + 2),
        "O_separate": 3 * H + 4 * m + 13 + k * (H + m + 2),
        "G0": 3 * H + 3 * m + 22,
        "T4": 2 * H - j + 2 * m + 32,
        "F": 2 * H - j + 2 * m + 9 + k * (H + m + 3) + r,
        "L": 2 * H - j + 2 * m + 15 + k * (H + m + 2),
        "N4": 2 * H - j + 2 * m + 27 + r,
    }


def support_checks() -> dict:
    x, a, b, n = map(var, ("x", "a", "b", "n"))
    p0 = eq(pred(ZERO), ZERO)
    separation = implies(eq(ZERO, succ(ZERO)), BOTTOM)
    cover = forall(("x",), conj(eq(pred(succ(x)), x),
        disj(eq(x, ZERO), eq(succ(pred(x)), x))))
    native_case = forall(("a", "b"), conj(eq(case(ZERO, a, b), a),
        forall(("n",), eq(case(succ(n), a, b), b))))
    A, B, C, D = (Formula("metavariable", (), name)
                  for name in ("A", "B", "C", "D"))
    k3_definition = Formula("definition", (k3(A, B, C),
        conj(implies(A, B), implies(B, C))))
    k4_definition = Formula("definition", (k4(A, B, C, D),
        conj(implies(A, B), implies(B, implies(C, D)))))
    nested_k4_definition = Formula("definition", (
        k4(A, B, C, D), k3(A, B, implies(C, D))))
    observed = {
        "p_zero": p0.size(), "separation": separation.size(),
        "predecessor_and_cover": cover.size(),
        "arithmetic_total": p0.size() + separation.size() + cover.size(),
        "native_case_support": native_case.size(),
        "K3_definition": k3_definition.size(),
        "K4_definition": k4_definition.size(),
        "joint_definition": k3_definition.size() + nested_k4_definition.size(),
    }
    expected = {"p_zero": 4, "separation": 6, "predecessor_and_cover": 16,
                "arithmetic_total": 26, "native_case_support": 17,
                "K3_definition": 12, "K4_definition": 15,
                "joint_definition": 24}
    assert observed == expected, (observed, expected)
    records = {"K3": 26 + 12, "K4": 26 + 15, "joint": 26 + 24,
               "native_case_K3": 26 + 17 + 12,
               "native_case_K4": 26 + 17 + 15,
               "native_case_joint": 26 + 17 + 24}
    assert records == {"K3": 38, "K4": 41, "joint": 50,
                       "native_case_K3": 55, "native_case_K4": 58,
                       "native_case_joint": 67}
    return {"observed": observed, "expected": expected,
            "fixed_records": records}


ADD_BODY = succ(var("v"))


def add(left: Term, right: Term) -> Term:
    # This is a genuine earlier recursor call, not an uncharged addition alias.
    return rec(ADD_BODY, left, right)


def descriptors() -> list[tuple[str, int, Term]]:
    v, w = var("v"), var("w")
    inner = add(add(v, succ(w)), var("c0"))
    base = [v, w, ZERO, succ(v), pred(v), succ(w), succ(succ(w)),
            add(v, w), add(v, succ(w)), add(v, add(v, v)),
            add(w, add(w, succ(w))), rec(inner, v, w, ZERO),
            rec(inner, succ(w), succ(v), ZERO)]
    result = []
    for m in range(5):
        for index, original in enumerate(base):
            h = original
            # Ensure that m counts exactly the parameters actually occurring.
            for i in range(m):
                h = add(h, var(f"c{i}"))
            result.append((f"structured_m{m}_{index:02d}", m, h))
    rng = random.Random(20261102)

    def random_term(depth: int, m: int) -> Term:
        atoms = [ZERO, v, w, *(var(f"c{i}") for i in range(m))]
        if depth == 0 or rng.randrange(5) == 0:
            return rng.choice(atoms)
        choice = rng.randrange(5)
        if choice == 0:
            return succ(random_term(depth - 1, m))
        if choice == 1:
            return pred(random_term(depth - 1, m))
        if choice == 2:
            return succ(w)
        if choice == 3:
            return add(random_term(depth - 1, m), random_term(depth - 1, m))
        return rec(inner, random_term(depth - 1, m),
                   random_term(depth - 1, m), random_term(depth - 1, m))

    for index in range(40):
        m = index % 5
        h = random_term(3, m)
        for i in range(m):
            if occurrences(h, f"c{i}") == 0:
                h = add(h, var(f"c{i}"))
        result.append((f"seeded_m{m}_{index:02d}", m, h))
    return result


def module_checks() -> dict:
    rows = []
    boundaries = 0
    for name, m, h in descriptors():
        p = profile(h, m)
        built = modules(h, m)
        actual = {key: (sum(f.size() for f in value)
                        if isinstance(value, tuple) else value.size())
                  for key, value in built.items()}
        expected = expected_costs(p)
        assert actual == expected, (name, p, actual, expected)
        assert actual["O_separate"] - actual["O_grouped"] == m
        # Include t in E: the endpoint binder is allowed in its middle index.
        x, t, b = var("x"), var("t"), var("b")
        names = tuple(f"c{i}" for i in range(m))
        parameters = tuple(var(c) for c in names)
        E = eq(rec(h, x, t, *parameters), succ(t))
        boundary = forall(("t", *names), exists(("b",), forall(("x",),
            k4(eq(succ(x), b), E, eq(x, b), eq(b, t)))))
        boundary_expected = E.size() + m + 14
        assert boundary.size() == boundary_expected
        expanded = forall(("t", *names), exists(("b",), forall(("x",),
            conj(implies(eq(succ(x), b), E),
                 implies(E, implies(eq(x, b), eq(b, t)))))))
        assert expanded.size() == 2 * E.size() + m + 17
        boundaries += 1
        rows.append({"name": name, "profile": p, "observed": actual,
                     "expected": expected,
                     "boundary_index_size": E.size(),
                     "boundary_size": boundary.size(),
                     "boundary_expanded_size": expanded.size()})
    # Explicit regression: frozen v,w, and S(w) do not affect active profiles.
    inner = add(add(var("v"), succ(var("w"))), var("c0"))
    outer = rec(inner, var("v"), var("w"), var("c0"))
    p = profile(outer, 1)
    assert (p["k"], p["j"], p["r"]) == (1, 0, 1)
    assert outer.size() > 1 + sum(t.size() for t in outer.args)
    return {"descriptor_cases": len(rows),
            "module_formula_equalities": 7 * len(rows),
            "guarded_substitution_equalities": len(rows),
            "boundary_cases": boundaries,
            "frozen_descriptor_regression": p,
            "cases": rows}


def bounded_scan_checks(limit: int) -> dict:
    cases = 0
    checked_implications = 0
    distributions = {}
    for target in range(limit + 1):
        cases_at_target = 0
        for bits in range(1 << (target + 1)):
            predicate = tuple(bool(bits & (1 << i)) for i in range(target + 1))
            state = 0
            for n in range(target):
                if predicate[state]:
                    state = n + 1
                assert 0 <= state <= n + 1
                assert state == n + 1 or not predicate[state]
            b = state
            # These are the two implications in the K4 boundary matrix.
            for x in range(target + 1):
                assert x + 1 != b or predicate[x]
                assert not (predicate[x] and x == b) or b == target
                checked_implications += 2
            assert b == 0 or predicate[b - 1]
            assert not predicate[b] or b == target
            cases += 1
            cases_at_target += 1
        distributions[str(target)] = cases_at_target
    assert cases == (1 << (limit + 2)) - 2
    return {"maximum_target": limit, "predicate_cases": cases,
            "pointwise_implications_checked": checked_implications,
            "cases_by_target": distributions,
            "scope": "All Boolean predicates on {0,...,t}, for each listed t; "
                     "x>t makes both tested antecedents false since b<=t."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scan-bound", type=int, default=12)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("verification_results.json"))
    args = parser.parse_args()
    if not 0 <= args.scan_bound <= 18:
        parser.error("--scan-bound must lie between 0 and 18")
    result = {
        "status": "PASS", "python": sys.version.split()[0],
        "verifier_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Finite syntax and bounded numerical diagnostics only; "
                 "not a mechanized proof of the metatheorem or a minimality theorem.",
        "counting_convention": "One node per variable, constant, application, "
            "equality, connective, falsity, or individual quantifier; every "
            "recursor occurrence additionally pays its entire frozen descriptor.",
        "description_cases": "Finite raw term bodies used to check universal "
            "template formulas; this script does not certify canonical admission "
            "or implement the infinite language generator.",
        "support": support_checks(), "modules": module_checks(),
        "bounded_scan": bounded_scan_checks(args.scan_bound),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"],
        "descriptor_cases": result["modules"]["descriptor_cases"],
        "module_formula_equalities": result["modules"]["module_formula_equalities"],
        "boundary_cases": result["modules"]["boundary_cases"],
        "bounded_predicates": result["bounded_scan"]["predicate_cases"],
        "output": str(args.output.resolve())}, indent=2))


if __name__ == "__main__":
    main()
