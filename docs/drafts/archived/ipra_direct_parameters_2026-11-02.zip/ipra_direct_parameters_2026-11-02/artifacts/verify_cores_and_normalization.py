#!/usr/bin/env python3
"""Additional exact ledgers and finite checks for the direct-parameter report.

This is not a proof assistant.  The sampled normalizer covers only the
displayed A(t,0) family, not the whole canonical language generator.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from verify_presentation import (
    BOTTOM, ZERO, Term, app, conj, disj, eq, exists, forall, implies,
    modules, rec, succ, var,
)


def family_normalize(t: Term) -> Term:
    """Apply the new A(t,0) rule to active terms; freeze all descriptors."""
    children = tuple(family_normalize(a) for a in t.args)
    result = Term(t.kind, t.name, children, t.descriptor)
    if (result.kind == "recursor" and result.descriptor == succ(var("v"))
            and len(children) == 2 and children[1] == ZERO):
        return children[0]
    return result


def old_rule_applies_to_family(t: Term) -> bool:
    """Relevant old rules: literal zero/successor counters and Q(Sr,a).

    Native pairing/p/C rules cannot match these A-only family terms.
    This recognizer is intentionally restricted to that family.
    """
    if t.kind == "recursor":
        counter = t.args[0]
        if counter == ZERO or (counter.kind == "application" and counter.name == "S"):
            return True
    return any(old_rule_applies_to_family(a) for a in t.args)


def main() -> None:
    x, y, z, w = map(var, ("x", "y", "z", "w"))
    sep = implies(eq(ZERO, succ(ZERO)), BOTTOM)
    cover = forall(("z",), exists(("y",), disj(eq(z, ZERO), eq(z, succ(y)))))
    q_ordinary = modules(w, 0)["O_grouped"]
    assert sep.size() == 6 and cover.size() == 10
    assert q_ordinary.size() == 16

    def q(a: Term, b: Term) -> Term:
        return app("q", a, b)

    qlaw = forall(("x", "y"), eq(q(q(ZERO, x), y), x))
    qsep = implies(eq(ZERO, q(ZERO, ZERO)), BOTTOM)
    qcover = forall(("z",), exists(("y",), disj(eq(z, ZERO), eq(z, q(ZERO, y)))))
    assert (qlaw.size(), qsep.size(), qcover.size()) == (9, 7, 11)
    records = {
        "T0_bare_K3": sep.size() + cover.size() + 12,
        "T0_bare_K4": sep.size() + cover.size() + 15,
        "T0_bare_joint": sep.size() + cover.size() + 24,
        "T0_ordinary_Q_constructor_bootstrap_K4": 31 + q_ordinary.size(),
        "q_interface_K4": qlaw.size() + qsep.size() + qcover.size() + 15,
        "q_positive_record_without_designation": qlaw.size() + qcover.size() + 15,
        "q_designation_record": 1 + 1 + eq(ZERO, q(ZERO, ZERO)).size(),
    }
    assert records == {
        "T0_bare_K3": 28, "T0_bare_K4": 31, "T0_bare_joint": 40,
        "T0_ordinary_Q_constructor_bootstrap_K4": 47,
        "q_interface_K4": 42, "q_positive_record_without_designation": 35,
        "q_designation_record": 7,
    }

    body = w
    samples = []
    for j in range(65):
        assert body.size() == 4 * j + 1
        assert family_normalize(body) == w
        assert not old_rule_applies_to_family(body)
        samples.append({"j": j, "charged_body_size": body.size(),
                        "canonical_body": "w", "additional_canonical_modules": 0})
        body = rec(succ(var("v")), body, ZERO)

    A_module = modules(succ(var("v")), 0)["O_grouped"]
    E_A = eq(rec(succ(var("v")), x, ZERO), x)
    assert A_module.size() == 23 and E_A.size() + 14 == 21

    # Independently execute the A recursion on bounded standard inputs.
    numerical_cases = 0
    for n in range(65):
        for initial in range(33):
            value = initial
            for _ in range(n):
                value += 1
            assert value == initial + n
            numerical_cases += 1

    result = {
        "status": "PASS",
        "scope": "Finite formula ledgers and the displayed normalization family only; "
                 "the general theorem is proved in the report, not by this script.",
        "verifier_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "records": records,
        "A_certificate_support": {"ordinary_module": 23, "boundary": 21, "total": 44},
        "normalization_family_samples": samples,
        "bounded_A_recursion_cases": numerical_cases,
    }
    output = Path(__file__).with_name("core_and_normalization_results.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "records": records,
                      "family_cases": len(samples), "output": str(output.resolve())}, indent=2))


if __name__ == "__main__":
    main()
