#!/usr/bin/env python3
"""Rebuild finite checks and the iPRA report. Python standard library only."""
from pathlib import Path
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    subprocess.run([sys.executable, str(ROOT / "artifacts/check_syntax.py")],
                   cwd=ROOT, check=True)
    engine = shutil.which("pdflatex")
    if engine is None:
        raise SystemExit("pdfLaTeX is required to compile report.tex")
    log_directory = ROOT / "artifacts/build_logs"
    log_directory.mkdir(exist_ok=True)
    for number in range(1, 4):
        result = subprocess.run(
            [engine, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            check=False)
        (log_directory / f"latex_pass_{number}.txt").write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-6000:])
            raise SystemExit(result.returncode)
    final_log = result.stdout
    bad = [line for line in final_log.splitlines()
           if "Overfull" in line or "undefined" in line
           or "duplicate ignored" in line or "Rerun" in line]
    summary = {"pdf": "report.pdf", "latex_passes": 3,
               "blocking_log_lines": bad,
               "status": "compiled; inspect rendering" if not bad else "review needed"}
    (ROOT / "artifacts/build_results.json").write_text(
        json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    if bad:
        raise SystemExit("Compilation succeeded but the log needs review")


if __name__ == "__main__":
    main()
