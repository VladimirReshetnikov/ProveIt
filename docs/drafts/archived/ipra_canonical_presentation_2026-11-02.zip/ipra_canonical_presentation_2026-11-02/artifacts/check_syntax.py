#!/usr/bin/env python3
"""Independent finite checks for the canonical iPRA presentation.

This checks exact syntax, specified translations, and bounded natural-number
instances. It is not a formal proof of bi-interpretability or of soundness in
all intuitionistic/nonstandard models. No imported draft code is used.

Run: python3 artifacts/check_syntax.py
The JSON result is written beside this script by default.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from functools import lru_cache
import itertools
import json
import math
from pathlib import Path
import random
from typing import Iterable


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    name: str = ""
    body: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    op: str
    args: tuple[object, ...] = ()
    binder: str = ""


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("0")
v, w = var("v"), var("w")
a, n, u = var("a"), var("n"), var("u")
x, y, z, b = var("x"), var("y"), var("z"), var("b")


def S(t: Term) -> Term:
    return Term("S", (t,))


def B(s: Term, t: Term) -> Term:
    return Term("B", (s, t))


def L(t: Term) -> Term:
    return Term("L", (t,))


def R(t: Term) -> Term:
    return Term("R", (t,))


def rec(h: Term, counter: Term, initial: Term) -> Term:
    if not active_variables(h) <= {"v", "w"}:
        raise ValueError("A descriptor captures an active numerical parameter")
    return Term("rec", (counter, initial), body=h)


def Q(counter: Term, initial: Term) -> Term:
    return rec(w, counter, initial)


def Z(counter: Term, initial: Term) -> Term:
    return rec(ZERO, counter, initial)


def pred(t: Term) -> Term:
    return Q(t, ZERO)


def choose(t: Term, initial: Term, update: Term) -> Term:
    return Q(Z(t, S(initial)), update)


@lru_cache(maxsize=None)
def term_size(t: Term) -> int:
    """Every recursor occurrence pays its complete stored descriptor."""
    return 1 + sum(term_size(c) for c in t.args) + (
        term_size(t.body) if t.body is not None else 0
    )


@lru_cache(maxsize=None)
def active_variables(t: Term) -> frozenset[str]:
    if t.op == "var":
        return frozenset((t.name,))
    return frozenset().union(*(active_variables(c) for c in t.args))


def active_count(t: Term, name: str) -> int:
    return int(t.op == "var" and t.name == name) + sum(
        active_count(c, name) for c in t.args
    )


def substitute(t: Term, substitution: dict[str, Term]) -> Term:
    """Simultaneous active substitution: frozen descriptors are untouched."""
    if t.op == "var":
        return substitution.get(t.name, t)
    return Term(t.op, tuple(substitute(c, substitution) for c in t.args),
                t.name, t.body)


@lru_cache(maxsize=None)
def canonical(t: Term) -> Term:
    """Signature compiler N, including the five computation/kernel rules.

    Descriptors are translated as separate two-slot expressions. This is a
    translation between signatures, not active substitution into a name.
    Identity bodies are never assigned a canonical recursor symbol.
    """
    children = tuple(canonical(c) for c in t.args)
    if t.op == "rec":
        assert t.body is not None
        g = canonical(t.body)
        counter, initial = children
        if g == v:                         # eliminate the identity name
            return initial
        if counter == ZERO:                # R_g(0,t) -> t
            return initial
        if g == w and counter.op == "S":   # Q(S(t),u) -> t
            return counter.args[0]
        return rec(g, counter, initial)
    if t.op == "L" and children[0].op == "B":
        return children[0].args[0]         # L(B(s,t)) -> s
    if t.op == "R" and children[0].op == "B":
        return children[0].args[1]         # R(B(s,t)) -> t
    if t.op == "B":
        left, right = children
        if (left.op == "L" and right.op == "R"
                and left.args[0] == right.args[0]):
            return left.args[0]           # B(L(t),R(t)) -> t
    return Term(t.op, children, t.name, t.body)


def interpret(t: Term) -> Term:
    """Homomorphic term interpretation J, distinct from normalization N."""
    children = tuple(interpret(c) for c in t.args)
    if t.op == "rec":
        assert t.body is not None
        g = canonical(t.body)
        return children[1] if g == v else rec(g, children[0], children[1])
    return Term(t.op, children, t.name, t.body)


def Eq(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


def And(p: Formula, q: Formula) -> Formula:
    return Formula("and", (p, q))


def Or(p: Formula, q: Formula) -> Formula:
    return Formula("or", (p, q))


def Imp(p: Formula, q: Formula) -> Formula:
    return Formula("imp", (p, q))


def K3(p: Formula, q: Formula, r: Formula) -> Formula:
    return Formula("K3", (p, q, r))


def K4(p: Formula, q: Formula, r: Formula, s: Formula) -> Formula:
    return Formula("K4", (p, q, r, s))


def All(names: Iterable[str], p: Formula) -> Formula:
    for name in reversed(tuple(names)):
        p = Formula("all", (p,), name)
    return p


def Ex(names: Iterable[str], p: Formula) -> Formula:
    for name in reversed(tuple(names)):
        p = Formula("ex", (p,), name)
    return p


def formula_size(p: Formula) -> int:
    if p.op == "eq":
        return 1 + sum(term_size(t) for t in p.args)
    return 1 + sum(formula_size(q) for q in p.args)


def expand_chains(p: Formula) -> Formula:
    if p.op == "eq" or p.op in {"bot", "prop"}:
        return p
    args = tuple(expand_chains(q) for q in p.args)
    if p.op == "K3":
        q, r, s = args
        return And(Imp(q, r), Imp(r, s))
    if p.op == "K4":
        q, r, s, t = args
        return And(Imp(q, r), Imp(r, Imp(s, t)))
    return Formula(p.op, args, p.binder)


def contract_guard(h: Term, state: Term, counter: Term,
                   successor: Term) -> Term:
    """Replace active literal S(w) first; never inspect a frozen body."""
    if h == S(w):
        return successor
    if h == v:
        return state
    if h == w:
        return counter
    return Term(h.op, tuple(contract_guard(c, state, counter, successor)
                            for c in h.args), h.name, h.body)


def profile(h: Term) -> tuple[int, int, int, int]:
    def probes(t: Term) -> tuple[int, int]:
        if t == S(w):
            return 1, 0
        if t == w:
            return 0, 1
        values = [probes(c) for c in t.args]
        return sum(q[0] for q in values), sum(q[1] for q in values)
    j, r = probes(h)
    return term_size(h), active_count(h, "v"), j, r


def modules(h: Term) -> dict[str, tuple[Formula, ...]]:
    step = substitute(h, {"v": rec(h, n, a), "w": n})
    guarded = contract_guard(h, u, n, x)
    result = {
        "O": (All(("a",), Eq(rec(h, ZERO, a), a)),
              All(("a", "n"), Eq(rec(h, S(n), a), step))),
        "G": (All(("a", "n", "u"), K3(
            And(Eq(n, ZERO), Eq(u, a)), Eq(rec(h, n, a), u),
            Eq(rec(h, S(n), a), substitute(h, {"v": u, "w": n})))),),
        "T": (All(("a", "n"), Ex(("u",), And(
            Imp(Eq(n, ZERO), Eq(u, a)), All(("x", "y"), K4(
                And(Eq(x, n), Eq(y, u)), Eq(rec(h, x, a), y),
                Eq(x, S(n)), Eq(y, guarded)))))),),
        "F": (All(("a", "n"), Eq(rec(h, n, a), choose(n, a,
            contract_guard(h, rec(h, pred(n), a), pred(n), n)))),),
    }
    if profile(h)[3] == 0:
        result["N4"] = (All(("a", "n"), Ex(("u",),
            All(("x", "y"), K4(
                And(Eq(S(x), n), Eq(y, u)), Eq(rec(h, x, a), y),
                Eq(x, n), Eq(y, choose(n, a,
                    contract_guard(h, u, ZERO, n))))))),)
    return result


def module_costs(h: Term) -> dict[str, int]:
    return {name: sum(formula_size(p) for p in ps)
            for name, ps in modules(h).items()}


def boundary(p: Formula) -> Formula:
    return All(("a",), Ex(("b",), All(("x",),
        K4(Eq(S(x), b), p, Eq(x, b), Eq(b, a)))))


def active_subterms(t: Term) -> list[Term]:
    result: list[Term] = []
    seen: set[Term] = set()
    def visit(s: Term) -> None:
        for child in s.args:
            visit(child)
        if s.op != "var" and s not in seen:
            seen.add(s)
            result.append(s)
    visit(t)
    return result


def replace_selected(t: Term, names: dict[Term, Term]) -> Term:
    if t in names:
        return names[t]
    return Term(t.op, tuple(replace_selected(c, names) for c in t.args),
                t.name, t.body)


def factor_equation(p: Formula, limit: int = 14) -> tuple[Formula, int]:
    """Exact subset factoring; explicit local binders, no implicit sharing.

    A modest bound protects diagnostic runtime; inputs above it are rejected,
    not silently approximated. The presentation's mathematical operator has
    no such diagnostic bound.
    """
    assert p.op == "eq"
    terms: list[Term] = []
    for side in p.args:
        for t in active_subterms(side):
            if t not in terms:
                terms.append(t)
    if len(terms) > limit:
        raise ValueError("Factoring diagnostic exceeds subset bound")
    best = p
    best_key = (formula_size(p), 0, ())
    checked = 0
    for mask in range(1 << len(terms)):
        chosen = tuple(i for i in range(len(terms)) if mask >> i & 1)
        mapping: dict[Term, Term] = {}
        bindings: list[tuple[Term, Term]] = []
        for i in chosen:
            symbol = var("__share_" + str(i))
            assert symbol.name not in set().union(
                *(active_variables(t) for t in p.args))
            rhs = replace_selected(terms[i], mapping)
            bindings.append((symbol, rhs))
            mapping[terms[i]] = symbol
        leaf = Eq(*(replace_selected(t, mapping) for t in p.args))
        reconstructed = leaf
        for symbol, rhs in reversed(bindings):
            reconstructed = Eq(*(substitute(t, {symbol.name: rhs})
                                 for t in reconstructed.args))
        assert reconstructed == p
        candidate = leaf
        for symbol, rhs in reversed(bindings):
            candidate = Ex((symbol.name,), And(Eq(symbol, rhs), candidate))
        key = (formula_size(candidate), len(chosen), chosen)
        if key < best_key:
            best, best_key = candidate, key
        checked += 1
    assert formula_size(best) <= formula_size(p)
    return best, checked


def pair(a_value: int, n_value: int) -> int:
    k = a_value + n_value
    return k * (k + 1) // 2 + n_value


def coordinates(value: int) -> tuple[int, int]:
    k = (math.isqrt(8 * value + 1) - 1) // 2
    right = value - k * (k + 1) // 2
    return k - right, right


def evaluate(t: Term, assignment: dict[str, int],
             fuel: list[int] | None = None) -> int:
    if fuel is None:
        fuel = [200000]
    fuel[0] -= 1
    if fuel[0] < 0:
        raise OverflowError("Diagnostic evaluation fuel exhausted")
    if t.op == "0":
        return 0
    if t.op == "var":
        return assignment[t.name]
    values = [evaluate(c, assignment, fuel) for c in t.args]
    if t.op == "S":
        result = values[0] + 1
    elif t.op == "B":
        result = pair(*values)
    elif t.op in {"L", "R"}:
        result = coordinates(values[0])[int(t.op == "R")]
    elif t.op == "rec":
        counter, result = values
        if counter > 200:
            raise OverflowError("Diagnostic counter bound exceeded")
        assert t.body is not None
        for i in range(counter):
            result = evaluate(t.body, {"v": result, "w": i}, fuel)
    else:
        raise ValueError(t.op)
    if result > 1000000:
        raise OverflowError("Diagnostic value bound exceeded")
    return result


def boundary_root_reductions(t: Term) -> set[Term]:
    """Only recursor computations, with a strict full-size decrease.

    This is deliberately NOT canonical(): native beta/eta rules belong to
    signature translation, not to this boundary reduction policy.
    """
    result: set[Term] = set()
    if t.op == "rec":
        counter, initial = t.args
        assert t.body is not None
        if counter == ZERO:
            result.add(initial)
        if counter.op == "S":
            previous = counter.args[0]
            result.add(substitute(t.body, {
                "v": rec(t.body, previous, initial), "w": previous}))
            if t.body == w:
                result.add(previous)
    return {s for s in result if term_size(s) < term_size(t)}


def boundary_one_steps(t: Term) -> set[Term]:
    result = boundary_root_reductions(t)
    for i, child in enumerate(t.args):
        for replacement in boundary_one_steps(child):
            children = list(t.args)
            children[i] = replacement
            result.add(Term(t.op, tuple(children), t.name, t.body))
    return result


def guarded_by(t: Term, target: str, marker: Term) -> bool:
    def walk(s: Term, under_marker: bool) -> bool:
        under_marker = under_marker or s == marker
        if s.op == "var" and s.name == target:
            return under_marker
        return all(walk(c, under_marker) for c in s.args)
    return walk(t, False)


def protected(t: Term, target: str = "x", depth: int = 2) -> bool:
    marker = var(target)
    for _ in range(depth):
        marker = R(marker)
    return guarded_by(t, target, marker)


def random_terms() -> tuple[list[Term], list[Term]]:
    rng = random.Random(20261102)
    descriptions = [ZERO, v, w, S(v), S(w), Q(v, ZERO),
                    B(v, w), L(v), R(v), B(L(v), R(v))]
    current = list(descriptions)
    for _ in range(4):
        earlier = tuple(descriptions)
        for _ in range(35):
            left, right = rng.choice(current), rng.choice(current)
            op = rng.randrange(7)
            if op == 0:
                candidate = S(left)
            elif op == 1:
                candidate = B(left, right)
            elif op == 2:
                candidate = L(B(left, right))
            elif op == 3:
                candidate = R(B(left, right))
            elif op == 4:
                candidate = B(L(left), R(left))
            elif op == 5:
                candidate = rec(rng.choice(earlier), ZERO, left)
            else:
                candidate = Q(S(left), right)
            if term_size(candidate) <= 180:
                current.append(candidate)
        descriptions.extend(current[-20:])
    descriptions = list(dict.fromkeys(descriptions + current))
    terms = [substitute(h, {"v": x, "w": a}) for h in descriptions]
    terms += [rec(h, n, a) for h in descriptions]
    return descriptions, terms


def run_checks() -> dict[str, object]:
    facts: dict[str, object] = {}
    sep = Imp(Eq(ZERO, S(ZERO)), Formula("bot"))
    cov = All(("z",), Ex(("y",), Or(Eq(z, ZERO), Eq(z, S(y)))))
    eta = All(("z",), Eq(B(L(z), R(z)), z))
    horizontal = Eq(S(B(S(a), n)), B(a, S(n)))
    projection = And(Eq(L(B(a, n)), a), Eq(R(B(a, n)), n))
    merged = All(("a", "n"), And(horizontal, projection))
    vertical = All(("n",), Eq(S(B(ZERO, n)), B(S(n), ZERO)))
    assert (formula_size(eta), formula_size(merged), formula_size(vertical)) == (8, 26, 10)
    assert formula_size(sep) == 6 and formula_size(cov) == 10
    prop = [Formula("prop", binder=name) for name in "ABCD"]
    p, q, r, s = prop
    k3_record = 1 + formula_size(K3(p, q, r)) + formula_size(expand_chains(K3(p, q, r)))
    k4_joint_record = 1 + formula_size(K4(p, q, r, s)) + formula_size(K3(p, q, Imp(r, s)))
    k4_standalone = 1 + formula_size(K4(p, q, r, s)) + formula_size(expand_chains(K4(p, q, r, s)))
    assert (k3_record, k4_joint_record, k4_standalone) == (12, 12, 15)
    facts["fixed_ledger"] = {
        "pairing_eta": 8, "pairing_merged_horizontal_projections": 26,
        "pairing_vertical": 10, "pairing_total": 44,
        "Sep": 6, "Cov": 10, "SepCov": 16,
        "K3_definition": 12, "K4_definition_from_K3": 12,
        "joint_definitions": 24, "standalone_K4_definition": 15,
        "joint_fixed_total": 84,
    }

    descriptions, terms = random_terms()
    boundary_cases = 0
    module_cases = 0
    for h in descriptions:
        H, k, j, remaining = profile(h)
        assert term_size(contract_guard(h, u, n, x)) == H - j
        assert contract_guard(h, u, n, S(n)) == substitute(h, {"v": u, "w": n})
        actual = module_costs(h)
        expected = {
            "O": 3 * H + 13 + k * (H + 2),
            "G": 3 * H + 21,
            "T": 2 * H - j + 32,
            "F": 2 * H - j + 13 + k * (H + 5) + 3 * remaining,
        }
        if remaining == 0:
            expected["N4"] = 2 * H - j + 31
        assert actual == expected, (h, actual, expected)
        module_cases += len(actual)
        equation = Eq(substitute(h, {"v": x, "w": a}), ZERO)
        size = formula_size(equation)
        assert formula_size(boundary(equation)) == size + 14
        assert formula_size(expand_chains(boundary(equation))) == 2 * size + 17
        boundary_cases += 1
    facts["exact_count_cases"] = {
        "descriptors": len(descriptions), "complete_modules": module_cases,
        "boundaries": boundary_cases,
        "templates": ["O", "G", "T", "F", "N4 when r=0"],
    }

    frozen_example = rec(B(v, w), x, a)
    changed = substitute(frozen_example, {"v": ZERO, "w": ZERO, "x": S(x)})
    assert changed.body == B(v, w) and changed.args == (S(x), a)
    assert active_count(frozen_example, "v") == 0
    facts["frozen_descriptor_substitution"] = "passed"

    for t in terms:
        nt, jt = canonical(t), interpret(t)
        assert canonical(nt) == nt
        assert term_size(nt) <= term_size(t)
        assert term_size(jt) <= term_size(t)
        assert canonical(jt) == nt
        assert active_variables(nt) <= active_variables(t)
    facts["canonical_syntax_cases"] = len(terms)

    duplicate_rows = []
    identity, counter, native = v, w, v
    for m in range(13):
        assert term_size(identity) == 4 * m + 1
        assert term_size(counter) == 4 * m + 1
        assert term_size(native) == 4 * (2 ** m) - 3
        assert canonical(identity) == v and canonical(counter) == w
        assert canonical(native) == v
        assert canonical(rec(identity, n, a)) == a
        assert canonical(rec(counter, n, a)) == Q(n, a)
        assert canonical(rec(native, n, a)) == a
        duplicate_rows.append({
            "m": m, "identity_body_size": term_size(identity),
            "counter_body_size": term_size(counter),
            "native_eta_body_size": term_size(native),
            "old_decoder_identity_module": term_size(identity) + 7,
            "old_decoder_counter_alias_module": (term_size(counter) + 10 if m else None),
            "canonical_additional_modules": 0,
        })
        identity = Q(S(identity), ZERO)
        counter = Q(S(counter), ZERO)
        native = B(L(native), R(native))
    facts["duplicate_families"] = duplicate_rows

    numerical_cases = 0
    evaluation_skips = 0
    # Small explicitly generated cases exercise every normalization rule and
    # frozen bodies without letting bounded testing masquerade as a proof.
    selected = descriptions[:70] + [Q(S(v), ZERO), L(B(v, w)), R(B(v, w)),
                                   B(L(v), R(v)), rec(v, w, v)]
    for h in selected:
        for left, right in itertools.product(range(5), repeat=2):
            assignment = {"v": left, "w": right}
            try:
                original = evaluate(h, assignment)
                normal = evaluate(canonical(h), assignment)
                translated = evaluate(interpret(h), assignment)
            except OverflowError:
                evaluation_skips += 1
                continue
            assert original == normal == translated
            numerical_cases += 1
    pairing_cases = 0
    for left, right in itertools.product(range(40), repeat=2):
        code = pair(left, right)
        assert coordinates(code) == (left, right)
        assert pair(left + 1, right) + 1 == pair(left, right + 1)
        pairing_cases += 1
    for code in range(2500):
        left, right = coordinates(code)
        assert pair(left, right) == code
        next_left, next_right = coordinates(code + 1)
        assert next_right in {0, right + 1}
        assert (next_left, next_right) == ((right + 1, 0) if left == 0
                                         else (left - 1, right + 1))
        assert pair(0, code) + 1 == pair(code + 1, 0)
        pairing_cases += 1
    facts["bounded_semantics"] = {
        "normalization_instances": numerical_cases,
        "instances_skipped_at_explicit_resource_bounds": evaluation_skips,
        "pairing_instances": pairing_cases,
    }

    guard = R(R(x))
    protected_terms = [substitute(h, {"v": guard, "w": a}) for h in descriptions]
    protected_terms += [rec(h, S(guard), B(a, guard)) for h in descriptions]
    protected_terms += [rec(h, ZERO, guard) for h in descriptions]
    reduction_count = 0
    for t in protected_terms:
        assert protected(t)
        for reduced in boundary_one_steps(t):
            assert term_size(reduced) < term_size(t)
            assert protected(reduced)
            assert active_variables(reduced) <= active_variables(t)
            reduction_count += 1
    facts["nested_projection_protection"] = {
        "input_terms": len(protected_terms), "one_step_reductions": reduction_count,
        "guard": "intact native R(R(x))",
        "policy": "active strictly shrinking recursor reductions only; no native beta/eta",
    }

    # The presentation's two-slot filter protects BOTH slots independently.
    # Neither free a outside L(a) nor free x outside R(x) may be introduced.
    two_slot_terms = [substitute(h, {"v": R(x), "w": L(a)})
                      for h in descriptions]
    two_slot_terms += [rec(h, S(R(x)), B(L(a), R(x)))
                       for h in descriptions]
    two_slot_terms += [rec(h, ZERO, B(L(a), R(x)))
                       for h in descriptions]
    two_slot_terms += [rec(h, L(a), R(x)) for h in descriptions]
    two_slot_reductions = 0
    inputs_with_both_slots = 0
    reductions_with_both_slots = 0
    for t in two_slot_terms:
        assert guarded_by(t, "x", R(x))
        assert guarded_by(t, "a", L(a))
        inputs_with_both_slots += {"x", "a"} <= active_variables(t)
        for reduced in boundary_one_steps(t):
            assert term_size(reduced) < term_size(t)
            assert guarded_by(reduced, "x", R(x))
            assert guarded_by(reduced, "a", L(a))
            assert active_variables(reduced) <= active_variables(t)
            two_slot_reductions += 1
            reductions_with_both_slots += {"x", "a"} <= active_variables(reduced)
    # Negative controls ensure a vacuous test does not pass an exposed slot.
    assert not guarded_by(B(x, L(a)), "x", R(x))
    assert not guarded_by(B(R(x), a), "a", L(a))
    assert guarded_by(B(R(x), L(a)), "x", R(x))
    assert guarded_by(B(R(x), L(a)), "a", L(a))
    facts["boundary_protection"] = {
        "input_terms": len(two_slot_terms),
        "input_terms_with_both_slots": inputs_with_both_slots,
        "one_step_reductions": two_slot_reductions,
        "reductions_retaining_both_slots": reductions_with_both_slots,
        "x_guard": "intact native R(x)",
        "a_guard": "intact native L(a)",
        "negative_controls": "both exposed-slot counterexamples rejected",
        "policy": "active strictly shrinking recursor reductions only; no native beta/eta",
    }

    filter_rows = []
    body = v
    for m in range(1, 13):
        body = S(body)
        equation = Eq(rec(body, R(x), a), a)
        assert canonical(body) == body and body != v
        assert all(guarded_by(side, "x", R(x)) for side in equation.args)
        assert not all(guarded_by(side, "a", L(a)) for side in equation.args)
        assert not any(boundary_one_steps(side) for side in equation.args)
        shared, _ = factor_equation(equation)
        assert shared == equation
        assert formula_size(equation) == m + 7
        assert formula_size(boundary(equation)) == m + 21
        filter_rows.append({
            "m": m, "equation_size": m + 7,
            "old_single_slot_boundary": m + 21,
            "new_two_slot_boundary_at_this_index": 0,
        })
    facts["strict_two_slot_filter_family"] = {
        "equation": "R_{S^m(v)}(R(x),a)=a, m>=1",
        "instances": filter_rows,
        "limitation": "The replacement induction proof uses a new lifted index; no proof-size domination is asserted.",
    }

    large = S(S(S(S(S(S(S(S(x))))))))
    factored, choices = factor_equation(Eq(B(large, large), B(large, a)))
    assert formula_size(factored) < formula_size(Eq(B(large, large), B(large, a)))
    # A second example ensures frozen names are charged but not sharing sites.
    payload = rec(Q(S(v), ZERO), x, a)
    sample = Eq(B(payload, payload), B(payload, ZERO))
    factored_second, choices_second = factor_equation(sample)
    assert formula_size(factored_second) < formula_size(sample)
    facts["explicit_equality_factoring"] = {
        "subsets_checked": choices + choices_second,
        "first_original_size": formula_size(Eq(B(large, large), B(large, a))),
        "first_factored_size": formula_size(factored),
        "second_original_size": formula_size(sample),
        "second_factored_size": formula_size(factored_second),
        "reconstruction": "every tested binding set expands back to its source equation",
    }
    facts["status"] = "all finite checks passed"
    facts["scope"] = (
        "Exact syntax/count checks and bounded standard-natural-number diagnostics; "
        "not a proof-assistant verification of the infinite theory, its intuitionistic "
        "interpretations, arbitrary nonstandard models, or global minimality."
    )
    return facts


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("syntax_results.json"))
    args = parser.parse_args()
    results = run_checks()
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": results["status"],
                      "results": str(args.output),
                      "count_cases": results["exact_count_cases"],
                      "canonical_terms": results["canonical_syntax_cases"],
                      "semantics": results["bounded_semantics"],
                      "protection": results["boundary_protection"]}, indent=2))


if __name__ == "__main__":
    main()
