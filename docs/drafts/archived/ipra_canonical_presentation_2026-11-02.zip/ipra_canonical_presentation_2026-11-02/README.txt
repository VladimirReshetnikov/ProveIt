CANONICAL DESCRIPTIONS AND PROJECTED BOUNDARIES FOR iPRA
2 November 2026
========================================================

Main result
-----------
The report gives an effective first-order intuitionistic theory C_34
definitionally equivalent, bi-interpretable, and equiconsistent with full
first-order intuitionistic primitive recursive arithmetic. The proof preserves
the whole carrier, native equality, genuine falsity, and arbitrary quantifiers.

New reductions relative to the pinned current drafts:
* Normalize finite recursion descriptions BEFORE naming recursors.
  Eliminate identity names and reuse existing canonical names for duplicates.
* Require both boundary slots to be protected: x inside R(x), a inside L(a).
* Merge the pairing quantifier prefix: kernel 45 -> 44 nodes.
* Combine the surviving best computation templates and exact equality sharing;
  use the inherited shared chain definitions at cost 24 rather than 27.

Fixed joint arithmetic/definition record: 84, previously 88 in the paired
draft. Protected Q,Z computations cost another 32 and are not hidden.
An old packet also containing identity support drops from 128 to 116.
These are finite packets, NOT the total size of the infinite theory.

The identity and duplicate families have unbounded removed module sizes.
The report states exactly which comparisons are proved and does not claim an
encoding-independent absolute minimum or shorter proofs for every theorem.

Files
-----
report.pdf                Compiled 24-page research report (final page count
                          is also recorded in artifacts/pdf_review.json).
report.tex, sections/     Complete editable LaTeX source.
AXIOMS.txt                Compact exact reference specification.
artifacts/check_syntax.py Fresh finite AST/count/normalization diagnostics.
artifacts/syntax_results.json
                          Exact results, including numerical resource skips.
provenance/               Source commit, Git blobs, hashes, review decisions.
build.py                  Re-run checks and compile the report.
SHA256SUMS.txt            Hashes of delivered files, excluding itself.

Rebuild
-------
Run from this directory:
    python3 build.py

Requires Python 3 and pdfLaTeX with standard AMS, Latin Modern, microtype,
geometry, booktabs, enumitem, xurl, hyperref, fancyhdr, and listings packages.
No third-party Python package is needed for the finite syntax checks.

Verification scope
------------------
The central metatheorem is a written constructive proof. The executable
checks exact finite syntax and bounded standard-natural-number behavior;
it is not a full proof-assistant formalization or a complete axiom emitter.
The diagnostic numerical bounds and factoring subset cap do not occur in
the mathematical specification of the theory.

Source provenance
-----------------
Repository: VladimirReshetnikov/ProveIt
Commit: 85560eb1cf1cdc96767951e3317716392e5c5496
Compared: four current archives against five immediately archived archives.
All four current drafts contain a surviving improvement; overlapping or
dominated components are not counted as separate advances.

This archive is the deliverable; no repository push or PR is implied.
