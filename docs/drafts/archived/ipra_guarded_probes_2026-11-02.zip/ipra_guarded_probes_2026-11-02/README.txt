INTUITIONISTIC PRA BY GUARDED PROBES
Research iteration prepared for Vladimir Reshetnikov
November 2, 2026

MAIN RESULT
The report gives explicit effective first-order intuitionistic theories,
proves common conservative definitional extensions with iPRA, and supplies
whole-carrier identity round trips. It does not replace iPRA by classical PRA.

The new guarded-probe computation table has cost 2H-j+33 in the existing
chain vocabulary. Here H is full descriptor size, including frozen nested
descriptions, and j counts active S(w) subterms. A state-independent table
costs 2H-j+3r+22; a mixed C/J table costs 2H-j+32 and has a local converse
requiring separation alone. An explicit infinite family has unbounded
savings over the previous recurring computation envelope.

Start with report.pdf. Its complete source is report.tex plus sections/.
AXIOMS.txt is a standalone compact specification.

SOURCE BASELINE
Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: 0593751362f559ccc52e269fe5ecac06a7d6e63c
Audited directory: docs/drafts/
Five current ZIPs and six archived ZIPs were read.
provenance/source_manifest.json records their exact paths and hashes.
All five current drafts improve some coordinate over the archived iteration
and remain comparison candidates.

FILES
report.pdf                    Compiled mathematical report.
report.tex, sections/*.tex     Complete editable LaTeX source.
AXIOMS.txt                    Exact compact theory and cost specification.
checks/syntax_audit.py         Dependency-free AST counts and substitutions.
checks/syntax_audit.json       Recorded output of the AST audit.
checks/finite_models.py        Exhaustive local finite-model diagnostics.
checks/finite_models.json      Recorded output, including counterexample.
provenance/source_manifest.json
                              Source repository identities and checksums.
provenance/review_notes.txt    Scope of independent mathematical review.
verification.txt              Final build and diagnostic status.
SHA256SUMS.txt                Checksums of all other archive members.

REPRODUCING THE CHECKS
From this directory, using Python 3.10 or later:

    python3 checks/syntax_audit.py
    python3 checks/finite_models.py

No third-party Python packages are needed.
The programs print JSON and exit nonzero if an assertion fails.

REBUILDING THE PDF
Using a TeX distribution containing latexmk, pdfLaTeX, amsmath, amsthm,
mathtools, lmodern, microtype, booktabs, enumitem, fancyhdr and hyperref:

    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

Alternatively run pdflatex enough times to resolve the table of contents
and references, normally three times on a clean directory.

WHAT WAS AND WAS NOT VERIFIED
The full general result is a written mathematical proof.
The Python audit checks literal AST counts, guard substitution, frozen
descriptions, selector bootstraps, and the reported infinite family.
Finite diagnostics check 1,024 two-element structures for the pure table,
512 Sep structures for the mixed table, and 64 eligible state-free
structures. These local tests do not formalize full iPRA or prove
bi-interpretability by themselves. No complete Lean/Rocq certificate
is claimed.

MINIMALITY SCOPE
The pure-chain theory is the recommended single presentation.
The optional mixed theory matches or improves the retained recurring
module envelope, but its fixed record is 39 rather than 28 for pure C
or 27 for the earlier covered J presentation.
Finite packets must charge definitions and missing arithmetic support.
Retain earlier complete formats when their total cost is smaller.
No absolute minimum over arbitrary languages, domains, calculi, encodings,
axiom-generator lengths, or proof lengths is claimed.

The bounded finite-candidate export comparison in the paper is a policy
for comparing explicit complete packages, not an implemented universal
shortest-proof search.
