#!/usr/bin/env python3
"""Audit literal syntax costs for the iPRA guarded-probe presentation.

Run with Python 3.10 or later, without third-party dependencies:
    python3 checks/syntax_audit.py

The JSON result checks AST sizes and finite syntactic identities. It is
not a proof-assistant verification of first-order equivalence or of the
bi-interpretation theorem. Every generated-function occurrence pays for
its complete frozen descriptor, even when Python objects are shared.
"""

from dataclasses import dataclass
import json


@dataclass(frozen=True)
class Node:
    op: str
    children: tuple = ()
    name: str = ""


def var(name):
    return Node("var", name=name)


ZERO = Node("zero")
BOTTOM = Node("bottom")
V, W = var("v"), var("w")
A, N, U, X, Y, B = map(var, ("a", "n", "u", "x", "y", "b"))


def node(op, *children):
    return Node(op, children)


def successor(t):
    return node("S", t)


def recursor(descriptor, counter, initial):
    return node("R", descriptor, counter, initial)


def equals(left, right):
    return node("eq", left, right)


def implies(left, right):
    return node("imp", left, right)


def conjunction(left, right):
    return node("and", left, right)


def disjunction(left, right):
    return node("or", left, right)


def chain(first, middle, last):
    return node("C", first, middle, last)


def conditional(test, alternative, consequence):
    return node("J", test, alternative, consequence)


def forall(names, formula):
    for name in reversed(names):
        formula = Node("forall", (formula,), name)
    return formula


def exists(name, formula):
    return Node("exists", (formula,), name)


def size(tree):
    """Bound-variable labels cost zero; each AST node costs one."""
    return 1 + sum(size(child) for child in tree.children)


def active_children(term):
    return term.children[1:] if term.op == "R" else term.children


def active_count(term, name):
    return int(term.op == "var" and term.name == name) + sum(
        active_count(child, name) for child in active_children(term)
    )


def protected_count(term):
    """Count active, pairwise disjoint subterms literally equal to S(w)."""
    if term == successor(W):
        return 1
    return sum(protected_count(child) for child in active_children(term))


def substitute(term, environment):
    """Capture-free substitution on unbound terms; freeze R descriptors."""
    if term.op in {"forall", "exists"}:
        raise ValueError("This helper substitutes only in unbound terms.")
    if term.op == "var":
        return environment.get(term.name, term)
    if term.op == "R":
        descriptor, counter, initial = term.children
        return recursor(descriptor, substitute(counter, environment),
                        substitute(initial, environment))
    return Node(term.op, tuple(substitute(c, environment) for c in term.children),
                term.name)


def guarded_probe(term):
    """Replace active S(w) by x, then residual v,w by u,n."""
    if term == successor(W):
        return X
    if term.op == "var":
        return {"v": U, "w": N}.get(term.name, term)
    if term.op == "R":
        descriptor, counter, initial = term.children
        return recursor(descriptor, guarded_probe(counter), guarded_probe(initial))
    return Node(term.op, tuple(guarded_probe(c) for c in term.children), term.name)


def predecessor_adapter(term):
    """For a state-free h: S(w) becomes x; residual w becomes Q(x,0)."""
    if term == successor(W):
        return X
    if term == W:
        return recursor(W, X, ZERO)
    if term == V:
        raise ValueError("The predecessor adapter requires a state-free update.")
    if term.op == "R":
        descriptor, counter, initial = term.children
        return recursor(descriptor, predecessor_adapter(counter),
                        predecessor_adapter(initial))
    return Node(term.op, tuple(predecessor_adapter(c) for c in term.children),
                term.name)


def direct_pair(h):
    current = recursor(h, N, A)
    return (
        forall(["a"], equals(recursor(h, ZERO, A), A)),
        forall(["a", "n"], equals(recursor(h, successor(N), A),
                                  substitute(h, {"v": current, "w": N}))),
    )


def current_graph(h):
    return forall(["a", "n", "u"], chain(
        conjunction(equals(N, ZERO), equals(U, A)), equals(recursor(h, N, A), U),
        equals(recursor(h, successor(N), A), substitute(h, {"v": U, "w": N}))))


def endpoint_graph(h):
    return forall(["a", "n"], exists("u", conjunction(
        implies(equals(N, ZERO), equals(U, A)),
        forall(["x", "y"], chain(
            conjunction(equals(X, N), equals(Y, U)), equals(recursor(h, X, A), Y),
            implies(equals(X, successor(N)), equals(Y, guarded_probe(h))))))))


def mixed_graph(h):
    return forall(["a", "n"], exists("u", forall(["x", "y"], chain(
        conjunction(equals(X, N), equals(Y, U)), equals(recursor(h, X, A), Y),
        conditional(equals(X, successor(N)),
                    implies(equals(X, ZERO), equals(Y, A)),
                    equals(Y, guarded_probe(h)))))))


def state_free_graph(h):
    assert active_count(h, "v") == 0
    return forall(["a", "x", "y"], chain(
        conjunction(equals(X, ZERO), equals(Y, A)), equals(recursor(h, X, A), Y),
        forall(["n"], implies(equals(X, successor(N)),
                              equals(Y, substitute(h, {"v": ZERO, "w": N}))))))


def adapted_graph(h):
    assert active_count(h, "v") == 0
    return forall(["a", "x", "y"], chain(
        conjunction(equals(X, ZERO), equals(Y, A)), equals(recursor(h, X, A), Y),
        disjunction(equals(X, ZERO), equals(Y, predecessor_adapter(h)))))


def boundary(equation):
    parameters = ["a"] if active_count(equation, "a") else []
    return forall(parameters + ["n"], exists("b", forall(["x"], chain(
        equals(successor(X), B), equation, implies(equals(X, B), equals(B, N))))))


def audit_descriptor(h):
    H = size(h)
    k = active_count(h, "v")
    j = protected_count(h)
    residual = active_count(h, "w") - j
    transformed = guarded_probe(h)
    assert size(transformed) == H - j
    assert substitute(transformed, {"x": successor(N)}) == substitute(
        h, {"v": U, "w": N})
    actual = {
        "D": sum(size(formula) for formula in direct_pair(h)),
        "G_C": size(current_graph(h)),
        "T_C_dagger": size(endpoint_graph(h)),
        "M_CJ_dagger": size(mixed_graph(h)),
    }
    expected = {
        "D": 3 * H + 13 + k * (H + 2),
        "G_C": 3 * H + 21,
        "T_C_dagger": 2 * H - j + 33,
        "M_CJ_dagger": 2 * H - j + 32,
    }
    if k == 0:
        G = size(predecessor_adapter(h))
        assert G == H - j + 3 * residual
        actual.update(V_C=size(state_free_graph(h)), A_C=size(adapted_graph(h)))
        expected.update(V_C=2 * H + 24, A_C=2 * H - j + 3 * residual + 22)
    if h == V:
        actual["identity"] = size(forall(["a", "n"], equals(recursor(h, N, A), A)))
        expected["identity"] = 8
    assert actual == expected, (actual, expected)
    pure = {name: cost for name, cost in actual.items() if name != "M_CJ_dagger"}
    old = min(3 * H + 13 + k * (H + 2), 3 * H + 21, 2 * H + 32,
              2 * H + 24 if k == 0 else float("inf"))
    return {"H": H, "k": k, "j": j, "r": residual, "sizes": actual,
            "pure_C_min": min(pure.values()), "mixed_min": min(actual.values()),
            "old_best_module_across_bases": old}


def main():
    separation = implies(equals(ZERO, successor(ZERO)), BOTTOM)
    coverage = forall(["x"], exists("y", disjunction(
        equals(X, ZERO), equals(X, successor(Y)))))
    seed15 = forall(["x"], exists("y", conditional(
        equals(X, ZERO), equals(X, successor(Y)), implies(equals(Y, ZERO), BOTTOM))))
    assert (size(separation), size(coverage), size(seed15)) == (6, 10, 15)
    p, q, t = map(var, ("P", "Q", "T"))
    c_record = size(chain(p, q, t)) + size(conjunction(implies(p, q), implies(q, t))) + 1
    j_record = size(conditional(p, q, t)) + size(conjunction(disjunction(p, q),
                                                         implies(p, t))) + 1
    assert c_record == j_record == 12

    # Both generated variables and protected subterms inside descriptors stay frozen.
    frozen_example = recursor(successor(W), successor(W), V)
    assert protected_count(frozen_example) == 1
    assert active_count(frozen_example, "w") == 1
    assert guarded_probe(frozen_example).children[0] == successor(W)
    assert substitute(frozen_example, {"w": ZERO}).children[0] == successor(W)

    closed, shifted = ZERO, W
    for _ in range(99):
        closed, shifted = successor(closed), successor(shifted)
    examples = {
        "Q": W, "Z": ZERO, "identity": V, "successor_update": successor(V),
        "subtraction_update": recursor(W, V, ZERO),
        "toggle_update": recursor(ZERO, V, W),
        "closed_100": closed, "shifted_100": shifted,
        "mixed_counter_occurrences": recursor(successor(V), successor(W), W),
        "frozen_counter_descriptor": frozen_example,
    }
    sample_results = {name: audit_descriptor(h) for name, h in examples.items()}
    for name in ("Q", "Z"):
        row = sample_results[name]
        assert row["sizes"]["D"] == row["pure_C_min"] == row["mixed_min"] == 16
        assert all(cost > 16 for key, cost in row["sizes"].items() if key != "D")

    boundaries = []
    for h in (W, successor(V), closed):
        for initial in (A, ZERO):
            equation = equals(recursor(h, X, initial), ZERO)
            F = size(equation)
            epsilon = int(active_count(equation, "a") > 0)
            actual = size(boundary(equation))
            assert actual == F + 15 + epsilon
            boundaries.append({"F": F, "epsilon": epsilon, "size": actual})

    family = []
    h = V
    for m in range(31):
        row = audit_descriptor(h)
        assert (row["H"], row["k"], row["j"]) == (5 * m + 1, 1, m)
        assert row["sizes"]["T_C_dagger"] == 9 * m + 35
        assert row["sizes"]["M_CJ_dagger"] == 9 * m + 34
        if m >= 2:
            assert row["old_best_module_across_bases"] == 10 * m + 34
        family.append({"m": m, **row})
        h = recursor(successor(V), successor(W), h)

    print(json.dumps({
        "status": "all assertions passed",
        "scope": "Exact AST sizes and finite syntactic identities; no metatheory formalization.",
        "fixed_sizes": {"Sep": 6, "Cov": 10, "S15": 15,
                        "C_definition": c_record, "J_definition": j_record,
                        "pure_C_record": 28, "mixed_S15_record": 39},
        "samples": sample_results, "boundaries": boundaries, "family": family,
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
