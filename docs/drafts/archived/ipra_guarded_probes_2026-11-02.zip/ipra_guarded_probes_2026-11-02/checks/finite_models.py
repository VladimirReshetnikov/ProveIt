#!/usr/bin/env python3
"""Finite diagnostics for the computation tables in the accompanying report.

These are exhaustive two-element Boolean model checks, not a formal proof of
intuitionistic first-order equivalence or of the full iPRA calibration.  The
paper gives the constructive proofs.  The active guarded substitution is a
syntactic congruence lemma; these checks use h itself in the guarded position.

Function tables use row-major indexing.  A binary table f is indexed as
f[2 * first_argument + second_argument].  No downloaded code is executed.
"""

from __future__ import annotations

import argparse
from itertools import product
import json
from pathlib import Path
from typing import Sequence

DOMAIN = range(2)
PAIRS = tuple(product(DOMAIN, repeat=2))
UNARY_TABLES = tuple(product(DOMAIN, repeat=2))
BINARY_TABLES = tuple(product(DOMAIN, repeat=4))


def require(condition: bool, message: str) -> None:
    """Keep verification active also when Python is run with -O."""
    if not condition:
        raise RuntimeError(message)


def chain(first: bool, middle: bool, last: bool) -> bool:
    return (not first or middle) and (not middle or last)


def weak_conditional(condition: bool, otherwise: bool, consequent: bool) -> bool:
    return (condition or otherwise) and (not condition or consequent)


def binary(table: Sequence[int], first: int, second: int) -> int:
    return table[2 * first + second]


def ordinary_equations(successor, update, recursor) -> bool:
    return all(
        binary(recursor, 0, initial) == initial
        and all(
            binary(recursor, successor[counter], initial)
            == binary(update, binary(recursor, counter, initial), counter)
            for counter in DOMAIN
        )
        for initial in DOMAIN
    )


def endpoint_table(successor, update, recursor) -> bool:
    def witness(initial: int, counter: int, state: int) -> bool:
        return (counter != 0 or state == initial) and all(
            chain(
                probe == counter and value == state,
                binary(recursor, probe, initial) == value,
                probe != successor[counter]
                or value == binary(update, state, counter),
            )
            for probe, value in PAIRS
        )

    return all(
        any(witness(initial, counter, state) for state in DOMAIN)
        for initial, counter in PAIRS
    )


def mixed_table(successor, update, recursor) -> bool:
    def witness(initial: int, counter: int, state: int) -> bool:
        return all(
            chain(
                probe == counter and value == state,
                binary(recursor, probe, initial) == value,
                weak_conditional(
                    probe == successor[counter],
                    probe != 0 or value == initial,
                    value == binary(update, state, counter),
                ),
            )
            for probe, value in PAIRS
        )

    return all(
        any(witness(initial, counter, state) for state in DOMAIN)
        for initial, counter in PAIRS
    )


def old_double_conditional(successor, update, recursor) -> bool:
    """The local W table from the double-conditional source package."""
    def witness(initial: int, counter: int, state: int) -> bool:
        return all(
            weak_conditional(
                binary(recursor, probe, initial) == value,
                counter != 0 or state == initial,
                weak_conditional(
                    probe == counter,
                    probe != successor[counter]
                    or value == binary(update, state, counter),
                    value == state,
                ),
            )
            for probe, value in PAIRS
        )

    return all(
        any(witness(initial, counter, state) for state in DOMAIN)
        for initial, counter in PAIRS
    )


def old_priority_table(successor, update, recursor) -> bool:
    """The local P table from the priority-computation source package."""
    def witness(initial: int, counter: int, state: int) -> bool:
        return all(
            binary(recursor, probe, initial) != value
            or weak_conditional(
                probe == counter,
                weak_conditional(
                    probe == 0,
                    probe != successor[counter]
                    or value == binary(update, state, counter),
                    value == initial,
                ),
                value == state,
            )
            for probe, value in PAIRS
        )

    return all(
        any(witness(initial, counter, state) for state in DOMAIN)
        for initial, counter in PAIRS
    )


def state_free_equations(successor, update, recursor) -> bool:
    return all(
        binary(recursor, 0, initial) == initial
        and all(
            binary(recursor, successor[counter], initial) == update[counter]
            for counter in DOMAIN
        )
        for initial in DOMAIN
    )


def adapted_state_free_table(successor, lifted_update, recursor) -> bool:
    return all(
        chain(
            probe == 0 and value == initial,
            binary(recursor, probe, initial) == value,
            probe == 0 or value == lifted_update[probe],
        )
        for initial, probe, value in product(DOMAIN, repeat=3)
    )


def coverage(successor) -> bool:
    return all(
        value == 0 or any(value == successor[pred] for pred in DOMAIN)
        for value in DOMAIN
    )


def successor_nonzero(successor) -> bool:
    return all(successor[counter] != 0 for counter in DOMAIN)


def rows(table):
    return [list(table[:2]), list(table[2:])]


def run_checks() -> dict:
    endpoint_count = 0
    mixed_count = 0
    endpoint_true_count = 0
    mixed_true_count = 0

    for successor, update, recursor in product(
        UNARY_TABLES, BINARY_TABLES, BINARY_TABLES
    ):
        equations = ordinary_equations(successor, update, recursor)
        endpoint = endpoint_table(successor, update, recursor)
        require(
            endpoint == equations,
            f"T equivalence failed: S={successor}, h={update}, R={recursor}",
        )
        endpoint_count += 1
        endpoint_true_count += int(equations)

        if successor[0] != 0:
            mixed = mixed_table(successor, update, recursor)
            require(
                mixed == equations,
                f"M equivalence failed: S={successor}, h={update}, R={recursor}",
            )
            mixed_count += 1
            mixed_true_count += int(equations)

    require(endpoint_count == 1024, "Incorrect endpoint enumeration size")
    require(mixed_count == 512, "Incorrect separated enumeration size")

    state_free_count = 0
    state_free_true_count = 0
    for successor, update, lifted_update, recursor in product(
        UNARY_TABLES, UNARY_TABLES, UNARY_TABLES, BINARY_TABLES
    ):
        if not (coverage(successor) and successor_nonzero(successor)):
            continue
        if not all(
            lifted_update[successor[counter]] == update[counter]
            for counter in DOMAIN
        ):
            continue
        equations = state_free_equations(successor, update, recursor)
        adapted = adapted_state_free_table(successor, lifted_update, recursor)
        require(
            adapted == equations,
            "A equivalence failed: "
            f"S={successor}, h={update}, g={lifted_update}, R={recursor}",
        )
        state_free_count += 1
        state_free_true_count += int(equations)

    require(state_free_count == 64, "Incorrect state-free enumeration size")
    require(state_free_true_count > 0, "State-free positive cases were vacuous")

    successor = (1, 1)
    update = (0, 1, 0, 1)  # h(v,w) = w.
    recursor = (0, 1, 0, 0)  # R(0,a) = a, R(1,a) = 0.
    countermodel_results = {
        "separation": successor[0] != 0,
        "ordinary_recursion_equations": ordinary_equations(
            successor, update, recursor
        ),
        "new_endpoint_T": endpoint_table(successor, update, recursor),
        "new_mixed_M": mixed_table(successor, update, recursor),
        "old_double_conditional_W": old_double_conditional(
            successor, update, recursor
        ),
        "old_priority_P": old_priority_table(successor, update, recursor),
    }
    expected_results = {
        "separation": True,
        "ordinary_recursion_equations": False,
        "new_endpoint_T": False,
        "new_mixed_M": False,
        "old_double_conditional_W": True,
        "old_priority_P": True,
    }
    require(countermodel_results == expected_results, "Countermodel failed")

    return {
        "status": "passed",
        "scope": (
            "Exhaustive two-element Boolean diagnostics for local modules. "
            "Not a formalization of intuitionistic logic, guarded syntax, "
            "the complete arithmetic reconstruction, or bi-interpretability."
        ),
        "endpoint_T": {
            "assumptions": "No arithmetic assumptions",
            "models_checked": endpoint_count,
            "models_satisfying_both_sides": endpoint_true_count,
        },
        "mixed_M": {
            "assumptions": "0 != S(0)",
            "models_checked": mixed_count,
            "models_satisfying_both_sides": mixed_true_count,
        },
        "state_free_A": {
            "assumptions": "Coverage, S(n) != 0, and g(S(n)) = h(n)",
            "models_checked": state_free_count,
            "models_satisfying_both_sides": state_free_true_count,
            "nonvacuity_note": (
                "These local assumptions do not require successor injectivity. "
                "The tests therefore have genuine finite eligible models."
            ),
        },
        "local_priority_countermodel": {
            "domain": [0, 1],
            "successor": list(successor),
            "update_rows_v_then_w": rows(update),
            "recursor_rows_n_then_a": rows(recursor),
            "results": countermodel_results,
            "limitation": (
                "Refutes equivalence of these local old tables to recursion "
                "under separation alone. It does not refute their complete "
                "source theories, which use additional bootstrap support."
            ),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Also write the JSON result here")
    arguments = parser.parse_args()
    text = json.dumps(run_checks(), indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
