#!/usr/bin/env python3
"""Rerun finite checks and compile the complete mathematical report."""
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
subprocess.run([sys.executable, str(root / "artifacts" / "verify.py")],
               cwd=root, check=True)
engine = shutil.which("pdflatex")
if engine is None:
    raise SystemExit("pdflatex is required to rebuild report.pdf")
build_dir = root / "build"
build_dir.mkdir(exist_ok=True)
for run in range(3):
    log_path = build_dir / f"pdflatex-pass-{run+1}.txt"
    with log_path.open("w") as stream:
        result = subprocess.run(
            [engine, "-halt-on-error", "-interaction=nonstopmode",
             "-file-line-error", "-output-directory", str(build_dir),
             "report.tex"], cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    if result.returncode:
        print(log_path.read_text()[-7000:])
        raise SystemExit(result.returncode)
shutil.copy2(build_dir / "report.pdf", root / "report.pdf")
print(f"Built {root / 'report.pdf'}")
