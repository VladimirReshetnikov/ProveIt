#!/usr/bin/env python3
"""Finite verification of iPRA syntax, counts, and numerical examples.

This is NOT a proof-assistant formalization.  Passing these tests checks finite
bookkeeping and bounded examples, not the infinite bi-interpretability theorem.
The mathematical proofs are in the accompanying report.

Run with Python 3.10 or later; only the standard library is used.
"""

from __future__ import annotations

import argparse
from collections import deque
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json
from pathlib import Path


@dataclass(frozen=True)
class Term:
    op: str
    args: tuple["Term", ...] = ()
    name: str = ""
    descriptor: "Descriptor | None" = None


@dataclass(frozen=True)
class Descriptor:
    body: Term
    parameters: int = 0


def V(name: str) -> Term:
    return Term("var", name=name)


Z = Term("zero")


def S(t: Term) -> Term:
    return Term("successor", (t,))


def R(d: Descriptor, n: Term, a: Term, *parameters: Term) -> Term:
    assert len(parameters) == d.parameters
    return Term("recursor", (n, a, *parameters), descriptor=d)


def iterate_successor(n: int, t: Term) -> Term:
    for _ in range(n):
        t = S(t)
    return t


v, w = V("v"), V("w")
Q_DESC = Descriptor(w)
A_DESC = Descriptor(S(v))
C_DESC = Descriptor(V("c1"), 1)


def Q(n: Term, a: Term) -> Term:
    return R(Q_DESC, n, a)


def A(n: Term, a: Term) -> Term:
    """A(n,a) = a+n, with its two-node frozen descriptor charged."""
    return R(A_DESC, n, a)


def C(n: Term, a: Term, b: Term) -> Term:
    return R(C_DESC, n, a, b)


@lru_cache(maxsize=None)
def size(t: Term) -> int:
    if t.op in {"zero", "var"}:
        return 1
    if t.op == "successor":
        return 1 + size(t.args[0])
    assert t.op == "recursor" and t.descriptor is not None
    return 1 + size(t.descriptor.body) + sum(map(size, t.args))


@lru_cache(maxsize=None)
def prefix(t: Term) -> str:
    if t.op == "zero":
        return "0"
    if t.op == "var":
        return "V(" + t.name + ")"
    if t.op == "successor":
        return "S(" + prefix(t.args[0]) + ")"
    assert t.descriptor is not None
    return "R[" + str(t.descriptor.parameters) + ";" + prefix(
        t.descriptor.body
    ) + "](" + ",".join(map(prefix, t.args)) + ")"


def active_occurrences(t: Term, name: str) -> int:
    """Frozen descriptor slots are never counted as active occurrences."""
    if t.op == "var":
        return int(t.name == name)
    return sum(active_occurrences(a, name) for a in t.args)


def active_substitute(t: Term, replacements: dict[str, Term]) -> Term:
    """Simultaneous substitution into actual arguments, never descriptors."""
    if t.op == "var":
        return replacements.get(t.name, t)
    return Term(
        t.op,
        tuple(active_substitute(a, replacements) for a in t.args),
        t.name,
        t.descriptor,
    )


def instantiate(d: Descriptor, state: Term, counter: Term,
                parameters: tuple[Term, ...]) -> Term:
    assert len(parameters) == d.parameters
    replacements = {"v": state, "w": counter}
    replacements.update({f"c{i + 1}": p for i, p in enumerate(parameters)})
    return active_substitute(d.body, replacements)


def is_rec(t: Term, d: Descriptor) -> bool:
    return t.op == "recursor" and t.descriptor == d


def root_reductions(t: Term, mode: str) -> set[Term]:
    """All root rewrites whose final fully charged tree is strictly smaller.

    old: direct-parameter rules plus the shifted-origin fused first step.
    new: also successor cancellation and autonomous-iteration fusion.
    """
    assert mode in {"old", "new"}
    candidates: set[Term] = set()
    if t.op != "recursor":
        return candidates
    assert t.descriptor is not None
    d = t.descriptor
    n, a, *rest = t.args
    parameters = tuple(rest)
    if n == Z:
        candidates.add(a)
    if n.op == "successor":
        predecessor = n.args[0]
        recursive_value = R(d, predecessor, a, *parameters)
        candidates.add(instantiate(d, recursive_value, predecessor, parameters))
        if predecessor == Z:
            candidates.add(instantiate(d, a, Z, parameters))
    if d == A_DESC and a == Z:
        candidates.add(n)
    if mode == "new":
        if d == Q_DESC and is_rec(n, A_DESC):
            inner_n, inner_a = n.args
            if inner_n.op == "successor":
                candidates.add(A(inner_n.args[0], inner_a))
        if active_occurrences(d.body, "w") == 0 and is_rec(a, d):
            inner_n, inner_a, *inner_parameters = a.args
            if tuple(inner_parameters) == parameters:
                candidates.add(R(d, A(n, inner_n), inner_a, *parameters))
    return {u for u in candidates if size(u) < size(t)}


def one_step(t: Term, mode: str) -> set[Term]:
    results = root_reductions(t, mode)
    for index, argument in enumerate(t.args):
        for replacement in one_step(argument, mode):
            args = t.args[:index] + (replacement,) + t.args[index + 1:]
            results.add(Term(t.op, args, t.name, t.descriptor))
    assert all(size(u) < size(t) for u in results)
    return results


def normalize(t: Term, mode: str, max_states: int = 20000) -> tuple[Term, int]:
    """Exhaust the finite strict-reduction closure; minimum/prefix tie break."""
    seen = {t}
    pending = deque([t])
    while pending:
        current = pending.popleft()
        for reduct in one_step(current, mode):
            if reduct not in seen:
                seen.add(reduct)
                pending.append(reduct)
                if len(seen) > max_states:
                    raise RuntimeError("Finite verification search limit exceeded")
    return min(seen, key=lambda u: (size(u), prefix(u))), len(seen)


def evaluate(t: Term, environment: dict[str, int]) -> int:
    if t.op == "zero":
        return 0
    if t.op == "var":
        return environment[t.name]
    if t.op == "successor":
        return 1 + evaluate(t.args[0], environment)
    assert t.descriptor is not None
    values = tuple(evaluate(a, environment) for a in t.args)
    n, state, *parameters = values
    assert n >= 0
    for counter in range(n):
        local = {"v": state, "w": counter}
        local.update({f"c{i + 1}": p for i, p in enumerate(parameters)})
        state = evaluate(t.descriptor.body, local)
    return state


@dataclass(frozen=True)
class Formula:
    op: str
    arguments: tuple["Formula", ...] = ()
    terms: tuple[Term, ...] = ()
    name: str = ""


def Eq(s: Term, t: Term) -> Formula:
    return Formula("equality", terms=(s, t))


def FVar(name: str) -> Formula:
    return Formula("formula_variable", name=name)


BOTTOM = Formula("bottom")


def connective(op: str, *arguments: Formula) -> Formula:
    return Formula(op, arguments=arguments)


def Forall(name: str, body: Formula) -> Formula:
    return Formula("forall", (body,), name=name)


def Exists(name: str, body: Formula) -> Formula:
    return Formula("exists", (body,), name=name)


def close_forall(names: list[str], body: Formula) -> Formula:
    for name in reversed(names):
        body = Forall(name, body)
    return body


def fsize(formula: Formula) -> int:
    return 1 + sum(map(fsize, formula.arguments)) + sum(map(size, formula.terms))


def expand_k4(formula: Formula) -> Formula:
    arguments = tuple(map(expand_k4, formula.arguments))
    if formula.op == "K4":
        a, p, c, d = arguments
        return connective("and", connective("implies", a, p),
                          connective("implies", p, connective("implies", c, d)))
    return Formula(formula.op, arguments, formula.terms, formula.name)


def ordinary_module(d: Descriptor) -> Formula:
    n, a = V("n"), V("a")
    parameters = tuple(V(f"c{i + 1}") for i in range(d.parameters))
    base = Eq(R(d, Z, a, *parameters), a)
    update = instantiate(d, R(d, n, a, *parameters), n, parameters)
    step = Forall("n", Eq(R(d, S(n), a, *parameters), update))
    return close_forall(["a"] + [p.name for p in parameters],
                       connective("and", base, step))


def module_formula(H: int, parameters: int, state_occurrences: int) -> int:
    return 3 * H + 3 * parameters + 13 + state_occurrences * (H + parameters + 2)


def boundary(equation: Formula, parameters: int) -> Formula:
    x, b, t = V("x"), V("b"), V("t")
    middle = connective("K4", Eq(S(x), b), equation, Eq(x, b), Eq(b, t))
    return close_forall(["t"] + [f"c{i + 1}" for i in range(parameters)],
                       Exists("b", Forall("x", middle)))


def constant_update_image(d: Descriptor, arguments: tuple[Term, ...]) -> Term:
    assert active_occurrences(d.body, "v") == 0
    assert active_occurrences(d.body, "w") == 0
    assert d.parameters >= 1
    assert all(active_occurrences(d.body, f"c{i + 1}") == 1
               for i in range(d.parameters))
    n, a, *parameters = arguments
    update = instantiate(d, Z, Z, tuple(parameters))
    return C(n, a, update)


def check_fixed_and_general_counts() -> dict:
    sep = connective("implies", Eq(Z, S(Z)), BOTTOM)
    cov = Forall("z", Exists("y", connective(
        "or", Eq(V("z"), Z), Eq(V("z"), S(V("y"))))))
    variables = tuple(map(FVar, ["A", "P", "C", "D"]))
    k4_record = connective("definition", connective("K4", *variables),
                           expand_k4(connective("K4", *variables)))
    assert (fsize(sep), fsize(cov), fsize(k4_record)) == (6, 10, 15)
    assert [fsize(ordinary_module(d)) for d in (Q_DESC, A_DESC, C_DESC)] == [16, 23, 19]
    descriptors = [
        Descriptor(Z), Descriptor(v), Q_DESC, A_DESC, C_DESC,
        Descriptor(A(v, v)), Descriptor(A(v, V("c1")), 1),
        Descriptor(A(V("c1"), V("c2")), 2),
        Descriptor(C(v, w, V("c1")), 1),
        Descriptor(S(V("c1")), 3),  # deliberately unused parameter slots
    ]
    for d in descriptors:
        expected = module_formula(size(d.body), d.parameters,
                                  active_occurrences(d.body, "v"))
        assert fsize(ordinary_module(d)) == expected
    boundary_cases = [
        (Eq(V("x"), Z), 0),
        (Eq(S(V("x")), V("t")), 0),
        (Eq(A(V("x"), V("c1")), V("t")), 1),
        (Eq(C(V("x"), V("c1"), V("c2")), V("t")), 2),
    ]
    for equation, parameters in boundary_cases:
        F = fsize(equation)
        assert fsize(boundary(equation, parameters)) == F + parameters + 14
        assert fsize(expand_k4(boundary(equation, parameters))) == 2 * F + parameters + 17
    return {
        "Sep": 6, "Cov": 10, "K4_definition_record": 15,
        "T0_fixed_record": 31, "Q_module": 16, "A_module": 23, "C_module": 19,
        "general_module_formula": "3H+3m+13+k(H+m+2)",
        "boundary_formula": "F+m+14", "expanded_boundary_formula": "2F+m+17",
        "module_samples": len(descriptors), "boundary_samples": len(boundary_cases),
    }


def check_cancellation_family() -> list[dict]:
    rows = []
    for m in range(1, 7):
        h = A(iterate_successor(m, w), v)
        for _ in range(m):
            h = Q(h, Z)
        old, old_states = normalize(h, "old")
        new, new_states = normalize(h, "new")
        assert old == h and size(h) == 4 * m + 5
        assert new == A(w, v) and size(new) == 5
        before = fsize(ordinary_module(Descriptor(h)))
        after = fsize(ordinary_module(Descriptor(new)))
        assert before == 16 * m + 35 and after == 35
        for n, a in product(range(7), range(7)):
            assert evaluate(h, {"w": n, "v": a}) == evaluate(new, {"w": n, "v": a})
        rows.append({"m": m, "old_body": size(h), "new_body": size(new),
                     "old_module": before, "new_module": after,
                     "old_closure_states": old_states, "new_closure_states": new_states})
    return rows


def check_autonomous_family() -> tuple[list[dict], int]:
    rows = []
    numerical_cases = 0
    for j in range(2, 9):
        g = Descriptor(iterate_successor(j, v))
        h = R(g, w, R(g, w, v))
        old, _ = normalize(h, "old")
        new, states = normalize(h, "new")
        assert old == h and size(h) == 2 * j + 7
        assert new == R(g, A(w, w), v) and size(new) == j + 8
        before = fsize(ordinary_module(Descriptor(h)))
        after = fsize(ordinary_module(Descriptor(new)))
        assert before == 8 * j + 43 and after == 4 * j + 47
        rows.append({"j": j, "old_body": size(h), "new_body": size(new),
                     "old_module": before, "new_module": after,
                     "new_closure_states": states})
        lhs = R(g, V("n"), R(g, V("m"), V("a")))
        rhs = R(g, A(V("n"), V("m")), V("a"))
        for n, m, a in product(range(9), range(9), range(6)):
            environment = {"n": n, "m": m, "a": a}
            assert evaluate(lhs, environment) == evaluate(rhs, environment) == a + j * (n + m)
            numerical_cases += 1
    return rows, numerical_cases


def check_constant_update() -> dict:
    d = Descriptor(A(V("c1"), V("c2")), 2)
    assert size(d.body) == 5 and fsize(ordinary_module(d)) == 34
    samples = [Z, S(Z), V("x"), iterate_successor(3, V("x")), A(V("x"), V("y"))]
    substitution_cases = 0
    for arguments in product(samples, repeat=4):
        raw = R(d, *arguments)
        image = constant_update_image(d, arguments)
        assert size(raw) - size(image) == 1
        substitution_cases += 1
    source = R(d, V("n"), V("a"), V("c1"), V("c2"))
    image = constant_update_image(d, source.args)
    assert size(source) == 10 and size(image) == 9
    numerical_cases = 0
    for n, a, c1, c2 in product(range(5), repeat=4):
        env = {"n": n, "a": a, "c1": c1, "c2": c2}
        assert evaluate(source, env) == evaluate(image, env)
        numerical_cases += 1
    substituted = active_substitute(source, {"v": Z, "w": S(Z), "c1": S(Z)})
    assert substituted.descriptor is d
    assert substituted.descriptor.body == A(V("c1"), V("c2"))
    assert substituted.args[2] == S(Z)
    return {"H": 5, "parameter_slots": 2, "ordinary_module": 34,
            "shared_C_module": 19, "source_variable_call": 10,
            "image_variable_call": 9, "saving_per_call": 1,
            "arbitrary_syntax_substitution_cases": substitution_cases,
            "bounded_numerical_cases": numerical_cases,
            "frozen_substitution_check": "passed"}


def check_scan() -> dict:
    tables = probes = invariant_checks = 0
    for target in range(11):
        for bits in product((False, True), repeat=target + 1):
            d = 0
            for n in range(target + 1):
                assert d == 0 or bits[d - 1]
                assert not bits[d] or d == n
                invariant_checks += 2
                if n < target and bits[d]:
                    d = n + 1
            b = d
            for tail_value in (False, True):
                for x in range(target + 3):
                    E = bits[x] if x <= target else tail_value
                    assert x + 1 != b or E
                    assert not E or x != b or b == target
                    probes += 1
            tables += 1
    return {"horizons": "0..10", "boolean_tables": tables,
            "invariant_checks": invariant_checks, "probe_checks": probes,
            "note": "Only bounded examples; outside the displayed probe range both numeric guards are false."}


def check_counter_dependence() -> dict:
    d = Descriptor(S(w))
    lhs = R(d, V("n"), R(d, V("m"), V("a")))
    forbidden_rhs = R(d, A(V("n"), V("m")), V("a"))
    environment = {"n": 2, "m": 3, "a": 0}
    left = evaluate(lhs, environment)
    right = evaluate(forbidden_rhs, environment)
    assert (left, right) == (2, 5)
    assert forbidden_rhs not in root_reductions(lhs, "new")
    # A longer counter-dependent body makes the forbidden fusion strictly
    # smaller.  This checks that rejection really uses counter independence,
    # rather than merely the strict size guard.
    longer = Descriptor(iterate_successor(3, w))
    longer_lhs = R(longer, V("n"), R(longer, V("m"), V("a")))
    longer_rhs = R(longer, A(V("n"), V("m")), V("a"))
    assert size(longer_rhs) < size(longer_lhs)
    assert evaluate(longer_lhs, environment) == 4
    assert evaluate(longer_rhs, environment) == 7
    assert longer_rhs not in root_reductions(longer_lhs, "new")
    return {"update": "S(w)", "n": 2, "m": 3, "a": 0,
            "nested_value": left, "merged_value": right,
            "fusion_rule_rejects_counter_dependent_descriptor": True,
            "strictly_smaller_invalid_fusion": {
                "update": "S(S(S(w)))", "old_size": size(longer_lhs),
                "new_size": size(longer_rhs), "nested_value": 4,
                "merged_value": 7, "rejected": True}}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("verification.json"))
    args = parser.parse_args()
    fixed = check_fixed_and_general_counts()
    cancellation = check_cancellation_family()
    autonomous, fusion_cases = check_autonomous_family()
    constant = check_constant_update()
    scan = check_scan()
    counterexample = check_counter_dependence()
    report = {
        "status": "passed",
        "scope": "Finite syntax/count checks and bounded examples; not a proof-assistant formalization.",
        "fixed_and_general_counts": fixed,
        "successor_cancellation_family": cancellation,
        "autonomous_fusion_family": autonomous,
        "autonomous_fusion_numerical_cases": fusion_cases,
        "constant_update_elimination": constant,
        "bounded_boundary_scan": scan,
        "necessary_counter_independence": counterexample,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("PASS: finite iPRA verification (not a formal proof of the metatheorem)")
    print("Fixed counts: Sep=6, Cov=10, K4=15; T0=31; Q=16, A=23, C=19.")
    print("General ordinary-module and both boundary formulas: all samples pass.")
    print("Cancellation: m=1..6, H=4m+5 -> 5; module=16m+35 -> 35.")
    print("Autonomous fusion: j=2..8, H=2j+7 -> j+8; module=8j+43 -> 4j+47.")
    print(f"Autonomous numerical examples: {fusion_cases}; counter-dependent counterexample: 2 != 5.")
    print("Constant update: H=5, module=34, shared C=19, call=10 -> 9;")
    print(f"  {constant['arbitrary_syntax_substitution_cases']} arbitrary-term substitutions and "
          f"{constant['bounded_numerical_cases']} numerical examples pass.")
    print(f"Boundary scans: {scan['boolean_tables']} Boolean tables, "
          f"{scan['invariant_checks']} invariant checks, {scan['probe_checks']} probe checks.")
    print(f"JSON result: {args.output}")


if __name__ == "__main__":
    main()
