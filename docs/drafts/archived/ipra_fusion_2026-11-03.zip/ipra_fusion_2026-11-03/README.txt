iPRA WITH A MINIMAL RETAINED CORE
Cancellation, iteration fusion, and parameter-only update elimination
3 November 2026

RESULT
The two-symbol construction matches the smallest current bare fixed record:
16 arithmetic nodes, or 31 including the paid K4 definition. It does not
claim a smaller fixed arithmetic core. The native-predecessor companion
matches the 41-node paid constructor core.
The K3-only alternatives have records28 and38, with one extra node per
boundary; they likewise match the current same-interface frontier.

The reduced canonical language adds certified cancellation and autonomous
iteration fusion, and deletes an affine parameter-only class of recursors.
The report proves full intuitionistic bi-interpretability, with both
whole-carrier identity round trips and genuine falsity preserved.

NEW EXACT FAMILIES
With A=R_[S(v)], Q=R_w, p(t)=Q(t,0):
  h_m = p^m(A(S^m(w),v)) -> A(w,v)
  descriptor: 4m+5 -> 5
  complete ordinary module: 16m+35 -> 35

With g_j=S^j(v), j>=2:
  R_gj(w,R_gj(w,v)) -> R_gj(A(w,w),v)
  descriptor: 2j+7 -> j+8
  complete ordinary module: 8j+43 -> 4j+47

These are ordinary-module comparisons, not universal claims about optimized
module selection or proof length. The exact homomorphic source-packet
theorem has its own stated nonincrease guarantee.

CONTENTS
report.pdf / report.tex / sections/  Complete report and LaTeX source
AXIOMS.txt                         Standalone exact specification
artifacts/verify.py                 Standard-library finite checks
artifacts/verification.json         Results from the completed run
provenance/source_manifest.json     All eight reviewed archives, pinned commit
provenance/comparison.csv           Fixed-support ledger
build.py                           Rerun checks and rebuild PDF
SHA256SUMS.txt                      File checksums, excluding this checksum file

REBUILD
python3 build.py
Requires Python 3 and pdflatex with the packages listed in report.tex.
Only the verification checks use Python; no third-party Python module is
required. LaTeX build intermediates go in build/.

LIMITS
Written mathematical proofs plus finite syntax and numerical diagnostics.
No complete Lean/Rocq formalization, no universal shortestness theorem,
and no universal translated-proof-length claim.

SNAPSHOT
VladimirReshetnikov/ProveIt
62494ae438e7518d7d9d3b923b506d2223672cdc
Three current archives and five archived archives were reviewed.
