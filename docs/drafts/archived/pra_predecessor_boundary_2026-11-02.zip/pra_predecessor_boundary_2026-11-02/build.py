#!/usr/bin/env python3
"""Reproduce the checks and compile the accompanying LaTeX research paper."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def run(command: list[str], root: Path, log: Path) -> None:
    result = subprocess.run(command, cwd=root, text=True, capture_output=True)
    log.write_text(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}); see {log}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf-only", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    build = root / "build"
    build.mkdir(exist_ok=True)
    verification = root / "verification"
    if not args.pdf_only:
        for name in ["check_boundary.py", "check_seed_sizes.py"]:
            run([sys.executable, str(verification / name)], root,
                build / f"{Path(name).stem}.txt")
        lean = os.environ.get("PRA_LEAN") or shutil.which("lean")
        if lean:
            for name in ["PredecessorBoundary.lean", "SeedNormalization.lean"]:
                run([lean, str(verification / name)], root,
                    build / f"{Path(name).stem}.txt")
            print("Python checks and both Lean files passed.")
        else:
            print("Python checks passed. Lean absent; compiler rerun skipped.")
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
               "-output-directory=build", "report.tex"]
    for number in range(1, 4):
        run(command, root, build / f"latex_pass_{number}.txt")
    log = (build / "report.log").read_text(errors="replace")
    problems = [line for line in log.splitlines()
                if "Overfull" in line or "undefined references" in line
                or "duplicate ignored" in line]
    if problems:
        raise RuntimeError("PDF layout/reference checks failed: " + "; ".join(problems))
    shutil.copyfile(build / "report.pdf", root / "report.pdf")
    summary = {
        "status": "passed",
        "pdf": "report.pdf",
        "pdf_sha256": hashlib.sha256((root / "report.pdf").read_bytes()).hexdigest(),
        "latex_passes": 3,
        "overfull_boxes": 0,
        "undefined_references": 0,
        "duplicate_hyperlink_destinations": 0,
        "scope": "Compilation and log checks; separate visual review is recorded separately."
    }
    (verification / "pdf_build.json").write_text(json.dumps(summary, indent=2) + "\n")
    shutil.copyfile(build / "latex_pass_3.txt", verification / "pdf_build_log.txt")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
