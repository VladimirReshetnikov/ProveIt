/-
Predecessor boundary certificates for PRA.
Lean 4.19.0, core library only; no Mathlib and no admitted theorems.

Scope: this file checks the constructive logical kernel, a concrete Nat
scan and its invariant, and the Q/Z/chi serialization of the certificate.
It does not formalize first-order syntax, the entire arithmetic bootstrap,
primitive-recursive representability, or the bi-interpretation metatheorem.
The scan is a finite iteration relative to a fixed decidable predicate.
When that predicate is primitive recursive, its displayed recursion is a
primitive-recursive definition; that syntactic fact is explained in the paper.
-/

namespace PredecessorBoundary

def StrongIf (condition whenTrue whenFalse : Prop) : Prop :=
  (condition ∧ whenTrue) ∨ (¬condition ∧ whenFalse)

def Certificate {α : Type} (S : α → α) (P : α → Prop) (b n : α) : Prop :=
  (P b → b = n) ∧ ∀ x, S x = b → P x

def ConditionalMatrix {α : Type} (S : α → α) (P : α → Prop)
    (b n : α) : Prop :=
  ∀ x, StrongIf (P x) (x = b → b = n) (S x ≠ b)

theorem conditional_to_certificate {α : Type} {S : α → α}
    {P : α → Prop} {b n : α}
    (matrix : ConditionalMatrix S P b n) : Certificate S P b n := by
  constructor
  · intro predicateAtWitness
    rcases matrix b with positive | negative
    · exact positive.2 rfl
    · exact False.elim (negative.1 predicateAtWitness)
  · intro x predecessor
    rcases matrix x with positive | negative
    · exact positive.1
    · exact False.elim (negative.2 predecessor)

theorem certificate_to_conditional {α : Type} {S : α → α}
    {P : α → Prop} [DecidablePred P] {b n : α}
    (certificate : Certificate S P b n) : ConditionalMatrix S P b n := by
  intro x
  by_cases predicateAtX : P x
  · apply Or.inl
    refine ⟨predicateAtX, ?_⟩
    intro atWitness
    subst x
    exact certificate.1 predicateAtX
  · apply Or.inr
    refine ⟨predicateAtX, ?_⟩
    intro predecessor
    exact predicateAtX (certificate.2 x predecessor)

theorem conditional_iff_certificate {α : Type} {S : α → α}
    {P : α → Prop} [DecidablePred P] {b n : α} :
    ConditionalMatrix S P b n ↔ Certificate S P b n :=
  ⟨conditional_to_certificate, certificate_to_conditional⟩

theorem induction_of_certificates {α : Type} {zero : α} {S : α → α}
    {P : α → Prop}
    (coverage : ∀ b, b = zero ∨ ∃ x, S x = b)
    (boundary : ∀ n, ∃ b, Certificate S P b n)
    (base : P zero) (progress : ∀ x, P x → P (S x)) : ∀ n, P n := by
  intro n
  obtain ⟨b, certificate⟩ := boundary n
  have predicateAtWitness : P b := by
    rcases coverage b with atZero | ⟨x, predecessor⟩
    · exact atZero.symm ▸ base
    · exact predecessor ▸ progress x (certificate.2 x predecessor)
  exact certificate.1 predicateAtWitness ▸ predicateAtWitness

theorem induction_of_conditional {α : Type} {zero : α} {S : α → α}
    {P : α → Prop}
    (coverage : ∀ b, b = zero ∨ ∃ x, S x = b)
    (boundary : ∀ n, ∃ b, ConditionalMatrix S P b n)
    (base : P zero) (progress : ∀ x, P x → P (S x)) : ∀ n, P n := by
  apply induction_of_certificates coverage _ base progress
  intro n
  obtain ⟨b, matrix⟩ := boundary n
  exact ⟨b, conditional_to_certificate matrix⟩

/- The assumptions base and progress are explicit hypotheses, so the
   preceding theorem verifies the full induction implication, not only
   an inference from already closed theorems. No decidability is needed
   in either forward induction theorem. -/

def scan (P : Nat → Prop) [DecidablePred P] : Nat → Nat
  | 0 => 0
  | k + 1 => if P (scan P k) then k + 1 else scan P k

def ScanInvariant (P : Nat → Prop) [DecidablePred P] (k : Nat) : Prop :=
  (P (scan P k) → scan P k = k) ∧
  (scan P k = 0 ∨
    (scan P k = Nat.succ (Nat.pred (scan P k)) ∧
      P (Nat.pred (scan P k))))

theorem scan_invariant (P : Nat → Prop) [DecidablePred P] :
    ∀ k, ScanInvariant P k := by
  intro k
  induction k with
  | zero =>
      exact ⟨fun _ => rfl, Or.inl rfl⟩
  | succ k previous =>
      change (P (scan P (k + 1)) → scan P (k + 1) = k + 1) ∧ _
      by_cases predicateAtOld : P (scan P k)
      · have oldIsCounter : scan P k = k := previous.1 predicateAtOld
        have predicateAtCounter : P k := oldIsCounter ▸ predicateAtOld
        have next : scan P (k + 1) = k + 1 := if_pos predicateAtOld
        rw [next]
        exact ⟨fun _ => rfl, Or.inr ⟨rfl, predicateAtCounter⟩⟩
      · have next : scan P (k + 1) = scan P k := if_neg predicateAtOld
        rw [next]
        exact ⟨fun impossible => False.elim (predicateAtOld impossible), previous.2⟩

theorem scan_certificate (P : Nat → Prop) [DecidablePred P] (n : Nat) :
    Certificate Nat.succ P (scan P n) n := by
  have invariant := scan_invariant P n
  refine ⟨invariant.1, ?_⟩
  intro x predecessor
  rcases invariant.2 with atZero | ⟨isSuccessor, predecessorTrue⟩
  · exact False.elim (Nat.noConfusion (predecessor.trans atZero))
  · have samePredecessor : x = Nat.pred (scan P n) :=
      Nat.succ.inj (predecessor.trans isSuccessor)
    exact samePredecessor.symm ▸ predecessorTrue

theorem scan_conditional (P : Nat → Prop) [DecidablePred P] (n : Nat) :
    ConditionalMatrix Nat.succ P (scan P n) n :=
  certificate_to_conditional (scan_certificate P n)

/- The following algebra records precisely the already-paid numerical
   background used by the raw term serializer. It does not include an
   induction hypothesis or a no-successor-fixed-point assumption. -/

structure NumericalAlgebra (α : Type) where
  zero : α
  S : α → α
  Q : α → α → α
  Z : α → α → α
  chi : α → α → α
  separation : zero ≠ S zero
  successor_nonzero : ∀ x, S x ≠ zero
  coverage : ∀ b, b = zero ∨ ∃ x, S x = b
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ x a, Q (S x) a = x
  z_zero : ∀ a, Z zero a = a
  z_succ : ∀ x a, Z (S x) a = zero
  bit_range : ∀ x y, chi x y = zero ∨ chi x y = S zero
  bit_one : ∀ x y, chi x y = S zero ↔ x = y

theorem zero_test_of_nonzero {α : Type} (A : NumericalAlgebra α)
    {r : α} (nonzero : r ≠ A.zero) (a : α) : A.Z r a = A.zero := by
  rcases A.coverage r with atZero | ⟨x, isSuccessor⟩
  · exact False.elim (nonzero atZero)
  · rw [← isSuccessor, A.z_succ]

theorem bit_reflexive {α : Type} (A : NumericalAlgebra α) (x : α) :
    A.chi x x = A.S A.zero :=
  (A.bit_one x x).2 rfl

theorem bit_zero_of_distinct {α : Type} (A : NumericalAlgebra α)
    {x y : α} (distinct : x ≠ y) : A.chi x y = A.zero := by
  rcases A.bit_range x y with isZero | isOne
  · exact isZero
  · exact False.elim (distinct ((A.bit_one x y).1 isOne))

def RawMatrix {α : Type} (A : NumericalAlgebra α)
    (t : α → α) (b n : α) : Prop :=
  ∀ x,
    A.Q (A.Z (t x) (A.S (A.chi (A.S x) b)))
      (A.Q (A.chi b n) (A.chi x b)) = A.zero

theorem raw_to_certificate {α : Type} (A : NumericalAlgebra α)
    {t : α → α} {b n : α} (raw : RawMatrix A t b n) :
    Certificate A.S (fun x => t x ≠ A.zero) b n := by
  constructor
  · intro trueAtWitness
    have atWitness := raw b
    rw [zero_test_of_nonzero A trueAtWitness, A.q_zero,
      bit_reflexive A b] at atWitness
    rcases A.bit_range b n with isZero | isOne
    · rw [isZero, A.q_zero] at atWitness
      exact False.elim (A.separation atWitness.symm)
    · exact (A.bit_one b n).1 isOne
  · intro x predecessor falseAtX
    have atX := raw x
    rw [falseAtX, A.z_zero, A.q_succ, predecessor,
      bit_reflexive A b] at atX
    exact A.separation atX.symm

theorem certificate_to_raw {α : Type} (A : NumericalAlgebra α)
    {t : α → α} {b n : α}
    (certificate : Certificate A.S (fun x => t x ≠ A.zero) b n) :
    RawMatrix A t b n := by
  intro x
  rcases A.coverage (t x) with falseAtX | ⟨r, successorValue⟩
  · rw [falseAtX, A.z_zero, A.q_succ]
    apply bit_zero_of_distinct A
    intro predecessor
    exact certificate.2 x predecessor falseAtX
  · have trueAtX : t x ≠ A.zero := by
      intro isZero
      exact A.successor_nonzero r (successorValue.trans isZero)
    rw [zero_test_of_nonzero A trueAtX, A.q_zero]
    rcases A.bit_range b n with isZero | isOne
    · rw [isZero, A.q_zero]
      apply bit_zero_of_distinct A
      intro atWitness
      have trueAtWitness : t b ≠ A.zero := atWitness ▸ trueAtX
      have witnessIsTarget := certificate.1 trueAtWitness
      have diagonal : A.chi b n = A.S A.zero :=
        (A.bit_one b n).2 witnessIsTarget
      exact A.separation (isZero.symm.trans diagonal)
    · rw [isOne, A.q_succ]

theorem raw_iff_certificate {α : Type} (A : NumericalAlgebra α)
    {t : α → α} {b n : α} :
    RawMatrix A t b n ↔ Certificate A.S (fun x => t x ≠ A.zero) b n :=
  ⟨raw_to_certificate A, certificate_to_raw A⟩

theorem induction_of_raw {α : Type} (A : NumericalAlgebra α)
    {t : α → α}
    (boundary : ∀ n, ∃ b, RawMatrix A t b n)
    (base : t A.zero ≠ A.zero)
    (progress : ∀ x, t x ≠ A.zero → t (A.S x) ≠ A.zero) :
    ∀ n, t n ≠ A.zero := by
  apply induction_of_certificates (P := fun x => t x ≠ A.zero)
    A.coverage _ base progress
  intro n
  obtain ⟨b, raw⟩ := boundary n
  exact ⟨b, raw_to_certificate A raw⟩

def naturalQ : Nat → Nat → Nat
  | 0, a => a
  | x + 1, _ => x

def naturalZ : Nat → Nat → Nat
  | 0, a => a
  | _ + 1, _ => 0

def naturalBit (x y : Nat) : Nat := if x = y then 1 else 0

def naturalAlgebra : NumericalAlgebra Nat where
  zero := 0
  S := Nat.succ
  Q := naturalQ
  Z := naturalZ
  chi := naturalBit
  separation := Nat.zero_ne_one
  successor_nonzero := Nat.succ_ne_zero
  coverage := by
    intro n
    cases n with
    | zero => exact Or.inl rfl
    | succ k => exact Or.inr ⟨k, rfl⟩
  q_zero := fun _ => rfl
  q_succ := fun _ _ => rfl
  z_zero := fun _ => rfl
  z_succ := fun _ _ => rfl
  bit_range := by
    intro x y
    by_cases same : x = y
    · exact Or.inr (if_pos same)
    · exact Or.inl (if_neg same)
  bit_one := by
    intro x y
    constructor
    · intro one
      by_cases same : x = y
      · exact same
      · have zero : naturalBit x y = 0 := if_neg same
        exact False.elim (Nat.zero_ne_one (zero.symm.trans one))
    · intro same
      exact if_pos same

theorem raw_scan_witness (t : Nat → Nat) (n : Nat) :
    RawMatrix naturalAlgebra t (scan (fun x => t x ≠ 0) n) n := by
  exact certificate_to_raw naturalAlgebra (scan_certificate (fun x => t x ≠ 0) n)

theorem natural_raw_boundary (t : Nat → Nat) :
    ∀ n, ∃ b, RawMatrix naturalAlgebra t b n := by
  intro n
  exact ⟨scan (fun x => t x ≠ 0) n, raw_scan_witness t n⟩

#print axioms conditional_to_certificate
#print axioms conditional_iff_certificate
#print axioms induction_of_certificates
#print axioms induction_of_conditional
#print axioms scan_invariant
#print axioms scan_certificate
#print axioms scan_conditional
#print axioms raw_iff_certificate
#print axioms induction_of_raw
#print axioms raw_scan_witness
#print axioms natural_raw_boundary

end PredecessorBoundary
