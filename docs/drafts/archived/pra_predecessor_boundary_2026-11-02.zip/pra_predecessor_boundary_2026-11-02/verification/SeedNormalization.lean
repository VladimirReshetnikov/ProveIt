/-
Lean 4.19.0, core library only.

Checks the new small fixed seed and its normalization instance:
  Off  : forall x y, x = y or chi x y = 0;
  Part : forall x, exists y, chi x 0 != chi x (S y).

Off + Part give coverage and positive diagonals. Together with the
Q recursion equations they imply separation and successor nonzeroness.
The single raw-boundary instance with the parameter-only term t(x,a)=a,
specialized to a=S(0), normalizes every diagonal to S(0).

This checks the local algebraic bootstrap. It is not a formalization of
the complete first-order bi-interpretation metatheorem or its syntax.
-/

namespace SeedNormalization

structure Seed (α : Type) where
  zero : α
  S : α → α
  Q : α → α → α
  Z : α → α → α
  chi : α → α → α
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ x a, Q (S x) a = x
  z_zero : ∀ a, Z zero a = a
  z_succ : ∀ x a, Z (S x) a = zero
  off : ∀ x y, x = y ∨ chi x y = zero
  part : ∀ x, ∃ y, chi x zero ≠ chi x (S y)

theorem coverage {α : Type} (A : Seed α) (x : α) :
    x = A.zero ∨ ∃ y, A.S y = x := by
  obtain ⟨y, different⟩ := A.part x
  rcases A.off x A.zero with atZero | firstZero
  · exact Or.inl atZero
  · rcases A.off x (A.S y) with isSuccessor | secondZero
    · exact Or.inr ⟨y, isSuccessor.symm⟩
    · exact False.elim (different (firstZero.trans secondZero.symm))

theorem diagonal_positive {α : Type} (A : Seed α) (x : α) :
    A.chi x x ≠ A.zero := by
  intro diagonalZero
  have entireRowZero : ∀ y, A.chi x y = A.zero := by
    intro y
    rcases A.off x y with same | offDiagonal
    · exact same ▸ diagonalZero
    · exact offDiagonal
  obtain ⟨y, different⟩ := A.part x
  exact different ((entireRowZero A.zero).trans (entireRowZero (A.S y)).symm)

theorem equality_iff_positive {α : Type} (A : Seed α) (x y : α) :
    x = y ↔ A.chi x y ≠ A.zero := by
  constructor
  · intro same
    exact same ▸ diagonal_positive A x
  · intro positive
    rcases A.off x y with same | offDiagonal
    · exact same
    · exact False.elim (positive offDiagonal)

theorem separation {α : Type} (A : Seed α) : A.zero ≠ A.S A.zero := by
  intro zeroIsSuccessor
  have collapse : ∀ a, a = A.zero := by
    intro a
    calc
      a = A.Q A.zero a := (A.q_zero a).symm
      _ = A.Q (A.S A.zero) a :=
        congrArg (fun r => A.Q r a) zeroIsSuccessor
      _ = A.zero := A.q_succ A.zero a
  exact diagonal_positive A A.zero (collapse (A.chi A.zero A.zero))

theorem successor_nonzero {α : Type} (A : Seed α) (x : α) :
    A.S x ≠ A.zero := by
  intro successorIsZero
  have predecessorIsZero : x = A.zero := by
    calc
      x = A.Q (A.S x) A.zero := (A.q_succ x A.zero).symm
      _ = A.Q A.zero A.zero :=
        congrArg (fun r => A.Q r A.zero) successorIsZero
      _ = A.zero := A.q_zero A.zero
  have zeroSuccessorIsZero : A.S A.zero = A.zero :=
    (congrArg A.S predecessorIsZero).symm.trans successorIsZero
  exact separation A zeroSuccessorIsZero.symm

theorem successor_injective {α : Type} (A : Seed α) :
    ∀ {x y}, A.S x = A.S y → x = y := by
  intro x y sameSuccessors
  calc
    x = A.Q (A.S x) A.zero := (A.q_succ x A.zero).symm
    _ = A.Q (A.S y) A.zero :=
      congrArg (fun r => A.Q r A.zero) sameSuccessors
    _ = y := A.q_succ y A.zero

theorem zero_test_of_nonzero {α : Type} (A : Seed α)
    {r : α} (nonzero : r ≠ A.zero) (a : α) : A.Z r a = A.zero := by
  rcases coverage A r with atZero | ⟨x, isSuccessor⟩
  · exact False.elim (nonzero atZero)
  · rw [← isSuccessor, A.z_succ]

def NormalizationInstance {α : Type} (A : Seed α) : Prop :=
  ∀ n, ∃ b, ∀ x, A.Q (A.chi b n) (A.chi x b) = A.zero

theorem diagonal_one_of_normalization {α : Type} (A : Seed α)
    (normalization : NormalizationInstance A) (n : α) :
    A.chi n n = A.S A.zero := by
  obtain ⟨b, matrix⟩ := normalization n
  have atWitness := matrix b
  have witnessIsTarget : b = n := by
    rcases A.off b n with same | offDiagonal
    · exact same
    · rw [offDiagonal, A.q_zero] at atWitness
      exact False.elim (diagonal_positive A b atWitness)
  have selfZero : A.Q (A.chi n n) (A.chi n n) = A.zero :=
    witnessIsTarget ▸ atWitness
  rcases coverage A (A.chi n n) with diagonalZero | ⟨r, successorDiagonal⟩
  · exact False.elim (diagonal_positive A n diagonalZero)
  · have predecessorZero : r = A.zero := by
      calc
        r = A.Q (A.S r) (A.chi n n) := (A.q_succ r (A.chi n n)).symm
        _ = A.Q (A.chi n n) (A.chi n n) :=
          congrArg (fun u => A.Q u (A.chi n n)) successorDiagonal
        _ = A.zero := selfZero
    exact successorDiagonal.symm.trans (congrArg A.S predecessorZero)

def RawMatrix {α : Type} (A : Seed α) (t : α → α) (b n : α) : Prop :=
  ∀ x,
    A.Q (A.Z (t x) (A.S (A.chi (A.S x) b)))
      (A.Q (A.chi b n) (A.chi x b)) = A.zero

theorem constant_one_raw_gives_normalization {α : Type} (A : Seed α)
    (constantOneBoundary :
      ∀ n, ∃ b, RawMatrix A (fun _ => A.S A.zero) b n) :
    NormalizationInstance A := by
  intro n
  obtain ⟨b, raw⟩ := constantOneBoundary n
  refine ⟨b, ?_⟩
  intro x
  have atX := raw x
  change A.Q (A.Z (A.S A.zero) (A.S (A.chi (A.S x) b)))
    (A.Q (A.chi b n) (A.chi x b)) = A.zero at atX
  rw [A.z_succ, A.q_zero] at atX
  exact atX

theorem constant_one_raw_normalizes_diagonal {α : Type} (A : Seed α)
    (constantOneBoundary :
      ∀ n, ∃ b, RawMatrix A (fun _ => A.S A.zero) b n) :
    ∀ n, A.chi n n = A.S A.zero :=
  diagonal_one_of_normalization A
    (constant_one_raw_gives_normalization A constantOneBoundary)

/- A universal parameter-only instance must be retained by any exporter
   using this bootstrap. Omitting every term with no active x occurrence
   would remove the instance needed by the next theorem. -/
theorem parameter_only_instance_normalizes {α : Type} (A : Seed α)
    (parameterOnlyBoundary : ∀ a n, ∃ b, RawMatrix A (fun _ => a) b n) :
    ∀ n, A.chi n n = A.S A.zero :=
  constant_one_raw_normalizes_diagonal A (parameterOnlyBoundary (A.S A.zero))

theorem exact_bit_range {α : Type} (A : Seed α)
    (normalization : NormalizationInstance A) (x y : α) :
    A.chi x y = A.zero ∨ A.chi x y = A.S A.zero := by
  rcases A.off x y with same | offDiagonal
  · exact Or.inr (same ▸ diagonal_one_of_normalization A normalization x)
  · exact Or.inl offDiagonal

theorem exact_bit_one_iff {α : Type} (A : Seed α)
    (normalization : NormalizationInstance A) (x y : α) :
    A.chi x y = A.S A.zero ↔ x = y := by
  constructor
  · intro isOne
    rcases A.off x y with same | offDiagonal
    · exact same
    · exact False.elim (separation A (offDiagonal.symm.trans isOne))
  · intro same
    exact same ▸ diagonal_one_of_normalization A normalization x

#print axioms coverage
#print axioms diagonal_positive
#print axioms equality_iff_positive
#print axioms separation
#print axioms successor_nonzero
#print axioms successor_injective
#print axioms zero_test_of_nonzero
#print axioms diagonal_one_of_normalization
#print axioms constant_one_raw_gives_normalization
#print axioms constant_one_raw_normalizes_diagonal
#print axioms parameter_only_instance_normalizes
#print axioms exact_bit_range
#print axioms exact_bit_one_iff

end SeedNormalization
