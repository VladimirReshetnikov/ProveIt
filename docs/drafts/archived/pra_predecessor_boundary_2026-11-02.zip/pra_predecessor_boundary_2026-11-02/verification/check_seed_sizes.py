#!/usr/bin/env python3
"""Check the improved fixed supports without repeating the kernel tests.

The earlier check_boundary.py/results.json pair records the transparent
34-node support on which the first independent kernel audit was run.
None of its formula counts or semantic tests depends on paying 34 rather
than 30 nodes: the 30-node seed derives that transparent background.
This supplementary result gives the authoritative final fixed supports.

The 23-node seed belongs to the uniform unsaturated theory.  It must
retain the t(x,a)=a predecessor-boundary instance (24 full nodes), whose
use derives the diagonal normalization.  It is not the seed assigned to
the optimized emitter, which uses the saturated 30-node support.
"""

from hashlib import sha256
import json
from pathlib import Path

from check_boundary import (
    FALSE, ONE, ZERO, a, chi, conjunction, disjunction, eq, exists,
    forall, implies, predecessor_raw, succ, x,
)


def main() -> None:
    separation = implies(eq(ZERO, ONE), FALSE)
    off = forall((x, a), disjunction(eq(x, a), eq(chi(x, a), ZERO)))
    bit = forall((x, a), conjunction(
        eq(chi(x, x), ONE),
        disjunction(eq(x, a), eq(chi(x, a), ZERO))))
    coverage = forall((x,), disjunction(
        eq(x, ZERO), exists((a,), eq(x, succ(a)))))
    part = forall((x,), exists((a,), implies(
        eq(chi(x, ZERO), chi(x, succ(a))), FALSE)))

    formulas = {
        "separation": separation,
        "off_diagonal": off,
        "exact_bit": bit,
        "coverage": coverage,
        "partition": part,
        "uniform_normalization_instance_t_equals_a": predecessor_raw(a),
    }
    counts = {name: {"full": node.size(), "active": node.size(False)}
              for name, node in formulas.items()}
    assert {name: count["full"] for name, count in counts.items()} == {
        "separation": 6,
        "off_diagonal": 11,
        "exact_bit": 18,
        "coverage": 10,
        "partition": 12,
        "uniform_normalization_instance_t_equals_a": 24,
    }

    def total(*names: str) -> int:
        return sum(counts[name]["full"] for name in names)

    primary = total("exact_bit", "partition")
    transparent = total("separation", "exact_bit", "coverage")
    uniform = total("off_diagonal", "partition")
    assert (primary, transparent, uniform) == (30, 34, 23)

    here = Path(__file__).resolve().parent
    retained = json.loads((here / "results.json").read_text())
    retained_checker = here / "check_boundary.py"
    assert retained["script_sha256"] == sha256(retained_checker.read_bytes()).hexdigest()
    result = {
        "status": "passed",
        "script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "formula_counts": counts,
        "recommended_saturated_seed": {
            "axioms": ["exact_bit", "partition"], "full_nodes": primary,
            "used_by": "The uniform saturated presentation and optimized emitter.",
            "derives": ["separation", "coverage"],
        },
        "transparent_seed": {
            "axioms": ["separation", "exact_bit", "coverage"],
            "full_nodes": transparent,
            "role": "Equivalent transparent support retained in the original "
                    "independent kernel verification.",
        },
        "optional_uniform_unsaturated_seed": {
            "axioms": ["off_diagonal", "partition"],
            "full_nodes": uniform,
            "required_retained_schema_instance": "t(x,a)=a",
            "normalization_instance_full_nodes": 24,
            "fixed_seed_plus_normalization_support": 47,
            "restriction": "Do not assign this seed to the minimum-size emitter "
                           "or omit its input-independent normalization instance.",
        },
        "partition_formula": "forall x exists y: "
                             "(chi(x,0)=chi(x,S(y))) -> false",
        "retained_kernel_results": {
            "file": "results.json",
            "sha256": sha256((here / "results.json").read_bytes()).hexdigest(),
            "checker_sha256": retained["script_sha256"],
            "status": retained["status"],
            "relationship": "Unchanged kernel checks use the transparent 34-node "
                            "support. Their local cost and semantic conclusions "
                            "remain valid after deriving that support from the "
                            "new saturated 30-node seed. The millions of kernel "
                            "checks were not rerun for this support-only update.",
        },
        "scope": "Exact AST counts only. The derivations of separation, coverage, "
                 "and optional diagonal normalization are proved in the paper. "
                 "This script does not claim a proof-assistant formalization.",
    }
    target = here / "seed_sizes.json"
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "primary": primary,
                      "transparent": transparent, "optional_uniform": uniform,
                      "normalization_instance": 24, "result": str(target)}, indent=2))


if __name__ == "__main__":
    main()
