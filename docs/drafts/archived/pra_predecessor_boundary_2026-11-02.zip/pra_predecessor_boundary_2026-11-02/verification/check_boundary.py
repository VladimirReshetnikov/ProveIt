#!/usr/bin/env python3
"""Independent syntax and finite semantic checks for predecessor boundary PRA.

This is a regression verifier, not a formalization of PRA or of the
bi-interpretation theorem.  In particular, no finite carrier below is
represented as a model of all the arithmetic axioms: finite nontrivial
models cannot have injective successor whose image omits zero.

The finite-carrier checks evaluate the exact displayed formula in local
algebras whose 0/1/2 case operations are fixed.  Successor on the other
elements is arbitrary, including noninjective maps and fixed points.
These checks test the asserted local Boolean equivalence and expose any
unmentioned dependence on successor having no fixed points.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from hashlib import sha256
from itertools import product
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    args: tuple["Node", ...] = ()
    descriptor: "Node | None" = None

    def size(self, full: bool = True) -> int:
        return (1 + sum(arg.size(full) for arg in self.args)
                + (self.descriptor.size(True)
                   if full and self.descriptor is not None else 0))


def var(name: str) -> Node:
    return Node("var:" + name)


ZERO = Node("0")
FALSE = Node("false")
x, a, n, b, c, u, v, w = map(var, "x a n b c u v w".split())


def fun(name: str, *args: Node) -> Node:
    return Node(name, tuple(args))


def succ(t: Node) -> Node:
    return fun("S", t)


ONE = succ(ZERO)


def rec(h: Node, counter: Node, initial: Node) -> Node:
    return Node("R", (counter, initial), h)


def q(k: Node, initial: Node) -> Node:
    return rec(w, k, initial)


def z(k: Node, initial: Node) -> Node:
    return rec(ZERO, k, initial)


def chi(left: Node, right: Node) -> Node:
    return fun("chi", left, right)


def eq(left: Node, right: Node) -> Node:
    return fun("=", left, right)


def conjunction(left: Node, right: Node) -> Node:
    return fun("and", left, right)


def disjunction(left: Node, right: Node) -> Node:
    return fun("or", left, right)


def implies(left: Node, right: Node) -> Node:
    return fun("implies", left, right)


def forall(names: tuple[Node, ...], matrix: Node) -> Node:
    for name in reversed(names):
        matrix = Node("forall:" + name.tag, (matrix,))
    return matrix


def exists(names: tuple[Node, ...], matrix: Node) -> Node:
    for name in reversed(names):
        matrix = Node("exists:" + name.tag, (matrix,))
    return matrix


def substitute(term: Node, source: Node, replacement: Node) -> Node:
    """Substitute in active slots only; never enter frozen descriptions."""
    if term == source:
        return replacement
    return Node(term.tag,
                tuple(substitute(arg, source, replacement)
                      for arg in term.args),
                term.descriptor)


def active_occurrences(term: Node, variable: Node) -> int:
    return int(term == variable) + sum(
        active_occurrences(arg, variable) for arg in term.args)


def at(term: Node, point: Node) -> Node:
    return substitute(term, x, point)


def predecessor_raw(term: Node) -> Node:
    matrix = eq(q(z(term, succ(chi(succ(x), b))),
                  q(chi(b, n), chi(x, b))), ZERO)
    return forall((a, n), exists((b,), forall((x,), matrix)))


def direct_raw(term: Node) -> Node:
    matrix = conjunction(eq(z(at(term, b), b), ZERO),
                         disjunction(eq(at(term, succ(b)), ZERO), eq(b, n)))
    return forall((a, n), exists((b,), matrix))


def covered_raw(term: Node) -> Node:
    matrix = conjunction(eq(c, q(z(at(term, b), b), n)),
                         eq(z(at(term, c), c), ZERO))
    return forall((a, n), exists((b, c), matrix))


def shared_direct_raw(term: Node) -> Node:
    matrix = conjunction(eq(c, succ(b)), conjunction(
        eq(z(at(term, b), b), ZERO),
        disjunction(eq(at(term, c), ZERO), eq(b, n))))
    return forall((a, n), exists((b, c), matrix))


def boolean_boundary(term: Node) -> Node:
    matrix = eq(q(at(term, succ(b)), at(term, b)),
                q(at(term, n), at(term, ZERO)))
    return forall((a, n), exists((b,), matrix))


def forward_single_copy(term: Node) -> Node:
    first = q(chi(b, ZERO), chi(x, b))
    second = q(chi(b, n), chi(x, succ(b)))
    matrix = eq(q(z(term, succ(first)), second), ZERO)
    return forall((a, n), exists((b,), forall((x,), matrix)))


def backward_conditional(predicate: Node) -> Node:
    positive = implies(eq(x, b), eq(b, n))
    negative = implies(eq(succ(x), b), FALSE)
    matrix = fun("StrongIf", predicate, positive, negative)
    return forall((a, n), exists((b,), forall((x,), matrix)))


def forward_conditional(predicate: Node) -> Node:
    positive = implies(eq(x, succ(b)), eq(b, n))
    negative = implies(eq(x, b), eq(b, ZERO))
    matrix = fun("StrongIf", predicate, positive, negative)
    return forall((a, n), exists((b,), forall((x,), matrix)))


def boolean_grammar(term: Node) -> bool:
    if term in (ZERO, ONE) or term.tag == "chi":
        return True
    return (term.tag == "R" and term.descriptor == w
            and len(term.args) == 2
            and all(boolean_grammar(arg) for arg in term.args))


def syntax_checks() -> dict:
    h = q(succ(v), chi(w, ZERO))
    nested = rec(rec(h, v, w), x, z(a, x))
    samples = {
        "variable_input": x,
        "parameter_only": a,
        "successor_input": succ(x),
        "native_bit": chi(x, a),
        "recursor_w": q(x, a),
        "frozen_nontrivial_body": rec(h, x, a),
        "nested_frozen_descriptions": nested,
        "boolean_zero": ZERO,
        "boolean_one": ONE,
        "boolean_nested": q(chi(rec(h, x, a), ZERO), ONE),
    }
    rows = []
    expected_full = {
        "predecessor_raw": lambda T, i: T + 23,
        "direct_raw": lambda T, i: 2 * T + i + 15,
        "covered_raw": lambda T, i: 2 * T + 18,
        "shared_direct_raw": lambda T, i: 2 * T + 21,
        "boolean_boundary": lambda T, i: 4 * T + i + 8,
        "forward_single_copy": lambda T, i: T + 28,
    }
    expected_active = {
        "predecessor_raw": lambda m, i: m + 20,
        "direct_raw": lambda m, i: 2 * m + i + 14,
        "covered_raw": lambda m, i: 2 * m + 15,
        "shared_direct_raw": lambda m, i: 2 * m + 20,
        "boolean_boundary": lambda m, i: 4 * m + i + 6,
        "forward_single_copy": lambda m, i: m + 24,
    }
    constructors = (predecessor_raw, direct_raw, covered_raw,
                    shared_direct_raw, boolean_boundary, forward_single_copy)
    for name, term in samples.items():
        T, m = term.size(), term.size(False)
        i = active_occurrences(term, x)
        counts = {}
        for constructor in constructors:
            formula = constructor(term)
            actual = {"full": formula.size(), "active": formula.size(False)}
            assert actual["full"] == expected_full[constructor.__name__](T, i)
            assert actual["active"] == expected_active[constructor.__name__](m, i)
            counts[constructor.__name__] = actual
        predicate = eq(term, a)
        F = predicate.size()
        assert backward_conditional(predicate).size() == F + 18
        assert forward_conditional(predicate).size() == F + 20
        assert substitute(term, x, succ(b)).size() == T + i
        assert substitute(term, x, b).size() == T
        rows.append({"name": name, "T": T, "m": m, "i": i,
                     "boolean_grammar": boolean_grammar(term),
                     "counts": counts})

    # A substitution into an active w deliberately leaves a nested w
    # description untouched.  This checks the freezing rule directly.
    frozen = rec(q(v, w), w, ZERO)
    changed = substitute(frozen, w, succ(w))
    assert changed.descriptor == frozen.descriptor
    assert changed.args[0] == succ(w)
    assert changed.size() == frozen.size() + 1

    sep = implies(eq(ZERO, ONE), FALSE)
    bit = forall((x, a), conjunction(eq(chi(x, x), ONE),
        disjunction(eq(x, a), eq(chi(x, a), ZERO))))
    coverage = forall((x,), disjunction(eq(x, ZERO),
        exists((a,), eq(x, succ(a)))))
    seed = {"separation": sep.size(), "exact_bit": bit.size(),
            "coverage": coverage.size()}
    assert seed == {"separation": 6, "exact_bit": 18, "coverage": 10}
    seed["total"] = sum(seed.values())
    return {"payload_samples": rows, "fixed_seed": seed,
            "conditional_costs": {"forward": "F+20", "backward": "F+18"},
            "metric": "One node per AST constructor, including each quantifier; "
                      "frozen descriptions charged recursively at every use.",
            "frozen_substitution_checks": "passed"}


def Q(counter: int, initial: int) -> int:
    return initial if counter == 0 else counter - 1


def Z(counter: int, initial: int) -> int:
    return initial if counter == 0 else 0


def eqbit(left: int, right: int) -> int:
    return int(left == right)


def raw_value(values: tuple[int, ...], successor: tuple[int, ...],
              witness: int, target: int, probe: int) -> bool:
    first_bit = eqbit(successor[probe], witness)
    # On the local finite carriers S(0)=1, S(1)=2.  Thus this is
    # the actual interpretation of S(chi(S(x),b)), not a new symbol.
    first_successor = successor[first_bit]
    return Q(Z(values[probe], first_successor),
             Q(eqbit(witness, target), eqbit(probe, witness))) == 0


def backward_case(values: tuple[int, ...], successor: tuple[int, ...],
                  witness: int, target: int, probe: int) -> bool:
    if values[probe] != 0:
        return probe != witness or witness == target
    return successor[probe] != witness


def local_carrier_checks() -> dict:
    reports = []
    for size in range(3, 7):
        maps = points = witnesses = 0
        maps_with_fixed_points = maps_noninjective = 0
        # The numeric bit cone is fixed. Every remaining successor
        # value is completely unrestricted, including zero and itself.
        for suffix in product(range(size), repeat=size - 2):
            successor = (1, 2) + suffix
            maps += 1
            maps_with_fixed_points += any(successor[j] == j for j in range(size))
            maps_noninjective += len(set(successor)) < size
            # Exhaustive raw values 0,1,2 through size 4. Larger
            # carriers exhaust zero/nonzero patterns, assigning
            # distinct nonzero representatives cyclically.
            alphabet = (0, 1, 2) if size <= 4 else (0, 1)
            for bits in product(alphabet, repeat=size):
                values = (tuple(bits) if size <= 4 else
                          tuple(0 if bit == 0 else 1 + j % (size - 1)
                                for j, bit in enumerate(bits)))
                for witness in range(size):
                    for target in range(size):
                        raw_all = backward_all = True
                        for probe in range(size):
                            left = raw_value(values, successor, witness, target, probe)
                            right = backward_case(values, successor, witness, target, probe)
                            assert left == right
                            raw_all = raw_all and left
                            backward_all = backward_all and right
                            points += 1
                        assert raw_all == backward_all
                        witnesses += 1
        reports.append({"carrier_size": size, "successor_maps": maps,
                        "maps_with_fixed_points": maps_with_fixed_points,
                        "noninjective_maps": maps_noninjective,
                        "pointwise_equivalences": points,
                        "witness_equivalences": witnesses})
    return {
        "scope": "Literal finite-carrier local evaluations with S(0)=1, S(1)=2, "
                 "arbitrary successor elsewhere, native equality bits, and numeric "
                 "Q/Z case operations. These are not models of the full arithmetic "
                 "axioms. The check establishes only the local raw/StrongIf identity.",
        "reports": reports,
        "no_fixed_point_assumption": "Not imposed; fixed-point maps included.",
        "all_relevant_raw_values": "Exhaustive 0/1/2 through size 4; exhaustive "
                                  "zero/nonzero patterns with varied positive "
                                  "representatives through size 6."}


def natural_scan(values: tuple[int, ...], target: int) -> int:
    witness = 0
    for counter in range(target):
        if values[witness] != 0:
            witness = counter + 1
    return witness


def prefix_checks() -> dict:
    prefix_count = targets = raw_points = direct_witnesses = 0
    covered_witnesses = boolean_witnesses = scan_steps = 0
    for length in range(3, 13):
        successor = tuple(j + 1 for j in range(length))
        for flags in product((0, 1), repeat=length):
            prefix_count += 1
            values = tuple(0 if flag == 0 else 1 + j % 4
                           for j, flag in enumerate(flags))
            for target in range(length - 1):
                targets += 1
                witness = natural_scan(values, target)
                assert (values[witness] == 0 or witness == target)
                assert (witness == 0 or values[witness - 1] != 0)
                for probe in range(length):
                    assert raw_value(values, successor, witness, target, probe)
                    assert backward_case(values, successor, witness, target, probe)
                    raw_points += 1

                # Verify the exact scan invariant at every intermediate stage.
                r = 0
                for k in range(target + 1):
                    assert values[r] == 0 or r == k
                    assert r == 0 or (r == (r - 1) + 1 and values[r - 1] != 0)
                    scan_steps += 1
                    if k < target and values[r] != 0:
                        r = k + 1

                direct = [j for j in range(target + 1)
                          if Z(values[j], j) == 0
                          and (values[j + 1] == 0 or j == target)]
                assert direct
                direct_witnesses += len(direct)
                covered = []
                for j in range(target + 1):
                    companion = Q(Z(values[j], j), target)
                    assert 0 <= companion < length
                    if Z(values[companion], companion) == 0:
                        covered.append((j, companion))
                assert covered
                covered_witnesses += len(covered)
                boolean = [j for j in range(max(target, 1) + 1)
                           if Q(flags[j + 1], flags[j])
                           == Q(flags[target], flags[0])]
                assert boolean
                boolean_witnesses += len(boolean)

    # The Boolean recipe is used only for the checked Boolean grammar.
    # No finite prefix is mislabeled an infinite countermodel to any
    # unproved raw-term generalization of that recipe.
    return {"prefix_lengths": [3, 12], "binary_prefixes": prefix_count,
            "target_instances": targets, "raw_probe_checks": raw_points,
            "scan_invariant_stages": scan_steps,
            "direct_witnesses_found": direct_witnesses,
            "covered_witnesses_found": covered_witnesses,
            "boolean_witnesses_found": boolean_witnesses,
            "scope": "Natural-number finite prefixes. This tests exact witnesses "
                     "and the stated quantifier-free invariant, not induction "
                     "or validity in arbitrary nonstandard models."}


def hypothesis_checks() -> dict:
    # Graph-only counterexample to deriving induction from the backward
    # witness when coverage is absent. This does not claim to satisfy
    # the full recursor theory.
    successor = (1, 1, 1)
    predicate = (True, True, False)
    target = witness = 2
    base = predicate[0]
    progress = all(not predicate[j] or predicate[successor[j]]
                   for j in range(3))
    boundary = all((j != witness or witness == target) if predicate[j]
                   else successor[j] != witness for j in range(3))
    coverage = all(j == 0 or j in successor for j in range(3))
    assert base and progress and boundary and not predicate[target]
    assert not coverage

    # A broken predecessor test chi(x,b), instead of chi(Sx,b), has
    # no witness for the constant-false predicate on the naturals.
    for witness in range(8):
        probe = witness
        broken = Q(Z(0, 1 + eqbit(probe, witness)),
                   Q(eqbit(witness, 0), eqbit(probe, witness))) == 0
        assert not broken

    # The Boolean candidate cannot be licensed for arbitrary raw terms.
    # For t(x)=Z(x,2) and n=0 its RHS is 1. Its LHS is 2 at b=0
    # and 0 at every b>0, so the axiom has no natural-number witness.
    raw_counterexample = lambda j: Z(j, 2)
    rhs = Q(raw_counterexample(0), raw_counterexample(0))
    assert rhs == 1
    assert Q(raw_counterexample(1), raw_counterexample(0)) == 2
    for witness in range(1, 9):
        assert Q(raw_counterexample(witness + 1),
                 raw_counterexample(witness)) == 0
    assert not boolean_grammar(z(x, succ(ONE)))

    # No successor fixed-point hypothesis is needed for the abstract
    # deduction boundary + coverage + base + progress -> P(target).
    checked = 0
    for size in range(1, 6):
        for successor in product(range(size), repeat=size):
            covered = all(j == 0 or j in successor for j in range(size))
            if not covered:
                continue
            for predicate in product((False, True), repeat=size):
                if not predicate[0]:
                    continue
                if not all(not predicate[j] or predicate[successor[j]]
                           for j in range(size)):
                    continue
                for target in range(size):
                    for witness in range(size):
                        boundary = all(
                            (j != witness or witness == target) if predicate[j]
                            else successor[j] != witness for j in range(size))
                        if boundary:
                            assert predicate[target]
                        checked += 1
    return {
        "covered_graph_deduction_checks": checked,
        "covered_graph_max_size": 5,
        "fixed_points_and_noninjectivity_allowed": True,
        "without_coverage_counterexample": {
            "successor": [1, 1, 1], "predicate": [True, True, False],
            "target": 2, "witness": 2,
            "base_progress_and_boundary": True, "conclusion": False,
            "scope": "Counterexample to the isolated graph-theoretic deduction, "
                     "not a model of the complete arithmetic theory."},
        "wrong_predecessor_test": "Rejected at the witness itself for all eight "
                                  "tested witnesses of the constant-false test.",
        "boolean_guard_is_essential": {
            "raw_term": "t(x)=Z(x,S(S(0)))", "target": 0,
            "right_side": 1, "left_side_at_zero": 2,
            "left_side_at_positive_inputs": 0,
            "claim": "A complete standard-natural counterexample to applying "
                     "the Boolean candidate outside its specified grammar. "
                     "The two input classes compute directly from Z/Q equations."}}


def envelope_checks() -> dict:
    raw_profiles = boolean_profiles = strictly_smaller = 0
    examples = []
    for T in range(1, 129):
        for i in range(T + 1):
            new = min(2 * T + i + 15, 2 * T + 18, T + 23)
            old = min(2 * T + i + 15, 2 * T + 18, T + 28)
            assert new <= old
            assert 2 * T + 18 <= 2 * T + 21
            raw_profiles += 1
            strictly_smaller += new < old
            new_b = min(new, 4 * T + i + 8)
            old_b = min(old, 4 * T + i + 8, T + 25)
            assert new_b <= old_b
            boolean_profiles += 1
    for T, i in [(1, 1), (3, 1), (5, 1), (10, 1), (20, 1), (50, 1)]:
        old = min(2 * T + i + 15, 2 * T + 18, T + 28)
        new = min(2 * T + i + 15, 2 * T + 18, T + 23)
        examples.append({"T": T, "i": i, "old_covered_raw": old,
                         "new_covered_raw": new, "saving": old - new})
    return {"abstract_size_profiles_checked": raw_profiles,
            "boolean_profiles_checked": boolean_profiles,
            "strict_raw_improvements": strictly_smaller,
            "new_raw": "min(2T+i+15,2T+18,T+23)",
            "new_boolean": "min(2T+i+15,2T+18,T+23,4T+i+8)",
            "old_common_covered_raw": "min(2T+i+15,2T+18,T+28)",
            "old_common_covered_boolean": "min(2T+i+15,2T+18,T+28,4T+i+8,T+25)",
            "examples": examples,
            "qualification": "Size profiles are algebraic profiles, not all "
                             "necessarily realized by a legal term. All fixed "
                             "basis comparisons here use the same 34-node seed. "
                             "i=0 clauses may be omitted separately when the "
                             "theory uses a vacuity-aware emitter."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("results.json"))
    args = parser.parse_args()
    result = {
        "status": "passed",
        "script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "syntax": syntax_checks(),
        "finite_local_carriers": local_carrier_checks(),
        "natural_prefixes": prefix_checks(),
        "hypothesis_audit": hypothesis_checks(),
        "envelopes": envelope_checks(),
        "proof_scope": "Finite executable checks and exact AST counts only. "
                       "The report's internal PRA invariant, arithmetic compiler, "
                       "and bi-interpretations are mathematical proofs, not "
                       "established by this script."
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"],
                      "result": str(args.output.resolve()),
                      "syntax_samples": len(result["syntax"]["payload_samples"]),
                      "finite_local_points": sum(r["pointwise_equivalences"]
                          for r in result["finite_local_carriers"]["reports"]),
                      "prefix_targets": result["natural_prefixes"]["target_instances"]},
                     indent=2))


if __name__ == "__main__":
    main()
