PRA FROM PREDECESSOR BOUNDARIES
Research archive prepared for Vladimir Reshetnikov, 2 November 2026
=================================================================

START HERE
  report.pdf       Complete paper, proofs, comparison, and limitations.
  report.tex       Main LaTeX source; includes every file in sections/.
  AXIOMS.txt       Standalone exact specifications of all recommended variants.

NEW RESULT
  A predecessor-boundary equation uses an arbitrary raw test term once:

  forall a n exists b forall x,
    Q(Z(t(x,a), S(chi(S(x),b))), Q(chi(b,n),chi(x,b))) = 0,

  where Q=R_w and Z=R_0 are initialized binary recursors. Full cost T+23;
  active cost m+20. The current one-occurrence raw alternatives cost T+28.
  No no-fixed-point lemma or toggle-recursion prelude is needed.

  The recommended saturated covered basis is the inherited Bit+Part=30.
  A uniform Off+Part=23 variant also works when it retains the 24-node
  t(x,a)=a normalization instance. The optimizing emitter uses seed 30.

  The compatible new literal raw envelope is
    min(2T+i+15, 2T+18, T+23, [4T+i+8]),
  with the bracketed clause restricted to the exact Boolean grammar.
  It is no larger than the combined surviving covered raw envelope in
  the same vocabulary. Native-formula and other-signature workloads are
  compared separately, not silently treated as identical raw terms.

  A native 0,S companion with a declared primitive strong conditional
  has an atomic clause F+18 instead of F+20. Its 16-node arithmetic seed
  and 14-node logical definition are separately charged.

CALIBRATION
  Detailed written proof of common conservative definitional extension
  with first-order PRA, hence equiconsistency and bi-interpretability.
  Both domains are whole carriers; both composite isomorphisms are the
  identity. Classical and intuitionistic results are separate matching
  pairs. No universal evaluator or standard-model assumption is used.

  The full theorem is not claimed to be entirely formalized in Lean.
  The two Lean files verify the new local kernels, scan, and unsaturated
  seed normalization. The forest countermodel proves that coverage is
  essential for the uniform predecessor theory's bi-interpretability.

SOURCE AUDIT
  Commit: 2ba9e7a5767fee450c6611868fdf0c4d3a27754e
  Repository: https://github.com/VladimirReshetnikov/ProveIt
  Five current and eight archived ZIPs inspected; all blobs verified.
  All five current proposals contain real improvements, so none is
  discarded wholesale. Source hashes and exact member references are
  under provenance/. Original source archives are not duplicated.

VERIFICATION
  verification/PredecessorBoundary.lean
  verification/SeedNormalization.lean
    Lean 4.19.0, core library only, no Mathlib, no admitted theorems.
    All printed generic/seed dependencies are empty; the two concrete
    Nat raw-witness results use only propext. Logs and hashes included.

  verification/check_boundary.py and results.json
    Exact AST counts; frozen substitutions; over 18.5 million pointwise
    local-kernel checks; explicit scan and grammar counterexamples.

  verification/check_seed_sizes.py and seed_sizes.json
    Final 30/34/23 support counts and 24-node normalization instance.
    The original large kernel results use transparent 34 support and
    remain unchanged; the supplementary result records final 30 support.

REBUILD
  python3 build.py
  python3 build.py --pdf-only

  Python 3.10+ standard library and a conventional pdfLaTeX installation
  suffice. To rerun Lean set PRA_LEAN to a Lean 4.19.0 executable or put
  lean on PATH. If Lean is absent, the build reports that it was skipped;
  the original source-bound compiler logs remain in verification/.

  The full build runs the Python checks and compiles the PDF three times.
  It writes disposable build/ files. The supplied PDF was also rendered
  and visually reviewed, with the result recorded in verification/.

LIMIT OF THE CLAIM
  This is a rigorous new improvement under stated syntax and support
  metrics. It is not an absolute shortest-axiomatization theorem across
  all languages, logical primitives, proof rules, and representations.
  No changes were posted to the repository.
