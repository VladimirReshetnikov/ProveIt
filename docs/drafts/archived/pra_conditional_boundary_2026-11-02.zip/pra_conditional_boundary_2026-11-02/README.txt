PRIMITIVE RECURSIVE ARITHMETIC WITH ONE PREDICATE OCCURRENCE
Prepared for Vladimir Reshetnikov, November 2, 2026

Read paper.pdf for the complete theorem, proofs, comparison, and qualifications.
The recommendation is CB_min in Section 2: initial arithmetic symbols 0,S;
one staged binary initialized-recursion constructor; 0 != S0; and the
shorter of native boundary choice and the new strong-conditional boundary.

Strong conditional:
  If(A,U,V) = (A and U) or ((A -> false) and V).

New native boundary:
  forall a n exists b forall x,
    If(P(x,a), (x=S(b) -> b=n), (x=b -> b=0)).

For a predicate of full tree size F and i active occurrences of x, the
conditional clause costs F+20. With the old native boundary available,
the exact emitted cost is min(2F+i+12,F+20). If i=0, emit no clause,
since the induction implication is already logical. For i>0 choose native
boundary when F+i<=8 and conditional boundary otherwise.

The conditional is a conservative primitive logical connective. Its
definition is printed and charged as fixed specification data. Expanding
it into the old connectives changes the clause cost to 2F+24. The main
pointwise comparison is in the explicitly stated conditional basis; it is
not an undisclosed abbreviation in the old basis.

An independent old-basis numerical boundary uses one raw payload copy
and costs T+28, versus the current single-copy value table's T+43.
Section 5 also supplies a compatible raw optimizer and its explicit
diagonal/coverage bootstrap. Both full arithmetic theories are ordinarily
bi-interpretable with first-order PRA, with whole-carrier domains and
identity interpretation composites. Classical and intuitionistic versions
are treated separately. No absolute shortestness theorem is claimed.

SOURCE AUDIT
All 8 current and 6 archived ZIPs were read at ProveIt commit
b306aef970d43d582765a1daef9d1734aa83978e.
The closing check added pra_smaller_modules_f6530de455.zip; all original
13 files were unchanged. Its improved Boolean compilers are included;
its graph-language and proof-rule interfaces are separately accounted.
Every current archive has some improvement; inherited features are
excluded individually, not by incorrectly discarding complete archives.
The source manifest includes exact ZIP byte hashes and immutable URLs.

REBUILD
  python3 build.py

Requirements: Python 3.10+ standard library; pdfLaTeX and the conventional
LaTeX packages listed in paper.tex. The build runs all three checkers and
compiles the PDF three times for the contents and cross-references.

CHECK WITHOUT TEX
  python3 build.py --verify-only

CHECK ONLY THE SERIALIZED LOGICAL PROOF
  python3 verification/check_induction.py --verify \
    verification/conditional_induction_certificate.json

VERIFICATION SCOPE
The 47-node logical certificate proves the expanded conditional boundary
implies the full induction implication in intuitionistic first-order
logic with equality, with no arithmetic induction oracle. The syntax
checker derives all size formulas from ASTs and charges frozen bodies.
The finite witness checker checks all Boolean traces of lengths 2..9.
These do not constitute a full Lean/Rocq formalization of the arithmetic
compiler, the infinite-schema metatheory, or the bi-interpretation.
Those arguments are supplied as detailed mathematical proofs in the paper.

ORGANIZATION
  paper.tex, sections/      Complete LaTeX source
  paper.pdf                Compiled paper
  AXIOMS.txt               Exact recommended theory in plain text
  verification/            Checkers, certificate, and recorded results
  provenance/              Source identity and proposal-by-proposal audit
  package_manifest.json    SHA-256 file hashes (excluding itself)

The previous source archives are referenced by hashes and URLs, not
duplicated in this package. No changes were posted to the repository.
