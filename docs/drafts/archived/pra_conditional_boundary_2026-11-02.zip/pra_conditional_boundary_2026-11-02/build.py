#!/usr/bin/env python3
"""Recheck the research artifacts and rebuild the paper using standard tools."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    verification = root / 'verification'
    for filename in ('check_induction.py', 'check_sizes.py', 'check_witnesses.py'):
        subprocess.run([sys.executable, str(verification / filename)], cwd=root, check=True)
    if args.verify_only:
        return
    if not shutil.which('pdflatex'):
        raise SystemExit('pdfLaTeX is required to rebuild paper.pdf; verification passed.')
    build = root / 'build'
    build.mkdir(exist_ok=True)
    for pass_number in range(1, 4):
        result = subprocess.run(
            ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
             '-output-directory', str(build), 'paper.tex'],
            cwd=root, capture_output=True, text=True)
        (build / f'pass_{pass_number}.txt').write_text(result.stdout + result.stderr)
        if result.returncode:
            print(result.stdout[-6000:])
            raise SystemExit(f'LaTeX pass {pass_number} failed; see build/ for the log.')
    shutil.copy2(build / 'paper.pdf', root / 'paper.pdf')
    print('All checks passed; paper.pdf rebuilt.')


if __name__ == '__main__':
    main()
