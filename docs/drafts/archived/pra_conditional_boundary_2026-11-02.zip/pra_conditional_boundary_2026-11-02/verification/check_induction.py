#!/usr/bin/env python3
"""Build and independently check a small intuitionistic FOL proof certificate.

The sole open assumption is the expanded conditional-boundary sentence.
The checker has no arithmetic-induction rule, arithmetic axioms, oracle,
tautology checker, or rule accepting the target conclusion. Equality transport
in either direction is an ordinary equality-elimination rule. Quantifier rules
check free-variable side conditions; substitution is capture avoiding.

Run this file to write/recheck the certificate and validation results beside
the script. Run with --verify PATH to check an existing certificate only.
The certificate proves one generic logical kernel, not the full arithmetic
compiler or the first-order bi-interpretability theorem.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys


class ProofError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ProofError(message)


def valid_name(name):
    return isinstance(name, str) and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", name)


def validate_term(term):
    require(isinstance(term, list) and term, "Malformed term")
    if term[0] == "var":
        require(len(term) == 2 and valid_name(term[1]), "Malformed variable")
    elif term[0] == "zero":
        require(len(term) == 1, "Malformed zero")
    elif term[0] == "succ":
        require(len(term) == 2, "Malformed successor")
        validate_term(term[1])
    else:
        raise ProofError("Unknown term constructor")


def validate_formula(formula):
    require(isinstance(formula, list) and formula, "Malformed formula")
    kind = formula[0]
    if kind == "bot":
        require(len(formula) == 1, "Malformed falsity")
    elif kind in {"pred", "eq"}:
        require(len(formula) == 3, "Malformed atomic formula")
        validate_term(formula[1])
        validate_term(formula[2])
    elif kind in {"and", "or", "imp"}:
        require(len(formula) == 3, "Malformed connective")
        validate_formula(formula[1])
        validate_formula(formula[2])
    elif kind in {"all", "ex"}:
        require(len(formula) == 3 and valid_name(formula[1]), "Malformed binder")
        validate_formula(formula[2])
    else:
        raise ProofError("Unknown formula constructor")


def term_free(term):
    if term[0] == "var":
        return {term[1]}
    if term[0] == "zero":
        return set()
    return term_free(term[1])


def free(formula):
    kind = formula[0]
    if kind == "bot":
        return set()
    if kind in {"pred", "eq"}:
        return term_free(formula[1]) | term_free(formula[2])
    if kind in {"and", "or", "imp"}:
        return free(formula[1]) | free(formula[2])
    return free(formula[2]) - {formula[1]}


def all_names(formula):
    kind = formula[0]
    if kind == "bot":
        return set()
    if kind in {"pred", "eq"}:
        return term_free(formula[1]) | term_free(formula[2])
    if kind in {"and", "or", "imp"}:
        return all_names(formula[1]) | all_names(formula[2])
    return all_names(formula[2]) | {formula[1]}


def subst_term(term, variable, replacement):
    if term[0] == "var":
        return copy.deepcopy(replacement if term[1] == variable else term)
    if term[0] == "zero":
        return ["zero"]
    return ["succ", subst_term(term[1], variable, replacement)]


def subst(formula, variable, replacement):
    """Substitute in free occurrences, alpha-renaming conflicting binders."""
    kind = formula[0]
    if kind == "bot":
        return ["bot"]
    if kind in {"pred", "eq"}:
        return [kind, subst_term(formula[1], variable, replacement),
                subst_term(formula[2], variable, replacement)]
    if kind in {"and", "or", "imp"}:
        return [kind, subst(formula[1], variable, replacement),
                subst(formula[2], variable, replacement)]
    binder, body = formula[1], formula[2]
    if binder == variable:
        return copy.deepcopy(formula)
    if binder in term_free(replacement) and variable in free(body):
        forbidden = all_names(body) | term_free(replacement) | {variable, binder}
        index = 0
        fresh = f"{binder}__{index}"
        while fresh in forbidden:
            index += 1
            fresh = f"{binder}__{index}"
        body = subst(body, binder, ["var", fresh])
        binder = fresh
    return [kind, binder, subst(body, variable, replacement)]


def context_free(context):
    result = set()
    for formula in context.values():
        result |= free(formula)
    return result


class Checker:
    """A deliberately small recursive natural-deduction kernel."""

    def __init__(self):
        self.nodes = 0
        self.rules = {}

    def infer(self, node, context):
        require(isinstance(node, dict), "Proof node must be an object")
        rule = node.get("rule")
        require(isinstance(rule, str), "Proof node has no rule")
        self.nodes += 1
        self.rules[rule] = self.rules.get(rule, 0) + 1
        premises = node.get("premises", [])
        require(isinstance(premises, list), "Premises must be a list")

        def arity(n):
            require(len(premises) == n, f"Wrong premise count for {rule}")

        def child(index, local=None):
            return self.infer(premises[index], context if local is None else local)

        def extend(label, formula):
            require(valid_name(label) and label not in context,
                    "Discharge label is not fresh")
            validate_formula(formula)
            return {**context, label: formula}

        if rule == "assumption":
            arity(0)
            label = node.get("label")
            require(label in context, "Undeclared or out-of-scope assumption")
            result, used = copy.deepcopy(context[label]), {label}
        elif rule == "and_intro":
            arity(2)
            left, lu = child(0)
            right, ru = child(1)
            result, used = ["and", left, right], lu | ru
        elif rule == "and_elim":
            arity(1)
            conjunction, used = child(0)
            index = node.get("index")
            require(conjunction[0] == "and" and type(index) is int
                    and index in {0, 1}, "Invalid conjunction elimination")
            result = conjunction[index + 1]
        elif rule == "imp_intro":
            arity(1)
            antecedent = node.get("antecedent")
            label = node.get("label")
            conclusion, used = child(0, extend(label, antecedent))
            result, used = ["imp", antecedent, conclusion], used - {label}
        elif rule == "imp_elim":
            arity(2)
            implication, iu = child(0)
            antecedent, au = child(1)
            require(implication[0] == "imp" and implication[1] == antecedent,
                    "Modus ponens antecedent mismatch")
            result, used = implication[2], iu | au
        elif rule == "or_elim":
            arity(3)
            disjunction, du = child(0)
            require(disjunction[0] == "or", "Expected a disjunction")
            left_label, right_label = node.get("left_label"), node.get("right_label")
            require(left_label != right_label, "Case labels must differ")
            left, lu = child(1, extend(left_label, disjunction[1]))
            right, ru = child(2, extend(right_label, disjunction[2]))
            require(left == right, "Disjunction cases have different conclusions")
            result = left
            used = du | (lu - {left_label}) | (ru - {right_label})
        elif rule == "bot_elim":
            arity(1)
            falsity, used = child(0)
            require(falsity == ["bot"], "Falsity elimination needs falsity")
            result = node.get("conclusion")
            validate_formula(result)
        elif rule == "all_intro":
            arity(1)
            variable = node.get("variable")
            require(valid_name(variable), "Malformed universal eigenvariable")
            require(variable not in context_free(context),
                    "Universal eigenvariable occurs in an open assumption")
            body, used = child(0)
            result = ["all", variable, body]
        elif rule == "all_elim":
            arity(1)
            universal, used = child(0)
            require(universal[0] == "all", "Expected a universal formula")
            term = node.get("term")
            validate_term(term)
            result = subst(universal[2], universal[1], term)
        elif rule == "ex_elim":
            arity(2)
            existential, eu = child(0)
            require(existential[0] == "ex", "Expected an existential formula")
            witness, label = node.get("witness"), node.get("label")
            require(valid_name(witness), "Malformed existential eigenvariable")
            require(witness not in context_free(context) | free(existential),
                    "Existential eigenvariable occurs in the outer context")
            instance = subst(existential[2], existential[1], ["var", witness])
            result, bu = child(1, extend(label, instance))
            require(witness not in free(result),
                    "Existential eigenvariable escapes into the conclusion")
            used = eu | (bu - {label})
        elif rule == "eq_refl":
            arity(0)
            term = node.get("term")
            validate_term(term)
            result, used = ["eq", term, term], set()
        elif rule == "eq_subst":
            arity(2)
            equality, eu = child(0)
            before, bu = child(1)
            require(equality[0] == "eq", "Equality transport needs an equality")
            template, variable = node.get("template"), node.get("variable")
            validate_formula(template)
            require(valid_name(variable), "Malformed equality placeholder")
            reverse = node.get("reverse", False)
            require(type(reverse) is bool, "Malformed transport orientation")
            left, right = equality[1:]
            if reverse:
                left, right = right, left
            require(before == subst(template, variable, left),
                    "Equality transport source does not match its template")
            result = subst(template, variable, right)
            used = eu | bu
        else:
            raise ProofError(f"Unrecognized inference rule: {rule}")

        validate_formula(result)
        require(used <= set(context), "A discharged assumption escaped its scope")
        return copy.deepcopy(result), used


def verify_certificate(certificate):
    require(certificate.get("format") == "pra-conditional-nd-v1", "Unknown format")
    context = certificate.get("assumptions")
    require(isinstance(context, dict), "Missing assumption context")
    for label, formula in context.items():
        require(valid_name(label), "Malformed assumption label")
        validate_formula(formula)
    expected = certificate.get("conclusion")
    validate_formula(expected)
    checker = Checker()
    inferred, used = checker.infer(certificate.get("proof"), context)
    require(inferred == expected, "The certificate concludes a different formula")
    return {
        "verified": True,
        "proof_nodes": checker.nodes,
        "inference_rule_counts": dict(sorted(checker.rules.items())),
        "used_open_assumptions": sorted(used),
        "unused_open_assumptions": sorted(set(context) - used),
        "used_assumption_formulas": {label: context[label] for label in sorted(used)},
        "conclusion": inferred,
    }


# The builder below contains the proposed derivation. The kernel above does not
# recognize this theorem or grant the builder any privileged inference rule.
def V(name):
    return ["var", name]


Z = ["zero"]
BOTTOM = ["bot"]


def S(term):
    return ["succ", term]


def P(left, right):
    return ["pred", left, right]


def E(left, right):
    return ["eq", left, right]


def And(left, right):
    return ["and", left, right]


def Or(left, right):
    return ["or", left, right]


def Imp(left, right):
    return ["imp", left, right]


def All(variable, body):
    return ["all", variable, body]


def Ex(variable, body):
    return ["ex", variable, body]


def node(rule, *premises, **data):
    return {"rule": rule, **data, "premises": list(premises)}


def assumption(label):
    return node("assumption", label=label)


def conjunction_part(proof, index):
    return node("and_elim", proof, index=index)


def universal_instance(proof, term):
    return node("all_elim", proof, term=term)


def apply(implication, antecedent):
    return node("imp_elim", implication, antecedent)


def reflexivity(term):
    return node("eq_refl", term=term)


def make_certificate():
    a, n, b, x = (V(name) for name in ("a", "n", "b", "x"))
    expanded_conditional = Or(
        And(P(x, a), Imp(E(x, S(b)), E(b, n))),
        And(Imp(P(x, a), BOTTOM), Imp(E(x, b), E(b, Z))),
    )
    boundary = All("a", All("n", Ex("b", All("x", expanded_conditional))))
    induction_hypotheses = And(P(Z, a), All("x", Imp(P(x, a), P(S(x), a))))
    goal = All("a", Imp(induction_hypotheses, All("n", P(n, a))))

    local_boundary = assumption("certificate")
    at_b = universal_instance(local_boundary, b)
    first_positive = conjunction_part(assumption("first_positive"), 0)
    first_negative = assumption("first_negative")
    b_zero = apply(conjunction_part(first_negative, 1), reflexivity(b))
    base = conjunction_part(assumption("induction_hypotheses"), 0)
    first_negative_yields_pb = node(
        "eq_subst", b_zero, base,
        variable="z", template=P(V("z"), a), reverse=True,
    )
    pb = node(
        "or_elim", at_b, first_positive, first_negative_yields_pb,
        left_label="first_positive", right_label="first_negative",
    )

    progress = conjunction_part(assumption("induction_hypotheses"), 1)
    psb = apply(universal_instance(progress, b), pb)
    at_sb = universal_instance(local_boundary, S(b))
    b_n = apply(conjunction_part(assumption("second_positive"), 1), reflexivity(S(b)))
    positive_yields_pn = node(
        "eq_subst", b_n, pb,
        variable="z", template=P(V("z"), a), reverse=False,
    )
    contradiction = apply(conjunction_part(assumption("second_negative"), 0), psb)
    negative_yields_pn = node("bot_elim", contradiction, conclusion=P(n, a))
    pn = node(
        "or_elim", at_sb, positive_yields_pn, negative_yields_pn,
        left_label="second_positive", right_label="second_negative",
    )
    exists_boundary = universal_instance(
        universal_instance(assumption("boundary"), a), n
    )
    without_b = node(
        "ex_elim", exists_boundary, pn, witness="b", label="certificate"
    )
    all_n = node("all_intro", without_b, variable="n")
    implication = node(
        "imp_intro", all_n, antecedent=induction_hypotheses,
        label="induction_hypotheses",
    )
    proof = node("all_intro", implication, variable="a")
    return {
        "format": "pra-conditional-nd-v1",
        "description": "Expanded conditional boundary implies the full induction implication",
        "predicate_symbol": "P is an arbitrary binary relation",
        "assumptions": {"boundary": boundary},
        "conclusion": goal,
        "proof": proof,
    }


def kernel_self_tests():
    """Targeted side-condition tests, not substitutes for the proof certificate."""
    checks = []

    def reject(label, proof, context):
        try:
            Checker().infer(proof, context)
        except ProofError:
            checks.append({"test": label, "result": "correctly rejected"})
            return
        raise ProofError(f"Unsound test proof was accepted: {label}")

    example = All("y", P(V("x"), V("y")))
    substituted = subst(example, "x", V("y"))
    require(substituted == All("y__0", P(V("y"), V("y__0"))),
            "Capture avoidance failed to alpha-rename")
    require(free(substituted) == {"y"}, "Capture avoidance changed free variables")
    checks.append({"test": "capture-avoiding substitution", "result": "passed"})

    quantified = All("x", example)
    inferred, _ = Checker().infer(
        universal_instance(assumption("h"), V("y")), {"h": quantified}
    )
    require(inferred == substituted, "Universal elimination captured a free variable")
    checks.append({"test": "universal elimination with binder conflict", "result": "passed"})

    reject("universal eigenvariable in open assumption",
           node("all_intro", assumption("h"), variable="x"),
           {"h": P(V("x"), V("a"))})
    reject("existential eigenvariable escaping conclusion",
           node("ex_elim", assumption("h"), assumption("w"), witness="b", label="w"),
           {"h": Ex("x", P(V("x"), V("a")))})
    reject("existential eigenvariable in outer assumption",
           node("ex_elim", assumption("h"), assumption("g"), witness="b", label="w"),
           {"h": Ex("x", P(V("x"), V("a"))), "g": P(V("b"), V("a"))})
    reject("mismatched equality-transport source",
           node("eq_subst", assumption("e"), assumption("p"),
                variable="z", template=P(V("z"), V("a"))),
           {"e": E(V("x"), V("y")), "p": P(Z, V("a"))})
    reject("undeclared assumption", assumption("missing"), {})
    reject("unrecognized induction oracle", node("arithmetic_induction"), {})
    reject("vacuous falsity elimination without falsity",
           node("bot_elim", reflexivity(Z), conclusion=BOTTOM), {})
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", type=Path, help="verify an existing JSON certificate only")
    args = parser.parse_args()
    if args.verify:
        certificate = json.loads(args.verify.read_text())
        result = verify_certificate(certificate)
        print(json.dumps(result, indent=2))
        return

    directory = Path(__file__).resolve().parent
    certificate_path = directory / "conditional_induction_certificate.json"
    result_path = directory / "conditional_induction_verification.json"
    certificate = make_certificate()
    certificate_path.write_text(json.dumps(certificate, indent=2) + "\n")
    # The checker consumes the serialized/reloaded proof, not builder state.
    loaded = json.loads(certificate_path.read_text())
    result = verify_certificate(loaded)
    require(result["used_open_assumptions"] == ["boundary"],
            "The generic proof has an unexpected assumption dependency")
    require(result["conclusion"] == make_certificate()["conclusion"],
            "The generic proof has the wrong induction goal")
    result["kernel_self_tests"] = kernel_self_tests()
    result["certificate_sha256"] = hashlib.sha256(certificate_path.read_bytes()).hexdigest()
    result["checker_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result["scope"] = (
        "Generic intuitionistic first-order logical implication only. "
        "The full arithmetic compiler and bi-interpretability theorem are not formalized."
    )
    result_path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "verified": result["verified"],
        "proof_nodes": result["proof_nodes"],
        "used_open_assumptions": result["used_open_assumptions"],
        "kernel_self_tests": len(result["kernel_self_tests"]),
        "certificate": str(certificate_path),
        "results": str(result_path),
    }, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ProofError, KeyError, IndexError, TypeError, RecursionError) as error:
        print(f"Verification failed: {error}", file=sys.stderr)
        sys.exit(1)
