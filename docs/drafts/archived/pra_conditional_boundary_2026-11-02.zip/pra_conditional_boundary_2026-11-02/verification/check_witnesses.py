#!/usr/bin/env python3
"""Finite Boolean checks for the new conditional and raw GD boundaries.

Run with Python 3.10+; standard library only. The complete corpus consists
of every Boolean trace of lengths 2 through 9. A length-L trace supplies
P(0),...,P(L-1); targets satisfy 0 <= n <= L-2, so each relevant successor
value is present. Every possible b <= L-2 is checked for exact equivalence
of the two new matrices to the native boundary certificate. The explicit
primitive-recursive candidate is then checked at every target.

Raw GD is checked both for 0/1 payloads and for non-Boolean positive
payloads. These are finite error checks. They are not proofs about an
infinite axiom schema, nonstandard arithmetic, or bi-interpretability.
"""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path


def implies(antecedent: bool, consequent: bool) -> bool:
    return not antecedent or consequent


def strong_conditional(test: bool, when_true: bool, when_false: bool) -> bool:
    # Literal Boolean reading of (P and U) or ((P -> false) and V).
    return (test and when_true) or ((not test) and when_false)


def chi(x: int, y: int) -> int:
    return int(x == y)


def native_boundary(trace: tuple[bool, ...], n: int, b: int) -> bool:
    return (b == 0 or trace[b]) and implies(trace[b + 1], b == n)


def conditional_at(test: bool, x: int, n: int, b: int) -> bool:
    return strong_conditional(
        test,
        implies(x == b + 1, b == n),
        implies(x == b, b == 0),
    )


def gd_at(payload: int, x: int, n: int, b: int) -> bool:
    guard = implies(x == b, b == 0) and implies(x == b + 1, b == n)
    return guard or chi(payload, 0) == chi(x, b + 1)


def candidate(trace: tuple[bool, ...], n: int) -> int:
    """e(0)=0; e(k+1)=e(k)+1 if P(e(k)+1), otherwise e(k)."""
    b = 0
    for k in range(n):
        if trace[b + 1]:
            b = b + 1
    return b


def checked_forall_conditional(trace: tuple[bool, ...], n: int, b: int) -> bool:
    values = [conditional_at(p, x, n, b) for x, p in enumerate(trace)]
    # This sampled outside point differs from both distinguished indices.
    # Both truth values are checked, instead of inventing a trace extension.
    outside = len(trace)
    values.extend(conditional_at(p, outside, n, b) for p in (False, True))
    return all(values)


def checked_forall_gd(
    trace: tuple[bool, ...], n: int, b: int, non_boolean: bool
) -> bool:
    def payload(test: bool, x: int) -> int:
        return (2 + x % 5 if non_boolean else 1) if test else 0

    values = [gd_at(payload(p, x), x, n, b) for x, p in enumerate(trace)]
    outside = len(trace)
    values.extend(gd_at(v, outside, n, b) for v in (0, 1, 7))
    return all(values)


def omission_examples() -> list[dict]:
    """Removing either branch condition destroys equivalence with BC.

    These examples establish only that the weakened matrices lose the
    exact boundary certificate; they are not full theory-independence
    or bi-interpretability countermodels.
    """
    examples = [
        ("omit_target_condition", (True, True, True), 1, 0),
        ("omit_base_condition", (True, False, False), 1, 1),
    ]
    reports = []
    for name, trace, n, b in examples:
        assert not native_boundary(trace, n, b)
        weak_c = []
        weak_gd = []
        for x, p in enumerate(trace):
            u = implies(x == b + 1, b == n)
            v = implies(x == b, b == 0)
            if name == "omit_target_condition":
                u = True
            else:
                v = True
            weak_c.append(strong_conditional(p, u, v))
            weak_gd.append((u and v) or chi(int(p), 0) == chi(x, b + 1))
        assert all(weak_c) and all(weak_gd)
        reports.append(
            {
                "omission": name,
                "trace": list(map(int, trace)),
                "target": n,
                "witness": b,
                "weakened_conditional_matrix": True,
                "weakened_gd_matrix": True,
                "native_boundary_certificate": False,
            }
        )
    return reports


def run() -> dict:
    trace_count = 0
    target_count = 0
    candidate_count = 0
    witness_equivalence_count = 0
    for length in range(2, 10):
        for trace in itertools.product((False, True), repeat=length):
            trace_count += 1
            for n in range(length - 1):
                target_count += 1
                b = candidate(trace, n)
                assert 0 <= b <= n
                assert native_boundary(trace, n, b)
                assert checked_forall_conditional(trace, n, b)
                assert checked_forall_gd(trace, n, b, non_boolean=False)
                assert checked_forall_gd(trace, n, b, non_boolean=True)
                candidate_count += 1
                for possible_b in range(length - 1):
                    expected = native_boundary(trace, n, possible_b)
                    assert checked_forall_conditional(trace, n, possible_b) == expected
                    assert checked_forall_gd(
                        trace, n, possible_b, non_boolean=False
                    ) == expected
                    assert checked_forall_gd(
                        trace, n, possible_b, non_boolean=True
                    ) == expected
                    witness_equivalence_count += 1
    return {
        "status": "PASS",
        "scope": "Finite arithmetic and Boolean checks; not a bi-interpretation proof.",
        "trace_lengths": [2, 9],
        "trace_count": trace_count,
        "target_instances": target_count,
        "candidate_witnesses_checked": candidate_count,
        "witness_matrix_equivalence_cases": witness_equivalence_count,
        "gd_payload_modes": ["Boolean 0/1", "zero or positive values 2 through 6"],
        "omission_controls": omission_examples(),
        "infinite_claims": "Proved in the mathematical paper, not by this script.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    results = run()
    rendered = json.dumps(results, indent=2) + "\n"
    if args.output is not None:
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
