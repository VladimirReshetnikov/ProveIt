#!/usr/bin/env python3
"""Reproducible syntax accounting for the audited PRA presentations.

Python 3.10+, standard library only. No proof assistant is required.
Counts are constructed from literal abstract syntax trees. Symbolic payload
nodes implement the proved substitution identity |P[u/x]|=|P|+i(|u|-1);
every stored descriptor remains frozen and is charged at every occurrence.
The finite profile sweep is a regression check, not a shortestness theorem.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path


class Poly:
    """Small integer polynomial ring, with canonical commutative monomials."""

    def __init__(self, value=0):
        if isinstance(value, Poly):
            self.terms = dict(value.terms)
        elif isinstance(value, str):
            self.terms = {(value,): 1}
        elif isinstance(value, dict):
            self.terms = {tuple(sorted(k)): v for k, v in value.items() if v}
        else:
            self.terms = {(): value} if value else {}

    def __add__(self, other):
        terms = dict(self.terms)
        for monomial, coefficient in Poly(other).terms.items():
            terms[monomial] = terms.get(monomial, 0) + coefficient
        return Poly(terms)

    __radd__ = __add__

    def __neg__(self):
        return Poly({k: -v for k, v in self.terms.items()})

    def __sub__(self, other):
        return self + -Poly(other)

    def __rsub__(self, other):
        return Poly(other) - self

    def __mul__(self, other):
        terms = {}
        for left, a in self.terms.items():
            for right, b in Poly(other).terms.items():
                monomial = tuple(sorted(left + right))
                terms[monomial] = terms.get(monomial, 0) + a * b
        return Poly(terms)

    __rmul__ = __mul__

    def __eq__(self, other):
        return self.terms == Poly(other).terms

    def evaluate(self, **values):
        result = 0
        for monomial, coefficient in self.terms.items():
            term = coefficient
            for variable in monomial:
                term *= values[variable]
            result += term
        return result

    def __str__(self):
        if not self.terms:
            return "0"
        pieces = []
        for monomial in sorted(self.terms, key=lambda k: (-len(k), k)):
            coefficient = self.terms[monomial]
            product = "*".join(monomial)
            if product:
                text = product if abs(coefficient) == 1 else f"{abs(coefficient)}*{product}"
            else:
                text = str(abs(coefficient))
            if pieces:
                pieces.append((" - " if coefficient < 0 else " + ") + text)
            else:
                pieces.append(("-" if coefficient < 0 else "") + text)
        return "".join(pieces)


@dataclass(frozen=True)
class Node:
    kind: str
    name: str = ""
    children: tuple[Node, ...] = ()
    descriptor: Node | None = None


def var(name):
    return Node("var", name)


zero = Node("const", "0")
bottom = Node("bottom", "false")
x, a, b, c, d, n, r, s, u, v, w, y = map(var, "x a b c d n r s u v w y".split())


def call(name, *children):
    return Node("call", name, tuple(children))


def S(term):
    return call("S", term)


def D(left, right):
    return call("D", left, right)


def Chi(left, right):
    return call("chi", left, right)


def R(body, counter, seed):
    return Node("call", "R", (counter, seed), body)


def Q(first, second):
    return R(w, first, second)


def Z(first, second):
    return R(zero, first, second)


def Eq(left, right):
    return Node("eq", "=", (left, right))


def And(left, right):
    return Node("and", "and", (left, right))


def Or(left, right):
    return Node("or", "or", (left, right))


def Imp(left, right):
    return Node("implies", "->", (left, right))


def Neg(formula):
    return Imp(formula, bottom)


def Ne(left, right):
    return Neg(Eq(left, right))


def C(test, yes, no):
    return Node("conditional", "C", (test, yes, no))


def quant(kind, name, formula):
    return Node(kind, name, (formula,))


def prefix(spec, formula):
    for kind, name in reversed(spec):
        formula = quant(kind, name, formula)
    return formula


def forall(names, formula):
    return prefix([("forall", name) for name in names.split()], formula)


def exists(names, formula):
    return prefix([("exists", name) for name in names.split()], formula)


def substitute(node, replacements):
    """Simultaneous active substitution; descriptors are never traversed.

    All template callers substitute into quantifier-free payloads and use
    fresh witness variables. This is not a general alpha-renaming API.
    """
    if node.kind == "var":
        return replacements.get(node.name, node)
    local = replacements
    if node.kind in {"forall", "exists"}:
        local = {k: value for k, value in replacements.items() if k != node.name}
    return Node(node.kind, node.name,
                tuple(substitute(child, local) for child in node.children),
                node.descriptor)


def at(payload, argument):
    return substitute(payload, {"x": argument})


def symbolic_size(node, full):
    if node.kind in {"schema_formula", "schema_term"}:
        size_name = ("F" if node.kind == "schema_formula" else "T") if full else "m"
        return (Poly(size_name)
                + Poly("i") * (symbolic_size(node.children[0], full) - 1)
                + Poly("j") * (symbolic_size(node.children[1], full) - 1))
    result = Poly(1) + sum((symbolic_size(child, full) for child in node.children), Poly())
    if full and node.descriptor is not None:
        result += symbolic_size(node.descriptor, True)
    return result


def size(node, full=False):
    assert node.kind not in {"schema_formula", "schema_term"}
    result = 1 + sum(size(child, full) for child in node.children)
    if full and node.descriptor is not None:
        result += size(node.descriptor, True)
    return result


def occurrences(node, variable):
    if node.kind == "var":
        return int(node.name == variable)
    if node.kind in {"forall", "exists"} and node.name == variable:
        return 0
    return sum(occurrences(child, variable) for child in node.children)


def expand_conditionals(node):
    children = tuple(expand_conditionals(child) for child in node.children)
    if node.kind == "conditional":
        test, yes, no = children
        return Or(And(test, yes), And(Neg(test), no))
    return Node(node.kind, node.name, children, node.descriptor)


def pretty(node):
    if node.kind in {"var", "const", "bottom"}:
        return node.name
    if node.kind in {"forall", "exists"}:
        return f"{node.kind} {node.name}. {pretty(node.children[0])}"
    if node.kind in {"eq", "and", "or", "implies"}:
        return f"({pretty(node.children[0])} {node.name} {pretty(node.children[1])})"
    name = node.name
    if node.descriptor is not None:
        name += "_{" + pretty(node.descriptor) + "}"
    return name + "(" + ", ".join(map(pretty, node.children)) + ")"


def IND(P):
    return forall("a", Imp(And(at(P, zero), forall("x", Imp(P, at(P, S(x))))),
                           forall("n", at(P, n))))


def bound_IND(P):
    step = forall("x y", Imp(Eq(y, S(x)), Imp(P, at(P, y))))
    return forall("a", Imp(And(at(P, zero), step), forall("n", at(P, n))))


def BC(P):
    body = And(Or(Eq(b, zero), at(P, b)), Imp(at(P, S(b)), Eq(b, n)))
    return forall("a n", exists("b", body))


def BC_shared(P):
    body = And(Eq(d, S(b)), And(Or(Eq(b, zero), at(P, b)), Imp(at(P, d), Eq(b, n))))
    return forall("a n", exists("b d", body))


def CN(P):
    body = C(P, Imp(Eq(x, S(b)), Eq(b, n)), Imp(Eq(x, b), Eq(b, zero)))
    return forall("a n", exists("b", forall("x", body)))


def boundary_three(P):
    body = And(Imp(at(P, b), at(P, n)),
               Or(Eq(b, zero), And(Eq(b, S(c)), at(P, c))))
    return forall("a n", exists("b c", body))


def I3(P):
    closure = forall("b c", Imp(Or(Eq(c, zero), And(Eq(c, S(b)), at(P, b))), at(P, c)))
    return forall("a", Imp(closure, forall("n", at(P, n))))


def DC(P):
    step = forall("x", Imp(Or(Eq(x, zero), P), at(P, S(x))))
    return forall("a", Imp(step, forall("x", Or(Eq(x, zero), P))))


def SP(P):
    step = forall("x", Imp(Or(Eq(x, zero), P), at(P, S(x))))
    return forall("a", Imp(step, forall("x", at(P, S(x)))))


def mask(t, argument, parameter, whole=False, marked=False):
    wrapper = Q if marked else Z
    descriptor = wrapper(t, x) if whole else t
    return Node("call", "M", (argument, parameter), descriptor)


def mask_definition(t, whole=False, marked=False):
    wrapper = Q if marked else Z
    return forall("x a", Eq(mask(t, x, a, whole, marked), wrapper(t, x)))


def mask_witness_matrix(t, shifted=True, whole=False, marked=False):
    point = S(b) if shifted else b
    inner = mask(t, point, a, whole, marked)
    return Eq(mask(t, Q(inner, n), a, whole, marked), zero)


def mask_witness(t, shifted=True, whole=False, marked=False):
    return forall("a n", exists("b", mask_witness_matrix(t, shifted, whole, marked)))


def fused_mask(t, shifted):
    definition = Eq(mask(t, n, a), Z(at(t, n), n))
    return forall("a n", exists("b", And(definition, mask_witness_matrix(t, shifted))))


def recursor_clauses(t):
    body = substitute(t, {"x": v, "a": w})
    base = Eq(R(body, zero, a), a)
    step = Eq(R(body, S(n), a), substitute(t, {"x": R(body, n, a), "a": n}))
    return base, step


def all_fused(t, shifted):
    base, step = recursor_clauses(t)
    definition = Eq(mask(t, n, a), Z(at(t, n), n))
    matrix = And(base, And(step, And(definition, mask_witness_matrix(t, shifted))))
    return forall("a n", exists("b", matrix))


def factored(t, shifted=True, merged=False, shared=False):
    point = (D(b, b) if merged else S(b)) if shifted else b
    value = d if shared else point
    core = And(Eq(c, Q(Z(at(t, value), value), n)), Eq(Z(at(t, c), c), zero))
    if shared:
        core = And(Eq(d, point), core)
    return forall("a n", exists("b d c" if shared else "b c", core))


def FB(t, shared=False):
    point = d if shared else S(b)
    matrix = Eq(Chi(b, Q(Z(at(t, point), point), n)), S(Z(at(t, b), b)))
    if shared:
        matrix = And(Eq(d, S(b)), matrix)
    return forall("a n", exists("b d" if shared else "b", matrix))


def FB_table(t):
    core = Eq(Chi(b, Q(Z(r, S(b)), n)), S(Z(s, b)))
    guard = Or(And(Eq(x, b), Eq(y, s)), And(Eq(x, S(b)), Eq(y, r)))
    table = forall("x y", Imp(guard, Eq(t, y)))
    return forall("a n", exists("b r s", And(core, table)))


def DB(t):
    matrix = Eq(Q(at(t, S(b)), at(t, b)), Q(at(t, n), at(t, zero)))
    return forall("a n", exists("b", matrix))


def NT(t, boolean=False, guard=False):
    right = Eq(t, Chi(x, b)) if boolean else Eq(Chi(t, zero), Chi(x, S(b)))
    if guard:
        left = Or(And(Eq(x, b), Ne(b, zero)), And(Eq(x, S(b)), Ne(b, n)))
        matrix = Imp(left, right)
    else:
        left = And(Imp(Eq(x, b), Eq(b, zero)), Imp(Eq(x, S(b)), Eq(b, n)))
        matrix = Or(left, right)
    return forall("a n", exists("b", forall("x", matrix)))


def successor_NT(t, shared=False):
    point = y if shared else S(x)
    guard = Or(Eq(point, b), And(Eq(x, b), Ne(b, n)))
    matrix = Imp(guard, Eq(Chi(at(t, point), zero), Chi(x, b)))
    if shared:
        matrix = forall("y", Imp(Eq(y, S(x)), matrix))
    return forall("a n", exists("b", forall("x", matrix)))


NATIVE = {
    "ordinary_IND": IND,
    "bound_IND": bound_IND,
    "native_BC": BC,
    "native_BC_shared": BC_shared,
    "boundary_three": boundary_three,
    "mask_free_I3": I3,
    "direct_closure": DC,
    "successor_propagation": SP,
    "new_CN": CN,
    "new_CN_expanded": lambda P: expand_conditionals(CN(P)),
}

RAW = {
    "tail_mask_definition": lambda t: mask_definition(t),
    "tail_mask_shifted_witness": lambda t: mask_witness(t),
    "tail_mask_unshifted_witness": lambda t: mask_witness(t, shifted=False),
    "whole_mask_definition": lambda t: mask_definition(t, whole=True),
    "whole_mask_shifted_witness": lambda t: mask_witness(t, whole=True),
    "whole_mask_unshifted_witness": lambda t: mask_witness(t, shifted=False, whole=True),
    "marked_mask_definition": lambda t: mask_definition(t, whole=True, marked=True),
    "marked_mask_shifted_witness": lambda t: mask_witness(t, whole=True, marked=True),
    "Boolean_tail_mask_definition": lambda t: mask_definition(t, marked=True),
    "Boolean_tail_mask_shifted_witness": lambda t: mask_witness(t, marked=True),
    "Boolean_tail_mask_unshifted_witness": lambda t: mask_witness(t, shifted=False, marked=True),
    "fused_mask_F13": lambda t: fused_mask(t, True),
    "fused_mask_F12": lambda t: fused_mask(t, False),
    "recursor_base": lambda t: forall("a", recursor_clauses(t)[0]),
    "recursor_step": lambda t: forall("a n", recursor_clauses(t)[1]),
    "all_four_fused_shifted": lambda t: all_fused(t, True),
    "all_four_fused_unshifted": lambda t: all_fused(t, False),
    "factored_S": factored,
    "factored_D": lambda t: factored(t, merged=True),
    "factored_unshifted": lambda t: factored(t, shifted=False),
    "factored_D_shared": lambda t: factored(t, merged=True, shared=True),
    "fused_FB": FB,
    "fused_FB_shared": lambda t: FB(t, True),
    "fused_FB_table": FB_table,
    "direct_Boolean_DB": DB,
    "new_NT_raw": NT,
    "new_NT_Boolean": lambda t: NT(t, boolean=True),
    "new_NT_guard": lambda t: NT(t, guard=True),
    "new_successor_NT": successor_NT,
    "new_successor_NT_shared": lambda t: successor_NT(t, shared=True),
}


def costs(node):
    return {"active": size(node), "full": size(node, True)}


def symbolic_records():
    P = Node("schema_formula", "P", (x, a))
    t = Node("schema_term", "t", (x, a))
    m, F, T, i = map(Poly, ("m", "F", "T", "i"))
    expected_native = {
        "ordinary_IND": (4*m+i+6, 4*F+i+6),
        "bound_IND": (4*m+12, 4*F+12),
        "native_BC": (2*m+i+12, 2*F+i+12),
        "native_BC_shared": (2*m+18, 2*F+18),
        "boundary_three": (3*m+15, 3*F+15),
        "mask_free_I3": (3*m+15, 3*F+15),
        "direct_closure": (3*m+i+13, 3*F+i+13),
        "successor_propagation": (3*m+2*i+9, 3*F+2*i+9),
        "new_CN": (m+20, F+20),
        "new_CN_expanded": (2*m+24, 2*F+24),
    }
    expected_raw = {
        "tail_mask_definition": (m+8, 2*T+9),
        "tail_mask_shifted_witness": (13, 2*T+14),
        "tail_mask_unshifted_witness": (12, 2*T+13),
        "whole_mask_definition": (m+8, 2*T+12),
        "whole_mask_shifted_witness": (13, 2*T+20),
        "whole_mask_unshifted_witness": (12, 2*T+19),
        "marked_mask_definition": (m+8, 2*T+12),
        "marked_mask_shifted_witness": (13, 2*T+20),
        "Boolean_tail_mask_definition": (m+8, 2*T+9),
        "Boolean_tail_mask_shifted_witness": (13, 2*T+14),
        "Boolean_tail_mask_unshifted_witness": (12, 2*T+13),
        "fused_mask_F13": (m+20, 4*T+22),
        "fused_mask_F12": (m+19, 4*T+21),
        "recursor_base": (6, T+6),
        "recursor_step": (m+2*i+7, 2*T+i*T+2*i+7),
        "all_four_fused_shifted": (2*m+2*i+32, (7+i)*T+2*i+34),
        "all_four_fused_unshifted": (2*m+2*i+31, (7+i)*T+2*i+33),
        "factored_S": (2*m+i+16, 2*T+i+19),
        "factored_D": (2*m+2*i+17, 2*T+2*i+20),
        "factored_unshifted": (2*m+15, 2*T+18),
        "factored_D_shared": (2*m+22, 2*T+25),
        "fused_FB": (2*m+i+14, 2*T+i+17),
        "fused_FB_shared": (2*m+19, 2*T+22),
        "fused_FB_table": (m+40, T+43),
        "direct_Boolean_DB": (4*m+i+6, 4*T+i+8),
        "new_NT_raw": (m+28, T+28),
        "new_NT_Boolean": (m+25, T+25),
        "new_NT_guard": (m+32, T+32),
        "new_successor_NT": (m+i+25, T+i+25),
        "new_successor_NT_shared": (m+30, T+30),
    }
    result = {}
    for family, payload, builders, expected in (
            ("native", P, NATIVE, expected_native), ("raw", t, RAW, expected_raw)):
        for name, builder in builders.items():
            tree = builder(payload)
            active, full = symbolic_size(tree, False), symbolic_size(tree, True)
            assert active == expected[name][0], (name, "active", str(active))
            assert full == expected[name][1], (name, "full", str(full))
            result[name] = {"family": family, "active": str(active), "full": str(full),
                            "literal_template": pretty(tree),
                            "_active_poly": active, "_full_poly": full}
    return result


def fixed_records():
    sep = Ne(zero, S(zero))
    bit = forall("x y", And(Eq(Chi(x, x), S(zero)), Or(Eq(x, y), Eq(Chi(x, y), zero))))
    off = forall("x y", Or(Eq(x, y), Eq(Chi(x, y), zero)))
    diag = forall("x", Eq(Chi(x, x), S(zero)))
    cov = forall("x", exists("y", Or(Eq(x, zero), Eq(x, S(y)))))
    part = forall("x", exists("y", Ne(Chi(x, zero), Chi(x, S(y)))))
    nontriv = exists("u", Ne(u, zero))
    off_D = forall("x y", Or(Eq(x, y), Eq(D(x, y), zero)))
    part_D = forall("x", exists("y", Ne(D(x, zero), D(x, D(y, y)))))
    trees = {"Sep": sep, "Bit": bit, "Off": off, "Diag": diag, "Coverage": cov,
             "Partition": part, "Nontriviality": nontriv, "Off_D": off_D, "Partition_D": part_D}
    expected = {"Sep": 6, "Bit": 18, "Off": 11, "Diag": 7, "Coverage": 10,
                "Partition": 12, "Nontriviality": 6, "Off_D": 11, "Partition_D": 13}
    for name, tree in trees.items():
        assert size(tree) == size(tree, True) == expected[name]
    return {name: {**costs(tree), "literal_formula": pretty(tree)} for name, tree in trees.items()}


def pick_full(named_nodes):
    """Select by FULL size; retain every full-size tie and use declared order."""
    records = [{"name": name, **costs(node)} for name, node in named_nodes]
    best = min(record["full"] for record in records)
    winners = [record["name"] for record in records if record["full"] == best]
    return {"minimum_full": best, "selected": winners[0], "all_full_ties": winners,
            "candidates": records}


def is_boolean_tail(node):
    """Literal grammar from the current DB proposal; no semantic test."""
    if node in {zero, S(zero)}:
        return True
    if node.kind == "call" and node.name == "chi" and len(node.children) == 2:
        return True
    return (node.kind == "call" and node.name == "R" and node.descriptor == w
            and len(node.children) == 2 and all(is_boolean_tail(child) for child in node.children))


def choose_native_primary(P):
    F, i = size(P, True), occurrences(P, "x")
    if i == 0:
        return {"selected": "omit_variable_absent", "minimum_full": 0,
                "reason": "The same-formula induction implication is a logical theorem when x is absent."}
    result = pick_full([("native_BC", BC(P)), ("new_CN", CN(P))])
    assert result["selected"] == ("native_BC" if F+i <= 8 else "new_CN")
    return result


def enhanced_raw_candidates(t):
    candidates = [("fused_FB", FB(t)), ("factored_unshifted", factored(t, shifted=False)),
                  ("new_NT_raw", NT(t))]
    if is_boolean_tail(t):
        candidates.extend([("direct_Boolean_DB", DB(t)), ("new_NT_Boolean", NT(t, boolean=True))])
    return candidates


def examples(symbolic):
    nested_descriptor = R(Q(v, zero), w, S(v))
    nested = R(nested_descriptor, x, a)
    formulas = [
        ("false", bottom),
        ("equality_with_parameter", Eq(x, a)),
        ("diagonal_equality", Eq(x, x)),
        ("successor_congruence", Imp(Eq(x, a), Eq(S(x), S(a)))),
        ("nested_frozen_recursors", Eq(nested, a)),
        ("mixed_connectives", And(Or(Eq(x, a), Eq(S(x), zero)),
                                  Imp(Eq(x, x), Eq(Q(x, a), Z(a, x))))),
    ]
    tall = x
    for _ in range(15):
        tall = S(tall)
    terms = [
        ("diagonal_bootstrap_parameter", a),
        ("input_variable", x),
        ("equality_bit", Chi(x, a)),
        ("long_successor_term", tall),
        ("nested_frozen_recursors", nested),
        ("many_input_occurrences", Chi(Chi(Chi(x, x), x), Chi(x, Chi(x, x)))),
    ]
    output = {"formulas": [], "terms": []}
    for family, fixtures, builders in (("formulas", formulas, NATIVE), ("terms", terms, RAW)):
        for name, payload in fixtures:
            profile = {"m": size(payload), "F": size(payload, True), "T": size(payload, True),
                       "i": occurrences(payload, "x"), "j": occurrences(payload, "a")}
            counted = {}
            for template, builder in builders.items():
                tree = builder(payload)
                count = costs(tree)
                assert count["active"] == symbolic[template]["_active_poly"].evaluate(**profile)
                assert count["full"] == symbolic[template]["_full_poly"].evaluate(**profile)
                counted[template] = {**count, "literal_formula": pretty(tree)}
            record = {"name": name, "literal_payload": pretty(payload), "profile": profile,
                      "counts": counted}
            if family == "formulas":
                record["optimized_native"] = pick_full([
                    ("ordinary_IND", IND(payload)), ("bound_IND", bound_IND(payload)),
                    ("native_BC", BC(payload)), ("new_CN", CN(payload))])
                record["primary_native_B_or_C"] = choose_native_primary(payload)
                if profile["i"]:
                    assert record["primary_native_B_or_C"]["minimum_full"] == record["optimized_native"]["minimum_full"]
            else:
                record["old_fused_frontier"] = pick_full([
                    ("fused_FB", FB(payload)), ("fused_FB_shared", FB(payload, True)),
                    ("fused_FB_table", FB_table(payload))])
                record["new_raw_frontier"] = pick_full([
                    ("fused_FB", FB(payload)), ("fused_FB_shared", FB(payload, True)),
                    ("new_NT_raw", NT(payload))])
                record["syntactically_Boolean"] = is_boolean_tail(payload)
                record["enhanced_raw_frontier"] = pick_full(enhanced_raw_candidates(payload))
            output[family].append(record)
    # Adversarial fixture: a substitution must leave descriptor occurrences frozen.
    frozen = R(Q(v, zero), v, a)
    changed = substitute(frozen, {"v": S(v)})
    assert changed.descriptor is frozen.descriptor
    assert size(changed) - size(frozen) == 1
    assert size(changed, True) - size(frozen, True) == 1
    output["frozen_substitution_check"] = {
        "before": pretty(frozen), "after": pretty(changed),
        "before_count": costs(frozen), "after_count": costs(changed),
        "descriptor_unchanged": True}
    # Both full-size ties and differing active/full objectives must be preserved.
    artificial_tie = pick_full([("Q(x,a)", Q(x, a)), ("S(S(S(x)))", S(S(S(x))))])
    assert artificial_tie["all_full_ties"] == ["Q(x,a)", "S(S(S(x)))"]
    assert artificial_tie["candidates"][0]["active"] != artificial_tie["candidates"][1]["active"]
    output["full_tie_check"] = artificial_tie
    # Two explicit bootstrap instances make the enhanced raw emitter noncircular.
    coverage_P = Or(Eq(x, zero), Eq(x, S(Q(x, zero))))
    coverage_bit = Q(Q(Chi(x, zero), Q(Chi(x, S(Q(x, zero))), S(zero))), S(zero))
    assert costs(coverage_P) == {"active": 10, "full": 11}
    assert occurrences(coverage_P, "x") == 3
    assert costs(coverage_bit) == {"active": 16, "full": 20}
    assert occurrences(coverage_bit, "x") == 3
    diag_choice = pick_full(enhanced_raw_candidates(a))
    coverage_choice = pick_full(enhanced_raw_candidates(coverage_bit))
    assert diag_choice["selected"] == "fused_FB" and diag_choice["minimum_full"] == 19
    assert coverage_choice["selected"] == "new_NT_Boolean" and coverage_choice["minimum_full"] == 45
    output["enhanced_raw_bootstrap"] = {
        "diagonal_tail": pretty(a), "diagonal_choice": diag_choice,
        "coverage_formula": pretty(coverage_P), "coverage_formula_count": costs(coverage_P),
        "coverage_truth_tail": pretty(coverage_bit), "coverage_tail_count": costs(coverage_bit),
        "coverage_input_occurrences": 3, "coverage_choice": coverage_choice,
        "fixed_plus_two_bootstrap_full": 17+19+45,
        "qualification": "81 is the fixed17 seed plus the shared19-node Diag and45-node coverage instances. Ordinary arithmetic support, including the no-fixed-point recursor, is additional shared support. This is not a claim that these finite instances axiomatize PRA."}
    return output


def profile_sweep():
    native_checks = raw_checks = 0
    native_ties = []
    for F in range(1, 97):
        # Necessary generous binary-tree range; not every profile is realizable.
        for i in range((F + 1) // 2 + 1):
            entries = [("ordinary_IND", 4*F+i+6), ("bound_IND", 4*F+12),
                       ("native_BC", 2*F+i+12), ("new_CN", F+20)]
            best = min(value for _, value in entries)
            assert best <= 4*F+i+6 and best <= 4*F+12 and best <= 2*F+i+12
            # Other current native forms are covered on F>=3, as documented.
            if F >= 3:
                assert best <= min(3*F+15, 3*F+i+13, 3*F+2*i+9)
                primary = 0 if i == 0 else min(2*F+i+12, F+20)
                assert primary <= best
                if i:
                    assert primary == best
            ties = [name for name, value in entries if value == best]
            if len(ties) > 1 and len(native_ties) < 12:
                native_ties.append({"F": F, "i": i, "cost": best, "ties": ties})
            native_checks += 1
    for T in range(1, 129):
        for i in range((T + 1) // 2 + 1):
            old = min(2*T+i+17, 2*T+22, T+43)
            new = min(2*T+i+17, 2*T+22, T+28)
            assert new <= old
            assert T+43 - (T+28) == 15
            assert new <= 4*T+21
            assert min(new, 4*T+i+8, T+25) <= 4*T+i+8
            enhanced = min(2*T+i+17, 2*T+18, T+28)
            assert enhanced <= min(old, 2*T+i+19, 2*T+18, 4*T+21)
            boolean_enhanced = min(enhanced, 4*T+i+8, T+25)
            assert boolean_enhanced <= 4*T+i+8
            # A sufficiently large coverage-tail candidate cannot select FR.
            if T > 10:
                assert T+28 < 2*T+18
            raw_checks += 1
    return {"native_profiles": native_checks, "raw_profiles": raw_checks,
            "native_full_size_ties": native_ties,
            "qualification": "Finite regression checks over necessary size ranges; algebraic certificates below provide the uniform comparisons."}


def archive_index():
    return {
        "archived": {
            "pra_counterexample_masks_2026-11-02.zip": ["tail_mask_definition", "tail_mask_shifted_witness", "tail_mask_unshifted_witness"],
            "pra_index_filters_2026-11-02.zip": ["whole_mask_definition", "whole_mask_shifted_witness", "whole_mask_unshifted_witness"],
            "pra_marked_predecessor_2026-11-02.zip": ["marked_mask_definition", "marked_mask_shifted_witness"],
            "pra_masked_descent_2026-11-02.zip": ["whole_mask_definition", "whole_mask_shifted_witness", "whole_mask_unshifted_witness"],
            "pra_pointwise_masks_2026-11-02.zip": ["whole_mask_definition", "whole_mask_shifted_witness", "whole_mask_unshifted_witness"],
            "pra_pointwise_masks_2026-11-02(1).zip": ["whole_mask_definition", "whole_mask_shifted_witness", "whole_mask_unshifted_witness"],
        },
        "current": {
            "PRA_f6530_Mask_Free_2026-11-02.zip": ["factored_S", "factored_D", "factored_unshifted", "mask_free_I3"],
            "pra_boundary_schema_2026-11-02.zip": ["boundary_three", "fused_mask_F12"],
            "pra_direct_closure_2026-11-02.zip": ["direct_closure", "successor_propagation"],
            "pra_factored_witnesses_2026-11-02.zip": ["factored_S", "factored_D", "factored_unshifted", "factored_D_shared"],
            "pra_fused_boundary_2026-11-02.zip": ["fused_FB", "fused_FB_shared", "fused_FB_table"],
            "pra_native_boundary_2026-11-02.zip": ["native_BC"],
            "pra_simpler_axiomatization_2026-11-02.zip": ["ordinary_IND", "bound_IND", "fused_mask_F13", "fused_mask_F12", "direct_Boolean_DB", "all_four_fused_shifted", "all_four_fused_unshifted"],
            "pra_smaller_modules_f6530de455.zip": ["Boolean_tail_mask_definition", "Boolean_tail_mask_shifted_witness", "Boolean_tail_mask_unshifted_witness"],
        },
        "note": "Index records matching induction modules and the separately labeled all-obligations fusion, not every serialization address. Covered variants require the coverage seed/support stated in the paper; Boolean variants require their literal Boolean grammar. D-language tails must be expanded in D before assigning T."}


def module_records(symbolic):
    specifications = [
        ("archived_tail_shifted", 24, ["tail_mask_definition", "tail_mask_shifted_witness"]),
        ("archived_tail_unshifted_as_printed", 34, ["tail_mask_definition", "tail_mask_unshifted_witness"]),
        ("archived_tail_unshifted_with_compatible_partition", 30, ["tail_mask_definition", "tail_mask_unshifted_witness"]),
        ("archived_whole_shifted", 24, ["whole_mask_definition", "whole_mask_shifted_witness"]),
        ("archived_whole_unshifted", 30, ["whole_mask_definition", "whole_mask_unshifted_witness"]),
        ("archived_marked_shifted", 24, ["marked_mask_definition", "marked_mask_shifted_witness"]),
        ("archived_D_whole_unshifted", 24, ["whole_mask_definition", "whole_mask_unshifted_witness"]),
        ("current_F13", 24, ["fused_mask_F13"]),
        ("current_F12", 30, ["fused_mask_F12"]),
        ("current_D_F12", 24, ["fused_mask_F12"]),
        ("current_factored_S", 24, ["factored_S"]),
        ("current_factored_D", 17, ["factored_D"]),
        ("current_factored_D_covered", 24, ["factored_unshifted"]),
        ("current_factored_D_shared", 17, ["factored_D_shared"]),
        ("current_FB_saturated", 24, ["fused_FB"]),
        ("current_FB_shared_saturated", 24, ["fused_FB_shared"]),
        ("current_FB_table_saturated", 24, ["fused_FB_table"]),
        ("current_DB_Boolean", 24, ["direct_Boolean_DB"]),
        ("current_native_BC", 6, ["native_BC"]),
        ("current_boundary_three", 6, ["boundary_three"]),
        ("current_direct_closure", 6, ["direct_closure"]),
        ("current_SP_with_explicit_coverage", 16, ["successor_propagation"]),
        ("current_native_I3", 6, ["mask_free_I3"]),
        ("current_bound_IND", 6, ["bound_IND"]),
        ("current_improved_Boolean_shifted", 24, ["Boolean_tail_mask_definition", "Boolean_tail_mask_shifted_witness"]),
        ("current_improved_Boolean_covered", 30, ["Boolean_tail_mask_definition", "Boolean_tail_mask_unshifted_witness"]),
        ("new_native_CN", 6, ["new_CN"]),
        ("new_raw_NT_saturated", 24, ["new_NT_raw"]),
        ("all_four_separate_shifted", 24, ["recursor_base", "recursor_step", "tail_mask_definition", "tail_mask_shifted_witness"]),
        ("all_four_fused_shifted", 24, ["all_four_fused_shifted"]),
    ]
    result = {}
    for name, seed, components in specifications:
        active = sum((symbolic[c]["_active_poly"] for c in components), Poly())
        full = sum((symbolic[c]["_full_poly"] for c in components), Poly())
        result[name] = {"component_axioms": components, "active": str(active),
                        "full": str(full), "separately_charged_fixed_seed": seed}
    result["accounting_notes"] = [
        "A module consisting of separate sentences is the sum of their sizes; no conjunction node is added unless it is actually printed.",
        "Fixed seed is a one-time cost, not a fresh surcharge on every module. Shared ordinary recursor support is excluded from induction-only rows on both sides.",
        "Minimal FB fixed seed is17, but its diagonal recovery uses the additional shared t=a instance of full size19. Saturated rows instead retain the7-node Diag axiom, yielding seed24.",
        "Successor propagation without explicit coverage has seed6 but the published shared coverage-bootstrap instance costs117 full nodes.",
        "The last two rows include recursor obligations; their sizes must not be compared directly with induction-only rows.",
    ]
    return result


def improved_compiler_records():
    contexts = {"and": Q(Chi(u, zero), v),
                "or": Chi(Q(u, Chi(v, zero)), zero),
                "implies": Chi(Q(v, u), zero)}
    expected = {"and": (3, 4), "or": (5, 6), "implies": (3, 4)}
    result = {}
    for name, context in contexts.items():
        active, full = size(context)-2, size(context, True)-2
        assert (active, full) == expected[name]
        assert occurrences(context, "u") == occurrences(context, "v") == 1
        result[name] = {"literal_context": pretty(context),
                        "active_overhead": active, "full_overhead": full,
                        "child_occurrences": [1, 1]}
    return result


def algebraic_certificates(symbolic):
    F, T, i = map(Poly, ("F", "T", "i"))
    equations = {
        "BC_minus_CN": symbolic["native_BC"]["_full_poly"] - symbolic["new_CN"]["_full_poly"],
        "old_single_tail_minus_NT": symbolic["fused_FB_table"]["_full_poly"] - symbolic["new_NT_raw"]["_full_poly"],
        "guard_minus_disjunctive_NT": symbolic["new_NT_guard"]["_full_poly"] - symbolic["new_NT_raw"]["_full_poly"],
        "three_copy_minus_BC": symbolic["boundary_three"]["_full_poly"] - symbolic["native_BC"]["_full_poly"],
        "direct_closure_minus_BC": symbolic["direct_closure"]["_full_poly"] - symbolic["native_BC"]["_full_poly"],
        "SP_minus_BC": symbolic["successor_propagation"]["_full_poly"] - symbolic["native_BC"]["_full_poly"],
        "native_IND_minus_BC": symbolic["ordinary_IND"]["_full_poly"] - symbolic["native_BC"]["_full_poly"],
        "best_mask_minus_FB": symbolic["fused_mask_F12"]["_full_poly"] - symbolic["fused_FB"]["_full_poly"],
    }
    assert equations["BC_minus_CN"] == F+i-8
    assert equations["old_single_tail_minus_NT"] == 15
    assert equations["guard_minus_disjunctive_NT"] == 4
    assert equations["three_copy_minus_BC"] == F-i+3
    assert equations["direct_closure_minus_BC"] == F+1
    assert equations["SP_minus_BC"] == F+i-3
    assert equations["native_IND_minus_BC"] == 2*F-6
    assert equations["best_mask_minus_FB"] == 2*T-i+4
    return {"exact_differences": {name: str(poly) for name, poly in equations.items()},
            "uniform_arguments": [
                "The optimized native minimum is <= each of its four candidate costs by definition; selection is by full size.",
                "For native formulas F>=3 and i<=F, the other native current costs minus BC are nonnegative as listed.",
                "Replacing the T+43 candidate by T+28 cannot increase a minimum: common candidates are identical, and the replacement is exactly15 smaller.",
                "The best fused-mask block exceeds FB by2T-i+4 >= T+4 >0 for0<=i<=T.",
                "Keeping DB as an optional Boolean candidate explicitly handles its favorable tiny-tail costs.",
                "The enhanced raw frontier is min{FB,FR,NT}, plus DB and BooleanNT only on the literal Boolean grammar. FR=2T+18 dominates the older FB-sharing cost2T+22 by4.",
                "The exact t=a Diag bootstrap selects FB19. The explicit coverage truth tail hasT20 and selects BooleanNT45. Hence every FR use occurs only after a coverage derivation using a non-FR selected instance.",
                "For i>0 andF>=3, old ordinary IND minusBC is2F-6>=0 and boundIND minusBC is2F-i>=0; therefore the four-way native minimum equals min{BC,CN}. ChooseBC iffF+i<=8. Ifi=0, omit the logically redundant induction instance.",
                "The CN size advantage uses primitive C. Expanding its strong conditional is fully charged as2F+24; no same-basis inequality is asserted between F+20 and old formulas when C is disallowed.",
            ]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_suffix(".json"))
    args = parser.parse_args()
    symbolic = symbolic_records()
    result = {
        "status": "PASS",
        "snapshot": "b306aef970d43d582765a1daef9d1734aa83978e",
        "metric": {"node_cost": 1, "binder_annotations": 0,
                   "negation": "A -> false", "one": "S(0)",
                   "full_descriptors": "charged recursively at every generated-function occurrence, without free sharing",
                   "conditional": "primitive C has one node; expanded C(A,U,V)=(A and U) or ((A -> false) and V)",
                   "selection": "minimum full size, all ties recorded; declared candidate order breaks ties"},
        "fixed_axioms": fixed_records(),
        "symbolic_templates": {name: {key: value for key, value in data.items() if not key.startswith("_")}
                               for name, data in symbolic.items()},
        "examples": examples(symbolic),
        "profile_checks": profile_sweep(),
        "algebraic_certificates": algebraic_certificates(symbolic),
        "complete_modules": module_records(symbolic),
        "added_draft_Boolean_compiler": improved_compiler_records(),
        "archive_index": archive_index(),
        "limits": ["This is a syntax checker, not a proof of bi-interpretability or absolute shortestness.",
                   "Native formula F and compiled raw-tail T are distinct inputs; no free cross-language translation is assumed.",
                   "Finite supporting axioms such as coverage, exact bits, and their bootstrap instances must be charged as specified in the paper."]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "templates": len(symbolic),
                      "predicate_examples": len(result["examples"]["formulas"]),
                      "term_examples": len(result["examples"]["terms"]),
                      "native_profiles": result["profile_checks"]["native_profiles"],
                      "raw_profiles": result["profile_checks"]["raw_profiles"],
                      "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
