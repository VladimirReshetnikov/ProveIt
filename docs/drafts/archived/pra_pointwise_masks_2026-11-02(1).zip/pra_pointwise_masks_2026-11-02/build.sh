#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 verification/kernel/check_kernel.py
python3 verification/check_mask_kernel.py
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
