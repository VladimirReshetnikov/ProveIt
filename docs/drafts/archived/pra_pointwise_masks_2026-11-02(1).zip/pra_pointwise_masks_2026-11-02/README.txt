PRA BY POINTWISE MASKS
November 2, 2026

Main deliverables
  report.tex / report.pdf     Complete paper and compiled PDF.
  sections/                  LaTeX source chapters.
  verification/              Exact counts, finite checks, proof certificate.
  provenance/                Pinned source snapshot and hashes.
  build.sh                   Standard-library checks and PDF rebuild.

RESULT
One generated binary family F_h is dispatched by a literal body test.
If h(v,w) is Z(t(v,w),v), F_h is a direct pointwise mask; otherwise it
is an initialized recursor. The main witness is

  forall a n, exists b, F_h(Q(F_h(S b,a),n),a) = 0.

It has 13 active nodes and 14+2W full nodes, with no coverage axiom.
Its explicit definition plus witness costs 19+m / 20+4W, compared
with at least 29+m / 31+6W for the current same-body initialized latch
and best witness, on the shared grammar with identical canonical frozen
descriptions. A 12-node variant adds a fixed partition principle.
Both theories have a common conservative definitional extension with
first-order PRA, including identity round trips on the whole carrier.

SCOPE OF THE SIMPLICITY CLAIM
This is a strict comparison of induction witnesses and complete selected
function blocks. It is not a language-independent global minimum, not
strict pointwise domination of old raw-input serializer addresses, and
not a claim that every finite program/proof becomes smaller. An escaped
recursion body adds two active and three full nodes when an old latch
trajectory is also needed. The paper explicitly accounts for that cost.

VERIFICATION SCOPE
The checked first-order proof certificate covers the abstract mask
kernel only. Python finite tests and AST counts do not establish the
whole equivalence theorem. The full staged-language, pairing, compilation,
and bi-interpretability arguments are written mathematical proofs in
the paper. No Lean or Rocq compilation is claimed.

REBUILD
  python3 verification/kernel/check_kernel.py
  python3 verification/check_mask_kernel.py
  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

or execute ./build.sh. Python 3 standard library and a standard TeX Live
installation suffice. The source snapshot is immutable and recorded
in provenance/source_manifest.json.
