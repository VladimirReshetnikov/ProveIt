#!/usr/bin/env python3
"""Independent finite checks for the hybrid pointwise-mask PRA presentation.

This is a syntax and finite standard-model checker, not a formal proof of PRA
equivalence. It uses only Python's standard library. Run it from any directory;
count_results.json is written beside this file.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import hashlib
import itertools
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    body: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple["Term | Formula", ...]


def var(name: str) -> Term:
    return Term(name)


ZERO = Term("0")
V, W = var("v"), var("w")
N, A, B, C, X, Y = map(var, ("n", "a", "b", "c", "x", "y"))


def successor(value: Term) -> Term:
    return Term("S", (value,))


def bit(left: Term, right: Term) -> Term:
    return Term("chi", (left, right))


def generated(body: Term, first: Term, second: Term) -> Term:
    return Term("F", (first, second), body)


def q(first: Term, second: Term) -> Term:
    return generated(W, first, second)


def z(first: Term, second: Term) -> Term:
    return generated(ZERO, first, second)


def mask_body(tail: Term) -> Term:
    return z(tail, V)


def is_mask(body: Term) -> bool:
    return body.tag == "F" and body.body == ZERO and body.args[1] == V


def escape(body: Term) -> Term:
    return z(ZERO, body)


def is_root_normalization_redex(term: Term) -> bool:
    """The legacy rule strips precisely an outer Q(Sr,s)."""
    return term.tag == "F" and term.body == W and term.args[0].tag == "S"


def root_normalize(term: Term) -> Term:
    while is_root_normalization_redex(term):
        term = term.args[0].args[0]
    return term


@lru_cache(maxsize=None)
def canonical_stored_descriptions(term: Term) -> bool:
    """Membership in the common legacy grammar, recursively through bodies.

    Active arguments may contain Q(Sr,s); every stored function description
    must already be root-normal. The test also enters nested descriptions.
    """
    if term.body is not None:
        if is_root_normalization_redex(term.body):
            return False
        if not canonical_stored_descriptions(term.body):
            return False
    return all(canonical_stored_descriptions(child) for child in term.args)


def normalize_stored_descriptions(term: Term) -> Term:
    """Normalize stored bodies only, preserving ordinary active subterms."""
    body = term.body
    if body is not None:
        body = root_normalize(normalize_stored_descriptions(body))
    return Term(
        term.tag,
        tuple(normalize_stored_descriptions(child) for child in term.args),
        body,
    )


def equality(left: Term, right: Term) -> Formula:
    return Formula("=", (left, right))


def connective(tag: str, left: Formula, right: Formula) -> Formula:
    return Formula(tag, (left, right))


def bind(kind: str, variables: tuple[Term, ...], formula: Formula) -> Formula:
    # Binder labels are metadata, not additional syntax-tree nodes.
    for variable in reversed(variables):
        formula = Formula(f"{kind}:{variable.tag}", (formula,))
    return formula


@lru_cache(maxsize=None)
def size(node: Term | Formula, full: bool = False) -> int:
    if isinstance(node, Formula):
        return 1 + sum(size(child, full) for child in node.children)
    answer = 1 + sum(size(child, full) for child in node.args)
    if full and node.body is not None:
        answer += size(node.body, True)
    return answer


@lru_cache(maxsize=None)
def occurrences(term: Term, variable: Term) -> int:
    # Deliberately do not inspect stored descriptions.
    if term == variable:
        return 1
    return sum(occurrences(child, variable) for child in term.args)


def substitute(term: Term, replacements: dict[Term, Term]) -> Term:
    """Simultaneous active substitution; stored bodies remain frozen."""
    if term in replacements:
        return replacements[term]
    return Term(
        term.tag,
        tuple(substitute(child, replacements) for child in term.args),
        term.body,
    )


def mask_definition(body: Term) -> Formula:
    return bind("forall", (X, A), equality(
        generated(body, X, A), substitute(body, {V: X, W: A})
    ))


def mask_witness(body: Term) -> Formula:
    inner = generated(body, successor(B), A)
    outer = generated(body, q(inner, N), A)
    return bind("forall", (A, N), bind("exists", (B,), equality(outer, ZERO)))


def unshifted_mask_witness(body: Term) -> Formula:
    inner = generated(body, B, A)
    outer = generated(body, q(inner, N), A)
    return bind("forall", (A, N), bind("exists", (B,), equality(outer, ZERO)))


def fixed_axioms() -> tuple[list[Formula], list[Formula]]:
    bottom = Formula("bottom", ())
    separation = connective("implies", equality(ZERO, successor(ZERO)), bottom)
    diagonal = equality(bit(X, X), successor(ZERO))
    off_diagonal = connective("or", equality(X, Y), equality(bit(X, Y), ZERO))
    main = [separation, bind("forall", (X,), diagonal),
            bind("forall", (X, Y), off_diagonal)]
    exact_bit = bind("forall", (X, Y), connective("and", diagonal, off_diagonal))
    partition_matrix = connective(
        "implies", equality(bit(X, ZERO), bit(X, successor(Y))), bottom
    )
    partition = bind("forall", (X,), bind("exists", (Y,), partition_matrix))
    return main, [exact_bit, partition]


def predecessor_witness(body: Term) -> Formula:
    inner = generated(body, B, A)
    outer = generated(body, q(z(inner, B), N), A)
    return bind("forall", (A, N), bind("exists", (B,), equality(outer, A)))


def ordinary_computation(body: Term) -> Formula:
    base = equality(generated(body, ZERO, A), A)
    previous = generated(body, N, A)
    step = equality(
        generated(body, successor(N), A),
        substitute(body, {V: previous, W: N}),
    )
    return bind("forall", (A, N), connective("and", base, step))


def bound_computation(body: Term) -> Formula:
    base = equality(generated(body, ZERO, A), A)
    previous = equality(generated(body, N, A), C)
    step = equality(
        generated(body, successor(N), A), substitute(body, {V: C, W: N})
    )
    bound_step = bind("forall", (C,), connective("implies", previous, step))
    return bind("forall", (A, N), connective("and", base, bound_step))


def right_computation(body: Term) -> Formula:
    base = equality(generated(body, ZERO, A), A)
    step = equality(
        generated(body, successor(N), A),
        generated(body, N, substitute(body, {V: A, W: ZERO})),
    )
    return bind("forall", (A, N), connective("and", base, step))


def separated_computation(body: Term) -> tuple[Formula, Formula]:
    base = bind("forall", (A,), equality(generated(body, ZERO, A), A))
    previous = equality(generated(body, N, A), C)
    step = equality(
        generated(body, successor(N), A), substitute(body, {V: C, W: N})
    )
    return base, bind("forall", (A, N, C), connective("implies", previous, step))


def generated_tails() -> list[Term]:
    """All 771 small terms, plus deterministic terms with frozen descriptions."""
    by_size: dict[int, list[Term]] = {1: [ZERO, V, W]}
    for total in range(2, 6):
        terms = [successor(child) for child in by_size[total - 1]]
        for left_size in range(1, total - 1):
            right_size = total - 1 - left_size
            for left, right in itertools.product(
                by_size[left_size], by_size[right_size]
            ):
                terms.extend((bit(left, right), q(left, right), z(left, right)))
        by_size[total] = terms
    terms = [term for total in range(1, 6) for term in by_size[total]]
    assert len(terms) == len(set(terms)) == 771

    # These descriptions are finite and have no self-reference. Their active
    # arguments may use v,w, while the stored description is kept frozen.
    previous_bodies = [V, successor(V), successor(successor(V)), bit(V, W)]
    for body in previous_bodies:
        for first, second in itertools.product((ZERO, V, W), repeat=2):
            terms.append(generated(body, first, second))
    for tail in (V, W, bit(V, W), successor(W)):
        body = mask_body(tail)
        terms.extend((generated(body, V, W), generated(escape(body), V, W)))

    rng = random.Random(20261102)
    pool = list(dict.fromkeys(terms))
    for _ in range(80):
        left, right = rng.choice(pool), rng.choice(pool)
        terms.append(rng.choice((bit, q, z))(left, right))
    # This genuinely new noncanonical name is checked syntactically and
    # semantically, but must be excluded from matched legacy comparisons.
    double_pad_v = q(successor(q(successor(V), W)), W)
    terms.append(generated(double_pad_v, V, W))
    return list(dict.fromkeys(terms))


@lru_cache(maxsize=None)
def evaluate(term: Term, first: int, second: int) -> int:
    if term == ZERO:
        return 0
    if term == V:
        return first
    if term == W:
        return second
    values = tuple(evaluate(child, first, second) for child in term.args)
    if term.tag == "S":
        return values[0] + 1
    if term.tag == "chi":
        return int(values[0] == values[1])
    if term.tag != "F" or term.body is None:
        raise ValueError(f"Unexpected evaluation node: {term}")
    index, seed = values
    body = term.body
    if body == W:
        return seed if index == 0 else index - 1
    if body == ZERO:
        return seed if index == 0 else 0
    if is_mask(body):
        return evaluate(body, index, seed)
    return iterate_body(body, index, seed)


@lru_cache(maxsize=None)
def iterate_body(body: Term, index: int, seed: int) -> int:
    state = seed
    for counter in range(index):
        state = evaluate(body, state, counter)
    return state


def natural_q(first: int, second: int) -> int:
    return second if first == 0 else first - 1


def natural_z(first: int, second: int) -> int:
    return second if first == 0 else 0


def run_checks() -> dict:
    tails = generated_tails()
    minimum_savings = {"active": None, "full": None}
    smallest_example = None
    total_syntax_comparisons = 0
    semantic_cases = 0
    last_zero_cases = 0
    optional_unshifted_cases = 0
    escape_cases = 0
    old_witness_cases = 0
    common_grammar_bodies = 0
    noncanonical_bodies = 0

    # Frozen substitution is a semantic requirement of the descriptions.
    frozen_body = bit(V, W)
    original = generated(frozen_body, V, W)
    replaced = substitute(original, {V: successor(V), W: ZERO})
    assert replaced.body == frozen_body
    assert replaced.args == (successor(V), ZERO)
    assert occurrences(generated(frozen_body, ZERO, ZERO), V) == 0

    main_seed, optional_seed = fixed_axioms()
    for full in (False, True):
        assert sum(size(item, full) for item in main_seed) == 24
        assert [size(item, full) for item in optional_seed] == [18, 12]

    for tail in tails:
        body = mask_body(tail)
        assert is_mask(body)
        assert not is_mask(escape(body))
        assert size(escape(body)) == size(body) + 2
        assert size(escape(body), True) == size(body, True) + 3
        mu, weight = size(body), size(body, True)
        count_v = occurrences(body, V)
        count_w = occurrences(body, W)
        assert count_v >= 1
        comparable_to_legacy = canonical_stored_descriptions(body)
        if comparable_to_legacy:
            common_grammar_bodies += 1
        else:
            noncanonical_bodies += 1

        definition, witness = mask_definition(body), mask_witness(body)
        optional_witness = unshifted_mask_witness(body)
        old_witness = predecessor_witness(body)
        ordinary = ordinary_computation(body)
        bounded = bound_computation(body)
        separated = separated_computation(body)
        assert (size(definition), size(definition, True)) == (6 + mu, 6 + 2 * weight)
        assert (size(witness), size(witness, True)) == (13, 14 + 2 * weight)
        assert (size(optional_witness), size(optional_witness, True)) == (12, 13 + 2 * weight)
        assert (size(old_witness), size(old_witness, True)) == (14, 16 + 2 * weight)
        assert (size(ordinary), size(ordinary, True)) == (
            13 + mu + 2 * count_v,
            13 + (3 + count_v) * weight + 2 * count_v,
        )
        assert (size(bounded), size(bounded, True)) == (20 + mu, 20 + 4 * weight)
        assert sum(size(item) for item in separated) == size(bounded)
        assert sum(size(item, True) for item in separated) == size(bounded, True)

        incumbents = [ordinary, bounded]
        if count_w == 0:
            right = right_computation(body)
            assert (size(right), size(right, True)) == (15 + mu, 15 + 4 * weight)
            incumbents.append(right)
        new_active = size(definition) + size(witness)
        new_full = size(definition, True) + size(witness, True)
        assert (new_active, new_full) == (19 + mu, 20 + 4 * weight)
        assert size(definition) + size(optional_witness) == 18 + mu
        assert size(definition, True) + size(optional_witness, True) == 19 + 4 * weight
        best_old_active = min(size(item) for item in incumbents) + size(old_witness)
        best_old_full = min(size(item, True) for item in incumbents) + size(old_witness, True)
        # These formula templates can be counted for arbitrary new syntax,
        # but are incumbent formulas only on the common canonical grammar.
        if comparable_to_legacy:
            assert best_old_active >= 29 + mu
            assert best_old_full >= 31 + 6 * weight
            for incumbent in incumbents:
                assert size(incumbent) + size(old_witness) - new_active >= 10
                assert size(incumbent, True) + size(old_witness, True) - new_full >= 11 + 2 * weight
                total_syntax_comparisons += 1
            savings = {"active": best_old_active - new_active, "full": best_old_full - new_full}
            for measure in minimum_savings:
                current = minimum_savings[measure]
                minimum_savings[measure] = savings[measure] if current is None else min(current, savings[measure])
        if tail == ZERO:
            smallest_example = {
                "tail": "0", "body": "Z(0,v)", "body_active": mu, "body_full": weight,
                "new_definition": [size(definition), size(definition, True)],
                "new_witness": [size(witness), size(witness, True)],
                "new_complete_block": [new_active, new_full],
                "optimistic_old_complete_block": [best_old_active, best_old_full],
            }

        # Natural-number examples corroborate (but do not replace) the proof.
        for parameter in range(5):
            def masked(index: int) -> int:
                return evaluate(body, index, parameter)

            assert masked(0) == 0
            for target in range(9):
                first_failure = next((index for index in range(1, target + 1)
                                      if masked(index) != 0), None)
                witness_index = target if first_failure is None else first_failure - 1
                next_value = masked(witness_index + 1)
                assert next_value in (0, witness_index + 1)
                assert masked(witness_index) == 0
                assert next_value != 0 or witness_index == target
                selected = natural_q(next_value, target)
                assert masked(selected) == 0
                semantic_cases += 1

                # This is exactly the last-zero recurrence used in the paper:
                # c(0)=0; c(Sk)=k if M(k)=0, and c(Sk)=c(k) otherwise.
                last_zero = 0
                for scan in range(target):
                    if masked(scan) == 0:
                        last_zero = scan
                assert masked(last_zero) == 0
                assert masked(target) == 0 or masked(last_zero + 1) != 0
                assert masked(natural_q(masked(last_zero + 1), target)) == 0
                last_zero_cases += 1

                # The optional coverage-based variant uses b=S(c(n,a)).
                optional_b = last_zero + 1
                assert masked(natural_q(masked(optional_b), target)) == 0
                optional_unshifted_cases += 1

                escaped_value = evaluate(generated(escape(body), V, W), target, parameter)
                assert escaped_value == iterate_body(body, target, parameter)
                escape_cases += 1

                if comparable_to_legacy:
                    orbit = lambda index: iterate_body(body, index, parameter)
                    old_failure = next((index for index in range(1, target + 1)
                                        if orbit(index) != parameter), None)
                    old_b = 0 if old_failure is None else old_failure
                    old_selected = natural_q(natural_z(orbit(old_b), old_b), target)
                    assert orbit(old_selected) == parameter
                    old_witness_cases += 1

    # Exhaust every Boolean pattern through index 9, so examples need not be
    # monotone or correspond to any particular small term.
    truth_pattern_cases = 0
    for truth in itertools.product((False, True), repeat=10):
        def masked(index: int) -> int:
            return 0 if truth[index] else index
        for target in range(9):
            failure = next((index for index in range(1, target + 1)
                            if masked(index) != 0), None)
            witness_index = target if failure is None else failure - 1
            assert masked(natural_q(masked(witness_index + 1), target)) == 0
            truth_pattern_cases += 1

    # Removing the existential and fixing b=n is NOT a sound strengthening.
    # For P(x) iff x<2, M(x) is zero below 2 and x from 2 onwards.
    threshold_body = mask_body(bit(q(V, ZERO), ZERO))
    threshold_mask = lambda index: evaluate(threshold_body, index, 0)
    for index in range(10):
        assert threshold_mask(index) == (0 if index < 2 else index)
    target = 4
    wrong_value = threshold_mask(natural_q(threshold_mask(target + 1), target))
    assert wrong_value == 4
    correct_b = 1
    assert threshold_mask(natural_q(threshold_mask(correct_b + 1), target)) == 0

    # This is an exact finite syntax ledger, not a claim that the finite
    # fragments themselves already have the strength of the full theories.
    finite_ledger = []
    for count in range(11):
        bodies = [mask_body(tail) for tail in tails[:count]]
        differences = []
        for full in (False, True):
            main_total = sum(size(item, full) for item in main_seed)
            optional_total = sum(size(item, full) for item in optional_seed)
            for body in bodies:
                definition = mask_definition(body)
                main_total += size(definition, full) + size(mask_witness(body), full)
                optional_total += size(definition, full) + size(unshifted_mask_witness(body), full)
            differences.append(optional_total - main_total)
        assert differences == [6 - count, 6 - count]
        finite_ledger.append({"mask_blocks": count, "optional_minus_main": differences})

    # Scope regression: ignoring recursive legacy normalization would make an
    # invalid all-new-bodies dominance claim. The same raw descriptor h costs
    # more in the new grammar than its normalized old representation.
    double_pad_v = q(successor(q(successor(V), W)), W)
    regression_body = mask_body(generated(double_pad_v, V, W))
    legacy_body = normalize_stored_descriptions(regression_body)
    assert size(double_pad_v, True) == 9
    assert not canonical_stored_descriptions(regression_body)
    assert canonical_stored_descriptions(legacy_body)
    assert size(regression_body) == size(legacy_body) == 5
    assert size(regression_body, True) == 15
    assert size(legacy_body, True) == 7
    regression_new = [size(mask_definition(regression_body), full)
                      + size(mask_witness(regression_body), full)
                      for full in (False, True)]
    legacy_candidates = [ordinary_computation(legacy_body), bound_computation(legacy_body)]
    regression_old = [min(size(item, full) for item in legacy_candidates)
                      + size(predecessor_witness(legacy_body), full)
                      for full in (False, True)]
    assert regression_new == [24, 80]
    assert regression_old == [36, 78]

    return {
        "status": "PASS",
        "scope": "Exact AST counts and finite standard-model checks; not a formal proof of bi-interpretability.",
        "small_tail_terms_exhausted": 771,
        "total_distinct_tails": len(tails),
        "common_grammar_comparison_bodies": common_grammar_bodies,
        "noncanonical_bodies_excluded_from_comparison": noncanonical_bodies,
        "incumbent_module_comparisons": total_syntax_comparisons,
        "new_mask_witness_semantic_cases": semantic_cases,
        "paper_last_zero_witness_semantic_cases": last_zero_cases,
        "optional_unshifted_witness_semantic_cases": optional_unshifted_cases,
        "escape_semantic_cases": escape_cases,
        "old_latch_witness_semantic_cases": old_witness_cases,
        "boolean_truth_patterns": 1024,
        "truth_pattern_target_cases": truth_pattern_cases,
        "exact_formulas": {
            "mask_definition": {"active": "6+mu", "full": "6+2W"},
            "new_witness": {"active": "13", "full": "14+2W"},
            "optional_unshifted_witness": {"active": "12", "full": "13+2W"},
            "main_fixed_axioms": {"active": 24, "full": 24},
            "optional_fixed_axioms": {"active": 30, "full": 30},
            "old_P14_witness": {"active": "14", "full": "16+2W"},
            "new_complete_mask_block": {"active": "19+mu", "full": "20+4W"},
            "optional_complete_mask_block": {"active": "18+mu", "full": "19+4W"},
            "optional_minus_main_for_k_mask_blocks": {"active": "6-k", "full": "6-k"},
            "optimistic_old_complete_block_lower_bound": {"active": "29+mu", "full": "31+6W"},
            "complete_block_savings_lower_bound": {"active": "10", "full": "11+2W"},
            "escape_body_surcharge": {"active": 2, "full": 3},
        },
        "minimum_observed_complete_block_savings": minimum_savings,
        "finite_optional_variant_ledger": finite_ledger,
        "smallest_example": smallest_example,
        "frozen_substitution_check": "PASS",
        "recursive_legacy_canonicality_check": "PASS",
        "mask_escape_dispatch_check": "PASS",
        "counterexample_to_fixing_b_equal_n": {
            "predicate": "x<2", "legal_tail": "chi(Q(v,0),0)",
            "target_n": target, "incorrect_fixed_b": target,
            "incorrect_result": wrong_value, "valid_witness_b": correct_b,
        },
        "comparison_scope_regression": {
            "noncanonical_descriptor": "d2=Q(S(Q(Sv,w)),w)=Pad^2(v)",
            "descriptor_full_size": 9,
            "new_mask_body": "h=Z(F_d2(v,w),v)",
            "body_active_size": 5,
            "new_body_full_size": 15,
            "old_normalized_body_full_size": 7,
            "new_complete_block": regression_new,
            "old_normalized_optimistic_complete_block": regression_old,
            "reason_excluded": "Nested stored body d2 is not root-normal in the legacy grammar; unqualified full-size dominance would be false.",
        },
        "comparison_limit": "Matched complete selected-function blocks only for bodies in the shared legacy grammar, with every nested stored descriptor recursively NF-canonical. Exact new syntax counts apply beyond that grammar; comparison does not. No pointwise raw-emitter domination or language-independent minimum is claimed.",
    }


if __name__ == "__main__":
    results = run_checks()
    script = Path(__file__).resolve()
    results["checker_sha256"] = hashlib.sha256(script.read_bytes()).hexdigest()
    output = script.with_name("count_results.json")
    output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))
