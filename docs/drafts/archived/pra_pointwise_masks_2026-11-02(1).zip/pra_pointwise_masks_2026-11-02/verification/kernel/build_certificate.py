#!/usr/bin/env python3
"""Construct the explicit certificate.  Only check_kernel.py verifies it."""
import json
from pathlib import Path
from check_kernel import SIGNATURE, app, eq, exact_statement, var


def ref(name):
    return {"rule": "assumption", "name": name}


def instantiate(proof, term):
    return {"rule": "forall_elim", "proof": proof, "term": term}


def rewrite(equality, premise, template):
    return {"rule": "eq_subst", "equality": equality, "premise": premise,
            "variable": "z", "template": template}


def modus_ponens(implication, premise):
    return {"rule": "imp_elim", "implication": implication, "premise": premise}


n, b, z = (var(name) for name in ("n", "b", "z"))
zero = app("0")
sb = app("S", b)
f = lambda term: app("F", term)
q = lambda left, right: app("Q", left, right)
target = eq(f(n), zero)
witness_context = eq(f(q(z, n)), zero)
zero_context = eq(f(z), zero)

# Branch F(Sb)=0: witness -> F(Q(0,n))=0 -> F(n)=0.
left_rewrite = rewrite(ref("zero_case"), ref("chosen_witness"), witness_context)
left_result = rewrite(instantiate(ref("q_zero"), n), left_rewrite, zero_context)

# Branch F(Sb)=Sb: witness -> F(Q(Sb,n))=0 -> F(b)=0.
right_rewrite = rewrite(ref("successor_case"), ref("chosen_witness"),
                        witness_context)
q_succ = instantiate(instantiate(ref("q_succ"), b), n)
return_at_b = rewrite(q_succ, right_rewrite, zero_context)
return_at_sb = modus_ponens(instantiate(ref("progress"), b), return_at_b)
# F(Sb)=Sb and F(Sb)=0 give Sb=0, contrary to nonzero.
successor_zero = rewrite(ref("successor_case"), return_at_sb, eq(z, zero))
contradiction = modus_ponens(instantiate(ref("nonzero"), b), successor_zero)
right_result = {"rule": "false_elim", "proof": contradiction,
                "conclusion": target}

case_proof = {
    "rule": "or_elim",
    "proof": instantiate(ref("range"), b),
    "left": {"assumption": "zero_case", "body": left_result},
    "right": {"assumption": "successor_case", "body": right_result},
}
proof = {
    "rule": "forall_intro", "variable": "n",
    "body": {
        "rule": "exists_elim",
        "proof": instantiate(ref("witness"), n),
        "variable": "b", "assumption": "chosen_witness", "body": case_proof,
    },
}
hypotheses, conclusion = exact_statement()
certificate = {
    "format": "mask-kernel-natural-deduction-v1",
    "signature": SIGNATURE,
    "hypotheses": hypotheses,
    "conclusion": conclusion,
    "proof": proof,
}
path = Path(__file__).with_name("mask_kernel_proof.json")
path.write_text(json.dumps(certificate, indent=2) + "\n", encoding="utf-8")
print(path.name)
