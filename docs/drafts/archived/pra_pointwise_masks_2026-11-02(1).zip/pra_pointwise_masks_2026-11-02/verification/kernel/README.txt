MASK WITNESS: EXECUTABLE ABSTRACT KERNEL CERTIFICATE

Run with Python 3 (standard library only):

    python3 check_kernel.py

Expected result: VERIFIED, 29 proof nodes, 8 checker controls passed.
The certificate is mask_kernel_proof.json.  The optional build_certificate.py
reconstructs that JSON from a readable sequence of rule applications; the
checker does not execute or trust the builder when checking an existing file.

EXACT STATEMENT

One sort; native equality; constant 0; unary S,F; binary Q.  From the six
universally closed hypotheses

  nonzero:  S(x) = 0 -> false
  q_zero:   Q(0,y) = y
  q_succ:   Q(S(x),y) = x
  range:    F(S(x)) = 0 or F(S(x)) = S(x)
  progress: F(x) = 0 -> F(S(x)) = 0
  witness:  for every n there exists b such that F(Q(F(S(b)),n)) = 0

prove: for every n, F(n) = 0.

The checker fixes this exact signature, hypothesis list, and conclusion.
Changing a certificate's hypotheses cannot silently turn it into a proof of a
different statement.  The six hypotheses are the lemma's explicit assumptions,
not theorem claims discharged by this certificate.

PROOF

Fix n and choose its witness b.  If F(S(b))=0, the witness and Q(0,n)=n give
F(n)=0.  If F(S(b))=S(b), the witness and Q(S(b),n)=b give F(b)=0.  Progress
therefore gives F(S(b))=0.  The case assumption then gives S(b)=0, contrary to
nonzero.  These are the two alternatives of range at b.  Eliminate the witness
and universally generalize n.

RULES AND TRUST BOUNDARY

The proof tree uses only assumption, universal introduction/elimination,
existential elimination, disjunction elimination, implication elimination,
equality substitution, and falsity elimination.  The checker verifies
well-formed syntax and the side conditions of every rule.  Universal
introduction and existential elimination check eigenvariable freshness;
substitution avoids variable capture.  Equality substitution requires its
premise to be the exact specified formula context at the equality's left term.

The file contains no `sorry`, unchecked theorem-reference mechanism, external
proof-assistant dependency, classical choice, arithmetic induction, coverage
assumption, finite-domain model search, or evaluation of proof-supplied Python.

The trusted mathematical component is the readable natural-deduction checker
itself, together with Python's execution of it.  This is a custom executable
proof certificate, not a Lean- or Rocq-kernel-checked proof.  Eight controls
exercise rejection of invalid rule uses/missing hypotheses and avoidance of
variable capture.  Those controls are a software sanity check, not a proof of
the checker's correctness.

SCOPE

This certificate proves only the displayed abstract arbitrary-carrier lemma.
It does not formalize the generated-language syntax, the translation of
quantifier-free formulas to masks, the derivation of the six hypotheses in the
proposed theory, the pairing construction, arbitrary primitive recursion, or
PRA bi-interpretability.  Those remain separate mathematical obligations.
