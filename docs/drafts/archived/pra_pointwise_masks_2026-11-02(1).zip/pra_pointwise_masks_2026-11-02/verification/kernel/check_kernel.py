#!/usr/bin/env python3
"""Check an explicit first-order natural-deduction proof of the mask kernel.

Python 3 standard library only.  This is a small independently readable proof
checker, not a Lean kernel and not a full formalization of PRA or interpretation
metatheory.  The certificate is untrusted input; it contains no derived axioms.
All six allowed hypotheses are checked against the exact statement below.
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path


class InvalidProof(Exception):
    """The supplied syntax or derivation is not accepted."""


SIGNATURE = {"0": 0, "S": 1, "Q": 2, "F": 1}
RULES = {
    "assumption": {"rule", "name"},
    "forall_intro": {"rule", "variable", "body"},
    "forall_elim": {"rule", "proof", "term"},
    "exists_elim": {"rule", "proof", "variable", "assumption", "body"},
    "or_elim": {"rule", "proof", "left", "right"},
    "imp_elim": {"rule", "implication", "premise"},
    "eq_subst": {"rule", "equality", "premise", "variable", "template"},
    "false_elim": {"rule", "proof", "conclusion"},
}


def require(condition, message):
    if not condition:
        raise InvalidProof(message)


def variable_name(value):
    require(isinstance(value, str) and value.isidentifier(),
            "Invalid variable name")


def check_term(term):
    require(isinstance(term, list) and term, "Term must be a nonempty list")
    if term[0] == "var":
        require(len(term) == 2, "Variable has wrong length")
        variable_name(term[1])
        return
    require(term[0] == "app" and len(term) >= 2,
            "Expected variable or function application")
    symbol = term[1]
    require(isinstance(symbol, str) and symbol in SIGNATURE,
            "Unknown function symbol")
    require(len(term) == 2 + SIGNATURE[symbol], "Wrong function arity")
    for argument in term[2:]:
        check_term(argument)


def check_formula(formula):
    require(isinstance(formula, list) and formula,
            "Formula must be a nonempty list")
    tag = formula[0]
    if tag == "false":
        require(len(formula) == 1, "Falsity has wrong length")
    elif tag == "eq":
        require(len(formula) == 3, "Equality has wrong length")
        check_term(formula[1])
        check_term(formula[2])
    elif tag in ("or", "imp"):
        require(len(formula) == 3, "Binary connective has wrong length")
        check_formula(formula[1])
        check_formula(formula[2])
    elif tag in ("forall", "exists"):
        require(len(formula) == 3, "Quantifier has wrong length")
        variable_name(formula[1])
        check_formula(formula[2])
    else:
        raise InvalidProof("Unknown formula constructor")


def term_variables(term):
    if term[0] == "var":
        return {term[1]}
    result = set()
    for argument in term[2:]:
        result |= term_variables(argument)
    return result


def free_variables(formula):
    tag = formula[0]
    if tag == "false":
        return set()
    if tag == "eq":
        return term_variables(formula[1]) | term_variables(formula[2])
    if tag in ("or", "imp"):
        return free_variables(formula[1]) | free_variables(formula[2])
    return free_variables(formula[2]) - {formula[1]}


def all_variables(formula):
    """Free and bound variable names, for capture-avoiding fresh names."""
    tag = formula[0]
    if tag in ("false", "eq"):
        return free_variables(formula)
    if tag in ("or", "imp"):
        return all_variables(formula[1]) | all_variables(formula[2])
    return all_variables(formula[2]) | {formula[1]}


def substitute_term(term, name, replacement):
    if term[0] == "var":
        return replacement if term[1] == name else term
    return ["app", term[1],
            *(substitute_term(t, name, replacement) for t in term[2:])]


def substitute(formula, name, replacement):
    """Capture-avoiding substitution of a term for free occurrences of name."""
    tag = formula[0]
    if tag == "false":
        return formula
    if tag == "eq":
        return ["eq", substitute_term(formula[1], name, replacement),
                substitute_term(formula[2], name, replacement)]
    if tag in ("or", "imp"):
        return [tag, substitute(formula[1], name, replacement),
                substitute(formula[2], name, replacement)]
    binder, body = formula[1], formula[2]
    if binder == name or name not in free_variables(body):
        return formula
    if binder in term_variables(replacement):
        forbidden = all_variables(body) | term_variables(replacement) | {name}
        index = 0
        while "fresh_" + str(index) in forbidden:
            index += 1
        fresh = "fresh_" + str(index)
        body = substitute(body, binder, ["var", fresh])
        binder = fresh
    return [tag, binder, substitute(body, name, replacement)]


def context_variables(context):
    result = set()
    for formula in context.values():
        result |= free_variables(formula)
    return result


def extend(context, name, formula):
    require(isinstance(name, str) and name and name not in context,
            "An assumption name must be fresh")
    return {**context, name: formula}


class Checker:
    def __init__(self):
        self.rule_count = {}

    def derive(self, node, context):
        require(isinstance(node, dict), "Proof node must be an object")
        rule = node.get("rule")
        require(isinstance(rule, str) and rule in RULES, "Unknown proof rule")
        require(set(node) == RULES[rule], "Unexpected or missing rule fields")
        self.rule_count[rule] = self.rule_count.get(rule, 0) + 1

        if rule == "assumption":
            require(isinstance(node["name"], str) and node["name"] in context,
                    "Unbound assumption")
            return context[node["name"]]

        if rule == "forall_intro":
            name = node["variable"]
            variable_name(name)
            require(name not in context_variables(context),
                    "Universal eigenvariable occurs in an open assumption")
            conclusion = self.derive(node["body"], context)
            return ["forall", name, conclusion]

        if rule == "forall_elim":
            premise = self.derive(node["proof"], context)
            require(premise[0] == "forall", "Universal elimination needs forall")
            check_term(node["term"])
            return substitute(premise[2], premise[1], node["term"])

        if rule == "exists_elim":
            premise = self.derive(node["proof"], context)
            require(premise[0] == "exists", "Existential elimination needs exists")
            name = node["variable"]
            variable_name(name)
            require(name not in context_variables(context) | free_variables(premise),
                    "Existential eigenvariable is not fresh")
            instance = substitute(premise[2], premise[1], ["var", name])
            inner = extend(context, node["assumption"], instance)
            conclusion = self.derive(node["body"], inner)
            require(name not in free_variables(conclusion),
                    "Existential eigenvariable escapes in the conclusion")
            return conclusion

        if rule == "or_elim":
            premise = self.derive(node["proof"], context)
            require(premise[0] == "or", "Disjunction elimination needs or")
            conclusions = []
            for key, formula in (("left", premise[1]), ("right", premise[2])):
                branch = node[key]
                require(isinstance(branch, dict)
                        and set(branch) == {"assumption", "body"},
                        "Malformed disjunction branch")
                inner = extend(context, branch["assumption"], formula)
                conclusions.append(self.derive(branch["body"], inner))
            require(conclusions[0] == conclusions[1],
                    "Disjunction branches have different conclusions")
            return conclusions[0]

        if rule == "imp_elim":
            implication = self.derive(node["implication"], context)
            premise = self.derive(node["premise"], context)
            require(implication[0] == "imp", "Implication elimination needs imp")
            require(implication[1] == premise, "Implication antecedent mismatch")
            return implication[2]

        if rule == "eq_subst":
            equality = self.derive(node["equality"], context)
            premise = self.derive(node["premise"], context)
            require(equality[0] == "eq", "Equality substitution needs equality")
            name = node["variable"]
            variable_name(name)
            template = node["template"]
            check_formula(template)
            require(substitute(template, name, equality[1]) == premise,
                    "Equality-substitution source formula mismatch")
            return substitute(template, name, equality[2])

        if rule == "false_elim":
            premise = self.derive(node["proof"], context)
            require(premise == ["false"], "Falsity elimination needs falsity")
            check_formula(node["conclusion"])
            return node["conclusion"]

        raise InvalidProof("Unreachable unknown rule")


def var(name):
    return ["var", name]


def app(symbol, *arguments):
    return ["app", symbol, *arguments]


def eq(left, right):
    return ["eq", left, right]


def forall(name, body):
    return ["forall", name, body]


def exact_statement():
    x, y, n, b = (var(s) for s in ("x", "y", "n", "b"))
    zero = app("0")
    sx = app("S", x)
    f = lambda t: app("F", t)
    hypotheses = {
        "nonzero": forall("x", ["imp", eq(sx, zero), ["false"]]),
        "q_zero": forall("y", eq(app("Q", zero, y), y)),
        "q_succ": forall("x", forall("y", eq(app("Q", sx, y), x))),
        "range": forall("x", ["or", eq(f(sx), zero), eq(f(sx), sx)]),
        "progress": forall("x", ["imp", eq(f(x), zero), eq(f(sx), zero)]),
        "witness": forall("n", ["exists", "b",
            eq(f(app("Q", f(app("S", b)), n)), zero)]),
    }
    return hypotheses, forall("n", eq(f(n), zero))


def verify(certificate):
    require(isinstance(certificate, dict)
            and set(certificate) == {"format", "signature", "hypotheses",
                                     "conclusion", "proof"},
            "Unexpected certificate fields")
    require(certificate["format"] == "mask-kernel-natural-deduction-v1",
            "Unsupported proof format")
    require(certificate["signature"] == SIGNATURE, "Wrong signature")
    expected_hypotheses, expected_conclusion = exact_statement()
    require(certificate["hypotheses"] == expected_hypotheses,
            "Certificate does not have the exact six advertised hypotheses")
    require(certificate["conclusion"] == expected_conclusion,
            "Certificate does not have the advertised conclusion")
    for formula in certificate["hypotheses"].values():
        check_formula(formula)
    check_formula(certificate["conclusion"])
    checker = Checker()
    conclusion = checker.derive(certificate["proof"], certificate["hypotheses"])
    require(conclusion == certificate["conclusion"], "Final conclusion mismatch")
    return checker


def checker_self_tests(certificate):
    """Negative controls for the main rules and eigenvariable conditions."""
    tests = []
    x, y = var("x"), var("y")
    zero = app("0")
    hypothesis = eq(x, zero)
    tests.append(("unbound assumption", {"rule": "assumption", "name": "missing"}, {}))
    tests.append(("false universal generalization", {
        "rule": "forall_intro", "variable": "x",
        "body": {"rule": "assumption", "name": "a"}}, {"a": hypothesis}))
    tests.append(("escaping existential witness", {
        "rule": "exists_elim", "proof": {"rule": "assumption", "name": "e"},
        "variable": "y", "assumption": "a",
        "body": {"rule": "assumption", "name": "a"}},
        {"e": ["exists", "x", hypothesis]}))
    tests.append(("wrong equality source", {
        "rule": "eq_subst", "equality": {"rule": "assumption", "name": "e"},
        "premise": {"rule": "assumption", "name": "p"},
        "variable": "z", "template": eq(var("z"), zero)},
        {"e": eq(x, y), "p": eq(y, zero)}))
    tests.append(("explosion without contradiction", {
        "rule": "false_elim", "proof": {"rule": "assumption", "name": "a"},
        "conclusion": eq(y, zero)}, {"a": hypothesis}))
    tests.append(("implication without antecedent", {
        "rule": "imp_elim", "implication": {"rule": "assumption", "name": "i"},
        "premise": {"rule": "assumption", "name": "p"}},
        {"i": ["imp", hypothesis, eq(y, zero)], "p": eq(y, zero)}))
    for label, proof, context in tests:
        try:
            Checker().derive(proof, context)
        except InvalidProof:
            pass
        else:
            raise InvalidProof("Negative control was accepted: " + label)
    # Substitution of y for x must rename the bound y, never capture it.
    capture_case = substitute(forall("y", eq(x, y)), "x", y)
    require(free_variables(capture_case) == {"y"},
            "Capture-avoidance control failed")
    # Removing a declared hypothesis or rewriting a certificate leaf is rejected.
    damaged = copy.deepcopy(certificate)
    del damaged["hypotheses"]["nonzero"]
    try:
        verify(damaged)
    except InvalidProof:
        pass
    else:
        raise InvalidProof("Missing-hypothesis control was accepted")
    return len(tests) + 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", nargs="?",
                        default=str(Path(__file__).with_name("mask_kernel_proof.json")))
    args = parser.parse_args()
    certificate = json.loads(Path(args.certificate).read_text(encoding="utf-8"))
    checker = verify(certificate)
    controls = checker_self_tests(certificate)
    result = {
        "status": "VERIFIED",
        "statement": "From the six declared hypotheses, forall n F(n) = 0",
        "logic": "intuitionistic first-order natural deduction with equality",
        "proof_nodes": sum(checker.rule_count.values()),
        "rule_counts": dict(sorted(checker.rule_count.items())),
        "checker_controls_passed": controls,
        "scope": "abstract arbitrary-carrier kernel only; not full PRA equivalence",
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (InvalidProof, OSError, ValueError, TypeError, KeyError) as error:
        raise SystemExit("REJECTED: " + str(error))
