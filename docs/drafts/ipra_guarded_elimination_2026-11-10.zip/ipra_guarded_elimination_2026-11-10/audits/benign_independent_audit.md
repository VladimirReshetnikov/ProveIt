# Independent audit of benign endpoint kernels

Audited by the arithmetic subagent, 10 November 2026.

## Scope and conclusion

The control-flow change in `logic_scratch/benign_endpoint.py` and
`logic_scratch/benign_ea_endpoint.py` is sound under the supplied finite-tree
native decoder, provided the inherited opening/decoding lemmas are retained.
The strict `a + []` opener in `benign_try.py` is also a sound implementation
of the same list-versus-scalar traversal on Python JSON values. This is a
written source audit, not a proof-assistant verification.

The conservative claim is about decoded native formulas, in particular
canonical native goals. Do not assert equality of the old and new accepted
raw strings: the new administrative step can close the raw truth alias `[]`,
which the old checker may not have been able to close as a raw goal. Its
meaning is the already provable equation 0=0. Raw alias normalization belongs
in the proof translation.

## Main preservation argument

A successful recursive call proves its decoded goal from its decoded finite
context. The freshness floor k decreases before every continuation parameter.
A numerical occurrence of a future negative label is rejected by root opening;
formula-sort scalar aliases are merely truth and do not carry numerical
parameter dependence.

A truthy elimination major is proved before the continuation. After proof,
`h = m[2:]` must succeed. On a successful run the usable major is an array of
arity at most three. If it has three children, its length prevents it from
matching either `[s,u]` or `[t]`. The continuation is the existing paired
elimination, with `h=[matrix]` and a fresh witness parameter.

For a major of arity one or two, h is the empty array. If the endpoint guard
and target comparison succeed, the changed goal is the proper source instance
of the equation/closure elimination; the continuation also receives theorem
truth. If either guard fails, a is unchanged, and the continuation receives
only theorem truth. The new parameter is absent from the already validated
numerical goal and context. Hence this branch proves the same goal under a
conservative fresh-parameter and theorem extension. Cut with a proof of 0=0,
then parameter renaming/removal, gives the old decoded sequent. The successfully
proved major is unused in this administrative case.

The primitive computation branch is unchanged semantically. When its equality
comparison succeeds it returns normally. When the comparison fails, h has not
been assigned in that invocation, and the continuation evaluation raises an
UnboundLocalError. No parent invocation's local h is inherited by a child.
Thus a failed computation is not silently accepted.

## Validation moved in the EA variant

The root driver calls `c(i(q()), [])`, so initial numerical scope is checked
before the first proof step can allocate a parameter. Every continuation goal
is supplied by `i(...)`, with the current floor and checked substitution image.
The only recursive call taking a raw goal is `c(m,g)` for a major, and it is
immediately preceded by `i(m) in g`. A failed hypothesis test still evaluates
that validator before recursive major checking. Thus all recursive goals have
the necessary pre-allocation scope check even though c has no general leading
`i(a)` call. Subproofs may lower k further; this only allocates labels fresh
for the previously validated goal/context.

The matched target computation `i(t,u)` and source computation `i(t,s)` both
normalize/check their used replacement images. Invalid unused certificate
payloads are inert, as in the inherited format. They do not supply a numerical
witness unless a witness coordinate is actually used.

## Python dispatch and raw aliases

Falsy numerical instruction heads 0, False, and 0.0 select the same permitted
atomic-progress choice. Other falsy heads such as [] select the permitted
case choice. A truthy scalar major cannot pass the required list slicing on a
successful elimination path. Accepted endpoint comparisons between integers,
Booleans and equal finite floats preserve their numerical-coordinate decoding;
malformed strings, dictionaries, None and NaN cannot survive a used numerical
position's range/opening check. Unused annotations can remain inert.

For `benign_try.py`, `a + []` succeeds exactly when a is a list among JSON
runtime types. If a child traversal fails, the outer exception handler attempts
an integer/list order comparison and itself raises; it cannot convert a failed
list traversal into acceptance. For nonlists the fallback has precisely the
old scalar range/substitution behavior. All list children are traversed. Lists
of arity greater than three reject at the arity table. This audit does not apply
to an unguarded `for b in a` opener: empty strings/dictionaries would then be
extra iterable aliases and require a different raw-format argument.

## Completeness and proof erasure

Existing canonical computations and DI/DE instances retain their encodings.
An existing canonical equation/closure elimination supplies endpoints and
motive satisfying the guard, so it is represented by the matched branch.
Consequently the underlying native calculus remains complete. Administrative
steps add no decoded consequences: recursively erase them using the theorem
0=0, freshness, and ordinary assumption cut. A producer can omit them entirely;
their role is to totalize the small elimination dispatch without an explicit
failure branch.

This is a proof-checker simplification and an exact conservative presentation,
not new numerical arithmetic or a proof of globally minimal axiomatization.

## Independent execution checks

`benign_independent_cases.json` records six focused packets against each of the
three variants (18 executions). Both unmatched-endpoint and mismatched-target
administrative continuations accept a genuine computation equation. The same
kind of padding does not prove 0=1. A future negative label in the original
goal rejects before allocation. A scalar major and a used string numerical
image reject. These tests supplement, and do not establish, the universal
arguments above.
