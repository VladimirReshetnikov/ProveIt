Guarded elimination with identity defaults
=========================================
Prepared for Vladimir Reshetnikov, 10 November 2026.

RESULT
An unmatched elimination instruction retains the requested goal, rather than
rejecting immediately or introducing a special failure state. Its continuation
adds only a theorem and a fresh unused parameter. This gives a smaller complete
proof-checking interface for the inherited iPRA presentation. The universal
soundness argument erases such administrative steps; ordinary proofs translate
using matching endpoints and correct parameter renaming.

The principal complete scalar checker, code/kernel.py, measures
284 tokens / 322 AST nodes / 720 normalized bytes. This ONE program is below
all three old observed minima: 287 / 323 / 738. The scalar family envelope is
281 / 318 / 713, attained across different programs. These are finite-corpus
implementation upper bounds,
not mathematical lower bounds, an absolute minimum, or a claimed significant
new arithmetic breakthrough.

READ FIRST
  ipra_guarded_elimination.pdf   Complete research report and inherited proofs
  report.tex                    Editable main LaTeX source
  report_standalone.tex          Expanded LaTeX with all inputs embedded
  appendices/                   All included LaTeX dependencies
  code/readable.py              Standalone readable proof checker
  CHECKER-FORMAT.txt             Public certificate and verdict convention
  SOUNDNESS-NOTES.txt            Implementation correctness notes

OPTIONAL SMALLER BYTE PROFILE
  successor_variant/code/kernel_bytes.py
      290 tokens / 333 AST nodes / 689 normalized bytes.
This is a separate arithmetic presentation using the existing counter-aware
successor-seeded recursor R, with the same new guarded elimination mechanism.
It is not the scalar I language. Its R-specific computation, identity expansion,
format notes, inherited arithmetic proofs, and 315 full-process checks are
in successor_variant/. Across both presentations the coordinate envelope is
281 / 318 / 689; no one program attains all three minima.

COMPACT COMPLETE PROGRAMS
  code/kernel.py                284 tokens / 322 AST / 720 bytes (principal)
  code/kernel_tokens.py         281 tokens / 325 AST / 739 bytes
  code/kernel_ast.py            285 tokens / 318 AST / 818 bytes
  code/kernel_bytes.py          283 tokens / 331 AST / 713 bytes

The byte profile uses the inherited elimination-only assumption interface and
therefore has a different canonical certificate compiler. It proves the same
equation/D object theory; auxiliary Q formulas expand via unused-witness D.
The regular programs also accept the directly represented Q extension.

RUN AN EXAMPLE
  python3 code/kernel.py < examples/unmatched_endpoints.json
  python3 code/kernel_bytes.py < examples/focused_unmatched_endpoints.json
  python3 code/readable.py < examples/false_after_unmatched_endpoints.json

The first two print ACCEPT and exit zero. The last prints REJECT and exits
nonzero. A traceback on rejection is part of the inherited verdict convention.
The input is JSON data, never code. Extra unused prefix cells are inert.

REPRODUCE
  python3 reproduce.py
  python3 reproduce.py --pdf

The first command verifies all whole-source metrics and reruns 2,769 complete
standalone process checks (2,454 scalar plus 315 successor-recursion checks). The second also rebuilds the PDF using pdflatex.
An additional independent R audit is reproducible with:
  python3 audits/r_focused_independent.py
Its 136 controls are recorded separately.
Measurements were made using CPython 3.12.14; ast.unparse can vary by version.
Only the Python standard library is needed for checkers, producers, and tests.
The PDF additionally needs the LaTeX packages declared in report.tex.

SOURCE COMPARISON
The repository snapshot is 7bded17cc0122767f86e494fcf256b47fe85c9b8.
Ten ZIP archives (6,213,010 total bytes) were verified against their Git blob
identities. evidence/source_archives.json records all archive hashes.
All 154 Python occurrences, representing 109 distinct source byte strings,
were measured; exact distinct sources are retained in reference/corpus_python
with original occurrence paths in evidence/all_python_sources.json. Small
utilities are not complete proof checkers. The exact three leading complete
comparators are in reference/comparators; metrics.json records their origins.
No network access is needed to reproduce the included measurements.

VALIDATION AND LIMITS
evidence/validation.json and validation_cases.json contain actual full-process
results. The positive corpus includes 157 inherited proofs, each translated
normally and with two deliberately unmatched instruction prefixes. Negative
controls cover false conclusions, false computations, future-parameter capture,
unscoped witnesses, malformed constructors, and inappropriate syntax.

The mathematical claims are written universal proofs with independent review,
not a Lean/Rocq formalization. Finite regression tests do not prove the general
metatheorems. Conservativity is for decoded native consequences, not identical
raw JSON packets or every raw alias spelling. The report explicitly treats
full quantified intuitionistic logic, actual equality, both interpretation
composites, and the ordinary falsity bridge.

ATTRIBUTION
The scalar arithmetic, logical basis, endpoint certificates, common
continuation, elimination-only assumption interface, and measurement method
are inherited from the supplied ProveIt drafts. The new contribution is the
identity default for unmatched eliminations and its checked implementation.
See reference/PROVENANCE.txt, the paper bibliography, and the retained license.
