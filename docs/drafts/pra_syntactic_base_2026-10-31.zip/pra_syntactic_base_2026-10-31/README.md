# PRA from a syntactic base

Research report prepared for Vladimir Reshetnikov, 31 October 2026.

## Result

The existing five-equality positive-base schema remains sufficient when
its three-rewrite-per-side admission condition is replaced by literal
identity of the boundary terms at 1. There is also an equivalent schema
with one varying term and no admission test, using the swap equation
`F(n,1,a) = F(1,n,a)`.

Both use the same binary initialized-iterator grammar:

    I_h(0,a) = a
    I_h(Sn,a) = h(n,I_h(n,a))

The update term has only the counter and current state free. Each
arithmetic instance has at most one fixed numerical parameter.

The paper proves conservative definitional equivalence with ordinary PRA,
separately in classical and intuitionistic first-order equality logic.
It includes native equality reflection, quantifier-free formula compilation,
pairing, all parameter tuples, and simulation of ordinary primitive recursion.

## Files

- `pra_syntactic_base.pdf`: complete compiled paper.
- `pra_syntactic_base.tex`, `core_section.tex`, `recovery.tex`,
  `completion.tex`, `discussion.tex`: all LaTeX sources.
- `check_boundary.py`, `boundary_checks.json`: finite term syntax,
  literal boundary certificates, and finite numerical sanity checks.
- `schema_sizes.py`, `schema_sizes.json`: reproducible arithmetic formula counts.
- `source_audit.json`: exact reviewed repository snapshot and archive hashes.
- `build.sh`: rebuild instructions as an executable shell script.
- `SHA256SUMS`: package checksums.

## Rebuild

Requires a normal TeX Live installation with pdfLaTeX/latexmk and the
standard packages listed in the main source, plus Python 3.10 or newer.
The Python scripts have no third-party dependencies.

```sh
python3 check_boundary.py --json > boundary_checks.json
python3 schema_sizes.py > schema_sizes.json
latexmk -pdf -interaction=nonstopmode -halt-on-error pra_syntactic_base.tex
```

Or run `bash build.sh` from this directory. It creates fresh check outputs
and compiles the PDF. Regenerate SHA256SUMS after modifying any artifact.

## Verification scope

The universal equivalence proofs are written mathematical proofs in the
paper. The code checks actual expanded finite term syntax and runs finite
standard-natural-number examples. It is not a Lean/Rocq formalization or a
first-order proof checker. No absolute minimality or historical-priority
claim is made. The earlier identity-target one-term conjecture is not solved
by changing the equation pattern to the new swap form.

No repository files were changed or committed for this report.
