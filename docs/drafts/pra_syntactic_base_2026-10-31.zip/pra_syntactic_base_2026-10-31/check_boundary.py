#!/usr/bin/env python3
"""Check finite-syntax boundary certificates for the literal-base presentation.

Only 0, successor, variables, and declared binary initialized iterators are
primitive term constructors.  A declaration I_h has equations

    I_h(0,a) = a
    I_h(Sn,a) = h(n,I_h(n,a)).

The rewrite checker uses these equations forwards at arbitrary term-tree
positions.  Stored declaration bodies are never rewritten.  Its bounded
join search is an exhaustive finite search, not semantic normalization.

The key mathematical construction is described by the following actual
iterator declarations (these labels abbreviate symbol names, not extra
rewrite rules):

    B = I_[0]             P = I_[i]
    A = I_[S(r)]          J = I_[B(i,r)].

A is addition, recursing on its first argument.  J has J(1,a)=a and
J(SSn,a)=0.  Two literal-base instances derive A(x,0)=x; a third derives
constructor coverage.  Given arbitrary
terms u(n,a),v(n,a), put U=u(P(P(n,0),0),a), V=v(P(P(n,0),0),a).
The padded pair is

    A(J(1,U),J(n,V)) , A(J(n,U),J(1,V)).

At n=1 these two terms are literally identical, without any rewrite.
All three bootstrap pairs are also literally identical at one.  Thus no
rewrite search is needed for admission.  The earlier direct constructor
pair n, S(P(n,0)) requires one rewrite; that comparison check is retained.
An optional one-term symmetric form F(n,1,a)=F(1,n,a) is also checked.

This program verifies syntactic certificates and runs a finite standard-
natural-number sanity check of the displayed terms.  It is NOT a prover
of full PRA equivalence or a formal verification of intuitionistic logic.
The universal mathematical proof belongs to the accompanying paper.

Usage: python3 check_boundary.py [--json]
Python 3.10 or newer; no third-party dependencies.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from functools import lru_cache
from typing import Union


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Succ:
    arg: Term


@dataclass(frozen=True)
class Iter:
    symbol: str
    counter: Term
    seed: Term


Term = Union[Var, Zero, Succ, Iter]
ZERO = Zero()
ONE = Succ(ZERO)
N = Var("n")
A = Var("a")
INDEX = Var("i")
STATE = Var("r")


def free_vars(term: Term) -> set[str]:
    if isinstance(term, Var):
        return {term.name}
    if isinstance(term, Zero):
        return set()
    if isinstance(term, Succ):
        return free_vars(term.arg)
    return free_vars(term.counter) | free_vars(term.seed)


def symbols(term: Term) -> set[str]:
    if isinstance(term, (Var, Zero)):
        return set()
    if isinstance(term, Succ):
        return symbols(term.arg)
    return {term.symbol} | symbols(term.counter) | symbols(term.seed)


def substitute(term: Term, replacement: dict[str, Term]) -> Term:
    if isinstance(term, Var):
        return replacement.get(term.name, term)
    if isinstance(term, Zero):
        return term
    if isinstance(term, Succ):
        return Succ(substitute(term.arg, replacement))
    return Iter(term.symbol, substitute(term.counter, replacement),
                substitute(term.seed, replacement))


def pretty(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if isinstance(term, Zero):
        return "0"
    if isinstance(term, Succ):
        return f"S({pretty(term.arg)})"
    return f"{term.symbol}({pretty(term.counter)},{pretty(term.seed)})"


DECLARATIONS: dict[str, Term] = {}


def declare(name: str, body: Term) -> None:
    """Reject forward/self references and hidden frozen parameters."""
    if name in DECLARATIONS:
        raise ValueError(f"Duplicate declaration: {name}")
    if not free_vars(body) <= {"i", "r"}:
        raise ValueError("An iterator body may use only index i and state r")
    if not symbols(body) <= DECLARATIONS.keys():
        raise ValueError("An iterator body may use only earlier symbols")
    DECLARATIONS[name] = body


declare("B", ZERO)
declare("P", INDEX)
declare("A", Succ(STATE))
declare("J", Iter("B", INDEX, STATE))


@dataclass(frozen=True)
class Step:
    path: tuple[int, ...]
    rule: str
    after: Term


def one_step(term: Term) -> list[Step]:
    """Enumerate every forward D0/DS rewrite, retaining its tree position."""
    result: list[Step] = []
    if isinstance(term, Iter):
        if isinstance(term.counter, Zero):
            result.append(Step((), f"{term.symbol}:D0", term.seed))
        elif isinstance(term.counter, Succ):
            n = term.counter.arg
            value = substitute(DECLARATIONS[term.symbol], {
                "i": n, "r": Iter(term.symbol, n, term.seed)})
            result.append(Step((), f"{term.symbol}:DS", value))
        for step in one_step(term.counter):
            result.append(Step((0,) + step.path, step.rule,
                               Iter(term.symbol, step.after, term.seed)))
        for step in one_step(term.seed):
            result.append(Step((1,) + step.path, step.rule,
                               Iter(term.symbol, term.counter, step.after)))
    elif isinstance(term, Succ):
        for step in one_step(term.arg):
            result.append(Step((0,) + step.path, step.rule, Succ(step.after)))
    return result


def reachable(term: Term, bound: int) -> dict[Term, tuple[Step, ...]]:
    if bound < 0:
        raise ValueError("Negative rewrite bound")
    found: dict[Term, tuple[Step, ...]] = {term: ()}
    frontier = [term]
    for _ in range(bound):
        next_frontier = []
        for before in frontier:
            for step in one_step(before):
                if step.after not in found:
                    found[step.after] = found[before] + (step,)
                    next_frontier.append(step.after)
        frontier = next_frontier
    return found


def bounded_join(left: Term, right: Term, bound: int):
    lnodes = reachable(left, bound)
    rnodes = reachable(right, bound)
    common = set(lnodes) & set(rnodes)
    if not common:
        return None
    chosen = min(common, key=lambda term: (
        len(lnodes[term]) + len(rnodes[term]), pretty(term)))
    return chosen, lnodes[chosen], rnodes[chosen]


def admitted(left: Term, right: Term, bound: int = 0):
    """Apply the exact boundary-at-one admission test to finite syntax."""
    for term in (left, right):
        if not free_vars(term) <= {"n", "a"}:
            raise ValueError("Only n and the single parameter a are permitted")
        if not symbols(term) <= DECLARATIONS.keys():
            raise ValueError("Undeclared iterator symbol")
    return bounded_join(substitute(left, {"n": ONE}),
                        substitute(right, {"n": ONE}), bound)


def pred(term: Term) -> Term:
    return Iter("P", term, ZERO)


def pad(left: Term, right: Term) -> tuple[Term, Term]:
    """Return expanded iterator syntax; no pad/shift/selector AST nodes."""
    twice = pred(pred(N))
    u = substitute(left, {"n": twice})
    v = substitute(right, {"n": twice})
    return (
        Iter("A", Iter("J", ONE, u), Iter("J", N, v)),
        Iter("A", Iter("J", N, u), Iter("J", ONE, v)),
    )


def swap_context(left: Term, right: Term) -> Term:
    """One term F(x,y,a) whose two fixed-boundary substitutions suffice."""
    x, y = Var("x"), Var("y")
    delayed = pred(pred(pred(Iter("A", x, y))))
    u = substitute(left, {"n": delayed})
    v = substitute(right, {"n": delayed})
    return Iter("A", Iter("J", y, u), Iter("J", x, v))


def swapped(term: Term) -> tuple[Term, Term]:
    if not free_vars(term) <= {"x", "y", "a"}:
        raise ValueError("Swap context may use only x,y,a")
    return (substitute(term, {"x": N, "y": ONE}),
            substitute(term, {"x": ONE, "y": N}))


def evaluate(term: Term, environment: dict[str, int]) -> int:
    """Standard-N interpretation, used only for explicitly finite checks."""
    if isinstance(term, Var):
        return environment[term.name]
    if isinstance(term, Zero):
        return 0
    if isinstance(term, Succ):
        return evaluate(term.arg, environment) + 1
    return evaluate_iterator(term.symbol, evaluate(term.counter, environment),
                             evaluate(term.seed, environment))


@lru_cache(maxsize=None)
def evaluate_iterator(symbol: str, count: int, seed: int) -> int:
    value = seed
    for index in range(count):
        value = evaluate(DECLARATIONS[symbol], {"i": index, "r": value})
    return value


def certificate_record(join) -> dict:
    term, left_steps, right_steps = join
    return {
        "common_reduct": pretty(term),
        "left_steps": [{"path": list(s.path), "rule": s.rule,
                        "after": pretty(s.after)} for s in left_steps],
        "right_steps": [{"path": list(s.path), "rule": s.rule,
                         "after": pretty(s.after)} for s in right_steps],
    }


def run_checks() -> dict:
    constructors = (N, Succ(pred(N)))
    assert admitted(*constructors, bound=0) is None
    cov = admitted(*constructors, bound=1)
    assert cov is not None
    assert cov[0] == ONE and len(cov[1]) == 0 and len(cov[2]) == 1

    # Without a boundary condition, the vacuous step for 0=1 is unsound.
    # The syntactic test correctly rejects this candidate.
    assert admitted(ZERO, ONE, bound=3) is None

    # Independently recognizable contextual-rewriting examples exercise both
    # child positions and the rule that discarded seeds need no evaluation.
    assert any(s.after == Succ(A) and s.path == (0,) for s in
               one_step(Succ(Iter("B", ZERO, A))))
    opaque_seed = Iter("J", N, A)
    assert any(s.after == ZERO and s.path == () for s in
               one_step(Iter("B", Succ(N), opaque_seed)))

    x, y = Var("x"), Var("y")
    bootstrap_contexts = [
        ("successor_translation", Iter("A", x, y)),
        ("right_zero_unit", Iter("A", x, Iter("A", y, ZERO))),
        ("constructor_coverage", Iter("A", x, pred(y))),
    ]
    bootstrap_records = []
    for name, context in bootstrap_contexts:
        left, right = swapped(context)
        join = admitted(left, right, bound=0)
        assert join is not None and not join[1] and not join[2]
        bootstrap_records.append({"purpose": name, "context": pretty(context),
            "left": pretty(left), "right": pretty(right),
            "certificate": certificate_record(join)})

    samples = [N, A, Succ(N), Succ(A), pred(N),
               Iter("B", N, A), Iter("A", N, A), Iter("J", N, A)]
    boundary_pairs = 0
    numerical_cases = 0
    for u in samples:
        for v in samples:
            left, right = pad(u, v)
            assert free_vars(left) <= {"n", "a"}
            assert free_vars(right) <= {"n", "a"}
            join = admitted(left, right, bound=0)
            assert join is not None and not join[1] and not join[2]
            swap_left, swap_right = swapped(swap_context(u, v))
            swap_join = admitted(swap_left, swap_right, bound=0)
            assert swap_join is not None and not swap_join[1] and not swap_join[2]
            boundary_pairs += 1
            for n in range(9):
                for a in range(5):
                    lhs = evaluate(left, {"n": n, "a": a})
                    rhs = evaluate(right, {"n": n, "a": a})
                    swap_lhs = evaluate(swap_left, {"n": n, "a": a})
                    swap_rhs = evaluate(swap_right, {"n": n, "a": a})
                    if n < 2:
                        assert lhs == rhs
                    else:
                        assert lhs == evaluate(u, {"n": n - 2, "a": a})
                        assert rhs == evaluate(v, {"n": n - 2, "a": a})
                    assert swap_lhs == lhs and swap_rhs == rhs
                    numerical_cases += 1

    for x in range(10):
        for a in range(6):
            assert evaluate_iterator("A", 0, a) == a
            assert evaluate_iterator("A", x, a) == x + a
            assert evaluate_iterator("A", x, 0) == x
            assert evaluate_iterator("J", 1, a) == a
            assert evaluate_iterator("J", x + 2, a) == 0

    demo = pad(Iter("A", N, A), Iter("B", Succ(N), Succ(A)))
    return {
        "status": "PASS",
        "scope": "finite syntax certificates and bounded standard-N checks; not a PRA theorem prover",
        "declarations_in_dependency_order": [
            {"symbol": name, "step_body": pretty(body)}
            for name, body in DECLARATIONS.items()],
        "old_constructor_instance_for_comparison": {
            "left": pretty(constructors[0]), "right": pretty(constructors[1]),
            "minimum_join_bound": 1, "certificate": certificate_record(cov)},
        "literal_bootstrap_instances": bootstrap_records,
        "padded_sample_instance": {
            "left": pretty(demo[0]), "right": pretty(demo[1]),
            "minimum_join_bound": 0,
            "certificate": certificate_record(admitted(*demo, bound=0))},
        "padded_boundary_pairs_checked": boundary_pairs,
        "swapped_boundary_pairs_checked": boundary_pairs,
        "padded_standard_N_cases_checked": numerical_cases,
        "standard_N_ranges": {"n": [0, 8], "a": [0, 4]},
        "helper_cases_checked": 60,
        "negative_checks": [
            "constructor pair rejected at bound zero",
            "constant equation 0=1 rejected through bound three"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="emit the full certificate record")
    args = parser.parse_args()
    result = run_checks()
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print("PASS: all three bootstrap boundaries are literally identical at one.")
        print("PASS: 64 padded pairs and 64 swapped-context pairs pass with zero rewrites.")
        print("PASS: 2,880 finite standard-N padding cases (both forms) and 60 helper cases.")
        print("PASS: contextual rewrite and negative admission checks.")
        print("Scope: syntactic certificates and finite sanity checks, not a proof of PRA equivalence.")


if __name__ == "__main__":
    main()
