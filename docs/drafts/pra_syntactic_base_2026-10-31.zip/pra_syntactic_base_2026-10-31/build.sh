#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
python3 check_boundary.py --json > boundary_checks.json
python3 schema_sizes.py > schema_sizes.json
latexmk -pdf -interaction=nonstopmode -halt-on-error pra_syntactic_base.tex
