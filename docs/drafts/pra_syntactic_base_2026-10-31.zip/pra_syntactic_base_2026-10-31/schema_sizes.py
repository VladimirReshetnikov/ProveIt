#!/usr/bin/env python3
"""Reproduce the displayed arithmetic formula counts.

Every variable, 0, function application, equality, connective, falsehood,
and quantifier contributes one node.  1 means S(0), negation means
implication to falsehood, and the outer parameter quantifier is included.
Schematic terms are counted as applications at their displayed arity.
The common D0 and DS computation families are not part of these counts.
"""
from __future__ import annotations
import json


def node(label, *children):
    return (label, *children)


def size(tree):
    return 1 + sum(size(c) for c in tree[1:])


def equalities(tree):
    return int(tree[0] == '=') + sum(equalities(c) for c in tree[1:])


def eq(a, b): return node('=', a, b)
def imp(a, b): return node('imp', a, b)
def land(a, b): return node('and', a, b)
def lor(a, b): return node('or', a, b)
def forall(v, f): return node('forall ' + v, f)
def succ(t): return node('S', t)
def neg(t): return imp(t, node('false'))
def app(f, *args): return node(f, *args)


zero, n, a = node('0'), node('n'), node('a')
one = succ(zero)
sep = neg(eq(zero, one))


def ordinary_equation(x):
    return eq(app('s', x, a), app('t', x, a))


def guarded(E, separator=sep, package=True):
    premise = forall('n', imp(lor(eq(n, zero), E(n)), E(succ(n))))
    conclusion = forall('n', lor(eq(n, zero), E(n)))
    if package:
        conclusion = land(separator, conclusion)
    return forall('a', imp(premise, conclusion))


def positive(E):
    return forall('a', imp(
        forall('n', imp(E(n), E(succ(n)))),
        land(sep, forall('n', lor(eq(n, zero), E(n))))))


def main():
    successor_E = lambda x: eq(app('f', x, a), succ(app('g', x, a)))
    swap_E = lambda x: eq(app('F', x, one, a), app('F', one, x, a))
    formulas = {
        'separated_Sep_plus_G': [sep, guarded(ordinary_equation, package=False)],
        'guarded_K': [guarded(ordinary_equation)],
        'base_free_successor_A_minus': [guarded(successor_E,
            neg(eq(zero, succ(app('g', zero, a)))))],
        'current_PB3': [positive(ordinary_equation)],
        'literal_base_L': [positive(ordinary_equation)],
        'single_term_swap_W': [positive(swap_E)],
    }
    expected = {
        'separated_Sep_plus_G': (6, 42), 'guarded_K': (6, 43),
        'base_free_successor_A_minus': (6, 48), 'current_PB3': (5, 39),
        'literal_base_L': (5, 39), 'single_term_swap_W': (5, 51),
    }
    output = {}
    for name, trees in formulas.items():
        count = sum(equalities(t) for t in trees)
        nodes = sum(size(t) for t in trees)
        assert (count, nodes) == expected[name], (name, count, nodes)
        output[name] = {'equality_occurrences': count, 'AST_nodes': nodes,
                        'arithmetic_items': len(trees), 'formula_trees': trees}
    print(json.dumps({'scope': __doc__, 'results': output}, indent=2))


if __name__ == '__main__':
    main()
