#!/usr/bin/env python3
"""Finite checks for the binary exclusive-induction PRA presentation.

Python 3.10+, standard library only. Example:
    python3 verify_binary_exclusive.py --output verification_results.json

Every function under test is evaluated from its primitive-recursion
description. Ordinary integer arithmetic is used only by the interpreter
for successor/loop control and as an independent reference in checks.

This is not a formal proof assistant or a proof of equivalence to PRA.
It checks finite numerical cases, a small equational rewrite certificate,
description well-formedness, and the free-variable budget of an explicit
induction ledger. Nonstandard models and all schema instances are outside
the scope of these executable checks.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator


@dataclass(frozen=True)
class Zero:
    pass


@dataclass(frozen=True)
class Variable:
    name: str


@dataclass(frozen=True)
class Successor:
    argument: Term


@dataclass(frozen=True)
class Call:
    name: str
    first: Term
    second: Term


Term = Zero | Variable | Successor | Call
ZERO = Zero()
ONE = Successor(ZERO)
N = Variable("n")
A = Variable("a")
V = Variable("v")


def successor(t: Term) -> Term:
    return Successor(t)


def predecessor(t: Term) -> Term:
    return Call("p", t, ZERO)


def gate(t: Term, u: Term) -> Term:
    return Call("b", t, u)


def alpha(t: Term, u: Term) -> Term:
    """Its intended numerical value is u dot-minus t."""
    return Call("alpha", t, u)


def add(t: Term, u: Term) -> Term:
    return Call("add", t, u)


def zero_test(t: Term) -> Term:
    return gate(t, ONE)


def equality_indicator(t: Term, u: Term) -> Term:
    return gate(alpha(t, u), gate(alpha(u, t), ONE))


def equality_error(t: Term, u: Term) -> Term:
    return zero_test(equality_indicator(t, u))


def selector(t: Term, u: Term, v: Term) -> Term:
    """A term using binary symbols, not a new ternary function symbol."""
    return add(gate(t, u), gate(zero_test(t), v))


def triangular(t: Term) -> Term:
    return Call("T", t, ZERO)


def rank(t: Term) -> Term:
    return Call("q", t, ZERO)


def pair(t: Term, u: Term) -> Term:
    return add(triangular(add(t, u)), u)


def right(t: Term) -> Term:
    return alpha(triangular(rank(t)), t)


def left(t: Term) -> Term:
    return alpha(right(t), rank(t))


def walk(t: Term) -> Iterator[Term]:
    yield t
    if isinstance(t, Successor):
        yield from walk(t.argument)
    elif isinstance(t, Call):
        yield from walk(t.first)
        yield from walk(t.second)


def variables(t: Term) -> set[str]:
    return {node.name for node in walk(t) if isinstance(node, Variable)}


def dependencies(t: Term) -> set[str]:
    return {node.name for node in walk(t) if isinstance(node, Call)}


def show(t: Term) -> str:
    if isinstance(t, Zero):
        return "0"
    if isinstance(t, Variable):
        return t.name
    if isinstance(t, Successor):
        return "S(" + show(t.argument) + ")"
    if isinstance(t, Call):
        return t.name + "(" + show(t.first) + "," + show(t.second) + ")"
    raise TypeError(t)


def substitute(t: Term, values: dict[str, Term]) -> Term:
    if isinstance(t, Zero):
        return t
    if isinstance(t, Variable):
        return values.get(t.name, t)
    if isinstance(t, Successor):
        return Successor(substitute(t.argument, values))
    if isinstance(t, Call):
        return Call(t.name, substitute(t.first, values),
                    substitute(t.second, values))
    raise TypeError(t)


@dataclass(frozen=True)
class Description:
    name: str
    base: Term
    step: Term


DESCRIPTIONS = (
    Description("p", ZERO, N),
    Description("b", A, ZERO),
    Description("alpha", A, predecessor(V)),
    Description("add", A, successor(V)),
    Description("T", ZERO, add(V, successor(N))),
    Description(
        "q", ZERO,
        selector(
            equality_error(successor(N), triangular(successor(V))),
            successor(V), V,
        ),
    ),
)


class Interpreter:
    """Evaluate binary recursors by iterating their declared step terms.

    For each symbol and second argument, cache the sequence of values.
    This avoids Python recursion depth limits for numerical iteration.
    The only recursion on Python's call stack is finite term evaluation
    through earlier descriptions.
    """

    def __init__(self, descriptions: tuple[Description, ...]) -> None:
        self.descriptions: dict[str, Description] = {}
        self.cache: dict[tuple[str, int], list[int]] = {}
        self.description_audit: list[dict] = []
        for description in descriptions:
            if description.name in self.descriptions:
                raise ValueError("Repeated description name: " + description.name)
            base_free = variables(description.base)
            step_free = variables(description.step)
            if not base_free <= {"a"}:
                raise ValueError("Bad base variables in " + description.name)
            if not step_free <= {"n", "v", "a"}:
                raise ValueError("Bad step variables in " + description.name)
            used = dependencies(description.base) | dependencies(description.step)
            if not used <= self.descriptions.keys():
                raise ValueError("Non-earlier dependency in " + description.name)
            self.descriptions[description.name] = description
            self.description_audit.append({
                "symbol": description.name,
                "arity": 2,
                "base": show(description.base),
                "step": show(description.step),
                "base_free_variables": sorted(base_free),
                "step_free_variables": sorted(step_free),
                "earlier_dependencies": sorted(used),
                "well_formed": True,
            })

    def evaluate(self, term: Term, environment: dict[str, int]) -> int:
        if isinstance(term, Zero):
            return 0
        if isinstance(term, Variable):
            return environment[term.name]
        if isinstance(term, Successor):
            return self.evaluate(term.argument, environment) + 1
        if isinstance(term, Call):
            return self.call(
                term.name,
                self.evaluate(term.first, environment),
                self.evaluate(term.second, environment),
            )
        raise TypeError(term)

    def call(self, name: str, first: int, second: int = 0) -> int:
        if type(first) is not int or type(second) is not int:
            raise ValueError("Numerical inputs must be integers")
        if first < 0 or second < 0:
            raise ValueError("Numerical inputs must be nonnegative")
        description = self.descriptions[name]
        key = (name, second)
        if key not in self.cache:
            self.cache[key] = [self.evaluate(description.base, {"a": second})]
        values = self.cache[key]
        while len(values) <= first:
            n = len(values) - 1
            values.append(self.evaluate(description.step, {
                "n": n, "v": values[-1], "a": second,
            }))
        return values[first]

    def normalize(self, term: Term, rewrite_limit: int = 10000) -> tuple[Term, int]:
        """Constructor rewriting using only the displayed computation rules."""
        rewrites = 0

        def normal(t: Term) -> Term:
            nonlocal rewrites
            if isinstance(t, (Zero, Variable)):
                return t
            if isinstance(t, Successor):
                return Successor(normal(t.argument))
            if not isinstance(t, Call):
                raise TypeError(t)
            first, second = normal(t.first), normal(t.second)
            description = self.descriptions[t.name]
            if isinstance(first, Zero):
                replacement = substitute(description.base, {"a": second})
            elif isinstance(first, Successor):
                replacement = substitute(description.step, {
                    "n": first.argument,
                    "v": Call(t.name, first.argument, second),
                    "a": second,
                })
            else:
                return Call(t.name, first, second)
            rewrites += 1
            if rewrites > rewrite_limit:
                raise RuntimeError("Symbolic rewrite limit exceeded")
            return normal(replacement)

        return normal(term), rewrites


class Checks:
    def __init__(self) -> None:
        self.counts: dict[str, int] = {}

    def equal(self, category: str, actual, expected, context=None) -> None:
        self.counts[category] = self.counts.get(category, 0) + 1
        if actual != expected:
            raise AssertionError({
                "category": category, "actual": actual,
                "expected": expected, "context": context,
            })


def induction_ledger() -> list[dict]:
    """Terms are explicit so the parameter budget is checked syntactically."""
    interval_error = gate(
        equality_error(alpha(A, N), ZERO),
        equality_error(rank(add(triangular(A), N)), A),
    )
    matrices = [
        ("coverage_and_separation", "exclusive", N, predecessor(N),
         "n=0 OR n=S(p(n))", []),
        ("alpha_shift", "equation", alpha(successor(N), successor(A)),
         alpha(N, A), "alpha(Sn,Sa)=alpha(n,a)", []),
        ("alpha_diagonal", "equation", alpha(N, N), ZERO,
         "alpha(n,n)=0", []),
        ("alpha_adjacent", "equation", alpha(N, successor(N)), ONE,
         "alpha(n,Sn)=1", []),
        ("gated_reconstruction", "equation",
         gate(alpha(A, N), alpha(alpha(N, A), A)),
         gate(alpha(A, N), N),
         "b(alpha(a,n),alpha(alpha(n,a),a))=b(alpha(a,n),n)", []),
        ("addition_right_zero", "equation", add(N, ZERO), N,
         "n+0=n", []),
        ("addition_right_successor", "equation",
         add(N, successor(A)), successor(add(N, A)),
         "n+Sa=S(n+a)", []),
        ("addition_commutativity", "equation", add(N, A), add(A, N),
         "n+a=a+n", []),
        ("alpha_cancellation", "equation", alpha(N, add(N, A)), A,
         "alpha(n,n+a)=a", []),
        ("alpha_sum_zero", "equation", alpha(add(N, A), A), ZERO,
         "alpha(n+a,a)=0", []),
        ("triangular_interval", "compiled_equation", interval_error, ZERO,
         "alpha(a,n)=0 -> q(T(a)+n)=a", ["q(T(a))=a"]),
        ("triangular_boundary", "equation", rank(triangular(N)), N,
         "q(T(n))=n", []),
    ]
    ledger = []
    for name, kind, first, second, matrix, assumptions in matrices:
        free = variables(first) | variables(second)
        if not free <= {"n", "a"}:
            raise AssertionError((name, free))
        # Equation induction is implemented by X with r=S(lhs), u=rhs.
        r = first if kind == "exclusive" else successor(first)
        u = second
        if variables(r) | variables(u) != free:
            raise AssertionError("Free variables changed in X compilation")
        ledger.append({
            "name": name,
            "induction_matrix": matrix,
            "matrix_type": kind,
            "free_variables": sorted(free),
            "fixed_parameters": sorted(free - {"n"}),
            "extra_fixed_assumptions": assumptions,
            "X_instance_r": show(r),
            "X_instance_u": show(u),
            "X_instance_count": 1,
            "parameter_budget_verified_syntactically": True,
        })
    if len(ledger) != 12:
        raise AssertionError("Unexpected induction ledger length")
    return ledger


def verify(arithmetic_bound: int, pair_bound: int) -> dict:
    if arithmetic_bound < 0 or pair_bound < 0:
        raise ValueError("Bounds must be nonnegative")
    interpreter = Interpreter(DESCRIPTIONS)
    checks = Checks()
    X, Y, Z = Variable("x"), Variable("y"), Variable("z")

    def value(term: Term, **environment: int) -> int:
        return interpreter.evaluate(term, environment)

    # Independent reference values are used only in the expected column.
    references = {
        "p": lambda n, a: 0 if n == 0 else n - 1,
        "b": lambda n, a: a if n == 0 else 0,
        "alpha": lambda n, a: max(0, a - n),
        "add": lambda n, a: n + a,
        "T": lambda n, a: n * (n + 1) // 2,
        "q": lambda n, a: (math.isqrt(8 * n + 1) - 1) // 2,
    }
    numerical_range = range(arithmetic_bound + 1)
    for name, reference in references.items():
        for n, a in itertools.product(numerical_range, repeat=2):
            checks.equal("recursor_reference_values",
                         interpreter.call(name, n, a), reference(n, a),
                         (name, n, a))
    for description in DESCRIPTIONS:
        for a in numerical_range:
            checks.equal("recursion_base_equations",
                         interpreter.call(description.name, 0, a),
                         interpreter.evaluate(description.base, {"a": a}),
                         (description.name, a))
            for n in numerical_range:
                previous = interpreter.call(description.name, n, a)
                checks.equal("recursion_successor_equations",
                             interpreter.call(description.name, n + 1, a),
                             interpreter.evaluate(description.step, {
                                 "n": n, "v": previous, "a": a,
                             }), (description.name, n, a))

    for x, y in itertools.product(numerical_range, repeat=2):
        env = {"x": x, "y": y}
        checks.equal("alpha_shift", value(alpha(successor(X), successor(Y)), **env),
                     value(alpha(X, Y), **env), (x, y))
        checks.equal("gated_reconstruction",
                     value(gate(alpha(Y, X), alpha(alpha(X, Y), Y)), **env),
                     value(gate(alpha(Y, X), X), **env), (x, y))
        checks.equal("equality_indicator", value(equality_indicator(X, Y), **env),
                     int(x == y), (x, y))
        checks.equal("equality_error", value(equality_error(X, Y), **env),
                     int(x != y), (x, y))
    for x in numerical_range:
        checks.equal("alpha_diagonal", value(alpha(X, X), x=x), 0, x)
        checks.equal("alpha_adjacent", value(alpha(X, successor(X)), x=x), 1, x)

    # Complete truth tables for Boolean error codes; 0 means true.
    truth_table = []
    for a in (0, 1):
        output = value(zero_test(X), x=a)
        checks.equal("Boolean_negation", output, int(a == 0), a)
        truth_table.append({"connective": "not", "inputs": [a], "output": output})
    connectives = {
        "and": (zero_test(gate(X, zero_test(Y))),
                lambda a, b: int(not (a == 0 and b == 0))),
        "or": (gate(zero_test(X), Y),
               lambda a, b: int(not (a == 0 or b == 0))),
        "implies": (gate(X, Y),
                    lambda a, b: int(not (a != 0 or b == 0))),
    }
    for name, (term, reference) in connectives.items():
        for a, b in itertools.product((0, 1), repeat=2):
            output = value(term, x=a, y=b)
            checks.equal("Boolean_" + name, output, reference(a, b), (a, b))
            truth_table.append({"connective": name, "inputs": [a, b],
                                "output": output})

    # Selector is a binary-language term, with addition used at this later stage.
    for x, y, z in itertools.product(range(min(arithmetic_bound, 8) + 1), repeat=3):
        checks.equal("selector_term", value(selector(X, Y, Z), x=x, y=y, z=z),
                     y if x == 0 else z, (x, y, z))

    for k in numerical_range:
        t = interpreter.call("T", k)
        checks.equal("triangular_boundaries", interpreter.call("q", t), k, k)
        for i in range(k + 1):
            checks.equal("triangular_intervals", interpreter.call("q", t + i),
                         k, (k, i))

    largest_pair_code = 0
    for x, y in itertools.product(range(pair_bound + 1), repeat=2):
        encoded = value(pair(X, Y), x=x, y=y)
        largest_pair_code = max(largest_pair_code, encoded)
        checks.equal("pairing_reference", encoded,
                     (x + y) * (x + y + 1) // 2 + y, (x, y))
        checks.equal("pairing_left_retraction", value(left(Z), z=encoded), x, (x, y))
        checks.equal("pairing_right_retraction", value(right(Z), z=encoded), y, (x, y))

    # Small tuple domains avoid explosive iterated pair codes while checking
    # each fixed finite length through four and the empty-tuple convention.
    tuple_cases = [()]
    for length in (1, 2, 3):
        tuple_cases.extend(itertools.product(range(3), repeat=length))
    tuple_cases.extend(itertools.product(range(2), repeat=4))
    largest_tuple_code = 0
    tuple_coordinates = 0
    for original in tuple_cases:
        encoded = 0
        for item in reversed(original):
            encoded = value(pair(X, Y), x=item, y=encoded)
        largest_tuple_code = max(largest_tuple_code, encoded)
        remainder = encoded
        for index, expected in enumerate(original):
            decoded = value(left(Z), z=remainder)
            checks.equal("tuple_coordinate_retractions", decoded, expected,
                         (list(original), index))
            tuple_coordinates += 1
            remainder = value(right(Z), z=remainder)
        checks.equal("tuple_terminal_code", remainder, 0, list(original))

    # Pure constructor-rewrite certificates: no arithmetic-induction lemmas.
    certificates = [
        ("predecessor_successor", predecessor(successor(X)), X),
        ("zero_test_zero", zero_test(ZERO), ONE),
        ("zero_test_successor", zero_test(successor(X)), ZERO),
        ("coverage_successor", successor(predecessor(successor(X))), successor(X)),
        ("equality_indicator_zero_zero", equality_indicator(ZERO, ZERO), ONE),
        ("equality_error_zero_zero", equality_error(ZERO, ZERO), ZERO),
    ]
    rewrite_certificate = []
    for name, lhs, rhs in certificates:
        left_normal, left_steps = interpreter.normalize(lhs)
        right_normal, right_steps = interpreter.normalize(rhs)
        checks.equal("constructor_rewrite_certificates", left_normal, right_normal, name)
        rewrite_certificate.append({
            "name": name,
            "lhs": show(lhs), "rhs": show(rhs),
            "normal_form": show(left_normal),
            "rewrite_count": left_steps + right_steps,
            "rules": "Only primitive-recursion base/successor computation equations",
            "verified": True,
        })

    ledger = induction_ledger()
    checks.equal("induction_ledger_count", len(ledger), 12)
    checks.equal("induction_ledger_parameter_bound",
                 max(len(item["fixed_parameters"]) for item in ledger), 1)
    checks.equal("maximum_primitive_function_arity",
                 max(item["arity"] for item in interpreter.description_audit), 2)

    return {
        "title": "Finite verification of binary exclusive-induction PRA helpers",
        "result": "PASS",
        "verification_scope": {
            "established_by_this_script": [
                "Well-formedness and earlier-dependency checks for six binary recursion descriptions",
                "Finite numerical agreement with independent reference arithmetic",
                "All Boolean truth-table entries for the gate-only formula compiler",
                "Finite gated-reconstruction, comparator, interval, pairing, and tuple checks",
                "Six symbolic constructor-rewrite certificates",
                "Free-variable and parameter-budget inspection of twelve displayed induction instances",
            ],
            "not_established_by_this_script": [
                "Formal correctness of deductions in intuitionistic or classical first-order logic",
                "Equivalence of the proposed axiom schema and ordinary PRA",
                "Validity for nonstandard structures or all numerical inputs",
                "Optimality or historical novelty of the axiomatization",
            ],
            "proof_location": "The accompanying mathematical report supplies the general proofs.",
            "evaluation_method": "Direct interpretation of primitive-recursion descriptions; memoized iteration",
            "reference_arithmetic_use": "Expected values only; the tested comparator does not call an equality oracle",
        },
        "finite_ranges": {
            "arithmetic_inputs_inclusive": [0, arithmetic_bound],
            "pair_inputs_inclusive": [0, pair_bound],
            "largest_pair_code": largest_pair_code,
            "tuple_cases": len(tuple_cases),
            "tuple_coordinates": tuple_coordinates,
            "tuple_domains": "Lengths 0 through 3 over {0,1,2}; length 4 over {0,1}",
            "largest_tuple_code": largest_tuple_code,
        },
        "counts": dict(sorted(checks.counts.items())),
        "total_checks": sum(checks.counts.values()),
        "binary_recursion_descriptions": interpreter.description_audit,
        "Boolean_error_truth_tables": truth_table,
        "constructor_rewrite_certificate": rewrite_certificate,
        "induction_instance_ledger": ledger,
        "induction_ledger_summary": {
            "fixed_preparation_X_instances": 12,
            "maximum_fixed_numerical_parameters": 1,
            "coverage_and_separation_share_one_instance": True,
            "later_QF_induction_instance": "One additional X instance after tuple coding",
            "scope": "Syntactic ledger only; the script does not prove the induction steps",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arithmetic-bound", type=int, default=32,
                        help="Inclusive upper bound for the basic arithmetic grid (default: 32)")
    parser.add_argument("--pair-bound", type=int, default=16,
                        help="Inclusive upper bound for both pairing inputs (default: 16)")
    parser.add_argument("--output", type=Path,
                        help="Also write the JSON report to this path")
    arguments = parser.parse_args()
    result = verify(arguments.arithmetic_bound, arguments.pair_bound)
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
