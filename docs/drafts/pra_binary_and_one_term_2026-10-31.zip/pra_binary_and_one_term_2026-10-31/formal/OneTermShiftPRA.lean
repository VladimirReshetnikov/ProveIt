/-
Copyright 2026. Prepared for Vladimir Reshetnikov.
Lean 4.19.0, no imports and no external packages.

Constructive core certificate for the ONE-TERM + FIXED-SHIFT PRA basis.
The one-term schema ranges over actual Term 2 syntax (one induction
variable and one numerical parameter), not all ambient functions.

Certified: separation and positive coverage; X1 implies identity-equation
induction; identity induction implies zero-equation induction; the fixed
shift equation gives a reflecting equality test; formula compilation and
one-parameter quantifier-free induction.

Scope: predecessor, selector, and subtraction are assumed through their
computation interfaces. The handwritten paper supplies their binary term
realization, the effective recursion-language grammar, pairing/parameter
coding, reverse axiomatization direction, and full first-order proof
translation. No claim of complete formalization of those steps is made.

The term/evaluation and later comparator/compiler portions adapt the
reviewed ThreeHelperPRA.lean certificate. The one-term bootstrap and
zero-induction interface are new.
-/

namespace OneTermShiftPRA

universe u v

/-- Computation interfaces only. Separation and coverage are derived from X1. -/
structure Core (M : Type v) where
  zero : M
  succ : M → M
  pred : M → M
  cond : M → M → M → M
  monus : M → M → M
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  cond_zero : ∀ a b, cond zero a b = a
  cond_succ : ∀ x a b, cond (succ x) a b = b
  monus_zero : ∀ y, monus zero y = y
  monus_succ : ∀ x y, monus (succ x) y = pred (monus x y)

/-- The one additional pure equation; introduced only after the X1 bootstrap. -/
def Shift {M : Type v} (C : Core M) : Prop :=
  ∀ x y, C.monus (C.succ x) (C.succ y) = C.monus x y

/-- A term has a finite variable context. Extra symbols have stated arities. -/
inductive Term (Sigma : Type u) (arity : Sigma → Nat) (n : Nat) : Type u where
  | var : Fin n → Term Sigma arity n
  | zero : Term Sigma arity n
  | succ : Term Sigma arity n → Term Sigma arity n
  | pred : Term Sigma arity n → Term Sigma arity n
  | cond : Term Sigma arity n → Term Sigma arity n →
      Term Sigma arity n → Term Sigma arity n
  | monus : Term Sigma arity n → Term Sigma arity n → Term Sigma arity n
  | extra : (f : Sigma) → (Fin (arity f) → Term Sigma arity n) →
      Term Sigma arity n

variable {M : Type v} {Sigma : Type u} {arity : Sigma → Nat}

abbrev Extra (M : Type v) (Sigma : Type u) (arity : Sigma → Nat) :=
  (f : Sigma) → (Fin (arity f) → M) → M

def Term.eval (C : Core M) (E : Extra M Sigma arity) {n : Nat}
    (t : Term Sigma arity n) (rho : Fin n → M) : M :=
  match t with
  | .var i => rho i
  | .zero => C.zero
  | .succ t => C.succ (t.eval C E rho)
  | .pred t => C.pred (t.eval C E rho)
  | .cond t s r => C.cond (t.eval C E rho) (s.eval C E rho) (r.eval C E rho)
  | .monus t s => C.monus (t.eval C E rho) (s.eval C E rho)
  | .extra f args => E f (fun i => (args i).eval C E rho)

/-- Variable 0 is the induction variable; variable 1 is the sole parameter. -/
def env2 (x a : M) : Fin 2 → M :=
  fun i => if i.val = 0 then x else a


/-- Exclusive disjunction, expanded constructively. -/
def Exclusive (A B : Prop) : Prop := (A ∨ B) ∧ ¬ (A ∧ B)

/-- X1 with exactly one numerical parameter and one schematic term. -/
def OneTermSchema (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (t : Term Sigma arity 2) (a : M),
    (∀ x, (x = C.zero ∨ x = C.succ (t.eval C E (env2 x a))) →
      x = t.eval C E (env2 (C.succ x) a)) →
    ∀ x, Exclusive (x = C.zero) (x = C.succ (t.eval C E (env2 x a)))

section Arithmetic

variable (C : Core M) (E : Extra M Sigma arity) (G : OneTermSchema C E)

include G

theorem constructor_coverage (x : M) :
    x = C.zero ∨ x = C.succ (C.pred x) := by
  have h := G (.pred (.var 0)) C.zero (by
    intro n _
    change n = C.pred (C.succ n)
    exact (C.pred_succ n).symm)
  exact (h x).1

theorem separation : C.zero ≠ C.succ C.zero := by
  intro bad
  have h := G (.pred (.var 0)) C.zero (by
    intro n _
    change n = C.pred (C.succ n)
    exact (C.pred_succ n).symm)
  apply (h C.zero).2
  constructor
  · rfl
  · change C.zero = C.succ (C.pred C.zero)
    simpa only [C.pred_zero] using bad

omit G in
theorem successor_injective {x y : M} (h : C.succ x = C.succ y) : x = y := by
  have hp := congrArg C.pred h
  simpa only [C.pred_succ] using hp

theorem successor_nonzero (x : M) : C.succ x ≠ C.zero := by
  intro h
  have hc := congrArg (fun q => C.cond q C.zero (C.succ C.zero)) h
  have h10 : C.succ C.zero = C.zero := by
    simpa only [C.cond_succ, C.cond_zero] using hc
  exact separation C E G h10.symm

theorem zero_cases (x : M) : x = C.zero ∨ x ≠ C.zero := by
  rcases constructor_coverage C E G x with hx | hx
  · exact Or.inl hx
  · apply Or.inr
    intro h0
    exact successor_nonzero C E G (C.pred x) (hx.symm.trans h0)

theorem conditional_nonzero (x a b : M) (hx : x ≠ C.zero) :
    C.cond x a b = b := by
  rcases constructor_coverage C E G x with h | h
  · exact False.elim (hx h)
  · rw [h, C.cond_succ]

theorem conditional_same (x a : M) : C.cond x a a = a := by
  rcases constructor_coverage C E G x with h | h
  · rw [h, C.cond_zero]
  · rw [h, C.cond_succ]

/-- X1[p composed with f] supplies induction for the identity equation f(n)=n. -/
theorem identity_induction (f : Term Sigma arity 2) (a : M)
    (base : f.eval C E (env2 C.zero a) = C.zero)
    (step : ∀ x, f.eval C E (env2 x a) = x →
      f.eval C E (env2 (C.succ x) a) = C.succ x) :
    ∀ x, f.eval C E (env2 x a) = x := by
  have one : f.eval C E (env2 (C.succ C.zero) a) = C.succ C.zero :=
    step C.zero base
  have guard : ∀ x,
      (x = C.zero ∨ x = C.succ (C.pred (f.eval C E (env2 x a)))) →
      f.eval C E (env2 x a) = x := by
    intro x hx
    rcases hx with hx | hx
    · subst x
      exact base
    · rcases constructor_coverage C E G (f.eval C E (env2 x a)) with hf | hf
      · have hx1 : x = C.succ C.zero := by
          calc
            x = C.succ (C.pred (f.eval C E (env2 x a))) := hx
            _ = C.succ C.zero := by rw [hf, C.pred_zero]
        have h01 : C.zero = C.succ C.zero := by
          calc
            C.zero = f.eval C E (env2 x a) := hf.symm
            _ = f.eval C E (env2 (C.succ C.zero) a) := by rw [hx1]
            _ = C.succ C.zero := one
        exact False.elim (separation C E G h01)
      · exact hf.trans hx.symm
  have h := G (.pred f) a (by
    intro n hn
    change n = C.pred (f.eval C E (env2 (C.succ n) a))
    change n = C.zero ∨ n = C.succ (C.pred (f.eval C E (env2 n a))) at hn
    rw [step n (guard n hn), C.pred_succ])
  intro x
  exact guard x (h x).1

/-- Zero induction uses f(n)=c(e(n),n,0), not a native-equality test. -/
theorem zero_induction (e : Term Sigma arity 2) (a : M)
    (base : e.eval C E (env2 C.zero a) = C.zero)
    (step : ∀ x, e.eval C E (env2 x a) = C.zero →
      e.eval C E (env2 (C.succ x) a) = C.zero) :
    ∀ x, e.eval C E (env2 x a) = C.zero := by
  let f : Term Sigma arity 2 := .cond e (.var 0) .zero
  have recover : ∀ x, f.eval C E (env2 x a) = x →
      e.eval C E (env2 x a) = C.zero := by
    intro x hx
    rcases constructor_coverage C E G (e.eval C E (env2 x a)) with he | he
    · exact he
    · have hx0 : x = C.zero := by
        have hs := hx.symm
        change x = C.cond (e.eval C E (env2 x a)) x C.zero at hs
        rw [he, C.cond_succ] at hs
        exact hs
      subst x
      exact base
  have h := identity_induction C E G f a
    (by
      change C.cond (e.eval C E (env2 C.zero a)) C.zero C.zero = C.zero
      rw [base, C.cond_zero])
    (by
      intro x hx
      change C.cond (e.eval C E (env2 (C.succ x) a)) (C.succ x) C.zero = C.succ x
      rw [step x (recover x hx), C.cond_zero])
  intro x
  exact recover x (h x)

/-- A test for the fixed numeral 1, constructed before native equality. -/
def oneError (x : M) : M := C.cond x (C.succ C.zero) (C.pred x)

theorem oneError_correct (x : M) : oneError C x = C.zero ↔ x = C.succ C.zero := by
  constructor
  · intro h
    rcases constructor_coverage C E G x with hx | hx
    · have bad : C.succ C.zero = C.zero := by
        simpa only [oneError, hx, C.cond_zero] using h
      exact False.elim (separation C E G bad.symm)
    · have hp : C.pred x = C.zero := by
        have hn : x ≠ C.zero := fun h0 =>
          successor_nonzero C E G (C.pred x) (hx.symm.trans h0)
        change C.cond x (C.succ C.zero) (C.pred x) = C.zero at h
        rw [conditional_nonzero C E G x _ _ hn] at h
        exact h
      exact hx.trans (congrArg C.succ hp)
  · intro h
    simp only [oneError, h, C.cond_succ, C.pred_succ]

variable (H : Shift C)

include H

theorem monus_diagonal (x : M) : C.monus x x = C.zero := by
  let e : Term Sigma arity 2 := .monus (.var 0) (.var 0)
  have h := zero_induction C E G e C.zero
    (by
      change C.monus C.zero C.zero = C.zero
      exact C.monus_zero _)
    (by
      intro n hn
      change C.monus n n = C.zero at hn
      change C.monus (C.succ n) (C.succ n) = C.zero
      exact (H n n).trans hn)
  exact h x

theorem monus_adjacent (x : M) : C.monus x (C.succ x) = C.succ C.zero := by
  let q : Term Sigma arity 2 := .monus (.var 0) (.succ (.var 0))
  let e : Term Sigma arity 2 := .cond q (.succ .zero) (.pred q)
  have h := zero_induction C E G e C.zero
    (by
      change oneError C (C.monus C.zero (C.succ C.zero)) = C.zero
      apply (oneError_correct C E G _).mpr
      exact C.monus_zero _)
    (by
      intro n hn
      change oneError C (C.monus n (C.succ n)) = C.zero at hn
      change oneError C (C.monus (C.succ n) (C.succ (C.succ n))) = C.zero
      rw [H]
      exact hn)
  exact (oneError_correct C E G _).mp (h x)

omit G in
theorem monus_predecessor_shift (x y : M) :
    C.pred (C.monus x (C.succ y)) = C.monus x y := by
  exact (C.monus_succ x (C.succ y)).symm.trans (H x y)

def error (x y : M) : M :=
  C.cond (C.monus x y) (C.monus y x) (C.succ C.zero)

/-- Fourth exact instance: a selector-guarded subtraction reconstruction. -/
theorem reconstruction (x y : M) :
    C.cond (C.monus y x) (C.monus (C.monus x y) y) x = x := by
  let s : Term Sigma arity 2 :=
    .cond (.monus (.var 1) (.var 0))
      (.monus (.monus (.var 0) (.var 1)) (.var 1)) (.var 0)
  have h := identity_induction C E G s y
    (by
      change C.cond (C.monus y C.zero)
        (C.monus (C.monus C.zero y) y) C.zero = C.zero
      rw [C.monus_zero, monus_diagonal C E G H]
      exact conditional_same C E G _ _)
    (by
      intro n hn
      change C.cond (C.monus y n) (C.monus (C.monus n y) y) n = n at hn
      change C.cond (C.monus y (C.succ n))
        (C.monus (C.monus (C.succ n) y) y) (C.succ n) = C.succ n
      rcases constructor_coverage C E G (C.monus y (C.succ n)) with hb | hb
      · have hb0 : C.monus y n = C.zero := by
          calc
            C.monus y n = C.pred (C.monus y (C.succ n)) :=
              (monus_predecessor_shift C H y n).symm
            _ = C.pred C.zero := congrArg C.pred hb
            _ = C.zero := C.pred_zero
        have hi : C.monus (C.monus n y) y = n := by
          simpa only [hb0, C.cond_zero] using hn
        rcases constructor_coverage C E G (C.monus n y) with ha | ha
        · have hyn : y = n := by
            simpa only [ha, C.monus_zero] using hi
          have bad : C.succ C.zero = C.zero := by
            calc
              C.succ C.zero = C.monus n (C.succ n) :=
                (monus_adjacent C E G H n).symm
              _ = C.monus y (C.succ n) := by rw [hyn]
              _ = C.zero := hb
          exact False.elim ((separation C E G) bad.symm)
        · let r := C.pred (C.monus n y)
          let q := C.monus r y
          have har : C.monus n y = C.succ r := ha
          have hpq : C.pred q = n := by
            calc
              C.pred q = C.monus (C.succ r) y := (C.monus_succ r y).symm
              _ = C.monus (C.monus n y) y :=
                congrArg (fun z => C.monus z y) har.symm
              _ = n := hi
          have hq : q = C.succ n := by
            rcases constructor_coverage C E G q with hq0 | hqs
            · have hn0 : n = C.zero := by
                calc
                  n = C.pred q := hpq.symm
                  _ = C.pred C.zero := congrArg C.pred hq0
                  _ = C.zero := C.pred_zero
              have hyr : y = C.succ r := by
                calc
                  y = C.monus n y := by rw [hn0, C.monus_zero]
                  _ = C.succ r := har
              have hq1 : q = C.succ C.zero := by
                calc
                  q = C.monus r (C.succ r) := congrArg (C.monus r) hyr
                  _ = C.succ C.zero := monus_adjacent C E G H r
              exact False.elim ((separation C E G) (hq0.symm.trans hq1))
            · exact hqs.trans (congrArg C.succ hpq)
          have hnext : C.monus (C.succ n) y = r := C.monus_succ n y
          rw [hb, C.cond_zero, hnext]
          exact hq
      · rw [hb, C.cond_succ])
  exact h x

theorem error_correct (x y : M) : error C x y = C.zero ↔ x = y := by
  constructor
  · intro h
    rcases constructor_coverage C E G (C.monus x y) with ha | ha
    · have hb : C.monus y x = C.zero := by
        simpa only [error, ha, C.cond_zero] using h
      have hr := reconstruction C E G H x y
      have hyx : y = x := by
        simpa only [hb, C.cond_zero, ha, C.monus_zero] using hr
      exact hyx.symm
    · have bad : C.succ C.zero = C.zero := by
        change C.cond (C.monus x y) (C.monus y x) (C.succ C.zero) = C.zero at h
        rw [ha, C.cond_succ] at h
        exact h
      exact False.elim ((separation C E G) bad.symm)
  · intro h
    subst y
    simp only [error, monus_diagonal C E G H, C.cond_zero]

theorem equality_cases (x y : M) : x = y ∨ x ≠ y := by
  rcases zero_cases C E G (error C x y) with h | h
  · exact Or.inl ((error_correct C E G H x y).mp h)
  · exact Or.inr (fun he => h ((error_correct C E G H x y).mpr he))

end Arithmetic

/-- Quantifier-free formulas include genuine intuitionistic implication. -/
inductive Formula (Sigma : Type u) (arity : Sigma → Nat) (n : Nat) : Type u where
  | equal : Term Sigma arity n → Term Sigma arity n → Formula Sigma arity n
  | truth : Formula Sigma arity n
  | falsehood : Formula Sigma arity n
  | conj : Formula Sigma arity n → Formula Sigma arity n → Formula Sigma arity n
  | disj : Formula Sigma arity n → Formula Sigma arity n → Formula Sigma arity n
  | impl : Formula Sigma arity n → Formula Sigma arity n → Formula Sigma arity n

def Formula.meaning (C : Core M) (E : Extra M Sigma arity) {n : Nat}
    (A : Formula Sigma arity n) (rho : Fin n → M) : Prop :=
  match A with
  | .equal s t => s.eval C E rho = t.eval C E rho
  | .truth => True
  | .falsehood => False
  | .conj A B => A.meaning C E rho ∧ B.meaning C E rho
  | .disj A B => A.meaning C E rho ∨ B.meaning C E rho
  | .impl A B => A.meaning C E rho → B.meaning C E rho

def Formula.compile {n : Nat} (A : Formula Sigma arity n) : Term Sigma arity n :=
  match A with
  | .equal s t => .cond (.monus s t) (.monus t s) (.succ .zero)
  | .truth => .zero
  | .falsehood => .succ .zero
  | .conj A B => .cond A.compile B.compile (.succ .zero)
  | .disj A B => .cond A.compile .zero B.compile
  | .impl A B => .cond A.compile B.compile .zero

def QFInduction (C : Core M) (E : Extra M Sigma arity) : Prop :=
  ∀ (A : Formula Sigma arity 2) (a : M),
    A.meaning C E (env2 C.zero a) →
    (∀ x, A.meaning C E (env2 x a) →
      A.meaning C E (env2 (C.succ x) a)) →
    ∀ x, A.meaning C E (env2 x a)

section Compilation

variable (C : Core M) (E : Extra M Sigma arity) (G : OneTermSchema C E)
  (H : Shift C)

include G H

/-- Correctness for every finite variable context, proved constructively. -/
theorem compiler_correct {n : Nat} (A : Formula Sigma arity n)
    (rho : Fin n → M) :
    A.compile.eval C E rho = C.zero ↔ A.meaning C E rho := by
  induction A with
  | equal s t => exact error_correct C E G H (s.eval C E rho) (t.eval C E rho)
  | truth => exact ⟨fun _ => True.intro, fun _ => rfl⟩
  | falsehood =>
      exact ⟨fun h => successor_nonzero C E G C.zero h, fun h => False.elim h⟩
  | conj A B ihA ihB =>
      change C.cond (A.compile.eval C E rho) (B.compile.eval C E rho)
        (C.succ C.zero) = C.zero ↔ (A.meaning C E rho ∧ B.meaning C E rho)
      rcases zero_cases C E G (A.compile.eval C E rho) with ha | ha
      · rw [ha, C.cond_zero]
        have hA := ihA.mp ha
        exact ⟨fun hb => ⟨hA, ihB.mp hb⟩, fun h => ihB.mpr h.2⟩
      · rw [conditional_nonzero C E G _ _ _ ha]
        have hnA : ¬ A.meaning C E rho := fun h => ha (ihA.mpr h)
        exact ⟨fun h => False.elim (successor_nonzero C E G C.zero h),
          fun h => False.elim (hnA h.1)⟩
  | disj A B ihA ihB =>
      change C.cond (A.compile.eval C E rho) C.zero (B.compile.eval C E rho) =
        C.zero ↔ (A.meaning C E rho ∨ B.meaning C E rho)
      rcases zero_cases C E G (A.compile.eval C E rho) with ha | ha
      · rw [ha, C.cond_zero]
        exact ⟨fun _ => Or.inl (ihA.mp ha), fun _ => rfl⟩
      · rw [conditional_nonzero C E G _ _ _ ha]
        constructor
        · intro hb
          exact Or.inr (ihB.mp hb)
        · intro h
          rcases h with hA | hB
          · exact False.elim (ha (ihA.mpr hA))
          · exact ihB.mpr hB
  | impl A B ihA ihB =>
      change C.cond (A.compile.eval C E rho) (B.compile.eval C E rho) C.zero =
        C.zero ↔ (A.meaning C E rho → B.meaning C E rho)
      rcases zero_cases C E G (A.compile.eval C E rho) with ha | ha
      · rw [ha, C.cond_zero]
        exact ⟨fun hb _ => ihB.mp hb, fun h => ihB.mpr (h (ihA.mp ha))⟩
      · rw [conditional_nonzero C E G _ _ _ ha]
        exact ⟨fun _ hA => False.elim (ha (ihA.mpr hA)), fun _ => rfl⟩

theorem formula_cases {n : Nat} (A : Formula Sigma arity n) (rho : Fin n → M) :
    A.meaning C E rho ∨ ¬ A.meaning C E rho := by
  rcases zero_cases C E G (A.compile.eval C E rho) with h | h
  · exact Or.inl ((compiler_correct C E G H A rho).mp h)
  · exact Or.inr (fun hA => h ((compiler_correct C E G H A rho).mpr hA))

/-- Induction transfer within exactly the certified one-parameter scope. -/
theorem quantifier_free_induction (A : Formula Sigma arity 2) (a : M)
    (base : A.meaning C E (env2 C.zero a))
    (step : ∀ x, A.meaning C E (env2 x a) →
      A.meaning C E (env2 (C.succ x) a)) :
    ∀ x, A.meaning C E (env2 x a) := by
  have h := zero_induction C E G A.compile a
    ((compiler_correct C E G H A (env2 C.zero a)).mpr base)
    (by
      intro x hx
      exact (compiler_correct C E G H A (env2 (C.succ x) a)).mpr
        (step x ((compiler_correct C E G H A (env2 x a)).mp hx)))
  intro x
  exact (compiler_correct C E G H A (env2 x a)).mp (h x)

end Compilation


#print axioms constructor_coverage
#print axioms separation
#print axioms identity_induction
#print axioms zero_induction
#print axioms reconstruction
#print axioms error_correct
#print axioms compiler_correct
#print axioms quantifier_free_induction

end OneTermShiftPRA
