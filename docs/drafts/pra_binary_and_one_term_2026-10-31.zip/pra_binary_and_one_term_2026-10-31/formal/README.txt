ONE-TERM PRA WITH ONE FIXED SHIFT EQUATION: LEAN CORE CERTIFICATE

File: OneTermShiftPRA.lean
Compiler: official Lean 4.19.0, commit 6caaee842e94 (Linux release).
Dependencies: Lean's standard distribution only; no imports or Mathlib.

Run:

  lean OneTermShiftPRA.lean

The complete checked source contains no sorry, admit, or axiom declaration.
Its assumptions are explicit structure fields and theorem hypotheses.
Eight final #print axioms commands report only [propext], the standard
Lean propositional-extensionality axiom. There is no Classical.choice,
excluded-middle axiom, quotient-soundness dependency, or sorryAx dependency
in those eight checked theorems.

CERTIFIED SCOPE

1. The schema X1 is restricted to actual finite Term 2 syntax, with one
   induction variable and one numerical parameter. Extra symbols carry
   explicit finite arities. The schema is not assumed for all ambient
   functions M -> M or for all ambient predicates.
2. X1[p] proves nontriviality 0 != S0 and positive constructor coverage.
3. X1[p composed with f] proves identity-equation induction f(n)=n.
4. Identity induction proves zero-equation induction via c(e(n),n,0).
5. With the separate fixed equation H: alpha(Sx,Sy)=alpha(x,y), the code
   proves the two subtraction diagonals, reconstruction, and the native
   equality reflection Delta(x,y)=0 iff x=y.
6. For syntactic quantifier-free formulas, including intuitionistic
   implication, the code proves the error-term compiler correct.
7. It derives quantifier-free induction with one numerical parameter.

The fixed equation H is a separate hypothesis introduced AFTER the X1
bootstrap. Coverage, separation, identity induction, and zero induction
do not depend on H in their theorem statements.

LIMITS OF THE CERTIFICATE

Core assumes predecessor, selector, and subtraction through their displayed
computation interfaces. Term syntax includes a ternary selector constructor.
The written report proves its realization as a term over binary symbols.
This certificate does not formalize that binary realization, the complete
effective primitive-recursion description grammar, tuple pairing/parameter
compression, the reverse axiomatization direction, or the translation of
arbitrary first-order derivations. Those claims have written mathematical
proofs in the report; they are not labeled machine-checked.

The certificate establishes the forward constructive core for X1+H. It
does not establish H from X1 alone.

PROVENANCE

The term/evaluation definitions and portions of the reconstruction and
formula-compiler proofs adapt the user's reviewed ThreeHelperPRA.lean
from pra_simplification_2026-10-31.zip. The X1 bootstrap, identity and zero
induction interfaces, fixed-shift dependency separation, and numeral-one
test are the new parts checked here.
