#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p .build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build pra_binary_and_one_term.tex > .build/latex-pass-1.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build pra_binary_and_one_term.tex > .build/latex-pass-2.txt
cp .build/pra_binary_and_one_term.pdf pra_binary_and_one_term.pdf
python3 artifacts/verify_binary_exclusive.py --output artifacts/verification_results.json > .build/verification-stdout.json
