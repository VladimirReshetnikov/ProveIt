TWO SMALL AXIOMATIZATIONS OF PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 31 October 2026.

START HERE

pra_binary_and_one_term.pdf   Complete report and mathematical proofs.
axioms.txt                    Exact standalone specifications.

RESULTS

1. Binary exclusive basis B_X: two computation-equation templates and
   one exclusive induction schema, with one fixed numerical parameter.
   All recursive function symbols are binary. This combines the strongest
   established template, arity, and parameter reductions in the five drafts.

2. One-term shift basis B_H: the same binary computation language, the
   one-term schema Y (called X1 in the older exclusive draft), and the
   fixed equation alpha(Sx,Sy)=alpha(x,y).
   Complete constructive equivalence is proved for this strengthened
   candidate. Y alone is not claimed complete.

Both bases work with either classical or intuitionistic logic.
Full ordinary PRA is an explicit conservative definitional extension.

CONTENTS

pra_binary_and_one_term.tex   Main LaTeX source.
sections/*.tex               All report sections.
formal/OneTermShiftPRA.lean   Compiled Lean certificate for the new core.
formal/README.txt            Exact formalization boundary.
formal/verification.txt      Compiler version, command, theorem dependencies.
artifacts/verify_binary_exclusive.py
                             Standard-library numerical and syntactic checks.
artifacts/verification_results.json
                             Recorded 20,123 successful finite checks.
reviewed_sources.json        Exact repository snapshot and source hashes.
VALIDATION.txt               Build, visual review, and verification record.
SHA256SUMS                   File integrity hashes.
build.sh                     Rebuild report and finite checks.

REBUILD

From this directory:
  ./build.sh

Requirements: pdflatex with the standard packages used in the preamble,
and Python 3.10 or later. No network access is required.
The script uses .build for intermediate TeX files.

To check the formal core:
  lean formal/OneTermShiftPRA.lean

The recorded compiler is official Lean 4.19.0. No external Lean package
or import is required.

VERIFICATION BOUNDARY

The complete equivalence theorems have explicit mathematical proofs.
The Lean certificate checks actual finite Term 2 syntax for the one-term
bootstrap, native equality reconstruction, formula compilation, and
one-parameter quantifier-free induction. The binary selector realization,
tuple coding, effective recursion language, reverse implication, and
full first-order proof translation are proved in the report rather
than certified by that Lean file.

Python checks are finite sanity checks, symbolic computation rewrites,
and a syntactic induction-parameter audit. They do not establish the
infinite schemas, cover nonstandard models, or prove minimality.

SOURCE AND NOVELTY SCOPE

All five current PRA draft archives were reviewed at repository commit
487040529a8792ae3239ae75e695424aee3d665c.
The incoming directory and index were also inspected.
Exact citations and comparison are in the report.

The exclusive schema, binary language, pairing construction, and one-term
candidate have clear predecessors in those drafts. The new contributions
are their verified combination, the gate-only equality bootstrap, and
the complete one-term-plus-shift proof with a checked constructive core.
No absolute shortest-encoding or historical-priority claim is made.
