#!/usr/bin/env python3
"""Finite diagnostics for initialized ordinary recursion and induction.

This file uses only the Python standard library. It implements a small,
explicit, acyclic term/descriptor syntax, translations in both directions,
and a Python METATHEORETIC evaluator. The evaluator is not a function symbol
of either arithmetic theory, and no primitive-recursive universal evaluator
is asserted. Finite numerical checks are not proofs of induction, internal
uniqueness, bi-interpretability, or claims about all nonstandard models.

Run: python3 artifacts/checks.py
The report is written beside this script as results.json.
No upstream program, network request, package installation, or external
proof assistant is used.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from itertools import product
import json
from math import factorial
from pathlib import Path


@dataclass(frozen=True)
class Term:
    tag: str
    children: tuple[Term, ...] = ()
    index: int | None = None
    symbol: str | None = None


ZERO = Term("zero")


def variable(index: int) -> Term:
    assert index >= 0
    return Term("variable", index=index)


def successor(term: Term) -> Term:
    return Term("successor", (term,))


ONE = successor(ZERO)


def call(symbol: str, *arguments: Term) -> Term:
    return Term("call", tuple(arguments), symbol=symbol)


def substitute(term: Term, replacements: tuple[Term, ...]) -> Term:
    """Capture-free substitution in a binder-free term body."""
    if term.tag == "variable":
        assert term.index is not None
        return replacements[term.index]
    return Term(
        term.tag,
        tuple(substitute(child, replacements) for child in term.children),
        term.index,
        term.symbol,
    )


def term_text(term: Term) -> str:
    if term.tag == "variable":
        return f"v{term.index}"
    if term.tag == "zero":
        return "0"
    if term.tag == "successor":
        return f"S({term_text(term.children[0])})"
    return f"{term.symbol}({','.join(map(term_text, term.children))})"


@dataclass(frozen=True)
class Descriptor:
    kind: str
    parameters: int
    base: Term | None
    update: Term

    @property
    def arity(self) -> int:
        return self.parameters + (1 if self.kind == "ordinary" else 2)


class Language:
    """A finite topologically ordered fragment of one description language."""

    def __init__(self, kind: str):
        assert kind in {"ordinary", "initialized"}
        self.kind = kind
        self.descriptors: dict[str, Descriptor] = {}

    def validate(self, term: Term, variables: int) -> None:
        if term.tag == "variable":
            assert term.index is not None and 0 <= term.index < variables
            assert not term.children
        elif term.tag == "zero":
            assert not term.children
        elif term.tag == "successor":
            assert len(term.children) == 1
        elif term.tag == "call":
            # Membership enforces an earlier dependency: no self-reference.
            assert term.symbol in self.descriptors
            assert len(term.children) == self.descriptors[term.symbol].arity
        else:
            raise AssertionError(f"Unknown term constructor: {term.tag}")
        for child in term.children:
            self.validate(child, variables)

    def add(
        self, symbol: str, parameters: int, update: Term, base: Term | None = None
    ) -> None:
        assert symbol not in self.descriptors and parameters >= 0
        # Both update interfaces are (counter, frozen tuple, previous value).
        # The initialized seed is deliberately absent from this interface.
        self.validate(update, parameters + 2)
        if self.kind == "ordinary":
            assert base is not None
            self.validate(base, parameters)
        else:
            assert base is None
        self.descriptors[symbol] = Descriptor(self.kind, parameters, base, update)


class Evaluator:
    """Python evaluation of finite descriptor DAGs, outside the theories."""

    def __init__(self, language: Language):
        self.language = language
        self.cache: dict[tuple[str, tuple[int, ...]], int] = {}

    def term(self, term: Term, environment: tuple[int, ...]) -> int:
        if term.tag == "zero":
            return 0
        if term.tag == "variable":
            assert term.index is not None
            return environment[term.index]
        if term.tag == "successor":
            return self.term(term.children[0], environment) + 1
        arguments = tuple(self.term(child, environment) for child in term.children)
        assert term.symbol is not None
        return self.function(term.symbol, arguments)

    def function(self, symbol: str, arguments: tuple[int, ...]) -> int:
        key = symbol, arguments
        if key in self.cache:
            return self.cache[key]
        descriptor = self.language.descriptors[symbol]
        assert len(arguments) == descriptor.arity
        assert all(isinstance(value, int) and value >= 0 for value in arguments)
        counter = arguments[0]
        if descriptor.kind == "ordinary":
            parameters = arguments[1:]
            assert descriptor.base is not None
            value = self.term(descriptor.base, parameters)
        else:
            value = arguments[1]
            parameters = arguments[2:]
        for stage in range(counter):
            value = self.term(descriptor.update, (stage, *parameters, value))
        self.cache[key] = value
        return value


class OrdinaryToInitialized:
    """F_g,h(n,b) maps to I_h*(n,g*(b),b), by finite syntax recursion."""

    def __init__(self, source: Language):
        assert source.kind == "ordinary"
        self.source = source
        self.target = Language("initialized")
        self.memo: dict[str, tuple[str, Term]] = {}

    def descriptor(self, symbol: str) -> tuple[str, Term]:
        if symbol not in self.memo:
            source = self.source.descriptors[symbol]
            assert source.base is not None
            base = self.term(source.base)
            update = self.term(source.update)
            target_symbol = "i_" + symbol
            self.target.add(target_symbol, source.parameters, update)
            self.memo[symbol] = target_symbol, base
        return self.memo[symbol]

    def term(self, term: Term) -> Term:
        if term.tag != "call":
            return Term(
                term.tag, tuple(self.term(t) for t in term.children), term.index
            )
        assert term.symbol is not None
        symbol, base = self.descriptor(term.symbol)
        arguments = tuple(self.term(t) for t in term.children)
        counter, parameters = arguments[0], arguments[1:]
        return call(symbol, counter, substitute(base, parameters), *parameters)


class InitializedToOrdinary:
    """I_h(n,a,b) maps to ordinary recursion with parameters (a,b)."""

    def __init__(self, source: Language):
        assert source.kind == "initialized"
        self.source = source
        self.target = Language("ordinary")
        self.memo: dict[str, str] = {}

    def descriptor(self, symbol: str) -> str:
        if symbol not in self.memo:
            source = self.source.descriptors[symbol]
            translated_update = self.term(source.update)
            # Insert a frozen seed at position 1 of the new update environment.
            # Old (n,b_1,...,b_k,v) becomes new (n,a,b_1,...,b_k,v).
            reindex = (variable(0),) + tuple(
                variable(i + 1) for i in range(1, source.parameters + 2)
            )
            update = substitute(translated_update, reindex)
            target_symbol = "o_" + symbol
            self.target.add(
                target_symbol, source.parameters + 1, update, base=variable(0)
            )
            self.memo[symbol] = target_symbol
        return self.memo[symbol]

    def term(self, term: Term) -> Term:
        if term.tag != "call":
            return Term(
                term.tag, tuple(self.term(t) for t in term.children), term.index
            )
        assert term.symbol is not None
        symbol = self.descriptor(term.symbol)
        return call(symbol, *(self.term(t) for t in term.children))


def ordinary_examples() -> Language:
    language = Language("ordinary")
    v = variable
    language.add("pred", 0, v(0), ZERO)
    language.add("add", 1, successor(v(2)), v(0))
    # sub(n,x) = x dotminus n; the first argument is the recursion counter.
    language.add("sub", 1, call("pred", v(2)), v(0))
    language.add("mul", 1, call("add", v(2), v(1)), ZERO)
    language.add("factorial", 0, call("mul", successor(v(0)), v(1)), ONE)
    language.add("is_zero", 0, ZERO, ONE)
    language.add("selector", 2, v(2), v(0))
    language.add(
        "affine", 2,
        call("add", call("mul", v(1), v(3)), call("add", v(0), v(2))),
        call("add", v(0), v(1)),
    )
    language.add(
        "three_parameters", 3,
        call("add", v(4), call("add", v(0), v(3))),
        call("add", v(0), call("mul", v(1), v(2))),
    )
    return language


def independent_value(symbol: str, arguments: tuple[int, ...]) -> int:
    n = arguments[0]
    if symbol == "pred":
        return max(n - 1, 0)
    if symbol == "add":
        return n + arguments[1]
    if symbol == "sub":
        return max(arguments[1] - n, 0)
    if symbol == "mul":
        return n * arguments[1]
    if symbol == "factorial":
        return factorial(n)
    if symbol == "is_zero":
        return int(n == 0)
    if symbol == "selector":
        return arguments[1] if n == 0 else arguments[2]
    if symbol == "affine":
        b, c = arguments[1:]
        value = b + c
        for stage in range(n):
            value = b * value + stage + c
        return value
    if symbol == "three_parameters":
        a, b, c = arguments[1:]
        return a + b * c + n * c + n * (n - 1) // 2
    raise AssertionError(symbol)


def translation_checks() -> dict:
    source = ordinary_examples()
    source_evaluator = Evaluator(source)
    forward = OrdinaryToInitialized(source)
    roots: dict[str, Term] = {}
    for symbol, descriptor in source.descriptors.items():
        root = call(symbol, *(variable(i) for i in range(descriptor.arity)))
        roots[symbol] = forward.term(root)
        forward.target.validate(roots[symbol], descriptor.arity)
    back = InitializedToOrdinary(forward.target)
    roundtrips = {symbol: back.term(root) for symbol, root in roots.items()}
    target_evaluator = Evaluator(forward.target)
    back_evaluator = Evaluator(back.target)
    rows = []
    for symbol, descriptor in source.descriptors.items():
        if symbol == "factorial":
            grid = product(range(9))
        elif symbol in {"affine", "three_parameters"}:
            grid = product(range(5), *(range(4) for _ in range(descriptor.parameters)))
        else:
            grid = product(*(range(9) for _ in range(descriptor.arity)))
        count = 0
        for arguments in grid:
            expected = independent_value(symbol, arguments)
            original = source_evaluator.function(symbol, arguments)
            translated = target_evaluator.term(roots[symbol], arguments)
            returned = back_evaluator.term(roundtrips[symbol], arguments)
            assert original == translated == returned == expected
            count += 1
        rows.append({"symbol": symbol, "cases": count, "status": "passed"})

    # A source initialized program with a genuinely arbitrary seed, rather than
    # only seeds produced by translation of ordinary programs.
    initialized = Language("initialized")
    initialized.add("seeded_counter", 0, variable(0))
    initialized.add("seeded_successor", 0, successor(variable(1)))
    initialized.add("overwrite_parameter", 1, variable(1))
    initialized.add(
        "dependent_counter", 1,
        call("seeded_successor", variable(0),
             call("seeded_successor", variable(1), variable(2))),
    )
    to_ordinary = InitializedToOrdinary(initialized)
    init_roots = {
        name: call(name, *(variable(i) for i in range(desc.arity)))
        for name, desc in initialized.descriptors.items()
    }
    ordinary_roots = {name: to_ordinary.term(t) for name, t in init_roots.items()}
    to_initialized = OrdinaryToInitialized(to_ordinary.target)
    init_roundtrips = {
        name: to_initialized.term(t) for name, t in ordinary_roots.items()
    }
    ie = Evaluator(initialized)
    oe = Evaluator(to_ordinary.target)
    re = Evaluator(to_initialized.target)
    initialized_rows = []
    for name, desc in initialized.descriptors.items():
        count = 0
        returned = init_roundtrips[name]
        assert returned.tag == "call"
        # The initializer a appears both as seed and as a frozen parameter.
        assert returned.children[1] == variable(1)
        assert returned.children[2] == variable(1)
        assert len(returned.children) == desc.arity + 1
        for arguments in product(*(range(6) for _ in range(desc.arity))):
            n, seed = arguments[:2]
            if name == "seeded_counter":
                expected = seed if n == 0 else n - 1
            elif name == "seeded_successor":
                expected = seed + n
            elif name == "overwrite_parameter":
                expected = seed if n == 0 else arguments[2]
            else:
                expected = seed + n * arguments[2] + n * (n - 1) // 2
            assert ie.function(name, arguments) == expected
            assert ie.function(name, arguments) == oe.term(ordinary_roots[name], arguments)
            assert ie.function(name, arguments) == re.term(returned, arguments)
            count += 1
        initialized_rows.append({
            "symbol": name, "cases": count, "status": "passed",
            "source": term_text(init_roots[name]),
            "roundtrip": term_text(returned),
            "redundant_frozen_seed_verified": True,
        })

    # Deliberate mutation: drop the translated base g(b) and always use seed 0.
    good = roots["add"]
    bad = call(good.symbol or "", good.children[0], ZERO, *good.children[2:])
    witness = (0, 3)
    correct = target_evaluator.term(good, witness)
    mutated = target_evaluator.term(bad, witness)
    assert correct == 3 and mutated == 0 and correct != mutated

    # Deliberate syntax mutation: an update is not permitted to refer to itself.
    rejected_self_reference = False
    broken = Language("initialized")
    try:
        broken.add("loop", 0, call("loop", variable(0), variable(1)))
    except AssertionError:
        rejected_self_reference = True
    assert rejected_self_reference
    return {
        "ordinary_to_initialized_to_ordinary": rows,
        "initialized_to_ordinary_to_initialized": initialized_rows,
        "ordinary_cases": sum(row["cases"] for row in rows),
        "initialized_cases": sum(row["cases"] for row in initialized_rows),
        "mutations_detected": [
            {"mutation": "Replace translated initial value by 0",
             "function": "add", "arguments": witness,
             "correct_value": correct, "mutated_value": mutated},
            {"mutation": "Admit a self-referential update descriptor",
             "rejected_by_syntax_validation": rejected_self_reference},
        ],
    }


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple[Node, ...] = ()

    def size(self) -> int:
        return 1 + sum(child.size() for child in self.children)


def node(label: str, *children: Node) -> Node:
    return Node(label, tuple(children))


def forall(names: list[str], formula: Node) -> Node:
    for name in reversed(names):
        formula = node("forall " + name, formula)
    return formula


def induction_ast(parameters: list[Node], width_two: bool = False) -> Node:
    zero, n = node("0"), node("n")

    def matrix(argument: Node) -> Node:
        if not width_two:
            return node("A", argument, *parameters)
        terms = [node(symbol, argument, *parameters) for symbol in ("f", "g", "h", "k")]
        return node("or", node("=", terms[0], terms[1]), node("=", terms[2], terms[3]))

    return forall(
        [p.label for p in parameters],
        node(
            "implies",
            node("and", matrix(zero),
                 forall(["n"], node("implies", matrix(n), matrix(node("S", n))))),
            forall(["n"], matrix(n)),
        ),
    )


def metric_checks() -> dict:
    rows = []
    bivariate_rows = []
    for m in range(1, 9):
        zero, n, a = node("0"), node("n"), node("a")
        frozen = [node("b" + str(i)) for i in range(m - 1)]
        parameters = [a, *frozen]
        names = [t.label for t in parameters]
        base = forall(names, node("=", node("R", zero, *parameters), a))
        ordinary_step = forall(
            ["n", *names],
            node("=", node("R", node("S", n), *parameters),
                 node("h", n, *frozen, node("R", n, *parameters))),
        )
        swap_step = forall(
            ["n", *names],
            node("=", node("R", node("S", n), *parameters),
                 node("h", n, *parameters, node("R", a, n, *frozen))),
        )
        sep = node("implies", node("=", zero, node("S", zero)), node("bottom"))
        f = lambda argument: node("f", argument, *parameters)
        old_schema = forall(
            names,
            node("implies", forall(["n"], node("=", f(node("S", n)), f(n))),
                 forall(["n"], node("or", node("=", node("T", f(zero), a), a),
                                    node("=", f(n), a)))),
        )
        direct = induction_ast(parameters)
        expanded = induction_ast(parameters, width_two=True)
        old_bodies = [node("b"), node("v"), node("C", node("D", a, n), n, a)]
        row = {
            "m_recursion_arguments_including_seed": m,
            "q_induction_parameters": m,
            "initialized_base": base.size(),
            "initialized_ordinary_step": ordinary_step.size(),
            "ordinary_computation": base.size() + ordinary_step.size(),
            "ground_separation": sep.size(),
            "qfi_template": direct.size(),
            "new_display": base.size() + ordinary_step.size() + sep.size() + direct.size(),
            "new_mandatory_helper_bodies": 0,
            "proof_only_predecessor_body": 1,
            "best_existing_display": base.size() + swap_step.size() + sep.size() + old_schema.size(),
            "best_existing_helper_bodies": sum(t.size() for t in old_bodies),
            "width_two_expanded_induction": expanded.size(),
            "width_two_expanded_total": base.size() + ordinary_step.size() + sep.size() + expanded.size(),
        }
        assert row["ordinary_computation"] == 6 * m + 12
        assert row["qfi_template"] == 5 * m + 14
        assert row["new_display"] == 11 * m + 32
        assert row["best_existing_display"] == 11 * m + 39
        assert row["best_existing_helper_bodies"] == 8
        assert row["width_two_expanded_induction"] == 17 * m + 53
        assert row["width_two_expanded_total"] == 23 * m + 71
        rows.append(row)
        for q in range(5):
            q_parameters = [node("c" + str(i)) for i in range(q)]
            measured = base.size() + ordinary_step.size() + sep.size()
            measured += induction_ast(q_parameters).size()
            assert measured == 6 * m + 5 * q + 32
            expanded_count = induction_ast(q_parameters, width_two=True).size()
            assert expanded_count == 17 * q + 53
            bivariate_rows.append({"m": m, "q": q, "display": measured})
    assert rows[0]["new_display"] == 43
    assert rows[0]["best_existing_display"] == 50
    assert rows[0]["width_two_expanded_induction"] == 70
    assert rows[0]["width_two_expanded_total"] == 94
    return {
        "node_convention": (
            "One per leaf, application, equality, connective, falsity and individual quantifier; "
            "negation expands to implication to falsity; 1 expands to S0."
        ),
        "new_bivariate_formula": "6*m + 5*q + 32",
        "new_diagonal_convention_q_equals_m": "11*m + 32",
        "width_two_expanded_induction_formula": "17*q + 53",
        "width_two_expanded_total_formula": "6*m + 17*q + 71",
        "rows": rows,
        "bivariate_rows": bivariate_rows,
        "comparison_limitations": [
            "The new QFI metavariable ranges over formulas; existing constancy metavariables range over terms.",
            "The 43-node display is not a like-for-like optimum within a term-only schema restriction.",
            "Both theories admit every finite arity; one displayed arity is not the entire specification.",
            "Descriptor encoding, bindings and schema enumerators are not included.",
            "The fully expanded width-two formula is counted without treating its four-term disjunction as one atom.",
        ],
    }


def algebra_and_boolean_checks() -> dict:
    evaluator = Evaluator(ordinary_examples())
    v = variable
    difference = call("add", call("sub", v(1), v(0)), call("sub", v(0), v(1)))
    equality_bit = call("selector", difference, ZERO, ONE)
    count = 0
    for x, y in product(range(13), repeat=2):
        add = evaluator.function("add", (x, y))
        sub = evaluator.function("sub", (y, x))
        reverse_sub = evaluator.function("sub", (x, y))
        assert add == x + y == evaluator.function("add", (y, x))
        assert sub == max(x - y, 0)
        assert (sub == 0) == (x <= y)
        assert (sub == reverse_sub == 0) == (x == y)
        assert evaluator.term(equality_bit, (x, y)) == int(x != y)
        assert evaluator.function("pred", (x + 1,)) == x
        assert (x == 0) or (x == evaluator.function("pred", (x,)) + 1)
        count += 1
    table = []
    for antecedent, consequent in product((0, 1), repeat=2):
        computed = evaluator.function("selector", (antecedent, consequent, 0))
        expected = int((antecedent == 0) and (consequent == 1))
        assert computed == expected
        table.append({"antecedent_bit": antecedent, "consequent_bit": consequent,
                      "implication_bit": computed})
    return {
        "natural_number_pair_cases": count,
        "bounds": "0 <= x,y <= 12",
        "checked": [
            "predecessor on successors", "addition and commutativity",
            "monus zero criterion", "two-sided monus equality criterion",
            "a syntactically built equality bit", "zero-or-successor coverage on natural inputs",
        ],
        "boolean_implication_truth_table": table,
        "bit_convention": "Error bits as in the paper: 0 denotes truth and 1 denotes falsehood.",
        "limitation": "The finite Boolean table is not a proof about arbitrary intuitionistic formulas.",
    }


def product_counterexample() -> dict:
    zero = (0, 0)
    witness = (0, 1)
    pred = lambda x: tuple(max(t - 1, 0) for t in x)
    succ = lambda x: tuple(t + 1 for t in x)
    cover = lambda x: x == zero or x == succ(pred(x))
    assert not cover(witness)
    assert cover(zero)
    assert all(cover(succ(x)) for x in product(range(5), repeat=2))

    def distance(x: int, y: int) -> int:
        return y - x if x <= y else x - y - 1

    points = list(product(range(4), repeat=2))
    reflection_checks = 0
    for x, y in product(points, repeat=2):
        dxy = tuple(distance(xi, yi) for xi, yi in zip(x, y))
        dyx = tuple(distance(yi, xi) for xi, yi in zip(x, y))
        assert (dxy == dyx) == (x == y)
        reflection_checks += 1
    return {
        "structure": "componentwise N x N",
        "formula": "x=0 OR x=S(p(x))",
        "witness": witness,
        "zero": zero,
        "successor_of_predecessor": succ(pred(witness)),
        "coverage_at_witness": False,
        "coverage_at_zero": True,
        "successor_step_instances_checked": 25,
        "distance_symmetry_reflection_pair_cases": reflection_checks,
        "scope": (
            "This explicitly checks the failed coverage instance and finite reflection examples. "
            "The claim that the full product satisfies all atomic induction instances "
            "is a mathematical argument in the paper, not established by this finite test."
        ),
    }


def main() -> None:
    result = {
        "status": "passed",
        "scope": "Finite diagnostics and exact finite syntax counts, not a formal proof certificate.",
        "script_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "translations": translation_checks(),
        "metrics": metric_checks(),
        "algebra_and_booleans": algebra_and_boolean_checks(),
        "product_counterexample": product_counterexample(),
    }
    destination = Path(__file__).resolve().with_name("results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "ordinary_translation_cases": result["translations"]["ordinary_cases"],
        "initialized_translation_cases": result["translations"]["initialized_cases"],
        "mutations_detected": len(result["translations"]["mutations_detected"]),
        "new_display": result["metrics"]["rows"][0]["new_display"],
        "existing_display": result["metrics"]["rows"][0]["best_existing_display"],
        "width_two_expanded_total": result["metrics"]["rows"][0]["width_two_expanded_total"],
        "results": str(destination),
    }, indent=2))


if __name__ == "__main__":
    main()
