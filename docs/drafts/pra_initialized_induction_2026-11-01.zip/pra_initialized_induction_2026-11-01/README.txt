PRA FROM INITIALIZED RECURSION
Research package prepared for Vladimir Reshetnikov, 1 November 2026

START HERE

report.pdf is the complete research article; report.tex is its standalone
editable LaTeX source. AXIOMS.txt specifies both effective theories.

MAIN RESULTS

1. Recommended readable basis: initialized ordinary recursion,
   0 != S0, and ordinary quantifier-free induction. Each matching logic
   gives a theory definitionally equivalent, hence bi-interpretable and
   equiconsistent, with first-order PRA. Both carriers and equalities
   remain native, and the round-trip isomorphisms are the identity.

2. Restricted induction theorem: it suffices to allow induction only for
   disjunctions of two native equations. This works constructively.
   Atomic-equation induction alone fails, as shown by N x N; its
   coordinate-swap automorphism also excludes parameter-free
   bi-interpretability with PRA. Two is an exact relative width threshold.

3. Transparent size comparison: the recommended formula-schema display
   costs 43 nodes at the representative arity, versus 50 in the strongest
   current stationary-term drafts. Mandatory selected helper bodies are
   0 versus 8. This changes the schematic class from terms to formulas.
   It is NOT an optimum claim inside the old term-only search space.
   Fully expanding the two-equation term schema gives 94 nodes, not 43.

CONTENTS

report.tex / report.pdf       Complete specification, proofs, and comparison
AXIOMS.txt                   Concise effective theory cards
build.py                     Offline PDF and diagnostic rebuild
artifacts/checks.py           Descriptor compilers and finite diagnostics
artifacts/results.json       Diagnostic results and exact syntax counts
formal/TwoEquation.lean       Checked constructive arithmetic and QF kernel
formal/TwoEquation.log        Thirteen successful axiom audits
formal/SCOPE.txt              Precise formalization scope and assumptions
formal/verification.json     Verified Lean version and source/log hashes
formal/lean-toolchain         Lean 4.19.0
audit/source_manifest.json   Eight immutable source archives and hashes
audit/mathematical_review.txt Independent mathematical audit
audit/validation.json         Deliverable validation and visual review record
SHA256SUMS.txt                Final package integrity checksums

REBUILD

  python3 build.py

Python 3 and a standard TeX Live installation are needed. No network access,
upstream scripts, or original draft ZIPs are required. The build uses
pdflatex with shell escape disabled.

  python3 build.py --checks-only
  python3 build.py --pdf-only
  python3 build.py --lean /path/to/lean

The optional Lean replay uses Lean 4.19.0 and only its bundled Std library.
No Mathlib download is required.

VERIFICATION SCOPE

The Lean file works over an arbitrary carrier with explicit admitted-term
certificates and restricted induction hypotheses. It checks the arithmetic
reconstruction, native equality reflection, Boolean compilation including
implication, and the full QF-induction endpoint. All thirteen audited
declarations have no global axiom dependencies. The Basis hypotheses remain
explicit parameters; this does not prove arithmetic without assumptions.

Concrete complete descriptor syntax, both recursion compilers, the
first-order proof-translation calculus, interpretation round trips, and the
product/automorphism lower bound are proved in the paper, not fully
formalized in Lean. The Python checks are finite diagnostics, not proofs
about nonstandard models. Its interpreter is metatheoretic and does not
assert an internal universal primitive-recursive evaluator.

The two logical equivalences are separate matching-logic statements.
No absolute minimum or broad historical novelty claim is made.

PROVENANCE

All eight current docs/drafts archives were retrieved and their Git blob
hashes verified at ProveIt commit:
8dc884c9db3e3a9bf1c54d6e89892b13e23f2e6a

The source manifest records exact versions; the paper credits the prior
drafts and standard background. Original archives are not duplicated.

