#!/usr/bin/env python3
"""Rebuild the research paper and finite diagnostics using local tools."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(command: list[str], log: Path | None = None) -> str:
    result = subprocess.run(
        command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, check=False,
    )
    if log is not None:
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(result.stdout)
    if result.returncode:
        print(result.stdout[-12000:], file=sys.stderr)
        raise SystemExit(result.returncode)
    return result.stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--checks-only", action="store_true")
    group.add_argument("--pdf-only", action="store_true")
    parser.add_argument("--lean", help="Optional path to Lean 4.19.0")
    args = parser.parse_args()
    if not args.pdf_only:
        print(run([sys.executable, "artifacts/checks.py"]).strip())
    if not args.checks_only:
        executable = shutil.which("pdflatex")
        if executable is None:
            raise SystemExit("pdflatex is required to compile the paper.")
        for number in range(1, 4):
            run(
                [executable, "-no-shell-escape", "-interaction=nonstopmode",
                 "-halt-on-error", "report.tex"],
                ROOT / "audit" / f"latex-pass-{number}.log",
            )
        log = (ROOT / "report.log").read_text()
        issues = [
            line for line in log.splitlines()
            if ("Overfull" in line or "undefined" in line
                or "Rerun to get" in line or "Label(s) may have changed" in line)
        ]
        result = {
            "status": "passed" if not issues else "review_required",
            "latex_issues": issues,
            "pdf_sha256": hashlib.sha256((ROOT / "report.pdf").read_bytes()).hexdigest(),
            "source_sha256": hashlib.sha256((ROOT / "report.tex").read_bytes()).hexdigest(),
            "scope": "Compilation and log check; visual inspection is separate.",
        }
        (ROOT / "audit" / "build.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result, indent=2))
        if issues:
            raise SystemExit(1)
    if args.lean:
        output = run([args.lean, "formal/TwoEquation.lean"],
                     ROOT / "formal" / "TwoEquation.log")
        audits = output.count("does not depend on any axioms")
        if audits != 13 or "sorryAx" in output or "Classical.choice" in output:
            raise SystemExit("Unexpected Lean axiom audit output.")
        print(f"Lean checked; {audits} declarations have no global axiom dependencies.")


if __name__ == "__main__":
    main()

