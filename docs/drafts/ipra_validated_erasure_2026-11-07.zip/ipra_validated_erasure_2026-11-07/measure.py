"""Reproduce the complete-program comparison, offline, without executing checkers.

Run from any directory with Python 3.10 or later. The supplied receipts were
produced using CPython 3.12.14; ast.unparse may change between Python versions.
The inherited source_measure.py is used unchanged. No checker, proof producer,
or external repository module is imported or executed by this script.
"""

import ast
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import tempfile


ROOT = Path(__file__).resolve().parent
COMPARISON = ROOT / "comparison"
RESULTS = ROOT / "results"
COORDINATES = ("normalized_tokens", "ast_nodes", "normalized_bytes")
CANDIDATES = ("checker.py", "checker_compact.py")
COMMON_DRIVER = """try:
    take = json.load(sys.stdin).pop
    1 / check(take(), [])
    print('ACCEPT')
except:
    print('REJECT')
    sys.exit(1)
"""


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def common_driver(source):
    """Replace only the final public driver, leaving the complete kernel intact."""
    tree = ast.parse(source)
    if not tree.body or not isinstance(tree.body[-1], ast.Try):
        raise ValueError("Expected a final top-level try/except public driver")
    old_driver = ast.unparse(tree.body[-1])
    for expected in ("json.load(", "check(take(), [])", "print('ACCEPT')",
                     "print('REJECT')"):
        if expected not in old_driver:
            raise ValueError("Unrecognized driver: " + expected)
    tree.body[-1] = ast.parse(COMMON_DRIVER).body[0]
    return ast.unparse(ast.fix_missing_locations(tree)) + "\n"


def envelope(rows, key):
    return {coordinate: min(row[key][coordinate] for row in rows)
            for coordinate in COORDINATES}


def attainers(rows, key, minimum):
    return {coordinate: [row["label"] for row in rows
                         if row[key][coordinate] == minimum[coordinate]]
            for coordinate in COORDINATES}


def improvements(measured, minimum):
    return {coordinate: {"baseline": minimum[coordinate],
                         "candidate": measured[coordinate],
                         "saved": minimum[coordinate] - measured[coordinate],
                         "strictly_smaller": measured[coordinate] < minimum[coordinate]}
            for coordinate in COORDINATES}


def tex_escape(text):
    return text.replace("_", "\\_")


def table_row(label, values):
    return label + " & " + " & ".join(str(values[k]) for k in COORDINATES) + " \\\\"


def main():
    manifest = json.loads((COMPARISON / "manifest.json").read_text())
    metric_path = COMPARISON / manifest["metric"]["local_file"]
    if digest(metric_path) != manifest["metric"]["sha256"]:
        raise ValueError("The inherited measurement source has changed")
    if len(manifest["archives"]) != 6 or len(manifest["programs"]) != 11:
        raise ValueError("Expected the pinned six-archive, eleven-program corpus")
    actual_files = {p.relative_to(COMPARISON).as_posix()
                    for p in (COMPARISON / "baselines").glob("*.py")}
    expected_files = {entry["local_file"] for entry in manifest["programs"]}
    if actual_files != expected_files:
        raise ValueError("Baseline file inventory differs from the manifest")
    for entry in manifest["programs"]:
        path = COMPARISON / entry["local_file"]
        if digest(path) != entry["sha256"] or path.stat().st_size != entry["raw_bytes"]:
            raise ValueError("Changed baseline: " + entry["local_file"])

    spec = importlib.util.spec_from_file_location("inherited_source_measure", metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)

    def complete_metrics(path):
        # The legacy helper also returns a field named "core"; it is not used.
        return {key: value for key, value in metric.metrics(path).items() if key != "core"}

    with tempfile.TemporaryDirectory(prefix="ipra_measure_") as temporary:
        temporary = Path(temporary)

        def measured_pair(path, label):
            controlled = temporary / (label.replace("/", "__") + ".py")
            controlled.write_text(common_driver(path.read_text()))
            return {"delivered": complete_metrics(path),
                    "common_driver": complete_metrics(controlled)}

        programs = []
        for entry in manifest["programs"]:
            path = COMPARISON / entry["local_file"]
            programs.append({**entry, **measured_pair(path, entry["label"])})
        candidates = [{"label": name, "arithmetic_profile": "scalar iteration",
                       **measured_pair(ROOT / name, name)} for name in CANDIDATES]

    minima = {key: envelope(programs, key) for key in ("delivered", "common_driver")}
    minimum_attainers = {key: attainers(programs, key, minima[key]) for key in minima}
    for candidate in candidates:
        candidate["comparison"] = {
            key: improvements(candidate[key], minima[key]) for key in minima}

    report = {
        "format": "ipra-complete-checker-measurements-v1",
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "archive_count": len(manifest["archives"]),
        "program_count": len(programs),
        "metric": manifest["metric"],
        "measurement_boundary": "Entire source: imports, input, validation, inference, exceptions, output, and exit status.",
        "normalization": "The unchanged inherited normalizer removes genuine docstrings, uses ast.unparse, and counts significant tokens, AST nodes, and UTF-8 bytes. Comments and layout do not affect the three comparison coordinates.",
        "not_counted": "The fixed ordinary Python runtime and standard library; no project-specific dependency is omitted.",
        "common_driver_source": COMMON_DRIVER,
        "common_driver_transformation": "Replace the final top-level try/except by the identical supplied stdin/sys.exit driver using Python's AST. No function definition or other kernel statement changes.",
        "archives": manifest["archives"],
        "coordinatewise_minima": minima,
        "minimum_attainers": minimum_attainers,
        "programs": programs,
        "candidates": candidates,
        "limitations": "A finite-corpus implementation comparison under one fixed source metric, not a global minimality theorem. The three minima need not be attained by one program. Baselines are parsed and measured, not certified sound by this script."
    }
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / "measurements.json").write_text(json.dumps(report, indent=2) + "\n")

    summary = ["% Generated by measure.py; all sources and hash checks are in measurements.json.",
               "\\begin{tabular}{@{}lrrr@{}}", "\\toprule",
               "Complete program & Tokens & AST nodes & Bytes \\\\", "\\midrule",
               table_row("Current delivered envelope", minima["delivered"])]
    summary += [table_row("\\texttt{" + tex_escape(row["label"]) + "}", row["delivered"])
                for row in candidates]
    summary += ["\\midrule", table_row("Current common-driver envelope", minima["common_driver"])]
    summary += [table_row("\\texttt{" + tex_escape(row["label"]) + "}, common driver", row["common_driver"])
                for row in candidates]
    summary += ["\\bottomrule", "\\end{tabular}"]
    (RESULTS / "metrics_table.tex").write_text("\n".join(summary) + "\n")

    baseline_table = ["% Generated by measure.py. Short archive names omit ipra_ and the shared date.",
                      "\\begin{tabular}{@{}lrrr@{}}", "\\toprule",
                      "Delivered baseline & Tokens & AST nodes & Bytes \\\\", "\\midrule"]
    for row in programs:
        archive, filename = row["label"].split("/")
        short = archive.removeprefix("ipra_").removesuffix("_2026-11-07") + "/" + filename
        baseline_table.append(table_row("\\texttt{" + tex_escape(short) + "}", row["delivered"]))
    baseline_table += ["\\midrule", table_row("Coordinatewise minimum", minima["delivered"]),
                       "\\bottomrule", "\\end{tabular}"]
    (RESULTS / "baseline_table.tex").write_text("\n".join(baseline_table) + "\n")

    print(json.dumps({"python": report["python"], "commit": manifest["commit"],
                      "coordinatewise_minima": minima,
                      "candidates": [{"label": row["label"],
                                      **{key: {c: row[key][c] for c in COORDINATES}
                                         for key in minima},
                                      "strictly_below_both_envelopes": all(
                                          row[key][c] < minima[key][c]
                                          for key in minima for c in COORDINATES)}
                                     for row in candidates]}, indent=2))


if __name__ == "__main__":
    main()
