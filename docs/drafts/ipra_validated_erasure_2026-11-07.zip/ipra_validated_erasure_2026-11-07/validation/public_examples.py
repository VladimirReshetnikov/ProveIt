"""Audit the shipped examples through both exact public stdin interfaces."""
from pathlib import Path
import hashlib
import itertools
import json
import subprocess
import sys


def audit_public_examples(root):
    index=root/'examples/index.json'
    records=json.loads(index.read_text())
    failures=[]
    runs=[]
    for record in records:
        path=root/'examples'/record['file']
        source=path.read_bytes()
        observed_hash=hashlib.sha256(source).hexdigest()
        if observed_hash!=record['sha256']:
            failures.append({'file':record['file'],'error':'example hash mismatch'})
        for checker,optimized in itertools.product(('checker.py','checker_compact.py'),(False,True)):
            command=[sys.executable]+(['-O'] if optimized else [])+[str(root/checker)]
            wanted=(0,'ACCEPT','') if record['expected'] else (1,'REJECT','')
            try:
                result=subprocess.run(command,input=source.decode(),text=True,
                                      capture_output=True,timeout=10)
                actual=(result.returncode,result.stdout.strip(),result.stderr)
                passed=actual==wanted
                if not passed:
                    failures.append({'file':record['file'],'checker':checker,
                                     'optimized':optimized,'actual':actual,'expected':wanted})
            except Exception as exc:
                passed=False
                failures.append({'file':record['file'],'checker':checker,
                                 'optimized':optimized,'error':type(exc).__name__})
            runs.append({'file':record['file'],'checker':checker,'optimized':optimized,
                         'expected':record['expected'],'passed':passed})
    return {'status':'PASS' if not failures else 'FAIL','examples':len(records),
            'subprocess_runs':len(runs),'normal_and_optimized':True,
            'index_sha256':hashlib.sha256(index.read_bytes()).hexdigest(),
            'runs':runs,'failures':failures}
