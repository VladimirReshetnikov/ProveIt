"""Focused regressions for validation-before-erasure and selective idempotence.

These are executable boundary checks, not a formal proof of soundness.
Run from any directory: python3 validation/opening_boundary_audit.py.
"""
import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = ast.parse((ROOT / 'checker.py').read_text())
source.body = [node for node in source.body if not isinstance(node, ast.Try)]
namespace = {}
exec(compile(source, str(ROOT / 'checker.py'), 'exec'), namespace)
opening = namespace['inst']
results = []


def success(name, a, image=None, depth=0, floor=0, expected=None):
    namespace['k'] = floor
    value = opening(a, image, depth)
    assert value == expected, (name, value, expected)
    results.append({'case': name, 'verdict': 'pass', 'returned': value})


def rejection(name, a, image=None, depth=0, floor=0):
    namespace['k'] = floor
    try:
        opening(a, image, depth)
    except Exception as error:
        results.append({'case': name, 'verdict': 'pass',
                        'exception': type(error).__name__})
    else:
        raise AssertionError(name + ': expected rejection')


success('negative scalar formula validates once', -1, floor=-1, expected=0)
rejection('normalized root formula zero does not revalidate', 0, floor=-1)
success('array formula with negative scalar normalizes', [-1], floor=-1,
        expected=[0])
success('normalized array formula revalidates', [0], floor=-1, expected=[0])
success('numerical hole returns a nonempty image array', 1, [0], 1,
        expected=[0])
success('formula hole erases a list image to empty array', 0, [0], 0,
        expected=[])
success('formula hole erases a scalar image to scalar zero', 0, 0, 0,
        expected=0)
success('NaN template hole uses a valid image then erases', float('nan'),
        [0], 0, expected=[])
rejection('NaN formula leaf without image rejects', [float('nan')])
rejection('infinite numerical leaf without image rejects', float('inf'),
          depth=1)
rejection('null child cannot be hidden by array fallback', [None])
rejection('oversized array cannot be hidden by formula erasure', [0, 0, 0, 0])
rejection('string cannot request a replacement image', 'x', [0], 0)
success('Boolean numerical alias uses its integer coordinate', False,
        depth=1, expected=0)
success('finite fractional zero alias is retained numerically', 0.5,
        depth=1, expected=0.5)
print(json.dumps({'passed': len(results), 'failed': 0, 'cases': results},
                 indent=2, allow_nan=False))
