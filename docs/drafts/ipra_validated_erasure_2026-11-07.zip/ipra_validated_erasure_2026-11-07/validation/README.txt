VALIDATION: finite implementation evidence
==========================================

Run from any working directory with Python 3.10 or later:

    python3 /path/to/ipra_validated_erasure_2026-11-07/validate.py

The suite writes results/validation.json. It imports no module from an
external source tree and uses only this archive and the standard library.
The production checkers do not import validation code or fixtures.

oracle.py is a readable named-rule interpreter adapted from the pinned
sort-erasure oracle. Formula and numerical opening have separate recursive
functions with explicit protected-variable counts. Scalar validation is
performed before erasure. It uses neither the production depth-offset table
nor Python structural matching. Public agreement is claimed only for runs
starting with the empty assumption context; arbitrary caller-supplied
contexts are outside this oracle's specification.

The suite checks both checker.py and checker_compact.py against this oracle
on the 147 inherited positive certificates, named examples, deterministic
subtree mutations, random JSON-shaped packets, forced false root equations,
and generated scalar-iterator computation equations. The named examples
include failed-major allocation, eigenvariable freshness, dummy capture,
numerical binary zero annotations, and malformed active formula data.

The opening tests exhaust a grid of raw atom classes, scope levels, fresh
parameter floors and substitution images, followed by random trees and
specific eager-validation tests. The grid includes booleans, finite floats,
large integers, NaN, infinities, strings, objects, null, and bad arities.
A valid image may replace an out-of-scope numeric leaf (including nonfinite
numeric input); missing or malformed active images fail. Malformed unused
proof annotations need not be inspected. These distinctions are intentional.

A separate bounded standard-model evaluator checks 400 numerical opening
identities and all generated computation equations. Its execution bounds
are test limits only, never part of proof acceptance. Numerical binary
constructors evaluate to zero and ignore their already-validated formula
annotations; those annotations need not be true.

Finally, both public files run in fresh subprocesses in normal and -O modes
on every inherited positive, every named example, and malformed stdin. The
contract checks exact verdict, exit code, empty stderr, and JSON parsing.
In-process traces additionally compare fresh-name allocation and leftover
packet cells, including rejected attempts.

These are finite reproducible tests. They are not a proof-assistant proof
of soundness, completeness, consistency, or bi-interpretability. The written
metatheory supplies those arguments. See ATTRIBUTION.txt, provenance.json,
and LICENSE-inherited.txt for inherited material and source hashes.
