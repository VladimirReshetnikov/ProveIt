CURRENT-CORPUS COMPARISON
=========================

Repository: VladimirReshetnikov/ProveIt
Pinned commit: fa69b78013baadf9a4e9d63ef1a57f56ca1eb017
Directory: docs/drafts

All eleven root-level checker*.py members of the six ZIP archives at that
snapshot are included unchanged in baselines/. Full archive names, member
paths, source hashes, original interfaces, and arithmetic profiles are in
manifest.json. The original source ZIPs are not duplicated in this package.
Their SHA-256 checksums, sizes, and Git blob SHA-1 identities are recorded.

The archives are:

  ipra_common_scope_2026-11-07.zip
  ipra_node_scopes_2026-11-07.zip
  ipra_one_shift_2026-11-07.zip
  ipra_scope_factoring_2026-11-07.zip
  ipra_sort_erasure_2026-11-07.zip
  ipra_uniform_descent_2026-11-07.zip

Their own reports compare against the preceding snapshot,
df8beb801d9f3e3eb3a8141722953fb58e63009e, and quote the obsolete envelope
356 / 378 / 1038. The present comparison measures the newer eleven
programs themselves. Its current envelope is 342 / 364 / 978.

MEASUREMENT

From the package root:

  python3 measure.py

The script works from any current directory. It checks the inventory and
SHA-256 hashes of every frozen baseline and of source_measure.py before
measuring. No network is used. The baselines are parsed, never executed.
The supplied receipt uses CPython 3.12.14.

source_measure.py is the unchanged measurement helper included in every
current archive. All six source copies had the same SHA-256 checksum:

  f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc

The three comparison coordinates count normalized significant Python
tokens, AST nodes, and UTF-8 source bytes after genuine docstrings are
removed and ast.unparse is applied. Comments and layout have no effect.
The entire program is counted: imports, public input, syntax/scope
validation, inference dispatch, exceptions, output, and exit status.
The fixed ordinary Python runtime and standard library are outside this
measure. No project-specific acceptance dependency is omitted.

The helper's legacy "core" field is deliberately not used: all reported
comparisons are of complete programs. Raw source bytes and SHA-256
checksums are also reported, but raw bytes are not one of the normalized
complexity coordinates and may increase when explanatory docstrings grow.

The separate common-driver control replaces only each program's final
top-level try/except block with exactly the same stdin/sys.exit driver.
Function definitions and other kernel statements are unchanged. It is
implemented as a transparent AST replacement; the exact replacement
source is recorded in results/measurements.json. Under this control the
current envelope is 341 / 362 / 970.

Output:

  results/measurements.json   Full metrics, identities, controls, and savings
  results/metrics_table.tex   Summary table of envelopes and new programs
  results/baseline_table.tex  All eleven delivered baseline measurements

The ordinary and compact candidate programs both use the controlled
driver already, so their delivered and common-driver counts coincide.

INTERPRETATION

The "envelope" is coordinatewise: different programs may attain its
different coordinates. It is the minimum of this finite declared corpus,
not a proven lower bound on all implementations of iPRA, a mathematical
minimality theorem, or an optimality claim across programming languages.

The measurement script neither proves the frozen programs sound nor uses
their behavior as a theoremhood oracle. Soundness and bi-interpretability
are separate mathematical obligations treated in the paper.
