#!/usr/bin/env python3
"""Rebuild the paper offline with pdfLaTeX and record the result."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def main():
    RESULTS.mkdir(exist_ok=True)
    env = dict(os.environ)
    env["SOURCE_DATE_EPOCH"] = str(int(
        datetime(2026, 11, 8, 6, 26, 59, tzinfo=timezone.utc).timestamp()))
    env["FORCE_SOURCE_DATE"] = "1"
    logs = []
    for run in range(1, 4):
        proc = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
             "-file-line-error", "report.tex"],
            cwd=ROOT, env=env, capture_output=True, text=True)
        name = f"latex_pass_{run}.txt"
        (RESULTS / name).write_text(proc.stdout + proc.stderr)
        logs.append(name)
        if proc.returncode:
            raise SystemExit(f"pdfLaTeX failed; see results/{name}")
    log = (ROOT / "report.log").read_text(errors="replace")
    bad = [line for line in log.splitlines()
           if "Overfull" in line or "undefined" in line
           or "multiply defined" in line]
    pdf = ROOT / "report.pdf"
    receipt = {
        "pdf": "report.pdf",
        "bytes": pdf.stat().st_size,
        "sha256": sha256(pdf.read_bytes()).hexdigest(),
        "page_count": int(re.search(r"Output written on .+ \((\d+) pages", log).group(1)),
        "latex_logs": logs,
        "layout_or_reference_warnings": bad,
        "visual_inspection": "Recorded separately in results/pdf_qa.json."
    }
    (RESULTS / "build.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    if bad:
        raise SystemExit("Review the recorded layout/reference warnings.")


if __name__ == "__main__":
    main()
