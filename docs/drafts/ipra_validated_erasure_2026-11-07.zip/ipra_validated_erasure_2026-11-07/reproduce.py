#!/usr/bin/env python3
"""Reproduce the fixed-source comparison and finite implementation evidence."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    for script in ("measure.py", "validate.py"):
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
    audit = subprocess.run(
        [sys.executable, str(ROOT / "validation/opening_boundary_audit.py")],
        cwd=ROOT, check=True, capture_output=True, text=True)
    receipt = json.loads(audit.stdout)
    (ROOT / "results/opening_boundary_audit.json").write_text(
        json.dumps(receipt, indent=2) + "\n")
    print(f"Focused opening boundary cases: {receipt['passed']} passed.")
    print("Measurement and finite validation completed. Rebuild the PDF with build.py.")


if __name__ == "__main__":
    main()
