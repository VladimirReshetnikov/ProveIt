#!/usr/bin/env python3
"""Run the package-local finite validation suite from any working directory."""
from pathlib import Path
import runpy
import sys
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here/'validation'))
runpy.run_path(str(here/'validation'/'run.py'),run_name='__main__')
