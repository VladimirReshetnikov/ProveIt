VALIDATED ERASURE: A SMALLER COMPLETE iPRA PROOF KERNEL
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date)
================================================================

START HERE

report.pdf is the complete paper. report.tex, sections/, and appendices/
contain its editable LaTeX source.

RESULT

At ProveIt commit fa69b78013baadf9a4e9d63ef1a57f56ca1eb017, the six current
draft archives contain eleven complete root checker programs. Remeasuring
those actual programs gives:

                                        tokens   AST nodes   normalized bytes
Current delivered coordinate minima:       342         364                978
checker.py:                                338         361                967
checker_compact.py:                        340         360                957

With the identical stdin/sys.exit driver for every source:

Current controlled coordinate minima:      341         362                970
checker.py:                                338         361                967
checker_compact.py:                        340         360                957

Both candidates are strictly below all three coordinates of both envelopes.
The inherited normalization script is unchanged. Measurements count the
complete program, including input/output and rejection, with only genuine
docstrings and comments excluded. Exact figures use CPython 3.12.14.

WHAT IS NEW

1. The opener validates a scalar or numerical substitution image before
   formula-sort erasure. Multiplication by depth parity preserves numerical
   data and erases formula leaves to zero/empty truth. This permits an
   arity-only scope table while retaining the existing exception-based
   list/scalar classification.
2. The elimination dispatcher constructs its pending closure once and
   reuses it. The compact version puts the same assignment in its condition.

The two computation schemas and five logical inference patterns are inherited.
Their full specification and proofs are included and credited. The new result
is a modest finite-corpus implementation improvement, not a new arithmetic
axiom basis, a global minimum theorem, or a foundational breakthrough.

MATHEMATICAL STATUS

Both programs implement scalar iteration. Their ordinary first-order
realization is bi-interpretable and equiconsistent with full intuitionistic
primitive recursive arithmetic, on the whole numerical domain with identity
composite isomorphisms. The paper reproduces the scalar comparator,
predecessor, equality reflection, and pairing bootstrap. The direct-recursion
calculus is an auxiliary mathematical presentation; no direct-counter
operation is hidden in the delivered programs.

Sound extraction and canonical completeness are written metatheorems for
the new raw representation. Finite tests are implementation evidence, not
formal proofs of soundness or consistency. No Lean/Rocq formalization is
claimed. A fixed Python process may reject large valid certificates because
of finite resources; completeness uses the standard unbounded-resource
idealization.

RUN

The checker reads a single JSON packet from standard input. The packet's
last cell is the closed goal; previous cells are instructions consumed from
the end. ACCEPT exits 0; REJECT exits 1.

  python3 checker.py < examples/zero.json
  python3 checker_compact.py < examples/zero.json
  python3 reproduce.py
  python3 build.py
  python3 package.py

Python 3.10 or later is required for the programs. Use the recorded Python
version for exact normalized-metric comparison. The checks and measurements
use only the standard library and download nothing. PDF rebuilding requires
pdfLaTeX and the packages declared in report.tex.

CONTENTS

  report.pdf / report.tex     Complete paper and main LaTeX source
  sections/ / appendices/    All mathematical source
  checker.py                Main, token-smaller complete verifier
  checker_compact.py         Equivalent AST/byte-smaller verifier
  FORMAT.txt                Raw syntax, scope, instructions, and limitations
  examples/                 Public sample packets
  validation/               Independent oracle, fixtures, and finite checks
  comparison/baselines/      Eleven unchanged current root checkers
  comparison/manifest.json  Pinned source identities and hashes
  results/                  Reproducible measurement and validation receipts
  measure.py / validate.py  Offline evidence entry points
  reproduce.py              Runs both evidence suites
  build.py                  Rebuilds the PDF
  package.py                 Repackages deliverables and checksums
  ATTRIBUTION.txt            Precise new/inherited contribution boundary
  LICENSE.txt                Inherited MIT No Attribution license
  SHA256SUMS.txt             Archive-content integrity checks
