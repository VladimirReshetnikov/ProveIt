#!/usr/bin/env python3
"""Create a clean ZIP and integrity manifest from the completed package."""
from hashlib import sha256
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and "__pycache__" not in relative.parts
            and path.suffix not in EXCLUDED_SUFFIXES
            and path.name != "SHA256SUMS.txt")


def main():
    files = sorted(p for p in ROOT.rglob("*") if included(p))
    sums = ROOT / "SHA256SUMS.txt"
    sums.write_text("".join(
        f"{sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n"
        for p in files))
    files = sorted(files + [sums])
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in files:
            name = f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}"
            entry = zipfile.ZipInfo(name, (2026, 11, 7, 12, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o644 << 16
            archive.writestr(entry, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(target) as archive:
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"ZIP integrity failure: {bad}")
    print(f"{target.name}: {target.stat().st_size} bytes")
    print(f"SHA-256: {sha256(target.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
