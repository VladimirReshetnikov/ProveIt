#!/usr/bin/env python3
"""Build the complete paper with the local TeX installation, offline."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent

def main():
    engine = shutil.which('pdflatex')
    if not engine:
        raise SystemExit('pdfLaTeX is required to rebuild the supplied PDF.')
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    for index in range(1, 4):
        process = subprocess.run(
            [engine, '-interaction=nonstopmode', '-halt-on-error',
             '-file-line-error', 'report.tex'],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (results / f'latex_pass_{index}.txt').write_text(process.stdout)
        if process.returncode:
            print(process.stdout[-7000:])
            raise SystemExit(process.returncode)
    print('Built report.pdf successfully.')

if __name__ == '__main__':
    main()
