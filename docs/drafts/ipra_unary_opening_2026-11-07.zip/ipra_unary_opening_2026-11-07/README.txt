ELIMINATING SUBSTITUTION ENVIRONMENTS FROM iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
================================================

START HERE
----------
report.pdf is the complete mathematical paper.
report.tex and sections/*.tex are its editable LaTeX sources.

RESULT
------
Scalar arithmetic and staged logical binders jointly eliminate every
substitution environment from the trusted proof checker. Every opening
needs at most one numerical image. The paper proves exact preservation
of successful opening and accepted certificates relative to the scalar,
syntax-directed variadic reference.

Complete program                      Tokens    AST nodes    Normalized bytes
Current coordinatewise frontier          411          425                1207
checker.py                              406          420                1197
checker_depth.py                        408          419                1200
Unary-only strict five-rule ablation     410          421                1203

The new unary opening alone crosses the current frontier. The primary also
uses the inherited sort-directed introduction to reduce it further. The core
comparison is strict as well: primary 347/357/947 versus 352/362/957.

The comparison includes all 10 current root checkers and 97 byte-distinct
checker sources found at 258 paths inside the six supplied archives. All 348
Python member paths, including exclusions, are inventoried. The frozen
repository commit is b10a56a8f655c607494a3069b31d6679d968797a.
The older 427/436/1246 headline in several source reports is not the current
frontier. Exact normalization uses the unchanged metric and CPython 3.12.14.

MATHEMATICAL GUARANTEE
----------------------
The presentation has zero, successor, scalar iteration, equality, two logical
binders, five primitive inference patterns, and two computation schemas. The
primary additionally checks a derived closure-introduction rule directly.
All logical and nonlogical rules are stated. Full intuitionistic first-order
logic and quantifier-free induction are reconstructed, with an internal
predecessor and internal simulation of every fixed primitive recursion.

The native calculus faithfully presents an ordinary theory bi-interpretable
with iPRA. Both domains are the full numerical domain; both composite
isomorphisms use x=y. This includes nonstandard counters. Equiconsistency
uses an explicit bridge between 0=S0 and ordinary falsity.

The scalar arithmetic basis and logical reconstruction are inherited from
the current drafts and explicitly attributed. The new result is removal of
the environment mechanism, its preservation proof, and the verified smaller
complete implementation. It is a modest structural advance, not a proof of
global minimality or a claim to a wholly new arithmetic foundation.

RUN
---
From this directory:

  python3 package.py --verify
  python3 reproduce.py
  python3 build.py

The first checks the delivered manifest, the second replays measurements and
independent validation for both checkers, and the third rebuilds report.pdf.
The supplied PDF needs no build step. Reproduction needs only the Python
standard library; rebuilding needs pdfLaTeX and the packages in report.tex.
All commands work offline. The checker syntax requires Python 3.10+.

For an individual proof packet:

  python3 checker.py examples/direct_closure_real_induction.json

See examples/index.json for the exact file list and expected verdicts.
All checkers print ACCEPT with exit status 0 or REJECT with exit status 1.
A rejection is not a mathematical decision of nonderivability.

VALIDATION
----------
Each final kernel passed 70 labelled fixtures representing 69 distinct packets,
8712 exact opening comparisons against both a variadic reference and an
independent named-variable oracle, 138 real normal/-O command-line runs,
and four targeted defect controls. The same cohorts are reused by both
kernels. Results are in results/validation.json and validation_depth.json.

The mathematical metatheory and kernel-correctness arguments are written
proofs. They have not been formalized in Lean or Rocq, and the finite tests
are not presented as such a formalization.

CONTENTS
--------
report.pdf, report.tex, sections/      Complete article and editable sources
checker.py, checker_depth.py          Entire measured acceptance programs
FORMAT.txt                           Exact sorted JSON certificate contract
examples/                            26 directly runnable proof packets
comparison/                          97 frozen sources, inventory, metric
validation/                          Independent oracle and portable tests
results/                             Measurements and verification evidence
research/                            Scope notes and unary-opening argument
ATTRIBUTION.txt, LICENSE_SOURCE.txt   Mathematical/code provenance and license
measure.py, reproduce.py, build.py    Offline reproduction and PDF build
package.py, SHA256SUMS.txt            Integrity check and ZIP creation

The initializer-free arithmetic construction discussed in the paper is an
unproved research lead and is not used by the checker or equivalence theorem.
No repository write or publication was performed.
