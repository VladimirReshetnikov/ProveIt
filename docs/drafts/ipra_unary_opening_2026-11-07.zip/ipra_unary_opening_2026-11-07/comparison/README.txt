REPRODUCIBLE FINITE-CORPUS COMPARISON

Snapshot
--------
Repository: VladimirReshetnikov/ProveIt
Commit: b10a56a8f655c607494a3069b31d6679d968797a
Directory: docs/drafts
Six ZIP archives were fetched at this exact commit. Their byte lengths, Git
blob SHA-1 values (including the Git blob header), and SHA-256 values were
verified. The original archive named "ipra_scalar_iteration_2026-11-07 (1).zip"
was locally called "ipra_scalar_iteration_2026-11-07_v2.zip" to avoid a path
with spaces; both names are retained in the provenance records.

Inventory and selection
-----------------------
The six archives contain 348 Python member paths. Every one is recorded in
python_inventory.json with its original archive, member name, SHA-256,
top-level function names, main-guard status, and inclusion decision.

The expanded checker cohort contains every Python member with all of:
  1. a top-level function named check;
  2. a top-level function named inst or subst;
  3. a top-level __name__ guard.

This selects 258 original paths representing 97 byte-distinct sources. Every
selected source is frozen, byte for byte, in frozen/<SHA-256>.py. The manifest
maps each frozen file to every original archive/member path. No imported
checker body or uncounted decoder is used by the delivered acceptance kernel.

Ten selected programs are current top-level primary/companion checkers:
atomic transport (2), combined (1), joint reductions (2), scalar iteration A
(2), scalar iteration B / (1) archive (1), and sort separation (2). Their
coordinatewise minima equal those of the expanded 97-source cohort.

The expanded inventory includes research variants and historical snapshots.
Its inclusion is a conservative comparison, not an endorsement of every
inherited implementation or mathematical claim. The small non-kernel files
excluded by the explicit predicate are build scripts, report/measurement
support, mutation helpers, and an oracle extension that imports a much larger
implementation. Their original paths and hashes remain in the inventory.

Measurement boundary
--------------------
source_measure.py is unchanged from the supplied drafts. Its SHA-256 is
f1404184bf9d39d85c4587f30e191785886c85fed0b3fe01f693191ca6f218dc.

The three reported primary measures are:
  * significant Python tokens after stripping docstrings and ast.unparse;
  * AST nodes after stripping docstrings;
  * UTF-8 bytes of ast.unparse output plus its final newline.

The complete-program measures include the syntax/opening function, the rule
checker, the eigenparameter cursor, imports, JSON loading, and the CLI verdict
boundary. The secondary core measures remove only imports and the top-level
__name__ guard using the same frozen routine. Comments and docstrings do not
affect these three normalized measures.

The reproduction in this archive used CPython 3.12.14. Other Python versions
may render ast.unparse output differently; measure.py reports the running
version so such changes are visible.

Reproduce
---------
From the package directory:

    python3 measure.py

The script verifies every frozen comparator hash and the metric-program hash,
then writes results/metrics.json, results/comparison.csv, and
results/comparison_table.tex. It requires no network or third-party packages.

To replay archive provenance after downloading the six original ZIP files:

    python3 measure.py --archives /path/to/archive/directory

This additionally checks every original archive hash and the hash and complete
inventory of all 348 Python members. The original ZIPs need not be redistributed
inside the new deliverable because all measured source bytes are frozen here.

Results and ablations
---------------------
The current complete-program envelope is 411 tokens / 425 AST nodes / 1207
normalized bytes. The core envelope is 352 / 362 / 957.

Primary checker.py:                  406 / 420 / 1197; core 347 / 357 / 947.
Depth companion checker_depth.py:    408 / 419 / 1200; core 349 / 356 / 950.
scalar_unary_strict.py:              410 / 421 / 1203; core 351 / 358 / 953.
scalar_sorted_variadic.py:           409 / 426 / 1204; core 350 / 363 / 954.

The strict five-rule ablation is the original scalar iterator checker with
only its opening engine specialized to zero or one image. It already lies
strictly below every current envelope coordinate, independently of the
sorted-introduction shortcut. The variadic ablation combines scalar iteration
and sorted introduction while retaining a substitution environment; its AST
count does not cross the current minimum. These two ablations isolate the
contribution of replacing environments by a single optional substitution image.

The candidate improvements concern this fixed finite corpus and these explicit
implementation metrics. They are not an absolute lower bound, a claim of global
minimality, or an implementation-independent measure of cognitive simplicity.
