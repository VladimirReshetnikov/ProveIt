INDEPENDENT VALIDATION

From the archive root run:
  python validation/verify.py

The test-support code is not imported by checker.py. This audit compares the
acceptance kernel against two references:
1. variadic_reference.py: the scalar/direct-Q kernel immediately before
   specialization to a single image; its opener still uses an environment.
2. named_oracle.py: an explicit named-variable syntax and proof interpreter,
   with no packed depth/sort word, no constructor-width table, and no pattern
   match dispatcher. Its provenance and small direct-Q adaptation are recorded
   in provenance.json. It retains the concrete odd/even alias spelling,
   because the native checker compares concrete JSON syntax literally.

fixtures_inherited.json contains the source scalar draft's 62 regression
packets. fixtures_targeted.json adds 8 focused controls, including a real
induction proof using its induction hypothesis, direct closure introduction,
unused null annotation, used null witness, and the forbidden second slot.
There are 70 labelled fixtures, comprising 69 distinct packets; one targeted
rejection duplicates an inherited packet on purpose for its local obligation.
All labels are checked against both references. The 69 distinct packets are
also run through the real command-line checker under normal Python and -O.

The opening tests enumerate 8,712 scope, alias, type, and substitution cases,
comparing exact successful output and joint rejection against both references.
This covers protected depths 0 through 3, numeric and formula sort, lower
bounds 0 and -3, empty and singleton image collections, nested I/Q/D, absent
and malformed unused images, and both aliases of each boundary coordinate.

Four deliberate defects must be detected: removing declaration validation,
allowing a second unbound slot, validating an inserted image in its caller's
binder context (capture), and restoring the removed recursor counter binder.
These controls ensure that the tests can actually distinguish the failures
whose absence they are meant to check.

Results are saved in results/validation.json. This is finite independent
validation; it is not a substitute for the general structural equivalence
proof or the bi-interpretability proof in the report.

The depth companion can be checked with:
  python validation/verify.py --checker checker_depth.py --output results/validation_depth.json
