#!/usr/bin/env python3
"""Independent regression and boundary audit of the unary-opening checker.

Test support is not part of the trusted acceptance kernel. The named oracle
uses explicit named binders, no packed sort/depth word or width table. A
frozen variadic reference supplies a second, differential check of the exact
zero-or-one-image specialization. Finite tests supplement, not replace, the
structural equivalence proof in the report.
"""
from __future__ import annotations
import argparse
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from named_oracle import Oracle, opening


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def outcome(fn):
    try:
        return ('success', fn())
    except Exception:
        return ('rejected',)


def run(module, packet):
    module.k = 0
    stack = deepcopy(packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(module.take(), []))
    except Exception:
        accepted = False
    return {'accepted': accepted, 'remaining': len(stack), 'final_k': module.k}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checker', type=Path, default=HERE.parent/'checker.py')
    parser.add_argument('--output', type=Path, default=HERE.parent/'results/validation.json')
    args = parser.parse_args()
    checker_path = args.checker.resolve()
    candidate = load(checker_path, 'candidate')
    reference = load(HERE/'variadic_reference.py', 'variadic_reference')
    inherited = json.loads((HERE/'fixtures_inherited.json').read_text())
    targeted = json.loads((HERE/'fixtures_targeted.json').read_text())
    rows = inherited + targeted
    rule_counts = Counter()
    accepts = 0
    cli_runs = 0
    for row in rows:
        actual = run(candidate, row['packet'])
        prior = run(reference, row['packet'])
        named = Oracle().run(row['packet'])
        assert actual['accepted'] == row['expected'], (row['name'], actual)
        assert actual == prior, (row['name'], actual, prior)
        assert actual['accepted'] == named['accepted'], (row['name'], actual, named)
        if actual['accepted']:
            assert actual['remaining'] == named['remaining'], row['name']
            assert actual['final_k'] == named['final_k'], row['name']
            rule_counts.update(named['rules'])
            accepts += 1
    # Execute each distinct packet through the actual CLI, not just imported
    # functions. Run both normal and optimized Python to expose assert-based
    # validity checks, and require exact status plus exact output.
    packets = {json.dumps(r['packet'],separators=(',',':')):r for r in rows}
    with tempfile.TemporaryDirectory(prefix='ipra-audit-') as temporary:
        path = Path(temporary)/'packet.json'
        for encoded, row in packets.items():
            path.write_text(encoded)
            for mode in ([], ['-O']):
                proc = subprocess.run([sys.executable,*mode,str(checker_path),str(path)],
                                      capture_output=True,text=True,timeout=10)
                expected = (0, 'ACCEPT\n', '') if row['expected'] else (1, 'REJECT\n', '')
                assert (proc.returncode,proc.stdout,proc.stderr) == expected, (row['name'],mode,proc)
                cli_runs += 1
    # Carefully enumerated alias/scope boundaries. The terms deliberately
    # include unused malformed images, both aliases of the single hole,
    # the immediately forbidden next slot, nested I, Q and D binders, and
    # declared / undeclared negative parameters.
    boundary = Counter()
    environments = [(), (None,), (0,), (-2,), (-4,), (1,), ([0],),
                    ([0,0,1],), ([0,0,3],)]
    for protected in range(4):
        for formula in (False, True):
            d = 2*protected + (not formula)
            coords = sorted(set([-4,-3,-2,-1,0,1,2,2*protected+1,
                                 2*protected+2,2*protected+3,2*protected+4]))
            terms = coords + [[x] for x in coords] + [[0,0,x] for x in coords]
            terms += [[0,0,[0,1,x]] for x in coords]
            values = ([[t,0] for t in terms] + [[[x,0]] for x in coords]
                      + [[[x,0],[0,0],[0,0]] for x in coords]) if formula else terms
            values += [True,False,0.0,None,{},'',[],[0,0,0,0]]
            for lower in (0,-3):
                for value in values:
                    for env in environments:
                        candidate.k = reference.k = lower
                        a = outcome(lambda: candidate.inst(deepcopy(value),*deepcopy(env),d=d))
                        b = outcome(lambda: reference.inst(deepcopy(value),*deepcopy(env),d=d))
                        c = outcome(lambda: opening(deepcopy(value),deepcopy(env),formula=formula,
                                                    depth=protected,lower=lower))
                        assert a == b == c, (protected,formula,lower,value,env,a,b,c)
                        boundary['total'] += 1
                        boundary['success' if a[0]=='success' else 'rejected'] += 1
    # Sensitivity controls: ensure that this finite suite detects the exact
    # four security-critical defects addressed by its boundary obligations.
    source = checker_path.read_text()
    defects = [
      ('undeclared_negative_parameter', 'k <= a < d + 2', 'a < d + 2', -1, (), 1),
      ('second_unbound_slot', 'k <= a < d + 2', 'k <= a < d + 4', 3, (0,), 1),
      ('capture_by_protected_binder', 'inst(t, d=1)', 'inst(t, d=d)', 3, (1,), 3),
      ('counter_binder_reintroduced', "b'\\0\\0\\2'", "b'\\0\\0\\4'", [0,0,3], (), 1),
    ]
    controls = []
    for name, old, new, value, env, d in defects:
        assert source.count(old) == 1, (name,'mutation anchor not unique')
        mutant = types.ModuleType('mutant_'+name)
        exec(compile(source.replace(old,new),'<deliberate-defect>','exec'), mutant.__dict__)
        candidate.k = mutant.k = 0
        clean = outcome(lambda: candidate.inst(deepcopy(value),*deepcopy(env),d=d))
        altered = outcome(lambda: mutant.inst(deepcopy(value),*deepcopy(env),d=d))
        assert clean[0] == 'rejected' and altered[0] == 'success', (name,clean,altered)
        controls.append({'name':name,'clean':'rejected','defect':'accepted'})
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    result = {
      'checker':checker_path.name,
      'checker_sha256':digest(checker_path),
      'named_oracle_sha256':digest(HERE/'named_oracle.py'),
      'variadic_reference_sha256':digest(HERE/'variadic_reference.py'),
      'inherited_fixture_count':len(inherited),
      'new_targeted_fixture_count':len(targeted),
      'labelled_fixture_count':len(rows),
      'distinct_packet_count':len(packets),
      'accepted_fixtures':accepts,
      'rejected_fixtures':len(rows)-accepts,
      'candidate_variadic_named_disagreements':0,
      'opening_boundary_comparisons':dict(boundary),
      'exact_cli_runs_normal_and_optimized':cli_runs,
      'successful_fixture_rule_counts':dict(sorted(rule_counts.items())),
      'deliberate_defect_controls':controls,
      'scope':'Finite independent evidence; general equivalence is proved structurally in report.'
    }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__ == '__main__':
    main()
