#!/usr/bin/env python3
"""Reproduce the comparison and independent checks for both final kernels."""
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    commands = [
        ['measure.py'],
        ['validation/verify.py'],
        ['validation/verify.py', '--checker', 'checker_depth.py',
         '--output', 'results/validation_depth.json'],
    ]
    if '--pdf' in sys.argv[1:]:
        commands.append(['build.py'])
    records = []
    for number, command in enumerate(commands, 1):
        process = subprocess.run([sys.executable, *command], cwd=ROOT,
                                 capture_output=True, text=True)
        log = ROOT / 'results' / f'reproduction_{number}.txt'
        log.write_text(process.stdout + process.stderr)
        records.append({'command':command, 'exit_status':process.returncode,
                        'log':str(log.relative_to(ROOT))})
        if process.returncode:
            print(process.stdout[-5000:] + process.stderr[-5000:])
            raise SystemExit(process.returncode)
    summary = {'status':'PASS', 'python':platform.python_version(),
               'steps':records, 'scope':'Measurements and finite validation; see paper for proofs.'}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
