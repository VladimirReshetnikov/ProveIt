"""Reproduce the complete-program comparison using frozen, unchanged sources.

Run: python3 measure.py
Optional provenance replay: python3 measure.py --archives /path/to/downloaded/zips
No network, third-party package, evaluator, or proof preprocessing is required.
"""
import argparse
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import zipfile

ROOT = Path(__file__).resolve().parent
FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def envelopes(rows):
    return ({key: min(row[key] for row in rows) for key in FIELDS},
            {key: min(row['core'][key] for row in rows) for key in FIELDS})


def verify_archives(directory, manifest, inventory):
    results = []
    for record in manifest['archives']:
        path = directory / record['name']
        if not path.exists():
            path = directory / record['local_name']
        data = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        require(actual == record['git_blob_sha'], 'Git blob mismatch: ' + record['name'])
        require(len(data) == record['bytes'], 'Length mismatch: ' + record['name'])
        require(hashlib.sha256(data).hexdigest() == record['sha256'],
                'SHA-256 mismatch: ' + record['name'])
        with zipfile.ZipFile(path) as archive:
            expected = [item for item in inventory if item['archive'] == record['name']]
            require(sorted(n for n in archive.namelist() if n.endswith('.py'))
                    == sorted(item['member'] for item in expected),
                    'Python inventory mismatch: ' + record['name'])
            for item in expected:
                require(hashlib.sha256(archive.read(item['member'])).hexdigest() == item['sha256'],
                        'Member mismatch: ' + item['member'])
        results.append({'archive': record['name'], 'verified': True, 'git_blob_sha': actual})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archives', type=Path)
    args = parser.parse_args()
    comparison = ROOT / 'comparison'
    manifest = json.loads((comparison / 'manifest.json').read_text())
    inventory = json.loads((comparison / 'python_inventory.json').read_text())
    metric_path = comparison / 'source_measure.py'
    require(sha256(metric_path) == manifest['metric_source_sha256'],
            'The inherited measurement algorithm has changed.')
    spec = importlib.util.spec_from_file_location('frozen_source_measure', metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    expanded = []
    by_hash = {}
    for source in manifest['sources']:
        path = ROOT / source['local_file']
        require(sha256(path) == source['sha256'], 'Changed comparator: ' + source['local_file'])
        row = {**source, **metric.metrics(path)}
        expanded.append(row)
        by_hash[source['sha256']] = row
    roots = [{**by_hash[item['sha256']], **item} for item in manifest['root_programs']]
    root_whole, root_core = envelopes(roots)
    expanded_whole, expanded_core = envelopes(expanded)
    candidates = []
    for label, path in [('Unary opening, primary', 'checker.py'),
                        ('Unary opening, protected-depth companion', 'checker_depth.py'),
                        ('Unary opening without sorted-introduction shortcut',
                         'comparison/scalar_unary_strict.py'),
                        ('Scalar plus sorted introduction, variadic opening',
                         'comparison/scalar_sorted_variadic.py')]:
        candidates.append({'label': label, 'local_file': path, **metric.metrics(ROOT / path)})
    primary, depth, strict, variadic = candidates
    improvements = [{
        'label': row['label'],
        'whole': {key: row[key] < expanded_whole[key] for key in FIELDS},
        'core': {key: row['core'][key] < expanded_core[key] for key in FIELDS}
    } for row in candidates]
    require(all(improvements[0]['whole'].values()) and all(improvements[0]['core'].values()),
            'The primary is not strictly below every expanded-envelope coordinate.')
    require(all(improvements[1]['whole'].values()) and all(improvements[1]['core'].values()),
            'The depth companion is not strictly below every expanded-envelope coordinate.')
    require(all(improvements[2]['whole'].values()) and all(improvements[2]['core'].values()),
            'The strict five-rule unary ablation no longer independently crosses the envelope.')
    result = {
        'status': 'PASS', 'python': platform.python_version(),
        'implementation': platform.python_implementation(), 'commit': manifest['commit'],
        'archive_count': manifest['archive_count'], 'root_program_count': len(roots),
        'python_path_count': len(inventory),
        'expanded_path_count': sum(len(row['original_paths']) for row in expanded),
        'expanded_distinct_sources': len(expanded),
        'metric_source_sha256': manifest['metric_source_sha256'],
        'root_whole_envelope': root_whole, 'root_core_envelope': root_core,
        'expanded_whole_envelope': expanded_whole, 'expanded_core_envelope': expanded_core,
        'primary': primary, 'depth_companion': depth,
        'strict_five_rule_ablation': strict, 'variadic_ablation': variadic,
        'strict_improvements': improvements,
        'primary_absolute_reduction': {key: expanded_whole[key] - primary[key] for key in FIELDS},
        'root_programs': roots,
        'expanded_programs': expanded,
        'scope': 'Finite comparison at the pinned commit, not an absolute or invariant lower-bound theorem. The complete-program counts include the opening/parser routine, rule dispatcher, imports, and JSON/CLI boundary. Core counts exclude imports and CLI using the unchanged inherited algorithm. No proof certificate, documentation, validation code, or untrusted elaboration support is counted as kernel code.'
    }
    if args.archives:
        result['archive_reverification'] = verify_archives(args.archives, manifest, inventory)
    results = ROOT / 'results'
    results.mkdir(exist_ok=True)
    (results / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    fields = ['kind', 'label', 'local_file', *FIELDS,
              'core_normalized_tokens', 'core_ast_nodes', 'core_normalized_bytes', 'sha256']
    with (results / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fields, extrasaction='ignore')
        writer.writeheader()
        for kind, rows in [('root_baseline', roots), ('candidate_or_ablation', candidates)]:
            for row in rows:
                writer.writerow({'kind': kind, **row,
                                 **{'core_' + k: row['core'][k] for k in FIELDS}})
    tex = [r'\begin{tabular}{@{}lrrr@{}}', r'\toprule',
           r'Complete program & Tokens & AST nodes & Bytes\\', r'\midrule']
    for row in roots:
        label = row['label'].replace('_', r'\_')
        tex.append(label + ' & ' + ' & '.join(str(row[k]) for k in FIELDS) + r'\\')
    tex.extend([r'\midrule', 'Current componentwise minima & '
                + ' & '.join(str(expanded_whole[k]) for k in FIELDS) + r'\\',
                'Scalar/sorted variadic ablation & '
                + ' & '.join(str(variadic[k]) for k in FIELDS) + r'\\',
                'Strict five-rule unary ablation & '
                + ' & '.join(str(strict[k]) for k in FIELDS) + r'\\',
                'Primary unary-opening checker & '
                + ' & '.join(str(primary[k]) for k in FIELDS) + r'\\',
                'Protected-depth companion & '
                + ' & '.join(str(depth[k]) for k in FIELDS) + r'\\',
                r'\bottomrule', r'\end{tabular}'])
    (results / 'comparison_table.tex').write_text('\n'.join(tex) + '\n')
    brief = {k: v for k, v in result.items()
             if k not in ('root_programs', 'expanded_programs', 'scope')}
    print(json.dumps(brief, indent=2))


if __name__ == '__main__':
    main()
