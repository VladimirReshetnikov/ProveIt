#!/usr/bin/env python3
"""Verify the delivered payload or rebuild its manifest and ZIP."""
import hashlib
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / 'SHA256SUMS.txt'
OMIT = {'.aux','.log','.out','.toc','.fls','.fdb_latexmk','.pyc','.synctex.gz'}

def payload():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and 'qa' not in p.parts
                  and p.suffix not in OMIT and p != MANIFEST)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if '--verify' in sys.argv[1:]:
        recorded = {}
        for line in MANIFEST.read_text().splitlines():
            value, name = line.split('  ', 1)
            recorded[name] = value
        actual = {str(p.relative_to(ROOT)):digest(p) for p in payload()}
        if recorded != actual:
            changed = sorted(k for k in recorded.keys() | actual.keys()
                             if recorded.get(k) != actual.get(k))
            raise SystemExit('Manifest mismatch: ' + ', '.join(changed))
        print(f'PASS: {len(actual)} payload hashes verified.')
        return
    files = payload()
    MANIFEST.write_text(''.join(f'{digest(p)}  {p.relative_to(ROOT)}\n' for p in files))
    target = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in [*files, MANIFEST]:
            archive.write(path, str(Path(ROOT.name)/path.relative_to(ROOT)))
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise SystemExit('ZIP integrity failure')
    print(f'Created {target.name}: {target.stat().st_size} bytes, {len(files)+1} members.')

if __name__ == '__main__':
    main()
