EXAMPLE PROOF PACKETS

The command-line checker consumes the JSON array from its end. The final
entry is the goal; preceding entries supply the rule instructions in the
order requested during backward checking. The helper index.json states the
expected acceptance of each example. Run one, for example, with:
  python checker.py examples/direct_closure_real_induction.json

That packet proves Q_x(I(x,0;u.Su)=x). Its step uses the literal equation
induction hypothesis I(k,0;u.Su)=k, equality transport, and the successor
iterator equation; it does not merely present a computation instance.

The inherited examples expose nested substitution, equation induction at a
parameter/compound term, retained-base use, compound numerical cases, and
negative controls for a compound induction hypothesis and escaping eigenname.
Their full provenance is in validation/fixtures_inherited.json. The examples
are convenience copies; validation/verify.py reads the two fixture cohorts.
