#!/usr/bin/env python3
"""Exact legal binary-iterator program for a PRA equality-reflection bridge.

This is a diagnostic, not a proof of a first-order metatheorem.  Every
descriptor below has only k and v free and refers only to earlier iterator
names.  Syntactic node counts expand p, parity, and the selector C; each
previous iterator name is counted as one function-symbol occurrence.

The standard numerical interpretation is
    decode(R(x,y)) = decode(y) - decode(x),
where decode(2a)=a and decode(2a+1)=-(a+1).
Consequently R(R(x,y),y)=x.  The weak proposed theory needs only the latter
equation and R(0,y)=y to recover native equality from R(x,y)=0.
"""

from __future__ import annotations

import argparse
from functools import lru_cache
import json
from pathlib import Path
from typing import Any


# Syntax: ("var", name), ("zero",), ("S", t), ("I", name, t, u).
Term = tuple[Any, ...]
k: Term = ("var", "k")
v: Term = ("var", "v")
zero: Term = ("zero",)


def S(t: Term) -> Term:
    return ("S", t)


one = S(zero)


def I(name: str, t: Term, u: Term) -> Term:
    return ("I", name, t, u)


def p(t: Term) -> Term:
    return I("P", t, zero)


def bit(t: Term) -> Term:
    return I("Q", t, zero)


def C(b: Term, t: Term, u: Term) -> Term:
    # P(B(b,St),u), so C(0,t,u)=t and C(Sn,t,u)=u by computation.
    return I("P", I("B", b, S(t)), u)


# Insertion order is the legal dependency order.
PROGRAM: dict[str, Term] = {
    "P": k,
    "B": zero,
    "Q": I("B", v, one),
    "Up": C(bit(v), S(S(v)), p(p(v))),
    # P(p(v),1) is 1 at v=0 and v-2 at positive even v.
    "Down": C(bit(v), I("P", p(v), one), S(S(v))),
    "R": C(bit(k), I("Up", S(k), v), I("Down", S(k), v)),
}


def term_nodes(t: Term) -> int:
    tag = t[0]
    if tag in ("var", "zero"):
        return 1
    if tag == "S":
        return 1 + term_nodes(t[1])
    if tag == "I":
        return 1 + term_nodes(t[2]) + term_nodes(t[3])
    raise ValueError(tag)


def symbols(t: Term) -> set[str]:
    if t[0] in ("var", "zero"):
        return set()
    if t[0] == "S":
        return symbols(t[1])
    return {t[1]} | symbols(t[2]) | symbols(t[3])


def variables(t: Term) -> set[str]:
    if t[0] == "var":
        return {t[1]}
    if t[0] == "zero":
        return set()
    if t[0] == "S":
        return variables(t[1])
    return variables(t[2]) | variables(t[3])


def display(t: Term) -> str:
    if t[0] == "var":
        return t[1]
    if t[0] == "zero":
        return "0"
    if t[0] == "S":
        return f"S({display(t[1])})"
    return f"{t[1]}({display(t[2])},{display(t[3])})"


def validate_program() -> None:
    seen: set[str] = set()
    for name, update in PROGRAM.items():
        assert variables(update) <= {"k", "v"}, (name, "free variable")
        assert symbols(update) <= seen, (name, "forward or circular reference")
        seen.add(name)


@lru_cache(maxsize=None)
def eval_term(t: Term, counter: int, state: int) -> int:
    if t[0] == "var":
        return counter if t[1] == "k" else state
    if t[0] == "zero":
        return 0
    if t[0] == "S":
        return eval_term(t[1], counter, state) + 1
    n = eval_term(t[2], counter, state)
    a = eval_term(t[3], counter, state)
    return eval_iterator(t[1], n, a)


@lru_cache(maxsize=None)
def eval_iterator(name: str, n: int, a: int) -> int:
    result = a
    for counter in range(n):
        result = eval_term(PROGRAM[name], counter, result)
    return result


def decode(n: int) -> int:
    return n // 2 if n % 2 == 0 else -(n // 2 + 1)


def encode(z: int) -> int:
    return 2 * z if z >= 0 else -2 * z - 1


def positive(n: int) -> int:
    return n // 2 if n % 2 == 0 else 0


def negative(n: int) -> int:
    return n // 2 + 1 if n % 2 else 0


def run_checks(bound: int) -> dict[str, Any]:
    validate_program()
    unary_checks = 0
    for n in range(bound):
        assert encode(decode(n)) == n
        assert eval_iterator("Q", n, 0) == n % 2
        assert decode(eval_iterator("Up", 1, n)) == decode(n) + 1
        assert decode(eval_iterator("Down", 1, n)) == decode(n) - 1
        assert eval_iterator("R", 0, n) == n
        assert eval_iterator("R", n, n) == 0
        unary_checks += 6

    pair_checks = 0
    for x in range(bound):
        for y in range(bound):
            r = eval_iterator("R", x, y)
            assert decode(r) == decode(y) - decode(x)
            assert r == encode(decode(y) - decode(x))
            assert eval_iterator("R", r, y) == x
            assert (r == 0) == (x == y)
            assert positive(r) + positive(x) + negative(y) == (
                negative(r) + negative(x) + positive(y)
            )
            pair_checks += 5

    descriptor_nodes = {name: term_nodes(t) for name, t in PROGRAM.items()}
    # Formula count: each quantifier, equality, variable, or function call
    # counts as one node; there are no defined macros in these two formulas.
    reflection_formula_nodes = 2 + 1 + (1 + (1 + 1 + 1) + 1) + 1
    minimum_formula_nodes = 2 + 1 + 2 * (1 + (1 + 1 + 1) + 1)
    assert reflection_formula_nodes == 9
    assert minimum_formula_nodes == 13

    return {
        "diagnostic_only": True,
        "bound_exclusive": bound,
        "unary_assertions": unary_checks,
        "pair_assertions": pair_checks,
        "legal_descriptors": {
            name: display(t) for name, t in PROGRAM.items()
        },
        "descriptor_nodes": descriptor_nodes,
        "descriptor_nodes_total": sum(descriptor_nodes.values()),
        "minimum_bridge_descriptors": {"P": 1, "B": 1, "M": 3},
        "minimum_bridge_descriptor_nodes_total": 5,
        "reflection_fixed_formula_nodes": reflection_formula_nodes,
        "minimum_fixed_formula_nodes": minimum_formula_nodes,
        "schema_display_totals": {
            "D_Sep_PC_Reflection": 18 + 6 + 26 + reflection_formula_nodes,
            "D_Sep_PC_Minimum": 18 + 6 + 26 + minimum_formula_nodes,
        },
        "cost_caveat": (
            "The reflection law saves four formula-tree nodes and simplifies "
            "the equality bootstrap, but its selected iterator descriptions "
            "are longer. This is not an improvement under every encoding cost."
        ),
        "decode_table": [decode(n) for n in range(12)],
        "reflection_table": [
            [eval_iterator("R", x, y) for y in range(8)]
            for x in range(8)
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=64)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.bound < 1:
        parser.error("--bound must be positive")
    result = run_checks(args.bound)
    rendered = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered)
    print(rendered, end="")


if __name__ == "__main__":
    main()
