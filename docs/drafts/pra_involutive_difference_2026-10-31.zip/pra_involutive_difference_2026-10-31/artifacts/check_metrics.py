#!/usr/bin/env python3
"""Reproduce the matched formula-tree counts, with explicit syntax.

Each quantifier, equality, connective, falsity, variable, constant, and
function application costs one node. Stored program descriptions are a
separate cost, calculated by check_program.py. Schematic term/function
calls charge their shown arguments rather than a substituted body.
"""
import argparse
import json
from pathlib import Path


def var(name):
    return ("var", name)


def call(name, *args):
    return ("call", name, args)


def eq(a, b):
    return ("eq", a, b)


def logic(op, *args):
    return (op, *args)


def forall(name, body):
    return ("forall", name, body)


def count(tree):
    if tree[0] in ("var", "zero", "false"):
        return 1
    if tree[0] == "call":
        return 1 + sum(map(count, tree[2]))
    if tree[0] == "forall":
        return 1 + count(tree[2])
    return 1 + sum(map(count, tree[1:]))


def render(tree):
    tag = tree[0]
    if tag == "var":
        return tree[1]
    if tag in ("zero", "false"):
        return "0" if tag == "zero" else "false"
    if tag == "call":
        return tree[1] + "(" + ",".join(map(render, tree[2])) + ")"
    if tag == "forall":
        return "forall " + tree[1] + ", " + render(tree[2])
    symbol = {"eq": "=", "or": "or", "implies": "->"}[tag]
    return "(" + (" " + symbol + " ").join(map(render, tree[1:])) + ")"


def results():
    x, y, n, a = map(var, ("x", "y", "n", "a"))
    zero = ("zero",)
    S = lambda t: call("S", t)
    one = S(zero)
    F = lambda t: call("f", t, a)
    I = lambda t, u: call("I_h", t, u)
    R = lambda t, u: call("R", t, u)
    M = lambda t, u: call("M", t, u)
    d0 = forall("a", eq(I(zero, a), a))
    ds = forall("n", forall("a", eq(I(S(n), a), call("h", n, I(n, a)))))
    sep = logic("implies", eq(zero, one), ("false",))
    pc = forall("a", logic("implies",
        forall("n", eq(F(S(S(n))), F(S(n)))),
        forall("n", logic("or", eq(n, zero), eq(F(n), F(one))))))
    inv = forall("x", forall("y", eq(R(R(x, y), y), x)))
    minimum = forall("x", forall("y", eq(M(M(x, y), y), M(M(y, x), x))))
    forms = {"D_zero": d0, "D_successor": ds, "Sep": sep,
             "PC_one_parameter": pc, "Inv": inv, "Min": minimum}
    counts = {name: count(tree) for name, tree in forms.items()}
    assert counts == {"D_zero": 6, "D_successor": 12, "Sep": 6,
                      "PC_one_parameter": 26, "Inv": 9, "Min": 13}, counts
    common = counts["D_zero"] + counts["D_successor"] + counts["Sep"] + counts["PC_one_parameter"]
    return {
        "metric": "formula AST nodes, stored descriptors charged separately",
        "formulas": {name: render(tree) for name, tree in forms.items()},
        "counts": counts,
        "matched_total_minimum": common + counts["Min"],
        "matched_total_involution": common + counts["Inv"],
        "saving": counts["Min"] - counts["Inv"],
        "not_absolute_minimality": True,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    data = json.dumps(results(), indent=2) + "\n"
    if args.output:
        args.output.write_text(data)
    print(data, end="")
