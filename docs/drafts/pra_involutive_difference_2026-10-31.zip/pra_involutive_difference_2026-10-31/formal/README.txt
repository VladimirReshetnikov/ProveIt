LEAN CERTIFICATE SCOPE
======================

Compiler: Lean 4.19.0. Both files are standalone and import no external
library. They use constructive logic and no induction on the arithmetic
carrier. Structural induction on finite syntax is metatheoretic.

InvolutionKernel.lean isolates the arbitrary-carrier bridge, zero and
equality decisions, selector, coverage, and a generic represented latch.
Its latch representability is an explicit input to the conditional lemma.

InvolutionConstancy.lean includes a finite Term grammar with initialized
binary iterators. Stored descriptor variables are not substituted when
actual term arguments are substituted. The Model structure has only
zero, successor, the finite-description-indexed run operation, and its
two computation equations. PositiveConstancy ranges over finite Terms,
not arbitrary semantic functions. EqualityError is the run of the exact
signedDifferenceUpdate descriptor; there is no opaque equality primitive.

Main endpoints:
  InvolutionConstancy.main_quantifier_free_induction
  InvolutionConstancy.main_quantifier_free_decision

The hypotheses at those endpoints are exactly Model(D), finite-term PC,
0 != S0, and RightInvolution for the specified signed-difference iterator.
The inherited equality-recognition interface is discharged by the new
bridge before reaching either endpoint.

The extended file verifies the numerical parameter-and-bit storage,
actual finite latch construction, native equality reflection, zero-code
compiler for all finite quantifier-free formulas, and one-parameter QFI.

The 35 printed axiom audits in the extended file all report that the
declarations depend on no axioms. This means no logical/oracle axioms
are introduced by the proofs; the arithmetic hypotheses are still
explicit theorem parameters. It is not a proof that Inv follows from D.

Outside the formalized scope, supplied by the paper:
  - soundness of the signed-difference involution inside ordinary PRA;
  - triangular pairing and arbitrary finite parameter elimination;
  - general PR-description compilation and both first-order round trips;
  - a formal syntactic first-order derivability/bi-interpretation theorem.

Historical attribution is preserved in the extended source. It adapts
the finite-syntax completion from the current minimum-symmetry package,
whose own source records earlier positive-constancy/uniqueness work.
