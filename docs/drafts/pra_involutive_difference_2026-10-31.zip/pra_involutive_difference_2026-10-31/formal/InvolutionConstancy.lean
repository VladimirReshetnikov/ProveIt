/-
  PRA from positive constancy and right involution.
  Finite-syntax constructive certificate, Lean 4.19.0; no imports.

  The arithmetic assumptions at main_quantifier_free_induction are exactly:
  the binary computation Model, finite-term PositiveConstancy, 0 != S0,
  and RightInvolution for the explicit signedDifferenceUpdate iterator.

  This file contains the new small InvolutionKernel, followed by a generic
  finite-syntax completion adapted from MinConstancy.lean in the inspected
  pra_minimum_symmetry_2026-10-31 archive. That source attributes its generic
  completion to pra_positive_constancy_2026-10-31/formal/PositiveConstancy.lean
  (ProveIt commit 514b6dfd2c1232848a259549c352b1935d53191c), itself refining
  the positive-uniqueness draft at b0350fd1c96d8273ca9c3b5ce025782b748cded7.
  The inherited attribution is preserved below. The new equality error is
  the explicit signed-difference iterator, and its recognition interface
  is discharged from right involution, not from a minimum equation.

  All one-parameter QF induction instances are linked through actual finite
  Term and Formula syntax, including the parameter-and-bit storage latch.
  The arbitrary carrier has no assumed equality decision or induction.
  Induction in this source is only on finite syntax. Pairing, arbitrary
  finite parameter tuples, validity of Inv inside ordinary PRA, and full
  first-order bi-interpretability remain written proofs in the paper.
-/

/-
  Constructive kernel for positive constancy and right involution.
  Lean 4.19.0, no imports.

  The carrier A is arbitrary. No induction on A, native equality decision,
  classical logic, choice, or arithmetic axiom beyond the listed hypotheses
  is used. PositiveConstancy is assumed only for the indicated gate family
  and, in later lemmas, for one specified coverage term or one specified
  latch. There is no global quantification of PC over all semantic functions.

  Formula is finite propositional syntax whose atoms are pairs of functions.
  Its structural induction is syntactic, not arithmetic induction. A source
  term interpretation may supply those functions; representability of the
  error and latch by legal PR descriptions is a separate written argument.
  Likewise, soundness of the chosen signed-difference program's involution
  in ordinary PRA and the full bi-interpretation are not formalized here.
-/

universe u

namespace InvolutionKernel

def PositiveConstancy {A : Type u} (zero : A) (succ : A → A)
    (f : A → A) : Prop :=
  (∀ n, f (succ (succ n)) = f (succ n)) →
  ∀ n, n = zero ∨ f n = f (succ zero)

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  P : A → A → A
  B : A → A → A
  R : A → A → A
  pZero : ∀ a, P zero a = a
  pSucc : ∀ n a, P (succ n) a = n
  bZero : ∀ a, B zero a = a
  bSucc : ∀ n a, B (succ n) a = zero
  rZero : ∀ a, R zero a = a
  nontrivial : zero ≠ succ zero
  pcGate : ∀ a, PositiveConstancy zero succ (fun n => B n a)
  rightInvolution : ∀ x y, R (R x y) y = x

namespace Kernel

variable {A : Type u} (K : Kernel A)

def one : A := K.succ K.zero

def pred (x : A) : A := K.P x K.zero

def select (z a b : A) : A := K.P (K.B z (K.succ a)) b

theorem succ_injective (x y : A) (h : K.succ x = K.succ y) : x = y := by
  have hp := congrArg (fun t => K.P t K.zero) h
  change K.P (K.succ x) K.zero = K.P (K.succ y) K.zero at hp
  rw [K.pSucc, K.pSucc] at hp
  exact hp

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro h
  have hp := congrArg (fun t => K.P t K.zero) h
  change K.P (K.succ x) K.zero = K.P K.zero K.zero at hp
  rw [K.pSucc, K.pZero] at hp
  rw [hp] at h
  exact K.nontrivial h.symm

theorem gate_alternative (n a : A) :
    n = K.zero ∨ K.B n a = K.zero := by
  have htail : ∀ k, K.B (K.succ (K.succ k)) a = K.B (K.succ k) a := by
    intro k
    rw [K.bSucc, K.bSucc]
  have h := K.pcGate a htail n
  change n = K.zero ∨ K.B n a = K.B (K.succ K.zero) a at h
  rw [K.bSucc] at h
  exact h

theorem gate_nonzero (n a : A) (hn : n ≠ K.zero) : K.B n a = K.zero := by
  cases K.gate_alternative n a with
  | inl hz => exact False.elim (hn hz)
  | inr h => exact h

theorem gate_zero (n : A) : K.B n K.zero = K.zero := by
  cases K.gate_alternative n K.zero with
  | inl hz => rw [hz, K.bZero]
  | inr h => exact h

theorem zero_decision (n : A) : n = K.zero ∨ n ≠ K.zero := by
  cases K.gate_alternative n K.one with
  | inl hz => exact Or.inl hz
  | inr h =>
      apply Or.inr
      intro hz
      rw [hz, K.bZero] at h
      exact K.nontrivial h.symm

theorem difference_diagonal (x : A) : K.R x x = K.zero := by
  have h := K.rightInvolution K.zero x
  rw [K.rZero] at h
  exact h

theorem difference_zero_iff (x y : A) : K.R x y = K.zero ↔ x = y := by
  constructor
  · intro hxy
    have h := K.rightInvolution x y
    rw [hxy, K.rZero] at h
    exact h.symm
  · intro hxy
    rw [hxy]
    exact K.difference_diagonal y

include K in
theorem equality_decision (x y : A) : x = y ∨ x ≠ y := by
  cases K.zero_decision (K.R x y) with
  | inl hz => exact Or.inl ((K.difference_zero_iff x y).mp hz)
  | inr hn =>
      exact Or.inr (fun hxy => hn ((K.difference_zero_iff x y).mpr hxy))

theorem selector_zero (a b : A) : K.select K.zero a b = a := by
  unfold select
  rw [K.bZero, K.pSucc]

theorem selector_nonzero (z a b : A) (hz : z ≠ K.zero) :
    K.select z a b = b := by
  unfold select
  rw [K.gate_nonzero z (K.succ a) hz, K.pZero]

theorem selector_equal (z a : A) : K.select z a a = a := by
  cases K.zero_decision z with
  | inl hz => rw [hz, K.selector_zero]
  | inr hn => exact K.selector_nonzero z a a hn

theorem constructor_coverage
    (pcCoverage : PositiveConstancy K.zero K.succ
      (fun n => K.R n (K.succ (K.pred n))))
    (n : A) : n = K.zero ∨ n = K.succ (K.pred n) := by
  have hsuccessor : ∀ k, K.R (K.succ k) (K.succ (K.pred (K.succ k))) =
      K.zero := by
    intro k
    unfold pred
    rw [K.pSucc, K.difference_diagonal]
  have htail : ∀ k,
      K.R (K.succ (K.succ k)) (K.succ (K.pred (K.succ (K.succ k)))) =
      K.R (K.succ k) (K.succ (K.pred (K.succ k))) := by
    intro k
    rw [hsuccessor, hsuccessor]
  cases pcCoverage htail n with
  | inl hz => exact Or.inl hz
  | inr h =>
      have hz : K.R n (K.succ (K.pred n)) = K.zero := h.trans (hsuccessor K.zero)
      exact Or.inr ((K.difference_zero_iff n (K.succ (K.pred n))).mp hz)

theorem ordinary_constancy (f : A → A)
    (pc : PositiveConstancy K.zero K.succ f)
    (step : ∀ n, f (K.succ n) = f n) (n : A) : f n = f K.zero := by
  have tail : ∀ k, f (K.succ (K.succ k)) = f (K.succ k) := by
    intro k
    exact step (K.succ k)
  cases pc tail n with
  | inl hz => rw [hz]
  | inr h => exact h.trans (step K.zero)

/- This is a conditional lemma for ONE supplied, representable latch q. -/
theorem zero_induction_from_latch (e q : A → A)
    (qZero : q K.zero = K.one)
    (qSucc : ∀ n, q (K.succ n) = K.B (e n) (q n))
    (pcLatch : PositiveConstancy K.zero K.succ q)
    (base : e K.zero = K.zero)
    (step : ∀ n, e n = K.zero → e (K.succ n) = K.zero) :
    ∀ n, e n = K.zero := by
  have qOne : q K.one = K.one := by
    change q (K.succ K.zero) = K.one
    rw [qSucc, base, K.bZero, qZero]
  have tail : ∀ n, q (K.succ (K.succ n)) = q (K.succ n) := by
    intro n
    cases K.zero_decision (e n) with
    | inl he =>
        rw [qSucc (K.succ n), step n he, K.bZero]
    | inr he =>
        have hq : q (K.succ n) = K.zero := by
          rw [qSucc, K.gate_nonzero (e n) (q n) he]
        rw [qSucc (K.succ n), hq, K.gate_zero]
  have positive : ∀ n, q (K.succ n) = K.one := by
    intro n
    cases pcLatch tail (K.succ n) with
    | inl hz => exact False.elim (K.succ_ne_zero n hz)
    | inr h => exact h.trans qOne
  intro n
  cases K.zero_decision (e n) with
  | inl he => exact he
  | inr he =>
      have hq : q (K.succ n) = K.zero := by
        rw [qSucc, K.gate_nonzero (e n) (q n) he]
      exact False.elim (K.nontrivial (hq.symm.trans (positive n)))

theorem induction_of_zero_code (phi : A → Prop) (e q : A → A)
    (code : ∀ n, e n = K.zero ↔ phi n)
    (qZero : q K.zero = K.one)
    (qSucc : ∀ n, q (K.succ n) = K.B (e n) (q n))
    (pcLatch : PositiveConstancy K.zero K.succ q)
    (base : phi K.zero)
    (step : ∀ n, phi n → phi (K.succ n)) : ∀ n, phi n := by
  have eBase := (code K.zero).mpr base
  have eStep : ∀ n, e n = K.zero → e (K.succ n) = K.zero := by
    intro n hn
    exact (code (K.succ n)).mpr (step n ((code n).mp hn))
  intro n
  exact (code n).mp (K.zero_induction_from_latch e q qZero qSucc pcLatch
    eBase eStep n)

end Kernel

inductive Formula (A : Type u) where
  | atom : (A → A) → (A → A) → Formula A
  | falsum : Formula A
  | conj : Formula A → Formula A → Formula A
  | disj : Formula A → Formula A → Formula A
  | impl : Formula A → Formula A → Formula A

namespace Formula

variable {A : Type u}

def holds : Formula A → A → Prop
  | .atom t v, n => t n = v n
  | .falsum, _ => False
  | .conj f g, n => holds f n ∧ holds g n
  | .disj f g, n => holds f n ∨ holds g n
  | .impl f g, n => holds f n → holds g n

def error (K : Kernel A) : Formula A → A → A
  | .atom t v, n => K.R (t n) (v n)
  | .falsum, _ => K.one
  | .conj f g, n => K.select (error K f n) (error K g n) K.one
  | .disj f g, n => K.select (error K f n) K.zero (error K g n)
  | .impl f g, n => K.select (error K f n) (error K g n) K.zero

theorem error_correct (K : Kernel A) (f : Formula A) (n : A) :
    error K f n = K.zero ↔ holds f n := by
  induction f with
  | atom t v => exact K.difference_zero_iff (t n) (v n)
  | falsum =>
      constructor
      · intro h
        exact K.nontrivial h.symm
      · intro h
        exact False.elim h
  | conj f g hf hg =>
      change K.select (error K f n) (error K g n) K.one = K.zero ↔
        holds f n ∧ holds g n
      cases K.zero_decision (error K f n) with
      | inl hz =>
          rw [hz, K.selector_zero]
          constructor
          · intro h
            exact ⟨hf.mp hz, hg.mp h⟩
          · intro h
            exact hg.mpr h.2
      | inr hn =>
          rw [K.selector_nonzero (error K f n) (error K g n) K.one hn]
          constructor
          · intro h
            exact False.elim (K.nontrivial h.symm)
          · intro h
            exact False.elim (hn (hf.mpr h.1))
  | disj f g hf hg =>
      change K.select (error K f n) K.zero (error K g n) = K.zero ↔
        holds f n ∨ holds g n
      cases K.zero_decision (error K f n) with
      | inl hz =>
          rw [hz, K.selector_zero]
          constructor
          · intro _
            exact Or.inl (hf.mp hz)
          · intro _
            rfl
      | inr hn =>
          rw [K.selector_nonzero (error K f n) K.zero (error K g n) hn]
          constructor
          · intro h
            exact Or.inr (hg.mp h)
          · intro h
            cases h with
            | inl h => exact False.elim (hn (hf.mpr h))
            | inr h => exact hg.mpr h
  | impl f g hf hg =>
      change K.select (error K f n) (error K g n) K.zero = K.zero ↔
        (holds f n → holds g n)
      cases K.zero_decision (error K f n) with
      | inl hz =>
          rw [hz, K.selector_zero]
          constructor
          · intro h _
            exact hg.mp h
          · intro h
            exact hg.mpr (h (hf.mp hz))
      | inr hn =>
          rw [K.selector_nonzero (error K f n) (error K g n) K.zero hn]
          constructor
          · intro _ h
            exact False.elim (hn (hf.mpr h))
          · intro _
            rfl

theorem induction_from_represented_latch (K : Kernel A) (f : Formula A)
    (q : A → A)
    (qZero : q K.zero = K.one)
    (qSucc : ∀ n, q (K.succ n) = K.B (error K f n) (q n))
    (pcLatch : PositiveConstancy K.zero K.succ q)
    (base : holds f K.zero)
    (step : ∀ n, holds f n → holds f (K.succ n)) : ∀ n, holds f n := by
  exact K.induction_of_zero_code (holds f) (error K f) q
    (error_correct K f) qZero qSucc pcLatch base step

end Formula

#print axioms Kernel.difference_zero_iff
#print axioms Kernel.zero_decision
#print axioms Kernel.equality_decision
#print axioms Kernel.constructor_coverage
#print axioms Kernel.zero_induction_from_latch
#print axioms Formula.error_correct
#print axioms Formula.induction_from_represented_latch

end InvolutionKernel


/-
Inherited generic completion through an equality-recognition interface.
Finite-syntax constructive certificate, Lean 4.19.0; no imports.
The interface is discharged from the right-involution law at the end of this file.

Historically adapted from FourUpdates.lean in the earlier source archive,
whose underlying
syntax, selector, digit coding, and formula compiler refine the ProveIt
positive-uniqueness draft (1), snapshot
b0350fd1c96d8273ca9c3b5ce025782b748cded7.

The carrier is arbitrary. Every PC instance ranges over the actual finite
Term syntax below, never over arbitrary carrier maps. The auxiliary ER
interface uses the displayed primitive-recursive equalityError term. The
final endpoint derives it from the new fixed equation and separation;
it is not an unlinked hypothesis. No induction on the carrier is assumed.

The final endpoint certifies all one-parameter quantifier-free induction
instances via actual finite Formula syntax. Pairing and elimination of
arbitrary finite parameter tuples remain written proofs in the paper.
-/

namespace InvolutionConstancy

inductive Term where
  | first
  | second
  | zero
  | succ (argument : Term)
  | iter (update counter seed : Term)
  deriving DecidableEq

def substitute : Term → Term → Term → Term
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => .zero
  | .succ t, x, y => .succ (substitute t x y)
  | .iter h n a, x, y => .iter h (substitute n x y) (substitute a x y)

def evaluate {A : Type u} (zero : A) (succ : A → A)
    (run : Term → A → A → A) : Term → A → A → A
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => zero
  | .succ t, x, y => succ (evaluate zero succ run t x y)
  | .iter h n a, x, y =>
      run h (evaluate zero succ run n x y) (evaluate zero succ run a x y)

structure Model (A : Type u) where
  zero : A
  succ : A → A
  run : Term → A → A → A
  run_zero : ∀ h a, run h zero a = a
  run_succ : ∀ h n a,
    run h (succ n) a = evaluate zero succ run h n (run h n a)

def value {A : Type u} (C : Model A) (t : Term) (x y : A) : A :=
  evaluate C.zero C.succ C.run t x y

variable {A : Type u} (C : Model A)

theorem value_substitute (t x y : Term) (n a : A) :
    value C (substitute t x y) n a =
      value C t (value C x n a) (value C y n a) := by
  induction t with
  | first => rfl
  | second => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | iter h n' a' _ ihn iha =>
      change C.run h (value C (substitute n' x y) n a)
          (value C (substitute a' x y) n a) =
        C.run h (value C n' (value C x n a) (value C y n a))
          (value C a' (value C x n a) (value C y n a))
      exact congr (congrArg (C.run h) ihn) iha

def oneTerm : Term := .succ .zero
def predTerm (t : Term) : Term := .iter .first t .zero
def addTerm (s t : Term) : Term := .iter (.succ .second) s t
def gateTerm (s t : Term) : Term := .iter .zero s t
def monusTerm (s t : Term) : Term := .iter (predTerm .second) s t

def one : A := C.succ C.zero
def pred (x : A) : A := C.run .first x C.zero
def add (x y : A) : A := C.run (.succ .second) x y
def gate (x y : A) : A := C.run .zero x y
def monus (x y : A) : A := C.run (predTerm .second) x y

theorem pred_zero : pred C C.zero = C.zero := C.run_zero _ _
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.run_succ _ _ _
theorem add_zero (x : A) : add C C.zero x = x := C.run_zero _ _
theorem add_succ (x y : A) : add C (C.succ x) y = C.succ (add C x y) :=
  C.run_succ _ _ _
theorem gate_zero (x : A) : gate C C.zero x = x := C.run_zero _ _
theorem gate_succ (x y : A) : gate C (C.succ x) y = C.zero := C.run_succ _ _ _
theorem monus_zero (x : A) : monus C C.zero x = x := C.run_zero _ _
theorem monus_succ (x y : A) : monus C (C.succ x) y = pred C (monus C x y) :=
  C.run_succ _ _ _

/-- Selector obtained from the initialized predecessor, without arithmetic laws. -/
def selectTerm (z x y : Term) : Term := .iter .first (gateTerm z (.succ x)) y

def select (z x y : A) : A := C.run .first (gate C z (C.succ x)) y

/- Explicit finite descriptor for signed-integer difference.
   Under d(2m)=m, d(2m+1)=-(m+1), signedUpUpdate adds one,
   signedDownUpdate subtracts one, and equalityError(x,y) codes d(y)-d(x).
   This numerical interpretation is verified in the paper, not assumed here.
-/
def signedParityUpdate : Term := gateTerm .second oneTerm

def signedParityTerm (t : Term) : Term := .iter signedParityUpdate t .zero

def signedUpUpdate : Term :=
  selectTerm (signedParityTerm .second)
    (.succ (.succ .second)) (predTerm (predTerm .second))

def signedDownUpdate : Term :=
  selectTerm (signedParityTerm .second)
    (.iter .first (predTerm .second) oneTerm)
    (.succ (.succ .second))

def signedDifferenceUpdate : Term :=
  selectTerm (signedParityTerm .first)
    (.iter signedUpUpdate (.succ .first) .second)
    (.iter signedDownUpdate (.succ .first) .second)

/-- The native equality error is one specified binary iterator. -/
def equalityErrorTerm (x y : Term) : Term := .iter signedDifferenceUpdate x y

def equalityError (x y : A) : A := C.run signedDifferenceUpdate x y

/-- One unrestricted finite term, one fixed numerical parameter. -/
def PositiveConstancy : Prop :=
  ∀ t : Term, ∀ a : A,
    (∀ n, value C t (C.succ (C.succ n)) a = value C t (C.succ n) a) →
    ∀ n, n = C.zero ∨ value C t n a = value C t (one C) a

/-- Auxiliary interface, discharged by derived_equality_recognition below. -/
def EqualityRecognition : Prop :=
  ∀ x y : A, x = y ↔ gate C (equalityError C x y) (one C) ≠ C.zero

variable (PC : PositiveConstancy C) (ER : EqualityRecognition C)
include PC ER

omit PC in
theorem separation : C.zero ≠ C.succ C.zero := by
  have h := (ER C.zero C.zero).mp rfl
  have hz : equalityError C C.zero C.zero = C.zero :=
    C.run_zero signedDifferenceUpdate C.zero
  rw [hz, gate_zero C] at h
  intro bad
  exact h bad.symm

omit PC ER in
theorem successor_injective {x y : A} (h : C.succ x = C.succ y) : x = y := by
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_succ C] at e
  exact e

omit PC in
theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro h
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_zero C] at e
  have bad : C.succ C.zero = C.zero := (congrArg C.succ e).symm.trans h
  exact separation C ER bad.symm

omit ER in
/-- The first PC instance obtains a gate law before constructor coverage. -/
theorem zero_or_gate (a x : A) : x = C.zero ∨ gate C x a = C.zero := by
  have q := PC (gateTerm .first .second) a (by
    intro n
    change gate C (C.succ (C.succ n)) a = gate C (C.succ n) a
    rw [gate_succ C, gate_succ C]) x
  rcases q with h | h
  · exact Or.inl h
  · change gate C x a = gate C (C.succ C.zero) a at h
    rw [gate_succ C] at h
    exact Or.inr h

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases zero_or_gate C PC (one C) x with h | h
  · exact Or.inl h
  · apply Or.inr
    intro bad
    rw [bad, gate_zero C] at h
    exact separation C ER h.symm

omit ER in
theorem gate_nonzero {x : A} (hx : x ≠ C.zero) (y : A) : gate C x y = C.zero := by
  rcases zero_or_gate C PC y x with h | h
  · exact False.elim (hx h)
  · exact h

theorem gate_nonzero_iff (x : A) : gate C x (one C) ≠ C.zero ↔ x = C.zero := by
  constructor
  · intro h
    rcases zero_or_gate C PC (one C) x with hx | hx
    · exact hx
    · exact False.elim (h hx)
  · intro h bad
    rw [h, gate_zero C] at bad
    exact separation C ER bad.symm

theorem equality_reflection (x y : A) : equalityError C x y = C.zero ↔ x = y := by
  exact ((ER x y).trans (gate_nonzero_iff C PC ER (equalityError C x y))).symm

theorem equality_decision (x y : A) : x = y ∨ x ≠ y := by
  rcases zero_decision C PC ER (equalityError C x y) with h | h
  · exact Or.inl ((equality_reflection C PC ER x y).mp h)
  · exact Or.inr (fun q => h ((equality_reflection C PC ER x y).mpr q))

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  let t := equalityErrorTerm .first (.succ (predTerm .first))
  have at_succ (n : A) : value C t (C.succ n) C.zero = C.zero := by
    change equalityError C (C.succ n) (C.succ (pred C (C.succ n))) = C.zero
    rw [pred_succ C]
    exact (equality_reflection C PC ER _ _).mpr rfl
  have q := PC t C.zero (by
    intro n
    exact (at_succ (C.succ n)).trans (at_succ n).symm) x
  rcases q with h | h
  · exact Or.inl h
  · have r := h.trans (at_succ C.zero)
    exact Or.inr ((equality_reflection C PC ER _ _).mp r)

/-- Ordinary term constancy is obtained by one predecessor delay. -/
theorem ordinary_constancy (t : Term) (a : A)
    (step : ∀ n, value C t (C.succ n) a = value C t n a) :
    ∀ n, value C t n a = value C t C.zero a := by
  let delayed := substitute t (predTerm .first) .second
  have delay (x : A) : value C delayed x a = value C t (pred C x) a := by
    exact value_substitute C t (predTerm .first) .second x a
  have positive := PC delayed a (by
    intro n
    rw [delay, delay, pred_succ C, pred_succ C]
    exact step n)
  intro n
  rcases positive (C.succ n) with hz | he
  · exact False.elim (successor_ne_zero C ER n hz)
  · rw [delay, delay, pred_succ C] at he
    change value C t n a = value C t (pred C (C.succ C.zero)) a at he
    rw [pred_succ C] at he
    exact he

def Bit (x : A) : Prop := x = C.zero ∨ x = one C

theorem gate_is_bit (x : A) : Bit C (gate C x (one C)) := by
  rcases zero_decision C PC ER x with h | h
  · exact Or.inr (by rw [h, gate_zero C])
  · exact Or.inl (gate_nonzero C PC h _)

def equalBitTerm (s t : Term) : Term := gateTerm (equalityErrorTerm s t) oneTerm
def equalBit (x y : A) : A := gate C (equalityError C x y) (one C)

theorem equalBit_is_bit (x y : A) : Bit C (equalBit C x y) :=
  gate_is_bit C PC ER _

theorem equalBit_one_iff (x y : A) : equalBit C x y = one C ↔ x = y := by
  constructor
  · intro h
    apply (ER x y).mpr
    change equalBit C x y ≠ C.zero
    intro bad
    exact separation C ER (bad.symm.trans h)
  · intro h
    rcases equalBit_is_bit C PC ER x y with hz | ho
    · exact False.elim ((ER x y).mp h hz)
    · exact ho

theorem equalBit_invariance (x y z w : A) (h : x = y ↔ z = w) :
    equalBit C x y = equalBit C z w := by
  rcases equalBit_is_bit C PC ER x y with hx | hx
  · rcases equalBit_is_bit C PC ER z w with hz | hz
    · exact hx.trans hz.symm
    · have eqxy := h.mpr ((equalBit_one_iff C PC ER z w).mp hz)
      have hx1 := (equalBit_one_iff C PC ER x y).mpr eqxy
      exact False.elim (separation C ER (hx.symm.trans hx1))
  · have eqzw := h.mp ((equalBit_one_iff C PC ER x y).mp hx)
    exact hx.trans ((equalBit_one_iff C PC ER z w).mpr eqzw).symm

/-- Successor uniqueness is derived, not included in the arithmetic schema. -/
theorem successor_solutions_equal (t u : Term) (a : A)
    (base : value C t C.zero a = value C u C.zero a)
    (stept : ∀ n, value C t (C.succ n) a = C.succ (value C t n a))
    (stepu : ∀ n, value C u (C.succ n) a = C.succ (value C u n a)) :
    ∀ n, value C t n a = value C u n a := by
  let monitor := equalBitTerm t u
  have invariant (n : A) : value C monitor (C.succ n) a = value C monitor n a := by
    change equalBit C (value C t (C.succ n) a) (value C u (C.succ n) a) =
      equalBit C (value C t n a) (value C u n a)
    apply equalBit_invariance C PC ER
    rw [stept, stepu]
    exact ⟨successor_injective C, congrArg C.succ⟩
  have q := ordinary_constancy C PC ER monitor a invariant
  intro n
  have qn := q n
  change equalBit C (value C t n a) (value C u n a) =
    equalBit C (value C t C.zero a) (value C u C.zero a) at qn
  have b := (equalBit_one_iff C PC ER _ _).mpr base
  exact (equalBit_one_iff C PC ER _ _).mp (qn.trans b)



omit PC ER in
theorem select_zero (x y : A) : select C C.zero x y = x := by
  unfold select
  rw [gate_zero C]
  exact C.run_succ .first x y

omit PC ER in
theorem select_succ (z x y : A) : select C (C.succ z) x y = y := by
  unfold select
  rw [gate_succ C]
  exact C.run_zero .first y

omit ER in
theorem select_nonzero {z : A} (hz : z ≠ C.zero) (x y : A) :
    select C z x y = y := by
  unfold select
  rw [gate_nonzero C PC hz]
  exact C.run_zero .first y

theorem select_same (z x : A) : select C z x x = x := by
  rcases zero_decision C PC ER z with h | h
  · rw [h, select_zero C]
  · exact select_nonzero C PC h x x

omit PC ER in
theorem value_select (z x y : Term) (n a : A) :
    value C (selectTerm z x y) n a =
      select C (value C z n a) (value C x n a) (value C y n a) := rfl

def parityUpdate : Term := gateTerm .second oneTerm
def parityTerm (t : Term) : Term := .iter parityUpdate t .zero
def halfUpdate : Term := selectTerm (parityTerm .first) .second (.succ .second)
def halfTerm (t : Term) : Term := .iter halfUpdate t .zero
def doubleTerm (t : Term) : Term := .iter (.succ (.succ .second)) t .zero

def parity (x : A) : A := C.run parityUpdate x C.zero
def half (x : A) : A := C.run halfUpdate x C.zero
def double (x : A) : A := C.run (.succ (.succ .second)) x C.zero

omit PC ER in
theorem parity_zero : parity C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem parity_succ (x : A) : parity C (C.succ x) = gate C (parity C x) (one C) :=
  C.run_succ _ _ _
omit PC ER in
theorem half_zero : half C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem half_succ (x : A) : half C (C.succ x) =
    select C (parity C x) (half C x) (C.succ (half C x)) := C.run_succ _ _ _
omit PC ER in
theorem double_zero : double C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem double_succ (x : A) : double C (C.succ x) =
    C.succ (C.succ (double C x)) := C.run_succ _ _ _
theorem parity_is_bit (x : A) : Bit C (parity C x) := by
  rcases coverage C PC ER x with h | h
  · exact Or.inl (by rw [h, parity_zero C])
  · rw [h, parity_succ C]
    exact gate_is_bit C PC ER _

theorem parity_twice (x : A) : parity C (C.succ (C.succ x)) = parity C x := by
  rw [parity_succ C, parity_succ C]
  rcases parity_is_bit C PC ER x with h | h
  · rw [h, gate_zero C]
    exact gate_succ C C.zero (one C)
  · rw [h]
    change gate C (gate C (C.succ C.zero) (one C)) (one C) = one C
    rw [gate_succ C, gate_zero C]

theorem half_twice (x : A) : half C (C.succ (C.succ x)) = C.succ (half C x) := by
  rw [half_succ C, half_succ C, parity_succ C]
  rcases parity_is_bit C PC ER x with h | h
  · rw [h, gate_zero C, select_zero C]
    exact select_succ C C.zero (half C x) (C.succ (half C x))
  · rw [h]
    change select C (gate C (C.succ C.zero) (one C))
      (select C (C.succ C.zero) (half C x) (C.succ (half C x)))
      (C.succ (select C (C.succ C.zero) (half C x) (C.succ (half C x)))) =
      C.succ (half C x)
    rw [gate_succ C, select_succ C, select_zero C]


/-- This proof uses only the derived term-constancy principle. -/
theorem parity_double (x : A) : parity C (double C x) = C.zero := by
  let t := parityTerm (doubleTerm .first)
  have step (n : A) : value C t (C.succ n) C.zero = value C t n C.zero := by
    change parity C (double C (C.succ n)) = parity C (double C n)
    rw [double_succ C, parity_twice C PC ER]
  have q := ordinary_constancy C PC ER t C.zero step x
  change parity C (double C x) = parity C (double C C.zero) at q
  rw [double_zero C, parity_zero C] at q
  exact q

/-- Successor comparison was proved with a Boolean equality monitor. -/
theorem half_double (x : A) : half C (double C x) = x := by
  let t := halfTerm (doubleTerm .first)
  have base : value C t C.zero C.zero = value C .first C.zero C.zero := by
    change half C (double C C.zero) = C.zero
    rw [double_zero C, half_zero C]
  have step (n : A) : value C t (C.succ n) C.zero = C.succ (value C t n C.zero) := by
    change half C (double C (C.succ n)) = C.succ (half C (double C n))
    rw [double_succ C, half_twice C PC ER]
  exact successor_solutions_equal C PC ER t .first C.zero base step (fun _ => rfl) x
theorem parity_odd (x : A) : parity C (C.succ (double C x)) = one C := by
  rw [parity_succ C, parity_double C PC ER, gate_zero C]

theorem half_odd (x : A) : half C (C.succ (double C x)) = x := by
  rw [half_succ C, parity_double C PC ER, select_zero C, half_double C PC ER]

def encodeTerm (a b : Term) : Term := selectTerm b (doubleTerm a) (.succ (doubleTerm a))
def encode (a b : A) : A := select C b (double C a) (C.succ (double C a))

omit PC ER in
theorem encode_zero (a : A) : encode C a C.zero = double C a :=
  select_zero C _ _

omit PC ER in
theorem encode_one (a : A) : encode C a (one C) = C.succ (double C a) :=
  select_succ C C.zero _ _

theorem half_encode (a b : A) : half C (encode C a b) = a := by
  rcases coverage C PC ER b with h | h
  · rw [h, encode_zero C, half_double C PC ER]
  · unfold encode
    rw [h, select_succ C, half_odd C PC ER]

theorem parity_encode (a b : A) (hb : Bit C b) : parity C (encode C a b) = b := by
  rcases hb with h | h
  · rw [h, encode_zero C, parity_double C PC ER]
  · rw [h, encode_one C, parity_odd C PC ER]

def indicatorTerm (t : Term) : Term := selectTerm t .zero oneTerm
def indicator (x : A) : A := select C x C.zero (one C)

omit PC ER in
theorem indicator_zero : indicator C C.zero = C.zero := select_zero C _ _
omit ER in
theorem indicator_nonzero {x : A} (hx : x ≠ C.zero) : indicator C x = one C :=
  select_nonzero C PC hx _ _

theorem indicator_is_bit (x : A) : Bit C (indicator C x) := by
  rcases zero_decision C PC ER x with h | h
  · exact Or.inl (by rw [h, indicator_zero C])
  · exact Or.inr (indicator_nonzero C PC h)

theorem indicator_reflects (x : A) (hx : indicator C x = C.zero) : x = C.zero := by
  rcases zero_decision C PC ER x with h | h
  · exact h
  · rw [indicator_nonzero C PC h] at hx
    exact False.elim (separation C ER hx.symm)

omit PC ER in
theorem value_encode (a b : Term) (n p : A) :
    value C (encodeTerm a b) n p = encode C (value C a n p) (value C b n p) := rfl

omit PC ER in
theorem value_indicator (t : Term) (n a : A) :
    value C (indicatorTerm t) n a = indicator C (value C t n a) := rfl


/-- This target-dependent update belongs only to the computation grammar. -/
def latchUpdate (t : Term) : Term :=
  encodeTerm (halfTerm .second)
    (selectTerm (parityTerm .second)
      (indicatorTerm (substitute t (.succ .first) (halfTerm .second))) oneTerm)

def latchStateTerm (t : Term) : Term :=
  .iter (latchUpdate t) .first
    (encodeTerm .second (indicatorTerm (substitute t .zero .second)))

def latchTerm (t : Term) : Term := parityTerm (latchStateTerm t)

def latchState (t : Term) (n a : A) : A :=
  C.run (latchUpdate t) n (encode C a (indicator C (value C t C.zero a)))

def latch (t : Term) (n a : A) : A := parity C (latchState C t n a)

omit PC ER in
theorem value_latchUpdate (t : Term) (n v : A) :
    value C (latchUpdate t) n v =
      encode C (half C v)
        (select C (parity C v)
          (indicator C (value C t (C.succ n) (half C v))) (one C)) := by
  unfold latchUpdate
  rw [value_encode C, value_select C, value_indicator C, value_substitute C]
  rfl

omit PC ER in
theorem value_latchState (t : Term) (n a : A) :
    value C (latchStateTerm t) n a = latchState C t n a := by
  change C.run (latchUpdate t) n
    (value C (encodeTerm .second (indicatorTerm (substitute t .zero .second))) n a) = _
  rw [value_encode C, value_indicator C, value_substitute C]
  rfl

omit PC ER in
theorem value_latch (t : Term) (n a : A) :
    value C (latchTerm t) n a = latch C t n a := by
  change parity C (value C (latchStateTerm t) n a) = _
  rw [value_latchState C]
  rfl

omit PC ER in
theorem latchState_zero (t : Term) (a : A) :
    latchState C t C.zero a = encode C a (indicator C (value C t C.zero a)) :=
  C.run_zero _ _

omit PC ER in
theorem latchState_succ (t : Term) (n a : A) :
    latchState C t (C.succ n) a =
      encode C (half C (latchState C t n a))
        (select C (parity C (latchState C t n a))
          (indicator C (value C t (C.succ n) (half C (latchState C t n a))))
          (one C)) := by
  have q := C.run_succ (latchUpdate t) n
    (encode C a (indicator C (value C t C.zero a)))
  change latchState C t (C.succ n) a =
    value C (latchUpdate t) n (latchState C t n a) at q
  rw [value_latchUpdate C] at q
  exact q


/-- Parameter preservation invokes only the derived term-constancy principle. -/
theorem stored_parameter (t : Term) (n a : A) :
    half C (latchState C t n a) = a := by
  let f := halfTerm (latchStateTerm t)
  have vf (x : A) : value C f x a = half C (latchState C t x a) := by
    change half C (value C (latchStateTerm t) x a) = _
    rw [value_latchState C]
  have step (x : A) : value C f (C.succ x) a = value C f x a := by
    rw [vf, vf, latchState_succ C, half_encode C PC ER]
  have q := ordinary_constancy C PC ER f a step n
  rw [vf, vf, latchState_zero C, half_encode C PC ER] at q
  exact q
omit PC ER in
theorem bit_or (x y : A) (hx : Bit C x) (hy : Bit C y) :
    Bit C (select C x y (one C)) := by
  rcases hx with hx | hx
  · rw [hx, select_zero C]
    exact hy
  · rw [hx]
    change Bit C (select C (C.succ C.zero) y (one C))
    rw [select_succ C]
    exact Or.inr rfl

theorem bit_or_zero_right (x y : A)
    (h : select C x y (one C) = C.zero) : y = C.zero := by
  rcases zero_decision C PC ER x with hx | hx
  · rw [hx, select_zero C] at h
    exact h
  · rw [select_nonzero C PC hx] at h
    exact False.elim (separation C ER h.symm)

theorem latch_is_bit (t : Term) (n a : A) : Bit C (latch C t n a) :=
  parity_is_bit C PC ER _

theorem latch_zero (t : Term) (a : A) :
    latch C t C.zero a = indicator C (value C t C.zero a) := by
  unfold latch
  rw [latchState_zero C, parity_encode C PC ER _ _ (indicator_is_bit C PC ER _)]

theorem latch_succ (t : Term) (n a : A) :
    latch C t (C.succ n) a =
      select C (latch C t n a)
        (indicator C (value C t (C.succ n) a)) (one C) := by
  unfold latch
  rw [latchState_succ C]
  rw [parity_encode C PC ER _ _ (bit_or C _ _
    (parity_is_bit C PC ER _) (indicator_is_bit C PC ER _))]
  rw [stored_parameter C PC ER]

/-- The current factor is present in the latch by constructor coverage alone. -/
theorem latch_reflects (t : Term) (n a : A)
    (hn : latch C t n a = C.zero) : value C t n a = C.zero := by
  rcases coverage C PC ER n with hz | hs
  · rw [hz, latch_zero C PC ER] at hn
    rw [hz]
    exact indicator_reflects C PC ER _ hn
  · rw [hs, latch_succ C PC ER] at hn
    have hb := bit_or_zero_right C PC ER _ _ hn
    rw [hs]
    exact indicator_reflects C PC ER _ hb


/-- Contextual zero induction from positive constancy and the fixed ER sentence. -/
theorem zero_induction (t : Term) (a : A)
    (base : value C t C.zero a = C.zero)
    (step : ∀ n, value C t n a = C.zero → value C t (C.succ n) a = C.zero) :
    ∀ n, value C t n a = C.zero := by
  have constant (n : A) : latch C t (C.succ n) a = latch C t n a := by
    rcases latch_is_bit C PC ER t n a with hz | ho
    · have next := step n (latch_reflects C PC ER t n a hz)
      rw [latch_succ C PC ER, hz, next, indicator_zero C, select_zero C]
    · rw [latch_succ C PC ER, ho]
      exact select_succ C C.zero _ _
  have term_step (n : A) : value C (latchTerm t) (C.succ n) a =
      value C (latchTerm t) n a := by
    rw [value_latch C, value_latch C]
    exact constant n
  have trace := ordinary_constancy C PC ER (latchTerm t) a term_step
  intro n
  have q := trace n
  rw [value_latch C, value_latch C, latch_zero C PC ER, base, indicator_zero C] at q
  exact latch_reflects C PC ER t n a q
/-- Actual finite quantifier-free syntax with two free numerical slots. -/
inductive Formula where
  | equal (left right : Term)
  | falsehood
  | conj (left right : Formula)
  | disj (left right : Formula)
  | impl (left right : Formula)

def holds : Formula → A → A → Prop
  | .equal s t, n, a => value C s n a = value C t n a
  | .falsehood, _, _ => False
  | .conj P Q, n, a => holds P n a ∧ holds Q n a
  | .disj P Q, n, a => holds P n a ∨ holds Q n a
  | .impl P Q, n, a => holds P n a → holds Q n a

def errorTerm : Formula → Term
  | .equal s t => equalityErrorTerm s t
  | .falsehood => oneTerm
  | .conj P Q => selectTerm (errorTerm P) (errorTerm Q) oneTerm
  | .disj P Q => selectTerm (errorTerm P) .zero (errorTerm Q)
  | .impl P Q => selectTerm (errorTerm P) (errorTerm Q) .zero

/-- Constructive compilation, including material implication on decided atoms. -/
theorem error_correct (P : Formula) (n a : A) :
    value C (errorTerm P) n a = C.zero ↔ holds C P n a := by
  induction P with
  | equal s t =>
      exact equality_reflection C PC ER (value C s n a) (value C t n a)
  | falsehood =>
      change one C = C.zero ↔ False
      constructor
      · intro h
        exact separation C ER h.symm
      · intro h
        exact False.elim h
  | conj P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) (value C (errorTerm Q) n a)
        (one C) = C.zero ↔ holds C P n a ∧ holds C Q n a
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro hq
          exact ⟨ihP.mp hp, ihQ.mp hq⟩
        · intro h
          exact ihQ.mpr h.2
      · rw [select_nonzero C PC hp]
        constructor
        · intro h
          exact False.elim (separation C ER h.symm)
        · intro h
          exact False.elim (hp (ihP.mpr h.1))
  | disj P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) C.zero
        (value C (errorTerm Q) n a) = C.zero ↔ holds C P n a ∨ holds C Q n a
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro _
          exact Or.inl (ihP.mp hp)
        · intro _
          rfl
      · rw [select_nonzero C PC hp]
        constructor
        · intro hq
          exact Or.inr (ihQ.mp hq)
        · intro h
          rcases h with h | h
          · exact False.elim (hp (ihP.mpr h))
          · exact ihQ.mpr h
  | impl P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) (value C (errorTerm Q) n a)
        C.zero = C.zero ↔ (holds C P n a → holds C Q n a)
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro hq _
          exact ihQ.mp hq
        · intro h
          exact ihQ.mpr (h (ihP.mp hp))
      · rw [select_nonzero C PC hp]
        constructor
        · intro _ h
          exact False.elim (hp (ihP.mpr h))
        · intro _
          rfl

theorem quantifier_free_decision (P : Formula) (n a : A) :
    holds C P n a ∨ ¬ holds C P n a := by
  rcases zero_decision C PC ER (value C (errorTerm P) n a) with h | h
  · exact Or.inl ((error_correct C PC ER P n a).mp h)
  · exact Or.inr (fun q => h ((error_correct C PC ER P n a).mpr q))

/-- The linked finite-syntax endpoint: full quantifier-free induction,
    with one arbitrary fixed numerical parameter, from PC and the fixed ER sentence. -/
theorem quantifier_free_induction (P : Formula) (a : A)
    (base : holds C P C.zero a)
    (step : ∀ n, holds C P n a → holds C P (C.succ n) a) :
    ∀ n, holds C P n a := by
  have ezero := (error_correct C PC ER P C.zero a).mpr base
  have estep (n : A) (h : value C (errorTerm P) n a = C.zero) :
      value C (errorTerm P) (C.succ n) a = C.zero := by
    apply (error_correct C PC ER P (C.succ n) a).mpr
    exact step n ((error_correct C PC ER P n a).mp h)
  have eind := zero_induction C PC ER (errorTerm P) a ezero estep
  intro n
  exact (error_correct C PC ER P n a).mp (eind n)


#print axioms value_substitute
#print axioms separation
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms zero_or_gate
#print axioms zero_decision
#print axioms gate_nonzero_iff
#print axioms equality_reflection
#print axioms equality_decision
#print axioms coverage
#print axioms ordinary_constancy
#print axioms equalBit_invariance
#print axioms successor_solutions_equal
#print axioms parity_double
#print axioms half_double
#print axioms half_encode
#print axioms parity_encode
#print axioms stored_parameter
#print axioms latch_reflects
#print axioms zero_induction
#print axioms error_correct
#print axioms quantifier_free_decision
#print axioms quantifier_free_induction


/- Every use of abstract PC is now supplied by an actual finite Term. -/

/-- The single fixed equation for the specified iterator. -/
def RightInvolution : Prop :=
  ∀ x y : A, equalityError C (equalityError C x y) y = x

omit PC ER in
/-- Explicitly instantiate the abstract kernel from finite syntax. -/
def bridgeKernel (pc : PositiveConstancy C) (sep : C.zero ≠ C.succ C.zero)
    (hinv : RightInvolution C) : InvolutionKernel.Kernel A where
  zero := C.zero
  succ := C.succ
  P := C.run .first
  B := gate C
  R := equalityError C
  pZero := C.run_zero .first
  pSucc := fun n a => C.run_succ .first n a
  bZero := gate_zero C
  bSucc := gate_succ C
  rZero := C.run_zero signedDifferenceUpdate
  nontrivial := sep
  pcGate := by
    intro a h n
    exact pc (gateTerm .first .second) a h n
  rightInvolution := hinv

omit PC ER in
theorem involution_error_correct (pc : PositiveConstancy C)
    (sep : C.zero ≠ C.succ C.zero) (hinv : RightInvolution C)
    (x y : A) : equalityError C x y = C.zero ↔ x = y := by
  exact (bridgeKernel C pc sep hinv).difference_zero_iff x y

omit PC ER in
/-- Equality recognition is discharged, not a hypothesis at the endpoint. -/
theorem derived_equality_recognition (pc : PositiveConstancy C)
    (sep : C.zero ≠ C.succ C.zero) (hinv : RightInvolution C) :
    EqualityRecognition C := by
  intro x y
  constructor
  · intro hxy hz
    have herror := (involution_error_correct C pc sep hinv x y).mpr hxy
    rw [herror, gate_zero C] at hz
    exact sep hz.symm
  · intro hn
    rcases zero_or_gate C pc (one C) (equalityError C x y) with hz | hg
    · exact (involution_error_correct C pc sep hinv x y).mp hz
    · exact False.elim (hn hg)

omit PC ER in
/-- Fully linked finite-syntax endpoint under D + Sep + PC + Inv. -/
theorem main_quantifier_free_induction (pc : PositiveConstancy C)
    (sep : C.zero ≠ C.succ C.zero) (hinv : RightInvolution C)
    (P : Formula) (a : A) (base : holds C P C.zero a)
    (step : ∀ n, holds C P n a → holds C P (C.succ n) a) :
    ∀ n, holds C P n a := by
  exact quantifier_free_induction C pc
    (derived_equality_recognition C pc sep hinv) P a base step

omit PC ER in
theorem main_quantifier_free_decision (pc : PositiveConstancy C)
    (sep : C.zero ≠ C.succ C.zero) (hinv : RightInvolution C)
    (P : Formula) (n a : A) : holds C P n a ∨ ¬ holds C P n a := by
  exact quantifier_free_decision C pc
    (derived_equality_recognition C pc sep hinv) P n a

#print axioms bridgeKernel
#print axioms involution_error_correct
#print axioms derived_equality_recognition
#print axioms main_quantifier_free_induction
#print axioms main_quantifier_free_decision

#check main_quantifier_free_induction
#check main_quantifier_free_decision

end InvolutionConstancy
