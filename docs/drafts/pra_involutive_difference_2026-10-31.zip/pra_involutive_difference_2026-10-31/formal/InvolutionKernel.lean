/-
  Constructive kernel for positive constancy and right involution.
  Lean 4.19.0, no imports.

  The carrier A is arbitrary. No induction on A, native equality decision,
  classical logic, choice, or arithmetic axiom beyond the listed hypotheses
  is used. PositiveConstancy is assumed only for the indicated gate family
  and, in later lemmas, for one specified coverage term or one specified
  latch. There is no global quantification of PC over all semantic functions.

  Formula is finite propositional syntax whose atoms are pairs of functions.
  Its structural induction is syntactic, not arithmetic induction. A source
  term interpretation may supply those functions; representability of the
  error and latch by legal PR descriptions is a separate written argument.
  Likewise, soundness of the chosen signed-difference program's involution
  in ordinary PRA and the full bi-interpretation are not formalized here.
-/

universe u

namespace InvolutionKernel

def PositiveConstancy {A : Type u} (zero : A) (succ : A → A)
    (f : A → A) : Prop :=
  (∀ n, f (succ (succ n)) = f (succ n)) →
  ∀ n, n = zero ∨ f n = f (succ zero)

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  P : A → A → A
  B : A → A → A
  R : A → A → A
  pZero : ∀ a, P zero a = a
  pSucc : ∀ n a, P (succ n) a = n
  bZero : ∀ a, B zero a = a
  bSucc : ∀ n a, B (succ n) a = zero
  rZero : ∀ a, R zero a = a
  nontrivial : zero ≠ succ zero
  pcGate : ∀ a, PositiveConstancy zero succ (fun n => B n a)
  rightInvolution : ∀ x y, R (R x y) y = x

namespace Kernel

variable {A : Type u} (K : Kernel A)

def one : A := K.succ K.zero

def pred (x : A) : A := K.P x K.zero

def select (z a b : A) : A := K.P (K.B z (K.succ a)) b

theorem succ_injective (x y : A) (h : K.succ x = K.succ y) : x = y := by
  have hp := congrArg (fun t => K.P t K.zero) h
  change K.P (K.succ x) K.zero = K.P (K.succ y) K.zero at hp
  rw [K.pSucc, K.pSucc] at hp
  exact hp

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro h
  have hp := congrArg (fun t => K.P t K.zero) h
  change K.P (K.succ x) K.zero = K.P K.zero K.zero at hp
  rw [K.pSucc, K.pZero] at hp
  rw [hp] at h
  exact K.nontrivial h.symm

theorem gate_alternative (n a : A) :
    n = K.zero ∨ K.B n a = K.zero := by
  have htail : ∀ k, K.B (K.succ (K.succ k)) a = K.B (K.succ k) a := by
    intro k
    rw [K.bSucc, K.bSucc]
  have h := K.pcGate a htail n
  change n = K.zero ∨ K.B n a = K.B (K.succ K.zero) a at h
  rw [K.bSucc] at h
  exact h

theorem gate_nonzero (n a : A) (hn : n ≠ K.zero) : K.B n a = K.zero := by
  cases K.gate_alternative n a with
  | inl hz => exact False.elim (hn hz)
  | inr h => exact h

theorem gate_zero (n : A) : K.B n K.zero = K.zero := by
  cases K.gate_alternative n K.zero with
  | inl hz => rw [hz, K.bZero]
  | inr h => exact h

theorem zero_decision (n : A) : n = K.zero ∨ n ≠ K.zero := by
  cases K.gate_alternative n K.one with
  | inl hz => exact Or.inl hz
  | inr h =>
      apply Or.inr
      intro hz
      rw [hz, K.bZero] at h
      exact K.nontrivial h.symm

theorem difference_diagonal (x : A) : K.R x x = K.zero := by
  have h := K.rightInvolution K.zero x
  rw [K.rZero] at h
  exact h

theorem difference_zero_iff (x y : A) : K.R x y = K.zero ↔ x = y := by
  constructor
  · intro hxy
    have h := K.rightInvolution x y
    rw [hxy, K.rZero] at h
    exact h.symm
  · intro hxy
    rw [hxy]
    exact K.difference_diagonal y

include K in
theorem equality_decision (x y : A) : x = y ∨ x ≠ y := by
  cases K.zero_decision (K.R x y) with
  | inl hz => exact Or.inl ((K.difference_zero_iff x y).mp hz)
  | inr hn =>
      exact Or.inr (fun hxy => hn ((K.difference_zero_iff x y).mpr hxy))

theorem selector_zero (a b : A) : K.select K.zero a b = a := by
  unfold select
  rw [K.bZero, K.pSucc]

theorem selector_nonzero (z a b : A) (hz : z ≠ K.zero) :
    K.select z a b = b := by
  unfold select
  rw [K.gate_nonzero z (K.succ a) hz, K.pZero]

theorem selector_equal (z a : A) : K.select z a a = a := by
  cases K.zero_decision z with
  | inl hz => rw [hz, K.selector_zero]
  | inr hn => exact K.selector_nonzero z a a hn

theorem constructor_coverage
    (pcCoverage : PositiveConstancy K.zero K.succ
      (fun n => K.R n (K.succ (K.pred n))))
    (n : A) : n = K.zero ∨ n = K.succ (K.pred n) := by
  have hsuccessor : ∀ k, K.R (K.succ k) (K.succ (K.pred (K.succ k))) =
      K.zero := by
    intro k
    unfold pred
    rw [K.pSucc, K.difference_diagonal]
  have htail : ∀ k,
      K.R (K.succ (K.succ k)) (K.succ (K.pred (K.succ (K.succ k)))) =
      K.R (K.succ k) (K.succ (K.pred (K.succ k))) := by
    intro k
    rw [hsuccessor, hsuccessor]
  cases pcCoverage htail n with
  | inl hz => exact Or.inl hz
  | inr h =>
      have hz : K.R n (K.succ (K.pred n)) = K.zero := h.trans (hsuccessor K.zero)
      exact Or.inr ((K.difference_zero_iff n (K.succ (K.pred n))).mp hz)

theorem ordinary_constancy (f : A → A)
    (pc : PositiveConstancy K.zero K.succ f)
    (step : ∀ n, f (K.succ n) = f n) (n : A) : f n = f K.zero := by
  have tail : ∀ k, f (K.succ (K.succ k)) = f (K.succ k) := by
    intro k
    exact step (K.succ k)
  cases pc tail n with
  | inl hz => rw [hz]
  | inr h => exact h.trans (step K.zero)

/- This is a conditional lemma for ONE supplied, representable latch q. -/
theorem zero_induction_from_latch (e q : A → A)
    (qZero : q K.zero = K.one)
    (qSucc : ∀ n, q (K.succ n) = K.B (e n) (q n))
    (pcLatch : PositiveConstancy K.zero K.succ q)
    (base : e K.zero = K.zero)
    (step : ∀ n, e n = K.zero → e (K.succ n) = K.zero) :
    ∀ n, e n = K.zero := by
  have qOne : q K.one = K.one := by
    change q (K.succ K.zero) = K.one
    rw [qSucc, base, K.bZero, qZero]
  have tail : ∀ n, q (K.succ (K.succ n)) = q (K.succ n) := by
    intro n
    cases K.zero_decision (e n) with
    | inl he =>
        rw [qSucc (K.succ n), step n he, K.bZero]
    | inr he =>
        have hq : q (K.succ n) = K.zero := by
          rw [qSucc, K.gate_nonzero (e n) (q n) he]
        rw [qSucc (K.succ n), hq, K.gate_zero]
  have positive : ∀ n, q (K.succ n) = K.one := by
    intro n
    cases pcLatch tail (K.succ n) with
    | inl hz => exact False.elim (K.succ_ne_zero n hz)
    | inr h => exact h.trans qOne
  intro n
  cases K.zero_decision (e n) with
  | inl he => exact he
  | inr he =>
      have hq : q (K.succ n) = K.zero := by
        rw [qSucc, K.gate_nonzero (e n) (q n) he]
      exact False.elim (K.nontrivial (hq.symm.trans (positive n)))

theorem induction_of_zero_code (phi : A → Prop) (e q : A → A)
    (code : ∀ n, e n = K.zero ↔ phi n)
    (qZero : q K.zero = K.one)
    (qSucc : ∀ n, q (K.succ n) = K.B (e n) (q n))
    (pcLatch : PositiveConstancy K.zero K.succ q)
    (base : phi K.zero)
    (step : ∀ n, phi n → phi (K.succ n)) : ∀ n, phi n := by
  have eBase := (code K.zero).mpr base
  have eStep : ∀ n, e n = K.zero → e (K.succ n) = K.zero := by
    intro n hn
    exact (code (K.succ n)).mpr (step n ((code n).mp hn))
  intro n
  exact (code n).mp (K.zero_induction_from_latch e q qZero qSucc pcLatch
    eBase eStep n)

end Kernel

inductive Formula (A : Type u) where
  | atom : (A → A) → (A → A) → Formula A
  | falsum : Formula A
  | conj : Formula A → Formula A → Formula A
  | disj : Formula A → Formula A → Formula A
  | impl : Formula A → Formula A → Formula A

namespace Formula

variable {A : Type u}

def holds : Formula A → A → Prop
  | .atom t v, n => t n = v n
  | .falsum, _ => False
  | .conj f g, n => holds f n ∧ holds g n
  | .disj f g, n => holds f n ∨ holds g n
  | .impl f g, n => holds f n → holds g n

def error (K : Kernel A) : Formula A → A → A
  | .atom t v, n => K.R (t n) (v n)
  | .falsum, _ => K.one
  | .conj f g, n => K.select (error K f n) (error K g n) K.one
  | .disj f g, n => K.select (error K f n) K.zero (error K g n)
  | .impl f g, n => K.select (error K f n) (error K g n) K.zero

theorem error_correct (K : Kernel A) (f : Formula A) (n : A) :
    error K f n = K.zero ↔ holds f n := by
  induction f with
  | atom t v => exact K.difference_zero_iff (t n) (v n)
  | falsum =>
      constructor
      · intro h
        exact K.nontrivial h.symm
      · intro h
        exact False.elim h
  | conj f g hf hg =>
      change K.select (error K f n) (error K g n) K.one = K.zero ↔
        holds f n ∧ holds g n
      cases K.zero_decision (error K f n) with
      | inl hz =>
          rw [hz, K.selector_zero]
          constructor
          · intro h
            exact ⟨hf.mp hz, hg.mp h⟩
          · intro h
            exact hg.mpr h.2
      | inr hn =>
          rw [K.selector_nonzero (error K f n) (error K g n) K.one hn]
          constructor
          · intro h
            exact False.elim (K.nontrivial h.symm)
          · intro h
            exact False.elim (hn (hf.mpr h.1))
  | disj f g hf hg =>
      change K.select (error K f n) K.zero (error K g n) = K.zero ↔
        holds f n ∨ holds g n
      cases K.zero_decision (error K f n) with
      | inl hz =>
          rw [hz, K.selector_zero]
          constructor
          · intro _
            exact Or.inl (hf.mp hz)
          · intro _
            rfl
      | inr hn =>
          rw [K.selector_nonzero (error K f n) K.zero (error K g n) hn]
          constructor
          · intro h
            exact Or.inr (hg.mp h)
          · intro h
            cases h with
            | inl h => exact False.elim (hn (hf.mpr h))
            | inr h => exact hg.mpr h
  | impl f g hf hg =>
      change K.select (error K f n) (error K g n) K.zero = K.zero ↔
        (holds f n → holds g n)
      cases K.zero_decision (error K f n) with
      | inl hz =>
          rw [hz, K.selector_zero]
          constructor
          · intro h _
            exact hg.mp h
          · intro h
            exact hg.mpr (h (hf.mp hz))
      | inr hn =>
          rw [K.selector_nonzero (error K f n) (error K g n) K.zero hn]
          constructor
          · intro _ h
            exact False.elim (hn (hf.mpr h))
          · intro _
            rfl

theorem induction_from_represented_latch (K : Kernel A) (f : Formula A)
    (q : A → A)
    (qZero : q K.zero = K.one)
    (qSucc : ∀ n, q (K.succ n) = K.B (error K f n) (q n))
    (pcLatch : PositiveConstancy K.zero K.succ q)
    (base : holds f K.zero)
    (step : ∀ n, holds f n → holds f (K.succ n)) : ∀ n, holds f n := by
  exact K.induction_of_zero_code (holds f) (error K f) q
    (error_correct K f) qZero qSucc pcLatch base step

end Formula

#print axioms Kernel.difference_zero_iff
#print axioms Kernel.zero_decision
#print axioms Kernel.equality_decision
#print axioms Kernel.constructor_coverage
#print axioms Kernel.zero_induction_from_latch
#print axioms Formula.error_correct
#print axioms Formula.induction_from_represented_latch

end InvolutionKernel
