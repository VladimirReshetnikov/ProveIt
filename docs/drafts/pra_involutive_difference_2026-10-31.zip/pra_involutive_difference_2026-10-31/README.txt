PRA FROM POSITIVE CONSTANCY AND AN INVOLUTIVE DIFFERENCE
Research package prepared for Vladimir Reshetnikov, 31 October 2026
================================================================

RESULT
One common nonlogical basis works for classical and intuitionistic PRA:
  binary primitive-recursive computation D;
  0 != S0;
  positive constancy PC with one fixed numerical parameter;
  R(R(x,y),y)=x for the explicit signed-difference iterator R.

R is not a new primitive or equality oracle. Its six iterator descriptors
are fully specified in AXIOMS.txt and in the paper. Computation gives
R(0,y)=y, so the new fixed axiom immediately proves R(x,y)=0 iff x=y.
The paper proves full bi-interpretability, with both round trips witnessed
by the identity graph, and effective consistency translations.

WHAT IS NEW RELATIVE TO THE CURRENT DRAFTS
The fixed minimum-symmetry bridge is replaced by a shorter involution law.
The fixed equation decreases from 13 to 9 formula-tree nodes; with unchanged
computation, separation, and positive constancy the display decreases
from 63 to 59. The early equality-bootstrap proof becomes three lines.
The selected program descriptions increase from 5 to 49 nodes. Thus this
is an axiom-display and proof-structure improvement, not an absolute
minimum or an improvement under every full encoding-cost measure.

CONTENTS
  pra_involutive_difference.pdf  Compiled research paper.
  pra_involutive_difference.tex  Complete self-contained LaTeX source.
  AXIOMS.txt                    Exact specification without LaTeX.
  formal/                       Lean source certificates and scope notes.
  artifacts/                    Executable diagnostics, metrics, results.
  audit/                        Source manifest, comparisons, proof review,
                                verification records, and build summary.
  Makefile                      Rebuild and verification commands.
  SHA256SUMS.txt                 Checksums of all other package files.

VERIFICATION SCOPE
The linked Lean 4.19.0 endpoint proves one-parameter quantifier-free
induction and decidability over an arbitrary carrier, using actual finite
Term/Formula syntax and the stated computation/PC/Sep/Inv assumptions.
It includes the explicit R descriptor and the stored-parameter latch.
All printed endpoint axiom audits report no axioms. The mathematical
assumptions remain explicit theorem parameters; this does not prove Inv
without assuming it in the weak theory.

Still written rather than fully formalized: ordinary PRA's proof of Inv,
pairing and all-parameter completion, full first-order derivability
translations, and the complete bi-interpretation metatheorem.

Python diagnostics evaluate the actual iterator descriptions; finite
checks do not replace the proofs about nonstandard models. The program
check at bound 64 reports 20,864 assertions and validates dependency order
and the strict update grammar. A separate AST counter reproduces the
formula metrics. The PDF was compiled and visually inspected.

REBUILD
  make pdf
  make diagnostics
  make lean LEAN_BIN=/absolute/path/to/lean

Requires Python 3, a standard TeX installation with latexmk, and Lean 4.19.0
for the formal sources. No Mathlib or Python third-party package is needed
for the included verification scripts. The sources make no network calls.

PROVENANCE
All six current PRA ZIP archives were inspected at ProveIt commit
3af028c8eb45b393331630537c5a94939c536341. The complete incoming README
and directory inventory had no additional PRA archive or relevant entry.
The Lean generic completion is adapted from the inspected minimum-symmetry
certificate, with attribution retained in the source. The new bridge,
its finite signed-difference description, and its linkage are documented.

NO GLOBAL OPTIMALITY CLAIM
The current primitive-equality-bit flat-meet variant has a smaller
57-node formula display, and an older generic delayed-uniqueness display
cited by the drafts has 52. These use different presentations and have
their own descriptor/generator costs. This package makes one matched,
reproducible improvement and gives complete written equivalence proofs.
