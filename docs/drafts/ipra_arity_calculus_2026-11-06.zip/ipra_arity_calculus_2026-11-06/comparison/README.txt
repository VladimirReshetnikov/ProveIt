REPRODUCIBLE COMPARISON OF THE CURRENT iPRA DRAFTS

Snapshot
--------
Repository: VladimirReshetnikov/ProveIt
Commit: 1d1b154fb3f071169b6a003b3f9d727166880006
Directory: docs/drafts

This directory contains exact copies of the five primary acceptance programs
and four companion acceptance programs in the five archives at that commit.
It does not include earlier comparison sources nested inside those archives.

The five downloaded archives were checked against the Git blob SHA-1 values
returned by GitHub. The immutable URLs, archive lengths, archive SHA-256
hashes, member paths, and source SHA-256 hashes are recorded in manifest.json.
The archives themselves are not duplicated here. Every measurement run
rechecks the nine retained source hashes. It parses these sources without
importing or executing them.

Reproduction
------------
From the containing package, run:

    python3 comparison/measure.py

The required candidates are checker.py (strict theorem acceptance) and
checker_open.py (strict open-sequent acceptance). checker_demand.py and
checker_open_demand.py are measured when present. The script writes:

    results/metrics.json
    results/metrics.csv
    results/numbers.tex
    results/comparison_table.tex
    results/core_comparison_table.tex

Load results/numbers.tex before either generated LaTeX table. The tables use
booktabs. Their candidate and envelope entries refer to generated macros,
including CandidateAST, CandidateTokens, CandidateNormTokens, CandidateBytes,
CandidateRaw, EnvelopeAST, EnvelopeTokens, EnvelopeNormTokens, EnvelopeBytes,
and EnvelopeRaw. CandidateOpen..., CandidateDemand..., CandidateOpenDemand...,
CandidateCore..., and CoreEnvelope... macros supply other comparisons.

The script also accepts --candidate-root and --output-dir for review in a
separate staging directory. It uses only the Python standard library and
requires no network access. CPython 3.12.14 was used for recorded results;
AST shapes and ast.unparse formatting can vary across Python releases, so
always measure candidates and references in the same interpreter.

Full-program metric
-------------------
The primary boundary is each entire Python acceptance program, including
imports, syntax tables, substitution, arithmetic, logic, JSON loading,
command-line argument handling, acceptance, and rejection. Only comments
and leading module/function/class docstrings are removed from the primary
measures. Source-token counts ignore comments and whitespace token classes.
Normalized tokens and normalized bytes use ast.unparse of the resulting
syntax tree. Identifier names are not shortened or canonicalized. Executable
AST nodes are all ast.walk nodes, including the module node. Raw byte length
includes the entire original file and is supplementary, as it depends on
formatting and explanatory comments.

The ordinary Python runtime and the standard-library json/sys implementations
are common dependencies and are outside all measured application programs.
No application-specific helper, proof generator, theorem library, recognizer,
or evaluator is omitted from the full-program metric.

The coordinatewise envelope is formed by taking a separate minimum for each
metric. It is calculated both over the five primary programs and over all
nine programs; these two envelopes coincide in this snapshot. All global
minimum coordinates come from the demand-style goal-reconstruction theorem
checker, not from the automatic-introduction program.

Matching acceptance interfaces
------------------------------
A theorem checker starts from an empty hypothesis context and accepts JSON
[goal, proof]. Goals may contain free numerical parameters. An open-sequent
checker accepts [goal, proof, *hypotheses] and validates those external
hypotheses. The extra interface work is included in the full-program count.
These interfaces present the same theory but are distinct acceptance tasks;
the script reports their minima separately.

Strict witness validation checks every supplied numerical witness, including
a witness unused by a vacuous universal binder. Demand validation may ignore
such an unused annotation. Replacing it with numerical zero yields a strict
certificate for the same well-formed sequent; no additional theorem results.
This distinction is explicit in the manifest and in each comparison row.

For each candidate the script reports (1) comparison with the all-program
coordinatewise minimum, and (2) comparison against the minimum with the same
interface and witness policy. A strict theorem candidate is allowed to beat
the smaller demand-theorem reference: it performs more syntax checking.
A theorem-only reduction is not presented as an unchanged open-sequent
interface. A strict open-sequent candidate has a separate comparison against
both strict open references. The demand open candidate is separately compared
against the demand open references. All measured variants have the same
well-formed theorem sets, as proved in the report; source size alone does not
establish that fact.

Uniform core-only supplement
----------------------------
The supplemental measurement deletes exactly two sorts of top-level nodes
from every stripped program: import statements, and the conventional
if __name__ == '__main__' block. Every other top-level item and its contents
remain. In these programs this keeps SCOPES, subst, and every check/infer
function, including any helpers or wrappers present. No hand-selected rule
branch is removed. Both source and normalized token counts are recomputed;
AST and normalized byte counts are also supplied. No raw-byte count is
assigned to an extracted core.

This is evidence that the improvement survives removal of the input/output
layer. It is not substituted for the complete-program result: the core's
internal function contract may assume validated contexts, and the original
CLI validation is still required for acceptance of arbitrary input files.
The strict theorem and strict open candidates have identical cores; the two
demand candidates likewise share one core.

Recorded CPython 3.12.14 values
-----------------------------
All-program envelope:
    582 AST nodes, 569 source tokens, 569 normalized tokens,
    1762 normalized bytes, 1852 raw bytes.
Strict theorem candidate:
    578 AST nodes, 561 source tokens, 563 normalized tokens,
    1746 normalized bytes, 1823 raw bytes.
All-reference core envelope:
    508 AST nodes, 498 source tokens, 500 normalized tokens,
    1440 normalized bytes.
Strict candidate core:
    505 AST nodes, 496 source tokens, 498 normalized tokens,
    1434 normalized bytes.

The script fails if the main strict theorem program no longer beats the
all-program envelope, if its core no longer beats the core envelope, or if
any included candidate no longer beats the corresponding matched-interface
and matched-witness-policy envelope. The global comparison of the larger
open interface is recorded, not required to beat theorem-only programs.

Interpretation of the result
----------------------------
This is a finite, runtime-relative, reproducible reduction below the current
corpus. It is not an absolute lower bound or a theorem that the candidate is
the shortest possible checker. All bytes remain inspectable. Mathematical
soundness, completeness, and bi-interpretability are separate proof
obligations addressed in the report and its validation artifacts.
