"""Reproduce full-program and supplemental core-only size comparisons.

The reference sources are parsed, never imported or executed. The default
candidate directory is this comparison directory's parent, and results are
written to its results/ directory. No network access or nonstandard module
is used. Comments and leading docstrings are the only omitted source text
in the primary (whole-program) comparison.
"""
from pathlib import Path
import argparse
import ast
import csv
import hashlib
import io
import json
import platform
import sys
import tokenize

HERE = Path(__file__).resolve().parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes',
          'normalized_bytes', 'raw_bytes')
CORE_FIELDS = FIELDS[:-1]
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}
MACRO_FIELDS = {
    'ast_nodes': 'AST', 'source_tokens': 'Tokens',
    'normalized_tokens': 'NormTokens', 'normalized_bytes': 'Bytes',
    'raw_bytes': 'Raw',
}
CANDIDATES = (
    ('strict_theorem', 'checker.py', 'theorem', 'strict',
     'New strict theorem checker', 'Candidate', True),
    ('strict_open', 'checker_open.py', 'open-sequent', 'strict',
     'New strict open checker', 'CandidateOpen', True),
    ('demand_theorem', 'checker_demand.py', 'theorem', 'demand',
     'New demand theorem checker', 'CandidateDemand', False),
    ('demand_open', 'checker_open_demand.py', 'open-sequent', 'demand',
     'New demand open checker', 'CandidateOpenDemand', False),
)


def is_main_guard(node):
    """Recognize only the conventional top-level command-line guard."""
    return (
        isinstance(node, ast.If)
        and isinstance(node.test, ast.Compare)
        and isinstance(node.test.left, ast.Name)
        and node.test.left.id == '__name__'
        and len(node.test.ops) == len(node.test.comparators) == 1
        and isinstance(node.test.ops[0], ast.Eq)
        and isinstance(node.test.comparators[0], ast.Constant)
        and node.test.comparators[0].value == '__main__'
    )


def source_span(node):
    """Include any decorators when retaining a top-level definition."""
    first = min([node.lineno]
                + [d.lineno for d in getattr(node, 'decorator_list', [])])
    return ((first, 0), (node.end_lineno, node.end_col_offset))


def measure(path):
    """Return exact whole-file metrics and the uniformly extracted core."""
    raw = Path(path).read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    doc_spans = []
    for node in ast.walk(tree):
        if (isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                              ast.AsyncFunctionDef))
                and node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            doc = node.body.pop(0)
            doc_spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))

    def contains(span, token):
        start, end = span
        return start <= token.start and token.end <= end

    def count(text, omitted=(), retained=None):
        return sum(
            token.type not in IGNORED
            and not any(contains(span, token) for span in omitted)
            and (retained is None
                 or any(contains(span, token) for span in retained))
            for token in tokenize.generate_tokens(io.StringIO(text).readline)
        )

    normalized = ast.unparse(tree) + '\n'
    # Keep every other top-level item, not only a selected list of functions.
    # Thus all syntax tables, definitions, helpers, and checks remain counted.
    core_body = [node for node in tree.body
                 if not isinstance(node, (ast.Import, ast.ImportFrom))
                 and not is_main_guard(node)]
    core = ast.Module(body=core_body, type_ignores=[])
    core_normalized = ast.unparse(core) + '\n'
    retained = [source_span(node) for node in core_body]
    return {
        'sha256': hashlib.sha256(raw).hexdigest(),
        'source_tokens': count(source, doc_spans),
        'normalized_tokens': count(normalized),
        'ast_nodes': sum(1 for _ in ast.walk(tree)),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'raw_bytes': len(raw),
        'core': {
            'source_tokens': count(source, doc_spans, retained),
            'normalized_tokens': count(core_normalized),
            'ast_nodes': sum(1 for _ in ast.walk(core)),
            'normalized_bytes': len(core_normalized.encode('utf-8')),
        },
    }


def envelope(rows, fields=FIELDS):
    if not rows:
        raise ValueError('Cannot compare against an empty reference class')
    return {key: min(row[key] for row in rows) for key in fields}


def below(row, target):
    return {key: row[key] < value for key, value in target.items()}


def emit_numbers(result, destination):
    lines = ['% Generated by comparison/measure.py; do not edit by hand.']

    def number(name, value):
        lines.append('\\newcommand{\\' + name + '}{' + str(value) + '}')

    def group(prefix, row):
        for field, suffix in MACRO_FIELDS.items():
            if field in row:
                number(prefix + suffix, row[field])

    number('BaselineArchiveCount', result['baseline_archive_count'])
    number('BaselineProgramCount', len(result['baselines']))
    number('BaselinePrimaryCount', sum(r['role'] == 'primary'
                                       for r in result['baselines']))
    group('Envelope', result['envelope'])
    group('PrimaryEnvelope', result['primary_envelope'])
    group('CoreEnvelope', result['core_envelope'])
    group('OpenEnvelope', result['interface_envelopes']['open-sequent'])
    for name, prefix in (
        ('strict_theorem', 'TheoremStrictEnvelope'),
        ('strict_open', 'OpenStrictEnvelope'),
        ('demand_theorem', 'TheoremDemandEnvelope'),
        ('demand_open', 'OpenDemandEnvelope'),
    ):
        group(prefix, result['matched_envelopes'][name])
    for name, row in result['candidates'].items():
        prefix = row['macro_prefix']
        group(prefix, row)
        group(prefix + 'Core', row['core'])
        if name == 'strict_theorem':
            # Both aliases are supplied for prose that leads with "core".
            group('CoreCandidate', row['core'])
            for key, suffix in MACRO_FIELDS.items():
                saving = 100 * (result['envelope'][key] - row[key]) / result['envelope'][key]
                number(prefix + suffix + 'Reduction', f'{saving:.2f}\\%')
            for key, value in row['core'].items():
                saving = 100 * (result['core_envelope'][key] - value) / result['core_envelope'][key]
                number('CoreCandidate' + MACRO_FIELDS[key] + 'Reduction',
                       f'{saving:.2f}\\%')
    (destination / 'numbers.tex').write_text('\n'.join(lines) + '\n')


def emit_table(result, destination, core=False):
    lines = [
        '% Generated by comparison/measure.py. Load results/numbers.tex first.',
        '\\begin{table}[htbp]', '\\centering\\small',
        '\\begin{tabular}{@{}lrrrr@{}}', '\\toprule',
        'Complete program & AST & Source tokens & Norm. tokens & Norm. bytes\\\\',
        '\\midrule',
    ]
    if core:
        lines[5] = 'Core, with imports and CLI removed & AST & Source tokens & Norm. tokens & Norm. bytes\\\\'
    fields = ('ast_nodes', 'source_tokens', 'normalized_tokens', 'normalized_bytes')
    for row in result['baselines']:
        values = row['core'] if core else row
        lines.append(row['label'] + ' & '
                     + ' & '.join(f'{values[key]:,}' for key in fields)
                     + '\\\\')
    prefix = 'CoreEnvelope' if core else 'Envelope'
    lines += [
        '\\midrule',
        '\\textbf{All nine: coordinatewise minimum} & '
        + ' & '.join('\\textbf{\\' + prefix + MACRO_FIELDS[key] + '}'
                     for key in fields) + '\\\\',
    ]
    for name, row in result['candidates'].items():
        # The theorem/open variants have identical cores, so print each core once.
        if core and row['interface'] != 'theorem':
            continue
        prefix = row['macro_prefix'] + ('Core' if core else '')
        label = ('New strict core' if row['witness_validation'] == 'strict'
                 else 'New demand core') if core else row['label']
        lines.append('\\textbf{' + label + '} & '
                     + ' & '.join('\\textbf{\\' + prefix + MACRO_FIELDS[key] + '}'
                                  for key in fields) + '\\\\')
    lines += ['\\bottomrule', '\\end{tabular}']
    if core:
        lines += [
            '\\caption{Supplemental core comparison. The same transformation removes',
            'only top-level imports and the command-line block from every program.',
            'All syntax tables and functions remain. The theorem and open variants',
            'of each new checker have identical cores.}',
            '\\label{tab:core-comparison}',
        ]
    else:
        lines += [
            '\\caption{Whole-program measurements of all five current primary checkers',
            'and all four companions. Imports, syntax checking, arithmetic, logic,',
            'JSON input, and rejection are counted. The theorem and open interfaces',
            'and strict versus demand witness validation are distinguished explicitly.}',
            '\\label{tab:comparison}',
        ]
    lines.append('\\end{table}')
    filename = 'core_comparison_table.tex' if core else 'comparison_table.tex'
    (destination / filename).write_text('\n'.join(lines) + '\n')


def emit_csv(result, destination):
    columns = ['kind', 'label', 'scope', 'interface', 'witness_validation',
               'source', 'sha256', *FIELDS]
    with (destination / 'metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        for kind, rows in [('baseline', result['baselines']),
                           ('candidate', result['candidates'].values())]:
            for row in rows:
                writer.writerow(dict(row, kind=kind, scope='whole'))
                core_row = {key: row[key] for key in columns if key in row
                            and key not in FIELDS}
                writer.writerow(dict(core_row, **row['core'], kind=kind, scope='core'))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-root', type=Path, default=HERE.parent,
                        help='directory containing the checker variants')
    parser.add_argument('--output-dir', type=Path, default=None,
                        help='defaults to candidate-root/results')
    args = parser.parse_args(argv)
    root = args.candidate_root.resolve()
    destination = (args.output_dir.resolve() if args.output_dir
                   else root / 'results')
    manifest = json.loads((HERE / 'manifest.json').read_text())
    baselines = []
    for entry in manifest['programs']:
        measured = measure(HERE / entry['source'])
        if measured['sha256'] != entry['source_sha256']:
            raise ValueError('Modified baseline: ' + entry['source'])
        row = dict(entry, **measured)
        row['source'] = 'comparison/' + entry['source']
        baselines.append(row)
    matched = {}
    for name, _, interface, validation, _, _, _ in CANDIDATES:
        matched[name] = envelope([r for r in baselines
                                  if r['interface'] == interface
                                  and r['witness_validation'] == validation])
    candidates = {}
    for name, filename, interface, validation, label, macro, required in CANDIDATES:
        path = root / filename
        if not path.is_file():
            if required:
                raise FileNotFoundError('Required checker missing: ' + str(path))
            continue
        candidates[name] = dict(
            source=filename, label=label, macro_prefix=macro, interface=interface,
            witness_validation=validation, **measure(path),
        )
    result = {
        'schema_version': 1,
        'repository': manifest['repository'],
        'commit': manifest['commit'],
        'python': sys.version,
        'python_version': platform.python_version(),
        'baseline_archive_count': len(manifest['archives']),
        'boundaries': {
            'whole': 'Entire Python acceptance program, including imports, syntax tables, substitution, arithmetic, logic, JSON/CLI, and rejection. Only comments and leading docstrings are omitted from primary metrics; raw bytes include them.',
            'core': 'Supplemental only: remove top-level imports and the __name__ == __main__ command-line block identically from every program; keep every other top-level item and all its contents. The same comment/docstring convention is then applied. No raw-byte metric is assigned to an extracted core.',
            'runtime': 'All programs use the same Python runtime and standard-library json/sys modules. Runtime and standard-library implementation sizes are not measured.',
        },
        'baselines': baselines,
        'envelope': envelope(baselines),
        'primary_envelope': envelope([r for r in baselines if r['role'] == 'primary']),
        'core_envelope': envelope([r['core'] for r in baselines], CORE_FIELDS),
        'interface_envelopes': {
            interface: envelope([r for r in baselines if r['interface'] == interface])
            for interface in ('theorem', 'open-sequent')
        },
        'matched_envelopes': matched,
        'candidates': candidates,
    }
    result['strictly_below'] = {
        name: below(row, result['envelope']) for name, row in candidates.items()
    }
    result['core_strictly_below'] = {
        name: below(row['core'], result['core_envelope'])
        for name, row in candidates.items()
    }
    result['matched_strictly_below'] = {
        name: below(row, matched[name]) for name, row in candidates.items()
    }
    result['gates'] = {
        'strict_theorem_below_all_complete_programs':
            all(result['strictly_below']['strict_theorem'].values()),
        'strict_core_below_all_reference_cores':
            all(result['core_strictly_below']['strict_theorem'].values()),
        'all_present_variants_below_matched_boundaries':
            all(all(values.values())
                for values in result['matched_strictly_below'].values()),
    }
    destination.mkdir(parents=True, exist_ok=True)
    (destination / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    emit_csv(result, destination)
    emit_numbers(result, destination)
    emit_table(result, destination)
    emit_table(result, destination, core=True)
    print(json.dumps({
        'status': 'passed' if all(result['gates'].values()) else 'failed',
        'baseline_programs': len(baselines),
        'envelope': result['envelope'], 'core_envelope': result['core_envelope'],
        'candidates': {name: {key: row[key] for key in FIELDS}
                       for name, row in candidates.items()},
        'gates': result['gates'],
    }, indent=2))
    if not all(result['gates'].values()):
        raise ValueError('A reported size-reduction claim no longer holds')
    return result


if __name__ == '__main__':
    main()
