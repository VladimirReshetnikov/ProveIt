"""Regenerate the checksum manifest and deliverable ZIP archive."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {'.aux', '.log', '.out', '.toc', '.pyc', '.fls', '.fdb_latexmk'}


def members():
    return sorted(p for p in ROOT.rglob('*')
                  if p.is_file() and '__pycache__' not in p.parts
                  and p.suffix not in EXCLUDED_SUFFIXES
                  and p.name != 'MANIFEST.sha256')


def main():
    paths = members()
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' +
                                p.relative_to(ROOT).as_posix() + '\n' for p in paths))
    archive = ROOT.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted([*paths, manifest]):
            output.write(path, (Path(ROOT.name) / path.relative_to(ROOT)).as_posix())
    print(str(archive))


if __name__ == '__main__':
    main()
