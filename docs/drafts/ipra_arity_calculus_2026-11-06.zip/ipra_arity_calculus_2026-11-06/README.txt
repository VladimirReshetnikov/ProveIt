A SMALLER COMPLETE PRESENTATION OF iPRA
Proofs as premise trees
Prepared for Vladimir Reshetnikov -- 6 November 2026

RESULT

The supplied calculus presents full first-order intuitionistic primitive
recursive arithmetic. report.pdf gives every logical and arithmetic rule,
derives the standard logical connectives and quantifier-free induction,
and proves bi-interpretability with iPRA using the whole number domain.
Both composite interpretations are internally isomorphic by identity.

The smallest supplied checker is checker_demand.py. The recommended default
checker.py additionally validates every witness of an active inference,
including witnesses of unused universal binders. Both beat the minimum of
the current complete programs in every declared size measure.

                                     AST    Source   Norm.    Norm.    Raw
                                    nodes   tokens  tokens    bytes   bytes
Current all-program lower envelope    582      569      569     1762    1852
New strict theorem checker            578      561      563     1746    1823
New demand theorem checker            566      551      553     1701    1788
New strict open-sequent checker        602      578      580     1805    1867
New demand open-sequent checker        590      568      570     1760    1847

The strict open-sequent checker also beats the current open-sequent envelope
of 605 AST nodes, 580 source tokens, 582 normalized tokens, 1811 normalized
bytes, and 1879 raw bytes. Its interface still validates external assumptions.

Supplementary comparison removes imports and CLI code identically from every
program. The strict core has 505 AST nodes / 496 source tokens / 498 normalized
tokens / 1434 normalized bytes. The corresponding current minima are
508 / 498 / 500 / 1440. The reduction therefore survives removal of I/O.

The new proof representation uses [q] for automatic guarded introduction,
[t,q] for existential introduction, and [] for one computation equation.
Formula-headed arrays handle elimination; null is the canonical hypothesis
leaf. The goal and certificate shape supply the omitted labels. This combines
the automatic-introduction theorem with the theorem interface and hypothesis
membership from the goal-reconstruction draft. The arithmetic basis is
inherited and credited. No universal PR evaluator or external theorem table
is hidden outside the measured checker.

This is a strict finite-corpus improvement, not an absolute minimality theorem.
The metatheory is proved in the article; it is not claimed to be fully
formalized in Lean or Rocq. The improvement is modest because the current
frontier is already very small.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 1d1b154fb3f071169b6a003b3f9d727166880006
Directory: docs/drafts

All five current archives and all nine top-level complete checkers were
inspected. The comparison uses their current code, not the older numbers
quoted by their embedded reports. Exact original sources, archive identities,
and SHA-256 hashes are included in comparison/. No repository write or
publication was performed.

START HERE

  report.pdf                    Complete article.
  report.tex, sections/*.tex     Complete LaTeX sources.
  checker.py                    Recommended strict theorem checker.
  checker_demand.py             Smallest supplied complete theorem checker.
  checker_open.py               Strict open-sequent checker.
  checker_open_demand.py        Demand open-sequent checker.
  FORMAT.txt                    Exact syntax and certificate conventions.
  examples/                     Nineteen ready-to-run theorem certificates.
  translate.py                  Forward/backward certificate conversions.
  automatic_compiler.py         Untrusted zero-detour compiler.
  comparison/                   Fixed baseline sources and measurements.
  validation/                   Independent named-variable oracle and audits.
  results/                      Executed metrics and validation records.
  reproduce.py                  Reproduce all measurements and audits.
  build.py                      Rebuild report.pdf.
  package.py                    Regenerate checksums and ZIP.
  MANIFEST.sha256               Hashes of every other delivered file.
  LICENSE_SOURCE.txt            License for inherited sources/documentation.

RUN

Python 3.10 or later is required. Recorded size metrics use CPython 3.12.14.
All Python artifacts use only the standard library and run offline.

  python3 reproduce.py
  python3 checker.py examples/residual.json
  python3 checker.py examples/closed_automatic_collision.json
  python3 checker_demand.py examples/reflexivity.json

The theorem programs accept [goal,proof] and begin with an empty assumption
context. The open-sequent programs accept [goal,proof,H0,...,Hn] and validate
all external formulas. Free number variables are permitted as parameters.

A demand checker may ignore a malformed numerical witness only when a used
universal inference does not use that number in either guard or consequent.
Replacing the irrelevant field by zero gives a strict proof of the same
sequent. Context-membership fallback may ignore an inactive proof payload;
it cannot establish a formula absent from the context. FORMAT.txt describes
the exact clause order. Every used expression and every public formula is
validated. Interpreter resource exhaustion rejects; completeness is stated
for ideal unbounded finite-tree execution.

Rebuild the article with an installed TeX distribution:

  python3 build.py

Rebuild the ZIP and hashes after intentional changes:

  python3 package.py

EXECUTED EVIDENCE

- Nine unchanged baseline-source hashes verified at each measurement run.
- Nineteen inherited certificates translated in both directions.
- Five source sequents closed by guarded abstraction and the zero detour.
- Twenty-four source reconstructions accepted by the strict predecessor.
- Three thousand seeded mutation trials; all 169 accepted mutants
  reconstructed into accepted strict predecessor proofs.
- Independent named-variable oracle: 19 theorem examples, 96 direct rule
  cases, 72 malformed syntax/context cases, 2000 theorem mutations, 4000
  arbitrary JSON documents, and 2000 random open sequents; no disagreements.
- Four thousand binding transformations compared with named semantics.
- 130 isolated public CLI cases across all four variants, including
  optimized Python, malformed input, interface arity, witness strictness,
  and rejection of 0 = S0.

These finite suites overlap. They complement the written proofs and do not
constitute an exhaustive or machine-checked proof of checker correctness.
