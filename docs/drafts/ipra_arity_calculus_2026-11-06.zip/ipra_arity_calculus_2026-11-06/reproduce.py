"""Reproduce the current-source comparison and all delivered validation offline."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    manifest = json.loads((ROOT / 'source_manifest.json').read_text())
    for entry in manifest['files']:
        observed = hashlib.sha256((ROOT / entry['path']).read_bytes()).hexdigest()
        if observed != entry['sha256']:
            raise ValueError('Changed source fixture: ' + entry['path'])
    steps = ['comparison/measure.py', 'validation.py',
             'validation/differential_audit.py', 'validation/boundary_audit.py']
    for script in steps:
        result = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT,
                                capture_output=True, text=True)
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
        print('PASS ' + script)
    summary = {'status': 'passed', 'steps': steps,
               'source_fixture_hashes_verified': len(manifest['files']),
               'python': sys.version}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('All measurements and audits passed.')


if __name__ == '__main__':
    main()
