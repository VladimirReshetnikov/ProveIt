"""Exercise the actual public process boundary of all four supplied kernels."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    variants = ['checker.py', 'checker_demand.py', 'checker_open.py',
                'checker_open_demand.py']
    counts = {name: 0 for name in variants}
    true = ['=', -1, -1]
    false = ['=', -1, ['s', -1]]
    vacuous = ['pi', true, true]
    reflexivity = json.loads((ROOT / 'examples/reflexivity.json').read_text())

    with tempfile.TemporaryDirectory(prefix='ipra-boundary-') as directory:
        path = Path(directory) / 'input.json'

        def run(name, data, expected, raw=False, optimized=False):
            path.write_text(data if raw else json.dumps(data), encoding='utf-8')
            flags = ['-I', '-S', *(['-O'] if optimized else [])]
            result = subprocess.run([sys.executable, *flags, str(ROOT / name), str(path)],
                                    text=True, capture_output=True)
            assert result.returncode == (0 if expected else 1), (name, data, result)
            assert result.stdout.strip() == ('ACCEPT' if expected else 'REJECT'), (name, result)
            counts[name] += 1

        for name in variants:
            for fixture in sorted((ROOT / 'examples').glob('*.json')):
                run(name, json.loads(fixture.read_text()), True)
            run(name, reflexivity, True, optimized=True)
            for data in [[false, None], [true, None], [true], [], None,
                         [['=', False, -1], None], [['=', 0.0, -1], None],
                         [['=', -2, -1], None]]:
                run(name, data, False)
            run(name, '{', False, raw=True)
            run(name, '[NaN,null]', False, raw=True)
            if '_open' in name:
                run(name, [true, None, true], True)
                run(name, [true, None, true, ['=', False, -1]], False)
                witness_proof = [vacuous, None, None, None]
                run(name, [true, witness_proof, vacuous, true], 'demand' in name)
            else:
                run(name, [true, None, true], False)
                run(name, [*reflexivity, true], False)

    result = {'status': 'passed', 'public_cli_cases': counts,
              'total_public_cli_cases': sum(counts.values()),
              'python': sys.version,
              'kernel_sha256': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                                for name in variants},
              'boundary': 'actual isolated subprocess, stdout and exit status'}
    (ROOT / 'results/boundary_audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
