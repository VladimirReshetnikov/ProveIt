INDEPENDENT ACCEPTANCE AUDIT

Subject: automatic-introduction iPRA checker with untagged certificates,
empty-list computation, and hypothesis membership.

The oracle is independent of the production mechanism.  It parses raw de
Bruijn syntax into seven named constructors.  Each introduced binder and each
opened eigenvariable receives a fresh Name.  Numerical substitution is then
ordinary simultaneous substitution of terms for names, with separate
alpha-equivalence.  The compact checker instead performs validation, lifting,
and parallel substitution in one recursive index traversal.  No part of the
oracle imports that traversal or a production proof builder.

FORMAL CONTROL-FLOW CHECK

1. Formula and term syntax.
   Each accepted goal and every supplied context formula has the exact native
   grammar.  Integers are exact Python ints; bools and floats are not terms.
   The integer -1 denotes zero and nonnegative integers denote variables.
   The recursion update is validated even at counter zero.  Constructor arity
   and the term/formula distinction are checked at every node.

   The compact validator destructures arbitrary Python iterables, whereas the
   oracle explicitly requires arrays.  This does not expand accepted finite
   JSON syntax: non-array JSON strings or object keys only produce further
   strings, never a valid integer term leaf.  None, Boolean, and floating
   values fail immediately.  At arrays, exact constructor lookup and strict
   arity checking give the displayed grammar by induction on the tree.

2. Binder opening.
   The parser environment lists current eigenvariables followed by enclosing
   local binders in de Bruijn order; original free parameters are canonical
   names indexed independently of binder count.  In the named checker, adding
   an eigenvariable therefore leaves the meaning of all context formulas
   unchanged.  An explicit proof annotation is interpreted in the extended
   environment.  The named method independently checks the production rule
   that all retained context formulas and an existential-elimination target
   must be lifted.

3. Automatic introduction.
   The numerical branch is selected precisely when the named guard is
   alpha-equivalent to the body's zero instance with the outer slot retained.
   This is the same test as literal equality of the corresponding de Bruijn
   trees.  Only a literal equality body receives the current body as induction
   hypothesis.  A compound body receives its zero instance.  Other guards use
   ordinary implication/universal introduction.

4. Guarded elimination and fallback.
   A well-formed elimination major that is not established makes the pattern
   guard false; execution may then succeed by hypothesis membership.  This is
   a genuine Hyp proof of the requested formula and is sound.  A malformed
   major causes an exception, which rejects the entire document.  Once the
   major succeeds, wrong elimination arity or a malformed used motive/witness
   also rejects, even if the requested formula occurs in the context.

   Thus the accepted certificate language intentionally permits arbitrary
   inactive payloads at Hyp leaves.  The audit does not claim that every
   malformed proof payload is rejected.  It checks that every accepted target
   is established by an actual active inference or by Hyp.

5. Arithmetic computation.
   A zero recursor has its initializer as reduct.  A successor recursor is
   reduced by simultaneous substitution for previous value and previous
   counter.  An opaque variable counter does not satisfy the computation
   case.  In particular, malformed updates and a variable counter cannot be
   hidden under the empty computation certificate.

6. Witness policy.
   The main checker validates universal witnesses even when unused, and always
   validates existential witnesses.  The companion demand variant may ignore
   a universal witness only when neither guard nor body contains its bound
   variable.  This distinction is exercised by direct regression cases; it
   changes accepted certificate payloads, not the native theorem set.

WHAT THE EXECUTABLE EVIDENCE ESTABLISHES

The reported run compares complete theorem fixtures, independently specified
positive and negative rule cases, malformed term/formula/context cases,
named-variable meanings of four kinds of binding transformation, theorem
mutations, arbitrary JSON documents, and open-sequent payloads.  The JSON
report records exact checker and oracle hashes and the random seed.

These finite checks are evidence about the implementation, not an exhaustive
enumeration of finite JSON trees and not a formalized proof of soundness or
bi-interpretability.  The metatheorems require the mathematical arguments in
the report.  Runtime recursion or memory limits may reject otherwise valid
certificates; they do not create an acceptance path.
