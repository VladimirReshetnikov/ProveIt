"""Reproduce independent checks of the automatic iPRA certificate checker.

No oracle routine delegates to the production substitution or proof checker.
The production code is imported only as the subject being compared.  The
arithmetic examples are input fixtures, not additional acceptance axioms.
"""

import argparse
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import sys

import independent_oracle as ref


HERE = Path(__file__).resolve().parent
SEED = 2026110602


def load_module(path):
    spec = importlib.util.spec_from_file_location("subject_checker", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def target_sequent(module, goal, proof, assumptions=()):
    try:
        for formula in assumptions:
            module.subst(formula)
        return module.check(goal, proof, list(assumptions)) is True
    except Exception:
        return False


def target_document(module, document):
    try:
        return module.check(*document, []) is True
    except Exception:
        return False


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def raw(expression, environment=()):
    """Encode named syntax, independently of the target's substitution."""
    if isinstance(expression, ref.Zero):
        return -1
    if isinstance(expression, ref.Var):
        if expression.name in environment:
            return environment.index(expression.name)
        if expression.name.kind == 0:
            return expression.name.index + len(environment)
        raise AssertionError("escaping private name")
    if isinstance(expression, ref.Succ):
        return ["s", raw(expression.value, environment)]
    if isinstance(expression, ref.Rec):
        inner = (expression.previous, expression.index) + environment
        return ["r", raw(expression.counter, environment),
                raw(expression.initial, environment), raw(expression.update, inner)]
    if isinstance(expression, ref.Eq):
        return ["=", raw(expression.left, environment), raw(expression.right, environment)]
    if isinstance(expression, ref.Pi):
        inner = (expression.variable,) + environment
        return ["pi", raw(expression.guard, inner), raw(expression.body, inner)]
    if isinstance(expression, ref.Exists):
        return ["ex", raw(expression.body, (expression.variable,) + environment)]
    raise AssertionError("unknown expression")


def tree_paths(tree, path=()):
    yield path
    if type(tree) is list:
        for index, child in enumerate(tree):
            yield from tree_paths(child, path + (index,))
    elif type(tree) is dict:
        for key, child in tree.items():
            yield from tree_paths(child, path + (key,))


def replace(tree, path, value):
    if not path:
        return value
    result = tree.copy()
    result[path[0]] = replace(tree[path[0]], path[1:], value)
    return result


def random_term(rng, depth=3):
    if depth == 0 or rng.randrange(3) == 0:
        return rng.choice([-1, 0, 1, 2, 3, 4, 9])
    if rng.randrange(2) == 0:
        return ["s", random_term(rng, depth - 1)]
    return ["r", random_term(rng, depth - 1), random_term(rng, depth - 1),
            random_term(rng, depth - 1)]


def random_formula(rng, depth=3):
    if depth == 0 or rng.randrange(3) == 0:
        return ["=", random_term(rng, 2), random_term(rng, 2)]
    if rng.randrange(2) == 0:
        return ["ex", random_formula(rng, depth - 1)]
    return ["pi", random_formula(rng, depth - 1), random_formula(rng, depth - 1)]


JSON_ATOMS = [None, False, True, -3, -2, -1, 0, 1, 2, 0.0, -1.0, 1.0,
              "", "r", "s", "=", "pi", "ex", "lam", "pack", "unknown"]


def random_json(rng, depth=3):
    if depth == 0 or rng.randrange(3) == 0:
        return deepcopy(rng.choice(JSON_ATOMS))
    if rng.randrange(5) == 0:
        return {str(index): random_json(rng, depth - 1)
                for index in range(rng.randrange(4))}
    return [random_json(rng, depth - 1) for _ in range(rng.randrange(6))]


def branch_fixtures():
    """Cases whose expected outcomes are justified directly by the rules."""
    true = ["=", -1, -1]
    false = ["=", -1, ["s", -1]]
    result = []

    def add(name, goal, proof, context, expected, demand=None):
        result.append(dict(name=name, goal=goal, proof=proof, assumptions=context,
                           strict=expected, demand=expected if demand is None else demand))

    for number, payload in enumerate(JSON_ATOMS + [{}, {"unused": [1, 2]}, [], [None]]):
        add("hyp_payload_%02d" % number, true, payload, [true], True)
        add("no_hyp_payload_%02d" % number, true, payload, [], False)
    add("failed_major_falls_back", true, [false, None], [true], True)
    add("failed_major_ignores_tail", true, [false, None, {}, None, None], [true], True)
    add("failed_major_without_hyp", true, [false, None], [], False)
    add("successful_major_wrong_arity", true, [true, None], [true], False)
    add("malformed_major_is_fatal", true, [["=", False, -1], None], [true], False)
    add("malformed_major_tag_is_fatal", true, [["s", -1], None], [true], False)
    add("malformed_major_extra_child", true, [["=", -1, -1, -1], None], [true], False)

    # Introducing a parameter: the original free parameter shifts to index 1.
    exists = ["ex", ["=", 0, 1]]
    add("exists_free_witness", exists, [0, None], [], True)
    add("exists_wrong_witness", exists, [["s", 0], None], [], False)
    for number, witness in enumerate([False, True, -2, 0.0, None, [], {}, ["s"], ["s", -1, -1]]):
        add("malformed_exists_witness_%02d" % number,
            ["ex", true], [witness, None], [true], False)

    major = ["ex", true]
    add("exists_elimination", true, [major, None, None], [major], True)
    add("exists_wrong_elimination_arity", true, [major, None, None, None], [major], False)
    escape = ["ex", ["=", 0, 1]]
    add("exists_eigenvariable_escape", ["=", 0, 1], [escape, None, None], [escape], False)
    add("exists_retains_outer_assumption", ["=", 0, 1], [major, None, None],
        [["=", 0, 1], major], True)

    add("pi_ordinary_identity", ["pi", ["=", 0, 1], ["=", 0, 1]], [None], [], True)
    add("pi_eigenvariable_escape", ["pi", ["=", 0, 1], ["=", 1, 2]], [None], [], False)
    add("pi_wrong_induction", ["pi", true, ["=", 0, -1]], [None], [], False)
    add("pi_vacuous_collision", ["pi", true, true], [None], [], True)
    vacuous = ["pi", true, true]
    for number, witness in enumerate([False, True, -2, 0.0, None, [], {}, ["s"]]):
        add("unused_universal_witness_%02d" % number,
            true, [vacuous, None, witness, None], [vacuous, true], False, True)
    used = ["pi", true, ["=", 0, 1]]
    add("pi_witness_substitution", ["=", ["s", 0], 0],
        [used, None, ["s", 0], None], [used, true], True)
    add("pi_witness_capture", ["=", ["s", 0], 1],
        [used, None, ["s", 0], None], [used, true], False)

    equality = ["=", 0, ["s", 0]]
    add("equality_transport", ["=", ["s", 0], -1],
        [equality, None, ["=", 0, -1], None], [equality, ["=", 0, -1]], True)
    add("equality_motive_wrong_sort", true,
        [true, None, ["s", -1], None], [true], False)
    add("equality_motive_boolean", true,
        [true, None, ["=", False, -1], None], [true], False)

    add("recursor_zero", ["=", ["r", -1, 0, ["s", 0]], 0], [], [], True)
    add("recursor_zero_bad_update", ["=", ["r", -1, 0, False], 0], [], [], False)
    add("recursor_step_previous", ["=", ["r", ["s", 0], -1, ["s", 0]],
                                   ["s", ["r", 0, -1, ["s", 0]]]], [], [], True)
    add("recursor_step_counter", ["=", ["r", ["s", 0], -1, 1], 0], [], [], True)
    opaque = ["=", ["r", 0, -1, 0], -1]
    add("opaque_counter_rejects_computation", opaque, [], [opaque], False)
    add("opaque_counter_can_be_hypothesis", opaque, None, [opaque], True)

    # A deeply bound motive makes equality substitution cross Pi, E, and R.
    oracle = ref.Oracle()
    hole = oracle.fresh()
    template = ["pi", ["=", 1, 2],
                ["ex", ["=", ["r", 2, 1, ["s", ["r", 0, 4, 5]]], 3]]]
    named_template = oracle.formula(template, (hole,))
    left = oracle.term(0)
    right = oracle.term(["s", 0])
    premise = raw(ref.substitute(named_template, {hole: left}))
    conclusion = raw(ref.substitute(named_template, {hole: right}))
    add("transport_nested_pi_ex_rec", conclusion,
        [equality, None, template, None], [equality, premise], True)
    return result


def binding_audit(module, rng, count=1000):
    """Compare index arithmetic with independent named-variable semantics."""
    for _ in range(count):
        oracle = ref.Oracle()
        external = tuple(oracle.fresh() for _ in range(rng.randrange(4)))
        expression = random_formula(rng)
        named = oracle.formula(expression, external)
        new = oracle.fresh()
        lifted = module.subst(expression)
        assert ref.same(named, oracle.formula(lifted, (new,) + external)), "lift"

        hole = oracle.fresh()
        template = oracle.formula(expression, (hole,) + external)
        term = random_term(rng)
        replacement = oracle.term(term, external)
        dropped = module.subst(expression, [term, -1])
        assert ref.same(ref.substitute(template, {hole: replacement}),
                        oracle.formula(dropped, external)), "one-binder substitution"

        successor = ["s", 0]
        retained = module.subst(expression, [successor, 0])
        assert ref.same(ref.substitute(template, {hole: ref.Succ(ref.Var(hole))}),
                        oracle.formula(retained, (hole,) + external)), "retained slot"

        previous, counter = oracle.fresh(), oracle.fresh()
        body = random_term(rng)
        named_body = oracle.term(body, (previous, counter) + external)
        first, second = random_term(rng), random_term(rng)
        expected = ref.substitute(named_body, {
            previous: oracle.term(first, external),
            counter: oracle.term(second, external)})
        actual = module.subst(body, [first, second, -2], formula=False)
        assert ref.same(expected, oracle.term(actual, external)), "two-binder substitution"
    return count * 4


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", type=Path, default=HERE.parent / "checker.py")
    parser.add_argument("--examples", type=Path, default=HERE.parent / "examples")
    parser.add_argument("--output", type=Path, default=HERE.parent / "results/independent_audit.json")
    parser.add_argument("--mutations", type=int, default=2000)
    parser.add_argument("--random-json", type=int, default=4000)
    args = parser.parse_args()
    rng = random.Random(SEED)
    target = load_module(args.checker)
    counts = {}

    fixtures = branch_fixtures()
    for case in fixtures:
        a, p, g = case["goal"], case["proof"], case["assumptions"]
        actual = target_sequent(target, a, p, g)
        independent = ref.accept_sequent(a, p, g)
        assert actual == independent == case["strict"], case["name"]
    counts["direct_rule_and_adversarial_cases"] = len(fixtures)

    # Goal syntax rejects illegal types and arities even when the malformed
    # goal is also present among the proposed assumptions.
    bad = JSON_ATOMS + [[], {}, ["="], ["=", -1], ["=", -1, -1, -1],
                       ["pi"], ["ex"], ["ex", ["=", -1, -1], ["=", -1, -1]],
                       ["unknown", ["=", -1, -1]], ["=", ["s"], -1],
                       ["=", ["r", -1, -1, []], -1]]
    for atom in [False, True, -2, -3, 0.0, -1.0, None, {}, [], "0"]:
        bad.extend([["=", atom, -1], ["=", -1, atom],
                    ["pi", ["=", -1, atom], ["=", -1, -1]],
                    ["ex", ["=", ["r", -1, -1, atom], -1]]])
    for formula in bad:
        assert not target_sequent(target, formula, None, [formula])
        assert not ref.accept_sequent(formula, None, [formula])
    counts["malformed_goal_and_context_cases"] = len(bad)

    positive = []
    for path in sorted(args.examples.glob("*.json")):
        data = json.loads(path.read_text())
        assert target_document(target, data), path
        assert ref.accept_document(data), path
        positive.append((path.name, data, list(tree_paths(data))))
    if not positive:
        raise AssertionError("no positive certificate fixtures")
    counts["theorem_examples"] = len(positive)

    counts["binding_transformations"] = binding_audit(target, rng)

    replacements = JSON_ATOMS + [[], {}, ["s", -1], ["=", -1, -1],
                                ["=", -1, ["s", -1]], ["ex", ["=", 0, 0]],
                                ["r", -1, -1, 0], {"0": 0}]
    accepted = 0
    for _ in range(args.mutations):
        name, data, paths = rng.choice(positive)
        changed = replace(data, rng.choice(paths), deepcopy(rng.choice(replacements)))
        observed = target_document(target, changed)
        expected = ref.accept_document(changed)
        if observed != expected:
            args.output.with_suffix(".failure.json").write_text(json.dumps(changed, indent=2))
            raise AssertionError(("mutated theorem", name, observed, expected))
        accepted += observed
    counts["theorem_mutations"] = args.mutations
    counts["accepted_theorem_mutations"] = accepted

    accepted = 0
    for index in range(args.random_json):
        if index % 4 == 0:
            data = random_json(rng)
        elif index % 4 == 1:
            data = [random_formula(rng, 2), random_json(rng)]
        elif index % 4 == 2:
            data = [random_json(rng), random_json(rng)]
        else:
            data = [["=", -1, ["s", -1]], random_json(rng)]
        observed = target_document(target, data)
        expected = ref.accept_document(data)
        assert observed == expected, ("arbitrary JSON", index, data)
        if index % 4 == 3:
            assert not observed, ("false equation", data)
        accepted += observed
    counts["random_json_documents"] = args.random_json
    counts["accepted_random_json_documents"] = accepted

    # Hypothesis fallback is intentionally permissive in proof payloads; fuzz
    # those paths too, including malformed active rule annotations.
    accepted = 0
    for index in range(2000):
        goal = random_formula(rng, 2)
        context = [goal] if index % 2 else []
        proof = random_json(rng)
        observed = target_sequent(target, goal, proof, context)
        expected = ref.accept_sequent(goal, proof, context)
        assert observed == expected, ("open JSON", index, goal, proof)
        accepted += observed
    counts["random_open_sequents"] = 2000
    counts["accepted_random_open_sequents"] = accepted

    result = dict(status="passed", seed=SEED,
                  checker=str(args.checker.resolve()), checker_sha256=digest(args.checker),
                  oracle_sha256=digest(HERE / "independent_oracle.py"),
                  audit_sha256=digest(Path(__file__)), python=sys.version,
                  counts=counts,
                  oracle_method="independent named-variable parser, substitution, alpha-equivalence, and rule interpreter",
                  limits=["Finite regression and differential evidence, not a machine-checked soundness theorem.",
                          "No exhaustive claim over all finite JSON inputs.",
                          "Resource exhaustion rejects through the same public exception boundary."])
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
