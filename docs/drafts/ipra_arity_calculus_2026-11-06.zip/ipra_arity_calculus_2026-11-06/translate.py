"""Untrusted proof conversion; neither checker imports this module."""
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT

def load(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

source = load('automatic_baseline', ROOT / 'reference/automatic.py')
target = load('new_compact_checker', ROOT / 'checker.py')


def erase(proof):
    if proof == 'r':
        return []
    if not isinstance(proof, list):
        return None
    if proof[0] == 'lam':
        return [erase(proof[1])]
    if proof[0] == 'pack':
        return [proof[1], erase(proof[2])]
    major, premise, *args = proof
    if major[0] == 'ex':
        return [major, erase(premise), erase(args[0])]
    return [major, erase(premise), args[0], erase(args[1])]


def reconstruct(a, p, g):
    """Rebuild an accepted new derivation for the strict automatic baseline.

    The reconstructed proof uses explicit tags and explicit hypothesis indices.
    This function is a certificate producer, never part of acceptance.
    """
    s = source.subst
    match a, p:
        case ['pi', h, b], [q]:
            if h == s(b, [-1, 0]):
                h = b if b[0] == '=' else h
                b = s(b, [['s', 0], 0])
            return ['lam', reconstruct(b, q, [*map(s, g), h])]
        case ['ex', b], [t, q]:
            h = ['=', 0, s(t, formula=False)]
            return ['pack', t, reconstruct(b, q, [*map(s, g), h])]
        case _, [[tag, *parts] as m, r, *args] if target.check(m, r, g):
            first = reconstruct(m, r, g)
            if tag == 'ex':
                return [m, first, reconstruct(s(a), args[0], [*map(s, g), *parts])]
            t, q = args
            b, c = (s(t, [v, -1]) if tag == '=' else s(v, [t, -1]) for v in parts)
            return [m, first, t, reconstruct(b, q, g)]
        case ['=', ['r', n, t, h], b], []:
            return 'r'
        case _:
            return g.index(a)


def to_twomode(a, p, g):
    """Expand the automatic introduction choice into its explicit old mode."""
    s=source.subst
    if not isinstance(p,list):
        return p
    if p[0]=='lam':
        _,h,b=a
        numerical=h==s(b,[-1,0])
        if numerical:
            h=b if b[0]=='=' else h
            b=s(b,[['s',0],0])
        return ['nat' if numerical else 'lam',to_twomode(b,p[1],[*map(s,g),h])]
    if p[0]=='pack':
        _,t,q=p
        return ['pack',t,to_twomode(a[1],q,[*map(s,g),['=',0,s(t,formula=False)]])]
    m,r,*args=p
    tag,*parts=m
    first=to_twomode(m,r,g)
    if tag=='ex':
        return ['use',m,first,to_twomode(s(a),args[0],[*map(s,g),*parts])]
    t,q=args
    b,c=(s(t,[v,-1]) if tag=='=' else s(v,[t,-1]) for v in parts)
    return ['use',m,first,t,to_twomode(b,q,g)]


def lift_twomode(p, depth=0):
    """Insert one unused free number slot under all local proof binders."""
    s=source.subst
    if not isinstance(p,list):
        return p
    if p[0] in ('lam','nat'):
        return [p[0],lift_twomode(p[1],depth+1)]
    if p[0]=='pack':
        return ['pack',s(p[1],(1,),depth,False),lift_twomode(p[2],depth+1)]
    _,m,r,*args=p
    head=['use',s(m,(1,),depth),lift_twomode(r,depth)]
    if m[0]=='ex':
        return [*head,lift_twomode(args[0],depth+1)]
    t,q=args
    return [*head,s(t,(1,),depth+(m[0]=='='),m[0]=='='),lift_twomode(q,depth)]


def close_automatic(data):
    """Close every source hypothesis by derived ordinary guarded introduction.

    Output is a genuine theorem certificate for the new public checker.
    No additional axioms or context-validation exceptions are introduced.
    """
    compiler=load('guard_detour_compiler',ROOT/'automatic_compiler.py')
    a,p,*g=data
    assert source.check(a,p,g)
    q=to_twomode(a,p,g)
    compiler.old.check(a,q,g)
    while g:
        h=g.pop()
        a=['pi',source.subst(h),source.subst(a)]
        q=['lam',lift_twomode(q)]
        compiler.old.check(a,q,g)
    a,automatic=compiler.translate_data([a,q])
    assert source.check(a,automatic,[])
    proof=erase(automatic)
    assert target.check(a,proof,[])
    return [a,proof]
