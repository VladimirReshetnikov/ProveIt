"""Reproducible conversion, mutation, and isolated-CLI checks (untrusted)."""
import ast
import copy
import hashlib
import io
import json
import random
import subprocess
import sys
import tokenize
from pathlib import Path
import translate as tr

ROOT = Path(__file__).resolve().parent
FIELDS = ('ast_nodes', 'source_tokens', 'normalized_tokens', 'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}

def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)) and node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
            doc = node.body.pop(0)
            spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    normal = ast.unparse(tree) + '\n'
    def count(text, omit=()):
        return sum(t.type not in IGNORED and not any(a <= t.start and t.end <= b for a,b in omit)
                   for t in tokenize.generate_tokens(io.StringIO(text).readline))
    return dict(source=str(path),sha256=hashlib.sha256(raw).hexdigest(),
                ast_nodes=sum(1 for _ in ast.walk(tree)),source_tokens=count(source,spans),
                normalized_tokens=count(normal),normalized_bytes=len(normal.encode()),raw_bytes=len(raw))

def accepts(module, a, p, g=()):
    try:
        return module.check(a, p, list(g)) is True
    except Exception:
        return False


def paths(tree, path=()):
    yield path
    if isinstance(tree, list):
        for i,v in enumerate(tree):
            yield from paths(v, (*path,i))


def replace(tree, path, value):
    if not path:
        return value
    result=tree.copy()
    result[path[0]]=replace(tree[path[0]],path[1:],value)
    return result


def main():
    examples=ROOT/'examples'
    examples.mkdir(exist_ok=True)
    fixtures=[]
    for path in sorted((tr.BASE/'source_examples').glob('*.json')):
        a,p,*g=json.loads(path.read_text())
        assert accepts(tr.source,a,p,g),path
        q=tr.erase(p)
        assert accepts(tr.target,a,q,g),path
        r=tr.reconstruct(a,q,g)
        assert accepts(tr.source,a,r,g),path
        if not g:
            (examples/path.name).write_text(json.dumps([a,q],indent=2)+'\n')
        fixtures.append([a,q,g,path.name])
    source_count=len(fixtures)
    closed_count=0
    for a,q,g,name in list(fixtures):
        if g:
            source_data=json.loads((tr.BASE/'source_examples'/name).read_text())
            closed_a,closed_p=tr.close_automatic(source_data)
            back=tr.reconstruct(closed_a,closed_p,[])
            assert accepts(tr.source,closed_a,back,[])
            closed_name='closed_'+name
            (examples/closed_name).write_text(json.dumps([closed_a,closed_p],indent=2)+'\n')
            fixtures.append([closed_a,closed_p,[],closed_name])
            closed_count+=1
    theorem_count=sum(not g for a,p,g,name in fixtures)
    # These tests compare every accepted mutation with an independently
    # reconstructed tagged proof checked by the strict predecessor.
    rng=random.Random(20261106)
    replacements=[None,True,False,-2,-1,0,1,[],['s',-1],['=',-1,-1],['ex',['=',-1,-1]]]
    mutation_count=3000
    accepted=0
    for _ in range(mutation_count):
        a,p,g,name=rng.choice(fixtures)
        data=[a,p]
        path=rng.choice(list(paths(data)))
        changed=replace(data,path,copy.deepcopy(rng.choice(replacements)))
        if not isinstance(changed,list) or len(changed)!=2:
            continue
        a2,p2=changed
        if accepts(tr.target,a2,p2,g):
            accepted+=1
            back=tr.reconstruct(a2,p2,g)
            assert accepts(tr.source,a2,back,g),(name,path,changed)
    # Public program must run with no Python site packages and no imports
    # of translator, proof library, or arithmetic schema generator.
    cli={}
    for path in sorted(examples.glob('*.json')):
        r=subprocess.run([sys.executable,'-I','-S',str(ROOT/'checker.py'),str(path)],capture_output=True,text=True)
        assert r.returncode==0 and r.stdout.strip()=='ACCEPT',(path,r.stdout,r.stderr)
        cli[path.name]='ACCEPT'
    bad=ROOT/'validation/bad_false_equation.json'
    bad.write_text(json.dumps([['=',-1,['s',-1]],None]))
    r=subprocess.run([sys.executable,'-I','-S',str(ROOT/'checker.py'),str(bad)],capture_output=True,text=True)
    assert r.returncode==1 and r.stdout.strip()=='REJECT'
    variants={name:measure(ROOT/name) for name in ('checker.py','checker_demand.py','checker_open.py','checker_open_demand.py')}
    result=dict(status='passed',source_examples=source_count,closed_hypothesis_examples=closed_count,all_examples=len(fixtures),theorem_examples=theorem_count,
                source_reconstructions=len(fixtures),mutation_trials=mutation_count,
                accepted_mutants_reconstructed=accepted,isolated_cli=cli,metrics=variants)
    (ROOT/'results/kernel_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='isolated_cli'},indent=2))

if __name__=='__main__':
    main()
