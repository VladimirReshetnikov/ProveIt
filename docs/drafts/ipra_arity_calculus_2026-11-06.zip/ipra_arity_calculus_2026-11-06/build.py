"""Build the article from its complete supplied LaTeX sources."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    if shutil.which('pdflatex') is None:
        raise SystemExit('Install a TeX distribution with pdflatex first.')
    for _ in range(2):
        result = subprocess.run(['pdflatex', '-interaction=nonstopmode',
                                 '-halt-on-error', '-file-line-error', 'report.tex'],
                                cwd=ROOT, text=True, capture_output=True)
        if result.returncode:
            raise SystemExit(result.stdout[-15000:] + result.stderr[-5000:])
    print('Built report.pdf')


if __name__ == '__main__':
    main()
