#!/usr/bin/env python3
"""Finite diagnostics for iPRA boundary and inverse-iterator presentations.

The tests check concrete syntax accounting, finite scans, and selected
numerical examples. They are NOT a proof-assistant formalization or a proof
of the infinite axiomatization/bi-interpretability theorems. Those proofs
are given in the accompanying report.

Run: python3 artifacts/check_axioms.py
     python3 artifacts/check_axioms.py --output /path/to/results.json
Only Python's standard library is required.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class Node:
    kind: str
    name: str = ""
    args: tuple["Node", ...] = ()
    descriptor: "Node | None" = None


def var(name: str) -> Node:
    return Node("var", name)


def const(name: str) -> Node:
    return Node("const", name)


def app(name: str, *args: Node, descriptor: Node | None = None) -> Node:
    return Node("app", name, tuple(args), descriptor)


def op(name: str, *args: Node) -> Node:
    return Node("formula", name, tuple(args))


def bind(name: str, variable: str, body: Node) -> Node:
    # The binder costs one node. Its bound-variable annotation is not an
    # additional occurrence. Actual variable leaves in the body are charged.
    return Node("binder", name + ":" + variable, (body,))


def forall(names: list[str], body: Node) -> Node:
    for name in reversed(names):
        body = bind("forall", name, body)
    return body


def exists(name: str, body: Node) -> Node:
    return bind("exists", name, body)


def size(node: Node) -> int:
    frozen = 0 if node.descriptor is None else size(node.descriptor)
    return 1 + frozen + sum(size(arg) for arg in node.args)


def substitute_term(node: Node, mapping: dict[str, Node]) -> Node:
    """Active term substitution. Stored descriptors are never traversed."""
    if node.kind == "var":
        return mapping.get(node.name, node)
    if node.kind == "binder":
        raise ValueError("This helper is only for terms and equation matrices")
    return Node(node.kind, node.name,
                tuple(substitute_term(a, mapping) for a in node.args),
                node.descriptor)


def active_occurrences(node: Node, name: str) -> int:
    return int(node.kind == "var" and node.name == name) + sum(
        active_occurrences(a, name) for a in node.args
    )


def free_variables(node: Node) -> set[str]:
    """Free active variables; numerical descriptor labels stay opaque."""
    if node.kind == "var":
        return {node.name}
    if node.kind == "binder":
        _, variable = node.name.split(":", 1)
        return free_variables(node.args[0]) - {variable}
    if node.kind == "defined_binder" and node.name.startswith("L:"):
        variable = node.name.split(":", 1)[1]
        A, P, v, C = node.args
        return ((free_variables(A) | free_variables(P)) - {variable}) | (
            free_variables(v) | free_variables(C)
        )
    return set().union(*(free_variables(a) for a in node.args))


def active_names(node: Node) -> set[str]:
    names = {node.name} if node.kind == "var" else set()
    if node.kind in {"binder", "defined_binder"} and ":" in node.name:
        names.add(node.name.split(":", 1)[1])
    for a in node.args:
        names |= active_names(a)
    return names


def fresh_name(avoid: set[str]) -> str:
    index = 0
    while f"fresh{index}" in avoid:
        index += 1
    return f"fresh{index}"


def substitute_formula(node: Node, mapping: dict[str, Node]) -> Node:
    """Capture-avoiding active numerical substitution, including L's scope."""
    if node.kind == "var":
        return mapping.get(node.name, node)
    if node.kind == "binder":
        operator, variable = node.name.split(":", 1)
        body = node.args[0]
        local = {k: v for k, v in mapping.items() if k != variable}
        replacement_variables = set().union(*(free_variables(v) for v in local.values()))
        if variable in replacement_variables:
            avoid = active_names(body) | set(mapping) | replacement_variables
            renamed = fresh_name(avoid)
            body = substitute_formula(body, {variable: var(renamed)})
            variable = renamed
        return bind(operator, variable, substitute_formula(body, local))
    if node.kind == "defined_binder" and node.name.startswith("L:"):
        variable = node.name.split(":", 1)[1]
        A, P, v, C = node.args
        assert variable not in free_variables(v) | free_variables(C)
        local = {k: value for k, value in mapping.items() if k != variable}
        replacement_variables = set().union(*(free_variables(value) for value in local.values()))
        if variable in replacement_variables:
            avoid = active_names(node) | set(mapping) | replacement_variables
            renamed = fresh_name(avoid)
            A = substitute_formula(A, {variable: var(renamed)})
            P = substitute_formula(P, {variable: var(renamed)})
            variable = renamed
        return Node("defined_binder", "L:" + variable, (
            substitute_formula(A, local), substitute_formula(P, local),
            substitute_formula(v, mapping), substitute_formula(C, mapping),
        ))
    return Node(node.kind, node.name,
                tuple(substitute_formula(a, mapping) for a in node.args),
                node.descriptor)


def expand_l(node: Node) -> Node:
    """Expand L_x(A,P;v,C) with its actual substitution and scope."""
    if node.kind == "defined_binder" and node.name.startswith("L:"):
        variable = node.name.split(":", 1)[1]
        A, P, v, C = (expand_l(a) for a in node.args)
        if variable in free_variables(v) | free_variables(C):
            raise ValueError("L binder variable must be absent from v and C")
        return conjunction(
            forall([variable], implies(A, P)),
            implies(substitute_formula(P, {variable: v}), C),
        )
    return Node(node.kind, node.name, tuple(expand_l(a) for a in node.args),
                node.descriptor)


def alpha_key(node: Node, environment: dict[str, int] | None = None,
              depth: int = 0) -> tuple:
    """An alpha-invariant key for expanded formulas, with frozen labels exact."""
    environment = {} if environment is None else environment
    if node.kind == "var":
        return ("bound", environment[node.name]) if node.name in environment else (
            "free", node.name
        )
    if node.kind == "binder":
        operator, variable = node.name.split(":", 1)
        nested = dict(environment)
        nested[variable] = depth
        return ("binder", operator, alpha_key(node.args[0], nested, depth + 1))
    return (node.kind, node.name, node.descriptor,
            tuple(alpha_key(a, environment, depth) for a in node.args))


ZERO = const("0")
BOTTOM = const("bottom")


def succ(term: Node) -> Node:
    return app("S", term)


def eq(left: Node, right: Node) -> Node:
    return op("=", left, right)


def implies(left: Node, right: Node) -> Node:
    return op("implies", left, right)


def conjunction(left: Node, right: Node) -> Node:
    return op("and", left, right)


def disjunction(left: Node, right: Node) -> Node:
    return op("or", left, right)


def k4(a: Node, p: Node, b: Node, q: Node) -> Node:
    return conjunction(implies(a, p), implies(p, implies(b, q)))


def k3(a: Node, p: Node, q: Node) -> Node:
    return conjunction(implies(a, p), implies(p, q))


def ordinary_module(h: Node, m: int) -> Node:
    n, a = var("n"), var("a")
    parameters = [var(f"c{i}") for i in range(1, m + 1)]

    def r(counter: Node) -> Node:
        return app("R", counter, a, *parameters, descriptor=h)

    base = eq(r(ZERO), a)
    update = substitute_term(h, {"v": r(n), "w": n})
    step = forall(["n"], eq(r(succ(n)), update))
    return forall(["a"] + [p.name for p in parameters],
                  conjunction(base, step))


def boundary(matrix: Node, m: int, kind: str) -> Node:
    x, t, b = var("x"), var("t"), var("b")
    names = ["t"] + [f"c{i}" for i in range(1, m + 1)]
    at_b = substitute_term(matrix, {"x": b})
    if kind == "old_expanded":
        body = forall(["x"], k4(eq(succ(x), b), matrix,
                                    eq(x, b), eq(b, t)))
    elif kind == "scoped":
        body = conjunction(
            forall(["x"], implies(eq(succ(x), b), matrix)),
            implies(at_b, eq(b, t)),
        )
    elif kind == "witnessed":
        predecessor = exists("x", conjunction(eq(succ(x), b), matrix))
        body = conjunction(disjunction(eq(b, ZERO), predecessor),
                           implies(at_b, eq(b, t)))
    elif kind == "old_k4":
        body = forall(["x"], op("K4", eq(succ(x), b), matrix,
                                    eq(x, b), eq(b, t)))
    elif kind == "old_k3":
        body = forall(["x"], op("K3", eq(succ(x), b), matrix,
                                    implies(eq(x, b), eq(b, t))))
    elif kind == "witnessed_j":
        # J's binder annotation x is not a separate syntax node.
        body = Node("defined_binder", "J:x",
                    (eq(b, ZERO), eq(succ(x), b), matrix, b, eq(b, t)))
    elif kind == "scoped_l":
        body = Node("defined_binder", "L:x",
                    (eq(succ(x), b), matrix, b, eq(b, t)))
    else:
        raise ValueError(kind)
    return forall(names, exists("b", body))


def check_ast_accounting() -> dict:
    sep = implies(eq(ZERO, succ(ZERO)), BOTTOM)
    coverage = forall(["z"], exists("y", disjunction(
        eq(var("z"), ZERO), eq(var("z"), succ(var("y"))))))
    fixed = {
        "Sep": size(sep),
        "Cov": size(coverage),
        "Q_ordinary_module": size(ordinary_module(var("w"), 0)),
        "C_ordinary_module": size(ordinary_module(var("c1"), 1)),
        "A_ordinary_module": size(ordinary_module(succ(var("v")), 0)),
    }
    assert fixed == {"Sep": 6, "Cov": 10, "Q_ordinary_module": 16,
                     "C_ordinary_module": 19, "A_ordinary_module": 23}

    A, B, P, C, D = (var(s) for s in ["A", "B", "P", "C", "D"])
    x, v = var("x"), var("v")
    j_left = Node("defined_binder", "J:x",
                  (A, app("B", x), app("P", x), v, C))
    j_right = conjunction(
        disjunction(A, exists("x", conjunction(app("B", x), app("P", x)))),
        implies(app("P", v), C),
    )
    l_left = Node("defined_binder", "L:x",
                  (app("A", x), app("P", x), v, C))
    l_right = expand_l(l_left)
    definitions = {
        "K3": size(op("K3", A, B, D)) + size(k3(A, B, D)) + 1,
        "K4": size(op("K4", A, B, C, D)) + size(k4(A, B, C, D)) + 1,
        "J": size(j_left) + size(j_right) + 1,
        "L": size(l_left) + size(l_right) + 1,
    }
    assert definitions == {"K3": 12, "K4": 15, "J": 22, "L": 19}

    checked_boundaries = 0
    for m in range(7):
        left = var("x")
        for depth in range(10):
            matrix = eq(left, var("t"))
            F = size(matrix)
            expected = {
                "old_expanded": 2 * F + m + 17,
                "scoped": 2 * F + m + 13,
                "witnessed": 2 * F + m + 17,
                "old_k4": F + m + 14,
                "old_k3": F + m + 15,
                "witnessed_j": F + m + 14,
                "scoped_l": F + m + 11,
            }
            for kind, wanted in expected.items():
                got = size(boundary(matrix, m, kind))
                assert got == wanted, (kind, m, F, got, wanted)
                checked_boundaries += 1
            assert expand_l(boundary(matrix, m, "scoped_l")) == boundary(matrix, m, "scoped")
            left = succ(left)

    module_templates = [var("v"), var("w"), ZERO, succ(var("v")),
                        app("A", var("v"), var("w"),
                            descriptor=succ(var("v")))]
    for depth in range(1, 8):
        term = var("v")
        for _ in range(depth):
            term = app("A", term, var("v"), descriptor=succ(var("v")))
        module_templates.append(term)
    checked_modules = 0
    for m in range(7):
        for h in module_templates:
            H = size(h)
            k = active_occurrences(h, "v")
            expected = 3 * H + 3 * m + 13 + k * (H + m + 2)
            got = size(ordinary_module(h, m))
            assert got == expected, (m, H, k, got, expected)
            checked_modules += 1

    frozen_test = app("A", var("v"), var("w"), descriptor=succ(var("v")))
    changed = substitute_term(frozen_test, {"v": ZERO, "w": succ(ZERO)})
    assert changed.descriptor == frozen_test.descriptor
    assert active_occurrences(frozen_test, "v") == 1
    assert changed.args == (ZERO, succ(ZERO))
    return {
        "fixed_records": fixed,
        "paid_definition_records": definitions,
        "scoped_L_fixed_record_with_Sep_and_Cov": size(sep) + size(coverage) + definitions["L"],
        "boundary_size_instances_checked": checked_boundaries,
        "ordinary_module_size_instances_checked": checked_modules,
        "frozen_descriptor_scope_control": "passed",
        "size_convention": (
            "one node per variable, constant, application, equation, connective, "
            "falsity and individual quantifier; every recursor occurrence also "
            "pays its full recursively frozen descriptor"
        ),
        "boundary_formulas": {
            "old_expanded": "2F+m+17",
            "scoped": "2F+m+13",
            "witnessed": "2F+m+17",
            "old_k4": "F+m+14",
            "old_k3": "F+m+15",
            "witnessed_j": "F+m+14",
            "scoped_l": "F+m+11",
        },
        "L_packet_tradeoffs_with_equal_other_support": {
            "L_minus_K4_for_r_boundaries": "4-3r",
            "L_minus_K3_for_r_boundaries": "7-4r",
            "L_minus_witnessed_J_for_r_boundaries": "7-3r",
            "qualification": "full fixed records are included; coverage support cannot be mixed for free",
        },
    }


def check_l_substitution() -> dict:
    x, b, t, y, z = (var(name) for name in ["x", "b", "t", "y", "z"])
    matrices = [
        eq(x, t),
        implies(eq(x, b), eq(t, ZERO)),
        forall(["y"], implies(eq(x, y), eq(y, t))),
        exists("z", eq(app("R", x, z, descriptor=succ(var("v"))), t)),
    ]
    antecedents = [eq(succ(x), b), eq(x, ZERO)]
    value_terms = [b, succ(b), y, app("A", y, b, descriptor=succ(var("v")))]
    consequents = [eq(b, t), forall(["z"], implies(eq(t, z), eq(z, b)))]
    substitutions = [
        {}, {"b": x}, {"t": succ(x)}, {"y": x},
        {"b": y, "t": x}, {"x": succ(z)}, {"b": succ(x), "t": succ(x)},
    ]
    checked = 0
    for A in antecedents:
        for P in matrices:
            for v in value_terms:
                for C in consequents:
                    expression = Node("defined_binder", "L:x", (A, P, v, C))
                    for mapping in substitutions:
                        left = expand_l(substitute_formula(expression, mapping))
                        right = substitute_formula(expand_l(expression), mapping)
                        assert alpha_key(left) == alpha_key(right)
                        checked += 1
    # Invalid unrenamed input must be rejected rather than capturing x.
    try:
        expand_l(Node("defined_binder", "L:x", (eq(x, b), eq(x, t), x, eq(b, t))))
    except ValueError:
        rejected = True
    else:
        rejected = False
    assert rejected
    return {
        "expansion_commutes_with_capture_avoiding_substitution_instances": checked,
        "nested_quantifier_and_bound_name_collision_cases_included": True,
        "free_x_in_unrenamed_value_term_rejected": rejected,
        "definition": "L_x(A,P;v,C) = (forall x (A implies P)) and (P[v/x] implies C)",
        "scope": "x binds only A and P; x must be absent from free variables of v and C",
    }


def scan_states(predicate: Callable[[int], bool], horizon: int) -> list[int]:
    states = [0]
    for n in range(horizon):
        old = states[-1]
        states.append(n + 1 if predicate(old) else old)
    return states


def witnessed_boundary_holds(predicate: Callable[[int], bool],
                              target: int, witness: int) -> bool:
    predecessor_part = witness == 0 or (
        witness > 0 and (witness - 1) + 1 == witness
        and predicate(witness - 1)
    )
    terminal_part = not predicate(witness) or witness == target
    return predecessor_part and terminal_part


def check_scan_instance(predicate: Callable[[int], bool], target: int) -> int:
    states = scan_states(predicate, target)
    for n, d in enumerate(states):
        assert 0 <= d <= n
        assert d == 0 or ((d - 1) + 1 == d and predicate(d - 1))
        assert not predicate(d) or d == n
    assert witnessed_boundary_holds(predicate, target, states[-1])
    return len(states)


def check_scans() -> dict:
    configurations = 0
    invariant_states = 0
    counts_by_horizon = {}
    for target in range(11):
        count = 0
        for bits in range(1 << (target + 1)):
            predicate = lambda x, bits=bits: bool((bits >> x) & 1)
            invariant_states += check_scan_instance(predicate, target)
            configurations += 1
            count += 1
        counts_by_horizon[str(target)] = count

    families = [
        ("x < target", lambda x, t, c: x < t),
        ("x = target", lambda x, t, c: x == t),
        ("(x+c) mod 3 = target mod 3", lambda x, t, c: (x + c) % 3 == t % 3),
        ("x*x+c <= target", lambda x, t, c: x * x + c <= t),
    ]
    target_dependent_checks = 0
    for _, family in families:
        for target in range(11):
            for parameter in range(5):
                predicate = lambda x, t=target, c=parameter, f=family: f(x, t, c)
                check_scan_instance(predicate, target)
                target_dependent_checks += 1

    moving_target_controls = []
    for label, family in families[:2]:
        target = 1
        correct = scan_states(lambda x: family(x, target, 0), target)[-1]
        wrong = 0
        for n in range(target):
            # Deliberate error: replace the fixed target parameter by n.
            wrong = n + 1 if family(wrong, n, 0) else wrong
        fixed_predicate = lambda x: family(x, target, 0)
        assert witnessed_boundary_holds(fixed_predicate, target, correct)
        assert not witnessed_boundary_holds(fixed_predicate, target, wrong)
        moving_target_controls.append({
            "predicate": label, "target": target,
            "correct_witness": correct, "moving_target_witness": wrong,
            "incorrect_scan_violates_WB": True,
        })
    return {
        "maximum_horizon": 10,
        "all_boolean_predicate_configurations": configurations,
        "invariant_states_checked": invariant_states,
        "configurations_by_horizon": counts_by_horizon,
        "target_dependent_examples": target_dependent_checks,
        "target_dependent_predicate_families": [name for name, _ in families],
        "moving_target_negative_controls": moving_target_controls,
        "invariants": [
            "0 <= d_n <= n",
            "d_n=0 or (S(pred(d_n))=d_n and E(pred(d_n),fixed_target,c))",
            "E(d_n,fixed_target,c) implies d_n=n",
        ],
    }


def iterate(update: Callable[[int, int, int | None], int],
            n: int, initial: int, parameter: int | None = None) -> int:
    value = initial
    for w in range(n):
        value = update(value, w, parameter)
    return value


def check_inverse_iterators() -> dict:
    positive_checks = 0
    unequal_length_checks = 0
    for j in range(1, 9):
        outer = lambda v, w, c, j=j: max(0, v - j)
        inner = lambda v, w, c, j=j: v + j
        for n in range(12):
            for a in range(15):
                assert iterate(outer, n, iterate(inner, n, a)) == a
                positive_checks += 1
                for m in range(8):
                    assert iterate(outer, n, iterate(inner, n + m, a)) == iterate(inner, m, a)
                    assert iterate(outer, n + m, iterate(inner, n, a)) == iterate(outer, m, a)
                    unequal_length_checks += 2

    # A counter-dependent INNER update is permitted and really is tested.
    outer = lambda v, w, c: v // 2
    inner = lambda v, w, c: 2 * v + (w % 2)
    nonautonomous_inner_checks = 0
    for n in range(12):
        for m in range(8):
            for a in range(15):
                assert iterate(outer, n, iterate(inner, n + m, a)) == iterate(inner, m, a)
                assert iterate(outer, n + m, iterate(inner, n, a)) == iterate(outer, m, a)
                nonautonomous_inner_checks += 2

    negatives = []
    outer_bad = lambda v, w, c: v // 2 if w == 0 else max(0, v - 1)
    inner_bad = lambda v, w, c: 2 * v if w == 0 else v + 1
    for v in range(20):
        for w in range(5):
            assert outer_bad(inner_bad(v, w, None), w, None) == v
    result = iterate(outer_bad, 2, iterate(inner_bad, 2, 1))
    assert result == 0 and result != 1
    negatives.append({
        "omitted_condition": "autonomous outer update",
        "initial": 1, "length": 2, "inner_result": 3, "actual_result": result,
        "incorrect_claim_result": 1,
        "pointwise_left_inverse_instances_checked": 100,
        "updates": "f_0(v)=floor(v/2), f_w(v)=pred(v) for w>0; "
                   "g_0(v)=2v, g_w(v)=v+1 for w>0",
    })

    predecessor = lambda v, w, c: max(0, v - 1)
    successor = lambda v, w, c: v + 1
    result = iterate(predecessor, 2, iterate(successor, 1, 1))
    assert result == 0 and result != 1
    negatives.append({
        "omitted_condition": "synchronized lengths without a remainder correction",
        "initial": 1, "outer_length": 2, "inner_length": 1,
        "actual_result": result, "incorrect_claim_result": 1,
        "updates": "f=pred, g=S",
    })

    minus = lambda v, w, c: max(0, v - c)
    plus = lambda v, w, c: v + c
    for c in range(6):
        for v in range(20):
            assert minus(plus(v, 0, c), 0, c) == v
    result = iterate(minus, 1, iterate(plus, 1, 0, 2), 1)
    assert result == 1 and result != 0
    negatives.append({
        "omitted_condition": "matching actual parameter tuples",
        "initial": 0, "length": 1, "outer_parameter": 1, "inner_parameter": 2,
        "actual_result": result, "incorrect_claim_result": 0,
        "updates": "f(v,c)=v truncated-minus c; g(v,w,c)=v+c",
    })

    for v in range(50):
        assert predecessor(successor(v, 0, None), 0, None) == v
    result = iterate(successor, 1, iterate(predecessor, 1, 0))
    assert result == 1 and result != 0
    negatives.append({
        "omitted_condition": "left-inverse direction f(g(v,w,c),c)=v",
        "initial": 0, "length": 1,
        "actual_result": result, "incorrect_claim_result": 0,
        "updates": "f=S, g=pred; the reverse identity g(f(v))=v does hold",
    })
    return {
        "synchronized_predecessor_successor_instances": positive_checks,
        "unequal_length_predecessor_successor_instances": unequal_length_checks,
        "counter_dependent_inner_instances": nonautonomous_inner_checks,
        "negative_side_condition_controls": negatives,
    }


def main() -> None:
    if not __debug__:
        raise RuntimeError("Run without -O: this diagnostic requires assertions")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("axiom_checks.json"))
    arguments = parser.parse_args()
    results = {
        "status": "passed",
        "verification_kind": "finite executable diagnostics, not formal proof",
        "ast_accounting": check_ast_accounting(),
        "scoped_L_hygiene": check_l_substitution(),
        "witnessed_boundaries": check_scans(),
        "inverse_iterators": check_inverse_iterators(),
    }
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": results["status"], "output": str(arguments.output),
                      "boolean_scans": results["witnessed_boundaries"]["all_boolean_predicate_configurations"],
                      "negative_side_condition_controls": len(results["inverse_iterators"]["negative_side_condition_controls"])}))


if __name__ == "__main__":
    main()
