#!/usr/bin/env python3
"""Check schematic inverse-iteration proofs relative to equation induction.

This small equality kernel checks symbolic proof trees, not only numerical
examples.  Its arithmetic assumptions are exactly the recursor equations,
one local left-inverse equation, and the equation-induction rule.  The report
proves that rule from the presented axioms.  This file is not a Lean/Rocq
formalization and does not itself formalize the full bi-interpretability proof.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path


@dataclass(frozen=True)
class Term:
    kind: str
    name: str
    args: tuple["Term", ...] = ()

    def show(self):
        return self.name if not self.args else (
            self.name + "(" + ",".join(t.show() for t in self.args) + ")"
        )


def V(name):
    return Term("variable", name)


def A(name, *args):
    return Term("application", name, tuple(args))


Z = A("0")


def S(t):
    return A("S", t)


def subst(t, mapping):
    if t.kind == "variable":
        return mapping.get(t.name, t)
    return A(t.name, *(subst(a, mapping) for a in t.args))


def free(t):
    if t.kind == "variable":
        return {t.name}
    return set().union(*(free(a) for a in t.args)) if t.args else set()


def at(t, path):
    for i in path:
        t = t.args[i]
    return t


def replace(t, path, replacement):
    if not path:
        return replacement
    i, *rest = path
    args = list(t.args)
    args[i] = replace(args[i], rest, replacement)
    return A(t.name, *args)


@dataclass(frozen=True)
class Equation:
    left: Term
    right: Term

    def instantiate(self, mapping):
        return Equation(subst(self.left, mapping), subst(self.right, mapping))

    def variables(self):
        return free(self.left) | free(self.right)

    def show(self):
        return self.left.show() + " = " + self.right.show()


@dataclass(frozen=True)
class Step:
    rule: str
    substitution: dict[str, Term]
    path: tuple[int, ...] = ()
    reverse: bool = False


class Kernel:
    """Equality rewriting plus an explicitly scoped equation-induction rule."""

    def __init__(self, axioms):
        self.theorems = dict(axioms)
        self.receipts = []

    def rewrite(self, current, step, hypotheses):
        if step.rule in hypotheses:
            if step.substitution:
                raise ValueError("A local induction hypothesis cannot be specialized")
            equation = hypotheses[step.rule]
        else:
            if step.rule not in self.theorems:
                raise ValueError("Unknown equality rule")
            schema = self.theorems[step.rule]
            if set(step.substitution) != schema.variables():
                raise ValueError("A universal equation needs every and only its free slots")
            equation = schema.instantiate(step.substitution)
        left, right = equation.left, equation.right
        if step.reverse:
            left, right = right, left
        if at(current, step.path) != left:
            raise ValueError("Equality rewrite does not match its selected subterm")
        return replace(current, step.path, right)

    def chain(self, goal, steps, hypotheses):
        current = goal.left
        terms = [current.show()]
        for step in steps:
            current = self.rewrite(current, step, hypotheses)
            terms.append(current.show())
        if current != goal.right:
            raise ValueError("Equality chain did not reach its declared right endpoint")
        return terms

    def induction(self, name, equation, counter, parameters, base, step):
        if counter in parameters or equation.variables() != {counter} | set(parameters):
            raise ValueError("Induction counter and fixed parameter scopes are incorrect")
        n = V(counter)
        base_goal = equation.instantiate({counter: Z})
        step_goal = equation.instantiate({counter: S(n)})
        base_terms = self.chain(base_goal, base, {})
        step_terms = self.chain(step_goal, step, {"IH": equation})
        self.theorems[name] = equation
        receipt = {
            "theorem": name,
            "equation": equation.show(),
            "induction_counter": counter,
            "fixed_parameters": list(parameters),
            "base_chain": base_terms,
            "step_chain": step_terms,
        }
        self.receipts.append(receipt)
        return receipt


def symbolic_checks():
    n, a, b, c, v, w, m, d = map(V, ("n", "a", "b", "c", "v", "w", "m", "d"))
    rf = lambda x, y, p: A("R_f", x, y, p)
    rg = lambda x, y, p: A("R_g", x, y, p)
    rh = lambda x, y, p: A("R_H", x, y, p)
    f = lambda x, p: A("f", x, p)
    g = lambda x, y, p: A("g", x, y, p)
    axioms = {
        "f_zero": Equation(rf(Z, a, c), a),
        "f_step": Equation(rf(S(n), a, c), f(rf(n, a, c), c)),
        "g_zero": Equation(rg(Z, a, c), a),
        "g_step": Equation(rg(S(n), a, c), g(rg(n, a, c), n, c)),
        "left_inverse": Equation(f(g(v, w, c), c), v),
        "H_zero": Equation(rh(Z, a, c), a),
        "H_step": Equation(rh(S(n), a, c), rf(n, rg(n, rh(n, a, c), c), c)),
    }
    k = Kernel(axioms)
    pivot = Equation(rf(S(n), b, c), rf(n, f(b, c), c))
    k.induction("pivot", pivot, "n", ("b", "c"), [
        Step("f_step", {"n": Z, "a": b, "c": c}),
        Step("f_zero", {"a": b, "c": c}, (0,)),
        Step("f_zero", {"a": f(b, c), "c": c}, reverse=True),
    ], [
        Step("f_step", {"n": S(n), "a": b, "c": c}),
        Step("IH", {}, (0,)),
        Step("f_step", {"n": n, "a": f(b, c), "c": c}, reverse=True),
    ])
    inverse = Equation(rf(n, rg(n, a, c), c), a)
    inverse_steps = [
        Step("pivot", {"n": n, "b": rg(S(n), a, c), "c": c}),
        Step("g_step", {"n": n, "a": a, "c": c}, (1, 0)),
        Step("left_inverse", {"v": rg(n, a, c), "w": n, "c": c}, (1,)),
        Step("IH", {}),
    ]
    k.induction("inverse_iteration", inverse, "n", ("a", "c"), [
        Step("f_zero", {"a": rg(Z, a, c), "c": c}),
        Step("g_zero", {"a": a, "c": c}),
    ], inverse_steps)
    wrapper = Equation(rh(n, a, c), a)
    k.induction("identity_wrapper", wrapper, "n", ("a", "c"), [
        Step("H_zero", {"a": a, "c": c}),
    ], [
        Step("H_step", {"n": n, "a": a, "c": c}),
        Step("inverse_iteration", {"n": n, "a": rh(n, a, c), "c": c}),
        Step("IH", {}),
    ])

    rejected = []

    def must_reject(name, action):
        try:
            action()
        except ValueError:
            rejected.append(name)
        else:
            raise AssertionError("Invalid certificate accepted: " + name)

    must_reject("specializing_the_local_induction_hypothesis", lambda: k.rewrite(
        inverse.left, Step("IH", {"a": S(a)}), {"IH": inverse}
    ))
    must_reject("mismatched_counters", lambda: k.rewrite(
        rf(n, rg(m, a, c), c),
        Step("inverse_iteration", {"n": n, "a": a, "c": c}), {}
    ))
    must_reject("mismatched_parameters", lambda: k.rewrite(
        rf(n, rg(n, a, d), c),
        Step("inverse_iteration", {"n": n, "a": a, "c": c}), {}
    ))
    nonautonomous = dict(axioms)
    nonautonomous["f_step"] = Equation(
        rf(S(n), a, c), A("f_clocked", rf(n, a, c), n, c)
    )
    kn = Kernel(nonautonomous)
    must_reject("outer_autonomy_removed", lambda: kn.chain(
        pivot.instantiate({"n": Z}), [
            Step("f_step", {"n": Z, "a": b, "c": c}),
            Step("f_zero", {"a": b, "c": c}, (0,)),
            Step("f_zero", {"a": f(b, c), "c": c}, reverse=True),
        ], {}
    ))
    return {
        "arithmetic_assumptions": {name: eq.show() for name, eq in axioms.items()},
        "assumed_inference": "Contextual equation induction, derived in the report",
        "schematic_certificates": k.receipts,
        "invalid_certificates_rejected": rejected,
        "inner_update_may_depend_on_counter": True,
        "tuple_parameter_note": "c denotes an arbitrary fixed finite tuple of explicit parameters",
    }


def charged(t, descs):
    total = 1 + sum(charged(a, descs) for a in t.args)
    if t.kind == "application" and t.name in descs:
        total += charged(descs[t.name], descs)
    return total


def positions(t, prefix=()):
    yield prefix
    for i, child in enumerate(t.args):
        yield from positions(child, prefix + (i,))


def numeral(t):
    k = 0
    while t.kind == "application" and t.name == "S":
        k += 1
        t = t.args[0]
    return k if t == Z else None


def old_root_rewrites(t, descs, zero_flags, absorption=False):
    """The old rules relevant to this family's vocabulary; descriptors frozen."""
    if t.kind != "application" or t.name not in descs:
        return []
    body = descs[t.name]
    n, a = t.args
    raw = []
    if n == Z:
        raw.append(("initialization", a))
    if n.name == "S" and n.kind == "application":
        u = n.args[0]
        raw.append(("shrinking_successor", subst(body, {"v": A(t.name, u, a), "w": u})))
    count = numeral(n)
    if count is not None:
        u = a
        clock = Z
        for _ in range(count):
            u = subst(body, {"v": u, "w": clock})
            clock = S(clock)
        raw.append(("finite_numeral_unfolding", u))
    if body == S(V("v")) and a == Z:
        raw.append(("addition_zero", n))
    if t.name in zero_flags and a == Z:
        raw.append(("zero_stability", Z))
    if "w" not in free(body) and a.kind == "application" and a.name == t.name:
        inner_n, inner_a = a.args
        raw.append(("autonomous_fusion", A(t.name, A("A", n, inner_n), inner_a)))
    # General predecessor cancellation through a literal successor-counter call.
    if t.name == "Q" and n.kind == "application" and n.name in descs:
        inner_body = descs[n.name]
        inner_n, inner_a = n.args
        if inner_body.kind == "application" and inner_body.name == "S":
            if inner_n.kind == "application" and inner_n.name == "S":
                u = inner_n.args[0]
                raw.append(("contextual_successor_cancellation", subst(
                    inner_body.args[0], {"v": A(n.name, u, inner_a), "w": u}
                )))
    if absorption:
        probe = subst(body, {"v": a, "w": V("fresh_clock")})
        if normalize_old(probe, descs, zero_flags, False) == a:
            raw.append(("absorbing_initializer", a))
    return [(rule, rhs) for rule, rhs in raw if charged(rhs, descs) < charged(t, descs)]


def old_successors(t, descs, zero_flags, absorption=False):
    out = []
    for path in positions(t):
        for rule, rhs in old_root_rewrites(at(t, path), descs, zero_flags, absorption):
            out.append((rule, path, replace(t, path, rhs)))
    return out


def normalize_old(t, descs, zero_flags, absorption=False):
    seen = {t}
    todo = [t]
    while todo:
        u = todo.pop()
        for _, _, new in old_successors(u, descs, zero_flags, absorption):
            if new not in seen:
                seen.add(new)
                todo.append(new)
    return min(seen, key=lambda u: (charged(u, descs), u.show()))


def module(hname, descs):
    n, a = V("n"), V("a")
    body = descs[hname]
    base = A("=", A(hname, Z, a), a)
    step = A("=", A(hname, S(n), a), subst(body, {"v": A(hname, n, a), "w": n}))
    # Binder names are annotations, not extra charged term nodes.
    return A("forall_a", A("and", base, A("forall_n", step)))


def erase_identity_symbol(t, symbol):
    """A fixed homomorphic interpretation; it never rewrites frozen labels."""
    if t.kind == "variable":
        return t
    if t.name == symbol:
        return erase_identity_symbol(t.args[1], symbol)
    return A(t.name, *(erase_identity_symbol(a, symbol) for a in t.args))


def family_checks(maximum=32):
    rows = []
    for j in range(1, maximum + 1):
        v, w = V("v"), V("w")
        fbody, gbody = v, v
        for _ in range(j):
            fbody = A("Q", fbody, Z)
            gbody = S(gbody)
        descs = {"Q": w, "A": S(v), "F": fbody, "G": gbody}
        hbody = A("F", w, A("G", w, v))
        descs["H"] = hbody
        flags = {"F"}
        assert normalize_old(subst(fbody, {"v": Z}), descs, set()) == Z
        assert normalize_old(subst(gbody, {"v": Z}), descs, set()) != Z
        old_moves = old_successors(hbody, descs, flags, absorption=True)
        assert not old_moves, [(rule, path) for rule, path, _ in old_moves]
        composition = subst(fbody, {"v": gbody})
        assert normalize_old(composition, descs, flags, absorption=True) == v
        assert charged(fbody, descs) == 3*j+1
        assert charged(gbody, descs) == j+1
        assert charged(hbody, descs) == 4*j+7
        call = A("H", V("n"), V("a"))
        assert charged(call, descs) == 4*j+10
        assert charged(module("F", descs), descs) == 12*j+19
        assert charged(module("G", descs), descs) == 4*j+19
        assert charged(module("H", descs), descs) == 16*j+43
        image_module = erase_identity_symbol(module("H", descs), "H")
        assert charged(image_module, descs) == 4*j+15
        native_fbody = v
        for _ in range(j):
            native_fbody = A("p", native_fbody)
        native_descs = {"F": native_fbody, "G": gbody, "H": hbody}
        assert charged(native_fbody, native_descs) == j+1
        assert charged(hbody, native_descs) == 2*j+7
        assert charged(call, native_descs) == 2*j+10
        assert charged(module("F", native_descs), native_descs) == 4*j+19
        assert charged(module("H", native_descs), native_descs) == 8*j+43
        native_image = erase_identity_symbol(module("H", native_descs), "H")
        assert charged(native_image, native_descs) == 2*j+15
        rows.append({
            "j": j, "f_descriptor": charged(fbody, descs),
            "g_descriptor": charged(gbody, descs),
            "identity_descriptor": charged(hbody, descs),
            "old_variable_call": charged(call, descs), "new_variable_call": 1,
            "f_module": charged(module("F", descs), descs),
            "g_module": charged(module("G", descs), descs),
            "old_outer_module": charged(module("H", descs), descs),
            "whole_homomorphic_image_module": charged(image_module, descs),
            "old_union_first_steps": len(old_moves),
            "local_composition_certificate": "old normalizer reaches literal v",
            "native_predecessor_counts": {
                "f_descriptor": charged(native_fbody, native_descs),
                "identity_descriptor": charged(hbody, native_descs),
                "old_variable_call": charged(call, native_descs),
                "new_variable_call": 1,
                "f_module": charged(module("F", native_descs), native_descs),
                "g_module": charged(module("G", native_descs), native_descs),
                "old_outer_module": charged(module("H", native_descs), native_descs),
                "whole_homomorphic_image_module": charged(native_image, native_descs),
            },
        })
    return {
        "range": [1, maximum], "rows": rows,
        "old_rule_audit_scope": (
            "All published rule patterns applicable to this family's vocabulary; "
            "not a byte-for-byte implementation of every source optimizer"
        ),
        "source_frozen_descriptors_not_traversed": True,
    }


def numerical_checks():
    def iterate(update, n, a):
        for w in range(n):
            a = update(a, w)
        return a
    count = 0
    for n in range(25):
        for a in range(25):
            f = lambda v, w: v//2
            g = lambda v, w: 2*v + w%2
            assert iterate(f, n, iterate(g, n, a)) == a
            count += 1
    bad_f = lambda v, w: v//2 if w == 0 else max(v-1, 0)
    bad_g = lambda v, w: 2*v if w == 0 else v+1
    assert all(bad_f(bad_g(v, w), w) == v for v in range(20) for w in range(5))
    inner = iterate(bad_g, 2, 2)
    actual = iterate(bad_f, 2, inner)
    assert (inner, actual) == (5, 1)
    return {
        "counter_dependent_inner_examples": count,
        "outer_autonomy_counterexample": {
            "initializer": 2, "counter": 2, "inner_result": inner,
            "outer_result": actual, "expected_if_unsafe_rule_were_true": 2,
        },
    }


def main():
    if not __debug__:
        raise SystemExit("Run without -O: this checker requires assertions")
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("retraction_checks.json"))
    args = parser.parse_args()
    result = {
        "status": "passed", "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "symbolic": symbolic_checks(), "family": family_checks(),
        "finite_examples": numerical_checks(),
        "limits": [
            "The symbolic kernel assumes contextual equation induction; the report derives it.",
            "The complete iPRA equivalence and the general old-normalizer blockage argument are written proofs.",
            "Finite arithmetic examples supplement and do not replace symbolic induction.",
        ],
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "passed", "symbolic_inductions": 3,
                      "rejected_invalid_certificates": 4, "family_instances": 32,
                      "numerical_examples": 625, "receipt": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
