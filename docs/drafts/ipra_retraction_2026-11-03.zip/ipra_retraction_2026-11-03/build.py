#!/usr/bin/env python3
"""Reproduce diagnostics, compile the report, checksum, and optionally ZIP.

Requires only Python's standard library for diagnostics and packaging.
The document requires pdflatex and its preamble's usual LaTeX packages.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


ROOT = Path(__file__).resolve().parent


def run_checked(command: list[str], log: Path) -> None:
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout[-12000:], file=sys.stderr)
        raise SystemExit(f"Command failed; see {log.relative_to(ROOT)}")


def deliverable_files() -> list[Path]:
    return sorted(path for path in ROOT.rglob("*")
                  if path.is_file()
                  and "build" not in path.relative_to(ROOT).parts
                  and "__pycache__" not in path.parts
                  and path.suffix not in {".pyc", ".zip"}
                  and path.name != "SHA256SUMS.txt")


def checksums() -> None:
    records = [f"{hashlib.sha256(p.read_bytes()).hexdigest()}  "
               f"{p.relative_to(ROOT).as_posix()}" for p in deliverable_files()]
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(records) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks-only", action="store_true")
    parser.add_argument("--archive", action="store_true")
    args = parser.parse_args()
    if args.checks_only and args.archive:
        parser.error("--archive requires a complete PDF build")
    for stem in ("retraction", "axioms"):
        run_checked([sys.executable, str(ROOT / "artifacts" / f"check_{stem}.py")],
                    ROOT / "artifacts" / f"check_{stem}_stdout.txt")
    receipts = {
        "retraction": json.loads((ROOT / "artifacts/retraction_checks.json").read_text()),
        "axioms": json.loads((ROOT / "artifacts/axiom_checks.json").read_text()),
    }
    assert all(r["status"] == "passed" for r in receipts.values())
    if args.checks_only:
        print("Both mathematical checkers passed.")
        return
    executable = shutil.which("pdflatex")
    if not executable:
        raise SystemExit("pdflatex is required for a complete report build")
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    for old_log in (ROOT / "artifacts").glob("latex_pass_*.txt"):
        old_log.unlink()
    previous = None
    passes = 0
    for passes in range(1, 6):
        run_checked([executable, "-interaction=nonstopmode", "-halt-on-error",
                     "-file-line-error", "-output-directory", str(build),
                     "report.tex"],
                    ROOT / "artifacts" / f"latex_pass_{passes}.txt")
        state = tuple((build / ("report" + ext)).read_bytes()
                      if (build / ("report" + ext)).exists() else b""
                      for ext in (".aux", ".toc", ".out"))
        if passes >= 2 and state == previous:
            break
        previous = state
    else:
        raise SystemExit("Cross-references did not stabilize in five LaTeX passes")
    log = (build / "report.log").read_text(errors="replace")
    fatal_warnings = [line for line in log.splitlines()
                      if "undefined references" in line or "undefined citations" in line]
    if fatal_warnings:
        raise SystemExit("Unresolved references: " + "\n".join(fatal_warnings))
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
    summary = {
        "status": "passed", "latex_passes": passes,
        "symbolic_induction_certificates": len(receipts["retraction"]["symbolic"]
                                                ["schematic_certificates"]),
        "family_range": receipts["retraction"]["family"]["range"],
        "boundary_ast_cases": receipts["axioms"]["ast_accounting"]
                                      ["boundary_size_instances_checked"],
        "overfull_box_log_lines": [line for line in log.splitlines()
                                   if "Overfull" in line],
        "verification_scope": "Written full mathematical proofs; symbolic equation-"
                              "induction certificates and finite diagnostics. No full "
                              "Lean/Rocq formalization.",
    }
    (ROOT / "artifacts/build_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    checksums()
    if args.archive:
        archive = ROOT.with_suffix(".zip")
        files = deliverable_files() + [ROOT / "SHA256SUMS.txt"]
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for path in sorted(files):
                z.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(archive) as z:
            bad = z.testzip()
            if bad:
                raise SystemExit("Archive integrity failure: " + bad)
        print(f"Created {archive.name} ({archive.stat().st_size:,} bytes)")
    print(f"Both checkers passed; PDF compiled in {passes} passes.")


if __name__ == "__main__":
    main()
