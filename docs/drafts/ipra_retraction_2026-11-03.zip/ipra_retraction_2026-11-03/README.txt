iPRA BY CERTIFIED RETRACTION ELIMINATION
Prepared for Vladimir Reshetnikov, 3 November 2026

Start with report.pdf. Its complete LaTeX source is report.tex plus sections/.
AXIOMS.txt is a compact independent reference specification.

NEW RESULT
If an autonomous update f is a left inverse of each counter-dependent
update g(-,w), then iterating g and then f for the same internal number
of steps returns the initializer. The report gives the internal equation-
induction proof and uses it to eliminate an infinite family of recursors
missed by all four current proposals.

For every complete current source in the stated generated- or native-
predecessor interfaces, its exact image is ordinarily bi-interpretable
and equiconsistent with full first-order iPRA. Every finite axiom image
is no larger. With generated predecessor, a family call4j+10 becomes1,
and its whole ordinary module16j+43 becomes4j+15.

A secondary new generic binder L costs19 to define and makes the scoped
direct boundaryF+m+11, three nodes below the old K4 boundary. Its larger
fixed prefix35 is disclosed. Select complete supported interfaces by
their actual costs; no incompatible prefixes or helpers are mixed.

AUDIT
All four current drafts improve on the three immediately archived ones
and survive the historical filter. The comparison is pinned to
  f26a867c0f5c94ec91e2aa26030720ed5046bca8
in VladimirReshetnikov/ProveIt. All seven source Git blob hashes were
verified. Immutable paths, SHA-256 hashes, decisions and costs are in
provenance/. Source ZIPs are not duplicated.

CONTENTS
  report.pdf, report.tex, sections/     Complete report and source
  AXIOMS.txt                            Exact reference construction
  artifacts/check_retraction.py         Symbolic equational proof checker
  artifacts/retraction_checks.json      Its checked certificates and counts
  artifacts/check_axioms.py             Independent finite diagnostics
  artifacts/axiom_checks.json           Syntax, scan and example results
  provenance/                           Source inventory, audit and costs
  build.py                              Rebuild/check/package script
  SHA256SUMS.txt                        Deliverable checksums

REBUILD
  python3 build.py
  python3 build.py --checks-only
  python3 build.py --archive

The checkers use only Python's standard library. Compiling the PDF needs
pdflatex and the packages listed in report.tex. Intermediate LaTeX output
goes to build/; build logs are saved in artifacts/. Recompilation can
change PDF metadata and therefore its checksum.

VERIFICATION SCOPE
Three schematic induction certificates are checked by a small equality
kernel relative to recursor equations, the local inverse law, and the
equation-induction rule derived in the report. The full first-order
interpretation theorem is a written proof, not a Lean/Rocq formalization.
The independent finite tests cover syntax costs and scope, capture-
avoiding binder expansion, exhaustive small scans, numerical instances,
and negative controls. They do not replace the universal proofs.

The theorem compares full theories and finite axiom image sizes. An
isolated finite packet need not be equivalent by itself to its image,
and a finite proof export can need additional certificate support.
No encoding-independent absolute minimum or proof-length domination is
claimed. These qualifications are part of the result, not open gaps in
the stated ordinary bi-interpretability theorem.
