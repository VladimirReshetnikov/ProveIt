A SMALLER COMPLETE PRESENTATION OF INTUITIONISTIC PRA
Unary closure and implicit premises -- 6 November 2026

MAIN RESULT

The complete strict checker is smaller in every declared whole-program and
core metric than all 14 complete top-level checker variants in the six drafts
at ProveIt commit b9aefe20fe876273886d5d55be49e6ccbefce9ad.

                         Current envelope    This checker
Significant source tokens       522               512
Normalized tokens               526               516
Python AST nodes                537               524
Normalized UTF-8 bytes          1633              1580

Uniform core (imports and CLI removed from all sources):
Normalized tokens               461               458
Python AST nodes                468               458
Normalized UTF-8 bytes          1324              1318

These measurements omit comments/docstrings uniformly. The explanatory
comments are included in the delivered source. Python and its ordinary
standard library are common runtime assumptions. The primary boundary counts
grammar, substitution, inference, computation, JSON parsing, and verdicts.

The mathematical basis is inherited from the unary numerical binder draft:
initialized primitive recursion, equality, existence, and Q_x B, read as
B(0) -> forall x B(x). Every logical and arithmetic rule is stated in the
paper. Full first-order intuitionistic logic and all quantifier-free induction
instances are recovered. The ordinary realization is bi-interpretable with
iPRA, with equality defining both internal composite isomorphisms.

The implementation integrates stack traversal, rigid parameter names,
theorem-only context validation, and shared sorted substitution. No new
arithmetic axiom deletion or absolute shortestness is claimed. A separate
countermodel proves that omitting the retained atomic base would destroy
completeness for the intended interpretation of Q.

START HERE

  report.pdf       Compiled 23-page mathematical report.
  report.tex       Main LaTeX source; section sources are in sections/.
  checker.py       The entire strict acceptance program.
  FORMAT.txt       Concrete syntax, stack instructions, and exact interface.

From this directory, with Python 3.10 or later:

  python3 checker.py examples/basic/equation_induction_at_parameter.json
  python3 checker.py examples/logic/universal_existence.json
  python3 checker.py examples/arithmetic/zero_plus_theorem.json
  python3 checker.py examples/rigid/basic/reflexivity_parameter.json

Successful checks print ACCEPT and exit with status 0. Failure prints REJECT
and exits with status 1. The public document is [goal, stack]; the initial
context is empty. The last stack item is consumed first. Unused leading stack
items are allowed and cannot create additional theorems.

REPRODUCTION

  python3 reproduce.py

This recomputes all measurements and finite validation evidence:

  247 corpus cases checked by both the compact and independent named checker;
  247 exact canonical tree/stack round trips;
  336 evaluations of the frozen original strict tree checker;
  110 focused proof and malformed-syntax fixtures;
   25 independent named-substitution comparisons;
   13 actual command-line boundary cases;
    6 deliberate semantic faults detected.

These are finite regression checks. The universal soundness, completeness,
and bi-interpretability results are mathematical proofs in report.pdf, not
machine-checked metatheorems. No Lean or Rocq verification is asserted.

To rebuild the PDF, install a normal LaTeX distribution with pdfLaTeX and the
packages in report.tex, then run:

  python3 build.py

To regenerate the deterministic ZIP and its internal file hashes:

  python3 package.py

FILES AND PROVENANCE

  comparison/manifest.json   Immutable repository pin, archive/blob hashes,
                             and SHA-256 hashes of every baseline checker.
  comparison/sources/       Byte-identical 14 reference checker programs.
  comparison/measure.py     Whole-program and uniform-core measurement code.
  validation/corpus.py      Proof-tree/stack translators and rigid renamings.
  validation/source_examples.json
                             Frozen source derivations and exact provenance.
  validation/named_reference.py
                             Independent sorted, named-variable rule checker.
  validation/focused.py     Binding, logical, malformed-input, and CLI checks.
  examples/                 68 standalone theorem documents.
  results/                  Machine-readable measurements and validation.
  MANIFEST.sha256            SHA-256 values of the packaged files.
  LICENSE_SOURCE.txt        Included license for inherited source material.

No validation program, translator, comparison script, or theorem database is
imported by checker.py. The original source archives are not required to run
the package. Their exact locations and hashes permit independent re-download.

CONVENTIONS AND LIMITS

iPRA means the full first-order intuitionistic theory with primitive-recursive
defining equations, successor separation/injectivity, and quantifier-free
induction including implication, conjunction, disjunction, and falsity.
Numerical coverage is accounted for explicitly; it is not silently inferred
from equation induction alone. Each recursion is a fixed finite syntactic
description. No uniformly total primitive-recursive evaluator for all such
descriptions is assumed.

Negative integer labels are free variable names, not negative arithmetic
values or extra constants. The mathematical checking algorithm is over finite
trees with unbounded resources. Python memory, integer-decoding, and recursion
limits may reject very large otherwise valid certificates.
