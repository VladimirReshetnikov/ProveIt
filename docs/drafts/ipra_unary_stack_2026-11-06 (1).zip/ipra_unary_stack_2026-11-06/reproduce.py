"""Recompute the complete checker comparison and finite validation evidence."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(script):
    result = subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT,
                            capture_output=True, text=True, timeout=180)
    if result.returncode:
        raise RuntimeError(script + '\n' + result.stdout + '\n' + result.stderr)
    return json.loads(result.stdout)


def main():
    (ROOT / 'results').mkdir(exist_ok=True)
    run('comparison/measure.py')
    corpus = run('validation/corpus.py')
    focused = run('validation/focused.py')
    (ROOT / 'results/focused.json').write_text(json.dumps(focused, indent=2) + '\n')
    if not corpus['all_passed'] or not focused['ok']:
        raise AssertionError('A validation group failed')
    summary = {
        'all_passed': True,
        'corpus_cases': corpus['total_cases'],
        'independent_named_corpus_checks': corpus['independent_named_evaluations'],
        'exact_canonical_roundtrips': corpus['canonical_roundtrips'],
        'frozen_checker_evaluations': corpus['frozen_checker_evaluations'],
        'focused_fixtures': focused['fixture_count'],
        'named_substitution_comparisons': focused['named_substitution_comparisons'],
        'actual_cli_cases': focused['actual_cli_cases'],
        'deliberate_semantic_faults_detected': focused['deliberate_semantic_faults_detected'],
        'limits': 'Finite regression evidence; general correctness and bi-interpretability '
                  'are proved in the report, not machine-verified by this script.'}
    (ROOT / 'results/reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')
    macros = {'CorpusCases': corpus['total_cases'],
              'CorpusSources': corpus['source_cases'],
              'CorpusTheorems': corpus['source_theorems'],
              'CorpusSequents': corpus['source_open_sequents'],
              'RigidVariants': corpus['rigid_variants'],
              'FrozenChecks': corpus['frozen_checker_evaluations'],
              'ExampleCount': corpus['standalone_example_files'],
              'FixtureCount': focused['fixture_count'],
              'SubstitutionCount': focused['named_substitution_comparisons'],
              'CLICount': focused['actual_cli_cases'],
              'FaultCount': focused['deliberate_semantic_faults_detected']}
    (ROOT / 'results/validation_numbers.tex').write_text(''.join(
        '\\newcommand{\\' + name + '}{' + str(value) + '}\n'
        for name, value in macros.items()))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
