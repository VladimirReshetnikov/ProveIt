"""Compile the supplied LaTeX source; requires pdfLaTeX and its named packages."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    if not shutil.which('pdflatex'):
        raise RuntimeError('Install a LaTeX distribution providing pdflatex')
    build = ROOT / '.build'
    build.mkdir(exist_ok=True)
    for number in range(1, 4):
        result = subprocess.run(
            ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
             '-file-line-error', '-output-directory=.build', 'report.tex'],
            cwd=ROOT, capture_output=True, text=True, timeout=120)
        (build / f'pass-{number}.txt').write_text(result.stdout + result.stderr)
        if result.returncode:
            raise RuntimeError(result.stdout[-12000:] + result.stderr)
    log = (build / 'report.log').read_text()
    problems = [line for line in log.splitlines()
                if 'Overfull' in line or 'undefined' in line]
    if problems:
        raise RuntimeError('Unresolved layout or reference issue:\n' + '\n'.join(problems))
    shutil.copyfile(build / 'report.pdf', ROOT / 'report.pdf')
    print('Built report.pdf with resolved references and no overfull boxes.')


if __name__ == '__main__':
    main()
