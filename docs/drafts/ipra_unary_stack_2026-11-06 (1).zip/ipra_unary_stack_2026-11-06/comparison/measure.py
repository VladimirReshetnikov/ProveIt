"""Measure every complete acceptance program at one identical boundary.

The primary boundary includes grammar, substitution, inference, JSON input,
file handling and verdict/rejection. Only comments and actual docstrings are
removed. The same Python runtime and standard library are shared assumptions.
The core diagnostic removes imports and __name__-guarded CLI blocks uniformly.
"""
import ast
import copy
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes')
CORE_FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


def count_tokens(text, omitted=()):
    return sum(tok.type not in IGNORED and not any(
        first <= tok.start and tok.end <= last for first, last in omitted)
        for tok in tokenize.generate_tokens(io.StringIO(text).readline))


def normalized_metrics(tree):
    normalized = ast.unparse(tree) + '\n'
    return {'normalized_tokens': count_tokens(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode('utf-8'))}


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    omitted = []
    for node in list(ast.walk(tree)):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr)
                    and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                omitted.append(((first.lineno, first.col_offset),
                                (first.end_lineno, first.end_col_offset)))
                node.body.pop(0)
    core = copy.deepcopy(tree)
    core.body = [n for n in core.body
                 if not isinstance(n, (ast.Import, ast.ImportFrom))
                 and not (isinstance(n, ast.If)
                          and '__name__' in ast.unparse(n.test))]
    return {'sha256': hashlib.sha256(raw).hexdigest(),
            'raw_bytes': len(raw), 'source_tokens': count_tokens(source, omitted),
            **normalized_metrics(tree), 'core': normalized_metrics(core)}


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['checkers']:
        measured = measure(ROOT / 'comparison' / entry['source'])
        if measured['sha256'] != entry['sha256']:
            raise ValueError('Changed baseline: ' + entry['source'])
        rows.append({**entry, **measured})
    minima = {f: min(row[f] for row in rows) for f in FIELDS}
    core_minima = {f: min(row['core'][f] for row in rows) for f in CORE_FIELDS}
    candidates = {name: measure(ROOT / name)
                  for name in ('checker.py', 'checker_readable.py')
                  if (ROOT / name).exists()}
    primary = candidates['checker.py']
    result = {'python_version': platform.python_version(),
              'repository': manifest['repository'], 'commit': manifest['commit'],
              'boundary': __doc__, 'baseline_count': len(rows),
              'baselines': rows, 'whole_envelope': minima,
              'core_envelope': core_minima, 'candidates': candidates,
              'whole_strict_improvement': {f: primary[f] < minima[f] for f in FIELDS},
              'core_strict_improvement': {f: primary['core'][f] < core_minima[f]
                                          for f in CORE_FIELDS},
              'whole_reduction_percent': {f: 100 * (1 - primary[f] / minima[f])
                                          for f in FIELDS}}
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    labels = {'source_tokens': 'SourceTokens', 'normalized_tokens': 'NormTokens',
              'ast_nodes': 'AST', 'normalized_bytes': 'Bytes'}
    macros = {'BaselineCount': len(rows)}
    for field, label in labels.items():
        macros['Old' + label] = minima[field]
        macros['New' + label] = primary[field]
        if field in CORE_FIELDS:
            macros['OldCore' + label] = core_minima[field]
            macros['NewCore' + label] = primary['core'][field]
    (ROOT / 'results/numbers.tex').write_text(''.join(
        '\\newcommand{\\' + key + '}{' + f'{value:,}' + '}\n'
        for key, value in macros.items()))
    table = ['\\begin{longtable}{@{}p{.39\\linewidth}lrrr@{}}',
             '\\toprule Draft & Variant & AST & Tokens & Bytes\\\\',
             '\\midrule\\endhead']
    for row in rows:
        draft = row['draft'].removeprefix('ipra_').removesuffix('_2026-11-06').replace('_', ' ')
        variant = row['checker'].removeprefix('checker').removesuffix('.py').strip('_') or 'primary'
        table.append(f"{draft} & {variant.replace('_', ' ')} & {row['ast_nodes']} & {row['normalized_tokens']} & {row['normalized_bytes']:,}\\\\")
    table.extend(['\\bottomrule', '\\end{longtable}'])
    (ROOT / 'results/baselines.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({key: result[key] for key in (
        'baseline_count', 'whole_envelope', 'core_envelope', 'candidates',
        'whole_strict_improvement', 'core_strict_improvement')}, indent=2))
    if not all(result['whole_strict_improvement'].values()):
        raise AssertionError('The primary checker does not beat the whole-program envelope')
    if not all(result['core_strict_improvement'].values()):
        raise AssertionError('The primary core does not beat the core envelope')
    return result


if __name__ == '__main__':
    main()
