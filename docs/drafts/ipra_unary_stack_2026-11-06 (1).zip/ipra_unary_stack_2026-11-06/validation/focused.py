"""Focused assurance for the combined strict theorem checker.

No inference kernel imports this file. The fixtures exercise the interfaces
between unary induction, stack ordering, rigid names, and fresh local numbers.
Expected accept/reject values are explicit. A second implementation parses
sorted expressions into named variables and checks the rules independently.
Run: python3 validation/focused.py [--checker PATH]
"""
import argparse
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import types

import named_reference as reference

ROOT = Path(__file__).resolve().parents[1]


def eq(a, b):
    return ['=', a, b]


def succ(a):
    return ['s', a]


def rec(n, a, h):
    return ['r', n, a, h]


def q(body):
    return ['q', body]


def ex(body):
    return ['ex', body]


def lift(a, width=1, formula=False):
    return reference.substitution(a, (width,), formula=formula)


def instance(body, term, formula=True):
    return reference.substitution(body, (term, -1), formula=formula)


def hyp(a):
    return a, [None]


def compute(t):
    _, n, a, h = t
    if n == 0:
        value = a
    else:
        assert n[0] == 's'
        previous = rec(n[1], a, h)
        value = reference.substitution(h, (previous, n[1], -2), formula=False)
    return eq(t, value), [[]]


def transport(major, motive, minor):
    _, left, right = major[0]
    assert minor[0] == instance(motive, left)
    return instance(motive, right), minor[1] + major[1] + [[major[0], motive]]


def reflexivity(t):
    witness = compute(rec(0, t, 0))
    return transport(witness, eq(1, lift(t)), witness)


def q_intro(body, step):
    expected = reference.substitution(body, (succ(1), 0))
    assert step[0] == expected
    return q(body), step[1] + [[]]


def q_elim(major, witness, base):
    assert major[0][0] == 'q'
    assert base[0] == instance(major[0][1], 0)
    return (instance(major[0][1], witness),
            base[1] + major[1] + [[major[0], witness]])


def ex_intro(body, witness, opened):
    assert opened[0] == body
    return ex(body), opened[1] + [[witness]]


def ex_elim(major, goal, opened, annotation=None):
    assert major[0][0] == 'ex'
    assert opened[0] == lift(goal, formula=True)
    return goal, opened[1] + major[1] + [[major[0], annotation]]


def reflexivity_without_computation(t):
    """Derive t=t from existence and transport alone, with no R0/RS leaf."""
    witness_equation = eq(1, lift(t))
    existence = ex_intro(witness_equation, t, hyp(witness_equation))
    opened = transport(hyp(witness_equation), eq(1, lift(t, 2)),
                       hyp(witness_equation))
    return ex_elim(existence, eq(t, t), opened)


def explode_equation(goal):
    """A certificate of a=b under 0=S0, using only fixed recursor equations."""
    _, a, b = goal
    zero_selector = rec(0, a, lift(b, 2))
    one_selector = rec(succ(0), a, lift(b, 2))
    selector_motive = rec(1, lift(a), lift(b, 3))
    first = transport(hyp(eq(0, succ(0))),
                      eq(lift(zero_selector), selector_motive),
                      reflexivity(zero_selector))
    second = transport(compute(zero_selector), eq(1, lift(one_selector)), first)
    return transport(compute(one_selector), eq(lift(a), 1), second)


def fixtures():
    rows = []

    def add(name, proof, expected=True, context=()):
        goal, stack = proof
        rows.append(dict(name=name, goal=goal, stack=stack,
                         context=list(context), expected=expected))

    true = eq(0, 0)
    falsehood = eq(0, succ(0))
    add('reflexivity_zero', reflexivity(0))
    add('reflexivity_rigid', reflexivity(-1))
    add('reflexivity_large_rigid', reflexivity(-(10 ** 80)))
    add('reflexivity_large_ordinary', reflexivity(1000))
    compound = rec(2, -1, rec(3, 1, succ(4)))
    for label, term in [('rigid', -1), ('compound', compound)]:
        proof = reflexivity_without_computation(term)
        assert [] not in proof[1]
        add('pure_logical_reflexivity_' + label, proof)
    add('different_rigid_parameters', (eq(-1, -2), reflexivity(-1)[1]), False)
    add('rigid_parameter_is_not_zero', (eq(-1, 0), reflexivity(-1)[1]), False)
    add('closed_contradiction', (falsehood, reflexivity(0)[1]), False)

    add('zero_returns_rigid_initializer', compute(rec(0, -1, -2)))
    add('zero_wrong_initializer', (eq(rec(0, -1, -2), -2), [[]]), False)
    add('successor_previous_counter', compute(rec(succ(-1), -2, 2)))
    add('successor_previous_value', compute(rec(succ(-1), -2, 1)))
    add('successor_swapped_update_slots',
        (eq(rec(succ(-1), -2, 1), -1), [[]]), False)
    update = rec(0, 2, 3)
    nested = rec(succ(-1), -2, update)
    add('nested_update_capture_avoiding',
        (eq(nested, rec(0, -1, rec(-1, -2, update))), [[]]))
    add('nested_update_wrong_counter',
        (eq(nested, rec(0, -2, rec(-1, -2, update))), [[]]), False)
    add('outer_positive_parameter_in_update',
        (eq(rec(succ(1), -2, 3), 1), [[]]))
    add('outer_positive_parameter_shift_error',
        (eq(rec(succ(1), -2, 3), 3), [[]]), False)
    for label, counter in [('rigid', -1), ('ordinary', 1), ('recursor', rec(0, 0, 0))]:
        add('nonconstructor_counter_' + label,
            (eq(rec(counter, 0, 0), 0), [[]]), False)

    add('existence_rigid', ex_intro(eq(1, -1), -1, hyp(eq(1, -1))))
    add('existence_ordinary_parameter',
        ex_intro(eq(1, succ(2)), succ(1), hyp(eq(1, succ(2)))))
    add('existence_witness_capture', (ex(eq(1, succ(1))), [None, [succ(1)]]), False)
    add('existence_wrong_rigid', (ex(eq(1, -1)), [None, [-2]]), False)
    add('existence_retains_ordinary_context',
        ex_intro(eq(2, 0), 0, hyp(eq(2, 0))), True, [eq(1, 0)])
    add('nested_exists_same_witness',
        ex_intro(ex(eq(1, 2)), -1,
                 ex_intro(eq(1, 2), 1, hyp(eq(1, 2)))))
    exists_zero = ex_intro(eq(1, 0), 0, hyp(eq(1, 0)))
    add('existential_elimination', ex_elim(exists_zero, true, reflexivity(0)))
    add('existential_unused_annotation',
        ex_elim(exists_zero, true, reflexivity(0), {'unused': [False, 'opaque']}))
    add('existential_eigenvariable_escape',
        (eq(1, 0), [None, None, [exists_zero[0], None]]), False,
        [exists_zero[0]])
    add('existential_retains_old_parameter',
        (eq(1, 0), [None, None, [exists_zero[0], None]]), True,
        [exists_zero[0], eq(1, 0)])
    nested_goal = q(eq(2, 0))
    nested_major = ex(nested_goal)
    add('nested_existential_eigenvariable_escape',
        (nested_goal, [None, None, [nested_major, None]]), False, [nested_major])

    # The equation induction hypothesis is useful only for an atomic matrix.
    iteration = eq(rec(1, 0, succ(1)), 1)
    iterated_step = rec(succ(1), 0, succ(1))
    step = transport(hyp(iteration), eq(lift(iterated_step), succ(1)),
                     compute(iterated_step))
    induction = q_intro(iteration, step)
    add('equation_induction', induction)
    add('equation_induction_at_rigid',
        q_elim(induction, -3, compute(rec(0, 0, succ(1)))))
    quantified_matrix = ex(lift(iteration, formula=True))
    target_step = reference.substitution(quantified_matrix, (succ(1), 0))
    # Illicitly use the quantified IH, then its equation matrix, as if full
    # induction were available. Correct QI supplies only its zero instance.
    major = quantified_matrix
    repacked = ex_intro(lift(target_step, formula=True)[1], 0,
                        transport(hyp(eq(rec(3, 0, succ(1)), 3)),
                          eq(lift(rec(succ(3), 0, succ(1))), succ(1)),
                          compute(rec(succ(3), 0, succ(1)))))
    illegal_step = ex_elim(hyp(major), target_step, repacked)
    add('forbidden_quantified_induction', q_intro(quantified_matrix, illegal_step), False)

    # A base-dependent atomic closure: (0=1) implies every x=1.
    add('equation_closure_needs_base',
        q_intro(eq(1, succ(0)), explode_equation(eq(succ(1), succ(0)))))
    add('rigid_parameter_context_under_q',
        q_intro(eq(-1, 0), hyp(eq(-1, 0))), True, [eq(-1, 0)])
    add('ordinary_parameter_context_under_q',
        q_intro(eq(2, 0), hyp(eq(2, 0))), True, [eq(1, 0)])
    add('q_context_variable_capture', (q(eq(1, 0)), [None, []]), False, [eq(1, 0)])

    # Matrix congruence across equation/compound roots. The equation target
    # must retain its base independently of its optional induction hypothesis.
    atomic = eq(1, -1)
    compound_matrix = ex(eq(2, -1))
    atomic_closure = q(atomic)
    compound_closure = q(compound_matrix)
    base_exists = ex_intro(eq(0, -1), 0, hyp(eq(0, -1)))
    step_exists = q_elim(hyp(compound_closure), succ(1), base_exists)
    step_atom = ex_elim(step_exists, eq(succ(1), -1), hyp(eq(succ(2), -1)))
    add('q_congruence_compound_to_equation', q_intro(atomic, step_atom),
        True, [compound_closure])
    recovered_base = ex_elim(hyp(ex(eq(0, -1))), eq(0, -1), hyp(eq(0, -1)))
    opened_atom = q_elim(hyp(atomic_closure), succ(2), recovered_base)
    repacked_step = ex_intro(eq(succ(2), -1), 0, opened_atom)
    add('q_congruence_equation_to_compound', q_intro(compound_matrix, repacked_step),
        True, [atomic_closure])

    equality = eq(1, 0)
    motive = ex(eq(1, 2))
    source_exists = ex_intro(eq(1, 2), 1, hyp(eq(1, 2)))
    add('formula_transport_beneath_exists',
        transport(hyp(equality), motive, source_exists), True, [equality])
    add('failed_major_hypothesis_fallback',
        (true, [None, [ex(true), None]]), True, [true])
    add('failed_major_no_new_theorem',
        (falsehood, [None, [ex(true), None]]), False, [true])
    add('arbitrary_hypothesis_annotation',
        (q(true), [{'this is a hypothesis annotation': True}, []]))

    trivial_q = q_intro(true, hyp(true))
    trivial_instance = q_elim(trivial_q, -7, reflexivity(0))
    add('strict_vacuous_rigid_witness', trivial_instance)
    add('missing_base_proof',
        (true, [None] + trivial_q[1] + [[trivial_q[0], 0]]), False)
    add('swapped_major_minor_stack',
        (true, trivial_q[1] + reflexivity(0)[1] + [[trivial_q[0], 0]]), False)
    add('empty_stack', (true, []), False)
    add('missing_major_stack', (true, [[trivial_q[0], 0]]), False)
    add('unused_stack_prefix', (true, [{'opaque unused prefix': False}] + reflexivity(0)[1]))
    bad_terms = [False, True, 0.0, '0', None, [], ['s'], ['s', 0, 0],
                 q(true), rec(0, 0, true), {'s': 0}]
    for index, bad in enumerate(bad_terms):
        stack = reflexivity(0)[1] + trivial_q[1] + [[trivial_q[0], bad]]
        add('strict_vacuous_witness_%02d' % index, (true, stack), False)
        add('strict_existence_witness_%02d' % index,
            (ex(eq(1, 1)), reflexivity(1)[1] + [[bad]]), False)
        add('dead_malformed_update_%02d' % index,
            (eq(rec(0, 0, bad), 0), [[]]), False)
    bad_formulas = [False, 0, 'q', [], ['q'], ['q', true, true], ['ex', 0],
                    eq(False, 0), eq(0.0, 0), ['pi', true, true], ['bot'],
                    ['=', 0], ['=', 0, 0, 0]]
    for index, bad in enumerate(bad_formulas):
        add('malformed_goal_%02d' % index, (bad, [None]), False)
        add('malformed_motive_%02d' % index,
            (true, reflexivity(0)[1] + reflexivity(0)[1] + [[true, bad]]), False)
    return rows


def load_kernel(path):
    spec = importlib.util.spec_from_file_location('focused_candidate', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def candidate_accepts(kernel, goal, stack, context=()):
    try:
        return bool(kernel.check(copy.deepcopy(goal), copy.deepcopy(stack),
                                 copy.deepcopy(list(context))))
    except Exception:
        return False


def run(checker):
    kernel = load_kernel(checker)
    records = []
    rows = fixtures()
    for row in rows:
        actual = candidate_accepts(kernel, row['goal'], row['stack'], row['context'])
        independent = reference.accept_sequent(row['goal'], row['stack'], row['context'])
        records.append(dict(name=row['name'], expected=row['expected'],
                            candidate=actual, named_reference=independent,
                            ok=actual == independent == row['expected']))

    substitution_records = []
    expressions = [
        (False, -13), (False, rec(succ(-1), 2, rec(2, 1, succ(4)))),
        (False, rec(1, -2, rec(3, 4, 5))),
        (True, ex(q(eq(rec(3, -7, succ(4)), 2)))),
        (True, q(ex(eq(3, rec(2, -1, 5))))),
    ]
    environments = [(1,), (0,), (-9, -1), (succ(1), 0),
                    (rec(-1, 1, 2), -2, -2)]
    for index, (formula, expression) in enumerate(expressions):
        for j, environment in enumerate(environments):
            expected = reference.substitution(expression, environment, formula=formula)
            actual = kernel.subst(copy.deepcopy(expression), environment, formula=formula)
            substitution_records.append(dict(name='substitution_%d_%d' % (index, j),
                                              ok=actual == expected))

    cli_records = []
    true, proof = reflexivity(0)
    documents = [
        ('valid_theorem', [true, proof], True),
        ('pure_logical_rigid_reflexivity', list(reflexivity_without_computation(-1)), True),
        ('extra_context_injection', [eq(0, succ(0)), [None], [eq(0, succ(0))]], False),
        ('extra_top_level_field', [true, proof, None], False),
        ('missing_proof', [true], False),
        ('nonlist_stack', [true, {'instruction': []}], False),
        ('numeric_stack', [true, 0], False),
        ('boolean_goal', [False, [None]], False),
        ('null_document', None, False),
        ('object_document', {'goal': true, 'stack': proof}, False),
    ]
    with tempfile.TemporaryDirectory(prefix='ipra-focused-') as directory:
        file = Path(directory) / 'proof.json'
        for name, document, expected in documents:
            file.write_text(json.dumps(document), encoding='utf-8')
            result = subprocess.run([sys.executable, str(checker), str(file)],
                                    capture_output=True, text=True, timeout=15)
            actual = result.returncode == 0 and result.stdout.strip() == 'ACCEPT'
            cli_records.append(dict(name=name, expected=expected, accepted=actual,
                                    ok=actual == expected))
        for name, content in [('malformed_json', '{'), ('trailing_json', '[0,0] [0,0]')]:
            file.write_text(content, encoding='utf-8')
            result = subprocess.run([sys.executable, str(checker), str(file)],
                                    capture_output=True, text=True, timeout=15)
            cli_records.append(dict(name=name,
                                    ok=result.returncode != 0 and result.stdout.strip() == 'REJECT'))
        file.write_text(json.dumps([true, proof]), encoding='utf-8')
        result = subprocess.run([sys.executable, str(checker), str(file), 'extra'],
                                capture_output=True, text=True, timeout=15)
        cli_records.append(dict(name='extra_cli_argument',
                                ok=result.returncode != 0 and result.stdout.strip() == 'REJECT'))

    # Deliberate semantic faults check that the selected regression cases
    # exercise the advertised invariant. These modules are never saved or
    # used for acceptance; only the unmodified kernel is delivered.
    mutation_records = []
    source = checker.read_text(encoding='utf-8')
    by_name = {row['name']: row for row in rows}
    mutations = [
        ('unrestricted_induction', "[b] * (b[0] == '=')", '[b]',
         'forbidden_quantified_induction'),
        ('omit_equation_base', "[subst(b, [0, 0])] + [b] * (b[0] == '=')",
         "[b] if b[0] == '=' else [subst(b, [0, 0])]", 'equation_closure_needs_base'),
        ('context_capture', '[*map(subst, g), *h]', '[*g, *h]',
         'existence_retains_ordinary_context'),
        ('existential_escape', 'b, h = subst(a), parts', 'b, h = a, parts',
         'existential_eigenvariable_escape'),
        ('unchecked_vacuous_witness', '                    subst(t, formula=False)\n', '',
         'strict_vacuous_witness_00'),
        ('update_slot_swap', "[['r', n, t, h], n, -2]", "[n, ['r', n, t, h], -2]",
         'successor_previous_counter'),
    ]
    for name, old, new, fixture in mutations:
        if source.count(old) != 1:
            raise ValueError('Semantic mutation anchor changed: ' + name)
        mutant = types.ModuleType('deliberate_fault_' + name)
        exec(compile(source.replace(old, new), '<deliberate fault ' + name + '>', 'exec'),
             mutant.__dict__)
        row = by_name[fixture]
        actual = candidate_accepts(mutant, row['goal'], row['stack'], row['context'])
        mutation_records.append(dict(name=name, fixture=fixture,
                                     original_expected=row['expected'], mutated=actual,
                                     ok=actual != row['expected']))

    groups = [records, substitution_records, cli_records, mutation_records]
    return dict(ok=all(row['ok'] for group in groups for row in group),
                fixture_count=len(records),
                named_substitution_comparisons=len(substitution_records),
                actual_cli_cases=len(cli_records),
                deliberate_semantic_faults_detected=sum(row['ok'] for row in mutation_records),
                proof_cases=records, substitutions=substitution_records, cli_cases=cli_records,
                semantic_faults=mutation_records,
                limits='Finite regression evidence, not a formal metatheorem. The named oracle '
                       'does not call the compact kernel or its substitution algorithm.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, default=ROOT / 'checker.py')
    args = parser.parse_args()
    report = run(args.checker.resolve())
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report['ok'] else 1)
