"""Finite regression corpus, certificate translations, and parameter renamings.

This is untrusted validation code. The primary checker never imports it.
The frozen corpus records exact repository provenance. Its tests compare the
new stack checker, the original strict unary tree checker, and an independent
named-variable stack checker. Passing finitely many cases is not a universal
machine-checked proof of soundness, completeness, or bi-interpretability.

Run from any working directory with ``python3 validation/corpus.py``.
"""
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def map_syntax(expression, variable, depth=0, formula=True):
    """Traverse sorted syntax, explicitly accounting for each local binder."""
    if not formula and type(expression) is int:
        return variable(expression, depth)
    tag, *arguments = expression
    if formula:
        if tag == '=' and len(arguments) == 2:
            return [tag, *(map_syntax(term, variable, depth, False)
                           for term in arguments)]
        if tag in ('q', 'ex') and len(arguments) == 1:
            return [tag, map_syntax(arguments[0], variable, depth + 1, True)]
    else:
        if tag == 's' and len(arguments) == 1:
            return [tag, map_syntax(arguments[0], variable, depth, False)]
        if tag == 'r' and len(arguments) == 3:
            index, initial, body = arguments
            return [tag, map_syntax(index, variable, depth, False),
                    map_syntax(initial, variable, depth, False),
                    map_syntax(body, variable, depth + 2, False)]
    raise ValueError('Malformed corpus syntax')


def lift(expression, amount=1, formula=True):
    def variable(index, depth):
        return index + amount if index > depth else index
    return map_syntax(expression, variable, formula=formula)


def substitute(expression, replacements, offset, formula=True):
    """Reference prefix substitution using an explicit binder-aware visitor."""
    def variable(index, depth):
        relative = index - depth
        if relative <= 0:
            return index
        if relative <= len(replacements):
            return lift(replacements[relative - 1], depth, formula=False)
        return index + offset
    return map_syntax(expression, variable, formula=formula)


def step_goal(goal):
    return substitute(goal[1], [['s', 1]], 0)


def elimination_premise(major, auxiliary, goal):
    tag, *parts = major
    if tag == 'ex':
        return lift(goal)
    if tag == 'q':
        return substitute(parts[0], [0], -1)
    if tag == '=':
        return substitute(auxiliary, [parts[0]], -1)
    raise ValueError('Unknown elimination in source certificate')


def proof_kind(goal, proof):
    """Identify the canonical subset used by the inherited certificates."""
    if goal[0] == 'q' and type(proof) is list and len(proof) == 1:
        return 'Q introduction'
    if goal[0] == 'ex' and type(proof) is list and len(proof) == 2:
        return 'existential introduction'
    if type(proof) is list and len(proof) >= 3:
        major = proof[0]
        if type(major) is list and major[0] in ('=', 'q', 'ex'):
            return {'=': 'equality transport', 'q': 'Q elimination',
                    'ex': 'existential elimination'}[major[0]]
    if proof == 'r':
        return 'recursion equation'
    if proof is None:
        return 'hypothesis'
    raise ValueError('Certificate lies outside the canonical corpus format')


def tree_to_stack(goal, proof):
    """Compile a canonical tree to a stack, without invoking either checker."""
    def preorder(current, tree):
        kind = proof_kind(current, tree)
        if kind == 'Q introduction':
            return [[], *preorder(step_goal(current), tree[0])]
        if kind == 'existential introduction':
            witness, child = tree
            return [[witness], *preorder(current[1], child)]
        if kind in ('equality transport', 'Q elimination',
                    'existential elimination'):
            major, major_proof, *arguments = tree
            if kind == 'existential elimination':
                auxiliary, child = None, arguments[0]
            else:
                auxiliary, child = arguments
            premise = elimination_premise(major, auxiliary, current)
            return [[major, auxiliary], *preorder(major, major_proof),
                    *preorder(premise, child)]
        return [[]] if kind == 'recursion equation' else [None]
    return list(reversed(preorder(goal, proof)))


def stack_to_tree(goal, stack, statistics=None):
    """Decode canonical stacks and require their exact exhaustion.

    This auxiliary decoder is deliberately stricter about unused stack
    prefixes than the primary acceptance program. It is a regression check,
    not an alternative definition of which public documents are accepted.
    """
    remaining = deepcopy(stack)
    counts = Counter()

    def visit(current):
        instruction = remaining.pop()
        if current[0] == 'q' and instruction == []:
            counts['Q introduction'] += 1
            return [visit(step_goal(current))]
        if (current[0] == 'ex' and type(instruction) is list
                and len(instruction) == 1):
            counts['existential introduction'] += 1
            return [instruction[0], visit(current[1])]
        if (type(instruction) is list and len(instruction) == 2
                and type(instruction[0]) is list):
            major, auxiliary = instruction
            major_proof = visit(major)
            premise = elimination_premise(major, auxiliary, current)
            child = visit(premise)
            if major[0] == 'ex':
                counts['existential elimination'] += 1
                return [major, major_proof, child]
            counts['Q elimination' if major[0] == 'q' else
                   'equality transport'] += 1
            return [major, major_proof, auxiliary, child]
        if instruction == []:
            counts['recursion equation'] += 1
            return 'r'
        if instruction is None:
            counts['hypothesis'] += 1
            return None
        raise ValueError('Noncanonical stack annotation')

    tree = visit(goal)
    if remaining:
        raise ValueError('Canonical decoder found an unused stack prefix')
    if statistics is not None:
        statistics.update(counts)
    return tree


def rename_case(case, mapping):
    """Rename root parameters in formulas, terms, and all proof annotations.

    Positive source keys denote free slots at the root of the sequent.
    Negative keys denote rigid parameters. Local eigenvariables and binders
    are protected. A positive destination is re-lifted under those binders;
    a negative destination remains rigid. In equality motives, placeholder
    slot 1 is additionally protected.
    """
    def rename(expression, opened=0, local=0, formula=True):
        def variable(index, depth):
            boundary = opened + depth
            if index < 0:
                target = mapping(index)
            elif index > boundary:
                target = mapping(index - boundary)
            else:
                return index
            return target if target < 0 else target + boundary
        return map_syntax(expression, variable, local, formula)

    def proof(current, tree, opened=0):
        kind = proof_kind(current, tree)
        if kind == 'Q introduction':
            return [proof(step_goal(current), tree[0], opened + 1)]
        if kind == 'existential introduction':
            witness, child = tree
            return [rename(witness, opened, formula=False),
                    proof(current[1], child, opened + 1)]
        if kind in ('equality transport', 'Q elimination',
                    'existential elimination'):
            major, major_proof, *arguments = tree
            prefix = [rename(major, opened), proof(major, major_proof, opened)]
            if kind == 'existential elimination':
                return [*prefix, proof(lift(current), arguments[0], opened + 1)]
            auxiliary, child = arguments
            renamed_auxiliary = rename(auxiliary, opened,
                                       local=int(major[0] == '='),
                                       formula=major[0] == '=')
            premise = elimination_premise(major, auxiliary, current)
            return [*prefix, renamed_auxiliary, proof(premise, child, opened)]
        return deepcopy(tree)

    return {**case, 'goal': rename(case['goal']),
            'context': [rename(item) for item in case['context']],
            'proof': proof(case['goal'], case['proof'])}


def free_names(case):
    names = set()

    def collect(name):
        names.add(name)
        return name

    rename_case(case, collect)
    return names


def safe_accept(checker, goal, proof, context):
    try:
        return bool(checker.check(deepcopy(goal), deepcopy(proof),
                                  deepcopy(context)))
    except Exception:
        return False


def main():
    corpus = json.loads((ROOT / 'validation/source_examples.json').read_text())
    reference_path = ROOT / corpus['reference_checker']['path']
    expected_hash = corpus['reference_checker']['sha256']
    if hashlib.sha256(reference_path.read_bytes()).hexdigest() != expected_hash:
        raise ValueError('The frozen original strict checker has changed')
    old = load_module('corpus_frozen_tree_checker', reference_path)
    new = load_module('corpus_new_stack_checker', ROOT / 'checker.py')
    named = load_module('corpus_named_reference',
                        ROOT / 'validation/named_reference.py')
    failures, rows = [], []
    rules = Counter()
    examples = []

    def record(case, variant, require_old):
        goal, proof, context = case['goal'], case['proof'], case['context']
        stack = tree_to_stack(goal, proof)
        decoded = stack_to_tree(goal, stack, rules)
        result = {'id': case['id'], 'variant': variant,
                  'open_context': bool(context), 'stack_items': len(stack),
                  'tree_roundtrip_exact': decoded == proof,
                  'candidate_accepted': safe_accept(new, goal, stack, context),
                  'named_reference_accepted': named.accept_sequent(goal, stack, context)}
        if require_old:
            # The theorem-only frozen checker assumes internal contexts are
            # sorted; validate externally supplied corpus contexts explicitly.
            for assumption in context:
                old.subst(assumption)
            result['frozen_tree_accepted'] = safe_accept(old, goal, proof, context)
            result['decoded_tree_accepted'] = safe_accept(old, goal, decoded, context)
        for field, value in result.items():
            if (field.endswith('_accepted') or field == 'tree_roundtrip_exact') and not value:
                failures.append({'id': case['id'], 'variant': variant, 'check': field})
        rows.append(result)
        if not context and variant in ('original', 'rigid'):
            group = 'rigid/' if variant == 'rigid' else ''
            path = ROOT / 'examples' / group / (case['id'] + '.json')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps([goal, stack], separators=(',', ':')) + '\n')
            examples.append(str(path.relative_to(ROOT)))

    rigid_count = 0
    for source in corpus['cases']:
        record(source, 'original', True)
        names = free_names(source)
        positives = {name for name in names if name > 0}
        if not positives:
            continue
        if any(name < 0 for name in names):
            raise ValueError('Inherited corpus unexpectedly contains rigid names')
        rigid = rename_case(source, lambda name: -name)
        record(rigid, 'rigid', False)
        rigid_count += 1
        fresh_offset = max(positives)
        eliminated = rename_case(rigid, lambda name: fresh_offset - name
                                 if name < 0 else name)
        if any(name < 0 for name in free_names(eliminated)):
            raise ValueError('Rigid elimination left a negative parameter')
        record(eliminated, 'fresh_slot_elimination', True)

    result = {
        'scope': 'Finite regression evidence; no universal machine proof is claimed.',
        'python': sys.version,
        'source_commit': corpus['commit'],
        'source_cases': len(corpus['cases']),
        'source_theorems': sum(not row['context'] for row in corpus['cases']),
        'source_open_sequents': sum(bool(row['context']) for row in corpus['cases']),
        'rigid_variants': rigid_count,
        'fresh_slot_eliminations': rigid_count,
        'total_cases': len(rows),
        'standalone_example_files': len(examples),
        'canonical_roundtrips': len(rows),
        'frozen_checker_evaluations': 2 * (len(corpus['cases']) + rigid_count),
        'candidate_evaluations': len(rows),
        'independent_named_evaluations': len(rows),
        'rule_occurrences': dict(sorted(rules.items())),
        'all_passed': not failures,
        'failures': failures,
        'example_files': examples,
        'cases': rows,
    }
    (ROOT / 'results').mkdir(exist_ok=True)
    (ROOT / 'results/corpus.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('cases', 'example_files')}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
