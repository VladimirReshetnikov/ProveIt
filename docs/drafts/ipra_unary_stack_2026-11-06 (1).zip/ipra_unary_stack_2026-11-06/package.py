"""Make a deterministic archive and its internal SHA-256 file manifest."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'.build', '__pycache__', '.git'}


def files():
    return sorted(path for path in ROOT.rglob('*')
                  if path.is_file() and not EXCLUDED.intersection(path.relative_to(ROOT).parts)
                  and path.name != 'MANIFEST.sha256'
                  and path.suffix not in ('.pyc', '.zip', '.aux', '.log', '.out', '.toc'))


def main():
    if not (ROOT / 'report.pdf').exists():
        raise RuntimeError('Compile report.pdf before packaging')
    selected = files()
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(
        hashlib.sha256(path.read_bytes()).hexdigest() + '  '
        + path.relative_to(ROOT).as_posix() + '\n' for path in selected))
    archive = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as output:
        for path in sorted([*selected, manifest]):
            info = zipfile.ZipInfo(ROOT.name + '/' + path.relative_to(ROOT).as_posix(),
                                   date_time=(2026, 11, 6, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            output.writestr(info, path.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(archive) as check:
        bad = check.testzip()
        if bad:
            raise RuntimeError('Corrupt archive member: ' + bad)
    print(str(archive))
    print('SHA-256 ' + hashlib.sha256(archive.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
