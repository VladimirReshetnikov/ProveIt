BJ EQUATIONAL CERTIFICATES
=========================

Scope
-----
checker.py is an independent, readable checker for the numerical reduction
in this report. It is NOT a complete first-order iPRA proof checker and no
checker-size record is claimed for it. It checks symbolic equations at
arbitrary free numerical parameters, rather than sampled numeral values.

The only numerical computation schemas it trusts are:

  B(B(0,a),b) = a
  J(0;u.h) = 0
  J(B(0,n);u.h) = h[J(n;u.h)/u].

Here S(a) abbreviates B(0,a). The JSON syntax has no S constructor and no
arithmetic macros. The symbol h in a JSON node ["h",t] is a fixed,
uninterpreted unary operation. It represents an arbitrary previously formed
update template, with passive parameters fixed. It is not a quantified
function variable or an evaluation oracle. Replacing it throughout a proof
by any fixed capture-avoiding source term gives the corresponding source
instance.

This external specialization first gives passive template parameters fresh
names absent from the entire certificate, including reference-substitution
domains, and freshens eigenvariables and binders. Expand the template before
finally instantiating those passive parameters. This avoids a reference's
substitution accidentally acting on an identically named fixed parameter.
No general executable schema-specialization translator is claimed here.

The other checked rules are reflexivity, symmetry, transitivity, numerical
term congruence, references to earlier checked lemmas with simultaneous
capture-avoiding substitution, local equation hypotheses, and induction on
one literal equation. The induction eigenvariable must be fresh for its
matrix, target, and all retained hypotheses. Forward references reject.
Congruence inside a J update concerns passive numerical parameters of a
fixed template. Capture avoidance never binds a free variable of the
equation premise as the iterator state.
There is no numerical evaluation, automatic rewriting, normalization,
coverage axiom, separation axiom, quantified induction, or theorem oracle.

Term syntax
-----------
  0                       numerical zero
  ["v", "x"]              a numerical variable
  ["B", a, b]             the binary gate
  ["h", a]                the fixed unary update template
  ["J", n, "u", body]     zero-seed iteration, binding u only in body

Terms are checked for exact constructor arities. Python booleans are not
numerical zero. Substitution explicitly renames binders to avoid capture.
Alpha-equivalence is compared by de Bruijn keys without reducing numerical
terms. The parser uses JSON data and never executes submitted code.

Theorems
--------
The untrusted producer expands these definitions before writing JSON:

  W(x)       = B(x,0)
  sigma(x)   = J(x;u.S(0))
  C(n,a,b)   = W(B(B(sigma(n),S(a)),b))
  P(n)       = C(n,0,W(n))
  H(u,a)     = C(u,S(a),S(h(P(u))))
  V(n,a)     = J(S(n);u.H(u,a))
  I(n,a)     = P(V(n,a)).

bj_equations.json checks the following 14 generic equations in order:

  sigma(0)=0                      sigma(S(n))=S(0)
  W(S(n))=n
  C(0,a,b)=a                      C(S(n),a,b)=b
  P(0)=0                          P(S(n))=n
  H(0,a)=S(a)                     H(S(x),a)=S(h(x))
  V(0,a)=S(a)                     V(S(n),a)=H(V(n,a),a)
  S(P(V(n,a)))=V(n,a)
  I(0,a)=a                        I(S(n),a)=h(I(n,a)).

The range equation uses the packet's sole induction node.
All earlier equations use computation and equational logic alone. The
initializer successor theorem uses the checked range theorem. Thus the
arbitrary-initializer compiler does not require numerical coverage.

The count is one EXPLICIT induction node in this binder-level certificate.
In a strict staged first-order elaboration, separately declared iterator
symbols for substituted bodies are related by a derived coherence lemma,
proved with equation induction. Expanding such admissible binder macros
may introduce additional inductions. No extra numerical axiom is needed.

Reproduction
------------
From the package root:

  python3 code/produce.py
  python3 code/checker.py < certificates/bj_equations.json
  python3 code/validate.py

The direct checking command prints ACCEPT and exits zero. Rejections print
REJECT, an explanatory diagnostic on stderr, and exit one. The producer and
validator are untrusted supporting programs; the checker imports neither.

validate.py checks the distributed main packet against the producer, checks
two explicit positive capture-avoidance examples, and runs all positive and
negative packets as fresh ordinary and optimized (-O) Python processes.
Negative controls cover malformed B computations and terms, a wrong range
matrix, a wrong h update, a bad induction base, a nonfresh eigenvariable,
an unavailable hypothesis, a forward reference, a wrong successor counter,
forged top-level assumptions, Boolean zero aliases, quantified matrices,
and two deliberately captured conclusions. It writes validation.json.

Validation is finite evidence about these programs and certificates. The
universal soundness proof of the checker, the entire iPRA interpretation,
and the Python runtime have not been verified by Lean, Rocq, or Isabelle.
As with ordinary finite implementations, resource exhaustion can reject
sufficiently large otherwise valid certificates.
