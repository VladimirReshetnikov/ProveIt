THREE COMPUTATION SCHEMAS FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
Research prepared for Vladimir Reshetnikov, 9 November 2026 (Pacific date)
=======================================================================

RESULT
------
The new numerical basis has 0, one binary operation B, and zero-seeded
iteration J. Successor is S(x)=B(0,x). Its three computation schemas are:

  B(B(0,a),b)=a
  J(0;u.h)=0
  J(B(0,n);u.h)=h[J(n;u.h)/u].

A short direct term gives an unrestricted selector and predecessor.
An equation invariant recovers arbitrary initialized iteration. The report
states every ordinary or native logical rule, constructs actual equality
reflection and a fixed-description primitive-recursion compiler, and proves
whole-domain bi-interpretability and equiconsistency with first-order iPRA.
Both numerical isomorphisms have graph x=y.

STATUS
------
This is a new mathematical simplification relative to the inspected
four-schema finite-initializer proposal. It does NOT establish a new
smallest complete proof checker or meet the requested global minimization.
No absolute minimum or literature-wide priority is claimed.

The symbolic evidence checker is a supporting equational-fragment checker,
not a complete iPRA checker. Its 14 generic equations have 76 proof-node
occurrences and one explicit induction node. Validation passed 32 fresh
ordinary/optimized CLI cases. An independent review replayed eight further
CLI cases. Binder-macro expansion into strict staged FOL can require derived
coherence inductions; the explicit packet count is not a count of all such
expanded first-order inference nodes.

The whole-current-source comparison must include smaller controls already
in the countdown archive. The selected complete reference programs attain
295 normalized tokens, 334 AST nodes, and 801 normalized bytes, in different
programs. These are attained implementation upper bounds, not proved lower
bounds on every possible theory or proof checker.

START HERE
----------
report.pdf                Complete report, with explicit proofs and limitations.
report.tex                Main editable LaTeX source.
compiler_appendix.tex     Self-contained scalar pairing/recursion details.
report_standalone.tex     Fully expanded independently compilable TeX source.
code/checker.py           Independent supporting equational checker.
code/produce.py           Untrusted symbolic certificate producer.
code/validate.py          Positive and targeted negative checks.
code/README.txt           Exact symbolic syntax, rules and validation boundary.
certificates/             Main symbolic proof, capture controls and receipts.
reference/                Nine unchanged complete comparison programs.
evidence/                 Source identities, measurements and review notes.
CLAIMS.json               Machine-readable result-status ledger.
MANIFEST.json             SHA-256 hashes of the archive payload.

REPRODUCTION
------------
From the extracted package root, using Python 3:

  python3 verify_archive.py
  python3 reproduce.py
  python3 code/checker.py < certificates/bj_equations.json

The final command prints ACCEPT. Rejections print REJECT and exit one.
The checker imports only Python's standard library and does not execute
submitted code, evaluate arithmetic, or import the proof producer.

The comparison normalizer is preserved unchanged from the supplied corpus.
Exact recorded source metrics use CPython 3.12.14. Other Python versions
may change ast.unparse output. Reproduction reports the actual version.

To rebuild the PDF and flattened source:

  python3 build.py

This uses installed TeX files only, with shell escape disabled and no
downloads. A normal pdfLaTeX distribution with the packages listed in
report.tex is required. The build helper can create a temporary local
format from installed TeX sources when that format is missing.

Run verify_archive.py BEFORE regenerating receipts or the PDF. The manifest
identifies the distributed payload; reproducing evidence or rebuilding with
a different runtime can change those files without changing the theorem.

PROVENANCE
----------
Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: 6c902762efcb1e78a5dd25db745310bab74f47a5
Directory: docs/drafts
Current archives: 14, all checked against Git blob identities and lengths.

The logical Choice-DI machinery, actual-equality reflection method, and
comparison programs are inherited and attributed in the report. The general
idea of using a special initial state before ordinary encoded states is
also inherited; the new contribution is the much simpler B/J implementation
and its internal proof. The original source archives are not duplicated.

The universal metatheorems have written proofs and independent assistant
reviews, not Lean/Rocq verification or external human peer review.
No changes, messages, issues, comments or commits were posted to the source
repository. Further research questions are included in the report.
