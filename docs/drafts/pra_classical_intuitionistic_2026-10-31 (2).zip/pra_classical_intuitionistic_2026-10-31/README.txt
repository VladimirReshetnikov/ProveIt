A SMALL BASIS FOR PRIMITIVE RECURSIVE ARITHMETIC
Classical and intuitionistic axiomatizations
Prepared for Vladimir Reshetnikov -- October 31, 2026

MAIN RESULT

The same nonlogical basis gives ordinary first-order PRA in either
classical or intuitionistic first-order logic:

  1. The two defining equations for every syntactically described
     primitive recursion.
  2. 0 != S(0).
  3. For arbitrary terms s(n,a), t(n,a), with parameters a fixed:

     [forall n ((n=0 or s(n,a)=t(n,a))
                 -> s(S(n),a)=t(S(n),a))]
       -> forall n (n=0 or s(n,a)=t(n,a)).

Universally close all parameters. This is an axiom schema, not a
quantification over functions. Equality is ordinary logical equality;
decidability is derived, not assumed.

The paper proves exact equivalence with quantifier-free induction
within the selected logic. The fixed zero disjunct supplies positive
predecessor coverage and makes the induction base automatic.

The paper also gives:

* An explicit constructive equality-test proof using only equation
  induction and predecessor coverage.
* A primitive-recursive compiler from quantifier-free formulas to
  equations, including intuitionistic implication and disjunction.
* A direct-product countermodel to bare equation induction.
* A Kripke countermodel explaining why compact negative classical
  presentations do not transfer unchanged to intuitionistic logic.
* An exact minimal-disjunction-width result in a specified family.
* A comparison with the native equational PRA calculus and a review
  of all six draft archives supplied by the repository.
* Further research questions.

FILES

pra_classical_intuitionistic.tex  Complete paper source.
pra_classical_intuitionistic.pdf  Compiled paper.
axioms.txt                       Plain-text formal specification.
source_audit.json                Pinned repository provenance and hashes.
verification.txt                 Recorded artifact and document checks.
build.sh                         Rebuild and replay instructions.
SHA256SUMS.txt                    Digests of the delivered files.

artifacts/check_certificates.py
artifacts/guarded_induction_certificates.json
  A small intuitionistic natural-deduction checker and three symbolic
  proof certificates. These verify G -> coverage, G -> equation
  induction, and ordinary guarded induction -> G.

artifacts/formula_compiler.py
artifacts/formula_compiler_examples.json
  Executable formula compilation and countermodel illustrations.

See artifacts/README.txt for the exact verification boundary.

REBUILD

Requirements:
  Python 3.10 or later (standard library only).
  A TeX distribution with pdflatex and the packages in the source.

From this directory:
  bash build.sh

To replay only the symbolic certificates:
  python3 artifacts/check_certificates.py --check

The PDF proof is the complete mathematical deliverable. The executable
kernel checks selected schematic deductions; it does not formalize
the entire equivalence theorem or establish its own soundness in a
proof assistant. Numerical compiler checks are illustrations only.

SCOPE OF SIMPLICITY

This is a compact explicit presentation, not a claim of an absolute
minimum number of symbols or bytes. With base D + 0 != 1 fixed,
induction on one positive equation is too weak; induction on two
positive equations in disjunction suffices, with one disjunct always
n=0. That narrower optimality statement is proved.

SOURCE SNAPSHOT

https://github.com/VladimirReshetnikov/ProveIt/tree/ffbbfd31452e7188a9e3ba62c81a3bdb64072b82/docs/drafts

The six original archives and external papers are not redistributed.
The new archive is a standalone deliverable.
