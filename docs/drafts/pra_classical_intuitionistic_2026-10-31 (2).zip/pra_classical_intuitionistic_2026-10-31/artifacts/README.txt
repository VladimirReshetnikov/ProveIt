COMPUTATIONAL ARTIFACTS: SCOPE AND REPRODUCTION
============================================

All programs use Python 3's standard library only. Run them from any directory:

  python3 check_certificates.py --check
  python3 formula_compiler.py --check

To regenerate the reviewable data files:

  python3 check_certificates.py --generate --check
  python3 formula_compiler.py --write

The source of each program states its trust boundary. These two programs serve
different purposes and their outputs should not be conflated.

1. SYMBOLIC FIRST-ORDER PROOF CERTIFICATES

check_certificates.py checks finite natural-deduction derivations. Its small
kernel validates equality rules, conjunction, disjunction, implication,
universal quantifiers, capture-avoiding substitution, and the eigenvariable
condition for universal introduction. Certificate generation is a separately
marked, untrusted part of the same source; generated JSON is loaded afresh and
checked. The only arithmetic axiom tags are:

  D_pred: forall n, p(S(n)) = n;
  G: the paper's exact two-term guarded induction schema.

guarded_induction_certificates.json contains these symbolic derivations:

  - G implies positive predecessor coverage (uses D_pred and G).
  - G implies equation induction (uses G).
  - Ordinary induction on n=0 or f(n)=g(n) implies G (logic only).

The unary function letters f,g are generic placeholders. Uniform substitution
by terms with fixed parameters gives the stated term schemata, with the usual
capture-avoidance convention. The checker does not assume excluded middle.

The verification also rejects five malformed/forged derivations and checks a
capture-avoiding substitution regression. proof_certificate_verification.txt
records the executed checks. These are actual syntactic proof checks, not
numerical samples, but they cover only the displayed elementary derivations.
They do NOT formalize the entire equivalence with PRA, the equality-test proof,
the metatheory of natural deduction, or the general Kripke-model theorem.

2. FORMULA COMPILER AND COUNTERMODEL WITNESSES

formula_compiler.py implements exactly the paper's error-term translation:

  (s=t)       -> d(s,t) = alpha(s,t) + beta(s,t)
  bottom,top  -> 1,0
  not A       -> z(error(A))
  A and B     -> error(A) + error(B)
  A or B      -> c(error(A),0,error(B))
  A implies B -> c(error(A),error(B),0)

The selector c(0,u,v)=u and c(S(n),u,v)=v follows the manuscript's convention.
The alpha and beta evaluators follow their primitive-recursive equations;
distance is computed from them rather than from an absolute-value oracle.

The program checks finite numerical examples and writes JSON syntax trees.
These samples illustrate and exercise the implementation; they cannot prove
the general compilation theorem or any unbounded induction assertion.

Two exact witness calculations are also included:

  - In the componentwise product N x N, x=(0,1) fails predecessor coverage,
    although the corresponding compiled error term equals (0,0).
  - A root and two terminal Kripke worlds share carrier N x N. Root equality
    requires both coordinates to agree; each terminal world uses one coordinate.
    The usual intuitionistic forcing clauses give false coverage and false
    equality excluded middle at the root, but true double-negated coverage.

The Kripke evaluator handles quantifier-free formulas only. It computes the
stated witness exactly but does not evaluate quantifiers over a finite substitute
for N and does not assert that numerical tests establish all Harrop/induction
axioms. Those model-theoretic assertions are proved in the manuscript.

formula_compiler_examples.json preserves the example syntax and witness data.
formula_compiler_verification.txt records the numerical-check counts and the
root/terminal forcing results.
