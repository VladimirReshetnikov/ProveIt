#!/usr/bin/env python3
"""Check small intuitionistic first-order proof certificates for the PRA core.

Trusted kernel: syntax/substitution and infer() below. The certificate generator
is untrusted. No Python evaluation, finite numerical sampling, excluded middle,
or induction rule is used by the kernel. The only arithmetic axiom tags are
D_pred (p(S(n))=n) and G, whose precise schema is reconstructed and checked.

The three certificates concern generic unary symbols f,g. They therefore admit
uniform substitution by arbitrary primitive-recursive terms with fixed
parameters, avoiding variable capture. This is NOT a formalization of the full
PRA equivalence, the equality-test construction, or the metatheory of logic.
"""
import argparse
import copy
import json
from pathlib import Path

ARITIES = {"0": 0, "S": 1, "p": 1, "f": 1, "g": 1}


class InvalidProof(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidProof(message)


def V(name):
    return ("v", name)


def F(name, *args):
    return ("f", name, tuple(args))


def Eq(a, b):
    return ("=", a, b)


def All(v, body):
    return ("all", v, body)


def And(a, b):
    return ("and", a, b)


def Or(a, b):
    return ("or", a, b)


def Imp(a, b):
    return ("imp", a, b)


ZERO = F("0")


def term_vars(t):
    require(isinstance(t, tuple) and t, "invalid term")
    if t[0] == "v":
        require(len(t) == 2 and isinstance(t[1], str) and t[1], "bad variable")
        return {t[1]}
    require(t[0] == "f" and len(t) == 3 and t[1] in ARITIES, "unknown function")
    require(isinstance(t[2], tuple) and len(t[2]) == ARITIES[t[1]], "wrong arity")
    result = set()
    for a in t[2]:
        result |= term_vars(a)
    return result


def free_vars(a):
    require(isinstance(a, tuple) and len(a) == 3, "invalid formula")
    if a[0] == "=":
        return term_vars(a[1]) | term_vars(a[2])
    if a[0] == "all":
        require(isinstance(a[1], str) and a[1], "bad quantified variable")
        return free_vars(a[2]) - {a[1]}
    require(a[0] in {"and", "or", "imp"}, "unknown formula connective")
    return free_vars(a[1]) | free_vars(a[2])


def sub_term(t, variable, replacement):
    if t[0] == "v":
        return replacement if t[1] == variable else t
    return F(t[1], *(sub_term(x, variable, replacement) for x in t[2]))


def sub(a, variable, replacement):
    """Capture-avoiding substitution of a term for a free formula variable."""
    if a[0] == "=":
        return Eq(sub_term(a[1], variable, replacement),
                  sub_term(a[2], variable, replacement))
    if a[0] != "all":
        return (a[0], sub(a[1], variable, replacement),
                sub(a[2], variable, replacement))
    bound, body = a[1], a[2]
    if bound == variable:
        return a
    if bound in term_vars(replacement) and variable in free_vars(body):
        avoid = free_vars(body) | term_vars(replacement) | {variable, bound}
        fresh = bound + "_fresh"
        while fresh in avoid:
            fresh += "_"
        body = sub(body, bound, V(fresh))
        bound = fresh
    return All(bound, sub(body, variable, replacement))


def guard_schema(variable, left, right):
    term_vars(left)
    term_vars(right)
    n = V(variable)
    e = Eq(left, right)
    a = Or(Eq(n, ZERO), e)
    return Imp(All(variable, Imp(a, sub(e, variable, F("S", n)))),
               All(variable, a))


def extend(context, label, formula):
    require(isinstance(label, str) and label not in context, "duplicate hypothesis label")
    free_vars(formula)
    return {**context, label: formula}


FIELDS = {
    "hyp": {"label"}, "refl": {"term"},
    "sym": {"proof"}, "trans": {"first", "second"},
    "cong": {"proof", "var", "template"},
    "eq_subst": {"equality", "proof", "var", "template"},
    "and_i": {"left", "right"}, "and_e1": {"pair"}, "and_e2": {"pair"},
    "or_i1": {"proof", "other"}, "or_i2": {"proof", "other"},
    "or_e": {"disjunction", "left_label", "left", "right_label", "right"},
    "imp_i": {"label", "assumption", "body"}, "imp_e": {"function", "argument"},
    "forall_i": {"var", "body"}, "forall_e": {"universal", "term"},
    "D_pred": {"formula"}, "G": {"var", "left", "right", "formula"},
}


def infer(node, context=None):
    """Small natural-deduction kernel: infer one conclusion or reject."""
    context = {} if context is None else context
    require(isinstance(node, dict), "proof node must be an object")
    r = node.get("rule")
    require(r in FIELDS and set(node) == FIELDS[r] | {"rule"}, "unknown rule/fields")
    ck = lambda key: infer(node[key], context)
    if r == "hyp":
        require(node["label"] in context, "undischarged/unavailable hypothesis")
        out = context[node["label"]]
    elif r == "refl":
        term_vars(node["term"])
        out = Eq(node["term"], node["term"])
    elif r == "sym":
        a = ck("proof")
        require(a[0] == "=", "symmetry needs equality")
        out = Eq(a[2], a[1])
    elif r == "trans":
        a, b = ck("first"), ck("second")
        require(a[0] == b[0] == "=" and a[2] == b[1], "transitivity mismatch")
        out = Eq(a[1], b[2])
    elif r == "cong":
        a = ck("proof")
        require(a[0] == "=", "congruence needs equality")
        term_vars(node["template"])
        out = Eq(sub_term(node["template"], node["var"], a[1]),
                 sub_term(node["template"], node["var"], a[2]))
    elif r == "eq_subst":
        a, premise = ck("equality"), ck("proof")
        require(a[0] == "=", "equality substitution needs equality")
        free_vars(node["template"])
        require(sub(node["template"], node["var"], a[1]) == premise,
                "equality substitution premise mismatch")
        out = sub(node["template"], node["var"], a[2])
    elif r == "and_i":
        out = And(ck("left"), ck("right"))
    elif r in {"and_e1", "and_e2"}:
        a = ck("pair")
        require(a[0] == "and", "conjunction elimination needs conjunction")
        out = a[1 if r == "and_e1" else 2]
    elif r in {"or_i1", "or_i2"}:
        a, b = ck("proof"), node["other"]
        free_vars(b)
        out = Or(a, b) if r == "or_i1" else Or(b, a)
    elif r == "or_e":
        a = ck("disjunction")
        require(a[0] == "or", "disjunction elimination needs disjunction")
        left = infer(node["left"], extend(context, node["left_label"], a[1]))
        right = infer(node["right"], extend(context, node["right_label"], a[2]))
        require(left == right, "disjunction branches disagree")
        out = left
    elif r == "imp_i":
        out = Imp(node["assumption"], infer(node["body"],
                  extend(context, node["label"], node["assumption"])))
    elif r == "imp_e":
        a, b = ck("function"), ck("argument")
        require(a[0] == "imp" and a[1] == b, "implication elimination mismatch")
        out = a[2]
    elif r == "forall_i":
        variable = node["var"]
        require(all(variable not in free_vars(a) for a in context.values()),
                "forall eigenvariable occurs in an undischarged hypothesis")
        out = All(variable, ck("body"))
    elif r == "forall_e":
        a = ck("universal")
        require(a[0] == "all", "universal elimination needs universal formula")
        term_vars(node["term"])
        out = sub(a[2], a[1], node["term"])
    elif r == "D_pred":
        out = All("n", Eq(F("p", F("S", V("n"))), V("n")))
        require(node["formula"] == out, "D_pred axiom mismatch")
    elif r == "G":
        out = guard_schema(node["var"], node["left"], node["right"])
        require(node["formula"] == out, "G axiom mismatch")
    free_vars(out)
    return out


# ---- Untrusted proof construction; every generated certificate is rechecked. ----
def N(rule, **kwargs):
    return {"rule": rule, **kwargs}


def hyp(label):
    return N("hyp", label=label)


def app(function, argument):
    return N("imp_e", function=function, argument=argument)


def inst(proof, term):
    return N("forall_e", universal=proof, term=term)


def gi(left, right):
    return N("G", var="n", left=left, right=right,
             formula=guard_schema("n", left, right))


def construct_certificates():
    n, hole = V("n"), V("_")
    e = lambda x: Eq(F("f", x), F("g", x))
    a = lambda x: Or(Eq(x, ZERO), e(x))
    pred = N("D_pred", formula=All("n", Eq(F("p", F("S", n)), n)))
    coverage_guard = Or(Eq(n, ZERO), Eq(n, F("S", F("p", n))))
    coverage_step = N("sym", proof=N("cong", proof=inst(pred, n),
                                      var="_", template=F("S", hole)))
    coverage = app(gi(n, F("S", F("p", n))), N("forall_i", var="n",
        body=N("imp_i", label="unused_guard", assumption=coverage_guard,
               body=coverage_step)))

    ordinary_step = All("n", Imp(e(n), e(F("S", n))))
    assumptions = And(e(ZERO), ordinary_step)
    base = N("and_e1", pair=hyp("induction_assumptions"))
    step = N("and_e2", pair=hyp("induction_assumptions"))
    transported_base = N("eq_subst", equality=N("sym", proof=hyp("zero_case")),
                         proof=base, var="_", template=e(hole))
    guard_step = N("forall_i", var="n", body=N("imp_i", label="guard", assumption=a(n),
        body=N("or_e", disjunction=hyp("guard"), left_label="zero_case",
               left=app(inst(step, n), transported_base), right_label="equation_case",
               right=app(inst(step, n), hyp("equation_case")))))
    guarded_result = app(gi(F("f", n), F("g", n)), guard_step)
    all_equations = N("forall_i", var="n", body=N("or_e",
        disjunction=inst(guarded_result, n), left_label="zero_case", left=transported_base,
        right_label="equation_case", right=hyp("equation_case")))
    equation_induction = N("imp_i", label="induction_assumptions",
                           assumption=assumptions, body=all_equations)

    guarded_induction = Imp(And(a(ZERO), All("n", Imp(a(n), a(F("S", n))))),
                            All("n", a(n)))
    g_premise = All("n", Imp(a(n), e(F("S", n))))
    step_from_g = N("forall_i", var="n", body=N("imp_i", label="local_guard",
        assumption=a(n), body=N("or_i2", other=Eq(F("S", n), ZERO),
            proof=app(inst(hyp("g_premise"), n), hyp("local_guard")))))
    from_ordinary = N("imp_i", label="guarded_induction", assumption=guarded_induction,
        body=N("imp_i", label="g_premise", assumption=g_premise,
            body=app(hyp("guarded_induction"), N("and_i",
                left=N("or_i1", proof=N("refl", term=ZERO), other=e(ZERO)),
                right=step_from_g))))
    return [
        {"name": "G_implies_predecessor_coverage", "proof": coverage,
         "theorem": All("n", coverage_guard), "arithmetic_axioms": ["D_pred", "G"]},
        {"name": "G_implies_equation_induction", "proof": equation_induction,
         "theorem": Imp(assumptions, All("n", e(n))), "arithmetic_axioms": ["G"]},
        {"name": "ordinary_guarded_induction_implies_G", "proof": from_ordinary,
         "theorem": Imp(guarded_induction, guard_schema("n", F("f", n), F("g", n))),
         "arithmetic_axioms": []},
    ]


def freeze(value):
    if isinstance(value, list):
        return tuple(freeze(v) for v in value)
    if isinstance(value, dict):
        return {k: freeze(v) for k, v in value.items()}
    return value


def arithmetic_tags(node):
    tags = {node["rule"]} & {"G", "D_pred"}
    for value in node.values():
        if isinstance(value, dict) and "rule" in value:
            tags |= arithmetic_tags(value)
    return tags


def verify_certificate(certificate):
    require(infer(certificate["proof"]) == certificate["theorem"], "final theorem mismatch")
    require(arithmetic_tags(certificate["proof"]) == set(certificate["arithmetic_axioms"]),
            "arithmetic-axiom manifest mismatch")


def rejection_tests(certificates):
    n = V("n")
    bad_eigenvariable = N("imp_i", label="open", assumption=Eq(n, ZERO),
        body=N("forall_i", var="n", body=hyp("open")))
    bad_g = gi(F("f", n), F("g", n))
    bad_g["formula"] = Imp(bad_g["formula"][1], All("n", Eq(F("f", n), F("g", n))))
    bad_discharge = N("imp_i", label="a", assumption=Eq(ZERO, ZERO), body=hyp("b"))
    bad_transport = N("eq_subst", equality=N("refl", term=ZERO),
        proof=N("refl", term=F("S", ZERO)), var="_", template=Eq(V("_"), ZERO))
    for name, proof in [("eigenvariable capture", bad_eigenvariable),
                        ("swapped G conclusion", bad_g),
                        ("unavailable hypothesis", bad_discharge),
                        ("invalid equality transport", bad_transport)]:
        try:
            infer(proof)
        except InvalidProof as error:
            print(f"REJECTED: {name}: {error}")
        else:
            raise AssertionError(f"invalid certificate accepted: {name}")
    # A capture-avoidance regression: substituting n for x must rename inner n.
    captured = sub(All("n", Eq(V("x"), V("n"))), "x", V("n"))
    require(free_vars(captured) == {"n"} and captured[1] != "n", "capture-avoidance failure")
    forged = copy.deepcopy(certificates[0])
    forged["theorem"] = All("n", Eq(n, ZERO))
    try:
        verify_certificate(forged)
    except InvalidProof:
        print("REJECTED: forged final theorem")
    else:
        raise AssertionError("forged theorem accepted")
    print("PASS: capture-avoiding substitution regression")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--generate", action="store_true", help="regenerate the untrusted JSON proofs")
    parser.add_argument("--check", action="store_true", help="check JSON proofs and adversarial controls")
    parser.add_argument("--certificates", type=Path,
                        default=Path(__file__).with_name("guarded_induction_certificates.json"))
    args = parser.parse_args()
    if args.generate:
        args.certificates.write_text(json.dumps(construct_certificates(), indent=2) + "\n")
        print(f"GENERATED: {args.certificates.name}")
    certificates = freeze(json.loads(args.certificates.read_text()))
    for certificate in certificates:
        verify_certificate(certificate)
        print(f"CHECKED: {certificate['name']} (axioms: {', '.join(certificate['arithmetic_axioms']) or 'logic only'})")
    rejection_tests(certificates)
    print("SCOPE: three symbolic first-order derivations; not the full PRA-equivalence theorem.")


if __name__ == "__main__":
    main()
