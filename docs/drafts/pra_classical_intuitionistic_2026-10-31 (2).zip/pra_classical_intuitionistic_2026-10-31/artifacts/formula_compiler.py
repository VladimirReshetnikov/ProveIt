#!/usr/bin/env python3
"""Illustrate the paper's error-term compiler and its two countermodel witnesses.

All number checks are finite illustrations, not proofs of the unbounded
equivalence theorem. The Kripke evaluator handles quantifier-free formulas
only; it does not attempt to check infinitely many induction/Harrop axioms.
Terms are JSON-compatible tuples: ('v','x'), ('0',), ('S',t), ('+',s,t), etc.
Formulas use =, and, or, imp, not, top, bottom. Zero denotes truth in compiled
error terms. alpha and beta are evaluated by their actual primitive recurrences.
"""
import argparse
import json
from pathlib import Path

ARITY = {"0": 0, "S": 1, "p": 1, "z": 1, "c": 3,
         "+": 2, "alpha": 2, "beta": 2, "d": 2}
FUTURE = {"root": ("root", "left", "right"), "left": ("left",), "right": ("right",)}
ZERO, ONE = ("0",), ("S", ("0",))
X, Y = ("v", "x"), ("v", "y")


def successor(n):
    return n + 1


def predecessor(n):
    return 0 if n == 0 else n - 1


def zero_indicator(n):
    return 1 if n == 0 else 0


def select(n, u, v):
    return u if n == 0 else v


def add(n, y):
    result = y
    for _ in range(n):
        result = successor(result)
    return result


def alpha(n, y):
    result = y
    for _ in range(n):
        result = predecessor(result)
    return result


def beta(n, y):
    result = 0
    for k in range(n):
        result = select(alpha(k, y), successor(result), result)
    return result


def distance(n, y):
    return add(alpha(n, y), beta(n, y))


HELPERS = {"0": lambda: 0, "S": successor, "p": predecessor,
           "z": zero_indicator, "c": select, "+": add,
           "alpha": alpha, "beta": beta, "d": distance}


def eval_term(term, assignment):
    if term[0] == "v":
        if len(term) != 2 or term[1] not in assignment:
            raise ValueError("invalid or unassigned variable")
        value = assignment[term[1]]
        if not isinstance(value, int) or value < 0:
            raise ValueError("expected a natural-number assignment")
        return value
    if term[0] not in ARITY or len(term) != 1 + ARITY[term[0]]:
        raise ValueError("invalid term or helper arity")
    return HELPERS[term[0]](*(eval_term(t, assignment) for t in term[1:]))


def eval_pair(term, assignment):
    return tuple(eval_term(term, {v: p[i] for v, p in assignment.items()}) for i in (0, 1))


def compile_formula(formula):
    op = formula[0]
    if op in {"top", "bottom"} and len(formula) == 1:
        return ZERO if op == "top" else ONE
    if op == "=" and len(formula) == 3:
        return ("d", formula[1], formula[2])
    if op == "not" and len(formula) == 2:
        return ("z", compile_formula(formula[1]))
    if op not in {"and", "or", "imp"} or len(formula) != 3:
        raise ValueError("unknown formula shape")
    a, b = compile_formula(formula[1]), compile_formula(formula[2])
    if op == "and":
        return ("+", a, b)
    if op == "or":
        return ("c", a, ZERO, b)
    return ("c", a, b, ZERO)


def classical_value(formula, assignment, product=False):
    op = formula[0]
    term_value = eval_pair if product else eval_term
    if op == "=":
        return term_value(formula[1], assignment) == term_value(formula[2], assignment)
    if op in {"top", "bottom"}:
        return op == "top"
    if op == "not":
        return not classical_value(formula[1], assignment, product)
    a = classical_value(formula[1], assignment, product)
    b = classical_value(formula[2], assignment, product)
    if op == "and":
        return a and b
    if op == "or":
        return a or b
    if op == "imp":
        return (not a) or b
    raise ValueError("unknown connective")


def force(formula, world, assignment):
    """Usual intuitionistic clauses; equality grows at the terminal worlds."""
    op = formula[0]
    if op == "=":
        a, b = eval_pair(formula[1], assignment), eval_pair(formula[2], assignment)
        if world == "root":
            return a == b
        coordinate = 0 if world == "left" else 1
        return a[coordinate] == b[coordinate]
    if op in {"top", "bottom"}:
        return op == "top"
    if op == "not":
        return force(("imp", formula[1], ("bottom",)), world, assignment)
    if op == "and":
        return force(formula[1], world, assignment) and force(formula[2], world, assignment)
    if op == "or":
        return force(formula[1], world, assignment) or force(formula[2], world, assignment)
    if op == "imp":
        return all(not force(formula[1], w, assignment) or force(formula[2], w, assignment)
                   for w in FUTURE[world])
    raise ValueError("unknown connective")


def examples():
    eq = ("=", X, Y)
    coverage = ("or", ("=", X, ZERO), ("=", X, ("S", ("p", X))))
    return {
        "predecessor_coverage": coverage,
        "equality_decidability": ("or", eq, ("not", eq)),
        "reflexivity": ("=", X, X),
        "negated_equality": ("not", eq),
        "implication": ("imp", ("=", X, ZERO), ("=", ("p", X), ZERO)),
        "connective_mix": ("and", coverage, ("imp", eq, ("=", ("S", X), ("S", Y)))),
        "truth": ("top",), "falsehood": ("bottom",),
    }


def run_checks():
    lines = []
    def report(line):
        print(line)
        lines.append(line)
    atoms = [("=", X, Y), ("=", X, ZERO), ("=", ("p", ("S", X)), X),
             ("=", ("alpha", X, Y), ZERO), ("=", ("beta", X, Y), ZERO),
             ("=", ("d", X, Y), ZERO)]
    formulas = [("top",), ("bottom",)] + atoms + [("not", a) for a in atoms]
    formulas += [(op, a, b) for op in ("and", "or", "imp") for a in atoms for b in atoms]
    formulas += list(examples().values())
    for n in range(9):
        for y in range(9):
            assert alpha(successor(n), y) == predecessor(alpha(n, y))
            assert beta(successor(n), y) == select(alpha(n, y), successor(beta(n, y)), beta(n, y))
            assert alpha(successor(n), successor(y)) == alpha(n, y)
            assert beta(successor(n), successor(y)) == beta(n, y)
            assert add(n, alpha(n, y)) == add(y, beta(n, y))
            assert (distance(n, y) == 0) == (n == y)
            assert alpha(n, n) == beta(n, n) == 0
            for formula in formulas:
                assignment = {"x": n, "y": y}
                assert (eval_term(compile_formula(formula), assignment) == 0) == classical_value(formula, assignment)
    report(f"PASS: {len(formulas) * 81} finite formula-compilation comparisons ({len(formulas)} formulas, x,y=0,...,8).")
    report("PASS: finite alpha/beta recurrence, shift, diagonal, balance, and distance checks.")

    assignment = {"x": (0, 1), "y": (0, 0)}
    coverage = examples()["predecessor_coverage"]
    decidability = examples()["equality_decidability"]
    product = {"assignment": assignment, "S_predecessor_x": eval_pair(("S", ("p", X)), assignment),
               "coverage": classical_value(coverage, assignment, product=True),
               "compiled_coverage_error": eval_pair(compile_formula(coverage), assignment)}
    assert product["coverage"] is False and product["compiled_coverage_error"] == (0, 0)
    report("PRODUCT WITNESS: x=(0,1), S(p(x))=(1,1); coverage is false, its compiled error is (0,0).")
    cases = {"coverage": coverage, "equality_decidability": decidability,
             "double_negated_coverage": ("not", ("not", coverage)),
             "compiled_coverage_zero": ("=", compile_formula(coverage), ZERO)}
    worlds = {name: {world: force(formula, world, assignment) for world in FUTURE}
              for name, formula in cases.items()}
    assert worlds["coverage"] == {"root": False, "left": True, "right": True}
    assert worlds["equality_decidability"] == {"root": False, "left": True, "right": True}
    assert all(worlds["double_negated_coverage"].values())
    assert all(worlds["compiled_coverage_zero"].values())
    for name, result in worlds.items():
        report(f"KRIPKE {name}: root={result['root']}, left={result['left']}, right={result['right']}.")
    # Persistence of the illustrated formulas is also checked at this assignment.
    for formula in formulas:
        if force(formula, "root", assignment):
            assert force(formula, "left", assignment) and force(formula, "right", assignment)
    report("SCOPE: numerical samples and exact quantifier-free witness evaluations; no unbounded proof is claimed.")
    data = {
        "scope": "Illustrations only; the paper proves the unbounded statements.",
        "compiler_examples": [{"name": name, "formula": formula, "error_term": compile_formula(formula)}
                              for name, formula in examples().items()],
        "product_witness": product,
        "kripke_witness": {"carrier": "N x N", "assignment": assignment,
            "equality": {"root": "both coordinates", "left": "first coordinate", "right": "second coordinate"},
            "forcing": worlds},
    }
    return data, "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="run illustrations (also the default)")
    parser.add_argument("--write", action="store_true", help="also write example JSON and verification text")
    args = parser.parse_args()
    data, verification = run_checks()
    if args.write:
        folder = Path(__file__).parent
        (folder / "formula_compiler_examples.json").write_text(json.dumps(data, indent=2) + "\n")
        (folder / "formula_compiler_verification.txt").write_text(verification)


if __name__ == "__main__":
    main()
