#!/usr/bin/env bash
set -eu
cd -- "$(dirname -- "$0")"
mkdir -p build
python3 artifacts/check_certificates.py --check > artifacts/proof_certificate_verification.txt
python3 artifacts/formula_compiler.py --check > artifacts/formula_compiler_verification.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_classical_intuitionistic.tex > build/pdflatex-pass1.txt
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_classical_intuitionistic.tex > build/pdflatex-pass2.txt
cp build/pra_classical_intuitionistic.pdf pra_classical_intuitionistic.pdf
cat artifacts/proof_certificate_verification.txt
cat artifacts/formula_compiler_verification.txt
printf 'Built pra_classical_intuitionistic.pdf\n'
