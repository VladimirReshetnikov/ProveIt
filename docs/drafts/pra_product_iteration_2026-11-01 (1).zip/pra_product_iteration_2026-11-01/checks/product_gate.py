#!/usr/bin/env python3
"""Finite syntax diagnostics for product-state P15.

This file implements the specified *literal* three-case admission gate.  It
does not evaluate an iterator, normalize a term, simplify a product projection,
search for a proof, or certify the arithmetic/bi-interpretability theorem.
Products are explicit binary product types, with N the only base type.

Run ``python3 product_gate.py`` for the self-tests, or add ``--json`` for a
machine-readable report.  No third-party dependencies are required.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import sys
from typing import Dict, Mapping, Optional, Tuple


@dataclass(frozen=True)
class Sort:
    tag: str
    left: Optional["Sort"] = None
    right: Optional["Sort"] = None

    def valid(self) -> bool:
        if self.tag == "N":
            return self.left is None and self.right is None
        return (
            self.tag == "product"
            and isinstance(self.left, Sort)
            and isinstance(self.right, Sort)
            and self.left.valid()
            and self.right.valid()
        )


N = Sort("N")


def Product(left: Sort, right: Sort) -> Sort:
    return Sort("product", left, right)


@dataclass(frozen=True)
class Term:
    tag: str
    children: Tuple["Term", ...] = ()
    name: Optional[str] = None
    sort: Optional[Sort] = None


def Var(name: str, sort: Sort) -> Term:
    return Term("variable", name=name, sort=sort)


ZERO = Term("zero")


def S(value: Term) -> Term:
    return Term("successor", (value,))


def Pair(left: Term, right: Term) -> Term:
    return Term("pair", (left, right))


def First(value: Term) -> Term:
    return Term("first", (value,))


def Second(value: Term) -> Term:
    return Term("second", (value,))


def Iter(index: str, counter: Term, seed: Term) -> Term:
    return Term("iterator", (counter, seed), name=index)


@dataclass(frozen=True)
class Formula:
    tag: str
    children: tuple = ()


def Eq(left: Term, right: Term) -> Formula:
    return Formula("equal", (left, right))


BOTTOM = Formula("bottom")
DELTA = Eq(ZERO, S(ZERO))


def And(left: Formula, right: Formula) -> Formula:
    return Formula("and", (left, right))


def Or(left: Formula, right: Formula) -> Formula:
    return Formula("or", (left, right))


def Implies(left: Formula, right: Formula) -> Formula:
    return Formula("implies", (left, right))


@dataclass(frozen=True)
class Description:
    name: str
    state: Sort
    body: Term


class SyntaxFailure(ValueError):
    pass


def term_type(
    term: Term, environment: Mapping[str, Sort], descriptions: Mapping[str, Description]
) -> Sort:
    """Check a finite term without reducing any of its constructors."""
    if not isinstance(term, Term):
        raise SyntaxFailure("Expected a term tree")
    if term.tag == "variable":
        if term.children or term.name not in environment:
            raise SyntaxFailure("Foreign or malformed variable")
        if term.sort != environment[term.name] or not term.sort.valid():
            raise SyntaxFailure("Variable type disagrees with its context")
        return term.sort
    if term.sort is not None:
        raise SyntaxFailure("Only variable nodes carry declared types")
    if term.tag == "zero":
        if term.children or term.name is not None:
            raise SyntaxFailure("Malformed zero")
        return N
    if term.tag != "iterator" and term.name is not None:
        raise SyntaxFailure("Unexpected name on structural term")
    if term.tag == "successor":
        if len(term.children) != 1 or term_type(term.children[0], environment, descriptions) != N:
            raise SyntaxFailure("Successor expects one N term")
        return N
    if term.tag == "pair":
        if len(term.children) != 2:
            raise SyntaxFailure("Pair expects two terms")
        return Product(*(term_type(t, environment, descriptions) for t in term.children))
    if term.tag in ("first", "second"):
        if len(term.children) != 1:
            raise SyntaxFailure("Projection expects one term")
        domain = term_type(term.children[0], environment, descriptions)
        if domain.tag != "product":
            raise SyntaxFailure("Projection requires an explicit product type")
        result = domain.left if term.tag == "first" else domain.right
        assert result is not None
        return result
    if term.tag == "iterator":
        if term.name not in descriptions:
            raise SyntaxFailure("Unknown, forward, or self-referential iterator")
        if len(term.children) != 2:
            raise SyntaxFailure("Iterator expects a counter and a seed")
        counter, seed = term.children
        state = descriptions[term.name].state
        if term_type(counter, environment, descriptions) != N:
            raise SyntaxFailure("Iterator counter must have type N")
        if term_type(seed, environment, descriptions) != state:
            raise SyntaxFailure("Iterator seed has the wrong state type")
        return state
    raise SyntaxFailure("Unknown term constructor")


def check_formula(
    formula: Formula, environment: Mapping[str, Sort], descriptions: Mapping[str, Description]
) -> None:
    """Accept only the specified quantifier-free formula grammar."""
    if not isinstance(formula, Formula):
        raise SyntaxFailure("Expected a formula tree")
    if formula.tag == "bottom":
        if formula.children:
            raise SyntaxFailure("Malformed falsity")
        return
    if formula.tag == "equal":
        if len(formula.children) != 2:
            raise SyntaxFailure("Equality expects two terms")
        left, right = formula.children
        if term_type(left, environment, descriptions) != term_type(right, environment, descriptions):
            raise SyntaxFailure("Equality compares different types")
        return
    if formula.tag in ("and", "or", "implies"):
        if len(formula.children) != 2:
            raise SyntaxFailure("Binary connective expects two formulas")
        for child in formula.children:
            check_formula(child, environment, descriptions)
        return
    raise SyntaxFailure("Matrix is not in the quantifier-free grammar")


def substitute_term(term: Term, substitution: Mapping[str, Term]) -> Term:
    """Literal simultaneous substitution; deliberately no beta/eta reduction."""
    if term.tag == "variable" and term.name in substitution:
        return substitution[term.name]
    return Term(
        term.tag,
        tuple(substitute_term(t, substitution) for t in term.children),
        term.name,
        term.sort,
    )


def substitute_formula(formula: Formula, substitution: Mapping[str, Term]) -> Formula:
    if formula.tag == "equal":
        return Eq(*(substitute_term(t, substitution) for t in formula.children))
    if formula.tag == "bottom":
        return formula
    if formula.tag in ("and", "or", "implies"):
        return Formula(
            formula.tag,
            tuple(substitute_formula(f, substitution) for f in formula.children),
        )
    raise SyntaxFailure("Only QF substitution is supported")


class Language:
    def __init__(self) -> None:
        self._descriptions: Dict[str, Description] = {}

    @property
    def descriptions(self) -> Mapping[str, Description]:
        # Return a copy so callers cannot insert an unvalidated description.
        return dict(self._descriptions)

    def add(self, name: str, state: Sort, body: Term) -> Description:
        if not isinstance(name, str) or not name or name in self._descriptions:
            raise SyntaxFailure("Description index must be fresh and nonempty")
        if not state.valid():
            raise SyntaxFailure("Invalid finite product state type")
        # The prospective new name is deliberately absent during body checking.
        # Only previously admitted iterator names can occur in the stored body.
        if term_type(body, {"v": state}, self._descriptions) != state:
            raise SyntaxFailure("Stored update must be an endomorphism")
        result = Description(name, state, body)
        self._descriptions[name] = result
        return result


@dataclass(frozen=True)
class Admission:
    accepted: bool
    case: Optional[str]
    reason: str


def admission(language: Language, current: str, matrix: Formula, parameter: Sort) -> Admission:
    """P15's three full-root literal cases after substituting n := 0.

    The parameter type can be any finite product, independently of the current
    iterator's state type.  Pattern matching examines only the root shape of
    the zero instance.  Substitution and type checking traverse finite syntax,
    but no subformula search or normalization is performed.
    """
    descriptions = language.descriptions
    try:
        if current not in descriptions:
            raise SyntaxFailure("Current iterator is not an admitted description")
        if not parameter.valid():
            raise SyntaxFailure("Invalid parameter type")
        check_formula(matrix, {"n": N, "a": parameter}, descriptions)
        base = substitute_formula(matrix, {"n": ZERO})
        # This explicit recheck also confirms that substitution removed n.
        check_formula(base, {"a": parameter}, descriptions)
    except SyntaxFailure as error:
        return Admission(False, None, str(error))

    # G: (B OR (0=S0)) -> B, literal orientation and literal B trees.
    if base.tag == "implies":
        antecedent, consequent = base.children
        if antecedent.tag == "or":
            candidate, delta = antecedent.children
            if candidate == consequent and delta == DELTA:
                return Admission(True, "G", "Literal guarded reflexivity")

    if base.tag == "equal":
        left, right = base.children
        if left.tag == "iterator" and left.name == current:
            counter, seed = left.children
            # Z: I_h(0,t)=t.
            if counter == ZERO and right == seed:
                return Admission(True, "Z", "Literal initialization equation")
            # C: I_h(Sr,t)=h(I_h(r,t)); h is expanded by literal substitution.
            if counter.tag == "successor":
                previous_counter = counter.children[0]
                previous_state = Iter(current, previous_counter, seed)
                expected = substitute_term(
                    descriptions[current].body, {"v": previous_state}
                )
                if right == expected:
                    return Admission(True, "C", "Literal successor equation")
    return Admission(False, None, "Zero instance matches none of the three literal cases")


def self_tests() -> dict:
    results = []

    def gate_test(label, language, current, matrix, parameter, expected, case=None):
        actual = admission(language, current, matrix, parameter)
        passed = actual.accepted == expected and (case is None or actual.case == case)
        results.append({"test": label, "passed": passed, "accepted": actual.accepted,
                        "case": actual.case, "reason": actual.reason})

    def description_test(label, language, name, state, body, expected):
        try:
            language.add(name, state, body)
            accepted, reason = True, "Earlier well-typed endomorphism"
        except SyntaxFailure as error:
            accepted, reason = False, str(error)
        results.append({"test": label, "passed": accepted == expected,
                        "accepted": accepted, "reason": reason})

    language = Language()
    description_test("identity description", language, "identity", N, Var("v", N), True)
    square_state = Product(N, N)
    v = Var("v", square_state)
    step_body = Pair(S(First(v)), First(v))
    description_test("counter-lag pure product update", language, "lag", square_state,
                     step_body, True)
    # A later body may reference an already validated iterator.
    description_test("earlier iterator dependency", language, "later", N,
                     Iter("identity", S(ZERO), Var("v", N)), True)
    description_test("self description rejected", language, "self", N,
                     Iter("self", ZERO, Var("v", N)), False)
    description_test("forward description rejected", language, "forward", N,
                     Iter("not_yet_defined", ZERO, Var("v", N)), False)
    description_test("foreign update variable rejected", language, "foreign", N,
                     S(Var("counter", N)), False)
    description_test("duplicate description index rejected", language, "identity", N,
                     Var("v", N), False)
    description_test("nonendomorphism rejected", language, "wrong_sort", N,
                     Pair(Var("v", N), ZERO), False)

    a = Var("a", square_state)
    initializer = Eq(Iter("lag", ZERO, a), a)
    gate_test("stationary initializer", language, "lag", initializer, square_state, True, "Z")

    # Two independent numerical arguments are a scalar counter plus a *product*
    # seed.  They occupy one parameter of a different, larger product type.
    parameter = Product(N, square_state)
    a_big = Var("a", parameter)
    r, t = First(a_big), Second(a_big)
    recurrence = Eq(
        Iter("lag", S(r), t),
        substitute_term(step_body, {"v": Iter("lag", r, t)}),
    )
    gate_test("stationary step with independent product parameter", language, "lag",
              recurrence, parameter, True, "C")

    separation = Implies(Or(BOTTOM, DELTA), BOTTOM)
    gate_test("stationary separation guard", language, "identity", separation, N, True, "G")

    n = Var("n", N)
    g = And(Eq(n, First(a)), Implies(Eq(Second(a), ZERO), Eq(n, S(ZERO))))
    g_zero = substitute_formula(g, {"n": ZERO})
    wrapped = Implies(Or(g_zero, DELTA), g)
    gate_test("ordinary induction wrapper", language, "identity", wrapped, square_state,
              True, "G")

    # An unused scalar parameter is allowed even when the current state is N^2.
    gate_test("guard parameter independent of state type", language, "lag", separation,
              N, True, "G")
    gate_test("literal guard with nested product projections", language, "lag",
              Implies(Or(Eq(First(a), ZERO), DELTA), Eq(First(a), ZERO)), square_state,
              True, "G")

    wrong_right = Eq(Iter("lag", S(r), t), Iter("lag", r, t))
    gate_test("wrong recurrence right side rejected", language, "lag", wrong_right,
              parameter, False)
    gate_test("foreign current index rejected", language, "missing", separation, N, False)
    gate_test("different iterator's initializer rejected", language, "identity",
              initializer, square_state, False)

    # Product eta is valid in the logical expansion, but is NOT used by the gate.
    eta_seed = Pair(First(a), Second(a))
    eta_only = Eq(Iter("lag", ZERO, eta_seed), a)
    gate_test("eta-equivalent nonliteral base rejected", language, "lag", eta_only,
              square_state, False)
    scalar_a = Var("a", N)
    beta_left = Eq(First(Pair(scalar_a, scalar_a)), scalar_a)
    beta_right = Eq(scalar_a, scalar_a)
    beta_only = Implies(Or(beta_left, DELTA), beta_right)
    gate_test("beta-equivalent nonliteral guard rejected", language, "identity",
              beta_only, N, False)

    # A permitted equation nested below another connective is not searched for.
    nested = And(initializer, Eq(First(a), First(a)))
    gate_test("no traversal to an admitted subformula", language, "lag", nested,
              square_state, False)
    reversed_delta = Eq(S(ZERO), ZERO)
    gate_test("reversed separation atom rejected", language, "identity",
              Implies(Or(BOTTOM, reversed_delta), BOTTOM), N, False)
    gate_test("unguarded reflexivity rejected in three-case version", language, "identity",
              Implies(BOTTOM, BOTTOM), N, False)
    gate_test("foreign matrix variable rejected", language, "identity",
              Implies(Or(Eq(Var("b", N), ZERO), DELTA), Eq(Var("b", N), ZERO)), N, False)
    gate_test("mistyped parameter rejected", language, "lag", initializer, N, False)
    gate_test("quantified changing matrix rejected", language, "identity",
              Formula("forall", ("b", N, Eq(n, Var("b", N)))), N, False)
    gate_test("stationary quantified matrix also rejected", language, "identity",
              Formula("forall", ("b", N, Eq(Var("b", N), Var("b", N)))), N, False)

    # The traversal for n:=0 is capture free because the QF language has no binders.
    # It must nevertheless reach a counter occurrence nested in a product term.
    hidden_n = Pair(n, ZERO)
    zero_probe = Eq(Iter("lag", ZERO, hidden_n), Pair(ZERO, ZERO))
    gate_test("full literal zero substitution", language, "lag", zero_probe, N, True, "Z")

    return {
        "scope": "Finite syntax and admission diagnostics; not a mathematical proof certificate",
        "normalization_performed": False,
        "number_of_tests": len(results),
        "passed": all(item["passed"] for item in results),
        "tests": results,
    }


if __name__ == "__main__":
    report = self_tests()
    if "--json" in sys.argv:
        print(json.dumps(report, indent=2))
    else:
        for result in report["tests"]:
            print(("PASS" if result["passed"] else "FAIL") + ": " + result["test"])
        print(f"{report['number_of_tests']} tests; overall {'PASS' if report['passed'] else 'FAIL'}")
        print(report["scope"])
    raise SystemExit(0 if report["passed"] else 1)
