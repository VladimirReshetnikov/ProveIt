#!/usr/bin/env python3
"""Executable finite-description compiler: primitive recursion -> tuple iteration.

This is a typed syntax implementation and finite numerical diagnostic, not a
proof-assistant formalization.  The universal correctness proof is in report.tex.
It uses no external packages.  Run with Python 3.10 or later.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import itertools
import json
import math
from pathlib import Path
from typing import Any

N = "N"
Type = Any


def product(a: Type, b: Type) -> Type:
    return (a, b)


def dimension(t: Type) -> int:
    return 1 if t == N else dimension(t[0]) + dimension(t[1])


@dataclass(frozen=True)
class PR:
    op: str
    arity: int
    args: tuple = ()


def zero(arity: int) -> PR:
    if arity < 0:
        raise ValueError("negative arity")
    return PR("zero", arity)


SUCC = PR("succ", 1)


def projection(arity: int, index: int) -> PR:
    if not 0 <= index < arity:
        raise ValueError("projection outside its arity")
    return PR("proj", arity, (index,))


def compose(f: PR, gs: tuple[PR, ...], arity: int | None = None) -> PR:
    if len(gs) != f.arity:
        raise ValueError("composition argument count")
    m = gs[0].arity if gs else arity
    if m is None or m < 0 or any(g.arity != m for g in gs):
        raise ValueError("composition source arity")
    return PR("comp", m, (f, gs))


def recurse(base: PR, step: PR) -> PR:
    # f(n,b) = Rec(base,step)(n,b); step arguments are (n,b,previous).
    if step.arity != base.arity + 2:
        raise ValueError("recursion step arity")
    return PR("rec", base.arity + 1, (base, step))


def evaluate_pr(f: PR, xs: tuple[int, ...]) -> int:
    if len(xs) != f.arity or any(x < 0 for x in xs):
        raise ValueError("PR input")
    if f.op == "zero":
        return 0
    if f.op == "succ":
        return xs[0] + 1
    if f.op == "proj":
        return xs[f.args[0]]
    if f.op == "comp":
        g, hs = f.args
        return evaluate_pr(g, tuple(evaluate_pr(h, xs) for h in hs))
    if f.op == "rec":
        g, h = f.args
        n, *b = xs
        value = evaluate_pr(g, tuple(b))
        for k in range(n):
            value = evaluate_pr(h, (k, *b, value))
        return value
    raise ValueError("unknown PR constructor")


@dataclass(frozen=True)
class Term:
    op: str
    type: Type
    args: tuple = ()


def var(name: str, t: Type = N) -> Term:
    return Term("var", t, (name,))


ZERO = Term("zero", N)


def succ(t: Term) -> Term:
    if t.type != N:
        raise ValueError("successor requires N")
    return Term("succ", N, (t,))


def pair(a: Term, b: Term) -> Term:
    return Term("pair", product(a.type, b.type), (a, b))


def first(t: Term) -> Term:
    if t.type == N:
        raise ValueError("first projection requires a product")
    return Term("fst", t.type[0], (t,))


def second(t: Term) -> Term:
    if t.type == N:
        raise ValueError("second projection requires a product")
    return Term("snd", t.type[1], (t,))


def pack(xs: tuple[Term, ...]) -> Term:
    if not xs:
        raise ValueError("empty product not part of this syntax")
    return xs[0] if len(xs) == 1 else pair(xs[0], pack(xs[1:]))


def unpack(t: Term, length: int) -> tuple[Term, ...]:
    if length == 1:
        return (t,)
    if length < 1:
        raise ValueError("empty product not part of this syntax")
    return (first(t), *unpack(second(t), length - 1))


@dataclass(frozen=True)
class Iterator:
    identifier: int
    binder: str
    state_type: Type
    body: Term


def free_vars(t: Term) -> set[str]:
    if t.op == "var":
        return {t.args[0]}
    if t.op == "zero":
        return set()
    if t.op == "iter":
        # The body is immutable symbol metadata, never an active term argument.
        return free_vars(t.args[1]) | free_vars(t.args[2])
    return set().union(*(free_vars(x) for x in t.args))


def descriptor_ids(t: Term) -> set[int]:
    if t.op in {"var", "zero"}:
        return set()
    if t.op == "iter":
        d, n, a = t.args
        return {d.identifier} | descriptor_ids(n) | descriptor_ids(a)
    return set().union(*(descriptor_ids(x) for x in t.args))


def iterate(d: Iterator, n: Term, a: Term) -> Term:
    if n.type != N or a.type != d.state_type:
        raise ValueError("iterator input type")
    return Term("iter", d.state_type, (d, n, a))


def evaluate_term(t: Term, env: dict[str, Any]) -> Any:
    if t.op == "var":
        return env[t.args[0]]
    if t.op == "zero":
        return 0
    if t.op == "succ":
        return evaluate_term(t.args[0], env) + 1
    if t.op == "pair":
        return tuple(evaluate_term(x, env) for x in t.args)
    if t.op == "fst":
        return evaluate_term(t.args[0], env)[0]
    if t.op == "snd":
        return evaluate_term(t.args[0], env)[1]
    if t.op == "iter":
        d, n, a = t.args
        count, state = evaluate_term(n, env), evaluate_term(a, env)
        for _ in range(count):
            state = evaluate_term(d.body, {d.binder: state})
        return state
    raise ValueError("unknown tuple term")


class Compiler:
    def __init__(self) -> None:
        self.descriptors: list[Iterator] = []
        self.next_binder = 0

    def compile(self, f: PR, xs: tuple[Term, ...]) -> Term:
        if len(xs) != f.arity or any(x.type != N for x in xs):
            raise ValueError("compiler input")
        if f.op == "zero":
            return ZERO
        if f.op == "succ":
            return succ(xs[0])
        if f.op == "proj":
            return xs[f.args[0]]
        if f.op == "comp":
            g, hs = f.args
            return self.compile(g, tuple(self.compile(h, xs) for h in hs))
        if f.op != "rec":
            raise ValueError("unknown PR description")
        g, h = f.args
        n, *params = xs
        b = tuple(params)
        initial_value = self.compile(g, b)
        seed = pair(ZERO, pair(pack(b), initial_value)) if b else pair(ZERO, initial_value)
        binder = f"state_{self.next_binder}"
        self.next_binder += 1
        state = var(binder, seed.type)
        counter = first(state)
        old_value = second(second(state)) if b else second(state)
        frozen = unpack(first(second(state)), len(b)) if b else ()
        new_value = self.compile(h, (counter, *frozen, old_value))
        update = pair(succ(counter), pair(first(second(state)), new_value)) if b else pair(succ(counter), new_value)
        # All iterators encountered inside the update have already been emitted.
        identifier = len(self.descriptors)
        d = Iterator(identifier, binder, state.type, update)
        if free_vars(update) - {binder}:
            raise RuntimeError("a supposedly unary update captured an external parameter")
        if any(j >= identifier for j in descriptor_ids(update)):
            raise RuntimeError("non-well-founded description")
        self.descriptors.append(d)
        result = iterate(d, n, seed)
        return second(second(result)) if b else second(result)


def text_term(t: Term) -> str:
    if t.op == "zero":
        return "0"
    if t.op == "var":
        return t.args[0]
    if t.op == "iter":
        d, n, a = t.args
        return f"I{d.identifier}({text_term(n)}, {text_term(a)})"
    if t.op == "pair":
        return f"({text_term(t.args[0])}, {text_term(t.args[1])})"
    label = {"succ": "S", "fst": "fst", "snd": "snd"}[t.op]
    return f"{label}({text_term(t.args[0])})"


def test_programs() -> dict[str, PR]:
    add = recurse(projection(1, 0), compose(SUCC, (projection(3, 2),)))
    pred = recurse(zero(0), projection(2, 0))
    mul = recurse(zero(1), compose(add, (projection(3, 1), projection(3, 2))))
    sub = recurse(projection(1, 0), compose(pred, (projection(3, 2),)))
    one = compose(SUCC, (zero(0),))
    fact_step = compose(mul, (compose(SUCC, (projection(2, 0),)), projection(2, 1)))
    fact = recurse(one, fact_step)
    # f(n,a,b)=a+n*b is a genuine two-parameter recursion.
    affine = recurse(projection(2, 0), compose(add, (projection(4, 2), projection(4, 3))))
    return {"predecessor": pred, "addition": add, "multiplication": mul,
            "truncated_subtraction": sub, "factorial": fact, "affine_two_parameters": affine}


def coding_pair(x: int, y: int) -> int:
    return (x + y) ** 2 + x


def bounded_decode(z: int) -> tuple[int, int]:
    # Exactly the double-sum code used in the paper, with gaps decoded to (0,0).
    matches = [(x, y) for x in range(z + 1) for y in range(z + 1)
               if coding_pair(x, y) == z]
    return sum(x for x, _ in matches), sum(y for _, y in matches)


def run_checks() -> dict:
    rows = []
    total = 0
    expected = {
        "predecessor": lambda n: max(n - 1, 0),
        "addition": lambda n, a: n + a,
        "multiplication": lambda n, a: n * a,
        "truncated_subtraction": lambda n, a: max(a - n, 0),
        "factorial": math.factorial,
        "affine_two_parameters": lambda n, a, b: a + n * b,
    }
    for name, f in test_programs().items():
        c = Compiler()
        variables = tuple(var(f"x{i}") for i in range(f.arity))
        t = c.compile(f, variables)
        bound = 6 if name == "factorial" else 8
        cases = 0
        for xs in itertools.product(range(bound), repeat=f.arity):
            source = evaluate_pr(f, xs)
            compiled = evaluate_term(t, dict(zip((v.args[0] for v in variables), xs)))
            if source != compiled or source != expected[name](*xs):
                raise RuntimeError((name, xs, source, compiled))
            cases += 1
        total += cases
        rows.append({"program": name, "cases": cases,
                     "iterator_descriptions": len(c.descriptors),
                     "maximum_state_dimension": max(dimension(d.state_type) for d in c.descriptors),
                     "compiled_term": text_term(t),
                     "updates": [{"id": d.identifier, "bound_state": d.binder,
                                  "state_dimension": dimension(d.state_type),
                                  "body": text_term(d.body)} for d in c.descriptors]})
    pairs = 0
    for x in range(7):
        for y in range(7):
            if bounded_decode(coding_pair(x, y)) != (x, y):
                raise RuntimeError("coding retraction")
            pairs += 1
    rejected = 0
    for bad in [lambda: projection(2, 2), lambda: recurse(zero(2), SUCC),
                lambda: compose(SUCC, (zero(1), zero(1))),
                lambda: succ(pair(ZERO, ZERO)), lambda: first(ZERO)]:
        try:
            bad()
        except ValueError:
            rejected += 1
        else:
            raise RuntimeError("negative control unexpectedly accepted")
    return {"status": "PASS", "scope": "finite typed compiler and standard-natural diagnostics; not a universal proof certificate",
            "compiled_evaluation_cases": total, "pairing_retraction_cases": pairs,
            "negative_controls": rejected, "programs": rows}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    report = run_checks()
    if args.json:
        args.json.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "programs"}, indent=2))
