#!/usr/bin/env python3
"""Finite syntax checks for the scalar literal S15 presentation.

Only finite trees are manipulated.  This program does not evaluate arithmetic,
normalize terms, search for proofs, or certify bi-interpretability.

Admitted matrices F(n,a):
  * quantifier-free, with F(0,a) literally B(a) -> B(a);
  * exactly R_h(0,a)=a;
  * exactly forall b [R_h(Sa,b)=h(a,R_h(a,b))];
  * exactly (0=S0) -> false.
The last three constructors are stationary in n.  The fixed bound name in the
third constructor is b.  There is no alpha-equivalence or equation-orientation
test.  A descriptor's stored update is part of its function-symbol name and
is not traversed when substituting in an application of that symbol.

Run with Python 3.10 or later.  The optional --json PATH writes the same finite
verification report that is printed to standard output.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


Tree = tuple[Any, ...]


def V(name: str) -> Tree:
    return ("v", name)


ZERO: Tree = ("0",)
BOT: Tree = ("bot",)


def S(term: Tree) -> Tree:
    return ("S", term)


def R(name: str, counter: Tree, seed: Tree) -> Tree:
    return ("R", name, counter, seed)


def Eq(left: Tree, right: Tree) -> Tree:
    return ("=", left, right)


def Imp(left: Tree, right: Tree) -> Tree:
    return ("imp", left, right)


def All(name: str, body: Tree) -> Tree:
    return ("all", name, body)


def term_variables(term: Tree) -> set[str]:
    tag = term[0]
    if tag == "v":
        return {term[1]}
    if tag == "0":
        return set()
    if tag == "S":
        return term_variables(term[1])
    if tag == "R":
        # The stored descriptor is deliberately not traversed.
        return term_variables(term[2]) | term_variables(term[3])
    raise ValueError("Not a term tree")


def formula_variables(formula: Tree) -> set[str]:
    tag = formula[0]
    if tag == "bot":
        return set()
    if tag == "=":
        return term_variables(formula[1]) | term_variables(formula[2])
    if tag in {"and", "or", "imp"}:
        return formula_variables(formula[1]) | formula_variables(formula[2])
    if tag == "all":
        return formula_variables(formula[2]) - {formula[1]}
    raise ValueError("Not a formula tree")


def substitute_term(term: Tree, substitution: dict[str, Tree]) -> Tree:
    """Simultaneous substitution: do not substitute again in inserted trees."""
    tag = term[0]
    if tag == "v":
        return substitution.get(term[1], term)
    if tag == "0":
        return term
    if tag == "S":
        return S(substitute_term(term[1], substitution))
    if tag == "R":
        return R(
            term[1],
            substitute_term(term[2], substitution),
            substitute_term(term[3], substitution),
        )
    raise ValueError("Not a term tree")


def substitute_qf(formula: Tree, substitution: dict[str, Tree]) -> Tree:
    """Substitution is needed only in the quantifier-free grammar branch."""
    tag = formula[0]
    if tag == "bot":
        return formula
    if tag == "=":
        return Eq(
            substitute_term(formula[1], substitution),
            substitute_term(formula[2], substitution),
        )
    if tag in {"and", "or", "imp"}:
        return (
            tag,
            substitute_qf(formula[1], substitution),
            substitute_qf(formula[2], substitution),
        )
    raise ValueError("Quantified formulas cannot enter the QF branch")


def is_qf(formula: Tree) -> bool:
    if formula[0] in {"bot", "="}:
        return True
    if formula[0] in {"and", "or", "imp"}:
        return is_qf(formula[1]) and is_qf(formula[2])
    return False


class Descriptors:
    """Finite dependency-ordered fragment of the effective full language."""

    def __init__(self) -> None:
        self.updates: dict[str, Tree] = {}

    def valid_term(self, term: Any) -> bool:
        if not isinstance(term, tuple) or not term:
            return False
        tag = term[0]
        if tag == "v":
            return len(term) == 2 and isinstance(term[1], str) and bool(term[1])
        if tag == "0":
            return len(term) == 1
        if tag == "S":
            return len(term) == 2 and self.valid_term(term[1])
        if tag == "R":
            return (
                len(term) == 4
                and isinstance(term[1], str)
                and term[1] in self.updates
                and self.valid_term(term[2])
                and self.valid_term(term[3])
            )
        return False

    def valid_formula(self, formula: Any) -> bool:
        if not isinstance(formula, tuple) or not formula:
            return False
        tag = formula[0]
        if tag == "bot":
            return len(formula) == 1
        if tag == "=":
            return (
                len(formula) == 3
                and self.valid_term(formula[1])
                and self.valid_term(formula[2])
            )
        if tag in {"and", "or", "imp"}:
            return (
                len(formula) == 3
                and self.valid_formula(formula[1])
                and self.valid_formula(formula[2])
            )
        if tag == "all":
            return (
                len(formula) == 3
                and isinstance(formula[1], str)
                and bool(formula[1])
                and self.valid_formula(formula[2])
            )
        return False

    def add(self, name: str, update: Tree) -> None:
        if not isinstance(name, str) or not name or name in self.updates:
            raise ValueError("Descriptor names must be new nonempty strings")
        # Checking before insertion forbids self-reference and later references.
        if not self.valid_term(update):
            raise ValueError("An update may use only earlier descriptors")
        if not term_variables(update) <= {"u", "v"}:
            raise ValueError("An update may use only counter u and state v")
        self.updates[name] = update


def initialization(name: str) -> Tree:
    return Eq(R(name, ZERO, V("a")), V("a"))


def successor(descriptors: Descriptors, name: str) -> Tree:
    a, b = V("a"), V("b")
    right = substitute_term(
        descriptors.updates[name], {"u": a, "v": R(name, a, b)}
    )
    return All("b", Eq(R(name, S(a), b), right))


SEPARATION = Imp(Eq(ZERO, S(ZERO)), BOT)


def admit(descriptors: Descriptors, formula: Any) -> str | None:
    """Return the exact matching branch, or None; perform no rewriting."""
    if not descriptors.valid_formula(formula):
        return None
    if not formula_variables(formula) <= {"n", "a"}:
        return None

    if is_qf(formula):
        zero_instance = substitute_qf(formula, {"n": ZERO})
        if zero_instance[0] == "imp" and zero_instance[1] == zero_instance[2]:
            return "literal_reflexive_base"

    if formula[0] == "=" and formula[1][0] == "R":
        name = formula[1][1]
        if formula == initialization(name):
            return "stationary_initialization"

    if formula[0] == "all" and formula[1] == "b":
        body = formula[2]
        if body[0] == "=" and body[1][0] == "R":
            name = body[1][1]
            if formula == successor(descriptors, name):
                return "stationary_successor"

    if formula == SEPARATION:
        return "stationary_separation"
    return None


def finite_checks() -> dict[str, Any]:
    language = Descriptors()
    language.add("counter", V("u"))
    language.add("zero", ZERO)
    language.add("next", S(V("v")))
    language.add("pred_state", R("counter", V("v"), ZERO))
    language.add("mixed", R("next", V("u"), V("v")))
    results: list[dict[str, Any]] = []

    def check(name: str, formula: Tree, expected: str | None) -> None:
        actual = admit(language, formula)
        if actual != expected:
            raise AssertionError(f"{name}: expected {expected!r}, got {actual!r}")
        results.append({"name": name, "expected": expected, "observed": actual})

    n, a, b, c = map(V, ("n", "a", "b", "c"))
    atoms = [
        BOT,
        Eq(n, a),
        Eq(n, ZERO),
        Eq(R("next", n, a), S(a)),
        Eq(R("mixed", n, R("pred_state", a, ZERO)), a),
    ]
    matrices = list(atoms)
    for connective in ("and", "or", "imp"):
        matrices.extend((connective, left, right) for left in atoms for right in atoms)
    for index, matrix in enumerate(matrices):
        normalized_template = Imp(substitute_qf(matrix, {"n": ZERO}), matrix)
        check(f"qf_induction_template_{index:03d}", normalized_template,
              "literal_reflexive_base")

    for name in language.updates:
        check(f"initialization_{name}", initialization(name), "stationary_initialization")
        check(f"successor_{name}", successor(language, name), "stationary_successor")

    check("separation", SEPARATION, "stationary_separation")
    check("broader_than_fixed_G_template", Imp(Eq(n, ZERO), Eq(ZERO, ZERO)),
          "literal_reflexive_base")
    check("stationary_reflexive_formula", Imp(Eq(a, a), Eq(a, a)),
          "literal_reflexive_base")

    check("one_seed_contraction_is_not_literal",
          Imp(initialization("next"), Eq(a, a)), None)
    check("two_seed_contractions_are_not_literal",
          Imp(Eq(R("next", ZERO, a), R("next", ZERO, a)), Eq(a, a)), None)
    check("symmetric_initialization_orientation", Eq(a, R("next", ZERO, a)), None)
    check("nonzero_initialization_counter", Eq(R("next", S(ZERO), a), a), None)
    check("semantic_reflexivity_does_not_replace_literal_comparison",
          Imp(Eq(R("next", ZERO, a), a), Eq(a, R("next", ZERO, a))), None)
    check("foreign_free_variable", Imp(Eq(c, c), Eq(c, c)), None)
    check("foreign_free_variable_inside_quantifier",
          All("b", Eq(R("next", S(a), b), S(R("next", c, b)))), None)
    check("wrong_successor_state",
          All("b", Eq(R("next", S(a), b), S(R("next", a, ZERO)))), None)
    check("wrong_successor_counter",
          All("b", Eq(R("next", S(S(a)), b), S(R("next", a, b)))), None)
    check("wrong_successor_descriptor",
          All("b", Eq(R("next", S(a), b), S(R("zero", a, b)))), None)
    check("reversed_successor_equation",
          All("b", Eq(S(R("next", a, b)), R("next", S(a), b))), None)
    check("renamed_bound_variable_is_not_literal",
          All("c", Eq(R("next", S(a), c), S(R("next", a, c)))), None)
    check("counter_dependent_quantified_matrix_with_correct_zero_instance",
          All("b", Eq(R("zero", S(a), b), n)), None)
    check("old_wrapped_successor_probe_is_not_a_new_constructor",
          Imp(All("b", Eq(S(R("next", a, b)), S(R("next", a, b)))),
              successor(language, "next")), None)
    check("arbitrary_quantified_reflexive_formula",
          Imp(All("b", Eq(a, b)), All("b", Eq(a, b))), None)
    check("unknown_descriptor", Eq(R("missing", ZERO, a), a), None)
    check("nonreflexive_zero_base", Imp(Eq(n, a), Eq(a, a)), None)
    check("malformed_arity", ("=", ("R", "next", ZERO), a), None)

    # Explicit descriptor hygiene controls, separate from matrix admission.
    descriptor_controls = []
    for label, name, update in [
        ("self_reference", "cycle", R("cycle", V("u"), V("v"))),
        ("undeclared_reference", "future", R("later", V("u"), V("v"))),
        ("hidden_frozen_parameter", "parameter", V("a")),
        ("duplicate_name", "next", ZERO),
    ]:
        try:
            language.add(name, update)
        except ValueError:
            descriptor_controls.append({"name": label, "rejected": True})
        else:
            raise AssertionError(f"Descriptor control unexpectedly accepted: {label}")

    before = dict(language.updates)
    application = R("mixed", n, a)
    transformed = substitute_term(application, {"n": ZERO, "a": S(n)})
    if transformed != R("mixed", ZERO, S(n)) or language.updates != before:
        raise AssertionError("Substitution traversed stored descriptions or inserted trees")

    return {
        "presentation": "scalar literal S15",
        "status": "all finite syntax checks passed",
        "scope": (
            "Finite admission and descriptor-hygiene diagnostics only. "
            "No arithmetic evaluation, proof search, proof-assistant verification, "
            "or independent certification of bi-interpretability is performed."
        ),
        "descriptor_count": len(language.updates),
        "matrix_check_count": len(results),
        "accepted_matrix_count": sum(r["observed"] is not None for r in results),
        "rejected_matrix_count": sum(r["observed"] is None for r in results),
        "descriptor_control_count": len(descriptor_controls),
        "substitution_hygiene_check": "passed",
        "matrix_checks": results,
        "descriptor_controls": descriptor_controls,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, help="also write the finite report to this path")
    arguments = parser.parse_args()
    report = finite_checks()
    rendered = json.dumps(report, indent=2, ensure_ascii=True) + "\n"
    if arguments.json is not None:
        arguments.json.parent.mkdir(parents=True, exist_ok=True)
        arguments.json.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
