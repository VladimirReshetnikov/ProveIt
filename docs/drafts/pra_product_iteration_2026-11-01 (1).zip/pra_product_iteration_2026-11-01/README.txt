PRA BY PRODUCT ITERATION AND LITERAL ADMISSION
Research report prepared for Vladimir Reshetnikov, 1 November 2026

START HERE
  report.pdf       Complete 15-page mathematical report (page count may
                   change slightly with the TeX distribution).
  report.tex       Full editable LaTeX source; no external TeX input files.
  AXIOMS.txt       Complete extractable specifications and interpretation scope.

MAIN RESULT
Finite product states permit one uniform pure-iteration constructor, without
a special counter-reading descriptor. A single propagation schema with three
literal base shapes recovers computation, separation, and all quantifier-free
induction. Every matrix is quantifier-free. The complete specification works
constructively and therefore in both matching logics.

The ordinary scalar expansion is bi-interpretable with first-order PRA by
inverse whole-domain term translations. The version with genuine product
sorts has the corresponding explicit finite-dimensional many-sorted
bi-interpretation. Both round trips are proved internally, including the
target coding retraction and the uniqueness argument.

WHAT IS AND IS NOT AN IMPROVEMENT
The earlier drafts already reach a 15-node OUTER display. This report does
not claim a new 15-node record. It removes several exceptions and the
local-rewrite admission machinery by changing to explicit product states.
Products expand to arbitrary finite scalar tuples: scalar arity and scalar
variable bounds increase. No absolute shortest total encoding is established.

A secondary scalar L15 refinement preserves the original binary language,
replaces local-rewrite admission by literal alternatives, and shortens the
chosen stationary computation axioms. Its one-parameter scalar arithmetic
bootstrap is inherited from the pinned draft sources, as stated in the report.
The main product proof does not depend on that imported scalar calibration.

CONTENTS
  checks/product_gate.py        Exact three-case typed gate and 27 diagnostics.
  checks/literal_gate.py        Scalar L15 gate and hygiene diagnostics.
  checks/iteration_compiler.py  Executable PR-to-tuple-iteration compiler.
  audit/*checks.json            Recorded exact finite diagnostic results.
  audit/source_manifest.json    Seven source archives, immutable URLs, Git blob
                               SHA-1 identities, byte sizes, and SHA-256 hashes.
  audit/mathematical_review.txt Independent review of the written argument.
  audit/document_validation.txt Build and visual layout verification summary.
  build.py                     Rebuilds the PDF and optionally replays checks.
  SHA256SUMS.txt                Release payload integrity hashes.

VERIFICATION BOUNDARY
All included checks are finite executable diagnostics. They are NOT Lean,
Rocq, or another proof-assistant formalization, and do not certify arbitrary
models. Universal correctness and both bi-interpretation round trips are
proved in the mathematical text. The report separates standard function
theory, internal source-theory proofs, and finite numerical experiments.

REPRODUCTION
Required: Python 3.10+ and pdflatex with the ordinary packages listed in
report.tex (TeX Live is sufficient). No third-party Python packages are used
by the mathematical checks.

  python3 build.py --checks

The check reports are written to audit/. Build logs go there as well.
The PDF uses no shell escape and requires no network access.

SOURCE SNAPSHOT
  VladimirReshetnikov/ProveIt
  0e1088217e60a865ee39f86a5563cadbbbc5875f
  docs/drafts (seven archives at retrieval)

The source archives were read as mathematical inputs, not executed.
They are not duplicated in this release; the exact immutable retrieval
identities and paths are in the source manifest. Older eight-archive counts
inside the reviewed documents refer to historical snapshots.
