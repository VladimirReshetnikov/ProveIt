#!/usr/bin/env python3
"""Build the report; optionally replay its finite syntax/compiler diagnostics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checks", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    if args.checks:
        names = [("product_gate", "product_gate_checks"),
                 ("literal_gate", "literal_gate_checks"),
                 ("iteration_compiler", "compiler_checks")]
        for script, output in names:
            process = subprocess.run(
                [sys.executable, str(root / "checks" / (script + ".py")),
                 "--json", str(audit / (output + ".json"))],
                cwd=root, text=True, capture_output=True, check=False)
            (audit / (script + "_console.txt")).write_text(process.stdout + process.stderr)
            if process.returncode:
                raise SystemExit(f"Diagnostic failed: {script}; see its audit log")
            print(f"PASS: {script}")
    latex = shutil.which("pdflatex")
    if not latex:
        raise SystemExit("pdflatex is required to rebuild report.pdf")
    for number in range(1, 4):
        process = subprocess.run(
            [latex, "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "-file-line-error", "report.tex"],
            cwd=root, text=True, capture_output=True, check=False)
        (audit / f"latex_pass_{number}.txt").write_text(process.stdout + process.stderr)
        if process.returncode:
            raise SystemExit(f"LaTeX failed on pass {number}; see audit/latex_pass_{number}.txt")
    log = (root / "report.log").read_text(errors="replace")
    problems = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()]
    summary = {"pdf": "report.pdf", "passes": 3,
               "layout_or_reference_warnings": problems,
               "scope": "Build diagnostics; visual inspection is a separate release check."}
    (audit / "build_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print("Built report.pdf")
    if problems:
        print("Review layout/reference warnings in audit/build_summary.json")


if __name__ == "__main__":
    main()
