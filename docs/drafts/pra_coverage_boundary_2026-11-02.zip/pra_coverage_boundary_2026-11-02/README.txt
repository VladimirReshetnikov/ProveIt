PRA FROM UNSHIFTED BOUNDARY WITNESSES
Research package prepared for Vladimir Reshetnikov, 2 November 2026

MAIN RESULT

The report gives a complete effective first-order theory CB in the
normalized binary-recursion language of three current ProveIt drafts.
It proves that CB and first-order PRA have a common conservative
definitional extension, hence are bi-interpretable and equiconsistent.
The interpretations preserve the whole carrier and native equality;
both round trips are internally the identity.

The new induction-bearing sentence is

  forall a n exists b,
    R_h(b,a)=a and (R_h(Sb,a)=a -> b=n).

It has 19 active nodes and 19+2W fully charged nodes for a canonical
descriptor of full size W. Explicit zero-or-successor coverage allows
the old successor shifts and the special counter-zero guard to be
removed. Coverage is charged in the calibration, not granted for free.

The exact emitter is pointwise no larger in either inherited tree
measure than the current scalar coordinatewise envelope, and strictly
smaller at the two calibration inputs and all old special return inputs.
The fourth, autonomous-orbits draft is included as a stated comparison
of matched complete cores because its primary language is different.
No encoding-independent global minimum or full proof formalization is
claimed.

START HERE

  report.pdf          Complete mathematical report.
  report.tex          Main LaTeX source; includes sections/*.tex.
  AXIOMS.txt          Exact language and complete axiom emitter.
  Makefile            Build and verification commands.

VERIFICATION

  formal/BoundaryCoverage.lean
    Lean 4.19.0, standard library only. Checks the arbitrary-carrier
    forward induction kernel, exact latch reflection, and the reverse
    boundary-search invariant. No sorry/admit or classical choice.
    The reverse theorem explicitly assumes the one invariant induction
    instance that PRA supplies. Full staged syntax, pairing, the PR
    compiler, and first-order bi-interpretation are proved in the report,
    not formalized in this kernel.

  formal/axiom-audit.txt, formal/lean-version.txt
    Recorded kernel audit and tested version. Some results use Lean's
    propext for proposition rewriting; no choice axiom appears.

  verification/check_sizes.py
    Independent Python AST implementation of both metrics and the
    actual emitters. Includes the old Local Return optional selector.
    Finite tests supplement the general inequalities proved in report.

  verification/results.json
    PASS: 25,814 distinct inputs, including all 22,107 base-alphabet
    terms through active size seven; all six new formula forms tested.
    22,717 strict improvements in both measures; 23,418 in full size.

  verification/all_counts.csv, examples.csv, family.csv,
  verification/example_formulas.json
    Per-input counts, representative fully expanded formulas, and a
    strict infinite-family calculation with checked finite examples.

  provenance/snapshot.json
    Immutable GitHub URLs, Git blob hashes, and SHA-256 hashes of all
    four comparison archives at commit
    53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4.

  SHA256SUMS.txt
    Checksums for the delivered package files, except this checksum
    file itself. Build-generated intermediates are not included.

REPRODUCE

From this directory:

  python3 verification/check_sizes.py
  lean formal/BoundaryCoverage.lean
  latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

Requirements: Python 3.10 or later (standard library only), Lean 4.19.0
with Std, and an ordinary TeX installation with latexmk. An elan setup
uses the included root lean-toolchain. The Makefile supplies equivalent
targets: make check, make lean, make pdf.

PROVENANCE AND CREDIT

The source archives were downloaded from the user-specified ProveIt
docs/drafts directory and verified against Git's blob hashes. They are
not duplicated in this deliverable. The report credits the inherited
normalized grammar, raw-alias recovery method, state-binding branch,
and triangular pairing retraction. The new contribution is the
coverage calibration, unshifted boundary selection, and complete
current-envelope reduction. No repository changes were published.
