# Executable syntax and size audit

Run from the archive root with Python 3.10 or later:

```sh
python3 verification/check_sizes.py
```

The checker uses only the Python standard library. It writes its results beside
the script. The default exhaustive active-tree bound is seven; `--max-size 8`
is available for a larger run, and `--output-dir PATH` redirects the generated
files. The default run is the one supplied with this archive.

## What is represented

Terms and formulas are actual immutable syntax trees. Variables, constants,
function applications, equalities, connectives, falsity, and quantifiers each
contribute one active node. A quantified variable's annotation contributes no
additional node. Negation is built as implication to falsity, and one is built
as successor applied to zero.

Every recursor application stores its finite descriptor separately from its
active arguments. The full measure recursively charges that descriptor at
every occurrence; it does not share descriptors as a DAG. Active substitution
and occurrence counting leave stored descriptors untouched. In particular,
the substitution tests also target the stored slot names `v,w`, so that an
accidental traversal into a descriptor would be detected.

The root normalizer strips only literal outer `Q(S(r),s)` layers. It neither
walks into other arguments nor rewrites stored descriptors. The program checks
normalization idempotence, size nonincrease, and descriptor preservation under
the double alias used in the proof. Every tested double alias must reach an
ordinary or state-bound computation branch.

## Which formulas are compared

The new emitter has the exact six cases in the report:

1. At `Q(S(n),a)`, emit only the 18-node equality-bit sentence.
2. At `Z(chi(n,0),a)`, emit separation and coverage, with costs 18/19.
3. If the body is canonical and the retained computation formula has at least
   19 active nodes, emit the unshifted boundary sentence.
4. Otherwise, if the body is autonomous, emit right recursion.
5. Otherwise, with at least four state occurrences, emit state-bound left
   recursion.
6. Otherwise emit ordinary left recursion.

The retained computation in case 3 is right recursion on autonomous bodies,
state-bound left recursion on other bodies with at least four state
occurrences, and ordinary left recursion otherwise. Thus the boundary test
precedes the autonomous branch, as in the final specification.

The incumbent formulas are independently reconstructed from the four source
archives in `docs/drafts` at ProveIt commit
`53f59452ff3340cfdff9b1ac34c80d14ee2ce1b4`:

- `pra_boundary_witness_2026-11-02.zip`: the four-case boundary emitter;
- `pra_local_return_2026-11-02.zip`: its primary emitter and optional broader
  return-pattern recognition;
- `pra_rooted_return_2026-11-02.zip`: its five-case emitter, including
  state binding at four state occurrences;
- `pra_autonomous_orbits_2026-11-02.zip`: the primary autonomous orbit template
  and its active, full, and joint generated optimizers, on matched `k=0`
  profiles.

The first three comparisons are literal comparisons in the shared normalized
binary language. Autonomous Orbits has a different descriptor grammar and
fixed resources. Its comparisons here are explicitly structural-profile
comparisons of its **complete recurring templates**, with its separate fixed
axioms omitted in its favor. The checker does not compare the new theory to
an isolated no-descent payload while treating that payload's computation
theory as free.

No code was copied from the earlier checkers. Their specified mathematical
formulas and counting conventions are the benchmark being independently
reimplemented.

## Supplied outputs

- `results.json`: run totals, coverage of all branches, checks, and examples.
- `all_counts.csv`: one row for every distinct tested input, including its
  active/full profile, selected branch, new costs, and coordinatewise current
  minima.
- `examples.csv`: a short table of representative cases.
- `example_formulas.json`: actual emitted formulas and individual incumbent
  formulas for the examples, together with their AST sizes.
- `family.csv`: the unbounded-improvement family's checked instances for
  `k=3,...,40`.

The default run enumerates every tree through active size seven over
`0,n,a,S,chi,Q,Z`, then adds all three incumbent marked families on smaller
tails, normalization aliases, high-occurrence terms, autonomous threshold
examples, and three deterministic finite stages of nested stored descriptors.
Random enrichment uses seed `20261102`; exhaustive generation itself is not
random. Duplicate inputs are counted only once.

## Unbounded family and limits

Let `t_0=a`, `t_(k+1)=Q(n,t_k)`, and `u_k=Z(n,t_k)`. For `k>=3`,

```text
m = 2k+3,   W = V = 3k+4,   i = k+1,   j = 1.

New:             active = 19,       full = 6k+27.
Current minimum: active = 2k+23,     full = 12k+36.
```

The current winner is Rooted Return's state-bound computation, so this is
compared with the current linear bound rather than an obsolete quadratic
ordinary-computation count. The constant new active core still has a growing
stored descriptor; the full measure makes that growth explicit.

This program verifies finite syntax, exact counts, and routing. It does not
verify a first-order proof, induction recovery, model interpretations, or
universal optimality. The report's symbolic inequalities prove the all-input
comparison; its mathematical proofs establish bi-interpretability. Passing
finite enumeration is supplementary evidence and is not a replacement for
either proof.
