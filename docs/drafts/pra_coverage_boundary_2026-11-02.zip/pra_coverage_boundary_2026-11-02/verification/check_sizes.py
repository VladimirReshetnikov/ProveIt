#!/usr/bin/env python3
"""Independent syntax audit for the coverage/boundary presentation of PRA.

Python 3.10+, standard library only.  This checks finite syntax and sizes,
not the mathematical calibration theorem.  The mathematical proof supplies
the unbounded inequalities.  No code from an earlier checker is copied.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import random
from collections import Counter
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Tree:
    kind: str
    label: str = ""
    children: tuple["Tree", ...] = ()
    descriptor: "Tree | None" = None
    _hash: int = field(init=False, compare=False, repr=False)

    def __post_init__(self):
        object.__setattr__(self, "_hash", hash(
            (self.kind, self.label, self.children, self.descriptor)))

    def __hash__(self):
        return self._hash


def var(name):
    return Tree("variable", name)


N, A, B, C, K, J = map(var, ("n", "a", "b", "c", "k", "j"))
V, W = map(var, ("v", "w"))
ZERO = Tree("application", "0")


def app(name, *args, descriptor=None):
    return Tree("application", name, tuple(args), descriptor)


def succ(x):
    return app("S", x)


def chi(x, y):
    return app("chi", x, y)


def q(x, y):
    return app("Q", x, y, descriptor=W)


def z(x, y):
    return app("Z", x, y, descriptor=ZERO)


ONE = succ(ZERO)


def connective(kind, *args):
    return Tree(kind, children=tuple(args))


def eq(x, y):
    return connective("=", x, y)


def conjunction(x, y):
    return connective("and", x, y)


def disjunction(x, y):
    return connective("or", x, y)


def implies(x, y):
    return connective("implies", x, y)


def negate(x):
    return implies(x, Tree("false"))


def forall(variable, formula):
    return Tree("forall", variable.label, (formula,))


def exists(variable, formula):
    return Tree("exists", variable.label, (formula,))


def close(formula):
    return forall(A, forall(N, formula))


@lru_cache(maxsize=None)
def active(tree):
    return 1 + sum(active(t) for t in tree.children)


@lru_cache(maxsize=None)
def full(tree):
    return (1 + sum(full(t) for t in tree.children)
            + (full(tree.descriptor) if tree.descriptor is not None else 0))


@lru_cache(maxsize=None)
def occurrences(tree, variable):
    """Active occurrences only: a frozen descriptor is not traversed."""
    return (int(tree.kind == "variable" and tree.label == variable)
            + sum(occurrences(t, variable) for t in tree.children))


@lru_cache(maxsize=None)
def root_nf(tree):
    if (tree.kind == "application" and tree.label == "Q"
            and tree.descriptor == W and tree.children[0].label == "S"
            and tree.children[0].kind == "application"):
        return root_nf(tree.children[0].children[0])
    return tree


def substitute(tree, replacements):
    """Simultaneous active substitution; never rewrite stored descriptions."""
    if tree.kind == "variable":
        return replacements.get(tree.label, tree)
    return Tree(tree.kind, tree.label,
                tuple(substitute(t, replacements) for t in tree.children),
                tree.descriptor)


@lru_cache(maxsize=None)
def display(tree):
    if tree.kind == "variable":
        return tree.label
    if tree.kind == "application":
        if not tree.children:
            return tree.label
        return tree.label + "(" + ",".join(map(display, tree.children)) + ")"
    if tree.kind in ("forall", "exists"):
        return tree.kind + " " + tree.label + ".(" + display(tree.children[0]) + ")"
    if tree.kind == "false":
        return "false"
    return "(" + (" " + tree.kind + " ").join(map(display, tree.children)) + ")"


DESCRIPTORS = {}


@lru_cache(maxsize=None)
def recursor_symbol(body, normalize=True):
    body = root_nf(body) if normalize else body
    stored = substitute(body, {"n": V, "a": W})
    if stored == W:
        name = "Q"
    elif stored == ZERO:
        name = "Z"
    elif stored == V:
        name = "R_identity"
    else:
        # Nested names already identify earlier descriptors.  Check collisions.
        name = "R_" + hashlib.sha256(display(stored).encode()).hexdigest()[:16]
    if name in DESCRIPTORS:
        assert DESCRIPTORS[name] == stored
    DESCRIPTORS[name] = stored
    return name, stored


def rec(body, x, y, normalize=True):
    name, stored = recursor_symbol(body, normalize)
    return app(name, x, y, descriptor=stored)


def base(body, normalize=True):
    return eq(rec(body, ZERO, A, normalize), A)


def left_matrix(body, normalize=True):
    step = eq(rec(body, succ(N), A, normalize),
              substitute(body, {"n": rec(body, N, A, normalize), "a": N}))
    return conjunction(base(body, normalize), step)


def left(body):
    return close(left_matrix(body))


def right(body):
    step = eq(rec(body, succ(N), A),
              rec(body, N, substitute(body, {"n": A, "a": ZERO})))
    return close(conjunction(base(body), step))


def bound_state(body):
    step = forall(C, implies(eq(rec(body, N, A), C),
                  eq(rec(body, succ(N), A),
                     substitute(body, {"n": C, "a": N}))))
    return close(conjunction(base(body), step))


def boundary(body, shifted=False):
    first_index = succ(K) if shifted else K
    second_index = succ(first_index)
    return close(exists(K, conjunction(
        eq(rec(body, first_index, A), A),
        implies(eq(rec(body, second_index, A), A), eq(K, N)))))


def local_return(body):
    selector = q(z(chi(rec(body, succ(succ(B)), A), A), succ(B)), N)
    return close(exists(B, eq(rec(body, succ(selector), A), A)))


def rooted_return(body):
    progress = forall(B, implies(eq(rec(body, succ(B), A), A),
                               eq(rec(body, succ(succ(B)), A), A)))
    return close(implies(progress, eq(rec(body, succ(N), A), A)))


SEPARATION = negate(eq(ZERO, ONE))
BIT_MATRIX = conjunction(eq(chi(A, A), ONE),
                         disjunction(eq(A, N), eq(chi(A, N), ZERO)))
BIT_ONLY = close(BIT_MATRIX)
OLD_SEED = close(conjunction(SEPARATION, BIT_MATRIX))
COVERAGE = forall(N, disjunction(eq(N, ZERO), eq(N, succ(q(N, ZERO)))))
COVER_SEED = conjunction(SEPARATION, COVERAGE)
S_SEED = q(succ(N), A)
G_SEED = z(chi(N, ZERO), A)


def h_local(tail):
    return q(z(chi(A, ZERO), succ(tail)), N)


def h_outer(tail):
    return z(chi(N, ZERO), h_local(tail))


def h_rooted(tail):
    return z(z(chi(A, ZERO), chi(tail, ZERO)), N)


def is_local(tree):
    if tree.kind != "application" or tree.label != "Q":
        return False
    first, second = tree.children
    return (second == N and first.kind == "application" and first.label == "Z"
            and first.children[0] == chi(A, ZERO)
            and first.children[1].kind == "application"
            and first.children[1].label == "S")


def is_outer(tree):
    return (tree.kind == "application" and tree.label == "Z"
            and tree.children[0] == chi(N, ZERO) and is_local(tree.children[1]))


def is_rooted(tree):
    if tree.kind != "application" or tree.label != "Z":
        return False
    first, second = tree.children
    if second != N or first.kind != "application" or first.label != "Z":
        return False
    test = first.children[1]
    return (first.children[0] == chi(A, ZERO)
            and test.kind == "application" and test.label == "chi"
            and test.children[1] == ZERO)


def profile(body):
    return (active(body), full(body), full(root_nf(body)),
            occurrences(body, "n"), occurrences(body, "a"))


def autonomous(body):
    return occurrences(body, "n") > 0 and occurrences(body, "a") == 0


def computation(body):
    if autonomous(body):
        return "autonomous", right(body)
    if occurrences(body, "n") >= 4:
        return "bound_state", bound_state(body)
    return "ordinary", left(body)


def new_emitter(body):
    if body == S_SEED:
        return "bit_seed", BIT_ONLY
    if body == G_SEED:
        return "coverage_seed", COVER_SEED
    branch, formula = computation(body)
    if root_nf(body) == body and active(formula) >= 19:
        return "boundary", boundary(body)
    return branch, formula


def old_bw(body):
    if body == S_SEED:
        return OLD_SEED
    if autonomous(body):
        return right(body)
    if is_local(body):
        return boundary(body, shifted=True)
    return left(body)


def old_lr(body, optional=False):
    if body == S_SEED:
        return OLD_SEED
    if autonomous(body):
        return right(body)
    if is_local(body) or (optional and is_outer(body)):
        return local_return(body)
    return left(body)


def old_rr(body):
    if body == G_SEED:
        return OLD_SEED
    if autonomous(body):
        return right(body)
    if is_rooted(body):
        return rooted_return(body)
    return bound_state(body) if occurrences(body, "n") >= 4 else left(body)


def ao_template(body, orbit=False, seed_aware=False):
    """Matched k=0 complete templates; fixed AO basis is omitted favorably.

    AO has a different grammar, so these are structural-profile benchmarks,
    not literal same-language axiom comparisons.  Its recursor keeps the raw
    descriptor.  The primary autonomous template updates with immutable a.
    """
    matrix = left_matrix(body, normalize=False)
    if seed_aware:
        matrix = conjunction(base(body, normalize=False),
            eq(rec(body, succ(N), A, False),
               substitute(body, {"n": rec(body, N, A, False), "a": A})))
    if orbit or seed_aware:
        payload = negate(forall(J,
            eq(rec(body, J, A, False), succ(rec(body, succ(J), A, False)))))
    else:
        payload = negate(forall(J,
            eq(substitute(body, {"n": J}),
               succ(substitute(body, {"n": succ(J)})))))
    return close(conjunction(matrix, payload))


def all_old(body):
    m, _, _, i, _ = profile(body)
    term, orbit = ao_template(body), ao_template(body, orbit=True)
    return {
        "boundary_witness": old_bw(body),
        "local_return": old_lr(body),
        "local_return_optional": old_lr(body, optional=True),
        "rooted_return": old_rr(body),
        "ao_primary_matched": ao_template(body, seed_aware=True),
        "ao_active_optimizer": term if 2 * m + i <= 7 else orbit,
        "ao_full_optimizer": term if i <= 7 else orbit,
        "ao_joint_optimizer": term if i < 7 else orbit,
    }


def double_alias(body):
    return q(succ(q(succ(body), A)), A)


def exact_cost_checks(body):
    m, w, v, i, _ = profile(body)
    checks = [
        (left(body), 13 + m + 2 * i, 13 + w + 2 * i + (2 + i) * v),
        (right(body), 15 + m, 15 + w + 3 * v),
        (bound_state(body), 20 + m, 20 + w + 3 * v),
        (boundary(body), 19, 19 + 2 * v),
        (boundary(body, shifted=True), 21, 21 + 2 * v),
        (local_return(body), 20, 22 + 2 * v),
        (rooted_return(body), 24, 24 + 3 * v),
        (ao_template(body), 19 + 3 * m + 3 * i,
         19 + (5 + i) * w + 3 * i),
        (ao_template(body, orbit=True), 26 + m + 2 * i,
         26 + (5 + i) * w + 2 * i),
    ]
    for formula, expected_active, expected_full in checks:
        assert (active(formula), full(formula)) == (expected_active, expected_full)


def bounded_trees(max_size):
    by_size = {1: [ZERO, N, A]}
    binary = (chi, q, z)
    for size in range(2, max_size + 1):
        level = [succ(t) for t in by_size[size - 1]]
        for left_size in range(1, size - 1):
            right_size = size - 1 - left_size
            for x in by_size[left_size]:
                for y in by_size[right_size]:
                    level.extend(f(x, y) for f in binary)
        by_size[size] = level
    return by_size


def stress_family(k):
    """u_k=Z(n,Q(n,...Q(n,a)...)), with k inner Q applications."""
    tail = A
    for _ in range(k):
        tail = q(N, tail)
    return z(N, tail)


def sample_inputs(max_size):
    by_size = bounded_trees(max_size)
    seen = set()
    tagged = []

    def add(tag, term):
        if term not in seen:
            seen.add(term)
            tagged.append((tag, term))

    for size, level in by_size.items():
        for term in level:
            add("exhaustive_size_" + str(size), term)
    # These wrappers explicitly exercise all incumbent marked branches.
    for size in range(1, min(5, max_size) + 1):
        for term in by_size[size]:
            add("old_local_pattern", h_local(term))
            add("old_optional_pattern", h_outer(term))
            add("old_rooted_pattern", h_rooted(term))
            add("double_alias", double_alias(term))
    for k in range(0, 41):
        term = stress_family(k)
        add("linear_family", term)
        add("high_occurrence_alias", double_alias(term))
    for k in range(1, 16):
        term = N
        for _ in range(k):
            term = succ(term)
        add("autonomous_threshold", term)
    # Three finite acyclic stages, with deterministic random active arguments.
    rng = random.Random(20261102)
    pool = [ZERO, N, A, chi(N, A), h_local(N), h_rooted(A)]
    for stage in range(3):
        earlier = list(pool)
        new_terms = []
        for _ in range(100):
            descriptor = rng.choice(earlier)
            x, y = rng.choice(earlier), rng.choice(earlier)
            term = rec(descriptor, x, y)
            new_terms.append(term)
            add("nested_descriptor_stage_" + str(stage + 1), term)
            add("nested_alias_stage_" + str(stage + 1), double_alias(term))
        pool.extend(new_terms[:12])
    return tagged, {str(k): len(v) for k, v in by_size.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-size", type=int, default=7,
                        help="exhaustive base-alphabet active tree bound (default 7)")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    assert 1 <= args.max_size <= 8, "Supported built-in bounds are 1 through 8."
    args.output_dir.mkdir(parents=True, exist_ok=True)
    assert (active(BIT_ONLY), full(BIT_ONLY)) == (18, 18)
    assert (active(COVER_SEED), full(COVER_SEED)) == (18, 19)
    assert (active(OLD_SEED), full(OLD_SEED)) == (25, 25)
    samples, levels = sample_inputs(args.max_size)
    branches, classes = Counter(), Counter()
    strict_active = strict_full = strict_both = 0
    fields = ["id", "sample_class", "input", "m", "W", "V", "i", "j",
              "new_branch", "new_active", "new_full", "old_min_active", "old_min_full"]
    # Publish only a complete ledger.  Keeping the buffer private also makes
    # concurrent readers see the preceding complete run until this one ends.
    with io.StringIO(newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for number, (sample_class, body) in enumerate(samples):
            exact_cost_checks(body)
            nf = root_nf(body)
            assert root_nf(nf) == nf and full(nf) <= full(body)
            assert active(nf) <= active(body)
            alias = double_alias(body)
            alias_branch, _ = new_emitter(alias)
            assert alias_branch in ("ordinary", "bound_state")
            assert root_nf(alias) == nf
            assert recursor_symbol(alias) == recursor_symbol(body)
            branch, formula = new_emitter(body)
            old = all_old(body)
            old_a, old_f = min(map(active, old.values())), min(map(full, old.values()))
            new_a, new_f = active(formula), full(formula)
            assert new_a <= old_a and new_f <= old_f, (
                display(body), branch, new_a, new_f, old_a, old_f)
            # Verify frozen descriptor substitution independently on each input.
            probe = rec(body, N, A)
            substituted = substitute(probe, {"n": succ(N), "a": ZERO,
                                             "v": succ(V), "w": ZERO})
            assert substituted.descriptor == probe.descriptor
            assert occurrences(probe, "n") == 1 and occurrences(probe, "a") == 1
            assert occurrences(probe, "v") == 0 and occurrences(probe, "w") == 0
            branches[branch] += 1
            classes[sample_class] += 1
            strict_active += new_a < old_a
            strict_full += new_f < old_f
            strict_both += new_a < old_a and new_f < old_f
            m, w, v, i, j = profile(body)
            writer.writerow(dict(zip(fields, [number, sample_class, display(body),
                m, w, v, i, j, branch, new_a, new_f, old_a, old_f])))
        csv_payload = stream.getvalue()
        assert sum(1 for _ in csv.DictReader(io.StringIO(csv_payload))) == len(samples)
        ledger_tmp = args.output_dir / "all_counts.csv.tmp"
        ledger_tmp.write_text(csv_payload, newline="")
        ledger_tmp.replace(args.output_dir / "all_counts.csv")
    assert set(branches) == {"bit_seed", "coverage_seed", "boundary",
                             "autonomous", "bound_state", "ordinary"}
    examples = {
        "zero": ZERO, "counter": A, "identity": N,
        "bit_seed": S_SEED, "coverage_seed": G_SEED,
        "canonical_computation_tie": chi(N, A),
        "canonical_boundary_active_tie": succ(chi(N, A)),
        "first_autonomous_boundary": succ(succ(succ(N))),
        "old_local_H0": h_local(ZERO),
        "old_local_Hchi": h_local(chi(N, A)),
        "old_optional_H0": h_outer(ZERO),
        "old_rooted_K0": h_rooted(ZERO),
        "noncanonical_bound_state": double_alias(stress_family(3)),
        "family_k3": stress_family(3),
        "family_k20": stress_family(20),
    }
    example_rows = []
    example_formulas = {}
    for name, body in examples.items():
        branch, formula = new_emitter(body)
        old = all_old(body)
        example_rows.append({"name": name, "input": display(body), "branch": branch,
            "new_active": active(formula), "new_full": full(formula),
            "old_min_active": min(map(active, old.values())),
            "old_min_full": min(map(full, old.values()))})
        example_formulas[name] = {
            "input": display(body), "new_branch": branch, "new_formula": display(formula),
            "incumbents": {k: {"formula": display(f), "active": active(f), "full": full(f)}
                           for k, f in old.items()}}
    with (args.output_dir / "examples.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=example_rows[0].keys())
        writer.writeheader()
        writer.writerows(example_rows)
    (args.output_dir / "example_formulas.json").write_text(
        json.dumps(example_formulas, indent=2) + "\n")
    family_rows = []
    for k in range(3, 41):
        body = stress_family(k)
        assert profile(body) == (2 * k + 3, 3 * k + 4, 3 * k + 4, k + 1, 1)
        _, formula = new_emitter(body)
        old = all_old(body)
        actual = (active(formula), full(formula),
                  min(map(active, old.values())), min(map(full, old.values())))
        expected = (19, 6 * k + 27, 2 * k + 23, 12 * k + 36)
        assert actual == expected, (k, actual, expected)
        family_rows.append({"k": k, "new_active": actual[0], "new_full": actual[1],
                            "old_min_active": actual[2], "old_min_full": actual[3]})
    with (args.output_dir / "family.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=family_rows[0].keys())
        writer.writeheader()
        writer.writerows(family_rows)
    result = {
        "status": "PASS", "implementation": "Independent Python AST checker",
        "max_exhaustive_active_size": args.max_size, "exhaustive_levels": levels,
        "exhaustive_base_total": sum(levels.values()), "total_distinct_inputs": len(samples),
        "new_branches": dict(sorted(branches.items())),
        "sample_classes": dict(sorted(classes.items())),
        "strict_active_inputs": strict_active, "strict_full_inputs": strict_full,
        "strict_both_inputs": strict_both,
        "incumbents": list(all_old(ZERO)),
        "checks": ["actual AST sizes versus exact symbolic formulas",
                   "new sizes below every incumbent in both metrics",
                   "root normalization idempotent and full-size nonincreasing",
                   "double alias reaches computation and preserves selected descriptor",
                   "substitution and occurrence counts ignore frozen descriptors",
                   "all six new emitter branches exercised",
                   "infinite-family formulas checked for k=3,...,40"],
        "scope": "Finite executable audit; unbounded result requires report proof.",
        "ao_comparison": "Matched k=0 complete templates; separate fixed costs omitted.",
        "examples": example_rows,
    }
    (args.output_dir / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in (
        "status", "exhaustive_base_total", "total_distinct_inputs", "new_branches",
        "strict_active_inputs", "strict_full_inputs", "strict_both_inputs")}, indent=2))


if __name__ == "__main__":
    main()
