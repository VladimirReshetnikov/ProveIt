import Std

/-!
# Unshifted boundary witnesses and quantifier-free induction

This is an arbitrary-carrier proof kernel. The forward direction assumes
coverage explicitly, but assumes neither induction nor a natural-number
carrier. The reverse direction uses exactly one displayed quantifier-free
boundary-invariant induction instance and the computations of its selector.
The finite-description language compiler, pairing construction, complete
axiom emitter, and first-order bi-interpretation are outside this kernel.
-/

namespace BoundaryCoverage

universe u

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  Q : A → A → A
  Z : A → A → A
  chi : A → A → A
  separated : zero ≠ succ zero
  q_zero : ∀ a, Q zero a = a
  q_succ : ∀ n a, Q (succ n) a = n
  z_zero : ∀ a, Z zero a = a
  z_succ : ∀ n a, Z (succ n) a = zero
  chi_diag : ∀ a, chi a a = succ zero
  chi_off : ∀ a b, a = b ∨ chi a b = zero

namespace Kernel

variable {A : Type u} (K : Kernel A)

def pred (x : A) : A := K.Q x K.zero

theorem pred_succ (x : A) : K.pred (K.succ x) = x := K.q_succ x K.zero

theorem succ_ne_zero (x : A) : K.succ x ≠ K.zero := by
  intro hs
  have hx : x = K.zero := by
    have hp := congrArg (fun z => K.Q z K.zero) hs
    simpa only [K.q_succ, K.q_zero] using hp
  apply K.separated
  exact hs.symm.trans (congrArg K.succ hx)

theorem chi_of_ne (x y : A) (h : x ≠ y) : K.chi x y = K.zero := by
  rcases K.chi_off x y with he | hc
  · exact False.elim (h he)
  · exact hc

include K in
theorem eq_or_ne (x y : A) : x = y ∨ x ≠ y := by
  rcases K.chi_off x y with he | hc
  · exact Or.inl he
  · apply Or.inr
    intro he
    subst x
    apply K.separated
    exact hc.symm.trans (K.chi_diag y)

/-- The unshifted, target-dependent two-occurrence boundary schema. -/
def BoundaryWitness (F : A → A) (a : A) : Prop :=
  ∀ n, ∃ b, F b = a ∧ (F (K.succ b) = a → b = n)

theorem boundary_implies_all_returns (F : A → A) (a : A)
    (witness : K.BoundaryWitness F a)
    (progress : ∀ n, F n = a → F (K.succ n) = a) :
    ∀ n, F n = a := by
  intro n
  rcases witness n with ⟨b, hb, hnext⟩
  have hbn : b = n := hnext (progress b hb)
  simpa only [hbn] using hb

/-- A zero-absorbing latch using a true-means-nonzero truth term. -/
def latch (truth : A → A → A) (v w : A) : A :=
  K.Z (K.chi (truth w (K.pred v)) K.zero) v

theorem latch_reflection
    (P : A → A → Prop) (truth : A → A → A)
    (truth_correct : ∀ n a, truth n a ≠ K.zero ↔ P n a)
    (v w a : A) :
    K.latch truth v w = K.succ a ↔ v = K.succ a ∧ P w a := by
  constructor
  · intro hl
    rcases K.eq_or_ne (truth w (K.pred v)) K.zero with ht | ht
    · have hz : K.zero = K.succ a := by
        simpa only [latch, ht, K.chi_diag, K.z_succ] using hl
      exact False.elim (K.succ_ne_zero a hz.symm)
    · have hv : v = K.succ a := by
        simpa only [latch, K.chi_of_ne _ _ ht, K.z_zero] using hl
      have hp : P w (K.pred v) := (truth_correct w (K.pred v)).mp ht
      exact ⟨hv, by simpa only [hv, K.pred_succ] using hp⟩
  · rintro ⟨hv, hp⟩
    have ht : truth w a ≠ K.zero := (truth_correct w a).mpr hp
    simp only [latch, hv, K.pred_succ, K.chi_of_ne _ _ ht, K.z_zero]

/--
The principal forward theorem. Coverage is a fixed, explicitly displayed
arithmetic hypothesis. Only the boundary witness for this one later-stage
latch recursor is needed; there is no use of induction in this proof.
-/
theorem induction_from_unshifted_boundary
    (coverage : ∀ n, n = K.zero ∨ n = K.succ (K.pred n))
    (P : A → A → Prop) (truth : A → A → A)
    (truth_correct : ∀ n a, truth n a ≠ K.zero ↔ P n a)
    (R : A → A → A)
    (rstep : ∀ n a, R (K.succ n) a = K.latch truth (R n a) n)
    (witness : ∀ a, K.BoundaryWitness (fun n => R n a) a)
    (a : A) (hbase : P K.zero a)
    (hprogress : ∀ n, P n a → P (K.succ n) a) :
    ∀ n, P n a := by
  have reflect : ∀ n, R n (K.succ a) = K.succ a → P n a := by
    intro n hn
    rcases coverage n with hz | hs
    · simpa only [hz] using hbase
    · have hr : K.latch truth (R (K.pred n) (K.succ a)) (K.pred n) =
          K.succ a := by
        rw [← rstep]
        simpa only [← hs] using hn
      have hp := ((K.latch_reflection P truth truth_correct
        (R (K.pred n) (K.succ a)) (K.pred n) a).mp hr).2
      have hps := hprogress (K.pred n) hp
      simpa only [← hs] using hps
  have stable : ∀ n, R n (K.succ a) = K.succ a →
      R (K.succ n) (K.succ a) = K.succ a := by
    intro n hn
    rw [rstep]
    exact (K.latch_reflection P truth truth_correct
      (R n (K.succ a)) n a).mpr ⟨hn, reflect n hn⟩
  have allReturns := K.boundary_implies_all_returns
    (fun n => R n (K.succ a)) (K.succ a) (witness (K.succ a)) stable
  exact fun n => reflect n (allReturns n)

/-- Arithmetic selector: choose n when x=a, otherwise choose b. -/
def choose (x a n b : A) : A :=
  K.Q (K.Z (K.chi x a) (K.succ b)) n

theorem choose_of_eq (x a n b : A) (he : x = a) :
    K.choose x a n b = n := by
  subst x
  simp only [choose, K.chi_diag, K.z_succ, K.q_zero]

theorem choose_of_ne (x a n b : A) (he : x ≠ a) :
    K.choose x a n b = b := by
  simp only [choose, K.chi_of_ne _ _ he, K.z_zero, K.q_succ]

/-- This displayed formula is quantifier-free in its arithmetic arguments. -/
def BoundaryInvariant (F : A → A) (a : A) (c : A → A) (n : A) : Prop :=
  F (c n) = a ∧ (F (K.succ (c n)) = a → c n = n)

theorem boundary_invariant_base
    (F : A → A) (a : A) (c : A → A)
    (fzero : F K.zero = a) (czero : c K.zero = K.zero) :
    K.BoundaryInvariant F a c K.zero := by
  constructor
  · simpa only [czero] using fzero
  · intro _
    exact czero

theorem boundary_invariant_step
    (F : A → A) (a : A) (c : A → A)
    (cstep : ∀ n, c (K.succ n) =
      K.choose (F (K.succ (c n))) a (K.succ n) (c n))
    (n : A) (hi : K.BoundaryInvariant F a c n) :
    K.BoundaryInvariant F a c (K.succ n) := by
  rcases K.eq_or_ne (F (K.succ (c n))) a with hn | hn
  · have hc : c (K.succ n) = K.succ n := by
      rw [cstep, K.choose_of_eq _ _ _ _ hn]
    have hcn : c n = n := hi.2 hn
    constructor
    · simpa only [hc, hcn] using hn
    · intro _
      exact hc
  · have hc : c (K.succ n) = c n := by
      rw [cstep, K.choose_of_ne _ _ _ _ hn]
    constructor
    · simpa only [hc] using hi.1
    · intro he
      have hbad : F (K.succ (c n)) = a := by
        simpa only [hc] using he
      exact False.elim (hn hbad)

/--
The constructive reverse theorem. The provided induction premise is exactly
the one quantifier-free invariant used by the primitive-recursive search c.
No choice, classical logic, least-number principle, or hidden induction is
used elsewhere. Applying this with F(n)=R_h(n,a) proves each boundary axiom
in PRA, since F(0)=a is its ordinary computation equation.
-/
theorem boundary_from_invariant_induction
    (F : A → A) (a : A) (c : A → A)
    (fzero : F K.zero = a) (czero : c K.zero = K.zero)
    (cstep : ∀ n, c (K.succ n) =
      K.choose (F (K.succ (c n))) a (K.succ n) (c n))
    (induction : K.BoundaryInvariant F a c K.zero →
      (∀ n, K.BoundaryInvariant F a c n →
        K.BoundaryInvariant F a c (K.succ n)) →
      ∀ n, K.BoundaryInvariant F a c n) :
    K.BoundaryWitness F a := by
  have hi := induction (K.boundary_invariant_base F a c fzero czero)
    (K.boundary_invariant_step F a c cstep)
  intro n
  exact ⟨c n, hi n⟩

end Kernel
end BoundaryCoverage

#print axioms BoundaryCoverage.Kernel.succ_ne_zero
#print axioms BoundaryCoverage.Kernel.eq_or_ne
#print axioms BoundaryCoverage.Kernel.latch_reflection
#print axioms BoundaryCoverage.Kernel.boundary_implies_all_returns
#print axioms BoundaryCoverage.Kernel.induction_from_unshifted_boundary
#print axioms BoundaryCoverage.Kernel.boundary_invariant_base
#print axioms BoundaryCoverage.Kernel.boundary_invariant_step
#print axioms BoundaryCoverage.Kernel.boundary_from_invariant_induction
