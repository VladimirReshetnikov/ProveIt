"""Replay all supplied measurements and independent implementation checks offline."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf', action='store_true', help='also rebuild the PDF')
    args = parser.parse_args()
    for relative in ['measure.py', 'comparison/expanded_measure.py', 'validation/run.py']:
        subprocess.run([sys.executable, str(ROOT / relative)], cwd=ROOT, check=True)
    if args.pdf:
        subprocess.run([sys.executable, str(ROOT / 'build.py')], cwd=ROOT, check=True)
    print('All requested reproduction steps completed successfully.')


if __name__ == '__main__':
    main()
