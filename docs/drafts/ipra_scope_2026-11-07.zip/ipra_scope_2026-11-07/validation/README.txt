VALIDATION OF THE SCOPE PRESENTATION

Run from any working directory:
    python3 /path/to/package/validation/run.py

All defaults are local to this package. No network, baseline checkout, or
third-party Python package is required. The script checks the frozen support
SHA-256 values in reference/provenance.json before importing either reference
acceptance program. Missing or changed support makes the run fail; importing
replacement support requires the explicit --export-reference option.

THE COUNTED WORK

* 66 distinct inherited certificate documents are transcoded from tagged
  syntax into the arity syntax. They are checked by the new demand and strict
  kernels, the corresponding frozen tagged kernels, and a separately written
  named-syntax rule interpreter. Accepted verdicts, final fresh-name supplies,
  and unconsumed proof-cell counts agree.
* Of these 66 documents, 45 have empty assumption contexts and are public
  theorem inputs; 21 are explicitly labeled internal open-sequent tests.
  Some of the 45 theorems have free numerical parameters. Do not confuse
  "empty assumption context" with "numerically closed root formula".
* The 66 documents are the union of 286 source paths (143 paths per witness
  policy). Identical source copies are counted once. Source aliases and
  canonical document hashes are preserved in reference/source_corpus.json.
* 384 distinct opening inputs cover both sorts, 0/1/2 distinguished holes,
  nested recursors, nested logical binders, and noncanonical existential
  annotations. Both policies are compared with ordinary substitution on a
  separately decoded named-binder syntax, and their resulting parameter
  supplies and local closedness are checked.
* 53 scope/shape certificate cases include 48 inherited attacks and five new
  arity/induction boundaries. There are two executions per case, one for each
  witness policy. They include true/false integer confusion, malformed terms,
  illegal positive-index capture, fresh-name collisions, the unavailable
  compound induction hypothesis, and malformed or unused existential fields.
* Five deliberate invalid variants are positive controls held only in memory.
  Four controls expose capture or freshness failures that approve false
  formulas. The fifth adds a prohibited compound IH and accepts a certificate
  which uses that IH; its conclusion happens to be true, but the certificate
  is outside the specified rule basis. No invalid variant is exported as a
  checker or used to approve a theorem.
* 114 public process executions test actual ACCEPT/REJECT behavior, including
  Python optimization mode for the selected boundary cases.

THE OPTIONAL CLOSED-SENTENCE CHECKER

The script also tests ../checker_closed.py. Its root formula must have no
free numerical parameters, including in existential annotations. All 45
inherited public theorem inputs are classified: 10 have numerically closed
roots, and nine of those certificates pass unchanged. The remaining one
uses an auxiliary parameter -6 before allocation; the theorem has the
simple zero-witness certificate exhibited by the focused tests.

Ten additional cases and ten public process runs check root parameters,
parameters in otherwise unused existential annotations, forward references,
inert unused witnesses, inert unread prefixes, reuse of an already allocated
parameter in a later sibling, loss of discharged assumptions, and parameter
reservations made during a failed speculative major premise. Every accepted
closed-checker execution agrees with the open demand checker and the named
oracle. Six direct leaf-boundary checks supplement these cases.

FILES

run.py                  untrusted validation driver and named-syntax oracle
reference/              byte-identical tagged kernels and inherited inputs
artifacts/theorems/     45 public arity-format theorem documents
artifacts/open_sequents/21 internal-interface fixtures, with explicit contexts
artifacts/audit_cases.json
artifacts/validation_results.json
                        detailed reproducible outcomes and kernel hashes
artifacts/cli_audits/   selected public boundary inputs
artifacts/closed_cli_audits/
                        optional closed-interface boundary inputs

The generated output can be redirected with --output. The accepted theorem
interface remains the standalone checker file plus Python json/sys. No
validation code is part of that acceptance boundary.

These are finite implementation checks. They do not constitute a formal
proof of general soundness, completeness, or bi-interpretability; the article
provides those mathematical arguments.

SOURCE ATTRIBUTION

The inherited inputs and tagged kernels are from:
https://github.com/VladimirReshetnikov/ProveIt
commit c5f42a50d9213259760ee385977481c04dccab28
docs/drafts/ipra_fresh_parameters_2026-11-06.zip

The upstream MIT No Attribution license is preserved in
reference/LICENSE_SOURCE.txt. Detailed provenance is in
reference/provenance.json. The new arity encoding, named-syntax oracle,
focused boundary cases, and execution driver are supplied with this package.
