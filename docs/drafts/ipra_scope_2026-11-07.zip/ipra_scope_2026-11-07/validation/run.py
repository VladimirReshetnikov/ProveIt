"""Independent validation of the locally nameless arity iPRA checkers.

This file is untrusted support, never imported by an acceptance kernel.
It uses a named-binder oracle with explicit syntax cases, compares accepted
proofs with the frozen tagged fresh-parameter kernels, and checks deliberate
capture/freshness failures with positive-control mutants held only in memory.

The inherited certificate corpus is attributed to
ProveIt c5f42a50d9213259760ee385977481c04dccab28,
docs/drafts/ipra_fresh_parameters_2026-11-06.zip.
Copies are deduplicated before counting. General metatheorems are not
machine-formalized by these finite implementation checks.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import random
import subprocess
import sys
import types

HERE = Path(__file__).resolve().parent
SNAPSHOT = 'c5f42a50d9213259760ee385977481c04dccab28'
ARCHIVE = 'ipra_fresh_parameters_2026-11-06'
sys.dont_write_bytecode = True
SEED = 202611071


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def from_source(source, name):
    module = types.ModuleType(name)
    exec(compile(source, name, 'exec'), module.__dict__)
    return module


def encode_tagged(a):
    """Syntax-only transcoding; canonical existential annotations are 0=0.

    Malformed tagged constructors are left malformed. This is not a proof
    checker and does not make any acceptance decision.
    """
    if type(a) is not list:
        return a
    if a and type(a[0]) is str:
        tag = a[0]
        if tag == '=' and len(a) == 3:
            return [encode_tagged(a[1]), encode_tagged(a[2])]
        if tag in ('s', 'u', 'q') and len(a) == 2:
            return [encode_tagged(a[1])]
        if tag == 'r' and len(a) == 4:
            return [encode_tagged(x) for x in a[1:]]
        if tag == 'ex' and len(a) == 2:
            return [encode_tagged(a[1]), [0, 0], [0, 0]]
    return [encode_tagged(x) for x in a]


class NamedSyntax:
    """Explicit named binding, independent of the packed-depth algorithm."""
    def __init__(self):
        self.serial = 0

    def fresh(self):
        self.serial += 1
        return ('binder', self.serial)

    def term(self, a, bound=(), holes=0):
        if type(a) is int:
            if a <= 0:
                return ('constant', a)
            if a <= len(bound):
                return ('variable', bound[a - 1])
            slot = a - len(bound) - 1
            if slot < holes:
                return ('hole', slot)
            raise ValueError('unbound positive term coordinate')
        if type(a) is not list:
            raise ValueError('term is neither an integer nor a constructor')
        if len(a) == 1:
            return ('successor', self.term(a[0], bound, holes))
        if len(a) == 3:
            u, v = self.fresh(), self.fresh()
            return ('recursor', self.term(a[0], bound, holes),
                    self.term(a[1], bound, holes), u, v,
                    self.term(a[2], (u, v) + bound, holes))
        raise ValueError('wrong numerical constructor arity')

    def formula(self, a, bound=(), holes=0):
        if type(a) is not list:
            raise ValueError('formula is not an array')
        if len(a) == 2:
            return ('equal', self.term(a[0], bound, holes),
                    self.term(a[1], bound, holes))
        if len(a) == 1:
            x = self.fresh()
            return ('closure', x, self.formula(a[0], (x,) + bound, holes))
        if len(a) == 3:
            x = self.fresh()
            return ('exists', x, *(self.formula(b, (x,) + bound, holes) for b in a))
        raise ValueError('wrong formula constructor arity')

    def term_data(self, t, bound=()):
        tag = t[0]
        if tag == 'constant':
            return t[1]
        if tag == 'variable':
            return bound.index(t[1]) + 1
        if tag == 'successor':
            return [self.term_data(t[1], bound)]
        if tag == 'recursor':
            _, n, a, u, v, h = t
            return [self.term_data(n, bound), self.term_data(a, bound),
                    self.term_data(h, (u, v) + bound)]
        raise ValueError('unsubstituted hole in result')

    def formula_data(self, a, bound=()):
        tag = a[0]
        if tag == 'equal':
            return [self.term_data(a[1], bound), self.term_data(a[2], bound)]
        if tag == 'closure':
            return [self.formula_data(a[2], (a[1],) + bound)]
        if tag == 'exists':
            return [self.formula_data(b, (a[1],) + bound) for b in a[2:]]
        raise ValueError('unknown named formula')


def children(a):
    tag = a[0]
    if tag in ('constant', 'variable', 'hole'):
        return ()
    if tag == 'successor':
        return (a[1],)
    if tag == 'recursor':
        return (a[1], a[2], a[5])
    if tag == 'equal':
        return a[1:]
    if tag in ('closure', 'exists'):
        return a[2:]
    raise ValueError('unknown named syntax')


def used_holes(a):
    if a[0] == 'hole':
        return {a[1]}
    return set().union(*(used_holes(c) for c in children(a)))


def negative_names(a):
    if a[0] == 'constant' and a[1] < 0:
        return {a[1]}
    return set().union(*(negative_names(c) for c in children(a)))


def substitute_names(a, replacements):
    """Ordinary structural replacement of uniquely named free holes."""
    tag = a[0]
    if tag == 'hole':
        return replacements[a[1]]
    if tag in ('constant', 'variable'):
        return a
    if tag == 'successor':
        return (tag, substitute_names(a[1], replacements))
    if tag == 'recursor':
        return (tag, substitute_names(a[1], replacements),
                substitute_names(a[2], replacements), a[3], a[4],
                substitute_names(a[5], replacements))
    if tag == 'equal':
        return (tag, *(substitute_names(c, replacements) for c in a[1:]))
    if tag in ('closure', 'exists'):
        return (tag, a[1], *(substitute_names(c, replacements) for c in a[2:]))
    raise ValueError('unknown named syntax')


class NamedOracle:
    """A separate rule interpreter using named substitution, not packed depth."""
    def __init__(self, policy):
        self.policy = policy
        self.k = 0
        self.stack = []
        self.allocations = []

    def opening(self, a, images=(), formula=True):
        syntax = NamedSyntax()
        tree = (syntax.formula if formula else syntax.term)(a, holes=len(images))
        self.k = min(self.k, *negative_names(tree)) if negative_names(tree) else self.k
        selected = range(len(images)) if self.policy == 'strict' else sorted(used_holes(tree))
        replacements = {}
        for i in selected:
            replacements[i] = syntax.term(images[i])
            names = negative_names(replacements[i])
            if names:
                self.k = min(self.k, *names)
        result = substitute_names(tree, replacements)
        return (syntax.formula_data if formula else syntax.term_data)(result)

    def allocate(self, relevant):
        names = set()
        for a in relevant:
            # A matrix can have one distinguished hole, but that is not a name.
            names |= negative_names(NamedSyntax().formula(a, holes=1))
        old = self.k
        self.k -= 1
        require(self.k not in names, ('oracle eigenparameter collision', self.k, names))
        require(all(self.k < n for n in names), ('oracle did not register all names', self.k, names))
        self.allocations.append({'previous_supply': old, 'allocated': self.k,
                                 'relevant_names': sorted(names)})
        return self.k

    def check(self, a, g):
        self.opening(a)
        instruction = self.stack.pop()
        if type(instruction) is list and len(instruction) == 2:
            major, annotation = instruction
            if self.check(major, g):
                if len(major) == 3:
                    eigen = self.allocate([a, *g, major])
                    assumption = self.opening(major[0], [eigen])
                    return self.check(a, [*g, assumption])
                if len(major) == 1:
                    motive, images = major[0], (0, annotation)
                else:
                    motive, images = annotation, major
                base, result = (self.opening(motive, [v]) for v in images)
                return result == a and self.check(base, g)
            return a in g
        if len(a) == 1 and instruction == []:
            body = a[0]
            base = self.opening(body, [0])
            local = [base]
            if len(body) == 2:
                local.append(body)
            eigen = self.allocate([a, *g])
            goal = self.opening(body, [[eigen]])
            assumptions = [self.opening(b, [eigen]) for b in local]
            return self.check(goal, [*g, *assumptions])
        if len(a) == 3 and type(instruction) is list and len(instruction) == 1:
            return self.check(self.opening(a[0], [instruction[0]]), g)
        if (len(a) == 2 and type(a[0]) is list and len(a[0]) == 3
                and instruction == []):
            n, initial, update = a[0]
            expected = initial
            if n != 0:
                if type(n) is not list or len(n) != 1:
                    raise ValueError('recursor computation counter is not zero or successor')
                n = n[0]
                expected = self.opening(update, [[n, initial, update], n], formula=False)
            return a[1] == expected
        return a in g

    def verdict(self, data):
        self.k = 0
        self.allocations = []
        a, p, *g = deepcopy(data)
        self.stack = p
        try:
            for h in g:
                self.opening(h)
            result = bool(self.check(a, g))
            return result, self.k, len(self.stack)
        except Exception as exc:
            if isinstance(exc, AssertionError):
                raise
            return False, self.k, len(self.stack)


def verdict(module, data, fused):
    module.k = 0
    a, p, *g = deepcopy(data)
    try:
        if fused:
            for h in g:
                module.inst(h)
            module.take = p.pop
            result = bool(module.check(a, g))
        else:
            for h in g:
                module.inst(h)
            result = bool(module.check(a, p, g))
        return result, module.k, len(p)
    except Exception:
        return False, module.k, len(p)


def export_reference(reference, destination):
    """Materialize only the small inherited inputs actually used in this audit."""
    destination.mkdir(parents=True, exist_ok=True)
    for policy, filename in [('strict', 'checker.py'), ('demand', 'checker_demand.py')]:
        (destination / ('reference_' + policy + '.py')).write_bytes((reference / filename).read_bytes())
    corpus = {}
    source_count = 0
    for policy in ('strict', 'demand'):
        for path in sorted((reference / 'examples' / policy).rglob('*.json')):
            data = json.loads(path.read_bytes())
            key = digest(canonical(data).encode())
            corpus.setdefault(key, {'sha256_canonical': key, 'certificate': data,
                                    'source_aliases': []})['source_aliases'].append(str(path.relative_to(reference)))
            source_count += 1
    rows = sorted(corpus.values(), key=lambda r: r['sha256_canonical'])
    require(len(rows) == 66, ('unexpected unique inherited corpus', len(rows)))
    source_cases = json.loads((reference / 'validation' / 'audit_cases.json').read_text())
    write_json(destination / 'source_corpus.json', rows)
    write_json(destination / 'source_audit_cases.json', source_cases)
    write_json(destination / 'provenance.json', {
        'repository': 'https://github.com/VladimirReshetnikov/ProveIt',
        'commit': SNAPSHOT,
        'archive_path': 'docs/drafts/' + ARCHIVE + '.zip',
        'source_paths_count': source_count,
        'unique_certificates': len(rows),
        'empty_context_theorems': sum(len(r['certificate']) == 2 for r in rows),
        'open_sequents': sum(len(r['certificate']) > 2 for r in rows),
        'reference_files': {name: digest((destination / name).read_bytes()) for name in
                            ('reference_strict.py', 'reference_demand.py',
                             'source_corpus.json', 'source_audit_cases.json')},
        'note': 'Inputs inherited from the current draft; source copies are deduplicated before counting.'})


def verify_support(support):
    """Check all frozen input hashes before importing any reference kernel."""
    manifest_path = support / 'provenance.json'
    if not manifest_path.is_file():
        raise FileNotFoundError('Missing frozen validation/reference support. '
                                'Restore the packaged files or use --export-reference explicitly.')
    manifest = json.loads(manifest_path.read_text())
    require(manifest['commit'] == SNAPSHOT, 'reference snapshot changed')
    require(manifest['archive_path'] == 'docs/drafts/' + ARCHIVE + '.zip',
            'reference archive changed')
    expected_names = {'reference_strict.py', 'reference_demand.py',
                      'source_corpus.json', 'source_audit_cases.json'}
    require(set(manifest['reference_files']) == expected_names, 'reference manifest file set changed')
    for name, expected_digest in manifest['reference_files'].items():
        path = support / name
        require(path.is_file() and digest(path.read_bytes()) == expected_digest,
                ('frozen reference hash mismatch', name))


def test_corpus(kernels, references, support, out):
    corpus = json.loads((support / 'source_corpus.json').read_text())
    reports = []
    public = []
    for index, row in enumerate(corpus):
        tagged = row['certificate']
        encoded = encode_tagged(tagged)
        require(digest(canonical(tagged).encode()) == row['sha256_canonical'], 'corpus hash mismatch')
        states = {}
        for policy in ('strict', 'demand'):
            original = verdict(references[policy], tagged, fused=False)
            fused = verdict(kernels[policy], encoded, fused=True)
            named = NamedOracle(policy)
            independent = named.verdict(encoded)
            require(original[0], ('inherited certificate rejected by reference', index, policy))
            require(fused == original == independent,
                    ('positive proof differential', index, policy, original, fused, independent))
            states[policy] = {'accepted': fused[0], 'final_supply': fused[1],
                              'unread_cells': fused[2], 'fresh_allocations': len(named.allocations)}
        label = min(row['source_aliases'], key=lambda x: (len(x), x))
        filename = f'{index:03d}_' + Path(label).name
        goal, stack, *context = encoded
        if context:
            path = out / 'open_sequents' / filename
            write_json(path, {'goal': goal, 'stack': stack, 'validated_external_context': context,
                              'scope': 'Internal interface test; this is not a theorem certificate.'})
        else:
            path = out / 'theorems' / filename
            write_json(path, [*stack, goal])
            public.append((filename, path))
        reports.append({'id': index, 'source_aliases': row['source_aliases'],
                        'source_sha256_canonical': row['sha256_canonical'],
                        'external_assumptions': len(context),
                        'fused_sha256_canonical': digest(canonical(encoded).encode()),
                        'states': states})
    return reports, public


def random_openings(kernels):
    rng = random.Random(SEED)

    def term(size, depth=0, holes=0):
        if not size or rng.randrange(3) == 0:
            return rng.choice([0, -1, -7, -1001, *range(1, depth + holes + 1)])
        if rng.randrange(2):
            return [term(size - 1, depth, holes)]
        return [term(size - 1, depth, holes), term(size - 1, depth, holes),
                term(size - 1, depth + 2, holes)]

    def formula(size, depth=0, holes=0):
        if not size or rng.randrange(3) == 0:
            return [term(2, depth, holes), term(2, depth, holes)]
        if rng.randrange(2):
            return [formula(size - 1, depth + 1, holes)]
        return [formula(size - 1, depth + 1, holes),
                formula(max(0, size - 2), depth + 1, holes),
                formula(max(0, size - 2), depth + 1, holes)]

    counts = {p: {'comparisons': 0, 'closed_output_checks': 0, 'supply_checks': 0}
              for p in kernels}
    identities = set()
    for holes in (0, 1, 2):
        for is_formula in (False, True):
            samples = {}
            while len(samples) < 64:
                images = [term(3) for _ in range(holes)]
                a = (formula if is_formula else term)(4, holes=holes)
                key = canonical([a, images, is_formula])
                samples[key] = (a, images)
            for key, (a, images) in samples.items():
                identities.add(key)
                initial = rng.choice([0, -3, -2000])
                for policy, module in kernels.items():
                    named = NamedOracle(policy)
                    named.k = initial
                    expected = named.opening(a, images, formula=is_formula)
                    module.k = initial
                    supplied = images
                    if policy == 'strict':
                        supplied = [module.inst(image, d=1) for image in images]
                    actual = module.inst(a, supplied, d=0 if is_formula else 1)
                    require(actual == expected, ('named opening mismatch', policy, a, images, actual, expected))
                    require(module.k == named.k, ('opening name supply mismatch', policy, a, images))
                    before = module.k
                    require(module.inst(actual, d=0 if is_formula else 1) == actual,
                            ('opened output not locally closed', policy))
                    require(module.k == before, ('closed-output validation changed registered supply', policy))
                    counts[policy]['comparisons'] += 1
                    counts[policy]['closed_output_checks'] += 1
                    counts[policy]['supply_checks'] += 1
    return {'seed': SEED, 'distinct_input_triples': len(identities), 'per_policy': counts}


def test_opening_boundaries(kernels):
    invalid_terms = [True, False, None, 1, 2, 1.0, '0', {}, [], [0, 0],
                     [0, 0, 3], [True], [0, 0, [0, 0, 5]], [0, 0, 0, 0]]
    valid_terms = [0, -1, -1000000, [0], [0, 0, 1], [0, 0, 2],
                   [0, 0, [0, 0, 3]], [0, 0, [0, 0, 4]]]
    invalid_formulas = [[], 0, True, [0], [0, 1], [[2, 2]],
                        [[0, 0], [0, 0], [2, 2]], [[0, 0], [0, 0], True],
                        [0, 0, 0, 0]]
    used_matrices = [[1, 0], [[[3, 1], [0, 0], [0, 0]]],
                     [[2, 1]], [[0, 0, 3], 0],
                     [[0, 0], [2, 0], [0, 0]],
                     [[0, 0], [0, 0], [2, 0]]]
    bad_images = [None, True, False, 1, [1], [0, 0, 3]]
    unused_matrices = [[0, 0], [[1, 1]], [[1, 1], [0, 0], [0, 0]]]
    counts = {p: {'invalid_terms_rejected': 0, 'valid_terms_accepted': 0,
                  'invalid_formulas_rejected': 0, 'used_bad_images_rejected': 0,
                  'unused_bad_images_rejected': 0, 'unused_bad_images_ignored': 0}
              for p in kernels}

    def opening(module, policy, a, images, formula=True):
        if policy == 'strict':
            images = [module.inst(image, d=1) for image in images]
        return module.inst(a, images, d=0 if formula else 1)

    def must_reject(call, detail):
        try:
            call()
        except Exception:
            return
        raise AssertionError(detail)

    for policy, module in kernels.items():
        for bad in invalid_terms:
            module.k = 0
            must_reject(lambda: module.inst(bad, d=1), ('invalid term accepted', policy, bad))
            counts[policy]['invalid_terms_rejected'] += 1
        for good in valid_terms:
            module.k = 0
            require(module.inst(good, d=1) == good, ('valid term rejected', policy, good))
            counts[policy]['valid_terms_accepted'] += 1
        for bad in invalid_formulas:
            module.k = 0
            must_reject(lambda: module.inst(bad), ('invalid formula accepted', policy, bad))
            counts[policy]['invalid_formulas_rejected'] += 1
        for body in used_matrices:
            for bad in bad_images:
                module.k = 0
                must_reject(lambda: opening(module, policy, body, [bad]),
                            ('used malformed image accepted or captured', policy, body, bad))
                counts[policy]['used_bad_images_rejected'] += 1
        for body in unused_matrices:
            for bad in bad_images:
                module.k = 0
                if policy == 'strict':
                    must_reject(lambda: opening(module, policy, body, [bad]),
                                ('strict unused malformed witness accepted', body, bad))
                    counts[policy]['unused_bad_images_rejected'] += 1
                else:
                    require(opening(module, policy, body, [bad]) == body,
                            ('demand unused image changed body', body, bad))
                    require(module.k == 0, 'unused image changed fresh-name supply')
                    counts[policy]['unused_bad_images_ignored'] += 1
    return counts


def new_audit_cases():
    # Intentionally use a compound induction hypothesis in a redundant
    # existential elimination. The conclusion is true, but this derivation is
    # invalid unless the prohibited compound IH is admitted.
    y = -1
    body = [[2, 2], [0, 0], [0, 0]]
    goal = [body]
    major = [[y, y], [0, 0], [0, 0]]
    t = [y]
    axiom = [[0, t, 0], t]
    reflexivity = [[], [], [axiom, [1, t]]]
    step = reflexivity + [[0], None, [major, None]]
    illegal_compound = step + [[]]
    return [
        {'name': 'compound_induction_hypothesis_is_unavailable',
         'goal': goal, 'proof': illegal_compound,
         'expected_strict': False, 'expected_demand': False},
        {'name': 'malformed_first_existential_annotation',
         'goal': [[0, 0], True, [0, 0]], 'proof': [[], [], [[[0, 0, 0], 0], [1, 0]], [0]],
         'expected_strict': False, 'expected_demand': False},
        {'name': 'malformed_second_existential_annotation',
         'goal': [[0, 0], [0, 0], [2, 2]], 'proof': [[], [], [[[0, 0, 0], 0], [1, 0]], [0]],
         'expected_strict': False, 'expected_demand': False},
        {'name': 'valid_noncanonical_existential_annotations',
         'goal': [[0, 0], [[2, 2]], [[1, 1], [0, 0], [0, 0]]],
         'proof': [[], [], [[[0, 0, 0], 0], [1, 0]], [0]],
         'expected_strict': True, 'expected_demand': True},
        {'name': 'unused_existential_annotations_do_not_become_assumptions',
         'goal': [0, [0]],
         'proof': [None, [], [], [[[0, 0, 0], 0], [1, 0]], [0],
                   [[[0, 0], [0, [0]], [0, [0]]], None]],
         'expected_strict': False, 'expected_demand': False},
    ]


def test_audits(kernels, references, support, sources, out):
    inherited = json.loads((support / 'source_audit_cases.json').read_text())
    cases = []
    rows = []
    for source in inherited:
        case = {**source, 'goal': encode_tagged(source['goal']),
                'proof': encode_tagged(source['proof']), 'origin': 'inherited tagged audit'}
        cases.append(case)
        for policy in ('strict', 'demand'):
            original = verdict(references[policy], [source['goal'], source['proof']], fused=False)
            fused = verdict(kernels[policy], [case['goal'], case['proof']], fused=True)
            independent = NamedOracle(policy).verdict([case['goal'], case['proof']])
            expected = source['expected_' + policy]
            require(original[0] == fused[0] == independent[0] == expected,
                    ('inherited audit mismatch', source['name'], policy, original, fused, independent))
            if expected:
                require(original == fused == independent,
                        ('accepted audit state mismatch', source['name'], policy, original, fused, independent))
            rows.append({'name': source['name'], 'policy': policy, 'accepted': fused[0],
                         'expected': expected, 'final_supply': fused[1]})
    for case in new_audit_cases():
        cases.append({**case, 'origin': 'new arity boundary'})
        for policy in ('strict', 'demand'):
            fused = verdict(kernels[policy], [case['goal'], case['proof']], fused=True)
            independent = NamedOracle(policy).verdict([case['goal'], case['proof']])
            expected = case['expected_' + policy]
            require(fused[0] == independent[0] == expected,
                    ('new audit mismatch', case['name'], policy, fused, independent))
            rows.append({'name': case['name'], 'policy': policy, 'accepted': fused[0],
                         'expected': expected, 'final_supply': fused[1]})

    def mutate_once(source, old, new):
        require(source.count(old) == 1, ('mutant target changed', old))
        return source.replace(old, new, 1)

    mutants = {
        'registration_deleted': mutate_once(sources['strict'], '        k = min(k, a)\n', ''),
        'strict_Q_witness_validation_deleted': mutate_once(sources['strict'], '[0, inst(t, d=1)]', '[0, t]'),
        'compound_IH_added': mutate_once(sources['strict'], '[:2 - len(b) % 2]', ''),
        'demand_image_validation_deleted': mutate_once(sources['demand'],
            'else inst(env[a - d // 2 - 1], d=1)', 'else env[a - d // 2 - 1]'),
    }
    specs = [
        ('registration_deleted', 'freshness_collision_with_goal_parameter'),
        ('registration_deleted', 'freshness_collision_with_major_only_parameter'),
        ('strict_Q_witness_validation_deleted', 'capture_by_illegal_positive_witness'),
        ('demand_image_validation_deleted', 'capture_by_illegal_positive_witness'),
        ('compound_IH_added', 'compound_induction_hypothesis_is_unavailable'),
    ]
    by_name = {c['name']: c for c in cases}
    controls = []
    for mutant, case_name in specs:
        module = from_source(mutants[mutant], 'deliberate_invalid_' + mutant)
        case = by_name[case_name]
        accepted = verdict(module, [case['goal'], case['proof']], fused=True)[0]
        require(accepted, ('positive-control mutant did not accept attack', mutant, case_name))
        controls.append({'deliberate_invalid_mutant': mutant, 'case': case_name,
                         'mutant_accepted': True, 'real_checkers_rejected': True})
    write_json(out / 'audit_cases.json', cases)
    return {'unique_cases': len(cases), 'inherited_cases': len(inherited),
            'new_cases': len(cases) - len(inherited), 'executions': len(rows),
            'outcomes': rows, 'positive_controls': controls}, cases


def test_cli(programs, public, cases, out):
    selected = {'reflexivity_0', 'capture_by_illegal_positive_witness',
                'freshness_collision_with_goal_parameter',
                'unused_bad_witness_False', 'compound_induction_hypothesis_is_unavailable',
                'valid_noncanonical_existential_annotations'}
    jobs = []
    for policy, program in programs.items():
        for name, path in public:
            jobs.append((policy, program, path, True, False, 'theorem/' + name))
        for case in cases:
            if case['name'] not in selected:
                continue
            path = out / 'cli_audits' / (case['name'] + '.json')
            write_json(path, [*case['proof'], case['goal']])
            for optimized in (False, True):
                jobs.append((policy, program, path, case['expected_' + policy],
                             optimized, 'audit/' + case['name']))

    def run(job):
        policy, program, path, expected, optimized, label = job
        result = subprocess.run([sys.executable, *(['-O'] if optimized else []),
                                 str(program), str(path)], text=True, capture_output=True, timeout=20)
        require(result.returncode == (0 if expected else 1)
                and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT'),
                ('CLI mismatch', policy, label, optimized, expected,
                 result.returncode, result.stdout, result.stderr))
        return {'policy': policy, 'case': label, 'optimized': optimized,
                'accepted': expected, 'exit_code': result.returncode}

    with ThreadPoolExecutor(max_workers=6) as pool:
        rows = list(pool.map(run, jobs))
    return {'process_executions': len(rows),
            'unique_theorem_inputs': len(public),
            'optimized_process_executions': sum(r['optimized'] for r in rows),
            'all_expected_outcomes_matched': True, 'outcomes': rows}


def test_closed(path, opened, support, out, skip_cli):
    """Focused trace inclusion and declared-name contract checks."""
    closed = load(path, 'optional_closed_checker')
    corpus = json.loads((support / 'source_corpus.json').read_text())
    inherited = []
    for index, row in enumerate(corpus):
        data = encode_tagged(row['certificate'])
        if len(data) != 2:
            continue
        names = negative_names(NamedSyntax().formula(data[0]))
        bounded = verdict(closed, data, fused=True)
        open_result = verdict(opened, data, fused=True)
        if names:
            require(not bounded[0] and bounded[1] == 0,
                    ('optional closed checker admitted an open root', index, bounded))
        if bounded[0]:
            named = NamedOracle('demand').verdict(data)
            require(bounded == open_result == named,
                    ('closed-to-open trace inclusion failed', index, bounded, open_result, named))
        inherited.append({'source_id': index, 'root_has_no_numerical_parameters': not names,
                          'accepted_by_closed': bounded[0], 'final_supply': bounded[1]})

    def refl(t):
        ax = [[0, t, 0], t]
        return [[], [], [ax, [1, t]]]

    def exists_equal(t, right=None):
        # E z(z=z), or E z(z=0) with zero witness.
        matrix = [1, 1] if right is None else [1, right]
        require(right is None or (t == 0 and right == 0), 'unsupported test constructor')
        return [matrix, [0, 0], [0, 0]], refl(t) + [[t]]

    def scoped_reflexivity(witness, right=None):
        major, proof = exists_equal(witness, right)
        return refl(0) + proof + [[major, None]]

    # The first premise allocates -1 and discharges its local assumption.
    # A later premise may use -1 as a free number, but not that assumption.
    earlier_scope = scoped_reflexivity(0)
    later_scope = scoped_reflexivity(-1)
    sibling_reuse = later_scope + earlier_scope + [[[0, 0], [0, 0]]]
    sibling_future = scoped_reflexivity(-2) + earlier_scope + [[[0, 0], [0, 0]]]
    leaking_goal = [[1, 0], [0, 0], [0, 0]]
    leaked_assumption = [None, [-1]] + scoped_reflexivity(0, 0) + [[[0, 0], leaking_goal]]
    spec_major = [[1, 0]]
    speculative = [None, [], [spec_major, 0], []]
    cases = [
        ('closed_reflexivity', [0, 0], refl(0), True),
        ('root_free_parameter', [-1, -1], refl(-1), False),
        ('root_free_parameter_in_ghost', [[0, 0], [-1, -1], [0, 0]], refl(0) + [[0]], False),
        ('forward_parameter_in_used_witness', [[1, 1], [0, 0], [0, 0]], refl(-1) + [[-1]], False),
        ('unused_future_witness_is_inert', [[0, 0], [0, 0], [0, 0]], refl(0) + [[-999]], True),
        ('unused_prefix_is_inert', [0, 0], [-999] + refl(0), True),
        ('declared_name_reused_in_later_sibling', [0, 0], sibling_reuse, True),
        ('future_name_used_in_later_sibling', [0, 0], sibling_future, False),
        ('discharged_assumption_cannot_escape_to_sibling', leaking_goal, leaked_assumption, False),
        ('failed_major_reserves_names_without_exporting_assumptions', [[0, 0]], speculative, True),
    ]
    records = []
    cli = []
    for name, goal, stack, expected in cases:
        data = [goal, stack]
        bounded = verdict(closed, data, fused=True)
        open_result = verdict(opened, data, fused=True)
        named = NamedOracle('demand').verdict(data)
        require(bounded[0] == expected, ('closed checker boundary mismatch', name, bounded, expected))
        require(open_result == named, ('closed audit open/oracle mismatch', name, open_result, named))
        if expected:
            require(bounded == open_result, ('closed accepted trace mismatch', name, bounded, open_result))
        records.append({'name': name, 'expected_closed': expected, 'closed': bounded,
                        'open': open_result, 'named': named})
        input_path = out / 'closed_cli_audits' / (name + '.json')
        write_json(input_path, [*stack, goal])
        if not skip_cli:
            result = subprocess.run([sys.executable, str(path.resolve()), str(input_path)],
                                    text=True, capture_output=True, timeout=15)
            require(result.returncode == (0 if expected else 1)
                    and result.stdout.strip() == ('ACCEPT' if expected else 'REJECT'),
                    ('closed CLI mismatch', name, result.stdout, result.stderr))
            cli.append({'name': name, 'exit_code': result.returncode, 'accepted': expected})
    for value, expected in [(-1, True), (-2, True), (-3, False), (True, False),
                            ([0, 0, 2], True), ([0, 0, 3], False)]:
        closed.k = -2
        try:
            actual = closed.inst(value, d=1) == value
        except Exception:
            actual = False
        require(actual == expected, ('declared-name leaf boundary', value, actual, expected))
    return {'kernel_sha256': digest(path.read_bytes()),
            'inherited_empty_context_inputs': len(inherited),
            'inherited_numerically_closed_roots': sum(r['root_has_no_numerical_parameters'] for r in inherited),
            'inherited_accepted': sum(r['accepted_by_closed'] for r in inherited),
            'inherited': inherited, 'focused_cases': records,
            'declared_name_leaf_checks': 6, 'public_cli_executions': len(cli),
            'public_cli': cli,
            'scope': 'A narrower root interface: only numerically closed formulas; arbitrary free-parameter roots are intentionally rejected.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--strict', type=Path, default=HERE.parent / 'checker_strict.py')
    parser.add_argument('--demand', type=Path, default=HERE.parent / 'checker.py')
    parser.add_argument('--export-reference', type=Path, default=None,
                        help='Explicitly import the pinned extracted source draft into --support.')
    parser.add_argument('--closed', type=Path, default=HERE.parent / 'checker_closed.py')
    parser.add_argument('--support', type=Path, default=HERE / 'reference')
    parser.add_argument('--output', type=Path, default=HERE / 'artifacts')
    parser.add_argument('--skip-cli', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.export_reference is not None:
        export_reference(args.export_reference, args.support)
    verify_support(args.support)
    programs = {'strict': args.strict.resolve(), 'demand': args.demand.resolve()}
    sources = {p: f.read_text() for p, f in programs.items()}
    kernels = {p: load(f, 'fused_' + p) for p, f in programs.items()}
    references = {p: load(args.support / ('reference_' + p + '.py'), 'reference_' + p)
                  for p in programs}
    corpus, public = test_corpus(kernels, references, args.support, args.output)
    openings = random_openings(kernels)
    boundaries = test_opening_boundaries(kernels)
    audits, cases = test_audits(kernels, references, args.support, sources, args.output)
    cli = {} if args.skip_cli else test_cli(programs, public, cases, args.output)
    closed = test_closed(args.closed, kernels['demand'], args.support, args.output, args.skip_cli) if args.closed else {}
    result = {
        'status': 'all expected outcomes matched', 'python': platform.python_version(),
        'snapshot': SNAPSHOT,
        'kernel_sha256': {p: digest(f.read_bytes()) for p, f in programs.items()},
        'unique_inherited_certificates': len(corpus), 'empty_context_theorems': len(public),
        'open_sequents': len(corpus) - len(public), 'corpus': corpus,
        'named_opening_comparison': openings, 'opening_boundaries': boundaries,
        'scope_and_shape_audits': audits, 'public_cli': cli,
        'optional_closed_checker': closed,
        'scope': 'Finite independent implementation validation; not a formal proof of general soundness or bi-interpretability.'}
    write_json(args.output / 'validation_results.json', result)
    print(json.dumps({k: result[k] for k in ('status', 'python', 'unique_inherited_certificates',
                                            'empty_context_theorems', 'open_sequents')}, indent=2))
    print(json.dumps({'named_openings': openings['distinct_input_triples'],
                      'audit_cases': audits['unique_cases'],
                      'mutant_controls': len(audits['positive_controls']),
                      'cli_executions': cli.get('process_executions', 0),
                      'closed_cli_executions': closed.get('public_cli_executions', 0)}, indent=2))


if __name__ == '__main__':
    main()
