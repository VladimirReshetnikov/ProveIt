"""Create a clean ZIP and SHA-256 manifest of the deliverable."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'build', '__pycache__'}


def members():
    return sorted(path for path in ROOT.rglob('*') if path.is_file()
                  and not any(part in EXCLUDED for part in path.relative_to(ROOT).parts)
                  and path.name != 'MANIFEST.sha256'
                  and path.suffix not in {'.pyc', '.zip'})


def main():
    files = members()
    manifest = ROOT / 'MANIFEST.sha256'
    manifest.write_text(''.join(
        hashlib.sha256(path.read_bytes()).hexdigest() + '  ' +
        path.relative_to(ROOT).as_posix() + '\n' for path in files))
    destination = ROOT.parent / (ROOT.name + '.zip')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in [*files, manifest]:
            info = zipfile.ZipInfo((Path(ROOT.name) / path.relative_to(ROOT)).as_posix(),
                                   date_time=(2026, 11, 7, 12, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes())
    print(destination.name, destination.stat().st_size, 'bytes;', len(files) + 1, 'members')


if __name__ == '__main__':
    main()
