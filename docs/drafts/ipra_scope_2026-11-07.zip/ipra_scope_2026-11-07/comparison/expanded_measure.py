"""Reproduce the expanded 120-path / 39-distinct-program lower envelope.

This measures complete standalone acceptance programs. The retained nine
current top-level checkers are the primary same-interface comparison; this
larger inventory checks that embedded ablations and references do not hide
a lower frontier. No compared source is executed or modified.
"""
import ast
from copy import deepcopy
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parents[1]
INVENTORY = ROOT / 'comparison' / 'expanded' / 'inventory.json'
IGNORE = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
          tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
KEYS = ('ast_nodes', 'normalized_tokens', 'normalized_bytes')


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and type(node.body[0].value.value) is str):
            node.body = node.body[1:]
        return node
    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def counts(tree):
    text = ast.unparse(tree) + '\n'
    return {'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_tokens': sum(t.type not in IGNORE for t in
                tokenize.generate_tokens(io.StringIO(text).readline)),
            'normalized_bytes': len(text.encode('utf-8'))}


def measure(path):
    raw = path.read_bytes()
    tree = StripDocstrings().visit(ast.parse(raw))
    core = deepcopy(tree)
    core.body = [n for n in core.body if not isinstance(n, (ast.Import, ast.ImportFrom))
                 and not (isinstance(n, ast.If) and '__name__' in ast.unparse(n.test))]
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'raw_bytes': len(raw),
            **counts(tree), 'core': counts(core)}


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def main():
    manifest = json.loads(INVENTORY.read_text())
    rows = []
    for entry in manifest['sources']:
        path = ROOT / entry['source_file']
        row = measure(path)
        require(row['sha256'] == entry['sha256'], ('source changed', entry['source_file']))
        require(all(row[k] == entry[k] for k in KEYS) and row['core'] == entry['core'],
                ('measurement differs from CPython 3.12.14 inventory', entry['source_file']))
        rows.append({**entry, **row})
    unique = {row['sha256'] for row in rows}
    require(len(unique) == manifest['distinct_sources'] == 39, 'wrong distinct-source inventory')
    require(len(manifest['inventory']) == manifest['source_paths'] == 120, 'wrong source-path inventory')
    require(all(entry['source_sha256'] in unique for entry in manifest['inventory']),
            'inventory has an unmapped source hash')
    whole = {key: min(row[key] for row in rows) for key in KEYS}
    core = {key: min(row['core'][key] for row in rows) for key in KEYS}
    require(whole == manifest['minima'] and core == manifest['core_minima'], 'envelope changed')
    candidates = {}
    for name, scope in [('checker.py', 'arbitrary free-parameter roots; demand witnesses'),
                        ('checker_strict.py', 'arbitrary free-parameter roots; strict witnesses'),
                        ('checker_closed.py', 'optional narrower numerically closed-root interface')]:
        result = measure(ROOT / name)
        result['scope'] = scope
        result['strictly_below_expanded_envelope'] = all(result[k] < whole[k] for k in KEYS)
        result['core_strictly_below_expanded_envelope'] = all(result['core'][k] < core[k] for k in KEYS)
        candidates[name] = result
    require(all(candidates[name]['strictly_below_expanded_envelope']
                and candidates[name]['core_strictly_below_expanded_envelope']
                for name in ('checker.py', 'checker_strict.py')),
            'same-interface primary programs no longer beat the envelope')
    result = {'python': platform.python_version(), 'commit': manifest['commit'],
              'source_paths': 120, 'distinct_sources': 39,
              'whole_envelope': whole, 'core_envelope': core,
              'candidates': candidates, 'sources': rows,
              'scope': 'Finite complete-program comparison, not a universal lower-bound theorem.'}
    output = ROOT / 'results' / 'expanded_comparison.json'
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'sources'}, indent=2))


if __name__ == '__main__':
    main()
