EXPANDED COMPLETE-PROGRAM INVENTORY

This directory preserves every standalone acceptance-program source found
by scanning all six pinned archives for Python files with a top-level check
function and both ACCEPT and REJECT string literals. All selected programs
import only Python json and sys, so no uncounted local source dependency is
needed for their acceptance computation.

There are 120 archived paths and 39 distinct byte strings. inventory.json
maps every original archive member to its SHA-256-named byte-identical source
copy in sources/. It also preserves the six source ZIP hashes and the pinned
GitHub commit. Sources are measured, never executed by the comparison script.

Run from any directory:
    python3 /path/to/package/comparison/expanded_measure.py

The script verifies every source hash, reproduces the whole-program and
core metrics, checks the inventory-to-source mappings, and writes
results/expanded_comparison.json. Normalization strips docstrings, uses
ast.unparse plus a final newline, and excludes tokenize's symbolic formatting
and comment token types. CPython 3.12.14 produced the stored measurements.

The full lower envelope is:
    491 AST nodes, 483 normalized tokens, 1462 normalized UTF-8 bytes.
The core envelope, removing imports and the main CLI conditional, is:
    425 AST nodes, 423 normalized tokens, 1200 normalized UTF-8 bytes.

These are the same envelopes as the nine current top-level programs. Thus
embedded ablations and differently named reference checkers do not reveal
a smaller supplied comparator. This finite source comparison is not a
universal minimality or lower-bound theorem over all possible theories.

The candidate programs checker.py and checker_strict.py beat all three
coordinates, both whole-program and core, while retaining arbitrary free
numerical parameters at the root. checker_closed.py is also measured but is
explicitly labeled as a narrower numerically closed-root interface.

Source repository:
https://github.com/VladimirReshetnikov/ProveIt
commit c5f42a50d9213259760ee385977481c04dccab28

The common upstream MIT No Attribution license is preserved verbatim in
LICENSE_SOURCE.txt. The source copies are unmodified.
