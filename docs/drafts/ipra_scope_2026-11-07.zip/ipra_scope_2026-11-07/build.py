"""Build the PDF from the complete supplied LaTeX sources."""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'build'


def main():
    if shutil.which('pdflatex') is None:
        raise SystemExit('Install pdfLaTeX and the ordinary packages listed in report.tex.')
    if not (ROOT / 'results/numbers.tex').exists():
        subprocess.run([sys.executable, str(ROOT / 'measure.py')], cwd=ROOT, check=True)
    BUILD.mkdir(exist_ok=True)
    for run in range(3):
        result = subprocess.run(
            ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
             '-output-directory', str(BUILD), 'report.tex'],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (BUILD / f'pass_{run + 1}.txt').write_text(result.stdout)
        if result.returncode:
            print(result.stdout[-12000:])
            raise SystemExit(result.returncode)
    shutil.copyfile(BUILD / 'report.pdf', ROOT / 'report.pdf')
    print('Built report.pdf')


if __name__ == '__main__':
    main()
