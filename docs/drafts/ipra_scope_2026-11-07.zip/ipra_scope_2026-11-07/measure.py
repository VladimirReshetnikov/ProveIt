"""Measure the complete current corpus and regenerate the report's exact tables."""
import csv
import json
from pathlib import Path
import platform

from comparison.expanded_measure import KEYS, measure, require

ROOT = Path(__file__).resolve().parent
LABELS = {
    'ipra_arity_2026-11-06.zip': 'arity',
    'ipra_direct_stream_2026-11-06.zip': 'direct stream',
    'ipra_fixed_slot_2026-11-06.zip': 'fixed slot',
    'ipra_fixed_variable_2026-11-06.zip': 'fixed variable',
    'ipra_fresh_parameters_2026-11-06.zip': 'fresh parameters',
    'ipra_variable_specialization_2026-11-06.zip': 'variable specialization',
}


def texnum(value):
    return f'{value:,}'.replace(',', '{,}')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['files']:
        row = measure(ROOT / entry['path'])
        require(row['sha256'] == entry['sha256'], ('changed comparison source', entry['path']))
        rows.append({**entry, **row})
    require(len(rows) == 9, 'expected nine current top-level programs')
    minima = {key: min(row[key] for row in rows) for key in KEYS}
    core_minima = {key: min(row['core'][key] for row in rows) for key in KEYS}
    proposals = {
        name: measure(ROOT / filename)
        for name, filename in [('main', 'checker.py'),
                               ('strict', 'checker_strict.py'),
                               ('closed', 'checker_closed.py')]
    }
    for name, row in proposals.items():
        row['whole_dominates_envelope'] = all(row[key] < minima[key] for key in KEYS)
        row['core_dominates_envelope'] = all(row['core'][key] < core_minima[key] for key in KEYS)
        require(row['whole_dominates_envelope'] and row['core_dominates_envelope'],
                ('strict reduction lost', name))
        row['percentage_reduction'] = {
            key: 100 * (minima[key] - row[key]) / minima[key] for key in KEYS}
    result = {
        'python': platform.python_version(), 'commit': manifest['commit'],
        'normalization': 'Remove genuine docstrings; ast.unparse plus newline; symbolic tokenize exclusions.',
        'rows': rows, 'minima': minima, 'core_minima': core_minima,
        'proposals': proposals,
        'closed_scope': 'The closed companion has a narrower root interface; the two primary programs do not.',
    }
    out = ROOT / 'results'
    out.mkdir(exist_ok=True)
    (out / 'metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    with (out / 'comparison.csv').open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['program', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'sha256'])
        for row in rows:
            writer.writerow([row['member'], row['normalized_tokens'],
                             row['ast_nodes'], row['normalized_bytes'], row['sha256']])
        for name, row in proposals.items():
            writer.writerow([name, row['normalized_tokens'],
                             row['ast_nodes'], row['normalized_bytes'], row['sha256']])
    macros = []
    for prefix, whole, core in [('Base', minima, core_minima)] + [
            (prefix, proposals[name], proposals[name]['core'])
            for prefix, name in [('New', 'main'), ('Strict', 'strict'), ('Closed', 'closed')]]:
        for suffix, key in [('Tokens', 'normalized_tokens'), ('AST', 'ast_nodes'),
                            ('Bytes', 'normalized_bytes')]:
            macros.append('\\newcommand{\\' + prefix + suffix + '}{' + texnum(whole[key]) + '}')
            macros.append('\\newcommand{\\' + prefix + 'Core' + suffix + '}{' + texnum(core[key]) + '}')
    (out / 'numbers.tex').write_text('\n'.join(macros) + '\n')
    table = [
        r'\begin{tabular}{@{}llrrr@{}}',
        r'\toprule',
        r'Presentation & Variant & Tokens & AST nodes & Bytes \\',
        r'\midrule',
    ]
    for row in rows:
        variant = 'demand' if 'demand' in row['member'] else 'strict'
        if 'fixed_' in row['archive'] or 'specialization' in row['archive']:
            variant = 'fixed variable'
        table.append(' & '.join([LABELS[row['archive']], variant,
                                *(texnum(row[k]) for k in
                                  ['normalized_tokens', 'ast_nodes', 'normalized_bytes'])]) + r' \\')
    table.extend([
        r'\midrule',
        r'\multicolumn{2}{l}{Current coordinatewise minima} & ' +
        ' & '.join(texnum(minima[k]) for k in
                   ['normalized_tokens', 'ast_nodes', 'normalized_bytes']) + r' \\',
        r'\midrule',
    ])
    for label, name in [('Proposed main', 'main'), ('Strict companion', 'strict'),
                        ('Closed-sentence companion', 'closed')]:
        row = proposals[name]
        table.append(r'\multicolumn{2}{l}{' + label + '} & ' +
                     ' & '.join(texnum(row[k]) for k in
                                ['normalized_tokens', 'ast_nodes', 'normalized_bytes']) + r' \\')
    table.extend([r'\bottomrule', r'\end{tabular}'])
    (out / 'comparison_table.tex').write_text('\n'.join(table) + '\n')
    print(json.dumps({'python': result['python'], 'current_envelope': minima,
                      'core_envelope': core_minima, 'proposals': proposals}, indent=2))


if __name__ == '__main__':
    main()
