A SMALLER COMPLETE PRESENTATION OF INTUITIONISTIC PRA
===================================================
Prepared for Vladimir Reshetnikov, 7 November 2026 (Pacific date).

RESULT
------
The primary complete proof checker is strictly smaller than the
coordinatewise lower envelope of all nine current top-level checkers in
the six ProveIt draft archives at commit:

    c5f42a50d9213259760ee385977481c04dccab28

Complete-program normalized measures, under CPython 3.12.14:

                           Tokens    AST nodes    UTF-8 bytes
  Current lower envelope      483          491          1462
  Main checker                461          478          1374
  Strict companion            468          483          1385
  Closed-sentence companion   457          473          1352

The main and strict programs retain arbitrary free numerical parameters
in the root formula. The optional closed-sentence program has a narrower
root interface, stated explicitly; the primary improvement does not rely
on that restriction. All three also beat the uniformly measured core
envelope. An expanded comparison of 120 supplied source paths / 39
distinct complete programs has exactly the same old envelope.

This is a strict improvement against a pinned finite corpus, not a proof
of a globally shortest axiomatization.

MATHEMATICS
-----------
The complete native basis has numerical zero, successor, initialized
primitive recursion, equality, unary closure Q, and existence.
Q_x B means B(0) -> forall x B(x).

There are six inference patterns (hypothesis, Q introduction/elimination,
existential introduction/elimination, and equality transport) and two
recursion computation schemas. Q introduction retains its zero base and
supplies an induction hypothesis only for a literal equation.

The paper derives full intuitionistic first-order logic and all
quantifier-free induction. Its ordinary staged-recursion realization is
bi-interpretable with iPRA on the whole numerical domain. Both internally
proved composite isomorphisms are x=y. The separate ordinary falsity
bridge and numerical coverage are stated explicitly.

The arithmetic basis is inherited and credited to the supplied drafts.
The implementation reduction synthesizes locally closed substitution
images, arity syntax, one scope/sort coordinate, and a single proof stream.
The closed-sentence variant adds declaration before use for parameters.

The general soundness, completeness, and bi-interpretation arguments are
mathematical proofs in the paper. This is not a Lean/Rocq formalization.
Finite executable checks are supporting evidence, not replacements for
those proofs. The combinator section evaluates legitimate alternatives
and proves the universal-evaluator obstruction; it does not claim to have
found a superior SK-based kernel.

START HERE
----------
  report.pdf                      Full compiled paper
  report.tex, sections/*.tex       Complete LaTeX sources
  checker.py                      Main standalone checker
  checker_strict.py               Strict witness-validation companion
  checker_closed.py               Optional closed-sentence checker
  FORMAT.txt                      Full syntax, rules, and certificate contract

RUN
---
From this directory:

    python3 checker.py examples/reflexivity_zero.json
    python3 checker_closed.py examples/exists_reflexivity_closed.json
    python3 checker.py validation/artifacts/theorems/011_successor_plus_theorem.json
    python3 reproduce.py
    python3 build.py

The first three print ACCEPT. The kernels need Python 3.10 or newer and
only the standard library. Reproduce exact normalized counts with
CPython 3.12.14. Reproduction requires no network.

build.py needs a normal pdfLaTeX installation and the ordinary packages
listed in report.tex. reproduce.py --pdf runs the checks and rebuilds the PDF.

PUBLIC THEOREMS AND TEST SEQUENTS
--------------------------------
validation/artifacts/theorems/ contains 45 distinct public inputs, all
with empty assumption contexts. Some formulas have free numerical
parameters; empty assumption context does not mean numerically closed.

validation/artifacts/open_sequents/ contains 21 additional internal
tests with explicitly validated assumptions. These are not public theorem
certificates. The public wrapper always starts with an empty context.

Ten inherited public goals are numerically closed. Nine old certificates
pass the optional checker unchanged. The remaining old proof uses
auxiliary witness -6 before allocation; the zero-witness certificate in
examples/exists_reflexivity_closed.json proves the same closed goal.
The completeness theorem permits this necessary proof transformation.

VALIDATION
----------
The two open-goal policies pass 66 unique inherited certificates,
384 distinct named-binder opening inputs per policy, 53 focused
scope/shape cases per policy, and 114 actual command-line executions.
Five deliberate invalid-variant controls exercise capture, freshness,
and the equation-only induction boundary. The optional closed program
adds ten focused cases, six direct syntax boundaries, and ten CLI runs.
See validation/README.txt and validation/artifacts/validation_results.json
for exact counts, overlaps, source provenance, and expected rejections.

REPRODUCIBILITY AND SOURCE ATTRIBUTION
------------------------------------
  comparison/manifest.json         Nine current sources, archive identities, hashes
  comparison/sources/              Unchanged current kernels
  comparison/expanded/             All 39 sources and their 120 member mappings
  comparison/expanded_measure.py   Independent expanded-envelope measurement
  measure.py                      Current comparison and report-table generation
  results/                        Exact metrics, CSV tables, expanded comparison
  validation/run.py               Independent named-syntax and CLI verification
  validation/reference/           Hash-verified frozen source corpus and kernels
  reproduce.py                    One-command offline reproduction
  build.py                        LaTeX compilation
  package.py                      Clean ZIP and manifest generation
  MANIFEST.sha256                  Delivered file hashes
  LICENSE_SOURCE.txt              Preserved upstream MIT No Attribution license

The acceptance programs import no comparison, generator, oracle, or
validation code. The full measured boundary includes JSON input and
verdict handling, not just an isolated logical core.

To verify the delivered files before rebuilding:

    sha256sum -c MANIFEST.sha256

After deliberate edits, package.py regenerates the manifest and ZIP.
