#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
latexmk -pdf -interaction=nonstopmode -halt-on-error pra_positive_constancy.tex
(
  cd alternative
  latexmk -pdf -interaction=nonstopmode -halt-on-error pra_fixed_updates.tex
)

