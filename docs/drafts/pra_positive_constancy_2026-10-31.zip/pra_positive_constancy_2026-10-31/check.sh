#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
"${PRA_LEAN_BIN:-lean}" formal/PositiveConstancy.lean > formal/PositiveConstancy.log
"${PRA_LEAN_BIN:-lean}" formal/FourUpdates.lean > formal/FourUpdates.log
python3 artifacts/schema_metrics.py > artifacts/schema_metrics.json
printf '%s\n' 'Both finite-syntax proof certificates and formula counts passed.'

