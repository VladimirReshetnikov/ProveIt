#!/usr/bin/env python3
"""Exact syntax counts, not numerical evidence for the mathematical theorems."""
import json
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class Node:
    op: str
    args: tuple = ()

def N(op, *args): return Node(op, args)
def var(name): return N("var:" + name)
def app(name, *args): return N("app:" + name, *args)
def eq(x,y): return N("eq",x,y)
def imp(x,y): return N("implies",x,y)
def conj(x,y): return N("and",x,y)
def disj(x,y): return N("or",x,y)
def allv(name,body): return N("forall:"+name,body)
def neg(body): return imp(body,N("false"))
def iff(x,y,expanded=True):
    return conj(imp(x,y),imp(y,x)) if expanded else N("iff",x,y)
def size(t): return 1+sum(size(a) for a in t.args)
def atoms(t): return (t.op=="eq")+sum(atoms(a) for a in t.args)
def metric(t): return {"nodes":size(t),"equality_occurrences":atoms(t)}
zero=N("zero")
S=lambda x:app("S",x)
one=S(zero)
n,a,x,y=map(var,("n","a","x","y"))
p=lambda x:app("I_counter",x,zero)
B=lambda x,y:app("I_zero",x,y)
A=lambda x,y:app("I_successor",x,y)
M=lambda x,y:app("I_predecessor",x,y)
f=lambda x:app("f",x,a)
delta=lambda x,y:A(M(x,y),M(y,x))

def pc():
    return allv("a",imp(
        allv("n",eq(f(S(S(n))),f(S(n)))),
        allv("n",disj(eq(n,zero),eq(f(n),f(one))))))
def pu(update):
    return allv("a",imp(
        allv("n",eq(f(S(S(n))),update(n,f(S(n))))),
        conj(neg(eq(zero,one)),
             allv("n",disj(eq(n,zero),
                eq(f(n),app("I_h",p(n),f(one))))))))
def er(expanded):
    return allv("x",allv("y",
        iff(eq(x,y),neg(eq(B(delta(x,y),one),zero)),expanded)))
def maxlaw():
    return allv("x",allv("y",eq(A(x,M(x,y)),A(y,M(y,x)))))

rows={
    "previous_generic_PU":metric(pu(lambda k,v:app("h",k,v))),
    "positive_constancy_PC":metric(pc()),
    "fixed_ER_biconditional_expanded":metric(er(True)),
    "fixed_ER_biconditional_primitive":metric(er(False)),
    "fixed_PU_successor":metric(pu(lambda k,v:S(v))),
    "fixed_PU_predecessor":metric(pu(lambda k,v:p(v))),
    "fixed_PU_identity":metric(pu(lambda k,v:v)),
    "fixed_PU_maximum":metric(pu(lambda k,v:A(v,B(M(k,v),one)))),
    "fixed_Max_equation":metric(maxlaw()),
}
expected={
    "previous_generic_PU":39, "positive_constancy_PC":26,
    "fixed_ER_biconditional_expanded":39,
    "fixed_ER_biconditional_primitive":20,
    "fixed_PU_successor":38,"fixed_PU_predecessor":39,
    "fixed_PU_identity":37,"fixed_PU_maximum":47,
    "fixed_Max_equation":13,
}
assert {k:v["nodes"] for k,v in rows.items()}==expected
assert rows["positive_constancy_PC"]["equality_occurrences"]==3
assert rows["previous_generic_PU"]["equality_occurrences"]==4
result={
    "convention":{
        "node":"Each variable, zero, function application, equality, logical connective, falsehood, and individual quantifier counts one.",
        "one":"S(0), expanded.",
        "predecessor":"I_counter(x,0), expanded.",
        "negation":"Implication to falsehood, expanded.",
        "biconditional":"Both expanded and primitive versions shown.",
        "function_indices":"A declared descriptor-indexed symbol counts as one function symbol. Its stored description is not a term argument.",
        "schematic_terms":"Displayed arguments count, arbitrarily substituted bodies do not.",
        "caution":"The fixed ER sentence is extra cost. PC alone is not claimed to axiomatize PRA.",
    },
    "results":rows,
    "totals":{
        "PC_plus_ER_expanded":size(pc())+size(er(True)),
        "PC_plus_ER_primitive_iff":size(pc())+size(er(False)),
        "three_fixed_PU_plus_Max":sum(rows[k]["nodes"] for k in [
            "fixed_PU_successor","fixed_PU_predecessor","fixed_PU_identity","fixed_Max_equation"]),
        "four_fixed_PU":sum(rows[k]["nodes"] for k in [
            "fixed_PU_successor","fixed_PU_predecessor","fixed_PU_identity","fixed_PU_maximum"])
    },
}
print(json.dumps(result,indent=2))

