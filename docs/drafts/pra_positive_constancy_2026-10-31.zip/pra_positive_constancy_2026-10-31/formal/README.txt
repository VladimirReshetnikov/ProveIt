FINITE-SYNTAX CERTIFICATES -- EXACT SCOPE
=======================================

1. PositiveConstancy.lean

Lean 4.19.0; no imports or external dependencies.
Namespace: PositiveConstancy.
Actual finite Term and Formula syntax; arbitrary arithmetic carrier.

Assumptions:
- Model: the two computation equations for all finite initialized binary
  iterator descriptions.
- PositiveConstancy: PC indexed only by finite Term syntax.
- EqualityRecognition: the one fixed ER sentence, built from the actual
  addition, monus, and zero-gate terms; it is not a free equality oracle.

Linked endpoint:
  quantifier_free_induction

The proof links separation, successor facts, gate reflection, zero and
equality decisions, native equality reflection, constructor coverage,
ordinary constancy, the Boolean equality monitor, derived successor
uniqueness, direct-doubling bit retractions, the cumulative latch, zero
induction, and a constructive finite-formula compiler.

23 printed theorem-dependency audits all report no global Lean axioms.
No errors or warnings in the final compiler log.

2. FourUpdates.lean

Lean 4.19.0; no imports or external dependencies.
Namespace: FourUpdates.
Linked endpoint:
  quantifier_free_induction

Assumptions: Model, exactly the three fixed positive-uniqueness updates
successor/predecessor/identity, and one fixed MaxLaw.
39 printed dependency audits all report no global Lean axioms.

The four-update companion is specified as a separate finite update
interface, and three_of_four extracts its three-update subfamily.
The derivation of Max from the fourth update is a written proof in the
companion report, not a linked endpoint of this file.

3. Common scope

An empty global-axiom report does not remove the explicit hypotheses.
There is no induction on the arithmetic carrier, no hidden use of Lean's
Nat induction on that carrier, no arbitrary-map arithmetic schema, and no
classical choice. Structural induction on finite syntax is metatheoretic.

Not claimed as formalized endpoints:
- Entire first-order deduction calculus and proof translations.
- Triangular pairing retractions.
- Elimination of arbitrary finite parameter tuples.
- Ordinary primitive-recursion source compiler.
- Converse from ordinary PRA.
- Full conservative definitional-equivalence theorem.

These are supplied as written proofs in the reports.

4. Provenance

The syntax and parts of the constructive infrastructure refine
ProveIt/docs/drafts/pra_positive_uniqueness_2026-10-31 (1).zip,
formal/PositiveUniqueness.lean, snapshot
b0350fd1c96d8273ca9c3b5ce025782b748cded7.

The reduced arithmetic interfaces, cumulative latch, formula compiler,
and PositiveConstancy certificate are part of this research.
Further details are retained in the source headers.

5. Re-run

  lean PositiveConstancy.lean
  lean FourUpdates.lean

Or use the archive-root check.sh with PRA_LEAN_BIN set to the Lean 4.19.0
executable. No mathlib, lake configuration, or downloaded dependencies
are required.

