Finite-syntax constructive certificate: exact scope
===================================================

FourUpdates.lean was checked with Lean 4.19.0, without imports or external
packages. Run: lean FourUpdates.lean
The recorded compiler output is FourUpdates.log.

Provenance
----------
The finite-term representation and elementary bootstrap were adapted from
ProveIt/docs/drafts/pra_positive_uniqueness_2026-10-31 (1).zip,
formal/PositiveUniqueness.lean, at repository snapshot
b0350fd1c96d8273ca9c3b5ce025782b748cded7.
The defining changes are the restricted arithmetic-update interface,
doubling defined by addition, the cumulative error latch, the explicit
MaxLaw bridge, and the actual finite-formula compiler.

Precise interfaces
------------------
The arbitrary type A is the arithmetic carrier; it has no induction
principle. Term is actual finite initialized-binary-iterator syntax with
two numerical slots. Stored update descriptors have independent scope;
substitution into an application never substitutes into its descriptor.
Model supplies only the two computation equations for all finite updates.

BasicUpdate admits only successor, predecessor, and identity. PositiveSchema
quantifies over finite candidate terms and exactly these three update
constructors. It never quantifies over arbitrary functions A -> A.
AllowedUpdate and FourPositiveSchema describe the four-update companion;
three_of_four derives the three-update interface. The fourth update is the
fixed maximum program, not an arbitrary target-dependent program.

Certified linked endpoint
-------------------------
quantifier_free_induction assumes Model, the three-update PositiveSchema,
and one fixed MaxLaw equation. It proves contextual quantifier-free induction
for every Formula with an induction slot and one fixed parameter slot.
Formula is actual finite syntax for native term equality, falsehood,
conjunction, disjunction and implication. The linked proof establishes:
- constructor separation, injectivity, nonzeroness and positive coverage;
- permitted recursion uniqueness and elementary addition/monus identities;
- parity/half retractions, with doubling defined as x+x;
- cumulative-latch zero-equation induction using identity uniqueness only;
- native equality reflection from MaxLaw and numerical equality decision;
- constructive formula compilation and full one-parameter QF induction.

The target-dependent latch update is used ONLY as a computation description.
It is not supplied to any arithmetic uniqueness callback. All arithmetic
callbacks carry an explicit BasicUpdate constructor.

All 39 printed dependency audits report no global Lean axioms. Computation,
PositiveSchema, and (where needed) MaxLaw remain explicit theorem hypotheses.
There are no sorry placeholders, axiom declarations, classical choices,
function extensionality assumptions, or induction on the arithmetic carrier.
Structural induction on finite Term/Formula syntax is metatheoretic.

Not certified as linked endpoints
--------------------------------
This file does not formalize an entire first-order deduction calculus, the
triangular pairing construction, arbitrary finite parameter tuples,
translation of ordinary primitive recursion, the converse proof from PRA,
or the full conservative definitional-equivalence theorem. These have
written proofs in the manuscript. It also does not derive MaxLaw from the
four-update companion; that reduction is proved in the manuscript using
the audited Boolean diagonal and maximum arguments from the source draft.
