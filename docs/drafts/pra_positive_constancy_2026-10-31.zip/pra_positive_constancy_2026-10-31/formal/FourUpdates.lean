/-
Three or four fixed updates: finite-syntax constructive core.
Adapted from the ProveIt draft pra_positive_uniqueness_2026-10-31 (1).zip,
formal/PositiveUniqueness.lean, repository snapshot
b0350fd1c96d8273ca9c3b5ce025782b748cded7.
Changes: restrict arithmetic updates to S, p, identity; a companion interface
adds the fourth maximum program. The three-update version uses an explicit
MaxLaw hypothesis only in the native equality-reflection endpoint.
Define doubling by addition; replace
arbitrary-update zero induction with a cumulative latch using only identity
arithmetic uniqueness. The new latch update is used only for computation.
Lean 4.19.0, no imports and no external packages.

The arithmetic carrier A is arbitrary. There is no induction on A.
Term is the actual well-founded binary initialized-iteration syntax.
An iterator's update has its own two bound slots; substitution in an
application does not enter that update descriptor. PU quantifies only over
these finite terms, never over arbitrary functions on the arithmetic carrier.

Certified here: substitution semantics, PU -> separation, successor laws,
contextual recursion uniqueness for the three permitted updates, constructor coverage, zero
decision, selected arithmetic identities, binary digit retractions, and
contextual zero-equation induction with an arbitrary fixed parameter, and
native equality reflection from the additional fixed MaxLaw, an actual finite
quantifier-free formula compiler, and one-parameter quantifier-free induction.
Pairing, arbitrary-parameter elimination, and full first-order proof-calculus
or theory equivalence are not claimed to be formalized in this file.
-/

namespace FourUpdates

universe u

inductive Term where
  | first
  | second
  | zero
  | succ (argument : Term)
  | iter (update counter seed : Term)
  deriving DecidableEq

def substitute : Term → Term → Term → Term
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => .zero
  | .succ t, x, y => .succ (substitute t x y)
  | .iter h n a, x, y => .iter h (substitute n x y) (substitute a x y)

def evaluate {A : Type u} (zero : A) (succ : A → A)
    (run : Term → A → A → A) : Term → A → A → A
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => zero
  | .succ t, x, y => succ (evaluate zero succ run t x y)
  | .iter h n a, x, y =>
      run h (evaluate zero succ run n x y) (evaluate zero succ run a x y)

structure Model (A : Type u) where
  zero : A
  succ : A → A
  run : Term → A → A → A
  run_zero : ∀ h a, run h zero a = a
  run_succ : ∀ h n a,
    run h (succ n) a = evaluate zero succ run h n (run h n a)

def value {A : Type u} (C : Model A) (t : Term) (x y : A) : A :=
  evaluate C.zero C.succ C.run t x y

variable {A : Type u} (C : Model A)

theorem value_substitute (t x y : Term) (n a : A) :
    value C (substitute t x y) n a =
      value C t (value C x n a) (value C y n a) := by
  induction t with
  | first => rfl
  | second => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | iter h n' a' _ ihn iha =>
      change C.run h (value C (substitute n' x y) n a)
          (value C (substitute a' x y) n a) =
        C.run h (value C n' (value C x n a) (value C y n a))
          (value C a' (value C x n a) (value C y n a))
      exact congr (congrArg (C.run h) ihn) iha

def oneTerm : Term := .succ .zero
def predTerm (t : Term) : Term := .iter .first t .zero
def addTerm (s t : Term) : Term := .iter (.succ .second) s t
def gateTerm (s t : Term) : Term := .iter .zero s t
def monusTerm (s t : Term) : Term := .iter (predTerm .second) s t

def one : A := C.succ C.zero
def pred (x : A) : A := C.run .first x C.zero
def add (x y : A) : A := C.run (.succ .second) x y
def gate (x y : A) : A := C.run .zero x y
def monus (x y : A) : A := C.run (predTerm .second) x y

theorem pred_zero : pred C C.zero = C.zero := C.run_zero _ _
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.run_succ _ _ _
theorem add_zero (x : A) : add C C.zero x = x := C.run_zero _ _
theorem add_succ (x y : A) : add C (C.succ x) y = C.succ (add C x y) :=
  C.run_succ _ _ _
theorem gate_zero (x : A) : gate C C.zero x = x := C.run_zero _ _
theorem gate_succ (x y : A) : gate C (C.succ x) y = C.zero := C.run_succ _ _ _
theorem monus_zero (x : A) : monus C C.zero x = x := C.run_zero _ _
theorem monus_succ (x y : A) : monus C (C.succ x) y = pred C (monus C x y) :=
  C.run_succ _ _ _

/-- Every quantified object is finite syntax; a is the sole fixed parameter. -/
def maximumUpdate : Term :=
  addTerm .second (gateTerm (monusTerm .first .second) oneTerm)

/-- Exactly four fixed programs may occur in an arithmetic PU instance. -/
inductive AllowedUpdate : Term → Prop where
  | successor : AllowedUpdate (.succ .second)
  | predecessor : AllowedUpdate (predTerm .second)
  | identity : AllowedUpdate .second
  | maximum : AllowedUpdate maximumUpdate

/-- Only the first three fixed programs are needed for the certified bootstrap. -/
inductive BasicUpdate : Term → Prop where
  | successor : BasicUpdate (.succ .second)
  | predecessor : BasicUpdate (predTerm .second)
  | identity : BasicUpdate .second

def PositiveSchema : Prop :=
  ∀ t h : Term, BasicUpdate h → ∀ a : A,
    (∀ n, value C t (C.succ (C.succ n)) a =
      value C h n (value C t (C.succ n) a)) →
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨
        value C t n a = C.run h (pred C n) (value C t (one C) a)

def FourPositiveSchema : Prop :=
  ∀ t h : Term, AllowedUpdate h → ∀ a : A,
    (∀ n, value C t (C.succ (C.succ n)) a =
      value C h n (value C t (C.succ n) a)) →
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨
        value C t n a = C.run h (pred C n) (value C t (one C) a)

theorem three_of_four (PU4 : FourPositiveSchema C) : PositiveSchema C := by
  intro t h allowed a step
  cases allowed with
  | successor => exact PU4 t _ .successor a step
  | predecessor => exact PU4 t _ .predecessor a step
  | identity => exact PU4 t _ .identity a step

variable (PU : PositiveSchema C)
include PU

theorem separation : C.zero ≠ C.succ C.zero := by
  exact (PU .first (.succ .second) .successor C.zero (fun _ => rfl)).1

omit PU in
theorem successor_injective {x y : A} (h : C.succ x = C.succ y) : x = y := by
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_succ C] at e
  exact e

theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro h
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_zero C] at e
  have bad : C.succ C.zero = C.zero := (congrArg C.succ e).symm.trans h
  exact separation C PU bad.symm

/-- Ordinary initialized recursion uniqueness, with a term parameter. -/
theorem recursion_uniqueness (t h : Term) (allowed : BasicUpdate h) (a : A)
    (step : ∀ n, value C t (C.succ n) a = value C h n (value C t n a)) :
    ∀ n, value C t n a = C.run h n (value C t C.zero a) := by
  let delayed := substitute t (predTerm .first) .second
  have delay (x : A) : value C delayed x a = value C t (pred C x) a := by
    exact value_substitute C t (predTerm .first) .second x a
  have positive := PU delayed h allowed a (by
    intro n
    rw [delay, delay, pred_succ C, pred_succ C]
    exact step n)
  intro n
  rcases positive.2 (C.succ n) with hz | he
  · exact False.elim (successor_ne_zero C PU n hz)
  · rw [delay, delay, pred_succ C] at he
    change value C t n a = C.run h n (value C t (pred C (C.succ C.zero)) a) at he
    rw [pred_succ C] at he
    exact he

theorem add_right_zero (x : A) : add C x C.zero = x := by
  have q := recursion_uniqueness C PU .first (.succ .second) .successor C.zero
    (fun _ => rfl) x
  exact q.symm

theorem add_one (x : A) : add C x (one C) = C.succ x := by
  have q := recursion_uniqueness C PU (.succ .first) (.succ .second) .successor C.zero
    (fun _ => rfl) x
  exact q.symm

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  have q := PU .first (.succ .second) .successor C.zero (fun _ => rfl)
  rcases q.2 x with hz | he
  · exact Or.inl hz
  · change x = add C (pred C x) (one C) at he
    rw [add_one C PU] at he
    exact Or.inr he

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases coverage C PU x with hz | hs
  · exact Or.inl hz
  · exact Or.inr (fun hz => successor_ne_zero C PU (pred C x) (hs.symm.trans hz))

theorem add_right_succ (x y : A) : add C x (C.succ y) = C.succ (add C x y) := by
  let t : Term := .succ (addTerm .first .second)
  have step (n : A) : value C t (C.succ n) y =
      value C (.succ .second) n (value C t n y) := by
    change C.succ (add C (C.succ n) y) = C.succ (C.succ (add C n y))
    rw [add_succ C]
  have q := recursion_uniqueness C PU t (.succ .second) .successor y step x
  change C.succ (add C x y) = add C x (C.succ (add C C.zero y)) at q
  rw [add_zero C] at q
  exact q.symm

theorem addition_commutes (x y : A) : add C x y = add C y x := by
  let t := addTerm .second .first
  have step (n : A) : value C t (C.succ n) y =
      value C (.succ .second) n (value C t n y) := by
    exact add_right_succ C PU y n
  have q := recursion_uniqueness C PU t (.succ .second) .successor y step x
  change add C y x = add C x (add C y C.zero) at q
  rw [add_right_zero C PU] at q
  exact q.symm

theorem monus_pred_commutes (x y : A) :
    monus C x (pred C y) = pred C (monus C x y) := by
  let t := predTerm (monusTerm .first .second)
  let h := predTerm .second
  have step (n : A) : value C t (C.succ n) y =
      value C h n (value C t n y) := by
    change pred C (monus C (C.succ n) y) = pred C (pred C (monus C n y))
    rw [monus_succ C]
  have q := recursion_uniqueness C PU t h .predecessor y step x
  change pred C (monus C x y) = monus C x (pred C (monus C C.zero y)) at q
  rw [monus_zero C] at q
  exact q.symm

theorem monus_shift (x y : A) : monus C (C.succ x) (C.succ y) = monus C x y := by
  rw [monus_succ C, ← monus_pred_commutes C PU, pred_succ C]

theorem monus_zero_right (x : A) : monus C x C.zero = C.zero := by
  have q := recursion_uniqueness C PU .zero (predTerm .second) .predecessor C.zero
    (fun _ => (pred_zero C).symm) x
  exact q.symm

theorem monus_diagonal (x : A) : monus C x x = C.zero := by
  let t := monusTerm .first .first
  have step (n : A) : value C t (C.succ n) C.zero =
      value C .second n (value C t n C.zero) := by
    exact monus_shift C PU n n
  have q := recursion_uniqueness C PU t .second .identity C.zero step x
  change monus C x x = C.run .second x (monus C C.zero C.zero) at q
  rw [monus_zero C] at q
  have z := recursion_uniqueness C PU .zero .second .identity C.zero (fun _ => rfl) x
  exact q.trans z.symm

theorem monus_add_cancel (x y : A) : monus C x (add C x y) = y := by
  let t := monusTerm .first (addTerm .first .second)
  have step (n : A) : value C t (C.succ n) y =
      value C .second n (value C t n y) := by
    change monus C (C.succ n) (add C (C.succ n) y) = monus C n (add C n y)
    rw [add_succ C, monus_shift C PU]
  have q := recursion_uniqueness C PU t .second .identity y step x
  change monus C x (add C x y) = C.run .second x (monus C C.zero (add C C.zero y)) at q
  rw [add_zero C, monus_zero C] at q
  have z := recursion_uniqueness C PU .second .second .identity y (fun _ => rfl) x
  exact q.trans z.symm

def selectTerm (z x y : Term) : Term :=
  addTerm (gateTerm z x) (gateTerm (gateTerm z oneTerm) y)

def select (z x y : A) : A :=
  add C (gate C z x) (gate C (gate C z (one C)) y)

theorem select_zero (x y : A) : select C C.zero x y = x := by
  unfold select one
  rw [gate_zero C, gate_zero C, gate_succ C, add_right_zero C PU]

omit PU in
theorem select_succ (z x y : A) : select C (C.succ z) x y = y := by
  unfold select
  rw [gate_succ C, gate_succ C, gate_zero C, add_zero C]

theorem select_nonzero {z : A} (hz : z ≠ C.zero) (x y : A) :
    select C z x y = y := by
  rcases coverage C PU z with h | h
  · exact False.elim (hz h)
  · rw [h, select_succ C]

theorem select_same (z x : A) : select C z x x = x := by
  rcases coverage C PU z with h | h
  · rw [h, select_zero C PU]
  · rw [h, select_succ C]

omit PU in
theorem value_select (z x y : Term) (n a : A) :
    value C (selectTerm z x y) n a =
      select C (value C z n a) (value C x n a) (value C y n a) := rfl

def Bit (x : A) : Prop := x = C.zero ∨ x = one C

def parityUpdate : Term := gateTerm .second oneTerm
def parityTerm (t : Term) : Term := .iter parityUpdate t .zero
def halfUpdate : Term := selectTerm (parityTerm .first) .second (.succ .second)
def halfTerm (t : Term) : Term := .iter halfUpdate t .zero
def doubleTerm (t : Term) : Term := addTerm t t

def parity (x : A) : A := C.run parityUpdate x C.zero
def half (x : A) : A := C.run halfUpdate x C.zero
def double (x : A) : A := add C x x

omit PU in
theorem parity_zero : parity C C.zero = C.zero := C.run_zero _ _
omit PU in
theorem parity_succ (x : A) : parity C (C.succ x) = gate C (parity C x) (one C) :=
  C.run_succ _ _ _
omit PU in
theorem half_zero : half C C.zero = C.zero := C.run_zero _ _
omit PU in
theorem half_succ (x : A) : half C (C.succ x) =
    select C (parity C x) (half C x) (C.succ (half C x)) := C.run_succ _ _ _
omit PU in
theorem double_zero : double C C.zero = C.zero := C.run_zero _ _
theorem double_succ (x : A) : double C (C.succ x) =
    C.succ (C.succ (double C x)) := by
  unfold double
  rw [add_succ C, add_right_succ C PU]

theorem gate_is_bit (x : A) : Bit C (gate C x (one C)) := by
  rcases coverage C PU x with h | h
  · exact Or.inr (by rw [h, gate_zero C])
  · exact Or.inl (by rw [h, gate_succ C])

theorem parity_is_bit (x : A) : Bit C (parity C x) := by
  rcases coverage C PU x with h | h
  · exact Or.inl (by rw [h, parity_zero C])
  · rw [h, parity_succ C]
    exact gate_is_bit C PU _

theorem parity_twice (x : A) : parity C (C.succ (C.succ x)) = parity C x := by
  rw [parity_succ C, parity_succ C]
  rcases parity_is_bit C PU x with h | h
  · rw [h, gate_zero C]
    exact gate_succ C C.zero (one C)
  · rw [h]
    change gate C (gate C (C.succ C.zero) (one C)) (one C) = one C
    rw [gate_succ C, gate_zero C]

theorem half_twice (x : A) : half C (C.succ (C.succ x)) = C.succ (half C x) := by
  rw [half_succ C, half_succ C, parity_succ C]
  rcases parity_is_bit C PU x with h | h
  · rw [h, gate_zero C, select_zero C PU]
    exact select_succ C C.zero (half C x) (C.succ (half C x))
  · rw [h]
    change select C (gate C (C.succ C.zero) (one C))
      (select C (C.succ C.zero) (half C x) (C.succ (half C x)))
      (C.succ (select C (C.succ C.zero) (half C x) (C.succ (half C x)))) =
      C.succ (half C x)
    rw [gate_succ C, select_succ C, select_zero C PU]

theorem parity_double (x : A) : parity C (double C x) = C.zero := by
  let t := parityTerm (doubleTerm .first)
  have step (n : A) : value C t (C.succ n) C.zero =
      value C .second n (value C t n C.zero) := by
    change parity C (double C (C.succ n)) = parity C (double C n)
    rw [double_succ C PU, parity_twice C PU]
  have q := recursion_uniqueness C PU t .second .identity C.zero step x
  change parity C (double C x) = C.run .second x (parity C (double C C.zero)) at q
  rw [double_zero C, parity_zero C] at q
  have z := recursion_uniqueness C PU .zero .second .identity C.zero (fun _ => rfl) x
  exact q.trans z.symm

theorem half_double (x : A) : half C (double C x) = x := by
  let t := halfTerm (doubleTerm .first)
  have step (n : A) : value C t (C.succ n) C.zero =
      value C (.succ .second) n (value C t n C.zero) := by
    change half C (double C (C.succ n)) = C.succ (half C (double C n))
    rw [double_succ C PU, half_twice C PU]
  have q := recursion_uniqueness C PU t (.succ .second) .successor C.zero step x
  change half C (double C x) = add C x (half C (double C C.zero)) at q
  rw [double_zero C, half_zero C, add_right_zero C PU] at q
  exact q

theorem parity_odd (x : A) : parity C (C.succ (double C x)) = one C := by
  rw [parity_succ C, parity_double C PU, gate_zero C]

theorem half_odd (x : A) : half C (C.succ (double C x)) = x := by
  rw [half_succ C, parity_double C PU, select_zero C PU, half_double C PU]

def encodeTerm (a b : Term) : Term := selectTerm b (doubleTerm a) (.succ (doubleTerm a))
def encode (a b : A) : A := select C b (double C a) (C.succ (double C a))

theorem encode_zero (a : A) : encode C a C.zero = double C a :=
  select_zero C PU _ _

omit PU in
theorem encode_one (a : A) : encode C a (one C) = C.succ (double C a) :=
  select_succ C C.zero _ _

theorem half_encode (a b : A) : half C (encode C a b) = a := by
  rcases coverage C PU b with h | h
  · rw [h, encode_zero C PU, half_double C PU]
  · unfold encode
    rw [h, select_succ C, half_odd C PU]

theorem parity_encode (a b : A) (hb : Bit C b) : parity C (encode C a b) = b := by
  rcases hb with h | h
  · rw [h, encode_zero C PU, parity_double C PU]
  · rw [h, encode_one C, parity_odd C PU]

def indicatorTerm (t : Term) : Term := selectTerm t .zero oneTerm
def indicator (x : A) : A := select C x C.zero (one C)

theorem indicator_zero : indicator C C.zero = C.zero := select_zero C PU _ _
theorem indicator_nonzero {x : A} (hx : x ≠ C.zero) : indicator C x = one C :=
  select_nonzero C PU hx _ _

theorem indicator_is_bit (x : A) : Bit C (indicator C x) := by
  rcases zero_decision C PU x with h | h
  · exact Or.inl (by rw [h, indicator_zero C PU])
  · exact Or.inr (indicator_nonzero C PU h)

theorem indicator_reflects (x : A) (hx : indicator C x = C.zero) : x = C.zero := by
  rcases zero_decision C PU x with h | h
  · exact h
  · rw [indicator_nonzero C PU h] at hx
    exact False.elim (separation C PU hx.symm)

omit PU in
theorem value_encode (a b : Term) (n p : A) :
    value C (encodeTerm a b) n p = encode C (value C a n p) (value C b n p) := rfl

omit PU in
theorem value_indicator (t : Term) (n a : A) :
    value C (indicatorTerm t) n a = indicator C (value C t n a) := rfl


/-- This target-dependent update belongs only to the computation grammar. -/
def latchUpdate (t : Term) : Term :=
  encodeTerm (halfTerm .second)
    (selectTerm (parityTerm .second)
      (indicatorTerm (substitute t (.succ .first) (halfTerm .second))) oneTerm)

def latchStateTerm (t : Term) : Term :=
  .iter (latchUpdate t) .first
    (encodeTerm .second (indicatorTerm (substitute t .zero .second)))

def latchTerm (t : Term) : Term := parityTerm (latchStateTerm t)

def latchState (t : Term) (n a : A) : A :=
  C.run (latchUpdate t) n (encode C a (indicator C (value C t C.zero a)))

def latch (t : Term) (n a : A) : A := parity C (latchState C t n a)

omit PU in
theorem value_latchUpdate (t : Term) (n v : A) :
    value C (latchUpdate t) n v =
      encode C (half C v)
        (select C (parity C v)
          (indicator C (value C t (C.succ n) (half C v))) (one C)) := by
  unfold latchUpdate
  rw [value_encode C, value_select C, value_indicator C, value_substitute C]
  rfl

omit PU in
theorem value_latchState (t : Term) (n a : A) :
    value C (latchStateTerm t) n a = latchState C t n a := by
  change C.run (latchUpdate t) n
    (value C (encodeTerm .second (indicatorTerm (substitute t .zero .second))) n a) = _
  rw [value_encode C, value_indicator C, value_substitute C]
  rfl

omit PU in
theorem value_latch (t : Term) (n a : A) :
    value C (latchTerm t) n a = latch C t n a := by
  change parity C (value C (latchStateTerm t) n a) = _
  rw [value_latchState C]
  rfl

omit PU in
theorem latchState_zero (t : Term) (a : A) :
    latchState C t C.zero a = encode C a (indicator C (value C t C.zero a)) :=
  C.run_zero _ _

omit PU in
theorem latchState_succ (t : Term) (n a : A) :
    latchState C t (C.succ n) a =
      encode C (half C (latchState C t n a))
        (select C (parity C (latchState C t n a))
          (indicator C (value C t (C.succ n) (half C (latchState C t n a))))
          (one C)) := by
  have q := C.run_succ (latchUpdate t) n
    (encode C a (indicator C (value C t C.zero a)))
  change latchState C t (C.succ n) a =
    value C (latchUpdate t) n (latchState C t n a) at q
  rw [value_latchUpdate C] at q
  exact q

/-- Parameter preservation invokes only identity arithmetic uniqueness. -/
theorem stored_parameter (t : Term) (n a : A) :
    half C (latchState C t n a) = a := by
  let f := halfTerm (latchStateTerm t)
  have vf (x : A) : value C f x a = half C (latchState C t x a) := by
    change half C (value C (latchStateTerm t) x a) = _
    rw [value_latchState C]
  have step (x : A) : value C f (C.succ x) a =
      value C .second x (value C f x a) := by
    change value C f (C.succ x) a = value C f x a
    rw [vf, vf, latchState_succ C, half_encode C PU]
  have q := recursion_uniqueness C PU f .second .identity a step n
  rw [vf, vf, latchState_zero C, half_encode C PU] at q
  have constant := recursion_uniqueness C PU .second .second .identity a
    (fun _ => rfl) n
  exact q.trans constant.symm

theorem bit_or (x y : A) (hx : Bit C x) (hy : Bit C y) :
    Bit C (select C x y (one C)) := by
  rcases hx with hx | hx
  · rw [hx, select_zero C PU]
    exact hy
  · rw [hx]
    change Bit C (select C (C.succ C.zero) y (one C))
    rw [select_succ C]
    exact Or.inr rfl

theorem bit_or_zero_right (x y : A)
    (h : select C x y (one C) = C.zero) : y = C.zero := by
  rcases zero_decision C PU x with hx | hx
  · rw [hx, select_zero C PU] at h
    exact h
  · rw [select_nonzero C PU hx] at h
    exact False.elim (separation C PU h.symm)

theorem latch_is_bit (t : Term) (n a : A) : Bit C (latch C t n a) :=
  parity_is_bit C PU _

theorem latch_zero (t : Term) (a : A) :
    latch C t C.zero a = indicator C (value C t C.zero a) := by
  unfold latch
  rw [latchState_zero C, parity_encode C PU _ _ (indicator_is_bit C PU _)]

theorem latch_succ (t : Term) (n a : A) :
    latch C t (C.succ n) a =
      select C (latch C t n a)
        (indicator C (value C t (C.succ n) a)) (one C) := by
  unfold latch
  rw [latchState_succ C]
  rw [parity_encode C PU _ _ (bit_or C PU _ _
    (parity_is_bit C PU _) (indicator_is_bit C PU _))]
  rw [stored_parameter C PU]

/-- The current factor is present in the latch by constructor coverage alone. -/
theorem latch_reflects (t : Term) (n a : A)
    (hn : latch C t n a = C.zero) : value C t n a = C.zero := by
  rcases coverage C PU n with hz | hs
  · rw [hz, latch_zero C PU] at hn
    rw [hz]
    exact indicator_reflects C PU _ hn
  · rw [hs, latch_succ C PU] at hn
    have hb := bit_or_zero_right C PU _ _ hn
    rw [hs]
    exact indicator_reflects C PU _ hb

/-- Contextual zero induction needs no target-dependent arithmetic update. -/
theorem zero_induction (t : Term) (a : A)
    (base : value C t C.zero a = C.zero)
    (step : ∀ n, value C t n a = C.zero → value C t (C.succ n) a = C.zero) :
    ∀ n, value C t n a = C.zero := by
  have constant (n : A) : latch C t (C.succ n) a = latch C t n a := by
    rcases latch_is_bit C PU t n a with hz | ho
    · have next := step n (latch_reflects C PU t n a hz)
      rw [latch_succ C PU, hz, next, indicator_zero C PU, select_zero C PU]
    · rw [latch_succ C PU, ho]
      exact select_succ C C.zero _ _
  have term_step (n : A) : value C (latchTerm t) (C.succ n) a =
      value C .second n (value C (latchTerm t) n a) := by
    change value C (latchTerm t) (C.succ n) a = value C (latchTerm t) n a
    rw [value_latch C, value_latch C]
    exact constant n
  have trace := recursion_uniqueness C PU (latchTerm t) .second .identity a term_step
  intro n
  have q := trace n
  rw [value_latch C, value_latch C, latch_zero C PU, base, indicator_zero C PU] at q
  have z := recursion_uniqueness C PU .zero .second .identity C.zero (fun _ => rfl) n
  exact latch_reflects C PU t n a (q.trans z.symm)

/-- The additional fixed equation in the shorter written presentation. -/
def MaxLaw : Prop :=
  ∀ x y : A, add C x (monus C x y) = add C y (monus C y x)

theorem sum_zero_left (x y : A) (h : add C x y = C.zero) : x = C.zero := by
  rcases coverage C PU x with hz | hs
  · exact hz
  · rw [hs, add_succ C] at h
    exact False.elim (successor_ne_zero C PU _ h)

theorem sum_zero_right (x y : A) (h : add C x y = C.zero) : y = C.zero := by
  have hx := sum_zero_left C PU x y h
  rw [hx, add_zero C] at h
  exact h

def distance (x y : A) : A := add C (monus C x y) (monus C y x)

theorem equality_reflection (maximum : MaxLaw C) (x y : A) :
    distance C x y = C.zero ↔ x = y := by
  constructor
  · intro h
    have hxy := sum_zero_left C PU (monus C x y) (monus C y x) h
    have hyx := sum_zero_right C PU (monus C x y) (monus C y x) h
    have q := maximum x y
    rw [hxy, hyx, add_right_zero C PU, add_right_zero C PU] at q
    exact q
  · intro h
    rw [h]
    unfold distance
    rw [monus_diagonal C PU, add_zero C]

theorem equality_decision (maximum : MaxLaw C) (x y : A) :
    x = y ∨ x ≠ y := by
  rcases zero_decision C PU (distance C x y) with hz | hn
  · exact Or.inl ((equality_reflection C PU maximum x y).mp hz)
  · exact Or.inr (fun h => hn ((equality_reflection C PU maximum x y).mpr h))


/-- Actual finite quantifier-free syntax with two free numerical slots. -/
inductive Formula where
  | equal (left right : Term)
  | falsehood
  | conj (left right : Formula)
  | disj (left right : Formula)
  | impl (left right : Formula)

def holds : Formula → A → A → Prop
  | .equal s t, n, a => value C s n a = value C t n a
  | .falsehood, _, _ => False
  | .conj P Q, n, a => holds P n a ∧ holds Q n a
  | .disj P Q, n, a => holds P n a ∨ holds Q n a
  | .impl P Q, n, a => holds P n a → holds Q n a

def errorTerm : Formula → Term
  | .equal s t => addTerm (monusTerm s t) (monusTerm t s)
  | .falsehood => oneTerm
  | .conj P Q => selectTerm (errorTerm P) (errorTerm Q) oneTerm
  | .disj P Q => selectTerm (errorTerm P) .zero (errorTerm Q)
  | .impl P Q => selectTerm (errorTerm P) (errorTerm Q) .zero

/-- Constructive compilation, including material implication on decided atoms. -/
theorem error_correct (maximum : MaxLaw C) (P : Formula) (n a : A) :
    value C (errorTerm P) n a = C.zero ↔ holds C P n a := by
  induction P with
  | equal s t =>
      exact equality_reflection C PU maximum (value C s n a) (value C t n a)
  | falsehood =>
      change one C = C.zero ↔ False
      constructor
      · intro h
        exact separation C PU h.symm
      · intro h
        exact False.elim h
  | conj P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) (value C (errorTerm Q) n a)
        (one C) = C.zero ↔ holds C P n a ∧ holds C Q n a
      rcases zero_decision C PU (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C PU]
        constructor
        · intro hq
          exact ⟨ihP.mp hp, ihQ.mp hq⟩
        · intro h
          exact ihQ.mpr h.2
      · rw [select_nonzero C PU hp]
        constructor
        · intro h
          exact False.elim (separation C PU h.symm)
        · intro h
          exact False.elim (hp (ihP.mpr h.1))
  | disj P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) C.zero
        (value C (errorTerm Q) n a) = C.zero ↔ holds C P n a ∨ holds C Q n a
      rcases zero_decision C PU (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C PU]
        constructor
        · intro _
          exact Or.inl (ihP.mp hp)
        · intro _
          rfl
      · rw [select_nonzero C PU hp]
        constructor
        · intro hq
          exact Or.inr (ihQ.mp hq)
        · intro h
          rcases h with h | h
          · exact False.elim (hp (ihP.mpr h))
          · exact ihQ.mpr h
  | impl P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) (value C (errorTerm Q) n a)
        C.zero = C.zero ↔ (holds C P n a → holds C Q n a)
      rcases zero_decision C PU (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C PU]
        constructor
        · intro hq _
          exact ihQ.mp hq
        · intro h
          exact ihQ.mpr (h (ihP.mp hp))
      · rw [select_nonzero C PU hp]
        constructor
        · intro _ h
          exact False.elim (hp (ihP.mpr h))
        · intro _
          rfl

theorem quantifier_free_decision (maximum : MaxLaw C) (P : Formula) (n a : A) :
    holds C P n a ∨ ¬ holds C P n a := by
  rcases zero_decision C PU (value C (errorTerm P) n a) with h | h
  · exact Or.inl ((error_correct C PU maximum P n a).mp h)
  · exact Or.inr (fun q => h ((error_correct C PU maximum P n a).mpr q))

/-- The linked finite-syntax endpoint: full quantifier-free induction,
    with one arbitrary fixed numerical parameter, from PU3 and MaxLaw. -/
theorem quantifier_free_induction (maximum : MaxLaw C) (P : Formula) (a : A)
    (base : holds C P C.zero a)
    (step : ∀ n, holds C P n a → holds C P (C.succ n) a) :
    ∀ n, holds C P n a := by
  have ezero := (error_correct C PU maximum P C.zero a).mpr base
  have estep (n : A) (h : value C (errorTerm P) n a = C.zero) :
      value C (errorTerm P) (C.succ n) a = C.zero := by
    apply (error_correct C PU maximum P (C.succ n) a).mpr
    exact step n ((error_correct C PU maximum P n a).mp h)
  have eind := zero_induction C PU (errorTerm P) a ezero estep
  intro n
  exact (error_correct C PU maximum P n a).mp (eind n)

#print axioms error_correct
#print axioms quantifier_free_decision
#print axioms quantifier_free_induction
#print axioms three_of_four
#print axioms equality_reflection
#print axioms equality_decision
#print axioms value_substitute
#print axioms separation
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms recursion_uniqueness
#print axioms coverage
#print axioms zero_decision
#print axioms add_right_zero
#print axioms add_right_succ
#print axioms addition_commutes
#print axioms monus_pred_commutes
#print axioms monus_shift
#print axioms monus_zero_right
#print axioms monus_diagonal
#print axioms monus_add_cancel
#print axioms select_zero
#print axioms select_nonzero
#print axioms parity_is_bit
#print axioms parity_twice
#print axioms half_twice
#print axioms double_succ
#print axioms parity_double
#print axioms half_double
#print axioms half_encode
#print axioms parity_encode
#print axioms indicator_reflects
#print axioms value_latchUpdate
#print axioms value_latchState
#print axioms stored_parameter
#print axioms latch_zero
#print axioms latch_succ
#print axioms latch_reflects
#print axioms zero_induction

end FourUpdates
