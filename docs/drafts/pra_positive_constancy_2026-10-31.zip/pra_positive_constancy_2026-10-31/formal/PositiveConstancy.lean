/-
Positive constancy and one fixed equality-recognition sentence.
Finite-syntax constructive certificate, Lean 4.19.0; no imports.

Adapted from FourUpdates.lean (this research archive), whose underlying
syntax, selector, digit coding, and formula compiler refine the ProveIt
positive-uniqueness draft (1), snapshot
b0350fd1c96d8273ca9c3b5ce025782b748cded7.

The carrier is arbitrary. Every PC instance ranges over the actual finite
Term syntax below, never over arbitrary carrier maps. The fixed ER sentence
uses the displayed primitive-recursive distance term, rather than an
uninterpreted equality oracle. No induction on the carrier is assumed.

The final endpoint certifies all one-parameter quantifier-free induction
instances via actual finite Formula syntax. Pairing and elimination of
arbitrary finite parameter tuples remain written proofs in the paper.
-/

namespace PositiveConstancy

universe u

inductive Term where
  | first
  | second
  | zero
  | succ (argument : Term)
  | iter (update counter seed : Term)
  deriving DecidableEq

def substitute : Term → Term → Term → Term
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => .zero
  | .succ t, x, y => .succ (substitute t x y)
  | .iter h n a, x, y => .iter h (substitute n x y) (substitute a x y)

def evaluate {A : Type u} (zero : A) (succ : A → A)
    (run : Term → A → A → A) : Term → A → A → A
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => zero
  | .succ t, x, y => succ (evaluate zero succ run t x y)
  | .iter h n a, x, y =>
      run h (evaluate zero succ run n x y) (evaluate zero succ run a x y)

structure Model (A : Type u) where
  zero : A
  succ : A → A
  run : Term → A → A → A
  run_zero : ∀ h a, run h zero a = a
  run_succ : ∀ h n a,
    run h (succ n) a = evaluate zero succ run h n (run h n a)

def value {A : Type u} (C : Model A) (t : Term) (x y : A) : A :=
  evaluate C.zero C.succ C.run t x y

variable {A : Type u} (C : Model A)

theorem value_substitute (t x y : Term) (n a : A) :
    value C (substitute t x y) n a =
      value C t (value C x n a) (value C y n a) := by
  induction t with
  | first => rfl
  | second => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | iter h n' a' _ ihn iha =>
      change C.run h (value C (substitute n' x y) n a)
          (value C (substitute a' x y) n a) =
        C.run h (value C n' (value C x n a) (value C y n a))
          (value C a' (value C x n a) (value C y n a))
      exact congr (congrArg (C.run h) ihn) iha

def oneTerm : Term := .succ .zero
def predTerm (t : Term) : Term := .iter .first t .zero
def addTerm (s t : Term) : Term := .iter (.succ .second) s t
def gateTerm (s t : Term) : Term := .iter .zero s t
def monusTerm (s t : Term) : Term := .iter (predTerm .second) s t

def one : A := C.succ C.zero
def pred (x : A) : A := C.run .first x C.zero
def add (x y : A) : A := C.run (.succ .second) x y
def gate (x y : A) : A := C.run .zero x y
def monus (x y : A) : A := C.run (predTerm .second) x y

theorem pred_zero : pred C C.zero = C.zero := C.run_zero _ _
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.run_succ _ _ _
theorem add_zero (x : A) : add C C.zero x = x := C.run_zero _ _
theorem add_succ (x y : A) : add C (C.succ x) y = C.succ (add C x y) :=
  C.run_succ _ _ _
theorem gate_zero (x : A) : gate C C.zero x = x := C.run_zero _ _
theorem gate_succ (x y : A) : gate C (C.succ x) y = C.zero := C.run_succ _ _ _
theorem monus_zero (x : A) : monus C C.zero x = x := C.run_zero _ _
theorem monus_succ (x y : A) : monus C (C.succ x) y = pred C (monus C x y) :=
  C.run_succ _ _ _

def distanceTerm (x y : Term) : Term := addTerm (monusTerm x y) (monusTerm y x)
def distance (x y : A) : A := add C (monus C x y) (monus C y x)

/-- One unrestricted finite term, one fixed numerical parameter. -/
def PositiveConstancy : Prop :=
  ∀ t : Term, ∀ a : A,
    (∀ n, value C t (C.succ (C.succ n)) a = value C t (C.succ n) a) →
    ∀ n, n = C.zero ∨ value C t n a = value C t (one C) a

/-- A single fixed sentence, using the actual distance program above. -/
def EqualityRecognition : Prop :=
  ∀ x y : A, x = y ↔ gate C (distance C x y) (one C) ≠ C.zero

variable (PC : PositiveConstancy C) (ER : EqualityRecognition C)
include PC ER

omit PC in
theorem separation : C.zero ≠ C.succ C.zero := by
  have h := (ER C.zero C.zero).mp rfl
  unfold distance at h
  rw [monus_zero C, add_zero C, gate_zero C] at h
  intro bad
  exact h bad.symm

omit PC ER in
theorem successor_injective {x y : A} (h : C.succ x = C.succ y) : x = y := by
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_succ C] at e
  exact e

omit PC in
theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro h
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_zero C] at e
  have bad : C.succ C.zero = C.zero := (congrArg C.succ e).symm.trans h
  exact separation C ER bad.symm

omit ER in
/-- The first PC instance obtains a gate law before constructor coverage. -/
theorem zero_or_gate (a x : A) : x = C.zero ∨ gate C x a = C.zero := by
  have q := PC (gateTerm .first .second) a (by
    intro n
    change gate C (C.succ (C.succ n)) a = gate C (C.succ n) a
    rw [gate_succ C, gate_succ C]) x
  rcases q with h | h
  · exact Or.inl h
  · change gate C x a = gate C (C.succ C.zero) a at h
    rw [gate_succ C] at h
    exact Or.inr h

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases zero_or_gate C PC (one C) x with h | h
  · exact Or.inl h
  · apply Or.inr
    intro bad
    rw [bad, gate_zero C] at h
    exact separation C ER h.symm

omit ER in
theorem gate_nonzero {x : A} (hx : x ≠ C.zero) (y : A) : gate C x y = C.zero := by
  rcases zero_or_gate C PC y x with h | h
  · exact False.elim (hx h)
  · exact h

theorem gate_nonzero_iff (x : A) : gate C x (one C) ≠ C.zero ↔ x = C.zero := by
  constructor
  · intro h
    rcases zero_or_gate C PC (one C) x with hx | hx
    · exact hx
    · exact False.elim (h hx)
  · intro h bad
    rw [h, gate_zero C] at bad
    exact separation C ER bad.symm

theorem equality_reflection (x y : A) : distance C x y = C.zero ↔ x = y := by
  exact ((ER x y).trans (gate_nonzero_iff C PC ER (distance C x y))).symm

theorem equality_decision (x y : A) : x = y ∨ x ≠ y := by
  rcases zero_decision C PC ER (distance C x y) with h | h
  · exact Or.inl ((equality_reflection C PC ER x y).mp h)
  · exact Or.inr (fun q => h ((equality_reflection C PC ER x y).mpr q))

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  let t := distanceTerm .first (.succ (predTerm .first))
  have at_succ (n : A) : value C t (C.succ n) C.zero = C.zero := by
    change distance C (C.succ n) (C.succ (pred C (C.succ n))) = C.zero
    rw [pred_succ C]
    exact (equality_reflection C PC ER _ _).mpr rfl
  have q := PC t C.zero (by
    intro n
    exact (at_succ (C.succ n)).trans (at_succ n).symm) x
  rcases q with h | h
  · exact Or.inl h
  · have r := h.trans (at_succ C.zero)
    exact Or.inr ((equality_reflection C PC ER _ _).mp r)

/-- Ordinary term constancy is obtained by one predecessor delay. -/
theorem ordinary_constancy (t : Term) (a : A)
    (step : ∀ n, value C t (C.succ n) a = value C t n a) :
    ∀ n, value C t n a = value C t C.zero a := by
  let delayed := substitute t (predTerm .first) .second
  have delay (x : A) : value C delayed x a = value C t (pred C x) a := by
    exact value_substitute C t (predTerm .first) .second x a
  have positive := PC delayed a (by
    intro n
    rw [delay, delay, pred_succ C, pred_succ C]
    exact step n)
  intro n
  rcases positive (C.succ n) with hz | he
  · exact False.elim (successor_ne_zero C ER n hz)
  · rw [delay, delay, pred_succ C] at he
    change value C t n a = value C t (pred C (C.succ C.zero)) a at he
    rw [pred_succ C] at he
    exact he

def Bit (x : A) : Prop := x = C.zero ∨ x = one C

theorem gate_is_bit (x : A) : Bit C (gate C x (one C)) := by
  rcases zero_decision C PC ER x with h | h
  · exact Or.inr (by rw [h, gate_zero C])
  · exact Or.inl (gate_nonzero C PC h _)

def equalBitTerm (s t : Term) : Term := gateTerm (distanceTerm s t) oneTerm
def equalBit (x y : A) : A := gate C (distance C x y) (one C)

theorem equalBit_is_bit (x y : A) : Bit C (equalBit C x y) :=
  gate_is_bit C PC ER _

theorem equalBit_one_iff (x y : A) : equalBit C x y = one C ↔ x = y := by
  constructor
  · intro h
    apply (ER x y).mpr
    change equalBit C x y ≠ C.zero
    intro bad
    exact separation C ER (bad.symm.trans h)
  · intro h
    rcases equalBit_is_bit C PC ER x y with hz | ho
    · exact False.elim ((ER x y).mp h hz)
    · exact ho

theorem equalBit_invariance (x y z w : A) (h : x = y ↔ z = w) :
    equalBit C x y = equalBit C z w := by
  rcases equalBit_is_bit C PC ER x y with hx | hx
  · rcases equalBit_is_bit C PC ER z w with hz | hz
    · exact hx.trans hz.symm
    · have eqxy := h.mpr ((equalBit_one_iff C PC ER z w).mp hz)
      have hx1 := (equalBit_one_iff C PC ER x y).mpr eqxy
      exact False.elim (separation C ER (hx.symm.trans hx1))
  · have eqzw := h.mp ((equalBit_one_iff C PC ER x y).mp hx)
    exact hx.trans ((equalBit_one_iff C PC ER z w).mpr eqzw).symm

/-- Successor uniqueness is derived, not included in the arithmetic schema. -/
theorem successor_solutions_equal (t u : Term) (a : A)
    (base : value C t C.zero a = value C u C.zero a)
    (stept : ∀ n, value C t (C.succ n) a = C.succ (value C t n a))
    (stepu : ∀ n, value C u (C.succ n) a = C.succ (value C u n a)) :
    ∀ n, value C t n a = value C u n a := by
  let monitor := equalBitTerm t u
  have invariant (n : A) : value C monitor (C.succ n) a = value C monitor n a := by
    change equalBit C (value C t (C.succ n) a) (value C u (C.succ n) a) =
      equalBit C (value C t n a) (value C u n a)
    apply equalBit_invariance C PC ER
    rw [stept, stepu]
    exact ⟨successor_injective C, congrArg C.succ⟩
  have q := ordinary_constancy C PC ER monitor a invariant
  intro n
  have qn := q n
  change equalBit C (value C t n a) (value C u n a) =
    equalBit C (value C t C.zero a) (value C u C.zero a) at qn
  have b := (equalBit_one_iff C PC ER _ _).mpr base
  exact (equalBit_one_iff C PC ER _ _).mp (qn.trans b)


/-- Selector obtained from the initialized predecessor, without arithmetic laws. -/
def selectTerm (z x y : Term) : Term := .iter .first (gateTerm z (.succ x)) y

def select (z x y : A) : A := C.run .first (gate C z (C.succ x)) y

omit PC ER in
theorem select_zero (x y : A) : select C C.zero x y = x := by
  unfold select
  rw [gate_zero C]
  exact C.run_succ .first x y

omit PC ER in
theorem select_succ (z x y : A) : select C (C.succ z) x y = y := by
  unfold select
  rw [gate_succ C]
  exact C.run_zero .first y

omit ER in
theorem select_nonzero {z : A} (hz : z ≠ C.zero) (x y : A) :
    select C z x y = y := by
  unfold select
  rw [gate_nonzero C PC hz]
  exact C.run_zero .first y

theorem select_same (z x : A) : select C z x x = x := by
  rcases zero_decision C PC ER z with h | h
  · rw [h, select_zero C]
  · exact select_nonzero C PC h x x

omit PC ER in
theorem value_select (z x y : Term) (n a : A) :
    value C (selectTerm z x y) n a =
      select C (value C z n a) (value C x n a) (value C y n a) := rfl

def parityUpdate : Term := gateTerm .second oneTerm
def parityTerm (t : Term) : Term := .iter parityUpdate t .zero
def halfUpdate : Term := selectTerm (parityTerm .first) .second (.succ .second)
def halfTerm (t : Term) : Term := .iter halfUpdate t .zero
def doubleTerm (t : Term) : Term := .iter (.succ (.succ .second)) t .zero

def parity (x : A) : A := C.run parityUpdate x C.zero
def half (x : A) : A := C.run halfUpdate x C.zero
def double (x : A) : A := C.run (.succ (.succ .second)) x C.zero

omit PC ER in
theorem parity_zero : parity C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem parity_succ (x : A) : parity C (C.succ x) = gate C (parity C x) (one C) :=
  C.run_succ _ _ _
omit PC ER in
theorem half_zero : half C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem half_succ (x : A) : half C (C.succ x) =
    select C (parity C x) (half C x) (C.succ (half C x)) := C.run_succ _ _ _
omit PC ER in
theorem double_zero : double C C.zero = C.zero := C.run_zero _ _
omit PC ER in
theorem double_succ (x : A) : double C (C.succ x) =
    C.succ (C.succ (double C x)) := C.run_succ _ _ _
theorem parity_is_bit (x : A) : Bit C (parity C x) := by
  rcases coverage C PC ER x with h | h
  · exact Or.inl (by rw [h, parity_zero C])
  · rw [h, parity_succ C]
    exact gate_is_bit C PC ER _

theorem parity_twice (x : A) : parity C (C.succ (C.succ x)) = parity C x := by
  rw [parity_succ C, parity_succ C]
  rcases parity_is_bit C PC ER x with h | h
  · rw [h, gate_zero C]
    exact gate_succ C C.zero (one C)
  · rw [h]
    change gate C (gate C (C.succ C.zero) (one C)) (one C) = one C
    rw [gate_succ C, gate_zero C]

theorem half_twice (x : A) : half C (C.succ (C.succ x)) = C.succ (half C x) := by
  rw [half_succ C, half_succ C, parity_succ C]
  rcases parity_is_bit C PC ER x with h | h
  · rw [h, gate_zero C, select_zero C]
    exact select_succ C C.zero (half C x) (C.succ (half C x))
  · rw [h]
    change select C (gate C (C.succ C.zero) (one C))
      (select C (C.succ C.zero) (half C x) (C.succ (half C x)))
      (C.succ (select C (C.succ C.zero) (half C x) (C.succ (half C x)))) =
      C.succ (half C x)
    rw [gate_succ C, select_succ C, select_zero C]


/-- This proof uses only the derived term-constancy principle. -/
theorem parity_double (x : A) : parity C (double C x) = C.zero := by
  let t := parityTerm (doubleTerm .first)
  have step (n : A) : value C t (C.succ n) C.zero = value C t n C.zero := by
    change parity C (double C (C.succ n)) = parity C (double C n)
    rw [double_succ C, parity_twice C PC ER]
  have q := ordinary_constancy C PC ER t C.zero step x
  change parity C (double C x) = parity C (double C C.zero) at q
  rw [double_zero C, parity_zero C] at q
  exact q

/-- Successor comparison was proved with a Boolean equality monitor. -/
theorem half_double (x : A) : half C (double C x) = x := by
  let t := halfTerm (doubleTerm .first)
  have base : value C t C.zero C.zero = value C .first C.zero C.zero := by
    change half C (double C C.zero) = C.zero
    rw [double_zero C, half_zero C]
  have step (n : A) : value C t (C.succ n) C.zero = C.succ (value C t n C.zero) := by
    change half C (double C (C.succ n)) = C.succ (half C (double C n))
    rw [double_succ C, half_twice C PC ER]
  exact successor_solutions_equal C PC ER t .first C.zero base step (fun _ => rfl) x
theorem parity_odd (x : A) : parity C (C.succ (double C x)) = one C := by
  rw [parity_succ C, parity_double C PC ER, gate_zero C]

theorem half_odd (x : A) : half C (C.succ (double C x)) = x := by
  rw [half_succ C, parity_double C PC ER, select_zero C, half_double C PC ER]

def encodeTerm (a b : Term) : Term := selectTerm b (doubleTerm a) (.succ (doubleTerm a))
def encode (a b : A) : A := select C b (double C a) (C.succ (double C a))

omit PC ER in
theorem encode_zero (a : A) : encode C a C.zero = double C a :=
  select_zero C _ _

omit PC ER in
theorem encode_one (a : A) : encode C a (one C) = C.succ (double C a) :=
  select_succ C C.zero _ _

theorem half_encode (a b : A) : half C (encode C a b) = a := by
  rcases coverage C PC ER b with h | h
  · rw [h, encode_zero C, half_double C PC ER]
  · unfold encode
    rw [h, select_succ C, half_odd C PC ER]

theorem parity_encode (a b : A) (hb : Bit C b) : parity C (encode C a b) = b := by
  rcases hb with h | h
  · rw [h, encode_zero C, parity_double C PC ER]
  · rw [h, encode_one C, parity_odd C PC ER]

def indicatorTerm (t : Term) : Term := selectTerm t .zero oneTerm
def indicator (x : A) : A := select C x C.zero (one C)

omit PC ER in
theorem indicator_zero : indicator C C.zero = C.zero := select_zero C _ _
omit ER in
theorem indicator_nonzero {x : A} (hx : x ≠ C.zero) : indicator C x = one C :=
  select_nonzero C PC hx _ _

theorem indicator_is_bit (x : A) : Bit C (indicator C x) := by
  rcases zero_decision C PC ER x with h | h
  · exact Or.inl (by rw [h, indicator_zero C])
  · exact Or.inr (indicator_nonzero C PC h)

theorem indicator_reflects (x : A) (hx : indicator C x = C.zero) : x = C.zero := by
  rcases zero_decision C PC ER x with h | h
  · exact h
  · rw [indicator_nonzero C PC h] at hx
    exact False.elim (separation C ER hx.symm)

omit PC ER in
theorem value_encode (a b : Term) (n p : A) :
    value C (encodeTerm a b) n p = encode C (value C a n p) (value C b n p) := rfl

omit PC ER in
theorem value_indicator (t : Term) (n a : A) :
    value C (indicatorTerm t) n a = indicator C (value C t n a) := rfl


/-- This target-dependent update belongs only to the computation grammar. -/
def latchUpdate (t : Term) : Term :=
  encodeTerm (halfTerm .second)
    (selectTerm (parityTerm .second)
      (indicatorTerm (substitute t (.succ .first) (halfTerm .second))) oneTerm)

def latchStateTerm (t : Term) : Term :=
  .iter (latchUpdate t) .first
    (encodeTerm .second (indicatorTerm (substitute t .zero .second)))

def latchTerm (t : Term) : Term := parityTerm (latchStateTerm t)

def latchState (t : Term) (n a : A) : A :=
  C.run (latchUpdate t) n (encode C a (indicator C (value C t C.zero a)))

def latch (t : Term) (n a : A) : A := parity C (latchState C t n a)

omit PC ER in
theorem value_latchUpdate (t : Term) (n v : A) :
    value C (latchUpdate t) n v =
      encode C (half C v)
        (select C (parity C v)
          (indicator C (value C t (C.succ n) (half C v))) (one C)) := by
  unfold latchUpdate
  rw [value_encode C, value_select C, value_indicator C, value_substitute C]
  rfl

omit PC ER in
theorem value_latchState (t : Term) (n a : A) :
    value C (latchStateTerm t) n a = latchState C t n a := by
  change C.run (latchUpdate t) n
    (value C (encodeTerm .second (indicatorTerm (substitute t .zero .second))) n a) = _
  rw [value_encode C, value_indicator C, value_substitute C]
  rfl

omit PC ER in
theorem value_latch (t : Term) (n a : A) :
    value C (latchTerm t) n a = latch C t n a := by
  change parity C (value C (latchStateTerm t) n a) = _
  rw [value_latchState C]
  rfl

omit PC ER in
theorem latchState_zero (t : Term) (a : A) :
    latchState C t C.zero a = encode C a (indicator C (value C t C.zero a)) :=
  C.run_zero _ _

omit PC ER in
theorem latchState_succ (t : Term) (n a : A) :
    latchState C t (C.succ n) a =
      encode C (half C (latchState C t n a))
        (select C (parity C (latchState C t n a))
          (indicator C (value C t (C.succ n) (half C (latchState C t n a))))
          (one C)) := by
  have q := C.run_succ (latchUpdate t) n
    (encode C a (indicator C (value C t C.zero a)))
  change latchState C t (C.succ n) a =
    value C (latchUpdate t) n (latchState C t n a) at q
  rw [value_latchUpdate C] at q
  exact q


/-- Parameter preservation invokes only the derived term-constancy principle. -/
theorem stored_parameter (t : Term) (n a : A) :
    half C (latchState C t n a) = a := by
  let f := halfTerm (latchStateTerm t)
  have vf (x : A) : value C f x a = half C (latchState C t x a) := by
    change half C (value C (latchStateTerm t) x a) = _
    rw [value_latchState C]
  have step (x : A) : value C f (C.succ x) a = value C f x a := by
    rw [vf, vf, latchState_succ C, half_encode C PC ER]
  have q := ordinary_constancy C PC ER f a step n
  rw [vf, vf, latchState_zero C, half_encode C PC ER] at q
  exact q
omit PC ER in
theorem bit_or (x y : A) (hx : Bit C x) (hy : Bit C y) :
    Bit C (select C x y (one C)) := by
  rcases hx with hx | hx
  · rw [hx, select_zero C]
    exact hy
  · rw [hx]
    change Bit C (select C (C.succ C.zero) y (one C))
    rw [select_succ C]
    exact Or.inr rfl

theorem bit_or_zero_right (x y : A)
    (h : select C x y (one C) = C.zero) : y = C.zero := by
  rcases zero_decision C PC ER x with hx | hx
  · rw [hx, select_zero C] at h
    exact h
  · rw [select_nonzero C PC hx] at h
    exact False.elim (separation C ER h.symm)

theorem latch_is_bit (t : Term) (n a : A) : Bit C (latch C t n a) :=
  parity_is_bit C PC ER _

theorem latch_zero (t : Term) (a : A) :
    latch C t C.zero a = indicator C (value C t C.zero a) := by
  unfold latch
  rw [latchState_zero C, parity_encode C PC ER _ _ (indicator_is_bit C PC ER _)]

theorem latch_succ (t : Term) (n a : A) :
    latch C t (C.succ n) a =
      select C (latch C t n a)
        (indicator C (value C t (C.succ n) a)) (one C) := by
  unfold latch
  rw [latchState_succ C]
  rw [parity_encode C PC ER _ _ (bit_or C _ _
    (parity_is_bit C PC ER _) (indicator_is_bit C PC ER _))]
  rw [stored_parameter C PC ER]

/-- The current factor is present in the latch by constructor coverage alone. -/
theorem latch_reflects (t : Term) (n a : A)
    (hn : latch C t n a = C.zero) : value C t n a = C.zero := by
  rcases coverage C PC ER n with hz | hs
  · rw [hz, latch_zero C PC ER] at hn
    rw [hz]
    exact indicator_reflects C PC ER _ hn
  · rw [hs, latch_succ C PC ER] at hn
    have hb := bit_or_zero_right C PC ER _ _ hn
    rw [hs]
    exact indicator_reflects C PC ER _ hb


/-- Contextual zero induction from positive constancy and the fixed ER sentence. -/
theorem zero_induction (t : Term) (a : A)
    (base : value C t C.zero a = C.zero)
    (step : ∀ n, value C t n a = C.zero → value C t (C.succ n) a = C.zero) :
    ∀ n, value C t n a = C.zero := by
  have constant (n : A) : latch C t (C.succ n) a = latch C t n a := by
    rcases latch_is_bit C PC ER t n a with hz | ho
    · have next := step n (latch_reflects C PC ER t n a hz)
      rw [latch_succ C PC ER, hz, next, indicator_zero C, select_zero C]
    · rw [latch_succ C PC ER, ho]
      exact select_succ C C.zero _ _
  have term_step (n : A) : value C (latchTerm t) (C.succ n) a =
      value C (latchTerm t) n a := by
    rw [value_latch C, value_latch C]
    exact constant n
  have trace := ordinary_constancy C PC ER (latchTerm t) a term_step
  intro n
  have q := trace n
  rw [value_latch C, value_latch C, latch_zero C PC ER, base, indicator_zero C] at q
  exact latch_reflects C PC ER t n a q
/-- Actual finite quantifier-free syntax with two free numerical slots. -/
inductive Formula where
  | equal (left right : Term)
  | falsehood
  | conj (left right : Formula)
  | disj (left right : Formula)
  | impl (left right : Formula)

def holds : Formula → A → A → Prop
  | .equal s t, n, a => value C s n a = value C t n a
  | .falsehood, _, _ => False
  | .conj P Q, n, a => holds P n a ∧ holds Q n a
  | .disj P Q, n, a => holds P n a ∨ holds Q n a
  | .impl P Q, n, a => holds P n a → holds Q n a

def errorTerm : Formula → Term
  | .equal s t => addTerm (monusTerm s t) (monusTerm t s)
  | .falsehood => oneTerm
  | .conj P Q => selectTerm (errorTerm P) (errorTerm Q) oneTerm
  | .disj P Q => selectTerm (errorTerm P) .zero (errorTerm Q)
  | .impl P Q => selectTerm (errorTerm P) (errorTerm Q) .zero

/-- Constructive compilation, including material implication on decided atoms. -/
theorem error_correct (P : Formula) (n a : A) :
    value C (errorTerm P) n a = C.zero ↔ holds C P n a := by
  induction P with
  | equal s t =>
      exact equality_reflection C PC ER (value C s n a) (value C t n a)
  | falsehood =>
      change one C = C.zero ↔ False
      constructor
      · intro h
        exact separation C ER h.symm
      · intro h
        exact False.elim h
  | conj P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) (value C (errorTerm Q) n a)
        (one C) = C.zero ↔ holds C P n a ∧ holds C Q n a
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro hq
          exact ⟨ihP.mp hp, ihQ.mp hq⟩
        · intro h
          exact ihQ.mpr h.2
      · rw [select_nonzero C PC hp]
        constructor
        · intro h
          exact False.elim (separation C ER h.symm)
        · intro h
          exact False.elim (hp (ihP.mpr h.1))
  | disj P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) C.zero
        (value C (errorTerm Q) n a) = C.zero ↔ holds C P n a ∨ holds C Q n a
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro _
          exact Or.inl (ihP.mp hp)
        · intro _
          rfl
      · rw [select_nonzero C PC hp]
        constructor
        · intro hq
          exact Or.inr (ihQ.mp hq)
        · intro h
          rcases h with h | h
          · exact False.elim (hp (ihP.mpr h))
          · exact ihQ.mpr h
  | impl P Q ihP ihQ =>
      change select C (value C (errorTerm P) n a) (value C (errorTerm Q) n a)
        C.zero = C.zero ↔ (holds C P n a → holds C Q n a)
      rcases zero_decision C PC ER (value C (errorTerm P) n a) with hp | hp
      · rw [hp, select_zero C]
        constructor
        · intro hq _
          exact ihQ.mp hq
        · intro h
          exact ihQ.mpr (h (ihP.mp hp))
      · rw [select_nonzero C PC hp]
        constructor
        · intro _ h
          exact False.elim (hp (ihP.mpr h))
        · intro _
          rfl

theorem quantifier_free_decision (P : Formula) (n a : A) :
    holds C P n a ∨ ¬ holds C P n a := by
  rcases zero_decision C PC ER (value C (errorTerm P) n a) with h | h
  · exact Or.inl ((error_correct C PC ER P n a).mp h)
  · exact Or.inr (fun q => h ((error_correct C PC ER P n a).mpr q))

/-- The linked finite-syntax endpoint: full quantifier-free induction,
    with one arbitrary fixed numerical parameter, from PC and the fixed ER sentence. -/
theorem quantifier_free_induction (P : Formula) (a : A)
    (base : holds C P C.zero a)
    (step : ∀ n, holds C P n a → holds C P (C.succ n) a) :
    ∀ n, holds C P n a := by
  have ezero := (error_correct C PC ER P C.zero a).mpr base
  have estep (n : A) (h : value C (errorTerm P) n a = C.zero) :
      value C (errorTerm P) (C.succ n) a = C.zero := by
    apply (error_correct C PC ER P (C.succ n) a).mpr
    exact step n ((error_correct C PC ER P n a).mp h)
  have eind := zero_induction C PC ER (errorTerm P) a ezero estep
  intro n
  exact (error_correct C PC ER P n a).mp (eind n)


#print axioms value_substitute
#print axioms separation
#print axioms successor_injective
#print axioms successor_ne_zero
#print axioms zero_or_gate
#print axioms zero_decision
#print axioms gate_nonzero_iff
#print axioms equality_reflection
#print axioms equality_decision
#print axioms coverage
#print axioms ordinary_constancy
#print axioms equalBit_invariance
#print axioms successor_solutions_equal
#print axioms parity_double
#print axioms half_double
#print axioms half_encode
#print axioms parity_encode
#print axioms stored_parameter
#print axioms latch_reflects
#print axioms zero_induction
#print axioms error_correct
#print axioms quantifier_free_decision
#print axioms quantifier_free_induction

end PositiveConstancy
