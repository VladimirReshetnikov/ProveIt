PRA FROM POSITIVE CONSTANCY
Research archive prepared for Vladimir Reshetnikov, 31 October 2026
==================================================================

START HERE

pra_positive_constancy.pdf    Main report: one positive-constancy term
                             schema plus one fixed equality-test law.
pra_positive_constancy.tex    Complete LaTeX source for the main report.
axioms.txt                   Exact standalone specification.

alternative/pra_fixed_updates.pdf
alternative/pra_fixed_updates.tex
                             Companion: three fixed recurrence updates
                             plus one maximum equation; also a strict
                             four-update subfamily of the prior PU basis.

MAIN RESULT

In the same binary initialized-iterator language used by the strongest
inspected draft, D + PC + ER is conservatively definitionally equivalent
to ordinary PRA, separately over classical and intuitionistic equality
logic. Every arithmetic instance has only one fixed numerical parameter.

The repeating PC schema has 26 expanded formula-tree nodes, versus 39 for
the prior binary PU schema, and uses one arbitrary term instead of a term
plus an arbitrary update program.

There is an explicit extra cost: ER is one fixed equality-test sentence.
It has 39 nodes with iff expanded, or 20 with primitive iff. The combined
arithmetic display is therefore not claimed to be shorter in total nodes.
There is no absolute minimality, finite-signature, or finite-axiom claim.

The new proof derives successor uniqueness through a Boolean equality
monitor, then obtains induction using a cumulative error program and
ordinary constancy. The target-dependent program appears only in a
computation definition, never in a new arithmetic schema.

FILES

formal/PositiveConstancy.lean  Finite-syntax constructive certificate of
                              the main basis through one-parameter QFI.
formal/PositiveConstancy.log   Clean Lean 4.19.0 output; 23 empty global-
                              axiom dependency audits.
formal/FourUpdates.lean       Companion certificate through the same
                              endpoint for three fixed updates plus Max.
formal/FourUpdates.log        Clean output; 39 empty dependency audits.
formal/README.txt             Exact scope of both certificates.
formal/FourUpdates_README.txt  Additional companion-specific scope.

artifacts/schema_metrics.py   Reproducible exact formula-tree counts.
artifacts/schema_metrics.json Recorded metric results.
source_audit.json             Immutable source URLs, snapshot, hashes,
                              and review scope.
VALIDATION.txt                Build and verification summary.
build.sh                      Build both reports with latexmk.
check.sh                      Re-run Lean certificates and formula counts.
lean-toolchain                leanprover/lean4:v4.19.0.
SHA256SUMS                    Checksums of delivered files.

BUILD

Run from the archive root:
  bash build.sh

Requires a normal TeX installation with latexmk, pdfLaTeX, and the packages
listed at the start of each source. No network access is needed once the
TeX distribution is installed.

VERIFY

With Lean 4.19.0 on PATH:
  bash check.sh

Or set the task-specific executable variable:
  PRA_LEAN_BIN=/absolute/path/to/lean bash check.sh

The certificates have no imports and require no external Lean packages.
The metrics script uses only Python's standard library.

VERIFICATION BOUNDARY

The certificates use an arbitrary carrier and actual finite Term and
Formula syntax. They do not use induction on the arithmetic carrier,
unrestricted arithmetic function variables, classical choice, sorry
placeholders, or extra global axioms. The displayed mathematical basis
remains explicit theorem hypotheses.

The complete first-order proof-calculus translation, triangular pairing,
arbitrary finite parameter tuples, source recursion compiler, converse,
and conservative definitional-equivalence endpoint are written proofs.
The companion's derivation of Max from the fourth update is also written,
rather than claimed as a linked machine-checked endpoint.

SOURCE COMPARISON

Repository snapshot:
  b0350fd1c96d8273ca9c3b5ce025782b748cded7

All six docs/drafts archives were reviewed. Their bytes were verified by
Git blob hashes. docs/incoming inventory and its README were inspected;
no PRA-labelled entry was found. Unrelated incoming archives were not
unpacked. The repository was used read-only.

The reports credit the supplied drafts' binary language, positive guard,
selector, bit coding, and triangular pairing. The reduction to positive
constancy plus the fixed ER law and its linked certificate are the primary
new deliverables. No exhaustive historical-priority claim is made.

