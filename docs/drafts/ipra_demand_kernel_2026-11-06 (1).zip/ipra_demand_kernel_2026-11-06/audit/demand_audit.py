"""Independent scope and certificate-reconstruction audit of the candidate.

This is not trusted by either acceptance program. It uses an explicit grammar
and binding traversal, independently of their SCOPES/subst implementation.
"""

from copy import deepcopy
from pathlib import Path
import hashlib
import argparse
import importlib.util
import json
import random
import sys

HERE = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj




def term(t):
    if type(t) is int:
        return t >= -1
    if type(t) is not list or not t:
        return False
    if t[0] == "s" and len(t) == 2:
        return term(t[1])
    if t[0] == "r" and len(t) == 4:
        return all(term(a) for a in t[1:])
    return False


def formula(a):
    if type(a) is not list or not a:
        return False
    if a[0] == "=" and len(a) == 3:
        return term(a[1]) and term(a[2])
    if a[0] == "pi" and len(a) == 3:
        return formula(a[1]) and formula(a[2])
    if a[0] == "ex" and len(a) == 2:
        return formula(a[1])
    return False


def transform(t, variable_action, depth=0):
    """A scope traversal using explicit, independently written constructor cases."""
    if type(t) is int:
        return t if t == -1 else variable_action(t, depth)
    if t[0] == "s":
        return ["s", transform(t[1], variable_action, depth)]
    if t[0] == "r":
        return ["r", transform(t[1], variable_action, depth),
                transform(t[2], variable_action, depth),
                transform(t[3], variable_action, depth + 2)]
    if t[0] == "=":
        return ["=", transform(t[1], variable_action, depth),
                transform(t[2], variable_action, depth)]
    if t[0] == "pi":
        return ["pi", transform(t[1], variable_action, depth + 1),
                transform(t[2], variable_action, depth + 1)]
    if t[0] == "ex":
        return ["ex", transform(t[1], variable_action, depth + 1)]
    raise ValueError("unknown constructor in independent traversal")


def lift(t, amount=1):
    return transform(t, lambda i, d: i if i < d else i + amount)


def instantiate(t, witness):
    assert term(witness)
    return transform(t, lambda i, d: i if i < d else
                     lift(witness, d) if i == d else i - 1)


def occurs(t):
    found = []
    transform(t, lambda i, d: found.append(i == d) or i)
    return any(found)


def accepted(checker, data):
    try:
        return checker.check(deepcopy(data)) is True
    except Exception:
        return False


def reconstruct(p, g):
    """Reconstruct an accepted candidate proof in the strict frozen baseline.

    Inferred major formulas come from the strict baseline, not from candidate
    infer. The contexts use the independent lifting routine above.
    """
    if type(p) is list and len(p) == 3 and p[0] in ("lam", "pack"):
        tag, a, q = p
        h = a if tag == "lam" else ["=", 0, lift(a)]
        return [tag, a, reconstruct(q, [*(lift(b) for b in g), h])]
    if type(p) is list and len(p) >= 2 and p[0] == "use":
        major = reconstruct(p[1], g)
        f = baseline.infer(major, g)
        if f[0] == "ex":
            assert len(p) == 3
            return ["use", major, reconstruct(p[2], [*(lift(b) for b in g), f[1]])]
        assert len(p) == 4
        parameter = p[2]
        if f[0] == "pi" and not (occurs(f[1]) or occurs(f[2])):
            parameter = -1
        return ["use", major, parameter, reconstruct(p[3], g)]
    if type(p) is list and len(p) == 4 and p[0] == "r":
        return p
    if type(p) is list and len(p) == 3 and p[0] == "nat":
        return ["nat", p[1], reconstruct(p[2], g)]
    return g[p]


def replay(data):
    a, p, *g = data
    return baseline.check([g, a, reconstruct(p, g)])


def ensure(data, expected, label, replay_valid=True):
    got = accepted(candidate, data)
    if got != expected:
        raise AssertionError((label, expected, got, data))
    if got and replay_valid:
        assert replay(deepcopy(data)), label
    return int(got)


def main():
    global candidate, baseline
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, default=HERE.parent / "checker.py")
    parser.add_argument("--baseline", type=Path, default=HERE.parent / "baseline.py")
    parser.add_argument("--examples", type=Path, default=HERE.parent / "examples")
    parser.add_argument("--output", type=Path, default=HERE / "results.json")
    args = parser.parse_args()
    candidate_path = args.candidate.resolve()
    baseline_path = args.baseline.resolve()
    candidate_hash = hashlib.sha256(candidate_path.read_bytes()).hexdigest()
    baseline_hash = hashlib.sha256(baseline_path.read_bytes()).hexdigest()
    candidate = module("demand_candidate", candidate_path)
    baseline = module("demand_baseline", baseline_path)
    counts = {}
    truth = ["=", -1, -1]
    false = ["=", -1, ["s", -1]]
    bad = [None, False, True, -2, -3, 0.0, -1.0, 1.5, "", "x", "s",
           "s-1", {}, {"s": -1}, {"r": [-1, -1, -1]}, [], [0], ["s"],
           ["s", -1, -1], ["r", -1, -1], ["r", -1, -1, -1, -1],
           ["s", False], ["s", 0.0], ["s", -2], ["r", -1, -1, True],
           ["r", -1, -1, ["s", -2]], ["unknown", -1], ["ex", truth],
           ["pi", truth, truth], truth, ["=", False, -1]]
    good = [-1, 0, 1, 7, ["s", -1], ["s", 0], ["r", 0, 1, 0],
            ["r", -1, 0, 1], ["r", 1, ["s", 0], ["r", 2, 3, 4]]]
    assert all(term(t) for t in good)
    assert all(not term(t) for t in bad)
    matrices = [truth, false, ["=", 0, 0], ["=", 0, -1], ["=", 1, 1],
                ["=", ["s", 0], ["s", 0]],
                ["ex", ["=", 0, 0]],
                ["ex", ["=", 1, 1]],
                ["ex", ["=", 2, 2]],
                ["pi", ["=", 0, 0], truth],
                ["pi", truth, ["=", 1, 1]],
                ["pi", ["=", 1, 1], ["ex", ["=", 2, 2]]],
                ["=", ["r", -1, -1, 0], ["r", -1, -1, 1]],
                ["=", ["r", -1, -1, 2], ["r", -1, -1, 2]],
                ["=", ["r", -1, -1, 3], ["r", -1, -1, 3]],
                ["ex", ["=", ["r", -1, -1, 2], 0]],
                ["ex", ["=", ["r", -1, -1, 3], 1]],
                ["ex", ["=", ["r", -1, -1, 4], 2]]]
    assert all(formula(a) for a in matrices)

    tested = accepted_count = 0
    for a in matrices:
        for b in matrices:
            for witness in good + bad:
                canonical = witness if term(witness) else -1
                guard = instantiate(a, canonical)
                goal = instantiate(b, canonical)
                data = [goal, ["use", 0, witness, 1], ["pi", a, b], guard]
                expected = term(witness) or not (occurs(a) or occurs(b))
                accepted_count += ensure(data, expected, "universal witness")
                tested += 1
    counts["universal_scope_grid"] = {"tested": tested, "accepted_and_replayed": accepted_count}

    tested = accepted_count = 0
    for payload in bad + good:
        for shift in range(7):
            try:
                candidate.subst(payload, (shift,), formula=False)
                success = True
            except Exception:
                success = False
            assert success == term(payload), (payload, shift)
            tested += 1
            accepted_count += success
    counts["lift_success_iff_wellformed_term"] = {"tested": tested, "accepted": accepted_count}

    tested = accepted_count = 0
    for p in [0, -1, False, True, 1, -2, 2, -3, 0.0, -1.0, "0", None, {}, [], ["bad"]]:
        data = [truth, p, truth]
        expected = type(p) in (int, bool) and int(p) in (0, -1)
        accepted_count += ensure(data, expected, "hypothesis indices")
        tested += 1
    # True is index 1, and -2 is index 0, in this two-entry context.
    accepted_count += ensure([truth, True, false, truth], True, "boolean index 1")
    accepted_count += ensure([truth, -2, truth, false], True, "negative index -2")
    tested += 2
    counts["hypothesis_index_aliases"] = {"tested": tested, "accepted_and_replayed": accepted_count}

    tested = accepted_count = 0
    for a in bad + good:
        data = [truth, ["use", 0, a, 1], truth, truth]
        expected = formula(a) and instantiate(a, -1) == truth
        accepted_count += ensure(data, expected, "equality template validation")
        tested += 1
    counts["equality_template_boundary"] = {"tested": tested, "accepted_and_replayed": accepted_count}

    eigen_cases = [
        ([truth, ["use", 0, 1], ["ex", ["=", 0, -1]]], False),
        ([truth, ["use", 0, 1], ["ex", truth]], True),
        ([["=", 0, 0], ["use", 0, 1], ["ex", truth], ["=", 0, 0]], True),
        ([["ex", ["=", 0, 0]], ["use", 0, 1], ["ex", ["ex", ["=", 0, 0]]]], True),
        ([["ex", ["=", 0, 0]], ["use", 0, 1], ["ex", ["ex", ["=", 1, 1]]]], False),
        ([truth, ["use", 0, 1, 1], ["ex", truth]], False),
    ]
    for data, expected in eigen_cases:
        ensure(data, expected, "existential eigenvariable")
    counts["existential_scope"] = {"tested": len(eigen_cases), "accepted_and_replayed": sum(e for _, e in eigen_cases)}

    tested = accepted_count = 0
    for shape in [None, False, True, 0, 2.0, "", "ab", {}, {"a": truth, "p": 0}, [], [truth]]:
        accepted_count += ensure(shape, False, "top-level finite JSON shape")
        tested += 1
    malformed_formulas = [*good, None, False, True, 0.0, {}, [], ["="], ["=", -1],
                          ["=", -1, -1, -1], ["=", True, -1], ["=", -1.0, -1],
                          ["ex"], ["ex", truth, truth], ["pi", truth], ["pi", truth, -1]]
    for f in malformed_formulas:
        assert not formula(f), f
        accepted_count += ensure([f, 0, f], False, "public formula validation")
        accepted_count += ensure([truth, 1, f, truth], False, "unused context formula validation")
        tested += 2
    counts["public_boundary"] = {"tested": tested, "accepted": accepted_count}

    example_paths = sorted(args.examples.glob("*.json"))
    if not example_paths:
        raise ValueError("No example certificates found in " + str(args.examples))
    for path in example_paths:
        data = json.loads(path.read_text())
        ensure(data, True, "full arithmetic example " + path.name)
    counts["full_arithmetic_replay"] = {"tested": len(example_paths), "accepted_and_replayed": len(example_paths)}

    # Mutate small complete certificates. Every accepted mutation must replay in
    # the stricter frozen checker, independently of the candidate translator.
    random.seed(20261107)
    examples = [json.loads(p.read_text()) for p in example_paths if p.stat().st_size < 6000]
    atoms = good + bad + [0, 1, -1, -2, ["use", 0, None, 1], ["lam", truth, 0]]

    def locations(t, path=()):
        yield path
        if type(t) is list:
            for i, v in enumerate(t):
                yield from locations(v, (*path, i))

    tested = accepted_count = 0
    for _ in range(1600):
        data = deepcopy(random.choice(examples))
        location = random.choice(list(locations(data)))
        replacement = deepcopy(random.choice(atoms))
        if location:
            holder = data
            for i in location[:-1]:
                holder = holder[i]
            holder[location[-1]] = replacement
        else:
            data = replacement
        if accepted(candidate, data):
            assert replay(data), data
            accepted_count += 1
        tested += 1
    counts["accepted_mutation_replay"] = {"tested": tested, "accepted_and_replayed": accepted_count}

    assert hashlib.sha256(candidate_path.read_bytes()).hexdigest() == candidate_hash
    assert hashlib.sha256(baseline_path.read_bytes()).hexdigest() == baseline_hash
    result = {"candidate_sha256": candidate_hash,
              "baseline_sha256": baseline_hash,
              "python": sys.version,
              "status": "PASS", "suites": counts,
              "note": "Finite tests support the separate proof; they do not establish universal soundness."}
    target = args.output
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
