A SMALLER COMPLETE AXIOMATIZATION OF iPRA
6 November 2026
Prepared for Vladimir Reshetnikov

READ FIRST

report.pdf is the complete paper. report.tex and sections/*.tex are all
of its LaTeX sources. checker.py is the entire standalone acceptance
program; nothing else in this package is imported by it.

RESULT

The checker has 639 normalized tokens, 684 AST nodes, and 2,071 normalized
UTF-8 bytes. The observed minima across the six current ProveIt archives,
including their embedded complete checkers, are 662, 712, and 2,150.
All three primary measurements therefore improve strictly. Significant
source tokens are 641 versus 664. Raw source is 2,439 bytes versus a
2,441-byte envelope; that two-byte formatting-sensitive difference is not
the basis of the result. The new source has 81 physical lines versus an
observed minimum of 80, so no line-count reduction is claimed.

Repository snapshot:
  https://github.com/VladimirReshetnikov/ProveIt
  Commit 820ef51b6ad3c13ce4a500673a9e81d951fbc06c
  Directory docs/drafts

The mathematical basis is inherited from the supplied draft series. The
new contribution is its smaller complete certificate presentation:

  1. A flat [goal, proof, *hypotheses] envelope constructs the context list.
  2. Hypothesis leaves use indices into already validated assumptions.
  3. Universal witnesses are validated when substitution uses them. If the
     variable occurs in neither principal matrix, any unused payload can
     be replaced by the ordinary zero witness with no change of sequent.

Equality templates are still completely validated during substitution.
All contexts and goals, including unused assumptions, remain validated.

This is a strict improvement over a pinned finite source set under an
explicit cost model, not a proof of absolute minimality among all possible
theories, programming languages, or encodings.

MATHEMATICAL CONTENT

The native calculus has one number sort; terms use 0, S, and fixed
initialized primitive recursion. Its formula constructors are equality,
guarded universal quantification Pi_x(A; B), and existence E_x A.
The complete primitive basis is six logical rule patterns, two recursion
equation schemas, and one numerical schema. That schema grants induction
only to literal equations and numerical cases to compound formulas.

The paper specifies every rule and proves:

  * equality reflexivity, symmetry, transitivity, and congruence;
  * explosion from the designated contradiction 0 = S0;
  * recovery of all ordinary intuitionistic connectives and quantifiers;
  * compilation of every fixed primitive-recursive description;
  * reflection of each quantifier-free formula into a literal equation;
  * the full quantifier-free induction schema;
  * faithful presentation of an ordinary intuitionistic first-order theory;
  * whole-domain bi-interpretability with iPRA and equiconsistency.

The ordinary realization explicitly includes numerical coverage and the
bridge 0 = S0 -> bottom. Its interpretations preserve the entire number
sort. Fixed-recursion uniqueness gives internal operation round trips at
arbitrary arguments, and x = y defines both composite isomorphisms.
The paper also gives an N x N countermodel showing why numerical cases
cannot simply be deleted from the native basis.

The reference iPRA is first-order intuitionistic PRA with all fixed
primitive-recursive function descriptions and induction for all
quantifier-free formulas, including their propositional connectives.
It is not only the quantifier-free proof calculus and is not full HA.

VERIFY

Python 3.11 or later, standard library only:

    python3 reproduce.py
    python3 checker.py examples/epsilon_zero_implies_equal.json
    python3 checker.py examples/forall_exists_successor.json

The recorded normalization uses CPython 3.12.14. AST-unparse-based byte and
token counts can depend on the Python version. The complete comparison
script records the version and does not import or execute the sources it
measures.

To reproduce individual evidence:

    python3 comparison/measure.py checker.py --require-strict-improvement
    python3 measure_ablation.py
    python3 validate.py
    python3 audit/demand_audit.py

All comparison sources, original proof bytes, and converted proof data are
included. No network access is needed. Auxiliary scripts may write updated
results and Python cache files, which are not needed to check a theorem.

BUILD THE PDF

Install a TeX distribution with pdflatex and the packages listed in
report.tex, then run:

    python3 build.py

Alternatively, python3 reproduce.py --pdf reruns the evidence and builds
the paper. report_numbers.py regenerates numerical macros and tables from
the measured and executed results and checks their checker hashes agree.

CERTIFICATE FORMAT

The public file is [goal, proof, hypothesis_0, hypothesis_1, ...]. An empty
hypothesis tail certifies an unconditional theorem; otherwise it certifies
a conditional sequent. The conclusion is inferred and compared to goal.

Numerical zero is integer -1. Nonnegative integers are de Bruijn variables.
Terms: integer >= -1, ["s", t], ["r", n, a, h].
Formulas: ["=", s, t], ["pi", A, B], ["ex", A].

Proofs: a context index; ["lam", A, p]; ["pack", t, p];
["use", p, a, q]; ["use", p, q] for an existential major;
["r", n, a, h] for a computation equation; ["nat", P, p].
See Section 6 for binding widths, substitutions, and exact inference rules.

Canonical proof indices are nonnegative integers. The actual checker
also permits negative list indices and Boolean aliases for indices 0/1.
These only select validated assumptions. In a vacuous universal
elimination, the unused witness field can be arbitrary decoded data.
translate.canonicalize replaces it by numerical zero and normalizes
assumption references. Used witnesses, equality templates, mathematical
syntax, and public sequents have strict formation checks.

The trust boundary is finite data decoded by the standard JSON reader,
not arbitrary custom Python objects. Python's nonfinite numeric decoder
extensions can survive only in unused payload fields, never as terms.
checker.py reports ACCEPT with status 0 or REJECT with status 1.

EVIDENCE AND ITS LIMITS

All 149 distinct inherited certificates translate and replay in both
directions, preserving contexts and conclusions. A separately written
named-variable rule interpreter validates 5,621 inference occurrences.
The main validation reports 1,319 assertions, including file integrity,
round trips, boundary inputs, canonicalization, and normal/optimized CLI.
The independent demand/scope audit reports 14,980 checks, including all
6,016 accepted cases from its 12,960-case grid replaying in the strict
baseline. These totals have different meanings and are not summed.

The report proves the soundness and interpretation arguments mathematically.
Neither the whole metatheory nor Python has been formally verified in
Lean or Rocq. Finite testing is supporting evidence, not a proof of all
inputs. Physical resource limits may reject very large valid certificates.

PACKAGE MAP

  report.tex, sections/       Complete paper source.
  report.pdf                 Compiled paper.
  checker.py                 Entire trusted candidate program.
  baseline.py                Unmodified strongest current baseline.
  translate.py               Checked forward/reverse proof conversion.
  examples/                  18 illustrative converted proofs.
  corpus/                    Remaining converted proofs (149 total).
  reference_corpus/           All 149 original proof files, unchanged.
  corpus_index.json          Source provenance and paired hashes.
  independent/               Attributed named-variable test interpreter.
  audit/                     Independent scope/reconstruction audit.
  ablations/                 Cumulative changes and formula-leaf control.
  comparison/                197 frozen sources and full source census.
  results/                   Reproduction, measurement, and PDF checks.
  validation_results.json    Detailed corpus and boundary results.
  ablation_metrics.json      Reproduced size of each reduction stage.
  MANIFEST.sha256            SHA-256 of each delivered file except itself.

ATTRIBUTION

The supplied ProveIt drafts are credited for the native logical basis,
arithmetic reflection, recursion coherence, and coverage correction.
The comparison and original proof files remain byte-identical to their
archived sources. The named-variable validation interpreter is included
unchanged with its own attribution. The new demand-driven reduction and
its independent validation are explained in report.pdf and the audit notes.
