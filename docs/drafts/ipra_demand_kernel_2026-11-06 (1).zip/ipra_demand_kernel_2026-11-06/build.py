"""Build the complete LaTeX paper; no network is used."""

from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
               "-file-line-error", "report.tex"]
    logs = []
    for _ in range(3):
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        logs.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT / "results/latex_build.log").write_text("\n".join(logs))
            print(logs[-1][-6000:])
            raise SystemExit(result.returncode)
    (ROOT / "results/latex_build.log").write_text(logs[-1])
    print("Built report.pdf from the delivered LaTeX sources.")


if __name__ == "__main__":
    main()
