"""Independent finite audit for the inferred-conclusion iPRA checker.

The oracle names bound variables and substitutes named free variables; it
does not import the candidate's scope table or substitution implementation.
Tests are finite implementation evidence, not a formal soundness proof.
"""

import argparse
import hashlib
import importlib.util
import itertools
import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path


ZERO = -1
ONE = ["s", ZERO]
TRUE = ["=", ZERO, ZERO]
FALSE = ["=", ZERO, ONE]


def valid(a, formula):
    if not formula and type(a) is int:
        return a >= -1
    if type(a) is not list or not a or type(a[0]) is not str:
        return False
    tag = a[0]
    if formula:
        if tag == "=":
            return len(a) == 3 and valid(a[1], False) and valid(a[2], False)
        if tag == "pi":
            return len(a) == 3 and valid(a[1], True) and valid(a[2], True)
        if tag == "ex":
            return len(a) == 2 and valid(a[1], True)
    else:
        if tag == "s":
            return len(a) == 2 and valid(a[1], False)
        if tag == "r":
            return len(a) == 4 and all(valid(t, False) for t in a[1:])
    return False


fresh = itertools.count()


def named(a, stack=()):
    """Resolve indices into fresh binder identities and named free variables."""
    if type(a) is int:
        if a == ZERO:
            return ("zero",)
        return ("bound", stack[a]) if a < len(stack) else ("free", a - len(stack))
    tag = a[0]
    if tag == "s":
        return ("succ", named(a[1], stack))
    if tag == "r":
        state, counter = next(fresh), next(fresh)
        return ("rec", named(a[1], stack), named(a[2], stack), state, counter,
                named(a[3], (state, counter, *stack)))
    if tag == "=":
        return ("equal", named(a[1], stack), named(a[2], stack))
    variable = next(fresh)
    if tag == "pi":
        return ("all", variable, named(a[1], (variable, *stack)),
                named(a[2], (variable, *stack)))
    if tag == "ex":
        return ("exists", variable, named(a[1], (variable, *stack)))
    raise ValueError("invalid named input")


def indices(a, stack=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "bound":
        return stack.index(a[1])
    if tag == "free":
        return a[1] + len(stack)
    if tag == "succ":
        return ["s", indices(a[1], stack)]
    if tag == "rec":
        return ["r", indices(a[1], stack), indices(a[2], stack),
                indices(a[5], (a[3], a[4], *stack))]
    if tag == "equal":
        return ["=", indices(a[1], stack), indices(a[2], stack)]
    if tag == "all":
        return ["pi", indices(a[2], (a[1], *stack)),
                indices(a[3], (a[1], *stack))]
    if tag == "exists":
        return ["ex", indices(a[2], (a[1], *stack))]
    raise ValueError("invalid named expression")


def replace_named(a, replacements, delta):
    tag = a[0]
    if tag == "free":
        i = a[1]
        if i < len(replacements):
            if replacements[i] is None:
                raise ValueError("deleted variable occurs")
            return replacements[i]
        return ("free", i + delta)
    if tag in ("zero", "bound"):
        return a
    if tag in ("succ",):
        return (tag, replace_named(a[1], replacements, delta))
    if tag == "rec":
        return (tag, replace_named(a[1], replacements, delta),
                replace_named(a[2], replacements, delta), a[3], a[4],
                replace_named(a[5], replacements, delta))
    if tag == "equal":
        return (tag, replace_named(a[1], replacements, delta),
                replace_named(a[2], replacements, delta))
    if tag == "all":
        return (tag, a[1], replace_named(a[2], replacements, delta),
                replace_named(a[3], replacements, delta))
    if tag == "exists":
        return (tag, a[1], replace_named(a[2], replacements, delta))
    raise ValueError("invalid named expression")


def oracle(a, env=(1,), depth=0, formula=True):
    if not valid(a, formula):
        raise ValueError("invalid syntax")
    stack = tuple(next(fresh) for _ in range(depth))
    replacements = [None if t is None else named(t) for t in env[:-1]]
    return indices(replace_named(named(a, stack), replacements, env[-1]), stack)


def term(rng, height=3):
    if height == 0 or rng.randrange(3) == 0:
        return rng.randrange(-1, 9)
    if rng.randrange(2) == 0:
        return ["s", term(rng, height - 1)]
    return ["r", term(rng, height - 1), term(rng, height - 1),
            term(rng, height - 1)]


def formula(rng, height=3):
    if height == 0 or rng.randrange(3) == 0:
        return ["=", term(rng, 2), term(rng, 2)]
    if rng.randrange(2) == 0:
        return ["pi", formula(rng, height - 1), formula(rng, height - 1)]
    return ["ex", formula(rng, height - 1)]


def succeeds(function, *args, **kwargs):
    try:
        return True, function(*args, **kwargs)
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        return False, None


def run(candidate, output):
    path = Path(candidate).resolve()
    spec = importlib.util.spec_from_file_location("candidate_under_audit", path)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    counts = {}
    failed = []

    def test(category, name, condition):
        counts[category] = counts.get(category, 0) + 1
        if not condition:
            failed.append({"category": category, "name": name})

    def cert(name, data, expected):
        ok, value = succeeds(checker.check, data)
        test("certificates", name, ok == expected and (not ok or value is True))

    rng = random.Random(762941)
    expressions = []
    for _ in range(240):
        expressions.append((term(rng), False))
        expressions.append((formula(rng), True))
    for i, (a, sort) in enumerate(expressions):
        for depth in range(4):
            k = rng.randrange(4)
            env = [*(term(rng, 2) for _ in range(k)), rng.randrange(-k, 4)]
            expected = oracle(a, env, depth, sort)
            ok, actual = succeeds(checker.subst, a, env, depth, formula=sort)
            test("named_substitution", f"{i}:{depth}", ok and actual == expected)
            expected_ok, expected = succeeds(oracle, a, [None, -1], depth, sort)
            ok, actual = succeeds(checker.subst, a, [None, -1], depth, formula=sort)
            test("partial_scope_deletion", f"{i}:{depth}",
                 ok == expected_ok and (not ok or actual == expected))
        lifted = oracle(a, (1,), formula=sort)
        ok, lowered = succeeds(checker.subst, lifted, [None, -1], formula=sort)
        test("lift_delete_roundtrip", str(i), ok and lowered == a)

    bad_scalars = [None, True, False, -2, -100, 0.0, -1.0, 1.0,
                   0.5, "", "s", "r", "=", "pi", "ex", {}, {"=": 0}]
    grammar_values = list(bad_scalars) + [-1, 0, 1, [], TRUE, ["s", -1]]
    tags = ["s", "r", "=", "pi", "ex", "unknown"]
    seeds = [-1, 0, True, None, "s", [], TRUE, ["s", -1]]
    for tag in tags:
        grammar_values.append([tag])
        for a in seeds:
            grammar_values.append([tag, a])
            for b in seeds:
                grammar_values.append([tag, a, b])
                for c in seeds:
                    grammar_values.append([tag, a, b, c])
    for width in range(1, 5):
        grammar_values.extend("".join(s) for s in itertools.product("sr=pex", repeat=width))
    grammar_values.extend(a for a, _ in expressions)
    for i, a in enumerate(grammar_values):
        for sort in (False, True):
            ok, _ = succeeds(checker.subst, a, formula=sort)
            test("grammar", f"{i}:{sort}", ok == valid(a, sort))
        if not valid(a, True):
            ok, _ = succeeds(checker.check, [[a], TRUE, TRUE])
            test("malformed_sequent", f"context:{i}", not ok)
            ok, _ = succeeds(checker.check, [[TRUE], a, TRUE])
            test("malformed_sequent", f"goal:{i}", not ok)

    # Expected goals below are written directly, independently of infer().
    cert("literal hypothesis", [[TRUE], TRUE, TRUE], True)
    cert("boolean lookup key returns stored", [[["=", 0, 1]], ["=", 0, 1],
         ["=", False, True]], True)
    cert("float lookup key returns stored", [[["=", 0, 1]], ["=", 0, 1],
         ["=", 0.0, 1.0]], True)
    cert("boolean goal rejected", [[["=", 0, 1]], ["=", False, True],
         ["=", 0, 1]], False)
    cert("false no proof", [[], FALSE, FALSE], False)
    cert("universal identity", [[], ["pi", ["=", 0, ZERO], ["=", 0, ZERO]],
         ["lam", ["=", 0, ZERO], ["=", 0, ZERO]]], True)
    cert("universal context captured", [[["=", 0, ZERO]],
         ["pi", TRUE, ["=", 0, ZERO]], ["lam", TRUE, ["=", 0, ZERO]]], False)
    cert("universal context lifted", [[["=", 0, ZERO]],
         ["pi", TRUE, ["=", 1, ZERO]], ["lam", TRUE, ["=", 1, ZERO]]], True)
    cert("witness equation packing", [[], ["ex", ["=", 0, ONE]],
         ["pack", ONE, ["=", 0, ONE]]], True)
    cert("parameter witness lifted", [[], ["ex", ["=", 0, 1]],
         ["pack", 0, ["=", 0, 1]]], True)
    cert("parameter witness capture rejected", [[], ["ex", ["=", 0, 0]],
         ["pack", 0, ["=", 0, 0]]], False)
    ex = ["ex", ["=", 0, ZERO]]
    cert("existential escape rejected", [[ex], ["=", 0, ZERO],
         ["use", ex, ["=", 0, ZERO]]], False)
    cert("existential retained parameter", [[ex, ["=", 0, ZERO]], ["=", 0, ZERO],
         ["use", ex, ["=", 1, ZERO]]], True)
    cert("existential vacuous witness", [[["ex", TRUE]], TRUE,
         ["use", ["ex", TRUE], TRUE]], True)
    cert("existential extra conclusion field", [[["ex", TRUE]], TRUE,
         ["use", ["ex", TRUE], TRUE, TRUE]], False)
    cert("existential missing branch", [[["ex", TRUE]], TRUE,
         ["use", ["ex", TRUE]]], False)
    rec0 = ["r", ZERO, 0, ["r", 1, 0, ["s", 2]]]
    cert("recursor zero with nested body", [[], ["=", rec0, 0], rec0], True)
    old = ["r", 2, 1, ["r", 1, 0, ["s", 2]]]
    rec1 = ["r", ["s", 2], 1, ["r", 1, 0, ["s", 2]]]
    # Under the inner body, old state is lifted through two local binders.
    lifted_old = ["r", 4, 3, ["r", 1, 0, ["s", 2]]]
    expected_update = ["r", 2, old, ["s", lifted_old]]
    cert("recursor successor simultaneous substitution",
         [[], ["=", rec1, expected_update], rec1], True)
    for n in (0, 1, ["r", ZERO, ZERO, ZERO]):
        r = ["r", n, ZERO, ZERO]
        cert("nonconstructor recursion counter " + repr(n), [[], ["=", r, ZERO], r], False)
    for bad in bad_scalars + [TRUE, ["s"], ["r", ZERO, ZERO]]:
        cert("unused malformed recursion body " + repr(bad),
             [[], TRUE, ["r", ZERO, ZERO, bad]], False)
        cert("unused malformed witness " + repr(bad),
             [[TRUE], ["ex", TRUE], ["pack", bad, TRUE]], False)

    # The conclusion is inferred only if no fresh witness occurs, including
    # occurrences under formulas and in semantically unused recursor fields.
    nested_bodies = [
        ["pi", TRUE, ["=", 1, ZERO]],
        ["ex", ["=", 1, ZERO]],
        ["=", ["r", ZERO, ZERO, 2], ZERO],
        ["ex", ["=", ["r", ZERO, ZERO, 3], ZERO]],
        ["pi", ["=", 1, ZERO], TRUE],
    ]
    for i, body in enumerate(nested_bodies):
        principal = ["ex", body]
        cert(f"nested witness escape {i}", [[principal], TRUE,
             ["use", principal, body]], False)
        shifted = oracle(body, (1,))
        vacuous = ["ex", shifted]
        cert(f"nested old variable survives {i}", [[vacuous], body,
             ["use", vacuous, shifted]], True)

    for i in range(30):
        p = formula(rng, 2)
        base = oracle(p, [ZERO, 0])
        step_conclusion = oracle(p, [["s", 0], 0])
        h = p if p[0] == "=" else base
        step = ["pi", h, step_conclusion]
        cert(f"numerical rule {i}", [[step], ["pi", base, p], ["nat", p, step]], True)
        cert(f"missing numerical premise {i}", [[], ["pi", base, p], ["nat", p]], False)
        if p[0] != "=" and p != base:
            forbidden = ["pi", p, step_conclusion]
            cert(f"quantified induction rejected {i}",
                 [[forbidden], ["pi", base, p], ["nat", p, forbidden]], False)

    # Actual JSON/CLI use includes malformed values Python json accepts by
    # default (NaN/Infinity); these must not become arithmetic syntax.
    cli_cases = [
        ("valid", json.dumps([[TRUE], TRUE, TRUE]), True),
        ("falsity", json.dumps([[], FALSE, FALSE]), False),
        ("null", "null", False),
        ("truncated", "[", False),
        ("invalid_nan_goal", '[[["=",0,0]],["=",NaN,0],["=",0,0]]', False),
        ("invalid_inf_context", '[[["=",Infinity,0]],["=",0,0],["=",0,0]]', False),
        ("float_key_alias", '[[["=",0,1]],["=",0,1],["=",0.0,1.0]]', True),
    ]
    with tempfile.TemporaryDirectory(prefix="ipra-independent-") as temp:
        for name, contents, expected in cli_cases:
            f = Path(temp) / (name + ".json")
            f.write_text(contents)
            for options, category in (([], "json_cli"), (["-O"], "optimized_json_cli")):
                result = subprocess.run([sys.executable, *options, str(path), str(f)],
                                        capture_output=True, text=True, timeout=20)
                test(category, name, result.returncode == (0 if expected else 1)
                     and result.stdout.strip() == ("ACCEPT" if expected else "REJECT"))
        for options, category in (([], "json_cli"), (["-O"], "optimized_json_cli")):
            result = subprocess.run([sys.executable, *options, str(path)],
                                    capture_output=True, text=True, timeout=20)
            test(category, "missing filename", result.returncode == 1
                 and result.stdout.strip() == "REJECT")

    report = {"candidate": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
              "audit_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "seed": 762941, "counts": counts, "total": sum(counts.values()),
              "failures": failed,
              "limits": "Finite tests of implementation invariants; no foundational formalization or absolute minimality claim."}
    if output:
        Path(output).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return not failed


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate")
    parser.add_argument("--out")
    options = parser.parse_args()
    raise SystemExit(0 if run(options.candidate, options.out) else 1)
