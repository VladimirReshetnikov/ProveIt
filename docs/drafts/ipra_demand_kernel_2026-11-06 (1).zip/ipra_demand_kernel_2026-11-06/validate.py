"""Focused executable evidence for the three checker reductions.

Run: python3 validate.py
This validates replay and the exact trust-boundary changes. It does not
claim a formal proof of soundness or a minimality theorem.
"""

from collections import Counter
from copy import deepcopy
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import baseline
import checker
import translate

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "independent"))
from audit import valid
import certificate_oracle

ZERO = -1
TRUE = ["=", ZERO, ZERO]
FALSE = ["=", ZERO, ["s", ZERO]]
counts = Counter()
failures = []
replay_records = []
rule_counts = Counter()
boundary_rule_counts = Counter()


def succeeds(function, *arguments):
    try:
        return True, function(*arguments)
    except Exception:
        return False, None


def test(category, name, condition):
    counts[category] += 1
    if not condition:
        failures.append({"category": category, "name": name})


def certificate(name, data, expected, category="boundary_certificates"):
    ok, value = succeeds(checker.check, data)
    test(category, name, ok == expected and (not ok or value is True))
    if ok:
        old = translate.reverse(data)
        independently_counted = certificate_oracle.check(old)
        boundary_rule_counts.update(independently_counted)
        test("accepted_replay", name, bool(independently_counted))
        normalized = translate.canonicalize(data)
        test("canonicalization", name, normalized == translate.canonicalize(normalized))


def run():
    corpus_index = json.loads((ROOT / "corpus_index.json").read_text())
    for record in corpus_index["records"]:
        path = ROOT / record["candidate_path"]
        reference_path = ROOT / record["reference_path"]
        test("corpus_hash", record["candidate_path"],
             hashlib.sha256(path.read_bytes()).hexdigest() == record["candidate_sha256"])
        test("corpus_hash", record["reference_path"],
             hashlib.sha256(reference_path.read_bytes()).hexdigest() == record["reference_sha256"])
        reference = json.loads(reference_path.read_text())
        baseline.check(reference)
        data = json.loads(path.read_text())
        test("archived_forward_translation", record["candidate_path"],
             translate.forward(reference) == data)
        checker.check(data)
        restored = translate.reverse(data)
        baseline.check(restored)
        test("archived_sequent_preservation", record["candidate_path"],
             reference[:2] == restored[:2])
        reduced = translate.forward(restored)
        checker.check(reduced)
        independent = certificate_oracle.check(restored)
        rule_counts.update(independent)
        test("archived_corpus_replay", record["candidate_path"], reduced == translate.canonicalize(data))
        replay_records.append({"file": record["candidate_path"],
                               "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                               "proof_nodes": sum(independent.values()),
                               "rules": dict(independent)})

    payloads = [None, True, False, -2, -100, 0.0, -1.0, 0.5, "", "s", "pi",
                {}, {"ignored": [True, None]}, [], ["s"], ["s", True],
                ["r", ZERO, ZERO], ["r", ZERO, ZERO, None], TRUE,
                0, 1, 19, ["s", ZERO], ["r", ZERO, ZERO, 0],
                float("nan"), float("inf"), -float("inf")]
    vacuous = ["pi", TRUE, TRUE]
    for index, payload in enumerate(payloads):
        data = [TRUE, ["use", 0, payload, 1], vacuous, TRUE]
        certificate(f"vacuous opaque witness {index}", data, True)
        normalized = translate.canonicalize(data)
        test("zero_witness_reconstruction", str(index), normalized[1][2] == ZERO)

    # All these wellformed matrices contain the eliminated variable, including
    # occurrences in syntactically retained but computationally unused fields.
    variable_matrices = [
        ["=", 0, ZERO],
        ["pi", TRUE, ["=", 1, ZERO]],
        ["ex", ["=", 1, ZERO]],
        ["=", ["r", ZERO, ZERO, 2], ZERO],
        ["pi", ["=", 1, ZERO], TRUE],
        ["ex", ["=", ["r", ZERO, ZERO, 3], ZERO]],
    ]
    for index, matrix in enumerate(variable_matrices):
        for side in (0, 1):
            principal = ["pi", matrix if side == 0 else TRUE,
                         matrix if side == 1 else TRUE]
            for j, payload in enumerate(payloads):
                if not valid(payload, False):
                    data = [TRUE, ["use", 0, payload, 1], principal, TRUE]
                    certificate(f"used witness {index}:{side}:{j}", data, False)

    for index, payload in enumerate(payloads):
        if not valid(payload, False):
            certificate(f"existential witness {index}",
                        [["ex", TRUE], ["pack", payload, 0], TRUE], False)
        if not valid(payload, True):
            certificate(f"equality template {index}",
                        [TRUE, ["use", 0, payload, 1], TRUE, TRUE], False)

    # Hypothesis aliases only select an existing validated formula.
    context = [TRUE, FALSE, ["=", 0, 1]]
    for reference in (0, 1, 2, -1, -2, -3, False, True):
        certificate("hypothesis " + repr(reference),
                    [context[reference], reference, *context], True)
    for reference in (-4, 3, 100, -100, 0.0, 1.0, None, "0", [], {}):
        certificate("bad hypothesis " + repr(reference), [TRUE, reference, *context], False)

    malformed = [None, True, False, -1, 0, 0.0, "", {}, [], ["=", False, 0],
                 ["=", 0.0, 0], ["=", -2, 0], ["pi", TRUE], ["ex", TRUE, TRUE],
                 ["=", ["s", 0, 0], 0], ["=", ["r", ZERO, ZERO, None], 0]]
    for index, item in enumerate(malformed):
        certificate(f"malformed goal {index}", [item, 0, TRUE], False)
        certificate(f"malformed hypothesis {index}", [TRUE, 0, TRUE, item], False)
    for i, top in enumerate((None, True, 0, "", {}, [], [TRUE])):
        certificate(f"malformed container {i}", top, False)

    # Existential elimination must delete its eigenvariable everywhere.
    for index, matrix in enumerate(variable_matrices):
        certificate(f"eigenvariable escape {index}",
                    [TRUE, ["use", 0, -1], ["ex", matrix]], False)
        shifted = checker.subst(matrix)
        certificate(f"old variable preserved {index}",
                    [matrix, ["use", 0, -1], ["ex", shifted]], True)

    # The non-equational branch is a case rule, not quantified induction.
    for index, matrix in enumerate(variable_matrices[1:]):
        if matrix[0] == "=":
            continue
        base = checker.subst(matrix, [ZERO, 0])
        step_consequent = checker.subst(matrix, [["s", 0], 0])
        required = ["pi", base, step_consequent]
        forbidden = ["pi", matrix, step_consequent]
        goal = ["pi", base, matrix]
        certificate(f"numerical cases {index}", [goal, ["nat", matrix, 0], required], True)
        certificate(f"quantified induction {index}", [goal, ["nat", matrix, 0], forbidden], False)

    # A small exhaustive grid stresses the eliminated eager validator.
    for index, (left, right, payload) in enumerate(itertools.product(
            [TRUE, ["=", 0, ZERO], ["ex", ["=", 1, ZERO]]], repeat=3)):
        principal = ["pi", left, right]
        old = [TRUE, ["use", 0, payload, 1], principal, TRUE]
        ok, _ = succeeds(checker.check, old)
        if ok:
            restored = translate.reverse(old)
            test("elimination_grid_replay", str(index), succeeds(baseline.check, restored)[0])
        else:
            test("elimination_grid_replay", str(index), True)

    cli_cases = [
        ("identity", json.dumps([TRUE, 0, TRUE]), True),
        ("opaque_witness", json.dumps([TRUE, ["use", 0, {"opaque": None}, 1], vacuous, TRUE]), True),
        ("nan_opaque_witness", json.dumps([TRUE, ["use", 0, float("nan"), 1], vacuous, TRUE]), True),
        ("nan_goal", json.dumps([["=", float("nan"), ZERO], 0, TRUE]), False),
        ("out_of_range_reference", json.dumps([TRUE, 1, TRUE]), False),
        ("empty_context_falsity", json.dumps([FALSE, 0]), False),
        ("truncated_json", "[", False),
    ]
    with tempfile.TemporaryDirectory(prefix="ipra-reduced-checker-") as temporary:
        for name, contents, expected in cli_cases:
            path = Path(temporary) / (name + ".json")
            path.write_text(contents)
            for flags, category in (([], "cli"), (["-O"], "optimized_cli")):
                result = subprocess.run([sys.executable, *flags, str(ROOT / "checker.py"), str(path)],
                                        capture_output=True, text=True, timeout=20)
                test(category, name, result.returncode == (0 if expected else 1)
                     and result.stdout.strip() == ("ACCEPT" if expected else "REJECT"))

    report = {"candidate_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
              "baseline_sha256": hashlib.sha256((ROOT / "baseline.py").read_bytes()).hexdigest(),
              "corpus_index_sha256": hashlib.sha256((ROOT / "corpus_index.json").read_bytes()).hexdigest(),
              "counts": dict(counts), "total": sum(counts.values()), "failures": failures,
              "corpus_certificates": len(replay_records), "corpus_rule_counts": dict(rule_counts),
              "boundary_rule_counts": dict(boundary_rule_counts),
              "corpus_proof_nodes": sum(rule_counts.values()), "corpus": replay_records,
              "limits": "Finite executable evidence; no machine-checked metatheorem or absolute minimality claim."}
    (ROOT / "validation_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "corpus"}, indent=2))
    return not failures


if __name__ == "__main__":
    raise SystemExit(0 if run() else 1)
