OFFLINE COMPARISON OF COMPLETE iPRA CHECKERS
=========================================

This folder is self-contained. It freezes the acceptance sources compared
with the accompanying checker, preserves their exact original bytes, and
recomputes the comparison without importing or executing compared code.
The original ZIP archives and a network connection are not required.

Repository: VladimirReshetnikov/ProveIt
Directory: docs/drafts
Pinned commit: 820ef51b6ad3c13ce4a500673a9e81d951fbc06c
The six archives and their original hashes are recorded in manifest.json
and ARCHIVES.txt. Each frozen source has at least one exact archive/member
origin. The archive SHA-256 and repository Git blob SHA-1 identify the source
archives; the per-source SHA-256 identifies the extracted original bytes.

RUN FROM THE DELIVERY ROOT

  python3 comparison/measure.py checker.py --require-strict-improvement

The optional positional argument is the complete prospective checker file,
resolved relative to the current working directory. Without an argument,
the script uses checker.py immediately above its own directory if present.
With neither a candidate argument nor that file, it measures baselines only.

To require improvement in the two secondary size measures as well:

  python3 comparison/measure.py checker.py --require-strict-all-size-measures

To measure only the frozen comparison corpus:

  python3 comparison/measure.py --baselines-only

The script checks every frozen source SHA-256 and byte length before using
it. It writes metrics.json, table.tex and macros.tex in its own directory.
Use --output-dir PATH to put these outputs elsewhere. table.tex requires
the ordinary LaTeX booktabs package. macros.tex supplies named values for
paper prose; the short CandidateTokens and BaselineTokens macros always
refer to normalized significant tokens.

Python 3.12 is recommended for reproducing the recorded normalized counts;
the recorded run used Python 3.12.14. There are no third-party Python
requirements. Python AST normalization can change across language versions,
so metrics.json records the actual version and the version-match flag.

CONTENTS AND BOUNDARIES

  measure.py             Measurement and LaTeX output generator.
  manifest.json          Selected files, primary labels, archive provenance,
                         standalone membership and dependency group records.
  source_inventory.json  Complete metadata census of every Python member of
                         all six current archives, including omitted support.
  sources/<sha256>.py    197 byte-distinct frozen source files.
  metrics.json           Recomputed measurements and candidate comparison.
  table.tex              Recomputed concise six-primary-plus-envelope table.
  macros.tex             Recomputed values and percentages for the paper.
  SOURCE_INVENTORY.txt   Selection, dependency closure and metric definitions.
  ARCHIVES.txt           Human-readable original archive hashes and sizes.

There are 158 distinct complete standalone acceptance modules and 74
recorded historical dependency groups. Their memberships overlap. The
197 frozen files comprise every standalone module plus 39 additional
historical dependency files. The six primary checker files are included
and labeled in the manifest. The selection also includes embedded
candidate, ablation, control and historical checker implementations.

Complete standalone modules are counted in full, including constructors,
axiom/rule data, substitution, sorting, formation checks, inference,
rejection, imports, JSON input and command-line handling. Historical groups
sum all their recorded unique dependencies, including adapters. Python and
its standard JSON implementation are common platform assumptions. Some
historical groups explicitly favor the comparison source by counting only
a mathematical core. These boundaries are preserved and reported.

The prospective candidate is measured as one whole file. The accompanying
candidate is standalone and imports only json and sys. A different candidate
with additional acceptance dependencies would require adding those files
to its measurement boundary; this script does not infer arbitrary Python
dependency closures or certify the soundness/completeness of passed code.

WHAT THE RESULT MEANS

The primary coordinates are normalized significant tokens, AST nodes and
normalized UTF-8 source bytes. These suppress differences in comments,
docstrings and formatting. Significant original tokens and raw source bytes
are secondary measures. Raw physical lines are recorded for transparency,
but are not an optimization coordinate: harmless line wrapping can change
them without changing the executable program.

The current combined finite lower envelope is:
  664 significant original tokens;
  662 significant normalized tokens;
  712 AST nodes;
  2,150 normalized UTF-8 bytes;
  2,441 raw source bytes.
The primary-envelope and full-corpus-envelope values coincide. Individual
coordinates can be attained by different files. In particular, inferred
elimination attains the first four listed minima; compact kernel attains
the raw-byte minimum.

This is an observed finite-corpus comparison, not a global mathematical
lower bound on proof-checker complexity and not an absolute-minimality
claim. The selection and inherited dependency groups are not a soundness
certificate for every historical proposal. The accompanying mathematical
argument and targeted executable tests justify the new construction;
size measurements alone do not establish equivalence to iPRA.

ATTRIBUTION

All files under sources/ are preserved verbatim from the six user-supplied
repository draft archives, including their original internal comments and
docstrings. Their original mathematical and implementation contributions
belong to those drafts. The accompanying paper distinguishes the inherited
basis from its new certificate representation and validation reductions.
