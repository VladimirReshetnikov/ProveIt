"""Reproduce all current-program measurements and validation, offline."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true", help="Also rebuild report.pdf")
    options = parser.parse_args()
    jobs = [
        ("comparison", ["comparison/measure.py", "checker.py", "--require-strict-improvement"]),
        ("ablation", ["measure_ablation.py"]),
        ("validation", ["validate.py"]),
        ("independent_audit", ["audit/demand_audit.py"]),
        ("paper_numbers", ["report_numbers.py"]),
    ]
    if options.pdf:
        jobs.append(("pdf_build", ["build.py"]))
    results = []
    for name, command in jobs:
        process = subprocess.run([sys.executable, *command], cwd=ROOT,
                                 text=True, capture_output=True)
        (ROOT / "results" / (name + ".log")).write_text(process.stdout + process.stderr)
        results.append({"name": name, "command": ["python3", *command],
                        "exit_code": process.returncode})
        print(name + ": " + ("PASS" if process.returncode == 0 else "FAIL"), flush=True)
        if process.returncode:
            print(process.stdout[-3000:] + process.stderr[-3000:])
            raise SystemExit(process.returncode)
    summary = {"status": "PASS", "python": sys.version,
               "checker_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
               "jobs": results}
    (ROOT / "results/reproduction.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
