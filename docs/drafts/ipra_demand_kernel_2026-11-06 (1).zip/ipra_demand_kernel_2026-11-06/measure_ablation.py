"""Reproduce complete-file ablation metrics without running the controls.

The metric convention is inherited from the pinned ProveIt draft series:
remove docstrings, count all AST nodes including contexts/operators, and
tokenize both source and ast.unparse output, excluding layout/comments.
"""

import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    yield node.body[0]


def tokens(source, omitted=()):
    return sum(token.type not in IGNORED and not any(
        start <= token.start and token.end <= end for start, end in omitted)
        for token in tokenize.generate_tokens(io.StringIO(source).readline))


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset))
             for node in docstrings(tree)]
    stripped = copy.deepcopy(tree)
    omitted = {id(node) for node in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, "body") and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in omitted]
    normalized = ast.unparse(stripped) + "\n"
    return {"path": path.relative_to(ROOT).as_posix(),
            "sha256": hashlib.sha256(data).hexdigest(),
            "source_tokens": tokens(source, spans),
            "normalized_tokens": tokens(normalized),
            "ast_nodes": sum(1 for _ in ast.walk(stripped)),
            "normalized_bytes": len(normalized.encode("utf-8")),
            "raw_bytes": len(data)}


def main():
    paths = [ROOT / "baseline.py", *sorted((ROOT / "ablations").glob("*.py")),
             ROOT / "checker.py"]
    report = {"python_version": platform.python_version(),
              "python_implementation": platform.python_implementation(),
              "trusted_scope": "Whole standalone file, including validation, imports and CLI.",
              "rows": [measure(path) for path in paths]}
    (ROOT / "ablation_metrics.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
