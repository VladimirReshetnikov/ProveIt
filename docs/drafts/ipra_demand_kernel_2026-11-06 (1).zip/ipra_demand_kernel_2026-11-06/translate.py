"""Untrusted replay translations between the frozen and reduced checkers.

The frozen baseline is the complete inferred_elimination checker from
VladimirReshetnikov/ProveIt, docs/drafts, commit
820ef51b6ad3c13ce4a500673a9e81d951fbc06c. Translations are verified by both
checkers; neither translator is imported by the candidate acceptance code.
"""

from copy import deepcopy

import baseline
import checker


def extended(context, assumption):
    return [*(baseline.subst(a) for a in context), assumption]


def uses_variable(expression, variable=0):
    """Syntactic free occurrence, counting both recursor-local binders."""
    if type(expression) is int:
        return expression == variable
    tag, *children = expression
    if tag == "r":
        return (uses_variable(children[0], variable)
                or uses_variable(children[1], variable)
                or uses_variable(children[2], variable + 2))
    if tag in ("pi", "ex"):
        variable += 1
    return any(uses_variable(child, variable) for child in children)


def forward_proof(proof, context):
    """A baseline derivation becomes an indexed candidate derivation."""
    match proof:
        case [("lam" | "pack") as tag, parameter, body]:
            assumption = (parameter if tag == "lam"
                          else ["=", 0, baseline.subst(parameter, formula=False)])
            return [tag, parameter, forward_proof(body, extended(context, assumption))]
        case ["use", major, *arguments]:
            major_formula = baseline.infer(major, context)
            translated_major = forward_proof(major, context)
            if major_formula[0] == "ex":
                body, = arguments
                return ["use", translated_major,
                        forward_proof(body, extended(context, major_formula[1]))]
            parameter, minor = arguments
            return ["use", translated_major, parameter, forward_proof(minor, context)]
        case ["r", _, _, _]:
            return proof
        case ["nat", matrix, step]:
            return ["nat", matrix, forward_proof(step, context)]
        case _:
            return context.index(proof)


def reverse_proof(proof, context, repairs=None):
    """Reconstruct ordinary witnesses and exact stored hypothesis formulas.

Every vacuous universal witness is replaced by zero, including arbitrary
JSON payloads. A used witness remains unchanged: candidate acceptance has
already validated it when it was substituted into a matrix.
"""
    match proof:
        case [("lam" | "pack") as tag, parameter, body]:
            assumption = (parameter if tag == "lam"
                          else ["=", 0, checker.subst(parameter, formula=False)])
            return [tag, parameter, reverse_proof(body, extended(context, assumption), repairs)]
        case ["use", major, *arguments]:
            major_formula = checker.infer(major, context)
            translated_major = reverse_proof(major, context, repairs)
            if major_formula[0] == "ex":
                body, = arguments
                return ["use", translated_major,
                        reverse_proof(body, extended(context, major_formula[1]), repairs)]
            parameter, minor = arguments
            if major_formula[0] == "pi" and not any(
                    uses_variable(part) for part in major_formula[1:]):
                if repairs is not None:
                    repairs.append({"operation": "vacuous_witness", "payload": parameter})
                parameter = checker.ZERO
            return ["use", translated_major, parameter,
                    reverse_proof(minor, context, repairs)]
        case ["r", _, _, _]:
            return proof
        case ["nat", matrix, step]:
            return ["nat", matrix, reverse_proof(step, context, repairs)]
        case _:
            if repairs is not None:
                repairs.append({"operation": "hypothesis_lookup", "reference": proof})
            return context[proof]


def forward(data):
    baseline.check(data)
    context, goal, proof = deepcopy(data)
    translated = [goal, forward_proof(proof, context), *context]
    checker.check(translated)
    return translated


def reverse(data, repairs=None):
    checker.check(data)
    goal, proof, *context = deepcopy(data)
    translated = [context, goal, reverse_proof(proof, context, repairs)]
    baseline.check(translated)
    return translated


def canonicalize(data):
    """Return a candidate certificate with nonnegative indices and witnesses."""
    return forward(reverse(data))
