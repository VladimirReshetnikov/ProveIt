NAMING VALUES BEFORE SPECIALIZATION
Research report on the supplied ProveIt drafts, 10 November 2026 (UTC)
======================================================================

STATUS
------
The requested significant new axiomatization below the whole supplied
complexity frontier has not been established. This package contains two
precise, narrower advances. It is not an absolute-minimality claim.

1. An exact new logical presentation restricts closure specialization to
   in-scope numerical variables and the numeral 1. Arbitrary term targets
   are recovered by first naming their values through an existential
   equality. The transformation preserves every raw native sequent and
   therefore the full-domain bi-interpretation with iPRA. It adds at most
   nine primitive proof-tree nodes per replaced specialization, without
   duplicating either premise. Each target class is separately necessary
   for preserving this unchanged contextual calculus.

2. A uniform continuation and a proved rejection-state invariant reduce
   three complete profiles of the inherited Choice-DI checker:

   Profile          Old tokens/AST/bytes       New tokens/AST/bytes
   Token                   292/336/865                287/331/811
   AST                     296/330/882                289/326/840
   Byte                    298/349/762                292/341/753

   The coordinate envelope improves from 292/330/762 to 287/326/753.
   Different whole programs attain the three coordinates. No one new
   program beats all three independent old minima. The new profiles
   implement the equivalent inherited calculus; their sizes are not
   attributed to the restriction in result 1. The separate checker that
   enforces that restriction directly measures 337/395/947.

OPEN FIRST
----------
report.pdf                      Complete compiled report.
ipra_named_specialization.tex    Standalone editable LaTeX source.
report.tex and theory/          Modular source.
code/qe_restricted.py            Complete checker enforcing the new rule.
code/qe_producer.py              Untrusted generator for expanded examples.
fixtures/qe_two.json             Closed expanded proof at target 2.
fixtures/qe_nested_successor_iterator.json
                                Closed expanded proof at a nested target.
fixtures/qe_compound_formula.json
                                Closed example with transport under Q.
code/kernel_{tokens,structure,bytes}.py
                                Three complete smaller inherited profiles.
code/translate_uniform.py       Old canonical packet to new packet translator.
reference/                      Frozen controls and attributed arithmetic proofs.
evidence/                       Measurements, checks, provenance, and reviews.
CLAIMS.json                     Exact contribution and limitation ledger.
MANIFEST.sha256.json             Digest and byte size of each archive member.

REPRODUCE
---------
Run from this directory with Python 3 (exact metrics use CPython 3.12.14):

    python3 verify_archive.py
    python3 reproduce.py

Run verify_archive.py before regenerating any files: it verifies the
distributed bytes. Reproduction refreshes evidence, so later digests can
change without changing a theorem.

Example standalone check:

    python3 code/qe_restricted.py < fixtures/qe_two.json

It prints ACCEPT and exits zero. Rejection prints REJECT and returns a
nonzero exit, with a traceback on stderr. The three smaller profiles use
the same verdict convention. Only standard json is imported by a kernel;
submitted strings are not executed as code.

To rebuild the report with an installed PDFLaTeX distribution:

    python3 build.py

To regenerate the distribution manifest and ZIP archive:

    python3 package.py

The standalone TeX is also independently compilable with PDFLaTeX.
No network, shell escape, or external bibliography processor is needed.

IMPORTANT CERTIFICATE CHANGE
----------------------------
The smaller profiles add a harmless truth assumption and an unused fresh
label at Eq/Q continuations. Old numerical labels and hypothesis pruning
therefore cannot be copied verbatim. The included translator reserializes
accepted canonical old proofs using the new contexts. The package does
not claim same-packet equivalence.

EVIDENCE BOUNDARY
-----------------
The interpretation and rule-equivalence theorems are written proofs with
independent assistant reviews. Executable certificates check concrete
instances and implementations. No Lean/Rocq formalization, external human
peer review, or verification of the Python runtime is claimed. Universal
claims are not inferred from finite numerical tests.

SOURCE SNAPSHOT
---------------
Repository: VladimirReshetnikov/ProveIt
Commit: 7e694b036f89a0f16313089329555da531d6a656
Directory: docs/drafts
All 11 ZIP lengths and Git blob hashes were verified. Their extracted
Python sources contain 519 occurrences and 398 distinct byte hashes.
There are no nested source ZIPs. Exact source-member hashes and the
inherited license are retained. No source-repository write was performed.

https://github.com/VladimirReshetnikov/ProveIt/tree/7e694b036f89a0f16313089329555da531d6a656/docs/drafts
