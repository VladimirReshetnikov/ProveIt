#!/usr/bin/env python3
"""Finite numerical diagnostics for the compensating-counter proof.

These checks concern standard natural numbers on a bounded grid. They do
not prove induction, arbitrary-model equality reflection, intuitionistic
derivability, either interpretation, or the identity round trips.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def pred(n: int) -> int:
    return max(n - 1, 0)


def sub(x: int, y: int) -> int:
    return max(x - y, 0)


def choose(z: int, zero_value: int, successor_value: int) -> int:
    return zero_value if z == 0 else successor_value


def f_term(u: int, v: int) -> int:
    return sub(u, v) + v


def g_term(u: int, v: int) -> int:
    return sub(v, u) + u


def update(a: int, b: int, w: int) -> int:
    # Exact written update: C(a, C(b,w,S(w)), S(w)).
    return choose(a, choose(b, w, w + 1), w + 1)


def bad_update(a: int, b: int, w: int) -> int:
    # Mutation: increments only when BOTH residuals are positive.
    return choose(a, w, choose(b, w, w + 1))


def require(condition: bool, label: str, witness: dict) -> None:
    if not condition:
        raise RuntimeError(json.dumps({"failed": label, "witness": witness}))


def trace_pair(x: int, y: int, scan_update=update) -> tuple[list[dict], dict | None]:
    trace = []
    w = 0
    for n in range(x + y + 3):
        a, b = sub(x, n), sub(y, n)
        left = w + f_term(a, b)
        right = w + g_term(a, b)
        state = {"n": n, "a": a, "b": b, "w": w, "L": left, "M": right}
        trace.append(state)
        if left != f_term(x, y) or right != g_term(x, y):
            return trace, {"x": x, "y": y, **state, "expected_L": f_term(x, y), "expected_M": g_term(x, y)}
        w = scan_update(a, b, w)
    return trace, None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-coordinate", type=int, default=64)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("compensation_checks.json"))
    args = parser.parse_args()
    bound = args.max_coordinate
    if bound < 1:
        raise ValueError("max-coordinate must be at least 1 so the mutation control is nontrivial")
    pair_count = state_count = transition_count = endpoint_count = 0
    reflection_count = 0
    for x in range(bound + 1):
        for y in range(bound + 1):
            pair_count += 1
            w = 0
            previous = None
            expected_left, expected_right = f_term(x, y), g_term(x, y)
            for n in range(x + y + 3):
                a, b = sub(x, n), sub(y, n)
                left, right = w + f_term(a, b), w + g_term(a, b)
                witness = {"x": x, "y": y, "n": n, "a": a, "b": b, "w": w}
                require(left == expected_left, "L(n)=F(x,y)", witness)
                require(right == expected_right, "M(n)=G(x,y)", witness)
                if previous is not None:
                    require((left, right) == previous, "stationarity of L and M", witness)
                    transition_count += 1
                previous = (left, right)
                state_count += 1
                if n == x + y:
                    require(a == 0 and b == 0, "residuals vanish at x+y", witness)
                    require(left == w and right == w, "endpoint identifies F and G", witness)
                    endpoint_count += 1
                next_a, next_b = sub(x, n + 1), sub(y, n + 1)
                require(next_a == pred(a) and next_b == pred(b), "residual update equations", witness)
                w = update(a, b, w)
            require(expected_left == expected_right, "balance identity", {"x": x, "y": y})
            delta = sub(x, y) + sub(y, x)
            error_bit = choose(delta, 0, 1)
            require((delta == 0) == (x == y), "native equality reflection on N", {"x": x, "y": y})
            require(error_bit in (0, 1) and (error_bit == 0) == (x == y), "computed equality bit on N", {"x": x, "y": y})
            reflection_count += 1

    mutation_witness = None
    for x in range(bound + 1):
        for y in range(bound + 1):
            _, failure = trace_pair(x, y, bad_update)
            if failure is not None:
                mutation_witness = failure
                break
        if mutation_witness is not None:
            break
    require(mutation_witness is not None, "mutated scan must be rejected", {"bound": bound})
    sample_pairs = [(0, 0), (0, 3), (2, 5), (5, 2), (4, 4)]
    samples = []
    for x, y in sample_pairs:
        if max(x, y) <= bound:
            trace, failure = trace_pair(x, y)
            require(failure is None, "sample trace", {"x": x, "y": y})
            samples.append({"x": x, "y": y, "states": trace})
    result = {
        "status": "passed",
        "scope": "Finite standard-natural-number diagnostics, not a proof of universal or nonstandard-model claims.",
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "grid": {"x": [0, bound], "y": [0, bound], "n_inclusive": "0 through x+y+2"},
        "counts": {
            "pairs": pair_count,
            "states": state_count,
            "stationarity_transitions": transition_count,
            "endpoint_checks": endpoint_count,
            "reflection_and_bit_pairs": reflection_count,
        },
        "formulas": {
            "sub": "d(x,y)=max(x-y,0)",
            "selector": "C(z,u,v)=u if z=0, otherwise v",
            "F": "d(u,v)+v",
            "G": "d(v,u)+u",
            "a_n": "d(x,n)",
            "b_n": "d(y,n)",
            "w_0": 0,
            "w_successor": "C(a_n,C(b_n,w_n,S(w_n)),S(w_n))",
            "L": "w_n+F(a_n,b_n)",
            "M": "w_n+G(a_n,b_n)",
            "endpoint": "n=x+y",
        },
        "mutation_control": {
            "mutation": "Increment w only if both residuals are positive, using C(a,w,C(b,w,S(w))).",
            "status": "rejected_as_required",
            "first_counterexample": mutation_witness,
        },
        "sample_traces": samples,
        "limitations": [
            "The carrier is Python's nonnegative integers, not an arbitrary first-order model.",
            "The numerical selector branches use Python equality; the manuscript separately proves constructive branching from coverage.",
            "No induction schema, proof translation, or bi-interpretation is certified by these tests.",
            "Arithmetic prerequisites and the absence of hidden disjunctive induction require the mathematical or formal proof.",
        ],
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", **result["counts"], "mutation": "rejected", "output": str(args.output)}))


if __name__ == "__main__":
    main()
