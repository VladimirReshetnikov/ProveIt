ARTIFACT SCOPE AND REPLAY

Python 3 standard library only. From the package root run:

  python3 artifacts/schema_metrics.py
  python3 artifacts/check_compensation.py

The first command rebuilds displayed syntax trees, includes all displayed
universal closures, and checks the exact counting formulas. It emits
schema_metrics.json. The two independent parameter counts are k (frozen
recursion arguments) and q (schema parameters, excluding a fresh probe).
Its ledger does not count the complete description of an infinite theory.

The second checks all x,y from 0 to 64 and all n from 0 through x+y+2,
inclusive. It evaluates the stated compensating-counter recurrence,
checks the two stationary invariants and their common endpoint, and
verifies that an intentionally incorrect scan is rejected. It emits
compensation_checks.json. --max-coordinate changes the finite bound.

These numerical diagnostics are not universal mathematical proofs and do
not certify induction, intuitionistic derivability, arbitrary carriers,
proof transport, or the bi-interpretation round trips. See the manuscript
and the separately scoped formal artifact for those claims and limits.

Neither script accesses the network or imports third-party packages.
No scripts from the input draft archives were used or executed here.
