#!/usr/bin/env python3
"""Recompute the report's finite syntax-tree ledger using only Python's stdlib.

This counts displayed templates, not full encodings of infinite theories.
Every occurrence of a term/formula metavariable is an application node with
its displayed arguments. No substituted body is silently expanded.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple["Node", ...] = ()

    def count(self) -> int:
        return 1 + sum(child.count() for child in self.children)

    def tree(self):
        return [self.label, *(child.tree() for child in self.children)]


def app(name: str, *args: Node) -> Node:
    return Node(name, tuple(args))


def var(name: str) -> Node:
    return Node("var:" + name)


def forall(names: list[str], body: Node) -> Node:
    for name in reversed(names):
        body = app("forall:" + name, body)
    return body


ZERO = Node("const:0")
BOTTOM = Node("falsity")


def succ(term: Node) -> Node:
    return app("S", term)


def eq(left: Node, right: Node) -> Node:
    return app("=", left, right)


def imp(left: Node, right: Node) -> Node:
    return app("implies", left, right)


def disj(left: Node, right: Node) -> Node:
    return app("or", left, right)


def conj(left: Node, right: Node) -> Node:
    return app("and", left, right)


def computation(m: int, kind: str) -> tuple[Node, Node]:
    """m is seed plus frozen arguments; m=1 means no frozen arguments."""
    if m < 1 or kind not in {"ordinary", "counter_swap", "full_swap"}:
        raise ValueError("invalid computation interface")
    n, a = var("n"), var("a")
    names = [f"b{i}" for i in range(m - 1)]
    frozen = [var(name) for name in names]
    base = forall(["a", *names], eq(app("R_h", ZERO, a, *frozen), a))
    if kind == "ordinary":
        recursive_call = app("R_h", n, a, *frozen)
    else:
        recursive_call = app("R_h", a, n, *frozen)
    arguments = [n, *frozen, recursive_call]
    if kind == "full_swap":
        arguments = [n, a, *frozen, recursive_call]
    step = forall(
        ["n", "a", *names],
        eq(app("R_h", succ(n), a, *frozen), app("h", *arguments)),
    )
    return base, step


def separation() -> Node:
    # Negation is expanded; 1 is S(0).
    return imp(eq(ZERO, succ(ZERO)), BOTTOM)


def induction_schema(q: int, kind: str) -> Node:
    if q < 0 or kind not in {"root", "qf_opaque", "two_equations"}:
        raise ValueError("invalid induction interface")
    names = [f"c{i}" for i in range(q)]
    parameters = [var(name) for name in names]
    n = var("n")

    def equation(argument: Node, left: str = "s", right: str = "t") -> Node:
        return eq(app(left, argument, *parameters), app(right, argument, *parameters))

    def matrix(argument: Node) -> Node:
        if kind == "qf_opaque":
            return app("A:formula_metavariable", argument, *parameters)
        if kind == "two_equations":
            return disj(equation(argument), equation(argument, "u", "v"))
        return disj(eq(argument, ZERO), equation(argument))

    if kind == "root":
        body = imp(
            forall(["n"], imp(matrix(n), equation(succ(n)))),
            forall(["n"], matrix(n)),
        )
    else:
        body = imp(
            conj(matrix(ZERO), forall(["n"], imp(matrix(n), matrix(succ(n))))),
            forall(["n"], matrix(n)),
        )
    return forall(names, body)


def fresh_probe_schema(q: int, inline: bool) -> Node:
    """q excludes the independently quantified fresh probe a."""
    if q < 0:
        raise ValueError("q must be nonnegative")
    names = [f"c{i}" for i in range(q)]
    parameters = [var(name) for name in names]
    n, a = var("n"), var("a")

    def f(argument: Node) -> Node:
        return app("f", argument, *parameters)

    stationary = forall(["n"], eq(f(succ(n)), f(n)))
    if inline:
        first = eq(app("C", app("D", a, f(ZERO)), f(ZERO), a), a)
        second = eq(succ(f(n)), a)
    else:
        first = eq(app("T", f(ZERO), a), a)
        second = eq(f(n), a)
    return forall(names, imp(stationary, forall(["a", "n"], disj(first, second))))


def helper_bodies(inline: bool) -> dict[str, Node]:
    bodies = {"C": var("b"), "D": var("v")}
    if not inline:
        bodies["T"] = app("C", app("D", var("a"), var("n")), var("n"), var("a"))
    return bodies


def check_equal(actual: int, expected: int, label: str) -> None:
    if actual != expected:
        raise RuntimeError(f"{label}: AST count {actual} != claimed count {expected}")


def row(m: int, q: int) -> dict:
    ordinary = computation(m, "ordinary")
    counter_swap = computation(m, "counter_swap")
    full_swap = computation(m, "full_swap")
    sep = separation().count()
    root = induction_schema(q, "root").count()
    qf = induction_schema(q, "qf_opaque").count()
    two = induction_schema(q, "two_equations").count()
    comparator = fresh_probe_schema(q, inline=False).count()
    inline = fresh_probe_schema(q, inline=True).count()
    ordinary_count = sum(tree.count() for tree in ordinary)
    counter_count = sum(tree.count() for tree in counter_swap)
    full_count = sum(tree.count() for tree in full_swap)
    checks = [
        (ordinary[0].count(), 2 * m + 4, "ordinary base"),
        (ordinary[1].count(), 4 * m + 8, "ordinary step"),
        (counter_count, 6 * m + 12, "counter-only swap computation"),
        (full_count, 6 * m + 13, "full swap computation"),
        (sep, 6, "separation"),
        (root, 29 + 7 * q, "Root schema"),
        (qf, 14 + 5 * q, "opaque QFI schema"),
        (two, 53 + 17 * q, "Two schema"),
        (comparator, 21 + 5 * q, "fresh comparator schema"),
        (inline, 26 + 6 * q, "fresh inline schema"),
    ]
    for actual, expected, label in checks:
        check_equal(actual, expected, label)
    return {
        "m_recursion_seed_plus_frozen": m,
        "k_recursion_frozen": m - 1,
        "q_schema_frozen_excluding_fresh_probe": q,
        "component_counts": {
            "ordinary_base": ordinary[0].count(),
            "ordinary_step": ordinary[1].count(),
            "ordinary_computation": ordinary_count,
            "counter_only_swap_computation": counter_count,
            "full_swap_computation": full_count,
            "separation": sep,
            "root_schema": root,
            "qf_opaque_schema": qf,
            "two_equations_schema": two,
            "fresh_comparator_schema": comparator,
            "fresh_inline_schema": inline,
        },
        "presentations": {
            "new_root": {"display": ordinary_count + sep + root, "bodies": 0},
            "prior_qf_opaque": {"display": ordinary_count + sep + qf, "bodies": 0},
            "prior_two_equations": {"display": ordinary_count + sep + two, "bodies": 0},
            "prior_fresh_comparator": {"display": full_count + sep + comparator, "bodies": 8},
            "prior_implicit_fresh_inline": {"display": counter_count + sep + inline, "bodies": 2},
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("schema_metrics.json"))
    args = parser.parse_args()
    rows = [row(m, q) for m in range(1, 5) for q in range(5)]
    for entry in rows:
        for counts in entry["presentations"].values():
            counts["partial_subtotal"] = counts["display"] + counts["bodies"]
    expected_bodies = {False: 8, True: 2}
    for inline, expected in expected_bodies.items():
        check_equal(sum(t.count() for t in helper_bodies(inline).values()), expected, "helper bodies")
    result = {
        "status": "passed",
        "scope": "Exact counts of finite displayed ASTs; no global minimality or full theory encoding claim.",
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "node_convention": "One node per leaf/application/equality/connective/falsity/individual quantifier; all universal closures included; negation and 1 expanded.",
        "parameters": {
            "k": "Number of frozen recursion parameters; k >= 0.",
            "m": "Seed plus frozen recursion parameters: m = k + 1.",
            "q": "Number of frozen arguments of the schema term/formula; q >= 0. A separately quantified fresh probe is excluded.",
        },
        "formulas_in_k_q": {
            "new_root_total": "6*k + 7*q + 53",
            "prior_qf_opaque_total": "6*k + 5*q + 38",
            "prior_two_equations_total": "6*k + 17*q + 77",
            "prior_fresh_comparator_display": "6*k + 5*q + 46",
            "prior_fresh_comparator_with_bodies": "6*k + 5*q + 54",
            "prior_implicit_fresh_inline_display": "6*k + 6*q + 50",
            "prior_implicit_fresh_inline_with_bodies": "6*k + 6*q + 52",
        },
        "comparability_notes": [
            "Root and Two are expanded term schemata; QFI uses an opaque arbitrary quantifier-free formula application.",
            "The 94-to-60 comparison fixes k=0,q=1 in both expanded term schemata.",
            "The 43-node QFI display fixes k=0,q=1, while the 54-node fresh-comparator subtotal commonly fixes k=0,q=0.",
            "The 52-node fresh-inline combination fixes k=0,q=0; at k=0,q=1 its subtotal is 58.",
            "Fresh-inline normalization was explicitly available in the prior successor-comparison draft; its combination is not claimed as a new proof mechanism.",
            "Arbitrary substituted bodies, names, arity/binding metadata, schema enumerators and proof calculi are not counted.",
            "All finite parameter arities remain part of the effective infinite specification; one row is not the whole theory.",
        ],
        "rows": rows,
        "representative_trees_k0_q1": {
            "computation": [n.tree() for n in computation(1, "ordinary")],
            "separation": separation().tree(),
            "root": induction_schema(1, "root").tree(),
            "qf_opaque": induction_schema(1, "qf_opaque").tree(),
            "two_equations": induction_schema(1, "two_equations").tree(),
            "fresh_comparator": fresh_probe_schema(1, False).tree(),
            "fresh_inline": fresh_probe_schema(1, True).tree(),
        },
        "helper_body_trees": {name: tree.tree() for name, tree in helper_bodies(False).items()},
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "rows": len(rows), "output": str(args.output)}))


if __name__ == "__main__":
    main()
