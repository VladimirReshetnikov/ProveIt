A SMALLER INDUCTION SCHEMA FOR PRIMITIVE RECURSIVE ARITHMETIC
Prepared for Vladimir Reshetnikov, 1 November 2026

START HERE

report.pdf is the complete manuscript; report.tex is its standalone
editable LaTeX source. AXIOMS.txt gives the exact effective theory.

MAIN RESULT

Use ordinary initialized recursion, 0 != S0, and only the schema

  [forall n ((n=0 OR s(n)=t(n)) -> s(Sn)=t(Sn))]
      -> forall n (n=0 OR s(n)=t(n)),

with arbitrary finite parameters and term descriptions.

This is definitionally equivalent to first-order PRA, separately with
classical and intuitionistic logic. Both interpretations use the full
carrier, native equality, and internally proved identity round trips.

WHAT IS NEW RELATIVE TO THE SIX REVIEWED DRAFTS

The preceding restricted-induction draft allowed s=t OR u=v.
Only n=0 OR s=t is necessary: one arbitrary equation and one fixed
zero case, with no separate base premise or selected comparison program.

Equivalently, single-equation induction plus the ONE fixed sentence
x=0 OR x=S(p(x)) yields all quantifier-free induction.
The key new proof derives the balance identity

  d(x,y)+y = d(y,x)+x

with atomic induction and a compensating recursion, so native equality
can be recognized without the previous disjunctive comparison induction.

This is a structural simplification, not a global minimum claim.
The full report discloses the earlier shorter opaque QFI display and
the implicit 52-node fresh-inline combination. It does not claim to
settle the earlier stationary-only candidate.

CONTENTS

report.tex / report.pdf        Complete specification and proofs
AXIOMS.txt                    Concise standalone exact axiomatization
build.py                      Offline rebuild and optional Lean replay
formal/AtomicCover.lean        Checked arbitrary-carrier constructive kernel
formal/AtomicCover.log         Seventeen successful dependency audits
formal/SCOPE.txt               Exact formalization assumptions and limits
formal/verification.json       Compiler result and source hash
artifacts/*.py                 Fresh standard-library diagnostics and ledger
artifacts/*.json               Reproducible diagnostic results and ASTs
audit/source_manifest.json     Six immutable input archives and hashes
audit/mathematical_review.txt  Independent mathematical review
audit/validation.json          Build and visual-review record
SHA256SUMS.txt                 Integrity hashes for the release payload

REBUILD

Python 3.10+ and standard TeX Live packages listed in report.tex suffice.
No network access, bibliography tool, or shell escape is required.

  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only

Optional replay with Lean 4.19.0 and its bundled Std library:

  python3 build.py --lean /absolute/path/to/lean

Or, from the formal directory:

  lean AtomicCover.lean

No Mathlib dependency is needed. Build output is kept in _build.

VERIFY DELIVERED BYTES

  sha256sum -c SHA256SUMS.txt

Verify before rebuilding: PDF metadata and regenerated build logs may
change on replay even when the mathematical content is unchanged.
No source ZIPs or compiler binaries are needed for the release checks.

VERIFICATION BOUNDARY

The full metatheorems and both signature translations are proved in
the manuscript. The Lean kernel verifies the arbitrary-carrier
bootstrap from the new schema through equality recognition and the
quantifier-free-induction endpoint. It has explicit term-admission and
computation assumptions; it does not formalize the complete concrete
description grammar, proof translations, or bi-interpretation round trips.
All seventeen audited endpoints have no global axiom dependencies;
the stated Basis assumptions remain explicit theorem parameters.

The numerical artifacts check 4,225 input pairs and 278,850 stationarity
transitions, plus endpoints and a deliberately incorrect mutation.
They are diagnostics, not universal or nonstandard-model proofs.

PROVENANCE

All six archives in ProveIt/docs/drafts were retrieved at commit
9db1e0b1a625767ac54321715f5669d75002360e.
The directory's latest update was bd7c1189f8d75f1cf738c156d8c376158de16460.
The repository was read only; no input archive scripts were executed.
The formal kernel credits its adapted portions from the supplied
TwoEquation.lean. The original input archives are not duplicated here.
