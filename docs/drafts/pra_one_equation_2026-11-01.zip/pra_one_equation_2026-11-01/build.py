#!/usr/bin/env python3
"""Offline checks, PDF build, and optional replay of the Lean kernel."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(command, cwd=ROOT):
    result = subprocess.run(
        [str(item) for item in command],
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if result.returncode:
        sys.stderr.write(result.stdout)
        raise RuntimeError(f"Command failed with exit {result.returncode}: {command[0]}")
    return result.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--checks-only", action="store_true")
    modes.add_argument("--pdf-only", action="store_true")
    parser.add_argument("--lean", help="Optional path to Lean 4.19.0")
    args = parser.parse_args()
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)
    results = {}
    if not args.pdf_only:
        for script in ("schema_metrics.py", "check_compensation.py"):
            output = run([sys.executable, ROOT / "artifacts" / script])
            results[script] = {"exit_code": 0}
            print(output.strip())
    if args.lean:
        version = run([args.lean, "--version"]).strip()
        if "version 4.19.0," not in version:
            raise RuntimeError("The recorded proof uses Lean 4.19.0; use that version.")
        output = run([args.lean, "AtomicCover.lean"], cwd=ROOT / "formal")
        (ROOT / "formal" / "AtomicCover.log").write_text(output)
        audits = [line for line in output.splitlines() if "does not depend on any axioms" in line]
        if len(audits) != 17 or "sorryAx" in output:
            raise RuntimeError("Unexpected dependency audit; inspect the complete log.")
        results["lean"] = {"version": version, "exit_code": 0, "audit_count": len(audits)}
        print(f"Lean passed; {len(audits)} endpoints have no global axiom dependencies.")
    if not args.checks_only:
        compiler = shutil.which("pdflatex")
        if compiler is None:
            raise RuntimeError("pdflatex is required to rebuild the PDF.")
        build = ROOT / "_build"
        build.mkdir(exist_ok=True)
        command = [
            compiler, "-no-shell-escape", "-interaction=nonstopmode",
            "-halt-on-error", "-output-directory", build, ROOT / "report.tex"
        ]
        for _ in range(3):
            output = run(command)
        log = (build / "report.log").read_text()
        (audit / "latex_build.log").write_text(log)
        problems = [
            line for line in log.splitlines()
            if "Overfull" in line or "undefined references" in line
            or ("LaTeX Warning: Citation" in line and "undefined" in line)
        ]
        if problems:
            raise RuntimeError("Resolve final TeX warnings before delivery: " + " | ".join(problems))
        shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
        pdf = (ROOT / "report.pdf").read_bytes()
        results["pdf"] = {
            "exit_code": 0, "passes": 3, "bytes": len(pdf),
            "sha256": hashlib.sha256(pdf).hexdigest(),
            "overfull_warnings": 0, "unresolved_references": False,
        }
        print(f"PDF built successfully ({len(pdf):,} bytes).")
    (audit / "build_results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
