"""Measure the entire trusted implementations under a reproducible convention.

No executable code is removed. Only module/function/class docstrings are
removed before ast.unparse supplies one standard formatting convention.
The raw source sizes are also retained, so normalization cannot hide data.
"""

import ast
import hashlib
import io
import json
from pathlib import Path
import sys
import token
import tokenize


ROOT = Path(__file__).resolve().parent
VARIANTS = (
    ("Displayed draft core", "baseline_kernel.py"),
    ("Without reflexivity and weakening", "reflexivity_kernel.py"),
    ("Final bridge calculus", "kernel.py"),
)


class RemoveDocstrings(ast.NodeTransformer):
    def visit_Module(self, node):
        self.generic_visit(node)
        return self.remove_first(node)

    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        return self.remove_first(node)

    def visit_AsyncFunctionDef(self, node):
        self.generic_visit(node)
        return self.remove_first(node)

    def visit_ClassDef(self, node):
        self.generic_visit(node)
        return self.remove_first(node)

    @staticmethod
    def remove_first(node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return node


def measure(path):
    raw = path.read_bytes()
    tree = RemoveDocstrings().visit(ast.parse(raw.decode("utf-8")))
    normalized = ast.unparse(tree) + "\n"
    ignored = {token.ENCODING, token.ENDMARKER, token.INDENT, token.DEDENT,
               token.NEWLINE, token.NL, token.COMMENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
              if t.type not in ignored]
    return {
        "filename": path.name,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "raw_utf8_bytes": len(raw),
        "executable_utf8_bytes": len(normalized.encode("utf-8")),
        "executable_nonempty_lines": sum(bool(line.strip()) for line in normalized.splitlines()),
        "executable_tokens": len(tokens),
        "executable_ast_nodes": sum(1 for _ in ast.walk(tree)),
    }


def main():
    rows = [{"variant": label, **measure(ROOT / filename)} for label, filename in VARIANTS]
    keys = ("raw_utf8_bytes", "executable_utf8_bytes", "executable_nonempty_lines",
            "executable_tokens", "executable_ast_nodes")
    baseline, final = rows[0], rows[-1]
    reduction = {key: {"absolute": baseline[key] - final[key],
                       "percent": round(100 * (baseline[key] - final[key]) / baseline[key], 4)}
                 for key in keys}
    assert all(final[key] < baseline[key] for key in keys)
    assert all(final[key] < rows[1][key] for key in keys)
    result = {
        "python_version": sys.version.split()[0],
        "accounting": "Entire standalone checker including fixed arithmetic data and validation. "
                      "Executable metrics remove only docstrings, then use ast.unparse. "
                      "No proof generator, parser driver, tests, or project module is imported by the kernels.",
        "comparison_scope": "Matched implementations of the common displayed calculus; "
                            "not literal checkers for all six archival serialization formats or a universal minimum.",
        "variants": rows,
        "baseline_to_final_reduction": reduction,
    }
    (ROOT / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = [r"\begin{center}\small",
             r"\begin{tabular}{@{}lrrrr@{}}",
             r"\toprule",
             r"Complete checker & Raw bytes & Executable bytes & Tokens & AST nodes\\",
             r"\midrule"]
    labels = ("Original logical core", "Two rule deletions", "Final bridge calculus")
    for label, row in zip(labels, rows):
        lines.append(f"{label} & {row['raw_utf8_bytes']:,} & {row['executable_utf8_bytes']:,} "
                     f"& {row['executable_tokens']:,} & {row['executable_ast_nodes']:,}" + r"\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    lines.append(f"The final checker removes {reduction['executable_ast_nodes']['absolute']} executable AST nodes "
                 f"({reduction['executable_ast_nodes']['percent']:.2f}\\%), "
                 f"{reduction['executable_tokens']['absolute']} tokens, and "
                 f"{reduction['executable_utf8_bytes']['absolute']} normalized UTF-8 bytes "
                 "relative to the matched original logical core.")
    lines.append(f"It has {final['executable_nonempty_lines']} nonempty lines after standard formatting, "
                 f"versus {baseline['executable_nonempty_lines']}. "
                 f"Measurements used Python {result['python_version']}.")
    (ROOT / "metrics_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
