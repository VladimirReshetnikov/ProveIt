"""Rebuild all verification summaries and the report; no shell escape."""

from pathlib import Path
import json
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def run(command, log):
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    log.write_text(result.stdout + result.stderr)
    if result.returncode:
        raise SystemExit(f"Failed ({result.returncode}); see {log}")
    return result


def main():
    artifacts = ROOT / "artifacts"
    artifacts.mkdir(exist_ok=True)
    run([sys.executable, "tests.py"], artifacts / "tests_stdout.txt")
    run([sys.executable, "measure.py"], artifacts / "measure_stdout.txt")
    test = json.loads((ROOT / "test_results.json").read_text())
    rows = (
        ("Mathematical proof certificates", test["certificate_count"]),
        ("Acceptance checks, including JSON replay", test["accepted_checks"]),
        ("Forged or malformed certificates rejected", test["rejected_checks"]),
        ("Translated replays in the original baseline", test["translated_baseline_replays"]),
        ("Finite substitution and lifting diagnostics", test["semantic_checks"]["total"]),
    )
    tex = [r"\begin{center}\small", r"\begin{tabular}{@{}lr@{}}",
           r"\toprule", r"Executed validation & Count\\", r"\midrule"]
    tex += [f"{label} & {count:,}" + r"\\" for label, count in rows]
    tex += [r"\bottomrule", r"\end{tabular}", r"\end{center}"]
    (ROOT / "validation_table.tex").write_text("\n".join(tex) + "\n")
    tex_output = artifacts / "tex-build"
    tex_output.mkdir(exist_ok=True)
    for number in range(1, 4):
        run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "-no-shell-escape",
             "-output-directory=" + str(tex_output), "report.tex"],
            artifacts / f"latex_pass_{number}.txt")
    pdf_bytes = (tex_output / "report.pdf").read_bytes()
    if not pdf_bytes.startswith(b"%PDF-") or b"%%EOF" not in pdf_bytes[-128:]:
        raise SystemExit("LaTeX did not leave a complete PDF file.")
    (ROOT / "report.pdf").write_bytes(pdf_bytes)
    log = (tex_output / "report.log").read_text(errors="replace")
    result = {
        "status": "PASS",
        "tests": test["status"],
        "latex_passes": 3,
        "pdf_bytes": len(pdf_bytes),
        "overfull_boxes": len(re.findall(r"Overfull \\[hv]box", log)),
        "undefined_references": "undefined references" in log,
        "undefined_citations": "Citation" in log and "undefined" in log,
        "visual_review": "Recorded separately after rendering; compilation alone is not visual review.",
    }
    (artifacts / "build_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
