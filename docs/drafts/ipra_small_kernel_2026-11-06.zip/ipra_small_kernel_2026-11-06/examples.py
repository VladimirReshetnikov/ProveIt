"""Untrusted proof builders and replayable examples for the small iPRA kernel.

Run ``python3 examples.py`` to regenerate certificates/*.json.  A builder is
never trusted: every emitted finite proof is checked by kernel.check.
"""

from pathlib import Path
import json

import kernel as K


Z = ("0",)
BOT = ("bot",)
HYP = ("hyp",)
R0 = ("r0",)
RS = ("rs",)
AX = ("ax",)


def V(i):
    return ("v", i)


def S(t):
    return ("s", t)


def R(n, a, h):
    return ("r", n, a, h)


def Eq(s, t):
    return ("=", s, t)


def Imp(a, b):
    return ("imp", a, b)


def And(a, b):
    return ("and", a, b)


def Or(a, b):
    return ("or", a, b)


def All(a):
    return ("all", a)


def Ex(a):
    return ("ex", a)


def Q(n, a):
    return R(n, a, V(1))


def P(n):
    return Q(n, Z)


def C(n, a, b):
    return R(n, a, K.shift(b, 2))


def inst(b, *ts):
    return K.instantiate(b, tuple(ts))


def lift(e, by=1, cutoff=0):
    return K.shift(e, by, cutoff)


def refl(t):
    """Q(0,t)=t, used twice in equality elimination, proves t=t."""
    q = Q(Z, t)
    template = Eq(V(0), lift(t))
    return ("eq_e", q, t, template, R0, R0)


def sym(s, t, proof):
    return ("eq_e", s, t, Eq(V(0), lift(s)), proof, refl(s))


def trans(s, t, u, st, tu):
    return ("eq_e", t, u, Eq(lift(s), V(0)), tu, st)


def congr(s, t, proof, term_template):
    """One-slot term context; its other variables are already lifted."""
    start = inst(term_template, s)
    formula_template = Eq(lift(start), term_template)
    return ("eq_e", s, t, formula_template, proof, refl(start))


def collapse_equation(s, t, collapse):
    """Prove s=t from 0=S0, using two transports and selector computation."""
    one = S(Z)
    selector_one = C(one, s, t)
    template = Eq(C(V(0), lift(s), lift(t)), lift(s))
    selector_equals_s = ("eq_e", Z, one, template, collapse, R0)
    return ("eq_e", selector_one, s, Eq(V(0), lift(t)), selector_equals_s, RS)


def explosion_under_bottom(formula):
    """Derive any formula in a context containing genuine BOT."""
    tag = formula[0]
    if tag == "bot":
        return HYP
    if tag == "=":
        collapse = ("imp_e", BOT, AX, HYP)
        return collapse_equation(formula[1], formula[2], collapse)
    if tag == "and":
        return ("and_i", explosion_under_bottom(formula[1]),
                explosion_under_bottom(formula[2]))
    if tag == "or":
        return ("or_i", 0, explosion_under_bottom(formula[1]))
    if tag == "imp":
        return ("imp_i", explosion_under_bottom(formula[2]))
    if tag == "all":
        return ("all_i", explosion_under_bottom(formula[1]))
    if tag == "ex":
        return ("ex_i", Z, explosion_under_bottom(inst(formula[1], Z)))
    raise ValueError("Not a formula")


def blast(formula, bottom_proof):
    """Use the derived BOT -> formula theorem, so no proof lifting is needed."""
    theorem = ("imp_i", explosion_under_bottom(formula))
    return ("imp_e", BOT, theorem, bottom_proof)


def successor_instance(equation):
    """Replace the template variable by its successor, retaining parameters."""
    return inst(lift(equation, 1, 1), S(V(0)))


def equation_induction(equation):
    """Derive the full contextual equation-induction implication.

    If E has one template slot followed by n parameters, return a proof of
      E(0) -> (forall x (E(x) -> E(Sx))) -> forall x E(x)
    in the n-parameter context.  No induction axiom other than SP is used.
    """
    base = inst(equation, Z)
    progress = All(Imp(equation, successor_instance(equation)))
    # First enter the universally quantified target, then SP's eigenvariable.
    e_sp = lift(equation, 1, 1)
    guard = Or(Eq(V(0), Z), e_sp)
    transport_template = lift(e_sp, 1, 1)
    zero_branch = (
        "eq_e", Z, V(0), transport_template,
        sym(V(0), Z, HYP), HYP,
    )
    present = ("or_e", guard, HYP, zero_branch, HYP)
    progress_twice_lifted = lift(progress, 2)
    next_step = (
        "imp_e", e_sp,
        ("all_e", progress_twice_lifted[1], V(0), HYP), present,
    )
    sp = ("sp", e_sp, V(0), next_step)
    target_equation = inst(e_sp, V(0))
    target_guard = Or(Eq(V(0), Z), target_equation)
    target_zero_branch = (
        "eq_e", Z, V(0), e_sp, sym(V(0), Z, HYP), HYP,
    )
    result = ("or_e", target_guard, sp, target_zero_branch, HYP)
    return ("imp_i", ("imp_i", ("all_i", result)))


def induction_formula(equation):
    return Imp(
        inst(equation, Z),
        Imp(All(Imp(equation, successor_instance(equation))), All(equation)),
    )


def apply_equation_induction(equation, base_proof, progress_proof):
    base = inst(equation, Z)
    progress = All(Imp(equation, successor_instance(equation)))
    after_base = ("imp_e", base, equation_induction(equation), base_proof)
    return ("imp_e", progress, after_base, progress_proof)


def close(formula, proof, variable_count):
    for _ in range(variable_count):
        formula = All(formula)
        proof = ("all_i", proof)
    return formula, proof


def certificate(name, formula, proof, variables=0, context=(), description=""):
    return {
        "name": name,
        "description": description,
        "variables": variables,
        "context": list(context),
        "conclusion": formula,
        "proof": proof,
    }


def examples():
    out = []

    def add(name, a, p, variables=0, context=(), description=""):
        out.append(certificate(name, a, p, variables, context, description))

    # The body has two recursor binders and captures its outer argument.
    nested = R(V(0), S(Z), R(V(1), V(0), S(V(2))))
    a, p = close(Eq(nested, nested), refl(nested), 1)
    add("derived_reflexivity_nested", a, p,
        description="Reflexivity is derived from base computation and equality transport, including nested recursors.")

    x, y, z = V(2), V(1), V(0)
    a = Imp(Eq(x, y), Imp(Eq(y, z), Eq(x, z)))
    p = ("imp_i", ("imp_i", trans(x, y, z, HYP, HYP)))
    a, p = close(a, p, 3)
    add("equality_transitivity", a, p)
    a, p = close(Imp(Eq(V(1), V(0)), Eq(V(0), V(1))),
                 ("imp_i", sym(V(1), V(0), HYP)), 2)
    add("equality_symmetry", a, p)

    a, p = close(Eq(P(S(V(0))), V(0)), RS, 1)
    add("predecessor_successor", a, p)
    add("predecessor_zero", Eq(P(Z), Z), R0)

    x, y = V(1), V(0)
    psx, psy = P(S(x)), P(S(y))
    transported = congr(S(x), S(y), HYP, P(V(0)))
    first = trans(x, psx, psy, sym(psx, x, RS), transported)
    inj = trans(x, psy, y, first, RS)
    a, p = close(Imp(Eq(S(x), S(y)), Eq(x, y)), ("imp_i", inj), 2)
    add("successor_injective", a, p,
        description="Successor injectivity follows from predecessor computation, without induction.")

    x = V(0)
    p_sx, p_z = P(S(x)), P(Z)
    transported = congr(S(x), Z, HYP, P(V(0)))
    x_to_pz = trans(x, p_sx, p_z, sym(p_sx, x, RS), transported)
    x_to_zero = trans(x, p_z, Z, x_to_pz, R0)
    sx_to_one = congr(x, Z, x_to_zero, S(V(0)))
    zero_to_one = trans(Z, S(x), S(Z), sym(S(x), Z, HYP), sx_to_one)
    absurd = ("imp_e", Eq(Z, S(Z)), AX, zero_to_one)
    a, p = close(Imp(Eq(S(x), Z), BOT), ("imp_i", absurd), 1)
    add("successor_nonzero", a, p,
        description="The separation axiom and predecessor equations prove every successor is nonzero.")

    e = Eq(S(P(V(0))), V(0))
    premise = congr(P(S(V(0))), V(0), RS, S(V(0)))
    a = All(Or(Eq(V(0), Z), e))
    p = ("all_i", ("sp", e, V(0), premise))
    add("constructor_coverage", a, p,
        description="SP derives x=0 or S(pred(x))=x with no unproved domain-coverage assumption.")

    # A parameter-containing induction theorem exercises all scope shifts.
    e = Eq(R(V(0), V(1), V(0)), V(1))
    a, p = close(induction_formula(e), equation_induction(e), 1)
    add("derived_equation_induction", a, p,
        description="A full equation-induction instance is derived from SP, retaining its initializer parameter.")
    r_x = R(V(0), V(1), V(0))
    r_sx = R(S(V(0)), V(1), V(0))
    step = trans(r_sx, r_x, V(1), RS, HYP)
    progress = ("all_i", ("imp_i", step))
    identity = apply_equation_induction(e, R0, progress)
    a, p = close(All(e), identity, 1)
    add("identity_update_recursion", a, p,
        description="For all a and n, rec(n,a;u,v.u)=a, using the derived equation-induction rule.")

    # A nontrivial recurrence identity needs transport of the induction hypothesis.
    e = Eq(R(V(0), Z, S(V(0))), V(0))
    r_x = R(V(0), Z, S(V(0)))
    r_sx = R(S(V(0)), Z, S(V(0)))
    step = trans(r_sx, S(r_x), S(V(0)), RS,
                 congr(r_x, V(0), HYP, S(V(0))))
    identity = apply_equation_induction(e, R0, ("all_i", ("imp_i", step)))
    add("successor_iteration_from_zero", All(e), identity,
        description="For every n, iterating successor n times from zero yields n.")

    # Native recursor substitution must capture free numerical parameters.
    # This is not rewriting a frozen description: the outer slot is active.
    body = Eq(R(S(Z), Z, V(2)), V(0))
    universal = All(body)
    p_universal = ("all_i", RS)
    captured = inst(body, S(S(Z)))
    add("captured_parameter_substitution", captured,
        ("all_e", body, S(S(Z)), p_universal),
        description="Universal instantiation replaces a recursor body's free parameter while preserving its local slots.")

    # A nested recursor body uses the outer state as a captured parameter.
    h = R(S(Z), Z, V(2))
    lhs = R(S(Z), S(Z), h)
    # The body of rhs must refer to the captured outer state under its own binders.
    rhs = inst(h, R(Z, S(Z), h), Z)
    add("nested_recursor_step", Eq(lhs, rhs), RS,
        description="The simultaneous state/counter substitution traverses a nested binder without capture.")

    # Logical replay examples cover every ordinary connective and quantifier.
    A, B, C = Eq(V(2), Z), Eq(V(1), Z), Eq(V(0), Z)
    con = And(A, B)
    swap = ("and_i", ("and_e", 1, con, HYP), ("and_e", 0, con, HYP))
    a, p = close(Imp(con, And(B, A)), ("imp_i", swap), 3)
    add("conjunction_commutes", a, p)
    dis = Or(A, B)
    swap = ("or_e", dis, HYP, ("or_i", 1, HYP), ("or_i", 0, HYP))
    a, p = close(Imp(dis, Or(B, A)), ("imp_i", swap), 3)
    add("disjunction_commutes", a, p)

    body = Eq(V(0), V(0))
    existential = Ex(body)
    witness = ("ex_i", Z, refl(Z))
    add("existential_reflexivity", existential, witness)
    # Eliminate an existential, but return an independent theorem.
    a = Imp(existential, Eq(Z, Z))
    p = ("imp_i", ("ex_e", body, HYP, refl(Z)))
    add("existential_elimination", a, p)

    conclusion = All(Ex(Eq(V(1), V(0))))
    a = Imp(BOT, conclusion)
    add("genuine_falsity_explosion", a, ("imp_i", blast(conclusion, HYP)),
        description="Full explosion is derived from the fixed falsity bridge and recursor equations, for quantified conclusions.")
    conclusion = And(Or(Eq(V(0), Z), BOT), Imp(Eq(V(0), S(Z)), All(Eq(V(0), V(1)))))
    a, p = close(Imp(BOT, conclusion), ("imp_i", blast(conclusion, HYP)), 1)
    add("derived_explosion_all_connectives", a, p,
        description="A second derived explosion certificate covers conjunction, disjunction, implication, quantification, and arithmetic parameters.")

    return out


def write_certificates(directory=None):
    directory = Path(directory or Path(__file__).with_name("certificates"))
    directory.mkdir(parents=True, exist_ok=True)
    rows = []
    for item in examples():
        ok = K.check(item["variables"], item["context"], item["conclusion"], item["proof"])
        if not ok:
            raise AssertionError("Kernel rejected generated certificate: " + item["name"])
        path = directory / (item["name"] + ".json")
        path.write_text(json.dumps(item, indent=2) + "\n")
        rows.append({"name": item["name"], "accepted": True, "bytes": path.stat().st_size})
    return rows


if __name__ == "__main__":
    print(json.dumps(write_certificates(), indent=2))
