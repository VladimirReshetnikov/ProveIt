"""Replay proof certificates, reject forged evidence, and check capture semantics.

The finite semantic checks are diagnostics.  They do not establish the global
equivalence theorem or formally verify this Python implementation.
"""

from pathlib import Path
import hashlib
import itertools
import json

import kernel as K
import baseline_kernel as B
import examples as E


def run():
    accepted = []
    rejected = []
    checks = E.examples()

    def yes(name, n, context, conclusion, proof):
        if K.check(n, context, conclusion, proof) is not True:
            raise AssertionError("Expected acceptance: " + name)
        accepted.append(name)

    def no(name, n, context, conclusion, proof):
        if K.check(n, context, conclusion, proof) is not False:
            raise AssertionError("Expected rejection: " + name)
        rejected.append(name)

    for item in checks:
        yes(item["name"], item["variables"], item["context"],
            item["conclusion"], item["proof"])
        legacy = to_baseline(item["variables"], tuple(item["context"]),
                             item["conclusion"], item["proof"])
        if not B.check(item["variables"], item["context"],
                       item["conclusion"], legacy):
            raise AssertionError("Conservative baseline rejected " + item["name"])
        # Actual weakening by unchanged proof reuse, without a W constructor.
        extra = E.All(E.Eq(E.V(0), E.V(0)))
        yes(item["name"] + "_with_extra_assumption", item["variables"],
            item["context"] + [extra], item["conclusion"], item["proof"])

    # Replay the serialized, user-facing proof trees too.
    certificate_results = E.write_certificates()
    for item in certificate_results:
        path = Path(__file__).with_name("certificates") / (item["name"] + ".json")
        data = json.loads(path.read_text())
        yes(item["name"] + "_json_replay", data["variables"], data["context"],
            data["conclusion"], data["proof"])

    z, one, v = E.Z, E.S(E.Z), E.V(0)
    true = E.Eq(z, z)
    no("removed_reflexivity_tag", 0, [], true, ("refl",))
    no("removed_weakening_tag", 0, [], true, ("weak", (), E.refl(z)))
    no("removed_explosion_tag", 0, [E.BOT], true, ("bot_e", E.HYP))
    no("removed_separation_tag", 0, [], E.Imp(E.Eq(z, one), E.BOT), ("sep",))
    no("bridge_is_not_bottom", 0, [], E.BOT, E.AX)
    no("forged_separation_antecedent", 0, [], E.Imp(true, E.BOT), E.AX)
    no("false_reflexive_computation", 0, [], E.Eq(z, one), E.R0)
    no("base_rule_at_successor", 0, [], E.Eq(E.R(one, z, E.V(1)), z), E.R0)
    no("wrong_base_value", 0, [], E.Eq(E.R(z, one, E.V(1)), z), E.R0)
    no("step_rule_at_zero", 0, [], E.Eq(E.R(z, one, E.V(1)), one), E.RS)
    no("state_and_counter_swapped", 0, [], E.Eq(E.R(one, one, E.V(0)), z), E.RS)
    no("omitted_counter_substitution", 0, [], E.Eq(E.R(one, one, E.V(1)), one), E.RS)
    no("implicit_multi_step_conversion", 0, [], E.Eq(E.R(one, one, E.V(0)), one), E.RS)

    # A wrong lift underneath an inner recursor changes the captured parameter.
    h = E.R(one, z, E.V(2))
    lhs = E.R(one, v, h)
    correct_rhs = E.R(one, z, E.R(z, E.V(2), h))
    wrong_rhs = E.R(one, z, E.R(z, E.V(0), h))
    yes("nested_capture_correct_literal", 1, [], E.Eq(lhs, correct_rhs), E.RS)
    no("nested_capture_wrong_literal", 1, [], E.Eq(lhs, wrong_rhs), E.RS)

    # Universal instantiation must substitute into a recursor's captured body.
    body = E.Eq(E.R(one, z, E.V(2)), E.V(0))
    witness = E.S(v)
    wrong_claim = E.Eq(E.R(one, z, E.V(2)), witness)
    proof = ("all_e", body, witness, ("all_i", E.RS))
    no("treating_captured_body_as_frozen_metadata", 1, [], wrong_claim, proof)
    correct_claim = E.Eq(E.R(one, z, E.S(E.V(2))), witness)
    yes("captured_body_parameter_changes", 1, [], correct_claim, proof)

    # Eigenvariables are new slots, never existing ambient parameters.
    no("universal_eigenvariable_leaks", 1, [E.Eq(v, z)],
       E.All(E.Eq(E.V(0), z)), ("all_i", E.HYP))
    body = E.Eq(E.V(0), z)
    major = ("ex_i", z, E.refl(z))
    no("existential_witness_leaks", 1, [], E.Eq(v, z),
       ("ex_e", body, major, E.HYP))
    no("existential_out_of_scope_witness", 0, [], E.Ex(E.Eq(E.V(0), E.V(0))),
       ("ex_i", E.V(0), E.refl(E.V(0))))

    # If SP shifted parameter slot 1 down to the new induction slot 0,
    # this fake proof would derive pred(1)=a for every a. The actual kernel
    # keeps a fixed, and rejects the alleged computation premise.
    equation = E.Eq(E.P(E.V(0)), E.V(1))
    conclusion = E.Or(E.Eq(one, z), E.Eq(E.P(one), v))
    no("sp_parameter_drift", 1, [], conclusion, ("sp", equation, one, E.RS))
    equation = E.Eq(E.P(E.V(0)), z)
    target = E.S(one)
    conclusion = E.Or(E.Eq(target, z), E.Eq(E.P(target), z))
    no("sp_ambient_assumption_leaks_eigenvariable", 1,
       [E.Eq(E.P(E.S(v)), z)], conclusion,
       ("sp", equation, target, E.HYP))
    not_equation = E.All(E.Eq(E.V(0), E.V(0)))
    no("sp_restricted_to_equations", 0, [], E.Or(true, not_equation),
       ("sp", not_equation, z, ("all_i", E.refl(E.V(0)))))

    # Equality transport must use precisely its declared formula template.
    no("equality_transport_wrong_result", 1, [E.Eq(v, z)], E.Eq(v, one),
       ("eq_e", v, z, E.Eq(E.V(0), E.V(1)), E.HYP, E.refl(v)))
    no("hypothesis_does_not_reverse_equality", 1, [E.Eq(v, z)], E.Eq(z, v), E.HYP)
    no("equality_template_out_of_scope", 0, [], true,
       ("eq_e", z, z, E.Eq(E.V(1), z), E.refl(z), E.refl(z)))

    no("unknown_rule", 0, [], true, ("oracle",))
    no("extra_rule_fields", 0, [], E.Imp(E.Eq(z, one), E.BOT), ("ax", "ignored"))
    no("negative_scope", -1, [], true, E.refl(z))
    no("boolean_scope", True, [], true, E.refl(z))
    no("float_scope", 0.0, [], true, E.refl(z))
    no("negative_variable", 1, [], E.Eq(E.V(-1), E.V(-1)), E.refl(E.V(-1)))
    no("escaped_variable", 0, [], E.Eq(v, v), E.refl(v))
    no("boolean_variable_index", 2, [], E.Eq(E.V(True), E.V(True)), E.refl(E.V(True)))
    no("float_variable_index", 2, [], E.Eq(E.V(0.0), E.V(0.0)), E.refl(E.V(0.0)))
    no("escaped_recursor_body_variable", 0, [], E.Eq(E.R(z, z, E.V(2)), z), E.R0)
    no("escaped_quantified_variable", 0, [], E.All(E.Eq(E.V(1), E.V(1))),
       ("all_i", E.refl(E.V(1))))
    no("malformed_term_extra_child", 0, [], E.Eq(("0", z), z), E.R0)
    no("malformed_formula_extra_child", 0, [], ("bot", z), ("sep",))
    no("formula_in_term_position", 0, [], E.Eq(E.BOT, E.BOT), E.R0)
    no("integer_in_formula_position", 0, [], 0, E.HYP)
    no("dictionary_input", 0, [], {"tag": "="}, E.HYP)
    no("null_input", 0, [], None, E.HYP)
    no("string_context", 0, "not a context", true, E.refl(z))
    no("bad_projection_index", 0, [], true,
       ("and_e", 2, E.And(true, true), ("and_i", E.refl(z), E.refl(z))))
    no("boolean_projection_index", 0, [], true,
       ("and_e", True, E.And(true, true), ("and_i", E.refl(z), E.refl(z))))
    no("no_classical_double_negation_rule", 0, [], E.BOT, ("dne", E.HYP))
    cyclic = []
    cyclic.append(cyclic)
    no("cyclic_certificate_container", 0, [], true, cyclic)

    semantic = semantic_checks()
    kernel_path = Path(K.__file__)
    result = {
        "status": "PASS",
        "scope": "Actual finite proof replay, malformed-evidence rejection, and finite substitution diagnostics; not a formal metatheorem verification.",
        "kernel_sha256": hashlib.sha256(kernel_path.read_bytes()).hexdigest(),
        "certificate_count": len(checks),
        "translated_baseline_replays": len(checks),
        "accepted_checks": len(accepted),
        "rejected_checks": len(rejected),
        "accepted": accepted,
        "rejected": rejected,
        "semantic_checks": semantic,
    }
    Path(__file__).with_name("test_results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("accepted", "rejected")}, indent=2))
    return result


def to_baseline(scope, context, claim, proof):
    """Untrusted finite proof conversion, replayed by the baseline checker.

    Only the two fixed axiom leaves change.  Goal propagation tells which
    direction of the bridge is used.  The converter is not part of either
    trusted kernel and no claim about its general correctness is assumed.
    """
    rule = proof[0]

    def go(a, p, n=scope, g=context):
        return to_baseline(n, g, a, p)

    if rule == "ax":
        if claim == E.Imp(E.Eq(E.Z, E.S(E.Z)), E.BOT):
            return ("sep",)
        if claim == E.Imp(E.BOT, E.Eq(E.Z, E.S(E.Z))):
            return ("imp_i", ("bot_e", E.HYP))
        raise ValueError("Unknown fixed bridge direction")
    if rule in ("hyp", "r0", "rs"):
        return proof
    if rule == "and_i":
        return (rule, go(claim[1], proof[1]), go(claim[2], proof[2]))
    if rule == "and_e":
        i, source, premise = proof[1:]
        return (rule, i, source, go(source, premise))
    if rule == "or_i":
        i, premise = proof[1:]
        return (rule, i, go(claim[i + 1], premise))
    if rule == "or_e":
        source, major, left, right = proof[1:]
        return (rule, source, go(source, major),
                go(claim, left, g=context + (source[1],)),
                go(claim, right, g=context + (source[2],)))
    if rule == "imp_i":
        return (rule, go(claim[2], proof[1], g=context + (claim[1],)))
    if rule == "imp_e":
        antecedent, major, minor = proof[1:]
        return (rule, antecedent, go(E.Imp(antecedent, claim), major), go(antecedent, minor))
    if rule == "all_i":
        lifted = tuple(E.lift(a) for a in context)
        return (rule, go(claim[1], proof[1], n=scope + 1, g=lifted))
    if rule == "all_e":
        body, witness, premise = proof[1:]
        return (rule, body, witness, go(E.All(body), premise))
    if rule == "ex_i":
        witness, premise = proof[1:]
        return (rule, witness, go(E.inst(claim[1], witness), premise))
    if rule == "ex_e":
        body, major, minor = proof[1:]
        lifted = tuple(E.lift(a) for a in context)
        return (rule, body, go(E.Ex(body), major),
                go(E.lift(claim), minor, n=scope + 1, g=lifted + (body,)))
    if rule == "eq_e":
        s, t, body, equality, premise = proof[1:]
        return (rule, s, t, body, go(E.Eq(s, t), equality), go(E.inst(body, s), premise))
    if rule == "sp":
        equation, target, premise = proof[1:]
        lifted = tuple(E.lift(a) for a in context)
        rooted = E.Or(E.Eq(E.V(0), E.Z), equation)
        return (rule, equation, target,
                go(E.successor_instance(equation), premise,
                   n=scope + 1, g=lifted + (rooted,)))
    raise ValueError("Unknown final-kernel certificate form: " + rule)


def evaluate(term, environment):
    """Independent numerical semantics: a direct primitive-recursion loop."""
    tag = term[0]
    if tag == "v":
        return environment[term[1]]
    if tag == "0":
        return 0
    if tag == "s":
        return evaluate(term[1], environment) + 1
    if tag == "r":
        count = evaluate(term[1], environment)
        state = evaluate(term[2], environment)
        if count > 10000:
            raise ValueError("Diagnostic evaluation budget exceeded")
        for counter in range(count):
            state = evaluate(term[3], (state, counter) + environment)
        return state
    raise ValueError("Invalid term passed to diagnostics")


def semantic_checks():
    z, one = E.Z, E.S(E.Z)
    # Every body below has two removable slots plus one outer parameter.
    bodies = [
        z, E.V(0), E.V(1), E.V(2), E.S(E.V(0)), E.S(E.V(2)),
        E.R(E.V(0), E.V(1), E.S(E.V(0))),
        E.R(E.V(1), E.V(0), E.V(1)),
        E.R(E.V(0), E.V(2), E.V(4)),
        E.R(one, E.V(2), E.R(one, z, E.V(2))),
        E.R(one, E.V(0), E.R(one, E.V(1), E.S(E.V(4)))),
        E.R(one, z, E.R(E.V(1), E.V(0), E.V(4))),
    ]
    replacements = [z, one, E.V(0), E.S(E.V(0)), E.R(one, z, E.V(2))]
    instantiation_count = 0
    for body, left, right, value in itertools.product(bodies, replacements, replacements, range(3)):
        assert K.term(3, body) and K.term(1, left) and K.term(1, right)
        result = K.instantiate(body, (left, right))
        assert K.term(1, result)
        env = (value,)
        lhs = evaluate(result, env)
        rhs = evaluate(body, (evaluate(left, env), evaluate(right, env)) + env)
        assert lhs == rhs, (body, left, right, env, lhs, rhs)
        instantiation_count += 1

    lifting_count = 0
    for body, environment, inserted in itertools.product(
            bodies, itertools.product(range(3), repeat=3), range(3)):
        result = K.shift(body, 1)
        assert K.term(4, result)
        assert evaluate(result, (inserted,) + environment) == evaluate(body, environment)
        lifting_count += 1

    # This checks SP's parameter-retaining substitution against numerical
    # semantics, using an equation whose sides both mention the parameter.
    equation = E.Eq(E.R(E.V(0), E.V(1), E.S(E.V(0))), E.V(1))
    step = E.successor_instance(equation)
    sp_count = 0
    for x, parameter in itertools.product(range(4), repeat=2):
        env = (x, parameter)
        expected_env = (x + 1, parameter)
        for actual, original in zip(step[1:], equation[1:]):
            assert evaluate(actual, env) == evaluate(original, expected_env)
            sp_count += 1
    return {
        "simultaneous_substitution_valuations": instantiation_count,
        "lifting_valuations": lifting_count,
        "sp_fixed_parameter_valuations": sp_count,
        "total": instantiation_count + lifting_count + sp_count,
    }


if __name__ == "__main__":
    run()
