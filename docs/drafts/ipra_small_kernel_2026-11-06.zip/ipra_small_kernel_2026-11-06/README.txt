A SMALLER COMPLETE KERNEL FOR INTUITIONISTIC PRA
6 November 2026
==============================================

MAIN RESULT

The complete calculus uses finite numerical terms

  x | 0 | S(t) | rec(n,a;u,k.h),

where u and k bind the previous state and counter in h. It retains genuine
logical falsity and all first-order connectives and quantifiers.

Primitive logical natural deduction omits equality reflexivity, weakening,
and general falsity elimination. The report derives all three. Arithmetic
has two fixed axioms connecting bottom with 0=S0, the two explicit recursion
equation schemas, and the same equation successor-closure rule shared by
the six current repository drafts. The report proves full-carrier
bi-interpretability and equiconsistency with a precisely specified iPRA.

The final full checker has 2,010 executable Python AST nodes, versus 2,138
for a matched implementation of the original logical core, a 5.99% reduction.
The original baseline already receives the same compact recursion notation
and scope machinery. These are implementation-relative measurements, not a
proved global minimum or measurements of six nonexistent original checkers.

READ FIRST

  report.pdf                  Complete typeset research report and proofs.
  report.tex                  Complete LaTeX source.
  AXIOMS.txt                  Standalone complete calculus specification.
  kernel.py                   Complete trusted checking algorithm.
  independent_review.txt      Independent code review and evidence boundary.
  metrics.json                Reproducible size comparison and source hashes.
  test_results.json           Proof replays and negative tests.
  provenance/source_manifest.json
                              Pinned repository snapshot and archive hashes.

CHECK PROOFS

Python 3.10 or later, standard library only:

  python3 tests.py
  python3 check_certificate.py certificates/*.json

The tests regenerate the nineteen certificate files, replay them with the
final checker, translate them into the original baseline and replay them,
exercise malformed and forged proof rejection, and run finite numerical
substitution diagnostics. The documented run used Python 3.12.14.

API

  import kernel
  accepted = kernel.check(scope, context, conclusion, certificate)

scope is the number of available free numerical slots. All input trees may
be JSON lists or Python tuples. The public entry point rejects malformed
input; helpers are for already validated immutable syntax. No input code
is executed. Certificates contain ordinary finite syntax, not callables.

JSON files contain keys:

  variables, context, conclusion, proof

The optional name and description keys are presentation metadata ignored by
the checker. The certificates' "variables" field is passed as scope.

Syntax and proof constructors are fully documented in kernel.py's opening
docstring. De Bruijn index 0 is the newest number slot. A recursion body
opens state at slot 0 and counter at slot 1; all older slots move up by two.
Quantifier bodies open one new slot. There are no explicit reflexivity,
weakening, general explosion, conversion, or normalization proof tags.

REPRODUCE SIZE COUNTS

  python3 measure.py

This measures the entire standalone kernels, including syntax checks,
scope checks, substitution, fixed arithmetic axioms, rule validation, and
the public rejection wrapper. It reports raw bytes and executable metrics.
For the latter, only docstrings are removed; Python ast.unparse supplies a
shared formatting convention. No executable branch or fixed axiom data is
removed. Exact counts can depend on the Python formatting version.

Comparison variants:

  baseline_kernel.py       Original logical rules and separation axiom.
  reflexivity_kernel.py    Intermediate version removing refl and weakening.
  kernel.py               Final version also deriving general explosion.

BUILD THE REPORT

  python3 build.py

This reruns meaningful checks and measurements, regenerates summary tables,
and invokes pdflatex three times. It writes build logs under artifacts/.
The compilation needs a normal LaTeX installation with amsmath, amsthm,
mathtools, booktabs, tabularx, enumitem, microtype, fancyhdr, hyperref,
listings, geometry, xcolor, and Latin Modern. No shell-escape is enabled.

PROVENANCE

Repository: VladimirReshetnikov/ProveIt
Pinned commit: 86b708a209fd20431908347c5aa051d73c8d4682
Path: docs/drafts
Snapshot date: 6 November 2026

All six current archive byte lengths and Git blob hashes were verified,
and their SHA-256 hashes recorded. Copies of the exact top-level source
specifications are included under provenance/source_specifications/.
The archived reports' older four-draft comparison is not treated as the
current directory contents.

VALIDATION BOUNDARY

The supplied program is a full proof checker, not merely a numerical
diagnostic. Nineteen actual mathematical proof trees are provided.
The universal soundness theorem, formula-reflection theorem, coherent
elaboration, and full bi-interpretability theorem are written mathematical
proofs. They have not been formalized in Lean or Rocq in this package.
Finite numerical tests do not establish these universal metatheorems.

No encoding-independent globally shortest checker is claimed. The result
is the smallest of the explicitly measured straightforward variants and
an explicit reduction of the logical rule table common to all six drafts.
