#!/usr/bin/env python3
"""Reproduce displayed-formula counts. No claim of specification minimality.

One node per variable, constant, application, logical operation, or individual
quantifier. Quantifier bound names label nodes and do not add child nodes.
Function-description indices are labels, not counted subtrees. Schematic term
applications count their displayed arguments, not arbitrary substituted bodies.
"""
from dataclasses import dataclass
from pathlib import Path
import json


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple = ()

    def size(self):
        return 1 + sum(child.size() for child in self.children)

    def equalities(self):
        return int(self.label == '=') + sum(c.equalities() for c in self.children)


def node(label, *children):
    return Node(label, children)


def forall(name, body):
    return node('forall ' + name, body)


def eq(a, b):
    return node('=', a, b)


def imp(a, b):
    return node('implies', a, b)


def either(a, b):
    return node('or', a, b)


def both(a, b):
    return node('and', a, b)


n, a, b, z, bottom = map(node, ['n', 'a', 'b', '0', 'false'])
S = lambda x: node('S', x)
one = S(z)
f = lambda x: node('f', x, a)
g = lambda x: node('g', x, a)
p = lambda x: node('P', x, z)
rho = lambda x: node('rho', x)
sep = imp(eq(z, one), bottom)
E = lambda x: eq(f(x), g(x))
guard = lambda x: either(eq(x, z), E(x))
premise = forall('n', imp(guard(n), E(S(n))))
PI = forall('a', imp(premise, forall('n', guard(n))))
PI_packed = forall('a', imp(premise, both(sep, forall('n', guard(n)))))

AU = forall('a', imp(
    forall('n', eq(f(S(n)), rho(f(n)))),
    both(sep, forall('n', either(eq(n, z),
        eq(f(n), node('J_rho', p(n), f(one))))))))

DU = forall('a', imp(
    forall('n', eq(f(S(n)), rho(f(n)))),
    both(sep, forall('n', either(eq(n, z),
        eq(f(n), rho(node('D_rho', n, f(z)))))))))

CU = forall('a', imp(
    forall('n', eq(f(S(n)), node('h', n, f(n)))),
    both(sep, forall('n', either(eq(n, z),
        eq(f(n), node('I_h', S(p(n)), f(z))))))))

SU = forall('a', imp(
    forall('n', eq(f(S(n)), node('h', n, f(n)))),
    both(sep, forall('n', either(eq(n, z),
        eq(f(n), node('I_h_plus', p(n), f(one))))))))

PC = forall('a', imp(
    forall('n', eq(f(S(S(n))), f(S(n)))),
    forall('n', either(eq(n, z), eq(f(n), f(one))))))

D0 = forall('a', eq(node('I_h', z, a), a))
DS = forall('n', forall('a', eq(node('I_h', S(n), a),
    node('h', n, node('I_h', n, a)))))

formulas = {'PI': PI, 'PI_packed': PI_packed, 'separation': sep,
    'AU': AU, 'DU': DU, 'CU': CU, 'SU': SU, 'PC': PC, 'D0_binary': D0,
    'DS_binary': DS}
expected = {'PI': 36, 'PI_packed': 43, 'separation': 6, 'AU': 36,
    'DU': 34, 'CU': 37, 'SU': 37, 'PC': 26, 'D0_binary': 6,
    'DS_binary': 12}
rows = {name: {'nodes': ast.size(), 'equalities': ast.equalities()}
        for name, ast in formulas.items()}
for name, wanted in expected.items():
    assert rows[name]['nodes'] == wanted, (name, rows[name], wanted)

report = {
    'status': 'PASS',
    'convention': __doc__.strip(),
    'formula_counts': rows,
    'binary_display_totals': {
        'PI_plus_separation': PI.size() + sep.size() + D0.size() + DS.size(),
        'PI_packed': PI_packed.size() + D0.size() + DS.size(),
        'AU': AU.size() + D0.size() + DS.size(),
        'DU_before_descriptor_compiler': DU.size() + D0.size() + DS.size(),
        'CU': CU.size() + D0.size() + DS.size(),
        'SU_before_descriptor_shift': SU.size() + D0.size() + DS.size(),
    },
    'limitations': [
        'No global shortestness theorem.',
        'Full PR grammar and arbitrary parameter tuples have separate costs.',
        'Descriptor compilers and stored program bodies are not counted.',
        'Counts are diagnostics, not mathematical proof verification.'
    ]
}
destination = Path(__file__).with_name('schema_metrics.json')
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
