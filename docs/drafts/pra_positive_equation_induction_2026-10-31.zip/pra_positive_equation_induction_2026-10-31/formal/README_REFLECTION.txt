EQUALITY REFLECTION: MACHINE-CHECKED SCOPE
========================================

File: EqualityReflection.lean
Compiler: Lean 4.19.0
Result: successful compilation; seven printed theorem dependency checks are
empty.  The exact compiler output is retained in EqualityReflection.log.

MAIN ENDPOINT

For an arbitrary carrier A, the file proves

  x = y  iff  M(x,y) = 0 and M(y,x) = 0,

where M(n,a) iterates the supplied predecessor on a, and equality is native
Lean equality on A.  No induction on A is available from Lean.  A is not
identified with Nat and is not assumed to be an inductive datatype.

EXPLICIT COMPUTATION/CONSTRUCTOR ASSUMPTIONS

The Data record supplies 0, successor, predecessor, M, and a conditional C,
together with the exact equations

  p(0)=0, p(Sx)=x,
  M(0,a)=a, M(Sn,a)=p(M(n,a)),
  C(0,a,b)=a, C(Sn,a,b)=b,

constructor coverage x=0 or x=S(p(x)), and 0 != S(0).  In the manuscript
these are obtained from primitive-recursion descriptions and PI.

EXACT INDUCTION ASSUMPTIONS

Four named families of single equational-induction instances are passed
as theorem parameters.  No induction over arbitrary predicates or arbitrary
carrier functions is assumed.

1. ShiftInduction, with one frozen parameter a:

     M(Sn,Sa) = M(n,a).

2. DiagonalInduction, with no frozen parameters:

     M(n,n) = 0.

3. OrbitCodeInduction, with frozen parameters x,y:

     RelCode(M(n,x),M(n,y)) = 1,

   where 1=S(0) and the fixed term

     RelCode(u,v) := C(M(u,v), C(M(v,u),1,0),0)

   is proved in the file to equal 1 exactly when both monus terms are 0.
   Thus this assumption is an equality of finite terms, not a logical
   relation-induction assumption.

4. BackwardInduction, with frozen parameters x,y:

     M(M(n,x),x) = M(M(n,x),y).

Each InductionInstance means that a proof of its particular base equality
and a proof of its particular implication from n to Sn produce that same
equality for every n.  These are exactly the ordinary equational-induction
instances derived from PI in the written proof.  The file constructs all
four base and step proofs from the displayed hypotheses.

METHOD

The first two instances give simultaneous monus shift and diagonal zero.
The zero relation R(u,v):=M(u,v)=0 and M(v,u)=0 forces u and v to be both
zero or both successors.  Consequently R is preserved by applying p to
both arguments, and p is injective on pairs satisfying R.

For fixed R(x,y), the third instance carries R along the predecessor
orbits of x and y.  The fourth instance carries equality backward from
the common zero endpoint to the original pair.  Evaluating it at n=x
uses M(x,x)=0 and yields x=y.

The proof uses no addition, order, maximum, pairing, diagonal scanner,
excluded middle, choice, function extensionality, or propositional
extensionality.  There are no sorry placeholders or additional axioms.

LIMITS

This is a checked mathematical kernel over an arbitrary carrier.  It is
not a complete formalization of first-order syntax, derivability, the PI
axiom generator, the compiler for all quantifier-free formulas, or the
identity bi-interpretability theorem.  Those links and the derivation of
the four named instances are proved in the accompanying manuscript.

The proof uses two frozen numerical parameters in its last two instances.
It directly certifies the full finite-parameter presentation.  It does not
by itself certify parameter coding for the restricted binary presentation
with one arithmetic parameter.

REPRODUCE

  lean --version
  lean EqualityReflection.lean

Run from this directory with Lean 4.19.0.  The file uses only Lean's core
prelude and requires no package download or external library.
