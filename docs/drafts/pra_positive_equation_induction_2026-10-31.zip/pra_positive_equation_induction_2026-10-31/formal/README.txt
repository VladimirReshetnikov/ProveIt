CONSTRUCTIVE LEAN CERTIFICATE
============================

File: PositiveEquation.lean
Lean version: 4.19.0
Dependencies: Lean core only (import Init); no Mathlib dependency.

Run from this directory:

  lean --version
  lean PositiveEquation.lean

The carrier is an arbitrary type. The proofs never invoke induction on that
carrier, Nat.induction, Classical.choice, classical case splitting, excluded
middle, or an unproved declaration. There are no sorry/admit placeholders.

EXACT VERIFIED SCOPE

1. One constant PI instance proves 0 != S(0).
2. The PI instance for f(n)=n and g(n)=S(p(n)), together with p(S(n))=n,
   proves separation and n=0 OR n=S(p(n)).
3. PI for a given pair f,g proves equation induction for that same pair.
4. Equation induction for f(S(n)),g(S(n)), together with coverage and
   separation, proves PI for f,g. No equality f(0)=g(0) is assumed here.
5. Equation induction comparing f(S(n)) with I_h(n,f(S(0))), together with
   the two computation equations, coverage and separation, proves the exact
   binary positive-tail recurrence uniqueness principle from the drafts.
6. The two specifically named PI instances in points 2 and 5 therefore prove
   that positive-tail uniqueness instance.

These are local schematic reductions. Functions on the arbitrary carrier
occur as the interpretations of particular terms, and every required PI or
equation-induction instance is an explicit theorem hypothesis. The file does
not assume a second-order schema over all predicates, does not identify every
semantic function with a primitive-recursive term, and does not silently add
induction for arbitrary subsets of the carrier.

To apply the checked reduction to the manuscript's effective first-order
theory, substitute interpretations of the displayed admitted finite terms.
The source grammar is closed under successor composition and substitution
into iterator applications, so the displayed comparison terms are legal.
Fixed numerical parameters remain fixed throughout the reductions.

NOT CLAIMED TO BE MACHINE CHECKED HERE

The full term grammar and its admissibility judgment; the full first-order
proof calculus; the completion from the restricted iterator language to all
primitive-recursive descriptions; equality reflection; Boolean formula
compilation; parameter coding; and the complete bi-interpretability theorem.
Those results and their proof dependencies are given in the manuscript.
The separate EqualityReflection.lean file checks the reflection kernel;
see README_REFLECTION.txt for its exact scope.

The file prints the axiom dependencies of all seven principal theorems.
Validation succeeded with exit code 0: every one depends on no axioms.
The exact version and compiler output are recorded in lean_version.txt and
validation.log. Their displayed hypotheses remain ordinary theorem parameters; an empty axiom
report does not remove those hypotheses or prove the entire final theory.
