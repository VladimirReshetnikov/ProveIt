/-
EqualityReflection.lean

Constructive verification of the finite predecessor-descent reflection kernel.
The carrier is arbitrary; no induction on the carrier is provided by Lean.
The only induction hypotheses are the FOUR displayed families of equations
below: ShiftInduction, DiagonalInduction, OrbitCodeInduction, BackwardInduction.
They are the exact finite list of equational-induction instances used in the
written proof.  In particular OrbitCodeInduction is an equality of terms,
not induction for an arbitrary logical predicate.

This file does not formalize first-order syntax, the PI schema, the full
formula compiler, or the bi-interpretability theorem.  Those connections are
proved in the manuscript.  All computation, constructor coverage, separation,
and induction assumptions are explicit parameters.  No sorry or axioms.
-/

universe u

namespace PRAEqualityReflection

structure Data (A : Type u) where
  zero : A
  succ : A → A
  pred : A → A
  monus : A → A → A
  cond : A → A → A → A
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  coverage : ∀ x, x = zero ∨ x = succ (pred x)
  separated : zero ≠ succ zero
  monus_zero : ∀ a, monus zero a = a
  monus_succ : ∀ n a, monus (succ n) a = pred (monus n a)
  cond_zero : ∀ a b, cond zero a b = a
  cond_succ : ∀ n a b, cond (succ n) a b = b

variable {A : Type u}

def One (d : Data A) : A := d.succ d.zero

def Rel (d : Data A) (x y : A) : Prop :=
  d.monus x y = d.zero ∧ d.monus y x = d.zero

def RelCode (d : Data A) (x y : A) : A :=
  d.cond (d.monus x y)
    (d.cond (d.monus y x) (One d) d.zero) d.zero

def InductionInstance (d : Data A) (P : A → Prop) : Prop :=
  P d.zero → (∀ n, P n → P (d.succ n)) → ∀ n, P n

def ShiftInduction (d : Data A) : Prop :=
  ∀ a, InductionInstance d
    (fun n => d.monus (d.succ n) (d.succ a) = d.monus n a)

def DiagonalInduction (d : Data A) : Prop :=
  InductionInstance d (fun n => d.monus n n = d.zero)

def OrbitCodeInduction (d : Data A) : Prop :=
  ∀ x y, InductionInstance d
    (fun n => RelCode d (d.monus n x) (d.monus n y) = One d)

def BackwardInduction (d : Data A) : Prop :=
  ∀ x y, InductionInstance d
    (fun n => d.monus (d.monus n x) x = d.monus (d.monus n x) y)

theorem relCode_spec (d : Data A) (x y : A) :
    RelCode d x y = One d ↔ Rel d x y := by
  constructor
  · intro h
    rcases d.coverage (d.monus x y) with hxy | hxy
    · rcases d.coverage (d.monus y x) with hyx | hyx
      · exact ⟨hxy, hyx⟩
      · have hc : RelCode d x y = d.zero := by
          calc
            RelCode d x y = d.cond d.zero
                (d.cond (d.monus y x) (One d) d.zero) d.zero :=
              congrArg (fun k => d.cond k
                (d.cond (d.monus y x) (One d) d.zero) d.zero) hxy
            _ = d.cond (d.monus y x) (One d) d.zero := d.cond_zero _ _
            _ = d.cond (d.succ (d.pred (d.monus y x))) (One d) d.zero :=
              congrArg (fun k => d.cond k (One d) d.zero) hyx
            _ = d.zero := d.cond_succ _ _ _
        have bad : d.zero = One d := hc.symm.trans h
        exact False.elim (d.separated bad)
    · have hc : RelCode d x y = d.zero := by
        calc
          RelCode d x y = d.cond (d.succ (d.pred (d.monus x y)))
              (d.cond (d.monus y x) (One d) d.zero) d.zero :=
            congrArg (fun k => d.cond k
              (d.cond (d.monus y x) (One d) d.zero) d.zero) hxy
          _ = d.zero := d.cond_succ _ _ _
      have bad : d.zero = One d := hc.symm.trans h
      exact False.elim (d.separated bad)
  · rintro ⟨hxy, hyx⟩
    calc
      RelCode d x y = d.cond d.zero
          (d.cond (d.monus y x) (One d) d.zero) d.zero :=
        congrArg (fun k => d.cond k
          (d.cond (d.monus y x) (One d) d.zero) d.zero) hxy
      _ = d.cond (d.monus y x) (One d) d.zero := d.cond_zero _ _
      _ = d.cond d.zero (One d) d.zero :=
        congrArg (fun k => d.cond k (One d) d.zero) hyx
      _ = One d := d.cond_zero _ _

theorem monus_shift (d : Data A) (ind : ShiftInduction d) (n a : A) :
    d.monus (d.succ n) (d.succ a) = d.monus n a := by
  apply ind a
  · calc
      d.monus (d.succ d.zero) (d.succ a)
          = d.pred (d.monus d.zero (d.succ a)) := d.monus_succ _ _
      _ = d.pred (d.succ a) := congrArg d.pred (d.monus_zero _)
      _ = a := d.pred_succ _
      _ = d.monus d.zero a := (d.monus_zero _).symm
  · intro k ih
    calc
      d.monus (d.succ (d.succ k)) (d.succ a)
          = d.pred (d.monus (d.succ k) (d.succ a)) := d.monus_succ _ _
      _ = d.pred (d.monus k a) := congrArg d.pred ih
      _ = d.monus (d.succ k) a := (d.monus_succ _ _).symm

theorem monus_diagonal (d : Data A)
    (shiftInd : ShiftInduction d) (diagInd : DiagonalInduction d) (n : A) :
    d.monus n n = d.zero := by
  apply diagInd
  · exact d.monus_zero _
  · intro k ih
    exact (monus_shift d shiftInd k k).trans ih

theorem rel_pred (d : Data A) (shiftInd : ShiftInduction d)
    (x y : A) (h : Rel d x y) : Rel d (d.pred x) (d.pred y) := by
  rcases d.coverage x with hx | hx
  · have hy : y = d.zero := (d.monus_zero y).symm.trans (hx ▸ h.1)
    subst x
    subst y
    constructor <;> simpa only [d.pred_zero] using d.monus_zero d.zero
  · rcases d.coverage y with hy | hy
    · have hx0 : x = d.zero := (d.monus_zero x).symm.trans (hy ▸ h.2)
      subst x
      subst y
      constructor <;> simpa only [d.pred_zero] using d.monus_zero d.zero
    · constructor
      · calc
          d.monus (d.pred x) (d.pred y)
              = d.monus (d.succ (d.pred x)) (d.succ (d.pred y)) :=
                  (monus_shift d shiftInd _ _).symm
          _ = d.monus x (d.succ (d.pred y)) :=
            congrArg (fun k => d.monus k (d.succ (d.pred y))) hx.symm
          _ = d.monus x y := congrArg (d.monus x) hy.symm
          _ = d.zero := h.1
      · calc
          d.monus (d.pred y) (d.pred x)
              = d.monus (d.succ (d.pred y)) (d.succ (d.pred x)) :=
                  (monus_shift d shiftInd _ _).symm
          _ = d.monus y (d.succ (d.pred x)) :=
            congrArg (fun k => d.monus k (d.succ (d.pred x))) hy.symm
          _ = d.monus y x := congrArg (d.monus y) hx.symm
          _ = d.zero := h.2

theorem pred_injective_on_rel (d : Data A) (x y : A)
    (h : Rel d x y) (hp : d.pred x = d.pred y) : x = y := by
  rcases d.coverage x with hx | hx
  · have hy : y = d.zero := (d.monus_zero y).symm.trans (hx ▸ h.1)
    exact hx.trans hy.symm
  · rcases d.coverage y with hy | hy
    · have hx0 : x = d.zero := (d.monus_zero x).symm.trans (hy ▸ h.2)
      exact hx0.trans hy.symm
    · exact hx.trans ((congrArg d.succ hp).trans hy.symm)

theorem relation_along_orbit (d : Data A)
    (shiftInd : ShiftInduction d) (orbitInd : OrbitCodeInduction d)
    (x y : A) (h : Rel d x y) (n : A) :
    Rel d (d.monus n x) (d.monus n y) := by
  apply (relCode_spec d _ _).mp
  apply orbitInd x y
  · apply (relCode_spec d _ _).mpr
    simpa only [d.monus_zero] using h
  · intro k ih
    have hr := (relCode_spec d _ _).mp ih
    have hr' := rel_pred d shiftInd _ _ hr
    apply (relCode_spec d _ _).mpr
    simpa only [d.monus_succ] using hr'

theorem equality_reflection (d : Data A)
    (shiftInd : ShiftInduction d) (diagInd : DiagonalInduction d)
    (orbitInd : OrbitCodeInduction d) (backInd : BackwardInduction d)
    (x y : A) : x = y ↔ Rel d x y := by
  constructor
  · intro h
    subst y
    exact ⟨monus_diagonal d shiftInd diagInd x,
      monus_diagonal d shiftInd diagInd x⟩
  · intro h
    have backward : ∀ j,
        d.monus (d.monus j x) x = d.monus (d.monus j x) y := by
      apply backInd x y
      · calc
          d.monus (d.monus d.zero x) x = d.monus x x :=
            congrArg (fun k => d.monus k x) (d.monus_zero x)
          _ = d.zero := monus_diagonal d shiftInd diagInd x
          _ = d.monus x y := h.1.symm
          _ = d.monus (d.monus d.zero x) y :=
            congrArg (fun k => d.monus k y) (d.monus_zero x).symm
      · intro j ih
        rcases d.coverage (d.monus j x) with hk | hk
        · have idx : d.monus (d.succ j) x = d.monus j x := by
            calc
              d.monus (d.succ j) x = d.pred (d.monus j x) := d.monus_succ _ _
              _ = d.pred d.zero := congrArg d.pred hk
              _ = d.zero := d.pred_zero
              _ = d.monus j x := hk.symm
          simpa only [idx] using ih
        · let r := d.pred (d.monus j x)
          have hp : d.pred (d.monus r x) = d.pred (d.monus r y) := by
            calc
              d.pred (d.monus r x) = d.monus (d.succ r) x :=
                (d.monus_succ _ _).symm
              _ = d.monus (d.monus j x) x :=
                congrArg (fun k => d.monus k x) hk.symm
              _ = d.monus (d.monus j x) y := ih
              _ = d.monus (d.succ r) y :=
                congrArg (fun k => d.monus k y) hk
              _ = d.pred (d.monus r y) := d.monus_succ _ _
          have hr := relation_along_orbit d shiftInd orbitInd x y h r
          have he := pred_injective_on_rel d _ _ hr hp
          simpa only [d.monus_succ] using he
    have result := backward x
    simpa only [monus_diagonal d shiftInd diagInd x, d.monus_zero] using result

#print axioms relCode_spec
#print axioms monus_shift
#print axioms monus_diagonal
#print axioms rel_pred
#print axioms pred_injective_on_rel
#print axioms relation_along_orbit
#print axioms equality_reflection

end PRAEqualityReflection
