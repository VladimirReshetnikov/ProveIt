import Init

/-!
# Constructive reductions for positive equation induction

Tested with Lean 4.19.0. This file uses only Lean's core library.

The carrier `α` is arbitrary. In particular, no induction principle on the
carrier and no interpretation of the carrier as `Nat` is used.

SCOPE: each hypothesis below supplies one explicitly displayed schematic
instance. The file does NOT assert that arbitrary semantic functions on `α`
are primitive-recursive terms. It does NOT postulate a second-order induction
axiom ranging over all predicates. A syntactic PRA presentation may instantiate
the theorems only when the displayed functions are interpretations of admitted
terms. The theorem statements list every needed instance explicitly.

The checked results are the local schematic reductions:

* a constant PI instance gives separation;
* the identity versus successor-of-predecessor instance gives coverage;
* the PI instance for `f,g` gives ordinary equation induction for `f,g`;
* equation induction for their successor shifts, coverage and separation give
  the PI instance for `f,g`;
* equation induction for a recurrence trajectory and its canonical iterator,
  together with coverage and separation, gives positive-tail uniqueness;
* two specifically named PI instances suffice for that uniqueness reduction.

The full finite-term grammar, its description-indexed iterators, completion to
all primitive-recursive functions, formula compilation, and the final
bi-interpretability theorem are proved in the accompanying manuscript, not
claimed to be formalized here.
-/

set_option autoImplicit false

universe u

namespace PositiveEquation

variable {α : Type u}

/-- One instance of the proposed packed positive equation induction schema. -/
def PI (zero : α) (succ : α → α) (f g : α → α) : Prop :=
  (∀ n, (n = zero ∨ f n = g n) → f (succ n) = g (succ n)) →
    (zero ≠ succ zero ∧ ∀ n, n = zero ∨ f n = g n)

/-- One ordinary equation-induction instance, usable under fixed hypotheses. -/
def EqI (zero : α) (succ : α → α) (f g : α → α) : Prop :=
  f zero = g zero →
    (∀ n, f n = g n → f (succ n) = g (succ n)) →
      ∀ n, f n = g n

/-- Positive constructor coverage using a specified predecessor term. -/
def Coverage (zero : α) (succ pred : α → α) : Prop :=
  ∀ n, n = zero ∨ n = succ (pred n)

/-- Separation follows from the constant-versus-itself PI instance. -/
theorem separation_of_constant_PI
    (zero : α) (succ : α → α)
    (hPI : PI zero succ (fun _ => zero) (fun _ => zero)) :
    zero ≠ succ zero := by
  have hstep : ∀ n,
      (n = zero ∨ (fun _ : α => zero) n = (fun _ : α => zero) n) →
      (fun _ : α => zero) (succ n) = (fun _ : α => zero) (succ n) := by
    intro n h
    rfl
  exact (hPI hstep).1

/-- The single constructor PI instance supplies separation and coverage. -/
theorem constructorData_of_PI
    (zero : α) (succ pred : α → α)
    (predSucc : ∀ n, pred (succ n) = n)
    (hPI : PI zero succ (fun n => n) (fun n => succ (pred n))) :
    zero ≠ succ zero ∧ Coverage zero succ pred := by
  have hstep : ∀ n,
      (n = zero ∨ n = succ (pred n)) →
      succ n = succ (pred (succ n)) := by
    intro n h
    exact (congrArg succ (predSucc n)).symm
  exact hPI hstep

theorem coverage_of_PI
    (zero : α) (succ pred : α → α)
    (predSucc : ∀ n, pred (succ n) = n)
    (hPI : PI zero succ (fun n => n) (fun n => succ (pred n))) :
    Coverage zero succ pred :=
  (constructorData_of_PI zero succ pred predSucc hPI).2

/-- PI for `f,g` yields equation induction for exactly those terms. -/
theorem equationInduction_of_PI
    (zero : α) (succ : α → α) (f g : α → α)
    (hPI : PI zero succ f g) :
    EqI zero succ f g := by
  intro hbase hnext
  have hstep : ∀ n,
      (n = zero ∨ f n = g n) → f (succ n) = g (succ n) := by
    intro n h
    cases h with
    | inl hz =>
        cases hz
        exact hnext zero hbase
    | inr he =>
        exact hnext n he
  have hpositive := (hPI hstep).2
  intro n
  cases hpositive n with
  | inl hz =>
      cases hz
      exact hbase
  | inr he =>
      exact he

/--
The reverse reduction needs equation induction for the successor-shifted
pair. It does not assume the unproved equation `f zero = g zero`.
-/
theorem positiveInduction_of_equationInduction
    (zero : α) (succ pred : α → α) (f g : α → α)
    (hsep : zero ≠ succ zero)
    (hcoverage : Coverage zero succ pred)
    (hEqI : EqI zero succ
      (fun n => f (succ n)) (fun n => g (succ n))) :
    PI zero succ f g := by
  intro hstep
  have hbase : f (succ zero) = g (succ zero) :=
    hstep zero (Or.inl rfl)
  have hnext : ∀ n,
      f (succ n) = g (succ n) →
      f (succ (succ n)) = g (succ (succ n)) := by
    intro n he
    exact hstep (succ n) (Or.inr he)
  have hsuccessors : ∀ n, f (succ n) = g (succ n) :=
    hEqI hbase hnext
  constructor
  · exact hsep
  · intro n
    cases hcoverage n with
    | inl hz =>
        exact Or.inl hz
    | inr hs =>
        apply Or.inr
        exact (congrArg f hs).trans
          ((hsuccessors (pred n)).trans (congrArg g hs).symm)

/--
One positive-tail uniqueness instance. `iter` is the one iterator whose
description is the displayed update `h`; the computation equations occur as
explicit hypotheses of the following theorems.
-/
def PU (zero : α) (succ pred : α → α)
    (iter h : α → α → α) (f : α → α) : Prop :=
  (∀ n, f (succ (succ n)) = h n (f (succ n))) →
    (zero ≠ succ zero ∧
      ∀ n, n = zero ∨ f n = iter (pred n) (f (succ zero)))

/--
Equation induction for the displayed comparison is sufficient for the exact
binary positive-tail recurrence uniqueness schema used by the source drafts.
-/
theorem positiveUniqueness_of_equationInduction
    (zero : α) (succ pred : α → α)
    (iter h : α → α → α) (f : α → α)
    (iterZero : ∀ a, iter zero a = a)
    (iterSucc : ∀ n a, iter (succ n) a = h n (iter n a))
    (hsep : zero ≠ succ zero)
    (hcoverage : Coverage zero succ pred)
    (hEqI : EqI zero succ
      (fun n => f (succ n))
      (fun n => iter n (f (succ zero)))) :
    PU zero succ pred iter h f := by
  intro hrec
  have hbase : f (succ zero) = iter zero (f (succ zero)) :=
    (iterZero (f (succ zero))).symm
  have hnext : ∀ n,
      f (succ n) = iter n (f (succ zero)) →
      f (succ (succ n)) = iter (succ n) (f (succ zero)) := by
    intro n he
    exact (hrec n).trans
      ((congrArg (h n) he).trans (iterSucc n (f (succ zero))).symm)
  have hsuccessors : ∀ n, f (succ n) = iter n (f (succ zero)) :=
    hEqI hbase hnext
  constructor
  · exact hsep
  · intro n
    cases hcoverage n with
    | inl hz =>
        exact Or.inl hz
    | inr hs =>
        exact Or.inr ((congrArg f hs).trans (hsuccessors (pred n)))

/--
An explicit two-instance reduction from PI to the source positive uniqueness
schema: the constructor instance and the recurrence-comparison instance.
-/
theorem positiveUniqueness_of_PI
    (zero : α) (succ pred : α → α)
    (iter h : α → α → α) (f : α → α)
    (predSucc : ∀ n, pred (succ n) = n)
    (iterZero : ∀ a, iter zero a = a)
    (iterSucc : ∀ n a, iter (succ n) a = h n (iter n a))
    (hConstructorPI :
      PI zero succ (fun n => n) (fun n => succ (pred n)))
    (hComparisonPI : PI zero succ
      (fun n => f (succ n))
      (fun n => iter n (f (succ zero)))) :
    PU zero succ pred iter h f := by
  have hdata :=
    constructorData_of_PI zero succ pred predSucc hConstructorPI
  have heq := equationInduction_of_PI zero succ
    (fun n => f (succ n))
    (fun n => iter n (f (succ zero))) hComparisonPI
  exact positiveUniqueness_of_equationInduction zero succ pred iter h f
    iterZero iterSucc hdata.1 hdata.2 heq

#print axioms separation_of_constant_PI
#print axioms constructorData_of_PI
#print axioms coverage_of_PI
#print axioms equationInduction_of_PI
#print axioms positiveInduction_of_equationInduction
#print axioms positiveUniqueness_of_equationInduction
#print axioms positiveUniqueness_of_PI

end PositiveEquation
