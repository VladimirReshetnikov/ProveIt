PRA FROM POSITIVE EQUATION INDUCTION
==================================
Prepared for Vladimir Reshetnikov, 31 October 2026.

Read pra_positive_equation_induction.pdf for the complete report and proofs.
The matching .tex file is the editable source. SPECIFICATION.txt gives the
exact theory without typographical shorthand.

RESULT

Primitive-recursive defining equations + 0!=S0 + induction on the fixed
positive equation pattern n=0 or s=t axiomatize PRA in both classical and
intuitionistic first-order logic separately. The interpretations are identity
interpretations in the shared effective description language.

The proof reconstructs native equality using only predecessor iteration and
a zero selector. This avoids addition, maximum, pairing, and a previously
assumed equality-reflection axiom. The report is a simplification of the
principle and proof, not a claim to improve the smallest formula-node count
among the six current drafts.

FILES

  pra_positive_equation_induction.tex  Complete source
  pra_positive_equation_induction.pdf  Compiled report
  SPECIFICATION.txt                   Exact axioms and theorem
  SOURCES.json                        Immutable repository snapshot and hashes
  formal/PositiveEquation.lean        Checked schema reductions
  formal/EqualityReflection.lean      Checked native-equality reflection kernel
  formal/README*.txt                  Precise verification scope
  formal/*.log                       Actual compiler/dependency output
  artifacts/check_metrics.py          Reproducible syntax counts
  artifacts/schema_metrics.json       Recorded results
  audit/VALIDATION.txt                Validation and limits
  audit/proof_review.txt              Proof-dependency audit
  build.sh                           Rebuild PDF
  check.sh                           Recheck counts and Lean kernels
  SHA256SUMS                         Hashes of archive contents

BUILD

Run ./build.sh with a standard TeX Live installation providing pdflatex,
amsmath, amsthm, mathtools, lmodern, microtype, geometry, booktabs, tabularx,
enumitem, fancyhdr, needspace, xurl, and hyperref.

Run ./check.sh with Python 3 and Lean 4.19.0 on PATH. The Lean files depend
only on the core prelude; no Mathlib or network access is needed.

SOURCE SCOPE

Six PRA archives at ProveIt commit
514b6dfd2c1232848a259549c352b1935d53191c were inspected. The incoming directory
inventory and index had no PRA-labelled entry; unrelated Busy Beaver ZIPs
were not unpacked. Existing drafts are not redistributed in this archive.

VERIFYING THE CLAIM

The report gives the full constructive equivalence proof. Lean checks local
mathematical kernels with explicit instance hypotheses; it does not encode
the entire first-order proof calculus, language generator, formula compiler,
or bi-interpretation theorem. Empty printed Lean axiom-dependency lists do
not remove those explicit hypotheses. The scope files explain them.
