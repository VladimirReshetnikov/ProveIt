#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 artifacts/check_metrics.py
lean --version
lean formal/PositiveEquation.lean
lean formal/EqualityReflection.lean
printf '%s\n' 'All requested certificate and metric checks passed.'
