#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p .build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build pra_positive_equation_induction.tex > .build/pass1.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build pra_positive_equation_induction.tex > .build/pass2.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=.build pra_positive_equation_induction.tex > .build/pass3.log
cp .build/pra_positive_equation_induction.pdf pra_positive_equation_induction.pdf
printf '%s\n' 'Built pra_positive_equation_induction.pdf'
