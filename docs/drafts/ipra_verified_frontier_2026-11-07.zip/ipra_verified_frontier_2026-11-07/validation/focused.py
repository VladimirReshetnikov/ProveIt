"""Independent focused scope, capture, dispatch, and malformed-input checks.
No implementation code or proof-generation module is copied into this script.
"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import sys

TARGET = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'checker.py'
spec = importlib.util.spec_from_file_location('focused_kernel', TARGET)
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)
T = [0, 0]
R0 = [[0, 0, 0], 0]
Q = lambda body: [body]
E = lambda body: [body, T, T]

def refl(t):
    major = [[0, t, 0], t]
    return [[], [], [major, [1, t]], [t, t]]

def run(packet):
    try:
        data = copy.deepcopy(packet)
        kernel.take = data.pop
        kernel.k = -len(kernel.take())
        verdict = bool(kernel.check(kernel.take(), []))
        return verdict, kernel.k, None
    except Exception as exc:
        return False, getattr(kernel, 'k', None), type(exc).__name__

records = []
def test(name, packet, expected, final_k=None):
    result = run(packet)
    assert result[0] == expected, (name, result, packet)
    if final_k is not None:
        assert result[1] == final_k, (name, result, final_k)
    records.append({'name': name, 'expected': expected, 'final_k': result[1], 'error': result[2]})

# Deterministic rules deliberately consume and ignore their rule annotation.
annotations = [None, False, True, 0, 2.0, '', {}, [0], [0, 0, 0]]
for i, value in enumerate(annotations):
    test(f'arithmetic_wildcard_{i}', [value, R0, []], True, 0)
    test(f'arithmetic_wildcard_false_{i}', [value, [[0, 0, 0], [0]], []], False, 0)
    test(f'closure_wildcard_{i}', [value, Q(T), []], True, -1)

# A failed major allocates a genuine eigenparameter before returning False.
# The following default rule must still be an independently valid inference.
false_progress = Q([[[1], 0, 0], [0]])
failed_major_instruction = [false_progress, None]
test('failed_allocating_major_then_QI', [[], [], failed_major_instruction, Q(T), []], True, -2)
test('failed_allocating_major_then_R0', [[], [], failed_major_instruction, R0, []], True, -1)
kernel.h = [T]
test('failed_allocating_major_no_fallback', [[], [], failed_major_instruction, T, []], False)

# Scope capacity is determined by header length, not its contents.
test('declared_parameter', refl(-1) + [[None]], True)
test('undeclared_parameter', refl(-1) + [[]], False)
test('beyond_declared_parameter', refl(-2) + [[None]], False)
test('string_header_same_capacity', refl(-1) + ['x'], True)
test('mapping_header_same_capacity', refl(-1) + [{'x': None}], True)
for header in [None, False, True, 1, 0.0]:
    test('nonsized_header_' + repr(header), refl(0) + [header], False)

# Demand validation checks used witnesses and ignores genuinely unused ones.
test('used_future_witness', refl(-1)[:-1] + [[-1], E([1, 0]), []], False)
test('used_bound_coordinate_as_witness', refl(0)[:-1] + [[1], E([1, 0]), []], False)
test('unused_future_witness', refl(0)[:-1] + [[-999], E(T), []], True)
test('unused_malformed_witness', refl(0)[:-1] + [[{'bad': True}], E(T), []], True)

# A major that tries to export its own not-yet-declared existential witness
# must be rejected before that major's proof is allowed to allocate a name.
exists_zero = E([1, 0])
leaked_major = [-1, 0]
minor_proof = refl(0)[:-1]
major_proof = refl(0)[:-1] + [[0], [exists_zero, None]]
test('existential_eigenparameter_cannot_escape', minor_proof + major_proof + [[leaked_major, T], T, []], False)

# Numerically equal malformed leaves cannot bypass typed formation checks.
for bad in [False, True, 0.0, 1.0, None, {}, [], [0, 0]]:
    test('malformed_root_' + repr(bad), [None, [bad, bad], []], False)
    test('malformed_ignored_recursion_update_' + repr(bad), [None, [[0, 0, bad], 0], []], False)
    test('malformed_existential_ghost_' + repr(bad), refl(0)[:-1] + [[0], [T, bad, T], []], bad == T)

# Capture avoidance: the replacement is independently checked at depth zero,
# even where its target hole lies beneath logical or recursion binders.
openings = [
    ('closure_rejects_capture', Q([3, 3]), [1], False, None),
    ('closure_accepts_declared_rigid', Q([3, 3]), [-1], True, Q([-1, -1])),
    ('recursor_rejects_capture', [[0, 0, 5], 0], [1], False, None),
    ('recursor_accepts_declared_rigid', [[0, 0, 5], 0], [-1], True, [[0, 0, -1], 0]),
]
for name, template, images, expected, output in openings:
    kernel.k = -1
    try:
        actual = kernel.inst(template, images)
        verdict = True
    except Exception:
        actual = None
        verdict = False
    assert verdict == expected and (not expected or actual == output), (name, actual)
    records.append({'name': name, 'expected': expected, 'output': actual})

report = {'status': 'all focused checks passed', 'target': str(TARGET), 'sha256': hashlib.sha256(TARGET.read_bytes()).hexdigest(), 'cases': len(records), 'records': records, 'limitations': 'Finite tests plus a manual rule audit; not a formal metatheory.'}
(Path(__file__).resolve().parents[1] / 'results/focused.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:report[k]for k in ['status','target','sha256','cases']}, indent=2))
