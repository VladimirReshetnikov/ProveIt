#!/usr/bin/env python3
"""Independent semantic/adversarial checks of the automatic-hypothesis kernel.

Uses no proof-generating library. The numerical oracle evaluates small closed
terms directly as primitive recursions; it does not use kernel.inst/check.
"""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE
TARGET = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE.parent / 'checker.py'
spec = importlib.util.spec_from_file_location('independent_candidate', TARGET)
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)
counts = {}


def paired(x):
    if type(x) is int and x > 0:
        return 2*x-1
    return [paired(v) for v in x] if type(x) is list else x

def initial_bound(x):
    if type(x) is int and x < 0:
        return x
    if type(x) is list:
        return min([0] + [initial_bound(v) for v in x])
    return 0

def packet(document):
    return paired(document)+[[0]*(-initial_bound(document[-1]))] if type(document) is list and document else document

def run(document, context=()):
    stream = paired(copy.deepcopy(document))
    root = stream.pop()
    g = paired(copy.deepcopy(list(context)))
    kernel.k = initial_bound([root,g])
    kernel.take = stream.pop
    try:
        result = kernel.check(kernel.inst(root), [kernel.inst(v) for v in g])
        status = 'accept' if result else 'false'
        error = None
    except Exception as exc:
        status = 'error'
        error = type(exc).__name__
    return status, error, kernel.k, stream


def numeral(n):
    return 0 if n == 0 else [numeral(n - 1)]


def evaluate(term, parameters=()):
    """Direct denotational semantics, independent of syntactic substitution."""
    if type(term) is int:
        if term == 0:
            return 0
        if term < 0 or term > len(parameters):
            raise ValueError('not a closed numerical term')
        return parameters[term - 1]
    if type(term) is not list:
        raise ValueError('wrong term type')
    if len(term) == 1:
        return 1 + evaluate(term[0], parameters)
    if len(term) != 3:
        raise ValueError('wrong term arity')
    counter = evaluate(term[0], parameters)
    answer = evaluate(term[1], parameters)
    if counter > 30 or answer > 1000:
        raise ValueError('outside bounded numerical test')
    for index in range(counter):
        answer = evaluate(term[2], (answer, index) + parameters)
        if answer > 1000:
            raise ValueError('outside bounded numerical test')
    return answer


def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'))


def reflexivity(term):
    major = [[0, term, 0], term]
    return [[], [], [major, [1, term]], [term, term]]


# Positive certificates touch equality elimination, both computation schemas,
# native Q introduction, native E introduction and zero-cell hypotheses.
terms = [numeral(n) for n in range(5)]
updates = [0, 1, 2, [1], [2], [[1]], [2, 1, [1]]]
for n, initial, update in itertools.product(range(4), range(3), updates):
    terms.append([numeral(n), numeral(initial), update])
terms = list({canonical(t): t for t in terms}.values())
positives = [reflexivity(t) for t in terms]
for t in terms:
    positives.append([[], [[0, t, 0], t]])
for n in range(5):
    positives.append([[], [[[numeral(n)], 0, 2], numeral(n)]])
positives.extend([
    [[], [[0, 0]]],
    [[], [[[0, 0], [0, 0], [0, 0]]]],
    [[], [[[0, [0]], [0, 0], [0, 0]]]],
    reflexivity(0)[:-1] + [[0], [[0, 0], [0, 0], [0, 0]]],
])
for doc in positives:
    result = run(doc)
    assert result[0] == 'accept', ('positive', doc, result)
    goal = doc[-1]
    if len(goal) == 2:
        assert evaluate(goal[0]) == evaluate(goal[1]), ('semantic positive', goal)
counts['independently_built_positive_certificates'] = len(positives)
counts['distinct_closed_numerical_terms'] = len(terms)

# A hypothesis must consume zero cells and validate its goal first.
for goal in [[0, 0], [-9, -9], [[0, 0]], [[0, 0], [0, 0], [0, 0]]]:
    poison = [None, False, {'must_not_be_read': True}]
    result = run(poison + [goal], [goal])
    assert result[0] == 'accept' and result[3] == poison, ('zero-cell hypothesis', result)
for bad in [False, True, 0.0, None, {}, [0, 0], [0, 0, 0, 0]]:
    goal = [bad, 0]
    assert run([goal], [goal])[0] != 'accept', ('validation before hypothesis', goal)
counts['hypothesis_consumption_and_validation_cases'] = 11

# Unknown nonhypothesis instructions must fail. A global h cannot satisfy a
# local unbound h; failed computation-pattern bindings cannot define h either.
kernel.h = [[0, 0]]
unmatched = [None, False, True, 0, 0.0, '', {}, [None], [0, 0, 0], [],
             [[0, [0]], None], [[[0], [0]], [0, 0]]]
for instruction in unmatched:
    doc = [[], instruction, [0, 0]]
    result = run(doc)
    assert result[0] != 'accept', ('unrecognized instruction', instruction, result)
assert run([None, [0, 0]])[1] == 'UnboundLocalError'
# This major is a well-formed false equation whose computation attempt returns
# False, rather than raising. It cannot authorize the outer common continuation.
failed_major = [[[0, 0, 0], [0]], [0, 0]]
assert run([[], failed_major, [0, 0]])[0] != 'accept'
counts['unrecognized_and_failed_major_cases'] = len(unmatched) + 2

# JSON bool/int equality aliases and malformed annotations cannot pass syntax
# validation. Vacuous witnesses and unconsumed prefixes have declared demand
# behavior and are tested separately.
refl = reflexivity(0)
policy_cases = []
for bad in [None, False, True, '', {}, 0.0, 1.0, [0, 0], [0, 0, 0, 0]]:
    policy_cases.append((refl[:-1] + [[bad, 0]], False, 'goal'))
    policy_cases.append((refl[:-1] + [[0], [[0, 0], bad, [0, 0]]], bad == [0, 0], 'annotation'))
    policy_cases.append((refl[:-1] + [[bad], [[0, 0], [0, 0], [0, 0]]], True, 'unused witness'))
    policy_cases.append(([bad] + refl, True, 'unused prefix'))
for bad in [None, False, True, 1, 2, [1], [0, 0], [0, 0, 3]]:
    policy_cases.append((refl[:-1] + [[bad], [[1, 0], [0, 0], [0, 0]]], False, 'used witness'))
for doc, expected, label in policy_cases:
    result = run(doc)
    assert (result[0] == 'accept') == expected, ('input policy', label, doc, result)
counts['malformed_syntax_and_demand_policy_cases'] = len(policy_cases)

# Try the proof of s=s against every bounded closed equation s=t. Every
# accepted goal is checked with the independent numerical semantics above.
checked = accepted = false_targets = 0
for left, right in itertools.product(terms, repeat=2):
    doc = reflexivity(left)[:-1] + [[left, right]]
    status = run(doc)[0]
    truth = evaluate(left) == evaluate(right)
    checked += 1
    false_targets += not truth
    if status == 'accept':
        accepted += 1
        assert truth, ('accepted false closed equation', doc)
counts['closed_equation_attack_certificates'] = checked
counts['numerically_false_equation_targets'] = false_targets
counts['accepted_closed_equations_checked_semantically'] = accepted

# Mutate all proof cells, leaving each ground-equation goal intact, and also
# replace each goal by a demonstrably false equation. This targets malformed
# dispatch, implicit rejection, and major-premise changes, while the semantic
# oracle supplies an independent safety condition.
rng = random.Random(0xA17020261107)
scalars = [None, False, True, -1000, -2, -1, 0, 1, 2, '', {}, [], [0], [0, 0], [0, 0, 0], [0, 0, 0, 0]]

def paths(x, prefix=()):
    yield prefix
    if isinstance(x, list):
        for i, child in enumerate(x):
            yield from paths(child, prefix + (i,))

def mutate(x, path, value):
    out = copy.deepcopy(x)
    if not path:
        return copy.deepcopy(value)
    cursor = out
    for i in path[:-1]:
        cursor = cursor[i]
    cursor[path[-1]] = copy.deepcopy(value)
    return out

mutations = accepted_mutations = false_mutations = 0
for doc in positives:
    if len(doc[-1]) != 2:
        continue
    proof = doc[:-1]
    positions = list(paths(proof))
    for _ in range(40):
        changed = mutate(proof, rng.choice(positions), rng.choice(scalars))
        if not isinstance(changed, list):
            continue
        for goal in [doc[-1], [0, [0]]]:
            mutant = changed + [goal]
            result = run(mutant)
            mutations += 1
            truth = evaluate(goal[0]) == evaluate(goal[1])
            false_mutations += not truth
            if result[0] == 'accept':
                accepted_mutations += 1
                assert truth, ('semantic mutation failure', mutant, result)
counts['proof_mutation_documents'] = mutations
counts['false_goal_mutation_documents'] = false_mutations
counts['accepted_mutations_checked_semantically'] = accepted_mutations

# Replay the translated corpus when available. This is additional evidence;
# it is not needed for the independent examples and semantic oracle above.
corpus = sorted((ROOT / 'examples/transported').glob('*.json'))
for path in corpus:
    doc = json.loads(path.read_text())
    assert run(doc)[0] == 'accept', ('translated corpus', path)
counts['translated_theorem_replays'] = len(corpus)

# Check the actual CLI's exception-to-rejection boundary on three categories.
cli_cases = [(reflexivity(0), True), ([None, [0, 0]], False), ([[], [0, [0]]], False), (False, False)]
with tempfile.TemporaryDirectory(prefix='ipra-independent-') as td:
    for i, (doc, expected) in enumerate(cli_cases):
        path = Path(td) / f'case_{i}.json'
        path.write_text(json.dumps(packet(doc)))
        proc = subprocess.run([sys.executable, str(TARGET), str(path)], capture_output=True, text=True)
        assert (proc.returncode == 0 and proc.stdout.strip() == 'ACCEPT') == expected
        if not expected:
            assert proc.returncode == 1 and proc.stdout.strip() == 'REJECT'
counts['cli_boundary_cases'] = len(cli_cases)

report = {
    'status': 'all independent checks passed',
    'kernel_sha256': hashlib.sha256(TARGET.read_bytes()).hexdigest(),
    'python': sys.version.split()[0],
    'counts': counts,
    'limitations': 'Finite adversarial and independent semantic tests; not a mechanized metatheory or proof of consistency.'
}
(HERE.parent / 'results/independent.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
