"""Untrusted transport from the frozen scope checker to paired coordinates.

Adapted, with attribution, from ipra_alternation_2026-11-07/translator.py in
VladimirReshetnikov/ProveIt at commit
18e3b9b4071c76fb9e817a2eb50d7b12f7246d18.  See ATTRIBUTION.txt.  This version
adds canonical paired coordinates j -> 2*j-1, an explicit parameter declaration
header, and target execution with a declaration-bound parameter namespace.

The acceptance kernel never imports this module.  We first record an accepted
source execution, including failed-major fallback effects, then emit a new
derivation.  Already available assumptions prune complete subtrees.  Scoped
eigenparameters are renamed at their declarations.  Parameters of the public
goal and supplied external context are fixed; other free auxiliary parameters
are uniformly specialized to zero.  The latter prevents a later auxiliary
name from colliding with an earlier eigenname after pruning changes allocation.

Usage: python3 translator.py SOURCE.json OUTPUT.json --target-checker CHECKER.py
For an internal open-sequent fixture use --context CONTEXT.json.  Such an
internal test is not a public empty-context theorem certificate.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import dataclass, field
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_kernel(path, name):
    spec = importlib.util.spec_from_file_location(name, Path(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_kernel(module, certificate, context=(), target=False):
    """Run exactly the public proof logic, with an explicitly checked context."""
    stream = deepcopy(certificate)
    module.take = stream.pop
    try:
        module.k = -len(stream.pop()) if target else 0
        for formula in context:
            module.inst(formula)
        accepted = bool(module.check(stream.pop(), deepcopy(list(context))))
        error = None
    except Exception as exc:
        accepted, error = False, type(exc).__name__
    return {"accepted": accepted, "remaining": len(stream),
            "final_k": module.k, "error": error}


def encode_coordinates(value):
    """Map ordinary bound coordinate j to the canonical paired code 2*j-1.

    This map is applied to syntax, not mathematical numerical values:
    numerical one is [0], while a positive integer token is a coordinate.
    Exact Boolean and float values remain unchanged, to preserve the source
    kernel's rejection of malformed tokens rather than silently repair them.
    """
    if type(value) is int:
        return 2 * value - 1 if value > 0 else value
    if type(value) is list:
        return [encode_coordinates(x) for x in value]
    if type(value) is dict:
        return {key: encode_coordinates(x) for key, x in value.items()}
    return value


def negative_parameters(value):
    if type(value) is int:
        return {value} if value < 0 else set()
    if type(value) is list:
        return set().union(*(negative_parameters(x) for x in value))
    if type(value) is dict:
        return set().union(*(negative_parameters(x) for x in value.values()))
    return set()


@dataclass
class Node:
    goal: object
    cell: object
    kind: str
    accepted: bool = False
    children: list = field(default_factory=list)
    eigen: int | None = None
    consumed: int = 0
    failed_major: bool = False


class SourceRecorder:
    """Explicit replay of the frozen source; compared with its real execution."""
    def __init__(self, module, certificate, context):
        self.module = module
        self.stream = deepcopy(certificate)
        self.goal = self.stream.pop()
        self.context = deepcopy(list(context))
        self.calls = 0
        self.failed_major_fallbacks = 0
        self.allocations = []
        module.k = 0
        for formula in context:
            module.inst(formula)

    def check(self, goal, context):
        self.calls += 1
        before = len(self.stream)
        m = self.module
        m.inst(goal)
        cell = self.stream.pop()
        node = Node(deepcopy(goal), deepcopy(cell), "hyp")

        def finish(accepted):
            node.accepted = bool(accepted)
            node.consumed = before - len(self.stream)
            return node

        def scoped(body, assumptions, kind):
            node.kind = kind
            m.k -= 1
            node.eigen = m.k
            self.allocations.append(m.k)
            child_goal = m.inst(body, [[m.k]])
            child_context = context + [m.inst(c, [m.k]) for c in assumptions]
            child = self.check(child_goal, child_context)
            node.children.append(child)
            return finish(child.accepted)

        if type(cell) is list and len(cell) == 2:
            major, annotation = cell
            major_node = self.check(major, context)
            if major_node.accepted:
                node.children.append(major_node)
                if len(major) == 3:
                    return scoped(goal, major[:1], "ex_elim")
                if len(major) == 1:
                    body, endpoints = major[0], [0, annotation]
                    node.kind = "q_elim"
                else:
                    body, endpoints = annotation, major
                    node.kind = "eq_elim"
                premise, result = (m.inst(body, [v]) for v in endpoints)
                if result != goal:
                    return finish(False)
                child = self.check(premise, context)
                node.children.append(child)
                return finish(child.accepted)
            node.failed_major = True
            self.failed_major_fallbacks += 1
            # The failed execution consumed cells and changed k.  It is not
            # an accepted proof premise and is deliberately omitted here.
            return finish(goal in context)

        if cell == [] and type(cell) is list and len(goal) == 1:
            body = goal[0]
            assumptions = [m.inst(body, [0]), body][:2 - len(body) % 2]
            return scoped(body, assumptions, "q_intro")

        if type(cell) is list and len(cell) == 1 and len(goal) == 3:
            node.kind = "ex_intro"
            child = self.check(m.inst(goal[0], [cell[0]]), context)
            node.children.append(child)
            return finish(child.accepted)

        if (cell == [] and type(cell) is list and len(goal) == 2
                and type(goal[0]) is list and len(goal[0]) == 3):
            node.kind = "compute"
            n, initial, update = goal[0]
            if n:
                n, = n
                initial = m.inst(update, ([n, initial, update], n), d=1)
            return finish(goal[1] == initial)

        return finish(goal in context)


class TargetEmitter:
    def __init__(self, module, goal, context):
        self.module = module
        self.context = encode_coordinates(deepcopy(list(context)))
        self.fixed = negative_parameters(goal) | negative_parameters(context)
        self.parameter_count = -min(self.fixed | {0})
        self.header = [0] * self.parameter_count
        self.cells = []
        self.pruned_subtrees = 0
        self.pruned_source_cells = 0
        self.grounded_names = set()
        self.allocations = []
        module.k = -self.parameter_count
        for formula in self.context:
            module.inst(formula)

    def rename(self, value, scope):
        if type(value) is int and value < 0:
            if value in scope:
                return scope[value]
            if value in self.fixed:
                return value
            self.grounded_names.add(value)
            return 0
        if type(value) is int and value > 0:
            return 2 * value - 1
        if type(value) is list:
            return [self.rename(x, scope) for x in value]
        if type(value) is dict:
            return {key: self.rename(x, scope) for key, x in value.items()}
        return value

    def emit(self, node, context, scope, expected=None):
        require(node.accepted, "cannot emit a rejected source subtree")
        m = self.module
        goal = self.rename(node.goal, scope)
        require(expected is None or goal == expected,
                "renamed source goal differs from the target premise")
        cached_goal = m.inst(goal)
        if goal in context:
            self.pruned_subtrees += 1
            self.pruned_source_cells += node.consumed
            return
        require(node.kind != "hyp", "lost a source assumption under transport")
        cell = self.rename(node.cell, scope)
        self.cells.append(deepcopy(cell))

        def scoped(body, assumptions, child):
            m.k -= 1
            new_name = m.k
            self.allocations.append({"source": node.eigen, "target": new_name})
            new_scope = dict(scope)
            require(node.eigen is not None, "source eigenname is missing")
            new_scope[node.eigen] = new_name
            child_goal = m.inst(body, [[new_name]])
            child_context = context + [m.inst(c, [new_name]) for c in assumptions]
            self.emit(child, child_context, new_scope, child_goal)

        if node.kind == "q_intro":
            body = goal[0]
            assumptions = [body, m.inst(body, [0])][len(body) % 2:]
            scoped(body, assumptions, node.children[0])
        elif node.kind == "ex_intro":
            self.emit(node.children[0], context, scope,
                      m.inst(goal[0], [cell[0]]))
        elif node.kind in ("q_elim", "eq_elim", "ex_elim"):
            major, annotation = cell
            self.emit(node.children[0], context, scope, major)
            if node.kind == "ex_elim":
                scoped(cached_goal, major[:1], node.children[1])
            else:
                if node.kind == "q_elim":
                    body, endpoints = major[0], [0, annotation]
                else:
                    body, endpoints = annotation, major
                premise, result = (m.inst(body, [v]) for v in endpoints)
                require(result == goal, "transported elimination has wrong goal")
                self.emit(node.children[1], context, scope, premise)
        elif node.kind == "compute":
            n, initial, update = goal[0]
            if n:
                n, = n
                initial = m.inst(update, ([n, initial, update], n), d=1)
            require(goal[1] == initial, "transported computation is not an axiom")
        else:
            raise ValueError("unknown recorded rule: " + node.kind)


def transport(certificate, context=(), source_path=None, target_path=None):
    """Preserve the exact decoded goal/context and all interface parameter names.

    The serialized goal changes only by canonical coordinate encoding.  Its
    numerical variables and decoded mathematical formula remain unchanged.
    The certificate ends with [goal, declaration_header], so target checkers
    pop the declaration header first.
    """
    source_path = source_path or ROOT / 'source_checker.py'
    target_path = target_path or ROOT.parents[1] / 'checker.py'
    source = load_kernel(source_path, 'transport_source')
    target = load_kernel(target_path, 'transport_target')
    require(type(certificate) is list and certificate,
            "a certificate must be a nonempty JSON array")
    direct_source = run_kernel(source, certificate, context)
    require(direct_source['accepted'], "the frozen source rejects this input")
    recorder = SourceRecorder(source, certificate, context)
    tree = recorder.check(recorder.goal, recorder.context)
    require(tree.accepted, "recorded source execution rejects")
    require(len(recorder.stream) == direct_source['remaining']
            and source.k == direct_source['final_k'],
            "source recorder differs from actual source execution")
    emitter = TargetEmitter(target, recorder.goal, context)
    emitter.emit(tree, deepcopy(emitter.context), {})
    encoded_goal = encode_coordinates(recorder.goal)
    certificate_out = list(reversed(emitter.cells)) + [
        deepcopy(encoded_goal), deepcopy(emitter.header)]
    require(certificate_out[-2] == encode_coordinates(certificate[-1]),
            "public goal was not preserved by canonical coordinate encoding")
    simulated_k = target.k
    direct_target = run_kernel(target, certificate_out, emitter.context, target=True)
    require(direct_target['accepted'] and direct_target['remaining'] == 0,
            "the target rejects transport or leaves instructions unconsumed")
    require(simulated_k == direct_target['final_k'],
            "target allocation replay differs from the actual target")
    summary = {
        'source_cells_total': len(certificate) - 1,
        'source_cells_consumed': tree.consumed,
        'source_unused_prefix_cells': direct_source['remaining'],
        'target_cells': len(emitter.cells),
        'declared_parameters': emitter.parameter_count,
        'coordinate_encoding': 'j > 0 maps to 2*j-1; zero and negative names fixed',
        'recorded_source_calls': recorder.calls,
        'failed_major_fallbacks': recorder.failed_major_fallbacks,
        'pruned_subtrees': emitter.pruned_subtrees,
        'pruned_source_cells': emitter.pruned_source_cells,
        'source_allocations': recorder.allocations,
        'retained_allocation_map': emitter.allocations,
        'fixed_parameters': sorted(emitter.fixed),
        'grounded_auxiliary_names': sorted(emitter.grounded_names),
        'source_run': direct_source,
        'target_run': direct_target,
    }
    return certificate_out, summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--context', type=Path)
    parser.add_argument('--source-checker', type=Path)
    parser.add_argument('--target-checker', type=Path)
    args = parser.parse_args()
    context = json.loads(args.context.read_text()) if args.context else []
    certificate = json.loads(args.source.read_text())
    result, summary = transport(certificate, context,
                                source_path=args.source_checker,
                                target_path=args.target_checker)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
