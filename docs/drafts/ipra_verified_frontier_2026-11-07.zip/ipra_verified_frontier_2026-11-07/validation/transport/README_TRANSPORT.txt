PAIRED-COORDINATE PROOF TRANSPORT
================================

This is untrusted transport and regression evidence for the default-rule
candidate. It is not a proof-checker dependency.

Reproduce from this directory:
  python3 validate_transport.py --target-checker /absolute/path/to/checker.py

Translate one frozen-source proof:
  python3 translator.py source.json target.json --target-checker /absolute/path/to/checker.py

For an internal sequent proof, supply its context as a separate JSON array
with --context context.json. The generated target certificate requires that
same context after canonical coordinate encoding when calling check(). An
internal sequent fixture is NOT a public theorem certificate.

Public target certificates have stack form:
  [unused_or_proof_cells..., GOAL, HEADER]
The checker pops HEADER first and sets its initial parameter floor to
-len(HEADER). The emitted header is a list of zero placeholders long enough to
retain every negative parameter name in the public goal and external context.
A negative token names an arbitrary natural-number parameter; its sign does
not represent a negative arithmetic value.

Positive raw tokens are bound-coordinate codes. The source coordinate j>0 is
encoded as 2*j-1. Numerical one is [0], not the raw coordinate token 1.
The root formula therefore changes its raw JSON representation, while the
whole decoded formula and its public numerical parameter names are preserved.

Validation result: 45 inherited public theorem proofs, 21 internal sequent
proofs, four source-focused theorem proofs, four new direct default-rule theorem
proofs, and six rejected public inputs. All 167 CLI runs passed, including
normal Python and python -O target execution. See results/transport.json.

The candidate exercised on this run had SHA256:
627ba45fec2b152b532c024c3666e9c0678b10ad8de6921d077d4910405e2e8b

Examples/theorems are public certificates. Examples/open_sequents contain
validated_external_context, stack, goal, and declaration_header fields, and
are intended for the documented internal context-bearing harness.

Scope collisions matter: after removing a redundant proof subtree, a later
source auxiliary name can numerically equal a retained target eigenparameter.
Scoped eigenname renaming alone is insufficient. The transporter specializes
non-interface free auxiliary names to zero, while respecting the local scope
map and preserving all interface names. The focused collision fixture tests
this distinction explicitly.
