"""Compile the report using a standard installed LaTeX distribution."""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex']
    for _ in range(3):
        run = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        if run.returncode:
            raise RuntimeError(run.stdout[-12000:] + run.stderr[-2000:])
    log = (ROOT / 'report.log').read_text(errors='replace')
    if 'There were undefined references' in log or 'Citation `' in log:
        raise RuntimeError('Unresolved references after the final pass')
    warnings = [line for line in log.splitlines() if 'Overfull' in line or 'Warning:' in line]
    if any('Overfull' in line for line in warnings):
        raise RuntimeError('Overfull material requires visual inspection: ' + repr(warnings))
    (ROOT / 'results/build.json').write_text(json.dumps({
        'status': 'compiled', 'passes': 3, 'command': command,
        'warnings': warnings,
        'engine': subprocess.run(['pdflatex', '--version'], text=True, capture_output=True).stdout.splitlines()[0]
    }, indent=2) + '\n')
    print('Compiled report.pdf with resolved references and no overfull boxes')


if __name__ == '__main__':
    main()
