"""Repeat the size comparison and all endorsed finite validation gates."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    commands = [
        ['measure.py'],
        ['validation/transport/validate_transport.py'],
        ['validation/independent.py', 'checker.py'],
        ['validation/focused.py', 'checker.py'],
    ]
    records = []
    for command in commands:
        result = subprocess.run([sys.executable, *command], cwd=ROOT, text=True, capture_output=True)
        if result.returncode:
            print(result.stdout)
            print(result.stderr, file=sys.stderr)
            raise SystemExit(result.returncode)
        print('PASS ' + ' '.join(command))
        records.append({'command': [sys.executable, *command], 'exit_code': result.returncode})
    (ROOT / 'results/reproduction.json').write_text(json.dumps({
        'status': 'all gates passed', 'commands': records,
        'limits': 'Finite executable checks; not mechanized metatheory.'
    }, indent=2) + '\n')


if __name__ == '__main__':
    main()
