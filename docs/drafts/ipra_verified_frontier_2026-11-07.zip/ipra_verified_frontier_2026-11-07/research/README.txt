The executable experiments in this directory are research prototypes, not the delivered acceptance kernel.
The endorsed program is ../checker.py. See report.pdf, Section 8, for limits.
