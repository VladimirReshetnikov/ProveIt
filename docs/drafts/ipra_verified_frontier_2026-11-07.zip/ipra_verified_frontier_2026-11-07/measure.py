"""Remeasure the whole candidate and every pinned comparison program."""
from pathlib import Path
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('source_measure', ROOT / 'comparison/source_measure.py')
measurement = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measurement)
KEYS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    all_programs = {}
    for entry in manifest['programs']:
        actual = measurement.metrics(ROOT / entry['local_file'])
        if actual['sha256'] != entry['sha256']:
            raise ValueError('Changed frozen comparison program: ' + entry['local_file'])
        all_programs[entry['sha256']] = actual
    rows = [all_programs[entry['sha256']] for entry in manifest['top_level']]
    minimum = {key: min(row[key] for row in rows) for key in KEYS}
    core_minimum = {key: min(row['core'][key] for row in rows) for key in KEYS}
    expanded_minimum = {key: min(row[key] for row in all_programs.values()) for key in KEYS}
    candidate = measurement.metrics(ROOT / 'checker.py')
    if minimum != manifest['coordinatewise_minimum'] or expanded_minimum != minimum:
        raise ValueError('The declared comparison envelope did not reproduce')
    if not all(candidate[key] < minimum[key] for key in KEYS):
        raise ValueError('The claimed whole-program improvement did not reproduce')
    if not all(candidate['core'][key] < core_minimum[key] for key in KEYS):
        raise ValueError('The claimed core improvement did not reproduce')
    result = {
        'python': platform.python_version(),
        'implementation': platform.python_implementation(),
        'commit': manifest['commit'],
        'top_level_count': len(rows),
        'embedded_paths': manifest['embedded_paths'],
        'embedded_distinct': len(all_programs),
        'coordinatewise_minimum': minimum,
        'core_minimum': core_minimum,
        'expanded_minimum': expanded_minimum,
        'candidate': candidate,
        'relative_reduction': {key: (minimum[key] - candidate[key]) / minimum[key] for key in KEYS},
        'scope': 'Strict comparison to this pinned finite corpus; no global minimality claim.',
    }
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
