A FURTHER VERIFIED CHECKER REDUCTION FOR iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026

RESULT
The complete checker.py has 439 normalized significant Python tokens,
451 AST nodes, and 1,289 normalized UTF-8 bytes under CPython 3.12.14.
The separate minima among the 13 current top-level comparators are
444 / 457 / 1,313. All 70 distinct complete programs in the expanded
inventory give the same minima. Imports, parsing, validation, inference,
scope handling, verdicts, and exit status are included.

This is a modest improvement of the inherited six-rule presentation.
It is not a new mathematical basis, an absolute minimality theorem,
or a claimed breakthrough. Report Sections 2-5 reproduce the inherited
equivalence proofs with attribution so this archive is self-contained.

START HERE
- report.pdf: complete report, proofs, evidence, and further questions.
- report.tex and sections/: editable LaTeX sources.
- checker.py: the entire trusted acceptance program; no project imports.
- FORMAT.txt: complete serialization contract.
- examples/default_computation.json: minimal public example.
- validation/transport/examples/theorems/: 53 public certificates.
- validation/transport/examples/open_sequents/: 21 internal fixtures
  under explicit assumptions, not public theorem certificates.
- comparison/: frozen code and exact source provenance.
- results/: measurements and finite-validation evidence.
- research/: unsuccessful alternative representations; not endorsed kernels.

RUN
    python3 checker.py examples/default_computation.json
    python3 reproduce.py
    python3 build.py

The first command prints ACCEPT. The second remeasures and validates.
The third requires a normal LaTeX installation and recompiles the PDF.
No network is required by these commands. Python 3.10+ structural pattern
matching is required; CPython 3.12.14 is the exact measurement reference.

THEORY
Numerical terms: variables, zero, successor, and a first-order recursor
with previous-value and previous-counter variables bound in its update.
Formulas: equality and two unary numerical binders Q and E.
Q B reads B(0) -> forall x B(x); E B reads exists x B(x).
The six rules and two computation schemas are explicit in report Section 2.
Equation induction is supplied only when the matrix is literally equality.
Ordinary intuitionistic logic, arithmetic separation and coverage, and
quantifier-free induction are recovered in the report. The full numerical
domain and equality are preserved by the two ordinary interpretations;
internal recursion uniqueness supplies identity composite isomorphisms.

LIMITS
The mathematical proofs are not fully mechanized in Lean or Rocq.
Finite tests do not establish consistency or soundness for all inputs.
The algorithmic completeness statement abstracts from finite Python
recursion, memory, and input limits. A rejection is not a disproof.
The complete source-size result concerns the pinned finite corpus only.

PINNED SOURCE
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 18e3b9b4071c76fb9e817a2eb50d7b12f7246d18
Directory: docs/drafts
See comparison/manifest.json and ATTRIBUTION.txt for exact provenance.
