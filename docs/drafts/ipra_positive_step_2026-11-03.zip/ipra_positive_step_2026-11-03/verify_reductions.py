#!/usr/bin/env python3
"""Finite AST checks for the iPRA presentation reductions.

This is a diagnostic, not a proof of the full interpretation theorem.  It
constructs real syntax trees, counts their nodes, checks homomorphic maps
and capture-avoiding substitution on bounded fixtures, and evaluates small
standard-natural-number examples.  A recursor's frozen descriptor is never
an active substitution site.  Its complete descriptor tree is nevertheless
charged at every occurrence, as in the compared reports.

Run: python3 verify_reductions.py [--output result.json]
Only the Python standard library is used.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class Const:
    name: str


@dataclass(frozen=True)
class Fun:
    name: str
    args: tuple[Term, ...]


@dataclass(frozen=True)
class Descriptor:
    body: Term
    parameters: tuple[str, ...] = ()


@dataclass(frozen=True)
class Symbol:
    """Copy of a frozen source label, with a possibly smaller active arity.

    The slots tell which original parameter positions remain active.  They
    are signature metadata computable from the copied source descriptor;
    they are not new arithmetic term nodes.  Distinct original parameter
    declarations remain distinct labels, even if the body does not use them.
    """

    label: Descriptor
    slots: tuple[int, ...]


@dataclass(frozen=True)
class Call:
    symbol: Symbol
    args: tuple[Term, ...]

    def __post_init__(self) -> None:
        if len(self.args) != 2 + len(self.symbol.slots):
            raise ValueError("Recursor call has the wrong active arity")


Term = Var | Const | Fun | Call


@dataclass(frozen=True)
class Eq:
    left: Term
    right: Term


@dataclass(frozen=True)
class Bottom:
    pass


@dataclass(frozen=True)
class Binary:
    kind: str
    left: Formula
    right: Formula


@dataclass(frozen=True)
class Quantifier:
    kind: str
    variable: str
    body: Formula


Formula = Eq | Bottom | Binary | Quantifier

ZERO = Const("0")
V, W = Var("v"), Var("w")


def successor(t: Term) -> Term:
    return Fun("S", (t,))


ONE = successor(ZERO)


def original_symbol(body: Term, parameters: tuple[str, ...] = ()) -> Symbol:
    return Symbol(Descriptor(body, parameters), tuple(range(len(parameters))))


C_SYMBOL = original_symbol(Var("c1"), ("c1",))
A_SYMBOL = original_symbol(successor(V))
Q_SYMBOL = original_symbol(W)


def case(n: Term, a: Term, b: Term) -> Term:
    return Call(C_SYMBOL, (n, a, b))


def addition(n: Term, a: Term) -> Term:
    return Call(A_SYMBOL, (n, a))


def forall(variables: tuple[str, ...], formula: Formula) -> Formula:
    for variable in reversed(variables):
        formula = Quantifier("forall", variable, formula)
    return formula


def term_size(t: Term) -> int:
    if isinstance(t, (Var, Const)):
        return 1
    if isinstance(t, Fun):
        return 1 + sum(map(term_size, t.args))
    return 1 + term_size(t.symbol.label.body) + sum(map(term_size, t.args))


def formula_size(f: Formula) -> int:
    if isinstance(f, Eq):
        return 1 + term_size(f.left) + term_size(f.right)
    if isinstance(f, Bottom):
        return 1
    if isinstance(f, Binary):
        return 1 + formula_size(f.left) + formula_size(f.right)
    return 1 + formula_size(f.body)


def active_variables(t: Term) -> set[str]:
    if isinstance(t, Var):
        return {t.name}
    if isinstance(t, Const):
        return set()
    result: set[str] = set()
    # In particular, do not visit a Call's frozen label.
    for arg in t.args:
        result.update(active_variables(arg))
    return result


def active_occurrences(t: Term, variable: str) -> int:
    if isinstance(t, Var):
        return int(t.name == variable)
    if isinstance(t, Const):
        return 0
    return sum(active_occurrences(arg, variable) for arg in t.args)


def equation_occurrences(f: Eq, variable: str) -> int:
    return active_occurrences(f.left, variable) + active_occurrences(f.right, variable)


def free_variables(f: Formula) -> set[str]:
    if isinstance(f, Eq):
        return active_variables(f.left) | active_variables(f.right)
    if isinstance(f, Bottom):
        return set()
    if isinstance(f, Binary):
        return free_variables(f.left) | free_variables(f.right)
    return free_variables(f.body) - {f.variable}


def all_active_names(f: Formula) -> set[str]:
    if isinstance(f, Quantifier):
        return {f.variable} | all_active_names(f.body)
    if isinstance(f, Binary):
        return all_active_names(f.left) | all_active_names(f.right)
    return free_variables(f)


def substitute_term(t: Term, substitution: dict[str, Term]) -> Term:
    """Simultaneous active substitution; frozen descriptors are unchanged."""
    if isinstance(t, Var):
        return substitution.get(t.name, t)
    if isinstance(t, Const):
        return t
    args = tuple(substitute_term(arg, substitution) for arg in t.args)
    if isinstance(t, Fun):
        return Fun(t.name, args)
    return Call(t.symbol, args)


def substitute_formula(f: Formula, substitution: dict[str, Term]) -> Formula:
    if isinstance(f, Eq):
        return Eq(substitute_term(f.left, substitution), substitute_term(f.right, substitution))
    if isinstance(f, Bottom):
        return f
    if isinstance(f, Binary):
        return Binary(f.kind, substitute_formula(f.left, substitution),
                      substitute_formula(f.right, substitution))
    relevant = {
        name: term for name, term in substitution.items()
        if name != f.variable and name in free_variables(f.body)
    }
    incoming: set[str] = set()
    for term in relevant.values():
        incoming.update(active_variables(term))
    variable, body = f.variable, f.body
    if variable in incoming:
        forbidden = all_active_names(body) | incoming | set(relevant) | {variable}
        index = 0
        while f"fresh{index}" in forbidden:
            index += 1
        renamed = f"fresh{index}"
        body = substitute_formula(body, {variable: Var(renamed)})
        variable = renamed
    return Quantifier(f.kind, variable, substitute_formula(body, relevant))


def map_formula(f: Formula, term_map: Callable[[Term], Term]) -> Formula:
    if isinstance(f, Eq):
        return Eq(term_map(f.left), term_map(f.right))
    if isinstance(f, Bottom):
        return f
    if isinstance(f, Binary):
        return Binary(f.kind, map_formula(f.left, term_map), map_formula(f.right, term_map))
    return Quantifier(f.kind, f.variable, map_formula(f.body, term_map))


def alpha_key(f: Formula) -> tuple:
    """Compare formulas up to active bound-variable renaming only."""
    def term_key(t: Term, bound: tuple[str, ...]) -> tuple:
        if isinstance(t, Var):
            for index, name in enumerate(reversed(bound)):
                if name == t.name:
                    return ("bound", index)
            return ("free", t.name)
        if isinstance(t, Const):
            return ("constant", t.name)
        args = tuple(term_key(arg, bound) for arg in t.args)
        if isinstance(t, Fun):
            return ("function", t.name, args)
        # Frozen labels are opaque to the surrounding binding environment.
        return ("recursor", t.symbol, args)

    def formula_key(g: Formula, bound: tuple[str, ...]) -> tuple:
        if isinstance(g, Eq):
            return ("equals", term_key(g.left, bound), term_key(g.right, bound))
        if isinstance(g, Bottom):
            return ("bottom",)
        if isinstance(g, Binary):
            return (g.kind, formula_key(g.left, bound), formula_key(g.right, bound))
        return (g.kind, formula_key(g.body, bound + (g.variable,)))

    return formula_key(f, ())


def ordinary_module(symbol: Symbol) -> Formula:
    """Build the entire unprojected module, including all quantifiers."""
    if symbol.slots != tuple(range(len(symbol.label.parameters))):
        raise ValueError("Build a source module before translating it")
    parameters = symbol.label.parameters
    c = tuple(Var(name) for name in parameters)
    a, n = Var("a"), Var("n")
    old = Call(symbol, (n, a) + c)
    environment = {"v": old, "w": n}
    environment.update(zip(parameters, c))
    base = Eq(Call(symbol, (ZERO, a) + c), a)
    step = Eq(Call(symbol, (successor(n), a) + c),
              substitute_term(symbol.label.body, environment))
    return forall(("a",) + parameters,
                  Binary("and", base, forall(("n",), step)))


def closure(equation: Eq, parameters: tuple[str, ...], shortened: bool) -> Formula:
    x = Var("x")
    predicate = Binary("or", Eq(x, ZERO), equation)
    successor_equation = substitute_formula(equation, {"x": successor(x)})
    successor_predicate = successor_equation if shortened else Binary(
        "or", Eq(successor(x), ZERO), successor_equation)
    premise = forall(("x",), Binary("implies", predicate, successor_predicate))
    return forall(parameters, Binary("implies", premise, forall(("x",), predicate)))


def z_body(index: int, value: Term = V) -> Term:
    for _ in range(index):
        value = case(value, ZERO, ONE)
    return value


Z1_SYMBOL = original_symbol(z_body(1))


def literal_z_degree(body: Term) -> int | None:
    degree = 0
    while (isinstance(body, Call) and body.symbol == C_SYMBOL
           and body.args[1:] == (ZERO, ONE)):
        degree += 1
        body = body.args[0]
    return degree if degree and body == V else None


def merge_z(t: Term) -> Term:
    if isinstance(t, (Var, Const)):
        return t
    args = tuple(merge_z(arg) for arg in t.args)
    if isinstance(t, Fun):
        return Fun(t.name, args)
    degree = literal_z_degree(t.symbol.label.body)
    if (degree is not None and degree >= 2
            and not t.symbol.label.parameters and not t.symbol.slots):
        return Call(Z1_SYMBOL, args)
    return Call(t.symbol, args)


def project_support(t: Term) -> Term:
    if isinstance(t, (Var, Const)):
        return t
    args = tuple(project_support(arg) for arg in t.args)
    if isinstance(t, Fun):
        return Fun(t.name, args)
    label = t.symbol.label
    active = active_variables(label.body)
    kept = tuple(index for index in t.symbol.slots if label.parameters[index] in active)
    argument_at = dict(zip(t.symbol.slots, args[2:]))
    return Call(Symbol(label, kept), args[:2] + tuple(argument_at[index] for index in kept))


def zero_pad(t: Term) -> Term:
    """The reverse interpretation of the copied-label arity projection."""
    if isinstance(t, (Var, Const)):
        return t
    args = tuple(zero_pad(arg) for arg in t.args)
    if isinstance(t, Fun):
        return Fun(t.name, args)
    label = t.symbol.label
    argument_at = dict(zip(t.symbol.slots, args[2:]))
    restored = tuple(argument_at.get(index, ZERO) for index in range(len(label.parameters)))
    return Call(Symbol(label, tuple(range(len(label.parameters)))), args[:2] + restored)


def evaluate(t: Term, environment: dict[str, int]) -> int:
    """External bounded examples, not an internal universal PR evaluator."""
    if isinstance(t, Var):
        return environment[t.name]
    if isinstance(t, Const):
        if t.name != "0":
            raise ValueError("Unknown constant")
        return 0
    if isinstance(t, Fun):
        if t.name != "S" or len(t.args) != 1:
            raise ValueError("Unknown primitive function")
        return evaluate(t.args[0], environment) + 1
    values = tuple(evaluate(arg, environment) for arg in t.args)
    counter, state = values[:2]
    if counter < 0:
        raise ValueError("Natural counters only")
    local = {name: 0 for name in t.symbol.label.parameters}
    local.update({t.symbol.label.parameters[index]: value
                  for index, value in zip(t.symbol.slots, values[2:])})
    for step in range(counter):
        local["v"], local["w"] = state, step
        state = evaluate(t.symbol.label.body, local)
    return state


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Also write the JSON summary here")
    arguments = parser.parse_args()
    checks: Counter[str] = Counter()

    def check(condition: bool, category: str, detail: str = "") -> None:
        if not condition:
            raise AssertionError(f"{category}: {detail}")
        checks[category] += 1

    x, y, u = Var("x"), Var("y"), Var("u")
    fixtures: list[Term] = [ZERO, ONE, x, y, successor(x), case(y, ZERO, successor(x)),
                           addition(successor(x), case(y, ZERO, ONE))]

    # Actual trees for the two equation-closure formats, including equations
    # with zero, one, and many active x occurrences and nested frozen labels.
    equations = [Eq(x, ZERO), Eq(x, x), Eq(successor(x), x), Eq(y, ZERO),
                 Eq(addition(x, x), successor(x)), Eq(case(x, x, y), x),
                 Eq(Call(original_symbol(Var("x"), ("x",)), (y, ZERO, y)), x)]
    for index, equation in enumerate(equations):
        for padding in range(6):
            parameters = tuple(sorted(free_variables(equation) - {"x"})) + tuple(
                f"dummy{i}" for i in range(padding))
            old = closure(equation, parameters, False)
            new = closure(equation, parameters, True)
            f, k, p = formula_size(equation), equation_occurrences(equation, "x"), len(parameters)
            check(formula_size(old) == 3*f + k + p + 17, "old_closure_ast_count", str(index))
            check(formula_size(new) == 3*f + k + p + 12, "short_closure_ast_count", str(index))
            check(formula_size(old) - formula_size(new) == 5, "closure_exact_saving")

    # Independently assemble recursion modules and compare with the source
    # formula for multiple state-occurrence counts and parameter lengths.
    for m in range(9):
        params = tuple(f"c{i+1}" for i in range(m))
        bodies = [ZERO, V, W, successor(V), successor(successor(V)), addition(V, V)]
        if m:
            bodies += [Var(params[0]), case(V, Var(params[0]), W),
                       addition(case(V, Var(params[0]), V), V)]
        for body in bodies:
            symbol = original_symbol(body, params)
            h, s = term_size(body), active_occurrences(body, "v")
            expected = 3*h + 3*m + 13 + s*(h + m + 2)
            check(formula_size(ordinary_module(symbol)) == expected,
                  "ordinary_module_ast_count", f"m={m}, state_occurrences={s}")

    # Selector-idempotence merges. The module image retains the original
    # active update and every quantifier; it is not a fresh target module.
    for j in range(2, 33):
        symbol = original_symbol(z_body(j))
        module = ordinary_module(symbol)
        image = map_formula(module, merge_z)
        check(term_size(symbol.label.body) == 1 + 5*j, "selector_descriptor_count")
        check(formula_size(module) == 20*j + 19, "selector_source_module_count")
        check(formula_size(image) == 5*j + 34, "selector_exact_image_module_count")
        for n in fixtures:
            for a in fixtures:
                call = Call(symbol, (n, a))
                projected = merge_z(call)
                check(term_size(call) - term_size(projected) == 5*(j-1),
                      "selector_arbitrary_actual_tree_saving")

    # Unused-parameter projection; labels are copied without any shortening.
    for m in range(1, 41):
        params = tuple(f"c{i+1}" for i in range(m))
        symbol = original_symbol(successor(V), params)
        variable_call = Call(symbol, (Var("n"), Var("a")) + tuple(map(Var, params)))
        projected = project_support(variable_call)
        check(term_size(variable_call) == m + 5 and term_size(projected) == 5,
              "support_variable_call_count")
        source_module = ordinary_module(symbol)
        image_module = map_formula(source_module, project_support)
        check(formula_size(source_module) == 23 + 4*m, "support_source_module_count")
        check(formula_size(image_module) == 23 + m, "support_exact_image_module_count")
        check(projected.symbol.label == symbol.label, "support_frozen_label_preserved")
        check(project_support(zero_pad(projected)) == projected, "support_literal_target_round_trip")
        for offset, n in enumerate(fixtures):
            a = fixtures[-1-offset]
            discarded = tuple(fixtures[(offset+i) % len(fixtures)] for i in range(m))
            call = Call(symbol, (n, a) + discarded)
            result = project_support(call)
            check(term_size(call) - term_size(result) == sum(map(term_size, discarded)),
                  "support_arbitrary_actual_tree_saving")

    # Frozen labels can contain names also present in an active substitution.
    scoped_symbol = original_symbol(case(V, W, Var("q")), ("q",))
    scoped_call = Call(scoped_symbol, (x, y, u))
    scoped_substitution = {"v": ZERO, "w": ONE, "q": successor(y), "x": successor(u)}
    changed = substitute_term(scoped_call, scoped_substitution)
    check(changed.symbol == scoped_symbol and changed.symbol.label.body == scoped_symbol.label.body,
          "frozen_descriptor_substitution_isolation")
    check(changed.args[0] == successor(u), "active_argument_substitution_occurs")

    # A deleted/trimmed operation within a retained frozen label stays there.
    padded = original_symbol(successor(V), ("c1", "c2"))
    frozen_inner = Call(padded, (W, V, Var("c1"), Var("c2")))
    outer = original_symbol(frozen_inner, ("c1", "c2"))
    outer_call = Call(outer, (x, y, ZERO, ONE))
    check(project_support(outer_call).symbol.label == outer.label,
          "nested_frozen_source_label_preserved")
    nested_z = original_symbol(Call(original_symbol(z_body(3)), (W, V)))
    nested_z_call = Call(nested_z, (x, y))
    check(merge_z(nested_z_call).symbol == nested_z,
          "nested_frozen_erased_name_remains_inert")

    compound = Call(padded, (Call(original_symbol(z_body(4)), (x, y)),
                            case(u, ZERO, ONE), addition(x, y), scoped_call))
    terms = fixtures + [scoped_call, outer_call, nested_z_call, compound]
    formulas: list[Formula] = [Eq(term, y) for term in terms]
    formulas += [Quantifier("forall", "x", Eq(compound, u)),
                 Quantifier("exists", "y", Binary("implies", Eq(u, y),
                   Quantifier("forall", "x", Binary("or", Eq(compound, x), Bottom())))),
                 forall(("x", "y"), Binary("and", Eq(outer_call, u), Eq(compound, y)))]
    substitutions = [
        {"x": successor(y), "y": ZERO},
        {"u": x, "y": successor(x)},
        {"x": compound, "u": addition(y, ONE)},
        {"u": y, "v": x, "c1": successor(u)},
    ]
    for name, transform in (("support", project_support), ("selector", merge_z)):
        for term in terms:
            check(term_size(transform(term)) <= term_size(term), f"{name}_general_nonincrease")
            for sigma in substitutions:
                left = transform(substitute_term(term, sigma))
                right = substitute_term(transform(term), {k: transform(v) for k, v in sigma.items()})
                check(left == right, f"{name}_term_substitution_coherence")
        for formula in formulas:
            check(formula_size(map_formula(formula, transform)) <= formula_size(formula),
                  f"{name}_formula_nonincrease")
            for sigma in substitutions:
                left = map_formula(substitute_formula(formula, sigma), transform)
                right = substitute_formula(map_formula(formula, transform),
                                           {k: transform(v) for k, v in sigma.items()})
                check(alpha_key(left) == alpha_key(right),
                      f"{name}_formula_substitution_coherence")

    # Negative controls ensure parameter occurrence and literal matching are
    # checked, rather than indiscriminately removing declarations/operations.
    used_parameter = original_symbol(Var("c1"), ("c1", "c2"))
    used_call = Call(used_parameter, (x, y, ONE, ZERO))
    check(project_support(used_call).symbol.slots == (0,), "used_parameter_retained")
    check(project_support(used_call).args == (x, y, ONE), "support_order_preserved")
    false_z = original_symbol(case(case(V, ZERO, ONE), ONE, ZERO))
    check(merge_z(Call(false_z, (x, y))).symbol == false_z, "nonmatching_selector_not_merged")
    constant_update = original_symbol(ZERO)
    check(evaluate(Call(constant_update, (ZERO, ONE)), {}) == 1,
          "initializer_needed_even_for_state_independent_update")

    # Standard-natural-number diagnostics, explicitly separate from proofs.
    for j in range(2, 9):
        symbol = original_symbol(z_body(j))
        for n in range(13):
            for a in range(13):
                call = Call(symbol, (Var("n"), Var("a")))
                values = {"n": n, "a": a}
                check(evaluate(call, values) == evaluate(merge_z(call), values),
                      "numerical_selector_merge")
    for n in range(13):
        for a in range(13):
            call = Call(padded, (Var("n"), Var("a"), addition(x, y), scoped_call))
            values = {"n": n, "a": a, "x": 2, "y": 3, "u": 4}
            check(evaluate(call, values) == evaluate(project_support(call), values),
                  "numerical_support_projection")
    for y_value in range(33):
        for n in range(33):
            residual = max(y_value-n, 0)
            result = y_value if residual == 0 else n + residual
            check(result == y_value, "numerical_residual_identity")
    for s in range(33):
        for t in range(33):
            r = max(s+1-t, 0)
            e = 1 if r == 0 else r-1
            beta = 0 if e == 0 else 1
            check(beta in (0, 1) and (beta == 0) == (s == t),
                  "numerical_equality_reflection")

    summary = {
        "status": "passed",
        "verification_scope": (
            "Bounded syntax-tree diagnostics and standard-natural-number examples. "
            "These checks do not formalize or replace the universal induction, "
            "intuitionistic logic, or bi-interpretability proofs."
        ),
        "representation": {
            "frozen_descriptors": "Charged in full at every recursor occurrence; never actively substituted.",
            "support_projection": "Copied source labels, fewer active auxiliary arguments, original quantifiers retained.",
            "selector_merge": "Fixed symbol map for literal zero/one selector iteration descriptors; all image clauses retained.",
        },
        "bounds": {
            "closure_equations": len(equations), "extra_vacuous_parameters": [0, 5],
            "generic_module_parameter_counts": [0, 8],
            "selector_descriptor_indices": [2, 32], "support_padding_counts": [1, 40],
            "numerical_selector_indices": [2, 8], "numerical_loop_counter_and_initializer": [0, 12],
            "numerical_residual_and_equality_inputs": [0, 32],
            "arbitrary_term_fixtures": len(terms), "formula_fixtures": len(formulas),
            "substitution_fixtures": len(substitutions),
        },
        "checks": dict(sorted(checks.items())),
        "total_checks": sum(checks.values()),
    }
    encoded = json.dumps(summary, indent=2, sort_keys=True) + "\n"
    if arguments.output is not None:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
