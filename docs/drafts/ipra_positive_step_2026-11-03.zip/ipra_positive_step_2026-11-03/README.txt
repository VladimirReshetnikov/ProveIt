A SIMPLER COMPLETE CALCULUS FOR iPRA
Positive-step equation closure, explicit logic, and exact source reductions
3 November 2026

START HERE
  report.pdf       Complete mathematical report.
  AXIOMS.txt       Stand-alone formal specification, including every logical rule.
  report.tex       Main LaTeX source (uses sections/).

RESULT
The recommended ordinary first-order theory C+ has genuine intuitionistic
falsity, a minimal-support initialized-recursion language, one separation
axiom, all initialized-recursion computation equations, and this contextual
equation rule:

  Gamma, x=0 OR E(x,c) |- E(Sx,c)
  --------------------------------------  x not free in Gamma; E an equation
  Gamma |- forall x (x=0 OR E(x,c)).

The additional premise assumption is discharged. There is no separate base
premise. The report proves full quantifier-free induction, ordinary
whole-carrier bi-interpretability with the explicitly specified iPRA, both
internally identity composites, and syntactic equiconsistency.

PRECISE SIMPLICITY CLAIMS
1. The ordinary closure schema is exactly five nodes smaller per instance
   than the current equation-closure draft, in its own fully charged ledger.
2. Separately, a fixed unused-parameter projection and idempotent-selector
   merge give a no-larger exact axiom image for each of the four current
   complete source theories, preserving its existing interface/reductions.
3. These are not an absolute shortestness theorem or a claim that the
   stand-alone C+ core dominates every compressed interface in every column.
   The source-relative refinements form a family, not one vocabulary
   simultaneously attaining all different interface minima.

The native binding-recursion notation is optional. Its substitution
coherence is proved in the appendix; the ordinary first-order core remains
the reference for bi-interpretability.

REPRODUCTION
  python3 build.py

Requires Python 3.10+ and pdflatex with the conventional packages listed
in report.tex. The diagnostic itself has no third-party Python dependencies.

Diagnostics only:
  python3 verify_reductions.py --output verification.json

The included run passes 6,084 finite syntax/numerical checks. It is not a
Lean/Rocq formalization of the universal arithmetic or interpretation proof.
The full proof is written in the report. This distinction is intentional.

SOURCE SNAPSHOT
VladimirReshetnikov/ProveIt
5753b3f955eb6681b6f89f5d778fda2b7ec8f87a

Four current archives: equation_closure, inverse_iteration, retraction,
successor_transport, all dated 2026-11-03. Exact names, byte sizes, Git blob
identifiers, and SHA-256 hashes are in provenance/source_manifest.json.
Original specification and LaTeX source copies are included under
provenance/source_specifications/ for auditability. They have not been
edited. They are comparison material, not extra axioms of the new core.

INTEGRITY
SHA256SUMS.txt covers the final deliverable contents, except itself.
Compilation logs and temporary page images are not deliverables.

FURTHER RESEARCH QUESTIONS
The report includes paid-binder optimization, formal verification,
certified support minimization, selector normalization, and precisely
formulated lower-bound problems.
