#!/usr/bin/env python3
"""Reproduce diagnostics and the PDF. Python dependencies: standard library only."""
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile


def main():
    root = Path(__file__).resolve().parent
    subprocess.run(
        [sys.executable, str(root / "verify_reductions.py"),
         "--output", str(root / "verification.json")],
        cwd=root, check=True,
    )
    latex = shutil.which("pdflatex")
    if latex is None:
        raise SystemExit("pdflatex is required to build report.pdf; diagnostics completed.")
    logs = root / "build_logs"
    logs.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="ipra_latex_") as stage_name:
        stage = Path(stage_name)
        shutil.copy2(root / "report.tex", stage / "report.tex")
        shutil.copytree(root / "sections", stage / "sections")
        for number in (1, 2, 3):
            result = subprocess.run(
                [latex, "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                cwd=stage, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            )
            (logs / f"latex_pass_{number}.txt").write_text(result.stdout)
            if result.returncode:
                print(result.stdout[-6000:])
                raise SystemExit(result.returncode)
        log = (stage / "report.log").read_text(errors="replace")
        pdf = (stage / "report.pdf").read_bytes()
        if not pdf.rstrip().endswith(b"%%EOF"):
            raise SystemExit("Incomplete PDF output")
        (root / "report.pdf").write_bytes(pdf)
        (logs / "report.log").write_text(log)
    warning_lines = [line for line in log.splitlines()
                     if "Overfull" in line or "undefined" in line.lower()
                     or "LaTeX Warning:" in line]
    result = {
        "status": "passed",
        "pdf_bytes": (root / "report.pdf").stat().st_size,
        "layout_or_reference_warnings": warning_lines,
        "diagnostics": json.loads((root / "verification.json").read_text())["total_checks"],
    }
    (logs / "build_summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
