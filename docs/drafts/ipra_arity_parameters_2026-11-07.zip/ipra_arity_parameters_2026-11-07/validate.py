"""Run the self-contained corpus comparison and independent adversarial audit."""
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parent
for script in ('validation/corpus_check.py', 'validation/independent_adversarial.py'):
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)
