CURRENT BASELINE SOURCES AND REPRODUCIBLE MEASUREMENTS

Repository: https://github.com/VladimirReshetnikov/ProveIt
Pinned commit: c5f42a50d9213259760ee385977481c04dccab28
Directory: docs/drafts

Selection and provenance
------------------------
All six ZIP files present in this directory at the pinned commit were
inspected. This folder contains byte-for-byte copies of all NINE complete
top-level checker*.py programs they supply. Nested historical comparison
programs are excluded. The older baseline manifests inside the six source
archives compare a previous iteration and do not describe this corpus.

manifest.json records each source archive's pinned URL, raw URL, byte size,
Git blob SHA-1, and SHA-256, and each copied program's archive member,
relative path, SHA-256, interface, and witness-validation policy. The Git
blob SHA-1 was independently recomputed from the exact downloaded ZIP
bytes and checked against the pinned repository tree. The ZIP archives
need not be downloaded to reproduce the source metrics.

Each source directory preserves the original archive's LICENSE_SOURCE.txt.
The repository's root license is also copied here as LICENSE_SOURCE.txt.
The source code and inherited arithmetic basis are credited to ProveIt
Contributors and the supplied research drafts. Copying these sources is
permitted by their MIT No Attribution license.

Reproduction
------------
From this directory or any other working directory:

  python3 /absolute/path/to/comparison/measure.py

This verifies all nine source SHA-256 values, regenerates metrics.json and
metrics.csv next to the script, and prints the current minima. The script
needs only Python's standard library. It is copied byte-for-byte from
ipra_arity_2026-11-06.zip, member
ipra_arity_2026-11-06/comparison/source_measure.py.
Its own SHA-256 and provenance appear in manifest.json.

To measure additional complete checker files at the same boundary:

  python3 /absolute/path/to/comparison/measure.py /path/to/checker.py

Optional candidate measurements and comparisons are printed as JSON. The
stored metrics.json and metrics.csv remain the baseline measurements.

Accounting boundary
-------------------
Whole-program counts include every executable expression and data table:
syntax validation, substitution, inference checking, imports, JSON input,
command-line handling, and accept/reject output. Comments and actual
module/function/class docstrings are removed uniformly. Normalized token
and byte counts use ast.unparse. AST nodes count the same stripped tree.
Source tokens are counted before reformatting, excluding only comments,
layout, and actual docstrings. Raw bytes are supplied separately.

The core diagnostic additionally removes imports and the __name__-guarded
command-line block from every program by the same operation. No translator,
proof builder, or external theorem database is counted as part of a checker
unless it participates in that checker's acceptance decision.

The common runtime is Python and its standard library. Python AST/unparse
behavior can change across versions; the actual version is recorded in
metrics.json. Reproduction here used CPython 3.12.14.

Current coordinatewise minima
-----------------------------
Whole: normalized tokens 483; AST nodes 491; normalized UTF-8 bytes 1462.
Core:  normalized tokens 423; AST nodes 425; normalized UTF-8 bytes 1200.

Different programs attain different coordinate minima. These are measured
minima of this finite current corpus, not a lower-bound theorem for all
possible axiomatizations or proof-checker languages.

The demand variants may ignore an ill-formed numerical-witness annotation
when its matrix does not use the witness. This changes accepted certificate
syntax but is intended to preserve the theorem set; those smaller variants
are included in the comparison. All nine programs check empty-context
theorems and allow inert unused material at the beginning of their reverse
streams. The direct-stream variant stores the goal at the end of one input
stream; the remaining variants use a [goal, proof_stack] pair.
