"""Compile the report until cross-reference and contents files stabilize."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    with tempfile.TemporaryDirectory(prefix="ipra-report-") as directory:
        previous = None
        for attempt in range(5):
            run = subprocess.run(
                ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", f"-output-directory={directory}", "report.tex"],
                cwd=ROOT, capture_output=True, text=True,
            )
            if run.returncode:
                print(run.stdout[-10000:])
                print(run.stderr)
                raise SystemExit(run.returncode)
            current = tuple(
                path.read_bytes() if path.exists() else b""
                for path in (Path(directory) / ("report." + suffix)
                             for suffix in ("aux", "toc", "out"))
            )
            if current == previous:
                break
            previous = current
        else:
            raise SystemExit("LaTeX cross-references did not stabilize in five passes")
        log = (Path(directory) / "report.log").read_text(errors="replace")
        shutil.copyfile(Path(directory) / "report.pdf", ROOT / "report.pdf")
        record = {
            "status": "PASS",
            "passes": attempt + 1,
            "cross_references_stable": True,
            "engine": run.stdout.splitlines()[0],
            "overfull_boxes": re.findall(r"Overfull \\[hv]box[^\n]*", log),
            "unresolved_references": bool(re.search(
                r"undefined references|Citation .* undefined|Reference .* undefined", log)),
            "output": "report.pdf",
        }
        (ROOT / "results" / "pdf_build.json").write_text(
            json.dumps(record, indent=2) + "\n")
        print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
