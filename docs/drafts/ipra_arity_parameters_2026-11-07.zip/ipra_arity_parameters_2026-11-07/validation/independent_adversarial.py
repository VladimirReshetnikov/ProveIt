"""Focused independent audit of the fresh-parameter arity stream checkers.

These are finite examples checking concrete parser/freshness risks, not a
formal proof of soundness, completeness, or bi-interpretability.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path(__file__).resolve().parent


def eq(s, t):
    return [s, t]


def ex(b, p=None, q=None):
    return [b, [0, 0] if p is None else p, [0, 0] if q is None else q]


def refl(t):
    r = [0, t, 0]
    major = [r, t]
    return [[major, [1, t]], [], []]


def stream(goal, consumed):
    return list(reversed(copy.deepcopy(consumed))) + [copy.deepcopy(goal)]


def fixtures():
    cases = []

    def add(name, goal, consumed, strict=True, demand=None, expected_k=None, reason=''):
        cases.append({'name': name, 'input': stream(goal, consumed),
                      'expected': {'strict': strict, 'demand': strict if demand is None else demand},
                      'expected_k': expected_k, 'reason': reason})

    add('zero_reflexivity', eq(0, 0), refl(0), expected_k=0,
        reason='Literal integer zero is the zero term, not a substitution hole.')
    add('rigid_parameter_reflexivity', eq(-7, -7), refl(-7), expected_k=-7,
        reason='Negative integers denote rigid free numerical names and register the supply.')
    add('successor_reflexivity', eq([0], [0]), refl([0]),
        reason='The numeral one is [0], distinct from dangling bound index 1.')
    add('dangling_positive_goal', eq(1, 1), refl(1), strict=False,
        reason='A positive index outside all syntactic binders is rejected.')
    add('boolean_is_not_integer', eq(True, True), refl(True), strict=False,
        reason='Python bool values must not pass the exact int atom test.')
    add('empty_formula', [], [17], strict=False,
        reason='Arity zero has no formula constructor.')
    add('four_field_formula', [[0, 0]] * 4, [17], strict=False,
        reason='The formula constructor table rejects arity four.')
    add('binary_term', eq([0, 0], [0, 0]), [17], strict=False,
        reason='A two-child list is invalid in term sort.')
    add('invalid_existential_pad', [[0, 0], 0, [0, 0]], [[0]] + refl(0), strict=False,
        reason='An ignored existential pad must still be a well-sorted formula.')
    add('unbound_index_in_pad', ex(eq(0, 0), eq(2, 2)), [[0]] + refl(0), strict=False,
        reason='The existential binds one coordinate independently in each formula field.')
    add('bound_index_in_pad', ex(eq(0, 0), eq(1, 1)), [[0]] + refl(0),
        reason='A pad may use its own existential-bound coordinate.')
    add('false_pads_are_not_assumptions', ex(eq(0, 0), eq(0, [0]), [eq(0, [0])]),
        [[0]] + refl(0), reason='Well-sorted pads are semantically ignored even when their erasures are false.')

    # Prove Q_x exists y (y=x). A name occurring only in a pad fixes the
    # next eigenparameter. The supplied witness and equality proof expose it.
    n = -1001
    goal = [ex(eq(1, 2), eq(-1000, -1000))]
    add('q_freshness_from_padding', goal, [[], [[n]]] + refl([n]),
        expected_k=n, reason='Entry traversal must register negative names in ignored pads before Q introduction.')
    add('wrong_eigenname_after_padding', goal, [[], [[-1]]] + refl([-1]), strict=False,
        reason='A certificate assuming allocation -1 must fail when a pad reserves -1000.')

    # Prove 0=0 by opening exists x (x=0), then use the actual local equality.
    major = ex(eq(1, 0), eq(-1000, -1000))
    local = eq(-1001, 0)
    add('existential_freshness_from_padding', eq(0, 0),
        [[major, None], [0]] + refl(0) + [[local, eq(1, 0)], 17, 17],
        expected_k=-1001, reason='All major pads must be registered before existential eigenparameter allocation.')

    # Without initial retained-goal registration, this unsound stream can
    # identify the fresh existential witness with a free conclusion name.
    major = ex(eq(1, 0))
    add('free_conclusion_capture_rejected', eq(-1, 0),
        [[major, None], [0]] + refl(0) + [17], strict=False,
        reason='Existential elimination cannot export its local equation as an equation about a free conclusion parameter.')

    add('vacuous_positive_witness', ex(eq(0, 0)), [[1]] + refl(0),
        strict=False, demand=True,
        reason='Demand policy may ignore an unused malformed witness; strict policy validates it.')
    add('vacuous_object_witness', ex(eq(0, 0)), [[{'unused': True}]] + refl(0),
        strict=False, demand=True,
        reason='Unused witness annotations may be arbitrary JSON only under the demand policy.')
    add('witness_used_only_in_own_pad', ex(eq(0, 0), eq(1, 1)), [[1]] + refl(0),
        strict=False, demand=True,
        reason='Own existential pads are not part of its logical matrix and are not opened by direct introduction.')
    nested = ex(eq(0, 0), eq(2, 2))
    add('witness_used_in_nested_pad', ex(nested), [[1], [0]] + refl(0), strict=False,
        reason='A nested pad belongs to the traversed matrix; a demanded image must be validated at depth zero.')
    body = eq([0, 0, 3], 0)
    add('recursor_capture_rejected', ex(body), [[1], []], strict=False,
        reason='A dangling witness index must not be captured by the recursor\'s two binders.')
    add('recursor_closed_image_accepted', ex(body), [[-7], []],
        expected_k=-7, reason='A locally closed rigid image is safe under recursor binders.')

    # Q of a constant equation has its base in context. A normally false
    # attempted major may consume input and still fall back to that base.
    false_major = eq(-1000, [0])
    add('failed_major_falls_back_to_hypothesis', [eq(0, 0)],
        [[], [false_major, None], 17], expected_k=-1000,
        reason='A guarded major returning False permits hypothesis fallback and retains the monotone supply.')
    add('malformed_major_does_not_fall_back', [eq(0, 0)],
        [[], [[], None], 17], strict=False,
        reason='A syntax exception rejects the stream; only a normal failed major permits fallback.')
    add('unused_prefix_allowed', eq(0, 0), refl(0) + [{'unread': 'prefix'}],
        reason='An unread initial stream prefix is permitted by the declared certificate language.')
    return cases


def load(path, label):
    spec = importlib.util.spec_from_file_location('independent_' + label, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_case(module, data):
    module.k = 0
    document = json.loads(json.dumps(data))
    module.take = document.pop
    try:
        accepted = bool(module.check(module.take(), []))
        error = None
    except Exception as exc:
        accepted = False
        error = type(exc).__name__
    return {'accepted': accepted, 'k': module.k, 'error': error,
            'unread_entries': len(document)}


def sensitivity_controls(paths, cases):
    controls = [
        ('strict', 'skip_goal_registration', 'b = inst(a)', 'b = a',
         'free_conclusion_capture_rejected'),
        ('demand', 'skip_image_validation',
         'else inst(env[a - d - 1], sort=False)', 'else env[a - d - 1]',
         'recursor_capture_rejected'),
    ]
    results = []
    for policy, name, old, new, fixture in controls:
        source = paths[policy].read_text()
        if source.count(old) != 1:
            raise ValueError('Sensitivity source no longer matches: ' + name)
        mutant = types.ModuleType('deliberate_defect_' + name)
        exec(compile(source.replace(old, new), str(paths[policy]), 'exec'), mutant.__dict__)
        case = next(c for c in cases if c['name'] == fixture)
        actual = run_case(mutant, case['input'])
        results.append({'name': name, 'policy': policy, 'case': fixture,
                        'mutant_accepted': actual['accepted'],
                        'caught': actual['accepted'] != case['expected'][policy]})
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--strict', type=Path, default=ROOT.parent / 'checker_strict.py')
    parser.add_argument('--demand', type=Path, default=ROOT.parent / 'checker.py')
    parser.add_argument('--output', type=Path, default=ROOT / 'independent_audit.json')
    args = parser.parse_args()
    paths = {'strict': args.strict.resolve(), 'demand': args.demand.resolve()}
    modules = {label: load(path, label) for label, path in paths.items()}
    cases = fixtures()
    case_dir = ROOT / 'independent_cases'
    case_dir.mkdir(exist_ok=True)
    results = []
    for case in cases:
        file = case_dir / (case['name'] + '.json')
        file.write_text(json.dumps(case['input'], indent=2) + '\n')
        row = {k: v for k, v in case.items() if k != 'input'}
        row['file'] = file.relative_to(ROOT).as_posix()
        row['results'] = {}
        for label, module in modules.items():
            actual = run_case(module, case['input'])
            actual['passed'] = actual['accepted'] == case['expected'][label]
            if actual['accepted'] and case['expected_k'] is not None:
                actual['passed'] &= actual['k'] == case['expected_k']
            row['results'][label] = actual
        results.append(row)

    cli = []
    for label, path in paths.items():
        for name in ('q_freshness_from_padding', 'free_conclusion_capture_rejected'):
            case = next(c for c in cases if c['name'] == name)
            run = subprocess.run([sys.executable, str(path), str(case_dir / (name + '.json'))],
                                 capture_output=True, text=True)
            wanted = case['expected'][label]
            cli.append({'policy': label, 'case': name, 'returncode': run.returncode,
                        'stdout': run.stdout.strip(), 'stderr': run.stderr.strip(),
                        'passed': (run.returncode == (0 if wanted else 1)
                                   and run.stdout.strip() == ('ACCEPT' if wanted else 'REJECT'))})
    controls = sensitivity_controls(paths, cases)
    output = {'scope': 'Focused finite implementation audit; no formal metatheorem claim.',
              'sources': {label: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                          for label, path in paths.items()},
              'case_count': len(cases), 'policy_runs': 2 * len(cases), 'cli_runs': len(cli),
              'sensitivity_control_count': len(controls),
              'passed': all(r['passed'] for row in results for r in row['results'].values())
                        and all(r['passed'] for r in cli)
                        and all(r['caught'] for r in controls),
              'cases': results, 'cli': cli, 'sensitivity_controls': controls}
    args.output.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({k: v for k, v in output.items() if k not in ('cases', 'cli')}, indent=2))
    if not output['passed']:
        for row in results:
            if not all(r['passed'] for r in row['results'].values()):
                print(json.dumps(row, indent=2))
        raise SystemExit(1)


if __name__ == '__main__':
    main()
