"""Translate guarded de Bruijn proof streams to the locally nameless checker.

This is an untrusted certificate producer. Every produced certificate is
checked again by the target kernel from a reset global counter. No translation
routine is imported by the theorem checker.
"""
import argparse
import copy
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OLD_PATH = ROOT / 'validation/reference/source_guarded.py'
STRICT_PATH = ROOT / 'comparison/sources/fresh_parameters/checker.py'
DEMAND_PATH = ROOT / 'comparison/sources/fresh_parameters/checker_demand.py'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


OLD = load('fresh_translation_source', OLD_PATH)


def normalize(a):
    """The pinned drafts use q and u for the same closure constructor."""
    if type(a) is list:
        return [normalize(x) for x in a]
    return 'u' if a == 'q' else a


class Target:
    def __init__(self, path, policy='strict'):
        if policy not in ('strict', 'demand'):
            raise ValueError('Unknown witness policy')
        self.kernel = load('fresh_translation_target', path)
        self.strict = policy == 'strict'
        self.open = self.kernel.inst
        self.counter_name = 'k'
        self.reset()

    def reset(self):
        setattr(self.kernel, self.counter_name, 0)

    @property
    def counter(self):
        return getattr(self.kernel, self.counter_name)

    def allocate(self):
        value = self.counter - 1
        setattr(self.kernel, self.counter_name, value)
        return value

    def witness(self, t):
        return self.open(t, formula=False) if self.strict else t


class Translator:
    def __init__(self, target, instruction_count):
        self.target = target
        # All external parameters are renamed uniformly. Widely separated
        # names cannot collide with a generated eigenparameter even when an
        # external parameter first appears in a late proof annotation.
        self.spacing = instruction_count + 2
        self.parameters = {}
        self.preorder = []
        self.counts = {
            'closure_introductions': 0,
            'existential_eliminations': 0,
            'guarded_existential_introductions_removed': 0,
            'guard_reflexivity_certificates': 0,
            'source_assumption_subproofs_shortened': 0,
        }

    def parameter(self, kind, value):
        key = kind, value
        if key not in self.parameters:
            self.parameters[key] = -self.spacing * (len(self.parameters) + 1)
        return self.parameters[key]

    def syntax(self, a, stack, d=0, formula=True):
        """Instantiate former local slots by closed terms; keep inner binders."""
        if not formula and type(a) is int:
            if a < 0:
                return self.parameter('rigid', a)
            if a <= d:
                return a
            index = a - d - 1
            if index < len(stack):
                return copy.deepcopy(stack[index])
            return self.parameter('free_slot', index - len(stack) + 1)
        tag, *args = a
        widths = ({'=': (0, 0), 'u': (1,), 'ex': (1,)} if formula
                  else {'s': (0,), 'r': (0, 0, 2)})[tag]
        return [tag, *(self.syntax(b, stack, d + w, w == 1)
                       for b, w in zip(args, widths, strict=True))]

    def reflexivity(self, a, context):
        """Derive t=t using two R0 axioms and equality transport."""
        if len(a) != 3 or a[0] != '=' or a[1] != a[2]:
            raise ValueError(('removed assumption was not reflexive', a))
        t = a[1]
        axiom = ['=', ['r', 0, t, 0], t]
        instructions = [[axiom, ['=', 1, t]], [], []]
        if not self.target.kernel.check(a, list(reversed(instructions)), context):
            raise ValueError('reflexivity certificate rejected')
        self.preorder.extend(instructions)
        self.counts['guard_reflexivity_certificates'] += 1

    def replay(self, a, proof, old_context, stack, new_context, expected=None):
        new_a = self.syntax(a, stack)
        if expected is not None and new_a != expected:
            raise ValueError(('translation/opening mismatch', a, stack, new_a, expected))
        # Exactly the validation performed at the start of the target check.
        self.target.open(new_a)

        # A source derivation of an available assumption can be shortened to
        # that assumption. Replay the old kernel to consume exactly its input.
        # This also handles source guard failures that fall back to Hyp.
        if a in old_context:
            if not OLD.check(a, proof, old_context):
                raise ValueError('source assumption subproof rejected')
            self.counts['source_assumption_subproofs_shortened'] += 1
            if new_a in new_context:
                self.preorder.append(None)
            else:
                self.reflexivity(new_a, new_context)
            return

        instruction = proof.pop()
        if a[0] == 'u' and instruction == []:
            self.preorder.append([])
            b = a[1]
            old_h = [OLD.subst(b, [0, 0]), b][:len(b) - 1]
            old_goal = OLD.subst(b, [['s', 1], 0])
            new_b = new_a[1]
            new_h = [self.target.open(new_b, (0,)), new_b][:len(new_b) - 1]
            eigen = self.target.allocate()
            goal = self.target.open(new_b, (['s', eigen],))
            context = [*new_context, *(self.target.open(c, (eigen,)) for c in new_h)]
            self.counts['closure_introductions'] += 1
            self.replay(old_goal, proof, [*map(OLD.subst, old_context), *old_h],
                        [eigen, *stack], context, goal)
            return

        if a[0] == 'ex' and type(instruction) is list and len(instruction) == 1:
            [old_t] = instruction
            new_t = self.syntax(old_t, stack, formula=False)
            self.preorder.append([new_t])
            goal = self.target.open(new_a[1], (self.target.witness(new_t),))
            old_h = ['=', 1, OLD.subst(old_t, formula=False)]
            self.counts['guarded_existential_introductions_removed'] += 1
            self.replay(a[1], proof, [*map(OLD.subst, old_context), old_h],
                        [new_t, *stack], new_context, goal)
            return

        if (type(instruction) is list and len(instruction) == 2
                and type(instruction[0]) is list and instruction[0]):
            m, annotation = instruction
            tag, *parts = m
            new_m = self.syntax(m, stack)
            if tag == '=':
                # The equality motive has one implicit substitution slot.
                new_annotation = self.syntax(annotation, stack, d=1)
            elif tag == 'u':
                new_annotation = self.syntax(annotation, stack, formula=False)
            else:
                new_annotation = None
            self.preorder.append([new_m, new_annotation])
            self.replay(m, proof, old_context, stack, new_context, new_m)

            if tag == 'ex':
                eigen = self.target.allocate()
                goal = self.target.open(new_a, (['s', eigen],))
                context = [*new_context, self.target.open(new_m[1], (eigen,))]
                self.counts['existential_eliminations'] += 1
                self.replay(OLD.subst(a), proof,
                            [*map(OLD.subst, old_context), *parts],
                            [eigen, *stack], context, goal)
                return

            if tag == 'u':
                witness = self.target.witness(new_annotation)
                new_motive, new_parts = new_m[1], (0, witness)
                old_motive, old_parts = parts[0], (0, annotation)
            else:
                new_motive, new_parts = new_annotation, tuple(new_m[1:])
                old_motive, old_parts = annotation, tuple(parts)
            new_b, new_c = (self.target.open(new_motive, (v,)) for v in new_parts)
            old_b, old_c = (OLD.subst(old_motive, [v, -1]) for v in old_parts)
            if new_c != new_a or old_c != a:
                raise ValueError(('elimination conclusion mismatch', a, new_a, old_c, new_c))
            self.replay(old_b, proof, old_context, stack, new_context, new_b)
            return

        if (instruction == [] and a[0] == '=' and type(a[1]) is list
                and len(a[1]) == 4 and a[1][0] == 'r'):
            self.preorder.append([])
            if not self.target.kernel.check(new_a, [[]], new_context):
                raise ValueError(('translated computation rejected', new_a))
            return
        raise ValueError(('unrecognized successful source inference', a, instruction))


def accepted(target, data):
    target.reset()
    a, p, *context = data
    try:
        for h in context:
            target.open(h)
        return bool(target.kernel.check(a, copy.deepcopy(p), context))
    except Exception:
        return False


def translate(data, target_path=STRICT_PATH, policy='strict'):
    data = normalize(data)
    a, original_proof, *old_context = data
    for h in old_context:
        OLD.subst(h)
    old_remaining = copy.deepcopy(original_proof)
    if not OLD.check(a, old_remaining, old_context):
        raise ValueError('source certificate rejected')
    target = Target(target_path, policy)
    producer = Translator(target, len(original_proof))
    new_a = producer.syntax(a, [])
    new_context = [producer.syntax(h, []) for h in old_context]
    for h in new_context:
        target.open(h)
    proof = copy.deepcopy(original_proof)
    producer.replay(a, proof, old_context, [], new_context, new_a)
    if proof != old_remaining:
        raise ValueError('source instruction consumption mismatch')
    result = [new_a, list(reversed(producer.preorder)), *new_context]
    expected_counter = target.counter
    if not accepted(target, result):
        raise ValueError('produced certificate rejected by reset target')
    if target.counter != expected_counter:
        raise ValueError(('counter replay mismatch', expected_counter, target.counter))
    details = {
        'external_context_size': len(old_context),
        'source_instructions': len(original_proof),
        'source_instructions_consumed': len(original_proof) - len(proof),
        'target_instructions': len(result[1]),
        'final_counter': target.counter,
        'parameters': [{'kind': kind, 'source': value, 'target': new}
                       for (kind, value), new in producer.parameters.items()],
        **producer.counts,
    }
    return result, details


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--demand', action='store_true')
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    policy = 'demand' if args.demand else 'strict'
    target_path = DEMAND_PATH if args.demand else STRICT_PATH
    certificate, details = translate(json.loads(args.input.read_text()), target_path, policy)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(certificate, separators=(',', ':')) + '\n')
    print(json.dumps(details, indent=2))


if __name__ == '__main__':
    main()
