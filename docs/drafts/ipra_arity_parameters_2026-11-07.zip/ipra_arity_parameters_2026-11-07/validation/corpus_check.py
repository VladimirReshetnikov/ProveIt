"""Untrusted finite comparison for the proposed complete checker files.

Loads existing frozen converters/checkers as comparison oracles. Nothing in
this file is imported by an acceptance program. Successful translations are
checked both by the original named-parameter kernel and by the arity candidate.
"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import random
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / 'validation/corpus'
FRESH = SOURCES / 'fresh_parameters'
DIRECT = SOURCES / 'direct_stream'
ARITY = SOURCES / 'arity'
OUT = ROOT / 'examples'
OUT.mkdir(exist_ok=True)

# Verify the frozen inputs before running the untrusted converter.
for entry in json.loads((ROOT / 'validation/corpus_manifest.json').read_text())['files']:
    if hashlib.sha256((ROOT / entry['file']).read_bytes()).hexdigest() != entry['sha256']:
        raise ValueError('Changed source certificate: ' + entry['file'])
for entry in json.loads((ROOT / 'validation/helper_manifest.json').read_text())['helpers']:
    if hashlib.sha256((ROOT / entry['file']).read_bytes()).hexdigest() != entry['sha256']:
        raise ValueError('Changed frozen validation helper: ' + entry['file'])


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


translator = load('candidate_frozen_translator', ROOT / 'validation' / 'translate_guarded.py')
reference = {
    'strict': load('candidate_reference_strict', ROOT / 'comparison/sources/fresh_parameters/checker.py'),
    'demand': load('candidate_reference_demand', ROOT / 'comparison/sources/fresh_parameters/checker_demand.py'),
}
candidates = {
    'strict': load('candidate_strict', ROOT / 'checker_strict.py'),
    'demand': load('candidate_demand', ROOT / 'checker.py'),
}


def encode(a, sort=True):
    if not sort and type(a) is int:
        return a
    if type(a) is not list or not a:
        raise ValueError('Not tagged syntax')
    tag, *args = a
    if sort and tag == '=' and len(args) == 2:
        return [encode(v, False) for v in args]
    if sort and tag in ('q', 'u') and len(args) == 1:
        return [encode(args[0])]
    if sort and tag == 'ex' and len(args) == 1:
        return [encode(args[0]), [0, 0], [0, 0]]
    if not sort and tag in ('s', 'r') and len(args) == (1 if tag == 's' else 3):
        return [encode(v, False) for v in args]
    raise ValueError('Wrong tagged arity/sort')


def decode(a, sort=True):
    if not sort and type(a) is int:
        return a
    if type(a) is not list:
        raise ValueError('Not arity syntax')
    if sort and len(a) == 1:
        return ['u', decode(a[0])]
    if sort and len(a) == 2:
        return ['=', *(decode(v, False) for v in a)]
    if sort and len(a) == 3:
        # The two extra formula fields are syntax decorations, not conjuncts.
        return ['ex', decode(a[0])]
    if not sort and len(a) in (1, 3):
        return ['s' if len(a) == 1 else 'r', *(decode(v, False) for v in a)]
    raise ValueError('Wrong arity/sort')


def change_stack(stack, change, arity=False):
    result = []
    for instruction in stack:
        if type(instruction) is list and len(instruction) == 1:
            try:
                result.append([change(instruction[0], False)])
            except (ValueError, TypeError, IndexError):
                result.append(copy.deepcopy(instruction))
        elif type(instruction) is list and len(instruction) == 2:
            major, payload = instruction
            changed = change(major)
            kind = len(major) if arity else major[0]
            if kind in (2, '='):
                payload = change(payload)
            elif kind in (1, 'u', 'q'):
                try:
                    payload = change(payload, False)
                except (ValueError, TypeError, IndexError):
                    payload = copy.deepcopy(payload)
            result.append([changed, payload])
        else:
            result.append(copy.deepcopy(instruction))
    return result


def accepts_named(module, document):
    a, p, *g = copy.deepcopy(document)
    module.k = 0
    try:
        for h in g:
            module.inst(h)
        result = module.check(a, p, g)
        return bool(result), len(p), module.k
    except Exception:
        return False, len(p), module.k


def accepts_candidate(module, document):
    a, p, *g = copy.deepcopy(document)
    module.k = 0
    module.take = p.pop
    try:
        for h in g:
            module.inst(h)
        result = module.check(a, g)
        return bool(result), len(p), module.k
    except Exception:
        return False, len(p), module.k


def encoded(document):
    a, p, *g = document
    return [encode(a), change_stack(p, encode), *(encode(h) for h in g)]


records, failures = [], []


def compare(name, document, policy, expected=True, save=False):
    arity = encoded(document)
    source = accepts_named(reference[policy], document)
    target = accepts_candidate(candidates[policy], arity)
    good = target == source and target[0] == expected
    if not good:
        failures.append({'name': name, 'policy': policy, 'expected': expected,
                         'source': source, 'candidate': target})
    row = {'name': name, 'policy': policy, 'closed': len(document) == 2,
           'expected': expected, 'accepted': target[0],
           'remaining': target[1], 'same_final_counter': target[2] == source[2]}
    if save and len(document) == 2:
        goal, stack = arity
        file = OUT / (name.replace('/', '__') + '__' + policy + '.json')
        file.write_text(json.dumps([*stack, goal], separators=(',', ':')) + '\n')
        row['file'] = str(file.relative_to(ROOT))
        row['sha256'] = hashlib.sha256(file.read_bytes()).hexdigest()
    records.append(row)
    return arity


for policy in ('strict', 'demand'):
    for p in sorted((FRESH / 'examples' / policy).rglob('*.json')):
        compare('fresh/' + str(p.relative_to(FRESH / 'examples' / policy)),
                json.loads(p.read_text()), policy, save=True)

translated = []
for p in sorted((DIRECT / 'examples').glob('*.json')):
    document = json.loads(p.read_text())
    source = [document[-1], document[:-1]]
    for policy, target_path in [('strict', translator.STRICT_PATH), ('demand', translator.DEMAND_PATH)]:
        new, details = translator.translate(source, target_path, policy)
        compare('direct/' + p.stem, new, policy, save=True)
        if policy == 'strict':
            translated.append(new)

for p in sorted((ARITY / 'examples').glob('*.json')):
    a, stack, *g = json.loads(p.read_text())
    source = [decode(a), change_stack(stack, decode, True), *(decode(h) for h in g)]
    for policy, target_path in [('strict', translator.STRICT_PATH), ('demand', translator.DEMAND_PATH)]:
        new, details = translator.translate(source, target_path, policy)
        compare('arity/' + p.stem, new, policy, save=True)
        if policy == 'strict':
            translated.append(new)

# Negative/positive mutated proofs are compared against both current kernels;
# no assumption that an arbitrary syntactic mutation must invalidate a proof.
rng = random.Random(20261107)
mutation_accepts = 0
for i in range(400):
    document = copy.deepcopy(rng.choice(translated))
    if i % 4 == 0:
        document[0] = ['=', 0, ['s', 0]]
    elif i % 4 == 1 and document[1]:
        document[1].pop(rng.randrange(len(document[1])))
    elif i % 4 == 2 and len(document[1]) > 1:
        j, k = rng.sample(range(len(document[1])), 2)
        document[1][j], document[1][k] = document[1][k], document[1][j]
    elif document[1]:
        document[1][rng.randrange(len(document[1]))] = rng.choice([None, []])
    for policy in ('strict', 'demand'):
        expected = accepts_named(reference[policy], document)[0]
        compare('mutation/%04d' % i, document, policy, expected)
        mutation_accepts += expected

cli = []
public = [r for r in records if 'file' in r]
selected = [public[0], public[len(public)//2], public[-1]]
with tempfile.TemporaryDirectory() as temporary:
    for mode in ([], ['-O']):
        for row in selected:
            path = ROOT / row['file']
            checker = ROOT / ('checker_strict.py' if row['policy'] == 'strict' else 'checker.py')
            run = subprocess.run([sys.executable, *mode, str(checker), str(path)], capture_output=True, text=True)
            good = run.returncode == 0 and run.stdout.strip() == 'ACCEPT'
            cli.append({'name': row['name'], 'optimized': bool(mode), 'passed': good})
            if not good:
                failures.append({'CLI': row['name'], 'mode': mode, 'stdout': run.stdout})
        for name, content in [('contradiction', [None, [0, [0]]]),
                              ('bad_goal', [None, True]),
                              ('context_injection', [[0, [0]], [None], [[0, [0]]]])]:
            path = Path(temporary) / (name + '.json')
            path.write_text(json.dumps(content))
            run = subprocess.run([sys.executable, *mode, str(ROOT / 'checker.py'), str(path)], capture_output=True, text=True)
            good = run.returncode == 1 and run.stdout.strip() == 'REJECT'
            cli.append({'name': name, 'optimized': bool(mode), 'passed': good})
            if not good:
                failures.append({'CLI': name, 'mode': mode, 'stdout': run.stdout})

summary = {
    'status': 'PASS' if not failures else 'FAIL',
    'candidate_checks': len(records),
    'fresh_corpus_checks': sum(r['name'].startswith('fresh/') for r in records),
    'direct_stream_translations': sum(r['name'].startswith('direct/') for r in records),
    'arity_translations': sum(r['name'].startswith('arity/') for r in records),
    'mutation_comparisons': sum(r['name'].startswith('mutation/') for r in records),
    'mutation_comparisons_accepted': mutation_accepts,
    'public_certificates_saved': len(public),
    'canonical_leftover_instructions': sum(r['remaining'] for r in public),
    'cli_checks': len(cli),
    'failure_count': len(failures),
    'scope': 'Finite executable comparisons; not a formalized metatheorem.'
}
(ROOT / 'results/validation.json').write_text(json.dumps({'summary': summary, 'records': records, 'cli': cli, 'failures': failures}, indent=2) + '\n')
print(json.dumps(summary, indent=2))
if failures:
    print(json.dumps(failures[:10], indent=2))
    raise SystemExit(1)
