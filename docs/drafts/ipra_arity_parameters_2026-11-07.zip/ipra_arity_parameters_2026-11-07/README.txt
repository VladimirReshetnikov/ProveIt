A SMALLER COMPLETE PRESENTATION OF iPRA
7 November 2026

Read report.pdf for the full mathematical construction, proofs,
comparison, combinator analysis, and further research questions.
report.tex and its four included section files are the complete source.

RESULT

The primary complete checker has 460 normalized significant Python tokens,
469 AST nodes, and 1409 normalized UTF-8 bytes. The coordinatewise minima
among all nine complete top-level checkers in the six current ProveIt draft
archives are 483 tokens, 491 AST nodes, and 1462 bytes. The acceptance core
is also smaller in all three measures: 400/404/1149 against 423/425/1200.

The pinned repository snapshot is:
c5f42a50d9213259760ee385977481c04dccab28
https://github.com/VladimirReshetnikov/ProveIt/tree/c5f42a50d9213259760ee385977481c04dccab28/docs/drafts

The improvement combines arity syntax, locally nameless fresh numerical
parameters, and one proof stream. The arithmetic and logical basis is
inherited, with attribution, from the supplied drafts. No new deletion
of an arithmetic axiom or absolute shortestness theorem is claimed.

The target is full intuitionistic first-order PRA, with unrestricted
ambient quantification and induction for all quantifier-free formulas.
The report gives both ordinary interpretations and proves that equality
defines the two composite isomorphisms, including on nonstandard models.
Its full-logic reconstruction is not merely an equational conservativity
claim. The metatheorems are mathematical proofs, not Lean/Rocq artifacts.

FILES

checker.py                 Complete primary acceptance program (demand).
checker_strict.py          Strict witness-validation companion.
FORMAT.txt                 Exact public certificate format.
report.tex, *.tex           Full report source and section files.
report.pdf                 Compiled report.
comparison/                All nine frozen baseline sources, licenses,
                           hashes, and unchanged measurement program.
measure_candidates.py      Recompute candidate metrics and TeX numbers.
validate.py                Run all packaged validation without a network.
validation/                Frozen inputs, translators, independent audit.
examples/                  450 public theorem certificates for the two
                           separately simulated witness policies.
results/                   Metrics, detailed validation records, build QA.
build.py                   Rebuild the PDF using pdflatex.
ATTRIBUTION.txt             Origin of inherited code and mathematical basis.
MANIFEST.sha256            Hashes of the final package files.

REPRODUCTION

Use Python 3.10 or later. Recorded metrics use CPython 3.12.14; Python AST
and unparse details can differ between interpreter versions.

  python3 comparison/measure.py
  python3 measure_candidates.py
  python3 validate.py
  python3 checker.py examples/direct__72_recursion_zero__demand.json
  python3 build.py

The final command additionally requires pdflatex and the standard packages
listed in report.tex. The other commands use only Python's standard library.
No network or source repository checkout is needed after extracting this ZIP.

The primary checker consumes one JSON list from its end: the last item
is the goal, and preceding items are a reversed proof-instruction stream.
It starts with an EMPTY context. Internal open-sequent fixtures are not
public theorem certificates. Demand examples end in __demand.json; their
strict counterparts end in __strict.json and use checker_strict.py.

VALIDATION

1292 differential comparisons, 50 independent policy runs, 16 command-line
checks, and two deliberate-defect controls passed. The canonical public
examples consume every instruction. Details and source hashes are recorded
in results/validation.json and validation/independent_audit.json.

Finite tests support the implementation; they do not prove consistency.
Relative consistency and bi-interpretability follow from the report's
mathematical arguments. Completeness is for the abstract finite algorithm
with adequate execution resources; a fixed Python recursion or memory
limit can reject a very large valid certificate.

COMBINATORS

The report proves that total untyped SK application plus a successor
combinator on the entire numerical domain produces a fixed point of
successor, contradicting iPRA. Typed, partial, or separately sorted
combinators escape that specific obstruction but require further
interpretation and kernel-size work. No unsupported claim of a smaller
combinator-based bi-interpretation is made.
