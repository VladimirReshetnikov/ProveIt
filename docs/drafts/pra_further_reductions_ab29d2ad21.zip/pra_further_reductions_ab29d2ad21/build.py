#!/usr/bin/env python3
"""Offline authored-check and TeX rebuild runner. Never executes source archives."""
import argparse,json,subprocess,sys,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def run(args,cwd=ROOT):
 return subprocess.run(args,cwd=cwd,text=True,capture_output=True,check=True)

def checks():
 a=ROOT/'artifacts'; r=a/'relational'
 commands=[a/'check_frontiers.py',a/'recursion/check_endpoint18.py',a/'induction/check_anchored_one_mark.py']
 result=[]
 for f in commands:
  plain=run([sys.executable,str(f)]); optimized=run([sys.executable,'-O',str(f)])
  if plain.stdout!=optimized.stdout:raise RuntimeError('Normal/-O output mismatch: '+str(f))
  json.loads(plain.stdout)
  if f.name=='check_endpoint18.py':f.with_name('endpoint18_checks.json').write_text(plain.stdout)
  if f.name=='check_anchored_one_mark.py':
   f.with_name('anchored_checks.normal.json').write_text(plain.stdout)
   f.with_name('anchored_checks.optimized.json').write_text(optimized.stdout)
  result.append({'script':str(f.relative_to(ROOT)),'normal_and_optimized_pass':True,'stdout_byte_identical':True})
  print('PASS '+str(f.relative_to(ROOT)),flush=True)
 graph=run([sys.executable,str(r/'validate_relational.py')])
 graph_result=json.loads((r/'final_relational_validation.json').read_text())
 if graph_result['status']!='PASS':raise RuntimeError('Relational validation failed')
 print('PASS artifacts/relational/validate_relational.py (16 subprocesses)',flush=True)
 (a/'replay_checks.json').write_text(json.dumps({'status':'PASS','arithmetic_checks':result,'relational_validation':'PASS: eight scripts in normal and optimized modes','scope':'Finite syntax/numerical diagnostics, not proof-assistant certificates.'},indent=2)+'\n')

def pdf():
 exe=shutil.which('pdflatex')
 if exe is None:raise SystemExit('pdflatex unavailable; configure TeX Live and rerun.')
 out=ROOT/'_build';out.mkdir(exist_ok=True)
 for i in range(1,4):
  p=run([exe,'-interaction=nonstopmode','-halt-on-error','-no-shell-escape','-output-directory='+str(out),'report.tex'])
  (out/f'latex-pass-{i}.log').write_text(p.stdout+p.stderr)
 log=(out/'report.log').read_text(errors='replace')
 if any(s in log for s in ('Undefined control sequence','There were undefined references')):raise RuntimeError('Unresolved TeX reference/error')
 shutil.copy2(out/'report.pdf',ROOT/'report.pdf');print('Rebuilt report.pdf; review layout before redistribution.')

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group();g.add_argument('--checks-only',action='store_true');g.add_argument('--pdf-only',action='store_true');args=p.parse_args()
 if not args.pdf_only:checks()
 if not args.checks_only:pdf()
