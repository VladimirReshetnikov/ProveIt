#!/bin/sh
set -eu
cd "$(dirname "$0")"
# A configured TeX Live works through build.py directly. On a minimal Linux
# installation, keep generated formats/maps in this package's writable _build.
if [ "${1:-}" != '--checks-only' ] && [ -d /usr/share/texlive/texmf-dist/tex ] && command -v pdftex >/dev/null 2>&1; then
  cache="$PWD/_build/texcache"
  mkdir -p "$cache/var" "$cache/config"
  export TEXINPUTS='.:/usr/share/texlive/texmf-dist/tex//:/usr/share/texmf/tex//:'
  export TEXFORMATS="$cache//:"
  export TEXMFVAR="$cache/var" TEXMFCONFIG="$cache/config"
  export TEXFONTMAPS="$cache//:/usr/share/texlive/texmf-dist/fonts/map//:/usr/share/texmf/fonts/map//:"
  export TFMFONTS='/usr/share/texmf/fonts/tfm//:/usr/share/texlive/texmf-dist/fonts/tfm//:'
  export T1FONTS='/usr/share/texmf/fonts/type1//:/usr/share/texlive/texmf-dist/fonts/type1//:'
  export VFFONTS='/usr/share/texmf/fonts/vf//:/usr/share/texlive/texmf-dist/fonts/vf//:'
  export ENCFONTS='/usr/share/texmf/fonts/enc//:/usr/share/texlive/texmf-dist/fonts/enc//:'
  if [ ! -f "$cache/pdflatex.fmt" ]; then
    (cd "$cache"; pdftex -ini -etex -jobname=pdflatex -progname=pdflatex pdflatex.ini > format.log)
  fi
  find /usr/share/texmf/fonts/map /usr/share/texlive/texmf-dist/fonts/map \
    -name lm.map -o -name cm.map -o -name cmextra.map -o -name symbols.map | sort | xargs cat > "$cache/pdftex.map"
fi
exec python3 build.py "$@"
