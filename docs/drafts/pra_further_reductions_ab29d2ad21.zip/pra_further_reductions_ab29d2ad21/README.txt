FURTHER REDUCTIONS OF BINARY PRA AND GRAPH AXIOMS
Prepared for Vladimir Reshetnikov; 2 November 2026.
Reviewed commit and main-at-intake: ab29d2ad2189948d995d6cffa7cea5298cd126a0.

START HERE
  report.pdf / report.tex    Complete 22-page mathematical report and source.
  AXIOMS.txt                 Short, exact specifications and count boundaries.
  VALIDATION.txt             Verification scope, evidence and replay commands.
  source_manifest.json       Pinned input identities and reference hashes.

MAIN RESULTS
1. Anchored literal 26: retain the existing outer 26 and one-mark gate, but
   restrict C to R_h(n,a)=t(n,a), the fixed initializer, falsity, or one
   fixed coverage shape. Only ONE arbitrary term remains. All actual
   axioms have at most two variable names. The full constructive bootstrap
   and compiler are given once. Deleting coverage prevents BI-interpretability
   in this interface; a one-way interpretation is not excluded.
2. Endpoint 18: a smaller partial display using three actual variables and
   three explicit atomic admission patterns. This is an honestly qualified
   trade-off, not a smaller complete encoding or an absolute minimum.
3. Binary-relation target: graph 49, an integrated fixed seed 159, and
   per-arithmetic-axiom overhead 39, improving round6's 337/72 (338 if its
   two fixed sentences are conjoined). Decoder 21 remains. The arithmetic
   scheme remains infinite. Complete source and graph round trips are proved.

Both matching classical/intuitionistic theories are treated separately.
No new end-to-end formal-kernel certificate or global shortestness claim.

REPRODUCE OFFLINE
Python 3.10+ standard library; TeX Live with the report's listed packages.
  sha256sum -c SHA256SUMS      # verify delivered bytes BEFORE rebuilding
  sh checks.sh                # all authored diagnostics, normal and -O
  sh build.sh --pdf-only      # rebuild PDF with shell escape disabled
  sh build.sh                 # both
Direct Python entry point: python3 build.py [--checks-only|--pdf-only].
The shell wrapper can create a package-local TeX cache on minimal Linux
installations. The direct Python PDF mode expects configured TeX Live.
No source/reference archive scripts are executed by these commands.
Rebuilding can change PDF metadata and generated evidence; identical PDF
bytes are not promised. The delivered PDF has separate visual audit evidence.

PROVENANCE AND REFERENCES
All eight input ZIPs were Git-blob/size verified, safely extracted, and
read as mathematical text. All 219 supplied internal SHA256 entries pass.
No downloaded Python, shell, Makefile, Lean or TeX program was executed.
The complete original input inventory and immutable URLs are in sources/.
The sealed round6 ZIP is retained unmodified under references/; it is
exactly the same archive now included in the user's repository commit.
The inherited fixed-program trace calibration remains explicit in the
report and references/alternate_signature.tex. It was not newly formalized.
references/intermediate_equation_grammar.tex preserves a superseded broader
research step; anchored_one_mark.tex is the final recommendation.

OPEN QUESTIONS
The old T0 arbitrary-seed initialization question and counter-free predecessor
problem remain open. The new admission rules do not settle them. Future
cost comparisons should price the generator as well as expanded axioms.
