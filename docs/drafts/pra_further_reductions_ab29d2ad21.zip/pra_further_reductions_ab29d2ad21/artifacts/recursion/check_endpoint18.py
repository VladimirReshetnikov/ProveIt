#!/usr/bin/env python3
"""Authored finite syntax checks for E18/E19; not a semantic proof checker."""
import json
from pathlib import Path


def V(name): return ('var', name)
def Z(): return ('zero',)
def Fn(name, *args): return ('fn', name, tuple(args))
def S(t): return Fn('S', t)
def Eq(t,u): return ('eq', t, u)
def Imp(p,q): return ('imp',p,q)
def And(p,q): return ('and',p,q)
def Or(p,q): return ('or',p,q)
def All(v,p): return ('all',v,p)
def Pred(name,*args): return ('pred',name,tuple(args))
BOT=('bot',)
TAU=Eq(Z(),Z())
BAD=Eq(Z(),S(Z()))
CURRENT='R_h'
BODY=Fn('R_old', V('u'), S(V('v')))
EARLIER={'S':1,'R_old':2}

def require(ok, message):
    if not ok: raise AssertionError(message)

def term_vars(t):
    if t[0]=='var': return {t[1]}
    if t[0]=='zero': return set()
    if t[0]=='fn': return set().union(*(term_vars(a) for a in t[2]))
    raise ValueError('not a term')

def formula_vars(f):
    if f[0]=='bot': return set()
    if f[0]=='eq': return term_vars(f[1])|term_vars(f[2])
    if f[0] in ('imp','and','or'): return formula_vars(f[1])|formula_vars(f[2])
    raise ValueError('not an admitted QF formula')

def validate_body(t):
    if t[0]=='var': return t[1] in {'u','v'}
    if t[0]=='zero': return True
    if t[0]=='fn':
        return (t[1] in EARLIER and len(t[2])==EARLIER[t[1]]
                and all(validate_body(a) for a in t[2]))
    return False

def st(t,mapping):
    if t[0]=='var': return mapping.get(t[1],t)  # do not traverse inserted trees
    if t[0]=='zero': return t
    if t[0]=='fn': return Fn(t[1],*(st(a,mapping) for a in t[2]))
    raise ValueError('not a term')

def sf(f,mapping):
    if f[0]=='bot': return f
    if f[0]=='eq': return Eq(st(f[1],mapping),st(f[2],mapping))
    if f[0] in ('imp','and','or'): return (f[0],sf(f[1],mapping),sf(f[2],mapping))
    raise ValueError('not an admitted QF formula')

def R(t,u,current=CURRENT): return Fn(current,t,u)

def rhs(t,u,body=BODY,current=CURRENT):
    return st(body, {'u':t,'v':R(t,u,current)})

def norm(f,body=BODY,current=CURRENT):
    """One formula traversal. Terms and replacement atoms are not traversed."""
    tag=f[0]
    if tag=='bot': return f
    if tag in ('imp','and','or'):
        return (tag,norm(f[1],body,current),norm(f[2],body,current))
    if tag!='eq': raise ValueError('not an admitted QF formula')
    left,right=f[1],f[2]
    if left[0]=='fn' and left[1]==current and len(left[2])==2:
        counter,seed=left[2]
        if counter==Z() and right==seed: return TAU
        if counter[0]=='fn' and counter[1]=='S' and len(counter[2])==1:
            t=counter[2][0]
            if right==rhs(t,seed,body,current): return TAU
    if f==BAD: return BOT
    return f

def admitted(f,body=BODY,current=CURRENT):
    if not validate_body(body): return False
    if not formula_vars(f)<={'x','y','z'}: return False
    base=sf(f, {'x':Z(),'y':V('a'),'z':V('b')})
    nbase=norm(base,body,current)
    return nbase[0]=='imp' and nbase[1]==nbase[2]

def size(t):
    tag=t[0]
    if tag in ('var','zero','bot'): return 1
    if tag in ('fn','pred'): return 1+sum(size(a) for a in t[2])
    if tag in ('eq','imp','and','or'): return 1+size(t[1])+size(t[2])
    if tag=='all': return 1+size(t[2])
    raise ValueError(tag)

def emitted(f,endpoint=True):
    a,b,n=V('a'),V('b'),V('n')
    now=sf(f,{'x':n,'y':a,'z':b})
    nxt=sf(f,{'x':S(n),'y':a,'z':b})
    conclusion=sf(f,{'x':a,'y':a,'z':b}) if endpoint else All('n',now)
    return All('a',All('b',Imp(All('n',Imp(now,nxt)),conclusion)))

checks=[]
def check(name,condition):
    require(condition,name)
    checks.append(name)

x,y,z=V('x'),V('y'),V('z')
a,b,n=V('a'),V('b'),V('n')
check('earlier binary update accepted', validate_body(BODY))
check('self-containing update rejected', not validate_body(R(V('u'),V('v'))))
check('hidden update parameter rejected', not validate_body(V('c')))
check('zero atom recognized', norm(Eq(R(Z(),a),a))==TAU)
check('successor atom recognized', norm(Eq(R(S(a),b),rhs(a,b)))==TAU)
check('bad atom recognized', norm(BAD)==BOT)
check('opposite equality orientation not rewritten', norm(Eq(a,R(Z(),a)))==Eq(a,R(Z(),a)))
check('earlier symbol not rewritten',norm(Eq(R(Z(),a,'R_old'),a))==Eq(R(Z(),a,'R_old'),a))
check('wrong successor counter not rewritten', norm(Eq(R(S(a),b),rhs(S(a),b)))==Eq(R(S(a),b),rhs(S(a),b)))
check('wrong successor seed not rewritten', norm(Eq(R(S(a),b),rhs(a,a)))==Eq(R(S(a),b),rhs(a,a)))
inside=Eq(S(R(Z(),a)),S(a))
check('no rewriting inside terms',norm(inside)==inside)
check('arbitrary reflexive equality retained',norm(Eq(a,a))==Eq(a,a))
check('replacement atom is stable', norm(TAU)==TAU and norm(BOT)==BOT)

zero_probe=Imp(TAU,Eq(R(Z(),z),z))
step_probe=Imp(TAU,Eq(R(S(y),z),rhs(y,z)))
sep_probe=Imp(BAD,BOT)
G=Or(Eq(x,z),Imp(Eq(R(Z(),x),x),Eq(S(z),S(z))))
qfi1_probe=Imp(sf(G,{'x':Z()}),G)
G2=Or(Eq(x,y),Eq(R(Z(),z),z))
qfi2_probe=Imp(sf(G2,{'x':Z()}),G2)
for label,probe in [('zero',zero_probe),('successor',step_probe),('separation',sep_probe),('QFI1',qfi1_probe),('QFI2',qfi2_probe)]:
    check(label+' probe admitted',admitted(probe))
    check(label+' zero-normalization reflexive',
          norm(sf(probe,{'x':Z(),'y':a,'z':b}))[1]==norm(sf(probe,{'x':Z(),'y':a,'z':b}))[2])
check('QFI1 middle slot unused', 'y' not in formula_vars(qfi1_probe))
check('QFI1 endpoint has desired G(a,b)',
      sf(qfi1_probe,{'x':a,'y':a,'z':b})==Imp(sf(G,{'x':Z(),'z':b}),sf(G,{'x':a,'z':b})))
check('hidden formula parameter rejected',not admitted(Imp(Eq(V('c'),V('c')),Eq(V('c'),V('c')))))
check('unguarded arbitrary equation rejected',not admitted(Eq(R(Z(),z),z)))
check('malformed successor probe rejected',not admitted(Imp(TAU,Eq(R(S(y),z),rhs(S(y),z)))))
check('simultaneous substitution does not traverse inserted term', st(y,{'y':R(Z(),y)})==R(Z(),y))

A=lambda t:Pred('F',t,a,b)
E18=All('a',All('b',Imp(All('n',Imp(A(n),A(S(n)))),Pred('F',a,a,b))))
E19=All('a',All('b',Imp(All('n',Imp(A(n),A(S(n)))),All('n',A(n)))))
A2=lambda t:Pred('F',t,a)
step_placeholder=Eq(R(S(n),a),Fn('h',n,R(n,a)))
N26=All('a',Imp(All('n',Imp(A2(n),A2(S(n)))),All('n',And(A2(n),step_placeholder))))
check('E18 count is 18',size(E18)==18)
check('E19 count is 19',size(E19)==19)
check('source N26 count is 26',size(N26)==26)

def name_inventory(t):
    tag=t[0]
    if tag=='var': return {t[1]}
    if tag in ('zero','bot'): return set()
    if tag in ('fn','pred'): return set().union(*(name_inventory(a) for a in t[2]))
    if tag in ('eq','imp','and','or'): return name_inventory(t[1])|name_inventory(t[2])
    if tag=='all': return {t[1]}|name_inventory(t[2])
    raise ValueError(tag)

check('E18 actual variable-name inventory', name_inventory(E18)=={'a','b','n'})
check('E19 actual variable-name inventory', name_inventory(E19)=={'a','b','n'})
check('source N26 actual variable-name inventory', name_inventory(N26)=={'a','n'})
for label,probe in [('zero',zero_probe),('successor',step_probe),('separation',sep_probe),('QFI1',qfi1_probe)]:
    check(label+' emitted axiom has only three variable names',name_inventory(emitted(probe))=={'a','b','n'})
    check(label+' normalization is idempotent',norm(norm(probe))==norm(probe))

result={
 'status':'passed', 'checks':checks, 'check_count':len(checks),
 'counts':{'E18':size(E18),'E19':size(E19),'existing_N26_outer':size(N26)},
 'actual_variable_names':{'E18':['a','b','n'],'E19':['a','b','n'],'existing_N26':['a','n']},
 'normalizer':'One formula-node traversal; exact current-index computation atom matches; no term rewriting.',
 'scope':'Finite authored syntax, admission, probe and metric diagnostics only. Written equivalence uses the established binary one-parameter arithmetic theorem; no proof-assistant certificate claimed.'
}
print(json.dumps(result,indent=2))
