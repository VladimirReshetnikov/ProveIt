(forall v (R a z v z))
