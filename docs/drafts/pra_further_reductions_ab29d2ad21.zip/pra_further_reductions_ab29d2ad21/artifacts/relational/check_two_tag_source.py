#!/usr/bin/env python3
"""Finite diagnostics for H48/G6 (and H42); NOT finite models of PRA.
Only this round's locally authored AST builder is imported.
"""
from pathlib import Path
from itertools import product
from functools import lru_cache
import json,hashlib
from two_tag_source import H42,H48,G6,C51

def check(ok,data):
 if not ok:raise RuntimeError(data)

def ast_eval(ast,D,R,env):
 op=ast[0]
 if op=='var':return env[ast[1]]
 if op=='false':return False
 if op=='R':return tuple(env[x[1]] for x in ast[1:]) in R
 if op=='=':return env[ast[1][1]]==env[ast[2][1]]
 if op=='and':return ast_eval(ast[1],D,R,env) and ast_eval(ast[2],D,R,env)
 if op=='or':return ast_eval(ast[1],D,R,env) or ast_eval(ast[2],D,R,env)
 if op=='imp':return not ast_eval(ast[1],D,R,env) or ast_eval(ast[2],D,R,env)
 vals=(ast_eval(ast[2],D,R,{**env,ast[1]:x}) for x in D)
 if op=='forall':return all(vals)
 if op=='exists':return any(vals)
 raise RuntimeError(op)

def semantic_H(D,R,z,a,variant=48):
 for x,y,t in product(D,repeat=3):
  good=False
  for u in D:
   if all(((a,z,x,z) in R if variant==42 else (t!=a or x!=z or u==z)) and
      (t not in (z,a) or (t,x,y,u) in R) and
      ((t,x,y,w) not in R or (t in (z,a) and w==u)) for w in D):
    good=True;break
  if not good:return False
 return True

def structural_obligations(D,R,z,a):
 G=all((a,z,v,z) in R for v in D)
 total_unique=all(sum((t,x,y,w) in R for w in D)==1 for t in (z,a) for x,y in product(D,repeat=2))
 support=all(t in (z,a) for t,x,y,w in R)
 return G and total_unique and support

def canonical(t,x,y,w):return (t==0 and w==x+y) or (t==1 and w==x*y)

def main():
 cases=accepted=astchecks=0
 for n in (1,2):
  D=tuple(range(n));tuples=tuple(product(D,repeat=4))
  for bits in range(1<<len(tuples)):
   R={v for i,v in enumerate(tuples) if (bits>>i)&1}
   for z,a in product(D,repeat=2):
    got=semantic_H(D,R,z,a);want=structural_obligations(D,R,z,a)
    check(got==want,('finite equivalence',n,bits,z,a,got,want))
    cases+=1;accepted+=int(got)
    if got or bits%997==0:
     env={'z':z,'a':a}
     check(ast_eval(H42(),D,R,env)==got,('H42 AST',n,bits,z,a))
     check(ast_eval(H48(),D,R,env)==got,('H48 AST',n,bits,z,a))
     check((ast_eval(C51(),D,R,env) and ast_eval(G6(),D,R,env))==got,('C/G AST',n,bits,z,a))
     astchecks+=1
 guardchecks=0
 for z,a in product(range(33),repeat=2):
  # Values 0,1 suffice to exclude every noncanonical guard witness in the proof.
  test=all(canonical(a,z,v,z) for v in (0,1))
  check(test==(z==0 and a==1),('canonical G',z,a));guardchecks+=1
 reversechecks=0
 for x,y,t in product(range(17),repeat=3):
  u=x+y if t==0 else x*y if t==1 else 0
  for w in {*range(18),u,x+y,x*y}:
   check(canonical(1,0,x,0),('G inclusion',x))
   check(t!=1 or x!=0 or u==0,('H48 output constraint',x,y,t,u))
   check(t not in (0,1) or canonical(t,x,y,u),('total',x,y,t,u))
   check(not canonical(t,x,y,w) or (t in (0,1) and w==u),('output',x,y,t,u,w))
   reversechecks+=1
 result={'status':'PASS','all_finite_relation_parameter_cases_domains_1_2':cases,
  'H48_satisfying_cases':accepted,'independent_exact_AST_crosscheck_cases':astchecks,
  'canonical_guard_two_test_checks':guardchecks,'canonical_reverse_witness_checks':reversechecks,
  'finite_equivalence_test_is_classical_only':True,
  'canonical_arithmetic_samples_are_not_models_of_PRA':True,
  'not_a_proof_assistant_certificate':True,
  'always_active_checks_not_python_asserts':True}
 p=Path(__file__).with_name('two_tag_source_checks.json');p.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
