#!/usr/bin/env python3
"""Fresh graph49 ledger; no downloaded code is imported."""
from functools import reduce
import json,pathlib
V=lambda x:('var',x)
BOT=('false',)
def E(x,y):return ('E',V(x),V(y))
def eq(x,y):return ('=',V(x),V(y))
def imp(a,b):return ('imp',a,b)
def neg(a):return imp(a,BOT)
def AND(*xs):return reduce(lambda a,b:('and',a,b),xs)
def OR(*xs):return reduce(lambda a,b:('or',a,b),xs)
def FA(x,f):return ('forall',x,f)
def EX(x,f):return ('exists',x,f)
def ALL(vs,f):return reduce(lambda f,x:FA(x,f),reversed(vs),f)
def SOME(vs,f):return reduce(lambda f,x:EX(x,f),reversed(vs),f)
def count(t):
 if t[0] in ('var','false'):return 1
 if t[0] in ('forall','exists'):return 1+count(t[2])
 return 1+sum(count(x) for x in t[1:])
def O(x):return E(x,'m')
def U(x,a,b,y):return imp(AND(E(a,y),E(y,b)),eq(y,x))
def D(x):return SOME(['a','b'],AND(O('a'),O('b'),FA('y',U(x,'a','b','y'))))
def B(x):return AND(O(x),FA('y',imp(O('y'),neg(E(x,'y')))))
def H49():return EX('m',FA('x',AND(neg(E('m','x')),OR(eq('x','m'),B('x'),D('x')))))
def decoder():return SOME(['p','q'],AND(E('x','p'),E('p','y'),E('t','q'),E('q','w'),E('p','q')))
def sexpr(t):
 if t[0]=='var':return t[1]
 if t[0]=='false':return 'false'
 if t[0] in ('forall','exists'):return f'({t[0]} {t[1]} {sexpr(t[2])})'
 return '('+' '.join([t[0]]+[sexpr(a) for a in t[1:]])+')'
if __name__=='__main__':
 result={'structure':count(H49()),'decoder':count(decoder()),'coordinate_branch':count(D('x')),'object_branch':count(B('x')),'additional_arithmetic_fact':'Whole source relation is single-valued in its output argument; object domain has two distinct elements','same_source_relation_required':True}
 if result['structure']!=49:raise RuntimeError(result)
 here=pathlib.Path(__file__).parent;(here/'graph49_metrics.json').write_text(json.dumps(result,indent=2)+'\n');(here/'graph49.sexp').write_text(sexpr(H49())+'\n');print(json.dumps(result,indent=2))
