#!/usr/bin/env python3
"""Independently rebuild the integrated159/39 target using the source audit's AST.
The author's integrated S-expressions are parsed as data, never imported.
"""
from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent
REL=HERE if (HERE/'two_tag_source.py').is_file() else HERE.parent/'research'/'relational'
sys.path.insert(0,str(REL))
from two_tag_source import H48,H49,G6,source_scheme,graph_translate,ALL,SOME,AND,OR,E,eq,imp,size,sexpr

def integrated():
 structure=H49()[2][2]
 h=graph_translate(H48())
 if h[:2]!=('forall','x'):raise RuntimeError('unexpected prefix')
 return SOME(['marker','z','a'],AND(E('z','marker'),E('a','marker'),ALL(['x'],AND(structure,h[2]))))
def scheme():
 return ALL(['marker'],OR(SOME(['r'],E('marker','r')),graph_translate(source_scheme(eq('q','q')))))
def scheme39():
 return ALL(['marker'],OR(SOME(['r'],E('marker','r')),
  ALL(['z','a'],imp(E('a','marker'),imp(graph_translate(G6()),graph_translate(eq('q','q')))))))
def parse(s):
 ts=iter(s.replace('(',' ( ').replace(')',' ) ').split())
 def item(tok):
  if tok!='(':return tok
  row=[]
  for tok in ts:
   if tok==')':return row
   row.append(item(tok))
  raise ValueError('unclosed')
 out=item(next(ts))
 if next(ts,None) is not None:raise ValueError('extra tokens')
 return out
def alpha(t,scope=()):
 if isinstance(t,str):
  for i,s in enumerate(reversed(scope)):
   if t==s:return ('bound',i)
  return ('free',t)
 if t[0] in ('forall','exists'):
  return (t[0],alpha(t[2],scope+(t[1],)))
 return (t[0],*(alpha(x,scope) for x in t[1:]))
def main():
 ours={'integrated159':integrated(),'scheme_test':scheme(),'scheme39_test':scheme39()}
 result={'status':'PASS','nodes':{},'author_AST_alpha_equivalence':{},'source_reads_as_data_only':True}
 for k,t in ours.items():
  s=sexpr(t)+'\n';(HERE/('independent_'+k+'.sexp')).write_text(s)
  authored=(REL/(k+'.sexp')).read_text()
  match=alpha(parse(s))==alpha(parse(authored))
  if not match:raise RuntimeError(('AST mismatch',k))
  result['nodes'][k]=size(t)
  result['author_AST_alpha_equivalence'][k]=match
  result[k+'_author_sha256']=hashlib.sha256(authored.encode()).hexdigest()
 if result['nodes']!={'integrated159':159,'scheme_test':46,'scheme39_test':42}:raise RuntimeError(result)
 result['intermediate_per_theta_overhead']=result['nodes']['scheme_test']-3
 result['final_per_theta_overhead']=result['nodes']['scheme39_test']-3
 result['savings_vs_round6_conjoined_seed338']=338-159
 result['savings_vs_round6_scheme72']=72-39
 (HERE/'independent_integrated159_audit.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
