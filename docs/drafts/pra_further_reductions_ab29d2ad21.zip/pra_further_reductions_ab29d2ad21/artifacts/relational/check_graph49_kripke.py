#!/usr/bin/env python3
"""Fresh finite constant-domain Kripke diagnostics for graph49.
The finite source package is not PRA and does not validate the unbounded
zero-guard-elimination lemma. All checks are explicit under python -O.
"""
from functools import lru_cache
from itertools import product
import random,json,pathlib
from graph49 import *
from check_graph49 import canonical,decode,package,need,H48
def unique(v,v1,f):return EX(v,AND(f(v),FA(v1,imp(f(v1),eq(v1,v)))))
def ordinary_AST():
 P=lambda x:AND(neg(eq(x,'m')),neg(O(x)))
 return AND(FA('x',neg(E('m','x'))),FA('x',OR(eq('x','m'),O('x'),P('x'))),ALL(['x','y'],imp(AND(O('x'),O('y')),neg(E('x','y')))),FA('p',imp(P('p'),unique('a','a1',lambda a:AND(O(a),E(a,'p'))))),FA('p',imp(P('p'),unique('b','b1',lambda b:AND(O(b),E('p',b))))),ALL(['a','b'],imp(AND(O('a'),O('b')),unique('p','p1',lambda p:AND(P(p),E('a',p),E(p,'b'))))))
def evaluate(t,n,WE,future,m):
 @lru_cache(None)
 def run(t,w,env):
  d=dict(env);op=t[0]
  if op=='var':return d[t[1]]
  if op=='false':return False
  if op=='E':return (d[t[1][1]],d[t[2][1]]) in WE[w]
  if op=='=':return d[t[1][1]]==d[t[2][1]]
  if op=='and':return run(t[1],w,env) and run(t[2],w,env)
  if op=='or':return run(t[1],w,env) or run(t[2],w,env)
  if op=='imp':return all(not run(t[1],v,env) or run(t[2],v,env) for v in future[w])
  if op=='forall':return all(run(t[2],v,tuple(sorted({**d,t[1]:x}.items()))) for v in future[w] for x in range(n))
  if op=='exists':return any(run(t[2],w,tuple(sorted({**d,t[1]:x}.items()))) for x in range(n))
  raise ValueError(op)
 return run(t,0,(('m',m),))
frames=[('chain',{0:(0,1),1:(1,)},[(),(1,),(0,1)]),('fork',{0:(0,1,2),1:(1,),2:(2,)},[(),(1,),(2,),(1,2),(0,1,2)])]
rng=random.Random(20261102);canonical_cases=negative_cases=mutant_cases=accepted=0
for name,future,patterns in frames:
 for _ in range(100):
  output={xy:rng.randrange(2) for xy in product(range(2),repeat=2)};presence={xy:rng.choice(patterns) for xy in output};WE={};labels=None
  for w in future:
   R={(0,x,y,x^y) for x,y in output}|{(1,x,y,output[x,y]) for x,y in output if w in presence[x,y]}
   V,Ee,m=canonical(range(2),R)
   if labels is None:labels={v:i for i,v in enumerate(sorted(V,key=repr))}
   WE[w]={(labels[x],labels[y]) for x,y in Ee}
  n=len(labels);mi=labels[m];tag=labels[('o',0)]
  need(evaluate(H49()[2],n,WE,future,mi),'canonical49 Kripke fail');need(evaluate(ordinary_AST(),n,WE,future,mi),'canonical incidence fail');canonical_cases+=1
  extra={(labels[('o',0)],labels[('o',1)])};NEG={w:WE[w]|extra for w in future}
  need(evaluate(H48()[2],n,NEG,future,mi),'negative48 lost');need(not evaluate(H49()[2],n,NEG,future,mi),'negative49 accepted');negative_cases+=1
  # Add one persistent arbitrary edge. Check the source package at every
  # world, then independently test the intuitionistic structural implication.
  for _ in range(3):
   e=(rng.randrange(n),rng.randrange(n));pattern=rng.choice(patterns);MUT={w:WE[w]|({e} if w in pattern else set()) for w in future};mutant_cases+=1
   package_ok=True
   for w in future:
    Oset={x for x in range(n) if (x,mi) in MUT[w]};Rset=decode(set(range(n)),MUT[w],mi)
    package_ok=package_ok and package(Oset,Rset,tag)
   if package_ok and evaluate(H49()[2],n,MUT,future,mi):
    need(evaluate(ordinary_AST(),n,MUT,future,mi),'arithmetic-backed49 Kripke implication failed');accepted+=1
out={'status':'PASS','canonical_monotone_functional_relation_cases':canonical_cases,'shared48_negative_controls':negative_cases,'persistent_single_edge_mutations':mutant_cases,'mutations_satisfying_full_package_and_H49_at_root':accepted,'frames':['two-world chain','three-world fork'],'all_relation_valuations_persistent':True,'global_output_functionality_checked_at_every_world':True,'all_checks_active_under_python_O':True,'scope':'Finite constant-domain Kripke diagnostics; not a proof/completeness certificate or finite PRA models; unbounded G-implies-object lemma is proved in text, not certified here.'}
pathlib.Path(__file__).with_name('graph49_kripke_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
