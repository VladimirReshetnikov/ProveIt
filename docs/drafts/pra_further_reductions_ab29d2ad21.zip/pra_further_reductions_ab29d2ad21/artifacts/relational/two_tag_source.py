#!/usr/bin/env python3
"""Fresh exact ASTs for the two-tag source and H48/G6 presentation.
No downloaded code or candidate code is imported. Every variable occurrence,
atom, connective, falsity and quantifier counts one; bound names are labels.
"""
from functools import reduce
from pathlib import Path
import hashlib,json

HERE=Path(__file__).resolve().parent
def V(x):return ('var',x)
def R(t,x,y,w):return ('R',V(t),V(x),V(y),V(w))
def E(x,y):return ('E',V(x),V(y))
def eq(x,y):return ('=',V(x),V(y))
def imp(a,b):return ('imp',a,b)
def neg(a):return imp(a,('false',))
def AND(*xs):return reduce(lambda a,b:('and',a,b),xs)
def OR(*xs):return reduce(lambda a,b:('or',a,b),xs)
def Q(kind,x,t):return (kind,x,t)
def ALL(xs,t):return reduce(lambda t,x:Q('forall',x,t),reversed(xs),t)
def SOME(xs,t):return reduce(lambda t,x:Q('exists',x,t),reversed(xs),t)
def size(t):
 if t[0] in ('var','false'):return 1
 if t[0] in ('forall','exists'):return 1+size(t[2])
 return 1+sum(size(x) for x in t[1:])
def occurrences(t,k):
 if t[0] in ('var','false'):return int(t[0]==k)
 ch=[t[2]] if t[0] in ('forall','exists') else t[1:]
 return int(t[0]==k)+sum(occurrences(x,k) for x in ch)
def sexpr(t):
 if t[0]=='var':return t[1]
 if t[0]=='false':return 'false'
 if t[0] in ('forall','exists'):return f'({t[0]} {t[1]} {sexpr(t[2])})'
 return '('+' '.join([t[0],*(sexpr(x) for x in t[1:])])+')'
def G6():return ALL(['v'],R('a','z','v','z'))
def H42():
 membership=OR(eq('t','z'),eq('t','a'))
 return ALL(['x','y','t'],SOME(['u'],ALL(['w'],AND(
  R('a','z','x','z'),imp(membership,R('t','x','y','u')),
  imp(R('t','x','y','w'),AND(membership,eq('w','u')))))))
def H48():
 membership=OR(eq('t','z'),eq('t','a'))
 return ALL(['x','y','t'],SOME(['u'],ALL(['w'],AND(
  imp(AND(eq('t','a'),eq('x','z')),eq('u','z')),
  imp(membership,R('t','x','y','u')),
  imp(R('t','x','y','w'),AND(membership,eq('w','u')))))))
def C51():
 return ALL(['x','y'],SOME(['u','v'],ALL(['w','t'],AND(
  R('z','x','y','u'),R('a','x','y','v'),
  imp(R('z','x','y','w'),eq('w','u')),
  imp(R('a','x','y','w'),eq('w','v')),
  imp(R('t','x','y','w'),OR(eq('t','z'),eq('t','a')))))))
def H51_distinct():
 return AND(neg(eq('z','a')),ALL(['x','y'],SOME(['u','v'],ALL(['w','t'],AND(
  R('a','z','x','z'),R('z','x','y','u'),R('a','x','y','v'),
  imp(R('t','x','y','w'),OR(AND(eq('t','z'),eq('w','u')),AND(eq('t','a'),eq('w','v')))))))))
def graph_translate(t,serial=None):
 if serial is None:serial=[0]
 if t[0] in ('var','false'):return t
 if t[0] in ('forall','exists'):
  kind,x,b=t;b=graph_translate(b,serial)
  return Q(kind,x,imp(E(x,'marker'),b) if kind=='forall' else AND(E(x,'marker'),b))
 if t[0]=='R':
  tag,x,y,w=[s[1] for s in t[1:]];serial[0]+=1
  p,q=f'dec_p_{serial[0]}',f'dec_q_{serial[0]}'
  return SOME([p,q],AND(E(x,p),E(p,y),E(tag,q),E(q,w),E(p,q)))
 return (t[0],*(graph_translate(x,serial) for x in t[1:]))
def sink_guard(t):return ALL(['marker'],imp(ALL(['s'],neg(E('marker','s'))),t))
def source_seed():return SOME(['z','a'],H48())
def source_scheme(theta):return ALL(['z','a'],imp(G6(),theta))
def H49():
 O=lambda x:E(x,'marker')
 D=lambda x:SOME(['b','c'],AND(O('b'),O('c'),ALL(['y'],imp(AND(E('b','y'),E('y','c')),eq('y',x)))))
 return SOME(['marker'],ALL(['x'],AND(neg(E('marker','x')),OR(eq('x','marker'),
  AND(O('x'),ALL(['y'],imp(O('y'),neg(E('x','y'))))),D('x')))))
def main():
 forms={'guard_G6':G6(),'joint_finite_H42':H42(),'joint_finite_H48':H48(),'safe_old_C51':C51(),
        'safe_distinct_H51':H51_distinct(),'closed_source_seed':source_seed(),
        'graph_seed':sink_guard(graph_translate(source_seed())),
        'audited_graph49':H49()}
 data={}
 for name,t in forms.items():
  data[name]={'nodes':size(t),'R_occurrences':occurrences(t,'R'),
   'quantifiers':occurrences(t,'forall')+occurrences(t,'exists')}
  p=HERE/(name+'.sexp');p.write_text(sexpr(t)+'\n')
  data[name]['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 test=eq('x','x')
 data['totals']={'graph_translated_H42':size(graph_translate(H42())),
  'graph_translated_H48':size(graph_translate(H48())),
  'graph_translated_G6':size(graph_translate(G6())),
  'source_seed_raw':size(source_seed()),
  'sink_guarded_graph_seed':size(forms['graph_seed']),
  'fixed_seed_with_graph49':size(forms['audited_graph49'])+size(forms['graph_seed']),
  'conjoined_fixed_seed_with_graph49':1+size(forms['audited_graph49'])+size(forms['graph_seed']),
  'complete_scheme_overhead':size(sink_guard(graph_translate(source_scheme(test))))-size(test),
  'generic_complete_graph_arithmetic_axiom':'N + 16 r + 4 q + 45',
  'round6_C79_G12_fixed_seed':337,'round6_C79_G12_scheme_overhead':72,
  'saving_from_round6_fixed_seed':337-size(forms['audited_graph49'])-size(forms['graph_seed']),
  'saving_from_round6_each_scheme_axiom':27,
  'reverse_proof_uses_arithmetic_decidable_equality':True,
  'not_pure_intuitionistic_quantifier_factoring':True,
  'infinite_arithmetic_scheme_required':True}
 expected={'guard_G6':6,'joint_finite_H42':42,'joint_finite_H48':48,'safe_old_C51':51,
           'safe_distinct_H51':51,'closed_source_seed':50,'graph_seed':118,'audited_graph49':49}
 for k,n in expected.items():
  if size(forms[k])!=n:raise RuntimeError((k,size(forms[k]),n))
 data['status']='PASS'
 (HERE/'two_tag_source_metrics.json').write_text(json.dumps(data,indent=2)+'\n')
 print(json.dumps(data,indent=2))
if __name__=='__main__':main()
