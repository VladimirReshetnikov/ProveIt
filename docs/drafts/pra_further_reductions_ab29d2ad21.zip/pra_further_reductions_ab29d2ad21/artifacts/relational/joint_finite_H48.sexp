(forall x (forall y (forall t (exists u (forall w (and (and (imp (and (= t a) (= x z)) (= u z)) (imp (or (= t z) (= t a)) (R t x y u))) (imp (R t x y w) (and (or (= t z) (= t a)) (= w u)))))))))
