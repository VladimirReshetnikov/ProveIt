#!/usr/bin/env python3
"""Bounded canonical-graph checks for the untyped-zero selector lemma.
Truncated arithmetic relations are not models of PRA or the full source.
The full proof uses an unbounded arithmetic witness and is in the text.
"""
from itertools import product
import pathlib,json
from check_graph49 import canonical,need
rows=[]
for n in range(2,9):
 O=range(n)
 R={(0,x,y,x+y) for x,y in product(O,repeat=2) if x+y<n}|{(1,x,y,x*y) for x,y in product(O,repeat=2) if x*y<n}
 V,E,m=canonical(O,R);V=tuple(V);objects={('o',x) for x in O}
 nxt={x:{y for y in V if (x,y) in E} for x in V};prev={y:{x for x in V if (x,y) in E} for y in V}
 chains={(x,y):nxt[x]&prev[y] for x in V for y in V}
 def G(z,a):
  second=chains[a,z]
  if not second:return False
  return all(any(nxt[p]&second for p in chains[z,v]) for v in objects)
 accepted=[(z,a) for z,a in product(V,repeat=2) if G(z,a)]
 false_zeros=[(z,a) for z,a in accepted if z not in objects]
 if n>=3:need(not false_zeros,'nonobject zero passed at >=3 objects')
 need(G(('o',0),('o',1)),'canonical selector missing')
 need(G(('o',0),('p',0,0)),'untyped tag counterexample missing')
 typed=[(z,a) for z,a in accepted if z in objects and a in objects]
 need(typed==[(('o',0),('o',1))],'typed canonical selector not unique')
 rows.append({'object_bound':n,'vertices':len(V),'all_parameter_pairs_tested':len(V)**2,'accepted_guards':len(accepted),'nonobject_zero_counterexamples':len(false_zeros),'nonobject_tag_mimic_P00_verified':True})
out={'status':'PASS','bounds':rows,'all_checks_active_under_python_O':True,'scope':'Truncated canonical arithmetic graphs only; not finite models of PRA/full source, not a proof of the unbounded implication. Text proves that implication constructively.'}
pathlib.Path(__file__).with_name('untyped_guard_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
