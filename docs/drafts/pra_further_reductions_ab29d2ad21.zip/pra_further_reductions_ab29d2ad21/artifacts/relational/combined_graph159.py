#!/usr/bin/env python3
"""Independent exact binary AST for the integrated159 seed and43 overhead.
Only locally authored builders are used. Checks remain active under -O.
"""
from graph49 import *
def R(t,x,y,w):return ('R',V(t),V(x),V(y),V(w))
def H48():
 tags=OR(eq('t','z'),eq('t','a'))
 return ALL(['x','y','t'],EX('u',FA('w',AND(
  imp(AND(eq('t','a'),eq('x','z')),eq('u','z')),
  imp(tags,R('t','x','y','u')),
  imp(R('t','x','y','w'),AND(tags,eq('w','u')))))))
def G6():return FA('v',R('a','z','v','z'))
def translate(t,serial=None):
 if serial is None:serial=[0]
 if t[0] in ('var','false'):return t
 if t[0] in ('forall','exists'):
  op,x,b=t;b=translate(b,serial)
  return (op,x,imp(O(x),b) if op=='forall' else AND(O(x),b))
 if t[0]=='R':
  tag,x,y,w=(v[1] for v in t[1:]);serial[0]+=1;p,q=f'dp{serial[0]}',f'dq{serial[0]}'
  return SOME([p,q],AND(E(x,p),E(p,y),E(tag,q),E(q,w),E(p,q)))
 return (t[0],*(translate(x,serial) for x in t[1:]))
def structure_body(x):
 B=AND(O(x),FA('r',imp(O('r'),neg(E(x,'r')))))
 D=SOME(['b','c'],AND(O('b'),O('c'),FA('r',imp(AND(E('b','r'),E('r','c')),eq('r',x)))))
 return AND(neg(E('m',x)),OR(eq(x,'m'),B,D))
def integrated160():return EX('m',AND(FA('x',structure_body('x')),translate(SOME(['z','a'],H48()))))
def integrated159():
 H=translate(H48())
 if H[:2]!=('forall','x'):raise RuntimeError('unexpected source prefix')
 return SOME(['m','z','a'],AND(O('z'),O('a'),FA('x',AND(structure_body('x'),H[2]))))
def outgoing_guard(theta):return FA('m',OR(EX('r',E('m','r')),theta))
def old_guard(theta):return FA('m',imp(FA('r',neg(E('m','r'))),theta))
def source_scheme(theta):return ALL(['z','a'],imp(G6(),theta))
def checks():
 forms={'joint_source_H48':H48(),'source_G6':G6(),'integrated160':integrated160(),'integrated159':integrated159(),'scheme_test':outgoing_guard(translate(source_scheme(eq('q','q')))),'scheme39_test':scheme39(eq('q','q'))}
 want={'joint_source_H48':48,'source_G6':6,'integrated160':160,'integrated159':159,'scheme_test':46,'scheme39_test':42}
 for name,t in forms.items():
  if count(t)!=want[name]:raise RuntimeError((name,count(t),want[name]))
 data={'status':'PASS','nodes':{name:count(t) for name,t in forms.items()},'source_H48_graph_translation':count(translate(H48())),'source_G6_graph_translation':count(translate(G6())),'new_outer_guard_overhead':count(outgoing_guard(eq('q','q')))-3,'old_outer_guard_overhead':count(old_guard(eq('q','q')))-3,'intermediate_typed_scheme_overhead':count(forms['scheme_test'])-3,'complete_arithmetic_scheme_overhead':count(forms['scheme39_test'])-3,'generic_arithmetic_scheme':'N + 16r + 4q + 39','fixed_seed_is_one_closed_sentence':True,'old_round6_fixed_seed_two_sentence_sum':337,'old_round6_fixed_seed_conjoined':338,'old_round6_per_arithmetic_axiom_overhead':72,'all_checks_active_under_python_O':True}
 here=pathlib.Path(__file__).parent
 for name,t in forms.items():(here/(name+'.sexp')).write_text(sexpr(t)+'\n')
 (here/'combined_graph159_metrics.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data,indent=2))

def scheme_no_zero_guard(theta):
 # The arithmetic zero parameter is quantified over all graph vertices;
 # only the multiplication-tag parameter retains its O guard.
 return FA('z',FA('a',imp(O('a'),imp(translate(G6()),translate(theta)))))
def scheme39(theta):return outgoing_guard(scheme_no_zero_guard(theta))

if __name__=='__main__':checks()
