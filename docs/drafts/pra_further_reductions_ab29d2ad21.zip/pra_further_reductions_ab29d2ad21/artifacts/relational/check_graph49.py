#!/usr/bin/env python3
"""Finite graph49 diagnostics, not finite models or formal proofs of PRA."""
import itertools,json,pathlib
from graph49 import *
def need(p,msg='check failed'):
 if not p:raise RuntimeError(msg)
def ev(t,V,Ee,env):
 op=t[0]
 if op=='var':return env[t[1]]
 if op=='false':return False
 if op=='E':return (ev(t[1],V,Ee,env),ev(t[2],V,Ee,env)) in Ee
 if op=='=':return ev(t[1],V,Ee,env)==ev(t[2],V,Ee,env)
 if op=='and':return ev(t[1],V,Ee,env) and ev(t[2],V,Ee,env)
 if op=='or':return ev(t[1],V,Ee,env) or ev(t[2],V,Ee,env)
 if op=='imp':return not ev(t[1],V,Ee,env) or ev(t[2],V,Ee,env)
 if op in ('forall','exists'):return (all if op=='forall' else any)(ev(t[2],V,Ee,{**env,t[1]:x}) for x in V)
 raise ValueError(op)
def ordinary(V,Ee,m):
 O={x for x in V if (x,m) in Ee};P=V-O-{m}
 return not any((m,x) in Ee for x in V) and not any((a,b) in Ee for a in O for b in O) and all(sum((a,p) in Ee for a in O)==1 and sum((p,b) in Ee for b in O)==1 for p in P) and all(sum((a,p) in Ee and (p,b) in Ee for p in P)==1 for a in O for b in O)
def direct(V,Ee,m):
 O={x for x in V if (x,m) in Ee}
 return not any((m,x) in Ee for x in V) and all(x==m or (x in O and not any((x,y) in Ee for y in O)) or any(all((a,y) not in Ee or (y,b) not in Ee or y==x for y in V) for a in O for b in O) for x in V)
def decode(V,Ee,m):
 O={x for x in V if (x,m) in Ee};pairs={(a,b):{p for p in V if (a,p) in Ee and (p,b) in Ee} for a in O for b in O}
 return {(t,a,b,c) for t,a,b,c in itertools.product(O,repeat=4) if any((p,q) in Ee for p in pairs[a,b] for q in pairs[t,c])}
def package(O,R,tag):
 if len(O)<2 or tag not in O:return False
 if any(len({w for tt,xx,yy,w in R if (tt,xx,yy)==(t,x,y)})>1 for t,x,y in itertools.product(O,repeat=3)):return False
 A={(x,y,w) for t,x,y,w in R if t==tag}
 return all(any((x,y,w) in A for w in O) for x,y in itertools.product(O,repeat=2)) and all(len({x for x in O if (x,y,w) in A})<=1 for y,w in itertools.product(O,repeat=2)) and all(len({y for y in O if (x,y,w) in A})<=1 for x,w in itertools.product(O,repeat=2))
def canonical(O,R):
 m=('m',);oo={x:('o',x) for x in O};pp={(x,y):('p',x,y) for x in O for y in O};V={m}|set(oo.values())|set(pp.values());Ee={(oo[x],m) for x in O}|{(oo[x],pp[x,y]) for x in O for y in O}|{(pp[x,y],oo[y]) for x in O for y in O}|{(pp[x,y],pp[t,w]) for t,x,y,w in R};return V,Ee,m

def H48():return EX('m',FA('x',SOME(['a','b'],FA('y',AND(neg(E('m','x')),OR(eq('x','m'),AND(O('x'),imp(O('y'),neg(E('x','y')))),AND(O('a'),O('b'),U('x','a','b','y'))))))))
need(count(H48())==48)
def main():
 counts={'all_graph_marker_pairs_through_four_vertices':0,'exact_AST_cases':0,'finite_full_package_cases_small_graphs':0,'two_object_function_tables_both_roundtrips':0,'single_edge_mutations':0,'mutation_packages_accepted':0}
 for n in range(1,5):
  V=set(range(n));edges=list(itertools.product(V,repeat=2))
  for bits in range(1<<len(edges)):
   Ee={e for i,e in enumerate(edges) if bits>>i&1}
   for m in V:
    got=direct(V,Ee,m);counts['all_graph_marker_pairs_through_four_vertices']+=1
    if got or bits%503==0:
     need(ev(H49()[2],V,Ee,{'m':m})==got,'AST mismatch');counts['exact_AST_cases']+=1
    if got:
     OO={x for x in V if (x,m) in Ee};R=decode(V,Ee,m)
     for tag in OO:
      if package(OO,R,tag):
       need(ordinary(V,Ee,m),'finite structural implication fails');counts['finite_full_package_cases_small_graphs']+=1
 inputs=list(itertools.product(range(2),repeat=2))
 for outputs in itertools.product(range(2),repeat=4):
  R={(0,x,y,x^y) for x,y in inputs}|{(1,x,y,w) for (x,y),w in zip(inputs,outputs)}
  V,Ee,m=canonical(range(2),R);need(direct(V,Ee,m));need(ordinary(V,Ee,m));RR=decode(V,Ee,m);OO={('o',0),('o',1)};need(package(OO,RR,('o',0)));need({tuple(x[1] for x in r) for r in RR}==R)
  coords={p:(next(x for x in OO if (x,p) in Ee),next(y for y in OO if (p,y) in Ee)) for p in V-OO-{m}}
  VV,EE,mm=canonical(OO,RR);f={m:mm,**{x:('o',x) for x in OO},**{p:('p',*xy) for p,xy in coords.items()}};need(set(f.values())==VV and {(f[x],f[y]) for x,y in Ee}==EE);counts['two_object_function_tables_both_roundtrips']+=1
  for edge in itertools.product(V,repeat=2):
   Es=Ee^{edge};counts['single_edge_mutations']+=1
   if direct(V,Es,m):
    Os={x for x in V if (x,m) in Es};Rs=decode(V,Es,m)
    if package(Os,Rs,('o',0)):
     need(ordinary(V,Es,m),'mutation implication fails');counts['mutation_packages_accepted']+=1
  # The tempting48 holds after a single isolated object edge; decoder unchanged.
  extra=Ee|{(('o',0),('o',1))}
  need(decode(V,extra,m)==RR,'isolated object edge changed decoder')
  need(ev(H48()[2],V,extra,{'m':m}),'48 counterexample missing')
  need(not direct(V,extra,m) and not ordinary(V,extra,m),'49 failed to reject extra edge')
 # Structure alone still accepts phantom pair/sink when source is absent.
 need(direct({0,1,2},{(1,0)},0) and not ordinary({0,1,2},{(1,0)},0))
 result={'status':'PASS',**counts,'tempting_48_refuted_on_all_16_function_tables':True,'phantom_pair_negative_control':True,'all_checks_active_under_python_O':True,'scope':'Finite diagnostics of the sufficient arithmetic package, not finite PRA models or a formal proof.'}
 here=pathlib.Path(__file__).parent;(here/'graph49_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
