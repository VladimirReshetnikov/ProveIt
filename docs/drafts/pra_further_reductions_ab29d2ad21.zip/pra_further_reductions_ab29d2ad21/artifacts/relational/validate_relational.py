#!/usr/bin/env python3
"""Re-run local authored round7 relational artifacts normally and with -O.
No downloads, prior packages, or external dependencies. All checks active.
"""
import ast,concurrent.futures,hashlib,json,pathlib,shutil,subprocess,sys,tempfile,time
HERE=pathlib.Path(__file__).resolve().parent
SCRIPTS=['graph49.py','two_tag_source.py','combined_graph159.py','check_graph49.py','check_graph49_kripke.py','check_two_tag_source.py','check_untyped_guard.py','audit_integrated159.py']
OUTPUTS=['graph49_metrics.json','two_tag_source_metrics.json','combined_graph159_metrics.json','graph49_checks.json','graph49_kripke_checks.json','two_tag_source_checks.json','untyped_guard_checks.json','independent_integrated159_audit.json']
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs={f.name:sha(f) for f in HERE.glob('*.py')}
for f in HERE.glob('*.py'):
 need(not any(isinstance(n,ast.Assert) for n in ast.walk(ast.parse(f.read_text()))),'disabled assertion risk: '+f.name)
def mode(opt):
 with tempfile.TemporaryDirectory(prefix='round7_relational_') as td:
  dst=pathlib.Path(td)/'artifacts';shutil.copytree(HERE,dst,ignore=shutil.ignore_patterns('__pycache__'))
  runs=[]
  for script in SCRIPTS:
   cmd=[sys.executable,*(['-O'] if opt else []),str(dst/script)]
   cp=subprocess.run(cmd,cwd=dst,capture_output=True,text=True,timeout=180)
   need(cp.returncode==0,script+' failed: '+cp.stderr+'\n'+cp.stdout)
   need(not cp.stderr,script+' produced stderr: '+cp.stderr)
   runs.append({'script':script,'returncode':cp.returncode,'stdout_sha256':hashlib.sha256(cp.stdout.encode()).hexdigest()})
  data={f:json.loads((dst/f).read_text()) for f in OUTPUTS}
  need(data['combined_graph159_metrics.json']['nodes']['integrated159']==159,'seed count')
  need(data['combined_graph159_metrics.json']['complete_arithmetic_scheme_overhead']==39,'scheme count')
  need(data['independent_integrated159_audit.json']['final_per_theta_overhead']==39,'independent count')
  return {'optimized':opt,'runs':runs,'results':data,'sexp_sha256':{f.name:sha(f) for f in dst.glob('*.sexp')}}
start=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:results=list(ex.map(mode,[False,True]))
need(results[0]['results']==results[1]['results'],'normal and -O JSON differ')
need(results[0]['sexp_sha256']==results[1]['sexp_sha256'],'normal and -O AST hashes differ')
need(results[0]['runs']==results[1]['runs'],'normal and -O stdout differs')
for name,h in inputs.items():need(sha(HERE/name)==h,'input changed: '+name)
out={'status':'PASS','python':sys.version.split()[0],'source_file_sha256':inputs,'all_python_files_zero_asserts':True,'all_checks_active_under_python_O':True,'all_normal_optimized_results_identical':True,'all_normal_optimized_AST_hashes_identical':True,'successful_processes':16,'elapsed_seconds':round(time.monotonic()-start,3),'runs':results,'scope':'Finite tests supplement written intuitionistic proofs; not finite models of PRA, proof-assistant certificates, or completeness proofs. The unbounded zero-guard lemma is proved in text.','no_downloaded_code_executed':True}
(HERE/'final_relational_validation.json').write_text(json.dumps(out,indent=2)+'\n')
g=results[0]['results']['graph49_checks.json'];k=results[0]['results']['graph49_kripke_checks.json'];s=results[0]['results']['two_tag_source_checks.json']
lines=['ROUND7 RELATIONAL VALIDATION: PASS','Final frontier: one 159-node fixed sentence; N + 16r + 4q + 39 per arithmetic axiom.','Decoder21; graph49; sourceH48; short sourceG6.','Independent AST rebuild alpha-matches author fixed159 and scheme39.',f'16 successful processes: eight scripts normal and python -O; byte-identical stdout/results/ASTs.',f'Every delivered Python file has zero ast.Assert statements; checks stay active under -O.',f'Graph cases through four vertices: {g["all_graph_marker_pairs_through_four_vertices"]}; exact AST cases: {g["exact_AST_cases"]}.',f'Canonical two-object function-table roundtrips: {g["two_object_function_tables_both_roundtrips"]}; edge mutations: {g["single_edge_mutations"]}.',f'Kripke canonical cases: {k["canonical_monotone_functional_relation_cases"]}; shared48 negative controls: {k["shared48_negative_controls"]}; persistent mutations: {k["persistent_single_edge_mutations"]}.','Source package checks and bounded untyped-guard checks: PASS; see adjacent JSON.','Negative controls: phantom pair/sink; invalid48 binder sharing; nonobject tag mimic; finite two-object zero-guard counterexamples.','Limits: finite diagnostics are not models of full PRA or formal proof certificates; the unbounded G-implies-object lemma is proved constructively in text.','No downloaded code executed. No network or prior package dependency.',f'Elapsed: {out["elapsed_seconds"]} seconds.']
(HERE/'final_relational_validation.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
