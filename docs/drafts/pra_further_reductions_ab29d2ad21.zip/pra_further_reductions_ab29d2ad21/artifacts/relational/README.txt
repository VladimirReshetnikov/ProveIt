ROUND 7 RELATIONAL FRONTIER — FINAL 159 / 39

Main complete proof chain:
  two_tag_source_proof.tex — explicit H48/G6 two-tag source and both identity composites
  graph49_proof.tex — arithmetic-backed graph49 and both whole-domain graph composites
  combined_graph159_proof.tex — integrated159 seed, positive guard, final39 scheme,
                               full untyped-zero lemma and retained-tag guard counterexample

Final exact generator: combined_graph159.py.
Independent reconstruction: audit_integrated159.py.
Final exact ASTs: integrated159.sexp and scheme39_test.sexp (test theta is q=q, size3).
All other 42/45/43/167 etc. counts are clearly identified historical/intermediate
forms, not the final frontier. Source rawH48→graph100; graph decoder21 unchanged.

Run all validation, normal and python -O, in isolated local copies:
  python validate_relational.py
No downloaded code, network, prior package, or third-party dependency is used.
All runtime checks are explicit, with zero Python assert statements.

Finite diagnostics supplement—not replace—the written intuitionistic proofs.
Finite function tables, Kripke graphs, and truncated arithmetic graphs are NOT
claimed as finite models of PRA. The untyped-zero lemma needs unbounded source
arithmetic; the bounded tests deliberately preserve a two-object counterexample.

The displayed infinite arithmetic scheme and the inherited PRA-to-T0 fixed-program
trace theorem remain explicit dependencies. No global optimality or proof-assistant
certificate is claimed.
