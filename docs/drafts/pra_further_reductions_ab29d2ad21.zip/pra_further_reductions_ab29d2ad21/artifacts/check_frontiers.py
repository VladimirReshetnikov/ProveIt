#!/usr/bin/env python3
"""Independent locally authored AST count audit. No source scripts imported."""
import hashlib,json,pathlib

def N(op,*xs): return (op,xs)
def v(name): return N(name)
def count(t): return 1+sum(count(x) for x in t[1])
def sub(t,env):
 if not t[1] and t[0] in env:return env[t[0]]
 return N(t[0],*(sub(x,env) for x in t[1]))
def occurrences(t,name):return int(not t[1] and t[0]==name)+sum(occurrences(x,name) for x in t[1])
def require(ok,message):
 if not ok:raise RuntimeError(message)
z=v('0');n=v('n');a=v('a');x=v('x');mark=v('z');seed=v('w');bot=N('bottom')
S=lambda t:N('S',t)
R=lambda n,a:N('R',n,a)
E=lambda s,t:N('=',s,t)
I=lambda p,q:N('->',p,q)
And=lambda p,q:N('and',p,q)
Or=lambda p,q:N('or',p,q)
Q=lambda var,p:N('forall:'+var,p)
bad=E(z,S(z));sep=I(bad,bot);b0=E(R(z,a),a);bs=E(R(S(n),a),N('h',n,R(n,a)))
def emission(F):
 return Q('a',I(Q('n',I(F,sub(F,{'n':S(n)}))),Q('n',And(F,bs))))
A=lambda t:N('A',t,a,a)
F=lambda t:N('F',t,a)
outer_diag=emission(A(n));outer_two=emission(F(n))
D=Q('a',I(And(Or(N('A',z,R(z,a),a),bad),Q('n',I(A(n),A(S(n))))),Q('n',And(A(n),bs))))
Ejoint=Q('a',I(And(Or(F(z),bad),Q('n',I(F(n),F(S(n))))),Q('n',And(F(n),And(b0,bs)))))
JNI=Q('a',I(Q('n',I(F(n),F(S(n)))),Q('n',And(F(n),And(b0,bs)))))
FI=Q('a',I(And(Or(F(z),bad),Q('n',I(F(n),F(S(n))))),Q('n',F(n))))
B0=Q('a',b0);BS=Q('a',Q('n',bs))
profiles={'binary_fused_42':count(B0)+count(BS)+count(FI),'explicit_joint_41':count(Ejoint),'JNI1_38':count(JNI)+count(sep),'diagonal_direct_41':count(D),'diagonal_reflexive_35':count(outer_diag)+count(sep),'guarded_diagonal_29':count(outer_diag),'one_mark_compact_26':count(outer_two),'normalized_26':count(outer_two),'rewrite_plus_Sep_32':count(outer_two)+count(sep)}
b=v('b'); F3=lambda t:N('F',t,a,b)
endpoint=Q('a',Q('b',I(Q('n',I(F3(n),F3(S(n)))),N('F',a,a,b))))
universal=Q('a',Q('b',I(Q('n',I(F3(n),F3(S(n)))),Q('n',F3(n)))))
profiles.update({'endpoint_18':count(endpoint),'universal_19':count(universal)})
for key,value in profiles.items():require(value==int(key.rsplit('_',1)[1]),key)
# Expose every ternary term placeholder in the restricted source grammar.
t=lambda name:N(name,n,a,a)
P=E(t('s'),t('t'));Qe=E(t('u'),t('v'))
atomic=I(P,Qe)
clausal=I(Or(P,Qe),Or(E(t('r'),t('s2')),E(t('t2'),t('u2'))))
exposed={'atomic':count(emission(atomic))+count(sep),'two_equation_clauses':count(emission(clausal))+count(sep)}
require(exposed=={'atomic':83,'two_equation_clauses':147},'Exposed term interface')
# Explicit one-mark templates: z marks at most one original seed occurrence.
templates=[E(x,x),E(x,mark),I(E(x,seed),E(mark,seed)),Or(E(S(x),mark),E(seed,seed)),And(E(x,seed),E(seed,S(seed)))]
matched=[]
for template in templates:
 k=occurrences(template,'z');require(k<=1,'Invalid diagnostic template')
 C=sub(template,{'x':n,'z':a,'w':a});D0=sub(template,{'x':z,'z':R(z,a),'w':a})
 C0=sub(C,{'n':z});Cs=sub(C,{'n':S(n)})
 direct=Q('a',I(And(Or(D0,bad),Q('n',I(C,Cs))),Q('n',And(C,bs))))
 explicit=Q('a',I(And(Or(C0,bad),Q('n',I(C,Cs))),Q('n',And(C,And(b0,bs)))))
 compact=emission(I(Or(D0,bad),C))
 require(count(D0)==count(C0)+2*k,'One-mark substitution size')
 require(count(direct)-count(explicit)==2*k-6,'Matched direct saving')
 require(count(compact)-count(direct)==2*count(D0)+12,'Compact expanded penalty')
 normalized=emission(I(C0,C));m=count(C);nu=occurrences(C,'n')
 require(count(normalized)==6*m+nu+19,'Normalized induction profile')
 matched.append({'matrix_size':m,'counter_occurrences':nu,'marks':k,'modified_base_size':count(D0),'explicit_joint':count(explicit),'one_mark_direct':count(direct),'one_mark_compact_expanded':count(compact),'normalized_induction_instance':count(normalized)})
out={'status':'PASS','scope':'Exact independent AST counts only; admission programs and arbitrary update bodies are excluded. No imported/downloaded code executed.','profiles':profiles,'exposed_term_interface':exposed,'matched_examples':matched,'normalization_induction_profile':'6m + occurrences_n(C) + 19 (opaque binary update interface)','scope_limits':['No complete generator byte cost or shortestness theorem.','No mathematical equivalence certified by these numerical counts.']}
text=json.dumps(out,indent=2)+'\n';pathlib.Path(__file__).with_suffix('.json').write_text(text);print(text,end='')
