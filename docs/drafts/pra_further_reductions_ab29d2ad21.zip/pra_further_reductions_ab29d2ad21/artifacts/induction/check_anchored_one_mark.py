#!/usr/bin/env python3
"""Authored diagnostics for the final restricted one-mark family.
No inherited source scripts imported. Runtime checks use explicit exceptions,
so python -O changes nothing. Finite tests are diagnostics, not the proof.
"""
from itertools import product
import json


def need(test, message):
    if not test:
        raise RuntimeError(message)


def N(op, *args):
    return (op, tuple(args))


def size(t):
    return 1 + sum(map(size, t[1]))


def occurrences(t, symbol):
    return int(t == N(symbol)) + sum(occurrences(x, symbol) for x in t[1])


def sub(t, env):
    if not t[1] and t[0] in env:
        return env[t[0]]
    return N(t[0], *(sub(x, env) for x in t[1]))


zero, n, a = N('0'), N('n'), N('a')
bot = N('bottom')
S = lambda t: N('S', t)
R = lambda h, x, y: N('R:' + h, x, y)
Eq = lambda x, y: N('=', x, y)
Or = lambda x, y: N('or', x, y)
And = lambda x, y: N('and', x, y)
Imp = lambda x, y: N('implies', x, y)
All = lambda v, f: N('forall:' + v, f)
bad = Eq(zero, S(zero))


def term(t):
    op, args = t
    if op in ('0', 'n', 'a'):
        return len(args) == 0
    if op == 'S':
        return len(args) == 1 and term(args[0])
    if op.startswith('R:'):
        # Descriptor identity is part of the function SYMBOL, not a subtree.
        return len(args) == 2 and all(map(term, args))
    return False


def coverage(h):
    return Or(Eq(n, zero), Eq(n, S(R(h, n, zero))))


def classify(C, h):
    if C == bot:
        return 'falsity'
    if C == Eq(R(h, zero, a), a):
        return 'fixed_initializer'
    if C == coverage(h):
        return 'fixed_coverage'
    if C[0] == '=' and len(C[1]) == 2:
        left, right = C[1]
        if left == R(h, n, a) and term(right):
            return 'one_arbitrary_term'
    return None


def a_paths(t, prefix=()):
    if t == a:
        return [prefix]
    return [p for i, child in enumerate(t[1])
            for p in a_paths(child, prefix + (i,))]


def one_mark_base(C, h, path):
    need(path is None or path in a_paths(C), 'mark is not one original a leaf')
    def walk(t, here):
        if path is not None and here == path:
            need(t == a, 'invalid marked leaf')
            return R(h, zero, a)  # Do NOT recurse into newly inserted a.
        if t == n:
            return zero
        return N(t[0], *(walk(x, here + (i,)) for i, x in enumerate(t[1])))
    return walk(C, ())


def make_A(C, h, path=None):
    need(classify(C, h) is not None, 'matrix outside final four-branch grammar')
    return Imp(Or(one_mark_base(C, h, path), bad), C)


def accepted_A(A, h):
    if A[0] != 'implies' or len(A[1]) != 2:
        return False
    ante, C = A[1]
    if classify(C, h) is None or ante[0] != 'or' or len(ante[1]) != 2:
        return False
    D, E = ante[1]
    return E == bad and any(D == one_mark_base(C, h, p)
                            for p in [None] + a_paths(C))


def emit(A, h):
    step = Eq(R(h, S(n), a), N('h', n, R(h, n, a)))
    return All('a', Imp(All('n', Imp(A, sub(A, {'n': S(n)}))),
                        All('n', And(A, step))))


outer = emit(N('A', n, a), 'h')
need(size(outer) == 26, 'outer count is not 26')
base_terms = (zero, n, a)
terms1 = set(base_terms)
terms1.update(S(t) for t in base_terms)
terms1.update(R(h, x, y) for h in ('h', 'g') for x, y in product(base_terms, repeat=2))
terms2 = set(base_terms)
terms2.update(S(t) for t in terms1)
terms2.update(R(h, x, y) for h in ('h', 'g') for x, y in product(terms1, repeat=2))
matrices = [Eq(R('h', n, a), t) for t in sorted(terms2)]
matrices += [Eq(R('h', zero, a), a), bot, coverage('h')]
syntax_count = 0
for C in matrices:
    for path in [None] + a_paths(C):
        A = make_A(C, 'h', path)
        need(accepted_A(A, 'h'), 'generated instance rejected')
        D = A[1][0][1][0]
        mark_count = int(path is not None)
        need(size(D) == size(C) + 2 * mark_count, 'one-mark size mismatch')
        expected = 6 * size(C) + 6 * mark_count + occurrences(C, 'n') + 34
        need(size(emit(A, 'h')) == expected, 'expanded count mismatch')
        # Invalid Bad replacement must fail even if propositionally equivalent.
        altered = Imp(Or(D, Eq(S(zero), zero)), C)
        need(not accepted_A(altered, 'h'), 'nonliteral Bad accepted')
        syntax_count += 1

# Strict rejections: reversed equations, wrong index, wrong fixed seed,
# zero-counter arbitrary RHS, and arbitrary Boolean formulas.
invalid = [Eq(a, R('h', n, a)), Eq(R('g', n, a), n),
           Eq(R('h', n, n), a), Eq(R('h', zero, a), n),
           Eq(R('h', zero, a), S(a)), Eq(n, a),
           And(Eq(n, a), Eq(a, n)), Imp(Eq(n, a), Eq(a, n)),
           Or(Eq(n, zero), Eq(n, S(R('g', n, zero)))),
           Eq(R('h', n, a), N('b'))]
for C in invalid:
    need(classify(C, 'h') is None, 'nonpermitted matrix accepted')

# Initializer orientation and exactly one ORIGINAL leaf.
init = Eq(R('h', zero, a), a)
init_A = make_A(init, 'h', (1,))
need(init_A[1][0][1][0] == Eq(R('h', zero, a), R('h', zero, a)),
     'initializer marking orientation incorrect')
need(occurrences(init_A[1][0][1][0], 'a') == 2,
     'inserted seed was re-marked')
# Changing both original seed leaves is not an allowed mark.
two_mark_D = Eq(R('h', zero, R('h', zero, a)), R('h', zero, a))
need(not accepted_A(Imp(Or(two_mark_D, bad), init), 'h'), 'two marks accepted')

# Standard-model bounded evaluations of every nontrivial arithmetic identity
# used in the written bootstrap. These do not certify internal induction.
p = lambda x: max(x - 1, 0)
d = lambda x, y: max(x - y, 0)
select = lambda z, u, v: u if z == 0 else v
U = lambda r: select(r, 1, select(p(r), 0, 1))
e = lambda x, y: U(d(x + 1, y))
limit = 48
arithmetic_cases = 0
for x, y in product(range(limit + 1), repeat=2):
    need((x + 1) + y == (x + y) + 1, 'left successor addition')
    need(d(x + 1, y + 1) == d(x, y), 'joint predecessor cancellation')
    need(d(p(x), y) == p(d(x, y)), 'predecessor/difference commutation')
    need(d(x + y, x) == y, 'constant-target difference cancellation')
    need(select(d(x, y), x, y + d(x, y)) == x, 'residual invariant')
    need((d(x + 1, y) == 1) == (x == y), 'shifted native equality test')
    need(e(x, y) in (0, 1) and (e(x, y) == 0) == (x == y), 'error bit')
    arithmetic_cases += 1
for seed, bit in product(range(limit + 1), (0, 1)):
    need((seed + bit == seed) == (bit == 0), 'CI target encoding')

# All Boolean truth tables, including constructive implication on decidable bits.
for b, c in product((0, 1), repeat=2):
    need((select(b, c, 1) == 0) == (b == 0 and c == 0), 'and bit')
    need((select(b, 0, c) == 0) == (b == 0 or c == 0), 'or bit')
    need((select(b, c, 0) == 0) == (b != 0 or c == 0), 'implication bit')

# Triangular pairing orientation J(x,y)=T(x+y)+x and bounded decoder
# recurrence from the proof, not a square-root substitute.
T = lambda z: z * (z + 1) // 2
pair_limit = 32
max_code = T(2 * pair_limit) + pair_limit
V = [0]
for k in range(max_code):
    old = V[-1]
    V.append(select(e(T(old + 1), k + 1), old + 1, old))
pair_cases = 0
for x, y in product(range(pair_limit + 1), repeat=2):
    code = T(x + y) + x
    row = V[code]
    left = d(code, T(row))
    right = d(row, left)
    need((row, left, right) == (x + y, x, y), 'pairing orientation/decoding')
    pair_cases += 1

# Coordinatewise equations do not force native disjunctive coverage.
# This tiny example diagnoses coverage failure, NOT infinite-product EqI.
vector = (0, 1)
need(vector != (0, 0) and vector != tuple(p(v) + 1 for v in vector),
     'mixed-coordinate coverage diagnostic')

report = {
    'status': 'PASS',
    'specification': 'C ::= R_h(n,a)=t(n,a) | R_h(0,a)=a | bottom | n=0 or n=S(R_h(n,0))',
    'arbitrary_term_slots': 1,
    'outer_AST_nodes': size(outer),
    'expanded_profile': '6*size(C) + 6*marks + occurrences_n(C) + 34',
    'depth_two_terms': len(terms2),
    'valid_marked_instances_checked': syntax_count,
    'rejected_matrix_examples': len(invalid),
    'arithmetic_pairs_checked': arithmetic_cases,
    'pairing_pairs_checked': pair_cases,
    'pairing_maximum_evaluated_code': max_code,
    'scope': [
        'Exact literal grammar, marking and AST checks are structural diagnostics.',
        'Bounded standard arithmetic and product examples are finite diagnostics, not proofs.',
        'Internal derivations, whole-carrier equivalence and non-bi-interpretability are proved in anchored_one_mark.tex.',
        'Outer count excludes substituted matrix bodies and admission-enumerator implementation; no shortestness claim.',
        'Expanded profile expands C but retains the displayed binary update placeholder h; it is not an arbitrary-update-body byte count.',
        'No downloaded or inherited checker code is imported or executed.'
    ]
}
print(json.dumps(report, indent=2, sort_keys=True))
