"""Reproduce complete-program measurements from the frozen current sources."""
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {
    tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
    tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER,
}
FIELDS = (
    "ast_nodes", "source_tokens", "normalized_tokens",
    "normalized_bytes", "raw_bytes",
)
CORE_FIELDS = ("ast_nodes", "normalized_tokens", "normalized_bytes")

def significant_tokens(source, excluded_spans=()):
    return sum(
        token.type not in IGNORED and not any(
            start <= token.start and token.end <= end
            for start, end in excluded_spans
        )
        for token in tokenize.generate_tokens(io.StringIO(source).readline)
    )

def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in list(ast.walk(tree)):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str):
                spans.append(((first.lineno, first.col_offset), (first.end_lineno, first.end_col_offset)))
                node.body.pop(0)
    normalized = ast.unparse(tree) + "\n"
    whole = {
        "ast_nodes": sum(1 for _ in ast.walk(tree)),
        "source_tokens": significant_tokens(source, spans),
        "normalized_tokens": significant_tokens(normalized),
        "normalized_bytes": len(normalized.encode("utf-8")),
        "raw_bytes": len(raw),
    }
    core = copy.deepcopy(tree)
    core.body = [
        node for node in core.body
        if not isinstance(node, (ast.Import, ast.ImportFrom, ast.If))
    ]
    normalized_core = ast.unparse(core) + "\n"
    core_metrics = {
        "ast_nodes": sum(1 for _ in ast.walk(core)),
        "normalized_tokens": significant_tokens(normalized_core),
        "normalized_bytes": len(normalized_core.encode("utf-8")),
    }
    return {
        "file": str(path.relative_to(ROOT)),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "whole": whole,
        "core": core_metrics,
    }

def main():
    snapshot = json.loads((ROOT / "comparison/snapshot.json").read_text())
    baselines = []
    for entry in snapshot["checker_sources"]:
        row = measure(ROOT / entry["file"])
        if row["sha256"] != entry["sha256"]:
            raise ValueError("Frozen source changed: " + entry["file"])
        baselines.append(row)
    variants = [
        measure(ROOT / name) for name in (
            "checker.py", "checker_demand.py", "checker_exact.py",
            "checker_open.py", "checker_open_demand.py",
        )
    ]
    minima = {field: min(row["whole"][field] for row in baselines) for field in FIELDS}
    core_minima = {field: min(row["core"][field] for row in baselines) for field in CORE_FIELDS}
    primary = variants[0]
    result = {
        "python_version": platform.python_version(),
        "repository": snapshot["repository"],
        "commit": snapshot["commit"],
        "boundary": "Entire standalone acceptance program; comments and docstrings excluded except from raw bytes.",
        "core_boundary": "Uniform diagnostic dropping imports and the top-level CLI; all top-level If statements in these frozen files are CLI guards.",
        "baselines": baselines,
        "variants": variants,
        "experimental": measure(ROOT / "research/alternating_prototype.py"),
        "current_minima": minima,
        "current_core_minima": core_minima,
        "primary_strictly_below_whole": {field: primary["whole"][field] < minima[field] for field in FIELDS},
        "primary_strictly_below_core": {field: primary["core"][field] < core_minima[field] for field in CORE_FIELDS},
    }
    output = ROOT / "results"
    output.mkdir(exist_ok=True)
    (output / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    names = {
        "reduced": "Reduced",
        "rigid_parameters": "Rigid parameters",
        "scope_kernel": "Scope kernel",
        "stack_kernel": "Stack kernel",
        "unary_numerical_binder": "Unary numerical binder",
        "universal": "Unary universal",
    }
    lines = [
        r"\begingroup\footnotesize",
        r"\begin{longtable}{@{}p{6.7cm}rrrrr@{}}",
        r"\toprule",
        r"Current variant & AST & Source & Norm. & Bytes & Raw\\",
        r"\midrule\endhead",
    ]
    for row in baselines:
        path = Path(row["file"])
        label = names[path.parent.name] + r" / \code{" + path.name + "}"
        values = [str(row["whole"][field]) for field in FIELDS]
        lines.append(label + " & " + " & ".join(values) + r"\\")
    lines.extend([r"\bottomrule", r"\end{longtable}", r"\endgroup"])
    (output / "baseline_table.tex").write_text("\n".join(lines) + "\n")
    print(json.dumps({
        "baseline_count": len(baselines),
        "current_minima": minima,
        "primary": primary,
        "all_whole_coordinates_improve": all(result["primary_strictly_below_whole"].values()),
        "all_core_coordinates_improve": all(result["primary_strictly_below_core"].values()),
    }, indent=2))

if __name__ == "__main__":
    main()
