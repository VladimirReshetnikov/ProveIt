"""Experimental alternating unary-prefix iPRA theorem checker."""
import json
import sys

def subst(a, env=(1,), d=0, formula=True):
    if not formula and type(a) is int:
        i = a - d
        return a if i <= 0 else subst(env[i - 1], (d,), formula=False) if i < len(env) else a + env[-1]
    tag, *args = a
    if formula and (type(tag) is not int or tag < 0):
        raise ValueError
    return [tag, *(subst(b, env, d + width, False) for b, width in zip(args, [tag, tag] if formula else {'s': b'\0', 'r': b'\0\0\2'}[tag], strict=True))]

def check(a, p, g):
    n, s, t = subst(a, (0,))
    b = [n - 1, s, t]
    match p.pop():
        case [] if n % 2:
            h = [subst(b, [0, 0]), *([b] if n == 1 else [])]
            b = subst(b, [['s', 1], 0])
        case [v] if n and not n % 2:
            h = [[0, 1, subst(v, formula=False)]]
        case [[k, u, v] as m, w] if check(m, p, g):
            if k and not k % 2:
                b, h = subst(a), [[k - 1, u, v]]
            else:
                if k:
                    subst(w, formula=False)
                    w, parts = [k - 1, u, v], [0, w]
                else:
                    parts = [u, v]
                b, c = (subst(w, [v, -1]) for v in parts)
                return c == a and check(b, p, g)
        case [] if not n:
            _, n, t, h = s
            if n:
                _, n = n
                t = subst(h, [['r', n, t, h], n, -2], formula=False)
            return a[2] == t
        case _:
            return a in g
    return check(b, p, [*map(subst, g), *h])
if __name__ == '__main__':
    try:
        _, path = sys.argv
        if not check(*json.load(open(path, 'rb')), []):
            raise ValueError
        print('ACCEPT')
    except Exception:
        print('REJECT')
        sys.exit(1)
