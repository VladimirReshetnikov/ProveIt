This direct flat-count prototype is experimental and larger than the selected checker.
It is included only to reproduce the implementation-size comparison.
The paper proves the underlying normalization theorem. This prototype has not
passed the full primary validation suite and is not a recommended kernel.
