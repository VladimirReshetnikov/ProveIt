"""Reproducible positive, adversarial, scoped-substitution, and CLI checks."""
from pathlib import Path
import copy
import importlib.util
import json
import random
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent

def load(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

DEMAND=load('checker_demand')
STRICT=load('checker')
OPEN=load('checker_open_demand')
OPEN_STRICT=load('checker_open')
COMPILER=load('compile_unary')


def accepts(module, document, opened=False):
    try:
        document=copy.deepcopy(document)
        return bool(module.check(*document) if opened else module.check(*document, []))
    except Exception:
        return False


def run_cli(name,document,optimized=False):
    with tempfile.NamedTemporaryFile(mode='w',suffix='.json',encoding='utf-8') as f:
        json.dump(document,f);f.flush()
        command=[sys.executable, *(['-O'] if optimized else []),str(ROOT/(name+'.py')),f.name]
        result=subprocess.run(command,capture_output=True,text=True,timeout=30)
    if result.returncode not in (0,1):raise AssertionError((name,result.returncode,result.stderr))
    expected='ACCEPT\n' if result.returncode==0 else 'REJECT\n'
    if result.stdout!=expected:raise AssertionError((name,result.stdout,result.stderr))
    return result.returncode==0


def syntax_and_semantics():
    eq=['=', ['r',0,0,0], 0]
    u=['u',eq]
    exists0=['ex',['=',1,0]]
    cases=[
      ('recursor_zero',[eq,[[]]],True,True),
      ('rigid_parameter_exists',[['ex',['=',1,-7]],[None,[-7]]],True,True),
      ('nested_rigid_parameter_exists',[['ex',['ex',['=',1,-7]]],[None,[-7],[0]]],True,True),
      ('contradiction',[['=', ['s',0],0],[None]],False,False),
      ('false_successor_computation',[['=', ['r',['s',0],0,1],['s',0]],[[]]],False,False),
      ('recursor_variable',[['=', ['r',1,0,0],0],[[]]],False,False),
      ('bool_leaf',[['=',False,0],[None]],False,False),
      ('float_leaf',[['=',0.0,0],[None]],False,False),
      ('unknown_constructor',[['unknown',0,0],[None]],False,False),
      ('equation_wrong_arity',[['=',0],[None]],False,False),
      ('successor_wrong_arity',[['=',['s',0,0],0],[None]],False,False),
      ('recursor_wrong_arity',[['=',['r',0,0],0],[None]],False,False),
      ('formula_in_term',[['=',['ex',['=',1,0]],0],[None]],False,False),
      ('term_in_formula',[['u',0],[[]]],False,False),
      ('bad_update_sort',[['=',['r',0,0,['=',1,2]],0],[[]]],False,False),
      ('empty_stack',[eq,[]],False,False),
      ('non_stack',[eq,{}],False,False),
      ('existential_escape',[['=',1,0],[None,None,[0],[exists0,0]]],False,False),
      ('compound_induction_hypothesis',[['u',['u',['=',2,0]]],[None,[]]],False,False),
      ('atomic_induction_wrong_step',[['u',['=',1,0]],[None,[]]],False,False),
      ('invalid_equality_motive',[eq,[None,[],[eq,0]]],False,False),
      ('invalid_existential_witness',[['ex',eq],[[],[False]]],False,False),
      ('invalid_unused_u_witness',[eq,[[],[],[],[u,False]]],True,False),
      ('valid_unused_u_witness',[eq,[[],[],[],[u,0]]],True,True),
      ('valid_u_witness_with_free_variable',[eq,[[],[],[],[u,1]]],True,True),
      ('unused_prefix',[eq,[{'irrelevant':'metadata'},[]]],True,True),
      ('forged_external_context',[['=',1,0],[None],['=',1,0]],False,False),
    ]
    results=[]
    for name,document,want_demand,want_strict in cases:
        got_demand=accepts(DEMAND,document)
        got_strict=accepts(STRICT,document)
        assert (got_demand,got_strict)==(want_demand,want_strict),(name,got_demand,got_strict)
        row={'name':name,'demand':got_demand,'strict':got_strict,'expected':[want_demand,want_strict]}
        for kernel,want in [('checker_demand',want_demand),('checker',want_strict)]:
            for optimized in (False,True):
                got=run_cli(kernel,document,optimized)
                assert got==want,(name,kernel,optimized,got)
        results.append(row)
    assert run_cli('checker_exact',[eq,[[]]])
    assert run_cli('checker_exact',[eq,[[]]],True)
    assert not run_cli('checker_exact',[eq,[0,[]]])
    assert not run_cli('checker_exact',[eq,[0,[]]],True)
    return results



def open_rule_tests():
    b=['=',1,0]
    u=['u',b]
    base=['=',0,0]
    compound=['ex',['=',1,2]]
    cases=[
        ('used_positive_witness',[['=',2,0],[None,None,[u,2]],u,base],True,True),
        ('used_rigid_witness',[['=',-7,0],[None,None,[u,-7]],u,base],True,True),
        ('used_bool_witness',[base,[None,None,[u,False]],u,base],False,False),
        ('used_float_witness',[base,[None,None,[u,0.0]],u,base],False,False),
        ('universal_fresh_variable_escape',[u,[None,[]],['=',['s',1],0]],False,False),
        ('forbidden_compound_induction_certificate',
            [['u',compound],[None,[['s',2]],None,[compound,0],[]]],False,False),
        ('unused_malformed_external_hypothesis',[base,[None],base,['=',False,0]],False,False),
        ('equality_motive_wrong_sort',[base,[None,None,[base,0]],base],False,False),
    ]
    results=[]
    for name,document,want_demand,want_strict in cases:
        got=(accepts(OPEN,document,True),accepts(OPEN_STRICT,document,True))
        assert got==(want_demand,want_strict),(name,got)
        for kernel,want in [('checker_open_demand',want_demand),('checker_open',want_strict)]:
            for optimized in (False,True):assert run_cli(kernel,document,optimized)==want,(name,kernel,optimized)
        results.append({'name':name,'demand':got[0],'strict':got[1],'all_cli_modes_verified':True})
    return results


def positive_examples():
    results=[]
    for p in sorted((ROOT/'examples').rglob('*.json')):
        document=json.loads(p.read_text())
        for mod in (OPEN,OPEN_STRICT):
            assert accepts(mod,document,True),(p,mod.__name__)
        closed=len(document)==2
        if closed:
            for mod in (DEMAND,STRICT):assert accepts(mod,document),(p,mod.__name__)
            for name in ('checker_demand','checker','checker_exact'):
                for optimized in (False,True):assert run_cli(name,document,optimized),(p,name,optimized)
        results.append({'file':str(p.relative_to(ROOT)),'theorem':closed,'instructions':len(document[1]),'accepted':True})
    return results


# An independent, name-based scope model. It does not implement shifts by
# the kernel's integer arithmetic. Explicit unique binder names are created
# on decoding and looked up on encoding. This tests both term/formula binders.
def decode(a,context=(),formula=True):
    if not formula and type(a) is int:
        if a==0:return ('zero',)
        if a<0:return ('rigid',a)
        return ('bound',context[-a]) if a<=len(context) else ('free',a-len(context))
    tag,*children=a
    widths=({'=':(0,0),'u':(1,),'ex':(1,)} if formula else {'s':(0,),'r':(0,0,2)})[tag]
    out=[]
    for child,width in zip(children,widths,strict=True):
        names=tuple(object() for _ in range(width))
        newcontext=context+tuple(reversed(names))
        out.append((names,decode(child,newcontext,width==1)))
    return ('node',tag,tuple(out))

def encode(a,context=()):
    tag,*parts=a
    if tag=='zero':return 0
    if tag=='rigid':return parts[0]
    if tag=='free':return len(context)+parts[0]
    if tag=='bound':return context[::-1].index(parts[0])+1
    constructor,children=parts
    return [constructor,*(encode(child,context+tuple(reversed(names)))for names,child in children)]

def named_transform(a,replacements,delta):
    tag,*parts=a
    if tag=='free':
        i=parts[0]
        return replacements[i-1] if i<=len(replacements) else ('free',i+delta)
    if tag!='node':return a
    constructor,children=parts
    return ('node',constructor,tuple((names,named_transform(child,replacements,delta))for names,child in children))

def reference_subst(a,env,protected_depth,formula):
    protected=tuple(object() for _ in range(protected_depth))
    named=decode(a,protected,formula)
    replacements=[decode(t,(),False)for t in env[:-1]]
    return encode(named_transform(named,replacements,env[-1]),protected)


def substitution_checks():
    rng=random.Random(20261106)
    def term(depth=0):
        if depth>=4 or rng.randrange(3)==0:return rng.choice([0,1,2,3,5,9,-1,-7])
        return ['s',term(depth+1)] if rng.randrange(2)==0 else ['r',term(depth+1),term(depth+1),term(depth+1)]
    def formula(depth=0):
        return ['=',term(),term()] if depth>=4 or rng.randrange(2)==0 else [rng.choice(['u','ex']),formula(depth+1)]
    checked=0
    for _ in range(1200):
        f=bool(rng.randrange(2));a=formula() if f else term()
        k=rng.randrange(4)
        env=[term()for _ in range(k)]+[rng.randrange(-k,4)]
        d=rng.randrange(4)
        expected=reference_subst(a,env,d,f)
        actual=STRICT.subst(a,env,d,f)
        assert expected==actual,(a,env,d,f,expected,actual)
        checked+=1
    # Explicit capture trap: free variable inserted beneath both recursor
    # update binders must remain free rather than become the accumulator.
    a=['r',1,0,3]
    assert STRICT.subst(a,[1,-1],formula=False)==['r',1,0,3]
    assert STRICT.subst(['ex',['=',2,-7]],[1,-1])==['ex',['=',2,-7]]
    return {'random_named_oracle_cases':checked,'seed':20261106,'explicit_capture_cases':2,'all_passed':True}



def translation_checks():
    import hashlib
    manifest=json.loads((ROOT/'translation_manifest.json').read_text())
    results=[]
    for row in manifest:
        source=ROOT/row['source'];target=ROOT/row['target']
        assert hashlib.sha256(source.read_bytes()).hexdigest()==row['source_sha256'],source
        assert hashlib.sha256(target.read_bytes()).hexdigest()==row['target_sha256'],target
        before=json.loads(source.read_text())
        compiled=COMPILER.compile_sequent(before)
        expected=json.loads(target.read_text())
        assert compiled==expected,source
        assert accepts(OPEN_STRICT,compiled,True),source
        if len(compiled)==2:assert accepts(STRICT,compiled),source
        results.append({'source':row['source'],'target':row['target'],'recompiled_identically':True,'strict_accepted':True})
    return results


def main():
    report={'translation_checks':translation_checks(),'positive_examples':positive_examples(),'semantic_and_format_cases':syntax_and_semantics(),'open_rule_cases':open_rule_tests(),'substitution':substitution_checks(),'assertions_in_kernel':False,'cli_checked_with_and_without_optimization':True}
    (ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'translation_checks':len(report['translation_checks']),'positive_examples':len(report['positive_examples']),'semantic_and_format_cases':len(report['semantic_and_format_cases']),'open_rule_cases':len(report['open_rule_cases']),'substitution':report['substitution']},indent=2))

if __name__=='__main__':main()
