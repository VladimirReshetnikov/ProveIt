"""Untrusted proof-tree to stack translator; kernels check its complete output."""
from pathlib import Path
import importlib.util
import json
import copy

def load(path, name):
    spec=importlib.util.spec_from_file_location(name, path)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m

ROOT=Path(__file__).resolve().parent
SOURCE=load(ROOT/'reference_unary.py','unary_source')
TARGET=load(ROOT/'checker_open_demand.py','stack_open')
THEOREM=load(ROOT/'checker_demand.py','stack_theorem')

def compile_node(a,p,g):
    match a,p:
        case ['u',b],[q]:
            h=[SOURCE.subst(b,[0,0]), *([b] if b[0]=='=' else [])]
            b=SOURCE.subst(b,[['s',1],0])
            return [[]]+compile_node(b,q,[*map(SOURCE.subst,g),*h])
        case ['ex',b],[t,q]:
            h=[['=',1,SOURCE.subst(t,formula=False)]]
            return [[t]]+compile_node(b,q,[*map(SOURCE.subst,g),*h])
        case _, [[tag,*parts] as m,r,*args] if SOURCE.check(m,r,*g):
            major=compile_node(m,r,g)
            if tag=='ex':
                q,=args
                minor=compile_node(SOURCE.subst(a),q,[*map(SOURCE.subst,g),*parts])
                return [[m,0]]+major+minor
            t,q=args
            if tag=='u':
                b=SOURCE.subst(parts[0],[0,-1])
            else:
                b=SOURCE.subst(t,[parts[0],-1])
            return [[m,t]]+major+compile_node(b,q,g)
        case ['=', ['r',n,t,h],b], 'r':
            return [[]]
        case _:
            if a not in g: raise ValueError('Invalid source proof')
            return [None]

def compile_sequent(document):
    a,p,*g=document
    if not SOURCE.check(a,p,*g):raise ValueError('Source rejected')
    program=list(reversed(compile_node(a,p,g)))
    result=[a,program,*g]
    if not TARGET.check(*copy.deepcopy(result)): raise ValueError('Target rejected')
    if not g and not THEOREM.check(a,copy.deepcopy(program),[]):raise ValueError('Theorem checker rejected')
    return result

if __name__=='__main__':
    import sys
    print(json.dumps(compile_sequent(json.loads(Path(sys.argv[1]).read_text())),indent=2))
