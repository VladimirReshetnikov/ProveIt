"""Reproduce validation, measurements, and the PDF from this archive."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def run(*args):
    subprocess.run(args, cwd=ROOT, check=True)

run(sys.executable, "validate.py")
run(sys.executable, "comparison/measure.py")
for _ in range(3):
    run("pdflatex", "-interaction=nonstopmode", "-halt-on-error", "report.tex")
