The independent audit records use working filenames before packaging.
checker_strict.py became checker.py; checker_open_strict.py became checker_open.py;
checker.py in the working candidate directory became checker_demand.py.
SHA-256 hashes identify the unchanged implementations across these renames.
The report incorporates the final attribution and build-pass corrections.
