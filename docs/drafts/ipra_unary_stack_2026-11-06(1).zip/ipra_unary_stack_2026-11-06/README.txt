A SMALLER COMPLETE PROOF PRESENTATION OF iPRA
6 November 2026

Read report.pdf for the complete calculus, logic and arithmetic reconstruction,
bi-interpretability proof, implementation correctness argument, measurements,
new alternating-prefix theorem, and further research questions.
report.tex and sections/*.tex are the complete LaTeX sources.

MAIN RESULT
The primary strict checker has 518 executable Python AST nodes, 511 significant
source tokens, 517 normalized tokens, 1582 normalized bytes, and 1653 raw bytes.
All are strictly below the corresponding componentwise minima of the fourteen
complete checkers in the six current draft archives at commit:
b9aefe20fe876273886d5d55be49e6ccbefce9ad

The primary also beats the uniformly stripped core minima:
452 AST nodes / 459 normalized tokens / 1320 normalized bytes
versus 468 / 461 / 1324. The core byte improvement is small: four bytes.
This is a finite-corpus improvement, not a proof of global minimality.

KERNELS
checker.py              Strict theorem checker; main recommended version.
checker_demand.py       Smaller companion permitting irrelevant bad U witnesses.
checker_exact.py        Strict theorem checker requiring complete stack consumption.
checker_open.py         Strict open-sequent checker; validates all external assumptions.
checker_open_demand.py  Demand-validation open-sequent companion.

The theorem input is [goal, stack].
The open input is [goal, stack, assumption1, assumption2, ...].
Stacks are stored in reverse execution order.
See FORMAT.txt for the exact grammar, rules, and acceptance policies.
Negative term integers name free parameters; they are not negative numbers.
The primary validates all selected witnesses but permits unused stack prefixes.
All variants recognize the same corresponding native consequences.

REPRODUCE (Python 3.12 recommended)
python3 validate.py
python3 comparison/measure.py
python3 checker.py examples/arithmetic_examples/zero_plus_theorem.json
python3 checker_exact.py examples/logic_examples/encoded_forall_exists_successor.json

The last two commands print ACCEPT.
Python 3.10 is the minimum implementation language version; use the recorded
Python 3.12 version when reproducing normalized-source measurements.

REBUILD THE PAPER
python3 build.py
Requires pdflatex and the ordinary TeX packages listed in report.tex.
This reruns validation and measurement before compiling the paper three times.

INCLUDED EVIDENCE
- 31 exact source proofs, their translations, and a frozen source checker.
- A portable untrusted compiler and independent named-binder substitution oracle.
- Malformed-input, scope, witness, arithmetic, and CLI optimization tests.
- Frozen current baseline checkers and SHA-256-checked measurement script.
- Detailed JSON results and separate audit records.

No helper is imported by the primary checker. Python's ordinary runtime and
standard JSON parsing are the same ambient facilities used for the comparison.
The metatheory is a mathematical proof, not a completed Lean/Rocq formalization.

ALTERNATING NORMAL FORM
The report also proves that arbitrary unary binder words can be replaced by
alternating words ending with U next to the equation. A formula can then be
represented by a binder count and two terms. The current direct experimental
checker is larger (605 AST / 559 normalized tokens / 1754 normalized bytes).
It is retained under research/ for reproducible measurement, not recommended
as the acceptance program and not claimed to have passed the primary suite.

ATTRIBUTION
The mathematical basis and several implementation ideas come from the six
current ProveIt draft proposals. The report distinguishes inherited material,
new implementation changes, and the new normal-form theorem.
See LICENSE_SOURCE.txt and comparison/snapshot.json.
