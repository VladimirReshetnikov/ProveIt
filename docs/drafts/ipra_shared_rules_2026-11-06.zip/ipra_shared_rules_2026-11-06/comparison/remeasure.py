"""Remeasure the frozen corpus without importing or executing a checker.

Usage: python3 remeasure.py [CANDIDATE.py]
"""
import ast,hashlib,io,json,pathlib,platform,sys,tokenize
ROOT=pathlib.Path(__file__).resolve().parent
AXES=('raw_bytes','normalized_bytes','source_tokens','normalized_tokens','ast_nodes')
SKIP={tokenize.ENCODING,tokenize.ENDMARKER,tokenize.COMMENT,tokenize.NL,tokenize.NEWLINE,tokenize.INDENT,tokenize.DEDENT}
class Strip(ast.NodeTransformer):
 def clean(self,n):
  if n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):n.body.pop(0)
  return self.generic_visit(n)
 visit_Module=clean
 visit_FunctionDef=clean
 visit_AsyncFunctionDef=clean
 visit_ClassDef=clean
def measure(path):
 data=path.read_bytes();source=data.decode('utf-8');tree=ast.parse(source);spans=[]
 for n in ast.walk(tree):
  if isinstance(n,(ast.Module,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):
   d=n.body[0];spans.append(((d.lineno,d.col_offset),(d.end_lineno,d.end_col_offset)))
 tokens=[t for t in tokenize.generate_tokens(io.StringIO(source).readline) if t.type not in SKIP and not any(a<=t.start and t.end<=b for a,b in spans)]
 tree=Strip().visit(tree);normalized=ast.unparse(tree)+'\n'
 ntokens=[t for t in tokenize.generate_tokens(io.StringIO(normalized).readline) if t.type not in SKIP]
 return {'sha256':hashlib.sha256(data).hexdigest(),'raw_bytes':len(data),'normalized_bytes':len(normalized.encode('utf-8')),'source_tokens':len(tokens),'normalized_tokens':len(ntokens),'ast_nodes':sum(1 for n in ast.walk(tree))}
def envelope(metrics):return {k:min(m[k] for m in metrics) for k in AXES}
def main():
 inv=json.loads((ROOT/'inventory.json').read_text());measured={}
 for row in inv['source_files']:
  m=measure(ROOT/row['path'])
  if m['sha256']!=row['sha256']:raise ValueError('Hash mismatch: '+row['path'])
  measured[row['sha256']]=m
 groups=[]
 for g in inv['inherited_groups']:
  groups.append({'id':g['id'],'label':g['label'],'metrics':{k:sum(measured[f['sha256']][k] for f in g['files']) for k in AXES}})
 primary=[{'archive':next(o['archive'] for o in row['occurrences'] if len(pathlib.PurePosixPath(o['archive_member']).parts)==2 and o['archive_member'].endswith('/checker.py')),'metrics':measured[row['sha256']]} for row in inv['primary_checkers']]
 standalone=[measured[row['sha256']] for row in inv['standalone_checkers']]
 result={'python_version':platform.python_version(),'repository_commit':inv['repository_commit'],'primary':primary,'primary_minima':envelope([r['metrics'] for r in primary]),'expanded_minima':envelope(standalone+[g['metrics'] for g in groups]),'standalone_count':len(standalone),'group_count':len(groups),'verified_source_count':len(measured)}
 if len(sys.argv)>1:
  result['candidate']=measure(pathlib.Path(sys.argv[1]));result['strict_below_expanded']={k:result['candidate'][k]<result['expanded_minima'][k] for k in AXES}
 (ROOT/'remeasured.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
