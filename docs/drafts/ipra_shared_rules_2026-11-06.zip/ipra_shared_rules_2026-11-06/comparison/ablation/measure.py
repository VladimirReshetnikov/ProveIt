"""Whole-program metrics, copied from the frozen d0 measurement method.

The measured files are not imported or executed. Comments, docstrings,
and layout are excluded from significant tokens and normalized source.
All executable statements, tables, import declarations, and CLI code count.
"""

import ast
import hashlib
import io
import tokenize


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    """Count complete source, excluding only documentation and layout."""
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                spans.append(((doc.lineno, doc.col_offset),
                              (doc.end_lineno, doc.end_col_offset)))
    excluded = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
                tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
    tokens = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
              if t.type not in excluded
              and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    normalized_tokens = [
        t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
        if t.type not in excluded]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return dict(
        sha256=hashlib.sha256(data).hexdigest(), raw_bytes=len(data),
        normalized_bytes=len(normalized.encode("utf-8")),
        source_tokens=len(tokens), normalized_tokens=len(normalized_tokens),
        ast_nodes=sum(1 for _ in ast.walk(tree)), lines=len(source.splitlines()),
        imported_modules=sorted(set(imports)))


