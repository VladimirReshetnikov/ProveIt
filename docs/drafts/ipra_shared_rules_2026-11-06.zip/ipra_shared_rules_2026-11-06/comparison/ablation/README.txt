ABLATION OF THE SELECTED COMPLETE iPRA CHECKER
============================================

Purpose and scope
-----------------
This is one replayable sequence of exact edits from the unchanged current
shared-traversal checker (d0) to the selected checker. It does not assemble
unrelated experimental variants into a misleading trajectory. Every numbered
.py file is a complete independently runnable acceptance program, including
syntax tables, all proof and arithmetic cases, falsity erasure, JSON parsing,
and the command-line wrapper. Only Python's json and sys modules are used.

The baseline is the checker.py member of
  docs/drafts/ipra_shared_traversal_2026-11-06.zip
at ProveIt commit 046c84aa5e99f3a437e5bc6873af9f9a1cc797a5.
The full identity and source hashes are in recipe.json and manifest.json.
The final source is byte-for-byte identical to the selected checker.py,
SHA-256 1cf50915efe8cb60d736b12eb45486e7b64f42a38422dc04340e3b513d8dbd2f.

Reproduction
------------
From this directory, run:
  python3 reproduce.py
This verifies every edit match, reconstructs every source in memory, compares
it with the bundled file, checks every unified patch, recomputes all complete
metrics, and checks the final hash. It does not execute a proof checker.
To regenerate the numbered sources, patches and metrics from the frozen
baseline and explicit recipe, run:
  python3 reproduce.py --write
Python 3.12.14 was used for the recorded measurements. ast.unparse and Python
AST details are interpreter-version-dependent; compare with the stated
version if a future interpreter produces different normalized metrics.

Metric convention
-----------------
Raw bytes count the complete file, including documentation. Source tokens
exclude comments, genuine docstrings and layout. Normalized bytes and tokens
use ast.unparse after docstring removal, followed by one newline. AST nodes
count the complete resulting tree. These are exactly the d0 measurement
conventions. All executable data and imports remain counted.

Sequence and measured effects
-----------------------------
The columns are raw bytes, normalized bytes, source tokens, normalized tokens,
and AST nodes. Deltas are from the immediately preceding row.

00_current_d0.py
  Unchanged current d0 checker
  Category: baseline
  Metrics: 2928 / 2618 / 808 / 808 / 855
  Deltas:  +0 / +0 / +0 / +0 / +0

01_strict_keys.py
  Validate every hypothesis lookup key before membership lookup.
  Category: validation strengthening
  Metrics: 2965 / 2655 / 816 / 816 / 863
  Deltas:  +37 / +37 / +8 / +8 / +8

02_shared_introductions.py
  Share pi/pack context extension, recursive inference, and result construction; compute the constructor flag once.
  Category: control-flow factoring
  Metrics: 2977 / 2645 / 808 / 806 / 861
  Deltas:  +12 / -10 / -8 / -10 / -2

03_allowed_sort_membership.py
  Express the allowed outer-sort alternatives by membership.
  Category: equivalent predicate spelling
  Metrics: 2964 / 2632 / 806 / 804 / 857
  Deltas:  -13 / -13 / -2 / -2 / -4

04_scalar_sort_flag.py
  Use not formula when the internally supplied flag is None, False, or True.
  Category: equivalent predicate spelling
  Metrics: 2956 / 2624 / 804 / 802 / 856
  Deltas:  -8 / -8 / -2 / -2 / -1

05_rec_counter_guard.py
  Rely on earlier full term validation and the existing TypeError rejection for a nonzero integer counter.
  Category: redundant validation removal
  Metrics: 2936 / 2604 / 797 / 795 / 845
  Deltas:  -20 / -20 / -7 / -7 / -11

06_cli_unpack.py
  Use exact tuple unpacking for the existing two-argument CLI contract.
  Category: equivalent CLI validation
  Metrics: 2920 / 2588 / 788 / 786 / 837
  Deltas:  -16 / -16 / -9 / -9 / -8

07_bare_exception.py
  Drop exception-message construction because the CLI exposes only ACCEPT or REJECT.
  Category: diagnostic simplification
  Metrics: 2874 / 2542 / 782 / 780 / 833
  Deltas:  -46 / -46 / -6 / -6 / -4

08_import_consolidation.py
  Put the same two counted standard-library imports in one statement.
  Category: import syntax normalization
  Metrics: 2868 / 2536 / 782 / 780 / 832
  Deltas:  -6 / -6 / +0 / +0 / -1

09_final.py
  Shorten the module docstring; executable code and all normalized metrics are unchanged.
  Category: documentation only
  Metrics: 2670 / 2536 / 782 / 780 / 832
  Deltas:  -198 / +0 / +0 / +0 / +0
Interpretation of the reduction
-------------------------------
The mathematical calculus is unchanged. The strict-key step intentionally
strengthens the certificate format: malformed Boolean or floating-point
aliases in hypothesis lookup keys are rejected even if Python equality would
match a stored well-formed formula. On well-formed certificates it changes no
accepted derivation. It costs 8 normalized tokens, 8 AST nodes and 37 bytes.

The principal control-flow factoring is stage 02: the two introductions share
context shifting, assumption extension, recursive inference and conclusion
construction. It saves 10 normalized tokens and 2 AST nodes against the
strict baseline. This is modest. The shared pack branch validates its witness
before constructing the context and then calls subst again to shift it;
it is a code-size optimization, not a claim of fewer traversal operations.

Stage 05 removes a redundant type guard because the entire recursor was
already validated and the existing wrapper rejects TypeError. It saves 7
normalized tokens and 11 AST nodes. The checker still validates every term,
including recursor bodies and unused annotations.

The other executable edits are local predicate spelling, CLI arity checking,
diagnostic-message removal, and import syntax. They should not be presented
as a new logical idea. From the strict baseline to the final executable code,
36 normalized tokens and 31 AST nodes are saved. The shared introductions and
redundant recursor guard account for 17 of those tokens and 13 of those nodes;
the remaining 19 tokens and 18 nodes come from the smaller syntactic and CLI
changes. In normalized bytes, these two main changes account for 30 of the
119 gross bytes saved from the strict baseline; predicate spelling saves
another 21, and CLI/diagnostic/import changes save 68.

Consequently, the reduction depends substantially on ordinary implementation
normalization. It is not an architectural breakthrough. The final whole-file
result is 28 normalized tokens and 23 AST nodes smaller than the original d0,
while also enforcing strict hypothesis-key formation.

The distinction matters especially for byte comparisons. Shortening the
module docstring saves 198 raw bytes and changes no normalized metric. This
accounts for 198 of the net 258 raw bytes saved from d0. Bare exception-message
removal saves 46 normalized bytes and changes no accepted/rejected result at
the CLI. Raw byte dominance and a small normalized byte margin should not be
used as the main mathematical evidence for simplicity.

Against the expanded canonical-only comparator (796 normalized tokens,
839 AST nodes, 2547 normalized bytes), stage 05 already wins on tokens (795),
stage 06 also wins on AST nodes (837), and stage 07 first wins on normalized
bytes (2542). The final stage is 780 normalized tokens, 832 AST nodes and
2536 normalized bytes, with public falsity and strict keys included. These
are reproducible finite-comparison results, not lower bounds on every
possible checker or a proof of an absolutely simplest axiomatization.

Correctness and verification boundary
-------------------------------------
See CHECKER_SOUNDNESS.txt for the transformation arguments, binding invariant,
and the infer/check soundness outline. Source replay is verified here; it is
not a formal proof of Python semantics. The selected final checker has the
previously reported finite independent regression evidence. This ablation
step does not broaden or repeat that testing. Existing audit expectations
were tightened only for the explicitly documented malformed hypothesis keys.

Files
-----
  00_current_d0.py ... 09_final.py: complete source at every stage
  recipe.json: all exact replacements, counts, provenance and final hash
  manifest.json: complete metrics, stage deltas and source hashes
  diffs/*.patch: unified diff for every consecutive pair
  measure.py: the frozen d0 measurement method, without its unrelated driver
  reproduce.py: read-only replay/measurement verifier; optional regeneration
  table.csv: machine-readable summary
  table.tex: ready-to-include LaTeX table
  CHECKER_SOUNDNESS.txt: implementation correspondence and soundness notes
