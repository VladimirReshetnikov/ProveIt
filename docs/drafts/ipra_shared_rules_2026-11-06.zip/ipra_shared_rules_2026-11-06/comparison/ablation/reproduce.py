"""Replay the explicit ablation edits and verify every complete source.

Run `python3 reproduce.py` to check bundled outputs without rewriting them.
Use `python3 reproduce.py --write` to recreate all generated outputs.
No proof checker is imported or run by this script.
"""

import argparse
import difflib
import hashlib
import json
import platform
from pathlib import Path

from measure import measure


ROOT = Path(__file__).resolve().parent
AXES = ("raw_bytes", "normalized_bytes", "source_tokens",
        "normalized_tokens", "ast_nodes")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true")
    options = parser.parse_args()
    recipe = json.loads((ROOT / "recipe.json").read_text())
    source_record = recipe["source"]
    source_path = ROOT / source_record["file"]
    source = source_path.read_text()
    require(hashlib.sha256(source.encode()).hexdigest() == source_record["sha256"],
            "Frozen d0 source hash changed")
    rows = [{"file": source_record["file"], "description": "Unchanged current d0 checker",
             "category": "baseline", "metrics": measure(source_path),
             "delta_from_previous": {axis: 0 for axis in AXES}}]
    previous_file = source_record["file"]
    for stage in recipe["stages"]:
        previous = source
        for replacement in stage["replacements"]:
            require(source.count(replacement["old"]) == replacement["count"],
                    "Edit match count changed in " + stage["file"])
            source = source.replace(replacement["old"], replacement["new"])
        path = ROOT / stage["file"]
        patch = "".join(difflib.unified_diff(
            previous.splitlines(keepends=True), source.splitlines(keepends=True),
            fromfile=previous_file, tofile=stage["file"]))
        patch_path = ROOT / "diffs" / (path.stem + ".patch")
        if options.write:
            path.write_text(source)
            patch_path.write_text(patch)
        else:
            require(path.read_text() == source, "Source replay mismatch: " + str(path))
            require(patch_path.read_text() == patch, "Patch replay mismatch: " + str(patch_path))
        metrics = measure(path)
        require(metrics["imported_modules"] == ["json", "sys"],
                "Uncounted dependency in " + stage["file"])
        row = {key: stage[key] for key in ("file", "description", "category")}
        row["metrics"] = metrics
        row["delta_from_previous"] = {
            axis: metrics[axis] - rows[-1]["metrics"][axis] for axis in AXES}
        rows.append(row)
        previous_file = stage["file"]
    require(hashlib.sha256(source.encode()).hexdigest() == recipe["target_sha256"],
            "Final stage does not reproduce the frozen selected checker")
    report = {
        "python_version": platform.python_version(),
        "method": "Complete acceptance modules, identical d0 measurement method; "
                  "only genuine docstrings, comments, and layout are excluded. "
                  "Normalized source uses ast.unparse plus one newline. "
                  "Each row is an independently runnable complete checker.",
        "source": source_record,
        "target_sha256": recipe["target_sha256"],
        "stages": rows,
        "total_delta": {axis: rows[-1]["metrics"][axis] - rows[0]["metrics"][axis]
                        for axis in AXES}}
    report_path = ROOT / "manifest.json"
    if options.write:
        report_path.write_text(json.dumps(report, indent=2) + "\n")
    else:
        recorded = json.loads(report_path.read_text())
        require(recorded["stages"] == rows,
                "Metric mismatch (check the recorded Python version before interpreting)")
        require(recorded["target_sha256"] == recipe["target_sha256"],
                "Target identity mismatch")
    print(json.dumps({"status": "passed", "stages_verified": len(rows),
                      "python_version": platform.python_version(),
                      "final_metrics": rows[-1]["metrics"],
                      "total_delta": report["total_delta"]}, indent=2))


if __name__ == "__main__":
    main()
