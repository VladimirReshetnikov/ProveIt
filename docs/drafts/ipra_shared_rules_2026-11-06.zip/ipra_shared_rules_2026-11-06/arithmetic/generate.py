"""Construct and check explicit arithmetic proofs in the unary iPRA calculus.

This is an UNTRUSTED proof generator.  Its output contains only the six
ordinary proof records accepted by the separate checker.  There are no
arithmetic-oracle, theorem-reference, or proof-sharing records in its output.

The named proof builder and reference checker are unchanged copies from
VladimirReshetnikov/ProveIt, ipra_unary_existential_2026-11-06, at repository
snapshot 9e338a5c51a26ac6ae90f2d8f563a44c3879ba68.  See provenance.json.

Every use of a previously established arithmetic lemma is expanded using
ordinary implication introduction/elimination.  This keeps the proof trees
manageable while ensuring every exported certificate is self-contained.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "vendor" / "validation"))
from builder import *


ONE = S(Z)


def pred(n):
    u, k = fresh("previous"), fresh("counter")
    return R(n, Z, u, k, k)


def qfun(n, a):
    u, k = fresh("previous"), fresh("counter")
    return R(n, a, u, k, k)


def add(a, n):
    u, k = fresh("previous"), fresh("counter")
    return R(n, a, u, k, S(u))


def diff(a, n):
    u, k = fresh("previous"), fresh("counter")
    return R(n, a, u, k, pred(u))


def eps(s, t):
    return qfun(diff(S(s), t), ONE)


def chain(*proofs):
    assert proofs
    result = proofs[0]
    for p in proofs[1:]:
        result = trans(result, p)
    return result


def congruent(p, context):
    x = fresh("replacement")
    return congr(p, x, context(x))


def transport(p, formula, premise):
    x = fresh("replacement")
    return rewrite(p, x, formula(x), premise)


def cases(t, conclusion, zero_branch, successor_branch):
    """Contextual number cases, derived from the non-equation numerical mode.

    The fresh template variable is distinct from every parameter in t and in
    the retained context.  In particular this construction can retain an
    induction hypothesis mentioning the term on which it splits.
    """
    x = fresh("case_template")
    matrix = Imp(Eq(t, x), conclusion)
    base = imp_intro(Eq(t, Z), zero_branch)

    def step(y, unused_fixed_base):
        return imp_intro(Eq(t, S(y)), lambda equality: successor_branch(y, equality))

    conditional = numerical(x, matrix, t, base, step)
    return imp_elim(conditional, refl(t))


LEMMAS = {}
ORDER = []
ACTIVE = None


def register(name, parameters, conclusion, build):
    global ACTIVE
    assert name not in LEMMAS
    previous, ACTIVE = ACTIVE, set()
    proof = as_goal(build(), conclusion)
    dependencies = ACTIVE
    ACTIVE = previous
    statement = conclusion
    for x in reversed(parameters):
        statement = All(x, statement)
        proof = pi_intro(x, T, proof)
    assert not free(statement), (name, free(statement))
    LEMMAS[name] = {
        "parameters": parameters,
        "conclusion": conclusion,
        "statement": statement,
        "proof": proof,
        "dependencies": dependencies,
    }
    ORDER.append(name)


def use(name, *arguments):
    if ACTIVE is not None:
        ACTIVE.add(name)
    entry = LEMMAS[name]
    assert len(arguments) == len(entry["parameters"])
    result = hyp(entry["statement"])
    for argument in arguments:
        result = pi_elim(result, argument, refl(Z))
    return result


def close(proof, dependencies):
    """Discharge all library assumptions by explicit ordinary logical cuts."""
    needed = set(dependencies)
    pending = list(dependencies)
    while pending:
        name = pending.pop()
        for dependency in LEMMAS[name]["dependencies"]:
            if dependency not in needed:
                needed.add(dependency)
                pending.append(dependency)
    for name in reversed(ORDER):
        if name in needed:
            entry = LEMMAS[name]
            guarded = pi_intro(fresh("cut_dummy"), entry["statement"], proof)
            proof = imp_elim(guarded, entry["proof"])
    return proof, [name for name in ORDER if name in needed]


def make_library():
    a, b, r, y, n = [fresh(x) for x in ("a", "b", "r", "y", "n")]

    def zero_plus():
        x = fresh("induction_n")
        matrix = Eq(add(Z, x), x)
        return numerical(x, matrix, n, compute(add(Z, Z)),
                         lambda k, ih: chain(compute(add(Z, S(k))),
                                             congruent(ih, S)))

    register("zero_plus", [n], Eq(add(Z, n), n), zero_plus)

    def successor_plus():
        x = fresh("induction_b")
        matrix = Eq(add(S(a), x), S(add(a, x)))
        base = chain(compute(add(S(a), Z)),
                     sym(congruent(compute(add(a, Z)), S)))

        def step(k, ih):
            return chain(compute(add(S(a), S(k))),
                         congruent(ih, S),
                         sym(congruent(compute(add(a, S(k))), S)))

        return numerical(x, matrix, b, base, step)

    register("successor_plus", [a, b], Eq(add(S(a), b), S(add(a, b))), successor_plus)

    register("plus_one", [a], Eq(add(a, ONE), S(a)),
             lambda: chain(compute(add(a, ONE)), congruent(compute(add(a, Z)), S)))

    def zero_diff():
        x = fresh("induction_b")
        matrix = Eq(diff(Z, x), Z)
        return numerical(x, matrix, b, compute(diff(Z, Z)),
                         lambda k, ih: chain(compute(diff(Z, S(k))),
                                             congruent(ih, pred), compute(pred(Z))))

    register("zero_diff", [b], Eq(diff(Z, b), Z), zero_diff)

    def diff_cancel():
        x = fresh("induction_b")
        matrix = Eq(diff(S(a), S(x)), diff(a, x))
        base = chain(compute(diff(S(a), ONE)),
                     congruent(compute(diff(S(a), Z)), pred),
                     compute(pred(S(a))), sym(compute(diff(a, Z))))

        def step(k, ih):
            return chain(compute(diff(S(a), S(S(k)))),
                         congruent(ih, pred), sym(compute(diff(a, S(k)))))

        return numerical(x, matrix, b, base, step)

    register("diff_cancel", [a, b], Eq(diff(S(a), S(b)), diff(a, b)), diff_cancel)

    def diagonal():
        x = fresh("induction_a")
        matrix = Eq(diff(x, x), Z)
        return numerical(x, matrix, a, compute(diff(Z, Z)),
                         lambda k, ih: chain(use("diff_cancel", k, k), ih))

    register("diff_diagonal", [a], Eq(diff(a, a), Z), diagonal)

    def successor_diagonal():
        x = fresh("induction_a")
        matrix = Eq(diff(S(x), x), ONE)
        return numerical(x, matrix, a, compute(diff(ONE, Z)),
                         lambda k, ih: chain(use("diff_cancel", S(k), k), ih))

    register("diff_successor_diagonal", [a], Eq(diff(S(a), a), ONE), successor_diagonal)

    def injective():
        assumption = Eq(S(a), S(b))
        return imp_intro(assumption,
                         lambda p: chain(sym(compute(pred(S(a)))),
                                         congruent(p, pred), compute(pred(S(b)))))

    register("successor_injective", [a, b], Imp(Eq(S(a), S(b)), Eq(a, b)), injective)

    def selector_same():
        x = fresh("induction_r")
        matrix = Eq(selector(x, a, a), a)
        return numerical(x, matrix, r, compute(selector(Z, a, a)),
                         lambda k, unused_ih: compute(selector(S(k), a, a)))

    register("selector_same", [r, a], Eq(selector(r, a, a), a), selector_same)

    def residual():
        x = fresh("induction_n")

        def left(counter):
            remainder = diff(y, counter)
            return selector(remainder, y, add(counter, remainder))

        matrix = Eq(left(x), y)
        base = chain(
            congruent(compute(diff(y, Z)), lambda v: selector(v, y, add(Z, v))),
            congruent(use("zero_plus", y), lambda v: selector(y, y, v)),
            use("selector_same", y, y),
        )

        def step(k, ih):
            remainder = diff(y, k)

            def next_left(v):
                return selector(v, y, add(S(k), v))

            local_goal = Eq(next_left(pred(remainder)), y)

            def zero_branch(is_zero):
                next_zero = chain(congruent(is_zero, pred), compute(pred(Z)))
                return chain(congruent(next_zero, next_left),
                             compute(selector(Z, y, add(S(k), Z))))

            def successor_branch(q, is_successor):
                specialized_ih = transport(
                    is_successor,
                    lambda v: Eq(selector(v, y, add(k, v)), y), ih)
                sum_equals_y = chain(
                    sym(compute(selector(S(q), y, add(k, S(q))))),
                    specialized_ih,
                )
                new_sum_equals_y = chain(
                    use("successor_plus", k, q),
                    sym(compute(add(k, S(q)))), sum_equals_y,
                )
                next_equals_q = chain(congruent(is_successor, pred), compute(pred(S(q))))
                return chain(
                    congruent(next_equals_q, next_left),
                    congruent(new_sum_equals_y, lambda v: selector(q, y, v)),
                    use("selector_same", q, y),
                )

            branches = cases(remainder, local_goal, zero_branch, successor_branch)
            return chain(congruent(compute(diff(y, S(k))), next_left), branches)

        return numerical(x, matrix, n, base, step)

    register("residual", [y, n], Eq(selector(diff(y, n), y, add(n, diff(y, n))), y), residual)

    def q_zero_implies_one():
        premise = Eq(qfun(r, ONE), Z)

        def body(q_is_zero):
            goal = Eq(r, ONE)

            def zero_branch(r_is_zero):
                q_is_one = chain(congruent(r_is_zero, lambda v: qfun(v, ONE)),
                                 compute(qfun(Z, ONE)))
                clash = chain(sym(q_is_zero), q_is_one)
                return collapse(clash, r, ONE)

            def successor_branch(q, r_is_successor):
                q_equals_counter = chain(congruent(r_is_successor, lambda v: qfun(v, ONE)),
                                         compute(qfun(S(q), ONE)))
                counter_is_zero = chain(sym(q_equals_counter), q_is_zero)
                return chain(r_is_successor, congruent(counter_is_zero, S))

            return cases(r, goal, zero_branch, successor_branch)

        return imp_intro(premise, body)

    register("q_zero_implies_one", [r], Imp(Eq(qfun(r, ONE), Z), Eq(r, ONE)),
             q_zero_implies_one)

    register("q_one_implies_zero", [r], Imp(Eq(r, ONE), Eq(qfun(r, ONE), Z)),
             lambda: imp_intro(Eq(r, ONE),
                               lambda p: chain(congruent(p, lambda v: qfun(v, ONE)),
                                               compute(qfun(ONE, ONE)))))

    def one_residual_implies_equal():
        premise = Eq(diff(S(a), b), ONE)

        def body(d_is_one):
            identity = use("residual", S(a), b)
            specialized = transport(d_is_one,
                                    lambda v: Eq(selector(v, S(a), add(b, v)), S(a)),
                                    identity)
            sum_equality = chain(sym(compute(selector(ONE, S(a), add(b, ONE)))),
                                 specialized)
            successors_equal = chain(sym(use("plus_one", b)), sum_equality)
            return sym(imp_elim(use("successor_injective", b, a), successors_equal))

        return imp_intro(premise, body)

    register("one_residual_implies_equal", [a, b],
             Imp(Eq(diff(S(a), b), ONE), Eq(a, b)), one_residual_implies_equal)

    register("equal_implies_one_residual", [a, b],
             Imp(Eq(a, b), Eq(diff(S(a), b), ONE)),
             lambda: imp_intro(Eq(a, b),
                               lambda p: chain(congruent(p, lambda v: diff(S(v), b)),
                                               use("diff_successor_diagonal", b))))

    register("epsilon_zero_implies_equal", [a, b],
             Imp(Eq(eps(a, b), Z), Eq(a, b)),
             lambda: imp_intro(Eq(eps(a, b), Z),
                               lambda p: imp_elim(use("one_residual_implies_equal", a, b),
                                                 imp_elim(use("q_zero_implies_one", diff(S(a), b)), p))))

    register("equal_implies_epsilon_zero", [a, b],
             Imp(Eq(a, b), Eq(eps(a, b), Z)),
             lambda: imp_intro(Eq(a, b),
                               lambda p: imp_elim(use("q_one_implies_zero", diff(S(a), b)),
                                                 imp_elim(use("equal_implies_one_residual", a, b), p))))


def structural_stats(value):
    stack = [(value, 1)]
    nodes, max_depth = 0, 0
    while stack:
        current, depth = stack.pop()
        nodes += 1
        max_depth = max(max_depth, depth)
        if type(current) is list:
            stack.extend((child, depth + 1) for child in current)
    stack = [(value[2], 1)]
    proof_nodes, proof_depth = 0, 0
    while stack:
        current, depth = stack.pop()
        proof_nodes += 1
        proof_depth = max(proof_depth, depth)
        if current[0] in ("pi", "pack"):
            stack.append((current[2], depth + 1))
        elif current[0] == "use":
            stack.extend(((current[1], depth + 1), (current[3], depth + 1)))
        else:
            assert current[0] in ("hyp", "rec", "nat")
    return {"json_nodes": nodes, "json_depth": max_depth,
            "proof_nodes": proof_nodes, "proof_depth": proof_depth}


def load_checker(path):
    spec = importlib.util.spec_from_file_location("additional_arithmetic_checker", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path,
                        help="Also check all certificates with this separate checker.py")
    args = parser.parse_args()
    additional = load_checker(args.checker) if args.checker else None
    out = ROOT / "certificates"
    out.mkdir(exist_ok=True)
    start = time.perf_counter()
    make_library()
    records = []
    s, t = fresh("external_s"), fresh("external_t")
    tests = [
        ("zero_plus", [s], [], Eq(add(Z, s), s), "0+s=s"),
        ("successor_plus", [s, t], [], Eq(add(S(s), t), S(add(s, t))), "S(s)+t=S(s+t)"),
        ("zero_diff", [s], [], Eq(diff(Z, s), Z), "d(0,s)=0"),
        ("diff_cancel", [s, t], [], Eq(diff(S(s), S(t)), diff(s, t)), "d(S(s),S(t))=d(s,t)"),
        ("diff_diagonal", [s], [], Eq(diff(s, s), Z), "d(s,s)=0"),
        ("diff_successor_diagonal", [s], [], Eq(diff(S(s), s), ONE), "d(S(s),s)=1"),
        ("residual", [s, t], [], Eq(selector(diff(s, t), s, add(t, diff(s, t))), s),
         "C(d(s,t),s,t+d(s,t))=s"),
        ("q_zero_implies_one", [s], [Eq(qfun(s, ONE), Z)], Eq(s, ONE), "Q(s,1)=0 |- s=1"),
        ("one_residual_implies_equal", [s, t], [Eq(diff(S(s), t), ONE)],
         Eq(s, t), "d(S(s),t)=1 |- s=t"),
        ("epsilon_zero_implies_equal", [s, t], [Eq(eps(s, t), Z)],
         Eq(s, t), "epsilon(s,t)=0 |- s=t"),
        ("equal_implies_epsilon_zero", [s, t], [Eq(s, t)],
         Eq(eps(s, t), Z), "s=t |- epsilon(s,t)=0"),
    ]
    for name, arguments, context, expected_goal, description in tests:
        before = time.perf_counter()
        proof = use(name, *arguments)
        for assumption in context:
            proof = imp_elim(proof, hyp(assumption))
        proof = as_goal(proof, expected_goal)
        proof, dependencies = close(proof, {name})
        data = certificate(context, proof, [s, t])
        assert data[:2] == [[encode(a, [s, t]) for a in context], encode(expected_goal, [s, t])]
        if additional is not None:
            assert additional.check(data)
        encoded = json.dumps(data, separators=(",", ":"), ensure_ascii=True) + "\n"
        path = out / (name + ".json")
        path.write_text(encoded)
        result = {"name": name, "statement": description,
                  "file": str(path.relative_to(ROOT)), "accepted": True,
                  "bytes": len(encoded.encode()),
                  "sha256": hashlib.sha256(encoded.encode()).hexdigest(),
                  "seconds": round(time.perf_counter() - before, 4),
                  "inlined_lemmas": dependencies,
                  **structural_stats(data)}
        records.append(result)
        print(json.dumps({k: result[k] for k in ("name", "accepted", "bytes", "seconds")}), flush=True)
    summary = {
        "python": platform.python_version(),
        "all_certificates_self_contained": True,
        "reference_checker": "vendor/checker.py",
        "additional_checker": str(args.checker) if args.checker else None,
        "total_seconds": round(time.perf_counter() - start, 4),
        "certificates": records,
        "lemma_dependencies": {name: sorted(LEMMAS[name]["dependencies"]) for name in ORDER},
    }
    (ROOT / "results.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"accepted": len(records), "total_bytes": sum(r["bytes"] for r in records),
                      "seconds": summary["total_seconds"]}), flush=True)


if __name__ == "__main__":
    main()
