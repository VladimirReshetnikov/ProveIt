"""Check the stored arithmetic certificates without running their generator.

Checks the original unary checker and, after explicit untrusted expansion,
the separately implemented compact checker.  --checker additionally checks
the candidate implementation.  Neither proof builder nor generator is used
to construct or replace the stored expected sequents in this verification.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "vendor" / "validation"))
import translate


def load_checker(path):
    spec = importlib.util.spec_from_file_location("additional_arithmetic_checker", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checker", type=Path)
    parser.add_argument("--save-expanded", action="store_true")
    args = parser.parse_args()
    candidate = load_checker(args.checker) if args.checker else None
    manifest = json.loads((ROOT / "results.json").read_text())
    results = []
    for item in manifest["certificates"]:
        start = time.perf_counter()
        path = ROOT / item["file"]
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == item["sha256"]
        data = json.loads(raw)
        assert translate.kernel.check(data)
        if candidate is not None:
            assert candidate.check(data)
        expanded = translate.certificate(data)
        assert expanded["assumptions"] == [translate.syntax(a) for a in data[0]]
        assert expanded["goal"] == translate.syntax(data[1])
        # certificate() has already run the independent compact checker.
        encoded = (json.dumps(expanded, separators=(",", ":")) + "\n").encode()
        if args.save_expanded:
            directory = ROOT / "expanded_certificates"
            directory.mkdir(exist_ok=True)
            (directory / path.name).write_bytes(encoded)
        record = {
            "name": item["name"],
            "unary_accepted": True,
            "independent_compact_accepted": True,
            "candidate_accepted": True if candidate else None,
            "native_sha256": item["sha256"],
            "expanded_sha256": hashlib.sha256(encoded).hexdigest(),
            "expanded_bytes": len(encoded),
            "seconds": round(time.perf_counter() - start, 4),
        }
        results.append(record)
        print(json.dumps(record), flush=True)
    output = {
        "count": len(results),
        "reference_unary": "vendor/checker.py",
        "independent_compact": "vendor/validation/baseline_checker.py",
        "untrusted_translator": "vendor/validation/translate.py",
        "candidate": str(args.checker) if args.checker else None,
        "candidate_sha256": hashlib.sha256(args.checker.read_bytes()).hexdigest() if args.checker else None,
        "results": results,
    }
    (ROOT / "verification_results.json").write_text(json.dumps(output, indent=2) + "\n")
    print(f"PASS: {len(results)} self-contained arithmetic certificates", flush=True)


if __name__ == "__main__":
    main()
