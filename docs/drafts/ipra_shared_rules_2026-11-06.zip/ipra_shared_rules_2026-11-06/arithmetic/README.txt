SUBSTANTIVE ARITHMETIC CERTIFICATES FOR THE UNARY iPRA CALCULUS

This directory supplies eleven self-contained finite proof certificates.
They use only the six existing proof tags: hyp, pi, use, pack, rec, nat.
No new trusted inference rule, arithmetic oracle, or theorem-reference
instruction is introduced. The theory and six tags are inherited from the
ipra_unary_existential_2026-11-06 proposal in VladimirReshetnikov/ProveIt.

NEW WORK

generate.py constructs explicit proof trees for subtraction cancellation,
the diagonal equations, the residual identity, and both directions of the
equality detector. The mathematical arguments are inherited from the
drafts; the complete executable certificates for these arguments are the
additional evidence provided here.

The definitions are finite expanding numerical term abbreviations:

  p(n)       = R(n,0; u,k.k)
  Q(n,a)     = R(n,a; u,k.k)
  a+n        = R(n,a; u,k.S(u))
  d(a,n)     = R(n,a; u,k.p(u))
  C(n,a,b)   = R(n,a; u,k.b)
  epsilon(s,t) = Q(d(S(s),t),1), where 1=S(0).

Each occurrence expands to a finite recursion term. There are no opaque
function constants in the exported certificates.

VERIFIED STATEMENTS

  zero_plus:                   0+s=s
  successor_plus:              S(s)+t=S(s+t)
  zero_diff:                   d(0,s)=0
  diff_cancel:                 d(S(s),S(t))=d(s,t)
  diff_diagonal:               d(s,s)=0
  diff_successor_diagonal:     d(S(s),s)=1
  residual:                   C(d(s,t),s,t+d(s,t))=s
  q_zero_implies_one:          Q(s,1)=0 |- s=1
  one_residual_implies_equal:  d(S(s),t)=1 |- s=t
  epsilon_zero_implies_equal:  epsilon(s,t)=0 |- s=t
  equal_implies_epsilon_zero:  s=t |- epsilon(s,t)=0

The first seven sequents have empty assumption lists. The final four
have exactly the displayed arithmetic assumption. Variables s,t are free
numerical parameters (de Bruijn slots 0,1); their universal closures follow
using the stated logical rules. No auxiliary lemma remains an assumption.

FIXED PARAMETERS

In cancellation, induction varies the second subtraction counter while the
first argument is fixed. In the residual lemma, induction varies n while y
is fixed. Its successor proof splits the term d(y,n) by applying numerical
cases to a FRESH template variable x in d(y,n)=x -> goal. Consequently the
retained induction hypothesis may mention d(y,n), and it is never applied
at a different value of y. The relevant freshness is enforced by the
ordinary binder-shifting rules of the checker, not by a trusted macro.

PROOF SIZE

Auxiliary theorems are universally quantified formulas. They are used as
hypotheses inside the generator and then discharged with explicit
implication introduction/elimination. This is an untrusted proof-construction
technique. The final JSON proof trees contain all lemma proofs in full.
All eleven certificates together occupy 51,043 bytes. The largest, the
forward equality-detector direction, occupies 13,918 bytes.

REPRODUCTION

Python 3.10 or later is required. Run from any working directory:

  python3 generate.py
  python3 verify.py

To additionally check with a compatible candidate implementation:

  python3 verify.py --checker /absolute/path/to/checker.py

To keep the independent compact-checker expansions:

  python3 verify.py --save-expanded

The stored native certificates can be checked individually with either
the original unary checker or the compatible candidate checker. The
independent compact checker accepts the explicitly translated certificates.

FILES AND TRUST BOUNDARY

  generate.py                    New untrusted arithmetic proof generator.
  certificates/*.json            Complete native finite proof certificates.
  results.json                   Sizes, hashes, exact proof counts, dependencies.
  verify.py                      Rechecks stored bytes and both implementations.
  verification_results.json      Per-certificate verification results.
  expanded_certificates/*.json   Complete independent-checker expansions.
  provenance.json                Attribution and hashes of unchanged vendor files.
  vendor/checker.py              Frozen original unary checker.
  vendor/validation/builder.py   Frozen original untrusted named proof builder.
  vendor/validation/translate.py Frozen original untrusted proof translator.
  vendor/validation/baseline_checker.py
                                Frozen independent compact checker.

The successful tests are concrete formal derivations of the displayed
sequents in the specified calculi. They do not, by themselves, prove the
metatheory of the checkers or the complete bi-interpretability theorem.
