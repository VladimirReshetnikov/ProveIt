"""Independent focused audit of a frozen iPRA checker.

All expected formulas and certificates below are constructed here from
named syntax. No candidate traversal, scope table, builder, or inference
function is called to construct an expectation. No inherited fixtures or
inherited proof generators are used. This is finite regression evidence,
not a machine-checked correctness proof.

Usage: python3 audit.py CANDIDATE.py [OUTPUT_DIRECTORY]
"""
import copy,hashlib,importlib.util,json,pathlib,subprocess,sys
Z=-1
T=('=',Z,Z)
D=('=',Z,('s',Z))
F=('false',)
FREE=('a','b','c')
EXPECTED_HASH='1cf50915efe8cb60d736b12eb45486e7b64f42a38422dc04340e3b513d8dbd2f'

def eq(a,b):return ('=',a,b)
def s(a):return ('s',a)
def pi(x,a,b):return ('pi',x,a,b)
def ex(x,a):return ('ex',x,a)
def rec(n,a,u,v,h):return ('r',n,a,u,v,h)
def hyp(a):return ('hyp',a)

def encode(a,bound=(),free=FREE):
    """Independent named-to-index conversion with explicit binders."""
    if type(a) is int:
        if a!=Z:raise ValueError('Only zero is an integer in named syntax')
        return Z
    if type(a) is str:
        return bound.index(a) if a in bound else len(bound)+free.index(a)
    tag=a[0]
    if tag=='false':return ['false']
    if tag=='s':return ['s',encode(a[1],bound,free)]
    if tag=='=':return ['=',encode(a[1],bound,free),encode(a[2],bound,free)]
    if tag=='r':
        _,n,z,u,v,h=a
        return ['r',encode(n,bound,free),encode(z,bound,free),encode(h,(u,v)+bound,free)]
    if tag=='pi':
        _,x,g,b=a
        return ['pi',encode(g,(x,)+bound,free),encode(b,(x,)+bound,free)]
    if tag=='ex':
        _,x,b=a
        return ['ex',encode(b,(x,)+bound,free)]
    raise ValueError('Unknown named expression')

def replace(a,name,image):
    if type(a) is str:return image if a==name else a
    if type(a) is int:return a
    tag=a[0]
    if tag=='false':return a
    if tag=='s':return s(replace(a[1],name,image))
    if tag=='=':return eq(replace(a[1],name,image),replace(a[2],name,image))
    if tag=='r':
        _,n,z,u,v,h=a
        return rec(replace(n,name,image),replace(z,name,image),u,v,h if name in (u,v) else replace(h,name,image))
    if tag=='pi':
        _,x,g,b=a
        return a if x==name else pi(x,replace(g,name,image),replace(b,name,image))
    if tag=='ex':
        _,x,b=a
        return a if x==name else ex(x,replace(b,name,image))
    raise ValueError('Unknown expression')

def proof(p,bound=()):
    tag=p[0]
    if tag=='hyp':return ['hyp',encode(p[1],bound)]
    if tag=='pi':
        _,x,a,q=p
        return ['pi',encode(a,(x,)+bound),proof(q,(x,)+bound)]
    if tag=='pack':
        _,x,t,q=p
        return ['pack',encode(t,bound),proof(q,(x,)+bound)]
    if tag=='use_pi':
        _,p,t,q=p
        return ['use',proof(p,bound),encode(t,bound),proof(q,bound)]
    if tag=='use_eq':
        _,p,x,a,q=p
        return ['use',proof(p,bound),encode(a,(x,)+bound),proof(q,bound)]
    if tag=='use_ex':
        _,p,a,x,q=p
        return ['use',proof(p,bound),encode(a,bound),proof(q,(x,)+bound)]
    if tag=='rec':return ['rec',encode(p[1],bound)]
    if tag=='nat':return ['nat',encode(p[2],(p[1],)+bound)]
    raise ValueError('Unknown named proof')

def numerical(z,p,force_induction=False):
    base=replace(p,z,Z)
    h=replace(p,z,'y') if p[0]=='=' or force_induction else base
    return pi('x',base,pi('dummy',pi('y',h,replace(p,z,s('y'))),replace(p,z,'x')))

def main():
    candidate=pathlib.Path(sys.argv[1]).resolve()
    out=pathlib.Path(sys.argv[2]).resolve() if len(sys.argv)>2 else pathlib.Path(__file__).resolve().parent
    out.mkdir(parents=True,exist_ok=True)
    fixtures=out/'fixtures';fixtures.mkdir(exist_ok=True)
    data=candidate.read_bytes();digest=hashlib.sha256(data).hexdigest()
    if digest!=EXPECTED_HASH:raise ValueError('Candidate changed; inspect and update the audit boundary explicitly')
    frozen=out/'checker_under_audit.py';frozen.write_bytes(data)
    spec=importlib.util.spec_from_file_location('candidate_under_independent_audit',frozen)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    cases=[]
    def add(name,g,a,p,expected=True,risk=''):
        cases.append((name,[[encode(b) for b in g],encode(a),proof(p)],expected,risk))
    def raw(name,record,expected=False,risk=''):
        cases.append((name,copy.deepcopy(record),expected,risk))

    ab=eq('a','b');a0=eq('a',Z)
    add('hyp_context_identity',[ab],ab,hyp(ab),risk='Validated stored hypothesis')
    add('pi_context_shift',[a0],pi('x',T,a0),('pi','x',T,hyp(a0)),risk='Shift retained free parameter under binder')
    add('reject_pi_context_capture',[a0],pi('x',T,a0),('pi','x',T,hyp(eq('x',Z))),False,'Retained parameter must not become eigenvariable')
    target=pi('x',eq('x','a'),pi('y',eq('y','x'),ab))
    p=('pi','x',eq('x','a'),('pi','y',eq('y','x'),hyp(ab)))
    add('nested_pi_context_shift',[ab],target,p,risk='Two successive shifts')
    principal=pi('x',T,ex('y',eq('x','y')))
    add('pi_use_nested_existential',[principal,T],ex('y',eq('a','y')),('use_pi',hyp(principal),'a',hyp(T)),risk='Witness substituted beneath existential binder')
    add('reject_pi_use_capture',[principal,T],ex('y',eq('y','y')),('use_pi',hyp(principal),'a',hyp(T)),False,'Wrong captured witness result')
    principal=pi('x',T,eq(rec('x','a','u','v',rec('v','u','w','z',s('x'))),'b'))
    rhs=eq(rec(s('b'),'a','u','v',rec('v','u','w','z',s(s('b')))),'b')
    add('pi_use_nested_recursion',[principal,T],rhs,('use_pi',hyp(principal),s('b'),hyp(T)),risk='Simultaneous one- and two-slot binders')

    fa=ex('x',eq('a','x'));fb=ex('x',eq('b','x'));template=ex('x',eq('slot','x'))
    add('transport_under_existential',[ab,fa],fb,('use_eq',hyp(ab),'slot',template,hyp(fa)),risk='Equality template binder capture')
    add('reject_transport_capture',[ab,fa],ex('x',eq('x','x')),('use_eq',hyp(ab),'slot',template,hyp(fa)),False,'Invalid captured output')
    complex_template=pi('x',eq('x','slot'),ex('y',eq(rec('y','slot','u','v',rec('v','u','w','z',s('slot'))),'x')))
    ca=replace(complex_template,'slot','a');cb=replace(complex_template,'slot','b')
    add('transport_under_mixed_binders',[ab,ca],cb,('use_eq',hyp(ab),'slot',complex_template,hyp(ca)),risk='Transport through Pi/ex/nested rec')

    add('pack_own_witness_equation',[],ex('x',eq('x','a')),('pack','x','a',hyp(eq('x','a'))),risk='Shared pack context construction')
    add('pack_retained_context',[ab],ex('x',ab),('pack','x',Z,hyp(ab)),risk='Pack retains shifted assumptions')
    ea=ex('x',eq('x','a'))
    add('ex_use_retained_context',[ea,ab],ab,('use_ex',hyp(ea),ab,'fresh',hyp(ab)),risk='Existential elimination eigenvariable boundary')
    add('reject_ex_witness_escape',[ea],ab,('use_ex',hyp(ea),ab,'fresh',hyp(eq('fresh','a'))),False,'Eigenvariable cannot become an ambient parameter')

    update=rec('v','u','w','z',s('a'))
    rzero=rec(Z,'a','u','v',update)
    add('rec_base_with_nested_body',[],eq(rzero,'a'),('rec',rzero),risk='Unused update body still validated')
    rs=rec(s('b'),'a','u','v',update)
    rb=rec('b','a','u','v',update)
    computed=replace(replace(update,'u',rb),'v','b')
    add('rec_step_nested_simultaneous',[],eq(rs,computed),('rec',rs),risk='Two simultaneous slots; nested update captures neither')
    open_rec=rec('b','a','u','v',update)
    add('reject_open_rec_counter',[],eq(open_rec,'a'),('rec',open_rec),False,'An open counter is not a computation redex')
    nonsucc=rec(rec(Z,Z,'u','v','u'),'a','w','z','w')
    add('reject_computationally_zero_counter',[],eq(nonsucc,'a'),('rec',nonsucc),False,'Checker has no implicit evaluator')
    wrong=replace(computed,'a','c')
    add('reject_rec_step_wrong_parameter',[],eq(rs,wrong),('rec',rs),False,'Retained recursion parameter changed')

    numerical_cases=[('atomic',eq(rec('n','a','u','v',s('u')),'n')),
                     ('existential',ex('w',eq('n','w'))),
                     ('pi',pi('w',eq('w','n'),eq(rec('n','a','u','v','v'),'w'))),
                     ('nested_false',ex('w',pi('z',F,eq('n','a'))))]
    for label,body in numerical_cases:
        add('nat_'+label,[],numerical('n',body),('nat','n',body),risk='Independent named construction of numerical schema')
        if body[0]!='=':
            add('reject_full_induction_'+label,[],numerical('n',body,True),('nat','n',body),False,'Non-equational template may receive cases only')

    add('false_alias_hypothesis',[F],D,hyp(F),risk='Whole-certificate falsity canonicalization')
    add('false_alias_pi',[],pi('x',D,D),('pi','x',F,hyp(F)),risk='Alias in binder annotation and hypothesis key')
    add('false_alias_pack',[F],ex('x',D),('pack','x',Z,hyp(F)),risk='Falsity inside existential body')
    nested_false=ex('x',pi('y',F,F));canonical_false=ex('x',pi('y',D,D))
    add('false_alias_nested_context',[nested_false],canonical_false,hyp(nested_false),risk='Aliases under multiple formula binders')
    false_template=ex('x',pi('y',F,eq('slot','x')))
    fca=replace(false_template,'slot','a');fcb=replace(false_template,'slot','b')
    add('false_alias_transport',[ab,fca],fcb,('use_eq',hyp(ab),'slot',false_template,hyp(fca)),risk='Alias conversion within equality template')

    valid=[[["=",0,0]],["=",0,0],["hyp",["=",0,0]]]
    for value,label in [(False,'bool'),(0.0,'float')]:
        bad=copy.deepcopy(valid);bad[2][1]=['=',value,value]
        raw('reject_'+label+'_hyp_key',bad,risk='Strict key formation before Python equality lookup')
        bad=copy.deepcopy(valid);bad[0][0]=['=',value,value]
        raw('reject_'+label+'_context',bad,risk='No Python bool/int or float/int conflation in terms')
    raw('reject_boolean_witness',[[],['ex',['=',0,1]],['pack',False,['hyp',['=',0,False]]]],risk='Shared pi/pack branch retains term sort')
    raw('reject_formula_as_witness',[[],['ex',['=',-1,-1]],['pack',['=',-1,-1],['hyp',['=',-1,-1]]]],risk='Shared introduction branch must not permit formula witness')
    raw('reject_term_as_pi_guard',[[],['pi',['=',-1,-1],['=',-1,-1]],['pi',-1,['hyp',['=',-1,-1]]]],risk='Shared introduction branch must require formula guard')
    raw('reject_false_as_term',[[],['ex',['=',0,1]],['pack',['false'],['hyp',['=',0,['false']]]]],risk='Public falsity is a formula alias only')
    raw('reject_false_rec_body',[[],['=',['r',-1,-1,['false']],-1],['rec',['r',-1,-1,['false']]]],risk='Base computation must validate unused body')
    for name,bad in [('successor_arity',['s',-1,-1]),('recursor_arity',['r',-1,-1]),('negative_index',-2),('boolean_body',True)]:
        r=['r',-1,-1,bad]
        raw('reject_'+name,[[],['=',r,-1],['rec',r]],risk='Dead recursion body formation')
    for name,goal in [('equality_arity',['=',-1]),('pi_arity',['pi',['=',-1,-1]]),('ex_arity',['ex',['=',-1,-1],['=',-1,-1]]),('unknown_constructor',['and',['=',-1,-1],['=',-1,-1]])]:
        raw('reject_'+name,[[goal],goal,['hyp',goal]],risk='Complete typed signature validation')
    raw('reject_extra_pi_proof_field',[[],['pi',['=',-1,-1],['=',-1,-1]],['pi',['=',-1,-1],['hyp',['=',-1,-1]],0]],risk='Proof arity exact')
    raw('reject_extra_pack_proof_field',[[],['ex',['=',0,-1]],['pack',-1,['hyp',['=',0,-1]],0]],risk='Shared proof arity exact')
    raw('reject_missing_pack_body',[[],['ex',['=',0,-1]],['pack',-1]],risk='Shared proof arity exact')
    raw('reject_nonlist_context',[{},['=',-1,-1],['hyp',['=',-1,-1]]],risk='Context envelope shape')
    raw('reject_extra_envelope_field',valid+[0],risk='Certificate envelope shape')
    raw('reject_closed_false',[[],['false'],['hyp',['false']]],risk='No context-free contradiction by hypothesis')

    errors=(ValueError,TypeError,IndexError,KeyError,RecursionError,OSError)
    results=[];failures=[]
    for name,record,expected,risk in cases:
        text=json.dumps(record,ensure_ascii=False,separators=(',',':'))+'\n'
        path=fixtures/(name+'.json');path.write_text(text)
        exception=None
        try:got=m.check(record)==True
        except errors as exc:got=False;exception=type(exc).__name__
        result={'name':name,'expected_accept':expected,'actual_accept':got,'risk':risk,'sha256':hashlib.sha256(text.encode()).hexdigest(),'exception':exception}
        results.append(result)
        if got!=expected:failures.append(result)
    # Ordinary and -O CLI behavior is sampled at the changed branch boundaries.
    cli=[]
    names={'pi_context_shift','pack_own_witness_equation','rec_step_nested_simultaneous','nat_existential','false_alias_transport','reject_bool_hyp_key','reject_term_as_pi_guard','reject_full_induction_existential','reject_open_rec_counter'}
    for row in results:
        if row['name'] not in names:continue
        for optimized in (False,True):
            args=[sys.executable]+(['-O'] if optimized else [])+[str(frozen),str(fixtures/(row['name']+'.json'))]
            p=subprocess.run(args,capture_output=True,text=True,timeout=10)
            ok=p.returncode==(0 if row['expected_accept'] else 1) and p.stdout.strip()==('ACCEPT' if row['expected_accept'] else 'REJECT') and p.stderr==''
            cli.append({'name':row['name'],'optimized':optimized,'returncode':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr,'ok':ok})
            if not ok:failures.append(cli[-1])
    result={'status':'passed' if not failures else 'FAILED','candidate_sha256':digest,'audit_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'construction':'Independent named syntax, expected schema and hand-specified derivations; no candidate/inherited helpers for expectations.','counts':{'certificates':len(results),'accept':sum(x['expected_accept'] for x in results),'reject':sum(not x['expected_accept'] for x in results),'cli_invocations':len(cli)},'results':results,'cli':cli,'failures':failures}
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('results','cli')},indent=2))
    if failures:raise SystemExit(1)
if __name__=='__main__':main()
