"""Compile report.tex to report.pdf, retaining a reproducible build log."""

from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent


def main():
    (ROOT / "build").mkdir(exist_ok=True)
    (ROOT / "results").mkdir(exist_ok=True)
    command = ["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
               "-outdir=build", "report.tex"]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    (ROOT / "results/latex_build.log").write_text(result.stdout + result.stderr)
    if result.returncode:
        print(result.stdout)
        print(result.stderr)
        raise SystemExit(result.returncode)
    shutil.copy2(ROOT / "build/report.pdf", ROOT / "report.pdf")
    print("Created report.pdf")


if __name__ == "__main__":
    main()
