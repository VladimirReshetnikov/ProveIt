A SMALLER COMPLETE KERNEL FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
6 November 2026

START HERE

  report.pdf      Complete mathematical report, comparisons, and checker listing.
  report.tex      LaTeX source; all included sections and tables are present.
  checker.py      Entire trusted certificate acceptance program.
  reproduce.py    Offline remeasurement, tests, and arithmetic cross-checks.

RESULT

The calculus presents full first-order intuitionistic PRA with all fixed
primitive-recursive descriptions and quantifier-free induction. Its
ordinary first-order realization is bi-interpretable with that reference
theory on the whole number domain; both composites have the internally
definable identity isomorphism. Genuine falsity is explicitly represented
by 0 = S0. See the report for the full rules and interpretation proofs.

The new complete checker has 780 normalized tokens, 782 source tokens,
832 executable AST nodes, 2536 normalized bytes, and 2670 raw bytes.
The expanded inspected frontier is 796 / 796 / 839 / 2547 / 2848,
respectively, attained by a canonical-only checker inside one archive.
The candidate retains public ["false"] and strict hypothesis-key syntax.

This is a modest, reproducible implementation improvement. The underlying
unary-existential/formula-amalgamation calculus is inherited and credited.
No claim of an absolute shortest possible proof checker is made.

PINNED BASELINE

  https://github.com/VladimirReshetnikov/ProveIt
  commit 046c84aa5e99f3a437e5bc6873af9f9a1cc797a5
  directory docs/drafts

All six current archive identities are recorded in SOURCE_PROVENANCE.json.
comparison/inventory.json records 448 Python-source occurrences, 109
distinct standalone checkers, 74 overlapping historical dependency groups,
and the 145 exact source files needed for their measurement. Required
custom imports are charged. Older component-only counts are not silently
treated as complete checkers. The optional canonical-only minimum is
identified explicitly because its input interface is narrower.

RUN THE CHECKER

Python 3.10+; only the standard library is needed.

  python3 checker.py arithmetic/certificates/zero_plus.json

The output is ACCEPT with exit code 0, or REJECT with exit code 1.
It accepts one JSON file with [context, conclusion, proof]. Read FORMAT.txt
for the exact syntax. Error messages are intentionally not part of the
wire contract. Resource exhaustion rejects; mathematical completeness
refers to the recursive algorithm with sufficient resources.

REPRODUCE ALL REPORTED SOFTWARE EVIDENCE

  python3 reproduce.py

Use Python 3.12.14 for the exact recorded measurements. Other Python
versions may normalize syntax differently; the checker itself uses 3.10+.

Do not run the test drivers with -O: some inherited untrusted test helpers
use Python assertions. The trusted checker itself has no assertions, and
its CLI is tested in both ordinary and -O modes.

To compile the PDF as well, install a conventional TeX Live distribution
with latexmk and run:

  python3 reproduce.py --pdf

Or compile just the report:

  python3 build.py

Tests update result logs and regenerate deterministic certificates where
appropriate. SHA256SUMS.txt describes the delivered snapshot; it is not a
promise that timing-bearing logs stay identical after a reproduction run.

SUPPORTING MATERIAL

  comparison/              Frozen programs, dependency inventory, measurements.
  comparison/ablation/     Sequential complete-checker variants and size deltas.
  validation/audit.py      Inherited regression plus fresh binding/rejection audit.
  validation/inherited/    Frozen fixtures from the shared-traversal proposal.
  validation/independent/  Separately written targeted named-syntax audit.
  validation/mathematical_audit.txt
                           Independent mathematical and source-code review.
  arithmetic/              Eleven inherited self-contained arithmetic proofs,
                           original untrusted generator, and reference checkers.
  results/                 Reproduction summary, tables, and LaTeX build log.

Arithmetic certificates cover subtraction cancellation, diagonal laws,
the residual identity, and both directions of the equality detector.
They are accepted by the new checker and cross-checked after explicit
translation by a separately implemented compact checker. Their assumptions
and conclusions are independently compared with the declared sequents.

The inherited arithmetic directory is copied from the unified-kernel draft.
Its original README's descriptions of "new work" refer to that earlier
iteration. The current package credits this material and rechecks it.
SOURCE_PROVENANCE.json retains original source identities and adaptations.

EVIDENCE LIMIT

The general mathematical results are proved in the report and reviewed
independently. The Python implementation and bi-interpretation theorem
are not formally verified in Lean or Rocq here. Finite tests are evidence
for implementation correctness and are not substituted for those proofs.
