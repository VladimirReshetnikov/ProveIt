"""Reproduce the frozen comparison and finite checker evidence offline.

The checker and audits use Python 3.10+ and its standard library.
Use Python 3.12.14 to reproduce the exact recorded source measurements.
Run the test driver without -O.
Use --pdf to compile the report afterwards (requires LaTeX/latexmk).
"""

import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    results = ROOT / "results"
    results.mkdir(exist_ok=True)
    jobs = [
        ("comparison", ["comparison/remeasure.py", "checker.py"]),
        ("ablation", ["comparison/ablation/reproduce.py"]),
        ("regression_and_binding", ["validation/audit.py", "checker.py",
         "--inherited", "validation/inherited", "--out", "validation/results"]),
        ("independent_audit", ["validation/independent/audit.py", "checker.py",
         "validation/independent"]),
        ("arithmetic", ["arithmetic/verify.py", "--checker", "checker.py",
         "--save-expanded"]),
    ]
    log = []
    for name, arguments in jobs:
        run = subprocess.run([sys.executable, *arguments], cwd=ROOT,
                             capture_output=True, text=True)
        log.append({"name": name, "returncode": run.returncode,
                    "stdout": run.stdout, "stderr": run.stderr})
        (results / "reproduction_log.json").write_text(
            json.dumps(log, indent=2) + "\n")
        if run.returncode:
            print(run.stdout, end="")
            print(run.stderr, file=sys.stderr, end="")
            raise SystemExit(run.returncode)
        print(name + ": passed", flush=True)

    comparison = json.loads((ROOT / "comparison/remeasured.json").read_text())
    regression = json.loads((ROOT / "validation/results/results.json").read_text())
    independent = json.loads((ROOT / "validation/independent/results.json").read_text())
    arithmetic = json.loads((ROOT / "arithmetic/verification_results.json").read_text())
    if not all(comparison["strict_below_expanded"].values()):
        raise ValueError("Candidate does not beat every measured coordinate")
    if regression["failures"] or independent["failures"]:
        raise ValueError("An audit reported a failure")
    summary = {
        "status": "passed",
        "python": platform.python_version(),
        "checker_sha256": hashlib.sha256((ROOT / "checker.py").read_bytes()).hexdigest(),
        "measurement": comparison["candidate"],
        "strict_below_expanded": comparison["strict_below_expanded"],
        "ablation_stages_verified": 10,
        "regression_counts": regression["counts"],
        "independent_counts": independent["counts"],
        "arithmetic_certificates": arithmetic["count"],
        "arithmetic_all_candidate_and_reference_accept": all(
            r["candidate_accepted"] and r["unary_accepted"]
            and r["independent_compact_accepted"] for r in arithmetic["results"]),
        "qualification": "Finite regression and cross-checking evidence, not a machine-checked metatheorem.",
    }
    (results / "verification_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    if args.pdf:
        subprocess.run([sys.executable, "build.py"], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
