Verification artifacts for the shifted index-filter presentation
================================================================

Run with Python 3.10 or newer and no third-party dependencies:

    python3 check_filter_axioms.py --output verification_summary.json

The script is standalone. It does not import code or results from the six
comparison drafts and does not need network access.

It checks:

1. Literal abstract syntax trees for the new defining equation and shifted
   13-node witness, the unshifted 12-node candidate, the previous base and
   direct/bound steps, and the six principal recurring draft templates.
   Frozen descriptions are charged anew at every call in full counts.
   Active substitutions never alter frozen descriptions.
   The section 7 refinements are also checked with their actual bodies:
   the separated guard, absorbing wrapper, separated one-transition and
   tail-boundary formulas, the autonomous right-computation spelling,
   and the optimized old compiler for the identical induction predicate.

2. The last-success candidate invariant and exact witness equation for all
   binary failure traces at indices 1,...,L, for every L from 1 through 14.
   Index zero is fixed to have filter value zero. The maximum sampled index
   is 14, so the largest complete trace contains 15 entries including zero.

3. Raw non-Boolean test values from {0,1,2,7}, including every such test
   sequence through maximum index 6, and four additional parameterized
   numerical families. Positive values are not silently restricted to one.

4. All possible index-filter assignments on two finite chain segments of
   heights zero through six. The segments serve as finite projections of
   the infinite countermodel described in unshifted_countermodel.txt.

The JSON contains exact case counts and all size formulas. These executable
finite checks do not constitute proof-assistant verification of the
infinite axiomatization or of its bi-interpretability theorem.

The package size comparison allows both the direct recursion step and the
bound-state step used by the drafts. Their coordinatewise minimum need not
be achieved by one actual spelling; using it is favorable to the baseline.

No claim is made that the new witness is shorter than every emitted formula
at every input of every old serializer. For example, a separated base
equation can have six active nodes and is a different logical obligation.
