#!/usr/bin/env python3
"""Standalone finite checks for the shifted index-filter presentation of PRA.

Only Python's standard library is used.  This script checks literal AST sizes,
finite traces, and a finite projection of a described infinite countermodel.
It is not a formal proof of the infinite first-order equivalence theorem.

Run: python3 check_filter_axioms.py --output verification_summary.json
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import product
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()
    descriptor: "Node | None" = None


def var(name: str) -> Node:
    return Node("var:" + name)


ZERO = Node("0")
V, W = var("v"), var("w")
A, N, B, C = (var(name) for name in ("a", "n", "b", "c"))
X, ZPAR = var("x"), var("z")


def succ(term: Node) -> Node:
    return Node("S", (term,))


def chi(left: Node, right: Node) -> Node:
    return Node("chi", (left, right))


def q(left: Node, right: Node) -> Node:
    return Node("Q", (left, right), W)


def zero_mask(left: Node, right: Node) -> Node:
    return Node("Z", (left, right), ZERO)


def call(name: str, body: Node, left: Node, right: Node) -> Node:
    return Node(name, (left, right), body)


def eq(left: Node, right: Node) -> Node:
    return Node("=", (left, right))


def land(left: Node, right: Node) -> Node:
    return Node("and", (left, right))


def implies(left: Node, right: Node) -> Node:
    return Node("implies", (left, right))


def quantify(kind: str, names: tuple[str, ...], formula: Node) -> Node:
    for name in reversed(names):
        formula = Node(kind + ":" + name, (formula,))
    return formula


def witness_quantifiers(formula: Node, parameter: str = "a") -> Node:
    return quantify("forall", (parameter, "n"),
                    quantify("exists", ("b",), formula))


def size(node: Node, full: bool = False) -> int:
    """Every syntax node counts once; full adds each stored descriptor tree."""
    answer = 1 + sum(size(child, full) for child in node.children)
    if full and node.descriptor is not None:
        answer += size(node.descriptor, True)
    return answer


def occurrence_count(node: Node, variable: Node) -> int:
    """Count active occurrences only: a stored descriptor remains frozen."""
    return int(node == variable) + sum(
        occurrence_count(child, variable) for child in node.children)


def substitute(node: Node, mapping: dict[Node, Node]) -> Node:
    if node in mapping:
        return mapping[node]
    return Node(node.tag,
                tuple(substitute(child, mapping) for child in node.children),
                node.descriptor)


def costs(node: Node) -> dict[str, int]:
    return {"active": size(node), "full": size(node, True)}


def old_witnesses(body: Node) -> dict[str, Node]:
    def r(left: Node, right: Node) -> Node:
        return call("R", body, left, right)

    absorbing = eq(r(succ(q(zero_mask(r(succ(succ(B)), A), succ(B)), N)), A), A)
    boundary = land(eq(r(B, A), A),
                    implies(eq(r(succ(B), A), A), eq(B, N)))
    exit_witness = eq(r(q(zero_mask(chi(r(B, A), A), B), N), A), A)
    predecessor_return = eq(r(q(q(chi(r(B, A), A), B), N), A), A)
    predecessor_witness = eq(r(q(zero_mask(r(B, A), B), N), A), A)
    separated = land(eq(r(succ(B), A), A),
                     implies(eq(r(succ(succ(B)), A), A), eq(B, N)))
    return {name: witness_quantifiers(formula) for name, formula in (
        ("absorbing_return", absorbing),
        ("coverage_boundary", boundary),
        ("exit_witness", exit_witness),
        ("predecessor_return", predecessor_return),
        ("predecessor_witness", predecessor_witness),
        ("separated_recursion", separated))}


def construction_formulas(tail: Node) -> dict[str, Node]:
    body = zero_mask(tail, V)

    def d(left: Node, right: Node) -> Node:
        return call("D", body, left, right)

    def r(left: Node, right: Node) -> Node:
        return call("R", body, left, right)

    definition = quantify("forall", ("x", "z"),
                          eq(d(X, ZPAR), substitute(body, {V: X, W: ZPAR})))
    shifted = witness_quantifiers(
        eq(d(q(d(succ(B), ZPAR), N), ZPAR), ZERO), "z")
    unshifted = witness_quantifiers(
        eq(d(q(d(B, ZPAR), N), ZPAR), ZERO), "z")
    base = quantify("forall", ("a",), eq(r(ZERO, A), A))
    direct_step = quantify("forall", ("a", "n"),
                           eq(r(succ(N), A),
                              substitute(body, {V: r(N, A), W: N})))
    bound_step = quantify("forall", ("a", "n", "c"),
                          implies(eq(r(N, A), C),
                                  eq(r(succ(N), A),
                                     substitute(body, {V: C, W: N}))))
    right_computation = quantify("forall", ("a", "n"),
                                 land(eq(r(ZERO, A), A),
                                      eq(r(succ(N), A),
                                         r(N, substitute(body, {V: A, W: ZERO})))))
    result = {"filter_definition": definition,
              "filter_shifted_13": shifted,
              "filter_unshifted_12": unshifted,
              "latch_base": base,
              "latch_direct_step": direct_step,
              "latch_bound_step": bound_step,
              "latch_right_computation": right_computation}
    result.update(old_witnesses(body))
    return result


def reported_refinement_formulas(tail: Node) -> tuple[dict[str, Node], dict[str, Node]]:
    """Build the actual wrappers and optimized identical-predicate old body.

    These are literal formulas copied into this independent checker, not
    imported counts or executable code from any draft.
    """
    separated_body = q(zero_mask(chi(W, ZERO), succ(tail)), V)
    predecessor = q(V, ZERO)
    absorbing_inner = zero_mask(chi(V, ZERO), zero_mask(tail, succ(predecessor)))
    absorbing_body = q(zero_mask(chi(W, ZERO), succ(absorbing_inner)), V)
    old_predicate_test = substitute(tail, {V: W, W: q(V, ZERO)})
    optimized_old_body = zero_mask(chi(old_predicate_test, ZERO), V)

    def guarded_r(left: Node, right: Node) -> Node:
        return call("R", separated_body, left, right)

    exposed_tail = substitute(tail, {V: A, W: succ(B)})
    selected_index = q(zero_mask(chi(exposed_tail, A), succ(B)), N)
    one_transition = witness_quantifiers(eq(guarded_r(succ(selected_index), A), A))
    tail_boundary = witness_quantifiers(
        land(eq(guarded_r(succ(B), A), A),
             implies(eq(exposed_tail, A), eq(B, N))))
    bodies = {"separated_guard": separated_body,
              "absorbing_wrapper": absorbing_body,
              "same_predicate_optimized_old_body": optimized_old_body}
    formulas = {
        "separated_boundary_actual_guard":
            old_witnesses(separated_body)["separated_recursion"],
        "separated_one_transition_actual_guard": one_transition,
        "separated_tail_boundary_actual_guard": tail_boundary,
        "absorbing_return_actual_wrapper":
            old_witnesses(absorbing_body)["absorbing_return"],
        "same_predicate_optimized_old_witness":
            old_witnesses(optimized_old_body)["predecessor_witness"],
    }
    return bodies, formulas


def sample_tails() -> list[Node]:
    tails = {ZERO, V, W, chi(V, W), zero_mask(W, V), q(V, W)}
    for depth in range(9):
        s = V
        for _ in range(depth):
            s = succ(s)
        tails.update((s, succ(s), chi(s, W), zero_mask(s, W), q(s, W),
                      call("R", s, V, W),
                      call("R", zero_mask(s, V), V, W)))
    return sorted(tails, key=repr)


def ast_checks() -> dict:
    templates = {
        "absorbing_return": (18, 20),
        "coverage_boundary": (19, 19),
        "exit_witness": (16, 18),
        "predecessor_return": (16, 18),
        "predecessor_witness": (14, 16),
        "separated_recursion": (21, 21),
    }
    min_active_saving = None
    min_full_saving = None
    for tail in sample_tails():
        mt, wt = size(tail), size(tail, True)
        body = zero_mask(tail, V)
        mh, wh = size(body), size(body, True)
        ih = occurrence_count(body, V)
        formulas = construction_formulas(tail)
        measured = {name: costs(formula) for name, formula in formulas.items()}
        assert (mh, wh) == (mt + 2, wt + 3)
        assert measured["filter_definition"] == {"active": mt + 8,
                                                  "full": 2 * wt + 12}
        assert measured["filter_shifted_13"] == {"active": 13,
                                                  "full": 14 + 2 * wh}
        assert measured["filter_unshifted_12"] == {"active": 12,
                                                    "full": 13 + 2 * wh}
        assert measured["latch_base"] == {"active": 6, "full": 6 + wh}
        assert measured["latch_direct_step"] == {
            "active": 7 + mh + 2 * ih,
            "full": 7 + 2 * wh + (2 + wh) * ih}
        assert measured["latch_bound_step"] == {
            "active": 14 + mh, "full": 14 + 3 * wh}
        assert measured["latch_right_computation"] == {
            "active": 15 + mh, "full": 15 + 4 * wh}
        for name, (active, full_constant) in templates.items():
            assert measured[name] == {"active": active,
                                      "full": full_constant + 2 * wh}
        j = occurrence_count(tail, W)
        bodies, refinements = reported_refinement_formulas(tail)
        assert costs(bodies["separated_guard"]) == {
            "active": mt + 7, "full": wt + 9}
        assert costs(bodies["absorbing_wrapper"]) == {
            "active": mt + 16, "full": wt + 21}
        assert costs(bodies["same_predicate_optimized_old_body"]) == {
            "active": mt + 2 * j + 4, "full": wt + 3 * j + 5}
        refinement_costs = {name: costs(formula) for name, formula in refinements.items()}
        assert refinement_costs["separated_boundary_actual_guard"] == {
            "active": 21, "full": 39 + 2 * wt}
        assert refinement_costs["separated_one_transition_actual_guard"] == {
            "active": 15 + mt + j, "full": 26 + 2 * wt + j}
        assert refinement_costs["separated_tail_boundary_actual_guard"] == {
            "active": 16 + mt + j, "full": 25 + 2 * wt + j}
        assert refinement_costs["absorbing_return_actual_wrapper"] == {
            "active": 18, "full": 62 + 2 * wt}
        assert refinement_costs["same_predicate_optimized_old_witness"] == {
            "active": 14, "full": 26 + 2 * wt + 6 * j}
        for old_cost in refinement_costs.values():
            assert measured["filter_shifted_13"]["active"] < old_cost["active"]
            assert measured["filter_shifted_13"]["full"] < old_cost["full"]
        new_total = {metric: measured["filter_definition"][metric]
                    + measured["filter_shifted_13"][metric]
                    for metric in ("active", "full")}
        old_envelope = {
            metric: measured["latch_base"][metric]
            + measured["predecessor_witness"][metric]
            + min(measured["latch_direct_step"][metric],
                  measured["latch_bound_step"][metric])
            for metric in ("active", "full")}
        active_saving = old_envelope["active"] - new_total["active"]
        full_saving = old_envelope["full"] - new_total["full"]
        assert active_saving >= 10
        assert full_saving >= 2 * wh + 11
        min_active_saving = min(active_saving, min_active_saving or active_saving)
        min_full_saving = min(full_saving, min_full_saving or full_saving)
    sample = construction_formulas(V)
    return {
        "tail_samples": len(sample_tails()),
        "all_node_count_assertions_passed": True,
        "convention": "Each active node costs one; each frozen body is charged "
                      "again at every call in full counts; binders cost one.",
        "definitions": {"mt": "active tail size", "Wt": "full tail size",
                        "mh": "mt+2", "Wh": "Wt+3",
                        "ih": "active occurrences of first slot in Z(t,v)"},
        "formulas": {
            "filter_definition": {"active": "mt+8", "full": "2*Wt+12"},
            "filter_shifted_13": {"active": "13", "full": "14+2*Wh"},
            "filter_unshifted_12": {"active": "12", "full": "13+2*Wh"},
            "latch_base": {"active": "6", "full": "6+Wh"},
            "latch_direct_step": {"active": "7+mh+2*ih",
                                   "full": "7+2*Wh+(2+Wh)*ih"},
            "latch_bound_step": {"active": "14+mh", "full": "14+3*Wh"},
            "latch_right_computation": {"active": "15+mh", "full": "15+4*Wh"},
            **{name: {"active": str(active), "full": f"{constant}+2*Wh"}
               for name, (active, constant) in templates.items()}},
        "package_comparison": {
            "new": {"active": "mh+19", "full": "20+4*Wh"},
            "old_direct": {"active": "27+mh+2*ih",
                           "full": "29+5*Wh+(2+Wh)*ih"},
            "old_bound": {"active": "34+mh", "full": "36+6*Wh"},
            "old_autonomous_right": {"active": "29+mh", "full": "31+6*Wh"},
            "old_coordinate_envelope_active_saving": "8+min(2*ih,7)",
            "old_coordinate_envelope_full_saving":
                "min(9+Wh+(2+Wh)*ih,16+2*Wh)",
            "minimum_sample_active_saving": min_active_saving,
            "minimum_sample_full_saving": min_full_saving,
            "scope": "Matched raw tail and descriptor accounting; not an "
                     "all-input theorem for the six heterogeneous emitters."},
        "sample_tail_v": {name: costs(formula) for name, formula in sample.items()},
        "reported_refinements": {
            "all_count_and_strict_comparison_assertions_passed": True,
            "j_or_s": "active occurrences of the second slot in the raw tail",
            "separated_guard_body": {"active": "mt+7", "full": "Wt+9"},
            "absorbing_wrapper_body": {"active": "mt+16", "full": "Wt+21"},
            "same_predicate_optimized_old_body": {
                "active": "mt+2*s+4", "full": "Wt+3*s+5"},
            "separated_boundary_actual_guard": {"active": "21", "full": "39+2*Wt"},
            "separated_one_transition_actual_guard": {
                "active": "15+mt+j", "full": "26+2*Wt+j"},
            "separated_tail_boundary_actual_guard": {
                "active": "16+mt+j", "full": "25+2*Wt+j"},
            "absorbing_return_actual_wrapper": {"active": "18", "full": "62+2*Wt"},
            "same_predicate_optimized_old_witness": {
                "active": "14", "full": "26+2*Wt+6*s"},
            "same_predicate_witness_saving": {"active": "1", "full": "6+6*s"},
            "scope": "Exact section 7 syntactic profiles, with actual guards "
                     "and matched raw tails; the same-predicate claim requires "
                     "the report's Boolean compiler correctness theorem."},
    }


def natural_q(x: int, fallback: int) -> int:
    return fallback if x == 0 else x - 1


def natural_z(test: int, value: int) -> int:
    return value if test == 0 else 0


def check_trace(f: tuple[int, ...]) -> int:
    """Check every listed target; c(n)+1<=n for n>0 avoids an extra value."""
    assert len(f) >= 2
    assert f[0] == 0
    assert all(value in (0, index) for index, value in enumerate(f))
    candidate = 0
    checked = 0
    for n in range(len(f)):
        assert candidate <= max(n - 1, 0)
        assert candidate + 1 < len(f)
        assert f[candidate] == 0
        assert f[n] == 0 or f[candidate + 1] != 0
        b = candidate
        selected = natural_q(f[b + 1], n)
        assert f[selected] == 0
        checked += 1
        candidate = n if f[n] == 0 else candidate
    return checked


def trace_checks(max_index: int = 14) -> dict:
    boolean_cases = 0
    boolean_targets = 0
    for last in range(1, max_index + 1):
        for failures in product((False, True), repeat=last):
            f = (0,) + tuple(index if fail else 0
                             for index, fail in enumerate(failures, 1))
            boolean_targets += check_trace(f)
            boolean_cases += 1
    raw_cases = 0
    raw_targets = 0
    alphabet = (0, 1, 2, 7)
    for last in range(1, 7):
        for raw in product(alphabet, repeat=last + 1):
            f = tuple(natural_z(test, index) for index, test in enumerate(raw))
            raw_targets += check_trace(f)
            raw_cases += 1
    parametric_cases = 0
    parametric_targets = 0
    for z in range(10):
        for formula in (
                lambda x, z: (x * x + z) % 7,
                lambda x, z: 0 if x == z else 10 ** 6 + x + z,
                lambda x, z: x * z,
                lambda x, z: 0 if x % (z + 1) == 0 else x + z + 1):
            f = tuple(natural_z(formula(index, z), index) for index in range(65))
            parametric_targets += check_trace(f)
            parametric_cases += 1
    return {
        "all_trace_assertions_passed": True,
        "boolean_traces": {
            "maximum_index": max_index,
            "largest_trace_length_including_index_zero": max_index + 1,
            "cases": boolean_cases,
            "target_and_invariant_checks": boolean_targets,
            "coverage": "All Boolean failure assignments at indices 1..L "
                        "for every L from 1 through 14; f(0)=0 is fixed."},
        "raw_nonboolean_tails": {"alphabet": list(alphabet), "maximum_index": 6,
                                  "cases": raw_cases,
                                  "target_and_invariant_checks": raw_targets},
        "parametric_raw_tails": {"parameters_z": list(range(10)),
                                  "cases": parametric_cases,
                                  "target_and_invariant_checks": parametric_targets},
    }


Point = tuple[int, int]
FOREST_ZERO = (0, 0)


def forest_s(x: Point) -> Point:
    return x[0], x[1] + 1


def forest_q(x: Point, fallback: Point) -> Point:
    if x == FOREST_ZERO:
        return fallback
    if x[1] == 0:
        return FOREST_ZERO
    return x[0], x[1] - 1


def forest_checks(max_height: int = 6) -> dict:
    points = tuple((chain, height) for chain in range(2)
                   for height in range(max_height + 1))
    variable_points = tuple(x for x in points if x != FOREST_ZERO)
    cases = 0
    checks = 0
    for bits in product((False, True), repeat=len(variable_points)):
        failures = {point: fail for point, fail in zip(variable_points, bits)}
        failures[FOREST_ZERO] = False

        def f(point: Point) -> Point:
            return point if failures[point] else FOREST_ZERO

        for target in points:
            if f(target) == FOREST_ZERO:
                witness = FOREST_ZERO
            else:
                witness = next((target[0], height)
                               for height in range(target[1] + 1)
                               if failures[(target[0], height)])
            assert f(forest_q(f(witness), target)) == FOREST_ZERO
            checks += 1
        cases += 1
    root = (1, 0)

    def coverage(x: Point) -> bool:
        return x == FOREST_ZERO or x == forest_s(forest_q(x, FOREST_ZERO))

    assert coverage(FOREST_ZERO)
    assert not coverage(root)
    assert all(coverage(forest_s(point)) for point in points)

    def coverage_filter(x: Point) -> Point:
        return FOREST_ZERO if coverage(x) else x

    assert all(coverage_filter(forest_q(coverage_filter(forest_s(b)), root)) !=
               FOREST_ZERO for b in points)
    return {
        "all_finite_forest_assertions_passed": True,
        "maximum_height": max_height,
        "point_count": len(points),
        "all_index_filter_assignments_with_f_zero_zero": cases,
        "unshifted_witness_target_checks": checks,
        "coverage_has_true_base_and_progress_but_fails_at_junk_root": True,
        "shifted_witness_detects_the_coverage_counterexample": True,
        "scope": "Finite projection checks support the separately supplied "
                 "infinite two-chain model argument; this is not a finite "
                 "model of successor injectivity and nonzeroness."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("verification_summary.json"))
    args = parser.parse_args()
    result = {
        "status": "all_checks_passed",
        "limitations": "Executable finite checks are not proof-assistant "
                       "verification of the infinite axiomatization theorem.",
        "ast": ast_checks(),
        "traces": trace_checks(),
        "unshifted_countermodel": forest_checks(),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(args.output),
                      "tail_samples": result["ast"]["tail_samples"],
                      "trace_cases": result["traces"]["boolean_traces"]["cases"],
                      "trace_targets": result["traces"]["boolean_traces"]
                          ["target_and_invariant_checks"]}, indent=2))


if __name__ == "__main__":
    main()
