/-
  Zero-or-input masks: the abstract kernel of the 13-node witness.

  Checked with Lean 4.19.0 using only its standard library.
  The forward proof is over an arbitrary type and uses no Nat induction.
  The reverse proof formalizes the primitive-recursive scan on Nat.

  This file does NOT formalize the complete generated PRA syntax,
  Boolean compiler, definitional equivalence, or bi-interpretation theorem.
-/

import Std

namespace ZeroInputMask

universe u

structure Kernel (A : Type u) where
  zero : A
  succ : A → A
  q : A → A → A
  q_zero : ∀ a, q zero a = a
  q_succ : ∀ x a, q (succ x) a = x
  separated : zero ≠ succ zero

variable {A : Type u}

/- Optional unshifted variant: partition plus Bit supplies the missing
   separation and coverage. These lemmas do not assume arithmetic induction. -/
theorem partition_separation
    (zero : A) (succ : A → A) (bit : A → A → A)
    (diagonal : ∀ x, bit x x = succ zero)
    (off_diagonal : ∀ x y, x = y ∨ bit x y = zero)
    (partition : ∀ x, ∃ y, bit x zero ≠ bit x (succ y)) :
    zero ≠ succ zero := by
  intro hcollapsed
  obtain ⟨y, hy⟩ := partition zero
  cases off_diagonal zero (succ y) with
  | inl heq => exact hy (congrArg (bit zero) heq)
  | inr hbit =>
      apply hy
      calc
        bit zero zero = succ zero := diagonal zero
        _ = zero := hcollapsed.symm
        _ = bit zero (succ y) := hbit.symm

theorem partition_coverage
    (zero : A) (succ : A → A) (bit : A → A → A)
    (off_diagonal : ∀ x y, x = y ∨ bit x y = zero)
    (partition : ∀ x, ∃ y, bit x zero ≠ bit x (succ y)) :
    ∀ x, x = zero ∨ ∃ y, x = succ y := by
  intro x
  obtain ⟨y, hy⟩ := partition x
  cases off_diagonal x zero with
  | inl heq => exact Or.inl heq
  | inr hzero =>
      cases off_diagonal x (succ y) with
      | inl heq => exact Or.inr ⟨y, heq⟩
      | inr hsucc => exact False.elim (hy (hzero.trans hsucc.symm))

theorem Kernel.succ_ne_zero (K : Kernel A) (x : A) : K.succ x ≠ K.zero := by
  intro h
  have hx : x = K.zero := by
    calc
      x = K.q (K.succ x) K.zero := (K.q_succ x K.zero).symm
      _ = K.q K.zero K.zero := congrArg (fun t => K.q t K.zero) h
      _ = K.zero := K.q_zero K.zero
  have hs : K.succ K.zero = K.zero := hx ▸ h
  exact K.separated hs.symm

/- The existential equation below is the one-parameter witness after
   fixing its numerical parameter.  All hypotheses remain explicit. -/
theorem shifted_mask_extract
    (K : Kernel A) (f : A → A)
    (range : ∀ x, f x = K.zero ∨ f x = x)
    (progress : ∀ x, f x = K.zero → f (K.succ x) = K.zero)
    (witness : ∀ n, ∃ b, f (K.q (f (K.succ b)) n) = K.zero) :
    ∀ n, f n = K.zero := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  cases range (K.succ b) with
  | inl hz =>
      rw [hz, K.q_zero] at hb
      exact hb
  | inr hs =>
      rw [hs, K.q_succ] at hb
      have impossible : K.succ b = K.zero := hs.symm.trans (progress b hb)
      exact False.elim (K.succ_ne_zero b impossible)

theorem unshifted_mask_extract
    (K : Kernel A) (f : A → A)
    (coverage : ∀ x, x = K.zero ∨ ∃ y, x = K.succ y)
    (range : ∀ x, f x = K.zero ∨ f x = x)
    (progress : ∀ x, f x = K.zero → f (K.succ x) = K.zero)
    (witness : ∀ n, ∃ b, f (K.q (f b) n) = K.zero) :
    ∀ n, f n = K.zero := by
  intro n
  obtain ⟨b, hb⟩ := witness n
  cases range b with
  | inl hz =>
      rw [hz, K.q_zero] at hb
      exact hb
  | inr hs =>
      cases coverage b with
      | inl hzero =>
          rw [hs, hzero, K.q_zero] at hb
          exact hb
      | inr hsucc =>
          obtain ⟨c, hc⟩ := hsucc
          rw [hs, hc, K.q_succ] at hb
          have hstate : f (K.succ c) = K.succ c := hc ▸ hs
          have impossible : K.succ c = K.zero :=
            hstate.symm.trans (progress c hb)
          exact False.elim (K.succ_ne_zero c impossible)

theorem induction_from_shifted_mask
    (K : Kernel A) (P : A → Prop) (f : A → A)
    (reflection : ∀ x, f x = K.zero ↔ P x ∨ x = K.zero)
    (range : ∀ x, f x = K.zero ∨ f x = x)
    (witness : ∀ n, ∃ b, f (K.q (f (K.succ b)) n) = K.zero)
    (base : P K.zero)
    (step : ∀ x, P x → P (K.succ x)) :
    ∀ n, P n := by
  have reflect : ∀ x, f x = K.zero → P x := by
    intro x hx
    cases (reflection x).mp hx with
    | inl hp => exact hp
    | inr hzero => exact hzero ▸ base
  have progress : ∀ x, f x = K.zero → f (K.succ x) = K.zero := by
    intro x hx
    exact (reflection (K.succ x)).mpr (Or.inl (step x (reflect x hx)))
  have all_zero := shifted_mask_extract K f range progress witness
  exact fun n => reflect n (all_zero n)

def mask (K : Kernel A) (t : A → A) (x : A) : A := K.q (t x) x

theorem mask_range
    (K : Kernel A) (t : A → A)
    (boolean : ∀ x, t x = K.zero ∨ t x = K.succ K.zero) :
    ∀ x, mask K t x = K.zero ∨ mask K t x = x := by
  intro x
  cases boolean x with
  | inl ht =>
      right
      exact (congrArg (fun a => K.q a x) ht).trans (K.q_zero x)
  | inr ht =>
      left
      exact (congrArg (fun a => K.q a x) ht).trans (K.q_succ K.zero x)

theorem mask_reflection
    (K : Kernel A) (P : A → Prop) (t : A → A)
    (boolean : ∀ x, t x = K.zero ∨ t x = K.succ K.zero)
    (truth : ∀ x, t x = K.succ K.zero ↔ P x) :
    ∀ x, mask K t x = K.zero ↔ P x ∨ x = K.zero := by
  intro x
  cases boolean x with
  | inl ht =>
      have hmask : mask K t x = x :=
        (congrArg (fun a => K.q a x) ht).trans (K.q_zero x)
      have hnot : ¬ P x := by
        intro hp
        exact K.separated (ht.symm.trans ((truth x).mpr hp))
      constructor
      · intro hf
        exact Or.inr (hmask.symm.trans hf)
      · intro hp
        cases hp with
        | inl hp => exact False.elim (hnot hp)
        | inr hx => exact hmask.trans hx
  | inr ht =>
      have hmask : mask K t x = K.zero :=
        (congrArg (fun a => K.q a x) ht).trans (K.q_succ K.zero x)
      constructor
      · intro _
        exact Or.inl ((truth x).mp ht)
      · intro _
        exact hmask

theorem induction_from_boolean_witness
    (K : Kernel A) (P : A → Prop) (t : A → A)
    (boolean : ∀ x, t x = K.zero ∨ t x = K.succ K.zero)
    (truth : ∀ x, t x = K.succ K.zero ↔ P x)
    (witness : ∀ n, ∃ b,
      mask K t (K.q (mask K t (K.succ b)) n) = K.zero)
    (base : P K.zero)
    (step : ∀ x, P x → P (K.succ x)) :
    ∀ n, P n :=
  induction_from_shifted_mask K P (mask K t)
    (mask_reflection K P t boolean truth) (mask_range K t boolean)
    witness base step

/- The primary report uses D_t(x) = Z(t(x), x).  Its Z operation has
   zero/successor equations, and agrees with Q on Boolean first arguments.
   This bridge makes the primary Z-mask formula explicit in the check. -/
structure ZeroMaskOps (K : Kernel A) where
  z : A → A → A
  z_zero : ∀ a, z K.zero a = a
  z_succ : ∀ x a, z (K.succ x) a = K.zero

def maskZ (K : Kernel A) (Z : ZeroMaskOps K) (t : A → A) (x : A) : A :=
  Z.z (t x) x

theorem boolean_maskZ_eq_maskQ
    (K : Kernel A) (Z : ZeroMaskOps K) (t : A → A)
    (boolean : ∀ x, t x = K.zero ∨ t x = K.succ K.zero) :
    ∀ x, maskZ K Z t x = mask K t x := by
  intro x
  cases boolean x with
  | inl ht =>
      have hz : maskZ K Z t x = x :=
        (congrArg (fun a => Z.z a x) ht).trans (Z.z_zero x)
      have hq : mask K t x = x :=
        (congrArg (fun a => K.q a x) ht).trans (K.q_zero x)
      exact hz.trans hq.symm
  | inr ht =>
      have hz : maskZ K Z t x = K.zero :=
        (congrArg (fun a => Z.z a x) ht).trans (Z.z_succ K.zero x)
      have hq : mask K t x = K.zero :=
        (congrArg (fun a => K.q a x) ht).trans (K.q_succ K.zero x)
      exact hz.trans hq.symm

theorem maskZ_range
    (K : Kernel A) (Z : ZeroMaskOps K) (t : A → A)
    (boolean : ∀ x, t x = K.zero ∨ t x = K.succ K.zero) :
    ∀ x, maskZ K Z t x = K.zero ∨ maskZ K Z t x = x := by
  intro x
  rw [boolean_maskZ_eq_maskQ K Z t boolean x]
  exact mask_range K t boolean x

theorem maskZ_reflection
    (K : Kernel A) (Z : ZeroMaskOps K) (P : A → Prop) (t : A → A)
    (boolean : ∀ x, t x = K.zero ∨ t x = K.succ K.zero)
    (truth : ∀ x, t x = K.succ K.zero ↔ P x) :
    ∀ x, maskZ K Z t x = K.zero ↔ P x ∨ x = K.zero := by
  intro x
  rw [boolean_maskZ_eq_maskQ K Z t boolean x]
  exact mask_reflection K P t boolean truth x

theorem induction_from_Z_boolean_witness
    (K : Kernel A) (Z : ZeroMaskOps K) (P : A → Prop) (t : A → A)
    (boolean : ∀ x, t x = K.zero ∨ t x = K.succ K.zero)
    (truth : ∀ x, t x = K.succ K.zero ↔ P x)
    (witness : ∀ n, ∃ b,
      maskZ K Z t (K.q (maskZ K Z t (K.succ b)) n) = K.zero)
    (base : P K.zero)
    (step : ∀ x, P x → P (K.succ x)) :
    ∀ n, P n :=
  induction_from_shifted_mask K P (maskZ K Z t)
    (maskZ_reflection K Z P t boolean truth) (maskZ_range K Z t boolean)
    witness base step

/- Reverse direction: the explicit last-success scan on Nat. -/
def scan (f : Nat → Nat) : Nat → Nat
  | 0 => 0
  | n + 1 => if f n = 0 then n else scan f n

theorem scan_invariant (f : Nat → Nat) (base : f 0 = 0) :
    ∀ n, f (scan f n) = 0 ∧ (f n = 0 ∨ f (scan f n + 1) ≠ 0) := by
  intro n
  induction n with
  | zero =>
      exact ⟨base, Or.inl base⟩
  | succ n ih =>
      by_cases hn : f n = 0
      · have hscan : scan f (n + 1) = n := if_pos hn
        rw [hscan]
        constructor
        · exact hn
        · by_cases hnext : f (n + 1) = 0
          · exact Or.inl hnext
          · exact Or.inr hnext
      · have hscan : scan f (n + 1) = scan f n := if_neg hn
        rw [hscan]
        exact ⟨ih.1, Or.inr (ih.2.resolve_left hn)⟩

def natQ : Nat → Nat → Nat
  | 0, a => a
  | x + 1, _ => x

theorem nat_shifted_witness
    (f : Nat → Nat) (base : f 0 = 0)
    (range : ∀ x, f x = 0 ∨ f x = x) :
    ∀ n, ∃ b, f (natQ (f (b + 1)) n) = 0 := by
  intro n
  let b := scan f n
  have inv := scan_invariant f base n
  refine ⟨b, ?_⟩
  cases range (b + 1) with
  | inl hz =>
      rw [hz]
      change f n = 0
      cases inv.2 with
      | inl hn => exact hn
      | inr hexit => exact False.elim (hexit hz)
  | inr hs =>
      rw [hs]
      change f b = 0
      exact inv.1

def natZ : Nat → Nat → Nat
  | 0, a => a
  | _ + 1, _ => 0

def natMaskZ (t : Nat → Nat) (x : Nat) : Nat := natZ (t x) x

/- Every raw Nat-valued body has a valid Z-mask witness.  The forward
   induction extraction only uses the Boolean bodies compiled from P. -/
theorem nat_raw_mask_witness (t : Nat → Nat) :
    ∀ n, ∃ b, natMaskZ t (natQ (natMaskZ t (b + 1)) n) = 0 := by
  have base : natMaskZ t 0 = 0 := by
    unfold natMaskZ
    cases t 0 <;> rfl
  have range : ∀ x, natMaskZ t x = 0 ∨ natMaskZ t x = x := by
    intro x
    unfold natMaskZ
    cases t x with
    | zero => exact Or.inr rfl
    | succ _ => exact Or.inl rfl
  exact nat_shifted_witness (natMaskZ t) base range

#print axioms Kernel.succ_ne_zero
#print axioms partition_separation
#print axioms partition_coverage
#print axioms shifted_mask_extract
#print axioms unshifted_mask_extract
#print axioms induction_from_shifted_mask
#print axioms mask_range
#print axioms mask_reflection
#print axioms induction_from_boolean_witness
#print axioms boolean_maskZ_eq_maskQ
#print axioms maskZ_range
#print axioms maskZ_reflection
#print axioms induction_from_Z_boolean_witness
#print axioms scan_invariant
#print axioms nat_shifted_witness
#print axioms nat_raw_mask_witness

end ZeroInputMask
