ZERO-OR-INPUT MASK: LEAN KERNEL CHECK
===================================

Source: ZeroInputMask.lean
Lean version: 4.19.0
Dependencies: Lean standard library only (import Std); no Mathlib.

Reproduce using a Lean 4.19.0 installation:

  lean ZeroInputMask.lean

The file checks sixteen named theorems. Every printed axiom audit reports
that the theorem does not depend on any axioms. In particular there is
no sorryAx, Classical.choice, or propext dependency.

WHAT IS CHECKED

1. Successors are nonzero from the Q equations and 0 != S(0).
2. The shifted-mask existential witness implies all zeros under local
   zero-progress, over an arbitrary type, without Nat induction.
3. The abstract reflection hypotheses yield the induction conclusion.
4. A Boolean term produces the required zero-or-input mask and reflection.
5. The Boolean-mask witness therefore yields the induction conclusion.
6. The primary Z-mask, D_t(x) = Z(t(x), x), agrees with the Q-mask on
   Boolean bodies and has the same range and reflection properties.
7. The actual Z-mask witness yields induction over an arbitrary type.
8. A primitive-recursive last-success scan satisfies its invariant on Nat.
9. That invariant constructs a witness for every zero-or-input Nat function.
10. Every raw Nat-valued body t, without a Boolean assumption, has a valid
    Z-mask witness. Thus the reverse check covers all raw bodies of the
    primary schema, while the forward proof uses its Boolean instances.
11. For the optional twelve-node variant, the partition seed and equality
    bit give separation and zero-or-successor coverage without induction.
    The unshifted existential witness then gives the zero-progress conclusion
    over an arbitrary type. The optional variant's reverse first-failure scan
    is proved in the report and is not formalized in this file.

WHAT IS NOT CHECKED

The file does not formalize the complete object-language syntax, all
primitive-recursive description constructors, the Boolean formula compiler,
the infinite axiom schema, proof translations, or the bi-interpretation
theorem. These remain mathematical arguments in the accompanying report.

The arbitrary-carrier forward theorem fixes numerical parameters externally;
its parameter-universal version follows by universal generalization. The
reverse Nat theorem checks the scan kernel, not its object-language PRA
formalization on all nonstandard models.

check_transcript.txt contains the actual successful verification output.
verification.json records its status and the SHA256 of the source.
