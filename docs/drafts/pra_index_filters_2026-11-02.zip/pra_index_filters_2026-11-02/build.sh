#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_index_filters.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_index_filters.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build pra_index_filters.tex
cp build/pra_index_filters.pdf pra_index_filters.pdf
