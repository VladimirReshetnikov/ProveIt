PRA BY INDEX FILTERS
===================
Prepared for Vladimir Reshetnikov, 2 November 2026.

Read pra_index_filters.pdf for the complete mathematical report.

RESULT
------
A binary-function first-order theory uses direct index filters
  D_t(x,z) = Z(t(x,z),x)
and the schema
  forall z,n exists b: D_t(Q(D_t(Sb,z),n),z)=0.
It has a 13-node recurring witness and derives predecessor coverage.
The report proves a common conservative definitional extension with
first-order PRA, hence equiconsistency and bi-interpretability with
identity domain maps. A 12-node variant trades six extra fixed seed
nodes for one fewer node per witness. Both work separately with
classical or intuitionistic first-order logic.

The strongest current latch witness has 14 active nodes. The new
13-node witness also saves two full-description nodes at matched body
size. The new explicit definition is charged in complete local-package
comparisons. No absolute shortestness or all-input domination of arbitrary
axiom enumerations is claimed.

CONTENTS
--------
pra_index_filters.tex, sections/*.tex  Complete LaTeX source.
pra_index_filters.pdf                 Compiled report.
build.sh                              Rebuild PDF (requires pdfLaTeX).
checks/check_filter_axioms.py          Standalone Python 3 verifier.
checks/verification_summary.json       Exact counts and finite-check results.
checks/unshifted_countermodel.txt      Full infinite two-chain countermodel.
lean/ZeroInputMask.lean                Formal forward and reverse kernels.
lean/lean-toolchain                    Lean 4.19.0 pin.
lean/check_transcript.txt              Actual successful Lean output.
lean/verification.json                 Check status, source hash, scope.
sources.json                          Six GitHub archives, pinned hashes/URLs.
SHA256SUMS.txt                         Checksums for the delivered files.

REPRODUCE
---------
From this directory:
  bash build.sh
  python3 checks/check_filter_axioms.py --output checks/verification_summary.json

With Lean 4.19.0 installed:
  cd lean
  lean ZeroInputMask.lean

Lean uses only Std; no Mathlib and no additional package download is needed.
The checked file has sixteen audited theorems, each with no axiom dependency.
Its hypotheses are explicit. The forward carrier is arbitrary; Nat induction
is used only in the formal reverse scan. The complete syntax, pairing proof,
and PRA bi-interpretation are written proofs, not fully formalized here.

The Python checks are independent error checks, not proofs of the infinite
axiomatization theorem. The complete proofs and their precise limitations
are in the report. Source ZIPs are not duplicated; sources.json gives their
immutable download URLs, commit, Git blob identities, and SHA-256 hashes.
