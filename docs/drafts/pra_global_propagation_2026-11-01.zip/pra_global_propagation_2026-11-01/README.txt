PRA BY GLOBAL PROPAGATION
Research prepared for Vladimir Reshetnikov, 1 November 2026 (Pacific time)

START HERE
  report.pdf       Complete mathematical paper.
  report.tex       Main editable LaTeX source.
  sections/*.tex   Included proof sections.
  AXIOMS.txt       Complete, independently extractable exact specification.

MAIN RESULT
Global propagation over a counter-and-parameter product state suffices for
the full parameterwise QF induction AXIOM. A primitive-recursive last-good
index either verifies the requested instance or exhibits a failing step.
The complete proof is constructive, including native equality reflection
before parameterwise induction has been recovered.

A stationary closed computation family allows the state shift itself to
be expressed with an existing iterator, yielding the G13 presentation:
one arithmetic schema, two exact admission alternatives, no primitive
shift or exceptional counter-reading recursion. Classical and intuitionistic
versions use the SAME nonlogical specification. The one-sorted expansion
has inverse whole-domain term interpretations with matching PRA, and both
composites are proved internally to be the identity.

WHAT THE SIZE RESULT DOES AND DOES NOT SAY
13 counts the typed unary-matrix OUTER wrapper. It is a valid partial
display count, not the length of a complete scalar theory. Including the
displayed gate patterns gives45, tied with the strongest current product
draft. Including product-law displays gives69, also tied. The raw binary
matrix expansion of G13 is25; the scalar global form is16. A named-shift
11-node variant costs15 when the shift is expanded in product primitives.
The result is a rigorously established presentation tradeoff. A shortest
complete encoding of PRA has not been established.

FILES
  formal/GlobalInduction.lean    Constructive arbitrary-carrier logical kernel.
  formal/GlobalInduction.log     Actual Lean theorem dependency output.
  formal/SCOPE.txt               Exact formalization boundary.
  formal/lean-toolchain          Lean 4.19.0 version specification.
  formal/verification.json       Compiler and source-hash receipt.
  checks/check_spec.py           Standard-library finite syntax diagnostics.
  checks/results.json            Exact checks, AST displays, finite evaluations.
  audit/source_manifest.json     Five pinned inputs, archive/member hashes.
  audit/mathematical_review.txt  Proof review and identified limits.
  audit/build_results.json       Build and verification receipt.
  build.py                      Portable rebuild driver.
  SHA256SUMS.txt                 Integrity hashes (excluding itself).

REBUILD
  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

The first command reruns diagnostics and builds report.pdf using pdflatex.
The optional second argument also recompiles the Lean kernel. No Mathlib
or external Python package is needed. The build script never installs
dependencies or executes downloaded comparison code. A rebuild changes
logs and PDF metadata, so the release checksums should then be regenerated.

VERIFICATION BOUNDARY
The Lean file checks the last-good invariant and its deduction of full
induction on an ARBITRARY carrier, with explicit predicate-decidability,
witness-successor, and one selected global-invariant-induction hypothesis.
It uses no Lean natural-number induction and no classical axioms; all four
dependency reports are empty. It does not formalize the syntax, arithmetic
bootstrap, compiler, or complete bi-interpretability theorem.

Finite Python diagnostics are not a proof for arbitrary models. The paper
provides the universal mathematical arguments and both round-trip proofs.

COMPARISON SNAPSHOT
  Repository: https://github.com/VladimirReshetnikov/ProveIt
  Commit: 9e793b1080d95e3fdd1537ba475e67e639d84f20
  Directory: docs/drafts (five archives, all inspected)

The full input archives are not duplicated. No commit, push, issue, comment,
or pull request is required to use this standalone research package.
