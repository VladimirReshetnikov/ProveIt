#!/usr/bin/env python3
"""Rebuild diagnostics and the paper; optionally replay the Lean kernel."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parent


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="path to a Lean 4.19.0 executable")
    parser.add_argument("--skip-pdf", action="store_true")
    args = parser.parse_args()
    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)
    receipt: dict[str, object] = {"python": sys.version.split()[0]}

    checked = subprocess.run(
        [sys.executable, str(ROOT / "checks/check_spec.py")],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    (audit / "python-check.log").write_text(checked.stdout + checked.stderr)
    receipt["syntax_exit_code"] = checked.returncode
    if checked.returncode:
        raise RuntimeError("Finite diagnostics failed; see audit/python-check.log")

    if not args.skip_pdf:
        compiler = shutil.which("pdflatex")
        if compiler is None:
            raise RuntimeError("pdflatex is required; no dependencies are installed automatically")
        with tempfile.TemporaryDirectory(prefix="pra-global-tex-") as temporary:
            for pass_number in range(1, 4):
                built = subprocess.run(
                    [compiler, "-interaction=nonstopmode", "-halt-on-error",
                     "-no-shell-escape", "-output-directory", temporary, "report.tex"],
                    cwd=ROOT, text=True, capture_output=True, check=False,
                )
                (audit / f"latex-pass-{pass_number}.log").write_text(
                    built.stdout + built.stderr
                )
                if built.returncode:
                    raise RuntimeError(f"LaTeX pass {pass_number} failed; see audit")
            shutil.copyfile(Path(temporary) / "report.pdf", ROOT / "report.pdf")
            shutil.copyfile(Path(temporary) / "report.log", audit / "latex-build.log")
        receipt["pdf"] = {"built": True, "bytes": (ROOT / "report.pdf").stat().st_size}

    if args.lean:
        source = ROOT / "formal/GlobalInduction.lean"
        compiled = subprocess.run(
            [args.lean, str(source)], cwd=ROOT, text=True, capture_output=True, check=False,
        )
        (ROOT / "formal/GlobalInduction.log").write_text(compiled.stdout + compiled.stderr)
        version = subprocess.run(
            [args.lean, "--version"], text=True, capture_output=True, check=False,
        )
        formal = {
            "compiler": version.stdout.strip(),
            "exit_code": compiled.returncode,
            "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "empty_dependency_reports": compiled.stdout.count("does not depend on any axioms"),
            "scope": "arbitrary-carrier last-good logical kernel only; see formal/SCOPE.txt",
        }
        (ROOT / "formal/verification.json").write_text(json.dumps(formal, indent=2) + "\n")
        receipt["lean"] = formal
        if compiled.returncode:
            raise RuntimeError("Lean failed; see formal/GlobalInduction.log")
    else:
        receipt["lean_replayed_this_run"] = False

    (audit / "build_results.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
