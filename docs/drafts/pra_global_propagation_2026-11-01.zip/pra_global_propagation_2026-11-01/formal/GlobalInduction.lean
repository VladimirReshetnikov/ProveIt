/-
Constructive logical kernel for parameter recovery from a global induction
instance.  This file formalizes only the counterexample invariant argument;
it does not formalize term syntax, the iterator compiler, or interpretation.

The carrier N is arbitrary.  No natural-number induction is used.  The only
induction hypothesis supplied to `parameterInduction` is the single global
induction instance for the explicitly displayed invariant.  In particular,
the induction hypotheses of a requested A-instance are introduced only after
that invariant has already been proved globally.
-/

namespace GlobalInduction

variable {N P : Type}

def Invariant (zero : N) (succ : N → N) (A : N → P → Prop)
    (witness : N → P → N) (n : N) (p : P) : Prop :=
  A zero p →
    A n p ∨
      (A (witness n p) p ∧ ¬ A (succ (witness n p)) p)

theorem invariantBase (zero : N) (succ : N → N) (A : N → P → Prop)
    (witness : N → P → N) :
    ∀ p, Invariant zero succ A witness zero p := by
  intro p hzero
  exact Or.inl hzero

theorem invariantStep (zero : N) (succ : N → N) (A : N → P → Prop)
    [decidableA : ∀ n p, Decidable (A n p)] (witness : N → P → N)
    (witnessStep : ∀ n p,
      witness (succ n) p = if A n p then n else witness n p) :
    ∀ n p, Invariant zero succ A witness n p →
      Invariant zero succ A witness (succ n) p := by
  intro n p previous hzero
  by_cases hn : A n p
  · by_cases hnext : A (succ n) p
    · exact Or.inl hnext
    · apply Or.inr
      rw [witnessStep n p, if_pos hn]
      exact ⟨hn, hnext⟩
  · rcases previous hzero with hnow | hfailure
    · exact False.elim (hn hnow)
    · apply Or.inr
      rw [witnessStep n p, if_neg hn]
      exact hfailure

theorem extractParameterizedInduction
    (zero : N) (succ : N → N) (A : N → P → Prop)
    (witness : N → P → N)
    (invariant : ∀ n p, Invariant zero succ A witness n p) :
    ∀ p, A zero p → (∀ n, A n p → A (succ n) p) → ∀ n, A n p := by
  intro p hzero hstep n
  rcases invariant n p hzero with hn | hfailure
  · exact hn
  · exact False.elim (hfailure.2 (hstep (witness n p) hfailure.1))

theorem parameterInduction
    (zero : N) (succ : N → N) (A : N → P → Prop)
    [decidableA : ∀ n p, Decidable (A n p)] (witness : N → P → N)
    (witnessStep : ∀ n p,
      witness (succ n) p = if A n p then n else witness n p)
    (globalInvariantInduction :
      (∀ p, Invariant zero succ A witness zero p) →
      (∀ n p, Invariant zero succ A witness n p →
        Invariant zero succ A witness (succ n) p) →
      ∀ n p, Invariant zero succ A witness n p) :
    ∀ p, A zero p → (∀ n, A n p → A (succ n) p) → ∀ n, A n p := by
  have hinvariant : ∀ n p, Invariant zero succ A witness n p :=
    globalInvariantInduction
      (invariantBase zero succ A witness)
      (invariantStep zero succ A witness witnessStep)
  exact extractParameterizedInduction zero succ A witness hinvariant

#print axioms invariantBase
#print axioms invariantStep
#print axioms extractParameterizedInduction
#print axioms parameterInduction

end GlobalInduction
