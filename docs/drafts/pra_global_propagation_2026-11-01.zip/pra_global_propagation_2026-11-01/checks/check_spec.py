#!/usr/bin/env python3
"""Finite diagnostics for the G13 presentation; not a universal proof.

No external packages, network access, or source-archive execution is used.
The mathematical proof and its scope are in report.tex.  This program checks
finite typed syntax, literal admission, declared partial AST counts, and the
counterexample-witness construction on all Boolean words of lengths 1..10.
Stored iterator descriptions are names, not arguments traversed by ordinary
substitution.  Admission performs no arithmetic or product normalization.
"""

from __future__ import annotations

from dataclasses import dataclass
import itertools
import json
from pathlib import Path


@dataclass(frozen=True)
class Ty:
    tag: str
    parts: tuple["Ty", ...] = ()


N = Ty("N")


def product(a: Ty, b: Ty) -> Ty:
    return Ty("product", (a, b))


def validate_type(t: Ty) -> None:
    if not isinstance(t, Ty):
        raise ValueError("a type must be a Ty tree")
    if t.tag == "N" and not t.parts:
        return
    if t.tag == "product" and len(t.parts) == 2:
        for p in t.parts:
            validate_type(p)
        return
    raise ValueError("malformed finite product type")


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    name: str = ""


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def succ(t: Term) -> Term:
    return Term("succ", (t,))


def pair(t: Term, u: Term) -> Term:
    return Term("pair", (t, u))


def fst(t: Term) -> Term:
    return Term("fst", (t,))


def snd(t: Term) -> Term:
    return Term("snd", (t,))


def iteration(name: str, n: Term, seed: Term) -> Term:
    return Term("iter", (n, seed), name)


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple[object, ...] = ()


def eq(t: Term, u: Term) -> Formula:
    return Formula("eq", (t, u))


BOTTOM = Formula("bottom")


def connective(tag: str, a: Formula, b: Formula) -> Formula:
    return Formula(tag, (a, b))


def implies(a: Formula, b: Formula) -> Formula:
    return connective("implies", a, b)


def disjoin(a: Formula, b: Formula) -> Formula:
    return connective("or", a, b)


def forall(name: str, ty: Ty, body: Formula) -> Formula:
    return Formula("forall", (name, ty, body))


DELTA = eq(ZERO, succ(ZERO))


def term_free(t: Term) -> set[str]:
    if t.tag == "var":
        return {t.name}
    return set().union(*(term_free(a) for a in t.args))


def formula_free(f: Formula) -> set[str]:
    if f.tag == "eq":
        return term_free(f.args[0]) | term_free(f.args[1])
    if f.tag == "bottom":
        return set()
    if f.tag == "forall":
        return formula_free(f.args[2]) - {f.args[0]}
    return set().union(*(formula_free(a) for a in f.args))


def term_substitute(t: Term, replacements: dict[str, Term]) -> Term:
    if t.tag == "var":
        return replacements.get(t.name, t)
    # An iterator's stored body is never traversed: only its active args.
    return Term(t.tag, tuple(term_substitute(a, replacements) for a in t.args), t.name)


def formula_substitute(f: Formula, replacements: dict[str, Term]) -> Formula:
    if f.tag == "eq":
        return eq(*(term_substitute(t, replacements) for t in f.args))
    if f.tag == "bottom":
        return f
    if f.tag == "forall":
        name, ty, body = f.args
        active = {k: v for k, v in replacements.items() if k != name}
        active = {k: v for k, v in active.items() if k in formula_free(body)}
        if not active:
            return f
        if any(name in term_free(t) for t in active.values()):
            occupied = formula_free(body) | set(active) | {name}
            for t in active.values():
                occupied |= term_free(t)
            index = 0
            while "bound_" + str(index) in occupied:
                index += 1
            fresh = "bound_" + str(index)
            body = formula_substitute(body, {name: var(fresh)})
            name = fresh
        return forall(name, ty, formula_substitute(body, active))
    return Formula(f.tag, tuple(formula_substitute(a, replacements) for a in f.args))


@dataclass(frozen=True)
class Descriptor:
    name: str
    state: Ty
    body: Term


class Registry:
    def __init__(self) -> None:
        self.descriptors: dict[str, Descriptor] = {}

    def term_type(self, t: Term, env: dict[str, Ty]) -> Ty:
        if not isinstance(t, Term):
            raise ValueError("not a term tree")
        if t.tag == "var" and not t.args and t.name in env:
            return env[t.name]
        if t.tag == "zero" and not t.args and not t.name:
            return N
        if t.name and t.tag not in {"var", "iter"}:
            raise ValueError("unexpected term metadata")
        if t.tag == "succ" and len(t.args) == 1:
            if self.term_type(t.args[0], env) == N:
                return N
        if t.tag == "pair" and len(t.args) == 2:
            return product(*(self.term_type(a, env) for a in t.args))
        if t.tag in {"fst", "snd"} and len(t.args) == 1:
            source = self.term_type(t.args[0], env)
            if source.tag == "product":
                return source.parts[0 if t.tag == "fst" else 1]
        if t.tag == "iter" and len(t.args) == 2:
            if t.name not in self.descriptors:
                raise ValueError("unknown, forward, or cyclic descriptor reference")
            d = self.descriptors[t.name]
            if (self.term_type(t.args[0], env) == N
                    and self.term_type(t.args[1], env) == d.state):
                return d.state
        raise ValueError("ill-typed or malformed term")

    def add(self, name: str, state: Ty, body: Term) -> Descriptor:
        if not name or name in self.descriptors:
            raise ValueError("descriptor names must be fresh")
        validate_type(state)
        # Only previous entries are visible here; this checks dependency order.
        if self.term_type(body, {"v": state}) != state:
            raise ValueError("update body must preserve its state type")
        d = Descriptor(name, state, body)
        self.descriptors[name] = d
        return d

    def validate_formula(self, f: Formula, env: dict[str, Ty], qf: bool) -> None:
        if not isinstance(f, Formula):
            raise ValueError("not a formula tree")
        if f.tag == "eq" and len(f.args) == 2:
            if self.term_type(f.args[0], env) != self.term_type(f.args[1], env):
                raise ValueError("equality has different argument types")
            return
        if f.tag == "bottom" and not f.args:
            return
        if f.tag in {"and", "or", "implies"} and len(f.args) == 2:
            for a in f.args:
                self.validate_formula(a, env, qf)
            return
        if f.tag == "forall" and len(f.args) == 3 and not qf:
            name, ty, body = f.args
            validate_type(ty)
            self.validate_formula(body, {**env, name: ty}, qf)
            return
        raise ValueError("malformed formula or forbidden quantifier")


def guarded(base: Formula, target: Formula) -> Formula:
    return implies(disjoin(base, DELTA), target)


def dynamic_admitted(reg: Registry, parameter: Ty, f: Formula) -> bool:
    try:
        validate_type(parameter)
        reg.validate_formula(f, {"n": N, "a": parameter}, qf=True)
        zero = formula_substitute(f, {"n": ZERO})
        if zero.tag != "implies" or zero.args[0].tag != "or":
            return False
        left, right = zero.args
        return left.args[1] == DELTA and left.args[0] == right
    except (ValueError, AttributeError, TypeError, IndexError):
        return False


def closed_computation(reg: Registry, name: str) -> Formula:
    d = reg.descriptors[name]
    x = var("x")
    n, a = fst(x), snd(x)
    old = iteration(name, n, a)
    updated = term_substitute(d.body, {"v": old})
    body = eq(pair(iteration(name, ZERO, a), iteration(name, succ(n), a)),
              pair(a, updated))
    return forall("x", product(N, d.state), body)


def stationary_admitted(reg: Registry, parameter: Ty,
                        name: str, f: Formula) -> bool:
    try:
        d = reg.descriptors[name]
        reg.validate_formula(f, {}, qf=False)
        return parameter == d.state and f == closed_computation(reg, name)
    except (KeyError, ValueError, AttributeError, TypeError, IndexError):
        return False


def compile_dynamic(reg: Registry, parameter: Ty, f: Formula) -> Formula:
    if not dynamic_admitted(reg, parameter, f):
        raise ValueError("cannot compile a rejected dynamic matrix")
    x = var("x")
    answer = formula_substitute(f, {"n": fst(x), "a": snd(x)})
    reg.validate_formula(answer, {"x": product(N, parameter)}, qf=True)
    return answer


def canonical_shift_body() -> Term:
    return pair(succ(fst(var("v"))), snd(var("v")))


def node(tag: str, *children: tuple) -> tuple:
    return (tag, children)


def size(tree: tuple) -> int:
    return 1 + sum(size(child) for child in tree[1])


def partial_ledger() -> dict[str, object]:
    x, n, a, z, zero = (node(k) for k in ("x", "n", "a", "z", "0"))
    s = lambda t: node("S", t)
    f = lambda *ts: node("F", *ts)
    p = lambda t, u: node("pair", t, u)
    l = lambda t: node("fst", t)
    r = lambda t: node("snd", t)
    q = lambda t: node("forall", t)
    imp = lambda t, u: node("implies", t, u)
    equation = lambda t, u: node("eq", t, u)
    ih = lambda t, u: node("I_h", t, u)
    shift = node("I_q", s(zero), x)
    outer = lambda advance: imp(q(imp(f(x), f(advance))), q(f(x)))
    named = outer(node("sigma", x))
    expanded = outer(p(s(l(x)), r(x)))
    guard_b = node("B", a)
    delta = equation(zero, s(zero))
    guard = imp(node("or", guard_b, delta), guard_b)
    old_z = equation(ih(zero, node("t", a)), node("t", a))
    old_c = equation(ih(s(node("r", a)), node("t", a)),
                     node("h", ih(node("r", a), node("t", a))))
    closed_c = q(equation(p(ih(zero, r(z)), ih(s(l(z)), r(z))),
                          p(r(z), node("h", ih(l(z), r(z))))))
    old_binary = q(imp(q(imp(f(n, a), f(s(n), a))), q(f(n, a))))
    old_unary = q(imp(q(imp(f(p(n, a)), f(p(s(n), a)))), q(f(p(n, a)))))
    global_two_coordinates = imp(q(q(imp(f(n, a), f(s(n), a)))), q(q(f(n, a))))
    decompile = lambda t: f(l(t), r(t))
    g13_decompiled = imp(q(imp(decompile(x), decompile(shift))), q(decompile(x)))
    product_laws = [q(q(equation(l(p(x, a)), x))),
                    q(q(equation(r(p(x, a)), a))),
                    q(equation(p(l(x), r(x)), x))]
    result = {
        "G13_unary_placeholder_wrapper": size(outer(shift)),
        "named_shift_unary_wrapper": size(named),
        "expanded_structural_shift_unary_wrapper": size(expanded),
        "old_P15_binary_placeholder_wrapper": size(old_binary),
        "old_P15_reexpressed_with_unary_matrix_and_explicit_pairs": size(old_unary),
        "global_form_with_two_explicit_coordinate_quantifiers": size(global_two_coordinates),
        "G13_with_unary_matrix_decompiled_to_binary_projections": size(g13_decompiled),
        "guard_pattern": size(guard),
        "closed_paired_computation_pattern": size(closed_c),
        "old_initialization_pattern": size(old_z),
        "old_successor_pattern": size(old_c),
        "product_law_patterns": [size(t) for t in product_laws],
    }
    result["new_outer_plus_patterns"] = size(outer(shift)) + size(guard) + size(closed_c)
    result["old_outer_plus_patterns"] = size(old_binary) + size(guard) + size(old_z) + size(old_c)
    result["new_with_product_patterns"] = result["new_outer_plus_patterns"] + 24
    result["old_with_product_patterns"] = result["old_outer_plus_patterns"] + 24
    result["displays"] = {
        "G13_unary_placeholder_wrapper":
            "(forall x (Fhat(x) -> Fhat(I_q(S0,x)))) -> forall x Fhat(x)",
        "named_shift_unary_wrapper":
            "(forall x (Fhat(x) -> Fhat(sigma(x)))) -> forall x Fhat(x)",
        "expanded_structural_shift_unary_wrapper":
            "(forall x (Fhat(x) -> Fhat(pair(S(fst(x)),snd(x))))) -> forall x Fhat(x)",
        "old_P15_binary_placeholder_wrapper":
            "forall a ((forall n (F(n,a) -> F(Sn,a))) -> forall n F(n,a))",
        "old_P15_reexpressed_with_unary_matrix_and_explicit_pairs":
            "forall a ((forall n (Fhat(pair(n,a)) -> Fhat(pair(Sn,a)))) -> forall n Fhat(pair(n,a)))",
        "global_form_with_two_explicit_coordinate_quantifiers":
            "(forall n forall a (F(n,a) -> F(Sn,a))) -> forall n forall a F(n,a)",
        "G13_with_unary_matrix_decompiled_to_binary_projections":
            "(forall x (F(fst(x),snd(x)) -> F(fst(I_q(S0,x)),snd(I_q(S0,x))))) -> forall x F(fst(x),snd(x))",
        "guard_pattern": "(B(a) or (0=S0)) -> B(a)",
        "closed_paired_computation_pattern":
            "forall z pair(I_h(0,snd(z)),I_h(S(fst(z)),snd(z))) = pair(snd(z),h(I_h(fst(z),snd(z))))",
        "old_initialization_pattern": "I_h(0,t(a))=t(a)",
        "old_successor_pattern": "I_h(S(r(a)),t(a))=h(I_h(r(a),t(a)))",
        "product_law_patterns": [
            "forall x forall y fst(pair(x,y))=x",
            "forall x forall y snd(pair(x,y))=y",
            "forall z pair(fst(z),snd(z))=z",
        ],
    }
    result["scope"] = (
        "Partial AST counts only. Matrix bodies, descriptor bodies and their validation, "
        "types, substitution, admission code, and scalar expansion are not fully priced. "
        "The two outer-plus-pattern totals tie; no total-shortestness claim follows."
    )
    return result


def run() -> dict[str, object]:
    tests: list[dict[str, object]] = []

    def check(name: str, actual: object, expected: object = True) -> None:
        if actual != expected:
            raise RuntimeError(f"diagnostic failed: {name}: {actual!r} != {expected!r}")
        tests.append({"name": name, "passed": True})

    def reject(name: str, action) -> None:
        try:
            action()
        except ValueError:
            check(name, True)
            return
        raise RuntimeError("expected rejection: " + name)

    reg = Registry()
    reg.add("zero", N, ZERO)
    reg.add("successor", N, succ(var("v")))
    reg.add("identity", N, var("v"))
    reg.add("identity_again", N, var("v"))
    reg.add("q_N", product(N, N), canonical_shift_body())
    reg.add("q_pair", product(N, product(N, N)), canonical_shift_body())
    reg.add("nested", N, iteration("successor", var("v"), ZERO))
    reject("self_reference_rejected", lambda: reg.add("self", N, iteration("self", ZERO, var("v"))))
    reject("forward_reference_rejected", lambda: reg.add("forward", N, iteration("later", ZERO, var("v"))))
    reject("external_update_parameter_rejected", lambda: reg.add("external", N, var("a")))
    reject("state_type_change_rejected", lambda: reg.add("badtype", N, pair(var("v"), ZERO)))
    reject("duplicate_descriptor_rejected", lambda: reg.add("zero", N, ZERO))
    reject("malformed_type_rejected", lambda: reg.add("badty", Ty("product", (N,)), ZERO))

    n, a = var("n"), var("a")
    base, target = eq(ZERO, a), eq(n, a)
    good = guarded(base, target)
    check("normalized_dynamic_matrix_admitted", dynamic_admitted(reg, N, good))
    check("separation_guard_admitted", dynamic_admitted(reg, N, guarded(BOTTOM, BOTTOM)))
    check("plain_reflexive_implication_rejected", dynamic_admitted(reg, N, implies(base, base)), False)
    check("plain_reflexive_equation_rejected", dynamic_admitted(reg, N, eq(a, a)), False)
    check("unequal_repeated_branches_rejected", dynamic_admitted(reg, N, guarded(base, eq(ZERO, succ(a)))), False)
    reverse_delta = eq(succ(ZERO), ZERO)
    check("reversed_delta_rejected", dynamic_admitted(reg, N, implies(disjoin(base, reverse_delta), target)), False)
    beta_equivalent = eq(fst(pair(ZERO, ZERO)), succ(ZERO))
    check("beta_equivalent_delta_rejected", dynamic_admitted(reg, N, implies(disjoin(base, beta_equivalent), target)), False)
    arithmetic_equivalent = eq(iteration("zero", ZERO, ZERO), succ(ZERO))
    check("computation_equivalent_delta_rejected", dynamic_admitted(reg, N, implies(disjoin(base, arithmetic_equivalent), target)), False)
    extra = guarded(eq(var("extra"), a), eq(var("extra"), a))
    check("extra_free_variable_rejected", dynamic_admitted(reg, N, extra), False)
    quantified = forall("x", N, eq(var("x"), var("x")))
    check("quantified_dynamic_branch_rejected", dynamic_admitted(reg, N, guarded(quantified, quantified)), False)
    wrong_type = guarded(eq(a, ZERO), eq(a, ZERO))
    check("ill_typed_dynamic_equality_rejected", dynamic_admitted(reg, product(N, N), wrong_type), False)
    check("unknown_function_descriptor_rejected", dynamic_admitted(reg, N, guarded(eq(iteration("missing", ZERO, a), a), target)), False)

    compiled = compile_dynamic(reg, N, good)
    check("compiled_matrix_has_only_x_free", formula_free(compiled), {"x"})
    check("compile_keeps_projection_syntax", compiled,
          guarded(eq(ZERO, snd(var("x"))), eq(fst(var("x")), snd(var("x")))))
    reject("compiler_rejects_bad_gate", lambda: compile_dynamic(reg, N, eq(a, a)))

    for name, d in reg.descriptors.items():
        c = closed_computation(reg, name)
        check("closed_computation_admitted_" + name, stationary_admitted(reg, d.state, name, c))
        check("closed_computation_closed_" + name, formula_free(c), set())
        check("closed_substitution_shadowing_" + name,
              formula_substitute(c, {"x": iteration("q_N", succ(ZERO), var("x"))}), c)
    c = closed_computation(reg, "identity")
    check("stationary_wrong_parameter_type_rejected", stationary_admitted(reg, product(N, N), "identity", c), False)
    check("stationary_wrong_descriptor_rejected", stationary_admitted(reg, N, "identity_again", c), False)
    renamed = forall("z", c.args[1], formula_substitute(c.args[2], {"x": var("z")}))
    check("alpha_equivalent_stationary_gate_rejected", stationary_admitted(reg, N, "identity", renamed), False)
    reversed_eq = forall("x", c.args[1], eq(c.args[2].args[1], c.args[2].args[0]))
    check("reversed_stationary_equation_rejected", stationary_admitted(reg, N, "identity", reversed_eq), False)
    changing = implies(eq(n, ZERO), c)
    check("nonstationary_quantified_computation_rejected", stationary_admitted(reg, N, "identity", changing), False)
    check("nonstationary_quantified_dynamic_rejected", dynamic_admitted(reg, N, changing), False)
    x = var("x")
    changing_at_zero = forall("x", product(N, N),
        eq(pair(iteration("identity", n, snd(x)),
                iteration("identity", succ(fst(x)), snd(x))),
           pair(snd(x), iteration("identity", fst(x), snd(x)))))
    check("changing_quantified_zero_instance_matches_C",
          formula_substitute(changing_at_zero, {"n": ZERO}), c)
    check("changing_quantified_zero_match_not_stationary",
          stationary_admitted(reg, N, "identity", changing_at_zero), False)
    check("changing_quantified_zero_match_not_dynamic",
          dynamic_admitted(reg, N, changing_at_zero), False)

    before = tuple(reg.descriptors.items())
    active = iteration("identity", n, a)
    check("active_arguments_substituted", term_substitute(active, {"n": ZERO}), iteration("identity", ZERO, a))
    check("private_descriptor_variable_not_substituted", term_substitute(active, {"v": succ(ZERO)}), active)
    check("registry_unchanged_by_substitution", tuple(reg.descriptors.items()), before)
    capture_test = forall("x", N, eq(var("a"), var("x")))
    captured = formula_substitute(capture_test, {"a": var("x")})
    check("capture_avoiding_substitution", formula_free(captured), {"x"})

    ledger = partial_ledger()
    for key, expected in {
        "G13_unary_placeholder_wrapper": 13,
        "named_shift_unary_wrapper": 11,
        "expanded_structural_shift_unary_wrapper": 15,
        "old_P15_binary_placeholder_wrapper": 15,
        "old_P15_reexpressed_with_unary_matrix_and_explicit_pairs": 18,
        "global_form_with_two_explicit_coordinate_quantifiers": 16,
        "G13_with_unary_matrix_decompiled_to_binary_projections": 25,
        "guard_pattern": 10,
        "closed_paired_computation_pattern": 22,
        "old_initialization_pattern": 7,
        "old_successor_pattern": 13,
        "product_law_patterns": [8, 8, 8],
        "new_outer_plus_patterns": 45,
        "old_outer_plus_patterns": 45,
        "new_with_product_patterns": 69,
        "old_with_product_patterns": 69,
    }.items():
        check("partial_ledger_" + key, ledger[key], expected)

    words = trajectories = invariant_checks = failure_witnesses = 0
    for length in range(1, 11):
        for values in itertools.product((False, True), repeat=length):
            words += 1
            for initial in range(length):
                trajectories += 1
                witness = initial
                for index, now in enumerate(values):
                    # The base disjunct makes the invariant independent of r(0).
                    if values[0] and not now:
                        if not (0 <= witness < index and values[witness]
                                and not values[witness + 1]):
                            raise RuntimeError("Boolean witness invariant failed")
                        failure_witnesses += 1
                    invariant_checks += 1
                    # Update r(n+1) from A(n), matching the mathematical definition.
                    witness = index if now else witness
    predecessor_checks = 0
    state = (0, 0)
    for index in range(101):
        if state != (index, max(0, index - 1)):
            raise RuntimeError("product predecessor state simulation failed")
        predecessor_checks += 1
        state = (state[0] + 1, state[0])

    return {
        "status": "passed",
        "scope": "Finite syntax and bounded diagnostics, not a formal or arbitrary-model proof.",
        "stationary_binder": "x (literal; alpha-equivalence is not admission)",
        "registry": {"descriptors": len(reg.descriptors), "dependency_order_validated": True},
        "named_diagnostics": {"count": len(tests), "cases": tests},
        "partial_ast_ledger": ledger,
        "boolean_witness": {
            "word_lengths": [1, 10], "all_words": words,
            "initial_witness_values": "every index of each word, including the ordinary seed zero",
            "trajectories": trajectories, "invariant_checks": invariant_checks,
            "failure_witness_cases": failure_witnesses,
            "scope": "Exhaustive over these finite Boolean words only; not an induction proof.",
        },
        "product_predecessor": {"natural_inputs": [0, 100], "checks": predecessor_checks},
    }


if __name__ == "__main__":
    result = run()
    destination = Path(__file__).with_name("results.json")
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "named_diagnostics": result["named_diagnostics"]["count"],
        "boolean_words": result["boolean_witness"]["all_words"],
        "witness_invariant_checks": result["boolean_witness"]["invariant_checks"],
        "partial_wrapper_counts": [13, 11, 15],
        "partial_generator_subtotals": [45, 45, 69, 69],
        "output": "checks/results.json",
        "scope": "diagnostics, not a universal proof",
    }, sort_keys=True))
