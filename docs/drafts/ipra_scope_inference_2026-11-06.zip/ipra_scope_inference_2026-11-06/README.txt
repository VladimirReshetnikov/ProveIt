SCOPE INFERENCE FOR INTUITIONISTIC PRIMITIVE RECURSIVE ARITHMETIC
==============================================================
Prepared for Vladimir Reshetnikov, 6 November 2026.

RESULT

This archive gives a fully specified small presentation of iPRA, a complete
standalone proof checker, proofs of the mathematical equivalences, and
reproducible implementation evidence. The checker has 726 executable Python
AST nodes, 677 normalized significant tokens, and 2,213 normalized bytes.
The counts include syntax and sort validation, substitution, arithmetic
axioms, inference, JSON input, and command-line rejection handling.

These measurements are below the corresponding measured lower envelope of
the current six draft archives, including their smaller canonical variants
and bundled complete comparators. The comparison is pinned to ProveIt commit
473749742630b5a7779e7c3a36cd23ebd9cb53b5. Source provenance, normalization,
and qualifications are recorded in the paper and comparison directory.
This is a finite comparative result, not an absolute minimality theorem
over all theories, encodings, programming languages, and implementations.

THE THEORY

The reference iPRA is intuitionistic first-order arithmetic with all fixed
primitive-recursive function descriptions and quantifier-free induction.
The native presentation uses numerical equality, a guarded universal binder
Pi x[A;B], and existence E x A. Terms use zero, successor, and an initialized
primitive-recursion constructor. Its arithmetic consists of the two recursion
equations and one numerical rule: induction for literal equations, numerical
cases for all other formulas. Falsity abbreviates the equation 0=S0.

The paper derives the ordinary intuitionistic logical rules, equality laws,
successor laws, and all source quantifier-free induction instances. It also
specifies the conventional first-order realization, including numerical
coverage and the contradiction bridge needed for the interpretation claim.
That realization is bi-interpretable with iPRA using the entire number sort
in both directions; equality gives the definable round-trip isomorphisms.
The native calculus faithfully presents it and is equiconsistent with iPRA.

The principal implementation change infers an existential-elimination
conclusion and checks witness nonescape by deleting the fresh numerical
slot. The lowering lemma applies beneath arbitrary nested quantifiers and
recursor bodies. Smaller compatible changes share introduction code, use
already validated constructor shape, and simplify exact CLI argument parsing.
The article separates the mathematical/certificate changes from the last
interface change and attributes inherited ingredients to the current drafts.

START HERE

  report.pdf            Complete mathematical report and evidence.
  report.tex            LaTeX source; sections/ contains its included text.
  checker.py            Entire trusted acceptance program.
  FORMAT.txt            Complete finite JSON syntax and inference format.
  examples/             Small ready-to-check demonstration certificates.
  reproduce.py          Reproduces measurements, checks, and optionally PDF.

  comparison/           Pinned source inventory, complete comparators,
                        measurement script, tables, and provenance.

  verification/kernel/  Frozen sorted canonical baseline, checked proof
                        translators in both directions, ablation programs,
                        fixtures, test scripts, and recorded results.

  verification/independent_audit.py
                        Separate named-variable binding and recursion audit.

The duplicate candidate.py under verification/kernel is for the comparison
and translation harness. checker.py at the archive root is the standalone
program to run. Neither checker imports a proof generator or translator.

REPRODUCING THE RESULTS

Run these commands from the extracted archive directory. Python 3.10 or later
is required by the pattern-matching syntax and strict zip operation; the
recorded exact counts use Python 3.12.14. The checker and verification code
use only the standard library. Unparser-based counts can vary across Python
versions, so use the recorded version for exact byte-for-byte measurements.

Check a demonstration:

  python3 checker.py examples/universal_reflexivity.json

Successful checking prints ACCEPT and exits with status 0. An invalid
certificate prints REJECT and exits with status 1.

Reproduce the computational evidence without compiling the PDF:

  python3 reproduce.py --no-pdf

Reproduce the complete package, including PDF compilation:

  python3 reproduce.py

The full run additionally needs pdflatex and the LaTeX packages named in
report.tex. The supplied PDF is already compiled. Compilation tools and
typesetting packages are not part of proof acceptance.

INDIVIDUAL VERIFICATION COMMANDS

  python3 comparison/measure.py --candidate checker.py
  python3 verification/kernel/measure.py
  python3 verification/kernel/validate.py
  python3 verification/independent_audit.py

The translators under verification/kernel recheck their input with the source
checker and their output with the target checker. For example, from within
that directory:

  python3 translate.py forward fixtures/baseline/example_reflexivity.json

Use reverse instead of forward to translate a candidate-format certificate
back to the frozen baseline. The JSON result is printed to standard output.

WHAT HAS BEEN CHECKED

The finite implementation evidence includes 257 frozen baseline cases:
150 accepted proofs translated in both directions with unchanged sequents,
91 negatives rejected by the candidate, and 16 malformed originals rejected
during untrusted translation. The latter 16 are explicitly not counted as
candidate-rejection evidence.

There are also 36 fresh direct cases, 2,000 independent tests of lowering
against a free-slot/decrement oracle, and 76 CLI checks. Direct cases exercise
retained parameters under nested logical and recursive binders, forbidden
witness escapes, malformed terms and arities, and rejection of induction for
quantified formulas where only the case rule is permitted. CLI checks cover
ordinary and optimized Python, malformed JSON, missing files, and wrong
argument counts. Detailed outcomes and certificates are included.

A separate audit uses a named-variable representation independent of the
candidate's substitution implementation. Its 2,471 cases also pass, including
1,693 legal scope exits and 665 rejected witness escapes, recursion steps,
malformed certificates, harmless lookup aliases, and command-line behavior.

The mathematical soundness, completeness, logical recovery, equiconsistency,
and bi-interpretability arguments are proofs in the report. The executable
checks provide finite evidence about the implementation and translations;
they are not a Lean/Rocq formalization or an exhaustive machine proof of
Python correctness. The complete calculus and its side conditions are in
report.pdf, with the exact operational format in FORMAT.txt.
