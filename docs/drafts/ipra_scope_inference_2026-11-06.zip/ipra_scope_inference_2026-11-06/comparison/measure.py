#!/usr/bin/env python3
"""Measure the complete pinned checker inventory without importing its code.

Run: python3 measure.py --candidate ../checker.py
Only the Python standard library is required (Python 3.11+).
"""

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
AXES = ("ast_nodes", "source_tokens", "normalized_tokens", "normalized_bytes", "raw_bytes")
IGNORED = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
           tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source, filename=path.name)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    significant = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
                   if t.type not in IGNORED
                   and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    tree = StripDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    normalized_tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
                         if t.type not in IGNORED]
    imports = []
    functions = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append("." * node.level + (node.module or ""))
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions.append(node.name)
    has_cli = any(isinstance(n, ast.If) and "__name__" in ast.unparse(n.test)
                  for n in tree.body)
    return {"sha256": hashlib.sha256(raw).hexdigest(), "raw_bytes": len(raw),
            "normalized_bytes": len(normalized.encode("utf-8")),
            "source_tokens": len(significant), "normalized_tokens": len(normalized_tokens),
            "ast_nodes": sum(1 for _ in ast.walk(tree)),
            "imports": sorted(set(imports)), "has_cli": has_cli,
            "function_names": sorted(set(functions))}


def envelope(rows):
    return {axis: min(row["metrics"][axis] for row in rows) for axis in AXES}


def latex_table(rows):
    lines = [r"\begin{tabular}{@{}lrrrrr@{}}", r"\toprule",
             r"Complete program & AST & Src. tok. & Norm. tok. & Norm. bytes & Raw bytes \\",
             r"\midrule"]
    for row in rows:
        label = row["label"].replace("_", r"\_").replace("&", r"\&")
        lines.append(label + " & " + " & ".join(f'{row["metrics"][axis]:,}' for axis in AXES) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path,
                        help="Path to the complete standalone candidate checker (never imported).")
    parser.add_argument("--label", default="New checker", help="Candidate label for summary table.")
    parser.add_argument("--output", type=Path, default=ROOT / "metrics.json",
                        help="JSON output; defaults to metrics.json beside this script.")
    parser.add_argument("--table", type=Path, default=ROOT / "summary_table.tex",
                        help="LaTeX table output; defaults beside this script.")
    parser.add_argument("--table-json", type=Path, default=ROOT / "summary_table.json",
                        help="Machine-readable selected table rows.")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "manifest.json").read_text())
    inventory = []
    for record in manifest["sources"]:
        values = measure(ROOT / record["stored_path"])
        if values["sha256"] != record["sha256"]:
            raise ValueError("Pinned source bytes changed: " + record["stored_path"])
        inventory.append({"stored_path": record["stored_path"], "sha256": record["sha256"],
                          "occurrence_count": len(record["occurrences"]), "metrics": values})
    by_hash = {row["sha256"]: row for row in inventory}
    selected = [{**row, "metrics": by_hash[row["sha256"]]["metrics"]}
                for row in manifest["summary_rows"]]
    minima = envelope(inventory)
    attaining = {axis: [r["stored_path"] for r in inventory if r["metrics"][axis] == minima[axis]]
                 for axis in AXES}
    result = {"python_version": platform.python_version(),
              "snapshot": manifest["snapshot"], "definitions": manifest["metric_definitions"],
              "inventory_criterion": manifest["inventory_criterion"],
              "inventory_count": len(inventory),
              "occurrence_count": sum(row["occurrence_count"] for row in inventory),
              "inventory_envelope": minima, "minimum_sources": attaining,
              "qualification": manifest["qualification"], "inventory": inventory}
    if args.candidate is not None:
        candidate = measure(args.candidate)
        result["candidate"] = {"filename": args.candidate.name, "metrics": candidate}
        result["candidate_below_or_equal_inventory"] = {
            axis: candidate[axis] <= minima[axis] for axis in AXES}
        result["candidate_strictly_below_inventory"] = {
            axis: candidate[axis] < minima[axis] for axis in AXES}
        result["candidate_dependency_notice"] = (
            "All source bytes in the supplied file are charged; any nonstandard dependency "
            "or external acceptance code must additionally be charged. Inspect imports and "
            "the accepted-program boundary before using these numbers as a complete-checker claim.")
        selected.append({"label": args.label, "role": "candidate", "metrics": candidate})
    result["summary_rows"] = selected
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    args.table.parent.mkdir(parents=True, exist_ok=True)
    args.table.write_text(latex_table(selected))
    args.table_json.parent.mkdir(parents=True, exist_ok=True)
    args.table_json.write_text(json.dumps(selected, indent=2) + "\n")
    brief = {key: result[key] for key in ("python_version", "inventory_count", "occurrence_count",
                                         "inventory_envelope")}
    if args.candidate is not None:
        brief.update({key: result[key] for key in ("candidate", "candidate_below_or_equal_inventory",
                                                  "candidate_strictly_below_inventory")})
    print(json.dumps(brief, indent=2))


if __name__ == "__main__":
    main()
