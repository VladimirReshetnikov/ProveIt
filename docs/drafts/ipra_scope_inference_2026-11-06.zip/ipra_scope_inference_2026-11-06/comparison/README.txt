PINNED CURRENT-CORPUS COMPARISON

Snapshot: VladimirReshetnikov/ProveIt, docs/drafts
Commit: 473749742630b5a7779e7c3a36cd23ebd9cb53b5
https://github.com/VladimirReshetnikov/ProveIt/tree/473749742630b5a7779e7c3a36cd23ebd9cb53b5/docs/drafts

CONTENTS

sources/ contains 151 byte-for-byte original Python sources, named by SHA-256.
manifest.json maps every source to every original archive and ZIP member path.
For each of the 632 source occurrences, it records the repository archive path,
archive Git blob SHA-1, archive SHA-256, and complete original ZIP member path.
The original six archive bytes were checked against these identities before use.
The archives themselves are not duplicated here.

All .py members in the six archives were parsed. The comparison census includes
sources defining functions named infer and check anywhere in the Python AST,
deduplicated by the SHA-256 of original bytes. This is a transparent syntactic
inventory rule, not a soundness/completeness test. Historical and ablation/control
variants are not all independently certified sound or complete; some omit a
separate CLI. All sources attaining any coordinate minimum are complete,
standalone acceptance programs with only json and sys imports.

omitted_small_components.json inventories the 32 distinct (45 occurrences)
additional Python files with normalized length below 2,400 bytes that do not
meet the census criterion. These are build/validation utilities, translators,
JSON wrappers, and components of earlier modular checkers. Full member provenance,
function names, imports, size measurements, and exclusion reasons are recorded.
A wrapper's omitted imports are not free: all acceptance dependencies must be
charged when comparing a modular checker.

REPRODUCE

Requires Python 3.11 or later, using only its standard library. Recorded values
were generated with CPython 3.12.14. The script neither imports nor executes
any program being measured. It checks each frozen file's SHA-256 first.

From this directory:

    python3 measure.py
    python3 measure.py --candidate ../checker.py

The optional candidate argument must name the complete standalone candidate
acceptance program. The script measures all its source, reports its imports
and CLI presence, and compares every axis with the full inventory's coordinate
minimum. If the candidate has custom acceptance dependencies, their code must
also be charged; a one-file measurement does not excuse hidden helpers.

Paths are resolved relative to this script for the frozen bundle, so the
commands also work from other working directories using a path to measure.py.
Candidate paths are interpreted relative to the caller's working directory.
Use --output, --table, and --table-json to select output destinations.

Default outputs:

- metrics.json: all 151 measured sources, coordinate minima and attaining
  sources, plus the supplied candidate's measurements and per-axis comparison.
- summary_table.json: six primary programs, sorted canonical checker, and the
  sorted split-introduction control, plus the candidate if supplied.
- summary_table.tex: the same rows in LaTeX (requires booktabs).

METRICS AND LIMITS

AST nodes count all ast.walk nodes after removing documentation strings,
including Load/Store and operator nodes. Source tokens exclude documentation
strings, comments, layout tokens, and end marker. Normalized tokens tokenize
ast.unparse of that stripped AST. Normalized bytes are its UTF-8 length plus
one final newline. Raw bytes count the entire original source unchanged.
Thus source tokens and normalized tokens are deliberately separate fields.

The shared Python runtime and its standard JSON/sys facilities are common
infrastructure. Syntax validation, primitive arithmetic, capture-avoiding
substitution, inference, imports, CLI, and rejection handling contained in
a source are all counted. Nothing is excluded merely for being called a helper.
Changing Python's ast.unparse version may affect normalized bytes/tokens; the
runtime version is therefore included in every measurement output.

Verified coordinatewise envelope of the pinned inventory:

    AST nodes:          750
    Source tokens:      703
    Normalized tokens:  701
    Normalized bytes: 2,265
    Raw bytes:        2,574

The sorted canonical checker attains the AST/token minima. Its split-introduction
control ties the AST minimum and attains the byte minima. Comparing only the six
primary checker.py files would miss these smaller bundled programs.

These finite implementation comparisons do not establish an absolute lower
bound or a globally shortest axiomatization of iPRA. They establish reproducible
size relations to this explicitly pinned corpus under the stated convention.
