#!/usr/bin/env python3
"""Reproduce the evidence and paper; no network access is required.

python3 reproduce.py --no-pdf
python3 reproduce.py

The report and finite audits do not participate in certificate acceptance.
"""

import argparse
import hashlib
import importlib.util
import json
import platform
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
VERIFY = ROOT / "verification"


def run(label, arguments, cwd=ROOT):
    process = subprocess.run(arguments, cwd=cwd, capture_output=True, text=True)
    log = VERIFY / (label + ".log")
    log.write_text(process.stdout + process.stderr, encoding="utf-8")
    if process.returncode:
        raise RuntimeError(f"{label} failed; see {log.relative_to(ROOT)}")
    print(label + ": passed", flush=True)


def tables():
    comparison = json.loads((ROOT / "comparison/metrics.json").read_text())
    candidate = comparison["candidate"]["metrics"]
    envelope = comparison["inventory_envelope"]
    primary = ("ast_nodes", "normalized_tokens", "normalized_bytes")
    if not all(candidate[key] < envelope[key] for key in primary):
        raise ValueError("Candidate no longer beats the normalized envelope")
    if candidate["imports"] != ["json", "sys"] or not candidate["has_cli"]:
        raise ValueError("Acceptance dependency boundary changed")
    lines = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Complete acceptance program & AST nodes & Norm. tokens & Norm. bytes \\",
             r"\midrule"]
    for row in comparison["summary_rows"]:
        label = row["label"]
        label = {"Sorted canonical checker": "Sorted: canonical",
                 "Sorted canonical minimum-byte control": "Sorted: minimum-byte control",
                 "Sorted split-introduction control": "Sorted: minimum-byte control"}.get(label, label)
        label = label.replace("_", r"\_").replace("&", r"\&")
        if row.get("role") == "candidate":
            lines.append(r"\midrule")
            label = r"\textbf{New complete checker}"
        values = " & ".join(f'{row["metrics"][key]:,}' for key in primary)
        lines.append(label + " & " + values + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (VERIFY / "comparison_table.tex").write_text("\n".join(lines) + "\n")
    macros = []
    for prefix, data in (("Candidate", candidate), ("Baseline", envelope)):
        for axis, suffix in (("ast_nodes", "AST"), ("normalized_tokens", "Tokens"),
                             ("normalized_bytes", "Bytes")):
            macros.append("\\newcommand{\\" + prefix + suffix + "}{" + f"{data[axis]:,}" + "}")
    (VERIFY / "metrics_macros.tex").write_text("\n".join(macros) + "\n")
    ablation = json.loads((VERIFY / "kernel/metrics.json").read_text())
    labels = ["Frozen sorted canonical checker", "Infer existential conclusion",
              "Unpack the validated successor", "Share introduction construction",
              "Unpack command-line arguments"]
    lines = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Cumulative change & AST & Norm. tokens & Norm. bytes \\", r"\midrule"]
    for label, row in zip(labels, ablation["ablation_chain"], strict=True):
        lines.append(label + " & " + " & ".join(f'{row["metrics"][key]:,}' for key in primary) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    (VERIFY / "ablation_table.tex").write_text("\n".join(lines) + "\n")
    return comparison


def compile_pdf():
    executable = shutil.which("pdflatex")
    if not executable:
        raise RuntimeError("pdflatex is required; use --no-pdf to run the other checks")
    build = VERIFY / "latex"
    build.mkdir(exist_ok=True)
    for pass_number in range(3):
        run(f"latex_pass_{pass_number + 1}", [executable, "-interaction=nonstopmode",
            "-halt-on-error", "-file-line-error", "-output-directory=" + str(build), "report.tex"])
    log = (build / "report.log").read_text(errors="replace")
    errors = [line for line in log.splitlines()
              if "Overfull" in line or "undefined references" in line
              or "undefined on input" in line or "Missing character" in line]
    (VERIFY / "compilation.json").write_text(json.dumps({
        "engine": executable, "passes": 3, "layout_or_reference_warnings": errors}, indent=2) + "\n")
    if errors:
        raise RuntimeError("Review LaTeX layout/reference warnings in verification/compilation.json")
    shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-pdf", action="store_true", help="Do not invoke LaTeX")
    parser.add_argument("--pdf-only", action="store_true", help="Reuse verified evidence; compile only")
    args = parser.parse_args()
    if args.no_pdf and args.pdf_only:
        parser.error("--no-pdf and --pdf-only are mutually exclusive")
    VERIFY.mkdir(exist_ok=True)
    if not args.pdf_only:
        actual = (ROOT / "checker.py").read_bytes()
        if actual != (VERIFY / "kernel/candidate.py").read_bytes():
            raise ValueError("The validation-suite candidate must be byte-identical to checker.py")
        run("kernel_validation", [sys.executable, str(VERIFY / "kernel/validate.py")])
        run("independent_audit", [sys.executable, str(VERIFY / "independent_audit.py"),
                                  str(ROOT / "checker.py")])
        run("measurement", [sys.executable, str(ROOT / "comparison/measure.py"),
                            "--candidate", str(ROOT / "checker.py")])
        run("ablation_measurement", [sys.executable, str(VERIFY / "kernel/measure.py")])
        comparison = tables()
        spec = importlib.util.spec_from_file_location("deliverable_checker", ROOT / "checker.py")
        checker = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(checker)
        examples = []
        for path in sorted((ROOT / "examples").glob("*.json")):
            checker.check(json.loads(path.read_text()))
            examples.append(path.name)
        tests = json.loads((VERIFY / "kernel/validation_results.json").read_text())
        independent = json.loads((VERIFY / "independent_audit_results.json").read_text())
        if tests["status"] != "passed" or not independent["passed"]:
            raise ValueError("A finite audit failed")
        summary = {"status": "passed", "python": platform.python_version(),
                   "checker_sha256": hashlib.sha256(actual).hexdigest(),
                   "repository_commit": "473749742630b5a7779e7c3a36cd23ebd9cb53b5",
                   "candidate_metrics": comparison["candidate"]["metrics"],
                   "comparison_envelope": comparison["inventory_envelope"],
                   "comparison_source_count": comparison["inventory_count"],
                   "baseline_regression": tests["baseline_regression"],
                   "direct_cases": tests["new_direct_cases"],
                   "lowering_checks": tests["lowering"],
                   "primary_cli_checks": tests["cli_invocations"],
                   "independent_audit_cases": independent["total_cases"],
                   "independent_audit_counts": independent["counts"],
                   "examples": examples,
                   "qualification": "Mathematical metatheory plus finite implementation audits; not a Lean/Rocq formalization."}
        (VERIFY / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        print("all examples: passed", flush=True)
    if not args.no_pdf:
        compile_pdf()
    print("Reproduction complete.", flush=True)


if __name__ == "__main__":
    main()
