"""Untrusted bidirectional translations to the sorted canonical checker.

Neither checker imports this module. Every translated proof is rechecked
by its target. This file deliberately prioritizes clear validation over size.
"""

import json
import sys

import baseline
import candidate


def erase_false(value):
    """Expand a public spelling before either canonical checker is called."""
    if value == ["false"]:
        return ["=", -1, ["s", -1]]
    return [erase_false(x) for x in value] if type(value) is list else value


def translate_proof(proof, context, reverse=False):
    source = candidate if reverse else baseline
    match proof:
        case [("lam" | "pack") as tag, annotation, child]:
            hypothesis = (annotation if tag == "lam" else
                          ["=", 0, source.subst(annotation, formula=False)])
            inner = [*map(source.subst, context), hypothesis]
            return [tag, annotation, translate_proof(child, inner, reverse)]
        case ["use", principal, *arguments]:
            formula = source.infer(principal, context)
            translated = translate_proof(principal, context, reverse)
            if formula[0] == "ex":
                inner = [*map(source.subst, context), formula[1]]
                if reverse:
                    child, = arguments
                    body_result = source.infer(child, inner)
                    conclusion = source.subst(body_result, [None, -1])
                    return ["use", translated, conclusion,
                            translate_proof(child, inner, reverse)]
                conclusion, child = arguments
                return ["use", translated, translate_proof(child, inner, reverse)]
            annotation, child = arguments
            return ["use", translated, annotation,
                    translate_proof(child, context, reverse)]
        case ["nat", matrix, step]:
            return ["nat", matrix, translate_proof(step, context, reverse)]
        case _:
            return proof


def translate(data, reverse=False):
    source, target = ((candidate, baseline) if reverse else
                      (baseline, candidate))
    canonical = erase_false(data)
    source.check(canonical)
    context, conclusion, proof = canonical
    result = [context, conclusion, translate_proof(proof, context, reverse)]
    target.check(result)
    return result


if __name__ == "__main__":
    direction, path = sys.argv[1:]
    if direction not in ("forward", "reverse"):
        raise ValueError("direction must be forward or reverse")
    with open(path, encoding="utf-8") as stream:
        translated = translate(json.load(stream), reverse=direction == "reverse")
    print(json.dumps(translated, separators=(",", ":")))
