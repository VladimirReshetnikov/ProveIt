"""Finite regression and binding checks; this is not part of acceptance."""

import hashlib
import json
import random
import subprocess
import sys
from pathlib import Path

import baseline
import candidate
import translate

ROOT = Path(__file__).resolve().parent


def accepts(checker, data):
    try:
        checker.check(data)
        return True
    except (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError):
        return False


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, separators=(",", ":")) + "\n")


def regression():
    folder = ROOT / "fixtures/baseline"
    manifest = json.loads((folder / "manifest.json").read_text())
    results = []
    for row in manifest["records"]:
        path = folder / row["file"]
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != row["sha256"]:
            raise ValueError("Changed fixture: " + row["file"])
        data = translate.erase_false(json.loads(raw))
        expected = row["expected"]
        if accepts(baseline, data) != expected:
            raise ValueError("Baseline fixture label disagrees: " + row["name"])
        if expected:
            changed = translate.translate(data)
            returned = translate.translate(changed, reverse=True)
            if returned[:2] != data[:2]:
                raise ValueError("Changed sequent: " + row["name"])
            status = "accepted_and_reverse_checked"
        else:
            try:
                g, a, p = data
                changed = [g, a, translate.translate_proof(p, g)]
            except (ValueError, TypeError, IndexError, KeyError, RecursionError):
                status = "rejected_during_untrusted_translation"
                changed = None
            else:
                if accepts(candidate, changed):
                    raise ValueError("Unexpected negative acceptance: " + row["name"])
                status = "rejected_by_candidate"
        if changed is not None:
            save_json(ROOT / "fixtures/candidate" / row["file"], changed)
        results.append({**row, "status": status})
    return results


def direct_cases():
    z = -1
    truth = ["=", z, z]
    body = ["=", 0, 0]
    exists = ["ex", body]
    # C depends on an outer parameter under pi, ex, and two recursor binders.
    complex_formula = ["pi", ["=", 0, 0],
                       ["ex", ["=", ["r", 1, 2,
                                      ["r", 1, 4, ["s", 0]]], 2]]]
    rows = []

    def add(name, data, expected):
        got = accepts(candidate, data)
        if got != expected:
            raise ValueError("Direct test disagrees: " + name)
        if expected:
            back = translate.translate(data, reverse=True)
            if back[:2] != data[:2]:
                raise ValueError("Direct test changed sequent: " + name)
        path = ROOT / "fixtures/direct" / (name + ".json")
        save_json(path, data)
        rows.append({"name": name, "expected": expected,
                     "file": str(path.relative_to(ROOT)),
                     "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})

    add("retained_parameter_below_four_binders",
        [[exists, complex_formula], complex_formula,
         ["use", exists, candidate.subst(complex_formula)]], True)
    add("retained_parameter_simple",
        [[exists, ["=", 0, 0]], ["=", 0, 0],
         ["use", exists, ["=", 1, 1]]], True)
    add("existential_witness_local_binder_preserved",
        [[exists, complex_formula], ["ex", candidate.subst(complex_formula)],
         ["pack", z, candidate.subst(complex_formula)]], True)

    escape_bodies = {
        "escape_atom": ["=", 0, 0],
        "escape_pi_guard": ["pi", ["=", 1, 1], truth],
        "escape_pi_consequent": ["pi", truth, ["=", 1, 1]],
        "escape_nested_quantifiers": ["pi", truth, ["ex", ["=", 2, 2]]],
        "escape_recursor_body": ["=", ["r", z, z, 2], z],
        "escape_nested_recursor": ["=", ["r", z, z,
                                         ["r", z, z, 4]], z],
    }
    for name, escaped in escape_bodies.items():
        premise = ["ex", escaped]
        add(name, [[premise], truth, ["use", premise, escaped]], False)
    add("existential_old_redundant_goal_rejected",
        [[exists, truth], truth, ["use", exists, truth, truth]], False)
    add("existential_missing_child", [[exists], truth, ["use", exists]], False)

    matrix = ["ex", ["=", 0, 1]]
    base = candidate.subst(matrix, [z, 0])
    successor = candidate.subst(matrix, [["s", 0], 0])
    bad_step = ["pi", matrix, successor]
    good_step = ["pi", base, successor]
    add("quantified_case_rule", [[good_step], ["pi", base, matrix],
                                  ["nat", matrix, good_step]], True)
    add("quantified_induction_rejected", [[bad_step], ["pi", base, matrix],
                                          ["nat", matrix, bad_step]], False)

    malformed_counters = [0, 1, ["r", z, z, z], ["s"], ["s", z, z],
                          True, False, 1.0, None, {}, "s", -2]
    for i, counter in enumerate(malformed_counters):
        add("bad_counter_" + str(i), [[], truth, ["r", counter, z, z]], False)
    for i, malformed in enumerate([True, 0.0, -2, None, {}, ["s"],
                                    ["r", z, z], ["pi", truth, truth]]):
        add("bad_recursion_body_" + str(i),
            [[], truth, ["r", z, z, malformed]], False)
    add("bad_formula_sort", [[], ["s", z], ["r", z, z, z]], False)
    add("falsity_alias_is_not_native", [[], ["false"], ["r", z, z, z]], False)
    add("false_cannot_be_a_theorem", [[], ["=", z, ["s", z]], ["=", z, ["s", z]]], False)
    return rows


def lowering_checks():
    rng = random.Random(643729)
    widths = {"s": (0,), "r": (0, 0, 2), "=": (0, 0),
              "pi": (1, 1), "ex": (1,)}

    def term(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return rng.randrange(-1, 7)
        if rng.randrange(2):
            return ["s", term(depth - 1)]
        return ["r", term(depth - 1), term(depth - 1), term(depth - 1)]

    def formula(depth):
        if depth == 0 or rng.randrange(3) == 0:
            return ["=", term(3), term(3)]
        if rng.randrange(2):
            return ["ex", formula(depth - 1)]
        return ["pi", formula(depth - 1), formula(depth - 1)]

    def free_slots(value, depth=0):
        if type(value) is int:
            return {value - depth} if value >= depth else set()
        result = set()
        for child, width in zip(value[1:], widths[value[0]], strict=True):
            result |= free_slots(child, depth + width)
        return result

    def independent_lower(value, depth=0):
        if type(value) is int:
            if value == depth:
                raise ValueError("escaping numerical slot")
            return value - 1 if value > depth else value
        return [value[0], *(independent_lower(child, depth + width)
                            for child, width in zip(value[1:], widths[value[0]], strict=True))]

    good = bad = 0
    for i in range(2000):
        is_formula = bool(i % 2)
        value = formula(4) if is_formula else term(5)
        expected = 0 not in free_slots(value)
        try:
            dropped = candidate.subst(value, [None, -1], formula=is_formula)
        except (ValueError, TypeError, IndexError, KeyError, RecursionError):
            if expected:
                raise ValueError("False freshness rejection")
            bad += 1
        else:
            if not expected or dropped != independent_lower(value):
                raise ValueError("Incorrect lowering result")
            if candidate.subst(dropped, formula=is_formula) != value:
                raise ValueError("Lowering/lifting identity failed")
            good += 1
    return {"seed": 643729, "cases": 2000, "accepted": good,
            "escape_rejections": bad,
            "oracle": "Independent free-slot traversal and direct index decrement"}


def cli_checks(records):
    count = 0
    for row in records:
        path = ROOT / row["file"]
        expected = (0, "ACCEPT\n") if row["expected"] else (1, "REJECT\n")
        for optimized in (False, True):
            args = [sys.executable, *(["-O"] if optimized else []),
                    str(ROOT / "candidate.py"), str(path)]
            result = subprocess.run(args, capture_output=True, text=True)
            if (result.returncode, result.stdout) != expected:
                raise ValueError("CLI mismatch: " + row["name"])
            count += 1
    malformed = ROOT / "fixtures/malformed.json"
    malformed.write_text("[\n")
    for extras in ([], [str(malformed)], ["missing-file.json"],
                   [str(malformed), str(malformed)]):
        result = subprocess.run([sys.executable, str(ROOT / "candidate.py"), *extras],
                                capture_output=True, text=True)
        if (result.returncode, result.stdout) != (1, "REJECT\n"):
            raise ValueError("Malformed CLI did not reject")
        count += 1
    return count


def main():
    rows = regression()
    direct = direct_cases()
    lowering = lowering_checks()
    cli = cli_checks(direct)
    counts = {key: sum(row["status"] == key for row in rows)
              for key in ("accepted_and_reverse_checked", "rejected_by_candidate",
                          "rejected_during_untrusted_translation")}
    report = {"status": "passed", "baseline_regression": {"cases": len(rows), **counts},
              "new_direct_cases": {"cases": len(direct),
                                   "positive": sum(row["expected"] for row in direct),
                                   "negative": sum(not row["expected"] for row in direct)},
              "lowering": lowering, "cli_invocations": cli,
              "regression_records": rows, "direct_records": direct,
              "qualification": "Finite tests and executable translations are evidence, not a formal proof of kernel soundness."}
    (ROOT / "validation_results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ("regression_records", "direct_records")}, indent=2))


if __name__ == "__main__":
    main()
