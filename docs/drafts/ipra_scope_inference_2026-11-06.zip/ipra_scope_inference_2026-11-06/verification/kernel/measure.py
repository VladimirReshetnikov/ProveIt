"""Count complete checker files with the current draft's normalization."""

import ast
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    data = path.read_bytes()
    source = data.decode("utf-8")
    tree = ast.parse(source)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                spans.append(((doc.lineno, doc.col_offset), (doc.end_lineno, doc.end_col_offset)))
    excluded = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
                tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT}
    significant = [t for t in tokenize.generate_tokens(io.StringIO(source).readline)
                   if t.type not in excluded
                   and not any(lo <= t.start and t.end <= hi for lo, hi in spans)]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    norm_tokens = [t for t in tokenize.generate_tokens(io.StringIO(normalized).readline)
                   if t.type not in excluded]
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    return {"sha256": hashlib.sha256(data).hexdigest(),
            "raw_bytes": len(data), "normalized_bytes": len(normalized.encode()),
            "source_tokens": len(significant), "normalized_tokens": len(norm_tokens),
            "ast_nodes": sum(1 for _ in ast.walk(tree)),
            "lines": len(source.splitlines()), "imported_modules": sorted(set(imports))}


def main():
    files = ["baseline.py", "candidate_inferred.py", "candidate_rec_unpacked.py",
             "candidate_fused.py", "candidate.py"]
    result = {"python": platform.python_version(),
              "method": "Complete acceptance sources; docstrings/comments/layout excluded from primary metrics.",
              "ablation_chain": [{"file": f, "metrics": measure(ROOT / f)} for f in files]}
    (ROOT / "metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
