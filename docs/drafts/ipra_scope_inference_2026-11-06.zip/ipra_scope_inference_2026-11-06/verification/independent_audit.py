#!/usr/bin/env python3
"""Independent tests of eigenvariable lowering and recursion discrimination.

Usage: python3 independent_audit.py [path/to/checker.py]
Default candidate: ../checker.py relative to this script.
Only the tested checker is imported; the oracle uses named variables and
never calls its substitution, syntax table, or inference implementation.
"""

import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile


class Escape(Exception):
    pass


class NamedOracle:
    def __init__(self):
        self.counter = 0

    def fresh(self):
        self.counter += 1
        return ("bound", self.counter)

    def term(self, tree, bound=()):
        if type(tree) is int:
            if tree == -1:
                return ("zero",)
            if tree < -1:
                raise ValueError("bad index")
            return bound[tree] if tree < len(bound) else ("free", tree - len(bound))
        if type(tree) is not list:
            raise ValueError("bad term")
        if len(tree) == 2 and tree[0] == "s":
            return ("s", self.term(tree[1], bound))
        if len(tree) == 4 and tree[0] == "r":
            u, v = self.fresh(), self.fresh()
            return ("r", self.term(tree[1], bound), self.term(tree[2], bound),
                    u, v, self.term(tree[3], (u, v) + bound))
        raise ValueError("bad term")

    def formula(self, tree, bound=()):
        if type(tree) is not list:
            raise ValueError("bad formula")
        if len(tree) == 3 and tree[0] == "=":
            return ("=", self.term(tree[1], bound), self.term(tree[2], bound))
        if len(tree) == 3 and tree[0] == "pi":
            y = self.fresh()
            return ("pi", y, self.formula(tree[1], (y,) + bound),
                    self.formula(tree[2], (y,) + bound))
        if len(tree) == 2 and tree[0] == "ex":
            y = self.fresh()
            return ("ex", y, self.formula(tree[1], (y,) + bound))
        raise ValueError("bad formula")

    def encode(self, node, bound=(), lower=False):
        kind = node[0]
        if kind == "zero":
            return -1
        if kind == "bound":
            return bound.index(node)
        if kind == "free":
            k = node[1]
            if lower and k == 0:
                raise Escape("the existential witness occurs free")
            return len(bound) + k - int(lower)
        if kind in ("s", "="):
            return [kind, *(self.encode(child, bound, lower) for child in node[1:])]
        if kind == "r":
            _, n, a, u, v, h = node
            return ["r", self.encode(n, bound, lower), self.encode(a, bound, lower),
                    self.encode(h, (u, v) + bound, lower)]
        if kind == "pi":
            _, y, a, b = node
            return ["pi", self.encode(a, (y,) + bound, lower),
                    self.encode(b, (y,) + bound, lower)]
        if kind == "ex":
            _, y, a = node
            return ["ex", self.encode(a, (y,) + bound, lower)]
        raise ValueError("bad named node")

    def lower(self, formula):
        named = self.formula(formula)
        assert self.encode(named) == formula
        return self.encode(named, lower=True)

    def recursion_step(self, n, a, h):
        # Decode the replacement expressions in the OUTER numerical context.
        old_state = self.term(["r", n, a, h])
        old_counter = self.term(n)
        body = self.term(h)

        def replace(node):
            tag = node[0]
            if tag == "free":
                k = node[1]
                if k == 0:
                    return old_state
                if k == 1:
                    return old_counter
                return ("free", k - 2)
            if tag in ("zero", "bound"):
                return node
            if tag == "s":
                return ("s", replace(node[1]))
            if tag == "r":
                _, count, init, u, v, step = node
                return ("r", replace(count), replace(init), u, v, replace(step))
            raise ValueError("unexpected named term")

        return self.encode(replace(body))


def main():
    candidate = (Path(sys.argv[1]) if len(sys.argv) > 1 else
                 Path(__file__).resolve().parent.parent / "checker.py").resolve()
    spec = importlib.util.spec_from_file_location("targeted_checker", candidate)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    counts = {"lowering_legal": 0, "lowering_escape": 0,
              "constructed_minor": 0, "recursion_step": 0,
              "recursion_reject": 0, "malformed_existential": 0,
              "lookup_aliases": 0, "cli": 0}
    failures = []
    alias_results = []
    caught_by_cli = (ValueError, TypeError, IndexError, KeyError, RecursionError, OSError)

    def invoke(call):
        try:
            return True, call()
        except Exception as exc:
            if not isinstance(exc, caught_by_cli):
                failures.append({"kind": "uncaught exception", "exception": repr(exc)})
            return False, type(exc).__name__

    def fail(label, **data):
        failures.append({"kind": label, **data})

    def lowering_case(body, label):
        body = json.loads(json.dumps(body, allow_nan=False))
        try:
            expected = NamedOracle().lower(body)
            legal = True
        except Escape:
            expected, legal = None, False
        ok, actual = invoke(lambda: checker.subst(body, [None, -1]))
        if ok != legal or (ok and actual != expected):
            fail("lowering", label=label, body=body, expected=expected,
                 legal=legal, actual=actual, accepted=ok)
        principal = ["ex", body]
        proof = ["use", principal, body]
        inferred, conclusion = invoke(lambda: checker.infer(proof, [principal]))
        if inferred != legal or (inferred and conclusion != expected):
            fail("existential inference", label=label, body=body, expected=expected,
                 legal=legal, actual=conclusion, accepted=inferred)
        if legal:
            ok, value = invoke(lambda: checker.check([[principal], expected, proof]))
            if not ok or value is not True:
                fail("public check", label=label, actual=value)
        counts["lowering_legal" if legal else "lowering_escape"] += 1

    # Exhaust every combination of up to two logical scopes and up to two
    # term contexts, including BOTH guarded-binder children and the recursor's
    # counter, initializer and two-slot body. Compare witness, outer parameter,
    # bound local and zero at the chosen leaf.
    formula_paths = [p for size in range(3)
                     for p in itertools.product(("pi-left", "pi-right", "ex"), repeat=size)]
    term_paths = [p for size in range(3)
                  for p in itertools.product(("s", "r-count", "r-init", "r-body"), repeat=size)]
    truth = ["=", -1, -1]
    for fp, tp, side in itertools.product(formula_paths, term_paths, (0, 1)):
        depth = len(fp) + 2 * tp.count("r-body")
        leaves = [("witness", depth), ("outer", depth + 1), ("zero", -1)]
        if depth:
            leaves.append(("bound", depth - 1))
        for desc, leaf in leaves:
            term = leaf
            for context in reversed(tp):
                if context == "s":
                    term = ["s", term]
                elif context == "r-count":
                    term = ["r", term, -1, -1]
                elif context == "r-init":
                    term = ["r", -1, term, -1]
                else:
                    term = ["r", -1, -1, term]
            body = ["=", term, -1] if side == 0 else ["=", -1, term]
            for context in reversed(fp):
                if context == "pi-left":
                    body = ["pi", body, truth]
                elif context == "pi-right":
                    body = ["pi", truth, body]
                else:
                    body = ["ex", body]
            lowering_case(body, [fp, tp, side, desc])

    # Independent deterministic mixed trees, with scopes deeper than the
    # bounded path grid and large free indices.
    rng = random.Random(761903)

    def random_term(depth, fuel):
        choice = rng.randrange(5) if fuel else 0
        if choice <= 1:
            return rng.choice([-1, *range(depth + 4), 10**40])
        if choice == 2:
            return ["s", random_term(depth, fuel - 1)]
        return ["r", random_term(depth, fuel - 1), random_term(depth, fuel - 1),
                random_term(depth + 2, fuel - 1)]

    def random_formula(depth, fuel):
        choice = rng.randrange(4) if fuel else 0
        if choice <= 1:
            return ["=", random_term(depth, min(fuel, 2)), random_term(depth, min(fuel, 2))]
        if choice == 2:
            return ["pi", random_formula(depth + 1, fuel - 1),
                    random_formula(depth + 1, fuel - 1)]
        return ["ex", random_formula(depth + 1, fuel - 1)]

    for i in range(200):
        lowering_case(random_formula(0, 4), ["mixed", i])

    # Minor derivations that INTRODUCE a further binder, rather than merely
    # return the existential assumption. The witness may occur in the proof
    # and its chosen term; only its occurrence in the conclusion is forbidden.
    principal = ["ex", ["=", 0, 0]]
    constructed = [
        ("lambda escape", ["lam", ["=", 0, 0], ["=", 1, 1]], False, None),
        ("pack escape", ["pack", 0, ["=", 0, 1]], False, None),
        ("pack hides chosen witness", ["pack", 0, ["r", -1, 0, -1]], True,
         ["ex", ["=", ["r", -1, 0, -1], 0]]),
    ]
    for label, minor, legal, expected in constructed:
        proof = ["use", principal, minor]
        ok, actual = invoke(lambda: checker.infer(proof, [principal]))
        if ok != legal or (ok and actual != expected):
            fail("constructed minor", label=label, accepted=ok, actual=actual, expected=expected)
        if legal and not checker.check([[principal], expected, proof]):
            fail("constructed minor public check", label=label)
        counts["constructed_minor"] += 1

    # Sorted validation must run before the two-item recursion-counter
    # destructuring. This rejects valid non-successor terms and invalid trees.
    counters = [0, 1, 10**40, ["r", -1, -1, -1], ["r", ["s", -1], -1, 0],
                None, True, False, 0.0, 1.5, "s", "s0", "r000", {},
                {"s": None, "0": None}, [], ["s"], ["s", -1, -1],
                ["other", -1], ["=", -1, -1], ["r", -1, -1], -2]
    for counter in counters:
        proof = ["r", counter, -1, -1]
        ok, actual = invoke(lambda: checker.infer(proof, []))
        if ok:
            fail("non-successor recursion accepted", counter=counter, actual=actual)
        counts["recursion_reject"] += 1

    terms = [-1, 0, 3, ["s", 1], ["r", -1, 2, 0]]
    bodies = [-1, 0, 1, 2, ["s", 0], ["r", -1, 0, ["s", 2]],
              ["r", 1, 2, ["r", 2, 3, ["s", 4]]]]
    for n, a, h in itertools.product(terms, (-1, 4), bodies):
        proof = ["r", ["s", n], a, h]
        expected = ["=", proof, NamedOracle().recursion_step(n, a, h)]
        ok, actual = invoke(lambda: checker.infer(proof, []))
        if not ok or actual != expected:
            fail("successor recursion", proof=proof, actual=actual, expected=expected)
        elif not checker.check([[], expected, proof]):
            fail("successor recursion public check", proof=proof)
        counts["recursion_step"] += 1

    # Invalid eliminator arities and malformed witness occurrences.
    e = ["ex", truth]
    malformed = [["use", e], ["use", e, truth, truth], ["use", e, truth, truth, truth],
                 ["use", e, None], ["use", e, {"=": None, "-1": None}],
                 ["use", e, "ex"], ["use", e, ["=", None, None]]]
    for proof in malformed:
        ok, actual = invoke(lambda: checker.infer(proof, [e]))
        if ok:
            fail("malformed existential accepted", proof=proof, actual=actual)
        counts["malformed_existential"] += 1

    # A membership key need not itself be a canonical formula: Python compares
    # booleans/floats with integer leaves. Acceptance is safe only because the
    # implementation returns the validated context entry, not the supplied key.
    aliases = [
        (["=", 0, 0], ["=", False, False]),
        (["=", 0, 0], ["=", 0.0, -0.0]),
        (["pi", ["=", 0, 0], ["=", ["s", 0], 1]],
         ["pi", ["=", False, 0.0], ["=", ["s", False], True]]),
    ]
    for formula, key in aliases:
        ok, actual = invoke(lambda: checker.infer(key, [formula]))
        if ok and (actual is not formula or not checker.check([[formula], formula, key])):
            fail("lookup alias returned unvalidated key", key=key, actual=actual)
        alias_results.append({"key": key, "accepted": ok,
                              "returns_validated_context_entry": bool(ok and actual is formula)})
        counts["lookup_aliases"] += 1

    # Verify that the actual command-line boundary handles the exceptions
    # used above and accepts an ordinary well-scoped elimination certificate.
    cli_cases = [
        ("valid elimination", [[e], truth, ["use", e, truth]], True),
        ("escaping witness", [[principal], truth, ["use", principal, principal[1]]], False),
        ("missing minor", [[e], truth, ["use", e]], False),
        ("extra minor", [[e], truth, ["use", e, truth, truth]], False),
        ("variable recursion counter", [[], truth, ["r", 0, -1, -1]], False),
        ("null input", None, False),
    ]
    with tempfile.TemporaryDirectory(prefix="ipra-targeted-") as temp:
        for label, data, legal in cli_cases:
            path = Path(temp) / "certificate.json"
            path.write_text(json.dumps(data, allow_nan=False), encoding="utf-8")
            proc = subprocess.run([sys.executable, str(candidate), str(path)],
                                  text=True, capture_output=True, timeout=10)
            expected_status = 0 if legal else 1
            expected_output = "ACCEPT" if legal else "REJECT"
            if (proc.returncode != expected_status or proc.stdout.strip() != expected_output
                    or proc.stderr):
                fail("CLI", label=label, code=proc.returncode,
                     stdout=proc.stdout, stderr=proc.stderr)
            counts["cli"] += 1
        for args in ([], ["one", "two"]):
            proc = subprocess.run([sys.executable, str(candidate), *args],
                                  text=True, capture_output=True, timeout=10)
            if proc.returncode != 1 or proc.stdout.strip() != "REJECT" or proc.stderr:
                fail("CLI argument count", args=args, code=proc.returncode,
                     stdout=proc.stdout, stderr=proc.stderr)
            counts["cli"] += 1

    result = {
        "candidate": candidate.name,
        "sha256": hashlib.sha256(candidate.read_bytes()).hexdigest(),
        "scope": "Independent named-variable oracle: existential eigenvariable removal, nested binding, and validated unary recursion discrimination",
        "counts": counts,
        "noncanonical_lookup_keys": alias_results,
        "total_cases": sum(counts.values()),
        "failures": failures,
        "passed": not failures,
        "limits": "Finite targeted tests supplement the accompanying structural soundness argument; they are not a formal proof or an exhaustive audit of the whole checker.",
    }
    output = Path(__file__).with_name("independent_audit_results.json")
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
