"""Exact certificates for the four-set deletion profile. Run with Python 3."""
from functools import lru_cache

K = 4
TOP = 15
E = (0, 10, 8, 6)
ZERO = (0,) * K

def imbalance(patterns):
    return tuple(sum(2 * ((x >> i) & 1) - 1 for x in patterns) for i in range(K))

def plus(left, right):
    return tuple(x + y for x, y in zip(left, right))

def ceildiv(a, b):
    return -((-a) // b)

def bottom(ell):
    return [0, TOP] + [TOP ^ (1 << i) for i in range(ell)]

def compatible(present, base):
    return all((x | y) in present for x in present for y in present.union(base))

def catalog():
    """Group usable slice types by bottom. Empty slice has zero imbalance."""
    groups = [set() for _ in range(5)]
    for mask in range(1 << TOP):
        holes = [x for x in range(TOP) if (mask >> x) & 1]
        d = len(holes)
        u = imbalance(holes)
        if max(u) <= 0:
            continue
        present = set(range(TOP + 1)).difference(holes)
        if not compatible(present, set(bottom(0))):
            continue
        waste = 4*d - 7*sum(u)
        assert waste >= 0
        # All searches below have total available waste <= 36.
        if waste <= 36:
            for ell in range(5):
                if compatible(present, set(bottom(ell))):
                    groups[ell].add((waste, d, u))
    return [sorted(g) for g in groups]

def verify_periodic_lower_bound(types):
    stars = {(7, tuple(7 if i == j else -1 for i in range(K))) for j in range(K)}
    assert {(d, u) for w, d, u in types if w == 0} == stars
    exceptional = [item for item in types if item[0] > 0]
    assert exceptional[0][0] == 10
    for r in range(4):
        b = 7*r + E[r] - 1
        max_waste = 4*b - 28*r
        def attainable(start, spent_waste, spent, u):
            # Counts of stars may be signed after period reduction.
            for n in range(ceildiv(4*r - sum(u), 4), (b - spent)//7 + 1):
                if sum(ceildiv(r - x + n, 8) for x in u) <= n:
                    return True
            for j in range(start, len(exceptional)):
                w, d, v = exceptional[j]
                if spent_waste + w > max_waste:
                    break
                if attainable(j, spent_waste+w, spent+d, plus(u, v)):
                    return True
            return False
        assert not attainable(0, 0, 0, ZERO)

def verify_bases_with_triples(groups):
    checked = []
    for t in range(1, 9):
        cap = 14 + 7*t + E[t % 4] - 1
        if 6 + 9*t > cap:
            continue
        checked.append(t)
        for ell in range(1, 5):
            base = bottom(ell)
            b = cap - (16 - len(base))
            need = plus(imbalance(base), (t,) * K)
            bound = 4*b - 7*sum(need)
            assert bound <= 36
            types = [(d, u) for w, d, u in groups[ell] if w <= bound]
            @lru_cache(maxsize=None)
            def attainable(money, residual):
                if max(residual) <= 0:
                    return True
                if max(residual) > money or 7*sum(residual) > 4*money:
                    return False
                return any(attainable(money-d, tuple(x-y for x,y in zip(residual,u)))
                           for d,u in types if d <= money)
            assert not attainable(b, need)
    assert checked == [1, 2, 3, 5, 6]

def verify_constructions():
    star = lambda i: [x for x in range(15) if x & (1 << i)]
    h1 = [2,3,6,7,10,11]
    h2 = [4,5,6,7,12,13]
    h3 = [8,9,10,11,12,13]
    witnesses = {
        1: (1, [h1,h2,h3]),
        2: (0, [[1,3,5,7,8,9,10,11,12,13,14],
                [2,3,4,5,6,7,10,11,12,13,14]]),
        3: (0, [star(3),star(2),star(1),[1,3,5,7,9,11]]),
        4: (0, [star(i) for i in range(4)]),
        5: (0, [h3,h3,star(2),star(2),h1,h1,star(0)])
    }
    for t,(ell,holes) in witnesses.items():
        base = set(bottom(ell))
        s = tuple(-x for x in imbalance(base))
        d = 16 - len(base)
        for h in holes:
            present = set(range(16)).difference(h)
            assert compatible(present, base)
            s = plus(s, imbalance(h))
            d += len(h)
        assert min(s) >= t
        assert d == 14 + 7*t + E[t % 4]
        print(f't={t}: witness d={d}, deficits={s}')

if __name__ == '__main__':
    groups = catalog()
    verify_periodic_lower_bound(groups[0])
    verify_bases_with_triples(groups)
    verify_constructions()
    print('All four-coordinate lower bounds and witnesses verified.')
