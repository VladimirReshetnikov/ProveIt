// Enumerate support patterns on five named generators and test Theorem 1's
// two numerical inequalities, using only exact integer operations.
// Build: c++ -O3 -std=c++20 verify_five.cpp -o verify_five
// Run: ./verify_five       or      ./verify_five --all (disable symmetry)
#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <string_view>
#include <vector>

using Mask = std::uint32_t;
constexpr int generators = 5;
constexpr int subsets = 1 << generators;
constexpr int types = 25;  // C(5,1)+C(5,2)+C(5,3)
constexpr Mask limit = Mask{1} << types;
using Permutation = std::array<int, types>;

int main(int argc, char** argv) {
    bool all = argc == 2 && std::string_view(argv[1]) == "--all";
    if (argc > 1 && !all) {
        std::cerr << "Usage: verify_five [--all]\n";
        return 2;
    }
    std::array<int, types> signature{};
    std::array<int, subsets> index{};
    int count = 0;
    for (unsigned s = 1; s < subsets; ++s) {
        if (std::popcount(s) <= 3) {
            signature[count] = s;
            index[s] = count++;
        }
    }
    if (count != types) return 2;

    // hit[g] gives the types seen in the union of the generators in g.
    std::array<Mask, subsets> hit{};
    std::array<Mask, types> strict_supersets{};
    for (int i = 0; i < types; ++i) {
        for (int g = 0; g < subsets; ++g)
            if (g & signature[i]) hit[g] |= Mask{1} << i;
        for (int j = 0; j < types; ++j)
            if (j != i && (signature[j] & signature[i]) == signature[i])
                strict_supersets[i] |= Mask{1} << j;
    }

    std::vector<Permutation> permutations;
    if (!all) {
        std::array<int, generators> perm{0, 1, 2, 3, 4};
        do {
            Permutation image{};
            for (int i = 0; i < types; ++i) {
                int s = 0;
                for (int k = 0; k < generators; ++k)
                    if (signature[i] & (1 << k)) s |= 1 << perm[k];
                image[i] = index[s];
            }
            permutations.push_back(image);
        } while (std::next_permutation(perm.begin(), perm.end()));
    }

    std::vector<bool> seen(all ? 0 : limit, false);
    int representatives = 0, worst_numerator = 0, worst_denominator = 1;
    for (Mask pattern = 1; pattern < limit; ++pattern) {
        if (!all && seen[pattern]) continue;
        ++representatives;
        for (const auto& perm : permutations) {
            Mask image = 0;
            for (Mask bits = pattern; bits; bits &= bits - 1)
                image |= Mask{1} << perm[std::countr_zero(bits)];
            seen[image] = true;
        }

        std::array<Mask, subsets> traces{};
        for (int g = 0; g < subsets; ++g) traces[g] = hit[g] & pattern;
        std::sort(traces.begin(), traces.end());
        int m = std::unique(traces.begin(), traces.end()) - traces.begin();
        int sum = 0, loss = 0;
        for (Mask bits = pattern; bits; bits &= bits - 1) {
            int i = std::countr_zero(bits);
            if (pattern & strict_supersets[i]) continue;
            int frequency = 0;
            for (int j = 0; j < m; ++j) frequency += (traces[j] >> i) & 1u;
            int excess = 2 * frequency - m;
            sum += excess;
            loss += std::max(0, -excess);
        }
        if (sum < 0 || 13 * loss > 3 * m) {
            std::cerr << "Failed: pattern=" << pattern << " size=" << m
                      << " sum=" << sum << " loss=" << loss << '\n';
            return 1;
        }
        if (loss * worst_denominator > m * worst_numerator) {
            worst_numerator = loss;
            worst_denominator = m;
        }
    }
    int expected = all ? limit - 1 : 306015;
    if (representatives != expected || 13 * worst_numerator != 3 * worst_denominator) {
        std::cerr << "Unexpected pattern count or maximum.\n";
        return 1;
    }
    std::cout << "Nonempty labeled patterns covered: " << limit - 1
              << "\nPatterns tested: " << representatives
              << "\nLargest loss/fiber size: " << worst_numerator << '/'
              << worst_denominator << "\nBoth inequalities verified.\n";
}
