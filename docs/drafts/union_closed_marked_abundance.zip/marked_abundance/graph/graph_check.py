#!/usr/bin/env python3
"""Exact checks for the bounded-degree marked-edge theorem, in standard Python."""

import argparse
from fractions import Fraction
from itertools import combinations


def tree_gap(delta):
    d = delta - 1
    a = 2 ** (d * d)
    b = (1 + 2**d) ** d
    q = a + b
    total = q*q + (q-1)**2 + 2*b*(q-1)
    return Fraction(2*q-1, 2*total)


def counts(adjacency):
    """Count valid induced subgraphs, including the empty set, by vertices."""
    n = len(adjacency)
    occurrences = [0] * n
    total = 0
    for subset in range(1 << n):
        vertices = [v for v in range(n) if subset & (1 << v)]
        if all(adjacency[v] & subset for v in vertices):
            total += 1
            for v in vertices:
                occurrences[v] += 1
    return total, occurrences


def verify_graph(adjacency, edges, bounds):
    delta = max(row.bit_count() for row in adjacency)
    if delta < 2:
        return 0
    gap = bounds[delta]
    total, occurrences = counts(adjacency)
    tested = 0
    for x, y in edges:
        if (adjacency[x] | adjacency[y]).bit_count() <= 2:
            continue
        high = max(occurrences[x], occurrences[y])
        if (2*high - total) * gap.denominator < 2*total * gap.numerator:
            raise AssertionError((adjacency, (x, y), total, occurrences, gap))
        tested += 1
    return tested


def verify_all(n):
    pairs = list(combinations(range(n), 2))
    bounds = {d: tree_gap(d) for d in range(2, n)}
    marked_edges = 0
    for graph in range(1 << len(pairs)):
        edges = [edge for i, edge in enumerate(pairs) if graph & (1 << i)]
        adjacency = [0] * n
        for x, y in edges:
            adjacency[x] |= 1 << y
            adjacency[y] |= 1 << x
        marked_edges += verify_graph(adjacency, edges, bounds)
    return 1 << len(pairs), marked_edges


def verify_extremizer(delta):
    d = delta - 1
    edges = [(0, 1)]
    next_vertex = 2
    for endpoint in (0, 1):
        z = next_vertex
        next_vertex += 1
        edges.append((endpoint, z))
        for _ in range(d):
            w = next_vertex
            next_vertex += 1
            edges.append((z, w))
            for _ in range(d):
                edges.append((w, next_vertex))
                next_vertex += 1
    adjacency = [0] * next_vertex
    for x, y in edges:
        adjacency[x] |= 1 << y
        adjacency[y] |= 1 << x
    total, occurrences = counts(adjacency)
    gap = Fraction(2*max(occurrences[:2]) - total, 2*total)
    assert occurrences[0] == occurrences[1] and gap == tree_gap(delta)
    return total, occurrences[0], gap


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--max-n", type=int, default=6, choices=range(3, 8),
                        help="largest labeled order (7 is substantially slower)")
    args = parser.parse_args()
    for n in range(3, args.max_n + 1):
        graphs, edges = verify_all(n)
        print(f"n={n}: {graphs} labeled graphs, {edges} eligible marked edges verified")
    for delta in (2, 3):
        total, frequency, gap = verify_extremizer(delta)
        print(f"extremizer at degree {delta}: {frequency}/{total}, excess {gap}")
