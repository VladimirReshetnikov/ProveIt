"""Offline reproduction of finite checks and frozen complete-source measures."""
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    results = {"python": platform.python_version(), "checks": []}
    commands = [
        [sys.executable, "code/syntax_compiler.py", "--output", "evidence/formulas", "--maximum-k", "4"],
        [sys.executable, "code/sharp_syntax.py"],
        [sys.executable, "code/check_fusions.py"],
        [sys.executable, "code/verify_metrics.py"],
    ]
    for command in commands:
        completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        results["checks"].append({"command": command[1:], "exit_code": completed.returncode,
                                  "stdout": completed.stdout, "stderr": completed.stderr})
        if completed.returncode:
            raise RuntimeError(completed.stdout + completed.stderr)
    results["all_passed"] = True
    results["scope"] = "Finite artifact validation and measurements; no Lean/Rocq verification of metatheorems."
    (ROOT / "evidence/reproduction.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"all_passed": True, "checks": len(commands), "python": platform.python_version()}, indent=2))

if __name__ == "__main__":
    main()

