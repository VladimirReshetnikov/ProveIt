EXACT LOGICAL DEPTH IN A PAIRED-BINDER PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 9 November 2026
========================================================

STATUS OF THE REQUEST
The requested new complete axiomatization with a proof checker strictly
below the current source frontier was NOT obtained. This package does not
claim a global minimum or a completed solution of that minimization task.

NEW MATHEMATICAL RESULTS
1. Combining inherited fusion and selector bounds gives this new corollary:
   for every finite d, there is a classically everywhere-true arithmetic
   family whose minimum native depth under both HA-provable and iPRA-provable
   equivalence is exactly d.
2. For every d>=1 there is a classically total native depth-d family A_d
   with a total X-recursive selector of X-realizers exactly when
   0^(2d-1) <=_T X. The earlier general selector bound is therefore sharp.

These are representation/oracle results for the fixed paired-binder grammar,
not proof-checker source-size lower bounds. The sharp families are new
relative to the inspected corpus;
we do not claim exact depth for the earlier report's different negative family.
Literature-wide priority is not established.

The report reproduces the inherited one-layer existential-universal fusion
and the one-layer disjunction-of-implications bound in a transparent form.
Neither fusion bound is claimed as new. Their historical sources and
provenance are in reference/fusion_provenance/. The bounded-depth selector
lemma is also inherited; its sharpness at every depth is the new theorem.

START HERE
report.pdf                    Complete report.
report.tex                    Main editable source.
report_standalone.tex          Inlined source of all report sections.
sections/                     Editable mathematical sections.
code/                         Formula compilers and finite verification.
evidence/                     Generated formulas, measurements and receipts.
reference/checkers/           34 unchanged declared-complete comparators.
reference/closed_equational/  Attributed scalar arithmetic compiler.
reviews/                      Independent assistant mathematical reviews.
ATTRIBUTION.txt                New/inherited boundaries and source provenance.
CLAIMS.json                   Machine-readable status ledger.
MANIFEST.json                 SHA-256 and sizes of all payload files.

COMPLETE THEORY
The main report includes the entire inherited full-PR native basis:
all computation schemas; Use, DI, DE, Tr; freshness conditions; derivation
of the intuitionistic logical rules; literal-equation induction; a direct
whole-domain equality characteristic; all quantifier-free induction; and
both identity-domain interpretation composites with full first-order iPRA.
This basis is comparison material, not a newly smaller axiomatization.

SOURCE AUDIT
VladimirReshetnikov/ProveIt
Commit: 195e4becb0a1f99c5598f7e39e2cdeb81461b2e4
All 17 current docs/drafts archives were retrieved and Git-blob verified.
The 34 distinct programs classified as complete were remeasured as whole
sources under CPython 3.12.14.
Coordinate minima: 305 tokens / 340 AST nodes / 820 normalized bytes.
Strict structurally-total decoder profiles: 305 / 341 / 820.
Different programs attain the minima. Byte counts are identifier-sensitive.
The audit does not newly formalize or certify every inherited checker proof.

REPRODUCE
  python3 reproduce.py
  python3 build.py
  python3 package.py

The first command requires Python's standard library and no network.
The second requires a local pdfLaTeX installation and standard packages.
The third creates a ZIP and verifies all payload hashes and ZIP CRCs.
The included PDF is already compiled.

VERIFICATION SCOPE
New scripts expand native formulas, check binding and symbol arities,
measure actual formula depth, check finite intuitionistic fusion semantics,
and reproduce frozen whole-source metrics. Fixed PR matrix symbols R_r/E_k
are not evaluated; no Turing-jump oracle is implemented or postulated.
The scripts are not complete proof checkers for the new mathematical proofs.

The finite fusion check covers 10 labelled Kripke frames, 9843 valuations,
58320 worldwise fusion comparisons, and 136 LEM-specialization comparisons,
with zero failures and explicit negative controls.

The infinite mathematical results have complete written proofs and
independent assistant audits. No Lean/Rocq formalization or external
peer review is claimed. All repository access was read-only.

