"""Expand the sharp-selector family, including its concrete Boolean tag matrix.

R_r is a fixed Boolean PR matrix for a Sigma^0_r-complete predicate;
its code is not supplied or evaluated. No oracle enters the emitted syntax.
The matrix E_d is fully expanded using C, equality characteristic e,
pair projections, and R_r. See report equations S1--S8.
"""
import hashlib
import json
from pathlib import Path
from syntax_compiler import (
    Compiler, ZERO, variable, function, equation,
    validate, depth, counts, free_names, render,
)

ROOT = Path(__file__).resolve().parents[1]

def run():
    output = ROOT / "evidence/sharp_formulas"
    output.mkdir(parents=True, exist_ok=True)
    receipts = []
    one = function("S", ZERO)
    for d in range(1, 5):
        r = 2 * d - 1
        n, w = variable("n"), variable("w")
        arguments = [variable("a" + str(i)) for i in range(1, r + 1)]
        tag = function("left", w)
        witness = function("right", w)
        first = function("R" + str(r), n, witness, *arguments[:-1])
        second = function("R" + str(r), n, *arguments)
        matrix = function(
            "C", function("e", tag, ZERO), first,
            function("C", function("e", tag, one),
                     function("C", second, one, ZERO), one))
        native = equation(matrix, ZERO)
        compiler = Compiler()
        prefix = ["w"] + ["a" + str(i) for i in range(1, r + 1)]
        for i in reversed(range(d)):
            native = compiler.exists_forall(prefix[2*i], prefix[2*i+1], native)
        arities = {"S": 1, "P": 1, "C": 3, "e": 2, "left": 1, "right": 1,
                   "R" + str(r): r + 1}
        validate(native, arities)
        assert free_names(native) == {"n"} and depth(native) == d
        packet = {
            "d": d, "required_jump": r,
            "status": "Expanded finite syntax. R_r is a fixed Boolean PR matrix, not evaluated.",
            "matrix_definition": "C(e(left(w),0),R_r(n,right(w),a1,...,a(r-1)),C(e(left(w),1),C(R_r(n,a1,...,ar),1,0),1))=0",
            "arities": arities, "formula": native,
        }
        content = json.dumps(packet, indent=2) + "\n"
        (output / f"sharp_{d}.json").write_text(content)
        (output / f"sharp_{d}.txt").write_text(render(native) + "\n")
        receipts.append({"d": d, "native_depth": depth(native), "required_jump": r,
                         **counts(native), "free_variables": sorted(free_names(native)),
                         "sha256": hashlib.sha256(content.encode()).hexdigest()})
    result = {"scope": "Syntax, scope, and depth only; no truth or oracle evaluation.",
              "families": receipts}
    (output / "measurements.json").write_text(json.dumps(result, indent=2) + "\n")
    return result

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))

