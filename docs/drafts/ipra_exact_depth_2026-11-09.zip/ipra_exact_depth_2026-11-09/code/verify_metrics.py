"""Remeasure frozen complete sources with the inherited whole-source metric."""
import csv
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("frozen_measure", ROOT / "reference/source_measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)

def run():
    frozen = json.loads((ROOT / "evidence/current_complete_metrics.json").read_text())
    rows = []
    for source in frozen["sources"]:
        actual = measure.metrics(ROOT / source["path"])
        if actual["sha256"] != source["sha256"]:
            raise ValueError("Frozen source changed: " + source["path"])
        for key in ("normalized_tokens", "ast_nodes", "normalized_bytes"):
            if actual[key] != source[key]:
                raise ValueError(f"Metric changed for {source['path']}: {key}")
        rows.append({"label": source["label"], "path": source["path"], **actual})
    keys = ("normalized_tokens", "ast_nodes", "normalized_bytes")
    minima = {key: min(row[key] for row in rows) for key in keys}
    strict = [row for row in rows if row["label"] != "clock operational"]
    strict_minima = {key: min(row[key] for row in strict) for key in keys}
    assert minima == frozen["minima"]
    assert strict_minima == frozen["strict_minima"]
    result = {
        "python": platform.python_version(),
        "source_count": len(rows),
        "minima": minima, "strict_minima": strict_minima,
        "all_hashes_and_metrics_match": True,
        "scope": "Whole-source measurements, not a proof of checker correctness.",
    }
    (ROOT / "evidence/remeasurement.json").write_text(json.dumps(result, indent=2) + "\n")
    with (ROOT / "evidence/checker_metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=("label", "path", *keys, "sha256"), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return result

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))

