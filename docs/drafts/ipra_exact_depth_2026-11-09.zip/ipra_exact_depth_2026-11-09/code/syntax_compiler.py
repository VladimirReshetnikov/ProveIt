"""Construct native D-formulas witnessing the exact-depth theorem.

This is an untrusted finite syntax compiler, not an iPRA proof checker.
E_k is the name of a fixed PR characteristic matrix chosen for a positive
Sigma^0_(2k)-complete predicate. The script does not evaluate E_k, choose
truth-dependent witnesses, or decide any jump set. It expands every G/M/U/
Dec macro into native equations and D binders before measuring depth.

Run: python3 syntax_compiler.py --output generated --maximum-k 4
"""

import argparse
import hashlib
import json
from pathlib import Path


ZERO = ("0",)


def variable(name):
    return ("v", name)


def function(name, *arguments):
    return ("f", name, *arguments)


def equation(left, right):
    return ("=", left, right)


def paired(x, y, body):
    return ("D", x, y, body)


def term_names(term):
    if term[0] == "v":
        return {term[1]}
    if term[0] == "0":
        return set()
    return set().union(*(term_names(child) for child in term[2:]))


def free_names(formula):
    if formula[0] == "=":
        return term_names(formula[1]) | term_names(formula[2])
    return free_names(formula[3]) - {formula[1], formula[2]}


def all_names(formula):
    if formula[0] == "=":
        return free_names(formula)
    return {formula[1], formula[2]} | all_names(formula[3])


def term_substitute(term, mapping):
    if term[0] == "v":
        return mapping.get(term[1], term)
    if term[0] == "0":
        return term
    return function(term[1], *(term_substitute(a, mapping) for a in term[2:]))


def depth(formula):
    if formula[0] == "=":
        return 0
    return 1 + depth(formula[3])


def counts(formula):
    def terms(term):
        return 1 if term[0] in ("0", "v") else 1 + sum(terms(a) for a in term[2:])

    if formula[0] == "=":
        return {"formula_nodes": 1, "term_nodes": terms(formula[1]) + terms(formula[2])}
    child = counts(formula[3])
    return {"formula_nodes": child["formula_nodes"] + 1, "term_nodes": child["term_nodes"]}


class Compiler:
    def __init__(self):
        self.next_name = 0
        self.reserved = set()

    def fresh(self, avoid=()):
        avoid = set(avoid) | self.reserved
        while True:
            result = "_b" + str(self.next_name)
            self.next_name += 1
            if result not in avoid:
                self.reserved.add(result)
                return result

    def substitute(self, formula, mapping):
        """Simultaneous, capture-avoiding substitution of numerical terms."""
        if formula[0] == "=":
            return equation(term_substitute(formula[1], mapping),
                            term_substitute(formula[2], mapping))
        _, x, y, body = formula
        active = {key: value for key, value in mapping.items() if key not in (x, y)}
        image_names = set().union(*(term_names(value) for value in active.values()))
        avoid = all_names(formula) | image_names | set(active)
        renaming = {}
        binders = [x, y]
        for index, old in enumerate((x, y)):
            if old in image_names:
                new = self.fresh(avoid)
                avoid.add(new)
                binders[index] = new
                renaming[old] = variable(new)
        if renaming:
            body = self.substitute(body, renaming)
        return paired(*binders, self.substitute(body, active))

    def align(self, formula, x, y):
        return self.substitute(formula[3],
                               {formula[1]: variable(x), formula[2]: variable(y)})

    def gate(self, control, formula):
        if formula[0] == "=":
            return equation(function("C", control, ZERO, formula[1]),
                            function("C", control, ZERO, formula[2]))
        _, x, y, body = formula
        if {x, y} & term_names(control):
            avoid = all_names(formula) | term_names(control)
            x = self.fresh(avoid)
            y = self.fresh(avoid | {x})
            body = self.align(formula, x, y)
        return paired(x, y, self.gate(control, body))

    def select(self, control, left, right):
        if left[0] == "=" and right[0] == "=":
            return equation(function("C", control, left[1], right[1]),
                            function("C", control, left[2], right[2]))
        avoid = all_names(left) | all_names(right) | term_names(control)
        x = self.fresh(avoid)
        y = self.fresh(avoid | {x})
        first = self.align(left, x, y) if left[0] == "D" else self.gate(variable(y), left)
        second = self.align(right, x, y) if right[0] == "D" else self.gate(variable(y), right)
        return paired(x, y, self.select(control, first, second))

    def exists_forall(self, x, y, body):
        z = self.fresh(all_names(body) | {x, y})
        matrix = self.substitute(body, {y: function("P", variable(z))})
        return paired(x, z, self.gate(variable(z), matrix))

    def excluded_middle(self, formula):
        u = self.fresh(all_names(formula))
        v = self.fresh(all_names(formula) | {u})
        truth = equation(ZERO, ZERO)
        falsehood = equation(ZERO, function("S", ZERO))
        antecedent = self.select(variable(u), truth, formula)
        consequent = self.select(variable(u), formula, falsehood)
        return paired(u, v, self.select(variable(v), antecedent, consequent))

    def semidecision_middle(self):
        """Depth-one encoding of not-K or K for Boolean PR certificate R."""
        x = self.fresh({"n"})
        y = self.fresh({"n", x})
        negative_instance = equation(
            function("R", variable("n"), function("P", variable(y))),
            function("S", ZERO))
        positive_instance = equation(
            function("R", variable("n"), function("P", variable(x))), ZERO)
        selected = self.select(variable(x), negative_instance, positive_instance)
        return paired(x, y, self.gate(variable(y), selected))

    def complete_family(self, k):
        if type(k) is not int or k < 1:
            raise ValueError("k must be a positive integer")
        arguments = [variable("n")]
        for j in range(1, k + 1):
            arguments.extend((variable("x" + str(j)), variable("y" + str(j))))
        result = equation(function("E" + str(k), *arguments), ZERO)
        for j in range(k, 0, -1):
            result = self.exists_forall("x" + str(j), "y" + str(j), result)
        return result


def validate(formula, arities, free=("n",)):
    """Independent sorted traversal: no macros, undeclared symbols, or free leaks."""
    def term(value, scope):
        if value[0] == "0":
            assert len(value) == 1
        elif value[0] == "v":
            assert len(value) == 2 and value[1] in scope
        else:
            assert value[0] == "f" and value[1] in arities
            assert len(value) == arities[value[1]] + 2
            for child in value[2:]:
                term(child, scope)

    def formula_walk(value, scope):
        if value[0] == "=":
            assert len(value) == 3
            term(value[1], scope)
            term(value[2], scope)
        else:
            assert value[0] == "D" and len(value) == 4
            assert type(value[1]) is str and type(value[2]) is str
            assert value[1] != value[2]
            formula_walk(value[3], scope | {value[1], value[2]})

    formula_walk(formula, set(free))


def render(formula):
    def term(t):
        if t[0] == "0":
            return "0"
        if t[0] == "v":
            return t[1]
        return t[1] + "(" + ",".join(term(a) for a in t[2:]) + ")"

    if formula[0] == "=":
        return term(formula[1]) + "=" + term(formula[2])
    return "D[" + formula[1] + "," + formula[2] + "](" + render(formula[3]) + ")"


def generate(output, maximum_k):
    output.mkdir(parents=True, exist_ok=True)
    receipts = []
    endpoints = []
    endpoint_formulas = [equation(ZERO, ZERO), Compiler().semidecision_middle()]
    for expected_depth, formula in enumerate(endpoint_formulas):
        arities = {"S": 1, "P": 1, "C": 3, "R": 2}
        validate(formula, arities)
        assert depth(formula) == expected_depth
        assert free_names(formula) == (set() if expected_depth == 0 else {"n"})
        packet = {
            "exact_depth": expected_depth,
            "status": ("Truth equation." if expected_depth == 0 else
                       "R is a fixed Boolean PR halting-certificate predicate; not evaluated."),
            "arities": arities,
            "formula": formula,
        }
        content = json.dumps(packet, indent=2) + "\n"
        (output / ("depth_" + str(expected_depth) + ".json")).write_text(content)
        (output / ("depth_" + str(expected_depth) + ".txt")).write_text(render(formula) + "\n")
        endpoints.append({
            "native_depth": depth(formula),
            **counts(formula),
            "free_variables": sorted(free_names(formula)),
            "expanded_json_bytes": len(content.encode()),
            "sha256": hashlib.sha256(content.encode()).hexdigest(),
        })
    for k in range(1, maximum_k + 1):
        compiler = Compiler()
        positive = compiler.complete_family(k)
        decision = compiler.excluded_middle(positive)
        arities = {"S": 1, "P": 1, "C": 3, "E" + str(k): 2 * k + 1}
        validate(positive, arities)
        validate(decision, arities)
        assert free_names(positive) == free_names(decision) == {"n"}
        assert depth(positive) == k and depth(decision) == k + 1
        packet = {
            "k": k,
            "status": "Expanded syntax; E_k is a fixed PR matrix symbol, not evaluated.",
            "arities": arities,
            "positive_predicate": positive,
            "excluded_middle": decision,
        }
        content = json.dumps(packet, indent=2) + "\n"
        path = output / ("family_" + str(k) + ".json")
        path.write_text(content)
        (output / ("family_" + str(k) + ".txt")).write_text(
            "A_" + str(k) + "(n) = " + render(positive) + "\n\n"
            "B_" + str(k) + "(n) = " + render(decision) + "\n")
        receipts.append({
            "k": k,
            "positive_native_depth": depth(positive),
            "excluded_middle_native_depth": depth(decision),
            "positive_counts": counts(positive),
            "excluded_middle_counts": counts(decision),
            "free_variables": sorted(free_names(decision)),
            "expanded_json_bytes": len(content.encode()),
            "sha256": hashlib.sha256(content.encode()).hexdigest(),
        })
    # A capture-sensitive check: replacing a free y by a bound-name x must
    # rename the binder, keep the inserted x free, and not alter native depth.
    compiler = Compiler()
    source = paired("x", "z", equation(variable("x"), variable("y")))
    changed = compiler.substitute(source, {"y": variable("x")})
    assert free_names(changed) == {"x"} and changed[1] != "x" and depth(changed) == 1
    summary = {
        "scope": "Finite syntax generation and measurements; not proof checking or truth evaluation.",
        "capture_avoidance_case": "passed",
        "all_expansions_sorted_and_closed_except_n": True,
        "endpoints": endpoints,
        "families": receipts,
    }
    (output / "measurements.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "generated")
    parser.add_argument("--maximum-k", type=int, default=4)
    args = parser.parse_args()
    if args.maximum_k < 1:
        parser.error("--maximum-k must be positive")
    print(json.dumps(generate(args.output, args.maximum_k), indent=2))
