"""Independent finite Kripke checks of the two fusion identities.

This checks the endpoint interpretation for all persistent valuations on
all forward-labelled partial orders of 1--3 worlds. The quantifier domains
are represented by the exact selector/antecedent classes used in the
fusions, not by a finite model of arithmetic. The general theorems and
arithmetical hierarchy arguments remain manuscript proofs.
"""
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def orders(size):
    pairs = [(i, j) for i in range(size) for j in range(i + 1, size)]
    for bits in itertools.product((False, True), repeat=len(pairs)):
        relation = {(i, i) for i in range(size)} | {
            edge for edge, flag in zip(pairs, bits) if flag
        }
        if all((i, k) in relation
               for i, j in relation for jj, k in relation if j == jj):
            yield relation

def run():
    frames = valuations = comparisons = lemma_instances = 0
    ungated_failures = lem_nontruth_instances = 0
    for size in range(1, 4):
        universe = frozenset(range(size))
        for relation in orders(size):
            frames += 1
            upsets = []
            for bits in itertools.product((False, True), repeat=size):
                chosen = frozenset(i for i, flag in enumerate(bits) if flag)
                if all(i not in chosen or j in chosen for i, j in relation):
                    upsets.append(chosen)
            def implication(a, b):
                return frozenset(w for w in universe
                    if all(v not in a or v in b for ww, v in relation if ww == w))
            def paired(matrix):
                # matrix[x][0] is the base; all columns form the universal.
                result = frozenset()
                for row in matrix:
                    universal = universe.intersection(*row)
                    result |= implication(row[0], universal)
                return result
            for a, b, c, e in itertools.product(upsets, repeat=4):
                valuations += 1
                # J: zero witness has antecedent a and positive consequent b.
                actual_j = paired(((a, b), (c, e)))
                expected_j = implication(a, b) | implication(c, e)
                assert actual_j == expected_j
                # U: the zero gate is true; successors cover the two y-classes.
                actual_u = paired(((universe, a, b), (universe, c, e)))
                expected_u = (a & b) | (c & e)
                assert actual_u == expected_u
                comparisons += 2 * size
                # A deliberate missing-gate error must be detected.
                if paired(((a, b), (c, e))) != expected_u:
                    ungated_failures += 1
            for a in upsets:
                actual_lem = paired(((universe, a), (a, frozenset())))
                expected_lem = a | implication(a, frozenset())
                assert actual_lem == expected_lem
                lemma_instances += size
                if actual_lem != universe:
                    lem_nontruth_instances += 1
    assert ungated_failures and lem_nontruth_instances
    result = {
        "frames": frames, "four_formula_valuations": valuations,
        "worldwise_fusion_comparisons": comparisons,
        "worldwise_lem_comparisons": lemma_instances,
        "missing_gate_negative_controls_detected": ungated_failures,
        "lem_not_forced_everywhere_cases": lem_nontruth_instances,
        "failures": 0,
        "scope": "Finite intuitionistic endpoint semantics; not arithmetic model checking or a formal proof of the infinite hierarchy.",
    }
    (ROOT / "evidence/kripke_fusions.json").write_text(json.dumps(result, indent=2) + "\n")
    return result

if __name__ == "__main__":
    print(json.dumps(run(), indent=2))

