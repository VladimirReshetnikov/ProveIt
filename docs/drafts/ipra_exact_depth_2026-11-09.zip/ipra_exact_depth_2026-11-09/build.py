"""Build the editable manuscript without shell escape or network access."""
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent

def main():
    main = (ROOT / "report.tex").read_text()
    standalone = re.sub(r"\\input\{([^}]+)\}",
        lambda match: (ROOT / match.group(1)).read_text(), main)
    (ROOT / "report_standalone.tex").write_text(standalone)
    logs = []
    for number in range(3):
        result = subprocess.run(
            ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
             "-halt-on-error", "report.tex"],
            cwd=ROOT, capture_output=True, text=True)
        logs.append(result.stdout + result.stderr)
        if result.returncode:
            (ROOT / "evidence/latex_build.txt").write_text("\n".join(logs))
            raise RuntimeError(logs[-1][-6000:])
    (ROOT / "evidence/latex_build.txt").write_text("\n".join(logs))
    print("Built report.pdf with three successful pdfLaTeX passes.")

if __name__ == "__main__":
    main()

