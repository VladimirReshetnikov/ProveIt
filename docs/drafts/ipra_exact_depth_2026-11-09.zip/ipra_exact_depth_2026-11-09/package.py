"""Create a deterministic ZIP and verify member CRCs and payload hashes."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}

def payload():
    return sorted(p for p in ROOT.rglob("*")
        if p.is_file() and p.name != "MANIFEST.json"
        and p.suffix not in EXCLUDED and "__pycache__" not in p.parts)

def main():
    files = payload()
    entries = [{"path": str(p.relative_to(ROOT)), "size": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    (ROOT / "MANIFEST.json").write_text(json.dumps({"files": entries}, indent=2) + "\n")
    archive = ROOT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in [*files, ROOT / "MANIFEST.json"]:
            item = zipfile.ZipInfo(str(Path(ROOT.name) / path.relative_to(ROOT)),
                                   date_time=(2026, 11, 9, 12, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o100644 << 16
            output.writestr(item, path.read_bytes())
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        for entry in entries:
            data = check.read(str(Path(ROOT.name) / entry["path"]))
            assert len(data) == entry["size"]
            assert hashlib.sha256(data).hexdigest() == entry["sha256"]
    print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size,
                      "payload_files": len(entries), "crc_and_hashes_verified": True,
                      "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))

if __name__ == "__main__":
    main()

