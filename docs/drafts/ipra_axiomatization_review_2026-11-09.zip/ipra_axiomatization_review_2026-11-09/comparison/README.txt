FROZEN COMPLETE-CHECKER COMPARISON
=================================

All 41 Python files in this directory are copied byte for byte from the
current ProveIt draft archives at commit
08edc6964d8990d2230179a9d65355ac1eee7a9e. The filename prefix is the first
twelve hexadecimal digits of that source's SHA-256. manifest.json records
the full hash, exact source archive/member origins, expected whole-source
measurements, and which seven leading sources receive bounded CLI replay.
The original MIT No Attribution license is retained unchanged.

No new minimum is claimed. These are inherited comparison programs.
The package's new mathematical result, if any, is stated separately in
the report; no size here is assigned to a different proposed theory.

Run from the package directory:

  python3 code/reproduce_comparison.py

This verifies every hash and reproduces whole-module measurements for all
41 files without executing any of them. It writes comparison_receipt.json
and comparison_metrics.csv under evidence. Exact expected measurements use
CPython 3.12.14; a different Python unparser may change these numbers.
Imports, fixed tables, input parsing, checks, failure handling and output
remain charged. Only comments and genuine docstrings are removed.

  python3 code/replay_leading_checkers.py

This executes only the seven leading small sources, whose complete source
was inspected before inclusion. Each imports only standard-library json,
reads standard input, performs list/scalar proof checks, and prints a verdict.
The other 34 comparator programs are not executed by this replay.

The bounded replay has 25 cases in each of ordinary Python and python -O:
all 13 inherited public CLI cases; eight selected positive cases testing
compound cases, retained base, equality through a binder, existential and
closure elimination, nested recursion scope, and failed-major fallback;
one known initial-validation attack; and three documented noncanonical
aliases. This gives 350 process executions across seven programs.

The three aliases intentionally distinguish the iterable-tree source from
the six strict-array sources. They are accepted by clock_iterable.py and
rejected by the other six. No equality of those entire public languages is
claimed. The iterable source's treatment of malformed nonempty strings has
a documented Python recursion-limit qualification.

Minimum coordinates: 305 normalized tokens, 340 AST nodes, 820 normalized
bytes. Different programs attain them. Excluding the qualified iterable
profile changes the AST minimum to 341. Byte comparisons depend on names;
an inherited uniform-renaming control reaches 816 bytes.

These are finite-corpus measurements, not a mathematical lower-bound
theorem. Finite replay is regression evidence, not a formal proof of the
general arithmetic or interpretation metatheorems. The report and the
source provenance identify the underlying mathematical dependencies.
