"""Complete readable checker for the local-rewriting presentation of iPRA.

The command-line interface always checks the LOCAL calculus.  It reads one
JSON object and prints ACCEPT or REJECT.  The Python API additionally exposes
the general-transport and atomic-transport reference calculi for testing proof
translations; certificate data cannot select either reference mode.

All program declarations are fixed finite primitive-recursive descriptions.
They are syntax, not objects quantified over by the arithmetic theory.  The
checker unfolds one defining equation; it never evaluates a general program.

Only Python's standard json module is imported.  No assertion, project module,
proof producer, compressed payload, dynamic evaluation, or semantic oracle is
used by the acceptance algorithm.  See the report for the mathematical
soundness/completeness argument and the stated limits of machine verification.
"""

import json


class ProofError(ValueError):
    """A declaration, syntax tree, scope, or inference is invalid."""


def require(condition, message):
    if not condition:
        raise ProofError(message)


def fields(value, names, description):
    require(type(value) is dict, description + " must be an object")
    require(set(value) == set(names), description + " has incorrect fields")


def name(value):
    return type(value) is str and value.isidentifier()


def variable(value):
    return ["$", value]


def zero():
    return ["0"]


def successor(term):
    return ["S", term]


def truth_formula():
    return ["=", ["id", zero()], zero()]


def fv_term(term):
    if term[0] == "$":
        return {term[1]}
    result = set()
    for child in term[1:]:
        result.update(fv_term(child))
    return result


def fv_formula(formula):
    if formula[0] == "=":
        return fv_term(formula[1]) | fv_term(formula[2])
    return fv_formula(formula[3]) - {formula[1], formula[2]}


def all_names(formula):
    if formula[0] == "=":
        return fv_formula(formula)
    return {formula[1], formula[2]} | all_names(formula[3])


def fresh_name(used, prefix="_v"):
    number = 0
    while prefix + str(number) in used:
        number += 1
    return prefix + str(number)


def subst_term(term, mapping):
    if term[0] == "$":
        return mapping.get(term[1], term)
    return [term[0], *(subst_term(child, mapping) for child in term[1:])]


def subst_formula(formula, mapping):
    """Simultaneous substitution; inserted terms are not substituted again."""
    if formula[0] == "=":
        return ["=", subst_term(formula[1], mapping),
                subst_term(formula[2], mapping)]
    x, y, body = formula[1:]
    active = {key: value for key, value in mapping.items() if key not in (x, y)}
    image_names = set()
    for term in active.values():
        image_names.update(fv_term(term))
    used = all_names(body) | image_names | set(active) | {x, y}
    renaming = {}
    binders = [x, y]
    for index, old in enumerate((x, y)):
        if old in image_names:
            new = fresh_name(used)
            used.add(new)
            binders[index] = new
            renaming[old] = variable(new)
    if renaming:
        body = subst_formula(body, renaming)
    return ["D", *binders, subst_formula(body, active)]


def alpha_key(formula):
    """Canonical key for alpha equivalence, retaining actual free names."""
    def term_key(term, environment):
        if term[0] == "$":
            item = term[1]
            return ("bound", environment[item]) if item in environment else ("free", item)
        return ("function", term[0],
                tuple(term_key(child, environment) for child in term[1:]))

    def formula_key(item, environment, depth):
        if item[0] == "=":
            return ("=", term_key(item[1], environment),
                    term_key(item[2], environment))
        extended = dict(environment)
        extended[item[1]] = depth
        extended[item[2]] = depth + 1
        return ("D", formula_key(item[3], extended, depth + 2))

    return formula_key(formula, {}, 0)


def alpha_equal(left, right):
    return alpha_key(left) == alpha_key(right)


def hypothesis(formula):
    """The ordinary assumption F, represented as the constant clause H -> F."""
    binder = fresh_name(all_names(formula), "_h")
    return (truth_formula(), binder, formula)


def replace_at(term, path, source, target):
    """Replace exactly one occurrence; path indexes arguments, not head names."""
    if not path:
        require(term == source, "rewrite source does not occur at the chosen path")
        return target
    index = path[0]
    require(term[0] != "$" and index < len(term) - 1,
            "rewrite path leaves the numerical term")
    result = list(term)
    result[index + 1] = replace_at(term[index + 1], path[1:], source, target)
    return result


class Checker:
    def __init__(self, declarations, mode="local"):
        require(mode in ("local", "atomic", "general"), "unknown reference mode")
        self.mode = mode
        self.functions = {
            "0": {"kind": "zero", "arity": 0},
            "S": {"kind": "successor", "arity": 1},
            "id": {"kind": "proj", "arity": 1, "index": 0},
        }
        require(type(declarations) is list, "declarations must be an array")
        for declaration in declarations:
            self.declare(declaration)
        self.nodes = 0
        self.max_depth = 0
        self.rule_counts = {}

    def declare(self, declaration):
        require(type(declaration) is dict, "declaration must be an object")
        kind = declaration.get("kind")
        required = {
            "proj": ("name", "kind", "arity", "index"),
            "comp": ("name", "kind", "arity", "outer", "inners"),
            "rec": ("name", "kind", "arity", "base", "step"),
        }
        require(type(kind) is str and kind in required, "unknown declaration kind")
        fields(declaration, required[kind], "declaration")
        symbol = declaration["name"]
        arity = declaration["arity"]
        require(name(symbol) and symbol not in self.functions,
                "function name is invalid or already declared")
        require(type(arity) is int and arity >= 0, "arity must be a nonnegative integer")
        if kind == "proj":
            index = declaration["index"]
            require(type(index) is int and 0 <= index < arity,
                    "projection index is outside its arity")
        elif kind == "comp":
            outer = declaration["outer"]
            inners = declaration["inners"]
            require(type(outer) is str and outer in self.functions,
                    "composition outer function must be earlier")
            require(type(inners) is list
                    and len(inners) == self.functions[outer]["arity"],
                    "composition has the wrong number of inner functions")
            for inner in inners:
                require(type(inner) is str and inner in self.functions
                        and self.functions[inner]["arity"] == arity,
                        "composition inner function is absent or has wrong arity")
        else:
            base = declaration["base"]
            step = declaration["step"]
            require(arity >= 1, "recursive function needs a counter argument")
            require(type(base) is str and base in self.functions
                    and self.functions[base]["arity"] == arity - 1,
                    "recursion base is absent or has wrong arity")
            require(type(step) is str and step in self.functions
                    and self.functions[step]["arity"] == arity + 1,
                    "recursion step is absent or has wrong arity")
        self.functions[symbol] = dict(declaration)

    def term(self, value, scope):
        require(type(value) is list and len(value) >= 1, "term must be a nonempty array")
        head = value[0]
        require(type(head) is str, "term head must be a string")
        if head == "$":
            require(len(value) == 2 and name(value[1]) and value[1] in scope,
                    "numerical variable is malformed or outside the scope")
            return
        require(head in self.functions, "unknown numerical function")
        require(len(value) == self.functions[head]["arity"] + 1,
                "numerical application has wrong arity")
        for child in value[1:]:
            self.term(child, scope)

    def formula(self, value, scope):
        require(type(value) is list and len(value) >= 1,
                "formula must be a nonempty array")
        head = value[0]
        require(type(head) is str, "formula head must be a string")
        if head == "=":
            require(len(value) == 3, "equation has wrong arity")
            self.term(value[1], scope)
            self.term(value[2], scope)
        else:
            require(head == "D" and len(value) == 4, "unknown formula constructor")
            x, y, body = value[1:]
            require(name(x) and name(y) and x != y, "paired binders must have distinct names")
            self.formula(body, scope | {x, y})

    def computation(self, term):
        """One defining equation; the input term has already been validated."""
        require(term[0] != "$", "a variable has no defining equation")
        description = self.functions[term[0]]
        kind = description["kind"]
        arguments = term[1:]
        if kind == "proj":
            return arguments[description["index"]]
        if kind == "comp":
            return [description["outer"],
                    *([inner, *arguments] for inner in description["inners"])]
        require(kind == "rec", "zero and successor have no computation axiom")
        counter, *parameters = arguments
        if counter == zero():
            return [description["base"], *parameters]
        require(counter[0] == "S", "recursion counter is neither zero nor a successor term")
        previous = counter[1]
        recursive_value = [term[0], previous, *parameters]
        return [description["step"], previous, recursive_value, *parameters]

    def check(self, proof, context=(), scope=frozenset(), expected=None):
        """Validate an explicit context, then check a derivation in that context."""
        require(type(scope) in (set, frozenset) and all(name(item) for item in scope),
                "scope must be a set of variable names")
        scope = set(scope)
        require(type(context) in (tuple, list), "context must be a sequence of clauses")
        for clause in context:
            require(type(clause) in (tuple, list) and len(clause) == 3,
                    "context entry must be an antecedent, binder, and body")
            antecedent, binder, body = clause
            require(name(binder), "clause binder is invalid")
            self.formula(antecedent, scope)
            require(binder not in fv_formula(antecedent),
                    "clause binder occurs in its antecedent")
            self.formula(body, scope | {binder})
        if expected is not None:
            self.formula(expected, scope)
        self._check(proof, tuple(context), scope, expected, 0)
        return {"accepted": True, "mode": self.mode, "proof_nodes": self.nodes,
                "maximum_depth": self.max_depth, "rule_counts": dict(self.rule_counts),
                "declared_functions": len(self.functions) - 3}

    def _check(self, proof, context, scope, expected, depth):
        require(type(proof) is dict, "proof node must be an object")
        rule = proof.get("rule")
        required = {
            "comp": ("rule", "conclusion"),
            "use": ("rule", "conclusion", "clause", "term", "premise"),
            "di": ("rule", "conclusion", "witness", "eigen", "premise"),
            "de": ("rule", "conclusion", "major", "eigen", "premise"),
            "rw": ("rule", "conclusion", "before", "source", "side", "path"),
            "tr": ("rule", "conclusion", "equality", "before", "variable", "motive"),
        }
        require(type(rule) is str and rule in required, "unknown inference rule")
        fields(proof, required[rule], "proof node")
        conclusion = proof["conclusion"]
        self.formula(conclusion, scope)
        if expected is not None:
            require(alpha_equal(conclusion, expected), "premise has the wrong conclusion")
        self.nodes += 1
        self.max_depth = max(self.max_depth, depth)
        self.rule_counts[rule] = self.rule_counts.get(rule, 0) + 1

        if rule == "comp":
            require(conclusion[0] == "=", "computation must conclude an equation")
            require(self.computation(conclusion[1]) == conclusion[2],
                    "conclusion is not a single defining equation")
            return

        if rule == "use":
            index = proof["clause"]
            require(type(index) is int and 0 <= index < len(context),
                    "clause index is outside the context")
            argument = proof["term"]
            self.term(argument, scope)
            antecedent, binder, body = context[index]
            target = subst_formula(body, {binder: argument})
            require(alpha_equal(conclusion, target), "clause specialization has wrong conclusion")
            self._check(proof["premise"], context, scope, antecedent, depth + 1)
            return

        if rule == "di":
            require(conclusion[0] == "D", "paired introduction needs a paired conclusion")
            witness = proof["witness"]
            eigen = proof["eigen"]
            self.term(witness, scope)
            require(name(eigen) and eigen not in scope, "introduction eigenvariable is not fresh")
            x, y, body = conclusion[1:]
            base = subst_formula(body, {x: witness, y: zero()})
            step = subst_formula(body, {x: witness, y: successor(variable(eigen))})
            extended = context + (hypothesis(base),)
            if body[0] == "=":
                induction = subst_formula(body, {x: witness, y: variable(eigen)})
                extended += (hypothesis(induction),)
            self._check(proof["premise"], extended, scope | {eigen}, step, depth + 1)
            return

        if rule == "de":
            major = proof["major"]
            self._check(major, context, scope, None, depth + 1)
            paired = major["conclusion"]
            require(paired[0] == "D", "paired elimination needs a paired major")
            eigen = proof["eigen"]
            require(name(eigen) and eigen not in scope, "elimination eigenvariable is not fresh")
            x, y, body = paired[1:]
            binder = fresh_name(all_names(body) | scope | {eigen}, "_b")
            base = subst_formula(body, {x: variable(eigen), y: zero()})
            opened = subst_formula(body, {x: variable(eigen), y: variable(binder)})
            clause = (base, binder, opened)
            self._check(proof["premise"], context + (clause,), scope | {eigen},
                        conclusion, depth + 1)
            return

        if rule == "rw":
            require(conclusion[0] == "=", "local rewriting can conclude only an equation")
            before = proof["before"]
            source = proof["source"]
            require(type(source) is dict and source.get("rule") == "use",
                    "rewrite source must be a direct clause use")
            self._check(source, context, scope, None, depth + 1)
            equation = source["conclusion"]
            require(equation[0] == "=", "rewrite source must conclude an equation")
            self._check(before, context, scope, None, depth + 1)
            old = before["conclusion"]
            require(old[0] == "=", "local rewriting needs an equation premise")
            side = proof["side"]
            path = proof["path"]
            require(type(side) is int and side in (0, 1), "rewrite side must be zero or one")
            require(type(path) is list and all(type(item) is int and item >= 0 for item in path),
                    "rewrite path must be an array of nonnegative integers")
            left = equation[1]
            right = equation[2]
            target = list(old)
            target[side + 1] = replace_at(old[side + 1], path, left, right)
            require(conclusion == target, "local rewrite has the wrong result")
            return

        require(self.mode != "local", "general transport is disabled in the local calculus")
        equality = proof["equality"]
        self._check(equality, context, scope, None, depth + 1)
        equation = equality["conclusion"]
        require(equation[0] == "=", "transport major must be an equation")
        placeholder = proof["variable"]
        require(name(placeholder) and placeholder not in scope,
                "transport placeholder must be a fresh variable name")
        motive = proof["motive"]
        self.formula(motive, scope | {placeholder})
        require(self.mode != "atomic" or motive[0] == "=",
                "atomic reference transport requires an equation motive")
        old = subst_formula(motive, {placeholder: equation[1]})
        target = subst_formula(motive, {placeholder: equation[2]})
        require(alpha_equal(conclusion, target), "transport has the wrong result")
        self._check(proof["before"], context, scope, old, depth + 1)


def check_packet(packet, mode="local"):
    fields(packet, ("declarations", "goal", "proof"), "proof packet")
    checker = Checker(packet["declarations"], mode)
    checker.formula(packet["goal"], set())
    return checker.check(packet["proof"], expected=packet["goal"])


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON object key")
        result[key] = value
    return result


def reject_constant(value):
    raise ProofError("nonfinite JSON numeric constant: " + value)


def load_packet(stream):
    return json.load(stream, object_pairs_hook=unique_object,
                     parse_constant=reject_constant)


if __name__ == "__main__":
    try:
        with open(0, encoding="utf-8") as stream:
            check_packet(load_packet(stream))
        print("ACCEPT")
    except Exception:
        print("REJECT")
        raise SystemExit(1)
