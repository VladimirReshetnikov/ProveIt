AXIOMATIZING iPRA: VERIFIED COMPARISON AND A COMPLETE REFERENCE BASIS
Research report on the ProveIt drafts, 9 November 2026
=================================================================

RESULT STATUS
-------------
The requested NEW axiomatization below the current complete-checker
frontier was not obtained. No significant new mathematical breakthrough,
absolute minimum, or new source-size record is claimed.

This archive supplies a complete inherited iPRA-equivalent native basis,
its explicit logical and nonlogical rules and both interpretation round
trips, an independent current-source audit, reproducible whole-source
measurements, and bounded execution evidence. It does not present old
theorems or an unvalidated prototype as a new solution.

START WITH report.pdf.

SNAPSHOT AND FINDINGS
---------------------
Repository: VladimirReshetnikov/ProveIt
Commit: 08edc6964d8990d2230179a9d65355ac1eee7a9e
https://github.com/VladimirReshetnikov/ProveIt/tree/08edc6964d8990d2230179a9d65355ac1eee7a9e/docs/drafts

All 22 current ZIP archives verified by length and Git blob identity.
625 direct Python member occurrences; 217 distinct Python sources.
41 distinct programs described by their packages as complete checkers.
Observed coordinate minima: 305 normalized tokens / 340 AST / 820 bytes.
Strict structurally guarded profiles: 305 / 341 / 820.
Different programs attain the minima. A historical identifier-renaming
control reaches 816 bytes. These are observed sizes, not universal lower
bounds. The audit does not newly formalize all inherited checker proofs.

All 41 source hashes and metric triples were independently reproduced.
Seven inspected leaders passed 350 bounded public CLI executions, including
ordinary and optimized Python, with zero failures. Expected noncanonical
alias differences between strict and iterable profiles are documented.
The other 34 sources were not executed.

A separate accepted certificate makes the passive-parameter scope of
the compact iterator explicit (two additional runs, zero failures).
The closed-unary language is a sufficient subgrammar, not the whole raw
accepted syntax. This is a specification clarification, not a checker bug.
A documented pulse experiment finds a 10-node reverse cycle but increases
the complete equality detector from 52 to 54 nodes; it is not an improvement.

CONTENTS
--------
report.pdf                 Compiled main report.
report.tex, sections/      Editable mathematical source.
report_standalone.tex      The complete report in one TeX source file.
comparison/                41 unchanged complete comparators and provenance.
code/                      Independent measurement and bounded replay.
fixtures/                  Certificates, expected verdicts, provenance.
evidence/                  Snapshot/source identities and actual receipts.
reference/                 Attributed scalar arithmetic/compiler dependencies.
reviews/                   Independent review notes and their limitations.
experiments/pulse/         Bounded cycle search and the larger 54-node variant.
CLAIMS.json                Explicit result-status ledger.
MANIFEST.json              Payload lengths and SHA-256 hashes.

REPRODUCTION
------------
From this extracted directory:

  python3 code/reproduce_comparison.py
  python3 code/replay_leading_checkers.py
  python3 code/check_passive_parameter.py
  python3 experiments/pulse/check_reverse_cycle.py reference/pulse52.py
  python3 build.py
  python3 package.py

The optional search_cycle.py reproduces the bounded diagnostic search;
it is explicitly not an exhaustive lower-bound argument for actual terms.

Python checks need only the standard library. Exact AST/unparser source
metrics are recorded under CPython 3.12.14. PDF rebuilding requires
pdfLaTeX and the ordinary packages listed in report.tex. Build commands
disable shell escape and never download packages. The PDF is included.

The mathematical results have written proofs and targeted assistant
reviews. They are not newly verified in Lean/Rocq or externally peer
reviewed. Finite numerical or certificate tests are not advertised as
proofs of infinite metatheorems.

Original 22 archives are not duplicated; their exact identities and the
direct-member inventory are included. All 41 comparator sources needed
for the standalone comparison ARE included unchanged.

Repository access was read-only. No external messages, issues, comments,
commits, or pull requests were created.
