"""Bounded public-CLI replay of seven inspected frozen leading kernels.

This is finite regression evidence, not a proof of arithmetic equivalence.
Only the seven small source files explicitly selected in the manifest run.
The other 34 complete-comparison programs are not executed.
"""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    programs = [item for item in manifest['programs'] if item['leading_fixture_replay']]
    require(len(programs) == 7, 'The bounded replay must have exactly seven programs.')
    for item in programs:
        require(hashlib.sha256((ROOT / item['file']).read_bytes()).hexdigest() == item['sha256'],
                'Frozen leading source hash mismatch: ' + item['file'])
    provenance = json.loads((ROOT / 'fixtures/provenance.json').read_text())
    for item in provenance['fixture_sources']:
        require(hashlib.sha256((ROOT / item['file']).read_bytes()).hexdigest() == item['sha256'],
                'Fixture hash mismatch: ' + item['file'])

    public = json.loads((ROOT / 'fixtures/inherited_cli_cases.json').read_text())['cases']
    selected = json.loads((ROOT / 'fixtures/selected_positive_cases.json').read_text())['records']
    supplemental = json.loads((ROOT / 'fixtures/supplemental_cases.json').read_text())['cases']
    cases = [{'name': 'public/' + c['name'], 'input_text': c['input_text'],
              'expected_accept': c['expected_accept'], 'group': 'inherited public CLI'}
             for c in public]
    cases += [{'name': 'selected/' + c['id'] + '/' + c['name'],
               'input_text': json.dumps(c['packet']), 'expected_accept': True,
               'group': 'selected inherited positive'} for c in selected]
    cases += [{'name': 'supplemental/' + c['name'], 'input_text': json.dumps(c['packet']),
               'expected_accept': c['expected_accept'],
               'expected_accept_iterable': c.get('expected_accept_iterable', c['expected_accept']),
               'group': 'documented alias difference' if 'expected_accept_iterable' in c else
                        'known validation attack'} for c in supplemental]
    require(len(cases) == 25, 'The bounded replay must have exactly 25 cases per mode.')

    def run(job):
        item, case, optimized = job
        expected = case['expected_accept']
        if item['label'] == 'clock_iterable.py':
            expected = case.get('expected_accept_iterable', expected)
        command = [sys.executable] + (['-O'] if optimized else []) + [str(ROOT / item['file'])]
        try:
            result = subprocess.run(command, input=case['input_text'], text=True,
                                    capture_output=True, timeout=10, cwd=ROOT)
            observed = {'stdout': result.stdout, 'stderr': result.stderr,
                        'returncode': result.returncode}
        except subprocess.TimeoutExpired:
            observed = {'timeout': True}
        wanted = {'stdout': 'ACCEPT\n' if expected else 'REJECT\n',
                  'stderr': '', 'returncode': 0 if expected else 1}
        return {'program': item['file'], 'label': item['label'], 'case': case['name'],
                'group': case['group'], 'optimized': optimized, 'expected_accept': expected,
                'passed': observed == wanted, 'observed': observed}

    jobs = [(item, case, optimized) for item in programs for case in cases
            for optimized in (False, True)]
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(run, jobs))
    failures = [r for r in results if not r['passed']]
    aliases = [r for r in results if r['group'] == 'documented alias difference']
    summary = {
        'commit': manifest['commit'], 'python': platform.python_version(),
        'program_count': len(programs), 'cases_per_program_per_mode': len(cases),
        'modes': ['ordinary', '-O'], 'cli_executions': len(results),
        'expected_accept_executions': sum(r['expected_accept'] for r in results),
        'expected_reject_executions': sum(not r['expected_accept'] for r in results),
        'failures': len(failures), 'all_passed': not failures,
        'case_sources': {'inherited_cli_cases': len(public), 'selected_positive_cases': len(selected),
                         'known_validation_attack': 1, 'documented_alias_cases': 3},
        'documented_alias_executions': len(aliases),
        'iterable_profile_alias_acceptances': sum(r['label'] == 'clock_iterable.py' and
                                                 r['expected_accept'] and r['passed'] for r in aliases),
        'strict_profile_alias_rejections': sum(r['label'] != 'clock_iterable.py' and
                                              not r['expected_accept'] and r['passed'] for r in aliases),
        'qualification': 'Three noncanonical aliases are accepted by the documented iterable '
                         'profile and rejected by the six strict profiles. This expected interface '
                         'difference is not a claim of all-input equivalence. Finite replay does '
                         'not prove the general soundness, completeness or bi-interpretability theorem.',
        'failed_cases': failures,
    }
    evidence = ROOT / 'evidence'
    evidence.mkdir(exist_ok=True)
    (evidence / 'leading_replay_receipt.json').write_text(json.dumps(summary, indent=2) + '\n')
    (evidence / 'leading_replay_details.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
