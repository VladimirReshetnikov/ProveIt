"""Replay the independent passive-parameter scope certificate.

This supplements, and does not alter, the 350-case inherited replay.
The only executed source is the inspected unchanged indexed comparator.
"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CHECKER = ROOT / "comparison/95aab9312957_recurrence_indexed.py"
FIXTURE = ROOT / "fixtures/passive_parameter_iterator.json"
RESULT = ROOT / "evidence/passive_parameter_check.json"


def main():
    payload = FIXTURE.read_text()
    results = []
    for optimized in (False, True):
        command = [sys.executable]
        if optimized:
            command.append("-O")
        command.append(str(CHECKER))
        process = subprocess.run(command, input=payload, capture_output=True,
                                 text=True, timeout=5, cwd=ROOT)
        result = {"optimized": optimized, "returncode": process.returncode,
                  "stdout": process.stdout, "stderr": process.stderr}
        result["pass"] = (process.returncode == 0
                          and process.stdout.strip() == "ACCEPT"
                          and not process.stderr)
        results.append(result)
    receipt = {
        "scope": "Independent passive-update-parameter certificate, separate from the 350-case replay",
        "checker": str(CHECKER.relative_to(ROOT)),
        "checker_sha256": hashlib.sha256(CHECKER.read_bytes()).hexdigest(),
        "fixture": str(FIXTURE.relative_to(ROOT)),
        "fixture_sha256": hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
        "decoded_goal": "D_{x,y}(It(1,0; u.y)=y), with x unused",
        "introduction_witness": "1",
        "raw_parameter_coordinate": 5,
        "parameter_scope": "The outer y slot, beyond the two repeated iterator state slots",
        "results": results,
        "runs": len(results),
        "failures": sum(not item["pass"] for item in results),
        "python": sys.version,
    }
    RESULT.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"runs": receipt["runs"], "failures": receipt["failures"]}))
    return bool(receipt["failures"])


if __name__ == "__main__":
    raise SystemExit(main())
