"""Verify and remeasure every frozen complete source without executing it."""
import ast
import csv
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(raw):
    tree = ast.fix_missing_locations(
        StripDocstrings().visit(ast.parse(raw.decode('utf-8-sig'))))
    normalized = ast.unparse(tree) + '\n'
    nodes = list(ast.walk(tree))
    return {
        'normalized_tokens': sum(t.type not in IGNORED for t in
                                 tokenize.generate_tokens(io.StringIO(normalized).readline)),
        'ast_nodes': len(nodes),
        'normalized_bytes': len(normalized.encode('utf-8')),
        'raw_bytes': len(raw),
        'functions': sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda))
                         for n in nodes),
        'branch_nodes': sum(isinstance(n, (ast.If, ast.IfExp, ast.Match, ast.Try))
                            for n in nodes),
    }


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    failures = []
    for item in manifest['programs']:
        raw = (ROOT / item['file']).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != item['sha256']:
            failures.append({'file': item['file'], 'reason': 'source hash mismatch'})
        measured = measure(raw)
        if measured != item['expected_metrics']:
            failures.append({'file': item['file'], 'reason': 'metric mismatch',
                             'expected': item['expected_metrics'], 'observed': measured})
        rows.append({'file': item['file'], 'label': item['label'], 'profile': item['profile'],
                     'sha256': digest, **measured})
    fields = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
    envelope = {key: min(row[key] for row in rows) for key in fields}
    strict_rows = [row for row in rows if row['label'] != 'clock_iterable.py']
    strict_envelope = {key: min(row[key] for row in strict_rows) for key in fields}
    if envelope != manifest['envelope']:
        failures.append({'reason': 'envelope mismatch', 'observed': envelope,
                         'expected': manifest['envelope']})
    receipt = {
        'scope': 'Static whole-source measurements only; no comparator is executed.',
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'python': platform.python_version(), 'reference_python': manifest['python_reference'],
        'program_count': len(rows), 'all_hashes_and_metrics_match': not failures,
        'envelope': envelope, 'excluding_iterable_alias_profile': strict_envelope,
        'minimum_attainers': {key: [row['file'] for row in rows if row[key] == envelope[key]]
                             for key in fields},
        'failures': failures,
        'qualification': 'These are observed corpus minima, not mathematical lower bounds. '
                         'Different programs attain different coordinates; bytes depend on names.',
    }
    evidence = ROOT / 'evidence'
    evidence.mkdir(exist_ok=True)
    (evidence / 'comparison_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    with (evidence / 'comparison_metrics.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(receipt, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
