"""Create a deterministic ZIP and verify every manifested payload."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent


def main():
    files = sorted(p for p in ROOT.rglob("*") if p.is_file()
                   and p.name != "MANIFEST.json"
                   and "__pycache__" not in p.parts
                   and p.suffix not in (".pyc", ".aux", ".toc", ".out"))
    records = [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size,
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    manifest = {"format": "sha256-payload-v1", "root": ROOT.name,
                "snapshot": "08edc6964d8990d2230179a9d65355ac1eee7a9e", "files": records}
    mp = ROOT / "MANIFEST.json"
    mp.write_text(json.dumps(manifest, indent=2) + "\n")
    files.append(mp)
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in sorted(files):
            info = zipfile.ZipInfo(ROOT.name + "/" + p.relative_to(ROOT).as_posix(),
                                   (2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, p.read_bytes())
    with zipfile.ZipFile(target) as archive:
        damaged = archive.testzip()
        if damaged:
            raise ValueError("CRC failure: " + damaged)
        for record in records:
            raw = archive.read(ROOT.name + "/" + record["path"])
            if len(raw) != record["bytes"] or hashlib.sha256(raw).hexdigest() != record["sha256"]:
                raise ValueError("Payload verification failed: " + record["path"])
    print(json.dumps({"archive": str(target), "payload_files": len(records),
                      "zip_bytes": target.stat().st_size,
                      "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                      "crc_and_payload_hashes": "verified"}, indent=2))


if __name__ == "__main__":
    main()
