"""Build the report offline with shell escape disabled."""
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def standalone():
    def expand(path):
        text = path.read_text()
        text = re.sub(r"\\input\{([^}]+)\}",
                      lambda m: expand(ROOT / m.group(1)), text)
        def listing(match):
            source = (ROOT / match.group(2)).read_text()
            options = match.group(1) or ""
            return "\\begin{lstlisting}" + options + "\n" + source + "\\end{lstlisting}"
        return re.sub(r"\\lstinputlisting(\[[^\]]*\])?\{([^}]+)\}", listing, text)
    output = ROOT / "report_standalone.tex"
    output.write_text(expand(ROOT / "report.tex"))
    return output


def main():
    source = standalone()
    if not shutil.which("pdflatex"):
        raise SystemExit("pdfLaTeX is required to rebuild the included PDF.")
    logs = []
    with tempfile.TemporaryDirectory(prefix="ipra_tex_") as temporary:
        command = ["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
                   "-halt-on-error", "-jobname=report",
                   "-output-directory=" + temporary, source.name]
        for number in range(3):
            result = subprocess.run(command, cwd=ROOT, text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            logs.append(f"PASS {number + 1}\n{result.stdout}")
            if result.returncode:
                (ROOT / "evidence/latex_build.txt").write_text("\n".join(logs))
                raise SystemExit("PDF build failed; see evidence/latex_build.txt")
        shutil.copyfile(Path(temporary) / "report.pdf", ROOT / "report.pdf")
        shutil.copyfile(Path(temporary) / "report.log", ROOT / "evidence/latex_final.log")
    (ROOT / "evidence/latex_build.txt").write_text("\n".join(logs))
    print("Built report.pdf from the complete standalone source.")


if __name__ == "__main__":
    main()
