"""Reproduce the 70 -> 52 node closed-iteration pulse simplification.

This file checks finite term syntax, exact ground computations, one symbolic
computation-law rewrite, and small numerical diagnostics.  It is not a full
iPRA proof checker and does not prove the interpretation metatheorems.

Primitive syntax: 0, variables, successor, and I_h(n,a), where h is a
closed unary finite term with only the distinguished state variable u.
Every update body is counted in full at every occurrence.
"""

from functools import lru_cache
import json


ZERO = ("zero",)
U = ("var", "u")
A = ("var", "a")
B = ("var", "b")


def S(t):
    return ("succ", t)


ONE = S(ZERO)


def I(h, n, a):
    return ("iter", h, n, a)


def add(a, b):
    return I(S(U), b, a)


def mask(n, a):
    return I(ZERO, n, a)


def Z(n):
    return mask(n, ONE)


def N(n):
    return I(Z(U), n, ZERO)


def old_j(t):
    return add(Z(t), add(N(t), N(t)))


def new_j(t):
    return mask(I(Z(U), t, t), S(t))


def mod3(t, update):
    return I(update(U), t, ZERO)


def g(t, update):
    return S(add(t, mod3(t, update)))


def G(t, update):
    return I(g(U, update), t, ZERO)


def K(t, update):
    return mask(N(t), G(t, update))


def E(t):
    return I(add(U, U), t, ONE)


def pulse_state(a, b, update):
    return I(K(U, update), b, E(a))


def detector(a, b, update, fused):
    state = pulse_state(a, b, update)
    return N(S(state)) if fused else Z(N(state))


def validate(t, allowed):
    tag = t[0]
    if tag == "zero" and len(t) == 1:
        return
    if tag == "var" and len(t) == 2 and t[1] in allowed:
        return
    if tag == "succ" and len(t) == 2:
        validate(t[1], allowed)
        return
    if tag == "iter" and len(t) == 4:
        validate(t[1], {"u"})
        validate(t[2], allowed)
        validate(t[3], allowed)
        return
    raise ValueError("Malformed or non-closed primitive term")


def nodes(t):
    if t[0] in ("zero", "var"):
        return 1
    return 1 + sum(nodes(c) for c in t[1:])


def subst(t, variable, replacement):
    if t[0] == "var":
        return replacement if t[1] == variable else t
    if t[0] == "zero":
        return t
    if t[0] == "succ":
        return S(subst(t[1], variable, replacement))
    # A closed update is a separate binding environment.
    return I(t[1], subst(t[2], variable, replacement),
             subst(t[3], variable, replacement))


def unfold_successor(t):
    if t[0] != "iter" or t[2][0] != "succ":
        raise ValueError("Not an iterator successor redex")
    h, n, a = t[1], t[2][1], t[3]
    return subst(h, "u", I(h, n, a))


@lru_cache(maxsize=None)
def evaluate(t, environment=()):
    tag = t[0]
    if tag == "zero":
        return 0
    if tag == "var":
        return dict(environment)[t[1]]
    if tag == "succ":
        return evaluate(t[1], environment) + 1
    h, counter, seed = t[1:]
    count = evaluate(counter, environment)
    state = evaluate(seed, environment)
    for unused in range(count):
        state = evaluate(h, (("u", state),))
    return state


def at(t, **environment):
    return evaluate(t, tuple(sorted(environment.items())))


def check():
    old = detector(A, B, old_j, False)
    cycle_only = detector(A, B, new_j, False)
    new = detector(A, B, new_j, True)
    for term in (old, cycle_only, new):
        validate(term, {"a", "b"})
    counts = {"old_cycle": nodes(old_j(U)),
              "new_cycle": nodes(new_j(U)),
              "old_detector": nodes(old),
              "cycle_replacement_detector": nodes(cycle_only),
              "new_detector": nodes(new)}
    if counts != {"old_cycle": 27, "new_cycle": 12,
                  "old_detector": 70, "cycle_replacement_detector": 55,
                  "new_detector": 52}:
        raise ValueError("Term counts changed")
    ground_cycle = [at(new_j(U), u=n) for n in range(3)]
    if ground_cycle != [1, 2, 0]:
        raise ValueError("Three-cycle computation failed")
    if unfold_successor(new) != cycle_only:
        raise ValueError("The parity fusion is not one exact computation step")
    checked = 0
    for a in range(6):
        for b in range(8):
            expected = int(a != b)
            observed = at(new, a=a, b=b)
            if observed != expected or at(old, a=a, b=b) != expected:
                raise ValueError("Numerical comparator diagnostic failed")
            checked += 1
    orbit = [at(pulse_state(A, B, new_j), a=4, b=b)
             for b in range(7)]
    if orbit != [16, 24, 36, 54, 81, 0, 0]:
        raise ValueError("Displayed orbit changed")
    return {"counts": counts, "cycle": ground_cycle,
            "exact_symbolic_computation_rewrite": True,
            "numerical_pairs_checked": checked,
            "orbit_at_a_4": orbit,
            "scope": "Syntax and finite diagnostics, not full formal verification"}


if __name__ == "__main__":
    print(json.dumps(check(), indent=2))
