import time,json
from pathlib import Path
M=8; UNKNOWN=M+1
levels=[[] for _ in range(13)]; seen={}; start=time.time()
def save(v,t,n):
 if v in seen:return False
 seen[v]=t;levels[n].append((v,t))
 if v[:3]==(1,2,0):
  print('FOUND',n,t,v,flush=True)
  Path('cycle_candidate.json').write_text(json.dumps({'nodes':n,'term':t,'vector':v}))
  return True
 return False
save((0,)*(M+1),('zero',),1)
save(tuple(range(M+1)),('var','u'),1)
for n in range(2,13):
 for v,t in levels[n-1]:
  w=tuple(x+1 if x<M else UNKNOWN for x in v)
  if save(w,('succ',t),n):raise SystemExit
 for hs in range(1,n-2):
  for ns in range(1,n-hs-1):
   ass=n-1-hs-ns
   if ass<1:continue
   for h,ht in levels[hs]:
    # each h's powers up to M on finite known domain
    ps=[tuple(range(M+1))]
    for k in range(M):ps.append(tuple(h[x] if x<=M else UNKNOWN for x in ps[-1]))
    for nv,nt in levels[ns]:
     for av,at in levels[ass]:
      w=tuple(ps[k][a] if k<=M and a<=M else UNKNOWN for k,a in zip(nv,av))
      if save(w,('iter',ht,nt,at),n):raise SystemExit
 print('level',n,'new',len(levels[n]),'total',len(seen),'elapsed',round(time.time()-start,2),flush=True)
