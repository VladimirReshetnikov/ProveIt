"""Finite closed-term diagnostics for a reverse three-cycle pulse variant.

The full-PR/iPRA argument is written in search_note.txt. This script checks
syntax, expanded tree sizes, and finite standard computations only.
"""
from pathlib import Path
import importlib.util
import json
import sys

if len(sys.argv) != 2:
    raise SystemExit('usage: python3 check_reverse_cycle.py PATH_TO_PULSE52_PY')
spec = importlib.util.spec_from_file_location('pulse52_reference', sys.argv[1])
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)

def reverse_j(t):
    return p.I(p.Z(p.U), t, p.S(p.ONE))

def reverse_g(t, update):
    return p.S(p.add(t, p.Z(p.mod3(t, update))))

def reverse_G(t, update):
    return p.I(reverse_g(p.U, update), t, p.ZERO)

def reverse_K(t, update):
    return p.mask(p.N(t), reverse_G(t, update))

def reverse_detector(a, b):
    return p.N(p.S(p.I(reverse_K(p.U, reverse_j), b, p.E(a))))

new = reverse_detector(p.A,p.B)
p.validate(new, {'a','b'})
counts = {
 'forward_cycle':p.nodes(p.new_j(p.U)),
 'reverse_cycle':p.nodes(reverse_j(p.U)),
 'forward_generator':p.nodes(p.g(p.U,p.new_j)),
 'reverse_generator':p.nodes(reverse_g(p.U,reverse_j)),
 'forward_masked_update':p.nodes(p.K(p.U,p.new_j)),
 'reverse_masked_update':p.nodes(reverse_K(p.U,reverse_j)),
 'forward_detector':p.nodes(p.detector(p.A,p.B,p.new_j,True)),
 'reverse_detector':p.nodes(new),
}
expected = {'forward_cycle':12,'reverse_cycle':10,
 'forward_generator':20,'reverse_generator':22,
 'forward_masked_update':33,'reverse_masked_update':35,
 'forward_detector':52,'reverse_detector':54}
if counts != expected: raise ValueError(counts)
cycle=[p.at(reverse_j(p.U),u=n) for n in (0,2,1)]
if cycle != [2,1,0]:raise ValueError(cycle)
orbit=[p.at(reverse_G(p.U,reverse_j),u=n) for n in range(13)]
if orbit != [(3*n+1)//2 for n in range(13)]:raise ValueError(orbit)
checked=0
for a in range(5):
 for b in range(7):
  value=p.at(new,a=a,b=b)
  if value != int(a!=b):raise ValueError((a,b,value))
  checked+=1
print(json.dumps({'counts':counts,'reverse_cycle_input_order':[0,2,1],
 'reverse_cycle_outputs':cycle,'reverse_G_values_0_through_12':orbit,
 'detector_pairs_checked':checked,
 'scope':'Closed-term syntax, expanded node counts, and finite standard computations; not a full formal proof.'},indent=2))
