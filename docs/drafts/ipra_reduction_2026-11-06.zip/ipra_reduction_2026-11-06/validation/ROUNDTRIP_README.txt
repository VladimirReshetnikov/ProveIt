PORTABLE ROUND-TRIP VALIDATION

Install roundtrip.py as validation/roundtrip.py in the final bundle.
It has no imports from scratch paths or from other local test modules.
Its only dependencies are the Python standard library and the three checker
files explicitly named below.

Default bundle paths:
  checker.py                       Goal-directed demand checker
  strict_checker.py                Goal-directed strict checker
  validation/reference.py          Frozen shared-transition checker
  validation/fixture_manifest.json Frozen fixture record list and provenance
  validation/fixtures/             All 256 frozen source certificate files
  validation/roundtrip_results.json Generated results
  validation/goal_corpus/           Generated 194 demand goal certificates
  validation/strict_corpus/         Generated 194 canonical strict certificates
  examples/                        Generated 18 examples (accepted by both)

Run from any directory:
  python3 /absolute/path/to/bundle/validation/roundtrip.py

All paths have command-line overrides:
  --reference --checker --strict-checker --fixtures --manifest --output
  --examples --corpus --strict-corpus

Exported translation functions:
  to_goal(reference, proof, context, strict=False, repairs=None)
  to_reference(reference, goal, proof, context)
  goal_accepts(checker, data)

The source format is [context, goal, proof]. The target format is
[goal, proof, *context]. The wrappers validate every context formula before
calling the internal recursive checker, exactly as the public CLI does.

For demand translation every witness payload is retained. For strict
translation an invalid Pi witness becomes -1 only after a separate occurrence
test confirms the first free number slot is absent from both major components.
All proofs, including the normalized strict proofs, are reconstructed into the
source format and checked again with literally unchanged context and goal.

The script pins the original reference hash and a canonical hash of all 256
original fixture records, so the compact final fixture_manifest.json and the
original full manifest are both supported without weakening provenance.
Every individual fixture hash and every expected source decision is checked.
The pinned archive URL, Git blob hash, SHA-256, source member paths, and
attribution are embedded in the script and copied into the result JSON.

Completed run in the agent's work directory:
  256 source decisions matched: 194 accepted, 62 rejected.
  194 demand translations accepted; all 194 reverse translations accepted.
  194 strict translations accepted; all 194 reverse translations accepted.
  150 demand certificates were already accepted by strict before normalization.
  44 certificates required exactly 44 vacuous witness repairs.
  11 direct probes checked against each implementation: 10 common rejections
    and one vacuous malformed witness accepted only by demand.
  18 examples passed both checkers under Python and Python -O: 72 CLI runs.
  11 probes passed both checkers in both modes: 44 further CLI runs.

Files from that run:
  portable_results.json
  portable_examples/ (18)
  goal_corpus/ (194)
  strict_corpus/ (194)

These finite tests support, but do not replace, the structural soundness and
completeness argument. No acceptance checker imports the translators, oracle,
fixture manifest, reproduction driver, or any test code.
