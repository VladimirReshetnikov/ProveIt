SMALLER COMPLETE PROOF KERNELS FOR iPRA
Prepared for Vladimir Reshetnikov -- 6 November 2026

RESULT

The primary goal-directed checker is strictly below the observed coordinatewise
lower envelope of the six current ProveIt draft archives, including their
embedded complete checkers and recorded historical dependency groups.

                             Current envelope     Primary     Strict witness
  Executable Python AST nodes             675          639                651
  Normalized Python tokens                634          612                622
  Significant source tokens               636          612                622
  Normalized UTF-8 source bytes          2,053        1,928              1,974
  Raw source bytes                      2,205        2,007              2,185

All figures count the entire program, including input formation, substitution,
logic, arithmetic, JSON input, and success/rejection handling. Python and its
standard json/sys runtime are common platform assumptions. Measurements use
CPython 3.12.14; normalization can vary with Python versions.

The new architecture checks an expected conclusion at each recursive call.
It eliminates conclusion synthesis and the fresh-variable deletion operation
for existential elimination. Introduction matrices come from the goal;
eliminations carry an explicit major formula which is itself validated and
proved. A recursion-computation certificate is just the marker "r".
The fresh-number transition is shared by the introduction and numerical rules.

The full mathematical basis, including all logical and nonlogical rules, is
specified in report.pdf. It recovers full intuitionistic first-order logic
and all quantifier-free induction, faithfully presents an ordinary theory
T_cov, and gives whole-domain bi-interpretations with iPRA. Equality defines
both internal round-trip isomorphisms. Native inconsistency (a closed proof
of 0=S0) is equivalent to iPRA inconsistency.

The recursor/Pi/E basis and its arithmetic/logical reconstruction are inherited
and credited to the supplied draft series. The new contribution is the smaller
goal-directed proof presentation and its verified finite-source comparison.
This is not an absolute minimality theorem.

START HERE

  report.pdf                  Complete 20-page mathematical report.
  report.tex, sections/*.tex   All LaTeX sources.
  checker.py                  Complete primary acceptance program.
  strict_checker.py           Matched complete strict-witness variant.
  FORMAT.txt                  Exact public certificate format and a small example.
  examples/                   18 certificates accepted by both programs.
  reproduce.py                Reproduce measurements and validation offline.
  build.py                    Rebuild the PDF offline with pdfLaTeX.
  package.py                  Rebuild the checksum manifest and ZIP.
  comparison/                 Frozen competitors, provenance, measurements.
  validation/                 Original fixtures, translators, corpora, independent audit.
  results/                    Actual executed measurements and validation results.
  MANIFEST.sha256              Hashes of all other deliverable files.
  LICENSE_SOURCE.txt          Inherited ProveIt MIT No Attribution license.

RUN

Python 3.10+; standard library only:

  python3 checker.py examples/reflexivity.json
  python3 strict_checker.py examples/reflexivity.json
  python3 reproduce.py

The first two commands print ACCEPT and exit zero. Rejection prints REJECT and
exits nonzero. The public acceptance interface is the CLI, not an unchecked
direct call to the internal recursive function.

To rebuild the PDF:

  python3 build.py

This requires pdfLaTeX and the packages listed in report.tex. The builder can
initialize a temporary local format if the installation lacks pdflatex.fmt;
it downloads nothing and changes no permanent TeX configuration. The fallback
builder is adapted from the supplied demand-kernel draft.

To rebuild the archive after edits:

  python3 package.py

CERTIFICATE CONTRACT

JSON is [goal, proof, hypothesis_0, hypothesis_1, ...].
The CLI validates every hypothesis; every recursive check validates its goal.
Numerical zero is -1, while nonnegative integers in terms are de Bruijn indices.
Boolean and floating-point values are not terms.

The primary permits an arbitrary unused universal witness annotation only
when the bound number occurs in neither principal matrix. Such an annotation
has the canonical ordinary witness zero. Every used witness is validated.
The strict variant validates all witnesses, including unused ones. Both have
exactly the same derivable well-formed sequents.

The internal check(a,p,g) assumes g was already validated. The public CLI
establishes this invariant; there is no separate advertised library API.

EXECUTED EVIDENCE

- All 256 frozen source-fixture decisions reproduced: 194 accept, 62 reject.
- All 194 accepted source certificates translated to each variant and back,
  preserving the exact context and goal; all four directions accepted.
- 150 certificates already satisfy the strict contract. The remaining 44
  require one vacuous witness repair each; no used witness is repaired.
- Independent named-binder/rule audit: 884 checks for each final checker.
  Each audit includes 142 direct cases and 194 inherited cases, each tested
  by an independent interpreter and the actual CLI.
- All native rule categories, malformed public statements and annotations,
  nested scope conditions, numerical-rule restrictions, and Python -O tested.
- 18 common examples run against both programs in normal and optimized mode.

The suites overlap; their totals are not added as independent examples.
The mathematical proofs are in the paper. Finite testing is implementation
evidence, not a Lean/Rocq verification of the complete metatheory or runtime.
Finite machine resources can reject very large otherwise valid certificates.

SOURCE SNAPSHOT

Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 0a86fcbd7c5e0d6a541291b4ac06c7dc77989161
Directory: docs/drafts

All six actual archive Git blob hashes were verified. The comparison scan
covers 1,042 Python-file occurrences, 272 distinct source hashes, 195
standalone/favorable core-only boundaries, and 74 recorded dependency groups.
The deliverable freezes 222 comparison source files. These are measured
without executing them; their inclusion is not a soundness endorsement.

PRIMARY SHA-256
1367fa42a532720200fdb9f9bba8b3fba4eac602dd10954a20c9c1ff66bfc8b1

STRICT SHA-256
36c2c1cda47466960fda04b35bfbc903c619919cedf27d02c427e258bced7c64

The paper includes Further research questions.
