#!/usr/bin/env python3
"""Reproduce finite checks, optionally the Lean kernel, and the LaTeX PDF."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent


def run(command: list[str], log: pathlib.Path) -> dict:
    completed = subprocess.run(command, cwd=ROOT, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.write_text(completed.stdout, encoding="utf-8")
    result = {"command": command, "exit_code": completed.returncode,
              "log": str(log.relative_to(ROOT))}
    if completed.returncode:
        print(completed.stdout, file=sys.stderr)
        raise RuntimeError(f"Command failed with exit {completed.returncode}: {command}")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Path to a Lean compiler; tested with Lean 4.19.0")
    parser.add_argument("--checks-only", action="store_true", help="Do not rebuild PDF")
    args = parser.parse_args()
    record = {"timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
              "python": sys.version.split()[0], "steps": [],
              "lean_rerun_in_this_build": bool(args.lean), "status": "running"}
    try:
        for name in ("check_schema", "check_arithmetic"):
            record["steps"].append(run(
                [sys.executable, f"checks/{name}.py"], ROOT / "checks" / f"{name}.log"))
        if args.lean:
            lean = str(pathlib.Path(args.lean).resolve()) if "/" in args.lean else args.lean
            version = subprocess.run([lean, "--version"], text=True,
                                     capture_output=True, check=True)
            record["lean_version"] = version.stdout.strip()
            record["steps"].append(run(
                [lean, "formal/CounterRecursionKernel.lean"], ROOT / "formal/lean-check.log"))
            log = (ROOT / "formal/lean-check.log").read_text()
            count = log.count("does not depend on any axioms")
            if count != 15 or "depends on axioms:" in log:
                raise RuntimeError(f"Unexpected Lean dependency report ({count} clean endpoints)")
            record["lean_axiom_free_conditional_endpoints"] = count
        if not args.checks_only:
            if not shutil.which("latexmk"):
                raise RuntimeError("latexmk is required to build report.pdf")
            record["steps"].append(run(
                ["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
                ROOT / "latex-build.log"))
            source_log = (ROOT / "report.log").read_text(errors="replace")
            errors = [line for line in source_log.splitlines()
                      if "Overfull" in line or "undefined" in line.lower()]
            if errors:
                raise RuntimeError("LaTeX layout/reference checks need review: " + repr(errors))
            record["pdf_bytes"] = (ROOT / "report.pdf").stat().st_size
        record["status"] = "passed"
    except Exception as error:
        record["status"] = "failed"
        record["error"] = str(error)
        raise
    finally:
        (ROOT / "build-results.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
