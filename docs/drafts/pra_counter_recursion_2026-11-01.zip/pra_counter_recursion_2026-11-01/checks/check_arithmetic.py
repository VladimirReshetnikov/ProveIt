#!/usr/bin/env python3
"""Finite checks of the paper's exact counter-recursive term definitions.

These computations are regression checks on standard natural numbers.
They are not a formal proof of the theory, of induction, or of either
interpretation. The paper supplies those arguments.
"""

from collections import defaultdict
import json


def successor(value):
    return value + 1


BODIES = {}
TRACES = defaultdict(list)


def recursor(body_name, count, seed):
    """Evaluate R_h(count, seed), caching each exact recursive trace."""
    if count < 0 or seed < 0:
        raise ValueError("Natural-number arguments are required")
    trace = TRACES[(body_name, seed)]
    if not trace:
        trace.append(seed)
    body = BODIES[body_name]
    while len(trace) <= count:
        counter = len(trace) - 1
        trace.append(body(trace[-1], counter))
    return trace[count]


def predecessor(value):
    return recursor("counter", value, 0)


def zero_select(count, seed):
    return recursor("zero", count, seed)


def select(test, zero_branch, successor_branch):
    # C(r,b,c) = R_w(Z(r,Sb), Z(Z(r,1),c)).
    return recursor(
        "counter",
        zero_select(test, successor(zero_branch)),
        zero_select(zero_select(test, 1), successor_branch),
    )


def add(left, right):
    return recursor("successor", right, left)


def difference(left, right):
    return recursor("predecessor", right, left)


def parity(value):
    return recursor("toggle", value, 0)


def half(value):
    return recursor("half", value, 0)


def double(value):
    return add(value, value)


def power_double(count, seed):
    return recursor("double", count, seed)


def strip0(value):
    return select(parity(value), half(value), value)


def strip1(value):
    return select(parity(value), half(value), successor(successor(value)))


def odd_part(value):
    return recursor("strip0", value, value)


def companion(value):
    return recursor("strip1", value, value)


def pair(left, right):
    return power_double(left, successor(double(right)))


def left_projection(value):
    return difference(value, half(difference(companion(value), odd_part(value))))


def right_projection(value):
    return half(odd_part(value))


BODIES.update(
    counter=lambda state, counter: counter,
    zero=lambda state, counter: 0,
    successor=lambda state, counter: successor(state),
    predecessor=lambda state, counter: predecessor(state),
    toggle=lambda state, counter: zero_select(state, 1),
    half=lambda state, counter: select(parity(counter), state, successor(state)),
    double=lambda state, counter: double(state),
    strip0=lambda state, counter: strip0(state),
    strip1=lambda state, counter: strip1(state),
)


def encode(values):
    result = 0
    for value in reversed(values):
        result = pair(value, result)
    return result


def decode(code, length):
    result = []
    for _ in range(length):
        result.append(left_projection(code))
        code = right_projection(code)
    return tuple(result)


def main():
    checks = 0
    families = defaultdict(int)

    def check(family, actual, expected, context):
        nonlocal checks
        if actual != expected:
            raise AssertionError(
                f"{family}: {context}: got {actual!r}, expected {expected!r}"
            )
        checks += 1
        families[family] += 1

    for name, body in BODIES.items():
        for seed in range(8):
            check("recursor_base", recursor(name, 0, seed), seed, (name, seed))
            for counter in range(13):
                check(
                    "recursor_step",
                    recursor(name, counter + 1, seed),
                    body(recursor(name, counter, seed), counter),
                    (name, counter, seed),
                )

    for n in range(129):
        check("predecessor", predecessor(n), max(n - 1, 0), n)
        check("parity", parity(n), n % 2, n)
        check("halving", half(n), n // 2, n)
        check("half_even", half(double(n)), n, n)
        check("half_odd", half(successor(double(n))), n, n)

    for test in range(7):
        for zero_branch in range(8):
            for successor_branch in range(8):
                check(
                    "selector",
                    select(test, zero_branch, successor_branch),
                    zero_branch if test == 0 else successor_branch,
                    (test, zero_branch, successor_branch),
                )

    for x in range(13):
        for y in range(13):
            check("addition", add(x, y), x + y, (x, y))
            check("difference", difference(x, y), max(x - y, 0), (x, y))
            check(
                "native_equality_test",
                difference(successor(x), y) == 1,
                x == y,
                (x, y),
            )

    max_pair_code = 0
    for x in range(6):
        for y in range(6):
            code = pair(x, y)
            max_pair_code = max(max_pair_code, code)
            check("pair_value", code, 2**x * (2 * y + 1), (x, y))
            check("left_retraction", left_projection(code), x, (x, y, code))
            check("right_retraction", right_projection(code), y, (x, y, code))

    for code in range(257):
        if code == 0:
            expected_left = expected_right = 0
        else:
            expected_left = (code & -code).bit_length() - 1
            expected_right = ((code >> expected_left) - 1) // 2
        check("all_code_left", left_projection(code), expected_left, code)
        check("all_code_right", right_projection(code), expected_right, code)

    for a in range(3):
        for b in range(3):
            for c in range(3):
                values = (a, b, c)
                check("tuple_retraction", decode(encode(values), 3), values, values)

    print(
        json.dumps(
            {
                "status": "pass",
                "checks": checks,
                "families": dict(sorted(families.items())),
                "pair_input_bound_inclusive": 5,
                "largest_pair_code_in_retraction_grid": max_pair_code,
                "all_code_bound_inclusive": 256,
                "tuple_length": 3,
                "tuple_coordinate_bound_inclusive": 2,
                "evaluation": "Exact primitive-recursion traces with memoization",
                "scope": "Finite numerical checks; not a theorem proof or formal verification",
            },
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
