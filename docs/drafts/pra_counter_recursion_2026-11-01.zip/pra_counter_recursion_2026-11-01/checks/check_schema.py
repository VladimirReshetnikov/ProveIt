#!/usr/bin/env python3
"""Generate and check finite axiom instances for counter-aware recursion.

Python 3.10+, standard library only. This script checks syntax, active AST
counts, binding, and descriptor discipline. It does not prove the infinite
schema, consistency, induction strength, or bi-interpretability.

Run this file to write results.json and examples.txt beside it.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import random


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple[Term, ...] = ()
    name: str = ""
    body: Term | None = None


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple[Formula | Term, ...] = ()
    bound: str = ""


def var(name):
    return Term("var", name=name)


ZERO = Term("zero")
n, a, v, w = (var(name) for name in ("n", "a", "v", "w"))


def succ(t):
    return Term("succ", (t,))


ONE = succ(ZERO)


def rec(body, counter, seed):
    return Term("rec", (counter, seed), body=body)


def delay(body, counter, seed):
    return Term("delay", (counter, seed), body=body)


def substitute(t, replacements):
    """Simultaneous substitution in active arguments only."""
    if t.tag == "var":
        return replacements.get(t.name, t)
    return Term(t.tag, tuple(substitute(x, replacements) for x in t.args),
                t.name, t.body)


def free_term(t):
    if t.tag == "var":
        return {t.name}
    return set().union(*(free_term(x) for x in t.args))


def validate(t, allowed, *, baseline=False, path=None):
    """Check arities, frozen-body variables, and absence of cyclic syntax."""
    path = set() if path is None else path
    if id(t) in path:
        raise ValueError("A descriptor or active term contains a cycle")
    path.add(id(t))
    try:
        iterator_tag = "delay" if baseline else "rec"
        arities = {"zero": 0, "var": 0, "succ": 1, iterator_tag: 2}
        if t.tag not in arities or len(t.args) != arities[t.tag]:
            raise ValueError("Illegal tag or arity")
        if t.tag == "var" and t.name not in allowed:
            raise ValueError("Unbound active variable")
        if t.tag == iterator_tag:
            if t.body is None:
                raise ValueError("Missing stored descriptor")
            validate(t.body, {"v"} if baseline else {"v", "w"},
                     baseline=baseline, path=path)
        elif t.body is not None:
            raise ValueError("Only a generated symbol may store a descriptor")
        for x in t.args:
            validate(x, allowed, baseline=baseline, path=path)
    finally:
        path.remove(id(t))


def term_nodes(t, *, stored=False):
    result = 1 + sum(term_nodes(x, stored=stored) for x in t.args)
    if stored and t.body is not None:
        result += term_nodes(t.body, stored=True)
    return result


def occurrences(t, name):
    return int(t.tag == "var" and t.name == name) + sum(
        occurrences(x, name) for x in t.args)


def rank(t):
    """Finite descriptor-dependency stage; active arguments do not bind."""
    stages = [0] + [rank(x) for x in t.args]
    if t.body is not None:
        stages.append(1 + rank(t.body))
    return max(stages)


def term_text(t):
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "succ":
        return "S(" + term_text(t.args[0]) + ")"
    symbol = {"rec": "R", "delay": "D"}[t.tag]
    return (symbol + "[" + term_text(t.body) + "](" +
            ",".join(term_text(x) for x in t.args) + ")")


def eq(x, y):
    return Formula("eq", (x, y))


def binary(tag, x, y):
    return Formula(tag, (x, y))


def all_(name, f):
    return Formula("all", (f,), name)


def formula_nodes(f, *, stored=False):
    return 1 + sum(term_nodes(x, stored=stored) if isinstance(x, Term)
                   else formula_nodes(x, stored=stored) for x in f.args)


def free_formula(f):
    result = set().union(*(free_term(x) if isinstance(x, Term)
                          else free_formula(x) for x in f.args))
    return result - {f.bound} if f.tag == "all" else result


def names_formula(f):
    result = set().union(*(free_term(x) if isinstance(x, Term)
                          else names_formula(x) for x in f.args))
    return result | ({f.bound} if f.tag == "all" else set())


def substitute_formula(f, replacements):
    """Capture-avoiding formula substitution, including shadowed binders."""
    if f.tag == "all":
        body, bound = f.args[0], f.bound
        remaining = {key: value for key, value in replacements.items()
                     if key != bound}
        relevant = {key: value for key, value in remaining.items()
                    if key in free_formula(body)}
        if any(bound in free_term(value) for value in relevant.values()):
            used = names_formula(body) | set(remaining)
            for value in remaining.values():
                used.update(free_term(value))
            index = 0
            while f"{bound}_{index}" in used:
                index += 1
            fresh = f"{bound}_{index}"
            body = substitute_formula(body, {bound: var(fresh)})
            bound = fresh
        return all_(bound, substitute_formula(body, remaining))
    return Formula(f.tag, tuple(substitute(x, replacements)
                                if isinstance(x, Term)
                                else substitute_formula(x, replacements)
                                for x in f.args), f.bound)


def quantifiers(f, depth=0):
    next_depth = depth + int(f.tag == "all")
    count, maximum = int(f.tag == "all"), next_depth
    for x in f.args:
        if isinstance(x, Formula):
            child_count, child_maximum = quantifiers(x, next_depth)
            count += child_count
            maximum = max(maximum, child_maximum)
    return count, maximum


def formula_rank(f):
    return max([0] + [rank(x) if isinstance(x, Term)
                      else formula_rank(x) for x in f.args])


def formula_text(f):
    if f.tag == "bot":
        return "false"
    if f.tag == "eq":
        return "(" + term_text(f.args[0]) + "=" + term_text(f.args[1]) + ")"
    if f.tag == "all":
        return "forall " + f.bound + " (" + formula_text(f.args[0]) + ")"
    operator = {"and": " AND ", "or": " OR ", "imp": " -> "}[f.tag]
    return "(" + formula_text(f.args[0]) + operator + formula_text(f.args[1]) + ")"


def adjacent_fragments(u):
    equality = eq(u, substitute(u, {"a": succ(a)}))
    rooted = binary("or", eq(n, ZERO), equality)
    progress = all_("n", binary("imp", rooted,
                    substitute_formula(equality, {"n": succ(n)})))
    return rooted, progress


def axiom(u, *, depth_two=False):
    validate(u, {"n", "a"})
    body = substitute(u, {"n": v, "a": w})
    separation = binary("imp", eq(ZERO, ONE), Formula("bot"))
    seed = eq(rec(body, ZERO, a), a)
    tail = eq(rec(body, succ(n), a),
              substitute(u, {"n": rec(body, n, a), "a": n}))
    computation = binary("and", separation, binary("and", seed, tail))
    rooted, progress = adjacent_fragments(u)
    if depth_two:
        return all_("a", binary("and", all_("n", computation),
                    binary("imp", progress, all_("n", rooted))))
    return all_("a", all_("n", binary("and", computation,
                binary("imp", progress, rooted))))


def matched_baseline_term(t, *, in_body=False):
    """Match active trees, NOT meanings: erase stored counter variables."""
    if t.tag == "var":
        return ZERO if in_body and t.name == "w" else t
    if t.tag == "rec":
        return delay(matched_baseline_term(t.body, in_body=True),
                     *(matched_baseline_term(x, in_body=in_body) for x in t.args))
    return Term(t.tag, tuple(matched_baseline_term(x, in_body=in_body)
                            for x in t.args), t.name)


def baseline_axiom(u):
    validate(u, {"n", "a"}, baseline=True)
    body = substitute(u, {"n": v, "a": ZERO})
    separation = binary("imp", eq(ZERO, ONE), Formula("bot"))
    reset = eq(delay(body, delay(ONE, n, ZERO), a), a)
    tail = eq(delay(body, succ(succ(n)), a),
              substitute(body, {"v": delay(body, succ(n), a)}))
    computation = binary("and", separation, binary("and", reset, tail))
    rooted, progress = adjacent_fragments(u)
    return all_("a", binary("imp", progress,
                all_("n", binary("and", rooted, computation))))


def samples():
    bodies = [v, w, ZERO, succ(v), succ(w), rec(w, v, w),
              rec(succ(v), w, v), rec(rec(w, v, w), v, w)]
    terms = [n, a, ZERO, ONE, succ(n), succ(a)]
    terms += [rec(h, x, y) for h in bodies
              for x in [n, a, ZERO, succ(n), succ(a)]
              for y in [n, a, ZERO, ONE]]
    rng = random.Random(20261101)

    def generate(depth):
        if depth == 0 or rng.randrange(4) == 0:
            return rng.choice([n, a, ZERO])
        if rng.randrange(3) == 0:
            return succ(generate(depth - 1))
        return rec(rng.choice(bodies), generate(depth - 1), generate(depth - 1))

    terms += [generate(4) for _ in range(320)]
    return list(dict.fromkeys(terms))


CHECKS = {}


def check(group, condition):
    if not condition:
        raise AssertionError(group)
    CHECKS[group] = CHECKS.get(group, 0) + 1


def reject(t):
    try:
        validate(t, {"n", "a"})
    except ValueError:
        check("invalid_syntax_rejected", True)
    else:
        raise AssertionError("Invalid syntax was admitted")


def main():
    inputs = samples()
    for u in inputs:
        m, i, j = term_nodes(u), occurrences(u, "n"), occurrences(u, "a")
        body = substitute(u, {"n": v, "a": w})
        validate(body, {"v", "w"})
        check("body_rank_preserved", rank(body) == rank(u))
        check("body_size_preserved", term_nodes(body) == m)
        check("body_variables", free_term(body) <= {"v", "w"})
        old_u = matched_baseline_term(u)
        validate(old_u, {"n", "a"}, baseline=True)
        check("matched_input_active_size", term_nodes(old_u) == m)
        check("matched_input_occurrences",
              (occurrences(old_u, "n"), occurrences(old_u, "a")) == (i, j))
        old_size = formula_nodes(baseline_axiom(old_u))
        check("baseline_node_formula", old_size == 38 + 7*m + 5*i + 3*j)
        for depth_two in (False, True):
            f = axiom(u, depth_two=depth_two)
            expected = 35 + int(depth_two) + 7*m + 4*i + 3*j
            check("new_node_formula", formula_nodes(f) == expected)
            check("strict_matched_syntax_saving",
                  old_size - formula_nodes(f) == 3 - int(depth_two) + i)
            check("closed_axioms", free_formula(f) == set())
            check("two_active_names", names_formula(f) <= {"n", "a"})
            check("quantifier_profiles", quantifiers(f) ==
                  ((4, 2) if depth_two else (3, 3)))
            check("next_stage_bound", formula_rank(f) == rank(u) + 1)

    frozen_body = rec(w, v, w)
    frozen = rec(frozen_body, n, a)
    changed = substitute(frozen, {"n": succ(a), "a": ZERO, "v": ONE, "w": ONE})
    check("descriptor_frozen_identity", changed.body is frozen.body)
    check("simultaneous_active_substitution", changed.args == (succ(a), ZERO))
    captured = substitute_formula(all_("a", eq(n, a)), {"n": a})
    check("capture_avoiding_rename", captured.bound != "a")
    check("capture_avoiding_free_variables", free_formula(captured) == {"a"})
    shadowed = all_("n", eq(n, a))
    check("shadowed_binder_protection",
          substitute_formula(shadowed, {"n": ZERO}) == shadowed)

    # An input can mention a recursor admitted at an earlier finite stage.
    first_body = substitute(n, {"n": v, "a": w})
    later_input = rec(first_body, n, a)
    check("earlier_recursor_input_allowed", rank(later_input) == 1)
    check("earlier_recursor_schema_next_stage", formula_rank(axiom(later_input)) == 2)

    reject(var("b"))
    reject(rec(var("z"), n, a))
    reject(rec(n, n, a))
    reject(Term("rec", (n, a)))
    reject(Term("succ", (n, a)))
    reject(Term("zero", body=v))
    cycle = rec(v, n, a)
    object.__setattr__(cycle, "body", cycle)
    reject(cycle)

    examples, rows = [], []
    for u in [n, a, succ(n), succ(a), later_input, rec(w, n, a)]:
        body = substitute(u, {"n": v, "a": w})
        f, alternative = axiom(u), axiom(u, depth_two=True)
        rows.append({"input": term_text(u), "body": term_text(body),
                     "active_nodes": formula_nodes(f),
                     "depth_two_active_nodes": formula_nodes(alternative),
                     "stored_bodies_repeated_nodes": formula_nodes(f, stored=True),
                     "input_stage": rank(u), "output_stage": formula_rank(f)})
        examples += ["INPUT: " + term_text(u), "BODY: " + term_text(body),
                     "THREE-BINDER FORM:", formula_text(f),
                     "DEPTH-TWO FOUR-BINDER FORM:", formula_text(alternative), ""]

    result = {
        "status": "passed",
        "scope": "Finite syntax, binding, staging and AST accounting only; no proof of the infinite theory or its equivalence to PRA.",
        "comparison_warning": "Matched syntax trees only. Stored counter variables are erased in the baseline shape map; that map is not a semantic translation. No uniform translated-instance or proof-length saving is claimed.",
        "count_convention": "One node per active variable, constant, function application, equality, connective or quantifier; frozen descriptor bodies charged separately; 1=S(0).",
        "input_terms": len(inputs),
        "candidate_formulas": 2 * len(inputs),
        "deterministic_seed": 20261101,
        "baseline_formula": "38+7*m+5*i+3*j",
        "three_binder_formula": "35+7*m+4*i+3*j",
        "depth_two_formula": "36+7*m+4*i+3*j",
        "quantifier_profiles": {"three_binder": [3, 3], "depth_two": [4, 2]},
        "checks_by_group": CHECKS,
        "total_checks": sum(CHECKS.values()),
        "examples": rows,
    }
    output = Path(__file__).resolve().parent
    (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    header = ("COUNTER-AWARE RECURSION: EXACT FINITE AXIOM INSTANCES\n\n"
              "R[body](counter,seed) retains a frozen binary descriptor.\n"
              "The body slots v,w mean state,counter. They are not active\n"
              "free individuals of the displayed first-order sentence.\n"
              "The two occurrences of forall n may legally shadow each other.\n\n")
    (output / "examples.txt").write_text(header + "\n".join(examples))
    print(json.dumps({key: result[key] for key in
                      ["status", "input_terms", "candidate_formulas", "total_checks"]}, indent=2))


if __name__ == "__main__":
    main()
