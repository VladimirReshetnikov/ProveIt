ORDINARY COUNTER RECURSION: A SHORTER ONE-SCHEMA PRESENTATION OF PRA
Prepared for Vladimir Reshetnikov, November 1, 2026 (America/Los_Angeles)

START HERE
  report.pdf                 Complete mathematical paper.
  report.tex and sections/   Complete LaTeX source.

RESULT
  One schema over one arbitrary two-variable term, in a generated language
  of binary scalar recursors with state and counter slots. The resulting
  theory has a common conservative definitional extension with PRA,
  separately in classical and intuitionistic first-order logic.

  Active formula size: 35 + 7m + 4i + 3j nodes, compared with the current
  adjacent baseline's 38 + 7m + 5i + 3j. Here m is input term size, i and j
  are its active first-slot and second-slot occurrences. This is a matched
  syntax/template comparison, not a uniform semantic translation bound.

TRADEOFFS
  Stored update bodies now receive the counter. The main formula has
  three quantifier occurrences at depth three; the depth-two alternative
  has four occurrences and still has a shorter active template. No global
  minimality claim is made. The strongest old autonomous-iterator baseline
  remains preferable if unary update bodies are required.

REBUILD
  python3 build.py
  python3 build.py --lean /path/to/lean
  python3 build.py --checks-only

  Requirements: Python 3.10+, latexmk, pdfLaTeX with the standard packages
  used in report.tex. The Lean kernel was checked with Lean 4.19.0 and Std;
  Mathlib is not needed. The build script never downloads dependencies.

VERIFICATION SCOPE
  checks/check_schema.py: finite syntax and exact AST counts, frozen
  descriptors, binding, closure and staging. Results: checks/results.json.
  checks/check_arithmetic.py: exact finite PR evaluations and pairing
  checks. These finite tests are not theorem proofs.
  formal/CounterRecursionKernel.lean: selected constructive bootstrap and
  propagation lemmas over arbitrary carriers, with explicit hypotheses.
  formal/lean-check.log: successful kernel run and 15 dependency reports.
  This is not a formalization of the complete interpretation theorem.

PROVENANCE
  source-manifest.json pins all five inspected ZIP archives to ProveIt
  commit 9e77f2a2bb9ccf0a4f85934f1f83df8a3f8767be, with Git blob and SHA-256
  hashes. The upstream ZIP archives are not redistributed in this package.
  Inherited proof architecture and adapted Lean lemmas are credited in
  the paper and source. The zero-anchor idea is explicitly left unproved.

CONTENTS
  build.py, build-results.json, latex-build.log
  checks/: runnable scripts, finite results and concrete schema examples
  formal/: Lean source, toolchain pin and successful check log
  source-manifest.json: exact baseline metadata
  SHA256SUMS.txt: hashes for the final package contents (excluding itself)
