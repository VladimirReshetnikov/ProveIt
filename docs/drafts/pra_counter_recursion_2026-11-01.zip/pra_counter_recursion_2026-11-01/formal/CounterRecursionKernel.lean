import Std

/-!
Constructive kernel for the counter-aware PRA presentation.

This file checks selected abstract consequences over an arbitrary carrier.
The function parameters stand for fixed term denotations; they are NOT
function variables in the first-order axiom schema. The finite syntax and
substitution rules are checked separately in checks/check_schema.py.

Checked here: payload projection/reassembly, computational predecessor and
selector, coverage, the two parity compilers, arbitrary equation propagation,
and equation induction under local hypotheses. Full truth reflection, pairing,
and the common definitional extension are proved in report.tex, not here.

The adjacent-propagation lemmas are adapted with attribution from
pra_adjacent_parameter_2026-11-01/formal/AdjacentKernel.lean in the audited
ProveIt snapshot. The new kernel/selector lemmas are specific to this package.
No classical tactic, sorry, or additional axiom is used.
-/

namespace CounterRecursionKernel

universe u
variable {A : Type u}

def Rooted (zero : A) (left right : A → A) (n : A) : Prop :=
  n = zero ∨ left n = right n

def Adjacent (zero : A) (succ : A → A) (term : A → A → A) : Prop :=
  ∀ a, (∀ n, Rooted zero (fun k => term k a) (fun k => term k (succ a)) n →
    term (succ n) a = term (succ n) (succ a)) →
    ∀ n, Rooted zero (fun k => term k a) (fun k => term k (succ a)) n

def Propagation (zero : A) (succ : A → A) (left right : A → A → A) : Prop :=
  ∀ a, (∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n →
    left (succ n) a = right (succ n) a) →
    ∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n

def Kernel (zero : A) (succ : A → A) (body recursor : A → A → A)
    (n a : A) : Prop :=
  zero ≠ succ zero ∧
    (recursor zero a = a ∧ recursor (succ n) a = body (recursor n a) n)

def Schema (zero : A) (succ : A → A) (body recursor : A → A → A) : Prop :=
  ∀ a n, Kernel zero succ body recursor n a ∧
    ((∀ k, Rooted zero (fun j => body j a) (fun j => body j (succ a)) k →
      body (succ k) a = body (succ k) (succ a)) →
      Rooted zero (fun j => body j a) (fun j => body j (succ a)) n)

theorem schemaToBasis
    (zero : A) (succ : A → A) (body recursor : A → A → A)
    (schemaInstance : Schema zero succ body recursor) :
    (∀ n a, Kernel zero succ body recursor n a) ∧ Adjacent zero succ body := by
  constructor
  · intro n a
    exact (schemaInstance a n).1
  · intro a progress n
    exact (schemaInstance a n).2 progress

theorem basisToSchema
    (zero : A) (succ : A → A) (body recursor : A → A → A)
    (kernel : ∀ n a, Kernel zero succ body recursor n a)
    (adjacent : Adjacent zero succ body) :
    Schema zero succ body recursor := by
  intro a n
  exact ⟨kernel n a, fun progress => adjacent a progress n⟩

theorem computationalPredecessor
    (zero : A) (succ : A → A) (counter : A → A → A)
    (base : ∀ a, counter zero a = a)
    (step : ∀ n a, counter (succ n) a = n) :
    counter zero zero = zero ∧ ∀ n, counter (succ n) zero = n := by
  exact ⟨base zero, fun n => step n zero⟩

def Select (zero : A) (succ : A → A) (counter zeroTest : A → A → A)
    (test left right : A) : A :=
  counter (zeroTest test (succ left)) (zeroTest (zeroTest test (succ zero)) right)

theorem computationalSelectorZero
    (zero : A) (succ : A → A) (counter zeroTest : A → A → A)
    (counterStep : ∀ n a, counter (succ n) a = n)
    (testZero : ∀ a, zeroTest zero a = a)
    (testSucc : ∀ n a, zeroTest (succ n) a = zero) :
    ∀ x y, Select zero succ counter zeroTest zero x y = x := by
  intro x y
  unfold Select
  rw [testZero, testZero, testSucc, counterStep]

theorem computationalSelectorSucc
    (zero : A) (succ : A → A) (counter zeroTest : A → A → A)
    (counterBase : ∀ a, counter zero a = a)
    (testZero : ∀ a, zeroTest zero a = a)
    (testSucc : ∀ n a, zeroTest (succ n) a = zero) :
    ∀ n x y, Select zero succ counter zeroTest (succ n) x y = y := by
  intro n x y
  unfold Select
  rw [testSucc, testSucc, testZero, counterBase]

theorem successorInjective
    (succ pred : A → A)
    (predSucc : ∀ n, pred (succ n) = n) :
    (∀ x y, succ x = succ y → x = y) := by
  intro x y equalSucc
  have equation := congrArg pred equalSucc
  simpa only [predSucc] using equation

theorem successorNonzero
    (zero : A) (succ pred : A → A)
    (separation : zero ≠ succ zero) (predZero : pred zero = zero)
    (predSucc : ∀ n, pred (succ n) = n) :
    ∀ n, succ n ≠ zero := by
  intro n equalZero
  have collapsed := congrArg pred equalZero
  rw [predSucc, predZero] at collapsed
  apply separation
  rw [collapsed] at equalZero
  exact equalZero.symm

theorem coverageFromAdjacent
    (zero : A) (succ pred : A → A) (selector : A → A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = y)
    (schemaInstance : Adjacent zero succ (fun n a => selector a n (succ (pred n)))) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  have raw := schemaInstance zero (by
    intro n _
    change selector zero (succ n) (succ (pred (succ n))) =
      selector (succ zero) (succ n) (succ (pred (succ n)))
    rw [selectZero, selectOne, predSucc])
  intro n
  have result := raw n
  change n = zero ∨ selector zero n (succ (pred n)) =
    selector (succ zero) n (succ (pred n)) at result
  simpa only [selectZero, selectOne] using result

theorem parityRangeWithoutInduction
    (zero : A) (succ pred parity : A → A) (zeroTest : A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (testZero : ∀ x, zeroTest zero x = x)
    (testSucc : ∀ n x, zeroTest (succ n) x = zero)
    (parityZero : parity zero = zero)
    (parityStep : ∀ n, parity (succ n) = zeroTest (parity n) (succ zero)) :
    ∀ n, parity n = zero ∨ parity n = succ zero := by
  intro n
  cases coverage n with
  | inl atZero => subst n; exact Or.inl parityZero
  | inr atSucc =>
    rw [atSucc, parityStep]
    cases coverage (parity (pred n)) with
    | inl innerZero => rw [innerZero, testZero]; exact Or.inr rfl
    | inr innerSucc => rw [innerSucc, testSucc]; exact Or.inl rfl

theorem parityFlips
    (zero : A) (succ parity : A → A) (zeroTest : A → A → A)
    (testZero : ∀ x, zeroTest zero x = x)
    (testSucc : ∀ n x, zeroTest (succ n) x = zero)
    (parityStep : ∀ n, parity (succ n) = zeroTest (parity n) (succ zero)) :
    (∀ a, parity a = zero → parity (succ a) = succ zero) ∧
    (∀ a, parity a = succ zero → parity (succ a) = zero) := by
  constructor
  · intro a value
    rw [parityStep, value, testZero]
  · intro a value
    rw [parityStep, value, testSucc]

def CompileZero (selector : A → A → A → A) (parity pred : A → A)
    (left right : A → A → A) (n a : A) : A :=
  selector (parity a) (left n a) (right n (pred a))

def CompileOne (selector : A → A → A → A) (parity pred : A → A)
    (left right : A → A → A) (n a : A) : A :=
  selector (parity a) (right n (pred a)) (left n a)

theorem compilerZero
    (zero : A) (succ pred parity : A → A) (selector : A → A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = y)
    (flipZero : ∀ a, parity a = zero → parity (succ a) = succ zero)
    (left right : A → A → A) (a : A) (value : parity a = zero) :
    ∀ n, (CompileZero selector parity pred left right n a =
      CompileZero selector parity pred left right n (succ a)) ↔
      left n a = right n a := by
  intro n
  unfold CompileZero
  rw [value, flipZero a value, predSucc, selectZero, selectOne]

theorem compilerOne
    (zero : A) (succ pred parity : A → A) (selector : A → A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = y)
    (flipOne : ∀ a, parity a = succ zero → parity (succ a) = zero)
    (left right : A → A → A) (a : A) (value : parity a = succ zero) :
    ∀ n, (CompileOne selector parity pred left right n a =
      CompileOne selector parity pred left right n (succ a)) ↔
      left n a = right n a := by
  intro n
  unfold CompileOne
  rw [value, flipOne a value, predSucc, selectZero, selectOne]

theorem transferAtParameter
    (zero : A) (succ : A → A) (left right term : A → A → A)
    (schemaInstance : Adjacent zero succ term) (a : A)
    (bridge : ∀ n, (term n a = term n (succ a)) ↔ left n a = right n a)
    (step : ∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n →
      left (succ n) a = right (succ n) a) :
    ∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n := by
  have rootedBridge : ∀ n,
      Rooted zero (fun k => term k a) (fun k => term k (succ a)) n ↔
      Rooted zero (fun k => left k a) (fun k => right k a) n := by
    intro n
    exact or_congr Iff.rfl (bridge n)
  have result := schemaInstance a (fun n hypothesis =>
    (bridge (succ n)).mpr (step n ((rootedBridge n).mp hypothesis)))
  intro n
  exact (rootedBridge n).mp (result n)

theorem equationPropagation
    (zero : A) (succ pred parity : A → A) (selector : A → A → A → A)
    (predSucc : ∀ n, pred (succ n) = n)
    (selectZero : ∀ x y, selector zero x y = x)
    (selectOne : ∀ x y, selector (succ zero) x y = y)
    (parityRange : ∀ a, parity a = zero ∨ parity a = succ zero)
    (flipZero : ∀ a, parity a = zero → parity (succ a) = succ zero)
    (flipOne : ∀ a, parity a = succ zero → parity (succ a) = zero)
    (left right : A → A → A)
    (zeroInstance : Adjacent zero succ (CompileZero selector parity pred left right))
    (oneInstance : Adjacent zero succ (CompileOne selector parity pred left right)) :
    Propagation zero succ left right := by
  intro a step
  cases parityRange a with
  | inl value =>
    exact transferAtParameter zero succ left right _ zeroInstance a
      (compilerZero zero succ pred parity selector predSucc selectZero selectOne
        flipZero left right a value) step
  | inr value =>
    exact transferAtParameter zero succ left right _ oneInstance a
      (compilerOne zero succ pred parity selector predSucc selectZero selectOne
        flipOne left right a value) step

theorem equationInduction
    (zero : A) (succ : A → A) (left right : A → A → A)
    (propagation : Propagation zero succ left right) (a : A)
    (base : left zero a = right zero a)
    (step : ∀ n, left n a = right n a → left (succ n) a = right (succ n) a) :
    ∀ n, left n a = right n a := by
  have extract : ∀ n, Rooted zero (fun k => left k a) (fun k => right k a) n →
      left n a = right n a := by
    intro n hypothesis
    cases hypothesis with
    | inl atZero => subst n; exact base
    | inr equation => exact equation
  have result := propagation a (fun n hypothesis => step n (extract n hypothesis))
  intro n
  exact extract n (result n)

#print axioms schemaToBasis
#print axioms basisToSchema
#print axioms computationalPredecessor
#print axioms computationalSelectorZero
#print axioms computationalSelectorSucc
#print axioms successorInjective
#print axioms successorNonzero
#print axioms coverageFromAdjacent
#print axioms parityRangeWithoutInduction
#print axioms parityFlips
#print axioms compilerZero
#print axioms compilerOne
#print axioms transferAtParameter
#print axioms equationPropagation
#print axioms equationInduction

end CounterRecursionKernel
