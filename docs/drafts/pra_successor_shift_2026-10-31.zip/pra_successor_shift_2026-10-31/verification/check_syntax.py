#!/usr/bin/env python3
"""Finite syntax and numerical diagnostics for the successor-plus-Shift basis.

Uses only the Python standard library. Run this file from any directory.
It writes schema_metrics.json and syntax_diagnostics.json beside itself.

Scope: these are executable syntax checks and finite standard-model examples,
not a proof of any axiom schema, induction principle, or bi-interpretation.
Stored iterator descriptors are symbol indices, not ordinary term arguments.
The external holes e, Rstar, f, g_m, and r_m denote finite term substitutions;
they do not introduce numerical function variables or primitive symbols.
"""

import argparse
import json
from dataclasses import dataclass
from itertools import product
from pathlib import Path


@dataclass(frozen=True)
class Node:
    kind: str
    args: tuple = ()
    name: str = ""


def var(name):
    return Node("var", name=name)


ZERO = Node("zero")


def app(name, *args):
    return Node("app", tuple(args), name)


def hole(name, *args):
    return Node("hole", tuple(args), name)


def iteration(name, counter, seed):
    return Node("iter", (counter, seed), name)


def successor(term):
    return app("S", term)


ONE = successor(ZERO)


def eq(left, right):
    return Node("eq", (left, right))


def implies(left, right):
    return Node("implies", (left, right))


def conjunction(left, right):
    return Node("and", (left, right))


def disjunction(left, right):
    return Node("or", (left, right))


def forall(name, body):
    return Node("forall", (body,), name)


def negation(body):
    return implies(body, Node("false"))


def biconditional(left, right):
    return conjunction(implies(left, right), implies(right, left))


def node_count(term):
    return 1 + sum(node_count(child) for child in term.args)


def equality_count(term):
    return int(term.kind == "eq") + sum(equality_count(c) for c in term.args)


def variables(term):
    """Free numerical variables; stored iterator indices are intentionally opaque."""
    if term.kind == "var":
        return {term.name}
    found = set().union(*(variables(child) for child in term.args))
    if term.kind == "forall":
        found.discard(term.name)
    return found


def substitute(term, replacements):
    """Simultaneous *term* substitution, never substitution into stored indices."""
    if term.kind == "var":
        return replacements.get(term.name, term)
    if term.kind == "forall":
        raise ValueError("This deliberately term-only substitution does not bind variables")
    return Node(term.kind,
                tuple(substitute(child, replacements) for child in term.args),
                term.name)


def render(term):
    if term.kind == "var":
        return term.name
    if term.kind == "zero":
        return "0"
    if term.kind == "iter":
        return "I_" + term.name + "(" + ",".join(map(render, term.args)) + ")"
    if term.kind in {"app", "hole"}:
        prefix = "$" if term.kind == "hole" else ""
        return prefix + term.name + "(" + ",".join(map(render, term.args)) + ")"
    if term.kind == "forall":
        return "forall " + term.name + ".(" + render(term.args[0]) + ")"
    if not term.args:
        return term.kind
    return term.kind + "(" + ",".join(map(render, term.args)) + ")"


def referenced_iterators(term):
    found = {term.name} if term.kind == "iter" else set()
    return found.union(*(referenced_iterators(child) for child in term.args))


def referenced_holes(term):
    found = {term.name} if term.kind == "hole" else set()
    return found.union(*(referenced_holes(child) for child in term.args))


class Language:
    def __init__(self, hole_arities):
        self.descriptors = {}
        self.hole_arities = hole_arities

    def check_term(self, term):
        if term.kind in {"var", "zero"}:
            if term.args:
                raise ValueError("A variable or zero has arguments")
        elif term.kind == "app":
            if term.name != "S" or len(term.args) != 1:
                raise ValueError("Only S is a primitive application in an actual term")
        elif term.kind == "iter":
            if len(term.args) != 2 or term.name not in self.descriptors:
                raise ValueError("Unknown, forward, or nonbinary iterator reference")
        elif term.kind == "hole":
            if self.hole_arities.get(term.name) != len(term.args):
                raise ValueError("Incorrect arity for an external finite-term hole")
        else:
            raise ValueError("A formula was supplied where a term was required")
        for child in term.args:
            self.check_term(child)

    def declare(self, name, descriptor):
        if name in self.descriptors:
            raise ValueError("Descriptor name already declared")
        self.check_term(descriptor)
        if not variables(descriptor) <= {"k", "v"}:
            raise ValueError("An iterator descriptor contains a passive parameter")
        self.descriptors[name] = descriptor


def build_language():
    arities = {"e": 2, "Rstar": 2, "f": 2}
    for length in range(4):
        arities["g" + str(length)] = length
        arities["r" + str(length)] = length + 2
    language = Language(arities)
    k, v = var("k"), var("v")
    language.declare("P", k)
    language.declare("A", successor(v))
    language.declare("B", ZERO)
    language.declare("M", pred(v))
    language.declare("delay", selector(k, v, successor(v)))
    language.declare("epsilon", zero_test(v))
    language.declare("half", selector(parity(k), v, successor(v)))
    language.declare("latch", bit_pair(
        half(v), selector(hole("e", k, half(v)), parity(v), ZERO)))
    language.declare("scanner", bit_pair(
        half(v), bit_and(parity(v), hole("Rstar", k, monus(k, half(v))))))
    language.declare("triangular", add(v, successor(k)))
    language.declare("rank", selector(
        distance(successor(k), triangular(successor(v))), successor(v), v))
    for length in range(4):
        passive = [tuple_get(left(v), j) for j in range(length)]
        language.declare("pr" + str(length), pair(
            left(v), hole("r" + str(length), k, right(v), *passive)))
    return language


# Every helper below expands to 0, S, and already declared binary iterators.
def pred(x):
    return iteration("P", x, ZERO)


def add(x, y):
    return iteration("A", x, y)


def gate(x, y):
    return iteration("B", x, y)


def selector(z, u, w):
    return iteration("P", gate(z, successor(u)), w)


def zero_test(x):
    return gate(x, ONE)


def monus(x, y):
    return iteration("M", x, y)


def delayed(n, seed):
    return iteration("delay", n, seed)


def parity(n):
    return iteration("epsilon", n, ZERO)


def half(n):
    return iteration("half", n, ZERO)


def double(x):
    return add(x, x)


def bit_pair(number, bit):
    return selector(bit, double(number), successor(double(number)))


def bit_and(x, y):
    return selector(x, ZERO, y)


def distance(x, y):
    return add(monus(x, y), monus(y, x))


def cancellation_term(x, k):
    return monus(k, add(x, k))


def latch(n, a):
    return iteration("latch", n, bit_pair(a, ONE))


def latch_bit(n, a):
    return parity(latch(n, a))


def scan(n, a):
    return iteration("scanner", n, bit_pair(a, ONE))


def scan_bit(n, a):
    return parity(scan(n, a))


def triangular(n):
    return iteration("triangular", n, ZERO)


def rank(n):
    return iteration("rank", n, ZERO)


def pair(x, y):
    return add(triangular(add(x, y)), y)


def right(code):
    return monus(triangular(rank(code)), code)


def left(code):
    return monus(right(code), rank(code))


def tuple_pack(entries):
    result = ZERO
    for entry in reversed(entries):
        result = pair(entry, result)
    return result


def tuple_get(code, index):
    for _ in range(index):
        code = right(code)
    return left(code)


def pr_seed(length, parameters):
    return pair(tuple_pack(parameters), hole("g" + str(length), *parameters))


def pr_translation(length, counter, parameters):
    return right(iteration("pr" + str(length), counter, pr_seed(length, parameters)))


def schema_metrics(language):
    n, a, x, y = [var(name) for name in ("n", "a", "x", "y")]
    f = lambda t: hole("f", t, a)
    separate = negation(eq(ZERO, ONE))
    d0 = forall("a", eq(app("I_h", ZERO, a), a))
    ds = forall("n", forall("a", eq(
        app("I_h", successor(n), a), app("h", n, app("I_h", n, a)))))
    premise = forall("n", eq(f(successor(n)), successor(f(n))))
    ssu = forall("a", implies(premise, conjunction(separate,
        forall("n", disjunction(eq(n, ZERO),
                               eq(f(n), successor(delayed(n, f(ZERO)))))))))
    shift = forall("n", forall("a", eq(
        monus(successor(n), successor(a)), monus(n, a))))
    au_s = forall("a", implies(premise, conjunction(separate,
        forall("n", disjunction(eq(n, ZERO), eq(f(n), add(pred(n), f(ONE))))))))
    du = forall("a", implies(
        forall("n", eq(f(successor(n)), app("rho", f(n)))),
        conjunction(separate, forall("n", disjunction(eq(n, ZERO), eq(
            f(n), app("rho", app("D_rho", n, f(ZERO)))))))))
    pc = forall("a", implies(
        forall("n", eq(f(successor(successor(n))), f(successor(n)))),
        forall("n", disjunction(eq(n, ZERO), eq(f(n), f(ONE))))))
    er = forall("x", forall("y", biconditional(
        eq(x, y), negation(eq(gate(distance(x, y), ONE), ZERO)))))
    formulas = {"D0": d0, "DS": ds, "SSU": ssu, "Shift": shift,
                "direct_AU_S": au_s, "previous_generic_DU": du,
                "positive_constancy_PC": pc, "fixed_ER_expanded_iff": er}
    expected = {"D0": 6, "DS": 12, "SSU": 34, "Shift": 11,
                "direct_AU_S": 36, "previous_generic_DU": 34,
                "positive_constancy_PC": 26, "fixed_ER_expanded_iff": 39}
    rows = {}
    for name, formula in formulas.items():
        actual = node_count(formula)
        if actual != expected[name]:
            raise AssertionError((name, actual, expected[name]))
        if variables(formula):
            raise AssertionError("Displayed formula has free numerical variables: " + name)
        rows[name] = {"nodes": actual, "equality_occurrences": equality_count(formula),
                      "formula": render(formula)}
    descriptor_rows = []
    for name, descriptor in language.descriptors.items():
        descriptor_rows.append({
            "name": name, "expanded_body": render(descriptor),
            "body_nodes": node_count(descriptor),
            "free_variables": sorted(variables(descriptor)),
            "earlier_iterator_indices": sorted(referenced_iterators(descriptor)),
            "external_term_holes": sorted(referenced_holes(descriptor))})
    assert node_count(language.descriptors["delay"]) == 7
    assert node_count(language.descriptors["M"]) == 3
    return {
        "scope": "Exact counts of displayed formula trees; not a minimum-description theorem.",
        "convention": {
            "one_node_each": ["variable", "0", "function application", "equality",
                              "logical connective", "falsehood", "individual quantifier"],
            "expanded_abbreviations": ["1=S(0)", "p(x)=I_P(x,0)",
                                       "negation=A implies false", "iff=two implications"],
            "helper_policy": "C, Z, delta, pairing and other helper terms are expanded. A declared iterator application counts as one application plus its two arguments.",
            "descriptor_policy": "Stored descriptor bodies are reported separately below. They are finite symbol indices, not extra application arguments.",
            "schema_policy": "Displayed f, h and rho applications count with their displayed arguments, not with every possible substituted finite body.",
            "total_policy": "Totals are sums of closed templates, without inserting artificial conjunctions between axioms."},
        "formulas": rows,
        "totals": {
            "computation_D": node_count(d0) + node_count(ds),
            "main_D_SSU_Shift": sum(map(node_count, (d0, ds, ssu, shift))),
            "direct_D_AU_S_Shift": sum(map(node_count, (d0, ds, au_s, shift))),
            "previous_D_PC_ER": sum(map(node_count, (d0, ds, pc, er))),
            "previous_D_generic_DU": sum(map(node_count, (d0, ds, du)))},
        "comparison_caution": "The previous generic DU total is smaller than 63 but has two unrestricted arithmetic term choices f,rho. The main basis has only f and a fixed equation; no total-node improvement over generic DU is claimed.",
        "descriptor_bodies": descriptor_rows,
        "fixed_main_iterator_descriptor_cost": {
            "names": ["P", "A", "B", "M", "delay"],
            "body_nodes_sum": sum(node_count(language.descriptors[name])
                                  for name in ["P", "A", "B", "M", "delay"]),
            "caution": "Excludes name encodings, declaration delimiters, and the infinite language-generation grammar. It is not an all-in description length."}}


def syntax_diagnostics(language):
    n, a, k, x, y, b, c = [var(t) for t in ("n", "a", "k", "x", "y", "b", "c")]
    templates = [
        ("predecessor", pred(x), {"x"}),
        ("selector_fully_expanded", selector(var("z"), var("u"), var("w")), {"z", "u", "w"}),
        ("zero_test", zero_test(x), {"x"}),
        ("delayed_iterator", delayed(n, a), {"n", "a"}),
        ("parity", parity(n), {"n"}), ("half", half(n), {"n"}),
        ("bit_encoding", bit_pair(x, b), {"x", "b"}),
        ("general_ramp", add(n, hole("f", n, a)), {"n", "a"}),
        ("H", cancellation_term(x, k), {"x", "k"}),
        ("H_zero_status_ramp", add(k, zero_test(cancellation_term(x, k))), {"x", "k"}),
        ("latch_state", latch(n, a), {"n", "a"}),
        ("latch_bit", latch_bit(n, a), {"n", "a"}),
        ("latch_parameter_projection", half(latch(n, a)), {"n", "a"}),
        ("scanner_state", scan(n, k), {"n", "k"}),
        ("scanner_bit", scan_bit(n, k), {"n", "k"}),
        ("scanner_parameter_projection", half(scan(n, k)), {"n", "k"}),
        ("triangular", triangular(k), {"k"}), ("rank", rank(n), {"n"}),
        ("pair", pair(x, y), {"x", "y"}),
        ("pair_left", left(c), {"c"}), ("pair_right", right(c), {"c"}),
        ("native_equality_error", distance(x, y), {"x", "y"}),
    ]
    for length in range(4):
        parameters = [var("a" + str(i + 1)) for i in range(length)]
        allowed = {p.name for p in parameters}
        templates.append(("tuple_" + str(length), tuple_pack(parameters), allowed))
        templates.append(("pr_seed_" + str(length), pr_seed(length, parameters), allowed))
        templates.append(("pr_translation_" + str(length),
                          pr_translation(length, n, parameters), allowed | {"n"}))
        templates.append(("pr_preservation_" + str(length),
                          left(iteration("pr" + str(length), n, c)), {"n", "c"}))
        for index in range(length):
            templates.append(("tuple_decoder_%d_%d" % (length, index + 1),
                              tuple_get(c, index), {"c"}))
    rows = []
    for name, term, allowed in templates:
        language.check_term(term)
        found = variables(term)
        if not found <= allowed:
            raise AssertionError((name, sorted(found), sorted(allowed)))
        rows.append({"name": name, "nodes": node_count(term),
                     "free_variables": sorted(found), "allowed_variables": sorted(allowed),
                     "external_term_holes": sorted(referenced_holes(term)), "passed": True})

    # Renaming term arguments must leave the stored descriptor literally unchanged.
    original_descriptors = dict(language.descriptors)
    original = iteration("half", var("k"), var("v"))
    replacement = {"k": a, "v": ONE}
    renamed = substitute(original, replacement)
    assert renamed == iteration("half", a, ONE)
    assert language.descriptors == original_descriptors
    compound = latch_bit(n, a)
    changed = substitute(compound, {"a": x, "k": y, "v": c})
    assert variables(changed) == {"n", "x"}
    assert referenced_iterators(changed) == referenced_iterators(compound)
    assert language.descriptors == original_descriptors

    negative_checks = []
    for label, name, bad_descriptor in [
        ("reject_passive_parameter", "bad_parameter", add(var("v"), var("a"))),
        ("reject_self_reference", "bad_self", iteration("bad_self", var("k"), var("v"))),
        ("reject_hole_arity", "bad_hole", hole("e", var("v"))),
    ]:
        try:
            language.declare(name, bad_descriptor)
        except ValueError as error:
            negative_checks.append({"name": label, "rejected": True, "reason": str(error)})
        else:
            raise AssertionError("Illegal descriptor was admitted: " + label)
    return {"template_count": len(rows), "templates": rows,
            "descriptor_count": len(language.descriptors),
            "descriptor_dependency_order_checked": True,
            "ordinary_substitution_preserves_stored_indices": True,
            "substitution_examples": [render(renamed), render(changed)],
            "negative_checks": negative_checks,
            "parameter_audit": [
                {"use": "ordinary constancy ramp", "counter": "n", "passive": ["a"]},
                {"use": "zero status of H", "counter": "k", "passive": ["x"]},
                {"use": "cancellation from H", "counter": "x", "passive": ["k"]},
                {"use": "latch preservation and tail", "counter": "n", "passive": ["a"]},
                {"use": "scanner preservation", "counter": "n", "passive": ["k"]},
                {"use": "PR state preservation", "counter": "n", "passive": ["c"]}],
            "scope": "Uniform free-variable/dependency checks on finite templates and four fixed compiler arities (0,1,2,3); not a formal proof for all source descriptions."}


class Evaluator:
    """Interpret the actual finite descriptor ASTs on standard natural numbers."""
    def __init__(self, language, hole_bodies):
        self.language = language
        self.hole_bodies = hole_bodies
        self.cache = {}

    def evaluate(self, term, environment):
        if term.kind == "var":
            return environment[term.name]
        if term.kind == "zero":
            return 0
        if term.kind == "app" and term.name == "S":
            return self.evaluate(term.args[0], environment) + 1
        if term.kind == "iter":
            counter, seed = (self.evaluate(child, environment) for child in term.args)
            return self.run_iterator(term.name, counter, seed)
        if term.kind == "hole":
            names, body = self.hole_bodies[term.name]
            values = [self.evaluate(child, environment) for child in term.args]
            return self.evaluate(body, dict(zip(names, values)))
        raise ValueError("Cannot numerically evaluate " + term.kind)

    def run_iterator(self, name, counter, seed):
        if counter < 0 or seed < 0:
            raise ValueError("Numerical diagnostics use natural numbers only")
        direct_key = (name, counter, seed)
        if direct_key in self.cache:
            return self.cache[direct_key]
        state = seed
        self.cache.setdefault((name, 0, seed), seed)
        for index in range(counter):
            key = (name, index + 1, seed)
            if key in self.cache:
                state = self.cache[key]
            else:
                state = self.evaluate(self.language.descriptors[name], {"k": index, "v": state})
                self.cache[key] = state
        return state


def numeric_diagnostics(language, bound):
    n, a, x, y = [var(name) for name in ("n", "a", "x", "y")]
    holes = {
        "e": (("n", "a"), selector(distance(n, a), ONE, ZERO)),
        "Rstar": (("x", "y"), zero_test(monus(y, x))),
        "f": (("n", "a"), add(n, a)),
    }
    for length in range(4):
        names = tuple("a" + str(i + 1) for i in range(length))
        total = ZERO
        for name in names:
            total = add(total, var(name))
        holes["g" + str(length)] = (names, total)
        holes["r" + str(length)] = (("k", "r") + names,
                                  add(var("r"), successor(total)))
    evaluator = Evaluator(language, holes)
    checks = {}

    def value(term):
        return evaluator.evaluate(term, {})

    numerals = [ZERO]
    for _ in range(max(3, bound + 2)):
        numerals.append(successor(numerals[-1]))

    def number(integer):
        while len(numerals) <= integer:
            numerals.append(successor(numerals[-1]))
        return numerals[integer]

    def check(name, condition):
        if not condition:
            raise AssertionError("Numerical diagnostic failed: " + name)
        checks[name] = checks.get(name, 0) + 1

    for i, j in product(range(bound + 1), repeat=2):
        ni, nj = number(i), number(j)
        check("P_constructor_equations", value(iteration("P", ZERO, nj)) == j and
              value(iteration("P", successor(ni), nj)) == i)
        check("delayed_successor_equations", value(delayed(ZERO, nj)) == j and
              value(delayed(ONE, nj)) == j and
              value(delayed(successor(successor(ni)), nj)) ==
              1 + value(delayed(successor(ni), nj)))
        check("Shift", value(monus(successor(ni), successor(nj))) == value(monus(ni, nj)))
        check("early_cancellation", value(cancellation_term(ni, nj)) == i)
        check("H_stationarity", value(cancellation_term(ni, successor(nj))) ==
              value(cancellation_term(ni, nj)))
        check("strict_comparison_complement", (value(monus(ni, nj)) != 0) ==
              (value(monus(nj, successor(ni))) == 0))
        check("stationary_reconstruction", value(add(monus(monus(nj, ni), ni),
                                                      monus(ni, nj))) == j)
        check("native_equality_error", (value(distance(ni, nj)) == 0) == (i == j))
        for bit in (0, 1):
            encoded = bit_pair(ni, number(bit))
            check("number_bit_retractions", value(half(encoded)) == i and
                  value(parity(encoded)) == bit)
        check("latch_parameter_preservation", value(half(latch(ni, nj))) == j)
        expected_bit = int(i <= j)
        check("latch_recurrence_example", value(latch_bit(ni, nj)) == expected_bit)
        check("scanner_parameter_preservation", value(half(scan(ni, nj))) == j)
        expected_scan = all(t <= max(j - t, 0) for t in range(i))
        check("scanner_recurrence_example", value(scan_bit(ni, nj)) == int(expected_scan))

    pair_bound = min(bound, 5)
    for i, j in product(range(pair_bound + 1), repeat=2):
        encoded = pair(number(i), number(j))
        check("general_pair_retractions", value(left(encoded)) == i and value(right(encoded)) == j)
    for k in range(bound + 1):
        check("triangular_boundary", value(rank(triangular(number(k)))) == k)
        for i in range(k + 1):
            check("triangular_interval", value(rank(add(triangular(number(k)), number(i)))) == k)
    for length in range(3):
        for parameters in product(range(2), repeat=length):
            parameter_terms = [number(parameter) for parameter in parameters]
            total = sum(parameters)
            for counter in range(4):
                translated = pr_translation(length, number(counter), parameter_terms)
                check("compiled_recursion_examples_arity_" + str(length),
                      value(translated) == total + counter * (total + 1))
    return {
        "scope": "Finite standard-natural-number evaluations of the actual descriptor ASTs. No universal axiom is tested or inferred, and this is not a proof of the mathematical theorems.",
        "evaluation_method": "Finite iteration of the declared AST bodies, with memoized prefixes; no closed-form overrides for arithmetic helpers.",
        "kernel_bound_inclusive": bound, "pair_bound_inclusive": pair_bound,
        "compiler_examples": "Arities 0,1,2; each parameter 0 or 1; counter 0..3. Initial value is parameter sum and each step adds that sum plus one.",
        "latch_example": "e(n,a)=1 exactly at n=a, and 0 otherwise, expressed by the expanded selector and equality-error term.",
        "scanner_example": "Rstar(x,y)=Z(M(y,x)); checks its recurrence and stored parameter, not the diagonal lemma hypotheses.",
        "checks_by_name": checks, "total_checks": sum(checks.values()),
        "memoized_iterator_prefixes": len(evaluator.cache), "all_passed": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=6,
                        help="Inclusive finite numerical bound (default: 6)")
    options = parser.parse_args()
    if not 1 <= options.bound <= 12:
        parser.error("--bound must lie between 1 and 12")
    language = build_language()
    metrics = schema_metrics(language)
    syntax = syntax_diagnostics(language)
    numerical = numeric_diagnostics(language, options.bound)
    directory = Path(__file__).resolve().parent
    (directory / "schema_metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    (directory / "syntax_diagnostics.json").write_text(json.dumps({
        "status": "passed", "syntax": syntax, "numerical": numerical,
        "not_proved_by_this_script": [
            "soundness or completeness of first-order reasoning",
            "validity of an axiom schema in arbitrary models",
            "the general induction and bi-interpretability theorems",
            "a shortestness theorem or a full primitive-recursive compiler theorem"]}, indent=2) + "\n")
    print(json.dumps({"status": "passed", "formula_totals": metrics["totals"],
                      "descriptor_count": len(language.descriptors),
                      "syntax_template_count": syntax["template_count"],
                      "numerical_checks": numerical["total_checks"],
                      "outputs": ["schema_metrics.json", "syntax_diagnostics.json"]}, indent=2))


if __name__ == "__main__":
    main()
