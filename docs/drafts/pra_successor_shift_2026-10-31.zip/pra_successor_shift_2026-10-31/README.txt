PRA FROM SUCCESSOR UNIQUENESS AND ONE SUBTRACTION IDENTITY
Research report prepared for Vladimir Reshetnikov, 31 October 2026

Read pra_successor_shift.pdf for the complete result and proof.
AXIOMS.txt gives a standalone exact specification.

PROVED RESULT
In the effective binary initialized-iterator language, a single arithmetic
successor-uniqueness schema with one numerical parameter, together with
one fixed predecessor-shift equation, is definitionally equivalent and
therefore bi-interpretable with ordinary first-order PRA in the same logic.
The result holds separately over classical and intuitionistic equality logic.

Equivalently, only successor and predecessor arithmetic uniqueness updates
are needed; the identity update in the current binary-language three-update
result is derivable. The improvement is the restricted-language theorem,
not the already known full-language successor-plus-Shift formula.

CONTENTS
  pra_successor_shift.tex, sections/ : complete LaTeX source
  pra_successor_shift.pdf            : compiled paper
  AXIOMS.txt                        : exact standalone specification
  SOURCES.json                      : immutable repository comparison audit
  formal/                           : two new Lean 4 proof kernels
  verification/                     : compiler logs, metrics, syntax diagnostics
  build.sh                          : rebuild the PDF with latexmk
  check_formal.sh                    : check Lean files; supports PRA_LEAN
  SHA256SUMS                        : hashes of final archive contents

REPRODUCE
  bash build.sh
  python3 verification/check_syntax.py
  bash check_formal.sh

Lean version used: 4.19.0. If Lean is not on PATH, set PRA_LEAN to its
absolute executable path before running check_formal.sh. No Mathlib is needed.

VALIDATION SCOPE
The complete bi-interpretability argument is the written proof. Lean checks
the new constructive bootstrap and cancellation kernels from explicit
computation facts and selected term-instance callbacks. All 17 reported
theorem dependency lists are empty. This does not constitute a formalization
of the complete first-order calculus or language translation. Finite numerical
checks are diagnostics, not universal proofs.

ATTRIBUTION
The six current ProveIt drafts were inspected at commit
514b6dfd2c1232848a259549c352b1935d53191c. The stored-latch, row-scanner,
equality-reflection, and coding completion is adapted from the autonomous
uniqueness draft with attribution in the paper. The new contribution is the
early cancellation argument and the resulting smaller update basis under
the same binary language and one-parameter restriction.

No absolute shortest axiomatization, historical priority, finite individual
axiom set, or elimination of Shift is claimed. No repository was modified.
