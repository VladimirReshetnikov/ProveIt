#!/usr/bin/env bash
# Recheck the constructive kernels. Tested with Lean 4.19.0 and its Std library.
# Usage: PRA_LEAN=/absolute/path/to/lean ./check_formal.sh
# Without PRA_LEAN, use the executable named lean on PATH.
set -euo pipefail

PRA_PACKAGE_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PRA_LEAN_EXEC="${PRA_LEAN:-lean}"

if ! command -v "$PRA_LEAN_EXEC" >/dev/null 2>&1; then
  printf '%s\n' 'Lean was not found. Set PRA_LEAN or add lean to PATH.' >&2
  exit 127
fi

mkdir -p "$PRA_PACKAGE_DIR/verification"
"$PRA_LEAN_EXEC" --version | tee "$PRA_PACKAGE_DIR/verification/lean-version.log"

for PRA_PROOF_NAME in DelayedSuccessorBootstrap TwoUpdateCore; do
  "$PRA_LEAN_EXEC" "$PRA_PACKAGE_DIR/formal/$PRA_PROOF_NAME.lean" 2>&1 |
    tee "$PRA_PACKAGE_DIR/verification/$PRA_PROOF_NAME.log"
done
