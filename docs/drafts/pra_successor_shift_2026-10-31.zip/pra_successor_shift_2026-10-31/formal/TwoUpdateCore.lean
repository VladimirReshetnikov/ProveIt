import Std

/-!
# A constructive two-update kernel for PRA

This file checks the new implication from successor/predecessor uniqueness
to native constancy, over an arbitrary carrier and without induction.
The written finite-syntax audit supplies the term-language interpretation.

`UniquenessInstance` denotes one callback for exactly its displayed `F`.
No theorem postulates uniqueness for all semantic functions.  Where a
family `forall a, UniquenessInstance ... (fun n => term(n,a))` occurs, it
is one syntactic schema instance with its one numerical parameter `a`.
No classical principle, decidable equality, or arithmetic induction is used.

The assumed addition identities and constructor facts are obtained by the
already documented successor-uniqueness bootstrap.  The theorem
`shift_from_predecessor` shows the only predecessor-uniqueness use.  The
rest of the argument needs only the resulting fixed Shift equation.
-/

namespace TwoUpdateCore

universe u

def UniquenessInstance {N : Type u} (zero : N) (succ : N → N)
    (iter : N → N → N) (update F : N → N) : Prop :=
  (∀ n, F (succ n) = update (F n)) →
    ∀ n, F n = iter n (F zero)

def Stationary {N : Type u} (succ : N → N) (F : N → N) : Prop :=
  ∀ n, F (succ n) = F n

section NoFixedPoint

variable {N : Type u} (zero one : N) (succ test parity : N → N)

/-- The parity proof needs only a positive bit range and its recurrence. -/
theorem successor_no_fixed_point
    (separate : zero ≠ one)
    (test_zero : test zero = one)
    (test_one : test one = zero)
    (parity_bits : ∀ n, parity n = zero ∨ parity n = one)
    (parity_step : ∀ n, parity (succ n) = test (parity n)) :
    ∀ n, succ n ≠ n := by
  intro n hn
  have hfixed : parity n = test (parity n) :=
    (congrArg parity hn).symm.trans (parity_step n)
  rcases parity_bits n with hb | hb
  · rw [hb, test_zero] at hfixed
    exact separate hfixed
  · rw [hb, test_one] at hfixed
    exact separate hfixed.symm

end NoFixedPoint

section BooleanConstancy

variable {N : Type u} (zero one : N) (succ : N → N)
variable (add : N → N → N)

/--
Exactly one successor callback, for the ramp `n ↦ add n (bit n)`.
The function `bit` represents a selected finite term (its passive
numerical parameter is suppressed), not an added function quantifier.
-/
theorem boolean_constancy
    (add_zero_left : ∀ b, add zero b = b)
    (add_succ_left : ∀ n b, add (succ n) b = succ (add n b))
    (add_zero_right : ∀ n, add n zero = n)
    (add_one_right : ∀ n, add n one = succ n)
    (no_fixed_point : ∀ n, succ n ≠ n)
    (bit : N → N)
    (bit_range : ∀ n, bit n = zero ∨ bit n = one)
    (ramp_instance : UniquenessInstance zero succ add succ
      (fun n => add n (bit n)))
    (stationary : Stationary succ bit) :
    ∀ n, bit n = bit zero := by
  have ramp_step : ∀ n,
      add (succ n) (bit (succ n)) = succ (add n (bit n)) := by
    intro n
    rw [stationary n, add_succ_left]
  have ramp := ramp_instance ramp_step
  intro n
  have heq : add n (bit n) = add n (bit zero) := by
    have hn := ramp n
    change add n (bit n) = add n (add zero (bit zero)) at hn
    rw [add_zero_left] at hn
    exact hn
  rcases bit_range n with hn | hn <;>
    rcases bit_range zero with hz | hz
  · exact hn.trans hz.symm
  · rw [hn, hz, add_zero_right, add_one_right] at heq
    exact False.elim (no_fixed_point n heq.symm)
  · rw [hn, hz, add_one_right, add_zero_right] at heq
    exact False.elim (no_fixed_point n heq)
  · exact hn.trans hz.symm

end BooleanConstancy

section Shift

variable {N : Type u} (zero : N) (succ pred : N → N)
variable (monus : N → N → N)

/-- One predecessor callback family, with displayed term `pred (monus n a)`. -/
theorem shift_from_predecessor
    (pred_succ : ∀ a, pred (succ a) = a)
    (monus_zero : ∀ a, monus zero a = a)
    (monus_step : ∀ n a, monus (succ n) a = pred (monus n a))
    (pred_instances : ∀ a, UniquenessInstance zero succ monus pred
      (fun n => pred (monus n a))) :
    ∀ n a, monus (succ n) (succ a) = monus n a := by
  have commute : ∀ n a, pred (monus n a) = monus n (pred a) := by
    intro n a
    have step : ∀ k,
        pred (monus (succ k) a) = pred (pred (monus k a)) := by
      intro k
      rw [monus_step]
    have h := pred_instances a step n
    change pred (monus n a) = monus n (pred (monus zero a)) at h
    rw [monus_zero] at h
    exact h
  intro n a
  rw [monus_step, commute, pred_succ]

end Shift

section Cancellation

variable {N : Type u} (zero one : N) (succ pred test : N → N)
variable (add monus : N → N → N)

/--
Cancellation from two explicit successor-instance families and Shift.
No general constancy, monus zero-at-zero-seed law, diagonal monus law,
zero-test induction, or parameter coding is among the hypotheses.
-/
theorem cancellation_identity
    (separate : zero ≠ one)
    (succ_nonzero : ∀ x, succ x ≠ zero)
    (coverage : ∀ x, x = zero ∨ x = succ (pred x))
    (add_zero_left : ∀ b, add zero b = b)
    (add_succ_left : ∀ n b, add (succ n) b = succ (add n b))
    (add_zero_right : ∀ n, add n zero = n)
    (add_succ_right : ∀ n b, add n (succ b) = succ (add n b))
    (add_one_right : ∀ n, add n one = succ n)
    (no_fixed_point : ∀ n, succ n ≠ n)
    (test_zero : test zero = one)
    (test_nonzero : ∀ x, x ≠ zero → test x = zero)
    (test_reflects_zero : ∀ x, test x = one → x = zero)
    (test_bits : ∀ x, test x = zero ∨ test x = one)
    (monus_zero : ∀ a, monus zero a = a)
    (monus_step : ∀ n a, monus (succ n) a = pred (monus n a))
    (shift : ∀ n a, monus (succ n) (succ a) = monus n a)
    (monitor_instances : ∀ x, UniquenessInstance zero succ add succ
      (fun k => add k (test (monus k (add x k)))))
    (cancel_instances : ∀ k, UniquenessInstance zero succ add succ
      (fun x => monus k (add x k))) :
    ∀ x k, monus k (add x k) = x := by
  let H : N → N → N := fun x k => monus k (add x k)
  have H_at_zero : ∀ x, H x zero = x := by
    intro x
    change monus zero (add x zero) = x
    rw [monus_zero, add_zero_right]
  have H_stationary : ∀ x k, H x (succ k) = H x k := by
    intro x k
    change monus (succ k) (add x (succ k)) = monus k (add x k)
    rw [add_succ_right, shift]
  have zero_status : ∀ x k, test (H x k) = test x := by
    intro x k
    have hb := boolean_constancy zero one succ add
      add_zero_left add_succ_left add_zero_right add_one_right no_fixed_point
      (fun j => test (H x j)) (fun j => test_bits (H x j))
      (monitor_instances x)
      (fun j => congrArg test (H_stationary x j)) k
    exact hb.trans (congrArg test (H_at_zero x))
  have H_zero : ∀ k, H zero k = zero := by
    intro k
    apply test_reflects_zero
    exact (zero_status zero k).trans test_zero
  have H_succ_nonzero : ∀ x k, H (succ x) k ≠ zero := by
    intro x k hz
    have ht : test (H (succ x) k) = zero :=
      (zero_status (succ x) k).trans (test_nonzero (succ x) (succ_nonzero x))
    rw [hz, test_zero] at ht
    exact separate ht.symm
  have H_pred : ∀ x k, pred (H (succ x) k) = H x k := by
    intro x k
    change pred (monus k (add (succ x) k)) = monus k (add x k)
    rw [add_succ_left]
    calc
      pred (monus k (succ (add x k))) =
          monus (succ k) (succ (add x k)) :=
            (monus_step k (succ (add x k))).symm
      _ = monus k (add x k) := shift k (add x k)
  have H_step : ∀ x k, H (succ x) k = succ (H x k) := by
    intro x k
    rcases coverage (H (succ x) k) with hz | hs
    · exact False.elim (H_succ_nonzero x k hz)
    · exact hs.trans (congrArg succ (H_pred x k))
  intro x k
  have hu := cancel_instances k (fun j => H_step j k) x
  change H x k = add x (H zero k) at hu
  rw [H_zero k, add_zero_right] at hu
  exact hu

/-- Applying the proven retraction gives native right cancellation. -/
theorem right_cancellation
    (cancel_identity : ∀ x k, monus k (add x k) = x)
    {x y k : N} (h : add x k = add y k) : x = y := by
  calc
    x = monus k (add x k) := (cancel_identity x k).symm
    _ = monus k (add y k) := congrArg (monus k) h
    _ = y := cancel_identity y k

end Cancellation

section NativeConstancy

variable {N : Type u} (zero : N) (succ : N → N)
variable (add monus : N → N → N)

/--
The final ramp uses one selected successor callback for the finite term F.
This is the identity-update uniqueness conclusion, now derived.
-/
theorem native_constancy
    (add_zero_left : ∀ b, add zero b = b)
    (add_succ_left : ∀ n b, add (succ n) b = succ (add n b))
    (add_comm : ∀ x y, add x y = add y x)
    (cancel_identity : ∀ x k, monus k (add x k) = x)
    (F : N → N)
    (ramp_instance : UniquenessInstance zero succ add succ
      (fun n => add n (F n)))
    (stationary : Stationary succ F) :
    ∀ n, F n = F zero := by
  have step : ∀ n, add (succ n) (F (succ n)) = succ (add n (F n)) := by
    intro n
    rw [stationary n, add_succ_left]
  have ramp := ramp_instance step
  intro n
  have heq : add n (F n) = add n (F zero) := by
    have h := ramp n
    change add n (F n) = add n (add zero (F zero)) at h
    rw [add_zero_left] at h
    exact h
  have hright : add (F n) n = add (F zero) n := by
    exact (add_comm (F n) n).trans (heq.trans (add_comm n (F zero)))
  exact right_cancellation add monus cancel_identity hright

end NativeConstancy

#print axioms successor_no_fixed_point
#print axioms boolean_constancy
#print axioms shift_from_predecessor
#print axioms cancellation_identity
#print axioms right_cancellation
#print axioms native_constancy

end TwoUpdateCore
