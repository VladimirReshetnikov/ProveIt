#!/usr/bin/env python3
"""Recheck the supplied evidence and optionally rebuild the PDF."""
from pathlib import Path
import argparse
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pdf', action='store_true', help='Also run the offline pdfLaTeX build.')
    args = parser.parse_args()
    commands = [
        ['verification/endpoint_certificates.py', '--output', 'verification/endpoint_results.json'],
        ['verification/parameter_audit.py'],
        ['verification/benchmark_current.py'],
    ]
    if args.pdf:
        commands.append(['build.py'])
    records = []
    for command in commands:
        result = subprocess.run([sys.executable, *command], cwd=ROOT,
                                text=True, capture_output=True)
        records.append({'command': command, 'exit_code': result.returncode})
        if result.returncode:
            print(result.stdout[-6000:] + result.stderr[-6000:])
            raise SystemExit(result.returncode)
        print('PASS ' + command[0])
    endpoint = json.loads((ROOT / 'verification/endpoint_results.json').read_text())
    params = json.loads((ROOT / 'verification/parameter_audit.json').read_text())
    result = {
        'success': True, 'commands': records,
        'symbolic_equation_schemas': len(endpoint['checked_schemas']),
        'invalid_symbolic_certificates_rejected': len(endpoint['adversarial_checks']),
        'declarations_audited': params['total_declaration_count'],
        'iterator_declarations': params['iterator_declaration_count'],
        'full_metatheory_formalized': False,
    }
    (ROOT / 'results/reproduction.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
