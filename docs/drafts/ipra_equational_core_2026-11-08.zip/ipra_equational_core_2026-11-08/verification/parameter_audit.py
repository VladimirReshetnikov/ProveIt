#!/usr/bin/env python3
"""Audit finite staged declarations and a conditional pairing compiler.

This is supporting evidence, not a proof assistant for the report's theorems.
The pair projection identities in the symbolic compiler checks are imports.
No universal mathematical claim is inferred from the finite computations.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Var:
    name: str


@dataclass(frozen=True)
class App:
    name: str
    args: tuple[Term, ...] = ()


Term = Var | App


def call(name: str, *args: Term) -> App:
    return App(name, args)


def free_vars(term: Term) -> set[str]:
    if isinstance(term, Var):
        return {term.name}
    return set().union(*(free_vars(arg) for arg in term.args))


def dependencies(term: Term) -> set[str]:
    if isinstance(term, Var):
        return set()
    return {term.name}.union(*(dependencies(arg) for arg in term.args))


def substitute(term: Term, images: dict[str, Term]) -> Term:
    """Simultaneous first-order substitution; declaration indices are fixed."""
    if isinstance(term, Var):
        return images.get(term.name, term)
    return App(term.name, tuple(substitute(arg, images) for arg in term.args))


def display(term: Term) -> str:
    if isinstance(term, Var):
        return term.name
    if not term.args:
        return term.name
    return f"{term.name}({', '.join(display(arg) for arg in term.args)})"


@dataclass(frozen=True)
class Declaration:
    name: str
    kind: str
    formals: tuple[str, ...]
    body: Term | None


class Registry:
    def __init__(self) -> None:
        self.entries: dict[str, Declaration] = {}

    def validate_term(self, term: Term, allowed: set[str]) -> None:
        if isinstance(term, Var):
            if term.name not in allowed:
                raise ValueError(f"undeclared free variable: {term.name}")
            return
        if term.name not in self.entries:
            raise ValueError(f"unknown or later-stage symbol: {term.name}")
        entry = self.entries[term.name]
        if len(term.args) != len(entry.formals):
            raise ValueError(f"wrong arity for {term.name}")
        for arg in term.args:
            self.validate_term(arg, allowed)

    def add(self, name: str, kind: str, formals: tuple[str, ...],
            body: Term | None) -> None:
        if name in self.entries:
            raise ValueError(f"duplicate declaration: {name}")
        if len(set(formals)) != len(formals):
            raise ValueError("formal parameters must be distinct")
        if kind == "iterator":
            if formals != ("n", "a", "p") or body is None:
                raise ValueError("iterator declarations have three fixed arguments")
            self.validate_term(body, {"u", "p"})
        elif kind == "abbreviation":
            if body is None:
                raise ValueError("missing abbreviation body")
            self.validate_term(body, set(formals))
        elif kind != "initial":
            raise ValueError(f"unknown declaration kind: {kind}")
        self.entries[name] = Declaration(name, kind, formals, body)

    def initial(self, name: str, *formals: str) -> None:
        self.add(name, "initial", tuple(formals), None)

    def abbreviation(self, name: str, formals: str, body: Term) -> None:
        self.add(name, "abbreviation", tuple(formals.split()), body)

    def iterator(self, name: str, body: Term) -> None:
        self.add(name, "iterator", ("n", "a", "p"), body)

    def expand_abbreviations(self, term: Term) -> Term:
        if isinstance(term, Var):
            return term
        args = tuple(self.expand_abbreviations(arg) for arg in term.args)
        entry = self.entries[term.name]
        if entry.kind != "abbreviation":
            return App(term.name, args)
        assert entry.body is not None
        opened = substitute(entry.body, dict(zip(entry.formals, args)))
        return self.expand_abbreviations(opened)

    def validate_iterator_applications(self, term: Term) -> int:
        if isinstance(term, Var):
            return 0
        entry = self.entries[term.name]
        if entry.kind == "iterator" and len(term.args) != 3:
            raise AssertionError("iterator application lost its explicit parameter")
        return int(entry.kind == "iterator") + sum(
            self.validate_iterator_applications(arg) for arg in term.args)


def make_registry() -> Registry:
    reg = Registry()
    reg.initial("0")
    reg.initial("S", "x")
    u, p, n, a, b, x, y, t, m, i = map(Var, "u p n a b x y t m i".split())
    zero, one = call("0"), call("S", call("0"))

    reg.iterator("K_parameter", p)
    reg.abbreviation("C", "n a b", call("K_parameter", n, a, b))
    reg.iterator("K_zero", zero)
    reg.abbreviation("Z", "n", call("K_zero", n, one, zero))
    reg.abbreviation("B", "n", call("Z", call("Z", n)))
    reg.iterator("K_successor", call("S", u))
    reg.abbreviation("add", "a b", call("K_successor", b, a, zero))
    reg.iterator("K_parity", call("Z", u))
    reg.abbreviation("N", "n", call("K_parity", n, zero, zero))
    reg.abbreviation("j", "u", call("add", call("Z", u),
                                     call("add", call("N", u), call("N", u))))
    reg.iterator("K_cycle", call("j", u))
    reg.abbreviation("M", "n", call("K_cycle", n, zero, zero))
    reg.iterator("K_ramp", call("S", call("add", u, call("M", u))))
    reg.abbreviation("G", "n", call("K_ramp", n, zero, zero))
    reg.abbreviation("H", "u", call("C", call("N", u), call("G", u), u))
    reg.iterator("K_double", call("add", u, u))
    reg.abbreviation("E", "x", call("K_double", x, one, zero))
    reg.iterator("K_factor", call("H", u))
    reg.abbreviation("L", "x y", call("N", call("K_factor", y, call("E", x), zero)))
    reg.iterator("K_predecessor", call("C", call("L", call("S", call("S", u)), p),
                                       u, call("S", u)))
    reg.abbreviation("V", "t m", call("K_predecessor", t, zero, m))
    reg.abbreviation("P", "m", call("V", m, m))
    reg.iterator("K_monus", call("P", u))
    reg.abbreviation("d", "a b", call("K_monus", b, a, zero))
    reg.iterator("K_multiply", call("add", u, p))
    reg.abbreviation("mul", "a b", call("K_multiply", b, zero, a))
    reg.abbreviation("ell", "a b", call("Z", call("d", a, b)))
    reg.abbreviation("U", "u n", call("C", call("ell", call("mul", call("S", u),
                                     call("S", u)), n), u, call("S", u)))
    reg.iterator("K_root", call("U", u, p))
    reg.abbreviation("A", "i n", call("K_root", i, zero, n))
    reg.abbreviation("r", "n", call("A", n, n))
    reg.abbreviation("J", "a b", call("add", call("mul", call("add", a, b),
                                     call("add", a, b)), a))
    reg.abbreviation("pi0", "n", call("d", n, call("mul", call("r", n), call("r", n))))
    reg.abbreviation("pi1", "n", call("d", call("r", n), call("pi0", n)))
    return reg


def pair(left: Term, right: Term) -> Term:
    return call("J", left, right)


def left(term: Term) -> Term:
    return call("pi0", term)


def right(term: Term) -> Term:
    return call("pi1", term)


def encode_tuple(values: tuple[Term, ...]) -> Term:
    result: Term = call("0")
    for value in reversed(values):
        result = pair(value, result)
    return result


def tuple_coordinate(code: Term, index: int) -> Term:
    for _ in range(index):
        code = right(code)
    return left(code)


def reduce_pair_projections(term: Term) -> Term:
    """Rewrite using two explicitly imported pairing theorems only."""
    if isinstance(term, Var):
        return term
    args = tuple(reduce_pair_projections(arg) for arg in term.args)
    if term.name in {"pi0", "pi1"} and len(args) == 1:
        subject = args[0]
        if isinstance(subject, App) and subject.name == "J" and len(subject.args) == 2:
            return subject.args[0 if term.name == "pi0" else 1]
    return App(term.name, args)


def compiler_example(reg: Registry) -> dict:
    w, n, a, v, k, c0, c1, c2 = map(Var, "w n a v k c0 c1 c2".split())
    reg.abbreviation("sample_step", "v k c0 c1 c2",
                     call("add", v, call("add", c0, call("add", call("mul", c1, k), c2))))
    counter, value, environment = left(w), left(right(w)), right(right(w))
    arguments = (value, counter, *(tuple_coordinate(environment, index) for index in range(3)))
    next_value = call("sample_step", *arguments)
    update = pair(call("S", counter), pair(next_value, environment))
    reg.abbreviation("sample_update", "w", update)
    reg.iterator("K_sample", call("sample_update", Var("u")))
    tuple_code = encode_tuple((c0, c1, c2))
    initial = pair(call("0"), pair(a, tuple_code))
    reg.abbreviation("sample_orbit", "n a c0 c1 c2", call("K_sample", n, initial, call("0")))
    expanded_update = reg.expand_abbreviations(update)
    assert free_vars(expanded_update) == {"w"}
    assertions = [
        ("initial counter", left(initial), call("0")),
        ("initial value", left(right(initial)), a),
        ("initial environment", right(right(initial)), tuple_code),
        ("counter step", left(update), call("S", counter)),
        ("value step", left(right(update)), next_value),
        ("environment step", right(right(update)), environment),
    ]
    assertions.extend((f"tuple coordinate {index}", tuple_coordinate(tuple_code, index), value)
                      for index, value in enumerate((c0, c1, c2)))
    checks = []
    for name, expression, expected in assertions:
        reduced = reduce_pair_projections(expression)
        assert reduced == expected, name
        checks.append({"name": name, "expression": display(expression),
                       "reduced": display(reduced), "passed": True})
    return {
        "parameter_count": 3,
        "step": display(reg.entries["sample_step"].body),
        "state_update": display(update),
        "free_variables_before_expansion": sorted(free_vars(update)),
        "free_variables_after_expansion": sorted(free_vars(expanded_update)),
        "checks_are_conditional_on_imported_theorems": [
            "pi0(J(a,b)) = a", "pi1(J(a,b)) = b"],
        "symbolic_checks": checks,
        "induction_boundary": "Environment and counter identities at arbitrary n need the report's two separate equation-induction proofs.",
    }


def rejection_checks(reg: Registry) -> list[dict]:
    u, p, z = Var("u"), Var("p"), Var("z")
    bad = [
        ("unknown later declaration", call("not_yet_declared", u), {"u", "p"}),
        ("wrong iterator arity", call("K_zero", u, p), {"u", "p"}),
        ("ambient variable captured", call("add", u, z), {"u", "p"}),
    ]
    results = []
    for name, term, allowed in bad:
        try:
            reg.validate_term(term, allowed)
        except ValueError as exc:
            results.append({"name": name, "rejected": True, "reason": str(exc)})
        else:
            raise AssertionError(f"invalid declaration accepted: {name}")
    return results


def substitution_check(reg: Registry) -> dict:
    n, a, p = Var("n"), Var("a"), Var("p")
    original = call("K_predecessor", n, a, p)
    update_before = reg.entries["K_predecessor"].body
    changed = substitute(original, {
        "n": call("add", Var("x"), Var("y")),
        "a": pair(Var("v"), Var("w")),
        "p": pair(Var("c"), Var("d")),
    })
    reg.validate_term(changed, free_vars(changed))
    count = reg.validate_iterator_applications(reg.expand_abbreviations(changed))
    assert len(changed.args) == 3
    assert reg.entries["K_predecessor"].body == update_before
    assert free_vars(update_before) == {"u", "p"}
    return {"before": display(original), "after": display(changed),
            "actual_argument_count": len(changed.args),
            "declaration_body_unchanged": True,
            "declaration_free_variables": sorted(free_vars(update_before)),
            "expanded_iterator_applications_checked": count}


def finite_evaluations(reg: Registry) -> list[dict]:
    @lru_cache(maxsize=None)
    def evaluate_function(name: str, values: tuple[int, ...]) -> int:
        if name == "0":
            return 0
        if name == "S":
            return values[0] + 1
        entry = reg.entries[name]
        assert entry.body is not None
        if entry.kind == "iterator":
            count, state, parameter = values
            for _ in range(count):
                state = evaluate_term(entry.body, {"u": state, "p": parameter})
            return state
        return evaluate_term(entry.body, dict(zip(entry.formals, values)))

    def evaluate_term(term: Term, assignment: dict[str, int]) -> int:
        if isinstance(term, Var):
            return assignment[term.name]
        return evaluate_function(term.name, tuple(evaluate_term(arg, assignment) for arg in term.args))

    examples = [("C", (0, 2, 3), 2), ("C", (1, 2, 3), 3),
                ("add", (2, 3), 5), ("N", (5,), 1),
                ("L", (1, 2), 1), ("L", (2, 1), 0),
                ("P", (0,), 0), ("P", (1,), 0), ("P", (2,), 1)]
    output = []
    for name, values, expected in examples:
        actual = evaluate_function(name, values)
        assert actual == expected, (name, values, actual, expected)
        output.append({"function": name, "arguments": list(values),
                       "expected": expected, "actual": actual, "passed": True})
    return output


def main() -> None:
    reg = make_registry()
    bootstrap_count = len(reg.entries)
    compiler = compiler_example(reg)
    substitution = substitution_check(reg)
    rejected = rejection_checks(reg)
    finite = finite_evaluations(reg)
    declarations = []
    seen: set[str] = set()
    for stage, entry in enumerate(reg.entries.values()):
        used = dependencies(entry.body) if entry.body is not None else set()
        assert used <= seen
        row = {"stage": stage, "name": entry.name, "kind": entry.kind,
               "arity": len(entry.formals), "formal_parameters": list(entry.formals),
               "earlier_dependencies": sorted(used)}
        if entry.body is not None:
            expanded = reg.expand_abbreviations(entry.body)
            row.update({"body": display(entry.body),
                        "free_variables": sorted(free_vars(entry.body)),
                        "expanded_free_variables": sorted(free_vars(expanded)),
                        "expanded_iterator_applications_checked": reg.validate_iterator_applications(expanded)})
            if entry.kind == "iterator":
                assert free_vars(expanded) <= {"u", "p"}
                row["frozen_parameter_used"] = "p" in free_vars(expanded)
                row["ambient_capture_count"] = len(free_vars(expanded) - {"u", "p"})
        declarations.append(row)
        seen.add(entry.name)
    iterator_rows = [row for row in declarations if row["kind"] == "iterator"]
    result = {
        "status": "PASS",
        "scope": "Finite structural audit and conditional symbolic compiler checks; universal theorems are proved in the report, not by this script.",
        "bootstrap_declaration_count": bootstrap_count,
        "total_declaration_count": len(declarations),
        "iterator_declaration_count": len(iterator_rows),
        "maximum_primitive_function_arity": max(len(entry.formals) for entry in reg.entries.values()
                                                if entry.kind != "abbreviation"),
        "frozen_parameter_updates": [row["name"] for row in iterator_rows if row["frozen_parameter_used"]],
        "all_ambient_capture_counts_zero": all(row["ambient_capture_count"] == 0 for row in iterator_rows),
        "declarations": declarations,
        "substitution_check": substitution,
        "compiler_example": compiler,
        "negative_tests": rejected,
        "finite_semantic_examples": finite,
        "not_certified": [
            "The universal predecessor, reflection, or pairing theorems.",
            "The soundness or completeness of a native iPRA proof checker.",
            "The interpretation-composite proofs at nonstandard arguments.",
            "Any global minimum or improvement over checker-size benchmarks.",
        ],
    }
    destination = Path(__file__).resolve().with_name("parameter_audit.json")
    destination.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"],
                      "declarations": len(declarations),
                      "iterator_declarations": len(iterator_rows),
                      "primitive_max_arity": result["maximum_primitive_function_arity"],
                      "frozen_parameter_updates": result["frozen_parameter_updates"],
                      "symbolic_checks": len(compiler["symbolic_checks"]),
                      "negative_tests": len(rejected),
                      "finite_examples": len(finite),
                      "output": destination.name}, indent=2))


if __name__ == "__main__":
    main()
