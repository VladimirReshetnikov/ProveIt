CURRENT-CORPUS CHECKER MEASUREMENTS

Run with CPython 3.12.14 (the version used for the reported measurements):

    python3 benchmark_current.py

The program verifies every frozen source SHA-256 and the metric SHA-256,
then rewrites current_frontier.json and current_frontier.tex.  It does not
execute any proof checker.  All required measurement inputs are local.

The --refresh option is only for the original research workspace, where
../drafts_listing.json and ../sources/*.zip contain the authenticated current
GitHub directory metadata and its verified archive payloads.  The normal
reproduction path does not need those ZIPs or network access.

SOURCE ATTRIBUTION
The baseline programs and baseline_metric.py are copied unchanged from the
drafts maintained in VladimirReshetnikov/ProveIt, docs/drafts, commit:

    06e097f723c659030816e0194e5eb7e8c607ba9b

They are inherited source material, not new checker implementations.
current_manifest.json records each original archive, archive member,
Git blob SHA-1, archive SHA-256, source SHA-256, and pinned repository URL.
The original reports and archives retain their detailed inherited credits.
benchmark_current.py is the new corpus-selection and reproducibility wrapper.

MEASUREMENT BOUNDARY
All 12 archive-root checker*.py files are included.  Three explicitly complete
standalone prototypes from the structural-audit archive are reported as a
supplemental set.  Including them leaves the same coordinate minima.

The Boolean-boundary code/local_calculus/checker.py is a proof-tree API
without a standalone JSON acceptance boundary.  It also contains producer
functions after the trusted checker.  Its full-file size is disclosed
separately and is not treated as a like-for-like kernel-size comparison.
Historical comparator copies and validation-only checker variants are excluded.

The unmodified inherited normalizer strips genuine docstrings, normalizes
with ast.unparse, and counts significant tokens, AST nodes, and UTF-8 bytes
of the complete program.  The primary comparison includes imports and the
public input/output and rejection boundary.

RESULT AND LIMIT
Observed current envelope: 317 tokens / 348 AST nodes / 885 bytes.
The structural initializer profile attains the first two minima; the compact
initializer profile attains the byte minimum.  These are finite-corpus source
measurements, not a mathematical lower-bound theorem or a correctness proof.
