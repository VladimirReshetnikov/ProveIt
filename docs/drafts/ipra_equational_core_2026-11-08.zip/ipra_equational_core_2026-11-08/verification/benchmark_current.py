"""Remeasure the pinned current iPRA checker corpus without executing checkers.

Default: verify the frozen source hashes and reproduce JSON/TeX measurements.
Initial ingestion (the research workspace only):
    python3 benchmark_current.py --refresh

The metric is the exact, unmodified source_measure.py from the pinned
kernels-and-initializer archive.  All source programs are copied byte for
byte.  Archive Git blob identities and SHA-256 identities are retained.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import platform
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
COMMIT = "06e097f723c659030816e0194e5eb7e8c607ba9b"
REPOSITORY = "VladimirReshetnikov/ProveIt"
COORDINATES = ("normalized_tokens", "ast_nodes", "normalized_bytes")
NORMALIZER_ARCHIVE = "ipra_kernels_and_initializer_obstruction_2026-11-08.zip"
NORMALIZER_MEMBER = "ipra_kernel_2026-11-08/comparison/source_measure.py"

LABELS = {
    ("ipra_boolean_core", "checker.py"): "Boolean core",
    ("ipra_boxed_witnesses", "checker.py"): "Boxed: primary",
    ("ipra_boxed_witnesses", "checker_compatible.py"): "Boxed: compatible",
    ("ipra_clausal_kernel", "checker.py"): "Clausal",
    ("ipra_context_blocks", "checker.py"): "Context blocks",
    ("ipra_context_pairs", "checker.py"): "Context pairs",
    ("ipra_context_pairs", "checker_exact_list.py"): "Context pairs: exact-list",
    ("ipra_fixed_contexts", "checker.py"): "Fixed contexts",
    ("ipra_kernels_and_initializer_obstruction", "checker.py"): "Initializer: compact",
    ("ipra_kernels_and_initializer_obstruction", "checker_structural.py"): "Initializer: structural",
    ("ipra_normalized_elimination", "checker.py"): "Normalized: primary",
    ("ipra_normalized_elimination", "checker_readable.py"): "Normalized: readable",
    ("ipra_structural_audit", "checker_prefix.py"): "Structural: prefix",
    ("ipra_structural_audit", "checker_atomic_transport.py"): "Structural: atomic transport",
    ("ipra_structural_audit", "checker_canonical.py"): "Structural: canonical",
    ("ipra_boolean_boundary", "checker.py"): "Boolean boundary: proof-tree API",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def classify(archive: str, member: str) -> str | None:
    parts = PurePosixPath(member).parts
    name = parts[-1] if parts else ""
    if not (name.startswith("checker") and name.endswith(".py")):
        return None
    if len(parts) <= 2:
        return "designated_root_standalone"
    if archive == "ipra_structural_audit_2026-11-08.zip" and "prototypes" in parts:
        return "supplemental_standalone"
    if archive == "ipra_boolean_boundary_2026-11-08.zip" and "local_calculus" in parts:
        return "supplemental_proof_tree_api"
    return None


def refresh() -> None:
    """Ingest only the twelve exact current archives; never rewrite originals."""
    listing = json.loads((WORK / "drafts_listing.json").read_text())
    (ROOT / "baselines").mkdir(exist_ok=True)
    archives, programs = [], []
    metric_metadata = None
    for entry in sorted(listing, key=lambda row: row["name"]):
        archive_path = WORK / "sources" / entry["name"]
        raw = archive_path.read_bytes()
        actual_blob = git_blob(raw)
        if actual_blob != entry["sha"]:
            raise ValueError(f"Archive Git blob mismatch: {entry['name']}")
        metadata = {
            "archive": entry["name"],
            "repository_path": entry["path"],
            "git_blob_sha1": actual_blob,
            "archive_sha256": digest(raw),
            "archive_bytes": len(raw),
            "pinned_url": f"https://github.com/{REPOSITORY}/blob/{COMMIT}/{entry['path']}",
        }
        archives.append(metadata)
        with zipfile.ZipFile(archive_path) as z:
            if entry["name"] == NORMALIZER_ARCHIVE:
                metric_data = z.read(NORMALIZER_MEMBER)
                (ROOT / "baseline_metric.py").write_bytes(metric_data)
                metric_metadata = {
                    "archive": entry["name"],
                    "archive_member": NORMALIZER_MEMBER,
                    "local_file": "baseline_metric.py",
                    "sha256": digest(metric_data),
                    "copied_unchanged": True,
                }
            for member in sorted(z.namelist()):
                role = classify(entry["name"], member)
                if role is None:
                    continue
                source = z.read(member)
                stem = entry["name"].removesuffix("_2026-11-08.zip")
                basename = PurePosixPath(member).name
                label = LABELS[(stem, basename)]
                relative = f"baselines/{stem}__{basename}"
                (ROOT / relative).write_bytes(source)
                programs.append({
                    **metadata,
                    "label": label,
                    "role": role,
                    "archive_member": member,
                    "frozen_file": relative,
                    "source_sha256": digest(source),
                })
    if metric_metadata is None:
        raise ValueError("The specified inherited normalizer is missing")
    manifest = {
        "repository": REPOSITORY,
        "commit": COMMIT,
        "selection_rule": "All archive-root checker*.py files; three explicitly complete structural prototypes and one proof-tree API reported separately. Historical and validation copies excluded.",
        "metric": metric_metadata,
        "archives": archives,
        "programs": programs,
    }
    (ROOT / "current_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def minimum(rows: list[dict]) -> dict:
    return {key: min(row[key] for row in rows) for key in COORDINATES}


def nondominated(rows: list[dict]) -> list[str]:
    return [row["label"] for row in rows if not any(
        all(other[key] <= row[key] for key in COORDINATES)
        and any(other[key] < row[key] for key in COORDINATES)
        for other in rows
    )]


def run() -> dict:
    manifest = json.loads((ROOT / "current_manifest.json").read_text())
    metric_path = ROOT / manifest["metric"]["local_file"]
    if digest(metric_path.read_bytes()) != manifest["metric"]["sha256"]:
        raise ValueError("The inherited metric source has changed")
    spec = importlib.util.spec_from_file_location("pinned_metric", metric_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load the pinned metric")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rows = []
    for entry in manifest["programs"]:
        path = ROOT / entry["frozen_file"]
        if digest(path.read_bytes()) != entry["source_sha256"]:
            raise ValueError(f"Frozen source changed: {entry['frozen_file']}")
        rows.append({**entry, **module.metrics(path)})
    main = [row for row in rows if row["role"] == "designated_root_standalone"]
    supplemental = [row for row in rows if row["role"] == "supplemental_standalone"]
    api = [row for row in rows if row["role"] == "supplemental_proof_tree_api"]
    envelope = minimum(main)
    result = {
        "repository": manifest["repository"],
        "commit": manifest["commit"],
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "metric": manifest["metric"],
        "archive_count": len(manifest["archives"]),
        "designated_program_count": len(main),
        "supplemental_standalone_count": len(supplemental),
        "supplemental_api_count": len(api),
        "coordinatewise_minimum": envelope,
        "minimum_attainers": {key: [row["label"] for row in main if row[key] == value]
                              for key, value in envelope.items()},
        "pareto_frontier": nondominated(main),
        "including_supplemental_standalone_minimum": minimum(main + supplemental),
        "selection_rule": manifest["selection_rule"],
        "api_note": "The local-calculus source is a proof-tree API with no standalone JSON boundary and also includes untrusted producer functions. Its whole-file measurement is disclosed separately, not treated as a like-for-like kernel score.",
        "proof_status_note": "These are static source measurements. No checker is executed, and no semantic correctness theorem follows from the measurements.",
        "archives": manifest["archives"],
        "programs": rows,
    }
    (ROOT / "current_frontier.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = [
        "% Generated by verification/benchmark_current.py; sources unchanged.",
        "\\begin{tabular}{@{}lrrr@{}}",
        "\\toprule",
        "Current complete program & Tokens & AST nodes & Bytes\\\\",
        "\\midrule",
    ]
    for row in main:
        lines.append(f"{row['label']} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']}\\\\")
    lines += [
        "\\midrule",
        f"Coordinatewise minima & {envelope['normalized_tokens']} & {envelope['ast_nodes']} & {envelope['normalized_bytes']}\\\\",
        "\\bottomrule", "\\end{tabular}", "",
    ]
    (ROOT / "current_frontier.tex").write_text("\n".join(lines))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refresh", action="store_true", help="ingest the current workspace's verified repository archives")
    args = parser.parse_args()
    if args.refresh:
        refresh()
    result = run()
    print(json.dumps({key: result[key] for key in (
        "commit", "python", "archive_count", "designated_program_count",
        "supplemental_standalone_count", "supplemental_api_count",
        "coordinatewise_minimum", "minimum_attainers", "pareto_frontier",
        "including_supplemental_standalone_minimum",
    )}, indent=2))
