#!/usr/bin/env python3
"""Symbolic equational certificates for the Boolean-selector bootstrap.

Run with Python 3.10+; only the standard library is used.  This is a small,
task-specific proof checker, not a Lean/Rocq formalization of the report.
It checks symbolic zero and S(k) cases, never a finite numerical grid.

Trusted mathematical interface:
  * first-order equality, congruence, and substitution of proved schemas;
  * contextual induction for a literal equation, with checked freshness;
  * the computational recurrences of the fixed scalar terms listed below.

The recurrences are imported from the definitions of C, addition, Z, B,
N, j, M and G.  They are not labelled independently certified theorems.
No Boolean range, numerical coverage, falsity, successor cancellation,
commutative-addition normalizer, or non-equational induction is imported.

F is a schematic opaque placeholder for a fixed unary scalar term.  The
certificate is uniform under replacing F by that term.  It does not claim
that an arbitrary expansion of a T0 model by a new function still satisfies
the expanded equation-induction schema.

In particular, the endpoint theorems are proved at B(n); using one at a
general b requires an explicit proof of B(b)=b.  For the ramp induction,
that proof is the separately checked theorem B(N(n))=N(n).
"""

from __future__ import annotations

import argparse
import json
from functools import lru_cache
from pathlib import Path


Term = tuple
Equation = tuple[Term, Term]
ARITY = {"0": 0, "S": 1, "+": 2, "C": 3, "Z": 1, "B": 1,
         "N": 1, "j": 1, "M": 1, "G": 1, "F": 1}


def V(name):
    return ("v", name)


def T(name, *args):
    return (name, *args)


ZERO = T("0")
ONE = T("S", ZERO)
HOLE = ("hole",)


def valid(t, *, allow_hole=False):
    if not isinstance(t, tuple) or not t:
        raise ValueError("A term must be a nonempty tuple")
    if t[0] == "v":
        if len(t) != 2 or not isinstance(t[1], str) or not t[1]:
            raise ValueError("Malformed variable")
        return
    if t == HOLE and allow_hole:
        return
    if t[0] not in ARITY or len(t) != ARITY[t[0]] + 1:
        raise ValueError("Unknown symbol or incorrect arity")
    for arg in t[1:]:
        valid(arg, allow_hole=allow_hole)


def variables(t):
    if t[0] == "v":
        return {t[1]}
    return set().union(*(variables(a) for a in t[1:])) if len(t) > 1 else set()


def subst(t, sigma):
    if t[0] == "v":
        return sigma.get(t[1], t)
    return (t[0], *(subst(a, sigma) for a in t[1:]))


def fill(t, replacement):
    if t == HOLE:
        return replacement
    if t[0] == "v":
        return t
    return (t[0], *(fill(a, replacement) for a in t[1:]))


@lru_cache(maxsize=None)
def nf(t):
    """Orient only imported computational equalities, not Boolean lemmas."""
    if t[0] == "v" or t == ZERO:
        return t
    op = t[0]
    args = tuple(nf(a) for a in t[1:])
    if op == "+":
        a, b = args
        if b == ZERO:                         # a + 0 = a
            return a
        if b[0] == "S":                      # a + S(b) = S(a+b)
            return nf(T("S", T("+", a, b[1])))
    elif op == "C":
        n, a, b = args
        if n == ZERO:                         # C(0,a,b) = a
            return a
        if n[0] == "S":                      # C(S(n),a,b) = b
            return b
    elif op == "Z":                          # Z(n) := C(n,1,0)
        return nf(T("C", args[0], ONE, ZERO))
    elif op == "B":                          # B(n) := Z(Z(n))
        return nf(T("Z", T("Z", args[0])))
    elif op == "N":
        n = args[0]
        if n == ZERO:                         # N(0) = 0
            return ZERO
        if n[0] == "S":                      # N(S(n)) = Z(N(n))
            return nf(T("Z", T("N", n[1])))
    elif op == "j":                          # j(u) := Z(u) + 2N(u)
        u = args[0]
        return nf(T("+", T("Z", u), T("+", T("N", u), T("N", u))))
    elif op == "M":
        n = args[0]
        if n == ZERO:                         # M(0) = 0
            return ZERO
        if n[0] == "S":                      # M(S(n)) = j(M(n))
            return nf(T("j", T("M", n[1])))
    elif op == "G":
        n = args[0]
        if n == ZERO:                         # G(0) = 0
            return ZERO
        if n[0] == "S":                      # G(S(n)) = S(G(n)+M(G(n)))
            g = T("G", n[1])
            return nf(T("S", T("+", g, T("M", g))))
    # S and opaque F have no rewrite rule.  Other stuck terms stay symbolic.
    return (op, *args)


class Kernel:
    """Check proof trees and store only checked assumption-free schemas."""

    def __init__(self):
        self.theorems = {}
        self.certificates = {}

    def check(self, proof, context=()):
        rule = proof["rule"]
        if rule == "defeq":
            a, b = proof["equation"]
            valid(a)
            valid(b)
            if nf(a) != nf(b):
                raise ValueError("Computational normal forms differ")
            return a, b
        if rule == "hyp":
            index = proof["index"]
            if not isinstance(index, int) or index < 0 or index >= len(context):
                raise ValueError("Hypothesis index outside the retained context")
            return context[index]
        if rule == "sym":
            a, b = self.check(proof["proof"], context)
            return b, a
        if rule == "trans":
            a, b = self.check(proof["first"], context)
            c, d = self.check(proof["second"], context)
            if b != c:
                raise ValueError("Transitivity middle terms do not match")
            return a, d
        if rule == "cong":
            template = proof["context"]
            valid(template, allow_hole=True)
            a, b = self.check(proof["proof"], context)
            return fill(template, a), fill(template, b)
        if rule == "instance":
            name = proof["name"]
            if name not in self.theorems:
                raise ValueError("Only previously checked schemas may be instantiated")
            sigma = proof["substitution"]
            for name, term in sigma.items():
                if not isinstance(name, str):
                    raise ValueError("Substitution domain must consist of variables")
                valid(term)
            a, b = self.theorems[proof["name"]]
            return subst(a, sigma), subst(b, sigma)
        if rule == "eq_ind":
            a, b = proof["template"]
            valid(a)
            valid(b)
            counter, eigen, target = proof["counter"], proof["eigen"], proof["target"]
            valid(target)
            if not isinstance(counter, str) or not isinstance(eigen, str):
                raise ValueError("Induction variable names must be strings")
            retained = set().union(*(variables(t) for e in context for t in e))
            params = (variables(a) | variables(b)) - {counter}
            if counter == eigen or counter in retained:
                raise ValueError("Induction counter conflicts with retained data")
            if eigen in retained | params | variables(target):
                raise ValueError("Induction eigenvariable is not fresh")
            base = subst(a, {counter: ZERO}), subst(b, {counter: ZERO})
            ih = subst(a, {counter: V(eigen)}), subst(b, {counter: V(eigen)})
            step_sub = {counter: T("S", V(eigen))}
            step = subst(a, step_sub), subst(b, step_sub)
            if self.check(proof["base"], context) != base:
                raise ValueError("Incorrect induction base equation")
            if self.check(proof["step"], (*context, ih)) != step:
                raise ValueError("Incorrect induction successor equation")
            sigma = {counter: target}
            return subst(a, sigma), subst(b, sigma)
        raise ValueError("Unknown inference rule")

    def register(self, name, certificate):
        if name in self.theorems:
            raise ValueError("Duplicate theorem name")
        equation = self.check(certificate)
        self.theorems[name] = equation
        self.certificates[name] = certificate
        return equation


def deq(a, b):
    return {"rule": "defeq", "equation": (a, b)}


def inst(name, **sigma):
    return {"rule": "instance", "name": name, "substitution": sigma}


def sym(proof):
    return {"rule": "sym", "proof": proof}


def cong(template, proof):
    return {"rule": "cong", "context": template, "proof": proof}


def chain(*proofs):
    result = proofs[0]
    for proof in proofs[1:]:
        result = {"rule": "trans", "first": result, "second": proof}
    return result


def endpoint_induction(left, right, counter="i", target=None):
    """Ordinary equation induction whose step does not use its IH."""
    eigen = "endpoint_k"
    target = V("preimage") if target is None else target
    return {
        "rule": "eq_ind", "template": (left, right),
        "counter": counter, "eigen": eigen, "target": target,
        "base": deq(subst(left, {counter: ZERO}), subst(right, {counter: ZERO})),
        "step": deq(subst(left, {counter: T("S", V(eigen))}),
                    subst(right, {counter: T("S", V(eigen))})),
    }


def boolean_schema(left, right):
    # The checked theorem is E(B(preimage)), not an unconditional E(b).
    return endpoint_induction(subst(left, {"b": T("B", V("i"))}),
                              subst(right, {"b": T("B", V("i"))}))


def use_boolean(name, templates, sigma, boolean_proof):
    """Derived equality proof: E(B(b)) plus B(b)=b entails E(b)."""
    actual_b = sigma["b"]
    other = {k: v for k, v in sigma.items() if k != "b"}
    theorem_instance = inst(name, preimage=actual_b, **other)
    left_context = subst(subst(templates[0], other), {"b": HOLE})
    right_context = subst(subst(templates[1], other), {"b": HOLE})
    return chain(sym(cong(left_context, boolean_proof)), theorem_instance,
                 cong(right_context, boolean_proof))


def proof_nodes(proof):
    return 1 + sum(proof_nodes(v) for v in proof.values()
                   if isinstance(v, dict) and "rule" in v)


def show(t):
    if t[0] == "v":
        return t[1]
    if t == ZERO:
        return "0"
    if t == ONE:
        return "1"
    if t[0] == "+":
        return "(" + show(t[1]) + " + " + show(t[2]) + ")"
    return t[0] + "(" + ", ".join(show(a) for a in t[1:]) + ")"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional JSON report path")
    options = parser.parse_args()
    kernel = Kernel()
    n, b, x, y = V("i"), V("b"), V("x"), V("y")

    # Z^3(n)=Z(n), proved by symbolic endpoint equation induction.
    kernel.register("Z_cubed", endpoint_induction(
        T("Z", T("Z", T("Z", n))), T("Z", n)))

    # B(N(n))=N(n): the successor case uses the already checked Z^3 law.
    k = V("parity_k")
    ns = T("N", T("S", k))
    triple = T("Z", T("Z", T("Z", T("N", k))))
    kernel.register("N_boolean", {
        "rule": "eq_ind", "template": (T("B", T("N", n)), T("N", n)),
        "counter": "i", "eigen": "parity_k", "target": V("preimage"),
        "base": deq(T("B", T("N", ZERO)), T("N", ZERO)),
        "step": chain(deq(T("B", ns), triple),
                      inst("Z_cubed", preimage=T("N", k)),
                      deq(T("Z", T("N", k)), ns)),
    })

    schemas = {
        "boolean_sum": (T("+", b, T("Z", b)), ONE),
        "boolean_shift": (T("+", T("+", x, b), ONE),
                          T("C", b, T("S", x), T("S", T("S", x)))),
        "boolean_discard": (T("C", b, T("+", x, b), y), T("C", b, x, y)),
        "boolean_cycle": (T("C", b, T("j", b), T("j", T("j", b))), T("Z", b)),
        "central_F": (T("F", T("C", b, x, y)),
                      T("C", b, T("F", x), T("F", y))),
        "central_M": (T("M", T("C", b, x, y)),
                      T("C", b, T("M", x), T("M", y))),
    }
    for name, equation in schemas.items():
        kernel.register(name, boolean_schema(*equation))

    # Branch-free ramp step under the single equation IH: M(G(k))=N(k).
    # All appearances of b below abbreviate the fixed term N(k).
    k = V("ramp_k")
    xn, bn = T("G", k), T("N", k)
    ih = {"rule": "hyp", "index": 0}
    boolean_n = inst("N_boolean", preimage=k)
    shift = use_boolean("boolean_shift", schemas["boolean_shift"],
                        {"b": bn, "x": xn}, boolean_n)
    central = use_boolean("central_M", schemas["central_M"],
                          {"b": bn, "x": T("S", xn), "y": T("S", T("S", xn))},
                          boolean_n)
    cycles_before_ih = T("C", bn, T("j", T("M", xn)),
                         T("j", T("j", T("M", xn))))
    ramp_step = chain(
        deq(T("M", T("G", T("S", k))),
            T("M", T("S", T("+", xn, T("M", xn))))),
        cong(T("M", T("S", T("+", xn, HOLE))), ih),
        cong(T("M", HOLE), chain(
            deq(T("S", T("+", xn, bn)), T("+", T("+", xn, bn), ONE)), shift)),
        central,
        deq(T("C", bn, T("M", T("S", xn)), T("M", T("S", T("S", xn)))),
            cycles_before_ih),
        cong(T("C", bn, T("j", HOLE), T("j", T("j", HOLE))), ih),
        use_boolean("boolean_cycle", schemas["boolean_cycle"], {"b": bn}, boolean_n),
        deq(T("Z", bn), T("N", T("S", k))),
    )
    kernel.register("ramp_invariant", {
        "rule": "eq_ind", "template": (T("M", T("G", n)), T("N", n)),
        "counter": "i", "eigen": "ramp_k", "target": V("n"),
        "base": deq(T("M", T("G", ZERO)), T("N", ZERO)),
        "step": ramp_step,
    })

    # These are proof-checker rejection tests, not tests of numerical samples.
    negative = {}
    broken_shift = boolean_schema(
        schemas["boolean_shift"][0], T("C", b, x, T("S", T("S", x))))
    bad_freshness = endpoint_induction(T("Z", T("Z", T("Z", n))), T("Z", n),
                                      target=V("endpoint_k"))
    candidates = {
        "altered_shift_missing_successor": broken_shift,
        "unproved_arbitrary_boolean_fixed_point": deq(T("B", b), b),
        "nonfresh_induction_eigenvariable": bad_freshness,
    }
    for name, certificate in candidates.items():
        try:
            kernel.check(certificate)
        except ValueError as exc:
            negative[name] = {"rejected": True, "reason": str(exc)}
        else:
            raise AssertionError("Unsound adversarial certificate accepted: " + name)

    report = {
        "scope": "Symbolic equality certificates with literal-equation induction",
        "finite_numerical_testing": False,
        "imported_computational_interface": [
            "C(0,a,b)=a; C(S(n),a,b)=b",
            "a+0=a; a+S(b)=S(a+b)",
            "Z(n)=C(n,1,0); B(n)=Z(Z(n))",
            "N(0)=0; N(S(n))=Z(N(n))",
            "j(u)=Z(u)+(N(u)+N(u))",
            "M(0)=0; M(S(n))=j(M(n))",
            "G(0)=0; G(S(n))=S(G(n)+M(G(n)))",
        ],
        "opaque_symbol": "F is a schematic opaque placeholder for a fixed unary scalar term",
        "checked_schemas": {
            name: {"statement": show(eq[0]) + " = " + show(eq[1]),
                   "equation": eq, "certificate_nodes": proof_nodes(kernel.certificates[name])}
            for name, eq in kernel.theorems.items()
        },
        "adversarial_checks": negative,
        "limitations": [
            "The imported recurrences are justified by the report's fixed scalar definitions.",
            "This does not formalize the staged scalar language or the full bi-interpretation.",
            "This does not certify the general Boolean patching metatheorem or the pairing proof.",
            "Python and this small checker form the trusted implementation base.",
        ],
        "success": True,
    }
    encoded = json.dumps(report, indent=2)
    if options.output:
        options.output.parent.mkdir(parents=True, exist_ok=True)
        options.output.write_text(encoded + "\n", encoding="utf-8")
    print(encoded)


if __name__ == "__main__":
    main()
