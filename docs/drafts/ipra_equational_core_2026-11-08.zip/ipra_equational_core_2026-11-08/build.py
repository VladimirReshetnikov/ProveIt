#!/usr/bin/env python3
"""Build the report using installed pdfLaTeX; no network or shell escape.

The optional Debian TeX setup follows the local-format workaround already
used in the pinned boxed-witnesses draft; no TeX binaries are distributed.
"""
from pathlib import Path
import json
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    if shutil.which('pdflatex') is None:
        raise SystemExit('Install pdfLaTeX and the packages named in report.tex.')
    (ROOT / 'results').mkdir(exist_ok=True)
    environment = os.environ.copy()
    with tempfile.TemporaryDirectory(prefix='ipra-equational-tex-') as temporary:
        temp = Path(temporary)

        def found(filename):
            return subprocess.run(['kpsewhich', filename], env=environment,
                                  capture_output=True).returncode == 0

        distribution = Path('/usr/share/texlive/texmf-dist')
        if not found('article.cls') and distribution.is_dir():
            environment['TEXMF'] = '{/usr/share/texlive/texmf-dist,/usr/share/texmf,/etc/texmf}'
        if not found('pdflatex.fmt'):
            setup = subprocess.run(
                ['pdftex', '-ini', '-etex', '-interaction=nonstopmode',
                 '-jobname=pdflatex', '-progname=pdflatex', 'pdflatex.ini'],
                cwd=temp, env=environment, text=True, capture_output=True)
            if setup.returncode:
                raise SystemExit(setup.stdout[-8000:] + setup.stderr)
            environment['TEXFORMATS'] = str(temp) + os.pathsep + environment.get('TEXFORMATS', '')
        if not found('pdftex.map') and distribution.is_dir():
            maps = sorted((distribution / 'fonts/map/dvips/amsfonts').glob('*.map'))
            lm = Path('/usr/share/texmf/fonts/map/dvips/lm/lm.map')
            if lm.is_file():
                maps.append(lm)
            (temp / 'pdftex.map').write_bytes(b'\n'.join(p.read_bytes() for p in maps))
            environment['TEXFONTMAPS'] = str(temp) + os.pathsep + environment.get('TEXFONTMAPS', '')
        for pass_number in range(1, 4):
            result = subprocess.run(
                ['pdflatex', '-no-shell-escape', '-interaction=nonstopmode',
                 '-halt-on-error', '-file-line-error', '-output-directory=' + str(temp),
                 'report.tex'], cwd=ROOT, env=environment, text=True,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            if result.returncode:
                (ROOT / 'results' / 'build_failure.txt').write_text(result.stdout)
                raise SystemExit(result.stdout[-10000:])
        log = (temp / 'report.log').read_text(errors='replace')
        unresolved = ('undefined references' in log or 'Citation `' in log or 'Reference `' in log)
        if unresolved:
            raise SystemExit('Unresolved reference in LaTeX build:\n' + log[-6000:])
        warnings = [line for line in log.splitlines() if 'Overfull' in line or 'Warning' in line]
        shutil.copyfile(temp / 'report.pdf', ROOT / 'report.pdf')
        (ROOT / 'results' / 'latex_warnings.txt').write_text('\n'.join(warnings) + '\n')
        (ROOT / 'results' / 'build.json').write_text(json.dumps({
            'success': True, 'passes': 3, 'unresolved_references': False,
            'warnings': warnings, 'pdf_bytes': (ROOT / 'report.pdf').stat().st_size,
            'network_required': False, 'shell_escape': False
        }, indent=2) + '\n')
        print('Built report.pdf; ' + str(len(warnings)) + ' LaTeX warnings.')


if __name__ == '__main__':
    main()
