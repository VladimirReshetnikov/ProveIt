THE EQUATIONAL CORE OF iPRA
Prepared for Vladimir Reshetnikov, 8 November 2026 (Pacific time).

READ FIRST
report.pdf is the complete 27-page research report. report.tex and sections/
are its complete LaTeX sources. The PDF is compiled from those sources.

RESULT
Scalar iteration and literal-equation induction already prove predecessor,
internal pairing, and the defining equations of every fixed primitive-
recursive function. The proof eliminates Boolean range, numerical branching,
genuine falsity, and non-equational induction from that arithmetic bootstrap.
The predecessor and pairing terms are inherited; their stronger equational
proofs and the context-projection theorem are the new contribution.

Every update needed for the bootstrap has at most one frozen parameter.
A staged theory with ternary iterator symbols K_h(n,a,p), closed binary
update declarations h(u,p), equation induction, Boolean range, and the
falsity bridge is proved whole-domain bi-interpretable with full first-order
iPRA. Both composite isomorphisms are internally the identity. After the
bootstrap, arbitrary later recursions can use closed unary updates by
packing the counter, value, and parameter tuple into the initial state.

The report also proves intuitionistic existential-universal quantifier
fusion for the inherited paired binder, and an exact classical standard-
model depth hierarchy: depth k defines Sigma^0_(2k) for k >= 1.

LIMITATION
The requested strict improvement in total proof-checker complexity is NOT
established. The pinned current envelope is 317 normalized Python tokens,
348 AST nodes, and 885 normalized bytes, attained by different profiles.
No new complete accepting program is claimed to beat it. The mathematical
results do not identify the bare equational theory with full iPRA and do not
delete Boolean range or the falsity bridge from the full theory.

SOURCE BOUNDARY
Repository: VladimirReshetnikov/ProveIt
Commit: 06e097f723c659030816e0194e5eb7e8c607ba9b
Directory: docs/drafts
All twelve current archive payloads were verified against their Git blob
hashes. Detailed provenance, archive hashes, and frozen program hashes are
in verification/current_manifest.json. The twelve-archive audit is in
results/corpus_audit.txt. The report distinguishes inherited and new results.

REPRODUCTION
Use Python 3.12 for exact source-metric comparison; all verification scripts
use the standard library. A normal TeX installation with pdfLaTeX and the
packages listed in report.tex is needed only to rebuild the PDF.

    python3 reproduce.py
    python3 reproduce.py --pdf

Individual commands:

    python3 verification/endpoint_certificates.py --output verification/endpoint_results.json
    python3 verification/parameter_audit.py
    python3 verification/benchmark_current.py
    python3 build.py

The default reproduction path is offline. The benchmark's optional --refresh
mode belongs to the original research workspace and is not needed here.
The build script can initialize missing local format/font-map files using
already-installed TeX sources; it downloads nothing and disables shell escape.

VERIFICATION SCOPE
The endpoint checker verifies nine symbolic equation schemas including the
complete branch-free ramp induction and rejects three invalid certificates.
Its imported scalar computational recurrences are explicitly listed.
The parameter auditor checks 40 declarations, including 13 iterator
declarations, maximum primitive arity three, no ambient update captures,
a three-parameter closed state-compiler example, nine conditional symbolic
projection checks, three negative cases, and nine small semantic examples.
Its pairing projection imports are explicit.

These artifacts do not formalize the full patching metatheorem, full pairing,
logical reconstruction, or bi-interpretation in Lean or Rocq. The complete
universal mathematical arguments are in the report. The benchmark measures
unchanged inherited source; it does not prove those kernels correct.

FILES
report.tex, sections/      Complete mathematical source
report.pdf                Compiled report
build.py                  Offline PDF build
reproduce.py              Evidence reproduction, optional PDF rebuild
verification/             Symbolic checks, declaration audit, frozen benchmarks
results/                  Source inventory, comparison audit, build/QA records
attribution/              Preserved original notices for inherited material
ATTRIBUTION.txt            Source credits and scope of adaptations
SHA256SUMS.txt             Hashes of the final package files

The final section contains Further research questions, including the unresolved
closed-update and anchored-iteration reductions and complete formal verification.
