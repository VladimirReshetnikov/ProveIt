"""Independent named-variable interpreter and extraction for fixed-variable Q proofs.

The compact candidate uses de Bruijn coordinates and one scope traversal. This
interpreter uses sorted dataclasses, fresh names, ordinary named substitution,
alpha-normal equality, and an explicit stack cursor. It imports only the frozen
predecessor's independently written syntax model; the candidate imports neither.
"""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import reference as old


class NamedSyntax(old.Oracle):
    def term(self, data, local=()):
        if type(data) is int and data < 0:
            return old.Var(('rigid', data))
        return super().term(data, local)


def coordinates(expression, local=()):
    if isinstance(expression, old.Var) and expression.name[0] == 'rigid':
        return expression.name[1]
    if isinstance(expression, old.Succ):
        return ['s', coordinates(expression.value, local)]
    if isinstance(expression, old.Rec):
        inner = (expression.accumulator, expression.predecessor) + local
        return ['r', coordinates(expression.index, local),
                coordinates(expression.initial, local), coordinates(expression.step, inner)]
    if isinstance(expression, old.Eq):
        return ['=', coordinates(expression.left, local), coordinates(expression.right, local)]
    if isinstance(expression, (old.Q, old.Ex)):
        tag = 'q' if isinstance(expression, old.Q) else 'ex'
        return [tag, coordinates(expression.body, (expression.variable,) + local)]
    return old.coordinates(expression, local)


def substitution(data, environment=(1,), depth=0, formula=True):
    """Independent prefix action through names, including rigid parameters."""
    syntax = NamedSyntax()
    local = tuple(('local', i) for i in range(depth))
    expression = (syntax.formula if formula else syntax.term)(data, local)
    replacements = [syntax.term(term) for term in environment[:-1]]
    tail = environment[-1]
    if type(tail) is not int:
        raise old.Invalid('A tail shift must be an integer')
    mapping = {}
    for name in old.free_parameters(expression):
        index = name[1]
        mapping[name] = (replacements[index] if index < len(replacements)
                         else old.Var(('free', index + tail)))
    return coordinates(old.replace(expression, mapping), local)


def occurs(expression, name):
    if isinstance(expression, old.Var):
        return expression.name == name
    if isinstance(expression, old.Zero):
        return False
    if isinstance(expression, old.Succ):
        return occurs(expression.value, name)
    if isinstance(expression, old.Rec):
        return (occurs(expression.index, name) or occurs(expression.initial, name)
                or name not in (expression.accumulator, expression.predecessor)
                and occurs(expression.step, name))
    if isinstance(expression, old.Eq):
        return occurs(expression.left, name) or occurs(expression.right, name)
    if isinstance(expression, (old.Q, old.Ex)):
        return expression.variable != name and occurs(expression.body, name)
    raise old.Invalid('Unknown sorted expression')


class StackOracle(NamedSyntax):
    def __init__(self, stack, demand=False):
        super().__init__()
        if type(stack) is not list:
            raise old.Invalid('Certificate must be a list of instructions')
        self.stack = stack
        self.cursor = len(stack)
        self.events = Counter()
        self.discarded_major_attempts = 0
        self.demand = demand
        self.erased_witnesses = 0
        self.erased_malformed_witnesses = 0

    def instruction(self):
        if self.cursor == 0:
            raise old.Invalid('Missing premise instruction')
        self.cursor -= 1
        return self.stack[self.cursor]

    def derive_stack(self, goal, context=(), local=()):
        instruction = self.instruction()
        # Intro and computation share the empty instruction; goal syntax decides.
        if isinstance(goal, old.Q) and instruction == []:
            self.events['equation_QI' if isinstance(goal.body, old.Eq) else 'compound_QI'] += 1
            eigen = self.fresh('eigen')
            assumptions = [*context, old.instantiate(goal, old.Zero())]
            if isinstance(goal.body, old.Eq):
                assumptions.append(old.instantiate(goal, old.Var(eigen)))
            step = old.instantiate(goal, old.Succ(old.Var(eigen)))
            success, child = self.derive_stack(step, assumptions, (eigen,) + local)
            return success, [child]

        if isinstance(goal, old.Ex) and type(instruction) is list and len(instruction) == 1:
            self.events['exists_I'] += 1
            witness = self.term(instruction[0], local)
            eigen = self.fresh('eigen')
            assumptions = [*context, old.Eq(old.Var(eigen), witness)]
            body = old.instantiate(goal, old.Var(eigen))
            success, child = self.derive_stack(body, assumptions, (eigen,) + local)
            return success, [deepcopy(instruction[0]), child]

        # A failed major may fall through to a hypothesis, but exceptions may not.
        if (type(instruction) is list and len(instruction) == 2
                and type(instruction[0]) is list and instruction[0]):
            raw_major, annotation = instruction
            major = self.formula(raw_major, local)
            established, major_proof = self.derive_stack(major, context, local)
            if established:
                if isinstance(major, old.Ex):
                    self.events['exists_E'] += 1
                    eigen = self.fresh('eigen')
                    assumptions = [*context, old.instantiate(major, old.Var(eigen))]
                    success, child = self.derive_stack(goal, assumptions, (eigen,) + local)
                    return success, [deepcopy(raw_major), major_proof, child]
                if isinstance(major, old.Q):
                    self.events['Q_E'] += 1
                    # The second header field is inert for Q.  Fixed QE
                    # always selects the current coordinate, even under local
                    # eigenvariables; an extracted old tree uses witness 1.
                    witness, annotation = self.term(1, local), 1
                    premise = old.instantiate(major, old.Zero())
                    conclusion = old.instantiate(major, witness)
                elif isinstance(major, old.Eq):
                    self.events['equality_E'] += 1
                    hole = self.fresh('template')
                    motive = self.formula(annotation, (hole,) + local)
                    premise = old.replace(motive, {hole: major.left})
                    conclusion = old.replace(motive, {hole: major.right})
                else:
                    raise old.Invalid('Unknown eliminable formula')
                if not old.same(goal, conclusion):
                    return False, None
                success, child = self.derive_stack(premise, context, local)
                return success, [deepcopy(raw_major), major_proof, deepcopy(annotation), child]
            self.discarded_major_attempts += 1

        if isinstance(goal, old.Eq) and isinstance(goal.left, old.Rec) and instruction == []:
            term = goal.left
            if isinstance(term.index, old.Zero):
                self.events['R0'] += 1
                result = term.initial
            elif isinstance(term.index, old.Succ):
                self.events['RS'] += 1
                predecessor = term.index.value
                previous = old.Rec(predecessor, term.initial, term.accumulator,
                                   term.predecessor, term.step)
                result = old.replace(term.step, {term.accumulator: previous,
                                                  term.predecessor: predecessor})
            else:
                raise old.Invalid('Computation needs zero or successor index')
            return old.same(goal.right, result), 'r'

        self.events['hypothesis'] += 1
        return any(old.same(goal, assumption) for assumption in context), None


def analyze(goal, stack, context=(), demand=False):
    oracle = None
    try:
        oracle = StackOracle(stack, demand)
        parsed_goal = oracle.formula(goal)
        parsed_context = [oracle.formula(item) for item in context]
        accepted, tree = oracle.derive_stack(parsed_goal, parsed_context)
        return {'accepted': accepted, 'tree': tree if accepted else None,
                'remaining': oracle.cursor, 'consumed': len(stack) - oracle.cursor,
                'events': dict(oracle.events),
                'discarded_major_attempts': oracle.discarded_major_attempts,
                'erased_witnesses': oracle.erased_witnesses,
                'erased_malformed_witnesses': oracle.erased_malformed_witnesses,
                'error': None}
    except Exception as error:
        return {'accepted': False, 'tree': None,
                'remaining': oracle.cursor if oracle is not None else None,
                'consumed': len(stack) - oracle.cursor if oracle is not None else None,
                'events': dict(oracle.events) if oracle is not None else {},
                'discarded_major_attempts': oracle.discarded_major_attempts if oracle else 0,
                'erased_witnesses': oracle.erased_witnesses if oracle else 0,
                'erased_malformed_witnesses': oracle.erased_malformed_witnesses if oracle else 0,
                'error': type(error).__name__ + ': ' + str(error)}


def accept_document(document, demand=False):
    return (type(document) is list and len(document) == 2
            and analyze(*document, demand=demand)['accepted'])
