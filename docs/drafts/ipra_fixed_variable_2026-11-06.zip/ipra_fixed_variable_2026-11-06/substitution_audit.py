"""Differential and independent named-variable audit of offset-first substitution.

No checked kernel is modified. The reference's named-variable substitution is
independent of both compact implementations. Run this script from any directory.
"""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parent


def load(name, relative):
    path = ROOT / relative
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


candidate_path = 'checker.py'
new = load('audit_candidate', candidate_path)
old = load('audit_tail_last', 'comparison/sources/draft_2/checker_demand.py')
reference = load('audit_named', 'validation_reference/named_substitution.py')
RNG = random.Random(2026110601)


def rename(expression, source, target):
    if type(expression) is not list:
        return expression
    return [target if field == source else rename(field, source, target)
            for field in expression]


def number(depth=0, budget=3):
    if budget <= 0 or RNG.randrange(4) == 0:
        return RNG.choice([0, -1, -2, -71, *range(1, depth + 9)])
    if RNG.randrange(3) == 0:
        return ['s', number(depth, budget - 1)]
    return ['r', number(depth, budget - 1), number(depth, budget - 1),
            number(depth + 2, budget - 1)]


def formula(depth=0, budget=3):
    if budget <= 0 or RNG.randrange(3) == 0:
        return ['=', number(depth, 2), number(depth, 2)]
    return [RNG.choice(['u', 'ex']), formula(depth + 1, budget - 1)]


def compare(expression, environment, depth, formula_sort):
    tail_environment = [*environment[1:], environment[0]]
    first = new.subst(deepcopy(expression), deepcopy(environment), depth, formula_sort)
    second = old.subst(deepcopy(expression), deepcopy(tail_environment), depth, formula_sort)
    named = reference.substitution(rename(expression, 'u', 'q'),
                                   rename(tail_environment, 'u', 'q'),
                                   depth, formula_sort)
    third = rename(named, 'q', 'u')
    if not (first == second == third):
        raise AssertionError({'input': expression, 'environment': environment,
                              'depth': depth, 'formula': formula_sort,
                              'new': first, 'old': second, 'named': third})


families = {name: 0 for name in ('raising', 'zero_retained', 'successor_retained',
                                'single_instantiation', 'double_instantiation',
                                'general_prefix')}
formulas = 0
terms = 0
for index in range(1000):
    depth = RNG.randrange(7)
    formula_sort = bool(index % 2)
    if formula_sort:
        # At least two logical binders, often with recursion under them.
        expression = ['u', ['ex', formula(depth + 2, 3)]]
        formulas += 1
    else:
        # Nested recursors test simultaneous previous-value/counter binding.
        expression = ['r', number(depth, 2), number(depth, 2),
                      ['r', number(depth + 2, 2), number(depth + 2, 2),
                       number(depth + 4, 2)]]
        terms += 1
    family = tuple(families)[index % len(families)]
    if family == 'raising':
        environment = [RNG.randrange(7)]
    elif family == 'zero_retained':
        environment = [0, 0]
    elif family == 'successor_retained':
        environment = [0, ['s', 1]]
    elif family == 'single_instantiation':
        environment = [-1, number(0, 3)]
    elif family == 'double_instantiation':
        n, initial, update = number(0, 2), number(0, 2), number(2, 2)
        environment = [-2, ['r', n, initial, update], n]
    else:
        count = RNG.randrange(5)
        # This bound ensures an untouched coordinate cannot become bound.
        environment = [RNG.randrange(-count, 5),
                       *(number(0, 2) for _ in range(count))]
    compare(expression, environment, depth, formula_sort)
    families[family] += 1

# Boundary cases target slot 0, rigid names, each protected/replaced slot,
# the first untouched slot, and deeper nested binding around them.
boundaries = 0
for depth in range(6):
    for replacements in range(4):
        environment = [-replacements, *([['s', 1]] * replacements)]
        for variable in [-999, -1, 0, *range(1, depth + replacements + 4)]:
            for expression, formula_sort in (
                (variable, False),
                (['r', variable, variable, ['r', variable, variable, variable]], False),
                (['u', ['ex', ['=', variable, variable]]], True),
            ):
                compare(expression, environment, depth, formula_sort)
                boundaries += 1

invalid = [None, True, False, 0.5, '', 's', 'ss', {}, {'s': 0}, [],
           ['s'], ['s', 0, 0], ['r'], ['r', 0, 0], ['r', 0, 0, 0, 0],
           ['unknown', 0], ['=', 0], ['=', 0, 0, 0], ['u'], ['u', ['=', 0, 0], 0],
           ['ex'], ['ex', ['=', 0, 0], 0], ['=', True, 0], ['s', False],
           ['u', ['=', 0, ['r', 0, 0, True]]]]
invalid_checks = 0
for expression in invalid:
    for formula_sort in (False, True):
        outcomes = []
        for implementation, item in ((new, expression), (old, expression)):
            try:
                implementation.subst(deepcopy(item), [1], 0, formula_sort)
                outcomes.append(True)
            except Exception:
                outcomes.append(False)
        try:
            reference.substitution(rename(expression, 'u', 'q'), [1], 0, formula_sort)
            outcomes.append(True)
        except Exception:
            outcomes.append(False)
        if len(set(outcomes)) != 1:
            raise AssertionError(('validation disagreement', expression, formula_sort, outcomes))
        if any(outcomes):
            raise AssertionError(('invalid accepted', expression, formula_sort))
        invalid_checks += 1

result = {
    'candidate': candidate_path,
    'sha256': hashlib.sha256((ROOT / candidate_path).read_bytes()).hexdigest(),
    'seed': 2026110601,
    'nested_random_cases': 1000,
    'formula_cases': formulas,
    'term_cases': terms,
    'environment_families': families,
    'deterministic_boundary_cases': boundaries,
    'invalid_sort_checks': invalid_checks,
    'all_agreed': True,
    'references': ['draft_2 checker_demand.py (tail-offset-last)',
                   'draft_0 validation/named_reference.py (named substitution)'],
    'limitation': 'Finite executable audit; not a formal proof of substitution correctness.',
}
output = ROOT / 'results/substitution.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
