"""Regenerate all comparison and implementation evidence without a network."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

if __name__ == '__main__':
    for filename in ('measure.py', 'substitution_audit.py', 'validation.py'):
        subprocess.run([sys.executable, str(ROOT / filename)], cwd=ROOT, check=True)
