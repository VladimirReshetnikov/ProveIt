"""Reproducible finite audit of the fixed-variable iPRA proof checker.

No acceptance kernel imports this file or validation_reference/.  Acceptance
is compared with a sorted named-variable interpreter; successful stacks are
extracted into proofs for the preceding unrestricted calculus.  This is
executable evidence, not a formalized general metatheorem.
"""
import argparse
from collections import Counter
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'validation_reference'))
import audit as legacy
import build_examples as builders
import named_stack as named
import proof_transforms as transforms
import compiler


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def predecessor(data):
    if type(data) is list:
        return [predecessor(item) for item in data]
    return 'q' if data == 'u' else data


def kernel_result(kernel, goal, stack, context=()):
    try:
        a, p, g = json.loads(json.dumps([goal, stack, list(context)]))
        accepted = kernel.check(a, p, g) is True
        return accepted, len(p)
    except Exception:
        return False, None


def named_source_accept(goal, tree, context=()):
    try:
        oracle = named.NamedSyntax()
        a = oracle.formula(predecessor(goal))
        g = [oracle.formula(predecessor(item)) for item in context]
        return oracle.derive(a, predecessor(tree), g)
    except Exception:
        return False


def integer_codes(data):
    if type(data) is int:
        yield data
    elif type(data) is list:
        for item in data:
            yield from integer_codes(item)


def source_corpus():
    rows = []
    for filename in ('generated_sequents.json', 'logic_sequents.json'):
        for row in json.loads((ROOT / 'validation_reference' / filename).read_text()):
            rows.append({**row, 'provenance': 'frozen predecessor examples'})
    generated = legacy.generated_rules()
    rows += [{**row, 'provenance': 'seeded predecessor rule generator'} for row in generated]
    q_rows = [row for row in generated if row['name'].startswith('generated_q_elimination_')]
    for row in q_rows:
        goal, proof = row['goal'], row['proof']
        # Bind a fresh variable around an already valid source derivation.
        # The compiler must lift its major/base proofs with all lexical
        # binders and equality-motive holes still protected.
        lifted_goal, lifted_proof = transforms.lift_proof((goal, proof))
        for tag, new_proof in (('q', [lifted_proof]), ('ex', [0, lifted_proof])):
            rows.append({'name': tag + '_wrapped_' + row['name'],
                         'goal': [tag, lifted_goal], 'proof': new_proof,
                         'context': row['context'], 'accepted': True,
                         'provenance': 'fresh-variable scope wrapper'})
        width = max([0, *integer_codes([goal, proof, row['context']])])
        images = [-i for i in range(1, width + 1)]
        rigid_goal, rigid_proof = transforms.substitute_proof((goal, proof), images, -width)
        rigid_context = [builders.substitute(item, images, -width) for item in row['context']]
        rows.append({'name': 'rigid_' + row['name'], 'goal': rigid_goal,
                     'proof': rigid_proof, 'context': rigid_context, 'accepted': True,
                     'provenance': 'rigid-parameter source renaming'})
    body = builders.eq(builders.rec(1, 0, builders.succ(1)), 1)
    step_term = builders.rec(builders.succ(1), 0, builders.succ(1))
    step = builders.transport(builders.hyp(body), builders.eq(builders.lift(step_term), builders.succ(1)),
                              builders.computation(step_term))
    induction = builders.q_intro(body, step)
    base = builders.computation(builders.rec(0, 0, builders.succ(1)))
    terms = [0, 1, 2, 17, builders.succ(0), builders.succ(1),
             builders.rec(2, 1, builders.succ(1)),
             builders.rec(1, 2, builders.rec(3, 1, builders.succ(4)))]
    for index, term in enumerate(terms):
        goal, proof = builders.q_elim(induction, term, base)
        rows.append({'name': 'macro_induction_' + str(index), 'goal': goal, 'proof': proof,
                     'context': [], 'accepted': True, 'provenance': 'new arbitrary-term induction instance'})
    return rows


def fixtures():
    rows = []

    def add(name, goal, stack, context=(), expected=False):
        rows.append({'name': name, 'goal': goal, 'stack': stack,
                     'context': list(context), 'expected': expected})

    E, S, R = legacy.E, legacy.S, legacy.R
    truth, false = E(0, 0), E(0, S(0))
    major = ['u', E(1, 0)]
    base = compiler.compile_tree(truth, compiler.native(legacy.reflexivity(0)))
    # All these values occupy an inert HEADER field, not a numerical
    # witness.  The result is always B(1), and can never be redirected.
    payloads = [0, 1, 2, -1, S(1), None, False, 0.0, {'junk': ['=', 0, 1]}, ['malformed']]
    for index, payload in enumerate(payloads):
        stream = base + [None, [major, payload]]
        add('fixed_Q_payload_invariance_%02d' % index, E(1, 0), stream, [major], True)
        add('fixed_Q_payload_cannot_select_2_%02d' % index, E(2, 0), stream, [major])
    add('fixed_Q_missing_base', E(1, 0), [None, None, [major, 0]], [major])
    add('fixed_Q_unproved_major', E(1, 0), base + [None, [major, 0]])
    add('fixed_Q_wrong_base', E(1, 0), [None, None, [major, 0]], [major, false])

    existential = ['ex', E(1, 0)]
    add('existential_eigenvariable_escape', E(1, 0),
        [None, None, [0], [existential, 0]])
    add('existential_preserves_outer_parameter', E(1, 0),
        [None, None, [0], [existential, 0]], [E(1, 0)], True)
    add('existential_witness_capture', ['ex', E(1, 1)], [None, [1]])
    add('existential_witness_parameter', ['ex', E(1, 2)], [None, [1]], expected=True)

    selected = {'forbidden_quantified_induction_hypothesis',
                'equation_rule_uses_retained_base', 'equation_induction',
                'equality_transport_beneath_binder', 'equality_transport_missing_minor',
                'equality_transport_wrong_orientation', 'recursion_wrong_accumulator_coordinate',
                'recursion_wrong_predecessor_coordinate', 'recursion_wrong_outer_parameter_shift',
                'recursion_outer_parameter_correct', 'invalid_boolean_in_computation'}
    for row in legacy.fixtures():
        if row['name'] not in selected:
            continue
        goal, tree, context = compiler.native([row['goal'], row['proof'], row['context']])
        add(row['name'], goal, compiler.compile_tree(goal, tree), context, row['accepted'])

    malformed_terms = [False, True, 0.0, None, '0', [], ['s'], ['s', 0, 0],
                       ['u', truth], ['r', 0, 0], ['r', 0, 0, truth], {'s': 0}]
    for index, term in enumerate(malformed_terms):
        add('malformed_existential_witness_%02d' % index,
            ['ex', E(1, 1)], [None, [term]])
    malformed_formulas = [False, 0, None, 'u', [], ['u'], ['u', truth, truth],
                          ['ex', 0], E(False, 0), E(0.0, 0), ['bot'], ['=', 0]]
    for index, formula in enumerate(malformed_formulas):
        add('malformed_goal_%02d' % index, formula, [None])
        add('malformed_motive_%02d' % index, truth,
            base + base + [[truth, formula]])
    add('false_theorem', false, [None])
    add('distinct_free_parameters', E(1, 2), [None], [E(1, 1)])
    add('distinct_rigid_parameters', E(-1, -2), [None], [E(-1, -1)])
    add('rigid_is_not_free_coordinate', E(-1, 1), [None], [E(-1, -1)])
    add('positive_parameter_not_zero', E(1, 0), [None])
    add('rigid_parameter_not_zero', E(-1, 0), [None])
    return rows


def run(checker, mutation_count=1200, substitution_count=360):
    kernel = load('fixed_variable_candidate', checker)
    old_compact = load('source_tree_checker', ROOT / 'validation_reference/source_checker.py')
    manifest = json.loads((ROOT / 'validation_reference/source_manifest.json').read_text())
    for record in manifest['files']:
        path = ROOT / 'validation_reference' / record['local_file']
        if hashlib.sha256(path.read_bytes()).hexdigest() != record['sha256']:
            raise ValueError('Changed frozen reference: ' + record['local_file'])
    failures, positives, corpus_results, fixture_results = [], [], [], []
    events = Counter()
    extracted = 0
    old_compact_count = 0

    def inspect(record, expected=None, exact=False):
        nonlocal extracted, old_compact_count
        goal, stack, context = record['goal'], record['stack'], record.get('context', [])
        actual, remaining = kernel_result(kernel, goal, stack, context)
        oracle = named.analyze(predecessor(goal), predecessor(stack), predecessor(context))
        if actual != oracle['accepted'] or expected is not None and actual != expected:
            failures.append({'kind': 'acceptance disagreement', 'name': record['name'],
                             'expected': expected, 'candidate': actual, 'oracle': oracle})
        if exact and actual and remaining != 0:
            failures.append({'kind': 'canonical stream not exhausted', 'name': record['name'],
                             'remaining': remaining})
        if actual and oracle['accepted']:
            events.update(oracle['events'])
            if not named_source_accept(goal, oracle['tree'], context):
                failures.append({'kind': 'extracted old named tree rejected', 'name': record['name']})
            if not any(i < 0 for i in integer_codes([goal, oracle['tree'], context])):
                old_compact_count += 1
                try:
                    old_ok = old_compact.check(predecessor(goal), deepcopy(oracle['tree']), predecessor(context))
                except Exception:
                    old_ok = False
                if not old_ok:
                    failures.append({'kind': 'extracted frozen compact tree rejected', 'name': record['name']})
            extracted += 1
        return actual, remaining

    for row in source_corpus():
        if not named_source_accept(row['goal'], row['proof'], row['context']):
            failures.append({'kind': 'invalid source sequent', 'name': row['name']})
            continue
        goal, tree, context = compiler.native([row['goal'], row['proof'], row['context']])
        stack = compiler.compile_tree(goal, tree)
        record = {'name': row['name'], 'goal': goal, 'stack': stack, 'context': context}
        actual, remaining = inspect(record, True, True)
        positives.append(record)
        corpus_results.append({'name': row['name'], 'provenance': row['provenance'],
                               'instructions': len(stack), 'accepted': actual, 'remaining': remaining})
        if row['name'].startswith('macro_induction_') or row['name'] in (
                'equation_induction', 'universal_reflexivity', 'implication_symmetry',
                'q_elimination_existential'):
            if not context:
                (ROOT / 'examples' / (row['name'] + '.json')).write_text(
                    json.dumps([goal, stack], indent=2) + '\n')

    fixed = fixtures()
    for row in fixed:
        actual, remaining = inspect(row, row['expected'])
        fixture_results.append({'name': row['name'], 'expected': row['expected'],
                                'accepted': actual, 'remaining': remaining})
        if row['expected']:
            positives.append(row)

    rng = random.Random(307106)
    simple = [False, True, 0.0, -1, -9, 0, 1, 2, 3, None, 'r', 'x', [],
              ['s'], ['=', 0, 0], ['u', ['=', 1, 1]], {'x': 0}]
    accepted_mutations = 0
    for index in range(mutation_count):
        source = rng.choice(positives)
        pair = [source['goal'], source['stack']]
        where = rng.choice(list(legacy.paths(pair)))
        replacement = deepcopy(rng.choice(simple)) if index % 3 else compiler.native(
            legacy.term(rng) if index % 2 else legacy.formula(rng))
        mutant = legacy.changed(pair, where, replacement)
        if type(mutant) is list and len(mutant) == 2:
            actual, _ = inspect({'name': 'bounded_mutation_%04d' % index,
                                 'goal': mutant[0], 'stack': mutant[1],
                                 'context': source['context']})
        else:
            try:
                actual = kernel.check(*deepcopy(mutant), []) is True
            except Exception:
                actual = False
            if actual:
                failures.append({'kind': 'malformed public document accepted', 'number': index})
        accepted_mutations += actual

    def add_rigid(data):
        if type(data) is int:
            return -rng.randrange(1, 6) if rng.randrange(4) == 0 else data
        if type(data) is list:
            return [add_rigid(item) for item in data]
        return data

    for index in range(substitution_count):
        formula = bool(index % 2)
        data = add_rigid(legacy.formula(rng) if formula else legacy.term(rng))
        images = [add_rigid(legacy.term(rng)) for _ in range(index % 4)]
        delta = -len(images) if index % 3 else index % 4
        depth = index % 5
        expected = compiler.native(named.substitution(data, [*images, delta], depth, formula))
        actual = kernel.subst(compiler.native(data), [delta, *compiler.native(images)], depth, formula)
        if actual != expected:
            failures.append({'kind': 'offset-first/named substitution mismatch', 'number': index,
                             'data': data, 'images': images, 'delta': delta, 'depth': depth})

    # Inject faults only into isolated in-memory copies, to confirm that the
    # selected tests actually detect their named scope/logic obligations.
    source = checker.read_text()
    faults = [
        ('unrestricted_formula_induction', '[subst(b, [0, 0]), b][:len(b) - 1]',
         '[subst(b, [0, 0]), b]', 'forbidden_quantified_induction_hypothesis'),
        ('missing_equation_induction_hypothesis', '[subst(b, [0, 0]), b][:len(b) - 1]',
         '[subst(b, [0, 0])]', 'equation_induction'),
        ('missing_retained_base', '[subst(b, [0, 0]), b][:len(b) - 1]',
         '[b] if len(b) == 3 else []', 'equation_rule_uses_retained_base'),
        ('missing_Q_elimination_base', 'return c == a and check(b, p, g)',
         'return c == a', 'fixed_Q_missing_base'),
        ('existential_goal_capture', 'b, h = subst(a), parts',
         'b, h = a, parts', 'existential_eigenvariable_escape'),
        ('wrong_fixed_coordinate', 't, parts = *parts, [0, 1]',
         't, parts = *parts, [0, 2]', 'fixed_Q_payload_invariance_00'),
        ('payload_reintroduced_as_Q_witness', 't, parts = *parts, [0, 1]',
         't, parts = *parts, [0, t]', 'fixed_Q_payload_cannot_select_2_02'),
    ]
    fault_results = []
    available = {row['name']: row for row in fixed}
    for name, before, after, case_name in faults:
        if source.count(before) != 1:
            failures.append({'kind': 'fault anchor mismatch', 'fault': name,
                             'occurrences': source.count(before)})
            continue
        namespace = {'__name__': 'isolated_fault'}
        exec(compile(source.replace(before, after, 1), '<isolated_fault>', 'exec'), namespace)
        mutant = type('Fault', (), {'check': staticmethod(namespace['check'])})
        case = available[case_name]
        actual, _ = kernel_result(mutant, case['goal'], case['stack'], case['context'])
        detected = actual != case['expected']
        fault_results.append({'fault': name, 'case': case_name,
                              'expected': case['expected'], 'mutant_accepts': actual,
                              'detected': detected})
        if not detected:
            failures.append({'kind': 'semantic fault not detected', 'fault': name})

    example = next(row for row in positives if row['name'] == 'macro_induction_6')
    public = [
        ('canonical_arbitrary_term_theorem', [example['goal'], example['stack']], True),
        ('false_theorem', [['=', 0, ['s', 0]], [None]], False),
        ('third_field_cannot_supply_context', [['=', 0, ['s', 0]], [None], [['=', 0, ['s', 0]]]], False),
        ('missing_proof', [example['goal']], False),
        ('null_document', None, False),
        ('inert_prefix', [example['goal'], [{'unread': True}, *example['stack']]], True),
    ]
    cli_results = []
    with tempfile.TemporaryDirectory() as temporary:
        directory = Path(temporary)
        for optimized in (False, True):
            command = [sys.executable, *(['-O'] if optimized else []), str(checker)]
            for name, document, expected in public:
                path = directory / (name + '.json')
                path.write_text(json.dumps(document))
                result = subprocess.run([*command, str(path)], capture_output=True, text=True, timeout=20)
                passed = result.returncode == (0 if expected else 1) and result.stdout.strip() == (
                    'ACCEPT' if expected else 'REJECT')
                cli_results.append({'name': name, 'optimized': optimized, 'passed': passed,
                                    'exit': result.returncode, 'stdout': result.stdout.strip()})
                if not passed:
                    failures.append({'kind': 'public CLI mismatch', 'name': name, 'optimized': optimized})
            malformed = directory / 'malformed.json'
            malformed.write_bytes(b'{not JSON')
            for name, arguments in [('missing_filename', []), ('malformed_json', [str(malformed)]),
                                    ('extra_filename', [str(malformed), str(malformed)])]:
                result = subprocess.run([*command, *arguments], capture_output=True, text=True, timeout=20)
                passed = result.returncode == 1 and result.stdout.strip() == 'REJECT'
                cli_results.append({'name': name, 'optimized': optimized, 'passed': passed,
                                    'exit': result.returncode, 'stdout': result.stdout.strip()})
                if not passed:
                    failures.append({'kind': 'public CLI mismatch', 'name': name, 'optimized': optimized})

    result = {
        'status': 'passed' if not failures else 'failed',
        'checker_sha256': hashlib.sha256(checker.read_bytes()).hexdigest(),
        'compiler_sha256': hashlib.sha256((ROOT / 'compiler.py').read_bytes()).hexdigest(),
        'named_interpreter_sha256': hashlib.sha256((ROOT / 'validation_reference/named_stack.py').read_bytes()).hexdigest(),
        'source_derivations': len(corpus_results),
        'source_groups': dict(Counter(row['provenance'] for row in corpus_results)),
        'canonical_streams_exhausted': all(row['accepted'] and row['remaining'] == 0 for row in corpus_results),
        'targeted_fixtures': len(fixture_results),
        'targeted_accepts': sum(row['expected'] for row in fixture_results),
        'targeted_rejects': sum(not row['expected'] for row in fixture_results),
        'mutations': mutation_count, 'accepted_mutations': accepted_mutations,
        'rejected_mutations': mutation_count - accepted_mutations,
        'named_substitution_comparisons': substitution_count,
        'successful_stack_extractions_checked_in_old_named_calculus': extracted,
        'extracted_trees_checked_by_frozen_compact_checker': old_compact_count,
        'public_cli_checks': len(cli_results),
        'semantic_faults_detected': sum(row['detected'] for row in fault_results),
        'rule_events_in_successful_extractions': dict(events),
        'corpus': corpus_results, 'fixtures': fixture_results,
        'fault_sensitivity': fault_results, 'cli': cli_results, 'failures': failures,
        'limits': 'Finite executable evidence. The general metatheory and bi-interpretability '
                  'are mathematical proofs; no Lean/Rocq formalization is claimed.'
    }
    (ROOT / 'results/validation.json').write_text(json.dumps(result, indent=2) + '\n')
    (ROOT / 'results/fixtures.json').write_text(json.dumps(fixed, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ('corpus', 'fixtures', 'cli', 'rule_events_in_successful_extractions')}, indent=2))
    if failures:
        raise SystemExit(1)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--checker', type=Path, default=ROOT / 'checker.py')
    parser.add_argument('--mutations', type=int, default=1200)
    parser.add_argument('--substitutions', type=int, default=360)
    args = parser.parse_args()
    run(args.checker.resolve(), args.mutations, args.substitutions)
