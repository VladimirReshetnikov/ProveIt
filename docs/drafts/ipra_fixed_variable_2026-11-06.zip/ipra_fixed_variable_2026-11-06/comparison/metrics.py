"""Measure every complete acceptance program at one identical boundary.

The primary boundary includes grammar, substitution, inference, JSON input,
file handling and verdict/rejection. Only comments and actual docstrings are
removed. The same Python runtime and standard library are shared assumptions.
The core diagnostic removes imports and __name__-guarded CLI blocks uniformly.
"""
import ast
import copy
import hashlib
import io
import json
import platform
import tokenize
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes')
CORE_FIELDS = ('normalized_tokens', 'ast_nodes', 'normalized_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL,
           tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
           tokenize.ENDMARKER}


def count_tokens(text, omitted=()):
    return sum(tok.type not in IGNORED and not any(
        first <= tok.start and tok.end <= last for first, last in omitted)
        for tok in tokenize.generate_tokens(io.StringIO(text).readline))


def normalized_metrics(tree):
    normalized = ast.unparse(tree) + '\n'
    return {'normalized_tokens': count_tokens(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(tree)),
            'normalized_bytes': len(normalized.encode('utf-8'))}


def measure(path):
    raw = path.read_bytes()
    source = raw.decode('utf-8')
    tree = ast.parse(source)
    omitted = []
    for node in list(ast.walk(tree)):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if (isinstance(first, ast.Expr)
                    and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                omitted.append(((first.lineno, first.col_offset),
                                (first.end_lineno, first.end_col_offset)))
                node.body.pop(0)
    core = copy.deepcopy(tree)
    core.body = [n for n in core.body
                 if not isinstance(n, (ast.Import, ast.ImportFrom))
                 and not (isinstance(n, ast.If)
                          and '__name__' in ast.unparse(n.test))]
    return {'sha256': hashlib.sha256(raw).hexdigest(),
            'raw_bytes': len(raw), 'source_tokens': count_tokens(source, omitted),
            **normalized_metrics(tree), 'core': normalized_metrics(core)}

