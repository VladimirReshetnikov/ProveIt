"""Build the complete paper from the supplied LaTeX sources."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

if __name__ == '__main__':
    subprocess.run([sys.executable, str(ROOT / 'measure.py')], cwd=ROOT, check=True)
    for _ in range(3):
        subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', 'report.tex'], cwd=ROOT, check=True)
