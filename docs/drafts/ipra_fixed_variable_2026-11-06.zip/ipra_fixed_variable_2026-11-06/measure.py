"""Reproduce the finite-corpus comparison at an unchanged acceptance boundary."""
import hashlib
import json
import platform
from pathlib import Path
from comparison.metrics import measure, FIELDS, CORE_FIELDS

ROOT = Path(__file__).resolve().parent


def main():
    manifest = json.loads((ROOT / 'comparison/manifest.json').read_text())
    rows = []
    for entry in manifest['checkers']:
        result = measure(ROOT / 'comparison' / entry['source'])
        if result['sha256'] != entry['sha256']:
            raise ValueError('Baseline changed: ' + entry['source'])
        rows.append({**entry, **result})
    minima = {field: min(row[field] for row in rows) for field in FIELDS}
    core_minima = {field: min(row['core'][field] for row in rows) for field in CORE_FIELDS}
    candidate = measure(ROOT / 'checker.py')
    result = {
        'repository': manifest['repository'], 'commit': manifest['commit'],
        'python': platform.python_version(), 'baseline_count': len(rows),
        'boundary': 'Complete acceptance program, including syntax, substitution, inference, JSON input, file handling, exception handling and verdict. Comments and actual docstrings excluded uniformly.',
        'core_boundary': 'Uniformly remove imports and the __name__ CLI block.',
        'baselines': rows, 'whole_minima': minima, 'core_minima': core_minima,
        'candidate': candidate,
        'whole_strict_improvement': {field: candidate[field] < minima[field] for field in FIELDS},
        'core_strict_improvement': {field: candidate['core'][field] < core_minima[field] for field in CORE_FIELDS},
    }
    (ROOT / 'results/metrics.json').write_text(json.dumps(result, indent=2) + '\n')
    labels = {'source_tokens': 'SourceTokens', 'normalized_tokens': 'NormTokens', 'ast_nodes': 'AST', 'normalized_bytes': 'Bytes'}
    macros = {'BaselineCount': len(rows)}
    for field, label in labels.items():
        macros['Old' + label], macros['New' + label] = minima[field], candidate[field]
        if field in CORE_FIELDS:
            macros['OldCore' + label] = core_minima[field]
            macros['NewCore' + label] = candidate['core'][field]
    (ROOT / 'results/numbers.tex').write_text(''.join(
        '\\newcommand{\\' + key + '}{' + f'{value:,}' + '}\n' for key, value in macros.items()))
    table = ['\\begin{longtable}{@{}llrrrr@{}}',
             '\\toprule Draft & Variant & Source & Norm. & AST & Bytes\\\\',
             '\\midrule\\endhead']
    for row in rows:
        variant = row['checker'].removeprefix('checker').removesuffix('.py').strip('_').replace('_', ' ') or 'primary'
        table.append(f"D{row['draft']} & {variant} & {row['source_tokens']} & {row['normalized_tokens']} & {row['ast_nodes']} & {row['normalized_bytes']:,}\\\\")
    table.extend(['\\bottomrule', '\\end{longtable}'])
    (ROOT / 'results/baselines.tex').write_text('\n'.join(table) + '\n')
    if not all(result['whole_strict_improvement'].values()) or not all(result['core_strict_improvement'].values()):
        raise AssertionError('Candidate does not strictly beat all envelope coordinates')
    print(json.dumps({key: result[key] for key in ('baseline_count', 'whole_minima', 'core_minima', 'candidate', 'whole_strict_improvement', 'core_strict_improvement')}, indent=2))
    return result


if __name__ == '__main__':
    main()
