A SMALLER PRESENTATION OF iPRA
Closure elimination at one variable
Prepared for Vladimir Reshetnikov, 6 November 2026 (Pacific date)

START HERE
  report.pdf             Complete compiled research paper.
  report.tex             Main LaTeX source; also needs sections/*.tex.
  checker.py             Entire standalone acceptance program.
  FORMAT.txt             Exact language and certificate format.

RESULT
Primitive numerical-closure elimination is restricted to the current
numerical variable, coordinate 1. Arbitrary-term instances are recovered
with an equality-guarded existential witness and equality transport.
The proof translation recurses on SOURCE derivations; it does not assume
literal lifting of restricted proofs. The new and old calculi have exactly
the same consequence relation. The unoptimized translation has N+5q <= 6N
rule nodes when the original has N nodes and q closure eliminations.

The report states all primitive rules and computation schemas, reconstructs
full intuitionistic first-order logic and all quantifier-free induction,
and proves whole-domain bi-interpretability and equiconsistency with iPRA.
Equality defines both internally proved composite isomorphisms.

Pinned source commit:
  9e8e3161b0dffb54fceb0b75ee818cc9e4ed2b10
All six current draft ZIPs were verified, and all 16 root checker variants
were remeasured. The current envelope is attained by D2/checker_demand.py.

                          Current minimum    Proposed
Significant source tokens        499             494
Normalized tokens                505             498
AST nodes                        510             502
Normalized UTF-8 bytes          1554            1534

Uniformly isolated core:
Normalized tokens                447             440
AST nodes                        444             436
Normalized UTF-8 bytes          1292            1272

The primary boundary includes grammar, substitution, all logical and
arithmetic rules, JSON input, file handling, exception handling and verdicts.
Comments and real docstrings are omitted uniformly. Raw source length is not
claimed to improve. This is a strict but modest finite-corpus improvement,
not an absolute minimality theorem. Other arithmetic basis ingredients are
inherited and explicitly credited. No Lean/Rocq formalization is claimed.

REPRODUCTION (Python 3.10+; measurement run uses CPython 3.12.14)
  python3 reproduce.py
  python3 checker.py examples/macro_induction_6.json
  python3 build.py

The first regenerates all measurements and tests without network access.
The second prints ACCEPT for an induction instance at a recursive term.
The third rebuilds the PDF; pdfLaTeX and ordinary packages are required.

VERIFICATION
989 source derivations compiled and accepted, with complete canonical
stream consumption; 80 targeted fixtures; 1200 bounded mutations compared
against an independent named-variable oracle; 360 main-suite substitution
checks; 18 public CLI checks including python -O; seven injected semantic
faults detected. A separate environment audit adds 1000 nested-binder cases,
720 boundary cases, and 50 malformed-sort comparisons against two references.
Some source derivations are open sequents with explicit valid test assumptions;
they are not 989 closed theorem certificates. The public interface always
starts with an empty context. Detailed results are in results/*.json.

ACCEPTANCE POLICY
Every active expression is validated. Elimination headers are [M,D]; D is
a formula motive only for equality, and is inert padding for Q and Ex.
Canonical padding is 0. An ignored Q payload cannot redirect its fixed
coordinate. Unread stack prefixes are allowed; compiler outputs consume
their entire stack. No ignored payload is interpreted as an asserted term.

SUPPORTING FILES
  compiler.py              Untrusted source-proof-to-certificate compiler.
  validation.py            Independent inference, mutation and CLI checks.
  substitution_audit.py    Old/new/named substitution comparison.
  validation_reference/   Frozen references, generators, examples, provenance.
  comparison/              All 16 exact measured programs and manifest.
  measure.py               Recomputes the finite-corpus comparison.
  reproduce.py             Runs all executable evidence.
  build.py                 Recompiles report.pdf.
  MANIFEST.sha256          Hashes of delivered files except the manifest itself.

Full source attribution and further research questions are in the report.
