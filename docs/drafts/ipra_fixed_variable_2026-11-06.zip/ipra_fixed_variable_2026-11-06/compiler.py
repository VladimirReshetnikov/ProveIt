"""Untrusted compiler from canonical unary-closure proof trees.

The source tree format is the one in the supplied ProveIt unary-Q drafts.
The target kernel has fixed-current-variable Q elimination.  This compiler
is not imported by the kernel; every emitted certificate must be checked.

Lifting follows the readable independent proof transformation bundled in
ipra_unary_stream_2026-11-06/validation/frozen/validation/proof_transforms.py.
"""
from copy import deepcopy


def native(data):
    """Rename the predecessor's q constructor to the baseline u spelling."""
    if type(data) is list:
        return [native(item) for item in data]
    return 'u' if data == 'q' else data


def substitute(expression, images=(), offset=1, depth=0):
    """Independent readable simultaneous numerical substitution."""
    if type(expression) is int:
        relative = expression - depth
        if relative <= 0:
            return expression
        if relative <= len(images):
            return substitute(images[relative - 1], offset=depth)
        return expression + offset
    tag, *children = expression
    widths = {'s': (0,), 'r': (0, 0, 2), '=': (0, 0),
              'u': (1,), 'ex': (1,)}[tag]
    return [tag, *(substitute(child, images, offset, depth + width)
                    for child, width in zip(children, widths, strict=True))]


def lift(expression, amount=1, protected=0):
    return substitute(expression, offset=amount, depth=protected)


def instance(body, term):
    return substitute(body, [term], -1)


def lift_proof(goal, proof, protected=0):
    """Lift a SOURCE proof; primitive restricted QE itself cannot be lifted."""
    changed_goal = lift(goal, protected=protected)
    if proof is None or proof == 'r':
        return changed_goal, deepcopy(proof)
    if goal[0] == 'u' and len(proof) == 1:
        child_goal = substitute(goal[1], [['s', 1]], 0)
        _, child = lift_proof(child_goal, proof[0], protected + 1)
        return changed_goal, [child]
    if goal[0] == 'ex' and len(proof) == 2:
        witness, child = proof
        _, changed_child = lift_proof(goal[1], child, protected + 1)
        return changed_goal, [lift(witness, protected=protected), changed_child]
    major, major_proof, *arguments = proof
    new_major, new_major_proof = lift_proof(major, major_proof, protected)
    if major[0] == 'ex':
        child, = arguments
        _, new_child = lift_proof(lift(goal), child, protected + 1)
        return changed_goal, [new_major, new_major_proof, new_child]
    annotation, child = arguments
    if major[0] == '=':
        new_annotation = lift(annotation, protected=protected + 1)
        child_goal = instance(annotation, major[1])
    else:
        if major[0] != 'u':
            raise ValueError('Unknown source major formula')
        new_annotation = lift(annotation, protected=protected)
        child_goal = instance(major[1], 0)
    _, new_child = lift_proof(child_goal, child, protected)
    return changed_goal, [new_major, new_major_proof, new_annotation, new_child]


def unrestricted_qe(major, major_proof, term, base_proof):
    """Compile arbitrary QE using one fresh equality-guarded existential.

    Input proofs are source TREES, so lifting them preserves the original
    rule.  Each lifted proper subproof is then recursively compiled.  This
    is structural recursion on source trees, not recursive use of this
    macro on a proof of the same size.
    """
    base_goal = instance(major[1], 0)
    if term == 1:
        return compile_tree(base_goal, base_proof) + compile_tree(major, major_proof) + [[major, 0]]
    renamed_major, renamed_major_proof = lift_proof(major, major_proof)
    renamed_base, renamed_base_proof = lift_proof(base_goal, base_proof)
    # Under fresh y, the original body is its y instance.  The renamed
    # matrix is also exactly the equality motive with its hole protected.
    fixed = (compile_tree(renamed_base, renamed_base_proof)
             + compile_tree(renamed_major, renamed_major_proof)
             + [[renamed_major, 0]])
    guard = ['=', 1, lift(term)]
    motive = renamed_major[1]
    # Equality elimination carries its motive in the uniform major header.
    transported = fixed + [None, [guard, motive]]
    existence = ['ex', guard]
    # ex y(y=t) has canonical guarded-introduction proof [None, [t]].
    return transported + [None, [term], [existence, 0]]


def compile_tree(goal, proof):
    """Compile a canonical source tree to an end-popped uniform-header target stream."""
    if proof is None:
        return [None]
    if proof == 'r':
        return [[]]
    if goal[0] == 'u' and len(proof) == 1:
        child_goal = substitute(goal[1], [['s', 1]], 0)
        return compile_tree(child_goal, proof[0]) + [[]]
    if goal[0] == 'ex' and len(proof) == 2:
        witness, child = proof
        return compile_tree(goal[1], child) + [[witness]]
    major, major_proof, *arguments = proof
    if major[0] == 'ex':
        child, = arguments
        return (compile_tree(lift(goal), child)
                + compile_tree(major, major_proof) + [[major, 0]])
    annotation, child = arguments
    if major[0] == '=':
        source = instance(annotation, major[1])
        return (compile_tree(source, child)
                + compile_tree(major, major_proof) + [[major, annotation]])
    if major[0] == 'u':
        return unrestricted_qe(major, major_proof, annotation, child)
    raise ValueError('Unknown source rule')


def main():
    """Compile one canonical predecessor theorem [goal,tree] JSON file."""
    import json
    from pathlib import Path
    import sys
    source, destination = map(Path, sys.argv[1:])
    goal, tree = native(json.loads(source.read_text()))
    destination.write_text(json.dumps([goal, compile_tree(goal, tree)], indent=2) + '\n')


if __name__ == '__main__':
    main()
