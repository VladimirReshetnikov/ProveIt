#!/usr/bin/env python3
"""Exact finite audit; Python 3.10+, standard library."""
from itertools import combinations
from math import comb
from fractions import Fraction
import random, json

def check(b, msg):
    if not b: raise AssertionError(msg)
def masks(n,r): return [sum(1<<i for i in c) for c in combinations(range(n),r)]
def subsets(m):
    s=m
    while s:
        yield s
        s=(s-1)&m

def closure(E):
    U={0}
    for e in E: U|={s|e for s in U}
    return U
def interior(E,s):
    a=0
    for e in E:
        if e&s==e: a|=e
    return a
def primal(E,n):
    G=[sum(1<<j for j,e in enumerate(E) if e>>i&1) for i in range(n)]
    return closure(G),G
def dual(E,n,U):
    F,_=primal(E,n); seen=set()
    for a in F:
        s=0
        for j,e in enumerate(E):
            if not a>>j&1: s|=e
        check(s not in seen,'injectivity'); seen.add(s)
        for j,e in enumerate(E): check((not a>>j&1)==(e&s==e),'absence')
    check(seen==U,'surjectivity')
def level(E,n):
    if next(iter(E)).bit_count()==n: return 2
    return 1+min(sum(((e^(1<<a))|(1<<v)) in E for a in range(n) if e>>a&1) for e in E for v in range(n) if not e>>v&1)
def lower(d,k): return 1+sum(comb(d+k-1,i) for i in range(d+1))
def exchange(E,n,extra=()):
    k=level(E,n)
    if k<2: return False
    d=n-next(iter(E)).bit_count(); full=(1<<n)-1
    U0=closure(E)
    check(U0=={0}|{s for s in range(1<<n) if any(s&e==e for e in E)},'upset')
    faces={full^s for s in U0 if s}
    for i in range(d+1): check(sum(s.bit_count()==i for s in faces)>=comb(d+k-1,i),'face bound')
    H=set(E)|set(extra); U=closure(H)
    check(len(U)>=lower(d,k),'total lower bound')
    for e in E:
        A={s for s in U if s&e==e}
        check(len(A)==2**d,'absence count')
        check(Fraction(len(U)-len(A),len(U))>=Fraction(lower(d,k)-2**d,lower(d,k)),'frequency')
        for f in H: check(sum(s&f==f for s in A)==2**(n-(e|f).bit_count()),'joint absence')
    return True

def repair(E,n,U,f,w):
    bad=[h for h in E if h&w and (h&~f)&~interior(E,(h|f)&~w)]
    A=[s for s in U if s&f==f]
    b=[s for s in A if interior(E,s&~w)|f!=s]
    check(bool(bad)==bool(b),'local-global equivalence')
    images={interior(E,s&~w) for s in A if s not in b}
    check(len(images)==len(A)-len(b),'injection')
    check(all(s in U and not s&w and s&f!=f for s in images),'range')
    L=sum(bool(s&w) and s&f!=f for s in U)
    B=sum(any(s&(h|f)==h|f for h in bad) for s in range(1<<n))
    check(len(b)<=B,'defect upper bound')
    check(len(U)-2*len(A)>=L-len(b)>=L-B,'defect inequality')
    return not bad

def main():
    rng=random.Random(20261125)
    stats=dict(uniform_systems=0,exchange_systems=0,repair_systems=0,repair_tests=0,repair_certificates=0,dual_checks=0)
    for n in range(1,6):
        for r in range(1,n+1):
            E=masks(n,r)
            for a in range(1,1<<len(E)):
                H={e for j,e in enumerate(E) if a>>j&1}
                stats['uniform_systems']+=1
                stats['exchange_systems']+=exchange(H,n,rng.sample(list(range(1,1<<n)),min(3,(1<<n)-1)))
    systems=[]
    for n in range(1,4):
        E=list(range(1,1<<n))
        systems.extend((n,[e for j,e in enumerate(E) if a>>j&1]) for a in range(1,1<<len(E)))
    for _ in range(600):
        n=rng.randrange(4,9)
        systems.append((n,sorted(rng.sample(list(range(1,1<<n)),rng.randint(1,min(16,(1<<n)-1))))))
    for n,E in systems:
        U=closure(E); dual(E,n,U)
        stats['dual_checks']+=1; stats['repair_systems']+=1
        for f in E:
            for w in subsets(f):
                stats['repair_tests']+=1
                stats['repair_certificates']+=repair(E,n,U,f,w)
    for d in range(1,6):
        for k in range(2,5):
            n=d+k-1; fixed=(1<<n)|(1<<(n+1)); E={e|fixed for e in masks(n,k-1)}
            check(exchange(E,n+2),'sharp core'); check(len(closure(E))==lower(d,k),'sharp equality')
    examples={}
    d,k=3,3; block=d+k-1; n=2*block; full=(1<<n)-1
    facets=set(masks(block,d))|{e<<block for e in masks(block,d)}; E={full^e for e in facets}
    check(exchange(E,n),'two-block core'); U=closure(E); F,G=primal(sorted(E),n)
    examples['nonmatroid_core']=dict(n=n,supports=len(E),exchange_level=level(E,n),members=len(U),point_frequency=str(Fraction(len(U)-2**d,len(U))),min_generator_size=min(g.bit_count() for g in G),supports_masks=sorted(E))
    n=10; E=sorted(set(masks(5,4))|{e<<5 for e in masks(5,4)}|{(1<<0)|(1<<1)|(1<<5)|(1<<6)})
    U=closure(E); F,G=primal(E,n); f=30; w=16
    check(repair(E,n,U,f,w),'bridge repair'); check(level(set(E),n)==1,'no full exchange')
    A=sum(s&f==f for s in U); L=sum(bool(s&w) and s&f!=f for s in U)
    check(min(g.bit_count() for g in G)>=4 and len(set(G))==n,'nondegenerate')
    examples['repair_bridge']=dict(n=n,supports=len(E),members=len(U),marked_frequency=str(Fraction(len(U)-A,len(U))),unused_images=L,min_generator_size=min(g.bit_count() for g in G),supports_masks=E,marked_mask=f,erasure_mask=w,generator_masks=G)
    E2=sorted(set(E)|{51}); U2=closure(E2)
    check(not repair(E2,n,U2,f,w),'defective example must fail exact test')
    bad=[h for h in E2 if h&w and (h&~f)&~interior(E2,(h|f)&~w)]
    A2=sum(s&f==f for s in U2); L2=sum(bool(s&w) and s&f!=f for s in U2)
    B2=sum(any(s&(h|f)==h|f for h in bad) for s in range(1<<n))
    b2=sum(s&f==f and interior(E2,s&~w)|f!=s for s in U2)
    check(L2>B2,'strict defect certificate')
    examples['defective_bridge']=dict(members=len(U2),bad_supports=bad,exact_bad=b2,unused_images=L2,boolean_bound=B2,marked_frequency=str(Fraction(len(U2)-A2,len(U2))))
    table=[dict(d=d,k=k,bound=str(Fraction(lower(d,k)-2**d,lower(d,k)))) for d in [1,2,5,10,50] for k in [2,3,4,5]]
    result=dict(status='PASS',stats=stats,sharp_cases=15,examples=examples,table=table)
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
