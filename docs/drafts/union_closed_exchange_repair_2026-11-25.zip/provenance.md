# Source review and limitations

Research date: 2026-11-25 (US Pacific). The directory inventory was fetched from the user-specified GitHub repository using the GitHub connector, then selected ZIP blobs were decoded in memory to inspect README files and, in several cases, opening manuscript sections. No files were written to GitHub. This was a selective comparison, not a full-text audit of all 30 ZIP archives.

## Inspected archives

All paths below are under `docs/drafts/` in `VladimirReshetnikov/ProveIt`, ref `main`. The listed values are Git blob SHAs returned by the connector (not SHA-256 checksums).

| Archive | Blob SHA | Relevant scope |
|---|---|---|
| `union_closed_rank_transport_2026-11-25.zip` | `f4c375d5ae9b7337ed4e542950da3d602be537be` | entropy rank transport and finite-size frequency bounds |
| `union_closed_dense_core_2026-11-25.zip` | `b1c269b2ae1cdb03f91797a2bf840e96730c5934` | robust marked-pair certificate via missing-generator types |
| `union_closed_signature_interfaces_2026-11-25.zip` | `7d715274e013371d5d4156b461f970c50c1f9c00` | separating signatures and exterior-fiber projection counts |
| `union_closed_lopsided_certificates_2026-11-25.zip` | `6a4907063eaf84961dcfacea3718ebf7741ff100` | negative dependence in incidence-support models |
| `union_closed_cycle_certificates.zip` | `78e17f9a3659b69b95c53e3c54e0a8f821a365b8` | directed-cycle feasible-set certificates |
| `union_closed_antichain_shadows_2026-11-25.zip` | `ce0aa9b6412a1196261afacbb8deb9954fb7ead7` | antichain shadows, entropy and cut capacities |
| `union_closed_redundant_core_2026-11-25.zip` | `18cd1e26f63dee50486533964e3fbf085660af09` | complete internal incidence types and deletion-robust exterior patterns |
| `union_closed_local_abundance.zip` | `cc4298e4a6199e5781de56cd7c363d4576ca8c4d` | exact local high-girth bounds |
| `union_closed_five_type_obstructions_2026-11-25.zip` | `031a30363602a04b7a35a4e3194f484a2f076a9c` | robust-pair compression and four-omission theorem |
| `union_closed_structural_theorems.zip` | `bba38e6abe6445578e551dfc16f678f4fdb4fa56` | fetched, but no README extracted in the second pass |
| `union_closed_defective_substitution.zip` | — | incomplete replacement blocks, joint absence bounds, distinct-union model; inspected README and opening text |

The new exchange condition uses a uniform support core whose complements form a pure complex with multiple extensions at each ridge, rather than requiring disjoint replacement blocks or all internal types of a fixed size. Additional supports need not obey any exchange or regularity conditions. The local repair condition preserves all generator indices outside a marked support by taking a largest feasible subset; its equivalence to reconstruction of this specific map and its defect--surplus bound are distinct from the stated antecedent mechanisms. These comparisons are limited to the inspected sections; they do not establish that no overlap exists in the full drafts.

## Public literature

- [Frankl conjecture overview](https://en.wikipedia.org/wiki/Union-closed_sets_conjecture): problem statement and background.
- [Bruhn et al., The graph formulation of the union-closed sets conjecture](https://doi.org/10.1016/j.ejc.2014.08.030): known structural cases, including triple-generated families.
- [Swartz (2004), Lower bounds for h-vectors of k-CM, independence, and broken circuit complexes](https://doi.org/10.1137/S0895480102411358): related established face-counting literature. No independent novelty claim for the ridge-count lemma or the matroid face bound.
- [Chase–Lovett, Approximate union closed conjecture](https://arxiv.org/abs/2211.11689): entropy approach and prior universal bound.
- [MathWorld, Union-Closed Sets Conjecture](https://mathworld.wolfram.com/Union-ClosedSetsConjecture.html): records Costa–Sadhu's later bound; used as secondary source.
- [Quantavane, November 2026 claim](https://quantavane.com/major-results/union-closed-sets-conjecture/): a more recent reported computer-assisted bound; not independently audited here.

Search phrases included union-closed sets conjecture + matroid bases, incidence dual, exchange, simplicial complex facets, dominated vertices, edge deletion, and cocircuit lower bounds. The search found related graph and matroid counting literature but did not establish historical priority for the marked-frequency applications and repair criterion. This is not a systematic literature review; no peer review or proof-assistant verification has occurred. The manuscript's general proofs are self-contained except for the standard fundamental-circuit fact in the optional matroid corollary.
