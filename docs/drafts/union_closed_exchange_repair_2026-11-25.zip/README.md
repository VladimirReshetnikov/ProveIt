# Exchange multiplicity and local repair

**Start with `paper.pdf`.** Research note for ProveIt, 25 November 2026.

Two restricted theorems for Frankl's union-closed sets conjecture:

1. If a marked uniform incidence core allows at least k−1 replacements of each support by each outside index, every marked point has frequency at least 1−2^d/(1+sum_{i=0}^d binom(d+k−1,i)), where d = number of indices outside a support. This is sharp and remains valid under arbitrary additional supports. The class includes but is not confined to matroids. Exact joint absence laws also follow.
2. A local deletion-repair condition is equivalent to a global reconstruction identity and supplies an injection proving half-frequency, even within each exterior fiber. The defect–surplus extension certifies some cases where exact repair fails.

The unrestricted conjecture is not proved; no improvement to its universal asymptotic bound is claimed. Historical novelty is provisional. The proofs are mathematical, not Lean/Rocq formalizations. No repository changes were made.

## Files

- `paper.tex`, `paper.pdf`: complete manuscript and compiled PDF.
- `verify.py`: dependency-free finite audit and exact examples (Python 3.10+).
- `verification.json`: actual audit output (2,223 uniform systems, 735 general systems, 68,838 repair tests, 15 sharpness instances).
- `provenance.md`: repository and public-literature comparison and limitations.
- `Makefile`: reproduction targets.
- `SHA256SUMS`: integrity manifest.

## Reproduction

```sh
sha256sum -c SHA256SUMS
python3 verify.py > verification-new.json
diff -u verification.json verification-new.json
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

Use standard TeX Live with AMS packages, Latin Modern, geometry, microtype, booktabs, xcolor, hyperref. PDF metadata may change on recompilation. The audit uses integer masks and exact fractions; explicit checks remain active under `python -O`. It supplements the proofs rather than replacing them.
