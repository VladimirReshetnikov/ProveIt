SHIFTED UNARY ITERATION FOR iPRA
==============================
Research prepared for Vladimir Reshetnikov, November 8, 2026.
Repository snapshot: 12a94890af11b5e75f753260f3be00bb11ae7f08

STATUS
------
The requested strict complete-proof-checker reduction has NOT been achieved.
The current complete-program coordinate envelope is 313 normalized tokens,
347 AST nodes, and 878 normalized bytes, attained by different programs.

The report gives an explicit completed theory U with only zero and shifted
closed-unary iteration as primitive numerical syntax. Successor is a term.
U includes one explicit fixed retraction equation for the constructed
predecessor. U is bi-interpretable and equiconsistent with full intuitionistic
first-order primitive recursive arithmetic. The extra equation is proved
in iPRA, but has NOT been derived in the smaller unary theory. Its entire
fixed term description must count toward any checker implementation.

NEW RESULTS RELATIVE TO THE INSPECTED DRAFTS
-----------------------------------------
1. A definable involution swaps zero and one and fixes every double successor.
2. Conjugation by that involution internally recovers zero-initialized iteration.
3. A translated transient clock gives an explicit predecessor term, proved for
   all standard inputs and by a written quantifier-free-induction argument in iPRA.
4. This term recovers arbitrary initialized iteration in the standard model.
5. One fixed retraction (equivalently clock) axiom yields a complete unary theory.
6. An exact internal clock equation isolates the remaining axiom-deletion problem.

FILES
-----
report.tex and sections/    Complete LaTeX manuscript.
report.pdf                 Compiled report.
code/equations/            Symbolic equational proof certificates and verifier.
code/clock/                Staged term source, evaluator, and numerical diagnostics.
code/measure_frontier.py   Reproduce all 16 complete comparator profiles.
evidence/                 Reproduction receipts and source provenance.
reference/checkers/       Unchanged complete comparator source files.
reference/source_measure.py
                           Unchanged inherited whole-program source normalizer.
reference/ipra_closed_equational_2026-11-08.zip
                           Exact inherited internal arithmetic reconstruction,
                           including its source, PDF, and supporting artifacts.
reference/LICENSE-inherited.txt
                           License retained with inherited sources.
MANIFEST.json              SHA-256 hashes and sizes of delivered package members.

REPRODUCE
---------
  python3 reproduce.py
  python3 build.py

Python diagnostics use only the standard library and do not need network access.
Use CPython 3.12 to reproduce the published normalized source sizes. Other Python
versions can change AST formatting. PDF compilation requires pdflatex and the
standard packages listed in report.tex. Alternatively run `make`.

VERIFYING SCOPE
---------------
The symbolic verifier proves 45 listed equations using eight literal-equation
induction nodes; fourteen damaged certificates are rejected. It is NOT a complete
iPRA checker and does NOT certify the full clock, the first-order interpretation,
or the complete report in Lean/Rocq. Its trusted rules are documented in its source.

The staged numerical artifact contains 49 legal closed-unary declarations. There
are 757 numerical checks and four malformed-signature controls. The evaluator
discloses elementary accelerations, checks their source signature, and never
substitutes the expected predecessor/clock/ramp/recovered-iterator answers.
Numerical checks do not establish an identity in arbitrary models.

Naming: code/clock uses C for the report's long clock A, and p for the final
predecessor P. The earlier lowercase p in the seed-recovery proof is a different
bootstrap term, aliased Q in the clock section.

ATTRIBUTION
-----------
The paired-binder logic, ordinary initialized-iteration arithmetic reconstruction,
and comparison checker programs come from the supplied ProveIt drafts. The
counter-dependent shifted recursion idea and explicit open unary question come
from ipra_successor_from_recursion_2026-11-08.zip. The new transposition,
translated clock, and completed unary presentation are claimed only as advances
relative to this inspected corpus, not as a historical-priority result.

No GitHub files, branches, commits, issues, or pull requests were modified.
