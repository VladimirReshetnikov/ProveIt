#!/usr/bin/env python3
"""Compile the LaTeX report; requires pdflatex and standard TeX Live packages."""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
for _ in range(3):
    subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                    "-file-line-error", "report.tex"], cwd=ROOT, check=True,
                   stdout=subprocess.DEVNULL)
print(ROOT / "report.pdf")
