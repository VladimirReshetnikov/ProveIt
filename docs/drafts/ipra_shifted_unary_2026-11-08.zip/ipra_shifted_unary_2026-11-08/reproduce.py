#!/usr/bin/env python3
"""Run all research certificates, numerical diagnostics, and source measurements."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
commands = [
    ["code/equations/verify_equations.py", "code/equations/equational_certificates.json",
     "--output", "code/equations/verification.json"],
    ["code/equations/test_certificates.py"],
    ["code/clock/evaluate.py"],
    ["code/measure_frontier.py"],
]
receipts = []
for command in commands:
    run = subprocess.run([sys.executable, *command], cwd=ROOT, env=env,
                         text=True, capture_output=True, check=False)
    receipts.append({"command": ["python3", *command], "exit_code": run.returncode,
                     "stdout": run.stdout, "stderr": run.stderr})
    print(command[0] + ": " + ("PASS" if run.returncode == 0 else "FAIL"), flush=True)
    if run.returncode:
        print(run.stdout, end="")
        print(run.stderr, end="", file=sys.stderr)
        raise SystemExit(run.returncode)
report = {"status": "PASS", "python": platform.python_version(), "runs": receipts,
          "scope": "Symbolic equations, bounded standard-model diagnostics, and comparison measurements; not a full formalization of the report."}
(ROOT / "evidence/reproduction.json").write_text(json.dumps(report, indent=2) + "\n")
