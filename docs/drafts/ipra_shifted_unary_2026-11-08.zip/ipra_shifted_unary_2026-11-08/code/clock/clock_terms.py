#!/usr/bin/env python3
"""Staged terms for the shifted closed-unary predecessor experiment.

Primitive numerical syntax is zero, variables, and K_h(n,a). F(name,t)
is only a transparent abbreviation for a previously declared unary term.
In particular s(t) expands to K_id(0,t); successor is not primitive.

This file describes terms. It does not assert an internal predecessor
theorem or implement a complete iPRA proof checker.
"""

import json
from pathlib import Path

ZERO = ("0",)
U = ("v", "u")


def call(name, argument):
    return ("F", name, argument)


def iterate(name, count, initializer):
    return ("K", name, count, initializer)


def signature():
    definitions = []

    def define(name, body):
        definitions.append({"name": name, "body": body})
        return name

    define("id", U)
    define("zero", ZERO)
    define("s", iterate("id", ZERO, U))

    def s(term, count=1):
        for _ in range(count):
            term = call("s", term)
        return term

    one, two = s(ZERO), s(ZERO, 2)
    define("Z", iterate("zero", U, ZERO))
    define("parity_from_one", iterate("Z", U, ZERO))
    define("H", iterate("zero", call("parity_from_one", U), one))
    define("V", iterate("H", U, ZERO))
    define("B2", call("Z", call("Z", call("V", U))))
    define("U", iterate("H", call("B2", U), U))
    define("tau", iterate("U", U, ZERO))

    def zero_iteration(update, name):
        conjugate = "conjugate_for_" + name
        define(conjugate, call("tau", call(update, call("tau", U))))
        define(name, call("tau", iterate(conjugate, U, ZERO)))
        return name

    def conjunction(b, c):
        return call("Z", call("tau", iterate("zero", call("Z", b), call("Z", c))))

    def disjunction(b, c):
        return call("Z", conjunction(call("Z", b), call("Z", c)))

    zero_iteration("s", "identity_clock")
    zero_iteration("Z", "N")
    define("cycle3", iterate("zero", conjunction(call("Z", call("N", U)),
                                                 call("Z", call("Z", U))), U))
    zero_iteration("cycle3", "M")
    define("cycle4", iterate("zero", conjunction(call("N", U),
                                                 call("Z", call("M", U))), U))
    zero_iteration("cycle4", "M4")
    define("s2", s(U, 2))
    zero_iteration("s2", "D")
    define("g", iterate("s", call("M", U), U))
    zero_iteration("g", "G")
    shifted = s(U, 8)
    define("bf", conjunction(call("Z", call("M", shifted)),
                              call("Z", call("N", shifted))))
    define("be", conjunction(call("Z", call("M", shifted)), call("N", shifted)))
    define("Fclock", iterate("G", call("bf", U), s(U)))
    define("T", iterate("zero", call("be", U), call("Fclock", U)))
    define("initializer_update", s(call("D", U), 9))
    define("a", iterate("initializer_update", U, two))
    define("e4", call("Z", call("M4", s(U, 2))))
    define("r", iterate("s", call("e4", U), U))
    zero_iteration("r", "R")
    define("C", iterate("T", call("R", U), call("a", U)))
    define("prefix_bit", disjunction(call("Z", call("M4", U)),
                                      call("Z", call("M4", s(U)))))
    define("prefix_step", iterate("zero", call("prefix_bit", U), U))
    define("W", iterate("prefix_step", U, ZERO))
    define("c", iterate("zero", call("Z", call("W", U)),
                         call("Z", call("M4", s(call("W", U))))))
    tail_argument = s(U, 6)
    define("p", iterate("Z", call("c", U),
                         iterate("s", call("M", tail_argument), call("C", tail_argument))))

    # These closed source updates are used only in initializer diagnostics.
    define("double_plus_one", iterate("s", U, U))
    for update in ("zero", "id", "s", "s2", "tau", "double_plus_one"):
        define("lift_" + update, s(call(update, call("p", U))))

    return {
        "primitive_syntax": ["zero", "variable", "K indexed by a closed earlier unary term"],
        "standard_meaning": "K_h(n,a)=h^n(a+1)",
        "successor_abbreviation": ["K", "id", ["0"], ["v", "u"]],
        "definitions": definitions,
        "target": "p",
        "status": "Standard-model construction; internal predecessor theorem remains open.",
    }


if __name__ == "__main__":
    destination = Path(__file__).with_name("terms.json")
    destination.write_text(json.dumps(signature(), indent=2) + "\n")
    print(destination.name)
