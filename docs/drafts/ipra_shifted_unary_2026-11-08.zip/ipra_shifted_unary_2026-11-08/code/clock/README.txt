SHIFTED CLOSED-UNARY CLOCK ARTIFACTS
==================================

Scope
-----
These files specify and evaluate the finite staged term for a standard
truncated predecessor. Every source term uses only zero, variables, and
K_h(n,a), where h is an earlier closed unary description. F(name,t) is a
transparent abbreviation. Successor expands to K_id(0,t).

This is not a full iPRA certificate checker. A successful diagnostic does
not prove the predecessor equation in nonstandard models, does not prove
the missing internal clock invariant, and does not establish the requested
bi-interpretability or checker-size improvement.

Files
-----
clock_terms.py constructs the source declaration table.
terms.json is that complete source table, with no uninterpreted update.
evaluate.py validates staged closure and evaluates source terms.
diagnostics.json records the reproducible finite checks.

Reproduce with Python 3.10 or later, with no third-party dependencies:

  python3 clock_terms.py
  python3 evaluate.py

Evaluate a term, for example p(40):

  python3 evaluate.py --evaluate p 40

Use literal defining-equation evaluation for a small helper example:

  python3 evaluate.py --direct --evaluate tau 12

Evaluation contract
-------------------
The standard interpretation is K_h(n,a)=h^n(a+1). Direct mode implements
that recurrence with transparent abbreviation expansion, memoization,
and exact cycle detection. A cycle is skipped only after an identical
integer state has actually recurred under the same fixed update.

The full clock deliberately visits exponentially large integer states.
Consequently default accelerated mode uses the following independently
proved standard helper identities:
  s(n)=n+1;
  Z(0)=1 and Z(n+1)=0;
  tau swaps 0 and 1 and fixes all n>=2;
  identity_clock(n)=n;
  N(n)=n mod 2, M(n)=n mod 3, M4(n)=n mod 4;
  D(n)=2n;
  G(n)=n+floor(n/2).
It also sums iterates of a declared affine update exactly. The permitted
affine descriptors are id, s, s2, initializer_update, and double_plus_one.
For h(x)=q*x+r, q>1, the formula used is
  K_h(n,a)=q^n*(a+1)+r*(q^n-1)/(q-1).
For q=1 it is a+1+r*n.

Accelerated evaluation requires the entire loaded declaration table to
match the bundled source exactly. A different staged source can still be
evaluated in direct mode. This prevents a changed helper body from being
silently evaluated using an old shortcut.

The evaluator NEVER replaces p by max(n-1,0), C by its clock-tail formula,
R by n+floor(n/3), or I_h by ordinary initialized iteration. These formulas
appear only as expected results in independent diagnostic comparisons.
The actual values of p, C, R, T, the prefix patch, and recovered I_h are
calculated from their staged source descriptions.

Evidence and limits
-------------------
The diagnostic compares all nine accelerated helper functions against
direct source evaluation on inputs 0..24, each affine iterator against
direct source evaluation on 16 pairs, and eleven control functions on
inputs 0..16. It checks the clock-tail formula for n=9..96 and the full
predecessor term for n=0..128. It also checks 48 deterministic seeded
examples of the recovered initialized iterator with six different closed
updates. Four malformed-source mutations must be rejected.

The finite checks guard implementation and transcription errors. The
universal standard-model predecessor claim rests on the separately
written phase proof, not on extending the numerical range of this test.
No amount of standard-model testing supplies the missing internal
equation-induction proof.
