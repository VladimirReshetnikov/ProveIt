#!/usr/bin/env python3
"""Verify symbolic equation proofs in shifted closed-unary iteration.

This is a research artifact for the transposition and zero-initializer
theorems. It is not a complete iPRA checker or a checker-size competitor.

Numerical syntax has zero, variables, named transparent unary terms, and
K_h(n,a). There is no primitive successor: s(a) is K_id(0,a).
Every defined unary body refers only to earlier declarations. The one
uninterpreted unary symbol f is a schematic update parameter: the proof
works uniformly for every fixed source closed unary term substituted for f.

The trusted rules are equality by computation/congruence/transitivity,
instantiation of earlier proved equations, and induction on one literal
equation. Fixed assumptions are retained; the induction variable must not
occur in them. The terminating fuel guard is a rejection condition only.
"""

import argparse
import hashlib
import json
from pathlib import Path


def freeze(t):
    if not isinstance(t, list):
        raise ValueError("a term must be a JSON array")
    if t == ["0"]:
        return ("0",)
    if len(t) == 2 and t[0] == "v" and isinstance(t[1], str):
        return ("v", t[1])
    if len(t) == 3 and t[0] == "F" and isinstance(t[1], str):
        return ("F", t[1], freeze(t[2]))
    if len(t) == 4 and t[0] == "K" and isinstance(t[1], str):
        return ("K", t[1], freeze(t[2]), freeze(t[3]))
    raise ValueError("malformed numerical term")


def subst(t, mapping):
    if t[0] == "v":
        return mapping.get(t[1], t)
    if t[0] == "0":
        return t
    return (*t[:2], *(subst(c, mapping) for c in t[2:]))


def variables(t):
    if t[0] == "v":
        return {t[1]}
    if t[0] == "0":
        return set()
    return set().union(*(variables(c) for c in t[2:]))


def declared(t, names):
    if t[0] in ("v", "0"):
        return
    if t[1] not in names:
        raise ValueError("forward or unknown unary declaration: " + t[1])
    for c in t[2:]:
        declared(c, names)


ZERO = ("0",)


def successor(a):
    return ("K", "id", ZERO, a)


class Kernel:
    def __init__(self, data):
        self.definitions = {}
        self.theorems = {}
        self.reductions = 0
        self.induction_nodes = 0
        self.calculation_nodes = 0
        self.proved_names = []
        for item in data["definitions"]:
            name = item["name"]
            if not isinstance(name, str) or name in self.definitions:
                raise ValueError("duplicate or malformed declaration")
            if item.get("schematic"):
                if name != "f" or "body" in item:
                    raise ValueError("only f may be an uninterpreted schema parameter")
                body = None
            else:
                body = freeze(item["body"])
                declared(body, self.definitions)
                if not variables(body) <= {"u"}:
                    raise ValueError("an update captures an external parameter")
            self.definitions[name] = body
        if self.definitions.get("id") != ("v", "u"):
            raise ValueError("id must be the identity unary term")
        self.data = data

    def tick(self, fuel):
        fuel[0] -= 1
        self.reductions += 1
        if fuel[0] < 0:
            raise ValueError("normalization fuel exhausted")

    def normal(self, term, fuel, memo):
        if term in memo:
            return memo[term]
        self.tick(fuel)
        tag = term[0]
        if tag in ("v", "0"):
            out = term
        elif tag == "F":
            name, argument = term[1], self.normal(term[2], fuel, memo)
            body = self.definitions[name]
            if body is None:
                out = ("F", name, argument)
            else:
                out = self.normal(subst(body, {"u": argument}), fuel, memo)
        else:
            name = term[1]
            count = self.normal(term[2], fuel, memo)
            seed = self.normal(term[3], fuel, memo)
            if count == ZERO:
                # K_id(0,a) is the chosen normal form for successor.
                out = successor(seed)
            elif count[:3] == ("K", "id", ZERO):
                previous = ("K", name, count[3], seed)
                out = self.normal(("F", name, previous), fuel, memo)
            else:
                out = ("K", name, count, seed)
        memo[term] = out
        return out

    def rewrite_exact(self, term, facts, fuel):
        # A finite exact-subterm replacement is an equality congruence.
        for left, right in facts:
            if term == left and left != right:
                self.tick(fuel)
                return right, True
        if term[0] in ("v", "0"):
            return term, False
        children, changed = [], False
        for child in term[2:]:
            new, did = self.rewrite_exact(child, facts, fuel)
            children.append(new)
            changed |= did
        return (*term[:2], *children), changed

    def simplify(self, term, facts, fuel, memo):
        for _ in range(1000):
            term = self.normal(term, fuel, memo)
            term, changed = self.rewrite_exact(term, facts, fuel)
            if not changed:
                return term
        raise ValueError("equational calculation did not terminate")

    def fact(self, item, hypotheses):
        if "hypothesis" in item:
            index = item["hypothesis"]
            if type(index) is not int or not 0 <= index < len(hypotheses):
                raise ValueError("invalid hypothesis index")
            answer = hypotheses[index]
        else:
            name = item["theorem"]
            if name not in self.theorems:
                raise ValueError("unproved theorem reference: " + name)
            old_hypotheses, left, right = self.theorems[name]
            mapping = {k: freeze(v) for k, v in item.get("substitution", {}).items()}
            for t in mapping.values():
                declared(t, self.definitions)
            required = [(subst(l, mapping), subst(r, mapping))
                        for l, r in old_hypotheses]
            if any(eq not in hypotheses for eq in required):
                raise ValueError("a theorem's fixed assumptions were not supplied")
            answer = (subst(left, mapping), subst(right, mapping))
        return answer[::-1] if item.get("reverse", False) else answer

    def proof(self, node, left, right, hypotheses):
        if node["rule"] == "calculation":
            self.calculation_nodes += 1
            fuel, memo = [2000000], {}
            facts = [self.fact(f, hypotheses) for f in node.get("facts", [])]
            facts = [(self.normal(l, fuel, memo), self.normal(r, fuel, memo))
                     for l, r in facts]
            l = self.simplify(left, facts, fuel, memo)
            r = self.simplify(right, facts, fuel, memo)
            if l != r:
                raise ValueError("the displayed equality does not follow by the calculation")
        elif node["rule"] == "equation_induction":
            self.induction_nodes += 1
            variable = node["variable"]
            if not isinstance(variable, str):
                raise ValueError("invalid induction variable")
            if any(variable in variables(l) | variables(r) for l, r in hypotheses):
                raise ValueError("induction variable occurs in a retained assumption")
            base_map = {variable: ZERO}
            step_map = {variable: successor(("v", variable))}
            self.proof(node["base"], subst(left, base_map), subst(right, base_map), hypotheses)
            self.proof(node["step"], subst(left, step_map), subst(right, step_map),
                       hypotheses + [(left, right)])
        else:
            raise ValueError("unknown proof rule")

    def verify(self):
        for item in self.data["theorems"]:
            name = item["name"]
            if not isinstance(name, str) or name in self.theorems:
                raise ValueError("duplicate or malformed theorem name")
            left, right = freeze(item["left"]), freeze(item["right"])
            hypotheses = [(freeze(l), freeze(r)) for l, r in item.get("hypotheses", [])]
            for t in [left, right] + [t for p in hypotheses for t in p]:
                declared(t, self.definitions)
            self.proof(item["proof"], left, right, hypotheses)
            self.theorems[name] = (hypotheses, left, right)
            self.proved_names.append(name)
        return {
            "status": "ACCEPT",
            "theorem_count": len(self.theorems),
            "equation_induction_nodes": self.induction_nodes,
            "calculation_nodes": self.calculation_nodes,
            "normalization_and_rewrite_steps": self.reductions,
            "theorems": self.proved_names,
            "scope": "symbolic equational proof certificate; not a complete iPRA proof checker",
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    source = args.certificate.read_bytes()
    data = json.loads(source)
    result = Kernel(data).verify()
    result["certificate_sha256"] = hashlib.sha256(source).hexdigest()
    text = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
