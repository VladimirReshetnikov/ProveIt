#!/usr/bin/env python3
"""Build explicit symbolic certificates for the shifted-unary results."""

import json
from pathlib import Path


def V(name): return ["v", name]
def Z(): return ["0"]
def F(name, argument): return ["F", name, argument]
def K(name, count, seed): return ["K", name, count, seed]
def S(argument): return F("s", argument)
def SS(argument): return S(S(argument))
def numeral(n):
    answer = Z()
    for _ in range(n): answer = S(answer)
    return answer


def AND(b, c):
    return F("delta", F("tau", K("zero", F("delta", b), F("delta", c))))


def OR(b, c):
    return F("delta", AND(F("delta", b), F("delta", c)))


u, n, x, c, d = map(V, ("u", "n", "x", "c", "d"))
definitions = [
    {"name": "id", "body": u},
    {"name": "zero", "body": Z()},
    {"name": "s", "body": K("id", Z(), u)},
    {"name": "delta", "body": K("zero", u, Z())},
    {"name": "parity", "body": K("delta", u, Z())},
    {"name": "step", "body": K("zero", F("parity", u), numeral(1))},
    {"name": "transient", "body": K("step", u, Z())},
    {"name": "low", "body": F("delta", F("delta", F("transient", u)))},
    {"name": "turn", "body": K("step", F("low", u), u)},
    {"name": "tau", "body": K("turn", u, Z())},
    {"name": "f", "schematic": True},
    {"name": "conj", "body": F("tau", F("f", F("tau", u)))},
    {"name": "J", "body": F("tau", K("conj", u, Z()))},
    {"name": "conj_s", "body": F("tau", S(F("tau", u)))},
    {"name": "J_s", "body": F("tau", K("conj_s", u, Z()))},
    {"name": "conj_delta", "body": F("tau", F("delta", F("tau", u)))},
    {"name": "N", "body": F("tau", K("conj_delta", u, Z()))},
    {"name": "j", "body": K("zero", AND(F("delta", F("N", u)),
                                            F("delta", F("delta", u))), u)},
    {"name": "conj_j", "body": F("tau", F("j", F("tau", u)))},
    {"name": "M", "body": F("tau", K("conj_j", u, Z()))},
    {"name": "h4", "body": K("zero", AND(F("N", u), F("delta", F("M", u))), u)},
    {"name": "conj_h4", "body": F("tau", F("h4", F("tau", u)))},
    {"name": "M4", "body": F("tau", K("conj_h4", u, Z()))},
    {"name": "prefix_b", "body": OR(F("delta", F("M4", u)),
                                      F("delta", F("M4", S(u))))},
    {"name": "prefix_h", "body": K("zero", F("prefix_b", u), u)},
    {"name": "prefix_W", "body": K("prefix_h", u, Z())},
    {"name": "prefix_c", "body": K("zero", F("delta", F("prefix_W", u)),
                                     F("delta", F("M4", S(F("prefix_W", u)))))},
    {"name": "patch", "body": K("delta", F("prefix_c", u), F("f", u))},
]
theorems = []


def fact(name, **substitution):
    return {"theorem": name, "substitution": substitution}


def hyp(index): return {"hypothesis": index}
def calc(*facts): return {"rule": "calculation", "facts": list(facts)}
def ind(variable, base, step):
    return {"rule": "equation_induction", "variable": variable, "base": base, "step": step}


def claim(name, left, right, proof=None, hypotheses=()):
    item = {"name": name, "left": left, "right": right, "proof": proof or calc()}
    if hypotheses: item["hypotheses"] = list(hypotheses)
    theorems.append(item)


claim("delta_zero", F("delta", Z()), numeral(1))
claim("delta_successor", F("delta", S(n)), Z())
for i, value in enumerate((1, 0, 1)):
    claim("parity_" + str(i), F("parity", numeral(i)), numeral(value))
for i, value in enumerate((0, 2, 0)):
    claim("step_" + str(i), F("step", numeral(i)), numeral(value))
for i, value in enumerate((1, 2)):
    claim("transient_" + str(i), F("transient", numeral(i)), numeral(value))
claim("transient_tail", F("transient", SS(n)), Z(), ind("n", calc(), calc(hyp(0))))
for i in (0, 1):
    claim("low_" + str(i), F("low", numeral(i)), numeral(1))
claim("low_tail", F("low", SS(n)), Z(), calc(fact("transient_tail")))
for i, value in enumerate((2, 0)):
    claim("turn_" + str(i), F("turn", numeral(i)), numeral(value))
claim("turn_tail", F("turn", SS(n)), S(SS(n)), calc(fact("low_tail")))
for i, value in enumerate((1, 0)):
    claim("tau_" + str(i), F("tau", numeral(i)), numeral(value))
claim("tau_tail", F("tau", SS(n)), SS(n),
      ind("n", calc(), calc(hyp(0), fact("turn_tail"))))
claim("involution_successor", F("tau", F("tau", S(n))), S(n),
      ind("n", calc(), calc(fact("tau_tail"))))
claim("involution", F("tau", F("tau", n)), n,
      ind("n", calc(), calc(fact("involution_successor"))))
claim("J_zero", F("J", Z()), Z())
claim("J_successor", F("J", S(n)), F("f", F("J", n)),
      calc(fact("involution", n=F("f", F("J", n)))))
claim("J_s_zero", F("J_s", Z()), Z())
claim("J_s_successor", F("J_s", S(n)), S(F("J_s", n)),
      calc(fact("involution", n=S(F("J_s", n)))))
claim("identity_clock", F("J_s", n), n,
      ind("n", calc(), calc(fact("J_s_successor"), hyp(0))))
claim("equal_shifted_seeds", K("f", n, c), K("f", n, d),
      ind("n", calc(hyp(0)), calc(hyp(1))), hypotheses=((S(c), S(d)),))
claim("zero_shifted_seed", K("f", n, c), F("J", n),
      ind("n", calc(hyp(0)), calc(fact("J_successor"), hyp(1))),
      hypotheses=((S(c), Z()),))

for i, value in enumerate((0, 2, 3, 0)):
    claim("prefix_h_" + str(i), F("prefix_h", numeral(i)), numeral(value))
for i, value in enumerate((1, 2, 3)):
    claim("prefix_W_" + str(i), F("prefix_W", numeral(i)), numeral(value))
claim("prefix_W_tail", F("prefix_W", S(SS(n))), Z(),
      ind("n", calc(), calc(hyp(0))))
for i, value in enumerate((1, 1, 2)):
    claim("prefix_c_" + str(i), F("prefix_c", numeral(i)), numeral(value))
claim("prefix_c_tail", F("prefix_c", S(SS(n))), Z(), calc(fact("prefix_W_tail")))
for i, value in enumerate((0, 0, 1)):
    claim("patch_" + str(i), F("patch", numeral(i)), numeral(value))
claim("patch_tail", F("patch", S(SS(n))), S(F("f", S(SS(n)))),
      calc(fact("prefix_c_tail")))


target = Path(__file__).with_name("equational_certificates.json")
target.write_text(json.dumps({"format": "shifted-unary-equations-v1",
                              "definitions": definitions, "theorems": theorems}, indent=2) + "\n")
print(target)
