#!/usr/bin/env python3
"""Positive and negative checks for the symbolic certificate verifier."""

import copy
import json
from pathlib import Path

from verify_equations import Kernel


HERE = Path(__file__).resolve().parent
original = json.loads((HERE / "equational_certificates.json").read_text())


def theorem(data, name):
    return next(t for t in data["theorems"] if t["name"] == name)


def definition(data, name):
    return next(t for t in data["definitions"] if t["name"] == name)


def set_bad_tau_zero(data):
    theorem(data, "tau_0")["right"] = ["0"]


def set_bad_transient_tail(data):
    theorem(data, "transient_tail")["right"] = ["F", "s", ["0"]]


def remove_tail_induction_hypothesis(data):
    theorem(data, "tau_tail")["proof"]["step"]["facts"] = [
        {"theorem": "turn_tail", "substitution": {}}]


def alter_zero_iteration_step(data):
    theorem(data, "J_successor")["right"] = ["F", "f", ["v", "n"]]


def capture_external_update_parameter(data):
    definition(data, "turn")["body"] = ["K", "step", ["F", "low", ["v", "u"]], ["v", "external"]]


def insert_forward_update_reference(data):
    definition(data, "delta")["body"] = ["K", "tau", ["v", "u"], ["0"]]


def alter_identity_update(data):
    definition(data, "id")["body"] = ["0"]


def reference_unproved_theorem(data):
    theorem(data, "J_successor")["proof"]["facts"][0]["theorem"] = "arbitrary_initializer"


def violate_induction_freshness(data):
    theorem(data, "equal_shifted_seeds")["hypotheses"] = [[["v", "n"], ["0"]]]


def omit_fixed_seed_assumption(data):
    theorem(data, "equal_shifted_seeds")["hypotheses"] = []


def use_conditional_theorem_without_assumption(data):
    data["theorems"].append({
        "name": "forged_seed_equality",
        "left": ["K", "f", ["v", "n"], ["v", "c"]],
        "right": ["K", "f", ["v", "n"], ["v", "d"]],
        "proof": {"rule": "calculation", "facts": [
            {"theorem": "equal_shifted_seeds", "substitution": {}}]},
    })


def insert_compound_induction_matrix(data):
    theorem(data, "involution")["left"] = ["or", ["0"], ["0"]]


def alter_prefix_value(data):
    theorem(data, "prefix_c_2")["right"] = ["F", "s", ["0"]]


def omit_patch_successor(data):
    theorem(data, "patch_tail")["right"] = ["F", "f", ["F", "s", ["F", "s", ["F", "s", ["v", "n"]]]]]


mutations = [
    set_bad_tau_zero,
    set_bad_transient_tail,
    remove_tail_induction_hypothesis,
    alter_zero_iteration_step,
    capture_external_update_parameter,
    insert_forward_update_reference,
    alter_identity_update,
    reference_unproved_theorem,
    violate_induction_freshness,
    omit_fixed_seed_assumption,
    use_conditional_theorem_without_assumption,
    insert_compound_induction_matrix,
    alter_prefix_value,
    omit_patch_successor,
]

positive = Kernel(original).verify()
negative_results = []
for mutation in mutations:
    data = copy.deepcopy(original)
    mutation(data)
    try:
        Kernel(data).verify()
    except (ValueError, KeyError, IndexError, TypeError) as error:
        negative_results.append({"mutation": mutation.__name__, "status": "REJECT",
                                 "reason": str(error)})
    else:
        raise AssertionError("damaged certificate accepted: " + mutation.__name__)

result = {
    "positive_status": positive["status"],
    "verified_theorems": positive["theorem_count"],
    "negative_tests": negative_results,
    "negative_test_count": len(negative_results),
    "scope": "regression checks; mathematical soundness still rests on the documented kernel rules",
}
(HERE / "certificate_tests.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
