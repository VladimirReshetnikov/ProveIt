#!/usr/bin/env python3
"""Reproduce whole-program metrics for the 16 complete current comparators."""
import importlib.util
import json
from pathlib import Path
import platform

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("inherited_measure", ROOT / "reference/source_measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
manifest = json.loads((ROOT / "reference/checker_manifest.json").read_text())
rows = []
for entry in manifest["programs"]:
    observed = measure.metrics(ROOT / entry["local_file"])
    if observed["sha256"] != entry["sha256"]:
        raise ValueError("Comparator bytes changed: " + entry["name"])
    rows.append({"name": entry["name"], "family": entry["family"], **observed})
fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
envelope = {key: min(row[key] for row in rows) for key in fields}
pareto = [row["name"] for row in rows if not any(
    all(other[key] <= row[key] for key in fields)
    and any(other[key] < row[key] for key in fields)
    for other in rows)]
result = {"commit": manifest["commit"], "python": platform.python_version(),
          "whole_current_envelope": envelope, "pareto": pareto,
          "program_count": len(rows), "programs": rows,
          "scope": "Complete comparator source metrics; no claim about the specialized research verifiers."}
(ROOT / "evidence/frontier.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "programs"}, indent=2))
