# Provenance and scope

## Repository review

Source directory: https://github.com/VladimirReshetnikov/ProveIt/tree/main/docs/drafts (main branch, inspected 25 November 2026 through the GitHub connector). The directory listing contains many ZIP archives. Selected archives were fetched as base64 and their TeX abstracts/opening sections or README files decoded for comparison; the complete contents of every archive were not reviewed. The following are the most relevant identified entries, with their directory-listing Git blob IDs:

| Archive | Blob SHA |
|---|---|
| union_closed_joint_laws_2026-11-25.zip | c497e7f366a6c29bd2002919c0a5e497d6359133 |
| union_closed_deletion_repair_2026-11-25.zip | 91723c866b8a7e50af44cb3ac3682a243fab2108 |
| union_closed_exchange_repair_2026-11-25.zip | 4ef1a0516b8e0ed44973ab44440aac0501042fc9 |
| union_closed_redundant_core_2026-11-25.zip | 18cd1e26f63dee50486533964e3fbf085660af09 |
| union_closed_signature_interfaces_2026-11-25.zip | 7d715274e013371d5d4156b461f970c50c1f9c00 |
| union_closed_uniform_threshold_2026-11-25.zip | 14fa30e81e9018fbf4664e4c6a4927f74ef8940a |
| union_closed_rank_transport_2026-11-25.zip | f4c375d5ae9b7337ed4e542950da3d602be537be |
| union_closed_exact_obstruction_theorems_2026-11-25.zip | a43404f7da75f9466787900b24363f9959c0f49c |
| union_closed_sharp_trace_obstructions_2026-11-25.zip | bef1e8104a5bc31e1246f27867e88a73441a4423 |
| union_closed_dense_core_2026-11-25.zip | b1c269b2ae1cdb03f91797a2bf840e96730c5934 |
| union_closed_antichain_shadows_2026-11-25.zip | ce0aa9b6412a1196261afacbb8deb9954fb7ead7 |
| union_closed_transversal_bounds.zip | d3174ec7be90f4735bd7e597a844065cdc70101c |
| union_closed_abundance_theorems.zip | e223bbd38fd1b46c1e790a61380532fa772c3395 |
| union_closed_local_abundance.zip | cc4298e4a6199e5781de56cd7c363d4576ca8c4d |
| union_closed_frequency_bounds.zip | 2c2534514f2afd2fead5cbbc22c2ffea3962ccc9 |

The structural-theorems archive was also requested, but no TeX abstract was recovered by the targeted extraction. It was not counted as inspected content. The dual incidence-support bijection is known from the earlier drafts and is not a novelty claim. The rank-transport and obstruction notes concern different approaches. Particularly close comparisons are the joint-laws, deletion-repair, exchange-repair, redundant-core, and signature-interfaces drafts, discussed in Section 6 of the manuscript. The exchange-repair condition allows nonsymmetric additional supports and is not subsumed by the present theorem.

## Public sources

- https://en.wikipedia.org/wiki/Union-closed_sets_conjecture — problem statement and background (correctly exclude the family consisting only of the empty set).
- https://arxiv.org/abs/2211.09055 — Gilmer's first positive constant bound, cited in the earlier drafts.
- https://zenodo.org/records/22727713 — Costa and Sadhu, 2026, reported lower bound 0.3828852549667978.
- https://quantavane.com/major-results/union-closed-sets-conjecture/ — November 2026 website report of a computer-assisted lower bound 0.38317525996679...; not independently checked here.
- https://doi.org/10.1016/j.ejc.2014.08.030 — Bruhn, Charbit, Schaudt, Telle, graph formulation of Frankl's conjecture. The graph-support setting in the present note is a dual generator-incidence model; it is not the same as the general maximal-independent-set formulation.

Searches included combinations of “union closed sets conjecture”, “generator incidence hypergraph”, “twin vertices”, “blow up”, “interchangeable”, “symmetry”, “induced subgraphs no isolated vertices”, and “frequency”. The search was selective, not a comprehensive priority search. It did not reveal the exact capped-profile domination and sharp joint limiting law. Classical binomial counts, permutation coupling, and join-irreducibility are standard tools. The specific combined theorem and exterior forcing sharpness are proposed original results; publication priority remains uncertain.

## Verification and decisions

The choice of a structural rather than an unrestricted entropy bound was made during the investigation. The complete proof is elementary; the Python checks audit finite instances only. No Lean/Rocq proof is supplied, and no independent reviewer has validated the result. The repo was read, not modified. Direct network retrieval from the working container was unavailable; the connector provided the selected ZIP contents.
