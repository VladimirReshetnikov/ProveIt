#!/usr/bin/env python3
"""Exact finite audits of the capped-profile theorem. Python 3.10+, stdlib only."""
from collections import defaultdict
from fractions import Fraction
from itertools import combinations, product
from math import comb, prod
import random


def check(ok, message):
    if not ok:
        raise AssertionError(message)


def bits(s):
    return s.bit_count()


def subsets(mask):
    s = mask
    while True:
        yield s
        if not s:
            return
        s = (s-1) & mask


def joins(edges):
    out = {0}
    for e in edges:
        out |= {s | e for s in out}
    return out


def union_all(edges):
    ans = 0
    for e in edges:
        ans |= e
    return ans


def basis(edges):
    return {e for e in edges if union_all(f for f in edges if f != e and f & e == f) != e}


def original_unions(edges, n):
    # Independent construction in the ORIGINAL universe of labelled supports.
    return joins([sum(1 << j for j, e in enumerate(edges) if e >> i & 1) for i in range(n)])


def tail(b, t):
    return sum(comb(b, j) for j in range(max(0, t), b+1))


def ratio(b, t, k):
    return Fraction(tail(b-k, t-k), tail(b, t))


def block_masks(sizes):
    blocks = []
    off = 0
    for b in sizes:
        blocks.append(((1 << b)-1) << off)
        off += b
    return blocks, off


def orbits(sizes, ext):
    blocks, off = block_masks(sizes)
    groups = defaultdict(set)
    for e in range(1, 1 << (off+ext)):
        profile = (tuple(bits(e & b) for b in blocks), e >> off)
        groups[profile].add(e)
    return list(groups.values())


def audit(edges, sizes, ext):
    blocks, off = block_masks(sizes)
    n = off+ext
    H = set(edges)
    if not H or any(not (union_all(H) & b) for b in blocks):
        return False
    J = basis(H)
    S = joins(H)
    check(joins(J) == S, 'basis')
    # Compare original uniform distinct unions and dual canonical subsets.
    marks = sorted(H)
    F = original_unions(marks, n)
    recovered = {sum(1 << j for j,e in enumerate(marks) if e & s != e) for s in S}
    check(F == recovered and len(F) == len(S), 'dual bijection')
    ranks = tuple(max(bits(e & b) for e in J) for b in blocks)
    check(all(r > 0 for r in ranks), 'active block')
    check(all(not (J & orb) or orb <= J for orb in orbits(sizes, ext)), 'basis invariance')
    # Independently predict the orbit-capped cells using the edge patterns.
    prof = lambda s: (s >> off, tuple(min(bits(s & b), t) for b,t in zip(blocks,ranks)))
    cells = defaultdict(set)
    for s in range(1 << n):
        cells[prof(s)].add(s)
    profiles = {(e >> off, tuple(bits(e & b) for b in blocks)) for e in J}
    predicted = 0
    for (R,c), cell in cells.items():
        fitting = [(D,a) for D,a in profiles if D & R == D and all(x<=y for x,y in zip(a,c))]
        feasible = (union_all(D for D,a in fitting) == R and
                    all(not v or any(a[i] for D,a in fitting) for i,v in enumerate(c)))
        check((cell <= S) if feasible else not (cell & S), 'capped-cell feasibility')
        ways = prod(comb(b,v) if v<t else tail(b,t) for b,t,v in zip(sizes,ranks,c))
        check(ways == len(cell), 'cell product count')
        predicted += ways if feasible else 0
    check(predicted == len(S), 'compressed exact count')
    by_ext = defaultdict(list)
    for s in S:
        by_ext[s >> off].append(s)
    for R, fiber in by_ext.items():
        # Check global and effective exterior-conditioned thresholds for every
        # containment event, not just the events corresponding to actual marks.
        allowed = [e for e in J if (e >> off) & R == e >> off]
        eff = tuple(max((bits(e & b) for e in allowed), default=0) for b in blocks)
        for m in range(1 << off):
            p = Fraction(sum(s & m == m for s in fiber), len(fiber))
            hi = prod(ratio(b,t,bits(m & B)) for b,t,B in zip(sizes,ranks,blocks))
            local = prod((ratio(b,t,bits(m & B)) if t else int(not (m & B)))
                         for b,t,B in zip(sizes,eff,blocks))
            check(p <= local <= hi, 'conditional containment bound')
    for e in H:
        p = Fraction(sum(s & e == e for s in S),len(S))
        hi = prod(ratio(b,t,bits(e & B)) for b,t,B in zip(sizes,ranks,blocks))
        check(p <= hi * Fraction(len(S)-1,len(S)), 'finite size correction')
    return True


def forcing_edges(sizes, ts, ks, L):
    blocks, off = block_masks(sizes)
    choices = [list(subsets(B)) for B in blocks]
    E = {union_all(es) for kk in (ks,tuple(min(k,t) for k,t in zip(ks,ts)))
         for es in product(*[[s for s in C if bits(s)==k] for C,k in zip(choices,kk)])}
    for i, (C,t) in enumerate(zip(choices,ts)):
        for j in range(L):
            E.update(s | (1 << (off+i*L+j)) for s in C if bits(s)==t)
    mark = union_all(next(s for s in C if bits(s)==k) for C,k in zip(choices,ks))
    return E,mark,off+len(sizes)*L


def forcing_counts(sizes, ts, ks, L):
    # Independent profile count; marks use the capped orbit for coverage.
    caps=tuple(min(k,t) for k,t in zip(ks,ts))
    N = A = 0
    for a in product(*(range(b+1) for b in sizes)):
        marked_available = all(v>=k for v,k in zip(a,caps))
        ways = 1
        for v,t in zip(a,ts):
            if v == 0:
                continue
            if v < t:
                if not marked_available:
                    ways = 0
                    break
            else:
                ways *= (1 << L) if marked_available else (1 << L)-1
        N += ways*prod(comb(b,v) for b,v in zip(sizes,a))
        if all(v>=k for v,k in zip(a,ks)):
            A += ways*prod(comb(b-k,v-k) for b,k,v in zip(sizes,ks,a))
    return N,A


def main():
    print('Exact finite verification (all comparisons use integers/Fraction)')
    total = 0
    for sizes, ext in [((2,2),0),((2,),2),((3,),1),((2,1),1)]:
        O = orbits(sizes,ext)
        passed = 0
        for mask in range(1,1<<len(O)):
            H = set().union(*(O[j] for j in range(len(O)) if mask>>j&1))
            passed += audit(H,sizes,ext)
        print(f'exhaustive orbit systems: blocks={sizes}, exterior={ext}, audited={passed}')
        total += passed
    rng = random.Random(20261125)
    count=0
    for sizes,ext in [((3,2),1),((2,2),2),((3,3),1),((4,),2)]:
        O=orbits(sizes,ext)
        for _ in range(150):
            H=set().union(*(orb for orb in O if rng.random()<0.30))
            count += audit(H,sizes,ext)
    print('random orbit systems audited:',count)
    total += count
    # Symmetric basis with asymmetric redundant marks: test separately.
    H={3,5,9,6,10,12,7,15}
    check(basis(H)=={3,5,9,6,10,12},'asymmetric redundancy example')
    check(audit(H,(4,),0),'asymmetric basis example')
    print('asymmetric redundant-mark example: passed')
    # Binomial inequality; sequential factor bound, checked for many parameters.
    nbin=0
    for b in range(1,101):
        for t in range(1,b//2+1):
            for k in range(1,b+1):
                check(ratio(b,t,k) <= Fraction(2,3)**k,'2/3 bound')
                nbin+=1
    print('binomial inequalities audited:',nbin)
    print('sharpness: size, ranks, mark counts, L, |F|, frequency, limiting frequency')
    for sizes,ts,ks in [((2,2),(1,1),(1,1)),((3,3),(1,1),(1,1)),
                         ((4,),(2,),(2,)),((3,4),(2,2),(1,2)),((3,),(3,),(1,)),((4,),(2,),(4,)),((3,4),(1,2),(2,3))]:
        hi=prod(ratio(b,t,k) for b,t,k in zip(sizes,ts,ks))
        for L in (1,2,4,8,16,32):
            N,A=forcing_counts(sizes,ts,ks,L)
            if sum(sizes)+len(sizes)*L <= 15:
                H,e,n=forcing_edges(sizes,ts,ks,L)
                S=joins(H)
                check((N,A)==(len(S),sum(s&e==e for s in S)),'forcing count')
                check(tuple(max(bits(e&B) for e in basis(H)) for B in block_masks(sizes)[0])==ts,'forcing rank')
            good=prod(tail(b,t) for b,t in zip(sizes,ts))*((1<<L)-1)**len(sizes)
            check(Fraction(A,N)<=hi*Fraction(N-1,N),'sharpness bound')
            check(abs(Fraction(A,N)-hi)<=1-Fraction(good,N),'sharpness TV bound')
            if L in (1,4,16,32):
                print(f' {sizes} {ts} {ks} {L:2d} {N} {float(1-Fraction(A,N)):.12f} {float(1-hi):.12f}')
    print('total orbit systems audited:',total)
    print('All exact checks passed.')

if __name__ == '__main__':
    main()
