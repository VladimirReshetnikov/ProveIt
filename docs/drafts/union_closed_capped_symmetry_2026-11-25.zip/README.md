# Capped symmetry profiles and sharp abundance in union-closed families

Research note, 25 November 2026. Start with `paper.pdf`.

## Contents

- `paper.tex`: self-contained mathematical manuscript, with proofs and references.
- `paper.pdf`: compiled manuscript (9 pages).
- `verify.py`: dependency-free Python 3.10+ exact finite checks.
- `verification.txt`: output of the actual verifier run.
- `provenance.md`: repository review, sources, and limits on novelty claims.
- `Makefile`: reproducible build and verification commands.
- `SHA256SUMS`: integrity manifest for the preceding files.

## Main contribution

For a dual support hypergraph with independently interchangeable blocks of generator indices, every feasible capped count profile is a product of exact-size layers and upper binomial tails. Consequently the canonical omitted-index set is stochastically dominated, even after exterior conditioning, by independent uniform subsets above the intrinsic rank thresholds. This yields an explicit strict frequency bound for every marked element. An exterior forcing construction realizes the extremal joint law in the limit, even with redundant marked supports exceeding the intrinsic ranks and in connected systems. In particular, if every marked block has size at least twice its rank and a support contains at least two core indices, its original element occurs in strictly more than 5/9 of the sets.

The mathematical proofs do not depend on the finite tests. The full conjecture remains open in this work. No new universal numerical constant, formal proof-assistant verification, or established historical priority is claimed. No GitHub changes were made.

## Reproduce

```
sha256sum -c SHA256SUMS
python3 verify.py
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
pdflatex -interaction=nonstopmode -halt-on-error paper.tex
```

All mathematical comparisons in the verifier are integer or exact `Fraction` comparisons. Displayed decimal numbers are for reading only. Recompiling the PDF may change metadata and its checksum.
