#!/usr/bin/env python3
"""Exact examples and witnesses for the six-coatom results; standard library."""
from itertools import combinations
from pathlib import Path
import json


def closed(family):
    return all(a|b in family for a,b in combinations(family,2))


def make_family(width, include_empty=True):
    local_top=63
    outside_top=((1<<(6*width))-1)<<6
    coatoms={63^(1<<i) for i in range(6)}
    bottom=coatoms|{63}
    if include_empty:
        bottom.add(0)
    family=set(bottom)|{outside_top|r for r in range(64)}
    for i in range(6):
        j=63^(1<<i)
        fibre={r for r in range(64) if r&j==r}|coatoms|{63}
        full=(1<<width)-1
        block=full<<(6+i*width)
        for c in range(full):
            b=(outside_top^block)|(c<<(6+i*width))
            family.update(b|r for r in fibre)
    return family


def main():
    records=[]
    for width in (1,2,3):
        for include_empty in (True,False):
            family=make_family(width,include_empty)
            assert closed(family)
            t=(1<<width)-1
            n=len(family)
            degrees=[sum(bool(a&(1<<x)) for a in family) for x in range(6+6*width)]
            assert n==228*t+(72 if include_empty else 71)
            assert degrees[:6]==[111*t+38]*6
            expected=190*t+38*(1<<(width-1))+26
            assert degrees[6:]==[expected]*(6*width)
            excess=228*max(degrees[:6])-111*n
            assert excess==(672 if include_empty else 783)
            record=dict(block_width=width,empty_set=include_empty,
                        members=n,t=t,local_degree=degrees[0],
                        outside_degree=expected,excess=excess,
                        unordered_distinct_pairs_checked=n*(n-1)//2,
                        all_unions_pass=True)
            records.append(record)
            print(json.dumps(record))
    # Witnesses for the two sharp positive-fibre assertions.
    coatoms={63^(1<<i) for i in range(6)}
    q4={r for r in range(64) if r&15==r}|coatoms|{63}
    score=lambda h:38*sum(r.bit_count() for r in h)-111*len(h)
    assert closed(q4) and score(q4)==31 and len(q4)==23
    q0={r for r in range(64) if r&62==r}|coatoms|{63}
    h=q0|{15}
    assert closed(h) and score(h)==41
    L=38*sum(bool(r&1) for r in h)-21*len(h)
    assert L==-553
    records.append(dict(witness='positive_score_gap',family=sorted(q4),score=31))
    records.append(dict(witness='coordinate_coefficient',family=sorted(h),
                        score=41,L=-553,coefficient='553/41'))
    out=Path(__file__).resolve().parent.parent/'data'/'construction_checks.json'
    out.write_text(json.dumps(records,indent=2)+'\n')


if __name__=='__main__':
    main()
