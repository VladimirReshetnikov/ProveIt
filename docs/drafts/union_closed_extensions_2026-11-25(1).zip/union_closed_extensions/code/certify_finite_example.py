#!/usr/bin/env python3
"""Directed rational enclosures for the stated finite six-point example."""
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt
from pathlib import Path
import json


@lru_cache(None)
def ln_unit(y):
    assert 1<=y<=2
    z=(y-1)/(y+1)
    lower=2*sum((z**(2*j+1)/F(2*j+1) for j in range(24)),F(0))
    error=2*z**49/(49*(1-z*z))
    return lower,lower+error


def ln_interval(x):
    x=F(x);assert x>0
    shift=0
    while x<1:x*=2;shift-=1
    while x>2:x/=2;shift+=1
    lo,hi=ln_unit(x);a,b=ln_unit(F(2))
    return (lo+shift*a,hi+shift*b) if shift>=0 else (lo+shift*b,hi+shift*a)


def enclosing_decimal(lo,hi,places=15):
    d=10**places
    a=(lo.numerator*d)//lo.denominator
    b=-((-hi.numerator*d)//hi.denominator)
    def fmt(v):return f'{v//d}.{v%d:0{places}d}'
    return [fmt(a),fmt(b)]


def main():
    n=10**6;e=10**4
    r=F(5,6)*(1-F(3359*e,615*n))**2
    d=10**60;s=isqrt(5*d*d)
    pl,ph=(F(s,d)-1)/2,(F(s+1,d)-1)/2
    l2,u2=ln_interval(2);ln,un=ln_interval(n)
    ld,ud=ln_interval(F(n,64))
    rows=[]
    for bottom in (0,480):
        lr,ur=ln_interval(F(192*n,e-bottom))
        a,b=l2+ln-r*ur,u2+un-r*lr
        assert 0<a<=b and ld>0
        lo,hi=1-ph*b/ld,1-pl*a/ud
        assert lo>F(5415,10000)
        if bottom:assert lo>F(5439,10000)
        record=dict(N=n,E_upper=e,bottom_score_subtracted=bottom,
                    rho_lower=str(r),outside_bound=enclosing_decimal(lo,hi),
                    arithmetic='exact rational intervals',certified=True)
        print(json.dumps(record));rows.append(record)
    (Path(__file__).resolve().parent.parent/'data'/'finite_example.json').write_text(
        json.dumps(rows,indent=2)+'\n')


if __name__=='__main__':main()
