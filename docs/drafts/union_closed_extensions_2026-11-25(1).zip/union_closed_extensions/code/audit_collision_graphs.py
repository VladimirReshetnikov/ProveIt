#!/usr/bin/env python3
"""Independent exact audit via positive-support graphs, not full bases.

Vertices of {x >= 0: unsigned_incidence*x=d} have connected support
components that are trees or odd unicyclic graphs.  Enumerate every support
with at most n edges, peel leaves, and solve the remaining odd cycles.
All arithmetic involving weights and objectives uses fractions.Fraction.
"""
from collections import deque
from fractions import Fraction as F
from itertools import combinations
import json
from pathlib import Path


def solve_support(n, edges, degrees):
    adj = [set() for _ in range(n)]
    for j, (u, v) in enumerate(edges):
        adj[u].add(j)
        adj[v].add(j)
    if any(not a for a in adj):
        return None
    rem = list(degrees)
    weights = [None] * len(edges)
    queue = deque(v for v in range(n) if len(adj[v]) == 1)
    while queue:
        v = queue.popleft()
        if len(adj[v]) != 1:
            continue
        e = next(iter(adj[v]))
        u = edges[e][0] + edges[e][1] - v
        w = rem[v]
        if w <= 0:
            return None
        weights[e] = w
        rem[u] -= w
        rem[v] = F(0)
        adj[v].remove(e)
        adj[u].remove(e)
        if len(adj[u]) == 1:
            queue.append(u)
    if any(len(adj[v]) == 0 and rem[v] != 0 for v in range(n)):
        return None
    if any(len(a) not in (0, 2) for a in adj):
        return None
    while any(adj):
        start = next(v for v in range(n) if adj[v])
        vertices, cycle_edges = [start], []
        v, prev = start, None
        while True:
            e = next(e for e in adj[v] if e != prev)
            u = edges[e][0] + edges[e][1] - v
            cycle_edges.append(e)
            if u == start:
                break
            vertices.append(u)
            prev, v = e, u
        if len(vertices) % 2 == 0:
            return None
        w0 = (rem[vertices[0]] + sum(
            (1 if j % 2 else -1) * rem[vertices[j]]
            for j in range(1, len(vertices)))) / 2
        ws = [w0]
        for j in range(1, len(vertices)):
            ws.append(rem[vertices[j]] - ws[-1])
        if any(w <= 0 for w in ws) or ws[-1] + ws[0] != rem[start]:
            return None
        for e, w in zip(cycle_edges, ws):
            weights[e] = w
            u, v = edges[e]
            adj[u].remove(e)
            adj[v].remove(e)
    assert all(w is not None and w > 0 for w in weights)
    assert all(sum(weights[e] for e, uv in enumerate(edges) if v in uv) == degrees[v]
               for v in range(n))
    return weights


def audit(case, degrees):
    n = len(degrees)
    all_edges = list(combinations(range(n), 2))
    count, best, maximizers = 0, F(-1), []
    for k in range(1, n + 1):
        for support in combinations(all_edges, k):
            weights = solve_support(n, support, degrees)
            if weights is None:
                continue
            count += 1
            value = sum(w*w for w in weights)
            if value > best:
                best, maximizers = value, []
            if value == best:
                maximizers.append([[list(e), str(w)] for e, w in zip(support, weights)])
    return dict(case=case, degrees=list(map(str,degrees)), vertices=count,
                collision_max=str(best), rho=str(1-best),
                maximizer_count=len(maximizers), witness=maximizers[0])


def main():
    cases = [('5,2', [F(1,4)]*2+[F(1,2)]*3),
             ('6,2', [F(1,4)]*2+[F(3,8)]*4),
             ('6,3', [F(13,48)]*3+[F(19,48)]*3),
             ('6,4', [F(7,24)]*4+[F(5,12)]*2),
             ('6,5', [F(5,16)]*5+[F(7,16)])]
    result = [audit(case, d) for case, d in cases]
    expected = {'5,2':'3/8','6,2':'11/32','6,3':'9/32',
                '6,4':'11/32','6,5':'17/64'}
    for row in result:
        assert row['collision_max'] == expected[row['case']], row
    target = Path(__file__).resolve().parent.parent/'data'/'collision_graph_audit.json'
    target.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
