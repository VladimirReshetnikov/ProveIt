#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <set>
#include <vector>
using Mask=std::uint64_t;
int main(){
 const int n=6;std::array<std::pair<int,int>,15> edges;int ei=0;
 for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)edges[ei++]={i,j};
 std::array<Mask,6> containing{};
 for(int r=0;r<64;r++)for(int i=0;i<n;i++)if(r&(1<<i))containing[i]|=(Mask(1)<<r);
 std::set<Mask> zeros, expected;
 for(int omit=0;omit<n;omit++){
  Mask q=0;for(int r=0;r<64;r++)if(!(r&(1<<omit))||std::popcount((unsigned)r)>=5)q|=Mask(1)<<r;
  expected.insert(q);
 }
 std::uint64_t leaves=0;int minimum=999999,minpos=999999,minratioNumer=0,minratioDenom=1,wcoord=-1;
 Mask witness=0,minposw=0;std::uint64_t failures=0;
 for(int eg=0;eg<(1<<15);eg++){
  std::array<int,6> adjacency{};
  for(int e=0;e<15;e++)if(eg&(1<<e)){
   auto [i,j]=edges[e];adjacency[i]|=1<<j;adjacency[j]|=1<<i;
  }
  std::array<int,64> isolated{};
  for(int r=1;r<64;r++)for(int i=0;i<6;i++)if((r&(1<<i))&&!(adjacency[i]&r))isolated[r]|=1<<i;
  for(int loops=0;loops<64;loops++){
   Mask generated=0;for(int r=1;r<64;r++)if(!(isolated[r]&~loops))generated|=Mask(1)<<r;
   for(int empty=0;empty<2;empty++){
    Mask smallclosure=generated|Mask(empty);Mask h=smallclosure|(Mask(1)<<63);
    for(int i=0;i<6;i++)if(smallclosure&~containing[i])h|=Mask(1)<<(63^(1<<i));
    int m=std::popcount(h),total=0;std::array<int,6>a{};
    for(int i=0;i<6;i++){a[i]=std::popcount(h&containing[i]);total+=a[i];}
    int s=38*total-111*m;minimum=std::min(minimum,s);leaves++;
    if(s<0)failures++;
    if(!s)zeros.insert(h);
    if(s>0){
     if(s<minpos){minpos=s;minposw=h;}
     for(int i=0;i<6;i++){
      int l=38*a[i]-21*m;
      if(31*l+255*s<0||41*l+553*s<0)failures++;
      if(l*minratioDenom<minratioNumer*s){minratioNumer=l;minratioDenom=s;witness=h;wcoord=i;}
     }
    }
   }
  }
 }
 if(zeros!=expected)failures++;
 std::cout<<"{\n  \"generator_choices\": "<<leaves<<",\n  \"min_score\": "<<minimum<<",\n  \"min_positive_score\": "<<minpos<<",\n  \"zero_fibres\": "<<zeros.size()<<",\n  \"zero_classification_passed\": "<<(zeros==expected?"true":"false")<<",\n  \"min_L_over_S\": ["<<minratioNumer<<","<<minratioDenom<<"],\n  \"min_ratio_witness\": {\"family_bitmask\": \""<<witness<<"\",\"coordinate\": "<<wcoord<<"},\n  \"min_score_witness_bitmask\": \""<<minposw<<"\",\n  \"failures\": "<<failures<<"\n}\n";
 return failures||minpos!=31||leaves!=(1ULL<<22)||zeros.size()!=6;
}
