#!/usr/bin/env python3
"""Exact vertex certificates for the eight local-to-outside entropy bounds.

Python 3.10+, standard library only. Enumerate all invertible bases of the
unsigned vertex-edge incidence matrix. Every vertex of {x>=0: Ax=b}
has independent positive support, which extends to one such basis.
No numerical rank decisions or floating-point comparisons are used.
"""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json


def solve(A, b):
    n = len(b)
    a = [[F(v) for v in row] + [F(q)] for row, q in zip(A, b)]
    for j in range(n):
        pivot = next((i for i in range(j, n) if a[i][j]), None)
        if pivot is None:
            return None
        a[j], a[pivot] = a[pivot], a[j]
        q = a[j][j]
        a[j] = [v / q for v in a[j]]
        for i in range(n):
            if i != j and a[i][j]:
                q = a[i][j]
                a[i] = [x - q*y for x, y in zip(a[i], a[j])]
    return [row[-1] for row in a]


def certify(n, degrees, expected, expected_vertices):
    edges = list(combinations(range(n), 2))
    vertices = set()
    tried = nonsingular = feasible = 0
    for basis in combinations(range(len(edges)), n):
        tried += 1
        A = [[int(i in edges[e]) for e in basis] for i in range(n)]
        x = solve(A, degrees)
        if x is None:
            continue
        nonsingular += 1
        if min(x) < 0:
            continue
        feasible += 1
        assert all(sum(x[j] for j, e in enumerate(basis) if i in edges[e])
                   == degrees[i] for i in range(n))
        assert sum(x) == 1
        full = [F(0)] * len(edges)
        for e, v in zip(basis, x):
            full[e] = v
        vertices.add(tuple(full))
    optimum = max(sum(v*v for v in x) for x in vertices)
    assert optimum == expected
    assert len(vertices) == expected_vertices
    witness = min(x for x in vertices if sum(v*v for v in x) == optimum)
    return dict(n=n, degrees=list(map(str, degrees)), bases=tried,
                nonsingular_bases=nonsingular, feasible_bases=feasible,
                vertices=len(vertices), maximum_collision=str(optimum),
                rho=str(1-optimum),
                witness=[dict(edge=list(e), weight=str(v))
                         for e, v in zip(edges, witness) if v])


def main():
    rows = [
        ('5,2', 5, [F(1,4)]*2+[F(1,2)]*3, F(3,8), 10),
        ('6,2', 6, [F(1,4)]*2+[F(3,8)]*4, F(11,32), 73),
        ('6,3', 6, [F(13,48)]*3+[F(19,48)]*3, F(9,32), 196),
        ('6,4', 6, [F(7,24)]*4+[F(5,12)]*2, F(11,32), 73),
        ('6,5', 6, [F(5,16)]*5+[F(7,16)], F(17,64), 160),
    ]
    out = []
    for case, n, deg, value, count in rows:
        record = dict(case=case, **certify(n, deg, value, count))
        out.append(record)
        print(case, 'vertices', record['vertices'], 'rho', record['rho'])
    # The remaining moment polytopes are single points; verify the actual
    # fibre matrices, not just the collision arithmetic.
    for n, t, weights, target, expected in [
        (5, 3, [F(40,97)]+[F(19,97)]*3, F(139,291), F(6726,9409)),
        (5, 4, [F(20,113)]*4+[F(33,113)], F(391,791), F(10080,12769)),
        (6, 6, [F(1,6)]*6, F(37,76), F(5,6)),
    ]:
        top = (1<<n)-1
        js = ([(1<<3)-1]+[top^(1<<i) for i in range(3)]
              if (n,t)==(5,3) else [top^(1<<i) for i in range(n)])
        fibres = [{s for s in range(1<<n) if s&j==s}
                  | {top^(1<<i) for i in range(t)} | {top} for j in js]
        A = [[F(sum(bool(s&(1<<i)) for s in h),len(h)) for h in fibres]
             for i in range(n)]
        assert sum(weights)==1
        assert all(sum(w*v for w,v in zip(weights,row))==target for row in A)
        # Certify uniqueness: find one nonsingular square row minor.
        full = [[F(1)]*len(weights)] + A
        assert any(solve([full[i] for i in inds],
                         [F(1) if i==0 else target for i in inds]) == weights
                   for inds in combinations(range(n+1),len(weights)))
        rho = 1-sum(w*w for w in weights)
        assert rho == expected
        record = dict(case=f'{n},{t}', vertices=1, weights=list(map(str,weights)),
                      fibre_sizes=list(map(len,fibres)), rho=str(rho))
        out.append(record)
        print(record['case'], 'unique balanced mixture', 'rho', record['rho'])
    dest=Path(__file__).resolve().parent.parent/'data'/'type_polytopes.json'
    dest.parent.mkdir(exist_ok=True)
    dest.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':
    main()
