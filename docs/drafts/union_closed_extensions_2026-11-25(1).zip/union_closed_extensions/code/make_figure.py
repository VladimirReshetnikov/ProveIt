#!/usr/bin/env python3
"""Optional scientific figure; requires matplotlib. Not part of any proof."""
from pathlib import Path
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent.parent
(root/'figures').mkdir(exist_ok=True)
phi=(math.sqrt(5)-1)/2
gamma=(1+3*math.sqrt(5))/10
eta=(41+117*math.sqrt(5))/380
L=37/76
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
                     'axes.spines.top':False,'axes.spines.right':False,
                     'pdf.fonttype':42,'ps.fonttype':42})
fig,ax=plt.subplots(figsize=(7.4,3.6),layout='constrained')
ax.axvspan(0,gamma,color='#E7F1EE',zorder=0)
ax.plot([0,1],[1-phi/6,1-phi],color='#256D85',lw=2.6,
        label=r'Proved lower bound: $1-\varphi(1+5\delta)/6$')
ax.axhline(.5,color='#995A38',ls='--',lw=1.3,label='Half-frequency threshold')
ax.axhline(L,color='#555F69',ls=':',lw=1.3,label=r'Local benchmark $37/76$')
ax.scatter([gamma,eta],[.5,L],color=['#995A38','#555F69'],s=32,zorder=4)
ax.annotate(r'$\gamma=0.770820\ldots$',xy=(gamma,.5),xytext=(.42,.58),
            arrowprops={'arrowstyle':'-','color':'#995A38'},color='#995A38')
ax.annotate(r'$\eta=0.796368\ldots$',xy=(eta,L),xytext=(.45,.41),
            arrowprops={'arrowstyle':'-','color':'#555F69'},color='#555F69')
ax.text(.03,.535,r'Outside abundance for every fixed $\delta<\gamma$',fontsize=9,color='#236653')
ax.set(xlim=(0,1),ylim=(.35,.94),xlabel=r'Excess exponent $\delta$ in $E\leq N^{\delta+o(1)}$',
       ylabel='Limiting outside frequency')
ax.grid(axis='y',alpha=.17)
ax.legend(loc='upper right',frameon=False,fontsize=9)
fig.savefig(root/'figures'/'six_point_stability.pdf')
fig.savefig(root/'figures'/'six_point_stability.png',dpi=180)
plt.close(fig)
