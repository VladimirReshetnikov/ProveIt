"""Exact certificates for the second-neighborhood generator entropy bound.

Python 3.10+, standard library only.  Run without -O.
No floating-point arithmetic is used in any assertion.
"""
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from math import comb
import json
from pathlib import Path

@lru_cache(None)
def ln_interval(y):
    assert F(1) <= y <= F(2)
    z = (y-1)/(y+1)
    lower = 2*sum((z**(2*j+1)/F(2*j+1) for j in range(12)), F(0))
    error = 2*z**25/(25*(1-z*z))
    return lower, lower+error

@lru_cache(None)
def log2_interval(x):
    x=F(x)
    assert x>0
    shift=0
    while x<1:
        x*=2; shift-=1
    while x>2:
        x/=2; shift+=1
    lo,hi=ln_interval(x)
    l2,u2=ln_interval(F(2))
    return F(shift)+lo/u2, F(shift)+hi/l2

@lru_cache(None)
def entropy_interval(p):
    p=F(p)
    if p==0 or p==1: return F(0),F(0)
    pl,ph=log2_interval(p)
    ql,qh=log2_interval(1-p)
    return -p*ph-(1-p)*qh, -p*pl-(1-p)*ql

def divergence_interval(p,q):
    a,b=log2_interval(p/q)
    c,d=log2_interval((1-p)/(1-q))
    return p*a+(1-p)*c, p*b+(1-p)*d

def posterior_law(r,k,ell,p):
    """Law of nontrivial posterior probabilities; masses sum to <= 1.

    The recurrence records e, the number of preceding neighbors, and
    counts n_j of root blocks having j late positively observed neighbors
    and no earlier active neighbor. Such a block contributes
    1-(1-a)^j to the probability of coverage without the root.
    A block with an earlier active neighbor contributes 1.
    A block with no possible active neighbor contributes 0.
    """
    p=F(p)
    assert r>=2 and k>=1 and ell>=0 and 0<p<1
    M=k*(r-1)
    q=(1-(1-p)**(r-1))**ell
    b=p+(1-p)*q
    a=p/b
    # (earlier-bit count, category, coefficient)
    # category -1 = certainly active; 0 = certainly inactive;
    # category 1 = late with all auxiliary outputs positive.
    neighbor=[(1,0,1-p),(1,-1,p),(0,0,1-b),(0,1,b)]
    block={(0,0):F(1)}
    for _ in range(r-1):
        nxt=defaultdict(F)
        for (e,j),w in block.items():
            for ee,jj,ww in neighbor:
                if ww:
                    nxt[e+ee,-1 if min(j,jj)<0 else j+jj]+=w*ww
        block=nxt
    states={(0,(0,)*(r-1)):F(1)}
    zeros=defaultdict(F)
    for _ in range(k):
        nxt=defaultdict(F)
        nz=defaultdict(F)
        for e,w in zeros.items():
            for (ee,j),ww in block.items(): nz[e+ee]+=w*ww
        for (e,ns),w in states.items():
            for (ee,j),ww in block.items():
                if j==0:
                    nz[e+ee]+=w*ww
                else:
                    nn=list(ns)
                    if j>0: nn[j-1]+=1
                    nxt[e+ee,tuple(nn)]+=w*ww
        states,zeros=nxt,nz
    total=sum((w/F((M+1)*comb(M,e)) for (e,ns),w in states.items()),F(0))
    total+=sum((w/F((M+1)*comb(M,e)) for e,w in zeros.items()),F(0))
    assert total==1
    law=defaultdict(F)
    for (e,ns),w in states.items():
        z=F(1)
        for j,n in enumerate(ns,1): z*=(1-(1-a)**j)**n
        B=p+(1-p)*z
        posterior=p/B
        mass=w*B/F((M+1)*comb(M,e))
        if 0<posterior<1: law[posterior]+=mass
    return dict(law)

def lower_L(r,k,ell,p):
    law=posterior_law(r,k,ell,p)
    conditional_upper=sum((w*entropy_interval(q)[1] for q,w in law.items()),F(0))
    return entropy_interval(p)[0]-conditional_upper

def direct_posterior_law(r,k,ell,p):
    """Independent brute-force Bayesian calculation on a finite rooted tree."""
    M=k*(r-1)
    leaf_count=M*ell*(r-1)
    N=1+M+leaf_count
    weight=[p**j*(1-p)**(N-j) for j in range(N+1)]
    law=defaultdict(F)
    for count in range(M+1):
        order_weight=F(1,(M+1)*comb(M,count))
        for earlier in combinations(range(M),count):
            observations=defaultdict(lambda:[F(0),F(0)])
            for assignment in range(1<<N):
                bits=[(assignment>>j)&1 for j in range(N)]
                root=bits[0]
                neighbors=bits[1:1+M]
                root_full=bool(root or all(any(neighbors[j*(r-1):(j+1)*(r-1)]) for j in range(k)))
                aux=[]
                for j in range(M):
                    vals=[]
                    for t in range(ell):
                        start=1+M+(j*ell+t)*(r-1)
                        vals.append(bool(neighbors[j] or any(bits[start:start+r-1])))
                    aux.append(all(vals))
                key=(root_full,tuple(aux),tuple(neighbors[j] for j in earlier))
                observations[key][root]+=weight[sum(bits)]
            assert sum((sum(masses) for masses in observations.values()),F(0))==1
            for m0,m1 in observations.values():
                if m0 and m1:
                    mass=m0+m1
                    law[m1/mass]+=order_weight*mass
    return dict(law)

def decimal_enclosure(x,den=10**10):
    """An outward rational interval for an exact rational number."""
    lo=(x.numerator*den)//x.denominator
    hi=-((-x.numerator*den)//x.denominator)
    return [f'{lo}/{den}',f'{hi}/{den}']

def certify():
    records=[]
    for r,k,ell,p,target,bad in [
        (3,4,3,F(8,25),F(101,200),F(2,25)),
        (4,5,4,F(4,15),F(63,125),F(3,50)),
    ]:
        L=lower_L(r,k,ell,p)
        L0=lower_L(r,k,0,p)
        lhs=r*(1-L)
        rhs=divergence_interval(1-target,F(1,2**r))[0]
        assert lhs<rhs
        robust_lhs=r*(1-((1-bad)*L+bad*L0))
        robust_rhs=divergence_interval(F(1,2),F(1,2**r))[0]
        assert robust_lhs<robust_rhs
        abundant_denominator = 36 if r==3 else 56
        assert lhs < (1-F(1,abundant_denominator))*robust_rhs
        record={
            'r':r,'minimum_generator_size':k,'external_observations':ell,
            'p':str(p),'mean_frequency_strictly_above':str(target),
            'entropy_deficit_upper_enclosure':decimal_enclosure(lhs),
            'target_divergence_lower_enclosure':decimal_enclosure(rhs),
            'maximum_fraction_bad_generators':str(bad),
            'fraction_strictly_abundant_exceeds':f'1/{abundant_denominator}',
            'robust_entropy_deficit_upper_enclosure':decimal_enclosure(robust_lhs),
            'half_divergence_lower_enclosure':decimal_enclosure(robust_rhs),
            'certified':True,
        }
        records.append(record)
        print(json.dumps(record))
    for r,k,ell,p in [(2,2,1,F(2,5)),(3,2,1,F(1,3)),(3,2,0,F(2,5))]:
        analytic=posterior_law(r,k,ell,p)
        direct=direct_posterior_law(r,k,ell,p)
        assert analytic==direct, (r,k,ell,p)
        print(f'Exact posterior-law identity passed: r={r}, k={k}, ell={ell}, p={p}')
    (Path(__file__).resolve().parent.parent/'data'/'generator_certificate.json').write_text(json.dumps(records,indent=2)+'\n')

if __name__=='__main__': certify()
