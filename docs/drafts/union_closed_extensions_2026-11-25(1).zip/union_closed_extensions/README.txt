FROM LOCAL EXTREMIZERS TO ABUNDANT OUTSIDE ELEMENTS
Partial results on Frankl's union-closed sets conjecture
Prepared for Vladimir Reshetnikov, November 25, 2026

READ FIRST
----------
union_closed_extensions.pdf is the complete research report. The editable
main source is union_closed_extensions.tex, with three included mathematical
sections, a short included bibliography fragment, and one supplied figure.

The full conjecture is NOT proved. This package proves new proposed
refinements of the six supplied ProveIt drafts and a separate generator
theorem. Exact predecessors for these quantitative extensions were not
located in the sources reviewed. Historical priority remains provisional.
Independent checking here means separately implemented computations and
separate AI proof reviews, not an independent human referee or a Lean proof.

MAIN SIX-POINT RESULT
--------------------
Assume F contains all six five-element subsets of a six-set U. Let
  N = number of distinct family members,
  M = maximum degree of a point of U,
  E = 228 M - 111 N,
  phi = (sqrt(5)-1)/2.

If N > 64 and 0 < E < 615 N / 3359, then E >= 672 and an outside
point has frequency at least

  1 - phi * [ln 2 + ln N - r ln(192 N/(E-480))] / ln(N/64),
  r = (5/6) * (1 - 3359 E/(615 N))^2.

If E <= N^(delta+o(1)), 0 <= delta < 1, the limiting inferior outside
frequency is at least 1 - phi*(1+5 delta)/6. This exceeds one half for
delta < (1+3 sqrt(5))/10 = 0.770820393...

If M_* is the maximum degree anywhere in the family, then
  liminf (228 M_* - 111 N)/N^eta >= 960/(6^(6/5) 38^eta),
  eta = (41+117 sqrt(5))/380 = 0.796368298...
The right side is 6.171633929... These are asymptotic statements;
the manuscript separately provides a finite inequality.

In the stated stability range, the exact minimum excess is 672, or 783
when the empty set is absent. All minimum-excess families are classified.
Their optimal asymptotic outside frequency is exactly (5+c_UC)/6,
where c_UC is the unknown optimal universal abundance constant.
This optimum equals 11/12 if and only if Frankl's conjecture is true.

FURTHER RESULTS
---------------
* A general theorem transfers finite zero-score fibre configurations
  into outside-frequency bounds. Eight explicit local configurations
  receive quantified stability regions and global excess exponents.
* If all generators have size d, every element is in r generators,
  and the bipartite incidence graph has no cycle shorter than 10:
    r = 3, d >= 4: mean frequency > 0.505; > 1/36 of points are abundant.
    r = 4, d >= 5: mean frequency > 0.504; > 1/56 of points are abundant.
  A robust variant tolerates 8% or 6%, respectively, of generator
  neighborhoods failing the required tree condition in a linear system.

PROOF DEPENDENCIES AND PRIOR WORK
--------------------------------
The local ratios and equality fibres are inherited from the supplied
union_closed_abundance.zip and are revalidated here. The rare-triple
draft in union_closed_partial_results.zip already contains the idea of
using cross-type unions and outside entropy. Our new results extend
that mechanism; we do not claim the underlying idea as new.
The binary entropy inequality is established Chase--Lovett input.
Poonen and Pulaj--Wood are credited for the local-fibre framework.
The generator comparison includes a separate unrefereed high-girth
result that has a stronger pointwise bound but requires girth 16.
See the report, literature_audit.txt, and provenance.json for details.

CONTENTS
--------
union_closed_extensions.pdf        Complete report.
union_closed_extensions.tex        Main LaTeX source.
minimum_excess_classification.tex  Exact minimum and classification.
generator_section.tex             Generator entropy proof and constants.
analytic_collision_lemmas.tex      Analytic type-collision optimizations.
generator_bib.tex                  Additional bibliography entries.
figures/                          PDF and PNG figure; PDF used by LaTeX.
code/                             Exact certificates and example builders.
data/                             Actual verification outputs and summaries.
proof_review.txt                  Six-point proof audit and limitations.
generator_review.txt              Separate generator proof audit.
literature_audit.txt               Sources reviewed and novelty scope.
provenance.json                    Source commit, archive hashes, attribution.
Makefile                          Reproduction commands.
MANIFEST.sha256                   Checksums of the delivered files.

REPRODUCTION
------------
On a normal TeX Live or MiKTeX installation with the listed common packages:
  make pdf
or run pdflatex union_closed_extensions.tex three times.
The figure is already supplied, so Python plotting is not required to
rebuild the PDF. No BibTeX run is necessary.

For all certificate checks, use Python 3.10+ and a C++20 compiler:
  make verify
Only the Python standard library is required. Do not use Python's -O
option because assertions implement exact checks. No external datasets,
optimization solver, network connection, or proprietary library is needed.

Individual commands are visible in the Makefile. The main local checker
and independent six-point checker must be compiled before running.
All checkers overwrite only their recorded outputs in data/ and build/.

To recreate the optional figure, install matplotlib and run:
  make figure
That numerical plot is explanatory and is not used to certify a theorem.

VERIFICATION SCOPE
------------------
The local-fibre reduction justifies exhaustive finite certificates; it is
not an enumeration of all arbitrary families on six ground points.
The independent six-point computation checks every one of 4,194,304
choices of small generators. The type-polytope algorithms use exact
rational arithmetic and agree on vertex counts 10, 73, 196, 73, 160.
Generator comparisons use rational outward bounds for logarithms.
Six explicit minimum-excess constructions have every pairwise union
checked, and two local sharpness witnesses are verified directly.
The finite example at N=1,000,000, E<=10,000 is certified by rational
intervals: the stronger outside lower bound lies between
0.543902371108557 and 0.543902371108558.

The proofs establish the general statements; these computations check
the finite ingredients and examples. No claim of full-conjecture proof,
optimality of the stability exponents, or historical-priority certification
is made.
