#!/usr/bin/env python3
"""Reproduce finite validation; the producer is not imported by kernel.py."""
import ast
import copy
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tokenize

from kernel import Invalid, verify

ROOT = Path(__file__).resolve().parent


def v(x): return ["v", x]
def z(): return ["0"]
def k(n, a, h): return ["K", n, a, h]
def s(a): return k(z(), a, v("$"))
def d(n): return k(n, z(), z())
def e(a, b): return ["eq", a, b]
def all_(x, a): return ["all", x, a]
def ex(x, a): return ["ex", x, a]
def imp(a, b): return ["imp", a, b]
def node(rule, *premises, **fields):
    return {"rule": rule, **fields, "premises": list(premises)}
def refl(t): return node("refl", term=t)
def hyp(i): return node("hyp", index=i)
def packet(goal, proof): return {"goal": goal, "proof": proof}
def transport(major, minor, body, name="m"):
    return node("transport", major, minor, var=name, body=body)


def positive_packets():
    a, b, n, x = v("a"), v("b"), v("n"), v("x")
    ident = v("$")
    one = s(z())
    out = {}
    out["zero_computation"] = packet(e(k(z(), z(), z()), one),
                                      node("K0", seed=z(), update=z()))
    out["successor_computation"] = packet(e(k(one, z(), ident), k(z(), z(), ident)),
                                          node("KS", count=z(), seed=z(), update=ident))
    br = ["or", e(d(x), z()), e(d(x), one)]
    out["boolean_range"] = packet(all_("x", br), node("all_i", node("BR", term=x), var="x"))
    false_bridge = imp(e(z(), one), ["bot"])
    out["falsity_bridge"] = packet(false_bridge, node("F"))
    out["reflexivity"] = packet(e(z(), z()), refl(z()))
    out["implication"] = packet(imp(e(z(), z()), e(z(), z())),
                                 node("imp_i", hyp(0), assume=e(z(), z())))
    conjunction = ["and", e(z(), z()), false_bridge]
    both = node("and_i", refl(z()), node("F"))
    out["conjunction"] = packet(conjunction, both)
    out["first_projection"] = packet(e(z(), z()), node("and_e", both, side=0))
    out["second_projection"] = packet(false_bridge, node("and_e", both, side=1))
    reversed_br = ["or", br[2], br[1]]
    orproof = node("or_e", node("BR", term=x),
                   node("or_i", hyp(0), side=1, other=br[2]),
                   node("or_i", hyp(0), side=0, other=br[1]))
    out["disjunction_cases"] = packet(all_("x", reversed_br), node("all_i", orproof, var="x"))
    universal = node("all_i", refl(x), var="x")
    out["universal_specialization"] = packet(e(one, one), node("all_e", universal, term=one))
    existential = ex("x", e(x, x))
    exproof = node("ex_i", refl(z()), var="x", body=e(x, x), term=z())
    out["existential_witness"] = packet(existential, exproof)
    exminor = node("ex_i", hyp(0), var="x", body=e(x, x), term=v("w"))
    out["existential_elimination"] = packet(existential, node("ex_e", exproof, exminor, var="w"))
    out["explosion"] = packet(imp(["bot"], e(z(), one)),
                               node("imp_i", node("bot_e", hyp(0), **{"as":e(z(), one)}),
                                    assume=["bot"]))

    # Capture avoidance at a quantified specialization: the bound inner y must
    # be renamed when x is replaced by the free ambient y.
    inner = node("all_i", node("ex_i", refl(x), var="y", body=e(x, v("y")), term=x), var="x")
    out["capture_avoiding_specialization"] = packet(
        all_("y", ex("z", e(v("y"), v("z")))),
        node("all_i", node("all_e", inner, term=v("y")), var="y"))

    # Equality transport uses a genuinely quantified motive with a conflicting
    # binder. Independent alpha-renaming in the premise is intentionally used.
    source_exists = node("ex_i", refl(v("y")), var="z",
                         body=e(v("y"), v("z")), term=v("y"))
    moved = transport(refl(v("y")), source_exists, ex("y", e(v("m"), v("y"))))
    out["quantified_transport"] = packet(all_("y", ex("z", e(v("y"), v("z")))),
                                         node("all_i", moved, var="y"))

    # Genuine contextual equation induction. The retained assumption a=b is
    # used in the base; only the literal matrix E(x) is assumed in the step.
    matrix_left = k(x, a, ident)
    matrix_right = s(b)
    base = transport(hyp(0), node("K0", seed=a, update=ident),
                     e(k(z(), a, ident), s(v("m"))))
    step = transport(hyp(1), node("KS", count=x, seed=a, update=ident),
                     e(k(s(x), a, ident), v("m")))
    induction = node("EI", base, step, var="x", left=matrix_left,
                     right=matrix_right, at=n)
    theorem = all_("a", all_("b", imp(e(a, b), all_("n", e(k(n, a, ident), s(b))))))
    theorem_proof = node("all_i", node("all_i", node("imp_i",
                         node("all_i", induction, var="n"), assume=e(a, b)), var="b"), var="a")
    out["contextual_equation_induction"] = packet(theorem, theorem_proof)

    # Successor separation is derived without BR or induction. Transport
    # sigma(x)=0 through delta, combine the two computation equations, then F.
    zero_test_successor = node("KS", count=x, seed=z(), update=z())
    delta_zero_equals_zero = transport(hyp(0), zero_test_successor, e(d(v("m")), z()))
    collapse = transport(delta_zero_equals_zero, node("K0", seed=z(), update=z()),
                         e(v("m"), one))
    contradiction = node("imp_e", node("F"), collapse)
    out["derived_successor_separation"] = packet(
        all_("x", imp(e(s(x), z()), ["bot"])),
        node("all_i", node("imp_i", contradiction, assume=e(s(x), z())), var="x"))

    # The outer state occurs twice in the actual arguments of a nested K;
    # the nested update has its own state binder and must remain unchanged.
    nested_update = k(ident, ident, ident)
    previous = k(z(), z(), nested_update)
    out["nested_update_scope_reset"] = packet(
        e(k(one, z(), nested_update), k(previous, previous, ident)),
        node("KS", count=z(), seed=z(), update=nested_update))

    # Repeated displayed binder names denote the nearest binder. The proof
    # deliberately uses distinct names to exercise alpha-equivalence.
    out["nested_shadow_alpha"] = packet(all_("x", all_("x", e(x, x))),
        node("all_i", node("all_i", refl(v("b")), var="b"), var="a"))
    return out


def negative_packets(positive):
    out = {}
    out["false_equation"] = packet(e(z(), s(z())), refl(z()))
    out["free_public_goal"] = packet(e(v("x"), v("x")), refl(v("x")))
    out["missing_hypothesis"] = packet(e(z(), z()), hyp(0))
    out["boolean_hypothesis_index"] = packet(imp(e(z(), z()), e(z(), z())),
        node("imp_i", hyp(False), assume=e(z(), z())))
    out["nonclosed_update"] = packet(all_("x", e(k(z(), z(), v("x")), s(z()))),
        node("all_i", node("K0", seed=z(), update=v("x")), var="x"))
    out["nonclosed_nested_update"] = packet(e(z(), z()), node("K0", seed=z(),
        update=k(z(), v("$"), v("external"))))
    out["unbound_count"] = packet(e(z(), z()), node("KS", count=v("x"), seed=z(), update=z()))
    out["bad_zero_arity"] = packet(e(["0", "extra"], z()), refl(z()))
    out["bad_term_tag"] = packet(e(["S", z()], z()), refl(z()))
    out["bad_formula_tag"] = packet(["iff", e(z(), z()), e(z(), z())], refl(z()))
    out["unknown_coverage_axiom"] = packet(e(z(), z()), node("Cov", term=z()))
    out["unknown_injectivity_axiom"] = packet(imp(e(s(z()), s(z())), e(z(), z())),
        node("SI", left=z(), right=z()))
    out["unknown_rule"] = packet(e(z(), z()), node("oracle"))
    out["extra_rule_field"] = packet(e(z(), z()), {**refl(z()), "trusted":True})
    out["wrong_premise_count"] = packet(e(z(), z()), node("refl", refl(z()), term=z()))
    out["wrong_implication_major"] = packet(e(z(), z()), node("imp_e", refl(z()), refl(z())))
    out["bad_conjunction_side"] = packet(e(z(), z()), node("and_e",
        node("and_i", refl(z()), refl(z())), side=2))
    out["mismatched_case_targets"] = packet(e(z(), z()), node("or_e",
        node("or_i", refl(z()), side=0, other=e(s(z()), s(z()))), hyp(0), hyp(0)))
    out["wrong_transport_source"] = packet(e(z(), z()), transport(refl(z()), refl(s(z())),
        e(v("m"), v("m"))))
    out["capturing_transport_template_name"] = packet(all_("m", e(v("m"), v("m"))),
        node("all_i", transport(refl(v("m")), refl(v("m")), e(v("m"), v("m"))), var="m"))
    out["nonfresh_universal_eigenvariable"] = packet(all_("x", all_("x", e(v("x"), v("x")))),
        node("all_i", node("all_i", refl(v("x")), var="x"), var="x"))
    exproof = node("ex_i", refl(z()), var="x", body=e(v("x"), v("x")), term=z())
    out["existential_eigenvariable_escape"] = packet(e(z(), z()), node("ex_e", exproof, hyp(0), var="w"))
    out["wrong_existential_witness"] = packet(ex("x", e(v("x"), z())),
        node("ex_i", refl(z()), var="x", body=e(v("x"), z()), term=s(z())))
    out["reserved_eigenvariable"] = packet(all_("$", e(v("$"), v("$"))),
        node("all_i", refl(v("$")), var="$"))
    out["false_boolean_range_goal"] = copy.deepcopy(positive["boolean_range"])
    out["false_boolean_range_goal"]["goal"] = all_("x", e(d(v("x")), z()))
    out["quantified_induction_matrix"] = packet(e(z(), z()), node("EI", refl(z()), refl(z()),
        var="x", left=all_("y", e(v("y"), v("y"))), right=z(), at=z()))
    out["wrong_induction_base"] = packet(e(z(), z()), node("EI", refl(s(z())), refl(z()),
        var="x", left=v("x"), right=v("x"), at=z()))
    out["wrong_induction_step"] = packet(e(z(), z()), node("EI", refl(z()), refl(z()),
        var="x", left=v("x"), right=v("x"), at=z()))
    out["nonfresh_induction_variable"] = packet(all_("x", e(v("x"), v("x"))),
        node("all_i", node("EI", refl(z()), refl(s(v("x"))), var="x",
                            left=v("x"), right=v("x"), at=v("x")), var="x"))
    out["induction_eigenvariable_in_target"] = packet(e(z(), z()),
        node("EI", refl(z()), refl(s(v("x"))), var="x",
             left=v("x"), right=v("x"), at=v("x")))

    # This corruption changes the fixed nested index as if the outer state
    # substitution were allowed to enter its independently bound update.
    out["nested_update_capture"] = copy.deepcopy(positive["nested_update_scope_reset"])
    rhs = out["nested_update_capture"]["goal"][2]
    rhs[3] = copy.deepcopy(rhs[1])

    # Both displayed statements happen to be true, but the supplied proof
    # concludes dependence on the OUTER binder. It is not an alpha-renaming
    # of a statement whose repeated name refers to the INNER binder.
    out["wrong_shadow_alpha"] = packet(all_("x", all_("x", e(v("x"), v("x")))),
        node("all_i", node("all_i", refl(v("a")), var="b"), var="a"))
    return out


def measure_source():
    class Strip(ast.NodeTransformer):
        def clean(self, node):
            self.generic_visit(node)
            if (node.body and isinstance(node.body[0], ast.Expr) and
                    isinstance(node.body[0].value, ast.Constant) and
                    isinstance(node.body[0].value.value, str)):
                node.body = node.body[1:]
            return node
        visit_Module = visit_FunctionDef = visit_AsyncFunctionDef = visit_ClassDef = clean
    tree = Strip().visit(ast.parse((ROOT / "kernel.py").read_text()))
    normalized = ast.unparse(tree) + "\n"
    ignored = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
               tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}
    return {"normalized_tokens":sum(t.type not in ignored for t in tokenize.generate_tokens(io.StringIO(normalized).readline)),
            "ast_nodes":sum(1 for _ in ast.walk(tree)),
            "normalized_bytes":len(normalized.encode("utf-8"))}


def main():
    positive = positive_packets()
    negative = negative_packets(positive)
    cases = [(name, value, True) for name,value in positive.items()]
    cases += [(name, value, False) for name,value in negative.items()]
    rows = []
    for name, value, expected in cases:
        try:
            actual = verify(value)
        except (Invalid, ValueError, TypeError, KeyError, IndexError):
            actual = False
        if bool(actual) != expected:
            raise RuntimeError("API verdict mismatch: " + name)
        text = json.dumps(value, indent=2) + "\n"
        for flags in ([], ["-O"]):
            run = subprocess.run([sys.executable, *flags, str(ROOT / "kernel.py")],
                                 input=text, text=True, capture_output=True, timeout=10)
            if (run.returncode == 0) != expected or ("ACCEPT" in run.stdout) != expected:
                raise RuntimeError("CLI verdict mismatch: " + name + repr(run))
        rows.append({"name":name, "expected":"ACCEPT" if expected else "REJECT",
                     "api":"PASS", "cli":"PASS", "optimized_cli":"PASS"})
        if expected:
            (ROOT / "examples" / (name + ".json")).write_text(text)
    malformed = ["{", '{"goal":["bot"],"goal":["bot"],"proof":{}}',
                 '{"goal":["bot"],"proof":NaN}', "null", "[]"]
    for text in malformed:
        run = subprocess.run([sys.executable, str(ROOT / "kernel.py")], input=text,
                             text=True, capture_output=True, timeout=10)
        if run.returncode == 0 or "ACCEPT" in run.stdout:
            raise RuntimeError("Malformed JSON accepted.")
    used_rules = set()
    def scan(value):
        if type(value) is dict:
            if "rule" in value: used_rules.add(value["rule"])
            for item in value.values(): scan(item)
        elif type(value) is list:
            for item in value: scan(item)
    for value in positive.values(): scan(value)
    result = {"python":platform.python_version(), "positive_packets":len(positive),
              "negative_packets":len(negative), "malformed_json_controls":len(malformed),
              "cli_runs":2*len(cases)+len(malformed), "all_cases_passed":True,
              "positive_rule_coverage":sorted(used_rules), "source_metrics":measure_source(),
              "scope":"Finite executable validation, not a formal proof of soundness, completeness, or the arithmetic equivalence.",
              "cases":rows}
    (ROOT / "validation.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({key:value for key,value in result.items() if key != "cases"},indent=2))


if __name__ == "__main__":
    main()
