#!/usr/bin/env python3
"""Validate and evaluate finite staged shifted-iteration terms.

Direct mode evaluates only the defining K recurrence, transparent macros,
memoization, and exact cycle skipping. Accelerated mode additionally uses
the disclosed elementary helper identities listed in ACCELERATED_HELPERS
and generic affine iteration. It never substitutes a predecessor formula,
the tail formula for B, the formula for R, or a recovered I_h formula.

Successful numerical diagnostics do not prove an equation in all models
of the equational theory and do not prove bi-interpretability with iPRA.
"""

import argparse
import copy
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import sys

from terms import ZERO, call, iterate, signature


ACCELERATED_HELPERS = {
    "s": "n+1, by the definition s(n)=K_id(0,n)",
    "Z": "1 at zero, otherwise 0, by one K_0 step",
    "tau": "interchange 0 and 1; fix n>=2, by the independently checked equations",
        "N": "n mod 2, by its exact two-state orbit",
    "M": "n mod 3, by its exact three-state orbit",
    "M4": "n mod 4, by its exact four-state orbit",
    "D": "2*n, by zero-initialized double-successor iteration",
    "A3": "3*n, by zero-initialized triple-successor iteration",
    "G": "n+floor(n/2), by its orbit 0,1,3,4,6,7,...",
}
AFFINE_UPDATES = {
    "id": (1, 0),
    "s": (1, 1),
    "s2": (1, 2),
    "s3": (1, 3),
    "initializer_update": (2, 9),
    "double_plus_one": (2, 1),
}


def freeze(term):
    if not isinstance(term, (list, tuple)):
        raise ValueError("term is not an array")
    if tuple(term) == ("0",):
        return ZERO
    if len(term) == 2 and term[0] == "v" and isinstance(term[1], str):
        return tuple(term)
    if len(term) == 3 and term[0] == "F" and isinstance(term[1], str):
        return ("F", term[1], freeze(term[2]))
    if len(term) == 4 and term[0] == "K" and isinstance(term[1], str):
        return ("K", term[1], freeze(term[2]), freeze(term[3]))
    raise ValueError("malformed term")


def inspect_term(term, earlier):
    if term[0] == "0":
        return set(), 1
    if term[0] == "v":
        return {term[1]}, 1
    if term[1] not in earlier:
        raise ValueError("a term refers to an unknown or later declaration: " + term[1])
    variables, nodes = set(), 1
    for child in term[2:]:
        found, count = inspect_term(child, earlier)
        variables |= found
        nodes += count
    return variables, nodes


def validate(data):
    definitions, total_nodes = {}, 0
    for item in data["definitions"]:
        name = item["name"]
        if not isinstance(name, str) or name in definitions:
            raise ValueError("malformed or repeated name")
        term = freeze(item["body"])
        variables, nodes = inspect_term(term, definitions)
        if not variables <= {"u"}:
            raise ValueError("a unary description captures an external variable")
        definitions[name] = term
        total_nodes += nodes
    if definitions.get("id") != ("v", "u"):
        raise ValueError("id must be the identity description")
    if definitions.get("s") != iterate("id", ZERO, ("v", "u")):
        raise ValueError("successor must expand to K_id(0,u)")
    if data.get("target") not in definitions:
        raise ValueError("missing target")
    return definitions, {
        "declarations": len(definitions),
        "nodes_in_declared_bodies": total_nodes,
        "all_descriptions_closed_unary": True,
        "all_references_to_earlier_declarations": True,
        "successor_is_an_abbreviation": True,
    }


class Evaluator:
    def __init__(self, data, accelerated=False, step_limit=5000000):
        self.definitions, self.validation = validate(data)
        if accelerated and self.definitions != validate(signature())[0]:
            raise ValueError("accelerated evaluation requires the exact bundled signature")
        self.accelerated = accelerated
        self.step_limit = step_limit
        self.steps = 0
        self.cycle_skips = 0
        self.affine_calls = 0
        self.helper_calls = 0

    def tick(self):
        self.steps += 1
        if self.steps > self.step_limit:
            raise RuntimeError("literal evaluation step budget exceeded")

    @lru_cache(maxsize=200000)
    def term(self, tree, environment):
        if tree[0] == "0":
            return 0
        if tree[0] == "v":
            return dict(environment)[tree[1]]
        if tree[0] == "F":
            return self.apply(tree[1], self.term(tree[2], environment))
        count = self.term(tree[2], environment)
        initial = self.term(tree[3], environment)
        return self.K(tree[1], count, initial)

    @lru_cache(maxsize=200000)
    def apply(self, name, value):
        if type(value) is not int or value < 0:
            raise ValueError("standard inputs must be nonnegative integers")
        if name not in self.definitions:
            raise ValueError("unknown unary term")
        if self.accelerated and name in ACCELERATED_HELPERS:
            self.helper_calls += 1
            if name == "s":
                return value + 1
            if name == "Z":
                return int(value == 0)
            if name == "tau":
                return 1 - value if value < 2 else value
            if name in ("N", "M", "M4"):
                return value % {"N": 2, "M": 3, "M4": 4}[name]
            if name == "D":
                return 2 * value
            if name == "A3":
                return 3 * value
            if name == "G":
                return value + value // 2
        return self.term(self.definitions[name], (("u", value),))

    @lru_cache(maxsize=200000)
    def K(self, name, count, initializer):
        if type(count) is not int or type(initializer) is not int or min(count, initializer) < 0:
            raise ValueError("standard iterator arguments must be nonnegative integers")
        if self.accelerated and name in AFFINE_UPDATES:
            self.affine_calls += 1
            coefficient, constant = AFFINE_UPDATES[name]
            if coefficient == 1:
                return initializer + 1 + constant * count
            power = coefficient ** count
            return power * (initializer + 1) + constant * ((power - 1) // (coefficient - 1))
        value, position, seen = initializer + 1, 0, {}
        while position < count:
            self.tick()
            if value in seen:
                period = position - seen[value]
                skip = (count - position) // period
                if skip:
                    position += skip * period
                    self.cycle_skips += 1
                    continue
            else:
                seen[value] = position
            value = self.apply(name, value)
            position += 1
        return value

    def recovered_iterator(self, update, count, initializer):
        # This is a literal source term, with two external inputs.
        term = call("p", iterate("lift_" + update, ("v", "n"), ("v", "a")))
        return self.term(term, (("a", initializer), ("n", count)))

