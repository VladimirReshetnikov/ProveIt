#!/usr/bin/env python3
"""Reproduce finite diagnostics, source legality, and term-size comparisons.

The predecessor, its clock, and recovered iterators are evaluated from their
source. Expected answers are used only by the comparisons after evaluation.
These tests do not prove the universal internal theorems in the paper.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import platform

from terms import ZERO, U, call, iterate, signature
from evaluate import ACCELERATED_HELPERS, AFFINE_UPDATES, Evaluator, validate

ROOT = Path(__file__).resolve().parents[2]


def need(condition, label):
    if not condition:
        raise ValueError(label)


def dependency_size(data, target):
    definitions, _ = validate(data)
    reached = set()

    def nodes(t):
        if t[0] in ("0", "v"):
            return 1
        reached.add(t[1])
        return 1 + sum(nodes(c) for c in t[2:])

    pending = {target}
    counted = {}
    while pending:
        name = min(pending)
        counted[name] = nodes(definitions[name])
        reached.add(name)
        pending = reached - set(counted)

    # Exact tree size in primitive 0 / variable / K syntax, expanding every
    # call and fixed update description, represented by (constant, occurrences
    # of the sole free input). Arithmetic on these counts avoids building the
    # possibly enormous expanded tree. Every K index is copied in full.
    sizes = {}

    def affine(t):
        tag = t[0]
        if tag == "0":
            return 1, 0
        if tag == "v":
            return 0, 1
        if tag == "F":
            fixed, times = sizes[t[1]]
            c, d = affine(t[2])
            return fixed + times * c, times * d
        a, b = affine(t[2])
        c, d = affine(t[3])
        h, k = sizes[t[1]]
        return 1 + a + c + h + k, b + d

    for item in data["definitions"]:
        sizes[item["name"]] = affine(definitions[item["name"]])
    fixed, copies = sizes[target]

    def expand(t, image):
        if t[0] == "0":
            return ("0",)
        if t[0] == "v":
            return image
        if t[0] == "F":
            return expand(definitions[t[1]], expand(t[2], image))
        return ("K", expand(t[2], image), expand(t[3], image),
                expand(definitions[t[1]], ("v", "bound_state")))

    def literal_nodes(t):
        return 1 if t[0] in ("0", "v") else 1 + sum(literal_nodes(x) for x in t[1:])

    literal = literal_nodes(expand(definitions[target], ("v", "outer_input")))
    need(literal == fixed + copies, "expanded-tree count disagrees with literal expansion")
    return {"target": target, "reachable_declarations": len(counted),
            "nodes_in_reachable_declared_bodies": sum(counted.values()),
            "expanded_primitive_tree_nodes_at_variable": fixed + copies,
            "literal_tree_expansion_verified": True,
            "expanded_input_occurrences": copies,
            "declaration_names": sorted(counted)}


def main():
    data = signature()
    encoded = (json.dumps(data, indent=2) + "\n").encode()
    Path(__file__).with_name("terms.json").write_bytes(encoded)
    direct = Evaluator(data, accelerated=False, step_limit=10000000)
    fast = Evaluator(data, accelerated=True)
    counts = {"helper_agreement": 0, "affine_agreement": 0,
              "control_agreement": 0, "predecessor": 0,
              "clock_value": 0, "graph_commutation": 0,
              "strong_graph": 0, "recovered_iteration": 0}
    for name in ACCELERATED_HELPERS:
        for n in range(17):
            need(direct.apply(name, n) == fast.apply(name, n), "helper: " + name)
            counts["helper_agreement"] += 1
    for name in AFFINE_UPDATES:
        for n in range(4):
            for a in range(4):
                need(direct.K(name, n, a) == fast.K(name, n, a), "affine: " + name)
                counts["affine_agreement"] += 1
    for name in ("cycle3", "cycle4", "bf", "be", "clock_inner", "T", "r",
                 "prefix_step", "H", "c"):
        for n in range(13):
            need(direct.apply(name, n) == fast.apply(name, n), "control: " + name)
            counts["control_agreement"] += 1

    for n in range(97):
        actual = fast.apply("p", n)
        need(actual == max(n - 1, 0), "predecessor at " + str(n))
        counts["predecessor"] += 1
    for n in range(65):
        value = fast.apply("B", n + 3)
        need(value + fast.apply("M", n) + 1 == n + 1, "clock equation")
        need(fast.apply("M", value) == 0, "clock residue")
        counts["clock_value"] += 1

    def selector2(b, x, y):
        return fast.K("s", fast.K("zero", fast.apply("Z", b), y),
                      fast.K("zero", b, x))

    def bit(u):
        return fast.apply("Z", fast.apply("M", u + 8))

    def graph(u, v):
        return v + 2 == selector2(bit(u), u, fast.apply("F", u))

    for u in range(97):
        v = fast.apply("F", u) if bit(u) else u
        need(graph(u, v), "graph antecedent")
        tu, tv = fast.apply("T", u), fast.apply("T", v)
        need(graph(tu, tv), "graph preservation")
        counts["graph_commutation"] += 1
        if bit(tu) == 0:
            need(tu == tv, "exact forward consequence")
            counts["strong_graph"] += 1

    for update in ("zero", "id", "s", "s2", "tau", "double_plus_one"):
        for n in range(4):
            for a in range(3):
                expected = a
                for _ in range(n):
                    expected = fast.apply(update, expected)
                observed = fast.recovered_iterator(update, n, a)
                need(observed == expected, "initialized iterator")
                counts["recovered_iteration"] += 1

    trace = [fast.K("T", 0, fast.apply("a", 3))]
    for _ in range(6):
        trace.append(fast.apply("T", trace[-1]))
    need(trace == [88, 136, 208, 316, 478, 721, 0], "six-step base trace")

    malformed = []
    for kind in ("captured_parameter", "forward_reference", "wrong_anchor", "extra_constructor"):
        changed = copy.deepcopy(data)
        if kind == "captured_parameter":
            changed["definitions"][-1]["body"] = ["v", "ambient"]
        elif kind == "forward_reference":
            changed["definitions"][0]["body"] = ["F", "p", ["v", "u"]]
        elif kind == "wrong_anchor":
            changed["definitions"][0]["body"] = ["0"]
        else:
            changed["definitions"][-1]["body"] = ["S", ["v", "u"]]
        try:
            validate(changed)
        except ValueError:
            malformed.append(kind)
        else:
            raise ValueError("accepted malformed signature: " + kind)

    old_path = ROOT / "reference/shifted_unary/clock_terms.py"
    spec = importlib.util.spec_from_file_location("inherited_clock_terms", old_path)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    comparison = {"new": dependency_size(data, "p"),
                  "old": dependency_size(old.signature(), "p"),
                  "scope": "Predecessor descriptions only; these are not complete proof-checker measurements."}
    receipt = {"status": "PASS", "python": platform.python_version(),
               "terms_sha256": hashlib.sha256(encoded).hexdigest(),
               "source_validation": fast.validation, "counts": counts,
               "base_trace": trace, "malformed_sources_rejected": malformed,
               "predecessor_description_comparison": comparison,
               "accelerated_helpers": ACCELERATED_HELPERS,
               "affine_accelerations": AFFINE_UPDATES,
               "direct_iteration_steps": direct.steps,
               "scope": "Finite standard-model diagnostics. The internal retraction, graph theorem, and bi-interpretability are written proofs; they are not established by this test range."}
    destination = ROOT / "evidence/clock_validation.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "counts": counts, "term_sizes": comparison}, indent=2))


if __name__ == "__main__":
    main()
