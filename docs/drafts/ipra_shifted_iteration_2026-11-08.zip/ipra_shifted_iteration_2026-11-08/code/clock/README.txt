STAGED SOURCE AND NUMERICAL EVIDENCE
==================================

Run python3 code/clock/verify.py from the package root.
The script writes terms.json and evidence/clock_validation.json.

terms.py / terms.json define the new predecessor as a finite acyclic list of
closed unary terms. F(name,arg) is transparent abbreviation. K(name,n,a)
uses a fixed earlier unary description; successor expands to K_id(0,arg).
The declaration A3 and the commuting affine F are proof/diagnostic helpers,
not dependencies of the predecessor term p.

evaluate.py is adapted from the old shifted-unary package. Its direct mode
uses only the recurrence K_h(n,a)=h^n(a+1), memoization, and exact cycle skipping.
Accelerated mode additionally uses the displayed standard helper identities
in ACCELERATED_HELPERS and the affine formulas in AFFINE_UPDATES. It checks
that the entire declaration table is exactly the bundled source before using
those shortcuts. It does NOT replace p, B, R, T, or a recovered initialized
iterator by their expected answers. Those are evaluated from their source.

The tests compare helpers, affine iterations, and control terms against direct
evaluation. Subsequent finite predecessor, clock, graph, and initialized-iterator
tests use the disclosed acceleration. Expected answers occur only in the test
comparisons. They are not evaluator shortcuts for the result being tested.

The dependency-size routine computes both declaration-body size and exact
fully expanded primitive tree size. It excludes unreachable diagnostic helpers,
counts each reachable declared body once for the DAG measure, and expands all
named calls and fixed K descriptions for the tree measure. These are metrics
of predecessor terms, never metrics of complete proof checkers.

The universal source-theory theorem has a written proof in report.pdf.
The finite numerical tests neither prove it in arbitrary models nor certify
the report in the supplied direct kernel or in Lean/Rocq.
