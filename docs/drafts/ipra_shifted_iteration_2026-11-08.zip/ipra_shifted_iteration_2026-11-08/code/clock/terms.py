#!/usr/bin/env python3
"""Finite staged source for the new shifted-unary predecessor.

Only zero, variables, and K indexed by a previously declared closed unary
term are numerical primitives. Every other name is a transparent abbreviation.
The universal theorem is proved in the accompanying paper, not by evaluation.
"""
import json
from pathlib import Path

ZERO = ("0",)
U = ("v", "u")


def call(name, argument):
    return ("F", name, argument)


def iterate(name, count, initializer):
    return ("K", name, count, initializer)


def signature():
    definitions = []

    def define(name, body):
        definitions.append({"name": name, "body": body})

    def s(t, count=1):
        for _ in range(count):
            t = call("s", t)
        return t

    def zero_iteration(update, name):
        conjugate = "conjugate_for_" + name
        define(conjugate, call("tau", call(update, call("tau", U))))
        define(name, call("tau", iterate(conjugate, U, ZERO)))

    def conjunction(b, c):
        return call("Z", call("tau", iterate("zero", call("Z", b), call("Z", c))))

    define("id", U)
    define("zero", ZERO)
    define("s", iterate("id", ZERO, U))
    define("Z", iterate("zero", U, ZERO))
    define("parity_from_one", iterate("Z", U, ZERO))
    define("tau_h", iterate("zero", call("parity_from_one", U), s(ZERO)))
    define("tau_v", iterate("tau_h", U, ZERO))
    define("tau_test", call("Z", call("Z", call("tau_v", U))))
    define("tau_update", iterate("tau_h", call("tau_test", U), U))
    define("tau", iterate("tau_update", U, ZERO))
    zero_iteration("Z", "N")
    define("cycle3", iterate("zero", conjunction(call("Z", call("N", U)),
                                                 call("Z", call("Z", U))), U))
    zero_iteration("cycle3", "M")
    define("cycle4", iterate("zero", conjunction(call("N", U),
                                                 call("Z", call("M", U))), U))
    zero_iteration("cycle4", "M4")
    define("s2", s(U, 2))
    zero_iteration("s2", "D")
    define("g", iterate("s", call("M", U), U))
    zero_iteration("g", "G")
    shifted = s(U, 8)
    define("bf", conjunction(call("Z", call("M", shifted)),
                              call("Z", call("N", shifted))))
    define("be", conjunction(call("Z", call("M", shifted)), call("N", shifted)))
    define("clock_inner", iterate("G", call("bf", U), s(U)))
    define("T", iterate("zero", call("be", U), call("clock_inner", U)))
    define("initializer_update", s(call("D", U), 9))
    define("a", iterate("initializer_update", U, s(ZERO, 2)))
    define("e4", call("Z", call("M4", s(U, 2))))
    define("r", iterate("s", call("e4", U), U))
    zero_iteration("r", "R")
    define("B", iterate("T", s(call("R", U), 2), call("a", U)))
    define("prefix_step", iterate("zero", call("Z", call("M", U)), U))
    define("H", iterate("prefix_step", U, ZERO))
    define("c", iterate("zero", call("Z", call("H", U)),
                         call("Z", call("M", call("H", U)))))
    define("p", iterate("Z", call("c", U),
                         iterate("s", call("M", U), call("B", U))))
    # Additional diagnostics below do not occur in the predecessor term.
    define("s3", s(U, 3))
    zero_iteration("s3", "A3")
    define("F", s(call("A3", U), 16))
    define("double_plus_one", iterate("s", U, U))
    for update in ("zero", "id", "s", "s2", "tau", "double_plus_one"):
        define("lift_" + update, s(call(update, call("p", U))))
    return {
        "primitive_syntax": ["zero", "variable", "K indexed by a closed earlier unary term"],
        "standard_meaning": "K_h(n,a)=h^n(a+1)",
        "successor_abbreviation": ["K", "id", ["0"], ["v", "u"]],
        "definitions": definitions,
        "target": "p",
        "status": "Written internal retraction proof from K computation, literal equation induction, and Boolean zero-test range; no injectivity assumption.",
    }


if __name__ == "__main__":
    destination = Path(__file__).with_name("terms.json")
    destination.write_text(json.dumps(signature(), indent=2) + "\n")
    print(destination.name)
