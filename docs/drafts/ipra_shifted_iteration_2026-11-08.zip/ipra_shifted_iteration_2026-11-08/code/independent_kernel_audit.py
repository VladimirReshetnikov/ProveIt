#!/usr/bin/env python3
"""Independent finite-model regression for the checker's substitution machinery.

The finite structures are arbitrary first-order structures, not models of U.
This tests the capture-avoiding substitution lemma, alpha-equivalence, and
the independent binding of every fixed K update. It does not prove soundness
of the checker or certify the predecessor theorem.
"""
import importlib.util
import itertools
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("audited_kernel", HERE / "direct_kernel" / "kernel.py")
kernel = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kernel)


def v(name):
    return ["v", name]


def z():
    return ["0"]


def k(count, seed, update):
    return ["K", count, seed, update]


def eq(a, b):
    return ["eq", a, b]


def term_value(term, env, size):
    if term[0] == "0":
        return 0
    if term[0] == "v":
        return env[term[1]]
    # Each source K_h is interpreted as a fixed binary operation indexed by h.
    count = term_value(term[1], env, size)
    value = (term_value(term[2], env, size) + 1) % size
    for _ in range(count):
        value = term_value(term[3], {"$": value}, size)
    return value


def truth(formula, env, size):
    tag = formula[0]
    if tag == "bot":
        return False
    if tag == "eq":
        return term_value(formula[1], env, size) == term_value(formula[2], env, size)
    if tag in ("all", "ex"):
        values = [truth(formula[2], env | {formula[1]: n}, size) for n in range(size)]
        return all(values) if tag == "all" else any(values)
    a = truth(formula[1], env, size)
    b = truth(formula[2], env, size)
    return (a and b) if tag == "and" else (a or b) if tag == "or" else ((not a) or b)


def main():
    names = ("x", "y", "_v0")
    state = v("$")
    terms = [z()] + [v(name) for name in names]
    terms += [k(z(), v(name), state) for name in names]
    terms += [k(v("x"), v("y"), k(state, state, z())),
              k(v("y"), v("x"), k(state, z(), state))]
    atoms = [eq(a, b) for a, b in itertools.product(terms[:4], repeat=2)]
    atoms += [eq(terms[-2], v("_v0")), eq(terms[-1], v("y")), ["bot"]]
    formulas = list(atoms)
    for a in atoms:
        for x in names:
            formulas.extend([["all", x, a], ["ex", x, a]])
        for x, y in itertools.product(names, repeat=2):
            formulas.extend([["all", x, ["ex", y, a]],
                             ["ex", x, ["all", y, a]]])
    for a, b in zip(atoms, reversed(atoms)):
        formulas.extend([["imp", ["all", "y", a], ["ex", "x", b]],
                         ["and", a, ["all", "x", b]],
                         ["or", ["ex", "y", a], b]])

    checks = 0
    for formula in formulas:
        kernel.formula(formula, set(names))
        for name in names:
            for image in terms:
                replaced = kernel.substitute(formula, name, image)
                kernel.formula(replaced, set(names))
                for size in (2, 3):
                    for values in itertools.product(range(size), repeat=len(names)):
                        env = dict(zip(names, values))
                        actual = truth(replaced, env, size)
                        expected = truth(formula, env | {name: term_value(image, env, size)}, size)
                        if actual != expected:
                            raise AssertionError((formula, name, image, replaced, env, size))
                        checks += 1

    alpha_cases = [
        (["all", "x", ["ex", "y", eq(v("x"), v("y"))]],
         ["all", "a", ["ex", "b", eq(v("a"), v("b"))]], True),
        (["all", "x", ["all", "x", eq(v("x"), z())]],
         ["all", "a", ["all", "b", eq(v("b"), z())]], True),
        (["all", "x", ["all", "x", eq(v("x"), z())]],
         ["all", "a", ["all", "b", eq(v("a"), z())]], False),
        (["all", "x", eq(v("x"), v("y"))],
         ["all", "y", eq(v("y"), v("x"))], False),
    ]
    for a, b, expected in alpha_cases:
        if kernel.same(a, b) != expected:
            raise AssertionError((a, b, expected))
    result = {
        "status": "PASS",
        "finite_model_substitution_checks": checks,
        "formulas": len(formulas),
        "substitution_terms": len(terms),
        "domain_sizes": [2, 3],
        "alpha_equivalence_checks": len(alpha_cases),
        "scope": "Finite semantic regression of substitution and alpha-equivalence, not a soundness proof or predecessor certificate."
    }
    (HERE.parent / "evidence" / "independent_kernel_validation.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
