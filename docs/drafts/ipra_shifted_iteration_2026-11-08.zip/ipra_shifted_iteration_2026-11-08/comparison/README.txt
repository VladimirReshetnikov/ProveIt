COMPLETE-CHECKER COMPARISON
===========================

Snapshot
  VladimirReshetnikov/ProveIt
  commit 12a94890af11b5e75f753260f3be00bb11ae7f08
  docs/drafts (six current ZIP archives)

The sixteen files in checkers/ are unchanged complete acceptance programs
copied from the current successor-from-recursion ZIP. Twelve are retained
historical baselines; four are equivalent source variants in that ZIP's
exploration/ directory. They implement the inherited scalar presentation.
They are not implementations of this report's stationarity presentation.

The current coordinate envelope is
  313 normalized tokens / 347 AST nodes / 878 normalized UTF-8 bytes.
Different programs attain the coordinates. The older 317 / 348 / 885 table
counts only the twelve historical sources. No one current source is
strictly below every coordinate. These are finite corpus measurements,
not a universal lower-bound theorem and not a formal correctness proof.

Reproduce offline from the package root:
  python3 comparison/measure.py

The script validates each complete source against its manifest SHA-256,
parses it without importing or executing it, strips genuine leading
docstrings, and applies ast.unparse to the entire program. It counts all
AST nodes, significant normalized tokens, and normalized UTF-8 bytes,
including imports and the standard-input acceptance/rejection wrapper.
Whitespace, comments, and docstrings are excluded; implementation code
is not excluded. The shared Python standard library is the fixed runtime
assumption of this inherited comparison convention.

Exact recorded numbers use CPython 3.12.14. A differing interpreter can
change ast.unparse output or AST accounting; the script records its actual
version and writes measured results before reporting a mismatch.

Output: evidence/baseline_metrics.json
Manifest: comparison/baseline_manifest.json

The manifest preserves all six original archive identities (byte length,
Git blob SHA-1, SHA-256, and pinned source URL), plus each current member
path and the deeper origin of the twelve historical sources. Outer ZIP
files are not included and are not required for offline reproduction of
the bundled complete-source measurements.

provenance/ contains unchanged historical attribution/license records,
the source variant explanation, and the original inherited normalizer.
Historical snapshots and novelty claims in those copied records describe
their source packages, not this investigation. The new measure.py is a
transparent restatement of the same whole-program metric. Its numerical
results have been independently checked against the inherited normalizer.

The *_open.py wrapper variants assume ordinary UTF-8 process input with
matching decoding/error handling; see the copied source explanation.
The raw checker syntax intentionally interprets numerical binary nodes
as zero and scalar labels at formula positions as truth. An accepted
scalar-zero goal is not an arithmetic contradiction.

This folder does not claim a new smallest checker. It makes the complete
current comparison boundary explicit and reproducible.
