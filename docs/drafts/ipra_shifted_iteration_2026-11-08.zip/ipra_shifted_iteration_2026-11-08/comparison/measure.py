"""Offline whole-program metrics. Checker sources are parsed, never executed."""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize

ROOT = Path(__file__).resolve().parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


class StripDocstrings(ast.NodeTransformer):
    def clean(self, node):
        self.generic_visit(node)
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body = node.body[1:]
        return node

    visit_Module = visit_FunctionDef = visit_AsyncFunctionDef = visit_ClassDef = clean


def measure(entry):
    raw = (ROOT / entry["local_file"]).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != entry["sha256"]:
        raise ValueError("Source digest mismatch: " + entry["local_file"])
    tree = StripDocstrings().visit(ast.parse(raw.decode("utf-8")))
    normalized = ast.unparse(tree) + "\n"
    result = {"normalized_tokens": sum(t.type not in IGNORED for t in
                  tokenize.generate_tokens(io.StringIO(normalized).readline)),
              "ast_nodes": sum(1 for _ in ast.walk(tree)),
              "normalized_bytes": len(normalized.encode("utf-8"))}
    return {"label": entry["label"], "file": entry["local_file"],
            "sha256": digest, **result,
            "matches_recorded_metrics": result == entry["recorded_metrics"]}


def main():
    manifest = json.loads((ROOT / "baseline_manifest.json").read_text())
    rows = [measure(entry) for entry in manifest["programs"]]
    minima = {key: min(row[key] for row in rows) for key in FIELDS}
    result = {"format": "ipra-baseline-metrics-v1", "commit": manifest["commit"],
              "python": platform.python_version(), "implementation": platform.python_implementation(),
              "program_count": len(rows), "coordinate_envelope": minima,
              "attainers": {key: [row["file"] for row in rows if row[key] == minima[key]]
                            for key in FIELDS}, "programs": rows,
              "all_source_hashes_verified": True,
              "matches_recorded_envelope": minima == manifest["recorded_envelope"],
              "all_metrics_match": all(row["matches_recorded_metrics"] for row in rows)}
    output = ROOT.parent / "evidence" / "baseline_metrics.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"program_count": len(rows), "envelope": minima,
                      "all_metrics_match": result["all_metrics_match"]}))
    if not result["all_metrics_match"]:
        raise SystemExit("Metrics differ from CPython 3.12.14; inspect the written receipt.")


if __name__ == "__main__":
    main()
