#!/usr/bin/env python3
"""Compile the main paper with local pdfLaTeX, without shell escape."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
engine = shutil.which("pdflatex")
if engine is None:
    raise SystemExit("Install pdfLaTeX and the packages listed in report.tex.")
logs = []
for _ in range(3):
    result = subprocess.run(
        [engine, "-no-shell-escape", "-interaction=nonstopmode", "-halt-on-error", "report.tex"],
        cwd=ROOT, capture_output=True, text=True)
    logs.append(result.stdout + result.stderr)
    if result.returncode:
        (ROOT / "evidence/latex_build.txt").write_text("\n".join(logs))
        raise SystemExit(logs[-1][-8000:])
(ROOT / "evidence/latex_build.txt").write_text("\n".join(logs))
print("Compiled", ROOT / "report.pdf")
