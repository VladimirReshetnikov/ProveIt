#!/usr/bin/env python3
"""Re-run the package's finite executable evidence without network access."""
import ast
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import tokenize

ROOT = Path(__file__).resolve().parent
scripts = ["comparison/measure.py", "code/direct_kernel/tests.py",
           "code/clock/verify.py", "code/independent_kernel_audit.py"]
for script in scripts:
    print("Running", script, flush=True)
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)

spec = importlib.util.spec_from_file_location("source_measure", ROOT / "comparison/measure.py")
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
kernel_path = ROOT / "code/direct_kernel/kernel.py"
raw = kernel_path.read_bytes()
tree = measure.StripDocstrings().visit(ast.parse(raw.decode()))
normalized = ast.unparse(tree) + "\n"
metrics = {"normalized_tokens": sum(token.type not in measure.IGNORED for token in
                                   tokenize.generate_tokens(io.StringIO(normalized).readline)),
           "ast_nodes": sum(1 for _ in ast.walk(tree)),
           "normalized_bytes": len(normalized.encode())}
expected = {"normalized_tokens": 2730, "ast_nodes": 2856, "normalized_bytes": 10512}
if metrics != expected:
    raise SystemExit("Direct kernel metrics differ; Python version or source may have changed.")
summary = {"status": "PASS", "python": platform.python_version(),
           "completed_scripts": scripts, "direct_kernel_metrics": metrics,
           "direct_kernel_sha256": hashlib.sha256(raw).hexdigest(),
           "scope": "Reproduces finite diagnostics and source measurements; does not formally verify the universal mathematical theorems."}
(ROOT / "evidence/reproduction.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
