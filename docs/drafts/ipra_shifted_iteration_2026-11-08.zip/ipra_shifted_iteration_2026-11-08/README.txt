SHIFTED UNARY ITERATION: AN AXIOMATIZATION OF iPRA WITHOUT PRIMITIVE SUCCESSOR
============================================================================
Prepared for Vladimir Reshetnikov, November 8, 2026 (Pacific date).

MAIN RESULT
-----------
The previous shifted-unary draft's internal retraction gap is closed.
Zero and a single staged shifted-iteration constructor with CLOSED UNARY
updates suffice. Successor sigma(a)=K_id(0,a) is a defined section.

The entire nonlogical basis is:
  K_h(0,a)=sigma(a),
  K_h(sigma(n),a)=h(K_h(n,a)),
  delta(n)=0 or delta(n)=1, where delta(n)=K_0(n,0),
  0=1 -> falsity,
  contextual induction for literal equations only.

All ordinary intuitionistic logical and equality rules are explicitly listed.
There is NO extra predecessor, retraction, successor injectivity, coverage,
pairing, or stronger induction axiom. The retraction theorem is proved even
without the falsity bridge. Successor injectivity and coverage follow.

The mathematical mechanism is an equation graph plus a clock satisfying
  sigma^2(u)=sigma^2(v) -> T(u)=T(v).
An extra clock step therefore supplies exact equality without assuming
successor cancellation. Two separate equation inductions yield the clock
invariants. A shorter prefix gives an explicit predecessor Pdagger.

The main paper includes the arithmetic reconstruction, pairing, closed
parameter-packing compiler, quantifier-free reflection, and both whole-domain
interpretation composites. Thus the full ordinary theory is bi-interpretable
and equiconsistent with full first-order intuitionistic PRA.

COMPLEXITY LIMIT
----------------
The requested strict complete-proof-checker size improvement is NOT established.
The current sixteen-program coordinate envelope is 313 normalized tokens,
347 AST nodes, and 878 bytes, with different attainers. It is not a universal
lower-bound theorem. Our complete readable direct checker is larger:
2730 tokens / 2856 AST nodes / 10512 bytes.

The predecessor description itself is smaller: 4462 primitive tree nodes
instead of 7303, and 229 nodes in reachable declared bodies instead of 254.
These are term-description metrics, not complete-checker measurements.
Most importantly, the predecessor is now a theorem definition, not an axiom.

START HERE
----------
report.pdf                     Complete compiled research paper.
report.tex and sections/        Complete editable LaTeX source.
code/direct_kernel/kernel.py   Complete standalone ordinary-theory checker.
code/direct_kernel/examples/   Twenty accepted closed certificate packets.
code/clock/                    Staged predecessor terms and evaluator.
evidence/                      Executed checks, source metrics, review scope.
comparison/                    Sixteen unchanged complete comparator sources.
reference/                     Attributed earlier papers and selected sources.
provenance/current_sources.json Exact ten-archive current snapshot and hashes.
ATTRIBUTION.txt                 New/inherited contribution boundaries.
SHA256SUMS                     Integrity manifest for every other payload file.

REPRODUCE OFFLINE
----------------
  python3 reproduce.py
  python3 build.py

Python scripts use only the standard library. CPython 3.12.14 reproduces the
published whole-source normalization measurements. The PDF build uses local
pdfLaTeX and the common packages listed in report.tex, without shell escape.
After deliberate edits, run python3 package.py to refresh hashes and the ZIP.

To check an example:
  python3 code/direct_kernel/kernel.py < code/direct_kernel/examples/zero_computation.json

VERIFICATION SCOPE
------------------
The universal retraction, pairing, and bi-interpretability theorems are written
mathematical proofs that received independent mathematical review. They are
not Lean/Rocq formalizations, and no complete direct-kernel certificate of the
whole paper is supplied. The direct kernel verifies the bundled proof packets;
the numerical tests detect finite implementation/transcription errors.

The checker suite accepts 20 examples, rejects 32 structured negative packets,
and rejects 5 malformed JSON inputs. Its 109 CLI runs and 52 structured API
checks pass. Independent logical substitution regression covers 502740 cases
and four alpha-equivalence checks. The separate clock diagnostics disclose
all helper acceleration; predecessor, B, R, T, and initialized iterators are
evaluated from their source descriptions, never replaced by expected answers.

PINNED REPOSITORY
-----------------
VladimirReshetnikov/ProveIt
commit deefab74912eef91a2cd1ba6686589cb8964466e
https://github.com/VladimirReshetnikov/ProveIt/tree/deefab74912eef91a2cd1ba6686589cb8964466e/docs/drafts

All ten current archive payloads were checked against their Git blob IDs.
No repository files, branches, issues, or pull requests were changed.
Novelty is asserted relative to the inspected corpus, not as global historical
priority or a claim to have found the absolutely simplest presentation.
