#!/usr/bin/env python3
"""Create a deterministic ZIP and SHA-256 manifest after deliberate edits."""
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
EXCLUDED_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def payloads():
    return sorted(p for p in ROOT.rglob("*") if p.is_file()
                  and "__pycache__" not in p.parts
                  and p.suffix not in EXCLUDED_SUFFIXES
                  and p.name != "SHA256SUMS")


entries = payloads()
manifest = "".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                   + p.relative_to(ROOT).as_posix() + "\n" for p in entries)
(ROOT / "SHA256SUMS").write_text(manifest)
destination = ROOT.with_suffix(".zip")
with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(entries + [ROOT / "SHA256SUMS"]):
        name = (Path(ROOT.name) / path.relative_to(ROOT)).as_posix()
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 8, 12, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        archive.writestr(info, path.read_bytes())
print(destination)
