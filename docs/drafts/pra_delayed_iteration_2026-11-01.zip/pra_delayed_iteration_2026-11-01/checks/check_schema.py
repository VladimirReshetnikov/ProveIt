#!/usr/bin/env python3
"""Finite syntax diagnostics for the delayed15 presentation.

This independently written checker tests a finite AST implementation and
representative instances. It is not a formal proof of bi-interpretability.
Only the Python standard library is used. Stored descriptor names are
metadata: substitution and free-variable inspection never enter a name.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class Node:
    tag: str
    children: tuple["Node", ...] = ()
    name: str = ""


def V(name):
    return Node("var", name=name)


ZERO = Node("zero")
BOT = Node("bottom")


def S(t):
    return Node("successor", (t,))


ONE = S(ZERO)


def D(name, n, a):
    return Node("delayed", (n, a), name)


def Eq(s, t):
    return Node("equal", (s, t))


def Or(p, q):
    return Node("or", (p, q))


def And(p, q):
    return Node("and", (p, q))


def Imp(p, q):
    return Node("implies", (p, q))


def All(name, body):
    return Node("forall", (body,), name)


DELTA = Eq(ZERO, ONE)


def free_variables(node):
    if node.tag == "var":
        return {node.name}
    result = set().union(*(free_variables(c) for c in node.children))
    return result - {node.name} if node.tag == "forall" else result


def variable_names(node):
    """Includes binders, excludes all stored descriptor metadata."""
    result = set().union(*(variable_names(c) for c in node.children))
    if node.tag in {"var", "forall"}:
        result.add(node.name)
    return result


def substitute(node, variable, replacement):
    """Capture-free free-variable substitution; descriptors are untouched."""
    if node.tag == "var":
        return replacement if node.name == variable else node
    if node.tag == "forall":
        binder = node.name
        body = node.children[0]
        if binder == variable:
            return node
        if binder in free_variables(replacement) and variable in free_variables(body):
            avoid = variable_names(body) | variable_names(replacement) | {variable}
            suffix = 0
            while f"fresh{suffix}" in avoid:
                suffix += 1
            fresh = f"fresh{suffix}"
            body = substitute(body, binder, V(fresh))
            binder = fresh
        return All(binder, substitute(body, variable, replacement))
    return Node(node.tag, tuple(substitute(c, variable, replacement)
                                for c in node.children), node.name)


def node_count(node):
    return 1 + sum(node_count(c) for c in node.children)


def render(node):
    c = node.children
    if node.tag == "var":
        return node.name
    if node.tag == "zero":
        return "0"
    if node.tag == "successor":
        return f"S({render(c[0])})"
    if node.tag == "delayed":
        return f"D[{node.name}]({render(c[0])},{render(c[1])})"
    if node.tag == "bottom":
        return "bottom"
    if node.tag == "forall":
        return f"forall {node.name} ({render(c[0])})"
    if node.tag == "matrix":
        return "F(" + ",".join(map(render, c)) + ")"
    op = {"equal": "=", "or": "or", "and": "and", "implies": "->"}[node.tag]
    return f"({render(c[0])} {op} {render(c[1])})"


class Registry:
    def __init__(self):
        self.bodies = {}

    def validate_term(self, term):
        tag, children = term.tag, term.children
        if tag == "var":
            if children or not term.name:
                raise ValueError("Malformed variable")
            return
        if tag == "zero":
            if children or term.name:
                raise ValueError("Malformed zero")
            return
        if tag == "successor":
            if len(children) != 1 or term.name:
                raise ValueError("Malformed successor")
        elif tag == "delayed":
            if len(children) != 2 or term.name not in self.bodies:
                raise ValueError("Unknown, later, self-referential, or malformed descriptor")
        else:
            raise ValueError("Not a term")
        for child in children:
            self.validate_term(child)

    def add(self, name, body):
        if not name or name in self.bodies:
            raise ValueError("Descriptor names must be fresh")
        self.validate_term(body)  # Only already registered names may occur.
        if not free_variables(body) <= {"v"}:
            raise ValueError("Update body has an external parameter or counter")
        if body in self.bodies.values():
            raise ValueError("This exact stored body already has a descriptor name")
        self.bodies[name] = body

    def validate_formula(self, formula):
        tag, c = formula.tag, formula.children
        if tag == "bottom":
            if c or formula.name:
                raise ValueError("Malformed falsity")
        elif tag == "equal":
            if len(c) != 2 or formula.name:
                raise ValueError("Malformed equality")
            for term in c:
                self.validate_term(term)
        elif tag in {"or", "and", "implies"}:
            if len(c) != 2 or formula.name:
                raise ValueError("Malformed connective")
            for subformula in c:
                self.validate_formula(subformula)
        elif tag == "forall":
            if len(c) != 1 or not formula.name:
                raise ValueError("Malformed universal quantifier")
            self.validate_formula(c[0])
        else:
            raise ValueError("Not an admitted object-language formula constructor")

    def expand_update(self, name, state):
        return substitute(self.bodies[name], "v", state)


def quantifier_free(node):
    return node.tag != "forall" and all(quantifier_free(c) for c in node.children)


def seed(name, epsilon):
    return Eq(D(name, epsilon, V("a")), V("a"))


def step_probe(registry, name):
    inner = D(name, S(V("a")), V("n"))
    return All("n", Eq(D(name, S(S(V("a"))), V("n")),
                       registry.expand_update(name, inner)))


def gate(registry, formula):
    """Return the exact branch name or None. No rewriting is performed."""
    try:
        registry.validate_formula(formula)
    except ValueError:
        return None
    if not free_variables(formula) <= {"n", "a"}:
        return None

    if quantifier_free(formula):
        zero_instance = substitute(formula, "n", ZERO)
        if zero_instance.tag == "implies":
            premise, conclusion = zero_instance.children
            if premise.tag == "or" and premise.children == (conclusion, DELTA):
                return "G"

    for name in registry.bodies:
        if formula == seed(name, ZERO):
            return "Z0"
        if formula == seed(name, ONE):
            return "Z1"
        if formula == step_probe(registry, name):
            return "C"
    return None


def emit_schema(formula):
    progressed = substitute(formula, "n", S(V("n")))
    return All("a", Imp(All("n", Imp(formula, progressed)), All("n", formula)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("schema_results.json"))
    args = parser.parse_args()
    checks = []

    def record(label, condition, **details):
        checks.append({"test": label, "passed": bool(condition), **details})
        if not condition:
            raise AssertionError(label)

    registry = Registry()
    registry.add("succ", S(V("v")))
    registry.add("zero", ZERO)
    registry.add("identity", V("v"))
    registry.add("nested", D("succ", V("v"), V("v")))

    def bad_description(label, name, body):
        before = dict(registry.bodies)
        try:
            registry.add(name, body)
            rejected = False
        except ValueError:
            rejected = True
        record(label, rejected and registry.bodies == before)

    bad_description("self reference rejected", "self", D("self", V("v"), ZERO))
    bad_description("later reference rejected", "early", D("future", V("v"), ZERO))
    bad_description("free counter rejected", "counter", V("u"))
    bad_description("frozen external parameter rejected", "parameter", D("succ", V("v"), V("a")))
    bad_description("duplicate descriptor rejected", "succ", V("v"))
    bad_description("duplicate body alias rejected", "succ_alias", S(V("v")))

    n, a = V("n"), V("a")
    equation = Eq(n, a)
    induction = Imp(Or(substitute(equation, "n", ZERO), DELTA), equation)
    positive = Or(Eq(n, ZERO), Eq(n, S(D("succ", n, ZERO))))
    positive_induction = Imp(Or(substitute(positive, "n", ZERO), DELTA), positive)
    later_equation = Eq(D("nested", n, a), a)
    later_induction = Imp(Or(substitute(later_equation, "n", ZERO), DELTA), later_equation)
    accepted = [
        ("separation guard", Imp(Or(BOT, DELTA), BOT), "G"),
        ("equation induction", induction, "G"),
        ("positive QF induction", positive_induction, "G"),
        ("complete-language later descriptor in matrix", later_induction, "G"),
    ]
    for name in registry.bodies:
        accepted.extend([
            (f"zero seed {name}", seed(name, ZERO), "Z0"),
            (f"one seed {name}", seed(name, ONE), "Z1"),
            (f"stationary successor {name}", step_probe(registry, name), "C"),
        ])
    for label, formula, expected in accepted:
        actual = gate(registry, formula)
        emitted = emit_schema(formula)
        record(label, actual == expected, branch=actual)
        record(label + ": closed with only two variable names",
               not free_variables(emitted) and variable_names(emitted) <= {"n", "a"})

    wrong_guard = Eq(ONE, ZERO)
    changing_quantified = All("b", Eq(D("succ", S(S(n)), V("b")),
                                       S(D("succ", S(n), V("b")))))
    renamed_stationary = All("b", Eq(D("succ", S(S(a)), V("b")),
                                      S(D("succ", S(a), V("b")))))
    rejected = [
        ("reversed separation atom", Imp(Or(Eq(ZERO, a), wrong_guard), equation)),
        ("reversed guard order", Imp(Or(DELTA, Eq(ZERO, a)), equation)),
        ("wrong zero specialization", Imp(Or(Eq(ZERO, a), DELTA), Eq(S(n), a))),
        ("unguarded reflexive base", Imp(Eq(ZERO, a), equation)),
        ("two seed is not admitted", seed("succ", S(ONE))),
        ("swapped seed equality", Eq(a, D("succ", ZERO, a))),
        ("active induction variable in seed", Eq(D("succ", ZERO, n), n)),
        ("changing quantified matrix", changing_quantified),
        ("renamed bound variable is not literal C", renamed_stationary),
        ("wrong delayed step right side", All("n", Eq(D("succ", S(S(a)), n), D("succ", S(a), n)))),
        ("extra free parameter", Eq(D("succ", ZERO, V("b")), V("b"))),
        ("unknown active descriptor", Eq(D("missing", ZERO, a), a)),
    ]
    for label, formula in rejected:
        record(label, gate(registry, formula) is None)

    nested_before = registry.bodies["nested"]
    application = D("nested", V("v"), a)
    replaced = substitute(application, "v", ZERO)
    record("stored body not traversed by active substitution",
           replaced == D("nested", ZERO, a) and registry.bodies["nested"] == nested_before)
    record("stored body not included in free variables",
           free_variables(D("nested", ZERO, a)) == {"a"})
    for name in registry.bodies:
        probe = step_probe(registry, name)
        record(f"bound n stationary under both substitutions: {name}",
               substitute(probe, "n", ZERO) == probe and
               substitute(probe, "n", S(n)) == probe)

    capture_example = All("a", Eq(n, a))
    capture_result = substitute(capture_example, "n", a)
    record("general substitution avoids capture",
           capture_result.name != "a" and free_variables(capture_result) == {"a"})
    record("shadowed binder is untouched",
           substitute(All("n", Eq(n, a)), "n", ZERO) == All("n", Eq(n, a)))

    opaque = Node("matrix", (n, a))
    outer = emit_schema(opaque)
    record("opaque outer AST count is 15", node_count(outer) == 15,
           count=node_count(outer))
    record("opaque outer formula is closed", not free_variables(outer))

    result = {
        "artifact": "delayed15 finite syntax diagnostics",
        "scope": "Finite software diagnostics, not a formal mathematical proof.",
        "matching_logics": ["classical first-order equality logic",
                            "intuitionistic first-order equality logic"],
        "all_passed": all(c["passed"] for c in checks),
        "check_count": len(checks),
        "descriptors_in_dependency_order": [
            {"name": name, "body": render(body)} for name, body in registry.bodies.items()
        ],
        "opaque_outer_formula": render(outer),
        "opaque_outer_node_count": node_count(outer),
        "representative_expanded_counts": {
            "separation_instance": node_count(emit_schema(Imp(Or(BOT, DELTA), BOT))),
            "succ_zero_seed_instance": node_count(emit_schema(seed("succ", ZERO))),
            "succ_one_seed_instance": node_count(emit_schema(seed("succ", ONE))),
            "succ_stationary_step_instance": node_count(emit_schema(step_probe(registry, "succ"))),
        },
        "count_scope": "Descriptor indices are opaque function-symbol names; their stored bodies and generator costs are excluded from the outer-template subtotal.",
        "checks": checks,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"all_passed": result["all_passed"],
                      "checks": len(checks), "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
