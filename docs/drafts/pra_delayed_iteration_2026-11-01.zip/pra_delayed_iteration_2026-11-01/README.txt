PRA FROM ONE UNIFORM DELAYED ITERATOR
Research prepared for Vladimir Reshetnikov, 1 November 2026.

START HERE
  report.pdf                 Complete manuscript and all written proofs.
  report.tex, sections/*.tex  Full editable LaTeX source.
  AXIOMS.txt                 Exact standalone formal specification.

MAIN RESULT
Every earlier unary term h(v) receives a binary delayed iterator:
  D_h(0,a)=a, D_h(S0,a)=a, D_h(SSn,a)=h(D_h(Sn,a)).
With 0!=S0 and one-parameter quantifier-free induction this is
term-bi-interpretable and definitionally equivalent to matching PRA,
separately for classical and intuitionistic logic. A single literal
admission schema packages exactly this basis in the existing 15-node
outer wrapper, with two individual variable names per generated axiom.

The key new term is p(n)=D_S(n,0). An internal equation induction proves
p(Sn)=n. Ordinary iteration is I_h(n,a)=D_h(Sn,a); the former exceptional
counter reader is K(n,a)=D_S(n,D_0(Sn,a)). No product sorts or exceptional
function constructor remain. The cost is a second seed equation for
every iterator. This is a new uniform scalar trade-off, not an absolute
minimum or a new outer-node record.

PROOFS AND CHECKS
  formal/DelayedKernel.lean   Constructive arbitrary-carrier new bridge.
  formal/SCOPE.txt            Exact formal verification boundary.
  formal/lean-toolchain       Lean version used: 4.19.0.
  checks/check_schema.py      Exact syntax/gate implementation and diagnostics.
  audit/schema_results.json  Recorded finite syntax results.
  audit/lean_verification.txt Actual successful Lean dependency reports.
  audit/source_manifest.json Five reviewed archives, immutable URLs/hashes.
  audit/mathematical_review.txt Independent manuscript audit.
  audit/validation.json       Build, visual review, and artifact fingerprints.
  SHA256SUMS.txt              Release content integrity hashes.

The Lean file checks the new algebraic bridge with explicit selected
equation-induction assumptions over an arbitrary carrier. It does NOT
formalize the full first-order gate, pairing/compiler, or whole-theory
bi-interpretation. Those are proved in the manuscript. The Python checks
are finite syntax diagnostics, not semantic proofs.

REBUILD
Requires Python 3 and a standard TeX Live installation with latexmk and
the packages used in report.tex. No Python third-party package is needed.
  python3 build.py
Optional Lean verification:
  python3 build.py --lean /absolute/path/to/lean
Only checks:
  python3 build.py --checks-only

The build makes no network requests and does not install dependencies.
Rebuilding may change PDF metadata and recorded logs/hashes.

SOURCE SNAPSHOT
  https://github.com/VladimirReshetnikov/ProveIt
  9e793b1080d95e3fdd1537ba475e67e639d84f20
  docs/drafts (five current archives).
Attribution is explicit in the report. Original source archives are not
duplicated. No repository modification is needed to use this package.
