#!/usr/bin/env python3
"""Rebuild the finite checks, optional Lean kernel, and PDF, offline."""
from __future__ import annotations
import argparse
import pathlib
import shutil
import subprocess
import sys
import tempfile


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean', help='Optional absolute path to Lean 4.19.0')
    parser.add_argument('--checks-only', action='store_true')
    args = parser.parse_args()
    root = pathlib.Path(__file__).resolve().parent
    audit = root / 'audit'
    audit.mkdir(exist_ok=True)
    checked = subprocess.run([sys.executable, str(root / 'checks/check_schema.py'),
                              '--output', str(audit / 'schema_results.json')],
                             cwd=root, text=True, capture_output=True)
    (audit / 'syntax_console.txt').write_text(checked.stdout + checked.stderr)
    if checked.returncode:
        raise SystemExit(checked.stdout + checked.stderr)
    print(checked.stdout.strip())
    if args.lean:
        run = subprocess.run([args.lean, str(root / 'formal/DelayedKernel.lean')],
                             cwd=root, text=True, capture_output=True)
        (audit / 'lean_verification.txt').write_text(run.stdout + run.stderr)
        if run.returncode:
            raise SystemExit(run.stdout + run.stderr)
        print('Lean kernel: checked successfully.')
    if args.checks_only:
        return
    if not shutil.which('latexmk'):
        raise SystemExit('latexmk was not found; install a TeX distribution first.')
    with tempfile.TemporaryDirectory(prefix='pra-delayed-build-') as tmp:
        run = subprocess.run(['latexmk', '-pdf', '-interaction=nonstopmode',
                              '-halt-on-error', '-outdir=' + tmp, 'report.tex'],
                             cwd=root, text=True, capture_output=True)
        (audit / 'latex_console.txt').write_text(run.stdout + run.stderr)
        log = pathlib.Path(tmp) / 'report.log'
        if log.exists():
            shutil.copy2(log, audit / 'latex.log')
        if run.returncode:
            raise SystemExit(run.stdout + run.stderr)
        shutil.copy2(pathlib.Path(tmp) / 'report.pdf', root / 'report.pdf')
    print('PDF built: report.pdf')


if __name__ == '__main__':
    main()
