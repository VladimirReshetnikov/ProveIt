/-
Delayed pure iteration: a constructive abstract-carrier kernel.

Checked scope:
* The carrier is an arbitrary type A, never Nat.
* The only arithmetic data are z : A, s : A -> A, and selected delayed
  function interpretations satisfying their THREE displayed equations.
* EqInd below is one equation-induction INSTANCE for two specified unary
  term functions. No theorem assumes induction for arbitrary predicates.
* The theorem premises select precisely the equation-induction instances
  used in the written proof. When applying this kernel to the first-order
  theory, the displayed functions must be interpretations of its finite
  terms. Lean's function parameters here are metatheoretic parameters, not
  an object-language function sort or a uniform universal evaluator.
* This file checks the new delayed-iteration bridge. It does not formalize
  the first-order parser, literal gate, derivation calculus, pairing,
  arbitrary-parameter compiler, or full PRA bi-interpretation.

No imports, `sorry`, added axioms, or classical reasoning are used.
-/

universe u

namespace DelayedKernel

variable {A : Type u}

/-- One selected instance of equation induction. -/
def EqInd (z : A) (s : A -> A) (f g : A -> A) : Prop :=
  f z = g z ->
  (forall n, f n = g n -> f (s n) = g (s n)) ->
  forall n, f n = g n

/-- The interpretation of one finite delayed-iteration descriptor. -/
structure Delayed (z : A) (s h : A -> A) where
  run : A -> A -> A
  atZero : forall a, run z a = a
  atOne : forall a, run (s z) a = a
  atStep : forall n a, run (s (s n)) a = h (run (s n) a)

variable {z : A} {s h : A -> A}

def iter (d : Delayed z s h) (n a : A) : A := d.run (s n) a

theorem iter_zero (d : Delayed z s h) (a : A) :
    iter d z a = a := d.atOne a

theorem iter_step (d : Delayed z s h) (n a : A) :
    iter d (s n) a = h (iter d n a) := d.atStep n a

def pred (ds : Delayed z s s) (n : A) : A := ds.run n z

theorem pred_zero (ds : Delayed z s s) : pred ds z = z := ds.atZero z

/-- The only induction needed for predecessor and the K recovery below.
    Its equation is D_S(S n,0)=n, with no frozen parameter. -/
theorem pred_succ
    (ds : Delayed z s s)
    (ei : EqInd z s (fun n => ds.run (s n) z) (fun n => n)) :
    forall n, pred ds (s n) = n := by
  apply ei
  · exact ds.atOne z
  · intro n ih
    exact (ds.atStep n z).trans (congrArg s ih)

theorem succ_injective
    (ds : Delayed z s s)
    (ei : EqInd z s (fun n => ds.run (s n) z) (fun n => n))
    {x y : A} (e : s x = s y) : x = y := by
  have q := congrArg (pred ds) e
  rw [pred_succ ds ei x, pred_succ ds ei y] at q
  exact q

theorem succ_ne_zero
    (ds : Delayed z s s)
    (ei : EqInd z s (fun n => ds.run (s n) z) (fun n => n))
    (sep : z ≠ s z) (n : A) : s n ≠ z := by
  intro e
  have q := congrArg (pred ds) e
  rw [pred_succ ds ei n, pred_zero ds] at q
  have sz : s z = z := (congrArg s q).symm.trans e
  exact sep sz.symm

def add (ds : Delayed z s s) (x y : A) : A := iter ds y x

theorem add_zero (ds : Delayed z s s) (x : A) : add ds x z = x :=
  iter_zero ds x

theorem zero_add
    (ds : Delayed z s s)
    (ei : EqInd z s (fun n => ds.run (s n) z) (fun n => n))
    (y : A) : add ds z y = y := pred_succ ds ei y

def zeroSelector (d0 : Delayed z s (fun _ => z)) (n a : A) : A :=
  iter d0 n a

theorem zeroSelector_zero (d0 : Delayed z s (fun _ => z)) (a : A) :
    zeroSelector d0 z a = a := iter_zero d0 a

theorem zeroSelector_succ
    (d0 : Delayed z s (fun _ => z)) (n a : A) :
    zeroSelector d0 (s n) a = z := iter_step d0 n a

def counter
    (ds : Delayed z s s) (d0 : Delayed z s (fun _ => z))
    (n a : A) : A := ds.run n (zeroSelector d0 n a)

theorem counter_zero
    (ds : Delayed z s s) (d0 : Delayed z s (fun _ => z)) (a : A) :
    counter ds d0 z a = a := by
  unfold counter
  rw [zeroSelector_zero, ds.atZero]

theorem counter_succ
    (ds : Delayed z s s) (d0 : Delayed z s (fun _ => z))
    (ei : EqInd z s (fun n => ds.run (s n) z) (fun n => n))
    (n a : A) : counter ds d0 (s n) a = n := by
  unfold counter
  rw [zeroSelector_succ]
  exact pred_succ ds ei n

/-- Shifted uniqueness, using its explicit one-parameter equation instance. -/
theorem delayed_unique_shift
    (d e : Delayed z s h)
    (ei : forall a, EqInd z s
      (fun n => d.run (s n) a) (fun n => e.run (s n) a))
    (a : A) : forall n, d.run (s n) a = e.run (s n) a := by
  apply ei a
  · exact (d.atOne a).trans (e.atOne a).symm
  · intro n ih
    exact (d.atStep n a).trans
      ((congrArg h ih).trans (e.atStep n a).symm)

/-- Uniqueness on all arguments; the second instance has the same sole
    frozen parameter a. It replaces any implicit appeal to coverage. -/
theorem delayed_unique
    (d e : Delayed z s h)
    (eiShift : forall a, EqInd z s
      (fun n => d.run (s n) a) (fun n => e.run (s n) a))
    (eiAll : forall a, EqInd z s
      (fun n => d.run n a) (fun n => e.run n a))
    (a : A) : forall n, d.run n a = e.run n a := by
  apply eiAll a
  · exact (d.atZero a).trans (e.atZero a).symm
  · intro n _
    exact delayed_unique_shift d e eiShift a n

/-- The D -> I,p -> D composite is provably the identity by precisely
    this atomic equation instance; no constructive coverage is needed. -/
theorem delayed_roundtrip
    (ds : Delayed z s s) (d : Delayed z s h)
    (eiPred : EqInd z s (fun n => ds.run (s n) z) (fun n => n))
    (eiRound : forall a, EqInd z s
      (fun n => d.run n a) (fun n => d.run (s (pred ds n)) a))
    (a : A) : forall n, d.run n a = iter d (pred ds n) a := by
  apply eiRound a
  · change d.run z a = d.run (s (pred ds z)) a
    rw [pred_zero, d.atZero, d.atOne]
  · intro n _
    change d.run (s n) a = d.run (s (pred ds (s n))) a
    rw [pred_succ ds eiPred]

/-- Ordinary iterators as the other side of the bridge. -/
structure Pure (z : A) (s h : A -> A) where
  run : A -> A -> A
  atZero : forall a, run z a = a
  atStep : forall n a, run (s n) a = h (run n a)

/-- An ordinary iterator and a predecessor give a delayed iterator. -/
def fromPure
    (i : Pure z s h) (p : A -> A)
    (pZero : p z = z) (pSucc : forall n, p (s n) = n) :
    Delayed z s h where
  run := fun n a => i.run (p n) a
  atZero := by intro a; rw [pZero, i.atZero]
  atOne := by intro a; rw [pSucc, i.atZero]
  atStep := by intro n a; rw [pSucc, pSucc, i.atStep]

/-- A delayed iterator gives an ordinary iterator simply by shifting. -/
def toPure (d : Delayed z s h) : Pure z s h where
  run := iter d
  atZero := iter_zero d
  atStep := iter_step d

/-- The I,p -> D -> I composite is immediately the identity. -/
theorem pure_roundtrip
    (i : Pure z s h) (p : A -> A)
    (pZero : p z = z) (pSucc : forall n, p (s n) = n)
    (n a : A) :
    (toPure (fromPure i p pZero pSucc)).run n a = i.run n a := by
  change i.run (p (s n)) a = i.run n a
  rw [pSucc]

end DelayedKernel

#print axioms DelayedKernel.pred_succ
#print axioms DelayedKernel.succ_injective
#print axioms DelayedKernel.succ_ne_zero
#print axioms DelayedKernel.counter_zero
#print axioms DelayedKernel.counter_succ
#print axioms DelayedKernel.delayed_unique
#print axioms DelayedKernel.delayed_roundtrip
#print axioms DelayedKernel.pure_roundtrip
