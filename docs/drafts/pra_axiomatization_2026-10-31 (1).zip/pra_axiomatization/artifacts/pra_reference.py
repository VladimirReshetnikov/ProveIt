#!/usr/bin/env python3
"""Reference syntax and finite checks for the compact PRA presentation.

Every arithmetic operation below is an arity-checked *syntactic* primitive
recursive description. Codes are never identified by equality of the functions
they compute. Primitive recursion uses the first argument as its counter.
As in the paper, compiled formulas return 0 for true and 1 for false.

The Python interpreter accepts arbitrary codes; it is not claimed to be a
primitive recursive universal evaluator. The finite checks illustrate the
paper's constructions, not its metamathematical equivalence proof.

Run: python3 pra_reference.py --report verification_report.json \
        --descriptions pr_descriptions.json
Only the Python standard library is required (Python 3.10 or later).
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from functools import cache
from pathlib import Path


@dataclass(frozen=True)
class Code:
    """A finite PR syntax tree: zero, successor, projection, composition, recursion."""

    tag: str
    arity: int
    children: tuple[Code, ...] = ()
    index: int = -1

    def __post_init__(self) -> None:
        if type(self.arity) is not int or self.arity < 0:
            raise ValueError("arity must be a natural number")
        if self.tag == "zero":
            valid = not self.children and self.index == -1
        elif self.tag == "successor":
            valid = self.arity == 1 and not self.children and self.index == -1
        elif self.tag == "projection":
            valid = (not self.children and type(self.index) is int
                     and 0 <= self.index < self.arity)
        elif self.tag == "composition":
            valid = bool(self.children) and self.index == -1
            if valid:
                outer, *inner = self.children
                valid = len(inner) == outer.arity and all(
                    part.arity == self.arity for part in inner
                )
        elif self.tag == "recursion":
            valid = len(self.children) == 2 and self.index == -1
            if valid:
                base, step = self.children
                valid = self.arity == base.arity + 1 and step.arity == base.arity + 2
        else:
            valid = False
        if not valid:
            raise ValueError(f"ill-formed {self.tag!r} description")


def zero(arity: int) -> Code:
    return Code("zero", arity)


def projection(arity: int, index: int) -> Code:
    """Projection indices are zero-based."""
    return Code("projection", arity, index=index)


def compose(arity: int, outer: Code, *inner: Code) -> Code:
    """Explicit input arity also handles nullary outer functions."""
    return Code("composition", arity, (outer, *inner))


def recurse(base: Code, step: Code) -> Code:
    """R(g,h)(0,p)=g(p); R(g,h)(n+1,p)=h(n,R(g,h)(n,p),p)."""
    return Code("recursion", base.arity + 1, (base, step))


SUCCESSOR = Code("successor", 1)


def numeral(arity: int, value: int) -> Code:
    if type(value) is not int or value < 0:
        raise ValueError("numeral must be a natural number")
    code = zero(arity)
    for _ in range(value):
        code = compose(arity, SUCCESSOR, code)
    return code


@cache
def evaluate(code: Code, arguments: tuple[int, ...]) -> int:
    """Execute a description; this is an external, total computable interpreter."""
    if len(arguments) != code.arity:
        raise ValueError("wrong number of arguments")
    if any(type(value) is not int or value < 0 for value in arguments):
        raise ValueError("arguments must be natural numbers")
    if code.tag == "zero":
        return 0
    if code.tag == "successor":
        return arguments[0] + 1
    if code.tag == "projection":
        return arguments[code.index]
    if code.tag == "composition":
        outer, *inner = code.children
        values = tuple(evaluate(part, arguments) for part in inner)
        return evaluate(outer, values)
    counter, *parameters = arguments
    base, step = code.children
    value = evaluate(base, tuple(parameters))
    for index in range(counter):
        value = evaluate(step, (index, value, *parameters))
    return value


# Fixed helpers. All definitions use only the five constructors above.
PREDECESSOR = recurse(zero(0), projection(2, 0))
ZERO_TEST = recurse(numeral(0, 1), zero(2))
CASE = recurse(projection(2, 0), projection(4, 3))
ADD = recurse(projection(1, 0), compose(3, SUCCESSOR, projection(3, 1)))
DIFFERENCE = recurse(
    projection(1, 0), compose(3, PREDECESSOR, projection(3, 1))
)
OVERSHOOT = recurse(
    zero(1),
    compose(
        3, CASE,
        compose(3, DIFFERENCE, projection(3, 0), projection(3, 2)),
        numeral(3, 1), projection(3, 1),
    ),
)
EQUALITY_TEST = compose(
    2, CASE, OVERSHOOT,
    compose(2, CASE, DIFFERENCE, zero(2), numeral(2, 1)), numeral(2, 1),
)
BOOL_NOT = compose(1, CASE, projection(1, 0), numeral(1, 1), zero(1))
BOOL_AND = compose(2, CASE, projection(2, 0), projection(2, 1), numeral(2, 1))
BOOL_OR = compose(2, CASE, projection(2, 0), zero(2), projection(2, 1))
BOOL_IMPLIES = compose(2, CASE, projection(2, 0), projection(2, 1), zero(2))
BOOL_IFF = EQUALITY_TEST

HELPERS = {
    "P": PREDECESSOR, "Z": ZERO_TEST, "C": CASE, "add": ADD,
    "d": DIFFERENCE, "o": OVERSHOOT, "E": EQUALITY_TEST,
    "not": BOOL_NOT, "and": BOOL_AND, "or": BOOL_OR,
    "implies": BOOL_IMPLIES, "iff": BOOL_IFF, "true": zero(0),
    "false": numeral(0, 1),
}


@dataclass(frozen=True)
class Term:
    """A variable, a numeral, or an application of a PR description."""

    tag: str
    value: int | Code
    arguments: tuple[Term, ...] = ()


@dataclass(frozen=True)
class Formula:
    """QF equality formulas with true/false/not/and/or/implies/iff."""

    tag: str
    arguments: tuple[Term | Formula, ...]


def variable(index: int) -> Term:
    return Term("variable", index)


def constant(value: int) -> Term:
    return Term("numeral", value)


def application(code: Code, *terms: Term) -> Term:
    return Term("application", code, terms)


def equality(left: Term, right: Term) -> Formula:
    return Formula("eq", (left, right))


def compile_term(term: Term, arity: int) -> Code:
    if term.tag == "variable" and type(term.value) is int and not term.arguments:
        return projection(arity, term.value)
    if term.tag == "numeral" and type(term.value) is int and not term.arguments:
        return numeral(arity, term.value)
    if term.tag == "application" and isinstance(term.value, Code):
        return compose(arity, term.value, *(compile_term(t, arity) for t in term.arguments))
    raise ValueError("ill-formed term")


def compile_formula(formula: Formula, arity: int) -> Code:
    """Compile a formula to a PR description returning 0 for true and 1 for false."""
    if formula.tag in ("true", "false"):
        if formula.arguments:
            raise ValueError("Boolean constants take no arguments")
        return numeral(arity, int(formula.tag == "false"))
    if formula.tag == "eq" and len(formula.arguments) == 2:
        if not all(isinstance(t, Term) for t in formula.arguments):
            raise ValueError("equality needs two terms")
        return compose(
            arity, EQUALITY_TEST,
            *(compile_term(t, arity) for t in formula.arguments),
        )
    operators = {"not": BOOL_NOT, "and": BOOL_AND, "or": BOOL_OR,
                 "implies": BOOL_IMPLIES, "iff": BOOL_IFF}
    operator = operators.get(formula.tag)
    if operator is None or len(formula.arguments) != operator.arity:
        raise ValueError("unknown connective or wrong connective arity")
    if not all(isinstance(f, Formula) for f in formula.arguments):
        raise ValueError("connectives need formulas")
    return compose(
        arity, operator, *(compile_formula(f, arity) for f in formula.arguments)
    )


def product_evaluate(code: Code, arguments: tuple[tuple[int, int], ...]) -> tuple[int, int]:
    """Interpret each PR symbol coordinatewise on N x N."""
    return tuple(evaluate(code, tuple(a[i] for a in arguments)) for i in range(2))


def formula_meaning(formula: Formula, environment: tuple, product: bool = False) -> bool:
    """Independent native Boolean semantics, including the product countermodel."""
    def term_meaning(term: Term):
        if term.tag == "variable":
            return environment[term.value]
        if term.tag == "numeral":
            return (term.value, term.value) if product else term.value
        values = tuple(term_meaning(t) for t in term.arguments)
        operation = product_evaluate if product else evaluate
        return operation(term.value, values)

    if formula.tag in ("true", "false"):
        return formula.tag == "true"
    if formula.tag == "eq":
        return term_meaning(formula.arguments[0]) == term_meaning(formula.arguments[1])
    values = [formula_meaning(f, environment, product) for f in formula.arguments]
    if formula.tag == "not":
        return not values[0]
    if formula.tag == "and":
        return values[0] and values[1]
    if formula.tag == "or":
        return values[0] or values[1]
    if formula.tag == "implies":
        return not values[0] or values[1]
    if formula.tag == "iff":
        return values[0] == values[1]
    raise ValueError("unknown formula")


def description_table() -> dict:
    """Export a DAG, sharing only literally identical syntactic descriptions."""
    records: list[dict] = []
    identifiers: dict[Code, int] = {}

    def visit(code: Code) -> int:
        if code not in identifiers:
            child_ids = [visit(child) for child in code.children]
            record = {"tag": code.tag, "arity": code.arity, "children": child_ids}
            if code.tag == "projection":
                record["index"] = code.index
            identifiers[code] = len(records)
            records.append(record)
        return identifiers[code]

    roots = {name: visit(code) for name, code in HELPERS.items()}
    return {"projection_indexing": "zero-based", "recursion_argument": "first",
            "truth_encoding": {"true": 0, "false": 1},
            "roots": roots, "nodes": records}


def verify() -> dict:
    """Run finite construction checks, with explicit bounds and proof limitations."""
    counts: dict[str, int] = {}

    def check(group: str, condition: bool) -> None:
        if not condition:
            raise AssertionError(f"verification failed in {group}")
        counts[group] = counts.get(group, 0) + 1

    bound = 7
    for n in range(bound):
        check("arithmetic_helpers", evaluate(PREDECESSOR, (n,)) == max(n - 1, 0))
        check("arithmetic_helpers", evaluate(ZERO_TEST, (n,)) == int(n == 0))
        for y in range(bound):
            for code, expected in [
                (ADD, n + y), (DIFFERENCE, max(y - n, 0)),
                (OVERSHOOT, int(n > y)), (EQUALITY_TEST, int(n != y)),
            ]:
                check("arithmetic_helpers", evaluate(code, (n, y)) == expected)
            d = evaluate(DIFFERENCE, (n, y))
            o = evaluate(OVERSHOOT, (n, y))
            check("accumulator_invariant", evaluate(CASE, (o, n + d, y)) == y)
            check("shift_identities", evaluate(DIFFERENCE, (n + 1, y + 1)) == d)
            check("shift_identities", evaluate(OVERSHOOT, (n + 1, y + 1)) == o)
    for c, a, b in itertools.product(range(bound), range(4), range(4)):
        check("case_semantics", evaluate(CASE, (c, a, b)) == (a if c == 0 else b))

    x, y, z = map(variable, range(3))
    atom_a, atom_b = equality(x, y), equality(y, z)
    cover = Formula("or", (
        equality(x, constant(0)),
        equality(x, application(SUCCESSOR, application(PREDECESSOR, x))),
    ))
    examples = {
        "true": Formula("true", ()),
        "false": Formula("false", ()),
        "equality": atom_a,
        "negation": Formula("not", (atom_a,)),
        "conjunction": Formula("and", (atom_a, atom_b)),
        "disjunction": Formula("or", (atom_a, atom_b)),
        "implication": Formula("implies", (atom_a, atom_b)),
        "equivalence": Formula("iff", (atom_a, atom_b)),
        "addition_with_parameters": equality(application(ADD, x, y), z),
        "substitution_with_parameters": Formula("implies", (
            atom_a, equality(application(ADD, x, z), application(ADD, y, z)),
        )),
        "zero_or_successor": cover,
    }
    for formula in examples.values():
        code = compile_formula(formula, 3)
        for environment in itertools.product(range(4), repeat=3):
            result = evaluate(code, environment)
            check("formula_compilation", result in (0, 1))
            check("formula_compilation",
                  (result == 0) == formula_meaning(formula, environment))

    bad_constructors = [
        lambda: zero(-1), lambda: projection(2, -1), lambda: projection(2, 2),
        lambda: projection(2, 0.5),
        lambda: compose(1, SUCCESSOR),
        lambda: compose(2, SUCCESSOR, projection(1, 0)),
        lambda: recurse(zero(1), zero(2)),
        lambda: compile_term(variable(3), 3),
        lambda: compile_formula(Formula("and", (atom_a,)), 3),
        lambda: compile_formula(Formula("true", (atom_a,)), 3),
        lambda: evaluate(SUCCESSOR, ()), lambda: evaluate(SUCCESSOR, (-1,)),
    ]
    for constructor in bad_constructors:
        try:
            constructor()
        except ValueError:
            check("rejected_malformed_inputs", True)
        else:
            raise AssertionError("malformed input was accepted")
    alternate_zero = compose(1, zero(0))
    check("syntactic_not_extensional_identity", alternate_zero != zero(1))
    for n in range(bound):
        check("syntactic_not_extensional_identity", evaluate(alternate_zero, (n,)) == 0)

    witness = (0, 1)
    product_environment = (witness, (0, 0), (0, 0))
    compiled_cover = product_evaluate(compile_formula(cover, 3), product_environment)
    native_cover = formula_meaning(cover, product_environment, product=True)
    product_zero_test = product_evaluate(ZERO_TEST, (witness,))
    fidelity_fails = (product_zero_test == (0, 0)) != (witness != (0, 0))
    check("product_counterexample", not native_cover and compiled_cover == (0, 0))
    check("product_counterexample", fidelity_fails)
    check("product_counterexample", formula_meaning(cover, ((0, 0),), product=True))
    for a, b in itertools.product(range(bound), repeat=2):
        check("product_successor_cases",
              formula_meaning(cover, ((a + 1, b + 1),), product=True))
    return {
        "status": "passed", "checks": counts, "total_checks": sum(counts.values()),
        "truth_encoding": {"true": 0, "false": 1},
        "bounds": {"helper_inputs": "0..6", "formula_variables": "0..3",
                   "formula_examples": list(examples)},
        "product_counterexample": {
            "domain": "N x N, coordinatewise PR functions", "witness": witness,
            "native_zero_or_successor_formula": native_cover,
            "compiled_characteristic_value": compiled_cover,
            "zero_test_at_witness": product_zero_test,
            "zero_test_fidelity_fails": fidelity_fails,
            "explanation": "The two coordinates satisfy different disjuncts."
        },
        "description_nodes": len(description_table()["nodes"]),
        "limits": [
            "Finite execution checks are not a formal proof of equivalence with PRA.",
            "Universal claims about the product model are proved in the paper.",
            "The interpreter is total computable, not a PR universal evaluator.",
            "No theorem prover, consistency proof, or absolute minimality claim is supplied."
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    parser.add_argument("--descriptions", type=Path)
    arguments = parser.parse_args()
    report = verify()
    text = json.dumps(report, indent=2) + "\n"
    if arguments.report:
        arguments.report.write_text(text, encoding="utf-8")
    if arguments.descriptions:
        arguments.descriptions.write_text(
            json.dumps(description_table(), indent=2) + "\n", encoding="utf-8"
        )
    print(text, end="")


if __name__ == "__main__":
    main()
