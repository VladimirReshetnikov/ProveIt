COMPACT AXIOMATIZATIONS OF PRIMITIVE RECURSIVE ARITHMETIC
Prepared 31 October 2026

RESULT
------
The recommended recursion-based classical first-order presentation has:
  D. Effective primitive recursive descriptions and their defining equations.
  Z. The fixed axiom z(x)=0 <-> x!=0, with z(0)=1, z(Sx)=0, and 1=S0.
  U. Two terms with the same initial value and recursion step are equal.

The paper proves exact deductive equivalence with ordinary first-order PRA
in the same description-indexed language. A countdown and overflow flag
give a native equality tester without assuming induction. This permits
translation of every quantifier-free formula and recovery of its induction
axiom. The usual successor axioms and 0!=1 are derived.

The paper also presents the particularly short direct axiomatization
  D + 0!=1 + quantifier-free induction.
For an equation-only calculus, D plus the uniqueness inference rule is the
natural compact answer; section 8.1 states that calculus explicitly.
It distinguishes both first-order presentations from Goodstein's equational
calculus. Defining equations plus uniqueness and 0!=1 do NOT suffice for
literal first-order PRA: the coordinatewise model N x N is a counterexample.
A finite binding grammar is given, with its metasyntactic status explained.

FILES
-----
  pra_axiomatization.tex                  Complete LaTeX source.
  pra_axiomatization.pdf                  Compiled mathematical paper.
  Makefile                               PDF and verification commands.
  artifacts/pra_reference.py              Standard-library Python reference.
  artifacts/pr_descriptions.json          32-node syntactic helper DAG.
  artifacts/verification_report.json      Saved finite-check results.
  SHA256SUMS                             SHA-256 hashes of package files.

BUILD THE PDF
-------------
Run from this directory:

  make pdf

or equivalently:

  mkdir -p build
  latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build pra_axiomatization.tex
  cp build/pra_axiomatization.pdf pra_axiomatization.pdf

Requirements: a standard TeX installation with pdflatex, latexmk, Latin
Modern, AMS packages, geometry, microtype, hyperref, and the other common
packages named in the source. No network access, external images, custom
fonts, or BibTeX run is required. The bibliography is embedded in the source.

RUN THE EXECUTABLE CHECKS
-------------------------
Run:

  make verify

or:

  python3 artifacts/pra_reference.py --report artifacts/verification_report.json --descriptions artifacts/pr_descriptions.json

Requirements: Python 3.10 or later; standard library only. The command
prints the report and replaces the two generated JSON artifacts.

The source implements five arity-checked PR description constructors:
zero, successor, projection, composition, and primitive recursion. Recursion
uses the first argument; the step receives (counter, previous_value, parameters).
Projection indices in Python are zero-based. Descriptions are identified only
by syntax, never by equality of the numerical functions they compute.

The helpers p,z,c,add,d,o,e match the paper. Formula syntax supports equality,
true, false, negation, conjunction, disjunction, implication, and equivalence.
The truth convention is uniform: 0 means TRUE and 1 means FALSE.

VERIFICATION RESULTS AND LIMITS
------------------------------
The delivered report records 1,949 successful checks. Arithmetic helper
inputs run from 0 through 6; formula inputs run from 0 through 3. It checks
helper values, the invariant and shifts used in the proof, Boolean compiler
branches and parameters, malformed-arity rejection, and the concrete product
counterexample. At (0,1), the native zero-or-successor formula is false but
its arithmetic encoding has value (0,0); z(0,1)=(1,0) violates the additional
zero-test axiom.

These finite checks support the implementation, not the universal theorem.
The paper contains the mathematical equivalence proof. The Python program
is an interpreter and demonstration, not a first-order proof checker, Lean
or Rocq development, consistency proof, or proof of absolute minimality.
Its idealized evaluation algorithm is total computable, not uniformly
primitive recursive in the numerical code of an arbitrary PR description.
Actual execution is subject to normal Python resource limits.

The underlying recursion-uniqueness approach is classical and credited to
Goodstein. No new proof-theoretic principle or absolute shortest presentation
is claimed. No third-party paper PDFs are redistributed in this archive;
the bibliography provides source links.
