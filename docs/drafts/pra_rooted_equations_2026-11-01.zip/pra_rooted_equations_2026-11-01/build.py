#!/usr/bin/env python3
"""Rebuild the PDF and diagnostics without downloading dependencies.

Run: python3 build.py --lean /absolute/path/to/lean
Omit --lean to run syntax diagnostics and rebuild the PDF only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def run_checked(args: list[str], cwd: Path, log: Path) -> str:
    completed = subprocess.run(args, cwd=cwd, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.write_text(completed.stdout, encoding="utf-8")
    if completed.returncode:
        raise RuntimeError(f"Command failed ({completed.returncode}); see {log.name}")
    return completed.stdout


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Lean executable, tested with 4.19.0")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    audit = root / "audit"
    audit.mkdir(exist_ok=True)
    receipt: dict[str, object] = {"status": "building", "lean_rerun": False}
    run_checked([sys.executable, "checks/check_schema.py"], root,
                audit / "python-check.log")
    receipt["diagnostics"] = json.loads((root / "checks/results.json").read_text())
    if args.lean:
        version = run_checked([args.lean, "--version"], root,
                              audit / "lean-version.log").strip()
        output = run_checked([args.lean, "formal/RootedKernel.lean"], root,
                             root / "formal/lean-check.log")
        reports = [line for line in output.splitlines()
                   if "does not depend on any axioms" in line]
        if len(reports) != 16 or "depends on axioms" in output:
            raise RuntimeError("Unexpected Lean axiom-dependency report")
        receipt["lean_rerun"] = True
        receipt["lean_version"] = version
        receipt["lean_empty_dependency_reports"] = len(reports)
    latex = shutil.which("pdflatex")
    if latex is None:
        raise RuntimeError("pdflatex is required to build report.pdf")
    with tempfile.TemporaryDirectory(prefix="pra-rooted-tex-") as tmp:
        temporary = Path(tmp)
        for index in range(1, 4):
            run_checked([latex, "-interaction=nonstopmode", "-halt-on-error",
                         "-file-line-error", f"-output-directory={tmp}",
                         "report.tex"], root, audit / f"latex-pass-{index}.log")
        log = (temporary / "report.log").read_text(errors="replace")
        (audit / "latex-final.log").write_text(log)
        receipt["latex_layout_or_reference_warnings"] = [
            line for line in log.splitlines()
            if "Overfull" in line or "undefined" in line.lower()]
        shutil.copyfile(temporary / "report.pdf", root / "report.pdf")
    if shutil.which("pdfinfo"):
        receipt["pdfinfo"] = run_checked(["pdfinfo", "report.pdf"], root,
                                        audit / "pdfinfo.txt")
    receipt["status"] = "passed"
    receipt["pdf_sha256"] = hashlib.sha256((root / "report.pdf").read_bytes()).hexdigest()
    receipt["scope"] = ("Compilation and finite diagnostics do not formalize "
                        "the complete bi-interpretation theorem.")
    (audit / "build_results.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": receipt["status"],
                      "lean_rerun": receipt["lean_rerun"],
                      "latex_warnings": receipt["latex_layout_or_reference_warnings"]},
                     indent=2))


if __name__ == "__main__":
    main()
