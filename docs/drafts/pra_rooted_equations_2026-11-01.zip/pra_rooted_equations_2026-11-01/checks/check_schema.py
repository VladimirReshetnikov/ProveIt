#!/usr/bin/env python3
"""Finite-syntax generator and bounded diagnostics for rooted-equation PRA.

Python 3.10+, standard library only.  Run from any directory:
    python3 checks/check_schema.py

The output is results.json plus generated_examples.txt beside this file.
These checks validate concrete syntax and finite examples.  They are not an
end-to-end formal proof of arithmetic calibration or bi-interpretability.
"""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    name: str = ""


def V(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def S(t: Term) -> Term:
    return Term("succ", (t,))


def D(name: str, n: Term, a: Term) -> Term:
    # The descriptor name is opaque data, never an active term argument.
    return Term("delay", (n, a), name)


def term_fv(t: Term) -> set[str]:
    if t.tag == "var":
        return {t.name}
    return set().union(*(term_fv(arg) for arg in t.args))


def term_subst(t: Term, name: str, replacement: Term) -> Term:
    if t.tag == "var" and t.name == name:
        return replacement
    return Term(t.tag, tuple(term_subst(x, name, replacement) for x in t.args), t.name)


def references(t: Term) -> set[str]:
    own = {t.name} if t.tag == "delay" else set()
    return own.union(*(references(arg) for arg in t.args))


def check_term_shape(t: Term) -> None:
    arities = {"var": 0, "zero": 0, "succ": 1, "delay": 2}
    if t.tag not in arities or len(t.args) != arities[t.tag]:
        raise ValueError("malformed term constructor")
    if t.tag in {"var", "delay"}:
        if not t.name:
            raise ValueError("a variable or descriptor reference needs a name")
    elif t.name:
        raise ValueError("a zero or successor node has an unexpected name")
    for arg in t.args:
        check_term_shape(arg)


def term_size(t: Term) -> int:
    return 1 + sum(term_size(x) for x in t.args)


def show_term(t: Term) -> str:
    if t.tag == "var":
        return t.name
    if t.tag == "zero":
        return "0"
    if t.tag == "succ":
        return f"S({show_term(t.args[0])})"
    if t.tag == "delay":
        return f"D[{t.name}]({show_term(t.args[0])}, {show_term(t.args[1])})"
    raise ValueError(f"unknown term tag: {t.tag}")


class Descriptors:
    def __init__(self) -> None:
        self.bodies: dict[str, Term] = {}

    def add(self, name: str, body: Term) -> None:
        check_term_shape(body)
        if name in self.bodies:
            raise ValueError("descriptor names must be unique")
        if body in self.bodies.values():
            raise ValueError("reuse the existing descriptor for identical stored syntax")
        if not term_fv(body) <= {"v"}:
            raise ValueError("a stored body has a free variable other than v")
        if not references(body) <= self.bodies.keys():
            raise ValueError("a stored body refers to a non-earlier descriptor")
        self.bodies[name] = body

    def apply(self, name: str, t: Term) -> Term:
        return term_subst(self.bodies[name], "v", t)

    def validate_term(self, t: Term) -> None:
        check_term_shape(t)
        if not references(t) <= self.bodies.keys():
            raise ValueError("unknown descriptor in active term")


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple["Formula", ...] = ()
    terms: tuple[Term, ...] = ()
    name: str = ""


BOT = Formula("bottom")


def Eq(s: Term, t: Term) -> Formula:
    return Formula("eq", terms=(s, t))


def And(a: Formula, b: Formula) -> Formula:
    return Formula("and", (a, b))


def Or(a: Formula, b: Formula) -> Formula:
    return Formula("or", (a, b))


def Imp(a: Formula, b: Formula) -> Formula:
    return Formula("imp", (a, b))


def All(name: str, body: Formula) -> Formula:
    return Formula("forall", (body,), name=name)


def Not(a: Formula) -> Formula:
    return Imp(a, BOT)


def ffv(f: Formula) -> set[str]:
    result = set().union(*(term_fv(t) for t in f.terms), *(ffv(a) for a in f.args))
    return result - {f.name} if f.tag == "forall" else result


def all_names(f: Formula) -> set[str]:
    result = set().union(*(term_fv(t) for t in f.terms), *(all_names(a) for a in f.args))
    return result | {f.name} if f.tag == "forall" else result


def fsubst(f: Formula, name: str, replacement: Term) -> Formula:
    if f.tag == "forall":
        binder, body = f.name, f.args[0]
        if binder == name:
            return f
        if binder in term_fv(replacement) and name in ffv(body):
            forbidden = all_names(body) | term_fv(replacement) | {name}
            index = 0
            fresh = f"{binder}_{index}"
            while fresh in forbidden:
                index += 1
                fresh = f"{binder}_{index}"
            body = fsubst(body, binder, V(fresh))
            binder = fresh
        return All(binder, fsubst(body, name, replacement))
    return Formula(
        f.tag,
        tuple(fsubst(a, name, replacement) for a in f.args),
        tuple(term_subst(t, name, replacement) for t in f.terms),
        f.name,
    )


def formula_size(f: Formula) -> int:
    # Binder declarations cost one quantifier node, not a second variable node.
    return 1 + sum(formula_size(a) for a in f.args) + sum(term_size(t) for t in f.terms)


def show_formula(f: Formula) -> str:
    if f.tag == "bottom":
        return "false"
    if f.tag == "eq":
        return f"({show_term(f.terms[0])} = {show_term(f.terms[1])})"
    if f.tag == "forall":
        return f"forall {f.name}. ({show_formula(f.args[0])})"
    if f.tag in {"and", "or", "imp"}:
        op = {"and": "AND", "or": "OR", "imp": "IMPLIES"}[f.tag]
        return f"({show_formula(f.args[0])} {op} {show_formula(f.args[1])})"
    if f.tag == "opaque":
        return f"{f.name}({', '.join(show_term(t) for t in f.terms)})"
    raise ValueError(f"unknown formula tag: {f.tag}")


N, A, STATE = V("n"), V("a"), V("v")
ONE = S(ZERO)
DELTA = Eq(ZERO, ONE)
SEPARATION = Not(DELTA)


def I(name: str, n: Term, a: Term) -> Term:
    return D(name, S(n), a)


def pred(n: Term) -> Term:
    return D("succ", n, ZERO)


def add(x: Term, y: Term) -> Term:
    return I("succ", y, x)


def sub(x: Term, y: Term) -> Term:
    return I("pred", y, x)


def z(n: Term, a: Term) -> Term:
    return I("zero", n, a)


def select(c: Term, a: Term, b: Term) -> Term:
    return add(z(c, a), z(z(c, ONE), b))


def chi(r: Term) -> Term:
    return select(r, ONE, select(pred(r), ZERO, ONE))


def eqbit(x: Term, y: Term) -> Term:
    return chi(sub(S(x), y))


def make_registry() -> Descriptors:
    ds = Descriptors()
    ds.add("id", STATE)
    ds.add("zero", ZERO)
    ds.add("one", ONE)
    ds.add("succ", S(STATE))
    ds.add("succ2", S(S(STATE)))
    ds.add("pred", pred(STATE))
    ds.add("double", add(STATE, STATE))
    return ds


def dynamic(ds: Descriptors, s: Term, t: Term) -> Formula:
    for term in (s, t):
        ds.validate_term(term)
        if not term_fv(term) <= {"n", "a"}:
            raise ValueError("a dynamic term has another free variable")
    return And(Or(Eq(N, ZERO), Eq(s, t)), SEPARATION)


def reset(ds: Descriptors, name: str) -> Formula:
    if name not in ds.bodies:
        raise ValueError("unknown descriptor")
    return All("n", Eq(D(name, D("one", N, ZERO), A), A))


def transition(ds: Descriptors, name: str) -> Formula:
    return All("n", Eq(D(name, S(S(A)), N), ds.apply(name, D(name, S(A), N))))


def axiom(f: Formula) -> Formula:
    return All("a", Imp(All("n", Imp(f, fsubst(f, "n", S(N)))), All("n", f)))


class Evaluator:
    """The intended standard-N delayed-iteration semantics only."""

    def __init__(self, descriptors: Descriptors) -> None:
        self.ds = descriptors

    @lru_cache(maxsize=None)
    def update(self, name: str, value: int) -> int:
        return self.term(self.ds.bodies[name], {"v": value})

    def term(self, t: Term, env: dict[str, int]) -> int:
        if t.tag == "var":
            return env[t.name]
        if t.tag == "zero":
            return 0
        if t.tag == "succ":
            return self.term(t.args[0], env) + 1
        if t.tag == "delay":
            counter = self.term(t.args[0], env)
            value = self.term(t.args[1], env)
            if counter < 0 or value < 0:
                raise ValueError("the standard interpretation uses natural numbers")
            for _ in range(max(counter - 1, 0)):
                value = self.update(t.name, value)
            return value
        raise ValueError("unknown term tag")


# Small propositional Kripke checks.  Their scope is stated in the output.
# An expression is an atom string, ('false',), or (connective, child, ...).
def atoms(p: object) -> set[str]:
    if isinstance(p, str):
        return {p}
    return set().union(*(atoms(q) for q in p[1:]))


def force(p: object, world: int, future: tuple[frozenset[int], ...], val: dict) -> bool:
    if isinstance(p, str):
        return world in val[p]
    op = p[0]
    if op == "false":
        return False
    if op == "and":
        return force(p[1], world, future, val) and force(p[2], world, future, val)
    if op == "or":
        return force(p[1], world, future, val) or force(p[2], world, future, val)
    if op == "imp":
        return all(not force(p[1], w, future, val) or force(p[2], w, future, val)
                   for w in future[world])
    raise ValueError("unknown propositional connective")


def kripke_checks() -> dict:
    imp = lambda a, b: ("imp", a, b)
    both = lambda a, b: ("and", a, b)
    either = lambda a, b: ("or", a, b)
    neg = lambda a: imp(a, ("false",))
    top = imp("X", "X")
    kernels = {
        "separation_conjunct_propagates": imp(imp("A", "B"),
                                             imp(both("K", "A"), both("K", "B"))),
        "rooted_equation_progress": imp(both(imp("Z", "E"), imp("E", "T")),
                                       imp(either("Z", "E"), "T")),
        "rooted_equation_conclusion": imp(imp("Z", "E"), imp(either("Z", "E"), "E")),
        "stationary_extraction": imp(imp(imp("X", "X"), "X"), "X"),
        "tautological_rooted_step_retains_separation": imp(both("K", either("Z", top)),
                                                           both("K", either("W", top))),
        "decidable_implication_truth_table": imp(
            both(either("A", neg("A")), either("B", neg("B"))),
            both(imp(imp("A", "B"), either(neg("A"), "B")),
                 imp(either(neg("A"), "B"), imp("A", "B")))),
    }
    frames = {
        "one_world": (frozenset({0}),),
        "two_world_chain": (frozenset({0, 1}), frozenset({1})),
        "three_world_chain": (frozenset({0, 1, 2}), frozenset({1, 2}), frozenset({2})),
        "three_world_fork": (frozenset({0, 1, 2}), frozenset({1}), frozenset({2})),
    }
    counts = {}
    for label, expr in kernels.items():
        count = 0
        for future in frames.values():
            worlds = range(len(future))
            subsets = [frozenset(w for w in worlds if bits & (1 << w))
                       for bits in range(1 << len(future))]
            upsets = [u for u in subsets if all(future[w] <= u for w in u)]
            names = sorted(atoms(expr))
            for choices in itertools.product(upsets, repeat=len(names)):
                valuation = dict(zip(names, choices))
                for world in worlds:
                    assert force(expr, world, future, valuation), (label, future, valuation, world)
                    count += 1
        counts[label] = count
    return {
        "frames": list(frames),
        "forced_instances_per_kernel": counts,
        "scope": "Finite propositional diagnostics on four frames; not a proof for all Kripke models.",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    ds = make_registry()
    ev = Evaluator(ds)

    def rejected(action) -> None:
        try:
            action()
        except ValueError:
            return
        raise AssertionError("an invalid construction was accepted")

    rejected(lambda: ds.add("bad_parameter", A))
    rejected(lambda: ds.add("bad_self", D("bad_self", STATE, ZERO)))
    rejected(lambda: ds.add("bad_forward", D("not_declared", STATE, ZERO)))
    rejected(lambda: ds.add("id", STATE))
    rejected(lambda: ds.add("duplicate_body", STATE))
    rejected(lambda: dynamic(ds, V("x"), ZERO))
    rejected(lambda: dynamic(ds, D("missing", N, A), ZERO))
    rejected(lambda: dynamic(ds, Term("succ"), ZERO))
    rejected(lambda: ds.add("bad_constructor", Term("universal_evaluator", (STATE,))))
    rejection_checks = 9

    before = dict(ds.bodies)
    active = D("pred", N, A)
    assert term_subst(active, "n", S(N)) == D("pred", S(N), A)
    assert term_subst(active, "v", S(STATE)) == active
    assert ds.bodies == before
    capture_example = All("n", Eq(V("x"), N))
    capture_result = fsubst(capture_example, "x", N)
    assert capture_result.name != "n" and ffv(capture_result) == {"n"}
    assert capture_result == All("n_0", Eq(N, V("n_0")))
    substitution_checks = 5

    pairs = [
        (ZERO, ZERO), (N, N), (N, ZERO), (N, S(pred(N))),
        (I("succ", N, ZERO), N), (pred(S(N)), N),
        (add(N, A), add(A, N)), (sub(S(N), S(A)), sub(N, A)),
        (eqbit(N, A), ZERO), (z(N, A), ZERO),
    ]
    matrices = [(f"G_{i}", dynamic(ds, s, t)) for i, (s, t) in enumerate(pairs)]
    for name in ds.bodies:
        matrices.extend([(f"R_{name}", reset(ds, name)),
                         (f"T_{name}", transition(ds, name))])
    examples = []
    for label, f in matrices:
        generated = axiom(f)
        assert not ffv(generated), (label, ffv(generated))
        assert all_names(generated) <= {"n", "a"}, (label, all_names(generated))
        if label.startswith(("R_", "T_")):
            assert "n" not in ffv(f)
            assert fsubst(f, "n", S(N)) == f
            substitution_checks += 2
        examples.append({"label": label, "matrix_nodes": formula_size(f),
                         "axiom_nodes": formula_size(generated),
                         "matrix": show_formula(f), "axiom": show_formula(generated)})
    assert ds.bodies == before

    opaque_f = Formula("opaque", terms=(N, A), name="F")
    assert formula_size(axiom(opaque_f)) == 15
    old_dynamic = Imp(Or(Formula("opaque", terms=(ZERO, A), name="A"), DELTA),
                      Formula("opaque", terms=(N, A), name="A"))
    new_dynamic = And(Or(Eq(N, ZERO), Eq(V("s"), V("t"))), SEPARATION)
    reset_atom = Eq(D("h", D("one", N, ZERO), A), A)
    # An opaque unary h is represented by a successor-shaped unary node solely
    # for this syntactic subtotal. Actual transition() inserts the actual body.
    next_h_opaque = Eq(D("h", S(S(N)), A), S(D("h", S(N), A)))
    counts = {
        "outer_P_with_opaque_binary_F": formula_size(axiom(opaque_f)),
        "old_G_with_opaque_binary_A": formula_size(old_dynamic),
        "new_G_with_two_single_node_term_holes": formula_size(new_dynamic),
        "reset_atom": formula_size(reset_atom),
        "reset_universal_closure": formula_size(All("a", All("n", reset_atom))),
        "next_atom_with_opaque_unary_h": formula_size(next_h_opaque),
        "next_universal_closure_with_opaque_unary_h": formula_size(All("a", All("n", next_h_opaque))),
    }
    assert counts == {
        "outer_P_with_opaque_binary_F": 15,
        "old_G_with_opaque_binary_A": 12,
        "new_G_with_two_single_node_term_holes": 14,
        "reset_atom": 7,
        "reset_universal_closure": 9,
        "next_atom_with_opaque_unary_h": 11,
        "next_universal_closure_with_opaque_unary_h": 13,
    }

    semantic = {"reset": 0, "next": 0, "predecessor": 0,
                "selector": 0, "equality_bit": 0, "delay_normalization": 0}
    for name in ds.bodies:
        for n, a in itertools.product(range(4), repeat=2):
            env = {"n": n, "a": a}
            assert ev.term(D(name, D("one", N, ZERO), A), env) == a
            semantic["reset"] += 1
            assert ev.term(D(name, S(S(N)), A), env) == ev.term(ds.apply(name, D(name, S(N), A)), env)
            semantic["next"] += 1
            assert ev.term(D(name, N, A), env) == ev.term(I(name, pred(N), A), env)
            semantic["delay_normalization"] += 1
    for n in range(12):
        assert ev.term(pred(N), {"n": n}) == max(n - 1, 0)
        assert ev.term(pred(S(N)), {"n": n}) == n
        semantic["predecessor"] += 2
    selector_term = select(N, A, V("b"))
    for n, a, b in itertools.product(range(4), range(3), range(3)):
        assert ev.term(selector_term, {"n": n, "a": a, "b": b}) == (a if n == 0 else b)
        semantic["selector"] += 1
    equality_term = eqbit(N, A)
    for n, a in itertools.product(range(8), repeat=2):
        assert ev.term(equality_term, {"n": n, "a": a}) == (0 if n == a else 1)
        semantic["equality_bit"] += 1

    product_point = (0, 1)
    product_pred = tuple(max(x - 1, 0) for x in product_point)
    product_successor_pred = tuple(x + 1 for x in product_pred)
    assert product_point != (0, 0) and product_point != product_successor_pred

    result = {
        "status": "passed",
        "descriptors": {name: show_term(body) for name, body in ds.bodies.items()},
        "schema": {
            "generated_examples": len(examples),
            "closed_with_only_names_n_a": len(examples),
            "rejected_invalid_constructions": rejection_checks,
            "substitution_and_scope_assertions": substitution_checks,
            "dynamic_grammar": "((n=0) OR (s=t)) AND ((0=S(0)) IMPLIES false)",
            "stationary_grammars": ["forall n. D_h(D_one(n,0),a)=a",
                                    "forall n. D_h(S(S(a)),n)=h(D_h(S(a),n))"],
            "descriptor_policy": "Finite earlier unary bodies; descriptor names opaque to active substitution.",
        },
        "partial_node_counts": counts,
        "counting_scope": (
            "One node per variable, constant, active application, connective, quantifier; "
            "bound declarations not double-counted. Descriptor bodies and grammar instructions "
            "are excluded from these labeled subtotals. Old G uses an opaque binary A; new G "
            "uses two one-node term holes. The result is NOT a total-description-length record."
        ),
        "standard_N_diagnostics": semantic,
        "semantic_scope": "Bounded intended-model evaluations, not proofs for arbitrary or nonstandard models.",
        "kripke_diagnostics": kripke_checks(),
        "product_counterexample_witness": {
            "point": product_point,
            "predecessor": product_pred,
            "successor_of_predecessor": product_successor_pred,
            "coverage_fails": True,
            "scope": "The written proof establishes all equation-induction instances in N x N; this only checks its witness.",
        },
        "formalization_scope": "No proof-assistant certificate or end-to-end bi-interpretability proof is asserted by this script.",
    }
    (args.output_dir / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    lines = ["GENERATED FINITE-SYNTAX EXAMPLES", "", "Descriptors (stored bodies):"]
    lines += [f"  {name}(v) := {show_term(body)}" for name, body in ds.bodies.items()]
    for item in examples:
        lines += ["", item["label"], f"Matrix [{item['matrix_nodes']} active AST nodes]:",
                  item["matrix"], f"Axiom [{item['axiom_nodes']} active AST nodes]:", item["axiom"]]
    (args.output_dir / "generated_examples.txt").write_text("\n".join(lines) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
