/-
Constructive local kernel for rooted equation propagation.

The carrier is arbitrary. Propagation and induction below are hypotheses for
the particular displayed schematic instances, not axioms quantifying over all
semantic functions or predicates. This file does not formalize the language
of arithmetic, axiom admission, numerical pairing, or bi-interpretability.

The Formula datatype only checks the propositional truth-term compiler after
the arithmetic equality-bit specifications have been supplied. It does not
assume a decision procedure for arbitrary quantified formulas.

Tested with Lean 4.19.0. Only Init is imported. There is no classical reasoning,
choice, sorry, or use of induction on Lean's natural numbers.
-/
import Init

namespace RootedKernel

universe u v
variable {A : Type u}

def InductionAt (zero : A) (succ : A → A) (P : A → Prop) : Prop :=
  P zero → (∀ n, P n → P (succ n)) → ∀ n, P n

def Propagation (succ : A → A) (F : A → A → Prop) : Prop :=
  ∀ a, (∀ n, F n a → F (succ n) a) → ∀ n, F n a

def Rooted (zero : A) (delta : Prop) (E : A → A → Prop) (n a : A) : Prop :=
  (n = zero ∨ E n a) ∧ ¬ delta

/-- Stationary matrices supply computation without any induction. -/
theorem stationary
    (zero : A) (succ : A → A) (P : A → Prop)
    (propagate : Propagation succ (fun _ a => P a)) :
    ∀ a, P a := by
  intro a
  exact propagate a (fun _ hp => hp) zero

/-- The reflexive equation is already enough to obtain separation. -/
theorem rooted_separation
    (zero : A) (succ : A → A) (delta : Prop)
    (propagate : Propagation succ (Rooted zero delta (fun n _ => n = n))) :
    ¬ delta := by
  have allRooted : ∀ n, Rooted zero delta (fun n _ => n = n) n zero := by
    apply propagate zero
    intro n hn
    exact ⟨Or.inr rfl, hn.2⟩
  exact (allRooted zero).2

/-- One rooted equation instance recovers precisely that equation's
    induction instance, with one unchanged parameter. -/
theorem rooted_equation_induction
    (zero : A) (succ : A → A) (delta : Prop)
    (left right : A → A → A)
    (propagate : Propagation succ
      (Rooted zero delta (fun n a => left n a = right n a))) :
    ∀ a, InductionAt zero succ (fun n => left n a = right n a) := by
  intro a hbase hstep n
  have allRooted : ∀ m,
      Rooted zero delta (fun k b => left k b = right k b) m a := by
    apply propagate a
    intro m hm
    have eqHere : left m a = right m a := by
      cases hm.1 with
      | inl hmzero => simpa only [hmzero] using hbase
      | inr heq => exact heq
    exact ⟨Or.inr (hstep m eqHere), hm.2⟩
  cases (allRooted n).1 with
  | inl hnzero => simpa only [hnzero] using hbase
  | inr heq => exact heq

/-- Constructor coverage comes from the admitted equation n = S(p(n)).
    Its successor case computes; no decidability hypothesis is present. -/
theorem rooted_coverage
    (zero : A) (succ pred : A → A) (delta : Prop)
    (predSucc : ∀ n, pred (succ n) = n)
    (propagate : Propagation succ
      (Rooted zero delta (fun n _ => n = succ (pred n)))) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  intro n
  have allRooted : ∀ m,
      Rooted zero delta (fun k _ => k = succ (pred k)) m zero := by
    apply propagate zero
    intro m hm
    exact ⟨Or.inr (congrArg succ (predSucc m).symm), hm.2⟩
  exact (allRooted n).1

/-- Conversely, QFI for this one fixed rooted matrix proves its propagation
    instance once separation is available. -/
theorem rooted_from_induction
    (zero : A) (succ : A → A) (delta : Prop) (E : A → A → Prop)
    (separate : ¬ delta)
    (ind : ∀ a, InductionAt zero succ (fun n => Rooted zero delta E n a)) :
    Propagation succ (Rooted zero delta E) := by
  intro a hstep
  exact ind a ⟨Or.inl rfl, separate⟩ hstep

/-- Coverage gives a constructive zero decision after successor separation. -/
theorem zero_decision
    (zero : A) (succ pred : A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (succNonzero : ∀ n, succ n ≠ zero) :
    ∀ n, n = zero ∨ n ≠ zero := by
  intro n
  cases coverage n with
  | inl hz => exact Or.inl hz
  | inr hs =>
    apply Or.inr
    intro hz
    exact succNonzero (pred n) (hs.symm.trans hz)

/-- A zero/one valued term represents a fixed proposition. -/
def BitSpec (zero one : A) (P : Prop) (bit : A) : Prop :=
  (bit = zero ∨ bit = one) ∧ (P ↔ bit = zero)

theorem bit_true
    (zero one : A) (P : Prop) (hp : P) : BitSpec zero one P zero := by
  exact ⟨Or.inl rfl, ⟨fun _ => rfl, fun _ => hp⟩⟩

theorem bit_false
    (zero one : A) (separate : zero ≠ one) (P : Prop) (hp : ¬ P) :
    BitSpec zero one P one := by
  refine ⟨Or.inr rfl, ⟨?_, ?_⟩⟩
  · intro h
    exact False.elim (hp h)
  · intro h
    exact False.elim (separate h.symm)

theorem bit_one_false
    (zero one : A) (separate : zero ≠ one) (P : Prop) (bit : A)
    (spec : BitSpec zero one P bit) (h : bit = one) : ¬ P := by
  intro hp
  exact separate ((spec.2.mp hp).symm.trans h)

theorem bit_transport
    (zero one : A) (P Q : Prop) (bit : A)
    (spec : BitSpec zero one P bit) (forward : Q → P) (backward : P → Q) :
    BitSpec zero one Q bit := by
  exact ⟨spec.1, ⟨fun h => spec.2.mp (forward h), fun h => backward (spec.2.mpr h)⟩⟩

theorem bit_conjunction
    (zero one : A) (separate : zero ≠ one) (choose : A → A → A → A)
    (chooseZero : ∀ x y, choose zero x y = x)
    (chooseOne : ∀ x y, choose one x y = y)
    (P Q : Prop) (p q : A)
    (pspec : BitSpec zero one P p) (qspec : BitSpec zero one Q q) :
    BitSpec zero one (P ∧ Q) (choose p q one) := by
  cases pspec.1 with
  | inl hz =>
    rw [hz, chooseZero q one]
    have hp : P := pspec.2.mpr hz
    exact bit_transport zero one Q (P ∧ Q) q qspec
      (fun h => h.2) (fun h => ⟨hp, h⟩)
  | inr ho =>
    rw [ho, chooseOne q one]
    have hp : ¬ P := bit_one_false zero one separate P p pspec ho
    exact bit_false zero one separate (P ∧ Q) (fun h => hp h.1)

theorem bit_disjunction
    (zero one : A) (separate : zero ≠ one) (choose : A → A → A → A)
    (chooseZero : ∀ x y, choose zero x y = x)
    (chooseOne : ∀ x y, choose one x y = y)
    (P Q : Prop) (p q : A)
    (pspec : BitSpec zero one P p) (qspec : BitSpec zero one Q q) :
    BitSpec zero one (P ∨ Q) (choose p zero q) := by
  cases pspec.1 with
  | inl hz =>
    rw [hz, chooseZero zero q]
    exact bit_true zero one (P ∨ Q) (Or.inl (pspec.2.mpr hz))
  | inr ho =>
    rw [ho, chooseOne zero q]
    have hp : ¬ P := bit_one_false zero one separate P p pspec ho
    apply bit_transport zero one Q (P ∨ Q) q qspec
    · intro h
      cases h with
      | inl h => exact False.elim (hp h)
      | inr h => exact h
    · exact Or.inr

theorem bit_implication
    (zero one : A) (separate : zero ≠ one) (choose : A → A → A → A)
    (chooseZero : ∀ x y, choose zero x y = x)
    (chooseOne : ∀ x y, choose one x y = y)
    (P Q : Prop) (p q : A)
    (pspec : BitSpec zero one P p) (qspec : BitSpec zero one Q q) :
    BitSpec zero one (P → Q) (choose p q zero) := by
  cases pspec.1 with
  | inl hz =>
    rw [hz, chooseZero q zero]
    have hp : P := pspec.2.mpr hz
    exact bit_transport zero one Q (P → Q) q qspec
      (fun h => h hp) (fun h _ => h)
  | inr ho =>
    rw [ho, chooseOne q zero]
    have hp : ¬ P := bit_one_false zero one separate P p pspec ho
    exact bit_true zero one (P → Q) (fun h => False.elim (hp h))

/-- Finite propositional syntax only; atoms stand for already specified
    arithmetic equations, with their numerical equality-bit witnesses. -/
inductive Formula (Atom : Type v) where
  | atom : Atom → Formula Atom
  | falsum : Formula Atom
  | conj : Formula Atom → Formula Atom → Formula Atom
  | disj : Formula Atom → Formula Atom → Formula Atom
  | impl : Formula Atom → Formula Atom → Formula Atom

def Formula.holds {Atom : Type v} (atomProp : Atom → Prop) : Formula Atom → Prop
  | .atom i => atomProp i
  | .falsum => False
  | .conj p q => p.holds atomProp ∧ q.holds atomProp
  | .disj p q => p.holds atomProp ∨ q.holds atomProp
  | .impl p q => p.holds atomProp → q.holds atomProp

def Formula.truthTerm {Atom : Type v}
    (zero one : A) (choose : A → A → A → A) (atomBit : Atom → A) :
    Formula Atom → A
  | .atom i => atomBit i
  | .falsum => one
  | .conj p q =>
    choose (p.truthTerm zero one choose atomBit) (q.truthTerm zero one choose atomBit) one
  | .disj p q =>
    choose (p.truthTerm zero one choose atomBit) zero (q.truthTerm zero one choose atomBit)
  | .impl p q =>
    choose (p.truthTerm zero one choose atomBit) (q.truthTerm zero one choose atomBit) zero

/-- Structural correctness of the finite truth-term compiler. -/
theorem compiled_truth {Atom : Type v}
    (zero one : A) (separate : zero ≠ one) (choose : A → A → A → A)
    (chooseZero : ∀ x y, choose zero x y = x)
    (chooseOne : ∀ x y, choose one x y = y)
    (atomProp : Atom → Prop) (atomBit : Atom → A)
    (atomSpec : ∀ i, BitSpec zero one (atomProp i) (atomBit i)) :
    ∀ f : Formula Atom,
      BitSpec zero one (f.holds atomProp) (f.truthTerm zero one choose atomBit) := by
  intro f
  induction f with
  | atom i => exact atomSpec i
  | falsum => exact bit_false zero one separate False (fun h => h)
  | conj p q hp hq =>
    exact bit_conjunction zero one separate choose chooseZero chooseOne
      (p.holds atomProp) (q.holds atomProp)
      (p.truthTerm zero one choose atomBit) (q.truthTerm zero one choose atomBit) hp hq
  | disj p q hp hq =>
    exact bit_disjunction zero one separate choose chooseZero chooseOne
      (p.holds atomProp) (q.holds atomProp)
      (p.truthTerm zero one choose atomBit) (q.truthTerm zero one choose atomBit) hp hq
  | impl p q hp hq =>
    exact bit_implication zero one separate choose chooseZero chooseOne
      (p.holds atomProp) (q.holds atomProp)
      (p.truthTerm zero one choose atomBit) (q.truthTerm zero one choose atomBit) hp hq

/-- The representation of equality by such a bit yields its decidability.
    The arithmetic derivation of bitSpec is deliberately an explicit input. -/
theorem equality_decision
    (zero one : A) (separate : zero ≠ one) (eqBit : A → A → A)
    (eqSpec : ∀ x y, BitSpec zero one (x = y) (eqBit x y)) :
    ∀ x y : A, x = y ∨ x ≠ y := by
  intro x y
  cases (eqSpec x y).1 with
  | inl hz => exact Or.inl ((eqSpec x y).2.mpr hz)
  | inr ho => exact Or.inr (bit_one_false zero one separate (x = y)
      (eqBit x y) (eqSpec x y) ho)

/-- Transfer the one equation-induction instance for a compiled truth term
    back to the one quantifier-free formula it represents. -/
theorem formula_induction_from_equation
    (zero : A) (succ : A → A) (P : A → A → Prop) (bit : A → A → A)
    (correct : ∀ n a, P n a ↔ bit n a = zero)
    (ind : ∀ a, InductionAt zero succ (fun n => bit n a = zero)) :
    ∀ a, InductionAt zero succ (fun n => P n a) := by
  intro a hbase hstep n
  have eqBase : bit zero a = zero := (correct zero a).mp hbase
  have eqStep : ∀ m, bit m a = zero → bit (succ m) a = zero := by
    intro m hm
    exact (correct (succ m) a).mp (hstep m ((correct m a).mpr hm))
  exact (correct n a).mpr (ind a eqBase eqStep n)

#print axioms stationary
#print axioms rooted_separation
#print axioms rooted_equation_induction
#print axioms rooted_coverage
#print axioms rooted_from_induction
#print axioms zero_decision
#print axioms bit_true
#print axioms bit_false
#print axioms bit_one_false
#print axioms bit_transport
#print axioms bit_conjunction
#print axioms bit_disjunction
#print axioms bit_implication
#print axioms compiled_truth
#print axioms equality_decision
#print axioms formula_induction_from_equation

end RootedKernel
