PRA FROM ROOTED EQUATIONS
Classical and intuitionistic first-order presentations
Research prepared for Vladimir Reshetnikov, 1 November 2026.

This package gives a simplification of the dynamic matrix generator in
the six PRA drafts at ProveIt commit
13300d26dac24e7e6b75fe38fd21fb5b5d416d41.

The computational language and two Reset/Next schemes are inherited from
pra_delayed_iteration_2026-11-01(1).zip. The new dynamic matrix is

  F(n,a) = ((n=0) OR (s(n,a)=t(n,a))) AND NOT(0=S(0)).

Only two terms s,t are supplied. No quantifier-free formula is supplied,
and no substitution of zero into an input formula is required.

The report proves whole-domain identity bi-interpretations with the
matching classical or intuitionistic first-order PRA. The reduction is
in the finite generator specification; no absolute minimum is claimed.

See report.pdf and report.tex for the complete argument and bibliography.
AXIOMS.txt is the standalone exact specification.
The checks and formal directories distinguish executable diagnostics from
the limited Lean-checked kernel. The full bi-interpretation is a written
mathematical proof, not a machine-checked first-order metatheorem.

REPRODUCING THE DELIVERABLE

  python3 checks/check_schema.py
  python3 build.py
  python3 build.py --lean /absolute/path/to/lean

The build uses Python 3, pdflatex with the packages named in report.tex,
and optionally Lean 4.19.0. No Mathlib is required. It runs three LaTeX
passes, copies report.pdf into this directory, and records diagnostics in
audit/. It does not download or install dependencies. To check only the
Lean kernel, run: lean formal/RootedKernel.lean

PACKAGE CONTENTS

  report.tex, sections/*.tex   Complete mathematical article
  report.pdf                  Compiled article
  AXIOMS.txt                  Standalone exact specification
  checks/check_schema.py      Finite syntax and bounded diagnostics
  checks/results.json         Diagnostic receipt and labeled node counts
  checks/generated_examples.txt
                              Example instances of the exact generator
  formal/RootedKernel.lean     Local constructive kernel
  formal/SCOPE.txt             What is and is not formalized
  audit/source_manifest.json  Source revision and archive fingerprints
  audit/independent_review.txt
                              Mathematical review scope
  build.py                    Reproducible build helper
  SHA256SUMS.txt              Package integrity hashes
