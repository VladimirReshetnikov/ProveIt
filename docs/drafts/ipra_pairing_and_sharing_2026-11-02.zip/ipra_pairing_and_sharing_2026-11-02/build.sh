#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 artifacts/verify.py > artifacts/checks.json
latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex
