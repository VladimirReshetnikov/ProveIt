iPRA: A 45-NODE PAIRING KERNEL AND EXPLICIT TERM SHARING
=====================================================
Prepared for Vladimir Reshetnikov, 2 November 2026.

START HERE
report.pdf contains the complete mathematical report and constructive proofs.
AXIOMS.txt is a standalone exact specification of the optimized reference
theory, including logical prices, normalization, admission and sharing.

MAIN RESULTS
Four pairing sentences totaling 45 fully counted nodes replace the former
seven-equation 176-node arithmetic bootstrap. A right coordinate that resets
to 0 or advances by 1 transfers diagonal equation induction to full induction.
Direct eta eliminates every pretransfer induction step. The boundary scheme
only needs equations in which every active x is inside native R(x).

The three new arithmetic primitives are proved internally canonical.
Both full-carrier interpretation composites are the identity, so the result
is ordinary intuitionistic bi-interpretability and equiconsistency with iPRA.

Explicit equality factoring is independently valid in pure intuitionistic
equality logic. It never enlarges an axiom and produces unbounded strict
savings over the old frontier, paying for all variables and definitions.

CONTENTS
report.tex and sections/*.tex    Complete LaTeX source.
report.pdf                      Compiled report.
AXIOMS.txt                      Exact reference theory.
artifacts/verify.py              Fresh Python syntax/count checker.
artifacts/checks.json            Recorded successful check results.
artifacts/VERIFICATION.txt       Scope and limitations of those checks.
provenance/source_manifest.json  Exact source paths, URLs, bytes and hashes.
provenance/draft_audit.csv        Current-vs-archived comparison.
build.sh                        Re-run checker and compile report.
SHA256SUMS.txt                   Delivered-file hashes (excluding itself).

REBUILD
Requirements: Python 3 standard library; TeX Live with latexmk/pdflatex and
the ordinary LaTeX packages named in report.tex.
From this directory run:
    bash build.sh
Or independently:
    python3 artifacts/verify.py > artifacts/checks.json
    latexmk -pdf -interaction=nonstopmode -halt-on-error report.tex

VERIFICATION STATUS
All supplied syntax/count tests passed. They include reconstruction
certificates for factoring, frozen-descriptor checks, exact module counts,
the45-node kernel, normalization and the strong projection admission filter.
The PDF was compiled and rendered for visual inspection.

The generic theorems are written mathematical proofs, not a fully mechanized
Lean/Rocq verification. Finite numerical diagnostics do not prove statements
about nonstandard models. The source archives were hash verified; no source
package executable was run. See artifacts/VERIFICATION.txt for exact scope.

COUNTING QUALIFICATIONS
45 counts the pairing kernel, not all logic or infinite schemes. The new
primitive signature and changed boundary family are disclosed. Transferred
proof packets may use larger projected equations. The universal nonincrease
claim concerns the separate equality-factoring transformation in each
presentation's original signature and logic. No absolute shortestness theorem
is claimed without a fixed global encoding and objective.
