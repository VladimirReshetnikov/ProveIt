#!/usr/bin/env python3
"""Fresh syntactic checks for factored iPRA axioms.

No draft executable is imported or run.  This program checks finite AST
identities, exact node counts, and reconstruction certificates.  It is
not a formal verification of the mathematical iPRA interpretation proof.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
import json
from math import isqrt
from typing import Iterable, Mapping


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    name: str = ""
    descriptor: "Term | None" = None


@dataclass(frozen=True)
class Formula:
    tag: str
    args: tuple["Formula | Term", ...]
    bound: str = ""


def var(name: str) -> Term:
    return Term("var", name=name)


ZERO = Term("zero")


def succ(t: Term) -> Term:
    return Term("succ", (t,))


def rec(h: Term, n: Term, a: Term) -> Term:
    return Term("rec", (n, a), descriptor=h)


def term_size(t: Term) -> int:
    # The stored descriptor is charged fully at EVERY recursor occurrence.
    return 1 + sum(term_size(c) for c in t.args) + (
        term_size(t.descriptor) if t.descriptor is not None else 0
    )


def formula_size(f: Formula) -> int:
    # A binder's variable annotation is not an additional AST occurrence.
    return 1 + sum(term_size(a) if isinstance(a, Term) else formula_size(a)
                   for a in f.args)


def eq(s: Term, t: Term) -> Formula:
    return Formula("eq", (s, t))


def conj(a: Formula, b: Formula) -> Formula:
    return Formula("and", (a, b))


def impl(a: Formula, b: Formula) -> Formula:
    return Formula("implies", (a, b))


def k3(a: Formula, b: Formula, c: Formula) -> Formula:
    return Formula("K3", (a, b, c))


def k4(a: Formula, b: Formula, c: Formula, d: Formula) -> Formula:
    return Formula("K4", (a, b, c, d))


def bind(kind: str, name: str, f: Formula) -> Formula:
    assert kind in {"forall", "exists"}
    return Formula(kind, (f,), name)


def forall(names: Iterable[str], f: Formula) -> Formula:
    for name in reversed(tuple(names)):
        f = bind("forall", name, f)
    return f


def active_vars(t: Term) -> set[str]:
    # Descriptor variables are lexical program slots, not active variables.
    return ({t.name} if t.tag == "var" else set()).union(
        *(active_vars(c) for c in t.args)
    )


def subst(t: Term, replacements: Mapping[str, Term]) -> Term:
    if t.tag == "var":
        return replacements.get(t.name, t)
    return Term(t.tag, tuple(subst(c, replacements) for c in t.args),
                t.name, t.descriptor)


V, W = var("v"), var("w")
A, N, U, X, Y = (var(s) for s in ("a", "n", "u", "x", "y"))


def q(n: Term, a: Term) -> Term:
    return rec(W, n, a)


def z(n: Term, a: Term) -> Term:
    return rec(ZERO, n, a)


def pred(n: Term) -> Term:
    return q(n, ZERO)


def choose(n: Term, a: Term, b: Term) -> Term:
    return q(z(n, succ(a)), b)


def add(a: Term, b: Term) -> Term:
    return rec(succ(V), b, a)


def minus(a: Term, b: Term) -> Term:
    return rec(pred(V), b, a)


def pair(a: Term, n: Term) -> Term:
    return Term("B", (a, n))


def left(t: Term) -> Term:
    return Term("L", (t,))


def right(t: Term) -> Term:
    return Term("R", (t,))


def error_term(s: Term, t: Term) -> Term:
    return q(minus(succ(s), t), succ(ZERO))


def equality_bit(s: Term, t: Term) -> Term:
    return z(error_term(s, t), succ(ZERO))


def triangular_term(t: Term) -> Term:
    return rec(add(V, succ(W)), t, ZERO)


def diagonal_index(t: Term) -> Term:
    body = add(V, equality_bit(succ(W), triangular_term(succ(V))))
    return rec(body, t, ZERO)


def seven_equations() -> tuple[Formula, ...]:
    return (
        eq(add(succ(A), X), succ(add(A, X))),
        eq(minus(succ(A), succ(X)), minus(A, X)),
        eq(minus(add(A, X), X), A),
        eq(minus(add(X, A), X), A),
        eq(minus(A, add(X, A)), ZERO),
        eq(choose(minus(A, X), A, add(X, minus(A, X))), A),
        eq(z(minus(X, A), error_term(
            diagonal_index(add(triangular_term(A), X)), A)), ZERO),
    )


def pair_scaffold() -> tuple[Formula, ...]:
    """Earlier 42-node reference scaffold; eta required induction support."""
    return (
        eq(pair(ZERO, ZERO), ZERO),
        forall(("a", "n"), eq(succ(pair(succ(A), N)), pair(A, succ(N)))),
        forall(("n",), eq(succ(pair(ZERO, N)), pair(succ(N), ZERO))),
        forall(("a", "n"), conj(eq(left(pair(A, N)), A),
                                   eq(right(pair(A, N)), N))),
    )


def primary_pair_scaffold() -> tuple[Formula, ...]:
    """Recommended 45-node scaffold: direct eta replaces B(0,0)=0."""
    zz = var("z")
    eta = forall(("z",), eq(pair(left(zz), right(zz)), zz))
    return (eta,) + pair_scaffold()[1:]


def diagonal_boundary_four(e: Formula) -> Formula:
    b = var("b")
    return forall(("a",), bind("exists", "b", forall(("x",), k4(
        eq(succ(X), b), e, eq(X, b), eq(b, A)))))


def contains_active_tag(t: Term, tag: str) -> bool:
    return t.tag == tag or any(contains_active_tag(c, tag) for c in t.args)


def contains_active_subterm(t: Term, needle: Term) -> bool:
    return t == needle or any(contains_active_subterm(c, needle) for c in t.args)


def admit_weak_right_boundary(f: Formula) -> bool:
    """Earlier reference filter: at least one literal active native R(x)."""
    normalized = normalize_equation(f)
    return any(contains_active_subterm(t, right(X)) for t in normalized.args)


def admit_right_boundary(f: Formula) -> bool:
    """Recommended strong filter after normalization.

    There is an active x and EVERY active x lies inside an intact literal
    native R(x). Frozen descriptor occurrences are never inspected.
    """
    normalized = normalize_equation(f)
    return ("x" in equation_vars(normalized)
            and all(only_guarded_x(t) for t in normalized.args))


def relevant_occurrence(t: Term, name: str, under_function: bool = False) -> bool:
    """Generalized omission test: S is the only nonconstant constructor."""
    if t.tag == "var":
        return t.name == name and under_function
    beneath = under_function or t.tag not in {"var", "zero", "succ"}
    return any(relevant_occurrence(c, name, beneath) for c in t.args)


def rewrite_term_once(t: Term) -> Term:
    """First eligible innermost-leftmost active redex; descriptors opaque.

    B/L/R are opaque operations: normalization may visit their arguments,
    but it never applies a rule at a B/L/R node.
    """
    for index, child in enumerate(t.args):
        new_child = rewrite_term_once(child)
        if new_child != child:
            children = t.args[:index] + (new_child,) + t.args[index+1:]
            return Term(t.tag, children, t.name, t.descriptor)
    if t.tag != "rec":
        return t
    h = t.descriptor
    assert h is not None
    counter, initial = t.args
    replacement = None
    if counter == ZERO:
        replacement = initial
    elif h == V:
        replacement = initial
    elif counter.tag == "succ":
        previous_counter = counter.args[0]
        replacement = subst(h, {
            "v": rec(h, previous_counter, initial), "w": previous_counter})
    if replacement is not None and term_size(replacement) < term_size(t):
        return replacement
    return t


def normalize_term(t: Term) -> Term:
    """Termination follows from the strict full-size decrease each time."""
    while True:
        new = rewrite_term_once(t)
        if new == t:
            return t
        assert term_size(new) < term_size(t)
        t = new


def normalize_equation(f: Formula) -> Formula:
    assert f.tag == "eq"
    s, t = (normalize_term(a) for a in f.args)
    while s.tag == "succ" and t.tag == "succ":
        s, t = s.args[0], t.args[0]
    # The immutable AST's fixed-field representation gives a deterministic
    # computable total ordering, without any semantic equivalence test.
    if repr(t) < repr(s):
        s, t = t, s
    result = eq(s, t)
    assert formula_size(result) <= formula_size(f)
    return result


def only_guarded_x(t: Term) -> bool:
    """Every active x must occur inside an intact opaque R(x) subtree."""
    if t == right(X):
        return True
    if t.tag == "var":
        return t.name != "x"
    return all(only_guarded_x(c) for c in t.args)


def pair_diagnostics() -> dict:
    # Natural-number diagnostics are intentionally finite; they certify no
    # induction or bi-interpretability theorem.
    def triangle(n: int) -> int:
        return n * (n + 1) // 2

    def B(a: int, n: int) -> int:
        return triangle(a + n) + n

    def LR(value: int) -> tuple[int, int]:
        diagonal = (isqrt(8 * value + 1) - 1) // 2
        r = value - triangle(diagonal)
        return diagonal - r, r

    def trunc(a: int, b: int) -> int:
        return max(a - b, 0)

    def clamp(x: int, t: int) -> int:
        return trunc(t, trunc(t, x))

    assert B(0, 0) == 0
    assert LR(0) == (0, 0)
    for a in range(21):
        for n in range(21):
            assert B(a + 1, n) + 1 == B(a, n + 1)
            assert LR(B(a, n)) == (a, n)
            assert trunc(n, B(a, n)) == 0
            assert clamp(B(a, n), n) == n
        assert B(0, a) + 1 == B(a + 1, 0)
    for value in range(1001):
        l, r = LR(value)
        assert B(l, r) == value
        assert 0 <= r <= value
        next_r = LR(value + 1)[1]
        assert next_r == 0 or next_r == r + 1
    for t in range(41):
        assert clamp(0, t) == 0
        for x in range(41):
            c = clamp(x, t)
            assert c == min(x, t)
            assert clamp(x + 1, t) in {c, c + 1}
            if trunc(t, x) == 0:
                assert c == t
    return {"status": "PASS", "pair_coordinate_range": [0, 20],
            "eta_Rstep_bound_range": [0, 1000], "clamp_range": [0, 40],
            "claims_checked": ["four primary scaffold identities", "derived B(0,0)=0",
                               "L(0)=R(0)=0", "eta",
                               "R(Sz)=0 or R(Sz)=S(Rz)", "R(z)<=z",
                               "pair target bound", "clamp base/step/endpoint"],
            "scope": "Bounded natural-number diagnostics only."}


def occurrences(t: Term, name: str) -> int:
    return int(t.tag == "var" and t.name == name) + sum(
        occurrences(c, name) for c in t.args
    )


def successor_counter_occurrences(t: Term) -> int:
    if t == succ(W):
        return 1
    return sum(successor_counter_occurrences(c) for c in t.args)


def guarded(t: Term, state: Term, counter: Term, probe: Term) -> Term:
    # Replace literal active S(w) first; never descend into a descriptor.
    if t == succ(W):
        return probe
    if t.tag == "var":
        return {"v": state, "w": counter}.get(t.name, t)
    return Term(t.tag, tuple(guarded(c, state, counter, probe)
                            for c in t.args), t.name, t.descriptor)


def data(h: Term) -> tuple[int, int, int, int]:
    H = term_size(h)
    k = occurrences(h, "v")
    j = successor_counter_occurrences(h)
    r = occurrences(h, "w") - j
    return H, k, j, r


def folded_star(h: Term) -> Formula:
    body = guarded(h, rec(h, pred(N), A), pred(N), N)
    return forall(("a", "n"), eq(rec(h, N, A), choose(N, A, body)))


def binding_star(h: Term) -> Formula:
    assert occurrences(h, "v") == 0
    body = guarded(h, ZERO, U, N)
    return forall(("a", "n", "u"), impl(eq(pred(N), U),
        eq(rec(h, N, A), choose(N, A, body))))


def endpoint_four(h: Term, step: Formula | None = None) -> Formula:
    if step is None:
        step = eq(Y, guarded(h, U, N, X))
    probes = forall(("x", "y"), k4(
        conj(eq(X, N), eq(Y, U)), eq(rec(h, X, A), Y),
        eq(X, succ(N)), step))
    return forall(("a", "n"), bind("exists", "u", conj(
        impl(eq(N, ZERO), eq(U, A)), probes)))


def replace_terms(t: Term, replacements: Mapping[Term, Term]) -> Term:
    # Matching a selected outer subtree takes priority over its descendants.
    if t in replacements:
        return replacements[t]
    return Term(t.tag, tuple(replace_terms(c, replacements) for c in t.args),
                t.name, t.descriptor)


def replace_in_equation(f: Formula, replacements: Mapping[Term, Term]) -> Formula:
    assert f.tag == "eq"
    return eq(*(replace_terms(t, replacements) for t in f.args))


def equation_vars(f: Formula) -> set[str]:
    assert f.tag == "eq"
    return active_vars(f.args[0]) | active_vars(f.args[1])


def distinct_active_subterms(f: Formula) -> tuple[Term, ...]:
    """First-occurrence postorder, left to right, excluding variables only."""
    assert f.tag == "eq"
    ordered: list[Term] = []
    seen: set[Term] = set()

    def visit(t: Term) -> None:
        for child in t.args:
            visit(child)
        if t.tag != "var" and t not in seen:
            seen.add(t)
            ordered.append(t)

    for term in f.args:
        visit(term)
    return tuple(ordered)


@dataclass(frozen=True)
class Factoring:
    original: Formula
    selected: tuple[Term, ...]
    definitions: tuple[tuple[Term, Term], ...]
    residual: Formula
    graph: Formula


def factor_equation(f: Formula, selected: Iterable[Term]) -> Factoring:
    requested = frozenset(selected)
    candidates = distinct_active_subterms(f)
    assert requested <= frozenset(candidates)
    ordered = tuple(t for t in candidates if t in requested)
    used_names = equation_vars(f)
    replacements: dict[Term, Term] = {}
    definitions: list[tuple[Term, Term]] = []
    next_id = 0
    for term in ordered:
        while True:
            next_id += 1
            fresh = f"graph_z_{next_id}"
            if fresh not in used_names:
                break
        used_names.add(fresh)
        name = var(fresh)
        reduced = replace_terms(term, replacements)
        definitions.append((name, reduced))
        replacements[term] = name
    residual = replace_in_equation(f, replacements)
    graph = residual
    for name, rhs in reversed(definitions):
        graph = bind("exists", name.name, conj(eq(name, rhs), graph))
    return Factoring(f, ordered, tuple(definitions), residual, graph)


def verify_factor_certificate(result: Factoring) -> None:
    # The certificate records the syntactic substitution step behind the
    # constructive proof.  The generic logical proof is not formalized here.
    expected = formula_size(result.residual) + sum(
        term_size(rhs) + 4 for _, rhs in result.definitions)
    assert formula_size(result.graph) == expected
    expanded: dict[str, Term] = {}
    original_names = equation_vars(result.original)
    assert len(result.definitions) == len(result.selected)
    for original, (name, rhs) in zip(result.selected, result.definitions):
        assert name.name not in original_names
        assert name.name not in active_vars(rhs)
        assert active_vars(rhs) <= original_names | set(expanded)
        expanded_rhs = subst(rhs, expanded)
        assert expanded_rhs == original
        expanded[name.name] = expanded_rhs
    recovered = eq(*(subst(t, expanded) for t in result.residual.args))
    assert recovered == result.original


def minimum_graph(f: Formula) -> Factoring:
    candidates = distinct_active_subterms(f)
    # Empty selection is considered first, so the result can never increase
    # size. Equal-size selections favor fewer bindings, then postorder.
    best = factor_equation(f, ())
    best_size = formula_size(best.graph)
    for count in range(1, len(candidates) + 1):
        for selection in combinations(candidates, count):
            result = factor_equation(f, selection)
            verify_factor_certificate(result)
            size = formula_size(result.graph)
            if size < best_size:
                best, best_size = result, size
    verify_factor_certificate(best)
    return best


def family(m: int) -> Term:
    h = V
    for _ in range(m):
        # A is addition's initialized recursor, with full descriptor S(v).
        h = rec(succ(V), h, h)
    return h


def old_envelope(h: Term) -> int:
    H, k, j, r = data(h)
    ell = j + r
    candidates = [3*H + 13 + k*(H+2), 3*H+21, 2*H-j+32,
                  2*H+13+k*(H+5)+3*ell]
    if k == 0:
        candidates.extend([2*H+21, 2*H-j+3*r+22])
    if h == V:
        candidates.append(8)
    return min(candidates)


def checks() -> dict:
    # Frozen descriptors cannot be accidentally instantiated or shared.
    frozen_test = rec(succ(W), succ(W), V)
    assert subst(frozen_test, {"w": ZERO, "v": succ(ZERO)}).descriptor == succ(W)
    probe_test = guarded(frozen_test, U, N, X)
    assert probe_test == rec(succ(W), X, U)
    assert data(frozen_test) == (6, 1, 1, 0)
    assert succ(W) not in distinct_active_subterms(eq(rec(succ(W), X, A), Y))
    assert term_size(rec(succ(W), X, A)) == 5

    suite = [V, W, ZERO, succ(V), succ(W), succ(succ(W)),
             rec(W, V, V), rec(succ(W), succ(W), V),
             rec(succ(V), succ(W), succ(W)),
             rec(ZERO, rec(W, W, ZERO), succ(W)),
             rec(succ(V), succ(V), W)]
    suite += [family(m) for m in range(1, 6)]
    module_rows = []
    for h in suite:
        H, k, j, r = data(h)
        assert term_size(guarded(h, U, N, X)) == H-j
        ps = formula_size(folded_star(h))
        assert ps == 2*H-j+13+k*(H+5)+3*r
        ts = formula_size(endpoint_four(h))
        assert ts == 2*H-j+32
        ls = None
        if k == 0:
            ls = formula_size(binding_star(h))
            assert ls == 2*H-j+21
        module_rows.append({"H":H,"k":k,"j":j,"r":r,
                            "P_star":ps,"L_star":ls,"T4_guarded":ts})

    seven = seven_equations()
    seven_sizes = [formula_size(f) for f in seven]
    assert seven_sizes == [13, 17, 13, 13, 13, 26, 67]
    assert sum(formula_size(forall(("a", "x"), f)) for f in seven) == 176
    normalized_seven = tuple(normalize_equation(f) for f in seven)
    normalized_seven_sizes = [formula_size(f) for f in normalized_seven]
    assert normalized_seven_sizes == seven_sizes
    assert len(set(normalized_seven)) == 7
    assert not any(admit_right_boundary(f) for f in seven)
    e6 = seven[5]
    e6_graph = minimum_graph(e6)
    assert formula_size(e6) == 26
    assert formula_size(e6_graph.graph) == 25

    reference_scaffold_sizes = [formula_size(f) for f in pair_scaffold()]
    assert reference_scaffold_sizes == [5, 12, 10, 15]
    assert sum(reference_scaffold_sizes) == 42
    scaffold_sizes = [formula_size(f) for f in primary_pair_scaffold()]
    assert scaffold_sizes == [8, 12, 10, 15]
    assert sum(scaffold_sizes) == 45
    assert term_size(pair(A, N)) == 3
    assert term_size(left(pair(A, N))) == 4
    assert term_size(right(pair(A, N))) == 4
    proxy = left(pair(X, ZERO))
    proxy_inputs = seven + (eq(X, A), eq(succ(X), A),
                           eq(rec(V, X, A), X))
    for original in proxy_inputs:
        transformed = eq(*(subst(t, {"x": proxy}) for t in original.args))
        assert any(contains_active_tag(t, "B") for t in transformed.args)
        assert any(contains_active_tag(t, "L") for t in transformed.args)
        assert any(relevant_occurrence(t, "x") for t in transformed.args)
        assert transformed not in seven
        assert eq(transformed.args[1], transformed.args[0]) not in seven
    # A shorter induction transfer uses R's reset-or-successor property:
    # E'(x,z)=E(R(x),L(z)); retained E(0,a) handles reset steps.  Its
    # logical proof is in the report; here we check the literal admission.
    for original in proxy_inputs:
        transformed = eq(*(subst(t, {"x": right(X), "a": left(var("z"))})
                           for t in original.args))
        assert any(contains_active_tag(t, "R") for t in transformed.args)
        assert any(relevant_occurrence(t, "x") for t in transformed.args)
        assert transformed not in seven
        assert eq(transformed.args[1], transformed.args[0]) not in seven
    # Additional cases deliberately let normalization erase all x's,
    # duplicate guarded x's, or cancel outer successors.
    lift_inputs = proxy_inputs + (
        eq(rec(V, X, A), A),
        eq(rec(ZERO, succ(X), A), ZERO),
        eq(succ(rec(V, X, A)), succ(A)),
        eq(rec(W, succ(X), A), X),
        eq(rec(W, ZERO, X), X),
        eq(rec(succ(V), succ(X), A), succ(rec(succ(V), X, A))),
        eq(succ(right(X)), succ(A)),
    )
    erased_inputs = 0
    retained_inputs = 0
    for original in lift_inputs:
        lift = eq(*(subst(t, {"x": right(X), "a": left(var("z"))})
                    for t in original.args))
        assert all(only_guarded_x(t) for t in lift.args)
        result = normalize_equation(lift)
        assert normalize_equation(result) == result
        assert all(only_guarded_x(t) for t in result.args)
        if "x" not in equation_vars(result):
            erased_inputs += 1
            assert not admit_right_boundary(result)
        else:
            retained_inputs += 1
            assert any(relevant_occurrence(t, "x") for t in result.args)
            assert any(contains_active_tag(t, "R") for t in result.args)
            assert result not in normalized_seven
            assert admit_right_boundary(result)
    assert erased_inputs > 0 and retained_inputs > 0
    eta = eq(pair(left(X), right(X)), X)
    assert normalize_equation(eta) == eta
    assert eta not in normalized_seven
    assert admit_weak_right_boundary(eta)
    assert not admit_right_boundary(eta)
    assert formula_size(eta) == 7
    eta_boundary_cost = formula_size(diagonal_boundary_four(eta))
    assert eta_boundary_cost == 21
    reference_eta_packet_cost = sum(reference_scaffold_sizes) + eta_boundary_cost
    assert reference_eta_packet_cost == 63
    assert reference_eta_packet_cost - sum(scaffold_sizes) == 18
    assert admit_weak_right_boundary(eq(right(X), X))
    assert not admit_right_boundary(eq(right(X), X))
    assert admit_right_boundary(eq(right(X), A))
    assert admit_right_boundary(eq(right(right(X)), A))
    assert not admit_right_boundary(eq(right(succ(X)), A))
    assert not admit_right_boundary(eq(A, A))
    # Active Q(Sx,a) reduces, whereas exactly the same text stored inside
    # a recursor description remains frozen.
    stored_redex = rec(W, succ(V), W)
    descriptor_test = rec(stored_redex, X, A)
    assert normalize_term(descriptor_test).descriptor == stored_redex
    assert normalize_term(q(succ(X), A)) == X
    assert normalize_term(rec(V, X, A)) == A
    # Frozen descriptor occurrences are inactive. A legal ordinary rewrite
    # may expose R(x) from a NEW-language descriptor, so test admission only
    # after normalization.
    descriptor_only_R = eq(rec(right(V), N, X), A)
    assert not admit_right_boundary(descriptor_only_R)
    exposed_R = eq(rec(right(W), succ(X), A), A)
    assert admit_right_boundary(exposed_R)
    numerical_pair_checks = pair_diagnostics()

    # Exhaustive subsets for each equation in this finite suite, with the
    # descriptor tree kept opaque by the candidate enumeration.
    graph_examples = [eq(Y, family(1)), eq(Y, family(2)),
                      eq(Y, family(3)), e6,
                      eq(q(X,A),q(X,A)),
                      eq(rec(succ(W), X, A), Y)]
    for f in graph_examples:
        result = minimum_graph(f)
        assert formula_size(result.graph) <= formula_size(f)

    rows = []
    for m in range(1, 9):
        h = family(m)
        H,k,j,r = data(h)
        assert H == 4*2**m-3
        assert k == 2**m and j == r == 0
        step = eq(Y, guarded(h,U,N,X))
        optimal = minimum_graph(step)
        G = formula_size(optimal.graph)
        # An explicit linear-size witness shares all proper nontrivial h_i.
        inner = [guarded(family(i),U,N,X) for i in range(1,m)]
        witness = factor_equation(step,inner)
        verify_factor_certificate(witness)
        assert formula_size(witness.graph) == 9*m-2
        assert G <= 9*m-2
        new = formula_size(endpoint_four(h,optimal.graph))
        assert new == H+30+G
        old = old_envelope(h)
        if m >= 2:
            assert old == 2*H+32
            assert new <= old
        rows.append({"m":m,"H":H,"unfactored_step":H+2,
                     "minimum_graph":G,"linear_witness":9*m-2,
                     "old_local_envelope":old,"new_T4":new,
                     "local_saving":old-new,
                     "selected_bindings":len(optimal.selected)})

    return {
        "status":"PASS",
        "scope":"Finite syntax/count/reconstruction checks; no full metatheorem formalization.",
        "descriptor_freezing":"PASS",
        "module_count_examples":module_rows,
        "E6":{"raw_equation":26,"factored_equation":25,
              "raw_universal_closure":28,"factored_universal_closure":27},
        "seven_protected_equations": {"sizes": seven_sizes,
                                      "normalized_sizes": normalized_seven_sizes,
                                      "universal_total": 176},
        "pair_variant": {"scaffold_sizes": scaffold_sizes, "total": 45,
                         "reference_scaffold_sizes": reference_scaffold_sizes,
                         "reference_scaffold_total": 42,
                         "reference_eta_boundary_cost": eta_boundary_cost,
                         "reference_supported_packet_cost": reference_eta_packet_cost,
                         "primary_packet_saving": reference_eta_packet_cost-sum(scaffold_sizes),
                         "proxy_inputs_checked": len(proxy_inputs),
                         "proxy": "x -> L(B(x,0))",
                         "reset_transfer": "E'(x,z)=E(R(x),L(z))",
                         "reset_transfer_inputs_checked": len(proxy_inputs),
                         "normalization": "Strictly decreasing ordinary recursion and R_v identity; shared outer S cancellation; repr orientation; B/L/R and descriptors opaque.",
                         "normalized_lift_inputs_checked": len(lift_inputs),
                         "normalized_lifts_x_erased": erased_inputs,
                         "normalized_lifts_x_retained": retained_inputs,
                         "eta_normalization": "unchanged",
                         "boundary_admission": "At least one active x, and EVERY active x is inside a literal native R(x), after normalization and before graph factoring.",
                         "seven_old_indices_admitted": 0,
                         "eta_admitted": False,
                         "eta_direct_axiom": True,
                         "eta_weak_reference_admitted": True,
                         "admitted_normalized_lifts": retained_inputs,
                         "nonadmitted_x_free_lifts": erased_inputs,
                         "numeric_diagnostics": numerical_pair_checks},
        "duplicate_family":rows,
    }


if __name__ == "__main__":
    print(json.dumps(checks(), indent=2))
