#!/usr/bin/env python3
"""Rebuild the independent checks and the PDF with Python 3 and pdfLaTeX."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def run(command):
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(result.returncode)
    return result.stdout


def checks():
    run([sys.executable, "artifacts/check_constructions.py", "--output",
         "artifacts/verification_results.json"])
    run([sys.executable, "artifacts/counterfree_check.py", "--bound", "1024", "--output",
         "artifacts/counterfree_results.json", "--witnesses", "artifacts/counterfree_rejections.jsonl"])
    run([sys.executable, "artifacts/verify_rejections.py", "--output",
         "artifacts/rejection_verification.json"])
    print("All finite diagnostics and the independent rejection-certificate check passed.")


def pdf():
    with tempfile.TemporaryDirectory(prefix="pra_fresh_probe_tex_") as temporary:
        transcripts = []
        previous = None
        for _ in range(5):
            transcripts.append(run(["pdflatex", "-no-shell-escape", "-interaction=nonstopmode",
                                    "-halt-on-error", "-output-directory=" + temporary, "report.tex"]))
            state = hashlib.sha256(b"".join(
                (Path(temporary) / ("report." + suffix)).read_bytes()
                for suffix in ["aux", "toc", "out"]
                if (Path(temporary) / ("report." + suffix)).exists())).hexdigest()
            if state == previous:
                break
            previous = state
        else:
            raise RuntimeError("LaTeX cross-references did not stabilize after five runs")
        log = (Path(temporary) / "report.log").read_text(errors="replace")
        shutil.copy2(Path(temporary) / "report.pdf", ROOT / "report.pdf")
        (ROOT / "audit").mkdir(exist_ok=True)
        (ROOT / "audit/latex_build.log").write_text("\n".join(transcripts))
        issues = [line for line in log.splitlines()
                  if "Overfull" in line or "undefined" in line.lower()
                  or "multiply defined" in line.lower()]
        result = {"status": "PASS" if not issues else "REVIEW_REQUIRED",
                  "latex_runs": len(transcripts), "layout_or_reference_warnings": issues,
                  "visual_review": "Separate visual inspection is required after a changed build."}
        if shutil.which("pdfinfo"):
            result["pdfinfo"] = run(["pdfinfo", "report.pdf"])
        (ROOT / "audit/build_results.json").write_text(json.dumps(result, indent=2) + "\n")
        if issues:
            print("PDF built; inspect these warnings:")
            print("\n".join(issues))
        else:
            print("PDF compiled with stable cross-references and no overfull boxes or unresolved references.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--checks-only", action="store_true")
    group.add_argument("--pdf-only", action="store_true")
    arguments = parser.parse_args()
    if not arguments.pdf_only:
        checks()
    if not arguments.checks_only:
        pdf()
