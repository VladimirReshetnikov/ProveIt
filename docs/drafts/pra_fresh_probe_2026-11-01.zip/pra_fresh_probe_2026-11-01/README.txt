PRA WITH A FRESH COMPARISON VARIABLE
Prepared for Vladimir Reshetnikov, 1 November 2026

Read report.pdf. Its complete editable source is report.tex plus sections/*.tex.

RESULTS

1. A smaller sufficient generating subschema of the current strongest
   initialized-swap presentation. Its stationary term f(n,b) is independent
   of the separately quantified comparison variable a. This restriction is
   intuitionistically equivalent to the old scheme by freezing old probe
   dependence as a new passive parameter and then specializing the probe.
   The disclosed display ledger is 46+8=54, versus the prior 50+8=58.

2. A new counter-free comparison update C(D(a,Sv),SSv,a), with nine nodes
   instead of twelve. It increments a exactly when a=S(v), and otherwise
   returns a. The corresponding counter-free presentation has ledger
   45+11=56, versus the prior counter-free 49+14=63.

3. A complete finite local lower-bound certificate for that counter-free
   update requirement in the fixed grammar 0,a,v,S,D,C. All 30,957 raw trees
   of sizes 1 through 8 are rejected. An independent checker parses every
   witness, evaluates D by its literal swap recurrence, and proves exhaustive
   coverage by unique-tree counts from the grammar recurrence.

4. A mathematical obstruction: replacing the arbitrary probe by fixed
   standard numeral probes, even all of them, admits a two-sheet nonstandard
   cover with a nontrivial involution. Hence that weakened theory is not
   parameter-free bi-interpretable with PRA. This is not a statement about
   its equiconsistency or about every interpretation allowing parameters.

The two positive presentations are bi-interpretable and equiconsistent with
ordinary first-order PRA, separately in classical and intuitionistic logic.
Both translations use the full carrier and native equality; both internally
proved round trips are identities. The report gives the complete constructive
reconstruction, forward and reverse compilers, internal uniqueness, and
Further research questions.

IMPORTANT QUALIFICATIONS

The four-node fresh-variable saving is in the representative generating
template and its dependency interface. It does not shorten every expanded
instance: one with genuine probe dependence can require another frozen
parameter. The ledger does not count the complete axiom enumerator or all
binding metadata. No absolute simplest-axiomatization claim is made.

The existing swap mechanism and several proof constructions are retained
and credited. The counter-free update is a separate computational improvement.
Finite numerical diagnostics are not proofs about arbitrary models. No
complete Lean/Rocq formalization of the new bi-interpretation is claimed.

CONTENTS

report.pdf, report.tex, sections/   Complete mathematical report and source
AXIOMS.txt                        Plain-text specification of both theories
build.py                          Offline rebuild command
artifacts/check_constructions.py  Counts, helpers, and compiler diagnostics
artifacts/counterfree_check.py     New comparator and exhaustive local search
artifacts/verify_rejections.py     Independent rejection-certificate checker
artifacts/*.json, *.jsonl          Reproducible results and all rejection witnesses
audit/source_manifest.json        Fixed snapshot, immutable source URLs and hashes
audit/*.txt                       Independent mathematical review notes
audit/build_results.json          Build result and PDF metadata
audit/visual_review.json          Final visual inspection record
MANIFEST.sha256                   Release file hashes, excluding this manifest

REBUILD

Python 3.10+ standard library; pdfLaTeX with the standard packages listed
in report.tex. No network access and no original draft archive is needed.

  python3 build.py
  python3 build.py --checks-only
  python3 build.py --pdf-only

The PDF can change byte-for-byte on rebuilding because of TeX metadata.
Rebuilt diagnostics and logs can also change release hashes. Verify
MANIFEST.sha256 before rebuilding if release integrity is the goal.

SOURCE REVIEW

ProveIt commit: 3abedb526f9557c7817899dbd5fcd9872a95c51d
All eight archives then present in docs/drafts were inspected. Input scripts
were not executed, and the original archives are not duplicated here.
The repository was read only.
