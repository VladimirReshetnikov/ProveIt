#!/usr/bin/env python3
"""Independent checks for the nine-node counter-free swap comparator.

No upstream draft code is imported. Python 3's standard library suffices.
The exhaustive search is a finite local obstruction in the explicitly fixed
term grammar 0,a,v,S,D,C. It is not a global axiomatization lower bound.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path


def distance(x: int, y: int) -> int:
    """Standard function D specified by D(0,y)=y; D(Sx,y)=D(y,x)."""
    return y - x if x <= y else x - y - 1


def selector(z: int, u: int, w: int) -> int:
    return u if z == 0 else w


def update(a: int, v: int) -> int:
    return selector(distance(a, v + 1), v + 2, a)


def comparator_table(bound: int) -> list[list[int]]:
    """Evaluate the literal swap recurrence, ordered by argument sum."""
    values = [[-1] * (bound + 1 - x) for x in range(bound + 1)]
    for total in range(bound + 1):
        for x in range(total + 1):
            y = total - x
            values[x][y] = y if x == 0 else update(y, values[y][x - 1])
    return values


def check_comparator(bound: int) -> dict:
    values = comparator_table(bound)
    checked = 0
    for x in range(bound + 1):
        for y in range(bound + 1 - x):
            expected = y + 1 if x == y and x > 0 else y
            assert values[x][y] == expected, (x, y, values[x][y], expected)
            checked += 1
    assert values[1][0] == 0
    assert values[1][1] == 2
    bit_bound = min(96, (bound - 2) // 2)
    bit_checks = 0
    for x, y in itertools.product(range(bit_bound + 1), repeat=2):
        bit = distance(y + 1, values[x + 1][y + 1])
        assert bit == int(x == y), (x, y, bit)
        bit_checks += 1
    return {
        "sum_bound": bound,
        "swap_pairs_checked": checked,
        "equality_inputs_maximum": bit_bound,
        "equality_bit_checks": bit_checks,
        "U_1_0": values[1][0],
        "U_1_1": values[1][1],
    }


def necessary_constraints() -> list[tuple[int, int, str, tuple[int, ...]]]:
    """Necessary for off-diagonal identity and a changed positive diagonal.

    If U(0,a)=a, U(Sn,a)=h(a,U(a,n)), U(x,a)=a for x!=a,
    and g(a)=U(a,a)!=a for all positive a, then:
      h(0,v)=0;
      h(a,v)=a when v not in {a,a-1};
      h(a,a-1) is neither a nor a-1.
    For the last exclusion, if g(a)=a-1, the off-diagonal equation at
    U(Sa,a) forces a=h(a,g(a))=h(a,a-1)=g(a)=a-1.
    The finite instances below are therefore necessary, not heuristics.
    """
    constraints = [(0, v, "equal", (0,)) for v in range(5)]
    constraints += [
        (a, v, "equal", (a,))
        for a in range(1, 5)
        for v in range(6)
        if v not in (a, a - 1)
    ]
    constraints += [(a, a - 1, "avoid", (a, a - 1)) for a in range(1, 5)]
    return constraints


def first_failure(values: tuple[int, ...], constraints: list) -> int | None:
    for index, (actual, (_, _, kind, targets)) in enumerate(zip(values, constraints)):
        valid = actual == targets[0] if kind == "equal" else actual not in targets
        if not valid:
            return index
    return None


def local_lower_bound(witness_path: Path | None) -> dict:
    """Enumerate all raw syntax trees through eight nodes, without pruning."""
    constraints = necessary_constraints()
    points = [(a, v) for a, v, _, _ in constraints]
    terms = {
        1: [
            ("0", tuple(0 for _ in points)),
            ("a", tuple(a for a, _ in points)),
            ("v", tuple(v for _, v in points)),
        ]
    }
    digest = hashlib.sha256()
    counts = {}
    survivors = []
    witness_stream = witness_path.open("w", encoding="utf-8") if witness_path else None
    try:
        for size in range(1, 9):
            if size > 1:
                level = []
                for tree, values in terms[size - 1]:
                    level.append((f"S({tree})", tuple(value + 1 for value in values)))
                for left_size in range(1, size - 1):
                    right_size = size - 1 - left_size
                    for left, right in itertools.product(terms[left_size], terms[right_size]):
                        tree = f"D({left[0]},{right[0]})"
                        values = tuple(distance(x, y) for x, y in zip(left[1], right[1]))
                        level.append((tree, values))
                for test_size in range(1, size - 2):
                    for yes_size in range(1, size - 1 - test_size):
                        no_size = size - 1 - test_size - yes_size
                        for test, yes, no in itertools.product(
                            terms[test_size], terms[yes_size], terms[no_size]
                        ):
                            tree = f"C({test[0]},{yes[0]},{no[0]})"
                            values = tuple(
                                selector(z, u, w) for z, u, w in zip(test[1], yes[1], no[1])
                            )
                            level.append((tree, values))
                terms[size] = level
            counts[str(size)] = len(terms[size])
            for tree, values in terms[size]:
                failure = first_failure(values, constraints)
                if failure is None:
                    survivors.append(tree)
                    continue
                a, v, kind, targets = constraints[failure]
                record = {
                    "size": size,
                    "term": tree,
                    "point": [a, v],
                    "value": values[failure],
                    "required": {kind: list(targets)},
                }
                line = json.dumps(record, separators=(",", ":"), sort_keys=True) + "\n"
                digest.update(line.encode("utf-8"))
                if witness_stream:
                    witness_stream.write(line)
    finally:
        if witness_stream:
            witness_stream.close()
    assert not survivors, survivors
    assert counts == {"1": 3, "2": 3, "3": 12, "4": 57, "5": 219,
                      "6": 1038, "7": 5052, "8": 24573}, counts
    chosen_values = tuple(update(a, v) for a, v in points)
    assert first_failure(chosen_values, constraints) is None
    return {
        "grammar": "h ::= 0 | a | v | S(h) | D(h,h) | C(h,h,h)",
        "cost": "one node for each variable, constant, or application occurrence",
        "enumeration": "all raw syntax trees; no semantic pruning",
        "necessary_constraints": [
            {"a": a, "v": v, "kind": kind, "targets": list(targets)}
            for a, v, kind, targets in constraints
        ],
        "raw_tree_counts": counts,
        "total_rejected": sum(counts.values()),
        "survivors": survivors,
        "rejection_records_sha256": digest.hexdigest(),
        "chosen_update": "C(D(a,S(v)),S(S(v)),a)",
        "chosen_update_size": 9,
        "scope": "off-diagonal identity and a changed diagonal at every positive a",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bound", type=int, default=512)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--witnesses", type=Path,
                        help="optional JSONL rejection certificate for every smaller raw tree")
    args = parser.parse_args()
    if args.bound < 4:
        parser.error("--bound must be at least 4")
    report = {
        "status": "PASS",
        "numerical_diagnostics": check_comparator(args.bound),
        "finite_local_lower_bound": local_lower_bound(args.witnesses),
        "verification_boundary": (
            "The finite tests and exhaustive local term search are not a "
            "proof-assistant verification of the full arithmetic bi-interpretation."
        ),
    }
    output = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(output, encoding="utf-8")
    print(output, end="")


if __name__ == "__main__":
    main()
