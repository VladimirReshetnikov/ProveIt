#!/usr/bin/env python3
"""Finite diagnostics and exact template-tree counts for the report.

Written for this report; imports no code from the inspected draft archives.
These tests do not certify arbitrary models or the bi-interpretation theorem.
"""
from __future__ import annotations

import argparse
import functools
import itertools
import json
import random
from pathlib import Path


def c(z, u, v):
    return u if z == 0 else v


def d(x, y):
    return max(y - x, 0) + max(x - y - 1, 0)


def p(x):
    return max(x - 1, 0)


def swap(h):
    @functools.lru_cache(maxsize=None)
    def value(x, a, frozen=()):
        if x == 0:
            return a
        n = x - 1
        return h(n, a, frozen, value(a, n, frozen))
    return value


def fold(h, x, y, frozen=(), damaged=False):
    left, right, steps = max(x - y, 0), max(y - x, 0), min(x, y)
    value = right if left == 0 else h(p(left), 0, frozen, p(left))
    for j in range(steps):
        inside = h(right + j, left + j, frozen, value)
        value = h(left + j, right + j + (0 if damaged else 1), frozen, inside)
    return value


def node(op, *children):
    return (op, *children)


def count(tree):
    return 1 + sum(count(child) for child in tree[1:])


def quant(variables, tree):
    for variable in reversed(variables):
        tree = node("forall:" + variable, tree)
    return tree


def schema_counts(k, counterfree=False, fresh=True):
    zero, a, n = node("0"), node("a"), node("n")
    frozen = [node("b" + str(i)) for i in range(k)]
    bound = ["b" + str(i) for i in range(k)]
    s = lambda x: node("S", x)
    eq = lambda x, y: node("=", x, y)
    r = lambda x, y: node("R", x, y, *frozen)
    initial = quant(["a", *bound], eq(r(zero, a), a))
    hargs = [a, *frozen, r(a, n)] if counterfree else [n, a, *frozen, r(a, n)]
    step = quant(["n", "a", *bound], eq(r(s(n), a), node("h", *hargs)))
    sep = node("imp", eq(zero, s(zero)), node("false"))
    f = lambda x: node("f", x, *([] if fresh else [a]), *frozen)
    premise = quant(["n"], eq(f(s(n)), f(n)))
    disjunction = node("or", eq(node("T", f(zero), a), a), eq(f(n), a))
    if fresh:
        probe = quant(bound, node("imp", premise, quant(["a", "n"], disjunction)))
    else:
        probe = quant(["a", *bound], node("imp", premise, quant(["n"], disjunction)))
    return {"computation": count(initial) + count(step), "separation": count(sep),
            "probe": count(probe), "display": count(initial) + count(step) + count(sep) + count(probe)}


def metrics():
    rows = []
    for k in range(6):
        old = schema_counts(k, fresh=False)
        new = schema_counts(k)
        cf = schema_counts(k, counterfree=True)
        assert old["display"] == 50 + 11 * k
        assert new["display"] == 46 + 11 * k
        assert cf["display"] == 45 + 11 * k
        assert old["probe"] - new["probe"] == 4
        rows.append({"frozen_parameters": k, "old": old, "fresh": new, "counterfree_fresh": cf})
    a, n, v = node("a"), node("n"), node("v")
    main = node("C", node("D", a, n), n, a)
    cf = node("C", node("D", a, node("S", v)), node("S", node("S", v)), a)
    assert count(main) == 6 and count(cf) == 9
    return {"rows": rows, "main_selected_bodies": [1, 1, count(main)],
            "counterfree_selected_bodies": [1, 1, count(cf)],
            "main_partial_subtotal": 54, "counterfree_partial_subtotal": 56}


def check_folds():
    updates = [
        ("zero", lambda n, a, b, v: 0),
        ("counter", lambda n, a, b, v: n),
        ("seed", lambda n, a, b, v: a),
        ("identity", lambda n, a, b, v: v),
        ("successor", lambda n, a, b, v: v + 1),
        ("affine", lambda n, a, b, v: n + a + v + sum(b)),
        ("frozen", lambda n, a, b, v: sum(b)),
        ("comparison", lambda n, a, b, v: c(d(a, n), n, a)),
        ("counterfree_bump", lambda n, a, b, v: c(d(a, v + 1), v + 2, a)),
        ("nonlinear_bounded", lambda n, a, b, v: (v * v + n + 2 * a + sum(b)) % 101),
    ]
    checks = 0
    detected = None
    for name, h in updates:
        direct = swap(h)
        for frozen in [(), (3,), (2, 5)]:
            for x, y in itertools.product(range(33), repeat=2):
                wanted = direct(x, y, frozen)
                actual = fold(h, x, y, frozen)
                assert wanted == actual, (name, x, y, frozen, wanted, actual)
                checks += 1
                if detected is None:
                    bad = fold(h, x, y, frozen, damaged=True)
                    if bad != wanted:
                        detected = {"update": name, "x": x, "y": y, "parameters": frozen,
                                    "correct": wanted, "damaged": bad}
    assert detected is not None
    return {"comparisons": checks, "updates": len(updates), "detected_damaged_fold": detected}


def check_helpers():
    raw_d = swap(lambda n, a, b, v: v)
    raw_t = swap(lambda n, a, b, v: c(raw_d(a, n), n, a))
    checks = 0
    for x, y in itertools.product(range(65), repeat=2):
        assert raw_d(x, y) == d(x, y)
        expected = p(y) if x == y and y != 0 else y
        assert raw_t(x, y) == expected
        checks += 1
    bits = 0
    for x, y in itertools.product(range(64), repeat=2):
        actual = c(d(y, raw_t(x + 1, y + 1)), 1, 0)
        assert actual == int(x == y)
        bits += 1
    return {"D_and_T_pairs": checks, "equality_bits": bits}


def check_forward_compilers():
    recursions = [
        ("constant", lambda b: sum(b) + 3, lambda n, b, v: v),
        ("linear", lambda b: sum(b), lambda n, b, v: v + 2),
        ("counter_sum", lambda b: 1, lambda n, b, v: v + n + sum(b)),
        ("alternating", lambda b: sum(b) % 2, lambda n, b, v: 1 - v),
        ("resetting", lambda b: 4, lambda n, b, v: 0 if n % 3 == 0 else v + 1),
        ("bounded_nonlinear", lambda b: 7, lambda n, b, v: (v * v + n + sum(b)) % 83),
    ]
    ordinary_count = cf_count = 0
    for name, g, step in recursions:
        def full_h(n, a, b, v):
            return c(d(n, a), v, c(n, g(b), step(p(n), b, v)))
        full = swap(full_h)

        def tagged_h(n, a, b, v):
            decoded = v // 2
            if v == 2 * decoded:
                return v + 1
            k = g(b) if p(a) == 0 else step(p(p(a)), b, decoded)
            return 2 * k
        tagged = swap(tagged_h)
        for frozen in [(), (2,), (1, 3)]:
            expected = g(frozen)
            for n in range(21):
                assert full(n + 1, n + 1, frozen) == expected, (name, n, frozen)
                ordinary_count += 1
                encoded = tagged(n + 1, n + 1, frozen)
                assert encoded == 2 * expected, (name, n, frozen, encoded, expected)
                assert encoded // 2 == expected
                cf_count += 1
                expected = step(n, frozen, expected)

    delta = swap(lambda n, a, b, v: v + 1)
    half = swap(lambda n, a, b, v: v + 1 if a == 2 * (v + 1) else v)
    tag_checks = 0
    for z in range(65):
        assert delta(z, z) == 2 * z
        assert half(2 * z, 2 * z) == z
        assert half(2 * z + 1, 2 * z + 1) == z
        tag_checks += 3
    return {"ordinary_forward": ordinary_count, "counterfree_forward": cf_count,
            "literal_tag_checks": tag_checks}


def formula_test():
    rng = random.Random(20261101)

    def formula(depth):
        if depth == 0 or rng.randrange(4) == 0:
            return ("eq", rng.randrange(4), rng.randrange(4))
        return (rng.choice(["and", "or", "imp"]), formula(depth - 1), formula(depth - 1))

    def values(tree, assignment):
        if tree[0] == "eq":
            equality = assignment[tree[1]] == assignment[tree[2]]
            return equality, int(equality)
        left, u = values(tree[1], assignment)
        right, v = values(tree[2], assignment)
        if tree[0] == "and":
            return left and right, c(u, 0, v)
        if tree[0] == "or":
            return left or right, c(u, v, 1)
        return (not left) or right, c(u, 1, v)

    for _ in range(2000):
        actual, bit = values(formula(5), [rng.randrange(7) for _ in range(4)])
        assert bit in (0, 1) and bool(bit) == actual
    return {"formula_samples": 2000, "seed": 20261101,
            "scope": "finite Boolean diagnostic; constructive implication proof is in manuscript"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = {"status": "PASS", "metrics": metrics(), "reverse_fold": check_folds(),
              "helpers": check_helpers(), "forward_compilers": check_forward_compilers(),
              "formula_bits": formula_test(),
              "verification_boundary": "finite diagnostics, not formal proof of either bi-interpretation"}
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
