#!/usr/bin/env python3
"""Independently verify the finite counter-free lower-bound certificate.

This checker does not import the generator, use semantic pruning, or
regenerate its candidate list. Unique well-formed trees plus the independent
grammar counting recurrence certify exhaustiveness. Evaluation of D uses its
literal swapped recurrence, rather than the generator's closed formula.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
from pathlib import Path


def parse(source):
    cursor = 0

    def read():
        nonlocal cursor
        if cursor >= len(source):
            raise ValueError("unexpected end")
        token = source[cursor]
        cursor += 1
        if token in "0av":
            return (token,)
        arities = {"S": 1, "D": 2, "C": 3}
        if token not in arities or source[cursor:cursor + 1] != "(":
            raise ValueError("invalid symbol or missing parenthesis")
        cursor += 1
        children = []
        for index in range(arities[token]):
            if index:
                if source[cursor:cursor + 1] != ",":
                    raise ValueError("missing comma")
                cursor += 1
            children.append(read())
        if source[cursor:cursor + 1] != ")":
            raise ValueError("missing close parenthesis")
        cursor += 1
        return (token, *children)

    result = read()
    if cursor != len(source):
        raise ValueError("trailing input")
    return result


def cost(tree):
    return 1 + sum(cost(child) for child in tree[1:])


def literal_d(x, y):
    while x:
        x, y = y, x - 1
    return y


def evaluate(tree, a, v):
    op = tree[0]
    if op == "0":
        return 0
    if op == "a":
        return a
    if op == "v":
        return v
    if op == "S":
        return evaluate(tree[1], a, v) + 1
    if op == "D":
        return literal_d(evaluate(tree[1], a, v), evaluate(tree[2], a, v))
    return evaluate(tree[2] if evaluate(tree[1], a, v) == 0 else tree[3], a, v)


def all_tree_counts(limit):
    counts = [0, 3]
    for size in range(2, limit + 1):
        amount = counts[size - 1]
        amount += sum(counts[i] * counts[size - 1 - i]
                      for i in range(1, size - 1))
        amount += sum(counts[i] * counts[j] * counts[size - 1 - i - j]
                      for i in range(1, size - 2)
                      for j in range(1, size - 1 - i))
        counts.append(amount)
    return counts


def verify(path):
    seen = set()
    counts = collections.Counter()
    for line_number, line in enumerate(path.read_text().splitlines(), start=1):
        record = json.loads(line)
        raw = record["term"]
        assert raw not in seen, (line_number, "duplicate")
        seen.add(raw)
        tree = parse(raw)
        size = cost(tree)
        assert size == record["size"] and 1 <= size <= 8
        a, v = record["point"]
        assert isinstance(a, int) and isinstance(v, int) and a >= 0 and v >= 0
        actual = evaluate(tree, a, v)
        assert actual == record["value"], (line_number, "wrong value")
        if a == 0:
            assert actual != 0
            expected_requirement = {"equal": [0]}
        elif v == a - 1:
            assert actual in (a, a - 1)
            expected_requirement = {"avoid": [a, a - 1]}
        else:
            assert v != a and actual != a
            expected_requirement = {"equal": [a]}
        assert record["required"] == expected_requirement
        counts[size] += 1
    expected = all_tree_counts(8)
    assert counts == {n: expected[n] for n in range(1, 9)}
    return {
        "status": "PASS",
        "unique_well_formed_rejected_trees": len(seen),
        "counts_by_size": dict(sorted(counts.items())),
        "exhaustiveness": "unique valid trees equal independent grammar counts at every size",
        "semantics": "D evaluated by literal swap recurrence",
        "certificate_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "scope": "fixed grammar and necessary point-mover conditions; not full formal verification",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", nargs="?", type=Path,
                        default=Path(__file__).with_name("counterfree_rejections.jsonl"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = json.dumps(verify(args.path), indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(result)
    print(result, end="")
