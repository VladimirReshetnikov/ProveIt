#!/usr/bin/env python3
"""Reproducible syntax metrics and program diagnostics for bounded-reflection PRA.

The AST counts are bookkeeping, and the finite numerical tests are diagnostics.
Neither is a formal proof of the first-order equivalence theorem. See the report
and the two separately scoped Lean certificates.
"""
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
import json
from pathlib import Path


def node(tag, *args):
    return (tag, *args)


def size(tree):
    return 1 + sum(size(child) for child in tree[1:])


def app(name, *args):
    return node(name, *args)


def eq(x, y):
    return node("=", x, y)


def imp(x, y):
    return node("implies", x, y)


def both(x, y):
    return node("and", x, y)


def either(x, y):
    return node("or", x, y)


def all_(var, body):
    # The binder variable is recorded in the tag, not counted as a child.
    return node("forall:" + var, body)


z, n, a, x, y, v, u = (node(s) for s in ("0", "n", "a", "x", "y", "v", "u"))
bot = node("false")
S = lambda t: app("S", t)
f = lambda t: app("f", t, a)
one = S(z)
sep = imp(eq(z, one), bot)
pc = all_("a", imp(
    all_("n", eq(f(S(S(n))), f(S(n)))),
    all_("n", either(eq(n, z), eq(f(n), f(one))))))
inv = all_("x", all_("y", eq(app("R", app("R", x, y), y), x)))
minimum = all_("x", all_("y", eq(
    app("M", app("M", x, y), y),
    app("M", app("M", y, x), x))))


def equation(t):
    return eq(app("s", t, a), app("t", t, a))


pi = all_("a", imp(
    all_("n", imp(either(eq(n, z), equation(n)), equation(S(n)))),
    all_("n", either(eq(n, z), equation(n)))))
pzi = all_("a", imp(
    all_("n", imp(either(eq(n, z), eq(f(n), z)), eq(f(S(n)), z))),
    all_("n", either(eq(n, z), eq(f(n), z)))))


def expanded_reflection(t, b):
    return app("C", app("M", b, t), app("M", t, b), t)


expanded_inv = all_("x", all_("y",
    eq(expanded_reflection(expanded_reflection(x, y), y), x)))
reflection_step = app("C", app("M", n, y), S(n), app("p", v))


@dataclass(frozen=True)
class Description:
    name: str
    parameters: tuple
    base: tuple
    step: tuple


descriptions = (
    Description("p", (), z, n),
    Description("C", ("u", "v"), u, v),
    Description("M", ("y",), y, app("p", node("state"))),
    Description("R", ("y",), y,
                app("C", app("M", n, y), S(n), app("p", node("state")))),
)


def check_term(t, allowed_vars, arities):
    name, *children = t
    if not children and name in allowed_vars:
        return
    assert name in arities, ("unknown symbol", name)
    assert len(children) == arities[name], ("arity mismatch", name)
    for child in children:
        check_term(child, allowed_vars, arities)


arities = {"0": 0, "S": 1}
for d in descriptions:
    check_term(d.base, set(d.parameters), arities)
    check_term(d.step, {"n", "state", *d.parameters}, arities)
    arities[d.name] = 1 + len(d.parameters)

metrics = {
    "PC_one_parameter": size(pc),
    "Sep": size(sep),
    "Inv_named_R": size(inv),
    "Min_named_M": size(minimum),
    "PI_one_parameter": size(pi),
    "PZI_one_parameter": size(pzi),
    "reflection_update_descriptor": size(reflection_step),
    "reflection_base_descriptor": size(y),
    "Inv_expanded_R_named_C": size(expanded_inv),
}
expected = {
    "PC_one_parameter": 26, "Sep": 6, "Inv_named_R": 9,
    "Min_named_M": 13, "PI_one_parameter": 36, "PZI_one_parameter": 29,
    "reflection_update_descriptor": 8, "reflection_base_descriptor": 1,
    "Inv_expanded_R_named_C": 33,
}
assert metrics == expected, (metrics, expected)
metrics["new_arithmetic_subtotal"] = size(pc) + size(sep) + size(inv)
metrics["new_subtotal_with_marginal_R_descriptor"] = (
    metrics["new_arithmetic_subtotal"] + size(reflection_step) + size(y))


def selector(test, zero_value, nonzero_value):
    return zero_value if test == 0 else nonzero_value


@lru_cache(maxsize=None)
def reflection(counter, seed):
    """Evaluate the exact recursion in the report, not its closed form."""
    value = seed
    for k in range(counter):
        value = selector(max(seed - k, 0), k + 1, max(value - 1, 0))
    return value


pair_count = 0
for counter, seed in product(range(201), repeat=2):
    got = reflection(counter, seed)
    wanted = seed - counter if counter <= seed else counter
    assert got == wanted
    assert reflection(got, seed) == counter
    assert (got == 0) == (counter == seed)
    pair_count += 1

selector_count = 0
for e, g in product(range(8), repeat=2):
    assert (selector(e, g, 1) == 0) == (e == 0 and g == 0)
    assert (selector(e, 0, g) == 0) == (e == 0 or g == 0)
    assert (selector(e, g, 0) == 0) == (e != 0 or g == 0)
    selector_count += 1


def truth(formula, env):
    tag, *args = formula
    if tag == "atom":
        return env[args[0]] == env[args[1]]
    if tag == "false":
        return False
    left, right = (truth(t, env) for t in args)
    if tag == "and":
        return left and right
    if tag == "or":
        return left or right
    assert tag == "implies"
    return not left or right


def error(formula, env):
    tag, *args = formula
    if tag == "atom":
        return reflection(env[args[0]], env[args[1]])
    if tag == "false":
        return 1
    left, right = (error(t, env) for t in args)
    if tag == "and":
        return selector(left, right, 1)
    if tag == "or":
        return selector(left, 0, right)
    assert tag == "implies"
    return selector(left, right, 0)


atoms = [("atom", "x", "y"), ("atom", "y", "z"), ("false",)]
formulas = atoms + [(op, l, r) for op in ("and", "or", "implies")
                    for l in atoms for r in atoms]
formulas += [("implies", l, ("or", r, ("false",)))
             for l in formulas[:15] for r in atoms]
formula_count = 0
for values in product(range(4), repeat=3):
    env = dict(zip(("x", "y", "z"), values))
    for formula in formulas:
        assert truth(formula, env) == (error(formula, env) == 0)
        formula_count += 1

result = {
    "status": "passed",
    "metrics": metrics,
    "descriptor_dependency_order": [d.name for d in descriptions],
    "finite_checks": {
        "reflection_pairs_0_through_200": pair_count,
        "selector_truth_table_pairs": selector_count,
        "formula_environment_pairs": formula_count,
    },
    "scope": (
        "AST bookkeeping and finite program diagnostics. Universal logical "
        "claims are proved in the report and the separately scoped Lean files."
    ),
}
output = Path(__file__).with_name("checks.json")
output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
