import Std

/-!
# Verification of the bounded-reflection program on `Nat`

This certificate verifies the specified primitive-recursive program and its
involution law on Lean's natural numbers.  It is separate from the arbitrary
carrier constructive kernel in `ReflectionCore.lean`.  A theorem about Lean's
`Nat` is not, by itself, a formalization of provability inside first-order PRA.
-/

namespace BoundedReflectionNat

def reflect : Nat → Nat → Nat
  | 0, y => y
  | n + 1, y => if y - n = 0 then n + 1 else reflect n y - 1

theorem base (y : Nat) : reflect 0 y = y := rfl

theorem step (n y : Nat) :
    reflect (n + 1) y = if y - n = 0 then n + 1 else reflect n y - 1 := rfl

theorem closed_form (n y : Nat) :
    reflect n y = if n ≤ y then y - n else n := by
  induction n with
  | zero => simp [reflect]
  | succ n ih =>
      by_cases hzero : y - n = 0
      <;> by_cases hle : n ≤ y
      <;> by_cases hnext : n + 1 ≤ y
      <;> simp [reflect, ih, hzero, hle, hnext]
      <;> omega

theorem involution (n y : Nat) : reflect (reflect n y) y = n := by
  by_cases hle : n ≤ y
  · have hsub : y - n ≤ y := Nat.sub_le y n
    rw [closed_form n y, if_pos hle, closed_form (y - n) y, if_pos hsub]
    omega
  · rw [closed_form n y, if_neg hle, closed_form n y, if_neg hle]

theorem equality_test (n y : Nat) : reflect n y = 0 ↔ n = y := by
  constructor
  · intro h
    calc
      n = reflect (reflect n y) y := (involution n y).symm
      _ = reflect 0 y := congrArg (fun t => reflect t y) h
      _ = y := base y
  · intro h
    subst n
    have hi := involution 0 y
    simpa [reflect] using hi

#print axioms closed_form
#print axioms involution
#print axioms equality_test

end BoundedReflectionNat
