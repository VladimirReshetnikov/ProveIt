import Std

/-!
# Constructive kernel for positive constancy and bounded reflection

This file checks the logical core over an arbitrary carrier.  Its function
parameters represent particular finite terms and particular axiom instances;
they are *not* object-language quantification over all functions.  The report
supplies the effective primitive-recursive term grammar, the latch description,
and the arithmetic proof that bounded reflection is involutive in PRA.

No `classical`, `sorry`, `DecidableEq`, or induction on the carrier is used.
Induction below is solely structural induction on the finite formula syntax.
-/

universe u

namespace ReflectionCore

def PositiveConstancy {A : Type u} (z : A) (s : A → A) (f : A → A) : Prop :=
  (∀ n, f (s (s n)) = f (s n)) →
  ∀ n, n = z ∨ f n = f (s z)

section Constructor
variable {A : Type u} (z : A) (s p : A → A)
variable (sep : z ≠ s z) (p0 : p z = z) (ps : ∀ n, p (s n) = n)

include ps in
theorem successor_injective {x y : A} (h : s x = s y) : x = y := by
  have hp := congrArg p h
  exact (ps x).symm.trans (hp.trans (ps y))

include sep p0 ps in
theorem successor_nonzero (x : A) : s x ≠ z := by
  intro h
  have hx : x = z := (ps x).symm.trans ((congrArg p h).trans p0)
  have hone : s z = z := (congrArg s hx).symm.trans h
  exact sep hone.symm
end Constructor

section Selector
variable {A : Type u} (z : A) (s : A → A) (c : A → A → A → A)
variable (sep : z ≠ s z)
variable (c0 : ∀ u v, c z u v = u)
variable (cs : ∀ n u v, c (s n) u v = v)
variable (pcC : ∀ u v, PositiveConstancy z s (fun n => c n u v))

include cs pcC in
theorem selector_cases (n u v : A) : n = z ∨ c n u v = v := by
  have tail : ∀ k, c (s (s k)) u v = c (s k) u v :=
    fun k => (cs (s k) u v).trans (cs k u v).symm
  rcases pcC u v tail n with hn | hc
  · exact Or.inl hn
  · exact Or.inr (hc.trans (cs z u v))

include sep c0 cs pcC in
theorem zero_decision (n : A) : n = z ∨ n ≠ z := by
  rcases selector_cases z s c cs pcC n (s z) z with hn | hc
  · exact Or.inl hn
  · apply Or.inr
    intro hn
    have hz : c z (s z) z = z := hn ▸ hc
    have hone : s z = z := (c0 (s z) z).symm.trans hz
    exact sep hone.symm

include cs pcC in
theorem selector_nonzero {n : A} (hn : n ≠ z) (u v : A) : c n u v = v := by
  rcases selector_cases z s c cs pcC n u v with h | h
  · exact False.elim (hn h)
  · exact h

include c0 cs pcC in
theorem selector_same (n u : A) : c n u u = u := by
  rcases selector_cases z s c cs pcC n u u with hn | hc
  · exact hn ▸ c0 u u
  · exact hc

include sep c0 cs in
theorem selector_successor_nonzero (n : A) : s n ≠ z := by
  intro hn
  have hz : c z (s z) z = z := hn ▸ cs n (s z) z
  have hone : s z = z := (c0 (s z) z).symm.trans hz
  exact sep hone.symm

include sep c0 cs pcC in
theorem selector_and (a b : A) :
    c a b (s z) = z ↔ a = z ∧ b = z := by
  rcases zero_decision z s c sep c0 cs pcC a with ha | ha
  · have hc : c a b (s z) = b := ha ▸ c0 b (s z)
    constructor
    · intro h
      exact ⟨ha, hc.symm.trans h⟩
    · intro h
      exact hc.trans h.2
  · have hc := selector_nonzero z s c cs pcC ha b (s z)
    constructor
    · intro h
      exact False.elim (sep (hc.symm.trans h).symm)
    · intro h
      exact False.elim (ha h.1)

include sep c0 cs pcC in
theorem selector_or (a b : A) :
    c a z b = z ↔ a = z ∨ b = z := by
  rcases zero_decision z s c sep c0 cs pcC a with ha | ha
  · have hc : c a z b = z := ha ▸ c0 z b
    exact ⟨fun _ => Or.inl ha, fun _ => hc⟩
  · have hc := selector_nonzero z s c cs pcC ha z b
    constructor
    · intro h
      exact Or.inr (hc.symm.trans h)
    · intro h
      rcases h with h | h
      · exact False.elim (ha h)
      · exact hc.trans h

include sep c0 cs pcC in
theorem selector_imp (a b : A) :
    c a b z = z ↔ (a = z → b = z) := by
  rcases zero_decision z s c sep c0 cs pcC a with ha | ha
  · have hc : c a b z = b := ha ▸ c0 b z
    constructor
    · intro h _
      exact hc.symm.trans h
    · intro h
      exact hc.trans (h ha)
  · have hc := selector_nonzero z s c cs pcC ha b z
    exact ⟨fun _ h => False.elim (ha h), fun _ => hc⟩
end Selector

section Constancy
variable {A : Type u} (z : A) (s : A → A)

theorem ordinary_constancy (f : A → A)
    (pcF : PositiveConstancy z s f)
    (stationary : ∀ n, f (s n) = f n) : ∀ n, f n = f z := by
  intro n
  rcases pcF (fun k => stationary (s k)) n with hn | hf
  · exact congrArg f hn
  · exact hf.trans (stationary z)
end Constancy

section Latch
variable {A : Type u} (z : A) (s : A → A) (c : A → A → A → A)
variable (sep : z ≠ s z)
variable (c0 : ∀ u v, c z u v = u)
variable (cs : ∀ n u v, c (s n) u v = v)
variable (pcC : ∀ u v, PositiveConstancy z s (fun n => c n u v))

/- `q` is the particular latch term obtained from the description of `e`.
The only non-selector PC instance used is the displayed instance `pcQ`. -/
include sep c0 cs pcC in
theorem zero_equation_induction (e q : A → A)
    (q0 : q z = s z)
    (qs : ∀ n, q (s n) = c (e n) (q n) z)
    (pcQ : PositiveConstancy z s q)
    (base : e z = z)
    (step : ∀ n, e n = z → e (s n) = z) : ∀ n, e n = z := by
  have qone : q (s z) = s z := by
    calc
      q (s z) = c (e z) (q z) z := qs z
      _ = c z (q z) z := congrArg (fun t => c t (q z) z) base
      _ = q z := c0 (q z) z
      _ = s z := q0
  have qzero : ∀ n, e n ≠ z → q (s n) = z := by
    intro n hn
    exact (qs n).trans (selector_nonzero z s c cs pcC hn (q n) z)
  have tail : ∀ n, q (s (s n)) = q (s n) := by
    intro n
    rcases zero_decision z s c sep c0 cs pcC (e n) with hn | hn
    · calc
        q (s (s n)) = c (e (s n)) (q (s n)) z := qs (s n)
        _ = c z (q (s n)) z :=
          congrArg (fun t => c t (q (s n)) z) (step n hn)
        _ = q (s n) := c0 (q (s n)) z
    · have hq := qzero n hn
      calc
        q (s (s n)) = c (e (s n)) (q (s n)) z := qs (s n)
        _ = c (e (s n)) z z := congrArg (fun t => c (e (s n)) t z) hq
        _ = z := selector_same z s c c0 cs pcC (e (s n)) z
        _ = q (s n) := hq.symm
  have allone : ∀ n, q (s n) = s z := by
    intro n
    rcases pcQ tail (s n) with hn | hq
    · exact False.elim (selector_successor_nonzero z s c sep c0 cs n hn)
    · exact hq.trans qone
  intro n
  rcases zero_decision z s c sep c0 cs pcC (e n) with hn | hn
  · exact hn
  · have honezero : s z = z := (allone n).symm.trans (qzero n hn)
    exact False.elim (sep honezero.symm)
end Latch

section Involution
variable {A : Type u} (z : A) (r : A → A → A)
variable (r0 : ∀ y, r z y = y)
variable (inv : ∀ x y, r (r x y) y = x)

include r0 inv in
theorem reflection_diagonal (y : A) : r y y = z := by
  calc
    r y y = r (r z y) y := congrArg (fun t => r t y) (r0 y).symm
    _ = z := inv z y

include r0 inv in
theorem equality_reflection (x y : A) : r x y = z ↔ x = y := by
  constructor
  · intro h
    calc
      x = r (r x y) y := (inv x y).symm
      _ = r z y := congrArg (fun t => r t y) h
      _ = y := r0 y
  · intro h
    have hd := reflection_diagonal z r r0 inv y
    exact h ▸ hd

include r0 inv in
theorem equality_decision
    (zeroDec : ∀ a : A, a = z ∨ a ≠ z) (x y : A) : x = y ∨ x ≠ y := by
  rcases zeroDec (r x y) with h | h
  · exact Or.inl ((equality_reflection z r r0 inv x y).mp h)
  · exact Or.inr (fun heq => h ((equality_reflection z r r0 inv x y).mpr heq))
end Involution

/-- Finite external formula syntax.  The terms in an atom have a single
displayed induction variable; all frozen parameters are held in the closure. -/
inductive Formula (A : Type u) where
  | atom : (A → A) → (A → A) → Formula A
  | falsum : Formula A
  | conj : Formula A → Formula A → Formula A
  | disj : Formula A → Formula A → Formula A
  | impl : Formula A → Formula A → Formula A

def Formula.eval {A : Type u} : Formula A → A → Prop
  | .atom lhs rhs, n => lhs n = rhs n
  | .falsum, _ => False
  | .conj f g, n => f.eval n ∧ g.eval n
  | .disj f g, n => f.eval n ∨ g.eval n
  | .impl f g, n => f.eval n → g.eval n

def Formula.error {A : Type u} (z : A) (s : A → A)
    (c : A → A → A → A) (r : A → A → A) : Formula A → A → A
  | .atom lhs rhs, n => r (lhs n) (rhs n)
  | .falsum, _ => s z
  | .conj f g, n => c (f.error z s c r n) (g.error z s c r n) (s z)
  | .disj f g, n => c (f.error z s c r n) z (g.error z s c r n)
  | .impl f g, n => c (f.error z s c r n) (g.error z s c r n) z

section Compiler
variable {A : Type u} (z : A) (s : A → A) (c : A → A → A → A)
variable (sep : z ≠ s z)
variable (c0 : ∀ u v, c z u v = u)
variable (cs : ∀ n u v, c (s n) u v = v)
variable (pcC : ∀ u v, PositiveConstancy z s (fun n => c n u v))
variable (r : A → A → A) (r0 : ∀ y, r z y = y)
variable (inv : ∀ x y, r (r x y) y = x)

include sep c0 cs pcC r0 inv in
theorem formula_compiler (f : Formula A) :
    ∀ n, f.eval n ↔ f.error z s c r n = z := by
  induction f with
  | atom lhs rhs =>
      intro n
      exact (equality_reflection z r r0 inv (lhs n) (rhs n)).symm
  | falsum =>
      intro n
      exact ⟨fun h => False.elim h, fun h => sep h.symm⟩
  | conj f g ihf ihg =>
      intro n
      exact (and_congr (ihf n) (ihg n)).trans
        (selector_and z s c sep c0 cs pcC
          (f.error z s c r n) (g.error z s c r n)).symm
  | disj f g ihf ihg =>
      intro n
      exact (or_congr (ihf n) (ihg n)).trans
        (selector_or z s c sep c0 cs pcC
          (f.error z s c r n) (g.error z s c r n)).symm
  | impl f g ihf ihg =>
      intro n
      have himp : (f.eval n → g.eval n) ↔
          (f.error z s c r n = z → g.error z s c r n = z) := by
        constructor
        · intro h he
          exact (ihg n).mp (h ((ihf n).mpr he))
        · intro h hf
          exact (ihg n).mpr (h ((ihf n).mp hf))
      exact himp.trans (selector_imp z s c sep c0 cs pcC
        (f.error z s c r n) (g.error z s c r n)).symm

/- One quantifier-free induction instance, using just the selector PC
instances and the PC instance for its explicitly supplied latch. -/
include sep c0 cs pcC r0 inv in
theorem quantifier_free_induction (f : Formula A) (q : A → A)
    (q0 : q z = s z)
    (qs : ∀ n, q (s n) = c (f.error z s c r n) (q n) z)
    (pcQ : PositiveConstancy z s q)
    (base : f.eval z)
    (step : ∀ n, f.eval n → f.eval (s n)) : ∀ n, f.eval n := by
  have compile := formula_compiler z s c sep c0 cs pcC r r0 inv f
  have eb : f.error z s c r z = z := (compile z).mp base
  have es : ∀ n, f.error z s c r n = z → f.error z s c r (s n) = z := by
    intro n hn
    exact (compile (s n)).mp (step n ((compile n).mpr hn))
  have allzero := zero_equation_induction z s c sep c0 cs pcC
    (f.error z s c r) q q0 qs pcQ eb es
  intro n
  exact (compile n).mpr (allzero n)
end Compiler

#print axioms successor_injective
#print axioms successor_nonzero
#print axioms zero_decision
#print axioms ordinary_constancy
#print axioms zero_equation_induction
#print axioms equality_reflection
#print axioms equality_decision
#print axioms formula_compiler
#print axioms quantifier_free_induction

end ReflectionCore
