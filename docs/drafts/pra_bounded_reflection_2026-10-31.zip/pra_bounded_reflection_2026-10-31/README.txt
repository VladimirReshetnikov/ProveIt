PRA FROM POSITIVE CONSTANCY AND BOUNDED REFLECTION
Research report prepared for Vladimir Reshetnikov
31 October 2026

Read pra_bounded_reflection.pdf, or compile pra_bounded_reflection.tex.

Main result
-----------
In the full effective language of primitive-recursive descriptions, retain
the defining equations, 0 != S0, positive term constancy (PC), and
    R(R(x,y),y) = x.
The designated function R is given by the short finite recursion printed in
the report and specification.txt. For each of classical and intuitionistic
first-order equality logic separately, the result proves exactly the same
formulas as ordinary first-order PRA in the same language. Both interpretations
and both round trips are the identity.

The principal simplification is native equality reflection in two substitutions.
The involution bridge has 9 formula-tree nodes, versus 13 for the current
minimum-symmetry bridge. The arithmetic display totals 41 nodes at one
parameter; the reflection descriptor costs an additional 9 term nodes.
The report explains why these are not an absolute shortest-encoding claim,
and why the strict binary-iterator comparison has a different cost.

Contents
--------
pra_bounded_reflection.tex / .pdf   Full mathematical report
specification.txt                 Standalone exact specification
formal/ReflectionCore.lean         Constructive arbitrary-carrier core
formal/BoundedReflectionNat.lean    Exact program verification on Lean Nat
artifacts/checks.py / checks.json   Reproducible metrics and finite diagnostics
artifacts/lean_core.log            Checked theorem/axiom output
artifacts/lean_nat.log             Checked program theorem/axiom output
artifacts/validation.json          Validation scope and results
source_audit.json                  Pinned current repository sources
SHA256SUMS                        SHA-256 hashes of delivered files
build.sh / check.sh                Reproduction commands

Build and check
---------------
LaTeX: bash build.sh
Lean and Python: bash check.sh
The checks require Python 3 and Lean 4.19.0 with Std. No Mathlib is needed.
If Lean is not on PATH:
    LEAN_BIN=/absolute/path/to/lean bash check.sh

Verification scope
------------------
The arbitrary-carrier Lean kernel has empty axiom dependencies for the audited
theorems. It treats particular functions and schema instances as hypotheses;
the written report supplies the finite-term discipline. It does not formalize
the complete first-order syntax or the bi-interpretation metatheorem.

The second Lean file proves the exact program's closed form and involution
for all Lean naturals. Its standard tactics use propext and Quot.sound.
It does not replace the internal intuitionistic-PRA derivation in the report.

All numerical tests are finite transcription diagnostics, not proofs of the
universal equivalence theorem. The complete mathematical argument, including
the internal PRA verification and both round trips, is in the report.

Source scope
------------
The six current drafts were inspected at Git commit
3af028c8eb45b393331630537c5a94939c536341. The incoming inventory and index
had no additional PRA-labelled entry. Source archives are identified by
immutable URLs and hashes rather than duplicated here.
