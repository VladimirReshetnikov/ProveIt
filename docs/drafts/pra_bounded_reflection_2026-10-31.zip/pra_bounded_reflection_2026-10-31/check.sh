#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 artifacts/checks.py
lean_cmd="$(printenv LEAN_BIN || true)"
if [ -z "$lean_cmd" ]; then
    lean_cmd=lean
fi
"$lean_cmd" --version
"$lean_cmd" formal/ReflectionCore.lean
"$lean_cmd" formal/BoundedReflectionNat.lean
