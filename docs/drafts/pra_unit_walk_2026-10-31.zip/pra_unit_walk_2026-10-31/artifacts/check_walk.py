#!/usr/bin/env python3
"""Finite syntax checks, exact schematic counts, and bounded walk diagnostics.

This script is NOT a proof of the axiom schema or PRA equivalence.  It checks
formula trees and selected finite traces over ordinary Python natural numbers.
The manuscript and the separately checked Lean development carry the proofs.

Run: python3 artifacts/check_walk.py --output audit/walk_diagnostics.json
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
import json
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class Node:
    kind: str
    label: str = ""
    children: tuple["Node", ...] = ()

    def data(self) -> dict:
        return {"kind": self.kind, "label": self.label,
                "children": [c.data() for c in self.children]}


def var(name: str) -> Node:
    return Node("variable", name)


ZERO = Node("constant", "0")


def app(name: str, *children: Node) -> Node:
    return Node("function", name, tuple(children))


def succ(x: Node) -> Node:
    return app("S", x)


ONE = succ(ZERO)


def form(kind: str, *children: Node, label: str = "") -> Node:
    return Node(kind, label, tuple(children))


def eq(x: Node, y: Node) -> Node:
    return form("equality", x, y)


def imp(x: Node, y: Node) -> Node:
    return form("implies", x, y)


def forall(name: str, body: Node) -> Node:
    return form("forall", body, label=name)


def pred(x: Node) -> Node:
    # P=I_counter: predecessor is the term P(x,0), not a unary primitive.
    return app("P", x, ZERO)


def select(z: Node, u: Node, v: Node) -> Node:
    # C(z,u,v) := P(B(z,S(u)),v).  C selects u at zero, v otherwise.
    return app("P", app("B", z, succ(u)), v)


def zero_test(x: Node) -> Node:
    # Match Z(x)=B(x,1) in the manuscript and gateTerm x oneTerm in Lean.
    return app("B", x, ONE)


def tally(t: Node) -> Counter:
    result = Counter({t.kind: 1})
    for child in t.children:
        result.update(tally(child))
    return result


def free_variables(t: Node) -> set[str]:
    if t.kind == "variable":
        return {t.label}
    result: set[str] = set()
    for child in t.children:
        result |= free_variables(child)
    if t.kind == "forall":
        result.discard(t.label)
    return result


def substitute(t: Node, replacements: dict[str, Node]) -> Node:
    """Capture-free substitution on term trees only; indices are immutable."""
    if t.kind == "variable":
        return replacements.get(t.label, t)
    assert t.kind in {"constant", "function"}, t.kind
    return Node(t.kind, t.label,
                tuple(substitute(c, replacements) for c in t.children))


def expand_placeholder(t: Node, name: str, body: Node,
                       slots: tuple[str, ...]) -> Node:
    children = tuple(expand_placeholder(c, name, body, slots)
                     for c in t.children)
    if t.kind == "function" and t.label == name:
        assert len(children) == len(slots)
        return substitute(body, dict(zip(slots, children)))
    return Node(t.kind, t.label, children)


def validate_term(t: Node, binary_symbols: set[str]) -> None:
    if t.kind in {"variable", "constant"}:
        assert not t.children
        return
    assert t.kind == "function", t.kind
    if t.label == "S":
        assert len(t.children) == 1
    else:
        assert t.label in binary_symbols, t.label
        assert len(t.children) == 2, (t.label, len(t.children))
    for child in t.children:
        validate_term(child, binary_symbols)


def metrics() -> dict:
    n, a, k, v = map(var, ("n", "a", "k", "v"))
    f = lambda x: app("f", x, a)
    separation = imp(eq(ZERO, ONE), form("bottom"))

    def schema(step: Callable[[Node, Node], Node], iterator: str) -> Node:
        premise = forall("n", eq(f(succ(succ(n))), step(n, f(succ(n)))))
        conclusion = forall("n", form("or", eq(n, ZERO),
            eq(f(n), app(iterator, pred(n), f(ONE)))))
        return forall("a", imp(premise,
                                form("and", separation, conclusion)))

    old = schema(lambda x, y: app("h", x, y), "I_h")
    compact = schema(lambda x, y: app("U_c", x, y), "I_U_c")
    expanded = schema(lambda x, y:
        select(app("c", x, y), succ(y), pred(y)), "I_U_c")
    wrapper = select(app("c", k, v), succ(v), pred(v))

    rows = {}
    for label, formula, expected in (
        ("unrestricted_PU_scaffold", old, (39, 4)),
        ("unit_walk_compact_scaffold", compact, (39, 4)),
        ("unit_walk_expanded_wrapper", expanded, (53, 4)),
    ):
        count = tally(formula)
        observed = (sum(count.values()), count["equality"])
        assert observed == expected, (label, observed, expected)
        assert not free_variables(formula)
        rows[label] = {"nodes": observed[0],
                       "equality_occurrences": observed[1],
                       "templates_including_computation": 3,
                       "by_kind": dict(sorted(count.items())),
                       "formula": formula.data()}
    wrapper_count = tally(wrapper)
    assert sum(wrapper_count.values()) == 11
    return {
        "convention": "One node per variable, constant, application, equality, "
            "connective, falsehood, or one-variable quantifier. Expand 1=S0, "
            "p(x)=P(x,0), and in the expanded row C(z,u,v)=P(B(z,S(u)),v). "
            "Schematic term bodies are excluded; their displayed arguments "
            "are included. Stored program indices are part of function-symbol "
            "names, not additional term arguments.",
        "interpretation": "The new restriction does not shorten the compact "
            "PU scaffold. Expanding the fixed unit-step wrapper increases "
            "39 nodes to 53. The improvement is restriction of permitted "
            "updates, not a decrease in literal expanded formula size.",
        "rows": rows,
        "unit_update_wrapper": {"nodes": sum(wrapper_count.values()),
                                "free_variables": sorted(free_variables(wrapper)),
                                "term": wrapper.data()},
        "excluded_costs": ["arbitrary substituted c and f bodies",
                           "stored program-description bit length",
                           "common computation schemas", "proof length"],
    }


def syntax_checks() -> dict:
    k, v, n, a = map(var, ("k", "v", "n", "a"))
    # Each displayed abbreviation below expands into applications of earlier
    # binary iterators.  Their mathematical laws are not proved by this check.
    epsilon = lambda x: app("Parity", x, ZERO)
    half = lambda x: app("Half", x, ZERO)
    double = lambda x: app("Add", x, x)
    encode = lambda x, b: select(b, double(x), succ(double(x)))
    allowed = {"P", "B", "Parity", "Half", "Add"}

    unit_update = select(app("c", k, v), succ(v), pred(v))
    identity_control = epsilon(k)
    identity_lift = select(epsilon(n), app("F", n, a),
                           succ(app("F", n, a)))
    lazy_control = select(epsilon(k), ZERO,
                          zero_test(app("q", half(k), half(v))))
    lazy_lift = encode(app("F", half(n), a), epsilon(n))
    truth_latch_control = select(epsilon(v),
        zero_test(app("F", succ(k), half(v))), ZERO)

    terms = {"unit_update": unit_update,
             "identity_control": identity_control,
             "identity_lift": identity_lift,
             "lazy_control": lazy_control,
             "lazy_lift": lazy_lift,
             "truth_latch_control": truth_latch_control}
    for name, term in terms.items():
        validate_term(term, allowed | {"c", "q", "F"})
        expected = {"n", "a"} if name.endswith("lift") else {"k", "v"}
        assert free_variables(term) <= expected, (name, free_variables(term))

    sample_terms = [ZERO, ONE, k, v, pred(v), app("Add", k, v),
                    select(k, v, succ(v)), select(v, ZERO, k)]
    substitutions = 0
    for sample in sample_terms:
        for proto, placeholder in ((unit_update, "c"), (lazy_control, "q")):
            actual = expand_placeholder(proto, placeholder, sample, ("k", "v"))
            validate_term(actual, allowed)
            assert free_variables(actual) <= {"k", "v"}
            substitutions += 1

    sample_f = [n, a, app("Add", n, a), pred(a), select(n, a, succ(a))]
    for sample in sample_f:
        for proto in (identity_lift, lazy_lift):
            actual = expand_placeholder(proto, "F", sample, ("n", "a"))
            validate_term(actual, allowed)
            assert free_variables(actual) <= {"n", "a"}
            substitutions += 1
        actual = expand_placeholder(truth_latch_control, "F", sample, ("n", "a"))
        validate_term(actual, allowed)
        assert free_variables(actual) <= {"k", "v"}
        substitutions += 1

    forbidden = app("Add", v, a)
    assert not free_variables(forbidden) <= {"k", "v"}
    bad_self_rejected = False
    try:
        validate_term(app("Self", k, v), allowed)
    except AssertionError:
        bad_self_rejected = True
    assert bad_self_rejected

    return {
        "terms": {name: {"free_variables": sorted(free_variables(term)),
                          "term": term.data()} for name, term in terms.items()},
        "substitution_checks": substitutions,
        "rejected_frozen_parameter": sorted(free_variables(forbidden)),
        "rejected_undeclared_self_reference": bad_self_rejected,
        "scope": "Finite term scope and substitution checks. A stored "
            "iterator description remains immutable under ordinary term "
            "substitution. All actual controls have only k,v free; trajectory "
            "terms have only n,a free. No semantic admission test is used.",
    }


def choose(z: int, u: int, v: int) -> int:
    return u if z == 0 else v


def predecessor(x: int) -> int:
    assert x >= 0
    return max(x - 1, 0)


def ztest(x: int) -> int:
    return choose(x, 1, 0)


def walk_step(control: Callable[[int, int], int], k: int, v: int) -> int:
    c = control(k, v)
    assert isinstance(c, int) and c >= 0
    return choose(c, v + 1, predecessor(v))


def iterate(step: Callable[[int, int], int], start: int, ticks: int) -> list[int]:
    state = start
    trace = [state]
    for k in range(ticks):
        state = step(k, state)
        assert isinstance(state, int) and state >= 0
        trace.append(state)
    return trace


def finite_diagnostics() -> dict:
    checks: Counter = Counter()
    seeds = [0, 1, 2, 3, 4, 7, 8, 15, 16, 31, 63, 64, 127]
    ticks = 80

    # If F(k,a)=b is stationary, its parity lift alternates b,Sb.  The
    # control is parity(k), with no dependence on the fixed parameter a.
    for a in seeds:
        for b in (a, a * a + 1, predecessor(a)):
            trace = iterate(lambda k, v: walk_step(lambda j, w: j % 2, k, v),
                            b, ticks)
            for k in range(ticks + 1):
                lifted = choose(k % 2, b, b + 1)
                assert trace[k] == lifted
                recovered = trace[k] if k % 2 == 0 else predecessor(trace[k])
                assert recovered == b
                checks["identity_lift_and_decode"] += 1

    controls: list[tuple[str, Callable[[int, int], int]]] = [
        ("always_stay", lambda n, v: 0),
        ("always_up", lambda n, v: 1),
        ("positive_nonboolean", lambda n, v: 7),
        ("counter_zero", lambda n, v: n),
        ("state_zero", lambda n, v: v),
        ("counter_parity", lambda n, v: n % 2),
        ("state_parity", lambda n, v: v % 2),
        ("mixed_parity", lambda n, v: (n + v) % 2),
        ("moving_threshold", lambda n, v: int(v <= n)),
        ("strict_moving_threshold", lambda n, v: int(v < n)),
        ("sparse_state_counter", lambda n, v: (3 * n + v * v) % 5),
        ("alternating_blocks", lambda n, v: (n // 3 + v // 2) % 2),
        ("large_values", lambda n, v: (n + 2 * v) ** 2),
    ]
    samples = []
    for name, q in controls:
        for start in seeds:
            lazy = iterate(lambda n, v: choose(q(n, v), v, v + 1), start, ticks)

            def control(k: int, v: int) -> int:
                return choose(k % 2, 0, ztest(q(k // 2, v // 2)))

            unit = iterate(lambda k, v: walk_step(control, k, v),
                           2 * start, 2 * ticks)
            for n in range(ticks):
                assert unit[2 * n] == 2 * lazy[n]
                assert unit[2 * n + 1] == 2 * lazy[n] + 1
                assert unit[2 * n + 2] == 2 * lazy[n + 1]
                assert unit[2 * n] // 2 == lazy[n]
                assert unit[2 * n + 1] // 2 == lazy[n]
                checks["two_tick_lazy_simulation"] += 1
                checks["lazy_stay_pairs" if q(n, lazy[n]) == 0
                       else "lazy_up_pairs"] += 1
            assert unit[-1] == 2 * lazy[-1]
            if start in (0, 3) and name in (
                    "always_stay", "always_up", "mixed_parity",
                    "sparse_state_counter", "moving_threshold"):
                samples.append({"control": name, "initial_state": start,
                                "lazy_first_9_states": lazy[:9],
                                "unit_first_17_states": unit[:17]})

    # Direct unit walks, including down-at-zero saturation, provide a second
    # check that controls are zero/nonzero tests, not necessarily Boolean.
    for name, c in controls:
        for start in seeds:
            trace = iterate(lambda k, v: walk_step(c, k, v), start, ticks)
            for k, (before, after) in enumerate(zip(trace, trace[1:])):
                assert after == (before + 1 if c(k, before) == 0
                                 else max(before - 1, 0))
                assert abs(after - before) <= 1
                checks["unit_local_steps"] += 1
                if before == 0 and c(k, before) != 0:
                    assert after == 0
                    checks["down_at_zero"] += 1

    assert checks["lazy_stay_pairs"] and checks["lazy_up_pairs"]
    assert checks["down_at_zero"]
    # A single standard-natural witness excludes these updates from the raw
    # unit-step family, irrespective of the chosen control.  This says nothing
    # about the derivability of their uniqueness principles in the theory.
    witness_state = 2
    permitted_outputs = [predecessor(witness_state), witness_state + 1]
    excluded_outputs = {"identity": witness_state,
                        "successor_twice": witness_state + 2,
                        "reset_zero": 0}
    for output in excluded_outputs.values():
        assert output not in permitted_outputs
    return {
        "scope": "Deterministic bounded checks on ordinary natural numbers; "
            "these are diagnostics, not universal proofs or finite-model "
            "verification of the first-order schema.",
        "seeds": seeds,
        "lazy_ticks_per_trace": ticks,
        "controls": [name for name, _ in controls],
        "checks": dict(sorted(checks.items())),
        "sample_traces": samples,
        "strict_update_restriction_witness": {
            "state": witness_state, "counter": 0,
            "permitted_unit_outputs": permitted_outputs,
            "excluded_update_outputs": excluded_outputs,
            "scope": "Raw update restriction only; the theory can derive "
                     "uniqueness for larger classes of updates."},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        help="Write the full JSON report to this path.")
    args = parser.parse_args()
    report = {"status": "passed",
              "formula_metrics": metrics(),
              "syntax_checks": syntax_checks(),
              "finite_diagnostics": finite_diagnostics(),
              "not_established_by_this_script": [
                  "PRA equivalence", "intuitionistic derivability",
                  "schema completeness", "global minimality",
                  "historical novelty", "Lean proof validity"]}
    encoded = json.dumps(report, indent=2) + "\n"
    if args.output is None:
        print(encoded, end="")
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
        print("Passed: exact formula counts, term scopes, and bounded walk diagnostics.")
        print("Compact PU: 39 nodes; expanded unit wrapper: 53 nodes; both 4 equalities.")
        print("Diagnostics are not a proof of PRA equivalence.")
        print(f"Report: {args.output}")


if __name__ == "__main__":
    main()
