/-
PRA from positive uniqueness of unit walks: constructive finite-syntax core.
Lean 4.19.0; no imports or external packages.

The finite Term/evaluation scaffold is adapted from PositiveUniqueness.lean
in ProveIt's pra_positive_uniqueness_2026-10-31 (1).zip, Git blob
04b1744536734af480cdee7117a5ec27965cfcbb, snapshot
60cefaa503c2a54dacf2fd03e75c68f9c2c65d80. The restricted walk schema,
parity lift, two-phase simulation and monotone latch are verified below.

The carrier is arbitrary. Induction below is only structural induction on
finite terms, never induction on the arithmetic carrier. The UnitSchema
quantifies over finite terms and one fixed numerical parameter. Its controls
have exactly a counter and current-state slot. The selector used here is
P(B(z,S(u)),v), so both selector equations are computation consequences.

This file certifies separation, constructor coverage, contextual unit-walk
uniqueness, and contextual constancy by the alternating parity lift. It then
derives the arithmetic clock and its retractions internally, and certifies
the two-phase upward lift and contextual uniqueness for every stay-or-up
control. A truth-bit latch then gives contextual zero-equation induction
with one fixed numerical parameter. No extra local arithmetic or clock
hypotheses are assumed. The complete manuscript equivalence to PRA is not
asserted to be one linked formal theorem.
-/

namespace UnitWalk

universe u

inductive Term where
  | first
  | second
  | zero
  | succ (argument : Term)
  | iter (update counter seed : Term)
  deriving DecidableEq

def substitute : Term → Term → Term → Term
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => .zero
  | .succ t, x, y => .succ (substitute t x y)
  | .iter h n a, x, y => .iter h (substitute n x y) (substitute a x y)

def evaluate {A : Type u} (zero : A) (succ : A → A)
    (run : Term → A → A → A) : Term → A → A → A
  | .first, x, _ => x
  | .second, _, y => y
  | .zero, _, _ => zero
  | .succ t, x, y => succ (evaluate zero succ run t x y)
  | .iter h n a, x, y =>
      run h (evaluate zero succ run n x y) (evaluate zero succ run a x y)

structure Model (A : Type u) where
  zero : A
  succ : A → A
  run : Term → A → A → A
  run_zero : ∀ h a, run h zero a = a
  run_succ : ∀ h n a,
    run h (succ n) a = evaluate zero succ run h n (run h n a)

def value {A : Type u} (C : Model A) (t : Term) (x y : A) : A :=
  evaluate C.zero C.succ C.run t x y

variable {A : Type u} (C : Model A)

theorem value_substitute (t x y : Term) (n a : A) :
    value C (substitute t x y) n a =
      value C t (value C x n a) (value C y n a) := by
  induction t with
  | first => rfl
  | second => rfl
  | zero => rfl
  | succ t ih => exact congrArg C.succ ih
  | iter h n' a' _ ihn iha =>
      change C.run h (value C (substitute n' x y) n a)
          (value C (substitute a' x y) n a) =
        C.run h (value C n' (value C x n a) (value C y n a))
          (value C a' (value C x n a) (value C y n a))
      exact congr (congrArg (C.run h) ihn) iha

def oneTerm : Term := .succ .zero
def predTerm (t : Term) : Term := .iter .first t .zero
def gateTerm (s t : Term) : Term := .iter .zero s t
def selectTerm (z x y : Term) : Term :=
  .iter .first (gateTerm z (.succ x)) y
def controlTerm (c : Term) : Term :=
  selectTerm c (.succ .second) (predTerm .second)
def parityTerm (t : Term) : Term :=
  .iter (gateTerm .second oneTerm) t .zero

def one : A := C.succ C.zero
def pred (x : A) : A := C.run .first x C.zero
def gate (x y : A) : A := C.run .zero x y
def select (z x y : A) : A := C.run .first (gate C z (C.succ x)) y
def parity (x : A) : A := C.run (gateTerm .second oneTerm) x C.zero

theorem pred_zero : pred C C.zero = C.zero := C.run_zero _ _
theorem pred_succ (x : A) : pred C (C.succ x) = x := C.run_succ _ _ _
theorem gate_zero (x : A) : gate C C.zero x = x := C.run_zero _ _
theorem gate_succ (x y : A) : gate C (C.succ x) y = C.zero :=
  C.run_succ _ _ _
theorem select_zero (x y : A) : select C C.zero x y = x := by
  unfold select
  rw [gate_zero C]
  exact C.run_succ _ _ _
theorem select_succ (z x y : A) : select C (C.succ z) x y = y := by
  unfold select
  rw [gate_succ C]
  exact C.run_zero _ _
theorem value_select (z x y : Term) (n a : A) :
    value C (selectTerm z x y) n a =
      select C (value C z n a) (value C x n a) (value C y n a) := rfl
theorem value_control (c : Term) (n v : A) :
    value C (controlTerm c) n v =
      select C (value C c n v) (C.succ v) (pred C v) := rfl
theorem control_zero (n v : A) :
    value C (controlTerm .zero) n v = C.succ v := select_zero C _ _
theorem control_one (n v : A) :
    value C (controlTerm oneTerm) n v = pred C v := select_succ C _ _ _
theorem parity_zero : parity C C.zero = C.zero := C.run_zero _ _
theorem parity_succ (n : A) :
    parity C (C.succ n) = gate C (parity C n) (one C) :=
  C.run_succ _ _ _

/-- Exactly one numerical parameter and finite control syntax. -/
def UnitSchema : Prop :=
  ∀ t c : Term, ∀ a : A,
    (∀ n, value C t (C.succ (C.succ n)) a =
      value C (controlTerm c) n (value C t (C.succ n) a)) →
    C.zero ≠ C.succ C.zero ∧
      ∀ n, n = C.zero ∨
        value C t n a =
          C.run (controlTerm c) (pred C n) (value C t (one C) a)

variable (UW : UnitSchema C)
include UW

theorem separation : C.zero ≠ C.succ C.zero := by
  have h := UW .first .zero C.zero (by
    intro n
    exact (control_zero C n (C.succ n)).symm)
  exact h.1

omit UW in
theorem successor_injective {x y : A} (h : C.succ x = C.succ y) : x = y := by
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_succ C] at e
  exact e

theorem successor_ne_zero (x : A) : C.succ x ≠ C.zero := by
  intro h
  have e := congrArg (pred C) h
  rw [pred_succ C, pred_zero C] at e
  have bad : C.succ C.zero = C.zero := (congrArg C.succ e).symm.trans h
  exact separation C UW bad.symm

/-- Ordinary uniqueness, still restricted to unit-walk updates. -/
theorem unit_uniqueness (t c : Term) (a : A)
    (step : ∀ n, value C t (C.succ n) a =
      value C (controlTerm c) n (value C t n a)) :
    ∀ n, value C t n a =
      C.run (controlTerm c) n (value C t C.zero a) := by
  let delayed := substitute t (predTerm .first) .second
  have delay (x : A) : value C delayed x a = value C t (pred C x) a := by
    exact value_substitute C t (predTerm .first) .second x a
  have positive := UW delayed c a (by
    intro n
    rw [delay, delay, pred_succ C, pred_succ C]
    exact step n)
  intro n
  rcases positive.2 (C.succ n) with hz | he
  · exact False.elim (successor_ne_zero C UW n hz)
  · rw [delay, delay, pred_succ C] at he
    change value C t n a =
      C.run (controlTerm c) n (value C t (pred C (C.succ C.zero)) a) at he
    rw [pred_succ C] at he
    exact he

theorem unit_comparison (t s c : Term) (a : A)
    (base : value C t C.zero a = value C s C.zero a)
    (tstep : ∀ n, value C t (C.succ n) a =
      value C (controlTerm c) n (value C t n a))
    (sstep : ∀ n, value C s (C.succ n) a =
      value C (controlTerm c) n (value C s n a)) :
    ∀ n, value C t n a = value C s n a := by
  intro n
  rw [unit_uniqueness C UW t c a tstep n,
      unit_uniqueness C UW s c a sstep n, base]

theorem coverage (x : A) : x = C.zero ∨ x = C.succ (pred C x) := by
  have h₁ := UW .first .zero C.zero (by
    intro n
    exact (control_zero C n (C.succ n)).symm)
  let t : Term := .succ (predTerm .first)
  have compute (n a : A) : value C t n a = C.succ (pred C n) := rfl
  have h₂ := UW t .zero C.zero (by
    intro n
    rw [compute, compute, pred_succ C, pred_succ C, control_zero C])
  rcases h₁.2 x with hz | he₁
  · exact Or.inl hz
  · rcases h₂.2 x with hz | he₂
    · exact Or.inl hz
    · right
      change x = C.run (controlTerm .zero) (pred C x) (one C) at he₁
      rw [compute, compute] at he₂
      change C.succ (pred C x) =
        C.run (controlTerm .zero) (pred C x) (C.succ (pred C (C.succ C.zero)))
        at he₂
      rw [pred_succ C] at he₂
      exact he₁.trans he₂.symm

theorem zero_decision (x : A) : x = C.zero ∨ x ≠ C.zero := by
  rcases coverage C UW x with hz | hs
  · exact Or.inl hz
  · exact Or.inr (fun hz =>
      successor_ne_zero C UW (pred C x) (hs.symm.trans hz))

theorem gate_range (x : A) :
    gate C x (one C) = C.zero ∨ gate C x (one C) = one C := by
  rcases coverage C UW x with hz | hs
  · rw [hz, gate_zero C]
    exact Or.inr rfl
  · rw [hs, gate_succ C]
    exact Or.inl rfl

theorem parity_range (x : A) : parity C x = C.zero ∨ parity C x = one C := by
  rcases coverage C UW x with hz | hs
  · rw [hz, parity_zero C]
    exact Or.inl rfl
  · rw [hs, parity_succ C]
    exact gate_range C UW _

/-- The identity update is recovered from a genuinely moving update. -/
theorem constancy (t : Term) (a : A)
    (step : ∀ n, value C t (C.succ n) a = value C t n a) :
    ∀ n, value C t n a = value C t C.zero a := by
  let frozen := substitute t .zero .second
  let lift (s : Term) := selectTerm (parityTerm .first) s (.succ s)
  let ctl := parityTerm .first
  have lift_value (s : Term) (n : A) :
      value C (lift s) n a =
        select C (parity C n) (value C s n a) (C.succ (value C s n a)) := rfl
  have frozen_value (n : A) : value C frozen n a = value C t C.zero a := by
    exact value_substitute C t .zero .second n a
  have lifted_step (s : Term)
      (stationary : ∀ n, value C s (C.succ n) a = value C s n a) :
      ∀ n, value C (lift s) (C.succ n) a =
        value C (controlTerm ctl) n (value C (lift s) n a) := by
    intro n
    rw [lift_value, lift_value, value_control]
    change select C (parity C (C.succ n)) (value C s (C.succ n) a)
        (C.succ (value C s (C.succ n) a)) =
      select C (parity C n)
        (C.succ (select C (parity C n) (value C s n a)
          (C.succ (value C s n a))))
        (pred C (select C (parity C n) (value C s n a)
          (C.succ (value C s n a))))
    rw [stationary n, parity_succ C]
    rcases parity_range C UW n with he | he
    · rw [he, gate_zero C, select_zero C, select_zero C]
      exact select_succ C C.zero _ _
    · rw [he]
      unfold one
      rw [gate_succ C, select_zero C, select_succ C, select_succ C, pred_succ C]
  have both := unit_comparison C UW (lift t) (lift frozen) ctl a (by
    rw [lift_value, lift_value, parity_zero C, select_zero C, select_zero C,
      frozen_value])
    (lifted_step t step)
    (lifted_step frozen (by intro n; rw [frozen_value, frozen_value]))
  intro n
  have eq := both n
  rw [lift_value, lift_value, frozen_value] at eq
  rcases parity_range C UW n with he | he
  · rw [he, select_zero C, select_zero C] at eq
    exact eq
  · rw [he] at eq
    unfold one at eq
    rw [select_succ C, select_succ C] at eq
    exact successor_injective C eq

/-- Comparison for successor, without identifying two stored descriptors. -/
theorem successor_comparison (t s : Term) (a : A)
    (base : value C t C.zero a = value C s C.zero a)
    (tstep : ∀ n, value C t (C.succ n) a = C.succ (value C t n a))
    (sstep : ∀ n, value C s (C.succ n) a = C.succ (value C s n a)) :
    ∀ n, value C t n a = value C s n a := by
  apply unit_comparison C UW t s .zero a base
  · intro n
    rw [control_zero C]
    exact tstep n
  · intro n
    rw [control_zero C]
    exact sstep n

def addTerm (x y : Term) : Term := .iter (.succ .second) x y
def doubleTerm (x : Term) : Term := addTerm x x
def halfTerm (x : Term) : Term :=
  .iter (selectTerm (parityTerm .first) .second (.succ .second)) x .zero

def add (x y : A) : A := C.run (.succ .second) x y
def double (x : A) : A := add C x x
def half (x : A) : A :=
  C.run (selectTerm (parityTerm .first) .second (.succ .second)) x C.zero

omit UW in
theorem add_zero (x : A) : add C C.zero x = x := C.run_zero _ _
omit UW in
theorem add_succ (x y : A) : add C (C.succ x) y = C.succ (add C x y) :=
  C.run_succ _ _ _
omit UW in
theorem half_zero : half C C.zero = C.zero := C.run_zero _ _
omit UW in
theorem half_succ (n : A) : half C (C.succ n) =
    select C (parity C n) (half C n) (C.succ (half C n)) :=
  C.run_succ _ _ _

theorem add_right_zero (x : A) : add C x C.zero = x := by
  apply successor_comparison C UW (addTerm .first .zero) .first C.zero
    (add_zero C C.zero) (fun n => add_succ C n C.zero) (fun _ => rfl) x

theorem add_right_succ (x y : A) : add C x (C.succ y) = C.succ (add C x y) := by
  apply successor_comparison C UW (addTerm .first (.succ .second))
    (.succ (addTerm .first .second)) y
  · change add C C.zero (C.succ y) = C.succ (add C C.zero y)
    rw [add_zero C, add_zero C]
  · exact fun n => add_succ C n (C.succ y)
  · intro n
    change C.succ (add C (C.succ n) y) = C.succ (C.succ (add C n y))
    rw [add_succ C]

omit UW in
theorem double_zero : double C C.zero = C.zero := add_zero C _
theorem double_succ (n : A) : double C (C.succ n) = C.succ (C.succ (double C n)) := by
  unfold double
  rw [add_succ C, add_right_succ C UW]

theorem parity_two_steps (n : A) : parity C (C.succ (C.succ n)) = parity C n := by
  rw [parity_succ C, parity_succ C]
  rcases parity_range C UW n with he | he
  · rw [he, gate_zero C]
    exact gate_succ C C.zero _
  · rw [he]
    unfold one
    rw [gate_succ C, gate_zero C]

theorem half_two_steps (n : A) : half C (C.succ (C.succ n)) = C.succ (half C n) := by
  rw [half_succ C, half_succ C, parity_succ C]
  rcases parity_range C UW n with he | he
  · rw [he, gate_zero C, select_zero C]
    exact select_succ C C.zero _ _
  · rw [he]
    unfold one
    rw [gate_succ C, select_succ C, select_zero C]

theorem parity_double (n : A) : parity C (double C n) = C.zero := by
  have h := constancy C UW (parityTerm (doubleTerm .first)) C.zero (by
    intro x
    change parity C (double C (C.succ x)) = parity C (double C x)
    rw [double_succ C UW, parity_two_steps C UW]) n
  change parity C (double C n) = parity C (double C C.zero) at h
  rw [double_zero C, parity_zero C] at h
  exact h

theorem parity_succ_double (n : A) : parity C (C.succ (double C n)) = one C := by
  rw [parity_succ C, parity_double C UW, gate_zero C]

theorem half_double (n : A) : half C (double C n) = n := by
  apply successor_comparison C UW (halfTerm (doubleTerm .first)) .first C.zero
  · change half C (double C C.zero) = C.zero
    rw [double_zero C, half_zero C]
  · intro x
    change half C (double C (C.succ x)) = C.succ (half C (double C x))
    rw [double_succ C UW, half_two_steps C UW]
  · exact fun _ => rfl

theorem half_succ_double (n : A) : half C (C.succ (double C n)) = n := by
  rw [half_succ C, parity_double C UW, select_zero C, half_double C UW]

/-- A stay-or-up update. Its descriptor differs from a unit control. -/
def lazyTerm (q : Term) : Term := selectTerm q .second (.succ .second)

def liftTerm (t : Term) : Term :=
  let f := substitute t (halfTerm .first) .second
  selectTerm (parityTerm .first) (doubleTerm f) (.succ (doubleTerm f))

/-- Counter and state are the only free slots; the frozen parameter is absent. -/
def liftedControl (q : Term) : Term :=
  selectTerm (parityTerm .first) .zero
    (gateTerm (substitute q (halfTerm .first) (halfTerm .second)) oneTerm)

omit UW in
theorem value_lazy (q : Term) (n v : A) :
    value C (lazyTerm q) n v = select C (value C q n v) v (C.succ v) := rfl

omit UW in
theorem value_lift (t : Term) (n a : A) :
    value C (liftTerm t) n a =
      select C (parity C n) (double C (value C t (half C n) a))
        (C.succ (double C (value C t (half C n) a))) := by
  let f := substitute t (halfTerm .first) .second
  change select C (parity C n) (double C (value C f n a))
      (C.succ (double C (value C f n a))) = _
  have h : value C f n a = value C t (half C n) a :=
    value_substitute C t (halfTerm .first) .second n a
  rw [h]

omit UW in
theorem value_lifted_control (q : Term) (n v : A) :
    value C (liftedControl q) n v =
      select C (parity C n) C.zero
        (gate C (value C q (half C n) (half C v)) (one C)) := by
  change select C (parity C n) C.zero
    (gate C (value C (substitute q (halfTerm .first) (halfTerm .second)) n v)
      (one C)) = _
  rw [value_substitute C]
  rfl

/-- The two-phase lift is a unit walk, proved before any induction axiom. -/
theorem lift_step (t q : Term) (a : A)
    (step : ∀ n, value C t (C.succ n) a =
      value C (lazyTerm q) n (value C t n a)) :
    ∀ n, value C (liftTerm t) (C.succ n) a =
      value C (controlTerm (liftedControl q)) n (value C (liftTerm t) n a) := by
  intro n
  rw [value_lift, value_control, value_lifted_control, value_lift]
  rcases parity_range C UW n with he | he
  · have he' : parity C (C.succ n) = one C := by
      rw [parity_succ C, he, gate_zero C]
    have hh : half C (C.succ n) = half C n := by
      rw [half_succ C, he, select_zero C]
    rw [he', hh, he, select_zero C, select_zero C, select_zero C]
    exact select_succ C C.zero _ _
  · have he' : parity C (C.succ n) = C.zero := by
      rw [parity_succ C, he]
      exact gate_succ C C.zero _
    have hh : half C (C.succ n) = C.succ (half C n) := by
      rw [half_succ C, he]
      exact select_succ C C.zero _ _
    rw [he', hh, he, select_zero C]
    change double C (value C t (C.succ (half C n)) a) =
      select C
        (select C (C.succ C.zero) C.zero
          (gate C
            (value C q (half C n)
              (half C (select C (C.succ C.zero)
                (double C (value C t (half C n) a))
                (C.succ (double C (value C t (half C n) a)))))) (one C)))
        (C.succ (select C (C.succ C.zero)
          (double C (value C t (half C n) a))
          (C.succ (double C (value C t (half C n) a)))))
        (pred C (select C (C.succ C.zero)
          (double C (value C t (half C n) a))
          (C.succ (double C (value C t (half C n) a)))))
    rw [select_succ C, select_succ C, half_succ_double C UW,
      pred_succ C, step (half C n), value_lazy]
    rcases coverage C UW (value C q (half C n) (value C t (half C n) a))
      with hz | hs
    · rw [hz, select_zero C, gate_zero C]
      exact (select_succ C C.zero _ _).symm
    · rw [hs, select_succ C, gate_succ C, select_zero C, double_succ C UW]

theorem lift_at_double (t : Term) (a n : A) :
    value C (liftTerm t) (double C n) a = double C (value C t n a) := by
  rw [value_lift, parity_double C UW, half_double C UW, select_zero C]

/-- Full finite-term comparison for every stay-or-up control. -/
theorem lazy_comparison (t s q : Term) (a : A)
    (base : value C t C.zero a = value C s C.zero a)
    (tstep : ∀ n, value C t (C.succ n) a =
      value C (lazyTerm q) n (value C t n a))
    (sstep : ∀ n, value C s (C.succ n) a =
      value C (lazyTerm q) n (value C s n a)) :
    ∀ n, value C t n a = value C s n a := by
  have lifted := unit_comparison C UW (liftTerm t) (liftTerm s)
    (liftedControl q) a (by
      rw [value_lift, value_lift, parity_zero C, half_zero C,
        select_zero C, select_zero C, base])
    (lift_step C UW t q a tstep) (lift_step C UW s q a sstep)
  intro n
  have h := lifted (double C n)
  rw [lift_at_double C UW, lift_at_double C UW] at h
  have h' := congrArg (half C) h
  rw [half_double C UW, half_double C UW] at h'
  exact h'

/-- Contextual ordinary uniqueness for every stay-or-up update. -/
theorem lazy_uniqueness (t q : Term) (a : A)
    (step : ∀ n, value C t (C.succ n) a =
      value C (lazyTerm q) n (value C t n a)) :
    ∀ n, value C t n a = C.run (lazyTerm q) n (value C t C.zero a) := by
  let initial := substitute t .zero .second
  let canonical : Term := .iter (lazyTerm q) .first initial
  have initial_value (n : A) : value C initial n a = value C t C.zero a :=
    value_substitute C t .zero .second n a
  have canonical_value (n : A) : value C canonical n a =
      C.run (lazyTerm q) n (value C t C.zero a) := by
    change C.run (lazyTerm q) n (value C initial n a) = _
    rw [initial_value]
  have h := lazy_comparison C UW t canonical q a (by
      rw [canonical_value, C.run_zero]) step (by
      intro n
      rw [canonical_value, canonical_value]
      exact C.run_succ _ _ _)
  intro n
  rw [← canonical_value]
  exact h n

/-- Encode the sole frozen parameter together with the truth bit of t = 0. -/
def truthEncodingTerm (t : Term) : Term :=
  selectTerm (gateTerm t oneTerm) (doubleTerm .second)
    (.succ (doubleTerm .second))

/-- Only counter and state occur freely; the parameter is decoded from state. -/
def truthLatchControl (t : Term) : Term :=
  selectTerm (parityTerm .second)
    (gateTerm (substitute t (.succ .first) (halfTerm .second)) oneTerm) .zero

omit UW in
theorem value_truth_encoding (t : Term) (n a : A) :
    value C (truthEncodingTerm t) n a =
      select C (gate C (value C t n a) (one C))
        (double C a) (C.succ (double C a)) := rfl

omit UW in
theorem value_truth_control (t : Term) (n v : A) :
    value C (truthLatchControl t) n v =
      select C (parity C v)
        (gate C (value C t (C.succ n) (half C v)) (one C)) C.zero := by
  change select C (parity C v)
    (gate C (value C (substitute t (.succ .first) (halfTerm .second)) n v)
      (one C)) C.zero = _
  rw [value_substitute C]
  rfl

/-- Full contextual induction for equations t(n,a) = 0, on finite syntax. -/
theorem zero_induction (t : Term) (a : A)
    (base : value C t C.zero a = C.zero)
    (step : ∀ n, value C t n a = C.zero → value C t (C.succ n) a = C.zero) :
    ∀ n, value C t n a = C.zero := by
  let encoded := truthEncodingTerm t
  let constant : Term := .succ (doubleTerm .second)
  let q := truthLatchControl t
  have encoded_value (n : A) : value C encoded n a =
      select C (gate C (value C t n a) (one C))
        (double C a) (C.succ (double C a)) := rfl
  have constant_value (n : A) : value C constant n a = C.succ (double C a) := rfl
  have control_value (n v : A) : value C q n v =
      select C (parity C v)
        (gate C (value C t (C.succ n) (half C v)) (one C)) C.zero :=
    value_truth_control C t n v
  have encoded_step (n : A) : value C encoded (C.succ n) a =
      value C (lazyTerm q) n (value C encoded n a) := by
    rw [encoded_value, value_lazy, encoded_value, control_value]
    rcases coverage C UW (value C t n a) with hz | hs
    · rw [hz, gate_zero C, step n hz]
      unfold one
      rw [gate_zero C, select_succ C,
        parity_succ_double C UW, half_succ_double C UW]
      unfold one
      rw [select_succ C, select_zero C]
    · rw [hs, gate_succ C, select_zero C, parity_double C UW,
        half_double C UW, select_zero C]
  have constant_step (n : A) : value C constant (C.succ n) a =
      value C (lazyTerm q) n (value C constant n a) := by
    rw [constant_value, constant_value, value_lazy, control_value,
      parity_succ_double C UW]
    unfold one
    rw [select_succ C, select_zero C]
  have equal := lazy_comparison C UW encoded constant q a (by
    rw [encoded_value, constant_value, base, gate_zero C]
    exact select_succ C C.zero _ _) encoded_step constant_step
  intro n
  rcases coverage C UW (value C t n a) with hz | hs
  · exact hz
  · have bad := equal n
    rw [encoded_value, constant_value, hs, gate_succ C, select_zero C] at bad
    have parity_bad := congrArg (parity C) bad
    rw [parity_double C UW, parity_succ_double C UW] at parity_bad
    exact False.elim (separation C UW parity_bad)

#print axioms separation
#print axioms unit_uniqueness
#print axioms coverage
#print axioms constancy
#print axioms parity_double
#print axioms half_double
#print axioms lift_step
#print axioms lazy_comparison
#print axioms lazy_uniqueness
#print axioms zero_induction

end UnitWalk
