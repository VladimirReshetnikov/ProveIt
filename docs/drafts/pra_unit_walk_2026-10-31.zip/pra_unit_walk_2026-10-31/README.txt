Primitive Recursive Arithmetic from Up/Down Walks
31 October 2026
================================================

MAIN RESULT

The same nonlogical basis works for classical and intuitionistic PRA:
initialized binary iterator computation equations plus positive uniqueness
only for updates W_c(k,v)=C(c(k,v),S(v),p(v)). The update moves to successor
or predecessor. The complete effective syntax is in axioms.txt.

This improves the strongest inspected binary positive-uniqueness draft by
strictly restricting the arithmetic update family. It does not reduce the
fully expanded formula length: the counts are 53 nodes versus 39, with four
equality occurrences in both. There is no claim of absolute minimality.

CONTENTS

pra_unit_walk.pdf       Compiled research article with full written proof.
pra_unit_walk.tex       Complete LaTeX source, no external figure dependencies.
axioms.txt              Standalone exact specification.
formal/UnitWalk.lean    Constructive finite-syntax certificate, Lean 4.19.0.
formal/UnitWalk.log     Successful check and ten empty axiom dependency sets.
artifacts/check_walk.py Independent simulation diagnostics and syntax metrics.
audit/walk_diagnostics.json  Recorded diagnostic results.
audit/source_manifest.json   Pinned source URLs, Git hashes, and SHA-256 hashes.
audit/proof_review.txt       Independent mathematical review of the report.
VALIDATION.txt          Exact checked scope and limitations.
Makefile               Optional build/check commands.
SHA256SUMS             Hashes of the delivered files except this hash manifest.

BUILD

Requires a standard LaTeX installation with latexmk and the packages named
in the source (TeX Live 2023 or newer suffices):

  latexmk -pdf -interaction=nonstopmode -halt-on-error pra_unit_walk.tex

CHECK LEAN

Install Lean 4.19.0 and put its binary on PATH, then run:

  lean formal/UnitWalk.lean

No Mathlib, Lake project, or external Lean imports are needed. The final
theorem is UnitWalk.zero_induction. It depends only on the model's two
computation equations and its exact finite-term UW schema, all passed as
explicit theorem hypotheses. No classical logic or arithmetic-domain
induction is added. The file prints dependency audits for ten key theorems.

RUN DIAGNOSTICS

Requires Python 3.10 or newer; uses only the standard library:

  python3 artifacts/check_walk.py --output audit/walk_diagnostics.json

Finite numerical tests do not prove the theory-equivalence result. They
independently exercise the two lifts and make the size convention reproducible.

CHECK ARCHIVE CONTENT HASHES

  sha256sum -c SHA256SUMS

SOURCE AND PROOF PROVENANCE

All six current ProveIt draft archives and the incoming README were inspected
at commit 60cefaa503c2a54dacf2fd03e75c68f9c2c65d80. The strongest like-for-like
baseline is pra_positive_uniqueness_2026-10-31 (1).zip. The report credits the
inherited binary language, positive schema, and completion arguments. The new
result is the unit-walk restriction and its constructive reductions.

The Lean term/evaluation scaffold follows the inspected finite-syntax
PositiveUniqueness.lean certificate; the restricted schema, parity lift,
two-tick reduction, and monotone latch are checked in the supplied file.

The complete equivalence theorem has a written proof. The linked Lean
certificate ends at zero-equation induction; it does not formalize the
entire first-order calculus or the later equality/pairing completion.
