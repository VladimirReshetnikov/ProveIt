#!/usr/bin/env python3
"""Rebuild the paper and schema ledger; optionally replay the Lean kernel.

Requirements: Python 3.10+, pdflatex with the packages used by report.tex.
Lean replay uses Lean 4.19.0 and requires no Mathlib or network downloads.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def run(arguments: list[str], timeout: int = 60) -> subprocess.CompletedProcess:
    return subprocess.run(
        arguments,
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", metavar="EXECUTABLE", help="replay using this Lean executable")
    parser.add_argument("--metrics-only", action="store_true")
    args = parser.parse_args()

    audit = ROOT / "audit"
    audit.mkdir(exist_ok=True)
    metrics = run(
        [
            sys.executable,
            "artifacts/schema_metrics.py",
            "--output",
            "artifacts/schema_metrics.json",
        ]
    )
    if metrics.returncode:
        raise SystemExit(metrics.stdout)
    metric_data = json.loads(metrics.stdout)
    result = {
        "schema_metrics": {
            "exit_code": metrics.returncode,
            "checked_presentation_rows": metric_data["checked_presentation_rows"],
            "sha256": digest(ROOT / "artifacts/schema_metrics.py"),
        }
    }

    if not args.metrics_only:
        binary = shutil.which("pdflatex")
        if not binary:
            raise SystemExit("pdflatex is required to rebuild report.pdf.")
        build = ROOT / "tmp" / "build"
        build.mkdir(parents=True, exist_ok=True)
        command = [
            binary,
            "-interaction=nonstopmode",
            "-halt-on-error",
            "-file-line-error",
            "-output-directory=" + str(build),
            "report.tex",
        ]
        transcripts = []
        for pass_number in (1, 2):
            completed = run(command)
            transcripts.append(completed.stdout)
            if completed.returncode:
                (audit / "latex_replay.log").write_text("\n".join(transcripts), encoding="utf-8")
                raise SystemExit(f"LaTeX pass {pass_number} failed:\n" + completed.stdout[-12000:])
        log = (build / "report.log").read_text(encoding="utf-8", errors="replace")
        if "Rerun to get cross-references right" in log:
            completed = run(command)
            transcripts.append(completed.stdout)
            if completed.returncode:
                raise SystemExit(completed.stdout)
            log = (build / "report.log").read_text(encoding="utf-8", errors="replace")
        shutil.copyfile(build / "report.pdf", ROOT / "report.pdf")
        (audit / "latex_replay.log").write_text("\n".join(transcripts), encoding="utf-8")
        problems = [
            line for line in log.splitlines()
            if "Overfull" in line or "undefined" in line or "Rerun to get" in line
        ]
        result["pdf"] = {
            "exit_code": 0,
            "bytes": (ROOT / "report.pdf").stat().st_size,
            "sha256": digest(ROOT / "report.pdf"),
            "layout_or_reference_warnings": problems,
        }

    if args.lean:
        version = run([args.lean, "--version"])
        if version.returncode:
            raise SystemExit(version.stdout)
        checked = run([args.lean, "formal/RootedInduction.lean"])
        (ROOT / "formal/RootedInduction.replay.log").write_text(
            version.stdout + checked.stdout, encoding="utf-8"
        )
        result["lean_replay"] = {
            "version": version.stdout.strip(),
            "exit_code": checked.returncode,
            "endpoints_without_external_axioms": checked.stdout.count(
                "does not depend on any axioms"
            ),
            "source_sha256": digest(ROOT / "formal/RootedInduction.lean"),
            "scope": (
                "Theorem under the explicit arbitrary-carrier Basis hypotheses; "
                "not a syntactic formalization of the complete bi-interpretation."
            ),
        }
        if checked.returncode:
            raise SystemExit(checked.stdout)
        if result["lean_replay"]["endpoints_without_external_axioms"] != 15:
            raise SystemExit("Unexpected Lean dependency-audit output; inspect the replay log.")

    (audit / "build_results.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
