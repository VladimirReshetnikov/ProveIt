PRA FROM EQUATION INDUCTION AND ONE COVERAGE AXIOM
Research report prepared for Vladimir Reshetnikov
1 November 2026

MAIN RESULT

Over the initialized primitive-recursion equations and 0 != S0, these
three principles are intuitionistically equivalent:

  (1) Full quantifier-free induction.
  (2) Induction on native equations plus the single coverage sentence
          forall x, x=0 OR x=S(p(x)).
  (3) For every finite pair of terms s(n,c), t(n,c), the universal
      parameter closure of
          [forall n, (n=0 OR s(n,c)=t(n,c)) -> s(Sn,c)=t(Sn,c)]
             -> forall n, n=0 OR s(n,c)=t(n,c).

The same nonlogical specification, with (3), gives the classical and
intuitionistic answers in their matching first-order equality logics.
Both are definitionally equivalent, hence bi-interpretable and
equiconsistent, with matching-logic first-order PRA.

The new proof replaces the current drafts' disjunctive comparison
induction by an atomic countdown invariant and establishes the native
equality criterion x=y iff (Sx dotminus y)=1.

CONTENTS

  report.tex / report.pdf
      Complete statement, constructive proofs, interpretation maps,
      both identity round trips, comparison, and limitations.

  formal/RootedInduction.lean
      Checked arbitrary-carrier constructive kernel.
  formal/RootedInduction.log
      Original successful Lean 4.19.0 compiler/dependency audit.
  formal/verification.json, formal/SCOPE.txt, formal/lean-toolchain
      Verification scope, source hash, endpoint list, toolchain pin.

  artifacts/schema_metrics.py / schema_metrics.json
      Independently constructed formula ASTs and matched arity counts.

  audit/source_manifest.json
      Six current ProveIt archives, immutable URLs, and content hashes.
  audit/build_results.json / latex_replay.log / visual_review.json
      Build and document review records.

  build.py
      Rebuild PDF and metrics; optionally replay the Lean kernel.
  SHA256SUMS.txt
      Hashes of the deliverable files.

REPRODUCING

  python3 build.py

Requires Python 3.10+ and pdflatex with the standard packages named in
report.tex. The document has an inline bibliography, so BibTeX is not
needed. No network connection is needed for building.

To recalculate only the partial formula ledger:

  python3 build.py --metrics-only

To additionally recheck the formal kernel using Lean 4.19.0:

  python3 build.py --lean /absolute/path/to/lean

No Mathlib dependency is required. A new replay log is separate from
the original successful log.

VERIFICATION SCOPE

The Lean file checks the rooted-to-equation/coverage reduction,
arithmetic invariant, native equality test, Boolean compiler, and QFI
over an arbitrary carrier with explicit Basis hypotheses and an
admissibility predicate for term-denotations. Fifteen audited endpoints
have no external axiom dependencies. The explicit hypotheses remain
assumptions. The full concrete program syntax, first-order derivation
calculus, interpretation compilers, and complete bi-interpretation
endpoints are established in the paper, not in the Lean file.

COMPARISON SCOPE

Source snapshot:
  9db1e0b1a625767ac54321715f5669d75002360e

The six current drafts were introduced by:
  bd7c1189f8d75f1cf738c156d8c376158de16460

This improves the two-arbitrary-equation schema structurally and in
its fully expanded display count. It does not claim an absolute
shortest theory or a uniform display advantage over every stationary
probe theory. The m and q parameter arities are counted independently.
The stationarity-only candidate's separate bootstrap remains open.

ATTRIBUTION

Initialized recursion, the two-equation baseline, the product
countermodel, and the organization of the Lean Boolean compiler are
credited to the inspected ProveIt drafts. The new rooted interface,
coverage-plus-equation bootstrap, countdown invariant, shifted
subtraction equality test, and their checked integration are the
contribution of this package relative to those drafts. No historical
priority claim is made for equational approaches to PRA.
