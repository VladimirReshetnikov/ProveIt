import Std

/-!
# The constructive kernel for rooted equation induction

This file works over an arbitrary carrier. `adm` denotes unary functions
represented by finite source terms after fixing their parameters. The
induction assumption is restricted to two admitted functions with one
fixed zero disjunct; it is NOT induction over all predicates or all
carrier-valued functions.

The initialized-recursion syntax and its compiler into the conventional
PRA language are treated in the accompanying paper. Here the selected
operations have their defining equations and term-closure properties.
No ambient induction on the carrier is used. The Boolean compiler is
adapted from the prior `TwoEquation.lean`; the rooted schema, countdown
invariant, and equality test are new replacements for its two-equation
induction and comparison argument.
-/

namespace RootedInduction

universe u

structure Basis (N : Type u) where
  zero : N
  succ : N → N
  pred : N → N
  cond : N → N → N → N
  add : N → N → N
  sub : N → N → N
  sep : zero ≠ succ zero
  pred_zero : pred zero = zero
  pred_succ : ∀ x, pred (succ x) = x
  cond_zero : ∀ a b, cond zero a b = a
  cond_succ : ∀ n a b, cond (succ n) a b = b
  add_zero : ∀ x, add x zero = x
  add_succ : ∀ x y, add x (succ y) = succ (add x y)
  sub_zero : ∀ x, sub x zero = x
  sub_succ : ∀ x y, sub x (succ y) = pred (sub x y)
  adm : (N → N) → Prop
  adm_const : ∀ a, adm (fun _ => a)
  adm_var : adm (fun x => x)
  adm_succ : ∀ f, adm f → adm (fun x => succ (f x))
  adm_pred : ∀ f, adm f → adm (fun x => pred (f x))
  adm_cond : ∀ f g h, adm f → adm g → adm h →
    adm (fun x => cond (f x) (g x) (h x))
  adm_add : ∀ f g, adm f → adm g → adm (fun x => add (f x) (g x))
  adm_sub : ∀ f g, adm f → adm g → adm (fun x => sub (f x) (g x))
  ind_rooted : ∀ f g, adm f → adm g →
    (∀ n, (n = zero ∨ f n = g n) → f (succ n) = g (succ n)) →
    ∀ n, n = zero ∨ f n = g n

namespace Basis

variable {N : Type u} (B : Basis N)

def one : N := B.succ B.zero

theorem atomicInd (f g : N → N) (hf : B.adm f) (hg : B.adm g)
    (hb : f B.zero = g B.zero)
    (hs : ∀ n, f n = g n → f (B.succ n) = g (B.succ n)) :
    ∀ n, f n = g n := by
  have h := B.ind_rooted f g hf hg (by
    intro n hn
    apply hs n
    rcases hn with hz | he
    · simpa only [hz] using hb
    · exact he)
  intro n
  rcases h n with hz | he
  · simpa only [hz] using hb
  · exact he

theorem succ_injective {x y : N} (h : B.succ x = B.succ y) : x = y := by
  have hp := congrArg B.pred h
  rw [B.pred_succ, B.pred_succ] at hp
  exact hp

theorem succ_ne_zero (x : N) : B.succ x ≠ B.zero := by
  intro h
  have hx : x = B.zero := by
    have hp := congrArg B.pred h
    rw [B.pred_succ, B.pred_zero] at hp
    exact hp
  rw [hx] at h
  exact B.sep h.symm

theorem cover (x : N) : x = B.zero ∨ x = B.succ (B.pred x) := by
  apply B.ind_rooted (fun n => n) (fun n => B.succ (B.pred n))
    B.adm_var (B.adm_succ _ (B.adm_pred _ B.adm_var)) ?_ x
  intro n _
  change B.succ n = B.succ (B.pred (B.succ n))
  rw [B.pred_succ]

theorem cond_same (z a : N) : B.cond z a a = a := by
  rcases B.cover z with h | h
  · rw [h, B.cond_zero]
  · rw [h, B.cond_succ]

theorem zero_add (x : N) : B.add B.zero x = x := by
  apply B.atomicInd (fun n => B.add B.zero n) (fun n => n)
    (B.adm_add _ _ (B.adm_const B.zero) B.adm_var) B.adm_var
    (B.add_zero B.zero) ?_ x
  intro n ih
  dsimp only at ih ⊢
  rw [B.add_succ, ih]

theorem succ_add (x y : N) : B.add (B.succ x) y = B.succ (B.add x y) := by
  apply B.atomicInd (fun n => B.add (B.succ x) n)
    (fun n => B.succ (B.add x n))
    (B.adm_add _ _ (B.adm_const _) B.adm_var)
    (B.adm_succ _ (B.adm_add _ _ (B.adm_const _) B.adm_var)) ?_ ?_ y
  · dsimp only
    rw [B.add_zero, B.add_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.add_succ, B.add_succ, ih]

theorem add_one (x : N) : B.add x B.one = B.succ x := by
  unfold one
  rw [B.add_succ, B.add_zero]

theorem sub_succ_succ (x y : N) :
    B.sub (B.succ x) (B.succ y) = B.sub x y := by
  apply B.atomicInd (fun n => B.sub (B.succ x) (B.succ n))
    (fun n => B.sub x n)
    (B.adm_sub _ _ (B.adm_const _) (B.adm_succ _ B.adm_var))
    (B.adm_sub _ _ (B.adm_const _) B.adm_var) ?_ ?_ y
  · dsimp only
    rw [B.sub_succ, B.sub_zero, B.pred_succ, B.sub_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.sub_succ (B.succ x) (B.succ n), ih, B.sub_succ x n]

theorem sub_add_cancel (x c : N) : B.sub (B.add x c) x = c := by
  apply B.atomicInd (fun n => B.sub (B.add n c) n) (fun _ => c)
    (B.adm_sub _ _ (B.adm_add _ _ B.adm_var (B.adm_const _)) B.adm_var)
    (B.adm_const _) ?_ ?_ x
  · dsimp only
    rw [B.zero_add, B.sub_zero]
  · intro n ih
    dsimp only at ih ⊢
    rw [B.succ_add, B.sub_succ_succ, ih]

theorem sub_self (x : N) : B.sub x x = B.zero := by
  have h := B.sub_add_cancel x B.zero
  rw [B.add_zero] at h
  exact h

theorem sub_next (x : N) : B.sub (B.succ x) x = B.one := by
  have h := B.sub_add_cancel x B.one
  rw [B.add_one] at h
  exact h

/-! A single-equation invariant replaces the former order comparison. -/

theorem residual (n y : N) :
    B.cond (B.sub y n) y (B.add n (B.sub y n)) = y := by
  apply B.atomicInd
    (fun n => B.cond (B.sub y n) y (B.add n (B.sub y n)))
    (fun _ => y)
    (B.adm_cond _ _ _ (B.adm_sub _ _ (B.adm_const _) B.adm_var)
      (B.adm_const _)
      (B.adm_add _ _ B.adm_var
        (B.adm_sub _ _ (B.adm_const _) B.adm_var)))
    (B.adm_const _) ?_ ?_ n
  · dsimp only
    rw [B.sub_zero, B.zero_add, B.cond_same]
  · intro k ih
    dsimp only at ih ⊢
    rw [B.sub_succ]
    rcases B.cover (B.sub y k) with hz | hp
    · rw [hz, B.pred_zero, B.cond_zero]
    · have hi : B.add k (B.succ (B.pred (B.sub y k))) = y := by
        rw [hp, B.cond_succ] at ih
        exact ih
      have he : B.add (B.succ k) (B.pred (B.sub y k)) = y := by
        calc
          B.add (B.succ k) (B.pred (B.sub y k)) =
              B.succ (B.add k (B.pred (B.sub y k))) := B.succ_add _ _
          _ = B.add k (B.succ (B.pred (B.sub y k))) := (B.add_succ _ _).symm
          _ = y := hi
      rw [he, B.cond_same]

theorem sub_one_reflects {x y : N}
    (h : B.sub (B.succ x) y = B.one) : x = y := by
  have hi := B.residual y (B.succ x)
  rw [h, one, B.cond_succ] at hi
  have he : B.succ y = B.succ x := by
    simpa only [B.add_succ, B.add_zero] using hi
  exact B.succ_injective he.symm

theorem cond_bit_range (z : N) :
    B.cond z B.zero B.one = B.zero ∨ B.cond z B.zero B.one = B.one := by
  rcases B.cover z with h | h
  · exact Or.inl (by rw [h, B.cond_zero])
  · exact Or.inr (by rw [h, B.cond_succ])

theorem cond_bit_zero (z : N) :
    B.cond z B.zero B.one = B.zero ↔ z = B.zero := by
  constructor
  · intro h
    rcases B.cover z with hz | hp
    · exact hz
    · rw [hp, B.cond_succ] at h
      exact False.elim (B.sep h.symm)
  · intro h
    rw [h, B.cond_zero]

def unitBit (r : N) : N :=
  B.cond r B.one (B.cond (B.pred r) B.zero B.one)

theorem unitBit_range (r : N) :
    B.unitBit r = B.zero ∨ B.unitBit r = B.one := by
  unfold unitBit
  rcases B.cover r with hz | hp
  · exact Or.inr (by rw [hz, B.cond_zero])
  · rw [hp, B.cond_succ, B.pred_succ]
    exact B.cond_bit_range (B.pred r)

theorem unitBit_zero (r : N) : B.unitBit r = B.zero ↔ r = B.one := by
  constructor
  · intro h
    unfold unitBit at h
    rcases B.cover r with hz | hp
    · rw [hz, B.cond_zero] at h
      exact False.elim (B.sep h.symm)
    · rw [hp, B.cond_succ, B.pred_succ] at h
      have hz := (B.cond_bit_zero (B.pred r)).1 h
      exact hp.trans (congrArg B.succ hz)
  · intro h
    unfold unitBit
    rw [h, one, B.cond_succ, B.pred_succ, B.cond_zero]

def eqBit (x y : N) : N := B.unitBit (B.sub (B.succ x) y)

theorem eqBit_adm (f g : N → N) (hf : B.adm f) (hg : B.adm g) :
    B.adm (fun n => B.eqBit (f n) (g n)) := by
  have hr := B.adm_sub _ _ (B.adm_succ _ hf) hg
  exact B.adm_cond _ _ _ hr (B.adm_const _)
    (B.adm_cond _ _ _ (B.adm_pred _ hr) (B.adm_const _) (B.adm_const _))

theorem eqBit_range (x y : N) :
    B.eqBit x y = B.zero ∨ B.eqBit x y = B.one :=
  B.unitBit_range (B.sub (B.succ x) y)

theorem eqBit_zero (x y : N) : B.eqBit x y = B.zero ↔ x = y := by
  constructor
  · intro h
    exact B.sub_one_reflects ((B.unitBit_zero _).1 h)
  · intro h
    subst y
    exact (B.unitBit_zero _).2 (B.sub_next x)

theorem eqBit_one (x y : N) : B.eqBit x y = B.one ↔ x ≠ y := by
  constructor
  · intro h hxy
    have hz := (B.eqBit_zero x y).2 hxy
    exact B.sep (hz.symm.trans h)
  · intro h
    rcases B.eqBit_range x y with hz | ho
    · exact False.elim (h ((B.eqBit_zero x y).1 hz))
    · exact ho

include B in
theorem equality_decidable (x y : N) : x = y ∨ x ≠ y := by
  rcases B.eqBit_range x y with hz | ho
  · exact Or.inl ((B.eqBit_zero x y).1 hz)
  · exact Or.inr ((B.eqBit_one x y).1 ho)

/-! The endpoint applies to every formula with an admitted error bit. -/

structure Encoded (A : N → Prop) where
  bit : N → N
  admitted : B.adm bit
  range : ∀ n, bit n = B.zero ∨ bit n = B.one
  truth : ∀ n, bit n = B.zero ↔ A n

namespace Encoded

variable {B} {A D : N → Prop}

theorem false_of_one (a : B.Encoded A) {n : N} (h : a.bit n = B.one) :
    ¬ A n := by
  intro ha
  have hz := (a.truth n).2 ha
  exact B.sep (hz.symm.trans h)

theorem induction (a : B.Encoded A) (hb : A B.zero)
    (hs : ∀ n, A n → A (B.succ n)) : ∀ n, A n := by
  have hi := B.atomicInd a.bit (fun _ => B.zero) a.admitted
    (B.adm_const _) ((a.truth B.zero).2 hb)
    (fun n hn => (a.truth (B.succ n)).2 (hs n ((a.truth n).1 hn)))
  intro n
  exact (a.truth n).1 (hi n)

end Encoded

def encodedEq (f g : N → N) (hf : B.adm f) (hg : B.adm g) :
    B.Encoded (fun n => f n = g n) where
  bit := fun n => B.eqBit (f n) (g n)
  admitted := B.eqBit_adm f g hf hg
  range := fun n => B.eqBit_range (f n) (g n)
  truth := fun n => B.eqBit_zero (f n) (g n)

def encodedTrue : B.Encoded (fun _ => True) where
  bit := fun _ => B.zero
  admitted := B.adm_const _
  range := fun _ => Or.inl rfl
  truth := fun _ => ⟨fun _ => True.intro, fun _ => rfl⟩

def encodedFalse : B.Encoded (fun _ => False) where
  bit := fun _ => B.one
  admitted := B.adm_const _
  range := fun _ => Or.inr rfl
  truth := fun _ => ⟨fun h => B.sep h.symm, fun h => False.elim h⟩

def encodedAnd {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n ∧ D n) where
  bit := fun n => B.cond (a.bit n) (d.bit n) B.one
  admitted := B.adm_cond _ _ _ a.admitted d.admitted (B.adm_const _)
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact d.range n
    · rw [ha, one, B.cond_succ]
      exact Or.inr rfl
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      constructor
      · intro h
        exact ⟨(a.truth n).1 ha, (d.truth n).1 h⟩
      · intro h
        exact (d.truth n).2 h.2
    · rw [ha, one, B.cond_succ]
      constructor
      · intro h
        exact False.elim (B.sep h.symm)
      · intro h
        exact False.elim (a.false_of_one ha h.1)

def encodedOr {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n ∨ D n) where
  bit := fun n => B.cond (a.bit n) B.zero (d.bit n)
  admitted := B.adm_cond _ _ _ a.admitted (B.adm_const _) d.admitted
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact Or.inl rfl
    · rw [ha, one, B.cond_succ]
      exact d.range n
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact ⟨fun _ => Or.inl ((a.truth n).1 ha), fun _ => rfl⟩
    · rw [ha, one, B.cond_succ]
      constructor
      · intro h
        exact Or.inr ((d.truth n).1 h)
      · intro h
        rcases h with h | h
        · exact False.elim (a.false_of_one ha h)
        · exact (d.truth n).2 h

def encodedImp {A D : N → Prop} (a : B.Encoded A) (d : B.Encoded D) :
    B.Encoded (fun n => A n → D n) where
  bit := fun n => B.cond (a.bit n) (d.bit n) B.zero
  admitted := B.adm_cond _ _ _ a.admitted d.admitted (B.adm_const _)
  range := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      exact d.range n
    · rw [ha, one, B.cond_succ]
      exact Or.inl rfl
  truth := by
    intro n
    rcases a.range n with ha | ha
    · rw [ha, B.cond_zero]
      constructor
      · intro h _
        exact (d.truth n).1 h
      · intro h
        exact (d.truth n).2 (h ((a.truth n).1 ha))
    · rw [ha, one, B.cond_succ]
      constructor
      · intro _ h
        exact False.elim (a.false_of_one ha h)
      · intro _
        rfl

/-!
This syntax is parameterized by admitted unary terms. It formalizes the
logical part of the QF compiler; parsing and interpreting the concrete
finite recursion descriptions are outside this file's scope.
-/

inductive QF (B : Basis N) : Type u where
  | atom (f g : N → N) (hf : B.adm f) (hg : B.adm g) : QF B
  | bot : QF B
  | top : QF B
  | conj : QF B → QF B → QF B
  | disj : QF B → QF B → QF B
  | impl : QF B → QF B → QF B

namespace QF

variable {B}

def denote : QF B → N → Prop
  | atom f g _ _ => fun n => f n = g n
  | bot => fun _ => False
  | top => fun _ => True
  | conj a d => fun n => a.denote n ∧ d.denote n
  | disj a d => fun n => a.denote n ∨ d.denote n
  | impl a d => fun n => a.denote n → d.denote n

def encode : (a : QF B) → B.Encoded a.denote
  | atom f g hf hg => B.encodedEq f g hf hg
  | bot => B.encodedFalse
  | top => B.encodedTrue
  | conj a d => B.encodedAnd a.encode d.encode
  | disj a d => B.encodedOr a.encode d.encode
  | impl a d => B.encodedImp a.encode d.encode

theorem induction (a : QF B) (hb : a.denote B.zero)
    (hs : ∀ n, a.denote n → a.denote (B.succ n)) : ∀ n, a.denote n := by
  exact a.encode.induction hb hs

end QF

end Basis

end RootedInduction

#print axioms RootedInduction.Basis.cover
#print axioms RootedInduction.Basis.atomicInd
#print axioms RootedInduction.Basis.residual
#print axioms RootedInduction.Basis.sub_one_reflects
#print axioms RootedInduction.Basis.eqBit_zero
#print axioms RootedInduction.Basis.equality_decidable
#print axioms RootedInduction.Basis.Encoded.induction
#print axioms RootedInduction.Basis.encodedEq
#print axioms RootedInduction.Basis.encodedTrue
#print axioms RootedInduction.Basis.encodedFalse
#print axioms RootedInduction.Basis.encodedAnd
#print axioms RootedInduction.Basis.encodedOr
#print axioms RootedInduction.Basis.encodedImp
#print axioms RootedInduction.Basis.QF.encode
#print axioms RootedInduction.Basis.QF.induction
