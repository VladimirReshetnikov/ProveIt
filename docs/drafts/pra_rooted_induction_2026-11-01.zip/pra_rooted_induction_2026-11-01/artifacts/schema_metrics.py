#!/usr/bin/env python3
"""Compare PRA schema displays with independent recursion/induction arities.

This is a partial formula-tree ledger, not a complete encoded theory length.
Every variable occurrence, constant, application, equality, binary connective,
falsity, and individual quantifier contributes one node. Binder names are
metadata. Negation expands as implication to falsity; 1 expands as S(0).

m >= 1 counts the seed plus frozen parameters of a recursion description.
q >= 0 counts the frozen parameters of an induction/stationarity term.
The fresh comparison probe is separately quantified and is NOT one of q.

Arbitrary substituted terms/updates are represented by their displayed
applications. Selected finite helper bodies are counted independently. QFI
uses a formula placeholder; the other induction matrices are fully expanded
in term placeholders. Those are different specification classes.

Comparison sources: ProveIt docs/drafts at commit
9db1e0b1a625767ac54321715f5669d75002360e, especially the initialized-induction,
fresh-probe, and compact-bases archives dated 2026-11-01. This implementation
was independently written; no programs supplied in the archives are executed.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class Node:
    label: str
    children: tuple["Node", ...] = ()

    def size(self) -> int:
        return 1 + sum(child.size() for child in self.children)


def atom(name: str) -> Node:
    return Node(name)


def app(name: str, *arguments: Node) -> Node:
    return Node(name, arguments)


def eq(left: Node, right: Node) -> Node:
    return app("=", left, right)


def imp(left: Node, right: Node) -> Node:
    return app("implies", left, right)


def conj(left: Node, right: Node) -> Node:
    return app("and", left, right)


def disj(left: Node, right: Node) -> Node:
    return app("or", left, right)


def forall(names: list[str], body: Node) -> Node:
    for name in reversed(names):
        body = Node("forall " + name, (body,))
    return body


ZERO, N, SEED = atom("0"), atom("n"), atom("a")
ONE = app("S", ZERO)
SEP = imp(eq(ZERO, ONE), atom("false"))


def recurrence(m: int, kind: str) -> tuple[Node, Node]:
    """Universally closed ordinary/full-swap/counter-free computation laws."""
    frozen_names = ["b" + str(i) for i in range(m - 1)]
    frozen = [atom(name) for name in frozen_names]
    base = forall(
        ["a", *frozen_names], eq(app("R", ZERO, SEED, *frozen), SEED)
    )
    if kind == "ordinary":
        call = app("R", N, SEED, *frozen)
        update = app("h", N, *frozen, call)
    elif kind == "full_swap":
        call = app("R", SEED, N, *frozen)
        update = app("h", N, SEED, *frozen, call)
    elif kind == "counterfree_swap":
        call = app("R", SEED, N, *frozen)
        update = app("h", SEED, *frozen, call)
    else:
        raise ValueError("unknown recurrence kind: " + kind)
    step = forall(
        ["n", "a", *frozen_names],
        eq(app("R", app("S", N), SEED, *frozen), update),
    )
    return base, step


def ordinary_induction(matrix: Callable[[Node], Node]) -> Node:
    return imp(
        conj(
            matrix(ZERO),
            forall(["n"], imp(matrix(N), matrix(app("S", N)))),
        ),
        forall(["n"], matrix(N)),
    )


def arithmetic_schema(q: int, kind: str) -> Node:
    frozen_names = ["c" + str(i) for i in range(q)]
    frozen = [atom(name) for name in frozen_names]

    def term(name: str, argument: Node) -> Node:
        return app(name, argument, *frozen)

    def equation(argument: Node) -> Node:
        return eq(term("s", argument), term("t", argument))

    if kind == "qfi":
        body = ordinary_induction(lambda n: term("formula A", n))
    elif kind == "two_equations":
        body = ordinary_induction(
            lambda n: disj(equation(n), eq(term("u", n), term("v", n)))
        )
    elif kind == "rooted":
        root = lambda n: disj(eq(n, ZERO), equation(n))
        body = imp(
            forall(["n"], imp(root(N), equation(app("S", N)))),
            forall(["n"], root(N)),
        )
    elif kind == "fresh_probe":
        body = imp(
            forall(["n"], eq(term("f", app("S", N)), term("f", N))),
            forall(
                ["a", "n"],
                disj(
                    eq(app("T", term("f", ZERO), SEED), SEED),
                    eq(term("f", N), SEED),
                ),
            ),
        )
    else:
        raise ValueError("unknown arithmetic schema kind: " + kind)
    return forall(frozen_names, body)


B, V = atom("b"), atom("v")
FULL_HELPERS = [B, V, app("C", app("D", SEED, N), N, SEED)]
CF_HELPERS = [
    B,
    V,
    app("C", app("D", SEED, app("S", V)), app("S", app("S", V)), SEED),
]

# Names, recurrence kind, arithmetic schema, finite bodies, symbolic ledger.
PRESENTATIONS = [
    ("rooted", "ordinary", "rooted", [], (6, 7, 47)),
    ("two_equations", "ordinary", "two_equations", [], (6, 17, 71)),
    ("qfi_formula_placeholder", "ordinary", "qfi", [], (6, 5, 32)),
    ("fresh_probe", "full_swap", "fresh_probe", FULL_HELPERS, (6, 5, 48)),
    (
        "counterfree_fresh_probe",
        "counterfree_swap",
        "fresh_probe",
        CF_HELPERS,
        (6, 5, 50),
    ),
]


def measure(m: int, q: int, presentation: tuple) -> dict:
    if m < 1 or q < 0:
        raise ValueError("require m >= 1 and q >= 0")
    name, recursion_kind, schema_kind, helpers, polynomial = presentation
    base, step = recurrence(m, recursion_kind)
    helper_nodes = sum(body.size() for body in helpers)
    pieces = {
        "recursion_base": base.size(),
        "recursion_step": step.size(),
        "separation": SEP.size(),
        "arithmetic_schema": arithmetic_schema(q, schema_kind).size(),
    }
    display = sum(pieces.values())
    total = display + helper_nodes
    cm, cq, constant = polynomial
    assert total == cm * m + cq * q + constant, (name, m, q, total)
    return {
        "presentation": name,
        "m": m,
        "q": q,
        "parts": pieces,
        "display_nodes": display,
        "selected_helper_body_nodes": helper_nodes,
        "partial_subtotal": total,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="also write the JSON result")
    args = parser.parse_args()
    rows = [
        measure(m, q, presentation)
        for m in range(1, 6)
        for q in range(5)
        for presentation in PRESENTATIONS
    ]
    result = {
        "scope": "formula display plus selected bodies, not full theory encoding",
        "m": "seed plus frozen recursion arguments, m >= 1",
        "q": "frozen induction/stationarity arguments, q >= 0; excludes fresh probe",
        "polynomials": {
            name: {"m": poly[0], "q": poly[1], "constant": poly[2]}
            for name, _, _, _, poly in PRESENTATIONS
        },
        "rooted_minus_fresh_probe": "2*q - 1",
        "rooted_minus_counterfree_fresh_probe": "2*q - 3",
        "two_equations_minus_rooted": "10*q + 24",
        "representative_rows": [row for row in rows if row["m"] == 1 and row["q"] < 2],
        "checked_arity_pairs": 25,
        "checked_presentation_rows": len(rows),
        "arity_range": {"m": [1, 5], "q": [0, 4]},
        "qualification": (
            "QFI's formula placeholder is not an expanded term-only matrix. "
            "All parameter arities remain admitted in every theory. The rooted "
            "scheme wins one node over fresh-probe at q=0 but is larger at q>=1. "
            "No claim is made about axiom-enumerator bit length or global optimality."
        ),
    }
    output = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(output, encoding="utf-8")
    print(output, end="")


if __name__ == "__main__":
    main()
