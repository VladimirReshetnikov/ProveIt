"""Verify the delivered manifest, or refresh it and build one portable ZIP."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "SHA256SUMS.txt"
TEMP_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".fmt", ".fls", ".fdb_latexmk"}


def included(path):
    relative = path.relative_to(ROOT)
    return (path.is_file() and path != MANIFEST
            and "__pycache__" not in relative.parts
            and path.suffix not in TEMP_SUFFIXES)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    paths = sorted(path for path in ROOT.rglob("*") if included(path))
    if args.verify:
        expected = {}
        for line in MANIFEST.read_text().splitlines():
            checksum, name = line.split("  ", 1)
            expected[name] = checksum
        actual = {path.relative_to(ROOT).as_posix(): digest(path) for path in paths}
        if expected != actual:
            changed = sorted(name for name in expected.keys() | actual.keys()
                             if expected.get(name) != actual.get(name))
            raise SystemExit("Manifest mismatch: " + ", ".join(changed))
        print(json.dumps({"status": "PASS", "payload_files": len(paths)}, indent=2))
        return
    MANIFEST.write_text("".join(
        f"{digest(path)}  {path.relative_to(ROOT).as_posix()}\n" for path in paths))
    archive = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as output:
        for path in [*paths, MANIFEST]:
            output.write(path, (Path(ROOT.name) / path.relative_to(ROOT)).as_posix())
    with zipfile.ZipFile(archive) as source:
        failure = source.testzip()
        if failure:
            raise SystemExit("ZIP CRC error: " + failure)
    print(json.dumps({"archive": str(archive), "payload_files": len(paths),
                      "bytes": archive.stat().st_size,
                      "sha256": digest(archive)}, indent=2))


if __name__ == "__main__":
    main()
