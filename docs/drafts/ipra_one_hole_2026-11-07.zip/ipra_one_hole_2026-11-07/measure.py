"""Recompute complete-source and core metrics with the frozen upstream metric."""
from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import platform

ROOT = Path(__file__).resolve().parent
FIELDS = ("normalized_tokens", "ast_nodes", "normalized_bytes")


def main():
    metric_path = ROOT / "comparison/source_measure.py"
    spec = importlib.util.spec_from_file_location("frozen_source_metric", metric_path)
    metric = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(metric)
    manifest = json.loads((ROOT / "comparison/manifest.json").read_text())
    rows = []
    for entry in manifest["programs"]:
        source = ROOT / "comparison" / entry["local_file"]
        result = metric.metrics(source)
        if result["sha256"] != entry["sha256"]:
            raise ValueError("Comparator changed: " + entry["local_file"])
        rows.append({**entry, **result})
    by_hash = {row["sha256"]: row for row in rows}
    current = [
        {**by_hash[entry["sha256"]], "archive_path": entry["path"]}
        for entry in manifest["root_programs"]
    ]
    envelope = {field: min(row[field] for row in current) for field in FIELDS}
    expanded = {field: min(row[field] for row in rows) for field in FIELDS}
    core = {field: min(row["core"][field] for row in current) for field in FIELDS}
    candidates = {
        name: metric.metrics(ROOT / name)
        for name in ("checker.py", "checker_five_rules.py")
    }
    for name, result in candidates.items():
        if not all(result[field] < envelope[field] for field in FIELDS):
            raise ValueError("Candidate fails strict complete envelope: " + name)
    if not all(candidates["checker.py"]["core"][field] < core[field] for field in FIELDS):
        raise ValueError("Primary fails strict core envelope")
    ablations = {}
    for path in sorted((ROOT / "comparison/ablations").glob("*.py")):
        ablations[path.name] = metric.metrics(path)
    result = {
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "commit": manifest["commit"],
        "archives": len(manifest["archives"]),
        "root_programs": len(current),
        "distinct_complete_sources": len(rows),
        "complete_envelope": envelope,
        "expanded_complete_envelope": expanded,
        "core_envelope": core,
        "candidates": candidates,
        "ablations": ablations,
        "current_programs": current,
        "all_programs": rows,
        "metric_sha256": hashlib.sha256(metric_path.read_bytes()).hexdigest(),
    }
    (ROOT / "results").mkdir(exist_ok=True)
    (ROOT / "results/metrics.json").write_text(json.dumps(result, indent=2) + "\n")
    with (ROOT / "results/comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["archive_path", *FIELDS, "sha256"])
        writer.writeheader()
        for row in current:
            writer.writerow({key: row[key] for key in writer.fieldnames})
    print(json.dumps({
        key: value for key, value in result.items()
        if key not in ("current_programs", "all_programs", "ablations")
    }, indent=2))
    return result


if __name__ == "__main__":
    main()
