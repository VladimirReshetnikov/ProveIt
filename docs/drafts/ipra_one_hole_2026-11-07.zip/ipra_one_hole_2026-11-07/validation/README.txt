ONE-HOLE SCALAR CHECKER: PORTABLE VALIDATION
7 November 2026
===========================================

Run from the delivered archive root:

    python3 -B validation/verify.py
    python3 -B validation/verify_translation.py

Both scripts are independent of the working research directory and network.
Only Python 3.10+ and its standard library are required. To validate relocated
checker copies, pass --main PATH --five PATH. The optional --output DIRECTORY
selects the result directory. The default is validation/results/.

The main checker permits direct Q introduction. Its five-rule companion
requires the same admissible inference to be expanded using D introduction
and D elimination. The two intentionally different certificate formats prove
the same mathematical theorem relation.

VERIFY.PY

For EACH checker, the executed suite records:

  * 6,776 opening cases against a separately written named-binder parser:
    3,522 valid openings and 3,254 rejected openings. These cover term/formula
    sort, protected binder depths 0 through 3, coordinate aliasing, declared
    and future rigid names, used and unused images, image capture, and JSON
    type boundaries.
  * 207 named fixed cases representing 154 distinct serialized packets:
    62 original scalar fixtures, 98 second-version scalar fixtures, and 47
    new one-hole and arithmetic cases. These cohorts overlap in packet bytes;
    the named count is not a count of independent mathematical theorems.
  * Main checker: 120 accepting and 87 rejecting fixed entries.
    Five-rule companion: 118 accepting and 89 rejecting entries.
    The two differences are explicitly labeled direct-Q certificates.
  * 1,600 deterministic packet mutations, 1,447 distinct. The first 1,200
    reproduce the original scalar draft's ordered regression cohort; the
    remaining 400 mutate the new one-hole fixtures. Candidate verdicts are
    compared with the named oracle configured for the appropriate rule set.
  * 224 actual command-line calls: every original and every new fixture under
    normal Python and Python -O, plus three malformed-JSON files in both modes.
    Both checkers together account for 448 public CLI calls.
  * 14 accepted arithmetic certificates also checked by a separate literal
    scalar-iterator evaluator. Six new certificates include addition,
    multiplication, exponentiation, parity, nested state references, and an
    evaluated recursion counter. The largest new certificate has 175 cells.
  * Eight deliberately defective variants detected: insertion-depth capture,
    restoring a nonexistent second iterator binder, removing root validation,
    treating booleans as integers, admitting compound induction hypotheses,
    removing the atomic retained base, permitting undeclared negative names,
    and replacing a missing image by an implicit zero image.

The global input sentence, every checked major premise, and every used image
remain closed relative to previously declared rigid parameters. Unbounded
positive-coordinate aliasing is allowed only when a one-hole template is
actually opened with an image. In particular, a closed update cannot smuggle
the removed recursion counter through the new convention.

FINITE TRANSLATION TO THE UNCHANGED ORIGINAL CHECKER

verify_translation.py independently compiles every oracle-accepted fixed and
mutated certificate from these same cohorts to baseline_scalar.py, the frozen
original scalar checker. It normalizes all external template coordinates to
the ordinary first-hole coordinate. For the main checker it also expands
direct Q introduction via D. Eigenparameter names are reassigned in target
allocation order, including the additional D-elimination name. The generated
root sentence must be identical to the source as a raw JSON tree (and
therefore under any fixed JSON serialization).

Every compiled certificate is then checked by the frozen baseline. This makes
the accepted differences concrete: they are different encodings of existing
derivations. In the original 1,200-mutation cohort, exactly three packets
change from rejection to acceptance for each new checker. Their excessive
positive motive coordinates are now legal one-hole aliases. Detailed source
and target hashes and the successful baseline checks are recorded in results/.

The main-checker translation audit compiles 173 accepted source certificates
(120 fixed and 53 mutations), representing 116 distinct source packets. It
expands five direct Q introductions across this cohort. The five-rule audit
compiles 168 certificates (118 fixed and 50 mutations), representing 112
distinct source packets. All target certificates accept in the unchanged
original checker, with exactly the original root sentence.

CONCRETE EXAMPLES

    python3 checker.py validation/examples/motive_alias_65535.json
    python3 checker.py validation/examples/nested_motive_aliases.json
    python3 checker.py validation/examples/arithmetic/power_two_three.json

These accept. The first uses coordinate 65535 for its only template hole.
The second opens that hole beneath both logical and iterator binders.
The last proves a scalar-iterator term equals the numeral 8.

    python3 checker.py validation/examples/true_capture_attack.json
    python3 checker.py validation/examples/global_initializer_hole.json
    python3 checker.py validation/examples/old_counter_is_not_a_hole_3.json

These reject. Rejection of a certificate is not a proof that its sentence is
false. The true-capture control specifically targets a false sentence, while
some other controls are purely syntax or proof-format failures.

FILES AND ATTRIBUTION

  named_oracle.py             Explicit named syntax and rule interpreter.
  compile_to_baseline.py      Untrusted source-to-baseline proof producer.
  baseline_scalar.py         Unmodified original scalar acceptance program.
  inherited_fixtures.json    Original and second-version source fixtures.
  new_cases.py               New fixture and arithmetic proof generator.
  new_fixtures.json          Materialized new fixtures.
  generate_scalar_cases.py   Inherited untrusted finite evaluation producer.
  mutation_support.py        Inherited generic JSON-tree mutation function.
  examples/                 New accepting and rejecting certificates.
  compiled_examples/        Baseline-compatible versions of new accepting ones.
  results/                  Executed validation and translation evidence.
  provenance.json           Pinned source archive and frozen support hashes.
  ATTRIBUTION.txt            Detailed source relationship.
  LICENSE_SOURCE.txt         Retained source license.

None of these support files is imported by either measured acceptance program.
The tests provide finite implementation evidence. They are not a Lean/Rocq
formalization, a proof of consistency, or a universal correctness theorem for
Python. The mathematical metatheorems and their scope are stated in the paper.
