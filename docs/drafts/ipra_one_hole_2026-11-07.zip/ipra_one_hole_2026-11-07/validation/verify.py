"""Reproduce finite arithmetic, substitution, oracle, and CLI validation.

Everything in this directory is untrusted test support.  Neither checker
imports it.  Successful finite tests do not prove universal soundness,
completeness, consistency, or the mathematical bi-interpretation theorem.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import argparse
import importlib.util
import json
import platform
import random
import subprocess
import sys
import tempfile
import types

from named_oracle import Oracle, opening
from mutation_support import mutate
from new_cases import cases as new_cases

HERE = Path(__file__).resolve().parent


def require(condition, detail):
    if not condition:
        raise AssertionError(detail)


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def file_hash(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path, label):
    spec = importlib.util.spec_from_file_location(label, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run(module, proof_packet):
    module.k = 0
    stack = deepcopy(proof_packet)
    try:
        module.take = stack.pop
        accepted = bool(module.check(stack.pop(), []))
        error = None
    except Exception as exception:
        accepted, error = False, type(exception).__name__
    return {'accepted': accepted, 'final_k': module.k,
            'remaining': len(stack) if type(stack) is list else None, 'error': error}


def agreement(module, proof_packet, direct, label):
    actual = run(module, proof_packet)
    expected = Oracle(direct_closure=direct).run(proof_packet)
    require(actual['accepted'] == expected['accepted'],
            ('oracle verdict', label, actual, expected))
    if actual['accepted']:
        for field in ('final_k', 'remaining'):
            require(actual[field] == expected[field],
                    ('successful execution state', label, field, actual, expected))
    return actual, expected


def opening_audit(module):
    """Explicit local-binder and global-image boundaries for one template hole."""
    atoms = [-3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 999, True, False, 0.0, None, {}]
    terms = [*atoms, [], [0], [1], [999], [0, 0], [0, 0, 1],
             [0, 0, 3], [0, 0, 999], [1, 0, [0, 3, 5]],
             [0, 0, [0, 1, 5]], [0, 0, [0, 1, 999]]]
    formulas = [[t, 0] for t in terms]
    formulas += [[[t, 0]] for t in (-2, 0, 1, 2, 3, 4, 5, 999)]
    formulas += [[[t, 0], [1, 2], [3, 4]] for t in (-2, 0, 1, 2, 3, 4, 5, 999)]
    formulas += [[], None, {}, [True], [[0, 0], [5, 5], [0, 0]],
                 [[[5, 1]], [[3, 4]], [[1, 2]]],
                 [[[[0, 0, 999], 5]], [0, 0], [0, 0]]]
    images = [None, 0, -1, -3, 1, 2, [0], [0, 0, 1], [0, 0, 3], True, {}]
    counts = Counter()
    for formula, values in ((True, formulas), (False, terms)):
        for value in values:
            for depth in (0, 1, 2, 3):
                for lower in (0, -2):
                    for image in images:
                        module.k = lower
                        try:
                            actual = module.inst(deepcopy(value), deepcopy(image),
                                                 d=2 * depth + (not formula))
                            valid = True
                        except Exception:
                            actual, valid = None, False
                        try:
                            expected = opening(deepcopy(value), deepcopy(image),
                                               formula=formula, depth=depth, lower=lower)
                            valid_expected = True
                        except Exception:
                            expected, valid_expected = None, False
                        require(valid == valid_expected and (not valid or actual == expected),
                                ('opening', value, image, formula, depth, lower, actual, expected))
                        counts['valid' if valid else 'invalid'] += 1
    return dict(counts)


def number(term, environment=()):
    """Literal standard-number evaluation, independent of proof validation."""
    if type(term) is int:
        if term == 0:
            return 0
        require(term > 0, ('free rigid parameter in numerical test', term))
        return environment[(term - 1) // 2]
    if len(term) == 1:
        return number(term[0], environment) + 1
    count, initial, update = term
    value = number(initial, environment)
    for _ in range(number(count, environment)):
        value = number(update, (value, *environment))
    return value


def cli(path, proof_file, expected, optimized=False):
    command = [sys.executable, *(['-O'] if optimized else []), str(path), str(proof_file)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=20)
    wanted = (0, 'ACCEPT', '') if expected else (1, 'REJECT', '')
    actual = (result.returncode, result.stdout.strip(), result.stderr)
    require(actual == wanted, ('public CLI', path.name, proof_file.name, optimized, actual))
    return {'optimized': optimized, 'exit_code': result.returncode,
            'stdout': result.stdout.strip()}


def altered(source, old, new, label):
    require(source.count(old) == 1, ('mutation source anchor', label))
    module = types.ModuleType('deliberate_' + label)
    exec(compile(source.replace(old, new), label, 'exec'), module.__dict__)
    return module


def controls(path, rows, direct):
    source = path.read_text()
    variable = 'a' if direct else 'b'
    hypothesis = f'h = [{variable}, inst({variable}, 0)][len({variable}) % 2:]'
    modifications = [
        ('image_capture', 'inst(t, d=1)', 'inst(t, d=d)',
         'new/true_capture_attack', True,
         'Using the insertion depth for images permits a false capture certificate.'),
        ('old_second_binder', "b'\\0\\0\\2'", "b'\\0\\0\\4'",
         'new/old_counter_is_not_a_hole_3', True,
         'A nonexistent scalar counter binder becomes incorrectly well formed.'),
        ('goal_validation_removed', 'if inst(a) in g:', 'if a in g:',
         'new/future_eigenparameter_escape', True,
         'An eigenparameter escapes when the root goal is not checked before allocation.'),
        ('boolean_as_integer', 'type(a) is int', 'isinstance(a, int)',
         'new/invalid_unused_update_True', True,
         'A JSON boolean incorrectly passes as a bound numerical coordinate.'),
        ('compound_induction', hypothesis,
         f'h = [{variable}, inst({variable}, 0)]',
         'original/compound_induction_hypothesis', True,
         'The mutant admits an invalid compound-induction certificate; the sentence has another proof.'),
        ('atomic_base_removed', hypothesis,
         f'h = [{variable}] if len({variable}) == 2 else [inst({variable}, 0)]',
         'original/retained_base_separation', False,
         'A valid certificate fails after the atomic retained base is deleted; this is incompleteness.'),
        ('future_names_allowed', ' and a >= k', '',
         'new/invalid_unused_update_-999', True,
         'The declared-before-use syntax contract fails even in an otherwise unused update.'),
        ('implicit_zero_image', 'def inst(a, t=None, d=0):', 'def inst(a, t=0, d=0):',
         'new/global_initializer_hole', True,
         'A global dangling coordinate is incorrectly given a default substitution image.'),
    ]
    by_name = {row['name']: row for row in rows}
    results = []
    for label, old, new, name, mutant_expected, explanation in modifications:
        module = altered(source, old, new, label)
        row = by_name[name]
        actual = run(module, row['packet'])
        require(actual['accepted'] == mutant_expected,
                ('defective control did not fire', path.name, label, actual))
        original_expected = row.get('five_expected', row['expected']) if not direct else row['expected']
        require(mutant_expected != original_expected, ('control fails to discriminate', label))
        results.append({'name': label, 'fixture': name, 'mutant_accepted': actual['accepted'],
                        'correct_accepted': original_expected, 'explanation': explanation})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--main', type=Path, default=HERE.parent/'checker.py')
    parser.add_argument('--five', type=Path, default=HERE.parent/'checker_five_rules.py')
    parser.add_argument('--output', type=Path, default=HERE/'results')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    provenance = json.loads((HERE/'provenance.json').read_text())
    for filename, expected_hash in provenance['frozen_support_sha256'].items():
        require(file_hash(HERE/filename) == expected_hash, ('changed frozen support', filename))
    inherited = json.loads((HERE/'inherited_fixtures.json').read_text())
    generated = new_cases(inherited)
    (HERE/'new_fixtures.json').write_text(json.dumps(generated, indent=2) + '\n')
    for row in generated:
        example = HERE/'examples'/(row['name'].removeprefix('new/') + '.json')
        example.parent.mkdir(parents=True, exist_ok=True)
        example.write_text(json.dumps(row['packet'], indent=2) + '\n')
    rows = inherited + generated
    require(len(inherited) == 160 and len(generated) == 47, 'fixed cohort changed')
    original = [row for row in inherited if row['cohort'] == 'original_scalar']
    require(len(original) == 62, 'original scalar cohort changed')
    frozen = load(HERE/'baseline_scalar.py', 'frozen_original_scalar')
    for row in inherited:
        require(run(frozen, row['packet'])['accepted'] == row['expected'],
                ('frozen baseline fixture', row['name']))

    numerical = []
    for row in rows:
        value = row.get('standard_value')
        if value is None and row['name'].startswith('original/scalar_evaluation_') and row['expected']:
            value = row['explanation']['standard_value']
        if value is not None:
            goal = row['packet'][-1]
            require(number(goal[0]) == number(goal[1]) == value,
                    ('literal numerical evaluation', row['name'], value))
            numerical.append({'name': row['name'], 'value': value,
                              'instruction_cells': len(row['packet']) - 1})

    rng = random.Random(20261107)
    mutations = []
    for index in range(1200):
        parent = original[index % len(original)]
        proof_packet = mutate(parent['packet'], rng)
        mutations.append({'index': index, 'parent': parent['name'],
                          'cohort': 'original_regression', 'packet': proof_packet,
                          'sha256': digest(proof_packet)})
    rng = random.Random(20261108)
    for index in range(400):
        parent = generated[index % len(generated)]
        proof_packet = mutate(parent['packet'], rng)
        mutations.append({'index': index, 'parent': parent['name'],
                          'cohort': 'new_format', 'packet': proof_packet,
                          'sha256': digest(proof_packet)})

    summaries = []
    for path, direct in ((args.main.resolve(), True), (args.five.resolve(), False)):
        module = load(path, 'candidate_' + path.stem)
        openings = opening_audit(module)
        fixed_results = []
        with tempfile.TemporaryDirectory(prefix='ipra_one_hole_') as temp:
            # CLI coverage includes every original scalar fixture and every
            # new one-hole fixture, under normal Python and Python -O.
            for index, row in enumerate(rows):
                actual, oracle = agreement(module, row['packet'], direct, row['name'])
                expected = row['expected'] if direct else row.get('five_expected', row['expected'])
                require(actual['accepted'] == expected, ('fixed verdict', path.name, row['name']))
                calls = []
                if row['cohort'] != 'scalar_v2':
                    proof_file = Path(temp)/f'case_{index:03d}.json'
                    proof_file.write_text(json.dumps(row['packet']) + '\n')
                    calls = [cli(path, proof_file, expected, flag) for flag in (False, True)]
                fixed_results.append({'name': row['name'], 'expected': expected,
                                      'sha256': digest(row['packet']), 'candidate': actual,
                                      'oracle_rules': oracle['rules'], 'cli': calls})
            malformed = []
            for index, text in enumerate(('', '[', 'not-json')):
                proof_file = Path(temp)/f'malformed_{index:02d}.json'
                proof_file.write_text(text)
                malformed += [cli(path, proof_file, False, flag) for flag in (False, True)]

        mutation_results, differences = [], []
        for row in mutations:
            label = (row['cohort'], row['index'])
            actual, _ = agreement(module, row['packet'], direct, label)
            old = run(frozen, row['packet'])['accepted']
            entry = {key: value for key, value in row.items() if key != 'packet'}
            entry.update({'accepted': actual['accepted'], 'baseline_accepted': old})
            mutation_results.append(entry)
            if old != actual['accepted']:
                differences.append({**entry, 'packet': row['packet']})
        deliberate = controls(path, rows, direct)
        detail = {'status': 'PASS', 'checker': path.name, 'checker_sha256': file_hash(path),
                  'direct_closure': direct, 'opening_cases': openings,
                  'fixed': fixed_results, 'malformed_json_cli': malformed,
                  'mutations': mutation_results, 'baseline_differences': differences,
                  'deliberate_controls': deliberate, 'numerical': numerical}
        (args.output/(path.stem + '.json')).write_text(json.dumps(detail, indent=2) + '\n')
        summaries.append({'checker': path.name, 'sha256': file_hash(path),
                          'opening_cases': openings, 'fixed_named_cases': len(rows),
                          'fixed_distinct_packets': len({digest(r['packet']) for r in rows}),
                          'fixed_accepts': sum(r['expected'] for r in fixed_results),
                          'fixed_rejects': sum(not r['expected'] for r in fixed_results),
                          'cli_calls': sum(len(r['cli']) for r in fixed_results) + len(malformed),
                          'mutations': len(mutations),
                          'distinct_mutations': len({r['sha256'] for r in mutations}),
                          'mutation_accepts': sum(r['accepted'] for r in mutation_results),
                          'baseline_differences_original_cohort': sum(r['cohort'] == 'original_regression' for r in differences),
                          'baseline_differences_new_cohort': sum(r['cohort'] == 'new_format' for r in differences),
                          'deliberate_controls_detected': len(deliberate),
                          'literal_numerical_certificates': len(numerical)})
        print(json.dumps(summaries[-1], sort_keys=True))

    provenance = {'source_commit': 'b10a56a8f655c607494a3069b31d6679d968797a',
                  'inherited_fixtures_sha256': file_hash(HERE/'inherited_fixtures.json'),
                  'frozen_baseline_sha256': file_hash(HERE/'baseline_scalar.py'),
                  'named_oracle_sha256': file_hash(HERE/'named_oracle.py')}
    summary = {'status': 'PASS', 'python': platform.python_version(),
               'provenance': provenance, 'kernels': summaries,
               'evidence_limit': 'Finite implementation comparisons and numerical tests; no formalized universal soundness, consistency, or bi-interpretation proof.'}
    (args.output/'summary.json').write_text(json.dumps(summary, indent=2) + '\n')


if __name__ == '__main__':
    main()
