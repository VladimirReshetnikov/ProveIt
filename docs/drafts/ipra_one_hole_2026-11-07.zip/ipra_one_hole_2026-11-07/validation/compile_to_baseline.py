"""Untrusted certificate compiler to the frozen original scalar checker.

It canonicalizes the sole template hole and expands direct Q introduction
through D introduction and elimination.  Fresh rigid names are reassigned in
the target's allocation order, including the extra D-elimination allocation.
The produced certificate is checked separately by baseline_scalar.py.
"""
from copy import deepcopy
from named_oracle import Oracle, opening


class Compiler:
    def __init__(self, direct_closure=True):
        self.direct_closure = direct_closure
        self.source_lower = 0
        self.target_lower = 0
        self.names = {}
        self.stack = []
        self.direct_introductions = 0
        self.aliased_motives = 0

    def rename(self, value):
        if type(value) is int:
            return self.names.get(value, value)
        if type(value) is list:
            return [self.rename(v) for v in value]
        return deepcopy(value)

    def motive(self, value, formula=True, depth=0):
        if not formula and type(value) is int:
            if value > 2 * depth:
                return 2 * depth + 1
            return self.rename(value)
        if formula:
            if len(value) == 2:
                return [self.motive(v, False, depth) for v in value]
            bound = 1 if len(value) == 1 else 2
            return [self.motive(v, True, depth + bound) for v in value]
        if len(value) == 1:
            return [self.motive(value[0], False, depth)]
        count, initial, body = value
        return [self.motive(count, False, depth),
                self.motive(initial, False, depth),
                self.motive(body, False, depth + 1)]

    def open(self, value, image=None, depth=0):
        return opening(value, image, depth=depth, lower=self.source_lower)

    def fresh_pair(self):
        self.source_lower -= 1
        self.target_lower -= 1
        self.names[self.source_lower] = self.target_lower
        return self.source_lower

    def compile_node(self, goal, context):
        # Source acceptance is checked independently before this producer runs.
        # A second explicit parse makes accidental misuse fail near its source.
        self.open(goal)
        target_goal = self.rename(goal)
        if goal in context:
            return target_goal, []
        instruction = self.stack.pop()
        if len(instruction) == 2:
            major, annotation = instruction
            target_major, major_cells = self.compile_node(major, context)
            if len(major) == 3:
                eigen = self.fresh_pair()
                assumption = self.open([major[0]], eigen)
                _, minor_cells = self.compile_node(goal, [*context, assumption])
                return target_goal, [[target_major, None], *major_cells, *minor_cells]
            if len(major) == 1:
                matrix = major[0]
                left, right = 0, annotation
                target_annotation = self.rename(annotation)
            else:
                matrix = annotation
                left, right = major
                target_annotation = self.motive(annotation)
                if target_annotation != self.rename(annotation):
                    self.aliased_motives += 1
            if self.open(matrix, right) != goal:
                raise ValueError('source transport endpoint does not match')
            _, minor_cells = self.compile_node(self.open(matrix, left), context)
            return target_goal, [[target_major, target_annotation], *major_cells, *minor_cells]
        if len(instruction) == 1:
            if len(goal) not in (1, 3) or (len(goal) == 1 and not self.direct_closure):
                raise ValueError('source introduction outside declared rule contract')
            annotation = instruction[0]
            target_annotation = self.rename(annotation)
            body = self.open(goal[0], annotation, depth=1)
            assumptions = [self.open(body, 0)]
            if len(body) == 2:
                assumptions.insert(0, body)
            eigen = self.fresh_pair()
            conclusion = self.open(body, [eigen])
            minor_context = [*context, *(self.open(a, eigen) for a in assumptions)]
            _, minor_cells = self.compile_node(conclusion, minor_context)
            if len(goal) == 3:
                return target_goal, [[target_annotation], *minor_cells]
            self.direct_introductions += 1
            # D_(unused,y) B(y) has the same matrix and the same introduction
            # premise as Q_y B(y).  Its elimination returns the Q hypothesis.
            paired = [target_goal[0], [0, 0], [0, 0]]
            self.target_lower -= 1
            return target_goal, [[paired, None], [0], *minor_cells]
        if instruction == []:
            return target_goal, [[]]
        raise ValueError('unsupported source instruction')

    def run(self, proof_packet):
        source = Oracle(direct_closure=self.direct_closure).run(proof_packet)
        if not source['accepted']:
            raise ValueError('compiler requires an independently accepted source proof')
        self.source_lower = self.target_lower = 0
        self.names = {}
        self.direct_introductions = self.aliased_motives = 0
        self.stack = deepcopy(proof_packet)
        goal, cells = self.compile_node(self.stack.pop(), [])
        if self.source_lower != source['final_k']:
            raise ValueError('source allocation trace disagrees with oracle')
        return {'packet': list(reversed(cells)) + [goal],
                'source_allocations': -self.source_lower,
                'target_allocations': -self.target_lower,
                'expanded_direct_introductions': self.direct_introductions,
                'normalized_motives': self.aliased_motives,
                'source_instruction_cells': len(proof_packet) - 1 - len(self.stack),
                'target_instruction_cells': len(cells)}
