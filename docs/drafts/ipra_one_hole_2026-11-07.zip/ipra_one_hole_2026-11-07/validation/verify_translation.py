"""Check accepted one-hole certificates after compilation to the old kernel.

This second audit isolates the deliberate format changes from mathematical
strength.  The target is the unchanged frozen original scalar checker.
"""
from pathlib import Path
import argparse
import json
import random

from compile_to_baseline import Compiler
from named_oracle import Oracle
from mutation_support import mutate
from new_cases import cases as new_cases
from verify import load, run, require, digest, file_hash

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--main', type=Path, default=HERE.parent/'checker.py')
    parser.add_argument('--five', type=Path, default=HERE.parent/'checker_five_rules.py')
    parser.add_argument('--output', type=Path, default=HERE/'results')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    inherited = json.loads((HERE/'inherited_fixtures.json').read_text())
    generated = new_cases(inherited)
    original = [row for row in inherited if row['cohort'] == 'original_scalar']
    rows = [dict(row, trace_cohort='fixed') for row in inherited + generated]
    for count, seed, parents, cohort in ((1200, 20261107, original, 'original_mutation'),
                                          (400, 20261108, generated, 'new_mutation')):
        rng = random.Random(seed)
        for index in range(count):
            parent = parents[index % len(parents)]
            rows.append({'name': cohort + '/' + str(index), 'trace_cohort': cohort,
                         'packet': mutate(parent['packet'], rng)})
    frozen = load(HERE/'baseline_scalar.py', 'translation_frozen_baseline')
    summaries = []
    for path, direct in ((args.main.resolve(), True), (args.five.resolve(), False)):
        source = load(path, 'translation_source_' + path.stem)
        checked, new_acceptances = [], []
        for row in rows:
            if not Oracle(direct_closure=direct).run(row['packet'])['accepted']:
                continue
            require(run(source, row['packet'])['accepted'], ('source oracle mismatch', row['name']))
            translated = Compiler(direct_closure=direct).run(row['packet'])
            target_packet = translated.pop('packet')
            require(target_packet[-1] == row['packet'][-1], ('root goal changed', row['name']))
            target_run = run(frozen, target_packet)
            require(target_run['accepted'], ('compiled proof rejected', path.name, row['name']))
            require(target_run['final_k'] == -translated['target_allocations'],
                    ('target allocation count', path.name, row['name']))
            entry = {'name': row['name'], 'cohort': row['trace_cohort'],
                     'source_sha256': digest(row['packet']), 'target_sha256': digest(target_packet),
                     **translated}
            checked.append(entry)
            if not run(frozen, row['packet'])['accepted']:
                require(translated['expanded_direct_introductions'] or translated['normalized_motives'],
                        ('unexplained old/new acceptance difference', row['name']))
                new_acceptances.append(entry)
            if row['name'].startswith('new/') and direct:
                output = HERE/'compiled_examples'/(row['name'].removeprefix('new/') + '.json')
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_text(json.dumps(target_packet, indent=2) + '\n')
        summary = {'checker': path.name, 'sha256': file_hash(path), 'status': 'PASS',
                   'compiled_certificates': len(checked),
                   'compiled_distinct_source_packets': len({r['source_sha256'] for r in checked}),
                   'fixed_certificates': sum(r['cohort'] == 'fixed' for r in checked),
                   'mutation_certificates': sum(r['cohort'] != 'fixed' for r in checked),
                   'expanded_direct_introductions': sum(r['expanded_direct_introductions'] for r in checked),
                   'normalized_motives': sum(r['normalized_motives'] for r in checked),
                   'newly_accepted_packets_explained': len(new_acceptances),
                   'source_allocations': sum(r['source_allocations'] for r in checked),
                   'target_allocations': sum(r['target_allocations'] for r in checked),
                   'source_instruction_cells': sum(r['source_instruction_cells'] for r in checked),
                   'target_instruction_cells': sum(r['target_instruction_cells'] for r in checked)}
        (args.output/(path.stem + '_translation.json')).write_text(
            json.dumps({'summary': summary, 'certificates': checked,
                        'newly_accepted_packets': new_acceptances}, indent=2) + '\n')
        summaries.append(summary)
        print(json.dumps(summary, sort_keys=True))
    (args.output/'translation_summary.json').write_text(json.dumps(
        {'status': 'PASS', 'baseline_sha256': file_hash(HERE/'baseline_scalar.py'),
         'kernels': summaries,
         'limit': 'Finite certificate compilation; the general soundness and completeness claims remain mathematical proof obligations.'},
        indent=2) + '\n')


if __name__ == '__main__':
    main()
