SINGLETON TEMPLATE NORMALIZATION AUDIT
====================================

This is independent, untrusted validation support for the singleton-template
iPRA checkers. The checkers do not import this package. It supplies a separate
term/formula grammar and a normalization of each external template hole to
the first free coordinate of the old vector opener.

Install this whole directory at:

  <package>/validation/template_audit/

The package root should contain checker.py and checker_five_rules.py.
Then run from any working directory:

  python3 -B <package>/validation/template_audit/audit_one_hole.py

This runs both variants and writes results.json beside this README. It needs
only Python 3.10 or later and the standard library; no network or other corpus
is required. Set --output PATH to choose another result location.

To test one candidate/reference pair explicitly:

  python3 -B audit_one_hole.py --checker /path/to/checker.py \
      --reference references/checker_vector_main.py \
      --cases cases.json --output results.json

To test several pairs, repeat --checker and --reference in the same order.
For the five-rule candidate use references/checker_vector_five.py.

WHAT IS CHECKED, PER VARIANT
----------------------------
* 6,000 deterministic randomized openings against the strict vector opener
  after independent template normalization. The seed is 9112026.
* 1,500 of those cases omit the image entirely, checking that validation still
  rejects every unprotected coordinate instead of treating it as a free hole.
* Both formula and numerical sorts, nested logical and iterator binders,
  protected coordinate aliases, huge external-hole coordinates, invalid images,
  malformed JSON values, and illegal future eigenparameters are exercised.
* The 62 unchanged scalar fixtures (45 accept, 17 reject) are checked against
  both the strict reference and their recorded expectations.
* Every equality motive is then inflated using hole offsets 3, 41 and 10^40,
  producing 186 packet tests. The new checker must preserve the original
  outcomes, final parameter floor, and remaining instruction count.
* Independently normalizing all inflated motives must restore the same result
  in the strict vector reference, in another 186 comparisons.

The bundled run has 1,816 successful openings, 135 accepted inflated packets,
and 99 inflated packets accepted by the singleton checker but rejected by
the strict vector parser. The latter demonstrate why raw acceptance-language
equality is NOT claimed. They all normalize to strict accepted certificates
with the unchanged public goal.

The same corpus is reused for both variants. Counts across variants are
executions of two implementations, not counts of distinct mathematical facts.
These are finite implementation tests. The general theorem is proved by
structural induction on templates and proof derivations in the report.

INDEPENDENCE AND TRUST BOUNDARY
------------------------------
The normalizer has separate formula and numerical grammar functions. It does
not use the production packed-depth byte table or the production opener to
normalize syntax. The two frozen strict-vector references retain their vector
index calculation and missing-index failure. No normalizer or oracle is part
of a delivered proof checker's trusted acceptance program.

references/checker_vector_main.py is the newly constructed strict-vector
counterpart of the main candidate's rule dispatch. Its substitution helper
is the inherited scalar vector opener. references/checker_vector_five.py is
the exact unchanged checker.py from the original current scalar archive.
cases.json is that archive's unchanged validation/new_cases/all_cases.json.

provenance.json records SHA-256 hashes of the bundled references, fixtures,
and inherited license/attribution files. The runner verifies them before use.
Every output also records the exact candidate and reference SHA-256 hashes.

ATTRIBUTION AND LICENSE
-----------------------
The inherited scalar source and fixtures come from Vladimir Reshetnikov's
ProveIt repository, docs/drafts/ipra_scalar_iteration_2026-11-07.zip, at commit
b10a56a8f655c607494a3069b31d6679d968797a. The source archive's Git blob hash is
57eefcca450cc0fd07977c663876641c38e8aef2. Its complete attribution is preserved
in SCALAR_ATTRIBUTION.txt and its MIT No Attribution license is preserved in
LICENSE_SOURCE.txt. The attribution's older snapshot identifies the scalar
draft's own predecessor corpus; the provenance above identifies the archive
actually inspected for this audit.

The explicit hole normalizer, coordinate-inflation test, portable runner,
and main strict-vector comparison program were prepared for Vladimir
Reshetnikov on 7 November 2026 as part of the singleton-template investigation.
This newly prepared validation material is made available under the same
MIT No Attribution terms. No priority claim is made for the inherited
calculus, scalar-iteration theorem, or earlier fixtures.
