"""Portable independent normalization audit for singleton-template checkers.

By default, run both root checkers after this directory is installed at
validation/template_audit. Explicit --checker/--reference pairs support other
locations. No network, external corpus, or nonstandard Python package is used.
The audited programs do not import this validation support.
"""
from pathlib import Path
from copy import deepcopy
import argparse
import hashlib
import importlib.util
import json
import platform
import random

ROOT = Path(__file__).resolve().parent
SEED = 9112026


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def canonical_term(value, bound=0, hole=lambda n: 2*n+1):
    """Parse numerical syntax and replace the unique external template hole."""
    if type(value) is int:
        if value <= 2*bound:
            return value
        return hole(bound)
    if type(value) is not list:
        raise ValueError('numerical syntax')
    if len(value) == 1:
        return [canonical_term(value[0], bound, hole)]
    if len(value) == 3:
        counter, initial, update = value
        return [canonical_term(counter, bound, hole),
                canonical_term(initial, bound, hole),
                canonical_term(update, bound+1, hole)]
    raise ValueError('numerical constructor')


def canonical_formula(value, bound=0, hole=lambda n: 2*n+1):
    """A separate formula grammar avoids the production depth/arity table."""
    if type(value) is not list:
        raise ValueError('formula syntax')
    if len(value) == 1:
        return [canonical_formula(value[0], bound+1, hole)]
    if len(value) == 2:
        return [canonical_term(v, bound, hole) for v in value]
    if len(value) == 3:
        return [canonical_formula(v, bound+2, hole) for v in value]
    raise ValueError('logical constructor')


def change_motives(packet, hole):
    """Only equality-transport motives are explicit formula templates."""
    result = deepcopy(packet)
    if type(result) is not list:
        return result
    for instruction in result[:-1]:
        if (type(instruction) is list and len(instruction) == 2
                and type(instruction[0]) is list and len(instruction[0]) == 2):
            try:
                instruction[1] = canonical_formula(instruction[1], hole=hole)
            except ValueError:
                # Unconsumed prefix data are permitted. A consumed malformed
                # motive cannot occur in an accepted proof certificate.
                pass
    return result


def opening(module, value, image, supplied, depth, lower):
    module.k = lower
    try:
        images = [deepcopy(image)] if supplied else []
        return True, module.inst(deepcopy(value), *images, d=depth)
    except Exception:
        return False, None


def run(module, packet):
    module.k = 0
    packet = deepcopy(packet)
    try:
        module.take = packet.pop
        accepted = bool(module.check(packet.pop(), []))
    except Exception:
        accepted = False
    return accepted, module.k, len(packet) if type(packet) is list else None


def audit(candidate, reference, cases):
    rng = random.Random(SEED)
    counters = dict(opening_tests=0, successful_openings=0,
                    no_image_tests=0, fixed_packets=0,
                    accepted_fixed_packets=0, inflated_packets=0,
                    accepted_inflated_packets=0,
                    vector_rejected_inflations=0, normalized_packets=0)

    def term(size, bound, holes=True):
        if size <= 0 or rng.randrange(3) == 0:
            choices = [0, -1, -2, -3, *range(1, 2*bound+1)]
            if holes:
                choices += [2*bound+1, 2*bound+2, 2*bound+3,
                            2*bound+91, 10**40]
            return rng.choice(choices)
        if rng.randrange(2) == 0:
            return [term(size-1, bound, holes)]
        return [term(size-1, bound, holes), term(size-1, bound, holes),
                term(size-1, bound+1, holes)]

    def formula(size, bound):
        if size <= 0 or rng.randrange(3) == 0:
            return [term(2, bound), term(2, bound)]
        if rng.randrange(2) == 0:
            return [formula(size-1, bound+1)]
        return [formula(size-1, bound+2) for _ in range(3)]

    malformed = [None, True, False, 0.0, 1.0, 'x', '', {}, {'x': 0},
                 [], [0, 0, 0, 0], [None], [False, 0], [[0, 0], 0]]
    for index in range(6000):
        bound = rng.randrange(5)
        numerical = rng.randrange(2)
        depth = 2*bound + numerical
        lower = -rng.randrange(4)
        if index % 7 == 0:
            value = deepcopy(rng.choice(malformed))
        else:
            value = term(3, bound) if numerical else formula(3, bound)
        image = term(2, 0, False) if index % 5 else rng.choice(malformed + [1, 2, 37])
        supplied = bool(index % 4)
        actual = opening(candidate, value, image, supplied, depth, lower)
        if supplied:
            try:
                canon = (canonical_term if numerical else canonical_formula)(value, bound)
                expected = opening(reference, canon, image, True, depth, lower)
            except ValueError:
                expected = False, None
        else:
            # No-image validation must reject all unprotected coordinates.
            expected = opening(reference, value, image, False, depth, lower)
            counters['no_image_tests'] += 1
        require(actual == expected,
                ('opening', index, value, image, supplied, depth, lower,
                 actual, expected))
        counters['opening_tests'] += 1
        counters['successful_openings'] += actual[0]

    for row in cases:
        packet = row['packet']
        actual = run(candidate, packet)
        old = run(reference, packet)
        require(actual == old, ('fixed packet', row['name'], actual, old))
        require(actual[0] == row['expected'],
                ('fixture expectation', row['name'], actual, row['expected']))
        counters['fixed_packets'] += 1
        counters['accepted_fixed_packets'] += actual[0]
        for offset in (3, 41, 10**40):
            inflated = change_motives(packet, lambda depth: 2*depth+offset)
            new_result = run(candidate, inflated)
            require(new_result == actual,
                    ('inflation', row['name'], offset, actual, new_result))
            counters['inflated_packets'] += 1
            counters['accepted_inflated_packets'] += new_result[0]
            counters['vector_rejected_inflations'] += new_result[0] and not run(reference, inflated)[0]
            canonical = change_motives(inflated, lambda depth: 2*depth+1)
            converted = run(reference, canonical)
            require(converted == new_result,
                    ('normalization', row['name'], offset, new_result, converted))
            counters['normalized_packets'] += 1
    return counters


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checker', type=Path, action='append',
                        help='Candidate path; repeat in the same order as --reference.')
    parser.add_argument('--reference', type=Path, action='append',
                        help='Strict-vector reference path paired with --checker.')
    parser.add_argument('--cases', type=Path, default=ROOT/'cases.json')
    parser.add_argument('--output', type=Path, default=ROOT/'results.json')
    args = parser.parse_args()
    require(bool(args.checker) == bool(args.reference),
            'Supply both --checker and --reference, or neither.')
    candidates = args.checker or [ROOT.parent.parent/'checker.py',
                                 ROOT.parent.parent/'checker_five_rules.py']
    references = args.reference or [ROOT/'references/checker_vector_main.py',
                                   ROOT/'references/checker_vector_five.py']
    require(len(candidates) == len(references),
            'Each --checker needs one --reference in the same order.')
    provenance = json.loads((ROOT/'provenance.json').read_text())
    for item in provenance['fixed_files']:
        require(digest(ROOT/item['path']) == item['sha256'],
                ('Changed frozen support', item['path']))
    cases = json.loads(args.cases.read_text())
    results = []
    for index, (candidate_path, reference_path) in enumerate(zip(candidates, references)):
        candidate = load('candidate_' + str(index), candidate_path.resolve())
        reference = load('reference_' + str(index), reference_path.resolve())
        results.append({'checker': candidate_path.name,
                        'checker_sha256': digest(candidate_path),
                        'reference': reference_path.name,
                        'reference_sha256': digest(reference_path),
                        'counts': audit(candidate, reference, cases)})
    report = {'passed': True, 'python': platform.python_version(),
              'random_seed': SEED, 'cases_sha256': digest(args.cases),
              'variants': results,
              'note': 'Finite implementation evidence, not a formal proof-assistant certificate.'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
