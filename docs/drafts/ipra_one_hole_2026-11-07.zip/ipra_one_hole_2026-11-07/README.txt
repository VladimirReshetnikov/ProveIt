ONE-HOLE SUBSTITUTION: A SMALLER COMPLETE PRESENTATION OF iPRA
Prepared for Vladimir Reshetnikov, 7 November 2026
============================================================

START HERE
----------
report.pdf is the complete 32-page mathematical paper.
report.tex and sections/*.tex are all editable LaTeX sources.

ESTABLISHED RESULT
------------------
Both complete acceptance programs are below the current ProveIt draft
frontier in every inherited normalized source measure:

                                      Tokens    AST nodes    UTF-8 bytes
Current coordinatewise envelope          411          425          1207
checker_five_rules.py                    406          415          1195
checker.py                              389          413          1188

The primary's core also beats every current core minimum:
330 / 350 / 938, compared with 352 / 362 / 957.

All counts include the complete trusted project program, including JSON
input, syntax and scope checking, substitution, inference, verdicts,
and exit handling. Exact normalization uses CPython 3.12.14 and the
unchanged inherited metric. Normalized bytes are different from raw bytes.

The current repository snapshot is:
  b10a56a8f655c607494a3069b31d6679d968797a
  https://github.com/VladimirReshetnikov/ProveIt/tree/b10a56a8f655c607494a3069b31d6679d968797a/docs/drafts

The six supplied archives contain ten current root programs. An expanded
inventory of 107 distinct complete checker sources has the same minima.
Every comparator is included, with source hashes and archive provenance.
The older 427 / 436 / 1246 envelope printed in the supplied reports is
their predecessor benchmark, not the current benchmark used here.

THE NEW IDEA
------------
Once arithmetic uses scalar iteration, every actual substitution in the
logical and arithmetic kernel supplies at most one numerical term.
The paired logical binder opens its two variables successively.
An environment vector, environment lookup, and index computation are
therefore unnecessary.

In an explicitly open template, all positive coordinates outside the
locally protected binders denote the same hole. Closed goals are checked
with no replacement available and still reject every dangling coordinate.
The paper proves an invocation-relative canonicalization theorem: every
accepted template has an ordinary one-variable spelling with exactly the
same endpoint instances. This gives an effective proof transformation,
not just an appeal to numerical experiments.

The five-rule companion changes only the original scalar checker's
substitution operation. It alone already crosses the current frontier.
The primary additionally uses sorted introduction, protected-depth opening,
and instruction-only dispatch. It directly accepts the already-derived
closure introduction. Both programs have the same mathematical theorem
set but different raw certificate languages.

MATHEMATICAL CONTENT
--------------------
The paper includes:
  * Every primitive logical and numerical axiom/schema/inference rule.
  * Derivation of full intuitionistic first-order logic and equation induction.
  * A shorter internal predecessor bootstrap, combining the original
    factor-trade map with a saturated-iteration argument.
  * Quantifier-free reflection, pairing, and full primitive-recursive coding.
  * Both ordinary interpretations and both internal composite isomorphisms.
  * A single-hole soundness/completeness proof and complete checker listings.
  * Explicit contribution/provenance boundaries and further research questions.

The ordinary realization is bi-interpretable with iPRA on the entire
numerical domain. The identity graph x=y gives both composite isomorphisms.
The result preserves full intuitionistic logic; it does not substitute a
classical or merely quantifier-free theory.

RUN
---
Python 3.10 or later is sufficient to run the checkers. They import only
json and sys. From this directory:

  python3 checker.py examples/iteration_zero.json
  python3 checker.py examples/reflexivity_one_hole.json
  python3 checker.py examples/addition_two_three.json

These print ACCEPT and exit 0. Each also works with checker_five_rules.py.

  python3 checker.py examples/false_equation.json
  python3 checker.py examples/invalid_closed_hole.json

These print REJECT and exit 1.

  python3 checker.py examples/direct_closure_reflexivity.json

The last example is accepted by the primary only. The companion implements
the five primitive patterns; expand the derived closure rule when using it.
examples/derived_closure_retained_base.json works with both programs.

FORMAT.txt gives the complete serialized syntax. A rejected packet is not
a proof that its goal is false. The checker verifies supplied proofs; it
does not search for them. Parser, stack, time, and memory limits can reject
sufficiently large otherwise-valid certificates.

REPRODUCE
---------
  python3 package.py --verify
  python3 reproduce.py
  python3 build.py

The first command checks the delivered file manifest. The second recomputes
all measurements and portable validation. The third rebuilds the PDF.
It needs pdfLaTeX and the standard packages listed in report.tex.
A local temporary-format fallback accommodates an unconfigured TeX tree;
no shell escape or network download is used.

Reproduction updates generated results. Recompiling can alter PDF hashes.
Verify the original manifest before regenerating outputs; after intentional
changes run package.py to refresh the manifest and create a new ZIP.

EVIDENCE BOUNDARY
-----------------
The metatheorems have written proofs and independent mathematical audits.
They are not formalized in Lean or Rocq. Finite tests validate the concrete
implementation and cannot prove consistency, minimality, or universal
correctness by themselves. The archive reports distinct packets separately
from overlapping named cases and mutations.

The achieved size claim is a strict reduction below a pinned finite corpus.
It is not a proof of the globally simplest possible axiomatization.
The inherited scalar arithmetic, fused logic, and interpretation construction
are explicitly credited. The main new contribution is elimination of the
substitution environment with a conservative single-hole template convention.

CONTENTS
--------
report.pdf; report.tex; sections/    Complete paper and editable sources
checker.py                          Entire primary acceptance program
checker_five_rules.py               Isolated one-hole specialization
FORMAT.txt; examples/                Concrete certificate contract and examples
comparison/                         107 frozen sources, hashes, metric, ablations
validation/                         Named oracle, normalization audit, fixtures
results/                            Metrics, validation and build receipts
measure.py; reproduce.py             Offline reproduction
build.py; package.py                 PDF build and manifest/ZIP generation
ATTRIBUTION.txt; LICENSE_SOURCE.txt   Intellectual provenance and source license
SHA256SUMS.txt                       Delivered payload integrity manifest
