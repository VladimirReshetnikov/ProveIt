"""Reproduce the complete comparison and all portable validation offline."""
from pathlib import Path
import argparse
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(script):
    result = subprocess.run([sys.executable, "-B", str(ROOT / script)],
                            cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    (ROOT / "results" / (Path(script).stem + "_run.txt")).write_text(result.stdout)
    if result.returncode:
        print(result.stdout)
        raise SystemExit(result.returncode)
    print("PASS:", script)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pdf", action="store_true")
    args = parser.parse_args()
    (ROOT / "results").mkdir(exist_ok=True)
    for script in ("measure.py", "validation/verify.py",
                   "validation/verify_translation.py",
                   "validation/template_audit/audit_one_hole.py"):
        run(script)
    named = json.loads((ROOT / "validation/results/summary.json").read_text())
    translated = json.loads((ROOT / "validation/results/translation_summary.json").read_text())
    templates = json.loads((ROOT / "validation/template_audit/results.json").read_text())
    if named["status"] != "PASS" or translated["status"] != "PASS" or not templates["passed"]:
        raise SystemExit("A validation summary did not report success.")
    summary = {
        "status": "PASS",
        "named_oracle": named,
        "certificate_translation": translated,
        "template_normalization": templates,
        "counting_note": "Cohorts overlap; named cases are not distinct theorem counts.",
        "proof_status": "Written metatheory, with finite executable implementation evidence; no Lean/Rocq formalization.",
    }
    (ROOT / "results/verification.json").write_text(json.dumps(summary, indent=2) + "\n")
    if args.pdf:
        run("build.py")
    print("All measurements and portable validation passed.")


if __name__ == "__main__":
    main()
