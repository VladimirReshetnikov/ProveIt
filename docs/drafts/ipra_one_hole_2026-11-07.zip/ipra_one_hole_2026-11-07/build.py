"""Compile the report; accommodate Debian TeX trees without generated formats."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def run(command, env, cwd):
    result = subprocess.run(command, env=env, cwd=cwd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-10000:] + '\n' + result.stderr[-3000:])
    return result.stdout


def main():
    if not shutil.which('pdflatex'):
        raise SystemExit('Install a LaTeX distribution providing pdflatex.')
    env = os.environ.copy()
    found = subprocess.run(['kpsewhich', 'pdflatex.fmt'], env=env, capture_output=True, text=True)
    with tempfile.TemporaryDirectory(prefix='ipra-tex-') as temporary:
        arguments = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error', '-no-shell-escape']
        fallback = not found.stdout.strip()
        if fallback:
            trees = [str(p) for p in [Path('/usr/share/texlive/texmf-dist'), Path('/usr/share/texmf')]
                     if p.is_dir()]
            if trees:
                env['TEXMF'] = '{' + ','.join(trees) + '}'
            run(['pdftex', '-ini', '-etex', '-interaction=nonstopmode', '-halt-on-error',
                 '-jobname=pdflatex', '-progname=pdflatex', 'pdflatex.ini'], env, temporary)
            arguments += ['-fmt=' + str(Path(temporary)/'pdflatex.fmt'),
                          r'\pdfmapfile{+lm.map}\pdfmapfile{+symbols.map}\pdfmapfile{+euler.map}\input{report.tex}']
        else:
            arguments.append('report.tex')
        for number in range(1, 4):
            output = run(arguments, env, ROOT)
            (ROOT/'results'/f'latex_pass_{number}.txt').write_text(output)
    log = (ROOT/'report.log').read_text(errors='replace')
    problems = [line for line in log.splitlines() if 'Overfull' in line or 'undefined' in line]
    if problems:
        raise RuntimeError('\n'.join(problems))
    result = dict(status='PASS', passes=3, temporary_format_bootstrap=fallback,
                  overfull_or_undefined_warnings=problems,
                  output_summary=next(line for line in log.splitlines() if 'Output written on' in line))
    (ROOT/'results/build.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
