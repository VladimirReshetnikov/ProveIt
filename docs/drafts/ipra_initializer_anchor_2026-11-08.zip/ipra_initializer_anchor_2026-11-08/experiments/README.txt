SECONDARY LOGICAL EXPERIMENT

This independent one-assumption progression-closure experiment is not part of
the proposed anchored theory and is not a size winner. It measures 332 tokens,
373 AST nodes, and 1004 normalized bytes. Nine targeted CLI checks were run;
a complete all-raw-input validation theorem is not claimed.

The atomic closure denotes a successor-progression condition, while compound
closure retains conditional universal meaning. Eliminating the retained atomic
base requires an additional successor-use elimination case and a compound
wrapper to restore uniform formula congruence. The main report does not rely
on this candidate. Its source and measurement receipt are included for
transparency about the unsuccessful size comparison.


FOCUSED ANCHORED-SYNTAX ADAPTATION
--------------------------------
checker_anchor_experiment.py is a natural adaptation of the current structural
checker to closed binary descriptors. It measures 453 normalized tokens,
480 AST nodes, and 1446 normalized bytes. Nine focused computation/capture
checks have their expected outcomes (anchor_checker_results.json).

The generic substitution traversal remains necessary for logical binders
and equality templates. Skipping a closed update index adds a syntax-specific
case. Applying a descriptor to the two different arguments, current state
and original initializer, also requires descriptor traversal and validation
of the inserted numerical images. The permitted arithmetic resource is
reduced, but this direct implementation adds code rather than saving it.

The prototype has NOT received full all-raw-input soundness/completeness
validation. Its counts are measurements of an experimental source file,
not a new validated checker bound or an impossibility result. The main
mathematical proof and symbolic predecessor certificate do not depend on it.
