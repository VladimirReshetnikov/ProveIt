"""Reproduce the pinned corpus comparison without downloading or executing it."""
import json
import platform
from pathlib import Path

from source_measure import metrics

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "reference/baseline_manifest.json").read_text())
rows = []
for entry in manifest["programs"]:
    measured = metrics(ROOT / entry["local_file"])
    if measured["sha256"] != entry["sha256"]:
        raise ValueError("Baseline source has changed: " + entry["local_file"])
    rows.append({**entry, **measured})
fields = ("normalized_tokens", "ast_nodes", "normalized_bytes")
result = {
    "python": platform.python_version(),
    "commit": manifest["commit"],
    "archive_count": len(manifest["archives"]),
    "program_count": len(rows),
    "coordinate_minima": {key: min(row[key] for row in rows) for key in fields},
    "minimum_attainers": {
        key: [row["local_file"] for row in rows
              if row[key] == min(r[key] for r in rows)] for key in fields
    },
    "rows": rows,
}
destination = ROOT / "results/baseline_metrics.json"
destination.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: value for key, value in result.items() if key != "rows"}, indent=2))
