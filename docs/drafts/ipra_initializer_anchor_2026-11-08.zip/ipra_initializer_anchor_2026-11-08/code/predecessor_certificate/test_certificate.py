"""Meaningful negative controls for the finite symbolic certificate."""
import copy
import json
import subprocess
import sys
from pathlib import Path
from checker import verify

ROOT=Path(__file__).resolve().parent
assumptions=json.loads((ROOT/'assumptions.json').read_text())
certificate=json.loads((ROOT/'certificate.json').read_text())

def selected(c,name):
    return next(t for t in c['theorems'] if t['name']==name)

def nodes(value):
    if isinstance(value,dict):
        if 'r' in value:yield value
        for child in value.values():yield from nodes(child)
    elif isinstance(value,list):
        for child in value:yield from nodes(child)

controls=[]
def rejection(name,edit):
    mutated=copy.deepcopy(certificate)
    edit(mutated)
    try:
        verify(assumptions,mutated)
    except Exception as error:
        controls.append({'case':name,'rejected':True,'reason':str(error)})
    else:
        raise RuntimeError('Malformed certificate accepted: '+name)

baseline=verify(assumptions,certificate)
(ROOT/'verification_results.json').write_text(json.dumps(baseline,indent=2)+'\n')
rejection('false_predecessor_claim',lambda c:selected(c,'P_successor')['conclusion'].__setitem__(1,['0']))
rejection('unretained_hypothesis',lambda c:selected(c,'P_successor').__setitem__('proof',
    {'r':'hyp','equation':[['P',['S',['v','m']]],['v','m']]}))
rejection('captured_induction_parameter',lambda c:selected(c,'V_guard')['proof'].__setitem__('fresh','m'))
rejection('induction_hypothesis_without_induction',lambda c:selected(c,'P_successor')['proof'].__setitem__('r','cases'))
rejection('opposite_boolean_branch',lambda c:selected(c,'A_preserves_guard')['proof'].__setitem__(
    'zero',copy.deepcopy(selected(c,'A_preserves_guard')['proof']['one'])))
rejection('undeclared_boolean_test',lambda c:selected(c,'A_preserves_guard')['proof'].__setitem__(
    'test',['P',['v','u']]))
rejection('missing_guard_proof',lambda c:next(n for n in nodes(selected(c,'V_successor')['proof'])
    if n.get('r')=='use' and n.get('name')=='B_under_guard').__setitem__('premises',[]))
rejection('future_theorem_reference',lambda c:selected(c,'L_strict_diagonal').__setitem__('proof',
    {'r':'use','name':'P_successor','subst':{'m':['v','m']},'premises':[]}))
rejection('unknown_computation_axiom',lambda c:next(n for n in nodes(c) if n.get('r')=='axiom').__setitem__(
    'name','invented_axiom'))
rejection('missing_axiom_substitution',lambda c:next(n for n in nodes(c) if n.get('r')=='axiom').__setitem__(
    'subst',{}))
rejection('malformed_function_arity',lambda c:selected(c,'P_successor')['conclusion'].__setitem__(
    0,['P',['S',['v','m']],['0']]))
rejection('required_theorem_omitted',lambda c:c.__setitem__('theorems',c['theorems'][:-1]))
rejection('conditional_final_goal_disallowed',lambda c:selected(c,'P_successor').__setitem__(
    'assumptions',[[['0'],['0']]]))

runs=[]
for optimized in (False,True):
    args=[sys.executable]+(['-O'] if optimized else [])+[str(ROOT/'checker.py')]
    result=subprocess.run(args,text=True,capture_output=True)
    if result.returncode or not json.loads(result.stdout)['verified']:
        raise RuntimeError('CLI verification failed')
    runs.append({'optimized':optimized,'returncode':result.returncode,'verified':True})
receipt={'baseline_verified':True,'negative_controls':controls,'cli_checks':runs,
         'scope':'Symbolic predecessor proof relative to explicitly listed imports; not a full iPRA formalization.'}
(ROOT/'test_results.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'verified_theorems':len(baseline['theorems']),
                  'checked_nodes':baseline['total_checked_nodes'],
                  'negative_controls_rejected':len(controls),'cli_checks':len(runs)},indent=2))
