"""Untrusted producer of an explicit, independently replayed proof tree."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
Z = ('0',)
def v(name): return ('v', name)
def S(t): return ('S', t)
def F(name, *args): return (name, *args)
def L(a,b): return F('L',a,b)
def C(e,a,b): return F('C',e,a,b)
def A(u,m): return F('A',u,m)
def B(u,m): return F('B',u,m)
def J(n,a): return F('J',n,a)
def V(n,m): return F('V',n,m)
def P(m): return F('P',m)
ONE=S(Z)
n,m,u,a,b,x,y,e = map(v, ['n','m','u','a','b','x','y','e'])

AXIOMS = {}
def axiom_schema(name,params,left,right):
    AXIOMS[name]={'name':name,'params':params,'equation':(left,right)}
axiom_schema('L0',['y'],L(Z,y),ONE)
axiom_schema('Ls0',['x'],L(S(x),Z),Z)
axiom_schema('Lss',['x','y'],L(S(x),S(y)),L(x,y))
axiom_schema('C0',['a','b'],C(Z,a,b),a)
axiom_schema('Cs',['n','a','b'],C(S(n),a,b),b)
axiom_schema('J0',['a'],J(Z,a),a)
axiom_schema('Js',['n','a'],J(S(n),a),B(J(n,a),a))
axiom_schema('Adef',['u','m'],A(u,m),C(L(S(S(u)),m),u,S(u)))
axiom_schema('Bdef',['u','m'],B(u,m),C(L(S(u),m),Z,A(u,m)))
axiom_schema('Vdef',['n','m'],V(n,m),J(S(n),m))
axiom_schema('Pdef',['m'],P(m),V(m,m))


def sub(t, mapping):
    if t[0]=='v': return mapping.get(t[1],t)
    return (t[0],*(sub(a,mapping) for a in t[1:]))

class Proof:
    def __init__(self,left,right,node): self.left,self.right,self.node=left,right,node
    @property
    def equation(self): return self.left,self.right

def ax(name,**mapping):
    schema=AXIOMS[name]
    assert set(mapping)==set(schema['params'])
    left,right=(sub(t,mapping) for t in schema['equation'])
    return Proof(left,right,{'r':'axiom','name':name,'subst':mapping})
def hyp(left,right): return Proof(left,right,{'r':'hyp','equation':(left,right)})
def refl(t): return Proof(t,t,{'r':'refl','term':t})
def sym(p): return Proof(p.right,p.left,{'r':'sym','proof':p.node})
def chain(*proofs):
    assert proofs
    for p,q in zip(proofs,proofs[1:]):
        assert p.right==q.left, ('chain mismatch',p.right,q.left)
    return Proof(proofs[0].left,proofs[-1].right,
                 {'r':'trans','proofs':[p.node for p in proofs]})
def at(t,path):
    for i in path:t=t[i]
    return t
def replace(t,path,value):
    if not path:return value
    result=list(t);result[path[0]]=replace(t[path[0]],path[1:],value)
    return tuple(result)
def rw(t,path,p):
    assert at(t,path)==p.left, ('rewrite mismatch',at(t,path),p.left,path)
    template=replace(t,path,v('_hole'))
    return Proof(t,replace(t,path,p.right),{'r':'cong','hole':'_hole',
                 'template':template,'proof':p.node})
def reduce(t,*steps):
    proofs=[refl(t)]
    for path,p in steps: proofs.append(rw(proofs[-1].right,path,p))
    return chain(*proofs)

THEOREMS=[]
REGISTRY={}
def theorem(name,params,proof,assumptions=()):
    item={'name':name,'params':params,'assumptions':assumptions,
          'conclusion':proof.equation,'proof':proof.node}
    THEOREMS.append(item); REGISTRY[name]=item
    return item

def use(name,premises=(),**mapping):
    schema=REGISTRY[name]
    assert set(mapping)==set(schema['params'])
    assert len(premises)==len(schema['assumptions'])
    for expected,p in zip(schema['assumptions'],premises):
        assert tuple(sub(t,mapping) for t in expected)==p.equation
    left,right=(sub(t,mapping) for t in schema['conclusion'])
    return Proof(left,right,{'r':'use','name':name,'subst':mapping,
                           'premises':[p.node for p in premises]})

def induction(rule,variable,body,target,fresh,base,step):
    assert base.equation==tuple(sub(t,{variable:Z}) for t in body)
    assert step.equation==tuple(sub(t,{variable:S(v(fresh))}) for t in body)
    conclusion=tuple(sub(t,{variable:target}) for t in body)
    return Proof(*conclusion,{'r':rule,'variable':variable,'fresh':fresh,
                  'body':body,'target':target,'base':base.node,'step':step.node})

# L(Sm,m)=0 by equation induction, keeping no changing parameters.
i=v('i_diag')
base=ax('Ls0',x=Z)
step=chain(ax('Lss',x=S(i),y=i),hyp(L(S(i),i),Z))
theorem('L_strict_diagonal',['m'],induction('ind','m',(L(S(m),m),Z),m,
                                               'i_diag',base,step))

# Unfolding V exposes the fixed anchored update.
theorem('V_raw_successor',['n','m'],reduce(V(S(n),m),
    ((),ax('Vdef',n=S(n),m=m)),
    ((),ax('Js',n=S(n),a=m)),
    ((1,),sym(ax('Vdef',n=n,m=m)))))

# Initial reset V(0,m)=0.
theorem('V_zero',['m'],reduce(V(Z,m),
    ((),ax('Vdef',n=Z,m=m)),
    ((),ax('Js',n=Z,a=m)),
    ((1,),ax('J0',a=m)),
    ((),ax('Bdef',u=m,m=m)),
    ((1,),use('L_strict_diagonal',m=m)),
    ((),ax('C0',a=Z,b=A(m,m)))))

# Conditional selector opening. The hypothesis is explicitly discharged
# as a premise of every subsequent invocation of this lemma.
guard=L(S(u),S(m))
theorem('B_under_guard',['u','m'],reduce(B(u,S(m)),
    ((),ax('Bdef',u=u,m=S(m))),
    ((1,),hyp(guard,ONE)),
    ((),ax('Cs',n=Z,a=Z,b=A(u,S(m))))),[(guard,ONE)])

# A preserves the guard by the supplied Boolean range of L.
test=L(S(S(u)),S(m))
goal=L(S(A(u,S(m))),S(m))
pa0=reduce(A(u,S(m)),
    ((),ax('Adef',u=u,m=S(m))),
    ((1,),hyp(test,Z)),
    ((),ax('C0',a=u,b=S(u))))
pa1=reduce(A(u,S(m)),
    ((),ax('Adef',u=u,m=S(m))),
    ((1,),hyp(test,ONE)),
    ((),ax('Cs',n=Z,a=u,b=S(u))))
zero=chain(rw(goal,(1,1),pa0),hyp(guard,ONE))
one=chain(rw(goal,(1,1),pa1),hyp(test,ONE))
theorem('A_preserves_guard',['u','m'],Proof(goal,ONE,
    {'r':'bool_cases','test':test,'conclusion':(goal,ONE),
     'zero':zero.node,'one':one.node}),[(guard,ONE)])

# Guard invariant, with m fixed throughout induction on n.
i=v('i_guard')
body=(L(S(V(n,S(m))),S(m)),ONE)
base=reduce(L(S(V(Z,S(m))),S(m)),
    ((1,1),use('V_zero',m=S(m))),
    ((),ax('Lss',x=Z,y=m)),
    ((),ax('L0',y=m)))
vi=V(i,S(m));ih=hyp(L(S(vi),S(m)),ONE)
pnext=chain(use('V_raw_successor',n=i,m=S(m)),
            use('B_under_guard',premises=[ih],u=vi,m=m))
step=chain(rw(L(S(V(S(i),S(m))),S(m)),(1,1),pnext),
           use('A_preserves_guard',premises=[ih],u=vi,m=m))
theorem('V_guard',['n','m'],induction('ind','n',body,n,'i_guard',base,step))

# Hence the positive-anchor orbit has exactly the old saturating recurrence.
vn=V(n,S(m))
theorem('V_successor',['n','m'],chain(
    use('V_raw_successor',n=n,m=S(m)),
    use('B_under_guard',premises=[use('V_guard',n=n,m=m)],u=vn,m=m)))

# The selector commutes with successor by numerical coverage, no induction.
z=v('i_cases')
body=(C(e,S(a),S(b)),S(C(e,a,b)))
base=chain(ax('C0',a=S(a),b=S(b)),
           sym(rw(S(C(Z,a,b)),(1,),ax('C0',a=a,b=b))))
step=chain(ax('Cs',n=z,a=S(a),b=S(b)),
           sym(rw(S(C(S(z),a,b)),(1,),ax('Cs',n=z,a=a,b=b))))
theorem('C_successor',['e','a','b'],induction('cases','e',body,e,
                                                  'i_cases',base,step))

# A_{SSm}(0)=1 and A_{SSm}(Su)=S A_{Sm}(u).
theorem('A_initial',['m'],reduce(A(Z,S(S(m))),
    ((),ax('Adef',u=Z,m=S(S(m)))),
    ((1,),ax('Lss',x=S(Z),y=S(m))),
    ((1,),ax('Lss',x=Z,y=m)),
    ((1,),ax('L0',y=m)),
    ((),ax('Cs',n=Z,a=Z,b=ONE))))

theorem('A_conjugacy',['u','m'],reduce(A(S(u),S(S(m))),
    ((),ax('Adef',u=S(u),m=S(S(m)))),
    ((1,),ax('Lss',x=S(S(u)),y=S(m))),
    ((),use('C_successor',e=L(S(S(u)),S(m)),a=u,b=S(u))),
    ((1,),sym(ax('Adef',u=u,m=S(m))))))

# Fixed-parameter shift, then only afterward diagonal specialization.
t=v('t');i=v('i_shift')
body=(V(S(t),S(S(m))),S(V(t,S(m))))
left=reduce(V(ONE,S(S(m))),
    ((),use('V_successor',n=Z,m=S(m))),
    ((1,),use('V_zero',m=S(S(m)))),
    ((),use('A_initial',m=m)))
right=rw(S(V(Z,S(m))),(1,),use('V_zero',m=S(m)))
base=chain(left,sym(right))
ih=hyp(V(S(i),S(S(m))),S(V(i,S(m))))
step=reduce(V(S(S(i)),S(S(m))),
    ((),use('V_successor',n=S(i),m=S(m))),
    ((1,),ih),
    ((),use('A_conjugacy',u=V(i,S(m)),m=m)),
    ((1,),sym(use('V_successor',n=i,m=m))))
theorem('V_shift',['t','m'],induction('ind','t',body,t,'i_shift',base,step))

theorem('P_zero',[],reduce(P(Z),
    ((),ax('Pdef',m=Z)),((),use('V_zero',m=Z))))

theorem('P_one',[],reduce(P(ONE),
    ((),ax('Pdef',m=ONE)),
    ((),use('V_successor',n=Z,m=Z)),
    ((1,),use('V_zero',m=ONE)),
    ((),ax('Adef',u=Z,m=ONE)),
    ((1,),ax('Lss',x=S(Z),y=Z)),
    ((1,),ax('Ls0',x=Z)),
    ((),ax('C0',a=Z,b=ONE))))

theorem('P_double_successor',['m'],reduce(P(S(S(m))),
    ((),ax('Pdef',m=S(S(m)))),
    ((),use('V_shift',t=S(m),m=m)),
    ((1,),sym(ax('Pdef',m=S(m))))))

i=v('i_pred')
step=chain(use('P_double_successor',m=i),
           rw(S(P(S(i))),(1,),hyp(P(S(i)),i)))
theorem('P_successor',['m'],induction('ind','m',(P(S(m)),m),m,
                                            'i_pred',use('P_one'),step))

assumptions={'equations':list(AXIOMS.values()),
 'boolean_range':'forall x y, L(x,y)=0 or L(x,y)=S(0)',
 'coverage':'forall x, x=0 or exists y, x=S(y)',
 'interpretation':{'J':'J_B, with B(u,v) the explicitly defined closed binary update',
 'A':'A(u,m)=C(L(S(S(u)),m),u,S(u))',
 'V':'V(n,m)=J_B(S(n),m)', 'P':'P(m)=V(m,m)'},
 'scope':'Comparator and selector properties are imported explicitly; see the report for their derivations.'}
certificate={'theorems':THEOREMS}
(ROOT/'assumptions.json').write_text(json.dumps(assumptions,indent=2)+'\n')
(ROOT/'certificate.json').write_text(json.dumps(certificate,indent=2)+'\n')
print('Produced',len(THEOREMS),'theorems')
