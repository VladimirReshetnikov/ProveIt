SYMBOLIC CERTIFICATE FOR THE ANCHORED PREDECESSOR
================================================

Scope
-----
This package checks a finite equational derivation of

    P(0) = 0,
    P(Sm) = m.

It also checks all intermediate reset, guard, recurrence, conjugacy, and
fixed-parameter shift lemmas used in the proof. It uses symbolic variables
and literal-equation induction, not tests of the equations at finite numbers.
The certificate has 15 theorems and 175 checked proof nodes. The source
checker is intentionally readable and is not a minimum-size contender.

Exact arithmetic imports
------------------------
The trusted assumptions are enumerated in assumptions.json:

  L(0,y)=1; L(Sx,0)=0; L(Sx,Sy)=L(x,y);
  C(0,a,b)=a; C(Sn,a,b)=b;
  J_B(0,a)=a; J_B(Sn,a)=B(J_B(n,a),a).

The four explicit definitions are

  A(u,m) = C(L(SSu,m),u,Su),
  B(u,m) = C(L(Su,m),0,A(u,m)),
  V(n,m) = J_B(Sn,m),
  P(m) = V(m,m).

The comparator Boolean range L(x,y)=0 or L(x,y)=1 and numerical coverage
x=0 or exists y x=Sy are also explicit imports. Here 1 denotes S(0).
The surrounding report supplies the internal anchored definitions and proofs
of the comparator and selector properties. This package does not recheck
that earlier arithmetic construction. It also does not formalize the
subsequent pairing, primitive-recursion compiler, or bi-interpretation.

The J symbol in the certificate is just J_B for this one fixed closed binary
update B. Its second update argument is the original initializer. No free
update parameters, arbitrary evaluation oracle, or numerical program code
is admitted by this fragment.

Trusted boundary and rules
--------------------------
checker.py, Python's standard JSON implementation, and assumptions.json form
the trusted boundary. build_certificate.py is an untrusted proof producer:
its output must replay through checker.py. Certificate labels do not confer
truth. A reference can use only a previously checked theorem with exact
parameter substitution and checked proofs of every conditional premise.

The checker implements:

* Axiom instantiation of the explicitly declared equations.
* Hypothesis use only for an equation present in the retained context.
* Reflexivity, symmetry, transitivity with matching endpoints, and numerical
  congruence via a displayed term template.
* Literal-equation induction. The base and successor goals are computed by
  substitution, and the exact induction equation is added to the successor
  context. The eigenvariable must be absent from the retained assumptions,
  fixed body data, and requested target term.
* Numerical cases from the explicitly imported coverage principle, with
  the same eigenvariable checks but no induction hypothesis.
* Boolean cases solely on a term with root L, justified by its explicit
  Boolean range. Both branches must prove the identical conclusion under
  their respective checked local equations.

Each theorem is checked in its declared conditional context and is then
universally closable in its declared parameters. The final two predecessor
goals are pinned in the checker and must be unconditional; changing their
conclusions, omitting them, or making them conditional rejects.

Soundness follows by induction on the finite proof tree: each equality rule
is valid in intuitionistic first-order logic with equality; the two cases
rules are justified by the displayed positive coverage/range assumptions;
and every induction node has a literal equation as its matrix with the
checked freshness conditions. This is a small custom proof checker, not a
Lean/Rocq formalization or an independently verified implementation of that
checker.

Reproduction
------------
Run from this directory, with Python 3:

  python3 checker.py
  python3 test_certificate.py

To regenerate the proof certificate before replaying:

  python3 build_certificate.py
  python3 checker.py

checker.py reads assumptions.json and certificate.json from its own directory.
It prints a JSON receipt and exits zero on successful verification. Rejection
exits one. No network access or nonstandard Python package is required.
No assertion is used by the trusted checker; ordinary and optimized Python
both verify the delivered certificate.

test_certificate.py additionally rejects 13 explicit malformed/unsound
mutations, including a captured induction parameter, an unretained
hypothesis, a successor step deprived of its induction hypothesis, an
opposite Boolean branch, missing guard evidence, a future theorem reference,
an invented axiom, malformed arity, and altered required goals.
These negative controls test implementation boundaries; they are not a
proof of correctness for every possible malformed JSON input.

Contents
--------
checker.py               Trusted proof-rule implementation.
assumptions.json         Exact imported schemas and definitions.
certificate.json         Complete symbolic proof tree.
build_certificate.py     Untrusted certificate producer.
test_certificate.py      Focused positive and negative checks.
theorems.txt             Human-readable checked theorem statements.
verification_results.json  Complete successful verification receipt.
test_results.json        Negative-control and normal/-O CLI results.
