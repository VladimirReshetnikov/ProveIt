"""Finite equational proof checker for the anchored predecessor certificate.

Trusted theory assumptions are read explicitly from assumptions.json.  Proof
rules are equality, conditional theorem use, literal-equation induction,
numerical coverage, and the declared Boolean range of L.  This is evidence
for the predecessor fragment only, not an iPRA minimal kernel.
"""
import json
import sys
from pathlib import Path

ARITIES = {'0': 0, 'S': 1, 'L': 2, 'C': 3, 'A': 2, 'B': 2,
           'J': 2, 'V': 2, 'P': 1}


def term(value):
    if not isinstance(value, list) or not value or not isinstance(value[0], str):
        raise ValueError('Malformed term')
    tag = value[0]
    if tag == 'v':
        if len(value) != 2 or not isinstance(value[1], str) or not value[1]:
            raise ValueError('Malformed variable')
        return ('v', value[1])
    if tag not in ARITIES or len(value) != ARITIES[tag] + 1:
        raise ValueError('Unknown symbol or wrong arity')
    return (tag, *(term(x) for x in value[1:]))


def eq(value):
    if not isinstance(value, list) or len(value) != 2:
        raise ValueError('Malformed equation')
    return term(value[0]), term(value[1])


def fv(t):
    if t[0] == 'v':
        return {t[1]}
    return set().union(*(fv(x) for x in t[1:]))


def subst(t, mapping):
    if t[0] == 'v':
        return mapping.get(t[1], t)
    return (t[0], *(subst(x, mapping) for x in t[1:]))


def seq(e, mapping):
    return tuple(subst(t, mapping) for t in e)


def free_eq(e):
    return fv(e[0]) | fv(e[1])


class Checker:
    def __init__(self, assumptions):
        self.axioms = {}
        self.theorems = {}
        self.nodes = 0
        for item in assumptions['equations']:
            name = item['name']
            params = tuple(item['params'])
            equation = eq(item['equation'])
            if name in self.axioms or len(set(params)) != len(params):
                raise ValueError('Duplicate axiom or parameter')
            if not free_eq(equation) <= set(params):
                raise ValueError('Undeclared axiom parameter')
            self.axioms[name] = (params, (), equation)
        if assumptions['boolean_range'] != 'forall x y, L(x,y)=0 or L(x,y)=S(0)':
            raise ValueError('Unexpected Boolean range assumption')
        if assumptions['coverage'] != 'forall x, x=0 or exists y, x=S(y)':
            raise ValueError('Unexpected coverage assumption')

    def schema(self, source, node, context):
        params, premises, conclusion = source[node['name']]
        mapping = {name: term(value) for name, value in node['subst'].items()}
        if set(mapping) != set(params):
            raise ValueError('Schema substitution must supply exactly the parameters')
        proofs = node.get('premises', [])
        if len(proofs) != len(premises):
            raise ValueError('Wrong number of conditional theorem premises')
        for required, proof in zip(premises, proofs):
            if self.prove(proof, context) != seq(required, mapping):
                raise ValueError('Conditional theorem premise mismatch')
        return seq(conclusion, mapping)

    def prove(self, node, context=()):
        self.nodes += 1
        rule = node['r']
        if rule == 'axiom':
            return self.schema(self.axioms, node, context)
        if rule == 'use':
            return self.schema(self.theorems, node, context)
        if rule == 'hyp':
            equation = eq(node['equation'])
            if equation not in context:
                raise ValueError('Hypothesis not present in the current context')
            return equation
        if rule == 'refl':
            t = term(node['term'])
            return t, t
        if rule == 'sym':
            left, right = self.prove(node['proof'], context)
            return right, left
        if rule == 'trans':
            first = self.prove(node['proofs'][0], context)
            left, current = first
            for proof in node['proofs'][1:]:
                old, new = self.prove(proof, context)
                if current != old:
                    raise ValueError('Transitivity endpoints do not agree')
                current = new
            return left, current
        if rule == 'cong':
            left, right = self.prove(node['proof'], context)
            template = term(node['template'])
            hole = node['hole']
            if not isinstance(hole, str):
                raise ValueError('Bad congruence placeholder')
            return subst(template, {hole: left}), subst(template, {hole: right})
        if rule in ('ind', 'cases'):
            variable, fresh = node['variable'], node['fresh']
            body, target = eq(node['body']), term(node['target'])
            occupied = free_eq(body) | fv(target)
            for assumption in context:
                occupied |= free_eq(assumption)
            if (not isinstance(variable, str) or not isinstance(fresh, str)
                    or fresh in occupied or variable == fresh):
                raise ValueError('Eigenvariable is not fresh for retained data')
            base = seq(body, {variable: ('0',)})
            if self.prove(node['base'], context) != base:
                raise ValueError('Incorrect base/case-zero conclusion')
            local = ('v', fresh)
            successor = seq(body, {variable: ('S', local)})
            step_context = context
            if rule == 'ind':
                step_context += (seq(body, {variable: local}),)
            if self.prove(node['step'], step_context) != successor:
                raise ValueError('Incorrect successor conclusion')
            return seq(body, {variable: target})
        if rule == 'bool_cases':
            test, conclusion = term(node['test']), eq(node['conclusion'])
            if test[0] != 'L':
                raise ValueError('Boolean split is allowed only for the declared L range')
            zero, one = ('0',), ('S', ('0',))
            if self.prove(node['zero'], context + ((test, zero),)) != conclusion:
                raise ValueError('Boolean zero branch concludes the wrong equation')
            if self.prove(node['one'], context + ((test, one),)) != conclusion:
                raise ValueError('Boolean one branch concludes the wrong equation')
            return conclusion
        raise ValueError('Unknown proof rule: ' + str(rule))

    def theorem(self, item):
        name, params = item['name'], tuple(item['params'])
        if name in self.theorems or name in self.axioms or len(set(params)) != len(params):
            raise ValueError('Duplicate theorem or parameter')
        premises = tuple(eq(x) for x in item.get('assumptions', []))
        expected = eq(item['conclusion'])
        all_free = free_eq(expected)
        for premise in premises:
            all_free |= free_eq(premise)
        if not all_free <= set(params):
            raise ValueError('Undeclared theorem parameter')
        before = self.nodes
        observed = self.prove(item['proof'], premises)
        if observed != expected:
            raise ValueError('Theorem conclusion differs from checked proof')
        self.theorems[name] = params, premises, expected
        return {'name': name, 'proof_nodes': self.nodes - before,
                'conditional_premises': len(premises), 'verified': True}


def verify(assumptions, certificate):
    checker = Checker(assumptions)
    results = [checker.theorem(item) for item in certificate['theorems']]
    zero, parameter = ('0',), ('v', 'm')
    required = {
        'P_zero': ((), (), (('P', zero), zero)),
        'P_successor': (('m',), (), (('P', ('S', parameter)), parameter)),
    }
    for name, expected in required.items():
        if checker.theorems.get(name) != expected:
            raise ValueError('Missing or altered required unconditional goal: ' + name)
    return {'verified': True, 'theorems': results,
            'total_checked_nodes': checker.nodes,
            'assumptions': [item['name'] for item in assumptions['equations']],
            'logical_principles': ['equality', 'literal-equation induction',
                                   'numerical coverage', 'Boolean range of L'],
            'scope': 'Anchored predecessor fragment; comparator and selector axioms explicit.'}


if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    try:
        assumptions = json.loads((root / 'assumptions.json').read_text())
        certificate = json.loads((root / 'certificate.json').read_text())
        print(json.dumps(verify(assumptions, certificate), indent=2))
    except Exception as error:
        print(json.dumps({'verified': False, 'error': str(error)}))
        raise SystemExit(1)
