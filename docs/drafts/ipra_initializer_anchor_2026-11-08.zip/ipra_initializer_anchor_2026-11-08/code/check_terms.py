"""Finite diagnostics for the anchored-iteration research article.

Run `python3 code/check_terms.py` from the package directory.  The output is
results/term_checks.json.  Two deliberately separate sections are reported:

1. Fully expanded syntax, evaluated using only the four constructors from
   anchor_terms.py.  There are NO hidden implementations of its macros.
2. Faster arithmetic-level standard-N examples, using Python comparison,
   addition, multiplication, and truncated subtraction where explicitly
   stated.  These check finite examples of algorithms, not proof derivations.

Neither section verifies a proof checker, consistency, internal derivability,
nonstandard models, or the bi-interpretation theorem.  Those are mathematical
claims whose arguments are given in the article.
"""

from __future__ import annotations

import argparse
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path
import platform
import time

from anchor_terms import Arena, Arithmetic, Evaluator


def run_expanded() -> dict:
    arena = Arena()
    ar = Arithmetic(arena)
    ev = Evaluator(arena)
    x, y = arena.Var(0), arena.Var(1)
    observations: list[dict] = []
    checks = 0

    def expect(label, term, env, expected):
        nonlocal checks
        actual = ev.evaluate(term, tuple(env))
        if actual != expected:
            raise AssertionError(f"{label}{tuple(env)}: {actual} != {expected}")
        checks += 1
        return actual

    for value in range(7):
        expect("parity", ar.N(x), [value], value % 2)
        expect("mod_three", ar.M(x), [value], value % 3)
        expect("ramp", ar.G(x), [value], (3 * value) // 2)
        expect("factor", ar.H(x), [value], value if value % 2 else (3 * value) // 2)
    for value in range(5):
        expect("power_two", ar.E(x), [value], 2 ** value)
    for left in range(5):
        for right in range(5):
            expect("comparator", ar.L(x, y), [left, right], int(left <= right))
    for test in range(3):
        for left in range(3):
            for right in range(3):
                expect("selector", ar.C(x, y, arena.Var(2)), [test, left, right], left if test == 0 else right)

    predecessor_values = []
    for value in range(5):
        predecessor_values.append(expect("predecessor", ar.P(x), [value], max(value - 1, 0)))
    observations.append({"name": "expanded_predecessor", "inputs": list(range(5)), "values": predecessor_values})

    # The two defining equations are checked directly for several programs.
    for name in ("zero", "successor", "parity", "summand", "predecessor"):
        program = ar.programs[name]
        for initial in range(3):
            if ev.iterate(program, 0, initial) != initial:
                raise AssertionError("J0 failed")
            checks += 1
            for counter in range(3):
                left = ev.iterate(program, counter + 1, initial)
                right = ev.evaluate(program, (ev.iterate(program, counter, initial), initial))
                if left != right:
                    raise AssertionError("JS failed")
                checks += 1

    # A nested program's formal slot 1 is not the caller's free variable 1.
    original = arena.J(ar.programs["summand"], x, y)
    changed = arena.substitute(original, {1: arena.numeral(3)})
    if arena.nodes[changed][1] != ar.programs["summand"]:
        raise AssertionError("Substitution rewrote a closed program")
    expect("scope_preservation", changed, [2], 9)
    closure_rejections = 0
    try:
        arena.J(arena.Var(2), ar.zero, ar.zero)
    except ValueError:
        closure_rejections += 1
    else:
        raise AssertionError("A captured outer variable was accepted")
    try:
        ev.evaluate(arena.Var(3), (0, 1))
    except ValueError:
        closure_rejections += 1
    else:
        raise AssertionError("An unbound variable was accepted")

    # An actual expanded packed-parameter example.  h(u,c)=Z(c), a=0,c=1.
    # The state remains zero, while the nonzero parameter is read and retained.
    # Keeping the encoded state at pair(0,1)=1 avoids enormous diagnostic values.
    output, packed = ar.compile_one_parameter(ar.Z(y), x, ar.zero, ar.one)
    packed_examples = []
    for counter in range(3):
        result = expect("packed_output", output, [counter], 0)
        parameter = expect("packed_parameter", ar.second(packed), [counter], 1)
        packed_examples.append({"counter": counter, "output": result, "parameter": parameter})
    observations.append({"name": "expanded_packed_parameter", "update": "h(u,c)=Z(c)", "initial": 0, "parameter": 1, "runs": packed_examples})

    # This counterexample detects an incorrect transfer of unary rotation to
    # all anchored updates: changing the initializer changes the anchor.
    summand = ar.programs["summand"]
    rotation_left = ev.iterate(summand, 2, 3)
    rotation_right = ev.iterate(summand, 1, ev.evaluate(summand, (3, 3)))
    if (rotation_left, rotation_right) != (9, 12):
        raise AssertionError("The anchor-change counterexample is wrong")
    observations.append({"name": "changed_anchor_rotation_counterexample", "left": rotation_left, "right": rotation_right, "equal": False})

    validation = arena.validate()
    return {
        "status": "passed",
        "kind": "fully_expanded_definitional_evaluation",
        "checks": checks,
        "intentional_invalid_inputs_rejected": closure_rejections,
        "syntax_validation": validation,
        "named_program_free_slots": {name: sorted(arena.free_variables(term)) for name, term in ar.programs.items()},
        "evaluator": ev.cache_statistics(),
        "observations": observations,
        "limitations": "Finite standard-natural-number evaluation only; no proof certificates or proof-checker correctness claim.",
    }


def anchored(update, counter, initial):
    """Direct numerical J, preserving exactly one immutable initializer."""
    state = initial
    for _ in range(counter):
        state = update(state, initial)
    return state


@lru_cache(maxsize=None)
def numeric_predecessor(number):
    # Deliberate arithmetic-level shortcut: L(x,y) is Python's comparison.
    def update(state, anchor):
        if state + 1 > anchor:
            return 0
        return state + 1 if state + 2 <= anchor else state
    return anchored(update, number + 1, number)


@lru_cache(maxsize=None)
def numeric_root(number):
    # Comparison, successor, square, and the proven predecessor are numerical
    # implementations here.  The reset and iteration themselves remain explicit.
    def update(state, anchor):
        if state + 1 > anchor:
            return 0
        bound = numeric_predecessor(anchor)
        return state + 1 if (state + 1) ** 2 <= bound else state
    return anchored(update, number + 1, number + 1)


def numeric_pair(left, right):
    return (left + right) ** 2 + left


def numeric_first(code):
    return max(code - numeric_root(code) ** 2, 0)


def numeric_second(code):
    return max(numeric_root(code) - numeric_first(code), 0)


def numeric_compiled(update, counter, initial, parameter):
    def packed_update(code, ignored_anchor):
        value, retained = numeric_first(code), numeric_second(code)
        return numeric_pair(update(value, retained), retained)
    code = anchored(packed_update, counter, numeric_pair(initial, parameter))
    return numeric_first(code), numeric_second(code)


def run_numeric() -> dict:
    pred_cases, root_cases, pair_cases, compiled_cases = 0, 0, 0, 0
    for number in range(65):
        if numeric_predecessor(number) != max(number - 1, 0):
            raise AssertionError("Numerical predecessor mismatch")
        pred_cases += 1
    for number in range(257):
        if numeric_root(number) != math.isqrt(number):
            raise AssertionError("Numerical root mismatch")
        root_cases += 1
    for left in range(13):
        for right in range(13):
            code = numeric_pair(left, right)
            if (numeric_first(code), numeric_second(code)) != (left, right):
                raise AssertionError("Numerical pairing mismatch")
            pair_cases += 1
    for initial in range(4):
        for parameter in range(4):
            for counter in range(6):
                result = numeric_compiled(lambda state, retained: state + retained, counter, initial, parameter)
                if result != (initial + counter * parameter, parameter):
                    raise AssertionError("Numerical compiled parameter mismatch")
                compiled_cases += 1
    return {
        "status": "passed",
        "kind": "arithmetic_level_standard_N_diagnostics",
        "intentional_shortcuts": ["L interpreted by integer comparison", "integer addition and multiplication", "truncated subtraction interpreted by max(x-y,0)"],
        "predecessor": {"inputs": "0..64", "cases": pred_cases},
        "root": {"inputs": "0..256", "cases": root_cases, "independent_oracle": "math.isqrt"},
        "pairing": {"each_coordinate": "0..12", "cases": pair_cases},
        "compiled_parameter": {"update": "h(u,c)=u+c", "initial": "0..3", "parameter": "0..3", "counter": "0..5", "cases": compiled_cases},
        "limitations": "These use faster intended arithmetic meanings, not expanded object-language evaluation. They do not prove symbolic identities or results in nonstandard models.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "results" / "term_checks.json")
    args = parser.parse_args()
    started = time.monotonic()
    result = {
        "artifact_type": "supporting_executable_diagnostics_not_a_proof_checker",
        "python": platform.python_version(),
        "expanded": run_expanded(),
        "arithmetic_level": run_numeric(),
    }
    result["elapsed_seconds"] = round(time.monotonic() - started, 3)
    result["source_sha256"] = {
        name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
        for name in ("anchor_terms.py", "check_terms.py")
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "passed", "output": str(args.output), "expanded_checks": result["expanded"]["checks"], "elapsed_seconds": result["elapsed_seconds"]}))


if __name__ == "__main__":
    main()
