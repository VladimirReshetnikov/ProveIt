"""Executable syntax and a definitional evaluator for anchored iteration.

This is a supporting executable model, NOT a proof checker and NOT a formal
verification of the article.  The abstract syntax is

    Var(index) | Zero | Succ(term) | J(program, counter, initializer).

Every program is an ordinary term whose free variables are drawn from the two
formal slots 0 (current state) and 1 (original initializer).  A nested J starts
a fresh program scope.  Ordinary substitution traverses a J's two argument
terms, but leaves its program untouched.  Programs are syntax, not numerical
codes available inside the object language.

The arena hash-conses this syntax into an acyclic directed graph.  Macro
builders below expand into this grammar; the evaluator knows no macro names
and has no arithmetic shortcuts.  It implements J0 and JS by finite iteration,
memoizing expression values and already computed iteration prefixes.  When a
positive iteration's program has no free variables at all, one JS contraction
erases both arguments, so the evaluator evaluates that closed program without
forcing its unused initializer.  This generic syntax-directed erasure avoids
evaluating an unselected branch in the expanded numerical selector.  Resource
limits bound diagnostics rather than adding an object-language principle.

The separate direct-number diagnostics in check_terms.py deliberately use
ordinary integer arithmetic.  They must not be confused with this evaluator.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping


Term = int


class Arena:
    """Hash-consed representation of exactly the grammar in the module header."""

    def __init__(self) -> None:
        self.nodes: list[tuple] = []
        self._intern: dict[tuple, Term] = {}
        self._free: dict[Term, frozenset[int]] = {}

    def _make(self, node: tuple) -> Term:
        if node not in self._intern:
            self._intern[node] = len(self.nodes)
            self.nodes.append(node)
        return self._intern[node]

    def _known(self, term: Term) -> None:
        if type(term) is not int or not 0 <= term < len(self.nodes):
            raise ValueError("A term reference must identify an existing node")

    def Var(self, index: int) -> Term:
        if type(index) is not int or index < 0:
            raise ValueError("Variable indices are nonnegative integers")
        return self._make(("var", index))

    def Zero(self) -> Term:
        return self._make(("zero",))

    def Succ(self, value: Term) -> Term:
        self._known(value)
        return self._make(("succ", value))

    def J(self, program: Term, counter: Term, initializer: Term) -> Term:
        for term in (program, counter, initializer):
            self._known(term)
        if not self.free_variables(program) <= {0, 1}:
            raise ValueError("An update may use only state slot 0 and anchor slot 1")
        return self._make(("J", program, counter, initializer))

    def numeral(self, number: int) -> Term:
        if type(number) is not int or number < 0:
            raise ValueError("A numeral must be a nonnegative integer")
        result = self.Zero()
        for _ in range(number):
            result = self.Succ(result)
        return result

    def free_variables(self, term: Term) -> frozenset[int]:
        self._known(term)
        if term not in self._free:
            node = self.nodes[term]
            if node[0] == "var":
                answer = frozenset({node[1]})
            elif node[0] == "zero":
                answer = frozenset()
            elif node[0] == "succ":
                answer = self.free_variables(node[1])
            else:
                # The program has a new scope, independent of the caller.
                answer = self.free_variables(node[2]) | self.free_variables(node[3])
            self._free[term] = answer
        return self._free[term]

    def substitute(self, term: Term, replacements: Mapping[int, Term]) -> Term:
        """Simultaneous substitution of free variables; never rewrite programs."""
        for index, value in replacements.items():
            if type(index) is not int or index < 0:
                raise ValueError("Invalid substitution index")
            self._known(value)
        memo: dict[Term, Term] = {}

        def visit(current: Term) -> Term:
            if current in memo:
                return memo[current]
            node = self.nodes[current]
            if node[0] == "var":
                answer = replacements.get(node[1], current)
            elif node[0] == "zero":
                answer = current
            elif node[0] == "succ":
                answer = self.Succ(visit(node[1]))
            else:
                answer = self.J(node[1], visit(node[2]), visit(node[3]))
            memo[current] = answer
            return answer

        return visit(term)

    def validate(self) -> dict[str, int]:
        """Check acyclicity, constructor shapes, and every nested closure."""
        programs: set[Term] = set()
        for index, node in enumerate(self.nodes):
            tag = node[0]
            if tag == "var":
                if len(node) != 2 or type(node[1]) is not int or node[1] < 0:
                    raise ValueError("Malformed variable")
                children = ()
            elif tag == "zero":
                if len(node) != 1:
                    raise ValueError("Malformed zero")
                children = ()
            elif tag == "succ":
                if len(node) != 2:
                    raise ValueError("Malformed successor")
                children = (node[1],)
            elif tag == "J":
                if len(node) != 4:
                    raise ValueError("Malformed iteration")
                children = node[1:]
                programs.add(node[1])
                if not self.free_variables(node[1]) <= {0, 1}:
                    raise ValueError("A program captures an outer variable")
            else:
                raise ValueError("Unknown syntax constructor")
            if any(type(child) is not int or not 0 <= child < index for child in children):
                raise ValueError("The syntax graph is not properly staged and acyclic")
        return {"syntax_nodes": len(self.nodes), "distinct_programs": len(programs)}


class Arithmetic:
    """The article's macros, expanded entirely to Arena's four constructors."""

    def __init__(self, arena: Arena) -> None:
        self.a = arena
        self.zero = arena.Zero()
        self.one = arena.Succ(self.zero)
        state, anchor = arena.Var(0), arena.Var(1)
        self.programs: dict[str, Term] = {}
        self.programs["zero"] = self.zero
        self.programs["successor"] = arena.Succ(state)
        self.programs["parity"] = self.Z(state)
        self.programs["mod_three"] = self.add(self.add(self.Z(state), self.N(state)), self.N(state))
        self.programs["ramp"] = arena.Succ(self.add(state, self.M(state)))
        self.programs["factor"] = self.C(self.N(state), self.G(state), state)
        self.programs["double"] = self.add(state, state)
        self.programs["predecessor"] = self.B(state, anchor)
        self.programs["subtract"] = self.P(state)
        self.programs["summand"] = self.add(state, anchor)
        self.programs["root"] = self.C(
            self.ell(arena.Succ(state), anchor), self.zero,
            self.U(state, self.P(anchor)),
        )

    def add(self, left: Term, right: Term) -> Term:
        return self.a.J(self.programs["successor"], right, left)

    def Z(self, number: Term) -> Term:
        return self.a.J(self.programs["zero"], number, self.one)

    def C(self, test: Term, at_zero: Term, at_successor: Term) -> Term:
        return self.add(
            self.a.J(self.programs["zero"], test, at_zero),
            self.a.J(self.programs["zero"], self.Z(test), at_successor),
        )

    def N(self, number: Term) -> Term:
        return self.a.J(self.programs["parity"], number, self.zero)

    def M(self, number: Term) -> Term:
        return self.a.J(self.programs["mod_three"], number, self.zero)

    def G(self, number: Term) -> Term:
        return self.a.J(self.programs["ramp"], number, self.zero)

    def H(self, number: Term) -> Term:
        return self.C(self.N(number), self.G(number), number)

    def E(self, number: Term) -> Term:
        return self.a.J(self.programs["double"], number, self.one)

    def L(self, left: Term, right: Term) -> Term:
        return self.N(self.a.J(self.programs["factor"], right, self.E(left)))

    def A(self, state: Term, anchor: Term) -> Term:
        return self.C(self.L(self.a.Succ(self.a.Succ(state)), anchor), state, self.a.Succ(state))

    def B(self, state: Term, anchor: Term) -> Term:
        return self.C(self.L(self.a.Succ(state), anchor), self.zero, self.A(state, anchor))

    def V(self, counter: Term, anchor: Term) -> Term:
        return self.a.J(self.programs["predecessor"], self.a.Succ(counter), anchor)

    def P(self, number: Term) -> Term:
        return self.V(number, number)

    def d(self, left: Term, right: Term) -> Term:
        return self.a.J(self.programs["subtract"], right, left)

    def mul(self, left: Term, right: Term) -> Term:
        return self.d(self.a.J(self.programs["summand"], right, left), left)

    def square(self, number: Term) -> Term:
        return self.mul(number, number)

    def ell(self, left: Term, right: Term) -> Term:
        return self.Z(self.d(left, right))

    def U(self, state: Term, bound: Term) -> Term:
        return self.C(self.ell(self.square(self.a.Succ(state)), bound), state, self.a.Succ(state))

    def W(self, counter: Term, bound: Term) -> Term:
        return self.a.J(self.programs["root"], self.a.Succ(counter), self.a.Succ(bound))

    def root(self, number: Term) -> Term:
        return self.W(number, number)

    def pair(self, left: Term, right: Term) -> Term:
        return self.add(self.square(self.add(left, right)), left)

    def first(self, code: Term) -> Term:
        return self.d(code, self.square(self.root(code)))

    def second(self, code: Term) -> Term:
        return self.d(self.root(code), self.first(code))

    def compile_one_parameter(self, update: Term, counter: Term, initial: Term, parameter: Term) -> tuple[Term, Term]:
        """Compile h(state,parameter), returning (output, final packed state)."""
        if not self.a.free_variables(update) <= {0, 1}:
            raise ValueError("This demonstration compiler takes one state and one parameter")
        packed = self.a.Var(0)
        body = self.a.substitute(update, {0: self.first(packed), 1: self.second(packed)})
        program = self.pair(body, self.second(packed))
        state = self.a.J(program, counter, self.pair(initial, parameter))
        return self.first(state), state


class ResourceLimit(RuntimeError):
    pass


@dataclass
class EvaluationStats:
    expression_cache_misses: int = 0
    iteration_steps: int = 0
    closed_program_erasures: int = 0
    maximum_value: int = 0


class Evaluator:
    """Interpret only Var, Zero, Succ, and J, with explicit resource bounds."""

    def __init__(self, arena: Arena, *, max_steps: int = 8_000_000, max_value: int = 1_000_000) -> None:
        self.arena = arena
        self.max_steps = max_steps
        self.max_value = max_value
        self.stats = EvaluationStats()
        self._values: dict[tuple[Term, tuple[int, ...]], int] = {}
        self._prefixes: dict[tuple[Term, int], list[int]] = {}

    def _number(self, value: int) -> int:
        if type(value) is not int or value < 0:
            raise ValueError("The numerical semantics uses nonnegative integers")
        if value > self.max_value:
            raise ResourceLimit(f"Diagnostic value limit exceeded: {value}")
        self.stats.maximum_value = max(self.stats.maximum_value, value)
        return value

    def evaluate(self, term: Term, environment: tuple[int, ...] = ()) -> int:
        environment = tuple(self._number(value) for value in environment)
        free = tuple(sorted(self.arena.free_variables(term)))
        if free and free[-1] >= len(environment):
            raise ValueError("The environment omits a free variable")
        key = (term, tuple(environment[index] for index in free))
        if key in self._values:
            return self._values[key]
        self.stats.expression_cache_misses += 1
        if self.stats.expression_cache_misses + self.stats.iteration_steps > self.max_steps:
            raise ResourceLimit("Diagnostic evaluation budget exceeded")
        node = self.arena.nodes[term]
        if node[0] == "var":
            result = environment[node[1]]
        elif node[0] == "zero":
            result = 0
        elif node[0] == "succ":
            result = self._number(self.evaluate(node[1], environment) + 1)
        else:
            counter = self.evaluate(node[2], environment)
            if counter > 0 and not self.arena.free_variables(node[1]):
                # JS replaces J_h(Sn,a) by h(J_h(n,a),a).  If neither
                # formal variable occurs in h, this is simply the closed h.
                # This is a generic definitional contraction, not a macro.
                self.stats.closed_program_erasures += 1
                result = self.evaluate(node[1], ())
            else:
                initial = self.evaluate(node[3], environment)
                result = self.iterate(node[1], counter, initial)
        self._values[key] = result
        return result

    def iterate(self, program: Term, counter: int, initial: int) -> int:
        counter, initial = self._number(counter), self._number(initial)
        if not self.arena.free_variables(program) <= {0, 1}:
            raise ValueError("The program is not closed over its two formal slots")
        values = self._prefixes.setdefault((program, initial), [initial])
        while len(values) <= counter:
            self.stats.iteration_steps += 1
            if self.stats.expression_cache_misses + self.stats.iteration_steps > self.max_steps:
                raise ResourceLimit("Diagnostic evaluation budget exceeded")
            # The immutable anchor is initial, never the current state.
            values.append(self.evaluate(program, (values[-1], initial)))
        return values[counter]

    def cache_statistics(self) -> dict[str, int]:
        return {
            **vars(self.stats),
            "cached_expression_values": len(self._values),
            "cached_iteration_prefixes": len(self._prefixes),
            "cached_iteration_values": sum(map(len, self._prefixes.values())),
        }
