ELIMINATING CAPTURED PARAMETERS FROM AN iPRA PRESENTATION
======================================================
Prepared for Vladimir Reshetnikov, November 8, 2026.

MAIN RESULT
-----------
A complete mathematical proof that full first-order intuitionistic primitive
recursive arithmetic is bi-interpretable with an arithmetic theory whose
fixed update descriptions see only their current state and original
initializer:

    J_h(0,a) = a
    J_h(Sn,a) = h(J_h(n,a),a).

Updates cannot capture independent ambient numerical parameters. Numerical
substitution never enters an update description. The new reset construction
gives predecessor using literal-equation induction before order, successor
injectivity, or pairing is available. Pair coding then compiles every fixed
primitive recursion. Both whole-domain interpretation composites are the
identity, internally in the respective theories.

STATUS OF THE REQUESTED MINIMUM
-------------------------------
The structural arithmetic restriction and theory equivalence are proved.
A strict improvement in complete proof-checker size is NOT established.
The current twelve-archive corpus has minima 317 normalized Python tokens,
348 AST nodes, and 885 normalized bytes, attained by different programs.
The full minimization request remains unresolved. This package does not
claim an absolute simplestness result or historical priority.

START HERE
----------
ipra_initializer_anchor.pdf   Complete research article.
ipra_initializer_anchor.tex   Main LaTeX source.
sections/                    All mathematical sections and appendices.

REPRODUCIBLE EVIDENCE
--------------------
code/predecessor_certificate/ Complete symbolic proof of the new predecessor
                             relative to explicit comparator/selector facts:
                             15 checked theorems, 175 proof nodes.
code/anchor_terms.py          Closed update syntax, expansions, and evaluator.
code/check_terms.py           157 expanded checks; 587 arithmetic-level cases.
code/measure_baselines.py     Reproduce all twelve current source comparisons.
code/source_measure.py        Unchanged inherited measurement routine.
reference/baselines/          Pinned source copies, not a new claimed checker.
reference/baseline_manifest.json  Commit and source/archive hashes.
results/                     Recorded measurements and diagnostic receipts.
experiments/                 Progression-closure and direct anchored-checker
                             experiments; neither is a size winner or a
                             dependency of the main proof.
SHA256SUMS.txt                Checksums of the delivered package files.

Run from this directory (Python 3.10+, standard library only):

    python3 code/measure_baselines.py
    python3 code/predecessor_certificate/checker.py
    python3 code/predecessor_certificate/test_certificate.py
    python3 code/check_terms.py

The source counts were measured on CPython 3.12.14. Other AST/unparser
versions may produce different normalized counts.

Build the PDF with:

    latexmk -pdf -halt-on-error -interaction=nonstopmode ipra_initializer_anchor.tex

BOUNDARIES
----------
The custom predecessor checker has an explicit trusted assumptions file and
does not formalize the comparator construction, pairing, or full
bi-interpretation. Its finite proof certificate is distinct from the numeric
tests. The latter are standard-natural-number diagnostics, with fully
expanded and faster arithmetic-level modes separately labelled. No full
Lean/Rocq formalization or new record-size native checker is claimed.

PROVENANCE
----------
The current ProveIt docs/drafts snapshot is
06e097f723c659030816e0194e5eb7e8c607ba9b.
All twelve ZIP files were checked against the Git blob hashes supplied by
GitHub. Inherited source and documentation are covered by the repository's
MIT No Attribution license, preserved in reference/PROVEIT_LICENSE.txt.
The report identifies inherited ingredients and the new anchored argument.
