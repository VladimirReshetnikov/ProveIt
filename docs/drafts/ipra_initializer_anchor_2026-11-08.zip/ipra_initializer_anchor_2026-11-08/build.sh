#!/bin/sh
set -eu
cd "$(dirname "$0")"
latexmk -pdf -halt-on-error -interaction=nonstopmode ipra_initializer_anchor.tex
