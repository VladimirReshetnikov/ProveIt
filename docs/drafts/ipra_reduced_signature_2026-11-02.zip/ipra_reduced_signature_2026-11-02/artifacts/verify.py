#!/usr/bin/env python3
"""Independent syntax and finite-diagnostic checker for the iPRA report.

Run with Python 3.10+; only the standard library is used.  The output is
artifacts/checks.json beside this script.  This checks finite syntax, exact
counts, translation invariants on an explicit finite sample, and bounded
standard-natural-number diagnostics.  It is NOT a formal proof of the
theory's interpretation, induction, or bi-interpretability theorems.

Descriptors are immutable trees.  Active substitution and normalization
never enter them.  Symbol compilation explicitly translates each stored
body bottom-up, then normalizes that body; application arguments are mapped
homomorphically.  In particular, computation axioms are NOT normalized to
tautologies by evaluating their active applications.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import cache
from pathlib import Path
import json
import math
import random


@dataclass(frozen=True)
class Term:
    tag: str
    args: tuple["Term", ...] = ()
    descriptor: "Term | None" = None
    name: str | None = None


@dataclass(frozen=True)
class Formula:
    tag: str
    parts: tuple["Formula | Term", ...] = ()
    binder: str | None = None


def var(name: str) -> Term:
    return Term("var", name=name)


zero = Term("zero")
v, w = var("v"), var("w")
a, n, u, x, y, z, b = (var(s) for s in ("a", "n", "u", "x", "y", "z", "b"))


def succ(t: Term) -> Term:
    return Term("S", (t,))


def pair(s: Term, t: Term) -> Term:
    return Term("B", (s, t))


def left(t: Term) -> Term:
    return Term("L", (t,))


def right(t: Term) -> Term:
    return Term("R", (t,))


def rec(h: Term, counter: Term, initial: Term) -> Term:
    return Term("rec", (counter, initial), descriptor=h)


def q(counter: Term, initial: Term) -> Term:
    return rec(w, counter, initial)


def zz(counter: Term, initial: Term) -> Term:
    return rec(zero, counter, initial)


def pred(t: Term) -> Term:
    return q(t, zero)


def select(counter: Term, initial: Term, other: Term) -> Term:
    return q(zz(counter, succ(initial)), other)


def eq(s: Term, t: Term) -> Formula:
    return Formula("=", (s, t))


bottom = Formula("bottom")


def conn(tag: str, *parts: Formula) -> Formula:
    return Formula(tag, tuple(parts))


def conjunction(*parts: Formula) -> Formula:
    assert parts
    ans = parts[-1]
    for part in reversed(parts[:-1]):
        ans = conn("and", part, ans)
    return ans


def implies(p: Formula, q_: Formula) -> Formula:
    return conn("implies", p, q_)


def quantify(tag: str, names: tuple[str, ...], body: Formula) -> Formula:
    for name in reversed(names):
        body = Formula(tag, (body,), binder=name)
    return body


def forall(names: tuple[str, ...], body: Formula) -> Formula:
    return quantify("forall", names, body)


def exists(names: tuple[str, ...], body: Formula) -> Formula:
    return quantify("exists", names, body)


@cache
def term_size(t: Term) -> int:
    return 1 + sum(term_size(p) for p in t.args) + (
        term_size(t.descriptor) if t.descriptor is not None else 0
    )


@cache
def formula_size(f: Formula) -> int:
    return 1 + sum(
        term_size(p) if isinstance(p, Term) else formula_size(p) for p in f.parts
    )


@cache
def active_free(t: Term) -> frozenset[str]:
    if t.tag == "var":
        assert t.name is not None
        return frozenset((t.name,))
    return frozenset().union(*(active_free(p) for p in t.args))


def formula_free(f: Formula) -> frozenset[str]:
    ans = frozenset().union(*(
        active_free(p) if isinstance(p, Term) else formula_free(p) for p in f.parts
    ))
    return ans - {f.binder} if f.binder is not None else ans


def active_substitute(t: Term, substitution: dict[str, Term]) -> Term:
    """Simultaneous active substitution; preserve every stored descriptor."""
    if t.tag == "var":
        return substitution.get(t.name, t)
    return Term(
        t.tag,
        tuple(active_substitute(p, substitution) for p in t.args),
        t.descriptor,
        t.name,
    )


def all_formula_variable_names(f: Formula) -> set[str]:
    names = set(formula_free(f))
    if f.binder is not None:
        names.add(f.binder)
    for p in f.parts:
        if isinstance(p, Formula):
            names.update(all_formula_variable_names(p))
    return names


def formula_substitute(f: Formula, substitution: dict[str, Term]) -> Formula:
    """Capture-avoiding substitution, including alpha-renaming when required."""
    if f.binder is not None:
        assert len(f.parts) == 1 and isinstance(f.parts[0], Formula)
        inner = f.parts[0]
        pending = {key: value for key, value in substitution.items() if key != f.binder}
        binder = f.binder
        needed = formula_free(inner) & pending.keys()
        replacement_free = frozenset().union(*(active_free(pending[k]) for k in needed))
        if binder in replacement_free:
            avoid = all_formula_variable_names(inner) | set(pending) | set(replacement_free)
            serial = 0
            fresh = f"{binder}_{serial}"
            while fresh in avoid:
                serial += 1
                fresh = f"{binder}_{serial}"
            inner = formula_substitute(inner, {binder: var(fresh)})
            binder = fresh
        return Formula(f.tag, (formula_substitute(inner, pending),), binder=binder)
    return Formula(f.tag, tuple(
        active_substitute(p, substitution) if isinstance(p, Term)
        else formula_substitute(p, substitution) for p in f.parts
    ))


@cache
def dependency_rank(t: Term) -> int:
    """Maximum finite symbol-dependency rank occurring in a term."""
    child_rank = max((dependency_rank(p) for p in t.args), default=0)
    if t.descriptor is None:
        return child_rank
    return max(child_rank, 1 + dependency_rank(t.descriptor))


@cache
def normalize_active(t: Term) -> Term:
    """N: bottom-up active R_g(0,t)->t and Q(Su,t)->u only."""
    children = tuple(normalize_active(p) for p in t.args)
    result = Term(t.tag, children, t.descriptor, t.name)
    if result.tag == "rec":
        counter, initial = result.args
        if counter == zero:
            return initial
        if result.descriptor == w and counter.tag == "S":
            return counter.args[0]
    return result


@cache
def canonical_body(h: Term) -> Term:
    return normalize_active(translate_term(h))


@cache
def translate_term(t: Term) -> Term:
    """Sigma on terms; application arguments are mapped homomorphically."""
    children = tuple(translate_term(p) for p in t.args)
    if t.tag == "rec":
        assert t.descriptor is not None
        g = canonical_body(t.descriptor)
        if g == v:
            return children[1]
        return rec(g, children[0], children[1])
    return Term(t.tag, children, t.descriptor, t.name)


def translate_formula(f: Formula) -> Formula:
    return Formula(f.tag, tuple(
        translate_term(p) if isinstance(p, Term) else translate_formula(p)
        for p in f.parts
    ), binder=f.binder)


@cache
def descriptors_canonical(t: Term) -> bool:
    if not all(descriptors_canonical(p) for p in t.args):
        return False
    if t.descriptor is None:
        return True
    g = t.descriptor
    return (
        active_free(g) <= {"v", "w"}
        and g != v
        and canonical_body(g) == g
        and descriptors_canonical(g)
    )


def profile(h: Term) -> tuple[int, int, int, int]:
    """Full H, active v count, active S(w) count, residual active w count."""
    if h == succ(w):
        return term_size(h), 0, 1, 0
    if h.tag == "var":
        return term_size(h), int(h == v), 0, int(h == w)
    sub = [profile(p) for p in h.args]
    return term_size(h), sum(p[1] for p in sub), sum(p[2] for p in sub), sum(p[3] for p in sub)


def dagger(h: Term, state: Term, residual: Term, current: Term) -> Term:
    if h == succ(w):
        return current
    if h == v:
        return state
    if h == w:
        return residual
    return Term(h.tag, tuple(dagger(p, state, residual, current) for p in h.args), h.descriptor, h.name)


def modules(h: Term) -> dict[str, tuple[Formula, ...]]:
    ordinary = (
        forall(("a",), eq(rec(h, zero, a), a)),
        forall(("a", "n"), eq(rec(h, succ(n), a), active_substitute(h, {"v": rec(h, n, a), "w": n}))),
    )
    graph = forall(("a", "n", "u"), conn("K3",
        conjunction(eq(n, zero), eq(u, a)),
        eq(rec(h, n, a), u),
        eq(rec(h, succ(n), a), active_substitute(h, {"v": u, "w": n})),
    ))
    endpoint = forall(("a", "n"), exists(("u",), conjunction(
        implies(eq(n, zero), eq(u, a)),
        forall(("x", "y"), conn("K4",
            conjunction(eq(x, n), eq(y, u)),
            eq(rec(h, x, a), y), eq(x, succ(n)), eq(y, dagger(h, u, n, x)),
        )),
    )))
    folded = forall(("a", "n"), eq(rec(h, n, a), select(n, a,
        dagger(h, rec(h, pred(n), a), pred(n), n))))
    bound = forall(("a", "n", "u"), implies(eq(pred(n), u),
        eq(rec(h, n, a), select(n, a, dagger(h, rec(h, u, a), u, n)))))
    ans = {"O": ordinary, "G": (graph,), "T": (endpoint,), "F": (folded,), "L": (bound,)}
    if profile(h)[3] == 0:
        next_graph = forall(("a", "n"), exists(("u",), forall(("x", "y"), conn("K4",
            conjunction(eq(succ(x), n), eq(y, u)), eq(rec(h, x, a), y), eq(x, n),
            eq(y, select(n, a, dagger(h, u, zero, n))),
        ))))
        ans["N4"] = (next_graph,)
    return ans


def atomic_active_subterms(t: Term) -> set[Term]:
    ans = {t}
    for child in t.args:
        ans.update(atomic_active_subterms(child))
    return ans


def occurrences(t: Term, target: Term) -> int:
    if t == target:
        return 1
    return sum(occurrences(child, target) for child in t.args)


def replace_subterm(t: Term, target: Term, replacement: Term) -> Term:
    if t == target:
        return replacement
    return Term(t.tag, tuple(replace_subterm(p, target, replacement) for p in t.args), t.descriptor, t.name)


def factor_one_atomic(e: Formula, target: Term, name: str = "shared") -> tuple[Formula, Formula, int]:
    """One explicit existential binding, not a claim of a global minimum."""
    assert e.tag == "=" and len(e.parts) == 2
    assert name not in formula_free(e)
    lhs, rhs = e.parts
    assert isinstance(lhs, Term) and isinstance(rhs, Term)
    count = occurrences(lhs, target) + occurrences(rhs, target)
    variable = var(name)
    residual = eq(replace_subterm(lhs, target, variable), replace_subterm(rhs, target, variable))
    graph = exists((name,), conjunction(eq(variable, target), residual))
    reconstructed = formula_substitute(residual, {name: target})
    assert reconstructed == e
    assert formula_size(graph) == formula_size(e) - (count - 1) * term_size(target) + count + 4
    return graph, residual, count


def kernel_counts() -> dict:
    eta = eq(pair(left(z), right(z)), z)
    horizontal = eq(succ(pair(succ(a), n)), pair(a, succ(n)))
    vertical = eq(succ(pair(zero, n)), pair(succ(n), zero))
    retract = conjunction(eq(left(pair(a, n)), a), eq(right(pair(a, n)), n))
    parts = [forall(("z",), eta), forall(("a", "n"), horizontal), forall(("n",), vertical), forall(("a", "n"), retract)]
    separate = [formula_size(p) for p in parts]
    bundled = forall(("a", "n"), conjunction(
        formula_substitute(eta, {"z": a}), horizontal, vertical, retract,
    ))
    sep = implies(eq(zero, succ(zero)), bottom)
    cov = forall(("z",), exists(("y",), conn("or", eq(z, zero), eq(z, succ(y)))))
    pa, pb, pc, pd = (Formula(s) for s in ("A", "B", "C", "D"))
    k3 = 1 + formula_size(conn("K3", pa, pb, pc)) + formula_size(conjunction(implies(pa, pb), implies(pb, pc)))
    k4 = 1 + formula_size(conn("K4", pa, pb, pc, pd)) + formula_size(conjunction(implies(pa, pb), implies(pb, implies(pc, pd))))
    nested = 1 + formula_size(conn("K4", pa, pb, pc, pd)) + formula_size(conn("K3", pa, pb, implies(pc, pd)))
    qz = sum(formula_size(f) for h in (w, zero) for f in modules(h)["O"])
    assert separate == [8, 12, 10, 15]
    assert sum(separate) == 45 and formula_size(bundled) == 44
    assert (formula_size(sep), formula_size(cov), k3, k4, k3 + nested, qz) == (6, 10, 12, 15, 24, 32)
    return {"pairing_sentences": separate, "pairing_separate": 45, "pairing_shared_prefix": 44,
            "separation": 6, "coverage": 10, "K3_record": 12, "K4_standalone_record": 15,
            "K4_via_K3_record": nested, "joint_K3_K4_records": 24, "protected_QZ": qz}


def sample_terms() -> list[Term]:
    rng = random.Random(20261102)
    pool = [v, w, zero, succ(v), succ(w), succ(zero), pair(v, w), left(v), right(w),
            q(succ(v), zero), rec(zero, zero, w), rec(succ(v), succ(w), v),
            rec(q(succ(v), zero), w, v)]
    seen = set(pool)
    attempts = 0
    while len(pool) < 500 and attempts < 20000:
        attempts += 1
        s, t = rng.choice(pool), rng.choice(pool)
        tag = rng.randrange(8)
        if tag == 0:
            candidate = succ(s)
        elif tag == 1:
            candidate = pair(s, t)
        elif tag == 2:
            candidate = left(s)
        elif tag == 3:
            candidate = right(s)
        elif tag == 4:
            candidate = q(succ(s), t)
        elif tag == 5:
            candidate = rec(rng.choice(pool), zero, t)
        elif tag == 6:
            candidate = rec(succ(v), s, t)
        else:
            candidate = rec(rng.choice(pool), s, t)
        if term_size(candidate) <= 350 and dependency_rank(candidate) <= 7 and candidate not in seen:
            seen.add(candidate)
            pool.append(candidate)
    assert len(pool) == 500
    return pool


def translation_checks(pool: list[Term]) -> dict:
    module_count = 0
    max_rank = 0
    for t in pool:
        assert active_free(t) <= {"v", "w"}
        nt = normalize_active(t)
        st = translate_term(t)
        assert normalize_active(nt) == nt
        assert translate_term(st) == st
        assert term_size(nt) <= term_size(t)
        assert term_size(st) <= term_size(t)
        assert dependency_rank(st) <= dependency_rank(t)
        assert active_free(st) <= active_free(t)
        assert descriptors_canonical(st)
        max_rank = max(max_rank, dependency_rank(t))
        replacement = {"v": succ(a), "w": pair(x, zero)}
        assert translate_term(active_substitute(t, replacement)) == active_substitute(
            st, {name: translate_term(value) for name, value in replacement.items()}
        )
        g = canonical_body(t)
        assert canonical_body(g) == g
        if g != v:
            for f in modules(g)["O"]:
                assert translate_formula(f) == f
                atom = f
                while atom.binder is not None:
                    atom = atom.parts[0]
                assert isinstance(atom, Formula) and atom.tag == "=" and atom.parts[0] != atom.parts[1]
                module_count += 1
    frozen = rec(succ(v), v, w)
    replaced = active_substitute(frozen, {"v": a, "w": n})
    assert replaced.descriptor == succ(v)
    assert replaced.args == (a, n)
    assert active_free(rec(succ(v), zero, a)) == {"a"}
    opaque = rec(q(succ(v), zero), a, n)
    assert normalize_active(opaque).descriptor == q(succ(v), zero)
    assert translate_term(opaque) == n
    capture_case = forall(("x",), eq(a, x))
    capture_result = formula_substitute(capture_case, {"a": x})
    assert capture_result.binder == "x_0" and formula_free(capture_result) == {"x"}
    assert capture_result.parts[0] == eq(x, var("x_0"))
    preserved_base = eq(rec(w, zero, a), a)
    assert translate_formula(preserved_base) == preserved_base
    assert normalize_active(rec(w, zero, a)) == a
    return {"sample_terms": len(pool), "max_sample_dependency_rank": max_rank,
            "checks_per_term": ["N idempotent", "Sigma idempotent", "both sizes nonincreasing",
                                "Sigma rank nonincreasing", "no new active free variable",
                                "canonical nonidentity stored descriptors", "active substitution commutes with Sigma"],
            "canonical_ordinary_axioms_preserved_nonreflexive": module_count,
            "frozen_descriptor_tests": "passed", "capture_avoiding_formula_substitution": "passed",
            "homomorphic_application_test": "Q(0,a)=a remains a nonreflexive axiom"}


def module_counts(pool: list[Term]) -> dict:
    tested = {name: 0 for name in ("O", "G", "T", "F", "L", "N4")}
    for h in pool:
        H, k, j, r = profile(h)
        expected = {"O": 3*H+13+k*(H+2), "G": 3*H+21, "T": 2*H-j+32,
                    "F": 2*H-j+13+k*(H+5)+3*r, "L": 2*H-j+21+k*(H+2), "N4": 2*H-j+31}
        for name, forms in modules(h).items():
            actual = sum(formula_size(f) for f in forms)
            assert actual == expected[name], (name, (H, k, j, r), actual, expected[name])
            tested[name] += 1
        assert term_size(dagger(h, u, n, x)) == H-j
        assert dagger(h, u, n, succ(n)) == active_substitute(h, {"v": u, "w": n})
    return {"descriptor_samples": len(pool), "counts_by_template": tested,
            "O": "3H+13+k(H+2)", "G": "3H+21", "T": "2H-j+32",
            "F": "2H-j+13+k(H+5)+3r", "L": "2H-j+21+k(H+2)",
            "N4": "2H-j+31, eligible only when r=0"}


def identity_family() -> list[dict]:
    h = v
    rows = []
    for m in range(21):
        H = term_size(h)
        old = forall(("a", "n"), eq(rec(h, n, a), a))
        image = translate_formula(old)
        assert H == 4*m+1 and canonical_body(h) == v
        assert formula_size(old) == H+7
        assert image == forall(("a", "n"), eq(a, a))
        assert formula_size(image) == 5
        assert term_size(rec(h, n, a)) == H+3 and translate_term(rec(h, n, a)) == a
        rows.append({"m": m, "descriptor_size_H": H, "source_identity_module": H+7,
                     "homomorphic_image_before_tautology_omission": 5,
                     "emitted_after_pure_reflexivity_omission": 0,
                     "source_call_size": H+3, "translated_call_size": 1})
        h = q(succ(h), zero)
    return rows


def boundary_counts(pool: list[Term]) -> dict:
    for h in pool[:100]:
        e = eq(rec(h, x, a), a)
        F = formula_size(e)
        lower, at_end, target = eq(succ(x), b), eq(x, b), eq(b, a)
        k4 = forall(("a",), exists(("b",), forall(("x",),
            conn("K4", lower, e, at_end, target))))
        k3 = forall(("a",), exists(("b",), forall(("x",),
            conn("K3", lower, e, implies(at_end, target)))))
        expanded = forall(("a",), exists(("b",), forall(("x",),
            conjunction(implies(lower, e), implies(e, implies(at_end, target))))))
        assert formula_size(k4) == F+14
        assert formula_size(k3) == F+15
        assert formula_size(expanded) == 2*F+17
        assert formula_size(translate_formula(k4)) <= formula_size(k4)
    return {"equation_samples": 100, "K4_diagonal": "F+14", "K3_diagonal": "F+15",
            "ordinary_logical_expansion": "2F+17", "translated_sentence_size_nonincrease": "passed"}


def sharing_checks() -> dict:
    t = a
    rows = []
    for m in range(1, 9):
        t = rec(succ(v), x, t)
        original = eq(q(t, zero), q(t, succ(zero)))
        graph, _, count = factor_one_atomic(original, t)
        assert count == 2 and term_size(t) == 4*m+1
        assert formula_size(original) == 2*term_size(t)+8
        assert formula_size(graph) == term_size(t)+14
        rows.append({"m": m, "shared_term_size": term_size(t), "equation_size": formula_size(original),
                     "one_binding_size": formula_size(graph), "with_empty_option": min(formula_size(original), formula_size(graph))})
    # A matching tree inside a stored descriptor is not an active occurrence.
    needle = succ(v)
    frozen_only = rec(needle, x, a)
    assert occurrences(frozen_only, needle) == 0
    assert replace_subterm(frozen_only, needle, z) == frozen_only
    return {"scope": "single-binding atomic factoring and exact reconstruction, not the full exhaustive optimizer",
            "rows": rows, "frozen_descriptor_exclusion": "passed"}


def numerical_diagnostics() -> dict:
    def triangle(k: int) -> int:
        return k*(k+1)//2

    def numeric_pair(i: int, j: int) -> int:
        return triangle(i+j)+j

    def coordinates(code: int) -> tuple[int, int]:
        k = (math.isqrt(8*code+1)-1)//2
        r = code-triangle(k)
        return k-r, r

    for code in range(4096):
        l, r = coordinates(code)
        ls, rs = coordinates(code+1)
        assert numeric_pair(l, r) == code
        assert rs == 0 or rs == r+1
        if l == 0:
            assert (ls, rs) == (r+1, 0)
        else:
            assert (ls, rs) == (l-1, r+1)
    pair_instances = 0
    for i in range(41):
        for j in range(41):
            assert coordinates(numeric_pair(i, j)) == (i, j)
            assert numeric_pair(i+1, j)+1 == numeric_pair(i, j+1)
            pair_instances += 1
    for j in range(41):
        assert numeric_pair(0, j)+1 == numeric_pair(j+1, 0)
    scan_patterns = 0
    invariant_states = 0
    for target in range(9):
        for bits in range(1 << (target+1)):
            truth = [(bits >> k) & 1 == 1 for k in range(target+1)]
            candidate = 0
            for k in range(target+1):
                assert 0 <= candidate <= k
                assert not truth[candidate] or candidate == k
                assert candidate == 0 or truth[candidate-1]
                invariant_states += 1
                if k < target and truth[candidate]:
                    candidate = k+1
            for probe in range(target+2):
                if probe+1 == candidate:
                    assert truth[probe]
                if probe == candidate and truth[probe]:
                    assert candidate == target
            scan_patterns += 1
    return {"pairing_eta_and_reset_codes": 4096, "retraction_and_horizontal_route_pairs": pair_instances,
            "vertical_route_instances": 41, "scan_max_target": 8, "all_scan_truth_patterns": scan_patterns,
            "scan_invariant_states": invariant_states,
            "qualification": "bounded standard-N diagnostics only; no inference about all or nonstandard inputs"}


def main() -> None:
    pool = sample_terms()
    results = {
        "status": "passed",
        "scope": "exact finite AST checks and bounded numerical diagnostics; not a mechanized interpretation or bi-interpretability proof",
        "arithmetic": "full first-order intuitionistic primitive recursive arithmetic",
        "metric": "one node per variable, constant, application, equality, connective, falsity, individual quantifier; full frozen descriptor charged at each recursor application",
        "normalizer_rules": ["R_g(0,t) -> t", "Q(Su,t) -> u"],
        "symbol_translation": "canonical g=N(Sigma(h)); R_h(s,t) maps to Sigma(t) when g=v, otherwise R_g(Sigma(s),Sigma(t)); no active normalization of the resulting application",
        "fixed_counts": kernel_counts(),
        "translation_checks": translation_checks(pool),
        "module_counts": module_counts(pool),
        "boundary_counts": boundary_counts(pool),
        "identity_family": identity_family(),
        "atomic_sharing": sharing_checks(),
        "finite_diagnostics": numerical_diagnostics(),
        "not_checked": ["a formal first-order derivation calculus", "generic theorem proofs", "arbitrary Kripke or nonstandard models", "optimality among all encodings", "the complete exhaustive sharing optimizer"],
    }
    output = Path(__file__).resolve().with_name("checks.json")
    output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": results["status"], "output": str(output),
                      "terms": len(pool), "module_template_cases": sum(results["module_counts"]["counts_by_template"].values()),
                      "scan_truth_patterns": results["finite_diagnostics"]["all_scan_truth_patterns"]}, indent=2))


if __name__ == "__main__":
    main()
