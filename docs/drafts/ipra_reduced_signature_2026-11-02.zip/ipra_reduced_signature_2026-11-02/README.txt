A REDUCED-SIGNATURE AXIOMATIZATION OF iPRA
========================================
Prepared for Vladimir Reshetnikov, 2 November 2026

START HERE
report.pdf is the complete mathematical report.
report.tex and sections/*.tex are its complete editable LaTeX sources.
AXIOMS.txt gives the exact standalone specification.

MAIN RESULT
The theory is bi-interpretable and syntactically equiconsistent with
FULL FIRST-ORDER INTUITIONISTIC PRA, with quantifier-free induction and
every fixed finite numerical parameter tuple. Both interpretations use
the entire carrier and preserve native equality and genuine falsity.
Both composites are identified internally by the equality relation.

The new reduction changes the generated numerical language:
  * Normalize an update body by certified erasing computation rules.
  * Introduce only irreducible nonidentity recursor descriptions.
  * Translate identity recursors to their initial-state argument.
  * Reuse the same canonical symbol for certified equivalent updates.
No obsolete recursor names or alias equations remain in the canonical
signature. This is a syntactic compiler, not a semantic program oracle.

An explicit family h_0=v, h_(m+1)=Q(S(h_m),0) previously retained
identity modules of size4m+8. Those modules and names disappear.
There are unbounded savings both in modules and in calls.

THE FINITE LEDGER
The strongest current native pairing kernel has45 nodes; sharing its
universal prefix gives44. Sep and Cov cost6 and10.
  K3-only fixed record:72.
  K4-only fixed record:75.
  Joint K3/K4 fixed record:84 (joint definition price24).
The protected Q,Z modules cost32 in addition. The recursion and
boundary schemes remain infinite. These are NOT whole-theory sizes.
The one-node kernel saving and inherited three-node logical saving are
credited separately from the new canonical-language reduction.

REFERENCE AND EXACT COMPARISON VERSIONS
C_flat_34 is the compact optimized reference: canonical signature,
the native pairing kernel, the union of supported computation options,
explicit equation sharing, and projected diagonal boundaries.
C_flat_4 is the clean one-chain presentation with ordinary computation.

The separate canonical image presentation C_im maps the complete raw
envelope axiom set homomorphically, deduplicates, and omits universal
reflexivities. Its finite source axiom packets never increase in fully
charged AST size, including explicitly shared source packets. An image
enumeration can contain several equivalent clauses for one symbol.
No global optimality of that enumeration or of transformed proofs is
claimed. The paper distinguishes these exact guarantees.

SOURCE AUDIT
Pinned repository: VladimirReshetnikov/ProveIt
Commit:44d32ed7bce61b58f6a28c03979cc95dd935acf7
There were four current and five archived archives at this snapshot.
All four current packages improved on the archived iteration and were
retained for comparison. See provenance/draft_audit.csv and the immutable
URLs and hashes in provenance/source_manifest.json.

CONTENTS
  report.pdf                   Compiled complete report.
  report.tex; sections/*.tex    Complete LaTeX source.
  AXIOMS.txt                   Exact theory and compiler specification.
  artifacts/verify.py          Standard-library syntax/count checker.
  artifacts/checks.json        Deterministic recorded check output.
  artifacts/VERIFICATION.txt   What is and is not verified.
  provenance/*                Source identities and comparative audit.
  build.py                    Re-run checks and compile PDF.
  SHA256SUMS.txt               Included-file integrity hashes.

REBUILD
Requires Python3.10+ and TeX Live with latexmk, pdflatex, and the normal
packages listed in report.tex. No network access is used by the build.
From this directory:
  python3 build.py
Or for the checker only:
  python3 artifacts/verify.py

VERIFICATION AND LIMITS
The generic theorem is a written constructive proof, not a complete
Lean or Rocq formalization. The checker verifies exact finite syntax,
counts, compiler invariants and bounded standard-number diagnostics;
these do not establish first-order induction by testing.
The PDF was compiled and visually inspected.

No absolute shortestness theorem across unrestricted languages,
encodings, domains or logical calculi is asserted. The achieved
comparison is the explicit supported frontier and finite-packet
nonincrease theorem, with the strict infinite-family improvement.
