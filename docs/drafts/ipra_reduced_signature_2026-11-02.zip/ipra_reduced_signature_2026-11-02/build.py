#!/usr/bin/env python3
"""Reproduce the finite checks and the PDF without network access."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys


def main() -> None:
    root = Path(__file__).resolve().parent
    result = subprocess.run(
        [sys.executable, str(root / "artifacts" / "verify.py")],
        cwd=root, check=True, capture_output=True, text=True,
    )
    parsed = json.loads(result.stdout)
    (root / "artifacts" / "checks.json").write_text(
        json.dumps(parsed, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    subprocess.run(
        ["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
         "-outdir=build", "report.tex"],
        cwd=root, check=True,
    )
    shutil.copy2(root / "build" / "report.pdf", root / "report.pdf")
    files = sorted(
        p for p in root.rglob("*") if p.is_file()
        and "build" not in p.relative_to(root).parts
        and "__pycache__" not in p.relative_to(root).parts
        and p.name != "SHA256SUMS.txt"
    )
    lines = [
        f"{hashlib.sha256(p.read_bytes()).hexdigest()}  "
        f"{p.relative_to(root).as_posix()}"
        for p in files
    ]
    (root / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("Checks passed; report.pdf and SHA256SUMS.txt rebuilt.")


if __name__ == "__main__":
    main()
