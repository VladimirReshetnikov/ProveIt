A SMALLER COMPLETE PRESENTATION OF iPRA
Computation certificates with canonical repair
Prepared for Vladimir Reshetnikov, 6 November 2026

START HERE

  report.pdf        Complete self-contained mathematical report.
  report.tex        LaTeX source, with sections/ and generated results/*.tex.
  checker.py        The complete 68-line trusted acceptance program.
  FORMAT.txt        Concrete syntax, binding conventions, and proof records.

RESULT

The entire checker is strictly below the coordinatewise observed source
envelope of the six current ProveIt drafts, including the inspected embedded
historical acceptance programs, at commit:

  0a86fcbd7c5e0d6a541291b4ac06c7dc77989161

                               Old envelope     This checker
  AST nodes                         675             646
  Significant source tokens        636             614
  Normalized source tokens         634             612
  Normalized UTF-8 bytes           2053            1940
  Raw source bytes                2205            2049

These are complete-file measurements under CPython 3.12.14. They include
formation, substitution, inference, arithmetic, JSON input, and rejection.
The public certificate remains [context, claimed_goal, proof]. All public
formulas are validated and the claimed conclusion is still checked.

The mathematical basis is inherited with attribution from the draft series.
The additional reduction allows unused numerical data in intermediate
recursor equations. A total external repair reconstructs every accepted
certificate as a fully well-formed derivation of the SAME public sequent.
The report proves this invariant and separately proves full intuitionistic
logical recovery, quantifier-free induction, whole-domain bi-interpretability
with first-order iPRA, and equiconsistency. It includes Further research
questions and the entire checker source.

This is a strict finite implementation improvement, not a proof of an
absolute shortest axiomatization. The general mathematical proofs have not
been mechanized in Lean or Rocq.

USE

Python 3.10+ and the standard library suffice to check certificates.

  python3 checker.py examples/reflexivity.json
  python3 checker.py examples/zero_plus_n.json
  python3 -O checker.py examples/reflexivity.json

Successful checking prints ACCEPT and exits 0; rejection prints REJECT and
exits 1. The checker uses no assertions that python -O could erase.

Reproduce all source measurements, proof repair, and adversarial tests:

  python3 reproduce.py

Also rebuild the PDF (requires latexmk, pdfLaTeX, and the ordinary packages
listed at the top of report.tex):

  python3 reproduce.py --pdf

Remeasure without repeating the validation suites:

  python3 reproduce.py --metrics-only

Build a fresh archive, including integrity hashes:

  python3 build.py --zip

The normal reproduction workflow is offline. All comparison sources and
test fixtures are included. Exact normalized sizes use CPython 3.12.14;
ast.unparse output can differ across Python versions. Every candidate is
remeasured using the same interpreter within one run.

TRANSLATE AND RECHECK

  python3 translate.py forward old.json new.json
  python3 translate.py backward new.json repaired.json

The forward direction erases redundant use tags from shared-transition
proof syntax. The backward direction repairs raw arithmetic data, restores
the tags, and checks the reconstructed proof against BOTH frozen targets:

  strict_shared.py   Original shared-transition checker, with full recursor
                     validation and demand-checked universal witnesses.
  strict_eager.py    Frozen checker with full validation of every witness
                     and every recursor term.

Both directions preserve the context and claimed goal literally. repair.py
and translate.py are untrusted support: checker.py does not import them.

VALIDATION

  256 inherited fixtures: 195 accepted and repaired, 61 rejected.
  Exactly one intentional new acceptance: unused_bad_recursor_body.
  204 focused hostile-data tests: 166 repaired acceptances, 38 rejections.
  800 substitution probes: all 617 successful traversals commute with repair.
  59,888 independent hostile/mutated cases: all 21,079 acceptances repaired
    and replayed with exact original public statements.
  36 process-level checks: 18 ordinary and 18 with python -O.

The original shared checker accepted 194 inherited fixtures; the eager
checker accepted 150 before repair. All 195 new-checker acceptances repair
to proofs accepted by both. The difference includes 44 older cases with
unused malformed universal witnesses, plus the newly repairable recursor
case. These are finite implementation checks, not counts of independent
theorems or a substitute for the all-input proof.

COMPARISON PROVENANCE

  1042 Python source occurrences across all six supplied ZIPs;
  272 byte-distinct sources, all frozen with hashes and origins;
  186 self-contained standalone acceptance modules;
  74 inherited dependency-group records (26 multifile; overlapping);
  222 acceptance/dependency sources and 50 separately inventoried support
    sources. Historical group and standalone counts must not be added as
    a count of distinct theories.

comparison/README.txt explains classification limits and historical module
aliases. comparison/measure.py hashes and reparses every frozen source
without executing it. comparison/metadata.json records all archive Git blob
identities and SHA-256 hashes. The source envelope is unchanged by including
the historical groups.

Optional regeneration from separately downloaded original ZIPs:

  python3 comparison/rebuild_from_archives.py /path/to/six-zips --out rebuilt

That script verifies the pinned Git blob identities before rebuilding its
census. It is not needed for ordinary offline reproduction.

PACKAGE CONTENTS

  sections/          Full mathematical arguments, including canonical repair.
  results/           Measurements, test logs, PDF QA summary, generated tables.
  controls/          Combined checker with the computation validation restored.
  comparison/        Frozen source census, provenance, and offline measurement.
  fixtures/          Exact inherited certificates and expected classifications.
  examples/          Ordinary, newly accepted, repaired, and rejected examples.
  validation/        Independent hostile/mutated-certificate audit.
  provenance.json    Source-checker and fixture hashes and origins.
  MANIFEST.sha256    Integrity hashes for the packaged files.

Only checker.py and the common Python/JSON runtime participate in acceptance.
No theorem database, schema generator, repair tool, or test interpreter is
hidden in the trusted boundary.

Candidate SHA-256:
  cc045189218430eb27c21c3043fc4491500692fb9f38c858790a2d7c5167165a
