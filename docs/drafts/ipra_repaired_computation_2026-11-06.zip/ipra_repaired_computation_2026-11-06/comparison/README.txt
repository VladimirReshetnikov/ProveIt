OFFLINE SOURCE CENSUS AND COMPLEXITY MEASUREMENT
==============================================

Pinned repository:
  VladimirReshetnikov/ProveIt
  commit 0a86fcbd7c5e0d6a541291b4ac06c7dc77989161
  docs/drafts

All six ZIP archives were read completely. Their Git blob SHA-1 values were
checked against the GitHub directory response; archive SHA-256 values and
byte sizes are recorded in metadata.json. All Python members were decoded,
parsed, and deduplicated by SHA-256 without executing any compared program.

Census:
  1,042 Python member occurrences;
  272 byte-distinct Python sources, with zero parsing failures;
  186 complete self-contained standalone acceptance modules;
  74 declared historical acceptance groups, including 26 multifile groups;
  222 frozen acceptance/dependency sources;
  50 excluded support/validation sources, also frozen for inspection.

The 186 standalone modules comprise 183 files with top-level infer/check
functions and three exported class-based Checker implementations. Each has
a __main__ branch and no Python imports other than json/sys. The full source
is measured, including parsing, formation, substitution, arithmetic, proof
checking, and rejection. All candidates, controls and ablation versions
meeting that criterion are included, not only top-level checker.py files.

The 74 historical groups preserve the exact original member hashes, labels,
recorded paths, and declared boundaries. Their size is the sum of distinct
member files. The groups and standalone modules overlap. Some historical
entries intentionally measure only a mathematical core without its CLI;
these favor the older programs. Standalone counts and group counts must not
be added as a count of distinct formal theories.

Every one of the 272 original Python sources is frozen:
  sources/<sha256>.py            acceptance/dependency source
  excluded_support/<sha256>.py   tests, proof generators, build tools, etc.

full_inventory.json preserves all source origins, functions, classes,
imports, hashes and measurements, including the excluded files. Therefore
the exclusion of a short parser-only adapter or test harness is inspectable.
An adapter importing a project module is never counted by itself as a full
checker; it is counted with the declared module dependencies.

Offline reproduction:

  python3 comparison/measure.py --candidate checker.py \
    --out results/comparison.json

The script hashes and reparses every frozen source, independently reproduces
the standalone classification, sums every dependency group, and recomputes
the coordinatewise envelope. It does not require GitHub, the original ZIPs,
or any third-party Python package. Use the same Python version for an exact
ast.unparse normalized-byte comparison. All programs on a given run are
measured by that same interpreter.

The broader ZIP provenance census is a separate program supplied by the
authoring workflow. Offline remeasurement does not need the ZIP downloads.

Limits:

1. This is an empirical finite corpus comparison, not a lower-bound theorem
   for arbitrary formal systems or programming languages.
2. Historical checkers are measured, not independently certified sound or
   complete. Independent validation interpreters are support programs, not
   proposed acceptance kernels, and are excluded from the envelope.
3. Six old groups combine an adapter importing 'kernel' with a differently
   named variant. They require installing the variant under the adapter's
   expected name to execute. Their source sizes are retained as favorable
   historical comparison boundaries. measure.py reports these aliases.
4. Some old groups omit adapters by explicit design. Including those cores
   cannot favor the new checker: the historical group envelope still exceeds
   the current standalone envelope in every metric.
5. Standard Python and its JSON parser are the common platform. Imported
   project-specific mathematical modules are charged in full.

Observed envelopes under CPython 3.12.14:
  Current and broad corpus: 636 source tokens, 634 normalized tokens,
                           675 AST nodes, 2053 normalized bytes,
                           2205 raw bytes.
  All historical groups:  1089 / 1089 / 1154 / 3486 / 3817.
  Multifile groups:       1677 / 1685 / 1816 / 5180 / 5833.

The five positions are source tokens / normalized tokens / AST nodes /
normalized bytes / raw bytes. Coordinatewise minima need not belong to
the same program.
