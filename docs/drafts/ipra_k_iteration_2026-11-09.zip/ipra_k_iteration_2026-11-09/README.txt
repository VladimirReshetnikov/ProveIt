iPRA FROM THE K COMBINATOR AND ZERO-SEEDED ITERATION
=================================================
Prepared for Vladimir Reshetnikov, November 9, 2026 (Pacific time).

MAIN RESULT AND LIMIT
---------------------
Numerical syntax: K, binary application, and fixed-update iteration J.
Successor is the abbreviation S(a)=K a. The three computation schemas are

    (K a) b = a
    J(K; u.h) = K
    J(K n; u.h) = h[J(n; u.h)/u]

The report proves whole-domain bi-interpretability and equiconsistency
with full first-order intuitionistic primitive recursive arithmetic.
It states both an ordinary intuitionistic theory and a complete native
paired-binder calculus whose usual logic is derived.

This reduces the previous finite zero-seed basis from four computation
schemas to three and simplifies its initializer and interpretation proofs.
The numerical reset function and K combinator are prior ingredients;
the new contribution is their finite-basis use and the explicit compiler.

Two complete readable checkers differ only in their arithmetic recognizer:

    new K/J basis: 1242 normalized tokens / 1406 AST nodes / 5236 bytes
    old G/J basis: 1340 normalized tokens / 1510 AST nodes / 5619 bytes

That is a matched saving of 98 tokens / 104 AST nodes / 383 bytes.
IT DOES NOT BEAT THE COMPACT FRONTIER. Current separate minima are
296/339/809 for silent-stderr rejection, or 295/334/801 if traceback
stderr is allowed. Different programs attain these coordinates.
No absolute simplest axiomatization or below-frontier checker is claimed.

MAIN FILES
----------
ipra_k_iteration.pdf       Compiled research article.
ipra_k_iteration.tex       Main LaTeX source.
sections/                 Complete included LaTeX sections.
code/matched_reset/       Two standalone native proof checkers, exact format,
                          source difference, examples and validation receipt.
code/verify_reset.py      Symbolic verifier for the new finite equational proof.
certificates/             Serialized symbolic proof receipt.
evidence/                 Pinned corpus, metrics, checks and reproduction output.
reference/                Attributed frozen comparator sources and prior theory.
MANIFEST.sha256           SHA-256 hashes of the deliverable files.

REPRODUCE OFFLINE
----------------
    python reproduce.py

This reruns 17 symbolic equations, one equation induction, 17 corruption
rejections, 56 matched checker cases and 120 public CLI runs. It remeasures
the seven frozen compact comparator programs. Use ordinary Python for the
evidence harness; its child CLI tests exercise both ordinary and -O Python.
All required modules are in Python's standard library. Measurements were
made with CPython 3.12.14; ast.unparse layout can differ between versions.

RUN THE NEW COMPLETE CHECKER
---------------------------
    python code/matched_reset/new_checker.py < code/matched_reset/examples/new_gate_retraction.json

The exact public format and every rule are documented in
code/matched_reset/FORMAT.txt. Input is JSON data, never executable code.
Finite process limits may reject sufficiently deep valid derivations.

BUILD THE PDF
-------------
    latexmk -pdf -interaction=nonstopmode -halt-on-error ipra_k_iteration.tex

No shell escape or network is needed to build the article.

OPTIONAL FULL CORPUS RE-AUDIT (NETWORK REQUIRED)
----------------------------------------------
    python code/fetch_snapshot.py downloaded_baseline
    python code/audit_frontier.py downloaded_baseline evidence/fresh_frontier_audit.json

The downloader uses the pinned commit, verifies Git blob identities, and
checks archive paths before extraction. The original fourteen archives
are not duplicated in this deliverable. The lone nested reference ZIP was
verified identical to an active archive; see evidence/nested_archive_audit.json.

EVIDENCE BOUNDARY
-----------------
The finite equational certificate treats two fixed J instances as named
families and explicitly documents that elaboration. It is not the full
iPRA checker. The full native checker is new_checker.py. The mathematical
bi-interpretation proof is in the article; there is no Lean/Rocq formalization.
Finite tests are evidence about the concrete implementations, not a proof
of every host-language behavior or an exhaustive minimality search.

ATTRIBUTION
-----------
Repository: VladimirReshetnikov/ProveIt
Commit: 6c902762efcb1e78a5dd25db745310bab74f47a5
The native Choice-DI logical basis and compact comparison sources are
inherited from the named repository drafts. The reset function already
appears as helper D in the finite-escape draft. The prior four-schema gate
source is included for exact comparison. Full citations are in the paper.
