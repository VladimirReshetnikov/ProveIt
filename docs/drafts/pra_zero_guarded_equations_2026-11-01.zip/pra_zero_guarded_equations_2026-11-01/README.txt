PRA FROM ZERO-GUARDED EQUATION PROPAGATION
Prepared for Vladimir Reshetnikov -- 1 November 2026

RESULT
The same nonlogical specification, in classical or intuitionistic
first-order equality logic, is term-bi-interpretable with matching
first-order PRA. It preserves the whole carrier and native equality;
both composites are internally the identity.

The improvement over the strongest current scalar draft is its dynamic
axiom generator. The variable input is only ONE equation E(n,a):

  F_E(n,a) := (n=0 OR E(n,a)) AND 0!=S(0).

Keep the best delayed-iteration reset and tail computation matrices and
the outer propagation scheme. There is no arbitrary QF matrix input,
no copied E(0,a), and no separate intuitionistic decision case.
The outer opaque count remains 15. This is not an absolute minimality
claim, and not every expanded axiom is shorter.

CONTENTS
  report.pdf                   Complete 17-page mathematical report
  report.tex                   Main TeX source
  arithmetic.tex               Constructive equality/Boolean reflection
  pairing.tex                  Pairing, parameter packing, PR compiler
  interpretations.tex          Both translations and both round trips
  comparison.tex               Counts, obstruction, scope, further research
  references.tex               Pinned sources and primary references
  AXIOMS.txt                   Complete stand-alone specification
  build.py                     PDF/check rebuild helper
  checks/check_spec.py          Finite syntax audit and bounded diagnostics
  checks/results.json          11,589 successful checks and precise scope
  formal/FixedZeroGuardKernel.lean
                               Constructive arbitrary-carrier logical kernel
  formal/lean-toolchain         leanprover/lean4:v4.19.0
  formal/lean-check.log         Actual compiler output, ten empty axiom reports
  formal/verification.json      Compiler version and source hash
  formal/SCOPE.txt              Exact formalization boundary
  audit/source_manifest.json   Six reviewed archives and source hashes
  audit/independent_review.txt  Independent mathematical/comparison review
  audit/validation.json         Build, page and artifact checks
  SHA256SUMS.txt                Content integrity list

REBUILD
Required: Python 3, latexmk, a normal pdflatex installation with the
packages listed in report.tex. No Python third-party packages are
required for the included syntax/numerical checks.

  python3 build.py

To additionally recheck the Lean kernel with Lean 4.19.0 installed:

  python3 build.py --lean /absolute/path/to/lean

The compiler was actually run for this release. The formal file proves
lemmas from explicit hypotheses, uses no Classical and no Nat induction,
and its ten printed dependency lists were empty. It does NOT formalize
the full descriptor grammar, pairing compiler or bi-interpretability
metatheorem. Those are written proofs in the report.

The Python checks are finite syntax audits and bounded diagnostics;
they are not a substitute for the mathematical proof.

COMPARISON
Current six drafts were read at ProveIt commit
13300d26dac24e7e6b75fe38fd21fb5b5d416d41.
The reset form of pra_delayed_iteration_2026-11-01(1).zip is the main
scalar baseline. The earlier smaller-generator draft was also read for
its equation-induction calibration and its explicitly unproved internal
pure-iteration predecessor route. Attribution appears in the report.
