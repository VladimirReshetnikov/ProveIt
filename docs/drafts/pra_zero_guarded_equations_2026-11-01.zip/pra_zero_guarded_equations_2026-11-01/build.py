#!/usr/bin/env python3
"""Rebuild the PDF and finite diagnostics; optionally recheck the Lean kernel."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


def run(command, cwd, logfile):
    result = subprocess.run(command, cwd=cwd, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    logfile.write_text(result.stdout, encoding="utf-8")
    if result.returncode:
        print(result.stdout[-10000:])
        raise SystemExit(result.returncode)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", help="Optional path to a Lean executable")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    out = root / "build"
    out.mkdir(exist_ok=True)
    run([sys.executable, str(root / "checks/check_spec.py")], root,
        out / "checks.log")
    if not shutil.which("latexmk"):
        raise SystemExit("latexmk is required to compile report.tex.")
    run(["latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
         "-outdir=" + str(out), "report.tex"], root, out / "latex-console.log")
    log = (out / "report.log").read_text(errors="replace")
    problems = [line for line in log.splitlines()
                if "Overfull" in line or "undefined" in line.lower()]
    if problems:
        raise SystemExit("Inspect LaTeX diagnostics:\n" + "\n".join(problems))
    shutil.copyfile(out / "report.pdf", root / "report.pdf")
    status = {
        "pdf": "report.pdf",
        "pdf_sha256": hashlib.sha256((root / "report.pdf").read_bytes()).hexdigest(),
        "checks": json.loads((root / "checks/results.json").read_text())["total_checks"],
        "lean_rechecked": False,
        "scope": "PDF rebuild and finite diagnostics, not the full formal metatheorem."
    }
    if args.lean:
        result = run([str(Path(args.lean).resolve()), "FixedZeroGuardKernel.lean"],
                     root / "formal", out / "lean-recheck.log")
        version = subprocess.check_output([args.lean, "--version"], text=True).strip()
        status.update({"lean_rechecked": True, "lean_version": version,
                       "lean_exit_code": result.returncode})
    (out / "rebuild.json").write_text(json.dumps(status, indent=2) + "\n")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
