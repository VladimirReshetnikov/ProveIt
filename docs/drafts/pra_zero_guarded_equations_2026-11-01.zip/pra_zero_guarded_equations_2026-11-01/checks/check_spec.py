#!/usr/bin/env python3
"""Finite audit of zero-guarded equation propagation.

This checks the explicit syntax generator, capture-avoiding substitution,
the 15-node opaque propagation wrapper, and bounded standard-number examples.
It is not a proof assistant and does not certify the infinite schema, the
arithmetic bootstrap, induction, bi-interpretability, or nonstandard models.

Primary dynamic matrix (one arbitrary equation only):
    ((n = 0) OR (s(n,a) = t(n,a))) AND ((0 = S(0)) -> bottom).
The earlier two-equation-disjunction proposal is not the delivered theory.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

# A tree is a tuple whose first entry is its constructor.  Stored descriptors
# are names in D nodes, never active subterms subject to substitution.
Tree = tuple[Any, ...]


def V(name: str) -> Tree:
    return ("var", name)


ZERO: Tree = ("zero",)
BOT: Tree = ("bottom",)
N, A, X = V("n"), V("a"), V("v")


def S(t: Tree) -> Tree:
    return ("succ", t)


def D(name: str, n: Tree, a: Tree) -> Tree:
    return ("delay", name, n, a)


def Eq(s: Tree, t: Tree) -> Tree:
    return ("eq", s, t)


def Or(p: Tree, q: Tree) -> Tree:
    return ("or", p, q)


def And(p: Tree, q: Tree) -> Tree:
    return ("and", p, q)


def Imp(p: Tree, q: Tree) -> Tree:
    return ("implies", p, q)


def All(v: str, p: Tree) -> Tree:
    return ("forall", v, p)


def children(t: Tree) -> tuple[Tree, ...]:
    tag = t[0]
    if tag in {"var", "zero", "bottom"}:
        return ()
    if tag == "delay":
        return t[2:]
    if tag == "forall":
        return (t[2],)
    if tag == "opaque":
        return t[2:]
    return t[1:]


def fv(t: Tree) -> set[str]:
    if t[0] == "var":
        return {t[1]}
    if t[0] == "forall":
        return fv(t[2]) - {t[1]}
    return set().union(*(fv(c) for c in children(t)))


def names(t: Tree) -> set[str]:
    result = fv(t)
    if t[0] == "forall":
        result.add(t[1])
    for c in children(t):
        result |= names(c)
    return result


def nodes(t: Tree) -> int:
    """One for each constructor; a binder name is not a separate node.

    D's descriptor identifier is charged as part of its function-symbol node;
    its stored body is explicitly excluded from this local AST count.
    """
    return 1 + sum(nodes(c) for c in children(t))


def free_occurrences(t: Tree, name: str) -> int:
    if t[0] == "var":
        return int(t[1] == name)
    if t[0] == "forall" and t[1] == name:
        return 0
    return sum(free_occurrences(c, name) for c in children(t))


def rebuild(t: Tree, cs: tuple[Tree, ...]) -> Tree:
    if t[0] in {"var", "zero", "bottom"}:
        return t
    if t[0] in {"delay", "opaque"}:
        return (t[0], t[1], *cs)
    if t[0] == "forall":
        return ("forall", t[1], cs[0])
    return (t[0], *cs)


def subst(t: Tree, var: str, replacement: Tree) -> Tree:
    """Capture-avoiding substitution of active free individual occurrences."""
    if t[0] == "var":
        return replacement if t[1] == var else t
    if t[0] == "forall":
        bound, body = t[1], t[2]
        if bound == var or var not in fv(body):
            return t
        if bound in fv(replacement):
            used = names(body) | fv(replacement) | {var}
            i = 0
            while f"fresh{i}" in used:
                i += 1
            fresh = f"fresh{i}"
            body = subst(body, bound, V(fresh))
            bound = fresh
        return All(bound, subst(body, var, replacement))
    return rebuild(t, tuple(subst(c, var, replacement) for c in children(t)))


def term_ok(t: Tree, descriptors: dict[str, Tree]) -> bool:
    if t[0] in {"var", "zero"}:
        return True
    if t[0] == "succ":
        return term_ok(t[1], descriptors)
    if t[0] == "delay":
        return t[1] in descriptors and all(term_ok(c, descriptors) for c in t[2:])
    return False


def add_descriptor(descriptors: dict[str, Tree], name: str, body: Tree) -> None:
    if name in descriptors or not term_ok(body, descriptors) or not fv(body) <= {"v"}:
        raise ValueError("Descriptor is not a fresh unary earlier-body description")
    descriptors[name] = body


DELTA = Eq(ZERO, S(ZERO))
SEP = Imp(DELTA, BOT)


def dynamic(equation: Tree, descriptors: dict[str, Tree]) -> Tree:
    if (
        equation[0] != "eq"
        or not all(term_ok(t, descriptors) for t in equation[1:])
        or not fv(equation) <= {"n", "a"}
    ):
        raise ValueError("Dynamic input must be one equation with free names n,a only")
    return And(Or(Eq(N, ZERO), equation), SEP)


def reset(name: str) -> Tree:
    return All("n", Eq(D(name, D("one", N, ZERO), A), A))


def transition(name: str, descriptors: dict[str, Tree]) -> Tree:
    old = D(name, S(A), N)
    return All("n", Eq(D(name, S(S(A)), N), subst(descriptors[name], "v", old)))


def wrapper(f: Tree) -> Tree:
    return All("a", Imp(All("n", Imp(f, subst(f, "n", S(N)))), All("n", f)))


def formula_depth(f: Tree) -> int:
    if f[0] in {"eq", "bottom", "opaque"}:
        return 0
    return 1 + max((formula_depth(c) for c in children(f)), default=0)


def evaluate(t: Tree, env: dict[str, int], descriptors: dict[str, Tree]) -> int:
    if t[0] == "var":
        return env[t[1]]
    if t[0] == "zero":
        return 0
    if t[0] == "succ":
        return evaluate(t[1], env, descriptors) + 1
    if t[0] == "delay":
        n = evaluate(t[2], env, descriptors)
        result = evaluate(t[3], env, descriptors)
        for _ in range(max(n - 1, 0)):
            result = evaluate(descriptors[t[1]], {"v": result}, descriptors)
        return result
    raise ValueError("Not a numerical term")


def native_value(f: Tree, env: dict[str, int], descriptors: dict[str, Tree]) -> bool:
    tag = f[0]
    if tag == "bottom":
        return False
    if tag == "eq":
        return evaluate(f[1], env, descriptors) == evaluate(f[2], env, descriptors)
    p = native_value(f[1], env, descriptors)
    q = native_value(f[2], env, descriptors)
    return {"and": p and q, "or": p or q, "implies": (not p) or q}[tag]


def z(n: int, a: int) -> int:
    return a if n == 0 else 0


def selector(n: int, a: int, b: int) -> int:
    return z(n, a) + z(z(n, 1), b)


def pred(n: int) -> int:
    return max(n - 1, 0)


def chi(n: int) -> int:
    return selector(n, 1, selector(pred(n), 0, 1))


def equality_bit(x: int, y: int) -> int:
    return chi(max(x + 1 - y, 0))


def error_bit(f: Tree, env: dict[str, int], descriptors: dict[str, Tree]) -> int:
    tag = f[0]
    if tag == "bottom":
        return 1
    if tag == "eq":
        return equality_bit(evaluate(f[1], env, descriptors), evaluate(f[2], env, descriptors))
    p = error_bit(f[1], env, descriptors)
    q = error_bit(f[2], env, descriptors)
    if tag == "and":
        return selector(p, q, 1)
    if tag == "or":
        return selector(p, 0, q)
    if tag == "implies":
        return selector(p, q, 0)
    raise ValueError("Not a quantifier-free formula")


def main() -> None:
    checks: dict[str, int] = {}

    def check(group: str, condition: bool) -> None:
        if not condition:
            raise AssertionError(group)
        checks[group] = checks.get(group, 0) + 1

    def reject(group: str, thunk: Any) -> None:
        try:
            thunk()
        except ValueError:
            check(group, True)
        else:
            raise AssertionError(f"{group}: invalid syntax was accepted")

    descriptors: dict[str, Tree] = {}
    for name, body in [("id", X), ("succ", S(X)), ("zero", ZERO), ("one", S(ZERO))]:
        add_descriptor(descriptors, name, body)
    add_descriptor(descriptors, "pred", D("succ", X, ZERO))
    add_descriptor(descriptors, "nested", D("pred", S(X), D("one", X, ZERO)))
    before = dict(descriptors)
    reject("descriptor_rejections", lambda: add_descriptor(descriptors, "self", D("self", X, ZERO)))
    reject("descriptor_rejections", lambda: add_descriptor(descriptors, "free_parameter", A))
    reject("descriptor_rejections", lambda: add_descriptor(descriptors, "future", D("missing", X, ZERO)))
    reject("descriptor_rejections", lambda: add_descriptor(descriptors, "id", X))
    check("descriptor_rejections", descriptors == before)

    terms = [ZERO, S(ZERO), N, A, S(N), S(A), D("succ", N, A), D("pred", N, ZERO)]
    dynamic_matrices = []
    for s in terms:
        for t in terms:
            equation = Eq(s, t)
            f = dynamic(equation, descriptors)
            dynamic_matrices.append(f)
            sentence = wrapper(f)
            check("generated_sentence_closedness", not fv(sentence))
            check("generated_sentence_names", names(sentence) <= {"n", "a"})
            check("fixed_dynamic_depth", formula_depth(f) == 2)
            check("dynamic_input_occurs_once", f[1][2] == Eq(s, t))
            # Fair common-equation comparison with the inherited old G.
            # Stored descriptor bodies are excluded, exactly as in nodes().
            k, r = nodes(equation), free_occurrences(equation, "n")
            old = Imp(Or(subst(equation, "n", ZERO), DELTA), equation)
            check("equation_input_count_formulas", nodes(old) == 2 * k + 6)
            check("equation_input_count_formulas", nodes(f) == k + 11)
            check("equation_input_count_formulas", nodes(wrapper(old)) == 6 * k + r + 23)
            check("equation_input_count_formulas", nodes(sentence) == 3 * k + r + 39)
    for h in descriptors:
        for f in [reset(h), transition(h, descriptors)]:
            check("stationary_bound_name", fv(f) <= {"a"})
            check("stationary_substitution", subst(f, "n", S(N)) == f)
            check("generated_sentence_closedness", not fv(wrapper(f)))
            check("generated_sentence_names", names(wrapper(f)) <= {"n", "a"})

    for invalid in [BOT, Or(Eq(N, A), Eq(N, A)), And(Eq(N, A), Eq(N, A)),
                    Imp(Eq(N, A), Eq(N, A)), All("n", Eq(N, A)), Eq(V("z"), A),
                    Eq(D("missing", N, A), ZERO)]:
        reject("dynamic_grammar_rejections", lambda invalid=invalid: dynamic(invalid, descriptors))

    # Demonstrate general capture avoidance independently of the generated
    # n,a-only instances; fresh0 is absent from every emitted axiom.
    captured = subst(All("a", Eq(N, A)), "n", A)
    check("capture_avoidance", captured == All("fresh0", Eq(A, V("fresh0"))))
    check("capture_avoidance", fv(captured) == {"a"})
    active = D("pred", N, A)
    check("stored_body_unchanged", subst(active, "n", S(N)) == D("pred", S(N), A))
    check("stored_body_unchanged", descriptors == before)

    opaque = ("opaque", "F", N, A)
    check("outer_opaque_ast_count", nodes(wrapper(opaque)) == 15)

    bound = 9
    for h in descriptors:
        for n in range(bound):
            for a in range(bound):
                env = {"n": n, "a": a}
                check("bounded_delayed_equations", evaluate(D(h, D("one", N, ZERO), A), env, descriptors) == a)
                lhs = evaluate(D(h, S(S(N)), A), env, descriptors)
                rhs = evaluate(subst(descriptors[h], "v", D(h, S(N), A)), env, descriptors)
                check("bounded_delayed_equations", lhs == rhs)
                for k in [0, 1]:
                    check("bounded_delayed_bases", evaluate(D(h, V("k"), A), {"k": k, "a": a}, descriptors) == a)
                normalized = D(h, S(D("succ", N, ZERO)), A)
                check("bounded_delay_normalization", evaluate(D(h, N, A), env, descriptors) == evaluate(normalized, env, descriptors))
    for n in range(20):
        check("bounded_predecessor", evaluate(D("succ", N, ZERO), {"n": n}, descriptors) == pred(n))
        check("bounded_chi", chi(n) == (0 if n == 1 else 1))
        for a in range(12):
            check("bounded_native_equality_bit", equality_bit(n, a) in {0, 1})
            check("bounded_native_equality_bit", (equality_bit(n, a) == 0) == (n == a))

    atoms = [Eq(N, ZERO), Eq(N, A), Eq(S(N), A), Eq(D("pred", N, ZERO), A), BOT]
    formulas = list(atoms)
    for left in atoms:
        for right in atoms:
            formulas.extend([And(left, right), Or(left, right), Imp(left, right)])
    formulas.extend([Imp(Imp(atoms[1], BOT), BOT), Imp(And(atoms[0], atoms[1]), Or(atoms[2], BOT))])
    for f in formulas:
        for n in range(7):
            for a in range(7):
                env = {"n": n, "a": a}
                bit = error_bit(f, env, descriptors)
                check("bounded_truth_terms", bit in {0, 1})
                check("bounded_truth_terms", (bit == 0) == native_value(f, env, descriptors))

    # This is only the direct failed coverage instance in the written product
    # countermodel.  Preservation of all equation-induction instances is a
    # mathematical Cartesian-product argument supplied in the report.
    product_zero = (0, 0)
    product_n = (0, 1)
    product_sp = tuple(pred(x) + 1 for x in product_n)
    check("product_coverage_counterexample", product_n != product_zero and product_n != product_sp)
    for x in range(5):
        for y in range(5):
            sn = (x + 1, y + 1)
            check("bounded_product_successor_coverage", sn == tuple(pred(t) + 1 for t in sn))

    result = {
        "status": "passed",
        "theory": "zero-guarded equation propagation T_Z",
        "scope": "Finite AST audit and bounded standard-number diagnostics only; not a formal proof of the full theorem.",
        "dynamic_matrix": "((n=0) or (s(n,a)=t(n,a))) and ((0=S(0))->bottom)",
        "matrix_constructors": ["G: one arbitrary equation in the fixed zero-guarded shape", "R: stationary quantified reset", "T: stationary quantified transition"],
        "opaque_outer_nodes": nodes(wrapper(opaque)),
        "outer_count_excludes": ["matrix bodies", "descriptor bodies", "language and generator code", "logic proof rules"],
        "dynamic_formula_connective_depth": 2,
        "common_equation_count_formulas": {
            "k": "AST size of E; stored descriptor bodies excluded",
            "r": "number of active free occurrences of n in E",
            "old_matrix": "2*k+6",
            "new_matrix": "k+11",
            "old_expanded_axiom": "6*k+r+23",
            "new_expanded_axiom": "3*k+r+39",
            "new_minus_old_expanded_axiom": "16-3*k",
        },
        "sample_descriptors": list(descriptors),
        "sample_dynamic_matrices": len(dynamic_matrices),
        "sample_stationary_matrices": 2 * len(descriptors),
        "bounded_delayed_equation_inputs": "0 <= n,a < 9",
        "bounded_truth_term_inputs": "0 <= n,a < 7",
        "product_coverage_witness": {"n": product_n, "zero": product_zero, "S_p_n": product_sp},
        "checks_by_group": checks,
        "total_checks": sum(checks.values()),
    }
    destination = Path(__file__).with_name("results.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
