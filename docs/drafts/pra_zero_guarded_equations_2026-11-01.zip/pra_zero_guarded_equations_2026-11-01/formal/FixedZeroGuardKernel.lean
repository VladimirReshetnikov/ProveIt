/-
Constructive logical kernel for the final fixed-zero-guard presentation.
Gate below contains ONE arbitrary equation and the fixed atom n = zero.

No arithmetic on Lean Nat, no Nat induction, no Classical, and no sorry.
The carrier and every operation are arbitrary parameters.  Assumptions
called gate are particular instances of the proposed source axiom.
This file does not formalize the finite descriptor grammar or full
first-order bi-interpretation; see SCOPE.txt.
-/

namespace PRAKernel

variable {A : Type u}

def Gate (zero : A) (succ : A → A) (E : A → Prop) (n : A) : Prop :=
  (n = zero ∨ E n) ∧ zero ≠ succ zero

def Propagation (zero : A) (succ : A → A) (E : A → Prop) : Prop :=
  (∀ n, Gate zero succ E n → Gate zero succ E (succ n)) →
    ∀ n, Gate zero succ E n

theorem separation_of_reflexive_gate
    (zero : A) (succ : A → A)
    (gate : Propagation zero succ (fun _ => zero = zero)) :
    zero ≠ succ zero := by
  have all : ∀ n, Gate zero succ (fun _ => zero = zero) n :=
    gate (by
      intro n hn
      exact ⟨Or.inr rfl, hn.2⟩)
  exact (all zero).2

theorem equation_induction
    (zero : A) (succ : A → A) (f g : A → A)
    (gate : Propagation zero succ (fun n => f n = g n))
    (base : f zero = g zero)
    (step : ∀ n, f n = g n → f (succ n) = g (succ n)) :
    ∀ n, f n = g n := by
  have all : ∀ n, Gate zero succ (fun n => f n = g n) n :=
    gate (by
      intro n hn
      refine ⟨Or.inr ?_, hn.2⟩
      cases hn.1 with
      | inl hz =>
        subst n
        exact step zero base
      | inr he => exact step n he)
  intro n
  cases (all n).1 with
  | inl hz =>
    subst n
    exact base
  | inr he => exact he

theorem coverage_from_guard
    (zero : A) (succ pred : A → A)
    (pred_succ : ∀ n, pred (succ n) = n)
    (gate : Propagation zero succ (fun n => n = succ (pred n))) :
    ∀ n, n = zero ∨ n = succ (pred n) := by
  have all : ∀ n, Gate zero succ (fun n => n = succ (pred n)) n :=
    gate (by
      intro n hn
      exact ⟨Or.inr (congrArg succ (pred_succ n)).symm, hn.2⟩)
  intro n
  exact (all n).1

theorem propagation_from_induction
    (zero : A) (succ : A → A) (E : A → Prop)
    (separation : zero ≠ succ zero)
    (induction : Gate zero succ E zero →
      (∀ n, Gate zero succ E n → Gate zero succ E (succ n)) →
      ∀ n, Gate zero succ E n) :
    Propagation zero succ E := by
  intro step
  exact induction ⟨Or.inl rfl, separation⟩ step

theorem successor_injective
    (succ pred : A → A) (pred_succ : ∀ n, pred (succ n) = n) :
    ∀ x y, succ x = succ y → x = y := by
  intro x y h
  exact (pred_succ x).symm.trans ((congrArg pred h).trans (pred_succ y))

theorem successor_nonzero
    (zero : A) (succ pred : A → A)
    (pred_zero : pred zero = zero)
    (pred_succ : ∀ n, pred (succ n) = n)
    (separation : zero ≠ succ zero) :
    ∀ n, succ n ≠ zero := by
  intro n hn
  have nz : n = zero :=
    (pred_succ n).symm.trans ((congrArg pred hn).trans pred_zero)
  exact separation (hn.symm.trans (congrArg succ nz))

theorem selector_same
    (zero : A) (succ pred : A → A) (select : A → A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (select_zero : ∀ a b, select zero a b = a)
    (select_succ : ∀ n a b, select (succ n) a b = b) :
    ∀ n a, select n a a = a := by
  intro n a
  cases coverage n with
  | inl hz =>
    rw [hz]
    exact select_zero a a
  | inr hs =>
    rw [hs]
    exact select_succ (pred n) a a

/-
The arithmetic reflection bridge uses ONE equation-induction instance.
Every displayed operation is an arbitrary parameter; no arithmetic facts
are smuggled in through Lean's built-in natural numbers.
-/
theorem residual_identity
    (zero : A) (succ pred : A → A)
    (add sub : A → A → A) (select : A → A → A → A)
    (coverage : ∀ n, n = zero ∨ n = succ (pred n))
    (pred_zero : pred zero = zero)
    (add_zero_left : ∀ x, add zero x = x)
    (add_shift : ∀ x y, add (succ x) y = add x (succ y))
    (sub_zero : ∀ x, sub x zero = x)
    (sub_succ : ∀ x n, sub x (succ n) = pred (sub x n))
    (select_zero : ∀ a b, select zero a b = a)
    (select_succ : ∀ n a b, select (succ n) a b = b)
    (y : A)
    (gate : Propagation zero succ
      (fun n => select (sub y n) y (add n (sub y n)) = y)) :
    ∀ n, select (sub y n) y (add n (sub y n)) = y := by
  have same : ∀ n a, select n a a = a :=
    selector_same zero succ pred select coverage select_zero select_succ
  apply equation_induction zero succ
    (fun n => select (sub y n) y (add n (sub y n))) (fun _ => y) gate
  · rw [sub_zero, add_zero_left]
    exact same y y
  · intro n ih
    cases coverage (sub y n) with
    | inl hz =>
      rw [sub_succ, hz, pred_zero, select_zero]
    | inr hs =>
      have selected : select (sub y n) y (add n (sub y n)) =
          add n (sub y n) := by
        rw [hs]
        exact select_succ (pred (sub y n)) y (add n (succ (pred (sub y n))))
      have old : add n (sub y n) = y := selected.symm.trans ih
      have next : add (succ n) (pred (sub y n)) = y :=
        (add_shift n (pred (sub y n))).trans
          ((congrArg (add n) hs.symm).trans old)
      rw [sub_succ, next]
      exact same (pred (sub y n)) y

theorem equality_reflection_from_residual
    (zero : A) (succ : A → A)
    (add sub : A → A → A) (select : A → A → A → A)
    (succ_injective : ∀ x y, succ x = succ y → x = y)
    (add_one : ∀ x, add x (succ zero) = succ x)
    (diagonal : ∀ x, sub (succ x) x = succ zero)
    (select_succ : ∀ n a b, select (succ n) a b = b)
    (residual : ∀ n y, select (sub y n) y (add n (sub y n)) = y) :
    ∀ x y, sub (succ x) y = succ zero ↔ x = y := by
  intro x y
  constructor
  · intro h
    have r := residual y (succ x)
    rw [h, select_succ, add_one] at r
    exact (succ_injective y x r).symm
  · intro h
    exact (congrArg (sub (succ x)) h.symm).trans (diagonal x)

theorem induction_through_reflection
    (zero : A) (succ : A → A) (E : A → Prop) (error : A → A)
    (reflection : ∀ n, E n ↔ error n = zero)
    (gate : Propagation zero succ (fun n => error n = zero))
    (base : E zero) (step : ∀ n, E n → E (succ n)) :
    ∀ n, E n := by
  have all : ∀ n, error n = zero :=
    equation_induction zero succ error (fun _ => zero) gate
      ((reflection zero).mp base)
      (by
        intro n hn
        exact (reflection (succ n)).mp (step n ((reflection n).mpr hn)))
  intro n
  exact (reflection n).mpr (all n)

#print axioms separation_of_reflexive_gate
#print axioms equation_induction
#print axioms coverage_from_guard
#print axioms propagation_from_induction
#print axioms successor_injective
#print axioms successor_nonzero
#print axioms selector_same
#print axioms residual_identity
#print axioms equality_reflection_from_residual
#print axioms induction_through_reflection

end PRAKernel
