Native certificate examples
============================

Each JSON file is [context, conclusion, proof]. Run:

    python3 ../checker.py reflexivity.json

Terms use -1 for numerical zero, integers >=0 for de Bruijn variables,
["s",t] for successor, and ["r",n,a,h] for initialized recursion.
Formula forms are ["=",s,t], ["pi",A,B], and ["ex",A].

Proofs use exact integer context indices (negative indices count from the
end), ["pi",A,q] and ["ex",t,q] for introductions, ["r",n,a,h] for
one-step recursion equations, and ["nat",P,q] for the numerical rule.
Applications are [major,t,minor] for Pi elimination,
[major,F,minor] for equality transport, and [major,branch] for
existential elimination. There is no application tag.

All 20 examples were transported from the pinned strict compact draft.
Original filenames are retained for provenance. In particular, the files
named literal_pi_hypothesis.json and literal_ex_hypothesis.json now select
their assumptions by integer index; their names describe the source test.

The examples include reflexivity, numerical coverage, quantified witness
construction, elementary addition and truncated-subtraction identities,
successor injectivity, and the arithmetic equality-test lemmas used in
the report. Their source locations and hashes are in
../validation/source_manifest.json; ../validation/translate.py can
translate them back to the frozen reference representation.
