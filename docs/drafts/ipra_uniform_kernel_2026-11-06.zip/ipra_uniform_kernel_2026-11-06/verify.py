"""Reproduce finite executable checks; no helper here is trusted by checker.py.

1. Recheck all 123 inherited certificate outcomes, verifying frozen hashes.
2. Build new derivations with explicit claims and replay them in both kernels.
3. Reject malformed hidden annotations, including strict-arity probes.
4. Compare binding operations with the preceding independent implementation.
5. Exercise each saved certificate through normal and optimized Python CLIs.

The separate independent named-variable oracle is supplied by another audit.
These tests do not claim a Lean/Rocq formalization or a general soundness proof.
"""

from pathlib import Path
import hashlib
import importlib.util
import json
import random
import subprocess
import sys

import checker as candidate
import build_proofs
import translate

ROOT = Path(__file__).resolve().parent
BASELINE_PATH = ROOT / "verification" / "baseline_composed.py"
_spec = importlib.util.spec_from_file_location("preceding_composed_checker", BASELINE_PATH)
baseline = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(baseline)
ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)


def ensure(condition, detail):
    if not condition:
        raise AssertionError(detail)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def accepts(module, document):
    try:
        return module.check(document) is True
    except ERRORS:
        return False


def negative_examples():
    z = candidate.ZERO
    t = ["=", z, z]
    theorem = ["hyp", t]
    yield "excess_equality_template_child", [[t], t,
        ["use", theorem, ["=", 0, z, z], theorem]]
    yield "excess_sigma_goal_child", [[["sig", t, t]], t,
        ["use", ["hyp", ["sig", t, t]], ["=", z, z, z], theorem]]
    yield "missing_equality_template_child", [[t], t,
        ["use", theorem, ["=", 0], theorem]]
    yield "unknown_annotation_tag", [[t], t,
        ["use", theorem, ["unknown", 0, z], theorem]]
    yield "unhashable_annotation_tag", [[t], t,
        ["use", theorem, [["="], 0, z], theorem]]
    # A zero-counter computation may not skip validation of its unused
    # body. Without that check, this double use would derive the valid T.
    for name, body in (("formula", ["pi", t, t]), ("boolean", True),
                       ("negative", -2)):
        bad = ["rec", ["r", z, z, body]]
        yield "unused_recursion_body_" + name, [[], t,
            ["use", bad, ["=", 0, z], bad]]


def binding_differential():
    rng = random.Random(744)

    def term(depth):
        if depth <= 0:
            return rng.randrange(-1, 7)
        op = rng.randrange(4)
        if op < 2:
            return rng.randrange(-1, 7)
        if op == 2:
            return ["s", term(depth - 1)]
        return ["r", term(depth - 1), term(depth - 1), term(depth - 1)]

    def formula(depth):
        if depth <= 0 or rng.randrange(3) == 0:
            return ["=", term(3), term(3)]
        return [rng.choice(["pi", "sig"]), formula(depth - 1), formula(depth - 1)]

    for number in range(2000):
        is_formula = number % 2 == 0
        a = formula(3) if is_formula else term(4)
        ensure(candidate.subst(a, formula=is_formula) == a,
               ("identity_validation", number))
        env = [term(3) for _ in range(20)]
        ensure(candidate.subst(a, lambda i: env[i]) == baseline.subst(a, lambda i: env[i]),
               ("substitution", number))
        for amount in (0, 1, 2, 3):
            ensure(candidate.shift(a, amount) == baseline.shift(a, amount),
                   ("shift", number, amount))
        witness = term(3)
        ensure(candidate.inst(a, witness) == baseline.inst(a, witness),
               ("instantiation", number))
    return {"random_seed": 744, "identity_validations": 2000,
            "substitution_comparisons": 2000, "nonnegative_shift_comparisons": 8000,
            "instantiation_comparisons": 2000}


def main():
    index = json.loads((ROOT / "verification" / "inherited_index.json").read_text())
    ensure(len(index["certificates"]) == 123, "inherited fixture count changed")
    ensure(sha256(BASELINE_PATH) == index["baseline_sha256"], "baseline checksum mismatch")
    cli = []
    inherited = {"accepted": [], "rejected": []}
    new_positive = []
    new_negative = []

    for record in index["certificates"]:
        path = ROOT / record["file"]
        ensure(sha256(path) == record["sha256"], ("fixture checksum", path.name))
        document = json.loads(path.read_text())
        expected = record["expected"]
        ensure(accepts(candidate, document) == expected, ("candidate inherited", path.name))
        ensure(accepts(baseline, document) == expected, ("baseline inherited", path.name))
        if expected:
            unchanged = translate.certificate(document)
            ensure(unchanged == document and baseline.check(unchanged),
                   ("identity bridge", path.name))
        inherited["accepted" if expected else "rejected"].append(path.name)
        cli.append((path, expected))

    positive_folder = ROOT / "certificates" / "new"
    negative_folder = ROOT / "certificates" / "adversarial"
    positive_folder.mkdir(parents=True, exist_ok=True)
    negative_folder.mkdir(parents=True, exist_ok=True)
    for name, document in build_proofs.examples().items():
        ensure(candidate.check(document), ("candidate new", name))
        ensure(baseline.check(document), ("baseline new", name))
        ensure(translate.certificate(document) == document, ("new identity bridge", name))
        path = positive_folder / (name + ".json")
        path.write_text(json.dumps(document, separators=(",", ":")) + "\n")
        new_positive.append(name)
        cli.append((path, True))
    for name, document in negative_examples():
        ensure(not accepts(candidate, document), ("candidate adversarial", name))
        ensure(not accepts(baseline, document), ("baseline adversarial", name))
        path = negative_folder / (name + ".json")
        path.write_text(json.dumps(document, separators=(",", ":")) + "\n")
        new_negative.append(name)
        cli.append((path, False))

    differential = binding_differential()
    for path, expected in cli:
        for optimized in (False, True):
            command = [sys.executable, "-B", *(["-O"] if optimized else []),
                       str(ROOT / "checker.py"), str(path)]
            result = subprocess.run(command, capture_output=True, text=True)
            ensure(result.returncode == (0 if expected else 1)
                   and result.stdout.strip() == ("ACCEPT" if expected else "REJECT")
                   and not result.stderr,
                   ("CLI", path.name, optimized, result.returncode,
                    result.stdout, result.stderr))

    summary = {
        "status": "PASS",
        "repository_commit": index["repository_commit"],
        "checker_sha256": sha256(ROOT / "checker.py"),
        "baseline_sha256": sha256(BASELINE_PATH),
        "inherited_certificate_outcomes": len(index["certificates"]),
        "inherited_accepted": len(inherited["accepted"]),
        "inherited_rejected": len(inherited["rejected"]),
        "new_positive_derivations": len(new_positive),
        "new_adversarial_rejections": len(new_negative),
        "identity_certificate_bridge_checks": len(inherited["accepted"]) + len(new_positive),
        "normal_and_optimized_cli_runs": 2 * len(cli),
        "differential_binding_checks": differential,
        "new_positive_names": new_positive,
        "new_adversarial_names": new_negative,
        "inherited_names": inherited,
        "scope": "Finite regression, identity-translation replay, and differential checks; no universal machine-checked soundness theorem is claimed.",
    }
    summary_path = ROOT / "verification" / "test_report.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    compact = {key: value for key, value in summary.items()
               if not key.endswith("_names") and key != "scope"}
    text = json.dumps(compact, indent=2) + "\n"
    (ROOT / "verification" / "test_run.txt").write_text(text)
    print(text, end="")


if __name__ == "__main__":
    main()
