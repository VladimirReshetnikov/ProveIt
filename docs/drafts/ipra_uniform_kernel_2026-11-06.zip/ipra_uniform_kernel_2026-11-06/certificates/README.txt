Executable proof certificates
=============================

Each JSON document has the same three-item envelope as the preceding
composed draft: [assumptions, goal, proof].

inherited/
  The 123 verbatim archived certificates from the composed draft pinned in
  verification/inherited_index.json. There are 77 accepted and 46 rejected
  cases. Names beginning reject_ are intentionally invalid; do not treat
  this directory as an all-positive test suite.

new/
  Twelve additional positive derivations built by build_proofs.py. These
  include derived equality rules, nested Pi/Sigma witnesses, compilation of
  ordinary existential introduction, an equation-induction proof for
  successor iteration, quantified numerical cases with no induction
  hypothesis, structural arithmetic explosion, and substitutions throughout
  proofs with local binders. Goals are explicitly written in the builder;
  they are not inferred from the proof to manufacture matching tests.

adversarial/
  Eight additional invalid documents. These probe excess/missing arities,
  invalid tags, and malformed recursion bodies hidden in otherwise useful
  computations. These must be rejected.

Run from the archive root:
  python3 checker.py certificates/new/equation_induction_successor_iteration.json
  python3 verify.py

The first command prints ACCEPT. The second verifies all saved outcomes,
replays positive certificates in the frozen preceding checker, and runs
normal and optimized Python command-line checks.
