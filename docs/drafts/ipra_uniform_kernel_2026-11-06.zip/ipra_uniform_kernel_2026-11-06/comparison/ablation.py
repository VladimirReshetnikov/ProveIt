"""Verify that the structural gain survives restoring a named zero constant."""

import json
from pathlib import Path
from census import FIELDS, measure


HERE = Path(__file__).resolve().parent
source = (HERE.parent / "checker.py").read_text()
restored = source.replace("import sys\n", "import sys\n\nZERO = -1\n")
restored = restored.replace("if n == -1:", "if n == ZERO:")
restored = restored.replace("base = subst(a, [-1, 0])", "base = subst(a, [ZERO, 0])")
control = HERE / "controls" / "named_zero.py"
if control.read_text() != restored:
    raise ValueError("Named-zero control is not exactly the stipulated change")
metrics = measure(restored.encode())
minimum = json.loads((HERE / "manifest.json").read_text())["reference_envelope"]
strict = {key: metrics[key] < minimum[key] for key in FIELDS}
result = {"change": "Restore ZERO = -1 and its two arithmetic references only.",
          "control": str(control.relative_to(HERE.parent)),
          "metrics": metrics, "strictly_below_finite_envelope": strict}
(HERE / "ablation.json").write_text(json.dumps(result, indent=2) + "\n")
if not all(strict.values()):
    raise ValueError("Structural improvement did not survive this control")
print("Named-zero control remains below all five finite minima.")
