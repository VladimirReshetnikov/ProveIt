FROZEN COMPLETE-CHECKER COMPARISON

The six current archives were read from VladimirReshetnikov/ProveIt at commit
820ef51b6ad3c13ce4a500673a9e81d951fbc06c. archive_provenance.json preserves their
exact GitHub filenames and paths, byte sizes, Git blob SHA-1 identifiers,
additional archive SHA-256 hashes, and byte-level verification results.

Run from any working directory:
    python3 /path/to/ipra_uniform_kernel_2026-11-06/measure.py
    python3 /path/to/ipra_uniform_kernel_2026-11-06/measure.py --require-improvement

The second command requires checker.py to be strictly smaller on every one
of five metrics: original-source significant tokens, normalized tokens, AST
nodes, normalized UTF-8 bytes, and raw source bytes. All comparator hashes
are checked first. Comparator code is parsed/tokenized, never imported or
executed. Only the measurement implementation in comparison/census.py is
imported. Results are written to metrics.json, table.tex, and macros.tex.

BOUNDARY AND COUNTS
The six extracted archives contained 890 Python source occurrences and 241
distinct source byte strings. The independent census identified 161 standalone
checker candidates and 74 recorded historical dependency groups. Groups overlap
standalone candidates and one another; these numbers are not a count of
independent mathematical theories. All recorded group dependencies were found.
Exactly 197 frozen source files suffice for every selected comparison boundary.

sources/ contains those exact files, named by SHA-256. manifest.json identifies
their occurrences in the pinned archives, standalone boundaries, complete
historical dependency groups, and the six primary checkers. coverage.json
records the full census totals and excluded components/support scripts.

All standalone candidates import only json and/or sys. Three legacy candidates
are class-based and were retained from the recorded standalone inventories.
The automatic standalone criterion for other files was top-level infer/check,
a CLI, and only json/sys imports. A multi-module checker is counted with all
its recorded source dependencies and adapter, never by its smallest component.

Excluded sources include adapters, build scripts, proof translators, validators,
measurement scripts, and partial syntax/arithmetic/kernel layers. Every excluded
source beating at least one coordinate of the resulting envelope was inspected
by role and imports. For example, the 619-token Hilbert layer imports syntax and
arithmetic; the 611-token guarded-binder kernel imports shared. A 674-token file
with 709 AST nodes and 1949 normalized bytes is a syntax layer without a checker.
None of these is a smaller complete standalone implementation.

MEASUREMENT DEFINITIONS
The complete executable source is counted, including imports, grammar validation,
substitution/binding operations, arithmetic and logical rules, goal comparison,
JSON input, the CLI, and rejection handling. Python and its standard JSON parser
are common platform assumptions. Comments, docstrings, and layout are excluded
from syntax-oriented metrics; raw bytes include them. The AST count includes
expression-context nodes. Normalized bytes and normalized tokens use ast.unparse
on the docstring-stripped AST, with one final newline.

Under Python 3.12.14 the observed coordinatewise envelope is:
    source tokens 664; normalized tokens 662; AST nodes 712;
    normalized bytes 2150; raw bytes 2441.
Inferred elimination attains the first four coordinates; compact kernel without
'(2)' attains raw bytes. The envelope is unchanged by all included historical
checker boundaries. Historical groups alone have the larger envelope:
    1089, 1089, 1154, 3486, 3817, in the same metric order.

LIMITS
This is a finite implementation comparison, not a lower bound on all possible
proof checkers or an absolute minimality theorem. Inclusion does not certify
every historical checker as sound or complete. Some old programs use differing
public falsity aliases or metadata conventions; canonical competitors are
counted favorably. Raw bytes are sensitive to prose and identifier spelling;
AST/token counts reduce that sensitivity. Python's AST normalization can change
across versions. measure.py records the runtime and reports any change from
the frozen reference envelope, always comparing freshly measured programs.
