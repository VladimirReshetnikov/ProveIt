SOURCE COMPARISON
=================

Run python3 measure.py from the archive's root directory. The program checks
every stored comparator hash, parses sources without importing or executing
them, measures the current checker.py, and regenerates verification/metrics.json,
verification/metrics_macros.tex and verification/comparison_table.tex.

PROVENANCE AND COVERAGE

provenance.json identifies all six ZIP archives in ProveIt/docs/drafts at
36fb791c722edc2549719744c38feef74fa422fb. Their SHA-256 digests and Git blob
SHA-1 identities were computed from the downloaded bytes. Every copied Python
file is an exact ZIP member. Identical bytes share one SHA-256-named snapshot.

manifest.json records six primary checker implementations and preserves the
initial 55-entry main/control/provenance subset (49 distinct source files).
This subset includes some older checker copies carried inside the current
archives; it is not a count of 55 independent current proposals.

An expanded census parsed every nested .py member in all six archives. It
found 233 occurrences of standalone JSON/CLI checker programs, representing
76 distinct byte hashes. These programs import only json/sys, include their
syntax validation, and have actual __main__ entrypoints. There are 73 functional
check/infer programs and three self-contained Arithmetic/Checker class-based
programs. The manifest records all their archive origins, grammar entrypoints,
and imports. Their whole-source coordinate minima equal those of the six
primary implementations.

For an additional check, the manifest carries all 230 groups from the composed
draft's supplied historical inventory, covering 74 distinct source sets. Of
these entries, 61 are labeled complete by that inventory; some others are
explicit favorable core-only comparisons. Their declared boundaries and file
closures are preserved verbatim in substance. They are supplementary grouped
size checks, not 230 new independently certified complete implementations.
Every listed file is charged when a group is counted. None of these historical
grouped counts lowers the standalone frontier. The complete collection uses
112 distinct Python source snapshots.

COUNTING CONVENTION

The headline token count uses lexical tokens in the original source, excluding
comments, whitespace/layout tokens and genuine initial module/function/class
docstrings. Redundant punctuation in the original source still counts.

AST counts remove only those docstrings; operators and contexts count as nodes.
Normalized bytes are the UTF-8 length of ast.unparse on that tree, with a final
newline. Normalized-token counts are recorded separately because ast.unparse
can alter punctuation. In particular the compact primary checker has 981
original-source tokens but 989 normalized tokens. The proposed checker has
the same token count under both conventions. Python's exact version is recorded.

Every acceptance-relevant line in each complete checker is counted: imports,
fixed tables, syntax validation, binding/substitution, all rules and schemas,
public falsity conversion, and JSON/CLI handling. Python and the standard
library are the common runtime boundary for all programs. Test/build/compiler
scripts are not included in a checker's count unless that checker imports them.

LIMITS

These are attained implementation minima within the recorded finite corpus,
not mathematical lower bounds on all possible proof checkers. Different
coordinate minima can be attained by different programs. A source-size audit
does not prove every historical calculus sound or bi-interpretable with iPRA;
the mathematical argument for the proposed checker is in the report. The
supplementary inherited inventories are not silently promoted to full public
theories when their source boundary says otherwise.
