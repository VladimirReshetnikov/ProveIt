"""Source-only checker metrics: no measured program is imported or executed.

The entire input source is counted. Python AST/context nodes are included;
comments, docstrings, and layout are removed for syntax-oriented metrics.
The original measurement implementation is independently derived from
the metric definitions retained in the source drafts.
"""
import ast
import copy
import hashlib
import io
import tokenize

FIELDS = ('source_tokens', 'normalized_tokens', 'ast_nodes', 'normalized_bytes', 'raw_bytes')
IGNORED = {tokenize.ENCODING, tokenize.COMMENT, tokenize.NL, tokenize.NEWLINE,
           tokenize.INDENT, tokenize.DEDENT, tokenize.ENDMARKER}


def docstrings(tree):
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str):
                yield first


def count_tokens(text, omitted=()):
    return sum(token.type not in IGNORED and not any(a <= token.start and token.end <= b for a, b in omitted)
               for token in tokenize.generate_tokens(io.StringIO(text).readline))


def measure(data):
    source = data.decode('utf-8')
    tree = ast.parse(source)
    spans = [((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset)) for node in docstrings(tree)]
    stripped = copy.deepcopy(tree)
    to_remove = {id(node) for node in docstrings(stripped)}
    for node in ast.walk(stripped):
        if hasattr(node, 'body') and isinstance(node.body, list):
            node.body = [child for child in node.body if id(child) not in to_remove]
    normalized = ast.unparse(stripped) + '\n'
    functions = [node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    imports = sorted({alias.name.split('.')[0] for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names}
                     | {node.module.split('.')[0] for node in ast.walk(tree) if isinstance(node, ast.ImportFrom) and node.module})
    has_cli = any(isinstance(node, ast.If) and isinstance(node.test, ast.Compare)
                  and isinstance(node.test.left, ast.Name) and node.test.left.id == '__name__' for node in tree.body)
    return {'sha256': hashlib.sha256(data).hexdigest(),
            'normalized_sha256': hashlib.sha256(normalized.encode()).hexdigest(),
            'source_tokens': count_tokens(source, spans), 'normalized_tokens': count_tokens(normalized),
            'ast_nodes': sum(1 for _ in ast.walk(stripped)), 'normalized_bytes': len(normalized.encode()),
            'raw_bytes': len(data), 'top_level_functions': functions, 'imports': imports, 'has_cli': has_cli}


def envelope(rows):
    return {field: min(row[field] for row in rows) for field in FIELDS}


