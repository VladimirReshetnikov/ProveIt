"""Identity certificate bridge to/from the preceding composed checker.

The calculus, public syntax, and proof-record format did not change. Hence
no proof expansion or falsity conversion is required for this bridge.
verify.py replays the unchanged result using the frozen preceding checker.
This convenience module is untrusted and is never imported by checker.py.
"""

from pathlib import Path
import json
import sys

import checker


def certificate(document):
    checker.check(document)
    return json.loads(json.dumps(document))


def main():
    if len(sys.argv) not in (2, 3):
        raise SystemExit("usage: translate.py INPUT.json [OUTPUT.json]")
    result = certificate(json.loads(Path(sys.argv[1]).read_text()))
    text = json.dumps(result, separators=(",", ":")) + "\n"
    if len(sys.argv) == 3:
        Path(sys.argv[2]).write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
