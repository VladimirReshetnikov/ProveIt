"""Run the pinned source comparison and certificate audits offline."""

from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


if __name__ == "__main__":
    for command in (
        [sys.executable, "measure.py", "--require-improvement"],
        [sys.executable, "comparison/ablation.py"],
        [sys.executable, "validation/run_tests.py"],
    ):
        subprocess.run(command, cwd=ROOT, check=True)
    print("Comparison and certificate verification passed.")
