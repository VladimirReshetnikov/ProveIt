"""Untrusted proof construction examples; checker.py never imports this module.

The helpers build ordinary derivations in the unchanged composed-kernel
certificate language. Every generated certificate is also replayed by the
frozen preceding checker in verify.py. Expected formulas below are explicit.
"""

from pathlib import Path
import json

import checker as k

Z = k.ZERO
T = ["=", Z, Z]
F = ["=", Z, ["s", Z]]


def eq(s, t):
    return ["=", s, t]


def hyp(a):
    return ["hyp", a]


def lift(env):
    return lambda i: i if i == 0 else k.shift(env(i - 1))


def substitute_proof(proof, context, env):
    """Admissible number substitution, including the proof's local binders."""
    def sub(p):
        return substitute_proof(p, context, env)

    match proof:
        case ["hyp", key]:
            # Use the stored wellformed formula, just as the kernel does.
            return hyp(k.subst(context[context.index(key)], env))
        case ["rec", r]:
            return ["rec", k.subst(r, env)]
        case ["nat", matrix]:
            return ["nat", k.subst(matrix, lift(env))]
        case ["pi", guard, body]:
            extended = [*map(k.shift, context), guard]
            return ["pi", k.subst(guard, lift(env)),
                    substitute_proof(body, extended, lift(env))]
        case ["pair", witness, left, right]:
            extended = [*map(k.shift, context), eq(0, k.shift(witness))]
            return ["pair", k.subst(witness, env),
                    substitute_proof(left, extended, lift(env)),
                    substitute_proof(right, extended, lift(env))]
        case ["use", principal, annotation, minor]:
            conclusion = k.infer(principal, context)
            if conclusion[0] == "sig":
                extended = [*map(k.shift, context), *conclusion[1:]]
                return ["use", sub(principal), k.subst(annotation, env),
                        substitute_proof(minor, extended, lift(env))]
            annotation_env = lift(env) if conclusion[0] == "=" else env
            return ["use", sub(principal), k.subst(annotation, annotation_env), sub(minor)]
        case _:
            raise ValueError("unknown proof record in untrusted builder")


def shift_proof(proof, context, count=1):
    return substitute_proof(proof, context, lambda i: i + count)


def reflexivity(term):
    computation = ["rec", ["r", Z, term, Z]]
    return ["use", computation, eq(0, k.shift(term)), computation]


def symmetry(proof, left):
    return ["use", proof, eq(0, k.shift(left)), reflexivity(left)]


def transitivity(first, second, left):
    return ["use", second, eq(k.shift(left), 0), first]


def ordinary_sigma(principal, witness, left, right, context):
    """Compile ordinary existential introduction to the witness-equation rule."""
    equation = eq(0, k.shift(witness))
    backwards = symmetry(hyp(equation), 0)

    def branch(matrix, premise):
        template = k.subst(matrix, lambda i: i if i == 0 else i + 1)
        return ["use", backwards, template, shift_proof(premise, context)]

    return ["pair", witness, branch(principal[1], left), branch(principal[2], right)]


def numerical(matrix, target, base, successor, context):
    """Compile a numerical rule to the packed zero-premise numerical axiom.

    successor is a proof of A(Sy) in shifted context plus the one guard H.
    H is A(y) for literal equations; otherwise it is the shifted A(0).
    In the latter case the caller may ignore that retained base assumption.
    """
    base_formula = k.inst(matrix, Z)
    guard = matrix if matrix[0] == "=" else k.shift(base_formula)
    step = ["pi", guard, successor]
    package = ["pair", Z, shift_proof(base, context), shift_proof(step, context)]
    return ["use", ["nat", matrix], target, package]


def explosion_equation(false_proof, left, right):
    """Derive left=right from 0=S0 using only computation and replacement."""
    body = k.shift(right, 2)
    choice_zero = ["r", Z, left, body]
    choice_one = ["r", ["s", Z], left, body]
    template = eq(["r", 0, k.shift(left), k.shift(right, 3)], k.shift(left))
    at_one = ["use", false_proof, template, ["rec", choice_zero]]
    backwards = symmetry(at_one, choice_one)
    return transitivity(backwards, ["rec", choice_one], left)


def explosion(formula, false_proof, context):
    """Structural explosion for the entire native first-order formula language."""
    if formula == ["false"]:
        return false_proof
    match formula:
        case ["=", left, right]:
            return explosion_equation(false_proof, left, right)
        case ["pi", guard, body]:
            extended = [*map(k.shift, context), guard]
            return ["pi", guard, explosion(body, shift_proof(false_proof, context), extended)]
        case ["sig", left, right]:
            extended = [*map(k.shift, context), eq(0, Z)]
            shifted_false = shift_proof(false_proof, context)
            return ["pair", Z, explosion(left, shifted_false, extended),
                    explosion(right, shifted_false, extended)]
        case _:
            raise ValueError("unknown formula in untrusted explosion builder")


def examples():
    """Return explicit claims together with proofs; no goal is inferred here."""
    result = {}
    recursive_term = ["r", ["s", 2], 4, ["r", 1, 0, ["s", 0]]]
    result["reflexivity_nested_recursion"] = [[], eq(recursive_term, recursive_term),
                                              reflexivity(recursive_term)]
    assumption = eq(0, recursive_term)
    result["symmetry_with_parameters"] = [[assumption], eq(recursive_term, 0),
                                           symmetry(hyp(assumption), 0)]
    first, second = eq(0, 1), eq(1, 2)
    result["transitivity_three_parameters"] = [[first, second], eq(0, 2),
                                                transitivity(hyp(first), hyp(second), 0)]

    # For arbitrary a: for every x, x=a implies some y satisfies y=x and x=a.
    guard = eq(0, 1)
    sigma = ["sig", eq(0, 1), eq(1, 2)]
    result["nested_pi_sigma_witness"] = [[], ["pi", guard, sigma],
        ["pi", guard, ["pair", 0, hyp(eq(0, 1)), hyp(eq(1, 2))]]]

    # The ordinary introduction helper transports premises through a fresh
    # witness equation rather than requiring primitive Sigma introduction.
    sigma_refl = ["sig", eq(0, 0), eq(0, 1)]
    result["ordinary_sigma_compilation"] = [[], sigma_refl,
        ordinary_sigma(sigma_refl, 0, reflexivity(0), reflexivity(0), [])]

    # A genuine equation-induction proof: iterating successor n times from
    # zero gives n. The step uses its induction hypothesis in replacement.
    iterate = ["r", 0, Z, ["s", 0]]
    matrix = eq(iterate, 0)
    base = ["rec", ["r", Z, Z, ["s", 0]]]
    step_term = ["r", ["s", 0], Z, ["s", 0]]
    step_template = eq(k.shift(step_term), ["s", 0])
    successor = ["use", hyp(matrix), step_template, ["rec", step_term]]
    induction = numerical(matrix, 0, base, successor, [])
    result["equation_induction_successor_iteration"] = [[], matrix, induction]

    # A quantified case formula. The successor branch has NO A(y) premise;
    # it ignores the retained A(0) guard and proves successor reflexivity.
    cases_matrix = ["pi", T, eq(1, 1)]
    cases_base = ["pi", T, reflexivity(Z)]
    cases_successor = ["pi", T, reflexivity(["s", 1])]
    cases_proof = numerical(cases_matrix, 0, cases_base, cases_successor, [])
    result["quantified_cases_without_induction_hypothesis"] = [[], cases_matrix, cases_proof]

    nested_formula = ["pi", eq(0, 1),
        ["sig", eq(["r", 1, ["s", 2], ["s", 0]], 0),
         ["pi", T, eq(["r", 2, 3, ["r", 1, 0, ["s", 0]]], 1)]]]
    result["arithmetic_explosion_nested_quantifiers"] = [[F], nested_formula,
                                                         explosion(nested_formula, hyp(F), [F])]
    result["genuine_bottom_to_arithmetic_clash"] = [[["false"]], F, hyp(F)]
    result["arithmetic_clash_to_genuine_bottom"] = [[F], ["false"], hyp(F)]

    # Substitute dependent recursors for all ambient variables throughout
    # two nontrivial proofs. Local Pi/Sigma and recursion slots stay bound.
    for name in ("nested_pi_sigma_witness", "equation_induction_successor_iteration"):
        context, goal, proof = result[name]
        env = lambda i: ["r", ["s", i + 2], i + 4, ["r", 1, 0, ["s", 0]]]
        result[name + "_substituted"] = [[k.subst(a, env) for a in context],
            k.subst(goal, env), substitute_proof(proof, context, env)]
    return result


def main():
    output = Path(__file__).resolve().parent / "certificates" / "new"
    output.mkdir(parents=True, exist_ok=True)
    for name, document in examples().items():
        k.check(document)
        (output / (name + ".json")).write_text(json.dumps(document, separators=(",", ":")) + "\n")
    print(f"Wrote {len(examples())} checked example certificates")


if __name__ == "__main__":
    main()
