"""Reproduce proof transport, focused formation/scope checks, and CLI checks.

Run this file from any working directory. All dependencies are bundled or in
the Python standard library. The acceptance program imports none of them.
"""

from collections import Counter
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

from build_cases import build
from translate import (ROOT, HERE, backward, candidate, forward, manifest,
                       reference)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value, pretty=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    options = {"indent": 2} if pretty else {"separators": (",", ":")}
    path.write_text(json.dumps(value, **options) + "\n")


def replay_corpus():
    records = []
    for row in manifest["records"]:
        source_path = ROOT / row["source_path"]
        require(digest(source_path) == row["sha256"], "Changed source fixture: " + row["name"])
        data = json.loads(source_path.read_text())
        translated = forward(data)  # validates source and translated proof
        restored = backward(translated)  # validates both again
        require(data[:2] == translated[:2] == restored[:2], "Changed declared sequent")
        destination = HERE / "translated" / row["name"]
        write_json(destination, translated)
        if row["name"].startswith("examples/"):
            write_json(ROOT / row["name"], translated)
        records.append({"name": row["name"], "source_accepted": True,
                        "forward_accepted": True, "backward_accepted": True,
                        "sequent_preserved": True,
                        "translated_path": str(destination.relative_to(ROOT)),
                        "translated_sha256": digest(destination)})
    return {"source_certificates": len(records),
            "forward_transports": len(records), "backward_transports": len(records),
            "records": records}


def focused_tests():
    cases = build()
    write_json(HERE / "focused_cases.json", cases, pretty=True)
    records = []
    reverse_roundtrips = 0
    inverse_lifts = 0
    for case in cases:
        error = None
        try:
            if case["kind"] == "check":
                result = candidate.check(*case["data"])
            elif case["kind"] == "infer":
                result = candidate.infer(case["proof"], case["context"])
            else:
                result = candidate.subst(case["tree"], [None, -1], formula=case["formula"])
            accepted = True
        except Exception as exc:
            accepted = False
            error = type(exc).__name__
        require(accepted == case["expected"], "Wrong focused decision: " + case["name"])
        if accepted and case["kind"] != "check":
            require(result == case["result"], "Wrong inferred result: " + case["name"])
        if accepted and case["kind"] == "check":
            restored = backward(case["data"])
            regenerated = forward(restored)
            require(case["data"][:2] == restored[:2] == regenerated[:2],
                    "Reverse transport changed a sequent: " + case["name"])
            reverse_roundtrips += 1
        if accepted and case["kind"] == "deletion":
            require(candidate.subst(result, formula=case["formula"]) == case["tree"],
                    "Deletion failed inverse lifting: " + case["name"])
            inverse_lifts += 1
        records.append({"name": case["name"], "kind": case["kind"],
                        "expected": case["expected"], "observed": accepted,
                        "rejection_exception": error})
    counts = Counter((case["kind"], case["expected"]) for case in cases)
    return {"cases": len(cases), "positive": sum(case["expected"] for case in cases),
            "negative": sum(not case["expected"] for case in cases),
            "by_kind": {kind: {"positive": counts[kind, True], "negative": counts[kind, False]}
                        for kind in ("check", "infer", "deletion")},
            "candidate_to_reference_to_candidate_roundtrips": reverse_roundtrips,
            "inverse_lifting_checks": inverse_lifts, "records": records}, cases


def cli_tests(cases):
    by_name = {case["name"]: case for case in cases}
    selected = ["pi_application", "ex_application", "quantified_cases",
                "bad_selector_0", "unused_pi_witness_0", "unused_recursion_body_0",
                "quantified_induction_is_rejected", "escaping_eigenvariable_sequent_0",
                "bad_proof_record_11"]
    records = []
    with tempfile.TemporaryDirectory(prefix="ipra-validation-") as temporary:
        directory = Path(temporary)
        paths = [("transported_reflexivity", ROOT / "examples/reflexivity.json", True)]
        for name in selected:
            case = by_name[name]
            path = directory / (name + ".json")
            write_json(path, case["data"])
            paths.append((name, path, case["expected"]))
        malformed = directory / "malformed.json"
        malformed.write_text("[,,]\n")
        paths.append(("malformed_json", malformed, False))
        for optimized in (False, True):
            command = [sys.executable] + (["-O"] if optimized else []) + [str(ROOT / "checker.py")]
            for name, path, expected in paths:
                process = subprocess.run(command + [str(path)], capture_output=True,
                                         text=True, timeout=30)
                require(process.returncode == (0 if expected else 1), "CLI status: " + name)
                require(process.stdout.strip() == ("ACCEPT" if expected else "REJECT"),
                        "CLI output: " + name)
                require(not process.stderr, "CLI unexpected stderr: " + name)
                records.append({"name": name, "optimized": optimized, "expected": expected,
                                "exit_code": process.returncode, "stdout": process.stdout.strip()})
            missing = subprocess.run(command, capture_output=True, text=True, timeout=30)
            require(missing.returncode == 1 and missing.stdout.strip() == "REJECT"
                    and not missing.stderr, "Missing CLI path was not rejected")
            records.append({"name": "missing_path", "optimized": optimized, "expected": False,
                            "exit_code": missing.returncode, "stdout": missing.stdout.strip()})
    return {"cases": len(records), "records": records}


def main():
    corpus = replay_corpus()
    focused, cases = focused_tests()
    cli = cli_tests(cases)
    report = {
        "status": "passed", "python_version": platform.python_version(),
        "checker_sha256": digest(ROOT / "checker.py"),
        "reference_checker_sha256": manifest["reference_checker_sha256"],
        "source_repository_commit": manifest["commit"],
        "source_corpus": corpus, "focused_cases": focused, "cli_checks": cli,
        "qualification": "Finite tests and checked certificate transports support the written invariants. They are not a formal proof of soundness, completeness, bi-interpretability, or absolute minimality.",
    }
    write_json(HERE / "verification.json", report, pretty=True)
    print(json.dumps({"status": report["status"],
                      "source_certificates_transported_both_directions": corpus["source_certificates"],
                      "focused_cases": focused["cases"], "focused_negative": focused["negative"],
                      "reverse_roundtrips": focused["candidate_to_reference_to_candidate_roundtrips"],
                      "cli_checks": cli["cases"]}, indent=2))


if __name__ == "__main__":
    main()
