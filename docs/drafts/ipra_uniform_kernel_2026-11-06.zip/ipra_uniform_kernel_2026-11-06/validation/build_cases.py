"""Construct independently specified small formation, rule and scope cases.

This file does not import either checker and never asks a checker to generate
an expected result. Most rejection cases hide a malformed intermediate input
behind a constant conclusion, so outer goal validation cannot mask the issue.
"""

import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
T = ["=", -1, -1]
D = ["=", -1, ["s", -1]]
V = ["=", 0, 0]
ET = ["ex", T]
PI = ["pi", T, T]
R0 = ["r", -1, -1, 0]
RS = ["r", ["s", -1], -1, 0]


def build():
    records = []

    def check(name, data, expected):
        records.append({"name": name, "kind": "check", "expected": expected,
                        "data": data})

    def infer(name, context, proof, expected, result=None):
        records.append({"name": name, "kind": "infer", "expected": expected,
                        "context": context, "proof": proof, "result": result})

    def deletion(name, tree, expected, result=None, formula=True):
        records.append({"name": name, "kind": "deletion", "expected": expected,
                        "tree": tree, "formula": formula, "result": result})

    # Small positive certificates cover every primitive rule and both ways
    # of indexing a context. Values are written independently of the kernel.
    check("hypothesis_first", [[T], T, 0], True)
    check("hypothesis_last", [[D, T], T, -1], True)
    check("hypothesis_negative_first", [[T, D], T, -2], True)
    check("pi_formula_hypothesis", [[PI], PI, 0], True)
    check("ex_formula_hypothesis", [[ET], ET, 0], True)
    check("pi_introduction", [[], ["pi", V, V], ["pi", V, -1]], True)
    check("ex_introduction", [[], ["ex", ["=", 0, -1]], ["ex", -1, -1]], True)
    check("recursor_zero", [[], ["=", R0, -1], R0], True)
    check("recursor_successor", [[], ["=", RS, R0], RS], True)
    check("pi_application", [[PI, T], T, [0, -1, 1]], True)
    check("equality_application", [[D, T], D, [0, ["=", -1, 0], 1]], True)
    check("computed_major_application", [[T], T, [R0, T, 0]], True)
    check("ex_application", [[ET], T, [0, -1]], True)
    check("ex_application_outer_parameter", [[ET, V], V, [0, 1]], True)
    check("closed_equation_induction", [[], PI, ["nat", T, ["pi", T, -1]]], True)
    check("closed_quantified_cases", [[], ["pi", ET, ET],
                                     ["nat", ET, ["pi", ET, -1]]], True)

    # P(x) = exists y (y=x). Only cases, not induction, is permitted for P.
    p = ["ex", ["=", 0, 1]]
    p0 = ["ex", ["=", 0, -1]]
    ps = ["ex", ["=", 0, ["s", 1]]]
    conclusion = ["pi", p0, p]
    check("quantified_cases", [[["pi", p0, ps]], conclusion, ["nat", p, 0]], True)
    check("quantified_induction_is_rejected", [[["pi", p, ps]], conclusion,
                                               ["nat", p, 0]], False)
    step = ["pi", V, ["=", ["s", 0], ["s", 0]]]
    check("literal_equation_induction", [[step], ["pi", T, V], ["nat", V, 0]], True)
    q = ["=", 0, 1]
    q0 = ["=", -1, 1]
    qs = ["=", ["s", 0], 1]
    check("induction_retains_parameters", [[["pi", q, qs]], ["pi", q0, q],
                                            ["nat", q, 0]], True)

    # Exact integer selectors reject host-language bool/float aliases. Signed
    # in-range integer selectors are intentional certificate syntax.
    for number, bad in enumerate([True, False, 0.0, None, "", "pi", [], {},
                                  1, -2, T, ["s", -1]]):
        check("bad_selector_" + str(number), [[T], T, bad], False)
    check("empty_context_has_no_hypothesis", [[], D, 0], False)
    for number, context in enumerate([None, "", {}, 0, True]):
        check("bad_context_type_" + str(number), [context, T, 0], False)
    for number, formula in enumerate([0, True, 0.0, None, ["s", -1],
                                      ["=", -1], ["=", -1, -1, -1],
                                      ["pi", T, 0], ["ex", T, T],
                                      ["unknown", T]]):
        check("bad_goal_" + str(number), [[T], formula, 0], False)
        check("bad_unused_context_formula_" + str(number), [[T, formula], T, 0], False)

    # These malformed numerical trees occur where their value is unused.
    bad_terms = [None, True, 0.0, -2, {}, "", [], ["s"],
                 ["s", -1, -1], ["r", -1, -1, None], T]
    for number, witness in enumerate(bad_terms):
        check("unused_pi_witness_" + str(number), [[PI, T], T, [0, witness, 1]], False)
        check("unused_ex_witness_" + str(number), [[T], ET, ["ex", witness, 0]], False)
        check("unused_recursion_body_" + str(number), [[T], T,
              [["r", -1, -1, witness], T, 0]], False)
        check("unused_successor_initializer_" + str(number), [[T], T,
              [["r", ["s", -1], witness, -1], T, 0]], False)

    for number, guard in enumerate([0, True, None, ["=", -1], ["pi", T, 0]]):
        infer("unused_malformed_guard_" + str(number), [T], ["pi", guard, 0], False)
    for number, template in enumerate([0, False, None, ["ex", 0], ["=", -1]]):
        infer("unused_malformed_template_" + str(number), [T], [0, template, 0], False)
    for number, counter in enumerate([0, 1, R0, True, -2]):
        check("noncomputing_recursion_counter_" + str(number), [[T], T,
              [["r", counter, -1, 0], T, 0]], False)

    # A scope occurrence must be detected even underneath a local binder,
    # in a guard, or in a recursor body ignored by the zero equation.
    escape_matrices = [
        V,
        ["pi", V, ["=", 1, 1]],
        ["pi", ["=", 1, 1], T],
        ["ex", ["=", 1, -1]],
        ["=", ["r", -1, -1, 2], -1],
        ["pi", T, ["ex", ["=", ["r", -1, -1, 4], -1]]],
    ]
    for number, matrix in enumerate(escape_matrices):
        infer("escaping_eigenvariable_" + str(number), [["ex", matrix]], [0, -1], False)
        check("escaping_eigenvariable_sequent_" + str(number),
              [[["ex", matrix]], T, [0, -1]], False)

    bad_records = [
        [], ["pi"], ["pi", T], ["pi", T, 0, 0],
        ["ex"], ["ex", -1], ["ex", -1, 0, 0],
        ["r", -1, -1], ["r", -1, -1, 0, 0],
        ["nat", T], ["nat", T, 0, 0],
        ["use", 0, -1, 1], ["lam", T, 0], ["pack", -1, 0],
        ["unknown", 0], [None, -1, 1], [True, -1, 1],
        [0], [0, -1], [0, -1, 1, 1],
    ]
    for number, proof in enumerate(bad_records):
        check("bad_proof_record_" + str(number), [[PI, T], T, proof], False)
    for number, proof in enumerate([[0], [0, 0, 0], [0, -1, 0, 0]]):
        check("bad_ex_application_arity_" + str(number), [[ET], T, proof], False)
    check("wrong_application_minor", [[PI, D], T, [0, -1, 1]], False)
    check("wrong_numerical_premise", [[T], PI, ["nat", T, 0]], False)

    # Deletion expectations use explicit index arithmetic at known depths.
    deletion("closed_deletion", T, True, T)
    deletion("outer_parameter_deletion", ["=", 1, 1], True, V)
    deletion("direct_scope_escape", V, False)
    deletion("pi_bound_and_outer", ["pi", V, ["=", 2, 2]], True,
             ["pi", V, ["=", 1, 1]])
    deletion("pi_guard_escape", ["pi", ["=", 1, 1], T], False)
    deletion("ex_bound_and_outer", ["ex", ["=", 0, 2]], True,
             ["ex", ["=", 0, 1]])
    deletion("ex_matrix_escape", ["ex", ["=", 1, -1]], False)
    deletion("recursor_bound_slots", ["=", R0, ["r", -1, -1, 1]], True,
             ["=", R0, ["r", -1, -1, 1]])
    deletion("recursor_outer_parameter", ["=", ["r", -1, -1, 3], -1], True,
             ["=", ["r", -1, -1, 2], -1])
    deletion("recursor_hidden_escape", ["=", ["r", -1, -1, 2], -1], False)
    deletion("mixed_depth_outer_parameter", ["pi", T,
             ["ex", ["=", ["r", -1, -1, 5], -1]]], True,
             ["pi", T, ["ex", ["=", ["r", -1, -1, 4], -1]]])
    deletion("mixed_depth_escape", ["pi", T,
             ["ex", ["=", ["r", -1, -1, 4], -1]]], False)
    deletion("nested_recursion_outer_parameter", ["r", -1, -1,
             ["r", -1, -1, 5]], True, ["r", -1, -1, ["r", -1, -1, 4]], False)
    deletion("nested_recursion_escape", ["r", -1, -1,
             ["r", -1, -1, 4]], False, formula=False)
    return records


if __name__ == "__main__":
    records = build()
    (HERE / "focused_cases.json").write_text(json.dumps(records, indent=2) + "\n")
    print("Constructed", len(records), "independently specified cases")
