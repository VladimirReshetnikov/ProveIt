"""Untrusted, checked translations between two certificate representations.

Both directions preserve the complete declared context and conclusion. The
frozen reference uses formula-valued hypothesis leaves and lam/pack/use tags;
the candidate uses integer hypotheses, pi/ex introductions, and applications.
Neither checker imports this module.
"""

import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "validation"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


manifest = json.loads((HERE / "source_manifest.json").read_text())
reference_path = ROOT / manifest["reference_checker_path"]
if hashlib.sha256(reference_path.read_bytes()).hexdigest() != manifest["reference_checker_sha256"]:
    raise RuntimeError("The frozen reference checker was modified")
reference = load_module("strict_reference", reference_path)
candidate = load_module("uniform_candidate", ROOT / "checker.py")


def raised(context):
    return [reference.subst(a) for a in context]


def forward_proof(proof, context):
    match proof:
        case ["lam", a, q]:
            return ["pi", a, forward_proof(q, raised(context) + [a])]
        case ["pack", witness, q]:
            h = ["=", 0, reference.subst(witness, formula=False)]
            return ["ex", witness, forward_proof(q, raised(context) + [h])]
        case ["r", _, _, _]:
            return proof
        case ["nat", a, q]:
            return ["nat", a, forward_proof(q, context)]
        case ["use", major, *args]:
            translated_major = forward_proof(major, context)
            principal = reference.infer(major, context)
            if principal[0] == "ex":
                q, = args
                return [translated_major,
                        forward_proof(q, raised(context) + principal[1:])]
            a, q = args
            return [translated_major, a, forward_proof(q, context)]
        case _:
            return context.index(proof)


def backward_proof(proof, context):
    match proof:
        case ["pi", a, q]:
            return ["lam", a, backward_proof(q, raised(context) + [a])]
        case ["ex", witness, q]:
            h = ["=", 0, reference.subst(witness, formula=False)]
            return ["pack", witness, backward_proof(q, raised(context) + [h])]
        case ["r", _, _, _]:
            return proof
        case ["nat", a, q]:
            return ["nat", a, backward_proof(q, context)]
        case [major, *args]:
            translated_major = backward_proof(major, context)
            principal = reference.infer(translated_major, context)
            if principal[0] == "ex":
                q, = args
                return ["use", translated_major,
                        backward_proof(q, raised(context) + principal[1:])]
            a, q = args
            return ["use", translated_major, a, backward_proof(q, context)]
        case _:
            if type(proof) is not int:
                raise ValueError("Invalid hypothesis selector")
            return context[proof]


def forward(data):
    reference.check(data)
    context, conclusion, proof = data
    result = [context, conclusion, forward_proof(proof, context)]
    candidate.check(*result)
    return result


def backward(data):
    candidate.check(*data)
    context, conclusion, proof = data
    result = [context, conclusion, backward_proof(proof, context)]
    reference.check(result)
    return result


if __name__ == "__main__":
    import sys

    _, direction, input_path, output_path = sys.argv
    transform = {"forward": forward, "backward": backward}[direction]
    result = transform(json.loads(Path(input_path).read_text()))
    Path(output_path).write_text(json.dumps(result, separators=(",", ":")) + "\n")
