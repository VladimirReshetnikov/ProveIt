Reproducible validation
=======================

Run, from any working directory:

    python3 /path/to/package/validation/run_tests.py

The runner imports only the bundled candidate and frozen strict reference
checker, the self-contained untrusted translator, and Python's standard
library. Neither acceptance program imports this validation code.

Frozen source material
----------------------
source_manifest.json pins the repository commit, archive Git blob and
SHA-256, checker hash, original member paths, and individual fixture hashes.
reference_checker.py is the exact strict checker from
ipra_compact_kernel_2026-11-06(2).zip at repository commit
820ef51b6ad3c13ce4a500673a9e81d951fbc06c.

source_corpus/ contains all 150 current-format positive certificates from
that draft's validation/translated/ directory, plus its two additional
Pi/Ex-hypothesis examples. Thus all 20 source examples are included, with
152 source certificates in total. The older test framework and its large
historical dependency tree are not needed or copied.

Proof transport
----------------
translate.py validates its source certificate before translating. In the
forward direction it replaces formula-valued hypothesis leaves by context
indices, renames lam/pack introductions to pi/ex, and removes use tags.
In the reverse direction it restores the selected context formula and
those tags. It checks the translated proof with the target checker.

Both directions retain the complete declared context and conclusion.
The source-to-candidate-to-source checks regenerate translated/ and all
20 native examples in ../examples/. Signed negative context selectors,
which intentionally denote positions from the end of the context, are
additionally exercised by candidate-to-source-to-candidate round trips.
Boolean and floating-point selectors are rejected.

The public command-line translator is:

    python3 validation/translate.py forward INPUT.json OUTPUT.json
    python3 validation/translate.py backward INPUT.json OUTPUT.json

Focused tests
--------------
build_cases.py constructs 168 small cases without importing either checker
or using a checker to generate expectations. focused_cases.json records
the actual inputs and expected decisions/results. The cases cover:

* all primitive rule families and both signed selector conventions;
* wrong formula, term, selector and context types and wrong arities;
* malformed unused universal and existential witnesses;
* malformed recursor bodies and initializers hidden by constant transport;
* freshness under either formula binder, in Pi guards, and in unused
  recursion bodies, including multiple nested binder depths;
* literal-equation induction versus quantified numerical cases;
* application syntax and rejection of obsolete or unknown proof tags.

There are 19 positive and 119 negative whole-sequent cases, 16 negative
direct-inference cases, and 14 independently specified deletion cases
(8 positive and 6 negative): 27 positives and 141 negatives in total.
The 19 positive candidate certificates also undergo checked reverse and
forward transports; the 8 successful deletions satisfy inverse lifting.

The CLI checks run 12 representative inputs under both normal Python and
python -O, including malformed JSON and a missing file argument. They
require exact ACCEPT/REJECT output, the correct exit status, and no stderr.

verification.json records the executed results and checker hashes.
These finite tests support the written invariants. They are not a formal
proof of soundness, completeness, bi-interpretability, or minimality.

