"""Compile the supplied LaTeX report and package the reviewed deliverables."""

import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
SKIP_SUFFIXES = {".aux", ".log", ".out", ".toc", ".pyc", ".synctex.gz"}


def deliverables():
    return sorted(path for path in ROOT.rglob("*") if path.is_file()
                  and "__pycache__" not in path.parts
                  and path.suffix not in SKIP_SUFFIXES
                  and path.name != "SHA256SUMS.txt")


def compile_pdf():
    with tempfile.TemporaryDirectory(prefix="ipra_tex_") as directory:
        environment = os.environ.copy()
        probe = subprocess.run(["kpsewhich", "pdflatex.fmt"],
                               capture_output=True, text=True)
        if not probe.stdout.strip():
            creation = subprocess.run(
                ["pdftex", "-ini", "-etex", "-jobname=pdflatex",
                 "-progname=pdflatex", "pdflatex.ini"], cwd=directory,
                capture_output=True, text=True)
            if creation.returncode:
                raise RuntimeError(creation.stdout[-12000:] + creation.stderr)
            environment["TEXFORMATS"] = directory + os.pathsep + environment.get("TEXFORMATS", "")
        for attempt in range(3):
            result = subprocess.run(
                ["pdflatex", "-interaction=nonstopmode", "-halt-on-error",
                 "-file-line-error", "-output-directory=" + directory, "report.tex"],
                cwd=ROOT, env=environment, capture_output=True, text=True)
            if result.returncode:
                raise RuntimeError(result.stdout[-12000:] + result.stderr)
            log = (Path(directory) / "report.log").read_text(errors="replace")
            if attempt >= 1 and "Rerun to get" not in log:
                break
        failures = ("Overfull \\hbox", "Overfull \\vbox", "undefined references",
                    "Citation `", "Reference `")
        if any(marker in log for marker in failures):
            raise RuntimeError("Inspect the LaTeX layout/reference warnings:\n" +
                               "\n".join(line for line in log.splitlines()
                                         if any(marker in line for marker in failures)))
        shutil.copyfile(Path(directory) / "report.pdf", ROOT / "report.pdf")
    print("Built", ROOT / "report.pdf")


def package():
    if not (ROOT / "report.pdf").is_file():
        raise FileNotFoundError("Compile report.pdf before packaging")
    entries = deliverables()
    checksum_file = ROOT / "SHA256SUMS.txt"
    checksum_file.write_text("".join(
        hashlib.sha256(path.read_bytes()).hexdigest() + "  " +
        path.relative_to(ROOT).as_posix() + "\n" for path in entries), encoding="utf-8")
    target = ROOT.parent / (ROOT.name + ".zip")
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for path in sorted([*entries, checksum_file]):
            archive.write(path, ROOT.name + "/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("ZIP integrity failure")
        for path in entries:
            name = ROOT.name + "/" + path.relative_to(ROOT).as_posix()
            if archive.read(name) != path.read_bytes():
                raise RuntimeError("Packaged bytes differ: " + name)
    print("Packaged", len(entries) + 1, "files into", target)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-only", action="store_true")
    parser.add_argument("--pdf-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        compile_pdf()
    if not args.pdf_only:
        package()
