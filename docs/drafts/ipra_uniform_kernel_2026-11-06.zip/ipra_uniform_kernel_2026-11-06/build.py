"""Compile report.tex with three ordinary pdflatex passes."""

import os
from pathlib import Path
import shutil
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parent


def main():
    compiler = shutil.which("pdflatex")
    if compiler is None:
        raise SystemExit("pdflatex is required; install a standard TeX Live distribution.")
    env = os.environ.copy()
    env.setdefault("SOURCE_DATE_EPOCH", "1794015383")
    env.setdefault("FORCE_SOURCE_DATE", "1")
    with tempfile.TemporaryDirectory(prefix="ipra-tex-") as temporary:
        for number in range(3):
            run = subprocess.run(
                [compiler, "-interaction=nonstopmode", "-halt-on-error",
                 "-output-directory=" + temporary, "report.tex"],
                cwd=ROOT, env=env, capture_output=True, text=True,
            )
            if run.returncode:
                print(run.stdout[-12000:])
                print(run.stderr)
                raise SystemExit("LaTeX compilation failed on pass " + str(number + 1))
        log = (Path(temporary) / "report.log").read_text(errors="replace")
        (ROOT / "validation" / "latex.log").write_text(log)
        shutil.copyfile(Path(temporary) / "report.pdf", ROOT / "report.pdf")
        warnings = [line for line in log.splitlines()
                    if "Overfull" in line or "undefined" in line or "LaTeX Warning" in line]
        for line in warnings:
            print(line)
    print("Created report.pdf")


if __name__ == "__main__":
    main()
