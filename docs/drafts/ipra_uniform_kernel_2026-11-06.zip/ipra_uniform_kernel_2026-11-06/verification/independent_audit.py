"""Independent audit of an iPRA JSON checker.

Usage: python3 independent_audit.py /absolute/path/to/checker.py [results.json]

The expected binding operations come from a named-variable oracle. It parses
bound variables to fresh Python object identities, substitutes *free names*
without numerical shifting, and re-encodes only at the end. It imports no
candidate traversal, scope table, formatter, or proof-generating helper.
This is finite validation evidence, not a formal proof of kernel correctness.
"""

import copy
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile


ERRORS = (ValueError, TypeError, IndexError, KeyError, RecursionError)
ZERO = -1
TRUTH = ["=", ZERO, ZERO]
CLASH = ["=", ZERO, ["s", ZERO]]


class BadSyntax(ValueError):
    pass


def node_parts(a, tag, arity):
    if type(a) is not list or len(a) != arity + 1 or a[0] != tag:
        raise BadSyntax("wrong constructor or arity")
    return a[1:]


def named_term(a, bound=()):
    """Decode indices to free numerical names and fresh bound identities."""
    if type(a) is int:
        if a == ZERO:
            return ("zero",)
        if a < 0:
            raise BadSyntax("negative variable")
        return ("bound", bound[a]) if a < len(bound) else ("free", a - len(bound))
    if type(a) is not list or not a or type(a[0]) is not str:
        raise BadSyntax("not a term")
    if a[0] == "s":
        (body,) = node_parts(a, "s", 1)
        return ("succ", named_term(body, bound))
    if a[0] == "r":
        counter, initial, body = node_parts(a, "r", 3)
        state_name, counter_name = object(), object()
        return ("rec", named_term(counter, bound), named_term(initial, bound),
                state_name, counter_name,
                named_term(body, (state_name, counter_name) + bound))
    raise BadSyntax("formula or unknown constructor in term position")


def named_formula(a, bound=(), allow_bottom=False):
    if type(a) is not list or not a or type(a[0]) is not str:
        raise BadSyntax("not a formula")
    if a[0] == "=" and len(a) == 3:
        return ("eq", named_term(a[1], bound), named_term(a[2], bound))
    if allow_bottom and a == ["false"]:
        return ("bottom",)
    if a[0] in ("pi", "sig") and len(a) == 3:
        name = object()
        return (a[0], name,
                named_formula(a[1], (name,) + bound, allow_bottom),
                named_formula(a[2], (name,) + bound, allow_bottom))
    raise BadSyntax("term, unknown constructor, or wrong formula arity")


def encode_named(a, bound=()):
    tag = a[0]
    if tag == "zero":
        return ZERO
    if tag == "free":
        return a[1] + len(bound)
    if tag == "bound":
        return bound.index(a[1])
    if tag == "succ":
        return ["s", encode_named(a[1], bound)]
    if tag == "rec":
        return ["r", encode_named(a[1], bound), encode_named(a[2], bound),
                encode_named(a[5], (a[3], a[4]) + bound)]
    if tag == "eq":
        return ["=", encode_named(a[1], bound), encode_named(a[2], bound)]
    if tag in ("pi", "sig"):
        return [tag, encode_named(a[2], (a[1],) + bound),
                encode_named(a[3], (a[1],) + bound)]
    if tag == "bottom":
        return ["false"]
    raise AssertionError("unknown named node")


def replace_free(a, env):
    """Named substitution: bound identities are never renamed or shifted."""
    tag = a[0]
    if tag == "free":
        return named_term(env(a[1]))
    if tag in ("zero", "bound", "bottom"):
        return a
    if tag == "succ":
        return (tag, replace_free(a[1], env))
    if tag == "rec":
        return (tag, replace_free(a[1], env), replace_free(a[2], env),
                a[3], a[4], replace_free(a[5], env))
    if tag == "eq":
        return (tag, replace_free(a[1], env), replace_free(a[2], env))
    if tag in ("pi", "sig"):
        return (tag, a[1], replace_free(a[2], env), replace_free(a[3], env))
    raise AssertionError("unknown named node")


def oracle_subst(a, env, formula):
    named = named_formula(a) if formula else named_term(a)
    return encode_named(replace_free(named, env))


def oracle_shift(a, distance=1, formula=True):
    return oracle_subst(a, lambda i: i + distance, formula)


def oracle_inst(a, witness, formula=True):
    return oracle_subst(a, lambda i: witness if i == 0 else i - 1, formula)


def public_wf(a, formula):
    try:
        if formula:
            named_formula(a, allow_bottom=True)
        else:
            named_term(a)
        return True
    except BadSyntax:
        return False


def positive_wf(a, formula):
    try:
        (named_formula if formula else named_term)(a)
        return True
    except BadSyntax:
        return False


def random_term(rng, depth, bound=0):
    if depth == 0 or rng.random() < .43:
        return rng.choice([ZERO, *range(bound + 4)])
    if rng.random() < .38:
        return ["s", random_term(rng, depth - 1, bound)]
    return ["r", random_term(rng, depth - 1, bound),
            random_term(rng, depth - 1, bound),
            random_term(rng, depth - 1, bound + 2)]


def random_formula(rng, depth, bound=0):
    if depth == 0 or rng.random() < .46:
        return ["=", random_term(rng, max(0, depth - 1), bound),
                random_term(rng, max(0, depth - 1), bound)]
    return [rng.choice(["pi", "sig"]),
            random_formula(rng, depth - 1, bound + 1),
            random_formula(rng, depth - 1, bound + 1)]


def random_json(rng, depth):
    atoms = [None, False, True, -3, -2, ZERO, 0, 1, 2, 5, 0.0, 1.0,
             -1.0, "", "s", "r", "=", "pi", "sig", "false", "unknown"]
    if depth == 0 or rng.random() < .45:
        return copy.deepcopy(rng.choice(atoms))
    choice = rng.randrange(4)
    if choice == 0:
        return {"arbitrary": random_json(rng, depth - 1)}
    tag = rng.choice(atoms)
    if choice == 1:
        tag = [tag]
    return [tag, *(random_json(rng, depth - 1) for _ in range(rng.randrange(5)))]


def explicit_mutants():
    scalar = [None, False, True, -5, -2, ZERO, 0, 1, 0.0, 1.0, -1.0,
              "", "s", "r", "=", "pi", "sig", "false", {}, []]
    yield from scalar
    for tag in ["s", "r", "=", "pi", "sig", "false", "unknown", [], {}, 0, True]:
        for arity in range(5):
            yield [copy.deepcopy(tag), *([ZERO] * arity)]
            yield [copy.deepcopy(tag), *([TRUTH] * arity)]
    for x in scalar:
        yield ["=", copy.deepcopy(x), ZERO]
        yield ["pi", copy.deepcopy(x), TRUTH]
        yield ["sig", TRUTH, copy.deepcopy(x)]
        yield ["r", ZERO, ZERO, copy.deepcopy(x)]
        yield ["=", ["r", ZERO, ZERO, copy.deepcopy(x)], ZERO]
    yield ["false", ZERO]
    yield ["=", ["false"], ZERO]
    yield ["pi", ["false"], ["false"]]
    yield ["r", ["s", ZERO], ZERO, ["false"]]


def load_candidate(path):
    spec = importlib.util.spec_from_file_location("independently_audited_ipra", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    if len(sys.argv) not in (2, 3):
        raise SystemExit(__doc__)
    path = Path(sys.argv[1]).resolve()
    K = load_candidate(path)
    counts = {"named_roundtrips": 0, "named_shifts": 0,
              "named_substitutions": 0, "named_instantiations": 0,
              "formation_comparisons": 0, "positive_certificates": 0,
              "negative_certificates": 0, "malformed_inference_records": 0,
              "canonical_hypothesis_identity": 0, "cli_cases": 0}
    rng = random.Random(202611060925)

    def equal(label, actual, expected):
        # Serialization enforces exact type equality for booleans versus ints.
        if json.dumps(actual, separators=(",", ":")) != json.dumps(expected, separators=(",", ":")):
            raise AssertionError((label, "actual", actual, "expected", expected))

    def case(label, data, expect):
        try:
            actual = K.check(copy.deepcopy(data)) is True
        except ERRORS:
            actual = False
        if actual != expect:
            raise AssertionError((label, "expected_accept", expect, "actual_accept", actual, data))
        counts["positive_certificates" if expect else "negative_certificates"] += 1

    def infer_reject(label, proof, context=()):
        try:
            got = K.infer(copy.deepcopy(proof), copy.deepcopy(list(context)))
        except ERRORS:
            counts["malformed_inference_records"] += 1
            return
        raise AssertionError((label, "invalid record returned", got, proof))

    def candidate_wf(a, formula):
        try:
            if hasattr(K, "wf"):
                return bool(K.wf(copy.deepcopy(a), formula))
            value = K.subst(copy.deepcopy(a), formula=formula)
            equal("validated identity substitution", value, a)
            return True
        except ERRORS:
            return False

    # Explicit collisions: indices at every boundary of nested R, Pi and Sigma.
    sources = []
    for i, j, k in itertools.product(range(5), repeat=3):
        t = ["r", i, ["s", j], ["r", 0, 1, ["r", k, 2, ["s", 4]]]]
        sources.append((t, False))
        sources.append((["pi", ["=", 0, i],
                         ["sig", ["=", 1, j], ["=", t, k]]], True))
    huge = 10**80
    sources.extend([(huge, False), (["r", huge, ZERO, huge + 2], False),
                    (["pi", TRUTH, ["=", huge + 1, 0]], True)])
    for _ in range(1200):
        sources.append((random_term(rng, 4), False))
        sources.append((random_formula(rng, 4), True))

    witnesses = [ZERO, 0, ["s", 1], ["r", 1, 2, ["r", 0, 3, ["s", 4]]]]
    for index, (source, is_formula) in enumerate(sources):
        parsed = (named_formula if is_formula else named_term)(source)
        equal("named roundtrip", encode_named(parsed), source)
        counts["named_roundtrips"] += 1
        for distance in (0, 1, 2, 5):
            equal("shift", K.shift(copy.deepcopy(source), distance),
                  oracle_shift(source, distance, is_formula))
            counts["named_shifts"] += 1
        witness = witnesses[index % len(witnesses)]
        equal("instantiation", K.inst(copy.deepcopy(source), copy.deepcopy(witness)),
              oracle_inst(source, witness, is_formula))
        counts["named_instantiations"] += 1
        # The second environment has nested binders and independent free names.
        environments = [lambda i: ["s", i + 1],
                        lambda i: ["r", i + 1, ZERO, ["r", 1, 0, ["s", i + 4]]]]
        for env in environments:
            equal("simultaneous substitution", K.subst(copy.deepcopy(source), env),
                  oracle_subst(source, env, is_formula))
            counts["named_substitutions"] += 1

    corpus = list(explicit_mutants())
    corpus.extend(random_json(rng, 4) for _ in range(1800))
    corpus.extend(source for source, _ in sources[::7])
    for value in corpus:
        for is_formula in (False, True):
            expected = positive_wf(value, is_formula)
            actual = candidate_wf(value, is_formula)
            if actual != expected:
                raise AssertionError(("formation disagreement", value, is_formula, actual, expected))
            counts["formation_comparisons"] += 1

    # Every expected formula below is constructed without candidate substitution.
    for _ in range(80):
        matrix = random_formula(rng, 3)
        term = random_term(rng, 3)
        other = random_term(rng, 3)
        guard = random_formula(rng, 3)
        body = random_formula(rng, 3)
        principal = ["pi", guard, body]
        premise = oracle_inst(guard, term)
        goal = oracle_inst(body, term)
        case("Pi instantiation with nested binders", [[principal, premise], goal,
             ["use", ["hyp", principal], term, ["hyp", premise]]], True)
        principal = ["=", term, other]
        premise = oracle_inst(matrix, term)
        goal = oracle_inst(matrix, other)
        case("equality transport with nested binders", [[principal, premise], goal,
             ["use", ["hyp", principal], matrix, ["hyp", premise]]], True)
        case("Pi introduction", [[], ["pi", guard, guard],
             ["pi", guard, ["hyp", guard]]], True)
        witness_eq = ["=", 0, oracle_shift(term, formula=False)]
        lifted = oracle_shift(matrix)
        case("witness equation introduction", [[matrix], ["sig", witness_eq, lifted],
             ["pair", term, ["hyp", witness_eq], ["hyp", lifted]]], True)
        principal = ["sig", guard, lifted]
        case("Sigma elimination with retained free parameters", [[principal], matrix,
             ["use", ["hyp", principal], matrix, ["hyp", lifted]]], True)
        r0 = ["r", ZERO, term, other]
        case("base recursion", [[], ["=", r0, term], ["rec", r0]], True)
        rs = ["r", ["s", term], ZERO, other]
        reduced = oracle_subst(other, lambda i:
            ["r", term, ZERO, other] if i == 0 else term if i == 1 else i - 2,
            False)
        case("successor recursion", [[], ["=", rs, reduced], ["rec", rs]], True)
        base = oracle_inst(matrix, ZERO)
        hyp = matrix if matrix[0] == "=" else oracle_shift(base)
        step = ["pi", hyp, oracle_subst(matrix, lambda i: ["s", 0] if i == 0 else i, True)]
        numerical = ["pi", ["sig", oracle_shift(base, 2), oracle_shift(step, 2)], matrix]
        case("numerical schema", [[], numerical, ["nat", matrix]], True)

    # Eigenvariable failures cannot be accepted even with well-formed syntax.
    parameter_eq = ["=", 0, ZERO]
    case("Pi parameter capture", [[parameter_eq], ["pi", TRUTH, parameter_eq],
         ["pi", TRUTH, ["hyp", ["=", 1, ZERO]]]], False)
    principal = ["sig", parameter_eq, TRUTH]
    case("Sigma witness escape", [[principal], parameter_eq,
         ["use", ["hyp", principal], parameter_eq, ["hyp", parameter_eq]]], False)
    hidden = ["=", ["r", ZERO, ZERO, 2], ZERO]
    principal = ["sig", hidden, TRUTH]
    case("Sigma witness escape under recursion", [[principal], hidden,
         ["use", ["hyp", principal], hidden, ["hyp", hidden]]], False)
    case("pair capture", [[], ["sig", ["=", 0, 0], ["=", 0, 0]],
         ["pair", 0, ["hyp", ["=", 0, 1]], ["hyp", ["=", 0, 1]]]], False)
    matrix = ["pi", TRUTH, ["=", 1, ZERO]]
    base = oracle_inst(matrix, ZERO)
    successor = oracle_subst(matrix, lambda i: ["s", 0] if i == 0 else i, True)
    forged = ["pi", ["sig", oracle_shift(base, 2),
                      oracle_shift(["pi", matrix, successor], 2)], matrix]
    case("forbidden induction on quantified formula", [[], forged, ["nat", matrix]], False)
    principal = ["=", 0, 1]
    template = ["pi", TRUTH, ["=", 1, 0]]
    before = oracle_inst(template, 0)
    case("equality capture under Pi", [[principal, before],
         ["pi", TRUTH, ["=", 0, 0]],
         ["use", ["hyp", principal], template, ["hyp", before]]], False)

    # Validate malformed annotations at the omitted-check boundary.
    sig_truth = ["sig", TRUTH, TRUTH]
    pi_truth = ["pi", TRUTH, TRUTH]
    for value in corpus[:600]:
        if not public_wf(value, True):
            case("malformed equality template", [[TRUTH], TRUTH,
                 ["use", ["hyp", TRUTH], value, ["hyp", TRUTH]]], False)
            case("malformed Sigma conclusion", [[sig_truth], TRUTH,
                 ["use", ["hyp", sig_truth], value, ["hyp", TRUTH]]], False)
        if not public_wf(value, False):
            case("malformed Pi witness", [[pi_truth, TRUTH], TRUTH,
                 ["use", ["hyp", pi_truth], value, ["hyp", TRUTH]]], False)
            case("malformed pair witness", [[TRUTH], sig_truth,
                 ["pair", value, ["hyp", TRUTH], ["hyp", TRUTH]]], False)
        # infer is the positive internal interface; it must preserve its invariant.
        if not positive_wf(value, True):
            infer_reject("malformed Pi guard", ["pi", value, ["hyp", TRUTH]], [TRUTH])
            infer_reject("malformed numerical matrix", ["nat", value])
        if not positive_wf(value, False):
            infer_reject("malformed zero-recursion body", ["rec", ["r", ZERO, ZERO, value]])

    # Hyp keys are untrusted lookup keys; accepted aliases must return stored data.
    canonical = ["=", 0, 1]
    for alias in (["=", False, True], ["=", 0.0, 1.0]):
        if K.infer(["hyp", alias], [canonical]) is not canonical:
            raise AssertionError("hypothesis lookup returned an unvalidated alias")
        counts["canonical_hypothesis_identity"] += 1
        case("canonical lookup alias", [[canonical], canonical, ["hyp", alias]], True)
    case("genuine bottom assumption", [[["false"]], ["false"], ["hyp", CLASH]], True)
    case("closed bottom rejection", [[], ["false"], ["hyp", ["false"]]], False)
    case("unknown proof tag", [[TRUTH], TRUTH, ["refl", ZERO]], False)
    roots = [None, False, 0, 0.0, "abc", {}, {"a": [], "b": TRUTH, "c": []},
             [], [[], TRUTH], [[], TRUTH, ["hyp", TRUTH], None], ["false"]]
    for data in roots:
        case("malformed envelope", data, False)

    cli_cases = [
        ("canonical hypothesis", [[TRUTH], TRUTH, ["hyp", TRUTH]], True),
        ("canonical Boolean key", [[canonical], canonical, ["hyp", ["=", False, True]]], True),
        ("Boolean goal", [[canonical], ["=", False, True], ["hyp", canonical]], False),
        ("Boolean equality annotation", [[TRUTH], TRUTH,
          ["use", ["hyp", TRUTH], ["=", False, ZERO], ["hyp", TRUTH]]], False),
        ("wrong signature arity", [[TRUTH], TRUTH,
          ["use", ["hyp", TRUTH], ["=", 0, ZERO, ZERO], ["hyp", TRUTH]]], False),
        ("nested wrong body sort", [[], TRUTH, ["rec", ["r", ZERO, ZERO, TRUTH]]], False),
        ("missing false proof", [[], ["false"], ["hyp", ["false"]]], False),
        ("dictionary envelope", {"assumptions": [], "goal": TRUTH, "proof": []}, False),
    ]
    with tempfile.TemporaryDirectory(prefix="ipra_independent_") as tmp:
        cert_path = Path(tmp) / "proof.json"
        for optimized in (False, True):
            for label, data, accepted in cli_cases:
                cert_path.write_text(json.dumps(data), encoding="utf-8")
                cmd = [sys.executable, *(["-O"] if optimized else []), str(path), str(cert_path)]
                completed = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                if completed.returncode != (0 if accepted else 1):
                    raise AssertionError(("CLI exit", label, optimized, completed.returncode,
                                          completed.stdout, completed.stderr))
                if completed.stdout.strip() != ("ACCEPT" if accepted else "REJECT"):
                    raise AssertionError(("CLI output", label, optimized, completed.stdout))
                counts["cli_cases"] += 1
    result = {"candidate": str(path),
              "candidate_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
              "oracle": "independent fresh-name substitution; no candidate scope metadata",
              "seed": 202611060925, "all_passed": True, "counts": counts,
              "scope": "Finite syntax, substitution, certificate, and adversarial JSON checks; not a formal metatheorem."}
    if len(sys.argv) == 3:
        Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
