Verification artifacts and trust boundary
========================================

checker.py at the archive root is the complete trusted acceptance program.
It imports only Python's json and sys modules. No file in verification/,
no proof builder, and no translator is imported by the acceptance program.

baseline_composed.py is a verbatim copy of the preceding composed draft's
complete checker. Its SHA-256 is:
89193df964269f17675822f2b81f2f8829d83a47e993c67208e36e182dc7e677

Source archive: docs/drafts/ipra_composed_kernel_2026-11-06.zip
Repository: VladimirReshetnikov/ProveIt
Pinned commit: 36fb791c722edc2549719744c38feef74fa422fb

inherited_index.json records the baseline hash, all 123 inherited fixture
hashes, and the expected acceptance outcome of each file.

test_report.json and test_run.txt are produced by:
  python3 verify.py

The regression suite checks inherited and newly constructed derivations,
adversarial malformed annotations, numerical substitutions, and both normal
and optimized command-line execution. translate.py is an identity bridge:
the public calculus and certificate language did not change. Positive
certificates are checked unchanged by both implementations.

independent_audit.py uses a separate fresh-name representation to check
binding operations, syntax, and adversarial certificates. Its output is
independent_audit_results.json. This independent oracle does not reuse the
candidate's scope table or substitution routines for expected results.

All tests are finite executable evidence. The mathematical report supplies
the general arguments. No Lean/Rocq formalization of the soundness or
bi-interpretability metatheorems is claimed.
