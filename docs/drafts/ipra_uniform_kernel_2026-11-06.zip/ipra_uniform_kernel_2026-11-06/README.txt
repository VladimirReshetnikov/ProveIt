A UNIFORM CERTIFICATE CALCULUS FOR iPRA
Prepared for Vladimir Reshetnikov, November 6, 2026

RESULT
The report gives the full native axiomatization, recovery of intuitionistic
logic and quantifier-free induction, a faithful ordinary realization, and
whole-domain bi-interpretations with iPRA. Both internal round trips use
numerical equality as their definable isomorphism. The designated native
contradiction is 0 = S0.

The arithmetic basis is retained from the strongest supplied drafts. The
new certificate representation uses strict integer hypothesis references,
shared pi/ex binder tags, and untagged elimination applications. The complete
standalone checker has 661 significant source tokens, 659 normalized tokens,
704 AST nodes, 2,115 normalized bytes, and 2,338 raw source bytes. All are
strictly below the finite coordinatewise envelope of the supplied corpus.

The paper also gives a direct native-language counterexample showing that
equation induction does not imply the compound-formula cases branch. This
is a precise independence result for the stated basis, not an assertion
that every alternative axiomatization must contain an identical rule.

FILES
report.pdf and report.tex   Complete paper, with sections/ source files.
checker.py                 Entire acceptance boundary; imports only json/sys.
examples/                  Twenty arithmetic and logical certificates.
validation/                Frozen strict reference, checked translations,
                           source/translated certificates, targeted audits.
comparison/                197 hash-checked historical source files,
                           161 standalone boundaries and 74 recorded groups,
                           provenance, inventory and machine-readable metrics.
measure.py                 Recounts the full finite comparison without
                           executing any compared program.
reproduce.py               Runs size and certificate verification offline.
build.py                   Builds the PDF using pdflatex.
FORMAT.txt                 Exact certificate syntax and usage.
MANIFEST.sha256            Checksums for all supplied files except itself.

QUICK START
Use Python 3.11 or later; the recorded measurements were made with 3.12.14.
From the unpacked package directory:

    python3 reproduce.py
    python3 checker.py examples/coverage.json
    python3 checker.py examples/epsilon_zero_implies_equal.json
    python3 build.py

The checker prints ACCEPT and exits zero only on successful checking.
Errors print REJECT and exit nonzero. The input is a JSON triple
[context, conclusion, proof]. Numerical variables and hypothesis references
are distinct roles even though both use integers. See FORMAT.txt.

PDF BUILD
A standard TeX Live installation with pdflatex, lmodern, microtype,
amsmath/amssymb/amsthm, mathtools, geometry, booktabs, enumitem,
xcolor, listings, fancyhdr, hyperref and bookmark is sufficient.
The supplied PDF is already compiled. The build needs no network.

PROVENANCE AND LIMITS
Repository: https://github.com/VladimirReshetnikov/ProveIt
Commit: 820ef51b6ad3c13ce4a500673a9e81d951fbc06c
Directory: docs/drafts
The six downloaded archive sizes and Git blob hashes were verified.
Exact filenames, archive hashes and all comparison boundaries are recorded
in comparison/archive_provenance.json and comparison/manifest.json.

The metatheory and checker have written correctness arguments plus finite
executable audits. They have not been formally verified in Lean or Rocq.
The result is a measured improvement over this finite corpus, not a proof
of a globally smallest axiomatization or a language-independent lower bound.
Python normalization can differ across Python versions. Practical resource
limits may reject very large valid certificates. No universal total
evaluator for primitive-recursive programs is postulated.

ATTRIBUTION
The theory, arithmetic constructions and source baseline are developed from
the supplied ProveIt draft proposals. Historical source files are preserved
unchanged with their hashes and embedded provenance. The uniform certificate
representation, its comparison and transport audit, the direct native cases
obstruction, and this assembled report constitute the current iteration.
