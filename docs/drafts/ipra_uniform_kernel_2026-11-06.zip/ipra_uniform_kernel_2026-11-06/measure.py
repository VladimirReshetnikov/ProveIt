"""Reproduce the complete-checker source-size comparison offline.

Run: python3 measure.py

No candidate or comparator checker is imported or executed. Exact source
snapshots are verified against comparison/manifest.json before measurement.
Python's runtime, JSON parser and standard library are the common boundary.
"""

import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import tokenize


ROOT = Path(__file__).resolve().parent
AXES = ("significant_source_tokens", "ast_nodes_without_docstrings",
        "normalized_utf8_bytes")
ALL_AXES = ("raw_utf8_bytes", "significant_source_tokens",
            "normalized_python_tokens", "ast_nodes_without_docstrings",
            "normalized_utf8_bytes")
IGNORED_TOKENS = {
    tokenize.ENCODING, tokenize.ENDMARKER, tokenize.COMMENT,
    tokenize.NL, tokenize.NEWLINE, tokenize.INDENT, tokenize.DEDENT,
}


class RemoveDocstrings(ast.NodeTransformer):
    def clean(self, node):
        if (node.body and isinstance(node.body[0], ast.Expr)
                and isinstance(node.body[0].value, ast.Constant)
                and isinstance(node.body[0].value.value, str)):
            node.body.pop(0)
        return self.generic_visit(node)

    visit_Module = clean
    visit_FunctionDef = clean
    visit_AsyncFunctionDef = clean
    visit_ClassDef = clean


def measure(path):
    """Count complete source, dropping only comments/layout and docstrings."""
    raw = path.read_bytes()
    source = raw.decode("utf-8")
    tree = ast.parse(source)
    docstrings = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef,
                             ast.AsyncFunctionDef, ast.ClassDef)):
            if (node.body and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)):
                doc = node.body[0]
                docstrings.append(((doc.lineno, doc.col_offset),
                                   (doc.end_lineno, doc.end_col_offset)))
    significant = [
        token for token in tokenize.generate_tokens(io.StringIO(source).readline)
        if token.type not in IGNORED_TOKENS
        and not any(lo <= token.start and token.end <= hi
                    for lo, hi in docstrings)
    ]
    tree = RemoveDocstrings().visit(tree)
    normalized = ast.unparse(tree) + "\n"
    return {
        "sha256": hashlib.sha256(raw).hexdigest(),
        "raw_utf8_bytes": len(raw),
        "significant_source_tokens": len(significant),
        "normalized_python_tokens": sum(
            token.type not in IGNORED_TOKENS for token in
            tokenize.generate_tokens(io.StringIO(normalized).readline)),
        "ast_nodes_without_docstrings": sum(1 for _ in ast.walk(tree)),
        "normalized_utf8_bytes": len(normalized.encode("utf-8")),
    }


def minima(rows):
    return {
        axis: {
            "value": min(row["metrics"][axis] for row in rows),
            "attained_by": [row["id"] for row in rows
                            if row["metrics"][axis]
                            == min(item["metrics"][axis] for item in rows)],
        } for axis in ALL_AXES
    }


def tex_row(label, metrics):
    return label + " & " + " & ".join(format(metrics[axis], ",") for axis in AXES) + r"\\"


def main():
    manifest_path = ROOT / "comparison/manifest.json"
    manifest = json.loads(manifest_path.read_text())
    cache = {}
    for record in manifest["source_files"]:
        metrics = measure(ROOT / record["snapshot_path"])
        if metrics["sha256"] != record["sha256"]:
            raise ValueError("Comparison source changed: " + record["snapshot_path"])
        cache[record["sha256"]] = metrics

    primary = [{**row, "metrics": cache[row["sha256"]]}
               for row in manifest["primary_checkers"]]
    focused = [{**row, "metrics": cache[row["sha256"]]}
               for row in manifest["focused_source_entries"]]
    standalone = [{"id": "standalone_" + row["sha256"],
                   **row, "metrics": cache[row["sha256"]]}
                  for row in manifest["standalone_programs"]]
    inherited = [
        {**row, "metrics": {
            axis: sum(cache[file["sha256"]][axis] for file in row["files"])
            for axis in ALL_AXES}}
        for row in manifest["inherited_groups"]
    ]
    declared_complete = [row for row in inherited
                         if row["declared_boundary"].startswith("complete")]
    candidate = measure(ROOT / "checker.py")
    frontier = minima(standalone)
    old = {axis: frontier[axis]["value"] for axis in ALL_AXES}
    savings = {
        axis: {"absolute": old[axis] - candidate[axis],
               "percent": 100 * (old[axis] - candidate[axis]) / old[axis]}
        for axis in ALL_AXES
    }
    primary_frontier = minima(primary)
    focused_frontier = minima(focused)
    primary_matches_expanded = all(
        primary_frontier[axis]["value"] == old[axis] for axis in AXES)
    focused_matches_expanded = all(
        focused_frontier[axis]["value"] == old[axis] for axis in AXES)
    method = (
        "Complete checker source: every syntax validator, binding operation, "
        "inference/schema handler, fixed data table, falsity conversion, import "
        "and JSON/CLI wrapper. Significant source tokens are counted in the "
        "original file after excluding comments, whitespace/layout tokens and "
        "genuine initial module/function/class docstrings. Normalized source is "
        "ast.unparse of the AST with those docstrings removed, plus one final "
        "newline; normalized tokens and UTF-8 bytes are reported separately. "
        "AST nodes include operators and contexts. Historical multi-file groups "
        "sum every source listed by the supplied inventory. Python and its "
        "standard library are excluded equally as the common runtime."
    )
    results = {
        "method": method,
        "python_version": platform.python_version(),
        "repository": manifest["repository"],
        "repository_commit": manifest["repository_commit"],
        "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "all_comparison_source_hashes_verified": True,
        "candidate": {"snapshot_path": "checker.py", "metrics": candidate},
        "counts": {
            "primary_checkers": len(primary),
            "focused_entries": len(focused),
            "focused_distinct_sources": len({row["sha256"] for row in focused}),
            "standalone_source_occurrences": sum(len(row["origins"]) for row in standalone),
            "distinct_standalone_programs": len(standalone),
            "inherited_inventory_groups": len(inherited),
            "inherited_distinct_source_sets": len({tuple(sorted(file["sha256"] for file in row["files"])) for row in inherited}),
            "inherited_declared_complete_groups": len(declared_complete),
            "all_distinct_source_files": len(cache),
        },
        "coordinate_minima": frontier,
        "primary_coordinate_minima": primary_frontier,
        "focused_coordinate_minima": focused_frontier,
        "inherited_inventory_minima": minima(inherited),
        "inherited_declared_complete_minima": minima(declared_complete),
        "primary_frontier_equals_expanded_standalone_frontier": primary_matches_expanded,
        "focused_frontier_equals_expanded_standalone_frontier": focused_matches_expanded,
        "candidate_strictly_below_every_claimed_coordinate": all(candidate[axis] < old[axis] for axis in AXES),
        "candidate_savings_against_frontier": savings,
        "primary_checkers": primary,
        "focused_entries": focused,
        "standalone_programs": standalone,
        "inherited_groups": inherited,
        "qualification": (
            "A finite source-size audit, not a theorem of absolute program-size "
            "optimality or soundness of every historical checker. The inherited "
            "groups preserve the source inventory's declared boundaries; they "
            "include partial cores and repeated inventories. Their sizes are "
            "supplementary, not new claims of complete standalone checkers. "
            "All those grouped sizes exceed the expanded standalone frontier. "
            "Raw bytes are sensitive to comments, docstrings and formatting."
        ),
    }
    output = ROOT / "verification"
    output.mkdir(exist_ok=True)
    (output / "metrics.json").write_text(json.dumps(results, indent=2) + "\n")
    macro_values = {
        "NewTokens": candidate["significant_source_tokens"],
        "NewNormalizedTokens": candidate["normalized_python_tokens"],
        "NewAST": candidate["ast_nodes_without_docstrings"],
        "NewBytes": candidate["normalized_utf8_bytes"],
        "OldTokens": old["significant_source_tokens"],
        "OldNormalizedTokens": old["normalized_python_tokens"],
        "OldAST": old["ast_nodes_without_docstrings"],
        "OldBytes": old["normalized_utf8_bytes"],
        "StandaloneCount": len(standalone),
        "FocusedCount": len(focused),
        "HistoricalGroupCount": len(inherited),
        "SnapshotCount": len(cache),
    }
    macros = ["% Generated by measure.py; do not edit by hand."]
    macros += [r"\newcommand{\%s}{%s}" % (name, format(value, ","))
               for name, value in macro_values.items()]
    (output / "metrics_macros.tex").write_text("\n".join(macros) + "\n")
    table = [r"\begin{tabular}{@{}lrrr@{}}", r"\toprule",
             r"Complete checker & Tokens & AST nodes & Normalized bytes\\",
             r"\midrule"]
    table += [tex_row(row["label"], row["metrics"]) for row in primary]
    table += [r"\midrule", tex_row("Coordinate minima (76 programs)", old),
              tex_row("New uniform checker", candidate),
              r"\bottomrule", r"\end{tabular}"]
    (output / "comparison_table.tex").write_text("\n".join(table) + "\n")
    if not results["candidate_strictly_below_every_claimed_coordinate"]:
        raise ValueError("The candidate no longer improves every claimed frontier coordinate")
    print(json.dumps({
        "candidate": candidate,
        "frontier": old,
        "counts": results["counts"],
        "all_comparison_source_hashes_verified": True,
        "source_tokens_equal_normalized_tokens_for_candidate":
            candidate["significant_source_tokens"] == candidate["normalized_python_tokens"],
        "savings_percent": {axis: round(savings[axis]["percent"], 3) for axis in AXES},
    }, indent=2))


if __name__ == "__main__":
    main()
