#!/usr/bin/env python3
"""Finite diagnostics for programs and compiler indexing, not a proof of PRA.

The report supplies universal/internal mathematical proofs. These checks use
ordinary Python integers and a finite sample, so they cannot verify a schema
over nonstandard models or the full syntactic bi-interpretation theorem.
"""
from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from typing import Callable


def pred(n):
    return max(n-1, 0)


def P(n, a):
    return a if n == 0 else n-1


def B(n, a):
    return a if n == 0 else 0


def C(z, u, v):
    return P(B(z, u+1), v)


@cache
def e(n, a):
    if n == 0:
        return B(a, 1)
    return C(a, 0, e(n-1, pred(a)))


@dataclass(frozen=True)
class Program:
    name: str
    g: Callable
    h: Callable
    k: Callable


PROGRAMS = (
    Program("identity_substitution_frozen_mixed", lambda a,b: a*a + 3*b[0] + b[1],
        lambda n,a,b,v: 2*v + (n+1)*a + b[0]*b[1], lambda a: a),
    Program("growing_substitution", lambda a,b: a + b[0],
        lambda n,a,b,v: v + (n+1)*(a+1) + b[1], lambda a: a+1),
    Program("oscillating_substitution", lambda a,b: a*a + b[0],
        lambda n,a,b,v: (n+1)*v + a + 2*b[0] + b[1], lambda a: 1 if a == 0 else 0),
    Program("noninjective_substitution", lambda a,b: (a+1)*(b[0]+1),
        lambda n,a,b,v: v + a*a + (n+b[1])*(b[0]+1), lambda a: a//2),
    Program("predecessor_substitution", lambda a,b: a + b[0]*b[1],
        lambda n,a,b,v: 3*v + a + n + b[0], pred),
)


def test_compiler():
    totals = {"evaluations": 0, "trace_equalities": 0, "successor_equations": 0}
    for pr in PROGRAMS:
        @cache
        def direct(n, a, b):
            return pr.g(a,b) if n == 0 else pr.h(n-1,a,b,direct(n-1,pr.k(a),b))
        def orbit(t,a):
            for _ in range(t):
                a = pr.k(a)
            return a
        def U(j,N,a,b):
            value = pr.g(orbit(N,a),b)
            for i in range(j):
                value = pr.h(i,orbit(max(N-i-1,0),a),b,value)
            return value
        for N,a,b0,b1 in itertools.product(range(8), range(6), range(3), range(3)):
            b = (b0,b1)
            got = U(N,N,a,b)
            assert got == direct(N,a,b), (pr.name,N,a,b)
            totals["evaluations"] += 1
            assert U(N+1,N+1,a,b) == pr.h(N,a,b,U(N,N,pr.k(a),b))
            totals["successor_equations"] += 1
            for j in range(N+1):
                assert direct(j,orbit(N-j,a),b) == U(j,N,a,b)
                totals["trace_equalities"] += 1
    return {"programs": [p.name for p in PROGRAMS],
            "bounds": {"counter": "0..7", "changed_seed": "0..5", "each_of_two_frozen_parameters": "0..2"},
            **totals}


def test_bit_and_latch():
    bit_checks = 0
    for x,y in itertools.product(range(81), repeat=2):
        assert e(x,y) == int(x == y)
        assert e(x+1,y+1) == e(x,y)
        bit_checks += 2
    truth_checks = 0
    for p,q in itertools.product((0,1), repeat=2):
        assert C(p,0,q) == (p and q)
        assert C(p,q,1) == (p or q)
        assert C(p,1,q) == int(not p or q)
        truth_checks += 3
    local_checks = 0
    for b,next_b,state in itertools.product((0,1),(0,1),(0,1,2,17)):
        first = C(b,0,state)
        second = C(next_b,0,first)
        if b == 0 or next_b == 1:
            assert first == second
            local_checks += 1
    def latch(bits):
        values = [1]
        for bit in bits:
            values.append(C(bit,0,values[-1]))
        return values
    words = progressive = base_false_progressive = 0
    for length in range(1,11):
        for bits in itertools.product((0,1), repeat=length):
            words += 1
            run = latch(bits)
            assert run == [int(all(bits[:j])) for j in range(length+1)]
            if all(bits[j] == 0 or bits[j+1] == 1 for j in range(length-1)):
                progressive += 1
                assert len(set(run[1:])) == 1
                if bits[0] == 1:
                    assert all(bits)
                    assert set(run[1:]) == {1}
                else:
                    base_false_progressive += 1
                    assert set(run[1:]) == {0}
    assert latch((0,1,1)) == [1,0,0,0]
    assert latch((1,0,1)) == [1,1,0,0]
    return {"e_grid": "0..80 in both arguments", "e_checks": bit_checks,
            "connective_truth_table_checks": truth_checks,
            "local_latch_transition_checks_including_nonbit_states": local_checks,
            "all_binary_words_length_1_to_10": words,
            "progressive_words": progressive,
            "progressive_words_with_false_base": base_false_progressive,
            "off_by_one_diagnostic": {"bits": [0,1,1], "latch_including_initial_seed": [1,0,0,0],
                "interpretation": "The shifted tail is stationary although the unshifted latch is not; without a true base it stays zero."},
            "broken_step_diagnostic": {"bits": [1,0,1], "latch_including_initial_seed": [1,1,0,0]}}


def model_witnesses():
    z = (0,0)
    x, y = (0,0), (0,1)
    bit = tuple(e(u,v) for u,v in zip(x,y))
    assert bit == (1,0) and bit != z and x != y
    return {
        "missing_separation": {"carrier_size": 1, "all_terms_denote": 0,
            "D_and_every_pointed_instance": "true because every equality is true",
            "Sep": False,
            "scope": "Complete one-element countermodel; no enumeration of an infinite language is needed."},
        "coordinatewise_product": {"carrier": "N x N", "constant_function_value": x,
            "anchor": y, "computed_e_at_initial_value_and_anchor": bit,
            "zero": z, "pointed_left_disjunct": False, "pointed_right_disjunct": False,
            "scope": "An explicit witness refuting Pointed in the product. Computation equations and ordinary constancy hold coordinatewise, as proved in the report; this is not a finite model of PRA."}}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("checks.json"))
    args = parser.parse_args()
    results = {"status": "PASS", "scope": "Finite implementation diagnostics only; no proof of universal axioms, nonstandard-model facts, or syntactic bi-interpretability is claimed.",
               "compiler": test_compiler(), "bit_and_latch": test_bit_and_latch(), "model_witnesses": model_witnesses()}
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print("PASS: compiler trace, frozen parameters, equality program, truth tables, and shifted-latch diagnostics.")
