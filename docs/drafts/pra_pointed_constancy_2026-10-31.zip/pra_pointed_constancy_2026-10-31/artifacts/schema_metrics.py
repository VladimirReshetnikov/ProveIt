#!/usr/bin/env python3
"""Recompute displayed formula-tree sizes, independently of source scripts.

This measures schematic displays, NOT full descriptions or global minimality.
All finite parameter tuples are permitted in the full-language presentations.
Bound variable names label quantifiers and are not separate variable nodes.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Node:
    name: str
    children: tuple["Node", ...] = ()

    def size(self) -> int:
        return 1 + sum(t.size() for t in self.children)

    def show(self) -> str:
        return self.name if not self.children else self.name + "(" + ",".join(t.show() for t in self.children) + ")"


def app(name: str, *args: Node) -> Node:
    return Node(name, args)


def forall(names: list[str], body: Node) -> Node:
    for name in reversed(names):
        body = app("forall " + name, body)
    return body


zero, bottom, n, x, y = (Node(s) for s in ("0", "false", "n", "x", "y"))
succ = lambda t: app("S", t)
eq = lambda t, u: app("=", t, u)
imp = lambda a, b: app("implies", a, b)
disj = lambda a, b: app("or", a, b)
neg = lambda a: imp(a, bottom)
one = succ(zero)
sep = neg(eq(zero, one))
inv = forall(["x", "y"], eq(app("R", app("R", x, y), y), x))
offdiag = forall(["x", "y"], disj(eq(app("e", x, y), zero), eq(x, y)))


def templates(m: int) -> dict[str, Node]:
    if m < 1:
        raise ValueError("The substitution grammar requires a distinguished parameter.")
    names = ["a" + str(i) for i in range(m)]
    pars = [Node(name) for name in names]
    anchor = pars[0]
    f = lambda t: app("f", t, *pars)
    stationary = forall(["n"], eq(f(succ(n)), f(n)))
    base = forall(names, eq(app("R", zero, *pars), app("g", *pars)))
    ordinary_step = forall(["n"] + names,
        eq(app("R", succ(n), *pars), app("h", n, *pars, app("R", n, *pars))))
    substitution_step = forall(["n"] + names,
        eq(app("R", succ(n), *pars), app("h", n, *pars,
            app("R", n, app("k", anchor), *pars[1:]))))
    pointed = forall(names, imp(stationary, forall(["n"],
        disj(eq(app("e", f(zero), anchor), zero), eq(f(n), anchor)))))
    ss = forall(names, imp(stationary, forall(["n"], neg(eq(succ(f(n)), f(zero))))))
    pc = forall(names, imp(forall(["n"], eq(f(succ(succ(n))), f(succ(n)))),
        forall(["n"], disj(eq(n, zero), eq(f(n), f(one))))))
    sz = forall(names, imp(stationary,
        disj(forall(["n"], eq(f(n), zero)), eq(app("Z", f(zero)), zero))))
    return {"D_base": base, "D_ordinary_step": ordinary_step,
            "D_substitution_step": substitution_step, "Pointed": pointed,
            "SS": ss, "PC": pc, "SZ": sz}


def result() -> dict:
    at_one = templates(1)
    sizes = {k: v.size() for k, v in at_one.items()}
    sizes.update(Sep=sep.size(), Inv=inv.size(), O=offdiag.size())
    a = Node("a")
    binary_base = forall(["a"], eq(app("I", zero, a), a))
    binary_step = forall(["n", "a"], eq(app("I", succ(n), a), app("h", n, app("I", n, a))))
    binary_d = binary_base.size() + binary_step.size()
    full_d = sizes["D_base"] + sizes["D_ordinary_step"]
    subst_d = sizes["D_base"] + sizes["D_substitution_step"]
    rows = []
    def row(stem, grammar, computation, schema, fixed, qualification):
        rows.append({"archive_stem": stem, "grammar": grammar,
                     "computation": computation, "arithmetic_schema": schema,
                     "fixed": fixed, "total": computation + schema + fixed,
                     "qualification": qualification})
    for stem in ("pra_anchored_involution", "pra_bounded_reflection", "pra_transposition_constancy"):
        row(stem, "ordinary PR with all finite frozen tuples", full_d, sizes["PC"], sizes["Sep"] + sizes["Inv"],
            "Different specified involution programs; descriptor bodies are a separate cost.")
    row("pra_involutive_difference", "initialized binary iterator", binary_d, sizes["PC"], sizes["Sep"] + sizes["Inv"],
        "Its primary PC schema has one passive parameter; its coding proof handles this restriction.")
    row("pra_stationary_zero", "ordinary PR with all finite frozen tuples", full_d, sizes["SZ"], sizes["Sep"] + sizes["Inv"],
        "Z and the involution are actual specified description symbols.")
    row("pra_substitution_descent", "parameter substitution with all finite frozen tuples", subst_d, sizes["SS"], sizes["O"],
        "Same complete description grammar and same designated e program as the new presentation.")
    row("pra_pointed_constancy", "parameter substitution with all finite frozen tuples", subst_d, sizes["Pointed"], sizes["Sep"],
        "New matched-language comparison: the other six rows are the actual current archives.")
    uniform = []
    for m in range(1, 9):
        t = templates(m)
        d = t["D_base"].size() + t["D_substitution_step"].size()
        old = d + t["SS"].size() + offdiag.size()
        new = d + t["Pointed"].size() + sep.size()
        assert d == 7*m + 14
        assert t["Pointed"].size() == 5*m + 20
        assert old == 12*m + 42 and new == 12*m + 40
        uniform.append({"parameters_in_display": m, "old_total": old, "new_total": new, "saving": old-new})
    assert [sizes[k] for k in ("D_base", "D_ordinary_step", "D_substitution_step", "Pointed", "SS", "PC", "SZ", "Sep", "Inv", "O")] == [7,13,14,25,22,26,24,6,9,11]
    assert binary_d == 18
    return {"status": "PASS", "source_commit": "392757d09455930d2b090b26bd1537799451c91a",
            "metric": "One node per variable, constant, application, equality, connective, falsity, and individual quantifier; 1=S(0), negation=A implies false.",
            "scope": "Template counts only. Stored descriptors, names, grammar encoding, and all instantiated term bodies are not included; no absolute shortestness claim.",
            "parameter_caution": "One-parameter displays do not mean a one-parameter-only theory. For example independent x and y in the equality decision are obtained using an additional frozen parameter.",
            "one_parameter_counts": sizes,
            "one_parameter_formulas": {k: v.show() for k,v in at_one.items()},
            "current_archive_comparison": rows,
            "uniform_formulas": {"D_substitution": "7*m + 14", "Pointed": "5*m + 20", "SS": "5*m + 17", "old_total": "12*m + 42", "new_total": "12*m + 40"},
            "uniform_comparison": uniform,
            "unchanged_e_descriptor_body_nodes": {"g_B_y_one": 4, "h_expanded_C_y_zero_v": 6, "k_P_y_zero": 3},
            "historical_caution": "A different 52-node delayed-uniqueness display is quoted inside predecessor papers. It is not one of the six current ZIPs and is not superseded by a global size theorem here."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("schema_metrics.json"))
    args = parser.parse_args()
    data = result()
    args.output.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print("PASS: current displays recomputed; matched total 54 -> 52, saving 2 for each tested tuple size.")
