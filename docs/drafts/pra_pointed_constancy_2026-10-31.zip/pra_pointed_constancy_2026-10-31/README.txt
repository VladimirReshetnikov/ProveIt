PRIMITIVE RECURSIVE ARITHMETIC FROM POINTED CONSTANCY
Prepared for Vladimir Reshetnikov, 31 October 2026

MAIN FILES
  pra_pointed_constancy.pdf          Complete report and proofs
  pra_pointed_constancy.tex          Main LaTeX source
  sections/reverse.tex               Reverse compiler and bi-interpretations
  AXIOMS.txt                        Exact standalone specification

RESULT
One arithmetic schema, plus 0 != S0 and the specified computation equations,
is definitionally equivalent to PRA in each matching logic separately.
Constant schema instances establish native equality recognition; a diagonal
instance and a shifted running test recover all quantifier-free induction.
The source and target have a common conservative definitional extension.

The matched display count improves from 54 to 52 nodes, uniformly by two nodes
at every finite parameter length, using the same language and comparator as
the current substitution-descent draft. This is a modest specific improvement,
not a theorem of absolute minimality.

SOURCE REVIEW
All six current PRA archives in ProveIt/docs/drafts were downloaded and
verified at commit 392757d09455930d2b090b26bd1537799451c91a. The incoming index
and inventory were examined; unrelated Busy Beaver ZIP interiors were not.
See audit/sources.json for exact paths and hashes.

BUILD
From this directory run:
  bash build.sh
This requires pdflatex and the common LaTeX packages listed in the source.
It compiles the report twice and writes the final PDF here.

REPRODUCE DIAGNOSTICS AND COUNTS
  python3 artifacts/schema_metrics.py
  python3 artifacts/checks.py
These require Python 3.10 or later and only the standard library.
The finite computational tests are diagnostics, not proofs of the universal
logical metatheorem.

CHECK THE LEAN KERNEL
  lean formal/PointedConstancy.lean
Checked with Lean 4.19.0, using Init only. No external package is required.
See formal/README.txt for exact hypotheses and scope. The kernel does not
assume a schema over all set-theoretic functions. Eighteen exported theorem
axiom audits are empty. The written report contains the complete syntax-level
interpretation argument; the whole metatheorem is not machine-formalized.

INTEGRITY
SHA256SUMS lists every deliverable file except itself. To check:
  sha256sum -c SHA256SUMS
