#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p audit
pdflatex -interaction=nonstopmode -halt-on-error pra_pointed_constancy.tex > audit/latex_build_pass1.log
pdflatex -interaction=nonstopmode -halt-on-error pra_pointed_constancy.tex > audit/latex_build_pass2.log
printf 'Built pra_pointed_constancy.pdf\n'
