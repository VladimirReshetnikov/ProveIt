/-
Constructive local kernel for PRA from pointed constancy.

This file assumes only the specific pointed-schema instances used by each
theorem. In particular, there is no assumption that every set-theoretic
function on the carrier satisfies the schema. `Core` contains the constant
term instances and the single diagonal-term instance. A constancy or latch
theorem takes its additional particular instance as an explicit argument.

The carrier is arbitrary and has native Lean equality. No induction on it,
classical reasoning, choice, or admitted proof occurs. The formula compiler
is a semantic finite propositional compiler, with atom values supplied by
an assignment. Full first-order term syntax, proof syntax, primitive-recursion
admissibility, the reverse compiler, and bi-interpretability remain written
proofs in the accompanying article.
-/

import Init

universe u

namespace PRAPointedConstancy

def PointedInstance {α : Type u} (zero : α) (succ : α → α)
    (eqtest : α → α → α) (f : α → α) (anchor : α) : Prop :=
  (∀ n, f (succ n) = f n) →
    ∀ n, eqtest (f zero) anchor = zero ∨ f n = anchor

structure Core (α : Type u) where
  zero : α
  succ : α → α
  eqtest : α → α → α
  separated : zero ≠ succ zero
  diagonal_base : eqtest zero zero = succ zero
  diagonal_step : ∀ n, eqtest (succ n) (succ n) = eqtest n n
  constant_instances : ∀ x a,
    PointedInstance zero succ eqtest (fun _ => x) a
  diagonal_instance :
    PointedInstance zero succ eqtest (fun n => eqtest n n) (succ zero)

/- The e comparison program in the paper has the two displayed recursion
equations below. These are enough to produce the computational hypotheses
used by Core; its lower-left corner and range are not assumed. -/
theorem comparison_computations {α : Type u}
    (zero : α) (succ pred : α → α)
    (branch eqtest : α → α → α) (select : α → α → α → α)
    (pred_succ : ∀ n, pred (succ n) = n)
    (branch_zero : ∀ a, branch zero a = a)
    (select_succ : ∀ n x y, select (succ n) x y = y)
    (eqtest_base : ∀ y, eqtest zero y = branch y (succ zero))
    (eqtest_step : ∀ n y,
      eqtest (succ n) y = select y zero (eqtest n (pred y))) :
    eqtest zero zero = succ zero ∧
      ∀ x y, eqtest (succ x) (succ y) = eqtest x y := by
  constructor
  · exact (eqtest_base zero).trans (branch_zero (succ zero))
  · intro x y
    calc
      eqtest (succ x) (succ y) =
          select (succ y) zero (eqtest x (pred (succ y))) := eqtest_step x (succ y)
      _ = eqtest x (pred (succ y)) := select_succ y zero (eqtest x (pred (succ y)))
      _ = eqtest x y := congrArg (eqtest x) (pred_succ y)

theorem selector_computations {α : Type u}
    (zero : α) (succ : α → α) (predSeed branch : α → α → α)
    (predSeed_zero : ∀ a, predSeed zero a = a)
    (predSeed_succ : ∀ n a, predSeed (succ n) a = n)
    (branch_zero : ∀ a, branch zero a = a)
    (branch_succ : ∀ n a, branch (succ n) a = zero) :
    let select := fun z x y => predSeed (branch z (succ x)) y
    (∀ x y, select zero x y = x) ∧
      ∀ n x y, select (succ n) x y = y := by
  dsimp
  constructor
  · intro x y
    exact (congrArg (fun z => predSeed z y) (branch_zero (succ x))).trans
      (predSeed_succ x y)
  · intro n x y
    exact (congrArg (fun z => predSeed z y) (branch_succ n (succ x))).trans
      (predSeed_zero y)

namespace Core

variable {α : Type u} (D : Core α)

abbrev one : α := D.succ D.zero

theorem one_ne_zero : D.one ≠ D.zero := by
  intro h
  exact D.separated h.symm

theorem off_diagonal (x y : α) : D.eqtest x y = D.zero ∨ x = y := by
  exact D.constant_instances x y (fun _ => rfl) D.zero

theorem diagonal_one (x : α) : D.eqtest x x = D.one := by
  have at_one : D.eqtest D.one D.one = D.one :=
    (D.diagonal_step D.zero).trans D.diagonal_base
  have first_value : D.eqtest (D.eqtest D.zero D.zero) D.one = D.one :=
    (congrArg (fun z => D.eqtest z D.one) D.diagonal_base).trans at_one
  cases D.diagonal_instance D.diagonal_step x with
  | inl h => exact False.elim (D.one_ne_zero (first_value.symm.trans h))
  | inr h => exact h

theorem eqtest_bits (x y : α) :
    D.eqtest x y = D.zero ∨ D.eqtest x y = D.one := by
  cases D.off_diagonal x y with
  | inl h => exact Or.inl h
  | inr h =>
    cases h
    exact Or.inr (D.diagonal_one x)

theorem eqtest_one_iff (x y : α) : D.eqtest x y = D.one ↔ x = y := by
  constructor
  · intro h
    cases D.off_diagonal x y with
    | inl hz => exact False.elim (D.one_ne_zero (h.symm.trans hz))
    | inr hxy => exact hxy
  · intro h
    cases h
    exact D.diagonal_one x

theorem eqtest_zero_iff (x y : α) : D.eqtest x y = D.zero ↔ x ≠ y := by
  constructor
  · intro hz hxy
    cases hxy
    exact D.one_ne_zero ((D.diagonal_one x).symm.trans hz)
  · intro hxy
    cases D.off_diagonal x y with
    | inl hz => exact hz
    | inr heq => exact False.elim (hxy heq)

include D in
theorem equality_decision (x y : α) : x = y ∨ x ≠ y := by
  cases D.off_diagonal x y with
  | inl hz => exact Or.inr ((D.eqtest_zero_iff x y).mp hz)
  | inr heq => exact Or.inl heq

theorem successor_laws (pred : α → α)
    (pred_zero : pred D.zero = D.zero)
    (pred_succ : ∀ n, pred (D.succ n) = n) :
    (∀ x, D.succ x ≠ D.zero) ∧
      ∀ x y, D.succ x = D.succ y → x = y := by
  constructor
  · intro x hx
    have xzero : x = D.zero :=
      (pred_succ x).symm.trans ((congrArg pred hx).trans pred_zero)
    exact D.one_ne_zero ((congrArg D.succ xzero).symm.trans hx)
  · intro x y h
    exact (pred_succ x).symm.trans ((congrArg pred h).trans (pred_succ y))

theorem constancy (t : α → α)
    (instance_at_base : PointedInstance D.zero D.succ D.eqtest t (t D.zero))
    (stationary : ∀ n, t (D.succ n) = t n) : ∀ n, t n = t D.zero := by
  intro n
  cases instance_at_base stationary n with
  | inl hz =>
    exact False.elim (D.one_ne_zero ((D.diagonal_one (t D.zero)).symm.trans hz))
  | inr heq => exact heq

structure BitRep (P : Prop) (b : α) : Prop where
  bits : b = D.zero ∨ b = D.one
  truth : P ↔ b = D.one

namespace BitRep

variable {D} {P Q : Prop} {b : α}

theorem transport (R : D.BitRep P b) {c : α} (h : b = c) : D.BitRep P c := by
  cases h
  exact R

theorem not_of_zero (R : D.BitRep P b) (hz : b = D.zero) : ¬ P := by
  intro hp
  exact D.one_ne_zero ((R.truth.mp hp).symm.trans hz)

end BitRep

theorem bitrep_of_false {P : Prop} (hp : ¬ P) : D.BitRep P D.zero where
  bits := Or.inl rfl
  truth := ⟨fun p => False.elim (hp p), fun h => False.elim (D.separated h)⟩

theorem bitrep_of_true {P : Prop} (hp : P) : D.BitRep P D.one where
  bits := Or.inr rfl
  truth := ⟨fun _ => rfl, fun _ => hp⟩

theorem atomic_representation (x y : α) : D.BitRep (x = y) (D.eqtest x y) where
  bits := D.eqtest_bits x y
  truth := (D.eqtest_one_iff x y).symm

structure Selector where
  select : α → α → α → α
  at_zero : ∀ x y, select D.zero x y = x
  at_one : ∀ x y, select D.one x y = y

variable (C : D.Selector)

theorem and_representation {P Q : Prop} {b c : α}
    (RP : D.BitRep P b) (RQ : D.BitRep Q c) :
    D.BitRep (P ∧ Q) (C.select b D.zero c) := by
  cases RP.bits with
  | inl hb =>
    have hn : ¬ (P ∧ Q) := fun hpq => RP.not_of_zero hb hpq.1
    have hc : C.select b D.zero c = D.zero :=
      (congrArg (fun z => C.select z D.zero c) hb).trans (C.at_zero D.zero c)
    exact (D.bitrep_of_false hn).transport hc.symm
  | inr hb =>
    have hp : P := RP.truth.mpr hb
    have R : D.BitRep (P ∧ Q) c :=
      ⟨RQ.bits, ⟨fun hpq => RQ.truth.mp hpq.2, fun h => ⟨hp, RQ.truth.mpr h⟩⟩⟩
    have hc : C.select b D.zero c = c :=
      (congrArg (fun z => C.select z D.zero c) hb).trans (C.at_one D.zero c)
    exact R.transport hc.symm

theorem or_representation {P Q : Prop} {b c : α}
    (RP : D.BitRep P b) (RQ : D.BitRep Q c) :
    D.BitRep (P ∨ Q) (C.select b c D.one) := by
  cases RP.bits with
  | inl hb =>
    have hn : ¬ P := RP.not_of_zero hb
    have R : D.BitRep (P ∨ Q) c :=
      ⟨RQ.bits, ⟨fun h => h.elim (fun hp => False.elim (hn hp)) RQ.truth.mp,
        fun h => Or.inr (RQ.truth.mpr h)⟩⟩
    have hc : C.select b c D.one = c :=
      (congrArg (fun z => C.select z c D.one) hb).trans (C.at_zero c D.one)
    exact R.transport hc.symm
  | inr hb =>
    have hpq : P ∨ Q := Or.inl (RP.truth.mpr hb)
    have hc : C.select b c D.one = D.one :=
      (congrArg (fun z => C.select z c D.one) hb).trans (C.at_one c D.one)
    exact (D.bitrep_of_true hpq).transport hc.symm

theorem implication_representation {P Q : Prop} {b c : α}
    (RP : D.BitRep P b) (RQ : D.BitRep Q c) :
    D.BitRep (P → Q) (C.select b D.one c) := by
  cases RP.bits with
  | inl hb =>
    have hpq : P → Q := fun hp => False.elim (RP.not_of_zero hb hp)
    have hc : C.select b D.one c = D.one :=
      (congrArg (fun z => C.select z D.one c) hb).trans (C.at_zero D.one c)
    exact (D.bitrep_of_true hpq).transport hc.symm
  | inr hb =>
    have hp : P := RP.truth.mpr hb
    have R : D.BitRep (P → Q) c :=
      ⟨RQ.bits, ⟨fun hpq => RQ.truth.mp (hpq hp), fun h _ => RQ.truth.mpr h⟩⟩
    have hc : C.select b D.one c = c :=
      (congrArg (fun z => C.select z D.one c) hb).trans (C.at_one D.one c)
    exact R.transport hc.symm

/- This datatype describes finite propositional formulas after their atom
terms have been evaluated under a fixed assignment. It does not purport to
formalize first-order arithmetic syntax or quantifiers. -/
inductive Formula (α : Type u) where
  | equal : α → α → Formula α
  | falsity : Formula α
  | truth : Formula α
  | conjunction : Formula α → Formula α → Formula α
  | disjunction : Formula α → Formula α → Formula α
  | implication : Formula α → Formula α → Formula α

def Formula.meaning : Formula α → Prop
  | .equal x y => x = y
  | .falsity => False
  | .truth => True
  | .conjunction G H => G.meaning ∧ H.meaning
  | .disjunction G H => G.meaning ∨ H.meaning
  | .implication G H => G.meaning → H.meaning

def compile : Formula α → α
  | .equal x y => D.eqtest x y
  | .falsity => D.zero
  | .truth => D.one
  | .conjunction G H => C.select (compile G) D.zero (compile H)
  | .disjunction G H => C.select (compile G) (compile H) D.one
  | .implication G H => C.select (compile G) D.one (compile H)

theorem compiler_correct (F : Formula α) : D.BitRep F.meaning (D.compile C F) := by
  induction F with
  | equal x y => exact D.atomic_representation x y
  | falsity => exact D.bitrep_of_false (fun h => h)
  | truth => exact D.bitrep_of_true True.intro
  | conjunction G H ihG ihH => exact D.and_representation C ihG ihH
  | disjunction G H ihG ihH => exact D.or_representation C ihG ihH
  | implication G H ihG ihH => exact D.implication_representation C ihG ihH

theorem shifted_latch_induction
    (P : α → Prop) (b r : α → α)
    (represent : ∀ n, D.BitRep (P n) (b n))
    (rbase : r D.zero = D.one)
    (rstep : ∀ n, r (D.succ n) = C.select (b n) D.zero (r n))
    (shifted_instance : PointedInstance D.zero D.succ D.eqtest
      (fun n => r (D.succ n)) (r (D.succ D.zero)))
    (base : P D.zero) (step : ∀ n, P n → P (D.succ n)) : ∀ n, P n := by
  have select_same (z : α) (hz : z = D.zero ∨ z = D.one) :
      C.select z D.zero D.zero = D.zero := by
    cases hz with
    | inl h => exact h ▸ C.at_zero D.zero D.zero
    | inr h => exact h ▸ C.at_one D.zero D.zero
  have bbase : b D.zero = D.one := (represent D.zero).truth.mp base
  have shifted_base : r (D.succ D.zero) = D.one := by
    calc
      r (D.succ D.zero) = C.select (b D.zero) D.zero (r D.zero) := rstep D.zero
      _ = C.select D.one D.zero (r D.zero) := congrArg
        (fun z => C.select z D.zero (r D.zero)) bbase
      _ = r D.zero := C.at_one D.zero (r D.zero)
      _ = D.one := rbase
  have shifted_step : ∀ n, r (D.succ (D.succ n)) = r (D.succ n) := by
    intro n
    cases (represent n).bits with
    | inl hz =>
      have hn : r (D.succ n) = D.zero := by
        calc
          r (D.succ n) = C.select (b n) D.zero (r n) := rstep n
          _ = C.select D.zero D.zero (r n) := congrArg
            (fun z => C.select z D.zero (r n)) hz
          _ = D.zero := C.at_zero D.zero (r n)
      calc
        r (D.succ (D.succ n)) =
            C.select (b (D.succ n)) D.zero (r (D.succ n)) := rstep (D.succ n)
        _ = C.select (b (D.succ n)) D.zero D.zero := congrArg
          (fun z => C.select (b (D.succ n)) D.zero z) hn
        _ = D.zero := select_same (b (D.succ n)) (represent (D.succ n)).bits
        _ = r (D.succ n) := hn.symm
    | inr hone =>
      have hnext : b (D.succ n) = D.one :=
        (represent (D.succ n)).truth.mp (step n ((represent n).truth.mpr hone))
      calc
        r (D.succ (D.succ n)) =
            C.select (b (D.succ n)) D.zero (r (D.succ n)) := rstep (D.succ n)
        _ = C.select D.one D.zero (r (D.succ n)) := congrArg
          (fun z => C.select z D.zero (r (D.succ n))) hnext
        _ = r (D.succ n) := C.at_one D.zero (r (D.succ n))
  have shifted_one : ∀ n, r (D.succ n) = D.one := by
    intro n
    exact (D.constancy (fun j => r (D.succ j)) shifted_instance shifted_step n).trans
      shifted_base
  intro n
  apply (represent n).truth.mpr
  cases (represent n).bits with
  | inl hz =>
    have hn : r (D.succ n) = D.zero := by
      calc
        r (D.succ n) = C.select (b n) D.zero (r n) := rstep n
        _ = C.select D.zero D.zero (r n) := congrArg
          (fun z => C.select z D.zero (r n)) hz
        _ = D.zero := C.at_zero D.zero (r n)
    exact False.elim (D.one_ne_zero ((shifted_one n).symm.trans hn))
  | inr hone => exact hone

theorem compiled_formula_induction
    (F : α → Formula α) (r : α → α)
    (rbase : r D.zero = D.one)
    (rstep : ∀ n, r (D.succ n) =
      C.select (D.compile C (F n)) D.zero (r n))
    (shifted_instance : PointedInstance D.zero D.succ D.eqtest
      (fun n => r (D.succ n)) (r (D.succ D.zero)))
    (base : (F D.zero).meaning)
    (step : ∀ n, (F n).meaning → (F (D.succ n)).meaning) :
    ∀ n, (F n).meaning := by
  exact D.shifted_latch_induction C (fun n => (F n).meaning)
    (fun n => D.compile C (F n)) r (fun n => D.compiler_correct C (F n))
    rbase rstep shifted_instance base step

#print axioms off_diagonal
#print axioms diagonal_one
#print axioms eqtest_bits
#print axioms eqtest_one_iff
#print axioms eqtest_zero_iff
#print axioms equality_decision
#print axioms successor_laws
#print axioms constancy
#print axioms atomic_representation
#print axioms and_representation
#print axioms or_representation
#print axioms implication_representation
#print axioms compiler_correct
#print axioms shifted_latch_induction
#print axioms compiled_formula_induction

end Core

/- Independent converse interface: no Core or pointed instance is assumed.
The article derives these hypotheses inside PRA by QF induction. -/
theorem pointed_from_constancy {α : Type u}
    (zero : α) (succ : α → α) (eqtest : α → α → α)
    (f : α → α) (a : α)
    (decision : f zero = a ∨ f zero ≠ a)
    (zero_for_disequal : f zero ≠ a → eqtest (f zero) a = zero)
    (constant_if_stationary : (∀ n, f (succ n) = f n) →
      ∀ n, f n = f zero) : PointedInstance zero succ eqtest f a := by
  intro stationary n
  cases decision with
  | inl h => exact Or.inr ((constant_if_stationary stationary n).trans h)
  | inr h => exact Or.inl (zero_for_disequal h)

#print axioms pointed_from_constancy
#print axioms comparison_computations
#print axioms selector_computations

end PRAPointedConstancy
