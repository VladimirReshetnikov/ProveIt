CONSTRUCTIVE LEAN KERNEL: POINTED CONSTANCY

File: PointedConstancy.lean
Runtime: Lean 4.19.0, import Init only; no Mathlib dependency.

REPLAY
  lean PointedConstancy.lean

WHAT IS CHECKED

1. The comparator's zero/zero and simultaneous-successor equations are
   consequences of its explicit substitution-recursion equations.
2. The composite selector's constructor equations are literal computations.
3. Constant pointed instances yield the native off-diagonal disjunction.
4. One pointed instance for n |-> e(n,n), anchored at 1, yields e(n,n)=1.
5. These facts give the Boolean range, exact recognition of native equality,
   exact recognition of disequality, and decidable native equality.
6. Predecessor equations plus separation yield the successor laws.
7. One pointed instance for a given stationary term yields its constancy.
8. A finite semantic propositional compiler handles equality, false, true,
   conjunction, disjunction, and implication constructively.
9. One particular instance for a shifted primitive-recursive latch yields
   induction for its represented predicate.
10. The compiler and latch are linked in compiled_formula_induction.
11. An independent converse interface derives one pointed instance from
    ordinary constancy, equality decision, and the equality indicator's
    off-diagonal value; it assumes no Core or pointed instance.

INSTANCE-LEVEL ASSUMPTIONS

There is no global assumption that every set-theoretic function on the
carrier satisfies the proposed schema. The Core structure takes only:
  - the constant-term instances, uniformly in their two numerical parameters;
  - the single diagonal-term instance anchored at 1;
along with the specified computation equations and ground separation.
The constancy and latch theorems take their additional single instance as
an explicit argument. Arbitrary fixed arithmetic parameters can be held
in the corresponding function closure; the paper proves these closures
come from legitimate finite terms and admitted primitive recursions.

VERIFICATION BOUNDARY

Lean equality is the carrier's native equality throughout. The carrier is
arbitrary. No classical logic, choice, induction on the carrier, sorry,
admit, or new global axiom occurs. The included #print axioms commands
audit the exported proof dependencies; the compilation log records them.

Formula is a finite semantic propositional datatype after atom terms have
been evaluated under a fixed assignment. It is not an encoding of the full
first-order arithmetic language. The file does not mechanize the complete
term grammar, proof calculus, syntactic schema substitution, arithmetic
primitive-recursion compiler, its uniqueness proof, the two interpretation
composites, or the full equiconsistency/bi-interpretability theorem. Those
parts are mathematical proofs in the accompanying manuscript. The local
certificate is intended to make the new constructive bootstrap and latch
argument independently auditable, not to overstate the formal scope.
