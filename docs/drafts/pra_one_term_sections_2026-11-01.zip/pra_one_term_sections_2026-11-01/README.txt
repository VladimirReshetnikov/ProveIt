PRA FROM ONE TERM AND ITS SECTIONS
Research prepared for Vladimir Reshetnikov
1 November 2026 (America/Los_Angeles)

RESULT
The preferred axiom generator uses one finite term u(n,a,b), one constructor,
and no separately assumed diagonal identity. Its probes are u(n,a,0) and
u(n,a,a); its attached computation descriptor is the zero section u(v,0,0).
The third formal slot is substituted away, leaving two individual names in
each emitted sentence. The same specification is definitionally equivalent
to classical or intuitionistic first-order PRA in the matching logic.

A companion result keeps the previous two-term input interface exactly.
Changing its diagonal to a zero section and shortening its successor
conclusion saves exactly 5+3*occ_a(s) active AST nodes in every generated
axiom. This is a strict fixed-interface improvement independent of the
preferred presentation's third-formal-slot tradeoff.

START HERE
report.pdf                    Full mathematical manuscript.
AXIOMS.txt                    Standalone exact complete specification.
report.tex + sections/*.tex    Complete editable LaTeX sources.

EVIDENCE AND REPRODUCTION
formal/SectionsKernel.lean     New constructive local kernel, core Lean only.
formal/lean-toolchain          Compiler version used.
formal/SCOPE.txt               Exact formal-verification boundary.
checks/check_schema.py         Finite syntax generator and bounded diagnostics.
checks/results.json           Exact counts and recorded test outcomes.
checks/examples.txt           Expanded generated examples and descriptor list.
audit/source_manifest.json    Pinned repository snapshot and input hashes.
audit/lean_check.txt           Actual compiler/version/source-hash receipt.
audit/mathematical_review.txt  Independent review of the completed proof.
audit/validation.json          Build and PDF validation record.
build.py                      Rebuild PDF and regenerate checks.
SHA256SUMS.txt                 Integrity hashes of the packaged deliverables.

REBUILD
From this directory:
  python3 build.py

Requirements: Python 3 and pdfLaTeX with the standard packages in report.tex.
No download or installation is performed by the build.

To repeat the separate Lean check with Lean 4.19.0:
  lean formal/SectionsKernel.lean
or:
  python3 build.py --lean /absolute/path/to/lean

VERIFICATION LIMITS
All 13 audited principal Lean declarations were checked and use no axioms.
They prove the local arbitrary-carrier compression argument under explicit
computational and propagation hypotheses. They do not formalize the entire
first-order language, truth compiler, scalar pairing, PR compiler, or full
bi-interpretation. Those proofs are in the manuscript. Finite Python examples
are diagnostics and do not prove consistency or induction strength.

SOURCES
All three current ProveIt/docs/drafts archives at revision
d605be20835fc80907e01a105bcb059f07ed8b8c were reviewed. Their hashes are in the
source manifest. The delayed language and arithmetic calibration are credited
to them; the section generator, selector bootstrap, parameter probe, and
strict zero-section count reduction are the new contributions.

The report includes Further research questions. It does not claim a global
shortest axiomatization or that the old unchanged fixed-point schema no longer
needs its diagonal axiom. No repository files were modified or published.
